from abc import ABC, abstractmethod
from enum import Enum
from typing import Literal

from .base import InputModel
from .elem import DocElement


class EvalStatus(Enum):
    """Evaluation status enum."""

    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"


class EvalLayoutBlock(InputModel):
    id: str | None = None
    type: str
    bbox: list[float]
    angle: Literal[0, 90, 180, 270] | None = None
    format: str
    content: str


class EvalLayout(DocElement):
    """Eval layout of a page."""

    layout_id: str  # gt layout_id
    provider: str  # eval target provider
    blocks: list[EvalLayoutBlock] = []
    relations: list[dict] = []
    status: Literal["pending", "success", "failed"] = "pending"


class EvalContent(DocElement):
    """Eval content of a block."""

    content_id: str  # gt content_id
    version: str  # eval target version
    format: str
    content: str
    status: Literal["pending", "success", "failed"] = "pending"


class EvalABC(ABC):
    """Abstract class for eval operations."""

    @abstractmethod
    def get_eval_layout(self, eval_layout_id: str) -> EvalLayout:
        """Get an eval layout by its ID."""
        raise NotImplementedError()

    @abstractmethod
    def get_eval_content(self, eval_content_id: str) -> EvalContent:
        """Get an eval content by its ID."""
        raise NotImplementedError()

    @abstractmethod
    def insert_eval_layout(
        self,
        layout_id: str,
        provider: str,
        blocks: list[EvalLayoutBlock] | None = None,
        relations: list[dict] | None = None,
    ) -> EvalLayout:
        """Insert a new eval layout into the database."""
        raise NotImplementedError()

    @abstractmethod
    def insert_eval_content(
        self,
        content_id: str,
        version: str,
        format: str,
        content: str,
    ) -> EvalContent:
        """Insert a new eval content into the database."""
        raise NotImplementedError()


class AioEvalABC(ABC):
    """Async abstract class for eval operations."""

    @abstractmethod
    async def get_eval_layout(self, eval_layout_id: str) -> EvalLayout:
        """Get an eval layout by its ID (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def get_eval_content(self, eval_content_id: str) -> EvalContent:
        """Get an eval content by its ID (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_eval_layout(
        self,
        layout_id: str,
        provider: str,
        blocks: list[EvalLayoutBlock] | None = None,
        relations: list[dict] | None = None,
    ) -> EvalLayout:
        """Insert a new eval layout into the database (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_eval_content(
        self,
        content_id: str,
        version: str,
        format: str,
        content: str,
    ) -> EvalContent:
        """Insert a new eval content into the database (async)."""
        raise NotImplementedError()
