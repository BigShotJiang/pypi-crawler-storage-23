from .tagging import ElementWithTags
from .task import ElementWithTask
from .value import ElementWithValue


class DocElement(ElementWithTags, ElementWithValue, ElementWithTask):
    """Base class for all doc elements."""
