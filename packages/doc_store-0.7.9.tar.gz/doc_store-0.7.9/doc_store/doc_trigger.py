import argparse
import os
import sys
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

from confluent_kafka import KafkaException

from .doc_store import DocStore
from .interface import DocEvent, Trigger, TriggerAction, TriggerCondition
from .utils import timed_property


def log(*args):
    ts = time.strftime("%m-%d %H:%M:%S")
    print(f"[{ts}]", *args, file=sys.stderr, flush=True)


def to_list(obj: None | str | list[str]) -> None | list[str]:
    if obj is None or isinstance(obj, list):
        return obj
    return [obj]


def parse_event(dic: dict):
    return DocEvent(
        elem_id=dic["elem_id"],
        elem_type=dic["elem_type"],
        event_type=dic["event_type"],
        event_user=dic["event_user"],
        doc_id=dic.get("doc_id"),
        page_id=dic.get("page_id"),
        layout_id=dic.get("layout_id"),
        block_id=dic.get("block_id"),
        page_providers=dic.get("page_providers"),
        layout_provider=dic.get("layout_provider"),
        block_type=dic.get("block_type"),
        block_versions=dic.get("block_versions"),
        content_version=dic.get("content_version"),
        tags=dic.get("tags"),
        page_tags=dic.get("page_tags"),
        tag_added=to_list(dic.get("tag_added")),
        tag_deleted=to_list(dic.get("tag_deleted")),
        provider_added=dic.get("provider_added"),
        version_added=dic.get("version_added"),
    )


def can_trigger(event: DocEvent, condition: TriggerCondition) -> bool:
    e, cond = event, condition  # create alias for brevity
    if cond.elem_type != e.elem_type:
        return False
    if cond.event_type != e.event_type:
        # special case: tag can be added during insert.
        if cond.event_type != "add_tag" or e.event_type != "insert":
            return False
    if cond.event_user and cond.event_user != e.event_user:
        return False
    if cond.tags:  # most used, put it first
        tags = set((e.tags or []) + (e.tag_added or []))
        if any(t not in tags for t in cond.tags):
            return False
    if cond.elem_type == "page" and cond.page_providers:
        providers = set(e.page_providers or [])
        if e.provider_added:
            providers.add(e.provider_added)
        if any(p not in providers for p in cond.page_providers):
            return False
    if cond.elem_type == "block" and cond.block_versions:
        versions = set(e.block_versions or [])
        if e.version_added:
            versions.add(e.version_added)
        if any(v not in versions for v in cond.block_versions):
            return False
    if cond.elem_type in ("layout", "block") and cond.page_tags:
        page_tags = set(e.page_tags or [])
        if any(t not in page_tags for t in cond.page_tags):
            return False
    if cond.elem_type in ("layout", "block") and cond.layout_provider:
        if e.layout_provider not in cond.layout_provider:
            return False
    if cond.elem_type == "block" and cond.block_type:
        if e.block_type not in cond.block_type:
            return False
    if cond.elem_type == "content" and cond.content_version:
        if e.content_version not in cond.content_version:
            return False
    if cond.event_type == "add_tag" and cond.tag_added:
        if all(t not in cond.tag_added for t in e.tag_added or []):
            return False
    if cond.event_type == "del_tag" and cond.tag_deleted:
        if all(t not in cond.tag_deleted for t in e.tag_deleted or []):
            return False
    if cond.event_type == "add_provider" and cond.provider_added:
        if e.provider_added not in cond.provider_added:
            return False
    if cond.event_type == "add_version" and cond.version_added:
        if e.version_added not in cond.version_added:
            return False
    return True


def do_action(event: DocEvent, action: TriggerAction, store: DocStore):
    if action.action_type == "add_tag":
        if action.add_tag:
            log("Adding tag", action.add_tag, "to", event.elem_id)
            store.add_tag(event.elem_id, action.add_tag)
        else:
            log("No tag specified to add.")

    elif action.action_type == "insert_task":
        if action.insert_task:
            log("Inserting task", action.insert_task, "for", event.elem_id)
            store.insert_task(event.elem_id, action.insert_task)
        else:
            log("No task specified to insert.")


class TriggerHandler:
    def __init__(self, store: DocStore):
        self.store = store
        self.store_cache = {}

    def get_store(self, username: str) -> DocStore:
        store = self.store_cache.get(username)
        if not store:
            store = self.store.impersonate(username)
            self.store_cache[username] = store
        return store

    @timed_property(ttl=60)
    def triggers(self) -> list[Trigger]:
        triggers = self.store.list_triggers()
        return [t for t in triggers if not t.disabled]

    def handle_event(self, event: DocEvent | dict):
        if not isinstance(event, DocEvent):
            event = parse_event(event)
        triggers: list[Trigger] = self.triggers
        for trigger in triggers:
            if can_trigger(event, trigger.condition):
                store = self.get_store(trigger.create_user)
                for action in trigger.actions:
                    do_action(event, action, store)


class EventStreamHandler:
    def __init__(
        self,
        trigger_handler: TriggerHandler,
        batch_size: int,
        io_executor: ThreadPoolExecutor | None,
        verbose: bool,
    ) -> None:
        from .kafka import KafkaReader

        self.group_id = "event-stream-handler"
        self.batch_size = batch_size
        self.io_executor = io_executor
        self.verbose = verbose
        config = {"auto.offset.reset": "latest"}
        self.kafka_reader = KafkaReader(self.group_id, self.batch_size, config)
        self.trigger_handler = trigger_handler

    def handle_in_loop(self):
        log("Event stream handler started...")

        cnt = 0
        start_time = time.time()
        last_end = start_time
        last_commit_time = start_time
        last_report_time = start_time
        verbose = self.verbose

        while True:
            batch_begin = time.time()
            s_cost = round(batch_begin - last_end, 4)

            begin = batch_begin
            messages = self.kafka_reader.next(timeout=5, commit_last_batch=False)
            last_end = time.time()
            r_cost = round(last_end - begin, 4)

            begin = last_end
            if self.io_executor is None:
                for msg in messages:
                    self.trigger_handler.handle_event(msg)
            else:  # use thread pool
                _ = list(self.io_executor.map(self.trigger_handler.handle_event, messages))
            last_end = time.time()
            h_cost = round(last_end - begin, 4)

            begin = last_end
            if begin - last_commit_time > 10:
                last_commit_time = begin
                self.kafka_reader.commit()
            last_end = time.time()
            c_cost = round(last_end - begin, 4)

            batch_sz = len(messages)
            cnt += batch_sz
            if verbose or (last_end - last_report_time > 10):
                last_report_time = last_end
                cnt_report = f"{cnt-batch_sz}+{batch_sz}"
                pure_qps = round(batch_sz / max(h_cost, 1e-6), 4)
                batch_qps = round(batch_sz / max(last_end - batch_begin, 1e-6), 4)
                acc_qps = round(cnt / max(last_end - start_time, 1e-6), 4)
                log(f"{cnt_report} | {r_cost} | {h_cost} | {c_cost} | {s_cost} | {pure_qps} | {batch_qps} | {acc_qps}")

            if not messages:
                time.sleep(1)


class DocStoreWithIDTags(DocStore):
    def _check_tag_name(self, name: str):
        if name.startswith(("pagepool__", "blockpool__")):
            return
        elif name.startswith(("layoutset__", "contentset__")):
            return
        else:
            return super()._check_tag_name(name)


def main():
    parser = argparse.ArgumentParser(usage=f"{sys.argv[0]} [options]")
    parser.add_argument("--batch-size", type=int, default=500, help="Number of events to handle each time")
    parser.add_argument("--num-threads", type=int, default=10, help="Number of threads to use")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")
    args = parser.parse_args()

    log("PID =", os.getpid())

    verbose: bool = args.verbose
    log("Verbose mode =", verbose)

    batch_size: int = args.batch_size
    assert 0 < batch_size < 5000, "batch_size should be in [1, 4999]"
    log("batch_size =", batch_size)

    num_threads: int = args.num_threads
    assert 0 <= num_threads < 100, "num_threads should be in [0, 99]"
    log("num_threads =", num_threads)

    io_executor = None
    if num_threads > 0:
        log(f"Initializing IO thread pool with {num_threads} threads...")
        io_executor = ThreadPoolExecutor(num_threads)

    log("Initializing doc store...")
    store = DocStoreWithIDTags()
    # mark_worker_as_ready()

    log("Initializing trigger handler...")
    trigger_handler = TriggerHandler(store)

    log("Initializing event stream handler...")
    stream_handler = EventStreamHandler(trigger_handler, batch_size, io_executor, verbose)

    while True:
        try:
            stream_handler.handle_in_loop()
        except KafkaException as e:
            print(type(e), str(e), file=sys.stderr)
            traceback.print_exc()
            time.sleep(10)
            continue
        except Exception as e:
            print(type(e), str(e), file=sys.stderr)
            traceback.print_exc()
            break


if __name__ == "__main__":
    main()
