from typing import Literal

from pydantic import BaseModel


class ScanCondition(BaseModel):
    elem_type: Literal["doc", "page", "layout", "block", "content"]
    page_providers: list[str] | None = None  # Match page with all these providers
    layout_provider: list[str] | None = None  # Match layout/block with any of these providers
    block_type: list[str] | None = None  # Match block with any of these types
    block_versions: list[str] | None = None  # Match block with all these versions
    content_version: list[str] | None = None  # Match content with any of these versions
    tags: list[str] | None = None  # Match element with all these tags
    no_page_providers: list[str] | None = None  # Match page without all these providers
    no_block_versions: list[str] | None = None  # Match block without all these versions
    no_tags: list[str] | None = None  # Match element without all these tags

    # attrs
    # metrics


class ScanAction(BaseModel):
    pass


class ScanInput(InputModel):
    name: str
    description: str
    condition: ScanCondition
    actions: list[ScanAction]
    sample_rate: float | None = None  # between 0 and 1
    limit: int | None = None
