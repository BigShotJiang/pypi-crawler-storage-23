"""Database operation interface for abstracting MongoDB and MySQL implementations."""

from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any, Iterable, Literal, Sequence

from pydantic import BaseModel


class IndexDefinition(BaseModel):
    """Index definition for database operations."""

    keys: list[tuple[str, int]]  # [(field_name, direction)] where direction: 1 for asc, -1 for desc
    unique: bool = False
    name: str | None = None  # Optional index name


class UpdateOperation(BaseModel):
    """Update operation definition."""

    filter: dict[str, Any]
    update: dict[str, Any]  # MongoDB update operators or SQL SET clause
    upsert: bool = False
    return_document: bool = False  # Whether to return the updated document


class QueryOptions(BaseModel):
    """Query options for database operations."""

    skip: int | None = None
    limit: int | None = None
    sort: list[tuple[str, int]] | None = None  # [(field_name, direction)]
    projection: dict[str, int] | list[str] | None = None  # Fields to include/exclude
    max_time_ms: int | None = None  # Maximum query execution time


class AggregateStage(BaseModel):
    """Aggregation pipeline stage."""

    stage_type: str  # e.g., "$match", "$group", "$lookup", etc.
    stage_data: dict[str, Any]


class DatabaseCollection(ABC):
    """Abstract interface for database collection/table operations."""

    @abstractmethod
    def find_one(
        self,
        filter: dict[str, Any],
        projection: dict[str, int] | list[str] | None = None,
    ) -> dict[str, Any] | None:
        """
        Find a single document/row matching the filter.

        Args:
            filter: Query filter conditions
            projection: Fields to include/exclude (MongoDB style) or column list (SQL style)

        Returns:
            Document/row as dict, or None if not found
        """
        raise NotImplementedError()

    @abstractmethod
    def find(
        self,
        filter: dict[str, Any],
        options: QueryOptions | None = None,
    ) -> Iterable[dict[str, Any]]:
        """
        Find multiple documents/rows matching the filter.

        Args:
            filter: Query filter conditions
            options: Query options (skip, limit, sort, projection, etc.)

        Returns:
            Iterable of documents/rows as dicts
        """
        raise NotImplementedError()

    @abstractmethod
    def aggregate(
        self,
        pipeline: list[dict[str, Any]],
        options: QueryOptions | None = None,
    ) -> Iterable[dict[str, Any]]:
        """
        Execute aggregation pipeline.

        Args:
            pipeline: Aggregation pipeline stages
            options: Query options (max_time_ms, etc.)

        Returns:
            Iterable of aggregated results
        """
        raise NotImplementedError()

    @abstractmethod
    def insert_one(self, document: dict[str, Any]) -> str:
        """
        Insert a single document/row.

        Args:
            document: Document/row data as dict

        Returns:
            Inserted document ID
        """
        raise NotImplementedError()

    @abstractmethod
    def insert_many(
        self,
        documents: Sequence[dict[str, Any]],
        ordered: bool = True,
    ) -> list[str]:
        """
        Insert multiple documents/rows.

        Args:
            documents: Sequence of documents/rows
            ordered: Whether to stop on first error (True) or continue (False)

        Returns:
            List of inserted document IDs
        """
        raise NotImplementedError()

    @abstractmethod
    def update_one(
        self,
        filter: dict[str, Any],
        update: dict[str, Any],
        upsert: bool = False,
    ) -> int:
        """
        Update a single document/row.

        Args:
            filter: Query filter conditions
            update: Update operations (MongoDB operators or SQL SET clause)
            upsert: Whether to insert if document doesn't exist

        Returns:
            Number of documents/rows modified (0 or 1)
        """
        raise NotImplementedError()

    @abstractmethod
    def update_many(
        self,
        filter: dict[str, Any],
        update: dict[str, Any],
    ) -> int:
        """
        Update multiple documents/rows.

        Args:
            filter: Query filter conditions
            update: Update operations

        Returns:
            Number of documents/rows modified
        """
        raise NotImplementedError()

    @abstractmethod
    def find_one_and_update(
        self,
        filter: dict[str, Any],
        update: dict[str, Any],
        projection: dict[str, int] | list[str] | None = None,
        upsert: bool = False,
        return_document: Literal["before", "after"] = "after",
    ) -> dict[str, Any] | None:
        """
        Find and update a single document/row atomically.

        Args:
            filter: Query filter conditions
            update: Update operations
            projection: Fields to include/exclude in returned document
            upsert: Whether to insert if document doesn't exist
            return_document: Return document before or after update

        Returns:
            Document/row as dict, or None if not found (and not upserted)
        """
        raise NotImplementedError()

    @abstractmethod
    def delete_one(self, filter: dict[str, Any]) -> int:
        """
        Delete a single document/row.

        Args:
            filter: Query filter conditions

        Returns:
            Number of documents/rows deleted (0 or 1)
        """
        raise NotImplementedError()

    @abstractmethod
    def delete_many(self, filter: dict[str, Any]) -> int:
        """
        Delete multiple documents/rows.

        Args:
            filter: Query filter conditions

        Returns:
            Number of documents/rows deleted
        """
        raise NotImplementedError()

    @abstractmethod
    def count_documents(self, filter: dict[str, Any]) -> int:
        """
        Count documents/rows matching the filter.

        Args:
            filter: Query filter conditions

        Returns:
            Number of matching documents/rows
        """
        raise NotImplementedError()

    @abstractmethod
    def estimated_document_count(self) -> int:
        """
        Get estimated document/row count (faster, but may be approximate).

        Returns:
            Estimated number of documents/rows
        """
        raise NotImplementedError()

    @abstractmethod
    def distinct(
        self,
        field: str,
        filter: dict[str, Any] | None = None,
    ) -> list[Any]:
        """
        Get distinct values for a field.

        Args:
            field: Field name to get distinct values for
            filter: Optional query filter conditions

        Returns:
            List of distinct values
        """
        raise NotImplementedError()

    @abstractmethod
    def create_index(self, index_def: IndexDefinition) -> str:
        """
        Create an index on the collection/table.

        Args:
            index_def: Index definition

        Returns:
            Index name
        """
        raise NotImplementedError()

    @abstractmethod
    def drop_index(self, index_name: str) -> None:
        """
        Drop an index by name.

        Args:
            index_name: Name of the index to drop
        """
        raise NotImplementedError()


class DatabaseClient(ABC):
    """Abstract interface for database client operations."""

    @abstractmethod
    def get_collection(self, name: str) -> DatabaseCollection:
        """
        Get a collection/table by name.

        Args:
            name: Collection/table name

        Returns:
            DatabaseCollection instance
        """
        raise NotImplementedError()

    @abstractmethod
    def list_collections(self) -> list[str]:
        """
        List all collection/table names.

        Returns:
            List of collection/table names
        """
        raise NotImplementedError()

    @abstractmethod
    def drop_collection(self, name: str) -> None:
        """
        Drop a collection/table by name.

        Args:
            name: Collection/table name to drop
        """
        raise NotImplementedError()

    @abstractmethod
    def start_transaction(self) -> Any:
        """
        Start a database transaction.

        Returns:
            Transaction context manager or transaction object
        """
        raise NotImplementedError()

    @abstractmethod
    def commit_transaction(self, transaction: Any) -> None:
        """
        Commit a transaction.

        Args:
            transaction: Transaction object returned by start_transaction
        """
        raise NotImplementedError()

    @abstractmethod
    def rollback_transaction(self, transaction: Any) -> None:
        """
        Rollback a transaction.

        Args:
            transaction: Transaction object returned by start_transaction
        """
        raise NotImplementedError()

    @abstractmethod
    def close(self) -> None:
        """Close the database connection."""
        raise NotImplementedError()


class DatabaseOperations(ABC):
    """
    High-level database operations interface.

    This interface abstracts common patterns used in DocStore,
    such as element CRUD operations, tagging, and metadata management.
    """

    @property
    @abstractmethod
    def client(self) -> DatabaseClient:
        """Get the database client."""
        raise NotImplementedError()

    @abstractmethod
    def get_collection(self, name: str) -> DatabaseCollection:
        """
        Get a collection/table by name.

        Args:
            name: Collection/table name

        Returns:
            DatabaseCollection instance
        """
        raise NotImplementedError()

    # Core element operations (doc, page, layout, block, content)
    @abstractmethod
    def find_element(
        self,
        collection_name: str,
        filter: dict[str, Any],
        projection: dict[str, int] | list[str] | None = None,
    ) -> dict[str, Any] | None:
        """
        Find a single element by filter.

        Args:
            collection_name: Name of the collection/table
            filter: Query filter conditions
            projection: Fields to include/exclude

        Returns:
            Element document/row as dict, or None if not found
        """
        raise NotImplementedError()

    @abstractmethod
    def find_elements(
        self,
        collection_name: str,
        filter: dict[str, Any],
        options: QueryOptions | None = None,
    ) -> Iterable[dict[str, Any]]:
        """
        Find multiple elements by filter.

        Args:
            collection_name: Name of the collection/table
            filter: Query filter conditions
            options: Query options

        Returns:
            Iterable of element documents/rows
        """
        raise NotImplementedError()

    @abstractmethod
    def insert_element(
        self,
        collection_name: str,
        document: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Insert a new element.

        Args:
            collection_name: Name of the collection/table
            document: Element data

        Returns:
            Inserted element document/row with generated ID

        Raises:
            AlreadyExistsError: If element with same unique key already exists
        """
        raise NotImplementedError()

    @abstractmethod
    def upsert_element(
        self,
        collection_name: str,
        filter: dict[str, Any],
        document: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Upsert an element (insert if not exists, update if exists).

        Args:
            collection_name: Name of the collection/table
            filter: Query filter to find existing element
            document: Element data to insert/update

        Returns:
            Element document/row after upsert
        """
        raise NotImplementedError()

    @abstractmethod
    def update_element(
        self,
        collection_name: str,
        filter: dict[str, Any],
        update: dict[str, Any],
    ) -> int:
        """
        Update an element.

        Args:
            collection_name: Name of the collection/table
            filter: Query filter conditions
            update: Update operations

        Returns:
            Number of elements updated (0 or 1)
        """
        raise NotImplementedError()

    @abstractmethod
    def update_element_field(
        self,
        collection_name: str,
        element_id: str,
        field: str,
        operation: Literal["add", "remove", "set", "unset"],
        value: Any | None = None,
    ) -> dict[str, Any] | None:
        """
        Update a specific field of an element (e.g., add tag, remove tag).

        Args:
            collection_name: Name of the collection/table
            element_id: Element ID
            field: Field name to update
            operation: Operation type (add/remove for arrays, set/unset for values)
            value: Value to add/remove/set

        Returns:
            Updated element document/row, or None if not found
        """
        raise NotImplementedError()

    @abstractmethod
    def delete_element(
        self,
        collection_name: str,
        filter: dict[str, Any],
    ) -> int:
        """
        Delete an element.

        Args:
            collection_name: Name of the collection/table
            filter: Query filter conditions

        Returns:
            Number of elements deleted (0 or 1)
        """
        raise NotImplementedError()

    # Aggregation and statistics
    @abstractmethod
    def aggregate_elements(
        self,
        collection_name: str,
        pipeline: list[dict[str, Any]],
        options: QueryOptions | None = None,
    ) -> Iterable[dict[str, Any]]:
        """
        Execute aggregation pipeline on elements.

        Args:
            collection_name: Name of the collection/table
            pipeline: Aggregation pipeline stages
            options: Query options

        Returns:
            Iterable of aggregated results
        """
        raise NotImplementedError()

    @abstractmethod
    def count_elements(
        self,
        collection_name: str,
        filter: dict[str, Any] | None = None,
        estimated: bool = False,
    ) -> int:
        """
        Count elements matching filter.

        Args:
            collection_name: Name of the collection/table
            filter: Query filter conditions (None for all)
            estimated: Whether to use estimated count (faster but approximate)

        Returns:
            Number of matching elements
        """
        raise NotImplementedError()

    @abstractmethod
    def distinct_field_values(
        self,
        collection_name: str,
        field: str,
        filter: dict[str, Any] | None = None,
    ) -> list[Any]:
        """
        Get distinct values for a field.

        Args:
            collection_name: Name of the collection/table
            field: Field name
            filter: Optional query filter conditions

        Returns:
            List of distinct values
        """
        raise NotImplementedError()

    # Batch operations
    @abstractmethod
    def batch_update_elements(
        self,
        collection_name: str,
        updates: list[UpdateOperation],
    ) -> list[int]:
        """
        Batch update multiple elements.

        Args:
            collection_name: Name of the collection/table
            updates: List of update operations

        Returns:
            List of numbers of documents modified for each operation
        """
        raise NotImplementedError()

    # Index management
    @abstractmethod
    def ensure_index(
        self,
        collection_name: str,
        index_def: IndexDefinition,
    ) -> str:
        """
        Ensure an index exists (create if not exists).

        Args:
            collection_name: Name of the collection/table
            index_def: Index definition

        Returns:
            Index name
        """
        raise NotImplementedError()

    @abstractmethod
    def list_indexes(self, collection_name: str) -> list[str]:
        """
        List all indexes on a collection/table.

        Args:
            collection_name: Name of the collection/table

        Returns:
            List of index names
        """
        raise NotImplementedError()

    # Transaction support
    @abstractmethod
    def execute_in_transaction(
        self,
        operations: list[Callable[[], Any]],
    ) -> list[Any]:
        """
        Execute multiple operations in a transaction.

        Args:
            operations: List of callable operations to execute

        Returns:
            List of operation results

        Raises:
            Exception: If any operation fails, transaction is rolled back
        """
        raise NotImplementedError()
