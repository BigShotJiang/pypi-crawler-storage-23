"""Async versions of S3 utility functions using aioboto3."""

import asyncio
import io
import re
from contextlib import asynccontextmanager
from typing import AsyncIterator

import aioboto3
from aiobotocore.response import StreamingBody
from botocore.client import Config
from botocore.exceptions import ClientError

from .config import config

__re_s3_path = re.compile("^s3a?://([^/]+)(?:/(.*))?$")


def split_s3_path(path: str) -> tuple[str, str]:
    """Split bucket and key from path (sync, no I/O)."""
    m = __re_s3_path.match(path)
    if m is None:
        raise ValueError(f"Invalid S3 path: {path}")
    return m.group(1), (m.group(2) or "")


def is_s3_404_error(e: Exception) -> bool:
    """Check if exception is a 404 error (sync, no I/O)."""
    if not isinstance(e, ClientError):
        return False
    return (
        e.response.get("Error", {}).get("Code") in ["404", "NoSuchKey"]
        or e.response.get("Error", {}).get("Message") == "Not Found"
        or e.response.get("ResponseMetadata", {}).get("HTTPStatusCode") == 404
    )


def _get_s3_profile(path: str):
    """Get S3 profile config for the given path."""
    bucket, _ = split_s3_path(path)
    bucket_profile = config.s3.buckets.get(bucket, None)
    if not bucket_profile:
        raise ValueError(f"Bucket {bucket} not found in S3 config.")
    profile = config.s3.profiles.get(bucket_profile, None)
    if not profile:
        raise ValueError(f"Profile {bucket_profile} not found in S3 config.")
    return profile


@asynccontextmanager
async def get_s3_client(path: str) -> AsyncIterator:
    """Get an async S3 client for the given path (context manager version).

    Usage:
        async with get_s3_client("s3://bucket/key") as client:
            await client.head_object(...)
    """
    profile = _get_s3_profile(path)
    session = aioboto3.Session()
    async with session.client(  # type: ignore[union-attr]
        "s3",
        aws_access_key_id=profile.aws_access_key_id,
        aws_secret_access_key=profile.aws_secret_access_key,
        endpoint_url=profile.endpoint_url,
        config=Config(
            s3={"addressing_style": profile.addressing_style},
            retries={"max_attempts": 8},
        ),
    ) as client:
        yield client


async def create_s3_client(path: str):
    """Create an async S3 client for the given path (manual lifecycle).

    The returned client must be closed manually by calling `await close_s3_client(client)`.

    Usage:
        client = await create_s3_client("s3://bucket/key")
        try:
            await client.head_object(...)
            await client.get_object(...)
        finally:
            await close_s3_client(client)
    """
    profile = _get_s3_profile(path)
    session = aioboto3.Session()
    client_ctx = session.client(
        "s3",
        aws_access_key_id=profile.aws_access_key_id,
        aws_secret_access_key=profile.aws_secret_access_key,
        endpoint_url=profile.endpoint_url,
        config=Config(
            s3={"addressing_style": profile.addressing_style},
            retries={"max_attempts": 8},
        ),
    )
    client = await client_ctx.__aenter__()  # type: ignore[union-attr]
    # Store context for later cleanup
    client._aio_client_ctx = client_ctx  # type: ignore[attr-defined]
    return client


async def close_s3_client(client) -> None:
    """Close an async S3 client created by `create_s3_client`."""
    ctx = getattr(client, "_aio_client_ctx", None)
    if ctx is not None:
        await ctx.__aexit__(None, None, None)


async def head_s3_object(path: str, raise_404: bool = False, client=None) -> dict | None:
    """Head an S3 object (async)."""

    async def _head(cli):
        bucket, key = split_s3_path(path)
        try:
            resp = await cli.head_object(Bucket=bucket, Key=key)
            return resp
        except ClientError as e:
            if not raise_404 and is_s3_404_error(e):
                return None
            raise

    if client is not None:
        return await _head(client)
    async with get_s3_client(path) as cli:
        return await _head(cli)


async def get_s3_object(path: str, client=None, **kwargs) -> dict:
    """Get an S3 object (async)."""

    async def _get(cli):
        bucket, key = split_s3_path(path)
        return await cli.get_object(Bucket=bucket, Key=key, **kwargs)

    if client is not None:
        return await _get(client)
    async with get_s3_client(path) as cli:
        return await _get(cli)


async def read_s3_object_detailed(path: str, client=None) -> tuple[StreamingBody, dict]:
    """Read S3 object and return body stream with metadata (async)."""
    obj = await get_s3_object(path, client=client)
    return obj.pop("Body"), obj


async def read_s3_object_bytes_detailed(path: str, size_limit: int = 0, client=None) -> tuple[bytes, dict]:
    """Read S3 object bytes with metadata, with retry logic (async).

    This method caches all content in memory, avoid large files.
    """
    retries = 0
    last_e = None
    while True:
        if retries > 5:
            msg = f"Retry exhausted for reading [{path}]"
            raise Exception(msg) from last_e
        try:
            stream, obj = await read_s3_object_detailed(path, client=client)
            async with stream:
                amt = size_limit if size_limit > 0 else None
                buf = await stream.read(amt)
            break
        except ClientError:
            raise
        except Exception as e:
            last_e = e
            retries += 1
            await asyncio.sleep(3)
    assert isinstance(buf, bytes)
    return buf, obj


async def read_s3_object(path: str, client=None) -> StreamingBody:
    """Read S3 object and return body stream (async)."""
    return (await read_s3_object_detailed(path, client=client))[0]


async def read_s3_object_bytes(path: str, size_limit: int = 0, client=None) -> bytes:
    """Read S3 object bytes (async).

    This method caches all content in memory, avoid large files.
    """
    return (await read_s3_object_bytes_detailed(path, size_limit, client=client))[0]


async def get_s3_presigned_url(
    path: str,
    expires_in: int = 3600,
    content_type: str = "",
    as_attachment: bool = False,
    client=None,
) -> str:
    """Generate a presigned URL for an S3 object (async)."""

    async def _presign(cli):
        bucket, key = split_s3_path(path)
        params = {"Bucket": bucket, "Key": key}
        if content_type:
            params["ResponseContentType"] = content_type
        if as_attachment:
            filename = key.split("/")[-1]
            params["ResponseContentDisposition"] = f'attachment; filename="{filename}"'
        return await cli.generate_presigned_url(ClientMethod="get_object", Params=params, ExpiresIn=expires_in)

    if client is not None:
        return await _presign(client)
    async with get_s3_client(path) as cli:
        return await _presign(cli)


async def put_s3_object(path: str, body: bytes = b"", client=None, **kwargs) -> dict:
    """Put an object to S3 (async)."""

    async def _put(cli):
        bucket, key = split_s3_path(path)
        return await cli.put_object(Bucket=bucket, Key=key, Body=body, **kwargs)

    if client is not None:
        return await _put(client)
    async with get_s3_client(path) as cli:
        return await _put(cli)


async def upload_s3_object_bytes(path: str, body: bytes, client=None, **kwargs) -> None:
    """Upload bytes to S3 using upload_fileobj (async)."""

    async def _upload(cli):
        bucket, key = split_s3_path(path)
        with io.BytesIO(body) as buffer:
            await cli.upload_fileobj(Fileobj=buffer, Bucket=bucket, Key=key, ExtraArgs=kwargs)

    if client is not None:
        await _upload(client)
        return
    async with get_s3_client(path) as cli:
        await _upload(cli)


async def upload_s3_object_file(path: str, local_file_path: str, client=None) -> None:
    """Upload a local file to S3 (async)."""
    from boto3.s3.transfer import TransferConfig

    transfer_config = TransferConfig(
        multipart_threshold=134217728,  # 128MiB
        multipart_chunksize=16777216,  # 16MiB, 156.25GiB maximum
    )

    async def _upload(cli):
        bucket, key = split_s3_path(path)
        await cli.upload_file(local_file_path, bucket, key, Config=transfer_config)

    if client is not None:
        await _upload(client)
        return
    async with get_s3_client(path) as cli:
        await _upload(cli)
