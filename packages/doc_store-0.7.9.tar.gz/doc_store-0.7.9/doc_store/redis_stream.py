import hashlib
import os
import socket
import time
import weakref
from dataclasses import dataclass
from datetime import datetime
from queue import Empty, Full, LifoQueue
from typing import Any, Dict, Generator, Iterable, List, Optional, cast

import redis
import redis.exceptions
from redis.sentinel import (
    Sentinel,
    SentinelConnectionPool,
    SentinelManagedConnection,
    SentinelManagedSSLConnection,
)

from .config import config


class SentinelBlockingConnectionPool(SentinelConnectionPool, redis.BlockingConnectionPool):
    """
    SentinelConnectionPool + BlockingConnectionPool:
    - Sentinel 自动 failover
    - 连接池满时阻塞等待 timeout 秒
    """

    def __init__(self, service_name, sentinel_manager, **kwargs):
        ssl = kwargs.pop("ssl", False)
        connection_class = kwargs.pop(
            "connection_class",
            SentinelManagedSSLConnection if ssl else SentinelManagedConnection,
        )
        self.is_master = kwargs.pop("is_master", True)
        self.check_connection = kwargs.pop("check_connection", False)

        max_connections = kwargs.pop("max_connections", 50)
        timeout = kwargs.pop("timeout", 20)
        queue_class = kwargs.pop("queue_class", LifoQueue)

        redis.BlockingConnectionPool.__init__(
            self,
            max_connections=max_connections,
            timeout=timeout,
            connection_class=connection_class,
            queue_class=queue_class,
            **kwargs,
        )

        self.connection_kwargs["connection_pool"] = weakref.proxy(self)
        self.service_name = service_name
        self.sentinel_manager = sentinel_manager

    def reset(self):
        redis.BlockingConnectionPool.reset(self)
        self.master_address = None
        self.slave_rr_counter = None

    def disconnect(self, inuse_connections=True):
        """
        Disconnect connections in the pool.
        When inuse_connections=False, only idle connections are closed.
        """
        self._checkpid()
        if inuse_connections:
            return super().disconnect()

        # Drain idle connections from the queue and disconnect them
        while True:
            try:
                conn = self.pool.get_nowait()
                if conn is not None:
                    conn.disconnect()
            except Empty:
                break
        # Refill placeholders
        for _ in range(self.max_connections):
            try:
                self.pool.put_nowait(None)
            except Full:
                break


@dataclass
class StreamMessage:
    stream: str
    id: str
    fields: Dict[str, Any]


class RedisStreamConsumer:
    """
    Generic Redis Stream consumer for consumer-group based consumption.
    - Auto-generates a unique consumer name per run (overridable via env).
    - Supports XREADGROUP and XAUTOCLAIM for reclaiming stale pending messages.
    - Provides helpers to ack messages and iterate batches with flush timeout.
    """

    def __init__(
        self,
        stream: str,
        group: str,
        client: redis.Redis,
        consumer: Optional[str] = None,
        create_group: bool = True,
    ):
        self.client = client
        self.stream = stream
        self.group = group
        self._start_ms = str(datetime.now()).split(".")[0].replace(":", "").replace("-", "").replace(" ", "-")
        self.consumer = consumer or self._generate_consumer_name()
        self.claim_cursor: str = "0-0"
        self._claim_cursor_initialized: bool = False
        # default parameters for operations (can be overridden per-call)
        self.default_read_count: int = config.redis.read_count
        self.default_claim_idle_ms: int = config.redis.claim_idle_ms
        self.default_claim_batch: int = config.redis.claim_batch
        self.default_flush_ms: int = config.redis.flush_ms
        if create_group:
            self.ensure_group()

    def _generate_consumer_name(self) -> str:
        env_id = os.getenv("REDIS_CONSUMER_ID")
        if env_id:
            return str(env_id)
        return f"{socket.gethostname()}-{os.getpid()}-{self._start_ms}"

    def ensure_group(self) -> None:
        try:
            self.client.xgroup_create(self.stream, self.group, id="0", mkstream=True)
        except redis.ResponseError as e:
            if "BUSYGROUP" not in str(e):
                raise

    def _with_auto_recovery(self, func, *args, **kwargs):
        try:
            return func(*args, **kwargs)
        except redis.ResponseError as e:
            error_msg = str(e)
            # stream 或 group 不存在
            if "NOGROUP" in error_msg or "no such key" in error_msg.lower():
                self.ensure_group()
                return func(*args, **kwargs)
            raise

    def read(
        self,
        count: Optional[int] = None,
        block_ms: Optional[int] = None,
    ) -> List[StreamMessage]:
        if count is None:
            count = self.default_read_count
        kwargs: Dict[str, Any] = {}
        if block_ms is not None:
            kwargs["block"] = block_ms

        res = self._with_auto_recovery(
            self.client.xreadgroup,
            groupname=self.group,
            consumername=self.consumer,
            streams={self.stream: ">"},
            count=count,
            **kwargs,
        )

        messages: List[StreamMessage] = []
        if not res:
            return messages
        for stream, entries in res:
            for mid, fields in entries:
                messages.append(StreamMessage(stream=stream, id=mid, fields=fields))
        return messages

    def ack(self, ids: Iterable[str]) -> int:
        if not ids:
            return 0
        res = self._with_auto_recovery(self.client.xack, self.stream, self.group, *ids)
        return int(res)

    def pending_summary(self) -> Dict[str, Any]:
        try:
            pend = self.client.xpending(self.stream, self.group)
            return pend if isinstance(pend, dict) else {"pending": 0}
        except Exception:
            return {"pending": 0}

    def _compute_distributed_claim_start(self) -> str:
        """
        根据 consumer name 的 hash 值，计算在 PEL 时间戳范围内的分布式起始位置。

        目的：避免所有 consumer 都从 0-0 开始扫描导致的惊群效应（Thundering Herd）。
        当 N 个 consumer 并发 claim 时，每个 consumer 会从 PEL 中不同的位置开始扫描，
        将扫描工作均匀分摊，全局 claim 吞吐量提升约 N 倍。
        """
        try:
            pending_info = self.client.xpending(self.stream, self.group)
            if not pending_info or not isinstance(pending_info, dict):
                return "0-0"
            min_id = pending_info.get("min")
            max_id = pending_info.get("max")
            if not min_id or not max_id:
                return "0-0"
            min_ts = int(min_id.split("-")[0])
            max_ts = int(max_id.split("-")[0])
            ts_range = max_ts - min_ts
            if ts_range <= 0:
                return "0-0"
            # 使用 consumer name 的 MD5 hash 确定在 PEL 范围内的起始偏移
            h = int(hashlib.md5(self.consumer.encode()).hexdigest(), 16)
            offset = h % ts_range
            return f"{min_ts + offset}-0"
        except Exception:
            return "0-0"

    def claim_stale(
        self,
        min_idle_ms: Optional[int] = None,
        count: Optional[int] = None,
        start_id: Optional[str] = None,
    ) -> List[StreamMessage]:
        if min_idle_ms is None:
            min_idle_ms = self.default_claim_idle_ms
        if count is None:
            count = self.default_claim_batch

        # 确定扫描起始位置：
        # 1. 显式传入 start_id → 使用传入值
        # 2. 首次调用（cursor 未初始化）→ 使用分布式 hash 起始位置，避免惊群
        # 3. 后续调用 → 使用上次 XAUTOCLAIM 返回的游标继续扫描
        if start_id is not None:
            effective_start_id = start_id
        elif not self._claim_cursor_initialized:
            effective_start_id = self._compute_distributed_claim_start()
            self._claim_cursor_initialized = True
        else:
            effective_start_id = self.claim_cursor

        res = self._with_auto_recovery(
            self.client.xautoclaim,
            name=self.stream,
            groupname=self.group,
            consumername=self.consumer,
            min_idle_time=min_idle_ms,
            start_id=effective_start_id,
            count=count,
        )

        messages: List[StreamMessage] = []
        next_id = effective_start_id
        if isinstance(res, (list, tuple)):
            if len(res) == 3:
                next_id, entries, _deleted = res
            elif len(res) == 2:
                next_id, entries = res
            else:
                entries = []
        else:
            entries = []
        for mid, fields in entries:
            messages.append(StreamMessage(stream=self.stream, id=mid, fields=fields))
        if isinstance(next_id, str) and next_id:
            if next_id == "0-0":
                # 已扫到 PEL 末尾并 wrap-around，重新计算分布式起始位置
                # 避免所有 consumer 再次汇聚到 0-0 产生新一轮惊群
                self._claim_cursor_initialized = False
            self.claim_cursor = next_id
        return messages

    def read_or_claim(
        self,
        count: Optional[int] = None,
        prefer_claim: bool = True,
        min_idle_ms: Optional[int] = None,
        block_ms: Optional[int] = None,
    ) -> List[StreamMessage]:
        """
        Fetch up to `count` messages by combining claiming pending and reading new ones.
        - If prefer_claim is True: claim first, then read the remaining.
        - If prefer_claim is False: read first, then claim the remaining.
        Uses default_read_count when `count` is None.
        """
        total = count if count is not None else self.default_read_count
        messages: List[StreamMessage] = []
        effective_idle = min_idle_ms if min_idle_ms is not None else self.default_claim_idle_ms

        if prefer_claim:
            reclaimed = self.claim_stale(min_idle_ms=effective_idle, count=total)
            if reclaimed:
                messages.extend(reclaimed)
            remaining = max(0, total - len(messages))
            if remaining > 0:
                new_msgs = self.read(count=remaining, block_ms=block_ms)
                if new_msgs:
                    messages.extend(new_msgs)
            return messages
        else:
            new_msgs = self.read(count=total, block_ms=block_ms)
            if new_msgs:
                messages.extend(new_msgs)
            remaining = max(0, total - len(messages))
            if remaining > 0:
                reclaimed = self.claim_stale(min_idle_ms=effective_idle, count=remaining)
                if reclaimed:
                    messages.extend(reclaimed)
            return messages

    def iter_batches(
        self,
        batch_size: int,
        block_ms: Optional[int] = None,
        flush_ms: Optional[int] = None,
        read_count: Optional[int] = None,
        min_idle_reclaim_ms: Optional[int] = None,
        reclaim_count: Optional[int] = None,
    ) -> Generator[List[StreamMessage], None, None]:
        """
        Yield lists of StreamMessage with size up to batch_size. Flush if idle for flush_ms.
        Optionally try to reclaim stale messages before reading new ones.
        """
        buffer: List[StreamMessage] = []
        last_flush = time.time()
        # time-based flush
        flush_threshold = flush_ms if flush_ms is not None else self.default_flush_ms
        while True:
            if min_idle_reclaim_ms is not None:
                reclaimed = self.claim_stale(
                    min_idle_ms=min_idle_reclaim_ms,
                    count=(reclaim_count if reclaim_count is not None else self.default_claim_batch),
                )
                if reclaimed:
                    buffer.extend(reclaimed)
                    if len(buffer) >= batch_size:
                        yield buffer[:batch_size]
                        buffer = buffer[batch_size:]
                        last_flush = time.time()
                        continue

            msgs = self.read(
                count=(read_count if read_count is not None else batch_size),
                block_ms=block_ms,
            )
            if msgs:
                buffer.extend(msgs)
                if len(buffer) >= batch_size:
                    yield buffer[:batch_size]
                    buffer = buffer[batch_size:]
                    last_flush = time.time()
                    continue

            if (time.time() - last_flush) * 1000.0 >= flush_threshold:
                if buffer:
                    yield buffer
                    buffer = []
                    last_flush = time.time()
                else:
                    break


class RedisStreamReader:
    """
    只读方式读取Stream中未被消费或未被ack的消息，不改变任何状态。
    适用于批量导出、数据分析等场景。

    性能优化：
    - 使用大批次减少网络往返（默认10000条/批次）
    - 使用Pipeline批量获取pending消息内容
    - XRANGE本身是O(log(N)+M)复杂度，M是返回的消息数
    """

    # 默认批次大小，适合大规模读取
    DEFAULT_BATCH_SIZE = 10000
    # Pipeline中每批获取的消息ID数量
    PIPELINE_CHUNK_SIZE = 500

    def __init__(self, client: redis.Redis):
        self.client = client

    def _fetch_messages_by_ids_pipeline(
        self,
        stream: str,
        ids: List[str],
    ) -> List[StreamMessage]:
        """
        使用Pipeline批量获取指定ID的消息内容。
        每个ID用单独的XRANGE id id获取，通过pipeline减少网络往返。
        """
        if not ids:
            return []

        messages: List[StreamMessage] = []
        # 分块执行pipeline，避免单次pipeline过大
        for i in range(0, len(ids), self.PIPELINE_CHUNK_SIZE):
            chunk_ids = ids[i : i + self.PIPELINE_CHUNK_SIZE]
            pipe = self.client.pipeline(transaction=False)
            for mid in chunk_ids:
                pipe.xrange(stream, min=mid, max=mid, count=1)
            results = pipe.execute()
            for mid, result in zip(chunk_ids, results):
                if result and len(result) > 0:
                    _, fields = result[0]
                    messages.append(StreamMessage(stream=stream, id=mid, fields=fields))
        return messages

    def get_group_last_delivered_id(self, stream: str, group: str) -> Optional[str]:
        """获取group的last-delivered-id，即最后一次XREADGROUP读取到的位置"""
        try:
            groups = self.client.xinfo_groups(stream)
            for g in groups:
                if g.get("name") == group:
                    return g.get("last-delivered-id")
            return None
        except redis.exceptions.ResponseError:
            return None

    def iter_pending_ids(
        self,
        stream: str,
        group: str,
        batch_size: Optional[int] = None,
    ) -> Generator[List[Dict[str, Any]], None, None]:
        """
        迭代获取所有pending消息的元信息（不包含消息内容）。
        返回的每条记录包含：message_id, consumer, idle_time, delivery_count
        """
        if batch_size is None:
            batch_size = self.DEFAULT_BATCH_SIZE
        start_id = "-"
        while True:
            # XPENDING stream group start end count
            pending = self.client.xpending_range(stream, group, min=start_id, max="+", count=batch_size)
            if not pending:
                break
            yield pending
            # 移动游标到最后一条消息ID之后
            last_id = pending[-1]["message_id"]
            # 增加ID以跳过当前最后一条
            parts = last_id.split("-")
            if len(parts) == 2:
                start_id = f"{parts[0]}-{int(parts[1]) + 1}"
            else:
                break
            if len(pending) < batch_size:
                break

    def iter_unread_messages(
        self,
        stream: str,
        group: str,
        batch_size: Optional[int] = None,
    ) -> Generator[List[StreamMessage], None, None]:
        """
        迭代读取group尚未读取的新消息（last-delivered-id之后的消息）。
        使用XRANGE，不改变group状态。

        对于大规模读取，建议batch_size设为10000-50000。
        """
        if batch_size is None:
            batch_size = self.DEFAULT_BATCH_SIZE
        last_delivered = self.get_group_last_delivered_id(stream, group)
        if last_delivered is None:
            # group不存在，从头读取所有消息
            start_id = "-"
        elif last_delivered == "0-0":
            # group刚创建，从头读取
            start_id = "-"
        else:
            # 从last-delivered-id的下一条开始
            parts = last_delivered.split("-")
            if len(parts) == 2:
                start_id = f"({last_delivered}"  # exclusive range
            else:
                start_id = "-"

        while True:
            # XRANGE stream start end COUNT count
            entries = self.client.xrange(stream, min=start_id, max="+", count=batch_size)
            if not entries:
                break
            messages = [StreamMessage(stream=stream, id=mid, fields=fields) for mid, fields in entries]
            yield messages
            # 移动游标
            last_id = entries[-1][0]
            start_id = f"({last_id}"  # exclusive
            if len(entries) < batch_size:
                break

    def iter_pending_messages(
        self,
        stream: str,
        group: str,
        batch_size: Optional[int] = None,
        use_pipeline: bool = True,
    ) -> Generator[List[StreamMessage], None, None]:
        """
        迭代读取所有pending消息的完整内容。
        先用XPENDING获取ID，再获取内容，不改变状态。

        Args:
            stream: Stream名称
            group: Consumer Group名称
            batch_size: 每批次读取的消息数量
            use_pipeline: 是否使用pipeline批量获取（推荐True，对稀疏pending更高效）
        """
        if batch_size is None:
            batch_size = self.DEFAULT_BATCH_SIZE

        for pending_batch in self.iter_pending_ids(stream, group, batch_size):
            if not pending_batch:
                continue
            # 获取这批pending消息的ID
            ids = [p["message_id"] for p in pending_batch]

            if use_pipeline:
                # Pipeline方式：每个ID单独获取，适合稀疏分布的pending消息
                messages = self._fetch_messages_by_ids_pipeline(stream, ids)
            else:
                # Range方式：获取ID范围内所有消息然后过滤，适合密集分布的pending消息
                min_id = ids[0]
                max_id = ids[-1]
                entries = self.client.xrange(stream, min=min_id, max=max_id)
                id_set = set(ids)
                messages = [StreamMessage(stream=stream, id=mid, fields=fields) for mid, fields in entries if mid in id_set]
            yield messages

    def iter_unconsumed_messages(
        self,
        stream: str,
        group: str,
        batch_size: Optional[int] = None,
        include_pending: bool = True,
        include_unread: bool = True,
    ) -> Generator[List[StreamMessage], None, None]:
        """
        迭代读取所有未完成消费的消息（pending + unread），不改变状态。

        Args:
            stream: Stream名称
            group: Consumer Group名称
            batch_size: 每批次读取的消息数量（默认10000）
            include_pending: 是否包含pending消息（已读未ack）
            include_unread: 是否包含unread消息（未读取的新消息）

        Yields:
            List[StreamMessage]: 消息批次
        """
        if batch_size is None:
            batch_size = self.DEFAULT_BATCH_SIZE
        if include_pending:
            yield from self.iter_pending_messages(stream, group, batch_size)
        if include_unread:
            yield from self.iter_unread_messages(stream, group, batch_size)

    def iter_all_messages(
        self,
        stream: str,
        batch_size: Optional[int] = None,
        start_id: str = "-",
        end_id: str = "+",
    ) -> Generator[List[StreamMessage], None, None]:
        """
        迭代读取Stream中的所有消息（不考虑consumer group）。
        这是最快的批量读取方式，直接使用XRANGE遍历整个stream。

        Args:
            stream: Stream名称
            batch_size: 每批次读取的消息数量（默认10000）
            start_id: 起始ID（默认"-"表示从头开始）
            end_id: 结束ID（默认"+"表示到末尾）

        Yields:
            List[StreamMessage]: 消息批次
        """
        if batch_size is None:
            batch_size = self.DEFAULT_BATCH_SIZE

        cursor = start_id
        while True:
            entries = self.client.xrange(stream, min=cursor, max=end_id, count=batch_size)
            if not entries:
                break
            messages = [StreamMessage(stream=stream, id=mid, fields=fields) for mid, fields in entries]
            yield messages
            # 移动游标（exclusive）
            last_id = entries[-1][0]
            cursor = f"({last_id}"
            if len(entries) < batch_size:
                break

    def count_unconsumed(self, stream: str, group: str) -> Dict[str, int]:
        """
        统计未消费消息数量。
        返回 {"pending": N, "unread": M, "total": N+M}
        """
        pending_count = 0
        unread_count = 0

        try:
            # 获取group信息，包含pending和lag
            groups = self.client.xinfo_groups(stream)
            for g in groups:
                if g.get("name") == group:
                    pending_count = int(g.get("pending", 0))
                    # Redis 7+ 支持 lag 字段
                    if "lag" in g and g["lag"] is not None:
                        unread_count = int(g["lag"])
                    else:
                        # fallback: 计算 stream长度 - (last-delivered-id之前的消息数)
                        stream_len = self.client.xlen(stream)
                        last_delivered = g.get("last-delivered-id")
                        if last_delivered and last_delivered != "0-0":
                            # 使用XLEN减去已分发数量（近似）
                            # 注意：这里简化处理，对于精确计数可能需要遍历
                            delivered_entries = self.client.xrange(stream, min="-", max=last_delivered, count=1)
                            if delivered_entries:
                                # 粗略估算：stream_len - 已读取的消息数
                                unread_count = max(0, stream_len - pending_count)
                            else:
                                unread_count = stream_len
                        else:
                            unread_count = stream_len
                    break
        except Exception:
            pass

        return {
            "pending": pending_count,
            "unread": unread_count,
            "total": pending_count + unread_count,
        }

    # ==================== 分区读取支持（用于 Spark 等分布式框架） ====================

    def get_stream_id_range(self, stream: str) -> Optional[Dict[str, str]]:
        """
        获取 Stream 的消息 ID 范围。
        返回 {"first_id": "...", "last_id": "..."} 或 None（stream 为空）
        """
        try:
            info = self.client.xinfo_stream(stream)
            first_entry = info.get("first-entry")
            last_entry = info.get("last-entry")
            if first_entry and last_entry:
                return {
                    "first_id": first_entry[0],
                    "last_id": last_entry[0],
                }
            return None
        except Exception:
            return None

    def get_unread_id_range(self, stream: str, group: str) -> Optional[Dict[str, str]]:
        """
        获取 group 未读消息的 ID 范围。
        返回 {"first_id": "...", "last_id": "..."} 或 None
        """
        last_delivered = self.get_group_last_delivered_id(stream, group)
        if last_delivered is None:
            return self.get_stream_id_range(stream)

        try:
            info = self.client.xinfo_stream(stream)
            last_entry = info.get("last-entry")
            if not last_entry:
                return None

            last_id = last_entry[0]
            # last_delivered 之后的第一条消息
            first_unread = self.client.xrange(stream, min=f"({last_delivered}", max="+", count=1)
            if not first_unread:
                return None

            return {
                "first_id": first_unread[0][0],
                "last_id": last_id,
            }
        except Exception:
            return None

    def get_pending_id_range(self, stream: str, group: str) -> Optional[Dict[str, str]]:
        """
        获取 pending 消息的 ID 范围。
        返回 {"first_id": "...", "last_id": "..."} 或 None
        """
        try:
            pending_info = self.client.xpending(stream, group)
            if isinstance(pending_info, dict):
                min_id = pending_info.get("min")
                max_id = pending_info.get("max")
                if min_id and max_id:
                    return {"first_id": min_id, "last_id": max_id}
            return None
        except Exception:
            return None

    @staticmethod
    def _parse_stream_id(stream_id: str) -> tuple:
        """解析 stream ID 为 (timestamp, sequence) 元组"""
        parts = stream_id.split("-")
        if len(parts) == 2:
            return (int(parts[0]), int(parts[1]))
        return (0, 0)

    @staticmethod
    def _format_stream_id(timestamp: int, sequence: int) -> str:
        """格式化 stream ID"""
        return f"{timestamp}-{sequence}"

    def compute_partitions(
        self,
        first_id: str,
        last_id: str,
        num_partitions: int,
    ) -> List[Dict[str, str]]:
        """
        根据 ID 范围计算分区边界。按时间戳均匀划分。

        Args:
            first_id: 起始消息 ID
            last_id: 结束消息 ID
            num_partitions: 分区数量

        Returns:
            分区列表，每个分区包含 {"start_id": "...", "end_id": "..."}
        """
        first_ts, first_seq = self._parse_stream_id(first_id)
        last_ts, last_seq = self._parse_stream_id(last_id)

        if num_partitions <= 1 or first_ts >= last_ts:
            return [{"start_id": first_id, "end_id": last_id}]

        # 按时间戳均匀划分
        ts_range = last_ts - first_ts
        step = ts_range // num_partitions

        partitions = []
        for i in range(num_partitions):
            if i == 0:
                start_id = first_id
            else:
                start_ts = first_ts + step * i
                start_id = f"{start_ts}-0"

            if i == num_partitions - 1:
                end_id = last_id
            else:
                end_ts = first_ts + step * (i + 1) - 1
                end_id = f"{end_ts}-{2**62}"  # 使用大 sequence 确保包含该时间戳的所有消息

            partitions.append({"start_id": start_id, "end_id": end_id})

        return partitions

    def get_unread_partitions(
        self,
        stream: str,
        group: str,
        num_partitions: int,
    ) -> List[Dict[str, str]]:
        """
        获取 unread 消息的分区列表，用于 Spark 并行读取。

        Args:
            stream: Stream 名称
            group: Consumer Group 名称
            num_partitions: 分区数量

        Returns:
            分区列表，每个分区包含 {"start_id": "...", "end_id": "..."}
        """
        id_range = self.get_unread_id_range(stream, group)
        if not id_range:
            return []
        return self.compute_partitions(id_range["first_id"], id_range["last_id"], num_partitions)

    def get_pending_partitions(
        self,
        stream: str,
        group: str,
        num_partitions: int,
    ) -> List[Dict[str, str]]:
        """
        获取 pending 消息的分区列表，用于 Spark 并行读取。

        Args:
            stream: Stream 名称
            group: Consumer Group 名称
            num_partitions: 分区数量

        Returns:
            分区列表，每个分区包含 {"start_id": "...", "end_id": "..."}
        """
        id_range = self.get_pending_id_range(stream, group)
        if not id_range:
            return []
        return self.compute_partitions(id_range["first_id"], id_range["last_id"], num_partitions)

    def iter_unread_partition(
        self,
        stream: str,
        group: str,
        start_id: str,
        end_id: str,
        batch_size: Optional[int] = None,
    ) -> Generator[List[StreamMessage], None, None]:
        """
        读取指定 ID 范围内的 unread 消息（用于单个 Spark 分区）。

        Args:
            stream: Stream 名称
            group: Consumer Group 名称
            start_id: 分区起始 ID
            end_id: 分区结束 ID
            batch_size: 每批次大小

        Yields:
            List[StreamMessage]: 消息批次
        """
        if batch_size is None:
            batch_size = self.DEFAULT_BATCH_SIZE

        # 确保只读取 unread 消息（在 last-delivered-id 之后）
        last_delivered = self.get_group_last_delivered_id(stream, group)
        if last_delivered and last_delivered != "0-0":
            # 如果 start_id 在 last_delivered 之前，调整为 last_delivered 之后
            start_ts, _ = self._parse_stream_id(start_id)
            delivered_ts, _ = self._parse_stream_id(last_delivered)
            if start_ts <= delivered_ts:
                start_id = f"({last_delivered}"

        cursor = start_id
        while True:
            entries = self.client.xrange(stream, min=cursor, max=end_id, count=batch_size)
            if not entries:
                break
            messages = [StreamMessage(stream=stream, id=mid, fields=fields) for mid, fields in entries]
            yield messages
            last_id = entries[-1][0]
            cursor = f"({last_id}"
            if len(entries) < batch_size:
                break

    def iter_pending_partition(
        self,
        stream: str,
        group: str,
        start_id: str,
        end_id: str,
        batch_size: Optional[int] = None,
    ) -> Generator[List[StreamMessage], None, None]:
        """
        读取指定 ID 范围内的 pending 消息（用于单个 Spark 分区）。

        Args:
            stream: Stream 名称
            group: Consumer Group 名称
            start_id: 分区起始 ID
            end_id: 分区结束 ID
            batch_size: 每批次大小

        Yields:
            List[StreamMessage]: 消息批次
        """
        if batch_size is None:
            batch_size = self.DEFAULT_BATCH_SIZE

        cursor = start_id
        while True:
            # 获取该范围内的 pending IDs
            pending = self.client.xpending_range(stream, group, min=cursor, max=end_id, count=batch_size)
            if not pending:
                break

            ids = [p["message_id"] for p in pending]
            # 使用 pipeline 获取消息内容
            messages = self._fetch_messages_by_ids_pipeline(stream, ids)
            if messages:
                yield messages

            # 移动游标
            last_id = pending[-1]["message_id"]
            parts = last_id.split("-")
            if len(parts) == 2:
                cursor = f"{parts[0]}-{int(parts[1]) + 1}"
            else:
                break
            if len(pending) < batch_size:
                break


class RedisStreamManager:
    def __init__(self, client: redis.Redis):
        self.client = client

    def stream_info(self, stream: str, full: bool = False) -> dict[str, Any] | None:
        try:
            resp = self.client.xinfo_stream(stream, full=full)
            if not isinstance(resp, dict):
                print(f"unexpected xinfo_stream response for stream {stream}: {resp}")
                return None
            return resp
        except redis.exceptions.ResponseError as e:
            if "no such key" == str(e):
                print(f"stream {stream} not found")
                return None
            raise e

    def groups_info(self, stream: str) -> List[Dict[str, Any]]:
        try:
            resp = self.client.xinfo_groups(stream)
            if not isinstance(resp, list):
                print(f"unexpected xinfo_groups response for stream {stream}: {resp}")
                return []
            return resp
        except redis.exceptions.ResponseError as e:
            if "no such key" == str(e):
                print(f"stream {stream} not found")
                return []
            raise e

    def consumers_info(self, stream: str, group: str) -> List[Dict[str, Any]]:
        return self.client.xinfo_consumers(stream, group)

    def last_generated_id(self, stream: str) -> Optional[str]:
        try:
            info = self.client.xinfo_stream(stream)
            return info.get("last-generated-id")
        except Exception:
            return None

    def trim_maxlen(self, stream: str, maxlen: int, approximate: bool = True, limit: Optional[int] = None) -> int:
        trimmed = self.client.xtrim(stream, maxlen=maxlen, approximate=approximate, limit=limit)
        return int(trimmed) if isinstance(trimmed, int) else int(trimmed or 0)

    def trim_minid(self, stream: str, minid: str, approximate: bool = True, limit: Optional[int] = None) -> int:
        trimmed = self.client.xtrim(stream, minid=minid, approximate=approximate, limit=limit)
        return int(trimmed) if isinstance(trimmed, int) else int(trimmed or 0)

    def get_message(self, stream: str, id: str):
        res = self.client.xrange(stream, min=id, max=id, count=1)
        # 格式：[('1640995200000-0', {'field1': 'val1', 'myfield': 'val2'})]
        if not res:
            return None
        return res[0][1]


@dataclass
class StreamCountInfo:
    """Per-stream count information for task tracking."""

    stream: str
    total: int  # max(add_count, stream_length)
    running: int  # PEL size (pending in consumer group)
    completed: int  # ack count


class RedisStream:
    # Redis hash key for tracking all-time add counts per stream
    _ADD_COUNTS_KEY = "_add_counts"
    # Redis hash key prefix for tracking all-time ack counts per stream
    _ACK_COUNTS_PREFIX = "_ack_counts"

    def __init__(self, url: Optional[str] = None) -> None:
        if config.redis.sentinels:
            sentinel_nodes = []
            for hp in config.redis.sentinels:
                h, p = hp.rsplit(":", 1) if ":" in hp else (hp, "26379")
                sentinel_nodes.append((h, int(p)))
            self.client = Sentinel(sentinel_nodes, socket_timeout=0.5).master_for(
                config.redis.service_name,
                password=config.redis.password,
                db=config.redis.db,
                socket_timeout=config.redis.blocking_timeout,
                decode_responses=True,
                max_connections=config.redis.max_connections,
            )
        else:
            url = url or config.redis.url
            pool = redis.BlockingConnectionPool.from_url(
                url,
                max_connections=config.redis.max_connections,
                timeout=config.redis.blocking_timeout,
                decode_responses=True,
            )
            self.client = redis.Redis(connection_pool=pool, decode_responses=True)

        self.manager = RedisStreamManager(self.client)
        self.consumer_group = config.redis.consumer_group
        self.consumer_pool: Dict[str, RedisStreamConsumer] = {}

        # Register Lua scripts for atomic add/ack with counting
        self._add_with_count_script = self.client.register_script(
            """
            local id
            local maxlen = tonumber(ARGV[1])
            if maxlen and maxlen > 0 then
                id = redis.call('XADD', KEYS[1], 'MAXLEN', '~', ARGV[1], '*', unpack(ARGV, 2))
            else
                id = redis.call('XADD', KEYS[1], '*', unpack(ARGV, 2))
            end
            redis.call('HINCRBY', KEYS[2], KEYS[1], 1)
            return id
            """
        )
        self._ack_with_count_script = self.client.register_script(
            """
            local ack = redis.call('XACK', KEYS[1], ARGV[1], ARGV[2])
            if ack > 0 then
                redis.call('HINCRBY', KEYS[2], KEYS[1], ack)
            end
            return ack
            """
        )

    def _ack_counts_key(self, group: Optional[str] = None) -> str:
        """Redis hash key for tracking all-time ack counts per stream."""
        return f"{self._ACK_COUNTS_PREFIX}:{group or self.consumer_group}"

    def add_with_count(self, stream: str, fields: Dict[str, Any]) -> str:
        """Atomically XADD a message and increment the add counter for the stream.

        Args:
            stream: Redis stream name.
            fields: Message fields to add.

        Returns:
            The message ID assigned by Redis.
        """
        maxlen = int(config.redis.stream_maxlen or 0)
        flat_args: List[str] = []
        for k, v in fields.items():
            flat_args.append(str(k))
            flat_args.append(str(v))
        message_id: str = self._add_with_count_script(  # type: ignore[assignment]
            keys=[stream, self._ADD_COUNTS_KEY],
            args=[maxlen] + flat_args,
        )
        return message_id

    def ack_with_count(self, stream: str, message_id: str, group: Optional[str] = None) -> int:
        """Atomically XACK a message and increment the ack counter for the stream.

        Args:
            stream: Redis stream name.
            message_id: The message ID to acknowledge.
            group: Consumer group name (defaults to self.consumer_group).

        Returns:
            Number of messages actually acknowledged (0 or 1).
        """
        effective_group = group or self.consumer_group
        ack_counts_key = self._ack_counts_key(effective_group)
        ack_count = self._ack_with_count_script(
            keys=[stream, ack_counts_key],
            args=[effective_group, message_id],
        )
        return int(ack_count)  # type: ignore[arg-type]

    def get_stream_counts(
        self,
        group: Optional[str] = None,
        key_pattern: Optional[str] = None,
    ) -> List[StreamCountInfo]:
        """Get per-stream count information for task tracking.

        All O(1) Redis operations per stream:
        - _add_counts hash: all-time messages added (self-maintained), fallback to XLEN
        - PEL size (group pending): delivered but not ACK'd = running
        - _ack_counts hash: all-time messages ACK'd (self-maintained) = completed

        Args:
            group: Consumer group name (defaults to self.consumer_group).
            key_pattern: Glob pattern to filter stream keys (e.g. "mycommand*").
                         If None, matches all non-internal keys.

        Returns:
            List of StreamCountInfo, one per matching stream.
        """
        effective_group = group or self.consumer_group

        # 1. Discover stream keys
        if key_pattern:
            keys: List[str] = self.client.keys(key_pattern)  # type: ignore[assignment]
        else:
            keys = self.client.keys("*")  # type: ignore[assignment]
            # Exclude internal keys (starting with _)
            keys = [k for k in keys if not k.startswith("_")]

        if not keys:
            return []

        # 2. Bulk-fetch counters (O(N) where N = number of fields in hash)
        ack_counts_key = self._ack_counts_key(effective_group)
        ack_counts: Dict[str, str] = self.client.hgetall(ack_counts_key)  # type: ignore[assignment]
        add_counts: Dict[str, str] = self.client.hgetall(self._ADD_COUNTS_KEY)  # type: ignore[assignment]

        # 3. Build per-stream results
        results: List[StreamCountInfo] = []
        for stream in keys:
            stream_length = cast(int, self.client.xlen(stream))
            groups_info = self.manager.groups_info(stream)

            consumer_group_info: Optional[Dict[str, Any]] = None
            for gi in groups_info:
                if gi["name"] == effective_group:
                    consumer_group_info = gi
                    break

            total = max(int(add_counts.get(stream, 0)), stream_length)

            if consumer_group_info is not None:
                running = int(consumer_group_info["pending"])
                completed = int(ack_counts.get(stream, 0))
            else:
                running = 0
                completed = 0

            results.append(
                StreamCountInfo(
                    stream=stream,
                    total=total,
                    running=running,
                    completed=completed,
                )
            )

        return results

    def get_message(self, stream: str, message_id: str) -> dict | None:
        res = self.client.xrange(stream, min=message_id, max=message_id, count=1)
        # 格式：[('1640995200000-0', {'field1': 'val1', 'myfield': 'val2'})]
        if not isinstance(res, list) or len(res) == 0:
            return None
        if not isinstance(res[0], tuple) or len(res[0]) < 2:
            return None
        if not isinstance(res[0][1], dict):
            return None
        return res[0][1]

    def get_consumer(self, stream: str) -> RedisStreamConsumer:
        key = f"{stream}:{self.consumer_group}"
        if key not in self.consumer_pool:
            self.consumer_pool[key] = RedisStreamConsumer(
                stream,
                self.consumer_group,
                self.client,
                create_group=True,
            )
        return self.consumer_pool[key]
