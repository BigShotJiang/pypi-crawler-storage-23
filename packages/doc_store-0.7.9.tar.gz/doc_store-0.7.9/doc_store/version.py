version = "0.7.9"

# Notes:
#   - 0.7.0 Merge redis code into DocStore, add `batch_id`.
#   - 0.7.0 Has bug, `task.store` is not accessable.
#   - 0.7.1 Recover Task as sub-class of Element.
#   - 0.7.2:
#     - split `interface.py` into many small files.
#     - add `PageExistsError`.
#     - http error encode/decode is more correctly.
#     - add `get_page_by_image_hash()`.
#     - change class `ElementTagging` to `TaggingInput`.
#     - `insert_page()` add parameter `skip_hash_check`.
#     - `update_task()` add parameter `check_mismatch`.
#     - block DocEvent can have `layout_provider` field.
#     - add `display_order` to Trigger.
#     - Trigger support update and delete.
#     - add `doc_trigger.py`
#   - 0.7.3:
#     - store/read S3 bucket configs on server.
#     - surrogates in PDF metadata are removed.
#   - 0.7.4:
#     - support reading user_home in spark executor.
#   - 0.7.5:
#     - remove EvalStatus (which is not supported by py3.10)
#   - 0.7.6:
#     - remove fastapi deps in DocClient
#   - 0.7.7:
#     - add `aioboto3` and `aiofiles` as project dependencies.
#     - add AioDocClient and Aio S3 Client.
#     - redis support connection pool and max_connections/blocking_timeout.
#     - DocClient support computing PDF/Image info on client side.
#     - DocEvent support new fields: doc_id/page_id/layout_id/block_id and page_tags.
#     - DocTrigger support page_tags.
#     - DocStore support readonly mode.
#     - Truncate PDF metadata field string to 64k when it is too long.
#   - 0.7.8:
#     - Redis support sentinels
#   - 0.7.9:
#     - Remove old redis stream and -1 priority.
#     - Block.image ensure cropped image width/height greater than 0.
#     - Redis stream store add/ack counts in another HASH key.


# Define the minimum required version for compatibility checks
# Please update this value when making breaking changes
min_required_version = "0.6.0"
