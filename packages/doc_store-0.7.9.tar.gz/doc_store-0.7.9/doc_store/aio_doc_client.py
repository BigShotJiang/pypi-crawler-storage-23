import json
import os
import warnings
from json import JSONDecodeError
from typing import AsyncIterable, Literal, TypeVar
from urllib.parse import quote

import httpx
import numpy as np

from .config import config
from .interface import (
    AioDocStoreInterface,
    AttrInput,
    AttrValueType,
    Block,
    BlockInput,
    Content,
    ContentBlockInput,
    ContentInput,
    Doc,
    DocInput,
    Element,
    ElemType,
    EmbeddableElemType,
    Embedding,
    EmbeddingInput,
    EmbeddingModel,
    EmbeddingModelUpdate,
    EmbeddingQuery,
    EvalContent,
    EvalLayout,
    EvalLayoutBlock,
    InputModel,
    KnownName,
    KnownNameInput,
    KnownNameUpdate,
    KnownOptionInput,
    Layout,
    LayoutInput,
    MetricInput,
    Page,
    PageInput,
    S3Bucket,
    StandaloneBlockInput,
    TaggingInput,
    Task,
    TaskCount,
    TaskInput,
    Trigger,
    TriggerInput,
    User,
    UserInput,
    UserUpdate,
    Value,
    ValueInput,
)
from .interface.error import decode_error
from .utils import encode_ndarray, get_username
from .version import version as client_version

T = TypeVar("T", bound=Element)


def _encode_uri_component(s: str) -> str:
    """Encode a string for safe inclusion in a URI component."""
    return quote(s, safe="-_.!~*'()", encoding="utf-8")


def _version_cmp(v1: str, v2: str) -> int:
    """Compare two version strings. return -1 if v1<v2, 0 if v1==v2, 1 if v1>v2."""
    v1_parts, v2_parts = v1.split("."), v2.split(".")
    for p1, p2 in zip(v1_parts, v2_parts):
        try:
            if int(p1) < int(p2):
                return -1
            elif int(p1) > int(p2):
                return 1
            continue
        except Exception:
            if p1 < p2:
                return -1
            elif p1 > p2:
                return 1
    if len(v1_parts) < len(v2_parts):
        return -1
    elif len(v1_parts) > len(v2_parts):
        return 1
    return 0


class AioDocClient(AioDocStoreInterface):
    """Async HTTP client for DocStore API."""

    def __init__(
        self,
        server_url: str | None = None,
        prefix: str = "/api/v1",
        timeout: int = 300,
        connect_timeout: int = 30,
        decode_value=True,
        skip_version_check=False,
    ):
        """
        Initialize AioDocClient.

        Args:
            server_url: Base URL of the DocStore API server
            timeout: Read timeout in seconds (for stream requests, this is per-chunk)
            connect_timeout: Connection timeout in seconds
            decode_value: Whether to decode Value objects automatically
            skip_version_check: Skip version compatibility check on init
        """
        super().__init__()

        proxy_envs = [env for env in os.environ.keys() if env.lower() in ("http_proxy", "https_proxy")]
        if len(proxy_envs) > 0:
            warnings.warn(
                f"HTTP proxy environment variables {proxy_envs} are set, which may affect AioDocClient behavior."
                " Please unset them if unintended.",
                UserWarning,
            )

        if not server_url:
            server_url = config.server.url
        if not server_url:
            raise ValueError("server_url must be provided either in argument or config.")
        self.server_url = server_url.rstrip("/")
        self.prefix = prefix.rstrip("/")
        self.decode_value = decode_value
        self.version_checked = skip_version_check

        self.client = httpx.AsyncClient(
            headers={
                "X-Username": get_username(),
            },
            timeout=httpx.Timeout(
                connect=connect_timeout,
                read=timeout,
                write=timeout,
                pool=connect_timeout,
            ),
        )

    async def check_version(self) -> None:
        """Check version compatibility with server."""
        server_info = await self._get("/health", _checking=True)
        server_version = server_info.get("version", "")
        min_required_version = server_info.get("min_required_version", "")

        if _version_cmp(client_version, min_required_version) < 0:
            raise RuntimeError(
                f"AioDocClient version ({client_version}) is lower than the minimum required server version"
                f" ({min_required_version}). Please upgrade the AioDocClient to ensure compatibility."
            )
        if server_version != client_version:
            warnings.warn(
                f"AioDocClient version ({client_version}) does not match server version ({server_version})."
                " This may lead to compatibility issues.",
                UserWarning,
            )

    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()

    async def __aenter__(self):
        """Async context manager entry."""
        if not self.version_checked:
            await self.check_version()
            self.version_checked = True
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()

    def _decode_json(self, response: httpx.Response):
        try:
            return response.json()
        except JSONDecodeError as e:
            raise JSONDecodeError(
                f"Response text:\n\n{response.text}\n---\n{e.msg}",
                e.doc,
                e.pos,
            ) from None

    async def _request(
        self,
        method: str,
        path: str,
        json_data: dict | list | None = None,
        params: dict | None = None,
        _checking: bool = False,
    ) -> httpx.Response:
        """Make async HTTP request to the server."""
        url = f"{self.server_url}{self.prefix}{path}"

        if not (_checking or self.version_checked):
            await self.check_version()
            self.version_checked = True

        retries = 5
        response = None
        exception = None
        while True:
            if retries < 0:
                break
            try:
                response = await self.client.request(
                    method=method,
                    url=url,
                    json=json_data,
                    params=params,
                )
            except httpx.RemoteProtocolError as e:
                exception = e
                retries -= 1
                continue
            except httpx.ConnectError as e:
                exception = e
                retries -= 1
                continue
            except httpx.ReadError as e:
                exception = e
                retries -= 1
                continue
            if response.status_code == 502:
                retries -= 1
                continue
            break

        if response is None:
            raise exception if exception else Exception("Failed to make request to server.")
        if response.status_code >= 400:
            exception = decode_error(response.status_code, response.text)
            raise exception
        return response

    async def _get(self, path: str, params: dict | None = None, _checking=False) -> dict:
        """Make async GET request and return JSON response."""
        response = await self._request("GET", path, params=params, _checking=_checking)
        return self._decode_json(response)

    async def _post(self, path: str, json_data: dict | list | None = None, params: dict | None = None) -> dict | list:
        """Make async POST request and return JSON response."""
        response = await self._request("POST", path, json_data=json_data, params=params)
        return self._decode_json(response)

    async def _put(self, path: str, json_data: dict | list | None = None, params: dict | None = None) -> dict | None:
        """Make async PUT request and return JSON response."""
        response = await self._request("PUT", path, json_data=json_data, params=params)
        if response.status_code == 204 or len(response.content) == 0:
            return None
        return self._decode_json(response)

    async def _patch(self, path: str, json_data: dict | list | None = None, params: dict | None = None) -> dict | None:
        """Make async PATCH request and return JSON response."""
        response = await self._request("PATCH", path, json_data=json_data, params=params)
        if response.status_code == 204 or len(response.content) == 0:
            return None
        return self._decode_json(response)

    async def _delete(self, path: str) -> dict | None:
        """Make async DELETE request and return JSON response."""
        response = await self._request("DELETE", path)
        if response.status_code == 204 or len(response.content) == 0:
            return None
        return self._decode_json(response)

    async def _stream(self, path: str, json_data: dict | list | None = None, params: dict | None = None) -> AsyncIterable[dict]:
        """Make async POST request and stream JSON lines response."""
        url = f"{self.server_url}{self.prefix}{path}"

        if not self.version_checked:
            await self.check_version()
            self.version_checked = True

        async with self.client.stream("POST", url, json=json_data, params=params) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if line:
                    yield json.loads(line)

    def _dump_elem(self, elem_input: InputModel) -> dict:
        """Dump element input model to dict for JSON serialization."""
        if isinstance(elem_input, LayoutInput):
            return {
                "blocks": [self._dump_elem(b) for b in elem_input.blocks],
                "relations": elem_input.relations,
                "tags": elem_input.tags,
            }
        return elem_input.model_dump()

    def _parse_elem(self, elem_type: type[T], elem_data: dict) -> T:
        """Parse element data into the specified type."""
        if elem_type == Layout:
            blocks = elem_data.get("blocks") or []
            elem_data["blocks"] = [self._parse_elem(Block, b) for b in blocks]
        elif elem_type == EvalLayout:
            blocks = elem_data.get("blocks") or []
            elem_data["blocks"] = [EvalLayoutBlock(**b) if isinstance(b, dict) else b for b in blocks]
        elem_object = elem_type(**elem_data)
        elem_object.aio_store = self
        if isinstance(elem_object, Value) and self.decode_value:
            elem_object.decode()
        return elem_object

    ####################
    # READ OPERATIONS  #
    ####################

    async def health_check(self, show_stats: bool = False) -> dict:
        """Check the health of the doc store (async)."""
        params = {"show_stats": show_stats} if show_stats else None
        return await self._get("/health", params=params)

    async def get_doc(self, doc_id: str) -> Doc:
        """Get a doc by its ID (async)."""
        data = await self._get(f"/docs/{doc_id}")
        return self._parse_elem(Doc, data)

    async def get_doc_by_pdf_path(self, pdf_path: str) -> Doc:
        """Get a doc by its PDF path (async)."""
        data = await self._get(f"/docs/pdf-path/{_encode_uri_component(pdf_path)}")
        return self._parse_elem(Doc, data)

    async def get_doc_by_pdf_hash(self, pdf_hash: str) -> Doc:
        """Get a doc by its PDF sha256sum hex-string (async)."""
        data = await self._get(f"/docs/pdf-hash/{pdf_hash}")
        return self._parse_elem(Doc, data)

    async def get_page(self, page_id: str) -> Page:
        """Get a page by its ID (async)."""
        data = await self._get(f"/pages/{page_id}")
        return self._parse_elem(Page, data)

    async def get_page_by_image_path(self, image_path: str) -> Page:
        """Get a page by its image path (async)."""
        data = await self._get(f"/pages/image-path/{_encode_uri_component(image_path)}")
        return self._parse_elem(Page, data)

    async def get_page_by_image_hash(self, image_hash: str) -> Page:
        """Get a page by its image hash (async)."""
        data = await self._get(f"/pages/image-hash/{image_hash}")
        return self._parse_elem(Page, data)

    async def get_layout(self, layout_id: str, expand: bool = False) -> Layout:
        """Get a layout by its ID (async)."""
        data = await self._get(f"/layouts/{layout_id}", params={"expand": expand})
        return self._parse_elem(Layout, data)

    async def get_layout_by_page_id_and_provider(self, page_id: str, provider: str, expand: bool = False) -> Layout:
        """Get a layout by its page ID and provider (async)."""
        data = await self._get(f"/pages/{page_id}/layouts/{provider}", params={"expand": expand})
        return self._parse_elem(Layout, data)

    async def get_block(self, block_id: str) -> Block:
        """Get a block by its ID (async)."""
        data = await self._get(f"/blocks/{block_id}")
        return self._parse_elem(Block, data)

    async def get_block_by_image_path(self, image_path: str) -> Block:
        """Get a block by its image path (async)."""
        data = await self._get(f"/blocks/image-path/{_encode_uri_component(image_path)}")
        return self._parse_elem(Block, data)

    async def get_super_block(self, page_id: str) -> Block:
        """Get the super block for a page (async)."""
        data = await self._get(f"/pages/{page_id}/super-block")
        return self._parse_elem(Block, data)

    async def get_content(self, content_id: str) -> Content:
        """Get a content by its ID (async)."""
        data = await self._get(f"/contents/{content_id}")
        return self._parse_elem(Content, data)

    async def get_content_by_block_id_and_version(self, block_id: str, version: str) -> Content:
        """Get a content by its block ID and version (async)."""
        data = await self._get(f"/blocks/{block_id}/contents/{version}")
        return self._parse_elem(Content, data)

    async def get_value(self, value_id: str) -> Value:
        """Get a value by its ID (async)."""
        data = await self._get(f"/values/{value_id}")
        return self._parse_elem(Value, data)

    async def get_value_by_elem_id_and_key(self, elem_id: str, key: str) -> Value:
        """Get a value by its elem_id and key (async)."""
        data = await self._get(f"/elements/{elem_id}/values/{key}")
        return self._parse_elem(Value, data)

    async def get_eval_layout(self, eval_layout_id: str) -> EvalLayout:
        """Get an eval layout by its ID (async)."""
        data = await self._get(f"/evallayouts/{eval_layout_id}")
        return self._parse_elem(EvalLayout, data)

    async def get_eval_content(self, eval_content_id: str) -> EvalContent:
        """Get an eval content by its ID (async)."""
        data = await self._get(f"/evalcontents/{eval_content_id}")
        return self._parse_elem(EvalContent, data)

    async def distinct_values(
        self,
        elem_type: ElemType,
        field: Literal["tags", "providers", "provider", "versions", "version"],
        query: dict | None = None,
    ) -> list[str]:
        """Get all distinct values for a specific field of an element type (async)."""
        data = await self._post(f"/distinct/{elem_type}/{field}", json_data=query)
        assert isinstance(data, list)
        return data

    async def find(
        self,
        elem_type: ElemType | type,
        query: dict | list[dict] | None = None,
        query_from: ElemType | type | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable[Element]:
        """Find elements of a specific type matching the query (async)."""
        # Convert class types to elem_type strings
        if isinstance(elem_type, type):
            elem_type = elem_type.__name__.lower()  # type: ignore
        if isinstance(query_from, type):
            query_from = query_from.__name__.lower()  # type: ignore

        params = {}
        if query_from:
            params["query_from"] = query_from
        if skip is not None:
            params["skip"] = skip
        if limit is not None:
            params["limit"] = limit

        # Map elem_type to element class
        elem_classes = {
            "doc": Doc,
            "page": Page,
            "layout": Layout,
            "block": Block,
            "content": Content,
            "value": Value,
            "task": Task,
            "eval_layout": EvalLayout,
            "eval_content": EvalContent,
        }

        assert isinstance(elem_type, str)
        elem_cls = elem_classes.get(elem_type, Element)

        async for data in self._stream(f"/stream/{elem_type}", json_data=query, params=params):
            yield self._parse_elem(elem_cls, data)

    async def count(
        self,
        elem_type: ElemType | type,
        query: dict | list[dict] | None = None,
        query_from: ElemType | type | None = None,
        estimated: bool = False,
    ) -> int:
        """Count elements of a specific type matching the query (async)."""
        # Convert class types to elem_type strings
        if isinstance(elem_type, type):
            elem_type = elem_type.__name__.lower()  # type: ignore
        if isinstance(query_from, type):
            query_from = query_from.__name__.lower()  # type: ignore

        params = {}
        if query_from:
            params["query_from"] = query_from
        if estimated:
            params["estimated"] = estimated

        data = await self._post(f"/count/{elem_type}", json_data=query, params=params)
        assert isinstance(data, int)
        return data

    ####################
    # WRITE OPERATIONS #
    ####################

    async def add_tag(self, elem_id: str, tag: str) -> None:
        """Add tag to an element (async)."""
        await self._put(f"/elements/{elem_id}/tags/{tag}")

    async def del_tag(self, elem_id: str, tag: str) -> None:
        """Delete tag from an element (async)."""
        await self._delete(f"/elements/{elem_id}/tags/{tag}")

    async def batch_add_tag(self, elem_type: ElemType, tag: str, elem_ids: list[str]) -> None:
        """Batch add tag to multiple elements (async)."""
        await self._post(f"/batch/{elem_type}/add-tag/{tag}", json_data=elem_ids)

    async def batch_del_tag(self, elem_type: ElemType, tag: str, elem_ids: list[str]) -> None:
        """Batch delete tag from multiple elements (async)."""
        await self._post(f"/batch/{elem_type}/del-tag/{tag}", json_data=elem_ids)

    async def add_attr(self, elem_id: str, name: str, attr_input: AttrInput) -> None:
        """Add an attribute to an element (async)."""
        input_data = self._dump_elem(attr_input)
        await self._put(f"/elements/{elem_id}/attrs/{name}", json_data=input_data)

    async def add_attrs(self, elem_id: str, attrs: dict[str, AttrValueType]) -> None:
        """Add multiple attributes to an element (async)."""
        await self._patch(f"/elements/{elem_id}/attrs", json_data=attrs)

    async def del_attr(self, elem_id: str, name: str) -> None:
        """Delete an attribute from an element (async)."""
        await self._delete(f"/elements/{elem_id}/attrs/{name}")

    async def add_metric(self, elem_id: str, name: str, metric_input: MetricInput) -> None:
        """Add a metric to an element (async)."""
        input_data = self._dump_elem(metric_input)
        await self._put(f"/elements/{elem_id}/metrics/{name}", json_data=input_data)

    async def del_metric(self, elem_id: str, name: str) -> None:
        """Delete a metric from an element (async)."""
        await self._delete(f"/elements/{elem_id}/metrics/{name}")

    async def tagging(self, elem_id: str, tagging_input: TaggingInput) -> None:
        """Add/Delete tags, attributes, and metrics to/from an element (async)."""
        input_data = self._dump_elem(tagging_input)
        await self._post(f"/elements/{elem_id}/tagging", json_data=input_data)

    async def batch_tagging(self, elem_type: ElemType, inputs: list[TaggingInput]) -> None:
        """Batch add/delete tags, attributes, and metrics to/from multiple elements (async)."""
        input_data = [self._dump_elem(t) for t in inputs]
        await self._post(f"/batch/{elem_type}/tagging", json_data=input_data)

    async def insert_value(self, elem_id: str, key: str, value_input: ValueInput) -> Value:
        """Insert a new value for a element (async)."""
        if isinstance(value_input.value, np.ndarray):
            value_input = ValueInput(
                value=encode_ndarray(value_input.value),
                type="ndarray",
            )
        input_data = self._dump_elem(value_input)
        data = await self._put(f"/elements/{elem_id}/values/{key}", json_data=input_data)
        assert isinstance(data, dict)
        return self._parse_elem(Value, data)

    async def insert_doc(self, doc_input: DocInput, skip_ext_check=False) -> Doc:
        """Insert a new doc into the database (async)."""
        doc_input.pdf_info = await self._read_pdf_info(doc_input.pdf_path, skip_ext_check)
        if doc_input.orig_path is not None:
            doc_input.orig_info = await self._read_orig_info(doc_input.orig_path)
        input_data = self._dump_elem(doc_input)
        data = await self._post("/docs", json_data=input_data, params={"skip_ext_check": skip_ext_check})
        assert isinstance(data, dict)
        return self._parse_elem(Doc, data)

    async def insert_page(self, page_input: PageInput, skip_hash_check: bool = False) -> Page:
        """Insert a new page into the database (async)."""
        params = {"skip_hash_check": True} if skip_hash_check else {}
        page_input.image_info = await self._read_image_info(page_input.image_path)
        input_data = self._dump_elem(page_input)
        data = await self._post("/pages", json_data=input_data, params=params)
        assert isinstance(data, dict)
        return self._parse_elem(Page, data)

    async def insert_layout(
        self, page_id: str, provider: str, layout_input: LayoutInput, insert_blocks=False, upsert=False
    ) -> Layout:
        """Insert a new layout into the database (async)."""
        input_data = self._dump_elem(layout_input)
        data = await self._put(
            f"/pages/{page_id}/layouts/{provider}",
            json_data=input_data,
            params={"insert_blocks": insert_blocks, "upsert": upsert},
        )
        assert isinstance(data, dict)
        return self._parse_elem(Layout, data)

    async def insert_block(self, page_id: str, block_input: BlockInput) -> Block:
        """Insert a new block for a page (async)."""
        input_data = self._dump_elem(block_input)
        data = await self._post(f"/pages/{page_id}/blocks", json_data=input_data)
        assert isinstance(data, dict)
        return self._parse_elem(Block, data)

    async def insert_blocks(self, page_id: str, blocks: list[BlockInput]) -> list[Block]:
        """Insert multiple blocks for a page (async)."""
        input_data = [self._dump_elem(b) for b in blocks]
        data = await self._post(f"/pages/{page_id}/blocks/batch", json_data=input_data)
        assert isinstance(data, list)
        return [self._parse_elem(Block, block_data) for block_data in data]

    async def insert_standalone_block(self, block_input: StandaloneBlockInput) -> Block:
        """Insert a new standalone block (without page) (async)."""
        block_input.image_info = await self._read_image_info(block_input.image_path)
        input_data = self._dump_elem(block_input)
        data = await self._post("/blocks", json_data=input_data)
        assert isinstance(data, dict)
        return self._parse_elem(Block, data)

    async def insert_content(self, block_id: str, version: str, content_input: ContentInput, upsert=False) -> Content:
        """Insert a new content for a block (async)."""
        input_data = self._dump_elem(content_input)
        data = await self._put(
            f"/blocks/{block_id}/contents/{version}",
            json_data=input_data,
            params={"upsert": upsert},
        )
        assert isinstance(data, dict)
        return self._parse_elem(Content, data)

    async def insert_content_blocks_layout(
        self,
        page_id: str,
        provider: str,
        content_blocks: list[ContentBlockInput],
        upsert: bool = False,
    ) -> Layout:
        """Import content blocks and create a layout for a page (async)."""
        input_data = [self._dump_elem(b) for b in content_blocks]
        data = await self._put(
            f"/pages/{page_id}/content-blocks-layouts/{provider}",
            json_data=input_data,
            params={"upsert": upsert},
        )
        assert isinstance(data, dict)
        return self._parse_elem(Layout, data)

    async def insert_eval_layout(
        self,
        layout_id: str,
        provider: str,
        blocks: list[EvalLayoutBlock] | None = None,
        relations: list[dict] | None = None,
    ) -> EvalLayout:
        """Insert a new eval layout into the database (async)."""
        input_data = {
            "layout_id": layout_id,
            "provider": provider,
            "blocks": [b.model_dump() for b in blocks] if blocks else [],
            "relations": relations or [],
        }
        data = await self._post("/evallayouts", json_data=input_data)
        assert isinstance(data, dict)
        return self._parse_elem(EvalLayout, data)

    async def insert_eval_content(
        self,
        content_id: str,
        version: str,
        format: str,
        content: str,
    ) -> EvalContent:
        """Insert a new eval content into the database (async)."""
        input_data = {
            "content_id": content_id,
            "version": version,
            "format": format,
            "content": content,
        }
        data = await self._post("/evalcontents", json_data=input_data)
        assert isinstance(data, dict)
        return self._parse_elem(EvalContent, data)

    ###################
    # TASK OPERATIONS #
    ###################

    async def list_tasks(
        self,
        query: dict | None = None,
        target: str | None = None,
        batch_id: str | None = None,
        command: str | None = None,
        status: str | None = None,
        create_user: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> list[Task]:
        """List tasks by filters (async)."""
        params = {
            **({"target": target} if target else {}),
            **({"batch_id": batch_id} if batch_id else {}),
            **({"command": command} if command else {}),
            **({"status": status} if status else {}),
            **({"create_user": create_user} if create_user else {}),
            **({"skip": skip} if skip is not None else {}),
            **({"limit": limit} if limit is not None else {}),
        }
        data = await self._post("/list/tasks", json_data=query, params=params)
        assert isinstance(data, list)
        return [self._parse_elem(Task, task_data) for task_data in data]

    async def get_task(self, task_id: str) -> Task:
        """Get a task by its ID (async)."""
        data = await self._get(f"/tasks/{task_id}")
        return self._parse_elem(Task, data)

    async def insert_task(self, target_id: str, task_input: TaskInput) -> Task:
        """Insert a new task into the database (async)."""
        input_data = self._dump_elem(task_input)
        data = await self._post(f"/elements/{target_id}/tasks", json_data=input_data)
        assert isinstance(data, dict)
        return self._parse_elem(Task, data)

    async def grab_new_tasks(self, command: str, num=10, hold_sec=3600) -> list[Task]:
        """Grab new tasks for processing (async)."""
        params = {"num": num, "hold_sec": hold_sec}
        data = await self._post(f"/grab-new-tasks/{command}", params=params)
        return [self._parse_elem(Task, task_data) for task_data in data]

    async def update_task(
        self,
        task_id: str,
        command: str,
        status: Literal["done", "error", "skipped"],
        error_message: str | None = None,
        check_mismatch: bool = False,
        task: Task | None = None,
    ) -> None:
        """Update a task after processing (async)."""
        params = {
            "command": command,
            "status": status,
            **({"error_message": error_message} if error_message else {}),
            **({"check_mismatch": check_mismatch} if check_mismatch else {}),
        }
        input_data = task.model_dump() if task else None
        await self._post(f"/update-grabbed-task/{task_id}", json_data=input_data, params=params)

    async def count_tasks(self, command: str | None = None) -> list[TaskCount]:
        """Count tasks grouped by priority and status (async)."""
        params = {"command": command} if command else {}
        data = await self._get("/count-tasks", params=params)
        assert isinstance(data, list)
        return [TaskCount(**task_count_data) for task_count_data in data]

    #########################
    # MANAGEMENT OPERATIONS #
    #########################

    async def list_s3_buckets(self) -> list[S3Bucket]:
        """List all S3 buckets in the system (async)."""
        data = await self._get("/s3-buckets")
        assert isinstance(data, list)
        return [S3Bucket(**bucket_data) for bucket_data in data]

    async def list_users(self) -> list[User]:
        """List all users in the system (async)."""
        data = await self._get("/users")
        assert isinstance(data, list)
        return [User(**user_data) for user_data in data]

    async def get_user(self, name: str) -> User:
        """Get a user by name (async)."""
        data = await self._get(f"/users/{name}")
        assert isinstance(data, dict)
        return User(**data)

    async def insert_user(self, user_input: UserInput) -> User:
        """Add a new user to the system (async)."""
        input_data = user_input.model_dump()
        data = await self._post("/users", json_data=input_data)
        assert isinstance(data, dict)
        return User(**data)

    async def update_user(self, name: str, user_update: UserUpdate) -> User:
        """Update an existing user in the system (async)."""
        input_data = user_update.model_dump()
        data = await self._put(f"/users/{name}", json_data=input_data)
        assert isinstance(data, dict)
        return User(**data)

    async def list_known_names(self) -> list[KnownName]:
        """List all known tag/attribute/metric names in the system (async)."""
        data = await self._get("/known-names")
        assert isinstance(data, list)
        return [KnownName(**name_data) for name_data in data]

    async def insert_known_name(self, known_name_input: KnownNameInput) -> KnownName:
        """Add a new known tag/attribute/metric name to the system (async)."""
        input_data = known_name_input.model_dump()
        data = await self._post("/known-names", json_data=input_data)
        assert isinstance(data, dict)
        return KnownName(**data)

    async def update_known_name(self, name: str, known_name_update: KnownNameUpdate) -> KnownName:
        """Update an existing known tag/attribute/metric name in the system (async)."""
        input_data = known_name_update.model_dump()
        data = await self._put(f"/known-names/{name}", json_data=input_data)
        assert isinstance(data, dict)
        return KnownName(**data)

    async def add_known_option(self, attr_name: str, option_name: str, option_input: KnownOptionInput) -> None:
        """Add/Update a new known option to a known attribute name (async)."""
        input_data = option_input.model_dump()
        await self._put(f"/known-names/{attr_name}/options/{option_name}", json_data=input_data)

    async def del_known_option(self, attr_name: str, option_name: str) -> None:
        """Delete a known option from a known attribute name (async)."""
        await self._delete(f"/known-names/{attr_name}/options/{option_name}")

    async def list_embedding_models(self) -> list[EmbeddingModel]:
        """List all embedding models in the system (async)."""
        data = await self._get("/embedding-models")
        assert isinstance(data, list)
        return [EmbeddingModel(**model_data) for model_data in data]

    async def get_embedding_model(self, name: str) -> EmbeddingModel:
        """Get an embedding model by name (async)."""
        data = await self._get(f"/embedding-models/{name}")
        assert isinstance(data, dict)
        return EmbeddingModel(**data)

    async def insert_embedding_model(self, embedding_model: EmbeddingModel) -> EmbeddingModel:
        """Insert a new embedding model to the system (async)."""
        input_data = embedding_model.model_dump()
        data = await self._post("/embedding-models", json_data=input_data)
        assert isinstance(data, dict)
        return EmbeddingModel(**data)

    async def update_embedding_model(self, name: str, update: EmbeddingModelUpdate) -> EmbeddingModel:
        """Update an existing embedding model in the system (async)."""
        input_data = update.model_dump()
        data = await self._put(f"/embedding-models/{name}", json_data=input_data)
        assert isinstance(data, dict)
        return EmbeddingModel(**data)

    async def add_embeddings(self, elem_type: EmbeddableElemType, model: str, embeddings: list[EmbeddingInput]) -> None:
        """Add embeddings to elements of same elem_type (async)."""
        input_data = [self._dump_elem(e) for e in embeddings]
        await self._post(f"/batch/{elem_type}/add-embedding/{model}", json_data=input_data)

    async def search_embeddings(self, elem_type: EmbeddableElemType, model: str, query: EmbeddingQuery) -> list[Embedding]:
        """Search embeddings for elements of same elem_type (async)."""
        input_data = self._dump_elem(query)
        data = await self._post(f"/search/{elem_type}/by-embedding/{model}", json_data=input_data)
        assert isinstance(data, list)
        return [Embedding(**emb_data) for emb_data in data]

    async def list_triggers(self) -> list[Trigger]:
        """List all triggers in the system (async)."""
        data = await self._get("/triggers")
        assert isinstance(data, list)
        return [Trigger(**trigger_data) for trigger_data in data]

    async def get_trigger(self, trigger_id: str) -> Trigger:
        """Get a trigger by ID (async)."""
        data = await self._get(f"/triggers/{trigger_id}")
        assert isinstance(data, dict)
        return Trigger(**data)

    async def insert_trigger(self, trigger_input: TriggerInput) -> Trigger:
        """Insert a new trigger to the system (async)."""
        input_data = self._dump_elem(trigger_input)
        data = await self._post("/triggers", json_data=input_data)
        assert isinstance(data, dict)
        return Trigger(**data)

    async def update_trigger(self, trigger_id: str, trigger_input: TriggerInput) -> Trigger:
        """Update an existing trigger in the system (async)."""
        input_data = self._dump_elem(trigger_input)
        data = await self._put(f"/triggers/{trigger_id}", json_data=input_data)
        assert isinstance(data, dict)
        return Trigger(**data)

    async def delete_trigger(self, trigger_id: str) -> None:
        """Delete a trigger from the system (async)."""
        await self._delete(f"/triggers/{trigger_id}")
