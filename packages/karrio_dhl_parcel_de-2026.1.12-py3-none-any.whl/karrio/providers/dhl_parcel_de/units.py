import csv
import attr
import typing
import pathlib
import karrio.lib as lib
import karrio.core.units as units
import karrio.core.models as models

import karrio.schemas.dhl_parcel_de.shipping_request as ship_req


# System config schema for runtime settings (e.g., API credentials)
# Format: Dict[str, Tuple[default_value, description, type]]
# Note: The actual env values are read by the server (constance.py) using decouple
SYSTEM_CONFIG = {
    "DHL_PARCEL_DE_USERNAME": (
        "",
        "DHL Parcel DE API username for production",
        str,
    ),
    "DHL_PARCEL_DE_PASSWORD": (
        "",
        "DHL Parcel DE API password for production",
        str,
    ),
    "DHL_PARCEL_DE_CLIENT_ID": (
        "",
        "DHL Parcel DE OAuth client ID for production",
        str,
    ),
    "DHL_PARCEL_DE_CLIENT_SECRET": (
        "",
        "DHL Parcel DE OAuth client secret for production",
        str,
    ),
    "DHL_PARCEL_DE_SANDBOX_USERNAME": (
        "user-valid",
        "DHL Parcel DE API username for sandbox/test mode",
        str,
    ),
    "DHL_PARCEL_DE_SANDBOX_PASSWORD": (
        "SandboxPasswort2023!",
        "DHL Parcel DE API password for sandbox/test mode",
        str,
    ),
    "DHL_PARCEL_DE_SANDBOX_CLIENT_ID": (
        "",
        "DHL Parcel DE OAuth client ID for sandbox/test mode",
        str,
    ),
    "DHL_PARCEL_DE_SANDBOX_CLIENT_SECRET": (
        "",
        "DHL Parcel DE OAuth client secret for sandbox/test mode",
        str,
    ),
}


class PackagingType(lib.StrEnum):
    """Carrier specific packaging type"""

    PACKAGE = "PACKAGE"

    """ Unified Packaging type mapping """
    envelope = PACKAGE
    pak = PACKAGE
    tube = PACKAGE
    pallet = PACKAGE
    small_box = PACKAGE
    medium_box = PACKAGE
    your_packaging = PACKAGE


class CustomsContentType(lib.StrEnum):
    other = "OTHER"
    present = "PRESENT"
    document = "DOCUMENT"
    return_of_goods = "RETURN_OF_GOODS"
    commercial_goods = "COMMERCIAL_GOODS"
    commercial_sample = "COMMERCIAL_SAMPLE"

    """ Unified Content type mapping """
    gift = present
    documents = document
    sample = commercial_sample
    merchandise = commercial_goods
    return_merchandise = return_of_goods


class Incoterm(lib.StrEnum):
    """Carrier specific incoterm"""

    DDU = "DDU"
    DAP = "DAP"
    DDP = "DDP"
    DDX = "DDX"
    DXV = "DXV"


class LabelType(lib.Enum):
    """Carrier specific label type"""

    PDF_A4 = ("PDF", "A4")
    ZPL2_A4 = ("ZPL2", "A4")
    PDF_910_300_700 = ("PDF", "910-300-700")
    ZPL2_910_300_700 = ("ZPL2", "910-300-700")
    PDF_910_300_700_oz = ("PDF", "910-300-700-oz")
    ZPL2_910_300_700_oz = ("ZPL2", "910-300-700-oz")
    PDF_910_300_710 = ("PDF", "910-300-710")
    ZPL2_910_300_710 = ("ZPL2", "910-300-710")
    PDF_910_300_600 = ("PDF", "910-300-600")
    ZPL2_910_300_600 = ("ZPL2", "910-300-600")
    PDF_910_300_610 = ("PDF", "910-300-610")
    ZPL2_910_300_610 = ("ZPL2", "910-300-610")
    PDF_910_300_400 = ("PDF", "910-300-400")
    ZPL2_910_300_400 = ("ZPL2", "910-300-400")
    PDF_910_300_410 = ("PDF", "910-300-410")
    ZPL2_910_300_410 = ("ZPL2", "910-300-410")
    PDF_910_300_300 = ("PDF", "910-300-300")
    ZPL2_910_300_300 = ("ZPL2", "910-300-300")
    PDF_910_300_300_oz = ("PDF", "910-300-300-oz")
    ZPL2_910_300_300_oz = ("ZPL2", "910-300-300-oz")

    """ Unified Label type mapping """
    PDF = PDF_A4
    ZPL = ZPL2_A4
    PNG = PDF_A4


class ShippingDocumentCategory(lib.StrEnum):
    """Carrier specific document category types.

    Maps DHL Parcel DE document types to standard ShippingDocumentCategory.
    Values match the exact syntax used by DHL Parcel DE API.
    """

    shipping_label = "shippingLabel"
    return_label = "returnLabel"
    export_document = "exportDocument"
    receipt = "receipt"
    cod_document = "codLabel"
    enclosed_return_label = "enclosedReturnLabel"
    harmonized_label = "harmonizedLabel"
    international_shipping_label = "internationalShippingLabel"
    warenpost_national = "warenpostNational"
    return_label_international = "returnLabelInternational"
    warenpost_international = "warenpostInternational"
    error_label = "errorLabel"
    qr_code = "qrCode"


class ShippingService(lib.Enum):
    """Carrier specific services"""

    dhl_parcel_de_paket = "V01PAK"
    dhl_parcel_de_kleinpaket = "V62KP"
    dhl_parcel_de_europaket = "V54EPAK"
    dhl_parcel_de_paket_international = "V53WPAK"
    dhl_parcel_de_warenpost_international = "V66WPI"

    # Alias for backwards compatibility (Warenpost replaced by Kleinpaket as of 2025)
    dhl_parcel_de_warenpost = dhl_parcel_de_kleinpaket


@attr.s(auto_attribs=True)
class ServiceBillingNumberType:
    """Typed object for service-specific billing number configuration."""

    service: ShippingService  # Required: shipping service enum
    billing_number: str  # Required: billing number for this service

    name: typing.Optional[str] = None  # Optional: friendly name for this entry


# Default test/sandbox billing numbers from DHL documentation
# https://developer.dhl.com/api-reference/parcel-de-shipping-post-parcel-germany-v2
DEFAULT_TEST_BILLING_NUMBERS: typing.List[ServiceBillingNumberType] = [
    # V01PAK - DHL Paket (incl. services)
    ServiceBillingNumberType(
        service="dhl_parcel_de_paket", billing_number="33333333330102"
    ),
    # V53WPAK - DHL Paket International
    ServiceBillingNumberType(
        service="dhl_parcel_de_paket_international", billing_number="33333333335301"
    ),
    # V54EPAK - DHL Europaket
    ServiceBillingNumberType(
        service="dhl_parcel_de_europaket", billing_number="33333333335401"
    ),
    # V62KP - DHL Kleinpaket
    ServiceBillingNumberType(
        service="dhl_parcel_de_kleinpaket", billing_number="33333333336201"
    ),
    # V66WPI - Warenpost International
    ServiceBillingNumberType(
        service="dhl_parcel_de_warenpost_international", billing_number="33333333336601"
    ),
]

# Default test billing number (V01PAK with services)
DEFAULT_TEST_BILLING_NUMBER = "33333333330102"


class ConnectionConfig(lib.Enum):
    label_type = lib.OptionEnum(
        "label_type",
        lib.units.create_enum("LabelType", [_.name for _ in LabelType]),  # type: ignore
    )
    language = lib.OptionEnum(
        "language",
        lib.units.create_enum("Language", ["de", "en"]),
    )
    default_billing_number = lib.OptionEnum(
        "default_billing_number", default=DEFAULT_TEST_BILLING_NUMBER
    )
    service_billing_numbers = lib.OptionEnum(
        "service_billing_numbers",
        typing.List[ServiceBillingNumberType],
        default=DEFAULT_TEST_BILLING_NUMBERS,
    )
    pickup_billing_number = lib.OptionEnum(
        "pickup_billing_number", str, default="22222222220801"
    )
    profile = lib.OptionEnum("profile")
    cost_center = lib.OptionEnum("cost_center")
    creation_software = lib.OptionEnum("creation_software")
    shipping_options = lib.OptionEnum("shipping_options", list)
    shipping_services = lib.OptionEnum("shipping_services", list)


class ShippingOption(lib.Enum):
    """Carrier specific options"""

    # fmt: off
    # Delivery Options
    dhl_parcel_de_preferred_neighbour = lib.OptionEnum(
        "preferredNeighbour",
        meta=dict(
            category="DELIVERY_OPTIONS",
            configurable=True,
            help="Preferred neighbour for delivery if recipient not home",
            compatible_services=["dhl_parcel_de_paket"],
        )
    )
    dhl_parcel_de_preferred_location = lib.OptionEnum(
        "preferredLocation",
        meta=dict(
            category="DELIVERY_OPTIONS",
            configurable=True,
            help="Preferred drop-off location (e.g., garage, shed)",
            compatible_services=["dhl_parcel_de_paket"],
        )
    )
    dhl_parcel_de_named_person_only = lib.OptionEnum(
        "namedPersonOnly", bool,
        meta=dict(
            category="DELIVERY_OPTIONS",
            configurable=True,
            help="Delivery only to the named recipient",
            compatible_services=["dhl_parcel_de_paket"],
        )
    )
    dhl_parcel_de_signed_for_by_recipient = lib.OptionEnum(
        "signedForByRecipient", bool,
        meta=dict(
            category="SIGNATURE",
            configurable=True,
            help="Require signature from recipient",
            compatible_services=["dhl_parcel_de_paket"],
        )
    )
    dhl_parcel_de_preferred_day = lib.OptionEnum(
        "preferredDay",
        meta=dict(
            category="DELIVERY_OPTIONS",
            configurable=True,
            help="Preferred delivery day (format: YYYY-MM-DD)",
            compatible_services=["dhl_parcel_de_paket"],
        )
    )
    dhl_parcel_de_no_neighbour_delivery = lib.OptionEnum(
        "noNeighbourDelivery", bool,
        meta=dict(
            category="DELIVERY_OPTIONS",
            configurable=True,
            help="Do not deliver to neighbours",
            compatible_services=["dhl_parcel_de_paket"],
        )
    )
    # Product/Insurance Options
    dhl_parcel_de_additional_insurance = lib.OptionEnum(
        "additionalInsurance", float,
        meta=dict(
            category="INSURANCE",
            configurable=False,
            help="Additional insurance value in EUR (0-2500, 0-25000, or 0-50000)",
            compatible_services=["dhl_parcel_de_paket", "dhl_parcel_de_paket_international", "dhl_parcel_de_europaket", "dhl_parcel_de_kleinpaket"],
        )
    )
    dhl_parcel_de_bulky_goods = lib.OptionEnum(
        "bulkyGoods", bool,
        meta=dict(
            category="DELIVERY_OPTIONS",
            configurable=True,
            help="Mark shipment as bulky goods (Sperrgut)",
            compatible_services=["dhl_parcel_de_paket", "dhl_parcel_de_kleinpaket"],
        )
    )
    dhl_parcel_de_cash_on_delivery = lib.OptionEnum(
        "cashOnDelivery", float,
        meta=dict(
            category="COD",
            configurable=False,
            help="Cash on delivery amount in EUR",
            compatible_services=["dhl_parcel_de_paket", "dhl_parcel_de_kleinpaket"],
        )
    )
    dhl_parcel_de_individual_sender_requirement = lib.OptionEnum(
        "individualSenderRequirement",
        meta=dict(
            category="INSTRUCTIONS",
            configurable=True,
            help="Custom sender note for the label",
        )
    )
    dhl_parcel_de_premium = lib.OptionEnum(
        "premium", bool,
        meta=dict(
            category="DELIVERY_OPTIONS",
            configurable=True,
            help="Premium shipping service",
            compatible_services=["dhl_parcel_de_paket_international", "dhl_parcel_de_warenpost_international"],
        )
    )
    # PUDO/Locker Options
    dhl_parcel_de_closest_drop_point = lib.OptionEnum(
        "closestDropPoint", bool,
        meta=dict(
            category="PUDO",
            configurable=True,
            help="Deliver to closest drop point (CDP)",
            compatible_services=["dhl_parcel_de_paket", "dhl_parcel_de_paket_international", "dhl_parcel_de_kleinpaket"],
        )
    )
    dhl_parcel_de_parcel_outlet_routing = lib.OptionEnum(
        "parcelOutletRouting",
        meta=dict(
            category="PUDO",
            configurable=True,
            help="Filial routing - deliver to retail outlet",
            compatible_services=["dhl_parcel_de_paket", "dhl_parcel_de_paket_international", "dhl_parcel_de_kleinpaket"],
        )
    )
    # International Options
    dhl_parcel_de_postal_delivery_duty_paid = lib.OptionEnum(
        "postalDeliveryDutyPaid", bool,
        meta=dict(
            category="PAPERLESS",
            configurable=True,
            help="Postal Delivered Duty Paid (pDDP) - sender pays customs duties",
            compatible_services=["dhl_parcel_de_paket_international"],
        )
    )
    # Address/Delivery Location Options (not typically configurable at method level)
    dhl_parcel_de_postal_charges = lib.OptionEnum(
        "postalCharges", float,
        meta=dict(configurable=False)
    )
    dhl_parcel_de_post_number = lib.OptionEnum(
        "postNumber",
        meta=dict(category="PUDO", configurable=False, help="Postnummer for Packstation delivery")
    )
    dhl_parcel_de_retail_id = lib.OptionEnum(
        "retailID",
        meta=dict(category="PUDO", configurable=False, help="Retail outlet ID")
    )
    dhl_parcel_de_po_box_id = lib.OptionEnum(
        "poBoxID",
        meta=dict(category="PUDO", configurable=False, help="PO Box ID")
    )
    # Customs/Export Options
    dhl_parcel_de_shipper_customs_ref = lib.OptionEnum(
        "shipperCustomsRef",
        meta=dict(
            category="INVOICE",
            configurable=True,
            help="Sender EORI number for customs",
            compatible_services=["dhl_parcel_de_paket_international", "dhl_parcel_de_europaket", "dhl_parcel_de_warenpost_international"],
        )
    )
    dhl_parcel_de_consignee_customs_ref = lib.OptionEnum(
        "consigneeCustomsRef",
        meta=dict(
            category="INVOICE",
            configurable=True,
            help="Recipient ID for customs",
            compatible_services=["dhl_parcel_de_paket_international", "dhl_parcel_de_europaket", "dhl_parcel_de_warenpost_international"],
        )
    )
    dhl_parcel_de_permit_no = lib.OptionEnum(
        "permitNo",
        meta=dict(
            category="INVOICE",
            configurable=True,
            help="Export permit number",
            compatible_services=["dhl_parcel_de_paket_international", "dhl_parcel_de_europaket", "dhl_parcel_de_warenpost_international"],
        )
    )
    dhl_parcel_de_attestation_no = lib.OptionEnum(
        "attestationNo",
        meta=dict(
            category="INVOICE",
            configurable=True,
            help="Attestation number",
            compatible_services=["dhl_parcel_de_paket_international", "dhl_parcel_de_europaket", "dhl_parcel_de_warenpost_international"],
        )
    )
    dhl_parcel_de_has_electronic_export_notification = lib.OptionEnum(
        "hasElectronicExportNotification", bool,
        meta=dict(
            category="PAPERLESS",
            configurable=True,
            help="Electronic export notification (EEN)",
            compatible_services=["dhl_parcel_de_paket_international", "dhl_parcel_de_europaket", "dhl_parcel_de_warenpost_international"],
        )
    )
    dhl_parcel_de_MRN = lib.OptionEnum(
        "MRN",
        meta=dict(
            category="INVOICE",
            configurable=True,
            help="Movement Reference Number for customs declaration",
            compatible_services=["dhl_parcel_de_paket_international", "dhl_parcel_de_europaket", "dhl_parcel_de_warenpost_international"],
        )
    )
    dhl_parcel_de_locker_id = lib.OptionEnum(
        "lockerID", lib.to_int,
        meta=dict(
            category="LOCKER",
            configurable=False,
            help="Packstation locker ID",
            compatible_services=["dhl_parcel_de_paket", "dhl_parcel_de_kleinpaket"],
        )
    )
    # Identity/Age Verification (object type - not UI configurable but used in API)
    dhl_parcel_de_ident_check = lib.OptionEnum(
        "identCheck", ship_req.IdentCheckType,
        meta=dict(configurable=False, compatible_services=["dhl_parcel_de_paket"])
    )
    # Return options (DHL Retoure) - individual fields for UI configuration
    dhl_parcel_de_return_enabled = lib.OptionEnum(
        "returnEnabled", bool,
        meta=dict(
            category="RETURN",
            configurable=True,
            help="Enable DHL Retoure - include return label with shipment",
            compatible_services=["dhl_parcel_de_paket", "dhl_parcel_de_kleinpaket"],
        )
    )
    dhl_parcel_de_return_receiver_id = lib.OptionEnum(
        "returnReceiverId",
        meta=dict(
            category="RETURN",
            configurable=True,
            help="DHL Receiver ID for returns (configured in DHL Business Portal)",
            compatible_services=["dhl_parcel_de_paket", "dhl_parcel_de_kleinpaket"],
        )
    )
    dhl_parcel_de_return_billing_number = lib.OptionEnum(
        "returnBillingNumber",
        meta=dict(
            category="RETURN",
            configurable=True,
            help="Billing number for returns (if different from main billing number)",
            compatible_services=["dhl_parcel_de_paket", "dhl_parcel_de_kleinpaket"],
        )
    )
    dhl_parcel_de_return_reference = lib.OptionEnum(
        "returnReference",
        meta=dict(
            category="RETURN",
            configurable=True,
            help="Reference text for the return label",
            compatible_services=["dhl_parcel_de_paket", "dhl_parcel_de_kleinpaket"],
        )
    )
    # DHL Retoure object type - used internally for API requests (not UI configurable)
    dhl_parcel_de_dhl_retoure = lib.OptionEnum(
        "dhlRetoure", ship_req.DhlRetoureType,
        meta=dict(
            category="RETURN",
            configurable=False,
            help="DHL Retoure configuration for return labels",
            compatible_services=["dhl_parcel_de_paket", "dhl_parcel_de_kleinpaket"],
        )
    )
    dhl_parcel_de_visual_check_of_age = lib.OptionEnum(
        "visualCheckOfAge",
        lib.units.create_enum("VisualCheckOfAge", ["A16", "A18"]),  # type: ignore
        meta=dict(
            category="DELIVERY_OPTIONS",
            configurable=True,
            help="Visual age check at delivery (A16=16+, A18=18+)",
            compatible_services=["dhl_parcel_de_paket"],
        )
    )
    dhl_parcel_de_endorsement = lib.OptionEnum(
        "endorsement",
        lib.units.create_enum("endorsement", ["RETURN", "ABANDON"]),  # type: ignore
        default="RETURN",
        meta=dict(
            category="DELIVERY_OPTIONS",
            configurable=True,
            help="Action if delivery fails (RETURN or ABANDON)",
            compatible_services=["dhl_parcel_de_paket", "dhl_parcel_de_paket_international", "dhl_parcel_de_kleinpaket", "dhl_parcel_de_warenpost_international"],
        )
    )

    """ Unified Option type mapping """
    signature_confirmation = dhl_parcel_de_signed_for_by_recipient
    hold_at_location = dhl_parcel_de_closest_drop_point
    cash_on_delivery = dhl_parcel_de_cash_on_delivery
    shipping_charges = dhl_parcel_de_postal_charges
    insurance = dhl_parcel_de_additional_insurance
    locker_id = dhl_parcel_de_locker_id
    # fmt: on


def shipping_options_initializer(
    options: dict,
    package_options: units.ShippingOptions = None,
) -> units.ShippingOptions:
    """
    Apply default values to the given options.
    """

    if package_options is not None:
        options.update(package_options.content)

    # Read dhlRetoure from raw options — the OptionEnum code "dhlRetoure"
    # doesn't match enum member name "dhl_parcel_de_dhl_retoure" so we handle
    # the key mapping and dict-to-object conversion here.
    # NOTE: use get() not pop() to avoid mutating the shared payload.options dict
    # which is reused by to_packages for per-package option initialization.
    _retoure_data = options.get("dhlRetoure")
    if _retoure_data is None:
        _retoure_data = options.get("dhl_parcel_de_dhl_retoure")

    def items_filter(key: str) -> bool:
        return key in ShippingOption or key in units.ShippingOption  # type: ignore

    _options = units.ShippingOptions(options, ShippingOption, items_filter=items_filter)

    # Inject properly converted dhlRetoure option
    if _retoure_data is not None:
        _retoure_obj = (
            lib.to_object(ship_req.DhlRetoureType, _retoure_data)
            if isinstance(_retoure_data, dict)
            else _retoure_data
        )
        _options._options["dhl_parcel_de_dhl_retoure"] = lib.OptionEnum(
            "dhlRetoure", ship_req.DhlRetoureType, state=_retoure_obj
        )

    return _options


class CustomsOption(lib.Enum):
    mrn = lib.OptionEnum("MRN")
    permit_number = lib.OptionEnum("permitNo")
    attestation_number = lib.OptionEnum("attestationNo")
    shipper_customs_ref = lib.OptionEnum("shipperCustomsRef")
    consignee_customs_ref = lib.OptionEnum("consigneeCustomsRef")
    electronic_export_notification = lib.OptionEnum("electronicExportNotification")


class TrackingStatus(lib.Enum):
    delivered = ["delivered", "dlvrd"]
    in_transit = ["transit", "srted", "ulfmv", "ldtmv", "pckdu", "shrcu"]
    delivery_failed = ["failure", "ndelv"]
    delivery_delayed = ["unknown"]


class TrackingIncidentReason(lib.Enum):
    """Maps DHL Parcel DE exception codes to normalized TrackingIncidentReason."""

    # Carrier-caused issues
    carrier_damaged_parcel = ["damaged", "package_damaged", "parcel_damaged"]
    carrier_sorting_error = ["misrouted", "sorting_error", "wrong_route"]
    carrier_address_not_found = [
        "address_not_found",
        "invalid_address",
        "unknown_address",
    ]
    carrier_parcel_lost = ["lost", "missing", "not_found"]
    carrier_not_enough_time = ["time_constraint", "insufficient_time"]
    carrier_vehicle_issue = ["vehicle_issue", "transport_problem", "mechanical_issue"]

    # Consignee-caused issues
    consignee_refused = ["refused", "delivery_refused", "recipient_refused"]
    consignee_business_closed = ["business_closed", "closed", "shop_closed"]
    consignee_not_available = [
        "not_available",
        "recipient_not_available",
        "unavailable",
    ]
    consignee_not_home = ["not_home", "nobody_home", "recipient_absent"]
    consignee_incorrect_address = ["incorrect_address", "wrong_address", "bad_address"]
    consignee_access_restricted = ["access_restricted", "no_access", "restricted"]

    # Customs-related issues
    customs_delay = [
        "customs_delay",
        "customs_hold",
        "customs_processing",
        "clearance_delay",
    ]
    customs_documentation = [
        "customs_documents",
        "missing_documents",
        "documentation_required",
    ]
    customs_duties_unpaid = ["duties_unpaid", "customs_fees", "payment_required"]

    # Weather/Force majeure
    weather_delay = ["weather_delay", "weather", "severe_weather", "weather_conditions"]
    natural_disaster = ["natural_disaster", "emergency", "catastrophe"]

    # Delivery exceptions
    delivery_exception_hold = ["hold", "held", "on_hold", "depot_hold"]
    delivery_exception_undeliverable = [
        "undeliverable",
        "cannot_deliver",
        "delivery_impossible",
    ]

    # Other issues
    unknown = []


def load_services_from_csv() -> list:
    """
    Load service definitions from CSV file.
    CSV format: service_code,service_name,zone_label,country_codes,min_weight,max_weight,max_length,max_width,max_height,rate,currency,transit_days,domicile,international
    """
    csv_path = pathlib.Path(__file__).resolve().parent / "services.csv"

    if not csv_path.exists():
        # Fallback to simple default if CSV doesn't exist
        return [
            models.ServiceLevel(
                service_name="DHL Paket",
                service_code="dhl_parcel_de_paket",
                currency="EUR",
                domicile=True,
                zones=[models.ServiceZone(rate=0.0)],
            )
        ]

    # Group zones by service
    services_dict: dict[str, dict] = {}

    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            service_code = row["service_code"]
            service_name = row["service_name"]

            # Map carrier service code to karrio service code
            karrio_service_code = ShippingService.map(service_code).name_or_key

            row_min_weight = float(row["min_weight"]) if row.get("min_weight") else None
            row_max_weight = float(row["max_weight"]) if row.get("max_weight") else None

            # Initialize service if not exists
            if karrio_service_code not in services_dict:
                services_dict[karrio_service_code] = {
                    "service_name": service_name,
                    "service_code": karrio_service_code,
                    "currency": row.get("currency", "EUR"),
                    "min_weight": row_min_weight,
                    "max_weight": row_max_weight,
                    "max_length": (
                        float(row["max_length"]) if row.get("max_length") else None
                    ),
                    "max_width": (
                        float(row["max_width"]) if row.get("max_width") else None
                    ),
                    "max_height": (
                        float(row["max_height"]) if row.get("max_height") else None
                    ),
                    "weight_unit": "KG",
                    "dimension_unit": "CM",
                    "domicile": row.get("domicile", "").lower() == "true",
                    "international": (
                        True if row.get("international", "").lower() == "true" else None
                    ),
                    "zones": [],
                }
            else:
                # Update service-level weight bounds to cover all zones
                current = services_dict[karrio_service_code]
                if row_min_weight is not None:
                    if current["min_weight"] is None or row_min_weight < current["min_weight"]:
                        current["min_weight"] = row_min_weight
                if row_max_weight is not None:
                    if current["max_weight"] is None or row_max_weight > current["max_weight"]:
                        current["max_weight"] = row_max_weight

            # Parse country codes
            country_codes = [
                c.strip() for c in row.get("country_codes", "").split(",") if c.strip()
            ]

            # Create zone
            zone = models.ServiceZone(
                label=row.get("zone_label", "Default Zone"),
                rate=float(row.get("rate", 0.0)),
                min_weight=row_min_weight,
                max_weight=row_max_weight,
                transit_days=(
                    int(row["transit_days"].split("-")[0]) if row.get("transit_days") else None
                ),
                country_codes=country_codes if country_codes else None,
            )

            services_dict[karrio_service_code]["zones"].append(zone)

    # Convert to ServiceLevel objects
    return [
        models.ServiceLevel(**service_data) for service_data in services_dict.values()
    ]


DEFAULT_SERVICES = load_services_from_csv()
