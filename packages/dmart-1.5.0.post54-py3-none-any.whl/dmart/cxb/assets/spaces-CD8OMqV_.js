import{w as s}from"./svelte-_VJvNMIn.js";const o=s(null);export{o as s};
