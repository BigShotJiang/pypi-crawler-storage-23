/**
 * Generic notification scheduling service that can be used by any plugin
 * Provides scheduling, validation, and lifecycle management for notifications
 */

/* eslint-disable no-console */

import { NotificationConfig, ScheduledNotification, ValidationResult } from '../types/notifications';

export class NotificationService {
  private scheduledNotifications: Map<string, ScheduledNotification> = new Map();

  /**
   * Schedule a notification to be shown at a specific time
   * @param config Notification configuration
   * @returns The notification ID
   */
  scheduleNotification(config: NotificationConfig): string {
    // Cancel existing notification with same ID if it exists
    if (this.scheduledNotifications.has(config.id)) {
      this.cancelNotification(config.id);
    }

    const delay = config.triggerAt - Date.now();

    if (delay <= 0) {
      console.warn(`NotificationService: Notification ${config.id} scheduled for past time, not scheduling`);
      return config.id;
    }

    const timeoutId = window.setTimeout(() => {
      this.handleNotificationTrigger(config).catch((error) => {
        console.error(`NotificationService: Unhandled error in notification ${config.id}:`, error);
      });
    }, delay);

    this.scheduledNotifications.set(config.id, {
      config,
      timeoutId,
    });

    console.log(
      `NotificationService: Scheduled notification ${config.id} to trigger in ${Math.round(delay / 1000)} seconds`,
    );

    return config.id;
  }

  /**
   * Cancel a scheduled notification
   * @param id Notification ID to cancel
   */
  cancelNotification(id: string): boolean {
    const scheduled = this.scheduledNotifications.get(id);
    if (!scheduled) {
      return false;
    }

    window.clearTimeout(scheduled.timeoutId);
    this.scheduledNotifications.delete(id);

    if (scheduled.config.onCancel) {
      scheduled.config.onCancel();
    }

    console.log(`NotificationService: Cancelled notification ${id}`);
    return true;
  }

  /**
   * Cancel all scheduled notifications
   */
  cancelAll(): void {
    const ids = Array.from(this.scheduledNotifications.keys());
    ids.forEach((id) => this.cancelNotification(id));
    console.log(`NotificationService: Cancelled all ${ids.length} notifications`);
  }

  /**
   * Get all currently scheduled notification IDs
   */
  getScheduledIds(): string[] {
    return Array.from(this.scheduledNotifications.keys());
  }

  /**
   * Check if a notification is currently scheduled
   */
  isScheduled(id: string): boolean {
    return this.scheduledNotifications.has(id);
  }

  /**
   * Get the configuration for a scheduled notification
   */
  getConfig(id: string): NotificationConfig | undefined {
    return this.scheduledNotifications.get(id)?.config;
  }

  /**
   * Handle notification trigger - validate and show if appropriate
   */
  private async handleNotificationTrigger(config: NotificationConfig): Promise<void> {
    try {
      // Remove from scheduled map since it's now triggered
      this.scheduledNotifications.delete(config.id);

      // Run validator if provided
      if (config.validator) {
        const result: ValidationResult = await config.validator();

        if (result.shouldReschedule) {
          console.log(`NotificationService: Notification ${config.id} requires rescheduling`, result.message);
          if (config.onReschedule && result.newData) {
            config.onReschedule(result.newData);
          }
          return;
        }

        if (!result.shouldNotify) {
          console.log(`NotificationService: Notification ${config.id} cancelled by validator`, result.message);
          return;
        }
      }

      // Show notification
      console.log(`NotificationService: Showing notification ${config.id}`);
      await config.renderer(config.data);
    } catch (error) {
      console.error(`NotificationService: Error handling notification ${config.id}:`, error);
    }
  }

  /**
   * Get count of scheduled notifications
   */
  getScheduledCount(): number {
    return this.scheduledNotifications.size;
  }

  /**
   * Dispose of the service and cancel all notifications
   */
  dispose(): void {
    this.cancelAll();
  }
}
