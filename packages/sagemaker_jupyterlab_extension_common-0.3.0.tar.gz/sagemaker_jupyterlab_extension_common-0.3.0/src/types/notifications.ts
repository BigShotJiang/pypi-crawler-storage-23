/**
 * Shared notification types for extensible notification system
 * These interfaces can be used by any plugin that needs to schedule notifications
 */

/**
 * Result of a validation check before showing a notification
 */
export interface ValidationResult {
  /** Whether the notification should be shown */
  shouldNotify: boolean;
  /** If true, reschedule all notifications with new data */
  shouldReschedule: boolean;
  /** New data to use for rescheduling (if shouldReschedule is true) */
  newData?: any;
  /** Optional message explaining the validation result */
  message?: string;
}

/**
 * Configuration for scheduling a notification
 */
export interface NotificationConfig<T = any> {
  /** Unique identifier for this notification */
  id: string;
  /** Unix timestamp (ms) when notification should trigger */
  triggerAt: number;
  /** Type of notification to display */
  type: 'toast' | 'modal' | 'custom';
  /** Optional validator function called before showing notification */
  validator?: () => Promise<ValidationResult>;
  /** Function to render the notification */
  renderer: (data?: T) => void | Promise<void>;
  /** Optional callback when notification is rescheduled */
  onReschedule?: (newTime: number) => void;
  /** Optional callback when notification is cancelled */
  onCancel?: () => void;
  /** Optional custom data associated with this notification */
  data?: T;
}

/**
 * Information about a scheduled notification
 */
export interface ScheduledNotification {
  config: NotificationConfig;
  timeoutId: number;
}

/**
 * Custom renderer interface for notification types
 */
export interface NotificationRenderer<T = any> {
  render: (data?: T) => void | Promise<void>;
  cleanup?: () => void;
}

export type NotificationType = 'toast' | 'modal' | 'custom';
