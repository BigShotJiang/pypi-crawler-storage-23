import { JupyterFrontEnd } from '@jupyterlab/application';
import { showDialog } from '@jupyterlab/apputils';
import { CapacityBlockNotificationManager } from '../CapacityBlockNotificationManager';
import * as utils from '../utils';
import { MAX_SAFE_TIMEOUT_MS, LONG_DELAY_CHECK_INTERVAL_MS } from '../constants';
import { ILogger } from '../../LoggerPlugin';

// Mock showDialog from @jupyterlab/apputils
jest.mock('@jupyterlab/apputils', () => ({
  ...jest.requireActual('@jupyterlab/apputils'),
  showDialog: jest.fn(),
}));

// Only mock fetchCapacityBlockEndTime and isCapacityBlockNotificationsEnabled, keep other utils functions real
jest.mock('../utils', () => ({
  ...jest.requireActual('../utils'),
  fetchCapacityBlockEndTime: jest.fn(),
  isCapacityBlockNotificationsEnabled: jest.fn(),
}));

// Mock Date.now at the global level
const MOCK_NOW = 1704067200000; // 2024-01-01T00:00:00.000Z

describe('CapacityBlockNotificationManager', () => {
  let manager: CapacityBlockNotificationManager;
  let mockApp: JupyterFrontEnd;
  let mockLogger: ILogger;

  beforeEach(() => {
    // Use modern fake timers and set system time FIRST
    jest.useFakeTimers({ now: MOCK_NOW });

    // Mock showDialog to resolve immediately
    (showDialog as jest.Mock).mockResolvedValue({ button: { accept: false } });

    // Default: feature flag enabled
    (utils.isCapacityBlockNotificationsEnabled as jest.Mock).mockResolvedValue(true);

    mockApp = {} as JupyterFrontEnd;

    // Create mock logger
    mockLogger = {
      fatal: jest.fn().mockResolvedValue(undefined),
      error: jest.fn().mockResolvedValue(undefined),
      warn: jest.fn().mockResolvedValue(undefined),
      info: jest.fn().mockResolvedValue(undefined),
      debug: jest.fn().mockResolvedValue(undefined),
      trace: jest.fn().mockResolvedValue(undefined),
      child: jest.fn().mockReturnThis(),
    } as unknown as ILogger;

    manager = new CapacityBlockNotificationManager(mockApp, mockLogger);
  });

  afterEach(() => {
    manager.dispose();
    jest.useRealTimers();
    jest.clearAllMocks();
  });

  describe('initialize', () => {
    // Tier 1: Feature flag disabled
    it('should not schedule notifications when feature flag is disabled', async () => {
      (utils.isCapacityBlockNotificationsEnabled as jest.Mock).mockResolvedValue(false);
      const endTime = MOCK_NOW + 2 * 60 * 60 * 1000; // 2 hours
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(endTime);

      await manager.initialize();

      const state = manager.getState();
      expect(state.isActive).toBe(false);
      expect(state.scheduledIds.length).toBe(0);
      expect(mockLogger.info).toHaveBeenCalledWith({
        Message: 'Capacity block notifications disabled via feature flag',
      });
    });

    // Tier 1: Feature flag enabled
    it('should schedule notifications when feature flag is enabled', async () => {
      (utils.isCapacityBlockNotificationsEnabled as jest.Mock).mockResolvedValue(true);
      const endTime = MOCK_NOW + 2 * 60 * 60 * 1000; // 2 hours
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(endTime);

      await manager.initialize();

      const state = manager.getState();
      expect(state.isActive).toBe(true);
      expect(state.scheduledIds.length).toBe(3);
    });

    // Tier 1: Notification timing - expires in 2 hours
    it('should schedule all notifications when CB expires in 2 hours', async () => {
      const endTime = MOCK_NOW + 2 * 60 * 60 * 1000; // 2 hours
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(endTime);

      await manager.initialize();

      const state = manager.getState();
      expect(state.isActive).toBe(true);
      expect(state.originalEndTime).toBe(endTime);
      expect(state.scheduledIds.length).toBe(3); // 30min, 10min, 2min
      expect(state.scheduledIds).toContain('capacity-block-30min');
      expect(state.scheduledIds).toContain('capacity-block-10min');
      expect(state.scheduledIds).toContain('capacity-block-2min');
    });

    // Tier 1: Notification timing - expires in 55 minutes (shutdown in 25 minutes)
    it('should only schedule 10min and 2min notifications when shutdown starts in 25 minutes', async () => {
      // CB ends in 55 minutes, shutdown starts in 25 minutes (55 - 30)
      const endTime = MOCK_NOW + 55 * 60 * 1000;
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(endTime);

      await manager.initialize();

      const state = manager.getState();
      expect(state.isActive).toBe(true);
      expect(state.scheduledIds.length).toBe(2); // Only 10min and 2min
      expect(state.scheduledIds).not.toContain('capacity-block-30min');
      expect(state.scheduledIds).toContain('capacity-block-10min');
      expect(state.scheduledIds).toContain('capacity-block-2min');
    });

    // Tier 1: No CB configured
    it('should not schedule notifications when no capacity block is configured', async () => {
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(null);

      await manager.initialize();

      const state = manager.getState();
      expect(state.isActive).toBe(false);
      expect(state.scheduledIds.length).toBe(0);
    });

    // Tier 1: 24-day boundary - within range
    it('should schedule notifications when CB is within 24 days', async () => {
      const endTime = MOCK_NOW + 10 * 24 * 60 * 60 * 1000; // 10 days
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(endTime);

      await manager.initialize();

      const state = manager.getState();
      expect(state.isActive).toBe(true);
      expect(state.originalEndTime).toBe(endTime);
      expect(state.scheduledIds.length).toBe(3);
    });

    // Tier 1: 24-day boundary - exactly at limit
    it('should schedule notifications when CB is exactly 24 days away', async () => {
      const endTime = MOCK_NOW + MAX_SAFE_TIMEOUT_MS;
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(endTime);

      await manager.initialize();

      const state = manager.getState();
      expect(state.isActive).toBe(true);
      expect(state.scheduledIds.length).toBeGreaterThan(0);
    });

    // Tier 1: 24-day boundary - beyond range
    it('should schedule 7-day check when CB is beyond 24 days', async () => {
      const endTime = MOCK_NOW + 60 * 24 * 60 * 60 * 1000; // 60 days
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(endTime);

      const setTimeoutSpy = jest.spyOn(window, 'setTimeout');

      await manager.initialize();

      const state = manager.getState();
      expect(state.isActive).toBe(true);
      expect(state.scheduledIds.length).toBe(0); // No immediate notifications
      expect(setTimeoutSpy).toHaveBeenCalledWith(expect.any(Function), LONG_DELAY_CHECK_INTERVAL_MS);
    });
  });

  describe('long delay check', () => {
    // Tier 2: Long delay check transitions to scheduling
    it('should schedule notifications after 7-day check when within range', async () => {
      const initialEndTime = MOCK_NOW + 60 * 24 * 60 * 60 * 1000; // 60 days
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(initialEndTime);

      await manager.initialize();

      // Advance time by 7 days
      jest.setSystemTime(new Date(MOCK_NOW + LONG_DELAY_CHECK_INTERVAL_MS));

      const futureNow = MOCK_NOW + LONG_DELAY_CHECK_INTERVAL_MS;
      const withinRangeEndTime = futureNow + 10 * 24 * 60 * 60 * 1000; // 10 days from future now
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(withinRangeEndTime);

      // Run all pending timers
      jest.runAllTimers();
      // Wait for async operations to complete
      await Promise.resolve();
      await Promise.resolve();

      const state = manager.getState();
      expect(state.scheduledIds.length).toBeGreaterThan(0);
    });

    // Tier 2: Long delay check schedules another check
    it('should schedule another 7-day check if still beyond range', async () => {
      const initialEndTime = MOCK_NOW + 60 * 24 * 60 * 60 * 1000; // 60 days
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(initialEndTime);

      await manager.initialize();

      const setTimeoutSpy = jest.spyOn(window, 'setTimeout');
      setTimeoutSpy.mockClear();

      // Advance time
      jest.advanceTimersByTime(LONG_DELAY_CHECK_INTERVAL_MS);
      jest.setSystemTime(new Date(MOCK_NOW + LONG_DELAY_CHECK_INTERVAL_MS));

      // Still beyond range after check
      const futureNow = MOCK_NOW + LONG_DELAY_CHECK_INTERVAL_MS;
      const stillFarEndTime = futureNow + 50 * 24 * 60 * 60 * 1000; // 50 days
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(stillFarEndTime);

      await Promise.resolve();

      // Should schedule another 7-day check
      expect(setTimeoutSpy).toHaveBeenCalledWith(expect.any(Function), LONG_DELAY_CHECK_INTERVAL_MS);
    });

    // Tier 2: Long delay check stops if CB no longer exists
    it('should stop checking if capacity block is no longer configured', async () => {
      const initialEndTime = MOCK_NOW + 60 * 24 * 60 * 60 * 1000;
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(initialEndTime);

      await manager.initialize();

      // No capacity block on check
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(null);

      jest.advanceTimersByTime(LONG_DELAY_CHECK_INTERVAL_MS);
      await Promise.resolve();

      const state = manager.getState();
      expect(state.isActive).toBe(false);
    });

    // Tier 2: Long delay check stops if CB expired
    it('should stop checking if capacity block has expired', async () => {
      const initialEndTime = MOCK_NOW + 60 * 24 * 60 * 60 * 1000;
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(initialEndTime);

      await manager.initialize();

      // Advance time
      jest.setSystemTime(new Date(MOCK_NOW + LONG_DELAY_CHECK_INTERVAL_MS));

      // CB expired
      const futureNow = MOCK_NOW + LONG_DELAY_CHECK_INTERVAL_MS;
      const expiredEndTime = futureNow - 1000; // 1 second ago
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(expiredEndTime);

      // Run all pending timers
      jest.runAllTimers();
      // Wait for async operations to complete
      await Promise.resolve();
      await Promise.resolve();

      const state = manager.getState();
      expect(state.isActive).toBe(false);
    });
  });

  describe('cancelAllNotifications', () => {
    // Tier 2: Cancellation
    it('should cancel all scheduled notifications', async () => {
      const endTime = MOCK_NOW + 2 * 60 * 60 * 1000;
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(endTime);

      await manager.initialize();
      expect(manager.getState().isActive).toBe(true);

      manager.cancelAllNotifications();

      const state = manager.getState();
      expect(state.isActive).toBe(false);
      expect(state.scheduledIds.length).toBe(0);
    });

    it('should cancel long delay check if exists', async () => {
      const endTime = MOCK_NOW + 60 * 24 * 60 * 60 * 1000;
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(endTime);

      await manager.initialize();

      const clearTimeoutSpy = jest.spyOn(window, 'clearTimeout');

      manager.cancelAllNotifications();

      expect(clearTimeoutSpy).toHaveBeenCalled();
      expect(manager.getState().isActive).toBe(false);
    });
  });

  describe('dispose', () => {
    // Tier 2: Dispose
    it('should clean up all resources', async () => {
      const endTime = MOCK_NOW + 2 * 60 * 60 * 1000;
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(endTime);

      await manager.initialize();

      manager.dispose();

      const state = manager.getState();
      expect(state.isActive).toBe(false);
    });

    it('should clear long delay check on dispose', async () => {
      const endTime = MOCK_NOW + 60 * 24 * 60 * 60 * 1000;
      (utils.fetchCapacityBlockEndTime as jest.Mock).mockResolvedValue(endTime);

      await manager.initialize();

      const clearTimeoutSpy = jest.spyOn(window, 'clearTimeout');

      manager.dispose();

      expect(clearTimeoutSpy).toHaveBeenCalled();
    });
  });
});
