import { fetchCapacityBlockEndTime, calculateDelay, formatMinutes } from '../utils';
import { EC2_SHUTDOWN_OFFSET_MINUTES } from '../constants';
import { ServerConnection } from '@jupyterlab/services';
import { URLExt } from '@jupyterlab/coreutils';
import { ILogger } from '../LoggerPlugin';

// Mock the JupyterLab modules
jest.mock('@jupyterlab/services');
jest.mock('@jupyterlab/coreutils');

describe('CapacityBlock Utils', () => {
  let mockLogger: ILogger;

  beforeEach(() => {
    // Create mock logger
    mockLogger = {
      fatal: jest.fn().mockResolvedValue(undefined),
      error: jest.fn().mockResolvedValue(undefined),
      warn: jest.fn().mockResolvedValue(undefined),
      info: jest.fn().mockResolvedValue(undefined),
      debug: jest.fn().mockResolvedValue(undefined),
      trace: jest.fn().mockResolvedValue(undefined),
      child: jest.fn().mockReturnThis(),
    } as unknown as ILogger;
  });

  describe('fetchCapacityBlockEndTime', () => {
    beforeEach(() => {
      global.fetch = jest.fn();
      jest.clearAllTimers();

      // Mock ServerConnection.makeSettings to return a base URL
      (ServerConnection.makeSettings as jest.Mock).mockReturnValue({
        baseUrl: 'http://localhost:8888/',
      });

      // Mock URLExt.join to concatenate URLs
      (URLExt.join as jest.Mock).mockImplementation((base: string, path: string) => {
        return base + path.replace(/^\//, '');
      });
    });

    afterEach(() => {
      jest.restoreAllMocks();
    });

    // Tier 1: Different timestamp formats
    it('should convert Unix timestamp in seconds to milliseconds', async () => {
      const mockEndTime = 1735689600; // seconds
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: async () => ({ capacityBlockEndTime: mockEndTime }),
      });

      const result = await fetchCapacityBlockEndTime(mockLogger);

      expect(result).toBe(mockEndTime * 1000); // Converted to ms
    });

    it('should handle ISO 8601 date strings', async () => {
      const isoDate = '2024-12-31T23:59:59Z';
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: async () => ({ capacityBlockEndTime: isoDate }),
      });

      const result = await fetchCapacityBlockEndTime(mockLogger);

      expect(result).toBe(Date.parse(isoDate));
    });

    it('should return null for invalid date format', async () => {
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: async () => ({ capacityBlockEndTime: 'invalid-date' }),
      });

      const result = await fetchCapacityBlockEndTime(mockLogger);

      expect(result).toBeNull();
    });

    it('should return null when capacityBlockEndTime is null', async () => {
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: true,
        json: async () => ({ capacityBlockEndTime: null }),
      });

      const result = await fetchCapacityBlockEndTime(mockLogger);

      expect(result).toBeNull();
    });

    // Tier 1: API errors return null
    it('should return null when API returns 404', async () => {
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 404,
      });

      const result = await fetchCapacityBlockEndTime(mockLogger);

      expect(result).toBeNull();
    });

    it('should return null when API returns 500', async () => {
      (global.fetch as jest.Mock).mockResolvedValue({
        ok: false,
        status: 500,
      });

      const result = await fetchCapacityBlockEndTime(mockLogger);

      expect(result).toBeNull();
    });

    it('should return null when network error occurs', async () => {
      (global.fetch as jest.Mock).mockRejectedValue(new Error('Network error'));

      const result = await fetchCapacityBlockEndTime(mockLogger);

      expect(result).toBeNull();
    });

    // Tier 2: API timeout
    it('should timeout after 5 seconds', async () => {
      jest.useRealTimers(); // Use real timers for this test

      const abortError = new Error('Aborted');
      abortError.name = 'AbortError';

      (global.fetch as jest.Mock).mockImplementation(
        () =>
          new Promise((_, reject) => {
            setTimeout(() => reject(abortError), 100);
          }),
      );

      const result = await fetchCapacityBlockEndTime(mockLogger);

      expect(result).toBeNull();
    }, 10000); // Increase test timeout
  });

  describe('calculateDelay', () => {
    // Tier 1: Delay calculation with EC2 shutdown offset
    it('should calculate correct delay accounting for 30-minute EC2 shutdown offset', () => {
      const endTime = Date.now() + 60 * 60 * 1000; // 1 hour from now
      const minutesBefore = 30;

      const delay = calculateDelay(endTime, minutesBefore);

      // Shutdown starts 30 minutes before endTime, so notification is at endTime - 30min - 30min = 0
      expect(delay).toBe(0);
    });

    it('should calculate delay correctly when CB expires in 2 hours', () => {
      const endTime = Date.now() + 2 * 60 * 60 * 1000; // 2 hours from now
      const minutesBefore = 30;

      const delay = calculateDelay(endTime, minutesBefore);

      // Shutdown at 1.5 hours, notification at 1 hour = 60 minutes
      expect(delay).toBe(60 * 60 * 1000);
    });

    it('should return 0 for end time in the past', () => {
      const endTime = Date.now() - 60 * 60 * 1000; // 1 hour ago
      const minutesBefore = 30;

      const delay = calculateDelay(endTime, minutesBefore);

      expect(delay).toBe(0);
    });

    it('should return 0 when notification time has already passed', () => {
      const endTime = Date.now() + 35 * 60 * 1000; // 35 minutes from now
      const minutesBefore = 30; // Want to notify 30 minutes before shutdown

      const delay = calculateDelay(endTime, minutesBefore);

      // Shutdown at 5 minutes from now, notification would be 25 minutes ago
      expect(delay).toBe(0);
    });

    it('should handle exact boundary case with shutdown offset', () => {
      const endTime = Date.now() + (EC2_SHUTDOWN_OFFSET_MINUTES + 30) * 60 * 1000; // 60 minutes from now
      const minutesBefore = 30;

      const delay = calculateDelay(endTime, minutesBefore);

      // Shutdown at 30 minutes from now, notification at 0 minutes from now
      expect(delay).toBeLessThanOrEqual(100); // Should be very close to 0 (within 100ms)
    });

    it('should calculate 10-minute notification correctly', () => {
      const endTime = Date.now() + 60 * 60 * 1000; // 1 hour from now
      const minutesBefore = 10;

      const delay = calculateDelay(endTime, minutesBefore);

      // Shutdown at 30 minutes from now, 10-minute notification at 20 minutes from now
      expect(delay).toBe(20 * 60 * 1000);
    });

    it('should calculate 2-minute notification correctly', () => {
      const endTime = Date.now() + 60 * 60 * 1000; // 1 hour from now
      const minutesBefore = 2;

      const delay = calculateDelay(endTime, minutesBefore);

      // Shutdown at 30 minutes from now, 2-minute notification at 28 minutes from now
      expect(delay).toBe(28 * 60 * 1000);
    });
  });

  describe('formatMinutes', () => {
    // Tier 2: Format utilities
    it('should format zero minutes', () => {
      expect(formatMinutes(0)).toBe('0 minutes');
    });

    it('should format singular minute', () => {
      expect(formatMinutes(1)).toBe('1 minute');
    });

    it('should format plural minutes', () => {
      expect(formatMinutes(30)).toBe('30 minutes');
    });

    it('should format two minutes', () => {
      expect(formatMinutes(2)).toBe('2 minutes');
    });
  });
});
