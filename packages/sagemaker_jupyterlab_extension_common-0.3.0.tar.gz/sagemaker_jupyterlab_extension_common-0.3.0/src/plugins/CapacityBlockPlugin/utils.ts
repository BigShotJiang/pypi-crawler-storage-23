/**
 * Utility functions for Capacity Block Plugin
 */

import { ServerConnection } from '@jupyterlab/services';
import { URLExt } from '@jupyterlab/coreutils';
import { CB_METADATA_ENDPOINT, EC2_SHUTDOWN_OFFSET_MINUTES, API_REQUEST_TIMEOUT_MS, MS_PER_MINUTE } from './constants';
import { CapacityBlockMetadata } from './types';
import { ILogger } from '../LoggerPlugin';

/**
 * Fetch capacity block metadata from backend API
 * @param logger Logger instance for logging
 * @returns Capacity block metadata including end time and feature flag status
 */
async function fetchCapacityBlockMetadata(logger: ILogger): Promise<CapacityBlockMetadata | null> {
  try {
    // Add timeout to prevent hanging
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), API_REQUEST_TIMEOUT_MS);

    // Construct proper URL with base URL
    const serverSettings = ServerConnection.makeSettings({});
    const requestUrl = URLExt.join(serverSettings.baseUrl, CB_METADATA_ENDPOINT);

    const response = await fetch(requestUrl, {
      method: 'GET',
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      return null;
    }

    const data: CapacityBlockMetadata = await response.json();
    return data;
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      logger.warn({ Message: 'API request timed out' });
    }
    return null;
  }
}

/**
 * Check if capacity block notifications are enabled via feature flag
 * @param logger Logger instance for logging
 * @returns True if notifications are enabled, false otherwise (default: false)
 */
export async function isCapacityBlockNotificationsEnabled(logger: ILogger): Promise<boolean> {
  try {
    const metadata = await fetchCapacityBlockMetadata(logger);

    if (!metadata) {
      // If we can't fetch metadata, default to disabled for safety
      return false;
    }

    // Default to false (disabled) if the field is not present
    return metadata.notificationsEnabled === true;
  } catch (error) {
    logger.error({ Message: 'Error checking notification feature flag', Error: error as Error });
    // Default to disabled on error for safety
    return false;
  }
}

/**
 * Fetch capacity block end time from backend API
 * @param logger Logger instance for logging
 * @returns Unix timestamp (ms) of capacity block end time, or null if not available
 */
export async function fetchCapacityBlockEndTime(logger: ILogger): Promise<number | null> {
  try {
    const data = await fetchCapacityBlockMetadata(logger);

    if (!data || !data.capacityBlockEndTime) {
      return null;
    }

    // Support both Unix timestamp (number) and ISO 8601 string
    let endTime: number;
    if (typeof data.capacityBlockEndTime === 'number') {
      // Unix timestamp in seconds - convert to milliseconds
      endTime = data.capacityBlockEndTime * 1000;
    } else {
      // ISO 8601 string
      endTime = Date.parse(data.capacityBlockEndTime);
      if (isNaN(endTime)) {
        logger.error({
          Message: `Invalid end time format: ${data.capacityBlockEndTime}`,
        });
        return null;
      }
    }

    return endTime;
  } catch (error) {
    logger.error({ Message: 'Error fetching capacity block end time', Error: error as Error });
    return null;
  }
}

/**
 * Format minutes into a human-readable string
 * @param minutes Number of minutes
 * @returns Formatted string like "30 minutes" or "2 minutes"
 */
export function formatMinutes(minutes: number): string {
  return `${minutes} minute${minutes !== 1 ? 's' : ''}`;
}

/**
 * Format a timestamp into a readable date/time string
 * @param timestamp Unix timestamp in milliseconds
 * @returns Formatted date/time string
 */
export function formatTimestamp(timestamp: number): string {
  return new Date(timestamp).toLocaleString();
}

/**
 * Calculate the delay in milliseconds until a notification should be shown
 * Accounts for the EC2 shutdown offset - shutdown starts 30 minutes before CB end time
 * @param endTime Capacity block end time (Unix timestamp ms)
 * @param minutesBefore Minutes before shutdown start time to show notification
 * @returns Delay in milliseconds, or 0 if notification time has passed
 */
export function calculateDelay(endTime: number, minutesBefore: number): number {
  const now = Date.now();
  // EC2 shutdown starts 30 minutes before CB end time
  const shutdownStartTime = endTime - EC2_SHUTDOWN_OFFSET_MINUTES * MS_PER_MINUTE;
  const notificationTime = shutdownStartTime - minutesBefore * MS_PER_MINUTE;
  const delay = notificationTime - now;
  return Math.max(0, delay);
}

/**
 * Calculate the EC2 shutdown start time
 * @param cbEndTime Capacity block end time (Unix timestamp ms)
 * @returns Shutdown start time (Unix timestamp ms)
 */
export function calculateShutdownStartTime(cbEndTime: number): number {
  return cbEndTime - EC2_SHUTDOWN_OFFSET_MINUTES * MS_PER_MINUTE;
}

/**
 * Calculate the expected notification time relative to shutdown start
 * @param cbEndTime Capacity block end time (Unix timestamp ms)
 * @param minutesBefore Minutes before shutdown start time
 * @returns Expected notification time (Unix timestamp ms)
 */
export function calculateExpectedNotificationTime(cbEndTime: number, minutesBefore: number): number {
  const shutdownStartTime = calculateShutdownStartTime(cbEndTime);
  return shutdownStartTime - minutesBefore * MS_PER_MINUTE;
}

/**
 * Check if current time is within tolerance window of expected notification time
 * @param expectedTime Expected notification time (Unix timestamp ms)
 * @param toleranceMs Tolerance window in milliseconds (default from constants)
 * @returns True if within tolerance window
 */
export function isWithinToleranceWindow(expectedTime: number, toleranceMs: number): boolean {
  const now = Date.now();
  const timeDiff = Math.abs(now - expectedTime);
  return timeDiff <= toleranceMs;
}

/**
 * Check if the capacity block end time has been extended beyond threshold
 * @param originalEndTime Original CB end time (Unix timestamp ms)
 * @param currentEndTime Current CB end time (Unix timestamp ms)
 * @param thresholdMs Extension threshold in milliseconds
 * @returns True if extended beyond threshold
 */
export function isExtendedBeyondThreshold(
  originalEndTime: number,
  currentEndTime: number,
  thresholdMs: number,
): boolean {
  const timeDiff = Math.abs(currentEndTime - originalEndTime);
  return timeDiff > thresholdMs;
}
