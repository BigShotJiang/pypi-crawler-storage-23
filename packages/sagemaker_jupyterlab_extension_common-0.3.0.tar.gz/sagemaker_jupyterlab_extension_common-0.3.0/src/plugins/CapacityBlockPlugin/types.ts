/**
 * Type definitions for Capacity Block Plugin
 */

/**
 * Response from capacity block metadata API
 */
export interface CapacityBlockMetadata {
  /** Capacity block end time: ISO 8601 string or Unix timestamp (seconds), or null if not available */
  capacityBlockEndTime: string | number | null;
  /** Whether capacity block notifications are enabled via feature flag */
  notificationsEnabled?: boolean;
}

/**
 * Notification timing configuration
 */
export interface NotificationTiming {
  /** Minutes before expiration to show notification */
  minutes: number;
  /** Type of notification to display */
  type: 'toast' | 'modal';
}

/**
 * Internal state for tracking scheduled notifications
 */
export interface CapacityBlockNotificationState {
  /** Original end time used for scheduling (Unix timestamp ms) */
  originalEndTime: number;
  /** IDs of currently scheduled notifications */
  scheduledIds: string[];
  /** Whether notifications are currently active */
  isActive: boolean;
}
