/**
 * Manages capacity block expiration notifications with smart validation and rescheduling
 */

import { JupyterFrontEnd } from '@jupyterlab/application';
import { Notification, showDialog, Dialog } from '@jupyterlab/apputils';
import { NotificationService } from '../../services/notificationService';
import { ValidationResult } from '../../types/notifications';
import {
  NOTIFICATION_TIMINGS,
  EXTENSION_THRESHOLD_MS,
  TOLERANCE_MS,
  MIN_SCHEDULE_TIME_MS,
  MAX_SAFE_TIMEOUT_MS,
  LONG_DELAY_CHECK_INTERVAL_MS,
  MS_PER_MINUTE,
  MS_PER_DAY,
} from './constants';
import { CapacityBlockNotificationState } from './types';
import {
  fetchCapacityBlockEndTime,
  isCapacityBlockNotificationsEnabled,
  formatMinutes,
  calculateDelay,
  calculateShutdownStartTime,
  calculateExpectedNotificationTime,
  isWithinToleranceWindow,
  isExtendedBeyondThreshold,
} from './utils';
import { ILogger } from '../LoggerPlugin';

export class CapacityBlockNotificationManager {
  private notificationService: NotificationService;
  private app: JupyterFrontEnd;
  private logger: ILogger;
  private state: CapacityBlockNotificationState = {
    originalEndTime: 0,
    scheduledIds: [],
    isActive: false,
  };
  private longDelayCheckTimeoutId: number | null = null;

  constructor(app: JupyterFrontEnd, logger: ILogger) {
    this.app = app;
    this.logger = logger;
    this.notificationService = new NotificationService();
  }

  /**
   * Initialize the notification manager
   * Fetches capacity block end time and schedules notifications if available
   */
  async initialize(): Promise<void> {
    try {
      // Check if notifications are enabled via feature flag
      const notificationsEnabled = await isCapacityBlockNotificationsEnabled(this.logger);

      if (!notificationsEnabled) {
        this.logger.info({ Message: 'Capacity block notifications disabled via feature flag' });
        return;
      }

      const endTime = await fetchCapacityBlockEndTime(this.logger);

      if (!endTime) {
        this.logger.info({ Message: 'No capacity block configured' });
        return;
      }

      await this.scheduleAllNotifications(endTime);
    } catch (error) {
      this.logger.error({ Message: 'Error initializing notifications', Error: error as Error });
    }
  }

  /**
   * Schedule all capacity block notifications
   * Handles both short-term (within 24 days) and long-term capacity blocks
   * @param endTime Unix timestamp (ms) of capacity block end time
   */
  async scheduleAllNotifications(endTime: number): Promise<void> {
    // Cancel any existing notifications and checks
    this.cancelAllNotifications();

    this.state.originalEndTime = endTime;
    this.state.isActive = true;
    this.state.scheduledIds = [];

    const timeUntilExpiry = endTime - Date.now();

    // Check if CB end time is beyond the safe setTimeout threshold
    if (timeUntilExpiry > MAX_SAFE_TIMEOUT_MS) {
      this.logger.info({
        Message: `Capacity block expires in ${Math.round(
          timeUntilExpiry / MS_PER_DAY,
        )} days, scheduling periodic check`,
      });
      this.scheduleLongDelayCheck(endTime);
      return;
    }

    // Calculate time until shutdown starts (30 minutes before CB end)
    const shutdownStartTime = calculateShutdownStartTime(endTime);
    const timeUntilShutdown = shutdownStartTime - Date.now();

    // If we're already within 2 minutes of shutdown, show modal immediately
    if (timeUntilShutdown <= 2 * MS_PER_MINUTE && timeUntilShutdown > 0) {
      this.logger.info({ Message: 'App opened with less than 2 minutes remaining, showing modal immediately' });
      await this.showNotification(2, 'modal');
      // Still mark as active so state is tracked
      return;
    }

    // Within safe range - schedule notifications normally
    for (const timing of NOTIFICATION_TIMINGS) {
      const delay = calculateDelay(endTime, timing.minutes);

      if (delay > 0) {
        const id = `capacity-block-${timing.minutes}min`;
        const triggerAt = Date.now() + delay;

        this.notificationService.scheduleNotification({
          id,
          triggerAt,
          type: timing.type,
          validator: () => this.validateAndDecide(endTime, timing.minutes),
          renderer: () => this.showNotification(timing.minutes, timing.type),
          onReschedule: (newEndTime: number) => {
            this.logger.info({ Message: 'Capacity block extended, rescheduling notifications' });
            this.scheduleAllNotifications(newEndTime);
          },
        });

        this.state.scheduledIds.push(id);
      }
    }

    this.logger.info({ Message: `Scheduled ${this.state.scheduledIds.length} notifications` });
  }

  /**
   * Schedule a periodic check for long-delayed capacity blocks
   * Checks every 7 days if the CB end time is within the safe setTimeout range
   * @param endTime Unix timestamp (ms) of capacity block end time
   */
  private scheduleLongDelayCheck(endTime: number): void {
    // Clear any existing check
    if (this.longDelayCheckTimeoutId !== null) {
      window.clearTimeout(this.longDelayCheckTimeoutId);
      this.longDelayCheckTimeoutId = null;
    }

    this.longDelayCheckTimeoutId = window.setTimeout(async () => {
      this.logger.debug({ Message: 'Running 7-day check for long-delayed CB' });

      try {
        // Fetch current end time in case it changed
        const currentEndTime = await fetchCapacityBlockEndTime(this.logger);

        if (!currentEndTime) {
          this.logger.info({ Message: 'Capacity block no longer configured' });
          this.cancelAllNotifications();
          return;
        }

        // Calculate shutdown start time (30 minutes before CB end time)
        const shutdownStartTime = calculateShutdownStartTime(currentEndTime);
        const timeUntilShutdown = shutdownStartTime - Date.now();

        if (timeUntilShutdown <= MIN_SCHEDULE_TIME_MS) {
          this.logger.info({ Message: 'Shutdown imminent' });
          this.cancelAllNotifications();
          return;
        }

        // Check if we're now within the safe range (use CB end time for this check)
        const timeUntilExpiry = currentEndTime - Date.now();
        if (timeUntilExpiry <= MAX_SAFE_TIMEOUT_MS) {
          this.logger.info({ Message: 'Within safe range, scheduling notifications' });
          await this.scheduleAllNotifications(currentEndTime);
        } else {
          // Still too far out, schedule another check
          this.scheduleLongDelayCheck(currentEndTime);
        }
      } catch (error) {
        this.logger.error({ Message: 'Error during periodic check', Error: error as Error });
        // On error, schedule another check to retry
        this.scheduleLongDelayCheck(endTime);
      }
    }, LONG_DELAY_CHECK_INTERVAL_MS);
  }

  /**
   * Validate whether notification should be shown and decide on rescheduling
   * Implements the smart validation logic with extension detection
   */
  private async validateAndDecide(originalEndTime: number, targetMinutes: number): Promise<ValidationResult> {
    try {
      const currentEndTime = await fetchCapacityBlockEndTime(this.logger);

      // If we can't fetch current end time, proceed with notification using original time
      if (!currentEndTime) {
        this.logger.warn({ Message: 'Could not fetch current end time, showing notification anyway' });
        return {
          shouldNotify: true,
          shouldReschedule: false,
          message: 'Unable to validate, proceeding with notification',
        };
      }

      // Check if capacity block was extended (difference > 5 minutes)
      if (isExtendedBeyondThreshold(originalEndTime, currentEndTime, EXTENSION_THRESHOLD_MS)) {
        this.logger.info({
          Message: `Capacity block extended by ${Math.round(
            Math.abs(currentEndTime - originalEndTime) / MS_PER_MINUTE,
          )} minutes`,
        });
        return {
          shouldNotify: false,
          shouldReschedule: true,
          newData: currentEndTime,
          message: 'Capacity block extended',
        };
      }

      // Within threshold - check tolerance
      const expectedNotificationTime = calculateExpectedNotificationTime(originalEndTime, targetMinutes);

      if (isWithinToleranceWindow(expectedNotificationTime, TOLERANCE_MS)) {
        return {
          shouldNotify: true,
          shouldReschedule: false,
          message: 'Within tolerance window',
        };
      }

      return {
        shouldNotify: false,
        shouldReschedule: false,
        message: 'Outside tolerance window',
      };
    } catch (error) {
      this.logger.error({ Message: 'Error validating notification', Error: error as Error });
      // On error, show notification to be safe
      return {
        shouldNotify: true,
        shouldReschedule: false,
        message: 'Validation error, showing notification',
      };
    }
  }

  /**
   * Show notification to user
   */
  private async showNotification(minutes: number, type: 'toast' | 'modal'): Promise<void> {
    const toastMessage = `Compute Resources Expiring in less than ${formatMinutes(minutes)}.`;
    const modalMessage = `Your compute resources will terminate in less than ${formatMinutes(
      minutes,
    )}! Save your work immediately to prevent data loss`;

    if (type === 'toast') {
      this.showToastNotification(minutes, toastMessage);
    } else {
      await this.showModalNotification(minutes, modalMessage);
    }
  }

  /**
   * Show toast notification
   */
  private showToastNotification(minutes: number, message: string): void {
    Notification.warning(message, {
      autoClose: false,
      actions: [
        {
          label: 'Dismiss',
          caption: 'Close this notification',
          displayType: 'default',
          callback: () => {
            // Dismiss action - notification will close automatically
          },
        },
        {
          label: 'Save All',
          caption: 'Save all open documents',
          displayType: 'warn',
          callback: () => {
            this.app.commands.execute('docmanager:save-all').catch((error) => {
              this.logger.error({ Message: 'Error saving documents', Error: error as Error });
            });
          },
        },
      ],
    });
  }

  /**
   * Show modal dialog notification
   */
  private async showModalNotification(minutes: number, message: string): Promise<void> {
    const result = await showDialog({
      title: 'CRITICAL: Compute Resources Expiring',
      body: message,
      buttons: [Dialog.cancelButton({ label: 'Dismiss' }), Dialog.warnButton({ label: 'Save All' })],
    });

    if (result.button.accept) {
      try {
        await this.app.commands.execute('docmanager:save-all');
      } catch (error) {
        this.logger.error({ Message: 'Error saving documents', Error: error as Error });
      }
    }
  }

  /**
   * Cancel all scheduled notifications
   */
  cancelAllNotifications(): void {
    this.notificationService.cancelAll();
    this.state.scheduledIds = [];
    this.state.isActive = false;

    // Clear long delay check if it exists
    if (this.longDelayCheckTimeoutId !== null) {
      window.clearTimeout(this.longDelayCheckTimeoutId);
      this.longDelayCheckTimeoutId = null;
    }
  }

  /**
   * Get current notification state (for debugging/testing)
   */
  getState(): CapacityBlockNotificationState {
    return { ...this.state };
  }

  /**
   * Dispose of the manager and clean up resources
   */
  dispose(): void {
    // Clear long delay check
    if (this.longDelayCheckTimeoutId !== null) {
      window.clearTimeout(this.longDelayCheckTimeoutId);
      this.longDelayCheckTimeoutId = null;
    }

    this.notificationService.dispose();
    this.state.isActive = false;
    this.logger.info({ Message: 'Disposed notification manager' });
  }
}
