/**
 * JupyterLab plugin for Capacity Block expiration notifications
 */

import { JupyterFrontEnd, JupyterFrontEndPlugin } from '@jupyterlab/application';
import { CapacityBlockNotificationManager } from './CapacityBlockNotificationManager';
import { ILogger } from '../LoggerPlugin';
import { getLoggerForPlugin } from '../../constants';

/**
 * Plugin ID
 */
const PLUGIN_ID = '@amzn/sagemaker-jupyterlab-extension-common:capacity-block';

/**
 * Capacity Block Plugin
 * Provides automatic notifications before capacity block expiration
 */
const CapacityBlockPlugin: JupyterFrontEndPlugin<void> = {
  id: PLUGIN_ID,
  requires: [ILogger],
  autoStart: true,
  activate: async (app: JupyterFrontEnd, baseLogger: ILogger) => {
    const logger = getLoggerForPlugin(baseLogger, PLUGIN_ID);
    logger.info({ Message: 'CapacityBlock plugin activated' });

    // Initialize notification manager
    const notificationManager = new CapacityBlockNotificationManager(app, logger);
    await notificationManager.initialize();
  },
};

export default CapacityBlockPlugin;
