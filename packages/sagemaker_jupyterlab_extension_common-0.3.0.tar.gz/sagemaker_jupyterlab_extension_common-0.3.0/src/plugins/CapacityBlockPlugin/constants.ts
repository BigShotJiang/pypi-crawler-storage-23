/**
 * Constants for Capacity Block notifications
 */

/**
 * Feature Flag: CAPACITY_BLOCK_NOTIFICATIONS_ENABLED
 *
 * Environment variable to control whether capacity block notifications are enabled.
 * Set to "true", "1", or "yes" to enable notifications.
 * Default: "false" (disabled)
 *
 * Example usage in app container:
 *   CAPACITY_BLOCK_NOTIFICATIONS_ENABLED=true
 *
 * When disabled (default), the plugin will activate but immediately return without
 * scheduling any notifications, avoiding runtime plugin disabling/uninstalling.
 * This provides deployment control - the feature can be deployed but not activated
 * until explicitly enabled via the environment variable.
 */

/**
 * Time conversion constants
 */
export const MS_PER_MINUTE = 60 * 1000; // 60,000 milliseconds
export const MS_PER_DAY = 24 * 60 * 60 * 1000; // 86,400,000 milliseconds

/**
 * Notification timing configurations
 * Defines when notifications should be shown before capacity block expiration
 */
export const NOTIFICATION_TIMINGS = [
  { minutes: 30, type: 'toast' as const },
  { minutes: 10, type: 'toast' as const },
  { minutes: 2, type: 'modal' as const },
];

/**
 * If capacity block end time changes by more than this threshold,
 * all notifications will be rescheduled
 */
export const EXTENSION_THRESHOLD_MS = 1 * MS_PER_MINUTE; // 1 minute

/**
 * Tolerance window for showing notifications
 * Notifications will still show if within ±30 secondss of scheduled time
 */
export const TOLERANCE_MS = 30 * 1000; // ±30 seconds

/**
 * API endpoint for fetching capacity block metadata
 */
export const CB_METADATA_ENDPOINT = '/aws/sagemaker/api/capacity-block-metadata';

/**
 * Minimum time before expiration to schedule any notifications
 * If capacity block expires in less than this time, notifications won't be scheduled
 */
export const MIN_SCHEDULE_TIME_MS = 2 * MS_PER_MINUTE; // 2 minutes

/**
 * Maximum safe setTimeout delay in JavaScript (24 days to be conservative)
 * JavaScript's setTimeout max is ~24.8 days (2^31-1 ms)
 */
export const MAX_SAFE_TIMEOUT_MS = 24 * MS_PER_DAY; // 24 days

/**
 * Interval for checking if long-delayed capacity blocks are ready for notification scheduling
 * Used when CB end time is beyond the safe setTimeout threshold
 */
export const LONG_DELAY_CHECK_INTERVAL_MS = 7 * MS_PER_DAY; // 7 days

/**
 * EC2 shutdown process starts 30 minutes before the capacity block end time
 * All notifications are relative to this shutdown start time, not the CB end time
 */
export const EC2_SHUTDOWN_OFFSET_MINUTES = 30;

/**
 * Timeout for API requests to fetch capacity block metadata
 */
export const API_REQUEST_TIMEOUT_MS = 5000; // 5 seconds
