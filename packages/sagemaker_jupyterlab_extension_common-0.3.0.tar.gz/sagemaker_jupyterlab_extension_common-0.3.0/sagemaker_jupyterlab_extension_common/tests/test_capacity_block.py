import json
import pytest
from unittest.mock import patch
from ..util.app_metadata import get_capacity_block_end_time


@pytest.fixture
def jp_server_config(jp_template_dir):
    """Configure the Jupyter server to load the extension"""
    return {
        "ServerApp": {
            "jpserver_extensions": {"sagemaker_jupyterlab_extension_common": True}
        },
    }


class TestCapacityBlockMetadata:
    """Tests for capacity block metadata functionality"""

    # Tier 1: Invalid data structures
    @patch(
        "sagemaker_jupyterlab_extension_common.util.file_watcher.WatchedJsonFile.get_key"
    )
    def test_get_capacity_block_end_time_with_string_instead_of_dict(
        self, get_key_mock
    ):
        """Test that string value is handled gracefully"""
        get_key_mock.return_value = "not a dict"

        result = get_capacity_block_end_time()

        assert result is None

    @patch(
        "sagemaker_jupyterlab_extension_common.util.file_watcher.WatchedJsonFile.get_key"
    )
    def test_get_capacity_block_end_time_with_missing_end_time_field(
        self, get_key_mock
    ):
        """Test that dict without CapacityBlockEndTime returns None"""
        get_key_mock.return_value = {"OtherField": "value"}

        result = get_capacity_block_end_time()

        assert result is None

    @patch(
        "sagemaker_jupyterlab_extension_common.util.file_watcher.WatchedJsonFile.get_key"
    )
    def test_get_capacity_block_end_time_with_none_capacity_block(self, get_key_mock):
        """Test that None CapacityBlock value returns None"""
        get_key_mock.return_value = None

        result = get_capacity_block_end_time()

        assert result is None

    # Tier 1: Valid capacity block data
    @patch(
        "sagemaker_jupyterlab_extension_common.util.file_watcher.WatchedJsonFile.get_key"
    )
    def test_get_capacity_block_end_time_with_valid_data(self, get_key_mock):
        """Test that valid capacity block data returns the end time"""
        expected_end_time = 1735689600
        get_key_mock.return_value = {"CapacityBlockEndTime": expected_end_time}

        result = get_capacity_block_end_time()

        assert result == expected_end_time

    # Tier 1: No capacity block configured
    @patch(
        "sagemaker_jupyterlab_extension_common.util.file_watcher.WatchedJsonFile.get_key"
    )
    def test_get_capacity_block_end_time_when_not_configured(self, get_key_mock):
        """Test that None is returned when capacity block is not configured"""
        get_key_mock.return_value = None

        result = get_capacity_block_end_time()

        assert result is None

    # Tier 1: Handler success with data
    @patch("sagemaker_jupyterlab_extension_common.handlers.get_capacity_block_end_time")
    async def test_capacity_block_metadata_handler_returns_data(
        self, get_cb_mock, jp_fetch
    ):
        """Test that the API endpoint returns capacity block end time"""
        expected_end_time = 1735689600
        get_cb_mock.return_value = expected_end_time

        response = await jp_fetch(
            "/aws/sagemaker/api/capacity-block-metadata", method="GET"
        )

        assert response.code == 200
        data = json.loads(response.body.decode())
        assert data["capacityBlockEndTime"] == expected_end_time

    # Tier 1: Handler success with null
    @patch("sagemaker_jupyterlab_extension_common.handlers.get_capacity_block_end_time")
    async def test_capacity_block_metadata_handler_returns_null(
        self, get_cb_mock, jp_fetch
    ):
        """Test that the API endpoint returns null when no capacity block is configured"""
        get_cb_mock.return_value = None

        response = await jp_fetch(
            "/aws/sagemaker/api/capacity-block-metadata", method="GET"
        )

        assert response.code == 200
        data = json.loads(response.body.decode())
        assert data["capacityBlockEndTime"] is None

    # Tier 2: Handler error handling
    @patch("sagemaker_jupyterlab_extension_common.handlers.get_capacity_block_end_time")
    async def test_capacity_block_metadata_handler_handles_exception(
        self, get_cb_mock, jp_fetch
    ):
        """Test that the API endpoint handles exceptions gracefully"""
        get_cb_mock.side_effect = Exception("File read error")

        # jp_fetch raises HTTPClientError for non-2xx status codes
        with pytest.raises(Exception) as exc_info:
            response = await jp_fetch(
                "/aws/sagemaker/api/capacity-block-metadata", method="GET"
            )

        # Verify it's an HTTP 500 error
        assert exc_info.value.code == 500

        # Parse the error response body
        data = json.loads(exc_info.value.response.body.decode())
        assert "errorMessage" in data
        assert data["errorMessage"] == "Failed to fetch capacity block metadata"
