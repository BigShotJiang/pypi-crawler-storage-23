from corio import environment_tools as env
from corio.constants import Constants
from corio.inspection_tools import get_call_path


def read() -> str:
    """

    Read a generic version file from the calling package path.

    """

    path = get_call_path(offset=2).parent / Constants.FILENAME_VERSION
    return read_path(path)


def read_path(path) -> str:
    """

    Read in version from specified path

    """
    from corio import Constants
    text = path.read_text(encoding=Constants.ENCODING).strip()

    text = get(text)
    return text


def get(text) -> str:
    """

    Optionally add dev build info to raw version string.

    """

    if not env.IS_DEV:
        return text

    import datetime
    from corio.tools import Constants
    from corio.version_tools import parse

    timestamp = datetime.datetime.now(datetime.timezone.utc).strftime(Constants.DATETIME_SEMVER_BUILD_FORMAT)

    version = parse(text)
    version = version.bump_patch()
    version = version.replace(prerelease=Constants.DEVELOPMENT, build=timestamp)
    text = str(version)

    return text
