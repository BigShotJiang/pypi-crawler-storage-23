def main():
    """

    Test debugger connection

    """
    from corio import debug
    debug.trace(is_debug=True)
