def main():
    import corio
    corio.hfh.main()
