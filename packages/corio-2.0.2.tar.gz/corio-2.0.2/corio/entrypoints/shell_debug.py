def main():
    """

    Start debugger

    """
    from corio import debug
    debug.debug_shell()
