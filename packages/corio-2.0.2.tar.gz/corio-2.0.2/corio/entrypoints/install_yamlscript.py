def main():
    """

    Ensure YS binary is installed.

    """
    from corio import yaml
    yaml.install()
