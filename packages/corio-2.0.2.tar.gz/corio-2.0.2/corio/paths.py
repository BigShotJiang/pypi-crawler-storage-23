from corio.path_tools.path_tools import PackagePaths

paths = PackagePaths()
