//! Rule configuration types and builders.

mod rule_config;

pub use rule_config::{RuleConfig, RuleOption, RuleOptions};
