//! Source code analysis and position mapping.

mod mapper;

pub use mapper::SourceMapper;
