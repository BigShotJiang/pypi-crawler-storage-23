"""
Main module for MCP Outline server
"""

from mcp_outline.server import main

if __name__ == "__main__":
    main()
