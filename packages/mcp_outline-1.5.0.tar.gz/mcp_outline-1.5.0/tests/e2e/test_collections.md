```mermaid
flowchart TD
    C[create_collection] --> L[list_collections\nverify ID visible]
    C --> U[update_collection]
    C --> E[export_collection]
    EA[export_all_collections]
    C --> D[delete_collection]
```
