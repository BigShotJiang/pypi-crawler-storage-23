## What does this PR do?

<!-- Brief description of the changes -->

## Checklist

- [ ] I ran `uv run pre-commit install` and committed with hooks enabled
- [ ] Tests pass locally (`uv run pytest tests/ -v`)
