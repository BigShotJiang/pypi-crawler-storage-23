"""Benchmark helpers for quality regression checks."""
