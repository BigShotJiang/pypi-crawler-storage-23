"""Tests for the markdown_it parser module."""
