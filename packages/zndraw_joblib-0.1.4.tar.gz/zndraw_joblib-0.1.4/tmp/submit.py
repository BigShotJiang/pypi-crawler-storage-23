# tmp/submit.py
"""Example: Submit tasks and monitor their progress."""

from collections import Counter

import httpx

from zndraw_joblib import JobManager
from zndraw_joblib.schemas import JobSummary, TaskResponse, PaginatedResponse
from tasks import Rotate

base_url = "http://localhost:8000"
headers = {"Authorization": "Bearer my-user-id"}


class SimpleApi:
    """Simple API adapter for task submission."""

    def __init__(self, base_url: str, token: str):
        self._base_url = base_url
        self._token = token
        self.http = httpx.Client()

    @property
    def base_url(self) -> str:
        return self._base_url

    def get_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._token}"}


api = SimpleApi(base_url=base_url, token="my-user-id")
manager = JobManager(api)


def print_header(title: str) -> None:
    print(f"\n{'=' * 60}")
    print(f"  {title}")
    print(f"{'=' * 60}")


def print_task(task: TaskResponse, prefix: str = "") -> None:
    status_icons = {
        "pending": "⏳",
        "claimed": "🔒",
        "running": "🔄",
        "completed": "✅",
        "failed": "❌",
        "cancelled": "🚫",
    }
    status_val = task.status.value if hasattr(task.status, "value") else task.status
    icon = status_icons.get(status_val, "❓")

    task_id = str(task.id)[:8]
    queue_info = f" (queue: #{task.queue_position})" if task.queue_position else ""
    print(
        f"{prefix}{icon} [{status_val:^10}] {task_id}... | {task.job_name}{queue_info}"
    )


def print_job(job: JobSummary) -> None:
    worker_count = len(job.workers)
    # Workers are UUIDs, convert to strings for display
    worker_strs = [str(w)[:8] + "..." for w in job.workers[:3]]
    print(f"  📦 {job.full_name}")
    print(
        f"     └─ {worker_count} worker(s): {', '.join(worker_strs)}{'...' if worker_count > 3 else ''}"
    )


# Submit 10 tasks using the SDK
print_header("Submitting 10 Tasks")
submitted_task_ids: list[str] = []
for i in range(10):
    extension = Rotate(angle=45.0 * (i + 1))
    task_id = manager.submit(extension, room="my-room")
    submitted_task_ids.append(task_id)
    print(f"  #{i + 1:2d} Created: {task_id[:8]}...")

print(f"\n  Total submitted: {len(submitted_task_ids)} tasks")

# List all tasks in the room showing queue positions
print_header("Tasks Queue Overview")
resp = httpx.get(f"{base_url}/v1/joblib/rooms/my-room/tasks", headers=headers)
tasks_data = PaginatedResponse[TaskResponse].model_validate(resp.json())
if tasks_data.items:
    for task in tasks_data.items:
        print_task(task, prefix="  ")
else:
    print("  (no tasks)")

# Wait for all tasks to complete using long-polling
print_header("Waiting for All Tasks to Complete")
pending_ids = set(submitted_task_ids)
completed_count = 0
poll_count = 0

while pending_ids:
    poll_count += 1
    # Check each pending task
    for task_id in list(pending_ids):
        resp = httpx.get(
            f"{base_url}/v1/joblib/tasks/{task_id}",
            headers={**headers, "Prefer": "wait=5"},
            timeout=10.0,
        )
        resp.raise_for_status()
        task = TaskResponse.model_validate(resp.json())
        if task.status.value in ("completed", "failed", "cancelled"):
            pending_ids.remove(task_id)
            completed_count += 1
            status_icon = {"completed": "✅", "failed": "❌", "cancelled": "🚫"}.get(
                task.status.value, "❓"
            )
            print(
                f"  {status_icon} Task {task_id[:8]}... -> {task.status.value} ({completed_count}/{len(submitted_task_ids)})"
            )

print(f"\n  All {len(submitted_task_ids)} tasks finished!")

# Final task listing
print_header("Final Task State")
resp = httpx.get(f"{base_url}/v1/joblib/rooms/my-room/tasks", headers=headers)
tasks_data = PaginatedResponse[TaskResponse].model_validate(resp.json())
status_counts: Counter[str] = Counter()
if tasks_data.items:
    for task in tasks_data.items:
        print_task(task, prefix="  ")
        status_val = task.status.value if hasattr(task.status, "value") else task.status
        status_counts[status_val] += 1
else:
    print("  (no tasks)")

# Status summary
print_header("Status Summary")
for status, count in sorted(status_counts.items()):
    icon = {
        "pending": "⏳",
        "claimed": "🔒",
        "running": "🔄",
        "completed": "✅",
        "failed": "❌",
        "cancelled": "🚫",
    }.get(status, "❓")
    print(f"  {icon} {status}: {count}")

# Worker distribution
print_header("Worker Distribution")
resp = httpx.get(f"{base_url}/v1/joblib/rooms/my-room/workers", headers=headers)
workers_data = resp.json()
if workers_data:
    for worker in workers_data:
        print(f"  👷 {worker}")
        # print(f"     └─ Jobs registered: {worker['job_count']}")
        # print(f"     └─ Last heartbeat: {worker['last_heartbeat']}")
else:
    print("  (no workers)")

# Available jobs
print_header("Available Jobs")
resp = httpx.get(f"{base_url}/v1/joblib/rooms/my-room/jobs", headers=headers)
jobs_data = PaginatedResponse[JobSummary].model_validate(resp.json()).items
if jobs_data:
    for job_data in jobs_data:
        print_job(JobSummary.model_validate(job_data))
else:
    print("  (no jobs registered)")

print()
