"""Shared extension classes for worker and task submission."""

from typing import ClassVar

from zndraw_joblib import Extension, Category


class Rotate(Extension):
    """Rotate atoms by an angle around an axis."""

    category: ClassVar[Category] = Category.MODIFIER

    angle: float = 0.0
    axis: str = "z"

    def run(self) -> None:
        print(f"  Rotating by {self.angle}° around {self.axis}")


class SelectByElement(Extension):
    """Select atoms by element symbol."""

    category: ClassVar[Category] = Category.SELECTION

    element: str = "C"

    def run(self) -> None:
        print(f"  Selecting element: {self.element}")


class Translate(Extension):
    """Translate atoms by a vector."""

    category: ClassVar[Category] = Category.MODIFIER

    x: float = 0.0
    y: float = 0.0
    z: float = 0.0

    def run(self) -> None:
        print(f"  Translating by ({self.x}, {self.y}, {self.z})")
