# Mock Responses Directory

This directory contains mock LLM responses for offline model validation testing.

## Subdirectories

- **baseline/**: 15 responses from gpt-4-turbo (all pass invariants)
- **candidate/**: 15 responses from gpt-4o-mini (3 fail invariants)

See the parent [README.md](../README.md) for details.
