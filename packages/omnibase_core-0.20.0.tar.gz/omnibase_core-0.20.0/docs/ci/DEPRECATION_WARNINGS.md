> **Navigation**: [Home](../INDEX.md) > CI > Deprecation Warning Configuration

# Deprecation Warning Configuration

> **Linear Ticket**: OMN-199 - Configure pytest deprecation warning capture
> **Phase**: 7 - Deprecation & CI Enforcement
> **Last Updated**: 2026-02-14

---

## Overview

> **HISTORICAL**: These deprecation warnings were relevant during the v0.5.0 migration. Most have been resolved in current versions. The project is now at v0.17.0. See current `pyproject.toml` for the active `filterwarnings` configuration.

This document describes the deprecation warning strategy for omnibase_core, including the historical v0.4.0 configuration and the completed transition to strict enforcement in v0.5.0+.

---

## Historical State (v0.4.0)

### Configuration

In `pyproject.toml`, deprecation warnings are configured to display during test runs:

```toml
filterwarnings = [
    # === Deprecation Warning Capture (OMN-199, Phase 7) ===
    # Display deprecation warnings during test runs so developers can address them
    # before v0.5.0 when these will become errors
    "default::DeprecationWarning",
    "default::PendingDeprecationWarning",
]
```

### Behavior

- **DeprecationWarning**: Displayed during test runs (not failures)
- **PendingDeprecationWarning**: Displayed during test runs (not failures)
- **Developer Action**: Warnings should be addressed proactively before v0.5.0

### Why Display Instead of Error?

The `default` filter displays warnings without causing test failures. This allows:

1. **Visibility**: Developers see deprecation warnings in test output
2. **Gradual Migration**: Time to address warnings before they become blocking
3. **Non-Blocking CI**: Tests pass even with deprecation warnings during transition period

---

## v0.5.0 Migration Path (Completed)

### Configuration Change (Completed in v0.5.0)

In v0.5.0, the configuration changed from `default` to `error`:

```toml
filterwarnings = [
    # === Deprecation Warning Enforcement (v0.5.0) ===
    # Deprecation warnings are now errors - tests will fail if they trigger warnings
    "error::DeprecationWarning",
    "error::PendingDeprecationWarning",
]
```

### Impact (Active since v0.5.0)

- **DeprecationWarning**: Causes test failures
- **PendingDeprecationWarning**: Causes test failures
- **CI Impact**: PRs with deprecation warnings fail CI checks

### Timeline

| Version | Behavior | Action Required |
|---------|----------|-----------------|
| **v0.4.x** | Warnings displayed | Address warnings proactively |
| **v0.5.0+** | Warnings become errors | All warnings must be resolved |
| **v0.17.0** (current) | Warnings are errors | Resolved - see `pyproject.toml` |

---

## How to Address Deprecation Warnings

### Step 1: Identify Warnings

Run the test suite and review deprecation warnings in the output:

```bash
# Run all tests and observe warnings
uv run pytest tests/

# Run with verbose warnings
uv run pytest tests/ -W default::DeprecationWarning
```

### Step 2: Categorize Warnings

Deprecation warnings typically fall into these categories:

| Category | Source | Resolution |
|----------|--------|------------|
| **Internal Code** | Your own deprecated usage | Update to new APIs |
| **Dependencies** | Third-party library deprecations | Update library or suppress |
| **Python stdlib** | Python version-specific deprecations | Update code patterns |

### Step 3: Resolve Internal Warnings

For warnings in omnibase_core code:

1. **Find the deprecated usage** in the warning message
2. **Check documentation** for the replacement API
3. **Update code** to use the non-deprecated alternative
4. **Verify fix** by re-running tests

Example:
```python
# Before (deprecated)
import warnings
warnings.warn("old_function is deprecated", DeprecationWarning)

# After (use new API)
from new_module import new_function
new_function()
```

### Step 4: Handle Dependency Warnings

For warnings from third-party libraries:

1. **Check if library update available** that resolves the warning
2. **Update dependency** if possible: `poetry update library-name`
3. **If no update available**, consider targeted suppression (see below)

### Step 5: Targeted Suppression (Last Resort)

If a warning cannot be resolved (e.g., waiting for upstream fix), add a targeted suppression:

```toml
# In pyproject.toml filterwarnings
filterwarnings = [
    "default::DeprecationWarning",
    "default::PendingDeprecationWarning",
    # Suppress specific unavoidable warning from dependency
    # TODO(YOUR-TICKET): Remove when library-name >= X.Y.Z
    "ignore:specific warning message:DeprecationWarning:library_name",
]
```

**Important**: Always include:
- A TODO comment with Linear ticket reference
- The minimum version that resolves the warning
- The specific warning message (not a broad suppression)

---

## Warning Filter Syntax Reference

### Filter Format

```text
action:message:category:module:line
```

### Actions

| Action | Effect |
|--------|--------|
| `error` | Turn warning into exception (test failure) |
| `ignore` | Suppress warning completely |
| `default` | Display warning once per location |
| `always` | Display warning every time |
| `once` | Display warning only first time |

### Examples

```toml
filterwarnings = [
    # Display all deprecation warnings (current v0.4.0 behavior)
    "default::DeprecationWarning",

    # Convert to errors (v0.5.0 behavior)
    "error::DeprecationWarning",

    # Suppress specific warning from specific module
    "ignore:datetime.datetime.utcnow:DeprecationWarning:some_library",

    # Suppress warnings matching regex pattern
    "ignore:.*is deprecated.*:DeprecationWarning",
]
```

---

## Pre-v0.5.0 Checklist (Resolved)

This checklist was completed during the v0.5.0 release:

- [x] Run full test suite: `uv run pytest tests/`
- [x] Review all `DeprecationWarning` output
- [x] Update code to resolve internal deprecations
- [x] Update dependencies where possible
- [x] Add targeted suppressions for unavoidable warnings (with TODOs)
- [x] Verify no new deprecation warnings appear

### Validation Command

```bash
# Treat deprecations as errors (this is now the default behavior since v0.5.0)
uv run pytest tests/ -W error::DeprecationWarning -W error::PendingDeprecationWarning
```

This validation is now enforced by default in `pyproject.toml` since v0.5.0.

---

## Related Documentation

- [CI Monitoring Guide](CI_MONITORING_GUIDE.md) - CI health monitoring
- [CI Test Strategy](../testing/CI_TEST_STRATEGY.md) - Overall test strategy
- [Testing Guide](../guides/TESTING_GUIDE.md) - Comprehensive testing documentation

---

## Configuration Location

The warning filter configuration is located in:

```text
pyproject.toml
```

Under the `[tool.pytest.ini_options]` section, in the `filterwarnings` array.

---

**Last Updated**: 2026-02-14
**Document Version**: 1.1.0
**Linear Ticket**: OMN-199
