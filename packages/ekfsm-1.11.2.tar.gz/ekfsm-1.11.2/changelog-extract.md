## [1.11.2] - 2026-03-05

### Changed
- Release 1.11.2
