# PyPI Package

This release is available on PyPI:

- **Package:** [ekfsm v1.11.2](https://pypi.org/project/ekfsm/1.11.2/)
- **Installation:** `pip install ekfsm==1.11.2`

## Alternative Installations

- **Latest stable:** `pip install ekfsm`
- **From source:** `pip install git+https://gitlab.com/path/to/ekfsm@v1.11.2`
