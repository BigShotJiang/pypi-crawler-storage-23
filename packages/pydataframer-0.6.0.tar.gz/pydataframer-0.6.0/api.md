# APIKeys

Types:

```python
from dataframer.types import APIKeyRotateResponse
```

Methods:

- <code title="post /api/users/api-key/rotate">client.api_keys.<a href="./src/dataframer/resources/api_keys.py">rotate</a>() -> <a href="./src/dataframer/types/api_key_rotate_response.py">APIKeyRotateResponse</a></code>

# Dataframer

Types:

```python
from dataframer.types import SampleClassification, SpecVersion
```

## SeedDatasets

Types:

```python
from dataframer.types.dataframer import (
    File,
    SeedDatasetRetrieveResponse,
    SeedDatasetListResponse,
    SeedDatasetCreateFromZipResponse,
    SeedDatasetCreateWithFilesResponse,
)
```

Methods:

- <code title="get /api/dataframer/seed-datasets/{dataset_id}/">client.dataframer.seed_datasets.<a href="./src/dataframer/resources/dataframer/seed_datasets/seed_datasets.py">retrieve</a>(dataset_id) -> <a href="./src/dataframer/types/dataframer/seed_dataset_retrieve_response.py">SeedDatasetRetrieveResponse</a></code>
- <code title="get /api/dataframer/seed-datasets/">client.dataframer.seed_datasets.<a href="./src/dataframer/resources/dataframer/seed_datasets/seed_datasets.py">list</a>() -> <a href="./src/dataframer/types/dataframer/seed_dataset_list_response.py">SeedDatasetListResponse</a></code>
- <code title="delete /api/dataframer/seed-datasets/{dataset_id}/">client.dataframer.seed_datasets.<a href="./src/dataframer/resources/dataframer/seed_datasets/seed_datasets.py">delete</a>(dataset_id) -> None</code>
- <code title="post /api/dataframer/seed-datasets/create-from-zip/">client.dataframer.seed_datasets.<a href="./src/dataframer/resources/dataframer/seed_datasets/seed_datasets.py">create_from_zip</a>(\*\*<a href="src/dataframer/types/dataframer/seed_dataset_create_from_zip_params.py">params</a>) -> <a href="./src/dataframer/types/dataframer/seed_dataset_create_from_zip_response.py">SeedDatasetCreateFromZipResponse</a></code>
- <code title="post /api/dataframer/seed-datasets/create/">client.dataframer.seed_datasets.<a href="./src/dataframer/resources/dataframer/seed_datasets/seed_datasets.py">create_with_files</a>(\*\*<a href="src/dataframer/types/dataframer/seed_dataset_create_with_files_params.py">params</a>) -> <a href="./src/dataframer/types/dataframer/seed_dataset_create_with_files_response.py">SeedDatasetCreateWithFilesResponse</a></code>

### Files

Types:

```python
from dataframer.types.dataframer.seed_datasets import FileDownloadResponse
```

Methods:

- <code title="get /api/dataframer/seed-datasets/{dataset_id}/files/{file_id}/">client.dataframer.seed_datasets.files.<a href="./src/dataframer/resources/dataframer/seed_datasets/files.py">download</a>(file_id, \*, dataset_id) -> <a href="./src/dataframer/types/dataframer/seed_datasets/file_download_response.py">FileDownloadResponse</a></code>

## Evaluations

Types:

```python
from dataframer.types.dataframer import EvaluationCreateResponse, EvaluationRetrieveResponse
```

Methods:

- <code title="post /api/dataframer/evaluations/">client.dataframer.evaluations.<a href="./src/dataframer/resources/dataframer/evaluations.py">create</a>(\*\*<a href="src/dataframer/types/dataframer/evaluation_create_params.py">params</a>) -> <a href="./src/dataframer/types/dataframer/evaluation_create_response.py">EvaluationCreateResponse</a></code>
- <code title="get /api/dataframer/evaluations/{evaluation_id}/">client.dataframer.evaluations.<a href="./src/dataframer/resources/dataframer/evaluations.py">retrieve</a>(evaluation_id) -> <a href="./src/dataframer/types/dataframer/evaluation_retrieve_response.py">EvaluationRetrieveResponse</a></code>

## RedTeamRuns

Types:

```python
from dataframer.types.dataframer import (
    RedTeamRunCreateResponse,
    RedTeamRunRetrieveResponse,
    RedTeamRunListResponse,
    RedTeamRunRetrieveStatusResponse,
)
```

Methods:

- <code title="post /api/dataframer/red-team-runs/">client.dataframer.red_team_runs.<a href="./src/dataframer/resources/dataframer/red_team_runs.py">create</a>(\*\*<a href="src/dataframer/types/dataframer/red_team_run_create_params.py">params</a>) -> <a href="./src/dataframer/types/dataframer/red_team_run_create_response.py">RedTeamRunCreateResponse</a></code>
- <code title="get /api/dataframer/red-team-runs/{run_id}/">client.dataframer.red_team_runs.<a href="./src/dataframer/resources/dataframer/red_team_runs.py">retrieve</a>(run_id) -> <a href="./src/dataframer/types/dataframer/red_team_run_retrieve_response.py">RedTeamRunRetrieveResponse</a></code>
- <code title="get /api/dataframer/red-team-runs/">client.dataframer.red_team_runs.<a href="./src/dataframer/resources/dataframer/red_team_runs.py">list</a>(\*\*<a href="src/dataframer/types/dataframer/red_team_run_list_params.py">params</a>) -> <a href="./src/dataframer/types/dataframer/red_team_run_list_response.py">RedTeamRunListResponse</a></code>
- <code title="delete /api/dataframer/red-team-runs/{run_id}/">client.dataframer.red_team_runs.<a href="./src/dataframer/resources/dataframer/red_team_runs.py">delete</a>(run_id) -> None</code>
- <code title="get /api/dataframer/red-team-runs/{run_id}/status/">client.dataframer.red_team_runs.<a href="./src/dataframer/resources/dataframer/red_team_runs.py">retrieve_status</a>(run_id) -> <a href="./src/dataframer/types/dataframer/red_team_run_retrieve_status_response.py">RedTeamRunRetrieveStatusResponse</a></code>

## RedTeamSpecs

Types:

```python
from dataframer.types.dataframer import (
    RedTeamSpecCreateResponse,
    RedTeamSpecRetrieveResponse,
    RedTeamSpecUpdateResponse,
    RedTeamSpecListResponse,
)
```

Methods:

- <code title="post /api/dataframer/red-team-specs/">client.dataframer.red_team_specs.<a href="./src/dataframer/resources/dataframer/red_team_specs.py">create</a>(\*\*<a href="src/dataframer/types/dataframer/red_team_spec_create_params.py">params</a>) -> <a href="./src/dataframer/types/dataframer/red_team_spec_create_response.py">RedTeamSpecCreateResponse</a></code>
- <code title="get /api/dataframer/red-team-specs/{spec_id}/">client.dataframer.red_team_specs.<a href="./src/dataframer/resources/dataframer/red_team_specs.py">retrieve</a>(spec_id) -> <a href="./src/dataframer/types/dataframer/red_team_spec_retrieve_response.py">RedTeamSpecRetrieveResponse</a></code>
- <code title="patch /api/dataframer/red-team-specs/{spec_id}/">client.dataframer.red_team_specs.<a href="./src/dataframer/resources/dataframer/red_team_specs.py">update</a>(spec_id, \*\*<a href="src/dataframer/types/dataframer/red_team_spec_update_params.py">params</a>) -> <a href="./src/dataframer/types/dataframer/red_team_spec_update_response.py">RedTeamSpecUpdateResponse</a></code>
- <code title="get /api/dataframer/red-team-specs/">client.dataframer.red_team_specs.<a href="./src/dataframer/resources/dataframer/red_team_specs.py">list</a>() -> <a href="./src/dataframer/types/dataframer/red_team_spec_list_response.py">RedTeamSpecListResponse</a></code>
- <code title="delete /api/dataframer/red-team-specs/{spec_id}/">client.dataframer.red_team_specs.<a href="./src/dataframer/resources/dataframer/red_team_specs.py">delete</a>(spec_id) -> None</code>

## Runs

Types:

```python
from dataframer.types.dataframer import RunCreateResponse, RunRetrieveResponse, RunListResponse
```

Methods:

- <code title="post /api/dataframer/runs/">client.dataframer.runs.<a href="./src/dataframer/resources/dataframer/runs/runs.py">create</a>(\*\*<a href="src/dataframer/types/dataframer/run_create_params.py">params</a>) -> <a href="./src/dataframer/types/dataframer/run_create_response.py">RunCreateResponse</a></code>
- <code title="get /api/dataframer/runs/{run_id}/">client.dataframer.runs.<a href="./src/dataframer/resources/dataframer/runs/runs.py">retrieve</a>(run_id) -> <a href="./src/dataframer/types/dataframer/run_retrieve_response.py">RunRetrieveResponse</a></code>
- <code title="get /api/dataframer/runs/">client.dataframer.runs.<a href="./src/dataframer/resources/dataframer/runs/runs.py">list</a>() -> <a href="./src/dataframer/types/dataframer/run_list_response.py">RunListResponse</a></code>
- <code title="delete /api/dataframer/runs/{run_id}/">client.dataframer.runs.<a href="./src/dataframer/resources/dataframer/runs/runs.py">delete</a>(run_id) -> None</code>
- <code title="post /api/dataframer/runs/{run_id}/cancel/">client.dataframer.runs.<a href="./src/dataframer/resources/dataframer/runs/runs.py">cancel</a>(run_id) -> None</code>

### Evaluations

Types:

```python
from dataframer.types.dataframer.runs import EvaluationListResponse
```

Methods:

- <code title="get /api/dataframer/runs/{run_id}/evaluations/">client.dataframer.runs.evaluations.<a href="./src/dataframer/resources/dataframer/runs/evaluations.py">list</a>(run_id) -> <a href="./src/dataframer/types/dataframer/runs/evaluation_list_response.py">EvaluationListResponse</a></code>

### Files

Types:

```python
from dataframer.types.dataframer.runs import FileDownloadResponse, FileDownloadAllResponse
```

Methods:

- <code title="get /api/dataframer/runs/{run_id}/files/{file_id}/download/">client.dataframer.runs.files.<a href="./src/dataframer/resources/dataframer/runs/files.py">download</a>(file_id, \*, run_id) -> <a href="./src/dataframer/types/dataframer/runs/file_download_response.py">FileDownloadResponse</a></code>
- <code title="get /api/dataframer/runs/{run_id}/files/download/">client.dataframer.runs.files.<a href="./src/dataframer/resources/dataframer/runs/files.py">download_all</a>(run_id) -> <a href="./src/dataframer/types/dataframer/runs/file_download_all_response.py">FileDownloadAllResponse</a></code>

## Specs

Types:

```python
from dataframer.types.dataframer import (
    SpecCreateResponse,
    SpecRetrieveResponse,
    SpecUpdateResponse,
    SpecListResponse,
)
```

Methods:

- <code title="post /api/dataframer/specs/">client.dataframer.specs.<a href="./src/dataframer/resources/dataframer/specs.py">create</a>(\*\*<a href="src/dataframer/types/dataframer/spec_create_params.py">params</a>) -> <a href="./src/dataframer/types/dataframer/spec_create_response.py">SpecCreateResponse</a></code>
- <code title="get /api/dataframer/specs/{spec_id}/">client.dataframer.specs.<a href="./src/dataframer/resources/dataframer/specs.py">retrieve</a>(spec_id, \*\*<a href="src/dataframer/types/dataframer/spec_retrieve_params.py">params</a>) -> <a href="./src/dataframer/types/dataframer/spec_retrieve_response.py">SpecRetrieveResponse</a></code>
- <code title="put /api/dataframer/specs/{spec_id}/">client.dataframer.specs.<a href="./src/dataframer/resources/dataframer/specs.py">update</a>(spec_id, \*\*<a href="src/dataframer/types/dataframer/spec_update_params.py">params</a>) -> <a href="./src/dataframer/types/dataframer/spec_update_response.py">SpecUpdateResponse</a></code>
- <code title="get /api/dataframer/specs/">client.dataframer.specs.<a href="./src/dataframer/resources/dataframer/specs.py">list</a>() -> <a href="./src/dataframer/types/dataframer/spec_list_response.py">SpecListResponse</a></code>
- <code title="delete /api/dataframer/specs/{spec_id}/">client.dataframer.specs.<a href="./src/dataframer/resources/dataframer/specs.py">delete</a>(spec_id, \*\*<a href="src/dataframer/types/dataframer/spec_delete_params.py">params</a>) -> None</code>
