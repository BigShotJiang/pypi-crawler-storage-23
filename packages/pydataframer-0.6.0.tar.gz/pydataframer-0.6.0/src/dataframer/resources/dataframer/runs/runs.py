# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from .files import (
    FilesResource,
    AsyncFilesResource,
    FilesResourceWithRawResponse,
    AsyncFilesResourceWithRawResponse,
    FilesResourceWithStreamingResponse,
    AsyncFilesResourceWithStreamingResponse,
)
from ...._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ...._utils import maybe_transform, async_maybe_transform
from ...._compat import cached_property
from .evaluations import (
    EvaluationsResource,
    AsyncEvaluationsResource,
    EvaluationsResourceWithRawResponse,
    AsyncEvaluationsResourceWithRawResponse,
    EvaluationsResourceWithStreamingResponse,
    AsyncEvaluationsResourceWithStreamingResponse,
)
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.dataframer import run_create_params
from ....types.dataframer.run_list_response import RunListResponse
from ....types.dataframer.run_create_response import RunCreateResponse
from ....types.dataframer.run_retrieve_response import RunRetrieveResponse

__all__ = ["RunsResource", "AsyncRunsResource"]


class RunsResource(SyncAPIResource):
    @cached_property
    def evaluations(self) -> EvaluationsResource:
        return EvaluationsResource(self._client)

    @cached_property
    def files(self) -> FilesResource:
        return FilesResource(self._client)

    @cached_property
    def with_raw_response(self) -> RunsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return RunsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> RunsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return RunsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        number_of_samples: int,
        spec_id: str,
        databricks_api_base: str | Omit = omit,
        databricks_client_id: str | Omit = omit,
        databricks_client_secret: str | Omit = omit,
        enable_revisions: bool | Omit = omit,
        generation_model: Literal[
            "anthropic/claude-opus-4-6",
            "anthropic/claude-opus-4-6-thinking",
            "anthropic/claude-sonnet-4-6",
            "anthropic/claude-sonnet-4-6-thinking",
            "anthropic/claude-haiku-4-5",
            "anthropic/claude-haiku-4-5-thinking",
            "deepseek-ai/DeepSeek-V3.1",
            "moonshotai/Kimi-K2-Instruct",
            "openai/gpt-oss-120b",
            "deepseek-ai/DeepSeek-R1-0528-tput",
            "Qwen/Qwen2.5-72B-Instruct-Turbo",
            "gemini/gemini-3-pro-preview",
            "gemini/gemini-3-pro-preview-thinking",
            "databricks/databricks-claude-3-7-sonnet",
            "databricks/databricks-claude-haiku-4-5",
            "databricks/databricks-claude-opus-4-1",
            "databricks/databricks-claude-opus-4-5",
            "databricks/databricks-claude-opus-4-6",
            "databricks/databricks-claude-sonnet-4",
            "databricks/databricks-claude-sonnet-4-5",
            "databricks/databricks-gemini-2-5-flash",
            "databricks/databricks-gemini-2-5-pro",
            "databricks/databricks-gemini-3-flash",
            "databricks/databricks-gemini-3-pro",
            "databricks/databricks-gpt-5",
        ]
        | Omit = omit,
        generation_thinking_budget: int | Omit = omit,
        max_examples_in_prompt: int | Omit = omit,
        max_revision_cycles: int | Omit = omit,
        outline_model: Literal[
            "anthropic/claude-opus-4-6",
            "anthropic/claude-opus-4-6-thinking",
            "anthropic/claude-sonnet-4-6",
            "anthropic/claude-sonnet-4-6-thinking",
            "anthropic/claude-haiku-4-5",
            "anthropic/claude-haiku-4-5-thinking",
            "deepseek-ai/DeepSeek-V3.1",
            "moonshotai/Kimi-K2-Instruct",
            "openai/gpt-oss-120b",
            "deepseek-ai/DeepSeek-R1-0528-tput",
            "Qwen/Qwen2.5-72B-Instruct-Turbo",
            "gemini/gemini-3-pro-preview",
            "gemini/gemini-3-pro-preview-thinking",
            "databricks/databricks-claude-3-7-sonnet",
            "databricks/databricks-claude-haiku-4-5",
            "databricks/databricks-claude-opus-4-1",
            "databricks/databricks-claude-opus-4-5",
            "databricks/databricks-claude-opus-4-6",
            "databricks/databricks-claude-sonnet-4",
            "databricks/databricks-claude-sonnet-4-5",
            "databricks/databricks-gemini-2-5-flash",
            "databricks/databricks-gemini-2-5-pro",
            "databricks/databricks-gemini-3-flash",
            "databricks/databricks-gemini-3-pro",
            "databricks/databricks-gpt-5",
        ]
        | Omit = omit,
        outline_thinking_budget: int | Omit = omit,
        pdf_template_prompt: str | Omit = omit,
        revision_model: Literal[
            "anthropic/claude-opus-4-6",
            "anthropic/claude-opus-4-6-thinking",
            "anthropic/claude-sonnet-4-6",
            "anthropic/claude-sonnet-4-6-thinking",
            "anthropic/claude-haiku-4-5",
            "anthropic/claude-haiku-4-5-thinking",
            "deepseek-ai/DeepSeek-V3.1",
            "moonshotai/Kimi-K2-Instruct",
            "openai/gpt-oss-120b",
            "deepseek-ai/DeepSeek-R1-0528-tput",
            "Qwen/Qwen2.5-72B-Instruct-Turbo",
            "gemini/gemini-3-pro-preview",
            "gemini/gemini-3-pro-preview-thinking",
            "databricks/databricks-claude-3-7-sonnet",
            "databricks/databricks-claude-haiku-4-5",
            "databricks/databricks-claude-opus-4-1",
            "databricks/databricks-claude-opus-4-5",
            "databricks/databricks-claude-opus-4-6",
            "databricks/databricks-claude-sonnet-4",
            "databricks/databricks-claude-sonnet-4-5",
            "databricks/databricks-gemini-2-5-flash",
            "databricks/databricks-gemini-2-5-pro",
            "databricks/databricks-gemini-3-flash",
            "databricks/databricks-gemini-3-pro",
            "databricks/databricks-gpt-5",
        ]
        | Omit = omit,
        revision_thinking_budget: int | Omit = omit,
        seed_shuffling_level: Literal["none", "sample", "field", "prompt"] | Omit = omit,
        spec_version: int | Omit = omit,
        unified_multifield: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunCreateResponse:
        """
        Start a new data generation run.

        **Async operation**: This endpoint returns immediately with a run ID. Poll
        `GET /api/dataframer/runs/{id}/` until status changes from
        `PENDING`/`PROCESSING` to `SUCCEEDED` or `FAILED`.

        Args:
          number_of_samples: Number of samples to generate

          spec_id: ID of the spec to use for generation. Spec must be in SUCCEEDED status.

          databricks_api_base: Databricks Model Serving endpoint URL (e.g.
              https://adb-xxx.azuredatabricks.net/serving-endpoints). Required when using
              databricks/models.

          databricks_client_id: Databricks service principal application (client) ID. Required when using
              databricks/models.

          databricks_client_secret: Databricks service principal secret. Required when using databricks/models.

          enable_revisions: Enable revision cycles. Recommended for very complex documents requiring
              reasoning, calculations, internal consistency. Also recommended if generated
              long or complex json/jsonl/csv documents in multi-file dataset mode. Incurs some
              extra cost and time so it's disabled by default.

          generation_model: Model for generation. Use -thinking suffix to enable thinking mode. For
              databricks/ models, you must also provide databricks_client_id,
              databricks_client_secret, and databricks_api_base.

          generation_thinking_budget: Token budget for extended thinking during generation. Only applies to models
              with -thinking suffix.

          max_examples_in_prompt: (advanced) Maximum number of seed examples to include in prompts. By default,
              only as many seeds as fit in 10K tokens are used. Use this to override the
              default.

          max_revision_cycles: Maximum number of revision cycles. 2-3 is a solid pick for complex documents
              requiring internal consistency, e.g. financial reports, invoices, etc.; increase
              to 3-5 for highest quality or when generated data has issues.

          outline_model: Model for outline generation

          outline_thinking_budget: Token budget for extended thinking during outline generation. Only applies to
              models with -thinking suffix.

          pdf_template_prompt: Prompt describing the desired PDF styling (e.g. 'Professional corporate style
              with blue headers'). When provided, an LLM generates custom CSS for PDF output.
              Only relevant for datasets containing PDF files.

          revision_model: Model for revisions (only used if enable_revisions is true)

          revision_thinking_budget: Token budget for extended thinking during revisions. Only applies to models with
              -thinking suffix.

          seed_shuffling_level: (advanced) How to shuffle seed examples between samples

          spec_version: Version number to use (optional, defaults to latest)

          unified_multifield: (advanced) Use unified multifield generation. This helps to reduce the
              generation cost by processing all fields together rather than one by one.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/dataframer/runs/",
            body=maybe_transform(
                {
                    "number_of_samples": number_of_samples,
                    "spec_id": spec_id,
                    "databricks_api_base": databricks_api_base,
                    "databricks_client_id": databricks_client_id,
                    "databricks_client_secret": databricks_client_secret,
                    "enable_revisions": enable_revisions,
                    "generation_model": generation_model,
                    "generation_thinking_budget": generation_thinking_budget,
                    "max_examples_in_prompt": max_examples_in_prompt,
                    "max_revision_cycles": max_revision_cycles,
                    "outline_model": outline_model,
                    "outline_thinking_budget": outline_thinking_budget,
                    "pdf_template_prompt": pdf_template_prompt,
                    "revision_model": revision_model,
                    "revision_thinking_budget": revision_thinking_budget,
                    "seed_shuffling_level": seed_shuffling_level,
                    "spec_version": spec_version,
                    "unified_multifield": unified_multifield,
                },
                run_create_params.RunCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunCreateResponse,
        )

    def retrieve(
        self,
        run_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunRetrieveResponse:
        """
        Get run details including status, progress (samples_completed/samples_failed),
        and generated_files when complete.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not run_id:
            raise ValueError(f"Expected a non-empty value for `run_id` but received {run_id!r}")
        return self._get(
            f"/api/dataframer/runs/{run_id}/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunRetrieveResponse,
        )

    def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunListResponse:
        """List all generation runs for your company, newest first."""
        return self._get(
            "/api/dataframer/runs/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunListResponse,
        )

    def delete(
        self,
        run_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a run and its generated files

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not run_id:
            raise ValueError(f"Expected a non-empty value for `run_id` but received {run_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/api/dataframer/runs/{run_id}/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def cancel(
        self,
        run_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Cancel a running generation job.

        Only PENDING or PROCESSING runs can be
        canceled.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not run_id:
            raise ValueError(f"Expected a non-empty value for `run_id` but received {run_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            f"/api/dataframer/runs/{run_id}/cancel/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncRunsResource(AsyncAPIResource):
    @cached_property
    def evaluations(self) -> AsyncEvaluationsResource:
        return AsyncEvaluationsResource(self._client)

    @cached_property
    def files(self) -> AsyncFilesResource:
        return AsyncFilesResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncRunsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncRunsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncRunsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return AsyncRunsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        number_of_samples: int,
        spec_id: str,
        databricks_api_base: str | Omit = omit,
        databricks_client_id: str | Omit = omit,
        databricks_client_secret: str | Omit = omit,
        enable_revisions: bool | Omit = omit,
        generation_model: Literal[
            "anthropic/claude-opus-4-6",
            "anthropic/claude-opus-4-6-thinking",
            "anthropic/claude-sonnet-4-6",
            "anthropic/claude-sonnet-4-6-thinking",
            "anthropic/claude-haiku-4-5",
            "anthropic/claude-haiku-4-5-thinking",
            "deepseek-ai/DeepSeek-V3.1",
            "moonshotai/Kimi-K2-Instruct",
            "openai/gpt-oss-120b",
            "deepseek-ai/DeepSeek-R1-0528-tput",
            "Qwen/Qwen2.5-72B-Instruct-Turbo",
            "gemini/gemini-3-pro-preview",
            "gemini/gemini-3-pro-preview-thinking",
            "databricks/databricks-claude-3-7-sonnet",
            "databricks/databricks-claude-haiku-4-5",
            "databricks/databricks-claude-opus-4-1",
            "databricks/databricks-claude-opus-4-5",
            "databricks/databricks-claude-opus-4-6",
            "databricks/databricks-claude-sonnet-4",
            "databricks/databricks-claude-sonnet-4-5",
            "databricks/databricks-gemini-2-5-flash",
            "databricks/databricks-gemini-2-5-pro",
            "databricks/databricks-gemini-3-flash",
            "databricks/databricks-gemini-3-pro",
            "databricks/databricks-gpt-5",
        ]
        | Omit = omit,
        generation_thinking_budget: int | Omit = omit,
        max_examples_in_prompt: int | Omit = omit,
        max_revision_cycles: int | Omit = omit,
        outline_model: Literal[
            "anthropic/claude-opus-4-6",
            "anthropic/claude-opus-4-6-thinking",
            "anthropic/claude-sonnet-4-6",
            "anthropic/claude-sonnet-4-6-thinking",
            "anthropic/claude-haiku-4-5",
            "anthropic/claude-haiku-4-5-thinking",
            "deepseek-ai/DeepSeek-V3.1",
            "moonshotai/Kimi-K2-Instruct",
            "openai/gpt-oss-120b",
            "deepseek-ai/DeepSeek-R1-0528-tput",
            "Qwen/Qwen2.5-72B-Instruct-Turbo",
            "gemini/gemini-3-pro-preview",
            "gemini/gemini-3-pro-preview-thinking",
            "databricks/databricks-claude-3-7-sonnet",
            "databricks/databricks-claude-haiku-4-5",
            "databricks/databricks-claude-opus-4-1",
            "databricks/databricks-claude-opus-4-5",
            "databricks/databricks-claude-opus-4-6",
            "databricks/databricks-claude-sonnet-4",
            "databricks/databricks-claude-sonnet-4-5",
            "databricks/databricks-gemini-2-5-flash",
            "databricks/databricks-gemini-2-5-pro",
            "databricks/databricks-gemini-3-flash",
            "databricks/databricks-gemini-3-pro",
            "databricks/databricks-gpt-5",
        ]
        | Omit = omit,
        outline_thinking_budget: int | Omit = omit,
        pdf_template_prompt: str | Omit = omit,
        revision_model: Literal[
            "anthropic/claude-opus-4-6",
            "anthropic/claude-opus-4-6-thinking",
            "anthropic/claude-sonnet-4-6",
            "anthropic/claude-sonnet-4-6-thinking",
            "anthropic/claude-haiku-4-5",
            "anthropic/claude-haiku-4-5-thinking",
            "deepseek-ai/DeepSeek-V3.1",
            "moonshotai/Kimi-K2-Instruct",
            "openai/gpt-oss-120b",
            "deepseek-ai/DeepSeek-R1-0528-tput",
            "Qwen/Qwen2.5-72B-Instruct-Turbo",
            "gemini/gemini-3-pro-preview",
            "gemini/gemini-3-pro-preview-thinking",
            "databricks/databricks-claude-3-7-sonnet",
            "databricks/databricks-claude-haiku-4-5",
            "databricks/databricks-claude-opus-4-1",
            "databricks/databricks-claude-opus-4-5",
            "databricks/databricks-claude-opus-4-6",
            "databricks/databricks-claude-sonnet-4",
            "databricks/databricks-claude-sonnet-4-5",
            "databricks/databricks-gemini-2-5-flash",
            "databricks/databricks-gemini-2-5-pro",
            "databricks/databricks-gemini-3-flash",
            "databricks/databricks-gemini-3-pro",
            "databricks/databricks-gpt-5",
        ]
        | Omit = omit,
        revision_thinking_budget: int | Omit = omit,
        seed_shuffling_level: Literal["none", "sample", "field", "prompt"] | Omit = omit,
        spec_version: int | Omit = omit,
        unified_multifield: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunCreateResponse:
        """
        Start a new data generation run.

        **Async operation**: This endpoint returns immediately with a run ID. Poll
        `GET /api/dataframer/runs/{id}/` until status changes from
        `PENDING`/`PROCESSING` to `SUCCEEDED` or `FAILED`.

        Args:
          number_of_samples: Number of samples to generate

          spec_id: ID of the spec to use for generation. Spec must be in SUCCEEDED status.

          databricks_api_base: Databricks Model Serving endpoint URL (e.g.
              https://adb-xxx.azuredatabricks.net/serving-endpoints). Required when using
              databricks/models.

          databricks_client_id: Databricks service principal application (client) ID. Required when using
              databricks/models.

          databricks_client_secret: Databricks service principal secret. Required when using databricks/models.

          enable_revisions: Enable revision cycles. Recommended for very complex documents requiring
              reasoning, calculations, internal consistency. Also recommended if generated
              long or complex json/jsonl/csv documents in multi-file dataset mode. Incurs some
              extra cost and time so it's disabled by default.

          generation_model: Model for generation. Use -thinking suffix to enable thinking mode. For
              databricks/ models, you must also provide databricks_client_id,
              databricks_client_secret, and databricks_api_base.

          generation_thinking_budget: Token budget for extended thinking during generation. Only applies to models
              with -thinking suffix.

          max_examples_in_prompt: (advanced) Maximum number of seed examples to include in prompts. By default,
              only as many seeds as fit in 10K tokens are used. Use this to override the
              default.

          max_revision_cycles: Maximum number of revision cycles. 2-3 is a solid pick for complex documents
              requiring internal consistency, e.g. financial reports, invoices, etc.; increase
              to 3-5 for highest quality or when generated data has issues.

          outline_model: Model for outline generation

          outline_thinking_budget: Token budget for extended thinking during outline generation. Only applies to
              models with -thinking suffix.

          pdf_template_prompt: Prompt describing the desired PDF styling (e.g. 'Professional corporate style
              with blue headers'). When provided, an LLM generates custom CSS for PDF output.
              Only relevant for datasets containing PDF files.

          revision_model: Model for revisions (only used if enable_revisions is true)

          revision_thinking_budget: Token budget for extended thinking during revisions. Only applies to models with
              -thinking suffix.

          seed_shuffling_level: (advanced) How to shuffle seed examples between samples

          spec_version: Version number to use (optional, defaults to latest)

          unified_multifield: (advanced) Use unified multifield generation. This helps to reduce the
              generation cost by processing all fields together rather than one by one.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/dataframer/runs/",
            body=await async_maybe_transform(
                {
                    "number_of_samples": number_of_samples,
                    "spec_id": spec_id,
                    "databricks_api_base": databricks_api_base,
                    "databricks_client_id": databricks_client_id,
                    "databricks_client_secret": databricks_client_secret,
                    "enable_revisions": enable_revisions,
                    "generation_model": generation_model,
                    "generation_thinking_budget": generation_thinking_budget,
                    "max_examples_in_prompt": max_examples_in_prompt,
                    "max_revision_cycles": max_revision_cycles,
                    "outline_model": outline_model,
                    "outline_thinking_budget": outline_thinking_budget,
                    "pdf_template_prompt": pdf_template_prompt,
                    "revision_model": revision_model,
                    "revision_thinking_budget": revision_thinking_budget,
                    "seed_shuffling_level": seed_shuffling_level,
                    "spec_version": spec_version,
                    "unified_multifield": unified_multifield,
                },
                run_create_params.RunCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunCreateResponse,
        )

    async def retrieve(
        self,
        run_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunRetrieveResponse:
        """
        Get run details including status, progress (samples_completed/samples_failed),
        and generated_files when complete.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not run_id:
            raise ValueError(f"Expected a non-empty value for `run_id` but received {run_id!r}")
        return await self._get(
            f"/api/dataframer/runs/{run_id}/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunRetrieveResponse,
        )

    async def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RunListResponse:
        """List all generation runs for your company, newest first."""
        return await self._get(
            "/api/dataframer/runs/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RunListResponse,
        )

    async def delete(
        self,
        run_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a run and its generated files

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not run_id:
            raise ValueError(f"Expected a non-empty value for `run_id` but received {run_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/api/dataframer/runs/{run_id}/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def cancel(
        self,
        run_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Cancel a running generation job.

        Only PENDING or PROCESSING runs can be
        canceled.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not run_id:
            raise ValueError(f"Expected a non-empty value for `run_id` but received {run_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            f"/api/dataframer/runs/{run_id}/cancel/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class RunsResourceWithRawResponse:
    def __init__(self, runs: RunsResource) -> None:
        self._runs = runs

        self.create = to_raw_response_wrapper(
            runs.create,
        )
        self.retrieve = to_raw_response_wrapper(
            runs.retrieve,
        )
        self.list = to_raw_response_wrapper(
            runs.list,
        )
        self.delete = to_raw_response_wrapper(
            runs.delete,
        )
        self.cancel = to_raw_response_wrapper(
            runs.cancel,
        )

    @cached_property
    def evaluations(self) -> EvaluationsResourceWithRawResponse:
        return EvaluationsResourceWithRawResponse(self._runs.evaluations)

    @cached_property
    def files(self) -> FilesResourceWithRawResponse:
        return FilesResourceWithRawResponse(self._runs.files)


class AsyncRunsResourceWithRawResponse:
    def __init__(self, runs: AsyncRunsResource) -> None:
        self._runs = runs

        self.create = async_to_raw_response_wrapper(
            runs.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            runs.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            runs.list,
        )
        self.delete = async_to_raw_response_wrapper(
            runs.delete,
        )
        self.cancel = async_to_raw_response_wrapper(
            runs.cancel,
        )

    @cached_property
    def evaluations(self) -> AsyncEvaluationsResourceWithRawResponse:
        return AsyncEvaluationsResourceWithRawResponse(self._runs.evaluations)

    @cached_property
    def files(self) -> AsyncFilesResourceWithRawResponse:
        return AsyncFilesResourceWithRawResponse(self._runs.files)


class RunsResourceWithStreamingResponse:
    def __init__(self, runs: RunsResource) -> None:
        self._runs = runs

        self.create = to_streamed_response_wrapper(
            runs.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            runs.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            runs.list,
        )
        self.delete = to_streamed_response_wrapper(
            runs.delete,
        )
        self.cancel = to_streamed_response_wrapper(
            runs.cancel,
        )

    @cached_property
    def evaluations(self) -> EvaluationsResourceWithStreamingResponse:
        return EvaluationsResourceWithStreamingResponse(self._runs.evaluations)

    @cached_property
    def files(self) -> FilesResourceWithStreamingResponse:
        return FilesResourceWithStreamingResponse(self._runs.files)


class AsyncRunsResourceWithStreamingResponse:
    def __init__(self, runs: AsyncRunsResource) -> None:
        self._runs = runs

        self.create = async_to_streamed_response_wrapper(
            runs.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            runs.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            runs.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            runs.delete,
        )
        self.cancel = async_to_streamed_response_wrapper(
            runs.cancel,
        )

    @cached_property
    def evaluations(self) -> AsyncEvaluationsResourceWithStreamingResponse:
        return AsyncEvaluationsResourceWithStreamingResponse(self._runs.evaluations)

    @cached_property
    def files(self) -> AsyncFilesResourceWithStreamingResponse:
        return AsyncFilesResourceWithStreamingResponse(self._runs.files)
