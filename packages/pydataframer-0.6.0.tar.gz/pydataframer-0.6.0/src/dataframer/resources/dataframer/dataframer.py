# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .specs import (
    SpecsResource,
    AsyncSpecsResource,
    SpecsResourceWithRawResponse,
    AsyncSpecsResourceWithRawResponse,
    SpecsResourceWithStreamingResponse,
    AsyncSpecsResourceWithStreamingResponse,
)
from ..._compat import cached_property
from .runs.runs import (
    RunsResource,
    AsyncRunsResource,
    RunsResourceWithRawResponse,
    AsyncRunsResourceWithRawResponse,
    RunsResourceWithStreamingResponse,
    AsyncRunsResourceWithStreamingResponse,
)
from ..._resource import SyncAPIResource, AsyncAPIResource
from .evaluations import (
    EvaluationsResource,
    AsyncEvaluationsResource,
    EvaluationsResourceWithRawResponse,
    AsyncEvaluationsResourceWithRawResponse,
    EvaluationsResourceWithStreamingResponse,
    AsyncEvaluationsResourceWithStreamingResponse,
)
from .red_team_runs import (
    RedTeamRunsResource,
    AsyncRedTeamRunsResource,
    RedTeamRunsResourceWithRawResponse,
    AsyncRedTeamRunsResourceWithRawResponse,
    RedTeamRunsResourceWithStreamingResponse,
    AsyncRedTeamRunsResourceWithStreamingResponse,
)
from .red_team_specs import (
    RedTeamSpecsResource,
    AsyncRedTeamSpecsResource,
    RedTeamSpecsResourceWithRawResponse,
    AsyncRedTeamSpecsResourceWithRawResponse,
    RedTeamSpecsResourceWithStreamingResponse,
    AsyncRedTeamSpecsResourceWithStreamingResponse,
)
from .seed_datasets.seed_datasets import (
    SeedDatasetsResource,
    AsyncSeedDatasetsResource,
    SeedDatasetsResourceWithRawResponse,
    AsyncSeedDatasetsResourceWithRawResponse,
    SeedDatasetsResourceWithStreamingResponse,
    AsyncSeedDatasetsResourceWithStreamingResponse,
)

__all__ = ["DataframerResource", "AsyncDataframerResource"]


class DataframerResource(SyncAPIResource):
    @cached_property
    def seed_datasets(self) -> SeedDatasetsResource:
        return SeedDatasetsResource(self._client)

    @cached_property
    def evaluations(self) -> EvaluationsResource:
        return EvaluationsResource(self._client)

    @cached_property
    def red_team_runs(self) -> RedTeamRunsResource:
        return RedTeamRunsResource(self._client)

    @cached_property
    def red_team_specs(self) -> RedTeamSpecsResource:
        return RedTeamSpecsResource(self._client)

    @cached_property
    def runs(self) -> RunsResource:
        return RunsResource(self._client)

    @cached_property
    def specs(self) -> SpecsResource:
        return SpecsResource(self._client)

    @cached_property
    def with_raw_response(self) -> DataframerResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return DataframerResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> DataframerResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return DataframerResourceWithStreamingResponse(self)


class AsyncDataframerResource(AsyncAPIResource):
    @cached_property
    def seed_datasets(self) -> AsyncSeedDatasetsResource:
        return AsyncSeedDatasetsResource(self._client)

    @cached_property
    def evaluations(self) -> AsyncEvaluationsResource:
        return AsyncEvaluationsResource(self._client)

    @cached_property
    def red_team_runs(self) -> AsyncRedTeamRunsResource:
        return AsyncRedTeamRunsResource(self._client)

    @cached_property
    def red_team_specs(self) -> AsyncRedTeamSpecsResource:
        return AsyncRedTeamSpecsResource(self._client)

    @cached_property
    def runs(self) -> AsyncRunsResource:
        return AsyncRunsResource(self._client)

    @cached_property
    def specs(self) -> AsyncSpecsResource:
        return AsyncSpecsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncDataframerResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncDataframerResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncDataframerResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return AsyncDataframerResourceWithStreamingResponse(self)


class DataframerResourceWithRawResponse:
    def __init__(self, dataframer: DataframerResource) -> None:
        self._dataframer = dataframer

    @cached_property
    def seed_datasets(self) -> SeedDatasetsResourceWithRawResponse:
        return SeedDatasetsResourceWithRawResponse(self._dataframer.seed_datasets)

    @cached_property
    def evaluations(self) -> EvaluationsResourceWithRawResponse:
        return EvaluationsResourceWithRawResponse(self._dataframer.evaluations)

    @cached_property
    def red_team_runs(self) -> RedTeamRunsResourceWithRawResponse:
        return RedTeamRunsResourceWithRawResponse(self._dataframer.red_team_runs)

    @cached_property
    def red_team_specs(self) -> RedTeamSpecsResourceWithRawResponse:
        return RedTeamSpecsResourceWithRawResponse(self._dataframer.red_team_specs)

    @cached_property
    def runs(self) -> RunsResourceWithRawResponse:
        return RunsResourceWithRawResponse(self._dataframer.runs)

    @cached_property
    def specs(self) -> SpecsResourceWithRawResponse:
        return SpecsResourceWithRawResponse(self._dataframer.specs)


class AsyncDataframerResourceWithRawResponse:
    def __init__(self, dataframer: AsyncDataframerResource) -> None:
        self._dataframer = dataframer

    @cached_property
    def seed_datasets(self) -> AsyncSeedDatasetsResourceWithRawResponse:
        return AsyncSeedDatasetsResourceWithRawResponse(self._dataframer.seed_datasets)

    @cached_property
    def evaluations(self) -> AsyncEvaluationsResourceWithRawResponse:
        return AsyncEvaluationsResourceWithRawResponse(self._dataframer.evaluations)

    @cached_property
    def red_team_runs(self) -> AsyncRedTeamRunsResourceWithRawResponse:
        return AsyncRedTeamRunsResourceWithRawResponse(self._dataframer.red_team_runs)

    @cached_property
    def red_team_specs(self) -> AsyncRedTeamSpecsResourceWithRawResponse:
        return AsyncRedTeamSpecsResourceWithRawResponse(self._dataframer.red_team_specs)

    @cached_property
    def runs(self) -> AsyncRunsResourceWithRawResponse:
        return AsyncRunsResourceWithRawResponse(self._dataframer.runs)

    @cached_property
    def specs(self) -> AsyncSpecsResourceWithRawResponse:
        return AsyncSpecsResourceWithRawResponse(self._dataframer.specs)


class DataframerResourceWithStreamingResponse:
    def __init__(self, dataframer: DataframerResource) -> None:
        self._dataframer = dataframer

    @cached_property
    def seed_datasets(self) -> SeedDatasetsResourceWithStreamingResponse:
        return SeedDatasetsResourceWithStreamingResponse(self._dataframer.seed_datasets)

    @cached_property
    def evaluations(self) -> EvaluationsResourceWithStreamingResponse:
        return EvaluationsResourceWithStreamingResponse(self._dataframer.evaluations)

    @cached_property
    def red_team_runs(self) -> RedTeamRunsResourceWithStreamingResponse:
        return RedTeamRunsResourceWithStreamingResponse(self._dataframer.red_team_runs)

    @cached_property
    def red_team_specs(self) -> RedTeamSpecsResourceWithStreamingResponse:
        return RedTeamSpecsResourceWithStreamingResponse(self._dataframer.red_team_specs)

    @cached_property
    def runs(self) -> RunsResourceWithStreamingResponse:
        return RunsResourceWithStreamingResponse(self._dataframer.runs)

    @cached_property
    def specs(self) -> SpecsResourceWithStreamingResponse:
        return SpecsResourceWithStreamingResponse(self._dataframer.specs)


class AsyncDataframerResourceWithStreamingResponse:
    def __init__(self, dataframer: AsyncDataframerResource) -> None:
        self._dataframer = dataframer

    @cached_property
    def seed_datasets(self) -> AsyncSeedDatasetsResourceWithStreamingResponse:
        return AsyncSeedDatasetsResourceWithStreamingResponse(self._dataframer.seed_datasets)

    @cached_property
    def evaluations(self) -> AsyncEvaluationsResourceWithStreamingResponse:
        return AsyncEvaluationsResourceWithStreamingResponse(self._dataframer.evaluations)

    @cached_property
    def red_team_runs(self) -> AsyncRedTeamRunsResourceWithStreamingResponse:
        return AsyncRedTeamRunsResourceWithStreamingResponse(self._dataframer.red_team_runs)

    @cached_property
    def red_team_specs(self) -> AsyncRedTeamSpecsResourceWithStreamingResponse:
        return AsyncRedTeamSpecsResourceWithStreamingResponse(self._dataframer.red_team_specs)

    @cached_property
    def runs(self) -> AsyncRunsResourceWithStreamingResponse:
        return AsyncRunsResourceWithStreamingResponse(self._dataframer.runs)

    @cached_property
    def specs(self) -> AsyncSpecsResourceWithStreamingResponse:
        return AsyncSpecsResourceWithStreamingResponse(self._dataframer.specs)
