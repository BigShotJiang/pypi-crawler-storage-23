# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.dataframer import spec_create_params, spec_delete_params, spec_update_params, spec_retrieve_params
from ...types.dataframer.spec_list_response import SpecListResponse
from ...types.dataframer.spec_create_response import SpecCreateResponse
from ...types.dataframer.spec_update_response import SpecUpdateResponse
from ...types.dataframer.spec_retrieve_response import SpecRetrieveResponse

__all__ = ["SpecsResource", "AsyncSpecsResource"]


class SpecsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> SpecsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return SpecsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SpecsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return SpecsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        name: str,
        databricks_api_base: str | Omit = omit,
        databricks_client_id: str | Omit = omit,
        databricks_client_secret: str | Omit = omit,
        dataset_id: str | Omit = omit,
        description: str | Omit = omit,
        extrapolate_axes: bool | Omit = omit,
        extrapolate_values: bool | Omit = omit,
        generate_conditional_distributions: bool | Omit = omit,
        generate_distributions: bool | Omit = omit,
        generation_objectives: str | Omit = omit,
        spec_generation_model_name: Literal[
            "anthropic/claude-opus-4-6",
            "anthropic/claude-opus-4-6-thinking",
            "anthropic/claude-sonnet-4-6",
            "anthropic/claude-sonnet-4-6-thinking",
            "anthropic/claude-haiku-4-5",
            "anthropic/claude-haiku-4-5-thinking",
            "deepseek-ai/DeepSeek-V3.1",
            "moonshotai/Kimi-K2-Instruct",
            "openai/gpt-oss-120b",
            "deepseek-ai/DeepSeek-R1-0528-tput",
            "Qwen/Qwen2.5-72B-Instruct-Turbo",
            "gemini/gemini-3-pro-preview",
            "gemini/gemini-3-pro-preview-thinking",
            "databricks/databricks-claude-3-7-sonnet",
            "databricks/databricks-claude-haiku-4-5",
            "databricks/databricks-claude-opus-4-1",
            "databricks/databricks-claude-opus-4-5",
            "databricks/databricks-claude-opus-4-6",
            "databricks/databricks-claude-sonnet-4",
            "databricks/databricks-claude-sonnet-4-5",
            "databricks/databricks-gemini-2-5-flash",
            "databricks/databricks-gemini-2-5-pro",
            "databricks/databricks-gemini-3-flash",
            "databricks/databricks-gemini-3-pro",
            "databricks/databricks-gpt-5",
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SpecCreateResponse:
        """
        Generate a new spec (async operation).

        **Async operation**: This endpoint returns immediately with a spec ID. Poll
        `GET /api/dataframer/specs/{id}/` until status is `SUCCEEDED` or `FAILED`.

        For seeded specs: provide `dataset_id` (ID of an uploaded seed dataset). For
        seedless specs: provide `generation_objectives` (text describing what data to
        generate).

        Args:
          name: Name for the new spec (must be unique)

          databricks_api_base: Databricks Model Serving endpoint URL (e.g.
              https://adb-xxx.azuredatabricks.net/serving-endpoints). Required when using
              databricks/ models.

          databricks_client_id: Databricks service principal application (client) ID. Required when using
              databricks/ models.

          databricks_client_secret: Databricks service principal secret. Required when using databricks/ models.

          dataset_id: ID of the seed dataset to generate spec from. Omit for seedless spec creation.

          description: Description of the spec's purpose (optional, for data organization purposes
              only)

          extrapolate_axes: Extrapolate to new axes/dimensions not present in seed data. Not applicable for
              seedless specs.

          extrapolate_values: Extrapolate new values beyond existing data ranges. Not applicable for seedless
              specs.

          generate_conditional_distributions: Generate conditional distributions showing how property values vary based on
              other properties. Requires generate_distributions to be true.

          generate_distributions: When true, the spec will include generated probability distributions for each
              property value; when false, each property will have a uniform distribution.

          generation_objectives: Custom objectives or instructions for data generation that directly influence
              contents of the generated spec. Required for seedless specs (when dataset_id is
              omitted).

          spec_generation_model_name: AI model to use for spec generation. For databricks/ models, you must also
              provide databricks_client_id, databricks_client_secret, and databricks_api_base.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/dataframer/specs/",
            body=maybe_transform(
                {
                    "name": name,
                    "databricks_api_base": databricks_api_base,
                    "databricks_client_id": databricks_client_id,
                    "databricks_client_secret": databricks_client_secret,
                    "dataset_id": dataset_id,
                    "description": description,
                    "extrapolate_axes": extrapolate_axes,
                    "extrapolate_values": extrapolate_values,
                    "generate_conditional_distributions": generate_conditional_distributions,
                    "generate_distributions": generate_distributions,
                    "generation_objectives": generation_objectives,
                    "spec_generation_model_name": spec_generation_model_name,
                },
                spec_create_params.SpecCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SpecCreateResponse,
        )

    def retrieve(
        self,
        spec_id: str,
        *,
        include_versions: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SpecRetrieveResponse:
        """Get spec details including status, YAML configuration, and versions.

        Also use
        this endpoint to poll spec creation status while it is still PROCESSING.

        Args:
          include_versions: Include all previous spec versions in the response

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not spec_id:
            raise ValueError(f"Expected a non-empty value for `spec_id` but received {spec_id!r}")
        return self._get(
            f"/api/dataframer/specs/{spec_id}/",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"include_versions": include_versions}, spec_retrieve_params.SpecRetrieveParams),
            ),
            cast_to=SpecRetrieveResponse,
        )

    def update(
        self,
        spec_id: str,
        *,
        content_yaml: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SpecUpdateResponse:
        """
        Replace the spec's YAML configuration with a new version.

        Each update creates a new version. Previous versions are preserved and can be
        retrieved using `include_versions=true` on the GET endpoint.

        To check the expected spec YAML format, check the YAML section in spec view in
        the UI, or look at YAML returned by the Get spec API endpoint. Only the `spec:`
        section is editable - the `metadata:` section is read-only and ignored.

        Args:
          content_yaml: Complete YAML spec configuration replacing its previous version in the spec. The
              YAML should have a 'spec' root key containing one or more editable fields:
              description, requirements, data_property_variations, selected_sql_schema_column,
              selected_sql_query_columns. To check the expected spec YAML format, check the
              YAML section in spec view in the UI, or look at YAML returned by the Get spec
              API endpoint. If a 'metadata' section is present, it is ignored (read-only).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not spec_id:
            raise ValueError(f"Expected a non-empty value for `spec_id` but received {spec_id!r}")
        return self._put(
            f"/api/dataframer/specs/{spec_id}/",
            body=maybe_transform({"content_yaml": content_yaml}, spec_update_params.SpecUpdateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SpecUpdateResponse,
        )

    def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SpecListResponse:
        """List all specs for your company.

        Shows name, status, dataset info, and creation
        time.
        """
        return self._get(
            "/api/dataframer/specs/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SpecListResponse,
        )

    def delete(
        self,
        spec_id: str,
        *,
        force: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a spec by ID

        Args:
          force: If true, delete the spec and all associated runs (including their generated
              files). If false or omitted, returns an error when runs exist.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not spec_id:
            raise ValueError(f"Expected a non-empty value for `spec_id` but received {spec_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/api/dataframer/specs/{spec_id}/",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"force": force}, spec_delete_params.SpecDeleteParams),
            ),
            cast_to=NoneType,
        )


class AsyncSpecsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncSpecsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncSpecsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSpecsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return AsyncSpecsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        name: str,
        databricks_api_base: str | Omit = omit,
        databricks_client_id: str | Omit = omit,
        databricks_client_secret: str | Omit = omit,
        dataset_id: str | Omit = omit,
        description: str | Omit = omit,
        extrapolate_axes: bool | Omit = omit,
        extrapolate_values: bool | Omit = omit,
        generate_conditional_distributions: bool | Omit = omit,
        generate_distributions: bool | Omit = omit,
        generation_objectives: str | Omit = omit,
        spec_generation_model_name: Literal[
            "anthropic/claude-opus-4-6",
            "anthropic/claude-opus-4-6-thinking",
            "anthropic/claude-sonnet-4-6",
            "anthropic/claude-sonnet-4-6-thinking",
            "anthropic/claude-haiku-4-5",
            "anthropic/claude-haiku-4-5-thinking",
            "deepseek-ai/DeepSeek-V3.1",
            "moonshotai/Kimi-K2-Instruct",
            "openai/gpt-oss-120b",
            "deepseek-ai/DeepSeek-R1-0528-tput",
            "Qwen/Qwen2.5-72B-Instruct-Turbo",
            "gemini/gemini-3-pro-preview",
            "gemini/gemini-3-pro-preview-thinking",
            "databricks/databricks-claude-3-7-sonnet",
            "databricks/databricks-claude-haiku-4-5",
            "databricks/databricks-claude-opus-4-1",
            "databricks/databricks-claude-opus-4-5",
            "databricks/databricks-claude-opus-4-6",
            "databricks/databricks-claude-sonnet-4",
            "databricks/databricks-claude-sonnet-4-5",
            "databricks/databricks-gemini-2-5-flash",
            "databricks/databricks-gemini-2-5-pro",
            "databricks/databricks-gemini-3-flash",
            "databricks/databricks-gemini-3-pro",
            "databricks/databricks-gpt-5",
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SpecCreateResponse:
        """
        Generate a new spec (async operation).

        **Async operation**: This endpoint returns immediately with a spec ID. Poll
        `GET /api/dataframer/specs/{id}/` until status is `SUCCEEDED` or `FAILED`.

        For seeded specs: provide `dataset_id` (ID of an uploaded seed dataset). For
        seedless specs: provide `generation_objectives` (text describing what data to
        generate).

        Args:
          name: Name for the new spec (must be unique)

          databricks_api_base: Databricks Model Serving endpoint URL (e.g.
              https://adb-xxx.azuredatabricks.net/serving-endpoints). Required when using
              databricks/ models.

          databricks_client_id: Databricks service principal application (client) ID. Required when using
              databricks/ models.

          databricks_client_secret: Databricks service principal secret. Required when using databricks/ models.

          dataset_id: ID of the seed dataset to generate spec from. Omit for seedless spec creation.

          description: Description of the spec's purpose (optional, for data organization purposes
              only)

          extrapolate_axes: Extrapolate to new axes/dimensions not present in seed data. Not applicable for
              seedless specs.

          extrapolate_values: Extrapolate new values beyond existing data ranges. Not applicable for seedless
              specs.

          generate_conditional_distributions: Generate conditional distributions showing how property values vary based on
              other properties. Requires generate_distributions to be true.

          generate_distributions: When true, the spec will include generated probability distributions for each
              property value; when false, each property will have a uniform distribution.

          generation_objectives: Custom objectives or instructions for data generation that directly influence
              contents of the generated spec. Required for seedless specs (when dataset_id is
              omitted).

          spec_generation_model_name: AI model to use for spec generation. For databricks/ models, you must also
              provide databricks_client_id, databricks_client_secret, and databricks_api_base.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/dataframer/specs/",
            body=await async_maybe_transform(
                {
                    "name": name,
                    "databricks_api_base": databricks_api_base,
                    "databricks_client_id": databricks_client_id,
                    "databricks_client_secret": databricks_client_secret,
                    "dataset_id": dataset_id,
                    "description": description,
                    "extrapolate_axes": extrapolate_axes,
                    "extrapolate_values": extrapolate_values,
                    "generate_conditional_distributions": generate_conditional_distributions,
                    "generate_distributions": generate_distributions,
                    "generation_objectives": generation_objectives,
                    "spec_generation_model_name": spec_generation_model_name,
                },
                spec_create_params.SpecCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SpecCreateResponse,
        )

    async def retrieve(
        self,
        spec_id: str,
        *,
        include_versions: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SpecRetrieveResponse:
        """Get spec details including status, YAML configuration, and versions.

        Also use
        this endpoint to poll spec creation status while it is still PROCESSING.

        Args:
          include_versions: Include all previous spec versions in the response

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not spec_id:
            raise ValueError(f"Expected a non-empty value for `spec_id` but received {spec_id!r}")
        return await self._get(
            f"/api/dataframer/specs/{spec_id}/",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"include_versions": include_versions}, spec_retrieve_params.SpecRetrieveParams
                ),
            ),
            cast_to=SpecRetrieveResponse,
        )

    async def update(
        self,
        spec_id: str,
        *,
        content_yaml: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SpecUpdateResponse:
        """
        Replace the spec's YAML configuration with a new version.

        Each update creates a new version. Previous versions are preserved and can be
        retrieved using `include_versions=true` on the GET endpoint.

        To check the expected spec YAML format, check the YAML section in spec view in
        the UI, or look at YAML returned by the Get spec API endpoint. Only the `spec:`
        section is editable - the `metadata:` section is read-only and ignored.

        Args:
          content_yaml: Complete YAML spec configuration replacing its previous version in the spec. The
              YAML should have a 'spec' root key containing one or more editable fields:
              description, requirements, data_property_variations, selected_sql_schema_column,
              selected_sql_query_columns. To check the expected spec YAML format, check the
              YAML section in spec view in the UI, or look at YAML returned by the Get spec
              API endpoint. If a 'metadata' section is present, it is ignored (read-only).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not spec_id:
            raise ValueError(f"Expected a non-empty value for `spec_id` but received {spec_id!r}")
        return await self._put(
            f"/api/dataframer/specs/{spec_id}/",
            body=await async_maybe_transform({"content_yaml": content_yaml}, spec_update_params.SpecUpdateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SpecUpdateResponse,
        )

    async def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SpecListResponse:
        """List all specs for your company.

        Shows name, status, dataset info, and creation
        time.
        """
        return await self._get(
            "/api/dataframer/specs/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SpecListResponse,
        )

    async def delete(
        self,
        spec_id: str,
        *,
        force: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Delete a spec by ID

        Args:
          force: If true, delete the spec and all associated runs (including their generated
              files). If false or omitted, returns an error when runs exist.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not spec_id:
            raise ValueError(f"Expected a non-empty value for `spec_id` but received {spec_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/api/dataframer/specs/{spec_id}/",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"force": force}, spec_delete_params.SpecDeleteParams),
            ),
            cast_to=NoneType,
        )


class SpecsResourceWithRawResponse:
    def __init__(self, specs: SpecsResource) -> None:
        self._specs = specs

        self.create = to_raw_response_wrapper(
            specs.create,
        )
        self.retrieve = to_raw_response_wrapper(
            specs.retrieve,
        )
        self.update = to_raw_response_wrapper(
            specs.update,
        )
        self.list = to_raw_response_wrapper(
            specs.list,
        )
        self.delete = to_raw_response_wrapper(
            specs.delete,
        )


class AsyncSpecsResourceWithRawResponse:
    def __init__(self, specs: AsyncSpecsResource) -> None:
        self._specs = specs

        self.create = async_to_raw_response_wrapper(
            specs.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            specs.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            specs.update,
        )
        self.list = async_to_raw_response_wrapper(
            specs.list,
        )
        self.delete = async_to_raw_response_wrapper(
            specs.delete,
        )


class SpecsResourceWithStreamingResponse:
    def __init__(self, specs: SpecsResource) -> None:
        self._specs = specs

        self.create = to_streamed_response_wrapper(
            specs.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            specs.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            specs.update,
        )
        self.list = to_streamed_response_wrapper(
            specs.list,
        )
        self.delete = to_streamed_response_wrapper(
            specs.delete,
        )


class AsyncSpecsResourceWithStreamingResponse:
    def __init__(self, specs: AsyncSpecsResource) -> None:
        self._specs = specs

        self.create = async_to_streamed_response_wrapper(
            specs.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            specs.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            specs.update,
        )
        self.list = async_to_streamed_response_wrapper(
            specs.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            specs.delete,
        )
