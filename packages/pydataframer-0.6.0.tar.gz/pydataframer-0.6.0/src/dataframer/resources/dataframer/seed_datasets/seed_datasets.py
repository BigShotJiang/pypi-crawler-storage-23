# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Mapping, cast
from typing_extensions import Literal

import httpx

from .files import (
    FilesResource,
    AsyncFilesResource,
    FilesResourceWithRawResponse,
    AsyncFilesResourceWithRawResponse,
    FilesResourceWithStreamingResponse,
    AsyncFilesResourceWithStreamingResponse,
)
from ...._types import (
    Body,
    Omit,
    Query,
    Headers,
    NoneType,
    NotGiven,
    FileTypes,
    SequenceNotStr,
    omit,
    not_given,
)
from ...._utils import extract_files, maybe_transform, deepcopy_minimal, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.dataframer import seed_dataset_create_from_zip_params, seed_dataset_create_with_files_params
from ....types.dataframer.seed_dataset_list_response import SeedDatasetListResponse
from ....types.dataframer.seed_dataset_retrieve_response import SeedDatasetRetrieveResponse
from ....types.dataframer.seed_dataset_create_from_zip_response import SeedDatasetCreateFromZipResponse
from ....types.dataframer.seed_dataset_create_with_files_response import SeedDatasetCreateWithFilesResponse

__all__ = ["SeedDatasetsResource", "AsyncSeedDatasetsResource"]


class SeedDatasetsResource(SyncAPIResource):
    @cached_property
    def files(self) -> FilesResource:
        return FilesResource(self._client)

    @cached_property
    def with_raw_response(self) -> SeedDatasetsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return SeedDatasetsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SeedDatasetsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return SeedDatasetsResourceWithStreamingResponse(self)

    def retrieve(
        self,
        dataset_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeedDatasetRetrieveResponse:
        """
        Get a seed dataset by ID, including its list of files

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not dataset_id:
            raise ValueError(f"Expected a non-empty value for `dataset_id` but received {dataset_id!r}")
        return self._get(
            f"/api/dataframer/seed-datasets/{dataset_id}/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SeedDatasetRetrieveResponse,
        )

    def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeedDatasetListResponse:
        """Get all seed datasets for your company"""
        return self._get(
            "/api/dataframer/seed-datasets/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SeedDatasetListResponse,
        )

    def delete(
        self,
        dataset_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Delete a seed dataset and all its files.

        Cannot delete if referenced by specs.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not dataset_id:
            raise ValueError(f"Expected a non-empty value for `dataset_id` but received {dataset_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/api/dataframer/seed-datasets/{dataset_id}/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def create_from_zip(
        self,
        *,
        name: str,
        zip_file: FileTypes,
        description: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeedDatasetCreateFromZipResponse:
        """
        Create a seed dataset by uploading a ZIP file.

        The system automatically detects the dataset type based on ZIP structure:

        - **SINGLE_FILE**: ZIP contains exactly one file containing all the samples
        - **MULTI_FILE**: ZIP contains multiple files at root level, where each file is
          a separate sample
        - **MULTI_FOLDER**: ZIP contains multiple folders, where each folder is a
          separate sample and only contains files with no nested folders

        ## File constraints by dataset type

        | Type         | Allowed formats                | Size limit           | Count limit                            |
        | ------------ | ------------------------------ | -------------------- | -------------------------------------- |
        | SINGLE_FILE  | CSV, JSON, JSONL               | 50MB                 | 1 file, min 2 rows                     |
        | MULTI_FILE   | TXT, MD, JSON, CSV, JSONL, PDF | 1MB/file, 50MB total | 2-1000 files                           |
        | MULTI_FOLDER | TXT, MD, JSON, CSV, JSONL, PDF | 1MB/file, 50MB total | 2-1000 files, 20/folder, min 2 folders |

        Args:
          name: Dataset name (unique within company)

          zip_file: ZIP file containing dataset files

          description: Optional dataset description

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        body = deepcopy_minimal(
            {
                "name": name,
                "zip_file": zip_file,
                "description": description,
            }
        )
        files = extract_files(cast(Mapping[str, object], body), paths=[["zip_file"]])
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return self._post(
            "/api/dataframer/seed-datasets/create-from-zip/",
            body=maybe_transform(body, seed_dataset_create_from_zip_params.SeedDatasetCreateFromZipParams),
            files=files,
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SeedDatasetCreateFromZipResponse,
        )

    def create_with_files(
        self,
        *,
        dataset_type: Literal["SINGLE_FILE", "MULTI_FILE", "MULTI_FOLDER"],
        files: SequenceNotStr[FileTypes],
        name: str,
        description: str | Omit = omit,
        folder_names: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeedDatasetCreateWithFilesResponse:
        """Create a new seed dataset the platform learns from, with uploaded files.

        After
        creation, use create_spec with the returned dataset ID.

        You can upload one of the following types of datasets:

        - **SINGLE_FILE**: exactly one file containing all the samples
        - **MULTI_FILE**: multiple files, where each file is a separate sample
        - **MULTI_FOLDER**: multiple folders, where each folder is a separate sample and
          only contains files with no nested folders

        ## File constraints by dataset type

        | Type         | Allowed formats                | Size limit           | Count limit                            |
        | ------------ | ------------------------------ | -------------------- | -------------------------------------- |
        | SINGLE_FILE  | CSV, JSON, JSONL               | 50MB                 | 1 file, min 2 rows                     |
        | MULTI_FILE   | TXT, MD, JSON, CSV, JSONL, PDF | 1MB/file, 50MB total | 2-1000 files                           |
        | MULTI_FOLDER | TXT, MD, JSON, CSV, JSONL, PDF | 1MB/file, 50MB total | 2-1000 files, 20/folder, min 2 folders |

        Args:
          files: Files to upload. SINGLE_FILE: exactly 1 file. MULTI_FILE: 2+ files.
              MULTI_FOLDER: 2+ files with corresponding folder_names.

          name: Dataset name (must be unique)

          description: Optional dataset description

          folder_names:
              Folder names for MULTI_FOLDER datasets. This is a parallel array with files:
              folder_names[i] specifies which folder files[i] belongs to (e.g., if
              files=['a.txt', 'b.txt'] and folder_names=['doc1', 'doc2'], then a.txt goes in
              doc1, b.txt goes in doc2). Minimum 2 unique folder names required.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        body = deepcopy_minimal(
            {
                "dataset_type": dataset_type,
                "files": files,
                "name": name,
                "description": description,
                "folder_names": folder_names,
            }
        )
        extracted_files = extract_files(cast(Mapping[str, object], body), paths=[["files", "<array>"]])
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return self._post(
            "/api/dataframer/seed-datasets/create/",
            body=maybe_transform(body, seed_dataset_create_with_files_params.SeedDatasetCreateWithFilesParams),
            files=extracted_files,
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SeedDatasetCreateWithFilesResponse,
        )


class AsyncSeedDatasetsResource(AsyncAPIResource):
    @cached_property
    def files(self) -> AsyncFilesResource:
        return AsyncFilesResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncSeedDatasetsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncSeedDatasetsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSeedDatasetsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/aimonlabs/dataframer-python-sdk#with_streaming_response
        """
        return AsyncSeedDatasetsResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        dataset_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeedDatasetRetrieveResponse:
        """
        Get a seed dataset by ID, including its list of files

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not dataset_id:
            raise ValueError(f"Expected a non-empty value for `dataset_id` but received {dataset_id!r}")
        return await self._get(
            f"/api/dataframer/seed-datasets/{dataset_id}/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SeedDatasetRetrieveResponse,
        )

    async def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeedDatasetListResponse:
        """Get all seed datasets for your company"""
        return await self._get(
            "/api/dataframer/seed-datasets/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SeedDatasetListResponse,
        )

    async def delete(
        self,
        dataset_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Delete a seed dataset and all its files.

        Cannot delete if referenced by specs.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not dataset_id:
            raise ValueError(f"Expected a non-empty value for `dataset_id` but received {dataset_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/api/dataframer/seed-datasets/{dataset_id}/",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def create_from_zip(
        self,
        *,
        name: str,
        zip_file: FileTypes,
        description: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeedDatasetCreateFromZipResponse:
        """
        Create a seed dataset by uploading a ZIP file.

        The system automatically detects the dataset type based on ZIP structure:

        - **SINGLE_FILE**: ZIP contains exactly one file containing all the samples
        - **MULTI_FILE**: ZIP contains multiple files at root level, where each file is
          a separate sample
        - **MULTI_FOLDER**: ZIP contains multiple folders, where each folder is a
          separate sample and only contains files with no nested folders

        ## File constraints by dataset type

        | Type         | Allowed formats                | Size limit           | Count limit                            |
        | ------------ | ------------------------------ | -------------------- | -------------------------------------- |
        | SINGLE_FILE  | CSV, JSON, JSONL               | 50MB                 | 1 file, min 2 rows                     |
        | MULTI_FILE   | TXT, MD, JSON, CSV, JSONL, PDF | 1MB/file, 50MB total | 2-1000 files                           |
        | MULTI_FOLDER | TXT, MD, JSON, CSV, JSONL, PDF | 1MB/file, 50MB total | 2-1000 files, 20/folder, min 2 folders |

        Args:
          name: Dataset name (unique within company)

          zip_file: ZIP file containing dataset files

          description: Optional dataset description

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        body = deepcopy_minimal(
            {
                "name": name,
                "zip_file": zip_file,
                "description": description,
            }
        )
        files = extract_files(cast(Mapping[str, object], body), paths=[["zip_file"]])
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return await self._post(
            "/api/dataframer/seed-datasets/create-from-zip/",
            body=await async_maybe_transform(body, seed_dataset_create_from_zip_params.SeedDatasetCreateFromZipParams),
            files=files,
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SeedDatasetCreateFromZipResponse,
        )

    async def create_with_files(
        self,
        *,
        dataset_type: Literal["SINGLE_FILE", "MULTI_FILE", "MULTI_FOLDER"],
        files: SequenceNotStr[FileTypes],
        name: str,
        description: str | Omit = omit,
        folder_names: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeedDatasetCreateWithFilesResponse:
        """Create a new seed dataset the platform learns from, with uploaded files.

        After
        creation, use create_spec with the returned dataset ID.

        You can upload one of the following types of datasets:

        - **SINGLE_FILE**: exactly one file containing all the samples
        - **MULTI_FILE**: multiple files, where each file is a separate sample
        - **MULTI_FOLDER**: multiple folders, where each folder is a separate sample and
          only contains files with no nested folders

        ## File constraints by dataset type

        | Type         | Allowed formats                | Size limit           | Count limit                            |
        | ------------ | ------------------------------ | -------------------- | -------------------------------------- |
        | SINGLE_FILE  | CSV, JSON, JSONL               | 50MB                 | 1 file, min 2 rows                     |
        | MULTI_FILE   | TXT, MD, JSON, CSV, JSONL, PDF | 1MB/file, 50MB total | 2-1000 files                           |
        | MULTI_FOLDER | TXT, MD, JSON, CSV, JSONL, PDF | 1MB/file, 50MB total | 2-1000 files, 20/folder, min 2 folders |

        Args:
          files: Files to upload. SINGLE_FILE: exactly 1 file. MULTI_FILE: 2+ files.
              MULTI_FOLDER: 2+ files with corresponding folder_names.

          name: Dataset name (must be unique)

          description: Optional dataset description

          folder_names:
              Folder names for MULTI_FOLDER datasets. This is a parallel array with files:
              folder_names[i] specifies which folder files[i] belongs to (e.g., if
              files=['a.txt', 'b.txt'] and folder_names=['doc1', 'doc2'], then a.txt goes in
              doc1, b.txt goes in doc2). Minimum 2 unique folder names required.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        body = deepcopy_minimal(
            {
                "dataset_type": dataset_type,
                "files": files,
                "name": name,
                "description": description,
                "folder_names": folder_names,
            }
        )
        extracted_files = extract_files(cast(Mapping[str, object], body), paths=[["files", "<array>"]])
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return await self._post(
            "/api/dataframer/seed-datasets/create/",
            body=await async_maybe_transform(
                body, seed_dataset_create_with_files_params.SeedDatasetCreateWithFilesParams
            ),
            files=extracted_files,
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SeedDatasetCreateWithFilesResponse,
        )


class SeedDatasetsResourceWithRawResponse:
    def __init__(self, seed_datasets: SeedDatasetsResource) -> None:
        self._seed_datasets = seed_datasets

        self.retrieve = to_raw_response_wrapper(
            seed_datasets.retrieve,
        )
        self.list = to_raw_response_wrapper(
            seed_datasets.list,
        )
        self.delete = to_raw_response_wrapper(
            seed_datasets.delete,
        )
        self.create_from_zip = to_raw_response_wrapper(
            seed_datasets.create_from_zip,
        )
        self.create_with_files = to_raw_response_wrapper(
            seed_datasets.create_with_files,
        )

    @cached_property
    def files(self) -> FilesResourceWithRawResponse:
        return FilesResourceWithRawResponse(self._seed_datasets.files)


class AsyncSeedDatasetsResourceWithRawResponse:
    def __init__(self, seed_datasets: AsyncSeedDatasetsResource) -> None:
        self._seed_datasets = seed_datasets

        self.retrieve = async_to_raw_response_wrapper(
            seed_datasets.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            seed_datasets.list,
        )
        self.delete = async_to_raw_response_wrapper(
            seed_datasets.delete,
        )
        self.create_from_zip = async_to_raw_response_wrapper(
            seed_datasets.create_from_zip,
        )
        self.create_with_files = async_to_raw_response_wrapper(
            seed_datasets.create_with_files,
        )

    @cached_property
    def files(self) -> AsyncFilesResourceWithRawResponse:
        return AsyncFilesResourceWithRawResponse(self._seed_datasets.files)


class SeedDatasetsResourceWithStreamingResponse:
    def __init__(self, seed_datasets: SeedDatasetsResource) -> None:
        self._seed_datasets = seed_datasets

        self.retrieve = to_streamed_response_wrapper(
            seed_datasets.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            seed_datasets.list,
        )
        self.delete = to_streamed_response_wrapper(
            seed_datasets.delete,
        )
        self.create_from_zip = to_streamed_response_wrapper(
            seed_datasets.create_from_zip,
        )
        self.create_with_files = to_streamed_response_wrapper(
            seed_datasets.create_with_files,
        )

    @cached_property
    def files(self) -> FilesResourceWithStreamingResponse:
        return FilesResourceWithStreamingResponse(self._seed_datasets.files)


class AsyncSeedDatasetsResourceWithStreamingResponse:
    def __init__(self, seed_datasets: AsyncSeedDatasetsResource) -> None:
        self._seed_datasets = seed_datasets

        self.retrieve = async_to_streamed_response_wrapper(
            seed_datasets.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            seed_datasets.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            seed_datasets.delete,
        )
        self.create_from_zip = async_to_streamed_response_wrapper(
            seed_datasets.create_from_zip,
        )
        self.create_with_files = async_to_streamed_response_wrapper(
            seed_datasets.create_with_files,
        )

    @cached_property
    def files(self) -> AsyncFilesResourceWithStreamingResponse:
        return AsyncFilesResourceWithStreamingResponse(self._seed_datasets.files)
