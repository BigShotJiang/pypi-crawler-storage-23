# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["RedTeamRunRetrieveResponse", "ResultsJson", "ResultsJsonBehaviorToEnhancedQuery"]


class ResultsJsonBehaviorToEnhancedQuery(BaseModel):
    """An adversarial query with its enhanced prompt"""

    adversarial_prompt: Optional[str] = None
    """The adversarially enhanced version of the query designed to bypass safeguards"""

    query: Optional[str] = None
    """The original query that could trigger the undesirable behavior"""


class ResultsJson(BaseModel):
    """Generated adversarial behaviors and prompts (null while running)"""

    behavior_to_enhanced_queries: Optional[Dict[str, List[ResultsJsonBehaviorToEnhancedQuery]]] = None
    """Map of behavior descriptions to their generated adversarial prompts"""


class RedTeamRunRetrieveResponse(BaseModel):
    """A red team run that generates adversarial prompts based on a spec"""

    id: Optional[str] = None
    """Unique identifier for the run"""

    company_id: Optional[str] = None
    """ID of the company that owns this run"""

    company_name: Optional[str] = None
    """Name of the company that owns this run"""

    completed_at: Optional[datetime] = None
    """Timestamp when the run completed (null if still running)"""

    created_at: Optional[datetime] = None
    """Timestamp when the run was created"""

    created_by: Optional[int] = None
    """ID of the user who created this run"""

    created_by_email: Optional[str] = None
    """Email of the user who created this run"""

    error_message: Optional[str] = None
    """Error message if the run failed"""

    api_model_name: Optional[
        Literal[
            "deepseek-ai/DeepSeek-V3.1",
            "deepseek-ai/DeepSeek-R1-0528-tput",
            "moonshotai/Kimi-K2-Instruct",
            "openai/gpt-oss-120b",
        ]
    ] = FieldInfo(alias="model_name", default=None)
    """Model to use for generating adversarial prompts"""

    number_of_behaviors: Optional[int] = None
    """Number of adversarial behaviors to generate"""

    number_of_prompts_per_behavior: Optional[int] = None
    """Number of adversarial prompts to generate for each behavior"""

    red_team_spec_id: Optional[str] = None
    """ID of the red team spec used for this run"""

    results_json: Optional[ResultsJson] = None
    """Generated adversarial behaviors and prompts (null while running)"""

    spec_name: Optional[str] = None
    """Name of the associated red team spec"""

    status: Optional[Literal["PENDING", "PROCESSING", "SUCCEEDED", "FAILED", "CANCELED"]] = None
    """Current status of the run"""

    task_id: Optional[str] = None
    """Internal task ID for tracking the async job"""

    trace: Optional[object] = None
    """Execution trace for debugging (internal use)"""
