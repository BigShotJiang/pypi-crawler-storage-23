# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["RunCreateParams"]


class RunCreateParams(TypedDict, total=False):
    number_of_samples: Required[int]
    """Number of samples to generate"""

    spec_id: Required[str]
    """ID of the spec to use for generation. Spec must be in SUCCEEDED status."""

    databricks_api_base: str
    """Databricks Model Serving endpoint URL (e.g.

    https://adb-xxx.azuredatabricks.net/serving-endpoints). Required when using
    databricks/models.
    """

    databricks_client_id: str
    """Databricks service principal application (client) ID.

    Required when using databricks/models.
    """

    databricks_client_secret: str
    """Databricks service principal secret. Required when using databricks/models."""

    enable_revisions: bool
    """Enable revision cycles.

    Recommended for very complex documents requiring reasoning, calculations,
    internal consistency. Also recommended if generated long or complex
    json/jsonl/csv documents in multi-file dataset mode. Incurs some extra cost and
    time so it's disabled by default.
    """

    generation_model: Literal[
        "anthropic/claude-opus-4-6",
        "anthropic/claude-opus-4-6-thinking",
        "anthropic/claude-sonnet-4-6",
        "anthropic/claude-sonnet-4-6-thinking",
        "anthropic/claude-haiku-4-5",
        "anthropic/claude-haiku-4-5-thinking",
        "deepseek-ai/DeepSeek-V3.1",
        "moonshotai/Kimi-K2-Instruct",
        "openai/gpt-oss-120b",
        "deepseek-ai/DeepSeek-R1-0528-tput",
        "Qwen/Qwen2.5-72B-Instruct-Turbo",
        "gemini/gemini-3-pro-preview",
        "gemini/gemini-3-pro-preview-thinking",
        "databricks/databricks-claude-3-7-sonnet",
        "databricks/databricks-claude-haiku-4-5",
        "databricks/databricks-claude-opus-4-1",
        "databricks/databricks-claude-opus-4-5",
        "databricks/databricks-claude-opus-4-6",
        "databricks/databricks-claude-sonnet-4",
        "databricks/databricks-claude-sonnet-4-5",
        "databricks/databricks-gemini-2-5-flash",
        "databricks/databricks-gemini-2-5-pro",
        "databricks/databricks-gemini-3-flash",
        "databricks/databricks-gemini-3-pro",
        "databricks/databricks-gpt-5",
    ]
    """Model for generation.

    Use -thinking suffix to enable thinking mode. For databricks/ models, you must
    also provide databricks_client_id, databricks_client_secret, and
    databricks_api_base.
    """

    generation_thinking_budget: int
    """Token budget for extended thinking during generation.

    Only applies to models with -thinking suffix.
    """

    max_examples_in_prompt: int
    """(advanced) Maximum number of seed examples to include in prompts.

    By default, only as many seeds as fit in 10K tokens are used. Use this to
    override the default.
    """

    max_revision_cycles: int
    """Maximum number of revision cycles.

    2-3 is a solid pick for complex documents requiring internal consistency, e.g.
    financial reports, invoices, etc.; increase to 3-5 for highest quality or when
    generated data has issues.
    """

    outline_model: Literal[
        "anthropic/claude-opus-4-6",
        "anthropic/claude-opus-4-6-thinking",
        "anthropic/claude-sonnet-4-6",
        "anthropic/claude-sonnet-4-6-thinking",
        "anthropic/claude-haiku-4-5",
        "anthropic/claude-haiku-4-5-thinking",
        "deepseek-ai/DeepSeek-V3.1",
        "moonshotai/Kimi-K2-Instruct",
        "openai/gpt-oss-120b",
        "deepseek-ai/DeepSeek-R1-0528-tput",
        "Qwen/Qwen2.5-72B-Instruct-Turbo",
        "gemini/gemini-3-pro-preview",
        "gemini/gemini-3-pro-preview-thinking",
        "databricks/databricks-claude-3-7-sonnet",
        "databricks/databricks-claude-haiku-4-5",
        "databricks/databricks-claude-opus-4-1",
        "databricks/databricks-claude-opus-4-5",
        "databricks/databricks-claude-opus-4-6",
        "databricks/databricks-claude-sonnet-4",
        "databricks/databricks-claude-sonnet-4-5",
        "databricks/databricks-gemini-2-5-flash",
        "databricks/databricks-gemini-2-5-pro",
        "databricks/databricks-gemini-3-flash",
        "databricks/databricks-gemini-3-pro",
        "databricks/databricks-gpt-5",
    ]
    """Model for outline generation"""

    outline_thinking_budget: int
    """Token budget for extended thinking during outline generation.

    Only applies to models with -thinking suffix.
    """

    pdf_template_prompt: str
    """Prompt describing the desired PDF styling (e.g.

    'Professional corporate style with blue headers'). When provided, an LLM
    generates custom CSS for PDF output. Only relevant for datasets containing PDF
    files.
    """

    revision_model: Literal[
        "anthropic/claude-opus-4-6",
        "anthropic/claude-opus-4-6-thinking",
        "anthropic/claude-sonnet-4-6",
        "anthropic/claude-sonnet-4-6-thinking",
        "anthropic/claude-haiku-4-5",
        "anthropic/claude-haiku-4-5-thinking",
        "deepseek-ai/DeepSeek-V3.1",
        "moonshotai/Kimi-K2-Instruct",
        "openai/gpt-oss-120b",
        "deepseek-ai/DeepSeek-R1-0528-tput",
        "Qwen/Qwen2.5-72B-Instruct-Turbo",
        "gemini/gemini-3-pro-preview",
        "gemini/gemini-3-pro-preview-thinking",
        "databricks/databricks-claude-3-7-sonnet",
        "databricks/databricks-claude-haiku-4-5",
        "databricks/databricks-claude-opus-4-1",
        "databricks/databricks-claude-opus-4-5",
        "databricks/databricks-claude-opus-4-6",
        "databricks/databricks-claude-sonnet-4",
        "databricks/databricks-claude-sonnet-4-5",
        "databricks/databricks-gemini-2-5-flash",
        "databricks/databricks-gemini-2-5-pro",
        "databricks/databricks-gemini-3-flash",
        "databricks/databricks-gemini-3-pro",
        "databricks/databricks-gpt-5",
    ]
    """Model for revisions (only used if enable_revisions is true)"""

    revision_thinking_budget: int
    """Token budget for extended thinking during revisions.

    Only applies to models with -thinking suffix.
    """

    seed_shuffling_level: Literal["none", "sample", "field", "prompt"]
    """(advanced) How to shuffle seed examples between samples"""

    spec_version: int
    """Version number to use (optional, defaults to latest)"""

    unified_multifield: bool
    """(advanced) Use unified multifield generation.

    This helps to reduce the generation cost by processing all fields together
    rather than one by one.
    """
