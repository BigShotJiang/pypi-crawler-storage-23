# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

from ..._types import FileTypes, SequenceNotStr

__all__ = ["SeedDatasetCreateWithFilesParams"]


class SeedDatasetCreateWithFilesParams(TypedDict, total=False):
    dataset_type: Required[Literal["SINGLE_FILE", "MULTI_FILE", "MULTI_FOLDER"]]

    files: Required[SequenceNotStr[FileTypes]]
    """Files to upload.

    SINGLE_FILE: exactly 1 file. MULTI_FILE: 2+ files. MULTI_FOLDER: 2+ files with
    corresponding folder_names.
    """

    name: Required[str]
    """Dataset name (must be unique)"""

    description: str
    """Optional dataset description"""

    folder_names: SequenceNotStr[str]
    """Folder names for MULTI_FOLDER datasets.

    This is a parallel array with files: folder_names[i] specifies which folder
    files[i] belongs to (e.g., if files=['a.txt', 'b.txt'] and folder_names=['doc1',
    'doc2'], then a.txt goes in doc1, b.txt goes in doc2). Minimum 2 unique folder
    names required.
    """
