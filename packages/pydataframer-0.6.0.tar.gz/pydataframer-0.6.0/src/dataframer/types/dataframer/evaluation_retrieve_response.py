# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime
from typing_extensions import Literal

from ..._models import BaseModel
from ..sample_classification import SampleClassification

__all__ = ["EvaluationRetrieveResponse", "DistributionAnalysis"]


class DistributionAnalysis(BaseModel):
    """Distribution comparison for a single property"""

    expected_distributions: Optional[Dict[str, float]] = None
    """Expected percentage for each property value (from the spec)"""

    observed_distributions: Optional[Dict[str, float]] = None
    """Observed percentage for each property value (from generated samples)"""

    property_name: Optional[str] = None
    """Name of the property being analyzed"""

    total_samples: Optional[int] = None
    """Total number of samples in the run"""

    total_samples_analyzed: Optional[int] = None
    """Number of samples that were successfully classified for this property"""


class EvaluationRetrieveResponse(BaseModel):
    """
    Full evaluation details including distribution analysis and sample classifications
    """

    id: Optional[str] = None
    """Unique identifier for the evaluation"""

    company_id: Optional[str] = None
    """ID of the company that owns this evaluation"""

    completed_at: Optional[datetime] = None
    """When evaluation completed"""

    conformance_explanation: Optional[str] = None
    """Human-readable explanation of the conformance score and any notable deviations"""

    conformance_score: Optional[float] = None
    """
    Overall conformance score (0-100) measuring how well generated samples match the
    spec's expected distributions. Null until evaluation completes.
    """

    conformant_areas: Optional[str] = None
    """Description of areas where samples conform well to the spec"""

    created_at: Optional[datetime] = None
    """When the evaluation was created"""

    created_by: Optional[int] = None
    """ID of the user who created this evaluation"""

    created_by_email: Optional[str] = None
    """Email of the user who created the evaluation"""

    distribution_analysis: Optional[List[DistributionAnalysis]] = None
    """Per-property comparison of expected vs observed distributions.

    Null until evaluation completes.
    """

    duration_seconds: Optional[float] = None
    """Time taken to complete the evaluation in seconds"""

    error_message: Optional[str] = None
    """Error message if evaluation failed"""

    non_conformant_areas: Optional[str] = None
    """Description of areas where samples deviate from the spec"""

    run_id: Optional[str] = None
    """ID of the run being evaluated"""

    sample_classifications: Optional[List[SampleClassification]] = None
    """Classification results for each generated sample.

    Empty until evaluation completes.
    """

    started_at: Optional[datetime] = None
    """When evaluation processing started"""

    status: Optional[Literal["PENDING", "PROCESSING", "SUCCEEDED", "FAILED"]] = None
    """Current status of the evaluation"""

    status_display: Optional[str] = None
    """Human-readable status display"""

    trace: Optional[Dict[str, object]] = None
    """Internal trace information including task_id and evaluation model used"""

    updated_at: Optional[datetime] = None
    """When the evaluation was last updated"""
