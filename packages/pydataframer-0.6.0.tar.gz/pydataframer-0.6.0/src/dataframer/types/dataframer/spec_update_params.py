# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["SpecUpdateParams"]


class SpecUpdateParams(TypedDict, total=False):
    content_yaml: Required[str]
    """Complete YAML spec configuration replacing its previous version in the spec.

    The YAML should have a 'spec' root key containing one or more editable fields:
    description, requirements, data_property_variations, selected_sql_schema_column,
    selected_sql_query_columns. To check the expected spec YAML format, check the
    YAML section in spec view in the UI, or look at YAML returned by the Get spec
    API endpoint. If a 'metadata' section is present, it is ignored (read-only).
    """
