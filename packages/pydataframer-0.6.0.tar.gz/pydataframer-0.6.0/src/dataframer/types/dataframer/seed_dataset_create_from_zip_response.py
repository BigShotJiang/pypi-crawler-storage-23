# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from .file import File
from ..._models import BaseModel

__all__ = ["SeedDatasetCreateFromZipResponse"]


class SeedDatasetCreateFromZipResponse(BaseModel):
    id: Optional[str] = None
    """Unique identifier for the dataset"""

    created_at: Optional[datetime] = None
    """Timestamp when the dataset was created"""

    created_by_email: Optional[str] = None
    """Email address of the user who created the dataset"""

    dataset_type: Optional[Literal["SINGLE_FILE", "MULTI_FILE", "MULTI_FOLDER"]] = None
    """Type of dataset structure.

    SINGLE_FILE: one CSV/JSON/JSONL file with tabular data. MULTI_FILE: multiple
    individual text files. MULTI_FOLDER: files organized into folders where each
    folder represents one sample.
    """

    description: Optional[str] = None
    """Optional description of the dataset contents or purpose"""

    file_count: Optional[int] = None
    """Total number of files in the dataset"""

    files: Optional[List[File]] = None
    """List of all files in the dataset"""

    folder_count: Optional[int] = None
    """Total number of folders in the dataset"""

    name: Optional[str] = None
    """Dataset name"""

    updated_at: Optional[datetime] = None
    """Timestamp when the dataset was last modified"""
