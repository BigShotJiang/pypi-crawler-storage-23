# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["RedTeamRunListResponse", "RedTeamRunListResponseItem"]


class RedTeamRunListResponseItem(BaseModel):
    """Summary of a red team run for list views"""

    id: Optional[str] = None
    """Unique identifier for the run"""

    completed_at: Optional[datetime] = None
    """When the run completed"""

    created_at: Optional[datetime] = None
    """When the run was created"""

    created_by_email: Optional[str] = None
    """Email of the creator"""

    api_model_name: Optional[str] = FieldInfo(alias="model_name", default=None)
    """Model used for generation"""

    number_of_behaviors: Optional[int] = None
    """Number of behaviors generated"""

    number_of_prompts_per_behavior: Optional[int] = None
    """Number of prompts per behavior"""

    red_team_spec_id: Optional[str] = None
    """ID of the red team spec"""

    spec_name: Optional[str] = None
    """Name of the associated spec"""

    status: Optional[Literal["PENDING", "PROCESSING", "SUCCEEDED", "FAILED", "CANCELED"]] = None
    """Current status of the run"""


RedTeamRunListResponse: TypeAlias = List[RedTeamRunListResponseItem]
