# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from ..._models import BaseModel

__all__ = ["RunListResponse", "RunListResponseItem"]


class RunListResponseItem(BaseModel):
    """Run summary for list views"""

    id: Optional[str] = None
    """Unique identifier for the run"""

    completed_at: Optional[datetime] = None
    """When the run completed (null if not finished)"""

    created_at: Optional[datetime] = None
    """When the run was created"""

    created_by_email: Optional[str] = None
    """Email of the user who created the run"""

    dataset_id: Optional[str] = None
    """ID of the seed dataset (null for seedless specs)"""

    dataset_name: Optional[str] = None
    """Name of the seed dataset (null for seedless specs)"""

    dataset_type: Optional[Literal["SINGLE_FILE", "MULTI_FILE", "MULTI_FOLDER"]] = None
    """Type of dataset"""

    samples_completed: Optional[int] = None
    """Number of samples successfully generated"""

    samples_failed: Optional[int] = None
    """Number of samples that failed to generate"""

    spec_id: Optional[str] = None
    """ID of the spec used"""

    spec_name: Optional[str] = None
    """Name of the spec"""

    spec_version: Optional[int] = None
    """Version number of the spec used"""

    status: Optional[Literal["PENDING", "PROCESSING", "SUCCEEDED", "FAILED", "CANCELED"]] = None
    """Current status of the run"""


RunListResponse: TypeAlias = List[RunListResponseItem]
