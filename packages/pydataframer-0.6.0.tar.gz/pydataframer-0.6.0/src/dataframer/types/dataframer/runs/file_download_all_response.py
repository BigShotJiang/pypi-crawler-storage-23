# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ...._models import BaseModel

__all__ = ["FileDownloadAllResponse"]


class FileDownloadAllResponse(BaseModel):
    download_url: Optional[str] = None
    """Presigned URL to download the ZIP file (valid for 1 hour)"""

    size_bytes: Optional[int] = None
    """Size of the ZIP file in bytes"""
