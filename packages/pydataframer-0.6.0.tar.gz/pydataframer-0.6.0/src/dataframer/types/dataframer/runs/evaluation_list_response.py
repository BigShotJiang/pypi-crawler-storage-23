# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from ...._models import BaseModel

__all__ = ["EvaluationListResponse", "EvaluationListResponseItem"]


class EvaluationListResponseItem(BaseModel):
    """Evaluation summary for list views"""

    id: Optional[str] = None
    """Unique identifier for the evaluation"""

    completed_at: Optional[datetime] = None
    """When evaluation completed"""

    conformance_score: Optional[float] = None
    """Overall conformance score (0-100). Null until evaluation completes."""

    created_at: Optional[datetime] = None
    """When the evaluation was created"""

    created_by_email: Optional[str] = None
    """Email of the user who created the evaluation"""

    run_id: Optional[str] = None
    """ID of the run being evaluated"""

    started_at: Optional[datetime] = None
    """When evaluation processing started"""

    status: Optional[Literal["PENDING", "PROCESSING", "SUCCEEDED", "FAILED"]] = None
    """Current status of the evaluation"""

    status_display: Optional[str] = None
    """Human-readable status display"""


EvaluationListResponse: TypeAlias = List[EvaluationListResponseItem]
