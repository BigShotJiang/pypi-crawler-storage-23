# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["RedTeamSpecCreateParams"]


class RedTeamSpecCreateParams(TypedDict, total=False):
    app_description: Required[str]
    """
    Description of the application being tested, including its purpose and key
    functionality
    """

    domain_description: Required[str]
    """
    Description of the domain or industry the application operates in (e.g.,
    'Healthcare', 'E-commerce', 'Financial services')
    """

    name: Required[str]
    """
    Name for the spec (will be converted to snake_case, must be unique within
    company)
    """

    concerns: str
    """
    Optional specific security concerns or undesirable behaviors to focus on (e.g.,
    'Should not provide medical diagnoses')
    """
