# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["EvaluationCreateParams"]


class EvaluationCreateParams(TypedDict, total=False):
    run_id: Required[str]
    """ID of the completed run to evaluate. Run must be in SUCCEEDED status."""

    evaluation_model: Literal[
        "anthropic/claude-opus-4-6",
        "anthropic/claude-opus-4-6-thinking",
        "anthropic/claude-sonnet-4-6",
        "anthropic/claude-sonnet-4-6-thinking",
        "anthropic/claude-haiku-4-5",
        "anthropic/claude-haiku-4-5-thinking",
        "deepseek-ai/DeepSeek-V3.1",
        "moonshotai/Kimi-K2-Instruct",
        "openai/gpt-oss-120b",
        "deepseek-ai/DeepSeek-R1-0528-tput",
        "Qwen/Qwen2.5-72B-Instruct-Turbo",
        "gemini/gemini-3-pro-preview",
        "gemini/gemini-3-pro-preview-thinking",
        "databricks/databricks-claude-3-7-sonnet",
        "databricks/databricks-claude-haiku-4-5",
        "databricks/databricks-claude-opus-4-1",
        "databricks/databricks-claude-opus-4-5",
        "databricks/databricks-claude-opus-4-6",
        "databricks/databricks-claude-sonnet-4",
        "databricks/databricks-claude-sonnet-4-5",
        "databricks/databricks-gemini-2-5-flash",
        "databricks/databricks-gemini-2-5-pro",
        "databricks/databricks-gemini-3-flash",
        "databricks/databricks-gemini-3-pro",
        "databricks/databricks-gpt-5",
    ]
    """AI model to use for evaluation. Defaults to anthropic/claude-sonnet-4-5."""
