# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from ..._models import BaseModel

__all__ = ["SpecListResponse", "SpecListResponseItem"]


class SpecListResponseItem(BaseModel):
    id: Optional[str] = None
    """Unique identifier for the spec"""

    created_at: Optional[datetime] = None
    """Timestamp when the spec was created"""

    dataset_id: Optional[str] = None
    """ID of the seed dataset this spec was created from. Null for seedless specs."""

    dataset_name: Optional[str] = None
    """Name of the seed dataset this spec was created from. Null for seedless specs."""

    description: Optional[str] = None
    """Human-readable description of what data this spec generates"""

    name: Optional[str] = None
    """Spec name, unique within its dataset (or unique among seedless specs)"""

    status: Optional[Literal["PROCESSING", "SUCCEEDED", "FAILED"]] = None
    """Current status of the spec.

    PROCESSING: spec is being generated. SUCCEEDED: spec is ready for generation.
    FAILED: spec generation failed.
    """


SpecListResponse: TypeAlias = List[SpecListResponseItem]
