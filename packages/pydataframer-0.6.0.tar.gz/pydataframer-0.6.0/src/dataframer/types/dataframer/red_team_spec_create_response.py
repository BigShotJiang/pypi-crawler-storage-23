# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from ..._models import BaseModel

__all__ = ["RedTeamSpecCreateResponse"]


class RedTeamSpecCreateResponse(BaseModel):
    """
    A red team specification defining the application context for adversarial prompt generation
    """

    id: Optional[str] = None
    """Unique identifier for the red team spec"""

    app_description: Optional[str] = None
    """
    Description of the application being tested, including its purpose and
    functionality
    """

    company_id: Optional[str] = None
    """ID of the company that owns this spec"""

    company_name: Optional[str] = None
    """Name of the company that owns this spec"""

    concerns: Optional[str] = None
    """Specific security concerns or behaviors to focus on during red teaming"""

    created_at: Optional[datetime] = None
    """Timestamp when the spec was created"""

    created_by: Optional[int] = None
    """ID of the user who created this spec"""

    created_by_email: Optional[str] = None
    """Email of the user who created this spec"""

    domain_description: Optional[str] = None
    """Description of the domain or industry the application operates in"""

    name: Optional[str] = None
    """Name of the red team spec (auto-converted to snake_case)"""

    updated_at: Optional[datetime] = None
    """Timestamp when the spec was last modified"""
