# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["File"]


class File(BaseModel):
    id: Optional[str] = None
    """Unique identifier for the file"""

    file_type: Optional[Literal["json", "jsonl", "csv", "md", "txt", "pdf"]] = None
    """File format.

    json: single JSON object or array. jsonl: newline-delimited JSON records. csv:
    comma-separated values. md: Markdown text. txt: plain text. pdf: PDF document.
    """

    path: Optional[str] = None
    """Full path of the file.

    For files in folders, includes folder name (e.g., 'folder_name/file.txt'). For
    files at root level, just the filename.
    """

    sha256: Optional[str] = None
    """SHA-256 hash of the file contents for integrity verification"""

    size_bytes: Optional[int] = None
    """File size in bytes"""
