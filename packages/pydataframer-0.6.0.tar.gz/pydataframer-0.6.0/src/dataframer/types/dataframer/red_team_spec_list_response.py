# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import TypeAlias

from ..._models import BaseModel

__all__ = ["RedTeamSpecListResponse", "RedTeamSpecListResponseItem"]


class RedTeamSpecListResponseItem(BaseModel):
    """Summary of a red team spec for list views"""

    id: Optional[str] = None
    """Unique identifier for the red team spec"""

    app_description: Optional[str] = None
    """Description of the application"""

    created_at: Optional[datetime] = None
    """Timestamp when the spec was created"""

    created_by_email: Optional[str] = None
    """Email of the user who created this spec"""

    domain_description: Optional[str] = None
    """Description of the domain"""

    name: Optional[str] = None
    """Name of the red team spec"""

    updated_at: Optional[datetime] = None
    """Timestamp when the spec was last modified"""


RedTeamSpecListResponse: TypeAlias = List[RedTeamSpecListResponseItem]
