# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["RedTeamSpecUpdateParams"]


class RedTeamSpecUpdateParams(TypedDict, total=False):
    app_description: str
    """Updated application description"""

    concerns: str
    """Updated security concerns"""

    domain_description: str
    """Updated domain description"""

    name: str
    """New name for the spec (will be converted to snake_case)"""
