# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["SpecDeleteParams"]


class SpecDeleteParams(TypedDict, total=False):
    force: bool
    """
    If true, delete the spec and all associated runs (including their generated
    files). If false or omitted, returns an error when runs exist.
    """
