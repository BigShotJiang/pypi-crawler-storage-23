# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["SpecUpdateResponse", "Version"]


class Version(BaseModel):
    content_yaml: Optional[str] = None

    created_at: Optional[datetime] = None


class SpecUpdateResponse(BaseModel):
    id: Optional[str] = None
    """Unique identifier for the spec"""

    content_yaml: Optional[str] = None
    """The YAML content from the latest version of this spec.

    Null when status is PROCESSING or FAILED.
    """

    created_at: Optional[datetime] = None
    """Timestamp when the spec was created"""

    created_by_email: Optional[str] = None
    """Email of the user who created this spec"""

    dataset_id: Optional[str] = None
    """ID of the seed dataset. Null for seedless specs."""

    dataset_name: Optional[str] = None
    """Name of the seed dataset. Null for seedless specs."""

    description: Optional[str] = None
    """
    Description of the spec's purpose (optional, for data organization purposes
    only)
    """

    error: Optional[str] = None
    """Error message when status is FAILED. Null otherwise."""

    name: Optional[str] = None
    """Spec name"""

    runtime_params: Optional[Dict[str, object]] = None
    """
    Parameters used during spec generation (model name, distribution settings, etc.)
    """

    status: Optional[Literal["PROCESSING", "SUCCEEDED", "FAILED"]] = None
    """Current status of the spec"""

    updated_at: Optional[datetime] = None
    """Timestamp when the spec was last modified"""

    versions: Optional[List[Version]] = None
    """All versions of this spec.

    Only included when include_versions=true. Empty when status is PROCESSING or
    FAILED.
    """
