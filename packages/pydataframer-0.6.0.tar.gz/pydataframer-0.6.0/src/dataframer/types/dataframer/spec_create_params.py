# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["SpecCreateParams"]


class SpecCreateParams(TypedDict, total=False):
    name: Required[str]
    """Name for the new spec (must be unique)"""

    databricks_api_base: str
    """Databricks Model Serving endpoint URL (e.g.

    https://adb-xxx.azuredatabricks.net/serving-endpoints). Required when using
    databricks/ models.
    """

    databricks_client_id: str
    """Databricks service principal application (client) ID.

    Required when using databricks/ models.
    """

    databricks_client_secret: str
    """Databricks service principal secret. Required when using databricks/ models."""

    dataset_id: str
    """ID of the seed dataset to generate spec from. Omit for seedless spec creation."""

    description: str
    """
    Description of the spec's purpose (optional, for data organization purposes
    only)
    """

    extrapolate_axes: bool
    """Extrapolate to new axes/dimensions not present in seed data.

    Not applicable for seedless specs.
    """

    extrapolate_values: bool
    """Extrapolate new values beyond existing data ranges.

    Not applicable for seedless specs.
    """

    generate_conditional_distributions: bool
    """
    Generate conditional distributions showing how property values vary based on
    other properties. Requires generate_distributions to be true.
    """

    generate_distributions: bool
    """
    When true, the spec will include generated probability distributions for each
    property value; when false, each property will have a uniform distribution.
    """

    generation_objectives: str
    """
    Custom objectives or instructions for data generation that directly influence
    contents of the generated spec. Required for seedless specs (when dataset_id is
    omitted).
    """

    spec_generation_model_name: Literal[
        "anthropic/claude-opus-4-6",
        "anthropic/claude-opus-4-6-thinking",
        "anthropic/claude-sonnet-4-6",
        "anthropic/claude-sonnet-4-6-thinking",
        "anthropic/claude-haiku-4-5",
        "anthropic/claude-haiku-4-5-thinking",
        "deepseek-ai/DeepSeek-V3.1",
        "moonshotai/Kimi-K2-Instruct",
        "openai/gpt-oss-120b",
        "deepseek-ai/DeepSeek-R1-0528-tput",
        "Qwen/Qwen2.5-72B-Instruct-Turbo",
        "gemini/gemini-3-pro-preview",
        "gemini/gemini-3-pro-preview-thinking",
        "databricks/databricks-claude-3-7-sonnet",
        "databricks/databricks-claude-haiku-4-5",
        "databricks/databricks-claude-opus-4-1",
        "databricks/databricks-claude-opus-4-5",
        "databricks/databricks-claude-opus-4-6",
        "databricks/databricks-claude-sonnet-4",
        "databricks/databricks-claude-sonnet-4-5",
        "databricks/databricks-gemini-2-5-flash",
        "databricks/databricks-gemini-2-5-pro",
        "databricks/databricks-gemini-3-flash",
        "databricks/databricks-gemini-3-pro",
        "databricks/databricks-gpt-5",
    ]
    """AI model to use for spec generation.

    For databricks/ models, you must also provide databricks_client_id,
    databricks_client_secret, and databricks_api_base.
    """
