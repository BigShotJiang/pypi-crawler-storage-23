# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["RedTeamRunCreateParams"]


class RedTeamRunCreateParams(TypedDict, total=False):
    model_name: Required[
        Literal[
            "deepseek-ai/DeepSeek-V3.1",
            "deepseek-ai/DeepSeek-R1-0528-tput",
            "moonshotai/Kimi-K2-Instruct",
            "openai/gpt-oss-120b",
        ]
    ]
    """Model to use for generating adversarial prompts"""

    number_of_behaviors: Required[int]
    """Number of adversarial behaviors to generate"""

    number_of_prompts_per_behavior: Required[int]
    """Number of adversarial prompts to generate for each behavior"""

    red_team_spec_id: Required[str]
    """ID of the red team spec to use"""
