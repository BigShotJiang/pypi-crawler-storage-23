# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["SampleClassification"]


class SampleClassification(BaseModel):
    """Classification results for a single generated sample"""

    id: Optional[str] = None
    """Unique identifier for this classification"""

    classifications: Optional[Dict[str, str]] = None
    """Map of property names to their classified values for this sample"""

    created_at: Optional[datetime] = None
    """When this classification was created"""

    evaluation_id: Optional[str] = None
    """ID of the parent evaluation"""

    sample_identifier: Optional[str] = None
    """Identifier for the sample (matches the generated sample name from the run)"""

    sub_file_classifications: Optional[Dict[str, object]] = None
    """For MULTI_FOLDER datasets only.

    Shows which files within the sample folder contributed to each classification.
    Maps property name -> value -> list of filenames.
    """
