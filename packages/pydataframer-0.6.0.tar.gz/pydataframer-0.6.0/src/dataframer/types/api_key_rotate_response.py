# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["APIKeyRotateResponse"]


class APIKeyRotateResponse(BaseModel):
    """Response from a successful API key rotation"""

    api_key: Optional[str] = None
    """The new API key. Store securely — it will not be shown again."""

    expires_at: Optional[datetime] = None
    """Expiration timestamp of the new API key"""

    masked_key: Optional[str] = None
    """Masked version of the key showing first 4 and last 4 characters (e.g.

    a1b2\\**\\**\\**\\**5678)
    """
