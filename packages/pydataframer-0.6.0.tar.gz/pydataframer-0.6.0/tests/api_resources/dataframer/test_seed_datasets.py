# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from dataframer import Dataframer, AsyncDataframer
from tests.utils import assert_matches_type
from dataframer.types.dataframer import (
    SeedDatasetListResponse,
    SeedDatasetRetrieveResponse,
    SeedDatasetCreateFromZipResponse,
    SeedDatasetCreateWithFilesResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSeedDatasets:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Dataframer) -> None:
        seed_dataset = client.dataframer.seed_datasets.retrieve(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(SeedDatasetRetrieveResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Dataframer) -> None:
        response = client.dataframer.seed_datasets.with_raw_response.retrieve(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        seed_dataset = response.parse()
        assert_matches_type(SeedDatasetRetrieveResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Dataframer) -> None:
        with client.dataframer.seed_datasets.with_streaming_response.retrieve(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            seed_dataset = response.parse()
            assert_matches_type(SeedDatasetRetrieveResponse, seed_dataset, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Dataframer) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `dataset_id` but received ''"):
            client.dataframer.seed_datasets.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Dataframer) -> None:
        seed_dataset = client.dataframer.seed_datasets.list()
        assert_matches_type(SeedDatasetListResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Dataframer) -> None:
        response = client.dataframer.seed_datasets.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        seed_dataset = response.parse()
        assert_matches_type(SeedDatasetListResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Dataframer) -> None:
        with client.dataframer.seed_datasets.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            seed_dataset = response.parse()
            assert_matches_type(SeedDatasetListResponse, seed_dataset, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete(self, client: Dataframer) -> None:
        seed_dataset = client.dataframer.seed_datasets.delete(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert seed_dataset is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Dataframer) -> None:
        response = client.dataframer.seed_datasets.with_raw_response.delete(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        seed_dataset = response.parse()
        assert seed_dataset is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Dataframer) -> None:
        with client.dataframer.seed_datasets.with_streaming_response.delete(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            seed_dataset = response.parse()
            assert seed_dataset is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Dataframer) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `dataset_id` but received ''"):
            client.dataframer.seed_datasets.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_from_zip(self, client: Dataframer) -> None:
        seed_dataset = client.dataframer.seed_datasets.create_from_zip(
            name="name",
            zip_file=b"raw file contents",
        )
        assert_matches_type(SeedDatasetCreateFromZipResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_from_zip_with_all_params(self, client: Dataframer) -> None:
        seed_dataset = client.dataframer.seed_datasets.create_from_zip(
            name="name",
            zip_file=b"raw file contents",
            description="description",
        )
        assert_matches_type(SeedDatasetCreateFromZipResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create_from_zip(self, client: Dataframer) -> None:
        response = client.dataframer.seed_datasets.with_raw_response.create_from_zip(
            name="name",
            zip_file=b"raw file contents",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        seed_dataset = response.parse()
        assert_matches_type(SeedDatasetCreateFromZipResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create_from_zip(self, client: Dataframer) -> None:
        with client.dataframer.seed_datasets.with_streaming_response.create_from_zip(
            name="name",
            zip_file=b"raw file contents",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            seed_dataset = response.parse()
            assert_matches_type(SeedDatasetCreateFromZipResponse, seed_dataset, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_files(self, client: Dataframer) -> None:
        seed_dataset = client.dataframer.seed_datasets.create_with_files(
            dataset_type="SINGLE_FILE",
            files=[b"raw file contents", b"raw file contents"],
            name="name",
        )
        assert_matches_type(SeedDatasetCreateWithFilesResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_files_with_all_params(self, client: Dataframer) -> None:
        seed_dataset = client.dataframer.seed_datasets.create_with_files(
            dataset_type="SINGLE_FILE",
            files=[b"raw file contents", b"raw file contents"],
            name="name",
            description="description",
            folder_names=["string", "string"],
        )
        assert_matches_type(SeedDatasetCreateWithFilesResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create_with_files(self, client: Dataframer) -> None:
        response = client.dataframer.seed_datasets.with_raw_response.create_with_files(
            dataset_type="SINGLE_FILE",
            files=[b"raw file contents", b"raw file contents"],
            name="name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        seed_dataset = response.parse()
        assert_matches_type(SeedDatasetCreateWithFilesResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create_with_files(self, client: Dataframer) -> None:
        with client.dataframer.seed_datasets.with_streaming_response.create_with_files(
            dataset_type="SINGLE_FILE",
            files=[b"raw file contents", b"raw file contents"],
            name="name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            seed_dataset = response.parse()
            assert_matches_type(SeedDatasetCreateWithFilesResponse, seed_dataset, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncSeedDatasets:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncDataframer) -> None:
        seed_dataset = await async_client.dataframer.seed_datasets.retrieve(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(SeedDatasetRetrieveResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncDataframer) -> None:
        response = await async_client.dataframer.seed_datasets.with_raw_response.retrieve(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        seed_dataset = await response.parse()
        assert_matches_type(SeedDatasetRetrieveResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncDataframer) -> None:
        async with async_client.dataframer.seed_datasets.with_streaming_response.retrieve(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            seed_dataset = await response.parse()
            assert_matches_type(SeedDatasetRetrieveResponse, seed_dataset, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncDataframer) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `dataset_id` but received ''"):
            await async_client.dataframer.seed_datasets.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncDataframer) -> None:
        seed_dataset = await async_client.dataframer.seed_datasets.list()
        assert_matches_type(SeedDatasetListResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncDataframer) -> None:
        response = await async_client.dataframer.seed_datasets.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        seed_dataset = await response.parse()
        assert_matches_type(SeedDatasetListResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncDataframer) -> None:
        async with async_client.dataframer.seed_datasets.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            seed_dataset = await response.parse()
            assert_matches_type(SeedDatasetListResponse, seed_dataset, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncDataframer) -> None:
        seed_dataset = await async_client.dataframer.seed_datasets.delete(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert seed_dataset is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncDataframer) -> None:
        response = await async_client.dataframer.seed_datasets.with_raw_response.delete(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        seed_dataset = await response.parse()
        assert seed_dataset is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncDataframer) -> None:
        async with async_client.dataframer.seed_datasets.with_streaming_response.delete(
            "182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            seed_dataset = await response.parse()
            assert seed_dataset is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncDataframer) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `dataset_id` but received ''"):
            await async_client.dataframer.seed_datasets.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_from_zip(self, async_client: AsyncDataframer) -> None:
        seed_dataset = await async_client.dataframer.seed_datasets.create_from_zip(
            name="name",
            zip_file=b"raw file contents",
        )
        assert_matches_type(SeedDatasetCreateFromZipResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_from_zip_with_all_params(self, async_client: AsyncDataframer) -> None:
        seed_dataset = await async_client.dataframer.seed_datasets.create_from_zip(
            name="name",
            zip_file=b"raw file contents",
            description="description",
        )
        assert_matches_type(SeedDatasetCreateFromZipResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create_from_zip(self, async_client: AsyncDataframer) -> None:
        response = await async_client.dataframer.seed_datasets.with_raw_response.create_from_zip(
            name="name",
            zip_file=b"raw file contents",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        seed_dataset = await response.parse()
        assert_matches_type(SeedDatasetCreateFromZipResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create_from_zip(self, async_client: AsyncDataframer) -> None:
        async with async_client.dataframer.seed_datasets.with_streaming_response.create_from_zip(
            name="name",
            zip_file=b"raw file contents",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            seed_dataset = await response.parse()
            assert_matches_type(SeedDatasetCreateFromZipResponse, seed_dataset, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_files(self, async_client: AsyncDataframer) -> None:
        seed_dataset = await async_client.dataframer.seed_datasets.create_with_files(
            dataset_type="SINGLE_FILE",
            files=[b"raw file contents", b"raw file contents"],
            name="name",
        )
        assert_matches_type(SeedDatasetCreateWithFilesResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_files_with_all_params(self, async_client: AsyncDataframer) -> None:
        seed_dataset = await async_client.dataframer.seed_datasets.create_with_files(
            dataset_type="SINGLE_FILE",
            files=[b"raw file contents", b"raw file contents"],
            name="name",
            description="description",
            folder_names=["string", "string"],
        )
        assert_matches_type(SeedDatasetCreateWithFilesResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create_with_files(self, async_client: AsyncDataframer) -> None:
        response = await async_client.dataframer.seed_datasets.with_raw_response.create_with_files(
            dataset_type="SINGLE_FILE",
            files=[b"raw file contents", b"raw file contents"],
            name="name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        seed_dataset = await response.parse()
        assert_matches_type(SeedDatasetCreateWithFilesResponse, seed_dataset, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create_with_files(self, async_client: AsyncDataframer) -> None:
        async with async_client.dataframer.seed_datasets.with_streaming_response.create_with_files(
            dataset_type="SINGLE_FILE",
            files=[b"raw file contents", b"raw file contents"],
            name="name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            seed_dataset = await response.parse()
            assert_matches_type(SeedDatasetCreateWithFilesResponse, seed_dataset, path=["response"])

        assert cast(Any, response.is_closed) is True
