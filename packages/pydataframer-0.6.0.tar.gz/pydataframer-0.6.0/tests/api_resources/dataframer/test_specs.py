# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from dataframer import Dataframer, AsyncDataframer
from tests.utils import assert_matches_type
from dataframer.types.dataframer import (
    SpecListResponse,
    SpecCreateResponse,
    SpecUpdateResponse,
    SpecRetrieveResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSpecs:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Dataframer) -> None:
        spec = client.dataframer.specs.create(
            name="Customer Support Conversations Spec",
        )
        assert_matches_type(SpecCreateResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Dataframer) -> None:
        spec = client.dataframer.specs.create(
            name="Customer Support Conversations Spec",
            databricks_api_base="databricks_api_base",
            databricks_client_id="databricks_client_id",
            databricks_client_secret="databricks_client_secret",
            dataset_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            description="description",
            extrapolate_axes=False,
            extrapolate_values=True,
            generate_conditional_distributions=True,
            generate_distributions=True,
            generation_objectives="generation_objectives",
            spec_generation_model_name="anthropic/claude-opus-4-6",
        )
        assert_matches_type(SpecCreateResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Dataframer) -> None:
        response = client.dataframer.specs.with_raw_response.create(
            name="Customer Support Conversations Spec",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        spec = response.parse()
        assert_matches_type(SpecCreateResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Dataframer) -> None:
        with client.dataframer.specs.with_streaming_response.create(
            name="Customer Support Conversations Spec",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            spec = response.parse()
            assert_matches_type(SpecCreateResponse, spec, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Dataframer) -> None:
        spec = client.dataframer.specs.retrieve(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(SpecRetrieveResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve_with_all_params(self, client: Dataframer) -> None:
        spec = client.dataframer.specs.retrieve(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            include_versions=True,
        )
        assert_matches_type(SpecRetrieveResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Dataframer) -> None:
        response = client.dataframer.specs.with_raw_response.retrieve(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        spec = response.parse()
        assert_matches_type(SpecRetrieveResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Dataframer) -> None:
        with client.dataframer.specs.with_streaming_response.retrieve(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            spec = response.parse()
            assert_matches_type(SpecRetrieveResponse, spec, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Dataframer) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `spec_id` but received ''"):
            client.dataframer.specs.with_raw_response.retrieve(
                spec_id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update(self, client: Dataframer) -> None:
        spec = client.dataframer.specs.update(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            content_yaml='spec:\n  description: "Customer support conversations with varying sentiment and priority"\n  requirements: "Each conversation should include a customer greeting, issue description, and agent response. Maintain professional tone throughout."\n  data_property_variations:\n    - property_name: sentiment\n      property_values:\n        - positive\n        - negative\n        - neutral\n      base_distributions:\n        positive: 40\n        negative: 30\n        neutral: 30\n    - property_name: priority\n      property_values:\n        - high\n        - medium\n        - low\n      base_distributions:\n        high: 20\n        medium: 50\n        low: 30\n',
        )
        assert_matches_type(SpecUpdateResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Dataframer) -> None:
        response = client.dataframer.specs.with_raw_response.update(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            content_yaml='spec:\n  description: "Customer support conversations with varying sentiment and priority"\n  requirements: "Each conversation should include a customer greeting, issue description, and agent response. Maintain professional tone throughout."\n  data_property_variations:\n    - property_name: sentiment\n      property_values:\n        - positive\n        - negative\n        - neutral\n      base_distributions:\n        positive: 40\n        negative: 30\n        neutral: 30\n    - property_name: priority\n      property_values:\n        - high\n        - medium\n        - low\n      base_distributions:\n        high: 20\n        medium: 50\n        low: 30\n',
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        spec = response.parse()
        assert_matches_type(SpecUpdateResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Dataframer) -> None:
        with client.dataframer.specs.with_streaming_response.update(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            content_yaml='spec:\n  description: "Customer support conversations with varying sentiment and priority"\n  requirements: "Each conversation should include a customer greeting, issue description, and agent response. Maintain professional tone throughout."\n  data_property_variations:\n    - property_name: sentiment\n      property_values:\n        - positive\n        - negative\n        - neutral\n      base_distributions:\n        positive: 40\n        negative: 30\n        neutral: 30\n    - property_name: priority\n      property_values:\n        - high\n        - medium\n        - low\n      base_distributions:\n        high: 20\n        medium: 50\n        low: 30\n',
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            spec = response.parse()
            assert_matches_type(SpecUpdateResponse, spec, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Dataframer) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `spec_id` but received ''"):
            client.dataframer.specs.with_raw_response.update(
                spec_id="",
                content_yaml='spec:\n  description: "Customer support conversations with varying sentiment and priority"\n  requirements: "Each conversation should include a customer greeting, issue description, and agent response. Maintain professional tone throughout."\n  data_property_variations:\n    - property_name: sentiment\n      property_values:\n        - positive\n        - negative\n        - neutral\n      base_distributions:\n        positive: 40\n        negative: 30\n        neutral: 30\n    - property_name: priority\n      property_values:\n        - high\n        - medium\n        - low\n      base_distributions:\n        high: 20\n        medium: 50\n        low: 30\n',
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Dataframer) -> None:
        spec = client.dataframer.specs.list()
        assert_matches_type(SpecListResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Dataframer) -> None:
        response = client.dataframer.specs.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        spec = response.parse()
        assert_matches_type(SpecListResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Dataframer) -> None:
        with client.dataframer.specs.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            spec = response.parse()
            assert_matches_type(SpecListResponse, spec, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete(self, client: Dataframer) -> None:
        spec = client.dataframer.specs.delete(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert spec is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete_with_all_params(self, client: Dataframer) -> None:
        spec = client.dataframer.specs.delete(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            force=True,
        )
        assert spec is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Dataframer) -> None:
        response = client.dataframer.specs.with_raw_response.delete(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        spec = response.parse()
        assert spec is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Dataframer) -> None:
        with client.dataframer.specs.with_streaming_response.delete(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            spec = response.parse()
            assert spec is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Dataframer) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `spec_id` but received ''"):
            client.dataframer.specs.with_raw_response.delete(
                spec_id="",
            )


class TestAsyncSpecs:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncDataframer) -> None:
        spec = await async_client.dataframer.specs.create(
            name="Customer Support Conversations Spec",
        )
        assert_matches_type(SpecCreateResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncDataframer) -> None:
        spec = await async_client.dataframer.specs.create(
            name="Customer Support Conversations Spec",
            databricks_api_base="databricks_api_base",
            databricks_client_id="databricks_client_id",
            databricks_client_secret="databricks_client_secret",
            dataset_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            description="description",
            extrapolate_axes=False,
            extrapolate_values=True,
            generate_conditional_distributions=True,
            generate_distributions=True,
            generation_objectives="generation_objectives",
            spec_generation_model_name="anthropic/claude-opus-4-6",
        )
        assert_matches_type(SpecCreateResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncDataframer) -> None:
        response = await async_client.dataframer.specs.with_raw_response.create(
            name="Customer Support Conversations Spec",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        spec = await response.parse()
        assert_matches_type(SpecCreateResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncDataframer) -> None:
        async with async_client.dataframer.specs.with_streaming_response.create(
            name="Customer Support Conversations Spec",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            spec = await response.parse()
            assert_matches_type(SpecCreateResponse, spec, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncDataframer) -> None:
        spec = await async_client.dataframer.specs.retrieve(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(SpecRetrieveResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve_with_all_params(self, async_client: AsyncDataframer) -> None:
        spec = await async_client.dataframer.specs.retrieve(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            include_versions=True,
        )
        assert_matches_type(SpecRetrieveResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncDataframer) -> None:
        response = await async_client.dataframer.specs.with_raw_response.retrieve(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        spec = await response.parse()
        assert_matches_type(SpecRetrieveResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncDataframer) -> None:
        async with async_client.dataframer.specs.with_streaming_response.retrieve(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            spec = await response.parse()
            assert_matches_type(SpecRetrieveResponse, spec, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncDataframer) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `spec_id` but received ''"):
            await async_client.dataframer.specs.with_raw_response.retrieve(
                spec_id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncDataframer) -> None:
        spec = await async_client.dataframer.specs.update(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            content_yaml='spec:\n  description: "Customer support conversations with varying sentiment and priority"\n  requirements: "Each conversation should include a customer greeting, issue description, and agent response. Maintain professional tone throughout."\n  data_property_variations:\n    - property_name: sentiment\n      property_values:\n        - positive\n        - negative\n        - neutral\n      base_distributions:\n        positive: 40\n        negative: 30\n        neutral: 30\n    - property_name: priority\n      property_values:\n        - high\n        - medium\n        - low\n      base_distributions:\n        high: 20\n        medium: 50\n        low: 30\n',
        )
        assert_matches_type(SpecUpdateResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncDataframer) -> None:
        response = await async_client.dataframer.specs.with_raw_response.update(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            content_yaml='spec:\n  description: "Customer support conversations with varying sentiment and priority"\n  requirements: "Each conversation should include a customer greeting, issue description, and agent response. Maintain professional tone throughout."\n  data_property_variations:\n    - property_name: sentiment\n      property_values:\n        - positive\n        - negative\n        - neutral\n      base_distributions:\n        positive: 40\n        negative: 30\n        neutral: 30\n    - property_name: priority\n      property_values:\n        - high\n        - medium\n        - low\n      base_distributions:\n        high: 20\n        medium: 50\n        low: 30\n',
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        spec = await response.parse()
        assert_matches_type(SpecUpdateResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncDataframer) -> None:
        async with async_client.dataframer.specs.with_streaming_response.update(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            content_yaml='spec:\n  description: "Customer support conversations with varying sentiment and priority"\n  requirements: "Each conversation should include a customer greeting, issue description, and agent response. Maintain professional tone throughout."\n  data_property_variations:\n    - property_name: sentiment\n      property_values:\n        - positive\n        - negative\n        - neutral\n      base_distributions:\n        positive: 40\n        negative: 30\n        neutral: 30\n    - property_name: priority\n      property_values:\n        - high\n        - medium\n        - low\n      base_distributions:\n        high: 20\n        medium: 50\n        low: 30\n',
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            spec = await response.parse()
            assert_matches_type(SpecUpdateResponse, spec, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncDataframer) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `spec_id` but received ''"):
            await async_client.dataframer.specs.with_raw_response.update(
                spec_id="",
                content_yaml='spec:\n  description: "Customer support conversations with varying sentiment and priority"\n  requirements: "Each conversation should include a customer greeting, issue description, and agent response. Maintain professional tone throughout."\n  data_property_variations:\n    - property_name: sentiment\n      property_values:\n        - positive\n        - negative\n        - neutral\n      base_distributions:\n        positive: 40\n        negative: 30\n        neutral: 30\n    - property_name: priority\n      property_values:\n        - high\n        - medium\n        - low\n      base_distributions:\n        high: 20\n        medium: 50\n        low: 30\n',
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncDataframer) -> None:
        spec = await async_client.dataframer.specs.list()
        assert_matches_type(SpecListResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncDataframer) -> None:
        response = await async_client.dataframer.specs.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        spec = await response.parse()
        assert_matches_type(SpecListResponse, spec, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncDataframer) -> None:
        async with async_client.dataframer.specs.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            spec = await response.parse()
            assert_matches_type(SpecListResponse, spec, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncDataframer) -> None:
        spec = await async_client.dataframer.specs.delete(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert spec is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete_with_all_params(self, async_client: AsyncDataframer) -> None:
        spec = await async_client.dataframer.specs.delete(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            force=True,
        )
        assert spec is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncDataframer) -> None:
        response = await async_client.dataframer.specs.with_raw_response.delete(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        spec = await response.parse()
        assert spec is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncDataframer) -> None:
        async with async_client.dataframer.specs.with_streaming_response.delete(
            spec_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            spec = await response.parse()
            assert spec is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncDataframer) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `spec_id` but received ''"):
            await async_client.dataframer.specs.with_raw_response.delete(
                spec_id="",
            )
