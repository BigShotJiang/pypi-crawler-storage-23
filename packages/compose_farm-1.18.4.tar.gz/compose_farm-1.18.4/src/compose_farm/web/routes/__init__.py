"""Web routes."""

from compose_farm.web.routes import actions, api, containers, pages

__all__ = ["actions", "api", "containers", "pages"]
