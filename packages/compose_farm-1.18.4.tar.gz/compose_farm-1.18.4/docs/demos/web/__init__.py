"""Web UI demo recording scripts."""
