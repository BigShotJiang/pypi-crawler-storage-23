# $Id: __init__.py 244840 2019-09-12 07:17:18Z jpritcha $
"""
API to ESO p2
"""
from .p2api import * # So that users only need to do import p2api
