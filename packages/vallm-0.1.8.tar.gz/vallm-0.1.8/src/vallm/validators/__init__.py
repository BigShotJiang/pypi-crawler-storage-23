"""Built-in validators for vallm."""
