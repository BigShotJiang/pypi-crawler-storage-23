"""Core modules for vallm."""

from vallm.core.languages import Language, detect_language, get_language_for_validation, LIZARD_SUPPORTED
