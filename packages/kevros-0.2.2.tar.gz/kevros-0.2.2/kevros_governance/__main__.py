"""Allow running the MCP server via: python -m kevros_governance"""

from kevros_governance.mcp_server import main

main()
