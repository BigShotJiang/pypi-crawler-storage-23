#!/usr/bin/env python3
"""
Backward-compatibility shim.

The canonical MCP server now lives at kevros_governance.mcp_server.
This file keeps Smithery, server.json, and cloned-repo workflows working.

Preferred invocations:
    kevros-mcp                       # pip-installed entry point
    python -m kevros_governance      # module invocation
"""

from kevros_governance.mcp_server import main

if __name__ == "__main__":
    main()
