"""Private benchmarking module for comparing optimization algorithms.

Not part of the public API. Interface may change without notice.
"""

from ._benchmark import Benchmark
from ._report import BenchmarkReport
from ._suite import BenchmarkSuite

__all__ = ["Benchmark", "BenchmarkReport", "BenchmarkSuite"]
