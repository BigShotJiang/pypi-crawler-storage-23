from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class ConvergenceConfig:
    """Configuration for convergence checking.

    Parameters
    ----------
    epsilon : float
        Absolute threshold for convergence when f_global is known.
        Converged when |best_score - f_global| < epsilon.
    n_iter_no_change : int
        Fallback for functions without known optimum.
        Converged when no improvement for this many iterations.
    tol_abs : float
        Minimum absolute improvement to count as "change"
        for the n_iter_no_change check.
    """

    epsilon: float = 1e-2
    n_iter_no_change: int = 50
    tol_abs: float = 1e-6


@dataclass
class ConvergenceResult:
    """Result of convergence analysis for a single run."""

    converged: bool
    iteration_converged: int | None = None
    time_converged: float | None = None
    final_gap: float | None = None


class ConvergenceChecker:
    """Checks convergence of a score history against a known or unknown optimum.

    All scores are expected in minimization space (lower = better).

    Two strategies:
    1. f_global known: converged when |best_score - f_global| < epsilon
    2. f_global unknown: converged when best score unchanged for n_iter_no_change
    """

    def __init__(
        self,
        config: ConvergenceConfig,
        f_global: float | None = None,
    ):
        self._config = config
        self._f_global = f_global

    def check(
        self,
        score_history: list[float],
        time_history: list[float],
    ) -> ConvergenceResult:
        if not score_history:
            return ConvergenceResult(converged=False)

        if self._f_global is not None:
            return self._check_absolute(score_history, time_history)
        return self._check_no_change(score_history, time_history)

    def _check_absolute(
        self,
        scores: list[float],
        times: list[float],
    ) -> ConvergenceResult:
        best_so_far = math.inf
        for i, score in enumerate(scores):
            best_so_far = min(best_so_far, score)
            if abs(best_so_far - self._f_global) < self._config.epsilon:
                return ConvergenceResult(
                    converged=True,
                    iteration_converged=i,
                    time_converged=times[i] if i < len(times) else None,
                    final_gap=abs(best_so_far - self._f_global),
                )
        return ConvergenceResult(
            converged=False,
            final_gap=abs(best_so_far - self._f_global),
        )

    def _check_no_change(
        self,
        scores: list[float],
        times: list[float],
    ) -> ConvergenceResult:
        n = self._config.n_iter_no_change
        tol = self._config.tol_abs
        best_so_far = math.inf
        best_at_iter = 0

        for i, score in enumerate(scores):
            if score < best_so_far - tol:
                best_so_far = score
                best_at_iter = i

            if i - best_at_iter >= n:
                return ConvergenceResult(
                    converged=True,
                    iteration_converged=i,
                    time_converged=times[i] if i < len(times) else None,
                )
        return ConvergenceResult(converged=False)
