from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from ._runner import _RunnerResult


class BenchmarkReport:
    """Container for benchmark results with analysis methods.

    All scores are in minimization space (lower = better).

    Parameters
    ----------
    results : list of _RunnerResult
        All individual run results from the benchmark.
    """

    def __init__(self, results: list[_RunnerResult]):
        self._results = results
        self._raw_df: pd.DataFrame | None = None

    _COLUMNS = [
        "optimizer", "function", "run", "seed",
        "best_score", "n_iterations", "wall_time",
        "converged", "iter_converged", "time_converged",
        "final_gap", "error",
    ]

    @property
    def raw_data(self) -> pd.DataFrame:
        """All individual runs as a DataFrame."""
        if self._raw_df is None:
            if not self._results:
                self._raw_df = pd.DataFrame(columns=self._COLUMNS)
            else:
                rows = []
                for r in self._results:
                    rows.append({
                        "optimizer": r.optimizer_name,
                        "function": r.function_name,
                        "run": r.run_index,
                        "seed": r.random_seed,
                        "best_score": r.best_score,
                        "n_iterations": r.n_iterations,
                        "wall_time": r.wall_time,
                        "converged": r.converged,
                        "iter_converged": r.iteration_converged,
                        "time_converged": r.time_converged,
                        "final_gap": r.final_gap,
                        "error": r.error,
                    })
                self._raw_df = pd.DataFrame(rows)
        return self._raw_df

    @property
    def errors(self) -> pd.DataFrame:
        """Runs that produced errors."""
        df = self.raw_data
        return df[df["error"].notna()]

    def summary(self) -> pd.DataFrame:
        """Aggregated results per optimizer.

        Returns
        -------
        pd.DataFrame
            Columns: optimizer, mean_score, std_score, median_score,
            mean_time, std_time, convergence_rate, n_runs,
            and optionally mean_iter_converged, mean_time_converged.
        """
        df = self.raw_data[self.raw_data["error"].isna()]
        if df.empty:
            return pd.DataFrame()

        grouped = df.groupby("optimizer")

        summary = grouped.agg(
            mean_score=("best_score", "mean"),
            std_score=("best_score", "std"),
            median_score=("best_score", "median"),
            mean_time=("wall_time", "mean"),
            std_time=("wall_time", "std"),
            convergence_rate=("converged", "mean"),
            n_runs=("run", "count"),
        ).reset_index()

        converged = df[df["converged"]]
        if not converged.empty:
            conv_agg = converged.groupby("optimizer").agg(
                mean_iter_converged=("iter_converged", "mean"),
                mean_time_converged=("time_converged", "mean"),
            ).reset_index()
            summary = summary.merge(conv_agg, on="optimizer", how="left")

        return summary

    def ranking(self, by: str = "score") -> pd.DataFrame:
        """Rank optimizers by specified criterion.

        Parameters
        ----------
        by : {"score", "iterations", "time"}
            - "score": by mean best score (ascending, lower = better)
            - "iterations": by mean iterations to convergence
            - "time": by mean wall-clock time to convergence
        """
        summary = self.summary()
        if summary.empty:
            return summary

        if by == "score":
            return summary.sort_values("mean_score", ascending=True).reset_index(
                drop=True
            )
        elif by == "iterations":
            if "mean_iter_converged" in summary.columns:
                return summary.sort_values(
                    "mean_iter_converged", ascending=True, na_position="last"
                ).reset_index(drop=True)
            return summary
        elif by == "time":
            if "mean_time_converged" in summary.columns:
                return summary.sort_values(
                    "mean_time_converged", ascending=True, na_position="last"
                ).reset_index(drop=True)
            return summary
        else:
            raise ValueError(
                f"Unknown ranking criterion: {by!r}. "
                f"Use 'score', 'iterations', or 'time'."
            )

    def per_function(self) -> pd.DataFrame:
        """Optimizer x Function breakdown with aggregated statistics."""
        df = self.raw_data[self.raw_data["error"].isna()]
        if df.empty:
            return pd.DataFrame()

        return df.groupby(["optimizer", "function"]).agg(
            mean_score=("best_score", "mean"),
            std_score=("best_score", "std"),
            convergence_rate=("converged", "mean"),
            mean_time=("wall_time", "mean"),
        ).reset_index()

    def compare(self, optimizer_a: str, optimizer_b: str) -> pd.DataFrame:
        """Pairwise comparison between two optimizers per function.

        For each function, shows which optimizer achieved a better mean score.
        """
        pf = self.per_function()
        if pf.empty:
            return pd.DataFrame()

        a_data = pf[pf["optimizer"] == optimizer_a].set_index("function")
        b_data = pf[pf["optimizer"] == optimizer_b].set_index("function")

        a_col = f"{optimizer_a}_score"
        b_col = f"{optimizer_b}_score"

        comparison = a_data[["mean_score"]].rename(
            columns={"mean_score": a_col}
        ).join(
            b_data[["mean_score"]].rename(columns={"mean_score": b_col}),
            how="outer",
        )

        comparison["winner"] = np.where(
            comparison[a_col] < comparison[b_col],
            optimizer_a,
            np.where(
                comparison[a_col] > comparison[b_col],
                optimizer_b,
                "tie",
            ),
        )

        return comparison.reset_index()

    def convergence_data(
        self, optimizer: str, function: str
    ) -> dict[str, Any]:
        """Get convergence curve data for a specific (optimizer, function) pair.

        Returns
        -------
        dict
            Keys: "iterations" (list[int]), "runs" (list[list[float]]),
            "mean" (list[float]), "std" (list[float]).
            Each curve is the running-best score over iterations.
        """
        matching = [
            r
            for r in self._results
            if r.optimizer_name == optimizer
            and r.function_name == function
            and r.error is None
        ]

        if not matching:
            return {"iterations": [], "runs": [], "mean": [], "std": []}

        # Pad shorter runs with their final value to align lengths
        max_len = max(len(r.best_so_far_history) for r in matching)
        padded = []
        for r in matching:
            curve = list(r.best_so_far_history)
            if curve and len(curve) < max_len:
                curve.extend([curve[-1]] * (max_len - len(curve)))
            padded.append(curve)

        arr = np.array(padded)
        return {
            "iterations": list(range(max_len)),
            "runs": [list(row) for row in arr],
            "mean": list(arr.mean(axis=0)),
            "std": list(arr.std(axis=0)),
        }
