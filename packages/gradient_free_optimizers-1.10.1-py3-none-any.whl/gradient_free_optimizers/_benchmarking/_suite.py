from __future__ import annotations

from typing import Any


class BenchmarkSuite:
    """A collection of test functions for benchmarking.

    Wraps Surfaces test function classes with configuration for
    instantiation (n_dim, resolution).

    Parameters
    ----------
    functions : list of type
        Surfaces test function classes (not instances).
    n_dim : int or None
        Number of dimensions for scalable functions.
        Ignored for fixed-dimension functions.
    resolution : int
        Points per dimension for the search space discretization.
    name : str or None
        Human-readable name for this suite.
    """

    def __init__(
        self,
        functions: list[type],
        n_dim: int | None = None,
        resolution: int = 100,
        name: str | None = None,
    ):
        self._function_classes = list(functions)
        self._n_dim = n_dim
        self._resolution = resolution
        self._name = name

    @property
    def name(self) -> str:
        return self._name or f"Custom({len(self._function_classes)} functions)"

    def __len__(self) -> int:
        return len(self._function_classes)

    def __iter__(self):
        return iter(self._function_classes)

    def __repr__(self) -> str:
        return f"BenchmarkSuite('{self.name}', {len(self)} functions)"

    def instantiate(self) -> list[tuple[str, Any]]:
        """Create (name, instance) pairs for all functions in the suite.

        Handles scalable vs fixed-dimension functions automatically.
        Scalable functions receive the suite's n_dim parameter.
        """
        instances = []
        for func_cls in self._function_classes:
            is_scalable = _is_scalable(func_cls)

            if is_scalable and self._n_dim is not None:
                inst = func_cls(n_dim=self._n_dim)
                func_name = f"{func_cls.__name__}(n_dim={self._n_dim})"
            elif is_scalable:
                inst = func_cls(n_dim=2)
                func_name = f"{func_cls.__name__}(n_dim=2)"
            else:
                inst = func_cls()
                func_name = func_cls.__name__

            instances.append((func_name, inst))
        return instances

    # ─────────────────────────────────────────────────────────────────
    # Predefined suite factory methods
    # ─────────────────────────────────────────────────────────────────

    @classmethod
    def convex(cls, n_dim: int = 10, resolution: int = 100) -> BenchmarkSuite:
        """Convex unimodal functions (easy baseline)."""
        from surfaces.test_functions.algebraic import (
            BoothFunction,
            MatyasFunction,
            SphereFunction,
        )

        return cls(
            [SphereFunction, MatyasFunction, BoothFunction],
            n_dim=n_dim,
            resolution=resolution,
            name="convex",
        )

    @classmethod
    def multimodal(cls, n_dim: int = 10, resolution: int = 100) -> BenchmarkSuite:
        """Multimodal functions with many local optima."""
        from surfaces.test_functions.algebraic import (
            AckleyFunction,
            CrossInTrayFunction,
            DropWaveFunction,
            EggholderFunction,
            GriewankFunction,
            HölderTableFunction,
            LeviFunctionN13,
            RastriginFunction,
            SchafferFunctionN2,
            StyblinskiTangFunction,
        )

        return cls(
            [
                AckleyFunction,
                RastriginFunction,
                GriewankFunction,
                StyblinskiTangFunction,
                EggholderFunction,
                SchafferFunctionN2,
                CrossInTrayFunction,
                DropWaveFunction,
                LeviFunctionN13,
                HölderTableFunction,
            ],
            n_dim=n_dim,
            resolution=resolution,
            name="multimodal",
        )

    @classmethod
    def ml(cls) -> BenchmarkSuite:
        """Machine learning hyperparameter optimization functions."""
        from surfaces.test_functions.machine_learning import (
            DecisionTreeClassifierFunction,
            DecisionTreeRegressorFunction,
            GradientBoostingClassifierFunction,
            GradientBoostingRegressorFunction,
            KNeighborsClassifierFunction,
            KNeighborsRegressorFunction,
            RandomForestClassifierFunction,
            RandomForestRegressorFunction,
            SVMClassifierFunction,
            SVMRegressorFunction,
        )

        return cls(
            [
                DecisionTreeClassifierFunction,
                DecisionTreeRegressorFunction,
                GradientBoostingClassifierFunction,
                GradientBoostingRegressorFunction,
                KNeighborsClassifierFunction,
                KNeighborsRegressorFunction,
                RandomForestClassifierFunction,
                RandomForestRegressorFunction,
                SVMClassifierFunction,
                SVMRegressorFunction,
            ],
            name="ml",
        )

    @classmethod
    def standard(cls, n_dim: int = 10, resolution: int = 100) -> BenchmarkSuite:
        """Standard academic benchmark (15 functions)."""
        from surfaces.collection.suites import standard

        return cls(list(standard), n_dim=n_dim, resolution=resolution, name="standard")

    @classmethod
    def bbob(cls, n_dim: int = 10, resolution: int = 100) -> BenchmarkSuite:
        """COCO/BBOB benchmark (24 functions)."""
        from surfaces.collection.suites import bbob

        return cls(list(bbob), n_dim=n_dim, resolution=resolution, name="bbob")

    @classmethod
    def from_collection(
        cls,
        collection,
        n_dim: int | None = None,
        resolution: int = 100,
    ) -> BenchmarkSuite:
        """Create a suite from a Surfaces collection (e.g. filtered result)."""
        return cls(
            list(collection),
            n_dim=n_dim,
            resolution=resolution,
            name="from_collection",
        )


def _get_spec(func_cls: type) -> dict[str, Any]:
    """Get merged _spec dict from class hierarchy."""
    result = {}
    for klass in reversed(func_cls.__mro__):
        if hasattr(klass, "_spec"):
            result.update(klass._spec)
    return result


def _is_scalable(func_cls: type) -> bool:
    spec = _get_spec(func_cls)
    return spec.get("scalable", False)
