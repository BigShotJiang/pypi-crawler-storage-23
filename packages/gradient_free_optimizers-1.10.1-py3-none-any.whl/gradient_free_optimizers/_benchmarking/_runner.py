from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Any

from ._convergence import ConvergenceChecker


@dataclass
class _RunnerResult:
    """Result of a single (optimizer, function, run) execution."""

    optimizer_name: str
    function_name: str
    run_index: int
    random_seed: int | None

    best_score: float
    best_params: dict[str, Any]
    n_iterations: int
    wall_time: float

    converged: bool
    iteration_converged: int | None = None
    time_converged: float | None = None
    final_gap: float | None = None

    score_history: list[float] = field(default_factory=list)
    best_so_far_history: list[float] = field(default_factory=list)
    time_history: list[float] = field(default_factory=list)

    error: str | None = None


def run_single(
    optimizer_cls: type,
    optimizer_kwargs: dict[str, Any],
    optimizer_name: str,
    func_instance: Any,
    func_name: str,
    run_index: int,
    n_iter: int | None,
    max_time: float | None,
    random_seed: int | None,
    convergence_checker: ConvergenceChecker,
) -> _RunnerResult:
    """Execute a single benchmark run.

    This is a module-level function (not a method) to ensure picklability
    for joblib parallel execution.

    Direction bridge:
    - Surfaces functions return raw loss (minimize convention, lower = better)
    - GFO always maximizes internally, so we negate: objective = -loss
    - search_data["score"] stores -loss (negative values for Sphere etc.)
    - We negate back to get minimization scores: loss = -gfo_score
    """
    try:
        search_space = func_instance.search_space

        opt = optimizer_cls(
            search_space,
            random_state=random_seed,
            **optimizer_kwargs,
        )

        # Negate objective for GFO (which always maximizes).
        # Surfaces functions return loss (lower = better), GFO maximizes,
        # so maximizing -loss = minimizing loss.
        def negated_objective(params):
            return -func_instance(params)

        start_time = time.perf_counter()

        search_kwargs = {
            "memory": True,
            "verbosity": False,
        }
        if n_iter is not None:
            search_kwargs["n_iter"] = n_iter
        if max_time is not None:
            search_kwargs["max_time"] = max_time

        opt.search(negated_objective, **search_kwargs)

        wall_time = time.perf_counter() - start_time

        # search_data["score"] contains -loss (GFO's internal scores).
        # Negate back to minimization space (loss, lower = better).
        raw_scores = opt.search_data["score"].tolist()
        score_history = [-s for s in raw_scores]

        # Build running-best history (minimization: lower is better)
        best_so_far = math.inf
        best_so_far_history = []
        for s in score_history:
            best_so_far = min(best_so_far, s)
            best_so_far_history.append(best_so_far)

        # Approximate time distribution across iterations
        n_actual = len(score_history)
        if n_actual > 0:
            time_history = [
                wall_time * (i + 1) / n_actual for i in range(n_actual)
            ]
        else:
            time_history = []

        # best_score in GFO = max(-loss) = -min_loss
        # Negate back: min_loss = -opt.best_score
        best_score_min = -opt.best_score

        conv_result = convergence_checker.check(score_history, time_history)

        return _RunnerResult(
            optimizer_name=optimizer_name,
            function_name=func_name,
            run_index=run_index,
            random_seed=random_seed,
            best_score=best_score_min,
            best_params=opt.best_para,
            n_iterations=n_actual,
            wall_time=wall_time,
            converged=conv_result.converged,
            iteration_converged=conv_result.iteration_converged,
            time_converged=conv_result.time_converged,
            final_gap=conv_result.final_gap,
            score_history=score_history,
            best_so_far_history=best_so_far_history,
            time_history=time_history,
        )

    except Exception as e:
        return _RunnerResult(
            optimizer_name=optimizer_name,
            function_name=func_name,
            run_index=run_index,
            random_seed=random_seed,
            best_score=math.inf,
            best_params={},
            n_iterations=0,
            wall_time=0.0,
            converged=False,
            error=f"{type(e).__name__}: {e}",
        )
