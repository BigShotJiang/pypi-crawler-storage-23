from __future__ import annotations

from typing import Any

from ._convergence import ConvergenceChecker, ConvergenceConfig
from ._report import BenchmarkReport
from ._runner import _RunnerResult, run_single
from ._suite import BenchmarkSuite


class Benchmark:
    """Orchestrates benchmark execution across optimizers and test functions.

    Parameters
    ----------
    optimizers : dict
        Mapping of label -> optimizer class or (class, kwargs) tuple.
        Example: {"HC": HillClimbingOptimizer,
                  "HC_eps01": (HillClimbingOptimizer, {"epsilon": 0.1})}
    suite : BenchmarkSuite
        The test function suite to benchmark against.
    n_iter : int or None
        Default iteration budget per run. Can be overridden in run().
    max_time : float or None
        Default time budget per run (seconds). Can be overridden in run().
    n_runs : int
        Number of independent runs per (optimizer, function) pair.
    random_state : int or None
        Base random seed. Per-run seeds: random_state + run_index.
    convergence_threshold : float
        Epsilon for absolute convergence: |best - f_global| < epsilon.
    n_iter_no_change : int
        Fallback convergence: iterations without improvement.
    n_jobs : int
        Parallel jobs. 1 = sequential, -1 = all CPUs.
    """

    def __init__(
        self,
        optimizers: dict[str, type | tuple[type, dict[str, Any]]],
        suite: BenchmarkSuite,
        n_iter: int | None = 500,
        max_time: float | None = None,
        n_runs: int = 10,
        random_state: int | None = 42,
        convergence_threshold: float = 1e-2,
        n_iter_no_change: int = 50,
        n_jobs: int = 1,
    ):
        self._optimizers = _parse_optimizers(optimizers)
        self._suite = suite
        self._n_iter = n_iter
        self._max_time = max_time
        self._n_runs = n_runs
        self._random_state = random_state
        self._convergence_threshold = convergence_threshold
        self._n_iter_no_change = n_iter_no_change
        self._n_jobs = n_jobs

    def run(
        self,
        n_iter: int | None = None,
        max_time: float | None = None,
    ) -> BenchmarkReport:
        """Execute the benchmark.

        Parameters
        ----------
        n_iter : int or None
            Override iteration budget. Falls back to constructor value.
        max_time : float or None
            Override time budget. Falls back to constructor value.

        Returns
        -------
        BenchmarkReport
        """
        n_iter = n_iter if n_iter is not None else self._n_iter
        max_time = max_time if max_time is not None else self._max_time

        if n_iter is None and max_time is None:
            raise ValueError(
                "At least one of n_iter or max_time must be set, "
                "either in the constructor or in run()."
            )

        function_instances = self._suite.instantiate()

        jobs = self._build_jobs(function_instances, n_iter, max_time)

        if self._n_jobs == 1:
            results = [run_single(*job) for job in jobs]
        else:
            results = self._run_parallel(jobs)

        return BenchmarkReport(results)

    def _build_jobs(
        self,
        function_instances: list[tuple[str, Any]],
        n_iter: int | None,
        max_time: float | None,
    ) -> list[tuple]:
        jobs = []
        for opt_name, opt_cls, opt_kwargs in self._optimizers:
            for func_name, func_instance in function_instances:
                f_global = getattr(func_instance, "f_global", None)
                conv_config = ConvergenceConfig(
                    epsilon=self._convergence_threshold,
                    n_iter_no_change=self._n_iter_no_change,
                )
                checker = ConvergenceChecker(conv_config, f_global=f_global)

                for run_idx in range(self._n_runs):
                    seed = (
                        self._random_state + run_idx
                        if self._random_state is not None
                        else None
                    )
                    jobs.append((
                        opt_cls,
                        opt_kwargs,
                        opt_name,
                        func_instance,
                        func_name,
                        run_idx,
                        n_iter,
                        max_time,
                        seed,
                        checker,
                    ))
        return jobs

    def _run_parallel(self, jobs: list) -> list[_RunnerResult]:
        try:
            from joblib import Parallel, delayed
        except ImportError:
            raise ImportError(
                "joblib is required for parallel benchmark execution (n_jobs != 1). "
                "Install it with: pip install joblib"
            ) from None

        return Parallel(n_jobs=self._n_jobs)(
            delayed(run_single)(*job) for job in jobs
        )


def _parse_optimizers(
    optimizers: dict[str, type | tuple[type, dict[str, Any]]],
) -> list[tuple[str, type, dict[str, Any]]]:
    parsed = []
    for name, value in optimizers.items():
        if isinstance(value, tuple):
            cls, kwargs = value
        else:
            cls, kwargs = value, {}
        parsed.append((name, cls, kwargs))
    return parsed
