from setuptools import setup, find_packages
import requests



setup(
    name="just4testlm",
    version="0.2.0",
    author="lm",
    author_email="lm@example.com",
    description="A hello world demo package",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[
        "requests",
    ],
    entry_points={
        "console_scripts": [
            "hello=hello_world:hello",
        ],
    },
)
