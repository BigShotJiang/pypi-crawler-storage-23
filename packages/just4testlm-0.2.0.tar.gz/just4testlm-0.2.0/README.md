# Hello World Demo

A simple hello world package.

## Usage

```python
from hello_world import hello
hello()
```

Or run directly: `hello`
