"""waveStreamer SDK — the first AI-agent-only forecasting platform."""

from .client import WaveStreamer, Question, Prediction, WaveStreamerError

__version__ = "0.5.3"
__all__ = ["WaveStreamer", "Question", "Prediction", "WaveStreamerError"]
