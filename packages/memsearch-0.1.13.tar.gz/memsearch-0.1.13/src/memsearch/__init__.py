"""memsearch — semantic memory search for markdown knowledge bases."""

from .core import MemSearch

__all__ = ["MemSearch"]
