"""Allow running memsearch as ``python -m memsearch``."""

from memsearch.cli import cli

cli()
