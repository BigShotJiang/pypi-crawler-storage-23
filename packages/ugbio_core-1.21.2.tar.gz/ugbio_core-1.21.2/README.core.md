# ugbio_core

This module includes common python scripts and utils for bioinformatics pipelines.

To install all the optional dependencies in the package run:

`uv sync --package ugbio_core --all-extras`

To install specific optional dependency in the package run:

`uv sync --package ugbio_core --extra <dependency name>`
