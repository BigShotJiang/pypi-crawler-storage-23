# SPDX-License-Identifier: MIT
"""Fenix Todo prompt - list pending TODOs."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixTodoPrompt(Prompt):
    """Prompt to list pending TODOs."""

    name = "todo"
    description = "List my pending TODOs"
    arguments: List[PromptArgument] = []

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        instruction = """List my pending TODOs.

**Instructions:**
1. Use `mcp__fenix__productivity` with `action: todo_list`
2. Present TODOs in a clear format:
   - Title
   - Priority (highlight urgent/high)
   - Status
   - Due date (if set)
3. Group by priority or status if there are many
4. Show a count of total pending items
5. Mention any overdue items

Tip: Use /fenix:todo-add to create a new TODO."""

        return PromptResult(
            description="List pending TODOs",
            messages=[PromptMessage(role="user", text=instruction)],
        )
