# SPDX-License-Identifier: MIT
"""Fenix Docs Create prompt - create documentation from conversation."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixDocsCreatePrompt(Prompt):
    """Prompt to create documentation from conversation context."""

    name = "docs-create"
    description = "Create documentation from conversation context"
    arguments: List[PromptArgument] = []

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        instruction = """Create documentation based on our conversation.

**Instructions:**
1. First, use `mcp__fenix__knowledge` with `action: doc_full_tree` to show the \
documentation structure
2. Analyze our conversation and identify what should be documented
3. Ask me where I want to place this new document (which parent folder)
4. Once I confirm the location, use `action: doc_create` with:
   - doc_title: An appropriate title based on the conversation
   - doc_type: "page"
   - doc_emoji: A relevant emoji
   - doc_parent_id: The ID of the chosen folder
   - doc_content: Generate documentation content from our conversation
5. Confirm the document was created with its title and location"""

        return PromptResult(
            description="Create documentation from conversation",
            messages=[PromptMessage(role="user", text=instruction)],
        )
