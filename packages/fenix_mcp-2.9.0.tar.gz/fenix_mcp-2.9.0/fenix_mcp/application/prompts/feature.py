# SPDX-License-Identifier: MIT
"""Fenix Feature prompt - create a feature request from conversation context."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixFeaturePrompt(Prompt):
    """Prompt to create a feature request from conversation context."""

    name = "feature"
    description = "Create a feature request from conversation context"
    arguments: List[PromptArgument] = []

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        instruction = """Create a feature request in Fenix based on our conversation.

**Instructions:**
1. Analyze the conversation to identify the feature being discussed
2. Use `mcp__fenix__knowledge` with `action: work_create` and:
   - work_type: "feature"
   - work_title: A clear title describing the feature
   - work_description: Include:
     - **Goal**: What this feature should accomplish
     - **User Story**: As a [user], I want [feature] so that [benefit]
     - **Requirements**: Key requirements discussed
     - **Notes**: Any additional context from our conversation
   - work_category: Choose appropriate (backend, frontend, fullstack, etc.)
   - work_priority: Set based on importance discussed (default: medium)
   - work_tags: Add relevant tags
3. Confirm with the feature key (e.g., PROJ-123)"""

        return PromptResult(
            description="Create feature request from conversation",
            messages=[PromptMessage(role="user", text=instruction)],
        )
