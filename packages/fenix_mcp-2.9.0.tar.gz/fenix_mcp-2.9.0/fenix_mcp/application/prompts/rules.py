# SPDX-License-Identifier: MIT
"""Fenix Rules prompt - list team coding rules and standards."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixRulesPrompt(Prompt):
    """Prompt to list team coding rules and standards."""

    name = "rules"
    description = "List team coding rules and standards"
    arguments: List[PromptArgument] = []

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        instruction = """List the team's coding rules and standards using the \
`mcp__fenix__knowledge` tool with `action: rule_list`.

**Instructions:**
1. Fetch all active team rules
2. Present them in a clear, organized format
3. Include: rule name, description, and scope for each rule
4. If there are many rules, group them by category or scope
5. Highlight any rules that are particularly important or frequently referenced"""

        return PromptResult(
            description="List team coding rules and standards",
            messages=[PromptMessage(role="user", text=instruction)],
        )
