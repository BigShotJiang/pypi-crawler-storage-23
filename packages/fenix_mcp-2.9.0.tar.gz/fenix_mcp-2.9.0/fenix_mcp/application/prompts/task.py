# SPDX-License-Identifier: MIT
"""Fenix Task prompt - create a task from conversation context."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixTaskPrompt(Prompt):
    """Prompt to create a task from conversation context."""

    name = "task"
    description = "Create a task from conversation context"
    arguments: List[PromptArgument] = []

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        instruction = """Create a task in Fenix based on our conversation.

**Instructions:**
1. Analyze the conversation to identify the main action item or task
2. Use `mcp__fenix__knowledge` with `action: work_create` and:
   - work_type: "task"
   - work_title: A clear, actionable title
   - work_description: Context and requirements from our conversation
   - work_category: Choose appropriate (backend, frontend, fullstack, etc.)
   - work_priority: Set based on urgency discussed (default: medium)
   - work_tags: Add relevant tags
3. Confirm with the task key (e.g., PROJ-123)

Tip: Use /fenix:bug for bugs or /fenix:feature for feature requests."""

        return PromptResult(
            description="Create task from conversation",
            messages=[PromptMessage(role="user", text=instruction)],
        )
