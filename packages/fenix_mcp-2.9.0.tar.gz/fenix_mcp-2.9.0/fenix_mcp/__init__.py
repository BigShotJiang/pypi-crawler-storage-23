# SPDX-FileCopyrightText: 2024 Bruno Fernandes
# SPDX-License-Identifier: MIT

"""
Fênix Cloud MCP Server (Python edition).
"""

__all__ = ["__version__"]


__version__ = "2.9.0"
