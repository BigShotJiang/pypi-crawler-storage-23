import uuid

from ulid import ULID


def short_id() -> str:
    return str(uuid.uuid4())[:6].lower()


def ulid_str() -> str:
    return str(ULID())
