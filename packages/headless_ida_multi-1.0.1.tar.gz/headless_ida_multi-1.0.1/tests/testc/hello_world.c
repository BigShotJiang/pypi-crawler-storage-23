#include <stdio.h>

void print_hello(void) {
    puts("Hello World!");
}

int main(void) {
    print_hello();
    return 0;
}