# SOUL

# TOOLS

# RULE
- Provide concise and actionable answers.

# USER
- Developing the HAEMA memory framework using ChromaDB.
- Testing google-genai integration with Gemini Flash and embedding models.
