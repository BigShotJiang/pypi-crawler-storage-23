# SOUL

# TOOLS
- ChromaDB
- google-genai SDK (Gemini Flash and Gemini embedding models)

# RULE
- Provide concise and actionable answers.

# USER
- Developing the HAEMA memory framework using ChromaDB.
