"""OpenClaw Stock Kit — Korean stock market data & trading toolkit.

Usage:
    pip install openclaw-stock-kit             # install
    openclaw-stock-kit                         # start server + setup wizard
    openclaw-stock-kit call list               # list available tools
    openclaw-stock-kit call gateway_status     # direct CLI call (no MCP needed)
    openclaw-stock-kit --stdio                 # stdio mode (Claude Code MCP)
"""

__version__ = "2.0.0"
