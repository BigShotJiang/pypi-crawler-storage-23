---
name: stock-kit
description: |
  Korean stock market data & trading toolkit.
  Call tools directly via CLI — no MCP protocol needed.

  Triggers: 주식, 현재가, 시세, 매매, 주문, 잔고, 뉴스, 공시, 차트,
  종목, 코스피, 코스닥, 환율, 금리, 시가총액, 급등주, 호가, 배당,
  stock, price, trade, order, balance, news, disclosure, chart, KOSPI

  Do NOT use for: general knowledge, coding, non-stock questions, cryptocurrency
argument-hint: "[종목명|질문]"
user-invocable: true
---

# Stock Kit — CLI 직접 호출 가이드

## 핵심: exec 도구로 바로 호출

MCP 프로토콜 불필요. exec 도구(bash)로 직접 호출한다.

```bash
/root/.local/bin/openclaw-stock-kit call <도구명> '<JSON 파라미터>' 2>/dev/null
```

### 기본 사용법

```bash
# 도구 목록 확인
/root/.local/bin/openclaw-stock-kit call list 2>/dev/null

# 상태 확인 (첫 호출 시 권장)
/root/.local/bin/openclaw-stock-kit call gateway_status 2>/dev/null

# 종목 검색 (무료, 키 불필요)
/root/.local/bin/openclaw-stock-kit call datakit_call '{"function":"search_stock","params_json":"{\"keyword\":\"삼성전자\"}"}' 2>/dev/null

# 과거 주가 조회 (무료)
/root/.local/bin/openclaw-stock-kit call datakit_call '{"function":"get_price","params_json":"{\"ticker\":\"005930\",\"start\":\"20260101\",\"end\":\"20260219\"}"}' 2>/dev/null

# 뉴스 검색
/root/.local/bin/openclaw-stock-kit call news_search_stock '{"stock_name":"삼성전자","days":7}' 2>/dev/null

# 키움 실시간 현재가 (키움 인증 필요)
/root/.local/bin/openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10001","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

중요: 2>/dev/null을 항상 붙여서 로딩 로그를 숨긴다.

---

## 도구 카탈로그 (29개)

### 1. DataKit — 과거 데이터 (무료, 키 불필요)

| 도구 | 설명 |
|------|------|
| datakit_call | 13개 함수 통합 호출 (get_price, get_ohlcv, search_stock 등) |
| datakit_list_functions | 사용 가능한 함수 카탈로그 |
| datakit_get_env_info | 환경 정보 + API 키 상태 |

#### datakit_call 주요 함수

| function | 설명 | params_json 예시 |
|----------|------|------------------|
| search_stock | 종목명으로 종목코드 검색 | {"keyword":"삼성전자"} |
| get_price | 일별 종가 | {"ticker":"005930","start":"20260101","end":"20260219"} |
| get_ohlcv | 일봉 (시고저종 거래량) | {"ticker":"005930","start":"20260101","end":"20260219"} |
| get_market_cap | 시가총액 | {"ticker":"005930","start":"20260101","end":"20260219"} |
| get_supply | 수급 (기관/외인 순매수) | {"ticker":"005930","start":"20260101","end":"20260219"} |
| get_index | 지수 (코스피/코스닥) | {"ticker":"1001","start":"20260101","end":"20260219"} |
| dart_disclosures | DART 공시 검색 | {"corp_name":"삼성전자","days":30} |
| ecos_indicator | ECOS 경제지표 | {"stat_code":"722Y001","item_code":"0101000","start":"202501","end":"202602"} |
| exchange_rate | 환율 조회 | {"currency":"USD","date":"20260219"} |

### 2. Kiwoom — 실시간 시세 + 매매 (키움 인증 필요)

| 도구 | 설명 |
|------|------|
| kiwoom_call_api | 185개 REST API 통합 호출 |
| kiwoom_list_apis | API 코드 카탈로그 |
| kiwoom_api_spec | API 스펙 조회 (파라미터 확인용) |
| kiwoom_get_env_info | 키움 환경 정보 |
| kiwoom_condition_list | 조건검색식 목록 |
| kiwoom_condition_search | 조건검색 종목조회 |
| kiwoom_condition_realtime | 실시간 조건검색 등록 |
| kiwoom_condition_stop | 실시간 조건검색 해제 |

#### kiwoom_call_api 주요 tr_id

| tr_id | 설명 |
|-------|------|
| ka10001 | 현재가 |
| ka10004 | 호가 |
| ka10081 | 일봉 차트 |
| ka10083 | 분봉 차트 |
| ka20001 | 업종 현재가 |
| kt10000 | 매수 주문 |
| kt10001 | 매도 주문 |

### 3. KIS — 한국투자증권 (KIS 인증 필요)

| 도구 | 설명 |
|------|------|
| kis_domestic_stock | 국내주식 74개 API |
| kis_overseas_stock | 해외주식 34개 API |
| kis_domestic_bond | 장내채권 14개 API |
| kis_domestic_futureoption | 국내선물옵션 20개 API |
| kis_overseas_futureoption | 해외선물옵션 19개 API |
| kis_elw | ELW 1개 API |
| kis_etfetn | ETF/ETN 2개 API |
| kis_auth | 인증 2개 API |
| kis_get_env_info | KIS 환경 정보 |

### 4. News — 뉴스 + 텔레그램

| 도구 | 설명 |
|------|------|
| news_search | 키워드 뉴스 검색 (Naver API) |
| news_search_stock | 종목별 뉴스 (중복제거) |
| telegram_auth | 텔레그램 인증 관리 |
| telegram_get_channels | 구독 채널 목록 |
| telegram_get_messages | 채널 메시지 조회 |
| news_get_env_info | 뉴스 환경 정보 |

### 5. Premium + Gateway

| 도구 | 설명 |
|------|------|
| premium_call | 브리핑, 엑셀, 백테스트, 강좌 |
| premium_list_functions | 프리미엄 기능 목록 |
| gateway_status | 전체 모듈 상태 + 도구 선택 가이드 |

---

## 의사결정 트리

1. 뉴스/소식 -> news_search_stock 또는 telegram_get_messages
2. 과거 주가/차트/시총 -> datakit_call (무료, 즉시 사용)
3. 실시간 현재가/호가 -> kiwoom_call_api 또는 kis_domestic_stock
4. 매매 주문 -> kiwoom_call_api 또는 kis_domestic_stock
5. 공시/거시지표 -> datakit_call (DART/ECOS)
6. 종목코드 모를 때 -> datakit_call (function=search_stock)
7. 모듈 상태 확인 -> gateway_status

---

## 에러 대처

- "Tool not found" -> call list로 정확한 도구명 확인
- "Unexpected keyword argument" -> kiwoom_api_spec 또는 datakit_list_functions로 파라미터 확인
- "KIWOOM_APP_KEY not set" -> 키움 API 키 미설정
- "Connection refused" -> call 모드는 SSE 서버 불필요 (독립 실행)
