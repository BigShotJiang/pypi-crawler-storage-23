#!/usr/bin/env python3
"""PreToolUse hook - logs tool call before execution.

This hook is called by Claude Code before each tool is executed.
It logs the tool name and input to the Cortex activity database.

Hook configuration for settings.json:
{
    "hooks": {
        "PreToolUse": [
            {
                "type": "command",
                "command": "python hooks/pre_tool_use.py"
            }
        ]
    }
}
"""

import json
import re
import sys
import os
import sqlite3
import time as _time
from datetime import datetime, timezone
from pathlib import Path

# Import shared session management
from session_utils import get_or_create_session, extract_skill_info, ensure_analytics_columns

# Import middleware cache (fail-open if not available)
# Note: check_cache and compute_cache_key removed — cache blocking is disabled
# (see comment in main()). Only ensure_cache_table is needed for DB init.
try:
    from middleware_cache import ensure_cache_table
except ImportError:
    ensure_cache_table = None


# Patterns for sensitive field names that should be redacted
SENSITIVE_FIELD_PATTERNS = [
    r'(?i)(api[_-]?key|apikey)',
    r'(?i)(password|passwd|pwd)',
    r'(?i)(secret|token|credential)',
    r'(?i)(auth[_-]?token|access[_-]?token)',
    r'(?i)(private[_-]?key|ssh[_-]?key)',
]


def redact_sensitive_fields(data: dict) -> dict:
    """Redact sensitive fields from a dictionary for safe logging.

    Recursively processes nested dicts and lists.
    """
    if not isinstance(data, dict):
        return data

    result = {}
    for key, value in data.items():
        # Check if key matches sensitive patterns
        is_sensitive = any(
            re.search(pattern, str(key))
            for pattern in SENSITIVE_FIELD_PATTERNS
        )

        if is_sensitive:
            result[key] = '[REDACTED]'
        elif isinstance(value, dict):
            result[key] = redact_sensitive_fields(value)
        elif isinstance(value, list):
            result[key] = [
                redact_sensitive_fields(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            result[key] = value

    return result


def get_db_path() -> Path:
    """Get the database path for the current project."""
    project_path = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())
    return Path(project_path) / ".omni-cortex" / "cortex.db"


def ensure_database(db_path: Path) -> sqlite3.Connection:
    """Ensure database exists and is initialized.

    Auto-creates the database and schema if it doesn't exist.
    This enables 'out of the box' functionality.
    """
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 30000")

    # Check if schema exists
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='activities'")
    if cursor.fetchone() is None:
        # Apply minimal schema for activities (full schema applied by MCP)
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS activities (
                id TEXT PRIMARY KEY,
                session_id TEXT,
                agent_id TEXT,
                timestamp TEXT NOT NULL,
                event_type TEXT NOT NULL,
                tool_name TEXT,
                tool_input TEXT,
                tool_output TEXT,
                duration_ms INTEGER,
                success INTEGER DEFAULT 1,
                error_message TEXT,
                project_path TEXT,
                file_path TEXT,
                metadata TEXT,
                started_at_ms INTEGER
            );
            CREATE INDEX IF NOT EXISTS idx_activities_timestamp ON activities(timestamp DESC);
            CREATE INDEX IF NOT EXISTS idx_activities_tool ON activities(tool_name);
        """)
        conn.commit()
    else:
        # Migration: add started_at_ms column for existing databases
        columns = [row[1] for row in cursor.execute("PRAGMA table_info(activities)").fetchall()]
        if "started_at_ms" not in columns:
            cursor.execute("ALTER TABLE activities ADD COLUMN started_at_ms INTEGER")
            conn.commit()

    # Ensure middleware_cache table exists (Spec 2)
    if ensure_cache_table is not None:
        try:
            ensure_cache_table(conn)
        except Exception:
            pass  # Fail-open

    return conn


def generate_id() -> str:
    """Generate a unique activity ID."""
    timestamp_ms = int(datetime.now().timestamp() * 1000)
    random_hex = os.urandom(4).hex()
    return f"act_{timestamp_ms}_{random_hex}"


def truncate(text: str, max_length: int = 10000) -> str:
    """Truncate text to max length."""
    if len(text) <= max_length:
        return text
    return text[:max_length - 20] + "\n... [truncated]"


def main():
    """Process PreToolUse hook."""
    try:
        # Read input from stdin with timeout protection
        import select
        if sys.platform != "win32":
            # Unix: use select for timeout
            ready, _, _ = select.select([sys.stdin], [], [], 5.0)
            if not ready:
                print(json.dumps({}))
                return

        # Read all input at once
        raw_input = sys.stdin.read()
        if not raw_input or not raw_input.strip():
            print(json.dumps({}))
            return

        input_data = json.loads(raw_input)

        # Extract data from hook input
        tool_name = input_data.get("tool_name")
        tool_input = input_data.get("tool_input", {})
        agent_id = input_data.get("agent_id")

        # Skip logging our own tools to prevent recursion
        # MCP tools are named like "mcp__omni-cortex__cortex_remember"
        if tool_name and ("cortex_" in tool_name or "omni-cortex" in tool_name):
            print(json.dumps({}))
            return

        project_path = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())

        # === Cache Check (Spec 2) — DISABLED (blocking) ===
        # The hook protocol only supports "block" (deny) or pass-through.
        # There is no "result substitution" mechanism, so using
        # {"decision": "block", "systemMessage": cached_content} causes the
        # tool to appear DENIED rather than returning cached data. The LLM
        # sees "Blocked by hook" instead of the cached result.
        #
        # Cache STORAGE in post_tool_use.py still works and is kept for
        # analytics (hit rates, re-read frequency). If Claude Code ever adds
        # a "substitute" decision type, re-enable this block.
        #
        # See: handoff mem_1771241179356_33ceef01 for discovery context.

        # Auto-initialize database (creates if not exists)
        db_path = get_db_path()
        conn = ensure_database(db_path)

        # Ensure analytics columns exist (skill_name, command_scope, etc.)
        ensure_analytics_columns(conn)

        # Get or create session (auto-manages session lifecycle)
        session_id = get_or_create_session(conn, project_path)

        # Redact sensitive fields before logging
        safe_input = redact_sensitive_fields(tool_input) if isinstance(tool_input, dict) else tool_input

        # Extract skill info for Skill tool calls
        skill_name = None
        command_scope = None
        if tool_name == "Skill" and isinstance(tool_input, dict):
            skill_name, command_scope = extract_skill_info(tool_input, project_path)

        # Generate activity ID
        activity_id = generate_id()

        # Insert activity record with started_at_ms for duration calculation (retry on lock)
        started_at_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
        cursor = conn.cursor()
        _retry_backoff = [0.2, 0.5, 1.0, 2.0, 4.0]
        for _attempt in range(5):
            try:
                cursor.execute(
                    """
                    INSERT INTO activities (
                        id, session_id, agent_id, timestamp, event_type,
                        tool_name, tool_input, project_path, started_at_ms,
                        skill_name, command_scope
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        activity_id,
                        session_id,
                        agent_id,
                        datetime.now(timezone.utc).isoformat(),
                        "pre_tool_use",
                        tool_name,
                        truncate(json.dumps(safe_input, default=str)),
                        project_path,
                        started_at_ms,
                        skill_name,
                        command_scope,
                    ),
                )
                conn.commit()
                break
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e) and _attempt < 4:
                    _time.sleep(_retry_backoff[_attempt])
                    continue
                raise
        conn.close()

        # Return empty response (no modification to tool call)
        print(json.dumps({}))

    except Exception as e:
        # Hooks should never block - log error but continue
        print(json.dumps({"systemMessage": f"Cortex pre_tool_use: {e}"}))

    sys.exit(0)


if __name__ == "__main__":
    main()
