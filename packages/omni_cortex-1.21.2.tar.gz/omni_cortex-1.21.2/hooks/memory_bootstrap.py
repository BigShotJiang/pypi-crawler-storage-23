#!/usr/bin/env python3
"""Auto-memory bootstrap for Claude Code projects.

Automatically creates and seeds ~/.claude/projects/{slug}/memory/MEMORY.md
when Claude Code starts in any project. On session end, enriches it with
learnings from the current session via Cortex DB.

This module is imported by user_prompt.py and stop.py hooks.
All functions are non-blocking (wrap in try/except, never raise).
No external dependencies (stdlib only).
"""

import json
import os
import re
import sqlite3
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Optional


def compute_slug(project_path: str) -> str:
    """Convert project path to Claude auto-memory slug.

    Algorithm: Remove ':', replace '\\' and '/' with '-'.

    Examples:
        D:\\Clients\\Ralph       -> D--Clients-Ralph
        /home/user/my-project   -> -home-user-my-project
        C:\\Users\\Tony\\Projects\\foo -> C--Users-Tony-Projects-foo
    """
    slug = project_path.replace(":", "-")
    slug = slug.replace("\\", "-")
    slug = slug.replace("/", "-")
    return slug


def get_memory_dir(project_path: str) -> Path:
    """Return ~/.claude/projects/{slug}/memory/"""
    slug = compute_slug(project_path)
    return Path.home() / ".claude" / "projects" / slug / "memory"


def get_memory_file(project_path: str) -> Path:
    """Return full path to MEMORY.md"""
    return get_memory_dir(project_path) / "MEMORY.md"


def detect_project_name(project_path: str) -> str:
    """Detect project name from config files or directory name.

    Detection order:
    1. CLAUDE.md title/header
    2. package.json -> name
    3. pyproject.toml -> [project].name
    4. Cargo.toml -> [package].name
    5. Directory basename (fallback)
    """
    p = Path(project_path)

    # 1. CLAUDE.md header
    try:
        claude_md = p / "CLAUDE.md"
        if claude_md.exists():
            with open(claude_md, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("# "):
                        name = line[2:].strip()
                        # Clean up common suffixes
                        for suffix in [" - ", " -- ", " | "]:
                            if suffix in name:
                                name = name.split(suffix)[0].strip()
                        if name:
                            return name
                    if line and not line.startswith("#"):
                        break  # Stop if we hit non-header content
    except Exception:
        pass

    # 2. package.json
    try:
        pkg_json = p / "package.json"
        if pkg_json.exists():
            with open(pkg_json, "r", encoding="utf-8") as f:
                data = json.load(f)
                name = data.get("name", "")
                if name:
                    return name
    except Exception:
        pass

    # 3. pyproject.toml
    try:
        pyproject = p / "pyproject.toml"
        if pyproject.exists():
            try:
                import tomllib
            except ImportError:
                tomllib = None

            if tomllib:
                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                    name = data.get("project", {}).get("name", "")
                    if name:
                        return name
            else:
                # Fallback: regex parse for name
                with open(pyproject, "r", encoding="utf-8") as f:
                    content = f.read()
                    match = re.search(r'^\s*name\s*=\s*"([^"]+)"', content, re.MULTILINE)
                    if match:
                        return match.group(1)
    except Exception:
        pass

    # 4. Cargo.toml
    try:
        cargo = p / "Cargo.toml"
        if cargo.exists():
            with open(cargo, "r", encoding="utf-8") as f:
                content = f.read()
                match = re.search(r'^\s*name\s*=\s*"([^"]+)"', content, re.MULTILINE)
                if match:
                    return match.group(1)
    except Exception:
        pass

    # 5. Fallback to directory basename
    return p.name


def seed_from_cortex(project_path: str, db_path: Path) -> list[str]:
    """Query Cortex DB for existing high-importance memories.

    Return list of formatted entries to include in template.
    Only includes memories with importance >= 70, top 10.
    """
    entries = []
    try:
        if not db_path.exists():
            return entries

        conn = sqlite3.connect(str(db_path))
        conn.execute("PRAGMA busy_timeout = 5000")
        conn.row_factory = sqlite3.Row

        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT content, type, importance_score, tags
            FROM memories
            WHERE importance_score >= 70
              AND status != 'archived'
            ORDER BY importance_score DESC
            LIMIT 10
            """,
        )

        for row in cursor.fetchall():
            content = row["content"]
            mem_type = row["type"] or "general"
            # Take first line or first 120 chars as summary
            first_line = content.split("\n")[0].strip()
            if len(first_line) > 120:
                first_line = first_line[:117] + "..."
            entries.append((mem_type, first_line))

        conn.close()
    except Exception:
        pass

    return entries


def _build_template(project_name: str, project_path: str, seed_entries: list) -> str:
    """Build the MEMORY.md template content."""
    date = datetime.now().strftime("%Y-%m-%d")

    lines = [
        f"# {project_name} - Auto Memory",
        "",
        "## Project Info",
        f"- **Path:** {project_path}",
        f"- **Created:** {date}",
        "",
        "## Key Patterns",
        "",
    ]

    # Add seeded pattern entries
    pattern_entries = [e for e in seed_entries if e[0] in ("pattern", "architecture", "config")]
    for _, summary in pattern_entries:
        lines.append(f"- {summary}")

    if pattern_entries:
        lines.append("")

    lines.extend([
        "## Gotchas",
        "",
    ])

    # Add seeded gotcha entries
    gotcha_entries = [e for e in seed_entries if e[0] in ("gotcha", "troubleshooting", "error")]
    for _, summary in gotcha_entries:
        lines.append(f"- {summary}")

    if gotcha_entries:
        lines.append("")

    lines.extend([
        "## Decisions",
        "",
    ])

    # Add seeded decision entries
    decision_entries = [e for e in seed_entries if e[0] in ("decision", "lesson")]
    for _, summary in decision_entries:
        lines.append(f"- {summary}")

    if decision_entries:
        lines.append("")

    # Any remaining entries go under a general section
    categorized_types = {"pattern", "architecture", "config", "gotcha", "troubleshooting", "error", "decision", "lesson"}
    other_entries = [e for e in seed_entries if e[0] not in categorized_types]
    if other_entries:
        lines.append("## Other Notes")
        lines.append("")
        for _, summary in other_entries:
            lines.append(f"- {summary}")
        lines.append("")

    return "\n".join(lines)


def ensure_memory_file(project_path: str) -> bool:
    """Create MEMORY.md if it doesn't exist. Return True if created.

    Seeds the template with high-importance Cortex memories if available.
    Non-blocking: returns False on any error.
    """
    try:
        memory_file = get_memory_file(project_path)

        if memory_file.exists():
            return False

        # Detect project name
        project_name = detect_project_name(project_path)

        # Try to seed from Cortex DB
        db_path = Path(project_path) / ".omni-cortex" / "cortex.db"
        seed_entries = seed_from_cortex(project_path, db_path)

        # Build template
        content = _build_template(project_name, project_path, seed_entries)

        # Create directory
        memory_file.parent.mkdir(parents=True, exist_ok=True)

        # Atomic write: write to temp file then rename
        fd, tmp_path = tempfile.mkstemp(
            dir=str(memory_file.parent),
            prefix=".MEMORY.md.",
            suffix=".tmp",
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(content)
            # On Windows, rename fails if target exists (but we checked above)
            Path(tmp_path).replace(memory_file)
        except Exception:
            # Clean up temp file on failure
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

        return True

    except Exception:
        return False


def parse_memory_sections(content: str) -> dict:
    """Parse existing MEMORY.md into sections for safe updates.

    Returns dict mapping section headers to list of content lines.
    The special key '__header__' holds lines before the first ## section.
    """
    sections = {"__header__": []}
    current_section = "__header__"

    for line in content.split("\n"):
        if line.startswith("## "):
            current_section = line[3:].strip()
            if current_section not in sections:
                sections[current_section] = []
        else:
            sections[current_section].append(line)

    return sections


def render_memory_file(sections: dict, project_name: str = None) -> str:
    """Render sections dict back into MEMORY.md format."""
    lines = []

    # Header lines first
    header = sections.get("__header__", [])
    if header:
        lines.extend(header)
    elif project_name:
        lines.append(f"# {project_name} - Auto Memory")
        lines.append("")

    # Render sections in order (preserve insertion order)
    for section_name, section_lines in sections.items():
        if section_name == "__header__":
            continue
        lines.append(f"## {section_name}")
        lines.extend(section_lines)

    # Ensure file ends with newline
    result = "\n".join(lines)
    if not result.endswith("\n"):
        result += "\n"

    return result


def _categorize_memory(mem_type: str, tags_str: str) -> str:
    """Map a memory type/tags to a MEMORY.md section name."""
    tags = []
    if tags_str:
        try:
            tags = json.loads(tags_str)
        except (json.JSONDecodeError, TypeError):
            tags = []

    # Type-based mapping
    type_map = {
        "decision": "Decisions",
        "lesson": "Decisions",
        "gotcha": "Gotchas",
        "troubleshooting": "Gotchas",
        "error": "Gotchas",
        "pattern": "Key Patterns",
        "architecture": "Key Patterns",
        "config": "Key Patterns",
    }

    if mem_type in type_map:
        return type_map[mem_type]

    # Tag-based fallback
    tag_set = set(t.lower() for t in tags)
    if tag_set & {"gotcha", "bug", "error", "troubleshooting"}:
        return "Gotchas"
    if tag_set & {"decision", "lesson"}:
        return "Decisions"
    if tag_set & {"pattern", "architecture", "config"}:
        return "Key Patterns"

    return "Other Notes"


def _is_duplicate(existing_lines: list, new_entry: str) -> bool:
    """Check if entry already exists (fuzzy: compare first 50 chars)."""
    # Strip leading "- " for comparison
    new_text = new_entry.lstrip("- ").strip()[:50].lower()
    if not new_text:
        return True

    for line in existing_lines:
        existing_text = line.lstrip("- ").strip()[:50].lower()
        if existing_text and new_text == existing_text:
            return True

    return False


def update_memory_with_learnings(
    project_path: str, db_path: Path, session_id: str
) -> int:
    """Append session learnings to MEMORY.md. Return count of entries added.

    Respects 200-line limit by prioritizing high-importance items.
    Only processes actionable memory types (decision, gotcha, pattern, etc).
    Skips session-specific types (context, handoff, progress).
    """
    try:
        memory_file = get_memory_file(project_path)

        # Only update if MEMORY.md already exists
        if not memory_file.exists():
            return 0

        if not db_path.exists():
            return 0

        conn = sqlite3.connect(str(db_path))
        conn.execute("PRAGMA busy_timeout = 5000")
        conn.row_factory = sqlite3.Row

        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT content, type, importance_score, tags
            FROM memories
            WHERE source_session_id = ?
              AND importance_score >= 60
              AND type NOT IN ('context', 'handoff', 'progress', 'retrospective')
            ORDER BY importance_score DESC
            """,
            (session_id,),
        )

        new_memories = cursor.fetchall()
        conn.close()

        if not new_memories:
            return 0

        # Read current MEMORY.md
        with open(memory_file, "r", encoding="utf-8") as f:
            content = f.read()

        current_line_count = len(content.split("\n"))

        # Parse into sections
        sections = parse_memory_sections(content)

        added = 0
        for mem in new_memories:
            # If approaching 200-line limit, only add high-importance
            if current_line_count + added >= 180 and mem["importance_score"] < 80:
                continue

            mem_content = mem["content"]
            mem_type = mem["type"] or "general"
            tags_str = mem["tags"]

            # Determine target section
            section_name = _categorize_memory(mem_type, tags_str)

            # Create section if it doesn't exist
            if section_name not in sections:
                sections[section_name] = [""]

            # Build entry: first line summary (max 150 chars)
            first_line = mem_content.split("\n")[0].strip()
            if len(first_line) > 150:
                first_line = first_line[:147] + "..."
            entry = f"- {first_line}"

            # Skip duplicates
            if _is_duplicate(sections[section_name], entry):
                continue

            sections[section_name].append(entry)
            added += 1

        if added == 0:
            return 0

        # Render and write back
        # Detect project name from header
        project_name = None
        header = sections.get("__header__", [])
        for line in header:
            if line.startswith("# "):
                project_name = line[2:].strip()
                break

        new_content = render_memory_file(sections, project_name)

        # Atomic write
        fd, tmp_path = tempfile.mkstemp(
            dir=str(memory_file.parent),
            prefix=".MEMORY.md.",
            suffix=".tmp",
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(new_content)
            Path(tmp_path).replace(memory_file)
        except Exception:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

        return added

    except Exception:
        return 0
