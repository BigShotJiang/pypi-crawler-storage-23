"""Conflict detection engine for memory storage.

Detects contradictions between new and existing memories using
heuristic signals (negation, temporal override, type mismatch).
Runs AFTER dedup check to avoid flagging duplicates as conflicts.
"""

import logging
import re
import sqlite3

from pydantic import BaseModel, Field

from ..models.memory import Memory, _row_to_memory
from .dedup import tokenize

logger = logging.getLogger(__name__)

# Negation patterns that suggest contradiction
NEGATION_PATTERNS = [
    r"\bnot\b", r"\bdon'?t\b", r"\bdoesn'?t\b", r"\bnever\b",
    r"\bno longer\b", r"\bstopped\b",
    r"\bwrong\b", r"\bincorrect\b", r"\bfalse\b", r"\binaccurate\b",
    r"\boutdated\b",
    r"\binstead\b", r"\brather than\b", r"\bbut actually\b",
    r"\bcontrary to\b",
    r"\bchanged from\b", r"\breplaced .+ with\b", r"\bswitched from\b",
    r"\bdeprecated\b", r"\bremoved\b", r"\bdiscontinued\b",
    r"\bno longer supported\b",
]

# Temporal patterns that suggest an update/override
TEMPORAL_PATTERNS = [
    r"\bnow\b", r"\bcurrently\b", r"\bas of\b", r"\bupdated\b",
    r"\bchanged\b",
    r"\bfixed\b", r"\bresolved\b", r"\bpatched\b", r"\bcorrected\b",
    r"\bnew version\b", r"\bv2\b", r"\blatest\b", r"\bmigrated to\b",
]

# Type pairs that are contradiction-prone
CONTRADICTION_TYPE_PAIRS = frozenset({
    ("error", "solution"),
    ("solution", "error"),
    ("config", "config"),
    ("decision", "decision"),
    ("tip", "warning"),
    ("warning", "tip"),
})

# Minimum topic token overlap for signals to fire
MIN_TOPIC_OVERLAP = 0.3


class ConflictMatch(BaseModel):
    """A single conflict detected between new and existing memory."""

    memory_id: str = Field(..., description="ID of the conflicting existing memory")
    score: float = Field(..., description="Combined conflict score 0-1")
    signals: dict[str, float] = Field(
        default_factory=dict,
        description="Individual signal scores",
    )
    summary: str = Field("", description="Brief description of the conflict")


class ConflictResult(BaseModel):
    """Result of conflict detection for a new memory."""

    has_conflicts: bool = Field(False, description="Whether conflicts were detected")
    conflicts: list[ConflictMatch] = Field(
        default_factory=list,
        description="List of detected conflicts",
    )


def detect_conflicts(
    conn: sqlite3.Connection,
    new_memory_id: str,
    new_content: str,
    new_type: str,
    threshold: float = 0.4,
    max_candidates: int = 10,
    similarity_threshold: float = 0.5,
    embedding_enabled: bool = False,
) -> ConflictResult:
    """Detect contradictions between a new memory and existing memories.

    Finds semantically similar memories and runs heuristic signals
    to determine if they contradict the new memory.

    Args:
        conn: Database connection
        new_memory_id: ID of the newly created memory
        new_content: Content of the new memory
        new_type: Type of the new memory
        threshold: Combined score threshold to flag as conflict
        max_candidates: Max memories to check
        similarity_threshold: Min similarity to consider as candidate
        embedding_enabled: Whether embeddings are available

    Returns:
        ConflictResult with detected conflicts
    """
    if embedding_enabled:
        candidates = _find_candidates_semantic(
            conn, new_memory_id, new_content, max_candidates, similarity_threshold
        )
    else:
        candidates = _find_candidates_keyword(
            conn, new_memory_id, new_content, max_candidates
        )

    if not candidates:
        return ConflictResult()

    conflicts = []
    new_tokens = tokenize(new_content)

    for memory in candidates:
        existing_tokens = tokenize(memory.content)
        topic_overlap = _calculate_topic_overlap(new_tokens, existing_tokens)

        # Skip candidates with very low topic overlap
        if topic_overlap < MIN_TOPIC_OVERLAP:
            continue

        # Run signals
        negation_score = _negation_signal(new_content, memory.content, topic_overlap)
        temporal_score = _temporal_signal(new_content, topic_overlap)
        type_score = _type_mismatch_signal(new_type, memory.type, topic_overlap)
        polarity_score = _polarity_flip_signal(new_content, memory.content, topic_overlap)

        # Weights: polarity_flip gets highest weight as most precise signal.
        # negation=0.20, temporal=0.20, type=0.15, polarity_flip=0.45
        combined = (
            negation_score * 0.20
            + temporal_score * 0.20
            + type_score * 0.15
            + polarity_score * 0.45
        )

        if combined >= threshold:
            summary = _build_summary(
                new_content, memory.content, negation_score, temporal_score,
                type_score, polarity_score,
            )
            conflicts.append(
                ConflictMatch(
                    memory_id=memory.id,
                    score=round(combined, 3),
                    signals={
                        "negation": round(negation_score, 3),
                        "temporal": round(temporal_score, 3),
                        "type_mismatch": round(type_score, 3),
                        "polarity_flip": round(polarity_score, 3),
                    },
                    summary=summary,
                )
            )

    # Sort by score descending
    conflicts.sort(key=lambda c: c.score, reverse=True)

    return ConflictResult(
        has_conflicts=len(conflicts) > 0,
        conflicts=conflicts,
    )


def _find_candidates_semantic(
    conn: sqlite3.Connection,
    new_memory_id: str,
    new_content: str,
    max_candidates: int,
    similarity_threshold: float,
) -> list[Memory]:
    """Find conflict candidates using embedding similarity."""
    from ..embeddings.local import is_model_available

    if not is_model_available():
        return _find_candidates_keyword(conn, new_memory_id, new_content, max_candidates)

    from .semantic import find_similar_memories

    results = find_similar_memories(
        conn,
        memory_id=new_memory_id,
        limit=max_candidates,
        similarity_threshold=similarity_threshold,
    )
    return [memory for memory, _score in results]


def _find_candidates_keyword(
    conn: sqlite3.Connection,
    new_memory_id: str,
    new_content: str,
    max_candidates: int,
) -> list[Memory]:
    """Find conflict candidates using keyword search."""
    from .keyword import keyword_search

    search_tokens = sorted(tokenize(new_content))[:15]
    if not search_tokens:
        return []

    search_query = " ".join(search_tokens)

    try:
        results = keyword_search(conn, search_query, limit=max_candidates + 1)
    except Exception as e:
        logger.warning(f"Conflict keyword search failed: {e}")
        return []

    # Exclude the new memory itself from candidates
    return [memory for memory, _score in results if memory.id != new_memory_id][:max_candidates]


def _calculate_topic_overlap(
    new_tokens: set[str], existing_tokens: set[str]
) -> float:
    """Calculate topic token overlap between two memories.

    Returns overlap ratio as |intersection| / min(|a|, |b|).
    Uses min rather than union to handle different-length texts fairly.
    """
    if not new_tokens or not existing_tokens:
        return 0.0

    intersection = new_tokens & existing_tokens
    denominator = min(len(new_tokens), len(existing_tokens))
    return len(intersection) / denominator


def _negation_signal(
    new_content: str, existing_content: str, topic_overlap: float
) -> float:
    """Score negation patterns in new content relative to existing.

    Checks for negation keywords that suggest the new memory
    contradicts the existing one.

    Returns:
        Score 0.0-1.0
    """
    new_lower = new_content.lower()
    max_expected = 2  # Cap at 2 matches so a single "NOT" scores 0.5

    match_count = 0
    for pattern in NEGATION_PATTERNS:
        if re.search(pattern, new_lower):
            match_count += 1

    if match_count == 0:
        return 0.0

    raw_score = min(match_count / max_expected, 1.0)

    # Scale by topic overlap to avoid false positives on unrelated content
    return raw_score * min(topic_overlap * 2, 1.0)


def _temporal_signal(new_content: str, topic_overlap: float) -> float:
    """Score temporal override patterns in new content.

    Checks for keywords suggesting the new memory updates/supersedes
    previous information.

    Returns:
        Score 0.0-1.0
    """
    new_lower = new_content.lower()

    match_count = 0
    for pattern in TEMPORAL_PATTERNS:
        if re.search(pattern, new_lower):
            match_count += 1

    if match_count == 0:
        return 0.0

    max_expected = 3
    raw_score = min(match_count / max_expected, 1.0)

    # Temporal signal requires topic overlap to be meaningful
    return raw_score * topic_overlap


def _type_mismatch_signal(
    new_type: str, existing_type: str, topic_overlap: float
) -> float:
    """Score type mismatch between memories.

    Certain type pairs are contradiction-prone (e.g., error vs solution,
    config vs config with same topic).

    Returns:
        Score 0.0 or 0.8
    """
    type_pair = (new_type, existing_type)

    if type_pair in CONTRADICTION_TYPE_PAIRS and topic_overlap > 0.5:
        return 0.8

    return 0.0


def _polarity_flip_signal(
    new_content: str, existing_content: str, topic_overlap: float
) -> float:
    """Detect when one memory negates what another affirms.

    Catches patterns like "uses SQLite" vs "does NOT use SQLite" where
    both memories discuss the same topic but only one contains negation.
    This is the most precise contradiction signal since it requires
    high topic overlap AND asymmetric negation.

    Returns:
        Score 0.0-1.0
    """
    if topic_overlap < 0.4:
        return 0.0

    new_lower = new_content.lower()
    existing_lower = existing_content.lower()

    new_negations = sum(1 for p in NEGATION_PATTERNS if re.search(p, new_lower))
    existing_negations = sum(1 for p in NEGATION_PATTERNS if re.search(p, existing_lower))

    # One-sided negation: one memory negates, the other affirms
    if new_negations > 0 and existing_negations == 0:
        asymmetry = 1.0
    elif existing_negations > 0 and new_negations == 0:
        asymmetry = 1.0
    elif abs(new_negations - existing_negations) >= 2:
        asymmetry = 0.5  # Large gap in negation density
    else:
        return 0.0

    # Boost: polarity_flip already passed its own overlap check (0.4),
    # so we can scale more aggressively. This ensures a single "NOT"
    # with moderate overlap still produces a strong signal.
    return asymmetry * min(topic_overlap * 1.5, 1.0)


def _build_summary(
    new_content: str,
    existing_content: str,
    negation_score: float,
    temporal_score: float,
    type_score: float,
    polarity_score: float = 0.0,
) -> str:
    """Build a brief human-readable summary of the conflict."""
    reasons = []

    if polarity_score > 0.3:
        reasons.append("polarity flip")
    if negation_score > 0.3:
        reasons.append("negation detected")
    if temporal_score > 0.3:
        reasons.append("temporal override")
    if type_score > 0:
        reasons.append("type mismatch")

    # Truncate content for summary
    new_preview = new_content[:80].replace("\n", " ")
    if len(new_content) > 80:
        new_preview += "..."
    existing_preview = existing_content[:80].replace("\n", " ")
    if len(existing_content) > 80:
        existing_preview += "..."

    reason_str = ", ".join(reasons) if reasons else "combined signals"
    return f'"{existing_preview}" vs "{new_preview}" ({reason_str})'
