"""Smart deduplication engine for memory storage.

Checks if new content duplicates an existing memory before storage.
Uses semantic similarity (embeddings) or keyword-based token overlap
as fallback when embeddings are disabled.
"""

import logging
import re
import sqlite3

from pydantic import BaseModel, Field

from ..models.memory import Memory, _row_to_memory
from ..embeddings.local import generate_embedding, blob_to_vector
from ..search.semantic import cosine_similarity

logger = logging.getLogger(__name__)

# Common English stop words for tokenization
STOP_WORDS = frozenset({
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "shall", "can", "need", "must",
    "and", "or", "but", "nor", "not", "so", "yet", "both", "either",
    "neither", "each", "every", "all", "any", "few", "more", "most",
    "other", "some", "such", "no",
    "of", "in", "to", "for", "with", "on", "at", "from", "by", "about",
    "as", "into", "through", "during", "before", "after", "above", "below",
    "between", "out", "off", "over", "under", "again", "further", "then",
    "once", "here", "there", "when", "where", "why", "how", "what", "which",
    "who", "whom", "this", "that", "these", "those", "am",
    "i", "me", "my", "myself", "we", "our", "ours", "ourselves",
    "you", "your", "yours", "yourself", "yourselves",
    "he", "him", "his", "himself", "she", "her", "hers", "herself",
    "it", "its", "itself", "they", "them", "their", "theirs", "themselves",
    "up", "down", "just", "now", "also", "very", "often", "however",
    "too", "usually", "really", "already", "since", "back", "still",
    "well", "even", "if", "than",
})

_TOKEN_PATTERN = re.compile(r"[a-z0-9]+")


class DedupResult(BaseModel):
    """Result of a deduplication check."""

    action: str = Field(..., description="Action: create, skip, or merge")
    matched_memory_id: str | None = Field(None, description="ID of matched memory")
    similarity: float = Field(0.0, description="Similarity score 0-1")
    token_overlap: float = Field(0.0, description="Token overlap ratio 0-1")
    delta_content: str | None = Field(None, description="New content not in existing memory")


def tokenize(text: str) -> set[str]:
    """Tokenize text into meaningful tokens.

    Lowercases, splits on non-alphanumeric characters, removes stop words.
    """
    tokens = set(_TOKEN_PATTERN.findall(text.lower()))
    return tokens - STOP_WORDS


def calculate_token_overlap(new_content: str, existing_content: str) -> tuple[float, str]:
    """Calculate token overlap between new and existing content.

    Returns:
        Tuple of (overlap_ratio, delta_text)
        - overlap_ratio: |intersection| / |new_tokens| (0-1)
        - delta_text: new content not covered by existing
    """
    new_tokens = tokenize(new_content)
    existing_tokens = tokenize(existing_content)

    if not new_tokens:
        return 1.0, ""

    intersection = new_tokens & existing_tokens
    overlap = len(intersection) / len(new_tokens)

    delta_tokens = new_tokens - existing_tokens
    delta_text = _extract_delta_text(new_content, delta_tokens)

    return overlap, delta_text


def _extract_delta_text(new_content: str, delta_tokens: set[str]) -> str:
    """Extract text from new_content containing delta tokens.

    Preserves meaningful phrases rather than isolated words.
    """
    if not delta_tokens:
        return ""

    lines = re.split(r"[\n.]+", new_content)
    delta_lines = []

    for line in lines:
        line = line.strip()
        if not line:
            continue
        line_tokens = tokenize(line)
        if line_tokens & delta_tokens:
            delta_lines.append(line)

    if delta_lines:
        return ". ".join(delta_lines)

    return " ".join(sorted(delta_tokens))


def check_duplicate(
    conn: sqlite3.Connection,
    content: str,
    threshold: float = 0.9,
    keyword_threshold: float = 0.85,
    max_candidates: int = 5,
    embedding_enabled: bool = True,
) -> DedupResult:
    """Check if content duplicates an existing memory.

    Uses semantic similarity when embeddings are enabled, otherwise
    falls back to keyword search with token overlap comparison.

    Args:
        conn: Database connection
        content: New memory content to check
        threshold: Semantic similarity threshold (0-1)
        keyword_threshold: Token overlap threshold for keyword fallback
        max_candidates: Max existing memories to compare
        embedding_enabled: Whether embeddings are available

    Returns:
        DedupResult with action (create/skip/merge) and match details
    """
    if embedding_enabled:
        return _check_semantic(conn, content, threshold, max_candidates)
    else:
        return _check_keyword(conn, content, keyword_threshold, max_candidates)


def _check_semantic(
    conn: sqlite3.Connection,
    content: str,
    threshold: float,
    max_candidates: int,
) -> DedupResult:
    """Check for duplicates using embedding cosine similarity."""
    from ..embeddings.local import is_model_available

    if not is_model_available():
        logger.warning("Embedding model not available for dedup check")
        return DedupResult(action="create")

    try:
        query_embedding = generate_embedding(content)
    except Exception as e:
        logger.warning(f"Dedup embedding generation failed: {e}")
        return DedupResult(action="create")

    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT m.*, e.vector
        FROM memories m
        JOIN embeddings e ON m.id = e.memory_id
        WHERE m.has_embedding = 1 AND m.status != 'archived'
        """
    )

    candidates = []
    for row in cursor.fetchall():
        memory_embedding = blob_to_vector(row["vector"])
        similarity = cosine_similarity(query_embedding, memory_embedding)
        if similarity >= threshold:
            memory = _row_to_memory(row)
            candidates.append((memory, similarity))

    candidates.sort(key=lambda x: x[1], reverse=True)
    candidates = candidates[:max_candidates]

    if not candidates:
        return DedupResult(action="create")

    best_memory, best_similarity = candidates[0]
    overlap, delta_text = calculate_token_overlap(content, best_memory.content)

    return _decide_action(best_memory.id, best_similarity, overlap, delta_text)


def _check_keyword(
    conn: sqlite3.Connection,
    content: str,
    keyword_threshold: float,
    max_candidates: int,
) -> DedupResult:
    """Check for duplicates using keyword search and token overlap."""
    from ..search.keyword import keyword_search

    # Use significant tokens as search query to avoid huge FTS queries
    search_tokens = sorted(tokenize(content))[:15]
    if not search_tokens:
        return DedupResult(action="create")

    search_query = " ".join(search_tokens)

    try:
        results = keyword_search(conn, search_query, limit=max_candidates)
    except Exception as e:
        logger.warning(f"Dedup keyword search failed: {e}")
        return DedupResult(action="create")

    if not results:
        return DedupResult(action="create")

    for memory, _bm25_score in results:
        overlap, delta_text = calculate_token_overlap(content, memory.content)
        if overlap >= keyword_threshold:
            return _decide_action(memory.id, overlap, overlap, delta_text)

    return DedupResult(action="create")


def _decide_action(
    memory_id: str,
    similarity: float,
    overlap: float,
    delta_text: str,
) -> DedupResult:
    """Decide SKIP vs MERGE based on token overlap.

    - overlap > 95%: SKIP (new content adds nothing)
    - overlap <= 95%: MERGE (new content adds some info)
    """
    if overlap > 0.95:
        return DedupResult(
            action="skip",
            matched_memory_id=memory_id,
            similarity=similarity,
            token_overlap=overlap,
        )
    else:
        return DedupResult(
            action="merge",
            matched_memory_id=memory_id,
            similarity=similarity,
            token_overlap=overlap,
            delta_content=delta_text,
        )
