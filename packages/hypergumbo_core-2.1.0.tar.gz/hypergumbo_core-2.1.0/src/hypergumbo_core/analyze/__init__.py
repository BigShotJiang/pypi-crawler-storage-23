"""Analyzer infrastructure for hypergumbo core."""
