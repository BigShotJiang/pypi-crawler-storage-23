"""dopeTask test helpers."""
