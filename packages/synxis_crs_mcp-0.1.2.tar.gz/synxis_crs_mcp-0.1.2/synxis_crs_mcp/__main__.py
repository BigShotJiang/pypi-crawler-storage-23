"""Run SynXis CRS MCP server as a module."""

from synxis_crs_mcp.cli import main

if __name__ == "__main__":
    main()
