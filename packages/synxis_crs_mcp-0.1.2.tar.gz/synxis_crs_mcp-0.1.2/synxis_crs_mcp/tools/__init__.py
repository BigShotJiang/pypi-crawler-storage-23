"""MCP tools for SynXis CRS management."""

from synxis_crs_mcp.tools.crs_tools import register_crs_tools

__all__ = ["register_crs_tools"]
