"""Test suite for synxis-crs-mcp."""
