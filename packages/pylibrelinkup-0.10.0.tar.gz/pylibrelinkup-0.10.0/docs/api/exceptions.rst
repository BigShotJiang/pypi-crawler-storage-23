Exceptions
==========

.. toctree::
   :maxdepth: 2

.. automodule:: pylibrelinkup.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
