from __future__ import annotations

from .qcodedocument import QCodeDocument

__all__ = ["QCodeDocument"]
