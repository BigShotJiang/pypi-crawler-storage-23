"""
Async utilities for GRKMemory.

Provides a helper to run blocking sync functions in a thread
without blocking the asyncio event loop.
"""

import asyncio
import sys
from typing import Any, Callable, TypeVar

T = TypeVar("T")


async def run_sync(func: Callable[..., T], *args: Any, **kwargs: Any) -> T:
    """Run a blocking function in a thread so the event loop stays free."""
    if sys.version_info >= (3, 9):
        return await asyncio.to_thread(func, *args, **kwargs)
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, lambda: func(*args, **kwargs))
