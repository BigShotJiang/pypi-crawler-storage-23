"""
Encryption utilities for GRKMemory.

Provides optional at-rest encryption for memory and token files
using Fernet symmetric encryption (AES-128-CBC + HMAC-SHA256).

Requires the ``cryptography`` package::

    pip install grkmemory[encryption]
"""

import base64
import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)

try:
    from cryptography.fernet import Fernet, InvalidToken
    ENCRYPTION_AVAILABLE = True
except ImportError:
    ENCRYPTION_AVAILABLE = False
    Fernet = None  # type: ignore[misc,assignment]
    InvalidToken = Exception  # type: ignore[misc,assignment]

MAGIC_HEADER = b"GRK_ENC_V1\n"


class FileEncryptor:
    """
    Symmetric file encryptor backed by Fernet.

    The encryption key can be supplied directly, read from the
    ``GRKMEMORY_ENCRYPTION_KEY`` environment variable, or generated
    automatically (useful for first-time setup).

    Args:
        key: A URL-safe base64-encoded 32-byte key.  If *None*, the key
             is read from the environment variable
             ``GRKMEMORY_ENCRYPTION_KEY``.

    Raises:
        ImportError: If the ``cryptography`` package is not installed.
        ValueError: If no key is available and ``auto_generate`` is False.
    """

    def __init__(self, key: Optional[str] = None) -> None:
        if not ENCRYPTION_AVAILABLE:
            raise ImportError(
                "Encryption requires the 'cryptography' package. "
                "Install with: pip install grkmemory[encryption]"
            )

        resolved_key = key or os.getenv("GRKMEMORY_ENCRYPTION_KEY")
        if not resolved_key:
            raise ValueError(
                "Encryption key required. Pass 'key' argument or set the "
                "GRKMEMORY_ENCRYPTION_KEY environment variable. "
                "Generate one with: python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
            )

        self._fernet = Fernet(resolved_key.encode() if isinstance(resolved_key, str) else resolved_key)

    def encrypt(self, data: bytes) -> bytes:
        """Encrypt raw bytes and return ciphertext."""
        return self._fernet.encrypt(data)

    def decrypt(self, token: bytes) -> bytes:
        """Decrypt a Fernet token and return plaintext bytes."""
        return self._fernet.decrypt(token)

    def encrypt_text(self, text: str) -> bytes:
        """Encrypt a UTF-8 string, returning bytes prefixed with a magic header."""
        ciphertext = self.encrypt(text.encode("utf-8"))
        return MAGIC_HEADER + ciphertext

    def decrypt_text(self, data: bytes) -> str:
        """Decrypt bytes (with magic header) back to a UTF-8 string."""
        if data.startswith(MAGIC_HEADER):
            data = data[len(MAGIC_HEADER):]
        return self.decrypt(data).decode("utf-8")

    @staticmethod
    def generate_key() -> str:
        """Generate a new Fernet key suitable for ``GRKMEMORY_ENCRYPTION_KEY``."""
        if not ENCRYPTION_AVAILABLE:
            raise ImportError("cryptography package is required")
        return Fernet.generate_key().decode()

    @staticmethod
    def is_encrypted(data: bytes) -> bool:
        """Return True if *data* starts with the GRKMemory encryption header."""
        return data.startswith(MAGIC_HEADER)
