"""
Memory Repository for GRKMemory.

This module provides persistent storage and retrieval of conversation memories.
Supports multiple storage formats: JSON (fast parsing) and TOON (token-efficient).
"""

import json
import logging
import threading
import time
import uuid
import datetime
from typing import Dict, List, Optional, Literal, Set, Tuple
from collections import defaultdict

logger = logging.getLogger(__name__)

from ..graph.semantic_graph import SemanticGraph
from ..utils.text import normalize_term, extract_concepts, validate_file_path
from ..utils.embeddings import EmbeddingGenerator, cosine_similarity
from ..utils.encryption import FileEncryptor, ENCRYPTION_AVAILABLE

# Try to import TOON format
try:
    from toon_format import encode as toon_encode, decode as toon_decode
    TOON_AVAILABLE = True
except ImportError:
    TOON_AVAILABLE = False
    toon_encode = None
    toon_decode = None

# Try to import FAISS for O(log n) vector search
try:
    import numpy as np
    import faiss
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False
    np = None  # type: ignore[assignment]
    faiss = None  # type: ignore[assignment]

# Type aliases
StorageFormat = Literal["json", "toon"]
OutputFormat = Literal["json", "toon", "text"]


def _match_tenant(
    memoria: Dict,
    user_id: Optional[str],
    session_id: Optional[str]
) -> bool:
    """Return True if memory matches the given user_id and/or session_id."""
    if user_id is not None and memoria.get("user_id") != user_id:
        return False
    if session_id is not None:
        sid = (memoria.get("source") or {}).get("session_id")
        if sid != session_id:
            return False
    return True


class MemoryRepository:
    """
    Repository for storing and retrieving conversation memories.
    
    Supports multiple storage formats:
    - JSON: Fast parsing (27x faster), universal compatibility
    - TOON: Token-efficient (25% smaller), optimized for LLM context
    
    Supports multiple search methods:
    - Graph-based semantic search (recommended)
    - Embedding similarity search
    - Tag-based search
    - Entity-based search
    
    Example:
        # Traditional JSON storage
        repo = MemoryRepository(
            memory_file="memories.json",
            storage_format="json",
            output_format="json"
        )
        
        # TOON storage (token-efficient)
        repo = MemoryRepository(
            memory_file="memories.toon",
            storage_format="toon",
            output_format="toon"
        )
        
        # Hybrid: JSON storage, TOON output (recommended for LLM apps)
        repo = MemoryRepository(
            memory_file="memories.json",
            storage_format="json",      # Fast parsing
            output_format="toon"        # 25% fewer tokens for LLM
        )
        
        # Save a conversation
        repo.save({
            "summary": "Discussion about AI",
            "tags": ["ai", "technology"],
            "entities": ["GPT-4", "OpenAI"],
            "key_points": ["AI is transforming industries"]
        })
        
        # Search memories (returns in configured output_format)
        results = repo.search("Tell me about AI", method="graph")
        
        # Get formatted context for LLM
        context = repo.format_for_llm(results)
    """
    
    def __init__(
        self,
        memory_file: str = "graph_retrieve_knowledge_memory.json",
        embedding_model: str = "text-embedding-3-small",
        enable_embeddings: bool = True,
        debug: bool = False,
        memory_limit: int = 5,
        threshold: float = 0.3,
        storage_format: StorageFormat = "json",
        output_format: OutputFormat = "json",
        lazy_load: bool = False,
        encryption_key: Optional[str] = None,
    ):
        """
        Initialize the memory repository.
        
        Args:
            memory_file: Path to file for persistent storage.
            embedding_model: Model for generating embeddings.
            enable_embeddings: Whether to generate embeddings.
            debug: Enable debug logging.
            memory_limit: Maximum memories to return from search.
            threshold: Minimum similarity threshold.
            storage_format: Format for storage ('json' or 'toon').
            output_format: Format for retrieve output ('json', 'toon', or 'text').
            lazy_load: When True, loads only metadata (id, summary, tags,
                entities, key_points, embedding) at init. Heavy fields like
                'messages' are stripped from RAM and loaded on-demand via
                get_memory_detail(). Reduces peak memory usage for large datasets.
            encryption_key: Optional Fernet key for at-rest encryption.
                Requires the ``cryptography`` package.
        """
        self.memory_file = validate_file_path(memory_file)
        self._lock = threading.RLock()
        self.enable_embeddings = enable_embeddings
        self.debug = debug
        self.memory_limit = memory_limit
        self.threshold = threshold
        self.storage_format = storage_format
        self.output_format = output_format
        self.lazy_load = lazy_load
        
        # Validate TOON availability
        if storage_format == "toon" and not TOON_AVAILABLE:
            raise ImportError(
                "TOON format requested but toon_format is not installed. "
                "Install with: pip install toon_format"
            )
        if output_format == "toon" and not TOON_AVAILABLE:
            raise ImportError(
                "TOON output format requested but toon_format is not installed. "
                "Install with: pip install toon_format"
            )
        
        # Auto-detect format from file extension
        if memory_file.endswith(".toon"):
            self.storage_format = "toon"
        elif memory_file.endswith(".json"):
            self.storage_format = "json"
        
        self.memories: List[Dict] = []
        self.semantic_graph = SemanticGraph()
        self._faiss_index = None
        self._faiss_id_map: List[str] = []
        self._query_cache: Dict[str, Tuple[float, Dict]] = {}
        self._query_cache_ttl: float = 60.0
        self._encryptor: Optional[FileEncryptor] = None
        if encryption_key:
            self._encryptor = FileEncryptor(key=encryption_key)
        
        if enable_embeddings:
            self.embedding_generator = EmbeddingGenerator(model=embedding_model)
        else:
            self.embedding_generator = None
        
        self._load_memories()
        self._rebuild_graph()
        self._build_faiss_index()
    
    # Fields kept in RAM during lazy_load mode
    _LAZY_FIELDS = {"id", "summary", "tags", "entities", "key_points", "embedding",
                    "created_at", "user_id", "source", "sentiment", "confidence"}

    def _load_memories(self):
        """Load existing memories from file (supports JSON, TOON, and encrypted formats)."""
        try:
            if self._encryptor is not None:
                with open(self.memory_file, "rb") as fb:
                    raw_bytes = fb.read()
                if not raw_bytes:
                    self.memories = []
                    return
                if FileEncryptor.is_encrypted(raw_bytes):
                    content = self._encryptor.decrypt_text(raw_bytes)
                else:
                    content = raw_bytes.decode("utf-8")
            else:
                with open(self.memory_file, "r", encoding="utf-8") as f:
                    content = f.read()
            
            if not content.strip():
                self.memories = []
                return
            
            if self.storage_format == "toon":
                if not TOON_AVAILABLE:
                    raise ImportError("TOON format requires toon_format package")
                raw = toon_decode(content)
                if not isinstance(raw, list):
                    raw = [raw]
            else:  # json
                raw = json.loads(content)

            if self.lazy_load:
                self.memories = [
                    {k: v for k, v in m.items() if k in self._LAZY_FIELDS}
                    for m in raw
                ]
            else:
                self.memories = raw
            
            if self.debug:
                mode = "lazy" if self.lazy_load else "full"
                logger.debug(
                    "Loaded %d memories (%s, %s)",
                    len(self.memories), self.storage_format.upper(), mode,
                )
                
        except FileNotFoundError:
            self.memories = []
            if self.debug:
                logger.debug("File %s not found. Starting fresh.", self.memory_file)
        except (json.JSONDecodeError, IOError, KeyError, TypeError) as e:
            self.memories = []
            if self.debug:
                logger.warning("Error loading file: %s. Starting fresh.", e)
    
    def _rebuild_graph(self):
        """Rebuild the semantic graph from memories."""
        if self.debug:
            logger.debug("Rebuilding semantic graph...")
        
        self.semantic_graph.clear()
        
        for memoria in self.memories:
            self.semantic_graph.add_conversation(memoria)
        
        self.semantic_graph.calculate_densities()
        self.semantic_graph.calculate_centralities()
        
        if self.debug:
            stats = self.semantic_graph.get_stats()
            logger.debug("Semantic graph: %d nodes, %d edges", stats['total_nodes'], stats['total_edges'])

    def _build_faiss_index(self):
        """Build a FAISS index from all memories that have embeddings."""
        if not FAISS_AVAILABLE or not self.enable_embeddings:
            return

        vectors = []
        id_map = []
        for m in self.memories:
            emb = m.get("embedding")
            if emb:
                vectors.append(emb)
                id_map.append(m["id"])

        if not vectors:
            self._faiss_index = None
            self._faiss_id_map = []
            return

        dim = len(vectors[0])
        matrix = np.array(vectors, dtype=np.float32)
        faiss.normalize_L2(matrix)

        index = faiss.IndexFlatIP(dim)
        index.add(matrix)

        self._faiss_index = index
        self._faiss_id_map = id_map

        if self.debug:
            logger.debug("FAISS index built: %d vectors, dim=%d", len(id_map), dim)

    def _update_faiss_index(self, embedding: List[float], memory_id: str):
        """Add a single vector to the existing FAISS index."""
        if not FAISS_AVAILABLE or not embedding or self._faiss_index is None:
            return

        vec = np.array([embedding], dtype=np.float32)
        faiss.normalize_L2(vec)
        self._faiss_index.add(vec)
        self._faiss_id_map.append(memory_id)

    def _invalidate_query_cache(self) -> None:
        """Clear the query profile cache (called when memories change)."""
        self._query_cache.clear()

    def save(self, data: Dict) -> bool:
        """
        Save a conversation memory.
        
        Args:
            data: Dictionary with conversation data. Should include:
                - summary: Text summary
                - tags: List of tags
                - entities: List of entities
                - key_points: List of key points
                - Optional: sentiment, confidence, notes
        
        Returns:
            True if saved successfully.
        """
        with self._lock:
            try:
                if "id" not in data:
                    data["id"] = str(uuid.uuid4())
                if "created_at" not in data:
                    data["created_at"] = datetime.datetime.now().isoformat()
                
                if self.enable_embeddings and self.embedding_generator:
                    if "embedding" not in data or not data["embedding"]:
                        summary = data.get("summary", "")
                        if summary:
                            if self.debug:
                                logger.debug("Generating summary embedding...")
                            data["embedding"] = self.embedding_generator.generate(summary)
                        else:
                            data["embedding"] = []
                
                self.memories.append(data)
                self._save_to_file()
                self._invalidate_query_cache()
                node = self.semantic_graph.add_conversation(data)
                affected = {node.session_id} | set(node.neighbors.keys())
                self.semantic_graph.calculate_densities_for(affected)
                self.semantic_graph.calculate_centralities_for(affected)
                self._update_faiss_index(data.get("embedding", []), data["id"])
                
                if self.debug:
                    logger.debug("Saved: %s", data.get('summary', 'No summary'))
                    logger.debug("File: %s (%s, %d sessions)", self.memory_file, self.storage_format.upper(), len(self.memories))
                
                return True
                
            except (IOError, json.JSONDecodeError, KeyError, TypeError) as e:
                logger.error("Error saving memory: %s", e)
                return False
    
    def save_batch(self, data_list: List[Dict]) -> int:
        """
        Save multiple conversation memories in a single batch.

        Uses batch embedding generation for efficiency, making one API call
        instead of N individual calls.

        Args:
            data_list: List of memory dictionaries. Each should include
                summary, tags, entities, key_points.

        Returns:
            Number of memories saved successfully.
        """
        if not data_list:
            return 0

        with self._lock:
            try:
                texts_to_embed: List[str] = []
                embed_indices: List[int] = []

                for i, data in enumerate(data_list):
                    if "id" not in data:
                        data["id"] = str(uuid.uuid4())
                    if "created_at" not in data:
                        data["created_at"] = datetime.datetime.now().isoformat()
                    summary = data.get("summary", "")
                    if (
                        self.enable_embeddings
                        and summary
                        and not data.get("embedding")
                    ):
                        texts_to_embed.append(summary)
                        embed_indices.append(i)
                    elif "embedding" not in data:
                        data["embedding"] = []

                if texts_to_embed and self.embedding_generator:
                    if self.debug:
                        logger.debug(
                            "Generating %d embeddings in batch...",
                            len(texts_to_embed),
                        )
                    embeddings = self.embedding_generator.generate_batch(texts_to_embed)
                    for idx, emb in zip(embed_indices, embeddings):
                        data_list[idx]["embedding"] = emb

                self.memories.extend(data_list)
                self._save_to_file()
                self._invalidate_query_cache()

                affected: Set[str] = set()
                for data in data_list:
                    node = self.semantic_graph.add_conversation(data)
                    affected.add(node.session_id)
                    affected.update(node.neighbors.keys())
                self.semantic_graph.calculate_densities_for(affected)
                self.semantic_graph.calculate_centralities_for(affected)

                for data in data_list:
                    self._update_faiss_index(data.get("embedding", []), data["id"])

                if self.debug:
                    logger.debug("Batch saved %d memories", len(data_list))

                return len(data_list)
            except (IOError, json.JSONDecodeError, KeyError, TypeError) as e:
                logger.error("Error in batch save: %s", e)
                return 0

    def _save_to_file(self):
        """Save memories to file in configured format (with optional encryption)."""
        if self.storage_format == "toon":
            if not TOON_AVAILABLE:
                raise ImportError("TOON format requires toon_format package")
            text_content = toon_encode(self.memories)
        else:
            text_content = json.dumps(self.memories, indent=2, ensure_ascii=False)

        if self._encryptor is not None:
            with open(self.memory_file, "wb") as fb:
                fb.write(self._encryptor.encrypt_text(text_content))
        else:
            with open(self.memory_file, "w", encoding="utf-8") as f:
                f.write(text_content)
    
    def search(
        self,
        query: str,
        method: str = "graph",
        limit: Optional[int] = None,
        threshold: Optional[float] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> List[Dict]:
        """
        Search for relevant memories.
        
        Args:
            query: Search query string.
            method: Search method ('graph', 'embedding', 'tags', 'entities').
            limit: Maximum results to return.
            threshold: Minimum similarity threshold.
            user_id: Optional user id for multi-tenant isolation.
            session_id: Optional session id for multi-tenant isolation.
        
        Returns:
            List of dictionaries with 'memoria' and 'similaridade' keys.
        """
        with self._lock:
            if not self.memories:
                return []
            
            limit = limit or self.memory_limit
            threshold = threshold or self.threshold
            
            allowed_ids: Optional[Set[str]] = None
            if user_id is not None or session_id is not None:
                allowed_ids = {
                    m["id"] for m in self.memories
                    if _match_tenant(m, user_id, session_id)
                }
            
            if method == "graph":
                return self._graph_search(query, threshold, limit, allowed_ids=allowed_ids)
            elif method == "embedding":
                return self._embedding_search(query, threshold, limit, allowed_ids=allowed_ids)
            elif method == "tags":
                return self._tag_search(query, threshold, limit, allowed_ids=allowed_ids)
            elif method == "entities":
                return self._entity_search(query, threshold, limit, allowed_ids=allowed_ids)
            else:
                return self._graph_search(query, threshold, limit, allowed_ids=allowed_ids)
    
    def get_memory_detail(self, memory_id: str) -> Optional[Dict]:
        """
        Load the full memory record (including heavy fields like messages)
        directly from the storage file.

        Useful in lazy_load mode where only metadata is kept in RAM.

        Args:
            memory_id: The unique id of the memory to retrieve.

        Returns:
            The full memory dict, or None if not found.
        """
        try:
            with open(self.memory_file, "r", encoding="utf-8") as f:
                content = f.read()
            if not content.strip():
                return None

            if self.storage_format == "toon":
                if not TOON_AVAILABLE:
                    return None
                records = toon_decode(content)
                if not isinstance(records, list):
                    records = [records]
            else:
                records = json.loads(content)

            for record in records:
                if record.get("id") == memory_id:
                    return record
        except (IOError, json.JSONDecodeError, KeyError, TypeError) as e:
            logger.error("Error loading memory detail: %s", e)
        return None

    def search_paginated(
        self,
        query: str,
        page: int = 1,
        page_size: int = 10,
        method: str = "graph",
        threshold: Optional[float] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Dict:
        """
        Paginated search over memories.

        Args:
            query: Search query string.
            page: 1-based page number.
            page_size: Results per page.
            method: Search method ('graph', 'embedding', 'tags', 'entities').
            threshold: Minimum similarity threshold.
            user_id: Optional user id for multi-tenant isolation.
            session_id: Optional session id for multi-tenant isolation.

        Returns:
            Dict with keys: results, page, page_size, total, total_pages.
        """
        all_results = self.search(
            query,
            method=method,
            limit=len(self.memories) or 1,
            threshold=threshold,
            user_id=user_id,
            session_id=session_id,
        )
        total = len(all_results)
        total_pages = max(1, (total + page_size - 1) // page_size)
        page = max(1, min(page, total_pages))
        start = (page - 1) * page_size
        end = start + page_size

        return {
            "results": all_results[start:end],
            "page": page,
            "page_size": page_size,
            "total": total,
            "total_pages": total_pages,
        }

    def _generate_query_profile(self, query: str) -> Dict:
        """Generate a profile for the query for graph-based search (cached with TTL)."""
        now = time.monotonic()
        cached = self._query_cache.get(query)
        if cached is not None:
            ts, profile = cached
            if now - ts < self._query_cache_ttl:
                return profile

        concepts = set(extract_concepts(query))
        embedding: List[float] = []

        if self.enable_embeddings and self.embedding_generator:
            embedding = self.embedding_generator.generate(query)

        profile = {
            "tags": concepts,
            "entities": concepts,
            "key_points": concepts,
            "concepts": concepts,
            "terms": concepts,
            "embedding": embedding or [],
        }
        self._query_cache[query] = (now, profile)
        return profile
    
    def _graph_search(
        self,
        query: str,
        threshold: float,
        limit: int,
        allowed_ids: Optional[Set[str]] = None
    ) -> List[Dict]:
        """Graph-based semantic search."""
        query_profile = self._generate_query_profile(query)
        query_embedding = query_profile.get("embedding", [])
        query_terms = query_profile.get("terms", set())
        
        nodes = self.semantic_graph.nodes
        concept_match_map = {}
        
        for session_id, node in nodes.items():
            if allowed_ids is not None and node.memoria.get("id") not in allowed_ids:
                continue
            all_terms = node.tags | node.entities | node.key_points
            matches = len(all_terms & query_terms)
            
            if query_embedding:
                sim = cosine_similarity(query_embedding, node.embedding)
                if sim >= 0.5:
                    matches += 1
            
            if matches > 0:
                concept_match_map[session_id] = matches
        
        # Fallback to embedding search if no matches
        if not concept_match_map and query_terms:
            # Try neighbor propagation
            neighbor_scores = defaultdict(float)
            for session_id, node in nodes.items():
                if allowed_ids is not None and node.memoria.get("id") not in allowed_ids:
                    continue
                all_terms = node.tags | node.entities | node.key_points
                direct_matches = len(all_terms & query_terms)
                if direct_matches > 0:
                    for neighbor_id, edge in node.neighbors.items():
                        if allowed_ids is None or neighbor_id in allowed_ids:
                            neighbor_scores[neighbor_id] += edge["weight"] * direct_matches
            
            for session_id, score in sorted(
                neighbor_scores.items(), key=lambda x: x[1], reverse=True
            )[:limit]:
                if score > 0:
                    concept_match_map[session_id] = concept_match_map.get(session_id, 0) + 1
        
        # Still no matches? Fall back to embedding
        if not concept_match_map:
            return self._embedding_search(query, threshold, limit, allowed_ids=allowed_ids)
        
        # Build results
        relevant_memories = []
        for session_id, matches in concept_match_map.items():
            node = nodes[session_id]
            if allowed_ids is not None and node.memoria.get("id") not in allowed_ids:
                continue
            memoria = node.memoria
            
            concept_similarity = matches / max(len(query_terms), 1)
            graph_density = min(node.density, 1.0)
            
            # Temporal decay
            temporal_decay = 1.0
            created_at = memoria.get("created_at", "")
            if created_at:
                try:
                    created_date = datetime.datetime.fromisoformat(
                        created_at.replace('Z', '+00:00')
                    )
                    days_old = (datetime.datetime.now(created_date.tzinfo) - created_date).days
                    temporal_decay = max(0.1, 1.0 - (days_old / 365.0))
                except (ValueError, TypeError, OverflowError):
                    pass
            
            # Composite score
            alpha, beta, gamma = 0.5, 0.35, 0.15
            composite_similarity = (
                alpha * concept_similarity +
                beta * graph_density +
                gamma * temporal_decay
            )
            
            if composite_similarity >= threshold:
                relevant_memories.append({
                    "memoria": memoria,
                    "similaridade": composite_similarity,
                    "concept_matches": matches,
                    "graph_density": graph_density,
                    "temporal_decay": temporal_decay,
                    "method": "graph"
                })
        
        # Sort and limit
        relevant_memories.sort(key=lambda x: x["similaridade"], reverse=True)
        return relevant_memories[:limit]
    
    def _embedding_search(
        self,
        query: str,
        threshold: float,
        limit: int,
        allowed_ids: Optional[Set[str]] = None
    ) -> List[Dict]:
        """Embedding similarity search. Uses FAISS when available, else linear scan."""
        if not self.enable_embeddings or not self.embedding_generator:
            return []
        
        query_embedding = self.embedding_generator.generate(query)
        if not query_embedding:
            return []

        if self._faiss_index is not None and allowed_ids is None:
            return self._faiss_search(query_embedding, threshold, limit)
        
        memories = self.memories
        if allowed_ids is not None:
            memories = [m for m in self.memories if m.get("id") in allowed_ids]
        
        results = []
        for memoria in memories:
            if memoria.get("embedding"):
                similarity = cosine_similarity(query_embedding, memoria["embedding"])
                if similarity >= threshold:
                    results.append({
                        "memoria": memoria,
                        "similaridade": similarity,
                        "method": "embedding"
                    })
        
        results.sort(key=lambda x: x["similaridade"], reverse=True)
        return results[:limit]

    def _faiss_search(
        self,
        query_embedding: List[float],
        threshold: float,
        limit: int,
    ) -> List[Dict]:
        """FAISS-accelerated nearest-neighbor search (cosine similarity via inner product)."""
        vec = np.array([query_embedding], dtype=np.float32)
        faiss.normalize_L2(vec)

        k = min(limit * 2, self._faiss_index.ntotal)
        if k == 0:
            return []
        scores, indices = self._faiss_index.search(vec, k)

        id_to_memory = {m["id"]: m for m in self.memories}
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0 or idx >= len(self._faiss_id_map):
                continue
            sim = float(score)
            if sim < threshold:
                continue
            mem_id = self._faiss_id_map[idx]
            memoria = id_to_memory.get(mem_id)
            if memoria:
                results.append({
                    "memoria": memoria,
                    "similaridade": sim,
                    "method": "embedding_faiss",
                })
            if len(results) >= limit:
                break

        return results
    
    def _field_search(
        self,
        query: str,
        threshold: float,
        limit: int,
        field: str,
        method_name: str,
        allowed_ids: Optional[Set[str]] = None,
    ) -> List[Dict]:
        """Generic field-based search (tags, entities, or any list field)."""
        query_words = [normalize_term(w) for w in query.lower().split()]

        memories = self.memories
        if allowed_ids is not None:
            memories = [m for m in self.memories if m.get("id") in allowed_ids]

        results = []
        for memoria in memories:
            items = [normalize_term(v) for v in memoria.get(field, [])]
            matches = sum(1 for word in query_words if any(word in item for item in items))

            if matches > 0:
                score = matches / len(query_words)
                if score >= threshold:
                    results.append({
                        "memoria": memoria,
                        "similaridade": score,
                        "method": method_name,
                    })

        results.sort(key=lambda x: x["similaridade"], reverse=True)
        return results[:limit]

    def _tag_search(
        self,
        query: str,
        threshold: float,
        limit: int,
        allowed_ids: Optional[Set[str]] = None
    ) -> List[Dict]:
        """Tag-based search."""
        return self._field_search(query, threshold, limit, "tags", "tags", allowed_ids)

    def _entity_search(
        self,
        query: str,
        threshold: float,
        limit: int,
        allowed_ids: Optional[Set[str]] = None
    ) -> List[Dict]:
        """Entity-based search."""
        return self._field_search(query, threshold, limit, "entities", "entities", allowed_ids)
    
    def format_background(self, results: List[Dict], format: Optional[OutputFormat] = None) -> str:
        """
        Format search results as background context for prompts.
        
        Args:
            results: Search results from search() method.
            format: Output format ('json', 'toon', or 'text'). Uses configured output_format if None.
        
        Returns:
            Formatted string with memory context.
        """
        if not results:
            return ""
        
        output_fmt = format or self.output_format
        
        if output_fmt == "text":
            return self._format_as_text(results)
        elif output_fmt == "toon":
            return self._format_as_toon(results)
        else:  # json
            return self._format_as_json(results)
    
    def _format_as_text(self, results: List[Dict]) -> str:
        """Format results as human-readable text."""
        text = "\n\n🧠 BACKGROUND MEMORY (relevant conversations from previous sessions):\n"
        
        for i, item in enumerate(results, 1):
            memoria = item["memoria"]
            similarity = item["similaridade"]
            
            text += f"\n{i}. {memoria.get('summary', 'No summary')}\n"
            text += f"   Tags: {', '.join(memoria.get('tags', []))}\n"
            text += f"   Entities: {', '.join(memoria.get('entities', []))}\n"
            text += f"   Sentiment: {memoria.get('sentiment', 'N/A')}\n"
            text += f"   Relevance: {similarity:.3f}\n"
        
        text += "\nUse this information as additional context for more personalized responses.\n"
        return text
    
    def _format_as_json(self, results: List[Dict]) -> str:
        """Format results as JSON string."""
        # Extract memories without embeddings for context
        memories = []
        for item in results:
            mem = {k: v for k, v in item["memoria"].items() if k != "embedding"}
            mem["relevance"] = item["similaridade"]
            memories.append(mem)
        
        return json.dumps(memories, indent=2, ensure_ascii=False)
    
    def _format_as_toon(self, results: List[Dict]) -> str:
        """Format results as TOON string (25% fewer tokens)."""
        if not TOON_AVAILABLE:
            if self.debug:
                logger.warning("TOON not available, falling back to JSON")
            return self._format_as_json(results)
        
        # Extract memories without embeddings for context
        memories = []
        for item in results:
            mem = {k: v for k, v in item["memoria"].items() if k != "embedding"}
            mem["relevance"] = round(item["similaridade"], 3)
            memories.append(mem)
        
        return toon_encode(memories)
    
    def format_for_llm(self, results: List[Dict], format: Optional[OutputFormat] = None) -> str:
        """
        Format search results optimized for LLM context.
        
        This is the recommended method for preparing memory context to send to an LLM.
        Use format='toon' for ~25% token savings.
        
        Args:
            results: Search results from search() method.
            format: Output format ('json', 'toon', or 'text'). Uses configured output_format if None.
        
        Returns:
            Formatted string optimized for LLM consumption.
        
        Example:
            results = repo.search("What about AI?")
            context = repo.format_for_llm(results, format="toon")  # 25% fewer tokens
            prompt = f"Context: {context}\\n\\nUser: {user_message}"
        """
        return self.format_background(results, format)
    
    def get_token_estimate(self, results: List[Dict]) -> Dict:
        """
        Estimate token counts for different output formats.
        
        Args:
            results: Search results from search() method.
        
        Returns:
            Dictionary with token estimates for each format.
        
        Example:
            estimates = repo.get_token_estimate(results)
            # {'json': 689, 'toon': 512, 'text': 580, 'savings_toon_vs_json': '25.7%'}
        """
        json_output = self._format_as_json(results)
        text_output = self._format_as_text(results)
        
        json_tokens = len(json_output) // 4
        text_tokens = len(text_output) // 4
        
        result = {
            "json": json_tokens,
            "text": text_tokens,
            "json_chars": len(json_output),
            "text_chars": len(text_output),
        }
        
        if TOON_AVAILABLE:
            toon_output = self._format_as_toon(results)
            toon_tokens = len(toon_output) // 4
            savings = ((json_tokens - toon_tokens) / json_tokens) * 100 if json_tokens > 0 else 0
            
            result["toon"] = toon_tokens
            result["toon_chars"] = len(toon_output)
            result["savings_toon_vs_json"] = f"{savings:.1f}%"
        
        return result
    
    def get_stats(
        self,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> Dict:
        """Get repository statistics, optionally filtered by tenant."""
        memories = self.memories
        if user_id is not None or session_id is not None:
            memories = [m for m in self.memories if _match_tenant(m, user_id, session_id)]
        return {
            "total_memories": len(memories),
            "graph_stats": self.semantic_graph.get_stats(),
            "memory_file": self.memory_file,
            "storage_format": self.storage_format,
            "output_format": self.output_format,
            "toon_available": TOON_AVAILABLE,
        }
    
    def clear(
        self,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ):
        """Clear memories. If user_id/session_id given, only removes that tenant's data."""
        with self._lock:
            if user_id is not None or session_id is not None:
                self.memories = [
                    m for m in self.memories
                    if not _match_tenant(m, user_id, session_id)
                ]
                self._rebuild_graph()
            else:
                self.memories.clear()
                self.semantic_graph.clear()
    
    def convert_storage_format(self, new_format: StorageFormat, new_file: Optional[str] = None) -> bool:
        """
        Convert storage to a different format.
        
        Args:
            new_format: Target format ('json' or 'toon').
            new_file: Optional new file path. If None, changes extension of current file.
        
        Returns:
            True if conversion successful.
        
        Example:
            # Convert from JSON to TOON
            repo.convert_storage_format("toon")
            
            # Convert to TOON with new filename
            repo.convert_storage_format("toon", "memories_optimized.toon")
        """
        if new_format == "toon" and not TOON_AVAILABLE:
            raise ImportError("TOON format requires toon_format package. Install: pip install toon_format")
        
        if new_file:
            self.memory_file = new_file
        else:
            # Change extension
            base = self.memory_file.rsplit(".", 1)[0]
            ext = ".toon" if new_format == "toon" else ".json"
            self.memory_file = base + ext
        
        self.storage_format = new_format
        self._save_to_file()
        
        if self.debug:
                logger.debug("Converted to %s: %s", new_format.upper(), self.memory_file)
        
        return True
    
    def export(
        self,
        filepath: str,
        format: Optional[StorageFormat] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> bool:
        """
        Export memories to a file in specified format.
        
        Args:
            filepath: Path to export file.
            format: Export format ('json' or 'toon'). Auto-detected from extension if None.
            user_id: Optional user id to filter exported memories.
            session_id: Optional session id to filter exported memories.
        
        Returns:
            True if export successful.
        
        Example:
            # Export to TOON for sharing
            repo.export("shared_memories.toon", format="toon")
            
            # Export to JSON for compatibility
            repo.export("backup.json")
        """
        if format is None:
            if filepath.endswith(".toon"):
                format = "toon"
            else:
                format = "json"
        
        if format == "toon" and not TOON_AVAILABLE:
            raise ImportError("TOON format requires toon_format package")
        
        filepath = validate_file_path(filepath)
        
        memories = self.memories
        if user_id is not None or session_id is not None:
            memories = [m for m in self.memories if _match_tenant(m, user_id, session_id)]
        
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                if format == "toon":
                    f.write(toon_encode(memories))
                else:
                    json.dump(memories, f, indent=2, ensure_ascii=False)
            
            if self.debug:
                logger.debug("Exported to %s (%s)", filepath, format.upper())
            
            return True
        except (IOError, json.JSONDecodeError, TypeError) as e:
            logger.error("Export failed: %s", e)
            return False
    
    @staticmethod
    def is_toon_available() -> bool:
        """Check if TOON format support is available."""
        return TOON_AVAILABLE