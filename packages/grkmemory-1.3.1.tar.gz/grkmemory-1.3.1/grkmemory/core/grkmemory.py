"""
GRKMemory - Graph Retrieve Knowledge Memory System.

This is the main entry point for the GRKMemory library.
"""

import logging
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

from .config import MemoryConfig
from .agent import KnowledgeAgent
from ..memory.repository import MemoryRepository
from ..graph.semantic_graph import SemanticGraph
from ..utils.async_helpers import run_sync


class GRKMemory:
    """
    GRKMemory - Graph Retrieve Knowledge Memory System.
    
    A semantic graph-based memory system for AI agents that enables
    intelligent knowledge retrieval and structured conversation analysis.
    
    Example:
        # Basic usage
        from grkmemory import GRKMemory
        
        grk = GRKMemory()
        
        # Search for relevant memories
        results = grk.search("What did we discuss about AI?")
        
        # Chat with memory context
        response = grk.chat("Tell me about our previous discussions")
        
        # Save a conversation
        grk.save_conversation([
            {"role": "user", "content": "Hello!"},
            {"role": "assistant", "content": "Hi there!"}
        ])
    
    Example with custom config:
        from grkmemory import GRKMemory, MemoryConfig
        
        config = MemoryConfig(
            memory_file="my_memories.json",
            model="gpt-4o",
            enable_embeddings=True,
            background_memory_method="graph"
        )
        
        grk = GRKMemory(config=config)
    """
    
    def __init__(self, config: Optional[MemoryConfig] = None):
        """
        Initialize GRKMemory.
        
        Args:
            config: Optional MemoryConfig instance. If not provided,
                   creates from environment variables.
        """
        self.config = config or MemoryConfig.from_env()
        
        # Initialize components
        self._repository = MemoryRepository(
            memory_file=self.config.memory_file,
            embedding_model=self.config.embedding_model,
            enable_embeddings=self.config.enable_embeddings,
            debug=self.config.debug,
            memory_limit=self.config.background_memory_limit,
            threshold=self.config.background_memory_threshold,
            storage_format=self.config.storage_format,
            output_format=self.config.output_format,
            encryption_key=self.config.encryption_key,
        )
        
        self._agent = KnowledgeAgent(
            model=self.config.model,
            name="GRKMemory Knowledge Assistant"
        )
    
    @property
    def repository(self) -> MemoryRepository:
        """Get the memory repository."""
        return self._repository
    
    @property
    def agent(self) -> KnowledgeAgent:
        """Get the knowledge agent."""
        return self._agent
    
    @property
    def graph(self) -> SemanticGraph:
        """Get the semantic graph."""
        return self._repository.semantic_graph
    
    def search(
        self,
        query: str,
        method: Optional[str] = None,
        limit: Optional[int] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> List[Dict]:
        """
        Search for relevant memories.
        
        Args:
            query: Search query string.
            method: Search method ('graph', 'embedding', 'tags', 'entities').
                   Uses config default if not provided.
            limit: Maximum results to return.
            user_id: Optional user id for multi-tenant isolation.
            session_id: Optional session id for multi-tenant isolation.
        
        Returns:
            List of search results with 'memoria' and 'similaridade' keys.
        
        Example:
            results = grk.search("AI projects")
            for r in results:
                print(f"{r['memoria']['summary']} - {r['similaridade']:.2f}")
        """
        method = method or self.config.background_memory_method
        return self._repository.search(
            query,
            method=method,
            limit=limit,
            user_id=user_id,
            session_id=session_id
        )
    
    def chat(
        self,
        message: str,
        include_memory: bool = True,
        method: Optional[str] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> str:
        """
        Chat with the GRKMemory agent.
        
        Automatically includes relevant memory context if available.
        
        Args:
            message: User message.
            include_memory: Whether to include memory context.
            method: Memory search method.
            user_id: Optional user id for multi-tenant isolation.
            session_id: Optional session id for multi-tenant isolation.
        
        Returns:
            Agent response text.
        
        Example:
            response = grk.chat("What did we discuss last time?")
            print(response)
        """
        context = None
        
        if include_memory and self.config.background_memory_enabled:
            results = self.search(
                message,
                method=method,
                user_id=user_id,
                session_id=session_id
            )
            if results:
                context = self._repository.format_background(results)
                if self.config.debug:
                    logger.debug("Found %d relevant memories", len(results))
        
        return self._agent.chat(message, context=context)
    
    def chat_with_history(
        self,
        messages: List[Dict],
        include_memory: bool = True,
        method: Optional[str] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> str:
        """
        Continue a conversation with message history.
        
        Args:
            messages: List of message dictionaries.
            include_memory: Whether to include memory context.
            method: Memory search method.
            user_id: Optional user id for multi-tenant isolation.
            session_id: Optional session id for multi-tenant isolation.
        
        Returns:
            Agent response text.
        """
        if include_memory and self.config.background_memory_enabled and messages:
            # Get last user message for context search
            last_user_msg = None
            for msg in reversed(messages):
                if msg.get("role") == "user":
                    last_user_msg = msg.get("content", "")
                    break
            
            if last_user_msg:
                results = self.search(
                    last_user_msg,
                    method=method,
                    user_id=user_id,
                    session_id=session_id
                )
                if results:
                    context = self._repository.format_background(results)
                    # Add context to last user message
                    messages = [m.copy() for m in messages]
                    for i in range(len(messages) - 1, -1, -1):
                        if messages[i].get("role") == "user":
                            messages[i]["content"] += context
                            break
        
        return self._agent.chat_with_history(messages)
    
    def save_conversation(
        self,
        messages: List[Dict],
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> bool:
        """
        Process and save a conversation.
        
        Analyzes the conversation to extract structured information
        and saves it to the memory repository.
        
        Args:
            messages: List of conversation messages.
            user_id: Optional user id for multi-tenant isolation.
            session_id: Optional session id for multi-tenant isolation.
        
        Returns:
            True if saved successfully.
        
        Example:
            success = grk.save_conversation([
                {"role": "user", "content": "Let's discuss AI"},
                {"role": "assistant", "content": "Sure! What aspect?"}
            ])
        """
        data = self._agent.process_conversation(
            messages,
            user_id=user_id,
            session_id=session_id
        )
        if not data:
            if self.config.debug:
                logger.warning("Failed to process conversation")
            return False
        
        return self._repository.save(data)
    
    def save_memories_batch(self, data_list: List[Dict]) -> int:
        """
        Save multiple pre-structured memories in a single batch.

        Uses batch embedding generation for efficiency (one API call
        instead of N).

        Args:
            data_list: List of memory dictionaries.

        Returns:
            Number of memories saved successfully.

        Example:
            count = grk.save_memories_batch([
                {"summary": "AI discussion", "tags": ["ai"]},
                {"summary": "Python tips", "tags": ["python"]},
            ])
        """
        return self._repository.save_batch(data_list)

    def save_memory(self, data: Dict) -> bool:
        """
        Save a pre-structured memory directly.
        
        Args:
            data: Dictionary with memory data.
        
        Returns:
            True if saved successfully.
        """
        return self._repository.save(data)
    
    def get_stats(
        self,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> Dict:
        """
        Get system statistics, optionally filtered by tenant.
        
        Args:
            user_id: Optional user id for multi-tenant isolation.
            session_id: Optional session id for multi-tenant isolation.
        
        Returns:
            Dictionary with memory and graph statistics.
        """
        return self._repository.get_stats(user_id=user_id, session_id=session_id)
    
    def get_graph_stats(self) -> Dict:
        """
        Get semantic graph statistics.
        
        Returns:
            Dictionary with graph statistics.
        """
        return self.graph.get_stats()
    
    def get_top_memories(
        self,
        limit: int = 10,
        by: str = "density",
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> List:
        """
        Get top memories by density or centrality, optionally filtered by tenant.
        
        Args:
            limit: Maximum memories to return.
            by: Sort by 'density' or 'centrality'.
            user_id: Optional user id for multi-tenant isolation.
            session_id: Optional session id for multi-tenant isolation.
        
        Returns:
            List of (summary, score) tuples.
        """
        if by == "centrality":
            results = self.graph.get_top_centrality_nodes(limit * 3 if user_id or session_id else limit)
        else:
            results = self.graph.get_top_density_nodes(limit * 3 if user_id or session_id else limit)
        
        if user_id is not None or session_id is not None:
            from ..memory.repository import _match_tenant
            filtered = []
            for summary, score in results:
                for node in self.graph.nodes.values():
                    if node.summary == summary:
                        if _match_tenant(node.memoria, user_id, session_id):
                            filtered.append((summary, score))
                        break
            return filtered[:limit]
        return results
    
    def format_memory_context(self, results: List[Dict]) -> str:
        """
        Format search results as context string.
        
        Args:
            results: Search results from search() method.
        
        Returns:
            Formatted context string.
        """
        return self._repository.format_background(results)
    
    async def search_async(
        self,
        query: str,
        method: Optional[str] = None,
        limit: Optional[int] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> List[Dict]:
        """Async search: runs search() in a thread so the event loop is not blocked."""
        method = method or self.config.background_memory_method
        return await run_sync(
            self._repository.search,
            query,
            method=method,
            limit=limit,
            user_id=user_id,
            session_id=session_id,
        )
    
    async def save_conversation_async(
        self,
        messages: List[Dict],
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> bool:
        """Async save_conversation: runs save_conversation() in a thread."""
        return await run_sync(
            self.save_conversation,
            messages,
            user_id=user_id,
            session_id=session_id,
        )
    
    async def chat_async(
        self,
        message: str,
        include_memory: bool = True,
        method: Optional[str] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> str:
        """Async chat: runs chat() in a thread."""
        return await run_sync(
            self.chat,
            message,
            include_memory=include_memory,
            method=method,
            user_id=user_id,
            session_id=session_id,
        )
    
    async def chat_with_history_async(
        self,
        messages: List[Dict],
        include_memory: bool = True,
        method: Optional[str] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> str:
        """Async chat_with_history: runs chat_with_history() in a thread."""
        return await run_sync(
            self.chat_with_history,
            messages,
            include_memory=include_memory,
            method=method,
            user_id=user_id,
            session_id=session_id,
        )
    
    @property
    def memory_count(self) -> int:
        """Get the total number of stored memories."""
        return len(self._repository.memories)
