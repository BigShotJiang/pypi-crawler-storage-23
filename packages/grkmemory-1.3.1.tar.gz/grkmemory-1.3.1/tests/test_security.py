"""
Security tests for GRKMemory.

Tests path traversal prevention, file permission enforcement, and rate limiting.
"""

import os
import tempfile
import pytest

from grkmemory.utils.text import validate_file_path


class TestValidateFilePath:
    """Tests for validate_file_path security function."""

    def test_rejects_dotdot_in_middle(self):
        with pytest.raises(ValueError, match="Path traversal"):
            validate_file_path("some/../../etc/passwd")

    def test_rejects_dotdot_at_start(self):
        with pytest.raises(ValueError, match="Path traversal"):
            validate_file_path("../secret.json")

    def test_rejects_dotdot_normalized(self):
        """The old bug: normpath collapsed '..' making the check pass."""
        with pytest.raises(ValueError, match="Path traversal"):
            validate_file_path("/a/b/../../../etc/passwd")

    def test_accepts_valid_relative_path(self):
        result = validate_file_path("memories.json")
        assert os.path.isabs(result)

    def test_accepts_valid_absolute_path(self):
        with tempfile.NamedTemporaryFile(suffix=".json") as f:
            result = validate_file_path(f.name)
            assert result == os.path.realpath(f.name)

    def test_base_dir_rejects_outside(self):
        with tempfile.TemporaryDirectory() as base:
            with pytest.raises(ValueError, match="resolves outside"):
                validate_file_path("/etc/passwd", base_dir=base)

    def test_base_dir_accepts_inside(self):
        with tempfile.TemporaryDirectory() as base:
            inner = os.path.join(base, "data.json")
            result = validate_file_path(inner, base_dir=base)
            assert result.startswith(os.path.realpath(base))

    def test_base_dir_rejects_symlink_escape(self, tmp_path):
        target = tmp_path / "outside"
        target.mkdir()
        secret = target / "secret.json"
        secret.write_text("{}")

        jail = tmp_path / "jail"
        jail.mkdir()
        link = jail / "escape.json"
        link.symlink_to(secret)

        with pytest.raises(ValueError, match="resolves outside"):
            validate_file_path(str(link), base_dir=str(jail))

    def test_allows_dotdot_in_filename(self):
        """Filenames like 'foo..bar' should not trigger traversal."""
        result = validate_file_path("foo..bar.json")
        assert os.path.isabs(result)
