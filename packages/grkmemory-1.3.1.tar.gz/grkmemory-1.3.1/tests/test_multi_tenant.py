"""
Tests: Multi-tenant (user_id / session_id)
==========================================

Verifica isolamento de memórias por user_id e session_id em save e search.
"""

import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from grkmemory.memory.repository import MemoryRepository


def test_search_filtered_by_user_id():
    """Salva duas memórias com user_id diferentes; search(query, user_id=A) retorna só as de A."""
    with tempfile.TemporaryDirectory() as tmpdir:
        memory_file = os.path.join(tmpdir, "tenant.json")
        repo = MemoryRepository(
            memory_file=memory_file,
            enable_embeddings=False,
            debug=False,
        )

        repo.save({
            "summary": "Memory for user A",
            "tags": ["python", "user_a"],
            "entities": ["Alice"],
            "key_points": ["topic_a"],
            "user_id": "user_A",
            "source": {"type": "session", "session_id": "sess_1"},
        })
        repo.save({
            "summary": "Memory for user B",
            "tags": ["python", "user_b"],
            "entities": ["Bob"],
            "key_points": ["topic_b"],
            "user_id": "user_B",
            "source": {"type": "session", "session_id": "sess_2"},
        })

        results_a = repo.search("python", method="tags", user_id="user_A")
        results_b = repo.search("python", method="tags", user_id="user_B")

        assert len(results_a) == 1
        assert results_a[0]["memoria"].get("user_id") == "user_A"
        assert len(results_b) == 1
        assert results_b[0]["memoria"].get("user_id") == "user_B"


def test_search_filtered_by_session_id():
    """Salva duas memórias com session_id diferentes; search(query, session_id=X) retorna só as de X."""
    with tempfile.TemporaryDirectory() as tmpdir:
        memory_file = os.path.join(tmpdir, "tenant.json")
        repo = MemoryRepository(
            memory_file=memory_file,
            enable_embeddings=False,
            debug=False,
        )

        repo.save({
            "summary": "Session one",
            "tags": ["tag_one"],
            "entities": ["E1"],
            "key_points": ["kp1"],
            "source": {"type": "session", "session_id": "sess_one"},
        })
        repo.save({
            "summary": "Session two",
            "tags": ["tag_two"],
            "entities": ["E2"],
            "key_points": ["kp2"],
            "source": {"type": "session", "session_id": "sess_two"},
        })

        results_one = repo.search("tag", method="tags", session_id="sess_one")
        results_two = repo.search("tag", method="tags", session_id="sess_two")

        assert len(results_one) == 1
        assert results_one[0]["memoria"].get("source", {}).get("session_id") == "sess_one"
        assert len(results_two) == 1
        assert results_two[0]["memoria"].get("source", {}).get("session_id") == "sess_two"


def test_search_filtered_by_user_id_and_session_id():
    """Filtro combinado user_id + session_id retorna só a memória que bate com ambos."""
    with tempfile.TemporaryDirectory() as tmpdir:
        memory_file = os.path.join(tmpdir, "tenant.json")
        repo = MemoryRepository(
            memory_file=memory_file,
            enable_embeddings=False,
            debug=False,
        )

        repo.save({
            "summary": "User A session 1",
            "tags": ["common"],
            "entities": ["X"],
            "key_points": ["k"],
            "user_id": "user_A",
            "source": {"type": "session", "session_id": "s1"},
        })
        repo.save({
            "summary": "User A session 2",
            "tags": ["common"],
            "entities": ["X"],
            "key_points": ["k"],
            "user_id": "user_A",
            "source": {"type": "session", "session_id": "s2"},
        })
        repo.save({
            "summary": "User B session 1",
            "tags": ["common"],
            "entities": ["X"],
            "key_points": ["k"],
            "user_id": "user_B",
            "source": {"type": "session", "session_id": "s1"},
        })

        results = repo.search("common", method="tags", user_id="user_A", session_id="s1")
        assert len(results) == 1
        assert results[0]["memoria"].get("user_id") == "user_A"
        assert results[0]["memoria"].get("source", {}).get("session_id") == "s1"


def test_search_without_tenant_returns_all():
    """Sem user_id/session_id, search retorna memórias de todos."""
    with tempfile.TemporaryDirectory() as tmpdir:
        memory_file = os.path.join(tmpdir, "tenant.json")
        repo = MemoryRepository(
            memory_file=memory_file,
            enable_embeddings=False,
            debug=False,
        )

        repo.save({
            "summary": "First",
            "tags": ["python"],
            "entities": ["E"],
            "key_points": ["K"],
            "user_id": "user_A",
            "source": {"session_id": "s1"},
        })
        repo.save({
            "summary": "Second",
            "tags": ["python"],
            "entities": ["E"],
            "key_points": ["K"],
            "user_id": "user_B",
            "source": {"session_id": "s2"},
        })

        results = repo.search("python", method="tags")
        assert len(results) >= 2
