"""
Tests: API assíncrona (search_async, save_conversation_async)
==============================================================

Verifica que search_async e save_conversation_async retornam os mesmos
resultados que as versões síncronas (usando pytest-asyncio).
"""

import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from grkmemory import GRKMemory
from grkmemory.core.config import MemoryConfig


@pytest.fixture
def grk_with_memories():
    """GRKMemory com memórias pré-carregadas (sem depender de API para search)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        memory_file = os.path.join(tmpdir, "async_test.json")
        config = MemoryConfig(
            memory_file=memory_file,
            background_memory_method="tags",
            background_memory_limit=10,
            enable_embeddings=False,
            debug=False,
            api_key="test-key-for-async-tests",  # needed for config validation; search does not call API
        )
        grk = GRKMemory(config=config)
        # Preencher repositório diretamente para não precisar de API
        grk.repository.save({
            "summary": "Async test memory",
            "tags": ["python", "async", "test"],
            "entities": ["GRKMemory"],
            "key_points": ["async API"],
        })
        yield grk


@pytest.mark.asyncio
async def test_search_async_matches_sync(grk_with_memories):
    """search_async retorna os mesmos resultados que search."""
    grk = grk_with_memories
    query = "python async"
    sync_results = grk.search(query, method="tags", limit=5)
    async_results = await grk.search_async(query, method="tags", limit=5)
    assert len(async_results) == len(sync_results)
    for s, a in zip(sync_results, async_results):
        assert s["memoria"].get("id") == a["memoria"].get("id")
        assert s["similaridade"] == a["similaridade"]


@pytest.mark.asyncio
async def test_save_conversation_async_returns_bool():
    """save_conversation_async executa e retorna um bool (como save_conversation)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        memory_file = os.path.join(tmpdir, "async_save.json")
        config = MemoryConfig(
            memory_file=memory_file,
            background_memory_method="tags",
            enable_embeddings=False,
            debug=False,
            api_key="test-key-for-async-tests",  # required by config; agent may fail with invalid key
        )
        grk = GRKMemory(config=config)
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi!"},
        ]
        # Pode falhar o processamento (sem API key) mas a chamada async não deve quebrar
        result = await grk.save_conversation_async(messages)
        assert isinstance(result, bool)
