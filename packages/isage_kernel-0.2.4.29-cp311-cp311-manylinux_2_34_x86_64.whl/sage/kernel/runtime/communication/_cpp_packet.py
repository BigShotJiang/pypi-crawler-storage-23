"""
_cpp_packet — C++ Packet + KeyRouter with Python fallback.

Tries to import ``_isage_kernel_ext`` (compiled with
``-DISAGE_KERNEL_BUILD_CPP=ON``).  Falls back transparently to pure-Python
implementations when the extension is not available.

Usage::

    from sage.kernel.runtime.communication._cpp_packet import (
        cpp_available,
        Packet,
        KeyRouter,
    )

    p = Packet(input_index=0, partition_key="user:42", partition_strategy="hash")
    assert p.is_keyed()

    router = KeyRouter()
    router.add_route("user:42", "worker-1")
    target, hit = router.route("user:42")   # ("worker-1", True)
    bucket = KeyRouter.hash_partition("user:42", n_partitions=4)
"""

from __future__ import annotations

import time

# ── Try to import the compiled C++ extension ──────────────────────────────
try:
    from _isage_kernel_ext import (  # type: ignore[import]
        KeyRouter,
        Packet,
    )

    cpp_available: bool = True
except ImportError:
    cpp_available = False

    # ── Pure-Python fallback implementations ──────────────────────────────

    class Packet:  # type: ignore[no-redef]
        """Pure-Python Packet (fallback, same API as C++ Packet)."""

        def __init__(
            self,
            input_index: int = 0,
            partition_key: str = "",
            partition_strategy: str = "",
        ) -> None:
            self.input_index = input_index
            self.partition_key = partition_key
            self.partition_strategy = partition_strategy
            self.timestamp_ns: int = time.time_ns()

        def is_keyed(self) -> bool:
            return bool(self.partition_key)

        def inherit(self) -> Packet:
            return Packet(
                input_index=self.input_index,
                partition_key=self.partition_key,
                partition_strategy=self.partition_strategy,
            )

        def update_key(self, new_key: str, new_strategy: str = "") -> Packet:
            return Packet(
                input_index=self.input_index,
                partition_key=new_key,
                partition_strategy=new_strategy or self.partition_strategy,
            )

        def __repr__(self) -> str:
            key = self.partition_key or "None"
            return f"<Packet[py] idx={self.input_index} key={key} ts={self.timestamp_ns}>"

    class KeyRouter:  # type: ignore[no-redef]
        """Pure-Python KeyRouter (fallback, same API as C++ KeyRouter)."""

        def __init__(self) -> None:
            self._routes: dict[str, str] = {}

        def add_route(self, key: str, target: str) -> None:
            self._routes[key] = target

        def remove_route(self, key: str) -> None:
            self._routes.pop(key, None)

        def route(self, key: str) -> tuple[str, bool]:
            if key in self._routes:
                return self._routes[key], True
            return "", False

        @staticmethod
        def hash_partition(key: str, n_partitions: int) -> int:
            if n_partitions <= 0:
                return 0
            return hash(key) % n_partitions

        @property
        def size(self) -> int:
            return len(self._routes)

        @property
        def empty(self) -> bool:
            return len(self._routes) == 0

        def clear(self) -> None:
            self._routes.clear()


__all__ = [
    "cpp_available",
    "Packet",
    "KeyRouter",
]
