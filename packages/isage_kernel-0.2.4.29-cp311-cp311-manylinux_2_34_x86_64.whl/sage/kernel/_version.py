"""Version information for sage-kernel package."""

# 独立硬编码版本
__version__ = "0.2.4.29"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
