class PlotDataError(ValueError):
    """Raised when plotting inputs are invalid or cannot be normalized."""
