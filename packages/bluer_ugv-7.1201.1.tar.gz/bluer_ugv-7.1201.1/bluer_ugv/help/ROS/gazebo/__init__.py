from bluer_ugv.help.ROS.gazebo.gui import help_functions as help_gui
from bluer_ugv.help.ROS.gazebo.robot import help_functions as help_robot


help_functions = {
    "gui": help_gui,
    "robot": help_robot,
}
