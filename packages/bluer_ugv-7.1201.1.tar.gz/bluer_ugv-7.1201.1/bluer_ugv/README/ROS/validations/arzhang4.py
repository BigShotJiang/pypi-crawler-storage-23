from bluer_objects.README.items import ImageItems
from bluer_objects.README.consts import assets_url

docs = [
    {
        "path": f"../docs/ROS/validations/arzhang4/{suffix}",
    }
    for suffix in [
        "",
    ]
]
