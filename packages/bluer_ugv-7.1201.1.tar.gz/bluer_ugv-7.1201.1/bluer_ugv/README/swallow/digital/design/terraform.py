from bluer_objects.README.items import ImageItems

from bluer_ugv.README.swallow.consts import swallow_assets2

docs = [
    {
        "path": "../docs/swallow/digital/design/terraform.md",
        "items": ImageItems(
            {
                f"{swallow_assets2}/20250611_100917.jpg": "",
                f"{swallow_assets2}/lab.png": "",
                f"{swallow_assets2}/lab2.png": "",
            }
        ),
    },
]
