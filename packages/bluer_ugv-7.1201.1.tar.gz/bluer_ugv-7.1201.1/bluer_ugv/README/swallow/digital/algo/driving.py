docs = [
    {
        "path": "../docs/swallow/digital/algo/driving.md",
    },
]
