#! /usr/bin/env bash

alias @ROS=bluer_ugv_ROS

alias @swallow=bluer_ugv_swallow

alias @ugv=bluer_ugv
