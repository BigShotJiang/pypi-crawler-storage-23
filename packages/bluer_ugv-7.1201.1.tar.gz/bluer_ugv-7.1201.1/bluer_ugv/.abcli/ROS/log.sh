#! /usr/bin/env bash

function bluer_ugv_ROS_log() {
    bluer_ai_log "GZ_IP: $GZ_IP"
    bluer_ai_log "GZ_RELAY: $GZ_RELAY"
    bluer_ai_log "GZ_PARTITION: $GZ_PARTITION"
    bluer_ai_log "RPI_LGPIO_CHIP=$RPI_LGPIO_CHIP"
}
