"""Tests for mm_clikit package."""
