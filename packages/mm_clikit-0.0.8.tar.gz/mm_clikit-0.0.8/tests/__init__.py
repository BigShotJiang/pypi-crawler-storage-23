"""Tests for mm-clikit."""
