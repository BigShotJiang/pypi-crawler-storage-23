#!/usr/bin/env python3
"""
live-casi languages: Multi-language support for AI text detection.

Supported: German (de), English (en), Japanese (ja), Chinese (zh),
           French (fr), Spanish (es).

Each language pack includes:
  - ChatGPT-typical phrases and sentence starters
  - DeepL/translation markers
  - Hedging words
  - Recommended tokenizer

Usage:
    from live_casi.languages import get_language_pack
    pack = get_language_pack('ja')
    print(pack['chatgpt_phrases'])
"""

__all__ = ['get_language_pack', 'SUPPORTED_LANGUAGES']

SUPPORTED_LANGUAGES = ['de', 'en', 'ja', 'zh', 'fr', 'es']

_PACKS = {
    'de': {
        'name': 'Deutsch',
        'tokenizer': 'dbmdz/german-gpt2',
        'chatgpt_phrases': [
            "es ist wichtig zu beachten", "es ist erwähnenswert",
            "zusammenfassend lässt sich sagen", "zusammenfassend lässt sich festhalten",
            "in diesem zusammenhang", "in diesem kontext",
            "darüber hinaus", "des weiteren", "es sei darauf hingewiesen",
            "eine wichtige rolle spielt", "von entscheidender bedeutung",
            "von großer bedeutung", "eine zentrale rolle",
            "ein wesentlicher aspekt", "eine umfassende analyse",
            "eine detaillierte analyse", "lässt sich feststellen",
            "kann festgestellt werden", "es zeigt sich, dass",
            "wie bereits erwähnt", "abschließend lässt sich",
            "insgesamt zeigt sich", "die ergebnisse deuten darauf hin",
            "es konnte gezeigt werden", "es ist unerlässlich",
        ],
        'chatgpt_starters': [
            "darüber hinaus", "zusammenfassend", "insgesamt", "abschließend",
            "des weiteren", "ferner", "überdies", "nichtsdestotrotz",
            "grundsätzlich", "letztendlich", "im wesentlichen", "insbesondere",
            "hervorzuheben ist", "bemerkenswert ist", "festzuhalten ist",
        ],
        'hedges': [
            "möglicherweise", "wahrscheinlich", "vermutlich", "tendenziell",
            "potenziell", "gegebenenfalls", "unter umständen",
        ],
        'deepl_markers': [
            "implementiert", "adressiert", "fokussiert", "evaluiert",
            "identifiziert", "generiert", "validiert", "optimiert",
            "wurde durchgeführt", "wurde festgestellt", "wurde beobachtet",
            "in bezug auf", "im hinblick auf", "hinsichtlich der",
        ],
    },
    'en': {
        'name': 'English',
        'tokenizer': 'gpt2',
        'chatgpt_phrases': [
            "it is important to note", "it is worth noting", "it should be noted",
            "in this context", "furthermore", "moreover", "additionally",
            "plays a crucial role", "of great significance",
            "a comprehensive analysis", "a detailed analysis",
            "it can be observed", "as previously mentioned",
            "the results suggest", "it was demonstrated",
            "it is essential", "significantly influenced",
            "in the following section", "as discussed above",
            "it is noteworthy that", "this underscores the importance",
            "a key finding", "the implications of these findings",
            "this highlights the need", "taken together",
        ],
        'chatgpt_starters': [
            "furthermore", "moreover", "additionally", "in conclusion",
            "overall", "notably", "essentially", "fundamentally",
            "interestingly", "importantly", "significantly",
            "it is worth", "it should be", "this suggests",
        ],
        'hedges': [
            "possibly", "probably", "presumably", "potentially",
            "perhaps", "arguably", "conceivably", "seemingly",
        ],
        'deepl_markers': [
            "implemented", "addressed", "focused", "evaluated",
            "identified", "generated", "validated", "optimized",
            "was carried out", "was determined", "was observed",
            "with regard to", "in terms of", "with respect to",
        ],
    },
    'ja': {
        'name': '日本語',
        'tokenizer': 'rinna/japanese-gpt2-medium',
        'chatgpt_phrases': [
            "重要なことは", "注目すべきは", "特筆すべきは",
            "まとめると", "結論として", "総合的に見ると",
            "さらに", "加えて", "その上",
            "重要な役割を果たして", "大きな意義がある",
            "本研究では", "本稿では",
            "包括的な分析", "詳細な分析",
            "確認することができた", "示唆している",
            "明らかになった", "考えられる",
            "不可欠である", "大きな影響を与えて",
            "以上のことから", "これらの結果は",
            "今後の課題として", "検討する必要がある",
        ],
        'chatgpt_starters': [
            "さらに", "加えて", "その上", "まとめると",
            "結論として", "総合的に", "特に", "基本的に",
            "最終的に", "本質的に", "注目すべきは",
            "重要なことは", "興味深いことに",
        ],
        'hedges': [
            "おそらく", "恐らく", "可能性がある",
            "と考えられる", "と思われる", "かもしれない",
            "と推測される", "の可能性が示唆される",
        ],
        'deepl_markers': [
            "実施された", "確認された", "観察された",
            "に関して", "の観点から", "に基づいて",
            "を踏まえて", "に鑑みて",
        ],
    },
    'zh': {
        'name': '中文',
        'tokenizer': 'uer/gpt2-chinese-cluecorpussmall',
        'chatgpt_phrases': [
            "值得注意的是", "需要指出的是", "重要的是",
            "总而言之", "综上所述", "总的来说",
            "此外", "另外", "除此之外",
            "发挥着重要作用", "具有重要意义",
            "本研究", "本文",
            "全面的分析", "详细的分析",
            "可以看出", "结果表明",
            "已经证明", "不可或缺",
            "产生了重大影响", "这些发现表明",
            "未来的研究方向", "需要进一步研究",
            "在此背景下", "从这个角度来看",
        ],
        'chatgpt_starters': [
            "此外", "另外", "总而言之", "综上所述",
            "值得注意的是", "特别是", "基本上",
            "最终", "本质上", "重要的是",
            "有趣的是", "显然",
        ],
        'hedges': [
            "可能", "也许", "大概", "或许",
            "似乎", "看起来", "据推测",
        ],
        'deepl_markers': [
            "被实施", "被确认", "被观察到",
            "关于", "在方面", "鉴于",
            "考虑到", "就而言",
        ],
    },
    'fr': {
        'name': 'Français',
        'tokenizer': 'gpt2',
        'chatgpt_phrases': [
            "il est important de noter", "il convient de souligner",
            "en résumé", "en conclusion", "dans l'ensemble",
            "de plus", "en outre", "par ailleurs",
            "joue un rôle crucial", "d'une grande importance",
            "une analyse approfondie", "une analyse détaillée",
            "il a été démontré", "les résultats suggèrent",
            "il est essentiel", "a significativement influencé",
            "dans le cadre de cette étude", "comme mentionné précédemment",
        ],
        'chatgpt_starters': [
            "de plus", "en outre", "par ailleurs", "en conclusion",
            "dans l'ensemble", "notamment", "essentiellement",
            "fondamentalement", "il est intéressant",
        ],
        'hedges': [
            "possiblement", "probablement", "vraisemblablement",
            "potentiellement", "éventuellement", "peut-être",
        ],
        'deepl_markers': [
            "a été réalisé", "a été constaté", "a été observé",
            "en ce qui concerne", "par rapport à", "eu égard à",
        ],
    },
    'es': {
        'name': 'Español',
        'tokenizer': 'gpt2',
        'chatgpt_phrases': [
            "es importante señalar", "cabe destacar", "vale la pena mencionar",
            "en resumen", "en conclusión", "en general",
            "además", "asimismo", "por otra parte",
            "desempeña un papel crucial", "de gran importancia",
            "un análisis exhaustivo", "un análisis detallado",
            "se ha demostrado", "los resultados sugieren",
            "es esencial", "ha influido significativamente",
            "en el marco de este estudio", "como se mencionó anteriormente",
        ],
        'chatgpt_starters': [
            "además", "asimismo", "por otra parte", "en conclusión",
            "en general", "en particular", "esencialmente",
            "fundamentalmente", "es interesante",
        ],
        'hedges': [
            "posiblemente", "probablemente", "presumiblemente",
            "potencialmente", "eventualmente", "quizás", "tal vez",
        ],
        'deepl_markers': [
            "fue realizado", "fue constatado", "fue observado",
            "con respecto a", "en relación con", "en cuanto a",
        ],
    },
}


def get_language_pack(language='de'):
    """Get the language pack for AI detection.

    Args:
        language: ISO 639-1 code ('de', 'en', 'ja', 'zh', 'fr', 'es').

    Returns:
        dict with chatgpt_phrases, chatgpt_starters, hedges, deepl_markers,
        tokenizer name, and language name.

    Raises:
        ValueError: If language not supported.
    """
    if language not in _PACKS:
        raise ValueError(
            f"Language '{language}' not supported. "
            f"Available: {', '.join(SUPPORTED_LANGUAGES)}"
        )
    return _PACKS[language].copy()
