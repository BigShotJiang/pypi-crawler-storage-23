#!/usr/bin/env python3
"""
CASI Post-Quantum Cryptography Analysis — live-casi v0.5.0

First statistical/black-box evaluation of PQC cipher output using CASI.
No existing tool does this — the Lattice Estimator is purely algebraic.

Supported families:
  - ML-KEM (Kyber) 512/768/1024  — Lattice KEM (FIPS 203)
  - ML-DSA (Dilithium) 44/65/87  — Lattice Signature (FIPS 204)
  - HQC 128/192/256              — Code-based KEM (NIST Round 4)

Usage:
    from live_casi.pqc import pqc_analyze, pqc_compare, pqc_causal
    results = pqc_analyze('mlkem', 768)
    report = pqc_compare(n_samples=1000)
    stats = pqc_causal('output.causal')

CLI:
    live-casi --pqc                        # Full 9-config analysis
    live-casi --pqc --cipher mlkem         # Only ML-KEM family
    live-casi --pqc --json                 # Machine-readable
    live-casi --pqc-causal output.causal   # Knowledge graph
"""

import os
import sys
import time
import json
import numpy as np

from .core import (
    compute_signal, compute_crypto_signal,
    STRATEGY_NAMES, CRYPTO_STRATEGY_NAMES, IMPL_STRATEGY_NAMES,
    Z_THRESHOLD, casi_verdict,
)

# ═══════════════════════════════════════════════════════════════
# PQC ALGORITHM REGISTRY
# ═══════════════════════════════════════════════════════════════

PQC_FAMILIES = {
    'mlkem': {
        'name': 'ML-KEM (Kyber)',
        'paradigm': 'Lattice (Module-LWE)',
        'standard': 'FIPS 203',
        'type': 'kem',
        'levels': {
            512:  {'module': 'pqcrypto.kem.ml_kem_512',  'nist_level': 1, 'ct_size': 768},
            768:  {'module': 'pqcrypto.kem.ml_kem_768',  'nist_level': 3, 'ct_size': 1088},
            1024: {'module': 'pqcrypto.kem.ml_kem_1024', 'nist_level': 5, 'ct_size': 1568},
        },
        'properties': {
            'operations': ['polynomial_multiplication', 'NTT', 'noise_sampling', 'compression'],
            'structure': 'lattice_lwe_encryption',
            'diffusion': 'polynomial_ring_arithmetic',
            'key_schedule': 'random_matrix_generation',
        },
    },
    'mldsa': {
        'name': 'ML-DSA (Dilithium)',
        'paradigm': 'Lattice (Module-LWE/SIS)',
        'standard': 'FIPS 204',
        'type': 'sign',
        'levels': {
            44: {'module': 'pqcrypto.sign.ml_dsa_44', 'nist_level': 2, 'sig_size': 2420},
            65: {'module': 'pqcrypto.sign.ml_dsa_65', 'nist_level': 3, 'sig_size': 3309},
            87: {'module': 'pqcrypto.sign.ml_dsa_87', 'nist_level': 5, 'sig_size': 4627},
        },
        'properties': {
            'operations': ['polynomial_multiplication', 'NTT', 'rejection_sampling', 'hashing'],
            'structure': 'fiat_shamir_with_aborts',
            'diffusion': 'polynomial_ring_arithmetic',
            'key_schedule': 'expandA_from_seed',
        },
    },
    'hqc': {
        'name': 'HQC',
        'paradigm': 'Code-based (QC-MDPC)',
        'standard': 'NIST Round 4 Selected',
        'type': 'kem',
        'levels': {
            128: {'module': 'pqcrypto.kem.hqc_128', 'nist_level': 1, 'ct_size': 4433},
            192: {'module': 'pqcrypto.kem.hqc_192', 'nist_level': 3, 'ct_size': 8978},
            256: {'module': 'pqcrypto.kem.hqc_256', 'nist_level': 5, 'ct_size': 14421},
        },
        'properties': {
            'operations': ['vector_multiplication', 'error_correction', 'hashing', 'xor'],
            'structure': 'syndrome_decoding',
            'diffusion': 'quasi_cyclic_code_multiplication',
            'key_schedule': 'random_code_generation',
        },
    },
}

# All 9 configurations for full analysis
PQC_CONFIGS = [
    ('mlkem', 512), ('mlkem', 768), ('mlkem', 1024),
    ('mldsa', 44),  ('mldsa', 65),  ('mldsa', 87),
    ('hqc', 128),   ('hqc', 192),   ('hqc', 256),
]


def pqc_verdict(casi_full, casi_crypto, pqc_type):
    """PQC-aware verdict that distinguishes structural format from cryptographic weakness.

    Signatures (sign) are NOT designed to be pseudorandom — high Impl-CASI is
    expected from hint vectors, rejection sampling, etc. Only Crypto-CASI matters.

    KEM ciphertexts should approximate pseudorandom. Elevated Crypto-CASI at
    scale indicates compression/packing artifacts, not necessarily weakness.
    """
    if pqc_type == 'sign':
        # Signatures: only crypto strategies matter
        if casi_crypto < 1.5:
            return 'PSEUDORANDOM'
        elif casi_crypto < 3.0:
            return 'DIST_BIAS'      # distributional bias detected
        else:
            return 'STRUCTURED'     # strong non-uniformity in crypto strategies
    else:
        # KEM: both matter but crypto takes precedence
        if casi_crypto < 1.5 and casi_full < 2.0:
            return 'PSEUDORANDOM'
        elif casi_crypto < 3.0:
            return 'DIST_BIAS'
        else:
            return 'STRUCTURED'


# ═══════════════════════════════════════════════════════════════
# PQC OUTPUT GENERATORS
# ═══════════════════════════════════════════════════════════════

def _import_pqc_module(module_path):
    """Import a pqcrypto module by dotted path."""
    import importlib
    return importlib.import_module(module_path)


def generate_pqc_stream(family, level, count, key_size=32):
    """Generate a byte stream from PQC operations.

    For KEM: generates count encapsulations, concatenates ciphertexts.
    For signatures: generates count signatures on random messages.

    Returns raw bytes suitable for compute_signal().
    """
    fam = PQC_FAMILIES[family]
    lev = fam['levels'][level]
    mod = _import_pqc_module(lev['module'])

    chunks = []
    total_bytes = 0
    target_bytes = count * key_size  # Match classical cipher output size

    if fam['type'] == 'kem':
        while total_bytes < target_bytes:
            pk, sk = mod.generate_keypair()
            ct, ss = mod.encrypt(pk)
            chunks.append(ct)
            total_bytes += len(ct)
    elif fam['type'] == 'sign':
        while total_bytes < target_bytes:
            pk, sk = mod.generate_keypair()
            msg = os.urandom(64)
            sig = mod.sign(sk, msg)
            chunks.append(sig)
            total_bytes += len(sig)

    raw = b''.join(chunks)[:target_bytes]
    return raw


# ═══════════════════════════════════════════════════════════════
# PQC CASI ANALYSIS
# ═══════════════════════════════════════════════════════════════

def pqc_analyze(family, level, n_samples=5000, key_size=32, verbose=True):
    """Analyze a single PQC configuration with all 12 CASI strategies.

    Returns dict with CASI score, per-strategy signals, and metadata.
    """
    fam = PQC_FAMILIES[family]
    lev = fam['levels'][level]
    label = f"{fam['name']}-{level}"

    if verbose:
        print(f"\n  Analyzing {label} (NIST Level {lev['nist_level']})...")

    t0 = time.time()
    raw = generate_pqc_stream(family, level, n_samples, key_size)
    t_gen = time.time() - t0

    # Convert to key-sized blocks for CASI
    keys = np.frombuffer(raw, dtype=np.uint8).reshape(-1, key_size)

    # Compute both full and crypto-only signals
    t1 = time.time()
    sig_full = compute_signal(keys)
    sig_crypto = compute_crypto_signal(keys)
    t_analysis = time.time() - t1

    # Compute baseline (random)
    rng_keys = np.frombuffer(os.urandom(len(raw)), dtype=np.uint8).reshape(-1, key_size)
    baseline = compute_signal(rng_keys)

    # CASI = signal / baseline
    casi_full = sig_full['total'] / max(baseline['total'], 1)
    casi_crypto = sig_crypto['total'] / max(
        sum(baseline[s] for s in CRYPTO_STRATEGY_NAMES), 1
    )

    # Per-strategy ratios
    strategy_detail = {}
    for s in STRATEGY_NAMES:
        b = max(baseline[s], 1)
        ratio = sig_full[s] / b
        strategy_detail[s] = {
            'signal': sig_full[s],
            'baseline': baseline[s],
            'ratio': round(ratio, 4),
            'significant': ratio > 1.5 or sig_full[s] > b + 3 * np.sqrt(b),
        }

    verdict_pqc = pqc_verdict(casi_full, casi_crypto, fam['type'])

    result = {
        'family': family,
        'level': level,
        'label': label,
        'paradigm': fam['paradigm'],
        'standard': fam['standard'],
        'nist_level': lev['nist_level'],
        'pqc_type': fam['type'],
        'casi_full': round(casi_full, 4),
        'casi_crypto': round(casi_crypto, 4),
        'verdict': verdict_pqc,
        'n_samples': keys.shape[0],
        'strategies': strategy_detail,
        'time_gen': round(t_gen, 3),
        'time_analysis': round(t_analysis, 3),
    }

    if verbose:
        v = result['verdict']
        print(f"    CASI (full):   {casi_full:.4f}")
        print(f"    CASI (crypto): {casi_crypto:.4f}  [{v}]")
        print(f"    Samples: {keys.shape[0]:,}  |  Gen: {t_gen:.1f}s  |  Analysis: {t_analysis:.1f}s")

        # Show significant strategies
        sigs = [s for s, d in strategy_detail.items() if d['significant']]
        if sigs:
            print(f"    Significant: {', '.join(sigs)}")

    return result


def pqc_compare(n_samples=5000, key_size=32, families=None, verbose=True):
    """Compare all PQC configurations. Returns full comparison report.

    Args:
        n_samples: keys per configuration
        families: list of family names to test, or None for all
        verbose: print progress
    """
    configs = PQC_CONFIGS
    if families:
        configs = [(f, l) for f, l in configs if f in families]

    if verbose:
        print(f"\n{'='*60}")
        print(f"  CASI Post-Quantum Cryptography Analysis")
        print(f"  {len(configs)} configurations × {n_samples:,} samples")
        print(f"{'='*60}")

    # Also compute classical baselines for comparison
    classical = {}
    if verbose:
        print(f"\n  Classical baselines:")
    for cipher_name in ['aes', 'chacha']:
        from .ciphers import CIPHERS
        cipher = CIPHERS[cipher_name]
        raw = cipher['generator'](n_samples)
        keys = np.frombuffer(raw, dtype=np.uint8).reshape(-1, key_size)
        sig = compute_signal(keys)
        rng = np.frombuffer(os.urandom(len(raw)), dtype=np.uint8).reshape(-1, key_size)
        base = compute_signal(rng)
        casi = sig['total'] / max(base['total'], 1)
        classical[cipher_name] = round(casi, 4)
        if verbose:
            print(f"    {cipher['name']:20s}  CASI = {casi:.4f}")

    # Run all PQC configs
    results = []
    for family, level in configs:
        r = pqc_analyze(family, level, n_samples, key_size, verbose)
        results.append(r)

    # Cross-family analysis
    analysis = _cross_analysis(results, classical)

    if verbose:
        _print_comparison_table(results, classical, analysis)

    return {
        'configs': results,
        'classical': classical,
        'analysis': analysis,
        'n_samples': n_samples,
    }


def _cross_analysis(results, classical):
    """Analyze cross-family patterns in PQC results."""
    analysis = {
        'security_level_correlation': {},
        'cross_family': {},
        'anomalies': [],
        'findings': [],
    }

    # Group by family
    by_family = {}
    for r in results:
        by_family.setdefault(r['family'], []).append(r)

    # 1. Security level correlation: does Crypto-CASI decrease with higher level?
    for fam, entries in by_family.items():
        entries_sorted = sorted(entries, key=lambda x: x['level'])
        crypto_scores = [e['casi_crypto'] for e in entries_sorted]
        full_scores = [e['casi_full'] for e in entries_sorted]
        levels = [e['level'] for e in entries_sorted]

        # Check monotonicity on crypto-CASI
        decreasing = all(crypto_scores[i] >= crypto_scores[i+1] for i in range(len(crypto_scores)-1))
        increasing = all(crypto_scores[i] <= crypto_scores[i+1] for i in range(len(crypto_scores)-1))

        analysis['security_level_correlation'][fam] = {
            'levels': levels,
            'crypto_scores': [round(s, 4) for s in crypto_scores],
            'full_scores': [round(s, 4) for s in full_scores],
            'trend': 'decreasing' if decreasing else 'increasing' if increasing else 'non-monotonic',
            'crypto_range': round(max(crypto_scores) - min(crypto_scores), 4),
        }

        if decreasing and max(crypto_scores) - min(crypto_scores) > 0.1:
            analysis['findings'].append(
                f"{PQC_FAMILIES[fam]['name']}: Crypto-CASI decreases with security level "
                f"({crypto_scores[0]:.4f} → {crypto_scores[-1]:.4f})"
            )

    # 2. Cross-family comparison: KEM vs Signature vs Code-based (using crypto-CASI)
    kem_scores = [r['casi_crypto'] for r in results if r['family'] == 'mlkem']
    sig_scores = [r['casi_crypto'] for r in results if r['family'] == 'mldsa']
    code_scores = [r['casi_crypto'] for r in results if r['family'] == 'hqc']

    if kem_scores and code_scores:
        lattice_kem_avg = np.mean(kem_scores)
        code_avg = np.mean(code_scores)
        lattice_sig_avg = np.mean(sig_scores) if sig_scores else 0
        analysis['cross_family'] = {
            'lattice_kem_avg': round(float(lattice_kem_avg), 4),
            'lattice_sig_avg': round(float(lattice_sig_avg), 4),
            'code_based_avg': round(float(code_avg), 4),
        }

        if abs(lattice_kem_avg - code_avg) > 0.3:
            analysis['findings'].append(
                f"Crypto-CASI separates ML-KEM ({lattice_kem_avg:.4f}) from "
                f"HQC ({code_avg:.4f}) — compression artifacts in lattice KEM"
            )

    # 3. Per-strategy anomalies: which strategies fire on PQC?
    for r in results:
        for s, d in r['strategies'].items():
            if d['significant']:
                analysis['anomalies'].append({
                    'config': r['label'],
                    'strategy': s,
                    'ratio': d['ratio'],
                    'signal': d['signal'],
                    'baseline': d['baseline'],
                })

    # 4. Strategy profile comparison across families
    for fam, entries in by_family.items():
        # Average strategy profile for this family
        profile = {}
        for s in STRATEGY_NAMES:
            profile[s] = round(float(np.mean([e['strategies'][s]['ratio'] for e in entries])), 4)

        analysis[f'{fam}_profile'] = profile

    return analysis


def _print_comparison_table(results, classical, analysis):
    """Print formatted comparison table."""
    print(f"\n{'='*60}")
    print(f"  RESULTS")
    print(f"{'='*60}")

    # Main table — Crypto-CASI is the primary metric for PQC
    print(f"\n  {'Config':<22s} {'Type':<5s} {'NIST':>4s} {'Crypto-CASI':>12s} {'Impl-CASI':>10s} {'Verdict':<14s}")
    print(f"  {'─'*20}  {'─'*5} {'─'*4} {'─'*12} {'─'*10} {'─'*14}")

    for r in results:
        print(f"  {r['label']:<22s} {r['pqc_type']:<5s} {r['nist_level']:>4d} "
              f"{r['casi_crypto']:>12.4f} {r['casi_full']:>10.4f} {r['verdict']:<14s}")

    # Classical comparison
    print(f"\n  Classical reference:")
    for name, score in classical.items():
        print(f"    {name:<16s}  CASI = {score:.4f}")

    # Security level correlation (Crypto-CASI)
    if analysis['security_level_correlation']:
        print(f"\n  Security Level Correlation (Crypto-CASI):")
        for fam, corr in analysis['security_level_correlation'].items():
            print(f"    {PQC_FAMILIES[fam]['name']:20s}  {corr['trend']:<15s}  "
                  f"range={corr['crypto_range']:.4f}  "
                  f"[{' → '.join(f'{s:.4f}' for s in corr['crypto_scores'])}]")

    # Cross-family
    if analysis.get('cross_family'):
        cf = analysis['cross_family']
        print(f"\n  Cross-Family Crypto-CASI:")
        print(f"    Lattice KEM avg:  {cf['lattice_kem_avg']:.4f}")
        print(f"    Lattice Sig avg:  {cf['lattice_sig_avg']:.4f}")
        print(f"    Code-based avg:   {cf['code_based_avg']:.4f}")

    # Anomalies
    if analysis['anomalies']:
        print(f"\n  Strategy Anomalies ({len(analysis['anomalies'])} detected):")
        for a in analysis['anomalies'][:10]:
            print(f"    {a['config']:<20s}  {a['strategy']:<20s}  ratio={a['ratio']:.2f}")

    # Key findings
    if analysis['findings']:
        print(f"\n  Key Findings:")
        for i, f in enumerate(analysis['findings'], 1):
            print(f"    {i}. {f}")

    print()


# ═══════════════════════════════════════════════════════════════
# PQC KNOWLEDGE GRAPH
# ═══════════════════════════════════════════════════════════════

def pqc_causal(output_path, n_samples=5000, verbose=True):
    """Generate .causal knowledge graph from PQC analysis.

    Requires dotcausal>=0.3.1.
    """
    from dotcausal import CausalWriter

    if verbose:
        print(f"\n  Generating PQC Knowledge Graph...")

    # Run full comparison first
    report = pqc_compare(n_samples=n_samples, verbose=verbose)

    # Build knowledge graph
    writer = CausalWriter(api_id="live-casi-pqc")

    triplet_count = 0

    # 1. Observation triplets — raw CASI measurements
    for r in report['configs']:
        writer.add_triplet(
            trigger=r['label'],
            mechanism="has_casi_score",
            outcome=f"{r['casi_full']:.4f}",
            confidence=0.99,
            source="live-casi-pqc",
            domain="pqc_measurement",
            evidence=f"Measured on {r['n_samples']} samples",
        )
        triplet_count += 1

        writer.add_triplet(
            trigger=r['label'],
            mechanism="has_crypto_casi",
            outcome=f"{r['casi_crypto']:.4f}",
            confidence=0.99,
            source="live-casi-pqc",
            domain="pqc_measurement",
            evidence=f"4 crypto strategies only",
        )
        triplet_count += 1

        writer.add_triplet(
            trigger=r['label'],
            mechanism="classified_as",
            outcome=r['verdict'],
            confidence=0.95,
            source="live-casi-pqc",
            domain="pqc_classification",
        )
        triplet_count += 1

        # Strategy-level triplets
        for s, d in r['strategies'].items():
            if d['significant']:
                writer.add_triplet(
                    trigger=r['label'],
                    mechanism=f"shows_significant_{s}",
                    outcome=f"ratio={d['ratio']:.2f}",
                    confidence=0.9,
                    source="live-casi-pqc",
                    domain="pqc_signal",
                    evidence=f"signal={d['signal']}, baseline={d['baseline']}",
                )
                triplet_count += 1

    # 2. Architecture triplets
    for fam_id, fam in PQC_FAMILIES.items():
        writer.add_triplet(
            trigger=fam['name'],
            mechanism="uses_paradigm",
            outcome=fam['paradigm'],
            confidence=1.0,
            source="nist",
            domain="pqc_architecture",
        )
        triplet_count += 1

        writer.add_triplet(
            trigger=fam['name'],
            mechanism="standardized_as",
            outcome=fam['standard'],
            confidence=1.0,
            source="nist",
            domain="pqc_standards",
        )
        triplet_count += 1

        for op in fam['properties']['operations']:
            writer.add_triplet(
                trigger=fam['name'],
                mechanism="relies_on",
                outcome=op,
                confidence=1.0,
                source="specification",
                domain="pqc_architecture",
            )
            triplet_count += 1

    # 3. Comparison triplets — security level correlations
    analysis = report['analysis']
    for fam_id, corr in analysis['security_level_correlation'].items():
        fam = PQC_FAMILIES[fam_id]
        if corr['score_range'] > 0.01:
            writer.add_triplet(
                trigger=fam['name'],
                mechanism=f"casi_{corr['trend']}_with_security_level",
                outcome=f"range={corr['score_range']:.4f}",
                confidence=0.85,
                source="live-casi-pqc",
                domain="pqc_correlation",
                evidence=f"Levels {corr['levels']}: {corr['scores']}",
            )
            triplet_count += 1

    # 4. Cross-family triplets
    if analysis.get('cross_family', {}).get('distinguishable'):
        cf = analysis['cross_family']
        writer.add_triplet(
            trigger="Lattice-based PQC",
            mechanism="distinguishable_from",
            outcome="Code-based PQC",
            confidence=0.8,
            source="live-casi-pqc",
            domain="pqc_paradigm",
            evidence=f"Lattice={cf['lattice_avg']:.4f}, Code={cf['code_based_avg']:.4f}",
        )
        triplet_count += 1

    # 5. Classical comparison triplets
    for cipher_name, score in report['classical'].items():
        for r in report['configs']:
            diff = abs(r['casi_full'] - score)
            if diff > 0.05:
                direction = "higher" if r['casi_full'] > score else "lower"
                writer.add_triplet(
                    trigger=r['label'],
                    mechanism=f"casi_{direction}_than",
                    outcome=cipher_name.upper(),
                    confidence=0.85,
                    source="live-casi-pqc",
                    domain="pqc_vs_classical",
                    evidence=f"{r['casi_full']:.4f} vs {score:.4f}",
                )
                triplet_count += 1

    # 6. Anomaly triplets
    for a in analysis['anomalies']:
        writer.add_triplet(
            trigger=a['config'],
            mechanism=f"anomaly_in_{a['strategy']}",
            outcome=f"ratio={a['ratio']:.2f}",
            confidence=0.75,
            source="live-casi-pqc",
            domain="pqc_anomaly",
        )
        triplet_count += 1

    # Write .causal file
    stats = writer.save(output_path)

    if verbose:
        explicit = triplet_count
        total = stats.get('total_triplets', stats.get('triplet_count', explicit))
        inferred = total - explicit if total > explicit else 0
        amp = (total / explicit * 100) if explicit > 0 else 0
        print(f"\n  Knowledge Graph: {output_path}")
        print(f"    Explicit triplets: {explicit}")
        print(f"    After inference:   {total}")
        if inferred > 0:
            print(f"    Amplification:     {amp:.1f}%")
        print(f"    File size:         {os.path.getsize(output_path):,} bytes")

    return {
        'output_path': output_path,
        'explicit_triplets': triplet_count,
        'stats': stats,
        'report': report,
    }


# ═══════════════════════════════════════════════════════════════
# ML-KEM COMPRESSION ISOLATION EXPERIMENT
# ═══════════════════════════════════════════════════════════════

# ML-KEM ciphertext = (u, v) where:
#   u = Compress_du(A^T * r + e1)  — compressed polynomial vector
#   v = Compress_dv(b^T * r + e2 + msg) — compressed polynomial
#
# ML-KEM-512:  k=2, d_u=10, u_bytes=640,  v_bytes=128, ct=768
# ML-KEM-768:  k=3, d_u=10, u_bytes=960,  v_bytes=128, ct=1088
# ML-KEM-1024: k=4, d_u=11, u_bytes=1408, v_bytes=160, ct=1568

MLKEM_PARAMS = {
    512:  {'k': 2, 'd_u': 10, 'u_bytes': 640,  'v_bytes': 128},
    768:  {'k': 3, 'd_u': 10, 'u_bytes': 960,  'v_bytes': 128},
    1024: {'k': 4, 'd_u': 11, 'u_bytes': 1408, 'v_bytes': 160},
}


def _decode_10bit(ct_bytes, n_coeffs):
    """Parse 10-bit packed coefficients. 5 bytes = 4 coefficients."""
    coeffs = []
    for i in range(0, len(ct_bytes), 5):
        if i + 4 >= len(ct_bytes) or len(coeffs) >= n_coeffs:
            break
        b = ct_bytes[i:i+5]
        coeffs.append(b[0] | ((b[1] & 0x03) << 8))
        coeffs.append((b[1] >> 2) | ((b[2] & 0x0F) << 6))
        coeffs.append((b[2] >> 4) | ((b[3] & 0x3F) << 4))
        coeffs.append((b[3] >> 6) | (b[4] << 2))
    return coeffs[:n_coeffs]


def _decode_11bit(ct_bytes, n_coeffs):
    """Parse 11-bit packed coefficients."""
    coeffs = []
    buf = 0
    bits = 0
    for byte in ct_bytes:
        buf |= byte << bits
        bits += 8
        while bits >= 11 and len(coeffs) < n_coeffs:
            coeffs.append(buf & 0x7FF)
            buf >>= 11
            bits -= 11
    return coeffs[:n_coeffs]


def mlkem_isolation(level=512, n_samples=500000, key_size=32, verbose=True):
    """Compression isolation experiment for ML-KEM.

    Separates the CASI signal into two components:
    1. Coefficient distribution (LWE noise non-uniformity)
    2. Bit-packing artifacts (10/11-bit → byte alignment)

    Generates four streams:
    A) Original bit-packed ciphertext (what you'd see in the wild)
    B) Same LWE coefficients, uniform 16-bit encoding + random padding
    C) Uniform random coefficients, same 16-bit encoding + random padding
    D) Pure random bytes (baseline)

    If B >> C ≈ D → coefficient distribution is the cause (LWE noise)
    If A >> B → bit-packing adds signal
    If A < B → bit-packing masks signal
    """
    params = MLKEM_PARAMS[level]
    fam = PQC_FAMILIES['mlkem']
    lev = fam['levels'][level]
    mod = _import_pqc_module(lev['module'])

    d_u = params['d_u']
    u_bytes = params['u_bytes']
    n_coeffs_per_ct = params['k'] * 256
    target_bytes = n_samples * key_size
    max_val = (1 << d_u) - 1

    if verbose:
        print(f"\n  ML-KEM-{level} Compression Isolation (d_u={d_u}, {n_samples:,} samples)")
        print(f"  {'='*60}")

    # Generate ciphertexts and extract coefficients
    original_chunks = []
    coefficients_all = []
    total = 0
    while total < target_bytes:
        pk, sk = mod.generate_keypair()
        ct, ss = mod.encrypt(pk)
        original_chunks.append(ct[:u_bytes])
        if d_u == 10:
            coefficients_all.extend(_decode_10bit(ct[:u_bytes], n_coeffs_per_ct))
        else:
            coefficients_all.extend(_decode_11bit(ct[:u_bytes], n_coeffs_per_ct))
        total += u_bytes

    # Stream A: Original encoding
    orig_bytes = b''.join(original_chunks)[:target_bytes]
    keys_a = np.frombuffer(orig_bytes, dtype=np.uint8).reshape(-1, key_size)

    # Stream B: LWE coefficients + randomized upper bits
    n_needed = target_bytes // 2
    coeff_arr = np.array(coefficients_all[:n_needed], dtype=np.uint16)
    rand_pad = np.frombuffer(os.urandom(n_needed * 2), dtype=np.uint16)[:n_needed]
    mask_low = (1 << d_u) - 1
    mask_high = ~mask_low & 0xFFFF
    combined_b = (coeff_arr & mask_low) | (rand_pad & mask_high)
    keys_b = np.frombuffer(combined_b.tobytes()[:target_bytes], dtype=np.uint8).reshape(-1, key_size)

    # Stream C: Uniform random coefficients + same format
    rand_coeffs = np.random.randint(0, max_val + 1, size=n_needed, dtype=np.uint16)
    rand_pad2 = np.frombuffer(os.urandom(n_needed * 2), dtype=np.uint16)[:n_needed]
    combined_c = (rand_coeffs & mask_low) | (rand_pad2 & mask_high)
    keys_c = np.frombuffer(combined_c.tobytes()[:target_bytes], dtype=np.uint8).reshape(-1, key_size)

    # Stream D: Pure random
    keys_d = np.frombuffer(os.urandom(target_bytes), dtype=np.uint8).reshape(-1, key_size)

    # Compute Crypto-CASI
    sig_a = compute_crypto_signal(keys_a)
    sig_b = compute_crypto_signal(keys_b)
    sig_c = compute_crypto_signal(keys_c)
    sig_d = compute_crypto_signal(keys_d)

    base = max(sig_d['total'], 1)
    casi_a = sig_a['total'] / base
    casi_b = sig_b['total'] / base
    casi_c = sig_c['total'] / base
    casi_d = 1.0

    # Determine causality
    packing_effect = casi_a - casi_b  # positive = packing adds signal, negative = packing masks
    dist_effect = casi_b - casi_c     # positive = LWE distribution causes signal

    if verbose:
        print(f"\n  Stream A — Original {d_u}-bit packing:       Crypto-CASI = {casi_a:.4f}")
        print(f"  Stream B — LWE coeffs, 16-bit + rand pad:  Crypto-CASI = {casi_b:.4f}")
        print(f"  Stream C — Uniform coeffs, same format:    Crypto-CASI = {casi_c:.4f}")
        print(f"  Stream D — Pure random (baseline):         Crypto-CASI = {casi_d:.4f}")
        print()
        print(f"  Packing effect (A-B):       {packing_effect:+.4f}  {'(packing ADDS signal)' if packing_effect > 0.5 else '(packing MASKS signal)' if packing_effect < -0.5 else '(minimal)'}")
        print(f"  Distribution effect (B-C):  {dist_effect:+.4f}  {'(LWE noise is non-uniform)' if dist_effect > 1.0 else '(coefficients are near-uniform)' if dist_effect < 0.5 else '(weak bias)'}")
        print()

        # Per-strategy
        print(f"  {'Strategy':<18s} {'Original':>9s} {'LWE+pad':>9s} {'Uni+pad':>9s} {'Random':>9s}")
        print(f"  {'─'*48}")
        for s in CRYPTO_STRATEGY_NAMES:
            print(f"  {s:<18s} {sig_a[s]:>9d} {sig_b[s]:>9d} {sig_c[s]:>9d} {sig_d[s]:>9d}")

    return {
        'level': level,
        'd_u': d_u,
        'n_samples': n_samples,
        'casi_original': round(casi_a, 4),
        'casi_lwe_uniform_encoding': round(casi_b, 4),
        'casi_uniform_coefficients': round(casi_c, 4),
        'casi_random': round(casi_d, 4),
        'packing_effect': round(packing_effect, 4),
        'distribution_effect': round(dist_effect, 4),
        'conclusion': 'LWE_DISTRIBUTION' if dist_effect > 1.0 and packing_effect < 0 else
                      'BIT_PACKING' if packing_effect > 1.0 and dist_effect < 0.5 else
                      'BOTH' if dist_effect > 0.5 and packing_effect > 0.5 else
                      'NONE',
    }


def run_mlkem_isolation(args):
    """CLI handler for --pqc-isolate."""
    n = getattr(args, 'keys', 500000) or 500000

    results = {}
    for level in [512, 768, 1024]:
        r = mlkem_isolation(level=level, n_samples=n, verbose=True)
        results[level] = r
        print()

    # Summary
    print(f"\n  {'='*60}")
    print(f"  ISOLATION SUMMARY")
    print(f"  {'='*60}")
    print(f"  {'Config':<16s} {'Original':>9s} {'LWE+pad':>9s} {'Uni+pad':>9s} {'Pack Δ':>9s} {'Dist Δ':>9s} {'Cause':>16s}")
    print(f"  {'─'*70}")
    for lev in [512, 768, 1024]:
        r = results[lev]
        print(f"  ML-KEM-{lev:<7d} {r['casi_original']:>9.4f} {r['casi_lwe_uniform_encoding']:>9.4f} "
              f"{r['casi_uniform_coefficients']:>9.4f} {r['packing_effect']:>+9.4f} "
              f"{r['distribution_effect']:>+9.4f} {r['conclusion']:>16s}")

    if getattr(args, 'json', False):
        print(json.dumps(results, indent=2, default=lambda x: float(x) if hasattr(x, 'item') else str(x)))


# ═══════════════════════════════════════════════════════════════
# CLI HANDLERS
# ═══════════════════════════════════════════════════════════════

def run_pqc(args):
    """CLI handler for --pqc."""
    families = None
    cipher_arg = getattr(args, 'cipher', 'chacha')
    if cipher_arg and cipher_arg not in ('chacha', 'all'):
        # Map cipher arg to PQC family
        mapping = {
            'mlkem': ['mlkem'], 'kyber': ['mlkem'],
            'mldsa': ['mldsa'], 'dilithium': ['mldsa'],
            'hqc': ['hqc'],
        }
        families = mapping.get(cipher_arg)
        if not families:
            print(f"  Unknown PQC family: {cipher_arg}")
            print(f"  Available: mlkem, mldsa, hqc (or 'all')")
            sys.exit(1)

    n_samples = getattr(args, 'keys', 5000) or 5000
    report = pqc_compare(n_samples=n_samples, families=families, verbose=not getattr(args, 'json', False))

    if getattr(args, 'json', False):
        # Clean numpy types for JSON
        print(json.dumps(report, indent=2, default=lambda x: float(x) if hasattr(x, 'item') else str(x)))


def run_pqc_causal(args):
    """CLI handler for --pqc-causal."""
    output_path = args.pqc_causal
    n_samples = getattr(args, 'keys', 5000) or 5000
    pqc_causal(output_path, n_samples=n_samples, verbose=True)
