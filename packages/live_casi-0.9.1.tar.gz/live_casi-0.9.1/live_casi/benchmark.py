#!/usr/bin/env python3
"""
CASI Frontier Benchmark — Phase 3 of live-casi v0.2.0

Compare CASI detection frontiers against published academic results.

Academic Frontiers:
    Speck 32/64:     R7-8     (Gohr 2019, neural distinguisher)
    ChaCha20:        R3-4     (Aumasson 2008, differential)
    Salsa20:         R3       (Aumasson 2008, differential)
    AES-128:         R5-6     (impossible differential)
    Blowfish:        R4       (Vaudenay 1996, differential)
    3DES:            R6-8     (Biham & Shamir, linear/differential)
    RC4:             KSA-64   (Mantin-Shamir 2001, bias)
    Camellia-128:    R6       (Wu et al. 2012, impossible differential)

Usage:
    from live_casi.benchmark import run_frontier_benchmark
    results = run_frontier_benchmark()
"""

import os
import time
import numpy as np

from .core import (
    compute_signal, compute_crypto_signal,
    STRATEGY_NAMES, CRYPTO_STRATEGY_NAMES, IMPL_STRATEGY_NAMES,
    casi_verdict, casi_color,
    BOLD, RESET, DIM, GREEN, YELLOW, RED, CYAN,
)
from .ciphers import CIPHERS


# Known academic frontiers (source papers)
ACADEMIC_FRONTIERS = {
    'chacha': {
        'frontier': 'R3-4',
        'frontier_mid': 3.5,
        'method': 'Differential (Aumasson 2008)',
        'source': 'FSE 2008',
    },
    'salsa': {
        'frontier': 'R3',
        'frontier_mid': 3,
        'method': 'Differential (Aumasson 2008)',
        'source': 'FSE 2008',
    },
    'aes': {
        'frontier': 'R5-6',
        'frontier_mid': 5.5,
        'method': 'Impossible differential',
        'source': 'Various',
    },
    'speck': {
        'frontier': 'R7-8',
        'frontier_mid': 7.5,
        'method': 'Neural distinguisher (Gohr 2019)',
        'source': 'CRYPTO 2019',
    },
    'blowfish': {
        'frontier': 'R4',
        'frontier_mid': 4,
        'method': 'Differential (Vaudenay 1996)',
        'source': 'Vaudenay 1996',
    },
    'tdes': {
        'frontier': 'R6-8',
        'frontier_mid': 7,
        'method': 'Linear/differential',
        'source': 'Biham & Shamir',
    },
    'rc4': {
        'frontier': 'KSA-64',
        'frontier_mid': 64,
        'method': 'KSA bias (Mantin-Shamir)',
        'source': 'EUROCRYPT 2001',
    },
    'camellia': {
        'frontier': 'R6',
        'frontier_mid': 6,
        'method': 'Impossible differential',
        'source': 'Wu et al. 2012',
    },
}


def compute_casi_at_rounds(cipher_name, rounds, n_keys=10000, key_size=32, seed=42):
    """Compute both crypto-CASI and full-CASI for a cipher at specific round count.

    Returns:
        crypto_casi: float — CASI using only 4 cryptanalytic strategies (paper-compatible)
        full_casi: float — CASI using all 12 strategies (implementation detection)
        crypto_signal: dict — per-strategy signal counts (4 strategies)
        full_signal: dict — per-strategy signal counts (12 strategies)
    """
    info = CIPHERS[cipher_name]
    gen = info['generator']

    data = gen(n_keys, rounds=rounds, seed=seed)
    keys = np.frombuffer(data, dtype=np.uint8).reshape(-1, key_size)

    # Compute both signal types
    crypto_signal = compute_crypto_signal(keys)
    full_signal = compute_signal(keys)

    # Baseline (same for both)
    baseline_keys = np.frombuffer(
        os.urandom(n_keys * key_size), dtype=np.uint8
    ).reshape(-1, key_size)
    crypto_baseline = compute_crypto_signal(baseline_keys)
    full_baseline = compute_signal(baseline_keys)

    crypto_casi = crypto_signal['total'] / max(crypto_baseline['total'], 1)
    full_casi = full_signal['total'] / max(full_baseline['total'], 1)

    return crypto_casi, full_casi, crypto_signal, full_signal


def find_frontier(cipher_name, n_keys=10000, key_size=32, seeds=None):
    """Find CASI frontiers for a cipher.

    Computes TWO frontiers:
        - crypto_frontier: using only 4 cryptanalytic strategies (paper-compatible,
          comparable to Gohr/Aumasson academic results)
        - impl_frontier: using all 12 strategies (includes implementation-bug
          detectors — NOT comparable to academic attack frontiers)

    The crypto_frontier is what should be compared to academic SOTA.
    The impl_frontier is always <= crypto_frontier in round count because
    implementation strategies fire at lower rounds trivially.

    Args:
        cipher_name: key in CIPHERS dict
        n_keys: number of keys per test
        key_size: key size in bytes
        seeds: list of seeds for multi-run (default [42])

    Returns:
        dict with both frontiers + per-round data
    """
    if seeds is None:
        seeds = [42]

    info = CIPHERS[cipher_name]
    full_rounds = info['full_rounds']
    is_slow = info.get('slow', False)

    if is_slow:
        n_keys = min(n_keys, 1000)

    # Test every round from 1 to full
    round_data = []
    crypto_frontier_round = 0
    impl_frontier_round = 0

    for r in range(1, full_rounds + 1):
        crypto_values = []
        full_values = []
        for seed in seeds:
            try:
                crypto_casi, full_casi, _, _ = compute_casi_at_rounds(
                    cipher_name, r, n_keys=n_keys, key_size=key_size, seed=seed)
                crypto_values.append(crypto_casi)
                full_values.append(full_casi)
            except Exception:
                crypto_values.append(float('nan'))
                full_values.append(float('nan'))

        crypto_mean = np.nanmean(crypto_values)
        crypto_std = np.nanstd(crypto_values) if len(crypto_values) > 1 else 0
        full_mean = np.nanmean(full_values)
        full_std = np.nanstd(full_values) if len(full_values) > 1 else 0

        round_data.append({
            'rounds': r,
            'crypto_casi_mean': float(crypto_mean),
            'crypto_casi_std': float(crypto_std),
            'full_casi_mean': float(full_mean),
            'full_casi_std': float(full_std),
            'crypto_verdict': casi_verdict(crypto_mean),
            'full_verdict': casi_verdict(full_mean),
        })

        # Crypto frontier: last round where crypto-CASI > 2.0
        if crypto_mean > 2.0:
            crypto_frontier_round = r
        # Impl frontier: last round where full-CASI > 2.0
        if full_mean > 2.0:
            impl_frontier_round = r

    return {
        'cipher': cipher_name,
        'cipher_name': info['name'],
        'family': info['family'],
        'full_rounds': full_rounds,
        'crypto_frontier': crypto_frontier_round,
        'impl_frontier': impl_frontier_round,
        'round_data': round_data,
    }


def run_frontier_benchmark(cipher_filter=None, n_seeds=1, n_keys=10000):
    """Run the full frontier benchmark.

    Args:
        cipher_filter: specific cipher to benchmark (or None for all)
        n_seeds: number of seeds for statistical confidence (default 1 for fast)
        n_keys: keys per test

    Returns:
        list of benchmark results
    """
    seeds = list(range(42, 42 + n_seeds))

    cipher_order = ['chacha', 'salsa', 'aes', 'speck', 'blowfish', 'tdes', 'rc4', 'camellia']
    if cipher_filter:
        cipher_order = [c for c in cipher_order if c == cipher_filter]

    results = []
    for cname in cipher_order:
        result = find_frontier(cname, n_keys=n_keys, seeds=seeds)

        # Add academic comparison — use CRYPTO frontier (4 strategies), NOT full
        if cname in ACADEMIC_FRONTIERS:
            acad = ACADEMIC_FRONTIERS[cname]
            result['academic_frontier'] = acad['frontier']
            result['academic_method'] = acad['method']
            result['academic_source'] = acad['source']
            result['academic_frontier_mid'] = acad['frontier_mid']

            # Compare crypto frontier (paper-compatible) against academic SOTA
            crypto_f = result['crypto_frontier']
            acad_f = acad['frontier_mid']
            gap = crypto_f - acad_f
            result['gap'] = gap
            if abs(gap) <= 1:
                result['match'] = 'MATCH'
            elif gap < -1:
                result['match'] = 'CASI weaker'
            else:
                result['match'] = 'CASI stronger'
        else:
            result['academic_frontier'] = 'N/A'
            result['academic_method'] = 'N/A'
            result['gap'] = None
            result['match'] = 'N/A'

        results.append(result)

    return results


# ═══════════════════════════════════════════════════════════════
# CLI: --benchmark
# ═══════════════════════════════════════════════════════════════

def run_benchmark(args):
    """CLI handler for --benchmark mode."""
    import json as json_mod

    quiet = getattr(args, 'quiet', False)
    json_out = getattr(args, 'json', False)
    cipher_filter = None

    # Check if user specified a specific cipher
    if hasattr(args, 'cipher') and args.cipher in CIPHERS and '--cipher' in __import__('sys').argv:
        cipher_filter = args.cipher

    # Statistical confidence: --benchmark-seeds N
    n_seeds = getattr(args, 'benchmark_seeds', 1)
    n_keys = 10000

    t0 = time.time()
    results = run_frontier_benchmark(
        cipher_filter=cipher_filter,
        n_seeds=n_seeds,
        n_keys=n_keys,
    )
    dt = time.time() - t0

    if json_out:
        out = {
            'benchmark': 'CASI Frontier (Crypto vs Implementation)',
            'note': 'crypto_frontier uses 4 cryptanalytic strategies (paper-compatible). '
                    'impl_frontier uses all 12 strategies (includes implementation-bug detectors).',
            'seeds': n_seeds,
            'keys_per_test': n_keys,
            'results': [],
            'elapsed_seconds': round(dt, 2),
        }
        for r in results:
            entry = {
                'cipher': r['cipher_name'],
                'family': r['family'],
                'full_rounds': r['full_rounds'],
                'crypto_frontier': r['crypto_frontier'],
                'impl_frontier': r['impl_frontier'],
                'academic_frontier': r['academic_frontier'],
                'gap_vs_academic': r['gap'],
                'match': r['match'],
                'round_data': r['round_data'],
            }
            out['results'].append(entry)
        print(json_mod.dumps(out, indent=2))
        return

    if quiet:
        for r in results:
            cf = r['crypto_frontier']
            print(f'{r["cipher_name"]} crypto:R{cf} '
                  f'impl:R{r["impl_frontier"]} '
                  f'SOTA:{r["academic_frontier"]} {r["match"]}')
        return

    # Full comparison table
    print()
    print(f'{BOLD}{CYAN}live-casi Frontier Benchmark{RESET}')
    print(f'{DIM}Crypto-CASI = 4 cryptanalytic strategies (paper-compatible){RESET}')
    print(f'{DIM}Impl-CASI   = all 12 strategies (includes implementation-bug detectors){RESET}')
    print(f'{DIM}{"═" * 88}{RESET}')

    hdr = (f'  {"Cipher":<14s}  {"Crypto":>8s}  {"Impl":>8s}  '
           f'{"Academic SOTA":>14s}  {"Gap":>5s}  {"Match?":<14s}')
    print(hdr)
    print(f'  {"─"*14}  {"─"*8}  {"─"*8}  {"─"*14}  {"─"*5}  {"─"*14}')

    for r in results:
        crypto_f = r['crypto_frontier']
        impl_f = r['impl_frontier']
        acad_f = r['academic_frontier']
        gap = r.get('gap')
        match = r['match']

        # Format frontiers
        if r['cipher'] == 'rc4':
            crypto_str = f'KSA-{crypto_f}'
            impl_str = f'KSA-{impl_f}'
        else:
            crypto_str = f'R{crypto_f}'
            impl_str = f'R{impl_f}'

        # Color based on match
        if match == 'MATCH':
            mc = GREEN
        elif 'weaker' in match:
            mc = DIM
        elif 'stronger' in match:
            mc = CYAN
        else:
            mc = DIM

        gap_str = f'{int(gap):+d}' if gap is not None else 'N/A'

        print(f'  {r["cipher_name"]:<14s}  {BOLD}{crypto_str:>8s}{RESET}  '
              f'{DIM}{impl_str:>8s}{RESET}  '
              f'{acad_f:>14s}  {gap_str:>5s}  {mc}{match:<14s}{RESET}')

    # Per-cipher detailed round progression (show BOTH crypto and full)
    print()
    for r in results:
        print(f'{DIM}{"─" * 88}{RESET}')
        print(f'  {BOLD}{r["cipher_name"]}{RESET} ({r["family"]}, {r["full_rounds"]} full rounds)')

        if r.get('academic_method'):
            print(f'  {DIM}Academic: {r["academic_method"]} [{r.get("academic_source", "")}]{RESET}')

        # Crypto-CASI progression
        print(f'  {BOLD}Crypto-CASI{RESET} (4 strategies):')
        parts = []
        for rd in r['round_data']:
            casi = rd['crypto_casi_mean']
            color = casi_color(casi)
            rnd = rd['rounds']
            label = f'R{rnd}' if r['cipher'] != 'rc4' else f'K{rnd}'
            parts.append(f'{color}{label}={casi:.1f}{RESET}')
        line_parts = []
        for i, p in enumerate(parts):
            line_parts.append(p)
            if (i + 1) % 6 == 0 or i == len(parts) - 1:
                print(f'    {" | ".join(line_parts)}')
                line_parts = []

        # Full-CASI progression (only if different from crypto)
        if r['impl_frontier'] != r['crypto_frontier']:
            print(f'  {DIM}Impl-CASI (12 strategies):{RESET}')
            parts = []
            for rd in r['round_data']:
                casi = rd['full_casi_mean']
                color = casi_color(casi)
                rnd = rd['rounds']
                label = f'R{rnd}' if r['cipher'] != 'rc4' else f'K{rnd}'
                parts.append(f'{color}{label}={casi:.1f}{RESET}')
            line_parts = []
            for i, p in enumerate(parts):
                line_parts.append(p)
                if (i + 1) % 6 == 0 or i == len(parts) - 1:
                    print(f'    {" | ".join(line_parts)}')
                    line_parts = []

    print(f'\n  {DIM}Elapsed: {dt:.1f}s (seeds={n_seeds}, keys/test={n_keys:,}){RESET}')

    # Legend
    print(f'\n  {DIM}Legend:{RESET}')
    print(f'  {DIM}  Crypto-CASI > 2.0 = structural weakness detectable (comparable to academic attacks){RESET}')
    print(f'  {DIM}  Impl-CASI > 2.0   = distributional non-randomness (trivial at low rounds, NOT cryptanalysis){RESET}')
    print(f'  {DIM}  Gap = crypto frontier − academic frontier (negative = CASI detects fewer rounds than SOTA){RESET}')
    print()
