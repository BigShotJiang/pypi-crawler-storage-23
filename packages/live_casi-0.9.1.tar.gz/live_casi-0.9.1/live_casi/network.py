#!/usr/bin/env python3
"""
live-casi Network Analysis — pcap + live monitor

Analyze network traffic for encryption quality. Each connection gets a CASI
score: SECURE (~1.0), WEAK (2-10), or PLAINTEXT (>10).

Requires: pip install live-casi[network]  (scapy)

Usage:
    live-casi --pcap capture.pcap           # Offline analysis
    sudo live-casi --monitor                # Live capture
    sudo live-casi --monitor --interface en0 --duration 60
"""

import os
import sys
import time
import struct
import socket
from collections import defaultdict

import numpy as np

from .core import (
    compute_signal, casi_verdict, casi_color,
    BOLD, RESET, DIM, GREEN, YELLOW, RED, CYAN,
)


# ═══════════════════════════════════════════════════════════════
# TLS constants + cipher suite names
# ═══════════════════════════════════════════════════════════════

TLS_CONTENT_TYPES = {
    0x14: 'ChangeCipherSpec',
    0x15: 'Alert',
    0x16: 'Handshake',
    0x17: 'ApplicationData',
}

TLS_VERSIONS = {
    (3, 0): 'SSL3.0',
    (3, 1): 'TLS1.0',
    (3, 2): 'TLS1.1',
    (3, 3): 'TLS1.2',
    (3, 4): 'TLS1.3',
}

TLS_HANDSHAKE_TYPES = {
    1: 'ClientHello',
    2: 'ServerHello',
    11: 'Certificate',
    14: 'ServerHelloDone',
    16: 'ClientKeyExchange',
}

# Common TLS cipher suites (2-byte codes -> human name)
CIPHER_SUITES = {
    0x1301: 'TLS_AES_128_GCM_SHA256',
    0x1302: 'TLS_AES_256_GCM_SHA384',
    0x1303: 'TLS_CHACHA20_POLY1305_SHA256',
    0x1304: 'TLS_AES_128_CCM_SHA256',
    0xc02c: 'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384',
    0xc02b: 'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256',
    0xc030: 'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
    0xc02f: 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
    0xcca9: 'TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256',
    0xcca8: 'TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256',
    0xc013: 'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA',
    0xc014: 'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA',
    0x002f: 'TLS_RSA_WITH_AES_128_CBC_SHA',
    0x0035: 'TLS_RSA_WITH_AES_256_CBC_SHA',
    0x009c: 'TLS_RSA_WITH_AES_128_GCM_SHA256',
    0x009d: 'TLS_RSA_WITH_AES_256_GCM_SHA384',
    0x0004: 'TLS_RSA_WITH_RC4_128_MD5',
    0x0005: 'TLS_RSA_WITH_RC4_128_SHA',
    0x000a: 'TLS_RSA_WITH_3DES_EDE_CBC_SHA',
}

# Cipher suites considered weak
WEAK_SUITES = {0x0004, 0x0005, 0x000a}  # RC4, 3DES

HTTP_METHODS = {b'GET', b'POST', b'PUT', b'DELETE', b'HEAD', b'OPTIONS', b'PATCH', b'CONNECT'}


# ═══════════════════════════════════════════════════════════════
# Connection tracking
# ═══════════════════════════════════════════════════════════════

class Connection:
    """Represents a single network connection with CASI analysis."""

    __slots__ = [
        'src_ip', 'src_port', 'dst_ip', 'dst_port', 'proto',
        'payload', 'packet_count', 'byte_count',
        'first_seen', 'last_seen',
        'protocol', 'tls_version', 'tls_cipher_suite', 'tls_cipher_name',
        'tls_sni', 'tls_app_data',
        'casi', 'verdict', 'cipher_id',
        'http_method', 'http_host',
    ]

    def __init__(self, src_ip, src_port, dst_ip, dst_port, proto='TCP'):
        self.src_ip = src_ip
        self.src_port = src_port
        self.dst_ip = dst_ip
        self.dst_port = dst_port
        self.proto = proto

        self.payload = bytearray()
        self.packet_count = 0
        self.byte_count = 0
        self.first_seen = None
        self.last_seen = None

        self.protocol = None  # TLS, HTTP, DNS, RAW
        self.tls_version = None
        self.tls_cipher_suite = None
        self.tls_cipher_name = None
        self.tls_sni = None
        self.tls_app_data = bytearray()

        self.casi = None
        self.verdict = None
        self.cipher_id = None

        self.http_method = None
        self.http_host = None

    @property
    def key(self):
        return (self.src_ip, self.src_port, self.dst_ip, self.dst_port)

    @property
    def duration(self):
        if self.first_seen and self.last_seen:
            return self.last_seen - self.first_seen
        return 0

    def add_payload(self, data, timestamp=None):
        """Add payload data from a packet."""
        self.payload.extend(data)
        self.byte_count += len(data)
        self.packet_count += 1
        if timestamp:
            if self.first_seen is None:
                self.first_seen = timestamp
            self.last_seen = timestamp

        # Detect protocol on first meaningful payload
        if self.protocol is None and len(self.payload) >= 5:
            self._detect_protocol()

        # If TLS, try to extract records
        if self.protocol == 'TLS':
            self._parse_tls_records(data)

    def _detect_protocol(self):
        """Detect the application protocol from payload."""
        p = bytes(self.payload[:10])

        # TLS: content type 0x14-0x17, version 0x03 0x0X
        if len(p) >= 5 and p[0] in (0x14, 0x15, 0x16, 0x17) and p[1] == 0x03 and p[2] <= 0x04:
            self.protocol = 'TLS'
            ver = (p[1], p[2])
            self.tls_version = TLS_VERSIONS.get(ver, f'TLS-{ver[0]}.{ver[1]}')
            return

        # HTTP: starts with method
        for method in HTTP_METHODS:
            if p[:len(method)] == method:
                self.protocol = 'HTTP'
                self.http_method = method.decode()
                # Try to extract Host header
                try:
                    header_text = bytes(self.payload[:2048]).decode('ascii', errors='ignore')
                    for line in header_text.split('\r\n'):
                        if line.lower().startswith('host:'):
                            self.http_host = line.split(':', 1)[1].strip()
                            break
                except Exception:
                    pass
                return

        # HTTP response
        if p[:5] == b'HTTP/':
            self.protocol = 'HTTP'
            return

        # DNS: port 53 heuristic
        if self.dst_port == 53 or self.src_port == 53:
            self.protocol = 'DNS'
            return

        # Raw/unknown
        self.protocol = 'RAW'

    def _parse_tls_records(self, new_data):
        """Extract TLS record info from new packet data."""
        payload = bytes(new_data)
        offset = 0

        while offset + 5 <= len(payload):
            content_type = payload[offset]
            if content_type not in (0x14, 0x15, 0x16, 0x17):
                break

            ver_major = payload[offset + 1]
            ver_minor = payload[offset + 2]
            record_len = struct.unpack('!H', payload[offset + 3:offset + 5])[0]

            if record_len > 16384 + 256:  # TLS max record + overhead
                break
            if offset + 5 + record_len > len(payload):
                break  # Incomplete record

            record_data = payload[offset + 5:offset + 5 + record_len]

            # Update TLS version — but never downgrade from TLS1.3
            # (TLS1.3 records use 0x0303 in headers for compatibility)
            ver = (ver_major, ver_minor)
            ver_str = TLS_VERSIONS.get(ver)
            if ver_str and self.tls_version != 'TLS1.3':
                self.tls_version = ver_str

            # Application Data → collect for CASI
            if content_type == 0x17:
                self.tls_app_data.extend(record_data)

            # Handshake → parse for SNI + cipher suite
            elif content_type == 0x16 and len(record_data) >= 4:
                self._parse_tls_handshake(record_data)

            offset += 5 + record_len

    def _parse_tls_handshake(self, data):
        """Parse TLS handshake message for SNI and cipher suite."""
        if len(data) < 4:
            return

        hs_type = data[0]
        # hs_length = struct.unpack('!I', b'\x00' + data[1:4])[0]

        if hs_type == 1:  # ClientHello
            self._parse_client_hello(data[4:])
        elif hs_type == 2:  # ServerHello
            self._parse_server_hello(data[4:])

    def _parse_client_hello(self, data):
        """Extract SNI from ClientHello."""
        try:
            if len(data) < 38:
                return

            # Skip: version(2) + random(32) = 34
            offset = 34

            # Session ID
            if offset >= len(data):
                return
            session_id_len = data[offset]
            offset += 1 + session_id_len

            # Cipher suites
            if offset + 2 > len(data):
                return
            cs_len = struct.unpack('!H', data[offset:offset + 2])[0]
            offset += 2 + cs_len

            # Compression methods
            if offset >= len(data):
                return
            comp_len = data[offset]
            offset += 1 + comp_len

            # Extensions
            if offset + 2 > len(data):
                return
            ext_total_len = struct.unpack('!H', data[offset:offset + 2])[0]
            offset += 2

            ext_end = offset + ext_total_len
            while offset + 4 <= ext_end and offset + 4 <= len(data):
                ext_type = struct.unpack('!H', data[offset:offset + 2])[0]
                ext_len = struct.unpack('!H', data[offset + 2:offset + 4])[0]
                offset += 4

                if ext_type == 0 and ext_len > 0:  # SNI extension
                    sni_data = data[offset:offset + ext_len]
                    if len(sni_data) >= 5:
                        name_len = struct.unpack('!H', sni_data[3:5])[0]
                        if len(sni_data) >= 5 + name_len:
                            self.tls_sni = sni_data[5:5 + name_len].decode('ascii', errors='ignore')

                offset += ext_len
        except Exception:
            pass

    def _parse_server_hello(self, data):
        """Extract cipher suite from ServerHello."""
        try:
            if len(data) < 38:
                return

            # Skip: version(2) + random(32) = 34
            offset = 34

            # Session ID
            if offset >= len(data):
                return
            session_id_len = data[offset]
            offset += 1 + session_id_len

            # Cipher suite (2 bytes)
            if offset + 2 > len(data):
                return
            suite_code = struct.unpack('!H', data[offset:offset + 2])[0]
            self.tls_cipher_suite = suite_code
            self.tls_cipher_name = CIPHER_SUITES.get(suite_code, f'0x{suite_code:04x}')

            # Check TLS 1.3 via supported_versions extension
            offset += 2
            if offset >= len(data):
                return
            # compression method
            offset += 1

            # Extensions (TLS 1.3 puts real version here)
            if offset + 2 > len(data):
                return
            ext_total_len = struct.unpack('!H', data[offset:offset + 2])[0]
            offset += 2

            ext_end = offset + ext_total_len
            while offset + 4 <= ext_end and offset + 4 <= len(data):
                ext_type = struct.unpack('!H', data[offset:offset + 2])[0]
                ext_len = struct.unpack('!H', data[offset + 2:offset + 4])[0]
                offset += 4

                if ext_type == 43 and ext_len >= 2:  # supported_versions
                    sv = struct.unpack('!H', data[offset:offset + 2])[0]
                    if sv == 0x0304:
                        self.tls_version = 'TLS1.3'

                offset += ext_len
        except Exception:
            pass

    def compute_casi(self, key_size=32):
        """Compute CASI score for this connection's payload."""
        # Choose the best data source
        data = bytes(self.tls_app_data) if self.tls_app_data else bytes(self.payload)

        if len(data) < key_size * 100:
            # Not enough data — infer from protocol
            if self.protocol == 'TLS':
                self.casi = 1.0  # Assume secure
                self.verdict = 'SECURE (TLS)'
            elif self.protocol == 'HTTP':
                self.casi = 999.0
                self.verdict = 'PLAINTEXT'
            elif self.protocol == 'DNS':
                self.casi = 999.0
                self.verdict = 'PLAINTEXT'
            else:
                self.casi = None
                self.verdict = 'INSUFFICIENT'
            return

        # Run CASI
        keys = np.frombuffer(data[:len(data) - len(data) % key_size],
                             dtype=np.uint8).reshape(-1, key_size)
        if len(keys) < 100:
            self.casi = None
            self.verdict = 'INSUFFICIENT'
            return

        signal = compute_signal(keys)
        baseline_keys = np.frombuffer(
            os.urandom(len(keys) * key_size), dtype=np.uint8
        ).reshape(-1, key_size)
        baseline = compute_signal(baseline_keys)

        self.casi = signal['total'] / max(baseline['total'], 1)
        self.verdict = casi_verdict(self.casi)

        # Try cipher identification on weak/broken connections
        if self.casi > 2.0 and self.protocol != 'HTTP':
            try:
                from .identify import identify_cipher
                result = identify_cipher(data, key_size=key_size)
                if result['confidence'] > 50:
                    self.cipher_id = result['cipher']
            except Exception:
                pass


def _canonicalize_key(src_ip, src_port, dst_ip, dst_port):
    """Canonicalize connection key so A→B and B→A map to same connection."""
    if (src_ip, src_port) <= (dst_ip, dst_port):
        return (src_ip, src_port, dst_ip, dst_port)
    return (dst_ip, dst_port, src_ip, src_port)


# ═══════════════════════════════════════════════════════════════
# pcap analysis (offline)
# ═══════════════════════════════════════════════════════════════

def analyze_pcap(filepath, key_size=32):
    """Analyze a pcap file and return per-connection CASI scores.

    Args:
        filepath: Path to pcap/pcapng file
        key_size: Bytes per key for CASI (default 32)

    Returns:
        list of Connection objects with CASI scores computed
    """
    try:
        from scapy.all import rdpcap, TCP, UDP, IP, IPv6, Raw, DNS as ScapyDNS
    except ImportError:
        raise ImportError(
            "scapy is required for pcap analysis.\n"
            "Install with: pip install live-casi[network]\n"
            "Or: pip install scapy"
        )

    packets = rdpcap(filepath)
    connections = {}

    for pkt in packets:
        # Extract IP layer
        if IP in pkt:
            src_ip = pkt[IP].src
            dst_ip = pkt[IP].dst
        elif IPv6 in pkt:
            src_ip = pkt[IPv6].src
            dst_ip = pkt[IPv6].dst
        else:
            continue

        # Extract transport layer
        if TCP in pkt:
            src_port = pkt[TCP].sport
            dst_port = pkt[TCP].dport
            proto = 'TCP'
        elif UDP in pkt:
            src_port = pkt[UDP].sport
            dst_port = pkt[UDP].dport
            proto = 'UDP'
        else:
            continue

        # Get payload — try Raw first, then fall back to raw bytes after transport layer
        if Raw in pkt:
            payload = bytes(pkt[Raw].load)
        elif TCP in pkt:
            payload = bytes(pkt[TCP].payload) if pkt[TCP].payload else b''
        elif UDP in pkt:
            payload = bytes(pkt[UDP].payload) if pkt[UDP].payload else b''
        else:
            payload = b''

        if not payload or len(payload) < 2:
            continue

        # Canonical key for bidirectional tracking
        key = _canonicalize_key(src_ip, src_port, dst_ip, dst_port)

        if key not in connections:
            # Use original direction for display
            connections[key] = Connection(src_ip, src_port, dst_ip, dst_port, proto)

        ts = float(pkt.time) if hasattr(pkt, 'time') else None
        connections[key].add_payload(payload, timestamp=ts)

    # Compute CASI for all connections
    result = list(connections.values())
    for conn in result:
        conn.compute_casi(key_size=key_size)

    # Sort: worst (highest CASI / plaintext) first
    def sort_key(c):
        if c.casi is None:
            return -1
        return -c.casi

    result.sort(key=sort_key)
    return result


# ═══════════════════════════════════════════════════════════════
# Live monitor
# ═══════════════════════════════════════════════════════════════

def live_monitor(interface=None, duration=None, key_size=32, callback=None, quiet=False):
    """Monitor live network traffic and score each connection with CASI.

    Args:
        interface: Network interface (default: auto-detect)
        duration: Capture duration in seconds (None = until Ctrl+C)
        key_size: Bytes per key for CASI
        callback: Optional function called on each display update with connection list
        quiet: Only print alerts (new plaintext/weak connections)

    Returns:
        list of Connection objects (after capture ends)
    """
    try:
        from scapy.all import sniff, TCP, UDP, IP, IPv6, Raw, conf
    except ImportError:
        raise ImportError(
            "scapy is required for live monitoring.\n"
            "Install with: pip install live-casi[network]\n"
            "Or: pip install scapy"
        )

    connections = {}
    conn_lock = None
    start_time = time.time()
    last_refresh = [0]
    packet_count = [0]
    alerted = set()  # Track which connections we've already alerted on

    def process_packet(pkt):
        nonlocal connections

        if IP in pkt:
            src_ip = pkt[IP].src
            dst_ip = pkt[IP].dst
        elif IPv6 in pkt:
            src_ip = pkt[IPv6].src
            dst_ip = pkt[IPv6].dst
        else:
            return

        if TCP in pkt:
            src_port = pkt[TCP].sport
            dst_port = pkt[TCP].dport
            proto = 'TCP'
        elif UDP in pkt:
            src_port = pkt[UDP].sport
            dst_port = pkt[UDP].dport
            proto = 'UDP'
        else:
            return

        if Raw in pkt:
            payload = bytes(pkt[Raw].load)
        elif TCP in pkt:
            payload = bytes(pkt[TCP].payload) if pkt[TCP].payload else b''
        elif UDP in pkt:
            payload = bytes(pkt[UDP].payload) if pkt[UDP].payload else b''
        else:
            payload = b''

        if not payload or len(payload) < 2:
            return

        key = _canonicalize_key(src_ip, src_port, dst_ip, dst_port)
        if key not in connections:
            connections[key] = Connection(src_ip, src_port, dst_ip, dst_port, proto)

        ts = float(pkt.time) if hasattr(pkt, 'time') else None
        connections[key].add_payload(payload, timestamp=ts)
        packet_count[0] += 1

        # Recompute CASI periodically (every 2 seconds)
        now = time.time()
        if now - last_refresh[0] >= 2.0:
            last_refresh[0] = now
            _refresh_connections(connections, key_size, alerted, quiet,
                                 start_time, packet_count[0])

    # Determine interface
    if interface is None:
        try:
            from scapy.all import conf as scapy_conf
            interface = scapy_conf.iface
        except Exception:
            interface = 'en0'

    if not quiet:
        print(f'{BOLD}{CYAN}live-casi Network Monitor{RESET}')
        print(f'{DIM}Interface: {interface} | Key size: {key_size}B | '
              f'{"Duration: " + str(duration) + "s" if duration else "Ctrl+C to stop"}{RESET}')
        print(f'{DIM}{"═" * 100}{RESET}')

    try:
        sniff(
            iface=interface,
            prn=process_packet,
            store=0,
            timeout=duration,
        )
    except PermissionError:
        print(f'\n{RED}Permission denied. Run with sudo:{RESET}')
        print(f'  sudo live-casi --monitor --interface {interface}')
        return []
    except KeyboardInterrupt:
        pass

    # Final computation
    for conn in connections.values():
        conn.compute_casi(key_size=key_size)

    result = list(connections.values())
    result.sort(key=lambda c: -(c.casi or -1))

    if not quiet:
        print(f'\n{DIM}{"═" * 100}{RESET}')
        _print_connection_table(result, start_time, packet_count[0], final=True)

    return result


def _refresh_connections(connections, key_size, alerted, quiet, start_time, pkt_count):
    """Recompute CASI for connections that have new data."""
    conn_list = list(connections.values())

    for conn in conn_list:
        old_verdict = conn.verdict
        conn.compute_casi(key_size=key_size)

        # Alert on newly detected problems
        if conn.verdict and conn.verdict != 'INSUFFICIENT' and conn.key not in alerted:
            if conn.casi and conn.casi > 2.0:
                alerted.add(conn.key)
                if quiet:
                    _print_alert(conn)

    if not quiet:
        # Clear and redraw
        conn_list.sort(key=lambda c: -(c.casi or -1))
        _print_connection_table(conn_list, start_time, pkt_count, final=False)


def _print_alert(conn):
    """Print a single-line alert for a problematic connection."""
    casi_str = f'{conn.casi:.1f}' if conn.casi else '?'
    info = conn.tls_sni or conn.http_host or ''
    print(f'{RED}ALERT{RESET} {conn.src_ip}:{conn.src_port} → '
          f'{conn.dst_ip}:{conn.dst_port} '
          f'CASI={casi_str} {conn.verdict} {info}')


def _print_connection_table(conns, start_time, pkt_count, final=False):
    """Print the connection table to terminal."""
    elapsed = time.time() - start_time

    # Move cursor up to overwrite previous table (if not final)
    if not final:
        # Count lines to clear (header + connections + summary)
        n_lines = min(len(conns), 20) + 5
        sys.stdout.write(f'\033[{n_lines}A\033[J')

    active = [c for c in conns if c.verdict and c.verdict != 'INSUFFICIENT']
    n_secure = sum(1 for c in active if c.casi is not None and c.casi < 2.0)
    n_weak = sum(1 for c in active if c.casi is not None and 2.0 <= c.casi <= 10.0)
    n_plain = sum(1 for c in active if c.casi is not None and c.casi > 10.0)
    n_plain += sum(1 for c in active if c.verdict == 'PLAINTEXT')
    n_tls_inferred = sum(1 for c in active if c.verdict == 'SECURE (TLS)')

    status = (f'{DIM}{len(conns)} connections | {pkt_count} packets | '
              f'{elapsed:.0f}s{RESET}')
    if final:
        status = f'{BOLD}Final Report:{RESET} ' + status
    print(status)

    hdr = (f'  {"#":>3}  {"Source":<22s}  {"Destination":<22s}  '
           f'{"Proto":<7s}  {"Bytes":>8s}  {"CASI":>6s}  {"Verdict":<12s}  {"Info":<30s}')
    print(hdr)
    print(f'  {"─" * 3}  {"─" * 22}  {"─" * 22}  {"─" * 7}  {"─" * 8}  {"─" * 6}  {"─" * 12}  {"─" * 30}')

    for i, conn in enumerate(conns[:30]):
        src = f'{conn.src_ip}:{conn.src_port}'
        dst = f'{conn.dst_ip}:{conn.dst_port}'

        proto = conn.protocol or conn.proto
        if conn.tls_version:
            proto = conn.tls_version

        byte_str = _format_bytes(conn.byte_count)

        if conn.casi is not None:
            casi_str = f'{conn.casi:.1f}'
            color = casi_color(conn.casi)
        elif conn.verdict == 'SECURE (TLS)':
            casi_str = '~1.0'
            color = GREEN
        elif conn.verdict == 'PLAINTEXT':
            casi_str = '>>10'
            color = RED
        else:
            casi_str = '—'
            color = DIM

        verdict = conn.verdict or '—'

        # Info field: SNI > HTTP host > cipher name > cipher ID
        info_parts = []
        if conn.tls_sni:
            info_parts.append(conn.tls_sni)
        elif conn.http_host:
            info_parts.append(conn.http_host)
        if conn.tls_cipher_name:
            short_cipher = conn.tls_cipher_name.replace('TLS_', '').replace('_WITH_', ' ')
            if len(short_cipher) > 25:
                short_cipher = short_cipher[:22] + '...'
            info_parts.append(f'({short_cipher})')
        elif conn.cipher_id:
            info_parts.append(f'[{conn.cipher_id}?]')
        if conn.http_method:
            info_parts.insert(0, conn.http_method)
        info = ' '.join(info_parts)[:30]

        # Warning marker
        warning = ''
        if conn.casi and conn.casi > 2.0:
            warning = ' ⚠️'
        elif conn.verdict == 'PLAINTEXT':
            warning = ' ⚠️'

        print(f'  {i + 1:>3}  {src:<22s}  {dst:<22s}  '
              f'{proto:<7s}  {byte_str:>8s}  {color}{casi_str:>6s}{RESET}  '
              f'{color}{verdict:<12s}{RESET}  {DIM}{info}{RESET}{warning}')

    if len(conns) > 30:
        print(f'{DIM}  ... and {len(conns) - 30} more connections{RESET}')

    # Summary line
    parts = []
    if n_secure or n_tls_inferred:
        parts.append(f'{GREEN}{n_secure + n_tls_inferred} SECURE{RESET}')
    if n_weak:
        parts.append(f'{YELLOW}{n_weak} WEAK ⚠️{RESET}')
    if n_plain:
        parts.append(f'{RED}{n_plain} PLAINTEXT ⚠️{RESET}')
    if parts:
        print(f'\n  {" | ".join(parts)}')


def _format_bytes(n):
    """Format byte count as human-readable."""
    if n < 1024:
        return f'{n}B'
    elif n < 1024 * 1024:
        return f'{n / 1024:.1f}K'
    else:
        return f'{n / (1024 * 1024):.1f}M'


# ═══════════════════════════════════════════════════════════════
# CLI handlers
# ═══════════════════════════════════════════════════════════════

def run_pcap(args):
    """CLI handler for --pcap mode."""
    import json as json_mod

    filepath = args.pcap
    if not os.path.isfile(filepath):
        print(f'{RED}File not found: {filepath}{RESET}')
        sys.exit(1)

    quiet = getattr(args, 'quiet', False)
    json_out = getattr(args, 'json', False)
    problems_only = getattr(args, 'problems_only', False)
    key_size = getattr(args, 'key_size', 32)

    t0 = time.time()
    conns = analyze_pcap(filepath, key_size=key_size)
    dt = time.time() - t0

    if problems_only:
        conns = [c for c in conns
                 if (c.casi is not None and c.casi > 2.0)
                 or c.verdict == 'PLAINTEXT']

    if json_out:
        out = {
            'file': filepath,
            'elapsed_seconds': round(dt, 2),
            'connections': [],
        }
        for c in conns:
            entry = {
                'src': f'{c.src_ip}:{c.src_port}',
                'dst': f'{c.dst_ip}:{c.dst_port}',
                'protocol': c.protocol,
                'tls_version': c.tls_version,
                'tls_cipher': c.tls_cipher_name,
                'tls_sni': c.tls_sni,
                'bytes': c.byte_count,
                'packets': c.packet_count,
                'casi': round(c.casi, 2) if c.casi is not None else None,
                'verdict': c.verdict,
            }
            out['connections'].append(entry)
        print(json_mod.dumps(out, indent=2))
        return

    if quiet:
        for c in conns:
            casi_str = f'{c.casi:.1f}' if c.casi is not None else '?'
            print(f'{c.src_ip}:{c.src_port} → {c.dst_ip}:{c.dst_port} '
                  f'{c.protocol or "?"} {casi_str} {c.verdict or "?"}')
        return

    # Full table output
    file_size = os.path.getsize(filepath)
    total_pkts = sum(c.packet_count for c in conns)

    print()
    print(f'{BOLD}{CYAN}live-casi pcap Analysis{RESET}')
    print(f'{DIM}File: {filepath} ({_format_bytes(file_size)}, '
          f'{total_pkts} packets with payload, {len(conns)} connections){RESET}')
    print(f'{DIM}{"═" * 100}{RESET}')

    _print_connection_table(conns, time.time() - dt, total_pkts, final=True)

    # TLS breakdown
    tls_conns = [c for c in conns if c.protocol == 'TLS']
    if tls_conns:
        print(f'\n{BOLD}TLS Breakdown:{RESET}')
        for c in tls_conns:
            sni = c.tls_sni or f'{c.dst_ip}:{c.dst_port}'
            ver = c.tls_version or '?'
            cipher = c.tls_cipher_name or 'unknown'
            weak = ''
            if c.tls_cipher_suite in WEAK_SUITES:
                weak = f' {RED}⚠️ WEAK CIPHER{RESET}'
            print(f'  {DIM}{sni:<30s} {ver:<8s} {cipher}{weak}{RESET}')

    print(f'\n{DIM}Elapsed: {dt:.1f}s{RESET}')
    print()


def run_monitor(args):
    """CLI handler for --monitor mode."""
    interface = getattr(args, 'interface', None)
    duration = getattr(args, 'duration', None)
    quiet = getattr(args, 'quiet', False)
    json_out = getattr(args, 'json', False)
    key_size = getattr(args, 'key_size', 32)

    conns = live_monitor(
        interface=interface,
        duration=duration,
        key_size=key_size,
        quiet=quiet,
    )

    if json_out:
        import json as json_mod
        out = {
            'connections': [],
        }
        for c in conns:
            entry = {
                'src': f'{c.src_ip}:{c.src_port}',
                'dst': f'{c.dst_ip}:{c.dst_port}',
                'protocol': c.protocol,
                'tls_version': c.tls_version,
                'tls_cipher': c.tls_cipher_name,
                'tls_sni': c.tls_sni,
                'bytes': c.byte_count,
                'packets': c.packet_count,
                'casi': round(c.casi, 2) if c.casi is not None else None,
                'verdict': c.verdict,
            }
            out['connections'].append(entry)
        print(json_mod.dumps(out, indent=2))
