#!/usr/bin/env python3
"""
live-casi academia: AI-Text Detection for Academic Documents.

5-layer analysis for detecting AI-generated content in dissertations,
theses, and academic papers. Combines CASI structural analysis with
linguistic markers for ChatGPT, DeepL, and paraphrasing tools.

Usage:
    from live_casi.academia import analyze_text, analyze_pdf
    result = analyze_text(text, language='de')
    result = analyze_pdf('dissertation.pdf', language='de')

    # CLI
    live-casi --academia dissertation.pdf

Layers:
    L1: Token-residuum mod K distribution (token-residuum method)
    L2: CASI 22-strategy structural profile
    L3: ChatGPT phrase/starter/hedging detection
    L4: DeepL/translationese marker detection
    L5: Intra-document style consistency (outlier segments)

Validated on:
    - 402 German dissertations (200 pre-2024 + 203 post-2024)
    - RAID benchmark (ACL 2024): AUC=0.871 for GPT-4o
    - GPT-4 German (alpaca-gpt4-deutsch): AUC=0.989
    - Dose-response: Spearman rho=-0.926 (causal proof)
    - Paraphrasing-robust: d=-2.17 after synonym+reorder

"""

import re
import subprocess
import tempfile
import os
import numpy as np

from .core import (
    compute_signal,
    compute_casi_score,
    STRATEGY_NAMES,
    CRYPTO_STRATEGY_NAMES,
    IMPL_STRATEGY_NAMES,
)

__all__ = [
    'analyze_text', 'analyze_pdf', 'AcademiaResult',
    'CHATGPT_PHRASES_DE', 'CHATGPT_PHRASES_EN',
    'DEEPL_MARKERS_DE',
]

# ═══════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════

K = 256  # Token residuum mod K 
SEG_TOKENS = 512  # Tokens per consistency segment

# Thresholds calibrated on 402 German dissertations (2026-02-27)
DEFAULT_THRESHOLDS = {
    "phrase_density": 0.75,
    "starter_pct": 1.5,
    "hedge_density": 0.80,
    "deepl_density": 1.0,
    "sent_cv_low": 0.55,
    "ttr_low": 0.72,
    "l1_high": 1.0,
}

# ═══════════════════════════════════════════════════════════════════
# LINGUISTIC MARKER DATABASES
# ═══════════════════════════════════════════════════════════════════

CHATGPT_PHRASES_DE = [
    "es ist wichtig zu beachten", "es ist erwähnenswert",
    "zusammenfassend lässt sich sagen", "zusammenfassend lässt sich festhalten",
    "in diesem zusammenhang", "in diesem kontext",
    "darüber hinaus", "des weiteren", "es sei darauf hingewiesen",
    "eine wichtige rolle spielt", "von entscheidender bedeutung",
    "von großer bedeutung", "eine zentrale rolle",
    "in der vorliegenden arbeit", "im rahmen dieser arbeit",
    "ein wesentlicher aspekt", "eine umfassende analyse",
    "eine detaillierte analyse", "lässt sich feststellen",
    "kann festgestellt werden", "es zeigt sich, dass",
    "wie bereits erwähnt", "abschließend lässt sich",
    "insgesamt zeigt sich", "die ergebnisse deuten darauf hin",
    "es konnte gezeigt werden", "im folgenden wird",
    "es ist unerlässlich", "maßgeblich beeinflusst",
    "einen signifikanten einfluss",
]

CHATGPT_PHRASES_EN = [
    "it is important to note", "it is worth noting",
    "in summary", "in conclusion", "furthermore",
    "it should be noted", "plays a crucial role",
    "of great importance", "a comprehensive analysis",
    "a detailed analysis", "it can be observed",
    "as mentioned earlier", "the results suggest",
    "it was demonstrated", "in the following",
    "it is essential", "significantly influenced",
]

CHATGPT_STARTERS_DE = [
    "darüber hinaus", "zusammenfassend", "insgesamt", "abschließend",
    "des weiteren", "ferner", "überdies", "nichtsdestotrotz",
    "grundsätzlich", "letztendlich", "im wesentlichen", "insbesondere",
    "hervorzuheben ist", "bemerkenswert ist", "festzuhalten ist",
]

CHATGPT_STARTERS_EN = [
    "furthermore", "in summary", "overall", "in conclusion",
    "moreover", "additionally", "nevertheless", "fundamentally",
    "ultimately", "essentially", "in particular", "notably",
    "it is noteworthy", "it is remarkable",
]

DEEPL_MARKERS_DE = [
    "implementiert", "adressiert", "fokussiert", "evaluiert",
    "identifiziert", "generiert", "validiert", "optimiert",
    "wurde durchgeführt", "wurde festgestellt", "wurde beobachtet",
    "wurde nachgewiesen", "konnte bestätigt werden",
    "in bezug auf", "im hinblick auf", "mit bezug auf",
    "hinsichtlich der", "in anbetracht",
]

HEDGE_WORDS_DE = [
    "möglicherweise", "wahrscheinlich", "vermutlich", "tendenziell",
    "potenziell", "gegebenenfalls", "unter umständen",
]

HEDGE_WORDS_EN = [
    "possibly", "probably", "presumably", "potentially",
    "perhaps", "arguably", "conceivably",
]


# ═══════════════════════════════════════════════════════════════════
# PROSE FILTER
# ═══════════════════════════════════════════════════════════════════

def _is_prose_line(line):
    """Check if a line is prose text (not formula/code/bibliography)."""
    line = line.strip()
    if len(line) < 20:
        return False
    if line.count('.') > len(line) * 0.3:
        return False
    alpha_ratio = sum(1 for c in line if c.isalpha()) / max(len(line), 1)
    if alpha_ratio < 0.4:
        return False
    if re.match(r'^[ACGTUNRYWSMKHBVD\s]{30,}$', line):
        return False
    if re.match(r'^\[\d+\]', line):
        return False
    return True


def _extract_prose(text):
    """Extract only prose paragraphs from text."""
    return '\n'.join(l for l in text.split('\n') if _is_prose_line(l))


# ═══════════════════════════════════════════════════════════════════
# TOKENIZER (lightweight, no transformers dependency)
# ═══════════════════════════════════════════════════════════════════

def _simple_tokenize(text):
    """Simple byte-level tokenization (no external dependencies).

    Uses UTF-8 byte values as token IDs. This is language-agnostic
    and doesn't require transformers/sentencepiece.
    """
    return list(text.encode('utf-8'))


def _get_tokenizer(language='de'):
    """Try to load HuggingFace tokenizer, fall back to byte-level."""
    try:
        from transformers import AutoTokenizer
        if language == 'de':
            tok = AutoTokenizer.from_pretrained('dbmdz/german-gpt2')
        else:
            tok = AutoTokenizer.from_pretrained('gpt2')
        return lambda text: tok.encode(text, add_special_tokens=False)
    except ImportError:
        return _simple_tokenize


# ═══════════════════════════════════════════════════════════════════
# ANALYSIS LAYERS
# ═══════════════════════════════════════════════════════════════════

def _layer1_token_residuum(tokens, thresholds=None):
    """L1: Token-residuum mod K histogram vs uniform."""
    if thresholds is None:
        thresholds = DEFAULT_THRESHOLDS
    residuals = np.array(tokens) % K
    hist = np.bincount(residuals, minlength=K).astype(np.float64)
    hist /= len(residuals)
    l1 = float(np.sum(np.abs(hist - np.ones(K) / K)))
    return {"l1": round(l1, 4), "l1_flag": l1 > thresholds["l1_high"]}


def _layer2_casi_profile(tokens):
    """L2: CASI structural profile using byte-level strategies."""
    residuals = np.array(tokens, dtype=np.uint8) % K
    # Build matrix: sliding window histograms
    window = 64
    rows = []
    for i in range(0, len(residuals) - window + 1, window // 2):
        hist = np.bincount(residuals[i:i+window], minlength=K).astype(np.float32)
        rows.append(hist)
    if len(rows) < 3:
        return {"casi_score": 0, "casi_norm": 0}

    mat = np.array(rows)
    # Quantile normalize
    flat = mat.flatten().astype(np.float64)
    ranks = np.argsort(np.argsort(flat)).astype(np.float64)
    quantiled = (ranks / len(ranks) * 255.999).astype(np.uint8)
    keys = quantiled.reshape(mat.shape)

    result = compute_casi_score(keys)
    score = float(result.get('casi', 0)) if isinstance(result, dict) else float(result)
    return {
        "casi_score": round(score, 4),
        "casi_norm": round(score / max(len(rows), 1), 6),
    }


def _layer3_chatgpt(text, language='de'):
    """L3: ChatGPT marker detection."""
    text_lower = text.lower()
    n_words = len(text.split())
    if n_words < 100:
        return {}

    phrases = CHATGPT_PHRASES_DE if language == 'de' else CHATGPT_PHRASES_EN
    starters = CHATGPT_STARTERS_DE if language == 'de' else CHATGPT_STARTERS_EN
    hedges = HEDGE_WORDS_DE if language == 'de' else HEDGE_WORDS_EN

    phrase_count = sum(text_lower.count(p) for p in phrases)
    phrase_density = phrase_count / (n_words / 1000)

    sentences = re.split(r'[.!?]\s+', text)
    starter_count = sum(1 for s in sentences
                        if any(s.strip().lower().startswith(st) for st in starters))
    starter_pct = starter_count / max(len(sentences), 1) * 100

    hedge_count = sum(text_lower.count(h) for h in hedges)
    hedge_density = hedge_count / (n_words / 1000)

    sent_lens = [len(s.split()) for s in sentences if len(s.split()) > 3]
    sent_cv = float(np.std(sent_lens) / max(np.mean(sent_lens), 1)) if sent_lens else 0

    found = [(p, text_lower.count(p)) for p in phrases if text_lower.count(p) > 0]
    found.sort(key=lambda x: -x[1])

    return {
        "phrase_density": round(phrase_density, 2),
        "starter_pct": round(starter_pct, 1),
        "hedge_density": round(hedge_density, 2),
        "sent_cv": round(sent_cv, 3),
        "top_phrases": found[:5],
    }


def _layer4_deepl(text, language='de'):
    """L4: DeepL/translationese marker detection."""
    text_lower = text.lower()
    n_words = len(text.split())
    if n_words < 100:
        return {}

    markers = DEEPL_MARKERS_DE if language == 'de' else []
    marker_count = sum(text_lower.count(m) for m in markers)
    marker_density = marker_count / (n_words / 1000)

    words = text_lower.split()
    window = 100
    ttrs = []
    for i in range(0, len(words) - window + 1, window):
        seg = words[i:i+window]
        ttrs.append(len(set(seg)) / len(seg))
    ttr = float(np.mean(ttrs)) if ttrs else 0

    found = [(m, text_lower.count(m)) for m in markers if text_lower.count(m) > 0]
    found.sort(key=lambda x: -x[1])

    return {
        "deepl_density": round(marker_density, 2),
        "ttr": round(ttr, 3),
        "top_markers": found[:5],
    }


def _layer5_consistency(tokens, thresholds=None):
    """L5: Intra-document style consistency analysis."""
    if thresholds is None:
        thresholds = DEFAULT_THRESHOLDS
    if len(tokens) < SEG_TOKENS * 3:
        return {"status": "too_short"}

    seg_l1s = []
    for i in range(0, len(tokens) - SEG_TOKENS + 1, SEG_TOKENS // 2):
        seg = tokens[i:i + SEG_TOKENS]
        residuals = np.array(seg) % K
        hist = np.bincount(residuals, minlength=K).astype(np.float64)
        hist /= len(residuals)
        l1 = float(np.sum(np.abs(hist - np.ones(K) / K)))
        seg_l1s.append(l1)

    l1_mean = np.mean(seg_l1s)
    l1_std = np.std(seg_l1s)
    threshold = l1_mean + 2 * l1_std

    outliers = []
    for i, l1 in enumerate(seg_l1s):
        if l1 > threshold:
            pct = round(i / len(seg_l1s) * 100)
            z = round((l1 - l1_mean) / max(l1_std, 0.01), 2)
            outliers.append({"position_pct": pct, "l1": round(l1, 4), "z_score": z})

    # ASCII heatmap
    n_bins = min(40, len(seg_l1s))
    heatmap = ""
    for b in range(n_bins):
        idx = b * len(seg_l1s) // n_bins
        v = seg_l1s[min(idx, len(seg_l1s) - 1)]
        z = (v - l1_mean) / max(l1_std, 0.01)
        if z > 2: heatmap += "!"
        elif z > 1: heatmap += "#"
        elif z > 0: heatmap += "+"
        elif z > -1: heatmap += "."
        else: heatmap += "_"

    return {
        "n_segments": len(seg_l1s),
        "l1_mean": round(l1_mean, 4),
        "l1_std": round(l1_std, 4),
        "n_outliers": len(outliers),
        "outlier_pct": round(len(outliers) / len(seg_l1s) * 100, 1),
        "outliers": outliers[:5],
        "heatmap": heatmap,
    }


# ═══════════════════════════════════════════════════════════════════
# RESULT CLASS
# ═══════════════════════════════════════════════════════════════════

class AcademiaResult:
    """Result of academic AI detection analysis."""

    def __init__(self, verdict, ai_probability, n_flags, flags, layers,
                 word_count=0, filename=None):
        self.verdict = verdict
        self.ai_probability = ai_probability
        self.n_flags = n_flags
        self.flags = flags
        self.layers = layers
        self.word_count = word_count
        self.filename = filename

    def __repr__(self):
        return (f"AcademiaResult(verdict='{self.verdict}', "
                f"ai_probability={self.ai_probability}%, "
                f"flags={self.flags})")

    def to_dict(self):
        return {
            "verdict": self.verdict,
            "ai_probability": self.ai_probability,
            "n_flags": self.n_flags,
            "flags": self.flags,
            "word_count": self.word_count,
            "filename": self.filename,
            "layers": self.layers,
        }


# ═══════════════════════════════════════════════════════════════════
# PUBLIC API
# ═══════════════════════════════════════════════════════════════════

def analyze_text(text, language='de', thresholds=None):
    """Analyze text for AI-generated content.

    Args:
        text: The text to analyze (raw string, not PDF).
        language: 'de' for German, 'en' for English.
        thresholds: Optional custom thresholds dict.

    Returns:
        AcademiaResult with verdict, probability, flags, and layer details.
    """
    if thresholds is None:
        thresholds = DEFAULT_THRESHOLDS

    prose = _extract_prose(text)
    if len(prose) < 500:
        return AcademiaResult("ERROR", 0, 0, ["text_too_short"], {})

    tokenize = _get_tokenizer(language)
    tokens = tokenize(prose)
    n_words = len(prose.split())

    # Run all 5 layers
    l1 = _layer1_token_residuum(tokens, thresholds)
    l2 = _layer2_casi_profile(tokens)
    l3 = _layer3_chatgpt(prose, language)
    l4 = _layer4_deepl(prose, language)
    l5 = _layer5_consistency(tokens, thresholds)

    # Collect flags
    flags = []
    if l3.get("phrase_density", 0) > thresholds["phrase_density"]:
        flags.append("ChatGPT-Phrases")
    if l3.get("starter_pct", 0) > thresholds["starter_pct"]:
        flags.append("ChatGPT-Starters")
    if l3.get("hedge_density", 0) > thresholds["hedge_density"]:
        flags.append("Hedging")
    if l3.get("sent_cv", 1) < thresholds["sent_cv_low"]:
        flags.append("Uniform-Sentences")
    if l4.get("deepl_density", 0) > thresholds["deepl_density"]:
        flags.append("DeepL-Markers")
    if l4.get("ttr", 1) < thresholds["ttr_low"]:
        flags.append("Low-TTR")

    n_flags = len(flags)

    # AI probability (empirically calibrated)
    prob_map = {0: 5, 1: 15, 2: 40, 3: 70, 4: 85, 5: 92, 6: 97}
    ai_prob = prob_map.get(min(n_flags, 6), 97)

    if l1.get("l1_flag"):
        ai_prob = min(ai_prob + 10, 99)
    if l5.get("outlier_pct", 0) > 5:
        ai_prob = min(ai_prob + 5, 99)

    if ai_prob >= 70:
        verdict = "HIGH_RISK"
    elif ai_prob >= 40:
        verdict = "SUSPICIOUS"
    elif ai_prob >= 15:
        verdict = "LOW_RISK"
    else:
        verdict = "CLEAN"

    layers = {
        "L1_token_residuum": l1,
        "L2_casi_profile": l2,
        "L3_chatgpt_markers": l3,
        "L4_deepl_markers": l4,
        "L5_consistency": l5,
    }

    return AcademiaResult(verdict, ai_prob, n_flags, flags, layers, n_words)


def analyze_pdf(pdf_path, language='de', thresholds=None):
    """Analyze a PDF file for AI-generated content.

    Requires pdftotext (from poppler-utils) to be installed.

    Args:
        pdf_path: Path to PDF file.
        language: 'de' for German, 'en' for English.
        thresholds: Optional custom thresholds dict.

    Returns:
        AcademiaResult with verdict, probability, flags, and layer details.
    """
    try:
        result = subprocess.run(
            ['pdftotext', '-layout', pdf_path, '-'],
            capture_output=True, text=True, timeout=60
        )
        text = result.stdout.strip()
    except FileNotFoundError:
        return AcademiaResult("ERROR", 0, 0, ["pdftotext_not_found"], {})
    except subprocess.TimeoutExpired:
        return AcademiaResult("ERROR", 0, 0, ["pdf_timeout"], {})

    if len(text) < 500:
        return AcademiaResult("ERROR", 0, 0, ["pdf_too_short"], {})

    result = analyze_text(text, language, thresholds)
    result.filename = os.path.basename(pdf_path)
    return result
