#!/usr/bin/env python3
"""
CASI Gap Analysis — Find where CASI detects weakness that NIST SP 800-22 misses.

Sweeps every round from 1 to full_rounds for each cipher. At each round,
computes CASI + all NIST tests. Identifies the exact rounds where:
  - CASI > 2.0 (detects weakness)
  - ALL NIST tests pass (p >= 0.01)

These "gap rounds" are the KEY SELLING POINT of CASI: structural weakness
that statistical tests fundamentally cannot detect.

Usage:
    from live_casi.gap_analysis import sweep_gap, format_gap_report
    gaps = sweep_gap(n_keys=10000)
    print(format_gap_report(gaps))

    # CLI:
    python -m live_casi --gap-analysis
    python -m live_casi --gap-analysis --keys 50000
"""

import json
import time
import numpy as np

from .ciphers import CIPHERS
from .core import compute_crypto_signal, compute_signal
from .nist_compare import NIST_TESTS, NIST_ALPHA


def compute_casi_score(keys, crypto_only=True):
    """Compute CASI score with fixed baseline."""
    n_keys = keys.shape[0]
    baseline_keys = np.frombuffer(
        np.random.RandomState(0xBA5E).bytes(n_keys * 32),
        dtype=np.uint8,
    ).reshape(n_keys, 32)
    signal_fn = compute_crypto_signal if crypto_only else compute_signal
    sig = signal_fn(keys)
    base = signal_fn(baseline_keys)
    return sig['total'] / max(base['total'], 1), sig


def run_nist_suite(keys):
    """Run all NIST tests on key array. Returns dict of results."""
    bits = np.unpackbits(keys.ravel())
    results = {}
    for name, test_fn in NIST_TESTS.items():
        p = test_fn(bits)
        results[name] = {'p_value': round(float(p), 6), 'pass': bool(p >= NIST_ALPHA)}
    return results


def sweep_cipher(cipher_key, n_keys=10000, seed=42):
    """Sweep every round of a cipher, computing CASI + NIST at each.

    Returns list of per-round results.
    """
    cipher = CIPHERS.get(cipher_key)
    if not cipher:
        return []

    gen = cipher['generator']
    full_rounds = cipher['full_rounds']
    results = []

    for r in range(1, full_rounds + 1):
        t0 = time.time()
        data = gen(n_keys, rounds=r, seed=seed)
        keys = np.frombuffer(data, dtype=np.uint8).reshape(n_keys, 32)

        casi, sig = compute_casi_score(keys, crypto_only=True)
        casi_full, sig_full = compute_casi_score(keys, crypto_only=False)
        nist = run_nist_suite(keys)

        nist_pass_count = sum(1 for v in nist.values() if v['pass'])
        nist_all_pass = nist_pass_count == len(NIST_TESTS)

        casi_detects = casi >= 2.0
        nist_detects = not nist_all_pass
        is_gap = casi_detects and not nist_detects

        results.append({
            'cipher': cipher['name'],
            'cipher_key': cipher_key,
            'round': r,
            'full_rounds': full_rounds,
            'casi_crypto': round(float(casi), 3),
            'casi_full': round(float(casi_full), 3),
            'signal': {k: int(v) for k, v in sig.items() if k != 'total'},
            'signal_total': int(sig['total']),
            'nist': nist,
            'nist_pass': nist_pass_count,
            'nist_total': len(NIST_TESTS),
            'nist_all_pass': nist_all_pass,
            'casi_detects': casi_detects,
            'nist_detects': nist_detects,
            'is_gap': is_gap,
            'time_s': round(time.time() - t0, 2),
        })

    return results


def sweep_gap(n_keys=10000, seed=42, skip_slow=True):
    """Sweep all ciphers and find gap rounds.

    Returns dict with 'all_results' and 'gaps'.
    """
    all_results = []
    gaps = []

    for key, cipher in CIPHERS.items():
        if skip_slow and cipher.get('slow'):
            continue
        results = sweep_cipher(key, n_keys=n_keys, seed=seed)
        all_results.extend(results)
        for r in results:
            if r['is_gap']:
                gaps.append(r)

    return {
        'all_results': all_results,
        'gaps': gaps,
        'summary': {
            'total_rounds_tested': len(all_results),
            'total_gaps': len(gaps),
            'gap_ciphers': list(set(g['cipher'] for g in gaps)),
            'n_keys': n_keys,
            'seed': seed,
        },
    }


def format_gap_report(data):
    """Format gap analysis as readable report."""
    gaps = data['gaps']
    all_results = data['all_results']
    summary = data['summary']

    lines = []
    lines.append("")
    lines.append("CASI Gap Analysis: Where CASI Detects What NIST Misses")
    lines.append("=" * 90)

    if not gaps:
        lines.append("\nNo gap rounds found at this sample size.")
        lines.append("(Try --keys 50000 for more statistical power)")
    else:
        lines.append(f"\n  {len(gaps)} GAP ROUNDS FOUND — CASI detected weakness, ALL {summary.get('nist_total', 5)} NIST tests passed\n")
        lines.append(f"  {'Cipher':<15} {'Round':>6} {'CASI':>8} {'NIST':>10}  NIST p-values")
        lines.append("  " + "-" * 80)

        for g in sorted(gaps, key=lambda x: (x['cipher'], x['round'])):
            nist = g['nist']
            p_strs = []
            for name in ['frequency', 'block_frequency', 'runs', 'longest_run', 'matrix_rank']:
                p = nist[name]['p_value']
                p_strs.append(f"{p:.3f}")

            lines.append(
                f"  {g['cipher']:<15} R{g['round']:<5} {g['casi_crypto']:>7.1f} "
                f"{g['nist_pass']}/{g['nist_total']:>8}  "
                f"{'  '.join(p_strs)}"
            )

            # Show which CASI strategies fired
            fired = [k for k, v in g['signal'].items() if v > 0]
            if fired:
                lines.append(f"  {'':15} {'':>6} Strategies: {', '.join(fired)}")

    # Summary table: all ciphers, all rounds
    lines.append("\n\nFull Round Sweep (CASI crypto score)")
    lines.append("=" * 90)

    # Group by cipher
    by_cipher = {}
    for r in all_results:
        by_cipher.setdefault(r['cipher_key'], []).append(r)

    for ck, rounds in by_cipher.items():
        cipher_name = rounds[0]['cipher']
        full_rounds = rounds[0]['full_rounds']
        lines.append(f"\n  {cipher_name} (full={full_rounds}):")

        # Print CASI scores as round profile
        profile_parts = []
        for r in rounds:
            marker = " *" if r['is_gap'] else ""
            if r['casi_crypto'] >= 2.0:
                profile_parts.append(f"  R{r['round']:>2}: {r['casi_crypto']:>7.1f}{marker}")
            elif r['casi_crypto'] >= 1.5:
                profile_parts.append(f"  R{r['round']:>2}: {r['casi_crypto']:>7.1f}  (borderline)")
            else:
                profile_parts.append(f"  R{r['round']:>2}: {r['casi_crypto']:>7.1f}")

        # Only show interesting rounds (first 5 + any > 1.0 + last)
        interesting = []
        for i, r in enumerate(rounds):
            if i < 5 or r['casi_crypto'] > 1.3 or r['is_gap'] or i == len(rounds) - 1:
                interesting.append(profile_parts[i])
            elif i == 5:
                interesting.append(f"  ... ({len(rounds) - 6} more rounds ≈ 1.0) ...")

        for line in interesting:
            lines.append(line)

    lines.append("\n" + "=" * 90)
    lines.append(f"\nTotal: {summary['total_rounds_tested']} rounds tested, "
                 f"{summary['total_gaps']} CASI-only detections found")
    lines.append(f"  * = GAP: CASI detects, NIST misses")
    lines.append("")

    return "\n".join(lines)


def save_gap_json(data, path='casi_gap_analysis.json'):
    """Save results as JSON."""
    with open(path, 'w') as f:
        json.dump(data, f, indent=2, default=str)
    return path
