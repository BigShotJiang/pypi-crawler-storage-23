#!/usr/bin/env python3
"""
live-casi nn_analysis: Neural Network Weight & Activation Analysis.

Compute CASI scores on model weights, activations, gradients, and
attention patterns to detect structural anomalies in neural networks.

Ported from casi_nn.py (casi-collapse project).

Usage:
    from live_casi.nn_analysis import (
        weight_to_casi_input, layer_casi, model_casi_profile,
        global_quantile_matrix,
    )

    # Analyze model weights
    profile = model_casi_profile(model)
    for name, casi in profile.items():
        print(f"{name}: CASI={casi:.2f}")

    # Analyze single layer
    score = layer_casi(model.transformer.h[0].attn.c_attn.weight)

Validated:
    - GPT-2 weight analysis (T01-T10)
    - Activation CASI during training (T10)
    - Gradient CASI for collapse detection (T23)
    - Attention pattern CASI (T27)
    - Cross-layer mutual information (T17)
"""

import numpy as np

from .core import compute_casi_score

__all__ = [
    'global_quantile_matrix', 'weight_to_casi_input',
    'layer_casi', 'model_casi_profile',
    'activation_casi', 'gradient_casi',
]


def global_quantile_matrix(matrix_2d):
    """Quantile-map a 2D float matrix to uint8, preserving shape.

    Each value gets mapped to its rank position in [0, 255].
    Under random data, this produces a near-uniform byte distribution.

    This is the fundamental CASI preprocessing step: convert any
    numeric matrix into a byte matrix suitable for CASI analysis.

    Args:
        matrix_2d: 2D numpy array (any numeric dtype).

    Returns:
        uint8 numpy array of same shape, values in [0, 255].
    """
    flat = np.asarray(matrix_2d).flatten().astype(np.float64)
    ranks = np.argsort(np.argsort(flat)).astype(np.float64)
    quantiled = (ranks / len(ranks) * 255.999).astype(np.uint8)
    return quantiled.reshape(matrix_2d.shape)


def weight_to_casi_input(weight_tensor, min_rows=100, max_key_size=256):
    """Convert a weight tensor to CASI-compatible (N, key_size) uint8 array.

    Handles arbitrary tensor shapes:
    - 2D (out, in): use as-is, each row = one neuron
    - 1D (bias): reshape to (N, key_size) chunks
    - 3D+ (conv): reshape to (out_channels, -1)

    Args:
        weight_tensor: PyTorch tensor or numpy array.
        min_rows: Minimum rows needed for CASI.
        max_key_size: Maximum columns.

    Returns:
        uint8 ndarray of shape (N, key_size) or None if too small.
    """
    try:
        import torch
        if isinstance(weight_tensor, torch.Tensor):
            w = weight_tensor.detach().cpu().float().numpy()
        else:
            w = np.asarray(weight_tensor, dtype=np.float32)
    except ImportError:
        w = np.asarray(weight_tensor, dtype=np.float32)

    if w.ndim == 1:
        ks = min(64, len(w))
        n = len(w) // ks
        if n < 2:
            return None
        w = w[:n * ks].reshape(n, ks)
    elif w.ndim > 2:
        w = w.reshape(w.shape[0], -1)

    if w.shape[0] < min_rows and w.shape[1] >= min_rows:
        w = w.T

    if w.shape[0] < 10:
        return None

    if w.shape[1] > max_key_size:
        n_chunks = w.shape[1] // max_key_size
        w = w[:, :n_chunks * max_key_size].reshape(-1, max_key_size)

    return global_quantile_matrix(w)


def layer_casi(weight_tensor, min_rows=100):
    """Compute CASI score for a single layer's weights.

    Args:
        weight_tensor: Weight tensor (PyTorch or numpy).
        min_rows: Minimum rows for valid CASI.

    Returns:
        float CASI score, or 0.0 if tensor too small.
    """
    keys = weight_to_casi_input(weight_tensor, min_rows=min_rows)
    if keys is None:
        return 0.0
    result = compute_casi_score(keys)
    return float(result.get('casi', 0)) if isinstance(result, dict) else float(result)


def model_casi_profile(model, min_rows=50):
    """Compute per-layer CASI profile of an entire model.

    Args:
        model: PyTorch model (nn.Module).
        min_rows: Minimum rows for valid CASI.

    Returns:
        dict {layer_name: casi_score} for all parameters.
    """
    profile = {}
    try:
        for name, param in model.named_parameters():
            score = layer_casi(param, min_rows=min_rows)
            if score > 0:
                profile[name] = round(score, 4)
    except Exception:
        pass
    return profile


def activation_casi(activations, min_rows=50):
    """Compute CASI on activation tensors.

    Useful for detecting collapse in hidden representations.

    Args:
        activations: Activation tensor (batch, seq_len, hidden_dim) or
            (batch, hidden_dim).
        min_rows: Minimum rows.

    Returns:
        float CASI score.
    """
    try:
        import torch
        if isinstance(activations, torch.Tensor):
            a = activations.detach().cpu().float().numpy()
        else:
            a = np.asarray(activations, dtype=np.float32)
    except ImportError:
        a = np.asarray(activations, dtype=np.float32)

    if a.ndim == 3:
        a = a.reshape(-1, a.shape[-1])
    elif a.ndim == 1:
        return 0.0

    if a.shape[0] < min_rows:
        return 0.0

    keys = global_quantile_matrix(a)
    result = compute_casi_score(keys)
    return float(result.get('casi', 0)) if isinstance(result, dict) else float(result)


def gradient_casi(gradients, min_rows=50):
    """Compute CASI on gradient tensors.

    Gradient CASI can detect training instabilities and collapse onset.

    Args:
        gradients: Gradient tensor.
        min_rows: Minimum rows.

    Returns:
        float CASI score.
    """
    return activation_casi(gradients, min_rows=min_rows)
