#!/usr/bin/env python3
"""
CASI Channel Probe — live-casi v0.4.0

Generate files with known CASI signatures. Send through any channel.
Verify on the other side. The delta between sent and received CASI
profiles characterizes the channel.

Probe format:
    [8 bytes: magic "CASIPRO\\x00"]
    [16 bytes: probe UUID]
    [8 bytes: timestamp (epoch seconds, big-endian)]
    [4 bytes: payload size (big-endian)]
    [4 bytes: key_size used (big-endian)]
    [12 × 8 bytes: expected signal counts per strategy (float64 big-endian)]
    [32 bytes: HMAC-SHA256 of above fields]
    [... crafted payload ...]

Total header: 8 + 16 + 8 + 4 + 4 + 96 + 32 = 168 bytes

Usage:
    from live_casi.probe import generate_probe, verify_probe
    generate_probe("probe.bin")
    result = verify_probe("received.bin")

CLI:
    live-casi --probe-generate probe.bin
    live-casi --probe-verify received.bin
    live-casi --probe-compare probe.bin received.bin
"""

import os
import sys
import time
import uuid
import struct
import hashlib
import hmac
import json
import numpy as np

from .core import compute_signal, STRATEGY_NAMES

# ═══════════════════════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════════════════════

PROBE_MAGIC = b'CASIPRO\x00'
PROBE_HEADER_SIZE = 168  # 8 + 16 + 8 + 4 + 4 + 96 + 32
PROBE_VERSION = 1
DEFAULT_PROBE_SIZE = 65536  # 64 KB payload
DEFAULT_KEY_SIZE = 32

# HMAC key — embedded in the tool, not secret (probe integrity, not secrecy)
_HMAC_KEY = b'live-casi-channel-probe-v1-integrity'

# Channel classification thresholds
THRESHOLD_TRANSPARENT = 0.15   # max relative delta for TRANSPARENT
THRESHOLD_ENCRYPTED = 0.80     # min strategies disrupted for ENCRYPTED


# ═══════════════════════════════════════════════════════════════
# PAYLOAD CRAFTING — Generate bytes with known CASI signatures
# ═══════════════════════════════════════════════════════════════

def _craft_payload(size, key_size=32, seed=None):
    """Craft a payload with specific, reproducible CASI signals.

    Strategy:
    - Start with random base (os.urandom)
    - Inject controlled patterns that trigger specific strategies
    - Record what signals we expect

    The payload has 5 zones:
    1. Random zone (40%): true random, should produce ~0 signal
    2. Block repeat zone (15%): repeated 16-byte blocks → triggers block_repetition
    3. Byte bias zone (15%): biased byte distribution → triggers byte_frequency
    4. Sequential zone (15%): incrementing counters → triggers seq_correlation
    5. Periodic zone (15%): periodic bit pattern → triggers spectral + autocorrelation

    Returns:
        (payload_bytes, expected_signals): payload and expected signal profile
    """
    if seed is not None:
        rng = np.random.RandomState(seed)
    else:
        rng = np.random.RandomState(int.from_bytes(os.urandom(4), 'big'))

    # Zone sizes (must sum to size)
    z_random = int(size * 0.40)
    z_repeat = int(size * 0.15)
    z_bias = int(size * 0.15)
    z_seq = int(size * 0.15)
    z_periodic = size - z_random - z_repeat - z_bias - z_seq

    parts = []

    # Zone 1: True random
    parts.append(rng.bytes(z_random))

    # Zone 2: Repeated blocks (trigger block_repetition)
    block = rng.bytes(16)
    n_repeats = z_repeat // 16
    parts.append(block * n_repeats + rng.bytes(z_repeat % 16))

    # Zone 3: Biased byte distribution (trigger byte_frequency)
    # Bias towards low bytes (0x00-0x3F) — 75% of bytes from this range
    biased = bytearray(z_bias)
    for i in range(z_bias):
        if rng.random() < 0.75:
            biased[i] = rng.randint(0, 64)
        else:
            biased[i] = rng.randint(0, 256)
    parts.append(bytes(biased))

    # Zone 4: Sequential counter (trigger seq_correlation)
    seq = bytearray(z_seq)
    for i in range(z_seq):
        seq[i] = i % 256
    parts.append(bytes(seq))

    # Zone 5: Periodic pattern (trigger spectral + autocorrelation)
    period = 32  # 32-byte period
    pattern = rng.bytes(period)
    n_periods = z_periodic // period
    parts.append(pattern * n_periods + rng.bytes(z_periodic % period))

    payload = b''.join(parts)
    assert len(payload) == size

    # Now compute actual expected signals by running CASI on this payload
    n_keys = len(payload) // key_size
    if n_keys < 100:
        n_keys = 100  # minimum for meaningful signal
    keys = np.frombuffer(payload[:n_keys * key_size], dtype=np.uint8).reshape(-1, key_size)
    expected = compute_signal(keys)

    return payload, expected


# ═══════════════════════════════════════════════════════════════
# PROBE GENERATION
# ═══════════════════════════════════════════════════════════════

def generate_probe(output_path, size=DEFAULT_PROBE_SIZE, key_size=DEFAULT_KEY_SIZE, seed=None):
    """Generate a CASI channel probe file.

    Args:
        output_path: path to write the probe file
        size: payload size in bytes (default 64KB)
        key_size: key size for CASI analysis (default 32)
        seed: random seed for reproducibility (None = random)

    Returns:
        dict with probe_id, expected_signals, file_size
    """
    # Generate probe UUID
    probe_id = uuid.uuid4()
    timestamp = int(time.time())

    # Craft payload with known signals
    payload, expected_signals = _craft_payload(size, key_size=key_size, seed=seed)

    # Build header
    header = bytearray()
    header.extend(PROBE_MAGIC)                                    # 8 bytes
    header.extend(probe_id.bytes)                                 # 16 bytes
    header.extend(struct.pack('>Q', timestamp))                   # 8 bytes
    header.extend(struct.pack('>I', size))                        # 4 bytes
    header.extend(struct.pack('>I', key_size))                    # 4 bytes

    # Expected signal counts per strategy (12 × float64)
    for strategy in STRATEGY_NAMES:
        val = float(expected_signals.get(strategy, 0))
        header.extend(struct.pack('>d', val))                     # 8 bytes each

    # HMAC-SHA256 over all header fields
    mac = hmac.new(_HMAC_KEY, bytes(header), hashlib.sha256).digest()
    header.extend(mac)                                            # 32 bytes

    assert len(header) == PROBE_HEADER_SIZE

    # Write file
    with open(output_path, 'wb') as f:
        f.write(header)
        f.write(payload)

    file_size = PROBE_HEADER_SIZE + size

    return {
        'probe_id': str(probe_id),
        'timestamp': timestamp,
        'payload_size': size,
        'key_size': key_size,
        'file_size': file_size,
        'output_path': output_path,
        'expected_signals': {s: expected_signals.get(s, 0) for s in STRATEGY_NAMES},
        'expected_total': expected_signals.get('total', 0),
    }


# ═══════════════════════════════════════════════════════════════
# PROBE VERIFICATION
# ═══════════════════════════════════════════════════════════════

def verify_probe(filepath, key_size=None):
    """Verify a received probe and characterize the channel.

    Args:
        filepath: path to the received probe file
        key_size: override key_size (None = use header value)

    Returns:
        dict with: probe_id, header_intact, channel_class, per-strategy deltas,
                   expected vs actual signals, verdict
    """
    with open(filepath, 'rb') as f:
        data = f.read()

    if len(data) < PROBE_HEADER_SIZE:
        return {
            'error': f'File too small ({len(data)} bytes, need {PROBE_HEADER_SIZE})',
            'channel_class': 'CORRUPTED',
        }

    # Parse header
    magic = data[:8]
    if magic != PROBE_MAGIC:
        return {
            'error': f'Not a CASI probe file (magic: {magic!r})',
            'channel_class': 'CORRUPTED',
        }

    probe_id = uuid.UUID(bytes=data[8:24])
    timestamp = struct.unpack('>Q', data[24:32])[0]
    payload_size = struct.unpack('>I', data[32:36])[0]
    header_key_size = struct.unpack('>I', data[36:40])[0]
    if key_size is None:
        key_size = header_key_size

    # Read expected signals
    expected = {}
    offset = 40
    for strategy in STRATEGY_NAMES:
        val = struct.unpack('>d', data[offset:offset+8])[0]
        expected[strategy] = val
        offset += 8

    # Verify HMAC
    stored_mac = data[offset:offset+32]
    computed_mac = hmac.new(_HMAC_KEY, data[:offset], hashlib.sha256).digest()
    header_intact = hmac.compare_digest(stored_mac, computed_mac)

    # Extract payload
    payload = data[PROBE_HEADER_SIZE:]

    # Run CASI on received payload
    n_keys = len(payload) // key_size
    if n_keys < 10:
        return {
            'probe_id': str(probe_id),
            'header_intact': header_intact,
            'error': f'Payload too small for analysis ({len(payload)} bytes, {n_keys} keys)',
            'channel_class': 'CORRUPTED',
        }

    keys = np.frombuffer(
        payload[:n_keys * key_size], dtype=np.uint8
    ).reshape(-1, key_size)
    actual = compute_signal(keys)

    # Compute per-strategy delta
    deltas = {}
    for strategy in STRATEGY_NAMES:
        exp = expected.get(strategy, 0)
        act = actual.get(strategy, 0)
        if exp > 0:
            delta = abs(act - exp) / exp
        elif act > 0:
            delta = 1.0  # signal appeared where none expected
        else:
            delta = 0.0  # both zero
        deltas[strategy] = {
            'expected': exp,
            'actual': act,
            'abs_delta': abs(act - exp),
            'rel_delta': delta,
        }

    # Classify channel
    channel_class = _classify_channel(deltas, header_intact)

    return {
        'probe_id': str(probe_id),
        'timestamp': timestamp,
        'payload_size': payload_size,
        'received_size': len(payload),
        'key_size': key_size,
        'header_intact': header_intact,
        'channel_class': channel_class,
        'deltas': deltas,
        'expected_total': sum(expected.get(s, 0) for s in STRATEGY_NAMES),
        'actual_total': actual.get('total', 0),
        'verdict': _channel_verdict(channel_class),
    }


def _classify_channel(deltas, header_intact):
    """Classify channel behavior from per-strategy deltas."""
    if not header_intact:
        return 'MODIFIED'

    rel_deltas = [d['rel_delta'] for d in deltas.values()]
    n_strategies = len(rel_deltas)

    # Count strategies with significant change
    n_changed = sum(1 for d in rel_deltas if d > THRESHOLD_TRANSPARENT)
    n_destroyed = sum(1 for d in rel_deltas if d > 0.5)

    # All deltas small → transparent channel
    if all(d <= THRESHOLD_TRANSPARENT for d in rel_deltas):
        return 'TRANSPARENT'

    # Most strategies disrupted → encrypted (signals destroyed by encryption)
    if n_destroyed / n_strategies >= THRESHOLD_ENCRYPTED:
        return 'ENCRYPTED'

    # Some strategies changed, others preserved → re-encoded
    if n_changed > 0:
        return 'RE_ENCODED'

    return 'TRANSPARENT'


def _channel_verdict(channel_class):
    """Human-readable verdict for channel class."""
    return {
        'TRANSPARENT': 'Channel did not modify the data — binary-transparent transfer',
        'ENCRYPTED': 'Channel applied encryption — probe signals destroyed (expected for secure channels)',
        'RE_ENCODED': 'Channel partially modified the data — possible re-encoding, compression, or format conversion',
        'MODIFIED': 'Probe header was modified — file format not preserved (possible binary transformation)',
        'CORRUPTED': 'Probe could not be parsed — file corrupted or truncated',
    }.get(channel_class, 'Unknown channel behavior')


# ═══════════════════════════════════════════════════════════════
# PROBE COMPARISON (side-by-side)
# ═══════════════════════════════════════════════════════════════

def compare_probes(original_path, received_path, key_size=None):
    """Compare original and received probe files side-by-side.

    Args:
        original_path: path to the original probe
        received_path: path to the received probe

    Returns:
        dict with original signals, received signals, deltas, channel class
    """
    # Read and verify both
    original = verify_probe(original_path, key_size=key_size)
    received = verify_probe(received_path, key_size=key_size)

    # Byte-level comparison
    with open(original_path, 'rb') as f:
        orig_bytes = f.read()
    with open(received_path, 'rb') as f:
        recv_bytes = f.read()

    # Check if files are identical
    identical = orig_bytes == recv_bytes
    size_diff = len(recv_bytes) - len(orig_bytes)

    # Byte-level difference in payload
    orig_payload = orig_bytes[PROBE_HEADER_SIZE:]
    recv_payload = recv_bytes[PROBE_HEADER_SIZE:]
    min_len = min(len(orig_payload), len(recv_payload))

    if min_len > 0:
        orig_arr = np.frombuffer(orig_payload[:min_len], dtype=np.uint8)
        recv_arr = np.frombuffer(recv_payload[:min_len], dtype=np.uint8)
        bytes_changed = int(np.sum(orig_arr != recv_arr))
        change_ratio = bytes_changed / min_len
    else:
        bytes_changed = 0
        change_ratio = 0.0

    return {
        'identical': identical,
        'size_diff': size_diff,
        'bytes_changed': bytes_changed,
        'change_ratio': change_ratio,
        'original': {
            'probe_id': original.get('probe_id'),
            'header_intact': original.get('header_intact'),
            'expected_total': original.get('expected_total', 0),
            'actual_total': original.get('actual_total', 0),
        },
        'received': {
            'probe_id': received.get('probe_id'),
            'header_intact': received.get('header_intact'),
            'expected_total': received.get('expected_total', 0),
            'actual_total': received.get('actual_total', 0),
            'channel_class': received.get('channel_class'),
            'verdict': received.get('verdict'),
        },
        'deltas': received.get('deltas', {}),
    }


# ═══════════════════════════════════════════════════════════════
# CLI HANDLERS
# ═══════════════════════════════════════════════════════════════

def run_probe_generate(args):
    """CLI handler for --probe-generate."""
    output_path = args.probe_generate
    size = getattr(args, 'probe_size', DEFAULT_PROBE_SIZE) or DEFAULT_PROBE_SIZE

    result = generate_probe(output_path, size=size)

    print(f"CASI Channel Probe Generated")
    print(f"{'='*50}")
    print(f"  Probe ID:     {result['probe_id']}")
    print(f"  Payload:      {result['payload_size']:,} bytes")
    print(f"  File size:    {result['file_size']:,} bytes")
    print(f"  Key size:     {result['key_size']} bytes")
    print(f"  Output:       {result['output_path']}")
    print(f"\nExpected signal profile:")
    for strategy in STRATEGY_NAMES:
        val = result['expected_signals'][strategy]
        bar = '#' * min(int(val / 50), 40) if val > 0 else '-'
        print(f"  {strategy:20s}  {val:8.0f}  {bar}")
    print(f"  {'TOTAL':20s}  {result['expected_total']:8.0f}")
    print(f"\nSend this file through any channel, then verify with:")
    print(f"  live-casi --probe-verify <received_file>")

    if getattr(args, 'json', False):
        print(json.dumps(result, indent=2))


def run_probe_verify(args):
    """CLI handler for --probe-verify."""
    filepath = args.probe_verify

    result = verify_probe(filepath)

    if 'error' in result:
        print(f"ERROR: {result['error']}", file=sys.stderr)
        sys.exit(1)

    # Color codes
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

    colors = {
        'TRANSPARENT': GREEN,
        'ENCRYPTED': GREEN,  # encrypted = good (secure channel)
        'RE_ENCODED': YELLOW,
        'MODIFIED': RED,
        'CORRUPTED': RED,
    }
    cc = result['channel_class']
    color = colors.get(cc, RESET)

    print(f"CASI Channel Probe Verification")
    print(f"{'='*60}")
    print(f"  Probe ID:       {result['probe_id']}")
    print(f"  Header intact:  {'YES' if result['header_intact'] else 'NO !!!'}")
    print(f"  Channel class:  {color}{BOLD}{cc}{RESET}")
    print(f"  Verdict:        {result['verdict']}")
    print(f"  Payload:        {result['received_size']:,} bytes received "
          f"(expected {result['payload_size']:,})")

    print(f"\nPer-strategy analysis:")
    print(f"  {'Strategy':20s}  {'Expected':>10s}  {'Actual':>10s}  {'Delta':>8s}  {'Status':>10s}")
    print(f"  {'-'*20}  {'-'*10}  {'-'*10}  {'-'*8}  {'-'*10}")

    for strategy in STRATEGY_NAMES:
        d = result['deltas'].get(strategy, {})
        exp = d.get('expected', 0)
        act = d.get('actual', 0)
        rel = d.get('rel_delta', 0)

        if rel <= THRESHOLD_TRANSPARENT:
            status = f"{GREEN}MATCH{RESET}"
        elif rel <= 0.5:
            status = f"{YELLOW}SHIFTED{RESET}"
        else:
            status = f"{RED}CHANGED{RESET}"

        print(f"  {strategy:20s}  {exp:10.0f}  {act:10.0f}  {rel:7.1%}  {status}")

    print(f"\n  Expected total: {result['expected_total']:.0f}")
    print(f"  Actual total:   {result['actual_total']:.0f}")

    if getattr(args, 'json', False):
        print(json.dumps(result, indent=2, default=str))


def run_probe_compare(args):
    """CLI handler for --probe-compare."""
    original = args.probe_compare[0]
    received = args.probe_compare[1]

    result = compare_probes(original, received)

    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

    print(f"CASI Channel Probe Comparison")
    print(f"{'='*60}")
    print(f"  Original:       {original}")
    print(f"  Received:       {received}")
    print(f"  Identical:      {'YES' if result['identical'] else 'NO'}")
    print(f"  Size diff:      {result['size_diff']:+d} bytes")
    print(f"  Bytes changed:  {result['bytes_changed']:,} / "
          f"{result['bytes_changed'] + (1 if result['change_ratio'] == 0 else int(result['bytes_changed'] / max(result['change_ratio'], 0.001))):,} "
          f"({result['change_ratio']:.1%})")

    cc = result['received'].get('channel_class', 'UNKNOWN')
    colors = {'TRANSPARENT': GREEN, 'ENCRYPTED': GREEN, 'RE_ENCODED': YELLOW,
              'MODIFIED': RED, 'CORRUPTED': RED}
    color = colors.get(cc, RESET)
    print(f"  Channel class:  {color}{BOLD}{cc}{RESET}")
    print(f"  Verdict:        {result['received'].get('verdict', 'N/A')}")

    if result['deltas']:
        print(f"\nPer-strategy delta:")
        for strategy in STRATEGY_NAMES:
            d = result['deltas'].get(strategy, {})
            rel = d.get('rel_delta', 0)
            bar_len = min(int(rel * 40), 40)
            bar = '█' * bar_len if bar_len > 0 else '·'
            print(f"  {strategy:20s}  {rel:7.1%}  {bar}")

    if getattr(args, 'json', False):
        print(json.dumps(result, indent=2, default=str))
