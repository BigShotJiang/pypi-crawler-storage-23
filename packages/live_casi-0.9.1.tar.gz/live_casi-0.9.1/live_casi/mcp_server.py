#!/usr/bin/env python3
"""
live-casi MCP Server — Use live-casi directly from Claude.

Install:
    pip install live-casi mcp

Add to Claude settings (~/.claude/claude_desktop_config.json):
    {
      "mcpServers": {
        "live-casi": {
          "command": "python3",
          "args": ["-m", "live_casi.mcp_server"]
        }
      }
    }

Then just ask Claude:
    "Check this dissertation for AI"
    "Is this file encrypted?"
    "Who wrote this text?"
"""

import os
import sys
import json
import tempfile

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("live-casi")


# ═══════════════════════════════════════════════════════════════════
# AI TEXT DETECTION
# ═══════════════════════════════════════════════════════════════════

@mcp.tool()
def check_ai(text: str, language: str = "de") -> str:
    """Check if text was written by AI (ChatGPT, DeepL, etc.).

    Runs 5-layer analysis: token distribution, CASI structural profile,
    ChatGPT phrase detection, DeepL marker detection, style consistency.

    Args:
        text: The text to check. Paste the full text here.
        language: 'de' for German, 'en' for English.

    Returns:
        Verdict (CLEAN/LOW_RISK/SUSPICIOUS/HIGH_RISK), AI probability,
        detected flags, and layer-by-layer details.
    """
    from .academia import analyze_text

    result = analyze_text(text, language=language)

    output = []
    output.append(f"VERDICT: {result.verdict}")
    output.append(f"AI Probability: {result.ai_probability}%")
    output.append(f"Flags: {', '.join(result.flags) if result.flags else 'none'}")
    output.append(f"Words: {result.word_count}")
    output.append("")

    for layer, data in result.layers.items():
        output.append(f"{layer}:")
        if isinstance(data, dict):
            for k, v in data.items():
                if k in ('top_phrases', 'top_markers', 'outliers'):
                    if v:
                        output.append(f"  {k}: {v[:3]}")
                elif k == 'heatmap':
                    output.append(f"  heatmap: [{v}]")
                    output.append(f"  (! = suspicious, # = elevated, + = slight, . = normal, _ = low)")
                else:
                    output.append(f"  {k}: {v}")

    return '\n'.join(output)


@mcp.tool()
def check_ai_pdf(filepath: str, language: str = "de") -> str:
    """Check a PDF document (dissertation, thesis, paper) for AI content.

    Extracts text from PDF, then runs full 5-layer AI detection.
    Requires pdftotext to be installed.

    Args:
        filepath: Absolute path to the PDF file.
        language: 'de' for German, 'en' for English.

    Returns:
        Full analysis report with verdict, flags, and suspicious passages.
    """
    from .academia import analyze_pdf

    if not os.path.exists(filepath):
        return f"Error: File not found: {filepath}"

    result = analyze_pdf(filepath, language=language)

    output = []
    output.append(f"File: {result.filename}")
    output.append(f"VERDICT: {result.verdict}")
    output.append(f"AI Probability: {result.ai_probability}%")
    output.append(f"Flags: {', '.join(result.flags) if result.flags else 'none'}")
    output.append(f"Words: {result.word_count}")
    output.append("")

    for layer, data in result.layers.items():
        output.append(f"{layer}:")
        if isinstance(data, dict):
            for k, v in data.items():
                if k in ('top_phrases', 'top_markers'):
                    if v:
                        output.append(f"  {k}: {v[:5]}")
                elif k == 'outliers':
                    if v:
                        output.append(f"  suspicious passages:")
                        for o in v[:3]:
                            output.append(f"    @{o['position_pct']}%: z={o['z_score']}")
                elif k == 'heatmap':
                    output.append(f"  heatmap: [{v}]")
                    output.append(f"  (! = suspicious, # = elevated, + = slight, . = normal)")
                else:
                    output.append(f"  {k}: {v}")

    return '\n'.join(output)


@mcp.tool()
def detect_ai_tools(text: str, language: str = "de") -> str:
    """Detect which specific AI tools were used (ChatGPT, DeepL, QuillBot).

    Analyzes text for tool-specific linguistic signatures.

    Args:
        text: The text to analyze.
        language: 'de' for German, 'en' for English.

    Returns:
        Per-tool analysis with detected markers and multi-signal score.
    """
    from .tool_signatures import detect_tools, multi_signal_score

    result = detect_tools(text, language=language)
    score = multi_signal_score(text, language=language)

    output = []
    output.append(f"AI Score: {score}/100")
    output.append(f"Flags: {', '.join(result['flags']) if result['flags'] else 'none'}")
    output.append("")

    gpt = result['chatgpt']
    output.append(f"ChatGPT indicators:")
    output.append(f"  Phrase density: {gpt['phrase_density']}/1K words")
    output.append(f"  Starter %: {gpt['starter_pct']}%")
    output.append(f"  Hedge density: {gpt['hedge_density']}/1K words")
    if gpt.get('found_phrases'):
        output.append(f"  Found: {gpt['found_phrases'][:5]}")

    dl = result['deepl']
    output.append(f"DeepL indicators:")
    output.append(f"  Marker density: {dl['marker_density']}/1K words")
    output.append(f"  Type-Token-Ratio: {dl['ttr']}")
    if dl.get('found_markers'):
        output.append(f"  Found: {dl['found_markers'][:5]}")

    para = result['paraphrase']
    output.append(f"Paraphrasing indicators:")
    output.append(f"  Sentence CV: {para['sent_cv']} (low = uniform = suspicious)")
    output.append(f"  Repetition ratio: {para['repetition_ratio']}")

    return '\n'.join(output)


# ═══════════════════════════════════════════════════════════════════
# AUTHOR FINGERPRINTING
# ═══════════════════════════════════════════════════════════════════

@mcp.tool()
def fingerprint_text(text: str) -> str:
    """Compute a stylometric fingerprint for a text.

    Returns a 256-dimensional byte frequency vector that characterizes
    the writing style. Use to compare texts by the same/different authors.

    Args:
        text: The text to fingerprint.

    Returns:
        Fingerprint summary with key statistics.
    """
    from .fingerprint import byte_vector, full_vector
    import numpy as np

    bv = byte_vector(text)
    fv = full_vector(text)

    # Key stats
    top_bytes = np.argsort(bv)[-10:][::-1]

    output = []
    output.append(f"Fingerprint computed ({len(text)} chars)")
    output.append(f"  Byte vector: {bv.shape[0]}d, entropy={float(-np.sum(bv[bv>0] * np.log2(bv[bv>0]))):.2f}")
    output.append(f"  Full vector: {fv.shape[0]}d")
    output.append(f"  Top bytes: {list(top_bytes)} ({[chr(b) if 32 <= b < 127 else f'0x{b:02x}' for b in top_bytes]})")

    return '\n'.join(output)


@mcp.tool()
def compare_authors(text_a: str, text_b: str) -> str:
    """Compare two texts to see if they were written by the same author.

    Uses cosine similarity on byte-frequency and full stylometric vectors.

    Args:
        text_a: First text sample.
        text_b: Second text sample.

    Returns:
        Similarity score and verdict (same/different author).
    """
    from .fingerprint import byte_vector, full_vector, cosine_similarity_vec

    bv_a = byte_vector(text_a)
    bv_b = byte_vector(text_b)
    fv_a = full_vector(text_a)
    fv_b = full_vector(text_b)

    byte_sim = cosine_similarity_vec(bv_a, bv_b)
    full_sim = cosine_similarity_vec(fv_a, fv_b)
    fused = 0.7 * byte_sim + 0.3 * full_sim

    if fused > 0.95:
        verdict = "VERY LIKELY same author"
    elif fused > 0.90:
        verdict = "LIKELY same author"
    elif fused > 0.85:
        verdict = "POSSIBLY same author"
    else:
        verdict = "LIKELY different authors"

    return (f"Similarity: {fused:.4f}\n"
            f"  Byte similarity: {byte_sim:.4f}\n"
            f"  Full similarity: {full_sim:.4f}\n"
            f"Verdict: {verdict}")


# ═══════════════════════════════════════════════════════════════════
# ENCRYPTION VALIDATION
# ═══════════════════════════════════════════════════════════════════

@mcp.tool()
def check_encryption(filepath: str) -> str:
    """Check if a binary file is properly encrypted.

    Reads the file, computes CASI score. CASI ~1.0 = secure,
    CASI > 2.0 = weak, CASI > 10.0 = broken/not encrypted.

    Args:
        filepath: Absolute path to the binary file.

    Returns:
        CASI score, verdict, and per-strategy breakdown.
    """
    import numpy as np
    from .core import compute_casi_score

    if not os.path.exists(filepath):
        return f"Error: File not found: {filepath}"

    data = open(filepath, 'rb').read()
    if len(data) < 1000:
        return f"Error: File too small ({len(data)} bytes)"

    # Reshape to matrix
    key_size = 256
    n_keys = min(len(data) // key_size, 50000)
    keys = np.frombuffer(data[:n_keys * key_size], dtype=np.uint8).reshape(n_keys, key_size)

    result = compute_casi_score(keys)
    casi = result.get('casi', 0) if isinstance(result, dict) else result

    if casi < 1.5:
        verdict = "SECURE — looks properly encrypted"
    elif casi < 5.0:
        verdict = "SUSPICIOUS — possible weakness"
    elif casi < 20.0:
        verdict = "WEAK — structural patterns detected"
    else:
        verdict = "BROKEN — not properly encrypted"

    output = []
    output.append(f"File: {os.path.basename(filepath)} ({len(data)} bytes)")
    output.append(f"CASI: {casi:.2f}")
    output.append(f"Verdict: {verdict}")

    return '\n'.join(output)


@mcp.tool()
def identify_cipher(filepath: str) -> str:
    """Identify what cipher was used to encrypt a file.

    Blind identification using CASI signal fingerprinting across
    8 cipher families.

    Args:
        filepath: Absolute path to encrypted binary file.

    Returns:
        Most likely cipher, confidence, and alternatives.
    """
    import numpy as np
    from . import identify_cipher as _identify

    if not os.path.exists(filepath):
        return f"Error: File not found: {filepath}"

    data = open(filepath, 'rb').read()
    key_size = 32
    n_keys = min(len(data) // key_size, 50000)
    keys = np.frombuffer(data[:n_keys * key_size], dtype=np.uint8).reshape(n_keys, key_size)

    result = _identify(keys)

    output = []
    output.append(f"File: {os.path.basename(filepath)}")
    if isinstance(result, dict):
        output.append(f"Cipher: {result.get('cipher', 'unknown')}")
        output.append(f"Confidence: {result.get('confidence', 0)}%")
        if 'alternatives' in result:
            output.append(f"Alternatives: {result['alternatives']}")
    else:
        output.append(f"Result: {result}")

    return '\n'.join(output)


# ═══════════════════════════════════════════════════════════════════
# MODEL COLLAPSE
# ═══════════════════════════════════════════════════════════════════

@mcp.tool()
def check_collapse(generated_texts: str, reference_texts: str) -> str:
    """Check if AI-generated texts show signs of model collapse.

    Compares structural properties of generated text against known
    good reference text. Rising CASI = progressive collapse.

    Args:
        generated_texts: Newline-separated generated texts to check.
        reference_texts: Newline-separated known good human texts.

    Returns:
        Collapse risk assessment with score and recommendations.
    """
    from .collapse import measure_collapse_risk

    gen = [t.strip() for t in generated_texts.split('\n') if t.strip()]
    ref = [t.strip() for t in reference_texts.split('\n') if t.strip()]

    if len(gen) < 3 or len(ref) < 3:
        return "Error: Need at least 3 texts in each group (separate with newlines)"

    result = measure_collapse_risk(gen, ref)

    output = []
    output.append(f"Verdict: {result['verdict']}")
    output.append(f"Risk Score: {result['risk_score']}/100")
    output.append(f"Generated L1: {result['gen_l1']}")
    output.append(f"Reference L1: {result['ref_l1']}")
    output.append(f"Divergence: {result['divergence']}")

    if result['verdict'] == 'HEALTHY':
        output.append("\nNo signs of collapse. Model output looks healthy.")
    elif result['verdict'] == 'EARLY_WARNING':
        output.append("\nEarly signs of drift. Consider mixing in more real data.")
    elif result['verdict'] == 'MODERATE_COLLAPSE':
        output.append("\nSignificant collapse detected. Stop self-training, increase data diversity.")
    else:
        output.append("\nSevere collapse. Model output has lost diversity. Retrain from checkpoint.")

    return '\n'.join(output)


# ═══════════════════════════════════════════════════════════════════
# SCAN / UTILITY
# ═══════════════════════════════════════════════════════════════════

@mcp.tool()
def scan_binary(filepath: str) -> str:
    """Scan a binary/firmware file for encrypted vs plaintext regions.

    Slides a window across the file, computing CASI at each position.
    Groups regions as PLAINTEXT, WEAK, ENCRYPTED, or BORDERLINE.

    Args:
        filepath: Absolute path to binary file.

    Returns:
        List of detected regions with type and CASI score.
    """
    from . import scan_binary as _scan

    if not os.path.exists(filepath):
        return f"Error: File not found: {filepath}"

    data = open(filepath, 'rb').read()
    if len(data) < 10000:
        return f"Error: File too small for scanning ({len(data)} bytes)"

    regions = _scan(data)

    output = []
    output.append(f"File: {os.path.basename(filepath)} ({len(data)} bytes)")
    output.append(f"Regions found: {len(regions)}")
    output.append("")

    for r in regions[:20]:
        output.append(f"  0x{r.get('offset', 0):08x} - 0x{r.get('end', 0):08x}: "
                      f"{r.get('label', '?')} (CASI={r.get('casi', 0):.1f})")

    return '\n'.join(output)


# ═══════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════

def main():
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
