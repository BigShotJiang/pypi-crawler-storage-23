#!/usr/bin/env python3
"""
live-casi tool_signatures: Detect specific AI writing tools.

Identifies signatures of ChatGPT, DeepL Write, QuillBot, and other
AI writing tools based on linguistic markers and cross-referencing.

Usage:
    from live_casi.tool_signatures import detect_tools, multi_signal_score

    result = detect_tools(text, language='de')
    score = multi_signal_score(text, language='de')

Validated:
    - 402 German dissertations: 5/10 metrics significant (p<0.05)
    - Multi-signal (>=3 flags): Pre=0.5% vs Post=3.4% (Chi²=5.31, p=0.021)
    - ChatGPT Starters: p=0.007, Hedging: p=0.001, DeepL: p=0.047

Reference:
"""

import re
import numpy as np
from collections import Counter

__all__ = [
    'detect_tools', 'multi_signal_score',
    'chatgpt_markers', 'deepl_markers', 'paraphrase_markers',
    'TOOL_SIGNATURES',
]


# ═══════════════════════════════════════════════════════════════════
# TOOL SIGNATURE DATABASES
# ═══════════════════════════════════════════════════════════════════

TOOL_SIGNATURES = {
    'chatgpt': {
        'de': {
            'phrases': [
                "es ist wichtig zu beachten", "es ist erwähnenswert",
                "zusammenfassend lässt sich sagen", "zusammenfassend lässt sich festhalten",
                "in diesem zusammenhang", "in diesem kontext",
                "darüber hinaus", "des weiteren", "es sei darauf hingewiesen",
                "eine wichtige rolle spielt", "von entscheidender bedeutung",
                "von großer bedeutung", "eine zentrale rolle",
                "ein wesentlicher aspekt", "eine umfassende analyse",
                "lässt sich feststellen", "kann festgestellt werden",
                "es zeigt sich, dass", "wie bereits erwähnt",
                "abschließend lässt sich", "insgesamt zeigt sich",
                "die ergebnisse deuten darauf hin", "es konnte gezeigt werden",
                "es ist unerlässlich", "maßgeblich beeinflusst",
            ],
            'starters': [
                "darüber hinaus", "zusammenfassend", "insgesamt", "abschließend",
                "des weiteren", "ferner", "überdies", "nichtsdestotrotz",
                "grundsätzlich", "letztendlich", "im wesentlichen", "insbesondere",
                "hervorzuheben ist", "bemerkenswert ist", "festzuhalten ist",
            ],
            'hedges': [
                "möglicherweise", "wahrscheinlich", "vermutlich", "tendenziell",
                "potenziell", "gegebenenfalls", "unter umständen",
            ],
        },
        'en': {
            'phrases': [
                "it is important to note", "it is worth noting", "it should be noted",
                "in this context", "furthermore", "moreover", "additionally",
                "plays a crucial role", "of great significance", "a comprehensive analysis",
                "it can be observed", "as previously mentioned", "in conclusion",
                "the results suggest", "it was demonstrated",
            ],
            'starters': [
                "furthermore", "moreover", "additionally", "in conclusion",
                "overall", "notably", "essentially", "fundamentally",
                "interestingly", "importantly", "significantly",
            ],
            'hedges': [
                "possibly", "probably", "presumably", "potentially",
                "perhaps", "arguably", "conceivably",
            ],
        },
    },
    'deepl': {
        'de': {
            'markers': [
                "implementiert", "adressiert", "fokussiert", "evaluiert",
                "identifiziert", "generiert", "validiert", "optimiert",
                "wurde durchgeführt", "wurde festgestellt", "wurde beobachtet",
                "wurde nachgewiesen", "konnte bestätigt werden",
                "in bezug auf", "im hinblick auf", "mit bezug auf",
                "hinsichtlich der", "in anbetracht",
            ],
        },
        'en': {
            'markers': [
                "implemented", "addressed", "focused", "evaluated",
                "identified", "generated", "validated", "optimized",
                "was carried out", "was determined", "was observed",
                "with regard to", "in terms of", "with respect to",
            ],
        },
    },
}

# Thresholds (calibrated on 402 German dissertations, 2026-02-27)
DEFAULT_THRESHOLDS = {
    'phrase_density': 0.75,
    'starter_pct': 1.5,
    'hedge_density': 0.80,
    'deepl_density': 1.0,
    'sent_cv_low': 0.55,
    'ttr_low': 0.72,
}


# ═══════════════════════════════════════════════════════════════════
# DETECTION FUNCTIONS
# ═══════════════════════════════════════════════════════════════════

def chatgpt_markers(text, language='de'):
    """Detect ChatGPT writing patterns.

    Returns:
        dict with phrase_density, starter_pct, hedge_density, found_phrases.
    """
    text_lower = text.lower()
    n_words = len(text.split())
    if n_words < 50:
        return {'phrase_density': 0, 'starter_pct': 0, 'hedge_density': 0}

    sigs = TOOL_SIGNATURES['chatgpt'].get(language, TOOL_SIGNATURES['chatgpt']['en'])

    phrase_count = sum(text_lower.count(p) for p in sigs['phrases'])
    phrase_density = phrase_count / (n_words / 1000)

    sentences = re.split(r'[.!?]\s+', text)
    starter_count = sum(1 for s in sentences
                        if any(s.strip().lower().startswith(st) for st in sigs['starters']))
    starter_pct = starter_count / max(len(sentences), 1) * 100

    hedge_count = sum(text_lower.count(h) for h in sigs['hedges'])
    hedge_density = hedge_count / (n_words / 1000)

    found = [(p, text_lower.count(p)) for p in sigs['phrases'] if text_lower.count(p) > 0]
    found.sort(key=lambda x: -x[1])

    return {
        'phrase_density': round(phrase_density, 2),
        'starter_pct': round(starter_pct, 1),
        'hedge_density': round(hedge_density, 2),
        'found_phrases': found[:10],
    }


def deepl_markers(text, language='de'):
    """Detect DeepL Write/Translate patterns.

    Returns:
        dict with marker_density, ttr, found_markers.
    """
    text_lower = text.lower()
    n_words = len(text.split())
    if n_words < 50:
        return {'marker_density': 0, 'ttr': 0}

    sigs = TOOL_SIGNATURES['deepl'].get(language, TOOL_SIGNATURES['deepl'].get('en', {}))
    markers = sigs.get('markers', [])

    marker_count = sum(text_lower.count(m) for m in markers)
    marker_density = marker_count / (n_words / 1000)

    # Type-Token-Ratio
    words = text_lower.split()
    window = 100
    ttrs = []
    for i in range(0, len(words) - window + 1, window):
        seg = words[i:i+window]
        ttrs.append(len(set(seg)) / len(seg))
    ttr = float(np.mean(ttrs)) if ttrs else len(set(words)) / max(len(words), 1)

    found = [(m, text_lower.count(m)) for m in markers if text_lower.count(m) > 0]
    found.sort(key=lambda x: -x[1])

    return {
        'marker_density': round(marker_density, 2),
        'ttr': round(ttr, 3),
        'found_markers': found[:10],
    }


def paraphrase_markers(text):
    """Detect paraphrasing tool patterns.

    Looks for: low sentence variety, uniform length, repeated structures.

    Returns:
        dict with sent_cv, repetition_ratio.
    """
    sentences = re.split(r'[.!?]\s+', text)
    sent_lens = [len(s.split()) for s in sentences if len(s.split()) > 3]

    if len(sent_lens) < 5:
        return {'sent_cv': 1.0, 'repetition_ratio': 0}

    sent_cv = float(np.std(sent_lens) / max(np.mean(sent_lens), 1))

    first_words = [s.strip().split()[0].lower() for s in sentences if s.strip()]
    if first_words:
        fw_counts = Counter(first_words)
        repetition_ratio = max(fw_counts.values()) / len(first_words)
    else:
        repetition_ratio = 0

    return {
        'sent_cv': round(sent_cv, 3),
        'repetition_ratio': round(repetition_ratio, 3),
    }


def detect_tools(text, language='de', thresholds=None):
    """Detect all AI writing tools in text.

    Args:
        text: Text to analyze.
        language: 'de' or 'en'.
        thresholds: Custom thresholds dict.

    Returns:
        dict with per-tool results, flags, and multi-signal score.
    """
    if thresholds is None:
        thresholds = DEFAULT_THRESHOLDS

    gpt = chatgpt_markers(text, language)
    dl = deepl_markers(text, language)
    para = paraphrase_markers(text)

    flags = []
    if gpt['phrase_density'] > thresholds['phrase_density']:
        flags.append('ChatGPT-Phrases')
    if gpt['starter_pct'] > thresholds['starter_pct']:
        flags.append('ChatGPT-Starters')
    if gpt['hedge_density'] > thresholds['hedge_density']:
        flags.append('Hedging')
    if dl['marker_density'] > thresholds['deepl_density']:
        flags.append('DeepL-Markers')
    if para['sent_cv'] < thresholds['sent_cv_low']:
        flags.append('Uniform-Sentences')
    if dl['ttr'] < thresholds['ttr_low']:
        flags.append('Low-TTR')

    return {
        'chatgpt': gpt,
        'deepl': dl,
        'paraphrase': para,
        'flags': flags,
        'n_flags': len(flags),
    }


def multi_signal_score(text, language='de', thresholds=None):
    """Compute multi-signal AI score (0-100).

    Higher = more likely AI-assisted. Based on cross-referencing
    multiple tool signatures.

    Args:
        text: Text to analyze.
        language: 'de' or 'en'.
        thresholds: Custom thresholds.

    Returns:
        int score 0-100.
    """
    result = detect_tools(text, language, thresholds)
    n = result['n_flags']
    score_map = {0: 5, 1: 15, 2: 40, 3: 70, 4: 85, 5: 92, 6: 97}
    return score_map.get(min(n, 6), 97)
