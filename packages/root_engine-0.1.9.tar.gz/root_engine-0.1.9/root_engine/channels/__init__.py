"""Chat channels module with plugin architecture."""

from root_engine.channels.base import BaseChannel
from root_engine.channels.manager import ChannelManager

__all__ = ["BaseChannel", "ChannelManager"]
