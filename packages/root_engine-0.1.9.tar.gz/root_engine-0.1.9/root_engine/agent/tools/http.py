"""Generic HTTP tool for REST API calls."""

import json
from typing import Any

import httpx

from root_engine.agent.tools.base import Tool
from root_engine.agent.tools.web import _validate_url

MAX_RESPONSE_CHARS = 8000
DEFAULT_TIMEOUT = 30
MAX_TIMEOUT = 120
ALLOWED_METHODS = ("get", "post", "put", "patch", "delete")


class HttpTool(Tool):
    """Make HTTP requests to any REST API."""

    name = "http"
    description = (
        "Make HTTP requests (GET, POST, PUT, PATCH, DELETE) to any REST API. "
        "Use for integrations with HubSpot, Stripe, Slack, GitHub, or any HTTP service."
    )
    parameters = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": list(ALLOWED_METHODS),
                "description": "HTTP method to use",
            },
            "url": {
                "type": "string",
                "description": "Full URL including scheme (https://...)",
            },
            "headers": {
                "type": "object",
                "description": "HTTP headers (e.g. Authorization, Content-Type)",
            },
            "body": {
                "description": "Request body — dict is sent as JSON, string is sent as-is",
            },
            "params": {
                "type": "object",
                "description": "URL query parameters",
            },
            "timeout": {
                "type": "integer",
                "description": f"Request timeout in seconds (default {DEFAULT_TIMEOUT}, max {MAX_TIMEOUT})",
                "minimum": 1,
                "maximum": MAX_TIMEOUT,
            },
        },
        "required": ["action", "url"],
    }

    async def execute(
        self,
        action: str,
        url: str,
        headers: dict[str, str] | None = None,
        body: Any = None,
        params: dict[str, str] | None = None,
        timeout: int = DEFAULT_TIMEOUT,
        **kwargs: Any,
    ) -> str:
        action = action.lower()
        if action not in ALLOWED_METHODS:
            return f"Error: unsupported action '{action}'. Must be one of: {', '.join(ALLOWED_METHODS)}"

        is_valid, error_msg = _validate_url(url)
        if not is_valid:
            return f"Error: {error_msg}"

        timeout_secs = min(int(timeout or DEFAULT_TIMEOUT), MAX_TIMEOUT)

        # Prepare body
        content: str | None = None
        json_body: Any = None
        if body is not None:
            if isinstance(body, dict):
                json_body = body
            else:
                content = str(body)

        try:
            async with httpx.AsyncClient(follow_redirects=True, max_redirects=5) as client:
                response = await client.request(
                    method=action.upper(),
                    url=url,
                    headers=headers or {},
                    params=params or {},
                    json=json_body,
                    content=content,
                    timeout=timeout_secs,
                )

            body_text = response.text
            if len(body_text) > MAX_RESPONSE_CHARS:
                body_text = body_text[:MAX_RESPONSE_CHARS] + f"\n... [truncated at {MAX_RESPONSE_CHARS} chars]"

            # Try to pretty-print JSON responses
            ctype = response.headers.get("content-type", "")
            if "application/json" in ctype:
                try:
                    body_text = json.dumps(response.json(), indent=2)
                    if len(body_text) > MAX_RESPONSE_CHARS:
                        body_text = body_text[:MAX_RESPONSE_CHARS] + f"\n... [truncated at {MAX_RESPONSE_CHARS} chars]"
                except Exception:
                    pass

            return f"Status: {response.status_code}\n\n{body_text}"
        except httpx.TimeoutException:
            return f"Error: request timed out after {timeout_secs}s"
        except Exception as e:
            return f"Error: {e}"
