"""Browser automation tool using Playwright."""

from pathlib import Path
from typing import Any

from root_engine.agent.tools.base import Tool


class BrowserTool(Tool):
    """
    Browser automation tool backed by Playwright.

    Provides a single 'browser' function to the LLM with an 'action' field.
    The browser session is lazily initialized on first use and reused across calls.
    """

    name = "browser"
    description = (
        "Control a web browser to interact with dynamic pages. "
        "Use 'snapshot' to read page content as an accessibility tree (start here). "
        "Use 'navigate', 'click', 'type', 'press', 'scroll', 'screenshot', or 'evaluate' for other actions."
    )
    parameters = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["navigate", "snapshot", "click", "type", "press", "scroll", "screenshot", "evaluate"],
                "description": (
                    "Action to perform: "
                    "'navigate' — go to a URL; "
                    "'snapshot' — get ARIA accessibility tree with [ref=eN] element markers; "
                    "'click' — click element by ref; "
                    "'type' — type text into element by ref (clears first); "
                    "'press' — send keyboard key (e.g. Enter, Tab, Escape); "
                    "'scroll' — scroll page up/down or to a ref; "
                    "'screenshot' — save PNG to workspace/screenshots/, returns path; "
                    "'evaluate' — run JavaScript, returns stringified result."
                ),
            },
            "url": {
                "type": "string",
                "description": "URL to navigate to (required for 'navigate').",
            },
            "ref": {
                "type": "string",
                "description": "Element ref from last snapshot, e.g. 'e12' (required for click/type/scroll-to-element).",
            },
            "text": {
                "type": "string",
                "description": "Text to type (for 'type') or key to press (for 'press', e.g. 'Enter', 'Tab').",
            },
            "direction": {
                "type": "string",
                "enum": ["up", "down"],
                "description": "Scroll direction (for 'scroll' without a ref).",
            },
            "script": {
                "type": "string",
                "description": "JavaScript to evaluate (for 'evaluate').",
            },
        },
        "required": ["action"],
    }

    def __init__(self, headless: bool = True, workspace: Path | None = None, channel: str = ""):
        self.headless = headless
        self.workspace = workspace
        self.channel = channel
        self._playwright = None
        self._browser = None
        self._page = None

    async def _ensure_page(self):
        """Lazily start Playwright and return the active page."""
        if self._page is not None:
            return self._page

        from playwright.async_api import async_playwright

        self._playwright = await async_playwright().start()
        launch_kwargs: dict = {"headless": self.headless}
        if self.channel:
            launch_kwargs["channel"] = self.channel
        self._browser = await self._playwright.chromium.launch(**launch_kwargs)
        self._page = await self._browser.new_page()
        return self._page

    async def close(self) -> None:
        """Shut down the browser and Playwright instance."""
        if self._browser:
            try:
                await self._browser.close()
            except Exception:
                pass
            self._browser = None
        if self._playwright:
            try:
                await self._playwright.stop()
            except Exception:
                pass
            self._playwright = None
        self._page = None

    # ------------------------------------------------------------------
    # Action handlers
    # ------------------------------------------------------------------

    async def _navigate(self, url: str) -> str:
        page = await self._ensure_page()
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        title = await page.title()
        return f"Navigated to: {page.url}\nTitle: {title}"

    async def _snapshot(self) -> str:
        page = await self._ensure_page()
        # page.aria_snapshot() (Playwright >=1.49) returns a YAML-like string with
        # built-in [ref=eN] markers on interactive elements. These refs are tracked
        # internally by Playwright and can be resolved with page.get_by_aria_ref().
        snapshot = await page.aria_snapshot()
        return snapshot or "No content in accessibility snapshot."

    async def _click(self, ref: str) -> str:
        page = await self._ensure_page()
        await page.locator(f"aria-ref={ref}").click(timeout=10000)
        return f"Clicked element {ref}"

    async def _type(self, ref: str, text: str) -> str:
        page = await self._ensure_page()
        locator = page.locator(f"aria-ref={ref}")
        await locator.clear(timeout=5000)
        await locator.press_sequentially(text, timeout=10000)
        return f"Typed '{text}' into element {ref}"

    async def _press(self, text: str) -> str:
        page = await self._ensure_page()
        await page.keyboard.press(text)
        return f"Pressed key: {text}"

    async def _scroll(self, ref: str | None, direction: str | None) -> str:
        page = await self._ensure_page()
        if ref:
            await page.locator(f"aria-ref={ref}").scroll_into_view_if_needed(timeout=5000)
            return f"Scrolled element {ref} into view"
        dy = -400 if direction == "up" else 400
        await page.mouse.wheel(0, dy)
        return f"Scrolled {direction or 'down'}"

    async def _screenshot(self) -> str:
        page = await self._ensure_page()
        base = self.workspace or Path.cwd()
        screenshots_dir = base / "screenshots"
        screenshots_dir.mkdir(parents=True, exist_ok=True)

        import time
        filename = f"screenshot_{int(time.time())}.png"
        dest = screenshots_dir / filename
        await page.screenshot(path=str(dest), full_page=False)
        return f"Screenshot saved: {dest}"

    async def _evaluate(self, script: str) -> str:
        page = await self._ensure_page()
        result = await page.evaluate(script)
        return str(result)

    # ------------------------------------------------------------------
    # Main dispatch
    # ------------------------------------------------------------------

    async def execute(self, action: str, **kwargs: Any) -> str:
        try:
            if action == "navigate":
                url = kwargs.get("url", "")
                if not url:
                    return "Error: 'url' is required for navigate"
                return await self._navigate(url)

            if action == "snapshot":
                return await self._snapshot()

            if action == "click":
                ref = kwargs.get("ref", "")
                if not ref:
                    return "Error: 'ref' is required for click"
                return await self._click(ref)

            if action == "type":
                ref = kwargs.get("ref", "")
                text = kwargs.get("text", "")
                if not ref:
                    return "Error: 'ref' is required for type"
                if not text:
                    return "Error: 'text' is required for type"
                return await self._type(ref, text)

            if action == "press":
                text = kwargs.get("text", "")
                if not text:
                    return "Error: 'text' (key name) is required for press"
                return await self._press(text)

            if action == "scroll":
                return await self._scroll(kwargs.get("ref"), kwargs.get("direction"))

            if action == "screenshot":
                return await self._screenshot()

            if action == "evaluate":
                script = kwargs.get("script", "")
                if not script:
                    return "Error: 'script' is required for evaluate"
                return await self._evaluate(script)

            return f"Error: unknown action '{action}'"

        except ImportError:
            return (
                "Error: playwright is not installed. "
                "Run: pip install 'root-engine[browser]' && playwright install chromium"
            )
        except Exception as e:
            return f"Browser error ({action}): {e}"
