"""Lightweight web UI for Root Engine."""

import asyncio
import json

from aiohttp import web

from root_engine import __version__

# ─── Embedded Assets ──────────────────────────────────────────────────────────

LOGO_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 120" width="100" height="120">
  <rect x="42" y="80" width="16" height="22" rx="3" fill="#4a5568"/>
  <line x1="42" y1="100" x2="28" y2="112" stroke="#4a5568" stroke-width="4" stroke-linecap="round"/>
  <line x1="58" y1="100" x2="72" y2="112" stroke="#4a5568" stroke-width="4" stroke-linecap="round"/>
  <line x1="50" y1="102" x2="50" y2="114" stroke="#4a5568" stroke-width="4" stroke-linecap="round"/>
  <polygon points="50,38 15,82 85,82" fill="#276749"/>
  <polygon points="50,22 22,64 78,64" fill="#2f855a"/>
  <polygon points="50,6 30,48 70,48" fill="#38a169"/>
  <rect x="33" y="50" width="34" height="24" rx="4" fill="#1a202c" opacity="0.85"/>
  <circle cx="43" cy="60" r="5" fill="#68d391"/>
  <circle cx="57" cy="60" r="5" fill="#68d391"/>
  <circle cx="43" cy="60" r="3" fill="#9ae6b4"/>
  <circle cx="57" cy="60" r="3" fill="#9ae6b4"/>
  <rect x="39" y="68" width="22" height="3" rx="1.5" fill="#4a5568"/>
  <rect x="39" y="68" width="8" height="3" rx="1.5" fill="#68d391"/>
  <line x1="50" y1="80" x2="50" y2="88" stroke="#68d391" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="50" y1="88" x2="44" y2="88" stroke="#68d391" stroke-width="1.5" stroke-linecap="round"/>
  <circle cx="44" cy="88" r="2" fill="#68d391"/>
  <line x1="50" y1="88" x2="56" y2="93" stroke="#68d391" stroke-width="1.5" stroke-linecap="round"/>
  <circle cx="56" cy="93" r="2" fill="#68d391"/>
</svg>"""

# _HTML_TEMPLATE uses __VERSION__ as a placeholder replaced at runtime.
_HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>__AGENT_NAME__</title>
  <style>
    :root {
      --bg: #0d1117;
      --surface: #161b22;
      --surface2: #1c2128;
      --border: #30363d;
      --text: #e6edf3;
      --text-muted: #8b949e;
      --green: #38a169;
      --green-light: #68d391;
      --green-pale: #9ae6b4;
      --user-bg: #132113;
      --radius: 10px;
    }
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html, body { height: 100%; overflow: hidden; }
    body {
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
      font-size: 14px;
      display: flex;
      flex-direction: column;
    }

    /* ── Header ── */
    #header {
      flex-shrink: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 16px;
      height: 56px;
      background: var(--surface);
      border-bottom: 1px solid var(--border);
    }
    .header-left { display: flex; align-items: center; gap: 10px; }
    .logo-img { width: 28px; height: 34px; }
    .agent-name {
      font-weight: 600;
      font-size: 15px;
      color: var(--text);
    }
    .header-right { display: flex; align-items: center; gap: 8px; }
    .version-badge {
      font-size: 11px;
      color: var(--text-muted);
      background: var(--surface2);
      border: 1px solid var(--border);
      border-radius: 20px;
      padding: 2px 8px;
    }
    .tab-btn {
      background: transparent;
      border: 1px solid transparent;
      color: var(--text-muted);
      cursor: pointer;
      padding: 5px 12px;
      border-radius: 6px;
      font-size: 13px;
      transition: all 0.15s;
    }
    .tab-btn:hover { color: var(--text); border-color: var(--border); }
    .tab-btn.active {
      color: var(--green-light);
      border-color: var(--green);
      background: rgba(56, 161, 105, 0.1);
    }

    /* ── Tab panels ── */
    .tab-panel { display: none; flex: 1; overflow: hidden; }
    .tab-panel.active { display: flex; flex-direction: column; }

    /* ── Chat panel ── */
    #messages {
      flex: 1;
      overflow-y: auto;
      padding: 20px 16px 8px;
      scroll-behavior: smooth;
    }
    #messages::-webkit-scrollbar { width: 6px; }
    #messages::-webkit-scrollbar-track { background: transparent; }
    #messages::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

    .message {
      display: flex;
      gap: 10px;
      margin-bottom: 16px;
      max-width: 820px;
    }
    .message.user { flex-direction: row-reverse; margin-left: auto; }
    .message-bubble {
      padding: 10px 14px;
      border-radius: var(--radius);
      line-height: 1.55;
      max-width: 75%;
    }
    .message.user .message-bubble {
      background: var(--user-bg);
      border: 1px solid rgba(56, 161, 105, 0.25);
      color: var(--text);
      border-bottom-right-radius: 2px;
    }
    .message.agent .message-bubble {
      background: var(--surface);
      border: 1px solid var(--border);
      color: var(--text);
      border-bottom-left-radius: 2px;
    }
    .message.thinking .message-bubble {
      background: var(--surface);
      border: 1px dashed var(--border);
      color: var(--text-muted);
      font-style: italic;
    }
    .message-avatar {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      font-weight: 600;
      flex-shrink: 0;
      margin-top: 2px;
    }
    .message.user .message-avatar {
      background: rgba(56, 161, 105, 0.2);
      color: var(--green-light);
      border: 1px solid rgba(56, 161, 105, 0.3);
    }
    .message.agent .message-avatar {
      background: var(--surface2);
      border: 1px solid var(--border);
      padding: 2px;
    }
    .dots { display: inline-block; animation: blink 1.4s infinite; }
    @keyframes blink { 0%, 80%, 100% { opacity: 0.2; } 40% { opacity: 1; } }

    /* ── Markdown styles inside agent bubbles ── */
    .message-bubble p { margin: 0 0 8px; }
    .message-bubble p:last-child { margin-bottom: 0; }
    .message-bubble h1, .message-bubble h2, .message-bubble h3 {
      margin: 10px 0 4px;
      color: var(--text);
    }
    .message-bubble h1 { font-size: 17px; }
    .message-bubble h2 { font-size: 15px; }
    .message-bubble h3 { font-size: 14px; }
    .message-bubble ul, .message-bubble ol { padding-left: 20px; margin: 6px 0; }
    .message-bubble li { margin: 3px 0; }
    .message-bubble code {
      background: rgba(13, 17, 23, 0.8);
      border: 1px solid var(--border);
      border-radius: 4px;
      padding: 1px 5px;
      font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
      font-size: 12px;
    }
    .message-bubble pre {
      background: var(--bg);
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 12px;
      overflow-x: auto;
      margin: 8px 0;
    }
    .message-bubble pre code {
      background: none;
      border: none;
      padding: 0;
      font-size: 12px;
      color: var(--green-pale);
    }
    .message-bubble strong { color: var(--text); font-weight: 600; }
    .message-bubble em { color: var(--text-muted); }
    .message-bubble a { color: var(--green-light); }

    /* ── Input area ── */
    .input-area {
      display: flex;
      gap: 8px;
      padding: 12px 16px 16px;
      border-top: 1px solid var(--border);
      background: var(--surface);
    }
    #msg-input {
      flex: 1;
      background: var(--surface2);
      border: 1px solid var(--border);
      border-radius: 8px;
      color: var(--text);
      padding: 10px 14px;
      font-size: 14px;
      outline: none;
      transition: border-color 0.15s;
    }
    #msg-input:focus { border-color: var(--green); }
    #msg-input::placeholder { color: var(--text-muted); }
    #send-btn {
      background: var(--green);
      border: none;
      border-radius: 8px;
      color: white;
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      padding: 10px 18px;
      transition: background 0.15s, opacity 0.15s;
    }
    #send-btn:hover { background: #2f9e58; }
    #send-btn:disabled { opacity: 0.5; cursor: not-allowed; }

    /* ── Settings panel ── */
    #settings-tab {
      flex: 1;
      overflow-y: auto;
    }
    #settings-tab::-webkit-scrollbar { width: 6px; }
    #settings-tab::-webkit-scrollbar-track { background: transparent; }
    #settings-tab::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
    .settings-content { max-width: 640px; margin: 0 auto; padding: 24px 16px 40px; }
    .settings-section {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 20px;
      margin-bottom: 16px;
    }
    .settings-section h3 {
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--green-light);
      margin-bottom: 14px;
    }
    .field-row {
      display: grid;
      grid-template-columns: 150px 1fr;
      align-items: start;
      gap: 10px;
      margin-bottom: 10px;
    }
    .field-row:last-child { margin-bottom: 0; }
    .field-label {
      font-size: 13px;
      color: var(--text-muted);
      text-align: right;
      padding-top: 9px;
    }
    .settings-input {
      background: var(--surface2);
      border: 1px solid var(--border);
      border-radius: 6px;
      color: var(--text);
      padding: 8px 12px;
      font-size: 13px;
      width: 100%;
      outline: none;
      transition: border-color 0.15s;
    }
    .settings-input:focus { border-color: var(--green); }
    .settings-input::placeholder { color: var(--text-muted); }
    select.settings-input { cursor: pointer; }
    textarea.settings-input {
      resize: vertical;
      min-height: 64px;
      font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
      font-size: 12px;
      line-height: 1.5;
    }
    input[type="number"].settings-input { -moz-appearance: textfield; }
    input[type="number"].settings-input::-webkit-outer-spin-button,
    input[type="number"].settings-input::-webkit-inner-spin-button { -webkit-appearance: none; }

    /* ── Toggle switch ── */
    .toggle-wrap { display: flex; align-items: center; gap: 6px; padding-top: 6px; }
    .toggle-wrap input[type="checkbox"] { display: none; }
    .toggle-slider {
      width: 34px;
      height: 18px;
      background: var(--border);
      border-radius: 9px;
      position: relative;
      cursor: pointer;
      transition: background 0.2s;
      flex-shrink: 0;
    }
    .toggle-slider::after {
      content: '';
      width: 14px;
      height: 14px;
      background: white;
      border-radius: 50%;
      position: absolute;
      top: 2px;
      left: 2px;
      transition: left 0.2s;
    }
    .toggle-wrap input:checked + .toggle-slider { background: var(--green); }
    .toggle-wrap input:checked + .toggle-slider::after { left: 18px; }

    /* ── Collapsible subsections ── */
    .collapsible-toggle {
      display: flex;
      align-items: center;
      gap: 6px;
      width: 100%;
      background: transparent;
      border: 1px solid var(--border);
      border-radius: 6px;
      color: var(--text-muted);
      cursor: pointer;
      font-size: 12px;
      font-family: inherit;
      padding: 6px 10px;
      margin-bottom: 10px;
      text-align: left;
      transition: color 0.15s, border-color 0.15s;
    }
    .collapsible-toggle:hover { color: var(--text); border-color: var(--green); }
    .collapsible-toggle::before { content: '▶'; font-size: 9px; flex-shrink: 0; }
    .collapsible-toggle.open::before { content: '▼'; }
    .collapsible-body { display: none; }
    .collapsible-body.open { display: block; }

    /* ── Channel cards ── */
    .channel-card {
      border: 1px solid var(--border);
      border-radius: 8px;
      margin-bottom: 8px;
      overflow: hidden;
    }
    .channel-card:last-child { margin-bottom: 0; }
    .channel-header {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 14px;
      cursor: pointer;
      background: var(--surface2);
      transition: background 0.15s;
      user-select: none;
    }
    .channel-header:hover { background: rgba(56, 161, 105, 0.06); }
    .channel-name {
      flex: 1;
      font-size: 13px;
      font-weight: 500;
      color: var(--text);
    }
    .channel-expand-icon { font-size: 10px; color: var(--text-muted); }
    .channel-body {
      display: none;
      padding: 14px;
      border-top: 1px solid var(--border);
    }

    /* ── Subfield groups ── */
    .subfield-group {
      margin: 10px 0 10px 10px;
      padding-left: 12px;
      border-left: 2px solid var(--border);
    }
    .subfield-title {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--text-muted);
      margin-bottom: 8px;
      margin-top: 4px;
    }

    /* ── Warning box ── */
    .warning-box {
      background: rgba(214, 158, 46, 0.1);
      border: 1px solid rgba(214, 158, 46, 0.3);
      border-radius: 6px;
      padding: 8px 12px;
      font-size: 12px;
      color: #e9c46a;
      margin-bottom: 12px;
      line-height: 1.5;
    }

    /* ── MCP server cards ── */
    .mcp-servers-list { margin-bottom: 10px; }
    .mcp-server-card {
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 14px;
      margin-bottom: 10px;
      background: var(--surface2);
    }
    .mcp-server-card:last-child { margin-bottom: 0; }
    .mcp-card-top {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 12px;
    }
    .mcp-name-input { flex: 1; }
    .remove-card-btn {
      background: transparent;
      border: 1px solid #6b4040;
      border-radius: 6px;
      color: #fc8181;
      cursor: pointer;
      font-size: 12px;
      font-family: inherit;
      padding: 5px 10px;
      transition: background 0.15s;
      flex-shrink: 0;
      white-space: nowrap;
    }
    .remove-card-btn:hover { background: rgba(252, 129, 129, 0.12); }
    .env-section { margin-top: 10px; }
    .env-section-label {
      font-size: 12px;
      color: var(--text-muted);
      margin-bottom: 6px;
      display: block;
    }
    .env-rows { margin-bottom: 6px; }
    .env-row {
      display: flex;
      gap: 6px;
      margin-bottom: 5px;
      align-items: center;
    }
    .env-key { flex: 1; min-width: 0; }
    .env-value { flex: 2; min-width: 0; }
    .remove-env-btn {
      background: transparent;
      border: 1px solid var(--border);
      border-radius: 4px;
      color: var(--text-muted);
      cursor: pointer;
      font-size: 11px;
      font-family: inherit;
      padding: 4px 8px;
      flex-shrink: 0;
      transition: color 0.15s, border-color 0.15s;
    }
    .remove-env-btn:hover { color: #fc8181; border-color: #6b4040; }
    .add-small-btn {
      background: transparent;
      border: 1px solid var(--border);
      border-radius: 6px;
      color: var(--text-muted);
      cursor: pointer;
      font-size: 12px;
      font-family: inherit;
      padding: 5px 12px;
      transition: color 0.15s, border-color 0.15s;
    }
    .add-small-btn:hover { color: var(--green-light); border-color: var(--green); }
    .add-mcp-btn {
      background: transparent;
      border: 2px dashed var(--border);
      border-radius: 8px;
      color: var(--text-muted);
      cursor: pointer;
      font-size: 13px;
      font-family: inherit;
      font-weight: 500;
      padding: 10px;
      width: 100%;
      transition: color 0.15s, border-color 0.15s;
    }
    .add-mcp-btn:hover { color: var(--green-light); border-color: var(--green); }

    /* ── Settings footer ── */
    .settings-footer {
      display: flex;
      align-items: center;
      gap: 14px;
      margin-top: 8px;
    }
    .save-btn {
      background: var(--green);
      border: none;
      border-radius: 8px;
      color: white;
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      padding: 10px 22px;
      transition: background 0.15s;
    }
    .save-btn:hover { background: #2f9e58; }
    .toast {
      font-size: 13px;
      color: var(--green-light);
      opacity: 0;
      transition: opacity 0.3s;
    }
    .toast.visible { opacity: 1; }

    /* ── Welcome message ── */
    .welcome {
      text-align: center;
      padding: 40px 20px;
      color: var(--text-muted);
    }
    .welcome .welcome-logo { margin-bottom: 12px; opacity: 0.7; }
    .welcome h2 { font-size: 18px; color: var(--text); margin-bottom: 8px; }
    .welcome p { font-size: 13px; line-height: 1.6; }
    .welcome .tip {
      display: inline-block;
      margin-top: 16px;
      font-size: 12px;
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 8px 14px;
    }

    /* ── Credentials Overlay ── */
    #creds-overlay {
      position: fixed;
      inset: 0;
      background: rgba(13, 17, 23, 0.96);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }
    #creds-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 36px 32px;
      max-width: 400px;
      width: 90%;
    }
    .creds-logo { text-align: center; margin-bottom: 20px; }
    #creds-card h2 { font-size: 20px; font-weight: 700; color: var(--text); margin-bottom: 6px; }
    .creds-subtitle { font-size: 13px; color: var(--text-muted); margin-bottom: 24px; line-height: 1.5; }
    .creds-field { margin-bottom: 14px; }
    .creds-label {
      display: block;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.07em;
      color: var(--text-muted);
      margin-bottom: 6px;
    }
    .creds-save-btn {
      width: 100%;
      background: var(--green);
      border: none;
      border-radius: 8px;
      color: white;
      cursor: pointer;
      font-size: 14px;
      font-weight: 600;
      padding: 12px;
      margin-top: 10px;
      transition: background 0.15s;
    }
    .creds-save-btn:hover { background: #2f9e58; }
    .creds-error { font-size: 12px; color: #fc8181; margin-top: 8px; display: none; }
    #gateway-dot.active { background: var(--green); }
  </style>
</head>
<body>
  <!-- ── Credentials Overlay ── -->
  <div id="creds-overlay" style="display:none">
    <div id="creds-card">
      <div class="creds-logo"><img src="/logo.svg" alt="__AGENT_NAME__" width="48" height="58"></div>
      <h2>Get Started</h2>
      <p class="creds-subtitle">Choose your AI provider and enter your API key to activate your assistant.</p>
      <div class="creds-field">
        <label class="creds-label" for="creds-provider">Provider</label>
        <select id="creds-provider" class="settings-input" onchange="onCredsProviderChange()">
          <option value="anthropic">Anthropic</option>
          <option value="openai">OpenAI</option>
          <option value="openrouter">OpenRouter</option>
          <option value="deepseek">DeepSeek</option>
          <option value="groq">Groq</option>
        </select>
      </div>
      <div class="creds-field">
        <label class="creds-label" for="creds-key">API Key</label>
        <input id="creds-key" class="settings-input" type="password" placeholder="Paste your API key here" autocomplete="off">
      </div>
      <div class="creds-field">
        <label class="creds-label" for="creds-model">Model</label>
        <input id="creds-model" class="settings-input" type="text" value="anthropic/claude-opus-4-5">
      </div>
      <div class="creds-error" id="creds-error"></div>
      <button class="creds-save-btn" onclick="saveCredentials()">Save &amp; Continue</button>
    </div>
  </div>

  <div id="header">
    <div class="header-left">
      <img src="/logo.svg" alt="__AGENT_NAME__" class="logo-img">
      <span class="agent-name" id="agent-name">__AGENT_NAME__</span>
    </div>
    <div class="header-right">
      <span class="version-badge">v__VERSION__</span>
      <div id="gateway-status" style="display:flex;align-items:center;gap:5px;font-size:12px;color:var(--text-muted)">
        <span id="gateway-dot" style="width:7px;height:7px;border-radius:50%;background:var(--border);flex-shrink:0"></span>
        <span>Gateway</span>
        <button id="gateway-start-btn" onclick="startGateway()" style="display:none;
          background:transparent;border:1px solid var(--border);border-radius:4px;
          color:var(--text-muted);cursor:pointer;font-size:11px;font-family:inherit;
          padding:2px 7px;transition:color 0.15s,border-color 0.15s">Start</button>
      </div>
      <button class="tab-btn active" data-tab="chat" onclick="switchTab('chat')">Chat</button>
      <button class="tab-btn" data-tab="settings" onclick="switchTab('settings')">&#9881; Settings</button>
    </div>
  </div>

  <div id="chat-tab" class="tab-panel active">
    <div id="messages">
      <div class="welcome">
        <div class="welcome-logo">
          <img src="/logo.svg" alt="" width="48" height="58">
        </div>
        <h2 id="welcome-name">Root Engine</h2>
        <p>Your AI assistant is ready. Type a message below to start chatting.</p>
        <span class="tip">&#9881; Use Settings to configure your API key and model.</span>
      </div>
    </div>
    <div class="input-area">
      <input
        id="msg-input"
        type="text"
        placeholder="Type a message..."
        onkeydown="if(event.key==='Enter' && !event.shiftKey){event.preventDefault();sendMessage();}"
        autocomplete="off"
        spellcheck="true"
      >
      <button id="send-btn" onclick="sendMessage()">Send</button>
    </div>
  </div>

  <div id="settings-tab" class="tab-panel">
    <div class="settings-content">

      <!-- ── AGENT ── -->
      <div class="settings-section">
        <h3>Agent</h3>
        <div class="field-row">
          <span class="field-label">Name</span>
          <input class="settings-input" type="text" data-path="agents.defaults.agentName" placeholder="Root Engine">
        </div>
        <div class="field-row">
          <span class="field-label">Model</span>
          <input class="settings-input" type="text" data-path="agents.defaults.model" placeholder="anthropic/claude-opus-4-5">
        </div>
        <div class="field-row">
          <span class="field-label">Workspace</span>
          <input class="settings-input" type="text" data-path="agents.defaults.workspace" placeholder="~/.root-engine/workspace">
        </div>
        <div class="field-row">
          <span class="field-label">Max Tokens</span>
          <input class="settings-input" type="number" data-path="agents.defaults.maxTokens" data-type="number" placeholder="8192" min="1">
        </div>
        <div class="field-row">
          <span class="field-label">Temperature</span>
          <input class="settings-input" type="number" data-path="agents.defaults.temperature" data-type="number" placeholder="0.7" min="0" max="2" step="0.1">
        </div>
        <div class="field-row">
          <span class="field-label">Max Iterations</span>
          <input class="settings-input" type="number" data-path="agents.defaults.maxToolIterations" data-type="number" placeholder="20" min="1">
        </div>
        <div class="field-row">
          <span class="field-label">Memory Window</span>
          <input class="settings-input" type="number" data-path="agents.defaults.memoryWindow" data-type="number" placeholder="50" min="1">
        </div>
      </div>

      <!-- ── API KEYS ── -->
      <div class="settings-section">
        <h3>API Keys</h3>
        <div class="field-row">
          <span class="field-label">Anthropic</span>
          <input class="settings-input" type="password" data-path="providers.anthropic.apiKey" placeholder="sk-ant-...">
        </div>
        <div class="field-row">
          <span class="field-label">OpenAI</span>
          <input class="settings-input" type="password" data-path="providers.openai.apiKey" placeholder="sk-...">
        </div>
        <div class="field-row">
          <span class="field-label">OpenRouter</span>
          <input class="settings-input" type="password" data-path="providers.openrouter.apiKey" placeholder="sk-or-...">
        </div>
        <div class="field-row">
          <span class="field-label">DeepSeek</span>
          <input class="settings-input" type="password" data-path="providers.deepseek.apiKey" placeholder="sk-...">
        </div>
        <div class="field-row">
          <span class="field-label">Groq</span>
          <input class="settings-input" type="password" data-path="providers.groq.apiKey" placeholder="gsk_...">
        </div>
        <div class="field-row">
          <span class="field-label">Gemini</span>
          <input class="settings-input" type="password" data-path="providers.gemini.apiKey" placeholder="AIza...">
        </div>

        <!-- More Providers (collapsed) -->
        <button class="collapsible-toggle" data-section="more-providers" onclick="toggleSection('more-providers')">More Providers</button>
        <div class="collapsible-body" id="more-providers">
          <div class="field-row">
            <span class="field-label">Moonshot</span>
            <input class="settings-input" type="password" data-path="providers.moonshot.apiKey" placeholder="sk-...">
          </div>
          <div class="field-row">
            <span class="field-label">MiniMax</span>
            <input class="settings-input" type="password" data-path="providers.minimax.apiKey" placeholder="...">
          </div>
          <div class="field-row">
            <span class="field-label">AiHubMix</span>
            <input class="settings-input" type="password" data-path="providers.aihubmix.apiKey" placeholder="...">
          </div>
          <div class="field-row">
            <span class="field-label">SiliconFlow</span>
            <input class="settings-input" type="password" data-path="providers.siliconflow.apiKey" placeholder="sk-...">
          </div>
          <div class="field-row">
            <span class="field-label">Zhipu</span>
            <input class="settings-input" type="password" data-path="providers.zhipu.apiKey" placeholder="...">
          </div>
          <div class="field-row">
            <span class="field-label">DashScope</span>
            <input class="settings-input" type="password" data-path="providers.dashscope.apiKey" placeholder="sk-...">
          </div>
          <div class="field-row">
            <span class="field-label">OpenAI Codex</span>
            <input class="settings-input" type="password" data-path="providers.openaiCodex.apiKey" placeholder="...">
          </div>
          <div class="field-row" style="margin-bottom:0">
            <span class="field-label">GitHub Copilot</span>
            <input class="settings-input" type="password" data-path="providers.githubCopilot.apiKey" placeholder="...">
          </div>
        </div>

        <!-- Self-hosted / Custom (collapsed) -->
        <button class="collapsible-toggle" data-section="self-hosted" onclick="toggleSection('self-hosted')" style="margin-bottom:0">Self-hosted / Custom</button>
        <div class="collapsible-body" id="self-hosted" style="margin-top:10px">
          <div class="field-row">
            <span class="field-label">vLLM Base URL</span>
            <input class="settings-input" type="text" data-path="providers.vllm.apiBase" placeholder="http://localhost:8000/v1">
          </div>
          <div class="field-row">
            <span class="field-label">Custom Base URL</span>
            <input class="settings-input" type="text" data-path="providers.custom.apiBase" placeholder="http://localhost:8000/v1">
          </div>
          <div class="field-row" style="margin-bottom:0">
            <span class="field-label">Custom API Key</span>
            <input class="settings-input" type="password" data-path="providers.custom.apiKey" placeholder="...">
          </div>
        </div>
      </div>

      <!-- ── TOOLS ── -->
      <div class="settings-section">
        <h3>Tools</h3>
        <div class="field-row">
          <span class="field-label">Brave Search Key</span>
          <input class="settings-input" type="password" data-path="tools.web.search.apiKey" placeholder="BSA-...">
        </div>
        <div class="field-row">
          <span class="field-label">Max Web Results</span>
          <input class="settings-input" type="number" data-path="tools.web.search.maxResults" data-type="number" placeholder="5" min="1" max="20">
        </div>
        <div class="field-row">
          <span class="field-label">Exec Timeout (s)</span>
          <input class="settings-input" type="number" data-path="tools.exec.timeout" data-type="number" placeholder="60" min="1">
        </div>
        <div class="field-row" style="margin-bottom:0">
          <span class="field-label">Restrict Workspace</span>
          <label class="toggle-wrap">
            <input type="checkbox" data-path="tools.restrictToWorkspace">
            <span class="toggle-slider" onclick="this.previousElementSibling.click()"></span>
          </label>
        </div>
      </div>

      <!-- ── MCP SERVERS ── -->
      <div class="settings-section">
        <h3>MCP Servers</h3>
        <div class="mcp-servers-list" id="mcp-servers-list"></div>
        <button class="add-mcp-btn" onclick="addMCPCard()">+ Add MCP Server</button>
      </div>

      <!-- ── CHANNELS ── -->
      <div class="settings-section">
        <h3>Channels</h3>

        <!-- Telegram -->
        <div class="channel-card">
          <div class="channel-header" onclick="toggleChannel(this)">
            <label class="toggle-wrap" style="padding-top:0" onclick="event.stopPropagation()">
              <input type="checkbox" data-path="channels.telegram.enabled">
              <span class="toggle-slider" onclick="event.stopPropagation(); this.previousElementSibling.click()"></span>
            </label>
            <span class="channel-name">Telegram</span>
            <span class="channel-expand-icon">▼</span>
          </div>
          <div class="channel-body">
            <div class="field-row">
              <span class="field-label">Bot Token</span>
              <input class="settings-input" type="password" data-path="channels.telegram.token" placeholder="123456:ABC-...">
            </div>
            <div class="field-row">
              <span class="field-label">Allow From</span>
              <input class="settings-input" type="text" data-path="channels.telegram.allowFrom" data-type="list" placeholder="user_id1, username2">
            </div>
            <div class="field-row" style="margin-bottom:0">
              <span class="field-label">Proxy</span>
              <input class="settings-input" type="text" data-path="channels.telegram.proxy" placeholder="http://127.0.0.1:7890">
            </div>
          </div>
        </div>

        <!-- WhatsApp -->
        <div class="channel-card">
          <div class="channel-header" onclick="toggleChannel(this)">
            <label class="toggle-wrap" style="padding-top:0" onclick="event.stopPropagation()">
              <input type="checkbox" data-path="channels.whatsapp.enabled">
              <span class="toggle-slider" onclick="event.stopPropagation(); this.previousElementSibling.click()"></span>
            </label>
            <span class="channel-name">WhatsApp</span>
            <span class="channel-expand-icon">▼</span>
          </div>
          <div class="channel-body">
            <div class="field-row">
              <span class="field-label">Bridge URL</span>
              <input class="settings-input" type="text" data-path="channels.whatsapp.bridgeUrl" placeholder="ws://localhost:3001">
            </div>
            <div class="field-row">
              <span class="field-label">Bridge Token</span>
              <input class="settings-input" type="password" data-path="channels.whatsapp.bridgeToken" placeholder="shared secret">
            </div>
            <div class="field-row" style="margin-bottom:0">
              <span class="field-label">Allow From</span>
              <input class="settings-input" type="text" data-path="channels.whatsapp.allowFrom" data-type="list" placeholder="+1234567890, +0987654321">
            </div>
          </div>
        </div>

        <!-- Discord -->
        <div class="channel-card">
          <div class="channel-header" onclick="toggleChannel(this)">
            <label class="toggle-wrap" style="padding-top:0" onclick="event.stopPropagation()">
              <input type="checkbox" data-path="channels.discord.enabled">
              <span class="toggle-slider" onclick="event.stopPropagation(); this.previousElementSibling.click()"></span>
            </label>
            <span class="channel-name">Discord</span>
            <span class="channel-expand-icon">▼</span>
          </div>
          <div class="channel-body">
            <div class="field-row">
              <span class="field-label">Bot Token</span>
              <input class="settings-input" type="password" data-path="channels.discord.token" placeholder="Bot token from Discord Developer Portal">
            </div>
            <div class="field-row" style="margin-bottom:0">
              <span class="field-label">Allow From</span>
              <input class="settings-input" type="text" data-path="channels.discord.allowFrom" data-type="list" placeholder="user_id1, user_id2">
            </div>
          </div>
        </div>

        <!-- Slack -->
        <div class="channel-card">
          <div class="channel-header" onclick="toggleChannel(this)">
            <label class="toggle-wrap" style="padding-top:0" onclick="event.stopPropagation()">
              <input type="checkbox" data-path="channels.slack.enabled">
              <span class="toggle-slider" onclick="event.stopPropagation(); this.previousElementSibling.click()"></span>
            </label>
            <span class="channel-name">Slack</span>
            <span class="channel-expand-icon">▼</span>
          </div>
          <div class="channel-body">
            <div class="field-row">
              <span class="field-label">Bot Token</span>
              <input class="settings-input" type="password" data-path="channels.slack.botToken" placeholder="xoxb-...">
            </div>
            <div class="field-row">
              <span class="field-label">App Token</span>
              <input class="settings-input" type="password" data-path="channels.slack.appToken" placeholder="xapp-...">
            </div>
            <div class="field-row">
              <span class="field-label">Reply in Thread</span>
              <label class="toggle-wrap">
                <input type="checkbox" data-path="channels.slack.replyInThread">
                <span class="toggle-slider" onclick="this.previousElementSibling.click()"></span>
              </label>
            </div>
            <div class="field-row">
              <span class="field-label">React Emoji</span>
              <input class="settings-input" type="text" data-path="channels.slack.reactEmoji" placeholder="eyes">
            </div>
            <div class="field-row">
              <span class="field-label">Group Policy</span>
              <select class="settings-input" data-path="channels.slack.groupPolicy">
                <option value="mention">mention</option>
                <option value="open">open</option>
                <option value="allowlist">allowlist</option>
              </select>
            </div>
            <div class="field-row">
              <span class="field-label">Group Allow From</span>
              <input class="settings-input" type="text" data-path="channels.slack.groupAllowFrom" data-type="list" placeholder="channel_id1, channel_id2">
            </div>
            <div class="subfield-group">
              <div class="subfield-title">Direct Messages</div>
              <div class="field-row">
                <span class="field-label">DM Enabled</span>
                <label class="toggle-wrap">
                  <input type="checkbox" data-path="channels.slack.dm.enabled">
                  <span class="toggle-slider" onclick="this.previousElementSibling.click()"></span>
                </label>
              </div>
              <div class="field-row">
                <span class="field-label">DM Policy</span>
                <select class="settings-input" data-path="channels.slack.dm.policy">
                  <option value="open">open</option>
                  <option value="allowlist">allowlist</option>
                </select>
              </div>
              <div class="field-row" style="margin-bottom:0">
                <span class="field-label">DM Allow From</span>
                <input class="settings-input" type="text" data-path="channels.slack.dm.allowFrom" data-type="list" placeholder="user_id1, user_id2">
              </div>
            </div>
          </div>
        </div>

        <!-- Email -->
        <div class="channel-card">
          <div class="channel-header" onclick="toggleChannel(this)">
            <label class="toggle-wrap" style="padding-top:0" onclick="event.stopPropagation()">
              <input type="checkbox" data-path="channels.email.enabled">
              <span class="toggle-slider" onclick="event.stopPropagation(); this.previousElementSibling.click()"></span>
            </label>
            <span class="channel-name">Email</span>
            <span class="channel-expand-icon">▼</span>
          </div>
          <div class="channel-body">
            <div class="warning-box">&#9888; Email channel reads your inbox. Enable only if you understand the security implications.</div>
            <div class="field-row">
              <span class="field-label">Consent Granted</span>
              <label class="toggle-wrap">
                <input type="checkbox" data-path="channels.email.consentGranted">
                <span class="toggle-slider" onclick="this.previousElementSibling.click()"></span>
              </label>
            </div>
            <div class="subfield-group">
              <div class="subfield-title">IMAP (Incoming)</div>
              <div class="field-row">
                <span class="field-label">Host</span>
                <input class="settings-input" type="text" data-path="channels.email.imapHost" placeholder="imap.gmail.com">
              </div>
              <div class="field-row">
                <span class="field-label">Port</span>
                <input class="settings-input" type="number" data-path="channels.email.imapPort" data-type="number" placeholder="993" min="1" max="65535">
              </div>
              <div class="field-row">
                <span class="field-label">Username</span>
                <input class="settings-input" type="text" data-path="channels.email.imapUsername" placeholder="user@example.com">
              </div>
              <div class="field-row">
                <span class="field-label">Password</span>
                <input class="settings-input" type="password" data-path="channels.email.imapPassword">
              </div>
              <div class="field-row">
                <span class="field-label">Mailbox</span>
                <input class="settings-input" type="text" data-path="channels.email.imapMailbox" placeholder="INBOX">
              </div>
              <div class="field-row" style="margin-bottom:0">
                <span class="field-label">Use SSL</span>
                <label class="toggle-wrap">
                  <input type="checkbox" data-path="channels.email.imapUseSsl">
                  <span class="toggle-slider" onclick="this.previousElementSibling.click()"></span>
                </label>
              </div>
            </div>
            <div class="subfield-group">
              <div class="subfield-title">SMTP (Outgoing)</div>
              <div class="field-row">
                <span class="field-label">Host</span>
                <input class="settings-input" type="text" data-path="channels.email.smtpHost" placeholder="smtp.gmail.com">
              </div>
              <div class="field-row">
                <span class="field-label">Port</span>
                <input class="settings-input" type="number" data-path="channels.email.smtpPort" data-type="number" placeholder="587" min="1" max="65535">
              </div>
              <div class="field-row">
                <span class="field-label">Username</span>
                <input class="settings-input" type="text" data-path="channels.email.smtpUsername" placeholder="user@example.com">
              </div>
              <div class="field-row">
                <span class="field-label">Password</span>
                <input class="settings-input" type="password" data-path="channels.email.smtpPassword">
              </div>
              <div class="field-row">
                <span class="field-label">Use TLS</span>
                <label class="toggle-wrap">
                  <input type="checkbox" data-path="channels.email.smtpUseTls">
                  <span class="toggle-slider" onclick="this.previousElementSibling.click()"></span>
                </label>
              </div>
              <div class="field-row" style="margin-bottom:0">
                <span class="field-label">From Address</span>
                <input class="settings-input" type="text" data-path="channels.email.fromAddress" placeholder="agent@example.com">
              </div>
            </div>
            <div class="field-row">
              <span class="field-label">Auto Reply</span>
              <label class="toggle-wrap">
                <input type="checkbox" data-path="channels.email.autoReplyEnabled">
                <span class="toggle-slider" onclick="this.previousElementSibling.click()"></span>
              </label>
            </div>
            <div class="field-row">
              <span class="field-label">Poll Interval (s)</span>
              <input class="settings-input" type="number" data-path="channels.email.pollIntervalSeconds" data-type="number" placeholder="30" min="5">
            </div>
            <div class="field-row" style="margin-bottom:0">
              <span class="field-label">Allow From</span>
              <input class="settings-input" type="text" data-path="channels.email.allowFrom" data-type="list" placeholder="sender@example.com, other@example.com">
            </div>
          </div>
        </div>

        <!-- Feishu -->
        <div class="channel-card">
          <div class="channel-header" onclick="toggleChannel(this)">
            <label class="toggle-wrap" style="padding-top:0" onclick="event.stopPropagation()">
              <input type="checkbox" data-path="channels.feishu.enabled">
              <span class="toggle-slider" onclick="event.stopPropagation(); this.previousElementSibling.click()"></span>
            </label>
            <span class="channel-name">Feishu / Lark</span>
            <span class="channel-expand-icon">▼</span>
          </div>
          <div class="channel-body">
            <div class="field-row">
              <span class="field-label">App ID</span>
              <input class="settings-input" type="text" data-path="channels.feishu.appId" placeholder="cli_...">
            </div>
            <div class="field-row">
              <span class="field-label">App Secret</span>
              <input class="settings-input" type="password" data-path="channels.feishu.appSecret">
            </div>
            <div class="field-row">
              <span class="field-label">Encrypt Key</span>
              <input class="settings-input" type="password" data-path="channels.feishu.encryptKey" placeholder="optional">
            </div>
            <div class="field-row">
              <span class="field-label">Verify Token</span>
              <input class="settings-input" type="password" data-path="channels.feishu.verificationToken" placeholder="optional">
            </div>
            <div class="field-row" style="margin-bottom:0">
              <span class="field-label">Allow From</span>
              <input class="settings-input" type="text" data-path="channels.feishu.allowFrom" data-type="list" placeholder="ou_xxx, ou_yyy">
            </div>
          </div>
        </div>

        <!-- DingTalk -->
        <div class="channel-card">
          <div class="channel-header" onclick="toggleChannel(this)">
            <label class="toggle-wrap" style="padding-top:0" onclick="event.stopPropagation()">
              <input type="checkbox" data-path="channels.dingtalk.enabled">
              <span class="toggle-slider" onclick="event.stopPropagation(); this.previousElementSibling.click()"></span>
            </label>
            <span class="channel-name">DingTalk</span>
            <span class="channel-expand-icon">▼</span>
          </div>
          <div class="channel-body">
            <div class="field-row">
              <span class="field-label">Client ID</span>
              <input class="settings-input" type="text" data-path="channels.dingtalk.clientId" placeholder="AppKey">
            </div>
            <div class="field-row">
              <span class="field-label">Client Secret</span>
              <input class="settings-input" type="password" data-path="channels.dingtalk.clientSecret" placeholder="AppSecret">
            </div>
            <div class="field-row" style="margin-bottom:0">
              <span class="field-label">Allow From</span>
              <input class="settings-input" type="text" data-path="channels.dingtalk.allowFrom" data-type="list" placeholder="staff_id1, staff_id2">
            </div>
          </div>
        </div>

        <!-- QQ -->
        <div class="channel-card">
          <div class="channel-header" onclick="toggleChannel(this)">
            <label class="toggle-wrap" style="padding-top:0" onclick="event.stopPropagation()">
              <input type="checkbox" data-path="channels.qq.enabled">
              <span class="toggle-slider" onclick="event.stopPropagation(); this.previousElementSibling.click()"></span>
            </label>
            <span class="channel-name">QQ</span>
            <span class="channel-expand-icon">▼</span>
          </div>
          <div class="channel-body">
            <div class="field-row">
              <span class="field-label">App ID</span>
              <input class="settings-input" type="text" data-path="channels.qq.appId" placeholder="AppID from q.qq.com">
            </div>
            <div class="field-row">
              <span class="field-label">Secret</span>
              <input class="settings-input" type="password" data-path="channels.qq.secret" placeholder="AppSecret">
            </div>
            <div class="field-row" style="margin-bottom:0">
              <span class="field-label">Allow From</span>
              <input class="settings-input" type="text" data-path="channels.qq.allowFrom" data-type="list" placeholder="openid1, openid2">
            </div>
          </div>
        </div>

        <!-- Mochat -->
        <div class="channel-card">
          <div class="channel-header" onclick="toggleChannel(this)">
            <label class="toggle-wrap" style="padding-top:0" onclick="event.stopPropagation()">
              <input type="checkbox" data-path="channels.mochat.enabled">
              <span class="toggle-slider" onclick="event.stopPropagation(); this.previousElementSibling.click()"></span>
            </label>
            <span class="channel-name">Mochat</span>
            <span class="channel-expand-icon">▼</span>
          </div>
          <div class="channel-body">
            <div class="field-row">
              <span class="field-label">Base URL</span>
              <input class="settings-input" type="text" data-path="channels.mochat.baseUrl" placeholder="http://localhost:9501">
            </div>
            <div class="field-row">
              <span class="field-label">Socket URL</span>
              <input class="settings-input" type="text" data-path="channels.mochat.socketUrl" placeholder="ws://localhost:9501">
            </div>
            <div class="field-row">
              <span class="field-label">API Token</span>
              <input class="settings-input" type="password" data-path="channels.mochat.apiToken">
            </div>
            <div class="field-row">
              <span class="field-label">Agent User ID</span>
              <input class="settings-input" type="text" data-path="channels.mochat.agentUserId">
            </div>
            <div class="field-row">
              <span class="field-label">Sessions</span>
              <input class="settings-input" type="text" data-path="channels.mochat.sessions" data-type="list" placeholder="session_id1, session_id2">
            </div>
            <div class="field-row">
              <span class="field-label">Panels</span>
              <input class="settings-input" type="text" data-path="channels.mochat.panels" data-type="list" placeholder="panel_id1, panel_id2">
            </div>
            <div class="field-row">
              <span class="field-label">Allow From</span>
              <input class="settings-input" type="text" data-path="channels.mochat.allowFrom" data-type="list" placeholder="user_id1, user_id2">
            </div>
            <div class="field-row">
              <span class="field-label">Reply Delay Mode</span>
              <select class="settings-input" data-path="channels.mochat.replyDelayMode">
                <option value="off">off</option>
                <option value="non-mention">non-mention</option>
              </select>
            </div>
            <div class="field-row">
              <span class="field-label">Reply Delay (ms)</span>
              <input class="settings-input" type="number" data-path="channels.mochat.replyDelayMs" data-type="number" placeholder="120000" min="0">
            </div>
            <button class="collapsible-toggle" data-section="mochat-advanced" onclick="toggleSection('mochat-advanced')" style="margin-top:8px;margin-bottom:0">Advanced</button>
            <div class="collapsible-body" id="mochat-advanced" style="margin-top:10px">
              <div class="field-row">
                <span class="field-label">Watch Limit</span>
                <input class="settings-input" type="number" data-path="channels.mochat.watchLimit" data-type="number" placeholder="100" min="1">
              </div>
              <div class="field-row">
                <span class="field-label">Socket Path</span>
                <input class="settings-input" type="text" data-path="channels.mochat.socketPath" placeholder="/socket.io">
              </div>
              <div class="field-row">
                <span class="field-label">Reconnect Delay (ms)</span>
                <input class="settings-input" type="number" data-path="channels.mochat.socketReconnectDelayMs" data-type="number" placeholder="1000" min="0">
              </div>
              <div class="field-row">
                <span class="field-label">Max Reconnect (ms)</span>
                <input class="settings-input" type="number" data-path="channels.mochat.socketMaxReconnectDelayMs" data-type="number" placeholder="10000" min="0">
              </div>
              <div class="field-row" style="margin-bottom:0">
                <span class="field-label">Connect Timeout (ms)</span>
                <input class="settings-input" type="number" data-path="channels.mochat.socketConnectTimeoutMs" data-type="number" placeholder="10000" min="0">
              </div>
            </div>
          </div>
        </div>

      </div><!-- end Channels section -->

      <!-- ── GATEWAY ── -->
      <div class="settings-section">
        <button class="collapsible-toggle" data-section="gateway-body" onclick="toggleSection('gateway-body')" style="font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:0.08em;color:var(--green-light);border-color:transparent;margin-bottom:0;padding-left:0">Gateway (Advanced)</button>
        <div class="collapsible-body" id="gateway-body" style="margin-top:14px">
          <div class="field-row">
            <span class="field-label">Host</span>
            <input class="settings-input" type="text" data-path="gateway.host" placeholder="0.0.0.0">
          </div>
          <div class="field-row" style="margin-bottom:0">
            <span class="field-label">Port</span>
            <input class="settings-input" type="number" data-path="gateway.port" data-type="number" placeholder="18790" min="1" max="65535">
          </div>
        </div>
      </div>

      <div class="settings-footer">
        <button class="save-btn" onclick="saveSettings()">Save Settings</button>
        <span class="toast" id="save-toast">Saved &#10003;</span>
      </div>
    </div>
  </div>

  <script>
    // ── Tab switching ──────────────────────────────────────────────────────────
    function switchTab(name) {
      document.querySelectorAll('.tab-panel').forEach(function(p) { p.classList.remove('active'); });
      document.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
      document.getElementById(name + '-tab').classList.add('active');
      document.querySelector('[data-tab="' + name + '"]').classList.add('active');
    }

    // ── HTML escape ────────────────────────────────────────────────────────────
    function escapeHtml(text) {
      return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }

    // ── Minimal Markdown renderer ──────────────────────────────────────────────
    function renderMarkdown(text) {
      if (!text) return '';
      var codeBlocks = [];
      text = text.replace(/```([\w]*)\n?([\s\S]*?)```/g, function(_, lang, code) {
        var idx = codeBlocks.length;
        codeBlocks.push('<pre><code>' + escapeHtml(code.trim()) + '</code></pre>');
        return '~~CODEBLOCK_' + idx + '~~';
      });
      text = escapeHtml(text);
      text = text.replace(/`([^`\n]+)`/g, '<code>$1</code>');
      text = text.replace(/[*][*][*](.+?)[*][*][*]/g, '<strong><em>$1</em></strong>');
      text = text.replace(/[*][*](.+?)[*][*]/g, '<strong>$1</strong>');
      text = text.replace(/[*]([^*\n]+)[*]/g, '<em>$1</em>');
      text = text.replace(/^### (.+)$/gm, '<h3>$1</h3>');
      text = text.replace(/^## (.+)$/gm, '<h2>$1</h2>');
      text = text.replace(/^# (.+)$/gm, '<h1>$1</h1>');
      text = text.replace(/((?:^[-*] .+[\n]?)+)/gm, function(block) {
        var items = block.trim().split('\n').map(function(line) {
          return '<li>' + line.replace(/^[-*] /, '') + '</li>';
        }).join('');
        return '<ul>' + items + '</ul>';
      });
      var sections = text.split(/\n\n+/);
      text = sections.map(function(s) {
        s = s.trim();
        if (!s) return '';
        if (/^<(h[1-3]|ul|ol|pre|li)/.test(s)) return s;
        return '<p>' + s.replace(/\n/g, '<br>') + '</p>';
      }).filter(Boolean).join('\n');
      text = text.replace(/~~CODEBLOCK_(\d+)~~/g, function(_, idx) {
        return codeBlocks[+idx];
      });
      return text;
    }

    // ── Chat helpers ───────────────────────────────────────────────────────────
    var _agentName = 'Root Engine';

    function scrollToBottom() {
      var el = document.getElementById('messages');
      el.scrollTop = el.scrollHeight;
    }

    function appendMessage(role, content) {
      var welcome = document.querySelector('.welcome');
      if (welcome) welcome.remove();

      var messages = document.getElementById('messages');
      var div = document.createElement('div');
      div.className = 'message ' + role;

      var avatar = document.createElement('div');
      avatar.className = 'message-avatar';
      if (role === 'user') {
        avatar.textContent = 'U';
      } else {
        var img = document.createElement('img');
        img.src = '/logo.svg';
        img.alt = '';
        img.width = 24;
        img.height = 29;
        avatar.appendChild(img);
      }

      var bubble = document.createElement('div');
      bubble.className = 'message-bubble';
      if (role === 'agent') {
        bubble.innerHTML = renderMarkdown(content);
      } else {
        bubble.textContent = content;
      }

      div.appendChild(avatar);
      div.appendChild(bubble);
      messages.appendChild(div);
      scrollToBottom();
      return bubble;
    }

    function addThinkingBubble() {
      var welcome = document.querySelector('.welcome');
      if (welcome) welcome.remove();

      var messages = document.getElementById('messages');
      var div = document.createElement('div');
      div.className = 'message agent thinking';
      div.id = 'thinking-bubble';

      var avatar = document.createElement('div');
      avatar.className = 'message-avatar';
      var img = document.createElement('img');
      img.src = '/logo.svg'; img.alt = ''; img.width = 24; img.height = 29;
      avatar.appendChild(img);

      var bubble = document.createElement('div');
      bubble.className = 'message-bubble';
      bubble.innerHTML = '<span class="dots">&#9679;&#9679;&#9679;</span>';

      div.appendChild(avatar);
      div.appendChild(bubble);
      messages.appendChild(div);
      scrollToBottom();
      return div;
    }

    function updateThinkingBubble(text) {
      var el = document.getElementById('thinking-bubble');
      if (el) {
        el.querySelector('.message-bubble').innerHTML =
          '<em style="font-size:12px;color:var(--text-muted)">&#8627; ' + escapeHtml(text) + '</em>';
        scrollToBottom();
      }
    }

    function removeThinkingBubble() {
      var el = document.getElementById('thinking-bubble');
      if (el) el.remove();
    }

    // ── SSE parser ─────────────────────────────────────────────────────────────
    var _sseBuffer = '';

    function parseSSEChunk(chunk) {
      _sseBuffer += chunk;
      var events = [];
      while (true) {
        var idx = _sseBuffer.indexOf('\n\n');
        if (idx === -1) break;
        var eventText = _sseBuffer.slice(0, idx);
        _sseBuffer = _sseBuffer.slice(idx + 2);
        var dataLines = eventText.split('\n').filter(function(l) { return l.startsWith('data: '); });
        if (dataLines.length > 0) {
          var dataStr = dataLines.map(function(l) { return l.slice(6); }).join('\n');
          try { events.push(JSON.parse(dataStr)); } catch(e) {}
        }
      }
      return events;
    }

    // ── Send message ───────────────────────────────────────────────────────────
    async function sendMessage() {
      var input = document.getElementById('msg-input');
      var sendBtn = document.getElementById('send-btn');
      var message = input.value.trim();
      if (!message) return;

      // First real user reply during onboarding — mark it complete
      if (_onboardingActive) {
        _onboardingActive = false;
        fetch('/api/complete-onboarding', {method: 'POST'}).catch(function() {});
      }

      input.value = '';
      input.disabled = true;
      sendBtn.disabled = true;
      _sseBuffer = '';

      appendMessage('user', message);
      var thinkingEl = addThinkingBubble();

      try {
        var response = await fetch('/api/chat', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({message: message, session: 'web:direct'})
        });

        var reader = response.body.getReader();
        var decoder = new TextDecoder();

        while (true) {
          var result = await reader.read();
          if (result.done) break;
          var events = parseSSEChunk(decoder.decode(result.value));
          for (var i = 0; i < events.length; i++) {
            var ev = events[i];
            if (ev.type === 'progress') {
              updateThinkingBubble(ev.text);
            } else if (ev.type === 'response') {
              removeThinkingBubble();
              appendMessage('agent', ev.text);
            } else if (ev.type === 'error') {
              removeThinkingBubble();
              appendMessage('agent', 'Error: ' + ev.text);
            } else if (ev.type === 'done') {
              removeThinkingBubble();
            }
          }
        }
      } catch(err) {
        removeThinkingBubble();
        appendMessage('agent', 'Connection error: ' + err.message);
      } finally {
        input.disabled = false;
        sendBtn.disabled = false;
        input.focus();
      }
    }

    // ── Collapsible subsections ────────────────────────────────────────────────
    function toggleSection(id) {
      var el = document.getElementById(id);
      if (!el) return;
      var isOpen = el.classList.contains('open');
      el.classList.toggle('open');
      var btn = document.querySelector('[data-section="' + id + '"]');
      if (btn) btn.classList.toggle('open', !isOpen);
    }

    // ── Channel cards ──────────────────────────────────────────────────────────
    function toggleChannel(header) {
      var body = header.nextElementSibling;
      var icon = header.querySelector('.channel-expand-icon');
      if (body.style.display === 'block') {
        body.style.display = 'none';
        icon.textContent = '▼';
      } else {
        body.style.display = 'block';
        icon.textContent = '▲';
      }
    }

    // ── MCP Servers ────────────────────────────────────────────────────────────
    function buildEnvRowHTML(key, val) {
      return '<div class="env-row">' +
        '<input type="text" class="env-key settings-input" placeholder="KEY" value="' + escapeHtml(key || '') + '">' +
        '<input type="text" class="env-value settings-input" placeholder="value" value="' + escapeHtml(val || '') + '">' +
        '<button class="remove-env-btn" onclick="this.parentElement.remove()">&#10005;</button>' +
      '</div>';
    }

    function makeMCPCard(name, data) {
      data = data || {};
      var card = document.createElement('div');
      card.className = 'mcp-server-card';

      var args = (data.args && data.args.length) ? data.args.join('\n') : '';
      var envHTML = '';
      if (data.env) {
        Object.keys(data.env).forEach(function(k) {
          envHTML += buildEnvRowHTML(k, data.env[k]);
        });
      }

      card.innerHTML =
        '<div class="mcp-card-top">' +
          '<input type="text" class="mcp-name-input settings-input" placeholder="Server name (unique)" value="' + escapeHtml(name || '') + '">' +
          '<button class="remove-card-btn" onclick="this.closest(\'.mcp-server-card\').remove()">Remove</button>' +
        '</div>' +
        '<div class="field-row">' +
          '<span class="field-label">Command</span>' +
          '<input type="text" class="mcp-command settings-input" placeholder="npx, uvx, python, ..." value="' + escapeHtml(data.command || '') + '">' +
        '</div>' +
        '<div class="field-row">' +
          '<span class="field-label">Args</span>' +
          '<textarea class="mcp-args settings-input" placeholder="One argument per line&#10;e.g. -y&#10;@modelcontextprotocol/server-everything" rows="3">' + escapeHtml(args) + '</textarea>' +
        '</div>' +
        '<div class="field-row">' +
          '<span class="field-label">URL</span>' +
          '<input type="text" class="mcp-url settings-input" placeholder="http://... (for HTTP transport)" value="' + escapeHtml(data.url || '') + '">' +
        '</div>' +
        '<div class="env-section">' +
          '<span class="env-section-label">Environment Variables</span>' +
          '<div class="env-rows">' + envHTML + '</div>' +
          '<button class="add-small-btn" onclick="addEnvRow(this)">+ Add Env Var</button>' +
        '</div>';

      return card;
    }

    function addEnvRow(btn) {
      var envRows = btn.previousElementSibling;
      var tmp = document.createElement('div');
      tmp.innerHTML = buildEnvRowHTML('', '');
      envRows.appendChild(tmp.firstChild);
    }

    function addMCPCard() {
      var list = document.getElementById('mcp-servers-list');
      list.appendChild(makeMCPCard('', {}));
    }

    function renderMCPServers(mcpServers) {
      var list = document.getElementById('mcp-servers-list');
      list.innerHTML = '';
      if (!mcpServers) return;
      Object.keys(mcpServers).forEach(function(name) {
        list.appendChild(makeMCPCard(name, mcpServers[name]));
      });
    }

    function collectMCPServers() {
      var servers = {};
      document.querySelectorAll('.mcp-server-card').forEach(function(card) {
        var name = card.querySelector('.mcp-name-input').value.trim();
        if (!name) return;
        var argsText = card.querySelector('.mcp-args').value.trim();
        var args = argsText ? argsText.split('\n').map(function(s) { return s.trim(); }).filter(Boolean) : [];
        var env = {};
        card.querySelectorAll('.env-row').forEach(function(row) {
          var k = row.querySelector('.env-key').value.trim();
          if (k) env[k] = row.querySelector('.env-value').value;
        });
        servers[name] = {
          command: card.querySelector('.mcp-command').value.trim(),
          args: args,
          env: env,
          url: card.querySelector('.mcp-url').value.trim()
        };
      });
      return servers;
    }

    // ── Settings: load ─────────────────────────────────────────────────────────
    async function loadConfig() {
      try {
        var resp = await fetch('/api/config');
        if (!resp.ok) return;
        var cfg = await resp.json();

        function getPath(obj, path) {
          return path.split('.').reduce(function(o, k) {
            return (o !== null && o !== undefined && o[k] !== undefined) ? o[k] : undefined;
          }, obj);
        }

        document.querySelectorAll('[data-path]').forEach(function(el) {
          if (el.closest('.mcp-server-card')) return;
          var val = getPath(cfg, el.dataset.path);
          if (val === undefined || val === null) return;
          if (el.type === 'checkbox') {
            el.checked = !!val;
          } else if (el.dataset.type === 'list') {
            el.value = Array.isArray(val) ? val.join(', ') : String(val);
          } else if (el.tagName === 'SELECT') {
            el.value = String(val);
          } else {
            el.value = val !== null && val !== undefined ? String(val) : '';
          }
        });

        // MCP servers
        var mcpServers = cfg.tools && cfg.tools.mcpServers ? cfg.tools.mcpServers : {};
        renderMCPServers(mcpServers);

        // Auto-expand enabled channels
        document.querySelectorAll('.channel-card').forEach(function(card) {
          var toggle = card.querySelector('input[type="checkbox"][data-path$=".enabled"]');
          if (toggle && toggle.checked) {
            var body = card.querySelector('.channel-body');
            if (body) body.style.display = 'block';
            var icon = card.querySelector('.channel-expand-icon');
            if (icon) icon.textContent = '▲';
          }
        });

        // Update agent name in header and welcome
        var name = (cfg.agents && cfg.agents.defaults && cfg.agents.defaults.agentName) || 'Root Engine';
        _agentName = name;
        document.getElementById('agent-name').textContent = name;
        var welcomeName = document.getElementById('welcome-name');
        if (welcomeName) welcomeName.textContent = name;
      } catch(e) {
        console.warn('Could not load config:', e);
      }
    }

    // ── Settings: save ─────────────────────────────────────────────────────────
    async function saveSettings() {
      var data = {};

      document.querySelectorAll('[data-path]').forEach(function(el) {
        if (el.closest('.mcp-server-card')) return;
        var path = el.dataset.path;
        if (el.type === 'checkbox') {
          data[path] = el.checked;
        } else if (el.dataset.type === 'number') {
          data[path] = el.value === '' ? null : Number(el.value);
        } else if (el.dataset.type === 'list') {
          data[path] = el.value.split(',').map(function(s) { return s.trim(); }).filter(Boolean);
        } else {
          data[path] = el.value;
        }
      });

      data['tools.mcpServers'] = collectMCPServers();

      try {
        var resp = await fetch('/api/config', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify(data)
        });
        if (resp.ok) {
          showToast();
          var name = data['agents.defaults.agentName'] || 'Root Engine';
          _agentName = name;
          document.getElementById('agent-name').textContent = name;
          var welcomeName = document.getElementById('welcome-name');
          if (welcomeName) welcomeName.textContent = name;
        } else {
          alert('Failed to save settings.');
        }
      } catch(e) {
        alert('Error saving settings: ' + e.message);
      }
    }

    function showToast() {
      var el = document.getElementById('save-toast');
      el.classList.add('visible');
      setTimeout(function() { el.classList.remove('visible'); }, 2500);
    }

    // ── Credentials Wizard ─────────────────────────────────────────────────────
    var PROVIDER_DEFAULTS = {
      anthropic:  {model: 'anthropic/claude-opus-4-5',            keyPath: 'providers.anthropic.apiKey'},
      openai:     {model: 'openai/gpt-4o',                        keyPath: 'providers.openai.apiKey'},
      openrouter: {model: 'openrouter/anthropic/claude-opus-4-5', keyPath: 'providers.openrouter.apiKey'},
      deepseek:   {model: 'deepseek/deepseek-chat',               keyPath: 'providers.deepseek.apiKey'},
      groq:       {model: 'groq/llama-3.3-70b-versatile',         keyPath: 'providers.groq.apiKey'},
    };

    function onCredsProviderChange() {
      var provider = document.getElementById('creds-provider').value;
      document.getElementById('creds-model').value = PROVIDER_DEFAULTS[provider].model;
    }

    async function saveCredentials() {
      var provider = document.getElementById('creds-provider').value;
      var apiKey = document.getElementById('creds-key').value.trim();
      var model = document.getElementById('creds-model').value.trim();
      var errEl = document.getElementById('creds-error');
      errEl.style.display = 'none';
      if (!apiKey) {
        errEl.textContent = 'Please enter your API key.';
        errEl.style.display = 'block';
        return;
      }
      var data = {};
      data[PROVIDER_DEFAULTS[provider].keyPath] = apiKey;
      data['agents.defaults.model'] = model;
      try {
        var resp = await fetch('/api/config', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify(data)
        });
        if (!resp.ok) throw new Error('Save failed');
        document.getElementById('creds-overlay').style.display = 'none';
        await loadConfig();
        _triggerOnboarding();
      } catch(e) {
        errEl.textContent = 'Failed to save. Please try again.';
        errEl.style.display = 'block';
      }
    }

    // ── Onboarding ─────────────────────────────────────────────────────────────
    var _onboardingActive = false;

    async function _triggerOnboarding() {
      _onboardingActive = true;
      _sseBuffer = '';
      addThinkingBubble();
      try {
        var response = await fetch('/api/chat', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({message: '__START_ONBOARDING__', session: 'web:direct'})
        });
        var reader = response.body.getReader();
        var decoder = new TextDecoder();
        while (true) {
          var result = await reader.read();
          if (result.done) break;
          var events = parseSSEChunk(decoder.decode(result.value));
          for (var i = 0; i < events.length; i++) {
            var ev = events[i];
            if (ev.type === 'progress') {
              updateThinkingBubble(ev.text);
            } else if (ev.type === 'response') {
              removeThinkingBubble();
              appendMessage('agent', ev.text);
            } else if (ev.type === 'error') {
              removeThinkingBubble();
              _onboardingActive = false;
            } else if (ev.type === 'done') {
              removeThinkingBubble();
            }
          }
        }
      } catch(err) {
        removeThinkingBubble();
        _onboardingActive = false;
      }
    }

    async function checkStatus() {
      try {
        var resp = await fetch('/api/status');
        if (!resp.ok) return;
        var status = await resp.json();
        _agentName = status.agent_name || 'Root Engine';
        document.getElementById('agent-name').textContent = _agentName;
        var welcomeName = document.getElementById('welcome-name');
        if (welcomeName) welcomeName.textContent = _agentName;
        if (!status.has_api_key) {
          document.getElementById('creds-overlay').style.display = 'flex';
          return;
        }
        if (!status.onboarded) {
          _triggerOnboarding();
        }
      } catch(e) {
        console.warn('Status check failed:', e);
      }
    }

    // ── Gateway status ─────────────────────────────────────────────────────────
    async function checkGatewayStatus() {
      try {
        var resp = await fetch('/api/gateway/status');
        if (!resp.ok) return;
        var s = await resp.json();
        var dot = document.getElementById('gateway-dot');
        var btn = document.getElementById('gateway-start-btn');
        if (s.running) {
          dot.classList.add('active');
          btn.style.display = 'none';
        } else {
          dot.classList.remove('active');
          btn.style.display = 'inline-block';
        }
      } catch(e) {}
    }

    async function startGateway() {
      var btn = document.getElementById('gateway-start-btn');
      btn.textContent = 'Starting\u2026';
      btn.disabled = true;
      try {
        var resp = await fetch('/api/gateway/start', {method: 'POST'});
        var data = await resp.json();
        if (resp.ok && data.ok) {
          setTimeout(checkGatewayStatus, 1500);
          btn.textContent = 'Start';
        } else {
          btn.textContent = 'Error';
          btn.disabled = false;
        }
      } catch(e) {
        btn.textContent = 'Error';
        btn.disabled = false;
      }
    }

    // ── Init ───────────────────────────────────────────────────────────────────
    document.addEventListener('DOMContentLoaded', function() {
      loadConfig();
      checkStatus();
      checkGatewayStatus();
      setInterval(checkGatewayStatus, 15000);
      document.getElementById('msg-input').focus();
    });
  </script>
</body>
</html>"""


def _make_html(agent_name: str = "Root Engine") -> str:
    return (_HTML_TEMPLATE
        .replace("__VERSION__", __version__)
        .replace("__AGENT_NAME__", agent_name))


# ─── Global State ─────────────────────────────────────────────────────────────

_agent_loop = None
_bus = None
_cron_service = None
_heartbeat_service = None
_channel_manager = None
_gateway_running = False
_gateway_tasks: list = []


# ─── Provider Builder ─────────────────────────────────────────────────────────

def _build_provider(config):
    """Build an LLM provider from config (raises RuntimeError on failure)."""
    from root_engine.providers.litellm_provider import LiteLLMProvider
    from root_engine.providers.openai_codex_provider import OpenAICodexProvider
    from root_engine.providers.custom_provider import CustomProvider
    from root_engine.providers.registry import find_by_name

    model = config.agents.defaults.model
    provider_name = config.get_provider_name(model)
    p = config.get_provider(model)

    if provider_name == "openai_codex" or model.startswith("openai-codex/"):
        return OpenAICodexProvider(default_model=model)

    if provider_name == "custom":
        return CustomProvider(
            api_key=p.api_key if p else "no-key",
            api_base=config.get_api_base(model) or "http://localhost:8000/v1",
            default_model=model,
        )

    spec = find_by_name(provider_name) if provider_name else None
    if not model.startswith("bedrock/") and not (p and p.api_key) and not (spec and spec.is_oauth):
        raise RuntimeError(
            "No API key configured. Add one in Settings → API Keys, then send a message."
        )

    return LiteLLMProvider(
        api_key=p.api_key if p else None,
        api_base=config.get_api_base(model),
        default_model=model,
        extra_headers=p.extra_headers if p else None,
        provider_name=provider_name,
    )


# ─── Agent Factory ─────────────────────────────────────────────────────────────

async def _build_agent(config) -> None:
    """Build and assign the global AgentLoop from config."""
    global _agent_loop, _bus, _cron_service
    from root_engine.bus.queue import MessageBus
    from root_engine.agent.loop import AgentLoop
    from root_engine.config.loader import get_data_dir
    from root_engine.cron.service import CronService

    bus = MessageBus()
    provider = _build_provider(config)  # raises if no key

    cron_store_path = get_data_dir() / "cron" / "jobs.json"
    cron = CronService(cron_store_path)
    _bus = bus
    _cron_service = cron

    _agent_loop = AgentLoop(
        bus=bus,
        provider=provider,
        workspace=config.workspace_path,
        model=config.agents.defaults.model,
        temperature=config.agents.defaults.temperature,
        max_tokens=config.agents.defaults.max_tokens,
        max_iterations=config.agents.defaults.max_tool_iterations,
        memory_window=config.agents.defaults.memory_window,
        brave_api_key=config.tools.web.search.api_key or None,
        exec_config=config.tools.exec,
        cron_service=cron,
        restrict_to_workspace=config.tools.restrict_to_workspace,
        mcp_servers=config.tools.mcp_servers,
        agent_name=config.agents.defaults.agent_name,
    )


# ─── Gateway Services ──────────────────────────────────────────────────────────

async def _start_gateway_services(config) -> None:
    """Start channel manager, cron, and heartbeat as background tasks."""
    global _gateway_running, _channel_manager, _heartbeat_service, _gateway_tasks

    if _agent_loop is None or _gateway_running:
        return

    from root_engine.channels.manager import ChannelManager
    from root_engine.heartbeat.service import HeartbeatService
    from root_engine.cron.types import CronJob

    # Wire cron callback (same pattern as gateway command)
    if _cron_service:
        async def on_cron_job(job: CronJob) -> str | None:
            return await _agent_loop.process_direct(
                job.payload.message,
                session_key=f"cron:{job.id}",
                channel=job.payload.channel or "cli",
                chat_id=job.payload.to or "direct",
            )
        _cron_service.on_job = on_cron_job
        await _cron_service.start()  # non-blocking, returns immediately

    # HeartbeatService
    async def on_heartbeat(prompt: str) -> str:
        return await _agent_loop.process_direct(prompt, session_key="heartbeat")

    _heartbeat_service = HeartbeatService(
        workspace=config.workspace_path,
        on_heartbeat=on_heartbeat,
        interval_s=30 * 60,
        enabled=True,
    )
    await _heartbeat_service.start()  # non-blocking, returns immediately

    # ChannelManager (needs the shared _bus)
    _channel_manager = ChannelManager(config, _bus)

    # Kick off blocking loops as background tasks
    _gateway_tasks = [
        asyncio.create_task(_agent_loop.run()),
        asyncio.create_task(_channel_manager.start_all()),
    ]
    _gateway_running = True
    enabled = _channel_manager.enabled_channels or []
    print(f"Gateway started — channels: {', '.join(enabled) if enabled else 'none configured'}")


# ─── Route Handlers ────────────────────────────────────────────────────────────

async def handle_index(request):  # noqa: ARG001
    from root_engine.config.loader import load_config
    try:
        name = load_config().agents.defaults.agent_name
    except Exception:
        name = "Root Engine"
    return web.Response(text=_make_html(name), content_type="text/html")


async def handle_logo(request):  # noqa: ARG001
    return web.Response(text=LOGO_SVG, content_type="image/svg+xml")


async def handle_get_config(request):  # noqa: ARG001
    from root_engine.config.loader import load_config
    config = load_config()
    return web.json_response(config.model_dump(by_alias=True))


async def handle_status(request):  # noqa: ARG001
    from root_engine.config.loader import load_config
    config = load_config()
    providers = config.providers
    provider_names = [
        "anthropic", "openai", "openrouter", "deepseek", "groq",
        "gemini", "zhipu", "dashscope", "moonshot", "minimax",
        "aihubmix", "siliconflow", "custom", "vllm",
    ]
    has_api_key = any(
        bool(getattr(getattr(providers, name, None), "api_key", ""))
        for name in provider_names
    )
    return web.json_response({
        "has_api_key": has_api_key,
        "agent_name": config.agents.defaults.agent_name,
        "onboarded": config.onboarded,
    })


async def handle_complete_onboarding(request):  # noqa: ARG001
    from root_engine.config.loader import load_config, save_config
    from root_engine.config.schema import Config
    config = load_config()
    config_dict = config.model_dump(by_alias=True)
    config_dict["onboarded"] = True
    new_config = Config.model_validate(config_dict)
    save_config(new_config)
    return web.json_response({"ok": True})


async def handle_post_config(request):
    from root_engine.config.loader import load_config, save_config
    from root_engine.config.schema import Config
    global _agent_loop

    data = await request.json()
    config = load_config()
    config_dict = config.model_dump(by_alias=True)

    # Apply dot-path patches (paths use camelCase matching JSON output)
    for key_path, value in data.items():
        parts = key_path.split(".")
        obj = config_dict
        for part in parts[:-1]:
            if part not in obj or not isinstance(obj[part], dict):
                obj[part] = {}
            obj = obj[part]
        obj[parts[-1]] = value

    new_config = Config.model_validate(config_dict)
    save_config(new_config)

    # Rebuild agent if provider/model config changed
    rebuild_keys = {"providers", "agents"}
    if any(k.split(".")[0] in rebuild_keys for k in data.keys()):
        if _agent_loop:
            try:
                await _agent_loop.close_mcp()
            except Exception:
                pass
        _agent_loop = None

    return web.json_response({"ok": True})


async def handle_chat(request):
    global _agent_loop
    data = await request.json()
    message = data.get("message", "")
    session_key = data.get("session", "web:direct")

    # Intercept onboarding trigger — replace with a system-level greeting prompt
    if message == "__START_ONBOARDING__":
        from root_engine.config.loader import load_config as _lc
        _cfg = _lc()
        _an = _cfg.agents.defaults.agent_name
        message = (
            f"Please greet the user warmly and introduce yourself as {_an}. "
            f"Then in a single friendly, conversational message ask them: "
            f"1) What they would like to be called, "
            f"2) Something interesting about themselves, "
            f"3) Whether they'd like to rename you (you're currently called {_an}). "
            f"Keep it warm and natural — not a bulleted list."
        )

    response = web.StreamResponse(headers={
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",
    })
    await response.prepare(request)

    async def _send_event(payload: dict) -> None:
        line = "data: " + json.dumps(payload, ensure_ascii=False) + "\n\n"
        await response.write(line.encode())

    # Build agent lazily if not initialized
    if _agent_loop is None:
        try:
            from root_engine.config.loader import load_config
            await _build_agent(load_config())
        except Exception as exc:
            await _send_event({"type": "error", "text": str(exc)})
            await _send_event({"type": "done"})
            return response

    async def on_progress(text: str) -> None:
        await _send_event({"type": "progress", "text": text})

    try:
        result = await _agent_loop.process_direct(
            message,
            session_key=session_key,
            channel="web",
            chat_id="direct",
            on_progress=on_progress,
        )
    except Exception as exc:
        await _send_event({"type": "error", "text": str(exc)})
        await _send_event({"type": "done"})
        return response

    await _send_event({"type": "response", "text": result})
    await _send_event({"type": "done"})
    return response


async def handle_gateway_status(request):  # noqa: ARG001
    channels = _channel_manager.enabled_channels if _channel_manager else []
    return web.json_response({"running": _gateway_running, "channels": channels})


async def handle_gateway_start(request):  # noqa: ARG001
    global _agent_loop
    if _agent_loop is None:
        try:
            from root_engine.config.loader import load_config
            await _build_agent(load_config())
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
    if _gateway_running:
        return web.json_response({"ok": True, "already_running": True})
    from root_engine.config.loader import load_config
    await _start_gateway_services(load_config())
    return web.json_response({"ok": True})


# ─── App Factory ───────────────────────────────────────────────────────────────

def create_app() -> web.Application:
    app = web.Application()
    app.router.add_get("/", handle_index)
    app.router.add_get("/logo.svg", handle_logo)
    app.router.add_get("/api/config", handle_get_config)
    app.router.add_post("/api/config", handle_post_config)
    app.router.add_get("/api/status", handle_status)
    app.router.add_post("/api/complete-onboarding", handle_complete_onboarding)
    app.router.add_post("/api/chat", handle_chat)
    app.router.add_get("/api/gateway/status", handle_gateway_status)
    app.router.add_post("/api/gateway/start", handle_gateway_start)
    return app


# ─── Startup ───────────────────────────────────────────────────────────────────

async def start(port: int = 7860, gateway: bool = False) -> None:
    """Build AgentLoop and start the aiohttp server."""
    global _agent_loop

    from root_engine.config.loader import load_config
    config = load_config()

    # Try to initialize agent at startup (graceful if no API key yet)
    try:
        await _build_agent(config)
    except Exception as exc:
        print(f"Note: Agent not initialized — {exc}")
        print("Configure your API key in Settings, then send a message to activate the agent.")

    app = create_app()
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "localhost", port)
    await site.start()

    print(f"Root Engine web UI running at http://localhost:{port}")
    print("Press Ctrl+C to stop")

    if gateway and _agent_loop is not None:
        await _start_gateway_services(config)

    try:
        while True:
            await asyncio.sleep(3600)
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
    finally:
        for task in _gateway_tasks:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        if _channel_manager:
            try:
                await _channel_manager.stop_all()
            except Exception:
                pass
        if _heartbeat_service:
            _heartbeat_service.stop()
        if _cron_service:
            _cron_service.stop()
        if _agent_loop:
            try:
                await _agent_loop.close_mcp()
            except Exception:
                pass
        await runner.cleanup()


def run(port: int = 7860, gateway: bool = False) -> None:
    """Entry point — asyncio.run(start(port))."""
    try:
        asyncio.run(start(port, gateway=gateway))
    except KeyboardInterrupt:
        pass
