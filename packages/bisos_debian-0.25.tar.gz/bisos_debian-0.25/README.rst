==========================================================================================
bisos.debian: Python Command-Services for interfacing with debain facilities (eg systemd).
==========================================================================================

.. contents::
   :depth: 3
..

Overview
========

bisos.debian is a python package that uses the PyCS-Framework for
interfacing with debain facilities (eg systemd). It is a
BISOS-Capability and a Standalone-BISOS-Package. Interfaces to Debian
facilities such as systemd

*bisos.debian* is based on PyCS-Foundation and can be used both as a
Command and as a Service (invoke/perform model of remote operations)
using RPYC for central management of multiple systems.

.. _table-of-contents:

Table of Contents TOC
=====================

-  `Overview <#overview>`__
-  `Uses of bisos.debian <#uses-of-bisosdebian>`__
-  `bisos.debian as a Standalone Piece of
   BISOS <#bisosdebian-as-a-standalone-piece-of-bisos>`__
-  `Installation <#installation>`__

   -  `With pip <#with-pip>`__
   -  `With pipx <#with-pipx>`__

-  `Documentation and Blee-Panels <#documentation-and-blee-panels>`__

   -  `bisos.debian Blee-Panels <#bisosdebian-blee-panels>`__

-  `Support <#support>`__

Uses of bisos.debian
====================

Within BISOS, bisos.debian is used as a common facility.

bisos.debian as a Standalone Piece of BISOS
===========================================

bisos.debian is a standalone piece of BISOS. It can be used as a
self-contained Python package separate from BISOS. Follow the
installtion and usage instructions below for your own use.

Installation
============

The sources for the bisos.debian pip package is maintained at:
https://github.com/bisos-pip/debian.

The bisos.debian pip package is available at PYPI as
https://pypi.org/project/bisos.debian

You can install bisos.debian with pip or pipx.

With pip
--------

If you need access to bisos.debian as a python module, you can install
it with pip:

.. code:: bash

   pip install bisos.debian

With pipx
---------

If you only need access to bisos.debian as a command on command-line,
you can install it with pipx:

.. code:: bash

   pipx install bisos.debian

The following commands are made available:

-  debian.cs
-  roInv-debian.cs
-  roPerf-debian.cs

Documentation and Blee-Panels
=============================

bisos.debian is part of ByStar Digital Ecosystem http://www.by-star.net.

This module's primary documentation is in the form of Blee-Panels.
Additional information is also available in:
http://www.by-star.net/PLPC/180047

bisos.debian Blee-Panels
------------------------

bisos.debian Blee-Panles are in ./panels directory. From within Blee and
BISOS these panles are accessible under the Blee "Panels" menu.

Support
=======

| For support, criticism, comments and questions; please contact the
  author/maintainer
| `Mohsen Banan <http://mohsen.1.banan.byname.net>`__ at:
  http://mohsen.1.banan.byname.net/contact
