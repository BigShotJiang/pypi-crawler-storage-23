"""Opinionated starter packs for common EAP workflow patterns."""

