"""Public EAP package namespace."""

