from django import template

register = template.Library()

@register.filter
def to_object_display_value(value):
    """
    Formatta il valore di un oggetto per la visualizzazione nella dashboard.
    """
    return value
