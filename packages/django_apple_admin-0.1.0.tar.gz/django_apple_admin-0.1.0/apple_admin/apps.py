from django.apps import AppConfig

class AppleAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apple_admin'
    verbose_name = 'Apple Design Django Admin'
