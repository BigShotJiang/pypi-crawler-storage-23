# Django Apple Admin 🍎

A premium, Apple-style UI for the Django Admin interface. This package transforms the default Django admin into a modern, polished experience with glassmorphism, responsive tabs, and enhanced interactive components.

## Features ✨

- **Apple Aesthetic**: Premium design system with glassmorphism, refined shadows, and iOS-like typography.
- **Tabbed Interface**: Automatically transforms complex forms (like User) and Inlines into clean, organized tabs.
- **Control Center Filters**: Modern, pill-based filter UI that is space-efficient and intuitive.
- **Portaling Selects**: Custom dropdowns that float above the content using `position: fixed` to avoid z-index and overflow issues.
- **Premium Tooltips**: Custom CSS-based tooltips with backdrop-blur and smooth animations.
- **Responsive & Minimalist**: Optimized for productivity and mobile usage.
- **Zero Configuration**: Just add to `INSTALLED_APPS` before `django.contrib.admin`.

## Installation 🚀

1. Install the package via pip:
   ```bash
   pip install django-apple-admin
   ```

2. Add `apple_admin` to your `INSTALLED_APPS` **above** `django.contrib.admin`:
   ```python
   INSTALLED_APPS = [
       'apple_admin',
       'django.contrib.admin',
       ...
   ]
   ```

## Requirements 🛠️

- Django >= 4.2
- Python >= 3.10
- PrimeIcons & Tailwind CSS (included via CDN in the templates)

## Development 💻

To contribute or experiment with the code:
1. Clone the repository.
2. Install in editable mode: `pip install -e .`

## License 📄

MIT License
