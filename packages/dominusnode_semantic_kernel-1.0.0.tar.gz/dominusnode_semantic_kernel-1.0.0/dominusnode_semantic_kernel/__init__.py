"""DomiNode plugin for Microsoft Semantic Kernel."""

from dominusnode_semantic_kernel.plugin import DominusNodePlugin

__version__ = "1.0.0"
__all__ = ["DominusNodePlugin"]
