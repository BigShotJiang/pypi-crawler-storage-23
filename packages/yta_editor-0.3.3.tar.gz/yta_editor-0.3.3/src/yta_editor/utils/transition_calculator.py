from yta_editor_nodes.processor.video.transitions import CircleOpeningTransitionProcessor
from yta_editor_common.frame.helper import FrameHelper
from yta_editor_utils.texture import TextureUtils
from yta_validation.parameter import ParameterValidator
from yta_validation import PythonValidator
from yta_math_easings.enums import EasingFunctionName
from yta_math_easings.abstract import EasingFunction
from av.video.frame import VideoFrame
from quicktions import Fraction
from typing import Union

import numpy as np


# TODO: This class below could be repeated and I just
# created because I needed to (at least by now)
# TODO: The progress is not being calculated correctly
class _TransitionCalculator:
    """
    *For internal use only*

    A class to simplify the way we make the calculations
    related to a transition. This class must be used within
    a transition item that needs these kind of calculations.

    The `easing_function_name` will define the transition
    speed, that is `linear` by default.
    """

    @property
    def fps(
        self
    ) -> float:
        """
        The `fps` associated to the `transition_item` that
        is attached to this instance.
        """
        # TODO: Is this the 'output_fps' (?)
        return self._transition_item.fps
    
    @property
    def output_size(
        self
    ) -> float:
        """
        The `output_size` associated to the `transition_item`
        that is attached to this instance.
        """
        return self._transition_item.output_size

    def __init__(
        self,
        transition_item: 'TransitionTrackItem',
        duration: float,
        do_use_gpu: bool = True,
        easing_function_name: EasingFunctionName = EasingFunctionName.LINEAR,
    ):
        easing_function_name = EasingFunctionName.to_enum(easing_function_name)

        self._transition_item: 'TransitionTrackItem' = transition_item
        """
        The transition item this helper was instantiated for.
        """
        self.duration: float = duration
        """
        The duration of the transition.
        """
        self._do_use_gpu: bool = do_use_gpu
        """
        *For internal useo only*

        The boolean flag to indicate if the GPU must be used
        or not when applying the node associated to this
        transition.
        """
        self.easing_function: EasingFunction = EasingFunction.get(easing_function_name)()
        """
        The easing function to be applied in the transition
        progress to handle its speed.
        """
        # TODO: This depends on each node implementation and the
        # arguments are different. By now I'm forcing this
        self._transition_node: CircleOpeningTransitionProcessor = CircleOpeningTransitionProcessor(
            # TODO: What do I do with the 'opengl_context' here (?)
            opengl_context = None
        )
        """
        The node that will process the transition, that must
        be implemented by the child class.
        """

    # TODO: This method can be overwritten to change
    # its behaviour if the specific transition needs
    # it
    def process_frame(
        self,
        frame_a: Union['moderngl.Texture', 'np.ndarray'],
        frame_b: Union['moderngl.Texture', 'np.ndarray'],
        evaluation_context: 'EvaluationContext'
    ) -> VideoFrame:
        """
        Process the `frame_a` and the `frame_b` provided and
        apply the transition at the `t_progress` provided by
        using the node of the `TransitionTrackItem` associated
        to this instance.
        """
        # TODO: Maybe this can be placed in the general
        # class if it doesn't change

        # TODO: This can be a texture
        processed_frame = self._get_process_frame_array(
            frame_a = frame_a,
            frame_b = frame_b,
            evaluation_context = evaluation_context
        # TODO: Force this with the 'yta-numpy' utils to 'np.uint8'
        )

        processed_frame = frame_to_uint8_ndarray(
            frame = processed_frame,
            do_include_alpha = False
        )

        # if PythonValidator.is_numpy_array(processed_frame):
        #     processed_frame = processed_frame.astype(np.uint8)

        #     # frame = VideoFrame.from_ndarray(
        #     #     # TODO: Force this with the 'yta-numpy' utils to 'np.uint8'
        #     #     array = processed_frame,
        #     #     format = 'rgb24'
        #     # )
        # elif PythonValidator.is_instance_of(processed_frame, 'Texture'):
        #     processed_frame, has_alpha = FrameHelper.texture_to_ndarray(
        #         frame = processed_frame
        #     )
            
        #     # TODO: Removing the alpha channel here but, should I (?)
        #     if has_alpha:
        #         processed_frame = processed_frame[:, :, :3]

        # else:
        #     # TODO: Wtf? This should not happen
        #     raise Exception('Wowowowooo, no texture, no np.ndarray... wtf?')
        
        frame = FrameHelper.ndarray_to_videoframe(
            frame = processed_frame,
            do_include_alpha = False,
            pts = None,
            time_base = Fraction(1, self.fps)
        )
        
        # TODO: If I return this as a numpy and make the
        # transformations and then we want to use that
        # same frame within other GPU processor... we are
        # f***
        return frame
    
    # TODO: Overwrite this method to make it custom (?)
    def _get_process_frame_array(
        self,
        frame_a: Union['moderngl.Texture', 'np.ndarray'],
        frame_b: Union['moderngl.Texture', 'np.ndarray'],
        evaluation_context: 'EvaluationContext'
    ) -> Union[np.ndarray, 'moderngl.Texture']:
        """
        Get the numpy array that will be used to build the
        pyav VideoFrame that will be returned.
        """
        
        return self._transition_node.process(
            inputs = {
                'first_input': frame_a,
                'second_input': frame_b
            },
            evaluation_context = evaluation_context,
            # TODO: Maybe evaluation_context instead (?)
            # progress = self.easing_function.ease(float(evaluation_context.progress)),
            do_use_gpu = self._do_use_gpu,
            output_size = self.output_size
        )
    
    def _get_process_audio_frames(
        self,
        audio_frames_a: list['AudioFrameWrapped'],
        audio_frames_b: list['AudioFrameWrapped'],
        evaluation_context: 'EvaluationContext'
    ) -> list['AudioFrame']:
        """
        Get the numpy array that will be used to build the
        pyav AudioFrame that will be returned.
        """

        """
        TODO: I don't know how to handle the audio within the
        transitions, because each transition works in a specific
        way and making the audio behave like the video movement
        is not easy... It could be based on the 't_progress',
        using something like this below (based on S-Curve Crossfade
        weights):

        weight_a = 0.5 * (1 + math.cos(t_progress * math.pi))
        weight_b = 1 - weight_a
        mixed_audio_frames = audio_frames_a * weight_a + audio_frames_b * weight_b

        But, as I don't know actually how to do it, by now we are
        just mixing both of them during the transition time in the
        same way as the video frames are accessed.
        """
        # TODO: Move this to top (?)
        from yta_editor.utils.frame_combinator import AudioFrameCombinator
        from yta_editor.timeline import concatenate_audio_frames

        collapsed_frames = [
            concatenate_audio_frames(frames)
            for frames in [audio_frames_a, audio_frames_b]
        ]

        # We keep only the non-silent frames because
        # we will sum them after and keeping them will
        # change the results.
        non_empty_collapsed_frames = [
            frame._frame
            for frame in collapsed_frames
            if not frame.is_from_gap
        ]

        if len(non_empty_collapsed_frames) == 0:
            # If they were all silent, just keep one
            non_empty_collapsed_frames = [collapsed_frames[0]._frame]

        frames = [
            AudioFrameCombinator.sum_tracks_frames(
                tracks_frames = non_empty_collapsed_frames,
                sample_rate = self._transition_item._track.audio_fps,
                # TODO: This was not being sent before
                layout = self._transition_item._track.audio_layout,
                format = self._transition_item._track.audio_format
            )
        ]

        # for audio_frame in frames:
        #     yield audio_frame
        # TODO: Should I yield (?)
        return frames


def frame_to_uint8_ndarray(
    frame: Union['moderngl.Texture', 'np.ndarray'],
    do_include_alpha: bool = True
):
    """
    Force the `frame` provided to be transformed into
    a uint8 numpy ndarray, removing the alpha channel
    if existing and `do_include_alpha` is `False`.
    """
    if (
        not PythonValidator.is_instance_of(frame, 'Texture') and
        not PythonValidator.is_numpy_array(frame)
    ):
        # TODO: Wtf? This should not happen
        raise Exception('Wowowowooo, no texture, no np.ndarray... wtf?')
    
    if PythonValidator.is_instance_of(frame, 'Texture'):
        frame, has_alpha = FrameHelper.texture_to_ndarray(frame)

        if (
            has_alpha and
            not do_include_alpha
        ):
            frame = frame[:, :, :3]

    return TextureUtils.numpy_to_uint8(frame)