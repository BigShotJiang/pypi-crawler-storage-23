from yta_editor.transformations.effects.abstract import EffectParameters
from yta_editor.transformations.effects.video import VideoEffect
from yta_editor_nodes.processor.transparency import TransparencyNodeProcessor
from yta_editor_utils.texture import TextureUtils
from yta_editor_time.evaluation_context import EvaluationContext
from yta_editor_parameters.abstract import VideoEditorParameter
from yta_editor_parameters import ConstantVideoEditorParameter
from yta_validation.parameter import ParameterValidator
from typing import Union
from dataclasses import dataclass


# TODO: We need to define all the specific effect
# params to be able to build them properly missing
# no fields
@dataclass
class TransparencyVideoEffectParameters(EffectParameters):
    """
    The parameters to use when applying the effect
    that changes the transparency for a specific
    `evaluation_context`.

    This will be returned by the effect when
    calculated, for a specific `evaluation_context`.
    """

    def __init__(
        self,
        transparency: float
    ):
        self.transparency: float = transparency
        """
        The value to apply as transparency.
        """
        

class TransparencyVideoEffect(VideoEffect):
    """
    The effect that will change the transparency of the
    element according to the provided conditions.
    """

    def __init__(
        self,
        do_use_gpu: bool = True,
        transparency: VideoEditorParameter = ConstantVideoEditorParameter(1.0)
    ):
        ParameterValidator.validate_mandatory_bool('do_use_gpu', do_use_gpu)
        ParameterValidator.validate_mandatory_instance_of('transparency', transparency, VideoEditorParameter)
        # TODO: Transparency should be limited to [0.0, 1.0]
        # or clamped automatically

        self.do_use_gpu: bool = do_use_gpu
        """
        Flag to indicate if using GPU or not.
        """
        # TODO: Maybe 'parse_params' (?)
        self.transparency: VideoEditorParameter = transparency
        """
        The `VideoEditorParameter` that defines the value that
        should be applied for the specific `evaluation_context`
        requested.
        """

    def _get_params_at(
        self,
        evaluation_context: EvaluationContext
    ) -> TransparencyVideoEffectParameters:
        """
        *For internal use only*

        Get the parameters that must be applied at the given
        `evaluation_context`.
        """
        ParameterValidator.validate_mandatory_instance_of('evaluation_context', evaluation_context, EvaluationContext)

        return TransparencyVideoEffectParameters(
            transparency = self.transparency.evaluate(
                evaluation_context = evaluation_context
            )
        )
    
    def _apply(
        self,
        # TODO: Set the type
        frame: any,
        output_size: Union[tuple[int, int], None],
        evaluation_context: EvaluationContext
    # TODO: Set the type
    ) -> any:
        parameters = self._get_params_at(
            evaluation_context = evaluation_context
        )

        if parameters.transparency == 1.0:
            return frame
            return TextureUtils.numpy_to_uint8(frame)
        
        return TransparencyNodeProcessor(
            # TODO: What do I do with the 'opengl_context' (?)
            opengl_context = None
        ).process(
            inputs = {
                'base_input': frame
            },
            evaluation_context = evaluation_context,
            do_use_gpu = self.do_use_gpu,
            output_size = output_size,
            transparency = parameters.transparency
        )