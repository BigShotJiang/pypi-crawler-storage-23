class garnish_using:
    __slots__ = ("__decorate__", "use_args", "use_kwargs")

    def __init__(self, func, *args, __self__=None, **kwargs):
        self.use_args = args
        self.use_kwargs = kwargs
        self.__decorate__ = func

    def __get__(self, instance, owner):
        return garnish_using(
            self.__decorate__.__get__(instance, owner), *self.use_args, __self__=instance, **self.use_kwargs)

    def __call__(self, func):
        if self.__self__ is not None:
            return self.__decorate__(*self.use_args, **self.use_kwargs)
        return self.__decorate__(func, *self.use_args, **self.use_kwargs)

    __matmul__ = __call__
    __rmatmul__ = __call__


class garnish:
    __slots__ = ("__decorate__")

    def __init__(self, func):
        self.__decorate__ = func

    def __get__(self, instance, owner):
        return garnish(self.__decorate__.__get__(instance, owner))

    def __call__(self, func):
        return self.__decorate__(func)

    def use(self, *args, **kwargs):
        return garnish_using(self.__decorate__, *args, **kwargs)
    
    __matmul__ = __call__
    __rmatmul__ = __call__

