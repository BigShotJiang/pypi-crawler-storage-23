from tfcommander.__about__ import __version__
