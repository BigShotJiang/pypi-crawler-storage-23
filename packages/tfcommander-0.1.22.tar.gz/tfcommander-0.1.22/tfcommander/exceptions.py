class TFCommanderError(Exception):
    pass


class AliasNotFoundError(TFCommanderError):
    def __init__(self, alias: str):
        self.alias = alias
        super().__init__(
            f"No alias found for '{alias}'. "
            f"Use `tf alias add {alias} <ip>` to define one."
        )


class ServiceRegistrationError(TFCommanderError):
    pass


class ServiceDeregistrationError(TFCommanderError):
    pass


class ConnectionError(TFCommanderError):
    def __init__(self, host: str, original_error: Exception):
        self.host = host
        self.original_error = original_error
        super().__init__(f"Error connecting to {host}: {original_error}")


class NoDomainError(TFCommanderError):
    def __init__(self):
        super().__init__(
            "You must specify at least one domain or provide --custom-rule."
        )
