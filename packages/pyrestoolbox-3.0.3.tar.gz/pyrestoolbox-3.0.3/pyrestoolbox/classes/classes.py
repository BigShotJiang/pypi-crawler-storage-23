#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""
    pyResToolbox - A collection of Reservoir Engineering Utilities
              Copyright (C) 2022, Mark Burgoyne

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    The GNU General Public License can be found in the LICENSE directory,
    and at  <https://www.gnu.org/licenses/>.

          Contact author at mark.w.burgoyne@gmail.com

Enum classes for method selection and class_dic registry.

Enums
-----
z_method      Z-factor calculation method (DAK, HY, WYW, BNS)
c_method      Critical property method (PMC, SUT, BNS)
pb_method     Bubble point method (STAN, VALMC, VELAR)
rs_method     Solution GOR method (VELAR, STAN, VALMC)
bo_method     Oil FVF method (MCAIN, STAN)
uo_method     Oil viscosity method (BR)
deno_method   Oil density method (SWMH)
co_method     Oil compressibility method (NUM)
kr_family     Relative permeability model family (COR, LET, JER)
kr_table      Relative permeability table type (SWOF, SGOF, SGWFN)
vlp_method    VLP multiphase flow correlation (HB, WG, GRAY, BB)
hyd_method    Hydrate formation correlation (MOTIEE, TOWLER)
inhibitor     Thermodynamic hydrate inhibitor (MEOH, MEG, DEG, TEG, ETOH)

Variables
---------
class_dic     Dict mapping method parameter names to their Enum classes
"""

__all__ = [
    'z_method', 'c_method', 'pb_method', 'rs_method', 'bo_method',
    'uo_method', 'deno_method', 'co_method', 'kr_family', 'kr_table',
    'vlp_method', 'hyd_method', 'inhibitor', 'class_dic',
]

from enum import Enum

class z_method(Enum):  # Gas Z-Factor calculation model
    DAK = 0
    HY = 1
    WYW = 2
    BUR = 3
    BNS = 3

class c_method(Enum):  # Gas critical properties calculation method
    PMC = 0
    SUT = 1
    BUR = 2
    BNS = 3

class pb_method(Enum):  # Bubble point calculation method
    STAN = 0
    VALMC = 1
    VELAR = 2

class rs_method(Enum):  # Oil solution gas calculation method
    VELAR = 0
    STAN = 1
    VALMC = 2

class bo_method(Enum):  # Oil FVF calculation method
    MCAIN = 0
    STAN = 1

class uo_method(Enum):  # Oil viscosity calculation method
    BR = 0

class deno_method(Enum):  # Oil Density calculation method
    SWMH = 0

class co_method(Enum):  # Oil compressibility calculation method
    EXPLT = 0

class kr_family(Enum):  # Relative permeability family type
    COR = 0
    LET = 1
    JER = 2

class kr_table(Enum):  # Relative permeability table type
    SWOF = 0
    SGOF = 1
    SGWFN = 2

class vlp_method(Enum):  # VLP multiphase flow correlation
    HB = 0      # Hagedorn-Brown
    WG = 1      # Woldesemayat-Ghajar
    GRAY = 2    # Gray
    BB = 3      # Beggs & Brill

class hyd_method(Enum):  # Hydrate formation correlation
    MOTIEE = 0  # Motiee (1991)
    TOWLER = 1  # Towler & Mokhatab (2005)

class inhibitor(Enum):  # Thermodynamic hydrate inhibitor
    MEOH = 0    # Methanol
    MEG = 1     # Monoethylene Glycol
    DEG = 2     # Diethylene Glycol
    TEG = 3     # Triethylene Glycol
    ETOH = 4    # Ethanol

class_dic = {
    "zmethod": z_method,
    "cmethod": c_method,
    "pbmethod": pb_method,
    "rsmethod": rs_method,
    "bomethod": bo_method,
    "uomethod": uo_method,
    "denomethod": deno_method,
    "comethod": co_method,
    "krfamily": kr_family,
    "krtable": kr_table,
    "vlpmethod": vlp_method,
    "hydmethod": hyd_method,
    "inhibitor": inhibitor,
}

