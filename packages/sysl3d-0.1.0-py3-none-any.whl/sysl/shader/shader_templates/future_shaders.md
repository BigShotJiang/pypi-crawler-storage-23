# Potential Future Renderers

Here, I have added a few shadertoy examples that have stunning visualization. It would be cool to these as and when possible!


https://www.shadertoy.com/view/dsdSW4
https://www.shadertoy.com/view/cll3R4
https://www.shadertoy.com/view/tl23Rm
https://www.shadertoy.com/view/mlsSRN
https://www.shadertoy.com/view/33BXW3
https://www.shadertoy.com/view/4ftfWN

# PBR
1. https://www.shadertoy.com/view/3tlBW7
2. https://www.shadertoy.com/view/XlKSDR
3. https://www.shadertoy.com/view/XdyyDd
4. https://www.shadertoy.com/view/dsdSW4


# Best Path Trace: 
...


https://www.shadertoy.com/view/wlVXWc
https://www.shadertoy.com/view/cll3R4
https://www.shadertoy.com/view/XdVfRm
https://www.shadertoy.com/view/Dtl3WS
https://www.shadertoy.com/view/Dly3DW
https://www.shadertoy.com/view/Xds3zN

https://www.shadertoy.com/view/tl23Rm
https://www.shadertoy.com/view/dtKXDc

Voxel acceleration struct
https://www.shadertoy.com/view/flyfRz

Cone-Traced Supersampling for Signed Distance Field Rendering
https://www.shadertoy.com/view/7lSXWK

https://www.shadertoy.com/view/4sdfzn

https://www.shadertoy.com/view/7tycDG

https://www.shadertoy.com/view/MsB3W1
https://www.shadertoy.com/view/MsSGD1

https://www.shadertoy.com/view/ll33Wn

https://www.shadertoy.com/view/ltcSz7


https://www.shadertoy.com/view/4s23WV

https://www.shadertoy.com/view/4dlBDj

https://www.shadertoy.com/view/ftyXRm

https://www.shadertoy.com/view/mlsSRN

https://www.shadertoy.com/view/4cVfWt

https://www.shadertoy.com/view/7lffDj


https://www.shadertoy.com/view/mdyXRD



https://www.shadertoy.com/view/X3VGWm
https://www.shadertoy.com/view/wdX3Wl

https://www.shadertoy.com/view/33BXW3

https://www.shadertoy.com/view/Xc3fRH

https://www.shadertoy.com/view/332XRm

https://www.shadertoy.com/view/4ftfWN

https://www.shadertoy.com/view/llScRz

https://www.shadertoy.com/view/McfGW2

https://www.shadertoy.com/view/4tdyRj

https://www.shadertoy.com/view/MltcDB

https://www.shadertoy.com/view/ttXSzl

https://www.shadertoy.com/view/4ltyD4

https://www.shadertoy.com/view/WdXXR8

https://www.shadertoy.com/view/WdlXRN

https://www.shadertoy.com/view/wslSRn

https://www.shadertoy.com/view/wlyXzt

https://www.shadertoy.com/view/styGDw

https://www.shadertoy.com/view/fdSGRy

https://www.shadertoy.com/view/WtGXWm

https://www.shadertoy.com/view/4sVczV

https://www.shadertoy.com/view/tl23Rm

Ice Primitive: 
https://www.shadertoy.com/view/MtGGz1


# Also consider different Camera Controls. DOF effects.
https://www.shadertoy.com/view/wtcGDj


## TEST
https://www.shadertoy.com/view/4sVczV

https://www.shadertoy.com/view/332XRm

https://www.shadertoy.com/view/4ftfWN


https://www.shadertoy.com/view/WdlXRN



https://www.shadertoy.com/view/4tdyRj

https://www.shadertoy.com/view/XctBz4