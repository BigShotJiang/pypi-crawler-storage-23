"""
This is derived from the original shadertoy code. 
https://www.shadertoy.com/view/3tKfDG
Original Author: Jacquemet Matthieu
"""
from .main_multipass import *
from .materials import *
from .lighting import *
from .main import *