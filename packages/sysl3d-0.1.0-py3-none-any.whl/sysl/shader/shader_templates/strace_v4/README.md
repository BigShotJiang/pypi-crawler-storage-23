# TODO

2. V4 with updated material pass with locality. 



3. Local 2D materials. 




4. Save primitive number and use it for some sort of manipulation.

4. Ray tracing stochastic shooting version - V5
