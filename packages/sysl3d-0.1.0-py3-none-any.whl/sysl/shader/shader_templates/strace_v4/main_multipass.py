credits = """
// This code is derived from https://www.shadertoy.com/view/3tKfDG
// Original Author: Jacquemet Matthieu
"""
import numpy as np
from string import Template
from ...shader_module import register_shader_module, SMMap
from ...shader_mod_ext import CustomFunctionShaderModule
from ..strace_v3.main_multipass import mainImagePostTrace as mainImagePostTrace_v3
from ..strace_v3.main_multipass import mainImageBaseTemplate as mainImageBaseTemplate_v3
from ..common import CONSTANTS

CONSTANTS.update({
    "_EE": ("float", 1000.0),
})

class mainImagePostTrace_v4(mainImagePostTrace_v3):
    def __init__(self, name=None, template=None, *args, **kwargs):
        if template is None:
            template = mainImageBaseTemplate_v3
        if name is None:
            name = "mainImage_post_trace_v4"

        super().__init__(name, template, *args, **kwargs)
        self.dependencies = ["setCamera_v1", "LightPackage_v4", "ShadeRayPostTrace_v4", "ToneMapping", "BasicSun_v4"]
        self.vardeps = ["cameraDistance", "cameraOrigin", "cameraAngleX", "cameraAngleY", "resolution", "_FOCAL_LENGTH", "_ZERO", "_AA"]
        self.inputs = ["color", "fragCoord", "resolution", "ca", "lig"]
        self.outputs = ["color"]
        self.aa = 1


SMMap["mainImage_post_trace_v4"] = mainImagePostTrace_v4


ShadeRayPostTrace_v4 = register_shader_module("""
@name ShadeRayPostTrace_v4
@inputs sun, sky
@outputs color
@dependencies LightPackage_v4, SphereTracePostTrace_v4, SphereTraceGeom_v4, background_v4, SCENE_NORMAL_GEOM, MATPoint
@vardeps 
// LightPackage funccalls - DirectionLight, Sky, Env, Shadow, Shade, SkyAmbient
// Background color
// Sample color from ray
// sun : Sun light
// ro : Ray origin
// rd : Ray direction
// steps : Number of trace steps
vec3 ShadeRayPostTrace(DirectionalLight sun, vec3 ro, vec3 rd, out int steps, float dist) {

    // Hit and number of steps
    bool hit = false;
    int s = 0;
    
    // primary ray
    MATPoint res = SphereTracePostTrace(ro, rd, 100.0, hit, s, dist);
    float t = res.x;
    Material mat = res.mat;
    steps += s;

    // Position 
    vec3 pt = ro + t * rd;

    if (!hit)
        return background(rd, sun);

    // Compute normal
    vec3 n = SCENE_NORMAL_GEOM(pt);

    // Shade object with light
    vec3 reflect_dir = reflect(rd, n);
    vec3 clearcoat = vec3(0);
    vec3 reflection;

    // reflection
    if (mat.mrc.z > 0.0 || mat.mrc.y == 0.0) {

        // secondary ray
        s = 0;
        res = SphereTraceGeom(pt+n*0.0001, reflect_dir, 100.0, hit, s);
        //res = SphereTracePostTrace(pt+n*0.01, reflect_dir, 100.0, hit, s, 0.0);
        t = res.x;
        steps += s;

        if (hit) {
            vec3 rpt = pt + t * reflect_dir;
            vec3 rn = SCENE_NORMAL_GEOM(rpt);
            vec3 sec_reflection = Env(reflect(reflect_dir, rn), sun);
            clearcoat = Shade(sun, res.mat, rpt, reflect_dir, rn, 
                            sec_reflection, sec_reflection*mat.mrc.z);
        } else
            clearcoat = Env(reflect_dir, sun);
    }
    if (mat.mrc.y == 0.0)
        reflection = clearcoat;
    else {
        float r = 1.0/max(mat.mrc.y, 0.00001);
        float v = Shadow(pt+n*0.0001, reflect_dir, 1000.0, r);
        reflection = mix(SkyAmbient(sun)*0.1, Env(reflect_dir, sun), v);
    }


    clearcoat *= mat.mrc.z;

    return Shade(sun, mat, pt, rd, n, reflection, clearcoat);
}""")

CONSTANTS.update({
    "_ST_EPSILON": ("float", 0.0001),
})

SphereTracePostTrace_v4 = register_shader_module("""
@name SphereTracePostTrace_v4
@inputs ro, rd, rdx, rdy, lig
@outputs col
@dependencies SCENE_EXPRESSION, MatFloor_v4
@vardeps _SCENE_RADIUS, _SCENE_BOX_CENTER, _SCENE_BOX_SIZE, _ZERO, _RAYCAST_MAX_STEPS, 
@vardeps _RAYCAST_CONSERVATIVE_STEPPING_RATE
MATPoint SphereTracePostTrace(in vec3 ro, in vec3 rd, float e, out bool _h,out int _s, float dist){

    MATPoint res;
    res.x = -1.0;

    // 1) Sphere cull: cheap dot/mul vs. complex SDF
    float b = dot(ro, ro) - _SCENE_RADIUS*_SCENE_RADIUS;
    float c = dot(ro, rd);
    float disc = c*c - b;
    if (disc <= 0.0) {
        _h = false;
        _s = 0;
        return res;
    }
    // no intersection with sphere
    float s   = sqrt(disc);
    float t0  = -c - s;
    float t1  = -c + s;
    if (t1 < 0.0) {
        _h = false;
        _s = 0;
        return res;
    }                   // both intersections behind camera

    float tmin = max(max(1.0, t0), dist);
    float tmax = min(20.0, t1);

    // 3) _AABB test
    vec3 inv_rd = 1.0 / rd;  // hoist reciprocal
    vec3 tA = ( _SCENE_BOX_CENTER - _SCENE_BOX_SIZE - ro ) * inv_rd;
    vec3 tB = ( _SCENE_BOX_CENTER + _SCENE_BOX_SIZE - ro ) * inv_rd;

    vec3 tMin3 = min(tA, tB);
    vec3 tMax3 = max(tA, tB);

    float tbmin = max( max(tMin3.x, tMin3.y), tMin3.z );
    float tbmax = min( min(tMax3.x, tMax3.y), tMax3.z );

    if (tbmin < tbmax && tbmax > 0.0 && tbmin < tmax) {
        tmin = max(tmin, tbmin);
        tmax = min(tmax, tbmax);

        // 4) Ray‐march only in [tmin, tmax]
        float t = tmin;
        for (int i = _ZERO; i < _RAYCAST_MAX_STEPS && t < tmax; i++) {
            MATPoint h = SCENE_EXPRESSION(ro + rd * t);
            if (abs(h.x) < 0.0001) {
                res.x = t;
                res.mat = h.mat;
                _h = true;
                _s = i;
                break;
            }
            t += h.x * _RAYCAST_CONSERVATIVE_STEPPING_RATE;
        }
    }

    return res;
}""")


SphereTraceGeom_v4 = register_shader_module("""
@name SphereTraceGeom_v4
@inputs ro, rd, rdx, rdy, lig
@outputs col
@dependencies GEOM_EXPRESSION, SCENE_EXPRESSION, MatFloor_v4
@vardeps _SCENE_RADIUS, _SCENE_BOX_CENTER, _SCENE_BOX_SIZE, _ZERO, _RAYCAST_MAX_STEPS, 
@vardeps _RAYCAST_CONSERVATIVE_STEPPING_RATE
MATPoint SphereTraceGeom(in vec3 ro, in vec3 rd, float e, out bool _h,out int _s){

    MATPoint res;
    res.x = -1.0;

    // 1) Sphere cull: cheap dot/mul vs. complex SDF
    float b = dot(ro, ro) - _SCENE_RADIUS*_SCENE_RADIUS;
    float c = dot(ro, rd);
    float disc = c*c - b;
    if (disc <= 0.0) {
        _h = false;
        _s = 0;
        return res;
    }
    // no intersection with sphere
    float s   = sqrt(disc);
    float t0  = -c - s;
    float t1  = -c + s;
    if (t1 < 0.0) {
        _h = false;
        _s = 0;
        return res;
    }                   // both intersections behind camera

    float tmin = max(1.0, t0);
    float tmax = min(20.0, t1);

    // 3) _AABB test
    vec3 inv_rd = 1.0 / rd;  // hoist reciprocal
    vec3 tA = ( _SCENE_BOX_CENTER - _SCENE_BOX_SIZE - ro ) * inv_rd;
    vec3 tB = ( _SCENE_BOX_CENTER + _SCENE_BOX_SIZE - ro ) * inv_rd;

    vec3 tMin3 = min(tA, tB);
    vec3 tMax3 = max(tA, tB);

    float tbmin = max( max(tMin3.x, tMin3.y), tMin3.z );
    float tbmax = min( min(tMax3.x, tMax3.y), tMax3.z );
    float t = 0.0;
    if (tbmin < tbmax && tbmax > 0.0 && tbmin < tmax) {
        tmin = max(tmin, tbmin);
        tmax = min(tmax, tbmax);

        // 4) Ray‐march only in [tmin, tmax]
        t = tmin;
        for (int i = _ZERO; i < _RAYCAST_MAX_STEPS && t < tmax; i++) {
            vec2 h = GEOM_EXPRESSION(ro + rd * t);
            if (abs(h.x) < 0.0001) {
                _h = true;
                _s = i;
                break;
            }
            t += h.x * _RAYCAST_CONSERVATIVE_STEPPING_RATE;
        }
    }
    res = SCENE_EXPRESSION(ro + rd * t);
    return res;
}""")

