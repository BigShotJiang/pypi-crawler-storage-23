from __future__ import annotations

import json
from pathlib import Path

from kernite.cli import main as cli_main
from kernite.evaluator import evaluate_execute


EXPECTED_STARTER_FILES = {
    "README.md",
    "policy.json",
    "execute-request.denied.json",
    "execute-request.approved.json",
    "guard.py",
}


def _read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _snapshot_files(path: Path) -> dict[str, str]:
    return {
        name: (path / name).read_text(encoding="utf-8")
        for name in sorted(EXPECTED_STARTER_FILES)
    }


def test_start_creates_expected_files(tmp_path: Path) -> None:
    target = tmp_path / "kernite"

    exit_code = cli_main(["start", "--dir", str(target)])

    assert exit_code == 0
    assert target.exists()
    assert {entry.name for entry in target.iterdir()} == EXPECTED_STARTER_FILES


def test_scaffold_alias_matches_start_output(tmp_path: Path) -> None:
    start_target = tmp_path / "start-bundle"
    scaffold_target = tmp_path / "scaffold-bundle"

    assert cli_main(["start", "--dir", str(start_target)]) == 0
    assert cli_main(["scaffold", "--dir", str(scaffold_target)]) == 0

    assert _snapshot_files(start_target) == _snapshot_files(scaffold_target)


def test_start_rerun_requires_force_when_directory_non_empty(tmp_path: Path) -> None:
    target = tmp_path / "kernite"

    assert cli_main(["start", "--dir", str(target)]) == 0
    exit_code = cli_main(["start", "--dir", str(target)])

    assert exit_code == 1


def test_start_force_overwrites_bundle_deterministically(tmp_path: Path) -> None:
    target = tmp_path / "kernite"

    assert cli_main(["start", "--dir", str(target)]) == 0
    first_snapshot = _snapshot_files(target)

    (target / "README.md").write_text("modified\n", encoding="utf-8")
    (target / "policy.json").write_text("{}", encoding="utf-8")

    assert cli_main(["start", "--dir", str(target), "--force"]) == 0
    second_snapshot = _snapshot_files(target)

    assert second_snapshot == first_snapshot


def test_generated_requests_have_expected_decisions(tmp_path: Path) -> None:
    target = tmp_path / "kernite"
    assert cli_main(["start", "--dir", str(target)]) == 0

    denied_request = _read_json(target / "execute-request.denied.json")
    approved_request = _read_json(target / "execute-request.approved.json")

    denied = evaluate_execute(denied_request, idempotency_key="starter-denied-test")
    approved = evaluate_execute(
        approved_request, idempotency_key="starter-approved-test"
    )

    assert denied["data"]["decision"] == "denied"
    assert set(denied["data"]["reason_codes"]) == {
        "required_currency",
        "amount_over_limit",
    }
    assert approved["data"]["decision"] == "approved"
    assert approved["data"]["reason_codes"] == []
