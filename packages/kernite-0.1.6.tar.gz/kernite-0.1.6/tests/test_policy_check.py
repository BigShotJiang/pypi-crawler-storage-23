from __future__ import annotations

from kernite.policy_check import check_policy_coverage
from kernite.policy_generate import generate_policy_artifacts


def _base_openapi() -> dict:
    return {
        "openapi": "3.0.3",
        "info": {"title": "Demo", "version": "1.0.0"},
        "paths": {
            "/invoices": {
                "post": {
                    "operationId": "createInvoice",
                    "x-kernite": {
                        "governed": True,
                        "object_type": "invoice",
                        "operation": "create",
                        "policy_key": "invoice_create_guard",
                        "mode": "enforce",
                    },
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["currency"],
                                    "properties": {
                                        "currency": {
                                            "type": "string",
                                            "enum": ["USD", "KRW"],
                                        }
                                    },
                                }
                            }
                        }
                    },
                }
            }
        },
    }


def test_check_policy_coverage_fails_when_x_kernite_missing() -> None:
    openapi = _base_openapi()
    del openapi["paths"]["/invoices"]["post"]["x-kernite"]

    report = check_policy_coverage(openapi)

    assert report["valid"] is False
    assert any(v["code"] == "missing_x_kernite" for v in report["violations"])


def test_check_policy_coverage_rejects_invalid_x_kernite_operation() -> None:
    openapi = _base_openapi()
    openapi["paths"]["/invoices"]["post"]["x-kernite"]["operation"] = "run"

    report = check_policy_coverage(openapi)

    assert report["valid"] is False
    assert any(v["code"] == "invalid_x_kernite_field" for v in report["violations"])


def test_check_policy_coverage_strict_detects_missing_mapping_and_bundle() -> None:
    openapi = _base_openapi()
    mapping = {
        "schema_version": "kernite.policy.mapping.v1",
        "operations": [],
    }
    bundle = {
        "schema_version": "kernite.policy.bundle.v1",
        "policies": [],
    }

    report = check_policy_coverage(openapi, mapping=mapping, bundle=bundle, strict=True)

    assert report["valid"] is False
    codes = {item["code"] for item in report["violations"]}
    assert "mapping_missing_operation" in codes
    assert "bundle_missing_policy" in codes


def test_check_policy_coverage_passes_when_fully_covered() -> None:
    openapi = _base_openapi()
    artifacts = generate_policy_artifacts(openapi)

    report = check_policy_coverage(
        openapi,
        mapping=artifacts["mapping"],
        bundle=artifacts["bundle"],
        strict=True,
    )

    assert report["valid"] is True
    assert report["violations"] == []


def test_check_policy_coverage_non_strict_downgrades_coverage_violations() -> None:
    openapi = _base_openapi()
    mapping = {
        "schema_version": "kernite.policy.mapping.v1",
        "operations": [],
    }

    report = check_policy_coverage(openapi, mapping=mapping, strict=False)

    assert report["valid"] is True
    assert report["violations"] == []
    assert report["warnings"]
