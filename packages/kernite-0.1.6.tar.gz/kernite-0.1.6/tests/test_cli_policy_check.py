from __future__ import annotations

import json
from pathlib import Path

from kernite.cli import main as cli_main


def _write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")


def _base_openapi(with_extension: bool = True) -> dict:
    operation: dict = {
        "operationId": "createInvoice",
        "requestBody": {
            "content": {
                "application/json": {
                    "schema": {
                        "type": "object",
                        "required": ["currency"],
                        "properties": {
                            "currency": {"type": "string", "enum": ["USD", "KRW"]}
                        },
                    }
                }
            }
        },
    }
    if with_extension:
        operation["x-kernite"] = {
            "governed": True,
            "object_type": "invoice",
            "operation": "create",
            "policy_key": "invoice_create_guard",
            "mode": "enforce",
        }

    return {
        "openapi": "3.0.3",
        "info": {"title": "Demo", "version": "1.0.0"},
        "paths": {"/invoices": {"post": operation}},
    }


def test_cli_policy_generate_writes_expected_artifacts(tmp_path: Path) -> None:
    schema_path = tmp_path / "openapi.json"
    out_dir = tmp_path / "generated"
    _write_json(schema_path, _base_openapi(with_extension=True))

    exit_code = cli_main(
        [
            "policy",
            "generate",
            "--schema",
            str(schema_path),
            "--out-dir",
            str(out_dir),
        ]
    )

    assert exit_code == 0
    assert (out_dir / "policy-bundle.generated.json").exists()
    assert (out_dir / "policy-map.generated.json").exists()
    assert (out_dir / "policy-generation-report.json").exists()


def test_cli_check_returns_non_zero_for_uncovered_schema(tmp_path: Path) -> None:
    schema_path = tmp_path / "openapi.json"
    report_path = tmp_path / "check-report.json"
    _write_json(schema_path, _base_openapi(with_extension=False))

    exit_code = cli_main(
        [
            "check",
            "--schema",
            str(schema_path),
            "--report-out",
            str(report_path),
        ]
    )

    assert exit_code == 1
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert report["valid"] is False
    assert any(v["code"] == "missing_x_kernite" for v in report["violations"])


def test_cli_check_returns_zero_for_generated_coverage(tmp_path: Path) -> None:
    schema_path = tmp_path / "openapi.json"
    out_dir = tmp_path / "generated"
    report_path = tmp_path / "check-report.json"
    _write_json(schema_path, _base_openapi(with_extension=True))

    generate_exit = cli_main(
        [
            "policy",
            "generate",
            "--schema",
            str(schema_path),
            "--out-dir",
            str(out_dir),
        ]
    )
    assert generate_exit == 0

    exit_code = cli_main(
        [
            "check",
            "--schema",
            str(schema_path),
            "--mapping",
            str(out_dir / "policy-map.generated.json"),
            "--bundle",
            str(out_dir / "policy-bundle.generated.json"),
            "--report-out",
            str(report_path),
            "--strict",
        ]
    )

    assert exit_code == 0
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert report["valid"] is True
    assert report["violations"] == []


def test_cli_check_returns_two_for_yaml_schema_file(tmp_path: Path) -> None:
    schema_path = tmp_path / "openapi.yaml"
    schema_path.write_text("openapi: 3.0.3\npaths: {}\n", encoding="utf-8")

    exit_code = cli_main(
        [
            "check",
            "--schema",
            str(schema_path),
        ]
    )

    assert exit_code == 2
