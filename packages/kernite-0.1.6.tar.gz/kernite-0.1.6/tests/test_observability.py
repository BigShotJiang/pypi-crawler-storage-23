from __future__ import annotations

import json
import sqlite3

import pytest

from kernite.observability import (
    CsvDecisionSink,
    DecisionSinkError,
    JsonlDecisionSink,
    ObservabilityConfig,
    SqliteDecisionSink,
    evaluate_execute_controlled,
)


def _base_request() -> dict:
    return {
        "workspace_id": "workspace-demo",
        "principal": {
            "type": "token",
            "id": "api:ops-bot",
        },
        "object_type": "invoice",
        "operation": "create",
        "payload": {
            "amount": 1200,
        },
        "policy_context": {
            "governed": True,
            "selected_policies": [
                {
                    "policy_key": "invoice_create_guard",
                    "policy_version": 1,
                    "effect": "allow",
                    "rules": [
                        {
                            "rule_key": "require_currency",
                            "rule_definition": {
                                "type": "required_fields",
                                "fields": ["currency"],
                            },
                            "reason_code": "required_currency",
                            "reason_message": "currency is required.",
                        }
                    ],
                }
            ],
        },
    }


def test_evaluate_execute_controlled_enforce_blocks_denied() -> None:
    result = evaluate_execute_controlled(_base_request(), mode="enforce")

    assert result["allow_write"] is False
    assert result["decision_raw"] == "denied"
    assert result["decision_effective"] == "denied"
    assert result["governance"]["data"]["decision"] == "denied"


def test_evaluate_execute_controlled_observe_allows_and_logs_jsonl(tmp_path) -> None:
    sink = JsonlDecisionSink(tmp_path / "events.jsonl")

    result = evaluate_execute_controlled(_base_request(), mode="observe", sink=sink)

    assert result["allow_write"] is True
    assert result["decision_raw"] == "denied"
    assert result["decision_effective"] == "approved"
    assert result["sink_status"] == "written"

    lines = (tmp_path / "events.jsonl").read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 1
    event = json.loads(lines[0])
    assert event["mode"] == "observe"
    assert event["decision_raw"] == "denied"
    assert "required_currency" in event["reason_codes"]


def test_evaluate_execute_controlled_skip_writes_csv_event(tmp_path) -> None:
    sink = CsvDecisionSink(tmp_path / "events.csv")

    result = evaluate_execute_controlled(_base_request(), mode="skip", sink=sink)

    assert result["allow_write"] is True
    assert result["decision_raw"] == "skipped"
    assert result["governance"] is None
    assert result["sink_status"] == "written"

    csv_text = (tmp_path / "events.csv").read_text(encoding="utf-8")
    assert "decision_raw" in csv_text
    assert "skipped" in csv_text


def test_sqlite_sink_persists_event(tmp_path) -> None:
    db_path = tmp_path / "events.sqlite"
    sink = SqliteDecisionSink(db_path)

    result = evaluate_execute_controlled(_base_request(), mode="observe", sink=sink)

    assert result["sink_status"] == "written"

    with sqlite3.connect(db_path) as conn:
        row = conn.execute(
            "select mode, decision_raw, decision_effective from kernite_decision_events"
        ).fetchone()

    assert row == ("observe", "denied", "approved")


def test_sink_failure_policy_fail_open_marks_failed_open() -> None:
    class FailingSink:
        def emit(self, event: dict) -> None:  # pragma: no cover - inline helper
            raise RuntimeError("sink write failed")

    result = evaluate_execute_controlled(
        _base_request(),
        mode="observe",
        sink=FailingSink(),
        sink_failure_policy="fail_open",
    )

    assert result["sink_status"] == "failed_open"
    assert "sink_error" in result


def test_sink_failure_policy_fail_closed_raises() -> None:
    class FailingSink:
        def emit(self, event: dict) -> None:  # pragma: no cover - inline helper
            raise RuntimeError("sink write failed")

    with pytest.raises(DecisionSinkError):
        evaluate_execute_controlled(
            _base_request(),
            mode="observe",
            sink=FailingSink(),
            sink_failure_policy="fail_closed",
        )


def test_observability_config_from_env_defaults_and_overrides() -> None:
    config = ObservabilityConfig.from_env(
        {
            "KERNITE_MODE": "observe",
            "KERNITE_SINK": "jsonl",
            "KERNITE_SINK_PATH": "/tmp/kernite-events.jsonl",
            "KERNITE_SINK_FAIL_POLICY": "fail_closed",
        }
    )

    assert config.mode == "observe"
    assert config.sink_type == "jsonl"
    assert config.sink_path == "/tmp/kernite-events.jsonl"
    assert config.sink_failure_policy == "fail_closed"
