from __future__ import annotations

import pytest

from kernite.policy_generate import generate_policy_artifacts


def _openapi_with_write_ops() -> dict:
    return {
        "openapi": "3.0.3",
        "info": {"title": "Demo", "version": "1.0.0"},
        "paths": {
            "/invoices": {
                "post": {
                    "operationId": "createInvoice",
                    "x-kernite": {
                        "governed": True,
                        "object_type": "invoice",
                        "operation": "create",
                        "policy_key": "invoice_create_guard",
                        "mode": "enforce",
                    },
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["currency"],
                                    "properties": {
                                        "currency": {
                                            "type": "string",
                                            "enum": ["USD", "KRW"],
                                        },
                                        "amount": {
                                            "type": "number",
                                            "maximum": 1000,
                                        },
                                    },
                                }
                            }
                        },
                    },
                }
            },
            "/payments/{id}": {
                "patch": {
                    "operationId": "updatePayment",
                    "x-kernite": {
                        "governed": True,
                        "object_type": "payment",
                        "operation": "update",
                        "policy_key": "payment_update_guard",
                        "mode": "observe",
                    },
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/PaymentUpdate"}
                            }
                        }
                    },
                }
            },
        },
        "components": {
            "schemas": {
                "PaymentUpdate": {
                    "type": "object",
                    "properties": {
                        "status": {
                            "type": "string",
                            "enum": ["pending", "posted"],
                        },
                        "note": {
                            "type": "string",
                            "maxLength": 10,
                        },
                    },
                }
            }
        },
    }


def test_generate_policy_artifacts_is_deterministic() -> None:
    openapi = _openapi_with_write_ops()

    first = generate_policy_artifacts(openapi)
    second = generate_policy_artifacts(openapi)

    assert first == second


def test_generate_policy_artifacts_builds_required_enum_and_max_rules() -> None:
    artifacts = generate_policy_artifacts(_openapi_with_write_ops())

    policies = artifacts["bundle"]["policies"]
    invoice_policy = next(
        policy for policy in policies if policy["policy_key"] == "invoice_create_guard"
    )

    rule_types = {rule["rule_definition"]["type"] for rule in invoice_policy["rules"]}
    assert "required_fields" in rule_types
    assert "allowed_values" in rule_types
    assert "max_value" in rule_types

    required_rule = next(
        rule
        for rule in invoice_policy["rules"]
        if rule["rule_definition"]["type"] == "required_fields"
    )
    assert required_rule["rule_definition"]["fields"] == ["currency"]


def test_generate_policy_artifacts_records_unsupported_constraints() -> None:
    artifacts = generate_policy_artifacts(_openapi_with_write_ops())

    unsupported = artifacts["report"]["unsupported_constraints"]
    assert unsupported
    assert any(
        item["code"] == "unsupported_constraint" and "maxLength" in item["message"]
        for item in unsupported
    )


def test_generate_policy_artifacts_fail_on_unsupported_marks_invalid() -> None:
    artifacts = generate_policy_artifacts(
        _openapi_with_write_ops(),
        fail_on_unsupported=True,
    )

    assert artifacts["report"]["valid"] is False


def test_generate_policy_artifacts_ref_cycle_is_rejected() -> None:
    openapi = {
        "openapi": "3.0.3",
        "info": {"title": "Cycle", "version": "1.0.0"},
        "paths": {
            "/things": {
                "post": {
                    "x-kernite": {
                        "governed": True,
                        "object_type": "thing",
                        "operation": "create",
                        "policy_key": "thing_create_guard",
                    },
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/A"}
                            }
                        }
                    },
                }
            }
        },
        "components": {
            "schemas": {
                "A": {"$ref": "#/components/schemas/B"},
                "B": {"$ref": "#/components/schemas/A"},
            }
        },
    }

    with pytest.raises(ValueError):
        generate_policy_artifacts(openapi)
