from __future__ import annotations

import json
import threading
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer

from kernite.cli import _GovernanceHandler


def _start_server() -> tuple[ThreadingHTTPServer, threading.Thread]:
    server = ThreadingHTTPServer(("127.0.0.1", 0), _GovernanceHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, thread


def _post_json(path: str, payload: object) -> tuple[int, dict]:
    server, thread = _start_server()
    try:
        host, port = server.server_address
        conn = HTTPConnection(host, port, timeout=5)
        body = json.dumps(payload).encode("utf-8")
        conn.request(
            "POST",
            path,
            body=body,
            headers={"Content-Type": "application/json"},
        )
        response = conn.getresponse()
        status = response.status
        data = json.loads(response.read().decode("utf-8"))
        conn.close()
        return status, data
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def test_validate_endpoint_reports_non_object_body_as_validation_error():
    status, data = _post_json("/validate/execute", ["not", "an", "object"])

    assert status == 200
    assert data["data"]["valid"] is False
    assert any(error["field"] == "body" for error in data["data"]["errors"])


def test_execute_endpoint_keeps_non_object_body_as_http_400():
    status, data = _post_json("/execute", ["not", "an", "object"])

    assert status == 400
    assert data["message"] == "Execute payload is invalid."
    assert data["data"]["valid"] is False
    assert any(error["field"] == "body" for error in data["data"]["errors"])


def test_execute_endpoint_accepts_associate_operation():
    status, data = _post_json(
        "/execute",
        {
            "workspace_id": "workspace-demo",
            "principal": {
                "type": "token",
                "id": "api:ops-bot",
                "attributes": {"hasVerifiedEmail": True},
            },
            "object_type": "association_edge",
            "operation": "associate",
            "payload": {"source_id": "rec-001", "target_id": "rec-002"},
            "policy_context": {
                "governed": True,
                "selected_policies": [
                    {
                        "policy_key": "association_verified_email",
                        "policy_version": 1,
                        "effect": "allow",
                        "conditions": [
                            {"left": "operation", "op": "eq", "right": "associate"},
                            {
                                "left": "principal.attributes.hasVerifiedEmail",
                                "op": "eq",
                                "right": True,
                            },
                        ],
                        "rules": [],
                    }
                ],
            },
        },
    )

    assert status == 200
    assert data["data"]["decision"] == "approved"


def test_policy_generate_endpoint_returns_bundle_and_mapping():
    status, data = _post_json(
        "/policy/generate",
        {
            "openapi": {
                "openapi": "3.0.3",
                "info": {"title": "Demo", "version": "1.0.0"},
                "paths": {
                    "/invoices": {
                        "post": {
                            "operationId": "createInvoice",
                            "x-kernite": {
                                "governed": True,
                                "object_type": "invoice",
                                "operation": "create",
                                "policy_key": "invoice_create_guard",
                                "mode": "enforce",
                            },
                            "requestBody": {
                                "content": {
                                    "application/json": {
                                        "schema": {
                                            "type": "object",
                                            "required": ["currency"],
                                            "properties": {
                                                "currency": {
                                                    "type": "string",
                                                    "enum": ["USD", "KRW"],
                                                }
                                            },
                                        }
                                    }
                                }
                            },
                        }
                    }
                },
            },
            "options": {"default_mode": "enforce"},
        },
    )

    assert status == 200
    assert data["message"] == "Policy bundle generated."
    assert data["data"]["bundle"]["schema_version"] == "kernite.policy.bundle.v1"
    assert data["data"]["mapping"]["schema_version"] == "kernite.policy.mapping.v1"
    assert data["data"]["report"]["valid"] is True


def test_policy_check_endpoint_reports_missing_x_kernite():
    status, data = _post_json(
        "/policy/check",
        {
            "openapi": {
                "openapi": "3.0.3",
                "info": {"title": "Demo", "version": "1.0.0"},
                "paths": {
                    "/invoices": {
                        "post": {
                            "requestBody": {
                                "content": {
                                    "application/json": {
                                        "schema": {
                                            "type": "object",
                                            "properties": {
                                                "currency": {"type": "string"}
                                            },
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
            },
            "options": {"strict": True},
        },
    )

    assert status == 200
    assert data["message"] == "Schema coverage check failed."
    assert data["data"]["valid"] is False
    assert any(v["code"] == "missing_x_kernite" for v in data["data"]["violations"])
