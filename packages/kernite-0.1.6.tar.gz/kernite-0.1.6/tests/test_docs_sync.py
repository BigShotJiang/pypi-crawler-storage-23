from __future__ import annotations

import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "sync_readme_from_docs_index.py"


def test_readme_sync_is_up_to_date() -> None:
    result = subprocess.run(
        [
            sys.executable,
            str(SCRIPT),
            "--check",
            "--readme",
            str(ROOT / "README.md"),
            "--index",
            str(ROOT / "docs" / "index.mdx"),
        ],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, (
        f"README sync drift detected.\nstdout:\n{result.stdout}\nstderr:\n{result.stderr}"
    )
