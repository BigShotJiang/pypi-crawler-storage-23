#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path


BEGIN_MARKER = "<!-- BEGIN SYNC:docs/index.mdx -->"
END_MARKER = "<!-- END SYNC:docs/index.mdx -->"
AUTOGEN_NOTE = (
    "<!-- Auto-generated from docs/index.mdx by "
    "scripts/sync_readme_from_docs_index.py. Do not edit this block manually. -->"
)


def _extract_index_body(index_text: str) -> str:
    text = index_text.replace("\r\n", "\n")
    if text.startswith("---\n"):
        end = text.find("\n---\n", 4)
        if end == -1:
            raise ValueError("Invalid frontmatter in docs/index.mdx")
        text = text[end + len("\n---\n") :]
    return text.strip() + "\n"


def _build_synced_block(index_body: str) -> str:
    return (
        f"{BEGIN_MARKER}\n"
        f"{AUTOGEN_NOTE}\n\n"
        f"{index_body.rstrip()}\n"
        f"{END_MARKER}"
    )


def _replace_or_insert_sync_block(readme_text: str, synced_block: str) -> str:
    text = readme_text.replace("\r\n", "\n")

    begin_idx = text.find(BEGIN_MARKER)
    end_idx = text.find(END_MARKER)
    if begin_idx != -1 and end_idx != -1 and end_idx > begin_idx:
        end_idx += len(END_MARKER)
        return text[:begin_idx] + synced_block + text[end_idx:]

    heading_end = text.find("\n")
    if heading_end == -1:
        return synced_block + "\n"

    insert_pos = heading_end + 1
    if text[insert_pos : insert_pos + 1] != "\n":
        return text[:insert_pos] + "\n" + synced_block + "\n\n" + text[insert_pos:]
    return text[: insert_pos + 1] + synced_block + "\n\n" + text[insert_pos + 1 :]


def sync_readme_from_index(*, readme_path: Path, index_path: Path, check_only: bool) -> int:
    readme_text = readme_path.read_text(encoding="utf-8")
    index_text = index_path.read_text(encoding="utf-8")

    index_body = _extract_index_body(index_text)
    synced_block = _build_synced_block(index_body)
    updated_readme = _replace_or_insert_sync_block(readme_text, synced_block)

    if updated_readme == readme_text.replace("\r\n", "\n"):
        print("README sync is up to date.")
        return 0

    if check_only:
        print("README sync drift detected. Run sync_readme_from_docs_index.py to update.")
        return 1

    readme_path.write_text(updated_readme, encoding="utf-8")
    print(f"Updated {readme_path}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Sync README block from docs/index.mdx",
    )
    parser.add_argument(
        "--readme",
        default="README.md",
        help="Path to README file (default: README.md)",
    )
    parser.add_argument(
        "--index",
        default="docs/index.mdx",
        help="Path to docs index file (default: docs/index.mdx)",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Check-only mode; exits non-zero on drift.",
    )

    args = parser.parse_args()

    return sync_readme_from_index(
        readme_path=Path(args.readme),
        index_path=Path(args.index),
        check_only=args.check,
    )


if __name__ == "__main__":
    raise SystemExit(main())
