from __future__ import annotations

import csv
import json
import os
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Protocol

from kernite.evaluator import evaluate_execute


VALID_RUNTIME_MODES: set[str] = {"enforce", "observe", "skip"}
VALID_SINK_TYPES: set[str] = {"none", "jsonl", "csv", "sqlite"}
VALID_SINK_FAILURE_POLICIES: set[str] = {"fail_open", "fail_closed"}


class DecisionSink(Protocol):
    def emit(self, event: Mapping[str, Any]) -> None: ...


class DecisionSinkError(RuntimeError):
    pass


class JsonlDecisionSink:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, event: Mapping[str, Any]) -> None:
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(dict(event), ensure_ascii=False, sort_keys=True))
            handle.write("\n")


class CsvDecisionSink:
    _FIELDNAMES = [
        "schema_version",
        "created_at",
        "mode",
        "allow_write",
        "decision_raw",
        "decision_effective",
        "sink_status",
        "workspace_id",
        "principal_id",
        "object_type",
        "operation",
        "ctx_id",
        "trace_hash",
        "idempotency_key",
        "reason_codes",
    ]

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, event: Mapping[str, Any]) -> None:
        file_exists = self.path.exists()
        row = {
            "schema_version": event.get("schema_version"),
            "created_at": event.get("created_at"),
            "mode": event.get("mode"),
            "allow_write": event.get("allow_write"),
            "decision_raw": event.get("decision_raw"),
            "decision_effective": event.get("decision_effective"),
            "sink_status": event.get("sink_status"),
            "workspace_id": event.get("workspace_id"),
            "principal_id": event.get("principal_id"),
            "object_type": event.get("object_type"),
            "operation": event.get("operation"),
            "ctx_id": event.get("ctx_id"),
            "trace_hash": event.get("trace_hash"),
            "idempotency_key": event.get("idempotency_key"),
            "reason_codes": json.dumps(
                list(event.get("reason_codes") or []),
                ensure_ascii=False,
                sort_keys=True,
            ),
        }

        with self.path.open("a", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=self._FIELDNAMES)
            if not file_exists or self.path.stat().st_size == 0:
                writer.writeheader()
            writer.writerow(row)


class SqliteDecisionSink:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        with sqlite3.connect(self.path) as conn:
            conn.execute(
                """
                create table if not exists kernite_decision_events (
                    id integer primary key autoincrement,
                    created_at text not null,
                    mode text not null,
                    allow_write integer not null,
                    decision_raw text not null,
                    decision_effective text not null,
                    sink_status text not null,
                    workspace_id text,
                    principal_id text,
                    object_type text,
                    operation text,
                    ctx_id text,
                    trace_hash text,
                    idempotency_key text,
                    reason_codes text not null,
                    schema_version text not null
                )
                """
            )

    def emit(self, event: Mapping[str, Any]) -> None:
        with sqlite3.connect(self.path) as conn:
            conn.execute(
                """
                insert into kernite_decision_events (
                    created_at,
                    mode,
                    allow_write,
                    decision_raw,
                    decision_effective,
                    sink_status,
                    workspace_id,
                    principal_id,
                    object_type,
                    operation,
                    ctx_id,
                    trace_hash,
                    idempotency_key,
                    reason_codes,
                    schema_version
                ) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    str(event.get("created_at") or ""),
                    str(event.get("mode") or ""),
                    1 if bool(event.get("allow_write")) else 0,
                    str(event.get("decision_raw") or ""),
                    str(event.get("decision_effective") or ""),
                    str(event.get("sink_status") or ""),
                    str(event.get("workspace_id") or "") or None,
                    str(event.get("principal_id") or "") or None,
                    str(event.get("object_type") or "") or None,
                    str(event.get("operation") or "") or None,
                    str(event.get("ctx_id") or "") or None,
                    str(event.get("trace_hash") or "") or None,
                    str(event.get("idempotency_key") or "") or None,
                    json.dumps(
                        list(event.get("reason_codes") or []),
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                    str(event.get("schema_version") or "kernite.decision_event.v1"),
                ),
            )


@dataclass(frozen=True)
class ObservabilityConfig:
    mode: str = "enforce"
    sink_type: str = "none"
    sink_path: str | None = None
    sink_failure_policy: str = "fail_open"

    @classmethod
    def from_env(
        cls,
        environ: Mapping[str, str] | None = None,
    ) -> "ObservabilityConfig":
        env = os.environ if environ is None else environ
        mode = str(env.get("KERNITE_MODE") or "enforce").strip().lower()
        if mode not in VALID_RUNTIME_MODES:
            mode = "enforce"

        sink_type = str(env.get("KERNITE_SINK") or "none").strip().lower()
        if sink_type not in VALID_SINK_TYPES:
            sink_type = "none"

        sink_path = str(env.get("KERNITE_SINK_PATH") or "").strip() or None

        sink_failure_policy = (
            str(env.get("KERNITE_SINK_FAIL_POLICY") or "fail_open").strip().lower()
        )
        if sink_failure_policy not in VALID_SINK_FAILURE_POLICIES:
            sink_failure_policy = "fail_open"

        return cls(
            mode=mode,
            sink_type=sink_type,
            sink_path=sink_path,
            sink_failure_policy=sink_failure_policy,
        )

    def create_sink(self) -> DecisionSink | None:
        if self.sink_type == "none":
            return None

        if not self.sink_path:
            raise ValueError("KERNITE_SINK_PATH is required when sink is enabled.")

        if self.sink_type == "jsonl":
            return JsonlDecisionSink(self.sink_path)
        if self.sink_type == "csv":
            return CsvDecisionSink(self.sink_path)
        if self.sink_type == "sqlite":
            return SqliteDecisionSink(self.sink_path)

        raise ValueError(f"Unsupported sink type: {self.sink_type}")


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_str(value: Any) -> str | None:
    normalized = str(value or "").strip()
    return normalized or None


def _build_event(
    *,
    request_body: Mapping[str, Any],
    governance: Mapping[str, Any] | None,
    mode: str,
    allow_write: bool,
    decision_raw: str,
    decision_effective: str,
    sink_status: str,
) -> dict[str, Any]:
    principal = request_body.get("principal")
    principal_id = None
    if isinstance(principal, Mapping):
        principal_id = _safe_str(principal.get("id"))

    data = governance.get("data") if isinstance(governance, Mapping) else {}
    if not isinstance(data, Mapping):
        data = {}

    reason_codes_raw = data.get("reason_codes")
    reason_codes: list[str] = []
    if isinstance(reason_codes_raw, list):
        reason_codes = [str(code) for code in reason_codes_raw]

    return {
        "schema_version": "kernite.decision_event.v1",
        "created_at": _utc_now_iso(),
        "mode": mode,
        "allow_write": allow_write,
        "decision_raw": decision_raw,
        "decision_effective": decision_effective,
        "sink_status": sink_status,
        "workspace_id": _safe_str(request_body.get("workspace_id")),
        "principal_id": principal_id,
        "object_type": _safe_str(request_body.get("object_type")),
        "operation": _safe_str(request_body.get("operation")),
        "ctx_id": _safe_str(governance.get("ctx_id"))
        if isinstance(governance, Mapping)
        else None,
        "trace_hash": _safe_str(data.get("trace_hash")),
        "idempotency_key": _safe_str(data.get("idempotency_key")),
        "reason_codes": reason_codes,
    }


def evaluate_execute_controlled(
    request_body: Mapping[str, Any],
    *,
    idempotency_key: str | None = None,
    mode: str = "enforce",
    sink: DecisionSink | None = None,
    sink_failure_policy: str = "fail_open",
) -> dict[str, Any]:
    normalized_mode = str(mode or "enforce").strip().lower()
    if normalized_mode not in VALID_RUNTIME_MODES:
        raise ValueError("mode must be one of: enforce, observe, skip")

    normalized_sink_failure_policy = (
        str(sink_failure_policy or "fail_open").strip().lower()
    )
    if normalized_sink_failure_policy not in VALID_SINK_FAILURE_POLICIES:
        raise ValueError("sink_failure_policy must be one of: fail_open, fail_closed")

    governance: dict[str, Any] | None = None
    if normalized_mode == "skip":
        decision_raw = "skipped"
        decision_effective = "approved"
        allow_write = True
    else:
        governance = evaluate_execute(request_body, idempotency_key=idempotency_key)
        data = governance.get("data") or {}
        decision_raw = str(data.get("decision") or "denied")

        if normalized_mode == "observe":
            decision_effective = "approved"
            allow_write = True
        else:
            decision_effective = decision_raw
            allow_write = decision_raw == "approved"

    sink_status = "skipped"
    sink_error = None

    event = _build_event(
        request_body=request_body,
        governance=governance,
        mode=normalized_mode,
        allow_write=allow_write,
        decision_raw=decision_raw,
        decision_effective=decision_effective,
        sink_status=sink_status,
    )

    if sink is not None:
        try:
            sink.emit(event)
            sink_status = "written"
        except Exception as exc:  # noqa: BLE001
            if normalized_sink_failure_policy == "fail_closed":
                raise DecisionSinkError(str(exc)) from exc
            sink_status = "failed_open"
            sink_error = str(exc)

    event["sink_status"] = sink_status

    result = {
        "allow_write": allow_write,
        "mode": normalized_mode,
        "decision_raw": decision_raw,
        "decision_effective": decision_effective,
        "governance": governance,
        "sink_status": sink_status,
    }
    if sink_error is not None:
        result["sink_error"] = sink_error
    return result
