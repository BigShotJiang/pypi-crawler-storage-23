from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

from kernite.evaluator import execute_request
from kernite.openapi_tools import OpenApiValidationError, load_openapi_json_file
from kernite.policy_check import check_policy_coverage, check_policy_response
from kernite.policy_generate import generate_policy_artifacts, generate_policy_response
from kernite.starter import scaffold_starter_bundle
from kernite.validation import validate_execute_request


def _json_response(
    handler: BaseHTTPRequestHandler, status: int, body: dict[str, Any]
) -> None:
    encoded = json.dumps(body, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(encoded)))
    handler.end_headers()
    handler.wfile.write(encoded)


class _GovernanceHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/health":
            _json_response(self, 200, {"status": "ok"})
            return
        _json_response(self, 404, {"message": "Not found"})

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path not in (
            "/execute",
            "/v1/execute",
            "/validate/execute",
            "/v1/validate/execute",
            "/policy/generate",
            "/v1/policy/generate",
            "/policy/check",
            "/v1/policy/check",
        ):
            _json_response(self, 404, {"message": "Not found"})
            return

        length_header = self.headers.get("Content-Length") or "0"
        try:
            length = int(length_header)
        except ValueError:
            _json_response(self, 400, {"message": "Invalid Content-Length"})
            return

        raw = self.rfile.read(length) if length > 0 else b"{}"
        try:
            body = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError:
            _json_response(self, 400, {"message": "Invalid JSON payload"})
            return

        idempotency_key = self.headers.get("Idempotency-Key")
        if path in ("/validate/execute", "/v1/validate/execute"):
            result = validate_execute_request(body, idempotency_key=idempotency_key)
            _json_response(self, 200, result)
            return

        if path in ("/execute", "/v1/execute"):
            status, result = execute_request(body, idempotency_key=idempotency_key)
            _json_response(self, status, result)
            return

        if path in ("/policy/generate", "/v1/policy/generate"):
            status, result = generate_policy_response(body)
            _json_response(self, status, result)
            return

        if path in ("/policy/check", "/v1/policy/check"):
            status, result = check_policy_response(body)
            _json_response(self, status, result)
            return

        _json_response(self, 404, {"message": "Not found"})


def _serve(host: str, port: int) -> None:
    server = ThreadingHTTPServer((host, port), _GovernanceHandler)
    print(f"kernite serving on http://{host}:{port}", flush=True)
    server.serve_forever()


def _add_scaffold_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--dir",
        default="kernite",
        help="Target directory for starter bundle (default: ./kernite)",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite files when target directory is non-empty.",
    )


def _load_json_file(path: str) -> Any:
    payload = Path(path).read_text(encoding="utf-8")
    return json.loads(payload)


def _write_json_file(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _handle_policy_generate(args: argparse.Namespace) -> int:
    try:
        openapi = load_openapi_json_file(args.schema)
    except (OpenApiValidationError, OSError, json.JSONDecodeError) as exc:
        print(str(exc), file=sys.stderr, flush=True)
        return 2

    try:
        artifacts = generate_policy_artifacts(
            openapi,
            default_mode=args.default_mode,
            fail_on_unsupported=args.fail_on_unsupported,
        )
    except (OpenApiValidationError, ValueError) as exc:
        print(str(exc), file=sys.stderr, flush=True)
        return 2

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    bundle_path = out_dir / "policy-bundle.generated.json"
    mapping_path = out_dir / "policy-map.generated.json"
    report_path = out_dir / "policy-generation-report.json"

    _write_json_file(bundle_path, artifacts["bundle"])
    _write_json_file(mapping_path, artifacts["mapping"])
    _write_json_file(report_path, artifacts["report"])

    print(f"Wrote {bundle_path}", flush=True)
    print(f"Wrote {mapping_path}", flush=True)
    print(f"Wrote {report_path}", flush=True)

    summary = artifacts["report"]["summary"]
    print(
        (
            "Policy generation summary: "
            f"write_operations={summary['write_operations']} "
            f"governed_operations={summary['governed_operations']} "
            f"policies_generated={summary['policies_generated']} "
            f"unsupported_constraints={summary['unsupported_constraints']}"
        ),
        flush=True,
    )

    if not artifacts["report"]["valid"]:
        return 1
    return 0


def _handle_check(args: argparse.Namespace) -> int:
    try:
        openapi = load_openapi_json_file(args.schema)
        mapping = _load_json_file(args.mapping) if args.mapping else None
        bundle = _load_json_file(args.bundle) if args.bundle else None
    except (OpenApiValidationError, OSError, json.JSONDecodeError) as exc:
        print(str(exc), file=sys.stderr, flush=True)
        return 2

    try:
        report = check_policy_coverage(
            openapi,
            mapping=mapping,
            bundle=bundle,
            strict=args.strict,
        )
    except (OpenApiValidationError, ValueError) as exc:
        print(str(exc), file=sys.stderr, flush=True)
        return 2

    report_out = Path(args.report_out)
    _write_json_file(report_out, report)

    print(
        (
            "Policy check summary: "
            f"write_operations={report['summary']['write_operations']} "
            f"violations={report['summary']['violations']} "
            f"warnings={report['summary']['warnings']} "
            f"strict={report['summary']['strict']}"
        ),
        flush=True,
    )

    if report["violations"]:
        for violation in report["violations"][:10]:
            print(
                f"- {violation['code']}: {violation['message']}",
                flush=True,
            )

    print(f"Wrote {report_out}", flush=True)

    return 0 if report["valid"] else 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="kernite")
    subparsers = parser.add_subparsers(dest="command")

    serve_parser = subparsers.add_parser(
        "serve", help="Start reference governance API server"
    )
    serve_parser.add_argument(
        "--host", default="127.0.0.1", help="Host to bind (default: 127.0.0.1)"
    )
    serve_parser.add_argument(
        "--port", default=8000, type=int, help="Port to bind (default: 8000)"
    )

    start_parser = subparsers.add_parser(
        "start",
        help="Scaffold a starter bundle with policy and execute requests.",
    )
    _add_scaffold_args(start_parser)

    scaffold_parser = subparsers.add_parser(
        "scaffold",
        help="Alias for `start` starter-bundle scaffolding.",
    )
    _add_scaffold_args(scaffold_parser)

    policy_parser = subparsers.add_parser(
        "policy",
        help="Policy artifact utilities.",
    )
    policy_subparsers = policy_parser.add_subparsers(dest="policy_command")

    policy_generate_parser = policy_subparsers.add_parser(
        "generate",
        help="Generate Kernite policy artifacts from OpenAPI JSON.",
    )
    policy_generate_parser.add_argument(
        "--schema",
        required=True,
        help="Path to OpenAPI JSON file.",
    )
    policy_generate_parser.add_argument(
        "--out-dir",
        required=True,
        help="Output directory for generated artifacts.",
    )
    policy_generate_parser.add_argument(
        "--default-mode",
        choices=("enforce", "observe", "skip"),
        default="enforce",
        help="Default x-kernite mode when not explicitly defined.",
    )
    policy_generate_parser.add_argument(
        "--fail-on-unsupported",
        action="store_true",
        help="Mark report invalid when unsupported OpenAPI constraints are found.",
    )

    check_parser = subparsers.add_parser(
        "check",
        help="Check OpenAPI schema coverage against Kernite contract.",
    )
    check_parser.add_argument(
        "--schema",
        required=True,
        help="Path to OpenAPI JSON file.",
    )
    check_parser.add_argument(
        "--mapping",
        help="Optional policy mapping JSON file.",
    )
    check_parser.add_argument(
        "--bundle",
        help="Optional policy bundle JSON file.",
    )
    check_parser.add_argument(
        "--report-out",
        default="kernite-check-report.json",
        help="Path to write machine-readable check report JSON.",
    )
    check_parser.add_argument(
        "--strict",
        action="store_true",
        default=True,
        help="Fail on uncovered governance checks (default behavior).",
    )
    check_parser.add_argument(
        "--no-strict",
        dest="strict",
        action="store_false",
        help="Downgrade coverage-only violations to warnings.",
    )

    args = parser.parse_args(argv)

    if args.command == "serve":
        _serve(args.host, args.port)
        return 0

    if args.command in {"start", "scaffold"}:
        try:
            target = scaffold_starter_bundle(args.dir, force=args.force)
        except (FileExistsError, ValueError) as exc:
            print(str(exc), file=sys.stderr, flush=True)
            return 1

        print(
            f"kernite starter bundle created at {target}",
            flush=True,
        )
        return 0

    if args.command == "policy" and args.policy_command == "generate":
        return _handle_policy_generate(args)

    if args.command == "check":
        return _handle_check(args)

    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
