from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Mapping, Sequence


WRITE_HTTP_METHODS: tuple[str, ...] = ("post", "put", "patch", "delete")
HTTP_METHOD_TO_OPERATION: dict[str, str] = {
    "post": "create",
    "put": "update",
    "patch": "update",
    "delete": "delete",
}
VALID_KERNITE_OPERATIONS: set[str] = {
    "create",
    "update",
    "archive",
    "activate",
    "delete",
    "associate",
}
VALID_KERNITE_MODES: set[str] = {"enforce", "observe", "skip"}


class OpenApiValidationError(ValueError):
    pass


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def openapi_sha256(document: Mapping[str, Any]) -> str:
    digest = hashlib.sha256(canonical_json(document).encode("utf-8")).hexdigest()
    return f"sha256:{digest}"


def slugify(value: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9]+", "_", str(value or "").strip().lower())
    text = re.sub(r"_+", "_", text).strip("_")
    return text or "value"


def ensure_openapi_document(document: Any) -> dict[str, Any]:
    if not isinstance(document, Mapping):
        raise OpenApiValidationError("OpenAPI document must be a JSON object.")

    openapi_version = str(document.get("openapi") or "").strip()
    if not openapi_version:
        raise OpenApiValidationError("OpenAPI document must include `openapi` version.")
    if not openapi_version.startswith("3."):
        raise OpenApiValidationError("Only OpenAPI 3.x documents are supported in v1.")

    paths = document.get("paths")
    if not isinstance(paths, Mapping):
        raise OpenApiValidationError("OpenAPI document must include object `paths`.")

    return dict(document)


def load_openapi_json_file(path: str | Path) -> dict[str, Any]:
    file_path = Path(path)
    suffix = file_path.suffix.lower()
    if suffix in {".yaml", ".yml"}:
        raise OpenApiValidationError(
            "YAML OpenAPI is not supported in v1. Convert to JSON and retry."
        )

    raw = file_path.read_text(encoding="utf-8")
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        if raw.lstrip().startswith("openapi:") or raw.lstrip().startswith("---"):
            raise OpenApiValidationError(
                "Detected non-JSON input. YAML OpenAPI is not supported in v1; convert to JSON and retry."
            ) from exc
        raise OpenApiValidationError(f"Invalid JSON schema: {exc}") from exc

    return ensure_openapi_document(payload)


def infer_operation_from_method(method: str) -> str:
    return HTTP_METHOD_TO_OPERATION.get(str(method).strip().lower(), "update")


def infer_object_type_from_path(path: str) -> str | None:
    segments = [segment for segment in str(path).split("/") if segment]
    static_segments = [segment for segment in segments if not segment.startswith("{")]
    if not static_segments:
        return None

    leaf = slugify(static_segments[-1])
    if leaf.endswith("ies") and len(leaf) > 3:
        return f"{leaf[:-3]}y"
    if leaf.endswith("s") and len(leaf) > 1:
        return leaf[:-1]
    return leaf


def build_operation_id(*, method: str, path: str, operation: Mapping[str, Any]) -> str:
    operation_id = str(operation.get("operationId") or "").strip()
    if operation_id:
        return operation_id
    return slugify(f"{method}_{path}")


def _resolve_json_pointer(document: Any, pointer: str) -> Any:
    if not pointer.startswith("#/"):
        raise OpenApiValidationError(f"Only local refs are supported: {pointer}")

    current = document
    for token in pointer[2:].split("/"):
        token = token.replace("~1", "/").replace("~0", "~")
        if isinstance(current, Mapping):
            if token not in current:
                raise OpenApiValidationError(
                    f"Unknown ref token `{token}` in `{pointer}`"
                )
            current = current[token]
            continue
        if isinstance(current, Sequence) and not isinstance(
            current, (str, bytes, bytearray)
        ):
            try:
                index = int(token)
            except ValueError as exc:
                raise OpenApiValidationError(
                    f"Ref token `{token}` must be array index in `{pointer}`"
                ) from exc
            if index < 0 or index >= len(current):
                raise OpenApiValidationError(
                    f"Ref index `{index}` out of range in `{pointer}`"
                )
            current = current[index]
            continue
        raise OpenApiValidationError(
            f"Ref token `{token}` is not resolvable in `{pointer}`"
        )

    return current


def resolve_refs(
    value: Any,
    *,
    document: Mapping[str, Any],
    seen_refs: tuple[str, ...] = (),
) -> Any:
    if isinstance(value, Mapping):
        ref_value = value.get("$ref")
        if ref_value is not None:
            ref = str(ref_value).strip()
            if not ref:
                raise OpenApiValidationError("$ref must be a non-empty string.")
            if ref in seen_refs:
                cycle = " -> ".join([*seen_refs, ref])
                raise OpenApiValidationError(f"Ref cycle detected: {cycle}")
            target = _resolve_json_pointer(document, ref)
            return resolve_refs(
                target,
                document=document,
                seen_refs=(*seen_refs, ref),
            )

        resolved: dict[str, Any] = {}
        for key, item in value.items():
            if key == "$ref":
                continue
            resolved[str(key)] = resolve_refs(
                item,
                document=document,
                seen_refs=seen_refs,
            )
        return resolved

    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [
            resolve_refs(item, document=document, seen_refs=seen_refs) for item in value
        ]

    return value


def normalize_operation_entry(
    *,
    path: str,
    method: str,
    operation: Mapping[str, Any],
    default_mode: str,
) -> dict[str, Any]:
    normalized_method = str(method).strip().lower()
    operation_id = build_operation_id(
        method=normalized_method,
        path=path,
        operation=operation,
    )

    extension_errors: list[dict[str, str]] = []

    x_kernite = operation.get("x-kernite")
    has_x_kernite = x_kernite is not None
    if x_kernite is None:
        x_kernite_dict: Mapping[str, Any] = {}
    elif isinstance(x_kernite, Mapping):
        x_kernite_dict = x_kernite
    else:
        extension_errors.append(
            {
                "field": "x-kernite",
                "code": "invalid_x_kernite_field",
                "message": "x-kernite must be an object.",
            }
        )
        x_kernite_dict = {}

    governed_raw = x_kernite_dict.get("governed", True)
    governed = True
    if isinstance(governed_raw, bool):
        governed = governed_raw
    else:
        extension_errors.append(
            {
                "field": "x-kernite.governed",
                "code": "invalid_x_kernite_field",
                "message": "x-kernite.governed must be a boolean.",
            }
        )

    mode_raw = str(x_kernite_dict.get("mode") or default_mode).strip().lower()
    mode = mode_raw or default_mode
    if mode not in VALID_KERNITE_MODES:
        extension_errors.append(
            {
                "field": "x-kernite.mode",
                "code": "invalid_x_kernite_field",
                "message": "x-kernite.mode must be one of: enforce, observe, skip.",
            }
        )
        mode = default_mode

    operation_raw = (
        str(
            x_kernite_dict.get("operation")
            or infer_operation_from_method(normalized_method)
        )
        .strip()
        .lower()
    )
    normalized_operation = operation_raw
    if normalized_operation not in VALID_KERNITE_OPERATIONS:
        extension_errors.append(
            {
                "field": "x-kernite.operation",
                "code": "invalid_x_kernite_field",
                "message": "x-kernite.operation must be one of: activate, archive, associate, create, delete, update.",
            }
        )

    object_type_raw = str(x_kernite_dict.get("object_type") or "").strip().lower()
    object_type = object_type_raw or infer_object_type_from_path(path)

    policy_key_raw = str(x_kernite_dict.get("policy_key") or "").strip()
    policy_key = policy_key_raw or None

    return {
        "path": str(path),
        "method": normalized_method,
        "operation_id": operation_id,
        "has_x_kernite": has_x_kernite,
        "governed": governed,
        "mode": mode,
        "object_type": object_type,
        "operation": normalized_operation,
        "policy_key": policy_key,
        "extension_errors": extension_errors,
        "operation_body": dict(operation),
    }


def iter_write_operations(
    document: Mapping[str, Any],
    *,
    default_mode: str = "enforce",
) -> list[dict[str, Any]]:
    normalized_default_mode = (
        str(default_mode or "enforce").strip().lower() or "enforce"
    )
    if normalized_default_mode not in VALID_KERNITE_MODES:
        raise OpenApiValidationError(
            "default_mode must be one of: enforce, observe, skip."
        )

    paths = document.get("paths")
    if not isinstance(paths, Mapping):
        raise OpenApiValidationError("OpenAPI `paths` must be an object.")

    operations: list[dict[str, Any]] = []
    for path in sorted(paths):
        path_item = paths[path]
        if not isinstance(path_item, Mapping):
            continue

        for method in WRITE_HTTP_METHODS:
            operation = path_item.get(method)
            if not isinstance(operation, Mapping):
                continue
            operations.append(
                normalize_operation_entry(
                    path=str(path),
                    method=method,
                    operation=operation,
                    default_mode=normalized_default_mode,
                )
            )

    operations.sort(key=lambda item: (item["path"], item["method"]))
    return operations


def extract_json_request_schema(
    *,
    operation_body: Mapping[str, Any],
    document: Mapping[str, Any],
) -> tuple[dict[str, Any] | None, list[dict[str, str]]]:
    warnings: list[dict[str, str]] = []

    request_body = operation_body.get("requestBody")
    if request_body is None:
        return None, warnings

    resolved_request_body = resolve_refs(request_body, document=document)
    if not isinstance(resolved_request_body, Mapping):
        warnings.append(
            {
                "code": "unsupported_openapi_shape",
                "message": "requestBody must resolve to an object.",
            }
        )
        return None, warnings

    content = resolved_request_body.get("content")
    if not isinstance(content, Mapping):
        warnings.append(
            {
                "code": "unsupported_openapi_shape",
                "message": "requestBody.content must be an object.",
            }
        )
        return None, warnings

    json_content = content.get("application/json")
    if not isinstance(json_content, Mapping):
        warnings.append(
            {
                "code": "unsupported_openapi_shape",
                "message": "Only requestBody.content['application/json'] is supported.",
            }
        )
        return None, warnings

    schema = json_content.get("schema")
    if schema is None:
        warnings.append(
            {
                "code": "unsupported_openapi_shape",
                "message": "application/json request body must include `schema`.",
            }
        )
        return None, warnings

    resolved_schema = resolve_refs(schema, document=document)
    if not isinstance(resolved_schema, Mapping):
        warnings.append(
            {
                "code": "unsupported_openapi_shape",
                "message": "Resolved request schema must be an object.",
            }
        )
        return None, warnings

    return dict(resolved_schema), warnings
