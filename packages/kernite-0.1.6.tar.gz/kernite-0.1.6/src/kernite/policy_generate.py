from __future__ import annotations

import json
import uuid
from typing import Any, Mapping

from kernite.openapi_tools import (
    OpenApiValidationError,
    canonical_json,
    ensure_openapi_document,
    extract_json_request_schema,
    iter_write_operations,
    openapi_sha256,
    slugify,
)


_UNSUPPORTED_KEYS = {
    "oneOf": "oneOf is not supported in v1 generation.",
    "anyOf": "anyOf is not supported in v1 generation.",
    "allOf": "allOf is not supported in v1 generation.",
    "pattern": "pattern is not supported in v1 generation.",
    "minLength": "minLength is not supported in v1 generation.",
    "maxLength": "maxLength is not supported in v1 generation.",
    "minItems": "minItems is not supported in v1 generation.",
    "maxItems": "maxItems is not supported in v1 generation.",
    "uniqueItems": "uniqueItems is not supported in v1 generation.",
}


def _ctx_id() -> str:
    return f"ctx_{uuid.uuid4().hex[:12]}"


def _make_code_base(*, object_type: str, operation: str) -> str:
    return f"{slugify(object_type)}_{slugify(operation)}"


def _generated_policy_key(operation_meta: Mapping[str, Any]) -> str:
    object_type = slugify(str(operation_meta.get("object_type") or "object"))
    operation = slugify(str(operation_meta.get("operation") or "operation"))
    operation_id = slugify(str(operation_meta.get("operation_id") or "operation"))
    return f"{object_type}_{operation}_{operation_id}_guard"


def _add_unsupported(
    unsupported: list[dict[str, str]],
    *,
    operation_meta: Mapping[str, Any],
    field_path: str,
    code: str,
    message: str,
) -> None:
    unsupported.append(
        {
            "code": code,
            "message": message,
            "path": str(operation_meta["path"]),
            "method": str(operation_meta["method"]),
            "operation_id": str(operation_meta["operation_id"]),
            "field_path": field_path,
        }
    )


def _walk_schema(
    *,
    schema: Mapping[str, Any],
    operation_meta: Mapping[str, Any],
    required_fields: set[str],
    enum_constraints: list[dict[str, Any]],
    max_constraints: list[dict[str, Any]],
    unsupported: list[dict[str, str]],
    prefix: str = "",
) -> None:
    for key, message in _UNSUPPORTED_KEYS.items():
        if key in schema:
            _add_unsupported(
                unsupported,
                operation_meta=operation_meta,
                field_path=prefix.rstrip("."),
                code="unsupported_constraint",
                message=message,
            )

    schema_type = str(schema.get("type") or "").strip().lower()
    if schema_type == "array" or "items" in schema:
        _add_unsupported(
            unsupported,
            operation_meta=operation_meta,
            field_path=prefix.rstrip("."),
            code="unsupported_constraint",
            message="Array constraints are not supported in v1 generation.",
        )

    raw_required = schema.get("required")
    if isinstance(raw_required, list):
        for field in raw_required:
            field_name = str(field).strip()
            if not field_name:
                continue
            required_fields.add(f"{prefix}{field_name}")

    properties = schema.get("properties")
    if not isinstance(properties, Mapping):
        return

    for property_name in sorted(properties):
        raw_child = properties[property_name]
        if not isinstance(raw_child, Mapping):
            continue
        child = dict(raw_child)
        field_path = f"{prefix}{property_name}"

        raw_enum = child.get("enum")
        if isinstance(raw_enum, list) and raw_enum:
            enum_values = sorted(raw_enum, key=canonical_json)
            enum_constraints.append(
                {
                    "field_path": field_path,
                    "values": enum_values,
                }
            )

        if "maximum" in child:
            maximum = child.get("maximum")
            if isinstance(maximum, (int, float)) and not isinstance(maximum, bool):
                max_constraints.append(
                    {
                        "field_path": field_path,
                        "max": maximum,
                    }
                )
            else:
                _add_unsupported(
                    unsupported,
                    operation_meta=operation_meta,
                    field_path=field_path,
                    code="unsupported_constraint",
                    message="maximum must be numeric for v1 generation.",
                )

        _walk_schema(
            schema=child,
            operation_meta=operation_meta,
            required_fields=required_fields,
            enum_constraints=enum_constraints,
            max_constraints=max_constraints,
            unsupported=unsupported,
            prefix=f"{field_path}.",
        )


def _build_rules(
    *,
    schema: Mapping[str, Any],
    object_type: str,
    operation: str,
    operation_meta: Mapping[str, Any],
    unsupported: list[dict[str, str]],
) -> list[dict[str, Any]]:
    required_fields: set[str] = set()
    enum_constraints: list[dict[str, Any]] = []
    max_constraints: list[dict[str, Any]] = []

    _walk_schema(
        schema=schema,
        operation_meta=operation_meta,
        required_fields=required_fields,
        enum_constraints=enum_constraints,
        max_constraints=max_constraints,
        unsupported=unsupported,
    )

    code_base = _make_code_base(object_type=object_type, operation=operation)

    rules: list[dict[str, Any]] = []
    if required_fields:
        sorted_fields = sorted(required_fields)
        rules.append(
            {
                "rule_key": f"require_{slugify(operation)}_fields",
                "rule_definition": {
                    "type": "required_fields",
                    "fields": sorted_fields,
                },
                "reason_code": f"{code_base}_missing_required_fields",
                "reason_message": "One or more required fields are missing.",
            }
        )

    for enum_constraint in sorted(
        enum_constraints,
        key=lambda item: str(item["field_path"]),
    ):
        field_path = str(enum_constraint["field_path"])
        rules.append(
            {
                "rule_key": f"{slugify(field_path)}_allowed_values",
                "rule_definition": {
                    "type": "allowed_values",
                    "field": field_path,
                    "values": list(enum_constraint["values"]),
                },
                "reason_code": f"{code_base}_{slugify(field_path)}_invalid_value",
                "reason_message": f"{field_path} contains a value outside allowed enum.",
            }
        )

    for max_constraint in sorted(
        max_constraints, key=lambda item: str(item["field_path"])
    ):
        field_path = str(max_constraint["field_path"])
        rules.append(
            {
                "rule_key": f"{slugify(field_path)}_max_value",
                "rule_definition": {
                    "type": "max_value",
                    "field": field_path,
                    "max": max_constraint["max"],
                },
                "reason_code": f"{code_base}_{slugify(field_path)}_over_max",
                "reason_message": f"{field_path} exceeds maximum allowed value.",
            }
        )

    return rules


def generate_policy_artifacts(
    openapi: Any,
    *,
    default_mode: str = "enforce",
    fail_on_unsupported: bool = False,
) -> dict[str, Any]:
    document = ensure_openapi_document(openapi)
    operations = iter_write_operations(document, default_mode=default_mode)

    warnings: list[dict[str, str]] = []
    unsupported: list[dict[str, str]] = []
    policies_by_key: dict[str, dict[str, Any]] = {}
    governed_scope_set: set[tuple[str, str]] = set()
    operation_map: list[dict[str, Any]] = []

    for operation_meta in operations:
        for error in operation_meta["extension_errors"]:
            warnings.append(
                {
                    "code": str(error["code"]),
                    "message": str(error["message"]),
                    "path": str(operation_meta["path"]),
                    "method": str(operation_meta["method"]),
                    "operation_id": str(operation_meta["operation_id"]),
                    "field": str(error["field"]),
                }
            )

        object_type = str(operation_meta.get("object_type") or "").strip().lower()
        if not object_type and operation_meta.get("governed"):
            warnings.append(
                {
                    "code": "unsupported_openapi_shape",
                    "message": "Unable to infer object_type from path; set x-kernite.object_type.",
                    "path": str(operation_meta["path"]),
                    "method": str(operation_meta["method"]),
                    "operation_id": str(operation_meta["operation_id"]),
                    "field": "x-kernite.object_type",
                }
            )
            object_type = "object"

        normalized_operation = (
            str(operation_meta.get("operation") or "").strip().lower()
        )
        if not normalized_operation:
            normalized_operation = "update"

        governed = bool(operation_meta.get("governed"))
        mode = str(operation_meta.get("mode") or default_mode)
        if governed:
            governed_scope_set.add((object_type, normalized_operation))

        policy_key = operation_meta.get("policy_key")
        if governed and mode in {"enforce", "observe"}:
            policy_key = str(
                policy_key or _generated_policy_key(operation_meta)
            ).strip()

            schema, schema_warnings = extract_json_request_schema(
                operation_body=operation_meta["operation_body"],
                document=document,
            )
            for warning in schema_warnings:
                warnings.append(
                    {
                        "code": str(warning["code"]),
                        "message": str(warning["message"]),
                        "path": str(operation_meta["path"]),
                        "method": str(operation_meta["method"]),
                        "operation_id": str(operation_meta["operation_id"]),
                        "field": "requestBody",
                    }
                )

            rules: list[dict[str, Any]] = []
            if schema is not None:
                rules = _build_rules(
                    schema=schema,
                    object_type=object_type,
                    operation=normalized_operation,
                    operation_meta=operation_meta,
                    unsupported=unsupported,
                )

            generated_policy = {
                "policy_key": policy_key,
                "policy_version": 1,
                "effect": "allow",
                "rules": rules,
            }
            existing_policy = policies_by_key.get(policy_key)
            if existing_policy and canonical_json(existing_policy) != canonical_json(
                generated_policy
            ):
                collision_policy_key = (
                    f"{policy_key}_{slugify(str(operation_meta['operation_id']))}"
                )
                warnings.append(
                    {
                        "code": "policy_key_collision",
                        "message": (
                            f"policy_key '{policy_key}' collided; wrote operation-specific key "
                            f"'{collision_policy_key}'."
                        ),
                        "path": str(operation_meta["path"]),
                        "method": str(operation_meta["method"]),
                        "operation_id": str(operation_meta["operation_id"]),
                        "field": "x-kernite.policy_key",
                    }
                )
                policy_key = collision_policy_key
                generated_policy["policy_key"] = policy_key
                policies_by_key[policy_key] = generated_policy
            else:
                policies_by_key[policy_key] = generated_policy

        operation_map.append(
            {
                "path": str(operation_meta["path"]),
                "method": str(operation_meta["method"]),
                "operation_id": str(operation_meta["operation_id"]),
                "governed": governed,
                "object_type": object_type,
                "operation": normalized_operation,
                "policy_key": policy_key,
                "mode": mode,
            }
        )

    operation_map.sort(key=lambda item: (item["path"], item["method"]))
    policies = [policies_by_key[key] for key in sorted(policies_by_key)]
    governed_scopes = [
        {"object_type": object_type, "operation": operation}
        for object_type, operation in sorted(governed_scope_set)
    ]

    warnings.sort(
        key=lambda item: (
            str(item.get("path") or ""),
            str(item.get("method") or ""),
            str(item.get("code") or ""),
            str(item.get("field") or ""),
        )
    )
    unsupported.sort(
        key=lambda item: (
            str(item.get("path") or ""),
            str(item.get("method") or ""),
            str(item.get("field_path") or ""),
            str(item.get("code") or ""),
        )
    )

    report_valid = True
    if fail_on_unsupported and unsupported:
        report_valid = False

    report = {
        "valid": report_valid,
        "summary": {
            "write_operations": len(operations),
            "governed_operations": sum(1 for item in operation_map if item["governed"]),
            "policies_generated": len(policies),
            "warnings": len(warnings),
            "unsupported_constraints": len(unsupported),
        },
        "warnings": warnings,
        "unsupported_constraints": unsupported,
    }

    bundle = {
        "schema_version": "kernite.policy.bundle.v1",
        "policies": policies,
        "governed_scopes": governed_scopes,
        "operation_map": operation_map,
        "source": {
            "openapi_sha256": openapi_sha256(document),
        },
    }

    mapping = {
        "schema_version": "kernite.policy.mapping.v1",
        "operations": operation_map,
    }

    return {
        "bundle": bundle,
        "mapping": mapping,
        "report": report,
    }


def generate_policy_response(payload: Any) -> tuple[int, dict[str, Any]]:
    if not isinstance(payload, Mapping):
        return 400, {
            "ctx_id": _ctx_id(),
            "message": "Invalid policy generation payload.",
            "data": {
                "error": "Request body must be an object.",
            },
        }

    options = payload.get("options")
    if options is None:
        options = {}
    if not isinstance(options, Mapping):
        return 400, {
            "ctx_id": _ctx_id(),
            "message": "Invalid policy generation payload.",
            "data": {
                "error": "options must be an object when provided.",
            },
        }

    default_mode = str(options.get("default_mode") or "enforce").strip().lower()
    fail_on_unsupported = bool(options.get("fail_on_unsupported", False))

    try:
        artifacts = generate_policy_artifacts(
            payload.get("openapi"),
            default_mode=default_mode,
            fail_on_unsupported=fail_on_unsupported,
        )
    except (OpenApiValidationError, ValueError) as exc:
        return 400, {
            "ctx_id": _ctx_id(),
            "message": "Policy generation failed.",
            "data": {
                "error": str(exc),
            },
        }

    message = "Policy bundle generated."
    if not artifacts["report"]["valid"]:
        message = "Policy bundle generated with unsupported constraints."

    return 200, {
        "ctx_id": _ctx_id(),
        "message": message,
        "data": artifacts,
    }


def dump_json_file(path: str, payload: Any) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
        handle.write("\n")
