from __future__ import annotations

import uuid
from typing import Any, Mapping

from kernite.openapi_tools import (
    OpenApiValidationError,
    VALID_KERNITE_MODES,
    ensure_openapi_document,
    iter_write_operations,
    slugify,
)


_COVERAGE_VIOLATION_CODES = {
    "missing_x_kernite",
    "missing_policy_key",
    "mapping_missing_operation",
    "bundle_missing_policy",
}


def _ctx_id() -> str:
    return f"ctx_{uuid.uuid4().hex[:12]}"


def _operation_key(*, method: str, path: str) -> str:
    return f"{str(method).strip().lower()} {str(path).strip()}"


def _violation(
    *,
    code: str,
    message: str,
    field: str,
    path: str | None = None,
    method: str | None = None,
    operation_id: str | None = None,
) -> dict[str, str]:
    violation = {
        "code": code,
        "message": message,
        "field": field,
    }
    if path:
        violation["path"] = path
    if method:
        violation["method"] = method
    if operation_id:
        violation["operation_id"] = operation_id
    return violation


def _parse_mapping(
    mapping: Any,
) -> tuple[dict[str, dict[str, Any]], list[dict[str, str]]]:
    violations: list[dict[str, str]] = []
    indexed: dict[str, dict[str, Any]] = {}

    if mapping is None:
        return indexed, violations

    if not isinstance(mapping, Mapping):
        violations.append(
            _violation(
                code="invalid_x_kernite_field",
                message="mapping must be an object.",
                field="mapping",
            )
        )
        return indexed, violations

    operations = mapping.get("operations")
    if not isinstance(operations, list):
        violations.append(
            _violation(
                code="invalid_x_kernite_field",
                message="mapping.operations must be an array.",
                field="mapping.operations",
            )
        )
        return indexed, violations

    for index, item in enumerate(operations):
        field_base = f"mapping.operations[{index}]"
        if not isinstance(item, Mapping):
            violations.append(
                _violation(
                    code="invalid_x_kernite_field",
                    message=f"{field_base} must be an object.",
                    field=field_base,
                )
            )
            continue

        path = str(item.get("path") or "").strip()
        method = str(item.get("method") or "").strip().lower()
        if not path or not method:
            violations.append(
                _violation(
                    code="invalid_x_kernite_field",
                    message=f"{field_base} must include path and method.",
                    field=field_base,
                )
            )
            continue

        indexed[_operation_key(method=method, path=path)] = dict(item)

    return indexed, violations


def _parse_bundle(bundle: Any) -> tuple[set[str], list[dict[str, str]]]:
    violations: list[dict[str, str]] = []
    policy_keys: set[str] = set()

    if bundle is None:
        return policy_keys, violations

    if not isinstance(bundle, Mapping):
        violations.append(
            _violation(
                code="invalid_x_kernite_field",
                message="bundle must be an object.",
                field="bundle",
            )
        )
        return policy_keys, violations

    policies = bundle.get("policies")
    if not isinstance(policies, list):
        violations.append(
            _violation(
                code="invalid_x_kernite_field",
                message="bundle.policies must be an array.",
                field="bundle.policies",
            )
        )
        return policy_keys, violations

    for index, policy in enumerate(policies):
        field_base = f"bundle.policies[{index}]"
        if not isinstance(policy, Mapping):
            violations.append(
                _violation(
                    code="invalid_x_kernite_field",
                    message=f"{field_base} must be an object.",
                    field=field_base,
                )
            )
            continue

        policy_key = str(policy.get("policy_key") or "").strip()
        if not policy_key:
            violations.append(
                _violation(
                    code="invalid_x_kernite_field",
                    message=f"{field_base}.policy_key must be a non-empty string.",
                    field=f"{field_base}.policy_key",
                )
            )
            continue

        rules = policy.get("rules")
        if rules is not None and not isinstance(rules, list):
            violations.append(
                _violation(
                    code="invalid_x_kernite_field",
                    message=f"{field_base}.rules must be an array.",
                    field=f"{field_base}.rules",
                )
            )

        policy_keys.add(policy_key)

    return policy_keys, violations


def check_policy_coverage(
    openapi: Any,
    *,
    mapping: Any = None,
    bundle: Any = None,
    strict: bool = True,
) -> dict[str, Any]:
    document = ensure_openapi_document(openapi)
    operations = iter_write_operations(document, default_mode="enforce")

    violations: list[dict[str, str]] = []
    warnings: list[dict[str, str]] = []

    mapping_index, mapping_violations = _parse_mapping(mapping)
    bundle_policy_keys, bundle_violations = _parse_bundle(bundle)
    violations.extend(mapping_violations)
    violations.extend(bundle_violations)

    for operation in operations:
        path = str(operation["path"])
        method = str(operation["method"])
        operation_id = str(operation["operation_id"])
        key = _operation_key(method=method, path=path)

        if not operation.get("has_x_kernite"):
            violations.append(
                _violation(
                    code="missing_x_kernite",
                    message="Write operation is missing required x-kernite extension.",
                    field="x-kernite",
                    path=path,
                    method=method,
                    operation_id=operation_id,
                )
            )

        for error in operation.get("extension_errors") or []:
            violations.append(
                _violation(
                    code="invalid_x_kernite_field",
                    message=str(error["message"]),
                    field=str(error["field"]),
                    path=path,
                    method=method,
                    operation_id=operation_id,
                )
            )

        governed = bool(operation.get("governed"))
        mode = str(operation.get("mode") or "enforce").strip().lower()
        if mode not in VALID_KERNITE_MODES:
            mode = "enforce"

        object_type = str(operation.get("object_type") or "").strip().lower()
        if governed and not object_type:
            violations.append(
                _violation(
                    code="invalid_x_kernite_field",
                    message="x-kernite.object_type is required when governed scope is enabled.",
                    field="x-kernite.object_type",
                    path=path,
                    method=method,
                    operation_id=operation_id,
                )
            )

        normalized_operation = str(operation.get("operation") or "").strip().lower()
        if governed and not normalized_operation:
            violations.append(
                _violation(
                    code="invalid_x_kernite_field",
                    message="x-kernite.operation is required when governed scope is enabled.",
                    field="x-kernite.operation",
                    path=path,
                    method=method,
                    operation_id=operation_id,
                )
            )

        policy_key = str(operation.get("policy_key") or "").strip()
        if governed and mode in {"enforce", "observe"} and not policy_key:
            violations.append(
                _violation(
                    code="missing_policy_key",
                    message="x-kernite.policy_key is required for governed enforce/observe operations.",
                    field="x-kernite.policy_key",
                    path=path,
                    method=method,
                    operation_id=operation_id,
                )
            )

        mapping_item = mapping_index.get(key)
        if mapping is not None and governed:
            if mapping_item is None:
                violations.append(
                    _violation(
                        code="mapping_missing_operation",
                        message="Governed operation is missing from mapping.operations.",
                        field="mapping.operations",
                        path=path,
                        method=method,
                        operation_id=operation_id,
                    )
                )
            else:
                mapping_object_type = (
                    str(mapping_item.get("object_type") or "").strip().lower()
                )
                if object_type and mapping_object_type != object_type:
                    violations.append(
                        _violation(
                            code="invalid_x_kernite_field",
                            message="mapping object_type does not match operation object_type.",
                            field="mapping.operations[].object_type",
                            path=path,
                            method=method,
                            operation_id=operation_id,
                        )
                    )
                mapping_operation = (
                    str(mapping_item.get("operation") or "").strip().lower()
                )
                if normalized_operation and mapping_operation != normalized_operation:
                    violations.append(
                        _violation(
                            code="invalid_x_kernite_field",
                            message="mapping operation does not match x-kernite operation.",
                            field="mapping.operations[].operation",
                            path=path,
                            method=method,
                            operation_id=operation_id,
                        )
                    )

                mapping_mode = str(mapping_item.get("mode") or "").strip().lower()
                if mapping_mode and mapping_mode != mode:
                    violations.append(
                        _violation(
                            code="invalid_x_kernite_field",
                            message="mapping mode does not match x-kernite mode.",
                            field="mapping.operations[].mode",
                            path=path,
                            method=method,
                            operation_id=operation_id,
                        )
                    )

                expected_policy_key = policy_key
                mapping_policy_key = str(mapping_item.get("policy_key") or "").strip()
                if mode in {"enforce", "observe"} and expected_policy_key:
                    if mapping_policy_key != expected_policy_key:
                        violations.append(
                            _violation(
                                code="invalid_x_kernite_field",
                                message="mapping policy_key does not match x-kernite policy_key.",
                                field="mapping.operations[].policy_key",
                                path=path,
                                method=method,
                                operation_id=operation_id,
                            )
                        )

        if bundle is not None and governed and mode in {"enforce", "observe"}:
            resolved_policy_key = (
                policy_key
                or f"{slugify(object_type)}_{slugify(normalized_operation)}_guard"
            )
            if resolved_policy_key not in bundle_policy_keys:
                violations.append(
                    _violation(
                        code="bundle_missing_policy",
                        message="Referenced policy_key is missing from bundle.policies.",
                        field="bundle.policies",
                        path=path,
                        method=method,
                        operation_id=operation_id,
                    )
                )

    if not strict:
        retained: list[dict[str, str]] = []
        for violation in violations:
            if violation["code"] in _COVERAGE_VIOLATION_CODES:
                warnings.append(violation)
            else:
                retained.append(violation)
        violations = retained

    violations.sort(
        key=lambda item: (
            str(item.get("path") or ""),
            str(item.get("method") or ""),
            str(item.get("field") or ""),
            str(item.get("code") or ""),
        )
    )
    warnings.sort(
        key=lambda item: (
            str(item.get("path") or ""),
            str(item.get("method") or ""),
            str(item.get("field") or ""),
            str(item.get("code") or ""),
        )
    )

    return {
        "valid": len(violations) == 0,
        "summary": {
            "write_operations": len(operations),
            "violations": len(violations),
            "warnings": len(warnings),
            "strict": bool(strict),
        },
        "violations": violations,
        "warnings": warnings,
    }


def check_policy_response(payload: Any) -> tuple[int, dict[str, Any]]:
    if not isinstance(payload, Mapping):
        return 400, {
            "ctx_id": _ctx_id(),
            "message": "Invalid policy check payload.",
            "data": {
                "error": "Request body must be an object.",
            },
        }

    options = payload.get("options")
    if options is None:
        options = {}
    if not isinstance(options, Mapping):
        return 400, {
            "ctx_id": _ctx_id(),
            "message": "Invalid policy check payload.",
            "data": {
                "error": "options must be an object when provided.",
            },
        }

    strict = bool(options.get("strict", True))

    try:
        report = check_policy_coverage(
            payload.get("openapi"),
            mapping=payload.get("mapping"),
            bundle=payload.get("bundle"),
            strict=strict,
        )
    except (OpenApiValidationError, ValueError) as exc:
        return 400, {
            "ctx_id": _ctx_id(),
            "message": "Schema coverage check failed.",
            "data": {
                "valid": False,
                "summary": {
                    "write_operations": 0,
                    "violations": 1,
                    "warnings": 0,
                    "strict": strict,
                },
                "violations": [
                    {
                        "code": "unsupported_openapi_shape",
                        "message": str(exc),
                        "field": "openapi",
                    }
                ],
                "warnings": [],
            },
        }

    message = "Schema coverage check passed."
    if not report["valid"]:
        message = "Schema coverage check failed."

    return 200, {
        "ctx_id": _ctx_id(),
        "message": message,
        "data": report,
    }
