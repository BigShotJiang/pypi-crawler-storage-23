# replx

[![PyPI version](https://badge.fury.io/py/replx.svg)](https://badge.fury.io/py/replx)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

`replx` is a CLI tool for MicroPython development. It uses an agent-based architecture to manage multiple CLI sessions and multiple boards in a consistent workflow.

## What replx provides

- Shared connection management across terminal sessions
- Foreground and background board handling per session
- Workspace-level default device configuration
- File operations on device storage
- Script execution, REPL access, and utility commands

## Installation

```sh
pip install replx
```

## Command summary

### Connection and session

- `setup`: Initialize workspace settings and register a default device.
- `scan`: List available serial devices.
- `status`: Show session and connection state.
- `fg`: Change the foreground device for the current session.
- `whoami`: Show the current foreground device.
- `disconnect`: Close a device connection.
- `shutdown`: Stop the agent and clear active sessions.

### Execution and interaction

- `exec` (`-c`): Execute inline Python code on the device.
- `run`: Run a local or device-side script.
- `repl`: Open an interactive REPL session.
- `shell`: Open a device file-system shell.

### File operations

- `ls`: List files and directories.
- `cat`: Print file content.
- `get`: Download files from device to local.
- `put`: Upload files from local to device.
- `cp`: Copy files or directories on device.
- `mv`: Move or rename files or directories on device.
- `rm`: Remove files or directories on device.
- `mkdir`: Create directories on device.
- `touch`: Create an empty file or update timestamps.

### Device management

- `usage`: Show device storage usage.
- `reset`: Perform a soft reset.
- `format`: Format the device file system.
- `init`: Run initialization scripts on device.
- `wifi`: Manage Wi-Fi configuration and status.
- `firmware`: Check, download, or update firmware.

### Package and build

- `pkg`: Search, download, and update packages.
- `mpy`: Compile `.py` files to `.mpy`.

## Notes

- `scan`, `status`, `whoami`, and `shutdown` are special commands and do not accept `--port`.
- Most device commands can omit the port when a foreground or workspace default device is available.

## License

MIT
