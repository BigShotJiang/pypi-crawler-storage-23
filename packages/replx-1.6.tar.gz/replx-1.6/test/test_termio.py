from termio import ReplSerial
from utools import rand, clamp, intervalChecker
import time


def new_token() -> str:
    return f"{rand(4):08x}"   # 예: "a3f2c1b4"


with ReplSerial(timeout=0) as ser:
    token        = new_token()
    authed       = False
    every_sess   = intervalChecker(1000)   # 미인증: 1초마다 SESSION 재전송
    heartbeat    = intervalChecker(5000)   # 인증 후: 5초마다 ALIVE

    # 최초 토큰 전송
    ser.write(f"SESSION={token}\r\n".encode())

    while True:
        # timeout=0이므로 \r\n이 두 pump 사이클에 걸려 도착할 수 있음 → b"\n" 사용
        line = ser.read_until(b"\n", max_size=64)
        if line and line.endswith(b"\n"):
            cmd = line.decode("utf-8", "replace").strip()

            # 인증 (항상 허용)
            if cmd.startswith("AUTH "):
                if cmd[5:] == token:
                    authed = True
                    ser.write(b"OK authenticated\r\n")
                else:
                    authed = False
                    ser.write(b"ERR wrong token\r\n")

            # 미인증 요청 거부
            elif not authed:
                ser.write(b"ERR not authenticated\r\n")

            # 인증 후 커맨드
            elif cmd.startswith("SET_PWM:"):
                try:
                    duty = clamp(int(cmd[8:]), 0, 100)
                    # pwm.duty(int(duty * 655.35))  # 0–100% → 0–65535
                    ser.write(f"OK pwm={duty}%\r\n".encode())
                except (ValueError, TypeError):
                    ser.write(b"ERR bad value\r\n")

            elif cmd.startswith("SET_FREQ:"):
                try:
                    freq = clamp(int(cmd[9:]), 1, 20_000)
                    # pwm.freq(freq)
                    ser.write(f"OK freq={freq}Hz\r\n".encode())
                except (ValueError, TypeError):
                    ser.write(b"ERR bad value\r\n")

            elif cmd == "RESET_SESSION":
                token  = new_token()
                authed = False
                every_sess = intervalChecker(1000)
                ser.write(f"SESSION={token}\r\n".encode())

            else:
                ser.write(b"ERR unknown cmd\r\n")

        # 주기적 전송 (커맨드 수신 여부와 무관)
        if not authed and every_sess():
            ser.write(f"SESSION={token}\r\n".encode())
        elif authed and heartbeat():
            ser.write(b"ALIVE\r\n")

        time.sleep_ms(10)