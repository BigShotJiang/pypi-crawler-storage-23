"""
Phase 1 regression test: 2-tier ThreadPoolExecutor

Verifies that:
1. AgentServer starts with two ThreadPoolExecutors (fast / slow).
2. _FAST_COMMANDS routing is correct.
3. Server responds to ping/status/session_info via UDP without errors.
4. Concurrent bursts of fast commands complete without thread-creation stalls.
5. Server shuts down cleanly and executors are stopped.
"""

import socket
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor

from replx.cli.agent.server.core import AgentServer, _FAST_COMMANDS, _LOOP_COMMANDS, _FAST_POOL_WORKERS, _SLOW_POOL_WORKERS
from replx.cli.agent.protocol import AgentProtocol

# Use a fixed port well away from the default to avoid conflicts
_TEST_PORT = 18799


def _send_and_recv(sock: socket.socket, msg: dict, timeout: float = 3.0) -> dict | None:
    """Send one request and collect the (non-ack) response."""
    data = AgentProtocol.encode_message(msg)
    sock.sendto(data, ('127.0.0.1', _TEST_PORT))
    sock.settimeout(timeout)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            raw, _ = sock.recvfrom(65535)
        except socket.timeout:
            return None
        resp = AgentProtocol.decode_message(raw)
        if resp and resp.get('seq') == msg['seq'] and resp.get('type') == 'response':
            return resp
    return None


def _ping(seq: int = 1) -> dict:
    return AgentProtocol.create_request('ping', seq=seq)


def _make_server() -> AgentServer:
    return AgentServer(port=_TEST_PORT)


class TestPhase1ThreadPool(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.server = _make_server()
        cls._srv_thread = threading.Thread(target=cls.server.start, daemon=True)
        cls._srv_thread.start()
        # Wait until server socket is bound
        for _ in range(50):
            time.sleep(0.05)
            if cls.server.running:
                break

    @classmethod
    def tearDownClass(cls):
        cls.server.cleanup()
        cls._srv_thread.join(timeout=3)

    # ------------------------------------------------------------------
    # 1. Structural checks
    # ------------------------------------------------------------------

    def test_executors_are_thread_pool_executors(self):
        """__init__ must create two ThreadPoolExecutor instances."""
        self.assertIsInstance(self.server._fast_executor, ThreadPoolExecutor)
        self.assertIsInstance(self.server._slow_executor, ThreadPoolExecutor)

    def test_fast_pool_worker_count(self):
        """Fast pool is configured with _FAST_POOL_WORKERS workers."""
        self.assertEqual(self.server._fast_executor._max_workers, _FAST_POOL_WORKERS)

    def test_slow_pool_worker_count(self):
        """Slow pool is configured with _SLOW_POOL_WORKERS workers."""
        self.assertEqual(self.server._slow_executor._max_workers, _SLOW_POOL_WORKERS)

    # ------------------------------------------------------------------
    # 2. _FAST_COMMANDS routing
    # ------------------------------------------------------------------

    def test_fast_commands_set_contains_repl_read(self):
        """repl_read stays in the fast executor pool (buffer_lock held by reader)."""
        self.assertIn('repl_read', _FAST_COMMANDS)

    def test_loop_commands_contain_ping(self):
        """ping is handled directly on the event loop (Phase 3)."""
        self.assertIn('ping', _LOOP_COMMANDS)

    def test_loop_commands_contain_status(self):
        """status is handled directly on the event loop (Phase 3)."""
        self.assertIn('status', _LOOP_COMMANDS)

    def test_loop_commands_contain_session_info(self):
        """session_info is handled directly on the event loop (Phase 3)."""
        self.assertIn('session_info', _LOOP_COMMANDS)

    def test_loop_commands_not_in_fast_commands(self):
        """Commands dispatched on the event loop must NOT be in _FAST_COMMANDS."""
        for cmd in _LOOP_COMMANDS:
            with self.subTest(cmd=cmd):
                self.assertNotIn(cmd, _FAST_COMMANDS)

    def test_slow_commands_not_in_fast_set(self):
        """Commands with serial I/O must NOT appear in _FAST_COMMANDS."""
        for cmd in ('exec', 'run', 'ls', 'put_file', 'get_file', 'repl_write',
                    'repl_enter', 'format', 'mkdir', 'rm'):
            with self.subTest(cmd=cmd):
                self.assertNotIn(cmd, _FAST_COMMANDS)

    # ------------------------------------------------------------------
    # 3. Functional UDP responses
    # ------------------------------------------------------------------

    def _sock(self) -> socket.socket:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(3.0)
        return s

    def test_ping_returns_pong(self):
        with self._sock() as s:
            req = AgentProtocol.create_request('ping', seq=100)
            resp = _send_and_recv(s, req)
        self.assertIsNotNone(resp, "No response to ping")
        self.assertTrue(resp['result'].get('pong'))

    def test_status_returns_dict(self):
        with self._sock() as s:
            req = AgentProtocol.create_request('status', seq=101)
            resp = _send_and_recv(s, req)
        self.assertIsNotNone(resp, "No response to status")
        self.assertIn('connected', resp['result'])

    def test_session_info_returns_dict(self):
        with self._sock() as s:
            req = AgentProtocol.create_request('session_info', seq=102)
            resp = _send_and_recv(s, req)
        self.assertIsNotNone(resp, "No response to session_info")
        self.assertIn('sessions', resp['result'])

    # ------------------------------------------------------------------
    # 4. Concurrent burst: fast pool must not stall
    # ------------------------------------------------------------------

    def test_concurrent_pings_complete_quickly(self):
        """100 concurrent pings must all complete within 2 s total.

        With the old Thread-per-request approach, creating 100 OS threads on
        Windows takes ~100–200 ms.  With the pool, all 100 requests should
        be dispatched in < 10 ms and complete well under 2 s.
        """
        N = 100
        results: list[dict | None] = [None] * N
        errors: list[str] = []

        def send_one(idx: int):
            try:
                with self._sock() as s:
                    req = AgentProtocol.create_request('ping', seq=200 + idx)
                    results[idx] = _send_and_recv(s, req, timeout=2.0)
            except Exception as e:
                errors.append(str(e))

        t0 = time.monotonic()
        threads = [threading.Thread(target=send_one, args=(i,)) for i in range(N)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)
        elapsed = time.monotonic() - t0

        self.assertEqual(errors, [], f"Errors during burst: {errors}")
        successes = sum(1 for r in results if r and r.get('result', {}).get('pong'))
        self.assertGreaterEqual(successes, N * 0.95,
                                f"Only {successes}/{N} pings succeeded")
        self.assertLess(elapsed, 3.0,
                        f"Burst took {elapsed:.2f}s — expected < 3 s")

    # ------------------------------------------------------------------
    # 5. Duplicate-sequence deduplication still works
    # ------------------------------------------------------------------

    def test_duplicate_seq_suppressed(self):
        """Sending the exact same seq twice should yield only one response."""
        with self._sock() as s:
            req = AgentProtocol.create_request('ping', seq=999)
            raw = AgentProtocol.encode_message(req)
            s.sendto(raw, ('127.0.0.1', _TEST_PORT))
            s.sendto(raw, ('127.0.0.1', _TEST_PORT))  # duplicate

            responses = []
            s.settimeout(0.5)
            deadline = time.monotonic() + 1.0
            while time.monotonic() < deadline:
                try:
                    data, _ = s.recvfrom(65535)
                    msg = AgentProtocol.decode_message(data)
                    if msg and msg.get('seq') == 999 and msg.get('type') == 'response':
                        responses.append(msg)
                except socket.timeout:
                    break

        # Exactly one response (ACK packets are filtered by type check above)
        self.assertEqual(len(responses), 1,
                         f"Expected 1 response, got {len(responses)}")


if __name__ == '__main__':
    unittest.main()
