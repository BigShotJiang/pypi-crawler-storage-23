import unittest
from unittest.mock import patch


class TestPkgSearchScopeFilter(unittest.TestCase):
    @patch("replx.cli.commands.package.OutputHelper.print_panel")
    @patch("replx.cli.commands.package._find_local_pkg_version", return_value=(0.0, True))
    @patch("replx.cli.commands.package.RegistryHelper.get_version", return_value=1.0)
    @patch("replx.cli.commands.package.RegistryHelper.walk_files_for_device")
    @patch("replx.cli.commands.package.RegistryHelper.walk_files_for_core")
    @patch("replx.cli.commands.package.RegistryHelper.root_sections")
    @patch("replx.cli.commands.package.StoreManager.load_local_meta", return_value={})
    @patch("replx.cli.commands.package.StoreManager.load_remote_meta", return_value={})
    @patch("replx.cli.commands.package._ensure_connected")
    def test_no_core_match_does_not_fallback_to_all(
        self,
        mock_ensure_connected,
        _mock_load_remote,
        _mock_load_local,
        mock_root_sections,
        mock_walk_core,
        mock_walk_device,
        _mock_get_version,
        _mock_find_local_ver,
        mock_print_panel,
    ):
        from replx.cli.commands.package import _pkg_search

        mock_ensure_connected.return_value = {
            "connected": True,
            "core": "ESP32P4C6",
            "device": "ESP32P4",
        }
        mock_root_sections.return_value = ({"RP2350", "ESP32S3"}, {"ticle_lite"})
        mock_walk_core.return_value = [("foo.py", {"source": "core/_std/src/foo.py"})]
        mock_walk_device.return_value = [("bar.py", {"source": "device/_ticle/src/bar.py"})]

        _pkg_search([], owner="PlanXLab", repo="replx_libs", ref="main")

        mock_walk_core.assert_not_called()
        mock_walk_device.assert_not_called()
        args, _kwargs = mock_print_panel.call_args
        self.assertIn("No results found.", args[0])

    @patch("replx.cli.commands.package.OutputHelper.print_panel")
    @patch("replx.cli.commands.package._find_local_pkg_version", return_value=(0.0, True))
    @patch("replx.cli.commands.package.RegistryHelper.get_version", return_value=1.0)
    @patch("replx.cli.commands.package.RegistryHelper.walk_files_for_device", return_value=[])
    @patch("replx.cli.commands.package.RegistryHelper.walk_files_for_core", return_value=[])
    @patch("replx.cli.commands.package.RegistryHelper.root_sections")
    @patch("replx.cli.commands.package.StoreManager.load_local_meta", return_value={})
    @patch("replx.cli.commands.package.StoreManager.load_remote_meta", return_value={})
    @patch("replx.cli.commands.package._ensure_connected")
    def test_explicit_other_core_query_returns_no_results(
        self,
        mock_ensure_connected,
        _mock_load_remote,
        _mock_load_local,
        mock_root_sections,
        _mock_walk_core,
        _mock_walk_device,
        _mock_get_version,
        _mock_find_local_ver,
        mock_print_panel,
    ):
        from replx.cli.commands.package import _pkg_search

        mock_ensure_connected.return_value = {
            "connected": True,
            "core": "RP2350",
            "device": "ticle-lite",
        }
        mock_root_sections.return_value = ({"RP2350", "ESP32S3"}, {"ticle_lite"})

        _pkg_search(["ESP32S3"], owner="PlanXLab", repo="replx_libs", ref="main")

        args, _kwargs = mock_print_panel.call_args
        self.assertIn("No results found.", args[0])


if __name__ == "__main__":
    unittest.main()
