"""
Phase 4 regression test: asyncio REPL reader task

Verifies that:
1. ReplSessionState has reader_future attribute (replaces daemon reader_thread).
2. ReplSessionState.stop() cancels reader_future when set.
3. _repl_reader_task is a coroutine function.
4. _repl_reader_task reads data from transport and buffers it correctly.
5. _repl_reader_task stops cleanly when conn.repl.active is set to False.
6. _repl_reader_task handles CancelledError gracefully (no exception propagation).
7. _repl_reader_task handles 20 consecutive TransportErrors then stops.
8. _cmd_repl_enter falls back to daemon thread when no event loop is present.
9. With an event loop available, _cmd_repl_enter creates reader_future not reader_thread.
"""

import asyncio
import inspect
import threading
import time
import unittest
from concurrent.futures import Future as ConcurrentFuture
from unittest.mock import MagicMock, patch, AsyncMock

from replx.cli.agent.server.connection_manager import ReplSessionState
from replx.cli.agent.server.handlers.repl import ReplCommandsMixin
from replx.utils.exceptions import TransportError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _run_coro(coro):
    """Run a coroutine synchronously (for testing without full event loop)."""
    return asyncio.run(coro)


def _make_repl_state() -> ReplSessionState:
    return ReplSessionState()


def _make_mock_conn(in_waiting_seq=None, read_bytes_seq=None):
    """Build a mock BoardConnection whose repl_protocol uses provided sequences."""
    conn = MagicMock()
    conn.repl = ReplSessionState()
    repl_proto = MagicMock()

    if in_waiting_seq is not None:
        repl_proto.in_waiting.side_effect = in_waiting_seq
    else:
        repl_proto.in_waiting.return_value = 0

    if read_bytes_seq is not None:
        repl_proto.read_bytes.side_effect = read_bytes_seq
    else:
        repl_proto.read_bytes.return_value = b""

    conn.repl_protocol = repl_proto
    return conn


# ---------------------------------------------------------------------------
# Suite 1 – ReplSessionState structural checks
# ---------------------------------------------------------------------------

class TestReplSessionState(unittest.TestCase):

    def test_reader_future_attribute_exists(self):
        """ReplSessionState must have a reader_future attribute."""
        state = _make_repl_state()
        self.assertTrue(hasattr(state, 'reader_future'))

    def test_reader_future_defaults_to_none(self):
        state = _make_repl_state()
        self.assertIsNone(state.reader_future)

    def test_reader_thread_attribute_still_exists(self):
        """Legacy reader_thread must be kept for fallback."""
        state = _make_repl_state()
        self.assertTrue(hasattr(state, 'reader_thread'))

    def test_stop_cancels_reader_future(self):
        """stop() must cancel reader_future if it is set."""
        state = _make_repl_state()
        mock_future = MagicMock(spec=ConcurrentFuture)
        state.reader_future = mock_future

        state.stop()

        mock_future.cancel.assert_called_once()
        self.assertIsNone(state.reader_future)

    def test_stop_clears_buffer(self):
        state = _make_repl_state()
        state.start(ppid=1234)
        state.append_output(b"hello")
        state.stop()
        self.assertEqual(state.read_output(), b"")

    def test_stop_joins_reader_thread_if_present(self):
        """Legacy: stop() must still join reader_thread if present."""
        state = _make_repl_state()
        mock_thread = MagicMock(spec=threading.Thread)
        mock_thread.is_alive.return_value = True
        state.reader_thread = mock_thread
        state.stop()
        mock_thread.join.assert_called_once()
        self.assertIsNone(state.reader_thread)


# ---------------------------------------------------------------------------
# Suite 2 – _repl_reader_task coroutine behaviour
# ---------------------------------------------------------------------------

class _MixinStub(ReplCommandsMixin):
    """Minimal stub so we can call mixin methods directly."""
    def __init__(self, slow_executor):
        self._slow_executor = slow_executor
        self._loop = None  # will be set per test


class TestReplReaderTask(unittest.TestCase):

    def test_repl_reader_task_is_coroutine_function(self):
        """_repl_reader_task must be an async (coroutine) function."""
        self.assertTrue(inspect.iscoroutinefunction(ReplCommandsMixin._repl_reader_task))

    def test_task_stops_when_active_false(self):
        """Task must terminate gracefully when conn.repl.active becomes False."""
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=2) as executor:
            mixin = _MixinStub(slow_executor=executor)
            conn = _make_mock_conn()
            conn.repl.start(ppid=1)

            # Set active=False immediately so the task loop condition fails
            conn.repl.active = False

            _run_coro(mixin._repl_reader_task(conn))
            # No exception means graceful stop - pass

    def test_task_reads_and_buffers_data(self):
        """Task must call read_bytes and append result to output_buffer."""
        from concurrent.futures import ThreadPoolExecutor

        data_chunk = b"hello world"
        hit_count = [0]

        def in_waiting_fn():
            hit_count[0] += 1
            if hit_count[0] == 1:
                return len(data_chunk)
            return 0  # second iteration: no data, loop ends via active=False

        stop_after_buffer = threading.Event()

        def read_bytes_fn(n):
            return data_chunk

        with ThreadPoolExecutor(max_workers=4) as executor:
            mixin = _MixinStub(slow_executor=executor)
            conn = _make_mock_conn(
                in_waiting_seq=[len(data_chunk), 0],
                read_bytes_seq=[data_chunk],
            )
            conn.repl.start(ppid=1)

            async def run_task():
                task = asyncio.create_task(mixin._repl_reader_task(conn))
                # Give the task time to read one chunk, then stop it
                await asyncio.sleep(0.05)
                conn.repl.active = False
                await asyncio.sleep(0.02)
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

            asyncio.run(run_task())
            buffered = conn.repl.read_output()
            self.assertEqual(buffered, data_chunk)

    def test_task_handles_cancelled_error_gracefully(self):
        """CancelledError from task.cancel() must not propagate."""
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=2) as executor:
            mixin = _MixinStub(slow_executor=executor)
            conn = _make_mock_conn()
            conn.repl.start(ppid=1)

            async def run_task():
                task = asyncio.create_task(mixin._repl_reader_task(conn))
                await asyncio.sleep(0.03)
                conn.repl.active = False
                task.cancel()
                # Should not raise
                try:
                    await task
                except asyncio.CancelledError:
                    pass  # cancellation of result is acceptable

            asyncio.run(run_task())
            # If we get here without an unhandled exception, the test passes.

    def test_task_stops_after_20_consecutive_transport_errors(self):
        """20 consecutive TransportErrors must stop the task."""
        from concurrent.futures import ThreadPoolExecutor

        call_count = [0]

        def in_waiting_raises():
            call_count[0] += 1
            raise TransportError("simulated")

        with ThreadPoolExecutor(max_workers=4) as executor:
            mixin = _MixinStub(slow_executor=executor)
            conn = MagicMock()
            conn.repl = ReplSessionState()
            conn.repl.start(ppid=1)
            proto = MagicMock()
            proto.in_waiting.side_effect = in_waiting_raises
            conn.repl_protocol = proto

            _run_coro(mixin._repl_reader_task(conn))
            # Task exited without exception — 20+ errors triggered stop
            self.assertGreaterEqual(call_count[0], 20)


# ---------------------------------------------------------------------------
# Suite 3 – _cmd_repl_enter integration (mocked board)
# ---------------------------------------------------------------------------

class TestReplEnterFallback(unittest.TestCase):
    """Verifies the fallback (thread) path when _loop is None."""

    def test_fallback_creates_daemon_thread_when_no_loop(self):
        """With _loop=None, _cmd_repl_enter must create a reader_thread."""
        from concurrent.futures import ThreadPoolExecutor

        with ThreadPoolExecutor(max_workers=2) as executor:
            mixin = _MixinStub(slow_executor=executor)
            mixin._loop = None  # no asyncio loop

            conn = MagicMock()
            conn.repl = ReplSessionState()
            proto = MagicMock()
            proto._in_raw_repl = False
            proto.exit_paste_mode = MagicMock()
            proto.interrupt = MagicMock()
            proto.in_waiting.return_value = 0
            proto.send_raw = MagicMock()
            # Simulate getting a >>> prompt response
            proto.read_bytes.return_value = b">>> "
            conn.repl_protocol = proto
            conn.port = 'COM_TEST'

            ctx = MagicMock()
            ctx.connection = conn
            ctx.ppid = 42

            with patch.object(mixin, '_repl_reader_loop'):
                result = mixin._cmd_repl_enter(ctx)
                # Whether entered or not, if prompted, reader_thread should be set
                if result.get('entered'):
                    self.assertIsNotNone(conn.repl.reader_thread)
                    self.assertIsNone(conn.repl.reader_future)


class TestReplEnterWithLoop(unittest.TestCase):
    """Verifies the asyncio-task path when _loop is set."""

    def test_asyncio_task_path_creates_reader_future(self):
        """With a running event loop, _cmd_repl_enter must set reader_future."""
        from concurrent.futures import ThreadPoolExecutor

        async def run():
            with ThreadPoolExecutor(max_workers=4) as executor:
                mixin = _MixinStub(slow_executor=executor)
                loop = asyncio.get_running_loop()
                mixin._loop = loop

                conn = MagicMock()
                conn.repl = ReplSessionState()
                proto = MagicMock()
                proto._in_raw_repl = False
                proto.exit_paste_mode = MagicMock()
                proto.interrupt = MagicMock()
                proto.in_waiting.return_value = 0
                proto.send_raw = MagicMock()
                proto.read_bytes.return_value = b">>> "
                conn.repl_protocol = proto
                conn.port = 'COM_TEST'

                ctx = MagicMock()
                ctx.connection = conn
                ctx.ppid = 99

                result = mixin._cmd_repl_enter(ctx)
                await asyncio.sleep(0.05)  # let task start

                if result.get('entered'):
                    self.assertIsNotNone(conn.repl.reader_future)
                    self.assertIsNone(conn.repl.reader_thread)
                    # Clean up
                    conn.repl.stop()
                    await asyncio.sleep(0.05)

        asyncio.run(run())


if __name__ == '__main__':
    unittest.main(verbosity=2)
