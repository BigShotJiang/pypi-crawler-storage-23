import unittest

from replx.cli.agent.server.command_dispatcher import CommandContext
from replx.cli.agent.server.handlers.session import SessionCommandsMixin
from replx.cli.agent.server.session_manager import SessionManager


class _StubConnectionManager:
    def __init__(self):
        self.disconnected_ports = []

    def disconnect(self, port: str) -> bool:
        self.disconnected_ports.append(port)
        return True


class _StubServer(SessionCommandsMixin):
    def __init__(self):
        self.session_manager = SessionManager()
        self.connection_manager = _StubConnectionManager()
        self.running = True
        self.server_socket = None

    def _get_session(self, ppid: int):
        return self.session_manager.get_session(ppid)


class TestSessionDisconnectReleasesSharedPort(unittest.TestCase):
    def test_disconnect_closes_port_even_if_shared_by_other_sessions(self):
        server = _StubServer()
        server.session_manager.add_connection_to_session(1001, "COM2", as_foreground=True)
        server.session_manager.add_connection_to_session(1002, "COM2", as_foreground=True)

        ctx = CommandContext(ppid=1001)
        result = server._cmd_session_disconnect(ctx, port="COM2")

        self.assertEqual(result.get("freed_port", "").lower(), "com2")
        self.assertEqual(len(server.connection_manager.disconnected_ports), 1)
        self.assertEqual(server.connection_manager.disconnected_ports[0].lower(), "com2")

        sessions = server.session_manager.get_all_sessions()
        for session in sessions.values():
            self.assertFalse(session.has_connection("COM2"))


if __name__ == "__main__":
    unittest.main()
