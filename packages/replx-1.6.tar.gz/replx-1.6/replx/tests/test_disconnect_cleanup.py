import unittest

from replx.cli.agent.server.connection_manager import BoardConnection, ConnectionManager


class _DummyTransport:
    def __init__(self):
        self.closed = False

    def write(self, data: bytes):
        pass

    def close(self):
        self.closed = True


class _DummyProtocol:
    """Mirrors ReplProtocol: transport is a public attribute (no leading underscore)."""
    def __init__(self, transport):
        self.transport = transport


class _DummyState:
    def __init__(self, active: bool):
        self.active = active
        self.stopped = False

    def stop(self):
        self.stopped = True
        self.active = False


class TestDisconnectCleansUpTransport(unittest.TestCase):
    def test_disconnect_stops_active_workers_and_closes_transport(self):
        manager = ConnectionManager()

        transport = _DummyTransport()
        protocol = _DummyProtocol(transport)

        connection = BoardConnection(port="COM4", repl_protocol=protocol)
        connection.repl = _DummyState(active=True)
        connection.interactive = _DummyState(active=True)

        manager.add_connection("COM4", connection)

        disconnected = manager.disconnect("com4")

        self.assertTrue(disconnected)
        self.assertTrue(connection.repl.stopped)
        self.assertTrue(connection.interactive.stopped)
        self.assertTrue(transport.closed, "transport.close() must be called to release the COM port")
        self.assertIsNone(connection.repl_protocol)
        self.assertIsNone(manager.get_connection("COM4"))


if __name__ == "__main__":
    unittest.main()
