"""
Phase 2 regression test: asyncio DatagramProtocol + heartbeat coroutine

Verifies that:
1. _AgentDatagramProtocol is a proper asyncio.DatagramProtocol subclass.
2. __init__ sets Phase-2 attributes to their initial sentinel values and
   does NOT create a _heartbeat_thread.
3. After start():
   - _loop is a running asyncio event loop.
   - _stop_event is an asyncio.Event.
   - _datagram_transport is set (not None).
   - No daemon thread named 'replx-heartbeat*' exists (it's a Task, not a Thread).
4. Server still responds correctly to ping / status / session_info.
5. cleanup() called from a foreign thread signals the loop correctly and
   the server shuts down cleanly.
6. After shutdown:
   - _loop is None (reset in start() finally block).
   - _cleaned_up is True.
   - Server thread terminates within a reasonable timeout.
7. Idempotent cleanup: a second cleanup() call does not raise.
"""

import asyncio
import socket
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor

from replx.cli.agent.server.core import (
    AgentServer,
    _AgentDatagramProtocol,
)
from replx.cli.agent.protocol import AgentProtocol

# Port distinct from Phase 1 (18799) to allow both suites to run concurrently.
_TEST_PORT = 18800
_ADDR = ('127.0.0.1', _TEST_PORT)
_TIMEOUT = 4.0  # per-request timeout (generous for slow CI machines)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_server() -> AgentServer:
    return AgentServer(port=_TEST_PORT)


def _send_recv(sock: socket.socket, msg: dict, timeout: float = _TIMEOUT) -> dict | None:
    """Send one request dict and return the first matching response."""
    data = AgentProtocol.encode_message(msg)
    sock.sendto(data, _ADDR)
    sock.settimeout(timeout)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            raw, _ = sock.recvfrom(65535)
        except socket.timeout:
            return None
        resp = AgentProtocol.decode_message(raw)
        if resp and resp.get('seq') == msg['seq'] and resp.get('type') == 'response':
            return resp
    return None


def _wait_ready(server: AgentServer, timeout: float = 3.0) -> bool:
    """Block until server.running is True or timeout expires."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if server.running:
            return True
        time.sleep(0.02)
    return False


# ---------------------------------------------------------------------------
# Suite 1 – Pure structural / class-level checks (no server started)
# ---------------------------------------------------------------------------

class TestPhase2Structure(unittest.TestCase):
    """Tests that do not require a running server."""

    def test_datagram_protocol_is_asyncio_subclass(self):
        """_AgentDatagramProtocol must inherit asyncio.DatagramProtocol."""
        self.assertTrue(issubclass(_AgentDatagramProtocol, asyncio.DatagramProtocol))

    def test_datagram_protocol_has_connection_made(self):
        self.assertTrue(callable(getattr(_AgentDatagramProtocol, 'connection_made', None)))

    def test_datagram_protocol_has_datagram_received(self):
        self.assertTrue(callable(getattr(_AgentDatagramProtocol, 'datagram_received', None)))

    def test_datagram_protocol_has_error_received(self):
        self.assertTrue(callable(getattr(_AgentDatagramProtocol, 'error_received', None)))

    # ------------------------------------------------------------------
    # Initial attribute values
    # ------------------------------------------------------------------

    def setUp(self):
        self.server = _make_server()

    def tearDown(self):
        # Ensure executors are released even if test fails before cleanup()
        try:
            self.server._fast_executor.shutdown(wait=False, cancel_futures=True)
            self.server._slow_executor.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass

    def test_loop_initially_none(self):
        self.assertIsNone(self.server._loop)

    def test_stop_event_initially_none(self):
        self.assertIsNone(self.server._stop_event)

    def test_datagram_transport_initially_none(self):
        self.assertIsNone(self.server._datagram_transport)

    def test_cleaned_up_initially_false(self):
        self.assertFalse(self.server._cleaned_up)

    def test_no_heartbeat_thread_attribute(self):
        """_heartbeat_thread was removed in Phase 2; replaced by an asyncio Task."""
        self.assertFalse(
            hasattr(self.server, '_heartbeat_thread'),
            "_heartbeat_thread attribute must not exist on the server",
        )


# ---------------------------------------------------------------------------
# Suite 2 – Integration tests (server runs in background thread)
# ---------------------------------------------------------------------------

class TestPhase2Integration(unittest.TestCase):
    """Tests that start a real AgentServer and communicate over UDP."""

    @classmethod
    def setUpClass(cls):
        cls.server = _make_server()
        cls._srv_thread = threading.Thread(
            target=cls.server.start,
            name='test-agent-server',
            daemon=True,
        )
        cls._srv_thread.start()
        ready = _wait_ready(cls.server, timeout=5.0)
        if not ready:
            raise RuntimeError("AgentServer did not become ready within 5 s")

    @classmethod
    def tearDownClass(cls):
        cls.server.cleanup()
        cls._srv_thread.join(timeout=5.0)

    def _sock(self) -> socket.socket:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(_TIMEOUT)
        return s

    # ------------------------------------------------------------------
    # A. Asyncio infrastructure – verified after start()
    # ------------------------------------------------------------------

    def test_loop_is_event_loop_while_running(self):
        """_loop must be an AbstractEventLoop instance while server is running."""
        self.assertIsInstance(self.server._loop, asyncio.AbstractEventLoop)

    def test_loop_is_running(self):
        """The loop must be running (not closed) while the server is active."""
        self.assertTrue(self.server._loop.is_running())

    def test_stop_event_is_asyncio_event(self):
        """_stop_event must be an asyncio.Event (not threading.Event)."""
        self.assertIsInstance(self.server._stop_event, asyncio.Event)

    def test_datagram_transport_set_after_start(self):
        """_datagram_transport must be set after start()."""
        self.assertIsNotNone(self.server._datagram_transport)

    def test_datagram_transport_is_asyncio_transport(self):
        self.assertIsInstance(
            self.server._datagram_transport,
            asyncio.DatagramTransport,
        )

    def test_no_heartbeat_daemon_thread(self):
        """Heartbeat must run as an asyncio Task, not a daemon Thread."""
        for t in threading.enumerate():
            if 'heartbeat' in t.name.lower():
                self.fail(
                    f"Found unexpected heartbeat daemon thread: {t.name!r}"
                )

    def test_server_socket_set_via_connection_made(self):
        """_AgentDatagramProtocol.connection_made() must populate server_socket."""
        self.assertIsNotNone(self.server.server_socket)

    def test_cleaned_up_false_while_running(self):
        self.assertFalse(self.server._cleaned_up)

    # ------------------------------------------------------------------
    # B. Functional – server still answers fast commands via new path
    # ------------------------------------------------------------------

    def test_ping_returns_pong(self):
        with self._sock() as s:
            req = AgentProtocol.create_request('ping', seq=200)
            resp = _send_recv(s, req)
        self.assertIsNotNone(resp, "No response to ping")
        self.assertTrue(resp['result'].get('pong'))

    def test_status_returns_dict(self):
        with self._sock() as s:
            req = AgentProtocol.create_request('status', seq=201)
            resp = _send_recv(s, req)
        self.assertIsNotNone(resp, "No response to status")
        self.assertIn('connected', resp['result'])

    def test_session_info_returns_dict(self):
        with self._sock() as s:
            req = AgentProtocol.create_request('session_info', seq=202)
            resp = _send_recv(s, req)
        self.assertIsNotNone(resp, "No response to session_info")
        self.assertIn('sessions', resp['result'])

    def test_status_returns_running_info(self):
        """status is a _FAST_COMMAND and must always respond even without a board."""
        with self._sock() as s:
            req = AgentProtocol.create_request('status', seq=204)
            resp = _send_recv(s, req)
        self.assertIsNotNone(resp, "No response to second status call")
        self.assertIn('connected', resp['result'])


# ---------------------------------------------------------------------------
# Suite 3 – Shutdown and idempotence (isolated server instance)
# ---------------------------------------------------------------------------

class TestPhase2Shutdown(unittest.TestCase):
    """Verify that cleanup() from a foreign thread shuts the server down cleanly."""

    def _start_server(self, port: int) -> tuple[AgentServer, threading.Thread]:
        server = AgentServer(port=port)
        thread = threading.Thread(
            target=server.start,
            name=f'test-shutdown-server-{port}',
            daemon=True,
        )
        thread.start()
        ready = _wait_ready(server, timeout=5.0)
        self.assertTrue(ready, f"Server on port {port} did not become ready")
        return server, thread

    def test_cleanup_from_foreign_thread_stops_server(self):
        """cleanup() called from the test (non-loop) thread must stop the server."""
        server, thread = self._start_server(port=18801)

        # Verify loop is running before cleanup
        self.assertIsNotNone(server._loop)
        self.assertTrue(server._loop.is_running())

        # Call cleanup from this thread (foreign to the event loop)
        server.cleanup()
        thread.join(timeout=5.0)

        self.assertFalse(thread.is_alive(), "Server thread did not terminate after cleanup()")

    def test_cleaned_up_true_after_shutdown(self):
        server, thread = self._start_server(port=18802)
        server.cleanup()
        thread.join(timeout=5.0)
        self.assertTrue(server._cleaned_up)

    def test_running_false_after_shutdown(self):
        server, thread = self._start_server(port=18803)
        server.cleanup()
        thread.join(timeout=5.0)
        self.assertFalse(server.running)

    def test_loop_none_after_shutdown(self):
        """start() finally block must reset _loop to None."""
        server, thread = self._start_server(port=18804)
        server.cleanup()
        thread.join(timeout=5.0)
        self.assertIsNone(server._loop)

    def test_stop_event_none_after_shutdown(self):
        """start() finally block must reset _stop_event to None."""
        server, thread = self._start_server(port=18805)
        server.cleanup()
        thread.join(timeout=5.0)
        self.assertIsNone(server._stop_event)

    def test_idempotent_cleanup(self):
        """A second cleanup() call must not raise any exception."""
        server, thread = self._start_server(port=18806)
        server.cleanup()
        thread.join(timeout=5.0)
        try:
            server.cleanup()  # second call — must be a no-op
        except Exception as exc:
            self.fail(f"Second cleanup() raised: {exc!r}")

    def test_cleanup_before_start_does_not_raise(self):
        """cleanup() on a never-started server must not raise."""
        server = AgentServer(port=18807)
        try:
            server.cleanup()
        except Exception as exc:
            self.fail(f"cleanup() on un-started server raised: {exc!r}")
        finally:
            server._fast_executor.shutdown(wait=False, cancel_futures=True)
            server._slow_executor.shutdown(wait=False, cancel_futures=True)


if __name__ == '__main__':
    unittest.main(verbosity=2)
