import unittest


class TestAgentPortCanonicalization(unittest.TestCase):
    def test_connection_manager_windows_com_case_insensitive(self):
        from replx.cli.agent.server import connection_manager as cm

        old_platform = cm.sys.platform
        cm.sys.platform = "win32"
        try:
            mgr = cm.ConnectionManager()
            conn = cm.BoardConnection(port="COM1")
            mgr.add_connection("COM1", conn)

            self.assertIsNotNone(mgr.get_connection("com1"))
            self.assertIsNotNone(mgr.get_connection("COM1"))
            self.assertTrue(mgr.has_connection("com1"))
            self.assertTrue(mgr.has_connection("COM1"))

            removed = mgr.remove_connection("com1")
            self.assertIsNotNone(removed)
            self.assertFalse(mgr.has_connection("COM1"))
        finally:
            cm.sys.platform = old_platform

    def test_connection_manager_disconnect_case_insensitive(self):
        from replx.cli.agent.server import connection_manager as cm

        old_platform = cm.sys.platform
        cm.sys.platform = "win32"
        try:
            mgr = cm.ConnectionManager()
            conn = cm.BoardConnection(port="COM4")
            mgr.add_connection("COM4", conn)

            self.assertTrue(mgr.disconnect("com4"))
            self.assertFalse(mgr.has_connection("COM4"))
        finally:
            cm.sys.platform = old_platform


if __name__ == "__main__":
    unittest.main()
