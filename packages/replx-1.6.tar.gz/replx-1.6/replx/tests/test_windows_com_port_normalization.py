import os
import tempfile
import unittest


class TestWindowsComPortNormalization(unittest.TestCase):
    def test_config_manager_case_insensitive_get_and_update(self):
        from replx.cli import config as cfg

        # Mock comports() so the test doesn't depend on actual hardware ports.
        import serial.tools.list_ports as lp
        old_comports = lp.comports
        lp.comports = lambda: [type("PortInfo", (), {"device": "COM1"})()]

        old_platform = cfg.sys.platform
        cfg.sys.platform = "win32"
        try:
            with tempfile.TemporaryDirectory() as td:
                env_path = os.path.join(td, ".replx")
                with open(env_path, "w", encoding="utf-8") as f:
                    f.write(
                        """
[com1]
VERSION=1.27.0
CORE=RP2350
DEVICE=ticle-lite
MANUFACTURER=Hanback

[DEFAULT]
CONNECTION=com1
""".lstrip()
                    )

                # Case-insensitive lookup
                conn = cfg.ConfigManager.get_connection(env_path, "COM1")
                self.assertIsNotNone(conn)
                self.assertEqual(conn.get("core"), "RP2350")

                # Update should NOT create a new section on Windows
                cfg.ConfigManager.update_connection(
                    env_path,
                    "COM1",
                    version="9.9.9",
                    set_default=True,
                )
                data = cfg.ConfigManager.read(env_path)
                # Stored key should use OS-provided casing (COM1)
                self.assertEqual(set(data.get("connections", {}).keys()), {"COM1"})
                self.assertEqual(data.get("default"), "COM1")
                self.assertEqual(data["connections"]["COM1"]["version"], "9.9.9")
        finally:
            cfg.sys.platform = old_platform
            lp.comports = old_comports

    def test_device_canonical_and_cmp_key(self):
        from replx.cli.commands import device as dev

        old_platform = dev.sys.platform
        dev.sys.platform = "win32"
        try:
            # Comparison key: case-insensitive on Windows
            self.assertEqual(dev._serial_port_cmp_key("COM1"), "com1")
            self.assertEqual(dev._serial_port_cmp_key("com1"), "com1")
        finally:
            dev.sys.platform = old_platform


if __name__ == "__main__":
    unittest.main()
