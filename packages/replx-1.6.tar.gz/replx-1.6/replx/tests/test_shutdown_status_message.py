import unittest


class TestShutdownStatusMessage(unittest.TestCase):
    def _patch_and_run(self, *, was_running, stop_result):
        import replx.cli.commands.utility as util

        old_get_port = util._get_current_agent_port
        old_is_running = util.AgentClient.is_agent_running
        old_stop = util.AgentClient.stop_agent
        old_print_panel = util.OutputHelper.print_panel

        calls = []

        try:
            util._get_current_agent_port = lambda: 9999
            util.AgentClient.is_agent_running = staticmethod(lambda port=None: was_running)
            util.AgentClient.stop_agent = staticmethod(lambda port=None: stop_result)
            util.OutputHelper.print_panel = lambda message, title, border_style: calls.append(
                {
                    "message": message,
                    "title": title,
                    "border_style": border_style,
                }
            )

            util._do_shutdown()
        finally:
            util._get_current_agent_port = old_get_port
            util.AgentClient.is_agent_running = old_is_running
            util.AgentClient.stop_agent = old_stop
            util.OutputHelper.print_panel = old_print_panel

        return calls

    def test_shutdown_complete_when_running_and_stopped(self):
        calls = self._patch_and_run(was_running=True, stop_result=True)

        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0]["title"], "Shutdown Complete")

    def test_already_shutdown_when_agent_not_running(self):
        calls = self._patch_and_run(was_running=False, stop_result=False)

        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0]["title"], "Already Shutdown")

    def test_shutdown_failed_when_running_but_not_stopped(self):
        calls = self._patch_and_run(was_running=True, stop_result=False)

        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0]["title"], "Shutdown Failed")


if __name__ == "__main__":
    unittest.main()
