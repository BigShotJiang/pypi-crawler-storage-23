"""arcui — Arc web UI. Coming soon."""

__version__ = "0.0.1"
