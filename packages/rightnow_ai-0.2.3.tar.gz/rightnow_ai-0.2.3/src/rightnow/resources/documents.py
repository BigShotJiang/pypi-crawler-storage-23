from __future__ import annotations

from typing import Any

from .._types import DocumentResponse


class Documents:
    """Sync documents: client.documents.summarize/translate/extract/diacritize(...)"""

    def __init__(self, client: object) -> None:
        self._client = client

    def _post(self, path: str, payload: dict[str, Any]) -> DocumentResponse:
        resp = self._client._http.post(  # type: ignore[attr-defined]
            self._client._build_url(path),  # type: ignore[attr-defined]
            json=payload,
            headers=self._client._headers,  # type: ignore[attr-defined]
            timeout=self._client.timeout,  # type: ignore[attr-defined]
        )
        self._client._raise_for_status(resp)  # type: ignore[attr-defined]
        return DocumentResponse(**resp.json())

    def summarize(
        self,
        *,
        text: str,
        model: str = "falcon-h1-arabic-7b",
        language: str = "ar",
        max_length: int | None = None,
        **kwargs: Any,
    ) -> DocumentResponse:
        payload: dict[str, Any] = {
            "text": text,
            "model": model,
            "language": language,
            **kwargs,
        }
        if max_length is not None:
            payload["max_length"] = max_length
        return self._post("/v1/documents/summarize", payload)

    def translate(
        self,
        *,
        text: str,
        source_language: str = "ar",
        target_language: str = "en",
        model: str = "falcon-h1-arabic-7b",
        **kwargs: Any,
    ) -> DocumentResponse:
        payload: dict[str, Any] = {
            "text": text,
            "model": model,
            "source_language": source_language,
            "target_language": target_language,
            **kwargs,
        }
        return self._post("/v1/documents/translate", payload)

    def extract(
        self,
        *,
        text: str,
        entities: list[str],
        model: str = "falcon-h1-arabic-7b",
        **kwargs: Any,
    ) -> DocumentResponse:
        payload: dict[str, Any] = {
            "text": text,
            "model": model,
            "entities": entities,
            **kwargs,
        }
        return self._post("/v1/documents/extract", payload)

    def diacritize(
        self,
        *,
        text: str,
        model: str = "falcon-h1-arabic-7b",
        **kwargs: Any,
    ) -> DocumentResponse:
        payload: dict[str, Any] = {"text": text, "model": model, **kwargs}
        return self._post("/v1/documents/diacritize", payload)


class AsyncDocuments:
    """Async documents: client.documents.summarize/translate/extract/diacritize(...)"""

    def __init__(self, client: object) -> None:
        self._client = client

    async def _post(self, path: str, payload: dict[str, Any]) -> DocumentResponse:
        resp = await self._client._http.post(  # type: ignore[attr-defined]
            self._client._build_url(path),  # type: ignore[attr-defined]
            json=payload,
            headers=self._client._headers,  # type: ignore[attr-defined]
            timeout=self._client.timeout,  # type: ignore[attr-defined]
        )
        self._client._raise_for_status(resp)  # type: ignore[attr-defined]
        return DocumentResponse(**resp.json())

    async def summarize(
        self,
        *,
        text: str,
        model: str = "falcon-h1-arabic-7b",
        language: str = "ar",
        max_length: int | None = None,
        **kwargs: Any,
    ) -> DocumentResponse:
        payload: dict[str, Any] = {
            "text": text,
            "model": model,
            "language": language,
            **kwargs,
        }
        if max_length is not None:
            payload["max_length"] = max_length
        return await self._post("/v1/documents/summarize", payload)

    async def translate(
        self,
        *,
        text: str,
        source_language: str = "ar",
        target_language: str = "en",
        model: str = "falcon-h1-arabic-7b",
        **kwargs: Any,
    ) -> DocumentResponse:
        payload: dict[str, Any] = {
            "text": text,
            "model": model,
            "source_language": source_language,
            "target_language": target_language,
            **kwargs,
        }
        return await self._post("/v1/documents/translate", payload)

    async def extract(
        self,
        *,
        text: str,
        entities: list[str],
        model: str = "falcon-h1-arabic-7b",
        **kwargs: Any,
    ) -> DocumentResponse:
        payload: dict[str, Any] = {
            "text": text,
            "model": model,
            "entities": entities,
            **kwargs,
        }
        return await self._post("/v1/documents/extract", payload)

    async def diacritize(
        self,
        *,
        text: str,
        model: str = "falcon-h1-arabic-7b",
        **kwargs: Any,
    ) -> DocumentResponse:
        payload: dict[str, Any] = {"text": text, "model": model, **kwargs}
        return await self._post("/v1/documents/diacritize", payload)
