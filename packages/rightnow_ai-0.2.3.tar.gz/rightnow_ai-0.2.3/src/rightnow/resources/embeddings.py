from __future__ import annotations

from typing import Any

from .._types import EmbeddingResponse


class Embeddings:
    """Sync embeddings: client.embeddings.create(...)"""

    def __init__(self, client: object) -> None:
        self._client = client

    def create(
        self,
        *,
        model: str,
        input: str | list[str],
        **kwargs: Any,
    ) -> EmbeddingResponse:
        payload: dict[str, Any] = {"model": model, "input": input, **kwargs}

        resp = self._client._http.post(  # type: ignore[attr-defined]
            self._client._build_url("/v1/embeddings"),  # type: ignore[attr-defined]
            json=payload,
            headers=self._client._headers,  # type: ignore[attr-defined]
            timeout=self._client.timeout,  # type: ignore[attr-defined]
        )
        self._client._raise_for_status(resp)  # type: ignore[attr-defined]
        return EmbeddingResponse(**resp.json())


class AsyncEmbeddings:
    """Async embeddings: client.embeddings.create(...)"""

    def __init__(self, client: object) -> None:
        self._client = client

    async def create(
        self,
        *,
        model: str,
        input: str | list[str],
        **kwargs: Any,
    ) -> EmbeddingResponse:
        payload: dict[str, Any] = {"model": model, "input": input, **kwargs}

        resp = await self._client._http.post(  # type: ignore[attr-defined]
            self._client._build_url("/v1/embeddings"),  # type: ignore[attr-defined]
            json=payload,
            headers=self._client._headers,  # type: ignore[attr-defined]
            timeout=self._client.timeout,  # type: ignore[attr-defined]
        )
        self._client._raise_for_status(resp)  # type: ignore[attr-defined]
        return EmbeddingResponse(**resp.json())
