from __future__ import annotations

import httpx

from ._base_client import BaseClient
from .resources.chat import AsyncChat
from .resources.embeddings import AsyncEmbeddings
from .resources.dialects import AsyncDialects
from .resources.documents import AsyncDocuments
from .resources.audio import AsyncAudio
from .resources.models import AsyncModels


class AsyncRightNow(BaseClient):
    """Asynchronous RightNow API client.

    Usage::

        from rightnow import AsyncRightNow

        async with AsyncRightNow(api_key="rn-xxx") as client:
            response = await client.chat.completions.create(
                model="falcon-h1-arabic-7b",
                messages=[{"role": "user", "content": "مرحبا"}],
            )
            print(response.choices[0].message.content)
    """

    chat: AsyncChat
    embeddings: AsyncEmbeddings
    dialects: AsyncDialects
    documents: AsyncDocuments
    audio: AsyncAudio
    models: AsyncModels

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float | None = None,
        max_retries: int | None = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._http = httpx.AsyncClient(timeout=self.timeout, follow_redirects=True)

        self.chat = AsyncChat(self)
        self.embeddings = AsyncEmbeddings(self)
        self.dialects = AsyncDialects(self)
        self.documents = AsyncDocuments(self)
        self.audio = AsyncAudio(self)
        self.models = AsyncModels(self)

    async def close(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> AsyncRightNow:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
