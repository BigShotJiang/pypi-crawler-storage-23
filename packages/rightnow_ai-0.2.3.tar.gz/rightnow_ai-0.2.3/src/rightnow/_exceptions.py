from __future__ import annotations


class RightNowError(Exception):
    """Base exception for the RightNow SDK."""

    def __init__(self, message: str, status_code: int | None = None, body: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class AuthenticationError(RightNowError):
    """Raised when the API key is invalid or missing (401)."""


class PermissionDeniedError(RightNowError):
    """Raised when the API key lacks permission for the request (403)."""


class NotFoundError(RightNowError):
    """Raised when the requested resource does not exist (404)."""


class BadRequestError(RightNowError):
    """Raised when the request is malformed (400)."""


class RateLimitError(RightNowError):
    """Raised when rate-limited (429)."""


class InternalServerError(RightNowError):
    """Raised on upstream server errors (500+)."""


class APIConnectionError(RightNowError):
    """Raised when the SDK cannot connect to the API."""


class APITimeoutError(APIConnectionError):
    """Raised when a request times out."""


STATUS_MAP: dict[int, type[RightNowError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    403: PermissionDeniedError,
    404: NotFoundError,
    429: RateLimitError,
}
