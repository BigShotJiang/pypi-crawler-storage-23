from __future__ import annotations

import httpx

from ._base_client import BaseClient
from .resources.chat import Chat
from .resources.embeddings import Embeddings
from .resources.dialects import Dialects
from .resources.documents import Documents
from .resources.audio import Audio
from .resources.models import Models


class RightNow(BaseClient):
    """Synchronous RightNow API client.

    Usage::

        from rightnow import RightNow

        client = RightNow(api_key="rn-xxx")
        response = client.chat.completions.create(
            model="falcon-h1-arabic-7b",
            messages=[{"role": "user", "content": "مرحبا"}],
        )
        print(response.choices[0].message.content)
    """

    chat: Chat
    embeddings: Embeddings
    dialects: Dialects
    documents: Documents
    audio: Audio
    models: Models

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float | None = None,
        max_retries: int | None = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._http = httpx.Client(timeout=self.timeout, follow_redirects=True)

        self.chat = Chat(self)
        self.embeddings = Embeddings(self)
        self.dialects = Dialects(self)
        self.documents = Documents(self)
        self.audio = Audio(self)
        self.models = Models(self)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> RightNow:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
