# RightNow — Arabic AI SDK

Python SDK for the Arabic API by RightNow. Chat, embeddings, speech-to-text, and text-to-speech — all optimized for Arabic.

## Install

```bash
pip install rightnow-ai
```

## Quick Start

```python
from rightnow import RightNow

client = RightNow(api_key="rn-...")

response = client.chat.completions.create(
    model="falcon-h1-arabic-7b",
    messages=[{"role": "user", "content": "ما هي عاصمة الأردن؟"}],
)
print(response.choices[0].message.content)
```

## Streaming

```python
stream = client.chat.completions.create(
    model="falcon-h1-arabic-7b",
    messages=[{"role": "user", "content": "مرحبا"}],
    stream=True,
)
for chunk in stream:
    if chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end="")
stream.close()
```

## Embeddings

```python
response = client.embeddings.create(
    model="bge-m3-arabic",
    input="مرحبا بالعالم",
)
print(response.data[0].embedding[:5])
```

## Async

```python
from rightnow import AsyncRightNow

async with AsyncRightNow(api_key="rn-...") as client:
    response = await client.chat.completions.create(
        model="falcon-h1-arabic-7b",
        messages=[{"role": "user", "content": "مرحبا"}],
    )
```

## Available Models

| Model | Type | Size | Description |
|-------|------|------|-------------|
| `falcon-h1-arabic-7b` | Chat | 7B | Best price/quality (default) |
| `falcon-h1-arabic-34b` | Chat | 34B | Complex reasoning |
| `jais-2-8b` | Chat | 8B | Strong dialect understanding |
| `allam-7b` | Chat | 7B | Saudi Arabic, MSA |
| `bge-m3-arabic` | Embeddings | 568M | 1024-dim, 8192 context |
| `whisper-v3-arabic` | STT | 809M | Arabic speech recognition |
| `chatterbox-arabic` | TTS | ~1B | Arabic text-to-speech |
