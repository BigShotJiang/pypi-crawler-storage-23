"""PolyMath language-specific subclasses (Part 1: AR-JA)."""
from __future__ import annotations

from wisent.core.contrastive_pairs.huggingface_pairs.hf_task_extractors.polymath import PolyMathExtractor

class PolyMathARTopExtractor(PolyMathExtractor):
    language = "ar"
    difficulty = "top"

class PolyMathARHighExtractor(PolyMathExtractor):
    language = "ar"
    difficulty = "high"

class PolyMathARMediumExtractor(PolyMathExtractor):
    language = "ar"
    difficulty = "medium"

class PolyMathARLowExtractor(PolyMathExtractor):
    language = "ar"
    difficulty = "low"

# Bengali
class PolyMathBNTopExtractor(PolyMathExtractor):
    language = "bn"
    difficulty = "top"

class PolyMathBNHighExtractor(PolyMathExtractor):
    language = "bn"
    difficulty = "high"

class PolyMathBNMediumExtractor(PolyMathExtractor):
    language = "bn"
    difficulty = "medium"

class PolyMathBNLowExtractor(PolyMathExtractor):
    language = "bn"
    difficulty = "low"

# German
class PolyMathDETopExtractor(PolyMathExtractor):
    language = "de"
    difficulty = "top"

class PolyMathDEHighExtractor(PolyMathExtractor):
    language = "de"
    difficulty = "high"

class PolyMathDEMediumExtractor(PolyMathExtractor):
    language = "de"
    difficulty = "medium"

class PolyMathDELowExtractor(PolyMathExtractor):
    language = "de"
    difficulty = "low"

# English
class PolyMathENTopExtractor(PolyMathExtractor):
    language = "en"
    difficulty = "top"

class PolyMathENHighExtractor(PolyMathExtractor):
    language = "en"
    difficulty = "high"

class PolyMathENMediumExtractor(PolyMathExtractor):
    language = "en"
    difficulty = "medium"

class PolyMathENLowExtractor(PolyMathExtractor):
    language = "en"
    difficulty = "low"

# Spanish
class PolyMathESTopExtractor(PolyMathExtractor):
    language = "es"
    difficulty = "top"

class PolyMathESHighExtractor(PolyMathExtractor):
    language = "es"
    difficulty = "high"

class PolyMathESMediumExtractor(PolyMathExtractor):
    language = "es"
    difficulty = "medium"

class PolyMathESLowExtractor(PolyMathExtractor):
    language = "es"
    difficulty = "low"

# French
class PolyMathFRTopExtractor(PolyMathExtractor):
    language = "fr"
    difficulty = "top"

class PolyMathFRHighExtractor(PolyMathExtractor):
    language = "fr"
    difficulty = "high"

class PolyMathFRMediumExtractor(PolyMathExtractor):
    language = "fr"
    difficulty = "medium"

class PolyMathFRLowExtractor(PolyMathExtractor):
    language = "fr"
    difficulty = "low"

# Indonesian
class PolyMathIDTopExtractor(PolyMathExtractor):
    language = "id"
    difficulty = "top"

class PolyMathIDHighExtractor(PolyMathExtractor):
    language = "id"
    difficulty = "high"

class PolyMathIDMediumExtractor(PolyMathExtractor):
    language = "id"
    difficulty = "medium"

class PolyMathIDLowExtractor(PolyMathExtractor):
    language = "id"
    difficulty = "low"

# Italian
class PolyMathITTopExtractor(PolyMathExtractor):
    language = "it"
    difficulty = "top"

class PolyMathITHighExtractor(PolyMathExtractor):
    language = "it"
    difficulty = "high"

class PolyMathITMediumExtractor(PolyMathExtractor):
    language = "it"
    difficulty = "medium"

class PolyMathITLowExtractor(PolyMathExtractor):
    language = "it"
    difficulty = "low"

# Japanese
class PolyMathJATopExtractor(PolyMathExtractor):
    language = "ja"
    difficulty = "top"

class PolyMathJAHighExtractor(PolyMathExtractor):
    language = "ja"
    difficulty = "high"

class PolyMathJAMediumExtractor(PolyMathExtractor):
    language = "ja"
    difficulty = "medium"

class PolyMathJALowExtractor(PolyMathExtractor):
    language = "ja"
    difficulty = "low"

