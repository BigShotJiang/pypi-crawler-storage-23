# AI Social Media Content Studio — Full Technology & Infrastructure Plan

> **Project:** Smartlyte AI Social Media Content Studio
> **Stack Core:** Next.js · Better Auth · Convex · Mastra AI

---

## 1. Core Framework & Infrastructure

### Next.js (App Router)
Full-stack framework powering the entire application.

**Used for:**
- All frontend pages: Post Creator, Content Calendar, News Search, Drafts, Brand Settings, Image Generation Panel
- API routes as the backend orchestrator (content extraction, news fetching, AI calls, scheduling triggers)
- Server Actions for form handling (post creation wizard, brand profile updates)
- Middleware for route protection and auth guards

---

### Better Auth
Authentication and session management layer.

**Used for:**
- Email/password and social login
- Session handling across the app
- OAuth token management for social media platforms — storing and refreshing access tokens for Facebook, Instagram, LinkedIn, and X
- Protecting API routes and dashboard pages
- Multi-user team support (enterprise manual approval workflow)

---

### Convex
Primary real-time database and backend state layer.

**Used for:**
- User profiles and account settings
- Brand voice preferences per user/organisation
- Saved posts, drafts, and post history
- Scheduled posts queue (date, time, platform, status)
- News search logs and image asset metadata
- Approval workflow state (pending / approved / rejected / published)
- Encrypted social platform tokens (access_token, refresh_token, expiry, platform_user_id, page_id per platform)
- Real-time subscriptions for the Pending Approval dashboard

---

## 2. AI & Agent Layer

### Mastra AI — Agent Orchestration

#### Content Generation Agent
- Input: Extracted content (URL/PDF/news) + tone, platform, language, CTA preference, length
- Output: 1–3 post variations per platform with hashtags and image description
- Used in: Use Case A (URL to Post), Use Case C (Blog Repurposing)

#### News Summarisation Agent
- Input: News headlines, excerpts, full article content, user's chosen tone and platform
- Output: Key insights, trend explanation, 1–3 social posts, hashtags, conversation-starter questions
- Used in: Use Case D (Post from News Headlines)

#### 30-Day Calendar Agent
- Input: Business type, goals, target audience, platforms, posting frequency
- Output: Full month grid with weekly themes, post ideas, captions, image suggestions, hashtags per slot
- Used in: Use Case B (Content Calendar Generator)

#### Blog Repurposing Agent
- Input: Blog text or URL
- Output: 5 LinkedIn posts, 5 Instagram captions, 10 X variations, 1 YouTube description, 1 short blog post
- Used in: Use Case C (Repurpose a Blog or Document)

#### Tone & Language Transformer Agent
- Input: Existing post + target tone + target language
- Output: Rewritten post in new tone/language with appropriate hashtags
- Used in: All use cases — shortening, lengthening, translating posts

---

### Claude API (via Mastra)
The LLM powering all agents above.

**Used for:** Content creation, tone/language transformation, summarisation, hashtag suggestions, blog and case study generation, post variation generation.

---

## 3. Content Extraction

### Cheerio + Playwright
For extracting content from user-submitted URLs (Use Case A).
- Cheerio — lightweight HTML parser for static pages
- Playwright — headless browser for JavaScript-rendered pages where Cheerio fails
- Extracts: page title, main body text, meta description, key sections

### pdf-parse
Extracts structured text from user-uploaded PDFs for Use Case C. Strips formatting and passes raw text to the Blog Repurposing Agent.

---

## 4. News APIs

### NewsAPI.org
Primary news aggregator for Use Case D. Keyword and region-based headline search (UK / Global / Europe / US), date filters, returns headline/excerpt/publisher/URL.

### GDELT API
Supplementary global events and news coverage. Free, no API key required.

### rss-parser (npm)
For ingesting custom RSS feeds defined by the user in settings.

> Optional: Bing News Search API — paid alternative for higher volume usage.

---

## 5. Image Generation & Storage

### Replicate API or fal.ai
AI image generation from post-specific prompts suggested by the Content Generation Agent. Integrated into the post builder UI via a "Generate Image" button.

### Cloudinary
Cloud storage and delivery for all image assets. Handles resizing and optimisation per platform (1:1 for Instagram, 1.91:1 for LinkedIn).

### Uploadthing
Handles user file uploads (PDFs, manual images) within the Next.js app. Passes files to Cloudinary for long-term storage.

---

## 6. Social Media Platform Integrations

### Meta — Facebook Pages

**Setup:**
- Meta Developer Account at developers.facebook.com
- Meta App (Business type) with Facebook Login and Pages API enabled

**Key APIs:**
- POST /{page-id}/feed — publish text posts
- POST /{page-id}/photos — publish image posts

**Permissions Required:**
- pages_manage_posts
- pages_read_engagement
- pages_show_list
- publish_pages

**Token Storage in Convex:**
- platform: "facebook"
- access_token (encrypted)
- page_id
- token_expiry
- scope array

**App Review:** Required for publishing to other users' pages. Requires a screencast demo, Privacy Policy URL, and Business Verification. Estimated wait: 1–4 weeks.

---

### Meta — Instagram

**Setup:**
- Same Meta App as Facebook
- Instagram Graph API product enabled
- Users must have an Instagram Business or Creator account linked to a Facebook Page

**Key APIs:**
- POST /{ig-user-id}/media — create media container
- POST /{ig-user-id}/media_publish — publish the container (two-step process)

**Permissions Required:**
- instagram_basic
- instagram_content_publish
- pages_read_engagement

**Important Limitation:** Instagram does not support text-only posts via API. Every post requires an image or video.

**Token Storage in Convex:**
- platform: "instagram"
- access_token (encrypted)
- ig_user_id
- token_expiry

**App Review:** Same Meta review process as Facebook. Estimated wait: 1–4 weeks.

---

### LinkedIn

**Setup:**
- LinkedIn Developer Account at developer.linkedin.com
- LinkedIn App associated with a Company Page
- Separate application for Marketing Developer Platform (MDP) required for company page posting

**Key APIs:**
- POST /ugcPosts — publish posts on behalf of a person or organisation

**Permissions Required:**
- w_member_social — post on behalf of a person
- w_organization_social — post to company pages (requires MDP access)
- r_liteprofile
- r_emailaddress

**Token Storage in Convex:**
- platform: "linkedin"
- access_token (encrypted)
- refresh_token (encrypted)
- linkedin_user_id
- organisation_id
- token_expiry

**Important Limitations:**
- OAuth tokens expire — refresh token handling is mandatory
- Rate limit: 100 API calls/day on basic tier
- Company page posting requires the user to be a page admin
- Marketing Developer Platform approval is a separate manual process

**App Review:** Marketing Developer Platform application required. Estimated wait: 2–6 weeks.

---

### X (Twitter)

**Setup:**
- X Developer Account at developer.twitter.com
- Project and App created in the developer portal
- Minimum Basic tier ($100/month) required for multi-user production use

**Key APIs:**
- POST /2/tweets — create a tweet
- POST /2/tweets with reply.in_reply_to_tweet_id — create a thread
- POST /1.1/media/upload — upload images (v1.1 endpoint, still required for media)

**OAuth 2.0 Scopes Required:**
- tweet.write
- tweet.read
- users.read
- offline.access (for refresh tokens — must be enabled in app settings)

**Token Storage in Convex:**
- platform: "x"
- access_token (encrypted)
- refresh_token (encrypted)
- x_user_id
- token_expiry

**Important Limitations:**
- Free tier: 1,500 tweets/month per app — not viable for a multi-user product
- Basic tier ($100/month): 3,000 tweets/month per user
- Thread posting requires sequential chained API calls
- Media uploads use the older v1.1 API alongside v2

**App Review:** Tier upgrade is instant (paid). No manual review required.

---

### TikTok (Future Phase)

**Setup:**
- TikTok for Developers account at developers.tiktok.com
- Apply for Content Posting API

**Key APIs:**
- POST /v2/post/publish/video/init/ — upload and publish video
- POST /v2/post/publish/content/init/ — photo posts

**Permissions Required:** video.publish, video.upload

**Important Limitations:**
- No text-only posts — video or photo required on every post
- Video must be uploaded to TikTok servers before publishing (chunked upload handling required)
- Developer portal is less mature than Meta and LinkedIn

**App Review:** Partially invitation-based. Timeline varies.

---

### OAuth Connection Flow (All Platforms)

Standard flow implemented via Better Auth and Convex:

1. User clicks "Connect [Platform]" in Integration Settings
2. App redirects to platform's OAuth consent screen
3. User grants requested permissions
4. Platform redirects back with a one-time auth code
5. Backend exchanges code for access_token and refresh_token
6. Tokens stored encrypted in Convex against the user's account
7. When posting: retrieve token → call platform API → handle response
8. If token expired: use refresh_token to silently obtain a new access_token
9. Log result (success / failure / retry) in Convex post history

---

### Platform Approval Timeline

| Platform    | Review Required                        | Estimated Wait | Cost          |
|-------------|----------------------------------------|----------------|---------------|
| Facebook    | Yes — App Review + Business Verification | 1–4 weeks    | Free          |
| Instagram   | Yes — same Meta App review             | 1–4 weeks      | Free          |
| LinkedIn    | Yes — Marketing Developer Platform     | 2–6 weeks      | Free          |
| X / Twitter | Tier upgrade only (no manual review)   | Instant        | $100/month    |
| TikTok      | Yes — invitation/review                | Varies         | Free          |

Recommendation: Submit LinkedIn and Meta App Review applications as early as possible — they are the biggest bottlenecks in the project. Build and test everything against your own developer accounts first since no review is needed for your own accounts.

---

## 7. Scheduling Engine

### Inngest
Queue-based background job engine for the auto-posting workflow (Use Case E, Workflow 3). Integrates natively with Next.js and Vercel.

**Used for:**
- Queuing scheduled posts with a target date and time
- Cron-based trigger at scheduled time to fire the correct platform API call
- Automatic retry logic on API failures
- Updating post status in Convex (queued → published / failed)
- Triggering Resend email notifications on publish

---

## 8. Real-time & Notifications

### Convex Real-time Subscriptions
- Live Pending Approval dashboard — new drafts appear instantly for the owner
- Post status updates reflected in UI without page refresh
- Calendar slot updates during calendar generation

### Resend
- Email notification when a post is published successfully
- Notification to owner when a draft is pending approval
- Rejection notification with comments back to the post creator

---

## 9. Frontend UI Components

### shadcn/ui + Tailwind CSS
Core component library for all UI surfaces — post builder, approval dashboard, settings panels, tabbed post previews, modals, form components.

### FullCalendar
Interactive calendar for the 30-day content calendar view. Provides month grid display with clickable slots that open the post editor.

### TipTap
Rich text editor for the post editing interface. Supports inline formatting, emoji insertion, and character count per platform.

---

## 10. Complete Technology Summary

| Technology              | Category    | Purpose                                           |
|-------------------------|-------------|---------------------------------------------------|
| Next.js (App Router)    | Framework   | Full-stack — frontend UI + backend API routes     |
| Better Auth             | Auth        | Sessions, social login, OAuth token management    |
| Convex                  | Database    | All data storage + real-time subscriptions        |
| Mastra AI               | Agents      | Orchestrates all AI workflows and agents          |
| Claude API              | LLM         | Powers all content generation and transformation  |
| Cheerio / Playwright    | Extraction  | URL content scraping                              |
| pdf-parse               | Extraction  | PDF text extraction                               |
| NewsAPI / GDELT / rss-parser | News   | Headline aggregation and RSS ingestion            |
| Replicate / fal.ai      | Image AI    | AI image generation from prompts                  |
| Cloudinary              | Storage     | Image hosting, resizing, delivery                 |
| Uploadthing             | File Upload | User PDF and image uploads                        |
| Meta Graph API          | Social      | Facebook Pages + Instagram publishing             |
| LinkedIn API + MDP      | Social      | LinkedIn personal + company page posting          |
| X API v2                | Social      | Tweet and thread publishing                       |
| TikTok API              | Social      | Video/photo posting (future phase)                |
| Inngest                 | Scheduling  | Background jobs, cron, auto-posting queue         |
| Resend                  | Email       | Post and approval notifications                   |
| shadcn/ui + Tailwind    | UI          | Component library                                 |
| FullCalendar            | UI          | 30-day calendar grid view                         |
| TipTap                  | UI          | Rich text post editor                             |

---

## 11. Recommended Build Order

1. Use Case A (URL to Post) — touches every layer; best integration test to validate the full stack
2. Auth + Social OAuth connections — foundation for all publishing; start Meta and LinkedIn reviews immediately
3. Use Case D (News to Post) — high value, showcases core AI agent capability
4. Use Case E (Scheduling + Auto-Post) — Inngest and social APIs working together
5. Use Case B (30-Day Calendar) — most complex agent; build on a stable foundation
6. Use Case C (Blog Repurposing) — straightforward once agents are established
7. Manual Approval Workflow — layer on top of the existing post pipeline
8. TikTok Integration — future phase
