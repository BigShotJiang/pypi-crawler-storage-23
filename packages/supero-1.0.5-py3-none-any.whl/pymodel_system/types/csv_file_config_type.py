# File: pymodel_system/types/csv_file_config_type.py
"""
This file was generated from the csv_file_config_type.json schema.
ENHANCED: Proper datetime handling with automatic string<->datetime conversion.
ENHANCED: Supero fluent API support with smart reference management.
"""

from typing import List, Dict, Any, Optional, TYPE_CHECKING
import importlib
import uuid
import inflection

from ..serialization_errors import ObjectDeserializationError, InvalidParentError
from datetime import datetime
import re

class CsvFileConfigType:
    """
    Represents a CsvFileConfigType instance.
    
    This class is auto-generated and includes:
    - Standard CRUD operations
    - Fluent API methods (when used with Supero)
    - Smart reference management with link data support
    - Parent-child hierarchy navigation
    """
    
    _OBJ_TYPE = "csv_file_config_type"
    _PARENT_TYPE = "None"

    # Type metadata for deserialization
    _type_metadata = {
    'source_type': {
        'type': 'str',
        'is_list': False,
        'json_name': 'source_type',
        'original_type': 'string',
        'mandatory': True,
        'static': False,
    },
    'file_path': {
        'type': 'str',
        'is_list': False,
        'json_name': 'file_path',
        'original_type': 'string',
        'mandatory': True,
        'static': False,
    },
    'file_format': {
        'type': 'str',
        'is_list': False,
        'json_name': 'file_format',
        'original_type': 'string',
        'mandatory': True,
        'static': False,
    },
    's3_bucket': {
        'type': 'str',
        'is_list': False,
        'json_name': 's3_bucket',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    's3_region': {
        'type': 'str',
        'is_list': False,
        'json_name': 's3_region',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'aws_access_key_id': {
        'type': 'str',
        'is_list': False,
        'json_name': 'aws_access_key_id',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'aws_secret_access_key': {
        'type': 'str',
        'is_list': False,
        'json_name': 'aws_secret_access_key',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'gcs_bucket': {
        'type': 'str',
        'is_list': False,
        'json_name': 'gcs_bucket',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'gcs_credentials_json': {
        'type': 'str',
        'is_list': False,
        'json_name': 'gcs_credentials_json',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'sftp_host': {
        'type': 'str',
        'is_list': False,
        'json_name': 'sftp_host',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'sftp_port': {
        'type': 'int',
        'is_list': False,
        'json_name': 'sftp_port',
        'original_type': 'number',
        'mandatory': False,
        'static': False,
    },
    'sftp_username': {
        'type': 'str',
        'is_list': False,
        'json_name': 'sftp_username',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'sftp_password': {
        'type': 'str',
        'is_list': False,
        'json_name': 'sftp_password',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'sftp_private_key': {
        'type': 'str',
        'is_list': False,
        'json_name': 'sftp_private_key',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'url': {
        'type': 'str',
        'is_list': False,
        'json_name': 'url',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'csv_delimiter': {
        'type': 'str',
        'is_list': False,
        'json_name': 'csv_delimiter',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'csv_quote_char': {
        'type': 'str',
        'is_list': False,
        'json_name': 'csv_quote_char',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'csv_has_header': {
        'type': 'bool',
        'is_list': False,
        'json_name': 'csv_has_header',
        'original_type': 'bool',
        'mandatory': False,
        'static': False,
    },
    'csv_encoding': {
        'type': 'str',
        'is_list': False,
        'json_name': 'csv_encoding',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'csv_skip_rows': {
        'type': 'int',
        'is_list': False,
        'json_name': 'csv_skip_rows',
        'original_type': 'number',
        'mandatory': False,
        'static': False,
    },
    'excel_sheet': {
        'type': 'str',
        'is_list': False,
        'json_name': 'excel_sheet',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'json_records_path': {
        'type': 'str',
        'is_list': False,
        'json_name': 'json_records_path',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    },
    'archive_after_processing': {
        'type': 'bool',
        'is_list': False,
        'json_name': 'archive_after_processing',
        'original_type': 'bool',
        'mandatory': False,
        'static': False,
    },
    'archive_path': {
        'type': 'str',
        'is_list': False,
        'json_name': 'archive_path',
        'original_type': 'string',
        'mandatory': False,
        'static': False,
    }
}
    
    # Infrastructure end_points metadata
    _end_points = []
    
    # Index definitions
    _indexes = {}

    _CONSTRAINTS = {}

    # Supero context (set by Supero wrapper)
    _supero_context = None

    @staticmethod
    def _normalize_name(name: str) -> str:
        """ 
        Normalize object/domain name to lowercase with preserved special characters.
        
        SPECIAL CASES (preserved as-is, only lowercased):
        - Email addresses (valid format: user@domain)
        - Phone numbers (start with + or are digit-heavy)
        
        For regular names:
        - Converts to lowercase
        - Allows: alphanumeric, hyphen (-), dot (.), underscore (_)
        - Replaces spaces and other chars with hyphen
        - Collapses multiple separators
        
        Args:
            name: Raw name (e.g., "Acme Corporation", "user@example.com", "+1-555-1234")
        
        Returns:
            Normalized name or preserved special format
            
        Examples:
            >>> normalize_name("Acme Corporation")
            'acme-corporation'
            >>> normalize_name("My_Project.Name")
            'my-project.name'
            >>> normalize_name("user@example.com")
            'user@example.com'
            >>> normalize_name("+1-555-1234")
            '+1-555-1234'
            >>> normalize_name("platform-admin@system.com")
            'platform-admin@system.com'
            >>> normalize_name("@@@")
            ''
        """
        if not name or not isinstance(name, str):
            return name
        
        # Strip whitespace
        name = name.strip()
        
        # SPECIAL CASE 1: Email addresses (valid format)
        # Must have: one @, something before @, something after @
        if '@' in name:
            parts = name.split('@')
            # Valid email: exactly one @, non-empty local and domain parts
            if len(parts) == 2 and parts[0] and parts[1]:
                # Additional check: domain should have at least one char
                # (could be "localhost" or "example.com")
                return name.lower()
            # Invalid email format - fall through to normal normalization
        
        # SPECIAL CASE 2: Phone numbers (starts with + or is digit-heavy)
        # Preserve as-is (including formatting)
        if name.startswith('+'):
            return name
        
        # Check if digit-heavy (>50% digits) - likely a phone number
        if len(name) > 0:
            digit_ratio = sum(c.isdigit() for c in name) / len(name)
            if digit_ratio > 0.5:
                return name
        
        # REGULAR NAME: Apply normalization
        # Convert to lowercase
        name = name.lower()
        
        # Allow: alphanumeric, hyphen, dot, underscore
        # Replace spaces and other special chars with hyphen
        name = re.sub(r'[^a-z0-9.\-_]+', '-', name)
        
        # Collapse multiple consecutive separators to single hyphen
        name = re.sub(r'[-_.]{2,}', '-', name)
        
        # Strip leading/trailing separators
        name = name.strip('-._')
        
        return name

    def __init__(
        self,
        source_type: str,
        file_path: str,
        file_format: str,
        s3_bucket: str = None,
        s3_region: str = 'us-east-1',
        aws_access_key_id: str = None,
        aws_secret_access_key: str = None,
        gcs_bucket: str = None,
        gcs_credentials_json: str = None,
        sftp_host: str = None,
        sftp_port: int = 22,
        sftp_username: str = None,
        sftp_password: str = None,
        sftp_private_key: str = None,
        url: str = None,
        csv_delimiter: str = ',',
        csv_quote_char: str = '"',
        csv_has_header: bool = True,
        csv_encoding: str = 'utf-8',
        csv_skip_rows: int = 0,
        excel_sheet: str = None,
        json_records_path: str = None,
        archive_after_processing: bool = False,
        archive_path: str = None
    ):
        # Set initialization flag to prevent tracking during __init__
        self._initializing = True
        
        self._py_to_json_map = {
    'source_type': 'source_type',
    'file_path': 'file_path',
    'file_format': 'file_format',
    's3_bucket': 's3_bucket',
    's3_region': 's3_region',
    'aws_access_key_id': 'aws_access_key_id',
    'aws_secret_access_key': 'aws_secret_access_key',
    'gcs_bucket': 'gcs_bucket',
    'gcs_credentials_json': 'gcs_credentials_json',
    'sftp_host': 'sftp_host',
    'sftp_port': 'sftp_port',
    'sftp_username': 'sftp_username',
    'sftp_password': 'sftp_password',
    'sftp_private_key': 'sftp_private_key',
    'url': 'url',
    'csv_delimiter': 'csv_delimiter',
    'csv_quote_char': 'csv_quote_char',
    'csv_has_header': 'csv_has_header',
    'csv_encoding': 'csv_encoding',
    'csv_skip_rows': 'csv_skip_rows',
    'excel_sheet': 'excel_sheet',
    'json_records_path': 'json_records_path',
    'archive_after_processing': 'archive_after_processing',
    'archive_path': 'archive_path'
}
        self._json_to_py_map = {
    'source_type': 'source_type',
    'file_path': 'file_path',
    'file_format': 'file_format',
    's3_bucket': 's3_bucket',
    's3_region': 's3_region',
    'aws_access_key_id': 'aws_access_key_id',
    'aws_secret_access_key': 'aws_secret_access_key',
    'gcs_bucket': 'gcs_bucket',
    'gcs_credentials_json': 'gcs_credentials_json',
    'sftp_host': 'sftp_host',
    'sftp_port': 'sftp_port',
    'sftp_username': 'sftp_username',
    'sftp_password': 'sftp_password',
    'sftp_private_key': 'sftp_private_key',
    'url': 'url',
    'csv_delimiter': 'csv_delimiter',
    'csv_quote_char': 'csv_quote_char',
    'csv_has_header': 'csv_has_header',
    'csv_encoding': 'csv_encoding',
    'csv_skip_rows': 'csv_skip_rows',
    'excel_sheet': 'excel_sheet',
    'json_records_path': 'json_records_path',
    'archive_after_processing': 'archive_after_processing',
    'archive_path': 'archive_path'
}

        self.source_type = source_type
        self.file_path = file_path
        self.file_format = file_format
        self.s3_bucket = s3_bucket
        self.s3_region = s3_region
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.gcs_bucket = gcs_bucket
        self.gcs_credentials_json = gcs_credentials_json
        self.sftp_host = sftp_host
        self.sftp_port = sftp_port
        self.sftp_username = sftp_username
        self.sftp_password = sftp_password
        self.sftp_private_key = sftp_private_key
        self.url = url
        self.csv_delimiter = csv_delimiter
        self.csv_quote_char = csv_quote_char
        self.csv_has_header = csv_has_header
        self.csv_encoding = csv_encoding
        self.csv_skip_rows = csv_skip_rows
        self.excel_sheet = excel_sheet
        self.json_records_path = json_records_path
        self.archive_after_processing = archive_after_processing
        self.archive_path = archive_path


        
        # Initialize reference link data storage
        self._ref_link_data = {}
        
        # Mark initialization as complete
        self._initializing = False
        self.set_default_parent()

    def set_parent(self, parent):
        """
        Set the parent of this object and automatically construct fq_name and parent_uuid.
        Args:
            parent: Parent object instance
        Raises:
            AttributeError: If obj_type is missing
            InvalidParentError: If parent type doesn't match expected parent_type
        Example:
            domain = Domain.create(name="engineering")
            project = Project.create(name="backend")
            project.set_parent(domain)
        """
        # Validate parent matches expected type
        if parent.obj_type != self.parent_type:
            raise InvalidParentError(
                f"Invalid parent object. Expected parent_type '{self.parent_type}', "
                f"but got '{parent.obj_type}'"
            )
        
        # Set parent relationships
        self.parent_fq_name = parent.fq_name
        if self.name:
            # Ensure fq_name contains normalized name
            normalized_name = self._normalize_name(self.name)
            self.fq_name = self.parent_fq_name + [normalized_name]

        if hasattr(parent, 'uuid') and parent.uuid:
            self.parent_uuid = parent.uuid

    def set_default_parent(self):
        """Set default parent for root-level objects if not already set."""
        if not hasattr(self, 'obj_type'):
            return
    
        # Only set defaults if parent info wasn't explicitly provided
        if self.parent_type == "config_root":
            # Only set parent_fq_name if it's not already set
            if getattr(self, 'parent_fq_name', None) is None:
                self.parent_fq_name = ["config_root"]
        
            # Only construct fq_name if it's not already set and we have a name
            if not getattr(self, 'fq_name', None) and self.name:
                normalized_name = self._normalize_name(self.name)
                self.fq_name = self.parent_fq_name + [normalized_name]

    def __setattr__(self, name: str, value):
        """
        Override setattr to:
        1. Preserve original name as display_name if not explicitly set
        2. Automatically normalize 'name' attribute
        3. Track pending field updates
        """
        # ========================================================================
        # CRITICAL: When setting 'name', preserve original as display_name first
        # ========================================================================
        
        
        # Always set the attribute (with normalized value if it was 'name')
        super().__setattr__(name, value)
        
        # Track pending field updates for partial updates
        try:
            # Only track if all conditions are met:
            if (hasattr(self, '_pending_field_updates') and 
                hasattr(self, '_py_to_json_map') and 
                name in self._py_to_json_map and
                name not in ['obj_type', 'parent_type', '_pending_field_updates', 
                           '_py_to_json_map', '_json_to_py_map', '_initializing', 
                           '_tracking_disabled', '_ref_link_data', '_supero_context'] and
                not getattr(self, '_initializing', False) and
                not getattr(self, '_tracking_disabled', False)):
                
                # Extra safety check - make sure _pending_field_updates is actually a set
                if isinstance(self._pending_field_updates, set):
                    self._pending_field_updates.add(name)
        except Exception:
            # If anything goes wrong with tracking, don't fail the attribute assignment
            # Just skip the tracking - the attribute was already set above
            pass

    # ========================================================================
    # SUPERO FLUENT API METHODS
    # ========================================================================

    @classmethod
    def create(cls, name: str, parent=None, **kwargs):
        """
        Fluent API: Create and optionally save object in one call.
        
        Args:
            name: Object name (required)
            parent: Optional parent object
            **kwargs: Additional attributes to set
            
        Returns:
            Created object instance (saved if Supero context is set)
            
        Example:
            # With Supero context:
            org = Supero.quickstart("acme")
            Project = org.get_schema("Project")
            project = Project.create(name="Alpha", status="active")
            
            # Or via parent:
            project = org.domain.create_project("Alpha", status="active")
        """
        obj = cls(name=name, **kwargs)
        if parent:
            obj.set_parent(parent)
        
        # Auto-save if _supero_context is set
        if hasattr(cls, '_supero_context') and cls._supero_context:
            saved_obj = cls._supero_context.save(obj)
            # Note: save() now handles method injection
            return saved_obj
        
        return obj

    @classmethod
    def find(cls, **filters):
        """
        Fluent API: Query objects with filters.
        
        Args:
            **filters: Filter conditions (supports Django-style lookups)
            
        Returns:
            QueryBuilder instance for chaining, or list if simple query
            
        Example:
            # Simple query:
            projects = Project.find(status="active")
            
            # Advanced query:
            projects = Project.find(status="active").limit(10).all()
            
            # Django-style lookups:
            projects = Project.find(priority__gte=5)
            projects = Project.find(name__contains="Alpha")
        """
        if not hasattr(cls, '_supero_context') or not cls._supero_context:
            raise RuntimeError(
                f"No Supero context set for {cls.__name__}. "
                f"Use: org = Supero.quickstart('name') then Project = org.get_schema('Project')"
            )
        
        if not filters:
            return cls.query()
        return cls.query().filter(**filters).all()

    @classmethod
    def find_one(cls, **filters):
        """
        Fluent API: Find single object matching filters.
        
        Args:
            **filters: Filter conditions
            
        Returns:
            First matching object or None
            
        Example:
            project = Project.find_one(name="Alpha")
            lead = User.find_one(role="lead")
        """
        if not hasattr(cls, '_supero_context') or not cls._supero_context:
            raise RuntimeError(f"No Supero context set for {cls.__name__}")
        
        return cls.query().filter(**filters).first()

    @classmethod
    def query(cls):
        """
        Start a query builder for advanced queries.
        
        Returns:
            QueryBuilder instance
            
        Example:
            projects = (Project.query()
                .filter(status="active")
                .filter(priority__gte=5)
                .order_by("-created_at")
                .limit(10)
                .all())
        """
        if not hasattr(cls, '_supero_context') or not cls._supero_context:
            raise RuntimeError(f"No Supero context set for {cls.__name__}")
        
        from supero.query import QueryBuilder
        return QueryBuilder(cls, cls._supero_context)

    @classmethod
    def bulk_load(cls, uuids):
        """
        Load multiple objects by UUID in single request.
        
        Args:
            uuids: List of UUIDs to load
            
        Returns:
            List of objects
            
        Example:
            projects = Project.bulk_load(["uuid1", "uuid2", "uuid3"])
        """
        if not hasattr(cls, '_supero_context') or not cls._supero_context:
            raise RuntimeError(f"No Supero context set for {cls.__name__}")
        
        import inflection
        obj_type = inflection.underscore(cls.__name__).replace('_', '-')
        return cls._supero_context.api_lib.list_bulk(
            obj_type,
            uuids=uuids,
            detail=True
        )

    @classmethod
    def bulk_create(cls, objects_data):
        """
        Create multiple objects in batch.
        
        Args:
            objects_data: List of dicts with object attributes
            
        Returns:
            List of created objects
            
        Example:
            projects = Project.bulk_create([
                {"name": "A", "status": "active"},
                {"name": "B", "status": "pending"}
            ])
        """
        if not hasattr(cls, '_supero_context') or not cls._supero_context:
            raise RuntimeError(f"No Supero context set for {cls.__name__}")
        
        created = []
        for data in objects_data:
            obj = cls.create(**data)
            created.append(obj)
        
        return created

    @classmethod
    def bulk_update(cls, objects, updates):
        """
        Update multiple objects with same changes.
        
        Args:
            objects: List of objects to update
            updates: Dict of attributes to update
            
        Example:
            projects = Project.find(status="pending")
            Project.bulk_update(projects, {"status": "active"})
        """
        for obj in objects:
            for key, value in updates.items():
                setattr(obj, key, value)
            obj.save()
        
        return objects

    @classmethod
    def bulk_save(cls, objects):
        """
        Save multiple objects.
        
        Args:
            objects: List of objects to save
            
        Example:
            for project in projects:
                project.status = "completed"
            Project.bulk_save(projects)
        """
        for obj in objects:
            obj.save()
        
        return objects

    @classmethod
    def bulk_delete(cls, objects=None, uuids=None):
        """
        Delete multiple objects.
        
        Args:
            objects: List of objects to delete
            uuids: List of UUIDs to delete
            
        Example:
            Project.bulk_delete(old_projects)
            Project.bulk_delete(uuids=["uuid1", "uuid2"])
        """
        if objects:
            for obj in objects:
                obj.delete()
        elif uuids:
            import inflection
            obj_type = inflection.underscore(cls.__name__).replace('_', '-')
            for uuid in uuids:
                cls._supero_context.api_lib._object_delete(obj_type, id=uuid)

    def save(self):
        """
        Fluent API: Save this object (create or update).
        
        Returns:
            Saved object with updated fields
            
        Example:
            project.status = "completed"
            project.save()
        """
        if not hasattr(self.__class__, '_supero_context') or not self.__class__._supero_context:
            raise RuntimeError(f"No Supero context set for {self.__class__.__name__}")
        
        return self.__class__._supero_context.save(self)

    def delete(self):
        """
        Fluent API: Delete this object.
        
        Returns:
            True if successful
            
        Example:
            old_project.delete()
        """
        if not hasattr(self.__class__, '_supero_context') or not self.__class__._supero_context:
            raise RuntimeError(f"No Supero context set for {self.__class__.__name__}")
        
        return self.__class__._supero_context.delete(self)

    def refresh(self):
        """
        Fluent API: Reload this object from server.
        
        Returns:
            Refreshed object
            
        Example:
            project.refresh()
        """
        if not hasattr(self.__class__, '_supero_context') or not self.__class__._supero_context:
            raise RuntimeError(f"No Supero context set for {self.__class__.__name__}")
        
        return self.__class__._supero_context.refresh(self)

    def update(self):
        """
        Context manager for batch updates.
        
        Returns:
            Self for use as context manager
            
        Example:
            with project.update() as p:
                p.status = "active"
                p.priority = 1
                # Auto-saves on exit
        """
        return self

    def __enter__(self):
        """Enter context manager."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager and auto-save."""
        if exc_type is None:
            self.save()

    def _validate_field_constraint(self, field_name: str, value: Any):
        """Validate a field value against its constraints."""
        if field_name not in self._CONSTRAINTS:
            return

        constraints = self._CONSTRAINTS[field_name]
        field_type = constraints.get('type')

        # String constraints
        if field_type == 'string' and isinstance(value, str):
            min_len = constraints.get('min-length')
            max_len = constraints.get('max-length')
            pattern = constraints.get('pattern')

            if min_len and len(value) < min_len:
                raise ValueError(
                    f"Field '{field_name}': value too short (min {min_len} chars, got {len(value)})"
                )

            if max_len and len(value) > max_len:
                raise ValueError(
                    f"Field '{field_name}': value too long (max {max_len} chars, got {len(value)})"
                )

            if pattern:
                import re
                if not re.match(pattern, value):
                    raise ValueError(
                        f"Field '{field_name}': value doesn't match pattern {pattern}"
                    )

        # Numeric constraints
        elif field_type in ['int', 'float'] and isinstance(value, (int, float)):
            min_val = constraints.get('min-value')
            max_val = constraints.get('max-value')
            range_val = constraints.get('range')

            if min_val is not None and value < min_val:
                raise ValueError(f"Field '{field_name}': value {value} below minimum {min_val}")

            if max_val is not None and value > max_val:
                raise ValueError(f"Field '{field_name}': value {value} above maximum {max_val}")

            if range_val:
                # Parse range like "[1-5]"
                import re
                match = re.match(r'^\[(\d+)-(\d+)\]$', range_val)
                if match:
                    range_min, range_max = int(match.group(1)), int(match.group(2))
                    if not (range_min <= value <= range_max):
                        raise ValueError(
                            f"Field '{field_name}': value {value} outside range {range_val}"
                        )


    def get_source_type(self) -> str:
        """Get the value of source_type."""
        return self.source_type

    def set_source_type(self, value: str):
        """Set the value of source_type."""
        self.source_type = value

    def is_set_source_type(self) -> bool:
        """Check if source_type was explicitly set."""
        return self.source_type is not None

    def get_file_path(self) -> str:
        """Get the value of file_path."""
        return self.file_path

    def set_file_path(self, value: str):
        """Set the value of file_path."""
        self.file_path = value

    def is_set_file_path(self) -> bool:
        """Check if file_path was explicitly set."""
        return self.file_path is not None

    def get_file_format(self) -> str:
        """Get the value of file_format."""
        return self.file_format

    def set_file_format(self, value: str):
        """Set the value of file_format."""
        self.file_format = value

    def is_set_file_format(self) -> bool:
        """Check if file_format was explicitly set."""
        return self.file_format is not None

    def get_s3_bucket(self) -> str:
        """Get the value of s3_bucket."""
        return self.s3_bucket

    def set_s3_bucket(self, value: str):
        """Set the value of s3_bucket."""
        self.s3_bucket = value

    def is_set_s3_bucket(self) -> bool:
        """Check if s3_bucket was explicitly set."""
        return self.s3_bucket is not None

    def get_s3_region(self) -> str:
        """Get the value of s3_region."""
        return self.s3_region

    def set_s3_region(self, value: str):
        """Set the value of s3_region."""
        self.s3_region = value

    def is_set_s3_region(self) -> bool:
        """Check if s3_region was explicitly set."""
        return self.s3_region is not None

    def get_aws_access_key_id(self) -> str:
        """Get the value of aws_access_key_id."""
        return self.aws_access_key_id

    def set_aws_access_key_id(self, value: str):
        """Set the value of aws_access_key_id."""
        self.aws_access_key_id = value

    def is_set_aws_access_key_id(self) -> bool:
        """Check if aws_access_key_id was explicitly set."""
        return self.aws_access_key_id is not None

    def get_aws_secret_access_key(self) -> str:
        """Get the value of aws_secret_access_key."""
        return self.aws_secret_access_key

    def set_aws_secret_access_key(self, value: str):
        """Set the value of aws_secret_access_key."""
        self.aws_secret_access_key = value

    def is_set_aws_secret_access_key(self) -> bool:
        """Check if aws_secret_access_key was explicitly set."""
        return self.aws_secret_access_key is not None

    def get_gcs_bucket(self) -> str:
        """Get the value of gcs_bucket."""
        return self.gcs_bucket

    def set_gcs_bucket(self, value: str):
        """Set the value of gcs_bucket."""
        self.gcs_bucket = value

    def is_set_gcs_bucket(self) -> bool:
        """Check if gcs_bucket was explicitly set."""
        return self.gcs_bucket is not None

    def get_gcs_credentials_json(self) -> str:
        """Get the value of gcs_credentials_json."""
        return self.gcs_credentials_json

    def set_gcs_credentials_json(self, value: str):
        """Set the value of gcs_credentials_json."""
        self.gcs_credentials_json = value

    def is_set_gcs_credentials_json(self) -> bool:
        """Check if gcs_credentials_json was explicitly set."""
        return self.gcs_credentials_json is not None

    def get_sftp_host(self) -> str:
        """Get the value of sftp_host."""
        return self.sftp_host

    def set_sftp_host(self, value: str):
        """Set the value of sftp_host."""
        self.sftp_host = value

    def is_set_sftp_host(self) -> bool:
        """Check if sftp_host was explicitly set."""
        return self.sftp_host is not None

    def get_sftp_port(self) -> int:
        """Get the value of sftp_port."""
        return self.sftp_port

    def set_sftp_port(self, value: int):
        """Set the value of sftp_port."""
        self.sftp_port = value

    def is_set_sftp_port(self) -> bool:
        """Check if sftp_port was explicitly set."""
        return self.sftp_port is not None

    def get_sftp_username(self) -> str:
        """Get the value of sftp_username."""
        return self.sftp_username

    def set_sftp_username(self, value: str):
        """Set the value of sftp_username."""
        self.sftp_username = value

    def is_set_sftp_username(self) -> bool:
        """Check if sftp_username was explicitly set."""
        return self.sftp_username is not None

    def get_sftp_password(self) -> str:
        """Get the value of sftp_password."""
        return self.sftp_password

    def set_sftp_password(self, value: str):
        """Set the value of sftp_password."""
        self.sftp_password = value

    def is_set_sftp_password(self) -> bool:
        """Check if sftp_password was explicitly set."""
        return self.sftp_password is not None

    def get_sftp_private_key(self) -> str:
        """Get the value of sftp_private_key."""
        return self.sftp_private_key

    def set_sftp_private_key(self, value: str):
        """Set the value of sftp_private_key."""
        self.sftp_private_key = value

    def is_set_sftp_private_key(self) -> bool:
        """Check if sftp_private_key was explicitly set."""
        return self.sftp_private_key is not None

    def get_url(self) -> str:
        """Get the value of url."""
        return self.url

    def set_url(self, value: str):
        """Set the value of url."""
        self.url = value

    def is_set_url(self) -> bool:
        """Check if url was explicitly set."""
        return self.url is not None

    def get_csv_delimiter(self) -> str:
        """Get the value of csv_delimiter."""
        return self.csv_delimiter

    def set_csv_delimiter(self, value: str):
        """Set the value of csv_delimiter."""
        self.csv_delimiter = value

    def is_set_csv_delimiter(self) -> bool:
        """Check if csv_delimiter was explicitly set."""
        return self.csv_delimiter is not None

    def get_csv_quote_char(self) -> str:
        """Get the value of csv_quote_char."""
        return self.csv_quote_char

    def set_csv_quote_char(self, value: str):
        """Set the value of csv_quote_char."""
        self.csv_quote_char = value

    def is_set_csv_quote_char(self) -> bool:
        """Check if csv_quote_char was explicitly set."""
        return self.csv_quote_char is not None

    def get_csv_has_header(self) -> bool:
        """Get the value of csv_has_header."""
        return self.csv_has_header

    def set_csv_has_header(self, value: bool):
        """Set the value of csv_has_header."""
        self.csv_has_header = value

    def is_set_csv_has_header(self) -> bool:
        """Check if csv_has_header was explicitly set."""
        return self.csv_has_header is not None

    def get_csv_encoding(self) -> str:
        """Get the value of csv_encoding."""
        return self.csv_encoding

    def set_csv_encoding(self, value: str):
        """Set the value of csv_encoding."""
        self.csv_encoding = value

    def is_set_csv_encoding(self) -> bool:
        """Check if csv_encoding was explicitly set."""
        return self.csv_encoding is not None

    def get_csv_skip_rows(self) -> int:
        """Get the value of csv_skip_rows."""
        return self.csv_skip_rows

    def set_csv_skip_rows(self, value: int):
        """Set the value of csv_skip_rows."""
        self.csv_skip_rows = value

    def is_set_csv_skip_rows(self) -> bool:
        """Check if csv_skip_rows was explicitly set."""
        return self.csv_skip_rows is not None

    def get_excel_sheet(self) -> str:
        """Get the value of excel_sheet."""
        return self.excel_sheet

    def set_excel_sheet(self, value: str):
        """Set the value of excel_sheet."""
        self.excel_sheet = value

    def is_set_excel_sheet(self) -> bool:
        """Check if excel_sheet was explicitly set."""
        return self.excel_sheet is not None

    def get_json_records_path(self) -> str:
        """Get the value of json_records_path."""
        return self.json_records_path

    def set_json_records_path(self, value: str):
        """Set the value of json_records_path."""
        self.json_records_path = value

    def is_set_json_records_path(self) -> bool:
        """Check if json_records_path was explicitly set."""
        return self.json_records_path is not None

    def get_archive_after_processing(self) -> bool:
        """Get the value of archive_after_processing."""
        return self.archive_after_processing

    def set_archive_after_processing(self, value: bool):
        """Set the value of archive_after_processing."""
        self.archive_after_processing = value

    def is_set_archive_after_processing(self) -> bool:
        """Check if archive_after_processing was explicitly set."""
        return self.archive_after_processing is not None

    def get_archive_path(self) -> str:
        """Get the value of archive_path."""
        return self.archive_path

    def set_archive_path(self, value: str):
        """Set the value of archive_path."""
        self.archive_path = value

    def is_set_archive_path(self) -> bool:
        """Check if archive_path was explicitly set."""
        return self.archive_path is not None



    # ========================================================================
    # END-POINTS QUERY METHODS
    # ========================================================================

    @classmethod
    def get_end_points(cls):
        """Get all configured end_points for this object type."""
        return [ep.copy() for ep in cls._end_points]

    @classmethod
    def get_end_point(cls, type=None, name=None, cloud=None, operation=None, enabled_only=True):
        """
        Query specific end-point by criteria.
        
        Args:
            type: End-point type (database, streaming, cache, search, blob-storage, vector-db)
            name: Technology name (mongo, kafka, redis, pinecone, etc.)
            cloud: Cloud environment (private, platform, public, hybrid)
            operation: Operation name (create, read, update, delete, search, similarity_search)
            enabled_only: Only return enabled end_points
        
        Returns:
            Matching end-point dict or None
        """
        for ep in cls._end_points:
            if enabled_only and not ep.get('enabled', True):
                continue
            if type and ep.get('type') != type:
                continue
            if name and ep.get('name') != name:
                continue
            if cloud and cloud not in ep.get('cloud', []):
                continue
            if operation and operation not in ep.get('operations', []):
                continue
            return ep.copy()
        return None

    @classmethod
    def get_end_points_by_type(cls, ep_type, enabled_only=True):
        """Get all end_points of a specific type."""
        return [
            ep.copy() for ep in cls._end_points 
            if ep.get('type') == ep_type and (not enabled_only or ep.get('enabled', True))
        ]

    @classmethod
    def get_end_points_by_cloud(cls, cloud, enabled_only=True):
        """Get all end_points available in a specific cloud."""
        return [
            ep.copy() for ep in cls._end_points 
            if cloud in ep.get('cloud', []) and (not enabled_only or ep.get('enabled', True))
        ]

    @classmethod
    def supports_operation(cls, operation, ep_type=None):
        """Check if this object type supports an operation."""
        for ep in cls._end_points:
            if not ep.get('enabled', True):
                continue
            if ep_type and ep.get('type') != ep_type:
                continue
            if operation in ep.get('operations', []):
                return True
        return False

    @classmethod
    def get_primary_end_point(cls, ep_type=None):
        """Get the primary (highest priority) end-point of a type."""
        candidates = cls._end_points
        if ep_type:
            candidates = [ep for ep in candidates if ep.get('type') == ep_type]
        
        candidates = [ep for ep in candidates if ep.get('enabled', True)]
        
        if not candidates:
            return None
        
        # Sort by priority (lower number = higher priority)
        candidates.sort(key=lambda x: x.get('priority', 999))
        return candidates[0].copy()

    @classmethod
    def supports_vector_search(cls):
        """Check if this object type has vector database support."""
        return cls.get_end_point(type="vector-db") is not None

    @classmethod
    def get_vector_config(cls):
        """Get vector database configuration."""
        vector_ep = cls.get_end_point(type="vector-db")
        return vector_ep.get('config', {}) if vector_ep else {}

    # ========================================================================
    # INDEX QUERY METHODS
    # ========================================================================

    @classmethod
    def get_indexes(cls):
        """Get all index definitions for this object type."""
        return {k: v.copy() for k, v in cls._indexes.items()}

    @classmethod
    def get_index(cls, name):
        """Get specific index definition by name."""
        idx = cls._indexes.get(name)
        return idx.copy() if idx else None

    @classmethod
    def get_index_names(cls):
        """Get all index names."""
        return list(cls._indexes.keys())

    @classmethod
    def get_indexes_for_attribute(cls, attr_name):
        """Get all indexes that include a specific attribute."""
        result = []
        for idx_name, idx_def in cls._indexes.items():
            fields = idx_def.get('fields', [])
            if any(f.get('name') == attr_name for f in fields):
                result.append(idx_name)
        return result

    @classmethod
    def get_compound_indexes(cls):
        """Get all compound indexes (indexes with multiple fields)."""
        return {
            k: v.copy() for k, v in cls._indexes.items()
            if v.get('type') == 'compound'
        }

    @classmethod
    def get_simple_indexes(cls):
        """Get all simple indexes (single field)."""
        return {
            k: v.copy() for k, v in cls._indexes.items()
            if v.get('type') == 'simple'
        }

    # ========================================================================
    # INSTANCE ROUTING METHODS
    # ========================================================================

    def get_routing_info(self):
        """
        Get routing information for this instance.
        Useful for sharding, partitioning, cloud selection.
        """
        return {
            'object_type': getattr(self, 'obj_type', self.__class__.__name__),
            'uuid': getattr(self, 'uuid', None),
            'cloud': self._determine_cloud(),
            'partition_key': self._get_partition_key(),
            'endpoints': self.get_end_points()
        }

    def _determine_cloud(self):
        """Determine cloud environment based on instance data."""
        if hasattr(self, 'country'):
            country = getattr(self, 'country')
            if country in ['US', 'Canada']:
                return 'private'
        return 'platform'

    def _get_partition_key(self):
        """Get partition key value for this instance."""
        for ep in self._end_points:
            partition_key_name = ep.get('config', {}).get('partition_key')
            if partition_key_name:
                return getattr(self, partition_key_name, getattr(self, 'uuid', ''))
        return getattr(self, 'uuid', '')

    # ========================================================================
    # PENDING FIELD TRACKING METHODS
    # ========================================================================

    def disable_pending_tracking(self):
        """Temporarily disable pending field tracking."""
        self._tracking_disabled = True
    
    def enable_pending_tracking(self):
        """Re-enable pending field tracking."""
        self._tracking_disabled = False
    
    def is_pending_tracking_enabled(self):
        """Check if pending field tracking is currently enabled."""
        return (hasattr(self, '_pending_field_updates') and 
                not getattr(self, '_initializing', False) and
                not getattr(self, '_tracking_disabled', False))

    def clear_pending_updates(self):
        """Clear the pending field updates set."""
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.clear()
    
    def get_pending_updates(self):
        """Get the set of pending field updates."""
        return getattr(self, '_pending_field_updates', set()).copy()
    
    def has_pending_updates(self):
        """Check if there are any pending updates."""
        return bool(getattr(self, '_pending_field_updates', set()))

    # ========================================================================
    # SERIALIZATION METHODS
    # ========================================================================

    @staticmethod
    def _parse_datetime(value):
        """Parse a datetime string or return datetime object as-is."""
        if value is None:
            return None
        if isinstance(value, datetime):
            return value
        if isinstance(value, str):
            try:
                return datetime.fromisoformat(value.replace('Z', '+00:00'))
            except:
                try:
                    return datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
                except:
                    return value
        return value

    @staticmethod
    def _format_datetime(value):
        """Format a datetime object to ISO string."""
        if value is None:
            return None
        if isinstance(value, datetime):
            return value.isoformat()
        return str(value)

    def to_dict(self, include_all_fields=True, validate=False):
        """
        Converts the object to a dictionary, including nested objects.
        ENHANCED: Automatically converts datetime objects to ISO strings.
        
        Args:
            include_all_fields: If True, include all non-None fields. 
                              If False, only include pending field updates + mandatory system fields
        """
        data = {}
        
        if include_all_fields or not hasattr(self, '_pending_field_updates'):
            for py_key, json_key in self._py_to_json_map.items():
                value = getattr(self, py_key, None)
                if value is not None:
                    if hasattr(value, 'to_dict'):
                        data[json_key] = value.to_dict()
                    elif isinstance(value, datetime):
                        data[json_key] = self._format_datetime(value)
                    elif isinstance(value, list):
                        converted_list = []
                        for item in value:
                            if hasattr(item, 'to_dict'):
                                converted_list.append(item.to_dict())
                            elif isinstance(item, datetime):
                                converted_list.append(self._format_datetime(item))
                            else:
                                converted_list.append(item)
                        data[json_key] = converted_list
                    else:
                        data[json_key] = value
        else:
            fields_to_include = set(self._pending_field_updates)
            mandatory_for_updates = {'uuid', 'name', 'fq_name', 'parent_uuid', 'obj_type', 'parent_type'}
            
            for field in mandatory_for_updates:
                if field in self._py_to_json_map:
                    value = getattr(self, field, None)
                    if value is not None:
                        if field == 'parent_uuid' or (value and value != ''):
                            fields_to_include.add(field)
            
            for py_key in fields_to_include:
                if py_key in self._py_to_json_map:
                    json_key = self._py_to_json_map[py_key]
                    value = getattr(self, py_key, None)
                    
                    if hasattr(value, 'to_dict'):
                        data[json_key] = value.to_dict()
                    elif isinstance(value, datetime):
                        data[json_key] = self._format_datetime(value)
                    elif isinstance(value, list):
                        converted_list = []
                        for item in value:
                            if hasattr(item, 'to_dict'):
                                converted_list.append(item.to_dict())
                            elif isinstance(item, datetime):
                                converted_list.append(self._format_datetime(item))
                            else:
                                converted_list.append(item)
                        data[json_key] = converted_list
                    else:
                        data[json_key] = value
        
        # NEW: Embed link_data into references before returning
        if hasattr(self, '_ref_link_data') and self._ref_link_data:
            for py_key, json_key in self._py_to_json_map.items():
                if py_key.endswith('_refs') and json_key in data:
                    # Get the refs list from data
                    refs = data[json_key]
                    if isinstance(refs, list):
                        # Embed link_data into each reference
                        refs_with_link_data = []
                        for ref in refs:
                            if isinstance(ref, dict):
                                ref_copy = ref.copy()
                                uuid = ref_copy.get('uuid')
                                if uuid and uuid in self._ref_link_data:
                                    ref_copy['link_data'] = self._ref_link_data[uuid]
                                refs_with_link_data.append(ref_copy)
                            else:
                                refs_with_link_data.append(ref)
                        data[json_key] = refs_with_link_data
        
        if validate:
            self._validate_mandatory_fields()
        
        return data 

    def to_dict_for_update(self):
        """Converts only the modified fields + mandatory system fields to a dictionary for partial updates."""
        return self.to_dict(include_all_fields=False)

    def _validate_mandatory_fields(self):
        """
        Validate that all mandatory fields are set with non-None values.
        
        Called by to_dict(validate=True) before CREATE operations.
        
        Raises:
            ValueError: If any mandatory fields are missing or None
        """
        missing = []
        
        # Check each field in type metadata
        if hasattr(self, '_type_metadata'):
            for field_name, metadata in self._type_metadata.items():
                if metadata.get('mandatory'):
                    value = getattr(self, field_name, None)
                    
                    # Check if value is None or empty
                    if value is None:
                        missing.append(field_name)
                    # For strings, check if empty
                    elif isinstance(value, str) and not value.strip():
                        missing.append(field_name)
        
        # Raise error if any mandatory fields are missing
        if missing:
            raise ValueError(
                f"Cannot serialize {self.__class__.__name__}: "
                f"Missing mandatory fields: {', '.join(missing)}. "
                f"Please set these fields before calling to_dict(validate=True)."
            )

    @classmethod
    def _get_type_for_attribute(cls, py_key):
        """Get the type class for a given attribute."""
        type_info = cls._type_metadata.get(py_key)
        if not type_info:
            return None, False, False
            
        type_name = type_info.get('type')
        is_list = type_info.get('is_list', False)
        
        if not type_name:
            return None, False, False
            
        builtin_types = {
            'string': str, 'str': str, 'int': int, 'integer': int,
            'float': float, 'bool': bool, 'boolean': bool,
            'list': list, 'dict': dict, 'uuid': str, 'date': str, 'datetime': str
        }
        
        if type_name.lower() in builtin_types:
            return builtin_types[type_name.lower()], is_list, False
            
        try:
            import inflection
            import importlib
            snake_type_name = inflection.underscore(type_name)
            
            import_paths = [
                f'pymodel.enums.{snake_type_name}',
                f'pymodel.types.{snake_type_name}',
                f'pymodel.objects.{snake_type_name}',
            ]
            
            for i, import_path in enumerate(import_paths):
                try:
                    module = importlib.import_module(import_path)
                    type_class = getattr(module, type_name, None)
                    if type_class:
                        is_enum = (i == 0)
                        return type_class, is_list, is_enum
                except (ImportError, AttributeError):
                    continue
                    
        except Exception:
            pass
            
        return None, is_list, False

    @classmethod
    def _deserialize_value(cls, value, target_type, is_list=False, is_enum=False, field_name="unknown", type_name="unknown"):
        """Deserialize a value to the target type with STRICT type checking and datetime support."""
        if value is None:
            return [] if is_list else None
        
        if type_name.lower() in ['datetime', 'date']:
            if is_list:
                if not isinstance(value, list):
                    raise ObjectDeserializationError(
                        f"Expected list for datetime field '{field_name}', got {type(value).__name__}",
                        obj_type=cls.__name__, attribute=field_name, value=value
                    )
                return [cls._parse_datetime(item) for item in value]
            else:
                return cls._parse_datetime(value)
            
        builtin_types = {str, int, float, bool, list, dict}
        
        if is_list:
            if not isinstance(value, list):
                raise ObjectDeserializationError(
                    f"Expected list for field '{field_name}', got {type(value).__name__}",
                    obj_type=cls.__name__, attribute=field_name, value=value
                )
                
            if not value:
                return []
                
            if target_type is None:
                import inflection
                raise ObjectDeserializationError(
                    f"CRITICAL: Cannot deserialize list field '{field_name}' - type '{type_name}' not found. "
                    f"Check if pymodel.types.{inflection.underscore(type_name)}.py exists with class {type_name}.",
                    obj_type=cls.__name__, attribute=field_name, value=f"List with {len(value)} items"
                )
            
            if target_type in builtin_types:
                # Auto-coerce JSON strings to dict for json/map/dict list items
                if target_type == dict:
                    import json
                    coerced = []
                    for item in value:
                        if isinstance(item, str):
                            try:
                                parsed = json.loads(item)
                                coerced.append(parsed if isinstance(parsed, dict) else item)
                            except (json.JSONDecodeError, TypeError):
                                coerced.append(item)
                        else:
                            coerced.append(item)
                    return coerced
                return value
            elif hasattr(target_type, 'from_dict'):
                deserialized_items = []
                for i, item in enumerate(value):
                    try:
                        if is_enum:
                            if isinstance(item, str):
                                deserialized_items.append(target_type(item))
                            else:
                                raise ObjectDeserializationError(
                                    f"Expected string for enum list item {i} in field '{field_name}', got {type(item).__name__}",
                                    obj_type=cls.__name__, attribute=f"{field_name}[{i}]", value=item
                                )
                        else:
                            if isinstance(item, dict):
                                deserialized_items.append(target_type.from_dict(item))
                            else:
                                raise ObjectDeserializationError(
                                    f"Expected dict for custom type list item {i} in field '{field_name}', got {type(item).__name__}",
                                    obj_type=cls.__name__, attribute=f"{field_name}[{i}]", value=item
                                )
                    except Exception as e:
                        raise ObjectDeserializationError(
                            f"Failed to deserialize list item {i} in field '{field_name}' to {target_type.__name__}: {str(e)}",
                            obj_type=cls.__name__, attribute=f"{field_name}[{i}]", value=item, original_error=e
                        )
                return deserialized_items
            else:
                raise ObjectDeserializationError(
                    f"CRITICAL: Type '{type_name}' found for field '{field_name}' but has no from_dict() method.",
                    obj_type=cls.__name__, attribute=field_name, value=f"Type: {target_type}"
                )
        else:
            if target_type is None:
                if type_name not in ['string', 'int', 'bool', 'float']:
                    try:
                        import logging
                        logging.getLogger(__name__).warning(
                            f"Could not find type '{type_name}' for field '{field_name}' in {cls.__name__}."
                        )
                    except:
                        pass
                return value

            if target_type in builtin_types:
                # Auto-coerce JSON string to dict for json/map/dict fields
                if target_type == dict and isinstance(value, str):
                    try:
                        import json
                        parsed = json.loads(value)
                        if isinstance(parsed, dict):
                            return parsed
                    except (json.JSONDecodeError, TypeError):
                        pass
                return value   
            elif hasattr(target_type, 'from_dict'):
                try:
                    if is_enum:
                        if isinstance(value, str):
                            return target_type(value)
                        else:
                            raise ObjectDeserializationError(
                                f"Expected string for enum field '{field_name}', got {type(value).__name__}",
                                obj_type=cls.__name__, attribute=field_name, value=value
                            )
                    else:
                        if isinstance(value, dict):
                            return target_type.from_dict(value)
                        else:
                            raise ObjectDeserializationError(
                                f"Expected dict for custom type field '{field_name}', got {type(value).__name__}",
                                obj_type=cls.__name__, attribute=field_name, value=value
                            )
                except Exception as e:
                    raise ObjectDeserializationError(
                        f"Failed to deserialize field '{field_name}' to {target_type.__name__}: {str(e)}",
                        obj_type=cls.__name__, attribute=field_name, value=value, original_error=e
                    )
            else:
                return value

    @classmethod
    def _find_field_value(cls, py_key, data):
        """Find a field value in data using multiple naming conventions."""
        import inflection
        field_variations = [
            py_key,
            py_key.replace('_', '-'),
            inflection.dasherize(py_key),
            inflection.underscore(py_key),
        ]
        
        field_variations = list(dict.fromkeys(field_variations))
        
        for variation in field_variations:
            if variation in data:
                return variation, data[variation]
        
        return None, None

    @classmethod
    def from_dict(cls, data):
        """
        Creates an instance from a dictionary, handling nested objects.
        ENHANCED: Automatically converts datetime strings to datetime objects.
        ENHANCED: Derives name from fq_name if missing, validates if both present.
        FLEXIBLE MODE: Accepts multiple field naming conventions.
        """
        if data is None:
            return cls.from_empty()
            
        if not isinstance(data, dict):
            raise ObjectDeserializationError(
                f"Expected dict or None for {cls.__name__} deserialization, got {type(data).__name__}",
                obj_type=cls.__name__, value=data
            )

        if not data:
            return cls.from_empty()

        # NEW: Auto-derive name from fq_name if missing, or validate if both present
        if 'fq_name' in data:
            fq_name = data.get('fq_name')
            if fq_name and isinstance(fq_name, list) and len(fq_name) > 0:
                expected_name = fq_name[-1]
                
                if 'name' in data:
                    # Both present - validate they match
                    provided_name = data['name']
                    if provided_name != expected_name:
                        raise ObjectDeserializationError(
                            f"Name mismatch in {cls.__name__}: 'name' field is '{provided_name}' but "
                            f"fq_name[-1] is '{expected_name}'. They must match.",
                            obj_type=cls.__name__, value=data
                        )
                else:
                    # Only fq_name present - auto-derive name
                    data = data.copy()  # Don't modify original
                    data['name'] = expected_name

        temp_instance = cls.from_empty()
        init_args = {}
        back_refs = {}
        ref_link_data = {}  # NEW: Store extracted link_data
        
        processed_fields = set()
        deserialization_failures = []
        
        for json_key, value in data.items():
            try:
                # NEW: Extract link_data from references
                if json_key.endswith('_refs') or json_key.endswith('-refs'):
                    if isinstance(value, list):
                        # Check each reference for link_data
                        clean_refs = []
                        for ref in value:
                            if isinstance(ref, dict):
                                ref_copy = ref.copy()
                                # Extract and store link_data
                                if 'link_data' in ref_copy:
                                    uuid = ref_copy.get('uuid')
                                    if uuid:
                                        ref_link_data[uuid] = ref_copy.pop('link_data')
                                clean_refs.append(ref_copy)
                            else:
                                clean_refs.append(ref)
                        value = clean_refs
                
                if (json_key.endswith('_back_refs') or json_key.endswith('_refs') or '_back_refs' in json_key):
                    back_refs[json_key] = value
                    continue
                    
                py_key = None
                py_key = temp_instance._json_to_py_map.get(json_key)
                
                if not py_key:
                    import inflection
                    potential_py_key = inflection.underscore(json_key)
                    if potential_py_key in cls._type_metadata:
                        py_key = potential_py_key
                
                if not py_key and json_key in cls._type_metadata:
                    py_key = json_key
                
                if not py_key:
                    for metadata_py_key in cls._type_metadata.keys():
                        field_name_found, _ = cls._find_field_value(metadata_py_key, {json_key: value})
                        if field_name_found:
                            py_key = metadata_py_key
                            break
                
                if py_key in ['parent_type', 'obj_type']:
                    continue
                
                if py_key in processed_fields:
                    continue
                    
                if py_key:
                    processed_fields.add(py_key)
                    
                    type_info = cls._get_type_for_attribute(py_key)
                    if type_info:
                        target_type, is_list, is_enum = type_info
                        original_type_name = cls._type_metadata.get(py_key, {}).get('type', 'unknown')
                        try:
                            deserialized_value = cls._deserialize_value(
                                value, target_type, is_list, is_enum,
                                field_name=json_key, type_name=original_type_name
                            )
                            init_args[py_key] = deserialized_value
                        except Exception as e:
                            deserialization_failures.append(f"Field '{json_key}' (Python: '{py_key}'): {str(e)}")
                    else:
                        init_args[py_key] = value
                    
            except Exception:
                pass

        if deserialization_failures:
            detailed_error = (
                f"DESERIALIZATION FAILED for {cls.__name__}: Field conversion errors: "
                f"{'; '.join(deserialization_failures)}."
            )
            raise ObjectDeserializationError(
                detailed_error, obj_type=cls.__name__,
                attribute=deserialization_failures[0].split("'")[1] if deserialization_failures else None,
                value=data, original_error=Exception("Field conversion failures")
            )

        try:
            instance = cls(**init_args)
        except TypeError as e:
            detailed_error = (
                f"OBJECT CONSTRUCTION FAILED for {cls.__name__}: Constructor rejected arguments. "
                f"Provided args: {list(init_args.keys())}. Error: {str(e)}."
            )
            raise ObjectDeserializationError(
                detailed_error, obj_type=cls.__name__, value=init_args, original_error=e
            )
        except Exception as e:
            detailed_error = f"OBJECT CONSTRUCTION FAILED for {cls.__name__}: {str(e)}"
            raise ObjectDeserializationError(
                detailed_error, obj_type=cls.__name__, value=init_args, original_error=e
            )
        
        # NEW: Attach extracted link_data to instance
        if ref_link_data:
            instance._ref_link_data = ref_link_data
        
        for ref_name, ref_value in back_refs.items():
            try:
                setattr(instance, ref_name, ref_value)
            except Exception:
                pass


        return instance

    @classmethod
    def from_mandatory(cls, source_type: str,
        file_path: str,
        file_format: str):
        """Creates an instance with only mandatory fields."""
        mandatory_args = {k: v for k, v in locals().items() if k != 'cls'}
        return cls(**mandatory_args)

    @classmethod
    def from_empty(cls):
        """Creates an empty instance with no fields set, providing defaults for mandatory fields."""
        return cls(source_type="", file_path="", file_format="")

csv_file_config_type=CsvFileConfigType
CsvFileConfigType=CsvFileConfigType
CsvFileConfigType=CsvFileConfigType
csv_file_config_type=CsvFileConfigType
