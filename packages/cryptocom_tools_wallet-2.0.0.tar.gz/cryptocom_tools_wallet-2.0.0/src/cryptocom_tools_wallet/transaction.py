"""
Transaction lifecycle management.

This module provides:
- TransactionManager: Full transaction lifecycle handling
- TxStatus: Transaction status enum
- TxResult: Transaction result model
"""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Callable, Protocol, runtime_checkable

from pydantic import BaseModel, Field
from web3 import Web3

if TYPE_CHECKING:
    from .signer import SignerManager


@runtime_checkable
class ChainConfigProtocol(Protocol):
    """Protocol defining required chain configuration interface."""

    @property
    def rpc_url(self) -> str:
        """RPC endpoint URL."""
        ...

    @property
    def chain_id(self) -> int:
        """Chain ID."""
        ...

    @property
    def supports_eip1559(self) -> bool:
        """Whether chain supports EIP-1559."""
        ...

    def get_explorer_tx_url(self, tx_hash: str) -> str:
        """Get block explorer URL for transaction."""
        ...


class TxStatus(str, Enum):
    """Transaction status states."""

    PENDING = "pending"
    SUBMITTED = "submitted"
    CONFIRMING = "confirming"
    CONFIRMED = "confirmed"
    FAILED = "failed"
    REVERTED = "reverted"


class TxResult(BaseModel):
    """Result of a transaction operation."""

    status: TxStatus = Field(description="Current transaction status")
    tx_hash: str | None = Field(default=None, description="Transaction hash")
    block_number: int | None = Field(default=None, description="Block number when confirmed")
    gas_used: int | None = Field(default=None, description="Actual gas used")
    error: str | None = Field(default=None, description="Error message if failed")
    explorer_url: str | None = Field(default=None, description="Block explorer URL")


class TransactionManager:
    """
    Manages the full transaction lifecycle.

    Handles:
    - Gas estimation with buffer
    - Nonce management
    - Transaction signing and submission
    - Confirmation waiting
    - Status tracking

    Example:
        ```python
        from web3 import Web3
        from cryptocom_tools_wallet import SignerManager, TransactionManager

        signer = SignerManager.from_env()
        tx_manager = TransactionManager(chain_config, signer)

        result = tx_manager.send_transaction(
            to="0x...",
            value=Web3.to_wei(1, "ether"),
        )
        print(result.explorer_url)
        ```
    """

    def __init__(
        self,
        chain: ChainConfigProtocol,
        signer: SignerManager,
        gas_buffer_percent: int = 20,
        timeout_seconds: int = 120,
    ):
        """
        Initialize transaction manager.

        Args:
            chain: Chain configuration (must implement ChainConfigProtocol).
            signer: Signer for transaction signing.
            gas_buffer_percent: Buffer to add to gas estimate (default 20%).
            timeout_seconds: Timeout for confirmation waiting (default 120s).
        """
        self.chain = chain
        self.signer = signer
        self.gas_buffer = gas_buffer_percent
        self.timeout = timeout_seconds
        self._web3: Web3 | None = None
        self._nonce_cache: int | None = None

    @property
    def web3(self) -> Web3:
        """Get or create Web3 instance."""
        if self._web3 is None:
            self._web3 = Web3(Web3.HTTPProvider(self.chain.rpc_url))
        return self._web3

    def _get_next_nonce(self) -> int:
        """Get next nonce, handling pending transactions."""
        address = self.web3.to_checksum_address(self.signer.address)
        pending_nonce = self.web3.eth.get_transaction_count(address, "pending")
        if self._nonce_cache is None or pending_nonce > self._nonce_cache:
            self._nonce_cache = pending_nonce
        else:
            self._nonce_cache += 1
        return self._nonce_cache

    def estimate_gas(self, to: str, value: int = 0, data: bytes = b"") -> int:
        """
        Estimate gas for a transaction.

        Args:
            to: Recipient address.
            value: Value in wei.
            data: Transaction data.

        Returns:
            Estimated gas with buffer applied.
        """
        from_addr = self.web3.to_checksum_address(self.signer.address)
        to_addr = self.web3.to_checksum_address(to)
        estimate = self.web3.eth.estimate_gas(
            {
                "from": from_addr,
                "to": to_addr,
                "value": self.web3.to_wei(value, "wei"),
                "data": data,
            }
        )
        return int(estimate * (1 + self.gas_buffer / 100))

    def send_transaction(
        self,
        to: str,
        value: int = 0,
        data: bytes = b"",
        gas: int | None = None,
        on_status_change: Callable[[TxStatus, TxResult], None] | None = None,
    ) -> TxResult:
        """
        Send a transaction with full lifecycle management.

        Args:
            to: Recipient address.
            value: Value in wei to send.
            data: Transaction data (for contract calls).
            gas: Gas limit (estimated if not provided).
            on_status_change: Callback for status updates.

        Returns:
            TxResult with final status and transaction details.
        """
        result = TxResult(status=TxStatus.PENDING)

        def update_status(status: TxStatus, **kwargs):
            result.status = status
            for k, v in kwargs.items():
                setattr(result, k, v)
            if on_status_change:
                on_status_change(status, result)

        try:
            # Estimate gas if not provided
            gas_limit = gas or self.estimate_gas(to, value, data)

            # Get nonce
            nonce = self._get_next_nonce()

            # Build transaction
            tx = {
                "from": self.signer.address,
                "to": self.web3.to_checksum_address(to),
                "value": value,
                "data": data,
                "gas": gas_limit,
                "nonce": nonce,
                "chainId": self.chain.chain_id,
            }

            # Add gas pricing (EIP-1559 or legacy)
            if self.chain.supports_eip1559:
                block = self.web3.eth.get_block("latest")
                base_fee = block.get("baseFeePerGas", 0)
                if base_fee:
                    tx["maxFeePerGas"] = base_fee * 2
                    tx["maxPriorityFeePerGas"] = self.web3.to_wei(2, "gwei")
                else:
                    tx["gasPrice"] = self.web3.eth.gas_price
            else:
                tx["gasPrice"] = self.web3.eth.gas_price

            # Sign and submit
            signed_tx = self.signer.sign_transaction(tx)
            tx_hash = self.web3.eth.send_raw_transaction(signed_tx)

            update_status(
                TxStatus.SUBMITTED,
                tx_hash=tx_hash.hex(),
                explorer_url=self.chain.get_explorer_tx_url(tx_hash.hex()),
            )

            # Wait for confirmation
            update_status(TxStatus.CONFIRMING)

            receipt = self.web3.eth.wait_for_transaction_receipt(tx_hash, timeout=self.timeout)

            if receipt["status"] == 1:
                update_status(
                    TxStatus.CONFIRMED,
                    block_number=receipt["blockNumber"],
                    gas_used=receipt["gasUsed"],
                )
            else:
                update_status(TxStatus.REVERTED, error="Transaction reverted")

            return result

        except Exception as e:
            update_status(TxStatus.FAILED, error=str(e))
            return result


__all__ = [
    "ChainConfigProtocol",
    "TxStatus",
    "TxResult",
    "TransactionManager",
]
