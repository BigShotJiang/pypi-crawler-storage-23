"""
Crypto.com Tools - Wallet Package

Wallet management tools for Crypto.com blockchain operations.
Uses CDPTool from cryptocom-tools-core for LangChain/LangGraph compatibility.

Key Features:
- Wallet creation via CDP API
- Secure private key management (SignerManager)
- Transaction lifecycle management (TransactionManager)
- Framework-agnostic state management

Example:
    ```python
    from cryptocom_tools_wallet import SignerManager, TransactionManager

    # Load signer from environment
    signer = SignerManager.from_env("PRIVATE_KEY")
    print(signer.address)

    # Or generate a new signer
    signer = SignerManager.generate()
    ```
"""

from cryptocom_tools_wallet.create import CreateWalletTool
from cryptocom_tools_wallet.signer import PrivateKeySigner, SignerManager
from cryptocom_tools_wallet.state import (
    WalletCredentials,
    WalletInfo,
    WalletState,
)
from cryptocom_tools_wallet.transaction import (
    ChainConfigProtocol,
    TransactionManager,
    TxResult,
    TxStatus,
)

__version__ = "0.1.0"

__all__ = [
    # Signer
    "SignerManager",
    "PrivateKeySigner",
    # Transaction
    "ChainConfigProtocol",
    "TransactionManager",
    "TxStatus",
    "TxResult",
    # State management
    "WalletState",
    "WalletInfo",
    "WalletCredentials",
    # Tools
    "CreateWalletTool",
]
