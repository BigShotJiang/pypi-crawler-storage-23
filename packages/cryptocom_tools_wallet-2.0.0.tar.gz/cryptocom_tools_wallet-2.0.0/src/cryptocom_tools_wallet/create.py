"""
Wallet creation tool for Crypto.com blockchain operations.

Uses CDPTool from cryptocom-tools-core for LangChain/LangGraph compatibility.
"""

from typing import Optional

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel, Field

from .state import WalletState


class CreateWalletInput(BaseModel):
    """Input schema for CreateWalletTool (no parameters needed)."""

    pass


class CreateWalletTool(CDPTool):
    """
    Tool for creating new blockchain wallets.

    Creates a new wallet using the Crypto.com Developer Platform
    and optionally registers it in the provided wallet state.

    Example:
        tool = CreateWalletTool(api_key="your-cdp-key")
        result = tool.invoke({})
    """

    name: str = "create_wallet"
    description: str = "Create a new blockchain wallet and return its address and private key"
    args_schema: type[BaseModel] = CreateWalletInput  # type: ignore[assignment]

    # Injected dependency (excluded from LLM schema)
    state: Optional[WalletState] = Field(default=None, exclude=True)

    def _run(self) -> str:  # type: ignore[override]
        """
        Create a new wallet.

        Returns:
            String description of created wallet with address and private key
        """
        try:
            from crypto_com_developer_platform_client import Wallet

            response = Wallet.create_wallet()

            # Validate response structure
            if not isinstance(response, dict):
                return "Error: Invalid response from CDP client"

            if response.get("status") != "Success":
                error_msg = response.get("error", "Unknown error")
                return f"Error: CDP wallet creation failed: {error_msg}"

            data = response.get("data", {})
            if "address" not in data or "privateKey" not in data:
                return "Error: Missing address or private key in response"

            address = self._to_checksum_address(data["address"])
            private_key = data["privateKey"]

            # Register in state if available
            if self.state:
                self.state.register_wallet(address)

            return f"Wallet created! Address: {address}, Private Key: {private_key}"

        except Exception as e:
            return f"Error: Failed to create wallet: {e}"

    @staticmethod
    def _to_checksum_address(address: str) -> str:
        """Convert address to checksum format."""
        try:
            from web3 import Web3

            if Web3.is_address(address):
                return Web3.to_checksum_address(address)
        except ImportError:
            pass
        return address
