"""
Secure signer management for wallet operations.

This module provides SignerManager for secure handling of private keys
and transaction signing.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from eth_account import Account
from eth_account.messages import encode_defunct

if TYPE_CHECKING:
    from eth_account.signers.local import LocalAccount


class SignerManager:
    """
    Secure signer management for wallet operations.

    Handles:
    - Private key loading (from env, file, or direct)
    - Address derivation
    - Message and transaction signing

    Example:
        ```python
        from cryptocom_tools_wallet import SignerManager

        # Load from environment variable
        signer = SignerManager.from_env()
        print(signer.address)

        # Generate new signer
        signer = SignerManager.generate()
        print(signer.address)

        # Direct key (use with caution!)
        signer = SignerManager(private_key="0x...")
        ```
    """

    def __init__(self, private_key: str | None = None):
        """
        Initialize signer with optional private key.

        Args:
            private_key: Hex-encoded private key (0x... or raw hex).
                        If None, signer operations will raise ValueError.
        """
        self._account: LocalAccount | None = None
        if private_key:
            # Ensure key starts with 0x
            if not private_key.startswith("0x"):
                private_key = f"0x{private_key}"
            self._account = Account.from_key(private_key)

    @classmethod
    def from_env(cls, env_var: str = "PRIVATE_KEY") -> SignerManager:
        """
        Load signer from environment variable.

        Args:
            env_var: Name of environment variable containing the private key.

        Returns:
            SignerManager instance with loaded key.

        Raises:
            ValueError: If environment variable is not set.
        """
        private_key = os.getenv(env_var)
        if not private_key:
            raise ValueError(
                f"Environment variable {env_var} not set. "
                "Set it with your private key or use SignerManager.generate()."
            )
        return cls(private_key=private_key)

    @classmethod
    def from_keyfile(cls, keyfile_path: str, password: str | None = None) -> SignerManager:
        """
        Load signer from encrypted keystore file.

        Args:
            keyfile_path: Path to the keystore JSON file.
            password: Password to decrypt the keyfile.

        Returns:
            SignerManager instance with loaded key.
        """
        with open(keyfile_path) as f:
            keyfile_content = f.read()

        private_key = Account.decrypt(keyfile_content, password or "")
        return cls(private_key=private_key.hex())

    @classmethod
    def generate(cls) -> SignerManager:
        """
        Generate a new random signer.

        Returns:
            SignerManager instance with new private key.

        Warning:
            Store the private key securely! It cannot be recovered.
        """
        account = Account.create()
        return cls(private_key=account.key.hex())

    @property
    def address(self) -> str:
        """
        Get the signer's Ethereum address.

        Returns:
            Checksummed Ethereum address.

        Raises:
            ValueError: If no signer is loaded.
        """
        if not self._account:
            raise ValueError("No signer loaded. Use from_env() or generate().")
        return self._account.address

    @property
    def is_loaded(self) -> bool:
        """Check if a signer is loaded."""
        return self._account is not None

    def sign_message(self, message: str) -> str:
        """
        Sign a message with the signer's private key.

        Args:
            message: Plain text message to sign.

        Returns:
            Hex-encoded signature.

        Raises:
            ValueError: If no signer is loaded.
        """
        if not self._account:
            raise ValueError("No signer loaded")

        msg = encode_defunct(text=message)
        signed = self._account.sign_message(msg)
        return signed.signature.hex()

    def sign_transaction(self, tx: dict) -> bytes:
        """
        Sign a transaction.

        Args:
            tx: Transaction dictionary with fields like
                'to', 'value', 'gas', 'gasPrice', 'nonce', 'chainId'.

        Returns:
            Raw signed transaction bytes.

        Raises:
            ValueError: If no signer is loaded.
        """
        if not self._account:
            raise ValueError("No signer loaded")

        signed = self._account.sign_transaction(tx)
        return signed.raw_transaction

    def __repr__(self) -> str:
        if self._account:
            return f"<SignerManager(address={self.address})>"
        return "<SignerManager(not loaded)>"


class PrivateKeySigner:
    """
    EOA signer using a private key.

    Implements the Signer protocol from cryptocom_tools_core.

    Example:
        signer = PrivateKeySigner(
            private_key="0x...",
            rpc_url="https://evm.cronos.org"
        )
        tx_hash = signer.send_transaction({
            "to": "0x...",
            "value": 1000000000000000000,
            "data": "0x"
        })
    """

    def __init__(
        self,
        private_key: str,
        rpc_url: str = "https://evm.cronos.org",
        chain_id: int = 25,
    ):
        from web3 import Web3

        # Ensure 0x prefix
        if not private_key.startswith("0x"):
            private_key = f"0x{private_key}"

        self._account: LocalAccount = Account.from_key(private_key)
        self._web3 = Web3(Web3.HTTPProvider(rpc_url))
        self._chain_id = chain_id

    @classmethod
    def from_env(
        cls,
        env_var: str = "PRIVATE_KEY",
        rpc_url: str = "https://evm.cronos.org",
        chain_id: int = 25,
    ) -> PrivateKeySigner:
        """
        Build a signer from an environment variable.

        Args:
            env_var: Environment variable that stores the private key.
            rpc_url: RPC endpoint used for transaction submission.
            chain_id: Chain ID used for signing transactions.

        Raises:
            ValueError: If the environment variable is missing.
        """
        private_key = os.getenv(env_var)
        if not private_key:
            raise ValueError(f"Environment variable {env_var} is not set")
        return cls(private_key=private_key, rpc_url=rpc_url, chain_id=chain_id)

    @property
    def address(self) -> str:
        return self._account.address

    @property
    def chain_id(self) -> int:
        return self._chain_id

    def send_transaction(self, tx: dict[str, object]) -> str:
        """Sign and broadcast transaction."""
        # Build full transaction
        # Use self._account.address directly (ChecksumAddress type) for web3 calls
        full_tx = {
            "from": self._account.address,
            "nonce": self._web3.eth.get_transaction_count(self._account.address),
            "gas": tx.get("gas", 200000),
            "gasPrice": tx.get("gasPrice") or self._web3.eth.gas_price,
            "chainId": self._chain_id,
            "to": tx["to"],
            "value": tx.get("value", 0),
            "data": tx.get("data", "0x"),
        }

        # Sign and send
        signed = self._account.sign_transaction(full_tx)
        tx_hash = self._web3.eth.send_raw_transaction(signed.raw_transaction)
        return tx_hash.hex()


__all__ = ["SignerManager", "PrivateKeySigner"]
