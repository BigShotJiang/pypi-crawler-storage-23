"""
Wallet state management for Crypto.com tools.

This module provides state management for wallets without any framework dependencies.
The state can be persisted and passed between tools.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class WalletInfo:
    """Information about a single wallet."""

    address: str
    """The wallet address in checksum format."""

    labels: List[str] = field(default_factory=list)
    """Optional labels for the wallet (e.g., 'smart-account')."""

    def __post_init__(self):
        """Validate wallet info after initialization."""
        if not self.address:
            raise ValueError("Wallet address cannot be empty")
        # Ensure address is lowercase for consistency
        self.address = self.address.lower()


@dataclass
class WalletState:
    """
    Wallet state container for managing multiple wallets.

    This class manages the wallet registry and active wallet selection
    without any framework dependencies. It can be serialized and passed
    between different tools and frameworks.
    """

    active_wallet: Optional[str] = None
    """The currently active wallet address."""

    wallet_registry: Dict[str, WalletInfo] = field(default_factory=dict)
    """Registry of all wallets in the session, keyed by address."""

    def register_wallet(self, address: str, labels: Optional[List[str]] = None) -> None:
        """
        Register a new wallet in the state.

        Args:
            address: The wallet address to register
            labels: Optional labels for the wallet
        """
        address = address.lower()
        wallet_info = WalletInfo(address=address, labels=labels or [])
        self.wallet_registry[address] = wallet_info

        # Set as active if no active wallet
        if not self.active_wallet:
            self.active_wallet = address

    def unregister_wallet(self, address: str) -> bool:
        """
        Remove a wallet from the registry.

        Args:
            address: The wallet address to remove

        Returns:
            True if wallet was removed, False if not found
        """
        address = address.lower()
        if address in self.wallet_registry:
            del self.wallet_registry[address]

            # If this was the active wallet, select another
            if self.active_wallet == address:
                if self.wallet_registry:
                    # Set first available wallet as active
                    self.active_wallet = next(iter(self.wallet_registry.keys()))
                else:
                    self.active_wallet = None

            return True
        return False

    def set_active_wallet(self, address: str) -> bool:
        """
        Set the active wallet.

        Args:
            address: The wallet address to make active

        Returns:
            True if wallet was set as active, False if not found
        """
        address = address.lower()
        if address in self.wallet_registry:
            self.active_wallet = address
            return True
        return False

    def get_active_wallet(self) -> Optional[str]:
        """
        Get the currently active wallet address.

        Returns:
            The active wallet address or None if no wallet is active
        """
        return self.active_wallet

    def get_wallet_info(self, address: str) -> Optional[WalletInfo]:
        """
        Get information about a specific wallet.

        Args:
            address: The wallet address to look up

        Returns:
            WalletInfo if found, None otherwise
        """
        return self.wallet_registry.get(address.lower())

    def list_wallets(self) -> List[WalletInfo]:
        """
        List all registered wallets.

        Returns:
            List of WalletInfo objects
        """
        return list(self.wallet_registry.values())

    def has_wallet(self, address: str) -> bool:
        """
        Check if a wallet is registered.

        Args:
            address: The wallet address to check

        Returns:
            True if wallet is registered, False otherwise
        """
        return address.lower() in self.wallet_registry

    def add_wallet_label(self, address: str, label: str) -> bool:
        """
        Add a label to a wallet.

        Args:
            address: The wallet address
            label: The label to add

        Returns:
            True if label was added, False if wallet not found
        """
        wallet_info = self.get_wallet_info(address)
        if wallet_info and label not in wallet_info.labels:
            wallet_info.labels.append(label)
            return True
        return False

    def remove_wallet_label(self, address: str, label: str) -> bool:
        """
        Remove a label from a wallet.

        Args:
            address: The wallet address
            label: The label to remove

        Returns:
            True if label was removed, False if wallet or label not found
        """
        wallet_info = self.get_wallet_info(address)
        if wallet_info and label in wallet_info.labels:
            wallet_info.labels.remove(label)
            return True
        return False

    def to_dict(self) -> dict:
        """
        Convert state to dictionary for serialization.

        Returns:
            Dictionary representation of the state
        """
        return {
            "active_wallet": self.active_wallet,
            "wallet_registry": {
                addr: {"address": info.address, "labels": info.labels}
                for addr, info in self.wallet_registry.items()
            },
        }

    @classmethod
    def from_dict(cls, data: dict) -> "WalletState":
        """
        Create WalletState from dictionary.

        Args:
            data: Dictionary with state data

        Returns:
            WalletState instance
        """
        state = cls()
        state.active_wallet = data.get("active_wallet")

        registry = data.get("wallet_registry", {})
        for addr, info in registry.items():
            wallet_info = WalletInfo(address=info["address"], labels=info.get("labels", []))
            state.wallet_registry[addr] = wallet_info

        return state


@dataclass
class WalletCredentials:
    """
    Wallet credentials returned when creating a new wallet.

    WARNING: The private key should be stored securely and never logged or exposed.
    """

    address: str
    """The wallet address in checksum format."""

    private_key: str
    """The wallet's private key (SENSITIVE - handle with care)."""

    def __post_init__(self):
        """Validate credentials after initialization."""
        if not self.address:
            raise ValueError("Wallet address cannot be empty")
        if not self.private_key:
            raise ValueError("Private key cannot be empty")
        # Ensure address is lowercase for consistency
        self.address = self.address.lower()

    def __repr__(self) -> str:
        """Safe representation that doesn't expose the private key."""
        return f"WalletCredentials(address='{self.address}', private_key='***')"

    def __str__(self) -> str:
        """Safe string representation that doesn't expose the private key."""
        return f"Wallet: {self.address}"
