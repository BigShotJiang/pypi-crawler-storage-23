# cryptocom-tools-wallet

Wallet management tools for Crypto.com blockchain operations. Part of the Crypto.com tools ecosystem.

## Overview

This package provides framework-agnostic wallet management tools for blockchain operations. It handles wallet creation, storage, and state management without any dependencies on specific AI frameworks like LangChain or LangGraph.

## Features

- Create new wallets
- Manage multiple wallets
- Switch between active wallets
- Delete wallets from session
- Get wallet balances
- Wallet state management

## Installation

```bash
pip install cryptocom-tools-wallet
```

For development:

```bash
pip install -e .
```

## Usage

### Basic Wallet Operations

```python
from cryptocom_tools_wallet import CreateWalletTool, WalletState

# Initialize wallet state
state = WalletState()

# Create wallet tool with explicit dependency injection
create_tool = CreateWalletTool()

# Create a new wallet (returns WalletCredentials)
result = create_tool.execute(state=state)
print(f"Created wallet: {result.address}")
```

### Wallet State Management

```python
from cryptocom_tools_wallet import WalletState, WalletRegistry

# Initialize state
state = WalletState()

# Register a wallet
state.register_wallet("0x123...")

# Set active wallet
state.set_active_wallet("0x123...")

# Get active wallet
active = state.get_active_wallet()

# List all wallets
wallets = state.list_wallets()
```

## Framework Adapters

This package is designed to work with framework adapters from `cryptocom-tool-adapters`:

```python
# With LangGraph adapter
from cryptocom_tool_adapters import to_langgraph_tool

create_wallet_lg = to_langgraph_tool(
    create_tool,
    state_extractor=lambda s: {"state": s.get("wallet_state")}
)

# With OpenAI SDK adapter
from cryptocom_tool_adapters import to_openai_function

create_wallet_openai = to_openai_function(
    create_tool,
    context={"state": wallet_state}
)
```

## Development

```bash
# Install with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Type checking
basedpyright

# Linting
ruff check .

# Formatting
black .
```

## License

MIT