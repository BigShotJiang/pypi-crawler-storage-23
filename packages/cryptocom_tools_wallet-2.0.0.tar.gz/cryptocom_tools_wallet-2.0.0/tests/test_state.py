"""Tests for wallet state management."""

import pytest

from cryptocom_tools_wallet import WalletCredentials, WalletInfo, WalletState


class TestWalletState:
    """Test WalletState functionality."""

    def test_init_empty_state(self):
        """Test initializing empty wallet state."""
        state = WalletState()
        assert state.active_wallet is None
        assert len(state.wallet_registry) == 0
        assert state.list_wallets() == []

    def test_register_wallet(self):
        """Test registering a new wallet."""
        state = WalletState()
        address = "0x123ABC"

        state.register_wallet(address)

        # Check wallet is registered
        assert state.has_wallet(address)
        assert state.has_wallet(address.lower())  # Should be case-insensitive
        assert len(state.wallet_registry) == 1

        # Check it's set as active
        assert state.active_wallet == address.lower()

    def test_register_wallet_with_labels(self):
        """Test registering a wallet with labels."""
        state = WalletState()
        address = "0x123ABC"
        labels = ["smart-account", "test"]

        state.register_wallet(address, labels)

        wallet_info = state.get_wallet_info(address)
        assert wallet_info is not None
        assert wallet_info.labels == labels

    def test_multiple_wallets(self):
        """Test managing multiple wallets."""
        state = WalletState()
        addr1 = "0x111"
        addr2 = "0x222"
        addr3 = "0x333"

        state.register_wallet(addr1)
        state.register_wallet(addr2)
        state.register_wallet(addr3)

        # Check all registered
        assert len(state.list_wallets()) == 3
        assert state.has_wallet(addr1)
        assert state.has_wallet(addr2)
        assert state.has_wallet(addr3)

        # First wallet should be active
        assert state.active_wallet == addr1

    def test_set_active_wallet(self):
        """Test setting active wallet."""
        state = WalletState()
        addr1 = "0x111"
        addr2 = "0x222"

        state.register_wallet(addr1)
        state.register_wallet(addr2)

        # Switch to second wallet
        result = state.set_active_wallet(addr2)
        assert result is True
        assert state.active_wallet == addr2

        # Try setting non-existent wallet
        result = state.set_active_wallet("0x999")
        assert result is False
        assert state.active_wallet == addr2  # Should remain unchanged

    def test_unregister_wallet(self):
        """Test removing a wallet."""
        state = WalletState()
        addr1 = "0x111"
        addr2 = "0x222"

        state.register_wallet(addr1)
        state.register_wallet(addr2)
        state.set_active_wallet(addr2)

        # Remove non-active wallet
        result = state.unregister_wallet(addr1)
        assert result is True
        assert not state.has_wallet(addr1)
        assert state.active_wallet == addr2

        # Remove active wallet
        state.register_wallet("0x333")
        result = state.unregister_wallet(addr2)
        assert result is True
        assert state.active_wallet == "0x333"  # Should switch to remaining wallet

    def test_unregister_last_wallet(self):
        """Test removing the last wallet."""
        state = WalletState()
        address = "0x123"

        state.register_wallet(address)
        result = state.unregister_wallet(address)

        assert result is True
        assert len(state.wallet_registry) == 0
        assert state.active_wallet is None

    def test_add_remove_labels(self):
        """Test adding and removing wallet labels."""
        state = WalletState()
        address = "0x123"

        state.register_wallet(address)

        # Add label
        result = state.add_wallet_label(address, "smart-account")
        assert result is True

        wallet_info = state.get_wallet_info(address)
        assert wallet_info is not None
        assert "smart-account" in wallet_info.labels

        # Add duplicate label (should not duplicate)
        result = state.add_wallet_label(address, "smart-account")
        assert result is False
        assert wallet_info.labels.count("smart-account") == 1

        # Remove label
        result = state.remove_wallet_label(address, "smart-account")
        assert result is True
        assert "smart-account" not in wallet_info.labels

        # Remove non-existent label
        result = state.remove_wallet_label(address, "non-existent")
        assert result is False

    def test_serialization(self):
        """Test state serialization and deserialization."""
        state = WalletState()
        state.register_wallet("0x111", ["label1"])
        state.register_wallet("0x222", ["label2", "label3"])
        state.set_active_wallet("0x222")

        # Serialize
        data = state.to_dict()
        assert data["active_wallet"] == "0x222"
        assert len(data["wallet_registry"]) == 2

        # Deserialize
        new_state = WalletState.from_dict(data)
        assert new_state.active_wallet == state.active_wallet
        assert len(new_state.wallet_registry) == len(state.wallet_registry)
        wallet_info_111 = new_state.get_wallet_info("0x111")
        wallet_info_222 = new_state.get_wallet_info("0x222")
        assert wallet_info_111 is not None
        assert wallet_info_222 is not None
        assert wallet_info_111.labels == ["label1"]
        assert wallet_info_222.labels == ["label2", "label3"]


class TestWalletInfo:
    """Test WalletInfo dataclass."""

    def test_wallet_info_init(self):
        """Test WalletInfo initialization."""
        info = WalletInfo(address="0x123ABC")
        assert info.address == "0x123abc"  # Should be lowercase
        assert info.labels == []

    def test_wallet_info_with_labels(self):
        """Test WalletInfo with labels."""
        labels = ["smart-account", "test"]
        info = WalletInfo(address="0x123", labels=labels)
        assert info.labels == labels

    def test_wallet_info_validation(self):
        """Test WalletInfo validation."""
        with pytest.raises(ValueError, match="address cannot be empty"):
            WalletInfo(address="")


class TestWalletCredentials:
    """Test WalletCredentials dataclass."""

    def test_credentials_init(self):
        """Test WalletCredentials initialization."""
        creds = WalletCredentials(address="0x123ABC", private_key="0xprivatekey")
        assert creds.address == "0x123abc"  # Should be lowercase
        assert creds.private_key == "0xprivatekey"

    def test_credentials_validation(self):
        """Test WalletCredentials validation."""
        with pytest.raises(ValueError, match="address cannot be empty"):
            WalletCredentials(address="", private_key="0xkey")

        with pytest.raises(ValueError, match="Private key cannot be empty"):
            WalletCredentials(address="0x123", private_key="")

    def test_credentials_repr_hides_key(self):
        """Test that repr doesn't expose private key."""
        creds = WalletCredentials(address="0x123", private_key="0xsecretkey")
        repr_str = repr(creds)
        assert "0xsecretkey" not in repr_str
        assert "***" in repr_str
        assert "0x123" in repr_str

    def test_credentials_str_hides_key(self):
        """Test that str doesn't expose private key."""
        creds = WalletCredentials(address="0x123", private_key="0xsecretkey")
        str_repr = str(creds)
        assert "0xsecretkey" not in str_repr
        assert "0x123" in str_repr
