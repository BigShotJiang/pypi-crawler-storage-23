"""Tests for wallet signer helpers."""

import pytest

from cryptocom_tools_wallet import PrivateKeySigner


def test_private_key_signer_from_env_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    """from_env raises when key is missing."""
    monkeypatch.delenv("PRIVATE_KEY", raising=False)
    with pytest.raises(ValueError, match="PRIVATE_KEY"):
        PrivateKeySigner.from_env()


def test_private_key_signer_from_env_loads_key(monkeypatch: pytest.MonkeyPatch) -> None:
    """from_env builds signer with explicit chain config."""
    monkeypatch.setenv(
        "TEST_PRIVATE_KEY",
        "0x59c6995e998f97a5a0044966f094538e3d84f4f3f8a4f8f6d5e0b6b8b8b8b8b8",
    )

    signer = PrivateKeySigner.from_env(
        env_var="TEST_PRIVATE_KEY",
        rpc_url="https://evm-t3.cronos.org",
        chain_id=338,
    )

    assert signer.chain_id == 338
    assert signer.address.startswith("0x")
    assert len(signer.address) == 42
