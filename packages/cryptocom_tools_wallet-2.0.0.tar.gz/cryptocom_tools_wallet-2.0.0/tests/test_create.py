"""
Tests for the CreateWalletTool.

This module tests the wallet creation tool with various scenarios including
successful creation, error handling, state management, and edge cases.
"""

from unittest.mock import MagicMock, patch

import pytest

from cryptocom_tools_wallet import (
    CreateWalletTool,
    WalletCredentials,
    WalletState,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def mock_wallet_class():
    """Create a mock for the Wallet class from CDP client."""
    with patch("crypto_com_developer_platform_client.Wallet") as mock:
        mock.create_wallet.return_value = {
            "status": "Success",
            "data": {
                "address": "0x1234567890abcdef1234567890abcdef12345678",
                "privateKey": "0xprivatekey123456789",
            },
        }
        yield mock


@pytest.fixture
def wallet_state() -> WalletState:
    """Create a fresh WalletState instance."""
    return WalletState()


@pytest.fixture
def create_wallet_tool(wallet_state) -> CreateWalletTool:
    """Create a CreateWalletTool with state management."""
    return CreateWalletTool(state=wallet_state)


@pytest.fixture
def create_wallet_tool_no_state() -> CreateWalletTool:
    """Create a CreateWalletTool without state management."""
    return CreateWalletTool(state=None)


# =============================================================================
# Basic Functionality Tests
# =============================================================================


def test_create_wallet_success(create_wallet_tool, mock_wallet_class):
    """Test successful wallet creation."""
    result = create_wallet_tool.invoke({})

    assert "Wallet created!" in result
    assert "0x1234567890abcdef1234567890abcdef12345678" in result.lower()
    assert "0xprivatekey123456789" in result

    # Verify CDP client was called
    mock_wallet_class.create_wallet.assert_called_once()


def test_create_wallet_registers_in_state(create_wallet_tool, wallet_state, mock_wallet_class):
    """Test that created wallet is registered in state."""
    result = create_wallet_tool.invoke({})

    assert "Wallet created!" in result
    # Check wallet is registered in state (address normalized to lowercase)
    assert wallet_state.has_wallet("0x1234567890abcdef1234567890abcdef12345678".lower())
    # Check it becomes the active wallet (first wallet)
    assert wallet_state.get_active_wallet() == "0x1234567890abcdef1234567890abcdef12345678".lower()


def test_create_wallet_without_state(create_wallet_tool_no_state, mock_wallet_class):
    """Test wallet creation without state management."""
    result = create_wallet_tool_no_state.invoke({})

    assert "Wallet created!" in result
    assert "0x1234567890abcdef1234567890abcdef12345678" in result.lower()
    assert "0xprivatekey123456789" in result


def test_create_wallet_result_string_format():
    """Test CreateWalletTool result string formatting."""
    # The tool returns a string directly, verify the format
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.return_value = {
            "status": "Success",
            "data": {
                "address": "0xabc123",
                "privateKey": "0xprivkey",
            },
        }
        tool = CreateWalletTool()
        result = tool.invoke({})
        assert "Wallet created! Address: 0xabc123, Private Key: 0xprivkey" in result

        # Failure case
        mock_wallet.create_wallet.return_value = {
            "status": "Error",
            "error": "Connection failed",
        }
        error_result = tool.invoke({})
        assert "Error" in error_result
        assert "Connection failed" in error_result


# =============================================================================
# Error Handling Tests
# =============================================================================


def test_create_wallet_cdp_error_status(wallet_state):
    """Test handling of CDP error status."""
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.return_value = {
            "status": "Error",
            "error": "Service unavailable",
        }

        tool = CreateWalletTool(state=wallet_state)
        result = tool.invoke({})

        assert "Error" in result
        assert "Service unavailable" in result
        # Wallet should not be registered in state
        assert len(wallet_state.list_wallets()) == 0


def test_create_wallet_cdp_exception(wallet_state):
    """Test handling of CDP client exception."""
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.side_effect = Exception("Network error")

        tool = CreateWalletTool(state=wallet_state)
        result = tool.invoke({})

        assert "Error" in result
        assert "Network error" in result


def test_create_wallet_invalid_response_format(wallet_state):
    """Test handling of invalid response format."""
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.return_value = "not a dict"

        tool = CreateWalletTool(state=wallet_state)
        result = tool.invoke({})

        assert "Error" in result
        assert "Invalid response" in result


def test_create_wallet_missing_data_fields(wallet_state):
    """Test handling of missing fields in response."""
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.return_value = {
            "status": "Success",
            "data": {
                "address": "0x123",
                # Missing privateKey
            },
        }

        tool = CreateWalletTool(state=wallet_state)
        result = tool.invoke({})

        assert "Error" in result
        assert "Missing" in result or "private key" in result.lower()


# =============================================================================
# State Management Tests
# =============================================================================


def test_create_multiple_wallets_state_management(wallet_state):
    """Test creating multiple wallets and state management."""
    addresses = [
        "0x1111111111111111111111111111111111111111",
        "0x2222222222222222222222222222222222222222",
        "0x3333333333333333333333333333333333333333",
    ]

    create_tool = CreateWalletTool(state=wallet_state)

    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        for i, addr in enumerate(addresses):
            mock_wallet.create_wallet.return_value = {
                "status": "Success",
                "data": {
                    "address": addr,
                    "privateKey": f"0xprivatekey{i}",
                },
            }

            result = create_tool.invoke({})
            assert "Wallet created!" in result
            assert addr in result

        # Verify all wallets are in state
        wallets = wallet_state.list_wallets()
        assert len(wallets) == 3

        # First wallet should be active
        assert wallet_state.get_active_wallet() == addresses[0].lower()


def test_wallet_state_persistence():
    """Test wallet state can be serialized and deserialized."""
    state = WalletState()
    state.register_wallet("0xabc123")
    state.register_wallet("0xdef456")
    state.set_active_wallet("0xdef456")

    # Serialize
    state_dict = state.to_dict()

    # Deserialize
    new_state = WalletState.from_dict(state_dict)

    assert new_state.has_wallet("0xabc123")
    assert new_state.has_wallet("0xdef456")
    assert new_state.get_active_wallet() == "0xdef456"


# =============================================================================
# Parameterized Tests
# =============================================================================


@pytest.mark.parametrize(
    "address,expected",
    [
        ("0xABC123", "0xABC123"),  # Tool returns address as-is from CDP
        ("0xabc123", "0xabc123"),  # Already lowercase
        ("abc123", "abc123"),  # No 0x prefix
    ],
)
def test_address_normalization(address, expected):
    """Test address normalization with different formats."""
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.return_value = {
            "status": "Success",
            "data": {
                "address": address,
                "privateKey": "0xkey",
            },
        }

        tool = CreateWalletTool()
        result = tool.invoke({})

        # Address should be in the result string
        assert expected in result


@pytest.mark.parametrize(
    "error_msg",
    [
        "Connection timeout",
        "Invalid API key",
        "Rate limit exceeded",
        "Internal server error",
    ],
)
def test_various_error_messages(error_msg):
    """Test handling of various error messages from CDP."""
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.return_value = {
            "status": "Error",
            "error": error_msg,
        }

        tool = CreateWalletTool()
        result = tool.invoke({})

        assert "Error" in result
        assert error_msg in result


# =============================================================================
# Tool Interface Tests
# =============================================================================


def test_tool_metadata():
    """Test tool metadata properties."""
    tool = CreateWalletTool()

    assert tool.name == "create_wallet"
    assert "wallet" in tool.description.lower()
    assert "private key" in tool.description.lower()


def test_tool_parameters_schema():
    """Test tool parameters schema."""
    from cryptocom_tools_wallet.create import CreateWalletInput

    tool = CreateWalletTool()
    # args_schema is the class, not instance
    assert tool.args_schema is CreateWalletInput
    schema = CreateWalletInput.model_json_schema()

    assert schema["type"] == "object"
    assert schema.get("properties", {}) == {}
    assert schema.get("required", []) == []


# =============================================================================
# Integration Tests with Other Tools
# =============================================================================


def test_create_wallet_with_balance_check(wallet_state, mock_wallet_class):
    """Test creating wallet and checking its balance (simulated)."""
    # Create wallet
    create_tool = CreateWalletTool(state=wallet_state)
    result = create_tool.invoke({})

    assert "Wallet created!" in result

    # Simulate balance check
    # This would normally use GetNativeBalanceTool
    active_wallet = wallet_state.get_active_wallet()
    assert active_wallet is not None

    # Mock balance check
    mock_balance_response = {
        "status": "Success",
        "data": {"balance": "0"},
    }
    # New wallets should have 0 balance
    assert mock_balance_response["data"]["balance"] == "0"


# =============================================================================
# Edge Cases
# =============================================================================


def test_create_wallet_empty_response():
    """Test handling of empty response from CDP."""
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.return_value = {}

        tool = CreateWalletTool()
        result = tool.invoke({})

        assert "Error" in result


def test_create_wallet_none_response():
    """Test handling of None response from CDP."""
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.return_value = None

        tool = CreateWalletTool()
        result = tool.invoke({})

        assert "Error" in result


def test_wallet_credentials_validation():
    """Test WalletCredentials validation."""
    # Valid credentials
    creds = WalletCredentials(
        address="0xABC123",
        private_key="0xprivkey",
    )
    assert creds.address == "0xabc123"  # Normalized to lowercase
    assert creds.private_key == "0xprivkey"

    # Test repr doesn't expose private key
    assert "***" in repr(creds)
    assert "0xprivkey" not in repr(creds)

    # Test str doesn't expose private key
    assert "0xabc123" in str(creds)
    assert "0xprivkey" not in str(creds)


def test_wallet_credentials_empty_validation():
    """Test WalletCredentials validation with empty values."""
    with pytest.raises(ValueError, match="address cannot be empty"):
        WalletCredentials(address="", private_key="key")

    with pytest.raises(ValueError, match="Private key cannot be empty"):
        WalletCredentials(address="0x123", private_key="")


# =============================================================================
# Mock and Monkeypatch Tests
# =============================================================================


def test_create_wallet_with_web3_checksum(monkeypatch):
    """Test address checksum conversion when web3 is available."""
    # Mock web3 module
    mock_web3 = MagicMock()
    mock_web3.is_address.return_value = True
    mock_web3.to_checksum_address.return_value = "0xChecksumAddress"

    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        with patch.dict("sys.modules", {"web3": MagicMock(Web3=mock_web3)}):
            mock_wallet.create_wallet.return_value = {
                "status": "Success",
                "data": {
                    "address": "0xlowercase",
                    "privateKey": "0xkey",
                },
            }

            tool = CreateWalletTool()
            result = tool.invoke({})

            assert "Wallet created!" in result
            # Address should be in the result
            assert "0x" in result


# =============================================================================
# Async Compatibility Test (for future)
# =============================================================================


def test_tool_is_synchronous():
    """Verify tool is synchronous (not async)."""
    tool = CreateWalletTool()
    # _run method should not be a coroutine
    import inspect

    assert not inspect.iscoroutinefunction(tool._run)
