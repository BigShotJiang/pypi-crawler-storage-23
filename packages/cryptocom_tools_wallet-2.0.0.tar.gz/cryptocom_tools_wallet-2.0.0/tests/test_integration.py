"""
Integration tests for wallet tools with other packages.

This module tests the integration of wallet tools with balance tools
from the cryptocom-tools-token package.
"""

from unittest.mock import patch

import pytest

from cryptocom_tools_wallet import (
    CreateWalletTool,
    WalletState,
)


@pytest.fixture
def wallet_state() -> WalletState:
    """Create a fresh wallet state."""
    return WalletState()


@pytest.fixture
def mock_wallet():
    """Mock the Wallet class from CDP client."""
    with patch("crypto_com_developer_platform_client.Wallet") as mock:
        mock.create_wallet.return_value = {
            "status": "Success",
            "data": {
                "address": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
                "privateKey": "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
            },
        }
        yield mock


def test_create_wallet_and_check_balance(mock_wallet, wallet_state):
    """Test creating a wallet and checking its balance."""
    # Import balance tool if available
    try:
        from cryptocom_tools_token import GetNativeBalanceTool
    except ImportError:
        pytest.skip("cryptocom-tools-token not installed")

    # Create wallet
    create_tool = CreateWalletTool(state=wallet_state)

    with patch("crypto_com_developer_platform_client.Wallet", mock_wallet):
        create_result = create_tool.invoke({})

    assert "Success" in create_result or "0x" in create_result

    # Check balance with mocked Token
    with patch("crypto_com_developer_platform_client.Token") as mock_token:
        mock_token.get_native_balance.return_value = {
            "status": "Success",
            "data": {"balance": "0"},
        }

        balance_tool = GetNativeBalanceTool()
        balance_result = balance_tool.invoke(
            {"address": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1"}
        )

        assert "0" in balance_result
        assert "WEI" in balance_result


def test_multiple_wallets_with_state_tracking(wallet_state):
    """Test creating multiple wallets and tracking them in state."""
    create_tool = CreateWalletTool(state=wallet_state)

    # Track created wallets
    created_addresses = []

    # Create 3 wallets with different addresses
    for i in range(3):
        with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
            mock_wallet.create_wallet.return_value = {
                "status": "Success",
                "data": {
                    "address": f"0x{i:040x}",
                    "privateKey": f"0xprivkey{i}",
                },
            }

            result = create_tool.invoke({})
            assert "Success" in result or "0x" in result
            created_addresses.append(f"0x{i:040x}".lower())

    # Verify all wallets are in state
    assert len(wallet_state.list_wallets()) == 3

    for addr in created_addresses:
        assert wallet_state.has_wallet(addr)

    # First wallet should be active
    assert wallet_state.get_active_wallet() == created_addresses[0]

    # Switch to second wallet
    assert wallet_state.set_active_wallet(created_addresses[1])
    assert wallet_state.get_active_wallet() == created_addresses[1]


def test_stateful_wallet_management_workflow(wallet_state):
    """Test a complete wallet management workflow."""
    create_tool = CreateWalletTool(state=wallet_state)

    # Create first wallet
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.return_value = {
            "status": "Success",
            "data": {
                "address": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
                "privateKey": "0xprivkey1",
            },
        }
        result1 = create_tool.invoke({})
        wallet1 = "0x742d35cc6634c0532925a3b844bc9e7595f0beb1"

    assert "Success" in result1 or "0x" in result1

    # Verify it's the active wallet
    assert wallet_state.get_active_wallet() == wallet1

    # Create second wallet with different address
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.return_value = {
            "status": "Success",
            "data": {
                "address": "0x9999999999999999999999999999999999999999",
                "privateKey": "0xprivkey999",
            },
        }
        result2 = create_tool.invoke({})
        wallet2 = "0x9999999999999999999999999999999999999999"

    assert "Success" in result2 or "0x" in result2

    # First wallet should still be active
    assert wallet_state.get_active_wallet() == wallet1

    # List all wallets
    wallets = wallet_state.list_wallets()
    assert len(wallets) == 2

    # Switch to second wallet
    assert wallet_state.set_active_wallet(wallet2)
    assert wallet_state.get_active_wallet() == wallet2

    # Delete first wallet
    assert wallet_state.unregister_wallet(wallet1)
    assert not wallet_state.has_wallet(wallet1)

    # Second wallet should still be active
    assert wallet_state.get_active_wallet() == wallet2

    # Verify only one wallet remains
    assert len(wallet_state.list_wallets()) == 1


def test_wallet_labels_and_metadata(wallet_state):
    """Test wallet labels and metadata management."""
    # Register wallet with labels
    wallet_state.register_wallet(
        address="0xabc123",
        labels=["main", "trading"],
    )

    # Get wallet info
    info = wallet_state.get_wallet_info("0xabc123")
    assert info is not None
    assert "main" in info.labels
    assert "trading" in info.labels

    # Add another label
    assert wallet_state.add_wallet_label("0xabc123", "defi")
    info = wallet_state.get_wallet_info("0xabc123")
    assert "defi" in info.labels

    # Remove a label
    assert wallet_state.remove_wallet_label("0xabc123", "trading")
    info = wallet_state.get_wallet_info("0xabc123")
    assert "trading" not in info.labels
    assert "main" in info.labels
    assert "defi" in info.labels


def test_state_serialization_and_recovery(wallet_state):
    """Test state can be serialized and recovered."""
    create_tool = CreateWalletTool(state=wallet_state)

    # Create wallet
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.return_value = {
            "status": "Success",
            "data": {
                "address": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
                "privateKey": "0xprivkey1",
            },
        }
        result = create_tool.invoke({})
        wallet_addr = "0x742d35cc6634c0532925a3b844bc9e7595f0beb1"

    assert "Success" in result or "0x" in result

    # Add labels
    wallet_state.add_wallet_label(wallet_addr, "primary")

    # Serialize state
    state_dict = wallet_state.to_dict()

    # Create new state from serialized data
    new_state = WalletState.from_dict(state_dict)

    # Verify state is preserved
    assert new_state.has_wallet(wallet_addr)
    assert new_state.get_active_wallet() == wallet_addr

    info = new_state.get_wallet_info(wallet_addr)
    assert info is not None
    assert "primary" in info.labels


def test_error_recovery_maintains_state(wallet_state):
    """Test that errors don't corrupt state."""
    create_tool = CreateWalletTool(state=wallet_state)

    # Create first wallet successfully
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.return_value = {
            "status": "Success",
            "data": {
                "address": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1",
                "privateKey": "0xprivkey1",
            },
        }
        result1 = create_tool.invoke({})
        wallet1 = "0x742d35cc6634c0532925a3b844bc9e7595f0beb1"

    assert "Success" in result1 or "0x" in result1

    # Simulate error on second wallet
    with patch("crypto_com_developer_platform_client.Wallet") as mock_wallet:
        mock_wallet.create_wallet.side_effect = Exception("Network error")
        result2 = create_tool.invoke({})

    assert "Error" in result2 or "error" in result2.lower()

    # State should still have first wallet
    assert len(wallet_state.list_wallets()) == 1
    assert wallet_state.has_wallet(wallet1)


def test_concurrent_wallet_operations(wallet_state):
    """Test concurrent operations on wallet state."""
    # This simulates multiple tools operating on the same state

    # Register multiple wallets quickly
    addresses = [f"0x{i:040x}" for i in range(10)]

    for addr in addresses:
        wallet_state.register_wallet(addr)

    # Verify all registered
    assert len(wallet_state.list_wallets()) == 10

    # Concurrent reads should work
    for addr in addresses:
        assert wallet_state.has_wallet(addr)

    # Switch active wallet multiple times
    for addr in addresses[::2]:  # Every other address
        assert wallet_state.set_active_wallet(addr)
        assert wallet_state.get_active_wallet() == addr
