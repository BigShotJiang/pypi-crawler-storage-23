class PayloopRequestInterceptedError(Exception):
    pass
