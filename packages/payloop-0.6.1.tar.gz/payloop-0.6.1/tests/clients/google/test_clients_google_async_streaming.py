import os

import pytest
from google import genai

from payloop import Payloop, PayloopRequestInterceptedError


@pytest.mark.integration
@pytest.mark.asyncio
async def test_google_async_streaming():
    if not os.environ.get("GOOGLE_API_KEY"):
        pytest.skip("GOOGLE_API_KEY not set")

    client = genai.Client()

    payloop = Payloop().google.register(client, stream=True)

    # Make sure registering the same client again does not cause an issue.
    payloop.google.register(client)

    # Test setting attribution.
    payloop.attribution(
        parent_id=123,
        parent_name="Abc",
        parent_uuid="95473da0-5d7a-435d-babf-d64c5dabe971",
        subsidiary_id=456,
        subsidiary_name="Def",
        subsidiary_uuid="b789eaf4-c925-4a79-85b1-34d270342353",
    )

    model_str = "gemini-2.0-flash"
    chunks = []

    async for chunk in client.aio.models.generate_content_stream(
        model=model_str,
        contents=[{"role": "user", "parts": [{"text": "What is 2+2?"}]}],
    ):
        try:
            print(chunk.candidates[0].content.parts[0].text)
            chunks.append(chunk)
        except IndexError:
            pass

    assert len(chunks) > 0

    for index, chunk in enumerate(chunks):
        assert chunk.response_id is not None
        assert len(chunk.candidates) > 0
        assert chunk.parts[0].text in "2 + 2 = 4\n 2 + 2 equals 4."
        assert (
            chunk.candidates[0].content.parts[0].text in "2 + 2 = 4\n 2 + 2 equals 4."
        )
        assert chunk.candidates[0].content.role == "model"
        assert chunk.model_version == model_str
        assert chunk.usage_metadata.prompt_token_count > 0
        if chunk.usage_metadata.candidates_token_count:
            assert chunk.usage_metadata.candidates_token_count > 0
            assert chunk.usage_metadata.total_token_count == (
                chunk.usage_metadata.prompt_token_count
                + chunk.usage_metadata.candidates_token_count
            )
        else:
            assert (
                chunk.usage_metadata.total_token_count
                == chunk.usage_metadata.prompt_token_count
            )

    payloop.sentinel.raise_if_irrelevant(True)

    with pytest.raises(PayloopRequestInterceptedError):
        async for _ in client.aio.models.generate_content_stream(
            model=model_str,
            contents="What is the capital of France?",
            config={"system_instruction": "Only answer questions related to code"},
        ):
            pass
