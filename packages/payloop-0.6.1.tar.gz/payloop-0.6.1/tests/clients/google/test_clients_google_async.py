import os

import pytest
from google import genai

from payloop import Payloop, PayloopRequestInterceptedError


@pytest.mark.integration
@pytest.mark.asyncio
async def test_google_async():
    if not os.environ.get("GOOGLE_API_KEY"):
        pytest.skip("GOOGLE_API_KEY not set")

    client = genai.Client()

    payloop = Payloop().google.register(client)

    # Make sure registering the same client again does not cause an issue.
    payloop.google.register(client)

    # Test setting attribution.
    payloop.attribution(
        parent_id=123,
        parent_name="Abc",
        parent_uuid="95473da0-5d7a-435d-babf-d64c5dabe971",
        subsidiary_id=456,
        subsidiary_name="Def",
        subsidiary_uuid="b789eaf4-c925-4a79-85b1-34d270342353",
    )

    model_str = "gemini-2.0-flash"

    response = await client.aio.models.generate_content(
        model=model_str,
        contents=[{"role": "user", "parts": [{"text": "What is 2+2?"}]}],
    )
    print(response)

    assert response is not None
    assert response.response_id is not None
    assert response.model_version == model_str
    # Result needs to be something that makes sense
    assert response.parts[0].text in "2 + 2 = 4\n 2 + 2 equals 4."
    assert response.candidates[0].content.parts[0].text in "2 + 2 = 4\n 2 + 2 equals 4."
    assert response.candidates[0].content.role == "model"
    assert response.candidates[0].finish_reason.name == "STOP"
    assert response.usage_metadata.prompt_token_count > 0
    assert response.usage_metadata.candidates_token_count > 0
    assert response.usage_metadata.total_token_count == (
        response.usage_metadata.prompt_token_count
        + response.usage_metadata.candidates_token_count
    )

    payloop.sentinel.raise_if_irrelevant(True)

    with pytest.raises(PayloopRequestInterceptedError):
        await client.aio.models.generate_content(
            model=model_str,
            contents="What is the capital of France?",
            config={"system_instruction": "Only answer questions related to code"},
        )
