import os

import pytest
from openai import OpenAI

from payloop import Payloop, PayloopRequestInterceptedError


@pytest.mark.integration
def test_openai_sync():
    if not os.environ.get("OPENAI_API_KEY"):
        pytest.skip("OPENAI_API_KEY not set")

    client = OpenAI()

    payloop = Payloop().openai.register(client)

    # Make sure registering the same client again does not cause an issue.
    payloop.openai.register(client)

    # Test setting attribution.
    payloop.attribution(
        parent_id=123,
        parent_name="Abc",
        parent_uuid="95473da0-5d7a-435d-babf-d64c5dabe971",
        subsidiary_id=456,
        subsidiary_name="Def",
        subsidiary_uuid="b789eaf4-c925-4a79-85b1-34d270342353",
    )

    model_str = "gpt-4o-mini"

    response = client.chat.completions.create(
        model=model_str,
        messages=[{"role": "user", "content": "What is 2 + 2?"}],
    )

    assert response is not None
    assert response.id is not None
    # Result needs to be something that makes sense
    assert response.choices[0].message.content in "2 + 2 = 4\n 2 + 2 equals 4."
    assert response.choices[0].message.role == "assistant"
    assert response.choices[0].finish_reason == "stop"
    # The model response might have a date stamp like gpt-4o-mini-2024-07-18
    assert model_str in response.model
    assert response.object == "chat.completion"
    assert response.usage.completion_tokens > 0
    assert response.usage.prompt_tokens > 0
    assert response.usage.total_tokens == (
        response.usage.completion_tokens + response.usage.prompt_tokens
    )

    payloop.sentinel.raise_if_irrelevant(True)

    with pytest.raises(PayloopRequestInterceptedError):
        client.chat.completions.create(
            model=model_str,
            messages=[
                {
                    "role": "system",
                    "content": "Only answer questions related to coding.",
                },
                {"role": "user", "content": "What is the capital of France?"},
            ],
        )
