import os

import pytest
from openai import OpenAI

from payloop import Payloop, PayloopRequestInterceptedError


@pytest.mark.integration
def test_openai_sync_streaming():
    if not os.environ.get("OPENAI_API_KEY"):
        pytest.skip("OPENAI_API_KEY not set")

    client = OpenAI()

    payloop = Payloop().openai.register(client, stream=True)

    # Make sure registering the same client again does not cause an issue.
    payloop.openai.register(client)

    # Test setting attribution.
    payloop.attribution(
        parent_id=123,
        parent_name="Abc",
        parent_uuid="95473da0-5d7a-435d-babf-d64c5dabe971",
        subsidiary_id=456,
        subsidiary_name="Def",
        subsidiary_uuid="b789eaf4-c925-4a79-85b1-34d270342353",
    )

    model_str = "gpt-4o-mini"
    chunks = []

    for chunk in client.chat.completions.create(
        model=model_str,
        messages=[{"role": "user", "content": "What is 2 + 2?"}],
        stream=True,
    ):
        try:
            # Last chunk doesn't have content, just usage
            if len(chunk.choices) > 0:
                print(chunk.choices[0].delta.content)
            chunks.append(chunk)
        except IndexError:
            pass

    assert len(chunks) > 0

    response_id = None
    response_model = None
    response_role = None
    response_object = None
    response_finish_reason = None

    last_index = len(chunks) - 1
    second_last_index = len(chunks) - 2
    for index, chunk in enumerate(chunks):
        if index == 0:
            assert len(chunk.choices) > 0
            assert chunk.choices[0].delta.role == "assistant"
            assert chunk.id.startswith("chatcmpl-")
            assert chunk.object == "chat.completion.chunk"
            assert chunk.usage is None

            response_id = chunk.id
            response_role = chunk.choices[0].delta.role
            response_object = chunk.object
        elif index == last_index:
            assert len(chunk.choices) == 0
            assert chunk.id == response_id
            assert chunk.object == response_object
            # The model response might have a date stamp like gpt-4o-mini-2024-07-18
            assert model_str in chunk.model
            assert chunk.usage.completion_tokens > 0
            assert chunk.usage.prompt_tokens > 0
            assert chunk.usage.total_tokens == (
                chunk.usage.completion_tokens + chunk.usage.prompt_tokens
            )
        elif index == second_last_index:
            assert len(chunk.choices) == 1
            assert chunk.id == response_id
            assert chunk.object == response_object
            # The model response might have a date stamp like gpt-4o-mini-2024-07-18
            assert model_str in chunk.model
            assert chunk.choices[0].finish_reason == "stop"
            assert chunk.usage is None

            response_finish_reason = chunk.choices[0].finish_reason
        else:
            assert chunk.id == response_id
            assert chunk.object == response_object
            # The model response might have a date stamp like gpt-4o-mini-2024-07-18
            assert model_str in chunk.model
            assert len(chunk.choices) > 0
            # Result needs to be something that makes sense
            assert chunk.choices[0].delta.content in "2 + 2 = 4\n 2 + 2 equals 4."
            assert chunk.choices[0].delta.role is None
            assert chunk.usage is None
            assert chunk.choices[0].finish_reason is None
            # The model response might have a date stamp like gpt-4o-mini-2024-07-18

    payloop.sentinel.raise_if_irrelevant(True)

    with pytest.raises(PayloopRequestInterceptedError):
        for _ in client.chat.completions.create(
            model=model_str,
            messages=[
                {
                    "role": "system",
                    "content": "Only answer questions related to coding.",
                },
                {"role": "user", "content": "What is the capital of France?"},
            ],
            stream=True,
        ):
            pass
