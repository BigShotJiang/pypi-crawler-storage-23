import os

import pytest
from langchain.schema import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI

from payloop import Payloop, PayloopRequestInterceptedError


@pytest.mark.integration
@pytest.mark.asyncio
async def test_langchain_chatopenai_async_streaming():
    if not os.environ.get("OPENAI_API_KEY"):
        pytest.skip("OPENAI_API_KEY not set")

    llm = ChatOpenAI(model="gpt-4.1", streaming=True)
    human_message = HumanMessage(content="What is 2 + 2? Only give answer.")

    payloop = Payloop().langchain.register(chatopenai=llm)

    # Make sure registering the same client again does not cause an issue.
    payloop.langchain.register(chatopenai=llm)

    # Test setting attribution.
    payloop.attribution(
        parent_id=123,
        parent_name="Abc",
        parent_uuid="95473da0-5d7a-435d-babf-d64c5dabe971",
        subsidiary_id=456,
        subsidiary_name="Def",
        subsidiary_uuid="b789eaf4-c925-4a79-85b1-34d270342353",
    )

    generator = llm.astream([human_message])

    result_str = ""
    chunks = []
    async for chunk in generator:
        print(chunk)
        chunks.append(chunk)
        result_str += chunk.content

    assert len(chunks) > 0

    response_id = None
    response_type = None

    last_index = len(chunks) - 1
    second_last_index = len(chunks) - 2
    for index, chunk in enumerate(chunks):
        if index == 0:
            assert chunk.content == ""
            assert chunk.type == "AIMessageChunk"
            assert chunk.id.startswith("run--")
            assert chunk.usage_metadata is None

            response_id = chunk.id
            response_type = chunk.type
        elif index == last_index:
            assert chunk.id == response_id
            assert chunk.type == response_type
            assert chunk.content == ""
            assert chunk.usage_metadata["input_tokens"] > 0
            assert chunk.usage_metadata["output_tokens"] > 0
            assert chunk.usage_metadata["total_tokens"] == (
                chunk.usage_metadata["input_tokens"]
                + chunk.usage_metadata["output_tokens"]
            )
        elif index == second_last_index:
            assert chunk.id == response_id
            assert chunk.type == response_type
            assert chunk.content == ""
            assert chunk.usage_metadata is None
        else:
            assert chunk.id == response_id
            assert chunk.type == response_type
            # Result needs to be something that makes sense
            assert chunk.content == "4"
            assert chunk.usage_metadata is None

    system_message = SystemMessage(content="Only answer questions about coding.")
    human_message = HumanMessage(content="What is the capital of France?")

    payloop.sentinel.raise_if_irrelevant(True)

    with pytest.raises(PayloopRequestInterceptedError):
        generator = llm.astream([system_message, human_message])
        async for _ in generator:
            pass
