import os

import pytest
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

from payloop import Payloop, PayloopRequestInterceptedError


@tool
def multiply(a: int, b: int) -> int:
    """Multiply a and b."""
    return a * b


@pytest.mark.integration
def test_langchain_chatopenai_sync():
    if not os.environ.get("OPENAI_API_KEY"):
        pytest.skip("OPENAI_API_KEY not set")

    model_str = "gpt-4o-mini"

    llm = ChatOpenAI(model=model_str)

    payloop = Payloop().langchain.register(chatopenai=llm)

    # Make sure registering the same client again does not cause an issue.
    payloop.langchain.register(chatopenai=llm)

    # Test setting attribution.
    payloop.attribution(
        parent_id=123,
        parent_name="Abc",
        parent_uuid="95473da0-5d7a-435d-babf-d64c5dabe971",
        subsidiary_id=456,
        subsidiary_name="Def",
        subsidiary_uuid="b789eaf4-c925-4a79-85b1-34d270342353",
    )

    # Bind (potentially multiple) tools to the model
    llm_with_tools = llm.bind_tools([multiply])

    # Step 1: Model generates tool calls
    messages = [{"role": "user", "content": "What is 10 * 10?"}]
    ai_msg = llm_with_tools.invoke(messages)
    print(ai_msg)

    assert ai_msg is not None
    assert ai_msg.id.startswith("run--")
    assert ai_msg.response_metadata["model_name"].startswith(model_str)
    assert ai_msg.response_metadata["finish_reason"] == "tool_calls"
    assert ai_msg.tool_calls[0]["name"] == "multiply"
    assert ai_msg.tool_calls[0]["type"] == "tool_call"
    assert ai_msg.tool_calls[0]["args"]["a"] == 10
    assert ai_msg.tool_calls[0]["args"]["b"] == 10
    assert ai_msg.usage_metadata["input_tokens"] > 0
    assert ai_msg.usage_metadata["output_tokens"] > 0
    assert ai_msg.usage_metadata["total_tokens"] == (
        ai_msg.usage_metadata["input_tokens"] + ai_msg.usage_metadata["output_tokens"]
    )

    # Step 2: Execute tools and collect results
    tool_result = multiply.invoke(ai_msg.tool_calls[0])

    assert tool_result.content == "100"
    assert tool_result.name == "multiply"

    payloop.sentinel.raise_if_irrelevant(True)

    with pytest.raises(PayloopRequestInterceptedError):
        llm_with_tools.invoke(
            [
                ("system", "Only answer questions related to coding."),
                ("user", "What is the capital of France?"),
            ]
        )
