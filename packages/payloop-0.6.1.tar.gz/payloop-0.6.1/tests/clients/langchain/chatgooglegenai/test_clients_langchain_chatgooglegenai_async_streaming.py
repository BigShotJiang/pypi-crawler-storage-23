import os

import pytest
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_google_genai import ChatGoogleGenerativeAI

from payloop import Payloop, PayloopRequestInterceptedError


@pytest.mark.integration
@pytest.mark.asyncio
async def test_langchain_chatgooglegenai_async_streaming():
    if not os.environ.get("GOOGLE_APPLICATION_CREDENTIALS"):
        pytest.skip("GOOGLE_APPLICATION_CREDENTIALS not set")

    llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash")
    human_message = HumanMessage(content="What is 2 + 2? Only give answer.")

    payloop = Payloop().langchain.register(chatgooglegenai=llm)

    # Make sure registering the same client again does not cause an issue.
    payloop.langchain.register(chatgooglegenai=llm)

    # Test setting attribution.
    payloop.attribution(
        parent_id=123,
        parent_name="Abc",
        parent_uuid="95473da0-5d7a-435d-babf-d64c5dabe971",
        subsidiary_id=456,
        subsidiary_name="Def",
        subsidiary_uuid="b789eaf4-c925-4a79-85b1-34d270342353",
    )

    generator = llm.astream([human_message])

    result_str = ""
    chunks = []
    async for chunk in generator:
        print(chunk)
        chunks.append(chunk)
        result_str += chunk.content

    assert len(chunks) > 0
    for index, chunk in enumerate(chunks):
        assert chunk.type == "AIMessageChunk"
        assert chunk.id.startswith("run--")
        assert chunk.usage_metadata["total_tokens"] == (
            chunk.usage_metadata["input_tokens"] + chunk.usage_metadata["output_tokens"]
        )
        # Result needs to be something that makes sense
        assert chunk.content in "4\n"

    system_message = SystemMessage(content="Only answer questions about coding.")
    human_message = HumanMessage(content="What is the capital of France?")

    payloop.sentinel.raise_if_irrelevant(True)

    with pytest.raises(PayloopRequestInterceptedError):
        generator = llm.astream([system_message, human_message])
        async for _ in generator:
            pass
