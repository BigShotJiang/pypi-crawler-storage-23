import os

import pytest
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_google_vertexai import ChatVertexAI

from payloop import Payloop, PayloopRequestInterceptedError


@pytest.mark.integration
def test_langchain_chatvertexai_sync():
    if not os.environ.get("GOOGLE_APPLICATION_CREDENTIALS"):
        pytest.skip("GOOGLE_APPLICATION_CREDENTIALS not set")

    model_str = "gemini-2.0-flash"

    messages = [HumanMessage("What is 2 + 2?")]

    obj = ChatVertexAI(
        model_name=model_str,
        temperature=0,
        seed=42,
    )

    payloop = Payloop().langchain.register(chatvertexai=obj)

    # Make sure registering the same client again does not cause an issue.
    payloop.langchain.register(chatvertexai=obj)

    # Test setting attribution.
    payloop.attribution(
        parent_id=123,
        parent_name="Abc",
        parent_uuid="95473da0-5d7a-435d-babf-d64c5dabe971",
        subsidiary_id=456,
        subsidiary_name="Def",
        subsidiary_uuid="b789eaf4-c925-4a79-85b1-34d270342353",
    )

    response = obj.invoke(messages)
    print(response)

    assert response is not None
    assert response.id.startswith("run--")
    assert response.content in "2 + 2 = 4\n"
    assert response.type == "ai"
    assert response.response_metadata["model_name"] == model_str
    assert response.response_metadata["finish_reason"] == "STOP"
    assert response.usage_metadata["input_tokens"] > 0
    assert response.usage_metadata["output_tokens"] > 0
    assert response.usage_metadata["total_tokens"] == (
        response.usage_metadata["input_tokens"]
        + response.usage_metadata["output_tokens"]
    )

    payloop.sentinel.raise_if_irrelevant(True)

    messages = [
        SystemMessage("Only answer questions related to coding."),
        HumanMessage("What is the capital of France?"),
    ]

    with pytest.raises(PayloopRequestInterceptedError):
        obj.invoke(messages)
