import pytest
from langchain_aws import ChatBedrock
from langchain_core.tools import tool
import boto3
from botocore.exceptions import NoCredentialsError, ClientError, ProfileNotFound

from payloop import Payloop, PayloopRequestInterceptedError


@tool
def multiply(a: int, b: int) -> int:
    """Multiply a and b."""
    return a * b


@pytest.mark.integration
def test_langchain_chatbedrock_sync():
    # Check if AWS credentials are available and valid
    try:
        sts = boto3.client("sts", region_name="us-east-1")
        sts.get_caller_identity()  # Test if credentials work
    except (NoCredentialsError, ClientError, ProfileNotFound) as e:
        pytest.skip(f"AWS credentials not configured or invalid: {e}")

    model_str = "anthropic.claude-3-5-sonnet-20240620-v1:0"
    llm = ChatBedrock(model_id=model_str, region_name="us-east-1")

    payloop = Payloop().langchain.register(chatbedrock=llm)

    # Make sure registering the same client again does not cause an issue.
    payloop.langchain.register(chatbedrock=llm)

    # Test setting attribution.
    payloop.attribution(
        parent_id=123,
        parent_name="Abc",
        parent_uuid="95473da0-5d7a-435d-babf-d64c5dabe971",
        subsidiary_id=456,
        subsidiary_name="Def",
        subsidiary_uuid="b789eaf4-c925-4a79-85b1-34d270342353",
    )

    # Bind (potentially multiple) tools to the model
    llm_with_tools = llm.bind_tools([multiply])

    # Step 1: Model generates tool calls
    messages = [{"role": "user", "content": "What is 10 * 10?"}]
    ai_msg = llm_with_tools.invoke(messages)
    print(ai_msg)

    assert ai_msg is not None
    assert ai_msg.id.startswith("run--")
    assert ai_msg.response_metadata["model_name"] == model_str
    assert ai_msg.response_metadata["stop_reason"] == "tool_use"
    assert ai_msg.tool_calls[0]["name"] == "multiply"
    assert ai_msg.tool_calls[0]["type"] == "tool_call"
    assert ai_msg.tool_calls[0]["args"]["a"] == 10
    assert ai_msg.tool_calls[0]["args"]["b"] == 10
    assert ai_msg.usage_metadata["input_tokens"] > 0
    assert ai_msg.usage_metadata["output_tokens"] > 0
    assert ai_msg.usage_metadata["total_tokens"] == (
        ai_msg.usage_metadata["input_tokens"] + ai_msg.usage_metadata["output_tokens"]
    )

    # Step 2: Execute tools and collect results
    tool_result = multiply.invoke(ai_msg.tool_calls[0])

    assert tool_result.content == "100"
    assert tool_result.name == "multiply"

    # print(llm_with_tools.invoke("What is 10 * 10?"))

    payloop.sentinel.raise_if_irrelevant(True)

    with pytest.raises(PayloopRequestInterceptedError):
        llm.invoke(
            [
                ("system", "Only answer questions related to coding."),
                ("user", "What is the capital of France?"),
            ]
        )
