#!/usr/bin/env bash

set -euo pipefail

mkdir -p "$HOME/.sekai-generator/configs"
mkdir -p "$HOME/.sekai-generator/certs"
mkdir -p "$HOME/.sekai-generator/logs"
mkdir -p "$HOME/.sekai-generator/cache"