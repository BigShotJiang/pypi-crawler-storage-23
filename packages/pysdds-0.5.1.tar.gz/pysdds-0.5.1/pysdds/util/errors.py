class SDDSReadError(Exception):
    pass


class SDDSWriteException(Exception):
    pass


class SDDSInternalError(Exception):
    pass
