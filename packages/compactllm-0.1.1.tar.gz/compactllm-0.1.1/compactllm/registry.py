"""
registry.py — CompactLLM's curated model catalog.

Contains a built-in list of vetted free models, organized by hardware tier.
Also handles fetching updated model lists from the remote registry.

Update strategy (layered fallback):
    1. Remote registry  — Fetched from GitHub weekly, cached locally
    2. Built-in list    — Always available offline, baked into the package
    3. HuggingFace API  — Live search for latest trending models (requires internet)
"""

import json
import time
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Cache config
# ---------------------------------------------------------------------------
CACHE_DIR = Path.home() / ".cache" / "compactllm"
REGISTRY_CACHE_FILE = CACHE_DIR / "registry.json"
REMOTE_REGISTRY_URL = (
    "https://raw.githubusercontent.com/compactllm-dev/registry/main/models.json"
)
CACHE_TTL_SECONDS = 7 * 24 * 3600  # refresh once a week

# ---------------------------------------------------------------------------
# Built-in curated model list (works 100% offline)
# ---------------------------------------------------------------------------
BUILTIN_MODELS = [

    # ── 🥔 POTATO TIER  (< 4 GB RAM) ──────────────────────────────────────
    {
        "id": "smollm2-tiny",
        "name": "SmolLM2 135M",
        "hf_id": "HuggingFaceTB/SmolLM2-135M-Instruct",
        "params": "135M",
        "min_ram_gb": 0.3,
        "tier": "potato",
        "license": "Apache 2.0",
        "tags": ["chat", "tiny", "fast", "general"],
        "best_for": "Ultra-fast tasks, testing, embedded devices",
        "quantized_gguf": None,
        "gated": False,
    },
    {
        "id": "qwen2.5-0.5b",
        "name": "Qwen 2.5 0.5B",
        "hf_id": "Qwen/Qwen2.5-0.5B-Instruct",
        "params": "0.5B",
        "min_ram_gb": 0.6,
        "tier": "potato",
        "license": "Apache 2.0",
        "tags": ["chat", "tiny", "multilingual"],
        "best_for": "Ultra-light completions, multilingual tasks",
        "quantized_gguf": None,
        "gated": False,
    },
    {
        "id": "tinyllama",
        "name": "TinyLlama 1.1B Chat",
        "hf_id": "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
        "params": "1.1B",
        "min_ram_gb": 1.0,
        "tier": "potato",
        "license": "Apache 2.0",
        "tags": ["chat", "fast", "general"],
        "best_for": "Quick Q&A, chat, general tasks on very low-end hardware",
        "quantized_gguf": "TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF",
        "gated": False,
    },
    {
        "id": "gemma3-1b",
        "name": "Gemma 3 1B",
        "hf_id": "google/gemma-3-1b-it",
        "params": "1B",
        "min_ram_gb": 1.0,
        "tier": "potato",
        "license": "Gemma ToS (free)",
        "tags": ["chat", "google", "multilingual", "long-context"],
        "best_for": "Chat with 128K context window, 140+ languages",
        "quantized_gguf": None,
        "gated": True,  # Requires HuggingFace login
    },
    {
        "id": "deepseek-r1-1.5b",
        "name": "DeepSeek R1 1.5B",
        "hf_id": "deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B",
        "params": "1.5B",
        "min_ram_gb": 1.5,
        "tier": "potato",
        "license": "MIT",
        "tags": ["reasoning", "math", "logic"],
        "best_for": "Math problems, logic, step-by-step reasoning",
        "quantized_gguf": None,
        "gated": False,
    },

    # ── 💻 BASIC TIER  (4–8 GB RAM) ───────────────────────────────────────
    {
        "id": "smollm2",
        "name": "SmolLM2 1.7B",
        "hf_id": "HuggingFaceTB/SmolLM2-1.7B-Instruct",
        "params": "1.7B",
        "min_ram_gb": 2.0,
        "tier": "basic",
        "license": "Apache 2.0",
        "tags": ["chat", "fast", "general", "recommended"],
        "best_for": "Best quality under 2B. General chat, Q&A, summarization",
        "quantized_gguf": None,
        "gated": False,
    },
    {
        "id": "qwen2.5-1.5b",
        "name": "Qwen 2.5 1.5B",
        "hf_id": "Qwen/Qwen2.5-1.5B-Instruct",
        "params": "1.5B",
        "min_ram_gb": 1.8,
        "tier": "basic",
        "license": "Apache 2.0",
        "tags": ["chat", "multilingual", "long-context"],
        "best_for": "Multilingual tasks, long context documents",
        "quantized_gguf": None,
        "gated": False,
    },
    {
        "id": "llama3.2-1b",
        "name": "Llama 3.2 1B",
        "hf_id": "meta-llama/Llama-3.2-1B-Instruct",
        "params": "1B",
        "min_ram_gb": 1.2,
        "tier": "basic",
        "license": "Llama 3.2 Community License",
        "tags": ["chat", "meta", "edge", "fast"],
        "best_for": "Meta's edge-optimised model. Fast general chat.",
        "quantized_gguf": None,
        "gated": True,  # Requires HuggingFace login + Meta approval
    },
    {
        "id": "exaone-2.4b",
        "name": "EXAONE 3.5 2.4B",
        "hf_id": "LGAI-EXAONE/EXAONE-3.5-2.4B-Instruct",
        "params": "2.4B",
        "min_ram_gb": 2.5,
        "tier": "basic",
        "license": "Apache 2.0",
        "tags": ["reasoning", "bilingual", "en", "ko"],
        "best_for": "Strong reasoning, English + Korean bilingual support",
        "quantized_gguf": "LGAI-EXAONE/EXAONE-3.5-2.4B-Instruct-GGUF",
        "gated": False,
    },
    {
        "id": "phi3.5-mini",
        "name": "Phi-3.5 Mini Instruct",
        "hf_id": "microsoft/Phi-3.5-mini-instruct",
        "params": "3.8B",
        "min_ram_gb": 3.5,
        "tier": "basic",
        "license": "MIT",
        "tags": ["coding", "reasoning", "microsoft"],
        "best_for": "Coding assistance, reasoning. Punches above its weight.",
        "quantized_gguf": None,
        "gated": False,
    },

    # ── 🖥️  MID TIER  (8–16 GB RAM) ───────────────────────────────────────
    {
        "id": "llama3.2-3b",
        "name": "Llama 3.2 3B",
        "hf_id": "meta-llama/Llama-3.2-3B-Instruct",
        "params": "3B",
        "min_ram_gb": 3.5,
        "tier": "mid",
        "license": "Llama 3.2 Community License",
        "tags": ["chat", "meta", "general", "recommended"],
        "best_for": "Best 3B model overall. Multilingual, 128K context.",
        "quantized_gguf": None,
        "gated": True,  # Requires HuggingFace login + Meta approval
    },
    {
        "id": "qwen2.5-coder-3b",
        "name": "Qwen 2.5 Coder 3B",
        "hf_id": "Qwen/Qwen2.5-Coder-3B-Instruct",
        "params": "3B",
        "min_ram_gb": 3.0,
        "tier": "mid",
        "license": "Apache 2.0",
        "tags": ["coding", "programming", "developer"],
        "best_for": "Code generation, debugging, code explanation",
        "quantized_gguf": None,
        "gated": False,
    },
    {
        "id": "gemma3-4b",
        "name": "Gemma 3 4B",
        "hf_id": "google/gemma-3-4b-it",
        "params": "4B",
        "min_ram_gb": 4.0,
        "tier": "mid",
        "license": "Gemma ToS (free)",
        "tags": ["chat", "multimodal", "google", "vision"],
        "best_for": "Chat + basic image understanding (multimodal)",
        "quantized_gguf": None,
        "gated": True,  # Requires HuggingFace login
    },
    {
        "id": "mistral-7b",
        "name": "Mistral 7B Instruct",
        "hf_id": "mistralai/Mistral-7B-Instruct-v0.3",
        "params": "7B",
        "min_ram_gb": 5.0,
        "tier": "mid",
        "license": "Apache 2.0",
        "tags": ["chat", "general", "fast", "recommended"],
        "best_for": "Fast, general purpose. Excellent quality for 7B.",
        "quantized_gguf": "TheBloke/Mistral-7B-Instruct-v0.3-GGUF",
        "gated": False,
    },

    # ── 🚀 HIGH TIER  (16 GB+ RAM) ─────────────────────────────────────────
    {
        "id": "phi4",
        "name": "Phi-4 14B",
        "hf_id": "microsoft/phi-4",
        "params": "14B",
        "min_ram_gb": 9.0,
        "tier": "high",
        "license": "MIT",
        "tags": ["coding", "reasoning", "microsoft", "high-quality"],
        "best_for": "Best coding + reasoning. Top quality per GB of RAM.",
        "quantized_gguf": None,
        "gated": False,
    },
    {
        "id": "llama3.1-8b",
        "name": "Llama 3.1 8B",
        "hf_id": "meta-llama/Llama-3.1-8B-Instruct",
        "params": "8B",
        "min_ram_gb": 6.0,
        "tier": "high",
        "license": "Llama 3.1 Community License",
        "tags": ["chat", "meta", "general", "high-quality"],
        "best_for": "High quality general purpose chat and reasoning",
        "quantized_gguf": "TheBloke/Llama-3.1-8B-Instruct-GGUF",
        "gated": True,  # Requires HuggingFace login + Meta approval
    },
]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def list_models(
    tier: Optional[str] = None,
    task: Optional[str] = None,
    max_ram_gb: Optional[float] = None,
    show_all: bool = False,
    include_gated: bool = False,
) -> list[dict]:
    """
    List free models available to run locally.

    By default, automatically detects your hardware and only returns models
    that will fit comfortably in your available RAM. Gated models (those
    requiring a HuggingFace login or special approval) are excluded by default.

    Args:
        tier:           Filter to a specific tier — 'potato', 'basic', 'mid',
                        'high', or 'all'. Defaults to auto-detect.
        task:           Filter by task tag e.g. 'coding', 'chat', 'reasoning',
                        'multilingual', 'math'.
        max_ram_gb:     Only return models requiring this much RAM or less.
        show_all:       If True, skip hardware filtering and show every model.
        include_gated:  If True, include models that require HuggingFace login
                        or special access approval. Default False.

    Returns:
        List of model info dicts, each containing:
            id, name, hf_id, params, min_ram_gb, tier,
            license, tags, best_for, gated

    Example:
        from compactllm import list_models

        # Models your machine can run right now (no login needed)
        models = list_models()

        # Only coding models
        models = list_models(task='coding')

        # Everything including gated models
        models = list_models(show_all=True, include_gated=True)
    """
    models = _get_registry()

    # Always filter out gated models unless explicitly requested
    if not include_gated:
        models = [m for m in models if not m.get("gated", False)]

    # Auto hardware-based filtering unless overridden
    if not show_all and tier is None and max_ram_gb is None:
        try:
            from .hardware import detect_hardware
            hw = detect_hardware()
            max_ram_gb = hw["ram_gb"] * 0.6  # 60% of RAM is a safe working limit
        except Exception:
            pass

    # Tier filter
    if tier and tier != "all":
        tier_order = ["potato", "basic", "mid", "high"]
        if tier in tier_order:
            cutoff = tier_order.index(tier)
            models = [m for m in models if tier_order.index(m["tier"]) <= cutoff]

    # RAM filter
    if max_ram_gb:
        models = [m for m in models if m["min_ram_gb"] <= max_ram_gb]

    # Task filter
    if task:
        task_lower = task.lower()
        models = [
            m for m in models
            if any(task_lower in t.lower() for t in m.get("tags", []))
        ]

    return models


def get_model_info(model_id: str) -> Optional[dict]:
    """
    Get metadata for a specific model.

    Args:
        model_id: Short ID like 'smollm2', full HuggingFace ID like
                  'HuggingFaceTB/SmolLM2-1.7B-Instruct', or display name.

    Returns:
        Model info dict, or None if not found.

    Example:
        info = get_model_info('mistral-7b')
        print(info['min_ram_gb'])  # 5.0
        print(info['license'])     # 'Apache 2.0'
    """
    model_id_lower = model_id.lower()
    for m in _get_registry():
        if (
            m["id"] == model_id
            or m["hf_id"] == model_id
            or m["id"] == model_id_lower
            or m["name"].lower() == model_id_lower
        ):
            return m
    return None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_registry() -> list[dict]:
    """
    Return the model registry, trying sources in priority order:
        1. Valid cached remote registry (if < 7 days old)
        2. Fresh remote registry fetch
        3. Built-in offline list (always works)
    """
    # 1. Try valid cache
    if REGISTRY_CACHE_FILE.exists():
        age = time.time() - REGISTRY_CACHE_FILE.stat().st_mtime
        if age < CACHE_TTL_SECONDS:
            try:
                with open(REGISTRY_CACHE_FILE) as f:
                    data = json.load(f)
                    if data.get("models"):
                        return data["models"]
            except Exception:
                pass

    # 2. Try fetching remote registry
    try:
        import urllib.request
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(REMOTE_REGISTRY_URL, timeout=3) as resp:
            data = json.loads(resp.read())
            with open(REGISTRY_CACHE_FILE, "w") as f:
                json.dump(data, f, indent=2)
            if data.get("models"):
                return data["models"]
    except Exception:
        pass  # Offline or registry not up yet — that's fine

    # 3. Offline fallback
    return BUILTIN_MODELS
