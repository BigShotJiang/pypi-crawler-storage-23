"""
tests/test_atomllm.py — Basic unit tests for AtomLLM.

Run with: pytest tests/
"""

import pytest
from unittest.mock import patch, MagicMock


# ── Registry tests ─────────────────────────────────────────────────────────

class TestRegistry:

    def test_list_models_returns_list(self):
        from atomllm import list_models
        models = list_models(show_all=True)
        assert isinstance(models, list)
        assert len(models) > 0

    def test_list_models_have_required_keys(self):
        from atomllm import list_models
        models = list_models(show_all=True)
        required = {"id", "name", "hf_id", "params", "min_ram_gb", "tier", "license", "best_for"}
        for m in models:
            assert required.issubset(m.keys()), f"Model {m.get('id')} missing keys"

    def test_list_models_tier_filter(self):
        from atomllm import list_models
        potato = list_models(tier="potato", show_all=True)
        for m in potato:
            assert m["tier"] == "potato"

    def test_list_models_task_filter(self):
        from atomllm import list_models
        coding = list_models(task="coding", show_all=True)
        for m in coding:
            assert any("coding" in t.lower() for t in m["tags"])

    def test_list_models_ram_filter(self):
        from atomllm import list_models
        models = list_models(max_ram_gb=1.5, show_all=True)
        for m in models:
            assert m["min_ram_gb"] <= 1.5

    def test_get_model_info_by_id(self):
        from atomllm import get_model_info
        info = get_model_info("smollm2")
        assert info is not None
        assert info["id"] == "smollm2"
        assert info["tier"] == "basic"

    def test_get_model_info_by_hf_id(self):
        from atomllm import get_model_info
        info = get_model_info("HuggingFaceTB/SmolLM2-1.7B-Instruct")
        assert info is not None
        assert info["id"] == "smollm2"

    def test_get_model_info_unknown_returns_none(self):
        from atomllm import get_model_info
        assert get_model_info("this-model-does-not-exist-xyz") is None


# ── Hardware tests ─────────────────────────────────────────────────────────

class TestHardware:

    def test_detect_hardware_returns_dict(self):
        from atomllm import detect_hardware
        hw = detect_hardware()
        assert isinstance(hw, dict)

    def test_detect_hardware_has_required_keys(self):
        from atomllm import detect_hardware
        hw = detect_hardware()
        required = {"ram_gb", "cpu_cores", "cpu_name", "has_gpu", "tier", "platform"}
        assert required.issubset(hw.keys())

    def test_detect_hardware_tier_is_valid(self):
        from atomllm import detect_hardware
        hw = detect_hardware()
        assert hw["tier"] in ("potato", "basic", "mid", "high")

    def test_detect_hardware_ram_is_positive(self):
        from atomllm import detect_hardware
        hw = detect_hardware()
        assert hw["ram_gb"] > 0


# ── Model class tests (mocked — no actual downloads) ───────────────────────

class TestModel:

    def test_model_init_with_known_id(self):
        from atomllm import Model
        # Should not raise — just resolves the ID
        model = Model("smollm2", verbose=False)
        assert model.name == "SmolLM2 1.7B"
        assert not model.is_loaded

    def test_model_init_with_raw_hf_id(self):
        from atomllm import Model
        model = Model("HuggingFaceTB/SmolLM2-1.7B-Instruct", verbose=False)
        assert model._hf_id == "HuggingFaceTB/SmolLM2-1.7B-Instruct"

    def test_model_repr(self):
        from atomllm import Model
        model = Model("smollm2", verbose=False)
        assert "smollm2" in repr(model).lower() or "SmolLM2" in repr(model)
        assert "not loaded" in repr(model)

    def test_model_info_property(self):
        from atomllm import Model
        model = Model("smollm2", verbose=False)
        assert model.info is not None
        assert model.info["id"] == "smollm2"

    def test_model_auto_returns_model(self):
        from atomllm import Model
        # Model.auto() should return a Model instance without raising
        model = Model.auto(verbose=False)
        assert isinstance(model, Model)

    def test_model_ask_mocked(self):
        from atomllm import Model

        model = Model("smollm2", verbose=False)
        # Mock the pipeline so we don't actually download anything
        mock_pipeline = MagicMock(return_value=[{"generated_text": "This is a test response."}])
        model._pipeline = mock_pipeline

        response = model.ask("Test question")
        assert response == "This is a test response."
        mock_pipeline.assert_called_once()

    def test_model_chat_clear_command(self, capsys):
        from atomllm import Model
        import io

        model = Model("smollm2", verbose=False)
        mock_pipeline = MagicMock(return_value=[{"generated_text": "Hello!"}])
        model._pipeline = mock_pipeline

        # Simulate: clear → quit
        with patch("builtins.input", side_effect=["clear", "quit"]):
            model.chat()

        captured = capsys.readouterr()
        assert "cleared" in captured.out.lower()
