"""
compactllm — Compact AI, any device. No API key. No cost.

Run powerful AI models locally on any device — from old laptops
to modern desktops. Zero API keys. Zero subscriptions. One line of code.

Usage:
    from compactllm import Model, list_models

    model = Model('smollm2')
    print(model.ask('What is AI?'))

    # Or let CompactLLM pick the best model for your hardware
    model = Model.auto()
    print(model.ask('Hello!'))
"""

from .model import Model
from .registry import list_models, get_model_info
from .hardware import detect_hardware

__version__ = "0.1.1"
__all__ = ["Model", "list_models", "get_model_info", "detect_hardware", "help"]


def help():
    """Print a quick-start guide for CompactLLM."""
    print("""
╔══════════════════════════════════════════════════════════════╗
║              ⚡ CompactLLM — Quick Start Guide               ║
╚══════════════════════════════════════════════════════════════╝

PYTHON API
──────────────────────────────────────────────────────────────
  from compactllm import Model, list_models, detect_hardware

  # Run a model (downloads once, cached forever)
  model = Model('smollm2')
  print(model.ask('What is AI?'))

  # Auto-pick best model for your hardware (no login needed)
  model = Model.auto()
  model = Model.auto(task='coding')

  # Stream response word by word
  for chunk in model.stream('Tell me a story'):
      print(chunk, end='', flush=True)

  # Interactive multi-turn chat
  model.chat()

  # With a system prompt
  model.ask('Explain recursion', system='You are a patient teacher')

BROWSE MODELS
──────────────────────────────────────────────────────────────
  list_models()                    # models for your hardware
  list_models(show_all=True)       # all models
  list_models(task='coding')       # filter by task
  list_models(task='reasoning')    # reasoning models
  list_models(include_gated=True)  # include login-required models

HARDWARE INFO
──────────────────────────────────────────────────────────────
  detect_hardware()   # your RAM, tier, GPU info

FREE MODELS (no login needed) ✅
──────────────────────────────────────────────────────────────
  smollm2-tiny      135M   Ultra-fast, testing
  qwen2.5-0.5b      0.5B   Tiny, multilingual
  tinyllama         1.1B   Fast general chat
  deepseek-r1-1.5b  1.5B   Math & reasoning
  smollm2           1.7B   ⭐ Best under 2B (start here)
  qwen2.5-1.5b      1.5B   Multilingual tasks
  exaone-2.4b       2.4B   Reasoning + Korean
  phi3.5-mini       3.8B   Coding & reasoning
  qwen2.5-coder-3b  3B     Code generation
  mistral-7b        7B     ⭐ Best 7B quality
  phi4              14B    ⭐ Best coding/reasoning

GATED MODELS (require HuggingFace login) 🔒
──────────────────────────────────────────────────────────────
  gemma3-1b         1B     Google (login required)
  llama3.2-1b       1B     Meta  (login + approval)
  llama3.2-3b       3B     Meta  (login + approval)
  gemma3-4b         4B     Google (login required)
  llama3.1-8b       8B     Meta  (login + approval)

CLI COMMANDS
──────────────────────────────────────────────────────────────
  compact hardware              # show RAM, GPU, tier
  compact list                  # models for your machine
  compact list --all            # all models
  compact list --task coding    # filter by task
  compact ask smollm2 "hi"      # one-shot question
  compact chat smollm2          # interactive chat session
  compact info smollm2          # model details
  compact version               # show version

DOCS & HELP
──────────────────────────────────────────────────────────────
  GitHub : https://github.com/compactllm-dev/compactllm
  Issues : https://github.com/compactllm-dev/compactllm/issues
  Email  : hello@compactllm.dev
""")

__version__ = "0.1.0"
__author__ = "CompactLLM"
__license__ = "Apache-2.0"
__description__ = "Compact AI, any device. No API key. No cost."

__all__ = ["Model", "list_models", "get_model_info", "detect_hardware"]
