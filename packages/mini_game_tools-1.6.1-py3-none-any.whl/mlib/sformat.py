def to_UUID(string):
    result = ""
    
    while len(string) > 0:
        if len(string) <= 4:
            result += string
            break
        else:
            result += string[:4]
            string = string[4:]
            result += "-"
            
    return result

def to_poly(expr, use_star=False):
    if not expr:
        return expr
    
    # 第一步：先处理乘方（内部统一用 **）
    expr = expr.replace("^", "**")
    expr = expr.replace(" ", "")
    
    # 第二步：解析项
    terms = []
    current = ""
    for char in expr:
        if char == '+' and current:
            terms.append(current)
            current = ""
        elif char == '-' and current:
            terms.append(current)
            current = "-"
        else:
            current += char
    if current:
        terms.append(current)
    
    # 第三步：解析每个项，提取系数和变量部分
    parsed_terms = {}  # 变量部分 -> 系数
    
    for term in terms:
        if not term:
            continue
        
        # 找第一个字母的位置
        var_start = -1
        for i, char in enumerate(term):
            if char.isalpha():
                var_start = i
                break
        
        # 常数项
        if var_start == -1:
            coeff = float(term) if '.' in term else int(term)
            parsed_terms[""] = parsed_terms.get("", 0) + coeff
            continue
        
        # 系数部分
        coeff_str = term[:var_start]
        if not coeff_str or coeff_str == '+':
            coeff = 1
        elif coeff_str == '-':
            coeff = -1
        else:
            coeff = float(coeff_str) if '.' in coeff_str else int(coeff_str)
        
        # 变量部分
        var_part = term[var_start:]
        
        # 处理 x10 的情况
        if len(var_part) > 1 and var_part[0].isalpha() and var_part[1:].isdigit():
            extra_coeff = int(var_part[1:])
            coeff *= extra_coeff
            var_part = var_part[0]
        
        # 关键：统一变量部分的表示（用 ** 存，不要转成 ^）
        # 这样 "x**2" 和 "x**2" 才能正确合并
        parsed_terms[var_part] = parsed_terms.get(var_part, 0) + coeff
    
    # 第四步：重新构建表达式
    result_terms = []
    
    # 先处理非常数项
    for var in sorted(parsed_terms.keys()):
        if var == "":
            continue
        coeff = parsed_terms[var]
        if coeff == 0:
            continue
        
        if coeff == 1:
            coeff_str = ""
        elif coeff == -1:
            coeff_str = "-"
        else:
            coeff_str = str(coeff)
        
        # 输出时再把 ** 转成 ^
        if use_star:
            var_str = var.replace("**", "^")
        else:
            var_str = var
            
        if coeff_str:
            if use_star:
                result_terms.append(f"{coeff_str}{var_str}")
            else:
                result_terms.append(f"{coeff_str}*{var_str}")
        else:
            result_terms.append(var_str)
    
    # 常数项
    if "" in parsed_terms and parsed_terms[""] != 0:
        result_terms.append(str(parsed_terms[""]))
    
    if not result_terms:
        return "0"
    
    result = result_terms[0]
    for term in result_terms[1:]:
        if term.startswith('-'):
            result += term
        else:
            result += "+" + term
    
    return result


def number_to_english(n):
    """把整数转成英语单词形式，适合对话文本"""
    if n == 0:
        return "zero"
    
    # 1-19 特殊形式
    units = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
             "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen",
             "seventeen", "eighteen", "nineteen"]
    
    # 整十
    tens = ["", "", "twenty", "thirty", "forty", "fifty", 
            "sixty", "seventy", "eighty", "ninety"]
    
    # 千以上单位
    thousands = ["", "thousand", "million", "billion", "trillion", 
                 "quadrillion", "quintillion", "sextillion", "septillion",
                 "octillion", "nonillion", "decillion"]
    
    def _convert_three_digits(num):
        """处理 1-999"""
        if num == 0:
            return ""
        if num < 20:
            return units[num]
        if num < 100:
            ten = tens[num // 10]
            unit = units[num % 10]
            return ten + ("-" + unit if unit else "")
        # 100-999
        hundred = units[num // 100] + " hundred"
        rest = num % 100
        if rest == 0:
            return hundred
        return hundred + " and " + _convert_three_digits(rest)
    
    if n < 0:
        return "negative " + number_to_english(-n)
    
    result = []
    group_index = 0
    while n > 0:
        group = n % 1000
        if group != 0:
            group_str = _convert_three_digits(group)
            if thousands[group_index]:
                group_str += " " + thousands[group_index]
            result.insert(0, group_str)
        n //= 1000
        group_index += 1
    
    return " ".join(result).strip()

def insert(base_str, place, insert_str):
    pos = place
    new_s = base_str[:pos] + insert_str + base_str[pos:]
    return new_s
        
