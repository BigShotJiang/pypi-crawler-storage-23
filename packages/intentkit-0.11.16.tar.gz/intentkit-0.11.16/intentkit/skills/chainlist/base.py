from intentkit.skills.base import IntentKitSkill


class ChainlistBaseTool(IntentKitSkill):
    """Base class for chainlist tools."""

    category: str = "chainlist"
