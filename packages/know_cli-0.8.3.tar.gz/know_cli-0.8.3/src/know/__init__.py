"""know - Living documentation generator for codebases."""

__version__ = "0.8.3"
__author__ = "Sushil Kumar"

from know.cli import main

__all__ = ["main", "__version__"]
