# 导入loguru模块
from loguru import logger
import sys
import traceback

# 定义一个Log类，封装loguru的功能
class LoguruHandler:
    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(LoguruHandler, cls).__new__(cls)
        return cls._instance

    # 初始化方法，设置日志文件的路径和格式
    def __init__(self, file_path: str = None, format_str: str = "{time} - {level} - {message}", rotation: str = None, compression: str = "zip"):
        if not LoguruHandler._initialized:
            if file_path:
                # 判断是否要日志滚动
                if rotation is None:
                    logger.add(file_path, format=format_str, compression=compression)
                else:
                    logger.add(file_path, format=format_str, rotation=rotation, compression=compression)
            else:
                logger.add(sys.stdout, format=format_str)
            LoguruHandler._initialized = True

    # 定义一个debug方法，用于记录调试级别的日志
    def debug(self, message: str) -> None:
        """
        记录调试级别的日志。
        
        :param message: 要记录的日志消息
        :type message: str
        """
        logger.debug(message)

    # 定义一个info方法，用于记录信息级别的日志
    def info(self, message: str) -> None:
        """
        记录信息级别的日志。
        
        :param message: 要记录的日志消息
        :type message: str
        """
        logger.info(message)

    # 定义一个warning方法，用于记录警告级别的日志
    def warning(self, message: str) -> None:
        """
        记录警告级别的日志。
        
        :param message: 要记录的日志消息
        :type message: str
        """
        logger.warning(message)

    # 定义一个error方法，用于记录错误级别的日志
    def error(self, message: str) -> None:
        """
        记录错误级别的日志。
        
        :param message: 要记录的日志消息
        :type message: str
        """
        logger.error(message)

    # 定义一个critical方法，用于记录严重级别的日志
    def critical(self, message: str) -> None:
        """
        记录严重级别的日志。
        
        :param message: 要记录的日志消息
        :type message: str
        """
        logger.critical(message)

    # 定义一个exception方法，用于记录异常信息
    def exception(self, message: str) -> None:
        """
        记录异常信息，自动包含堆栈跟踪。
        
        :param message: 要记录的日志消息
        :type message: str
        """
        logger.exception(message)

    # 定义一个set_level方法，用于设置日志级别
    def set_level(self, level: str) -> None:
        """
        设置日志级别。
        
        :param level: 日志级别，可选值：DEBUG, INFO, WARNING, ERROR, CRITICAL
        :type level: str
        """
        logger.remove()
        if level == "DEBUG":
            logger.add(sys.stdout, level="DEBUG")
        elif level == "INFO":
            logger.add(sys.stdout, level="INFO")
        elif level == "WARNING":
            logger.add(sys.stdout, level="WARNING")
        elif level == "ERROR":
            logger.add(sys.stdout, level="ERROR")
        elif level == "CRITICAL":
            logger.add(sys.stdout, level="CRITICAL")

    # 定义一个add_file_handler方法，用于添加文件处理器
    def add_file_handler(self, file_path: str, rotation: str = None, compression: str = "zip", level: str = "INFO") -> None:
        """
        添加文件日志处理器。
        
        :param file_path: 日志文件路径
        :type file_path: str
        :param rotation: 日志文件轮转配置
        :type rotation: str
        :param compression: 日志文件压缩格式
        :type compression: str
        :param level: 日志级别
        :type level: str
        """
        if rotation:
            logger.add(file_path, rotation=rotation, compression=compression, level=level)
        else:
            logger.add(file_path, compression=compression, level=level)

    # 定义一个clear_handlers方法，用于清除所有处理器
    def clear_handlers(self) -> None:
        """
        清除所有日志处理器。
        """
        logger.remove()

    # 定义一个log_with_context方法，用于记录带上下文的日志
    def log_with_context(self, level: str, message: str, **context) -> None:
        """
        记录带上下文的日志。
        
        :param level: 日志级别
        :type level: str
        :param message: 日志消息
        :type message: str
        :param context: 上下文信息
        :type context: dict
        """
        context_str = ", ".join([f"{k}={v}" for k, v in context.items()])
        full_message = f"{message} | {context_str}"
        
        if level == "DEBUG":
            self.debug(full_message)
        elif level == "INFO":
            self.info(full_message)
        elif level == "WARNING":
            self.warning(full_message)
        elif level == "ERROR":
            self.error(full_message)
        elif level == "CRITICAL":
            self.critical(full_message)

    def configure(self, **kwargs) -> None:
        """
        配置日志处理器。
        
        :param kwargs: 配置参数
        :type kwargs: dict
        
        示例:
        >>> logger.configure(
        ...     level="INFO",
        ...     format="{time} - {level} - {name} - {message}",
        ...     file_path="app.log",
        ...     rotation="100MB",
        ...     compression="zip"
        ... )
        """
        import sys
        
        # 清除现有处理器
        self.clear_handlers()
        
        # 获取配置参数
        level = kwargs.get("level", "INFO")
        format_str = kwargs.get("format", "{time} - {level} - {message}")
        file_path = kwargs.get("file_path")
        rotation = kwargs.get("rotation")
        compression = kwargs.get("compression", "zip")
        
        # 添加控制台处理器
        logger.add(sys.stdout, level=level, format=format_str)
        
        # 添加文件处理器（如果指定）
        if file_path:
            if rotation:
                logger.add(file_path, level=level, format=format_str, rotation=rotation, compression=compression)
            else:
                logger.add(file_path, level=level, format=format_str, compression=compression)

    def structured_log(self, level: str, message: str, **data) -> None:
        """
        记录结构化日志。
        
        :param level: 日志级别
        :type level: str
        :param message: 日志消息
        :type message: str
        :param data: 结构化数据
        :type data: dict
        
        示例:
        >>> logger.structured_log("INFO", "User login", user_id=123, ip="192.168.1.1")
        """
        import json
        
        log_data = {
            "message": message,
            "data": data
        }
        
        log_message = json.dumps(log_data, ensure_ascii=False)
        
        if level == "DEBUG":
            self.debug(log_message)
        elif level == "INFO":
            self.info(log_message)
        elif level == "WARNING":
            self.warning(log_message)
        elif level == "ERROR":
            self.error(log_message)
        elif level == "CRITICAL":
            self.critical(log_message)

    def with_context(self, **context) -> "LoguruHandler":
        """
        创建一个带上下文的日志处理器。
        
        :param context: 上下文信息
        :type context: dict
        :return: 带上下文的日志处理器
        :rtype: LoguruHandler
        
        示例:
        >>> user_logger = logger.with_context(user_id=123)
        >>> user_logger.info("User action")  # 会自动包含 user_id=123
        """
        class ContextualLoguruHandler(LoguruHandler):
            def __init__(self, parent, context):
                self.parent = parent
                self.context = context
                # 不调用父类的 __init__，因为已经初始化过了
            
            def log(self, level, message, **kwargs):
                combined_context = {**self.context, **kwargs}
                self.parent.log_with_context(level, message, **combined_context)
            
            def debug(self, message, **kwargs):
                self.log("DEBUG", message, **kwargs)
            
            def info(self, message, **kwargs):
                self.log("INFO", message, **kwargs)
            
            def warning(self, message, **kwargs):
                self.log("WARNING", message, **kwargs)
            
            def error(self, message, **kwargs):
                self.log("ERROR", message, **kwargs)
            
            def critical(self, message, **kwargs):
                self.log("CRITICAL", message, **kwargs)
            
            def exception(self, message, **kwargs):
                combined_context = {**self.context, **kwargs}
                context_str = ", ".join([f"{k}={v}" for k, v in combined_context.items()])
                full_message = f"{message} | {context_str}"
                self.parent.exception(full_message)
        
        return ContextualLoguruHandler(self, context)

    def get_level(self) -> str:
        """
        获取当前日志级别。
        
        :return: 当前日志级别
        :rtype: str
        """
        # 获取第一个处理器的级别
        try:
            handlers = list(logger._core.handlers.values())
            if handlers:
                return handlers[0].level.name
        except (AttributeError, KeyError, IndexError):
            pass
        return "INFO"

    def add_error_handler(self, file_path: str) -> None:
        """
        添加错误日志处理器，专门记录 ERROR 及以上级别的日志。
        
        :param file_path: 错误日志文件路径
        :type file_path: str
        """
        logger.add(file_path, level="ERROR", format="{time} - {level} - {message}")

    def add_json_handler(self, file_path: str, level: str = "INFO") -> None:
        """
        添加 JSON 格式的日志处理器。
        
        :param file_path: 日志文件路径
        :type file_path: str
        :param level: 日志级别
        :type level: str
        """
        # 使用简单的格式字符串
        logger.add(file_path, level=level, format="{time:YYYY-MM-DD HH:mm:ss} {level} {message}")

    def add_timed_rotation(self, file_path: str, rotation: str = "00:00", level: str = "INFO") -> None:
        """
        添加按时间轮转的日志处理器。
        
        :param file_path: 日志文件路径
        :type file_path: str
        :param rotation: 轮转时间，格式如 "00:00"（每天凌晨）
        :type rotation: str
        :param level: 日志级别
        :type level: str
        
        示例:
        >>> logger.add_timed_rotation("app.log", "00:00")  # 每天凌晨轮转
        """
        logger.add(
            file_path,
            level=level,
            rotation=rotation,
            compression="zip",
            format="{time} - {level} - {message}"
        )

    def add_size_rotation(self, file_path: str, max_size: str = "100MB", level: str = "INFO") -> None:
        """
        添加按大小轮转的日志处理器。
        
        :param file_path: 日志文件路径
        :type file_path: str
        :param max_size: 最大文件大小，如 "100MB"
        :type max_size: str
        :param level: 日志级别
        :type level: str
        
        示例:
        >>> logger.add_size_rotation("app.log", "50MB")  # 每达到 50MB 轮转
        """
        logger.add(
            file_path,
            level=level,
            rotation=max_size,
            compression="zip",
            format="{time} - {level} - {message}"
        )

    def log_performance(self, operation: str, duration: float, **context) -> None:
        """
        记录性能指标日志。
        
        :param operation: 操作名称
        :type operation: str
        :param duration: 操作持续时间（秒）
        :type duration: float
        :param context: 上下文信息
        :type context: dict
        
        示例:
        >>> logger.log_performance("API call", 0.123, endpoint="/api/users")
        """
        self.log_with_context(
            "INFO",
            f"Performance metric",
            operation=operation,
            duration=duration,
            **context
        )

    def log_request(self, method: str, url: str, status_code: int, duration: float) -> None:
        """
        记录 HTTP 请求日志。
        
        :param method: HTTP 方法
        :type method: str
        :param url: 请求 URL
        :type url: str
        :param status_code: 状态码
        :type status_code: int
        :param duration: 请求持续时间（秒）
        :type duration: float
        
        示例:
        >>> logger.log_request("GET", "https://api.example.com", 200, 0.123)
        """
        level = "INFO" if 200 <= status_code < 400 else "ERROR"
        self.log_with_context(
            level,
            f"HTTP request",
            method=method,
            url=url,
            status_code=status_code,
            duration=duration
        )

    def log_exception(self, message: str, exc_info: Exception = None) -> None:
        """
        记录异常信息，可指定异常对象。
        
        :param message: 日志消息
        :type message: str
        :param exc_info: 异常对象
        :type exc_info: Exception
        
        示例:
        >>> try:
        ...     1 / 0
        ... except Exception as e:
        ...     logger.log_exception("Division by zero", e)
        """
        if exc_info:
            import traceback
            traceback_str = traceback.format_exc()
            self.error(f"{message}\n{traceback_str}")
        else:
            self.exception(message)

    def set_log_level(self, level: str) -> None:
        """
        设置全局日志级别。
        
        :param level: 日志级别，可选值：DEBUG, INFO, WARNING, ERROR, CRITICAL
        :type level: str
        
        示例:
        >>> logger.set_log_level("DEBUG")
        """
        self.set_level(level)

    def get_log_handlers(self) -> list:
        """
        获取当前所有日志处理器。
        
        :return: 处理器列表
        :rtype: list
        """
        try:
            return list(logger._core.handlers.values())
        except AttributeError:
            return []

    def remove_handler(self, handler_id) -> None:
        """
        移除指定的日志处理器。
        
        :param handler_id: 处理器 ID
        :type handler_id: int
        """
        try:
            logger.remove(handler_id)
        except Exception as e:
            self.error(f"移除处理器失败: {e}")

    def add_console_handler(self, level: str = "INFO", format_str: str = "{time} - {level} - {message}") -> None:
        """
        添加控制台日志处理器。
        
        :param level: 日志级别
        :type level: str
        :param format_str: 日志格式
        :type format_str: str
        """
        import sys
        logger.add(sys.stdout, level=level, format=format_str)

    def add_traceback_handler(self, file_path: str, level: str = "ERROR") -> None:
        """
        添加带详细回溯的日志处理器。
        
        :param file_path: 日志文件路径
        :type file_path: str
        :param level: 日志级别
        :type level: str
        """
        logger.add(
            file_path,
            level=level,
            format="{time} - {level} - {message}\n{exception}",
            backtrace=True,
            diagnose=True
        )

    def log_dict(self, level: str, data: dict) -> None:
        """
        记录字典数据。
        
        :param level: 日志级别
        :type level: str
        :param data: 字典数据
        :type data: dict
        
        示例:
        >>> logger.log_dict("INFO", {"user": "john", "action": "login"})
        """
        import json
        message = json.dumps(data, ensure_ascii=False, indent=2)
        
        if level == "DEBUG":
            self.debug(message)
        elif level == "INFO":
            self.info(message)
        elif level == "WARNING":
            self.warning(message)
        elif level == "ERROR":
            self.error(message)
        elif level == "CRITICAL":
            self.critical(message)

# # 创建一个Log对象，指定日志文件的路径和格式
# log = LoguruHandler("log.txt", "{time} - {level} - {message}")

# # 调用info方法，记录一条信息级别的日志
# log.info("This is an info message")

# # 调用error方法，记录一条错误级别的日志
# log.error("This is an error message")