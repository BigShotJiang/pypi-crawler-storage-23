# -*- coding: utf-8 -*-
"""
Azure Compute 服务
"""

from typing import List, Dict, Any, Optional
from PyraUtils.log import LoguruHandler


class AzureComputeService:
    """
    Azure Compute 服务
    """
    
    def __init__(self, client):
        """
        初始化 Compute 服务
        
        :param client: Azure 客户端
        """
        self.client = client
        self.logger = LoguruHandler()
    
    def list_virtual_machines(self, resource_group: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        列出虚拟机
        
        :param resource_group: 资源组名称
        :return: 虚拟机列表
        """
        try:
            if resource_group:
                vms = list(self.client.virtual_machines.list(resource_group))
            else:
                vms = list(self.client.virtual_machines.list_all())
            
            vm_list = [vm.as_dict() for vm in vms]
            self.logger.info(f"获取虚拟机列表成功，共 {len(vm_list)} 个虚拟机")
            return vm_list
        except Exception as e:
            self.logger.error(f"获取虚拟机列表失败: {str(e)}")
            raise
    
    def start_virtual_machine(self, resource_group: str, vm_name: str) -> Dict[str, Any]:
        """
        启动虚拟机
        
        :param resource_group: 资源组名称
        :param vm_name: 虚拟机名称
        :return: 操作结果
        """
        try:
            response = self.client.virtual_machines.begin_start(resource_group, vm_name).result()
            self.logger.info(f"启动虚拟机 {vm_name} 成功")
            return response.as_dict() if response else {}
        except Exception as e:
            self.logger.error(f"启动虚拟机 {vm_name} 失败: {str(e)}")
            raise
    
    def stop_virtual_machine(self, resource_group: str, vm_name: str) -> Dict[str, Any]:
        """
        停止虚拟机
        
        :param resource_group: 资源组名称
        :param vm_name: 虚拟机名称
        :return: 操作结果
        """
        try:
            response = self.client.virtual_machines.begin_stop(resource_group, vm_name).result()
            self.logger.info(f"停止虚拟机 {vm_name} 成功")
            return response.as_dict() if response else {}
        except Exception as e:
            self.logger.error(f"停止虚拟机 {vm_name} 失败: {str(e)}")
            raise
    
    def restart_virtual_machine(self, resource_group: str, vm_name: str) -> Dict[str, Any]:
        """
        重启虚拟机
        
        :param resource_group: 资源组名称
        :param vm_name: 虚拟机名称
        :return: 操作结果
        """
        try:
            response = self.client.virtual_machines.begin_restart(resource_group, vm_name).result()
            self.logger.info(f"重启虚拟机 {vm_name} 成功")
            return response.as_dict() if response else {}
        except Exception as e:
            self.logger.error(f"重启虚拟机 {vm_name} 失败: {str(e)}")
            raise
    
    def get_virtual_machine(self, resource_group: str, vm_name: str) -> Dict[str, Any]:
        """
        获取虚拟机信息
        
        :param resource_group: 资源组名称
        :param vm_name: 虚拟机名称
        :return: 虚拟机信息
        """
        try:
            vm = self.client.virtual_machines.get(resource_group, vm_name)
            vm_info = vm.as_dict()
            self.logger.info(f"获取虚拟机 {vm_name} 信息成功")
            return vm_info
        except Exception as e:
            self.logger.error(f"获取虚拟机 {vm_name} 信息失败: {str(e)}")
            raise