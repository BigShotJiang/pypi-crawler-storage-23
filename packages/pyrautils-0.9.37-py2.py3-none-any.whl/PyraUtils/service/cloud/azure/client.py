# -*- coding: utf-8 -*-
"""
Azure API 客户端
"""

from typing import Dict, Any, Optional
from PyraUtils.log import LoguruHandler


try:
    from azure.identity import ClientSecretCredential, DefaultAzureCredential
    from azure.mgmt.compute import ComputeManagementClient
    from azure.mgmt.storage import StorageManagementClient
    from azure.mgmt.resource import ResourceManagementClient
    from azure.mgmt.dns import DnsManagementClient
    from azure.mgmt.sql import SqlManagementClient
    from azure.mgmt.redis import RedisManagementClient
    AZURE_SDK_AVAILABLE = True
except ImportError:
    AZURE_SDK_AVAILABLE = False


class AzureCloudClient:
    """
    Azure API 客户端
    """
    
    def __init__(self, tenant_id: str, client_id: str, client_secret: str, subscription_id: str, timeout: int = 30, max_retries: int = 3):
        """
        初始化 Azure 客户端
        
        :param tenant_id: 租户 ID
        :param client_id: 客户端 ID
        :param client_secret: 客户端密钥
        :param subscription_id: 订阅 ID
        :param timeout: 请求超时时间（秒）
        :param max_retries: 最大重试次数
        """
        self.tenant_id = tenant_id
        self.client_id = client_id
        self.client_secret = client_secret
        self.subscription_id = subscription_id
        self.timeout = timeout
        self.max_retries = max_retries
        self.logger = LoguruHandler()
        
        if not AZURE_SDK_AVAILABLE:
            self.logger.warning("Azure SDK 未安装，将使用 API 调用方式")
        
        # 创建凭证
        self.credential = ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
    
    def get_client(self, service: str) -> Any:
        """
        获取指定服务的客户端
        
        :param service: 服务名称
        :return: 服务客户端
        """
        if not AZURE_SDK_AVAILABLE:
            raise ImportError("Azure SDK 未安装，请运行 'pip install azure-identity azure-mgmt-compute azure-mgmt-storage azure-mgmt-resource azure-mgmt-dns azure-mgmt-sql azure-mgmt-redis' 安装")
        
        if service == 'compute':
            return ComputeManagementClient(self.credential, self.subscription_id)
        elif service == 'storage':
            return StorageManagementClient(self.credential, self.subscription_id)
        elif service == 'resource':
            return ResourceManagementClient(self.credential, self.subscription_id)
        elif service == 'dns':
            return DnsManagementClient(self.credential, self.subscription_id)
        elif service == 'sql':
            return SqlManagementClient(self.credential, self.subscription_id)
        elif service == 'redis':
            return RedisManagementClient(self.credential, self.subscription_id)
        else:
            raise ValueError(f"不支持的服务: {service}")
    
    def request(self, action: str, params: Dict[str, Any], service: str = 'compute') -> Dict[str, Any]:
        """
        发送 API 请求
        
        :param action: API 操作名称
        :param params: 请求参数
        :param service: 服务名称
        :return: 响应结果
        :raises Exception: 请求失败时抛出异常
        """
        try:
            client = self.get_client(service)
            
            self.logger.debug(f"发送 Azure API 请求: {action}, 服务: {service}")
            
            # 调用对应方法
            response = getattr(client, action)(**params)
            
            # 转换响应为字典
            if hasattr(response, 'as_dict'):
                result = response.as_dict()
            else:
                # 对于迭代器类型的响应
                result = [item.as_dict() for item in response]
            
            self.logger.debug(f"Azure API 请求成功: {action}")
            
            return result
        except Exception as e:
            error_msg = f"Azure API 处理失败: {str(e)}"
            self.logger.error(error_msg)
            raise