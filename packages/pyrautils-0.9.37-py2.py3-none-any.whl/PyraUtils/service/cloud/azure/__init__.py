# -*- coding: utf-8 -*-
"""
Azure 云服务模块
"""

from .client import AzureCloudClient

__all__ = ['AzureCloudClient']