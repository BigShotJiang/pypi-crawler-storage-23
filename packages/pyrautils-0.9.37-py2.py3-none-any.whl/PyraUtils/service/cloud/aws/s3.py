# -*- coding: utf-8 -*-
"""
AWS S3 服务
"""

from typing import List, Dict, Any, Optional
from PyraUtils.log import LoguruHandler


class AwsS3Service:
    """
    AWS S3 服务
    """
    
    def __init__(self, client):
        """
        初始化 S3 服务
        
        :param client: AWS 客户端
        """
        self.client = client
        self.logger = LoguruHandler()
    
    def list_buckets(self) -> Dict[str, Any]:
        """
        列出所有存储桶
        
        :return: 存储桶列表
        """
        try:
            response = self.client.list_buckets()
            self.logger.info(f"获取 S3 存储桶列表成功，共 {len(response['Buckets'])} 个存储桶")
            return response
        except Exception as e:
            self.logger.error(f"获取 S3 存储桶列表失败: {str(e)}")
            raise
    
    def create_bucket(self, bucket_name: str, region: Optional[str] = None) -> Dict[str, Any]:
        """
        创建存储桶
        
        :param bucket_name: 存储桶名称
        :param region: 区域
        :return: 操作结果
        """
        try:
            params = {'Bucket': bucket_name}
            if region:
                params['CreateBucketConfiguration'] = {
                    'LocationConstraint': region
                }
            
            response = self.client.create_bucket(**params)
            self.logger.info(f"创建 S3 存储桶 {bucket_name} 成功")
            return response
        except Exception as e:
            self.logger.error(f"创建 S3 存储桶 {bucket_name} 失败: {str(e)}")
            raise
    
    def delete_bucket(self, bucket_name: str) -> Dict[str, Any]:
        """
        删除存储桶
        
        :param bucket_name: 存储桶名称
        :return: 操作结果
        """
        try:
            response = self.client.delete_bucket(Bucket=bucket_name)
            self.logger.info(f"删除 S3 存储桶 {bucket_name} 成功")
            return response
        except Exception as e:
            self.logger.error(f"删除 S3 存储桶 {bucket_name} 失败: {str(e)}")
            raise
    
    def list_objects(self, bucket_name: str, prefix: Optional[str] = None) -> Dict[str, Any]:
        """
        列出存储桶中的对象
        
        :param bucket_name: 存储桶名称
        :param prefix: 前缀
        :return: 对象列表
        """
        try:
            params = {'Bucket': bucket_name}
            if prefix:
                params['Prefix'] = prefix
            
            response = self.client.list_objects_v2(**params)
            object_count = response.get('KeyCount', 0)
            self.logger.info(f"获取 S3 存储桶 {bucket_name} 中的对象成功，共 {object_count} 个对象")
            return response
        except Exception as e:
            self.logger.error(f"获取 S3 存储桶 {bucket_name} 中的对象失败: {str(e)}")
            raise
    
    def put_object(self, bucket_name: str, key: str, body: bytes, **kwargs) -> Dict[str, Any]:
        """
        上传对象
        
        :param bucket_name: 存储桶名称
        :param key: 对象键
        :param body: 对象内容
        :param kwargs: 其他参数
        :return: 操作结果
        """
        try:
            params = {
                'Bucket': bucket_name,
                'Key': key,
                'Body': body,
                **kwargs
            }
            
            response = self.client.put_object(**params)
            self.logger.info(f"上传 S3 对象 {key} 到存储桶 {bucket_name} 成功")
            return response
        except Exception as e:
            self.logger.error(f"上传 S3 对象 {key} 到存储桶 {bucket_name} 失败: {str(e)}")
            raise
    
    def get_object(self, bucket_name: str, key: str) -> Dict[str, Any]:
        """
        下载对象
        
        :param bucket_name: 存储桶名称
        :param key: 对象键
        :return: 对象内容
        """
        try:
            response = self.client.get_object(Bucket=bucket_name, Key=key)
            self.logger.info(f"下载 S3 对象 {key} 从存储桶 {bucket_name} 成功")
            return response
        except Exception as e:
            self.logger.error(f"下载 S3 对象 {key} 从存储桶 {bucket_name} 失败: {str(e)}")
            raise
    
    def delete_object(self, bucket_name: str, key: str) -> Dict[str, Any]:
        """
        删除对象
        
        :param bucket_name: 存储桶名称
        :param key: 对象键
        :return: 操作结果
        """
        try:
            response = self.client.delete_object(Bucket=bucket_name, Key=key)
            self.logger.info(f"删除 S3 对象 {key} 从存储桶 {bucket_name} 成功")
            return response
        except Exception as e:
            self.logger.error(f"删除 S3 对象 {key} 从存储桶 {bucket_name} 失败: {str(e)}")
            raise