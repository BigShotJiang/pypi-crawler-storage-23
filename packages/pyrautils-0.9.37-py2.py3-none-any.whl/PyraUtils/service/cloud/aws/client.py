# -*- coding: utf-8 -*-
"""
AWS API 客户端
"""

from typing import Dict, Any, Optional
from PyraUtils.log import LoguruHandler


try:
    import boto3
    from botocore.exceptions import BotoCoreError, ClientError
    AWS_SDK_AVAILABLE = True
except ImportError:
    AWS_SDK_AVAILABLE = False


class AwsCloudClient:
    """
    AWS API 客户端
    """
    
    def __init__(self, region: str, access_key: str, secret_key: str, session_token: Optional[str] = None, timeout: int = 30, max_retries: int = 3):
        """
        初始化 AWS 客户端
        
        :param region: 区域名称，如 us-east-1
        :param access_key: 访问密钥
        :param secret_key: 安全密钥
        :param session_token: 会话令牌（可选）
        :param timeout: 请求超时时间（秒）
        :param max_retries: 最大重试次数
        """
        self.region = region
        self.access_key = access_key
        self.secret_key = secret_key
        self.session_token = session_token
        self.timeout = timeout
        self.max_retries = max_retries
        self.logger = LoguruHandler()
        
        if not AWS_SDK_AVAILABLE:
            self.logger.warning("AWS SDK 未安装，将使用 API 调用方式")
        
        # 配置客户端
        self.config = {
            'region_name': region,
            'aws_access_key_id': access_key,
            'aws_secret_access_key': secret_key,
            'retries': {
                'max_attempts': max_retries,
                'mode': 'standard'
            }
        }
        
        if session_token:
            self.config['aws_session_token'] = session_token
    
    def get_client(self, service: str) -> Any:
        """
        获取指定服务的客户端
        
        :param service: 服务名称
        :return: 服务客户端
        """
        if not AWS_SDK_AVAILABLE:
            raise ImportError("AWS SDK 未安装，请运行 'pip install boto3' 安装")
        
        return boto3.client(service, **self.config)
    
    def request(self, action: str, params: Dict[str, Any], service: str = 'ec2') -> Dict[str, Any]:
        """
        发送 API 请求
        
        :param action: API 操作名称
        :param params: 请求参数
        :param service: 服务名称
        :return: 响应结果
        :raises Exception: 请求失败时抛出异常
        """
        try:
            client = self.get_client(service)
            
            self.logger.debug(f"发送 AWS API 请求: {action}, 服务: {service}")
            
            # 调用对应方法
            response = getattr(client, action)(**params)
            
            self.logger.debug(f"AWS API 请求成功: {action}")
            
            return response
        except (BotoCoreError, ClientError) as e:
            error_msg = f"AWS API 错误: {str(e)}"
            self.logger.error(error_msg)
            raise
        except Exception as e:
            error_msg = f"AWS API 处理失败: {str(e)}"
            self.logger.error(error_msg)
            raise