# -*- coding: utf-8 -*-
"""
AWS EC2 服务
"""

from typing import List, Dict, Any, Optional
from PyraUtils.log import LoguruHandler


class AwsEC2Service:
    """
    AWS EC2 服务
    """
    
    def __init__(self, client):
        """
        初始化 EC2 服务
        
        :param client: AWS 客户端
        """
        self.client = client
        self.logger = LoguruHandler()
    
    def describe_instances(self, instance_ids: Optional[List[str]] = None, filters: Optional[List[Dict]] = None) -> Dict[str, Any]:
        """
        描述 EC2 实例
        
        :param instance_ids: 实例 ID 列表
        :param filters: 过滤器
        :return: 实例信息
        """
        try:
            params = {}
            if instance_ids:
                params['InstanceIds'] = instance_ids
            if filters:
                params['Filters'] = filters
            
            response = self.client.describe_instances(**params)
            self.logger.info(f"获取 EC2 实例信息成功，共 {len(response['Reservations'])} 个预留实例")
            return response
        except Exception as e:
            self.logger.error(f"获取 EC2 实例信息失败: {str(e)}")
            raise
    
    def start_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        启动 EC2 实例
        
        :param instance_id: 实例 ID
        :return: 操作结果
        """
        try:
            response = self.client.start_instances(InstanceIds=[instance_id])
            self.logger.info(f"启动 EC2 实例 {instance_id} 成功")
            return response
        except Exception as e:
            self.logger.error(f"启动 EC2 实例 {instance_id} 失败: {str(e)}")
            raise
    
    def stop_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        停止 EC2 实例
        
        :param instance_id: 实例 ID
        :return: 操作结果
        """
        try:
            response = self.client.stop_instances(InstanceIds=[instance_id])
            self.logger.info(f"停止 EC2 实例 {instance_id} 成功")
            return response
        except Exception as e:
            self.logger.error(f"停止 EC2 实例 {instance_id} 失败: {str(e)}")
            raise
    
    def reboot_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        重启 EC2 实例
        
        :param instance_id: 实例 ID
        :return: 操作结果
        """
        try:
            response = self.client.reboot_instances(InstanceIds=[instance_id])
            self.logger.info(f"重启 EC2 实例 {instance_id} 成功")
            return response
        except Exception as e:
            self.logger.error(f"重启 EC2 实例 {instance_id} 失败: {str(e)}")
            raise
    
    def create_instance(self, image_id: str, instance_type: str, min_count: int = 1, max_count: int = 1, **kwargs) -> Dict[str, Any]:
        """
        创建 EC2 实例
        
        :param image_id: 镜像 ID
        :param instance_type: 实例类型
        :param min_count: 最小实例数
        :param max_count: 最大实例数
        :param kwargs: 其他参数
        :return: 操作结果
        """
        try:
            params = {
                'ImageId': image_id,
                'InstanceType': instance_type,
                'MinCount': min_count,
                'MaxCount': max_count,
                **kwargs
            }
            
            response = self.client.run_instances(**params)
            self.logger.info(f"创建 EC2 实例成功，共 {len(response['Instances'])} 个实例")
            return response
        except Exception as e:
            self.logger.error(f"创建 EC2 实例失败: {str(e)}")
            raise
    
    def terminate_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        终止 EC2 实例
        
        :param instance_id: 实例 ID
        :return: 操作结果
        """
        try:
            response = self.client.terminate_instances(InstanceIds=[instance_id])
            self.logger.info(f"终止 EC2 实例 {instance_id} 成功")
            return response
        except Exception as e:
            self.logger.error(f"终止 EC2 实例 {instance_id} 失败: {str(e)}")
            raise