# -*- coding: utf-8 -*-
"""
AWS 云服务模块
"""

from .client import AwsCloudClient

__all__ = ['AwsCloudClient']