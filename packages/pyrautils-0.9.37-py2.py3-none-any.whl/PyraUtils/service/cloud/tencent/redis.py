# -*- coding: utf-8 -*-
"""
腾讯云 Redis 服务
"""

from typing import Dict, Any, Optional, List
from PyraUtils.service.cloud.tencent.client import TencentCloudClient
from PyraUtils.service.cloud.tencent.client import TENCENT_SDK_AVAILABLE


class TencentCloudRedisService:
    """
    腾讯云 Redis 服务
    """
    
    def __init__(self, client: TencentCloudClient):
        """
        初始化 Redis 服务
        
        :param client: 腾讯云客户端
        """
        self.client = client
        self.logger = client.logger
    
    def create_instance(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        创建 Redis 实例
        
        :param params: 创建参数
        :return: 创建结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.redis.v20180412 import models as redis_models
                client = self.client.get_client('redis')
                req = redis_models.CreateInstancesRequest()
                for key, value in params.items():
                    setattr(req, key, value)
                resp = client.CreateInstances(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug("使用腾讯云 Redis SDK 创建实例成功")
                return result
            else:
                result = self.client.request('CreateInstances', params, '2018-04-12', 'redis')
                self.logger.debug("使用 API 调用创建实例成功")
                return result
        except Exception as e:
            error_msg = f"创建 Redis 实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def resize_instance(self, instance_id: str, new_spec: Dict[str, Any]) -> Dict[str, Any]:
        """
        调整 Redis 实例规格
        
        :param instance_id: 实例 ID
        :param new_spec: 新规格
        :return: 调整结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.redis.v20180412 import models as redis_models
                client = self.client.get_client('redis')
                req = redis_models.UpgradeInstanceRequest()
                req.InstanceId = instance_id
                for key, value in new_spec.items():
                    setattr(req, key, value)
                resp = client.UpgradeInstance(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 Redis SDK 调整实例规格成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    **new_spec
                }
                result = self.client.request('UpgradeInstance', params, '2018-04-12', 'redis')
                self.logger.debug(f"使用 API 调用调整实例规格成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"调整 Redis 实例规格失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def list_instances(self, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        列出 Redis 实例
        
        :param params: 查询参数
        :return: 实例列表
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.redis.v20180412 import models as redis_models
                client = self.client.get_client('redis')
                req = redis_models.DescribeInstancesRequest()
                if params:
                    for key, value in params.items():
                        setattr(req, key, value)
                resp = client.DescribeInstances(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug("使用腾讯云 Redis SDK 列出实例成功")
                return result.get('Response', {}).get('InstanceSet', [])
            else:
                params = params or {}
                response = self.client.request('DescribeInstances', params, '2018-04-12', 'redis')
                self.logger.debug("使用 API 调用列出实例成功")
                return response.get('Response', {}).get('InstanceSet', [])
        except Exception as e:
            error_msg = f"列出 Redis 实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
