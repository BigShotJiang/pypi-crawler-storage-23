# -*- coding: utf-8 -*-
"""
腾讯云短信服务
"""

from typing import Dict, Any, Optional, List
from PyraUtils.service.cloud.tencent.client import TencentCloudClient
from PyraUtils.service.cloud.tencent.client import TENCENT_SDK_AVAILABLE


class TencentCloudSMSService:
    """
    腾讯云短信服务
    """
    
    def __init__(self, client: TencentCloudClient):
        """
        初始化短信服务
        
        :param client: 腾讯云客户端
        """
        self.client = client
        self.logger = client.logger
    
    def send_sms(self, phone_numbers: List[str], template_id: str, sign_name: str, template_params: Dict[str, str]) -> Dict[str, Any]:
        """
        发送短信
        
        :param phone_numbers: 手机号码列表
        :param template_id: 模板 ID
        :param sign_name: 签名名称
        :param template_params: 模板参数
        :return: 发送结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.sms.v20210111 import models as sms_models
                client = self.client.get_client('sms')
                req = sms_models.SendSmsRequest()
                req.PhoneNumberSet = phone_numbers
                req.TemplateID = template_id
                req.SignName = sign_name
                req.TemplateParamSet = [str(v) for v in template_params.values()]
                resp = client.SendSms(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 SMS SDK 发送短信成功")
                return result
            else:
                params = {
                    'PhoneNumberSet': phone_numbers,
                    'TemplateID': template_id,
                    'SignName': sign_name,
                    'TemplateParamSet': [str(v) for v in template_params.values()]
                }
                result = self.client.request('SendSms', params, '2021-01-11', 'sms')
                self.logger.debug(f"使用 API 调用发送短信成功")
                return result
        except Exception as e:
            error_msg = f"发送短信失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def send_batch_sms(self, phone_numbers: List[str], template_id: str, sign_name: str, template_params_list: List[Dict[str, str]]) -> Dict[str, Any]:
        """
        批量发送短信
        
        :param phone_numbers: 手机号码列表
        :param template_id: 模板 ID
        :param sign_name: 签名名称
        :param template_params_list: 模板参数列表
        :return: 发送结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.sms.v20210111 import models as sms_models
                client = self.client.get_client('sms')
                req = sms_models.SendBatchSmsRequest()
                req.PhoneNumberSet = phone_numbers
                req.TemplateID = template_id
                req.SignName = sign_name
                req.TemplateParamSetList = [[str(v) for v in params.values()] for params in template_params_list]
                resp = client.SendBatchSms(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 SMS SDK 批量发送短信成功")
                return result
            else:
                params = {
                    'PhoneNumberSet': phone_numbers,
                    'TemplateID': template_id,
                    'SignName': sign_name,
                    'TemplateParamSetList': [[str(v) for v in params.values()] for params in template_params_list]
                }
                result = self.client.request('SendBatchSms', params, '2021-01-11', 'sms')
                self.logger.debug(f"使用 API 调用批量发送短信成功")
                return result
        except Exception as e:
            error_msg = f"批量发送短信失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def pull_sms_send_status(self, send_time: int, limit: int = 100) -> Dict[str, Any]:
        """
        拉取短信发送状态
        
        :param send_time: 发送时间
        :param limit: 拉取数量
        :return: 发送状态
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.sms.v20210111 import models as sms_models
                client = self.client.get_client('sms')
                req = sms_models.PullSmsSendStatusRequest()
                req.SendDateTime = send_time
                req.Limit = limit
                resp = client.PullSmsSendStatus(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 SMS SDK 拉取短信发送状态成功")
                return result
            else:
                params = {
                    'SendDateTime': send_time,
                    'Limit': limit
                }
                result = self.client.request('PullSmsSendStatus', params, '2021-01-11', 'sms')
                self.logger.debug(f"使用 API 调用拉取短信发送状态成功")
                return result
        except Exception as e:
            error_msg = f"拉取短信发送状态失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def add_sms_sign(self, sign_name: str, sign_source: int, document_type: int, image: str) -> Dict[str, Any]:
        """
        申请短信签名
        
        :param sign_name: 签名名称
        :param sign_source: 签名来源
        :param document_type: 证明类型
        :param image: 证明图片
        :return: 申请结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.sms.v20210111 import models as sms_models
                client = self.client.get_client('sms')
                req = sms_models.AddSmsSignRequest()
                req.SignName = sign_name
                req.SignSource = sign_source
                req.DocumentType = document_type
                req.ProofImage = image
                resp = client.AddSmsSign(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 SMS SDK 申请短信签名成功: {sign_name}")
                return result
            else:
                params = {
                    'SignName': sign_name,
                    'SignSource': sign_source,
                    'DocumentType': document_type,
                    'ProofImage': image
                }
                result = self.client.request('AddSmsSign', params, '2021-01-11', 'sms')
                self.logger.debug(f"使用 API 调用申请短信签名成功: {sign_name}")
                return result
        except Exception as e:
            error_msg = f"申请短信签名失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def add_sms_template(self, template_name: str, template_content: str, template_type: int, remark: str) -> Dict[str, Any]:
        """
        申请短信模板
        
        :param template_name: 模板名称
        :param template_content: 模板内容
        :param template_type: 模板类型
        :param remark: 备注
        :return: 申请结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.sms.v20210111 import models as sms_models
                client = self.client.get_client('sms')
                req = sms_models.AddSmsTemplateRequest()
                req.TemplateName = template_name
                req.TemplateContent = template_content
                req.TemplateType = template_type
                req.Remark = remark
                resp = client.AddSmsTemplate(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 SMS SDK 申请短信模板成功: {template_name}")
                return result
            else:
                params = {
                    'TemplateName': template_name,
                    'TemplateContent': template_content,
                    'TemplateType': template_type,
                    'Remark': remark
                }
                result = self.client.request('AddSmsTemplate', params, '2021-01-11', 'sms')
                self.logger.debug(f"使用 API 调用申请短信模板成功: {template_name}")
                return result
        except Exception as e:
            error_msg = f"申请短信模板失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def get_sms_sign_list(self, limit: int = 20, offset: int = 0) -> List[Dict[str, Any]]:
        """
        获取短信签名列表
        
        :param limit: 数量限制
        :param offset: 偏移量
        :return: 签名列表
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.sms.v20210111 import models as sms_models
                client = self.client.get_client('sms')
                req = sms_models.DescribeSmsSignListRequest()
                req.Limit = limit
                req.Offset = offset
                resp = client.DescribeSmsSignList(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug("使用腾讯云 SMS SDK 获取短信签名列表成功")
                return result.get('Response', {}).get('SignList', [])
            else:
                params = {
                    'Limit': limit,
                    'Offset': offset
                }
                response = self.client.request('DescribeSmsSignList', params, '2021-01-11', 'sms')
                self.logger.debug("使用 API 调用获取短信签名列表成功")
                return response.get('Response', {}).get('SignList', [])
        except Exception as e:
            error_msg = f"获取短信签名列表失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def get_sms_template_list(self, limit: int = 20, offset: int = 0) -> List[Dict[str, Any]]:
        """
        获取短信模板列表
        
        :param limit: 数量限制
        :param offset: 偏移量
        :return: 模板列表
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.sms.v20210111 import models as sms_models
                client = self.client.get_client('sms')
                req = sms_models.DescribeSmsTemplateListRequest()
                req.Limit = limit
                req.Offset = offset
                resp = client.DescribeSmsTemplateList(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug("使用腾讯云 SMS SDK 获取短信模板列表成功")
                return result.get('Response', {}).get('TemplateList', [])
            else:
                params = {
                    'Limit': limit,
                    'Offset': offset
                }
                response = self.client.request('DescribeSmsTemplateList', params, '2021-01-11', 'sms')
                self.logger.debug("使用 API 调用获取短信模板列表成功")
                return response.get('Response', {}).get('TemplateList', [])
        except Exception as e:
            error_msg = f"获取短信模板列表失败: {str(e)}"
            self.logger.error(error_msg)
            raise
