# -*- coding: utf-8 -*-
"""
腾讯云 API 客户端
"""

from typing import Dict, Any, Optional
from PyraUtils.log import LoguruHandler


try:
    from tencentcloud.common import credential
    from tencentcloud.common.profile.client_profile import ClientProfile
    from tencentcloud.common.profile.http_profile import HttpProfile
    from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
    from tencentcloud.cvm.v20170312 import cvm_client, models as cvm_models
    from tencentcloud.rds.v20180322 import rds_client, models as rds_models
    from tencentcloud.redis.v20180412 import redis_client, models as redis_models
    from tencentcloud.dnspod.v20210323 import dnspod_client, models as dnspod_models
    from tencentcloud.cos.v20180606 import cos_client, models as cos_models
    from tencentcloud.sms.v20210111 import sms_client, models as sms_models
    TENCENT_SDK_AVAILABLE = True
except ImportError:
    TENCENT_SDK_AVAILABLE = False


class TencentCloudClient:
    """
    腾讯云 API 客户端
    """
    
    def __init__(self, region: str, access_key: str, secret_key: str, timeout: int = 30, max_retries: int = 3):
        """
        初始化腾讯云客户端
        
        :param region: 区域名称，如 ap-beijing
        :param access_key: 访问密钥
        :param secret_key: 安全密钥
        :param timeout: 请求超时时间（秒）
        :param max_retries: 最大重试次数
        """
        self.region = region
        self.access_key = access_key
        self.secret_key = secret_key
        self.timeout = timeout
        self.max_retries = max_retries
        self.logger = LoguruHandler()
        
        if not TENCENT_SDK_AVAILABLE:
            self.logger.warning("腾讯云 SDK 未安装，将使用 API 调用方式")
        
        # 创建凭证
        self.cred = credential.Credential(access_key, secret_key)
        
        # 创建 HTTP 配置
        self.http_profile = HttpProfile()
        self.http_profile.endpoint = "cvm.tencentcloudapi.com"
        self.http_profile.read_timeout = timeout
        self.http_profile.retry = max_retries
        
        # 创建客户端配置
        self.client_profile = ClientProfile()
        self.client_profile.httpProfile = self.http_profile
    
    def get_client(self, service: str) -> Any:
        """
        获取指定服务的客户端
        
        :param service: 服务名称
        :return: 服务客户端
        """
        if not TENCENT_SDK_AVAILABLE:
            raise ImportError("腾讯云 SDK 未安装，请运行 'pip install tencentcloud-sdk-python' 安装")
        
        if service == 'cvm':
            return cvm_client.CvmClient(self.cred, self.region, self.client_profile)
        elif service == 'rds':
            return rds_client.RdsClient(self.cred, self.region, self.client_profile)
        elif service == 'redis':
            return redis_client.RedisClient(self.cred, self.region, self.client_profile)
        elif service == 'dnspod':
            return dnspod_client.DnspodClient(self.cred, "", self.client_profile)
        elif service == 'cos':
            return cos_client.CosClient(self.cred, self.region, self.client_profile)
        elif service == 'sms':
            return sms_client.SmsClient(self.cred, self.region, self.client_profile)
        else:
            raise ValueError(f"不支持的服务: {service}")
    
    def request(self, action: str, params: Dict[str, Any], version: str, service: str = 'cvm') -> Dict[str, Any]:
        """
        发送 API 请求
        
        :param action: API 操作名称
        :param params: 请求参数
        :param version: API 版本
        :param service: 服务名称
        :return: 响应结果
        :raises Exception: 请求失败时抛出异常
        """
        try:
            client = self.get_client(service)
            
            # 根据服务和操作名称创建请求对象
            if service == 'cvm':
                req = cvm_models.__dict__.get(f"{action}Request")()
            elif service == 'rds':
                req = rds_models.__dict__.get(f"{action}Request")()
            elif service == 'redis':
                req = redis_models.__dict__.get(f"{action}Request")()
            elif service == 'dnspod':
                req = dnspod_models.__dict__.get(f"{action}Request")()
            elif service == 'cos':
                req = cos_models.__dict__.get(f"{action}Request")()
            elif service == 'sms':
                req = sms_models.__dict__.get(f"{action}Request")()
            else:
                raise ValueError(f"不支持的服务: {service}")
            
            # 设置请求参数
            for key, value in params.items():
                setattr(req, key, value)
            
            self.logger.debug(f"发送腾讯云 API 请求: {action}, 服务: {service}, 版本: {version}")
            
            # 发送请求
            resp = client.__dict__.get(action)(req)
            
            # 将响应转换为字典
            result = resp.to_json_string()
            import json
            result_dict = json.loads(result)
            
            self.logger.debug(f"腾讯云 API 请求成功: {action}")
            
            return result_dict
        except TencentCloudSDKException as e:
            error_msg = f"腾讯云 API 错误: {str(e)}"
            self.logger.error(error_msg)
            raise
        except Exception as e:
            self.logger.error(f"腾讯云 API 处理失败: {str(e)}")
            raise
