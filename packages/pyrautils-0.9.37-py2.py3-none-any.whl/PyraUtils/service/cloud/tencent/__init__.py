# -*- coding: utf-8 -*-
"""
腾讯云服务
"""

from .client import TencentCloudClient
from .database import TencentCloudDatabaseService
from .redis import TencentCloudRedisService
from .ecs import TencentCloudECSService
from .dns import TencentCloudDNSService
from .cos import TencentCloudCOSService
from .sms import TencentCloudSMSService
from ..config import CloudConfigManager
from typing import Optional


class TencentCloud:
    """
    腾讯云服务入口
    """
    
    def __init__(self, region: Optional[str] = None, access_key: Optional[str] = None, secret_key: Optional[str] = None, config_manager: Optional[CloudConfigManager] = None):
        """
        初始化腾讯云服务
        
        :param region: 区域名称，如 ap-beijing
        :param access_key: 访问密钥
        :param secret_key: 安全密钥
        :param config_manager: 配置管理器实例
        """
        if config_manager:
            self.region = region or config_manager.get_region('tencent')
            self.access_key = access_key or config_manager.get_access_key('tencent')
            self.secret_key = secret_key or config_manager.get_secret_key('tencent')
        else:
            self.region = region
            self.access_key = access_key
            self.secret_key = secret_key
        
        if not all([self.region, self.access_key, self.secret_key]):
            raise ValueError("缺少必要的配置参数")
        
        self.client = TencentCloudClient(self.region, self.access_key, self.secret_key)
    
    def database(self) -> TencentCloudDatabaseService:
        """
        获取数据库服务
        
        :return: 数据库服务实例
        """
        return TencentCloudDatabaseService(self.client)
    
    def redis(self) -> TencentCloudRedisService:
        """
        获取 Redis 服务
        
        :return: Redis 服务实例
        """
        return TencentCloudRedisService(self.client)
    
    def ecs(self) -> TencentCloudECSService:
        """
        获取 ECS 服务
        
        :return: ECS 服务实例
        """
        return TencentCloudECSService(self.client)
    
    def dns(self) -> TencentCloudDNSService:
        """
        获取 DNS 服务
        
        :return: DNS 服务实例
        """
        return TencentCloudDNSService(self.client)
    
    def cos(self) -> TencentCloudCOSService:
        """
        获取对象存储（COS）服务
        
        :return: COS 服务实例
        """
        return TencentCloudCOSService(self.client)
    
    def sms(self) -> TencentCloudSMSService:
        """
        获取短信服务
        
        :return: 短信服务实例
        """
        return TencentCloudSMSService(self.client)


__all__ = [
    'TencentCloud',
    'TencentCloudClient',
    'TencentCloudDatabaseService',
    'TencentCloudRedisService',
    'TencentCloudECSService',
    'TencentCloudDNSService',
    'TencentCloudCOSService',
    'TencentCloudSMSService'
]
