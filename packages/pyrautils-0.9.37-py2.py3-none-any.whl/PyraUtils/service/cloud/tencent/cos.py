# -*- coding: utf-8 -*-
"""
腾讯云对象存储（COS）服务
"""

from typing import Dict, Any, Optional, List
from PyraUtils.service.cloud.tencent.client import TencentCloudClient
from PyraUtils.service.cloud.tencent.client import TENCENT_SDK_AVAILABLE


class TencentCloudCOSService:
    """
    腾讯云对象存储（COS）服务
    """
    
    def __init__(self, client: TencentCloudClient):
        """
        初始化 COS 服务
        
        :param client: 腾讯云客户端
        """
        self.client = client
        self.logger = client.logger
    
    def create_bucket(self, bucket_name: str, region: str = None) -> Dict[str, Any]:
        """
        创建存储桶
        
        :param bucket_name: 存储桶名称
        :param region: 区域，默认使用客户端区域
        :return: 创建结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cos.v20180606 import models as cos_models
                client = self.client.get_client('cos')
                req = cos_models.CreateBucketRequest()
                req.BucketName = bucket_name
                req.Region = region or self.client.region
                resp = client.CreateBucket(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 COS SDK 创建存储桶成功: {bucket_name}")
                return result
            else:
                params = {
                    'BucketName': bucket_name,
                    'Region': region or self.client.region
                }
                result = self.client.request('CreateBucket', params, '2018-11-26', 'cos')
                self.logger.debug(f"使用 API 调用创建存储桶成功: {bucket_name}")
                return result
        except Exception as e:
            error_msg = f"创建存储桶失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def delete_bucket(self, bucket_name: str) -> Dict[str, Any]:
        """
        删除存储桶
        
        :param bucket_name: 存储桶名称
        :return: 删除结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cos.v20180606 import models as cos_models
                client = self.client.get_client('cos')
                req = cos_models.DeleteBucketRequest()
                req.BucketName = bucket_name
                resp = client.DeleteBucket(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 COS SDK 删除存储桶成功: {bucket_name}")
                return result
            else:
                params = {'BucketName': bucket_name}
                result = self.client.request('DeleteBucket', params, '2018-11-26', 'cos')
                self.logger.debug(f"使用 API 调用删除存储桶成功: {bucket_name}")
                return result
        except Exception as e:
            error_msg = f"删除存储桶失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def put_object(self, bucket_name: str, key: str, content: bytes, **kwargs) -> Dict[str, Any]:
        """
        上传对象
        
        :param bucket_name: 存储桶名称
        :param key: 对象键
        :param content: 对象内容
        :param kwargs: 其他参数
        :return: 上传结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cos.v20180606 import models as cos_models
                client = self.client.get_client('cos')
                req = cos_models.PutObjectRequest()
                req.BucketName = bucket_name
                req.Key = key
                req.Content = content
                for key_param, value in kwargs.items():
                    setattr(req, key_param, value)
                resp = client.PutObject(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 COS SDK 上传对象成功: {key}")
                return result
            else:
                params = {
                    'BucketName': bucket_name,
                    'Key': key,
                    'Content': content,
                    **kwargs
                }
                result = self.client.request('PutObject', params, '2018-11-26', 'cos')
                self.logger.debug(f"使用 API 调用上传对象成功: {key}")
                return result
        except Exception as e:
            error_msg = f"上传对象失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def get_object(self, bucket_name: str, key: str) -> Dict[str, Any]:
        """
        获取对象
        
        :param bucket_name: 存储桶名称
        :param key: 对象键
        :return: 对象内容
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cos.v20180606 import models as cos_models
                client = self.client.get_client('cos')
                req = cos_models.GetObjectRequest()
                req.BucketName = bucket_name
                req.Key = key
                resp = client.GetObject(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 COS SDK 获取对象成功: {key}")
                return result
            else:
                params = {
                    'BucketName': bucket_name,
                    'Key': key
                }
                result = self.client.request('GetObject', params, '2018-11-26', 'cos')
                self.logger.debug(f"使用 API 调用获取对象成功: {key}")
                return result
        except Exception as e:
            error_msg = f"获取对象失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def delete_object(self, bucket_name: str, key: str) -> Dict[str, Any]:
        """
        删除对象
        
        :param bucket_name: 存储桶名称
        :param key: 对象键
        :return: 删除结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cos.v20180606 import models as cos_models
                client = self.client.get_client('cos')
                req = cos_models.DeleteObjectRequest()
                req.BucketName = bucket_name
                req.Key = key
                resp = client.DeleteObject(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 COS SDK 删除对象成功: {key}")
                return result
            else:
                params = {
                    'BucketName': bucket_name,
                    'Key': key
                }
                result = self.client.request('DeleteObject', params, '2018-11-26', 'cos')
                self.logger.debug(f"使用 API 调用删除对象成功: {key}")
                return result
        except Exception as e:
            error_msg = f"删除对象失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def list_objects(self, bucket_name: str, prefix: str = '', max_keys: int = 1000) -> List[Dict[str, Any]]:
        """
        列出对象
        
        :param bucket_name: 存储桶名称
        :param prefix: 前缀
        :param max_keys: 最大返回数量
        :return: 对象列表
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cos.v20180606 import models as cos_models
                client = self.client.get_client('cos')
                req = cos_models.ListObjectsRequest()
                req.BucketName = bucket_name
                req.Prefix = prefix
                req.MaxKeys = max_keys
                resp = client.ListObjects(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 COS SDK 列出对象成功: {bucket_name}")
                return result.get('Response', {}).get('Contents', [])
            else:
                params = {
                    'BucketName': bucket_name,
                    'Prefix': prefix,
                    'MaxKeys': max_keys
                }
                response = self.client.request('ListObjects', params, '2018-11-26', 'cos')
                self.logger.debug(f"使用 API 调用列出对象成功: {bucket_name}")
                return response.get('Response', {}).get('Contents', [])
        except Exception as e:
            error_msg = f"列出对象失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def set_bucket_acl(self, bucket_name: str, acl: str) -> Dict[str, Any]:
        """
        设置存储桶 ACL
        
        :param bucket_name: 存储桶名称
        :param acl: ACL 类型
        :return: 设置结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cos.v20180606 import models as cos_models
                client = self.client.get_client('cos')
                req = cos_models.PutBucketAclRequest()
                req.BucketName = bucket_name
                req.ACL = acl
                resp = client.PutBucketAcl(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 COS SDK 设置存储桶 ACL 成功: {bucket_name}")
                return result
            else:
                params = {
                    'BucketName': bucket_name,
                    'ACL': acl
                }
                result = self.client.request('PutBucketAcl', params, '2018-11-26', 'cos')
                self.logger.debug(f"使用 API 调用设置存储桶 ACL 成功: {bucket_name}")
                return result
        except Exception as e:
            error_msg = f"设置存储桶 ACL 失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def get_bucket_acl(self, bucket_name: str) -> Dict[str, Any]:
        """
        获取存储桶 ACL
        
        :param bucket_name: 存储桶名称
        :return: ACL 信息
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cos.v20180606 import models as cos_models
                client = self.client.get_client('cos')
                req = cos_models.GetBucketAclRequest()
                req.BucketName = bucket_name
                resp = client.GetBucketAcl(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 COS SDK 获取存储桶 ACL 成功: {bucket_name}")
                return result
            else:
                params = {'BucketName': bucket_name}
                result = self.client.request('GetBucketAcl', params, '2018-11-26', 'cos')
                self.logger.debug(f"使用 API 调用获取存储桶 ACL 成功: {bucket_name}")
                return result
        except Exception as e:
            error_msg = f"获取存储桶 ACL 失败: {str(e)}"
            self.logger.error(error_msg)
            raise
