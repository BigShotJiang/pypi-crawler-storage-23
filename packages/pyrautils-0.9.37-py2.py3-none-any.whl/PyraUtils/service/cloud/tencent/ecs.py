# -*- coding: utf-8 -*-
"""
腾讯云 ECS 服务
"""

from typing import Dict, Any, Optional, List
from PyraUtils.service.cloud.tencent.client import TencentCloudClient
from PyraUtils.service.cloud.tencent.client import TENCENT_SDK_AVAILABLE


class TencentCloudECSService:
    """
    腾讯云 ECS 服务
    """
    
    def __init__(self, client: TencentCloudClient):
        """
        初始化 ECS 服务
        
        :param client: 腾讯云客户端
        """
        self.client = client
        self.logger = client.logger
    
    def create_instance(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        创建 ECS 实例
        
        :param params: 创建参数
        :return: 创建结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.RunInstancesRequest()
                for key, value in params.items():
                    setattr(req, key, value)
                resp = client.RunInstances(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug("使用腾讯云 CVM SDK 创建实例成功")
                return result
            else:
                result = self.client.request('RunInstances', params, '2017-03-12', 'cvm')
                self.logger.debug("使用 API 调用创建实例成功")
                return result
        except Exception as e:
            error_msg = f"创建 ECS 实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def start_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        启动 ECS 实例
        
        :param instance_id: 实例 ID
        :return: 启动结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.StartInstancesRequest()
                req.InstanceIds = [instance_id]
                resp = client.StartInstances(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 启动实例成功: {instance_id}")
                return result
            else:
                params = {'InstanceIds': [instance_id]}
                result = self.client.request('StartInstances', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用启动实例成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"启动 ECS 实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def stop_instance(self, instance_id: str, force: bool = False) -> Dict[str, Any]:
        """
        停止 ECS 实例
        
        :param instance_id: 实例 ID
        :param force: 是否强制停止
        :return: 停止结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.StopInstancesRequest()
                req.InstanceIds = [instance_id]
                req.ForceStop = force
                resp = client.StopInstances(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 停止实例成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceIds': [instance_id],
                    'ForceStop': force
                }
                result = self.client.request('StopInstances', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用停止实例成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"停止 ECS 实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def restart_instance(self, instance_id: str, force: bool = False) -> Dict[str, Any]:
        """
        重启 ECS 实例
        
        :param instance_id: 实例 ID
        :param force: 是否强制重启
        :return: 重启结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.RebootInstancesRequest()
                req.InstanceIds = [instance_id]
                req.ForceReboot = force
                resp = client.RebootInstances(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 重启实例成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceIds': [instance_id],
                    'ForceReboot': force
                }
                result = self.client.request('RebootInstances', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用重启实例成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"重启 ECS 实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def list_instances(self, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        列出 ECS 实例
        
        :param params: 查询参数
        :return: 实例列表
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.DescribeInstancesRequest()
                if params:
                    for key, value in params.items():
                        setattr(req, key, value)
                resp = client.DescribeInstances(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug("使用腾讯云 CVM SDK 列出实例成功")
                return result.get('Response', {}).get('InstanceSet', [])
            else:
                params = params or {}
                response = self.client.request('DescribeInstances', params, '2017-03-12', 'cvm')
                self.logger.debug("使用 API 调用列出实例成功")
                return response.get('Response', {}).get('InstanceSet', [])
        except Exception as e:
            error_msg = f"列出 ECS 实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def describe_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        查询 ECS 实例详情
        
        :param instance_id: 实例 ID
        :return: 实例详情
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.DescribeInstancesRequest()
                req.InstanceIds = [instance_id]
                resp = client.DescribeInstances(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 查询实例详情成功: {instance_id}")
                instances = result.get('Response', {}).get('InstanceSet', [])
                return instances[0] if instances else {}
            else:
                params = {'InstanceIds': [instance_id]}
                response = self.client.request('DescribeInstances', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用查询实例详情成功: {instance_id}")
                instances = response.get('Response', {}).get('InstanceSet', [])
                return instances[0] if instances else {}
        except Exception as e:
            error_msg = f"查询 ECS 实例详情失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def modify_instance_attribute(self, instance_id: str, attributes: Dict[str, Any]) -> Dict[str, Any]:
        """
        修改 ECS 实例属性
        
        :param instance_id: 实例 ID
        :param attributes: 要修改的属性
        :return: 修改结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.ModifyInstanceAttributeRequest()
                req.InstanceId = instance_id
                for key, value in attributes.items():
                    setattr(req, key, value)
                resp = client.ModifyInstanceAttribute(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 修改实例属性成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    **attributes
                }
                result = self.client.request('ModifyInstanceAttribute', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用修改实例属性成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"修改 ECS 实例属性失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def resize_instance_spec(self, instance_id: str, instance_type: str) -> Dict[str, Any]:
        """
        调整 ECS 实例规格
        
        :param instance_id: 实例 ID
        :param instance_type: 新的实例规格
        :return: 调整结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.ResizeInstanceRequest()
                req.InstanceId = instance_id
                req.InstanceType = instance_type
                resp = client.ResizeInstance(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 调整实例规格成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'InstanceType': instance_type
                }
                result = self.client.request('ResizeInstance', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用调整实例规格成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"调整 ECS 实例规格失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def release_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        释放 ECS 实例
        
        :param instance_id: 实例 ID
        :return: 释放结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.TerminateInstancesRequest()
                req.InstanceIds = [instance_id]
                resp = client.TerminateInstances(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 释放实例成功: {instance_id}")
                return result
            else:
                params = {'InstanceIds': [instance_id]}
                result = self.client.request('TerminateInstances', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用释放实例成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"释放 ECS 实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def reset_instance_password(self, instance_id: str, password: str, username: str = 'root') -> Dict[str, Any]:
        """
        重置 ECS 实例密码
        
        :param instance_id: 实例 ID
        :param password: 新密码
        :param username: 用户名
        :return: 重置结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.ResetInstancePasswordRequest()
                req.InstanceId = instance_id
                req.Password = password
                req.UserName = username
                resp = client.ResetInstancePassword(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 重置实例密码成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'Password': password,
                    'UserName': username
                }
                result = self.client.request('ResetInstancePassword', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用重置实例密码成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"重置 ECS 实例密码失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def create_image(self, instance_id: str, image_name: str, image_description: str = '') -> Dict[str, Any]:
        """
        创建自定义镜像
        
        :param instance_id: 实例 ID
        :param image_name: 镜像名称
        :param image_description: 镜像描述
        :return: 创建结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.CreateImageRequest()
                req.InstanceId = instance_id
                req.ImageName = image_name
                req.ImageDescription = image_description
                resp = client.CreateImage(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 创建自定义镜像成功: {image_name}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'ImageName': image_name,
                    'ImageDescription': image_description
                }
                result = self.client.request('CreateImage', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用创建自定义镜像成功: {image_name}")
                return result
        except Exception as e:
            error_msg = f"创建自定义镜像失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def list_images(self, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        列出镜像
        
        :param params: 查询参数
        :return: 镜像列表
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.DescribeImagesRequest()
                if params:
                    for key, value in params.items():
                        setattr(req, key, value)
                resp = client.DescribeImages(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug("使用腾讯云 CVM SDK 列出镜像成功")
                return result.get('Response', {}).get('ImageSet', [])
            else:
                params = params or {}
                response = self.client.request('DescribeImages', params, '2017-03-12', 'cvm')
                self.logger.debug("使用 API 调用列出镜像成功")
                return response.get('Response', {}).get('ImageSet', [])
        except Exception as e:
            error_msg = f"列出镜像失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def delete_image(self, image_id: str) -> Dict[str, Any]:
        """
        删除镜像
        
        :param image_id: 镜像 ID
        :return: 删除结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.DeleteImageRequest()
                req.ImageId = image_id
                resp = client.DeleteImage(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 删除镜像成功: {image_id}")
                return result
            else:
                params = {'ImageId': image_id}
                result = self.client.request('DeleteImage', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用删除镜像成功: {image_id}")
                return result
        except Exception as e:
            error_msg = f"删除镜像失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def create_disk(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        创建云盘
        
        :param params: 创建参数
        :return: 创建结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.CreateDisksRequest()
                for key, value in params.items():
                    setattr(req, key, value)
                resp = client.CreateDisks(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug("使用腾讯云 CVM SDK 创建云盘成功")
                return result
            else:
                result = self.client.request('CreateDisks', params, '2017-03-12', 'cvm')
                self.logger.debug("使用 API 调用创建云盘成功")
                return result
        except Exception as e:
            error_msg = f"创建云盘失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def attach_disk(self, instance_id: str, disk_id: str) -> Dict[str, Any]:
        """
        挂载云盘
        
        :param instance_id: 实例 ID
        :param disk_id: 云盘 ID
        :return: 挂载结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.AttachDisksRequest()
                req.InstanceId = instance_id
                req.DiskIds = [disk_id]
                resp = client.AttachDisks(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 挂载云盘成功: {disk_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'DiskIds': [disk_id]
                }
                result = self.client.request('AttachDisks', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用挂载云盘成功: {disk_id}")
                return result
        except Exception as e:
            error_msg = f"挂载云盘失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def detach_disk(self, instance_id: str, disk_id: str) -> Dict[str, Any]:
        """
        卸载云盘
        
        :param instance_id: 实例 ID
        :param disk_id: 云盘 ID
        :return: 卸载结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.DetachDisksRequest()
                req.InstanceId = instance_id
                req.DiskIds = [disk_id]
                resp = client.DetachDisks(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 卸载云盘成功: {disk_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'DiskIds': [disk_id]
                }
                result = self.client.request('DetachDisks', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用卸载云盘成功: {disk_id}")
                return result
        except Exception as e:
            error_msg = f"卸载云盘失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def resize_disk(self, disk_id: str, new_size: int) -> Dict[str, Any]:
        """
        扩容云盘
        
        :param disk_id: 云盘 ID
        :param new_size: 新的云盘大小（GB）
        :return: 扩容结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.ResizeDiskRequest()
                req.DiskId = disk_id
                req.DiskSize = new_size
                resp = client.ResizeDisk(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 扩容云盘成功: {disk_id}")
                return result
            else:
                params = {
                    'DiskId': disk_id,
                    'DiskSize': new_size
                }
                result = self.client.request('ResizeDisk', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用扩容云盘成功: {disk_id}")
                return result
        except Exception as e:
            error_msg = f"扩容云盘失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def delete_disk(self, disk_id: str) -> Dict[str, Any]:
        """
        删除云盘
        
        :param disk_id: 云盘 ID
        :return: 删除结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cvm.v20170312 import models as cvm_models
                client = self.client.get_client('cvm')
                req = cvm_models.DeleteDisksRequest()
                req.DiskIds = [disk_id]
                resp = client.DeleteDisks(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 CVM SDK 删除云盘成功: {disk_id}")
                return result
            else:
                params = {'DiskIds': [disk_id]}
                result = self.client.request('DeleteDisks', params, '2017-03-12', 'cvm')
                self.logger.debug(f"使用 API 调用删除云盘成功: {disk_id}")
                return result
        except Exception as e:
            error_msg = f"删除云盘失败: {str(e)}"
            self.logger.error(error_msg)
            raise
