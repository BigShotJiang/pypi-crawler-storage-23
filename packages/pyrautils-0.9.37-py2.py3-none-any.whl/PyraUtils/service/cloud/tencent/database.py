# -*- coding: utf-8 -*-
"""
腾讯云数据库服务
"""

from typing import Dict, Any, Optional, List
from PyraUtils.service.cloud.tencent.client import TencentCloudClient
from PyraUtils.service.cloud.tencent.client import TENCENT_SDK_AVAILABLE


class TencentCloudDatabaseService:
    """
    腾讯云数据库服务
    """
    
    def __init__(self, client: TencentCloudClient):
        """
        初始化数据库服务
        
        :param client: 腾讯云客户端
        """
        self.client = client
        self.logger = client.logger
    
    def create_instance(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        创建数据库实例
        
        :param params: 创建参数
        :return: 创建结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.CreateDBInstanceRequest()
                for key, value in params.items():
                    setattr(req, key, value)
                resp = client.CreateDBInstance(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug("使用腾讯云 RDS SDK 创建实例成功")
                return result
            else:
                result = self.client.request('CreateDBInstance', params, '2018-03-20', 'cdb')
                self.logger.debug("使用 API 调用创建实例成功")
                return result
        except Exception as e:
            error_msg = f"创建数据库实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def resize_instance(self, instance_id: str, new_spec: Dict[str, Any]) -> Dict[str, Any]:
        """
        调整数据库实例规格
        
        :param instance_id: 实例 ID
        :param new_spec: 新规格
        :return: 调整结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.UpgradeDBInstanceRequest()
                req.InstanceId = instance_id
                for key, value in new_spec.items():
                    setattr(req, key, value)
                resp = client.UpgradeDBInstance(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 调整实例规格成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    **new_spec
                }
                result = self.client.request('UpgradeDBInstance', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用调整实例规格成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"调整数据库实例规格失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def create_user(self, instance_id: str, user_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        创建数据库用户
        
        :param instance_id: 实例 ID
        :param user_info: 用户信息
        :return: 创建结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.CreateDBInstanceUserRequest()
                req.InstanceId = instance_id
                for key, value in user_info.items():
                    setattr(req, key, value)
                resp = client.CreateDBInstanceUser(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 创建用户成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    **user_info
                }
                result = self.client.request('CreateDBInstanceUser', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用创建用户成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"创建数据库用户失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def grant_privilege(self, instance_id: str, user_name: str, privileges: Dict[str, Any]) -> Dict[str, Any]:
        """
        授权数据库用户
        
        :param instance_id: 实例 ID
        :param user_name: 用户名
        :param privileges: 权限信息
        :return: 授权结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.GrantDBInstancePrivilegeRequest()
                req.InstanceId = instance_id
                req.UserName = user_name
                for key, value in privileges.items():
                    setattr(req, key, value)
                resp = client.GrantDBInstancePrivilege(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 授权用户成功: {user_name}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'UserName': user_name,
                    **privileges
                }
                result = self.client.request('GrantDBInstancePrivilege', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用授权用户成功: {user_name}")
                return result
        except Exception as e:
            error_msg = f"授权数据库用户失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def list_instances(self, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        列出数据库实例
        
        :param params: 查询参数
        :return: 实例列表
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.DescribeDBInstancesRequest()
                if params:
                    for key, value in params.items():
                        setattr(req, key, value)
                resp = client.DescribeDBInstances(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug("使用腾讯云 RDS SDK 列出实例成功")
                return result.get('Response', {}).get('Items', [])
            else:
                params = params or {}
                response = self.client.request('DescribeDBInstances', params, '2018-03-20', 'cdb')
                self.logger.debug("使用 API 调用列出实例成功")
                return response.get('Response', {}).get('Items', [])
        except Exception as e:
            error_msg = f"列出数据库实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def describe_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        查询数据库实例详情
        
        :param instance_id: 实例 ID
        :return: 实例详情
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.DescribeDBInstanceDetailRequest()
                req.InstanceId = instance_id
                resp = client.DescribeDBInstanceDetail(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 查询实例详情成功: {instance_id}")
                return result.get('Response', {}).get('Instance', {})
            else:
                params = {'InstanceId': instance_id}
                response = self.client.request('DescribeDBInstanceDetail', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用查询实例详情成功: {instance_id}")
                return response.get('Response', {}).get('Instance', {})
        except Exception as e:
            error_msg = f"查询数据库实例详情失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def start_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        启动数据库实例
        
        :param instance_id: 实例 ID
        :return: 启动结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.StartDBInstanceRequest()
                req.InstanceId = instance_id
                resp = client.StartDBInstance(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 启动实例成功: {instance_id}")
                return result
            else:
                params = {'InstanceId': instance_id}
                result = self.client.request('StartDBInstance', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用启动实例成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"启动数据库实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def stop_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        停止数据库实例
        
        :param instance_id: 实例 ID
        :return: 停止结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.StopDBInstanceRequest()
                req.InstanceId = instance_id
                resp = client.StopDBInstance(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 停止实例成功: {instance_id}")
                return result
            else:
                params = {'InstanceId': instance_id}
                result = self.client.request('StopDBInstance', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用停止实例成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"停止数据库实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def restart_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        重启数据库实例
        
        :param instance_id: 实例 ID
        :return: 重启结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.RestartDBInstanceRequest()
                req.InstanceId = instance_id
                resp = client.RestartDBInstance(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 重启实例成功: {instance_id}")
                return result
            else:
                params = {'InstanceId': instance_id}
                result = self.client.request('RestartDBInstance', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用重启实例成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"重启数据库实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def delete_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        删除数据库实例
        
        :param instance_id: 实例 ID
        :return: 删除结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.DeleteDBInstanceRequest()
                req.InstanceId = instance_id
                resp = client.DeleteDBInstance(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 删除实例成功: {instance_id}")
                return result
            else:
                params = {'InstanceId': instance_id}
                result = self.client.request('DeleteDBInstance', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用删除实例成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"删除数据库实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def modify_instance_attribute(self, instance_id: str, attributes: Dict[str, Any]) -> Dict[str, Any]:
        """
        修改数据库实例属性
        
        :param instance_id: 实例 ID
        :param attributes: 要修改的属性
        :return: 修改结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.ModifyDBInstanceAttributeRequest()
                req.InstanceId = instance_id
                for key, value in attributes.items():
                    setattr(req, key, value)
                resp = client.ModifyDBInstanceAttribute(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 修改实例属性成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    **attributes
                }
                result = self.client.request('ModifyDBInstanceAttribute', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用修改实例属性成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"修改数据库实例属性失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def list_users(self, instance_id: str) -> List[Dict[str, Any]]:
        """
        列出数据库用户
        
        :param instance_id: 实例 ID
        :return: 用户列表
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.DescribeDBInstanceUsersRequest()
                req.InstanceId = instance_id
                resp = client.DescribeDBInstanceUsers(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 列出用户成功: {instance_id}")
                return result.get('Response', {}).get('Users', [])
            else:
                params = {'InstanceId': instance_id}
                response = self.client.request('DescribeDBInstanceUsers', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用列出用户成功: {instance_id}")
                return response.get('Response', {}).get('Users', [])
        except Exception as e:
            error_msg = f"列出数据库用户失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def delete_user(self, instance_id: str, user_name: str) -> Dict[str, Any]:
        """
        删除数据库用户
        
        :param instance_id: 实例 ID
        :param user_name: 用户名
        :return: 删除结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.DeleteDBInstanceUserRequest()
                req.InstanceId = instance_id
                req.UserName = user_name
                resp = client.DeleteDBInstanceUser(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 删除用户成功: {user_name}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'UserName': user_name
                }
                result = self.client.request('DeleteDBInstanceUser', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用删除用户成功: {user_name}")
                return result
        except Exception as e:
            error_msg = f"删除数据库用户失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def reset_user_password(self, instance_id: str, user_name: str, new_password: str) -> Dict[str, Any]:
        """
        重置数据库用户密码
        
        :param instance_id: 实例 ID
        :param user_name: 用户名
        :param new_password: 新密码
        :return: 重置结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.ModifyDBInstanceUserPasswordRequest()
                req.InstanceId = instance_id
                req.UserName = user_name
                req.Password = new_password
                resp = client.ModifyDBInstanceUserPassword(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 重置用户密码成功: {user_name}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'UserName': user_name,
                    'Password': new_password
                }
                result = self.client.request('ModifyDBInstanceUserPassword', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用重置用户密码成功: {user_name}")
                return result
        except Exception as e:
            error_msg = f"重置数据库用户密码失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def create_database(self, instance_id: str, db_name: str, character_set: str = 'utf8mb4') -> Dict[str, Any]:
        """
        创建数据库
        
        :param instance_id: 实例 ID
        :param db_name: 数据库名称
        :param character_set: 字符集
        :return: 创建结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.CreateDatabaseRequest()
                req.InstanceId = instance_id
                req.DbName = db_name
                req.Charset = character_set
                resp = client.CreateDatabase(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 创建数据库成功: {db_name}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'DbName': db_name,
                    'Charset': character_set
                }
                result = self.client.request('CreateDatabase', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用创建数据库成功: {db_name}")
                return result
        except Exception as e:
            error_msg = f"创建数据库失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def list_databases(self, instance_id: str) -> List[Dict[str, Any]]:
        """
        列出数据库
        
        :param instance_id: 实例 ID
        :return: 数据库列表
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.DescribeDatabasesRequest()
                req.InstanceId = instance_id
                resp = client.DescribeDatabases(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 列出数据库成功: {instance_id}")
                return result.get('Response', {}).get('Databases', [])
            else:
                params = {'InstanceId': instance_id}
                response = self.client.request('DescribeDatabases', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用列出数据库成功: {instance_id}")
                return response.get('Response', {}).get('Databases', [])
        except Exception as e:
            error_msg = f"列出数据库失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def delete_database(self, instance_id: str, db_name: str) -> Dict[str, Any]:
        """
        删除数据库
        
        :param instance_id: 实例 ID
        :param db_name: 数据库名称
        :return: 删除结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.DeleteDatabaseRequest()
                req.InstanceId = instance_id
                req.DbName = db_name
                resp = client.DeleteDatabase(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 删除数据库成功: {db_name}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'DbName': db_name
                }
                result = self.client.request('DeleteDatabase', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用删除数据库成功: {db_name}")
                return result
        except Exception as e:
            error_msg = f"删除数据库失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def create_backup(self, instance_id: str, backup_type: str = 'physical', backup_desc: str = '') -> Dict[str, Any]:
        """
        创建数据库备份
        
        :param instance_id: 实例 ID
        :param backup_type: 备份类型（physical/logical）
        :param backup_desc: 备份描述
        :return: 创建结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.CreateBackupRequest()
                req.InstanceId = instance_id
                req.BackupType = backup_type
                req.Remark = backup_desc
                resp = client.CreateBackup(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 创建备份成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'BackupType': backup_type,
                    'Remark': backup_desc
                }
                result = self.client.request('CreateBackup', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用创建备份成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"创建数据库备份失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def list_backups(self, instance_id: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        列出数据库备份
        
        :param instance_id: 实例 ID
        :param params: 查询参数
        :return: 备份列表
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.DescribeBackupsRequest()
                req.InstanceId = instance_id
                if params:
                    for key, value in params.items():
                        setattr(req, key, value)
                resp = client.DescribeBackups(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 列出备份成功: {instance_id}")
                return result.get('Response', {}).get('Items', [])
            else:
                params = params or {}
                params['InstanceId'] = instance_id
                response = self.client.request('DescribeBackups', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用列出备份成功: {instance_id}")
                return response.get('Response', {}).get('Items', [])
        except Exception as e:
            error_msg = f"列出数据库备份失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def restore_instance(self, instance_id: str, backup_id: str) -> Dict[str, Any]:
        """
        恢复数据库实例
        
        :param instance_id: 实例 ID
        :param backup_id: 备份 ID
        :return: 恢复结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.RestoreDBInstanceRequest()
                req.InstanceId = instance_id
                req.BackupId = backup_id
                resp = client.RestoreDBInstance(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 恢复实例成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'BackupId': backup_id
                }
                result = self.client.request('RestoreDBInstance', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用恢复实例成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"恢复数据库实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def modify_parameter(self, instance_id: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """
        修改数据库参数
        
        :param instance_id: 实例 ID
        :param parameters: 参数列表
        :return: 修改结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.ModifyDBParametersRequest()
                req.InstanceId = instance_id
                req.ParamList = parameters
                resp = client.ModifyDBParameters(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 修改参数成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    'ParamList': parameters
                }
                result = self.client.request('ModifyDBParameters', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用修改参数成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"修改数据库参数失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def describe_parameters(self, instance_id: str) -> List[Dict[str, Any]]:
        """
        查询数据库参数
        
        :param instance_id: 实例 ID
        :return: 参数列表
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.cdb.v20170320 import models as cdb_models
                client = self.client.get_client('rds')
                req = cdb_models.DescribeDBParametersRequest()
                req.InstanceId = instance_id
                resp = client.DescribeDBParameters(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 RDS SDK 查询参数成功: {instance_id}")
                return result.get('Response', {}).get('Items', [])
            else:
                params = {'InstanceId': instance_id}
                response = self.client.request('DescribeDBParameters', params, '2018-03-20', 'cdb')
                self.logger.debug(f"使用 API 调用查询参数成功: {instance_id}")
                return response.get('Response', {}).get('Items', [])
        except Exception as e:
            error_msg = f"查询数据库参数失败: {str(e)}"
            self.logger.error(error_msg)
            raise
