# -*- coding: utf-8 -*-
"""
腾讯云 DNS 服务
"""

from typing import Dict, Any, Optional, List
from PyraUtils.service.cloud.tencent.client import TencentCloudClient
from PyraUtils.service.cloud.tencent.client import TENCENT_SDK_AVAILABLE


class TencentCloudDNSService:
    """
    腾讯云 DNS 服务
    """
    
    def __init__(self, client: TencentCloudClient):
        """
        初始化 DNS 服务
        
        :param client: 腾讯云客户端
        """
        self.client = client
        self.logger = client.logger
    
    def create_domain(self, domain_name: str) -> Dict[str, Any]:
        """
        创建域名
        
        :param domain_name: 域名名称
        :return: 创建结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.dnspod.v20210323 import models as dnspod_models
                client = self.client.get_client('dnspod')
                req = dnspod_models.CreateDomainRequest()
                req.DomainName = domain_name
                resp = client.CreateDomain(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 DNS SDK 创建域名成功: {domain_name}")
                return result
            else:
                params = {'DomainName': domain_name}
                result = self.client.request('CreateDomain', params, '2018-07-24', 'dnspod')
                self.logger.debug(f"使用 API 调用创建域名成功: {domain_name}")
                return result
        except Exception as e:
            error_msg = f"创建域名失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def add_record(self, domain_name: str, record: Dict[str, Any]) -> Dict[str, Any]:
        """
        添加 DNS 记录
        
        :param domain_name: 域名名称
        :param record: 记录信息
        :return: 添加结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.dnspod.v20210323 import models as dnspod_models
                client = self.client.get_client('dnspod')
                req = dnspod_models.CreateRecordRequest()
                req.Domain = domain_name
                for key, value in record.items():
                    setattr(req, key, value)
                resp = client.CreateRecord(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 DNS SDK 添加记录成功: {domain_name}")
                return result
            else:
                params = {
                    'Domain': domain_name,
                    **record
                }
                result = self.client.request('CreateRecord', params, '2018-07-24', 'dnspod')
                self.logger.debug(f"使用 API 调用添加记录成功: {domain_name}")
                return result
        except Exception as e:
            error_msg = f"添加 DNS 记录失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def update_record(self, record_id: str, record: Dict[str, Any]) -> Dict[str, Any]:
        """
        更新 DNS 记录
        
        :param record_id: 记录 ID
        :param record: 记录信息
        :return: 更新结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.dnspod.v20210323 import models as dnspod_models
                client = self.client.get_client('dnspod')
                req = dnspod_models.ModifyRecordRequest()
                req.RecordId = record_id
                for key, value in record.items():
                    setattr(req, key, value)
                resp = client.ModifyRecord(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 DNS SDK 更新记录成功: {record_id}")
                return result
            else:
                params = {
                    'RecordId': record_id,
                    **record
                }
                result = self.client.request('ModifyRecord', params, '2018-07-24', 'dnspod')
                self.logger.debug(f"使用 API 调用更新记录成功: {record_id}")
                return result
        except Exception as e:
            error_msg = f"更新 DNS 记录失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def delete_record(self, record_id: str) -> Dict[str, Any]:
        """
        删除 DNS 记录
        
        :param record_id: 记录 ID
        :return: 删除结果
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.dnspod.v20210323 import models as dnspod_models
                client = self.client.get_client('dnspod')
                req = dnspod_models.DeleteRecordRequest()
                req.RecordId = record_id
                resp = client.DeleteRecord(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 DNS SDK 删除记录成功: {record_id}")
                return result
            else:
                params = {'RecordId': record_id}
                result = self.client.request('DeleteRecord', params, '2018-07-24', 'dnspod')
                self.logger.debug(f"使用 API 调用删除记录成功: {record_id}")
                return result
        except Exception as e:
            error_msg = f"删除 DNS 记录失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def list_records(self, domain_name: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        列出 DNS 记录
        
        :param domain_name: 域名名称
        :param params: 查询参数
        :return: 记录列表
        """
        try:
            if TENCENT_SDK_AVAILABLE:
                from tencentcloud.dnspod.v20210323 import models as dnspod_models
                client = self.client.get_client('dnspod')
                req = dnspod_models.DescribeRecordListRequest()
                req.Domain = domain_name
                if params:
                    for key, value in params.items():
                        setattr(req, key, value)
                resp = client.DescribeRecordList(req)
                import json
                result = json.loads(resp.to_json_string())
                self.logger.debug(f"使用腾讯云 DNS SDK 列出记录成功: {domain_name}")
                return result.get('Response', {}).get('RecordList', [])
            else:
                params = params or {}
                params['Domain'] = domain_name
                response = self.client.request('DescribeRecordList', params, '2018-07-24', 'dnspod')
                self.logger.debug(f"使用 API 调用列出记录成功: {domain_name}")
                return response.get('Response', {}).get('RecordList', [])
        except Exception as e:
            error_msg = f"列出 DNS 记录失败: {str(e)}"
            self.logger.error(error_msg)
            raise
