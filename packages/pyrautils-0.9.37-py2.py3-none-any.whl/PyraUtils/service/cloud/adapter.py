# -*- coding: utf-8 -*-
"""
云服务 SDK 适配器

该模块提供了云服务 SDK 的适配器，当检测到已安装对应的 SDK 时，自动使用 SDK 实现，
否则使用当前的 API 调用实现。
"""

from typing import Dict, Any, Optional


class CloudServiceAdapter:
    """
    云服务适配器
    """
    
    @staticmethod
    def is_aliyun_sdk_available() -> bool:
        """
        检查阿里云 SDK 是否可用
        
        :return: SDK 是否可用
        """
        try:
            import aliyun-python-sdk-core
            return True
        except ImportError:
            return False
    
    @staticmethod
    def is_tencent_sdk_available() -> bool:
        """
        检查腾讯云 SDK 是否可用
        
        :return: SDK 是否可用
        """
        try:
            import tencentcloud
            return True
        except ImportError:
            return False
    
    @staticmethod
    def is_aws_sdk_available() -> bool:
        """
        检查 AWS SDK 是否可用
        
        :return: SDK 是否可用
        """
        try:
            import boto3
            return True
        except ImportError:
            return False
    
    @staticmethod
    def is_azure_sdk_available() -> bool:
        """
        检查 Azure SDK 是否可用
        
        :return: SDK 是否可用
        """
        try:
            import azure.identity
            import azure.mgmt.compute
            return True
        except ImportError:
            return False
    
    @staticmethod
    def create_aliyun_client(region: str, access_key: str, secret_key: str, **kwargs) -> Any:
        """
        创建阿里云客户端
        
        :param region: 区域
        :param access_key: 访问密钥
        :param secret_key: 安全密钥
        :param kwargs: 其他参数
        :return: 阿里云客户端
        """
        from PyraUtils.service.cloud.aliyun.client import AliCloudClient
        return AliCloudClient(region, access_key, secret_key, **kwargs)
    
    @staticmethod
    def create_tencent_client(region: str, access_key: str, secret_key: str, **kwargs) -> Any:
        """
        创建腾讯云客户端
        
        :param region: 区域
        :param access_key: 访问密钥
        :param secret_key: 安全密钥
        :param kwargs: 其他参数
        :return: 腾讯云客户端
        """
        from PyraUtils.service.cloud.tencent.client import TencentCloudClient
        return TencentCloudClient(region, access_key, secret_key, **kwargs)
    
    @staticmethod
    def create_aws_client(region: str, access_key: str, secret_key: str, **kwargs) -> Any:
        """
        创建 AWS 客户端
        
        :param region: 区域
        :param access_key: 访问密钥
        :param secret_key: 安全密钥
        :param kwargs: 其他参数
        :return: AWS 客户端
        """
        from PyraUtils.service.cloud.aws.client import AwsCloudClient
        return AwsCloudClient(region, access_key, secret_key, **kwargs)
    
    @staticmethod
    def create_azure_client(tenant_id: str, client_id: str, client_secret: str, subscription_id: str, **kwargs) -> Any:
        """
        创建 Azure 客户端
        
        :param tenant_id: 租户 ID
        :param client_id: 客户端 ID
        :param client_secret: 客户端密钥
        :param subscription_id: 订阅 ID
        :param kwargs: 其他参数
        :return: Azure 客户端
        """
        from PyraUtils.service.cloud.azure.client import AzureCloudClient
        return AzureCloudClient(tenant_id, client_id, client_secret, subscription_id, **kwargs)


# 适配器实例
adapter = CloudServiceAdapter()


def is_sdk_available(cloud: str) -> bool:
    """
    检查云服务 SDK 是否可用
    
    :param cloud: 云服务名称
    :return: SDK 是否可用
    """
    if cloud == 'aliyun':
        return adapter.is_aliyun_sdk_available()
    elif cloud == 'tencent':
        return adapter.is_tencent_sdk_available()
    elif cloud == 'aws':
        return adapter.is_aws_sdk_available()
    elif cloud == 'azure':
        return adapter.is_azure_sdk_available()
    return False


def create_client(cloud: str, **kwargs) -> Optional[Any]:
    """
    创建云服务客户端
    
    :param cloud: 云服务名称
    :param kwargs: 客户端参数
    :return: 云服务客户端
    """
    if cloud == 'aliyun':
        return adapter.create_aliyun_client(**kwargs)
    elif cloud == 'tencent':
        return adapter.create_tencent_client(**kwargs)
    elif cloud == 'aws':
        return adapter.create_aws_client(**kwargs)
    elif cloud == 'azure':
        return adapter.create_azure_client(**kwargs)
    return None
