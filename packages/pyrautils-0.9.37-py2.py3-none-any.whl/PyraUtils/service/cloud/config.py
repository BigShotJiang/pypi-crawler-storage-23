# -*- coding: utf-8 -*-
"""
云服务配置管理
"""

import os
import json
from typing import Dict, Any, Optional
from PyraUtils.log import LoguruHandler


class CloudConfigManager:
    """
    云服务配置管理器
    """
    
    def __init__(self, config_file: Optional[str] = None, config: Optional[Dict[str, Any]] = None):
        """
        初始化配置管理器
        
        :param config_file: 配置文件路径
        :param config: 直接传递的配置字典
        """
        self.config_file = config_file
        self.logger = LoguruHandler()
        if config:
            self.config = config
        else:
            self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """
        加载配置
        
        :return: 配置字典
        """
        config = {}
        
        # 从配置文件加载
        if self.config_file and os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                self.logger.info(f"从配置文件加载配置: {self.config_file}")
            except Exception as e:
                self.logger.error(f"加载配置文件失败: {str(e)}")
        
        # 从环境变量加载，覆盖配置文件中的值
        config = self._load_from_env(config)
        
        return config
    
    def _load_from_env(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        从环境变量加载配置
        
        :param config: 基础配置字典
        :return: 更新后的配置字典
        """
        # 阿里云配置
        aliyun_config = config.get('aliyun', {})
        aliyun_config['access_key'] = os.getenv('ALIYUN_ACCESS_KEY', aliyun_config.get('access_key'))
        aliyun_config['secret_key'] = os.getenv('ALIYUN_SECRET_KEY', aliyun_config.get('secret_key'))
        aliyun_config['region'] = os.getenv('ALIYUN_REGION', aliyun_config.get('region', 'cn-beijing'))
        if aliyun_config:
            config['aliyun'] = aliyun_config
        
        # 腾讯云配置
        tencent_config = config.get('tencent', {})
        tencent_config['access_key'] = os.getenv('TENCENT_ACCESS_KEY', tencent_config.get('access_key'))
        tencent_config['secret_key'] = os.getenv('TENCENT_SECRET_KEY', tencent_config.get('secret_key'))
        tencent_config['region'] = os.getenv('TENCENT_REGION', tencent_config.get('region', 'ap-beijing'))
        if tencent_config:
            config['tencent'] = tencent_config
        
        # AWS配置
        aws_config = config.get('aws', {})
        aws_config['access_key'] = os.getenv('AWS_ACCESS_KEY', aws_config.get('access_key'))
        aws_config['secret_key'] = os.getenv('AWS_SECRET_KEY', aws_config.get('secret_key'))
        aws_config['region'] = os.getenv('AWS_REGION', aws_config.get('region', 'us-east-1'))
        if aws_config:
            config['aws'] = aws_config
        
        # Azure配置
        azure_config = config.get('azure', {})
        azure_config['subscription_id'] = os.getenv('AZURE_SUBSCRIPTION_ID', azure_config.get('subscription_id'))
        azure_config['client_id'] = os.getenv('AZURE_CLIENT_ID', azure_config.get('client_id'))
        azure_config['client_secret'] = os.getenv('AZURE_CLIENT_SECRET', azure_config.get('client_secret'))
        azure_config['tenant_id'] = os.getenv('AZURE_TENANT_ID', azure_config.get('tenant_id'))
        if azure_config:
            config['azure'] = azure_config
        
        return config
    
    def get_config(self, cloud: str) -> Dict[str, Any]:
        """
        获取指定云服务的配置
        
        :param cloud: 云服务名称 (aliyun/tencent/aws/azure)
        :return: 配置字典
        """
        return self.config.get(cloud, {})
    
    def get_access_key(self, cloud: str) -> Optional[str]:
        """
        获取访问密钥
        
        :param cloud: 云服务名称
        :return: 访问密钥
        """
        return self.get_config(cloud).get('access_key')
    
    def get_secret_key(self, cloud: str) -> Optional[str]:
        """
        获取安全密钥
        
        :param cloud: 云服务名称
        :return: 安全密钥
        """
        return self.get_config(cloud).get('secret_key')
    
    def get_region(self, cloud: str) -> str:
        """
        获取区域
        
        :param cloud: 云服务名称
        :return: 区域名称
        """
        return self.get_config(cloud).get('region', 'cn-beijing' if cloud == 'aliyun' else 'ap-beijing' if cloud == 'tencent' else 'us-east-1')
    
    def save_config(self, config: Dict[str, Any]) -> bool:
        """
        保存配置到文件
        
        :param config: 配置字典
        :return: 是否保存成功
        """
        if not self.config_file:
            self.logger.error("未指定配置文件路径")
            return False
        
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            self.logger.info(f"配置已保存到: {self.config_file}")
            self.config = config
            return True
        except Exception as e:
            self.logger.error(f"保存配置文件失败: {str(e)}")
            return False
    
    def update_config(self, cloud: str, key: str, value: Any) -> bool:
        """
        更新配置
        
        :param cloud: 云服务名称
        :param key: 配置键
        :param value: 配置值
        :return: 是否更新成功
        """
        if cloud not in self.config:
            self.config[cloud] = {}
        
        self.config[cloud][key] = value
        
        if self.config_file:
            return self.save_config(self.config)
        return True
