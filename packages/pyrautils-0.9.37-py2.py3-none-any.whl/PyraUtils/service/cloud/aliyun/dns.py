# -*- coding: utf-8 -*-
"""
阿里云 DNS 服务
"""

from typing import Dict, Any, Optional, List
from PyraUtils.service.cloud.aliyun.client import AliCloudClient
from PyraUtils.service.cloud.aliyun.client import ALIYUN_SDK_AVAILABLE


class AliCloudDNSService:
    """
    阿里云 DNS 服务
    """
    
    def __init__(self, client: AliCloudClient):
        """
        初始化 DNS 服务
        
        :param client: 阿里云客户端
        """
        self.client = client
        self.logger = client.logger
    
    def create_domain(self, domain_name: str) -> Dict[str, Any]:
        """
        创建域名
        
        :param domain_name: 域名名称
        :return: 创建结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkdns.request.v20150109 import AddDomainRequest
                request = AddDomainRequest.AddDomainRequest()
                request.set_DomainName(domain_name)
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 DNS SDK 创建域名成功: {domain_name}")
                return result
            else:
                params = {'DomainName': domain_name}
                result = self.client.request('AddDomain', params, '2015-01-09', 'alidns')
                self.logger.debug(f"使用 API 调用创建域名成功: {domain_name}")
                return result
        except Exception as e:
            error_msg = f"创建域名失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def add_record(self, domain_name: str, record: Dict[str, Any]) -> Dict[str, Any]:
        """
        添加 DNS 记录
        
        :param domain_name: 域名名称
        :param record: 记录信息
        :return: 添加结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkdns.request.v20150109 import AddDomainRecordRequest
                request = AddDomainRecordRequest.AddDomainRecordRequest()
                request.set_DomainName(domain_name)
                if 'RR' in record:
                    request.set_RR(record['RR'])
                if 'Type' in record:
                    request.set_Type(record['Type'])
                if 'Value' in record:
                    request.set_Value(record['Value'])
                if 'TTL' in record:
                    request.set_TTL(record['TTL'])
                if 'Priority' in record:
                    request.set_Priority(record['Priority'])
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 DNS SDK 添加记录成功: {domain_name}")
                return result
            else:
                params = {
                    'DomainName': domain_name,
                    **record
                }
                result = self.client.request('AddDomainRecord', params, '2015-01-09', 'alidns')
                self.logger.debug(f"使用 API 调用添加记录成功: {domain_name}")
                return result
        except Exception as e:
            error_msg = f"添加 DNS 记录失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def update_record(self, record_id: str, record: Dict[str, Any]) -> Dict[str, Any]:
        """
        更新 DNS 记录
        
        :param record_id: 记录 ID
        :param record: 记录信息
        :return: 更新结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkdns.request.v20150109 import UpdateDomainRecordRequest
                request = UpdateDomainRecordRequest.UpdateDomainRecordRequest()
                request.set_RecordId(record_id)
                if 'RR' in record:
                    request.set_RR(record['RR'])
                if 'Type' in record:
                    request.set_Type(record['Type'])
                if 'Value' in record:
                    request.set_Value(record['Value'])
                if 'TTL' in record:
                    request.set_TTL(record['TTL'])
                if 'Priority' in record:
                    request.set_Priority(record['Priority'])
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 DNS SDK 更新记录成功: {record_id}")
                return result
            else:
                params = {
                    'RecordId': record_id,
                    **record
                }
                result = self.client.request('UpdateDomainRecord', params, '2015-01-09', 'alidns')
                self.logger.debug(f"使用 API 调用更新记录成功: {record_id}")
                return result
        except Exception as e:
            error_msg = f"更新 DNS 记录失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def delete_record(self, record_id: str) -> Dict[str, Any]:
        """
        删除 DNS 记录
        
        :param record_id: 记录 ID
        :return: 删除结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkdns.request.v20150109 import DeleteDomainRecordRequest
                request = DeleteDomainRecordRequest.DeleteDomainRecordRequest()
                request.set_RecordId(record_id)
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 DNS SDK 删除记录成功: {record_id}")
                return result
            else:
                params = {'RecordId': record_id}
                result = self.client.request('DeleteDomainRecord', params, '2015-01-09', 'alidns')
                self.logger.debug(f"使用 API 调用删除记录成功: {record_id}")
                return result
        except Exception as e:
            error_msg = f"删除 DNS 记录失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def list_records(self, domain_name: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        列出 DNS 记录
        
        :param domain_name: 域名名称
        :param params: 查询参数
        :return: 记录列表
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkdns.request.v20150109 import DescribeDomainRecordsRequest
                request = DescribeDomainRecordsRequest.DescribeDomainRecordsRequest()
                request.set_DomainName(domain_name)
                if params:
                    if 'PageNumber' in params:
                        request.set_PageNumber(params['PageNumber'])
                    if 'PageSize' in params:
                        request.set_PageSize(params['PageSize'])
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 DNS SDK 列出记录成功: {domain_name}")
                return result.get('DomainRecords', {}).get('Record', [])
            else:
                params = params or {}
                params['DomainName'] = domain_name
                response = self.client.request('DescribeDomainRecords', params, '2015-01-09', 'alidns')
                self.logger.debug(f"使用 API 调用列出记录成功: {domain_name}")
                return response.get('DomainRecords', {}).get('Record', [])
        except Exception as e:
            error_msg = f"列出 DNS 记录失败: {str(e)}"
            self.logger.error(error_msg)
            raise
