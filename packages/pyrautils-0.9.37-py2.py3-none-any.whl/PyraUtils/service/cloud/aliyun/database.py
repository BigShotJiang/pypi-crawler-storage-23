# -*- coding: utf-8 -*-
"""
阿里云数据库服务
"""

from typing import Dict, Any, Optional, List
from PyraUtils.log import LoguruHandler

try:
    from aliyunsdkrds.request.v20140815 import CreateDBInstanceRequest, ModifyDBInstanceSpecRequest
    from aliyunsdkrds.request.v20140815 import CreateAccountRequest, GrantAccountPrivilegeRequest
    from aliyunsdkrds.request.v20140815 import DescribeDBInstancesRequest, DescribeDBInstanceAttributeRequest
    from aliyunsdkrds.request.v20140815 import StartDBInstanceRequest, StopDBInstanceRequest, RestartDBInstanceRequest
    from aliyunsdkrds.request.v20140815 import DeleteDBInstanceRequest, ModifyDBInstanceAttributeRequest
    from aliyunsdkrds.request.v20140815 import DescribeAccountsRequest, DeleteAccountRequest, ResetAccountPasswordRequest
    from aliyunsdkrds.request.v20140815 import CreateDatabaseRequest, DescribeDatabasesRequest, DeleteDatabaseRequest
    from aliyunsdkrds.request.v20140815 import CreateBackupRequest, DescribeBackupsRequest, RestoreDBInstanceRequest
    from aliyunsdkrds.request.v20140815 import ModifyDBParameterGroupRequest, DescribeDBParametersRequest
    ALIYUN_RDS_SDK_AVAILABLE = True
except ImportError:
    ALIYUN_RDS_SDK_AVAILABLE = False


class AliCloudDatabaseService:
    """
    阿里云数据库服务
    """
    
    def __init__(self, client):
        """
        初始化数据库服务
        
        :param client: 阿里云客户端
        """
        self.client = client
        self.logger = LoguruHandler()
        
        if not ALIYUN_RDS_SDK_AVAILABLE:
            self.logger.warning("阿里云 RDS SDK 未安装，将使用通用 API 调用方式")
    
    def create_instance(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        创建数据库实例
        
        :param params: 创建参数
        :return: 创建结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                return self.client.request('CreateDBInstance', params, '2014-08-15', 'rds')
            
            request = CreateDBInstanceRequest()
            for key, value in params.items():
                setattr(request, key, value)
            
            self.logger.debug("创建数据库实例")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug("创建数据库实例成功")
            return result
        except Exception as e:
            self.logger.error(f"创建数据库实例失败: {str(e)}")
            raise
    
    def resize_instance(self, instance_id: str, new_spec: Dict[str, Any]) -> Dict[str, Any]:
        """
        调整数据库实例规格
        
        :param instance_id: 实例 ID
        :param new_spec: 新规格
        :return: 调整结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DBInstanceId': instance_id,
                    **new_spec
                }
                return self.client.request('ModifyDBInstanceSpec', params, '2014-08-15', 'rds')
            
            request = ModifyDBInstanceSpecRequest()
            request.set_DBInstanceId(instance_id)
            for key, value in new_spec.items():
                setattr(request, key, value)
            
            self.logger.debug(f"调整数据库实例规格: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"调整数据库实例规格成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"调整数据库实例规格失败: {str(e)}")
            raise
    
    def create_user(self, instance_id: str, user_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        创建数据库用户
        
        :param instance_id: 实例 ID
        :param user_info: 用户信息
        :return: 创建结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DBInstanceId': instance_id,
                    **user_info
                }
                return self.client.request('CreateAccount', params, '2014-08-15', 'rds')
            
            request = CreateAccountRequest()
            request.set_DBInstanceId(instance_id)
            for key, value in user_info.items():
                setattr(request, key, value)
            
            self.logger.debug(f"创建数据库用户: {user_info.get('AccountName')}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"创建数据库用户成功: {user_info.get('AccountName')}")
            return result
        except Exception as e:
            self.logger.error(f"创建数据库用户失败: {str(e)}")
            raise
    
    def grant_privilege(self, instance_id: str, user_name: str, privileges: Dict[str, Any]) -> Dict[str, Any]:
        """
        授权数据库用户
        
        :param instance_id: 实例 ID
        :param user_name: 用户名
        :param privileges: 权限信息
        :return: 授权结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DBInstanceId': instance_id,
                    'AccountName': user_name,
                    **privileges
                }
                return self.client.request('GrantAccountPrivilege', params, '2014-08-15', 'rds')
            
            request = GrantAccountPrivilegeRequest()
            request.set_DBInstanceId(instance_id)
            request.set_AccountName(user_name)
            for key, value in privileges.items():
                setattr(request, key, value)
            
            self.logger.debug(f"授权数据库用户: {user_name}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"授权数据库用户成功: {user_name}")
            return result
        except Exception as e:
            self.logger.error(f"授权数据库用户失败: {str(e)}")
            raise
    
    def list_instances(self, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        列出数据库实例
        
        :param params: 查询参数
        :return: 实例列表
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = params or {}
                response = self.client.request('DescribeDBInstances', params, '2014-08-15', 'rds')
                return response.get('Items', {}).get('DBInstance', [])
            
            request = DescribeDBInstancesRequest()
            if params:
                for key, value in params.items():
                    setattr(request, key, value)
            
            self.logger.debug("列出数据库实例")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"列出数据库实例成功，共 {len(result.get('Items', {}).get('DBInstance', []))} 个实例")
            return result.get('Items', {}).get('DBInstance', [])
        except Exception as e:
            self.logger.error(f"列出数据库实例失败: {str(e)}")
            raise
    
    def describe_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        查询数据库实例详情
        
        :param instance_id: 实例 ID
        :return: 实例详情
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {'DBInstanceId': instance_id}
                response = self.client.request('DescribeDBInstanceAttribute', params, '2014-08-15', 'rds')
                return response.get('Items', {}).get('DBInstanceAttribute', [])[0] if response.get('Items', {}).get('DBInstanceAttribute') else {}
            
            request = DescribeDBInstanceAttributeRequest()
            request.set_DBInstanceId(instance_id)
            
            self.logger.debug(f"查询数据库实例详情: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            attributes = result.get('Items', {}).get('DBInstanceAttribute', [])
            self.logger.debug(f"查询数据库实例详情成功: {instance_id}")
            return attributes[0] if attributes else {}
        except Exception as e:
            self.logger.error(f"查询数据库实例详情失败: {str(e)}")
            raise
    
    def start_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        启动数据库实例
        
        :param instance_id: 实例 ID
        :return: 启动结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {'DBInstanceId': instance_id}
                return self.client.request('StartDBInstance', params, '2014-08-15', 'rds')
            
            request = StartDBInstanceRequest()
            request.set_DBInstanceId(instance_id)
            
            self.logger.debug(f"启动数据库实例: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"启动数据库实例成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"启动数据库实例失败: {str(e)}")
            raise
    
    def stop_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        停止数据库实例
        
        :param instance_id: 实例 ID
        :return: 停止结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {'DBInstanceId': instance_id}
                return self.client.request('StopDBInstance', params, '2014-08-15', 'rds')
            
            request = StopDBInstanceRequest()
            request.set_DBInstanceId(instance_id)
            
            self.logger.debug(f"停止数据库实例: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"停止数据库实例成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"停止数据库实例失败: {str(e)}")
            raise
    
    def restart_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        重启数据库实例
        
        :param instance_id: 实例 ID
        :return: 重启结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {'DBInstanceId': instance_id}
                return self.client.request('RestartDBInstance', params, '2014-08-15', 'rds')
            
            request = RestartDBInstanceRequest()
            request.set_DBInstanceId(instance_id)
            
            self.logger.debug(f"重启数据库实例: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"重启数据库实例成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"重启数据库实例失败: {str(e)}")
            raise
    
    def delete_instance(self, instance_id: str, release_connection: bool = False) -> Dict[str, Any]:
        """
        删除数据库实例
        
        :param instance_id: 实例 ID
        :param release_connection: 是否释放连接
        :return: 删除结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DBInstanceId': instance_id,
                    'ReleaseConnection': 'true' if release_connection else 'false'
                }
                return self.client.request('DeleteDBInstance', params, '2014-08-15', 'rds')
            
            request = DeleteDBInstanceRequest()
            request.set_DBInstanceId(instance_id)
            request.set_ReleaseConnection('true' if release_connection else 'false')
            
            self.logger.debug(f"删除数据库实例: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"删除数据库实例成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"删除数据库实例失败: {str(e)}")
            raise
    
    def modify_instance_attribute(self, instance_id: str, attributes: Dict[str, Any]) -> Dict[str, Any]:
        """
        修改数据库实例属性
        
        :param instance_id: 实例 ID
        :param attributes: 要修改的属性
        :return: 修改结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DBInstanceId': instance_id,
                    **attributes
                }
                return self.client.request('ModifyDBInstanceAttribute', params, '2014-08-15', 'rds')
            
            request = ModifyDBInstanceAttributeRequest()
            request.set_DBInstanceId(instance_id)
            for key, value in attributes.items():
                setattr(request, key, value)
            
            self.logger.debug(f"修改数据库实例属性: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"修改数据库实例属性成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"修改数据库实例属性失败: {str(e)}")
            raise
    
    def list_users(self, instance_id: str) -> List[Dict[str, Any]]:
        """
        列出数据库用户
        
        :param instance_id: 实例 ID
        :return: 用户列表
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {'DBInstanceId': instance_id}
                response = self.client.request('DescribeAccounts', params, '2014-08-15', 'rds')
                return response.get('Accounts', {}).get('Account', [])
            
            request = DescribeAccountsRequest()
            request.set_DBInstanceId(instance_id)
            
            self.logger.debug(f"列出数据库用户: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"列出数据库用户成功，共 {len(result.get('Accounts', {}).get('Account', []))} 个用户")
            return result.get('Accounts', {}).get('Account', [])
        except Exception as e:
            self.logger.error(f"列出数据库用户失败: {str(e)}")
            raise
    
    def delete_user(self, instance_id: str, user_name: str) -> Dict[str, Any]:
        """
        删除数据库用户
        
        :param instance_id: 实例 ID
        :param user_name: 用户名
        :return: 删除结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DBInstanceId': instance_id,
                    'AccountName': user_name
                }
                return self.client.request('DeleteAccount', params, '2014-08-15', 'rds')
            
            request = DeleteAccountRequest()
            request.set_DBInstanceId(instance_id)
            request.set_AccountName(user_name)
            
            self.logger.debug(f"删除数据库用户: {user_name}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"删除数据库用户成功: {user_name}")
            return result
        except Exception as e:
            self.logger.error(f"删除数据库用户失败: {str(e)}")
            raise
    
    def reset_user_password(self, instance_id: str, user_name: str, new_password: str) -> Dict[str, Any]:
        """
        重置数据库用户密码
        
        :param instance_id: 实例 ID
        :param user_name: 用户名
        :param new_password: 新密码
        :return: 重置结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DBInstanceId': instance_id,
                    'AccountName': user_name,
                    'AccountPassword': new_password
                }
                return self.client.request('ResetAccountPassword', params, '2014-08-15', 'rds')
            
            request = ResetAccountPasswordRequest()
            request.set_DBInstanceId(instance_id)
            request.set_AccountName(user_name)
            request.set_AccountPassword(new_password)
            
            self.logger.debug(f"重置数据库用户密码: {user_name}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"重置数据库用户密码成功: {user_name}")
            return result
        except Exception as e:
            self.logger.error(f"重置数据库用户密码失败: {str(e)}")
            raise
    
    def create_database(self, instance_id: str, db_name: str, character_set: str = 'utf8mb4') -> Dict[str, Any]:
        """
        创建数据库
        
        :param instance_id: 实例 ID
        :param db_name: 数据库名称
        :param character_set: 字符集
        :return: 创建结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DBInstanceId': instance_id,
                    'DBName': db_name,
                    'CharacterSetName': character_set
                }
                return self.client.request('CreateDatabase', params, '2014-08-15', 'rds')
            
            request = CreateDatabaseRequest()
            request.set_DBInstanceId(instance_id)
            request.set_DBName(db_name)
            request.set_CharacterSetName(character_set)
            
            self.logger.debug(f"创建数据库: {db_name}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"创建数据库成功: {db_name}")
            return result
        except Exception as e:
            self.logger.error(f"创建数据库失败: {str(e)}")
            raise
    
    def list_databases(self, instance_id: str) -> List[Dict[str, Any]]:
        """
        列出数据库
        
        :param instance_id: 实例 ID
        :return: 数据库列表
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {'DBInstanceId': instance_id}
                response = self.client.request('DescribeDatabases', params, '2014-08-15', 'rds')
                return response.get('Databases', {}).get('Database', [])
            
            request = DescribeDatabasesRequest()
            request.set_DBInstanceId(instance_id)
            
            self.logger.debug(f"列出数据库: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"列出数据库成功，共 {len(result.get('Databases', {}).get('Database', []))} 个数据库")
            return result.get('Databases', {}).get('Database', [])
        except Exception as e:
            self.logger.error(f"列出数据库失败: {str(e)}")
            raise
    
    def delete_database(self, instance_id: str, db_name: str) -> Dict[str, Any]:
        """
        删除数据库
        
        :param instance_id: 实例 ID
        :param db_name: 数据库名称
        :return: 删除结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DBInstanceId': instance_id,
                    'DBName': db_name
                }
                return self.client.request('DeleteDatabase', params, '2014-08-15', 'rds')
            
            request = DeleteDatabaseRequest()
            request.set_DBInstanceId(instance_id)
            request.set_DBName(db_name)
            
            self.logger.debug(f"删除数据库: {db_name}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"删除数据库成功: {db_name}")
            return result
        except Exception as e:
            self.logger.error(f"删除数据库失败: {str(e)}")
            raise
    
    def create_backup(self, instance_id: str, backup_type: str = 'Full', backup_desc: str = '') -> Dict[str, Any]:
        """
        创建数据库备份
        
        :param instance_id: 实例 ID
        :param backup_type: 备份类型（Full/Incremental）
        :param backup_desc: 备份描述
        :return: 创建结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DBInstanceId': instance_id,
                    'BackupType': backup_type,
                    'BackupDescription': backup_desc
                }
                return self.client.request('CreateBackup', params, '2014-08-15', 'rds')
            
            request = CreateBackupRequest()
            request.set_DBInstanceId(instance_id)
            request.set_BackupType(backup_type)
            request.set_BackupDescription(backup_desc)
            
            self.logger.debug(f"创建数据库备份: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"创建数据库备份成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"创建数据库备份失败: {str(e)}")
            raise
    
    def list_backups(self, instance_id: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        列出数据库备份
        
        :param instance_id: 实例 ID
        :param params: 查询参数
        :return: 备份列表
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = params or {}
                params['DBInstanceId'] = instance_id
                response = self.client.request('DescribeBackups', params, '2014-08-15', 'rds')
                return response.get('Items', {}).get('Backup', [])
            
            request = DescribeBackupsRequest()
            request.set_DBInstanceId(instance_id)
            if params:
                for key, value in params.items():
                    setattr(request, key, value)
            
            self.logger.debug(f"列出数据库备份: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"列出数据库备份成功，共 {len(result.get('Items', {}).get('Backup', []))} 个备份")
            return result.get('Items', {}).get('Backup', [])
        except Exception as e:
            self.logger.error(f"列出数据库备份失败: {str(e)}")
            raise
    
    def restore_instance(self, instance_id: str, backup_id: str, restore_time: Optional[str] = None) -> Dict[str, Any]:
        """
        恢复数据库实例
        
        :param instance_id: 实例 ID
        :param backup_id: 备份 ID
        :param restore_time: 恢复时间点（可选）
        :return: 恢复结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DBInstanceId': instance_id,
                    'BackupId': backup_id
                }
                if restore_time:
                    params['RestoreTime'] = restore_time
                return self.client.request('RestoreDBInstance', params, '2014-08-15', 'rds')
            
            request = RestoreDBInstanceRequest()
            request.set_DBInstanceId(instance_id)
            request.set_BackupId(backup_id)
            if restore_time:
                request.set_RestoreTime(restore_time)
            
            self.logger.debug(f"恢复数据库实例: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"恢复数据库实例成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"恢复数据库实例失败: {str(e)}")
            raise
    
    def modify_parameter(self, instance_id: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """
        修改数据库参数
        
        :param instance_id: 实例 ID
        :param parameters: 参数列表
        :return: 修改结果
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DBInstanceId': instance_id,
                    'Parameters': parameters
                }
                return self.client.request('ModifyDBParameterGroup', params, '2014-08-15', 'rds')
            
            request = ModifyDBParameterGroupRequest()
            request.set_DBInstanceId(instance_id)
            request.set_Parameters(parameters)
            
            self.logger.debug(f"修改数据库参数: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"修改数据库参数成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"修改数据库参数失败: {str(e)}")
            raise
    
    def describe_parameters(self, instance_id: str) -> List[Dict[str, Any]]:
        """
        查询数据库参数
        
        :param instance_id: 实例 ID
        :return: 参数列表
        """
        try:
            if not ALIYUN_RDS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {'DBInstanceId': instance_id}
                response = self.client.request('DescribeDBParameters', params, '2014-08-15', 'rds')
                return response.get('Parameters', {}).get('Parameter', [])
            
            request = DescribeDBParametersRequest()
            request.set_DBInstanceId(instance_id)
            
            self.logger.debug(f"查询数据库参数: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"查询数据库参数成功")
            return result.get('Parameters', {}).get('Parameter', [])
        except Exception as e:
            self.logger.error(f"查询数据库参数失败: {str(e)}")
            raise
