# -*- coding: utf-8 -*-
"""
阿里云 ECS 服务
"""

from typing import Dict, Any, Optional, List
from PyraUtils.log import LoguruHandler

try:
    from aliyunsdkecs.request.v20140526 import RunInstancesRequest, StartInstanceRequest, StopInstanceRequest, RebootInstanceRequest
    from aliyunsdkecs.request.v20140526 import DescribeInstancesRequest, ModifyInstanceAttributeRequest, ResizeInstanceRequest
    from aliyunsdkecs.request.v20140526 import DeleteInstanceRequest, ResetPasswordRequest, CreateImageRequest
    from aliyunsdkecs.request.v20140526 import DescribeImagesRequest, DeleteImageRequest, CreateDiskRequest
    from aliyunsdkecs.request.v20140526 import AttachDiskRequest, DetachDiskRequest, ResizeDiskRequest, DeleteDiskRequest
    ALIYUN_ECS_SDK_AVAILABLE = True
except ImportError:
    ALIYUN_ECS_SDK_AVAILABLE = False


class AliCloudECSService:
    """
    阿里云 ECS 服务
    """
    
    def __init__(self, client):
        """
        初始化 ECS 服务
        
        :param client: 阿里云客户端
        """
        self.client = client
        self.logger = LoguruHandler()
        
        if not ALIYUN_ECS_SDK_AVAILABLE:
            self.logger.warning("阿里云 ECS SDK 未安装，将使用通用 API 调用方式")
    
    def create_instance(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        创建 ECS 实例
        
        :param params: 创建参数
        :return: 创建结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                return self.client.request('RunInstances', params, '2014-05-26', 'ecs')
            
            request = RunInstancesRequest()
            for key, value in params.items():
                setattr(request, key, value)
            
            self.logger.debug("创建 ECS 实例")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug("创建 ECS 实例成功")
            return result
        except Exception as e:
            self.logger.error(f"创建 ECS 实例失败: {str(e)}")
            raise
    
    def start_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        启动 ECS 实例
        
        :param instance_id: 实例 ID
        :return: 启动结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {'InstanceId': instance_id}
                return self.client.request('StartInstance', params, '2014-05-26', 'ecs')
            
            request = StartInstanceRequest()
            request.set_InstanceId(instance_id)
            
            self.logger.debug(f"启动 ECS 实例: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"启动 ECS 实例成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"启动 ECS 实例失败: {str(e)}")
            raise
    
    def stop_instance(self, instance_id: str, force: bool = False) -> Dict[str, Any]:
        """
        停止 ECS 实例
        
        :param instance_id: 实例 ID
        :param force: 是否强制停止
        :return: 停止结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'InstanceId': instance_id,
                    'ForceStop': 'true' if force else 'false'
                }
                return self.client.request('StopInstance', params, '2014-05-26', 'ecs')
            
            request = StopInstanceRequest()
            request.set_InstanceId(instance_id)
            request.set_ForceStop('true' if force else 'false')
            
            self.logger.debug(f"停止 ECS 实例: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"停止 ECS 实例成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"停止 ECS 实例失败: {str(e)}")
            raise
    
    def restart_instance(self, instance_id: str, force: bool = False) -> Dict[str, Any]:
        """
        重启 ECS 实例
        
        :param instance_id: 实例 ID
        :param force: 是否强制重启
        :return: 重启结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'InstanceId': instance_id,
                    'ForceStop': 'true' if force else 'false'
                }
                return self.client.request('RebootInstance', params, '2014-05-26', 'ecs')
            
            request = RebootInstanceRequest()
            request.set_InstanceId(instance_id)
            request.set_ForceStop('true' if force else 'false')
            
            self.logger.debug(f"重启 ECS 实例: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"重启 ECS 实例成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"重启 ECS 实例失败: {str(e)}")
            raise
    
    def list_instances(self, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        列出 ECS 实例
        
        :param params: 查询参数
        :return: 实例列表
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = params or {}
                response = self.client.request('DescribeInstances', params, '2014-05-26', 'ecs')
                return response.get('Instances', {}).get('Instance', [])
            
            request = DescribeInstancesRequest()
            if params:
                for key, value in params.items():
                    setattr(request, key, value)
            
            self.logger.debug("列出 ECS 实例")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"列出 ECS 实例成功，共 {len(result.get('Instances', {}).get('Instance', []))} 个实例")
            return result.get('Instances', {}).get('Instance', [])
        except Exception as e:
            self.logger.error(f"列出 ECS 实例失败: {str(e)}")
            raise
    
    def describe_instance(self, instance_id: str) -> Dict[str, Any]:
        """
        查询 ECS 实例详情
        
        :param instance_id: 实例 ID
        :return: 实例详情
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {'InstanceId': instance_id}
                response = self.client.request('DescribeInstances', params, '2014-05-26', 'ecs')
                instances = response.get('Instances', {}).get('Instance', [])
                return instances[0] if instances else {}
            
            request = DescribeInstancesRequest()
            request.set_InstanceId(instance_id)
            
            self.logger.debug(f"查询 ECS 实例详情: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            instances = result.get('Instances', {}).get('Instance', [])
            self.logger.debug(f"查询 ECS 实例详情成功: {instance_id}")
            return instances[0] if instances else {}
        except Exception as e:
            self.logger.error(f"查询 ECS 实例详情失败: {str(e)}")
            raise
    
    def modify_instance_attribute(self, instance_id: str, attributes: Dict[str, Any]) -> Dict[str, Any]:
        """
        修改 ECS 实例属性
        
        :param instance_id: 实例 ID
        :param attributes: 要修改的属性
        :return: 修改结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'InstanceId': instance_id,
                    **attributes
                }
                return self.client.request('ModifyInstanceAttribute', params, '2014-05-26', 'ecs')
            
            request = ModifyInstanceAttributeRequest()
            request.set_InstanceId(instance_id)
            for key, value in attributes.items():
                setattr(request, key, value)
            
            self.logger.debug(f"修改 ECS 实例属性: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"修改 ECS 实例属性成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"修改 ECS 实例属性失败: {str(e)}")
            raise
    
    def resize_instance_spec(self, instance_id: str, instance_type: str) -> Dict[str, Any]:
        """
        调整 ECS 实例规格
        
        :param instance_id: 实例 ID
        :param instance_type: 新的实例规格
        :return: 调整结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'InstanceId': instance_id,
                    'InstanceType': instance_type
                }
                return self.client.request('ResizeInstance', params, '2014-05-26', 'ecs')
            
            request = ResizeInstanceRequest()
            request.set_InstanceId(instance_id)
            request.set_InstanceType(instance_type)
            
            self.logger.debug(f"调整 ECS 实例规格: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"调整 ECS 实例规格成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"调整 ECS 实例规格失败: {str(e)}")
            raise
    
    def release_instance(self, instance_id: str, force: bool = False) -> Dict[str, Any]:
        """
        释放 ECS 实例
        
        :param instance_id: 实例 ID
        :param force: 是否强制释放
        :return: 释放结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'InstanceId': instance_id,
                    'Force': 'true' if force else 'false'
                }
                return self.client.request('DeleteInstance', params, '2014-05-26', 'ecs')
            
            request = DeleteInstanceRequest()
            request.set_InstanceId(instance_id)
            request.set_Force('true' if force else 'false')
            
            self.logger.debug(f"释放 ECS 实例: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"释放 ECS 实例成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"释放 ECS 实例失败: {str(e)}")
            raise
    
    def reset_instance_password(self, instance_id: str, password: str, username: str = 'root') -> Dict[str, Any]:
        """
        重置 ECS 实例密码
        
        :param instance_id: 实例 ID
        :param password: 新密码
        :param username: 用户名
        :return: 重置结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'InstanceId': instance_id,
                    'Password': password,
                    'UserName': username
                }
                return self.client.request('ResetPassword', params, '2014-05-26', 'ecs')
            
            request = ResetPasswordRequest()
            request.set_InstanceId(instance_id)
            request.set_Password(password)
            request.set_UserName(username)
            
            self.logger.debug(f"重置 ECS 实例密码: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"重置 ECS 实例密码成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"重置 ECS 实例密码失败: {str(e)}")
            raise
    
    def create_image(self, instance_id: str, image_name: str, image_description: str = '') -> Dict[str, Any]:
        """
        创建自定义镜像
        
        :param instance_id: 实例 ID
        :param image_name: 镜像名称
        :param image_description: 镜像描述
        :return: 创建结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'InstanceId': instance_id,
                    'ImageName': image_name,
                    'Description': image_description
                }
                return self.client.request('CreateImage', params, '2014-05-26', 'ecs')
            
            request = CreateImageRequest()
            request.set_InstanceId(instance_id)
            request.set_ImageName(image_name)
            request.set_Description(image_description)
            
            self.logger.debug(f"创建自定义镜像: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"创建自定义镜像成功: {instance_id}")
            return result
        except Exception as e:
            self.logger.error(f"创建自定义镜像失败: {str(e)}")
            raise
    
    def list_images(self, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        列出镜像
        
        :param params: 查询参数
        :return: 镜像列表
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = params or {}
                response = self.client.request('DescribeImages', params, '2014-05-26', 'ecs')
                return response.get('Images', {}).get('Image', [])
            
            request = DescribeImagesRequest()
            if params:
                for key, value in params.items():
                    setattr(request, key, value)
            
            self.logger.debug("列出镜像")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"列出镜像成功，共 {len(result.get('Images', {}).get('Image', []))} 个镜像")
            return result.get('Images', {}).get('Image', [])
        except Exception as e:
            self.logger.error(f"列出镜像失败: {str(e)}")
            raise
    
    def delete_image(self, image_id: str) -> Dict[str, Any]:
        """
        删除镜像
        
        :param image_id: 镜像 ID
        :return: 删除结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {'ImageId': image_id}
                return self.client.request('DeleteImage', params, '2014-05-26', 'ecs')
            
            request = DeleteImageRequest()
            request.set_ImageId(image_id)
            
            self.logger.debug(f"删除镜像: {image_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"删除镜像成功: {image_id}")
            return result
        except Exception as e:
            self.logger.error(f"删除镜像失败: {str(e)}")
            raise
    
    def create_disk(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        创建云盘
        
        :param params: 创建参数
        :return: 创建结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                return self.client.request('CreateDisk', params, '2014-05-26', 'ecs')
            
            request = CreateDiskRequest()
            for key, value in params.items():
                setattr(request, key, value)
            
            self.logger.debug("创建云盘")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug("创建云盘成功")
            return result
        except Exception as e:
            self.logger.error(f"创建云盘失败: {str(e)}")
            raise
    
    def attach_disk(self, instance_id: str, disk_id: str) -> Dict[str, Any]:
        """
        挂载云盘
        
        :param instance_id: 实例 ID
        :param disk_id: 云盘 ID
        :return: 挂载结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'InstanceId': instance_id,
                    'DiskId': disk_id
                }
                return self.client.request('AttachDisk', params, '2014-05-26', 'ecs')
            
            request = AttachDiskRequest()
            request.set_InstanceId(instance_id)
            request.set_DiskId(disk_id)
            
            self.logger.debug(f"挂载云盘: {disk_id} 到实例: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"挂载云盘成功: {disk_id}")
            return result
        except Exception as e:
            self.logger.error(f"挂载云盘失败: {str(e)}")
            raise
    
    def detach_disk(self, instance_id: str, disk_id: str) -> Dict[str, Any]:
        """
        卸载云盘
        
        :param instance_id: 实例 ID
        :param disk_id: 云盘 ID
        :return: 卸载结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'InstanceId': instance_id,
                    'DiskId': disk_id
                }
                return self.client.request('DetachDisk', params, '2014-05-26', 'ecs')
            
            request = DetachDiskRequest()
            request.set_InstanceId(instance_id)
            request.set_DiskId(disk_id)
            
            self.logger.debug(f"卸载云盘: {disk_id} 从实例: {instance_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"卸载云盘成功: {disk_id}")
            return result
        except Exception as e:
            self.logger.error(f"卸载云盘失败: {str(e)}")
            raise
    
    def resize_disk(self, disk_id: str, new_size: int) -> Dict[str, Any]:
        """
        扩容云盘
        
        :param disk_id: 云盘 ID
        :param new_size: 新的云盘大小（GB）
        :return: 扩容结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {
                    'DiskId': disk_id,
                    'NewSize': new_size
                }
                return self.client.request('ResizeDisk', params, '2014-05-26', 'ecs')
            
            request = ResizeDiskRequest()
            request.set_DiskId(disk_id)
            request.set_NewSize(new_size)
            
            self.logger.debug(f"扩容云盘: {disk_id} 到 {new_size}GB")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"扩容云盘成功: {disk_id}")
            return result
        except Exception as e:
            self.logger.error(f"扩容云盘失败: {str(e)}")
            raise
    
    def delete_disk(self, disk_id: str) -> Dict[str, Any]:
        """
        删除云盘
        
        :param disk_id: 云盘 ID
        :return: 删除结果
        """
        try:
            if not ALIYUN_ECS_SDK_AVAILABLE:
                # 回退到通用 API 调用
                params = {'DiskId': disk_id}
                return self.client.request('DeleteDisk', params, '2014-05-26', 'ecs')
            
            request = DeleteDiskRequest()
            request.set_DiskId(disk_id)
            
            self.logger.debug(f"删除云盘: {disk_id}")
            response = self.client.do_action(request)
            
            import json
            result = json.loads(response.decode('utf-8'))
            self.logger.debug(f"删除云盘成功: {disk_id}")
            return result
        except Exception as e:
            self.logger.error(f"删除云盘失败: {str(e)}")
            raise
