# -*- coding: utf-8 -*-
"""
阿里云短信服务
"""

from typing import Dict, Any, Optional, List
from PyraUtils.service.cloud.aliyun.client import AliCloudClient
from PyraUtils.service.cloud.aliyun.client import ALIYUN_SDK_AVAILABLE


class AliCloudSMSService:
    """
    阿里云短信服务
    """
    
    def __init__(self, client: AliCloudClient):
        """
        初始化短信服务
        
        :param client: 阿里云客户端
        """
        self.client = client
        self.logger = client.logger
    
    def send_sms(self, phone_numbers: List[str], sign_name: str, template_code: str, template_param: Dict[str, str]) -> Dict[str, Any]:
        """
        发送短信
        
        :param phone_numbers: 手机号码列表
        :param sign_name: 签名名称
        :param template_code: 模板代码
        :param template_param: 模板参数
        :return: 发送结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdksms.request.v20170525 import SendSmsRequest
                import json
                request = SendSmsRequest.SendSmsRequest()
                request.set_PhoneNumbers(','.join(phone_numbers))
                request.set_SignName(sign_name)
                request.set_TemplateCode(template_code)
                request.set_TemplateParam(json.dumps(template_param))
                response = self.client.client.do_action(request)
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 SMS SDK 发送短信成功: {phone_numbers}")
                return result
            else:
                import json
                params = {
                    'PhoneNumbers': ','.join(phone_numbers),
                    'SignName': sign_name,
                    'TemplateCode': template_code,
                    'TemplateParam': json.dumps(template_param)
                }
                result = self.client.request('SendSms', params, '2017-05-25', 'dysmsapi')
                self.logger.debug(f"使用 API 调用发送短信成功: {phone_numbers}")
                return result
        except Exception as e:
            error_msg = f"发送短信失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def send_batch_sms(self, phone_numbers: List[str], sign_names: List[str], template_code: str, template_params: List[Dict[str, str]]) -> Dict[str, Any]:
        """
        批量发送短信
        
        :param phone_numbers: 手机号码列表
        :param sign_names: 签名名称列表
        :param template_code: 模板代码
        :param template_params: 模板参数列表
        :return: 发送结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdksms.request.v20170525 import SendBatchSmsRequest
                import json
                request = SendBatchSmsRequest.SendBatchSmsRequest()
                request.set_PhoneNumberJson(json.dumps(phone_numbers))
                request.set_SignNameJson(json.dumps(sign_names))
                request.set_TemplateCode(template_code)
                request.set_TemplateParamJson(json.dumps(template_params))
                response = self.client.client.do_action(request)
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 SMS SDK 批量发送短信成功")
                return result
            else:
                import json
                params = {
                    'PhoneNumberJson': json.dumps(phone_numbers),
                    'SignNameJson': json.dumps(sign_names),
                    'TemplateCode': template_code,
                    'TemplateParamJson': json.dumps(template_params)
                }
                result = self.client.request('SendBatchSms', params, '2017-05-25', 'dysmsapi')
                self.logger.debug(f"使用 API 调用批量发送短信成功")
                return result
        except Exception as e:
            error_msg = f"批量发送短信失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def query_send_status(self, biz_id: str, phone_number: str, send_date: str, page_size: int = 10, current_page: int = 1) -> Dict[str, Any]:
        """
        查询发送状态
        
        :param biz_id: 业务 ID
        :param phone_number: 手机号码
        :param send_date: 发送日期
        :param page_size: 页大小
        :param current_page: 当前页
        :return: 发送状态
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdksms.request.v20170525 import QuerySendDetailsRequest
                import json
                request = QuerySendDetailsRequest.QuerySendDetailsRequest()
                request.set_BizId(biz_id)
                request.set_PhoneNumber(phone_number)
                request.set_SendDate(send_date)
                request.set_PageSize(page_size)
                request.set_CurrentPage(current_page)
                response = self.client.client.do_action(request)
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 SMS SDK 查询发送状态成功: {biz_id}")
                return result
            else:
                params = {
                    'BizId': biz_id,
                    'PhoneNumber': phone_number,
                    'SendDate': send_date,
                    'PageSize': page_size,
                    'CurrentPage': current_page
                }
                result = self.client.request('QuerySendDetails', params, '2017-05-25', 'dysmsapi')
                self.logger.debug(f"使用 API 调用查询发送状态成功: {biz_id}")
                return result
        except Exception as e:
            error_msg = f"查询发送状态失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def add_sms_sign(self, sign_name: str, sign_source: int, sign_type: int, proof_file: str, remark: str) -> Dict[str, Any]:
        """
        申请短信签名
        
        :param sign_name: 签名名称
        :param sign_source: 签名来源
        :param sign_type: 签名类型
        :param proof_file: 证明文件
        :param remark: 备注
        :return: 申请结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdksms.request.v20170525 import AddSmsSignRequest
                import json
                request = AddSmsSignRequest.AddSmsSignRequest()
                request.set_SignName(sign_name)
                request.set_SignSource(sign_source)
                request.set_SignType(sign_type)
                request.set_ProofFile(proof_file)
                request.set_Remark(remark)
                response = self.client.client.do_action(request)
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 SMS SDK 申请短信签名成功: {sign_name}")
                return result
            else:
                params = {
                    'SignName': sign_name,
                    'SignSource': sign_source,
                    'SignType': sign_type,
                    'ProofFile': proof_file,
                    'Remark': remark
                }
                result = self.client.request('AddSmsSign', params, '2017-05-25', 'dysmsapi')
                self.logger.debug(f"使用 API 调用申请短信签名成功: {sign_name}")
                return result
        except Exception as e:
            error_msg = f"申请短信签名失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def add_sms_template(self, template_name: str, template_content: str, template_type: int, remark: str) -> Dict[str, Any]:
        """
        申请短信模板
        
        :param template_name: 模板名称
        :param template_content: 模板内容
        :param template_type: 模板类型
        :param remark: 备注
        :return: 申请结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdksms.request.v20170525 import AddSmsTemplateRequest
                import json
                request = AddSmsTemplateRequest.AddSmsTemplateRequest()
                request.set_TemplateName(template_name)
                request.set_TemplateContent(template_content)
                request.set_TemplateType(template_type)
                request.set_Remark(remark)
                response = self.client.client.do_action(request)
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 SMS SDK 申请短信模板成功: {template_name}")
                return result
            else:
                params = {
                    'TemplateName': template_name,
                    'TemplateContent': template_content,
                    'TemplateType': template_type,
                    'Remark': remark
                }
                result = self.client.request('AddSmsTemplate', params, '2017-05-25', 'dysmsapi')
                self.logger.debug(f"使用 API 调用申请短信模板成功: {template_name}")
                return result
        except Exception as e:
            error_msg = f"申请短信模板失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def get_sms_sign_list(self, page_size: int = 10, current_page: int = 1) -> Dict[str, Any]:
        """
        获取短信签名列表
        
        :param page_size: 页大小
        :param current_page: 当前页
        :return: 签名列表
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdksms.request.v20170525 import QuerySmsSignListRequest
                import json
                request = QuerySmsSignListRequest.QuerySmsSignListRequest()
                request.set_PageSize(page_size)
                request.set_CurrentPage(current_page)
                response = self.client.client.do_action(request)
                result = json.loads(response.decode('utf-8'))
                self.logger.debug("使用阿里云 SMS SDK 获取短信签名列表成功")
                return result
            else:
                params = {
                    'PageSize': page_size,
                    'CurrentPage': current_page
                }
                result = self.client.request('QuerySmsSignList', params, '2017-05-25', 'dysmsapi')
                self.logger.debug("使用 API 调用获取短信签名列表成功")
                return result
        except Exception as e:
            error_msg = f"获取短信签名列表失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def get_sms_template_list(self, page_size: int = 10, current_page: int = 1) -> Dict[str, Any]:
        """
        获取短信模板列表
        
        :param page_size: 页大小
        :param current_page: 当前页
        :return: 模板列表
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdksms.request.v20170525 import QuerySmsTemplateListRequest
                import json
                request = QuerySmsTemplateListRequest.QuerySmsTemplateListRequest()
                request.set_PageSize(page_size)
                request.set_CurrentPage(current_page)
                response = self.client.client.do_action(request)
                result = json.loads(response.decode('utf-8'))
                self.logger.debug("使用阿里云 SMS SDK 获取短信模板列表成功")
                return result
            else:
                params = {
                    'PageSize': page_size,
                    'CurrentPage': current_page
                }
                result = self.client.request('QuerySmsTemplateList', params, '2017-05-25', 'dysmsapi')
                self.logger.debug("使用 API 调用获取短信模板列表成功")
                return result
        except Exception as e:
            error_msg = f"获取短信模板列表失败: {str(e)}"
            self.logger.error(error_msg)
            raise
