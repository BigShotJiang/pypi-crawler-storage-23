# -*- coding: utf-8 -*-
"""
阿里云服务
"""

from .client import AliCloudClient
from .database import AliCloudDatabaseService
from .redis import AliCloudRedisService
from .ecs import AliCloudECSService
from .dns import AliCloudDNSService
from .oss import AliCloudOSSService
from .sms import AliCloudSMSService
from ..config import CloudConfigManager
from typing import Optional


class AliCloud:
    """
    阿里云服务入口
    """
    
    def __init__(self, region: Optional[str] = None, access_key: Optional[str] = None, secret_key: Optional[str] = None, config_manager: Optional[CloudConfigManager] = None):
        """
        初始化阿里云服务
        
        :param region: 区域名称，如 cn-beijing
        :param access_key: 访问密钥
        :param secret_key: 安全密钥
        :param config_manager: 配置管理器实例
        """
        if config_manager:
            self.region = region or config_manager.get_region('aliyun')
            self.access_key = access_key or config_manager.get_access_key('aliyun')
            self.secret_key = secret_key or config_manager.get_secret_key('aliyun')
        else:
            self.region = region
            self.access_key = access_key
            self.secret_key = secret_key
        
        if not all([self.region, self.access_key, self.secret_key]):
            raise ValueError("缺少必要的配置参数")
        
        self.client = AliCloudClient(self.region, self.access_key, self.secret_key)
    
    def database(self) -> AliCloudDatabaseService:
        """
        获取数据库服务
        
        :return: 数据库服务实例
        """
        return AliCloudDatabaseService(self.client)
    
    def redis(self) -> AliCloudRedisService:
        """
        获取 Redis 服务
        
        :return: Redis 服务实例
        """
        return AliCloudRedisService(self.client)
    
    def ecs(self) -> AliCloudECSService:
        """
        获取 ECS 服务
        
        :return: ECS 服务实例
        """
        return AliCloudECSService(self.client)
    
    def dns(self) -> AliCloudDNSService:
        """
        获取 DNS 服务
        
        :return: DNS 服务实例
        """
        return AliCloudDNSService(self.client)
    
    def oss(self) -> AliCloudOSSService:
        """
        获取对象存储（OSS）服务
        
        :return: OSS 服务实例
        """
        return AliCloudOSSService(self.client)
    
    def sms(self) -> AliCloudSMSService:
        """
        获取短信服务
        
        :return: 短信服务实例
        """
        return AliCloudSMSService(self.client)


__all__ = [
    'AliCloud',
    'AliCloudClient',
    'AliCloudDatabaseService',
    'AliCloudRedisService',
    'AliCloudECSService',
    'AliCloudDNSService',
    'AliCloudOSSService',
    'AliCloudSMSService'
]
