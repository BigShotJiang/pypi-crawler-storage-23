# -*- coding: utf-8 -*-
"""
阿里云 Redis 服务
"""

from typing import Dict, Any, Optional, List
from PyraUtils.service.cloud.aliyun.client import AliCloudClient
from PyraUtils.service.cloud.aliyun.client import ALIYUN_SDK_AVAILABLE


class AliCloudRedisService:
    """
    阿里云 Redis 服务
    """
    
    def __init__(self, client: AliCloudClient):
        """
        初始化 Redis 服务
        
        :param client: 阿里云客户端
        """
        self.client = client
        self.logger = client.logger
    
    def create_instance(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        创建 Redis 实例
        
        :param params: 创建参数
        :return: 创建结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkrkvstore.request.v20150101 import CreateInstanceRequest
                import json
                request = CreateInstanceRequest.CreateInstanceRequest()
                for key, value in params.items():
                    setattr(request, f"set_{key}", value)
                response = self.client.client.do_action(request)
                result = json.loads(response.decode('utf-8'))
                self.logger.debug("使用阿里云 Redis SDK 创建实例成功")
                return result
            else:
                result = self.client.request('CreateInstance', params, '2015-01-01', 'r-kvstore')
                self.logger.debug("使用 API 调用创建实例成功")
                return result
        except Exception as e:
            error_msg = f"创建 Redis 实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def resize_instance(self, instance_id: str, new_spec: Dict[str, Any]) -> Dict[str, Any]:
        """
        调整 Redis 实例规格
        
        :param instance_id: 实例 ID
        :param new_spec: 新规格
        :return: 调整结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkrkvstore.request.v20150101 import ResizeInstanceRequest
                import json
                request = ResizeInstanceRequest.ResizeInstanceRequest()
                request.set_InstanceId(instance_id)
                for key, value in new_spec.items():
                    setattr(request, f"set_{key}", value)
                response = self.client.client.do_action(request)
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 Redis SDK 调整实例规格成功: {instance_id}")
                return result
            else:
                params = {
                    'InstanceId': instance_id,
                    **new_spec
                }
                result = self.client.request('ResizeInstance', params, '2015-01-01', 'r-kvstore')
                self.logger.debug(f"使用 API 调用调整实例规格成功: {instance_id}")
                return result
        except Exception as e:
            error_msg = f"调整 Redis 实例规格失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def list_instances(self, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        列出 Redis 实例
        
        :param params: 查询参数
        :return: 实例列表
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkrkvstore.request.v20150101 import DescribeInstancesRequest
                import json
                request = DescribeInstancesRequest.DescribeInstancesRequest()
                if params:
                    for key, value in params.items():
                        setattr(request, f"set_{key}", value)
                response = self.client.client.do_action(request)
                result = json.loads(response.decode('utf-8'))
                self.logger.debug("使用阿里云 Redis SDK 列出实例成功")
                return result.get('Instances', {}).get('KVStoreInstance', [])
            else:
                params = params or {}
                response = self.client.request('DescribeInstances', params, '2015-01-01', 'r-kvstore')
                self.logger.debug("使用 API 调用列出实例成功")
                return response.get('Instances', {}).get('KVStoreInstance', [])
        except Exception as e:
            error_msg = f"列出 Redis 实例失败: {str(e)}"
            self.logger.error(error_msg)
            raise
