# -*- coding: utf-8 -*-
"""
阿里云对象存储（OSS）服务
"""

from typing import Dict, Any, Optional, List
from PyraUtils.service.cloud.aliyun.client import AliCloudClient
from PyraUtils.service.cloud.aliyun.client import ALIYUN_SDK_AVAILABLE


class AliCloudOSSService:
    """
    阿里云对象存储（OSS）服务
    """
    
    def __init__(self, client: AliCloudClient):
        """
        初始化 OSS 服务
        
        :param client: 阿里云客户端
        """
        self.client = client
        self.logger = client.logger
    
    def create_bucket(self, bucket_name: str, storage_class: str = 'Standard') -> Dict[str, Any]:
        """
        创建存储空间
        
        :param bucket_name: 存储空间名称
        :param storage_class: 存储类型
        :return: 创建结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkoss.request.v20190517 import CreateBucketRequest
                request = CreateBucketRequest.CreateBucketRequest()
                request.set_BucketName(bucket_name)
                request.set_StorageClass(storage_class)
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 OSS SDK 创建存储空间成功: {bucket_name}")
                return result
            else:
                params = {
                    'BucketName': bucket_name,
                    'StorageClass': storage_class
                }
                result = self.client.request('CreateBucket', params, '2019-05-01', 'oss')
                self.logger.debug(f"使用 API 调用创建存储空间成功: {bucket_name}")
                return result
        except Exception as e:
            error_msg = f"创建存储空间失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def delete_bucket(self, bucket_name: str) -> Dict[str, Any]:
        """
        删除存储空间
        
        :param bucket_name: 存储空间名称
        :return: 删除结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkoss.request.v20190517 import DeleteBucketRequest
                request = DeleteBucketRequest.DeleteBucketRequest()
                request.set_BucketName(bucket_name)
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 OSS SDK 删除存储空间成功: {bucket_name}")
                return result
            else:
                params = {'BucketName': bucket_name}
                result = self.client.request('DeleteBucket', params, '2019-05-01', 'oss')
                self.logger.debug(f"使用 API 调用删除存储空间成功: {bucket_name}")
                return result
        except Exception as e:
            error_msg = f"删除存储空间失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def put_object(self, bucket_name: str, object_key: str, content: bytes, **kwargs) -> Dict[str, Any]:
        """
        上传对象
        
        :param bucket_name: 存储空间名称
        :param object_key: 对象键
        :param content: 对象内容
        :param kwargs: 其他参数
        :return: 上传结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkoss.request.v20190517 import PutObjectRequest
                request = PutObjectRequest.PutObjectRequest()
                request.set_BucketName(bucket_name)
                request.set_Key(object_key)
                request.set_Content(content)
                for key, value in kwargs.items():
                    setattr(request, f"set_{key}", value)
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 OSS SDK 上传对象成功: {object_key}")
                return result
            else:
                params = {
                    'BucketName': bucket_name,
                    'Key': object_key,
                    'Content': content,
                    **kwargs
                }
                result = self.client.request('PutObject', params, '2019-05-01', 'oss')
                self.logger.debug(f"使用 API 调用上传对象成功: {object_key}")
                return result
        except Exception as e:
            error_msg = f"上传对象失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def get_object(self, bucket_name: str, object_key: str) -> Dict[str, Any]:
        """
        获取对象
        
        :param bucket_name: 存储空间名称
        :param object_key: 对象键
        :return: 对象内容
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkoss.request.v20190517 import GetObjectRequest
                request = GetObjectRequest.GetObjectRequest()
                request.set_BucketName(bucket_name)
                request.set_Key(object_key)
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 OSS SDK 获取对象成功: {object_key}")
                return result
            else:
                params = {
                    'BucketName': bucket_name,
                    'Key': object_key
                }
                result = self.client.request('GetObject', params, '2019-05-01', 'oss')
                self.logger.debug(f"使用 API 调用获取对象成功: {object_key}")
                return result
        except Exception as e:
            error_msg = f"获取对象失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def delete_object(self, bucket_name: str, object_key: str) -> Dict[str, Any]:
        """
        删除对象
        
        :param bucket_name: 存储空间名称
        :param object_key: 对象键
        :return: 删除结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkoss.request.v20190517 import DeleteObjectRequest
                request = DeleteObjectRequest.DeleteObjectRequest()
                request.set_BucketName(bucket_name)
                request.set_Key(object_key)
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 OSS SDK 删除对象成功: {object_key}")
                return result
            else:
                params = {
                    'BucketName': bucket_name,
                    'Key': object_key
                }
                result = self.client.request('DeleteObject', params, '2019-05-01', 'oss')
                self.logger.debug(f"使用 API 调用删除对象成功: {object_key}")
                return result
        except Exception as e:
            error_msg = f"删除对象失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def list_objects(self, bucket_name: str, prefix: str = '', max_keys: int = 100) -> List[Dict[str, Any]]:
        """
        列出对象
        
        :param bucket_name: 存储空间名称
        :param prefix: 前缀
        :param max_keys: 最大返回数量
        :return: 对象列表
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkoss.request.v20190517 import ListObjectsRequest
                request = ListObjectsRequest.ListObjectsRequest()
                request.set_BucketName(bucket_name)
                request.set_Prefix(prefix)
                request.set_MaxKeys(max_keys)
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 OSS SDK 列出对象成功: {bucket_name}")
                return result.get('Contents', {}).get('Content', [])
            else:
                params = {
                    'BucketName': bucket_name,
                    'Prefix': prefix,
                    'MaxKeys': max_keys
                }
                response = self.client.request('ListObjects', params, '2019-05-01', 'oss')
                self.logger.debug(f"使用 API 调用列出对象成功: {bucket_name}")
                return response.get('Contents', {}).get('Content', [])
        except Exception as e:
            error_msg = f"列出对象失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def set_bucket_acl(self, bucket_name: str, acl: str) -> Dict[str, Any]:
        """
        设置存储空间 ACL
        
        :param bucket_name: 存储空间名称
        :param acl: ACL 类型
        :return: 设置结果
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkoss.request.v20190517 import PutBucketAclRequest
                request = PutBucketAclRequest.PutBucketAclRequest()
                request.set_BucketName(bucket_name)
                request.set_ACL(acl)
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 OSS SDK 设置存储空间 ACL 成功: {bucket_name}")
                return result
            else:
                params = {
                    'BucketName': bucket_name,
                    'ACL': acl
                }
                result = self.client.request('PutBucketAcl', params, '2019-05-01', 'oss')
                self.logger.debug(f"使用 API 调用设置存储空间 ACL 成功: {bucket_name}")
                return result
        except Exception as e:
            error_msg = f"设置存储空间 ACL 失败: {str(e)}"
            self.logger.error(error_msg)
            raise
    
    def get_bucket_acl(self, bucket_name: str) -> Dict[str, Any]:
        """
        获取存储空间 ACL
        
        :param bucket_name: 存储空间名称
        :return: ACL 信息
        """
        try:
            if ALIYUN_SDK_AVAILABLE:
                from aliyunsdkoss.request.v20190517 import GetBucketAclRequest
                request = GetBucketAclRequest.GetBucketAclRequest()
                request.set_BucketName(bucket_name)
                response = self.client.client.do_action(request)
                import json
                result = json.loads(response.decode('utf-8'))
                self.logger.debug(f"使用阿里云 OSS SDK 获取存储空间 ACL 成功: {bucket_name}")
                return result
            else:
                params = {'BucketName': bucket_name}
                result = self.client.request('GetBucketAcl', params, '2019-05-01', 'oss')
                self.logger.debug(f"使用 API 调用获取存储空间 ACL 成功: {bucket_name}")
                return result
        except Exception as e:
            error_msg = f"获取存储空间 ACL 失败: {str(e)}"
            self.logger.error(error_msg)
            raise
