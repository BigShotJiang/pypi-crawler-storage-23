# -*- coding: utf-8 -*-
"""
阿里云 API 客户端
"""

from typing import Dict, Any, Optional
from PyraUtils.log import LoguruHandler


try:
    from aliyunsdkcore.client import AcsClient
    from aliyunsdkcore.request import CommonRequest
    from aliyunsdkcore.auth.credentials import AccessKeyCredential
    from aliyunsdkcore.auth.credentials import StsTokenCredential
    from aliyunsdkecs.request.v20140526 import DescribeInstancesRequest, StartInstanceRequest, StopInstanceRequest, RebootInstanceRequest
    from aliyunsdkrds.request.v20140815 import DescribeDBInstancesRequest, StartDBInstanceRequest, StopDBInstanceRequest
    from aliyunsdkoss.request.v20190517 import PutObjectRequest, GetObjectRequest, DeleteObjectRequest
    from aliyunsdkdns.request.v20150109 import DescribeDomainRecordsRequest, AddDomainRecordRequest, UpdateDomainRecordRequest, DeleteDomainRecordRequest
    from aliyunsdksms.request.v20170525 import SendSmsRequest
    ALIYUN_SDK_AVAILABLE = True
except ImportError:
    ALIYUN_SDK_AVAILABLE = False


class AliCloudClient:
    """
    阿里云 API 客户端
    """
    
    def __init__(self, region: str, access_key: str, secret_key: str, timeout: int = 30, max_retries: int = 3):
        """
        初始化阿里云客户端
        
        :param region: 区域名称，如 cn-beijing
        :param access_key: 访问密钥
        :param secret_key: 安全密钥
        :param timeout: 请求超时时间（秒）
        :param max_retries: 最大重试次数
        """
        self.region = region
        self.access_key = access_key
        self.secret_key = secret_key
        self.timeout = timeout
        self.max_retries = max_retries
        self.logger = LoguruHandler()
        
        if not ALIYUN_SDK_AVAILABLE:
            self.logger.warning("阿里云 SDK 未安装，将使用 API 调用方式")
        
        # 创建凭证
        self.credential = AccessKeyCredential(access_key, secret_key)
        
        # 创建客户端
        self.client = AcsClient(
            credential=self.credential,
            region_id=region,
            timeout=timeout,
            auto_retry=True,
            max_retry_times=max_retries
        )
    
    def request(self, action: str, params: Dict[str, Any], version: str, service: str = 'ecs') -> Dict[str, Any]:
        """
        发送 API 请求
        
        :param action: API 操作名称
        :param params: 请求参数
        :param version: API 版本
        :param service: 服务名称
        :return: 响应结果
        :raises Exception: 请求失败时抛出异常
        """
        try:
            if not ALIYUN_SDK_AVAILABLE:
                raise ImportError("阿里云 SDK 未安装，请运行 'pip install aliyun-python-sdk-core aliyun-python-sdk-ecs aliyun-python-sdk-rds aliyun-python-sdk-oss aliyun-python-sdk-dns aliyun-python-sdk-sms' 安装")
            
            # 创建通用请求
            request = CommonRequest()
            request.set_accept_format('json')
            request.set_domain(f"{service}.aliyuncs.com")
            request.set_method('POST')
            request.set_protocol_type('https')
            request.set_version(version)
            request.set_action_name(action)
            request.set_region_id(self.region)
            
            # 设置请求参数
            for key, value in params.items():
                request.add_query_param(key, value)
            
            self.logger.debug(f"发送阿里云 API 请求: {action}, 服务: {service}, 版本: {version}")
            
            # 发送请求
            response = self.client.do_action(request)
            
            # 解析响应
            import json
            result = json.loads(response.decode('utf-8'))
            
            self.logger.debug(f"阿里云 API 请求成功: {action}")
            
            # 检查响应是否包含错误
            if 'Code' in result and result['Code'] != 'Success':
                error_msg = f"阿里云 API 错误: {result.get('Message', 'Unknown error')}"
                self.logger.error(error_msg)
                raise Exception(error_msg)
            
            return result
        except Exception as e:
            error_msg = f"阿里云 API 处理失败: {str(e)}"
            self.logger.error(error_msg)
            raise
