"""
HTTP 模块 - 提供 HTTP 请求和 JWT 认证功能

This module provides utilities for HTTP requests and JWT authentication, including:
- HttpxBasicUtil: Basic HTTP client for making requests
- HttpxClientUtil: Advanced HTTP client with connection pooling
- JWT: JSON Web Token utilities
- JWTDecorator: Decorator for JWT authentication
"""

from ._httpx import HttpxBasicUtil, HttpxClientUtil
from ._jwt import JWT, JWTDecorator

__all__ = ['HttpxBasicUtil', 'HttpxClientUtil', 'JWT', 'JWTDecorator']
