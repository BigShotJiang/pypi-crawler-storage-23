# -*- coding: utf-8 -*-

"""
created by：2021-11-25 14:21:41
modify by: 2021-12-02 19:53:33

功能：httpx二次封装，常用的get,post,head,delete方法封装。
     这个是第三方库，使用提前需要pip install httpx

参考文档:
    https://github.com/encode/httpx
    https://www.python-httpx.org/
"""

import httpx
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class HttpxBasicUtil:
    """httpx二次封装，常用的get,post,head,delete等方法封装，工具类。

    注意事项：
    - 初始化超时时间为None时，应使用 httpx.Timeout(None, None)
    使用示例：
    ```python
    resp = HttpxBasicUtil.httpx_method('GET', 'http://example.com')
    ```
    """

    @staticmethod
    def httpx_method(method:str, url:str, **kwargs) -> bytes | str:
        """Sends a request and returns response content.

        参数:

            method: - ``GET``, ``OPTIONS``, ``HEAD``, ``POST``, ``PUT``, ``PATCH``, or ``DELETE``.
            url – 新建 Request 对象的URL
            follow_redirects: 与 requests不同，HTTPX 在默认情况下不遵循重定向。如果需要自动重定向，需要明确执行此操作让"follow_redirects=True".
            params – (可选) Request 对象的查询字符中要发送的字典或字节内容
            data – (可选) Request 对象的 body 中要包括的字典、字节或类文件数据
            json – (可选) Request 对象的 body 中要包括的 Json 数据
            headers – (可选) Request 对象的字典格式的 HTTP 头
            cookies – (可选) Request 对象的字典或 CookieJar 对象
            files – (可选)字典，'name':file-like-objects(或{'name':('filename',fileobj)})用于上传含多个部分的（类）文件对象
            auth – (可选) Auth tuple to enable Basic/Digest/Custom HTTP Auth.
            timeout (浮点或元组) – (可选) 等待服务器数据的超时限制，是一个浮点数，或是一个(connect timeout, read timeout)元组
            allow_redirects (bool) – (可选) Boolean. True 表示允许跟踪 POST/PUT/DELETE 方法的重定向

        :return: 响应内容
        :rtype: bytes | str
        """
        logger.info(f"发送 {method} 请求到: {url}")
        try:
            # 构建请求参数
            timeout = kwargs.pop('timeout', 30.0)
            follow_redirects = kwargs.pop('follow_redirects', False)
            
            # 发送请求
            with httpx.Client(timeout=timeout, follow_redirects=follow_redirects) as client:
                response = client.request(method=method, url=url, **kwargs)
                
                # 检查响应状态码
                response.raise_for_status()
                
                # 根据响应内容类型返回不同格式
                if response.headers.get('content-type', '').startswith('application/json'):
                    return response.json()
                else:
                    return response.content
                    
        except httpx.HTTPError as e:
            logger.error(f"HTTP请求失败: {url}, 错误: {e}")
            raise
        except Exception as e:
            logger.error(f"请求失败: {url}, 错误: {e}")
            raise

    @staticmethod
    def httpx_get(url: str, **kwargs) -> bytes | str:
        """
        发送 GET 请求。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> httpx_get('https://api.example.com')
        '{"status": "ok"}'
        """
        return HttpxBasicUtil.httpx_method('GET', url, **kwargs)

    @staticmethod
    def httpx_post(url: str, **kwargs) -> bytes | str:
        """
        发送 POST 请求。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> httpx_post('https://api.example.com', json={'key': 'value'})
        '{"status": "ok"}'
        """
        return HttpxBasicUtil.httpx_method('POST', url, **kwargs)

    @staticmethod
    def httpx_put(url: str, **kwargs) -> bytes | str:
        """
        发送 PUT 请求。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        """
        return HttpxBasicUtil.httpx_method('PUT', url, **kwargs)

    @staticmethod
    def httpx_delete(url: str, **kwargs) -> bytes | str:
        """
        发送 DELETE 请求。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        """
        return HttpxBasicUtil.httpx_method('DELETE', url, **kwargs)

    @staticmethod
    def httpx_patch(url: str, **kwargs) -> bytes | str:
        """
        发送 PATCH 请求。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        """
        return HttpxBasicUtil.httpx_method('PATCH', url, **kwargs)

    @staticmethod
    def retry_request(method: str, url: str, max_retries: int = 3, delay: float = 1.0, backoff_factor: float = 1.0, **kwargs) -> bytes | str:
        """
        带重试机制的 HTTP 请求。

        :param method: 请求方法
        :type method: str
        :param url: 请求 URL
        :type url: str
        :param max_retries: 最大重试次数
        :type max_retries: int
        :param delay: 初始重试间隔（秒）
        :type delay: float
        :param backoff_factor: 退避因子，每次重试间隔会乘以该因子
        :type backoff_factor: float
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> retry_request('GET', 'https://api.example.com', max_retries=3)
        '{"status": "ok"}'
        """
        import time
        
        retry_count = 0
        current_delay = delay
        while retry_count < max_retries:
            try:
                return HttpxBasicUtil.httpx_method(method, url, **kwargs)
            except Exception as e:
                retry_count += 1
                if retry_count < max_retries:
                    logger.warning(f"请求失败，{current_delay:.2f}秒后重试 ({retry_count}/{max_retries}): {e}")
                    time.sleep(current_delay)
                    current_delay *= backoff_factor
                else:
                    logger.error(f"请求失败，已达到最大重试次数: {e}")
                    raise

    @staticmethod
    def upload_file(url: str, file_path: str, field_name: str = 'file', **kwargs) -> bytes | str:
        """
        上传文件。

        :param url: 上传 URL
        :type url: str
        :param file_path: 本地文件路径
        :type file_path: str
        :param field_name: 表单字段名
        :type field_name: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> upload_file('https://api.example.com/upload', 'path/to/file.txt')
        '{"status": "ok", "file_id": "123"}'
        """
        logger.info(f"开始上传文件: {file_path} -> {url}")
        
        try:
            import os
            file_name = os.path.basename(file_path)
            
            with open(file_path, 'rb') as f:
                files = {field_name: (file_name, f)}
                return HttpxBasicUtil.httpx_post(url, files=files, **kwargs)
        except Exception as e:
            logger.error(f"文件上传失败: {e}")
            raise

    @staticmethod
    def batch_requests(requests: list, max_concurrency: int = 5) -> list:
        """
        批量发送 HTTP 请求。

        :param requests: 请求列表，每个元素为字典，包含 method、url 和可选的 kwargs
        :type requests: list
        :param max_concurrency: 最大并发数
        :type max_concurrency: int
        :return: 响应列表，与请求列表顺序对应
        :rtype: list
        
        示例:
        >>> requests = [
        ...     {'method': 'GET', 'url': 'https://api.example.com/1'},
        ...     {'method': 'GET', 'url': 'https://api.example.com/2'}
        ... ]
        >>> batch_requests(requests)
        ['{"id": 1}', '{"id": 2}']
        """
        import asyncio
        from httpx import AsyncClient
        
        logger.info(f"开始批量请求，共 {len(requests)} 个请求，最大并发数: {max_concurrency}")
        
        async def send_request(req, client):
            try:
                method = req['method']
                url = req['url']
                kwargs = req.get('kwargs', {})
                
                response = await client.request(method, url, **kwargs)
                response.raise_for_status()
                
                if response.headers.get('content-type', '').startswith('application/json'):
                    return response.json()
                else:
                    return response.content
            except Exception as e:
                logger.error(f"批量请求失败: {url}, 错误: {e}")
                return None
        
        async def main():
            async with AsyncClient(timeout=30.0, follow_redirects=False) as client:
                # 限制并发数
                semaphore = asyncio.Semaphore(max_concurrency)
                
                async def bounded_send_request(req):
                    async with semaphore:
                        return await send_request(req, client)
                
                tasks = [bounded_send_request(req) for req in requests]
                results = await asyncio.gather(*tasks)
                return results
        
        try:
            results = asyncio.run(main())
            logger.info(f"批量请求完成，成功 {sum(1 for r in results if r is not None)} 个，失败 {sum(1 for r in results if r is None)} 个")
            return results
        except Exception as e:
            logger.error(f"批量请求执行失败: {e}")
            raise

    @staticmethod
    def get_session_with_cookies(cookies: dict = None) -> httpx.Client:
        """
        获取带 cookie 的 HTTP 会话。

        :param cookies: cookie 字典
        :type cookies: dict
        :return: HTTP 客户端会话
        :rtype: httpx.Client
        
        示例:
        >>> session = get_session_with_cookies({"session_id": "123456"})
        >>> response = session.get('https://api.example.com')
        """
        client = httpx.Client(timeout=30.0, follow_redirects=False)
        if cookies:
            client.cookies.update(cookies)
        return client

    @staticmethod
    def get_json_response(url: str, **kwargs) -> dict:
        """
        发送 GET 请求并返回 JSON 响应。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: JSON 响应
        :rtype: dict
        
        示例:
        >>> get_json_response('https://api.example.com/data')
        {'status': 'ok', 'data': [...]}
        """
        response = HttpxBasicUtil.httpx_get(url, **kwargs)
        if not isinstance(response, dict):
            raise ValueError("Response is not JSON format")
        return response

    @staticmethod
    def post_json_response(url: str, json_data: dict, **kwargs) -> dict:
        """
        发送 POST 请求并返回 JSON 响应。

        :param url: 请求 URL
        :type url: str
        :param json_data: JSON 数据
        :type json_data: dict
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: JSON 响应
        :rtype: dict
        
        示例:
        >>> post_json_response('https://api.example.com/create', {'name': 'test'})
        {'status': 'ok', 'id': 123}
        """
        response = HttpxBasicUtil.httpx_post(url, json=json_data, **kwargs)
        if not isinstance(response, dict):
            raise ValueError("Response is not JSON format")
        return response

    @staticmethod
    def get_session() -> httpx.Client:
        """
        获取 HTTP 会话。

        :return: HTTP 客户端会话
        :rtype: httpx.Client
        
        示例:
        >>> session = get_session()
        >>> response = session.get('https://api.example.com')
        """
        return httpx.Client(timeout=30.0, follow_redirects=False)

    @staticmethod
    def download_file(url: str, save_path: str, chunk_size: int = 8192) -> bool:
        """
        下载文件。

        :param url: 文件 URL
        :type url: str
        :param save_path: 保存路径
        :type save_path: str
        :param chunk_size: 下载块大小
        :type chunk_size: int
        :return: 下载是否成功
        :rtype: bool
        
        示例:
        >>> download_file('https://example.com/file.zip', 'download.zip')
        True
        """
        logger.info(f"开始下载文件: {url} -> {save_path}")
        
        try:
            with httpx.stream('GET', url) as response:
                response.raise_for_status()
                
                # 创建目录
                import os
                os.makedirs(os.path.dirname(save_path), exist_ok=True)
                
                # 写入文件
                with open(save_path, 'wb') as f:
                    for chunk in response.iter_bytes(chunk_size=chunk_size):
                        f.write(chunk)
                
            logger.info(f"文件下载成功: {save_path}")
            return True
        except Exception as e:
            logger.error(f"文件下载失败: {e}")
            return False

    @staticmethod
    def get_with_retry(url: str, max_retries: int = 3, delay: float = 1.0, backoff_factor: float = 1.0, **kwargs) -> bytes | str:
        """
        带重试机制的 GET 请求。

        :param url: 请求 URL
        :type url: str
        :param max_retries: 最大重试次数
        :type max_retries: int
        :param delay: 初始重试间隔（秒）
        :type delay: float
        :param backoff_factor: 退避因子，每次重试间隔会乘以该因子
        :type backoff_factor: float
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> get_with_retry('https://api.example.com')
        '{"status": "ok"}'
        """
        return HttpxBasicUtil.retry_request('GET', url, max_retries, delay, backoff_factor, **kwargs)

    @staticmethod
    def post_with_retry(url: str, max_retries: int = 3, delay: float = 1.0, backoff_factor: float = 1.0, **kwargs) -> bytes | str:
        """
        带重试机制的 POST 请求。

        :param url: 请求 URL
        :type url: str
        :param max_retries: 最大重试次数
        :type max_retries: int
        :param delay: 初始重试间隔（秒）
        :type delay: float
        :param backoff_factor: 退避因子，每次重试间隔会乘以该因子
        :type backoff_factor: float
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> post_with_retry('https://api.example.com', json={'key': 'value'})
        '{"status": "ok"}'
        """
        return HttpxBasicUtil.retry_request('POST', url, max_retries, delay, backoff_factor, **kwargs)

    @staticmethod
    def httpx_head(url: str, **kwargs) -> bytes | str:
        """
        发送 HEAD 请求。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        """
        return HttpxBasicUtil.httpx_method('HEAD', url, **kwargs)

    @staticmethod
    def httpx_options(url: str, **kwargs) -> bytes | str:
        """
        发送 OPTIONS 请求。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        """
        return HttpxBasicUtil.httpx_method('OPTIONS', url, **kwargs)

    @staticmethod
    def stream_get(url: str, chunk_size: int = 8192, **kwargs) -> httpx.Response:
        """
        流式获取数据。

        :param url: 请求 URL
        :type url: str
        :param chunk_size: 块大小
        :type chunk_size: int
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应对象
        :rtype: httpx.Response
        
        示例:
        >>> with stream_get('https://example.com/large-file.txt') as response:
        ...     for chunk in response.iter_bytes(chunk_size=1024):
        ...         process_chunk(chunk)
        """
        logger.info(f"开始流式获取: {url}")
        return httpx.stream('GET', url, **kwargs)

    @staticmethod
    def get_text(url: str, **kwargs) -> str:
        """
        发送 GET 请求并返回文本响应。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 文本响应
        :rtype: str
        
        示例:
        >>> get_text('https://example.com')
        '<html>...</html>'
        """
        response = HttpxBasicUtil.httpx_get(url, **kwargs)
        if isinstance(response, bytes):
            return response.decode('utf-8')
        return response

    @staticmethod
    def get_content(url: str, **kwargs) -> bytes:
        """
        发送 GET 请求并返回字节响应。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 字节响应
        :rtype: bytes
        
        示例:
        >>> get_content('https://example.com/image.jpg')
        b'\xff\xd8\xff\xe0...'
        """
        response = HttpxBasicUtil.httpx_get(url, **kwargs)
        if isinstance(response, str):
            return response.encode('utf-8')
        return response

    @staticmethod
    def post_form(url: str, data: dict, **kwargs) -> bytes | str:
        """
        发送表单 POST 请求。

        :param url: 请求 URL
        :type url: str
        :param data: 表单数据
        :type data: dict
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> post_form('https://api.example.com/login', {'username': 'user', 'password': 'pass'})
        '{"status": "ok"}'
        """
        return HttpxBasicUtil.httpx_post(url, data=data, **kwargs)

    @staticmethod
    def get_status_code(url: str, **kwargs) -> int:
        """
        获取 URL 的状态码。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 状态码
        :rtype: int
        
        示例:
        >>> get_status_code('https://example.com')
        200
        """
        logger.info(f"获取状态码: {url}")
        try:
            with httpx.Client(timeout=30.0, follow_redirects=False) as client:
                response = client.head(url, **kwargs)
                return response.status_code
        except Exception as e:
            logger.error(f"获取状态码失败: {e}")
            raise

    @staticmethod
    def is_url_accessible(url: str, timeout: float = 5.0) -> bool:
        """
        检查 URL 是否可访问。

        :param url: 要检查的 URL
        :type url: str
        :param timeout: 超时时间（秒）
        :type timeout: float
        :return: URL 是否可访问
        :rtype: bool
        
        示例:
        >>> is_url_accessible('https://example.com')
        True
        """
        logger.info(f"检查 URL 可访问性: {url}")
        try:
            with httpx.Client(timeout=timeout, follow_redirects=False) as client:
                response = client.head(url)
                return 200 <= response.status_code < 400
        except Exception as e:
            logger.error(f"检查 URL 可访问性失败: {e}")
            return False

    @staticmethod
    def get_page_title(url: str, **kwargs) -> str:
        """
        获取网页标题。

        :param url: 网页 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 网页标题
        :rtype: str
        
        示例:
        >>> get_page_title('https://example.com')
        'Example Domain'
        """
        import re
        
        logger.info(f"获取网页标题: {url}")
        try:
            html = HttpxBasicUtil.get_text(url, **kwargs)
            match = re.search(r'<title>(.*?)</title>', html, re.IGNORECASE)
            if match:
                return match.group(1).strip()
            return ""
        except Exception as e:
            logger.error(f"获取网页标题失败: {e}")
            return ""

    @staticmethod
    def request_with_timeout(url: str, method: str = 'GET', timeout: float = 30.0, **kwargs) -> bytes | str:
        """
        带超时设置的请求。

        :param url: 请求 URL
        :type url: str
        :param method: 请求方法
        :type method: str
        :param timeout: 超时时间（秒）
        :type timeout: float
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> request_with_timeout('https://example.com', timeout=10.0)
        '<html>...</html>'
        """
        return HttpxBasicUtil.httpx_method(method, url, timeout=timeout, **kwargs)

    @staticmethod
    def request_with_auth(url: str, method: str = 'GET', auth: tuple = None, **kwargs) -> bytes | str:
        """
        带认证的请求。

        :param url: 请求 URL
        :type url: str
        :param method: 请求方法
        :type method: str
        :param auth: 认证信息，格式为 (username, password)
        :type auth: tuple
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> request_with_auth('https://api.example.com', auth=('user', 'pass'))
        '{"status": "ok"}'
        """
        return HttpxBasicUtil.httpx_method(method, url, auth=auth, **kwargs)

    @staticmethod
    def request_with_proxy(url: str, method: str = 'GET', proxy: str = None, **kwargs) -> bytes | str:
        """
        带代理的请求。

        :param url: 请求 URL
        :type url: str
        :param method: 请求方法
        :type method: str
        :param proxy: 代理地址
        :type proxy: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> request_with_proxy('https://example.com', proxy='http://127.0.0.1:8080')
        '<html>...</html>'
        """
        proxies = None
        if proxy:
            proxies = {
                'http': proxy,
                'https': proxy
            }
        return HttpxBasicUtil.httpx_method(method, url, proxies=proxies, **kwargs)

    @staticmethod
    def simulate_browser_request(url: str, **kwargs) -> bytes | str:
        """
        模拟浏览器请求。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> simulate_browser_request('https://example.com')
        '<html>...</html>'
        """
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
        
        # 合并 headers
        if 'headers' in kwargs:
            headers.update(kwargs['headers'])
        kwargs['headers'] = headers
        
        return HttpxBasicUtil.httpx_get(url, **kwargs)

    @staticmethod
    def get_redirect_url(url: str, **kwargs) -> str:
        """
        获取 URL 的重定向地址。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 重定向地址
        :rtype: str
        
        示例:
        >>> get_redirect_url('https://short.url/abc123')
        'https://example.com'
        """
        logger.info(f"获取重定向 URL: {url}")
        try:
            with httpx.Client(timeout=30.0, follow_redirects=False) as client:
                response = client.get(url, **kwargs)
                if response.status_code in (301, 302, 303, 307, 308):
                    return response.headers.get('Location', '')
                return url
        except Exception as e:
            logger.error(f"获取重定向 URL 失败: {e}")
            return url

    @staticmethod
    def get_response_headers(url: str, **kwargs) -> dict:
        """
        获取 URL 的响应头。

        :param url: 请求 URL
        :type url: str
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应头
        :rtype: dict
        
        示例:
        >>> get_response_headers('https://example.com')
        {'Content-Type': 'text/html', ...}
        """
        logger.info(f"获取响应头: {url}")
        try:
            with httpx.Client(timeout=30.0, follow_redirects=False) as client:
                response = client.head(url, **kwargs)
                return dict(response.headers)
        except Exception as e:
            logger.error(f"获取响应头失败: {e}")
            return {}

    @staticmethod
    def post_json(url: str, data: dict, **kwargs) -> bytes | str:
        """
        发送 JSON POST 请求。

        :param url: 请求 URL
        :type url: str
        :param data: JSON 数据
        :type data: dict
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> post_json('https://api.example.com', {'key': 'value'})
        '{"status": "ok"}'
        """
        return HttpxBasicUtil.httpx_post(url, json=data, **kwargs)

    @staticmethod
    def put_json(url: str, data: dict, **kwargs) -> bytes | str:
        """
        发送 JSON PUT 请求。

        :param url: 请求 URL
        :type url: str
        :param data: JSON 数据
        :type data: dict
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> put_json('https://api.example.com/123', {'key': 'value'})
        '{"status": "ok"}'
        """
        return HttpxBasicUtil.httpx_method('PUT', url, json=data, **kwargs)

    @staticmethod
    def patch_json(url: str, data: dict, **kwargs) -> bytes | str:
        """
        发送 JSON PATCH 请求。

        :param url: 请求 URL
        :type url: str
        :param data: JSON 数据
        :type data: dict
        :param kwargs: 其他请求参数
        :type kwargs: dict
        :return: 响应内容
        :rtype: bytes | str
        
        示例:
        >>> patch_json('https://api.example.com/123', {'key': 'value'})
        '{"status": "ok"}'
        """
        return HttpxBasicUtil.httpx_method('PATCH', url, json=data, **kwargs)


class HttpxClientUtil:
    """
    
    httpx连接池二次封装，异步支持
    
    常用的get,post,head,delete方法封装，工具类。

    注意事项：
    - 初始化超时时间为None时，应使用 httpx.Timeout(None, None)
    - proxies 参数建议使用字典类型，格式如下：
      {
          "http": "http://user:password@192.168.0.1:8080",
          "https": "https://user:password@192.168.0.1:8080",
      }
    使用示例：
    ```python
    client = HttpxClientUtil(timeout=httpx.Timeout(5.0, connect_timeout=2.0))
    resp = client.httpx_method('GET', 'http://example.com')
    ```
    """

    def __init__(self, http2:bool=False, proxies=None, timeout=5.0,
                max_keepalive=20, max_connections=100, keepalive_expiry:float=5.0) -> None:
        """
        http2: 是否启用 HTTP/2 支持的客户端，默认为 False。
        proxies： 代理地址，建议使用字典格式。可以分别指定 http 和 https 的代理地址。格式如下：
            {
                "http": "http://user:password@192.168.0.1:8080",
                "https": "https://user:password@192.168.0.1:8080",
            }
        max_keepalive : 允许保持活动连接的数量，默认为 20。可以设置为 None 来无限制。
        max_connections: 最大允许连接数，默认为 100。可以设置为 None 来无限制。
        keepalive_expiry: 浮点， 指定连接的存活期限,默认为5.0
        timeout: 超时时间，可以是浮点数或者 None。如果传入 None，则默认禁止超时；如果不是 None，则应该使用 httpx.Timeout 类型。
        """
        self.http2 = http2
        self.proxies = proxies
        self.timeout = httpx.Timeout(timeout) if timeout is not None else httpx.Timeout(None)

        self.limits = httpx.Limits(
            max_keepalive_connections=max_keepalive,
            max_connections=max_connections,
            keepalive_expiry=keepalive_expiry
        )
        
        logger.info(f"HttpxClientUtil 初始化成功: HTTP/2={http2}, 超时={timeout}, 最大连接数={max_connections}")

    def httpx_method(self, method, url, **kwargs) -> httpx.Response:
        """同步方法，使用 httpx.Client 进行请求，在请求完成后自动关闭客户端。"""
        logger.info(f"发送同步 {method} 请求到: {url}")
        if kwargs.get('params'):
            logger.debug(f"请求参数: {kwargs.get('params')}")
        if kwargs.get('json'):
            logger.debug(f"请求体: {kwargs.get('json')}")
            
        try:
            with httpx.Client(
                http2=self.http2,
                proxies=self.proxies,
                timeout=self.timeout,
                limits=self.limits
            ) as client:
                resp = client.request(method, url, **kwargs)
                resp.raise_for_status()
                logger.info(f"同步请求成功，状态码: {resp.status_code}")
                return resp
        except (httpx.RequestError, httpx.HTTPStatusError) as err:
            logger.error(f"同步请求出错: {err}")
            raise RuntimeError(f"请求出错: {err}")
        except Exception as e:
            logger.error(f"同步请求未知错误: {e}")
            raise RuntimeError(f"未知错误: {e}")

    async def async_method(self, method, url, **kwargs) -> httpx.Response:
        """异步方法，使用 httpx.AsyncClient 进行请求，在异步操作完成后自动关闭客户端。"""
        logger.info(f"发送异步 {method} 请求到: {url}")
        if kwargs.get('params'):
            logger.debug(f"请求参数: {kwargs.get('params')}")
        if kwargs.get('json'):
            logger.debug(f"请求体: {kwargs.get('json')}")
            
        try:
            async with httpx.AsyncClient(
                http2=self.http2,
                proxies=self.proxies,
                timeout=self.timeout,
                limits=self.limits
            ) as client:
                resp = await client.request(method, url, **kwargs)
                resp.raise_for_status()
                logger.info(f"异步请求成功，状态码: {resp.status_code}")
                return resp
        except (httpx.RequestError, httpx.HTTPStatusError) as err:
            logger.error(f"异步请求出错: {err}")
            raise RuntimeError(f"请求出错: {err}")
        except Exception as e:
            logger.error(f"异步请求未知错误: {e}")
            raise RuntimeError(f"未知错误: {e}")
