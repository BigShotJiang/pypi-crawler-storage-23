# -*- coding: utf-8 -*-
"""
created by：2022-07-29 16:17:18
modify by: 2022-08-01 18:51:42
功能：时间相关的函数封装
"""

import pytz
import datetime
import calendar
from typing import Optional

class TimeUtils:
    """
    时间处理工具类，提供各种常用的时间操作方法。
    """

    @staticmethod
    def datetime_strftime_now(tz_info: Optional[str] = "Asia/Shanghai",
                              strftime: str = "%Y-%m-%d %H:%M:%S") -> str:
        """
        获取当前时间的格式化字符串。

        :param tz_info: 时区信息，如 "Asia/Shanghai"，None 表示使用本地时区
        :type tz_info: Optional[str]
        :param strftime: 时间格式化字符串，默认 "%Y-%m-%d %H:%M:%S"
        :type strftime: str
        :return: 格式化后的时间字符串
        :rtype: str
        :raises pytz.exceptions.UnknownTimeZoneError: 如果提供了无效的时区信息
        
        示例用法：
        >>> TimeUtils.datetime_strftime_now()
        '2023-12-25 10:30:45'
        >>> TimeUtils.datetime_strftime_now(tz_info="UTC", strftime="%Y-%m-%dT%H:%M:%SZ")
        '2023-12-25T02:30:45Z'
        """
        if tz_info:
            tz_info_obj = pytz.timezone(tz_info)
            return datetime.datetime.now(tz=tz_info_obj).strftime(strftime) 
        else:
            return datetime.datetime.now().strftime(strftime)

    @staticmethod
    def timegm_timestamp(value: datetime.datetime) -> float:
        """
        将 datetime 对象转换为 Unix 时间戳（秒）。

        :param value: 要转换的 datetime 对象
        :type value: datetime.datetime
        :return: Unix 时间戳（自 1970-01-01 00:00:00 UTC 以来的秒数）
        :rtype: float
        
        示例用法：
        >>> dt = datetime.datetime(2023, 12, 25, 10, 30, 45)
        >>> TimeUtils.timegm_timestamp(dt)
        1703490645.0
        """
        if value.tzinfo is None:
            # 假设无时区的datetime对象是UTC时间
            return float(calendar.timegm(value.timetuple()))
        else:
            # 对于带时区的datetime对象，先转换为UTC再获取时间戳
            return float(calendar.timegm(value.astimezone(datetime.timezone.utc).timetuple()))

    @staticmethod
    def datetime_utc_now(date_type: str = "seconds", tz: Optional[datetime.tzinfo] = None, 
                        timedelta: int = 0) -> datetime.datetime:
        """
        获取当前 UTC 时间，并可选择添加时间偏移。

        :param date_type: 时间偏移的单位，支持 seconds、minutes、hours、days、weeks
        :type date_type: str
        :param tz: 时区信息，默认使用 UTC 时区
        :type tz: Optional[datetime.tzinfo]
        :param timedelta: 时间偏移量，正数表示未来时间，负数表示过去时间
        :type timedelta: int
        :return: 带时区信息的 datetime 对象
        :rtype: datetime.datetime
        
        示例用法：
        >>> TimeUtils.datetime_utc_now()
        datetime.datetime(2023, 12, 25, 2, 30, 45, 123456, tzinfo=datetime.timezone.utc)
        >>> TimeUtils.datetime_utc_now(date_type="minutes", timedelta=30)
        datetime.datetime(2023, 12, 25, 3, 0, 45, 123456, tzinfo=datetime.timezone.utc)
        """
        if tz is None:
            tz = datetime.timezone.utc

        # 验证 date_type 参数
        valid_date_types = {'seconds', 'minutes', 'hours', 'days', 'weeks'}
        if date_type.lower() not in valid_date_types:
            raise ValueError(f"无效的 date_type: {date_type}，支持的类型包括: {', '.join(valid_date_types)}")

        datetime_timedelta = datetime.timedelta(**{date_type.lower(): timedelta}) 
        return datetime.datetime.now(tz=tz) + datetime_timedelta

    @staticmethod
    def timestamp_to_datetime(timestamp: float, tz: Optional[datetime.tzinfo] = None) -> datetime.datetime:
        """
        将 Unix 时间戳转换为 datetime 对象。

        :param timestamp: Unix 时间戳（秒）
        :type timestamp: float
        :param tz: 时区信息，默认使用 UTC 时区
        :type tz: Optional[datetime.tzinfo]
        :return: datetime 对象
        :rtype: datetime.datetime
        
        示例用法：
        >>> TimeUtils.timestamp_to_datetime(1703490645.0)
        datetime.datetime(2023, 12, 25, 10, 30, 45, tzinfo=datetime.timezone.utc)
        """
        if tz is None:
            tz = datetime.timezone.utc
        return datetime.datetime.fromtimestamp(timestamp, tz=tz)

    @staticmethod
    def string_to_datetime(date_string: str, format_str: str = "%Y-%m-%d %H:%M:%S") -> datetime.datetime:
        """
        将字符串转换为 datetime 对象。

        :param date_string: 日期时间字符串
        :type date_string: str
        :param format_str: 日期时间格式，默认 "%Y-%m-%d %H:%M:%S"
        :type format_str: str
        :return: datetime 对象
        :rtype: datetime.datetime
        
        示例用法：
        >>> TimeUtils.string_to_datetime('2023-12-25 10:30:45')
        datetime.datetime(2023, 12, 25, 10, 30, 45)
        """
        return datetime.datetime.strptime(date_string, format_str)

    @staticmethod
    def datetime_to_string(dt: datetime.datetime, format_str: str = "%Y-%m-%d %H:%M:%S") -> str:
        """
        将 datetime 对象转换为字符串。

        :param dt: datetime 对象
        :type dt: datetime.datetime
        :param format_str: 日期时间格式，默认 "%Y-%m-%d %H:%M:%S"
        :type format_str: str
        :return: 格式化后的字符串
        :rtype: str
        
        示例用法：
        >>> dt = datetime.datetime(2023, 12, 25, 10, 30, 45)
        >>> TimeUtils.datetime_to_string(dt)
        '2023-12-25 10:30:45'
        """
        return dt.strftime(format_str)

    @staticmethod
    def format_duration(seconds: float) -> str:
        """
        格式化时间差，将秒数转换为可读的时间格式。

        :param seconds: 秒数
        :type seconds: float
        :return: 格式化后的时间字符串
        :rtype: str
        
        示例用法：
        >>> TimeUtils.format_duration(3661)
        '1小时1分钟1秒'
        """
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        parts = []
        if hours > 0:
            parts.append(f"{int(hours)}小时")
        if minutes > 0:
            parts.append(f"{int(minutes)}分钟")
        if seconds > 0:
            parts.append(f"{int(seconds)}秒")
        return "".join(parts) if parts else "0秒"

    @staticmethod
    def get_relative_time(dt: datetime.datetime) -> str:
        """
        获取相对时间，如 "3分钟前"、"1小时前" 等。

        :param dt: 要比较的 datetime 对象
        :type dt: datetime.datetime
        :return: 相对时间字符串
        :rtype: str
        
        示例用法：
        >>> dt = datetime.datetime.now() - datetime.timedelta(minutes=5)
        >>> TimeUtils.get_relative_time(dt)
        '5分钟前'
        """
        now = datetime.datetime.now(datetime.timezone.utc)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=datetime.timezone.utc)
        delta = now - dt
        seconds = delta.total_seconds()
        
        if seconds < 60:
            return f"{int(seconds)}秒前"
        elif seconds < 3600:
            return f"{int(seconds / 60)}分钟前"
        elif seconds < 86400:
            return f"{int(seconds / 3600)}小时前"
        elif seconds < 604800:
            return f"{int(seconds / 86400)}天前"
        else:
            return dt.strftime("%Y-%m-%d")

    @staticmethod
    def get_weekday(dt: datetime.datetime, lang: str = "zh") -> str:
        """
        获取指定日期的星期几。

        :param dt: datetime 对象
        :type dt: datetime.datetime
        :param lang: 语言，支持 "zh"（中文）和 "en"（英文）
        :type lang: str
        :return: 星期几字符串
        :rtype: str
        
        示例用法：
        >>> dt = datetime.datetime(2023, 12, 25)
        >>> TimeUtils.get_weekday(dt)
        '星期一'
        >>> TimeUtils.get_weekday(dt, lang="en")
        'Monday'
        """
        if lang == "zh":
            weekdays = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"]
        else:
            weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        return weekdays[dt.weekday() + 1]

    @staticmethod
    def get_month_days(year: int, month: int) -> int:
        """
        获取指定月份的天数。

        :param year: 年份
        :type year: int
        :param month: 月份（1-12）
        :type month: int
        :return: 月份天数
        :rtype: int
        
        示例用法：
        >>> TimeUtils.get_month_days(2023, 2)
        28
        >>> TimeUtils.get_month_days(2024, 2)
        29
        """
        return calendar.monthrange(year, month)[1]

    @staticmethod
    def is_weekend(dt: datetime.datetime) -> bool:
        """
        判断指定日期是否为周末。

        :param dt: datetime 对象
        :type dt: datetime.datetime
        :return: 是否为周末
        :rtype: bool
        
        示例用法：
        >>> dt = datetime.datetime(2023, 12, 23)  # 星期六
        >>> TimeUtils.is_weekend(dt)
        True
        """
        return dt.weekday() >= 5

    @staticmethod
    def add_business_days(dt: datetime.datetime, days: int) -> datetime.datetime:
        """
        添加工作日（排除周末）。

        :param dt: 起始 datetime 对象
        :type dt: datetime.datetime
        :param days: 要添加的工作日天数
        :type days: int
        :return: 新的 datetime 对象
        :rtype: datetime.datetime
        
        示例用法：
        >>> dt = datetime.datetime(2023, 12, 22)  # 星期五
        >>> TimeUtils.add_business_days(dt, 1)
        datetime.datetime(2023, 12, 25, ...)  # 星期一
        """
        current = dt
        while days > 0:
            current += datetime.timedelta(days=1)
            if not TimeUtils.is_weekend(current):
                days -= 1
        return current

    @staticmethod
    def get_quarter(dt: datetime.datetime) -> int:
        """
        获取指定日期的季度。

        :param dt: datetime 对象
        :type dt: datetime.datetime
        :return: 季度（1-4）
        :rtype: int
        
        示例用法：
        >>> dt = datetime.datetime(2023, 4, 1)
        >>> TimeUtils.get_quarter(dt)
        2
        """
        return (dt.month - 1) // 3 + 1
