#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by：2018-2-23 14:15:57
modify by: 2023-05-17 17:46:40

功能：封装常见文件操作的工具类，包括打开大文件、创建目录、复制目录树、获取目录下的文件列表、更改文件所有权、
      批量重命名文件、单个文件重命名以及压缩与解压文件。
"""
import os
from pathlib import Path
from typing import List
import gzip
import lzma
import shutil
import tarfile
import zipfile
import py7zr
import platform
import io
import bz2
import hashlib
import tempfile
import datetime
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()

class FileUtils:
    """
    封装常见文件操作的工具类，包括打开大文件、创建目录、复制目录树、获取目录下的文件列表、更改文件所有权
    """
    @staticmethod
    def open_large_file(filename: str):
        """
        逐行读取大文件，使用生成器避免一次性加载整个文件到内存中。

        :param filename: 要逐行读取的文件路径
        :type filename: str
        :yield: 文件的每一行内容（已去除首尾空白字符）
        :raises OSError: 如果文件无法打开或读取
        """
        logger.info(f"开始逐行读取大文件: {filename}")
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                for line in f:
                    yield line.strip()
            logger.info(f"大文件读取完成: {filename}")
        except OSError as e:
            logger.error(f"读取文件失败: {filename}, 错误: {e}")
            raise

    @staticmethod
    def create_folder(path: str) -> None:
        """
        创建目录，如果目录的上级目录不存在，也会被递归创建。

        :param path: 要创建的目录路径
        :type path: str
        :raises OSError: 如果无法创建目录（如权限不足）
        """
        logger.info(f"开始创建目录: {path}")
        try:
            Path(path).mkdir(parents=True, exist_ok=True)
            logger.info(f"目录创建成功: {path}")
        except OSError as e:
            logger.error(f"创建目录失败: {path}, 错误: {e}")
            raise

    @staticmethod
    def copy(src: str, dst: str, ignore=None, dirs_exist_ok=True) -> None:
        """
        递归地复制一个目录树到指定目录。

        :param src: 源目录的路径。
        :param dst: 目标目录的路径。
        :param ignore: 可选参数, 默认为None。可以是shutil.ignore_patterns()返回的函数，
                      或包含忽略模式的列表/元组，或None表示不忽略任何文件。
        :param dirs_exist_ok: 可选参数，默认为True。当目标目录存在时是否抛出异常。
        
        :raises FileNotFoundError: 如果源目录不存在
        :raises OSError: 如果无法复制目录
        """
        logger.info(f"开始复制目录: 从 {src} 到 {dst}")
        src_path = Path(src)
        dst_path = Path(dst)
        
        if not src_path.exists():
            logger.error(f"源目录不存在: {src}")
            raise FileNotFoundError(f"源目录不存在: {src}")
            
        if ignore and isinstance(ignore, (list, tuple)):
            # 如果ignore是列表或元组，将其转换为shutil.ignore_patterns函数
            ignore = shutil.ignore_patterns(*ignore)

        try:
            # 使用shutil.copytree进行目录复制
            shutil.copytree(src, dst, ignore=ignore, dirs_exist_ok=dirs_exist_ok)
            logger.info(f"目录复制成功: 从 {src} 到 {dst}")
        except OSError as e:
            logger.error(f"复制目录失败: 从 {src} 到 {dst}, 错误: {e}")
            raise

    @staticmethod
    def get_listfile_01(path: str) -> List[str]:
        """
        使用 os.walk() 遍历指定目录，返回目录下所有文件的路径（不包含文件夹）。

        :param path: 指定的目录路径
        :type path: str
        :return: 包含指定目录下所有文件的路径列表
        :rtype: List[str]
        :raises FileNotFoundError: 如果指定的目录不存在
        """
        logger.info(f"开始获取目录文件列表（方法1）: {path}")
        path_obj = Path(path)
        if not path_obj.exists():
            logger.error(f"目录不存在: {path}")
            raise FileNotFoundError(f"目录不存在: {path}")
            
        file_path_list = []
        for root, _, files in os.walk(path):
            file_path_list.extend(os.path.join(root, f) for f in files)

        logger.info(f"获取目录文件列表完成，共 {len(file_path_list)} 个文件")
        return file_path_list

    @staticmethod
    def get_listfile_02(path: str) -> List[str]:
        """
        使用 os.scandir() 递归遍历指定目录，返回目录下所有文件的路径（不包含文件夹）。
        
        os.scandir() 可能相较 os.walk() 性能更高，尤其在列出大量目录内容时。

        :param path: 指定的目录路径
        :type path: str
        :return: 包含指定目录下所有文件的路径列表
        :rtype: List[str]
        :raises FileNotFoundError: 如果指定的目录不存在
        """
        logger.info(f"开始获取目录文件列表（方法2）: {path}")
        path_obj = Path(path)
        if not path_obj.exists():
            logger.error(f"目录不存在: {path}")
            raise FileNotFoundError(f"目录不存在: {path}")
            
        file_path_list = []
        
        def scan_dir(dir_path):
            for entry in os.scandir(dir_path):
                if entry.is_file():
                    file_path_list.append(entry.path)
                # 如果entry是文件夹，则递归调用scan_dir()来扫描其内部
                elif entry.is_dir():
                    scan_dir(entry.path)

        scan_dir(path)
        logger.info(f"获取目录文件列表完成，共 {len(file_path_list)} 个文件")
        return file_path_list

    @staticmethod
    def get_listfile_03(path: str, include_files: bool = True, include_dirs: bool = False) -> List[str]:
        """获取指定目录下的所有文件和/或文件夹列表。

        :param path: 目标文件夹路径
        :type path: str
        :param include_files: 是否包含文件，默认值为 True
        :type include_files: bool
        :param include_dirs: 是否包含子文件夹，默认值为 False
        :type include_dirs: bool
        :return: 包含指定目录下的文件或文件夹路径的列表
        :rtype: List[str]
        :raises FileNotFoundError: 如果指定的目录不存在
        :raises ValueError: 如果 include_files 和 include_dirs 都为 False
        """
        logger.info(f"开始获取目录文件列表（方法3）: {path}, 包含文件: {include_files}, 包含目录: {include_dirs}")
        path_obj = Path(path)
        if not path_obj.exists():
            logger.error(f"目录不存在: {path}")
            raise FileNotFoundError(f"目录不存在: {path}")

        file_list = []
        dir_list = []

        for root, dirs, files in os.walk(path, topdown=False):
            if include_files:
                file_list.extend([os.path.join(root, f) for f in files])
            if include_dirs:
                dir_list.extend([os.path.join(root, d) for d in dirs])

        if include_files and include_dirs:
            result = [*file_list, *dir_list]
            logger.info(f"获取目录文件和目录列表完成，共 {len(result)} 个项目")
            return result
        elif include_files:
            logger.info(f"获取目录文件列表完成，共 {len(file_list)} 个文件")
            return file_list
        elif include_dirs:
            logger.info(f"获取目录列表完成，共 {len(dir_list)} 个目录")
            return dir_list
        else:
            logger.error("至少需要包含文件或文件夹中的一种")
            raise ValueError("至少需要包含文件或文件夹中的一种")

    @staticmethod
    def change_owner(src: str, uid: int, gid: int, loop: bool = False) -> None:
        """
        更改指定文件或目录的所有者（UID）和所属组（GID）。

        :param src: 要更改所有权的文件或目录路径
        :type src: str
        :param uid: 新的所有者用户 ID
        :type uid: int
        :param gid: 新的所属组 ID
        :type gid: int
        :param loop: 是否递归处理子文件和子目录，默认值为 False
        :type loop: bool
        
        :raises OSError: 如果在 Windows 系统上调用此方法
        :raises FileNotFoundError: 如果指定的文件或目录不存在
        :raises PermissionError: 如果没有足够的权限更改所有权
        
        注意事项：
        - 此方法仅在 Linux/macOS 系统上有效，Windows 系统不支持
        - 递归处理时会忽略符号链接，避免不可预期的后果
        - 需要 root 权限或相应的文件系统权限
        
        示例用法：
        >>> FileUtils.change_owner('/path/to/file.txt', 1000, 1000)
        >>> FileUtils.change_owner('/path/to/dir', 1000, 1000, loop=True)
        """
        logger.info(f"开始更改文件/目录所有权: {src}, UID: {uid}, GID: {gid}, 递归: {loop}")
        if platform.system().lower() == 'windows':
            logger.error('Windows 系统无法设置文件或目录的所有者')
            raise OSError('Windows 系统无法设置文件或目录的所有者')
        
        src_path = Path(src)
        if not src_path.exists():
            logger.error(f"文件或目录不存在: {src}")
            raise FileNotFoundError(f"文件或目录不存在: {src}")
            
        try:
            if src_path.is_file():
                os.chown(src, uid, gid)
                logger.info(f"文件所有权更改成功: {src}")
            elif src_path.is_dir() and loop:
                for dirpath, dirnames, filenames in os.walk(src):
                    # 处理子目录
                    for dirname in dirnames:
                        filepath = os.path.join(dirpath, dirname)
                        if os.path.islink(filepath):  # 如果是符号链接，则跳过
                            continue
                        os.chown(filepath, uid, gid)
                    
                    # 处理文件
                    for filename in filenames:
                        filepath = os.path.join(dirpath, filename)
                        if os.path.islink(filepath):  # 如果是符号链接，则跳过
                            continue
                        os.chown(filepath, uid, gid)
                logger.info(f"目录及其子内容所有权更改成功: {src}")
        except PermissionError as e:
            logger.error(f"更改所有权失败: {src}, 错误: {e}")
            raise
        except OSError as e:
            logger.error(f"更改所有权失败: {src}, 错误: {e}")
            raise

    @staticmethod
    def rename_files(file_lists: List[str], file_prefix: str = "", file_suffix: int = 1) -> None:
        """
        批量重命名文件。

        :param file_lists: 要重命名的文件列表，即包含多个文件路径的字符串列表
        :type file_lists: List[str]
        :param file_prefix: 新文件名的前缀，默认为空字符串
        :type file_prefix: str
        :param file_suffix: 新文件名的起始序号，必须为正整数，默认为1
        :type file_suffix: int
        :return: None
        
        :raises ValueError: 如果 file_suffix 不是正整数
        :raises FileNotFoundError: 如果列表中的文件不存在
        :raises OSError: 如果重命名操作失败
        
        示例用法：
        >>> file_list = ["file1.txt", "file2.txt", "file3.txt"]
        >>> FileUtils.rename_files(file_list, "new_", 10)
        # 结果：new_010.txt, new_011.txt, new_012.txt
        """
        logger.info(f"开始批量重命名文件，共 {len(file_lists)} 个文件")
        if not isinstance(file_suffix, int) or file_suffix <= 0:
            logger.error(f"file_suffix 必须是正整数，当前值: {file_suffix}")
            raise ValueError("file_suffix must be a positive integer")

        original_files = []  # 保存原始文件路径和新文件名的映射

        try:
            for i, file_path in enumerate(file_lists):
                # 检查文件是否存在
                if not os.path.exists(file_path):
                    logger.error(f"文件不存在: {file_path}")
                    raise FileNotFoundError(f"文件不存在: {file_path}")
                    
                # 获取文件扩展名
                _, file_ext = os.path.splitext(file_path)
                # 构造新文件名
                new_name = f"{file_prefix}{file_suffix + i:03d}{file_ext}"
                # 获取文件所在目录
                dir_path = os.path.dirname(file_path)
                # 构造完整的新文件路径
                new_path = os.path.join(dir_path, new_name) if dir_path else new_name
                
                original_files.append((file_path, new_path))

            # 执行重命名操作
            for old_path, new_path in original_files:
                os.rename(old_path, new_path)
                logger.info(f"文件重命名成功: {old_path} -> {new_path}")
                
        except Exception as e:
            # 回滚所有已完成的重命名操作
            for old_path, new_path in original_files:
                if os.path.exists(new_path):
                    try:
                        os.rename(new_path, old_path)
                        logger.info(f"文件重命名回滚: {new_path} -> {old_path}")
                    except Exception:
                        pass  # 忽略回滚时的错误
            logger.error(f"批量重命名失败: {e}")
            raise OSError(f"批量重命名失败: {e}") from e


    @staticmethod
    def rename_file(old_path: str, new_path: str) -> None:
        """
        重命名单个文件。

        :param old_path: 原文件路径
        :type old_path: str
        :param new_path: 新文件路径
        :type new_path: str
        
        :raises FileNotFoundError: 如果原文件不存在
        :raises FileExistsError: 如果新路径的文件已存在
        :raises OSError: 如果重命名操作失败
        """
        logger.info(f"开始重命名文件: {old_path} -> {new_path}")
        old_path_obj = Path(old_path)
        new_path_obj = Path(new_path)
        
        if not old_path_obj.exists():
            logger.error(f"原文件不存在: {old_path}")
            raise FileNotFoundError(f"原文件不存在: {old_path}")
            
        if new_path_obj.exists():
            logger.error(f"新文件已存在: {new_path}")
            raise FileExistsError(f"新文件已存在: {new_path}")
            
        try:
            old_path_obj.rename(new_path_obj)
            logger.info(f"文件重命名成功: {old_path} -> {new_path}")
        except OSError as e:
            logger.error(f"重命名失败: {e}")
            raise OSError(f"重命名失败: {e}") from e

    @staticmethod
    def compress_file(source_path: str, target_path: str, compress_type: str = "gz") -> None:
        """
        将指定文件进行压缩。

        :param source_path: 要压缩的文件路径
        :type source_path: str
        :param target_path: 压缩文件保存路径
        :type target_path: str
        :param compress_type: 压缩类型，支持 gz, bz2, xz, zip, 7z
        :type compress_type: str
        
        :raises FileNotFoundError: 如果源文件不存在
        :raises ValueError: 如果压缩类型不受支持
        :raises OSError: 如果压缩操作失败
        """
        logger.info(f"开始压缩文件: {source_path} -> {target_path}, 压缩类型: {compress_type}")
        source_path_obj = Path(source_path)
        if not source_path_obj.exists():
            logger.error(f"源文件不存在: {source_path}")
            raise FileNotFoundError(f"源文件不存在: {source_path}")
            
        compress_types = get_compress_types()
        compress_func, mode = compress_types.get(compress_type.lower(), (None, None))
        
        if compress_func is None:
            supported_types = ', '.join(compress_types.keys())
            logger.error(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
            raise ValueError(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
            
        try:
            if compress_type.lower() == "zip":
                # ZipFile 需要使用 writestr 方法
                with zipfile.ZipFile(target_path, 'w') as f_out:
                    with open(source_path, 'rb') as f_in:
                        f_out.writestr(source_path_obj.name, f_in.read())
            elif compress_type.lower() == "7z":
                # py7zr 需要使用 write 方法
                with py7zr.SevenZipFile(target_path, 'w') as f_out:
                    f_out.write(source_path, source_path_obj.name)
            elif compress_type.lower() in ["gz", "bz2", "xz"]:
                # 对于 gz, bz2, xz 格式，需要先创建 tar 文件
                with tarfile.open(target_path, f'w:{compress_type}') as tar:
                    tar.add(source_path, arcname=source_path_obj.name)
            else:
                # 其他压缩格式
                with open(source_path, 'rb') as f_in, compress_func(target_path, mode) as f_out:
                    shutil.copyfileobj(f_in, f_out)
            logger.info(f"文件压缩成功: {target_path}")
        except OSError as e:
            logger.error(f"压缩文件失败: {source_path} -> {target_path}, 错误: {e}")
            raise

    @staticmethod
    def extract_file(file_path: str, extract_path: str, compress_type: str = None) -> None:
        """
        将压缩文件解压到指定目录。

        :param file_path: 压缩文件路径
        :type file_path: str
        :param extract_path: 解压缩目标目录
        :type extract_path: str
        :param compress_type: 压缩文件类型，如果为 None 则自动检测
        :type compress_type: str
        
        :raises FileNotFoundError: 如果压缩文件不存在
        :raises ValueError: 如果压缩类型不受支持
        :raises OSError: 如果解压操作失败
        """
        logger.info(f"开始解压文件: {file_path} -> {extract_path}")
        file_path_obj = Path(file_path)
        extract_path_obj = Path(extract_path)
        
        # 检查压缩文件是否存在
        if not file_path_obj.exists():
            logger.error(f"压缩文件不存在: {file_path}")
            raise FileNotFoundError(f"压缩文件不存在: {file_path}")
            
        # 创建目标目录
        extract_path_obj.mkdir(parents=True, exist_ok=True)
        logger.info(f"创建解压目标目录: {extract_path}")
        
        # 如果未指定压缩类型，尝试从文件名中推断
        if not compress_type:
            suffix = file_path_obj.suffix.lower()
            if suffix == '.gz' or suffix == '.tgz':
                compress_type = 'gz'
            elif suffix == '.bz2':
                compress_type = 'bz2'
            elif suffix == '.xz':
                compress_type = 'xz'
            elif suffix == '.zip':
                compress_type = 'zip'
            elif suffix == '.7z':
                compress_type = '7z'
            else:
                logger.error(f"无法从文件名推断压缩类型: {file_path}")
                raise ValueError(f"无法从文件名推断压缩类型: {file_path}")
        
        compress_type = compress_type.lower()
        compression_formats = get_compression_formats()
        compression_format = compression_formats.get(compress_type)
        
        try:
            if compression_format is None:
                if compress_type == "zip":
                    with zipfile.ZipFile(file_path) as zfile:
                        zfile.extractall(extract_path)  # 对于 zip 文件，使用 extractall() 方法进行解压
                        logger.info(f"ZIP文件解压成功: {file_path} -> {extract_path}")
                elif compress_type == "7z":
                    with py7zr.SevenZipFile(file_path, mode='r') as sfile:
                        sfile.extractall(path=extract_path)  # 对于 7z 文件，使用 extractall() 方法进行解压
                        logger.info(f"7z文件解压成功: {file_path} -> {extract_path}")
                else:
                    supported_types = ', '.join(compression_formats.keys())
                    logger.error(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
                    raise ValueError(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
            else:
                try:
                    with tarfile.open(file_path, compression_format) as tar:
                        def safe_member_filter(member, path):
                            # 使用 `isreg` 来检查是否是常规文件，如果不是常规文件则返回 None
                            return member if member.isreg() else None
                        
                        # 使用 `filter` 参数来确保安全提取
                        tar.extractall(path=extract_path, filter=safe_member_filter)
                        logger.info(f"压缩文件解压成功: {file_path} -> {extract_path}")
                except (tarfile.ReadError, OSError) as e:
                    logger.error(f"解压文件失败: {file_path} -> {extract_path}, 错误: {e}")
                    raise ValueError(f"解压失败: {str(e)}")
        except OSError as e:
            logger.error(f"解压文件失败: {file_path} -> {extract_path}, 错误: {e}")
            raise

    @staticmethod
    def get_file_hash(file_path: str, algorithm: str = 'md5') -> str:
        """
        计算文件的哈希值。

        :param file_path: 文件路径
        :type file_path: str
        :param algorithm: 哈希算法，支持 'md5', 'sha1', 'sha256'
        :type algorithm: str
        :return: 文件的哈希值
        :rtype: str
        
        :raises FileNotFoundError: 如果文件不存在
        :raises OSError: 如果读取文件失败
        :raises ValueError: 如果算法不支持
        
        示例:
        >>> FileUtils.get_file_hash('example.txt')
        'd41d8cd98f00b204e9800998ecf8427e'
        """
        logger.info(f"开始计算文件哈希: {file_path}, 算法: {algorithm}")
        file_path_obj = Path(file_path)
        
        if not file_path_obj.exists():
            logger.error(f"文件不存在: {file_path}")
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        if algorithm not in ['md5', 'sha1', 'sha256']:
            logger.error(f"不支持的哈希算法: {algorithm}")
            raise ValueError("不支持的哈希算法，支持的算法: md5, sha1, sha256")
        
        try:
            hash_obj = getattr(hashlib, algorithm)()
            with open(file_path, 'rb') as f:
                while chunk := f.read(4096):
                    hash_obj.update(chunk)
            hash_value = hash_obj.hexdigest()
            logger.info(f"文件哈希计算成功: {hash_value}")
            return hash_value
        except OSError as e:
            logger.error(f"读取文件失败: {file_path}, 错误: {e}")
            raise

    @staticmethod
    def format_file_size(size: int) -> str:
        """
        将文件大小格式化为人类可读的形式。

        :param size: 文件大小（字节）
        :type size: int
        :return: 格式化后的文件大小
        :rtype: str
        
        示例:
        >>> FileUtils.format_file_size(1024)
        '1.0 KB'
        >>> FileUtils.format_file_size(1048576)
        '1.0 MB'
        """
        if not isinstance(size, (int, float)):
            return str(size)
        
        units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
        unit_index = 0
        current_size = float(size)
        
        while current_size >= 1024 and unit_index < len(units) - 1:
            current_size /= 1024
            unit_index += 1
        
        if unit_index == 0:
            return f"{int(current_size)} {units[unit_index]}"
        else:
            return f"{current_size:.1f} {units[unit_index]}"

    @staticmethod
    def get_file_type(file_path: str) -> str:
        """
        获取文件类型。

        :param file_path: 文件路径
        :type file_path: str
        :return: 文件类型
        :rtype: str
        
        :raises FileNotFoundError: 如果文件不存在
        
        示例:
        >>> FileUtils.get_file_type('example.txt')
        'text'
        >>> FileUtils.get_file_type('example.jpg')
        'image'
        """
        logger.info(f"开始获取文件类型: {file_path}")
        file_path_obj = Path(file_path)
        
        if not file_path_obj.exists():
            logger.error(f"文件不存在: {file_path}")
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        # 根据文件扩展名判断文件类型
        extension = file_path_obj.suffix.lower()
        
        # 文本文件
        if extension in ['.txt', '.md', '.rst', '.py', '.java', '.cpp', '.h', '.js', '.css', '.html']:
            return 'text'
        # 图片文件
        elif extension in ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp']:
            return 'image'
        # 音频文件
        elif extension in ['.mp3', '.wav', '.flac', '.ogg', '.m4a']:
            return 'audio'
        # 视频文件
        elif extension in ['.mp4', '.avi', '.mov', '.wmv', '.flv']:
            return 'video'
        # 压缩文件
        elif extension in ['.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz']:
            return 'compressed'
        # 文档文件
        elif extension in ['.doc', '.docx', '.pdf', '.xls', '.xlsx', '.ppt', '.pptx']:
            return 'document'
        # 可执行文件
        elif extension in ['.exe', '.bat', '.sh']:
            return 'executable'
        # 其他文件
        else:
            return 'other'

    @staticmethod
    def safe_delete(file_path: str) -> bool:
        """
        安全删除文件。

        :param file_path: 文件路径
        :type file_path: str
        :return: 删除是否成功
        :rtype: bool
        
        示例:
        >>> FileUtils.safe_delete('example.txt')
        True
        """
        logger.info(f"开始安全删除文件: {file_path}")
        file_path_obj = Path(file_path)
        
        if not file_path_obj.exists():
            logger.warning(f"文件不存在: {file_path}")
            return False
        
        try:
            file_path_obj.unlink()
            logger.info(f"文件删除成功: {file_path}")
            return True
        except OSError as e:
            logger.error(f"删除文件失败: {file_path}, 错误: {e}")
            return False

    @staticmethod
    def create_temp_file(content: str = '', suffix: str = '') -> str:
        """
        创建临时文件。

        :param content: 文件内容
        :type content: str
        :param suffix: 文件后缀
        :type suffix: str
        :return: 临时文件路径
        :rtype: str
        
        示例:
        >>> FileUtils.create_temp_file('test content', '.txt')
        '/tmp/tmpabc123.txt'
        """
        logger.info("开始创建临时文件")
        
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix=suffix, delete=False) as f:
                if content:
                    f.write(content)
                temp_path = f.name
            logger.info(f"临时文件创建成功: {temp_path}")
            return temp_path
        except OSError as e:
            logger.error(f"创建临时文件失败: {e}")
            raise

    @staticmethod
    def detect_file_encoding(file_path: str) -> str:
        """
        检测文件的编码格式。

        :param file_path: 文件路径
        :type file_path: str
        :return: 文件编码
        :rtype: str
        
        :raises FileNotFoundError: 如果文件不存在
        :raises OSError: 如果读取文件失败
        
        示例:
        >>> FileUtils.detect_file_encoding('example.txt')
        'utf-8'
        """
        logger.info(f"开始检测文件编码: {file_path}")
        file_path_obj = Path(file_path)
        
        if not file_path_obj.exists():
            logger.error(f"文件不存在: {file_path}")
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        try:
            import chardet
            with open(file_path, 'rb') as f:
                raw_data = f.read(1024)
            result = chardet.detect(raw_data)
            encoding = result['encoding'] or 'utf-8'
            logger.info(f"文件编码检测成功: {encoding}")
            return encoding
        except OSError as e:
            logger.error(f"读取文件失败: {file_path}, 错误: {e}")
            raise

    @staticmethod
    def get_file_size(file_path: str) -> int:
        """
        获取文件大小（字节）。

        :param file_path: 文件路径
        :type file_path: str
        :return: 文件大小（字节）
        :rtype: int
        
        :raises FileNotFoundError: 如果文件不存在
        :raises OSError: 如果无法获取文件大小
        
        示例:
        >>> FileUtils.get_file_size('example.txt')
        1024
        """
        logger.info(f"开始获取文件大小: {file_path}")
        file_path_obj = Path(file_path)
        
        if not file_path_obj.exists():
            logger.error(f"文件不存在: {file_path}")
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        try:
            size = file_path_obj.stat().st_size
            logger.info(f"文件大小获取成功: {size} 字节")
            return size
        except OSError as e:
            logger.error(f"获取文件大小失败: {file_path}, 错误: {e}")
            raise

    @staticmethod
    def copy_file(src: str, dst: str) -> None:
        """
        复制单个文件。

        :param src: 源文件路径
        :type src: str
        :param dst: 目标文件路径
        :type dst: str
        
        :raises FileNotFoundError: 如果源文件不存在
        :raises OSError: 如果复制失败
        
        示例:
        >>> FileUtils.copy_file('source.txt', 'destination.txt')
        """
        logger.info(f"开始复制文件: {src} -> {dst}")
        src_path = Path(src)
        dst_path = Path(dst)
        
        if not src_path.exists():
            logger.error(f"源文件不存在: {src}")
            raise FileNotFoundError(f"源文件不存在: {src}")
        
        # 确保目标目录存在
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            shutil.copy2(src, dst)
            logger.info(f"文件复制成功: {src} -> {dst}")
        except OSError as e:
            logger.error(f"文件复制失败: {src} -> {dst}, 错误: {e}")
            raise

    @staticmethod
    def move_file(src: str, dst: str) -> None:
        """
        移动单个文件。

        :param src: 源文件路径
        :type src: str
        :param dst: 目标文件路径
        :type dst: str
        
        :raises FileNotFoundError: 如果源文件不存在
        :raises OSError: 如果移动失败
        
        示例:
        >>> FileUtils.move_file('source.txt', 'destination.txt')
        """
        logger.info(f"开始移动文件: {src} -> {dst}")
        src_path = Path(src)
        dst_path = Path(dst)
        
        if not src_path.exists():
            logger.error(f"源文件不存在: {src}")
            raise FileNotFoundError(f"源文件不存在: {src}")
        
        # 确保目标目录存在
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            shutil.move(src, dst)
            logger.info(f"文件移动成功: {src} -> {dst}")
        except OSError as e:
            logger.error(f"文件移动失败: {src} -> {dst}, 错误: {e}")
            raise

    @staticmethod
    def get_directory_size(path: str) -> int:
        """
        获取目录大小（字节）。

        :param path: 目录路径
        :type path: str
        :return: 目录大小（字节）
        :rtype: int
        
        :raises FileNotFoundError: 如果目录不存在
        :raises OSError: 如果无法获取目录大小
        
        示例:
        >>> FileUtils.get_directory_size('path/to/dir')
        1048576
        """
        logger.info(f"开始获取目录大小: {path}")
        path_obj = Path(path)
        
        if not path_obj.exists():
            logger.error(f"目录不存在: {path}")
            raise FileNotFoundError(f"目录不存在: {path}")
        
        if not path_obj.is_dir():
            logger.error(f"路径不是目录: {path}")
            raise ValueError(f"路径不是目录: {path}")
        
        try:
            size = 0
            for file_path in path_obj.rglob('*'):
                if file_path.is_file():
                    size += file_path.stat().st_size
            logger.info(f"目录大小获取成功: {size} 字节")
            return size
        except OSError as e:
            logger.error(f"获取目录大小失败: {path}, 错误: {e}")
            raise

    @staticmethod
    def find_files(path: str, pattern: str = '*') -> List[str]:
        """
        查找符合模式的文件。

        :param path: 搜索目录
        :type path: str
        :param pattern: 文件模式，支持通配符
        :type pattern: str
        :return: 符合模式的文件路径列表
        :rtype: List[str]
        
        :raises FileNotFoundError: 如果目录不存在
        
        示例:
        >>> FileUtils.find_files('path/to/dir', '*.txt')
        ['path/to/dir/file1.txt', 'path/to/dir/file2.txt']
        """
        logger.info(f"开始查找文件: {path}, 模式: {pattern}")
        path_obj = Path(path)
        
        if not path_obj.exists():
            logger.error(f"目录不存在: {path}")
            raise FileNotFoundError(f"目录不存在: {path}")
        
        try:
            files = [str(file_path) for file_path in path_obj.rglob(pattern) if file_path.is_file()]
            logger.info(f"文件查找完成，共找到 {len(files)} 个文件")
            return files
        except OSError as e:
            logger.error(f"文件查找失败: {path}, 错误: {e}")
            return []

    @staticmethod
    def clean_directory(path: str, keep_files: List[str] = None) -> None:
        """
        清理目录，删除所有文件和子目录。

        :param path: 目录路径
        :type path: str
        :param keep_files: 要保留的文件列表
        :type keep_files: List[str]
        
        :raises FileNotFoundError: 如果目录不存在
        :raises OSError: 如果清理失败
        
        示例:
        >>> FileUtils.clean_directory('path/to/dir', ['important.txt'])
        """
        logger.info(f"开始清理目录: {path}")
        path_obj = Path(path)
        
        if not path_obj.exists():
            logger.error(f"目录不存在: {path}")
            raise FileNotFoundError(f"目录不存在: {path}")
        
        if not path_obj.is_dir():
            logger.error(f"路径不是目录: {path}")
            raise ValueError(f"路径不是目录: {path}")
        
        keep_files = keep_files or []
        
        try:
            for item in path_obj.iterdir():
                if item.name in keep_files:
                    logger.info(f"保留文件: {item.name}")
                    continue
                
                if item.is_file():
                    item.unlink()
                    logger.info(f"删除文件: {item.name}")
                elif item.is_dir():
                    shutil.rmtree(item)
                    logger.info(f"删除目录: {item.name}")
            logger.info(f"目录清理成功: {path}")
        except OSError as e:
            logger.error(f"目录清理失败: {path}, 错误: {e}")
            raise

    @staticmethod
    def backup_file(file_path: str, suffix: str = None) -> str:
        """
        备份文件。

        :param file_path: 文件路径
        :type file_path: str
        :param suffix: 备份文件后缀，默认为时间戳
        :type suffix: str
        :return: 备份文件路径
        :rtype: str
        
        :raises FileNotFoundError: 如果文件不存在
        :raises OSError: 如果备份失败
        
        示例:
        >>> FileUtils.backup_file('example.txt')
        'example.txt.bak_20231225_103045'
        """
        logger.info(f"开始备份文件: {file_path}")
        file_path_obj = Path(file_path)
        
        if not file_path_obj.exists():
            logger.error(f"文件不存在: {file_path}")
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        try:
            if suffix is None:
                suffix = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            
            backup_path = f"{file_path}.bak_{suffix}"
            shutil.copy2(file_path, backup_path)
            logger.info(f"文件备份成功: {backup_path}")
            return backup_path
        except OSError as e:
            logger.error(f"文件备份失败: {file_path}, 错误: {e}")
            raise

    @staticmethod
    def touch_file(file_path: str) -> None:
        """
        创建空文件或更新文件时间戳。

        :param file_path: 文件路径
        :type file_path: str
        
        :raises OSError: 如果操作失败
        
        示例:
        >>> FileUtils.touch_file('new_file.txt')
        """
        logger.info(f"开始创建/更新文件: {file_path}")
        file_path_obj = Path(file_path)
        
        # 确保目录存在
        file_path_obj.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            file_path_obj.touch(exist_ok=True)
            logger.info(f"文件创建/更新成功: {file_path}")
        except OSError as e:
            logger.error(f"文件创建/更新失败: {file_path}, 错误: {e}")
            raise

    @staticmethod
    def is_empty_file(file_path: str) -> bool:
        """
        检查文件是否为空。

        :param file_path: 文件路径
        :type file_path: str
        :return: 文件是否为空
        :rtype: bool
        
        :raises FileNotFoundError: 如果文件不存在
        
        示例:
        >>> FileUtils.is_empty_file('empty.txt')
        True
        >>> FileUtils.is_empty_file('non_empty.txt')
        False
        """
        logger.info(f"开始检查文件是否为空: {file_path}")
        file_path_obj = Path(file_path)
        
        if not file_path_obj.exists():
            logger.error(f"文件不存在: {file_path}")
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        if not file_path_obj.is_file():
            logger.error(f"路径不是文件: {file_path}")
            raise ValueError(f"路径不是文件: {file_path}")
        
        try:
            is_empty = file_path_obj.stat().st_size == 0
            logger.info(f"文件检查完成，是否为空: {is_empty}")
            return is_empty
        except OSError as e:
            logger.error(f"文件检查失败: {file_path}, 错误: {e}")
            raise

#############
####  压缩包方法       
#############

def get_compress_types():
    """
    返回支持的压缩类型与相应打开文件的函数和模式。

    :return: 压缩类型与函数、模式的映射字典。
    """
    return {
        "gz": (gzip.open, 'wb'),    # .gz 文件使用 gzip.open 打开，并以写入二进制模式
        "bz2": (bz2.open, 'wb'),    # .bz2 文件使用 bz2.open 打开，并以写入二进制模式
        "xz": (lzma.open, 'wb'),    # .xz 文件使用 lzma.open 打开，并以写入二进制模式
        "zip": (zipfile.ZipFile, 'w'),  # .zip 文件使用 ZipFile 打开，并以写入模式
        "7z": (py7zr.SevenZipFile, 'w')  # .7z 文件使用 SevenZipFile 打开，并以写入模式
    }

def get_compression_formats():
    """
    返回支持的压缩格式对应的 tarfile 模式。

    :return: 压缩类型与 tarfile 模式的映射字典。
    """
    return {
        "gz": "r:gz",   # .gz 文件采用 "r:gz" 解压格式
        "tgz": "r:gz",  # .tgz 文件也采用 "r:gz" 解压格式
        "bz2": "r:bz2", # .bz2 文件采用 "r:bz2" 解压格式
        "xz": "r:xz",   # .xz 文件采用 "r:xz" 解压格式
        "zip": None,     # .zip 文件不需要指定 tarfile 格式（使用 zipfile 模块）
        "7z": None       # .7z 文件不需要指定 tarfile 格式（使用 py7zr 模块）
    }

class ZipFilesUtils:
    """
    压缩与解压缩工具类
    """
    @staticmethod
    def compress_data(data=None, compress_type: str = "gz", stream: bool = False, chunk_size: int = 4096, file_path: str = None) -> bytes:
        """
        压缩数据，支持内存压缩和流式压缩。

        :param data: 要压缩的数据，如果指定了 file_path，则此参数会被忽略
        :type data: bytes or None
        :param compress_type: 压缩类型，支持 gz, bz2, xz, zip, 7z
        :type compress_type: str
        :param stream: 是否使用流式处理，默认为 False
        :type stream: bool
        :param chunk_size: 流式处理时的块大小，默认为 4096
        :type chunk_size: int
        :param file_path: 要压缩的文件路径，如果指定，则从文件读取数据
        :type file_path: str or None
        :return: 压缩后的数据
        :rtype: bytes
        
        :raises ValueError: 如果压缩类型不受支持
        :raises FileNotFoundError: 如果指定的文件不存在
        """
        logger.info(f"开始压缩数据，压缩类型: {compress_type}, 流式处理: {stream}")
        
        compress_types = get_compress_types()
        compress_func, mode = compress_types.get(compress_type.lower(), (None, None))
        
        if compress_func is None:
            supported_types = ', '.join(compress_types.keys())
            logger.error(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
            raise ValueError(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
        
        try:
            compressed_data = io.BytesIO()
            
            if compress_type.lower() == "zip":
                with zipfile.ZipFile(compressed_data, 'w') as f_out:
                    if file_path:
                        # 从文件读取数据
                        logger.info(f"从文件读取数据进行压缩: {file_path}")
                        file_name = Path(file_path).name
                        with open(file_path, 'rb') as f_in:
                            if stream:
                                # 流式处理
                                while chunk := f_in.read(chunk_size):
                                    # 对于 zip，需要先读取所有数据
                                    # 这里使用临时缓冲区
                                    buffer = io.BytesIO()
                                    buffer.write(chunk)
                                    while chunk := f_in.read(chunk_size):
                                        buffer.write(chunk)
                                    buffer.seek(0)
                                    f_out.writestr(file_name, buffer.getvalue())
                            else:
                                # 一次性读取
                                f_out.writestr(file_name, f_in.read())
                    else:
                        # 从内存数据读取
                        if not isinstance(data, bytes):
                            raise ValueError("data 必须是 bytes 类型")
                        f_out.writestr('data', data)
            elif compress_type.lower() == "7z":
                with py7zr.SevenZipFile(compressed_data, 'w') as f_out:
                    if file_path:
                        # 从文件读取数据
                        logger.info(f"从文件读取数据进行压缩: {file_path}")
                        f_out.write(file_path, Path(file_path).name)
                    else:
                        # 从内存数据读取
                        if not isinstance(data, bytes):
                            raise ValueError("data 必须是 bytes 类型")
                        f_out.writebytes('data', data)
            elif compress_type.lower() in ["gz", "bz2", "xz"]:
                with compress_func(compressed_data, mode) as f_out:
                    if file_path:
                        # 从文件读取数据
                        logger.info(f"从文件读取数据进行压缩: {file_path}")
                        with open(file_path, 'rb') as f_in:
                            if stream:
                                # 流式处理
                                while chunk := f_in.read(chunk_size):
                                    f_out.write(chunk)
                            else:
                                # 一次性读取
                                f_out.write(f_in.read())
                    else:
                        # 从内存数据读取
                        if not isinstance(data, bytes):
                            raise ValueError("data 必须是 bytes 类型")
                        if stream:
                            # 流式处理
                            for i in range(0, len(data), chunk_size):
                                chunk = data[i:i+chunk_size]
                                f_out.write(chunk)
                        else:
                            # 一次性写入
                            f_out.write(data)
            else:
                # 其他压缩格式
                with compress_func(compressed_data, mode) as f_out:
                    if file_path:
                        # 从文件读取数据
                        logger.info(f"从文件读取数据进行压缩: {file_path}")
                        with open(file_path, 'rb') as f_in:
                            if stream:
                                # 流式处理
                                while chunk := f_in.read(chunk_size):
                                    f_out.write(chunk)
                            else:
                                # 一次性读取
                                f_out.write(f_in.read())
                    else:
                        # 从内存数据读取
                        if not isinstance(data, bytes):
                            raise ValueError("data 必须是 bytes 类型")
                        if stream:
                            # 流式处理
                            for i in range(0, len(data), chunk_size):
                                chunk = data[i:i+chunk_size]
                                f_out.write(chunk)
                        else:
                            # 一次性写入
                            f_out.write(data)
            
            compressed_data.seek(0)
            logger.info(f"压缩成功: {compress_type}")
            return compressed_data.getvalue()
        except Exception as e:
            logger.error(f"压缩失败: {e}")
            raise

    @staticmethod
    def extract_data(data=None, compress_type: str = "gz", stream: bool = False, chunk_size: int = 4096, file_path: str = None) -> bytes:
        """
        解压数据，支持内存解压和流式解压。

        :param data: 要解压的数据，如果指定了 file_path，则此参数会被忽略
        :type data: bytes or None
        :param compress_type: 压缩类型，支持 gz, bz2, xz, zip, 7z
        :type compress_type: str
        :param stream: 是否使用流式处理，默认为 False
        :type stream: bool
        :param chunk_size: 流式处理时的块大小，默认为 4096
        :type chunk_size: int
        :param file_path: 要解压的文件路径，如果指定，则从文件读取数据
        :type file_path: str or None
        :return: 解压后的数据
        :rtype: bytes
        
        :raises ValueError: 如果压缩类型不受支持
        :raises FileNotFoundError: 如果指定的文件不存在
        """
        logger.info(f"开始解压数据，压缩类型: {compress_type}, 流式处理: {stream}")
        
        try:
            if compress_type.lower() == "zip":
                # 解压 ZIP 文件
                if file_path:
                    logger.info(f"从文件读取数据进行解压: {file_path}")
                    with zipfile.ZipFile(file_path) as zfile:
                        # 假设只有一个文件
                        for name in zfile.namelist():
                            with zfile.open(name) as f:
                                if stream:
                                    # 流式处理
                                    decompressed_data = b''
                                    while chunk := f.read(chunk_size):
                                        decompressed_data += chunk
                                    logger.info("ZIP 解压成功（流式处理）")
                                    return decompressed_data
                                else:
                                    # 一次性读取
                                    decompressed_data = f.read()
                                    logger.info("ZIP 解压成功")
                                    return decompressed_data
                else:
                    if not isinstance(data, bytes):
                        raise ValueError("data 必须是 bytes 类型")
                    compressed_data = io.BytesIO(data)
                    with zipfile.ZipFile(compressed_data) as zfile:
                        # 假设只有一个文件
                        for name in zfile.namelist():
                            with zfile.open(name) as f:
                                if stream:
                                    # 流式处理
                                    decompressed_data = b''
                                    while chunk := f.read(chunk_size):
                                        decompressed_data += chunk
                                    logger.info("ZIP 解压成功（流式处理）")
                                    return decompressed_data
                                else:
                                    # 一次性读取
                                    decompressed_data = f.read()
                                    logger.info("ZIP 解压成功")
                                    return decompressed_data
            elif compress_type.lower() == "7z":
                # 解压 7z 文件
                if file_path:
                    logger.info(f"从文件读取数据进行解压: {file_path}")
                    with py7zr.SevenZipFile(file_path, mode='r') as sfile:
                        # 假设只有一个文件
                        for name in sfile.getnames():
                            with sfile.open(name) as f:
                                if stream:
                                    # 流式处理
                                    decompressed_data = b''
                                    while chunk := f.read(chunk_size):
                                        decompressed_data += chunk
                                    logger.info("7z 解压成功（流式处理）")
                                    return decompressed_data
                                else:
                                    # 一次性读取
                                    decompressed_data = f.read()
                                    logger.info("7z 解压成功")
                                    return decompressed_data
                else:
                    if not isinstance(data, bytes):
                        raise ValueError("data 必须是 bytes 类型")
                    compressed_data = io.BytesIO(data)
                    with py7zr.SevenZipFile(compressed_data, mode='r') as sfile:
                        # 假设只有一个文件
                        for name in sfile.getnames():
                            with sfile.open(name) as f:
                                if stream:
                                    # 流式处理
                                    decompressed_data = b''
                                    while chunk := f.read(chunk_size):
                                        decompressed_data += chunk
                                    logger.info("7z 解压成功（流式处理）")
                                    return decompressed_data
                                else:
                                    # 一次性读取
                                    decompressed_data = f.read()
                                    logger.info("7z 解压成功")
                                    return decompressed_data
            elif compress_type.lower() in ["gz", "bz2", "xz"]:
                # 解压 gz, bz2, xz 文件
                compress_types = get_compress_types()
                compress_func, _ = compress_types.get(compress_type.lower(), (None, None))
                
                if compress_func:
                    try:
                        if file_path:
                            logger.info(f"从文件读取数据进行解压: {file_path}")
                            # 首先尝试直接解压（非 tar 格式）
                            with compress_func(file_path, 'rb') as f_in:
                                if stream:
                                    # 流式处理
                                    decompressed_data = b''
                                    while chunk := f_in.read(chunk_size):
                                        decompressed_data += chunk
                                    logger.info(f"{compress_type} 解压成功（直接解压，流式处理）")
                                    return decompressed_data
                                else:
                                    # 一次性读取
                                    decompressed_data = f_in.read()
                                    logger.info(f"{compress_type} 解压成功（直接解压）")
                                    return decompressed_data
                        else:
                            if not isinstance(data, bytes):
                                raise ValueError("data 必须是 bytes 类型")
                            compressed_data = io.BytesIO(data)
                            # 首先尝试直接解压（非 tar 格式）
                            compressed_data.seek(0)
                            with compress_func(compressed_data, 'rb') as f_in:
                                if stream:
                                    # 流式处理
                                    decompressed_data = b''
                                    while chunk := f_in.read(chunk_size):
                                        decompressed_data += chunk
                                    logger.info(f"{compress_type} 解压成功（直接解压，流式处理）")
                                    return decompressed_data
                                else:
                                    # 一次性读取
                                    decompressed_data = f_in.read()
                                    logger.info(f"{compress_type} 解压成功（直接解压）")
                                    return decompressed_data
                    except Exception as e:
                        # 如果直接解压失败，尝试作为 tar 压缩包解压
                        logger.debug(f"直接解压失败，尝试作为 tar 压缩包解压: {e}")
                        compression_formats = get_compression_formats()
                        compression_format = compression_formats.get(compress_type.lower())
                        
                        if compression_format:
                            try:
                                if file_path:
                                    with tarfile.open(file_path, compression_format) as tar:
                                        # 假设只有一个文件
                                        for member in tar.getmembers():
                                            if member.isreg():
                                                with tar.extractfile(member) as f:
                                                    if stream:
                                                        # 流式处理
                                                        decompressed_data = b''
                                                        while chunk := f.read(chunk_size):
                                                            decompressed_data += chunk
                                                        logger.info(f"{compress_type} 解压成功（tar 格式，流式处理）")
                                                        return decompressed_data
                                                    else:
                                                        # 一次性读取
                                                        decompressed_data = f.read()
                                                        logger.info(f"{compress_type} 解压成功（tar 格式）")
                                                        return decompressed_data
                                else:
                                    if not isinstance(data, bytes):
                                        raise ValueError("data 必须是 bytes 类型")
                                    compressed_data = io.BytesIO(data)
                                    compressed_data.seek(0)
                                    with tarfile.open(fileobj=compressed_data, mode=compression_format) as tar:
                                        # 假设只有一个文件
                                        for member in tar.getmembers():
                                            if member.isreg():
                                                with tar.extractfile(member) as f:
                                                    if stream:
                                                        # 流式处理
                                                        decompressed_data = b''
                                                        while chunk := f.read(chunk_size):
                                                            decompressed_data += chunk
                                                        logger.info(f"{compress_type} 解压成功（tar 格式，流式处理）")
                                                        return decompressed_data
                                                    else:
                                                        # 一次性读取
                                                        decompressed_data = f.read()
                                                        logger.info(f"{compress_type} 解压成功（tar 格式）")
                                                        return decompressed_data
                            except Exception as tar_error:
                                logger.error(f"tar 格式解压失败: {tar_error}")
                                raise
            else:
                # 不支持的压缩类型
                supported_types = ', '.join(get_compress_types().keys())
                logger.error(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
                raise ValueError(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
        except Exception as e:
            logger.error(f"解压失败: {e}")
            raise

    @staticmethod
    def compress_directory(source_dir: str, target_path: str, compress_type: str = "zip") -> None:
        """
        压缩整个目录。

        :param source_dir: 要压缩的目录路径
        :type source_dir: str
        :param target_path: 压缩文件保存路径
        :type target_path: str
        :param compress_type: 压缩类型，支持 zip, 7z, gz, bz2, xz
        :type compress_type: str
        
        :raises FileNotFoundError: 如果源目录不存在
        :raises ValueError: 如果压缩类型不受支持
        :raises OSError: 如果压缩操作失败
        """
        logger.info(f"开始压缩目录: {source_dir} -> {target_path}, 压缩类型: {compress_type}")
        source_dir_obj = Path(source_dir)
        
        if not source_dir_obj.exists():
            logger.error(f"源目录不存在: {source_dir}")
            raise FileNotFoundError(f"源目录不存在: {source_dir}")
        
        if not source_dir_obj.is_dir():
            logger.error(f"路径不是目录: {source_dir}")
            raise ValueError(f"路径不是目录: {source_dir}")
        
        try:
            if compress_type.lower() == "zip":
                with zipfile.ZipFile(target_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                    for root, _, files in os.walk(source_dir):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, source_dir)
                            zf.write(file_path, arcname)
                logger.info(f"目录压缩成功 (ZIP): {target_path}")
            elif compress_type.lower() == "7z":
                with py7zr.SevenZipFile(target_path, 'w') as szf:
                    szf.writeall(source_dir, '')
                logger.info(f"目录压缩成功 (7z): {target_path}")
            elif compress_type.lower() in ["gz", "bz2", "xz"]:
                import tarfile
                with tarfile.open(target_path, f'w:{compress_type}') as tar:
                    tar.add(source_dir, arcname=source_dir_obj.name)
                logger.info(f"目录压缩成功 (tar.{compress_type}): {target_path}")
            else:
                supported_types = ', '.join(['zip', '7z', 'gz', 'bz2', 'xz'])
                logger.error(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
                raise ValueError(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
        except OSError as e:
            logger.error(f"压缩目录失败: {source_dir} -> {target_path}, 错误: {e}")
            raise

    @staticmethod
    def compress_file_to_file(source_path: str, target_path: str, compress_type: str = "gz", chunk_size: int = 4096) -> None:
        """
        直接从源文件压缩到目标文件，减少内存使用。

        :param source_path: 源文件路径
        :type source_path: str
        :param target_path: 目标压缩文件路径
        :type target_path: str
        :param compress_type: 压缩类型，支持 gz, bz2, xz, zip, 7z
        :type compress_type: str
        :param chunk_size: 流式处理时的块大小，默认为 4096
        :type chunk_size: int
        
        :raises FileNotFoundError: 如果源文件不存在
        :raises ValueError: 如果压缩类型不受支持
        :raises OSError: 如果压缩操作失败
        """
        logger.info(f"开始文件到文件压缩: {source_path} -> {target_path}, 压缩类型: {compress_type}")
        
        source_path_obj = Path(source_path)
        if not source_path_obj.exists():
            logger.error(f"源文件不存在: {source_path}")
            raise FileNotFoundError(f"源文件不存在: {source_path}")
        
        compress_types = get_compress_types()
        compress_func, mode = compress_types.get(compress_type.lower(), (None, None))
        
        if compress_func is None:
            supported_types = ', '.join(compress_types.keys())
            logger.error(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
            raise ValueError(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
        
        try:
            if compress_type.lower() == "zip":
                with zipfile.ZipFile(target_path, 'w') as f_out:
                    file_name = source_path_obj.name
                    f_out.write(source_path, file_name)
                logger.info(f"文件到文件 ZIP 压缩成功: {target_path}")
            elif compress_type.lower() == "7z":
                with py7zr.SevenZipFile(target_path, 'w') as f_out:
                    f_out.write(source_path, source_path_obj.name)
                logger.info(f"文件到文件 7z 压缩成功: {target_path}")
            elif compress_type.lower() in ["gz", "bz2", "xz"]:
                with compress_func(target_path, mode) as f_out:
                    with open(source_path, 'rb') as f_in:
                        while chunk := f_in.read(chunk_size):
                            f_out.write(chunk)
                logger.info(f"文件到文件 {compress_type} 压缩成功: {target_path}")
            else:
                supported_types = ', '.join(['zip', '7z', 'gz', 'bz2', 'xz'])
                logger.error(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
                raise ValueError(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
        except OSError as e:
            logger.error(f"文件到文件压缩失败: {source_path} -> {target_path}, 错误: {e}")
            raise

    @staticmethod
    def extract_file_to_file(source_path: str, target_path: str, compress_type: str = None, chunk_size: int = 4096) -> None:
        """
        直接从压缩文件解压到目标文件，减少内存使用。

        :param source_path: 压缩文件路径
        :type source_path: str
        :param target_path: 目标文件路径
        :type target_path: str
        :param compress_type: 压缩文件类型，如果为 None 则自动检测
        :type compress_type: str
        :param chunk_size: 流式处理时的块大小，默认为 4096
        :type chunk_size: int
        
        :raises FileNotFoundError: 如果压缩文件不存在
        :raises ValueError: 如果压缩类型不受支持
        :raises OSError: 如果解压操作失败
        """
        logger.info(f"开始文件到文件解压: {source_path} -> {target_path}")
        
        source_path_obj = Path(source_path)
        if not source_path_obj.exists():
            logger.error(f"压缩文件不存在: {source_path}")
            raise FileNotFoundError(f"压缩文件不存在: {source_path}")
        
        # 确保目标目录存在
        target_path_obj = Path(target_path)
        target_path_obj.parent.mkdir(parents=True, exist_ok=True)
        
        # 如果未指定压缩类型，尝试从文件名中推断
        if not compress_type:
            suffix = source_path_obj.suffix.lower()
            if suffix == '.gz' or suffix == '.tgz':
                compress_type = 'gz'
            elif suffix == '.bz2':
                compress_type = 'bz2'
            elif suffix == '.xz':
                compress_type = 'xz'
            elif suffix == '.zip':
                compress_type = 'zip'
            elif suffix == '.7z':
                compress_type = '7z'
            else:
                logger.error(f"无法从文件名推断压缩类型: {source_path}")
                raise ValueError(f"无法从文件名推断压缩类型: {source_path}")
        
        compress_type = compress_type.lower()
        
        try:
            if compress_type == "zip":
                with zipfile.ZipFile(source_path) as zfile:
                    # 假设只有一个文件
                    for name in zfile.namelist():
                        with zfile.open(name) as f_in:
                            with open(target_path, 'wb') as f_out:
                                while chunk := f_in.read(chunk_size):
                                    f_out.write(chunk)
                logger.info(f"文件到文件 ZIP 解压成功: {target_path}")
            elif compress_type == "7z":
                with py7zr.SevenZipFile(source_path, mode='r') as sfile:
                    # 假设只有一个文件
                    for name in sfile.getnames():
                        with sfile.open(name) as f_in:
                            with open(target_path, 'wb') as f_out:
                                while chunk := f_in.read(chunk_size):
                                    f_out.write(chunk)
                logger.info(f"文件到文件 7z 解压成功: {target_path}")
            elif compress_type in ["gz", "bz2", "xz"]:
                compress_types = get_compress_types()
                compress_func, _ = compress_types.get(compress_type.lower(), (None, None))
                
                if compress_func:
                    try:
                        # 首先尝试直接解压（非 tar 格式）
                        with compress_func(source_path, 'rb') as f_in:
                            with open(target_path, 'wb') as f_out:
                                while chunk := f_in.read(chunk_size):
                                    f_out.write(chunk)
                        logger.info(f"文件到文件 {compress_type} 解压成功（直接解压）: {target_path}")
                    except Exception as e:
                        # 如果直接解压失败，尝试作为 tar 压缩包解压
                        logger.debug(f"直接解压失败，尝试作为 tar 压缩包解压: {e}")
                        compression_formats = get_compression_formats()
                        compression_format = compression_formats.get(compress_type)
                        
                        if compression_format:
                            try:
                                with tarfile.open(source_path, compression_format) as tar:
                                    # 假设只有一个文件
                                    for member in tar.getmembers():
                                        if member.isreg():
                                            with tar.extractfile(member) as f_in:
                                                with open(target_path, 'wb') as f_out:
                                                    while chunk := f_in.read(chunk_size):
                                                        f_out.write(chunk)
                                    logger.info(f"文件到文件 {compress_type} 解压成功（tar 格式）: {target_path}")
                            except Exception as tar_error:
                                logger.error(f"tar 格式解压失败: {tar_error}")
                                raise
            else:
                supported_types = ', '.join(['zip', '7z', 'gz', 'bz2', 'xz'])
                logger.error(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
                raise ValueError(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
        except OSError as e:
            logger.error(f"文件到文件解压失败: {source_path} -> {target_path}, 错误: {e}")
            raise

    @staticmethod
    def list_archive_contents(file_path: str, compress_type: str = None) -> List[str]:
        """
        列出压缩文件中的内容。

        :param file_path: 压缩文件路径
        :type file_path: str
        :param compress_type: 压缩文件类型，如果为 None 则自动检测
        :type compress_type: str
        :return: 压缩文件中的内容列表
        :rtype: List[str]
        
        :raises FileNotFoundError: 如果压缩文件不存在
        :raises ValueError: 如果压缩类型不受支持
        :raises OSError: 如果操作失败
        """
        logger.info(f"开始列出压缩文件内容: {file_path}")
        file_path_obj = Path(file_path)
        
        if not file_path_obj.exists():
            logger.error(f"压缩文件不存在: {file_path}")
            raise FileNotFoundError(f"压缩文件不存在: {file_path}")
        
        # 如果未指定压缩类型，尝试从文件名中推断
        if not compress_type:
            suffix = file_path_obj.suffix.lower()
            if suffix == '.gz' or suffix == '.tgz':
                compress_type = 'gz'
            elif suffix == '.bz2':
                compress_type = 'bz2'
            elif suffix == '.xz':
                compress_type = 'xz'
            elif suffix == '.zip':
                compress_type = 'zip'
            elif suffix == '.7z':
                compress_type = '7z'
            else:
                logger.error(f"无法从文件名推断压缩类型: {file_path}")
                raise ValueError(f"无法从文件名推断压缩类型: {file_path}")
        
        compress_type = compress_type.lower()
        contents = []
        
        try:
            if compress_type == "zip":
                with zipfile.ZipFile(file_path) as zfile:
                    contents = zfile.namelist()
                logger.info(f"ZIP 文件内容列表获取成功，共 {len(contents)} 项")
            elif compress_type == "7z":
                with py7zr.SevenZipFile(file_path, mode='r') as sfile:
                    contents = sfile.getnames()
                logger.info(f"7z 文件内容列表获取成功，共 {len(contents)} 项")
            elif compress_type in ["gz", "bz2", "xz"]:
                compression_formats = get_compression_formats()
                compression_format = compression_formats.get(compress_type)
                
                if compression_format:
                    with tarfile.open(file_path, compression_format) as tar:
                        contents = [member.name for member in tar.getmembers()]
                    logger.info(f"{compress_type} 文件内容列表获取成功，共 {len(contents)} 项")
                else:
                    logger.error(f"不支持的压缩类型: {compress_type}")
                    raise ValueError(f"不支持的压缩类型: {compress_type}")
            else:
                supported_types = ', '.join(['zip', '7z', 'gz', 'bz2', 'xz'])
                logger.error(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
                raise ValueError(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
            
            return contents
        except OSError as e:
            logger.error(f"列出压缩文件内容失败: {file_path}, 错误: {e}")
            raise
