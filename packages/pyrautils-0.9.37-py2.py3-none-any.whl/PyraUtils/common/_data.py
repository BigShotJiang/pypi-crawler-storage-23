#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by: 2026-03-01
modify by: 2026-03-01

功能：数据处理工具类，提供各种常用的数据转换和处理方法。
"""

from typing import Any, Dict, List, Union, Optional
import json
import csv
import io
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class DataUtils:
    """
    数据处理工具类，提供各种常用的数据转换和处理方法。
    """
    
    @staticmethod
    def convert_to_dict(data: Any) -> dict:
        """
        将数据转换为字典。

        :param data: 要转换的数据
        :type data: Any
        :return: 转换后的字典
        :rtype: dict
        
        示例用法：
        >>> DataUtils.convert_to_dict([('a', 1), ('b', 2)])
        {'a': 1, 'b': 2}
        """
        logger.info("开始将数据转换为字典")
        try:
            if isinstance(data, dict):
                result = data
            elif isinstance(data, (list, tuple)):
                # 尝试将列表或元组转换为字典
                result = {}
                for item in data:
                    if isinstance(item, (list, tuple)) and len(item) >= 2:
                        result[item[0]] = item[1]
                    else:
                        result[str(item)] = item
            else:
                # 其他类型转换为单键值对
                result = {'value': data}
            
            logger.info("数据转换为字典成功")
            return result
        except Exception as e:
            logger.error(f"数据转换为字典失败: {e}")
            return {}
    
    @staticmethod
    def convert_to_list(data: Any) -> list:
        """
        将数据转换为列表。

        :param data: 要转换的数据
        :type data: Any
        :return: 转换后的列表
        :rtype: list
        
        示例用法：
        >>> DataUtils.convert_to_list({'a': 1, 'b': 2})
        [('a', 1), ('b', 2)]
        """
        logger.info("开始将数据转换为列表")
        try:
            if isinstance(data, list):
                result = data
            elif isinstance(data, dict):
                # 将字典转换为键值对列表
                result = list(data.items())
            elif isinstance(data, (tuple, set)):
                result = list(data)
            else:
                # 其他类型转换为单元素列表
                result = [data]
            
            logger.info("数据转换为列表成功")
            return result
        except Exception as e:
            logger.error(f"数据转换为列表失败: {e}")
            return []
    
    @staticmethod
    def flatten_list(nested_list: List[Any]) -> List[Any]:
        """
        扁平化嵌套列表。

        :param nested_list: 嵌套列表
        :type nested_list: List[Any]
        :return: 扁平化后的列表
        :rtype: List[Any]
        
        示例用法：
        >>> DataUtils.flatten_list([1, [2, [3, 4], 5], 6])
        [1, 2, 3, 4, 5, 6]
        """
        logger.info("开始扁平化嵌套列表")
        try:
            result = []
            for item in nested_list:
                if isinstance(item, list):
                    result.extend(DataUtils.flatten_list(item))
                else:
                    result.append(item)
            
            logger.info("嵌套列表扁平化成功")
            return result
        except Exception as e:
            logger.error(f"嵌套列表扁平化失败: {e}")
            return []
    
    @staticmethod
    def deduplicate_list(data_list: List[Any]) -> List[Any]:
        """
        去重列表。

        :param data_list: 要去重的列表
        :type data_list: List[Any]
        :return: 去重后的列表
        :rtype: List[Any]
        
        示例用法：
        >>> DataUtils.deduplicate_list([1, 2, 2, 3, 4, 4, 5])
        [1, 2, 3, 4, 5]
        """
        logger.info("开始去重列表")
        try:
            # 对于可哈希的元素，使用集合去重
            if all(isinstance(item, (int, float, str, bool, tuple)) for item in data_list):
                result = list(set(data_list))
            else:
                # 对于不可哈希的元素，使用遍历去重
                result = []
                for item in data_list:
                    if item not in result:
                        result.append(item)
            
            logger.info("列表去重成功")
            return result
        except Exception as e:
            logger.error(f"列表去重失败: {e}")
            return []
    
    @staticmethod
    def sort_dict_by_keys(data: dict, reverse: bool = False) -> dict:
        """
        按键对字典进行排序。

        :param data: 要排序的字典
        :type data: dict
        :param reverse: 是否降序排序
        :type reverse: bool
        :return: 排序后的字典
        :rtype: dict
        
        示例用法：
        >>> DataUtils.sort_dict_by_keys({'b': 2, 'a': 1, 'c': 3})
        {'a': 1, 'b': 2, 'c': 3}
        """
        logger.info("开始按键排序字典")
        try:
            result = dict(sorted(data.items(), key=lambda item: item[0], reverse=reverse))
            logger.info("字典按键排序成功")
            return result
        except Exception as e:
            logger.error(f"字典按键排序失败: {e}")
            return data
    
    @staticmethod
    def sort_dict_by_values(data: dict, reverse: bool = False) -> dict:
        """
        按值对字典进行排序。

        :param data: 要排序的字典
        :type data: dict
        :param reverse: 是否降序排序
        :type reverse: bool
        :return: 排序后的字典
        :rtype: dict
        
        示例用法：
        >>> DataUtils.sort_dict_by_values({'b': 2, 'a': 1, 'c': 3})
        {'a': 1, 'b': 2, 'c': 3}
        """
        logger.info("开始按值排序字典")
        try:
            result = dict(sorted(data.items(), key=lambda item: item[1], reverse=reverse))
            logger.info("字典按值排序成功")
            return result
        except Exception as e:
            logger.error(f"字典按值排序失败: {e}")
            return data
    
    @staticmethod
    def filter_dict(data: dict, keys: List[str]) -> dict:
        """
        过滤字典，只保留指定的键。

        :param data: 要过滤的字典
        :type data: dict
        :param keys: 要保留的键列表
        :type keys: List[str]
        :return: 过滤后的字典
        :rtype: dict
        
        示例用法：
        >>> DataUtils.filter_dict({'a': 1, 'b': 2, 'c': 3}, ['a', 'c'])
        {'a': 1, 'c': 3}
        """
        logger.info("开始过滤字典")
        try:
            result = {key: data[key] for key in keys if key in data}
            logger.info("字典过滤成功")
            return result
        except Exception as e:
            logger.error(f"字典过滤失败: {e}")
            return {}
    
    @staticmethod
    def exclude_dict_keys(data: dict, keys: List[str]) -> dict:
        """
        排除字典中的指定键。

        :param data: 要处理的字典
        :type data: dict
        :param keys: 要排除的键列表
        :type keys: List[str]
        :return: 排除后的字典
        :rtype: dict
        
        示例用法：
        >>> DataUtils.exclude_dict_keys({'a': 1, 'b': 2, 'c': 3}, ['b'])
        {'a': 1, 'c': 3}
        """
        logger.info("开始排除字典键")
        try:
            result = {key: value for key, value in data.items() if key not in keys}
            logger.info("字典键排除成功")
            return result
        except Exception as e:
            logger.error(f"字典键排除失败: {e}")
            return data
    
    @staticmethod
    def to_csv(data: Union[List[dict], dict], headers: List[str] = None) -> str:
        """
        将数据转换为 CSV 格式。

        :param data: 要转换的数据，支持列表或字典
        :type data: Union[List[dict], dict]
        :param headers: CSV 表头
        :type headers: List[str]
        :return: CSV 格式字符串
        :rtype: str
        
        示例用法：
        >>> data = [{'name': 'John', 'age': 30}, {'name': 'Jane', 'age': 25}]
        >>> DataUtils.to_csv(data)
        "name,age\nJohn,30\nJane,25\n"
        """
        logger.info("开始将数据转换为CSV格式")
        try:
            output = io.StringIO()
            
            if isinstance(data, dict):
                data = [data]
            
            if not data:
                return ""
            
            if headers is None:
                # 从第一个字典中提取表头
                headers = list(data[0].keys())
            
            writer = csv.DictWriter(output, fieldnames=headers, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(data)
            
            result = output.getvalue()
            output.close()
            logger.info("数据转换为CSV格式成功")
            return result
        except Exception as e:
            logger.error(f"数据转换为CSV格式失败: {e}")
            return ""
    
    @staticmethod
    def from_csv(csv_str: str) -> List[dict]:
        """
        从 CSV 格式字符串解析数据。

        :param csv_str: CSV 格式字符串
        :type csv_str: str
        :return: 解析后的数据列表
        :rtype: List[dict]
        
        示例用法：
        >>> csv_str = "name,age\nJohn,30\nJane,25\n"
        >>> DataUtils.from_csv(csv_str)
        [{'name': 'John', 'age': '30'}, {'name': 'Jane', 'age': '25'}]
        """
        logger.info("开始从CSV格式解析数据")
        try:
            input_io = io.StringIO(csv_str)
            reader = csv.DictReader(input_io)
            result = list(reader)
            input_io.close()
            logger.info("从CSV格式解析数据成功")
            return result
        except Exception as e:
            logger.error(f"从CSV格式解析数据失败: {e}")
            return []
    
    @staticmethod
    def deep_copy(data: Any) -> Any:
        """
        深度复制数据。

        :param data: 要复制的数据
        :type data: Any
        :return: 复制后的数据
        :rtype: Any
        
        示例用法：
        >>> data = {'a': 1, 'b': [2, 3]}
        >>> copy_data = DataUtils.deep_copy(data)
        >>> copy_data['b'].append(4)
        >>> data
        {'a': 1, 'b': [2, 3]}
        >>> copy_data
        {'a': 1, 'b': [2, 3, 4]}
        """
        logger.info("开始深度复制数据")
        try:
            # 使用 JSON 序列化/反序列化进行深度复制
            result = json.loads(json.dumps(data))
            logger.info("数据深度复制成功")
            return result
        except Exception as e:
            logger.error(f"数据深度复制失败: {e}")
            return data
    
    @staticmethod
    def is_empty(data: Any) -> bool:
        """
        检查数据是否为空。

        :param data: 要检查的数据
        :type data: Any
        :return: 是否为空
        :rtype: bool
        
        示例用法：
        >>> DataUtils.is_empty({})
        True
        >>> DataUtils.is_empty([1, 2, 3])
        False
        """
        logger.info("开始检查数据是否为空")
        try:
            if data is None:
                return True
            elif isinstance(data, (str, list, tuple, dict, set)):
                return len(data) == 0
            else:
                return False
        except Exception as e:
            logger.error(f"检查数据是否为空失败: {e}")
            return False
    
    @staticmethod
    def safe_get(data: Any, keys: str, default: Any = None) -> Any:
        """
        安全获取嵌套数据中的值。

        :param data: 要获取数据的对象
        :type data: Any
        :param keys: 键路径，使用点号分隔
        :type keys: str
        :param default: 默认值
        :type default: Any
        :return: 获取的值或默认值
        :rtype: Any
        
        示例用法：
        >>> data = {'user': {'name': 'John', 'address': {'city': 'New York'}}}
        >>> DataUtils.safe_get(data, 'user.address.city')
        'New York'
        >>> DataUtils.safe_get(data, 'user.address.zipcode', 'Unknown')
        'Unknown'
        """
        logger.info(f"开始安全获取数据: {keys}")
        try:
            key_list = keys.split(".")
            result = data
            
            for key in key_list:
                if isinstance(result, dict) and key in result:
                    result = result[key]
                elif isinstance(result, (list, tuple)) and key.isdigit():
                    index = int(key)
                    if 0 <= index < len(result):
                        result = result[index]
                    else:
                        return default
                else:
                    return default
            
            logger.info(f"安全获取数据成功: {keys}")
            return result
        except Exception as e:
            logger.error(f"安全获取数据失败: {e}")
            return default

    @staticmethod
    def merge_dicts(*dicts: dict) -> dict:
        """
        合并多个字典。

        :param dicts: 要合并的字典
        :type dicts: dict
        :return: 合并后的字典
        :rtype: dict
        
        示例用法：
        >>> DataUtils.merge_dicts({'a': 1}, {'b': 2}, {'c': 3})
        {'a': 1, 'b': 2, 'c': 3}
        >>> DataUtils.merge_dicts({'a': 1}, {'a': 2, 'b': 3})
        {'a': 2, 'b': 3}
        """
        logger.info("开始合并字典")
        try:
            result = {}
            for d in dicts:
                if isinstance(d, dict):
                    result.update(d)
            logger.info("字典合并成功")
            return result
        except Exception as e:
            logger.error(f"字典合并失败: {e}")
            return {}

    @staticmethod
    def deep_merge_dicts(dict1: dict, dict2: dict) -> dict:
        """
        深度合并两个字典。

        :param dict1: 第一个字典
        :type dict1: dict
        :param dict2: 第二个字典
        :type dict2: dict
        :return: 合并后的字典
        :rtype: dict
        
        示例用法：
        >>> dict1 = {'a': 1, 'b': {'c': 2}}
        >>> dict2 = {'b': {'d': 3}, 'e': 4}
        >>> DataUtils.deep_merge_dicts(dict1, dict2)
        {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
        """
        logger.info("开始深度合并字典")
        try:
            result = dict1.copy()
            for key, value in dict2.items():
                if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                    result[key] = DataUtils.deep_merge_dicts(result[key], value)
                else:
                    result[key] = value
            logger.info("字典深度合并成功")
            return result
        except Exception as e:
            logger.error(f"字典深度合并失败: {e}")
            return dict1

    @staticmethod
    def get_nested_keys(data: dict, prefix: str = "") -> list:
        """
        获取字典中所有嵌套键的路径。

        :param data: 字典
        :type data: dict
        :param prefix: 前缀
        :type prefix: str
        :return: 键路径列表
        :rtype: list
        
        示例用法：
        >>> data = {'user': {'name': 'John', 'address': {'city': 'New York'}}}
        >>> DataUtils.get_nested_keys(data)
        ['user', 'user.name', 'user.address', 'user.address.city']
        """
        logger.info("开始获取嵌套键")
        try:
            keys = []
            for key, value in data.items():
                full_key = f"{prefix}.{key}" if prefix else key
                keys.append(full_key)
                if isinstance(value, dict):
                    keys.extend(DataUtils.get_nested_keys(value, full_key))
            logger.info("获取嵌套键成功")
            return keys
        except Exception as e:
            logger.error(f"获取嵌套键失败: {e}")
            return []

    @staticmethod
    def dict_to_xml(data: dict, root: str = "root") -> str:
        """
        将字典转换为 XML 字符串。

        :param data: 字典
        :type data: dict
        :param root: 根元素名称
        :type root: str
        :return: XML 字符串
        :rtype: str
        
        示例用法：
        >>> data = {'user': {'name': 'John', 'age': 30}}
        >>> DataUtils.dict_to_xml(data)
        '<root><user><name>John</name><age>30</age></user></root>'
        """
        logger.info("开始将字典转换为XML")
        try:
            def _dict_to_xml(data, parent):
                xml = []
                for key, value in data.items():
                    if isinstance(value, dict):
                        xml.append(f"<{key}>")
                        xml.append(_dict_to_xml(value, key))
                        xml.append(f"</{key}>")
                    else:
                        xml.append(f"<{key}>{value}</{key}>")
                return "".join(xml)

            xml = f"<{root}>" + _dict_to_xml(data, root) + f"</{root}>"
            logger.info("字典转换为XML成功")
            return xml
        except Exception as e:
            logger.error(f"字典转换为XML失败: {e}")
            return f"<{root}></{root}>"

    @staticmethod
    def chunk_list(data: list, size: int) -> list:
        """
        将列表分块。

        :param data: 列表
        :type data: list
        :param size: 块大小
        :type size: int
        :return: 分块后的列表
        :rtype: list
        
        示例用法：
        >>> DataUtils.chunk_list([1, 2, 3, 4, 5], 2)
        [[1, 2], [3, 4], [5]]
        """
        logger.info(f"开始将列表分块，块大小: {size}")
        try:
            result = []
            for i in range(0, len(data), size):
                result.append(data[i:i+size])
            logger.info("列表分块成功")
            return result
        except Exception as e:
            logger.error(f"列表分块失败: {e}")
            return []

    @staticmethod
    def group_by(data: list, key: callable) -> dict:
        """
        根据指定键对列表进行分组。

        :param data: 列表
        :type data: list
        :param key: 分组键函数
        :type key: callable
        :return: 分组后的字典
        :rtype: dict
        
        示例用法：
        >>> data = [{'name': 'John', 'age': 30}, {'name': 'Jane', 'age': 25}, {'name': 'Bob', 'age': 30}]
        >>> DataUtils.group_by(data, lambda x: x['age'])
        {30: [{'name': 'John', 'age': 30}, {'name': 'Bob', 'age': 30}], 25: [{'name': 'Jane', 'age': 25}]}
        """
        logger.info("开始根据键分组列表")
        try:
            result = {}
            for item in data:
                group_key = key(item)
                if group_key not in result:
                    result[group_key] = []
                result[group_key].append(item)
            logger.info("列表分组成功")
            return result
        except Exception as e:
            logger.error(f"列表分组失败: {e}")
            return {}

    @staticmethod
    def calculate_statistics(data: list) -> dict:
        """
        计算列表的统计信息。

        :param data: 数字列表
        :type data: list
        :return: 统计信息字典
        :rtype: dict
        
        示例用法：
        >>> DataUtils.calculate_statistics([1, 2, 3, 4, 5])
        {'count': 5, 'sum': 15, 'mean': 3.0, 'min': 1, 'max': 5}
        """
        logger.info("开始计算列表统计信息")
        try:
            if not data or not all(isinstance(x, (int, float)) for x in data):
                return {}

            count = len(data)
            sum_ = sum(data)
            mean = sum_ / count
            min_ = min(data)
            max_ = max(data)

            result = {
                'count': count,
                'sum': sum_,
                'mean': mean,
                'min': min_,
                'max': max_
            }
            logger.info("列表统计信息计算成功")
            return result
        except Exception as e:
            logger.error(f"计算统计信息失败: {e}")
            return {}

    @staticmethod
    def to_json(data: Any, indent: int = 2) -> str:
        """
        将数据转换为 JSON 字符串。

        :param data: 要转换的数据
        :type data: Any
        :param indent: 缩进空格数
        :type indent: int
        :return: JSON 字符串
        :rtype: str
        
        示例用法：
        >>> DataUtils.to_json({'name': 'John', 'age': 30})
        '{"name": "John", "age": 30}'
        """
        logger.info("开始将数据转换为JSON")
        try:
            result = json.dumps(data, ensure_ascii=False, indent=indent)
            logger.info("数据转换为JSON成功")
            return result
        except Exception as e:
            logger.error(f"数据转换为JSON失败: {e}")
            return ""

    @staticmethod
    def from_json(json_str: str) -> Any:
        """
        从 JSON 字符串解析数据。

        :param json_str: JSON 字符串
        :type json_str: str
        :return: 解析后的数据
        :rtype: Any
        
        示例用法：
        >>> DataUtils.from_json('{"name": "John", "age": 30}')
        {'name': 'John', 'age': 30}
        """
        logger.info("开始从JSON解析数据")
        try:
            result = json.loads(json_str)
            logger.info("从JSON解析数据成功")
            return result
        except Exception as e:
            logger.error(f"从JSON解析数据失败: {e}")
            return None
