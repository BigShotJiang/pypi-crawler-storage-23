"""
Password 模块 - 提供密码生成、强度检查和TOTP认证功能

This module provides utilities for password management and two-factor authentication, including:
- PasswordMaker: Utility for generating secure passwords
- PasswordStrength: Utility for checking password strength
- PasswordPolicy: Class for defining password policies
- hash_password: Function to hash passwords
- verify_password: Function to verify hashed passwords
- generate_totp_secret: Function to generate TOTP secrets
- generate_totp_qr_code: Function to generate TOTP QR codes
- verify_totp_code: Function to verify TOTP codes
"""

from ._password import (
    PasswordMaker, PasswordStrength, PasswordPolicy, 
    hash_password, verify_password, 
    generate_totp_secret, generate_totp_qr_code, verify_totp_code
)

__all__ = [
    'PasswordMaker', 'PasswordStrength', 'PasswordPolicy', 
    'hash_password', 'verify_password', 
    'generate_totp_secret', 'generate_totp_qr_code', 'verify_totp_code'
]
