#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by: 2024-03-18
modify by: 2024-03-18

功能：密码生成和强度检查工具类。
"""

import secrets
import random
import string
import hashlib
import bcrypt
from typing import Optional, Set, Dict, Any
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class PasswordMaker:
    """
    密码生成器类，用于生成安全的随机密码。
    
    示例用法：
    >>> from PyraUtils.password._password import PasswordMaker
    >>> 
    >>> # 生成默认长度（10位）的随机密码
    >>> password = PasswordMaker.make_random_password()
    >>> print(password)
    >>> 
    >>> # 生成指定长度（16位）的随机密码
    >>> password = PasswordMaker.make_random_password(length=16)
    >>> print(password)
    >>> 
    >>> # 生成仅包含字母和数字的随机密码
    >>> password = PasswordMaker.make_random_password(allowed_chars=string.ascii_letters + string.digits)
    >>> print(password)
    """
    
    @staticmethod
    def make_random_password(length: int = 10, allowed_chars: Optional[str] = None) -> str:
        """
        生成一个随机密码。

        :param length: 指定生成密码的长度，默认为10
        :type length: int
        :param allowed_chars: 指定可用于构造密码的字符集合。如果未指定，则使用默认的安全字符集
        :type allowed_chars: Optional[str]
        :return: 一个随机生成的密码字符串
        :rtype: str
        :raises ValueError: 如果长度小于1
        """
        logger.info(f"开始生成随机密码，长度: {length}")
        if length < 1:
            logger.error("密码长度必须大于0")
            raise ValueError("密码长度必须大于0")
            
        # 如果没有指定允许的字符集合，则使用默认的安全字符集
        if not allowed_chars:
            allowed_chars = string.ascii_letters + string.digits + string.punctuation
            logger.debug("使用默认安全字符集")
        else:
            logger.debug("使用自定义字符集")
            
        # 生成随机密码直到达到需要的长度
        password = ''.join(secrets.choice(allowed_chars) for _ in range(length))
        logger.info("随机密码生成成功")
        # 注意：不要记录密码本身，避免安全风险
        return password

    @staticmethod
    def make_password_reset_token() -> str:
        """
        生成密码重置令牌。

        :return: 密码重置令牌
        :rtype: str
        """
        logger.info("生成密码重置令牌")
        token = secrets.token_urlsafe(32)
        logger.info("密码重置令牌生成成功")
        return token


class PasswordStrength:
    """
    密码强度检查器类，用于评估密码强度和检测弱密码。
    
    弱口令字典推荐地址: 
    - https://github.com/wwl012345/PasswordDic
    - https://github.com/brannondorsey/naive-hashcat/releases/download/data/rockyou.txt
    
    示例用法：
    >>> from PyraUtils.password._password import PasswordStrength
    >>> 
    >>> # 初始化密码强度检查器（使用弱密码字典）
    >>> strength_checker = PasswordStrength(words_path='path/to/weak_passwords.txt')
    >>> 
    >>> # 检查密码是否为弱密码
    >>> is_weak = strength_checker.is_weak_password('password123')
    >>> print(f"密码是否为弱密码: {is_weak}")
    >>> 
    >>> # 检查密码强度
    >>> strength = strength_checker.password_strength('My$trongP@ssw0rd123')
    >>> print(f"密码强度: {strength}")
    """
    
    def __init__(self, words_path: Optional[str] = None):
        """
        初始化 PasswordStrength 对象。

        :param words_path: 弱口令字典文件路径。如果不提供，则需要后续手动设置 word_set 属性
        :type words_path: Optional[str]
        :raises FileNotFoundError: 如果指定的文件不存在
        """
        self.word_set: Set[str] = set()
        if words_path:
            logger.info(f"开始加载弱密码字典: {words_path}")
            try:
                with open(words_path, 'r', encoding='utf-8') as f:
                    # 从给定文件中读取并存储弱密码库
                    self.word_set.update(line.strip().lower() for line in f)
                logger.info(f"弱密码字典加载成功，共 {len(self.word_set)} 条记录")
            except FileNotFoundError:
                logger.error(f"弱口令字典不存在: {words_path}")
                raise FileNotFoundError(
                    "弱口令字典不存在，请下载以下字典：\n"
                    "- https://github.com/wwl012345/PasswordDic\n"
                    "- https://github.com/brannondorsey/naive-hashcat/releases/download/data/rockyou.txt"
                )

    def is_weak_password(self, pw_str: str) -> bool:
        """
        根据预定义的弱口令字典检测密码是否弱。

        :param pw_str: 要检测的密码字符串
        :type pw_str: str
        :return: 如果密码被认为是弱密码返回 True，否则返回 False
        :rtype: bool
        :raises ValueError: 如果弱密码字典未加载
        """
        logger.info("开始检查密码是否为弱密码")
        if not self.word_set:
            logger.error("弱密码字典未加载")
            raise ValueError("弱密码字典未加载，请初始化时提供字典路径或手动设置 word_set 属性")
        
        is_weak = pw_str.lower() in self.word_set
        if is_weak:
            logger.warning("检测到弱密码")
        else:
            logger.info("密码不在弱密码字典中")
        return is_weak

    def password_strength(self, pw_str: str) -> str:
        """
        评估密码的复杂度，并根据结果分类。

        :param pw_str: 要评估的密码字符串
        :type pw_str: str
        :return: 密码的强度等级（'WEAK', 'MEDIUM', 'STRONG'）
        :rtype: str
        """
        logger.info("开始评估密码强度")
        # 检查密码长度和是否为弱密码
        if len(pw_str) < 8:
            logger.info("密码强度: WEAK (长度不足8位)")
            return 'WEAK'
            
        try:
            if self.is_weak_password(pw_str):
                logger.info("密码强度: WEAK (在弱密码字典中)")
                return 'WEAK'
        except ValueError:
            # 如果弱密码字典未加载，跳过弱密码检查
            logger.debug("弱密码字典未加载，跳过弱密码检查")
            pass
        
        # 计算密码中包含的不同字符类别数量
        char_classes = [
            string.ascii_lowercase,  # 小写字母
            string.ascii_uppercase,  # 大写字母
            string.digits,           # 数字
            string.punctuation       # 标点符号
        ]
        
        strength_score = sum(1 for char_class in char_classes if any(c in pw_str for c in char_class))
        
        # 根据长度和字符类别数量判断密码强度
        if len(pw_str) >= 12 and strength_score >= 3:
            logger.info("密码强度: STRONG")
            return 'STRONG'
        elif len(pw_str) >= 8 and strength_score >= 2:
            logger.info("密码强度: MEDIUM")
            return 'MEDIUM'
        else:
            logger.info("密码强度: WEAK")
            return 'WEAK'

    def get_password_strength_details(self, pw_str: str) -> Dict[str, Any]:
        """
        获取密码强度的详细信息。

        :param pw_str: 要评估的密码字符串
        :type pw_str: str
        :return: 包含密码强度详细信息的字典
        :rtype: Dict[str, Any]
        """
        logger.info("开始获取密码强度详细信息")
        details = {
            'length': len(pw_str),
            'has_lowercase': any(c.islower() for c in pw_str),
            'has_uppercase': any(c.isupper() for c in pw_str),
            'has_digits': any(c.isdigit() for c in pw_str),
            'has_punctuation': any(c in string.punctuation for c in pw_str),
            'strength_level': self.password_strength(pw_str)
        }
        
        # 计算密码强度得分（0-100）
        score = 0
        if details['length'] >= 12:
            score += 30
        elif details['length'] >= 8:
            score += 20
        else:
            score += 5
        
        if details['has_lowercase']:
            score += 15
        if details['has_uppercase']:
            score += 15
        if details['has_digits']:
            score += 15
        if details['has_punctuation']:
            score += 15
        
        # 检查是否为弱密码
        try:
            if self.is_weak_password(pw_str):
                score = max(0, score - 30)
        except ValueError:
            pass
        
        details['score'] = min(100, score)
        logger.info(f"密码强度详细信息获取完成，得分: {details['score']}")
        return details

    def validate_password_rules(self, pw_str: str, min_length: int = 8, require_lowercase: bool = True, 
                               require_uppercase: bool = True, require_digits: bool = True, 
                               require_punctuation: bool = True) -> Dict[str, bool]:
        """
        验证密码是否符合指定规则。

        :param pw_str: 要验证的密码字符串
        :type pw_str: str
        :param min_length: 最小密码长度
        :type min_length: int
        :param require_lowercase: 是否要求包含小写字母
        :type require_lowercase: bool
        :param require_uppercase: 是否要求包含大写字母
        :type require_uppercase: bool
        :param require_digits: 是否要求包含数字
        :type require_digits: bool
        :param require_punctuation: 是否要求包含标点符号
        :type require_punctuation: bool
        :return: 包含各项规则验证结果的字典
        :rtype: Dict[str, bool]
        """
        logger.info("开始验证密码规则")
        validation = {
            'length': len(pw_str) >= min_length,
            'lowercase': not require_lowercase or any(c.islower() for c in pw_str),
            'uppercase': not require_uppercase or any(c.isupper() for c in pw_str),
            'digits': not require_digits or any(c.isdigit() for c in pw_str),
            'punctuation': not require_punctuation or any(c in string.punctuation for c in pw_str)
        }
        validation['all_passed'] = all(validation.values())
        logger.info(f"密码规则验证完成，结果: {validation['all_passed']}")
        return validation


def hash_password(password: str) -> str:
    """
    使用 bcrypt 对密码进行哈希处理。

    :param password: 原始密码
    :type password: str
    :return: 哈希后的密码
    :rtype: str
    """
    logger.info("开始对密码进行哈希处理")
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    logger.info("密码哈希处理完成")
    return hashed.decode('utf-8')


def verify_password(password: str, hashed_password: str) -> bool:
    """
    验证密码是否与哈希值匹配。

    :param password: 原始密码
    :type password: str
    :param hashed_password: 哈希后的密码
    :type hashed_password: str
    :return: 密码是否匹配
    :rtype: bool
    """
    logger.info("开始验证密码")
    try:
        is_match = bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))
        logger.info(f"密码验证完成，结果: {is_match}")
        return is_match
    except Exception as e:
        logger.error(f"密码验证失败: {e}")
        return False


def generate_totp_secret() -> str:
    """
    生成 TOTP 双因素认证密钥。

    :return: TOTP 密钥
    :rtype: str
    """
    import base64
    secret = secrets.token_bytes(20)
    return base64.b32encode(secret).decode('utf-8')


def generate_totp_qr_code(secret: str, issuer: str, user: str) -> str:
    """
    生成 TOTP 二维码 URL。

    :param secret: TOTP 密钥
    :type secret: str
    :param issuer: 发行者名称
    :type issuer: str
    :param user: 用户标识
    :type user: str
    :return: 二维码 URL
    :rtype: str
    """
    import urllib.parse
    
    label = urllib.parse.quote(f"{issuer}:{user}")
    params = urllib.parse.urlencode({
        'secret': secret,
        'issuer': issuer,
        'algorithm': 'SHA1',
        'digits': 6,
        'period': 30
    })
    
    return f"otpauth://totp/{label}?{params}"


def verify_totp_code(secret: str, code: str) -> bool:
    """
    验证 TOTP 代码。

    :param secret: TOTP 密钥
    :type secret: str
    :param code: TOTP 代码
    :type code: str
    :return: 代码是否有效
    :rtype: bool
    """
    import base64
    import time
    import hmac
    import hashlib
    
    try:
        # 解码密钥
        secret_bytes = base64.b32decode(secret.upper() + '=' * ((8 - len(secret) % 8) % 8))
        
        # 获取当前时间窗口
        timestamp = int(time.time() // 30)
        
        # 验证当前时间窗口和前一个时间窗口
        for offset in range(-1, 2):
            # 计算时间戳的字节表示
            time_bytes = timestamp.to_bytes(8, 'big')
            
            # 计算 HMAC
            hmac_digest = hmac.new(secret_bytes, time_bytes, hashlib.sha1).digest()
            
            # 提取动态验证码
            offset = hmac_digest[-1] & 0x0F
            code_bytes = hmac_digest[offset:offset+4]
            code_int = int.from_bytes(code_bytes, 'big') & 0x7FFFFFFF
            expected_code = str(code_int % 1000000).zfill(6)
            
            if code == expected_code:
                return True
        
        return False
    except Exception as e:
        logger.error(f"TOTP 代码验证失败: {e}")
        return False


class PasswordPolicy:
    """
    密码策略类，用于定义和验证密码策略。
    """
    
    def __init__(self, min_length: int = 8, max_length: int = 128,
                 require_lowercase: bool = True, require_uppercase: bool = True,
                 require_digits: bool = True, require_punctuation: bool = True,
                 require_special_chars: bool = False,
                 max_repeated_chars: int = 3,
                 max_consecutive_chars: int = 3,
                 disallow_common_passwords: bool = True,
                 common_passwords_path: str = None):
        """
        初始化密码策略。

        :param min_length: 最小密码长度
        :type min_length: int
        :param max_length: 最大密码长度
        :type max_length: int
        :param require_lowercase: 是否要求包含小写字母
        :type require_lowercase: bool
        :param require_uppercase: 是否要求包含大写字母
        :type require_uppercase: bool
        :param require_digits: 是否要求包含数字
        :type require_digits: bool
        :param require_punctuation: 是否要求包含标点符号
        :type require_punctuation: bool
        :param require_special_chars: 是否要求包含特殊字符
        :type require_special_chars: bool
        :param max_repeated_chars: 最大重复字符数
        :type max_repeated_chars: int
        :param max_consecutive_chars: 最大连续字符数
        :type max_consecutive_chars: int
        :param disallow_common_passwords: 是否禁止使用常见密码
        :type disallow_common_passwords: bool
        :param common_passwords_path: 常见密码字典路径
        :type common_passwords_path: str
        """
        self.min_length = min_length
        self.max_length = max_length
        self.require_lowercase = require_lowercase
        self.require_uppercase = require_uppercase
        self.require_digits = require_digits
        self.require_punctuation = require_punctuation
        self.require_special_chars = require_special_chars
        self.max_repeated_chars = max_repeated_chars
        self.max_consecutive_chars = max_consecutive_chars
        self.disallow_common_passwords = disallow_common_passwords
        
        # 加载常见密码字典
        self.common_passwords = set()
        if disallow_common_passwords and common_passwords_path:
            try:
                with open(common_passwords_path, 'r', encoding='utf-8') as f:
                    self.common_passwords.update(line.strip().lower() for line in f)
                logger.info(f"加载了 {len(self.common_passwords)} 个常见密码")
            except Exception as e:
                logger.warning(f"无法加载常见密码字典: {e}")
    
    def validate(self, password: str) -> dict:
        """
        验证密码是否符合策略。

        :param password: 要验证的密码
        :type password: str
        :return: 验证结果，包含各项规则的验证结果和错误信息
        :rtype: dict
        """
        errors = []
        
        # 验证长度
        if len(password) < self.min_length:
            errors.append(f"密码长度必须至少为 {self.min_length} 个字符")
        if len(password) > self.max_length:
            errors.append(f"密码长度不能超过 {self.max_length} 个字符")
        
        # 验证字符类型
        if self.require_lowercase and not any(c.islower() for c in password):
            errors.append("密码必须包含至少一个小写字母")
        if self.require_uppercase and not any(c.isupper() for c in password):
            errors.append("密码必须包含至少一个大写字母")
        if self.require_digits and not any(c.isdigit() for c in password):
            errors.append("密码必须包含至少一个数字")
        if self.require_punctuation and not any(c in string.punctuation for c in password):
            errors.append("密码必须包含至少一个标点符号")
        
        # 验证重复字符
        if self.max_repeated_chars > 0:
            count = 1
            for i in range(1, len(password)):
                if password[i] == password[i-1]:
                    count += 1
                    if count > self.max_repeated_chars:
                        errors.append(f"密码不能包含超过 {self.max_repeated_chars} 个连续重复的字符")
                        break
                else:
                    count = 1
        
        # 验证连续字符
        if self.max_consecutive_chars > 0:
            for i in range(len(password) - self.max_consecutive_chars):
                is_consecutive = True
                for j in range(1, self.max_consecutive_chars + 1):
                    if ord(password[i + j]) != ord(password[i]) + j:
                        is_consecutive = False
                        break
                if is_consecutive:
                    errors.append(f"密码不能包含超过 {self.max_consecutive_chars} 个连续的字符")
                    break
        
        # 验证常见密码
        if self.disallow_common_passwords and password.lower() in self.common_passwords:
            errors.append("密码不能使用常见密码")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors
        }
    
    def get_policy_description(self) -> str:
        """
        获取密码策略描述。

        :return: 密码策略描述
        :rtype: str
        """
        rules = []
        rules.append(f"长度: {self.min_length}-{self.max_length} 个字符")
        
        if self.require_lowercase:
            rules.append("包含至少一个小写字母")
        if self.require_uppercase:
            rules.append("包含至少一个大写字母")
        if self.require_digits:
            rules.append("包含至少一个数字")
        if self.require_punctuation:
            rules.append("包含至少一个标点符号")
        
        if self.max_repeated_chars > 0:
            rules.append(f"不超过 {self.max_repeated_chars} 个连续重复字符")
        if self.max_consecutive_chars > 0:
            rules.append(f"不超过 {self.max_consecutive_chars} 个连续字符")
        if self.disallow_common_passwords:
            rules.append("不使用常见密码")
        
        return "\n".join(rules)


def generate_password_suggestion(length: int = 12) -> str:
    """
    生成密码建议。

    :param length: 密码长度
    :type length: int
    :return: 生成的密码
    :rtype: str
    """
    logger.info(f"生成密码建议，长度: {length}")
    # 确保密码包含各种字符类型
    password = []
    
    # 添加至少一个每种类型的字符
    password.append(secrets.choice(string.ascii_lowercase))
    password.append(secrets.choice(string.ascii_uppercase))
    password.append(secrets.choice(string.digits))
    password.append(secrets.choice(string.punctuation))
    
    # 填充剩余长度
    remaining_length = length - 4
    if remaining_length > 0:
        all_chars = string.ascii_letters + string.digits + string.punctuation
        password.extend(secrets.choice(all_chars) for _ in range(remaining_length))
    
    # 打乱顺序
    secrets.SystemRandom().shuffle(password)
    result = ''.join(password)
    logger.info("密码建议生成成功")
    return result


def analyze_password_complexity(password: str) -> dict:
    """
    分析密码复杂度。

    :param password: 密码
    :type password: str
    :return: 复杂度分析结果
    :rtype: dict
    """
    logger.info("分析密码复杂度")
    analysis = {
        'length': len(password),
        'has_lowercase': any(c.islower() for c in password),
        'has_uppercase': any(c.isupper() for c in password),
        'has_digits': any(c.isdigit() for c in password),
        'has_punctuation': any(c in string.punctuation for c in password),
        'unique_chars': len(set(password)),
        'entropy': calculate_password_entropy(password)
    }
    
    # 计算强度等级
    score = 0
    if analysis['length'] >= 12:
        score += 30
    elif analysis['length'] >= 8:
        score += 20
    else:
        score += 5
    
    if analysis['has_lowercase']:
        score += 15
    if analysis['has_uppercase']:
        score += 15
    if analysis['has_digits']:
        score += 15
    if analysis['has_punctuation']:
        score += 15
    
    if analysis['unique_chars'] >= analysis['length'] * 0.8:
        score += 10
    
    score = min(100, score)
    
    if score >= 80:
        analysis['strength'] = 'STRONG'
    elif score >= 50:
        analysis['strength'] = 'MEDIUM'
    else:
        analysis['strength'] = 'WEAK'
    
    analysis['score'] = score
    logger.info(f"密码复杂度分析完成，得分: {score}")
    return analysis


def calculate_password_entropy(password: str) -> float:
    """
    计算密码熵。

    :param password: 密码
    :type password: str
    :return: 密码熵
    :rtype: float
    """
    import math
    
    # 确定字符集大小
    char_set_size = 0
    if any(c.islower() for c in password):
        char_set_size += 26
    if any(c.isupper() for c in password):
        char_set_size += 26
    if any(c.isdigit() for c in password):
        char_set_size += 10
    if any(c in string.punctuation for c in password):
        char_set_size += len(string.punctuation)
    
    if char_set_size == 0:
        return 0
    
    # 计算熵
    entropy = len(password) * math.log2(char_set_size)
    return entropy


def generate_password_hint(password: str) -> str:
    """
    生成密码提示。

    :param password: 密码
    :type password: str
    :return: 密码提示
    :rtype: str
    """
    logger.info("生成密码提示")
    hints = []
    
    # 基于密码长度
    hints.append(f"长度为 {len(password)} 个字符")
    
    # 基于字符类型
    if any(c.islower() for c in password):
        hints.append("包含小写字母")
    if any(c.isupper() for c in password):
        hints.append("包含大写字母")
    if any(c.isdigit() for c in password):
        hints.append("包含数字")
    if any(c in string.punctuation for c in password):
        hints.append("包含标点符号")
    
    # 基于特殊特征
    if len(set(password)) == len(password):
        hints.append("所有字符都不重复")
    
    # 随机选择3个提示
    if len(hints) > 3:
        hints = random.sample(hints, 3)
    
    return "; ".join(hints)


def check_password_history(password: str, history: list) -> bool:
    """
    检查密码是否在历史记录中。

    :param password: 新密码
    :type password: str
    :param history: 密码历史记录
    :type history: list
    :return: 是否在历史记录中
    :rtype: bool
    """
    logger.info("检查密码历史记录")
    for old_password_hash in history:
        if verify_password(password, old_password_hash):
            logger.warning("密码在历史记录中")
            return True
    logger.info("密码不在历史记录中")
    return False


def generate_secure_token(length: int = 32) -> str:
    """
    生成安全令牌。

    :param length: 令牌长度
    :type length: int
    :return: 安全令牌
    :rtype: str
    """
    logger.info(f"生成安全令牌，长度: {length}")
    token = secrets.token_urlsafe(length)
    logger.info("安全令牌生成成功")
    return token


def mask_password(password: str, show_chars: int = 2) -> str:
    """
    掩码密码，只显示前几个字符。

    :param password: 密码
    :type password: str
    :param show_chars: 显示的字符数
    :type show_chars: int
    :return: 掩码后的密码
    :rtype: str
    """
    if len(password) <= show_chars:
        return '*' * len(password)
    return password[:show_chars] + '*' * (len(password) - show_chars)


def validate_password_with_feedback(password: str, policy: PasswordPolicy = None) -> dict:
    """
    验证密码并提供详细反馈。

    :param password: 密码
    :type password: str
    :param policy: 密码策略
    :type policy: PasswordPolicy
    :return: 验证结果和反馈
    :rtype: dict
    """
    logger.info("验证密码并提供反馈")
    
    # 如果没有提供策略，使用默认策略
    if policy is None:
        policy = PasswordPolicy()
    
    # 验证密码
    validation = policy.validate(password)
    
    # 分析密码复杂度
    complexity = analyze_password_complexity(password)
    
    # 生成建议
    suggestions = []
    if complexity['length'] < 12:
        suggestions.append("使用至少12个字符的密码")
    if not complexity['has_lowercase']:
        suggestions.append("添加小写字母")
    if not complexity['has_uppercase']:
        suggestions.append("添加大写字母")
    if not complexity['has_digits']:
        suggestions.append("添加数字")
    if not complexity['has_punctuation']:
        suggestions.append("添加标点符号")
    
    return {
        'valid': validation['valid'],
        'errors': validation['errors'],
        'complexity': complexity,
        'suggestions': suggestions,
        'hint': generate_password_hint(password)
    }