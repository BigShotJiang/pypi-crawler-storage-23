#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by: 2024-03-18
modify by: 2026-03-01 11:00:00

功能：SSL 证书检查工具类，提供证书格式验证和过期时间检查功能。
"""

import os
import datetime
from typing import Tuple, Optional, Dict, Any
from OpenSSL import crypto
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class SSLUtils:
    """
    SSL 证书检查工具类，提供证书格式验证、过期时间检查和证书信息提取功能。
    
    示例用法：
    >>> from PyraUtils import SSLUtils
    >>> 
    >>> # 检查证书是否为 PEM 格式
    >>> is_pem = SSLUtils.is_pem_format('path/to/cert.pem')
    >>> print(f"证书是否为 PEM 格式: {is_pem}")
    >>> 
    >>> # 检查证书是否将在 30 天内过期
    >>> is_expiring, details = SSLUtils.check_cert_expiry('path/to/cert.pem', days=30)
    >>> print(f"证书是否即将过期: {is_expiring}")
    >>> print(f"证书过期时间: {details['expiration_date']}")
    >>> print(f"证书剩余天数: {details['remaining_days']}")
    """
    
    @staticmethod
    def is_pem_format(cert_path: str) -> bool:
        """
        检查给定路径的证书文件是否为有效的 PEM 格式。

        :param cert_path: 证书文件的路径
        :type cert_path: str
        :return: 布尔值，表示是否为有效的 PEM 格式
        :rtype: bool
        :raises FileNotFoundError: 如果证书文件不存在
        """
        logger.info(f"开始检查证书是否为 PEM 格式: {cert_path}")
        if not os.path.exists(cert_path):
            logger.error(f"证书文件不存在: {cert_path}")
            raise FileNotFoundError(f"证书文件不存在: {cert_path}")

        try:
            with open(cert_path, 'rb') as cert_file:
                cert_content = cert_file.read()
            # 尝试加载证书内容
            crypto.load_certificate(crypto.FILETYPE_PEM, cert_content)
            logger.info(f"证书 {cert_path} 是有效的 PEM 格式")
            return True
        except crypto.Error:
            # 如果加载失败，则不是有效的 PEM 格式
            logger.info(f"证书 {cert_path} 不是有效的 PEM 格式")
            return False

    @staticmethod
    def check_cert_expiry(cert_path: str, days: int = 30) -> Tuple[bool, Dict[str, Any]]:
        """
        检查给定路径的 SSL 证书是否将在指定天数内过期。

        :param cert_path: 包含 SSL 证书的路径
        :type cert_path: str
        :param days: 相对于当前日期，考虑为即将过期的天数阈值
        :type days: int
        :return: 元组 (即将过期的布尔值, 证书详细信息)
        :rtype: Tuple[bool, Dict[str, Any]]
        :raises FileNotFoundError: 如果证书文件不存在
        :raises ValueError: 如果证书格式无效
        """
        logger.info(f"开始检查证书过期时间: {cert_path}, 阈值: {days}天")
        if not os.path.exists(cert_path):
            logger.error(f"证书文件不存在: {cert_path}")
            raise FileNotFoundError(f"证书文件不存在: {cert_path}")

        try:
            # 读取证书内容
            with open(cert_path, 'rb') as cert_file:
                cert_content = cert_file.read()

            # 加载证书
            cert = crypto.load_certificate(crypto.FILETYPE_PEM, cert_content)

            # 获取证书创建时间
            before_date = datetime.datetime.strptime(cert.get_notBefore().decode('ascii'), '%Y%m%d%H%M%SZ')
            
            # 获取证书过期时间
            expiration_date = datetime.datetime.strptime(cert.get_notAfter().decode('ascii'), '%Y%m%d%H%M%SZ')
            # 计算当前时间与过期时间的差值
            now = datetime.datetime.utcnow()
            remaining = expiration_date - now
            remaining_days = remaining.days

            # 判断是否快到期
            is_expiring = remaining < datetime.timedelta(days=days)
            if is_expiring:
                logger.warning(f"证书 {cert_path} 将在 {remaining_days} 天内过期")
            else:
                logger.info(f"证书 {cert_path} 有效期还有 {remaining_days} 天")
            
            # 提取证书详细信息
            details = {
                'start_date': before_date,
                'expiration_date': expiration_date,
                'remaining_days': remaining_days,
                'is_expiring': is_expiring,
                'issuer': SSLUtils._get_cert_issuer(cert),
                'subject': SSLUtils._get_cert_subject(cert),
                'serial_number': cert.get_serial_number(),
                'version': cert.get_version()
            }
            
            return is_expiring, details
        except crypto.Error as e:
            error_msg = f"无效的证书格式: {str(e)}"
            logger.error(f"检查证书过期时间失败: {cert_path}, 错误: {error_msg}")
            raise ValueError(error_msg)
        except Exception as e:
            error_msg = str(e)
            logger.error(f"检查证书过期时间失败: {cert_path}, 错误: {error_msg}")
            raise ValueError(error_msg)

    @staticmethod
    def _get_cert_issuer(cert) -> Dict[str, str]:
        """
        提取证书的颁发者信息。

        :param cert: 证书对象
        :return: 颁发者信息字典
        :rtype: Dict[str, str]
        """
        issuer = cert.get_issuer()
        issuer_info = {}
        for item in issuer.get_components():
            key, value = item
            issuer_info[key.decode('utf-8')] = value.decode('utf-8')
        return issuer_info

    @staticmethod
    def _get_cert_subject(cert) -> Dict[str, str]:
        """
        提取证书的主题信息。

        :param cert: 证书对象
        :return: 主题信息字典
        :rtype: Dict[str, str]
        """
        subject = cert.get_subject()
        subject_info = {}
        for item in subject.get_components():
            key, value = item
            subject_info[key.decode('utf-8')] = value.decode('utf-8')
        return subject_info

    @staticmethod
    def get_cert_info(cert_path: str) -> Dict[str, Any]:
        """
        获取证书的详细信息。

        :param cert_path: 证书文件的路径
        :type cert_path: str
        :return: 证书详细信息字典
        :rtype: Dict[str, Any]
        :raises FileNotFoundError: 如果证书文件不存在
        :raises ValueError: 如果证书格式无效
        """
        logger.info(f"开始获取证书详细信息: {cert_path}")
        if not os.path.exists(cert_path):
            logger.error(f"证书文件不存在: {cert_path}")
            raise FileNotFoundError(f"证书文件不存在: {cert_path}")

        try:
            with open(cert_path, 'rb') as cert_file:
                cert_content = cert_file.read()

            cert = crypto.load_certificate(crypto.FILETYPE_PEM, cert_content)

            info = {
                'version': cert.get_version(),
                'serial_number': cert.get_serial_number(),
                'subject': SSLUtils._get_cert_subject(cert),
                'issuer': SSLUtils._get_cert_issuer(cert),
                'not_before': datetime.datetime.strptime(cert.get_notBefore().decode('ascii'), '%Y%m%d%H%M%SZ'),
                'not_after': datetime.datetime.strptime(cert.get_notAfter().decode('ascii'), '%Y%m%d%H%M%SZ'),
                'fingerprint_sha1': cert.digest('sha1').decode('utf-8'),
                'fingerprint_sha256': cert.digest('sha256').decode('utf-8')
            }
            
            logger.info(f"获取证书详细信息成功: {cert_path}")
            return info
        except crypto.Error as e:
            error_msg = f"无效的证书格式: {str(e)}"
            logger.error(f"获取证书信息失败: {cert_path}, 错误: {error_msg}")
            raise ValueError(error_msg)
        except Exception as e:
            error_msg = str(e)
            logger.error(f"获取证书信息失败: {cert_path}, 错误: {error_msg}")
            raise ValueError(error_msg)

    @staticmethod
    def is_cert_valid(cert_path: str) -> bool:
        """
        检查证书是否有效（未过期）。

        :param cert_path: 证书文件的路径
        :type cert_path: str
        :return: 如果证书有效返回 True，否则返回 False
        :rtype: bool
        :raises FileNotFoundError: 如果证书文件不存在
        :raises ValueError: 如果证书格式无效
        """
        is_expiring, details = SSLUtils.check_cert_expiry(cert_path, days=0)
        return not is_expiring

    @staticmethod
    def verify_cert_chain(cert_path: str, ca_bundle_path: str) -> bool:
        """
        验证证书链是否有效。

        :param cert_path: 证书文件的路径
        :type cert_path: str
        :param ca_bundle_path: CA 证书 bundle 的路径
        :type ca_bundle_path: str
        :return: 如果证书链有效返回 True，否则返回 False
        :rtype: bool
        :raises FileNotFoundError: 如果证书文件不存在
        """
        logger.info(f"开始验证证书链: {cert_path}，使用 CA bundle: {ca_bundle_path}")
        if not os.path.exists(cert_path):
            logger.error(f"证书文件不存在: {cert_path}")
            raise FileNotFoundError(f"证书文件不存在: {cert_path}")
        if not os.path.exists(ca_bundle_path):
            logger.error(f"CA bundle 文件不存在: {ca_bundle_path}")
            raise FileNotFoundError(f"CA bundle 文件不存在: {ca_bundle_path}")

        try:
            # 加载证书
            with open(cert_path, 'rb') as f:
                cert_content = f.read()
            cert = crypto.load_certificate(crypto.FILETYPE_PEM, cert_content)

            # 加载 CA bundle
            with open(ca_bundle_path, 'rb') as f:
                ca_bundle = f.read()

            # 创建证书存储
            store = crypto.X509Store()
            
            # 解析 CA bundle 中的证书
            ca_certs = ca_bundle.split(b'-----END CERTIFICATE-----')
            for ca_cert in ca_certs:
                ca_cert = ca_cert.strip()
                if ca_cert:
                    ca_cert = ca_cert + b'-----END CERTIFICATE-----'
                    try:
                        store.add_cert(crypto.load_certificate(crypto.FILETYPE_PEM, ca_cert))
                    except crypto.Error:
                        pass  # 跳过无效的证书

            # 创建证书上下文
            store_ctx = crypto.X509StoreContext(store, cert)
            
            # 验证证书
            store_ctx.verify_certificate()
            logger.info(f"证书链验证成功: {cert_path}")
            return True
        except crypto.X509StoreContextError:
            logger.warning(f"证书链验证失败: {cert_path}")
            return False
        except Exception as e:
            logger.error(f"验证证书链时发生错误: {str(e)}")
            return False