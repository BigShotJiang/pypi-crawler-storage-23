#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by：2022-07-28 16:17:47
modify by: 2026-03-01 11:00:00

功能描述：封装 ipaddress 库的函数，进行 IP 地址相关操作。
"""
import socket
import ipaddress
from typing import List, Optional, Union
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class IPAddressUtils:
    """IP 地址实用工具类，提供验证 IP 地址和网络地址有效性的方法。
    
    封装了 Python 标准库中的 ipaddress 模块，提供更便捷的 IP 地址验证、
    网络地址验证和本地 IP 地址获取功能。
    
    示例用法：
    >>> IPAddressUtils.is_valid_ip('192.168.1.1')
    True
    >>> IPAddressUtils.get_internal_ip()
    '192.168.1.100'
    """
    
    @staticmethod
    def _ip_network(network: str) -> ipaddress.IPv4Network | ipaddress.IPv6Network:
        """
        验证网络地址是否合法。
        
        :param network: 网络地址字符串（如 '192.168.1.0/24'）
        :type network: str
        :return: 合法的网络地址对象
        :rtype: Union[ipaddress.IPv4Network, ipaddress.IPv6Network]
        :raises ValueError: 如果网络地址无效
        """
        logger.info(f"开始验证网络地址: {network}")
        try:
            network_obj = ipaddress.ip_network(network)
            logger.info(f"网络地址验证成功: {network}")
            return network_obj
        except ValueError as e:
            logger.error(f"网络地址验证失败: {network}, 错误: {e}")
            raise ValueError(f"Invalid network address '{network}': {e}")

    @staticmethod
    def _ip_address(address: str) -> ipaddress.IPv4Address | ipaddress.IPv6Address:
        """
        验证 IP 地址是否合法。
        
        :param address: IP 地址字符串（如 '192.168.1.1'）
        :type address: str
        :return: 合法的 IP 地址对象
        :rtype: Union[ipaddress.IPv4Address, ipaddress.IPv6Address]
        :raises ValueError: 如果 IP 地址无效
        """
        logger.info(f"开始验证 IP 地址: {address}")
        try:
            address_obj = ipaddress.ip_address(address)
            logger.info(f"IP 地址验证成功: {address}")
            return address_obj
        except ValueError as e:
            logger.error(f"IP 地址验证失败: {address}, 错误: {e}")
            raise ValueError(f"Invalid IP address '{address}': {e}")

    @staticmethod
    def is_valid_ip(address: str) -> bool:
        """
        检查 IP 地址是否有效。

        :param address: 要检查的 IP 地址字符串
        :type address: str
        :return: 如果 IP 地址有效，返回 True，否则返回 False
        :rtype: bool
        """
        try:
            IPAddressUtils._ip_address(address)
            return True
        except ValueError:
            return False

    @staticmethod
    def is_valid_network(network: str) -> bool:
        """
        检查网络地址是否有效。

        :param network: 要检查的网络地址字符串（如 '192.168.1.0/24'）
        :type network: str
        :return: 如果网络地址有效，返回 True，否则返回 False
        :rtype: bool
        """
        try:
            IPAddressUtils._ip_network(network)
            return True
        except ValueError:
            return False

    @staticmethod
    def check_ip_in_network(address: str, network: str) -> bool:
        """
        检查 IP 地址是否在指定网络中。

        :param address: 要检查的 IP 地址字符串
        :type address: str
        :param network: 网络地址字符串（如 '192.168.1.0/24'）
        :type network: str
        :return: 如果 IP 地址在网络中，返回 True，否则返回 False
        :rtype: bool
        :raises ValueError: 如果 IP 地址或网络地址无效
        """
        logger.info(f"开始检查 IP 地址: {address} 是否在网络 {network} 中")
        valid_address = IPAddressUtils._ip_address(address)
        valid_network = IPAddressUtils._ip_network(network)
        result = valid_address in valid_network
        logger.info(f"IP 地址 {address} {'在' if result else '不在'} 网络 {network} 中")
        return result

    @staticmethod
    def check_ip_in_networks(address: str, network_list: Optional[List[str]] = None) -> bool:
        """
        验证给定的 IP 地址是否属于指定的网络地址列表中的任意一个。

        :param address: 要验证的 IP 地址字符串
        :type address: str
        :param network_list: 网络地址字符串列表，默认值为 None
        :type network_list: Optional[List[str]]
        :return: 如果 IP 地址属于网络列表中的任意网络，返回 True，否则返回 False
        :rtype: bool
        :raises ValueError: 如果 IP 地址或网络地址无效
        """
        logger.info(f"开始检查 IP 地址: {address} 是否在网络列表中")
        if not network_list:
            logger.info("网络列表为空，返回 False")
            return False
            
        valid_address = IPAddressUtils._ip_address(address)
        
        for network_str in network_list:
            network = IPAddressUtils._ip_network(network_str)
            if valid_address in network:
                logger.info(f"IP 地址 {address} 在网络 {network_str} 中")
                return True
        logger.info(f"IP 地址 {address} 不在任何指定网络中")
        return False

    @staticmethod
    def get_internal_ip() -> str:
        """
        获取本地内网 IP 地址。

        :return: 本地内网 IP 地址字符串
        :rtype: str
        :raises RuntimeError: 如果无法获取内网 IP 地址
        """
        logger.info("开始获取本地内网 IP 地址")
        # 使用 UDP 协议获取内网 IP，不会实际发送数据
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                # 连接到一个公共 IP 地址（不会实际建立连接）
                s.connect(('10.255.255.255', 1))
                internal_ip = s.getsockname()[0]
            logger.info(f"获取本地内网 IP 地址成功: {internal_ip}")
            return internal_ip
        except Exception as e:
            logger.error(f"获取本地内网 IP 地址失败: {e}")
            raise RuntimeError(f"无法获取内网IP地址: {e}")

    @staticmethod
    def get_external_ip() -> str:
        """
        获取公网 IP 地址。

        :return: 公网 IP 地址字符串
        :rtype: str
        :raises RuntimeError: 如果无法获取公网 IP 地址
        """
        logger.info("开始获取公网 IP 地址")
        try:
            # 使用第三方服务获取公网 IP
            import httpx
            with httpx.Client(timeout=10.0) as client:
                response = client.get('https://api.ipify.org')
                response.raise_for_status()
                external_ip = response.text.strip()
            logger.info(f"获取公网 IP 地址成功: {external_ip}")
            return external_ip
        except Exception as e:
            logger.error(f"获取公网 IP 地址失败: {e}")
            raise RuntimeError(f"无法获取公网IP地址: {e}")

    @staticmethod
    def get_ip_version(address: str) -> int:
        """
        获取 IP 地址的版本（4 或 6）。

        :param address: IP 地址字符串
        :type address: str
        :return: IP 地址版本（4 或 6）
        :rtype: int
        :raises ValueError: 如果 IP 地址无效
        """
        addr = IPAddressUtils._ip_address(address)
        if isinstance(addr, ipaddress.IPv4Address):
            return 4
        elif isinstance(addr, ipaddress.IPv6Address):
            return 6
        else:
            raise ValueError(f"Unknown IP address type: {type(addr)}")
