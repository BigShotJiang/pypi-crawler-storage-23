#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by：2024-03-06
modify by: 2026-03-01 11:00:00

功能：MAC地址相关的基础方法
"""

import re
import random
from typing import Optional
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class MacUtils:
    """
    MAC 地址处理工具类，提供 MAC 地址验证、标准化和生成功能。
    
    支持常见的 MAC 地址格式：
    - 00:11:22:33:44:55（冒号分隔）
    - 00-11-22-33-44-55（连字符分隔）
    - 001122334455（无分隔符）
    
    示例用法：
    >>> MacUtils.is_valid_mac('00:11:22:33:44:55')
    True
    >>> MacUtils.standardize_mac('001122334455')
    '00:11:22:33:44:55'
    >>> MacUtils.generate_random_mac()
    '00:11:22:33:44:55'
    """
    
    @staticmethod
    def standardize_mac(mac: str) -> str:
        """
        将 MAC 地址标准化为冒号分隔的大写格式。
        
        :param mac: MAC 地址字符串
        :type mac: str
        :return: 标准化后的 MAC 地址（如：00:11:22:33:44:55）
        :rtype: str
        :raises ValueError: 如果 MAC 地址无效
        """
        logger.info(f"开始标准化 MAC 地址: {mac}")
        try:
            # 移除所有非十六进制字符进行清洗
            sanitized_mac = re.sub(r'[^0-9A-Fa-f]', '', mac)
            
            if len(sanitized_mac) != 12:
                logger.error(f"MAC 地址长度无效: {mac}")
                raise ValueError(f"Invalid MAC address length: {mac}")
            
            # 将 MAC 地址格式化为冒号分隔的格式
            colon_separated_mac = ':'.join(sanitized_mac[i:i+2] for i in range(0, 12, 2))
            
            # 转换为大写
            standardized_mac = colon_separated_mac.upper()
            logger.info(f"MAC 地址标准化成功: {standardized_mac}")
            return standardized_mac
        except Exception as e:
            logger.error(f"处理 MAC 地址失败: {mac}, 错误: {e}")
            raise ValueError(f"Error processing MAC address '{mac}': {e}")

    @staticmethod
    def is_valid_mac(mac: str) -> bool:
        """
        验证 MAC 地址是否有效。
        
        支持的格式：
        - 00:11:22:33:44:55（冒号分隔）
        - 00-11-22-33-44-55（连字符分隔）
        - 001122334455（无分隔符）
        
        :param mac: MAC 地址字符串
        :type mac: str
        :return: 如果 MAC 地址有效返回 True，否则返回 False
        :rtype: bool
        """
        logger.info(f"开始验证 MAC 地址: {mac}")
        # 删除 MAC 地址字符串前后的空格
        mac = mac.strip()
        
        # 支持无分隔符、冒号分隔和连字符分隔的 MAC 地址格式
        patterns = [
            r'^[0-9A-Fa-f]{12}$',  # 无分隔符：001122334455
            r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$',  # 冒号分隔：00:11:22:33:44:55
            r'^([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}$'   # 连字符分隔：00-11-22-33-44-55
        ]
        
        for pattern in patterns:
            if re.match(pattern, mac):
                logger.info(f"MAC 地址验证成功: {mac}")
                return True
        logger.info(f"MAC 地址验证失败: {mac}")
        return False

    @staticmethod
    def generate_random_mac() -> str:
        """
        生成随机 MAC 地址。
        
        :return: 随机生成的 MAC 地址（如：00:11:22:33:44:55）
        :rtype: str
        """
        logger.info("开始生成随机 MAC 地址")
        # 生成 6 个随机字节
        mac_bytes = [random.randint(0, 255) for _ in range(6)]
        # 确保 MAC 地址是本地管理的（第二个字节的第二位为 1）
        mac_bytes[0] &= 0xFE
        mac_bytes[0] |= 0x02
        # 格式化为冒号分隔的大写格式
        mac = ':'.join(f'{b:02X}' for b in mac_bytes)
        logger.info(f"随机 MAC 地址生成成功: {mac}")
        return mac

    @staticmethod
    def format_mac(mac: str, separator: str = ':') -> str:
        """
        格式化 MAC 地址为指定分隔符的格式。
        
        :param mac: MAC 地址字符串
        :type mac: str
        :param separator: 分隔符，默认为冒号
        :type separator: str
        :return: 格式化后的 MAC 地址
        :rtype: str
        :raises ValueError: 如果 MAC 地址无效
        """
        logger.info(f"开始格式化 MAC 地址: {mac}，使用分隔符: {separator}")
        # 先标准化 MAC 地址
        standardized_mac = MacUtils.standardize_mac(mac)
        # 替换分隔符
        formatted_mac = standardized_mac.replace(':', separator)
        logger.info(f"MAC 地址格式化成功: {formatted_mac}")
        return formatted_mac

    @staticmethod
    def get_oui(mac: str) -> str:
        """
        获取 MAC 地址的组织唯一标识符（OUI）。
        
        :param mac: MAC 地址字符串
        :type mac: str
        :return: OUI 部分（前 6 个字符）
        :rtype: str
        :raises ValueError: 如果 MAC 地址无效
        """
        logger.info(f"开始获取 MAC 地址的 OUI: {mac}")
        standardized_mac = MacUtils.standardize_mac(mac)
        oui = standardized_mac[:8]  # 前 8 个字符，包括冒号
        logger.info(f"MAC 地址 OUI 获取成功: {oui}")
        return oui

    @staticmethod
    def is_multicast(mac: str) -> bool:
        """
        检查 MAC 地址是否为多播地址。
        
        :param mac: MAC 地址字符串
        :type mac: str
        :return: 如果是多播地址返回 True，否则返回 False
        :rtype: bool
        :raises ValueError: 如果 MAC 地址无效
        """
        logger.info(f"开始检查 MAC 地址是否为多播地址: {mac}")
        standardized_mac = MacUtils.standardize_mac(mac)
        # 第一个字节的最低位为 1 表示多播地址
        first_byte = int(standardized_mac[:2], 16)
        is_multicast = (first_byte & 0x01) == 0x01
        logger.info(f"MAC 地址 {mac} {'是' if is_multicast else '不是'} 多播地址")
        return is_multicast

    @staticmethod
    def is_unicast(mac: str) -> bool:
        """
        检查 MAC 地址是否为单播地址。
        
        :param mac: MAC 地址字符串
        :type mac: str
        :return: 如果是单播地址返回 True，否则返回 False
        :rtype: bool
        :raises ValueError: 如果 MAC 地址无效
        """
        return not MacUtils.is_multicast(mac)