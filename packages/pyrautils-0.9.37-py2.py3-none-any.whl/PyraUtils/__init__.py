"""
Top-level package for PyraUtils.

PyraUtils is a comprehensive utility library for Python, providing a wide range of
practical tools for common tasks such as file operations, HTTP requests, logging,
password handling, and more.

Example usage:
    >>> from PyraUtils import FileUtils
    >>> FileUtils.get_file_size('example.txt')
    1024

    >>> from PyraUtils import HttpxBasicUtil
    >>> response = HttpxBasicUtil.httpx_get('https://example.com')

    >>> from PyraUtils import LoguruHandler
    >>> logger = LoguruHandler()
    >>> logger.info('Hello, PyraUtils!')
"""

__author__ = "PyraUtils"
__email__ = 'ops@920430.com'
__version__ = '0.9.37'

# 导入常用模块
from PyraUtils.log import LoguruHandler, LoggingHandler, LoggingFileHandler
from PyraUtils.http import JWT, JWTDecorator, HttpxBasicUtil, HttpxClientUtil
from PyraUtils.common import FileUtils, ZipFilesUtils, JsonUtils, TimeUtils, StringsUtils, DataUtils
from PyraUtils.password import (
    PasswordMaker, PasswordStrength, PasswordPolicy, 
    hash_password, verify_password, 
    generate_totp_secret, generate_totp_qr_code, verify_totp_code
)

__all__ = [
    # Logging
    'LoguruHandler', 'LoggingHandler', 'LoggingFileHandler',
    # HTTP
    'JWT', 'JWTDecorator', 'HttpxBasicUtil', 'HttpxClientUtil',
    # Common
    'FileUtils', 'ZipFilesUtils', 'JsonUtils', 'TimeUtils', 'StringsUtils', 'DataUtils',
    # Password
    'PasswordMaker', 'PasswordStrength', 'PasswordPolicy', 
    'hash_password', 'verify_password', 
    'generate_totp_secret', 'generate_totp_qr_code', 'verify_totp_code'
]

# 版本信息
VERSION = __version__

# 模块别名，提高兼容性
try:
    # 尝试导入其他模块，确保兼容性
    from PyraUtils.network import IPAddressUtils, MacUtils, SSLUtils
    from PyraUtils.signature import HashUtils, HMACUtils, SignatureUtils
    
    __all__.extend([
        'IPAddressUtils', 'MacUtils', 'SSLUtils',
        'HashUtils', 'HMACUtils', 'SignatureUtils'
    ])
except ImportError:
    # 如果导入失败，不影响主功能
    pass
