"""Planner audits, conventions and schemas."""
