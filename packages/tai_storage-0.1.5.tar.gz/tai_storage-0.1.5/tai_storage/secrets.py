"""
Gestión de secretos y credenciales desde variables de entorno.
"""
import os
from typing import Optional

from tai_alphi import Alphi
from tai_storage.exceptions import SecretNotFoundError

logger = Alphi.get_logger_by_name('tai-storage')


class SecretManager:
    """
    Gestiona la obtención de secretos desde valores directos
    o variables de entorno.
    """
    
    @staticmethod
    def get_secret(
        value: Optional[str] = None,
        env_var: Optional[str] = None,
        required: bool = True
    ) -> Optional[str]:
        """
        Obtiene un secreto priorizando el valor directo sobre la variable de entorno.
        
        Args:
            value: Valor directo del secreto
            env_var: Nombre de la variable de entorno
            required: Si True, lanza excepción si no se encuentra el secreto
            
        Returns:
            El secreto encontrado o None si no es requerido
            
        Raises:
            SecretNotFoundError: Si el secreto es requerido y no se encuentra
            
        Examples:
            >>> SecretManager.get_secret(value='mi_clave')
            'mi_clave'
            
            >>> os.environ['API_KEY'] = 'clave123'
            >>> SecretManager.get_secret(env_var='API_KEY')
            'clave123'
            
            >>> SecretManager.get_secret(value='directo', env_var='VAR')
            'directo'  # Prioriza valor directo
        """
        # Prioridad 1: valor directo
        if value is not None:
            logger.debug(f"Secret obtained from direct value")
            return value
        
        # Prioridad 2: variable de entorno
        if env_var is not None:
            secret = os.getenv(env_var)
            if secret is not None:
                logger.debug(f"Secret obtained from environment variable: {env_var}")
                return secret
            else:
                logger.warning(f"Environment variable not found: {env_var}")
        
        # No encontrado
        if required:
            error_msg = f"Secret not found. Provide either 'value' or set '{env_var}' environment variable"
            logger.error(error_msg)
            raise SecretNotFoundError(error_msg)
        
        logger.debug("Optional secret not found, returning None")
        return None
    
    @staticmethod
    def get_multiple(secrets_config: dict) -> dict:
        """
        Obtiene múltiples secretos de una vez.
        
        Args:
            secrets_config: Dict con configuración de secretos
                {
                    'account_name': {'value': None, 'env_var': 'AZURE_ACCOUNT', 'required': True},
                    'account_key': {'value': 'key123', 'env_var': None, 'required': True}
                }
                
        Returns:
            Dict con los secretos obtenidos
            
        Example:
            >>> config = {
            ...     'user': {'env_var': 'DB_USER'},
            ...     'password': {'env_var': 'DB_PASS'}
            ... }
            >>> SecretManager.get_multiple(config)
            {'user': 'admin', 'password': 'secret123'}
        """
        logger.debug(f"Obtaining {len(secrets_config)} secrets")
        return {
            key: SecretManager.get_secret(**config)
            for key, config in secrets_config.items()
        }
