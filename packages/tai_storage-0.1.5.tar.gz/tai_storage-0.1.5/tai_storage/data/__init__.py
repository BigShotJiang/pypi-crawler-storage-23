"""
tai-storage data module: Transformaciones de archivos a DataFrames.

Este módulo proporciona funcionalidades para convertir archivos (CSV, Excel, Parquet, etc.)
a pandas DataFrames con inferencia automática de tipos.

Requiere instalación de dependencias adicionales:
    pip install tai-storage[data]

Ejemplo:
    >>> from tai_storage import LocalOrigin
    >>> 
    >>> origin = LocalOrigin(root_path='/data')
    >>> file = origin.get_folder('reports').get_file('data.xlsx')
    >>> 
    >>> # Usar get_data() para obtener reader
    >>> df = file.get_data().to_dataframe(sheet_name='Ventas', infer_types=True)
    >>> 
    >>> # Métodos específicos
    >>> df = file.get_data().to_csv(sep=';')
    >>> df = file.get_data().to_excel(sheet_name='Ventas')
"""

__all__ = [
    'CSVReader',
    'ExcelReader',
    'ParquetReader',
    'JSONReader',
    'FileDataReader',
    'TypeInferencer',
    'normalizar_texto',
    'infer_and_convert_dataframe',
]

from .readers import CSVReader, ExcelReader, ParquetReader, JSONReader
from .file_reader import FileDataReader
from .types import TypeInferencer, infer_and_convert_dataframe
from .transformers import normalizar_texto
