"""
Implementación de tai-storage para sistema de archivos local.
"""
from tai_storage.implementations.local.origin import LocalOrigin
from tai_storage.implementations.local.folder import LocalFolder
from tai_storage.implementations.local.file import LocalFile

__all__ = ['LocalOrigin', 'LocalFolder', 'LocalFile']
