"""
Clases base abstractas de tai-storage.
"""
from tai_storage.base.origin import Origin
from tai_storage.base.folder import Folder
from tai_storage.base.file import File

__all__ = ['Origin', 'Folder', 'File']
