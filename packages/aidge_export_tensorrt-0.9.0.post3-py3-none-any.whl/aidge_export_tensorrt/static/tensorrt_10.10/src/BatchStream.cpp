#include "BatchStream.hpp"
#include "Utils.hpp"
#include <cstdlib>
#include <fstream>
#include <iostream>

bool BatchStream::update()
{
    std::string inputFileName =
        _prefix + std::to_string(_fileCount++) + ".batch";
    std::ifstream file(inputFileName, std::ios_base::in);

    if (!file.is_open())
        gLogger.log(
            LogSeverity::kERROR,
            ("Could not open calibration file " + inputFileName).c_str());
    for (std::size_t i = 0; i < _imageSize; ++i) {
        if (file.eof()) {
            gLogger.log(LogSeverity::kERROR,
                        "Error: Unexpected end of file. Wrong input size.");
            std::exit(EXIT_FAILURE);
        }
        file >> _fileBatch[i];
    }
    _fileBatchPos = 0;

    file.close();
    return true;
}
