#include "Utils.hpp"
#include <iostream>

int Logger::severityToInt(Severity severity) noexcept
{
    switch (severity) {
    case Severity::kINTERNAL_ERROR:
        return 0;
    case Severity::kERROR:
        return 1;
    case Severity::kWARNING:
        return 2;
    case Severity::kINFO:
        return 3;
    case Severity::kVERBOSE:
    default:
        return 4;
    }
}

void Logger::log(Severity severity, const char *msg) noexcept
{
    if (severityToInt(severity) > mMinSeverityInt) {
        return;
    }
    switch (severity) {
    case Severity::kINTERNAL_ERROR:
        std::cerr << "INTERNAL_ERROR: ";
        break;
    case Severity::kERROR:
        std::cerr << "ERROR: ";
        break;
    case Severity::kWARNING:
        std::cerr << "WARNING: ";
        break;
    case Severity::kINFO:
        std::cerr << "INFO: ";
        break;
    default:
        std::cerr << "VERBOSE: ";
        break;
    }
    std::cerr << msg << std::endl;
}

void Logger::setLogLevel(Severity minSeverity) noexcept
{
    mMinSeverity = minSeverity;
    mMinSeverityInt = severityToInt(minSeverity);
}

bool cudaSupportsDataType(nvinfer1::DataType dataType)
{
    int deviceId;
    cudaError_t status = cudaGetDevice(&deviceId);
    if (status != cudaSuccess) {
        gLogger.log(LogSeverity::kERROR,
                    ("Failed to get CUDA device: " +
                     std::string(cudaGetErrorString(status)))
                        .c_str());
        return false;
    }

    cudaDeviceProp deviceProp;
    status = cudaGetDeviceProperties(&deviceProp, deviceId);
    if (status != cudaSuccess) {
        gLogger.log(LogSeverity::kERROR,
                    ("Failed to get device properties: " +
                     std::string(cudaGetErrorString(status)))
                        .c_str());
        return false;
    }

    int major = deviceProp.major;
    int minor = deviceProp.minor;
    float computeCapability = major + minor * 0.1f;

    switch (dataType) {
    case nvinfer1::DataType::kFLOAT:
        // FP32 supported on all SM 7.5+
        return computeCapability >= 7.5f;

    case nvinfer1::DataType::kHALF:
        // FP16 supported on all SM 7.5+
        return computeCapability >= 7.5f;

    case nvinfer1::DataType::kINT8:
        // INT8 supported on all SM 7.5+
        return computeCapability >= 7.5f;

    case nvinfer1::DataType::kINT32:
        // INT32 supported on all SM 7.5+
        return computeCapability >= 7.5f;

    case nvinfer1::DataType::kBOOL:
        // BOOL supported on all SM 7.5+
        return computeCapability >= 7.5f;

    default:
        gLogger.log(LogSeverity::kERROR,
                    "Unknown data type in cudaSupportsDataType");
        return false;
    }
}
