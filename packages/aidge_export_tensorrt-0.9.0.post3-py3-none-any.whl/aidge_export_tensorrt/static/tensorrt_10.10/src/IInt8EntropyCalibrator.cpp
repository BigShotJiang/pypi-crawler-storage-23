#include "IInt8EntropyCalibrator.hpp"
#include <fstream>
#include <iterator>

const void *Int8EntropyCalibrator::readCalibrationCache(size_t &length) noexcept
{
    _calibrationCache.clear();
    std::ifstream input(calibrationTableName(), std::ios::binary);
    input >> std::noskipws;
    if (_readCache && input.good()) {
        std::copy(std::istream_iterator<char>(input),
                  std::istream_iterator<char>(),
                  std::back_inserter(_calibrationCache));
    }
    length = _calibrationCache.size();
    return length ? &_calibrationCache[0] : nullptr;
}

void Int8EntropyCalibrator::writeCalibrationCache(const void *cache,
                                                  size_t length) noexcept
{
    std::ofstream output(calibrationTableName(), std::ios::binary);
    output.write(reinterpret_cast<const char *>(cache), length);
}
