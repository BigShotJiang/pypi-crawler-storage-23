"""Example: Test multiple datatypes (FP32, FP16) profile and compare performance."""

import build.lib.aidge_trt as aidge_trt
from utils.table import print_models_table

model_path = "model.onnx"
nb_iterations = 10

# Set log level (optional)
# aidge_trt.set_log_level(aidge_trt.LogSeverity.INFO)

# Create models with different datatypes
# nb_bits: -32=FP32, -16=FP16, 8=INT8
models = {}

# FP32 (default, nb_bits=-32)
model_fp32 = aidge_trt.Graph(nb_bits=-32)
model_fp32.load(model_path)
# Uncomment if model has dynamic shapes or inputs
# model_fp32.set_input_profile([[1, 3, 224, 224]]) # adapt to your inputs dims
model_fp32.initialize()
model_fp32.profile(nb_iterations=nb_iterations)
models["FP32"] = model_fp32

# FP16 (nb_bits=-16)
model_fp16 = aidge_trt.Graph(filepath="", nb_bits=-16)
model_fp16.load(model_path)
# Uncomment if model has dynamic shapes or inputs
# model_fp16.set_input_profile([[1, 3, 224, 224]]) # adapt to your inputs dims
model_fp16.initialize()
model_fp16.profile(nb_iterations=nb_iterations)
models["FP16"] = model_fp16

# Print comparison table
print_models_table(models)
