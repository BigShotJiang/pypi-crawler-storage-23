#ifndef __AIDGE_TENSORRT_UTILS_HPP__
#define __AIDGE_TENSORRT_UTILS_HPP__

#include <NvInfer.h>
#include <algorithm>
#include <cuda_runtime.h>
#include <string>
#include <utility>
#include <vector>

#define DIV_UP(X, Y) ((X) / (Y) + ((X) % (Y) > 0))
#define CEIL_DIV(X, Y) (((X) + (Y)-1) / (Y))

struct Profiler : public nvinfer1::IProfiler
{
    typedef std::pair<std::string, float> Record;
    std::vector<Record> mProfile;
    unsigned int mIterations = 0;

    virtual void reportLayerTime(const char *layerName, float ms) noexcept
    {
        auto record =
            std::find_if(mProfile.begin(),
                         mProfile.end(),
                         [&](const Record &r) { return r.first == layerName; });
        if (record == mProfile.end())
            mProfile.push_back(std::make_pair(layerName, ms));
        else
            record->second += ms;
    }

    std::vector<Record> getProfile() const noexcept { return mProfile; }
    void setIterations(unsigned int iterations) noexcept
    {
        mIterations = iterations;
    }
    unsigned int getIterations() const noexcept { return mIterations; }

    void clear() noexcept { mProfile.clear(); }
    size_t size() const noexcept { return mProfile.size(); }
    bool empty() const noexcept { return mProfile.empty(); }
    virtual ~Profiler() = default;
};

class Logger : public nvinfer1::ILogger {
  public:
    Logger() : mMinSeverity(Severity::kINFO), mMinSeverityInt(3) {}

    void log(Severity severity, const char *msg) noexcept override;

    void setLogLevel(Severity minSeverity) noexcept;

    Severity getLogLevel() const noexcept { return mMinSeverity; }

  private:
    Severity mMinSeverity;
    int mMinSeverityInt;

    static int severityToInt(Severity severity) noexcept;
};

static Logger gLogger;

using LogSeverity = nvinfer1::ILogger::Severity;

inline void setLogLevel(LogSeverity minSeverity) noexcept
{
    gLogger.setLogLevel(minSeverity);
}

inline LogSeverity getLogLevel() noexcept { return gLogger.getLogLevel(); }

static bool endsWith(std::string const &str, std::string const &suffix)
{
    if (str.length() < suffix.length()) {
        return false;
    }
    return std::equal(suffix.rbegin(), suffix.rend(), str.rbegin());
}

static std::string removeSubstring(const std::string &input,
                                   const std::string &substringToRemove)
{
    std::string result = input;
    size_t pos = result.find(substringToRemove);

    if (pos != std::string::npos) {
        result.erase(pos, substringToRemove.length());
    }

    return result;
}

static std::string baseName(const std::string &filePath)
{
    const size_t slashPos = filePath.find_last_of("/\\");
    return (slashPos == std::string::npos) ? filePath
                                           : filePath.substr(slashPos + 1);
}

static size_t dataTypeToSize(nvinfer1::DataType dataType)
{
    switch ((int)dataType) {
    case int(nvinfer1::DataType::kFLOAT):
        return 4;
    case int(nvinfer1::DataType::kHALF):
        return 2;
    case int(nvinfer1::DataType::kINT8):
        return 1;
    case int(nvinfer1::DataType::kINT32):
        return 4;
    case int(nvinfer1::DataType::kBOOL):
        return 1;
    default:
        return 4;
    }
}

bool cudaSupportsDataType(nvinfer1::DataType dataType);

static bool cudaHasFastFp16()
{
    return cudaSupportsDataType(nvinfer1::DataType::kHALF);
}

static bool cudaHasFastInt8()
{
    return cudaSupportsDataType(nvinfer1::DataType::kINT8);
}

#endif // __AIDGE_TENSORRT_UTILS_HPP__