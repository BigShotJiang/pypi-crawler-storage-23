#ifndef __AIDGE_TENSORRT_IINT8_ENTROPY_CALIBRATOR_HPP__
#define __AIDGE_TENSORRT_IINT8_ENTROPY_CALIBRATOR_HPP__

#include "BatchStream.hpp"
#include "cuda_utils.h"
#include <NvInfer.h>
#include <algorithm>
#include <string>
#include <vector>

class Int8EntropyCalibrator : public nvinfer1::IInt8EntropyCalibrator2 {
  public:
    Int8EntropyCalibrator(BatchStream &stream,
                          int firstBatch,
                          std::string cacheName,
                          bool readCache = true)
        : _stream(stream),
          _calibrationCacheName(cacheName),
          _readCache(readCache)
    {
        nvinfer1::Dims dims = _stream.getDims();
        _inputCount =
            _stream.getBatchSize() * dims.d[1] * dims.d[2] * dims.d[3];
        CHECK_CUDA_STATUS(
            cudaMalloc(&_deviceInput, _inputCount * sizeof(float)));
        _stream.reset(firstBatch);
    }

    virtual ~Int8EntropyCalibrator()
    {
        CHECK_CUDA_STATUS(cudaFree(_deviceInput));
    }

    int getBatchSize() const noexcept override
    {
        return _stream.getBatchSize();
    }

    bool getBatch(void *bindings[],
                  const char *names[],
                  int nbBindings) noexcept override
    {
        if (!_stream.next()) {
            return false;
        }
        CHECK_CUDA_STATUS(cudaMemcpy(_deviceInput,
                                     _stream.getBatch(),
                                     _inputCount * sizeof(float),
                                     cudaMemcpyHostToDevice));
        bindings[0] = _deviceInput;
        return true;
    }

    const void *readCalibrationCache(size_t &length) noexcept override;

    virtual void writeCalibrationCache(const void *cache,
                                       size_t length) noexcept override;

  private:
    std::string calibrationTableName() { return _calibrationCacheName; }
    BatchStream _stream;
    size_t _inputCount;
    bool _readCache{true};
    std::string _calibrationCacheName;
    void *_deviceInput{nullptr};
    std::vector<char> _calibrationCache;
};

#endif // __AIDGE_TENSORRT_IINT8_ENTROPY_CALIBRATOR_HPP__
