"""Table utilities for displaying TensorRT model information and performance."""

from typing import Any

from rich.console import Console
from rich.table import Table


def print_models_table(models: dict[str, Any]) -> None:
    """Print a table with model names and latency.

    Args:
        models: Dictionary mapping model names to Graph objects, e.g., {"model1": Graph(), "model2": Graph()}
    """
    console = Console()

    if not models:
        console.print("[yellow]No models provided[/yellow]")
        return

    table = Table(title="Model Performance")
    table.add_column("Name", style="bold")
    table.add_column("Latency", justify="right")

    for name, model in models.items():
        latency = model.get_average_latency()
        latency_text = f"{latency:.3f} ms"
        table.add_row(name, latency_text)

    console.print(table)
