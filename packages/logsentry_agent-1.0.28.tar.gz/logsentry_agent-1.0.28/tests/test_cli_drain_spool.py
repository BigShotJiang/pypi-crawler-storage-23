import sqlite3
import sys
from pathlib import Path

import pytest
from logsentry_agent import cli
from logsentry_agent.http import SendResult
from logsentry_agent.spool import SpoolQueue


def _write_config(path: Path, *, spool_path: Path, state_path: Path) -> None:
    path.write_text(
        f'''
agent_id: "agent-123"
shared_secret: "secret-123"
endpoint: "http://localhost:8002/v1/ingest"
spool_path: "{spool_path}"
state_path: "{state_path}"
sources:
  - windows_eventlog
'''.strip(),
        encoding="utf-8",
    )


@pytest.fixture(autouse=True)
def _isolate_env_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    env_path = tmp_path / "logsentry-agent.env"
    env_path.write_text("", encoding="utf-8")
    monkeypatch.setenv("LOGSENTRY_ENV_FILE", str(env_path))
    monkeypatch.delenv("LOGSENTRY_AGENT_ID", raising=False)
    monkeypatch.delenv("LOGSENTRY_AGENT_SECRET", raising=False)
    monkeypatch.delenv("LOGSENTRY_AGENT_SECRET_FILE", raising=False)
    monkeypatch.delenv("LOGSENTRY_ENDPOINT", raising=False)


def test_drain_spool_clear_spool_creates_backup_and_clears_rows(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
):
    config_path = tmp_path / "agent.yml"
    spool_path = tmp_path / "spool.db"
    state_path = tmp_path / "state.json"
    _write_config(config_path, spool_path=spool_path, state_path=state_path)

    spool = SpoolQueue(spool_path, max_mb=10)
    spool.enqueue({"events": [{"message": "cannot ingest"}]})
    assert spool.pending_count() == 1

    monkeypatch.setattr(
        sys,
        "argv",
        ["logsentry-agent", "--config", str(config_path), "drain-spool", "--clear-spool"],
    )

    with pytest.raises(SystemExit) as exc:
        cli.main()

    assert exc.value.code == 0
    output = capsys.readouterr().out
    assert "Spool backed up to:" in output
    assert "Spool cleared." in output

    assert spool.pending_count() == 0
    backups = list(tmp_path.glob("spool.db.bak-*"))
    assert len(backups) == 1
    with sqlite3.connect(backups[0]) as conn:
        row = conn.execute("SELECT COUNT(*) FROM spool").fetchone()
    assert row is not None
    assert row[0] == 1


def test_drain_spool_handles_keyboard_interrupt_and_preserves_remaining_rows(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
):
    config_path = tmp_path / "agent.yml"
    spool_path = tmp_path / "spool.db"
    state_path = tmp_path / "state.json"
    _write_config(config_path, spool_path=spool_path, state_path=state_path)

    spool = SpoolQueue(spool_path, max_mb=10)
    spool.enqueue({"events": [{"message": "first"}]})
    spool.enqueue({"events": [{"message": "second"}]})
    assert spool.pending_count() == 2

    calls = {"count": 0}

    def fake_send_spool_payload(*, payload, config, spool):
        calls["count"] += 1
        if calls["count"] == 1:
            return SendResult(status="ok"), 1, True
        raise KeyboardInterrupt

    monkeypatch.setattr(cli, "_send_spool_payload", fake_send_spool_payload)
    monkeypatch.setattr(
        sys,
        "argv",
        ["logsentry-agent", "--config", str(config_path), "drain-spool"],
    )

    with pytest.raises(SystemExit) as exc:
        cli.main()

    assert exc.value.code == 130
    output = capsys.readouterr().out
    assert "Drain interrupted by user; kept remaining spool items." in output
    assert spool.pending_count() == 1
