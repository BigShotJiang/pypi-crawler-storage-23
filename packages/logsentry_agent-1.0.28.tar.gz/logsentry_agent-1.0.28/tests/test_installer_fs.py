from logsentry_agent.installer import fs


def test_group_exists_returns_false_when_grp_unavailable(monkeypatch):
    monkeypatch.setattr(fs, "grp", None)
    assert fs.group_exists("any-group") is False


def test_user_exists_returns_false_when_pwd_unavailable(monkeypatch):
    monkeypatch.setattr(fs, "pwd", None)
    assert fs.user_exists("any-user") is False
