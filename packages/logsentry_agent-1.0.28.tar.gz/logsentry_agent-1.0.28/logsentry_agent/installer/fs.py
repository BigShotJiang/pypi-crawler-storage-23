from __future__ import annotations

try:
    import grp
except ModuleNotFoundError:  # pragma: no cover - Windows
    grp = None

try:
    import pwd
except ModuleNotFoundError:  # pragma: no cover - Windows
    pwd = None


def group_exists(name: str) -> bool:
    if grp is None:
        return False
    try:
        grp.getgrnam(name)
        return True
    except KeyError:
        return False


def user_exists(name: str) -> bool:
    if pwd is None:
        return False
    try:
        pwd.getpwnam(name)
        return True
    except KeyError:
        return False
