from __future__ import annotations

from logsentry_agent.normalize import apply_graceful_degradation
from logsentry_agent.utils.timeparse import now_utc_iso


def build_health_event(metrics: dict, *, severity: str = "low", details: str | None = None) -> dict:
    event = {
        "source": "agent",
        "category": "system",
        "action": "agent.health",
        "severity": severity,
        "timestamp": now_utc_iso(),
        "metrics": metrics,
    }
    if details:
        event["details"] = details
    return apply_graceful_degradation(event, parser="agent_health_v1", confidence=1.0)
