from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Iterable
from zoneinfo import ZoneInfo

COMMON_TIME_FORMATS: tuple[str, ...] = (
    "%d/%b/%Y:%H:%M:%S %z",  # Apache/Nginx
    "%Y-%m-%dT%H:%M:%S%z",  # ISO8601/RFC3339
    "%Y-%m-%d %H:%M:%S%z",
)

SYSLOG_TIME_FORMAT = "%b %d %H:%M:%S"
NOW_OVERRIDE: str | None = None
DEFAULT_TIMEZONE = timezone.utc


def resolve_timezone(value: str | None) -> timezone.tzinfo:
    if not value:
        return timezone.utc
    normalized = value.strip()
    if not normalized or normalized.upper() == "UTC":
        return timezone.utc
    try:
        return ZoneInfo(normalized)
    except Exception:
        return timezone.utc


def set_default_timezone(value: str | None) -> None:
    global DEFAULT_TIMEZONE
    DEFAULT_TIMEZONE = resolve_timezone(value)


def default_timezone() -> timezone.tzinfo:
    return DEFAULT_TIMEZONE


def now_in_timezone(now: datetime | None = None) -> datetime:
    current = now or datetime.now(DEFAULT_TIMEZONE)
    if current.tzinfo is None:
        current = current.replace(tzinfo=DEFAULT_TIMEZONE)
    return current.astimezone(DEFAULT_TIMEZONE)


def format_timestamp(value: datetime) -> str:
    localized = value.astimezone(DEFAULT_TIMEZONE)
    if localized.utcoffset() == timedelta(0):
        return localized.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return localized.isoformat()


def _parse_with_formats(value: str, formats: Iterable[str]) -> datetime | None:
    for fmt in formats:
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


def parse_timestamp(
    value: str | None,
    warnings: list[str] | None = None,
    *,
    now: datetime | None = None,
) -> str | None:
    if not value:
        if warnings is not None:
            warnings.append("missing timestamp")
        return None
    raw = value.strip()
    if not raw:
        if warnings is not None:
            warnings.append("empty timestamp")
        return None
    normalized = raw.replace("Z", "+00:00") if raw.endswith("Z") else raw
    parsed = None
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        parsed = _parse_with_formats(normalized, COMMON_TIME_FORMATS)
    if parsed is None:
        try:
            parsed = datetime.strptime(normalized, SYSLOG_TIME_FORMAT)
            now = now or now_in_timezone()
            parsed = parsed.replace(year=now.year, tzinfo=DEFAULT_TIMEZONE)
        except ValueError:
            parsed = None
    if parsed is None:
        if warnings is not None:
            warnings.append(f"unparsed timestamp: {raw}")
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=DEFAULT_TIMEZONE)
    return format_timestamp(parsed)


def now_utc_iso(now: datetime | None = None) -> str:
    if NOW_OVERRIDE is not None:
        return NOW_OVERRIDE
    current = now_in_timezone(now)
    return format_timestamp(current)
