"""Utility helpers for parsing and normalization."""
