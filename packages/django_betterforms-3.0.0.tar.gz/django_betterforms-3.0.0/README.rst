django-betterforms
------------------

.. image:: https://github.com/fusionbox/django-betterforms/actions/workflows/ci.yml/badge.svg
   :target: https://github.com/fusionbox/django-betterforms/actions/workflows/ci.yml
   :alt: Build Status

.. image:: https://coveralls.io/repos/fusionbox/django-betterforms/badge.png
   :target: http://coveralls.io/r/fusionbox/django-betterforms
   :alt: Build Status

`django-betterforms` builds on the built-in django forms.


Installation
============

1.  Install the package::

    $ pip install django-betterforms

2.  Add ``betterforms`` to your ``INSTALLED_APPS``.


