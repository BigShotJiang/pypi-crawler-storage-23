## 0.2.0 (2026-02-18)

### Feat

- clean cancellation on Ctrl+C with cooperative stop_event
- auto-detect account type instead of requiring --type flag
- expand progress to full width with stable column sizes
- add --gc flag to run git gc --aggressive before archiving

## 0.1.1 (2026-02-18)

## 0.1.0 (2026-02-18)

### Feat

- initial commit
