"""Entry point for python -m claudex"""

from claudex.cli import main

if __name__ == "__main__":
    main()
