# Improvement Proposals

Track proposed improvements to workflow, guidelines, and tooling.

## Format

| ID | Date | Proposal | Priority | Status |
|----|------|----------|----------|--------|

---

_No proposals yet._
