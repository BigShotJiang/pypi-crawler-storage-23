# Violations Log

Track all violations for pattern analysis and workflow improvement.

## Format

Each violation entry:
- Unique ID (V001, V002, ...)
- Date and severity
- Type, file, description
- Root cause and prevention

---

_No violations logged yet._
