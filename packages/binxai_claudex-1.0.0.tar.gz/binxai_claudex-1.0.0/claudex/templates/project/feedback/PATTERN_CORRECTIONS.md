# Pattern Corrections

Document common mistakes and their correct implementations.

## Format

### PC001 - [Date] - [Category]
**Mistake**: [what was done wrong]
**Correction**: [what should have been done]
**Prevention**: [how to prevent in future]

---

_No corrections logged yet._
