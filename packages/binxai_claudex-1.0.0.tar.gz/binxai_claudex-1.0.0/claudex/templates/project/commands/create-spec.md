# /create-spec — Alias for /new-spec

Create a new feature specification. This is an alias for `/new-spec`.

## Usage
```
/create-spec <feature-title>
```

See `/new-spec` for the full process.
