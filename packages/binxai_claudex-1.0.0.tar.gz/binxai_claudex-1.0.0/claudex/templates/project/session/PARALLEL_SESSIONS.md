# Parallel Sessions

> Coordination file for parallel Claude Code sessions. Max 5 concurrent.

## Active Sessions

| # | Branch | Worktree | File Ownership | GH Issue | Status |
|---|--------|----------|----------------|----------|--------|
| - | No active parallel sessions | - | - | - | - |

## Merge Order

1. (No sessions planned)

## Conflict Zones (DO NOT parallelize)

- (Define shared files that only one session may touch)

## Session History

| # | Branch | PR | Merged | Date |
|---|--------|----|--------|------|
| - | No history | - | - | - |
