# Context Summary

## Active Task
<!-- One-line summary of what's in progress -->

## Key Decisions
<!-- Architecture and approach decisions made this session -->
- <!-- Decision 1 -->

## Files Modified
<!-- Track touched files to avoid conflicts -->
- <!-- file path -->

## Open Questions
<!-- Unresolved ambiguities or blockers -->
- <!-- Question 1 -->

## Re-injection Prompt
<!--
Paste this block into a new session to restore context:

I was working on: [task title]
Branch: [branch name]
Last completed: [last step from TASK_PROGRESS.md]
Next action: [first item from Next Actions]
Key files: [list from Files Modified]
-->
