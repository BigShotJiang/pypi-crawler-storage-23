# Current Task

## Task
<!-- Brief task title -->

## GitHub Issue
<!-- Link or number, e.g. BinxAI/claudex #42 -->

## Goal
<!-- What success looks like -->

## Done Conditions
- [ ] <!-- Acceptance criterion 1 -->
- [ ] <!-- Acceptance criterion 2 -->

## Notes
<!-- Constraints, links, context -->

---
_Created: <!-- date --> | Updated: <!-- date -->_
