#!/usr/bin/env python3
import sys
import os
import re
import logging
import argparse
from typing import Optional, Any
from contextlib import asynccontextmanager

from pydantic_ai import Agent, ModelSettings, RunContext
from pydantic_ai.mcp import (
    load_mcp_servers,
    MCPServerStreamableHTTP,
    MCPServerSSE,
)
from pydantic_ai_skills import SkillsToolset
from pydantic_ai.ui.ag_ui import AGUIAdapter
from pydantic_ai.ui import SSE_CONTENT_TYPE

from fastapi import FastAPI, Request
from starlette.responses import Response, StreamingResponse
from pydantic import ValidationError
import uvicorn
import httpx

from jellyfin_mcp.utils import (
    to_integer,
    to_boolean,
    to_float,
    to_list,
    to_dict,
    get_mcp_config_path,
    get_skills_path,
    create_model,
    prune_large_messages,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

__version__ = "0.2.15"

AGENT_NAME = "JellyfinAgent"
AGENT_DESCRIPTION = (
    "An intelligent agent for managing and interacting with a Jellyfin media server."
)

DEFAULT_HOST = os.getenv("HOST", "0.0.0.0")
DEFAULT_PORT = to_integer(os.getenv("PORT", "9001"))
DEFAULT_DEBUG = to_boolean(os.getenv("DEBUG", "False"))
DEFAULT_PROVIDER = os.getenv("PROVIDER", "openai")
DEFAULT_MODEL_ID = os.getenv("MODEL_ID", "gpt-4o")
DEFAULT_LLM_BASE_URL = os.getenv("LLM_BASE_URL", None)
DEFAULT_LLM_API_KEY = os.getenv("LLM_API_KEY", None)
DEFAULT_MCP_URL = os.getenv("MCP_URL", None)
DEFAULT_MCP_CONFIG = os.getenv("MCP_CONFIG", get_mcp_config_path())
DEFAULT_CUSTOM_SKILLS_DIRECTORY = os.getenv("CUSTOM_SKILLS_DIRECTORY", None)
DEFAULT_ENABLE_WEB_UI = to_boolean(os.getenv("ENABLE_WEB_UI", "False"))
DEFAULT_SSL_VERIFY = to_boolean(os.getenv("SSL_VERIFY", "True"))

DEFAULT_MAX_TOKENS = to_integer(os.getenv("MAX_TOKENS", "16384"))
DEFAULT_TEMPERATURE = to_float(os.getenv("TEMPERATURE", "0.7"))
DEFAULT_TOP_P = to_float(os.getenv("TOP_P", "1.0"))
DEFAULT_TIMEOUT = to_float(os.getenv("TIMEOUT", "32400.0"))
DEFAULT_TOOL_TIMEOUT = to_float(os.getenv("TOOL_TIMEOUT", "32400.0"))
DEFAULT_PARALLEL_TOOL_CALLS = to_boolean(os.getenv("PARALLEL_TOOL_CALLS", "True"))
DEFAULT_SEED = to_integer(os.getenv("SEED", None))
DEFAULT_PRESENCE_PENALTY = to_float(os.getenv("PRESENCE_PENALTY", "0.0"))
DEFAULT_FREQUENCY_PENALTY = to_float(os.getenv("FREQUENCY_PENALTY", "0.0"))
DEFAULT_LOGIT_BIAS = to_dict(os.getenv("LOGIT_BIAS", None))
DEFAULT_STOP_SEQUENCES = to_list(os.getenv("STOP_SEQUENCES", None))
DEFAULT_EXTRA_HEADERS = to_dict(os.getenv("EXTRA_HEADERS", None))
DEFAULT_EXTRA_BODY = to_dict(os.getenv("EXTRA_BODY", None))

SUPERVISOR_SYSTEM_PROMPT = """You are the Jellyfin Supervisor Agent.
Your goal is to assist the user by assigning tasks to specialized child agents through your available toolset.
Analyze the user's request and determine which domain(s) it falls into (Media, System, User, LiveTV, Devices).
Then, call the appropriate tool(s) to delegate the task.
Synthesize the results from the child agents into a final helpful response.
Always be warm, professional, and helpful.
"""

MEDIA_AGENT_PROMPT = """You are the Jellyfin Media Agent.
Your goal is to manage and retrieve media content.
This includes: Movies, TV Shows, Music, Artists, Albums, Genres, Playlists, Libraries, Items, Images, Traversing folders, and Streaming information.
Use your tools to find media, list items, get details, and manage library metadata.
"""

SYSTEM_AGENT_PROMPT = """You are the Jellyfin System Agent.
Your goal is to manage server system tasks.
This includes: Server Configuration, Activity Logs, Backend System info, Scheduled Tasks, Plugins, Packages, API Keys, Backups, and Localization.
Use your tools to check server status, logs, and configuration.
"""

USER_AGENT_PROMPT = """You are the Jellyfin User Agent.
Your goal is to manage user-centric interaction.
This includes: User accounts, User libraries, Views, Sessions, Playback Status (Playstate), Suggestions, Search, and Display Preferences.
Use your tools to manage users and their session data.
"""

LIVETV_AGENT_PROMPT = """You are the Jellyfin LiveTV Agent.
Your goal is to manage Live TV functionality.
This includes: Channels, Tuners, Guide info (if available via tags), and Recordings.
Use your tools to list channels and access live TV features.
"""

DEVICE_AGENT_PROMPT = """You are the Jellyfin Device Agent.
Your goal is to manage connected devices.
This includes: Listing devices, Device options, SyncPlay, QuickConnect, and Remote Image handling.
Use your tools to manage client devices connected to the server.
"""


def create_agent(
    provider: str = DEFAULT_PROVIDER,
    model_id: str = DEFAULT_MODEL_ID,
    base_url: Optional[str] = DEFAULT_LLM_BASE_URL,
    api_key: Optional[str] = DEFAULT_LLM_API_KEY,
    mcp_url: str = DEFAULT_MCP_URL,
    mcp_config: str = DEFAULT_MCP_CONFIG,
    custom_skills_directory: Optional[str] = DEFAULT_CUSTOM_SKILLS_DIRECTORY,
    ssl_verify: bool = DEFAULT_SSL_VERIFY,
) -> Agent:

    logger.info("Initializing Jellyfin Agent System...")

    model = create_model(
        provider=provider,
        model_id=model_id,
        base_url=base_url,
        api_key=api_key,
        ssl_verify=ssl_verify,
        timeout=DEFAULT_TIMEOUT,
    )
    settings = ModelSettings(
        max_tokens=DEFAULT_MAX_TOKENS,
        temperature=DEFAULT_TEMPERATURE,
        top_p=DEFAULT_TOP_P,
        timeout=DEFAULT_TIMEOUT,
        parallel_tool_calls=DEFAULT_PARALLEL_TOOL_CALLS,
        seed=DEFAULT_SEED,
        presence_penalty=DEFAULT_PRESENCE_PENALTY,
        frequency_penalty=DEFAULT_FREQUENCY_PENALTY,
        logit_bias=DEFAULT_LOGIT_BIAS,
        stop_sequences=DEFAULT_STOP_SEQUENCES,
        extra_headers=DEFAULT_EXTRA_HEADERS,
        extra_body=DEFAULT_EXTRA_BODY,
    )

    agent_toolsets = []
    if mcp_url:
        if "sse" in mcp_url.lower():
            server = MCPServerSSE(
                mcp_url,
                http_client=httpx.AsyncClient(
                    verify=ssl_verify, timeout=DEFAULT_TIMEOUT
                ),
            )
        else:
            server = MCPServerStreamableHTTP(
                mcp_url,
                http_client=httpx.AsyncClient(
                    verify=ssl_verify, timeout=DEFAULT_TIMEOUT
                ),
            )
        agent_toolsets.append(server)
        logger.info(f"Connected to MCP Server: {mcp_url}")
    elif mcp_config:
        mcp_toolset = load_mcp_servers(mcp_config)
        for server in mcp_toolset:
            if hasattr(server, "http_client"):
                server.http_client = httpx.AsyncClient(
                    verify=ssl_verify, timeout=DEFAULT_TIMEOUT
                )
        agent_toolsets.extend(mcp_toolset)
        logger.info(f"Connected to MCP Config JSON: {mcp_toolset}")

    # Always load default skills

    skill_dirs = [get_skills_path()]

    if custom_skills_directory and os.path.exists(custom_skills_directory):

        skill_dirs.append(str(custom_skills_directory))

    agent_toolsets.append(SkillsToolset(directories=skill_dirs))

    agent_defs = {
        "media": (
            MEDIA_AGENT_PROMPT,
            "Jellyfin_Media_Agent",
            [
                "Artists",
                "Audio",
                "Collection",
                "Genres",
                "HlsSegment",
                "Image",
                "ItemLookup",
                "ItemRefresh",
                "ItemUpdate",
                "Items",
                "Library",
                "LibraryStructure",
                "Lyrics",
                "MediaInfo",
                "MediaSegments",
                "Movies",
                "MusicGenres",
                "Persons",
                "Playlists",
                "RemoteImage",
                "Studios",
                "Subtitle",
                "Trailers",
                "TvShows",
                "UniversalAudio",
                "VideoAttachments",
                "Videos",
                "Years",
                "DynamicHls",
            ],
        ),
        "system": (
            SYSTEM_AGENT_PROMPT,
            "Jellyfin_System_Agent",
            [
                "ActivityLog",
                "ApiKey",
                "Backup",
                "Branding",
                "ClientLog",
                "Configuration",
                "Dashboard",
                "Environment",
                "Filter",
                "Localization",
                "Package",
                "Plugins",
                "ScheduledTasks",
                "Startup",
                "System",
                "TimeSync",
                "Tmdb",
            ],
        ),
        "user": (
            USER_AGENT_PROMPT,
            "Jellyfin_User_Agent",
            [
                "InstantMix",
                "Playstate",
                "QuickConnect",
                "Search",
                "Session",
                "Suggestions",
                "SyncPlay",
                "Trickplay",
                "User",
                "UserLibrary",
                "UserViews",
                "DisplayPreferences",
            ],
        ),
        "livetv": (
            LIVETV_AGENT_PROMPT,
            "Jellyfin_LiveTV_Agent",
            ["Channels", "LiveTv"],
        ),
        "device": (DEVICE_AGENT_PROMPT, "Jellyfin_Device_Agent", ["Devices"]),
    }

    # 1. Identify Universal Skills
    # Universal skills are those in the skills directory that do NOT start with the package prefix
    package_prefix = "jellyfin-"
    skills_path = get_skills_path()
    universal_skill_dirs = []

    if os.path.exists(skills_path):
        for item in os.listdir(skills_path):
            item_path = os.path.join(skills_path, item)
            if os.path.isdir(item_path):
                if not item.startswith(package_prefix):
                    universal_skill_dirs.append(item_path)
                    logger.info(f"Identified universal skill: {item}")

    supervisor_skills = []
    child_agents = {}
    supervisor_skills_directories = [get_skills_path()]

    for tag_key, (system_prompt, agent_name, tags_list) in agent_defs.items():
        tag_toolsets = []
        for ts in agent_toolsets:

            def filter_func(ctx, tool_def, t_list=tags_list):
                if not tool_def.tags:
                    return False
                return any(t in tool_def.tags for t in t_list)

            if hasattr(ts, "filtered"):
                filtered_ts = ts.filtered(filter_func)
                tag_toolsets.append(filtered_ts)

        # Load specific skills for these tags
        for tag in tags_list:
            # Convert CamelCase to kebab-case for directory name
            # e.g. ActivityLog -> activity-log
            kebab_tag = re.sub(r"(?<!^)(?=[A-Z])", "-", tag).lower()
            skill_dir_name = f"jellyfin-{kebab_tag}"

            child_skills_directories = []

            # Check custom skills directory
            if custom_skills_directory:
                skill_dir_path = os.path.join(custom_skills_directory, skill_dir_name)
                if os.path.exists(skill_dir_path):
                    child_skills_directories.append(skill_dir_path)

            # Check default skills directory
            default_skill_path = os.path.join(get_skills_path(), skill_dir_name)
            if os.path.exists(default_skill_path):
                child_skills_directories.append(default_skill_path)

            # Append Universal Skills to ALL child agents
            if universal_skill_dirs:
                child_skills_directories.extend(universal_skill_dirs)

            if child_skills_directories:
                ts = SkillsToolset(directories=child_skills_directories)
                tag_toolsets.append(ts)

        agent = Agent(
            name=agent_name,
            system_prompt=system_prompt,
            model=model,
            model_settings=settings,
            toolsets=tag_toolsets,
            tool_timeout=DEFAULT_TOOL_TIMEOUT,
        )
        child_agents[tag_key] = agent

    # Create Custom Agent if custom_skills_directory is provided
    if custom_skills_directory:
        custom_agent_tag = "custom_agent"
        custom_agent_name = "Custom_Agent"
        custom_agent_prompt = (
            "You are the Custom Agent.\n"
            "Your goal is to handle custom tasks or general tasks not covered by other specialists.\n"
            "You have access to valid custom skills and universal skills."
        )

        custom_agent_skills_dirs = list(universal_skill_dirs)
        custom_agent_skills_dirs.append(custom_skills_directory)

        custom_toolsets = []
        custom_toolsets.append(SkillsToolset(directories=custom_agent_skills_dirs))

        custom_agent = Agent(
            name=custom_agent_name,
            system_prompt=custom_agent_prompt,
            model=model,
            model_settings=settings,
            toolsets=custom_toolsets,
            tool_timeout=DEFAULT_TOOL_TIMEOUT,
        )
        child_agents[custom_agent_tag] = custom_agent

    if custom_skills_directory:
        supervisor_skills_directories.append(custom_skills_directory)
    supervisor_skills.append(SkillsToolset(directories=supervisor_skills_directories))
    logger.info(f"Loaded supervisor skills from: {supervisor_skills_directories}")

    supervisor = Agent(
        name=AGENT_NAME,
        system_prompt=SUPERVISOR_SYSTEM_PROMPT,
        model=model,
        model_settings=settings,
        toolsets=supervisor_skills,
        deps_type=Any,
    )

    @supervisor.tool
    async def assign_to_media_agent(ctx: RunContext[Any], task: str) -> str:
        """Assign a media-related task to the Media Agent (Content, Library, Items)."""
        return (
            await child_agents["media"].run(task, usage=ctx.usage, deps=ctx.deps)
        ).output

    @supervisor.tool
    async def assign_to_system_agent(ctx: RunContext[Any], task: str) -> str:
        """Assign a system-related task to the System Agent (Config, Logs, System Info)."""
        return (
            await child_agents["system"].run(task, usage=ctx.usage, deps=ctx.deps)
        ).output

    @supervisor.tool
    async def assign_to_user_agent(ctx: RunContext[Any], task: str) -> str:
        """Assign a user-related task to the User Agent (Users, Sessions, Playback)."""
        return (
            await child_agents["user"].run(task, usage=ctx.usage, deps=ctx.deps)
        ).output

    @supervisor.tool
    async def assign_to_livetv_agent(ctx: RunContext[Any], task: str) -> str:
        """Assign a LiveTV-related task to the LiveTV Agent."""
        return (
            await child_agents["livetv"].run(task, usage=ctx.usage, deps=ctx.deps)
        ).output

    @supervisor.tool
    async def assign_to_device_agent(ctx: RunContext[Any], task: str) -> str:
        """Assign a device-related task to the Device Agent."""
        return (
            await child_agents["device"].run(task, usage=ctx.usage, deps=ctx.deps)
        ).output

    if "custom_agent" in child_agents:

        @supervisor.tool
        async def assign_task_to_custom_agent(ctx: RunContext[Any], task: str) -> str:
            """Assign a task to the Custom Agent."""
            return (
                await child_agents["custom_agent"]
                .run(task, usage=ctx.usage, deps=ctx.deps)
                .output
            )

    return supervisor


def create_agent_server(
    provider: str = DEFAULT_PROVIDER,
    model_id: str = DEFAULT_MODEL_ID,
    base_url: Optional[str] = DEFAULT_LLM_BASE_URL,
    api_key: Optional[str] = DEFAULT_LLM_API_KEY,
    mcp_url: str = DEFAULT_MCP_URL,
    mcp_config: str = DEFAULT_MCP_CONFIG,
    custom_skills_directory: Optional[str] = DEFAULT_CUSTOM_SKILLS_DIRECTORY,
    debug: bool = DEFAULT_DEBUG,
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
    enable_web_ui: bool = DEFAULT_ENABLE_WEB_UI,
    ssl_verify: bool = DEFAULT_SSL_VERIFY,
):
    print(
        f"Starting {AGENT_NAME}:"
        f"\tprovider={provider}"
        f"\tmodel={model_id}"
        f"\tbase_url={base_url}"
        f"\tmcp={mcp_url} | {mcp_config}"
        f"\tssl_verify={ssl_verify}"
    )
    agent = create_agent(
        provider=provider,
        model_id=model_id,
        base_url=base_url,
        api_key=api_key,
        mcp_url=mcp_url,
        mcp_config=mcp_config,
        custom_skills_directory=custom_skills_directory,
        ssl_verify=ssl_verify,
    )
    # Skills are loaded per-agent based on tags

    a2a_app = agent.to_a2a(
        name=AGENT_NAME,
        description=AGENT_DESCRIPTION,
        version=__version__,
        skills=[],
        debug=debug,
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if hasattr(a2a_app, "router") and hasattr(a2a_app.router, "lifespan_context"):
            async with a2a_app.router.lifespan_context(a2a_app):
                yield
        else:
            yield

    app = FastAPI(
        title=f"{AGENT_NAME} Server",
        description=AGENT_DESCRIPTION,
        debug=debug,
        lifespan=lifespan,
    )

    app.mount("/a2a", a2a_app)

    @app.post("/ag-ui")
    async def ag_ui_endpoint(request: Request) -> Response:
        accept = request.headers.get("accept", SSE_CONTENT_TYPE)
        try:
            run_input = AGUIAdapter.build_run_input(await request.body())
        except ValidationError as e:
            return Response(
                content=e.json(), media_type="application/json", status_code=422
            )

        if hasattr(run_input, "messages"):
            run_input.messages = prune_large_messages(run_input.messages)

        adapter = AGUIAdapter(agent=agent, run_input=run_input, accept=accept)
        return StreamingResponse(
            adapter.encode_stream(adapter.run_stream()), media_type=accept
        )

    if enable_web_ui:
        app.mount("/", agent.to_web(instructions=SUPERVISOR_SYSTEM_PROMPT))

    logger.info(f"Starting server on {host}:{port}")
    uvicorn.run(app, host=host, port=port)


def agent_server():
    print(f"Jellyfin Agent v{__version__}")
    parser = argparse.ArgumentParser(
        add_help=False, description=f"Run the {AGENT_NAME} A2A + AG-UI Server"
    )
    parser.add_argument(
        "--host", default=DEFAULT_HOST, help="Host to bind the server to"
    )
    parser.add_argument(
        "--port", type=int, default=DEFAULT_PORT, help="Port to bind the server to"
    )
    parser.add_argument("--debug", type=bool, default=DEFAULT_DEBUG, help="Debug mode")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")

    parser.add_argument(
        "--provider",
        default=DEFAULT_PROVIDER,
        choices=["openai", "anthropic", "google", "huggingface"],
        help="LLM Provider",
    )
    parser.add_argument("--model-id", default=DEFAULT_MODEL_ID, help="LLM Model ID")
    parser.add_argument(
        "--base-url",
        default=DEFAULT_LLM_BASE_URL,
        help="LLM Base URL (for OpenAI compatible providers)",
    )
    parser.add_argument("--api-key", default=DEFAULT_LLM_API_KEY, help="LLM API Key")
    parser.add_argument("--mcp-url", default=DEFAULT_MCP_URL, help="MCP Server URL")
    parser.add_argument(
        "--mcp-config", default=DEFAULT_MCP_CONFIG, help="MCP Server Config"
    )
    parser.add_argument(
        "--web",
        action="store_true",
        default=DEFAULT_ENABLE_WEB_UI,
        help="Enable Pydantic AI Web UI",
    )

    parser.add_argument(
        "--insecure",
        action="store_true",
        help="Disable SSL verification for LLM requests (Use with caution)",
    )
    parser.add_argument("--help", action="store_true", help="Show usage")

    args = parser.parse_args()

    if hasattr(args, "help") and args.help:

        parser.print_help()

        sys.exit(0)

    if args.debug:
        for handler in logging.root.handlers[:]:
            logging.root.removeHandler(handler)

        logging.basicConfig(
            level=logging.DEBUG,
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            handlers=[logging.StreamHandler()],
            force=True,
        )
        logging.getLogger("pydantic_ai").setLevel(logging.DEBUG)
        logging.getLogger("fastmcp").setLevel(logging.DEBUG)
        logging.getLogger("httpcore").setLevel(logging.DEBUG)
        logging.getLogger("httpx").setLevel(logging.DEBUG)
        logger.setLevel(logging.DEBUG)
        logger.debug("Debug mode enabled")

    create_agent_server(
        provider=args.provider,
        model_id=args.model_id,
        base_url=args.base_url,
        api_key=args.api_key,
        mcp_url=args.mcp_url,
        mcp_config=args.mcp_config,
        custom_skills_directory=args.custom_skills_directory,
        debug=args.debug,
        host=args.host,
        port=args.port,
        enable_web_ui=args.web,
        ssl_verify=not args.insecure,
    )


if __name__ == "__main__":
    agent_server()
