from ..imports import *
SOLANA_MINT = get_env_val("SOLANA_MINT") or '';
SOLANA_WS_ENDPOINT = get_env_val("SOLANA_MAINNET_)WS_ENDPOINT") or '';
SOLANA_RPC_URL = get_env_val("SOLANA_MAINNET_RPC_URL") or '';
ANKR_RPC_URL = get_env_val("SOLANA_FALLBACK_RPC_URL") or '';
ANKR_WS_ENDPOINT = get_env_val("SOLANA_FALLBACK_WS_ENDPOINT") or '';
PUMP_FUN_PROGRAMID = get_env_val("PUMP_FUN_PROGRAMID") or '6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P';
