"""Evaluation framework for retrieval quality."""
