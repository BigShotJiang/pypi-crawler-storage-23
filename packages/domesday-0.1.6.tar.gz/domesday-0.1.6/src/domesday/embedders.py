"""Embedder implementations.

Each class conforms to the Embedder protocol: a `dimension` property
and an `embed(texts)` method that returns vectors.
"""

from __future__ import annotations

import logging
from collections.abc import Sequence
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# Model → default dimension lookup
VOYAGE_DIMENSIONS: dict[str, int] = {
    "voyage-3-large": 1024,
    "voyage-3": 1024,
    "voyage-3-lite": 512,
    "voyage-code-3": 1024,
}

OPENAI_DIMENSIONS: dict[str, int] = {
    "text-embedding-3-large": 3072,
    "text-embedding-3-small": 1536,
    "text-embedding-ada-002": 1536,
}

# Max batch sizes per API
_VOYAGE_MAX_BATCH = 128
_OPENAI_MAX_BATCH = 2048


def _default_dimension(model: str, lookup: dict[str, int], fallback: int) -> int:
    return lookup.get(model, fallback)


@dataclass(frozen=True, slots=True)
class VoyageEmbedder:
    """Embedder using Voyage AI's embedding API.

    Requires: `pip install voyageai`
    Env: VOYAGE_API_KEY
    """

    model: str = "voyage-4-lite"
    dimension: int | None = None

    def _resolved_dimension(self) -> int:
        return self.dimension or _default_dimension(self.model, VOYAGE_DIMENSIONS, 1024)

    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        import voyageai

        client = voyageai.Client()
        all_embeddings: list[list[float]] = []

        # Batch to stay within API limits
        for i in range(0, len(texts), _VOYAGE_MAX_BATCH):
            batch = list(texts[i : i + _VOYAGE_MAX_BATCH])
            logger.debug(
                "Voyage embed batch %d–%d of %d texts (model=%s)",
                i,
                i + len(batch),
                len(texts),
                self.model,
            )
            result = client.embed(
                texts=batch,
                model=self.model,
                input_type="document",
            )
            all_embeddings.extend(result.embeddings)  # type: ignore[arg-type]

        logger.info(
            "Voyage embedded %d texts → %d vectors (dim=%d)",
            len(texts),
            len(all_embeddings),
            self._resolved_dimension(),
        )
        return all_embeddings


@dataclass(frozen=True, slots=True)
class OpenAIEmbedder:
    """Embedder using OpenAI's embedding API.

    Requires: `pip install openai`
    Env: OPENAI_API_KEY
    """

    model: str = "text-embedding-3-small"
    dimension: int | None = None

    def _resolved_dimension(self) -> int:
        return self.dimension or _default_dimension(self.model, OPENAI_DIMENSIONS, 1536)

    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        try:
            import openai
        except ImportError:
            raise ImportError(
                "OpenAI embedder requires the 'openai' package. "
                "Install with `uv add domesday[openai]` or choose a different embedder."
            )

        client = openai.OpenAI()
        all_embeddings: list[list[float]] = []

        for i in range(0, len(texts), _OPENAI_MAX_BATCH):
            batch = list(texts[i : i + _OPENAI_MAX_BATCH])
            logger.debug(
                "OpenAI embed batch %d–%d of %d texts (model=%s)",
                i,
                i + len(batch),
                len(texts),
                self.model,
            )
            response = client.embeddings.create(
                input=batch,
                model=self.model,
            )
            batch_embeddings = [item.embedding for item in response.data]
            all_embeddings.extend(batch_embeddings)

        logger.info(
            "OpenAI embedded %d texts → %d vectors (dim=%d)",
            len(texts),
            len(all_embeddings),
            self._resolved_dimension(),
        )
        return all_embeddings


class SentenceTransformerEmbedder:
    """Local embedder using sentence-transformers (runs on GPU if available).

    Requires: `pip install sentence-transformers`
    No API key needed — runs locally.
    """

    def __init__(self, model: str = "all-MiniLM-L6-v2", dimension: int = 384) -> None:
        self.model = model
        self.dimension = dimension
        self._model_instance: object | None = None

    def _get_model(self) -> object:
        if self._model_instance is None:
            import sentence_transformers

            self._model_instance = sentence_transformers.SentenceTransformer(self.model)
            self.dimension = self._model_instance.get_sentence_embedding_dimension()
            logger.info("Loaded local model '%s' (dim=%d)", self.model, self.dimension)
        return self._model_instance

    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        model = self._get_model()
        logger.debug("Local embed: %d texts (model=%s)", len(texts), self.model)
        embeddings = model.encode(list(texts), show_progress_bar=False)  # type: ignore[attr-defined]
        logger.info(
            "Local embedded %d texts → %d vectors (dim=%d)",
            len(texts),
            len(embeddings),
            self.dimension,
        )
        return [e.tolist() for e in embeddings]
