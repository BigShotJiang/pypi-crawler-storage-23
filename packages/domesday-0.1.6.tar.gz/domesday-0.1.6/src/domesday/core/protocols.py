"""Protocol definitions for swappable backends.

Each protocol defines a minimal interface. Implementations live in
domesday/stores/, domesday/embedders/, domesday/generators/.
Swap backends by changing config — nothing else touches these contracts.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from typing import Protocol, runtime_checkable

from domesday.core import models

# ---------------------------------------------------------------------------
# Document storage (metadata + raw text)
# ---------------------------------------------------------------------------


@runtime_checkable
class SnippetStore(Protocol):
    """Persistent storage for snippet metadata and raw text."""

    def add(self, snippet: models.Snippet) -> models.Snippet: ...

    def get(self, snippet_id: str) -> models.Snippet | None: ...

    def update(self, snippet: models.Snippet) -> models.Snippet: ...

    def deactivate(self, snippet_id: str) -> None:
        """Soft-delete: marks a snippet as inactive (superseded or removed)."""
        ...

    def list_recent(
        self,
        n: int = 20,
        *,
        project: str | None = None,
        author: str | None = None,
        tags: Sequence[str] | None = None,
        active_only: bool = True,
    ) -> list[models.Snippet]: ...

    def get_all_active(self, *, project: str | None = None) -> list[models.Snippet]:
        """Return all active snippets, optionally filtered by project."""
        ...

    def list_projects(self) -> list[str]:
        """Return all distinct project names with active snippets."""
        ...

    def rename_project(self, old_name: str, new_name: str) -> int:
        """Rename all snippets from old_name to new_name. Returns count updated."""
        ...

    def count(self, *, active_only: bool = True, project: str | None = None) -> int: ...

    def ensure_initialized(self) -> None:
        """Lazily initialize on first use (e.g. open DB connection)."""
        ...


# ---------------------------------------------------------------------------
# Vector storage (embeddings + similarity search)
# ---------------------------------------------------------------------------


@runtime_checkable
class VectorStore(Protocol):
    """Stores chunk embeddings and supports similarity search."""

    def add_chunks(
        self,
        *,
        chunks: Iterable[models.Chunk],
        embeddings: Iterable[Sequence[float]],
        embedding_model: str,
        project: str,
    ) -> None: ...

    def search(
        self,
        query_embedding: Sequence[float],
        k: int | None,
        *,
        project: str | None = None,
        filter_tags: Sequence[str] | None = None,
        embedding_model: str | None = None,
    ) -> list[tuple[str, str, float]]:
        """Returns list of (chunk_id, snippet_id, score)."""
        ...

    def delete_by_snippet(self, snippet_id: str) -> None:
        """Remove all chunks for a given snippet (used on edit/deactivate)."""
        ...

    def rename_project(self, old_name: str, new_name: str) -> int:
        """Update project metadata on all chunks from old_name to new_name.
        Returns count of chunks updated."""
        ...

    def count(self) -> int: ...

    def ensure_initialized(self) -> None:
        """Lazily initialize on first use (e.g. open Chroma client)."""
        ...


# ---------------------------------------------------------------------------
# Embedding
# ---------------------------------------------------------------------------


@runtime_checkable
class Embedder(Protocol):
    """Converts text to dense vector embeddings."""

    @property
    def model(self) -> str:
        """Model name or identifier."""
        ...

    @property
    def dimension(self) -> int:
        """Dimensionality of the output vectors."""
        ...

    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        """Embed one or more texts. Batching is handled internally."""
        ...


# ---------------------------------------------------------------------------
# Text generation (RAG answer generation)
# ---------------------------------------------------------------------------


@runtime_checkable
class Generator(Protocol):
    """Generates answers from retrieved context using an LLM."""

    def generate(
        self,
        query: str,
        context: Sequence[models.SearchResult],
        *,
        system_prompt: str | None = None,
    ) -> models.RAGResponse: ...


# ---------------------------------------------------------------------------
# Chunker (text splitting strategy)
# ---------------------------------------------------------------------------


@runtime_checkable
class Chunker(Protocol):
    """Splits a snippet's text into chunks for embedding."""

    def chunk(self, snippet: models.Snippet) -> list[models.Chunk]: ...


# ---------------------------------------------------------------------------
# Reranker (optional post-retrieval relevance filtering)
# ---------------------------------------------------------------------------


@runtime_checkable
class Reranker(Protocol):
    """Reranks/filters search results by relevance to the query."""

    def rerank(
        self,
        query: str,
        results: Sequence[models.SearchResult],
    ) -> list[models.SearchResult]: ...
