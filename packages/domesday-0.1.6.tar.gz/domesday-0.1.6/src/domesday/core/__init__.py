"""Core models, protocols, and pipeline."""
