"""domesday — a shared knowledge base that keeps AI tools informed of your team's project-specific information."""

import importlib.metadata

__version__ = importlib.metadata.version("domesday")
