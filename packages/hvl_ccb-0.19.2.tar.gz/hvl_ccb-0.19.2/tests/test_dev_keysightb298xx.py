#  Copyright (c) ETH Zurich, SIS ID and HVL D-ITET
#
"""
Tests for the keysightb298xx KeysightB2985A device class.
"""

from collections import defaultdict
from queue import Queue
from time import sleep

import pytest
from bitstring import BitArray

from hvl_ccb.comm.visa import VisaCommunicationError
from hvl_ccb.dev.keysightb298xx import (
    KeysightB2985A,
    KeysightB2985AConfig,
    KeysightB2985AError,
    KeysightB2985AVisaCommunication,
    KeysightB2985AVisaCommunicationConfig,
)
from hvl_ccb.dev.keysightb298xx.comm import (
    KeysightB2985AVisaCommunicationError,
    ready_to_query,
    ready_to_read,
    ready_to_write,
)
from hvl_ccb.dev.keysightb298xx.modules.submodules.sense import (
    SensCharge,
    SensCurrent,
    SensResistance,
)
from hvl_ccb.dev.keysightb298xx.modules.submodules.status import (
    _MeasStatusRegister,
    _OperStatusRegister,
    _QuesStatusRegister,
    _StatusBitFullRegister,
    _StatusBitSmallRegister,
    _StatusRegisterFull,
)
from hvl_ccb.utils.typing import Number

interface_type = KeysightB2985AVisaCommunicationConfig.InterfaceType.TCPIP_INSTR


class MaskedKeysightB2985AVisaCommunication(KeysightB2985AVisaCommunication):
    def __init__(self, configuration) -> None:
        super().__init__(configuration)

        self._read_buffer: defaultdict = defaultdict(Queue)
        self._write_buffer: Queue = Queue()

        self._last_command: str | list[str] = ""

        self._stb: int = 0

    def spoll(self) -> int:
        return self._stb

    def open(self) -> None:
        self._write_buffer.put("*ESE 1;*OPC")

        self._stb = 32

    def close(self) -> None:
        pass

    @ready_to_write
    def write(self, command: str, *, expected_answer: str = "0") -> None:
        if self._stb < 32:
            self._stb += 4
            self.put_name("SYSTem:ERRor:ALL?", "Some_Error_String")
            return
        if self._stb - 32 >= 16:
            self._stb += 4
            self.put_name("SYSTem:ERRor:ALL?", "Some_Error_String")
            return
        self.put_name("*ESE?", "1")
        self._stb -= 32
        self._write_buffer.put(f"{command};*OPC")
        sleep(0.3)
        if "?" in command:
            self._last_command = command
            self.put_name(command, expected_answer)
            self._stb += 16

        self._stb += 32

    @ready_to_write
    def write_multiple(self, *commands: str, expected_answer: str = "0") -> None:
        if self._stb < 32:
            self._stb += 4
            self.put_name("SYSTem:ERRor:ALL?", "Some_Error_String")
            return
        if self._stb - 32 >= 16:
            self._stb += 4
            self.put_name("SYSTem:ERRor:ALL?", "Some_Error_String")
            return
        self.put_name("*ESE?", "1")
        self._stb -= 32
        command_str: str = ";".join(commands)
        self._write_buffer.put(f"{command_str};*OPC")
        sleep(0.3)
        if "?" in command_str:
            self._last_command = command_str
            self.put_name(command_str, expected_answer)
            self._stb += 16

        self._stb += 32

    @ready_to_read
    def read(self) -> str:
        if not self._read_buffer[self._last_command].empty():
            self._stb -= 16
            answer = self._read_buffer[self._last_command].get()
            self._last_command = ""
            return answer

        self._stb += 4
        self.put_name("SYSTem:ERRor:ALL?", "Some_Error_String")
        raise KeysightB2985AVisaCommunicationError

    @ready_to_query
    def query(
        self,
        command: str,
        _n_attempts_max: int | None = None,
        _attempt_interval_sec: Number | None = None,
    ) -> str | None:
        if self._stb < 32:
            self._stb += 4
            self.put_name("SYSTem:ERRor:ALL?", "Some_Error_String")
            return None
        if self._stb - 32 >= 16:
            self._stb += 4
            self.put_name("SYSTem:ERRor:ALL?", "Some_Error_String")
            return None
        self._stb -= 32
        sleep(0.3)
        if command == "SYSTem:ERRor:ALL?":
            self._stb -= 4
        self._stb += 32
        command = "*ESR?;" + command + ";*OPC"
        if not self._read_buffer[command].empty():
            return tuple(self._read_buffer[command].get().split(";"))[1]

        self._stb += 4
        self.put_name("SYSTem:ERRor:ALL?", "Some_Error_String")
        raise KeysightB2985AVisaCommunicationError

    @ready_to_query
    def query_multiple(
        self,
        *commands: str,
        _n_attempts_max: int | None = None,
        _attempt_interval_sec: Number | None = None,
    ) -> None | str | tuple[str, ...]:
        if self._stb < 32:
            self._stb += 4
            self.put_name("SYSTem:ERRor:ALL?", "Some_Error_String")
            return None
        if self._stb - 32 >= 16:
            self._stb += 4
            self.put_name("SYSTem:ERRor:ALL?", "Some_Error_String")
            return None
        self._stb -= 32
        sleep(0.3)
        self._stb += 32
        commands_string = ";".join(commands)
        commands_string = "*ESR?;" + commands_string + ";*OPC"
        if not self._read_buffer[commands_string].empty():
            return tuple(self._read_buffer[commands_string].get().split(";"))[1:]

        self._stb += 4
        self.put_name("SYSTem:ERRor:ALL?", "Some_Error_String")
        raise KeysightB2985AVisaCommunicationError

    def _append_output_buffer(self, *command: str) -> None:
        if len(self._output_buffer) > self.MULTI_COMMANDS_MAX - 2 - len(command):
            msg = "Output buffer full"
            raise KeysightB2985AVisaCommunicationError(msg)
        self._output_buffer += list(command)
        self._output_buffer.append("*WAI")

    def write_bytes(self, value: bytes) -> int:
        command_str = value.decode()
        self._write_buffer.put(command_str)
        return len(value)

    @ready_to_write
    def send_output_buffer(self) -> None:
        self.write_multiple(*tuple(self._output_buffer))
        self._output_buffer = []

    def put_name(self, command: str, string: str) -> None:
        self._read_buffer[command].put(string)

    def get_written(self) -> str | None:
        return self._write_buffer.get() if not self._write_buffer.empty() else None


@pytest.fixture(scope="module")
def com_config():
    return {
        "interface_type": interface_type,
        "host": "127.0.0.1",
        "open_timeout": 10,
        "timeout": 50,
    }


@pytest.fixture(scope="module")
def dev_config():
    return {
        "module": SensCurrent,
        "spoll_interval": 0.2,
        "spoll_start_delay": 0,
    }


@pytest.fixture
def testdev(com_config, dev_config):
    com = MaskedKeysightB2985AVisaCommunication(com_config)
    dev = KeysightB2985A(com, dev_config)
    dev.SPOLL_INTERVAL = 0.03
    dev.SPOLL_START_DELAY = 0
    assert dev is not None
    with dev:
        assert dev.com.get_written() == "*ESE 1;*OPC"
        assert dev.com.get_written() == "*RST;*CLS;*OPC"
        assert dev.com.get_written() == ":DISP:ENAB 1;*OPC"
        yield dev


@pytest.fixture(scope="module", params=[SensCharge, SensCurrent, SensResistance])
def dev_config_var(request):
    return {
        "module": request.param,
        "spoll_interval": 0.2,
        "spoll_start_delay": 0,
    }


@pytest.fixture
def testdev_var(com_config, dev_config_var):
    com = MaskedKeysightB2985AVisaCommunication(com_config)
    dev = KeysightB2985A(com, dev_config_var)
    dev.SPOLL_INTERVAL = 0.03
    dev.SPOLL_START_DELAY = 0
    assert dev is not None
    with dev:
        assert dev.com.get_written() == "*ESE 1;*OPC"
        assert dev.com.get_written() == "*RST;*CLS;*OPC"
        assert dev.com.get_written() == ":DISP:ENAB 1;*OPC"
        yield dev


def test_dev_config(dev_config):
    config = KeysightB2985AConfig(**dev_config)
    for key, value in dev_config.items():
        assert getattr(config, key) == value


@pytest.mark.parametrize(
    "wrong_config_dict",
    [
        {"spoll_interval": 0},
        {"spoll_interval": -1},
        {"spoll_start_delay": -1},
    ],
)
def test_invalid_config_dict(dev_config, wrong_config_dict):
    invalid_config = dict(dev_config)
    invalid_config.update(wrong_config_dict)
    with pytest.raises(ValueError):
        KeysightB2985AConfig(**invalid_config)


def test_instantiation(com_config):
    dev = KeysightB2985A(com_config)
    assert dev is not None

    copy_config = dict(com_config)
    copy_config.pop("interface_type")
    dev = KeysightB2985A(copy_config)
    assert dev is not None


def test_stop(testdev_var: KeysightB2985A):
    # case polling: send stopping instructions
    sleep(3)
    testdev_var.stop()
    assert testdev_var.com.get_written() == "*RST;*CLS;*OPC"
    # case not polling: do nothing, just log a warning
    testdev_var.stop()


def test_query_status(testdev: KeysightB2985A):
    testdev.com._stb = 36
    testdev.com.put_name("*ESR?;SYSTem:ERRor:ALL?;*OPC", "1;Some_Error_String")
    with pytest.raises(KeysightB2985AError):
        testdev.query_status()

    assert testdev.com.get_written() == "*OPC"

    testdev.com._stb = 0
    testdev.com.write("TEST")
    sleep(1)
    testdev.com._stb = 32
    sleep(1)
    assert testdev.com.get_written() == "TEST;*WAI;*OPC"


def test_comm_decorators(testdev: KeysightB2985A):
    with pytest.raises(KeysightB2985AVisaCommunicationError):
        testdev.com.read()

    testdev.com._stb = 48
    with pytest.raises(KeysightB2985AVisaCommunicationError):
        testdev.com.query("TEST")

    testdev.com._output_buffer = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    testdev.com._stb = 16
    with pytest.raises(KeysightB2985AVisaCommunicationError):
        testdev.com.write("TEST")

    testdev.com._stb = 16
    testdev.com._output_buffer = ["TEST"]

    with pytest.raises(KeysightB2985AVisaCommunicationError):
        testdev.com.send_output_buffer()


def test_self_test_and_operation_complete(testdev: KeysightB2985A):
    testdev.com.put_name("*ESR?", "1")
    assert testdev.self_test() is True
    assert testdev.com.get_written() == "*TST?;*OPC"

    testdev.com._stb = 32
    testdev.status.status_summary.update_status()
    assert testdev.wait_operation_complete(2) is True

    testdev.com._stb = 0
    testdev.status.status_summary.update_status()
    with pytest.raises(TimeoutError):
        testdev.wait_operation_complete(0.1)


@pytest.mark.parametrize(
    ("module_name", "module_command"),
    [
        ("acquire", ":ACQ"),
        ("transition", ":TRAN"),
    ],
)
def test_acq_trans_base(
    testdev: KeysightB2985A,
    module_name,
    module_command,
):
    module = testdev.__getattribute__(module_name)
    module.abort()
    assert testdev.com.get_written() == f":ABORT{module_command};*OPC"

    module.start()
    assert testdev.com.get_written() == f":INIT{module_command};*OPC"

    testdev.com.put_name(f"*ESR?;:IDLE{module_command}?;*OPC", "1;0")
    assert module.idle is False


@pytest.mark.parametrize(
    ("module_name", "module_command", "submodule_name", "submodule_command"),
    [
        ("acquire", ":ACQ", "arm", ":ARM"),
        ("acquire", ":ACQ", "trigger", ":TRIG"),
        ("transition", ":TRAN", "trigger", ":TRIG"),
        ("transition", ":TRAN", "arm", ":ARM"),
    ],
)
def test_arm_trig_base(
    testdev: KeysightB2985A,
    module_name,
    module_command,
    submodule_name,
    submodule_command,
):
    module = testdev.__getattribute__(module_name).__getattribute__(submodule_name)
    testdev.com.put_name(f"*ESR?;{submodule_command}{module_command}:COUN?;*OPC", "0;1")
    assert module.count == 1

    module.count = 100
    assert (
        testdev.com.get_written()
        == f"{submodule_command}{module_command}:COUN 100;*OPC"
    )

    with pytest.raises(ValueError):
        module.count = 100_001

    testdev.com.put_name(
        f"*ESR?;{submodule_command}{module_command}:DEL?;*OPC", "1;0.001"
    )
    assert module.delay == 0.001

    module.delay = 2
    assert (
        testdev.com.get_written() == f"{submodule_command}{module_command}:DEL 2;*OPC"
    )

    with pytest.raises(ValueError):
        module.delay = 100_001

    testdev.com.put_name(f"*ESR?;{submodule_command}{module_command}:BYP?;*OPC", "1;1")
    assert module.event_bypass is True

    module.event_bypass = False
    assert (
        testdev.com.get_written() == f"{submodule_command}{module_command}:BYP OFF;*OPC"
    )

    testdev.com.put_name(
        f"*ESR?;{submodule_command}{module_command}:SOUR?;*OPC", "1;TIM"
    )
    assert module.event_source == "TIM"

    module.event_source = "LAN"
    assert (
        testdev.com.get_written()
        == f"{submodule_command}{module_command}:SOUR LAN;*OPC"
    )

    with pytest.raises(ValueError):
        module.event_source = "IMM"

    module.event_source = "INST"
    assert testdev.com.get_written() == f"{submodule_command}{module_command}:IMM;*OPC"

    assert module.event_source == "INST"

    testdev.com.put_name(
        f"*ESR?;{submodule_command}{module_command}:TOUT:STAT?;"
        f"{submodule_command}{module_command}:TOUT:SIGN?;*OPC",
        "0;1;TOUT",
    )
    assert module.event_out == "TOUT"

    testdev.com.put_name(
        f"*ESR?;{submodule_command}{module_command}:TOUT:STAT?;"
        f"{submodule_command}{module_command}:TOUT:SIGN?;*OPC",
        "1;0;TOUT",
    )
    assert module.event_out == "OFF"

    module.event_out = "LAN"
    assert (
        testdev.com.get_written()
        == f"{submodule_command}{module_command}:TOUT:STAT 1;*OPC"
    )
    assert (
        testdev.com.get_written()
        == f"{submodule_command}{module_command}:TOUT:SIGN LAN;*OPC"
    )

    module.event_out = "OFF"
    assert (
        testdev.com.get_written()
        == f"{submodule_command}{module_command}:TOUT:STAT 0;*OPC"
    )

    testdev.com.put_name(
        f"*ESR?;{submodule_command}{module_command}:TIM?;*OPC", "1;0.5"
    )
    assert module.event_timer_interval == 0.5

    module.event_timer_interval = 5
    assert (
        testdev.com.get_written() == f"{submodule_command}{module_command}:TIM 5;*OPC"
    )

    with pytest.raises(ValueError):
        module.event_timer_interval = 0

    testdev.com.put_name(
        f"*ESR?;{submodule_command}{module_command}:SOUR:LAN?;*OPC", "1;LAN0,LAN2"
    )
    assert module.event_lan_source == ["LAN0", "LAN2"]

    testdev.com.put_name(
        f"*ESR?;{submodule_command}{module_command}:SOUR:LAN?;*OPC", "1;LAN0"
    )
    assert module.event_lan_source == ["LAN0"]

    module.event_lan_source = ["LAN0"]
    assert (
        testdev.com.get_written()
        == f"{submodule_command}{module_command}:SOUR:LAN LAN0;*OPC"
    )

    module.event_lan_source = ["LAN0", "LAN2"]
    assert (
        testdev.com.get_written()
        == f"{submodule_command}{module_command}:SOUR:LAN LAN0,LAN2;*OPC"
    )

    with pytest.raises(TypeError):
        module.event_lan_source = "TEST"

    with pytest.raises(ValueError):
        module.event_lan_source = ["TEST"]


def test_data_module(testdev: KeysightB2985A):
    testdev.data.clear()
    assert testdev.com.get_written() == ":SENS:DATA:CLE;*OPC"

    sleep(0.2)

    testdev.com.put_name("*ESR?;:FORM:ELEM:SENS?;*OPC", "1;VOLT,CURR,TIME")
    form = testdev.data.structure
    assert form == ["VOLT", "CURR", "TIME"]

    sleep(0.2)

    testdev.com.put_name("*ESR?;:FORM:ELEM:SENS?;*OPC", "1;VOLT,CURR,TIME")
    testdev.com.put_name(
        "*ESR?;:SENS:DATA?;*OPC", "1;1.0,1.0,1.0,2.0,2.0,2.0,3.0,3.0,3.0"
    )
    data_all = testdev.data.get_all()
    assert data_all == {
        "CURR": [1.0, 2.0, 3.0],
        "VOLT": [1.0, 2.0, 3.0],
        "TIME": [1.0, 2.0, 3.0],
    }

    sleep(0.2)

    testdev.com.put_name("*ESR?;:FORM:ELEM:SENS?;*OPC", "1;VOLT,CURR,TIME")
    testdev.com.put_name(
        "*ESR?;:SENS:DATA:LAT?;*OPC", "1;4.0,4.0,4.0,5.0,5.0,5.0,6.0,6.0,6.0"
    )
    data_lat = testdev.data.get_latest()

    assert data_lat == {
        "CURR": [4.0, 5.0, 6.0],
        "VOLT": [4.0, 5.0, 6.0],
        "TIME": [4.0, 5.0, 6.0],
    }

    correct_format = [
        "CURR",
        "VOLT",
        "TIME",
        "CHAR",
        "STAT",
        "TEMP",
        "HUM",
        "SOUR",
        "RES",
    ]
    testdev.data.structure = correct_format
    assert (
        testdev.com.get_written() == f":FORM:ELEM:SENS {','.join(correct_format)};*OPC"
    )

    wrong_format = [*correct_format, "TEST"]

    with pytest.raises(ValueError):
        testdev.data.structure = wrong_format


def test_input_module(testdev_var: KeysightB2985A):
    cmdlet = ":"
    if testdev_var.config.module == SensCharge:
        cmdlet += "CHAR"
        module = testdev_var.input.charge  #
        rang = 2e-9
    elif testdev_var.config.module == SensCurrent:
        cmdlet += "CURR"
        module = testdev_var.input.current
        rang = 2e-9
    elif testdev_var.config.module == SensResistance:
        cmdlet += "RES"
        module = testdev_var.input.resistance
        rang = 10e9
    else:
        raise ValueError

    testdev_var.com.put_name(f"*ESR?;:SENS{cmdlet}:APER?;*OPC", "1;0.5")
    assert testdev_var.input.aperture == 0.5

    with pytest.raises(ValueError):
        testdev_var.input.aperture = 3

    testdev_var.input.aperture = 1
    assert testdev_var.com.get_written() == f":SENS{cmdlet}:APER 1;*OPC"

    testdev_var.com.put_name(
        f"*ESR?;:SENS{cmdlet}:APER:AUTO?;:SENS{cmdlet}:APER:AUTO:MODE?;*OPC", "0;1;LONG"
    )
    assert testdev_var.input.aperture_mode == "LONG"

    testdev_var.input.aperture_mode = "MED"
    assert testdev_var.com.get_written() == f":SENS{cmdlet}:APER:AUTO ON;*OPC"
    assert testdev_var.com.get_written() == f":SENS{cmdlet}:APER:AUTO:MODE MED;*OPC"

    testdev_var.input.aperture_mode = "OFF"
    assert testdev_var.com.get_written() == f":SENS{cmdlet}:APER:AUTO OFF;*OPC"

    testdev_var.com.put_name(
        f"*ESR?;:SENS{cmdlet}:APER:AUTO?;:SENS{cmdlet}:APER:AUTO:MODE?;*OPC", "1;0;LONG"
    )
    assert testdev_var.input.aperture_mode == "OFF"

    testdev_var.com.put_name(f"*ESR?;:SENS{cmdlet}:RANG:AUTO?;*OPC", "0;0")
    assert module.auto_range is False

    module.auto_range = True
    assert testdev_var.com.get_written() == f":SENS{cmdlet}:RANG:AUTO 1;*OPC"

    testdev_var.com.put_name(f"*ESR?;:SENS{cmdlet}:RANG?;*OPC", f"0;{rang};LONG")
    assert module.measurement_range == rang

    module.measurement_range = rang * 10
    assert testdev_var.com.get_written() == f":SENS{cmdlet}:RANG {rang * 10};*OPC"

    with pytest.raises(ValueError):
        module.measurement_range = rang * 10e9

    testdev_var.com.put_name("*ESR?;:INP:STAT?;*OPC", "1;0")
    assert testdev_var.input.is_enabled is False

    testdev_var.input.is_enabled = True
    assert testdev_var.com.get_written() == ":INP:STAT 1;*OPC"

    testdev_var.com.put_name("*ESR?;:INP:ZCOR:STAT?;*OPC", "1;1")
    assert testdev_var.input.is_zero_corrected is True

    testdev_var.input.is_zero_corrected = False
    assert testdev_var.com.get_written() == ":INP:ZCOR:STAT 0;*OPC"

    testdev_var.com.put_name("*ESR?;:SENS:VOLT:RANG?;*OPC", "1;20.0")
    assert testdev_var.input.voltage.measurement_range == 20.0

    testdev_var.input.voltage.measurement_range = 20
    assert testdev_var.com.get_written() == ":SENS:VOLT:RANG 20.0;*OPC"

    with pytest.raises(ValueError):
        testdev_var.input.voltage.measurement_range = 100


def test_output_module(testdev: KeysightB2985A):
    testdev.com.put_name("*ESR?;:OUTP:STAT?;*OPC", "1;0")
    assert testdev.output.is_enabled is False

    testdev.output.is_enabled = True
    assert testdev.com.get_written() == ":OUTP:STAT 1;*OPC"

    testdev.com.put_name("*ESR?;:OUTP:OFF:MODE?;*OPC", "1;NORM")
    assert testdev.output.off_mode == "NORM"

    testdev.output.off_mode = "ZERO"
    assert testdev.com.get_written() == ":OUTP:OFF:MODE ZERO;*OPC"

    testdev.com.put_name("*ESR?;:OUTP:LOW?;*OPC", "1;FLO")
    assert testdev.output.low_potential == "FLO"

    testdev.output.low_potential = "COMM"
    assert testdev.com.get_written() == ":OUTP:LOW COMM;*OPC"

    testdev.com.put_name("*ESR?;:SOUR:VOLT:MODE?;*OPC", "1;FIX")
    assert testdev.output.voltage_mode == "FIX"

    testdev.output.voltage_mode = "ARB"
    assert testdev.com.get_written() == ":SOUR:VOLT:MODE ARB;*OPC"

    testdev.com.put_name("*ESR?;:SOUR:VOLT:LEV:IMM:AMPL?;*OPC", "1;333")
    assert testdev.output.voltage == 333

    testdev.output.voltage = 444
    assert testdev.com.get_written() == ":SOUR:VOLT:RANG MAX;*OPC"
    assert testdev.com.get_written() == ":SOUR:VOLT:LEV:IMM:AMPL 444;*OPC"

    testdev.output.voltage = -444
    assert testdev.com.get_written() == ":SOUR:VOLT:RANG MIN;*OPC"
    assert testdev.com.get_written() == ":SOUR:VOLT:LEV:IMM:AMPL -444;*OPC"

    with pytest.raises(ValueError):
        testdev.output.voltage = 10000

    testdev.com.put_name("*ESR?;:SOUR:VOLT:RANG?;*OPC", "1;MAX")
    assert testdev.output._range == "MAX"

    testdev.com.put_name("*ESR?;:SOUR:VOLT:RLIM:STAT?;*OPC", "1;1")
    assert testdev.output.use_r_series is True

    testdev.output.use_r_series = False
    assert testdev.com.get_written() == ":SOUR:VOLT:RLIM:STAT 0;*OPC"


@pytest.mark.parametrize(
    ("register_name", "cmdlet"),
    [
        ("measurement_status", ":MEAS"),
        ("questionable_status", ":QUES"),
        ("operation_status", ":OPER"),
    ],
)
def test_full_status_register(testdev: KeysightB2985A, register_name: str, cmdlet: str):
    register = testdev.status.__getattribute__(register_name)
    for bit in register.__dict__.values():
        if isinstance(bit, _StatusBitFullRegister):
            testdev.com.put_name(f"*ESR?;:STAT{cmdlet}:COND?;*OPC", "1;0")
            assert bit.condition is False
            testdev.com.put_name(f"*ESR?;:STAT{cmdlet}:EVEN?;*OPC", "1;0")
            assert bit.event is False
            testdev.com.put_name(f"*ESR?;:STAT{cmdlet}:ENAB?;*OPC", "1;0")
            assert bit.enable is False
            testdev.com.put_name(f"*ESR?;:STAT{cmdlet}:ENAB?;*OPC", "1;0")
            bit.enable = True
            assert testdev.com.get_written() == (
                f":STAT{cmdlet}:ENAB {2 ** (bit._bit)};*OPC"
            )
            testdev.com.put_name(f"*ESR?;:STAT{cmdlet}:PTR?;*OPC", "1;0")
            assert bit.transition_pos is False
            testdev.com.put_name(f"*ESR?;:STAT{cmdlet}:PTR?;*OPC", "1;0")
            bit.transition_pos = True
            assert testdev.com.get_written() == (
                f":STAT{cmdlet}:PTR {2 ** (bit._bit)};*OPC"
            )
            testdev.com.put_name(f"*ESR?;:STAT{cmdlet}:NTR?;*OPC", "1;0")
            assert bit.transition_neg is False
            testdev.com.put_name(f"*ESR?;:STAT{cmdlet}:NTR?;*OPC", "1;0")
            bit.transition_neg = True
            assert testdev.com.get_written() == (
                f":STAT{cmdlet}:NTR {2 ** (bit._bit)};*OPC"
            )


def test_status_module(testdev: KeysightB2985A):
    testdev.status.clear_registers()
    assert testdev.com.get_written() == "*CLS;*OPC"

    for register in testdev.status.__dict__.values():
        if isinstance(register, _StatusRegisterFull):
            if isinstance(register, _MeasStatusRegister):
                assert isinstance(
                    testdev.status.measurement_status.limit_test_summary,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.measurement_status.sample_buffer_available,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.measurement_status.sample_buffer_full,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.measurement_status.trace_buffer_available,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.measurement_status.trace_buffer_full,
                    _StatusBitFullRegister,
                )
            elif isinstance(register, _QuesStatusRegister):
                assert isinstance(
                    testdev.status.questionable_status.over_temperature,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.questionable_status.calibration_result,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.questionable_status.interlock_open,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.questionable_status.transient_event_lost,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.questionable_status.acquire_event_lost,
                    _StatusBitFullRegister,
                )
            elif isinstance(register, _OperStatusRegister):
                assert isinstance(
                    testdev.status.operation_status.test_running,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.operation_status.transition_idle,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.operation_status.wait_for_transition_trigger,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.operation_status.wait_for_transition_arm,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.operation_status.acquisition_idle,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.operation_status.wait_for_acquisition_trigger,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.operation_status.wait_for_acquisition_arm,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.operation_status.instrument_locked,
                    _StatusBitFullRegister,
                )
                assert isinstance(
                    testdev.status.operation_status.program_running,
                    _StatusBitFullRegister,
                )
            else:
                raise TypeError


def test_status_module_standard_event_summary(testdev: KeysightB2985A):
    register = testdev.status.standard_event
    cmdlet = "*ES"
    for bit in register.__dict__.values():
        if isinstance(bit, _StatusBitSmallRegister):
            with pytest.raises(VisaCommunicationError):
                bit.enable = True
            if bit._bit in [0, 2, 3, 4, 5, 7]:
                testdev.com.put_name(f"*ESR?;{cmdlet}E?;*OPC", f"1;{2**bit._bit}")
                assert bit.enable is True

            with pytest.raises(VisaCommunicationError):
                bit.enable = True

            with pytest.raises(VisaCommunicationError):
                assert bit.condition is False

    assert isinstance(register.operation_complete, _StatusBitSmallRegister)
    assert isinstance(register.query_error, _StatusBitSmallRegister)
    assert isinstance(register.device_error, _StatusBitSmallRegister)
    assert isinstance(register.execution_error, _StatusBitSmallRegister)
    assert isinstance(register.command_error, _StatusBitSmallRegister)
    assert isinstance(register.power_on, _StatusBitSmallRegister)


def test_status_module_status_summary(testdev: KeysightB2985A):
    register = testdev.status.status_summary
    cmdlet = "*SR"
    # testdev.com._stb = 16
    register.update_status()
    array = BitArray(length=8, uint=32)
    array.reverse()
    assert register.condition == array

    testdev.com.put_name(f"*ESR?;{cmdlet}E?;*OPC", "1;0")
    assert register.enable == BitArray(length=8, uint=0)

    testdev.com.put_name(f"*ESR?;{cmdlet}E?;*OPC", "1;0")
    testdev.status.status_summary.enable = BitArray(length=8, uint=1)
    assert testdev.com.get_written() == f"{cmdlet}E 128;*OPC"

    assert isinstance(register.measurement_status, _StatusBitSmallRegister)
    assert isinstance(register.error_queue, _StatusBitSmallRegister)
    assert isinstance(register.questionable_status, _StatusBitSmallRegister)
    assert isinstance(register.output_buffer, _StatusBitSmallRegister)
    assert isinstance(register.standard_event_status, _StatusBitSmallRegister)
    assert isinstance(register.summary, _StatusBitSmallRegister)
    assert isinstance(register.operation_status, _StatusBitSmallRegister)


def test_range_format_deprecation_warning(testdev: KeysightB2985A):
    with pytest.raises(DeprecationWarning):
        testdev.input.current.range = 2e-9

    with pytest.raises(DeprecationWarning):
        _ = testdev.input.current.range

    with pytest.raises(DeprecationWarning):
        testdev.data.format = ["VOLT", "CURR"]

    with pytest.raises(DeprecationWarning):
        _ = testdev.data.format
