#  Copyright (c) ETH Zurich, SIS ID and HVL D-ITET
#
"""
Mockups of devices or servers for testing
"""
