#  Copyright (c) ETH Zurich, SIS ID and HVL D-ITET
#
"""
Socket to mime a Modbus based device server for the tests
"""

import asyncio
import logging
import socket
import traceback
from abc import ABC, abstractmethod
from collections.abc import Iterable
from contextlib import suppress
from ipaddress import IPv4Address, IPv6Address
from threading import Event, Thread
from time import monotonic, sleep
from typing import TYPE_CHECKING, Any, cast

import serial
from pymodbus.datastore import (
    ModbusDeviceContext,
    ModbusSequentialDataBlock,
    ModbusServerContext,
)
from pymodbus.server import (
    ModbusBaseServer,
    ModbusSerialServer,
    ModbusTcpServer,
)
from typing_extensions import Self

from hvl_ccb.comm.modbus import (
    ModbusSerialCommunicationConfig,
    ModbusTcpCommunicationConfig,
)
from hvl_ccb.configuration import ConfigurationMixin, configdataclass
from hvl_ccb.utils.validation import validate_bool

if TYPE_CHECKING:
    from pymodbus import FramerType

    from hvl_ccb.comm.serial import (
        SerialCommunicationBytesize,
        SerialCommunicationParity,
        SerialCommunicationStopbits,
    )

logger = logging.getLogger(__name__)

REGISTER_BUFFER: int = 10


def get_free_tcp_port(host):
    with socket.socket() as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((host, 0))
        _addr, port = sock.getsockname()
    return port


class ModbusTestServerError(Exception):
    """Error from a LocalTcpTestServer"""


@configdataclass
class _ModbusBaseTestServerCommunicationConfig:
    use_holding_registers: bool = True

    def clean_values(self) -> None:
        validate_bool("register type", self.use_holding_registers, logger=logger)


@configdataclass
class ModbusTcpTestServerCommunicationConfig(
    ModbusTcpCommunicationConfig, _ModbusBaseTestServerCommunicationConfig
):
    host: str | IPv4Address | IPv6Address = "127.0.0.1"

    port: int | None = None

    def clean_values(self) -> None:
        if self.port is None:
            self.force_value("port", get_free_tcp_port(self.host))
        _ModbusBaseTestServerCommunicationConfig.clean_values(self)
        ModbusTcpCommunicationConfig.clean_values(self)


@configdataclass
class ModbusSerialTestServerCommunicationConfig(
    _ModbusBaseTestServerCommunicationConfig, ModbusSerialCommunicationConfig
):
    port: str | None = None

    def clean_values(self) -> None:
        _ModbusBaseTestServerCommunicationConfig.clean_values(self)
        ModbusSerialCommunicationConfig.clean_values(self)


class RunningBasicModbusDeviceMockup(ConfigurationMixin, ABC):
    def __init__(
        self, config: dict[str, Any] | _ModbusBaseTestServerCommunicationConfig
    ) -> None:
        super().__init__(config)

        self.context: ModbusServerContext = self._build_context(
            self.config.unit,
            self._required_block_size(),
            self.config.use_holding_registers,
        )

        self._ts: ModbusBaseServer | None = None
        self._ts_process: Thread | None = None

        self._loop: asyncio.AbstractEventLoop | None = None
        self._ready_evt: Event = Event()
        self._thread_exc: BaseException | None = None
        self._thread_tb: str | None = None

        self._serve_task: asyncio.Task[None] | None = None

    @abstractmethod
    def _generate_test_server(self) -> ModbusBaseServer: ...

    @staticmethod
    @abstractmethod
    def _required_block_size() -> int: ...

    @abstractmethod
    def _initialize_registers(self) -> None: ...

    @abstractmethod
    def _wait_open(self, timeout: float) -> None: ...

    @staticmethod
    def _build_context(unit, size, use_holding_registers) -> "ModbusServerContext":
        """
        Build the Modbus context with its data structure
        """
        block = ModbusSequentialDataBlock(0, [0] * size)

        server = ModbusDeviceContext(
            di=ModbusSequentialDataBlock(0, [0] * 10),
            co=ModbusSequentialDataBlock(0, [0] * 10),
            hr=block
            if use_holding_registers
            else ModbusSequentialDataBlock(0, [0] * size),
            ir=block
            if not use_holding_registers
            else ModbusSequentialDataBlock(0, [0] * size),
        )

        return ModbusServerContext(devices={unit: server}, single=False)

    def __enter__(self) -> Self:
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def set_register(self, addr: int, values: Iterable[int]) -> None:
        function_code = 3 if self.config.use_holding_registers else 4
        self.context[self.config.unit].setValues(function_code, addr, list(values))

    def get_register(self, addr: int, count: int) -> list[int] | list[bool] | None:
        function_code = 3 if self.config.use_holding_registers else 4
        answer = self.context[self.config.unit].getValues(function_code, addr, count)
        return answer if isinstance(answer, list) else None

    def _ts_start_helper(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)

        async def main() -> None:
            # Create server while loop is running (fixes "no running event loop")
            self._ts = self._generate_test_server()
            self._ready_evt.set()
            await self._ts.serve_forever()

        try:
            self._serve_task = self._loop.create_task(main())

            # Stop loop automatically if task finishes (e.g. on shutdown or exception)
            self._serve_task.add_done_callback(
                lambda _: self._loop.call_soon_threadsafe(self._loop.stop)
            )

            self._loop.run_forever()

        except Exception as exc:  # noqa: BLE001
            self._thread_exc = exc
            self._thread_tb = "".join(
                traceback.format_exception(type(exc), exc, exc.__traceback__)
            )
            self._ready_evt.set()
        finally:
            try:
                if self._serve_task is not None and not self._serve_task.done():
                    self._serve_task.cancel()
                    self._loop.run_until_complete(
                        asyncio.gather(self._serve_task, return_exceptions=True)
                    )
                self._loop.run_until_complete(self._loop.shutdown_asyncgens())
            finally:
                self._loop.close()

    def open(self) -> None:
        if self._ts_process is not None and self._ts_process.is_alive():
            return

        self._thread_exc = None
        self._thread_tb = None
        self._ts = None
        self._loop = None
        self._ready_evt.clear()

        self._ts_process = Thread(target=self._ts_start_helper, daemon=True)
        self._ts_process.start()

        # Wait until server is created (or thread crashed)
        if not self._ready_evt.wait(timeout=2.0):
            msg = "Server thread did not signal readiness in time"
            raise RuntimeError(msg)

        if self._thread_exc is not None:
            tb = self._thread_tb or repr(self._thread_exc)
            msg = f"Server thread crashed during startup:\n{tb}"
            raise RuntimeError(msg) from self._thread_exc

        # Optional: confirm socket accept
        self._wait_open(timeout=2.0)

    def close(self) -> None:
        if self._ts_process is None:
            msg = "The test server was not started"
            raise ModbusTestServerError(msg)

        loop = self._loop
        server = self._ts

        if loop is None or server is None:
            self._ts_process.join(timeout=2.0)
            self._ts_process = None
            return

        async def shutdown_async() -> None:
            # Try async shutdown; if it's sync in your build, fall back.
            shutdown = getattr(server, "shutdown", None)
            if shutdown is None:
                loop.stop()
                return

            res = shutdown()
            if asyncio.iscoroutine(res):
                await res
            loop.stop()

        fut = asyncio.run_coroutine_threadsafe(shutdown_async(), loop)
        try:
            fut.result(timeout=2.0)
        except (asyncio.CancelledError, TimeoutError):
            loop.call_soon_threadsafe(loop.stop)

        self._ts_process.join(timeout=2.0)
        self._ts_process = None
        self._loop = None
        self._ts = None
        self._serve_task = None


class LocalModbusTcpServer(RunningBasicModbusDeviceMockup):
    @staticmethod
    def config_cls():
        return ModbusTcpTestServerCommunicationConfig

    def _generate_test_server(self) -> "ModbusBaseServer":
        """Return the 'ModbusServer' type to be used."""
        address = (self.config.host, self.config.port)
        return ModbusTcpServer(self.context, address=address)

    @staticmethod
    def _required_block_size() -> int:
        return 10 + REGISTER_BUFFER

    def _initialize_registers(self) -> None:
        """Populate the registers with initial values"""
        for register in range(self._required_block_size()):
            self.set_register(register, [register])

    def _wait_open(self, timeout: float = 2.0) -> None:
        """_summary_

        :param timeout: _description_, defaults to 2.0
        :raises RuntimeError: _description_
        """
        address = (self.config.host, self.config.port)

        deadline = monotonic() + timeout

        while monotonic() < deadline:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(0.2)
                if sock.connect_ex(address) == 0:
                    return

            sleep(0.05)

        msg = f"Server did not open {address} within {timeout}s."
        raise RuntimeError(msg)


class LocalModbusSerialServer(RunningBasicModbusDeviceMockup):
    @staticmethod
    def config_cls():
        return ModbusSerialTestServerCommunicationConfig

    def _generate_test_server(self) -> "ModbusBaseServer":
        """Return the 'ModbusServer' type to be used."""
        return ModbusSerialServer(
            context=self.context,
            port=cast("str", self.config.port),
            framer=cast("FramerType", self.config.framer),
            baudrate=self.config.baudrate,
            bytesize=cast("SerialCommunicationBytesize", self.config.bytesize).value,
            parity=cast("SerialCommunicationParity", self.config.parity).value,
            stopbits=cast("SerialCommunicationStopbits", self.config.stopbits).value,
            timeout=self.config.timeout,
        )

    @staticmethod
    def _required_block_size() -> int:
        return 10 + REGISTER_BUFFER

    def _initialize_registers(self) -> None:
        """Populate the registers with initial values"""
        for register in range(self._required_block_size()):
            self.set_register(register, [register])

    def _wait_open(self, timeout: float = 2.0) -> None:
        """_summary_

        :param timeout: _description_, defaults to 2.0
        :raises RuntimeError: _description_
        """
        deadline = monotonic() + timeout

        server_config = {
            "port": cast("str", self.config.port),
            "baudrate": self.config.baudrate,
            "bytesize": cast("SerialCommunicationBytesize", self.config.bytesize).value,
            "parity": cast("SerialCommunicationParity", self.config.parity).value,
            "stopbits": cast("SerialCommunicationStopbits", self.config.stopbits).value,
            "timeout": self.config.timeout,
        }
        while monotonic() < deadline:
            with suppress(serial.SerialException):
                _ = serial.Serial(**server_config)
                return
            sleep(0.05)

        msg = f"Server did not open {self.config.port} within {timeout}s."
        raise RuntimeError(msg)
