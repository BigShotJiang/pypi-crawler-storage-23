#  Copyright (c) ETH Zurich, SIS ID and HVL D-ITET
#
"""
Tests for the Communication Protocol package comm.modbus
"""

import re
import subprocess
import sys
import time

import pytest

from hvl_ccb.comm.modbus import (
    ModbusConnectionError,
    ModbusSerialCommunication,
    ModbusSerialCommunicationConfig,
    ModbusTcpCommunication,
    ModbusTcpCommunicationConfig,
)
from mocked_comm.modbus import (
    LocalModbusSerialServer,
    LocalModbusTcpServer,
    get_free_tcp_port,
)

linux_exclusive = pytest.mark.skipif(
    sys.platform == "win32",
    reason="Virtual serial ports are not supported on Windows",
)


def create_pty_pair(timeout: float = 3.0) -> tuple[str, str, subprocess.Popen]:
    """
    Start socat to create a PTY pair.

    Returns:
        (pty1_path, pty2_path, process_handle)
    """

    proc = subprocess.Popen(
        ["socat", "-d", "-d", "pty,raw,echo=0", "pty,raw,echo=0"],  # noqa: S607
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )

    ptys = []
    deadline = time.time() + timeout
    pattern = re.compile(r"PTY is (/dev/pts/\d+)")

    while time.time() < deadline and len(ptys) < 2:
        line = proc.stderr.readline()
        if not line:
            continue

        match = pattern.search(line)
        if match:
            ptys.append(match.group(1))

    if len(ptys) != 2:
        proc.terminate()
        msg = "Failed to create PTY pair via socat"
        raise RuntimeError(msg)

    return ptys[0], ptys[1], proc


# Serial Setup
@pytest.fixture(scope="module")
def serial_pair():
    pty1, pty2, proc = create_pty_pair()
    yield pty1, pty2
    proc.terminate()
    proc.wait(timeout=2)


# serial server
@pytest.fixture(scope="module")
def com_config_server_serial(serial_pair):
    return {"port": serial_pair[0], "unit": 1, "framer": "rtu", "stopbits": 1}


@pytest.fixture(scope="module")
def serial_server(com_config_server_serial):
    with LocalModbusSerialServer(com_config_server_serial) as ts:
        yield ts


# serial client
@pytest.fixture(scope="module")
def com_config_client_serial(serial_pair):
    return {"port": serial_pair[1], "unit": 1, "framer": "rtu", "stopbits": 1}


@pytest.fixture(scope="module")
def serial_client(com_config_client_serial):
    with ModbusSerialCommunication(com_config_client_serial) as tc:
        yield tc


# TCP Config
@pytest.fixture(scope="module")
def com_config_tcp():
    return {"host": "127.0.0.1", "unit": 1, "port": get_free_tcp_port("127.0.0.1")}


@pytest.fixture(scope="module")
def com_config_tcp_input_regs_client():
    return {"host": "127.0.0.1", "unit": 2, "port": get_free_tcp_port("127.0.0.1")}


@pytest.fixture(scope="module")
def com_config_tcp_input_regs_server(com_config_tcp_input_regs_client):
    new_dict = com_config_tcp_input_regs_client.copy()
    new_dict["use_holding_registers"] = False
    return new_dict


@pytest.fixture(scope="module")
def com_config_tcp_not_started():
    return {"host": "127.0.0.1", "unit": 1, "port": get_free_tcp_port("127.0.0.1")}


@pytest.fixture(scope="module")
def tcp_server(com_config_tcp):
    with LocalModbusTcpServer(com_config_tcp) as ts:
        yield ts


@pytest.fixture(scope="module")
def tcp_server_input_regs(com_config_tcp_input_regs_server):
    with LocalModbusTcpServer(com_config_tcp_input_regs_server) as ts:
        yield ts


@pytest.fixture(scope="module")
def tcp_client(com_config_tcp):
    with ModbusTcpCommunication(com_config_tcp) as tc:
        yield tc


@pytest.fixture(scope="module")
def tcp_client_input_regs(com_config_tcp_input_regs_client):
    with ModbusTcpCommunication(com_config_tcp_input_regs_client) as tc:
        yield tc


@pytest.fixture(scope="module")
def tcp_client_not_started(com_config_tcp_not_started):
    return ModbusTcpCommunication(com_config_tcp_not_started)


def test_com_config_tcp(com_config_tcp) -> None:
    com_config = ModbusTcpCommunicationConfig(**com_config_tcp)
    assert com_config

    host = com_config_tcp["host"]
    com_config_tcp["host"] = "127..1"
    with pytest.raises(ValueError):
        _ = ModbusTcpCommunicationConfig(**com_config_tcp)
    com_config_tcp["host"] = host


def test_modbus_tcp_connect_holding_regs(
    tcp_server_input_regs, tcp_client_input_regs
) -> None:
    assert tcp_client_input_regs.client.connected

    tcp_server_input_regs.set_register(1, [66])
    assert tcp_client_input_regs.read_input_registers(address=1, count=1) == [66]


def test_modbus_tcp_connect(tcp_server, tcp_client) -> None:
    assert tcp_client.client.connected

    tcp_client.write_registers(address=0, values=44)
    assert tcp_server.get_register(0, 1) == [44]

    tcp_server.set_register(1, [66])
    assert tcp_client.read_holding_registers(address=1, count=1) == [66]

    with pytest.raises(ModbusConnectionError):
        tcp_client.read_holding_registers(address=500, count=1)


def test_modbus_tcp_not_started(tcp_client_not_started) -> None:
    with pytest.raises(ModbusConnectionError):
        tcp_client_not_started.open()

    with pytest.raises(ModbusConnectionError):
        tcp_client_not_started.write_registers(50, [1])

    with pytest.raises(ModbusConnectionError):
        tcp_client_not_started.read_input_registers(50, 1)

    with pytest.raises(ModbusConnectionError):
        tcp_client_not_started.read_holding_registers(50, 1)


@linux_exclusive
def test_com_config_serial(com_config_client_serial) -> None:
    com_config = ModbusSerialCommunicationConfig(**com_config_client_serial)
    assert com_config

    port = com_config_client_serial["port"]
    com_config_client_serial["port"] = ""
    with pytest.raises(ModbusConnectionError):
        _ = ModbusSerialCommunicationConfig(**com_config_client_serial)
    com_config_client_serial["port"] = port

    com_config = ModbusSerialCommunicationConfig(**com_config_client_serial)
    assert com_config

    stopbits = com_config_client_serial["stopbits"]
    com_config_client_serial["stopbits"] = 1.5
    with pytest.raises(ModbusConnectionError):
        _ = ModbusSerialCommunicationConfig(**com_config_client_serial)
    com_config_client_serial["stopbits"] = stopbits

    com_config = ModbusSerialCommunicationConfig(**com_config_client_serial)
    assert com_config

    framer = com_config_client_serial["framer"]
    com_config_client_serial["framer"] = "TLS"
    with pytest.raises(ValueError):
        _ = ModbusSerialCommunicationConfig(**com_config_client_serial)
    com_config_client_serial["framer"] = "tls"
    with pytest.raises(ModbusConnectionError):
        _ = ModbusSerialCommunicationConfig(**com_config_client_serial)
    com_config_client_serial["framer"] = framer

    com_config = ModbusSerialCommunicationConfig(**com_config_client_serial)
    assert com_config

    unit = com_config_client_serial["unit"]
    com_config_client_serial["unit"] = 300
    with pytest.raises(ValueError):
        _ = ModbusSerialCommunicationConfig(**com_config_client_serial)
    com_config_client_serial["unit"] = unit

    com_config = ModbusSerialCommunicationConfig(**com_config_client_serial)
    assert com_config


@linux_exclusive
def test_modbus_serial_connect(serial_server, serial_client) -> None:

    assert serial_client is not None

    assert serial_client.client.connected

    serial_client.write_registers(address=0, values=1)
    assert serial_server.get_register(0, 1) == [1]
    serial_server.set_register(1, [1])

    assert serial_client.read_holding_registers(address=0, count=1) == [1]


@linux_exclusive
def test_modbus_serial_not_started(serial_server, serial_client) -> None:

    assert serial_client is not None

    assert serial_client.client.connected

    serial_client.write_registers(address=0, values=1)
    assert serial_server.get_register(0, 1) == [1]
    serial_server.set_register(1, [1])

    assert serial_client.read_holding_registers(address=0, count=1) == [1]
