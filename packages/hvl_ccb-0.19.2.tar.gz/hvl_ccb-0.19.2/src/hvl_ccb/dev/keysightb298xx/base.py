#  Copyright (c) ETH Zurich, SIS ID and HVL D-ITET
#
from hvl_ccb.configuration import configdataclass
from hvl_ccb.dev.base import DeviceError
from hvl_ccb.dev.visa import VisaDeviceConfig

from .modules import (
    SensCharge,
    SensCurrent,
    SensResistance,
)


class KeysightB2985AError(DeviceError):
    """General error class for the Keysight B2985A device."""


@configdataclass
class KeysightB2985AConfig(VisaDeviceConfig):
    """
    Configdataclass for the KeysightB2985A device.
    """

    module: type[SensCharge | SensCurrent | SensResistance] = SensCurrent
