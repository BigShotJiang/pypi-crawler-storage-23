#  Copyright (c) ETH Zurich, SIS ID and HVL D-ITET
#
from hvl_ccb.dev.keysightb298xx.comm import KeysightB2985AVisaCommunication


class _BaseModule:
    """
    Base class for all submodules.
    """

    def __init__(
        self,
        com: KeysightB2985AVisaCommunication,
        base_command: str,
        name: str,
    ) -> None:
        self._com = com
        self._base_command = base_command
        self._name = name
