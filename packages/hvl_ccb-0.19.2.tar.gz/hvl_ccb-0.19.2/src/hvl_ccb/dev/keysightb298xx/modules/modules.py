#  Copyright (c) ETH Zurich, SIS ID and HVL D-ITET
#
import logging
from typing import Any

from hvl_ccb.dev.keysightb298xx.comm import KeysightB2985AVisaCommunication
from hvl_ccb.dev.keysightb298xx.modules.submodules.format import FormatElements, _Format
from hvl_ccb.dev.keysightb298xx.modules.submodules.input import _CurrentInput
from hvl_ccb.dev.keysightb298xx.modules.submodules.output import (
    LowPotential,
    OffMode,
    _OutputBase,
)
from hvl_ccb.dev.keysightb298xx.modules.submodules.sense import (
    SensCharge,
    SensCurrent,
    SensResistance,
    SensVoltage,
    _SensDataBase,
    _SenseBase,
)
from hvl_ccb.dev.keysightb298xx.modules.submodules.source import _VoltageSourceBase
from hvl_ccb.dev.keysightb298xx.modules.submodules.status import (
    _MeasStatusRegister,
    _OperStatusRegister,
    _QuesStatusRegister,
    _StandardEventRegister,
    _StatusSummary,
)
from hvl_ccb.dev.keysightb298xx.modules.submodules.trigger import _AcqTrans

logger = logging.getLogger(__name__)


class Acquisition(_AcqTrans):
    """
    Class providing functionality for the acquisition system.
    """

    def __init__(self, com: KeysightB2985AVisaCommunication) -> None:
        super().__init__(com, ":ACQ", "acquisition")


class Data(_SensDataBase):
    """
    Class providing functionality to control data format
    , read and clear the acquired data.
    """

    def __init__(self, com: KeysightB2985AVisaCommunication) -> None:
        self._format = _Format(com)
        super().__init__(com)

    def get_all(self) -> dict:
        """
        Read all the data in the output buffer.

        :return: dict with the data in the buffer.
        """
        answer = self._com.query(f"{self._base_command}?")
        form = self._format.structure

        return self._clean_data(answer, form)

    def get_latest(self) -> dict:
        """
        Read the latest data in the output buffer.

        :return: dict with the data in the buffer.
        """
        answer = self._com.query(f"{self._base_command}:LAT?")
        form = self._format.structure

        return self._clean_data(answer, form)

    @property
    def structure(self) -> Any:
        """
        Get the data format.

        :return: The data format.
        """
        return self._format.structure

    @structure.setter
    def structure(self, value: list[FormatElements]) -> None:
        """
        Set the data format.

        :param value: The new data format.
        """
        self._format.structure = value

    @property
    def format(self) -> None:
        msg = "The format property is deprecated, use structure instead."
        raise DeprecationWarning(msg)

    @format.setter  # noqa: A003
    def format(self, value: list[FormatElements]) -> None:  # noqa: ARG002
        msg = "The format property is deprecated, use structure instead."
        raise DeprecationWarning(msg)


class Input(_SenseBase):
    """
    Class providing functionality to control the voltage and current/charge
    input. A sub module must be provided as current/charge measurements are exclusive
    to each other. The aperture and its mode are used for both submodules.
    """

    def __init__(
        self,
        com: KeysightB2985AVisaCommunication,
        sens_module: SensCharge | SensCurrent | SensResistance,
    ) -> None:
        self.__dict__[sens_module._name] = sens_module
        self.current: SensCharge
        self.charge: SensCurrent
        self.resistance: SensResistance
        self._voltage = SensVoltage(com)
        self._current_input = _CurrentInput(com)
        super().__init__(com, sens_module._base_command, "input")

    @property
    def voltage(self) -> SensVoltage:
        return self._voltage

    @property
    def is_enabled(self) -> bool:
        """
        Get the state of the input.

        :return: True if the input is enabled, False otherwise.
        """
        return self._current_input.is_enabled

    @is_enabled.setter
    def is_enabled(self, value: bool) -> None:
        """
        Set the state of the input.

        :param value: True to enable the input, False to disable it.
        """
        self._current_input.is_enabled = value

    @property
    def is_zero_corrected(self) -> bool:
        """
        Get the state of the zero correction.

        :return: True if zero correction is enabled, False otherwise.
        """
        return self._current_input.is_zero_corrected

    @is_zero_corrected.setter
    def is_zero_corrected(self, value: bool) -> None:
        """
        Set the state of the zero correction.

        :param value: True to enable zero correction, False to disable it.
        """
        self._current_input.is_zero_corrected = value


class Output(_VoltageSourceBase):
    """
    Class providing intuitive functionality for the voltage output.
    """

    def __init__(self, com: KeysightB2985AVisaCommunication) -> None:
        self._output = _OutputBase(com, ":OUTP", "output_sub")
        super().__init__(com, ":SOUR:VOLT", "output")

    @property
    def is_enabled(self) -> bool:
        """
        Get the state of the output.

        :return: True if the output is enabled, False otherwise.
        """
        return self._output.is_enabled

    @is_enabled.setter
    def is_enabled(self, value: bool) -> None:
        """
        Set the state of the output.

        :param value: True to enable the output, False to disable it.
        """
        self._output.is_enabled = value

    @property
    def off_mode(self) -> OffMode:
        """
        Get the off mode of the output.

        :return: The off mode.
        """
        return self._output.off_mode

    @off_mode.setter
    def off_mode(self, value: OffMode) -> None:
        """
        Set the off mode of the output.

        :param value: The off mode to set.
        """
        self._output.off_mode = value

    @property
    def low_potential(self) -> LowPotential:
        """
        Get the low potential mode of the output.

        :return: The low potential mode.
        """
        return self._output.low_potential

    @low_potential.setter
    def low_potential(self, value: LowPotential) -> None:
        """
        Set the low potential mode of the output.

        :param value: The low potential mode to set.
        """
        self._output.low_potential = value


class Status:
    """
    Class providing access to the various status registers.
    """

    def __init__(self, com: KeysightB2985AVisaCommunication) -> None:
        self._com = com
        self.status_summary = _StatusSummary(com)
        self.measurement_status = _MeasStatusRegister(com)
        self.questionable_status = _QuesStatusRegister(com)
        self.operation_status = _OperStatusRegister(com)
        self.standard_event = _StandardEventRegister(com)

    def clear_registers(self) -> None:
        logger.info("Clear all registers")
        self._com.write("*CLS")


class Transition(_AcqTrans):
    """
    Class providing functionality for the transition system. To use this the source
    subsystem must be implemented fully first.
    """

    def __init__(self, com: KeysightB2985AVisaCommunication) -> None:
        super().__init__(com, ":TRAN", "transition")
