#  Copyright (c) ETH Zurich, SIS ID and HVL D-ITET
#
import logging

from aenum import StrEnum

from hvl_ccb.dev.keysightb298xx.modules.submodules.base import _BaseModule
from hvl_ccb.utils.validation import validate_bool, validate_number

logger = logging.getLogger(__name__)


class VoltageMode(StrEnum):
    """
    Voltage mode selection.
    """

    ARBITRARY = "ARB"
    FIXED = "FIX"
    SWEEP = "SWE"
    LIST = "LIST"


class VoltageRange(StrEnum):
    """
    Voltage range selection.
    """

    MINIMUM = "MIN"
    DEFAULT = "DEF"
    MAXIMUM = "MAX"


class _VoltageSourceBase(_BaseModule):
    """
    Base class for voltage source modules.
    """

    @property
    def voltage_mode(self) -> VoltageMode:
        """
        Get the voltage mode of the source.

        :return: The voltage mode.
        """
        return VoltageMode(self._com.query(f"{self._base_command}:MODE?"))

    @voltage_mode.setter
    def voltage_mode(self, value: VoltageMode) -> None:
        """
        Set the voltage mode of the source.

        :param value: The voltage mode to set.
        """
        value = VoltageMode(value)
        logger.info(f"Voltage mode: {value}")
        self._com.write(f"{self._base_command}:MODE {value}")

    @property
    def voltage(self) -> float:
        """
        Get the voltage level of the source.

        :return: The voltage level in V.
        """
        return float(self._com.query(f"{self._base_command}:LEV:IMM:AMPL?"))

    @voltage.setter
    def voltage(self, value: float) -> None:
        """
        Set the voltage level of the source.

        :param value: The voltage level in V.
        """
        value = self._value_checker(value)
        self._range = VoltageRange.MINIMUM if value < 0 else VoltageRange.MAXIMUM  # type: ignore[assignment]
        logger.info(f"Set voltage: {value} V")
        self._com.write(f"{self._base_command}:LEV:IMM:AMPL {value}")

    @property
    def _range(self) -> VoltageRange:
        return VoltageRange(self._com.query(f"{self._base_command}:RANG?"))

    @_range.setter
    def _range(self, value: VoltageRange) -> None:
        logger.debug(f"Set voltage range: {value}")
        self._com.write(f"{self._base_command}:RANG {value}")

    @property
    def use_r_series(self) -> bool:
        """
        Get the state of the R-series resistor.

        :return: True if the R-series resistor is enabled, False otherwise.
        """
        return bool(int(self._com.query(f"{self._base_command}:RLIM:STAT?")))

    @use_r_series.setter
    def use_r_series(self, value: bool) -> None:
        """
        Set the state of the R-series resistor.

        :param value: True to enable the R-series resistor, False to disable it.
        """
        validate_bool("R series", value, logger)
        logger.info(f"Use R series: {value}")
        self._com.write(f"{self._base_command}:RLIM:STAT {int(value)}")

    def _value_checker(self, value: float) -> float:
        # Check value to be in HW limits
        validate_number("Voltage Level", value, (-1000, 1000), (int, float), logger)
        return value
