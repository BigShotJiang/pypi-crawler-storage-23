# cyborgdb/client/__init__.py
"""Client module for CyborgDB."""
