from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import whisper


@dataclass
class TranscribeOptions:
    model_size: str = "medium"
    model_dir: str = ""
    language: Optional[str] = None
    task: str = "transcribe"


def ensure_model_available(opts: TranscribeOptions) -> None:
    whisper.load_model(opts.model_size, download_root=opts.model_dir)


def transcribe_file(path: str, opts: TranscribeOptions) -> str:
    model = whisper.load_model(opts.model_size, download_root=opts.model_dir)
    result = model.transcribe(
        path,
        language=opts.language,
        task=opts.task,
    )
    return str(result.get("text", "")).strip()
