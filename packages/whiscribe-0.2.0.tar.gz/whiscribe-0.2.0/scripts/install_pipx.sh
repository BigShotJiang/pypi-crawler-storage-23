#!/usr/bin/env bash
set -euo pipefail
pip install -U pipx
pipx ensurepath
pipx install .
echo "Installed. Run: whiscribe"
