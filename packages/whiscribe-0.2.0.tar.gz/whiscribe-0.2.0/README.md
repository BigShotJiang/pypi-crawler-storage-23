# Whiscribe

A cross-platform PyQt6 desktop app that:
- On startup checks a model directory for a Whisper model and downloads if missing (default: `medium`)
- Lets users upload audio/video or record audio
- Transcribes audio into text
- Lets users copy or export TXT/PDF/DOCX

## Install/run for development
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .\.venv\Scripts\Activate.ps1
pip install -U pip
pip install -e .
whiscribe
```

## Install/run for users (pipx)
This avoids packaging huge ML deps into an installer. Dependencies are installed at install time.
```bash
pip install -U pipx
pipx ensurepath
pipx install .
whiscribe
```

## Notes on dependencies
- Whisper depends on PyTorch; pip will install the appropriate wheels where available.
- Video input uses `imageio-ffmpeg` which provides an ffmpeg binary in most environments.

## Optional: pin/override torch
If you want explicit torch control, install torch first and then install whiscribe.
