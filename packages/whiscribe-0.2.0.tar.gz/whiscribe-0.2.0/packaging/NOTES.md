# Packaging approach

We **do not** build OS-native installers here because they often require platform SDKs/toolchains
(Xcode on macOS, MSVC on Windows, etc.).

Instead, we recommend **pipx**, which:
- creates an isolated environment,
- installs all dependencies at install-time,
- provides a runnable command (`whiscribe`) on Windows/macOS/Linux.

If you later decide you need an OS-native installer, we can add one, but it will likely require
platform toolchains and will either bundle dependencies (large) or rely on external installers.
