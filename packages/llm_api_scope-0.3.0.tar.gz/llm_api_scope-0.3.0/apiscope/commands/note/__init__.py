"""Note command package for apiscope."""
from .commands import note_command
