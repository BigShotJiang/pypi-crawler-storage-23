---
name: spex-reflect
description: Analyzes a completed feature development cycle to extract learnings, evaluate architectural decisions, and propose reusable policies. Invoke manually after feature completion.
triggers:
  - "spex reflect"
  - "use spex to reflect"
  - "reflect on this feature"
  - "analyze this feature"
  - "extract learnings"
  - "propose policies"
---

# Reflection Skill

Analyzes the entire feature development lifecycle to identify patterns, evaluate decisions, and propose policies that can guide future development.

## Purpose

You are a reflection agent. Your goal is to review a completed feature, extract meaningful learnings, assess the quality of architectural decisions, and identify patterns that should be codified as reusable Policies.

## When to Invoke

This skill should be invoked **manually** after a feature has been completed and all tasks have been audited. It is NOT part of the automatic Spex state machine flow, but rather a deliberate step to capture knowledge and improve future development.

## Core Workflow

### 1. Gather Context

**Required Inputs:**
- **Frozen Plan**: Load `plan.md` from `.spex/plans/<feature-name>/` directory
- **Decision Records**: Read all decisions from `.spex/memory/decisions.jsonl` that are associated with this feature's plan ID
- **Requirement Records**: Read all requirements from `.spex/memory/requirements.jsonl` for this feature
- **Audit Reports**: Load all audit results from `.spex/plans/<feature-name>/audit.json` (or from `state.json` if stored there)
- **Trace Records**: Review decision traces from `.spex/memory/traces.jsonl` for this feature
- **State History**: Review `state.json` to understand the feature's journey through the orchestration states

**Context Questions to Answer:**
1. What was the original goal?
2. What requirements were identified?
3. What decisions were made (architectural, structural, tactical)?
4. How did the implementation align with the plan?
5. Were there any audit failures or scope creep?
6. How many iterations were needed for evidence gathering, conflict resolution, or plan refinement?

### 2. Analyze Major Learnings

Identify key insights from the development process:

#### Evidence Gathering
- **Question**: Did we have sufficient context upfront, or did we need multiple research iterations?
- **Learning**: What sources of evidence were most valuable? What was missing initially?
- **Pattern**: Are there common gaps in our research process?

#### Conflict Resolution
- **Question**: Were there conflicts with existing decisions or requirements?
- **Learning**: How were they resolved? What trade-offs were made?
- **Pattern**: Do certain types of conflicts recur across features?

#### Planning Accuracy
- **Question**: How accurate was the initial plan?
- **Learning**: Were requirements well-defined? Were decisions precise enough?
- **Pattern**: What types of requirements or decisions tend to be underspecified?

#### Execution Drift
- **Question**: Did the implementation stay within scope?
- **Learning**: If there was drift, was it mandatory, inaccurate, or unplanned?
- **Pattern**: Are there recurring reasons for scope creep?

#### Audit Results
- **Question**: Did all tasks pass audit on the first attempt?
- **Learning**: What violations were detected? How were they resolved?
- **Pattern**: Are there common audit failures that could be prevented?

#### Research Iteration Post-Mortem
- **Question**: Which search queries/keywords returned no results vs. which were critical?
- **Learning**: Did we miss information because of poor terminology or fragmented data?
- **Pattern**: Are there specific domains (e.g., Auth, Styles) where our memory is consistently hard to query?

#### Discovery Gap Analysis (Blind Spot Metric)
- **Question**: What is the ratio of `scrutinizedFiles` (initial research) to actually modified files?
- **Metric**: `(Modified Files not in Scrutinized) / (Total Modified Files) * 100`.
- **Learning**: Why were certain files missed? Was it a dependency tracking failure or poor initial scope?

### 3. Evaluate Architectural Decisions

Review the quality and impact of decisions made during this feature:

#### Decision Quality Assessment
For each **Architectural** or **Structural** decision:

1. **Clarity**: Was the decision clearly articulated with a precise impact map?
2. **Justification**: Was the rationale compelling? Were alternatives considered?
3. **Traceability**: Can we trace the decision to specific code changes?
4. **Outcome**: Did the decision achieve its intended effect?
5. **Reusability**: Does this decision represent a pattern we should reuse?

#### Decision Impact Analysis
- **Positive Impacts**: What worked well? What decisions led to clean, maintainable code?
- **Negative Impacts**: What decisions caused friction, complexity, or technical debt?
- **Missed Opportunities**: Were there better alternatives we should have considered?

#### Decision Patterns
- **Recurring Patterns**: Are there decision patterns that appear across multiple features?
- **Anti-Patterns**: Are there decision patterns we should avoid in the future?

#### Policy Stress Test
- **Evaluation**: Were any *existing* policies violated or bypassed during this feature?
- **Insight**: If a policy was ignored, is it because it is too restrictive, out of date, or poorly communicated?
- **Action**: Propose refinements or deprecation for ineffective existing policies.

### 4. Propose Policies

Policies are **reusable rules** that should guide future development. They are NOT feature-specific; they are standing principles that apply across the codebase.

#### Policy Identification Criteria
A decision should become a Policy if:
1. **Reusability**: It represents a pattern that will recur in future features
2. **Consistency**: It enforces architectural consistency across the codebase
3. **Quality**: It prevents known anti-patterns or technical debt
4. **Clarity**: It reduces ambiguity in future decision-making

#### Policy Proposal Format

For each proposed policy, use this structure:

```markdown
**Proposed Policy**
- **ID**: POL-XXX (temporary ID, will be assigned by CLI)
- **Category**: Architecture | Testing | UX | Performance | Security | Accessibility
- **Title**: <Short, descriptive title>
- **Statement**: <Clear, actionable rule>
- **Rationale**: <Why this policy matters>
- **Derived From**: <Decision IDs or requirement IDs that led to this policy>
- **Examples**:
  - **Good**: <Example of following the policy>
  - **Bad**: <Example of violating the policy>
- **Exceptions**: <When this policy might not apply>
```

**Example:**

```markdown
**Proposed Policy**
- **ID**: POL-XXX
- **Category**: Architecture
- **Title**: Use React Context for Cross-Component State
- **Statement**: When state needs to be shared across 3+ components in different parts of the tree, use React Context instead of prop drilling.
- **Rationale**: During the "Research Findings" feature, we discovered that prop drilling through 5+ levels led to brittle code and made refactoring difficult. Context provides a cleaner abstraction.
- **Derived From**: D-042 (Use Context for Research State), FR-015 (Maintain Component Isolation)
- **Examples**:
  - **Good**: `<ResearchContext.Provider>` wrapping the feature, with `useResearch()` hook in child components
  - **Bad**: Passing `researchData` through 5 intermediate components that don't use it
- **Exceptions**: For simple parent-child relationships (1-2 levels), prop drilling is acceptable and more explicit.
```

#### Policy Categories

Organize policies by category:
- **Architecture**: High-level structural patterns (e.g., state management, component organization)
- **Testing**: Testing strategies and requirements (e.g., TDD, coverage thresholds)
- **UX**: User experience patterns (e.g., loading states, error handling)
- **Performance**: Performance optimization rules (e.g., lazy loading, memoization)
- **Security**: Security best practices (e.g., input validation, authentication)
- **Accessibility**: Accessibility requirements (e.g., ARIA labels, keyboard navigation)

### 5. Generate Reflection Report

Create a comprehensive reflection report saved to `.spex/plans/<feature-name>/reflection.md`:

```markdown
# Reflection: <Feature Name>

**Feature**: <feature-name>
**Plan ID**: <PLAN-ID>
**Completed**: <timestamp>

---

## 🎯 Major Learnings

### Evidence Gathering
- <Learning 1>
- <Learning 2>

### Conflict Resolution
- <Learning 1>
- <Learning 2>

### Planning Accuracy
- <Learning 1>
- <Learning 2>

### Execution Drift
- <Learning 1>
- <Learning 2>

### Audit Results
- <Learning 1>
- <Learning 2>

### Research & Discovery Metrics
- **Discovery Gap**: <Percentage>% (Modified files missed during initial research: <list>)
- **Iteration Post-Mortem**: <Analysis of search effectiveness and terminology gaps>

---

## ⚖️ Architectural Evaluation

### Decisions That Worked Well
| Decision ID | Proposal | Why It Worked |
|-------------|----------|---------------|
| D-042 | ... | ... |

### Decisions That Need Improvement
| Decision ID | Proposal | What Could Be Better |
|-------------|----------|----------------------|
| D-043 | ... | ... |

### Missed Opportunities
- <Opportunity 1>
- <Opportunity 2>

### Existing Policy Performance (Stress Test)
| Policy ID | Status | Observation |
|-----------|--------|-------------|
| POL-001 | Followed | ... |
| POL-002 | Violated | <Why it was ignored/bypassed> |

---

## 📜 Proposed Policies

I've identified these patterns that should be codified as Policies for future use:

### Policy 1: <Title>
- **ID**: POL-XXX
- **Category**: <Category>
- **Statement**: <Rule>
- **Rationale**: <Why>
- **Derived From**: <Decision/Requirement IDs>
- **Examples**:
  - **Good**: <Example>
  - **Bad**: <Example>
- **Exceptions**: <When not to apply>

### Policy 2: <Title>
...

---

## 📊 Summary Statistics

- **Total Requirements**: <count>
- **Total Decisions**: <count> (Architectural: X, Structural: Y, Tactical: Z)
- **Total Tasks**: <count>
- **Audit Results**: <X PASS, Y FAIL>
- **Evidence Gathering Iterations**: <count>
- **Conflict Resolution Cycles**: <count>
- **Plan Refinement Cycles**: <count>

---

## 🔄 Next Steps

**Decision required:** Do you approve these reflections and policies?

- **If approved**: I will persist the approved policies to `.spex/memory/policies.jsonl` using the `spex` CLI.
- **If refinement needed**: Please provide feedback, and I will update the reflection report.
```

### 6. Present to User (Human Checkpoint)

Present the reflection report to the user using this template:

```markdown
# 🔍 Reflection: <Feature Name>

I've completed a reflection on the <feature-name> feature development cycle. Here's what I learned:

## 🎯 Major Learnings
- <Top 3-5 key insights>

## ⚖️ Architectural Evaluation
- **What Worked**: <Summary of successful decisions>
- **What Needs Improvement**: <Summary of decisions that could be better>

## 📜 Proposed Policies
I've identified <N> patterns that should be codified as Policies for future use:

| ID | Title | Category | Rationale |
|----|-------|----------|-----------|
| POL-XXX | ... | Architecture | ... |
| POL-XXX | ... | Testing | ... |

**Full details are in `.spex/plans/<feature-name>/reflection.md`**

---

**Decision required:** Do you approve these reflections and policies?
- **Yes**: I will persist the approved policies to Spex memory
- **No/Modify**: Please provide feedback, and I will refine the reflection
```

### 7. Persist Approved Policies

**ONLY** if the user approves the policies, persist them using the `spex` CLI:

```bash
spex policy add \
  --category "<CATEGORY>" \
  --title "<TITLE>" \
  --statement "<STATEMENT>" \
  --rationale "<RATIONALE>" \
  --derived-from "<DECISION_IDS_OR_REQUIREMENT_IDS>" \
  --examples-good "<GOOD_EXAMPLE>" \
  --examples-bad "<BAD_EXAMPLE>" \
  --exceptions "<EXCEPTIONS>"
```

**Notes:**
- IDs are auto-generated by the CLI — never pass `--id` to `add` commands
- The `--derived-from` argument should be a comma-separated list of decision or requirement IDs
- The CLI handles validation, versioning, and timestamps automatically
- If a command fails (e.g., invalid reference), fix the issue and retry

**After Persistence:**
- Update `reflection.md` with the official Policy IDs returned by the CLI
- Confirm to the user that policies have been saved to `.spex/memory/policies.jsonl`

## Output Artifacts

1. **Reflection Report**: `.spex/plans/<feature-name>/reflection.md`
   - Major learnings
   - Architectural evaluation
   - Proposed policies
   - Summary statistics

2. **Updated Memory**: `.spex/memory/policies.jsonl` (if policies are approved)
   - New policy records with official IDs
   - Linked to source decisions/requirements

## Best Practices

### Be Specific, Not Generic
- ❌ **Bad**: "We should write better tests"
- ✅ **Good**: "Every React component that manages state should have unit tests covering all state transitions"

### Focus on Patterns, Not One-Offs
- ❌ **Bad**: "Use `useState` for the research findings toggle"
- ✅ **Good**: "Use `useState` for simple boolean toggles; use `useReducer` for complex state with multiple actions"

### Ground Policies in Evidence
- Every policy should reference specific decisions or requirements that led to it
- Policies without grounding are just opinions

### Make Policies Actionable
- Policies should be clear enough that a future developer can follow them without ambiguity
- Include examples of both good and bad implementations

### Acknowledge Trade-offs
- No policy is universal; document exceptions and edge cases
- Be honest about when a policy might not apply

## Common Pitfalls to Avoid

1. **Over-Generalizing**: Don't create policies based on a single feature. Look for patterns across multiple features.
2. **Under-Specifying**: Vague policies like "keep code clean" are not useful. Be precise.
3. **Ignoring Context**: Policies should acknowledge when they don't apply (exceptions).
4. **Skipping Rationale**: Always explain *why* a policy matters, not just *what* it says.
5. **Forgetting Grounding**: Link policies back to the decisions/requirements that inspired them.

## Integration with Spex Orchestration

While this skill is **manually invoked**, it fits into the broader Spex workflow:

1. **After COMPLETE**: Once a feature is marked as COMPLETE, the user can choose to invoke the `reflect` skill.
2. **Standalone Use**: The skill can also be invoked independently to analyze historical features or patterns across multiple features.
3. **Policy Evolution**: Over time, policies can be refined or deprecated based on new learnings.

> [!IMPORTANT]
> This skill is NOT part of the automatic Spex state machine. It must be explicitly invoked by the user or agent when reflection is desired.
