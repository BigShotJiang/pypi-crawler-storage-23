# DEPRECATED

This file has been split into two separate, purpose-specific procedures:

- **[memory-routing.md](memory-routing.md)** — Lightweight routing check (keyword search, logic drift, policy check). Used in SKILL.md Step 1 for flow classification and in knowledge-capture CAPTURE_CHECK. No blame, no impact discovery.

- **[memory-analysis.md](memory-analysis.md)** — Full post-code analysis (blame, orphaning, extended keywords, impact discovery). Used inside the RESEARCH state in orchestration-guide.md.

Do not use this file. Read the appropriate procedure above instead.
