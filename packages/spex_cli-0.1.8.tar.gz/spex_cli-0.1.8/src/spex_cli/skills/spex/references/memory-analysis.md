# Memory Analysis Procedure

This procedure performs a deep technical memory analysis **during the RESEARCH phase**. It uses `spex blame` and `spex impact` to connect the physical code you are modifying to the historical decisions that created it.

> [!CAUTION]
> Run this procedure only after `scrutinizedFiles` have been identified. Do not skip any step.

## Output Contract (MANDATORY)

Before exiting you MUST populate the `memory` section of `research.json`.

---

## Step 1: Blame on Scrutinized Files

Run blame on every file in `scrutinizedFiles` from `research.json` to discover which historical decisions and requirements govern this code:

```bash
spex blame <file1> <file2> ...
```

> **TRUNCATION RULE**: If output exceeds tool limits and is saved to a file, you MUST read the full saved file. Partial blame = no blame.

---

## Step 2: Extract IDs + Orphaning Check

### 2a. Extract all requirement and decision IDs from blame output

Identify every `FR-`, `NFR-`, `CR-`, `UR-`, and `D-` ID found in the blame output.

### 2b. Orphaning check (Crucial for DELETIONS/REFACTORS)

If your plan involves deleting or heavily modifying code, for every ID from 2a answer: **does any surviving code (code not being removed) still satisfy this requirement or depend on this decision?**

Any **NO** = Orphaning conflict. You must document this in the `conflicts` section of `research.json` and flag it as an Open Question for the user.

---

## Step 3: Technical Conflict Discovery

Cross-reference the physical constraints of the code (data flows, limits) with the historical decisions and requirements. 

Search memory (`requirements.jsonl`, `decisions.jsonl`, `policies.jsonl`) for any components, variables, or patterns discovered in the code.

Are you proposing a change that contradicts an existing Decision (e.g., adding a cache when `D-012` explicitly rejected a cache)?
- If **YES**, this is a Technical Conflict (Logic Drift / Incompatibility).

---

## Step 4: Impact Discovery (MANDATORY when any conflict or orphaning exists)

For every technical conflict or orphaning risk found in Steps 2 and 3:

```bash
spex impact <conflicting-id>
```

Identify:
- **Upstream**: Requirements that will become unsatisfied.
- **Downstream**: Decisions built on this truth that will be destabilized.
- **Physical**: Files and code traces that must be refactored.

Do not proceed until every conflict has a complete impact radius mapped.

---

## Step 5: Populate research.json Memory Section

Update `.spex/<feature-name>/research.json` — populate the `memory` section:

```json
{
  "memory": {
    "conflicts": [
      {
        "severity": "blocking | warning",
        "type": "Incompatibility | Redundancy | Regression | Logic Drift | Orphaning",
        "message": "string",
        "existingId": "string",
        "impact_radius": {
          "upstream": [{"id": "string", "type": "string", "description": "string"}],
          "downstream": [{"id": "string", "type": "string", "proposal": "string"}],
          "traces": [{"traceId": "string", "commitHashes": ["string"]}]
        }
      }
    ],
    "grounding": [
      {"id": "string", "description": "string", "link": "string"}
    ],
    "leverage": [
      {"id": "string", "suggestion": "string"}
    ]
  }
}
```
