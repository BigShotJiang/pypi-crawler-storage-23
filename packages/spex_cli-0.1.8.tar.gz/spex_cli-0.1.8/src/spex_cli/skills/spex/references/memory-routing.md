# Memory Routing Procedure

This procedure performs a lightweight memory check to determine blast radius for flow selection. It runs **before code research** and **before any implementation**.

It checks for keyword-based conflicts, logic drift, and policy violations using only the goal description. Orphaning detection (which requires knowing which files will be modified) is deferred to the RESEARCH state.

> [!CAUTION]
> This procedure is unconditional. Run it verbatim every time. Do not skip any step.

## Output Contract (MANDATORY)

Before exiting you MUST produce this exact summary block AND save `routing-cache.json`.

```
ROUTING CHECK FINDINGS
-----------------------
Keywords used        : [list keywords derived from goal]
Keyword hits         : [NONE | <ID>: <matched term>]
Logic Drift          : [NONE | <ID>: rejected alternative matched — "<text>"]
Policy conflicts     : [NONE | <ID>: <reason>]

Contrast Matrix
  Incompatibility (Direct) : NONE | FOUND: ...
  Redundancy               : NONE | FOUND: ...
  Regression (Implicit)    : NONE | FOUND: ...
  Logic Drift              : NONE | FOUND: ...
  Orphaning (Deletion)     : DEFERRED — evaluated in RESEARCH state

BLAST RADIUS : LOW | HIGH
Reason       : ...
```

---

## Step 1: Load Context

```bash
cat .spex/memory/apps.jsonl | jq -rc 'select(.status == "active")'

cat .spex/memory/decisions.jsonl \
  | jq -rc 'select(.status == "active" and (.decisionClass == "architectural")'

cat .spex/memory/policies.jsonl | jq -rc 'select(.status == "active")'
```

---

## Step 2: Keyword Search

Derive **at least 3 keywords** from the goal: nouns, feature names, UI terms, route names, component names.

**Search requirements:**
```bash
cat .spex/memory/requirements.jsonl | jq -rc 'select(.status == "active")' \
  | grep -i "KEYWORD1\|KEYWORD2\|KEYWORD3"
```

**Search decisions:**
```bash
cat .spex/memory/decisions.jsonl | jq -rc 'select(.status == "active")' \
  | grep -i "KEYWORD1\|KEYWORD2\|KEYWORD3"
```

Log every hit.

---

## Step 3: Logic Drift Check

Search the `alternatives` field of every active decision for keywords from the goal. This detects proposals that were previously considered and **explicitly rejected**.

```bash
cat .spex/memory/decisions.jsonl \
  | jq -rc 'select(.status == "active") | {id, alternatives}' \
  | grep -i "KEYWORD1\|KEYWORD2\|KEYWORD3"
```

Any match where the current goal maps to a rejected path = **Logic Drift conflict**. Log the decision ID and the rejected text.

---

## Step 4: Policy Check

```bash
cat .spex/memory/policies.jsonl | jq -rc 'select(.status == "active")' \
  | grep -i "KEYWORD1\|KEYWORD2\|KEYWORD3"
```

Also review the full active policy list loaded in Step 1 for any policy governing the patterns or domain being changed — even if keywords don't match literally.

---

## Step 5: Contrast Matrix

Evaluate every archetype. Write an answer for each — blank entries are not allowed.

| Archetype | Detection Signal | Your Finding |
|-----------|-----------------|--------------|
| **Incompatibility (Direct)** | Goal violates an active Policy or Architectural Decision | `NONE` or `FOUND: <ID> — <reason>` |
| **Redundancy** | Goal overlaps >80% with an existing active requirement or feature | `NONE` or `FOUND: <ID> — <reason>` |
| **Regression (Implicit)** | Goal touches a domain governed by an NFR or Invariant | `NONE` or `FOUND: <ID> — <reason>` |
| **Logic Drift** | Proposal matches a rejected Alternative in a past Decision | `NONE` or `FOUND: <ID> — "<rejected text>"` |
| **Orphaning (Deletion)** | Cannot be evaluated without blame. | `DEFERRED` |

---

## Step 6: Blast Radius Assessment

Blast radius is **HIGH** if **any** of the following are true:

1. Any active Structural or Architectural decision contradicted (Steps 2, 5)
2. Any active Policy violated (Steps 4, 5)
3. Any Logic Drift found — proposal matches a rejected alternative (Step 3)
4. Redundancy >80% overlap found (Steps 2, 5)

Write the verdict:

```
BLAST RADIUS: HIGH
Reason: D43 contradicted (explicitly rejected "separate dashboard page")
```

or:

```
BLAST RADIUS: LOW
Reason: No conflicts found. Orphaning deferred to RESEARCH state.
```

---

## Step 7: Save Routing Cache

Save findings to `.spex/<feature-name>/routing-cache.json`:

```json
{
  "timestamp": "<ISO timestamp>",
  "keywords": ["<keyword1>", "<keyword2>", "<keyword3>"],
  "blastRadius": "LOW | HIGH",
  "reason": "<reason>",
  "findings": {
    "keywordHits": [{"id": "<ID>", "matchedTerm": "<term>", "type": "requirement | decision"}],
    "logicDriftHits": [{"id": "<ID>", "rejectedText": "<text>"}],
    "policyConflicts": [{"id": "<ID>", "reason": "<reason>"}],
    "contrastMatrix": {
      "incompatibility": "NONE | FOUND: ...",
      "redundancy": "NONE | FOUND: ...",
      "regression": "NONE | FOUND: ...",
      "logicDrift": "NONE | FOUND: ...",
      "orphaning": "DEFERRED"
    }
  }
}
```
