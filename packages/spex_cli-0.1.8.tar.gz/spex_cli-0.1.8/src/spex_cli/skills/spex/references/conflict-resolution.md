# Conflict Resolution Procedure

This procedure is used to handle contradictions, redundancies, or risks identified during memory research or auditing.

## Goal
Ensure the Spex memory remains a "Single Source of Truth" without stale, conflicting, or redundant entries.

## Resolution Strategies

When a conflict is detected, present it to the human with the following options:

1.  **Override**: The new direction is correct. Deprecate the existing memory item and persist the new one.
2.  **Merge**: The existing item and new item are both partially correct. Combine them into a new version, deprecate the old one, and persist the merged result.
3.  **Cancel**: The existing memory item is correct. Reject the new proposal and maintain the current state.
4.  **Refine**: The new proposal can be adjusted to avoid the conflict while still satisfying the goal.

## Orphaning Conflicts (Deletion chains)

When an **Override** is chosen for an Orphaning conflict, the cleanup is a chain — not a single item:
1. Deprecate all Requirements that are now unsatisfied.
2. Deprecate all Decisions whose `satisfies` pointed to those requirements.
3. Verify no other active Requirement still references the deprecated items via `satisfies`.
4. Only then is the deletion considered memory-clean.

> Leaving requirements as "active" with no satisfying code is a silent lie in the knowledge model.

## Detailed Procedure

### 1. Present Options

**Grouping rule**: Before presenting, group conflicts by subject (e.g. all conflicts touching the same feature, page, or requirement chain). Present one group at a time. Do NOT dump all conflicts in a single message.

**For each group, use the `AskUserQuestion` tool** with:
- `question`: a concise summary of the conflict group (e.g. "Conflict 1 of 3 — D38 + FR-034: Governance route. How should this be resolved?")
- `options`: one option per resolution strategy relevant to this conflict (Override, Cancel, Merge, or Refine), each with a short description of its cleanup cost.

For each conflict (or group) show in the message body:
*   **The Discrepancy**: "Goal says X, but existing Decision [D-XXX] says Y."
*   **The Impact Radius**: Summarize the `impact_radius` from research:
    *   **Orphaned Requirements**: "Overriding this will leave [FR-XXX] unsatisfied."
    *   **Destabilized Decisions**: "Decisions [D-YYY] and [D-ZZZ] were built on this truth."
    *   **Physical Debt**: "Traces show this affects code in 3 files."
*   **Rationale for Conflict**: Why the friction exists (Matrix type and evidence).

Wait for the user's answer before presenting the next conflict or group.

### 2. Execute Resolution
Once the user selects a strategy, use the `spex` CLI to update memory:
*   **Deprecate**: `spex decision deprecate --id <ID>`, `spex requirement deprecate --id <ID>` `spex policy deprecate --id <ID>`
*   **Update**: `spex requirement update --id <ID> ...`
*   **Add**: Use the standard `add` commands for the new or merged items.

### 3. Verify Side Effects
*   Check if the resolution broke any "Satisfies" links.
*   Warn the user if a resolved conflict leaves orphaned items (e.g., a Decision pointing to a now-deprecated Requirement).
