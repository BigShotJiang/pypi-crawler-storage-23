AGENT_CONFIG = {
    "claude": {
        "name": "Claude Code",
        "folder": ".claude/",
        "settings_file": "claude_settings/settings.json",
    },
    "gemini": {
        "name": "Gemini CLI",
        "folder": ".gemini/",
        "settings_file": "claude_settings/settings.json"
    },
    "cursor-agent": {
        "name": "Cursor",
        "folder": ".cursor/",
        "settings_file": "claude_settings/settings.json"
    },
    "opencode": {
        "name": "opencode",
        "folder": ".opencode/"
    },
    "codex": {
        "name": "Codex CLI",
        "folder": ".codex/"
    },
    "agy": {
        "name": "Antigravity",
        "folder": ".agent/"
    },
    "copilot": {
        "name": "GitHub Copilot",
        "folder": ".github/"
    }
}