import streamlit as st
import json
import pandas as pd
import plotly.express as px
from pathlib import Path

# Page configuration
st.set_page_config(
    page_title="Spex Memory", 
    layout="wide", 
    initial_sidebar_state="expanded"
)

# Custom CSS for our exact color palette
st.markdown("""
<style>
    /* Global Background */
    .stApp {
        background-color: #0D1117;
        color: #E5E7EB;
    }
    
    /* Headlines */
    h1, h2, h3, h4, h5, h6 {
        color: #FFFFFF !াবাহ;
        font-family: 'Inter', sans-serif;
    }
    
    /* Sidebar */
    [data-testid="stSidebar"] {
        background-color: #161B22;
        border-right: 1px solid #30363D;
    }
    
    /* Cards / Containers */
    div.stElementContainerContainer, div.stVerticalBlock > div {
        /* border-color: #30363D !important; */
    }
    
    .st-emotion-cache-16idsys {
        background-color: #161B22;
        border: 1px solid #30363D;
        border-radius: 8px;
    }

    /* Metric Cards Override */
    [data-testid="stMetricValue"] {
        color: #F97316;
    }
    
    /* Buttons and UI Elements */
    .stButton>button {
        background-color: #F97316;
        color: white;
        border-radius: 4px;
        border: none;
    }
    
    .stButton>button:hover {
        background-color: #8B5CF6;
        color: white;
    }

    /* Tabs */
    .stTabs [data-baseweb="tab-list"] {
        gap: 24px;
        background-color: transparent;
    }

    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: transparent;
        border-radius: 4px 4px 0px 0px;
        gap: 1px;
        padding-top: 10px;
        padding-bottom: 10px;
        color: #9CA3AF;
    }

    .stTabs [aria-selected="true"] {
        color: #F97316 !important;
        border-bottom: 2px solid #F97316 !important;
    }

    /* Input Fields */
    .stTextInput input {
        background-color: #1C2128 !important;
        border: 1px solid #30363D !important;
        color: #FFFFFF !important;
    }
    
    /* Metric Card Styling */
    div[data-testid="metric-container"] {
        background-color: #161B22;
        border: 1px solid #30363D;
        padding: 15px;
        border-radius: 10px;
    }

    /* Tooltip / Popover */
    .spex-tooltip {
        position: relative;
        display: inline-block;
        cursor: help;
        border-bottom: 1px dotted #9CA3AF;
        color: #60A5FA;
        font-weight: 500;
    }
    .spex-tooltip .spex-tooltiptext {
        visibility: hidden;
        width: max-content;
        max-width: 300px;
        background-color: #161B22;
        color: #E5E7EB;
        text-align: left;
        border-radius: 6px;
        padding: 10px 14px;
        position: absolute;
        z-index: 1000;
        bottom: 125%;
        left: 50%;
        transform: translateX(-50%);
        opacity: 0;
        transition: opacity 0.2s;
        border: 1px solid #30363D;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.4);
        font-size: 0.85rem;
        font-weight: normal;
        white-space: normal;
        line-height: 1.5;
    }
    .spex-tooltip:hover .spex-tooltiptext {
        visibility: visible;
        opacity: 1;
    }

    /* Expandable Cards */
    details > summary {
        list-style: none;
        outline: none;
    }
    details > summary::-webkit-details-marker {
        display: none;
    }

    /* Commit History Style */
    .timeline-header {
        color: #9CA3AF;
        font-size: 0.9rem;
        margin: 24px 0 8px 0;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .commit-group {
        border: 1px solid #30363D;
        border-radius: 6px;
        background-color: transparent;
        margin-bottom: 24px;
        overflow: hidden;
    }
    .commit-item {
        border-bottom: 1px solid #30363D;
        background-color: transparent;
    }
    .commit-item:last-child {
        border-bottom: none;
    }
    .commit-item > summary {
        padding: 12px 16px;
        cursor: pointer;
        display: flex;
        flex-direction: column;
        gap: 4px;
        transition: background-color 0.2s;
    }
    .commit-item > summary:hover {
        background-color: #161B22;
    }
</style>
""", unsafe_allow_html=True)

def load_jsonl(filepath):
    """Load items from a JSONL file into a list of dictionaries."""
    if not Path(filepath).exists():
        return []
    items = []
    with open(filepath, 'r') as f:
        for line in f:
            if line.strip():
                try:
                    items.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return items

def get_latest_versions(items):
    """Filter to only the latest version of each ID."""
    if not items:
        return []
    
    latest = {}
    for item in items:
        item_id = item.get('id')
        version = item.get('version', 1)
        if item_id not in latest or version > latest[item_id].get('version', 0):
            latest[item_id] = item
    return list(latest.values())

def main():
    # Load data
    base_path = Path(".spex/memory")
    req_items = load_jsonl(base_path / "requirements.jsonl")
    dec_items = load_jsonl(base_path / "decisions.jsonl")
    pol_items = load_jsonl(base_path / "policies.jsonl")
    plan_items = load_jsonl(base_path / "plans.jsonl")

    # Filter to latest versions
    requirements = get_latest_versions(req_items)
    decisions = get_latest_versions(dec_items)
    policies = get_latest_versions(pol_items)
    plans = get_latest_versions(plan_items)

    # Assign types for identification
    for r in requirements:
        r["item_type"] = "Requirements"
    for d in decisions:
        d["item_type"] = "Decisions"
    for p in policies:
        p["item_type"] = "Policies"
    for pl in plans:
        pl["item_type"] = "Plans"

    all_items = requirements + decisions + policies + plans
    df = pd.DataFrame(all_items)

    # Header with Member Name
    params = st.query_params
    member_name = params.get("member", "Team Contributions")
    st.title(f"Memory: {member_name}")

    if df.empty:
        st.info("No contributions found in spex memory.")
        return

    # Ensure createdAt is a datetime object
    df['createdAt'] = pd.to_datetime(df['createdAt'], errors='coerce')

    # Build dictionary for description popovers
    id_to_desc = {}
    for _, row in df.iterrows():
        item_id = row.get('id')
        if not item_id or (isinstance(item_id, float) and pd.isna(item_id)):
            continue
        t_name = row.get('item_type')
        if t_name == 'Decisions':
            desc = row.get('proposal', 'Untitled')
        elif t_name == 'Plans':
            desc = row.get('featureName', 'Untitled')
        else:
            desc = row.get('description', 'Untitled')
        id_to_desc[str(item_id)] = str(desc)

    def format_satisfies(satisfies_val):
        if not satisfies_val or (isinstance(satisfies_val, float) and pd.isna(satisfies_val)):
            return None
        
        s_list = satisfies_val if isinstance(satisfies_val, list) else [satisfies_val]
        formatted = []
        for s_id in s_list:
            if not s_id or (isinstance(s_id, float) and pd.isna(s_id)):
                continue
            
            s_id_str = str(s_id).strip()
            if not s_id_str or s_id_str.lower() == 'nan':
                continue
                
            desc = id_to_desc.get(s_id_str, "Description not found")
            safe_desc = desc.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')
            html = f'<span class="spex-tooltip">{s_id_str}<span class="spex-tooltiptext">{safe_desc}</span></span>'
            formatted.append(html)
            
        return ", ".join(formatted) if formatted else None

    # --- SIDEBAR FILTERS ---
    st.sidebar.title("Filters")
    
    # Author Filter (Pre-select if in URL)
    authors = sorted(df['author'].dropna().unique().tolist())
    default_authors = []
    if "member" in params:
        param_member = params["member"]
        if param_member in authors:
            default_authors = [param_member]
    selected_authors = st.sidebar.multiselect("Authors", options=authors, default=default_authors)
    
    # Scope Filter
    scopes = set()
    for s_list in df['scope'].dropna():
        if isinstance(s_list, list):
            scopes.update(s_list)
    selected_scopes = st.sidebar.multiselect("Scope", options=sorted(list(scopes)))
    
    # Decision Class Filter
    dec_classes = sorted(df[df['item_type'] == 'Decisions']['decisionClass'].dropna().unique().tolist())
    selected_dec_classes = st.sidebar.multiselect("Decision Class", options=dec_classes)
    
    # Requirement Type Filter
    req_types = sorted(df[df['item_type'] == 'Requirements']['type'].dropna().unique().tolist())
    selected_req_types = st.sidebar.multiselect("Requirement Type", options=req_types)

    # Status Filter
    statuses = sorted(df['status'].dropna().unique().tolist())
    selected_statuses = st.sidebar.multiselect("Status", options=statuses)

    # --- FILTER LOGIC ---
    filtered_df = df.copy()
    
    if selected_authors:
        filtered_df = filtered_df[filtered_df['author'].isin(selected_authors)]
    if selected_scopes:
        filtered_df = filtered_df[filtered_df['scope'].apply(lambda x: any(s in x for s in selected_scopes) if isinstance(x, list) else False)]
    if selected_dec_classes:
        filtered_df = filtered_df[(filtered_df['item_type'] != 'Decisions') | (filtered_df['decisionClass'].isin(selected_dec_classes))]
    if selected_req_types:
        filtered_df = filtered_df[(filtered_df['item_type'] != 'Requirements') | (filtered_df['type'].isin(selected_req_types))]
    if selected_statuses:
        filtered_df = filtered_df[filtered_df['status'].isin(selected_statuses)]

    # --- ACTIVITY GRAPH ---
    st.markdown("<div style='margin-top: 40px;'></div>", unsafe_allow_html=True)
    st.subheader("Engagement & Activity")
    st.markdown("<div style='color: #9CA3AF; font-size: 0.9rem; margin-bottom: 20px;'>Visualize contribution frequency and focus areas over time.</div>", unsafe_allow_html=True)
    
    graph_df = filtered_df.dropna(subset=['createdAt']).copy()
    if not graph_df.empty:
        graph_df['date'] = graph_df['createdAt'].dt.date
        
        # Define color map for consistency
        color_map = {
            'Requirements': '#FBBF24', # Amber Gold
            'Decisions': '#F97316',    # Vibrant Orange
            'Plans': '#8B5CF6',        # Electric Purple
            'Policies': '#EC4899'      # Magenta Pink
        }

        # Breakdown Tabs
        g_tab1, g_tab2, g_tab3 = st.tabs(["📈 Total Activity", "🏷️ By Type", "🎯 By Scope"])
        
        with g_tab1:
            chart_data = graph_df.groupby('date').size().reset_index(name='items')
            fig = px.bar(chart_data, x='date', y='items', color_discrete_sequence=['#F97316'],
                         template="plotly_dark", labels={'items': 'Contributions', 'date': 'Date'})
            fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', font_color='#E5E7EB', margin=dict(l=0, r=0, t=20, b=0))
            st.plotly_chart(fig, use_container_width=True, key="total_graph")

        with g_tab2:
            chart_data = graph_df.groupby(['date', 'item_type']).size().reset_index(name='items')
            fig = px.bar(chart_data, x='date', y='items', color='item_type', 
                         color_discrete_map=color_map,
                         template="plotly_dark", labels={'items': 'Contributions', 'date': 'Date', 'item_type': 'Category'})
            fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', font_color='#E5E7EB', margin=dict(l=0, r=0, t=20, b=0))
            st.plotly_chart(fig, use_container_width=True, key="type_graph")

        with g_tab3:
            exploded_df = graph_df.explode('scope')
            chart_data = exploded_df.groupby(['date', 'scope']).size().reset_index(name='items')
            fig = px.bar(chart_data, x='date', y='items', color='scope',
                         template="plotly_dark", labels={'items': 'Contributions', 'date': 'Date', 'scope': 'Scope'})
            fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', font_color='#E5E7EB', margin=dict(l=0, r=0, t=20, b=0))
            st.plotly_chart(fig, use_container_width=True, key="scope_graph")
    else:
        st.info("No contribution data found for activity chart.")

    # --- UNIVERSAL SEARCH & SORT ---
    st.markdown("---")
    col_search, col_sort = st.columns([4, 1])
    with col_search:
        search_query = st.text_input("Search contributions...", placeholder="Keyword search across all types...", key="universal_search", label_visibility="collapsed")
    with col_sort:
        sort_newest = st.toggle("Newest First", value=True)
    
    if search_query:
        # Filter all columns for keywords
        mask = filtered_df.astype(str).apply(lambda x: x.str.contains(search_query, case=False)).any(axis=1)
        filtered_df = filtered_df[mask]

    # Re-sort
    filtered_df = filtered_df.sort_values(by='createdAt', ascending=not sort_newest)

    # --- TABS ---
    tab_list = ["Decisions", "Requirements", "Plans", "Policies"]
    tab_titles = [f"{t} ({len(filtered_df[filtered_df['item_type'] == t])})" for t in tab_list]
    tabs = st.tabs(tab_titles)
    
    for i, t_name in enumerate(tab_list):
        with tabs[i]:
            items = filtered_df[filtered_df['item_type'] == t_name]
            if items.empty:
                st.write(f"No {t_name.lower()} found.")
            else:
                # Group items by date
                grouped = items.groupby(items['createdAt'].dt.date, sort=False)
                for date_val, group_items in grouped:
                    date_str = date_val.strftime('%b %d, %Y') if pd.notnull(date_val) else 'Unknown Date'
                    st.markdown(
                        f'<div class="timeline-header">'
                        f'<svg viewBox="0 0 16 16" width="16" height="16" fill="#9CA3AF"><path d="M11.93 8.5a4.002 4.002 0 0 1-7.86 0H.75a.75.75 0 0 1 0-1.5h3.32a4.002 4.002 0 0 1 7.86 0h3.32a.75.75 0 0 1 0 1.5Zm-1.43-.5a2.5 2.5 0 1 0-5 0 2.5 2.5 0 0 0 5 0Z"></path></svg>'
                        f'Contributions on {date_str}</div>', 
                        unsafe_allow_html=True
                    )
                    
                    group_html = '<div class="commit-group">'
                    for _, row in group_items.iterrows():
                        def get_val(r, key):
                            v = r.get(key)
                            if pd.isna(v) or v is None:
                                return None
                            return str(v)

                        # Field Visibility Logic
                        all_fields = {}
                        if t_name == "Requirements":
                            all_fields = {
                                "Plan ID": get_val(row, 'planId'),
                                "Type": get_val(row, 'type'),
                                "Source": get_val(row, 'source'),
                                "Acceptance Criteria": get_val(row, 'acceptanceCriteria')
                            }
                        elif t_name == "Decisions":
                            all_fields = {
                                "Rationale": get_val(row, 'rationale'),
                                "Alternatives": get_val(row, 'alternatives'),
                                "Satisfies": format_satisfies(row.get('satisfies')),
                                "Impact": str(row.get('impact', '')),
                                "Decision Class": get_val(row, 'decisionClass'),
                                "Grounding": get_val(row, 'grounding')
                            }
                        elif t_name == "Plans":
                            all_fields = {
                                "Goal": get_val(row, 'goal'),
                                "Context": get_val(row, 'context'),
                                "Timeline": f"Approved: {get_val(row, 'approvedAt')} | Completed: {get_val(row, 'completedAt')}" if get_val(row, 'approvedAt') else None
                            }
                        elif t_name == "Policies":
                            all_fields = {
                                "Plan ID": get_val(row, 'planId'),
                                "Rationale": get_val(row, 'rationale'),
                                "Satisfies": format_satisfies(row.get('satisfies'))
                            }

                        # Build Fields HTML
                        fields_html = ""
                        for label, val in all_fields.items():
                            if val and str(val).strip() and str(val).lower() != 'nan':
                                fields_html += f'<div style="margin-bottom: 12px;"><div style="font-weight: 600; color: #9CA3AF; font-size: 0.8rem; text-transform: uppercase; margin-bottom: 2px;">{label}</div><div style="color: #E5E7EB; font-size: 0.9rem; line-height: 1.5;">{val}</div></div>'
                        
                        # Scope tag footer
                        scope_html = ""
                        scope = row.get('scope')
                        if isinstance(scope, list):
                            scope_list = [s for s in scope if s]
                        elif scope is not None and not pd.isna(scope) and str(scope).lower() != 'nan':
                            scope_list = [scope]
                        else:
                            scope_list = []
                        if scope_list:
                            badges = "".join([f'<span style="background-color: #1C2128; border: 1px solid #30363D; color: #9CA3AF; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem; margin-right: 6px;">{s}</span>' for s in scope_list])
                            scope_html = f'<div style="margin-top: 12px; display: flex; align-items: center; gap: 8px;"><span style="font-size: 0.75rem; color: #9CA3AF; text-transform: uppercase; font-weight: 600;">Scope</span> {badges}</div>'

                        status = get_val(row, 'status') or 'active'
                        status_colors = {
                            'active': '#22C55E',
                            'deprecated': '#9CA3AF',
                            'obsolete': '#EF4444',
                            'draft': '#FBBF24',
                            'approved': '#8B5CF6'
                        }
                        status_color = status_colors.get(status.lower(), '#9CA3AF')
                        title = row.get('proposal' if t_name == 'Decisions' else ('featureName' if t_name == 'Plans' else 'description'), 'Untitled')
                        author = row['author']
                        
                        group_html += (
                            f'<details class="commit-item">'
                            f'<summary>'
                            f'<div style="display: flex; justify-content: space-between; align-items: baseline;">'
                            f'<div style="color: #E5E7EB; font-weight: 600; font-size: 0.95rem;">{title}</div>'
                            f'<div style="color: #9CA3AF; font-size: 0.8rem; font-family: monospace; display: flex; align-items: center; gap: 6px;">'
                            f'<span style="width: 8px; height: 8px; border-radius: 50%; background-color: {status_color}; display: inline-block;"></span>'
                            f'{row["id"]}</div>'
                            f'</div>'
                            f'<div style="color: #9CA3AF; font-size: 0.8rem; margin-top: 4px; display: flex; justify-content: space-between; align-items: center;">'
                            f'<div style="display: flex; align-items: center; gap: 8px;">'
                            f'<span>👤 {author} contributed</span>'
                            f'<span style="display: flex; align-items: center; gap: 4px; color: {status_color};">'
                            f'<svg viewBox="0 0 16 16" width="12" height="12" fill="currentColor"><path d="M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z"></path></svg>'
                            f'{status.capitalize()}'
                            f'</span>'
                            f'</div>'
                            f'</div>'
                            f'</summary>'
                            f'<div style="padding: 16px; background-color: #0D1117; border-top: 1px solid #30363D;">{fields_html}{scope_html}</div>'
                            f'</details>'
                        )
                    group_html += '</div>'
                    st.markdown(group_html, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
