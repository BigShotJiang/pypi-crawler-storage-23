#!/usr/bin/env bash
# test_decision-id_trailers.sh
#
# Proves that git commit trailers with decision-id values survive
# both rebase and squash (interactive rebase) operations.
#
# Two distinct behaviours are demonstrated:
#
#   REBASE  — each commit is replayed with its message unchanged.
#             decision-id trailers remain in the canonical trailer
#             block at the end of the message.
#
#   SQUASH  — commit messages are concatenated.  Earlier commits'
#             trailers end up in the middle of the combined body,
#             not in the final trailer block; but every decision-id
#             value is still present in the full commit message.

set -euo pipefail

# ── Terminal colors ──────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0

pass()    { echo -e "  ${GREEN}✓ PASS${NC}  $1"; PASS_COUNT=$((PASS_COUNT + 1)); }
fail()    { echo -e "  ${RED}✗ FAIL${NC}  $1"; FAIL_COUNT=$((FAIL_COUNT + 1)); }
section() { echo -e "\n${BLUE}━━━  $1  ━━━${NC}"; }
info()    { echo -e "  ${YELLOW}→${NC}  $1"; }

# ── Scratch repo ─────────────────────────────────────────────────────────────
REPO=$(mktemp -d)
trap 'rm -rf "$REPO"' EXIT

cd "$REPO"
git init -q
git config user.email "ci@test.local"
git config user.name  "CI Test"
git config advice.detachedHead false

# ── Helpers ──────────────────────────────────────────────────────────────────

# Canonical trailer block of HEAD (lines in RFC-2822 trailer position)
head_trailers() {
  git log -1 --format='%B' | git interpret-trailers --parse
}

# Full raw message of HEAD (used for squash assertions)
head_body() {
  git log -1 --format='%B'
}

# True if the full message contains the given decision-id value
body_has() {
  head_body | grep -q "decision-id: $1"
}

# True if the canonical trailer block contains the given decision-id value
trailer_has() {
  head_trailers | grep -q "decision-id: $1"
}

# ── Squash-sequence editor (Python, cross-platform) ──────────────────────────
# Turns every "pick" line except the first into "squash".
SQUASH_EDITOR=$(mktemp)
cat > "$SQUASH_EDITOR" << 'PYEOF'
#!/usr/bin/env python3
import sys
lines = open(sys.argv[1]).readlines()
result, seen_pick = [], False
for line in lines:
    if line.startswith('pick') and seen_pick:
        result.append('squash' + line[4:])
    else:
        result.append(line)
        if line.startswith('pick'):
            seen_pick = True
open(sys.argv[1], 'w').writelines(result)
PYEOF
chmod +x "$SQUASH_EDITOR"

# ── ROOT commit ───────────────────────────────────────────────────────────────
printf "root\n" > root.txt
git add root.txt
git commit -q -m "chore: root"
ROOT_SHA=$(git rev-parse HEAD)

# Advance main by one commit (used as rebase target)
printf "extra\n" > extra.txt
git add extra.txt
git commit -q -m "chore: extra"
EXTRA_SHA=$(git rev-parse HEAD)

# ═══════════════════════════════════════════════════════════════════════════════
section "TEST 1 — Plain rebase: trailer stays in canonical trailer block"
# ═══════════════════════════════════════════════════════════════════════════════
#
#  Before:  root ── extra                     (base advances)
#            └── feat[decision-id: DEC-001]   (feature off root)
#
#  After rebase feat onto extra:
#           root ── extra ── feat[decision-id: DEC-001]
#
#  The trailer must remain in the canonical (end-of-message) trailer block.

git checkout -q "$ROOT_SHA"
git checkout -q -b test1/feature

printf "impl\n" > impl.txt
git add impl.txt
git commit -q -m "feat: implement thing

decision-id: DEC-001"

info "Trailer block before rebase:  $(head_trailers | tr '\n' ' ')"
git rebase -q "$EXTRA_SHA"
info "Trailer block after  rebase:  $(head_trailers | tr '\n' ' ')"

if trailer_has "DEC-001"; then
    pass "DEC-001 is in the canonical trailer block after rebase"
else
    fail "DEC-001 is MISSING from the canonical trailer block after rebase"
fi

# ═══════════════════════════════════════════════════════════════════════════════
section "TEST 2 — Rebase with multiple trailers in one commit"
# ═══════════════════════════════════════════════════════════════════════════════
#
#  One commit carrying two decision-id trailers, rebased onto a new tip.
#  Both must remain in the canonical trailer block.

git checkout -q "$EXTRA_SHA"
git checkout -q -b test2/multi-trailer

printf "c\n" > c.txt
git add c.txt
git commit -q -m "feat: multi-decision change

decision-id: DEC-020
decision-id: DEC-021"

info "Trailer block before rebase:  $(head_trailers | tr '\n' ' ')"

# Advance base
git checkout -q "$EXTRA_SHA"
git checkout -q -b test2/newbase
printf "extra2\n" > extra2.txt
git add extra2.txt
git commit -q -m "chore: extra2"
EXTRA2_SHA=$(git rev-parse HEAD)

git checkout -q test2/multi-trailer
git rebase -q "$EXTRA2_SHA"

info "Trailer block after  rebase:  $(head_trailers | tr '\n' ' ')"

if trailer_has "DEC-020" && trailer_has "DEC-021"; then
    pass "Both DEC-020 and DEC-021 are in the canonical trailer block after rebase"
else
    fail "Trailer block after rebase: '$(head_trailers | tr '\n' ' ')'"
fi

# ═══════════════════════════════════════════════════════════════════════════════
section "TEST 3 — Squash: all decision-id values preserved in combined message"
# ═══════════════════════════════════════════════════════════════════════════════
#
#  Two commits, each with a distinct decision-id, squashed into one.
#
#  NOTE ON SQUASH BEHAVIOUR:
#    git squash concatenates both commit messages.  The earlier commit's
#    trailers appear mid-body (not at the end), so they are NOT returned by
#    `git interpret-trailers --parse`.  However, every decision-id value
#    IS present in the full commit message — nothing is dropped.
#
#  This test verifies the full-message preservation guarantee.

git checkout -q "$EXTRA_SHA"
git checkout -q -b test3/squash

printf "a\n" > a.txt
git add a.txt
git commit -q -m "feat: step A

decision-id: DEC-010"

printf "b\n" > b.txt
git add b.txt
git commit -q -m "feat: step B

decision-id: DEC-011"

info "Commits before squash:"
git log --oneline -2 | sed 's/^/    /'

# GIT_EDITOR=true accepts the auto-generated combined message unchanged
GIT_SEQUENCE_EDITOR="$SQUASH_EDITOR" GIT_EDITOR=true \
    git rebase -q -i HEAD~2

info "Full message after squash:"
head_body | sed 's/^/    /'
info "Canonical trailer block after squash: $(head_trailers | tr '\n' '|')"

if body_has "DEC-010" && body_has "DEC-011"; then
    pass "Both DEC-010 and DEC-011 are present in the full squashed message"
else
    fail "A decision-id value was LOST from the squashed message (body: '$(head_body | tr '\n' ' ')')"
fi

# Bonus: confirm git can still extract the last trailer block
if trailer_has "DEC-011"; then
    pass "DEC-011 (last commit's trailer) is in the canonical trailer block"
else
    fail "DEC-011 is missing from the canonical trailer block"
fi

# ═══════════════════════════════════════════════════════════════════════════════
section "TEST 4 — Rebase + squash chain (three commits → one)"
# ═══════════════════════════════════════════════════════════════════════════════
#
#  Three commits with distinct decision-ids, rebased onto a new base and then
#  squashed into one.  All three decision-id values must survive in the body.

git checkout -q "$EXTRA_SHA"
git checkout -q -b test4/chain

for N in 030 031 032; do
    printf "%s\n" "$N" > "${N}.txt"
    git add "${N}.txt"
    git commit -q -m "feat: step ${N}

decision-id: DEC-${N}"
done

info "Commits before rebase+squash:"
git log --oneline -3 | sed 's/^/    /'

# Advance base
git checkout -q "$EXTRA_SHA"
git checkout -q -b test4/newbase
printf "extra3\n" > extra3.txt
git add extra3.txt
git commit -q -m "chore: extra3"
EXTRA3_SHA=$(git rev-parse HEAD)

# Rebase onto new base
git checkout -q test4/chain
git rebase -q "$EXTRA3_SHA"

# Squash all three into one
GIT_SEQUENCE_EDITOR="$SQUASH_EDITOR" GIT_EDITOR=true \
    git rebase -q -i HEAD~3

info "Full message after rebase+squash:"
head_body | sed 's/^/    /'

if body_has "DEC-030" && body_has "DEC-031" && body_has "DEC-032"; then
    pass "All three decision-id values (DEC-030, DEC-031, DEC-032) survived rebase+squash"
else
    fail "Missing decision-id value(s) after rebase+squash (body: '$(head_body | tr '\n' ' ')')"
fi

# ═══════════════════════════════════════════════════════════════════════════════
section "TEST 5 — Parallel feature branches both rebased onto an advanced main"
# ═══════════════════════════════════════════════════════════════════════════════
#
#  Simulates the real-world scenario where two features are developed in
#  parallel from the same main commit, then a mandatory history rebase is
#  required because main has since advanced (e.g. a hotfix or a third team's
#  feature landed).
#
#  Graph before rebase:
#
#    main:    S0 ──── S1 ──── S2(hotfix)
#                      │
#                      ├── alpha-A [DEC-100]
#                      │   └── alpha-B [DEC-101]   (feature/alpha, 2 commits)
#                      │
#                      └── beta-A  [DEC-200]
#                          └── beta-B  [DEC-201]   (feature/beta,  2 commits)
#
#  Action: rebase both branches onto S2 (forced by the team lead).
#
#  Graph after rebase:
#
#    main:    S0 ──── S1 ──── S2(hotfix)
#                              ├── alpha-A [DEC-100]
#                              │   └── alpha-B [DEC-101]
#                              └── beta-A  [DEC-200]
#                                  └── beta-B  [DEC-201]
#
#  All four decision-id trailers must survive the rebase, in their canonical
#  trailer-block positions, on each respective branch.

# S1 — the shared branch point (already exists as EXTRA_SHA)
SHARED_SHA="$EXTRA_SHA"

# ── feature/alpha: two commits, each with a decision-id ──────────────────────
git checkout -q "$SHARED_SHA"
git checkout -q -b test5/feature-alpha

printf "alpha-a\n" > alpha_a.txt
git add alpha_a.txt
git commit -q -m "feat(alpha): implement part A

Covers the first half of the alpha feature.

decision-id: DEC-100"

printf "alpha-b\n" > alpha_b.txt
git add alpha_b.txt
git commit -q -m "feat(alpha): implement part B

Covers the second half of the alpha feature.

decision-id: DEC-101"

# ── feature/beta: two commits, each with a decision-id ───────────────────────
git checkout -q "$SHARED_SHA"
git checkout -q -b test5/feature-beta

printf "beta-a\n" > beta_a.txt
git add beta_a.txt
git commit -q -m "feat(beta): implement part A

First slice of the beta feature.

decision-id: DEC-200"

printf "beta-b\n" > beta_b.txt
git add beta_b.txt
git commit -q -m "feat(beta): implement part B

Second slice of the beta feature.

decision-id: DEC-201"

# ── S2 — hotfix lands on main while both features were in-flight ─────────────
git checkout -q "$SHARED_SHA"
git checkout -q -b test5/main
printf "hotfix\n" > hotfix.txt
git add hotfix.txt
git commit -q -m "fix: critical hotfix — mandates history rebase for all open branches"
HOTFIX_SHA=$(git rev-parse HEAD)

info "Graph before rebase:"
echo "    main   : $(git log --oneline test5/main | head -3 | tr '\n' '|')"
echo "    alpha  : $(git log --oneline test5/feature-alpha | head -3 | tr '\n' '|')"
echo "    beta   : $(git log --oneline test5/feature-beta  | head -3 | tr '\n' '|')"

# ── Rebase feature/alpha onto hotfix ─────────────────────────────────────────
git checkout -q test5/feature-alpha
git rebase -q "$HOTFIX_SHA"

# Per-commit check: walk each commit individually
alpha_ok=true
for COMMIT in $(git log --format='%H' "$HOTFIX_SHA"..HEAD); do
    MSG=$(git show -s --format='%B' "$COMMIT")
    TRLRS=$(echo "$MSG" | git interpret-trailers --parse)
    SHORT=$(git show -s --format='%s' "$COMMIT")
    info "  alpha after rebase — '$SHORT' trailers: $(echo "$TRLRS" | tr '\n' ' ')"
    if ! echo "$TRLRS" | grep -q "decision-id: DEC-1"; then
        alpha_ok=false
    fi
done

if $alpha_ok; then
    pass "feature/alpha: all decision-id trailers (DEC-100, DEC-101) survived rebase onto hotfix"
else
    fail "feature/alpha: a decision-id trailer was LOST after mandatory rebase"
fi

# ── Rebase feature/beta onto hotfix ──────────────────────────────────────────
git checkout -q test5/feature-beta
git rebase -q "$HOTFIX_SHA"

beta_ok=true
for COMMIT in $(git log --format='%H' "$HOTFIX_SHA"..HEAD); do
    MSG=$(git show -s --format='%B' "$COMMIT")
    TRLRS=$(echo "$MSG" | git interpret-trailers --parse)
    SHORT=$(git show -s --format='%s' "$COMMIT")
    info "  beta  after rebase — '$SHORT' trailers: $(echo "$TRLRS" | tr '\n' ' ')"
    if ! echo "$TRLRS" | grep -q "decision-id: DEC-2"; then
        beta_ok=false
    fi
done

if $beta_ok; then
    pass "feature/beta:  all decision-id trailers (DEC-200, DEC-201) survived rebase onto hotfix"
else
    fail "feature/beta:  a decision-id trailer was LOST after mandatory rebase"
fi

# ── Cross-branch isolation: alpha trailers must NOT bleed into beta ───────────
git checkout -q test5/feature-alpha
ALPHA_BODY=$(git log --format='%B' "$HOTFIX_SHA"..HEAD)
git checkout -q test5/feature-beta
BETA_BODY=$(git log --format='%B' "$HOTFIX_SHA"..HEAD)

if echo "$BETA_BODY" | grep -q "DEC-100" || echo "$BETA_BODY" | grep -q "DEC-101"; then
    fail "Cross-contamination: alpha decision-ids appeared in beta after rebase"
elif echo "$ALPHA_BODY" | grep -q "DEC-200" || echo "$ALPHA_BODY" | grep -q "DEC-201"; then
    fail "Cross-contamination: beta decision-ids appeared in alpha after rebase"
else
    pass "No cross-branch decision-id contamination — each branch kept only its own trailers"
fi

# ═══════════════════════════════════════════════════════════════════════════════
section "SUMMARY"
# ═══════════════════════════════════════════════════════════════════════════════

echo ""
echo "  Passed : $PASS_COUNT"
echo "  Failed : $FAIL_COUNT"
echo ""

if [[ "$FAIL_COUNT" -eq 0 ]]; then
    echo -e "${GREEN}All $PASS_COUNT tests passed.${NC}"
    echo ""
    echo "  Key findings:"
    echo "  • REBASE         — decision-id trailers stay in the canonical trailer block"
    echo "                     (git interpret-trailers --parse returns them correctly)"
    echo "  • SQUASH         — All decision-id values appear in the combined message body;"
    echo "                     the last commit's trailer lands in the canonical trailer block"
    echo "  • PARALLEL REBASE— When multiple feature branches share a base and are"
    echo "                     force-rebased onto an advanced main, each branch retains"
    echo "                     only its own decision-id trailers — no cross-contamination"
    exit 0
else
    echo -e "${RED}$FAIL_COUNT test(s) failed.${NC}"
    exit 1
fi
