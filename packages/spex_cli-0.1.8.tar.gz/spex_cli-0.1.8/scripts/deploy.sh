#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

# Define colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Starting deployment process for spex-cli...${NC}"

# Ensure we are in the project root
cd "$(dirname "$0")/.."

# 1. Check for uncommitted changes
if [[ -n $(git status -s) ]]; then
    echo -e "${RED}Error: You have uncommitted changes. Please commit or stash them before deploying.${NC}"
    exit 1
fi

# 2. Ensure build and twine are installed
echo -e "${YELLOW}Ensuring twine is available...${NC}"
if command -v uv &> /dev/null; then
    # Use uv to run twine
    RUN_TWINE="uv run twine"
    BUILD_CMD="uv build"
else
    echo -e "${YELLOW}uv not found, falling back to pip and python -m build...${NC}"
    python3 -m pip install --upgrade build twine
    RUN_TWINE="python3 -m twine"
    BUILD_CMD="python3 -m build"
fi

# Detect local .pypirc
TWINE_OPTS=""
if [[ -f ".pypirc" ]]; then
    echo -e "${YELLOW}Using local .pypirc file...${NC}"
    TWINE_OPTS="--config-file .pypirc"
fi

# 3. Clean previous builds
echo -e "${YELLOW}Cleaning up previous builds...${NC}"
rm -rf dist/ build/ *.egg-info

# 4. Build the package
echo -e "${YELLOW}Building the package...${NC}"
$BUILD_CMD

# 5. Check the distribution packages
echo -e "${YELLOW}Running twine check...${NC}"
$RUN_TWINE check dist/*

# 6. Prompt for deployment target
echo -e "${GREEN}Build successful and verified!${NC}"
echo "Where would you like to upload?"
echo "1) TestPyPI (recommended for testing)"
echo "2) PyPI (production)"
echo "3) Exit"
read -p "Enter choice [1-3]: " choice

case $choice in
    1)
        echo -e "${YELLOW}Uploading to TestPyPI...${NC}"
        $RUN_TWINE upload $TWINE_OPTS --repository testpypi dist/*
        ;;
    2)
        echo -e "${YELLOW}Uploading to PyPI...${NC}"
        $RUN_TWINE upload $TWINE_OPTS dist/*
        ;;
    3)
        echo -e "${YELLOW}Exiting without upload.${NC}"
        exit 0
        ;;
    *)
        echo -e "${RED}Invalid choice. Exiting.${NC}"
        exit 1
        ;;
esac

echo -e "${GREEN}Deployment complete!${NC}"
