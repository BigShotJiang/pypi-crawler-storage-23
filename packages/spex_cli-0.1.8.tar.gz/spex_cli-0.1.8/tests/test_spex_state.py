import json
import pytest
from datetime import datetime


@pytest.fixture
def temp_spex_env(tmp_path):
    """Setup a temporary .spex directory structure"""
    spex_dir = tmp_path / ".spex"
    memory_dir = spex_dir / "memory"
    memory_dir.mkdir(parents=True)
    
    # Global memory files
    (memory_dir / "requirements.jsonl").touch()
    (memory_dir / "decisions.jsonl").touch()
    (memory_dir / "plans.jsonl").touch()
    (memory_dir / "traces.jsonl").touch()
    
    return tmp_path

def run_spex(cwd, args):
    """Run spex CLI with args"""
    import subprocess
    return subprocess.run(["spex"] + args, cwd=cwd, capture_output=True, text=True)

def init_feature(env, name):
    """Initialize a feature directory with state.json"""
    feat_dir = env / ".spex" / name
    feat_dir.mkdir(parents=True)
    state = {
        "featureName": name,
        "currentState": "INIT",
        "stateHistory": [{"state": "INIT", "timestamp": datetime.now().isoformat()}],
        "context": {"planId": "P-TEST-1"},
        "metadata": {"createdAt": datetime.now().isoformat(), "updatedAt": datetime.now().isoformat()}
    }
    with open(feat_dir / "state.json", "w") as f:
        json.dump(state, f)
    return feat_dir

def test_valid_transition_init_to_research(temp_spex_env):
    init_feature(temp_spex_env, "feat1")
    res = run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "RESEARCH"])
    assert res.returncode == 0
    data = json.loads(res.stdout)
    assert data["valid"] is True
    assert data["nextState"] == "RESEARCH"

    # Verify state.json was updated
    with open(temp_spex_env / ".spex/feat1/state.json", "r") as f:
        state = json.load(f)
        assert state["currentState"] == "RESEARCH"
        assert len(state["stateHistory"]) == 2

def test_invalid_transition(temp_spex_env):
    init_feature(temp_spex_env, "feat1")
    # INIT -> GENERATE_PLAN is invalid
    res = run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "GENERATE_PLAN"])
    assert res.returncode != 0
    data = json.loads(res.stdout)
    assert data["valid"] is False
    assert "Invalid transition" in data["error"]

def test_missing_artifact_enforcement(temp_spex_env):
    feat_dir = init_feature(temp_spex_env, "feat1")

    # First move to RESEARCH
    run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "RESEARCH"])

    # Now try to move to GENERATE_PLAN without research.json
    res = run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "GENERATE_PLAN"])
    assert res.returncode != 0
    data = json.loads(res.stdout)
    assert data["valid"] is False
    assert "Missing research.json" in data["error"]

def test_valid_research_to_generate_plan_transition(temp_spex_env):
    feat_dir = init_feature(temp_spex_env, "feat1")
    run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "RESEARCH"])

    # Create research.json with memory section
    with open(feat_dir / "research.json", "w") as f:
        json.dump({"codebase": {"facts": []}, "memory": {"conflicts": []}}, f)

    res = run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "GENERATE_PLAN"])
    assert res.returncode == 0
    assert json.loads(res.stdout)["valid"] is True

def test_generate_plan_requires_memory_facts(temp_spex_env):
    feat_dir = init_feature(temp_spex_env, "feat1")
    # Fast track to RESEARCH
    with open(feat_dir / "state.json", "r") as f:
        state = json.load(f)
        state["currentState"] = "RESEARCH"
        with open(feat_dir / "state.json", "w") as wf:
            json.dump(state, wf)

    # Create research.json WITHOUT 'memory' section
    with open(feat_dir / "research.json", "w") as f:
        json.dump({"codebase": {}}, f)

    res = run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "GENERATE_PLAN"])
    assert res.returncode != 0
    assert "missing 'memory' section" in json.loads(res.stdout)["error"]


def test_compiling_tasks_requires_approved_plan(temp_spex_env):
    """COMPILING_TASKS gate must find an approved plan via get_latest_jq (not get_latest_active_jq)."""
    feat_dir = init_feature(temp_spex_env, "feat1")

    # Fast-track to REVIEWING_PLAN
    with open(feat_dir / "state.json", "r") as f:
        state = json.load(f)
    state["currentState"] = "REVIEWING_PLAN"
    state["context"]["planId"] = "P-TEST-1"
    with open(feat_dir / "state.json", "w") as f:
        json.dump(state, f)

    # Write an approved plan into plans.jsonl
    plans_file = temp_spex_env / ".spex" / "memory" / "plans.jsonl"
    plan_entry = {
        "id": "P-TEST-1",
        "version": 1,
        "status": "approved",
        "createdAt": datetime.now().isoformat(),
        "author": "test",
        "featureName": "feat1",
        "goal": "test goal",
        "context": "",
        "approvedAt": datetime.now().isoformat(),
    }
    with open(plans_file, "w") as f:
        f.write(json.dumps(plan_entry) + "\n")

    res = run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "COMPILING_TASKS"])
    assert res.returncode == 0, f"Expected success but got: {res.stdout} {res.stderr}"
    data = json.loads(res.stdout)
    assert data["valid"] is True
    assert data["nextState"] == "COMPILING_TASKS"
