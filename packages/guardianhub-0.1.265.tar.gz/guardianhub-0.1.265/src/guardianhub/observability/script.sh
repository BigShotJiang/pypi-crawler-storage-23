export OTEL_EXPORTER_OTLP_ENDPOINT="http://langfuse.guardianhub.com"
export OTEL_EXPORTER_OTLP_TRACES_TIMEOUT=10000
export LANGFUSE_PROJECT_ID="cmm9p2ug8000130078ksjqbbr"
export LANGFUSE_PUBLIC_KEY="pk-lf-8607e0c1-b14d-47d6-9951-63194d70029b"
export LANGFUSE_SECRET_KEY="sk-lf-9aeab65f-9461-44f1-b8e3-56d5e830b67f"

pytest tests/test_baggage.py::TestLangfuseClient -s