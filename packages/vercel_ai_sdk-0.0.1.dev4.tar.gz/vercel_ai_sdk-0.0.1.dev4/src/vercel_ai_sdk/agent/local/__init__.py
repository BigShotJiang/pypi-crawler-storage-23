from . import fs
from .fs import LocalFilesystem

__all__ = ["fs", "LocalFilesystem"]
