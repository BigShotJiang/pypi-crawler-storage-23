"""
Vocal CLI - Command-line interface for Vocal Speech AI Platform

This CLI provides Ollama-style commands for model management and audio transcription.
"""

__version__ = "0.3.3"
