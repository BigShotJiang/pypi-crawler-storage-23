## Summary

-

## Problem

-

## Changes

-

## Test Evidence

- [ ] `uv run pytest -q`
- [ ] Additional/manual checks (describe)

## Risk and Rollback

-

## Docs

- [ ] Not needed
- [ ] Updated (`README.md` / `docs/*`)
