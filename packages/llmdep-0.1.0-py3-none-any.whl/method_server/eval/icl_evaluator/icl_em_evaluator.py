from ..utils.text_postprocessors import remove_punctuation

from .icl_base_evaluator import BaseEvaluator

"""
class EMEvaluator(BaseEvaluator):


    def __init__(self) -> None:
        super().__init__()


    #reference不会是list(list(str))吧
    def score(self, predictions, references: list[list[str]]):
        if len(predictions) != len(references):
            return {
                'error': 'predictions and references have different '
                'length'
            }
        predictions = [
            general_postprocess(prediction) for prediction in predictions
        ]
        processed_answers = [[general_postprocess(j) for j in i]
                             for i in references]


        cnt = 0
        #print(f"pre:{predictions}")
        #print(f"processed_ans:{processed_answers}")
        #print(f"ref:{references}")
        for pred, ans, origin_ans in zip(predictions, processed_answers,
                                         references):
            if pred in ans or pred in origin_ans:
                cnt += 1

        if len(predictions) == 0:
            socre = 0
        else:
            score = cnt / len(predictions) * 100

        return {'EM_score': score}

"""

class EMEvaluator(BaseEvaluator):
    """EM evaluator for sentences"""

    def __init__(self) -> None:
        super().__init__()

    #reference是list(list(str))
    def score(self, predictions: list[str], references: list[list[str]]):
        em = 0
        total_count = 0

        if len(predictions) != len(references):
            return {
                'error': 'predictions and references have different '
                'length'
            }

        for pre, ref in zip(predictions, references):
            total_count += 1
            em += self.calc_em_score(ref, pre)


        if total_count == 0:
            em_score = 0
        else:
            em_score = 100.0 * em / total_count
        return {'EM_score': em_score}
    

    def calc_em_score(self, answers, prediction):
        em = 0
        for ans in answers:
            ans_ = remove_punctuation(ans)
            prediction_ = remove_punctuation(prediction)
            if ans_ == prediction_:
                em = 1
                break
        return em
