from ..utils.text_postprocessors import mixed_segmentation, find_lcs

from .icl_base_evaluator import BaseEvaluator



class F1Evaluator(BaseEvaluator):
    """F1 evaluator for sentences"""

    def __init__(self) -> None:
        super().__init__()

    #reference是list(list(str))
    def score(self, predictions: list[str], references: list[list[str]]):
        f1 = 0
        total_count = 0

        if len(predictions) != len(references):
            return {
                'error': 'predictions and references have different '
                'length'
            }

        for pre, ref in zip(predictions, references):
            total_count += 1
            f1 += self.calc_f1_score(ref, pre)


        if total_count == 0:
            f1_score = 0
        else:
            f1_score = 100.0 * f1 / total_count
        return {'F1_score': f1_score}
    

    def calc_f1_score(self, reference, prediction):
        f1_scores = []
        for ans in reference:
            #print(ans)
            ans_segs = mixed_segmentation(ans, rm_punc=True)
            prediction_segs = mixed_segmentation(prediction, rm_punc=True)
            lcs, lcs_len = find_lcs(ans_segs, prediction_segs)
            if lcs_len == 0:
                f1_scores.append(0)
                continue
            precision = 1.0 * lcs_len / len(prediction_segs)
            recall = 1.0 * lcs_len / len(ans_segs)
            f1 = (2 * precision * recall) / (precision + recall)
            f1_scores.append(f1)
        return max(f1_scores)
