#from utils import general_postprocess

from .icl_base_evaluator import BaseEvaluator


class MatchAccEvaluator(BaseEvaluator):
    """Exact match evaluator. reference can be [[str]] or [str]"""

    def __init__(self) -> None:
        super().__init__()

    def score(self, predictions: list[str], references):
        if len(predictions) != len(references):
            return {
                'error': 'predictions and references have different '
                'length'
            }
        """
        predictions = [
            general_postprocess(prediction) for prediction in predictions
        ]
        """
        


        cnt = 0
        for pred, origin_ans in zip(predictions, references):
            if type(origin_ans) == type(['str']):
                single_cnt = 0.0
                for single_golden_ans in origin_ans:
                    if single_golden_ans in pred:
                        single_cnt += 1
                cnt += single_cnt / len(origin_ans)
                    
            else:
                if origin_ans in pred:
                    cnt += 1

        score = cnt / len(predictions) * 100

        return {'matchAcc': score}
