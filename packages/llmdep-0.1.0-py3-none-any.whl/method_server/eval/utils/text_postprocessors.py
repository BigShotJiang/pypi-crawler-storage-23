import re
import nltk

def remove_punctuation_white_space(text: str) -> str:
    regex = re.compile("[^\\w\\s]")
    new_text = regex.sub("", text)
    new_text = new_text.replace(" ", "")
    return new_text

def general_postprocess(text: str) -> str:
    truncated_text = re.split(r'[\n.,]', text, 1)[0]
    no_punctuation = re.sub(r'[^\w\s]', '', truncated_text)
    no_articles = re.sub(r'\b(a|an|the)\b', '', no_punctuation, flags=re.IGNORECASE)
    cleaned_text = re.sub(r'\s+', ' ', no_articles).strip()
    return cleaned_text

def general_cn_postprocess(text: str) -> str:
    import jieba
    cleaned_text = ' '.join(jieba.cut(text))
    return cleaned_text

def first_capital_postprocess(text: str) -> str:
    for t in text:
        if t.isupper():
            return t
    return ''

def first_number_postprocess(text: str) -> str:
    for t in text:
        if t.isnumeric():
            return t
    return ''

def first_option_postprocess(text: str, options: str) -> str:
    patterns = [
        f'[Tt]he answer is [{options}]',
        f'[Tt]he correct answer is [{options}]',
        f'答案是(.*?)[{options}]',
        f'答案为(.*?)[{options}]',
        f'正确的选项为(.*?)[{options}]',
        f'正确的选项是(.*?)[{options}]',
        f'固选(.*?)[{options}]',
        f'答案应该是(.*?)[{options}]',
        f'(\\s|^)[{options}][\\s。，,\\.$]',
        f'[{options}]',
    ]
    regexes = [re.compile(pattern) for pattern in patterns]
    for regex in regexes:
        match = regex.search(text)
        if match:
            outputs = match.group(0)
            for i in options:
                if i in outputs:
                    return i
    return ''

def first_capital_postprocess_multi(text: str) -> str:
    match = re.search(r'([A-D]+)', text)
    if match:
        return match.group(1)
    return ''

def last_option_postprocess(text: str, options: str) -> str:
    match = re.findall(rf'([{options}])', text)
    if match:
        return match[-1]
    return ''

def mixed_segmentation(in_str, rm_punc=False):
    in_str = str(in_str).lower().strip()
    segs_out = []
    temp_str = ""
    sp_char = ['-', ':', '_', '*', '^', '/', '\\', '~', '`', '+', '=',
               '，', '。', '：', '？', '！', '“', '”', '；', '’', '《', '》', '……', '·', '、',
               '「', '」', '（', '）', '－', '～', '『', '』']
    def is_chinese_char(c):
        try:
            return '\u4e00' <= c <= '\u9fa5'
        except:
            return False
    
    for char in in_str:
        if rm_punc and char in sp_char:
            continue
        
        if is_chinese_char(char) or char in sp_char:
            if temp_str != "":
                try:
                    ss = nltk.word_tokenize(temp_str)
                    segs_out.extend(ss)
                except:
                    segs_out.append(temp_str)
                temp_str = ""
            segs_out.append(char)
        else:
            temp_str += char
    if temp_str != "":
        try:
            ss = nltk.word_tokenize(temp_str)
            segs_out.extend(ss)
        except:
            segs_out.append(temp_str)
    
    if not segs_out:
        segs_out = [in_str.replace(' ', '')]
    
    return segs_out

def remove_punctuation(in_str):
    in_str = str(in_str).lower().strip()
    sp_char = ['-', ':', '_', '*', '^', '/', '\\', '~', '`', '+', '=',
               '，', '。', '：', '？', '！', '“', '”', '；', '’', '《', '》', '……', '·', '、',
               '「', '」', '（', '）', '－', '～', '『', '』']
    out_segs = []
    for char in in_str:
        if char in sp_char:
            continue
        else:
            out_segs.append(char)
    return ''.join(out_segs)

def find_lcs(s1, s2):
    m = [[0 for i in range(len(s2) + 1)] for j in range(len(s1) + 1)]
    mmax = 0
    p = 0
    for i in range(len(s1)):
        for j in range(len(s2)):
            if s1[i] == s2[j]:
                m[i + 1][j + 1] = m[i][j] + 1
                if m[i + 1][j + 1] > mmax:
                    mmax = m[i + 1][j + 1]
                    p = i + 1
    return s1[p - mmax:p], mmax

def filter_unrecorded_data(preprocessed_user_ans, prediction_id, preprocessed_golden_ans, golden_id):
    filtered_prediction = []
    filtered_reference = []
    filtered_ids = []
    start_index_of_golden_ans = 0
    for i in range(0, len(prediction_id)):
        for j in range(start_index_of_golden_ans, len(golden_id)):
            if prediction_id[i] == golden_id[j]:
                filtered_prediction.append(preprocessed_user_ans[i])
                filtered_reference.append(preprocessed_golden_ans[j])
                filtered_ids.append(prediction_id[i])
                start_index_of_golden_ans = j + 1
                break
    return filtered_prediction, filtered_reference, filtered_ids
