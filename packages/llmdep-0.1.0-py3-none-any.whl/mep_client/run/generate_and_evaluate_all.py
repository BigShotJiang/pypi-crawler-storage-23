import os
import sys
import argparse
import json

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from config import load_llm_config

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from utils import generate_user_ans
from run import run_evaluation

_llm_cfg = load_llm_config()
add_model_args = _llm_cfg.add_model_args
instantiate_model = _llm_cfg.instantiate_model
get_model_choices = _llm_cfg.get_model_choices


def add_common_args(parser):
    parser.add_argument("--batch_size", type=int, default=1, help="Batch size during generation")
    parser.add_argument("--rate_limit", type=float, default=5.0, help="Token bucket fill rate per second")
    parser.add_argument("--bucket_capacity", type=float, default=20.0, help="Token bucket capacity")
    parser.add_argument("--worker_nums", type=int, default=6, help="Number of concurrent workers")
    parser.add_argument("--limited_test", type=int, nargs='?', const=10, default=None, help="Limit test to N examples: --limited_test (10), --limited_test 50 (custom), no flag (full)")
    parser.add_argument("--batch_config", default=os.path.join(os.path.dirname(__file__), "all.json"),
                        help="Batch task configuration file")


def generate_and_evaluate_all(
    batch_size=1,
    rate_limit=5.0,
    bucket_capacity=20.0,
    worker_nums=6,
    limited_test=False,
    batch_config=os.path.join(os.path.dirname(__file__), "all.json"),
):
    config_path = batch_config
    if not os.path.exists(config_path):
        print(f"Error: Configuration file not found → {config_path}")
        sys.exit(1)

    with open(config_path, encoding="utf-8") as f:
        tasks = json.load(f)

    if not isinstance(tasks, list) or not tasks:
        print("Error: all.json should be a non-empty list")
        sys.exit(1)

    print(f"Loaded {len(tasks)} tasks to process\n")

    for i, task in enumerate(tasks, 1):
        model_name = task.get("model")
        benchmark = task.get("benchmark")

        if not model_name or not benchmark:
            print(f"Task {i} missing model or benchmark, skipping")
            continue

        print(f"\n===== [ {i}/{len(tasks)} ]  {model_name}  @  {benchmark}  =====")

        model_parser = argparse.ArgumentParser(add_help=False)
        add_model_args(model_parser, model_name)

        combined = {
            "model_name": model_name,
            "benchmark": benchmark,
            "batch_size": batch_size,
            "worker_nums": worker_nums,
            "rate_limit": rate_limit,
            "bucket_capacity": bucket_capacity,
            "limited_test": limited_test,
        }

        model_specific_args = model_parser.parse_args([])
        for k, v in vars(model_specific_args).items():
            if k not in combined or combined[k] is None:
                combined[k] = v

        model = instantiate_model(model_name, argparse.Namespace(**combined))

        metadata = generate_user_ans(
            model=model,
            benchmark_name=benchmark,
            batch_size=batch_size,
            worker_nums=worker_nums,
            rate_limit=rate_limit,
            bucket_capacity=bucket_capacity,
            limited_test=limited_test,
            model_name=model_name
        )

        run_tag = metadata.get("run_tag")
        current_model_name = metadata.get("model_name", model_name)
        selected_benchmark = metadata.get("selected_benchmark", benchmark)

        if not run_tag:
            print("metadata missing run_tag, skipping evaluation")
            continue

        actual_run_tag = f"{run_tag}_{current_model_name}"

        try:
            run_evaluation(actual_run_tag, selected_benchmark)
            print("Evaluation completed")
        except Exception as e:
            print(f"Evaluation failed: {e}")

    print("\n" + "="*50)
    print("All tasks processed")
    print("="*50)


def main():
    parser = argparse.ArgumentParser(description="Batch generate answers + automatic evaluation (based on all.json)")
    add_common_args(parser)
    args = parser.parse_args()
    generate_and_evaluate_all(
        batch_size=args.batch_size,
        rate_limit=args.rate_limit,
        bucket_capacity=args.bucket_capacity,
        worker_nums=args.worker_nums,
        limited_test=args.limited_test,
        batch_config=args.batch_config,
    )


if __name__ == "__main__":
    main()