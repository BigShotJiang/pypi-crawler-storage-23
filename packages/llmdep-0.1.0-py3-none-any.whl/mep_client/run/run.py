import os
import sys
import json
import argparse
import datetime
import inspect

# Set up paths
run_dir = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(run_dir, '..')))
sys.path.insert(0, run_dir)
from config import ensure_server_on_sys_path, get_server_dir
from utils.server_data_access import save_final_results, run_server_evaluation

ensure_server_on_sys_path()


def run_evaluation(run_tag, benchmark_name="BiPaR"):
    """
    Run the evaluation process

    Args:
        run_tag: Run tag, usually in format "run_id_model_name"
        benchmark_name: Name of the benchmark (default: "BiPaR")
    """
    # Parse run_tag to extract run_id and model_name
    if '_' in run_tag:
        run_tag_parts = run_tag.split('_')
        run_id = run_tag_parts[0]
        model_name = '_'.join(run_tag_parts[1:])
    else:
        run_id = run_tag
        model_name = 'unknown'

    print(f"\nRunning server-side evaluation for {run_tag} ...")
    evaluation_results = run_server_evaluation(benchmark_name, model_name, run_id)

    save_final_results(benchmark_name, model_name, run_id, evaluation_results)

    print(f"Evaluation completed! Results saved to final_results/{benchmark_name}/{model_name}/{run_id}/")
    print(f"Overall performance: {json.dumps(evaluation_results['overall_performance'], indent=2, ensure_ascii=False)}")


def resolve_run_tag(run_tag, benchmark_name):
    server_dir = get_server_dir()
    cache_dir = os.path.join(server_dir, benchmark_name, "cache")

    if run_tag:
        if "_" in run_tag:
            parts = run_tag.split("_")
            rid = parts[0]
            model = "_".join(parts[1:])
        else:
            rid = run_tag
            model = "unknown"
        p = os.path.join(cache_dir, model, rid)
        if os.path.isdir(p):
            return f"{rid}_{model}"

    # Find the most recent run if no specific run_tag is given
    latest = None
    latest_mtime = -1
    if os.path.isdir(cache_dir):
        for model in os.listdir(cache_dir):
            mp = os.path.join(cache_dir, model)
            if not os.path.isdir(mp):
                continue
            for rid in os.listdir(mp):
                rp = os.path.join(mp, rid)
                if os.path.isdir(rp):
                    m = os.path.getmtime(rp)
                    if m > latest_mtime:
                        latest_mtime = m
                        latest = (rid, model)

    if latest:
        rid, model = latest
        return f"{rid}_{model}"

    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run_tag', required=False, default=None, help='Run tag to evaluate')
    parser.add_argument('--benchmark', default='BiPaR', help='Benchmark name to use')
    args = parser.parse_args()

    chosen = resolve_run_tag(args.run_tag, args.benchmark)
    if not chosen:
        print("Error: No valid run tag found")
        return

    run_evaluation(chosen, args.benchmark)


if __name__ == '__main__':
    main()