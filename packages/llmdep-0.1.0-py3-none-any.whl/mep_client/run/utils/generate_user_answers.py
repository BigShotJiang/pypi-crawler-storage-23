import os
import json
import logging
import datetime
from tqdm import tqdm, trange
import time
import jsonlines
import concurrent.futures
import threading
from .server_data_access import save_intermediate_results
import importlib.util
from collections import defaultdict
import re


class TokenBucket:
    def __init__(self, capacity, fill_rate):
        """
        Token Bucket for rate limiting.
        """
        self.capacity = float(capacity)
        self.fill_rate = float(fill_rate)
        self.tokens = self.capacity
        self.last_time = time.time()

    def acquire(self, tokens=1.0):
        """
        Acquire the specified number of tokens. Blocks if not enough tokens are available.
        """
        now = time.time()
        added_tokens = (now - self.last_time) * self.fill_rate
        self.tokens = min(self.capacity, self.tokens + added_tokens)
        self.last_time = now

        if self.tokens >= tokens:
            self.tokens -= tokens
            return True
        else:
            wait_time = (tokens - self.tokens) / self.fill_rate
            time.sleep(wait_time)
            self.tokens = 0.0
            self.last_time = time.time()
            return True


def user_generation_convertion_from_jsonl(user_gen_path, output_file_name):
    user_ans_json = {}
    for benchmark in os.listdir(user_gen_path):
        benchmark_path = os.path.join(user_gen_path, benchmark)
        if not os.path.isdir(benchmark_path):
            continue
        user_ans_json[benchmark] = {}
        for subtask_file in os.listdir(benchmark_path):
            if not subtask_file.endswith(".jsonl"):
                continue
            subtask_name = subtask_file[:-6]
            user_ans_json[benchmark][subtask_name] = []
            with jsonlines.open(os.path.join(benchmark_path, subtask_file)) as reader:
                for obj in reader:
                    user_ans_json[benchmark][subtask_name].append(obj)

    with open(output_file_name, 'w', encoding='utf-8') as f:
        json.dump(user_ans_json, f, indent=4, ensure_ascii=False)


def setup_dual_loggers(log_dir):
    """Set up dual loggers"""
    os.makedirs(log_dir, exist_ok=True)

    gen_logger = logging.getLogger("generation")
    err_logger = logging.getLogger("error")

    for logger in [gen_logger, err_logger]:
        for handler in logger.handlers[:]:
            handler.close()
            logger.removeHandler(handler)

    for logger, filename, level in [
        (gen_logger, "generation.log", logging.INFO),
        (err_logger, "error.log", logging.WARNING)
    ]:
        handler = logging.FileHandler(os.path.join(log_dir, filename), encoding='utf-8')
        handler.setFormatter(logging.Formatter('%(asctime)s | %(message)s'))
        logger.addHandler(handler)
        logger.setLevel(level)

    return gen_logger, err_logger


def type_converter(_single_data):
    if type(_single_data) == type(123):
        return 'int'
    elif type(_single_data) == type(123.4):
        return 'int'
    else:
        return 'string'


def generate_user_ans(
    model,
    benchmark_name,
    batch_size,
    worker_nums=2,
    rate_limit=5.0,
    bucket_capacity=10.0,
    limited_test=None,
    model_name="qwen-plus",
    convert_raw_to_json=False,
    continue_generate=False,
    run_id=None,
    stop_event=None
):
    """
    Script for generating user answers. The generate_func(input: List[str]) is a function parameter
    that takes a list of strings as input and returns a list of model-generated texts. By default,
    it truncates to the first 300 characters. batch_size is the number of items fed to the model at once.

    The keys in the user question dictionary are strictly required to be: "Prompt", "Input", "Post", "Id"
    - rate_limit: allowed requests per second (tokens per second)
    - bucket_capacity: maximum capacity of the token bucket (allowed burst requests)
    - stop_event: threading event used to stop the task
    """

    import sys
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
    from config import get_server_dir
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    server_dir = get_server_dir()
    prepare_func = None
    prepare_path = os.path.join(server_dir, benchmark_name, "methods", "prepare_ques.py")
    if os.path.exists(prepare_path):
        spec = importlib.util.spec_from_file_location("prepare_ques", prepare_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        prepare_func = mod.prepare_question_list if hasattr(mod, "prepare_question_list") else None

    _benchmarks = [d for d in os.listdir(server_dir) if os.path.isdir(os.path.join(server_dir, d))]
    if benchmark_name not in _benchmarks:
        print(f"Warning: specified benchmark {benchmark_name} does not exist")
        return {
            "run_tag": None,
            "model_name": model_name,
            "log_dir": None,
            "selected_benchmark": benchmark_name,
            "benchmarks_processed": [],
            "batch_size": batch_size,
            "initial_worker_nums": worker_nums,
            "final_worker_nums": worker_nums,
            "rate_limit": rate_limit,
            "bucket_capacity": bucket_capacity,
            "total_questions": 0,
            "total_success": 0,
            "total_errors": 0,
            "rate_limit_429_count": 0,
            "total_time_seconds": 0.0,
            "convert_raw_to_json": convert_raw_to_json,
            "continue_generate": continue_generate,
            "limited_test": limited_test,
            "final_json_path": None,
            "created_at": datetime.datetime.now().isoformat()
        }

    task_records_file = os.path.join(project_root, "mep_client", "log", "task_records.json")

    run_tag = run_id
    if run_tag:
        print(f"Using specified run_id: {run_tag}")

    if continue_generate and not run_tag:
        print(f"Checking interrupted resume status...")
        if os.path.exists(task_records_file):
            try:
                with open(task_records_file, 'r', encoding='utf-8') as f:
                    task_records = json.load(f)
                for record in task_records:
                    if (record["model"] == model_name and
                        record["benchmark"] == benchmark_name and
                        not record["completed"]):
                        run_tag = record["run_id"]
                        print(f"Found unfinished task: run_id={run_tag}")
                        break
                else:
                    print(f"No matching unfinished task found, creating new task")
            except (json.JSONDecodeError, IOError) as e:
                print(f"Failed to read task records: {e}, creating new task")

    if run_tag is None:
        run_tag = datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
        print(f"Generated new run_id: {run_tag}")

    log_dir = os.path.join(project_root, "mep_client", "log", f"{run_tag}_{model_name}")

    global generation_logger, error_logger
    generation_logger, error_logger = setup_dual_loggers(log_dir)

    task_record = {
        "run_id": run_tag,
        "model": model_name,
        "benchmark": benchmark_name,
        "start_time": datetime.datetime.now().isoformat(),
        "completed": False,
        "total_questions": 0,
        "completed_questions": 0,
        "status": "running",
        "current_subtask": None
    }

    generation_log_file = os.path.join(log_dir, "generation.log")
    completed_ids = set()

    if (continue_generate or run_id) and os.path.exists(generation_log_file):
        with open(generation_log_file, 'r', encoding='utf-8') as f:
            log_content = f.read()

        pattern = re.compile(r'subtask: (\S+)\nid: (\S+)\n', re.MULTILINE)

        for match in pattern.finditer(log_content):
            subtask_name, id_val = match.groups()
            completed_ids.add((subtask_name, id_val))

    # Update global count
    global_completed = len(completed_ids)
    task_record["completed_questions"] = global_completed
    task_record["total_questions"] = 0

    if os.path.exists(task_records_file):
        try:
            with open(task_records_file, 'r', encoding='utf-8') as f:
                task_records = json.load(f)
            updated = False
            for i, record in enumerate(task_records):
                if record["run_id"] == run_tag:
                    task_records[i] = task_record
                    updated = True
                    break
            if not updated:
                task_records.append(task_record)
        except (json.JSONDecodeError, IOError) as e:
            print(f"Failed to read task records: {e}, creating new task record")
            task_records = [task_record]
    else:
        task_records = [task_record]

    with open(task_records_file, 'w', encoding='utf-8') as f:
        json.dump(task_records, f, indent=2, ensure_ascii=False)

    current_worker_num = worker_nums

    # Initialize token bucket
    token_bucket = TokenBucket(capacity=bucket_capacity, fill_rate=rate_limit)

    start_time = time.perf_counter()
    total_questions = 0
    total_success = 0
    total_errors = 0
    rate_limit_429_count = 0
    benchmarks_processed = [benchmark_name]

    generated_answers = None
    prepared = None
    if callable(prepare_func):
        prepared = prepare_func()
    if isinstance(prepared, dict) and all(
        isinstance(v, dict) and "queries" in v and "ids" in v for v in prepared.values()
    ):
        generated_answers = {}
        for subtask_name, payload in prepared.items():
            # Check if need to stop
            if stop_event and stop_event.is_set():
                print(f"\nReceived stop signal, stopping task processing")
                task_record["status"] = "paused"
                with open(task_records_file, 'w', encoding='utf-8') as f:
                    json.dump(task_records, f, indent=2, ensure_ascii=False)
                break

            queries = payload["queries"]
            ids = payload["ids"]
            if limited_test is not None and not continue_generate:
                queries = queries[:limited_test]
                ids = ids[:limited_test]

            subtask_total = len(queries)
            total = subtask_total
            total_questions += subtask_total

            task_record["total_questions"] = total_questions

            task_record["current_subtask"] = subtask_name

            try:
                with open(task_records_file, 'r', encoding='utf-8') as f:
                    task_records = json.load(f)
                for i, record in enumerate(task_records):
                    if record["run_id"] == run_tag:
                        task_records[i] = task_record
                        break
                with open(task_records_file, 'w', encoding='utf-8') as f:
                    json.dump(task_records, f, indent=2, ensure_ascii=False)
            except (json.JSONDecodeError, IOError) as e:
                error_logger.warning(f"Failed to update task records: {e}")
                # Continue processing even if task records update fails

            print(f"\nStarting to process subtask: {subtask_name}")

            # Save current completed question count
            current_completed = task_record["completed_questions"]
            subtask_completed = 0
            if continue_generate:
                log_dir = os.path.join(project_root, "mep_client", "log", f"{run_tag}_{model_name}")
                generation_log_file = os.path.join(log_dir, "generation.log")
                if os.path.exists(generation_log_file):
                    with open(generation_log_file, 'r', encoding='utf-8') as f:
                        log_content = f.read()

                    subtask_pattern = re.compile(r'retrycount: 0\nbenchmark: (\w+)\n(?:subtask: (\w+)\n)?id: (\S+)\ngeneration: ([\s\S]*?)\nprompt: ([\s\S]*?)(?=retrycount: 0|$)', re.MULTILINE)
                    subtask_matches = subtask_pattern.findall(log_content)
                    if subtask_matches:
                        completed_ids.update((subtask_name, id_val) for id_val in subtask_matches)
                        # Calculate how many questions are already completed in current subtask
                        subtask_completed = len(subtask_matches)
                        print(f"Found {subtask_completed} completed questions for current subtask from log")
                        print(f"Current subtask completed: {subtask_completed} questions")

            # Filter out already completed questions
            current_subtask_completed = 0
            if completed_ids:
                filtered_queries = []
                filtered_ids = []
                for q, id_val in zip(queries, ids):
                    if (subtask_name, id_val) not in completed_ids:
                        filtered_queries.append(q)
                        filtered_ids.append(id_val)
                    else:
                        current_subtask_completed += 1
                queries = filtered_queries
                ids = filtered_ids
                if not queries:
                    print(f"All questions completed, skipping {subtask_name}")
                    generated_answers[subtask_name] = []

                    # Update current subtask status
                    task_records_file = os.path.join(project_root, "mep_client", "log", "task_records.json")
                    if os.path.exists(task_records_file):
                        try:
                            with open(task_records_file, 'r', encoding='utf-8') as f:
                                task_records = json.load(f)
                            for i, record in enumerate(task_records):
                                if record["run_id"] == run_tag:
                                    record["current_subtask"] = subtask_name
                                    with open(task_records_file, 'w', encoding='utf-8') as f:
                                        json.dump(task_records, f, indent=2, ensure_ascii=False)
                                    print(f"Updated subtask status: {subtask_name} completed")
                                    break
                        except (json.JSONDecodeError, IOError) as e:
                            error_logger.warning(f"Failed to update task records: {e}")
                            # Continue processing even if task records update fails
                    continue

            generated_answers[subtask_name] = []
            for i in trange(0, len(queries), batch_size, desc=f"{benchmark_name}/{subtask_name}"):
                # Check if need to stop
                if stop_event and stop_event.is_set():
                    print(f"\nReceived stop signal, stopping current batch processing")
                    task_record["status"] = "paused"
                    with open(task_records_file, 'w', encoding='utf-8') as f:
                        json.dump(task_records, f, indent=2, ensure_ascii=False)
                    return {
                        "run_tag": run_tag,
                        "model_name": model_name,
                        "log_dir": log_dir,
                        "selected_benchmark": benchmark_name,
                        "benchmarks_processed": benchmarks_processed,
                        "batch_size": batch_size,
                        "initial_worker_nums": worker_nums,
                        "final_worker_nums": current_worker_num,
                        "rate_limit": rate_limit,
                        "bucket_capacity": bucket_capacity,
                        "total_questions": total_questions,
                        "total_success": total_success,
                        "total_errors": total_errors,
                        "rate_limit_429_count": rate_limit_429_count,
                        "total_time_seconds": time.perf_counter() - start_time,
                        "convert_raw_to_json": convert_raw_to_json,
                        "continue_generate": continue_generate,
                        "limited_test": limited_test,
                        "final_json_path": None,
                        "created_at": datetime.datetime.now().isoformat()
                    }

                end = min(i + batch_size, len(queries))
                batch_questions = queries[i:end]
                batch_ids = ids[i:end]

                with concurrent.futures.ThreadPoolExecutor(max_workers=current_worker_num, thread_name_prefix='EvalWorker') as executor:
                    future_to_idx = {}
                    for idx, q in enumerate(batch_questions):
                        if stop_event and stop_event.is_set():
                            print(f"\nReceived stop signal, cancelling thread pool tasks")
                            for future in future_to_idx:
                                future.cancel()
                            break
                        token_bucket.acquire()
                        future_to_idx[executor.submit(model.call_with_prompt, q)] = idx

                    responses = [None] * len(batch_questions)
                    for future in concurrent.futures.as_completed(future_to_idx, timeout=1900):
                        if stop_event and stop_event.is_set():
                            print(f"\nReceived stop signal, stopping current batch")
                            for f in future_to_idx:
                                if not f.done():
                                    f.cancel()
                            break
                        idx = future_to_idx[future]
                        try:
                            responses[idx] = future.result(timeout=1900)
                        except concurrent.futures.TimeoutError:
                            print(f"Warning: model call timeout, ID: {batch_ids[idx]}")
                            responses[idx] = '{"code": 504, "content": "", "error": "Model call timeout"}'
                            error_logger.warning(f"TIMEOUT_ERROR | id={batch_ids[idx]} | error=Model call timeout")
                        except Exception as e:
                            print(f"Warning: model call exception, ID: {batch_ids[idx]}, error: {str(e)}")
                            responses[idx] = f'{{"code": 500, "content": "", "error": "{str(e)}"}}'
                            error_logger.warning(f"MODEL_CALL_ERROR | id={batch_ids[idx]} | error={str(e)}")

                for j in range(len(batch_questions)):
                    raw_resp = responses[j]
                    item_id = batch_ids[j]
                    prompt_text = batch_questions[j]
                    try:
                        resp = json.loads(raw_resp)
                    except (json.JSONDecodeError, TypeError):
                        resp = {"code": 500, "content": "", "error": "Model returned invalid JSON"}
                        error_logger.warning(f"JSON_PARSE_ERROR | id={item_id} | raw={raw_resp}")
                    code = resp.get("code", 500)
                    content = resp.get("content", "")
                    if code == 200:
                        ans_text = content
                        generation_logger.info(
                            f"retrycount: 0\nbenchmark: {benchmark_name}\n"
                            f"subtask: {subtask_name}\n"
                            f"id: {item_id}\ngeneration: {content}\nprompt: {prompt_text}"
                        )
                        total_success += 1

                        completed_ids.add((subtask_name, item_id))

                        task_records_file = os.path.join(project_root, "mep_client", "log", "task_records.json")
                        if os.path.exists(task_records_file):
                            try:
                                with open(task_records_file, 'r', encoding='utf-8') as f:
                                    task_records = json.load(f)
                                for i_record, record in enumerate(task_records):
                                    if record["run_id"] == run_tag:
                                        record["completed_questions"] = len(completed_ids)
                                        record["total_questions"] = total_questions
                                        with open(task_records_file, 'w', encoding='utf-8') as f:
                                            json.dump(task_records, f, indent=2, ensure_ascii=False)
                                        break
                            except (json.JSONDecodeError, IOError) as e:
                                error_logger.warning(f"Failed to update task records: {e}")
                                # Continue processing even if task records update fails
                    else:
                        ans_text = ""
                        error_logger.warning(
                            f"code={code} | id={item_id} | benchmark={benchmark_name} | subtask={subtask_name} | error={resp.get('error','NULL')}"
                        )
                        total_errors += 1
                        if code == 429:
                            rate_limit_429_count += 1
                            old = current_worker_num
                            current_worker_num = max(1, current_worker_num // 2)
                            error_logger.warning(f"RATE_LIMIT_429 | concurrency downgrade {old}→{current_worker_num}")
                    generated_answers[subtask_name].append({"id": item_id, "ans": ans_text})

                # # Save subtask results immediately after completion
                # import jsonlines
                # from config import get_server_dir
                # server_dir_for_save = get_server_dir()
                # result_dir = os.path.join(server_dir_for_save, benchmark_name, "cache", model_name, run_tag)
                # os.makedirs(result_dir, exist_ok=True)
                # result_path = os.path.join(result_dir, f"{subtask_name}.jsonl")
                # with jsonlines.open(result_path, 'w') as writer:
                #     for result in generated_answers[subtask_name]:
                #         writer.write(result)
                # print(f"Saved {subtask_name} results to {result_path}")

                # Current subtask processing completed, update current subtask
                task_records_file = os.path.join(project_root, "mep_client", "log", "task_records.json")
                if os.path.exists(task_records_file):
                    try:
                        with open(task_records_file, 'r', encoding='utf-8') as f:
                            task_records = json.load(f)
                        for i_record, record in enumerate(task_records):
                            if record["run_id"] == run_tag:
                                record["current_subtask"] = subtask_name
                                with open(task_records_file, 'w', encoding='utf-8') as f:
                                    json.dump(task_records, f, indent=2, ensure_ascii=False)
                                break
                    except (json.JSONDecodeError, IOError) as e:
                        error_logger.warning(f"Failed to update task records: {e}")
                        # Continue processing even if task records update fails

    def get_complete_answers():
        """Extract all completed answers from log and merge with newly generated answers"""
        log_dir = os.path.join(project_root, "mep_client", "log", f"{run_tag}_{model_name}")
        generation_log_file = os.path.join(log_dir, "generation.log")

        if not os.path.exists(generation_log_file):
            print(f"Log file does not exist, using currently generated answers")
            return generated_answers

        with open(generation_log_file, 'r', encoding='utf-8') as f:
            log_content = f.read()

        log_entry_pattern = re.compile(r'retrycount: 0\nbenchmark: (\w+)\nsubtask: (\S+)\nid: (\S+)\ngeneration: ([\s\S]*?)\nprompt: ([\s\S]*?)(?=retrycount: 0|$)', re.MULTILINE)

        matches = log_entry_pattern.findall(log_content)
        if not matches:
            print(f"No valid entries found in log, using currently generated answers")
            return generated_answers

        complete_results = {}

        if isinstance(generated_answers, dict):
            for subtask_name in generated_answers.keys():
                complete_results[subtask_name] = []
            for match in matches:
                benchmark, subtask, id_val, generation, prompt = match
                if not subtask:
                    subtask = "default"

                if subtask not in complete_results:
                    complete_results[subtask] = []

                try:
                    parsed_id = int(id_val)
                except Exception:
                    parsed_id = id_val
                exists = any(item["id"] == parsed_id for item in complete_results[subtask])
                if not exists:
                    complete_results[subtask].append({"id": parsed_id, "ans": generation.strip()})

            for subtask_name, subtask_results in generated_answers.items():
                for result in subtask_results:
                    existing = False
                    for item in complete_results[subtask_name]:
                        if item["id"] == result["id"]:
                            existing = True
                            break
                    if not existing:
                        complete_results[subtask_name].append(result)

        return complete_results

    complete_answers = get_complete_answers()

    save_intermediate_results(benchmark_name, model_name, run_tag, complete_answers)

    total_time = time.perf_counter() - start_time
    print(f"\nUser answer generation completed! Total time: {total_time:.2f} seconds")
    print(f"Logs saved to: {log_dir}/generation.log")

    final_json_path = None

    if isinstance(complete_answers, dict):
        total_completed = sum(len(items) for items in complete_answers.values())
    elif isinstance(complete_answers, list):
        total_completed = len(complete_answers)

    task_record["completed_questions"] = total_completed
    task_record["total_questions"] = total_questions

    # Check if paused
    if not (stop_event and stop_event.is_set()):
        task_record["completed"] = True
        task_record["status"] = "completed"
        print("Task completed")
    else:
        task_record["completed"] = False
        task_record["status"] = "paused"
        print("Task paused")

    # Update task record
    task_records_file = os.path.join(project_root, "mep_client", "log", "task_records.json")
    if os.path.exists(task_records_file):
        try:
            with open(task_records_file, 'r', encoding='utf-8') as f:
                task_records = json.load(f)
            for i, record in enumerate(task_records):
                if record["run_id"] == run_tag:
                    task_records[i] = task_record
                    break
            with open(task_records_file, 'w', encoding='utf-8') as f:
                json.dump(task_records, f, indent=2, ensure_ascii=False)
        except (json.JSONDecodeError, IOError) as e:
            error_logger.warning(f"Failed to update task records: {e}")
            # Continue processing even if task records update fails

    # Clean up log handlers, release file handles
    try:
        gen_logger = logging.getLogger("generation")
        for handler in gen_logger.handlers[:]:
            handler.close()
            gen_logger.removeHandler(handler)

        err_logger = logging.getLogger("error")
        for handler in err_logger.handlers[:]:
            handler.close()
            err_logger.removeHandler(handler)
    except Exception as e:
        pass

    metadata = {
        "run_tag": run_tag,
        "model_name": model_name,
        "log_dir": log_dir,
        "selected_benchmark": benchmark_name,
        "benchmarks_processed": benchmarks_processed,
        "batch_size": batch_size,
        "initial_worker_nums": worker_nums,
        "final_worker_nums": current_worker_num,
        "rate_limit": rate_limit,
        "bucket_capacity": bucket_capacity,
        "total_questions": total_questions,
        "total_success": total_success,
        "total_errors": total_errors,
        "rate_limit_429_count": rate_limit_429_count,
        "total_time_seconds": total_time,
        "convert_raw_to_json": convert_raw_to_json,
        "continue_generate": continue_generate,
        "limited_test": limited_test,
        "final_json_path": final_json_path,
        "created_at": datetime.datetime.now().isoformat()
    }
    return metadata