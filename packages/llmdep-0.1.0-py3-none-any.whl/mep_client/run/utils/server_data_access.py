def save_intermediate_results(benchmark_name, model_name, run_tag, results):
    """
    Save intermediate results (model-generated answers) to the server side
    
    Args:
        benchmark_name: Name of the benchmark
        model_name: Name of the model
        run_tag: Run identifier / tag
        results: Model-generated answers (usually dict of subtask → list of results)
    """
    import os
    import jsonlines
    import sys
    
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
    from config import get_server_dir
    
    server_dir = get_server_dir()
    result_dir = os.path.join(server_dir, benchmark_name, "cache", model_name, run_tag)
    os.makedirs(result_dir, exist_ok=True)
    
    for subtask_name, subtask_results in results.items():
        result_path = os.path.join(result_dir, f"{subtask_name}.jsonl")
        with jsonlines.open(result_path, 'w') as writer:
            for result in subtask_results:
                writer.write(result)


def get_evaluation_results(benchmark_name, model_name, run_tag):
    """
    Retrieve final evaluation results from the server side
    
    Args:
        benchmark_name: Name of the benchmark
        model_name: Name of the model
        run_tag: Run identifier / tag
    
    Returns:
        The evaluation result dictionary
    """
    import os
    import json
    import sys
    
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
    from config import get_server_dir
    
    server_dir = get_server_dir()
    eval_result_path = os.path.join(
        server_dir, benchmark_name, "cache", model_name, run_tag, "evaluation_report.json"
    )
    
    with open(eval_result_path, encoding='utf-8') as f:
        return json.load(f)


def save_final_results(benchmark_name, model_name, run_tag, evaluation_results):
    """
    Save final evaluation results to the client/project side
    
    Args:
        benchmark_name: Name of the benchmark/dataset
        model_name: Name of the model
        run_tag: Run identifier / tag
        evaluation_results: Dictionary containing the evaluation results
    """
    import os
    import json
    
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    result_dir = os.path.join(project_root, "final_results", benchmark_name, model_name, run_tag)
    os.makedirs(result_dir, exist_ok=True)
    
    # Save complete report
    complete_report = {
        "model": model_name,
        "time": run_tag,
        **evaluation_results
    }
    
    result_path = os.path.join(result_dir, "evaluation_report.json")
    with open(result_path, 'w', encoding='utf-8') as f:
        json.dump(complete_report, f, indent=4, ensure_ascii=False)
    
    # Save overall performance summary (append to all_results.json)
    formatted_results = {
        "model": model_name,
        "time": run_tag,
        **evaluation_results['overall_performance']
    }
    
    benchmark_summary_path = os.path.join(
        project_root, "final_results", benchmark_name, "all_results.json"
    )

    all_results = []
    if os.path.exists(benchmark_summary_path):
        with open(benchmark_summary_path, 'r', encoding='utf-8') as f:
            all_results = json.load(f)
    
    # Append new result
    all_results.append(formatted_results)
    
    with open(benchmark_summary_path, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, indent=4, ensure_ascii=False)


def run_server_evaluation(benchmark_name, model_name, run_tag):
    """
    Execute the benchmark's evaluation script (usually located on server side)
    from the client side in a unified manner.
    
    This function dynamically loads and runs the eval_script.py of the benchmark.
    """
    import os
    import sys
    import importlib.util
    import json
    
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
    from config import get_server_dir
    
    server_dir = get_server_dir()
    benchmark_dir = os.path.join(server_dir, benchmark_name)
    eval_script_path = os.path.join(benchmark_dir, "methods", "eval_script.py")
    
    # Dynamically import eval_script.py
    spec = importlib.util.spec_from_file_location("eval_script", eval_script_path)
    eval_module = importlib.util.module_from_spec(spec)
    sys.modules["eval_script"] = eval_module
    spec.loader.exec_module(eval_module)
    
    # Run evaluation
    evaluation_results = eval_module.evaluate(model_name, run_tag)
    
    # Save result to server cache
    eval_result_path = os.path.join(
        benchmark_dir, "cache", model_name, run_tag, "evaluation_report.json"
    )
    with open(eval_result_path, "w", encoding="utf-8") as f:
        json.dump(evaluation_results, f, indent=4, ensure_ascii=False)
    
    return evaluation_results