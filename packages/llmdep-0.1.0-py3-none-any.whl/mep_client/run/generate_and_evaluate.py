import os
import sys
import argparse
import warnings

warnings.filterwarnings("ignore", category=UserWarning)

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from config import load_llm_config

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from utils import generate_user_ans
from run import run_evaluation

_llm_cfg = load_llm_config()
add_model_args = _llm_cfg.add_model_args
instantiate_model = _llm_cfg.instantiate_model
get_model_choices = _llm_cfg.get_model_choices


def add_common_args(parser):
    parser.add_argument("--benchmark", required=False, help="Name of the benchmark to use")
    parser.add_argument("--batch_size", type=int, default=1, help="Batch size during generation")
    parser.add_argument("--rate_limit", type=float, default=5.0, help="Token bucket fill rate per second")
    parser.add_argument("--bucket_capacity", type=float, default=10.0, help="Token bucket capacity")
    parser.add_argument("--worker_nums", type=int, default=2, help="Number of concurrent worker threads")
    parser.add_argument("--limited_test", type=int, nargs='?', const=10, default=None, help="Limit test to N examples: --limited_test (10), --limited_test 50 (custom), no flag (full)")
    parser.add_argument("--continue_generate", action="store_true", help="Whether to continue an interrupted generation task")
    parser.add_argument("--run_id", type=str, default=None, help="Specify the run_id of the task to continue")


def parse_args():
    base = argparse.ArgumentParser(add_help=False)
    base.add_argument("--model_name", choices=get_model_choices(), required=False)
    add_common_args(base)
    known, _ = base.parse_known_args()

    full = argparse.ArgumentParser(description="Generate model answers and optionally run evaluation")
    full.add_argument("--model_name", choices=get_model_choices(), required=False)
    add_common_args(full)

    if getattr(known, "model_name", None):
        add_model_args(full, known.model_name)

    full.add_argument("--evaluate", action="store_true", help="Whether to run evaluation immediately after generation")

    args = full.parse_args()
    return args


def main():
    args = parse_args()

    # If run_id is provided, read corresponding model_name and benchmark from task_records.json
    if args.run_id:
        import json
        task_records_file = os.path.join(os.path.dirname(__file__), "..", "log", "task_records.json")
        if os.path.exists(task_records_file):
            with open(task_records_file, 'r', encoding='utf-8') as f:
                task_records = json.load(f)

            # Find matching run_id
            for record in task_records:
                if record["run_id"] == args.run_id:
                    if not args.model_name:
                        args.model_name = record["model"]
                        print(f"Retrieved model_name: {args.model_name}")
                    if not args.benchmark:
                        args.benchmark = record["benchmark"]
                        print(f"Retrieved benchmark: {args.benchmark}")
                    break

    # Validate required parameters
    if not args.model_name:
        print("Error: model_name must be provided or retrieved via run_id")
        return
    if not args.benchmark:
        print("Error: benchmark must be provided or retrieved via run_id")
        return

    model = instantiate_model(args.model_name, args)

    metadata = generate_user_ans(
        model=model,
        benchmark_name=args.benchmark,
        batch_size=args.batch_size,
        worker_nums=args.worker_nums,
        rate_limit=args.rate_limit,
        bucket_capacity=args.bucket_capacity,
        limited_test=args.limited_test,
        model_name=args.model_name,
        continue_generate=args.continue_generate,
        run_id=args.run_id
    )

    # If evaluation is requested, run it directly
    if args.evaluate:
        print("\nStarting evaluation...")

        # Use the actual run_tag returned by generate_user_ans
        run_tag = metadata["run_tag"]
        model_name = metadata["model_name"]
        actual_run_tag = f"{run_tag}_{model_name}"

        # Get selected_benchmark if available
        selected_benchmark = metadata.get("selected_benchmark", "BiPaR")

        # Run evaluation
        run_evaluation(actual_run_tag, selected_benchmark)


if __name__ == "__main__":
    main()