# - FastAPI server for evaluation APIs

from fastapi import FastAPI, Body
from typing import Dict, Any, List, Optional
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '.')))
from evaluation_api import (
    start_evaluation,
    pause_evaluation,
    continue_evaluation,
    get_dataset_ranking,
    get_model_benchmark_results,
    get_evaluation_result_by_run_id,
    get_task_status
)

app = FastAPI(
    title="Evaluation API Service",
    description="API for managing model evaluations in the background",
    version="1.0.0"
)

@app.post("/start_evaluation", response_model=Dict[str, str])
def api_start_evaluation(
    model_name: str = Body(...),
    benchmark: str = Body(...),
    body: Dict[str, Any] = Body(None)  # For additional kwargs like batch_size, etc.
):
    """
    Start a new evaluation task.
    """
    kwargs = body or {}
    return start_evaluation(model_name, benchmark, **kwargs)

@app.post("/pause_evaluation", response_model=Dict[str, str])
def api_pause_evaluation(run_id: str = Body(..., embed=True)):
    """
    Pause an ongoing evaluation task.
    """
    return pause_evaluation(run_id)

@app.post("/continue_evaluation", response_model=Dict[str, str])
def api_continue_evaluation(run_id: str = Body(..., embed=True)):
    """
    Continue a paused evaluation task.
    """
    return continue_evaluation(run_id)

@app.get("/dataset_ranking/{dataset_name}", response_model=List[Dict[str, Any]])
def api_get_dataset_ranking(dataset_name: str):
    """
    Get ranking of models on the specified dataset.
    """
    return get_dataset_ranking(dataset_name)

@app.get("/model_benchmark_results/{model_name}", response_model=Dict[str, Any])
def api_get_model_benchmark_results(model_name: str):
    """
    Get results of the same model across different benchmarks.
    """
    return get_model_benchmark_results(model_name)

@app.get("/evaluation_result/{run_id}", response_model=Dict[str, Any])
def api_get_evaluation_result_by_run_id(run_id: str):
    """
    Query evaluation result by run_id.
    """
    return get_evaluation_result_by_run_id(run_id)

@app.get("/task_status/{run_id}", response_model=Dict[str, Any])
def api_get_task_status(run_id: str):
    """
    Get current status of a task.
    """
    return get_task_status(run_id)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, workers=1)