#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
llmdep CLI Entry Point

This module serves as the command-line interface for llmdep.
It parses command-line arguments and delegates to the existing
generate_and_evaluate.py module.

Usage:
    llmdep gen_eval --benchmark ARC --model qwen-plus --worker_nums 20 --evaluate
    llmdep gen_eval -b ethics -m deepseek -w 10 --limited_test 10
"""

import sys
import os
import argparse


def main():
    """
    Main entry point.
    
    Workflow:
    1. Parse user command (gen_eval, evaluate, list)
    2. Convert arguments to format expected by generate_and_evaluate.py
    3. Call the main() function from generate_and_evaluate.py
    """
    
    # Create main parser
    parser = argparse.ArgumentParser(
        prog="llmdep",
        description="Benchmark Server - Distributed LLM Evaluation Benchmark"
    )
    
    # Create subparsers (like 'pip install', 'pip uninstall')
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # ========== Subcommand 1: gen_eval ==========
    # llmdep gen_eval --benchmark ARC --model qwen-plus --evaluate
    gen_eval_parser = subparsers.add_parser(
        "gen_eval",
        help="Generate model answers (with optional evaluation)"
    )
    
    # Arguments (can be auto-retrieved from task_records if run_id is provided)
    gen_eval_parser.add_argument(
        "--benchmark", "-b",
        required=False,
        help="Benchmark name, e.g., ARC, ethics, ARC_parquet"
    )
    gen_eval_parser.add_argument(
        "--model", "-m",
        required=False,
        help="Model name, e.g., qwen-plus, deepseek"
    )
    
    # Optional arguments (with defaults)
    gen_eval_parser.add_argument(
        "--worker_nums", "-w",
        type=int,
        default=2,
        help="Number of concurrent worker threads (default: 2)"
    )
    gen_eval_parser.add_argument(
        "--batch_size",
        type=int,
        default=1,
        help="Batch size for processing (default: 1)"
    )
    gen_eval_parser.add_argument(
        "--rate_limit",
        type=float,
        default=5.0,
        help="Token bucket fill rate per second (default: 5.0)"
    )
    gen_eval_parser.add_argument(
        "--bucket_capacity",
        type=float,
        default=10.0,
        help="Token bucket capacity (default: 10.0)"
    )
    
    # Flag arguments (store_true)
    gen_eval_parser.add_argument(
        "--evaluate", "-e",
        action="store_true",
        help="Run evaluation immediately after generation"
    )
    gen_eval_parser.add_argument(
        "--limited_test",
        type=int,
        nargs='?',
        const=10,
        default=None,
        help="--limited_test (10 questions), --limited_test N (custom), no flag (full test)"
    )
    gen_eval_parser.add_argument(
        "--continue_generate",
        action="store_true",
        help="Continue from interrupted task"
    )
    gen_eval_parser.add_argument(
        "--run_id",
        type=str,
        default=None,
        help="Specify run_id to continue"
    )
    
    # ========== Subcommand 2: evaluate ==========
    # llmdep evaluate --benchmark ARC --run_tag 20260210-164048-322281_qwen-plus
    eval_parser = subparsers.add_parser(
        "evaluate",
        help="Evaluate existing results only"
    )
    eval_parser.add_argument(
        "--benchmark", "-b",
        required=True,
        help="Benchmark name"
    )
    eval_parser.add_argument(
        "--run_tag", "-r",
        required=True,
        help="Run tag (format: timestamp_modelname)"
    )
    
    # ========== Subcommand 3: list ==========
    # llmdep list                    (list both)
    # llmdep list benchmark          (list only benchmarks)
    # llmdep list model              (list only models)
    list_parser = subparsers.add_parser(
        "list",
        help="List available benchmarks and models"
    )
    list_parser.add_argument(
        "type",
        choices=["benchmark", "model"],
        nargs="?",
        default=None,
        help="List only benchmarks or only models (default: list both)"
    )
    
    # ========== Subcommand 4: batch ==========
    # llmdep batch --config tasks.json
    batch_parser = subparsers.add_parser(
        "batch",
        help="Batch process multiple tasks from config file"
    )
    batch_parser.add_argument(
        "--config", "-c",
        help="Batch task config file (default: all.json in mep_client/run/)"
    )
    batch_parser.add_argument(
        "--worker_nums", "-w",
        type=int,
        default=6,
        help="Number of concurrent worker threads (default: 6)"
    )
    batch_parser.add_argument(
        "--batch_size",
        type=int,
        default=1,
        help="Batch size for processing (default: 1)"
    )
    batch_parser.add_argument(
        "--rate_limit",
        type=float,
        default=5.0,
        help="Token bucket fill rate per second (default: 5.0)"
    )
    batch_parser.add_argument(
        "--bucket_capacity",
        type=float,
        default=20.0,
        help="Token bucket capacity (default: 20.0)"
    )
    batch_parser.add_argument(
        "--limited_test",
        type=int,
        nargs='?',
        const=10,
        default=None,
        help="--limited_test (10 questions), --limited_test N (custom), no flag (full test)"
    )
    
    # ========== Subcommand 5: loadllm ==========
    # llmdep loadllm /path/to/model_dir
    # llmdep loadllm --batch /path/to/folder_with_models
    loadllm_parser = subparsers.add_parser(
        "loadllm",
        help="Load a custom LLM model into llmdep"
    )
    loadllm_parser.add_argument(
        "path",
        help="Path to the model directory (e.g., /path/to/my_model)"
    )
    loadllm_parser.add_argument(
        "--move", "-m",
        action="store_true",
        help="Move instead of copy (delete original folder)"
    )
    loadllm_parser.add_argument(
        "--batch", "-b",
        action="store_true",
        help="Batch mode: load all subdirectories as separate models"
    )
    
    # ========== Subcommand 6: loadbench ==========
    # llmdep loadbench /path/to/benchmark_dir
    # llmdep loadbench --batch /path/to/folder_with_benchmarks
    loadbench_parser = subparsers.add_parser(
        "loadbench",
        help="Load a custom benchmark into llmdep"
    )
    loadbench_parser.add_argument(
        "path",
        help="Path to the benchmark directory (e.g., /path/to/ARC)"
    )
    loadbench_parser.add_argument(
        "--move", "-m",
        action="store_true",
        help="Move instead of copy (delete original folder)"
    )
    loadbench_parser.add_argument(
        "--batch", "-b",
        action="store_true",
        help="Batch mode: load all subdirectories as separate benchmarks"
    )
    
    # ========== Subcommand 7: loadconfig ==========
    # llmdep loadconfig /path/to/config.py
    loadconfig_parser = subparsers.add_parser(
        "loadconfig",
        help="Load LLM configuration file"
    )
    loadconfig_parser.add_argument(
        "path",
        help="Path to the config.py file (e.g., /path/to/llm/config.py)"
    )
    loadconfig_parser.add_argument(
        "--move", "-m",
        action="store_true",
        help="Move instead of copy (delete original file)"
    )
    
    # ========== Subcommand 8: where ==========
    # llmdep where
    where_parser = subparsers.add_parser(
        "where",
        help="Show llmdep package installation path"
    )
    
    # ========== Subcommand 9: exportall ==========
    # llmdep exportall /path/to/export
    export_parser = subparsers.add_parser(
        "exportall",
        help="Export all user configurations (models, benchmarks, config)"
    )
    export_parser.add_argument(
        "path",
        help="Path to export configurations to (will create a folder structure)"
    )
    
    # ========== Subcommand 10: importall ==========
    # llmdep importall /path/to/export
    import_parser = subparsers.add_parser(
        "importall",
        help="Import all configurations from an exported folder"
    )
    import_parser.add_argument(
        "path",
        help="Path to the folder containing exported configurations"
    )
    import_parser.add_argument(
        "--move", "-m",
        action="store_true",
        help="Move instead of copy (delete original files)"
    )
    
    # ========== Parse arguments ==========
    # Show help if no args
    if len(sys.argv) == 1:
        parser.print_help()
        return
    
    args = parser.parse_args()
    
    # ========== Execute command ==========
    if args.command == "gen_eval":
        run_gen_eval(args)
    elif args.command == "evaluate":
        run_evaluate_only(args)
    elif args.command == "list":
        run_list(args)
    elif args.command == "batch":
        run_batch(args)
    elif args.command == "loadllm":
        run_loadllm(args)
    elif args.command == "loadbench":
        run_loadbench(args)
    elif args.command == "loadconfig":
        run_loadconfig(args)
    elif args.command == "where":
        run_where()
    elif args.command == "exportall":
        run_exportall(args)
    elif args.command == "importall":
        run_importall(args)
    else:
        parser.print_help()


def run_gen_eval(args):
    """
    Execute gen_eval command.
    
    How it works:
        1. Replace sys.argv with the format expected by generate_and_evaluate.py
        2. Import and call generate_and_evaluate.main()
    
    Example user input:
        llmdep gen_eval -b ARC -m qwen-plus -w 20 -e
    
    Converted to generate_and_evaluate.py format:
        python generate_and_evaluate.py --benchmark ARC --model_name qwen-plus --worker_nums 20 --evaluate
    """
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Check for required files/directories and give helpful tips
    config_path = os.path.join(current_dir, "llm", "config.py")
    if not os.path.exists(config_path):
        print("=" * 60)
        print("ERROR: LLM config file not found!")
        print("=" * 60)
        print(f"Missing: {config_path}")
        print("")
        print("Please load your config file first:")
        print("  llmdep loadconfig /path/to/llm/config.py")
        print("")
        return
    
    # Check if MODEL_REGISTRY is empty
    try:
        import llm.config as llm_config
        if not llm_config.MODEL_REGISTRY:
            print("=" * 60)
            print("ERROR: No models configured in config.py!")
            print("=" * 60)
            print("MODEL_REGISTRY is empty. Please update your config.py")
            print("to add model configurations, or load a complete config:")
            print("  llmdep loadconfig /path/to/llm/config.py")
            print("")
            return
    except Exception as e:
        print(f"Warning: Could not check MODEL_REGISTRY - {e}")
    
    # Check if benchmark exists
    if args.benchmark:
        benchmark_path = os.path.join(current_dir, "method_server", args.benchmark)
        if not os.path.exists(benchmark_path):
            print("=" * 60)
            print(f"ERROR: Benchmark '{args.benchmark}' not found!")
            print("=" * 60)
            print(f"Missing: {benchmark_path}")
            print("")
            print("Please load your benchmark first:")
            print(f"  llmdep loadbench /path/to/{args.benchmark}")
            print("")
            print("Or list available benchmarks:")
            print("  llmdep list benchmark")
            print("")
            return
    
    # Check if model exists
    if args.model:
        model_folder = args.model.replace('-', '_')
        model_path = os.path.join(current_dir, "llm", model_folder)
        if not os.path.exists(model_path):
            print("=" * 60)
            print(f"ERROR: Model '{args.model}' not found!")
            print("=" * 60)
            print(f"Missing folder: {model_path}")
            print("")
            print("Please load your model first:")
            print(f"  llmdep loadllm /path/to/{model_folder}")
            print("")
            print("Or list available models:")
            print("  llmdep list model")
            print("")
            print("Note: Make sure the model is also registered in llm/config.py")
            print("")
            return
    
    # Build new sys.argv
    # Note: generate_and_evaluate.py uses --model_name, not --model
    new_argv = [
        "generate_and_evaluate.py",
        "--worker_nums", str(args.worker_nums),
        "--batch_size", str(args.batch_size),
        "--rate_limit", str(args.rate_limit),
        "--bucket_capacity", str(args.bucket_capacity),
    ]
    
    # Add optional arguments (can be auto-retrieved from run_id)
    if args.benchmark:
        new_argv.extend(["--benchmark", args.benchmark])
    if args.model:
        new_argv.extend(["--model_name", args.model])  # Note: parameter name differs!
    if args.run_id:
        new_argv.extend(["--run_id", args.run_id])
    
    # Add flag arguments
    if args.evaluate:
        new_argv.append("--evaluate")
    if args.limited_test is not None:
        new_argv.extend(["--limited_test", str(args.limited_test)])
    if args.continue_generate:
        new_argv.append("--continue_generate")
    
    # Replace sys.argv
    old_argv = sys.argv
    sys.argv = new_argv
    
    try:
        # Add mep_client/run to Python path
        run_dir = os.path.join(current_dir, "mep_client", "run")
        if run_dir not in sys.path:
            sys.path.insert(0, run_dir)
        
        # Add mep_client to Python path (for config.py)
        mep_client_dir = os.path.join(current_dir, "mep_client")
        if mep_client_dir not in sys.path:
            sys.path.insert(0, mep_client_dir)
        
        # Add llm to Python path
        llm_dir = os.path.join(current_dir, "llm")
        if llm_dir not in sys.path:
            sys.path.insert(0, llm_dir)
        
        # Set working directory
        os.chdir(current_dir)
        
        # Import and call generate_and_evaluate.py
        import generate_and_evaluate
        generate_and_evaluate.main()
        
    finally:
        # Restore original sys.argv
        sys.argv = old_argv


def run_evaluate_only(args):
    """
    Execute evaluation only (without generation).
    
    Example:
        llmdep evaluate -b ARC -r 20260210-164048-322281_qwen-plus
    """
    current_dir = os.path.dirname(os.path.abspath(__file__))
    run_dir = os.path.join(current_dir, "mep_client", "run")
    mep_client_dir = os.path.join(current_dir, "mep_client")
    
    old_path = sys.path.copy()
    old_cwd = os.getcwd()
    
    try:
        if run_dir not in sys.path:
            sys.path.insert(0, run_dir)
        if mep_client_dir not in sys.path:
            sys.path.insert(0, mep_client_dir)
        os.chdir(current_dir)
        
        from run import run_evaluation
        run_evaluation(args.run_tag, args.benchmark)
        print(f"\nEvaluation completed! Results saved to final_results/{args.benchmark}/")
        
    finally:
        sys.path = old_path
        os.chdir(old_cwd)


def run_batch(args):
    """
    Execute batch processing.
    
    Config file format (JSON array):
    [
        {"model": "qwen-plus", "benchmark": "ARC_parquet"},
        {"model": "deepseek", "benchmark": "ethics"}
    ]
    
    Example:
        llmdep batch --config my_tasks.json
        llmdep batch -w 10 --limited_test 50
    """
    import json
    import argparse
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    run_dir = os.path.join(current_dir, "mep_client", "run")
    mep_client_dir = os.path.join(current_dir, "mep_client")
    llm_dir = os.path.join(current_dir, "llm")
    
    old_path = sys.path.copy()
    old_cwd = os.getcwd()
    
    try:
        os.chdir(current_dir)
        
        # Insert order matters: later insert(0) goes to the front
        # Priority: run_dir > mep_client_dir > llm_dir
        # mep_client/config.py has load_llm_config, so it must be before llm/config.py
        sys.path.insert(0, llm_dir)
        sys.path.insert(0, mep_client_dir)
        sys.path.insert(0, run_dir)
        
        # Get config file
        if args.config:
            config_path = args.config
        else:
            config_path = os.path.join(run_dir, "all.json")
        
        if not os.path.exists(config_path):
            print(f"Error: Config file not found -> {config_path}")
            return
        
        with open(config_path, encoding="utf-8") as f:
            tasks = json.load(f)
        
        if not isinstance(tasks, list) or not tasks:
            print("Error: Config file should be a non-empty JSON array")
            return
        
        print(f"Loaded {len(tasks)} tasks from {config_path}\n")
        
        from config import load_llm_config
        from utils import generate_user_ans
        from run import run_evaluation
        
        _llm_cfg = load_llm_config()
        add_model_args = _llm_cfg.add_model_args
        instantiate_model = _llm_cfg.instantiate_model
        
        for i, task in enumerate(tasks, 1):
            model_name = task.get("model")
            benchmark = task.get("benchmark")
            
            if not model_name or not benchmark:
                print(f"Task {i} missing model or benchmark, skipping")
                continue
            
            print(f"\n{'='*50}")
            print(f"[ {i}/{len(tasks)} ] {model_name} @ {benchmark}")
            print(f"{'='*50}")
            
            model_parser = argparse.ArgumentParser(add_help=False)
            add_model_args(model_parser, model_name)
            
            combined = {
                "model_name": model_name,
                "benchmark": benchmark,
                "batch_size": args.batch_size,
                "worker_nums": args.worker_nums,
                "rate_limit": args.rate_limit,
                "bucket_capacity": args.bucket_capacity,
                "limited_test": args.limited_test,
            }
            
            model_specific_args = model_parser.parse_args([])
            for k, v in vars(model_specific_args).items():
                if k not in combined or combined[k] is None:
                    combined[k] = v
            
            model = instantiate_model(model_name, argparse.Namespace(**combined))
            
            metadata = generate_user_ans(
                model=model,
                benchmark_name=benchmark,
                batch_size=args.batch_size,
                worker_nums=args.worker_nums,
                rate_limit=args.rate_limit,
                bucket_capacity=args.bucket_capacity,
                limited_test=args.limited_test,
                model_name=model_name
            )
            
            run_tag = metadata.get("run_tag")
            actual_model_name = metadata.get("model_name", model_name)
            selected_benchmark = metadata.get("selected_benchmark", benchmark)
            
            if run_tag:
                actual_run_tag = f"{run_tag}_{actual_model_name}"
                try:
                    run_evaluation(actual_run_tag, selected_benchmark)
                    print(f"Task {i} evaluation completed")
                except Exception as e:
                    print(f"Task {i} evaluation failed: {e}")
            else:
                print(f"Warning: metadata missing run_tag, skipping evaluation")
        
        print(f"\n{'='*50}")
        print("All tasks processed")
        print(f"{'='*50}")
        
    finally:
        sys.path = old_path
        os.chdir(old_cwd)


def run_loadllm(args):
    """
    Load a custom LLM model into llmdep.
    
    Args:
        args.path: Path to the model directory or parent directory in batch mode
        args.move: If True, move instead of copy (delete original folder)
        args.batch: If True, load all subdirectories as separate models
    
    Example:
        llmdep loadllm /path/to/my_qwen_model
        llmdep loadllm /path/to/my_qwen_model --move
        llmdep loadllm --batch /path/to/folder_with_multiple_models
    """
    import shutil
    
    PROTECTED_LLM = {"BaseModel.py", "config.py", "__init__.py", "__pycache__"}
    
    def is_protected_llm(name):
        return name in PROTECTED_LLM or name.lower() in [p.lower() for p in PROTECTED_LLM]
    
    source_path = os.path.abspath(args.path)
    
    if not os.path.exists(source_path):
        print(f"Error: Source path does not exist -> {source_path}")
        return
    
    if not os.path.isdir(source_path):
        print(f"Error: Source path is not a directory -> {source_path}")
        return
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    llm_dir = os.path.join(current_dir, "llm")
    
    if args.batch:
        subdirs = [d for d in os.listdir(source_path) 
                   if os.path.isdir(os.path.join(source_path, d)) and not d.startswith('__') and not d.startswith('.')]
        
        if not subdirs:
            print(f"No subdirectories found in -> {source_path}")
            return
        
        valid_models = []
        invalid = []
        for d in subdirs:
            card_path = os.path.join(source_path, d, "model_card.json")
            if os.path.exists(card_path):
                valid_models.append(d)
            else:
                invalid.append(d)
        
        if invalid:
            print(f"[SKIP] Not valid models (missing model_card.json): {', '.join(invalid)}")
        
        filtered = [d for d in valid_models if not is_protected_llm(d)]
        protected_skipped = [d for d in valid_models if is_protected_llm(d)]
        if protected_skipped:
            print(f"[SKIP] Protected items: {', '.join(protected_skipped)}")
        
        if not filtered:
            print(f"No valid models found to import")
            return
        
        print(f"Batch mode: loading {len(filtered)} models...")
        print("=" * 50)
        
        existing = []
        new_items = []
        for model_name in filtered:
            dst = os.path.join(llm_dir, model_name)
            if os.path.exists(dst):
                existing.append(model_name)
            else:
                new_items.append(model_name)
        
        replace_existing = False
        if existing:
            print(f"Found {len(existing)} existing models: {', '.join(existing)}")
            print(f"Found {len(new_items)} new models")
            response = input(f"Replace {len(existing)} existing model(s)? [y/N]: ")
            if response.lower() in ['y', 'yes']:
                replace_existing = True
        
        success = []
        skipped = []
        
        for model_name in filtered:
            src = os.path.join(source_path, model_name)
            dst = os.path.join(llm_dir, model_name)
            
            if os.path.exists(dst):
                if not replace_existing:
                    print(f"[SKIP] '{model_name}' already exists")
                    skipped.append(model_name)
                    continue
                
                try:
                    shutil.rmtree(dst)
                except Exception as e:
                    print(f"[FAIL] Cannot remove existing '{model_name}' -> {e}")
                    skipped.append(model_name)
                    continue
            
            try:
                if not args.move:
                    shutil.copytree(src, dst)
                    print(f"[COPY] '{model_name}' -> {dst}")
                else:
                    shutil.move(src, dst)
                    print(f"[MOVE] '{model_name}' -> {dst}")
                success.append(model_name)
            except Exception as e:
                print(f"[FAIL] '{model_name}' -> {e}")
                skipped.append(model_name)
        
        print("=" * 50)
        print(f"Results: {len(success)} loaded, {len(skipped)} skipped")
        if success:
            print(f"Available models: {', '.join(success)}")
    else:
        model_name = os.path.basename(source_path.rstrip(os.sep))
        
        if is_protected_llm(model_name):
            print(f"Error: '{model_name}' is a protected framework file, not a model directory")
            print(f"Protected items: {', '.join(PROTECTED_LLM)}")
            return
        
        target_path = os.path.join(llm_dir, model_name)
        
        if os.path.exists(target_path):
            print(f"Warning: Model '{model_name}' already exists at -> {target_path}")
            response = input("Replace existing model? [y/N]: ")
            if response.lower() not in ['y', 'yes']:
                print("Operation cancelled.")
                return
            
            try:
                shutil.rmtree(target_path)
            except Exception as e:
                print(f"Error: Cannot remove existing model -> {e}")
                return
        
        if not args.move:
            print(f"Copying model '{model_name}'...")
            shutil.copytree(source_path, target_path)
            print(f"Successfully copied to: {target_path}")
        else:
            print(f"Moving model '{model_name}'...")
            shutil.move(source_path, target_path)
            print(f"Successfully moved to: {target_path}")
        
        print(f"\nYou can now use this model with: llmdep gen_eval -m {model_name} -b <benchmark>")


def run_loadbench(args):
    """
    Load a custom benchmark into llmdep.
    
    Args:
        args.path: Path to the benchmark directory or parent directory in batch mode
        args.move: If True, move instead of copy (delete original folder)
        args.batch: If True, load all subdirectories as separate benchmarks
    
    Example:
        llmdep loadbench /path/to/ARC
        llmdep loadbench /path/to/ARC --move
        llmdep loadbench --batch /path/to/folder_with_multiple_benchmarks
    """
    import shutil
    
    PROTECTED_BENCH = {"eval", "__init__.py", "__pycache__"}
    
    def is_protected_bench(name):
        return name in PROTECTED_BENCH or name.lower() in [p.lower() for p in PROTECTED_BENCH]
    
    source_path = os.path.abspath(args.path)
    
    if not os.path.exists(source_path):
        print(f"Error: Source path does not exist -> {source_path}")
        return
    
    if not os.path.isdir(source_path):
        print(f"Error: Source path is not a directory -> {source_path}")
        return
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    method_server_dir = os.path.join(current_dir, "method_server")
    
    if args.batch:
        subdirs = [d for d in os.listdir(source_path) 
                   if os.path.isdir(os.path.join(source_path, d)) and not d.startswith('__') and not d.startswith('.')]
        
        if not subdirs:
            print(f"No subdirectories found in -> {source_path}")
            return
        
        valid_benches = []
        invalid = []
        for d in subdirs:
            card_path = os.path.join(source_path, d, "dataset_card.json")
            if os.path.exists(card_path):
                valid_benches.append(d)
            else:
                invalid.append(d)
        
        if invalid:
            print(f"[SKIP] Not valid benchmarks (missing dataset_card.json): {', '.join(invalid)}")
        
        filtered = [d for d in valid_benches if not is_protected_bench(d)]
        protected_skipped = [d for d in valid_benches if is_protected_bench(d)]
        if protected_skipped:
            print(f"[SKIP] Protected items: {', '.join(protected_skipped)}")
        
        if not filtered:
            print(f"No valid benchmarks found to import")
            return
        
        print(f"Batch mode: loading {len(filtered)} benchmarks...")
        print("=" * 50)
        
        existing = []
        new_items = []
        for bench_name in filtered:
            dst = os.path.join(method_server_dir, bench_name)
            if os.path.exists(dst):
                existing.append(bench_name)
            else:
                new_items.append(bench_name)
        
        replace_existing = False
        if existing:
            print(f"Found {len(existing)} existing benchmarks: {', '.join(existing)}")
            print(f"Found {len(new_items)} new benchmarks")
            response = input(f"Replace {len(existing)} existing benchmark(s)? [y/N]: ")
            if response.lower() in ['y', 'yes']:
                replace_existing = True
        
        success = []
        skipped = []
        
        for bench_name in filtered:
            src = os.path.join(source_path, bench_name)
            dst = os.path.join(method_server_dir, bench_name)
            
            if os.path.exists(dst):
                if not replace_existing:
                    print(f"[SKIP] '{bench_name}' already exists")
                    skipped.append(bench_name)
                    continue
                
                try:
                    shutil.rmtree(dst)
                except Exception as e:
                    print(f"[FAIL] Cannot remove existing '{bench_name}' -> {e}")
                    skipped.append(bench_name)
                    continue
            
            try:
                if not args.move:
                    shutil.copytree(src, dst)
                    print(f"[COPY] '{bench_name}' -> {dst}")
                else:
                    shutil.move(src, dst)
                    print(f"[MOVE] '{bench_name}' -> {dst}")
                success.append(bench_name)
            except Exception as e:
                print(f"[FAIL] '{bench_name}' -> {e}")
                skipped.append(bench_name)
        
        print("=" * 50)
        print(f"Results: {len(success)} loaded, {len(skipped)} skipped")
        if success:
            print(f"Available benchmarks: {', '.join(success)}")
    else:
        bench_name = os.path.basename(source_path.rstrip(os.sep))
        
        if is_protected_bench(bench_name):
            print(f"Error: '{bench_name}' is a protected framework folder, not a benchmark")
            print(f"Protected items: {', '.join(PROTECTED_BENCH)}")
            return
        
        target_path = os.path.join(method_server_dir, bench_name)
        
        if os.path.exists(target_path):
            print(f"Warning: Benchmark '{bench_name}' already exists at -> {target_path}")
            response = input("Replace existing benchmark? [y/N]: ")
            if response.lower() not in ['y', 'yes']:
                print("Operation cancelled.")
                return
            
            try:
                shutil.rmtree(target_path)
            except Exception as e:
                print(f"Error: Cannot remove existing benchmark -> {e}")
                return
        
        if not args.move:
            print(f"Copying benchmark '{bench_name}'...")
            shutil.copytree(source_path, target_path)
            print(f"Successfully copied to: {target_path}")
        else:
            print(f"Moving benchmark '{bench_name}'...")
            shutil.move(source_path, target_path)
            print(f"Successfully moved to: {target_path}")
        
        print(f"\nYou can now use this benchmark with: llmdep gen_eval -b {bench_name} -m <model>")


def run_loadconfig(args):
    """
    Load LLM configuration file.
    
    Args:
        args.path: Path to the config.py file
        args.move: If True, move instead of copy (delete original file)
    
    Example:
        llmdep loadconfig /path/to/llm/config.py
        llmdep loadconfig /path/to/llm/config.py --move
    """
    import shutil
    
    source_path = os.path.abspath(args.path)
    
    if not os.path.exists(source_path):
        print(f"Error: Source file does not exist -> {source_path}")
        return
    
    if not os.path.isfile(source_path):
        print(f"Error: Source path is not a file -> {source_path}")
        return
    
    if not source_path.endswith('.py'):
        print(f"Warning: Source file is not a .py file -> {source_path}")
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_path = os.path.join(current_dir, "llm", "config.py")
    
    if os.path.exists(target_path):
        print(f"Warning: config.py already exists at {target_path}")
        print("WARNING: Replacing config.py may break existing model configurations!")
        response = input("Replace existing config.py? [y/N]: ")
        if response.lower() not in ['y', 'yes']:
            print("Operation cancelled.")
            return
    
    if not args.move:
        print(f"Copying config.py...")
        shutil.copy2(source_path, target_path)
        print(f"Successfully copied to: {target_path}")
    else:
        print(f"Moving config.py...")
        shutil.move(source_path, target_path)
        print(f"Successfully moved to: {target_path}")
    
    print(f"\nConfig loaded successfully!")


def run_where():
    """
    Show llmdep package installation path.
    
    Example:
        llmdep where
    """
    current_dir = os.path.dirname(os.path.abspath(__file__))
    print(f"llmdep installation path: {current_dir}")
    print("")
    print("Key directories:")
    print(f"  LLM models:     {os.path.join(current_dir, 'llm')}")
    print(f"  LLM config:     {os.path.join(current_dir, 'llm', 'config.py')}")
    print(f"  Benchmarks:     {os.path.join(current_dir, 'method_server')}")


def run_exportall(args):
    """
    Export all user configurations (models, benchmarks, config.py).
    
    Creates a folder structure:
    <export_path>/
      llm/
        config.py
        model1/
        model2/
        ...
      benchmarks/
        benchmark1/
        benchmark2/
        ...
    
    Args:
        args.path: Path to export configurations to
    
    Example:
        llmdep exportall /path/to/my_backup
    """
    import shutil
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    llm_dir = os.path.join(current_dir, "llm")
    method_server_dir = os.path.join(current_dir, "method_server")
    
    PROTECTED_LLM = {"BaseModel.py", "config.py", "__init__.py", "__pycache__", "config_backup.py"}
    PROTECTED_BENCH = {"eval", "__init__.py", "__pycache__"}
    
    export_path = os.path.abspath(args.path)
    
    if os.path.exists(export_path):
        response = input(f"Warning: Export path '{export_path}' already exists. Overwrite? [y/N]: ")
        if response.lower() not in ['y', 'yes']:
            print("Operation cancelled.")
            return
        shutil.rmtree(export_path)
    
    export_llm = os.path.join(export_path, "llm")
    export_bench = os.path.join(export_path, "benchmarks")
    os.makedirs(export_llm, exist_ok=True)
    os.makedirs(export_bench, exist_ok=True)
    
    print(f"Exporting configurations to: {export_path}")
    print("=" * 50)
    
    config_src = os.path.join(llm_dir, "config.py")
    if os.path.exists(config_src):
        shutil.copy2(config_src, os.path.join(export_llm, "config.py"))
        print("[EXPORT] llm/config.py")
    
    models = [d for d in os.listdir(llm_dir) 
              if os.path.isdir(os.path.join(llm_dir, d)) and d not in PROTECTED_LLM]
    
    for model in models:
        src = os.path.join(llm_dir, model)
        dst = os.path.join(export_llm, model)
        shutil.copytree(src, dst)
        print(f"[EXPORT] llm/{model}/")
    
    benchmarks = [d for d in os.listdir(method_server_dir) 
                if os.path.isdir(os.path.join(method_server_dir, d)) and d not in PROTECTED_BENCH]
    
    for bench in benchmarks:
        src = os.path.join(method_server_dir, bench)
        dst = os.path.join(export_bench, bench)
        shutil.copytree(src, dst)
        print(f"[EXPORT] benchmarks/{bench}/")
    
    print("=" * 50)
    print(f"Export complete!")
    print(f"")
    print(f"To import on another installation:")
    print(f"  llmdep importall {export_path}")


def run_importall(args):
    """
    Import all configurations from an exported folder.
    
    Expected folder structure:
    <import_path>/
      llm/
        config.py
        model1/
        model2/
        ...
      benchmarks/
        benchmark1/
        benchmark2/
        ...
    
    Args:
        args.path: Path to the folder containing exported configurations
        args.move: If True, move instead of copy (delete original files)
    
    Example:
        llmdep importall /path/to/my_backup
        llmdep importall /path/to/my_backup --move
    """
    import shutil
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    llm_dir = os.path.join(current_dir, "llm")
    method_server_dir = os.path.join(current_dir, "method_server")
    
    PROTECTED_LLM = {"BaseModel.py", "config.py", "__init__.py", "__pycache__", "config_backup.py"}
    PROTECTED_BENCH = {"eval", "__init__.py", "__pycache__"}
    
    import_path = os.path.abspath(args.path)
    
    if not os.path.exists(import_path):
        print(f"Error: Import path does not exist -> {import_path}")
        return
    
    import_llm = os.path.join(import_path, "llm")
    import_bench = os.path.join(import_path, "benchmarks")
    
    if not os.path.exists(import_llm) and not os.path.exists(import_bench):
        print(f"Error: No 'llm' or 'benchmarks' folder found in {import_path}")
        print("Expected structure: <path>/llm/ and <path>/benchmarks/")
        return
    
    print(f"Importing configurations from: {import_path}")
    print("=" * 50)
    
    if os.path.exists(import_llm):
        config_src = os.path.join(import_llm, "config.py")
        if os.path.exists(config_src):
            config_dst = os.path.join(llm_dir, "config.py")
            if os.path.exists(config_dst):
                print(f"[EXIST] llm/config.py already exists")
                response = input("Replace existing config.py? [y/N]: ")
                if response.lower() in ['y', 'yes']:
                    shutil.copy2(config_src, config_dst)
                    print(f"[IMPORT] llm/config.py")
            else:
                shutil.copy2(config_src, config_dst)
                print(f"[IMPORT] llm/config.py")
        
        models = [d for d in os.listdir(import_llm) 
                  if os.path.isdir(os.path.join(import_llm, d)) and d not in PROTECTED_LLM]
        
        if models:
            print(f"Found {len(models)} model(s) to import")
            existing = [m for m in models if os.path.exists(os.path.join(llm_dir, m))]
            if existing:
                print(f"  Existing models: {', '.join(existing)}")
                response = input("Replace existing model(s)? [y/N]: ")
                replace = response.lower() in ['y', 'yes']
            else:
                replace = False
            
            for model in models:
                src = os.path.join(import_llm, model)
                dst = os.path.join(llm_dir, model)
                
                if os.path.exists(dst):
                    if not replace:
                        print(f"[SKIP] llm/{model}/ (already exists)")
                        continue
                    shutil.rmtree(dst)
                
                if not args.move:
                    shutil.copytree(src, dst)
                    print(f"[COPY] llm/{model}/")
                else:
                    shutil.move(src, dst)
                    print(f"[MOVE] llm/{model}/")
    
    if os.path.exists(import_bench):
        benchmarks = [d for d in os.listdir(import_bench) 
                     if os.path.isdir(os.path.join(import_bench, d)) and d not in PROTECTED_BENCH]
        
        if benchmarks:
            print(f"Found {len(benchmarks)} benchmark(s) to import")
            existing = [b for b in benchmarks if os.path.exists(os.path.join(method_server_dir, b))]
            if existing:
                print(f"  Existing benchmarks: {', '.join(existing)}")
                response = input("Replace existing benchmark(s)? [y/N]: ")
                replace = response.lower() in ['y', 'yes']
            else:
                replace = False
            
            for bench in benchmarks:
                src = os.path.join(import_bench, bench)
                dst = os.path.join(method_server_dir, bench)
                
                if os.path.exists(dst):
                    if not replace:
                        print(f"[SKIP] benchmarks/{bench}/ (already exists)")
                        continue
                    shutil.rmtree(dst)
                
                if not args.move:
                    shutil.copytree(src, dst)
                    print(f"[COPY] benchmarks/{bench}/")
                else:
                    shutil.move(src, dst)
                    print(f"[MOVE] benchmarks/{bench}/")
    
    print("=" * 50)
    print("Import complete!")


def run_list(args):
    """
    List available benchmarks and/or models.
    
    Default: list both benchmarks and models
    With --benchmark/-b: list only benchmarks
    With --model/-m: list only models
    """
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    list_both = args.type is None
    list_benchmarks = list_both or args.type == "benchmark"
    list_models = list_both or args.type == "model"
    
    if list_benchmarks:
        server_dir = os.path.join(current_dir, "method_server")
        if os.path.exists(server_dir):
            benchmarks = [d for d in os.listdir(server_dir) 
                         if os.path.isdir(os.path.join(server_dir, d))
                         and not d.startswith("__")
                         and not d.startswith(".")
                         and d != "eval"]
            if list_both:
                print("=" * 50)
                print("Available benchmarks:")
            else:
                print("Available benchmarks:")
            for b in sorted(benchmarks):
                card_path = os.path.join(server_dir, b, "dataset_card.json")
                if os.path.exists(card_path):
                    print(f"  ✓ {b}")
                else:
                    print(f"  - {b} (missing dataset_card.json)")
        else:
            print(f"Error: method_server directory not found at {server_dir}")
    
    if list_models:
        llm_dir = os.path.join(current_dir, "llm")
        if os.path.exists(llm_dir):
            try:
                import llm.config as llm_config
                registered_models = set(llm_config.MODEL_REGISTRY.keys())
                registered_names_normalized = {m.replace('-', '_'): m for m in registered_models}
            except:
                registered_models = set()
                registered_names_normalized = {}
            
            models = []
            for d in os.listdir(llm_dir):
                dir_path = os.path.join(llm_dir, d)
                if os.path.isdir(dir_path) and not d.startswith("__"):
                    card_path = os.path.join(dir_path, "model_card.json")
                    if os.path.exists(card_path):
                        original_name = registered_names_normalized.get(d, d)
                        models.append((d, original_name in registered_models))
            
            if list_both:
                print()
                print("=" * 50)
                print("Available models:")
            else:
                print("Available models:")
            for folder_name, is_registered in sorted(models):
                if is_registered:
                    print(f"  ✓ {folder_name}")
                else:
                    print(f"  ? {folder_name} (not registered in config.py)")
            
            model_folders = {d for d, _ in models}
            missing_folders = []
            for reg_name in registered_models:
                normalized = reg_name.replace('-', '_')
                if normalized not in model_folders:
                    missing_folders.append((reg_name, normalized))
            if missing_folders:
                print()
                print("Models registered in config.py but folder not found:")
                for reg_name, folder_name in sorted(missing_folders):
                    if not os.path.exists(os.path.join(llm_dir, folder_name)):
                        print(f"  ✗ {reg_name} (folder missing: {folder_name}/)")
        else:
            print(f"Error: llm directory not found at {llm_dir}")
    
    if list_both:
        print()
        print("=" * 50)
        print("Note: Use 'llmdep list --benchmark' or 'llmdep list --model' to filter")


if __name__ == "__main__":
    main()
