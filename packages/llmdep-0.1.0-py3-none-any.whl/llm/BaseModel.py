import os
import logging
import datetime

class BaseModel:
    def __init__(self, args):
        self.args = args
        self.worker_num = getattr(args, 'worker_nums', 1)
        self.model_name = getattr(args, 'modelname', None)
        ts = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
        name = self.model_name if self.model_name else 'model'
        self.run_tag = f"{ts}_{name}"
        self._set_logger()

    def _set_logger(self):
        self.generation_logging = logging.getLogger(f"generation_logging_{self.run_tag}")
        self.error_logging = logging.getLogger(f"error_logging_{self.run_tag}")
        project_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
        log_dir = os.path.join(project_path, 'log', self.run_tag)
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        generation_handler = logging.FileHandler(os.path.join(log_dir, 'generation.log'), mode='a', encoding='utf-8')
        error_handler = logging.FileHandler(os.path.join(log_dir, 'error.log'), mode='a', encoding='utf-8')
        formatter = logging.Formatter('\n%(asctime)s %(levelname)s\n%(message)s')
        generation_handler.setFormatter(formatter)
        error_handler.setFormatter(formatter)
        self.generation_logging.setLevel(logging.INFO)
        self.error_logging.setLevel(logging.INFO)
        self.generation_logging.addHandler(generation_handler)
        self.error_logging.addHandler(error_handler)

    def list_prompts_to_questions(self, prompts):
        return [[{"role": "user", "content": p}] for p in prompts]


