"""Setup Simian Examples."""

import os

from setuptools import setup


version = os.environ.get("CI_COMMIT_TAG", "3.dev1")

setup(
    version=version,
    install_requires=[
        f"simian-gui=={version}",
        "scipy",
    ],
    extras_require={"local": [f"simian-local=={version}"]},
)
