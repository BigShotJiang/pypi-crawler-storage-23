"""Simian Wrapped Ball Thrower app.

Built for simian.gui 3.1.0.
"""

import math

import numpy as np
import simian.examples.ballthrower as throw_gui
import simian.gui
from simian.examples.ballthrower import (
    COLLAPSE_PANEL,
    LABEL_LEFT,
    causeError,
    clearHistory,
    gui_event,
)
from simian.gui import component, utils

try:
    from monkeyproof.modelwrapper.mwapp.application import Application
except ImportError as exc:
    raise RuntimeError("Simian wrapper could not be found. Is it installed?") from exc


if __name__ == "__main__":
    # Run as a script
    from simian.entrypoint import assert_simian_gui_imports

    assert_simian_gui_imports()
    from simian.local import run

    run("simian.examples.wrapped_thrower", window_title="Wrapped Ball Thrower", debug=False)


def gui_init(meta_data) -> dict:
    """Initializes the form.

    Initialization of the form and the components therein.

    Returns:
        payload:    Form definition.
    """
    app = Application("examples.thrower.ballthrower_model.ThrowerModel")
    app.populate(
        userData={
            "Resources_XLS": {
                "SelectedBall": {"value": "None"},
                "SpeedHorizontal": {"value": 10 / math.sqrt(2)},
                "SpeedVertical": {"value": 10 / math.sqrt(2)},
            }
        }
    )
    utils.setCache(meta_data, "app", app)

    # Get the list of balls from the wrapped model.
    balls_list = app.model.dataStore.resources.getValue("DefinedBalls")

    # Create a form and add a label.
    form_obj = simian.gui.Form("form")

    # Create tabs in the form.
    tabs = component.Tabs(key="tabs", parent=form_obj)
    tab_inputs, tab_settings = tabs.setContent(labels=["Inputs", "Used settings"])

    # Create a Columns object and fill it with two empty columns.
    col = component.Columns(key="inputColumns", parent=tab_inputs)
    left_column, right_column = col.setContent(components=[], widths=[6, 6])

    # Add Throw speed and angle controls.
    created_components = throw_gui.add_throw_speed_controls(left_column)

    # Put a Ball selector component in the throw options panel
    ball_selector = component.Select("ballSelector", created_components["throwPanel"])
    ball_selector.label = "Selected Ball"
    ball_selector.tooltip = "Ball to throw."
    ball_selector.setRequired()
    ball_selector.labelPosition = "left-left"

    # Fill the Balls selector with the list of balls from the wrapped model.
    ball_selector.setValues(balls_list["Name"], balls_list.to_dict("records"))

    # Add the options panels and controls.
    left_dis_opts = {"disabled": True, **LABEL_LEFT}

    def ball_prop(name: str) -> dict:
        return {
            "calculateValue": f"""
            if (data.ballSelector) {{
                value=data.ballSelector['{name}']
            }} else {{
                value = 0
            }}""",
            **left_dis_opts,
        }

    ball_mass_opts = ball_prop("Weight [kg]")
    ball_radius_opts = ball_prop("Diameter [m]")
    ball_drag_opts = ball_prop("Drag Coefficient [-]")

    utils.addComponentsFromTable(
        parent=left_column,
        build_table=[
            # key               class       level   options             default label                               tooltip
            ["ballPanel",       "Panel",    1,      COLLAPSE_PANEL,     None,   "Ball settings",                    None],
            ["ballMass",        "Number",   2,      ball_mass_opts,     0,      "Mass [kg]:",                       "Mass of the ball."],
            ["ballRadius",      "Number",   2,      ball_radius_opts,   0,      "Radius [m]:",                      "Radius of the ball."],
            ["dragCoefficient", "Number",   2,      ball_drag_opts,     0,      "Drag coefficient [-]:",            "Drag coefficient of the ball."],
            ["constantsPanel",  "Panel",    1,      COLLAPSE_PANEL,     None,   "Constants",                        None],
            ["gravity",         "Number",   2,      left_dis_opts,      9.81,   "Gravity [m/s<sup>2</sup>]:",       "Gravitational accelleration acting on the ball."],
            ["airDensity",      "Number",   2,      left_dis_opts,      1.29,   "Air density [kg/m<sup>3</sup>]:",  "Density of the air through which the ball moves."]  # fmt: skip
        ],
    )

    # Show Scenario information.
    scenario_grid = component.HtmlTable(
        "scenario_info", left_column, column_names=["Scenario Name", "Wind speed"]
    )
    scenario_grid.setDefaultValue(
        [[i_scen.name, i_scen.getValue("Wind")[0][0]] for i_scen in app.model.dataStore.scenarios]
    )

    # Fill the right column.
    throw_gui.fill_right_column(right_column)

    # Fill the Settings tab.
    _fill_settings_tab(tab_settings)

    # Put the form in the outputs.
    payload = {
        "form": form_obj,
        "navbar": {
            "title": "Wrapped Ball Thrower",
            "subtitle": "<small>Simian demo</small>",
        },
        "showChanged": True,  # Flag changes to the settings in the UI.
    }

    return payload


def throwing(meta_data: dict, payload: dict) -> dict:
    """Simulate throwing a ball.

    Get the settings from the payload.
    """
    throw_speed, _ = utils.getSubmissionData(payload, key="throwSpeed")
    throw_angle, _ = utils.getSubmissionData(payload, key="throwAngle")
    selected_ball, _ = utils.getSubmissionData(payload, key="ballSelector")

    # Convert the speed and angle to the speed components.
    ver_speed = throw_speed * math.sin(throw_angle / 180 * math.pi)
    hor_speed = throw_speed * math.cos(throw_angle / 180 * math.pi)

    app, _ = utils.getCache(meta_data, "app")

    resources = app.model.dataStore.resources
    resources.setValue("SelectedBall", selected_ball["Name"], overload=True)
    resources.setValue("SpeedHorizontal", hor_speed, overload=True)
    resources.setValue("SpeedVertical", ver_speed, overload=True)
    app.model.run()

    trajectories = app.model.dataStore.custom["trajectories"]

    # Create a Plotly object from the information in the payload.
    plot_obj, _ = utils.getSubmissionData(payload, key="plot")

    # Plot the new newly calculated x and y values, append the legend and put the plotly
    # object in the submission data.
    nr = int(len(plot_obj.figure.data) / 4 + 1)

    for i_scen, i_res in trajectories.items():
        plot_obj.figure.add_scatter(
            x=i_res["x"], y=i_res["y"], name=f"Attempt {nr} - {i_scen}", mode="lines"
        )
    utils.setSubmissionData(payload, key="plot", data=plot_obj)

    # Get the maximum thrown distances.
    distances = [d[-1] for d in app.model.dataStore.results.getValue("Distance")[1:]]

    # Update the table with the settings used for the throws.
    new_row = [
        nr,
        nr,
        round(hor_speed, 3),
        round(ver_speed, 3),
        selected_ball["Weight [kg]"],
        selected_ball["Diameter [m]"] / 2,
        selected_ball["Drag Coefficient [-]"],
        round(min(distances), 3),
        round(max(distances), 3),
        round(np.mean(distances), 3),
        round(max(distances) - min(distances), 3),
    ]

    if nr == 1:
        # First throw. Only put the new row in the table.
        new_table_values = [new_row]
    else:
        # Extra row. Append the row to the DataFrame from the submission data.
        new_table_values, _ = utils.getSubmissionData(payload, key="summary")
        new_table_values.append(dict(zip(new_table_values[0].keys(), new_row)))

    utils.setSubmissionData(payload, key="summary", data=new_table_values)

    return payload


def _fill_settings_tab(tab_settings):
    """Fill Settings tab."""
    # Create a table to store the throw settings in.
    table_out = component.DataTables(key="summary", parent=tab_settings)
    table_out.setColumns(
        *[
            list(x)
            for x in zip(
                ["Id", "id"],
                ["Attempt", "attempt"],
                ["Horizontal speed", "hor_speed"],
                ["Vertical speed", "ver_speed"],
                ["Ball mass", "ball_mass"],
                ["Radius", "radius"],
                ["Drag Coeff.", "drag"],
                ["Min. distance", "min_dist"],
                ["Max. distance", "max_dist"],
                ["Mean distance", "mean_dist"],
                ["Spread distance", "spread_dist"],
            )
        ],
        visible=[False] + [True] * 10,
    )
    table_out.label = "Used settings per throw"
    table_out.setFeatures(searching=False, ordering=False, paging=False)
