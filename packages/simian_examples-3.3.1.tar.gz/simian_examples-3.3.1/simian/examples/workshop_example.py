"""Workshop Example application.

Built for simian.gui 3.0.0.
"""

import logging
import numbers

import plotly.express
from pandas import DataFrame as pandas_DataFrame
from simian.gui import Form, component, utils

# Import the GAP Minder data from the Plotly Express module.
# The resulting GAP_DATA is a pandas.DataFrame. The columns that will be used are:
# "year" and "continents"
GAP_DATA = plotly.express.data.gapminder()
GAP_DATA.insert(0, "id", GAP_DATA.index)  # 'id' is needed in DataTables, so we are adding it here.


if __name__ == "__main__":
    # Run as a script
    from simian.local import run

    run(
        "simian.examples.workshop_example",
        window_title="Workshop application",
        debug=True,
        show_refresh=True,
    )


def gui_init(_meta_data: dict) -> dict:
    """Initializes the form.

    Initialization of the form and the components therein.

    Returns:
        payload:    Form definition.
    """
    # Setup component initializers and create the Form from the definition in the .json file.
    Form.componentInitializer(
        gapTable=init_gap_table,
        selectContinents=make_trigger_happy,
        selectYears=make_trigger_happy,
    )
    form = Form(from_file=__file__)

    # Put the form in the outputs.
    payload = {
        "form": form,
        "navbar": {
            "title": "Workshop Application",
            "subtitle": "<small>Simian Demo</small>",
        },
        "showChanged": True,  # Flag changes to the settings in the UI.
    }

    return payload


def init_gap_table(gap_table: component.DataTables):
    """Initializer function for the gapTable."""
    table_column_names = list(GAP_DATA.columns)

    gap_table.setColumns(
        titles=[i_name.capitalize() for i_name in table_column_names],
        keys=table_column_names,
        className=["noneditable"] * len(table_column_names),
        visible=[False] + [True] * (len(table_column_names) - 1),
    )


def make_trigger_happy(comp):
    """Initializer to make input components triggerHappy."""
    comp.properties["triggerHappy"] = "FilterChange"


def gui_event(meta_data: dict, payload: dict) -> dict:
    """Event handling of the application.

    Args:
        meta_data:      Form meta data.
        payload:        Current status of the Form's contents.

    Returns:
        payload:        Updated Form contents.
    """
    # Register the events with their functions.
    Form.eventHandler(
        LoadData=load_data,
        RunScenarios=update_scenarios,
        FilterChange=filter_changed,
    )
    try:
        caller = utils.getEventFunction(meta_data, payload)
        payload = caller(meta_data, payload)

    except ImportError as exc:
        # No method with matching name found in the current namespace. May be used to have
        # custom event routing. Here we only log the occurrence.
        logging.exception(exc)

    # Lower the "Form has changes" flag.
    payload["pristine"] = True

    return payload


def filter_changed(meta_data: dict, payload: dict) -> dict:
    """Continent or Year selection change callback."""
    # Continent or year selection changed. Update the table and plot.
    update_table_and_plot(payload)

    # Trigger a recalculate of the scenarios.
    update_scenarios(meta_data, payload)

    return payload


def filter_data(selected_continents: list, selected_years: list) -> pandas_DataFrame:
    """Filter GAP data based on selected continents and years."""
    if isinstance(selected_continents, str):
        # Selected continent is a string. Put in a list for use in the filtering.
        selected_continents = [selected_continents]

    if isinstance(selected_years, numbers.Number):
        # Selected year is a number. Put in a list for use in the filtering.
        selected_years = [selected_years]

    # Filter the GAP data.
    new_gap = GAP_DATA[
        GAP_DATA["continent"].isin(selected_continents) & GAP_DATA["year"].isin(selected_years)
    ]

    return new_gap


def load_data(_meta_data: dict, payload: dict) -> dict:
    """Put the Gap Minder data in the table."""
    utils.setSubmissionData(payload, "gapTable", GAP_DATA)

    # Put the available continents in the Select component.
    gap_continents = sorted(set(GAP_DATA["continent"]))
    utils.setSubmissionData(payload, "selectContinents", gap_continents)
    utils.setSubmissionData(payload, "availableContinents", gap_continents)

    # Put the available years in the Select component and select the last year.
    gap_years = sorted(set(GAP_DATA["year"]))
    utils.setSubmissionData(payload, "selectYears", [gap_years[-1]])
    utils.setSubmissionData(payload, "availableYears", gap_years)

    # Plot the loaded data.
    update_table_and_plot(payload)

    return payload


def update_scenarios(_meta_data: dict, payload: dict) -> dict:
    """Update the scenario results in the scenario list."""
    scenario_list, _ = utils.getSubmissionData(payload, key="scenarios")

    for scenario_row in scenario_list:
        # Loop over the scenario rows.
        selected_year = scenario_row["inputYear"]

        # Get the selected continents and filter the GAP data for the scenario year.
        selected_continents, _ = utils.getSubmissionData(payload, "selectContinents")
        filtered_gap_data = filter_data(selected_continents, selected_year)

        # Calculate the Total population of all nations in the selection.
        scenario_row["totalPop"] = float(filtered_gap_data["pop"].sum())

    utils.setSubmissionData(payload, "scenarios", scenario_list)

    return payload


def update_table_and_plot(payload: dict) -> None:
    """Put the GAP data in the table and plot."""
    selected_year, _ = utils.getSubmissionData(payload, "selectYears")

    # Get the selected continents and filter the GAP data for the selected years.
    selected_continents, _ = utils.getSubmissionData(payload, "selectContinents")
    filtered_gap_data = filter_data(selected_continents, selected_year)

    # Fill table with GAP data.
    utils.setSubmissionData(payload, "gapTable", filtered_gap_data)

    update_plot(payload, filtered_gap_data=filtered_gap_data)


def update_plot(payload: dict, filtered_gap_data: pandas_DataFrame = GAP_DATA) -> None:
    """Update the plot with a 'filtered' set of data."""
    # Recreate the Plotly object.
    plot_obj = utils.getSubmissionData(payload, key="plot")[0]

    # Plot the new newly calculated x and y values, append the legend and put the plotly
    # object in the submission data.
    if len(filtered_gap_data) == 0:
        # No data. Empty the plot.
        plot_obj.figure = None

    else:
        # Fill the plot with data.
        # https://plotly.com/python/line-and-scatter/
        plot_obj.figure = plotly.express.scatter(
            filtered_gap_data,
            x="gdpPercap",
            log_x=True,
            y="lifeExp",
            symbol="year",
            size="pop",
            size_max=60,
            color="continent",
            hover_name="country",
        )

    # Put the new plot contents in the payload.
    utils.setSubmissionData(payload, "plot", plot_obj)
