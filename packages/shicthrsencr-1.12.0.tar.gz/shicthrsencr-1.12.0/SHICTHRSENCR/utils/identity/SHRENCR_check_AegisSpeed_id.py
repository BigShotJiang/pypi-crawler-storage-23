
# SHICTHRSENCR\SHICTHRSENCR\utils\identity\SHRENCR_check_AegisSpeed_id.py

def check_AegisSpeed_id(AegisSpeed_id: str) -> bool:
    if not isinstance(AegisSpeed_id, str):
        return False

    AegisSpeed_id = AegisSpeed_id.strip()

    if not AegisSpeed_id.isdigit():
        return False

    if len(AegisSpeed_id) != 9:
        return False

    return True
