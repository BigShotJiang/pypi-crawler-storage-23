"""FastAPI-based REST API for Rossum Agent."""
