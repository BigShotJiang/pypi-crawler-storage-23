# IV Thrombolysis for Acute Ischemic Stroke — AHA/ASA 2019

## IV Alteplase — Standard of Care

### Dosing Protocol (Class I)
- **Dose:** 0.9 mg/kg (maximum total dose: 90 mg).
- **Administration:** 10% of the total dose as an IV bolus over 1 minute, followed by the remaining 90% infused IV over 60 minutes.
- **Example:** 80 kg patient → Total dose = 72 mg → Bolus = 7.2 mg IV push, then 64.8 mg IV over 60 min.

### Time Windows
- **Standard window (Class I):** Onset-to-needle ≤ **3 hours**. Strongest evidence of benefit.
- **Extended window (Class I):** Onset-to-needle ≤ **4.5 hours**. Benefit confirmed but effect size slightly smaller.
- **Wake-up stroke / Unknown onset:** IV alteplase CAN be administered if MRI shows DWI-FLAIR mismatch (DWI lesion present, no corresponding FLAIR signal change), indicating the event is likely within 4.5 hours (Class IIa).

### Absolute Contraindications
The following are absolute contraindications to IV alteplase per AHA/ASA 2019:

- Active internal bleeding (excluding menses)
- Current intracranial hemorrhage on CT
- Subarachnoid hemorrhage (suspected or confirmed)
- Recent (within 3 months) intracranial or intraspinal surgery, or serious head trauma
- Intracranial neoplasm, AVM, or aneurysm
- BP persistently > 185/110 mmHg despite treatment
- Platelet count < 100,000/mm³
- INR > 1.7 or PT > 15 seconds
- aPTT > 40 seconds (if on heparin)
- Use of direct thrombin inhibitors or direct factor Xa inhibitors within 48 hours (unless normal lab values)
- Treatment dose of LMWH within previous 24 hours
- Blood glucose < 50 mg/dL

### Relative Contraindications (Weigh Risk/Benefit)
- Minor or rapidly improving stroke symptoms (NIHSS ≤ 4 with non-disabling deficit)
- Major surgery within 14 days
- GI or urinary tract hemorrhage within 21 days
- Arterial puncture at non-compressible site within 7 days
- Seizure at stroke onset (if residual deficits are attributable to stroke, not post-ictal)
- Pregnancy

### Post-Alteplase Monitoring
- **Neurological checks (NIHSS):** Every 15 minutes during infusion, every 30 minutes for 6 hours, then hourly for 24 hours.
- **No antithrombotics (antiplatelet or anticoagulant) for 24 hours** post-alteplase. Obtain follow-up CT at 24 hours before starting antiplatelet therapy.
- **Suspected hemorrhagic conversion:** Stop infusion immediately. Obtain STAT CT head. Administer cryoprecipitate (10 units) if fibrinogen < 200. Consult neurosurgery.

## IV Tenecteplase (Emerging Alternative)
- Tenecteplase 0.25 mg/kg (max 25 mg) as a single IV bolus is an alternative to alteplase, particularly before thrombectomy (Class IIb in AHA/ASA 2019, with stronger endorsement in subsequent updates). Advantages: simpler single-bolus administration.
