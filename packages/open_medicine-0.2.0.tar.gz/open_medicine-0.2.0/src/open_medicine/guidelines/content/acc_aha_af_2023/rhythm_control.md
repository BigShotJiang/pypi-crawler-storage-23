# Rhythm Control in Atrial Fibrillation — ACC/AHA 2023

## General Principles

Rhythm control (restoration and maintenance of sinus rhythm) is indicated for symptomatic patients or when rate control fails to improve quality of life. Early rhythm control (within 1 year of AF diagnosis) is associated with improved cardiovascular outcomes.

## Cardioversion

- **Pharmacological cardioversion:** 
  - **Normal LV function:** Intravenous Amiodarone, Ibutilide, or Flecainide.
  - **HFrEF:** Amiodarone IV is the preferred agent.
- **Electrical cardioversion (DCCV):** Preferred for hemodynamically unstable AF, when patient desires immediate rhythm conversion, or when pharmacological cardioversion fails.
- **Anticoagulation before cardioversion:** 
  - If AF duration > 48 hours or unknown: Anticoagulate for ≥ 3 weeks before cardioversion OR perform transesophageal echocardiography (TEE) to rule out left atrial appendage thrombus. 
  - **Post-cardioversion:** Continue OAC for ≥ 4 weeks regardless of CHA2DS2-VASc score.

## Long-Term Rhythm Control

### Catheter Ablation (First-Line in Many Cases)
- **First-line therapy:** Recommended for selected patients with symptomatic paroxysmal AF, particularly younger patients with few comorbidities (Class I).
- **HFrEF:** Recommended for patients with HFrEF to improve survival and reduce heart failure hospitalizations (Class I).
- **Refractory AF:** Recommended for symptomatic AF when Antiarrhythmic Drugs (AADs) have been ineffective, contraindicated, not tolerated, or not preferred (Class I).
- **Anticoagulation:** Ablation is superior to AADs for maintaining sinus rhythm but **does not eliminate the need for long-term anticoagulation**. OAC continuation must be based on the CHA2DS2-VASc score, not the success of the ablation.

### Antiarrhythmic Drugs (AADs) & Clinical Caveats

> **Important:** No antiarrhythmic drug received a Class I recommendation for long-term maintenance of sinus rhythm in the 2023 guideline. Selection is based primarily on *safety* (avoiding proarrhythmia and organ toxicity) rather than efficacy.

- **Flecainide, Propafenone:** 
  - **Indication:** Only in patients WITHOUT structural heart disease (no CAD, no LVH, no HFrEF). 
  - **Caveat:** Must be combined with an AV nodal blocking agent (beta-blocker or non-DHP CCB) to prevent 1:1 conduction of atrial flutter.
- **Dofetilide:** 
  - **Indication:** Can be used in HFrEF and CAD. 
  - **Caveat:** Requires strictly monitored 3-day inpatient initiation with continuous ECG monitoring due to high risk of QT prolongation and Torsades de Pointes. Highly dependent on renal function.
- **Dronedarone:** 
  - **Indication:** Reduces AF hospitalization in patients with paroxysmal/persistent AF in sinus rhythm. 
  - **Contraindication:** Strictly contraindicated in NYHA Class III-IV strict or any recent decompensation, and in permanent AF.
- **Sotalol:** 
  - **Indication:** Eased to Class IIb due to association with increased mortality risk. 
  - **Caveat:** Requires inpatient initiation and strict QT monitoring (similar to Dofetilide). Dependent on renal clearance.
- **Amiodarone:** 
  - **Indication:** Most effective AAD for maintaining sinus rhythm. Safe in HFrEF.
  - **Caveat:** Reserved as a last resort due to significant long-term cumulative toxicity (thyroid, pulmonary, hepatic, ocular, dermatologic). Requires baseline and ongoing multi-organ surveillance testing.
