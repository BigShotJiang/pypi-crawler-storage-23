# Quick SOFA (qSOFA) Screening — SCCM/ESICM 2016

## Clinical Use of qSOFA

The Quick Sequential Organ Failure Assessment (qSOFA) score is a bedside prompt designed to identify adult patients with suspected infection who are more likely to have poor outcomes typical of sepsis. 

It is particularly useful in out-of-hospital, emergency department, or general hospital ward settings because it relies solely on clinical examination findings without requiring laboratory tests.

### qSOFA Criteria

A patient meets the qSOFA criteria if they exhibit at least **two** of the following three clinical parameters:
1. **Respiratory Rate:** ≥ 22 breaths per minute
2. **Altered Mentation:** Glasgow Coma Scale (GCS) < 15
3. **Systolic Blood Pressure:** ≤ 100 mmHg

### Interpretation and Thresholds

- **Score < 2:** Low risk. Not suggestive of a high risk for in-hospital mortality from sepsis. Continued clinical monitoring is appropriate.
- **Score ≥ 2:** High risk. A score of 2 or more points near the onset of infection is associated with an increased risk of poor outcome (in-hospital mortality or ICU stay ≥ 3 days). 

**Clinical Action for Score ≥ 2:**
Patients exhibiting a qSOFA score of ≥ 2 should prompt clinicians to:
- Further investigate for the presence of organ dysfunction.
- Consider stepping up therapy or monitoring (e.g., escalating care to ICU if appropriate).
- Consider the possibility of unacknowledged infection in a patient not previously known to be infected.

> **OpenMedicine Calculator:** `calculate_qsofa` — available via MCP for rapid, automated bedside scoring.
