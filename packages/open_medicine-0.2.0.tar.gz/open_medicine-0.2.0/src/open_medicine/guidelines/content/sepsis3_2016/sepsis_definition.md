# Sepsis Definition — SCCM/ESICM 2016

## The Sepsis-3 Consensus Definition

The Third International Consensus Definitions for Sepsis and Septic Shock (Sepsis-3) redefined sepsis to emphasize the dysregulated host response and the presence of organ dysfunction.

- **Sepsis** is defined as life-threatening organ dysfunction caused by a dysregulated host response to infection.

### Clinical Criteria for Organ Dysfunction (SOFA)

Organ dysfunction can be identified as an acute change in total SOFA (Sequential Organ Failure Assessment) score.

- A baseline SOFA score can be assumed to be zero in patients not known to have preexisting organ dysfunction.
- **Threshold for Sepsis:** An acute increase in the SOFA score of **≥ 2 points** consequent to the infection.
- This threshold of a SOFA score ≥ 2 is associated with an overall mortality risk of approximately 10% in a general hospital population with suspected infection.

Even patients presenting with modest dysfunction can deteriorate rapidly, emphasizing the seriousness of this condition.

> **OpenMedicine Calculator:** `calculate_sofa` — available via MCP for scoring organ failure across 6 systems (respiration, coagulation, liver, cardiovascular, CNS, renal).

## Septic Shock

Septic shock is a subset of sepsis in which underlying circulatory and cellular/metabolic abnormalities are profound enough to substantially increase mortality (expected mortality > 40%).

**Clinical Criteria for Septic Shock:**
Patients with sepsis who, despite adequate fluid resuscitation (e.g., 30 mL/kg of IV crystalloid), require:
- Vasopressors to maintain a mean arterial pressure (MAP) ≥ 65 mmHg (Norepinephrine is first-line)
- AND have a serum lactate level > 2 mmol/L (> 18 mg/dL)

## Actionable Management: The 1-Hour Bundle
Upon recognition of Sepsis or Septic Shock, begin the following resuscitation bundle immediately (within 1 hour):
1. **Measure lactate level.** Remeasure if initial lactate is elevated (> 2 mmol/L).
2. **Obtain blood cultures** before administering antibiotics.
3. **Administer broad-spectrum antibiotics** (e.g., Piperacillin-Tazobactam + Vancomycin).
4. **Begin rapid administration of 30 mL/kg crystalloid** for hypotension or lactate ≥ 4 mmol/L.
5. **Apply vasopressors** if hypotensive during or after fluid resuscitation to maintain MAP ≥ 65 mmHg (Norepinephrine preferred).
