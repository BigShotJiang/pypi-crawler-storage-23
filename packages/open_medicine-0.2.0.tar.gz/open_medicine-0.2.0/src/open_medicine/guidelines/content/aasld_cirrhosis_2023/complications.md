# Cirrhosis Complications Management — AASLD 2023

## 1. Ascites Management

### First-Line Therapy
- **Sodium restriction:** < 2 g/day (88 mmol/day).
- **Diuretics:**
  - **Spironolactone:** Start 100 mg daily, titrate up to 400 mg daily.
  - **Furosemide:** Start 40 mg daily, titrate up to 160 mg daily.
  - **Ratio:** Maintain 100:40 (spironolactone:furosemide) to preserve potassium balance.
- **Monitoring:** Check renal function and electrolytes within 1 week of initiation or dose change. Target weight loss: 0.5 kg/day (without edema) or 1 kg/day (with edema).

### Refractory Ascites
- **Definition:** Ascites unresponsive to maximum-dose diuretics or recurrent within 4 weeks of adequate therapy.
- **Action:**
  - **Serial large-volume paracentesis (LVP):** Remove > 5 L with albumin replacement (6–8 g albumin per liter removed).
  - **Consider TIPS (Transjugular Intrahepatic Portosystemic Shunt):** In selected patients (Child-Pugh ≤ 12, no severe encephalopathy, no cardiac/pulmonary disease). TIPS reduces portal pressure and ascites recurrence.
  - **Refer for transplant evaluation** if not already being followed.

### Spontaneous Bacterial Peritonitis (SBP) Prophylaxis
- **Primary prophylaxis (in high-risk patients):** Norfloxacin 400 mg daily OR Trimethoprim-Sulfamethoxazole DS daily if ascitic fluid protein < 1.5 g/dL WITH liver failure (Child-Pugh ≥ 9 and bilirubin ≥ 3) OR renal impairment (Cr ≥ 1.2, BUN ≥ 25, or Na ≤ 130).
- **Secondary prophylaxis (after first episode of SBP):** Norfloxacin 400 mg daily indefinitely.
- **SBP Diagnosis:** Ascitic fluid PMN count ≥ 250 cells/mm³.
- **SBP Treatment:** Ceftriaxone 2 g IV daily (or Cefotaxime 2 g IV q8h) for 5 days. Add IV albumin (1.5 g/kg on day 1, 1 g/kg on day 3) if creatinine > 1 mg/dL, BUN > 30, or bilirubin > 4.

---

## 2. Variceal Bleeding

### Primary Prophylaxis (Prevention of First Bleed)
- **Carvedilol** is the preferred NSBB for portal hypertension (AASLD 2023).
  - **Dose:** Start 6.25 mg daily (3.125 mg BID). Target maintenance: 6.25–12.5 mg/day.
  - **Lower starting dose** in Child-Pugh B/C. Hold if SBP < 90, HR < 55, or AKI develops.
- **Contraindication to NSBB:** Perform endoscopic variceal ligation (EVL) for medium-large varices.

### Acute Variceal Hemorrhage (AVH)
Actionable steps upon presentation:
1. **Resuscitation:** Restrictive transfusion strategy (target Hb 7–8 g/dL). Avoid over-resuscitation.
2. **Vasoactive agent:** Start **Octreotide** 50 mcg IV bolus, then 50 mcg/hr infusion (continue for 2–5 days). OR **Terlipressin** if available.
3. **Antibiotic prophylaxis:** Ceftriaxone 1 g IV daily for 7 days (reduces mortality and rebleeding).
4. **Endoscopy:** Perform within **12 hours** of presentation. EVL (band ligation) is the preferred endoscopic therapy for esophageal varices.
5. **Early TIPS (within 72 hours):** Consider in high-risk patients (Child-Pugh B with active bleeding at endoscopy, or Child-Pugh C ≤ 13).

### Secondary Prophylaxis (After First Bleed)
- Combination of NSBB (carvedilol or propranolol) **plus** EVL until variceal obliteration.

---

## 3. Hepatic Encephalopathy (HE)

### Classification
| Grade | West Haven Criteria | Clinical Features |
|---|---|---|
| Minimal/Covert | 0–I | No overt signs; detected by psychometric testing only |
| Grade II | Overt | Lethargy, disorientation, asterixis |
| Grade III | Overt, severe | Somnolence, marked confusion, but arousable |
| Grade IV | Coma | Unresponsive |

### Pharmacotherapy

- **First-line:** Lactulose 15–30 mL PO every 1–2 hours until ≥ 2 bowel movements, then titrate to **2–3 bowel movements per day**.
  - For acute severe HE (Grade III-IV): Lactulose can be given as a **rectal enema** (300 mL in 700 mL water, retained for 30–60 min) if patient cannot take orally.
- **Add-on (for recurrent HE despite lactulose):** Rifaximin 550 mg PO BID.
- **Identify and treat precipitants:** Infection (especially SBP), GI bleeding, electrolyte abnormalities (hypokalemia, hyponatremia), constipation, excessive protein intake, sedative medications, dehydration/renal failure.
- **Avoid benzodiazepines and opioids** — these worsen HE.
- **Nutrition:** Do NOT restrict protein (this worsens HE by promoting catabolism). Maintain 1.2–1.5 g/kg/day protein intake.
