---
name: Feature Request — New Calculator
about: Propose a new clinical calculator or score
title: "[CALCULATOR] "
labels: enhancement, good first issue
assignees: ''
---

## Calculator Name

(e.g., Wells Score for Pulmonary Embolism)

## Clinical Use

What clinical decision does this calculator support?

## Primary Reference

- **DOI:** `10.xxxx/...`
- **Study/Guideline:** (Name, year, journal)

## Scoring Criteria

List the criteria and their point values:

| Criterion | Points |
|-----------|--------|
| ... | ... |

## Interpretation

| Score Range | Interpretation |
|-------------|---------------|
| ... | ... |

## LOINC Code (if known)

(e.g., `LP419518-4`)

## Implementation Notes

Any relevant notes about edge cases, variants, or special considerations.
