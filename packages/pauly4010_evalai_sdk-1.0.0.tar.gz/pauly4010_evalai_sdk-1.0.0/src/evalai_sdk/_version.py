__version__ = "1.0.0"
SDK_VERSION = __version__
SPEC_VERSION = "1.0"
