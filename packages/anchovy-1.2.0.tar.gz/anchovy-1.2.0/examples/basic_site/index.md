---
template: base.jinja.html
footnote: Generated with Anchovy!
---

# Welcome to Example Site 1!

![Anchovy](static/images/anchovy-nypl.jpg)

This is just a demo of Anchovy, so we could talk about Anchovy here; but you
should really just go read the README instead.
