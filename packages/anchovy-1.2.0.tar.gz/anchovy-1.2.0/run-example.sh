anchovy examples/$1.py -i examples/$1 -o output/$1 -w working/$1 --custody-cache output/$1.json --purge -s
