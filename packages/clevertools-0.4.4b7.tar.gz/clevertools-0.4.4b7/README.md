# clevertools

`clevertools` is a Python utility library for everyday filesystem and runtime tasks.

It provides:
- file and directory creation
- IO helpers for JSON, TOML, YAML, TXT, BSON, Dockerfile, and PDF
- cleanup helpers (`clean_file`, `clean_folder`, `clean_pycaches`)
- structured logging with console and file handlers
- runtime helpers for `.env`, `sys.path`, and file bootstrapping
- a typed exception/validation model

## Installation

```bash
python -m pip install -r requirements.txt
```

Project metadata is defined in `pyproject.toml`.

## Python version

- Required: `>=3.10`

## Quick start

```python
from pathlib import Path
from clevertools.file_handling import create_folder, create_file, write_json, read_json
from clevertools.logger import configure_default_logging, add_file_handler, log

base = Path("tmp_demo")
create_folder(base)
create_file(base / "config.json")
write_json(base / "config.json", {"mode": "dev", "enabled": True})

data = read_json(base / "config.json")
print(data["mode"])

configure_default_logging(include_date=True, include_time=True)
add_file_handler(base / "run.log")
log("bootstrap", "INFO", "Startup complete")
```

## Documentation

Start at `docs/README.md`.

Main areas:
- chapters: `docs/chapters/*.md`
- module guides: `docs/modules/*.md`
- file-level API docs: `docs/api/**/*.md`
- reference: `docs/reference/*.md`
- local test program: `docs/testing/local_test_program.md`

## Repository structure

- `src/clevertools`: library source code
- `tests`: local integration-style test sub-program
- `docs`: project documentation

## Legal

See:
- `LICENSE`
- `NOTICE`
- `CONTRIBUTORS`
