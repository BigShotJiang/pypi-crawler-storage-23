from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import os

try:
    from dotenv import load_dotenv as _load_dotenv
except ModuleNotFoundError:
    _load_dotenv = None

from ..error_handling.exceptions import (
    OperationError,
    ParseError,
    TypeValidationError,
    ValueValidationError,
)
from ..error_handling.validation import ValidateFile


@dataclass(frozen=True)
class EnvAccessor:
    def get(self, key: str, default: Optional[str] = None) -> Optional[str]:
        if not isinstance(key, str):
            raise TypeValidationError(
                f"`key` must be of type `str`, got {type(key).__name__}."
            )

        normalized_key = key.strip()
        if not normalized_key:
            raise ValueValidationError("`key` must not be empty.")

        return os.getenv(normalized_key, default)


env = EnvAccessor()


def _parse_env_line(line: str, line_number: int) -> tuple[str, str] | None:
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return None

    if stripped.startswith("export "):
        stripped = stripped[len("export ") :].strip()

    if "=" not in stripped:
        raise ParseError(f"Invalid .env syntax at line {line_number}: missing '='.")

    key, value = stripped.split("=", 1)
    key = key.strip()
    value = value.strip()

    if not key:
        raise ParseError(f"Invalid .env syntax at line {line_number}: empty key.")

    if (
        len(value) >= 2
        and ((value[0] == "'" and value[-1] == "'") or (value[0] == '"' and value[-1] == '"'))
    ):
        value = value[1:-1]

    return key, value


def load_env(path: Path | str = ".env", override: bool = False) -> None:
    if not isinstance(path, (Path, str)):
        raise TypeValidationError(f"`path` must be of type `Path` or `str`, got {type(path).__name__}.")

    normalized_path = str(path).strip()
    if not normalized_path:
        raise ValueValidationError("`path` must not be empty.")

    env_file = Path(normalized_path)
    ValidateFile(env_file)

    try:
        if _load_dotenv is not None:
            _load_dotenv(dotenv_path=env_file, override=override)
            return

        with env_file.open("r", encoding="utf-8") as file:
            for line_number, line in enumerate(file, start=1):
                parsed = _parse_env_line(line, line_number)
                if parsed is None:
                    continue
                key, value = parsed
                if override or key not in os.environ:
                    os.environ[key] = value
    except ParseError:
        raise
    except Exception as exc:
        raise OperationError(f"Failed to load .env file '{env_file}': {exc}") from exc