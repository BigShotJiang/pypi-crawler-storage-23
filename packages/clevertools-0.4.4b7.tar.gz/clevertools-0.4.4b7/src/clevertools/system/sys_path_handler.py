from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional
from pathlib import Path
import sys

from ..error_handling.exceptions import (
    OperationError,
    TypeValidationError,
    ValueValidationError,
)

from ..error_handling.validation import ValidateFolder

@dataclass
class PathsDto:
    paths: Optional[List[Path | str]] = None
    path: Optional[Path | str] = None


def _normalize_path(value: Path | str, source: str) -> str:
    if not isinstance(value, (Path, str)):
        raise TypeValidationError(f"`{source}` must contain only `str` or `Path`, got {type(value).__name__}.")

    normalized = str(value).strip()
    if not normalized:
        raise ValueValidationError(f"`{source}` must not be empty.")

    return normalized

def runtime_paths(paths: PathsDto) -> None:
    if not isinstance(paths, PathsDto):
        raise TypeValidationError(f"`paths` must be an instance of PathsDto, got {type(paths).__name__}.")

    entries: List[Path | str] = []

    if paths.paths is not None:
        if not isinstance(paths.paths, list):
            raise TypeValidationError(f"`paths.paths` must be a list, got {type(paths.paths).__name__}.")
        entries.extend(paths.paths)

    if paths.path is not None:
        entries.append(paths.path)

    if not entries:
        raise ValueValidationError("No path entries provided in `path` or `paths`.")

    try:
        for entry in entries:
            normalized_path = _normalize_path(entry, "paths.paths/path")
            validator = ValidateFolder(normalized_path, raise_on_error=False)
            if not validator.is_ok:
                if validator.error is not None:
                    raise validator.error
                raise ValueValidationError(f"Path validation failed: {normalized_path}")
            sys.path.append(normalized_path)
    except (TypeValidationError, ValueValidationError):
        raise
    except Exception as exc:
        raise OperationError(f"Failed to append runtime paths to sys.path: {exc}") from exc