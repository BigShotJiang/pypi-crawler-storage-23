from __future__ import annotations

from pathlib import Path

from ..error_handling.exceptions import (
    FileReadError,
    FileSystemError,
    FileWriteError,
    MissingResourceError,
    PermissionDeniedError,
    TypeValidationError,
    ValueValidationError,
)
from ..error_handling.validation import ValidateFile


def _normalize_path(path: Path | str, source: str) -> Path:
    if not isinstance(path, (Path, str)):
        raise TypeValidationError(f"`{source}` must be of type `Path` or `str`, got {type(path).__name__}.")

    normalized = str(path).strip()
    if not normalized:
        raise ValueValidationError(f"`{source}` must not be empty.")

    return Path(normalized)


def ensure_existent(path: Path | str, ensure_parents: bool = False, is_directory: bool = False) -> Path:
    target = _normalize_path(path, "path")

    if target.exists():
        return target

    try:
        if is_directory:
            target.mkdir(parents=ensure_parents, exist_ok=True)
        else:
            if not target.parent.exists():
                if ensure_parents:
                    target.parent.mkdir(parents=True, exist_ok=True)
                else:
                    raise MissingResourceError(
                        f"Parent directory does not exist: '{target.parent}'."
                    )
            target.touch(exist_ok=True)
    except PermissionError as exc:
        raise PermissionDeniedError(
            f"Permission denied while ensuring path '{target}': {exc}"
        ) from exc
    except MissingResourceError:
        raise
    except OSError as exc:
        raise FileSystemError(f"Failed to ensure path '{target}': {exc}") from exc

    return target


def ensure_content(file_path: Path | str, template_path: Path | str, overwrite: bool = False, ensure_parents: bool = False) -> Path:
    template_file = _normalize_path(template_path, "template_path")
    ValidateFile(template_file)

    target_file = ensure_existent(
        file_path, ensure_parents=ensure_parents, is_directory=False
    )
    ValidateFile(target_file)

    try:
        template_content = template_file.read_text(encoding="utf-8")
    except OSError as exc:
        raise FileReadError(f"Failed to read template file '{template_file}': {exc}") from exc

    try:
        current_content = target_file.read_text(encoding="utf-8")
    except OSError as exc:
        raise FileReadError(f"Failed to read target file '{target_file}': {exc}") from exc

    if overwrite or not current_content.strip():
        try:
            target_file.write_text(template_content, encoding="utf-8")
        except OSError as exc:
            raise FileWriteError(f"Failed to write content to '{target_file}': {exc}") from exc

    return target_file