from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from .exceptions import DependencyError, ValidationError
from ..messages import MESSAGES


@dataclass
class ValidateFile:
    file_path: Path | str
    raise_on_error: bool = True
    is_ok: bool = field(init=False, default=False)
    error: Exception | None = field(init=False, default=None)

    def __post_init__(self) -> None:
        self.path = Path(self.file_path)
        try:
            self.validate()
            self.is_ok = True
        except Exception as exc:
            self.is_ok = False
            self.error = exc
            if self.raise_on_error:
                raise

    def validate(self) -> None:
        self.does_file_exist()
        self.is_file()

    def does_file_exist(self) -> None:
        if not self.path.exists():
            raise DependencyError(MESSAGES["validation.file_missing"].format(path=self.path))

    def is_file(self) -> None:
        if not self.path.is_file():
            raise ValidationError(MESSAGES["validation.file_not_file"].format(path=self.path))

@dataclass
class ValidateFolder:
    folder_path: Path | str
    raise_on_error: bool = True
    is_ok: bool = field(init=False, default=False)
    error: Exception | None = field(init=False, default=None)

    def __post_init__(self) -> None:
        self.path = Path(self.folder_path)
        try:
            self.validate()
            self.is_ok = True
        except Exception as exc:
            self.is_ok = False
            self.error = exc
            if self.raise_on_error:
                raise

    def validate(self) -> None:
        self.does_folder_exist()
        self.is_folder()

    def does_folder_exist(self) -> None:
        if not self.path.exists():
            raise DependencyError(MESSAGES["validation.folder_missing"].format(path=self.path))

    def is_folder(self) -> None:
        if not self.path.is_dir():
            raise ValidationError(MESSAGES["validation.folder_not_dir"].format(path=self.path))