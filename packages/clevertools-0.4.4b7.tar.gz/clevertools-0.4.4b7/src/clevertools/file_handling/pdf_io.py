from __future__ import annotations

from pathlib import Path

from ..error_handling.exceptions import PathError, ValidationError
from ..error_handling.validation import ValidateFile
from ..messages import MESSAGES


def read_pdf(file_path: Path | str) -> bytes:
    path: Path = Path(file_path)

    if not ValidateFile(path).is_ok:
        raise PathError("Invalid or non existent file")

    try:
        with path.open("rb") as f:
            return f.read()
    except (OSError, ValidationError) as exc:
        raise RuntimeError(MESSAGES["io.pdf.read_failed"].format(path=path, reason=exc)) from exc


def write_pdf(file_path: Path | str, data: bytes) -> None:
    path = Path(file_path)

    if not ValidateFile(path).is_ok:
        raise PathError("Invalid or non existent file")

    try:
        with path.open("wb") as f:
            f.write(data)
    except (OSError, TypeError, ValueError, ValidationError) as exc:
        raise RuntimeError(MESSAGES["io.pdf.write_failed"].format(path=path, reason=exc)) from exc