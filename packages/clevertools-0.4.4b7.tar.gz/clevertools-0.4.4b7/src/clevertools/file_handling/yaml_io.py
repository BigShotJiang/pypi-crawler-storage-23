from __future__ import annotations

from typing import Dict, Any
from pathlib import Path
import yaml

from ..error_handling.exceptions import PathError, ValidationError
from ..error_handling.validation import ValidateFile
from ..messages import MESSAGES

def read_yaml(file_path: Path | str) -> Dict[Any, Any]:
    path: Path = Path(file_path)
    
    if not ValidateFile(path).is_ok:
        raise PathError(f"Invalid or non existent file")

    try:
        with path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            return data if data is not None else {}
    except (OSError, yaml.YAMLError, ValidationError) as exc:
        raise RuntimeError(MESSAGES["io.yaml.read_failed"].format(path=path, reason=exc)) from exc

def write_yaml(file_path: Path | str, data: Any) -> None:
    path = Path(file_path)

    if not ValidateFile(path).is_ok:
        raise PathError(f"Invalid or non existent file")

    try:
        with path.open("w", encoding="utf-8") as f:
            yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)
    except (OSError, yaml.YAMLError, TypeError, ValueError, ValidationError) as exc:
        raise RuntimeError(MESSAGES["io.yaml.write_failed"].format(path=path, reason=exc)) from exc