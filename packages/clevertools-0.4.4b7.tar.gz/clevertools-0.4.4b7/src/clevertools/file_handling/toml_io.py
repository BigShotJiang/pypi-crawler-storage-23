from __future__ import annotations

from typing import Any, Dict
from pathlib import Path
import tomllib
import tomli_w

from ..error_handling.exceptions import PathError, ValidationError
from ..error_handling.validation import ValidateFile
from ..messages import MESSAGES


class TomlData(dict):
    def get(self, key: Any, default: Any = None) -> Any:
        if not isinstance(key, str) or "." not in key:
            return super().get(key, default)

        if key in self:
            return super().get(key, default)

        current: Any = self
        for part in key.split("."):
            if not isinstance(current, dict) or part not in current:
                return default
            current = current[part]
        return current


def read_toml(file_path: Path | str) -> TomlData:
    path: Path = Path(file_path)
    
    if not ValidateFile(path).is_ok:
        raise PathError(f"Invalid or non existent file")

    try:
        with path.open("rb") as f:
            data = tomllib.load(f)
    except (OSError, tomllib.TOMLDecodeError, ValidationError) as exc:
        raise RuntimeError(MESSAGES["io.toml.read_failed"].format(path=path, reason=exc)) from exc

    return TomlData(data)


def write_toml(file_path: Path | str, data: Any) -> None:
    path = Path(file_path)

    if not ValidateFile(path).is_ok:
        raise PathError(f"Invalid or non existent file")
    
    try:
        with path.open("wb") as f:
            tomli_w.dump(data, f)
    except (ModuleNotFoundError, OSError, TypeError, ValueError, ValidationError) as exc:
        raise RuntimeError(MESSAGES["io.toml.write_failed"].format(path=path, reason=exc)) from exc