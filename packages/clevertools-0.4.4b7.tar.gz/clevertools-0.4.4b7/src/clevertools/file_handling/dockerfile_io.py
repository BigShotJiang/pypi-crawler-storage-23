from __future__ import annotations

from pathlib import Path

from ..error_handling.exceptions import PathError, ValidationError
from ..error_handling.validation import ValidateFile
from ..messages import MESSAGES


def read_dockerfile(file_path: Path | str) -> str:
    path: Path = Path(file_path)

    if not ValidateFile(path).is_ok:
        raise PathError("Invalid or non existent file")

    try:
        with path.open("r", encoding="utf-8") as f:
            return f.read()
    except (OSError, UnicodeDecodeError, ValidationError) as exc:
        raise RuntimeError(MESSAGES["io.dockerfile.read_failed"].format(path=path, reason=exc)) from exc


def write_dockerfile(file_path: Path | str, data: str) -> None:
    path = Path(file_path)

    if not ValidateFile(path).is_ok:
        raise PathError("Invalid or non existent file")

    try:
        with path.open("w", encoding="utf-8") as f:
            f.write(data)
    except (OSError, TypeError, ValueError, ValidationError) as exc:
        raise RuntimeError(MESSAGES["io.dockerfile.write_failed"].format(path=path, reason=exc)) from exc