from __future__ import annotations

from typing import Any, Dict
from pathlib import Path

from ..error_handling.exceptions import PathError, ValidationError
from ..error_handling.validation import ValidateFile
from ..messages import MESSAGES


def read_bson(file_path: Path | str) -> Dict[Any, Any]:
    path: Path = Path(file_path)

    if not ValidateFile(path).is_ok:
        raise PathError("Invalid or non existent file")

    try:
        from bson import BSON

        with path.open("rb") as f:
            data = f.read()
        return BSON(data).decode()
    except (ModuleNotFoundError, OSError, TypeError, ValueError, ValidationError) as exc:
        raise RuntimeError(MESSAGES["io.bson.read_failed"].format(path=path, reason=exc)) from exc


def write_bson(file_path: Path | str, data: Any) -> None:
    path = Path(file_path)

    if not ValidateFile(path).is_ok:
        raise PathError("Invalid or non existent file")

    try:
        from bson import BSON

        with path.open("wb") as f:
            f.write(BSON.encode(data))
    except (ModuleNotFoundError, OSError, TypeError, ValueError, ValidationError) as exc:
        raise RuntimeError(MESSAGES["io.bson.write_failed"].format(path=path, reason=exc)) from exc