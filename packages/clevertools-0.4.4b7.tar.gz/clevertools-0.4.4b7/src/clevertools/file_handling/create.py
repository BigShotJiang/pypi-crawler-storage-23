from __future__ import annotations

from pathlib import Path
from ..error_handling.validation import ValidateFile, ValidateFolder
from ..messages import MESSAGES

def create_file(file_path: Path | str) -> None:
    path: Path = Path(file_path)

    try:
        if path.exists():
            ValidateFile(path)
            print(MESSAGES["file_handling.create.exists"].format(path=path))
        else:
            if not path.parent.exists():
                raise FileNotFoundError(MESSAGES["file_handling.create.parent_missing"].format(path=path.parent))
            path.touch(exist_ok=True)
            print(MESSAGES["file_handling.create.created"].format(path=path))
    except Exception as exc:
        raise RuntimeError(MESSAGES["file_handling.create.failed"].format(path=path, reason=exc)) from exc

def create_folder(folder_path: Path | str) -> None:
    path: Path = Path(folder_path)

    try:
        if not path.exists():
            path.mkdir(parents=True, exist_ok=True)
            print(MESSAGES["file_handling.create.created"].format(path=path))
        else:
            print(MESSAGES["file_handling.create.exists"].format(path=path))

        ValidateFolder(path)
    except Exception as exc:
        raise RuntimeError(MESSAGES["file_handling.create_folder.failed"].format(path=path, reason=exc)) from exc