from __future__ import annotations

from typing import Optional, Iterable
from pathlib import Path
import shutil
import os

from ..error_handling.exceptions import ValidationError
from ..error_handling.validation import ValidateFolder
from ..messages import MESSAGES

class PycacheCleaner:
    def __init__(self, skipped_dirs: Optional[Iterable[str]]) -> None:
        self.skip_set: set[str] = set(skipped_dirs or [])
        self.cache_dir_name: str = "__pycache__"
        self.bytecode_suffixes: set[str] = {".pyc", ".pyo"}

    def _remove_path(self, path: Path) -> None:
        try:
            if path.is_symlink() or path.is_file():
                path.unlink(missing_ok=True)
                return

            if path.is_dir():
                shutil.rmtree(path)
                return

            return
        except Exception as exc:
            raise RuntimeError(MESSAGES["cleaning.pycache.remove_path_failed"].format(path=path, reason=exc)) from exc

    def _start_removing(self, folder_path: Path) -> None:
        try:
            for current_dir, dir_names, file_names in os.walk(folder_path, topdown=True):
                current_path = Path(current_dir)

                dir_names[:] = [d for d in dir_names if d not in self.skip_set]

                if self.cache_dir_name in dir_names:
                    pycache_path = current_path / self.cache_dir_name
                    self._remove_path(pycache_path)
                    dir_names.remove(self.cache_dir_name)

                for fn in file_names:
                    p = current_path / fn
                    if p.suffix in self.bytecode_suffixes:
                        self._remove_path(p)
        except Exception as exc:
            raise RuntimeError(MESSAGES["cleaning.pycache.scan_failed"].format(path=folder_path, reason=exc)) from exc

def clean_pycaches(folder_path: Path | str, skipped_dirs: Optional[Iterable[str]] = None) -> None:
    path: Path = Path(folder_path)

    if not ValidateFolder(path).is_ok:
        raise ValidationError(f"{path} folder is invalid, is not existent or is not ok.")

    try:
        if path.resolve() == Path("/"):
            raise ValueError(MESSAGES["cleaning.root_refused"])

        cleaner = PycacheCleaner(skipped_dirs)
        cleaner._start_removing(path)
    except Exception as exc:
        raise RuntimeError(MESSAGES["cleaning.pycache.scan_failed"].format(path=path, reason=exc)) from exc