from __future__ import annotations

from typing import Iterable, Optional
from pathlib import Path
import shutil

from ..error_handling.exceptions import ValidationError
from ..error_handling.validation import ValidateFolder
from ..messages import MESSAGES

class FolderCleaner:
    def __init__(self, skipped_dirs: Optional[Iterable[str]]) -> None:
        self.skip_set: set[str] = set(skipped_dirs or [])

    def _remove_item(self, item: Path) -> None:
        try:
            if item.is_symlink() or item.is_file():
                item.unlink()
            elif item.is_dir():
                shutil.rmtree(item)
        except Exception as exc:
            raise RuntimeError(MESSAGES["cleaning.folder.remove_item_failed"].format(path=item, reason=exc)) from exc

    def _start_removing(self, folder_path: Path) -> None:
        try:
            for item in folder_path.iterdir():
                if item.name in self.skip_set:
                    continue

                self._remove_item(item)
        except Exception as exc:
            raise RuntimeError(MESSAGES["cleaning.folder.scan_failed"].format(path=folder_path, reason=exc)) from exc

def clean_folder(folder_path: Path | str, skipped_dirs: Optional[Iterable[str]] = None) -> None:
    path: Path = Path(folder_path)
    
    if not ValidateFolder(path).is_ok:
        raise ValidationError(f"{path} folder is invalid, is not existent or is not ok.")

    try:
        if path.resolve() == Path("/"):
            raise ValueError(MESSAGES["cleaning.root_refused"])

        cleaner = FolderCleaner(skipped_dirs)
        cleaner._start_removing(path)
    except Exception as exc:
        raise RuntimeError(MESSAGES["cleaning.folder.scan_failed"].format(path=path, reason=exc)) from exc