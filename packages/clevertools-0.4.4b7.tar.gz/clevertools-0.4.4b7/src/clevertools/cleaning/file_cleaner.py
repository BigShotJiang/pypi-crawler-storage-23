from __future__ import annotations

from pathlib import Path

from ..error_handling.exceptions import ValidationError
from ..error_handling.validation import ValidateFile
from ..messages import MESSAGES

class FileCleaner:
    def _start_removing(self, file_path: Path) -> None:
        try:
            file_path.unlink()
        except Exception as exc:
            raise RuntimeError(MESSAGES["cleaning.file.remove_failed"].format(path=file_path, reason=exc)) from exc

    def _start_emptying(self, file_path: Path) -> None:
        try:
            with file_path.open("w"):
                pass
        except Exception as exc:
            raise RuntimeError(MESSAGES["cleaning.file.remove_failed"].format(path=file_path, reason=exc)) from exc

def clean_file(file_path: Path | str) -> None:
    path: Path = Path(file_path)
    
    if not ValidateFile(path).is_ok:
        raise ValidationError(f"{path} file is invalid, is not existent or is not ok.")

    try:
        if path.resolve() == Path("/"):
            raise ValueError(MESSAGES["cleaning.root_refused"])

        cleaner = FileCleaner()
        cleaner._start_removing(path)
    except Exception as exc:
        raise RuntimeError(MESSAGES["cleaning.file.remove_failed"].format(path=path, reason=exc)) from exc