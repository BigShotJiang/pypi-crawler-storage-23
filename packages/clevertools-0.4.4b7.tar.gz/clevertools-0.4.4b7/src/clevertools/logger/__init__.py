from __future__ import annotations

from .core import (
    LogStructure,
    add_console_handler,
    add_file_handler,
    add_new_log_structure,
    build_standard_format,
    configure_default_logging,
    get_structure,
)
from .log_cmd import log

__all__ = [
    "LogStructure",
    "log",
    "build_standard_format",
    "add_console_handler",
    "add_file_handler",
    "add_new_log_structure",
    "configure_default_logging",
    "get_structure",
]