from __future__ import annotations

from typing import Optional, TextIO
from pathlib import Path
import atexit
import sys


_output_capture_file_path: Optional[Path] = None
_output_capture_handle: Optional[TextIO] = None
_original_stdout: Optional[TextIO] = None
_original_stderr: Optional[TextIO] = None
_atexit_registered = False


class TeeStream:
    def __init__(self, primary: TextIO, secondary: TextIO) -> None:
        self._primary = primary
        self._secondary = secondary

    def write(self, text: str) -> int:
        written = self._primary.write(text)
        self._secondary.write(text)
        return written

    def flush(self) -> None:
        self._primary.flush()
        self._secondary.flush()

    def isatty(self) -> bool:
        return self._primary.isatty()

    @property
    def encoding(self) -> Optional[str]:
        return getattr(self._primary, "encoding", None)


def restore_output_capture() -> None:
    global _output_capture_file_path
    global _output_capture_handle
    global _original_stdout
    global _original_stderr

    if _original_stdout is not None:
        sys.stdout = _original_stdout
    if _original_stderr is not None:
        sys.stderr = _original_stderr
    if _output_capture_handle is not None:
        _output_capture_handle.close()
    _output_capture_file_path = None
    _output_capture_handle = None
    _original_stdout = None
    _original_stderr = None


def enable_output_capture(log_path: Path) -> None:
    global _output_capture_file_path
    global _output_capture_handle
    global _original_stdout
    global _original_stderr
    global _atexit_registered

    if _output_capture_file_path == log_path and _output_capture_handle is not None:
        return

    if _output_capture_handle is not None:
        restore_output_capture()

    file_handle = log_path.open(mode="a", encoding="utf-8", buffering=1)
    stdout_stream: TextIO = sys.stdout
    stderr_stream: TextIO = sys.stderr
    _original_stdout = stdout_stream
    _original_stderr = stderr_stream
    sys.stdout = TeeStream(stdout_stream, file_handle)
    sys.stderr = TeeStream(stderr_stream, file_handle)
    _output_capture_file_path = log_path
    _output_capture_handle = file_handle

    if not _atexit_registered:
        atexit.register(restore_output_capture)
        _atexit_registered = True