from __future__ import annotations

from typing import Any, Optional
import logging

from .constants import LIB_LOGGER_NAME
from .handlers import add_console_handler, add_file_handler
from .structures import (
    DEFAULT_DATE_FORMAT,
    DEFAULT_RECORD_FORMAT,
    DEFAULT_TIME_FORMAT,
    LogStructure,
    add_new_log_structure,
    get_structure,
)


_logger = logging.getLogger(LIB_LOGGER_NAME)
_logger.addHandler(logging.NullHandler())


def build_standard_format(include_date: bool = False, include_time: bool = False) -> str:
    head = "%(process_name)s | %(levelname)s"
    if include_date and include_time:
        return f"{head} | %(date)s, %(time)s = %(message)s"
    if include_date:
        return f"{head} | %(date)s = %(message)s"
    if include_time:
        return f"{head} | %(time)s = %(message)s"
    return f"{head} = %(message)s"


def configure_default_logging(
    *,
    level: int = logging.INFO,
    fmt: Optional[str] = None,
    include_date: bool = False,
    include_time: bool = False,
    use_eu_date: bool = True,
    auto_timestamp: Optional[bool] = None,
    date_format: Optional[str] = None,
    time_format: Optional[str] = None,
) -> None:
    resolved_fmt = fmt or build_standard_format(include_date=include_date, include_time=include_time)
    needs_timestamp = include_date or include_time
    if auto_timestamp is None:
        resolved_auto_timestamp = needs_timestamp
    else:
        resolved_auto_timestamp = auto_timestamp or (fmt is None and needs_timestamp)
    resolved_date_format = date_format or ("%d.%m.%Y" if use_eu_date else DEFAULT_DATE_FORMAT)
    resolved_time_format = time_format if isinstance(time_format, str) and time_format.strip() else DEFAULT_TIME_FORMAT

    add_new_log_structure(
        "DEFAULT",
        fmt=resolved_fmt,
        required_fields=("process_name",),
        default_extra={"id": 0},
        auto_timestamp=resolved_auto_timestamp,
        date_format=resolved_date_format,
        time_format=resolved_time_format,
    )
    add_console_handler(level=level, fmt=resolved_fmt)


def log(process: str, level: str, message: str, **meta: Any) -> None:
    structure = get_structure("DEFAULT")
    structure(0, process, level, message, **meta)


add_new_log_structure(
    "DEFAULT",
    fmt=DEFAULT_RECORD_FORMAT,
    required_fields=("process_name",),
    default_extra={"id": 0},
    auto_timestamp=True,
    date_format=DEFAULT_DATE_FORMAT,
    time_format=DEFAULT_TIME_FORMAT,
)


__all__ = [
    "LogStructure",
    "build_standard_format",
    "add_console_handler",
    "add_file_handler",
    "add_new_log_structure",
    "configure_default_logging",
    "get_structure",
    "log",
]
