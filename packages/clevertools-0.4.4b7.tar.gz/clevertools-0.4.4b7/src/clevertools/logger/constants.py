from __future__ import annotations


LIB_LOGGER_NAME = "clevertools"