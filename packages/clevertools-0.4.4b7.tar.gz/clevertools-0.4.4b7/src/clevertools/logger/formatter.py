from __future__ import annotations

import logging

from .structures import _STRUCTURES


class StructureFormatter(logging.Formatter):
    def __init__(self, fallback_fmt: str) -> None:
        super().__init__(fallback_fmt)
        self._fallback_fmt = fallback_fmt

    def format(self, record: logging.LogRecord) -> str:
        structure_name = getattr(record, "structure_name", None)
        if structure_name and structure_name in _STRUCTURES:
            structure_fmt = _STRUCTURES[structure_name].fmt
            return logging.Formatter(structure_fmt).format(record)
        return logging.Formatter(self._fallback_fmt).format(record)