from __future__ import annotations

from typing import Optional
from datetime import datetime
from pathlib import Path
from secrets import token_hex
import logging
import sys

from ..file_handling.create import create_file, create_folder
from .constants import LIB_LOGGER_NAME
from .formatter import StructureFormatter
from .output_capture import enable_output_capture
from .structures import DEFAULT_RECORD_FORMAT


def _script_directory() -> Path:
    argv0 = Path(sys.argv[0]) if sys.argv else Path()
    if argv0.name in ("", "-", "-c"):
        return Path.cwd()
    try:
        resolved = argv0.resolve()
    except OSError:
        return Path.cwd()
    if resolved.exists():
        return resolved.parent
    return Path.cwd()


def _resolve_log_path(filename: Optional[str | Path]) -> Path:
    if filename:
        return Path(filename).expanduser().resolve()

    logs_dir = _script_directory() / "logs"
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    random_suffix = token_hex(4)
    return logs_dir / f"Log_{stamp}_{random_suffix}.log"


def add_console_handler(level: int = logging.INFO, fmt: str = DEFAULT_RECORD_FORMAT) -> None:
    logger = logging.getLogger(LIB_LOGGER_NAME)
    logger.setLevel(level)

    console_stream = getattr(sys, "__stderr__", sys.stderr)
    handler = logging.StreamHandler(stream=console_stream)
    handler.setFormatter(StructureFormatter(fmt))

    if not any(
        isinstance(existing_handler, logging.StreamHandler) and not isinstance(existing_handler, logging.FileHandler)
        for existing_handler in logger.handlers
    ):
        logger.addHandler(handler)

    logger.propagate = False


def add_file_handler(filename: Optional[str | Path] = None, level: Optional[int] = None, fmt: str = DEFAULT_RECORD_FORMAT, mirror_console_output: bool = True) -> Path:
    logger = logging.getLogger(LIB_LOGGER_NAME)
    if level is not None:
        logger.setLevel(level)

    target_path = _resolve_log_path(filename)
    create_folder(target_path.parent)
    create_file(target_path)

    handler = logging.FileHandler(target_path, encoding="utf-8")
    handler.setFormatter(StructureFormatter(fmt))

    if not any(
        isinstance(existing_handler, logging.FileHandler)
        and existing_handler.baseFilename == str(target_path)
        for existing_handler in logger.handlers
    ):
        logger.addHandler(handler)
    else:
        handler.close()

    logger.propagate = False

    if mirror_console_output:
        enable_output_capture(target_path)

    return target_path