from __future__ import annotations

from typing import Any, Dict, Iterable, Optional
from dataclasses import dataclass, field
from datetime import datetime
import logging

from .constants import LIB_LOGGER_NAME


DEFAULT_RECORD_FORMAT = "%(process_name)s | [ %(levelname)s ] = %(message)s"
DEFAULT_STRUCTURE_FORMAT = "%(id)s | %(process_name)s | %(levelname)s | %(date)s %(time)s | %(message)s"
DEFAULT_DATE_FORMAT = "%Y-%m-%d"
DEFAULT_TIME_FORMAT = "%H:%M:%S"


def _normalize_level(level: str) -> int:
    level_name = (level or "INFO").strip().upper()
    value = logging.getLevelName(level_name)
    if isinstance(value, int):
        return value
    raise ValueError(f"Invalid log level: {level!r}")


@dataclass(frozen=True)
class LogStructure:
    name: str
    fmt: str
    required_fields: tuple[str, ...] = field(default_factory=tuple)
    default_extra: Dict[str, Any] = field(default_factory=dict)
    auto_timestamp: bool = True
    date_format: str = DEFAULT_DATE_FORMAT
    time_format: str = DEFAULT_TIME_FORMAT

    def __call__(self, log_id: int, process: str, level: str, message: str, **meta: Any) -> None:
        logger = logging.getLogger(LIB_LOGGER_NAME)
        extra: Dict[str, Any] = {
            "id": log_id,
            "process_name": process,
            "structure_name": self.name,
            **self.default_extra,
            **meta,
        }

        if self.auto_timestamp:
            now = datetime.now()
            extra.setdefault("date", now.strftime(self.date_format))
            extra.setdefault("time", now.strftime(self.time_format))

        for field_name in self.required_fields:
            if field_name not in extra:
                raise ValueError(f"Missing required field: {field_name!r}")

        logger.log(_normalize_level(level), message, extra=extra)


_STRUCTURES: Dict[str, LogStructure] = {}


def add_new_log_structure(
    name: str,
    *,
    fmt: str = DEFAULT_STRUCTURE_FORMAT,
    required_fields: Optional[Iterable[str]] = None,
    default_extra: Optional[Dict[str, Any]] = None,
    auto_timestamp: bool = True,
    date_format: str = DEFAULT_DATE_FORMAT,
    time_format: str = DEFAULT_TIME_FORMAT,
) -> None:
    _STRUCTURES[name] = LogStructure(
        name=name,
        fmt=fmt,
        required_fields=tuple(required_fields or ()),
        default_extra=dict(default_extra or {}),
        auto_timestamp=auto_timestamp,
        date_format=date_format,
        time_format=time_format,
    )


def get_structure(name: str) -> LogStructure:
    try:
        return _STRUCTURES[name]
    except KeyError as exc:
        raise KeyError(f"Unknown log structure: {name!r}") from exc