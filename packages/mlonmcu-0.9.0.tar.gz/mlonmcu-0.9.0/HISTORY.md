# History

## 0.1.0 (2021-11-12)

* First closed-source release.
