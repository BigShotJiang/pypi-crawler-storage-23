=====
Usage
=====

To use ML on MCU in a project::

    import mlonmcu
