.. include:: AUTO_VECTORIZE.md
   :parser: myst_parser.sphinx_
