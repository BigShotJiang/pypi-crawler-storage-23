# CMSIS-NN BYOC Feature

## Usage

- The used extensions have to be manually selected by setting `cmsisnnbyoc.mcpu` on the command line

## Compatibility

- The `cmsisnnbyoc` feature is not compatible with the `desired_layout` config for the TVM targets
