.. include:: COMPONENTS.md
   :parser: myst_parser.sphinx_


Components in Detail
====================

.. toctree::
   :maxdepth: 2
   :caption: Components:

   components/cmsisnnbyoc
   components/muriscvnnbyoc
   components/auto_vectorize
