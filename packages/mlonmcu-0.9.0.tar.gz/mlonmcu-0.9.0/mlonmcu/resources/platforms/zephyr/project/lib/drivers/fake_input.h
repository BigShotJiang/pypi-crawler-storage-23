#ifndef DRIVER_FAKE_INPUT_H
#define DRIVER_FAKE_INPUT_H

#include <stddef.h>

void FakeInput_GetData(void *out, size_t len);

#endif
