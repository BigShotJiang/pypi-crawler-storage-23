void init_target();
void deinit_target();
