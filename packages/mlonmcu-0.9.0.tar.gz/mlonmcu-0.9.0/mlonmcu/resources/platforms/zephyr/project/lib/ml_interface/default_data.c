#include "ml_interface.h"
#include <stddef.h>
const int num_data_buffers_in = 0;
const int num_data_buffers_out = 0;
const unsigned char *const data_buffers_in[] = {};
const unsigned char *const data_buffers_out[] = {};
const size_t data_size_in[] = {};
const size_t data_size_out[] = {};
