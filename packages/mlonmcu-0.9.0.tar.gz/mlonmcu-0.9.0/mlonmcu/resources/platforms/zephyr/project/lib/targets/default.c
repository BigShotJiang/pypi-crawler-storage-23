__attribute__((weak)) void init_target() {}
__attribute__((weak)) void deinit_target() {}
