# Package data for licenses-deny (TOML mappings, etc.)
