"""Package initialization for licenses_deny."""

from .cli import main

__all__ = ['main']
