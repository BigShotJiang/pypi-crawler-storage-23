from typing import List, Dict, Any, Optional

class ConflictsResource:
    def __init__(self, client):
        self.client = client

    def list(self, skip: int = 0, limit: int = 100, 
             status_filter: Optional[str] = None, 
             priority_filter: Optional[str] = None) -> List[Dict[str, Any]]:
        """List conflicts."""
        params = {"skip": skip, "limit": limit}
        if status_filter: params["status_filter"] = status_filter
        if priority_filter: params["priority_filter"] = priority_filter
        
        return self.client._request("GET", "/conflicts/", params=params)

    def get(self, conflict_id: int) -> Dict[str, Any]:
        """Get a specific conflict."""
        return self.client._request("GET", f"/conflicts/{conflict_id}")

    def create(self, conversation_id: int, title: str, description: str, 
               priority: str = "medium") -> Dict[str, Any]:
        """Create a new conflict report."""
        data = {
            "conversation_id": conversation_id,
            "title": title,
            "description": description,
            "priority": priority
        }
        return self.client._request("POST", "/conflicts/", json_data=data)

    def update(self, conflict_id: int, title: Optional[str] = None, 
               description: Optional[str] = None, priority: Optional[str] = None,
               status: Optional[str] = None, assigned_to: Optional[int] = None,
               resolution_notes: Optional[str] = None) -> Dict[str, Any]:
        """Update a conflict."""
        data = {}
        if title: data["title"] = title
        if description: data["description"] = description
        if priority: data["priority"] = priority
        if status: data["status"] = status
        if assigned_to: data["assigned_to"] = assigned_to
        if resolution_notes: data["resolution_notes"] = resolution_notes
        
        return self.client._request("PUT", f"/conflicts/{conflict_id}", json_data=data)
