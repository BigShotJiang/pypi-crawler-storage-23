from typing import Dict, Any

class CaptchaResource:
    def __init__(self, client):
        self.client = client

    def get_challenge(self, project_id: str) -> Dict[str, str]:
        """
        Get a new CAPTCHA challenge for the project.
        
        Args:
            project_id: The Voni Project ID
            
        Returns:
            Dict containing 'token' and 'question'
        """
        return self.client._request("GET", f"/widget/{project_id}/captcha")

    def verify_challenge(self, project_id: str, token: str, answer: str) -> Dict[str, Any]:
        """
        Verify a CAPTCHA answer.
        
        Args:
            project_id: The Voni Project ID
            token: The challenge token
            answer: The user's answer
            
        Returns:
            Dict containing 'success' status
        """
        data = {
            "token": token,
            "answer": answer
        }
        return self.client._request("POST", f"/widget/{project_id}/captcha/verify", json_data=data)
