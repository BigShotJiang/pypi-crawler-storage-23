from typing import List, Dict, Any

class InvitationResource:
    def __init__(self, client):
        self.client = client

    def list(self, project_id: str) -> List[Dict[str, Any]]:
        """List all pending invitations for a project."""
        return self.client._request("GET", f"/projects/{project_id}/invitations")

    def invite(self, project_id: str, email: str, role: str = "member") -> Dict[str, Any]:
        """Invite a user to the project."""
        data = {
            "email": email,
            "role": role
        }
        return self.client._request("POST", f"/projects/{project_id}/invitations", json_data=data)

    def revoke(self, project_id: str, invitation_id: int) -> bool:
        """Revoke a pending invitation."""
        self.client._request("DELETE", f"/projects/{project_id}/invitations/{invitation_id}")
        return True
