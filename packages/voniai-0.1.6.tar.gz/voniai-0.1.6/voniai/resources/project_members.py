from typing import List, Dict, Any

class ProjectMembersResource:
    def __init__(self, client):
        self.client = client

    def list(self, project_id: str, skip: int = 0, limit: int = 100) -> List[Dict[str, Any]]:
        """List all members of a project."""
        params = {"skip": skip, "limit": limit}
        return self.client._request("GET", f"/projects/{project_id}/members", params=params)

    def add(self, project_id: str, email: str, role: str = "member") -> Dict[str, Any]:
        """Add a member to the project."""
        data = {
            "email": email,
            "role": role
        }
        return self.client._request("POST", f"/projects/{project_id}/members", json_data=data)

    def update(self, project_id: str, member_id: int, role: str) -> Dict[str, Any]:
        """Update a project member's role."""
        data = {"role": role}
        return self.client._request("PUT", f"/projects/{project_id}/members/{member_id}", json_data=data)

    def remove(self, project_id: str, member_id: int) -> bool:
        """Remove a member from the project."""
        self.client._request("DELETE", f"/projects/{project_id}/members/{member_id}")
        return True
