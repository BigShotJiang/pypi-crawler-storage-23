from typing import List, Dict, Any

class WebhookResource:
    def __init__(self, client):
        self.client = client

    def list(self) -> List[Dict[str, Any]]:
        """List all webhook endpoints."""
        return self.client._request("GET", "/integrations/webhooks/")

    def create(self, url: str, description: str = "") -> Dict[str, Any]:
        """Create a new webhook endpoint."""
        data = {
            "url": url,
            "description": description
        }
        return self.client._request("POST", "/integrations/webhooks/", json_data=data)

    def delete(self, webhook_id: int) -> bool:
        """Delete a webhook endpoint."""
        self.client._request("DELETE", f"/integrations/webhooks/{webhook_id}")
        return True
