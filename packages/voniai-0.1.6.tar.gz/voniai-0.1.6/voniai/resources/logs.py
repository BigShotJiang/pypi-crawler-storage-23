from typing import Dict, Any, Optional

class LogsResource:
    def __init__(self, client):
        self.client = client

    def create(self, level: int, message: str, timestamp: str, 
               context: Optional[Dict[str, Any]] = None, 
               stack: Optional[str] = None) -> None:
        """Create a log entry."""
        data = {
            "level": level,
            "message": message,
            "timestamp": timestamp
        }
        if context:
            data["context"] = context
        if stack:
            data["stack"] = stack
            
        self.client._request("POST", "/logs", json_data=data)
