from typing import List, Dict, Any

class ApiKeysResource:
    def __init__(self, client):
        self.client = client

    def list(self) -> List[Dict[str, Any]]:
        """List all API keys for the authenticated user."""
        return self.client._request("GET", "/api-keys/")

    def create(self, name: str) -> Dict[str, Any]:
        """Create a new API key."""
        data = {"name": name}
        return self.client._request("POST", "/api-keys/", json_data=data)

    def delete(self, key_id: int) -> bool:
        """Delete an API key."""
        self.client._request("DELETE", f"/api-keys/{key_id}")
        return True
