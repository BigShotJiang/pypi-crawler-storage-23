from typing import Dict, Any, List

class SystemResource:
    def __init__(self, client):
        self.client = client

    def get_status(self) -> Dict[str, Any]:
        """Get system status and health information."""
        return self.client._request("GET", "/system/status")

    def post_metrics(self, metrics: List[Dict[str, Any]]) -> None:
        """Post performance metrics."""
        data = {"metrics": metrics}
        self.client._request("POST", "/system/metrics", json_data=data)
