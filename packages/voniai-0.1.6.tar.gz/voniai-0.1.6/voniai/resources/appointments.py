from typing import Dict, Any, List, Optional

class AppointmentResource:
    def __init__(self, client):
        self.client = client

    def list(self, project_id: int, skip: int = 0, limit: int = 100) -> List[Dict[str, Any]]:
        """List all appointments for a project."""
        return self.client._request("GET", f"/projects/{project_id}/appointments", params={"skip": skip, "limit": limit})

    def get(self, project_id: int, appointment_id: int) -> Dict[str, Any]:
        """Get details of a specific appointment."""
        return self.client._request("GET", f"/projects/{project_id}/appointments/{appointment_id}")

    def update(self, project_id: int, appointment_id: int, updates: Dict[str, Any]) -> Dict[str, Any]:
        """Update an appointment's information or status."""
        return self.client._request("PUT", f"/projects/{project_id}/appointments/{appointment_id}", json_data=updates)

    def delete(self, project_id: int, appointment_id: int) -> None:
        """Delete an appointment."""
        self.client._request("DELETE", f"/projects/{project_id}/appointments/{appointment_id}")
