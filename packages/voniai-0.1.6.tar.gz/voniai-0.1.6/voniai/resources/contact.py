from typing import Dict, Any, Optional

class ContactResource:
    def __init__(self, client):
        self.client = client

    def submit(self, name: str, email: str, subject: str, message: str) -> Dict[str, Any]:
        """Submit a contact form."""
        data = {
            "name": name,
            "email": email,
            "subject": subject,
            "message": message
        }
        return self.client._request("POST", "/contact/submit", json_data=data)

    def schedule_demo(self, name: str, email: str, company: Optional[str] = None,
                      phone: Optional[str] = None, preferred_date: Optional[str] = None,
                      preferred_time: Optional[str] = None, message: Optional[str] = None) -> Dict[str, Any]:
        """Schedule a demo."""
        data = {
            "name": name,
            "email": email
        }
        if company: data["company"] = company
        if phone: data["phone"] = phone
        if preferred_date: data["preferred_date"] = preferred_date
        if preferred_time: data["preferred_time"] = preferred_time
        if message: data["message"] = message
        
        return self.client._request("POST", "/contact/schedule-demo", json_data=data)
