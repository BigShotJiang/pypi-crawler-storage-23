from typing import Dict, Any

class UserResource:
    def __init__(self, client):
        self.client = client

    def me(self) -> Dict[str, Any]:
        """Get current user information."""
        return self.client._request("GET", "/users/me")
