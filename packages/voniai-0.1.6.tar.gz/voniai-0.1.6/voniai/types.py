from typing import TypedDict, List, Optional, Dict, Any

class QuickAction(TypedDict, total=False):
    label: str
    message: str

class WidgetColors(TypedDict, total=False):
    primary: str
    header: str
    userMessage: str
    botMessage: str
    background: str
    text: str

class WidgetSettings(TypedDict, total=False):
    colors: WidgetColors
    colorScheme: str
    position: str
    avatarUrl: str
    launcherIconUrl: str
    greeting: str
    quick_actions: List[QuickAction]
    auto_generate_quick_actions: bool
    proactiveDelay: int
    allowedDomains: List[str]
    features: Dict[str, bool]
