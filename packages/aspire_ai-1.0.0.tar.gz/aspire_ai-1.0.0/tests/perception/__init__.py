"""Tests for ASPIRE perception modules."""
