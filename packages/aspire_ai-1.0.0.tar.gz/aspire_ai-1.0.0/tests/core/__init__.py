"""Core ASPIRE tests."""
