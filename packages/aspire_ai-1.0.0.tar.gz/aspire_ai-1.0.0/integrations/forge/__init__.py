"""
ASPIRE for Forge: Teaching image generation models to develop aesthetic judgment.

Instead of just generating images, models learn to internalize what makes
a good image through adversarial dialogue with vision-language teacher models.
"""
