from sng4onnx.onnx_opname_generator import generate, main

__version__ = '2.0.1'
