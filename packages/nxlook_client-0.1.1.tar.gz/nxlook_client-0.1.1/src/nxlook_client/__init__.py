# src/epistemic_infer/__init__.py

"""
NxLook Epistemic AI Inference Library
"""

from .inference import inference, interactive_inference, non_interactive_inference

__all__ = [
    'inference',
    'interactive_inference',
    'non_interactive_inference'
]
