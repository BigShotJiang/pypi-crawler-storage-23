# NxLook Epistemic AI Inference Library

> **Inference-only** Python library for Epistemic AI trained models. No training, no reverse engineering.

## Installation

```bash
pip install nxlook-client
```

# Usage
## Non-interactive Inference
```
from nxlook_client import non_interactive_inference

response = non_interactive_inference(
    model_path="path/to/your/model.pth",
    prompt="What is the meaning of life?"
)
print(response)
```

##Interactive Chat Mode
```
from nxlook_client import interactive_inference

interactive_inference("path/to/your/model.pth", temperature=0.6)
Unified inference() Function
from epistemic_infer import inference

# Non-interactive
response = inference("model.pth", prompt="Hello world")

# Interactive
inference("model.pth", interactive=True)
```

#Requirements
    Python 3.8+
    PyTorch 2.0+

#License
    MIT