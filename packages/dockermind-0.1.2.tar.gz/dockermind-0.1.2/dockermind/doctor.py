"""
Docker doctor -- checks that Docker is installed and running.
"""

from __future__ import annotations

import subprocess

from dockermind.utils import command_available, run_command, green, red, yellow, dim


def check_docker_installed() -> bool:
    """Return True if the ``docker`` binary is on the PATH."""
    return command_available("docker")


def check_docker_running() -> bool:
    """Return True if the Docker daemon is responsive."""
    try:
        run_command(["docker", "info"], capture=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        return False


def run_doctor() -> bool:
    """Run all health checks and print results. Return True if everything passes."""
    all_ok = True

    print()
    print("  Docker Environment Check")
    print("  " + "-" * 40)

    # Check 1: Docker installed
    if check_docker_installed():
        print(f"  {green('PASS')}  Docker CLI is installed")
    else:
        print(f"  {red('FAIL')}  Docker CLI is not installed")
        print(f"         {dim('Install Docker: https://docs.docker.com/get-docker/')}")
        all_ok = False

    # Check 2: Docker daemon running
    if all_ok:
        if check_docker_running():
            print(f"  {green('PASS')}  Docker daemon is running")

            # Bonus: show Docker version
            try:
                result = run_command(["docker", "version", "--format", "{{.Server.Version}}"])
                version = result.stdout.strip()
                print(f"         {dim(f'Server version: {version}')}")
            except (subprocess.CalledProcessError, FileNotFoundError):
                pass
        else:
            print(f"  {red('FAIL')}  Docker daemon is not running")
            print(f"         {dim('Start Docker Desktop or run: sudo systemctl start docker')}")
            all_ok = False

    # Check 3: Docker Compose available
    compose_available = False
    try:
        run_command(["docker", "compose", "version"], capture=True)
        compose_available = True
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        pass

    if not compose_available:
        # Try legacy docker-compose
        try:
            run_command(["docker-compose", "version"], capture=True)
            compose_available = True
        except (subprocess.CalledProcessError, FileNotFoundError, OSError):
            pass

    if compose_available:
        print(f"  {green('PASS')}  Docker Compose is available")
    else:
        print(f"  {yellow('WARN')}  Docker Compose not found (optional)")

    print()

    if all_ok:
        print(f"  {green('All checks passed. Ready to build.')}")
    else:
        print(f"  {red('Some checks failed. Fix the issues above.')}")

    print()
    return all_ok
