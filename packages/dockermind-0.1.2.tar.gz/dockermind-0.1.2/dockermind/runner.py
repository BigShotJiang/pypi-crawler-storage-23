"""
Docker runner -- wraps ``docker build`` and ``docker run`` with clean error handling.
"""

from __future__ import annotations

import socket
import subprocess
import sys

from dockermind.utils import green, red, yellow, dim, bold


def _check_port_available(port: int) -> bool:
    """Return True if *port* is free on localhost; False if already bound."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", port))
        return True
    except OSError:
        return False


def docker_build(
    project_path: str,
    *,
    tag: str = "dockermind-app",
) -> bool:
    """Run ``docker build`` and stream output. Return True on success."""
    print()
    print(f"  {bold('Building image:')} {tag}")
    print(f"  {dim(f'Context: {project_path}')}")
    print()

    cmd = [
        "docker", "build",
        "-t", tag,
        project_path,
    ]

    try:
        # Stream build output directly to terminal
        process = subprocess.Popen(
            cmd,
            stdout=sys.stdout,
            stderr=sys.stderr,
        )
        exit_code = process.wait()

        print()
        if exit_code == 0:
            print(f"  {green(f'Image built successfully: {tag}')}")
            return True
        else:
            print(f"  {red(f'Build failed with exit code {exit_code}')}")
            return False

    except FileNotFoundError:
        print(f"  {red('Docker is not installed or not on PATH.')}")
        print(f"  {dim('Run `dockermind doctor` to diagnose.')}")
        return False
    except OSError as e:
        print(f"  {red(f'Failed to run docker build: {e}')}")
        return False


def docker_run(
    *,
    tag: str = "dockermind-app",
    port: int = 3000,
    detach: bool = False,
) -> bool:
    """Run ``docker run`` with port mapping. Return True on success."""
    print()
    print(f"  {bold('Running container:')} {tag}")
    print(f"  {dim(f'Port mapping: {port}:{port}')}")

    # Lightweight port-in-use warning (non-blocking)
    if not _check_port_available(port):
        print(f"  {yellow(f'Warning: Port {port} appears to be in use.')}")

    print()

    cmd = [
        "docker", "run",
        "--rm",
        "-p", f"{port}:{port}",
    ]

    if detach:
        cmd.append("-d")

    cmd.append(tag)

    try:
        if detach:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                container_id = result.stdout.strip()[:12]
                print(f"  {green(f'Container started: {container_id}')}")
                print(f"  {dim(f'Listening on http://localhost:{port}')}")
                return True
            else:
                print(f"  {red(f'Failed to start container.')}")
                if result.stderr:
                    print(f"  {dim(result.stderr.strip())}")
                return False
        else:
            # Foreground mode -- stream output
            print(f"  {dim(f'Listening on http://localhost:{port}')}")
            print(f"  {dim('Press Ctrl+C to stop.')}")
            print()

            process = subprocess.Popen(
                cmd,
                stdout=sys.stdout,
                stderr=sys.stderr,
            )
            try:
                exit_code = process.wait()
            except KeyboardInterrupt:
                print()
                print(f"  {yellow('Stopping container...')}")
                process.terminate()
                process.wait(timeout=10)
                return True

            return exit_code == 0

    except FileNotFoundError:
        print(f"  {red('Docker is not installed or not on PATH.')}")
        return False
    except OSError as e:
        print(f"  {red(f'Failed to run docker run: {e}')}")
        return False
