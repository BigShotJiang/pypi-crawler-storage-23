"""
Dockermind -- Smart Dockerfile generation CLI for Node.js and Python projects.
"""

__version__ = "0.1.1"
