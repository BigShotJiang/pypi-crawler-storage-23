"""
Utility helpers shared across dockermind modules.

Includes coloured terminal output, file helpers, and common constants.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys


# ---------------------------------------------------------------------------
# Terminal colour helpers (zero dependencies)
# ---------------------------------------------------------------------------

_SUPPORTS_COLOR = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def _colour(code: str, text: str) -> str:
    """Wrap *text* in an ANSI colour escape if the terminal supports it."""
    if _SUPPORTS_COLOR:
        return f"\033[{code}m{text}\033[0m"
    return text


def red(t: str) -> str:
    return _colour("31", t)


def green(t: str) -> str:
    return _colour("32", t)


def yellow(t: str) -> str:
    return _colour("33", t)


def cyan(t: str) -> str:
    return _colour("36", t)


def bold(t: str) -> str:
    return _colour("1", t)


def dim(t: str) -> str:
    return _colour("2", t)


# ---------------------------------------------------------------------------
# File helpers
# ---------------------------------------------------------------------------


def file_exists(project_path: str, filename: str) -> bool:
    """Return True if *filename* exists inside *project_path*."""
    return os.path.isfile(os.path.join(project_path, filename))


def read_file(project_path: str, filename: str) -> str | None:
    """Read a text file from *project_path* and return its contents, or None."""
    filepath = os.path.join(project_path, filename)
    try:
        with open(filepath, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except (OSError, IOError):
        return None


def write_file(path: str, content: str) -> None:
    """Write *content* to *path*, creating parent directories as needed."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)


# ---------------------------------------------------------------------------
# Subprocess helpers
# ---------------------------------------------------------------------------


def run_command(
    cmd: list[str],
    *,
    cwd: str | None = None,
    capture: bool = True,
) -> subprocess.CompletedProcess[str]:
    """Run an external command and return the CompletedProcess result.

    Raises subprocess.CalledProcessError on non-zero exit.
    """
    return subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=capture,
        text=True,
        check=True,
    )


def command_available(name: str) -> bool:
    """Return True if *name* is on the PATH."""
    return shutil.which(name) is not None


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------


def extract_port_from_source(source: str) -> int | None:
    """Try to extract a port number from source code.

    Looks for common patterns like ``app.listen(3000)``,
    ``process.env.PORT``, ``uvicorn.run(..., port=8000)`` etc.
    """
    # Node patterns: app.listen(3000)  /  .listen(PORT)
    match = re.search(r"\.listen\(\s*(\d{2,5})\s*[\),]", source)
    if match:
        return int(match.group(1))

    # Python patterns: port=8000
    match = re.search(r"port\s*=\s*(\d{2,5})", source)
    if match:
        return int(match.group(1))

    return None


def confirm(prompt: str) -> bool:
    """Prompt the user with a y/N confirmation."""
    try:
        answer = input(f"{prompt} [y/N] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    return answer in ("y", "yes")
