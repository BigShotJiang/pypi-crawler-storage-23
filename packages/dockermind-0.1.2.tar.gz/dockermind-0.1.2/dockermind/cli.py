"""
Dockermind CLI -- built with Typer.

Commands:
    dockermind init        Analyse project and generate Dockerfile
    dockermind build       Build Docker image from generated Dockerfile
    dockermind run         Run the built Docker image
    dockermind doctor      Check Docker environment health
    dockermind version     Show dockermind version
"""

from __future__ import annotations

import os
import sys

import typer

from dockermind import __version__
from dockermind.analyzer import Analyzer
from dockermind.compose_generator import generate_compose
from dockermind.doctor import run_doctor
from dockermind.dockerfile_generator import generate_dockerfile, generate_dockerignore
from dockermind.runner import docker_build, docker_run
from dockermind.utils import (
    bold,
    confirm,
    cyan,
    dim,
    file_exists,
    green,
    red,
    write_file,
    yellow,
)

# ---------------------------------------------------------------------------
# Typer app
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="dockermind",
    help="Smart Dockerfile generation CLI for Node.js and Python projects.",
    add_completion=False,
    no_args_is_help=True,
)


def _banner() -> None:
    """Print the dockermind banner."""
    typer.echo()
    typer.echo(f"  {bold('dockermind')} {dim(f'v{__version__}')}")
    typer.echo(f"  {dim('Smart Dockerfile generation for Node.js & Python')}")
    typer.echo()


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


@app.command()
def init(
    path: str = typer.Argument(
        ".",
        help="Path to the project directory to analyse.",
    ),
    compose: bool = typer.Option(
        False,
        "--compose",
        help="Also generate docker-compose.yml.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Show generated files without writing to disk.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Overwrite existing Dockerfile without asking.",
    ),
) -> None:
    """Analyse a project and generate an optimised Dockerfile."""
    _banner()

    project_path = os.path.abspath(path)

    if not os.path.isdir(project_path):
        typer.echo(red(f"  Error: '{project_path}' is not a valid directory."))
        raise typer.Exit(code=1)

    typer.echo(dim(f"  Analysing: {project_path}"))
    typer.echo()

    # -- Run analysis --
    analyzer = Analyzer(project_path)
    result = analyzer.run()

    if result.language is None:
        typer.echo(red("  Error: Could not detect a supported project type."))
        typer.echo(dim("  Supported: Node.js (package.json) or Python (requirements.txt / pyproject.toml)"))
        raise typer.Exit(code=1)

    # -- Display analysis summary --
    typer.echo(f"  {bold('Project Analysis')}")
    typer.echo("  " + "-" * 40)
    typer.echo(f"  Language:    {cyan(result.language)}")

    if result.framework:
        typer.echo(f"  Framework:   {cyan(result.framework)}")

    typer.echo(f"  Version:     {cyan(result.runtime_version)}")
    typer.echo(f"  Port:        {cyan(str(result.port))}")

    if result.language == "node":
        typer.echo(f"  Build step:  {cyan('yes' if result.has_build_script else 'no')}")
        if result.start_script:
            typer.echo(f"  Start:       {dim(result.start_script)}")

    if result.language == "python":
        if result.python_entry_module:
            typer.echo(f"  Entry:       {dim(result.python_entry_module)}")
        typer.echo(f"  Uvicorn:     {cyan('yes' if result.uses_uvicorn else 'no')}")

    # Show warnings
    if result.warnings:
        typer.echo()
        for w in result.warnings:
            typer.echo(f"  {yellow(f'Warning: {w}')}")

    typer.echo()

    # -- Generate files --
    dockerfile_content = generate_dockerfile(result)
    dockerignore_content = generate_dockerignore(result)
    compose_content = generate_compose(result) if compose else None

    # -- Dry run: just print and exit --
    if dry_run:
        typer.echo(bold("  --- Dockerfile ---"))
        typer.echo()
        typer.echo(dockerfile_content)

        typer.echo(bold("  --- .dockerignore ---"))
        typer.echo()
        typer.echo(dockerignore_content)

        if compose_content:
            typer.echo(bold("  --- docker-compose.yml ---"))
            typer.echo()
            typer.echo(compose_content)

        raise typer.Exit(code=0)

    # -- Safety: check for existing Dockerfile --
    dockerfile_path = os.path.join(project_path, "Dockerfile")
    if os.path.isfile(dockerfile_path) and not force:
        typer.echo(yellow("  A Dockerfile already exists in this project."))
        if not confirm("  Overwrite?"):
            typer.echo(dim("  Aborted."))
            raise typer.Exit(code=0)

    # -- Write files --
    files_written: list[str] = []

    write_file(dockerfile_path, dockerfile_content)
    files_written.append("Dockerfile")

    dockerignore_path = os.path.join(project_path, ".dockerignore")
    if not os.path.isfile(dockerignore_path):
        write_file(dockerignore_path, dockerignore_content)
        files_written.append(".dockerignore")
    else:
        typer.echo(dim("  .dockerignore already exists, skipping."))

    if compose_content:
        compose_path = os.path.join(project_path, "docker-compose.yml")
        if os.path.isfile(compose_path) and not force:
            typer.echo(yellow("  docker-compose.yml already exists."))
            if confirm("  Overwrite?"):
                write_file(compose_path, compose_content)
                files_written.append("docker-compose.yml")
            else:
                typer.echo(dim("  Skipped docker-compose.yml."))
        else:
            write_file(compose_path, compose_content)
            files_written.append("docker-compose.yml")

    # -- Summary --
    typer.echo()
    typer.echo(green("  Generated files:"))
    for f in files_written:
        typer.echo(green(f"    - {f}"))
    typer.echo()


# ---------------------------------------------------------------------------
# build
# ---------------------------------------------------------------------------


@app.command()
def build(
    path: str = typer.Argument(
        ".",
        help="Path to the project directory containing the Dockerfile.",
    ),
    tag: str = typer.Option(
        "dockermind-app",
        "--tag", "-t",
        help="Docker image tag.",
    ),
) -> None:
    """Build a Docker image from the project's Dockerfile."""
    _banner()

    project_path = os.path.abspath(path)
    dockerfile = os.path.join(project_path, "Dockerfile")

    if not os.path.isfile(dockerfile):
        typer.echo(red("  Dockerfile not found. Run 'dockermind init' first."))
        raise typer.Exit(code=1)

    success = docker_build(project_path, tag=tag)
    raise typer.Exit(code=0 if success else 1)


# ---------------------------------------------------------------------------
# run
# ---------------------------------------------------------------------------


@app.command()
def run(
    tag: str = typer.Option(
        "dockermind-app",
        "--tag", "-t",
        help="Docker image tag to run.",
    ),
    port: int = typer.Option(
        3000,
        "--port", "-p",
        help="Port to map (host:container).",
    ),
    detach: bool = typer.Option(
        False,
        "--detach", "-d",
        help="Run container in background.",
    ),
) -> None:
    """Run a Docker container from a built image."""
    _banner()
    success = docker_run(tag=tag, port=port, detach=detach)
    raise typer.Exit(code=0 if success else 1)


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------


@app.command()
def doctor() -> None:
    """Check that Docker is installed and running."""
    _banner()
    ok = run_doctor()
    raise typer.Exit(code=0 if ok else 1)


# ---------------------------------------------------------------------------
# version
# ---------------------------------------------------------------------------


@app.command()
def version() -> None:
    """Show dockermind version."""
    typer.echo(f"dockermind v{__version__}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


if __name__ == "__main__":
    app()
