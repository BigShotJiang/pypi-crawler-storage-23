"""
Project analyzer -- detects project type, framework, version, port, and scripts.

Only Node.js and Python are supported in v1.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field

from dockermind.utils import file_exists, read_file, extract_port_from_source, yellow


# ---------------------------------------------------------------------------
# Analysis result dataclass
# ---------------------------------------------------------------------------


@dataclass
class AnalysisResult:
    """Everything dockermind needs to know about the target project."""

    # Core detection
    language: str | None = None          # "node" | "python" | None
    framework: str | None = None         # "express" | "fastapi" | "flask" | None

    # Runtime version
    node_version: str = "18"             # Default Node version
    python_version: str = "3.11"         # Default Python version

    # Scripts (Node)
    has_build_script: bool = False
    build_script: str | None = None
    start_script: str | None = None

    # Entry point (Python)
    python_entry_module: str | None = None  # e.g. "main:app"
    uses_uvicorn: bool = False

    # Port
    port: int | None = None
    port_is_default: bool = False        # True if we fell back to a default

    # Package manager
    has_package_lock: bool = False
    has_yarn_lock: bool = False
    has_pnpm_lock: bool = False

    # Raw Python dependency names (lowercase) for native-package inference
    python_deps: set[str] = field(default_factory=set)

    # Warnings generated during analysis
    warnings: list[str] = field(default_factory=list)

    @property
    def runtime_version(self) -> str:
        """Return the resolved runtime version string."""
        if self.language == "node":
            return self.node_version
        return self.python_version


# ---------------------------------------------------------------------------
# Analyzer
# ---------------------------------------------------------------------------


class Analyzer:
    """Analyse a project directory and return an AnalysisResult."""

    def __init__(self, project_path: str) -> None:
        if not os.path.isdir(project_path):
            raise FileNotFoundError(f"Project path does not exist: {project_path}")
        self.path = project_path

    def run(self) -> AnalysisResult:
        """Run full analysis pipeline and return the result."""
        result = AnalysisResult()

        has_node = file_exists(self.path, "package.json")
        has_python = (
            file_exists(self.path, "requirements.txt")
            or file_exists(self.path, "pyproject.toml")
        )

        # Language detection -- only one allowed
        if has_node and has_python:
            # Hard stop: ambiguous multi-runtime projects are not supported.
            raise SystemExit(
                "Error: Multiple backend runtimes detected (Node.js and Python).\n"
                "Please run dockermind inside the specific service directory."
            )

        if has_node:
            result.language = "node"
            self._analyse_node(result)
        elif has_python:
            result.language = "python"
            self._analyse_python(result)
        else:
            # Unsupported or empty project
            result.language = None

        return result

    # ------------------------------------------------------------------
    # Node.js analysis
    # ------------------------------------------------------------------

    def _analyse_node(self, result: AnalysisResult) -> None:
        """Populate *result* with Node.js-specific details."""
        raw = read_file(self.path, "package.json")
        if not raw:
            result.warnings.append("package.json exists but could not be read.")
            return

        try:
            pkg = json.loads(raw)
        except json.JSONDecodeError:
            result.warnings.append("package.json is not valid JSON.")
            return

        # -- Node version from engines field --
        engines = pkg.get("engines", {})
        requested_version = engines.get("node", "")
        if requested_version:
            result.node_version = self._parse_node_version(requested_version)
        # else: stays at default "18"

        # -- Scripts --
        scripts = pkg.get("scripts", {})
        if "build" in scripts:
            result.has_build_script = True
            result.build_script = scripts["build"]
        result.start_script = scripts.get("start")

        # -- Framework detection --
        all_deps = {
            **pkg.get("dependencies", {}),
            **pkg.get("devDependencies", {}),
        }
        if "express" in all_deps:
            result.framework = "express"
        elif "fastify" in all_deps:
            result.framework = "fastify"
        elif "koa" in all_deps:
            result.framework = "koa"
        # For v1 we just note whatever framework; Dockerfile is the same.

        # -- Lock file detection --
        result.has_package_lock = file_exists(self.path, "package-lock.json")
        result.has_yarn_lock = file_exists(self.path, "yarn.lock")
        result.has_pnpm_lock = file_exists(self.path, "pnpm-lock.yaml")

        # -- Port detection --
        result.port = self._detect_node_port(pkg)
        if result.port is None:
            result.port = 3000
            result.port_is_default = True
            result.warnings.append(
                "Could not detect port from source. Defaulting to 3000."
            )

    def _parse_node_version(self, version_spec: str) -> str:
        """Extract a major version number from an engines.node specifier.

        Examples:
            ">=18"          -> "18"
            "^20.0.0"       -> "20"
            "18.x"          -> "18"
            ">=18 <22"      -> "18"
        """
        match = re.search(r"(\d{1,3})", version_spec)
        if match:
            return match.group(1)
        return "18"  # safe fallback

    def _detect_node_port(self, pkg: dict) -> int | None:
        """Try to detect port from source files or scripts."""
        # Check common entry points for .listen(PORT)
        candidates = ["server.js", "index.js", "app.js", "src/index.js", "src/server.js",
                       "src/app.js", "dist/index.js", "server.ts", "index.ts", "src/index.ts"]

        for filename in candidates:
            source = read_file(self.path, filename)
            if source:
                port = extract_port_from_source(source)
                if port:
                    return port

        return None

    # ------------------------------------------------------------------
    # Python analysis
    # ------------------------------------------------------------------

    def _analyse_python(self, result: AnalysisResult) -> None:
        """Populate *result* with Python-specific details."""

        # Gather all dependency names
        deps_lower: set[str] = set()

        # From requirements.txt
        reqs = read_file(self.path, "requirements.txt")
        if reqs:
            for line in reqs.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                # "fastapi==0.100.0" -> "fastapi"
                dep_name = re.split(r"[>=<!~\[]", line)[0].strip().lower()
                if dep_name:
                    deps_lower.add(dep_name)

        # From pyproject.toml (simple parse -- no toml library needed for v1)
        pyproject = read_file(self.path, "pyproject.toml")
        if pyproject:
            # Quick regex extraction for dependencies list
            for match in re.finditer(r'"([a-zA-Z0-9_-]+)', pyproject):
                deps_lower.add(match.group(1).lower())

        # Expose raw deps for native-package inference in dockerfile_generator
        result.python_deps = deps_lower

        # -- Framework detection --
        if "fastapi" in deps_lower:
            result.framework = "fastapi"
            result.port = 8000
        elif "flask" in deps_lower:
            result.framework = "flask"
            result.port = 5000
        else:
            # Unknown Python framework -- set a sensible default
            result.framework = None
            result.port = 8000
            result.warnings.append(
                "No recognised framework (FastAPI/Flask). Defaulting to port 8000."
            )

        # -- Uvicorn detection --
        if "uvicorn" in deps_lower:
            result.uses_uvicorn = True

        # -- Detect entry module --
        result.python_entry_module = self._detect_python_entry(result)

        # -- Python version from pyproject.toml requires-python --
        if pyproject:
            match = re.search(r'requires-python\s*=\s*["\']([^"\']+)["\']', pyproject)
            if match:
                ver_match = re.search(r"(\d+\.\d+)", match.group(1))
                if ver_match:
                    result.python_version = ver_match.group(1)

    def _detect_python_entry(self, result: AnalysisResult) -> str | None:
        """Detect the Python entry module (e.g. 'main:app')."""

        # Look for common entry files
        candidates = ["main.py", "app.py", "application.py", "server.py",
                       "src/main.py", "src/app.py"]

        for filename in candidates:
            source = read_file(self.path, filename)
            if source is None:
                continue

            # Look for FastAPI() or Flask() app instantiation
            app_match = re.search(
                r"(\w+)\s*=\s*(?:FastAPI|Flask)\s*\(", source
            )
            if app_match:
                app_var = app_match.group(1)
                module_name = filename.replace("/", ".").replace(".py", "")
                return f"{module_name}:{app_var}"

        # Fallback: if main.py exists, assume main:app
        if file_exists(self.path, "main.py"):
            return "main:app"
        if file_exists(self.path, "app.py"):
            return "app:app"

        return None
