"""
Docker Compose generator -- produces docker-compose.yml content from AnalysisResult.

Only generated when the user explicitly requests it via ``dockermind init --compose``.
"""

from __future__ import annotations

from dockermind.analyzer import AnalysisResult


def generate_compose(analysis: AnalysisResult, service_name: str = "app") -> str:
    """Return docker-compose.yml content as a string.

    Includes:
      - restart: unless-stopped
      - correct port mapping
      - env_file support
    """
    port = analysis.port or (3000 if analysis.language == "node" else 8000)

    lines = [
        "services:",
        f"  {service_name}:",
        "    build:",
        "      context: .",
        "      dockerfile: Dockerfile",
        f"    ports:",
        f'      - "{port}:{port}"',
        "    restart: unless-stopped",
        "    env_file:",
        "      - .env",
    ]

    # Add environment section with common variables
    lines += [
        "    environment:",
        "      - NODE_ENV=production" if analysis.language == "node" else "      - PYTHONUNBUFFERED=1",
    ]

    lines.append("")

    return "\n".join(lines)
