"""
Dockerfile generator -- produces optimised Dockerfile content from an AnalysisResult.

Rules (v1):
  - Node with build script  -> multi-stage (builder + runtime)
  - Node without build      -> single-stage
  - Python                  -> single-stage with pip install
  - Never use Alpine images -- always -slim (Debian bookworm)
"""

from __future__ import annotations

from dockermind.analyzer import AnalysisResult


def generate_dockerfile(analysis: AnalysisResult) -> str:
    """Return the full Dockerfile content as a string."""
    if analysis.language == "node":
        return _generate_node(analysis)
    elif analysis.language == "python":
        return _generate_python(analysis)
    else:
        raise ValueError(f"Unsupported language: {analysis.language}")


def generate_dockerignore(analysis: AnalysisResult) -> str:
    """Return .dockerignore content appropriate for the project."""
    if analysis.language == "node":
        return _node_dockerignore()
    elif analysis.language == "python":
        return _python_dockerignore()
    return _generic_dockerignore()


# ---------------------------------------------------------------------------
# Node.js Dockerfile generation
# ---------------------------------------------------------------------------


def _generate_node(analysis: AnalysisResult) -> str:
    """Generate a Node.js Dockerfile.

    Multi-stage when a build script exists; single-stage otherwise.
    """
    version = analysis.node_version
    base_image = f"node:{version}-slim"

    # Determine install command based on lock file
    install_cmd = _node_install_cmd(analysis)
    install_cmd_prod = _node_install_cmd(analysis, production=True)

    # Determine the CMD
    start_cmd = _node_start_cmd(analysis)

    port = analysis.port or 3000

    if analysis.has_build_script:
        return _node_multistage(
            base_image=base_image,
            install_cmd=install_cmd,
            install_cmd_prod=install_cmd_prod,
            build_script=analysis.build_script or "npm run build",
            start_cmd=start_cmd,
            port=port,
        )
    else:
        return _node_singlestage(
            base_image=base_image,
            install_cmd=install_cmd_prod,
            start_cmd=start_cmd,
            port=port,
        )


def _node_multistage(
    *,
    base_image: str,
    install_cmd: str,
    install_cmd_prod: str,
    build_script: str,
    start_cmd: str,
    port: int,
) -> str:
    """Multi-stage Node.js Dockerfile (build + runtime)."""

    # Determine run build command
    if "pnpm" in install_cmd:
        run_build = "pnpm run build"
    elif "yarn" in install_cmd:
        run_build = "yarn build"
    else:
        run_build = "npm run build"

    lines = [
        f"# ---- Stage 1: Build ----",
        f"FROM {base_image} AS builder",
        "",
        "WORKDIR /app",
        "",
        "# Copy dependency manifests first for better layer caching",
        "COPY package*.json ./",
    ]

    # Copy lock files based on what exists
    if "pnpm" in install_cmd:
        lines.append("COPY pnpm-lock.yaml ./")
    elif "yarn" in install_cmd:
        lines.append("COPY yarn.lock ./")

    lines += [
        "",
        f"RUN {install_cmd}",
        "",
        "# Copy source code and build",
        "COPY . .",
        f"RUN {run_build}",
        "",
        f"# ---- Stage 2: Production ----",
        f"FROM {base_image}",
        "",
        "WORKDIR /app",
        "",
        "# Copy dependency manifests",
        "COPY package*.json ./",
    ]

    if "pnpm" in install_cmd_prod:
        lines.append("COPY pnpm-lock.yaml ./")
    elif "yarn" in install_cmd_prod:
        lines.append("COPY yarn.lock ./")

    lines += [
        "",
        f"# Install production dependencies only",
        f"RUN {install_cmd_prod}",
        "",
        "# Copy built output from builder stage",
        "COPY --from=builder /app/dist ./dist",
        "",
        f"EXPOSE {port}",
        "",
        f'CMD {start_cmd}',
        "",
    ]

    return "\n".join(lines)


def _node_singlestage(
    *,
    base_image: str,
    install_cmd: str,
    start_cmd: str,
    port: int,
) -> str:
    """Single-stage Node.js Dockerfile (no build step)."""
    lines = [
        f"FROM {base_image}",
        "",
        "WORKDIR /app",
        "",
        "# Copy dependency manifests first for better layer caching",
        "COPY package*.json ./",
    ]

    if "pnpm" in install_cmd:
        lines.append("COPY pnpm-lock.yaml ./")
    elif "yarn" in install_cmd:
        lines.append("COPY yarn.lock ./")

    lines += [
        "",
        f"RUN {install_cmd}",
        "",
        "# Copy application source",
        "COPY . .",
        "",
        f"EXPOSE {port}",
        "",
        f'CMD {start_cmd}',
        "",
    ]

    return "\n".join(lines)


def _node_install_cmd(analysis: AnalysisResult, *, production: bool = False) -> str:
    """Return the appropriate npm/yarn/pnpm install command."""
    if analysis.has_pnpm_lock:
        # pnpm requires corepack or global install; keep it simple
        base = "corepack enable && pnpm install"
        if production:
            return base + " --prod"
        return base + " --frozen-lockfile"

    if analysis.has_yarn_lock:
        if production:
            return "yarn install --production --frozen-lockfile"
        return "yarn install --frozen-lockfile"

    # Default: npm
    if production:
        return "npm ci --omit=dev"
    return "npm ci"


def _node_start_cmd(analysis: AnalysisResult) -> str:
    """Determine the CMD instruction for a Node project."""
    if analysis.start_script:
        script = analysis.start_script.strip()

        # If the start script begins with "node", extract the entry file safely.
        if script.startswith("node "):
            try:
                # Use shlex-style split to handle paths with spaces / flags.
                parts = script.split()
                # parts[0] == "node", parts[1:] are args.
                if len(parts) >= 2:
                    entry_file = parts[1].strip()
                    if entry_file:
                        return f'["node", "{entry_file}"]'
            except (IndexError, ValueError):
                pass  # fall through to package-manager start below

        # Otherwise wrap in npm/yarn/pnpm start
        if analysis.has_pnpm_lock:
            return '["pnpm", "start"]'
        if analysis.has_yarn_lock:
            return '["yarn", "start"]'
        return '["npm", "start"]'

    # No start script -- try common entry files
    return '["node", "index.js"]'


# ---------------------------------------------------------------------------
# Python Dockerfile generation
# ---------------------------------------------------------------------------


def _infer_system_packages(analysis: AnalysisResult) -> list[str]:
    """Return a list of apt packages required by detected Python dependencies."""
    mapping: dict[str, str] = {
        "psycopg2": "libpq-dev",
        "pillow": "libjpeg-dev",
        "lxml": "libxml2-dev",
        "numpy": "build-essential",
    }
    packages: list[str] = []
    deps = analysis.python_deps
    for dep_substring, apt_pkg in mapping.items():
        if any(dep_substring in d for d in deps) and apt_pkg not in packages:
            packages.append(apt_pkg)
    return sorted(packages)


def _generate_python(analysis: AnalysisResult) -> str:
    """Generate a Python Dockerfile (always single-stage)."""
    version = analysis.python_version
    base_image = f"python:{version}-slim"
    port = analysis.port or 8000

    cmd = _python_cmd(analysis, port)
    system_packages = _infer_system_packages(analysis)

    lines = [
        f"FROM {base_image}",
        "",
        "# Prevent Python from writing .pyc files and enable unbuffered output",
        "ENV PYTHONDONTWRITEBYTECODE=1",
        "ENV PYTHONUNBUFFERED=1",
        "",
        "WORKDIR /app",
        "",
    ]

    # Install system-level native dependencies if needed
    if system_packages:
        pkg_list = " ".join(system_packages)
        lines += [
            "# Install native build dependencies",
            "RUN apt-get update && \\",
            f"    apt-get install -y {pkg_list} && \\",
            "    rm -rf /var/lib/apt/lists/*",
            "",
        ]

    lines += [
        "# Install dependencies first for better layer caching",
        "COPY requirements.txt ./",
        "RUN pip install --no-cache-dir -r requirements.txt",
        "",
        "# Copy application source",
        "COPY . .",
        "",
        f"EXPOSE {port}",
        "",
        f'CMD {cmd}',
        "",
    ]

    return "\n".join(lines)


def _python_cmd(analysis: AnalysisResult, port: int) -> str:
    """Determine the CMD instruction for a Python project."""
    entry = analysis.python_entry_module or "main:app"

    if analysis.uses_uvicorn or analysis.framework == "fastapi":
        return f'["uvicorn", "{entry}", "--host", "0.0.0.0", "--port", "{port}"]'

    if analysis.framework == "flask":
        # For Flask, use flask run with proper host/port binding
        module = entry.split(":")[0] if ":" in entry else "app"
        return (
            f'["flask", "run", "--host", "0.0.0.0", "--port", "{port}"]'
        )

    # Generic fallback
    return f'["python", "-m", "{entry.split(":")[0] if ":" in entry else entry}"]'


# ---------------------------------------------------------------------------
# .dockerignore content
# ---------------------------------------------------------------------------


def _node_dockerignore() -> str:
    return """\
node_modules
npm-debug.log*
.git
.gitignore
.dockerignore
Dockerfile
docker-compose*.yml
.env
.env.*
.vscode
.idea
coverage
.nyc_output
dist
build
*.md
LICENSE
"""


def _python_dockerignore() -> str:
    return """\
__pycache__
*.pyc
*.pyo
.git
.gitignore
.dockerignore
Dockerfile
docker-compose*.yml
.env
.env.*
.vscode
.idea
.venv
venv
.tox
.pytest_cache
*.egg-info
dist
build
*.md
LICENSE
"""


def _generic_dockerignore() -> str:
    return """\
.git
.gitignore
.dockerignore
Dockerfile
docker-compose*.yml
.env
.env.*
.vscode
.idea
*.md
LICENSE
"""
