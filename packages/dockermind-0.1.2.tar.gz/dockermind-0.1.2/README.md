# Dockermind

> Smart Dockerfile generation CLI for Node.js and Python projects.

## Overview

Dockermind analyses a project (Node.js or Python), infers the runtime and framework, and generates production-optimised Dockerfile and .dockerignore (optionally a docker-compose.yml). It also provides a small CLI to build and run the resulting image and a doctor command to validate the local Docker environment.

This repository contains a Next.js frontend (in the `app/` and `components/` folders) and the `dockermind` Python package that implements analysis and generation logic.

## Requirements

- Python 3.10 or newer (the package declares `requires-python = ">=3.10"`)
- Docker (for `dockermind build`, `dockermind run` and to validate with `dockermind doctor`)
- Node.js (for the Next.js frontend; development and build use the `next` CLI)

When running commands below, ensure you are in the repository root.

## Node / Frontend commands (npm scripts)

The repository defines the following npm scripts in `package.json`. These are the standard Next.js scripts and an ESLint target.

- `npm run dev` (alias: `pnpm dev` / `yarn dev`) — Runs `next dev`.
  - What it does: starts the Next.js development server. The server serves the app in development mode, enables fast refresh, and rebuilds pages on change. Default listening port is 3000 unless overridden by environment variables.

- `npm run build` — Runs `next build`.
  - What it does: produces a production build for Next.js, compiling pages and assets into the `.next` directory. Run this before `npm run start` for production usage.

- `npm run start` — Runs `next start`.
  - What it does: launches the Next.js production server that serves the contents of the `.next` build directory. Requires a successful `npm run build` beforehand.

- `npm run lint` — Runs `eslint .`.
  - What it does: runs ESLint across the repository (the configuration and rules are determined by the repo). Use this to detect and fix lint issues.

Notes:

- Use your preferred package manager. The repository contains a `pnpm-lock.yaml` file; if you use pnpm prefer `pnpm install`. Otherwise `npm ci` or `npm install` will work for npm users.

## Python / Dockermind CLI

The Python package is configured in `pyproject.toml`. It exposes a console entry point named `dockermind` (see `[project.scripts]`). After installing the package, the `dockermind` command will be available.

Installation (editable/development install):

```bash
python -m pip install -e .
```

What that does: installs the package in editable mode and registers the `dockermind` CLI entry point. You can then run the CLI from the repository root.

Available CLI commands (usage: `dockermind <command> [options]`):

- `dockermind init [path] [--compose] [--dry-run] [--force]`
  - What it does: Analyses the project at `path` (defaults to `.`) to detect whether the project is Node.js or Python, determines framework, ports, and build/start steps, then generates a Dockerfile and `.dockerignore`. If `--compose` is specified it also generates a `docker-compose.yml`. `--dry-run` prints generated files to the console without writing them. Without `--force`, the command will prompt before overwriting an existing Dockerfile.

- `dockermind build [path] [--tag <tag>]`
  - What it does: Runs `docker build` using the `Dockerfile` in `path` (defaults to `.`). The `--tag` (`-t`) option sets the image name (default `dockermind-app`). The command streams `docker build` output to the terminal and returns a non-zero exit code on failure.

- `dockermind run [--tag <tag>] [--port <port>] [--detach]`
  - What it does: Runs a Docker container from an image built by `dockermind build`. The command maps host port to container port as `port:port` and runs the container in foreground by default. Use `--detach` (`-d`) to run in background. The command checks if the selected port appears in use and warns if so.

- `dockermind doctor`
  - What it does: Verifies that Docker is installed and that the Docker daemon is running. Also checks for Docker Compose and prints helpful messages and next steps. Returns a non-zero exit code if checks fail.

- `dockermind version`
  - What it does: Prints the installed dockermind package version.

You can also invoke the CLI directly (without installing) with:

```bash
python -m dockermind.cli init --dry-run
```

This runs the `init` command using the local source tree without installing the package.

## Test and helper scripts

- `scripts/run_tests.py` — Self-contained smoke tests.
  - What it does: creates a temporary copy of the `dockermind` package inside `/tmp`, imports it and runs a suite of smoke tests that exercise analysis, Dockerfile generation and compose generation for representative Node.js and Python fixtures. The script prints pass/fail results and exits with non-zero status if any tests fail. It is intended as an on-host smoke test and may assume a POSIX environment (it uses `/tmp`).

- `scripts/run_tests.sh` — Simple shell wrapper for tests.
  - What it does: installs minimal Python dependencies if needed and then runs the repo test harness under a specific path used by some CI environments.

Notes about tests: the tests in `scripts/run_tests.py` are not a replacement for a full test suite. They are smoke tests that exercise the core behaviour of the analysis and generation modules.

## Docker usage notes

- Generated Dockerfiles attempt to create small, production-ready images. For Node.js projects the generator may use multi-stage builds when a build step is present. For Python projects it will attempt to use `uvicorn` for FastAPI projects or `flask` for Flask projects and will add minimal system packages when native dependencies are detected.
- The `dockermind run` and `dockermind build` commands rely on the local Docker CLI and daemon.

## Contributing & Development

- Install Python development dependencies from `pyproject.toml` for tests and linters (e.g. `pytest`, `ruff`, `mypy`).
- Follow the linting and type checks present in the repo. Use `npm run lint` for JavaScript/TypeScript code quality checks.

## Developer Contact

- GitHub: https://github.com/Aakashsingh0388
- LinkedIn: https://www.linkedin.com/in/aakash-singh-7b8416318/

If you need further details about the project or help building images, please open an issue on GitHub or contact the developer directly via LinkedIn.

## License

This project is provided under the MIT License (see `dockermind.egg-info` for packaged metadata).
