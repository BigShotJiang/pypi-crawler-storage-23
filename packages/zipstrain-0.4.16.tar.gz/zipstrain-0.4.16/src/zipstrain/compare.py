"""zipstrain.compare
========================
This module provides all comparison functions for zipstrain.

"""

from __future__ import annotations

import pathlib
import tempfile

import polars as pl

try:
    import duckdb
except ImportError:  # pragma: no cover - dependency optional at import time
    duckdb = None

class PolarsANIExpressions:
    """ 
    Any kind of ANI calculation based on two profiles should be implemented as a method of this class.
    In defining this method, the following rules should be followed:
    
    -   The method returns a Polars expression (pl.Expr).
    
    -   When applied to a row, the method returns a zero if that position is a SNV. Otherwise it should return a number greater than zero.
    
    -   A, T, C, G columns in the first profile are named "A", "T", "C", "G" and in the second profile they are named "A_2", "T_2", "C_2", "G_2".
    
    1. popani: Population ANI based on the shared alleles between two profiles.
    2. conani: Consensus ANI based on the consensus alleles between two profiles.
    3. cosani_<threshold>: Generalized cosine similarity ANI where threshold is a float value between 0 and 1. Once the similarity is below the threshold, it is considered a SNV.
    """
    MPILE_1_BASES = ["A", "T", "C", "G"]
    MPILE_2_BASES = ["A_2", "T_2", "C_2", "G_2"]

    def popani(self):
        return pl.col("A")*pl.col("A_2") + pl.col("C")*pl.col("C_2") + pl.col("G")*pl.col("G_2") + pl.col("T")*pl.col("T_2")
    
    def conani(self):
        max_base_1=pl.max_horizontal(*[pl.col(base) for base in self.MPILE_1_BASES])
        max_base_2=pl.max_horizontal(*[pl.col(base) for base in self.MPILE_2_BASES])
        return pl.when((pl.col("A")==max_base_1) & (pl.col("A_2")==max_base_2) | 
                       (pl.col("T")==max_base_1) & (pl.col("T_2")==max_base_2) | 
                       (pl.col("C")==max_base_1) & (pl.col("C_2")==max_base_2) | 
                       (pl.col("G")==max_base_1) & (pl.col("G_2")==max_base_2)).then(1).otherwise(0)
    
    def generalized_cos_ani(self,threshold:float=0.4):
        dot_product = pl.col("A")*pl.col("A_2") + pl.col("C")*pl.col("C_2") + pl.col("G")*pl.col("G_2") + pl.col("T")*pl.col("T_2")
        magnitude_1 = (pl.col("A")**2 + pl.col("C")**2 + pl.col("G")**2 + pl.col("T")**2)**0.5
        magnitude_2 = (pl.col("A_2")**2 + pl.col("C_2")**2 + pl.col("G_2")**2 + pl.col("T_2")**2)**0.5
        cos_sim = dot_product / (magnitude_1 * magnitude_2)
        return pl.when(cos_sim >= threshold).then(1).otherwise(0)

    def __getattribute__(self, name):
        if name.startswith("cosani_"):
            try:
                threshold = float(name.split("_")[1])
            except ValueError:
                raise AttributeError(f"Invalid threshold in method name: {name}")
            return lambda: self.generalized_cos_ani(threshold)
        else:
            return super().__getattribute__(name)


def _validate_compare_engine(compare_engine: str) -> str:
    compare_engine = str(compare_engine).lower()
    if compare_engine not in {"duckdb", "polars"}:
        raise ValueError("Invalid compare_engine. Choose either 'duckdb' or 'polars'.")
    return compare_engine


def _validate_ani_method(ani_method: str) -> None:
    if ani_method in {"popani", "conani"}:
        return
    if ani_method.startswith("cosani_"):
        try:
            float(ani_method.split("_")[1])
        except ValueError as exc:
            raise ValueError(f"Invalid ANI method: {ani_method}") from exc
        return
    raise ValueError(f"Invalid ANI method: {ani_method}")


def _require_duckdb():
    if duckdb is None:
        raise ImportError(
            "DuckDB compare engine requested but 'duckdb' is not installed. "
            "Install the package or use compare_engine='polars'."
        )
    return duckdb


def _quote_path(path: pathlib.Path) -> str:
    return str(path).replace("'", "''")


def _copy_query_to_parquet(conn, query: str, output_path: pathlib.Path) -> None:
    conn.execute(
        f"COPY ({query}) TO '{_quote_path(output_path)}' "
        "(FORMAT PARQUET, COMPRESSION ZSTD)"
    )


def _quote_literal(value: str) -> str:
    return value.replace("'", "''")


def _duckdb_relation_has_column(conn, parquet_path: pathlib.Path, column_name: str) -> bool:
    column_name = column_name.lower()
    columns = {
        row[0].lower()
        for row in conn.execute(
            f"DESCRIBE SELECT * FROM read_parquet('{_quote_path(parquet_path)}')"
        ).fetchall()
    }
    return column_name in columns


def _duckdb_filtered_profile_query(
    parquet_path: pathlib.Path,
    alias: str,
    min_cov: int,
    has_genome_col: bool,
    extra_filters: list[str] | None = None,
    gene_scope: str | None = None,
) -> str:
    from_clause = f"read_parquet('{_quote_path(parquet_path)}') AS {alias}"
    if has_genome_col:
        genome_expr = f"{alias}.genome"
    else:
        from_clause += f" LEFT JOIN stb_map ON {alias}.chrom = stb_map.scaffold"
        genome_expr = "COALESCE(stb_map.genome, 'NA')"

    filters = [f"({alias}.A + {alias}.C + {alias}.G + {alias}.T) >= {int(min_cov)}"]
    if extra_filters:
        filters.extend(extra_filters)
    if gene_scope is not None:
        filters.append(f"{alias}.gene = '{_quote_literal(gene_scope)}'")

    where_clause = " AND ".join(filters)
    return f"""
        SELECT
            {alias}.chrom AS chrom,
            {alias}.pos AS pos,
            {alias}.gene AS gene,
            {alias}.A AS A,
            {alias}.T AS T,
            {alias}.C AS C,
            {alias}.G AS G,
            {genome_expr} AS genome
        FROM {from_clause}
        WHERE {where_clause}
        ORDER BY {alias}.chrom, {alias}.pos
    """


def _empty_genome_compare_frame() -> pl.LazyFrame:
    return pl.DataFrame(
        schema={
            "genome": pl.String,
            "total_positions": pl.Int64,
            "share_allele_pos": pl.Int64,
            "genome_pop_ani": pl.Float64,
            "max_consecutive_length": pl.Int64,
            "shared_genes_count": pl.Int64,
            "identical_gene_count": pl.Int64,
            "perc_id_genes": pl.Float64,
        }
    ).lazy()


def _empty_gene_compare_frame() -> pl.LazyFrame:
    return pl.DataFrame(
        schema={
            "genome": pl.String,
            "gene": pl.String,
            "total_positions": pl.Int64,
            "share_allele_pos": pl.Int64,
            "ani": pl.Float64,
        }
    ).lazy()


def _ensure_genome_column(
    mpile_contig: pl.LazyFrame,
    scaffold_to_genome: pl.LazyFrame | None,
) -> pl.LazyFrame:
    schema_names = mpile_contig.collect_schema().names()
    if "genome" in schema_names:
        return mpile_contig
    if scaffold_to_genome is None:
        raise ValueError(
            "Input profile does not have a 'genome' column and scaffold_to_genome was not provided."
        )

    return mpile_contig.join(
        scaffold_to_genome.select(["scaffold", "genome"]),
        left_on="chrom",
        right_on="scaffold",
        how="left",
    ).with_columns(pl.col("genome").fill_null("NA"))


def _prepare_frame(
    mpile_contig: pl.LazyFrame,
    min_cov: int,
    engine: str,
    scaffold_to_genome: pl.LazyFrame | None,
    scaffold_scope: list | None = None,
) -> pl.LazyFrame:
    if scaffold_scope is not None:
        mpile_contig = mpile_contig.filter(pl.col("chrom").is_in(scaffold_scope))
    mpile_contig = _ensure_genome_column(mpile_contig, scaffold_to_genome)
    mpile_contig = coverage_filter(mpile_contig, min_cov, engine=engine)
    return mpile_contig.set_sorted(["chrom", "pos"], descending=[False, False])


def _duckdb_ani_expression(ani_method: str, left_alias: str = "p1", right_alias: str = "p2") -> str:
    _validate_ani_method(ani_method)
    l = left_alias
    r = right_alias

    a1 = f"CAST({l}.A AS DOUBLE)"
    t1 = f"CAST({l}.T AS DOUBLE)"
    c1 = f"CAST({l}.C AS DOUBLE)"
    g1 = f"CAST({l}.G AS DOUBLE)"
    a2 = f"CAST({r}.A AS DOUBLE)"
    t2 = f"CAST({r}.T AS DOUBLE)"
    c2 = f"CAST({r}.C AS DOUBLE)"
    g2 = f"CAST({r}.G AS DOUBLE)"

    dot_product = (
        f"({a1} * {a2} + {c1} * {c2} + {g1} * {g2} + {t1} * {t2})"
    )
    if ani_method == "popani":
        return dot_product

    max_1 = f"GREATEST({a1}, {t1}, {c1}, {g1})"
    max_2 = f"GREATEST({a2}, {t2}, {c2}, {g2})"
    if ani_method == "conani":
        return (
            "CASE WHEN ("
            f"({a1} = {max_1} AND {a2} = {max_2}) OR "
            f"({t1} = {max_1} AND {t2} = {max_2}) OR "
            f"({c1} = {max_1} AND {c2} = {max_2}) OR "
            f"({g1} = {max_1} AND {g2} = {max_2})"
            ") THEN 1 ELSE 0 END"
        )

    threshold = float(ani_method.split("_")[1])
    magnitude_1 = f"SQRT(POWER({a1}, 2) + POWER({c1}, 2) + POWER({g1}, 2) + POWER({t1}, 2))"
    magnitude_2 = f"SQRT(POWER({a2}, 2) + POWER({c2}, 2) + POWER({g2}, 2) + POWER({t2}, 2))"
    cosine_similarity = f"{dot_product} / NULLIF(({magnitude_1}) * ({magnitude_2}), 0)"
    return f"CASE WHEN {cosine_similarity} >= {threshold:.17g} THEN 1 ELSE 0 END"


def _compare_genomes_polars(
    mpile_contig_1: pl.LazyFrame,
    mpile_contig_2: pl.LazyFrame,
    min_cov: int,
    min_gene_compare_len: int,
    memory_mode: str,
    chrom_batch_size: int,
    shared_scaffolds: list | None,
    scaffold_scope: list | None,
    engine: str,
    ani_method: str,
    scaffold_to_genome: pl.LazyFrame | None,
) -> pl.LazyFrame:
    if memory_mode == "heavy":
        lf1 = _prepare_frame(
            mpile_contig=mpile_contig_1,
            min_cov=min_cov,
            engine=engine,
            scaffold_to_genome=scaffold_to_genome,
            scaffold_scope=scaffold_scope,
        )
        lf2 = _prepare_frame(
            mpile_contig=mpile_contig_2,
            min_cov=min_cov,
            engine=engine,
            scaffold_to_genome=scaffold_to_genome,
            scaffold_scope=scaffold_scope,
        )
        lf = get_shared_locs(lf1, lf2, ani_method=ani_method)
        lf = add_contiguity_info(lf)
        genome_comp = calculate_pop_ani(lf)
        max_consecutive_per_genome = get_longest_consecutive_blocks(lf)
        gene = get_gene_ani(lf, min_gene_compare_len)
        genome_comp = genome_comp.join(max_consecutive_per_genome, on="genome", how="left")
        genome_comp = genome_comp.join(gene, on="genome", how="left")
    elif memory_mode == "light":
        if not shared_scaffolds:
            return _empty_genome_compare_frame()
        shared_scaffolds_batches = [
            shared_scaffolds[i:i + chrom_batch_size]
            for i in range(0, len(shared_scaffolds), chrom_batch_size)
        ]
        lf_list = []
        for scaffold in shared_scaffolds_batches:
            lf1 = _prepare_frame(
                mpile_contig=mpile_contig_1.filter(pl.col("chrom").is_in(scaffold)),
                min_cov=min_cov,
                engine=engine,
                scaffold_to_genome=scaffold_to_genome,
                scaffold_scope=scaffold_scope,
            )
            lf2 = _prepare_frame(
                mpile_contig=mpile_contig_2.filter(pl.col("chrom").is_in(scaffold)),
                min_cov=min_cov,
                engine=engine,
                scaffold_to_genome=scaffold_to_genome,
                scaffold_scope=scaffold_scope,
            )
            lf = get_shared_locs(lf1, lf2, ani_method=ani_method)
            lf = add_contiguity_info(lf)
            lf_list.append(lf)
        if not lf_list:
            return _empty_genome_compare_frame()
        lf = pl.concat(lf_list)
        genome_comp = calculate_pop_ani(lf)
        max_consecutive_per_genome = get_longest_consecutive_blocks(lf)
        gene = get_gene_ani(lf, min_gene_compare_len)
        genome_comp = genome_comp.join(max_consecutive_per_genome, on="genome", how="left")
        genome_comp = genome_comp.join(gene, on="genome", how="left")
    else:
        raise ValueError("Invalid memory_mode. Choose either 'heavy' or 'light'.")
    return genome_comp


def _compare_genes_polars(
    mpile_contig_1: pl.LazyFrame,
    mpile_contig_2: pl.LazyFrame,
    min_cov: int,
    min_gene_compare_len: int,
    engine: str,
    ani_method: str,
    scaffold_to_genome: pl.LazyFrame | None,
) -> pl.LazyFrame:
    lf1 = _prepare_frame(
        mpile_contig=mpile_contig_1,
        min_cov=min_cov,
        engine=engine,
        scaffold_to_genome=scaffold_to_genome,
    )
    lf2 = _prepare_frame(
        mpile_contig=mpile_contig_2,
        min_cov=min_cov,
        engine=engine,
        scaffold_to_genome=scaffold_to_genome,
    )
    lf = get_shared_locs(lf1, lf2, ani_method=ani_method)
    gene_comp = (
        lf.group_by(["genome", "gene"])
        .agg(
            total_positions=pl.len(),
            share_allele_pos=(pl.col("surr") > 0).sum(),
        )
        .filter(pl.col("total_positions") >= min_gene_compare_len)
        .with_columns(ani=pl.col("share_allele_pos") / pl.col("total_positions") * 100)
    )
    return gene_comp


def _compare_genomes_duckdb(
    mpile_contig_1: pl.LazyFrame,
    mpile_contig_2: pl.LazyFrame,
    min_cov: int,
    min_gene_compare_len: int,
    memory_mode: str,
    shared_scaffolds: list | None,
    scaffold_scope: list | None,
    engine: str,
    ani_method: str,
    scaffold_to_genome: pl.LazyFrame | None,
) -> pl.LazyFrame:
    _require_duckdb()
    if memory_mode not in {"heavy", "light"}:
        raise ValueError("Invalid memory_mode. Choose either 'heavy' or 'light'.")
    if memory_mode == "light" and not shared_scaffolds:
        return _empty_genome_compare_frame()

    lf1 = mpile_contig_1
    lf2 = mpile_contig_2
    if memory_mode == "light":
        lf1 = lf1.filter(pl.col("chrom").is_in(shared_scaffolds))
        lf2 = lf2.filter(pl.col("chrom").is_in(shared_scaffolds))

    lf1 = _prepare_frame(
        mpile_contig=lf1,
        min_cov=min_cov,
        engine=engine,
        scaffold_to_genome=scaffold_to_genome,
        scaffold_scope=scaffold_scope,
    )
    lf2 = _prepare_frame(
        mpile_contig=lf2,
        min_cov=min_cov,
        engine=engine,
        scaffold_to_genome=scaffold_to_genome,
        scaffold_scope=scaffold_scope,
    )

    with tempfile.TemporaryDirectory(prefix="zipstrain_compare_") as tmp_dir:
        tmp_dir_path = pathlib.Path(tmp_dir)
        lf1_path = tmp_dir_path / "lf1_filtered.parquet"
        lf2_path = tmp_dir_path / "lf2_filtered.parquet"
        shared_path = tmp_dir_path / "shared_locs.parquet"
        contig_path = tmp_dir_path / "contiguous.parquet"
        pop_path = tmp_dir_path / "pop_ani.parquet"
        max_consecutive_path = tmp_dir_path / "max_consecutive.parquet"
        gene_path = tmp_dir_path / "gene_ani.parquet"
        final_path = tmp_dir_path / "genome_compare.parquet"

        lf1.sink_parquet(lf1_path, compression="zstd", engine=engine)
        lf2.sink_parquet(lf2_path, compression="zstd", engine=engine)

        ani_expr = _duckdb_ani_expression(ani_method=ani_method)
        conn = duckdb.connect()
        try:
            conn.execute("SET preserve_insertion_order=true")
            shared_query = f"""
                SELECT
                    {ani_expr} AS surr,
                    p1.chrom AS scaffold,
                    p1.pos AS pos,
                    p1.gene AS gene,
                    p1.genome AS genome
                FROM read_parquet('{_quote_path(lf1_path)}') AS p1
                INNER JOIN read_parquet('{_quote_path(lf2_path)}') AS p2
                    ON p1.chrom = p2.chrom
                   AND p1.pos = p2.pos
                ORDER BY p1.chrom, p1.pos
            """
            _copy_query_to_parquet(conn, shared_query, shared_path)

            contig_query = f"""
                WITH ordered AS (
                    SELECT
                        surr,
                        scaffold,
                        pos,
                        gene,
                        genome,
                        LAG(scaffold, 1, scaffold) OVER (ORDER BY scaffold, pos) AS prev_scaffold
                    FROM read_parquet('{_quote_path(shared_path)}')
                )
                SELECT
                    surr,
                    scaffold,
                    pos,
                    gene,
                    genome,
                    SUM(
                        CASE WHEN scaffold <> prev_scaffold OR surr = 0 THEN 1 ELSE 0 END
                    ) OVER (
                        ORDER BY scaffold, pos
                        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                    ) AS group_id
                FROM ordered
            """
            _copy_query_to_parquet(conn, contig_query, contig_path)

            pop_query = f"""
                SELECT
                    genome,
                    COUNT(*) AS total_positions,
                    SUM(CASE WHEN surr > 0 THEN 1 ELSE 0 END) AS share_allele_pos,
                    SUM(CASE WHEN surr > 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS genome_pop_ani
                FROM read_parquet('{_quote_path(contig_path)}')
                GROUP BY genome
            """
            _copy_query_to_parquet(conn, pop_query, pop_path)

            max_consecutive_query = f"""
                WITH block_lengths AS (
                    SELECT
                        genome,
                        scaffold,
                        group_id,
                        COUNT(*) AS length
                    FROM read_parquet('{_quote_path(contig_path)}')
                    GROUP BY genome, scaffold, group_id
                )
                SELECT
                    genome,
                    MAX(length) AS max_consecutive_length
                FROM block_lengths
                GROUP BY genome
            """
            _copy_query_to_parquet(conn, max_consecutive_query, max_consecutive_path)

            gene_query = f"""
                WITH per_gene AS (
                    SELECT
                        genome,
                        gene,
                        COUNT(*) AS total_positions,
                        SUM(CASE WHEN surr > 0 THEN 1 ELSE 0 END) AS share_allele_pos
                    FROM read_parquet('{_quote_path(contig_path)}')
                    GROUP BY genome, gene
                    HAVING COUNT(*) >= {int(min_gene_compare_len)}
                ),
                filtered AS (
                    SELECT
                        genome,
                        total_positions,
                        share_allele_pos
                    FROM per_gene
                    WHERE gene <> 'NA'
                )
                SELECT
                    genome,
                    COUNT(*) AS shared_genes_count,
                    SUM(CASE WHEN share_allele_pos = total_positions THEN 1 ELSE 0 END) AS identical_gene_count,
                    SUM(CASE WHEN share_allele_pos = total_positions THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS perc_id_genes
                FROM filtered
                GROUP BY genome
            """
            _copy_query_to_parquet(conn, gene_query, gene_path)

            final_query = f"""
                SELECT
                    p.genome,
                    p.total_positions,
                    p.share_allele_pos,
                    p.genome_pop_ani,
                    m.max_consecutive_length,
                    g.shared_genes_count,
                    g.identical_gene_count,
                    g.perc_id_genes
                FROM read_parquet('{_quote_path(pop_path)}') AS p
                LEFT JOIN read_parquet('{_quote_path(max_consecutive_path)}') AS m
                    USING (genome)
                LEFT JOIN read_parquet('{_quote_path(gene_path)}') AS g
                    USING (genome)
            """
            _copy_query_to_parquet(conn, final_query, final_path)
        finally:
            conn.close()
        return pl.read_parquet(final_path).lazy()


def _compare_genes_duckdb(
    mpile_contig_1: pl.LazyFrame,
    mpile_contig_2: pl.LazyFrame,
    min_cov: int,
    min_gene_compare_len: int,
    engine: str,
    ani_method: str,
    scaffold_to_genome: pl.LazyFrame | None,
) -> pl.LazyFrame:
    _require_duckdb()
    lf1 = _prepare_frame(
        mpile_contig=mpile_contig_1,
        min_cov=min_cov,
        engine=engine,
        scaffold_to_genome=scaffold_to_genome,
    )
    lf2 = _prepare_frame(
        mpile_contig=mpile_contig_2,
        min_cov=min_cov,
        engine=engine,
        scaffold_to_genome=scaffold_to_genome,
    )

    with tempfile.TemporaryDirectory(prefix="zipstrain_gene_compare_") as tmp_dir:
        tmp_dir_path = pathlib.Path(tmp_dir)
        lf1_path = tmp_dir_path / "lf1_filtered.parquet"
        lf2_path = tmp_dir_path / "lf2_filtered.parquet"
        shared_path = tmp_dir_path / "shared_locs.parquet"
        final_path = tmp_dir_path / "gene_compare.parquet"

        lf1.sink_parquet(lf1_path, compression="zstd", engine=engine)
        lf2.sink_parquet(lf2_path, compression="zstd", engine=engine)

        ani_expr = _duckdb_ani_expression(ani_method=ani_method)
        conn = duckdb.connect()
        try:
            conn.execute("SET preserve_insertion_order=true")
            shared_query = f"""
                SELECT
                    {ani_expr} AS surr,
                    p1.genome AS genome,
                    p1.gene AS gene
                FROM read_parquet('{_quote_path(lf1_path)}') AS p1
                INNER JOIN read_parquet('{_quote_path(lf2_path)}') AS p2
                    ON p1.chrom = p2.chrom
                   AND p1.pos = p2.pos
                ORDER BY p1.chrom, p1.pos
            """
            _copy_query_to_parquet(conn, shared_query, shared_path)

            final_query = f"""
                WITH per_gene AS (
                    SELECT
                        genome,
                        gene,
                        COUNT(*) AS total_positions,
                        SUM(CASE WHEN surr > 0 THEN 1 ELSE 0 END) AS share_allele_pos
                    FROM read_parquet('{_quote_path(shared_path)}')
                    GROUP BY genome, gene
                )
                SELECT
                    genome,
                    gene,
                    total_positions,
                    share_allele_pos,
                    share_allele_pos * 100.0 / total_positions AS ani
                FROM per_gene
                WHERE total_positions >= {int(min_gene_compare_len)}
            """
            _copy_query_to_parquet(conn, final_query, final_path)
        finally:
            conn.close()
        return pl.read_parquet(final_path).lazy()


def compare_genomes_duckdb_from_parquet(
    mpileup_contig_1: str | pathlib.Path,
    mpileup_contig_2: str | pathlib.Path,
    scaffolds_1: str | pathlib.Path | None,
    scaffolds_2: str | pathlib.Path | None,
    stb_file: str | pathlib.Path,
    output_file: str | pathlib.Path,
    min_cov: int = 5,
    min_gene_compare_len: int = 100,
    memory_mode: str = "heavy",
    genome: str = "all",
    ani_method: str = "popani",
) -> None:
    _require_duckdb()
    _validate_ani_method(ani_method)
    if memory_mode not in {"heavy", "light"}:
        raise ValueError("Invalid memory_mode. Choose either 'heavy' or 'light'.")

    mpileup_contig_1 = pathlib.Path(mpileup_contig_1)
    mpileup_contig_2 = pathlib.Path(mpileup_contig_2)
    stb_file = pathlib.Path(stb_file)
    output_file = pathlib.Path(output_file)
    sample_1_name = mpileup_contig_1.name
    sample_2_name = mpileup_contig_2.name
    genome_scope = None if genome == "all" else genome

    with tempfile.TemporaryDirectory(prefix="zipstrain_compare_duckdb_") as tmp_dir:
        tmp_dir_path = pathlib.Path(tmp_dir)
        lf1_path = tmp_dir_path / "lf1_filtered.parquet"
        lf2_path = tmp_dir_path / "lf2_filtered.parquet"
        shared_path = tmp_dir_path / "shared_locs.parquet"
        contig_path = tmp_dir_path / "contiguous.parquet"
        pop_path = tmp_dir_path / "pop_ani.parquet"
        max_consecutive_path = tmp_dir_path / "max_consecutive.parquet"
        gene_path = tmp_dir_path / "gene_ani.parquet"

        conn = duckdb.connect()
        try:
            conn.execute("SET preserve_insertion_order=true")
            conn.execute(
                "CREATE TEMP VIEW stb_map AS "
                f"SELECT column0 AS scaffold, column1 AS genome "
                f"FROM read_csv_auto('{_quote_path(stb_file)}', header=false)"
            )

            if genome_scope is None:
                conn.execute("CREATE TEMP VIEW target_genomes AS SELECT DISTINCT genome FROM stb_map")
            else:
                genome_scope_quoted = _quote_literal(genome_scope)
                conn.execute(
                    "CREATE TEMP VIEW scope_scaffolds AS "
                    f"SELECT scaffold FROM stb_map WHERE genome = '{genome_scope_quoted}'"
                )
                conn.execute(
                    "CREATE TEMP VIEW target_genomes AS "
                    f"SELECT DISTINCT genome FROM stb_map WHERE genome = '{genome_scope_quoted}'"
                )

            if memory_mode == "light":
                if scaffolds_1 is None or scaffolds_2 is None:
                    raise ValueError("scaffolds_1 and scaffolds_2 are required in light memory mode.")
                scaffolds_1 = pathlib.Path(scaffolds_1)
                scaffolds_2 = pathlib.Path(scaffolds_2)
                conn.execute(
                    "CREATE TEMP VIEW scaffolds_1 AS "
                    f"SELECT column0 AS scaffold FROM read_csv_auto('{_quote_path(scaffolds_1)}', header=false)"
                )
                conn.execute(
                    "CREATE TEMP VIEW scaffolds_2 AS "
                    f"SELECT column0 AS scaffold FROM read_csv_auto('{_quote_path(scaffolds_2)}', header=false)"
                )
                conn.execute(
                    "CREATE TEMP VIEW shared_scaffolds AS "
                    "SELECT DISTINCT s1.scaffold "
                    "FROM scaffolds_1 AS s1 "
                    "INNER JOIN scaffolds_2 AS s2 ON s1.scaffold = s2.scaffold"
                )

            has_genome_1 = _duckdb_relation_has_column(conn, mpileup_contig_1, "genome")
            has_genome_2 = _duckdb_relation_has_column(conn, mpileup_contig_2, "genome")
            genome_scope_quoted = _quote_literal(genome_scope) if genome_scope is not None else None

            filters_1: list[str] = []
            filters_2: list[str] = []
            if memory_mode == "light":
                filters_1.append("p1.chrom IN (SELECT scaffold FROM shared_scaffolds)")
                filters_2.append("p2.chrom IN (SELECT scaffold FROM shared_scaffolds)")
            if genome_scope is not None:
                filters_1.append("p1.chrom IN (SELECT scaffold FROM scope_scaffolds)")
                filters_2.append("p2.chrom IN (SELECT scaffold FROM scope_scaffolds)")
                if has_genome_1:
                    filters_1.append(f"p1.genome = '{genome_scope_quoted}'")
                if has_genome_2:
                    filters_2.append(f"p2.genome = '{genome_scope_quoted}'")

            _copy_query_to_parquet(
                conn,
                _duckdb_filtered_profile_query(
                    parquet_path=mpileup_contig_1,
                    alias="p1",
                    min_cov=min_cov,
                    has_genome_col=has_genome_1,
                    extra_filters=filters_1,
                ),
                lf1_path,
            )
            _copy_query_to_parquet(
                conn,
                _duckdb_filtered_profile_query(
                    parquet_path=mpileup_contig_2,
                    alias="p2",
                    min_cov=min_cov,
                    has_genome_col=has_genome_2,
                    extra_filters=filters_2,
                ),
                lf2_path,
            )

            ani_expr = _duckdb_ani_expression(ani_method=ani_method)
            shared_query = f"""
                SELECT
                    {ani_expr} AS surr,
                    p1.chrom AS scaffold,
                    p1.pos AS pos,
                    p1.gene AS gene,
                    p1.genome AS genome
                FROM read_parquet('{_quote_path(lf1_path)}') AS p1
                INNER JOIN read_parquet('{_quote_path(lf2_path)}') AS p2
                    ON p1.chrom = p2.chrom
                   AND p1.pos = p2.pos
                ORDER BY p1.chrom, p1.pos
            """
            _copy_query_to_parquet(conn, shared_query, shared_path)

            contig_query = f"""
                WITH ordered AS (
                    SELECT
                        surr,
                        scaffold,
                        pos,
                        gene,
                        genome,
                        LAG(scaffold, 1, scaffold) OVER (ORDER BY scaffold, pos) AS prev_scaffold
                    FROM read_parquet('{_quote_path(shared_path)}')
                )
                SELECT
                    surr,
                    scaffold,
                    pos,
                    gene,
                    genome,
                    SUM(
                        CASE WHEN scaffold <> prev_scaffold OR surr = 0 THEN 1 ELSE 0 END
                    ) OVER (
                        ORDER BY scaffold, pos
                        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                    ) AS group_id
                FROM ordered
            """
            _copy_query_to_parquet(conn, contig_query, contig_path)

            pop_query = f"""
                SELECT
                    genome,
                    COUNT(*) AS total_positions,
                    SUM(CASE WHEN surr > 0 THEN 1 ELSE 0 END) AS share_allele_pos,
                    SUM(CASE WHEN surr > 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS genome_pop_ani
                FROM read_parquet('{_quote_path(contig_path)}')
                GROUP BY genome
            """
            _copy_query_to_parquet(conn, pop_query, pop_path)

            max_consecutive_query = f"""
                WITH block_lengths AS (
                    SELECT
                        genome,
                        scaffold,
                        group_id,
                        COUNT(*) AS length
                    FROM read_parquet('{_quote_path(contig_path)}')
                    GROUP BY genome, scaffold, group_id
                )
                SELECT
                    genome,
                    MAX(length) AS max_consecutive_length
                FROM block_lengths
                GROUP BY genome
            """
            _copy_query_to_parquet(conn, max_consecutive_query, max_consecutive_path)

            gene_query = f"""
                WITH per_gene AS (
                    SELECT
                        genome,
                        gene,
                        COUNT(*) AS total_positions,
                        SUM(CASE WHEN surr > 0 THEN 1 ELSE 0 END) AS share_allele_pos
                    FROM read_parquet('{_quote_path(contig_path)}')
                    GROUP BY genome, gene
                    HAVING COUNT(*) >= {int(min_gene_compare_len)}
                ),
                filtered AS (
                    SELECT
                        genome,
                        total_positions,
                        share_allele_pos
                    FROM per_gene
                    WHERE gene <> 'NA'
                )
                SELECT
                    genome,
                    COUNT(*) AS shared_genes_count,
                    SUM(CASE WHEN share_allele_pos = total_positions THEN 1 ELSE 0 END) AS identical_gene_count,
                    SUM(CASE WHEN share_allele_pos = total_positions THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS perc_id_genes
                FROM filtered
                GROUP BY genome
            """
            _copy_query_to_parquet(conn, gene_query, gene_path)

            final_query = f"""
                WITH comp AS (
                    SELECT
                        p.genome AS genome,
                        p.total_positions,
                        p.share_allele_pos,
                        p.genome_pop_ani,
                        m.max_consecutive_length,
                        g.shared_genes_count,
                        g.identical_gene_count,
                        g.perc_id_genes
                    FROM read_parquet('{_quote_path(pop_path)}') AS p
                    LEFT JOIN read_parquet('{_quote_path(max_consecutive_path)}') AS m USING (genome)
                    LEFT JOIN read_parquet('{_quote_path(gene_path)}') AS g USING (genome)
                )
                SELECT
                    COALESCE(comp.genome, tgt.genome) AS genome,
                    COALESCE(comp.total_positions, 0) AS total_positions,
                    COALESCE(comp.share_allele_pos, 0) AS share_allele_pos,
                    COALESCE(comp.genome_pop_ani, 0) AS genome_pop_ani,
                    COALESCE(comp.max_consecutive_length, 0) AS max_consecutive_length,
                    COALESCE(comp.shared_genes_count, 0) AS shared_genes_count,
                    COALESCE(comp.identical_gene_count, 0) AS identical_gene_count,
                    COALESCE(comp.perc_id_genes, 0) AS perc_id_genes,
                    '{_quote_literal(sample_1_name)}' AS sample_1,
                    '{_quote_literal(sample_2_name)}' AS sample_2
                FROM comp
                FULL OUTER JOIN target_genomes AS tgt ON comp.genome = tgt.genome
            """
            _copy_query_to_parquet(conn, final_query, output_file)
        finally:
            conn.close()


def compare_genes_duckdb_from_parquet(
    mpileup_contig_1: str | pathlib.Path,
    mpileup_contig_2: str | pathlib.Path,
    stb_file: str | pathlib.Path,
    output_file: str | pathlib.Path,
    scope: str = "all:all",
    min_cov: int = 5,
    min_gene_compare_len: int = 100,
    ani_method: str = "popani",
) -> None:
    _require_duckdb()
    _validate_ani_method(ani_method)

    try:
        genome_scope, gene_scope = scope.split(":")
    except ValueError as exc:
        raise ValueError("scope must be in the format '<genome_scope>:<gene_scope>'") from exc

    mpileup_contig_1 = pathlib.Path(mpileup_contig_1)
    mpileup_contig_2 = pathlib.Path(mpileup_contig_2)
    stb_file = pathlib.Path(stb_file)
    output_file = pathlib.Path(output_file)
    sample_1_name = mpileup_contig_1.name
    sample_2_name = mpileup_contig_2.name

    with tempfile.TemporaryDirectory(prefix="zipstrain_gene_compare_duckdb_") as tmp_dir:
        tmp_dir_path = pathlib.Path(tmp_dir)
        lf1_path = tmp_dir_path / "lf1_filtered.parquet"
        lf2_path = tmp_dir_path / "lf2_filtered.parquet"
        shared_path = tmp_dir_path / "shared_locs.parquet"

        conn = duckdb.connect()
        try:
            conn.execute("SET preserve_insertion_order=true")
            conn.execute(
                "CREATE TEMP VIEW stb_map AS "
                f"SELECT column0 AS scaffold, column1 AS genome "
                f"FROM read_csv_auto('{_quote_path(stb_file)}', header=false)"
            )

            genome_scope_quoted = None
            if genome_scope != "all":
                genome_scope_quoted = _quote_literal(genome_scope)
                conn.execute(
                    "CREATE TEMP VIEW scope_scaffolds AS "
                    f"SELECT scaffold FROM stb_map WHERE genome = '{genome_scope_quoted}'"
                )

            has_genome_1 = _duckdb_relation_has_column(conn, mpileup_contig_1, "genome")
            has_genome_2 = _duckdb_relation_has_column(conn, mpileup_contig_2, "genome")

            filters_1: list[str] = []
            filters_2: list[str] = []
            if genome_scope != "all":
                filters_1.append("p1.chrom IN (SELECT scaffold FROM scope_scaffolds)")
                filters_2.append("p2.chrom IN (SELECT scaffold FROM scope_scaffolds)")
                if has_genome_1:
                    filters_1.append(f"p1.genome = '{genome_scope_quoted}'")
                if has_genome_2:
                    filters_2.append(f"p2.genome = '{genome_scope_quoted}'")

            gene_scope_filter = None if gene_scope == "all" else gene_scope
            _copy_query_to_parquet(
                conn,
                _duckdb_filtered_profile_query(
                    parquet_path=mpileup_contig_1,
                    alias="p1",
                    min_cov=min_cov,
                    has_genome_col=has_genome_1,
                    extra_filters=filters_1,
                    gene_scope=gene_scope_filter,
                ),
                lf1_path,
            )
            _copy_query_to_parquet(
                conn,
                _duckdb_filtered_profile_query(
                    parquet_path=mpileup_contig_2,
                    alias="p2",
                    min_cov=min_cov,
                    has_genome_col=has_genome_2,
                    extra_filters=filters_2,
                    gene_scope=gene_scope_filter,
                ),
                lf2_path,
            )

            ani_expr = _duckdb_ani_expression(ani_method=ani_method)
            shared_query = f"""
                SELECT
                    {ani_expr} AS surr,
                    p1.genome AS genome,
                    p1.gene AS gene
                FROM read_parquet('{_quote_path(lf1_path)}') AS p1
                INNER JOIN read_parquet('{_quote_path(lf2_path)}') AS p2
                    ON p1.chrom = p2.chrom
                   AND p1.pos = p2.pos
                ORDER BY p1.chrom, p1.pos
            """
            _copy_query_to_parquet(conn, shared_query, shared_path)

            final_query = f"""
                WITH per_gene AS (
                    SELECT
                        genome,
                        gene,
                        COUNT(*) AS total_positions,
                        SUM(CASE WHEN surr > 0 THEN 1 ELSE 0 END) AS share_allele_pos
                    FROM read_parquet('{_quote_path(shared_path)}')
                    GROUP BY genome, gene
                )
                SELECT
                    genome,
                    gene,
                    total_positions,
                    share_allele_pos,
                    share_allele_pos * 100.0 / total_positions AS ani,
                    '{_quote_literal(sample_1_name)}' AS sample_1,
                    '{_quote_literal(sample_2_name)}' AS sample_2
                FROM per_gene
                WHERE total_positions >= {int(min_gene_compare_len)}
            """
            _copy_query_to_parquet(conn, final_query, output_file)
        finally:
            conn.close()

def coverage_filter(mpile_frame:pl.LazyFrame, min_cov:int,engine:str)-> pl.LazyFrame:
    """
    Filter the mpile lazyframe based on minimum coverage at each loci.
    
    Args:
        mpile_frame (pl.LazyFrame): The input LazyFrame containing coverage data.
        min_cov (int): The minimum coverage threshold.
    
    Returns:
        pl.LazyFrame: Filtered LazyFrame with positions having coverage >= min_cov.
    """
    mpile_frame = mpile_frame.with_columns(
        (pl.col("A") + pl.col("C") + pl.col("G") + pl.col("T")).alias("cov")
    )
    return mpile_frame.filter(pl.col("cov") >= min_cov)



def get_shared_locs(mpile_contig_1:pl.LazyFrame, mpile_contig_2:pl.LazyFrame,ani_method:str="popani") -> pl.LazyFrame:
    """
    Returns a lazyframe with ATCG information for shared scaffolds and positions between two mpileup files.

    Args:
        mpile_contig_1 (pl.LazyFrame): The first mpileup LazyFrame.
        mpile_contig_2 (pl.LazyFrame): The second mpileup LazyFrame.
        ani_method (str): The ANI calculation method to use. Default is "popani".
    
    Returns:
        pl.LazyFrame: Merged LazyFrame containing shared scaffolds and positions with ATCG information.
    """
    ani_expr=getattr(PolarsANIExpressions(), ani_method)()

    mpile_contig= mpile_contig_1.join(
        mpile_contig_2,
        on=["chrom", "pos"],
        how="inner",
        suffix="_2"  # To distinguish lf2 columns
    ).with_columns(
        ani_expr.alias("surr")
    ).select(
        pl.col("surr"),
        scaffold=pl.col("chrom"),
        pos=pl.col("pos"),
        gene=pl.col("gene"),
        genome=pl.col("genome")
    )
    return mpile_contig

def add_contiguity_info(mpile_contig:pl.LazyFrame) -> pl.LazyFrame:
    """ Adds group id information to the lazy frame. If on the same scaffold and not popANI, then they are in the same group.
    
    Args:
        mpile_contig (pl.LazyFrame): The input LazyFrame containing mpileup data.
    
    Returns:
        pl.LazyFrame: Updated LazyFrame with group id information added.
    """

    mpile_contig= mpile_contig.sort(["scaffold", "pos"])
    mpile_contig = mpile_contig.with_columns([
        (pl.col("scaffold").shift(1).fill_null(pl.col("scaffold")).alias("prev_scaffold")),
    ])
    mpile_contig = mpile_contig.with_columns([
        (((pl.col("scaffold") != pl.col("prev_scaffold")) | (pl.col("surr") == 0))).cum_sum().alias("group_id")
    ])
    return mpile_contig

def add_genome_info(mpile_contig:pl.LazyFrame, scaffold_to_genome:pl.LazyFrame) -> pl.LazyFrame:
    """
    Adds genome information to the mpileup LazyFrame based on scaffold to genome mapping.
    
    Args:
        mpile_contig (pl.LazyFrame): The input LazyFrame containing mpileup data.
        scaffold_to_genome (pl.LazyFrame): The LazyFrame mapping scaffolds to genomes.
    
    Returns:
        pl.LazyFrame: Updated LazyFrame with genome information added.
    """
    return mpile_contig.join(
        scaffold_to_genome, on="scaffold", how="inner"
    ).fill_null("NA")

def calculate_pop_ani(mpile_contig:pl.LazyFrame) -> pl.LazyFrame:
    """
    Calculates the population ANI (Average Nucleotide Identity) for the given mpileup LazyFrame.
    NOTE: Remember that this function should be applied to the merged mpileup using get_shared_locs.

    Args:
        mpile_contig (pl.LazyFrame): The input LazyFrame containing mpileup data.
    
    Returns:
        pl.LazyFrame: Updated LazyFrame with population ANI information added.
    """
    return mpile_contig.group_by("genome").agg(
            total_positions=pl.len(),
            share_allele_pos=(pl.col("surr") > 0 ).sum()
        ).with_columns(
            genome_pop_ani=pl.col("share_allele_pos")/pl.col("total_positions")*100,
        )

def get_longest_consecutive_blocks(mpile_contig:pl.LazyFrame) -> pl.LazyFrame:
    """
    Calculates the longest consecutive blocks for each genome in the mpileup LazyFrame for any genome.
    
    Args:
        mpile_contig (pl.LazyFrame): The input LazyFrame containing mpileup data.
    
    Returns:
        pl.LazyFrame: Updated LazyFrame with longest consecutive blocks information added.
    """
    block_lengths = (
        mpile_contig.group_by(["genome", "scaffold", "group_id"])
        .agg(pl.len().alias("length"))
    ) 
    return block_lengths.group_by("genome").agg(pl.col("length").max().alias("max_consecutive_length"))

def get_gene_ani(mpile_contig:pl.LazyFrame, min_gene_compare_len:int) -> pl.LazyFrame:
    """
    Calculates gene ANI (Average Nucleotide Identity) for each gene in each genome.
    
    Args:
        mpile_contig (pl.LazyFrame): The input LazyFrame containing mpileup data.
        min_gene_compare_len (int): Minimum length of the gene to consider for comparison.
    
    Returns:
        pl.LazyFrame: Updated LazyFrame with gene ANI information added.
    """
    return mpile_contig.group_by(["genome", "gene"]).agg(
        total_positions=pl.len(),
        share_allele_pos=(pl.col("surr") > 0).sum()
    ).filter(pl.col("total_positions") >= min_gene_compare_len).with_columns(
        identical=(pl.col("share_allele_pos") == pl.col("total_positions")),
    ).filter(pl.col("gene") != "NA").group_by("genome").agg(
        shared_genes_count=pl.len(),
        identical_gene_count=pl.col("identical").sum()
    ).with_columns(perc_id_genes=pl.col("identical_gene_count") / pl.col("shared_genes_count") * 100)

def get_unique_scaffolds(mpile_contig:pl.LazyFrame,batch_size:int=10000) -> set:
    """
    Retrieves unique scaffolds from the mpileup LazyFrame.

    Args:
        mpile_contig (pl.LazyFrame): The input LazyFrame containing mpileup data.
        batch_size (int): The number of rows to process in each batch. Default is 10000.
    Returns:
        set: A set of unique scaffold names.
    """
    scaffolds = set()
    start_index = 0
    while True:
        batch = mpile_contig.slice(start_index, batch_size).select("chrom").collect()
        if batch.height == 0:
            break
        scaffolds.update(batch["chrom"].to_list())
        start_index += batch_size
    return scaffolds 


def compare_genomes(mpile_contig_1:pl.LazyFrame,
              mpile_contig_2:pl.LazyFrame,
              null_model:pl.LazyFrame|None=None,
              scaffold_to_genome:pl.LazyFrame|None=None,
              min_cov:int=5,
              min_gene_compare_len:int=100,
              memory_mode:str="heavy",
              chrom_batch_size:int=10000,
              shared_scaffolds:list=None,
              scaffold_scope:list=None,
              engine="streaming",
              ani_method:str="popani",
              compare_engine:str="duckdb"
            )-> pl.LazyFrame:
    """
    Compares two profiles and generates genome-level comparison statistics.
    The final output is a Polars LazyFrame with genome comparison statisticsin the following columns:
    
    - genome: The genome identifier.
    
    - total_positions: Total number of positions compared.
    
    - share_allele_pos: Number of positions with shared alleles.
    
    - genome_pop_ani: Population ANI percentage.
    
    - max_consecutive_length: Length of the longest consecutive block of shared alleles.
    
    - shared_genes_count: Number of genes compared.
    
    - identical_gene_count: Number of identical genes.
    
    - perc_id_genes: Percentage of identical genes.

    Args:
        mpile_contig_1 (pl.LazyFrame): The first profile as a LazyFrame.
        mpile_contig_2 (pl.LazyFrame): The second profile as a LazyFrame.
        null_model (pl.LazyFrame): Deprecated and ignored. Sequencing error adjustment is expected to be done during profiling.
        min_cov (int): Minimum coverage threshold for filtering positions. Default is 5.
        min_gene_compare_len (int): Minimum length of genes that needs to be covered to consider for comparison. Default is 100.
        memory_mode (str): Memory mode for processing. Options are "heavy" or "light". Default is "heavy".
        chrom_batch_size (int): Batch size for processing scaffolds in light memory mode. Default
        shared_scaffolds (list): List of shared scaffolds between the two profiles. Required for light memory mode.
        scaffold_scope (list): List of scaffolds to limit the comparison to. Default is None.
        engine (str): The Polars engine to use for computation. Default is "streaming".
        ani_method (str): The ANI calculation method to use. Default is "popani".
    
    Returns:
        pl.LazyFrame: A LazyFrame containing genome-level comparison statistics.
    """
    compare_engine = _validate_compare_engine(compare_engine)
    if compare_engine == "polars":
        return _compare_genomes_polars(
            mpile_contig_1=mpile_contig_1,
            mpile_contig_2=mpile_contig_2,
            min_cov=min_cov,
            min_gene_compare_len=min_gene_compare_len,
            memory_mode=memory_mode,
            chrom_batch_size=chrom_batch_size,
            shared_scaffolds=shared_scaffolds,
            scaffold_scope=scaffold_scope,
            engine=engine,
            ani_method=ani_method,
            scaffold_to_genome=scaffold_to_genome,
        )
    return _compare_genomes_duckdb(
        mpile_contig_1=mpile_contig_1,
        mpile_contig_2=mpile_contig_2,
        min_cov=min_cov,
        min_gene_compare_len=min_gene_compare_len,
        memory_mode=memory_mode,
        shared_scaffolds=shared_scaffolds,
        scaffold_scope=scaffold_scope,
        engine=engine,
        ani_method=ani_method,
        scaffold_to_genome=scaffold_to_genome,
    )



def compare_genes(mpile_contig_1:pl.LazyFrame,
              mpile_contig_2:pl.LazyFrame,
              null_model:pl.LazyFrame|None=None,
              scaffold_to_genome:pl.LazyFrame|None=None,
              min_cov:int=5,
              min_gene_compare_len:int=100,
              engine="streaming",
              ani_method:str="popani",
              compare_engine:str="duckdb"
            )-> pl.LazyFrame:
    """
    Compares two profiles and generates gene-level comparison statistics.
    The final output is a Polars LazyFrame with gene comparison statistics in the following columns:
    - genome: The genome identifier.
    - gene: The gene identifier.
    - total_positions: Total number of positions compared in the gene.
    - share_allele_pos: Number of positions with shared alleles in the gene.
    - ani: Average Nucleotide Identity (ANI) percentage for the gene.
    
    Args:
        mpile_contig_1 (pl.LazyFrame): The first profile as a LazyFrame.
        mpile_contig_2 (pl.LazyFrame): The second profile as a LazyFrame.
        null_model (pl.LazyFrame): Deprecated and ignored. Sequencing error adjustment is expected to be done during profiling.
        scaffold_to_genome (pl.LazyFrame): A mapping LazyFrame from scaffolds to genomes.
        min_cov (int): Minimum coverage threshold for filtering positions. Default is 5.
        min_gene_compare_len (int): Minimum length of genes that needs to be covered to consider for comparison. Default is 100.
        engine (str): The Polars engine to use for computation. Default is "streaming".
        ani_method (str): The ANI calculation method to use. Default is "popani".
    
    Returns:
        pl.LazyFrame: A LazyFrame containing gene-level comparison statistics.
    """
    compare_engine = _validate_compare_engine(compare_engine)
    if compare_engine == "polars":
        return _compare_genes_polars(
            mpile_contig_1=mpile_contig_1,
            mpile_contig_2=mpile_contig_2,
            min_cov=min_cov,
            min_gene_compare_len=min_gene_compare_len,
            engine=engine,
            ani_method=ani_method,
            scaffold_to_genome=scaffold_to_genome,
        )
    return _compare_genes_duckdb(
        mpile_contig_1=mpile_contig_1,
        mpile_contig_2=mpile_contig_2,
        min_cov=min_cov,
        min_gene_compare_len=min_gene_compare_len,
        engine=engine,
        ani_method=ani_method,
        scaffold_to_genome=scaffold_to_genome,
    )
