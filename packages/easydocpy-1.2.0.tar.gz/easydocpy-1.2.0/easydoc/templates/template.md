# %module_name%

## Introduction

%version%
%author%
%creation_date%
%last_release_date%

%intro%

%roadmap%

%TODO%

## Uses

## Technical details

%const%
