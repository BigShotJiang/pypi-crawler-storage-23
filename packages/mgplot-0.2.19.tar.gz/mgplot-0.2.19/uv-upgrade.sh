uv lock --upgrade
uv sync --upgrade

