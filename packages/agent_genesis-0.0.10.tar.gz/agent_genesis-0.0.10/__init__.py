"""Top-level exports for the evaluation SDK package."""

from .api import (
    create_config,
    create_phase,
    create_problem,
    init_registry,
    get_registry,
    register_problem,
    sync_problem,
    sync_all_problems,
    create_problem_revision,
    create_client,
    create_worker,
    run_worker,
    get_version_history,
    get_version_diff,
    list_revisions,
    create_revision,
    merge_revision,
    close_revision,
    get_data_export,
    get_phase_template,
    get_phase_files,
)

from .base import BaseEvaluator
from .dual_sandbox_evaluator import DualSandboxEvaluator

from .models import (
    PhaseConfig,
    RuntimeConfig,
    CaseResult,
    PhaseResult,
    UserSubmission,
    CaseStatus,
    PhaseStatus,
)

from .client import EvaluationClient
from .service import EvaluationService
from .registry import ProblemRegistry, build_artifact_from_dir
from .models import ProblemConfig

from .sandbox_pool import (
    SandboxManager,
    SandboxBusyError,
    create_sandbox,
    destroy_sandbox,
    get_sandbox_stats,
)

from .health import (
    MetricsCollector,
    HealthServer,
    get_metrics_collector,
    start_health_server,
    stop_health_server,
)

from .config import SystemConfig, get_config, ClientMode

__all__: list[str] = [
    "create_config",
    "create_phase",
    "create_problem",
    "init_registry",
    "get_registry",
    "register_problem",
    "sync_problem",
    "sync_all_problems",
    "create_problem_revision",
    "create_client",
    "create_worker",
    "run_worker",
    "get_version_history",
    "get_version_diff",
    "list_revisions",
    "create_revision",
    "merge_revision",
    "close_revision",
    "get_data_export",
    "get_phase_template",
    "get_phase_files",
    "BaseEvaluator",
    "DualSandboxEvaluator",
    "PhaseConfig",
    "RuntimeConfig",
    "CaseResult",
    "PhaseResult",
    "UserSubmission",
    "CaseStatus",
    "PhaseStatus",
    "EvaluationClient",
    "EvaluationService",
    "ProblemRegistry",
    "ProblemConfig",
    "build_artifact_from_dir",
    "SandboxManager",
    "SandboxBusyError",
    "create_sandbox",
    "destroy_sandbox",
    "get_sandbox_stats",
    "MetricsCollector",
    "HealthServer",
    "get_metrics_collector",
    "start_health_server",
    "stop_health_server",
    "SystemConfig",
    "get_config",
    "ClientMode",
]

try:
    from importlib.metadata import version as _pkg_version, PackageNotFoundError as _PNF
    __version__: str = _pkg_version("agent-genesis")
except _PNF:
    __version__ = "0.0.10"
