from .trainable import AbstractTrainableFeatureDecoder
from .noop import NoopFeatureDecoder
