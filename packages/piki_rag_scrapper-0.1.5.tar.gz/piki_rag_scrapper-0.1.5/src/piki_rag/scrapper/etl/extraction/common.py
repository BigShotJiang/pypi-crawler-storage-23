class Extractor:
    def is_extractable(self, path) -> bool:
        pass

    def extract(self, path: str) -> str:
        pass
