"""
PromptVault — Version, compare, and manage your LLM prompts.

No API keys. No LLM calls. Bring your own model.

Quick Start:
    from promptvault import Prompt, Compare

    # 1. Define two prompt versions
    v1 = Prompt("summarize", template="Summarize this: {text}")
    v2 = Prompt("summarize", template="Summarize in 3 bullets: {text}", version="v2")

    # 2. YOU call your LLM (any LLM, any way you like)
    r1 = your_llm(v1.render(text="Some article..."))
    r2 = your_llm(v2.render(text="Some article..."))

    # 3. PromptVault compares and tracks
    cmp = Compare(v1, v2)
    cmp.log(r1, r2)
    cmp.show()
"""

from .prompt import Prompt
from .compare import Compare
from .registry import Registry
from .storage import PromptStorage

__version__ = "0.1.0"
__author__ = "PromptVault Contributors"
__license__ = "MIT"

__all__ = [
    "Prompt",
    "Compare",
    "Registry",
    "PromptStorage",
]
