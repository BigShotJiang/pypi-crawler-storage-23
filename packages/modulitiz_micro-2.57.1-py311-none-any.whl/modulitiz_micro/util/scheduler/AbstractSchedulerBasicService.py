import logging
from abc import ABC

from apscheduler.events import JobExecutionEvent

from modulitiz_nano.exceptions.ExceptionUtil import ExceptionUtil
from modulitiz_nano.files.ModuloLogging import ModuloLogging


class AbstractSchedulerBasicService(ABC):
	def __init__(self,logger:ModuloLogging|None,logLevel:int|None):
		super().__init__()
		self._logger=logger
		self.__logLevel=logLevel
		self.loggerInternal=logging.getLogger('apscheduler')
	
	def _addLoggerInternalToMainLogger(self):
		if self._logger is None:
			return
		level=self._logger.level if self.__logLevel is None else self.__logLevel
		self.loggerInternal.setLevel(level)
		for handler in self._logger.handlers:
			self.loggerInternal.addHandler(handler)
	
	def _standardOnException(self,event: JobExecutionEvent):
		self._logger.error("Job error: "+ExceptionUtil.toString(event.exception))
