import oracledb

from modulitiz_micro.database.ModuloSqlServer import ModuloSqlServer


class ModuloSqlOracle(ModuloSqlServer):
	DEFAULT_PORT=1521
	
	def __init__(self,port:int|None,*args,**kwargs):
		super().__init__(*args,**kwargs)
		if port is None:
			port=self.DEFAULT_PORT
		self.port=port
	
	def connessione(self):
		dsn="{}/{}@{}:{}/xe".format(self.username,self.password,self.host,self.port)
		self.connDb=oracledb.connect(dsn)
		self.connDb=dsn
	
