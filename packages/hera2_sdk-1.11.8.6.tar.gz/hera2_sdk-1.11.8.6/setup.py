"""
hera2-sdk: thin wrapper that depends on openmetadata-ingestion and forwards extras.
"""

from setuptools import setup

INGESTION_VERSION = "1.11.8"

PLUGIN_EXTRAS = [
    "airflow",
    "amundsen",
    "athena",
    "atlas",
    "azuresql",
    "azure-sso",
    "backup",
    "bigquery",
    "bigtable",
    "clickhouse",
    "dagster",
    "dbt",
    "db2",
    "db2-ibmi",
    "databricks",
    "datalake-azure",
    "datalake-gcs",
    "datalake-s3",
    "deltalake",
    "deltalake-storage",
    "deltalake-spark",
    "domo",
    "doris",
    "druid",
    "dynamodb",
    "elasticsearch",
    "opensearch",
    "exasol",
    "glue",
    "great-expectations",
    "great-expectations-1xx",
    "greenplum",
    "cockroach",
    "hive",
    "iceberg",
    "impala",
    "kafka",
    "kafkaconnect",
    "kinesis",
    "looker",
    "mlflow",
    "mongo",
    "cassandra",
    "couchbase",
    "mssql",
    "mssql-odbc",
    "mysql",
    "nifi",
    "openlineage",
    "oracle",
    "pgspider",
    "pinotdb",
    "postgres",
    "powerbi",
    "qliksense",
    "presto",
    "pymssql",
    "quicksight",
    "redash",
    "redpanda",
    "redshift",
    "sagemaker",
    "salesforce",
    "sample-data",
    "sap-hana",
    "sas",
    "singlestore",
    "sklearn",
    "snowflake",
    "superset",
    "tableau",
    "teradata",
    "trino",
    "vertica",
    "pandas",
    "pyarrow",
    "pii-processor",
    "presidio-analyzer",
]

OTHER_EXTRAS = [
    "all",
    "slim",
    "all-dev-env",
    "dev",
    "test",
    "test-unit",
    "e2e_test",
    "playwright",
    "docs",
    "data-insight",
]

ALL_EXTRAS = PLUGIN_EXTRAS + OTHER_EXTRAS

setup(
    install_requires=[
        f"openmetadata-ingestion~={INGESTION_VERSION}.0",
        "cachetools",
    ],
    extras_require={
        extra: [f"openmetadata-ingestion[{extra}]~={INGESTION_VERSION}.0"]
        for extra in ALL_EXTRAS
    },
)
