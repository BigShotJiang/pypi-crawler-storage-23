"""Shared fixtures, MockProvider, and Hypothesis strategies for the Synth test suite."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from dataclasses import dataclass, field
from typing import Any

import pytest
from hypothesis import HealthCheck, settings

# ---------------------------------------------------------------------------
# Hypothesis profile — disable the example database so stale failing examples
# from previous runs never cause spurious CI failures.
# ---------------------------------------------------------------------------

settings.register_profile(
    "ci",
    database=None,
    suppress_health_check=[HealthCheck.too_slow],
)
settings.load_profile("ci")


# ---------------------------------------------------------------------------
# Async helper for property tests
# Property tests (Hypothesis) are synchronous functions that need to call
# async code. Using asyncio.run() can conflict with pytest-asyncio's event
# loop when tests run in the same session. This helper always creates a
# fresh isolated loop to avoid "This event loop is already running" errors.
# ---------------------------------------------------------------------------

def run_async(coro):  # type: ignore[no-untyped-def]
    """Run an async coroutine in a fresh event loop.

    Use this in Hypothesis property tests instead of ``asyncio.run()`` to
    avoid conflicts with pytest-asyncio's managed event loop.

    Parameters
    ----------
    coro:
        An awaitable coroutine to execute.

    Returns
    -------
    Any
        The return value of the coroutine.
    """
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()

from synth.providers.base import (
    BaseProvider,
    ProviderDoneEvent,
    ProviderEvent,
    ProviderResponse,
    TextChunkEvent,
    ToolCallInfo,
)
from synth.types import Message, TokenUsage


# ---------------------------------------------------------------------------
# Call record — stores arguments for each provider invocation
# ---------------------------------------------------------------------------


@dataclass
class ProviderCallRecord:
    """Captures the arguments of a single ``complete()`` or ``stream()`` call.

    Attributes
    ----------
    messages:
        The conversation messages passed to the provider.
    tools:
        The tool schemas passed to the provider, if any.
    kwargs:
        Any additional keyword arguments forwarded to the provider.
    method:
        Which method was called (``"complete"`` or ``"stream"``).
    """

    messages: list[Message]
    tools: list[dict[str, Any]] | None
    kwargs: dict[str, Any]
    method: str


# ---------------------------------------------------------------------------
# MockProvider
# ---------------------------------------------------------------------------


_DEFAULT_USAGE = TokenUsage(input_tokens=10, output_tokens=20, total_tokens=30)


def _default_response(text: str = "mock response") -> ProviderResponse:
    """Build a simple ``ProviderResponse`` with sensible defaults."""
    return ProviderResponse(text=text, usage=_DEFAULT_USAGE)


class MockProvider(BaseProvider):
    """Configurable mock provider for testing.

    Returns pre-configured responses without making live API calls, enabling
    deterministic testing of agent behaviour and full CI without API keys.

    Parameters
    ----------
    responses:
        A list of ``ProviderResponse`` objects returned by ``complete()`` in
        order.  When the list is exhausted the provider cycles back to the
        first response.  Defaults to a single generic response.
    stream_events:
        A list of ``ProviderEvent`` lists.  Each inner list is yielded in
        order by a single ``stream()`` call.  Cycles when exhausted.
        Defaults to a text-chunk + done sequence matching the first response.
    error:
        If set, every ``complete()`` and ``stream()`` call raises this
        exception *before* returning any data.  Useful for simulating rate
        limits, auth failures, or malformed responses.

    Attributes
    ----------
    call_history:
        A list of ``ProviderCallRecord`` objects — one per ``complete()`` or
        ``stream()`` invocation — for assertion in tests.
    """

    def __init__(
        self,
        responses: list[ProviderResponse] | None = None,
        stream_events: list[list[ProviderEvent]] | None = None,
        error: Exception | None = None,
        **kwargs: Any,
    ) -> None:
        self._responses: list[ProviderResponse] = responses or [_default_response()]
        self._stream_events: list[list[ProviderEvent]] | None = stream_events
        self._error: Exception | None = error
        self._call_index: int = 0
        self._stream_index: int = 0
        self.call_history: list[ProviderCallRecord] = []

    # -- helpers -------------------------------------------------------------

    def _next_response(self) -> ProviderResponse:
        """Return the next response, cycling when the list is exhausted."""
        resp = self._responses[self._call_index % len(self._responses)]
        self._call_index += 1
        return resp

    def _next_stream_events(self) -> list[ProviderEvent]:
        """Return the next stream event list, cycling when exhausted."""
        if self._stream_events:
            events = self._stream_events[
                self._stream_index % len(self._stream_events)
            ]
            self._stream_index += 1
            return events

        # Derive a default stream from the next response.
        resp = self._next_response()
        events: list[ProviderEvent] = []
        if resp.text:
            events.append(TextChunkEvent(text=resp.text))
        events.append(ProviderDoneEvent(usage=resp.usage))
        return events

    def _record_call(
        self,
        method: str,
        messages: list[Message],
        tools: list[dict[str, Any]] | None,
        kwargs: dict[str, Any],
    ) -> None:
        self.call_history.append(
            ProviderCallRecord(
                messages=messages,
                tools=tools,
                kwargs=kwargs,
                method=method,
            )
        )

    # -- BaseProvider interface ----------------------------------------------

    async def complete(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> ProviderResponse:
        """Return the next pre-configured response.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Additional provider options (ignored but recorded).

        Raises
        ------
        Exception
            Re-raises the configured ``error`` if one was provided.
        """
        self._record_call("complete", messages, tools, kwargs)
        if self._error is not None:
            raise self._error
        return self._next_response()

    async def stream(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ProviderEvent, None]:
        """Yield pre-configured stream events.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Additional provider options (ignored but recorded).

        Raises
        ------
        Exception
            Re-raises the configured ``error`` if one was provided.
        """
        self._record_call("stream", messages, tools, kwargs)
        if self._error is not None:
            raise self._error
        for event in self._next_stream_events():
            yield event


# ---------------------------------------------------------------------------
# Pytest fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def mock_provider() -> MockProvider:
    """Return a default ``MockProvider`` instance with a single generic response."""
    return MockProvider()
