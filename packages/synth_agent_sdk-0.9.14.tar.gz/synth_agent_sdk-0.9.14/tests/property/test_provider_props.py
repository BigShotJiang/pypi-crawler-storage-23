# Feature: synth-agent-sdk, Properties 9, 10, 41: Provider routing and retry
"""Property-based tests for provider routing, retry logic, and invalid model handling.

**Property 9: Provider routing correctness**
**Validates: Requirements 4.1**

For any model string with a known provider prefix, the ProviderRouter should
return an instance of the correct provider class corresponding to that prefix.

**Property 10: Retry with exponential backoff**
**Validates: Requirements 4.5**

For any provider call that returns a transient error (HTTP 429 or 5xx), the
system should retry up to max_retries times, with each retry delay being
greater than the previous delay.

**Property 41: Invalid model string raises SynthConfigError**
**Validates: Requirements 1.3**

For any model string that does not match any known provider prefix and has no
base_url configured, the Agent should raise a SynthConfigError containing the
invalid model string.
"""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from synth.errors import SynthConfigError
from synth.providers.retry import RetryHandler
from synth.providers.router import KNOWN_PREFIXES, ProviderRouter, _PROVIDER_SPECS


def _run_async(coro):  # type: ignore[no-untyped-def]
    """Run a coroutine in a fresh event loop (safe inside Hypothesis tests)."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()

# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

# Model suffix: random alphanumeric string to append after a known prefix
_model_suffix = st.from_regex(r"[a-z0-9][a-z0-9._-]{0,30}", fullmatch=True)

# Known prefix strategy
_known_prefix = st.sampled_from(KNOWN_PREFIXES)

# Valid model strings: known prefix + random suffix
_valid_model_string = st.tuples(_known_prefix, _model_suffix).map(
    lambda t: t[0] + t[1]
)

# Invalid model strings: text that does NOT start with any known prefix
_invalid_model_string = st.text(
    alphabet=st.characters(whitelist_categories=("L", "N"), whitelist_characters="-_./"),
    min_size=1,
    max_size=40,
).filter(
    lambda s: not any(s.startswith(p) for p in KNOWN_PREFIXES)
)

# Retry config strategies
_max_retries = st.integers(min_value=1, max_value=5)
_retry_backoff = st.floats(min_value=0.1, max_value=2.0)

# Transient HTTP status codes (429 + 5xx)
_transient_status = st.sampled_from([429, 500, 502, 503, 504])


# ---------------------------------------------------------------------------
# Property 9: Provider routing correctness
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    prefix=_known_prefix,
    suffix=_model_suffix,
)
def test_provider_routing_correctness(prefix, suffix):
    """Property 9: For any model string with a known provider prefix, the
    ProviderRouter should return an instance of the correct provider class
    corresponding to that prefix.

    **Validates: Requirements 4.1**
    """
    model = prefix + suffix
    spec = _PROVIDER_SPECS[prefix]
    module_path, class_name, _package, _extra = spec

    # Create a mock provider class that records instantiation
    mock_cls = MagicMock()
    mock_cls.return_value = MagicMock()

    # Create a mock module containing the provider class
    mock_module = MagicMock()
    setattr(mock_module, class_name, mock_cls)

    def fake_import(name):
        if name == module_path:
            return mock_module
        raise ImportError(f"No module named '{name}'")

    with patch("importlib.import_module", side_effect=fake_import):
        router = ProviderRouter()
        provider = router.resolve(model)

    # The correct provider class was instantiated
    mock_cls.assert_called_once()

    # The model string was passed to the constructor
    call_kwargs = mock_cls.call_args
    assert call_kwargs[1].get("model") == model or call_kwargs[0][0] == model


# ---------------------------------------------------------------------------
# Property 10: Retry with exponential backoff
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    max_retries=_max_retries,
    retry_backoff=_retry_backoff,
    status_code=_transient_status,
)
def test_retry_with_exponential_backoff(max_retries, retry_backoff, status_code):
    """Property 10: For any provider call that returns a transient error
    (HTTP 429 or 5xx), the system should retry up to max_retries times,
    with each retry delay being greater than the previous delay.

    **Validates: Requirements 4.5**
    """
    call_count = 0
    captured_delays: list[float] = []

    # Build a mock HTTP response that triggers retryable errors
    mock_request = httpx.Request("POST", "https://api.example.com/v1/chat")
    mock_response = httpx.Response(status_code, request=mock_request)

    async def failing_fn():
        nonlocal call_count
        call_count += 1
        raise httpx.HTTPStatusError(
            f"HTTP {status_code}",
            request=mock_request,
            response=mock_response,
        )

    async def mock_sleep(delay):
        captured_delays.append(delay)

    handler = RetryHandler(max_retries=max_retries, retry_backoff=retry_backoff)

    with patch("synth.providers.retry.asyncio.sleep", side_effect=mock_sleep):
        try:
            _run_async(handler.execute(failing_fn))
        except httpx.HTTPStatusError:
            pass  # Expected after exhausting retries

    # Total calls = 1 initial + max_retries retries
    assert call_count == max_retries + 1

    # Number of delays = max_retries (no sleep after final attempt)
    assert len(captured_delays) == max_retries

    # Each delay must be strictly greater than the previous
    for i in range(1, len(captured_delays)):
        assert captured_delays[i] > captured_delays[i - 1], (
            f"Delay {i} ({captured_delays[i]:.4f}) should be greater than "
            f"delay {i - 1} ({captured_delays[i - 1]:.4f})"
        )

    # Each delay should follow the exponential formula: base * 2^attempt + jitter
    # Verify minimum bound (without jitter): retry_backoff * 2^attempt
    for attempt, delay in enumerate(captured_delays):
        min_delay = retry_backoff * (2 ** attempt)
        assert delay >= min_delay, (
            f"Delay for attempt {attempt} ({delay:.4f}) should be >= "
            f"base delay ({min_delay:.4f})"
        )


# ---------------------------------------------------------------------------
# Property 41: Invalid model string raises SynthConfigError
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(model=_invalid_model_string)
def test_invalid_model_string_raises_synth_config_error(model):
    """Property 41: For any model string that does not match any known
    provider prefix and has no base_url configured, the Agent should raise
    a SynthConfigError containing the invalid model string.

    **Validates: Requirements 1.3**
    """
    router = ProviderRouter()

    try:
        router.resolve(model)
        raise AssertionError(
            f"Expected SynthConfigError for invalid model string '{model}'"
        )
    except SynthConfigError as err:
        # Error message contains the invalid model string
        assert model in str(err), (
            f"Error message should contain the invalid model string '{model}', "
            f"got: {err}"
        )

        # Error has required SynthError fields
        assert err.component == "ProviderRouter"
        assert err.suggestion  # non-empty suggestion
