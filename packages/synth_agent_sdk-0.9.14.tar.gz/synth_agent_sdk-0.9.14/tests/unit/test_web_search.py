"""Unit tests for synth.tools.web_search.

Covers provider resolution, each search provider, the ``web_search``
tool function, and error handling.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from synth.errors import SynthConfigError
from synth.tools.web_search import (
    _resolve_provider,
    _search_brave,
    _search_serpapi,
    _search_tavily,
    web_search,
)


# ---------------------------------------------------------------------------
# Provider resolution
# ---------------------------------------------------------------------------


class TestResolveProvider:
    """Tests for ``_resolve_provider``."""

    def test_brave_preferred_when_set(self) -> None:
        env = {"BRAVE_API_KEY": "key1", "SERPAPI_API_KEY": "key2"}
        with patch.dict("os.environ", env, clear=True):
            name, fn = _resolve_provider()
        assert name == "BRAVE_API_KEY"
        assert fn is _search_brave

    def test_serpapi_when_brave_missing(self) -> None:
        env = {"SERPAPI_API_KEY": "key2"}
        with patch.dict("os.environ", env, clear=True):
            name, fn = _resolve_provider()
        assert name == "SERPAPI_API_KEY"
        assert fn is _search_serpapi

    def test_tavily_when_others_missing(self) -> None:
        env = {"TAVILY_API_KEY": "key3"}
        with patch.dict("os.environ", env, clear=True):
            name, fn = _resolve_provider()
        assert name == "TAVILY_API_KEY"
        assert fn is _search_tavily

    def test_raises_when_none_configured(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            with pytest.raises(SynthConfigError, match="No web search"):
                _resolve_provider()


# ---------------------------------------------------------------------------
# Brave provider
# ---------------------------------------------------------------------------


class TestSearchBrave:
    """Tests for ``_search_brave``."""

    def test_parses_response(self) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "web": {
                "results": [
                    {
                        "title": "Result 1",
                        "url": "https://example.com/1",
                        "description": "First result",
                    },
                    {
                        "title": "Result 2",
                        "url": "https://example.com/2",
                        "description": "Second result",
                    },
                ],
            },
        }
        env = {"BRAVE_API_KEY": "test-key"}
        with patch.dict("os.environ", env), \
             patch("httpx.get", return_value=mock_resp):
            results = _search_brave("test query", 5)

        assert len(results) == 2
        assert results[0]["title"] == "Result 1"
        assert results[0]["url"] == "https://example.com/1"
        assert results[0]["snippet"] == "First result"

    def test_respects_limit(self) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "web": {
                "results": [
                    {"title": f"R{i}", "url": f"u{i}", "description": f"d{i}"}
                    for i in range(10)
                ],
            },
        }
        env = {"BRAVE_API_KEY": "test-key"}
        with patch.dict("os.environ", env), \
             patch("httpx.get", return_value=mock_resp):
            results = _search_brave("q", 3)

        assert len(results) == 3

    def test_empty_results(self) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"web": {"results": []}}
        env = {"BRAVE_API_KEY": "test-key"}
        with patch.dict("os.environ", env), \
             patch("httpx.get", return_value=mock_resp):
            results = _search_brave("q", 5)

        assert results == []


# ---------------------------------------------------------------------------
# SerpAPI provider
# ---------------------------------------------------------------------------


class TestSearchSerpapi:
    """Tests for ``_search_serpapi``."""

    def test_parses_response(self) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "organic_results": [
                {
                    "title": "Serp 1",
                    "link": "https://serp.com/1",
                    "snippet": "Serp snippet",
                },
            ],
        }
        env = {"SERPAPI_API_KEY": "test-key"}
        with patch.dict("os.environ", env), \
             patch("httpx.get", return_value=mock_resp):
            results = _search_serpapi("q", 5)

        assert len(results) == 1
        assert results[0]["url"] == "https://serp.com/1"


# ---------------------------------------------------------------------------
# Tavily provider
# ---------------------------------------------------------------------------


class TestSearchTavily:
    """Tests for ``_search_tavily``."""

    def test_parses_response(self) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "results": [
                {
                    "title": "Tavily 1",
                    "url": "https://tavily.com/1",
                    "content": "Tavily content",
                },
            ],
        }
        env = {"TAVILY_API_KEY": "test-key"}
        with patch.dict("os.environ", env), \
             patch("httpx.post", return_value=mock_resp):
            results = _search_tavily("q", 5)

        assert len(results) == 1
        assert results[0]["snippet"] == "Tavily content"


# ---------------------------------------------------------------------------
# web_search @tool function
# ---------------------------------------------------------------------------


class TestWebSearchTool:
    """Tests for the ``web_search`` decorated tool function."""

    def test_has_tool_schema(self) -> None:
        assert hasattr(web_search, "_tool_schema")
        schema = web_search._tool_schema
        assert schema["name"] == "web_search"
        assert "query" in schema["parameters"]["properties"]

    def test_returns_formatted_results(self) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "web": {
                "results": [
                    {
                        "title": "Flight Deal",
                        "url": "https://flights.com",
                        "description": "Great business class deal",
                    },
                ],
            },
        }
        env = {"BRAVE_API_KEY": "test-key"}
        with patch.dict("os.environ", env, clear=True), \
             patch("httpx.get", return_value=mock_resp):
            output = web_search("business class LHR to Tokyo")

        assert "Flight Deal" in output
        assert "https://flights.com" in output
        assert "Great business class deal" in output

    def test_returns_no_results_message(self) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"web": {"results": []}}
        env = {"BRAVE_API_KEY": "test-key"}
        with patch.dict("os.environ", env, clear=True), \
             patch("httpx.get", return_value=mock_resp):
            output = web_search("impossible query xyz")

        assert "No results found" in output

    def test_returns_error_message_on_failure(self) -> None:
        env = {"BRAVE_API_KEY": "test-key"}
        with patch.dict("os.environ", env, clear=True), \
             patch("httpx.get", side_effect=RuntimeError("timeout")):
            output = web_search("test")

        assert "Web search failed" in output

    def test_raises_when_no_provider(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            with pytest.raises(SynthConfigError, match="No web search"):
                web_search("test")

    def test_limit_parameter_optional(self) -> None:
        schema = web_search._tool_schema
        required = schema["parameters"]["required"]
        assert "query" in required
        assert "limit" not in required
