"""Unit tests for ``synth.cli.deploy_cmd`` — Deploy_Wizard stage runner.

Covers stage execution order, ``[  OK  ]``/``[FAIL]`` formatting,
dry-run mode, halt-on-failure behaviour, and the success summary.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

import click
from synth.cli.deploy_cmd import (
    StageResult,
    _print_stage_result,
    _stage_credentials,
    _stage_dependencies,
    _stage_manifest,
    _stage_package,
    _stage_submit,
    _stage_validate_file,
    _read_agentcore_yaml,
    run_deploy,
)
from synth.errors import SynthConfigError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@dataclass
class _FakeCreds:
    source: str
    account_id: str
    profile_name: str | None


def _make_fake_agent(model: str = "claude-test") -> MagicMock:
    agent = MagicMock()
    agent.model = model
    return agent


def _make_manifest(name: str = "test_agent") -> dict:
    return {"name": name, "description": "Test", "actions": [{"name": "invoke"}]}


# ---------------------------------------------------------------------------
# StageResult
# ---------------------------------------------------------------------------


class TestStageResult:
    def test_defaults(self) -> None:
        r = StageResult(success=True, message="ok")
        assert r.suggestion is None
        assert r.data is None

    def test_failure_with_suggestion(self) -> None:
        r = StageResult(success=False, message="bad", suggestion="fix it")
        assert not r.success
        assert r.suggestion == "fix it"


# ---------------------------------------------------------------------------
# _print_stage_result
# ---------------------------------------------------------------------------


class TestPrintStageResult:
    def _capture(self, stage_name: str, result: StageResult, dry_run: bool = False) -> str:
        output: list[str] = []
        with patch("click.echo", side_effect=lambda s, **kw: output.append(str(s))):
            _print_stage_result(stage_name, result, dry_run=dry_run)
        return "\n".join(output)

    def test_success_contains_ok_prefix(self) -> None:
        out = self._capture("My stage", StageResult(success=True, message="done"))
        assert "[  OK  ]" in out
        assert "My stage" in out
        assert "done" in out

    def test_failure_contains_fail_prefix(self) -> None:
        out = self._capture("My stage", StageResult(success=False, message="oops", suggestion="fix"))
        assert "[FAIL]" in out
        assert "My stage" in out
        assert "oops" in out

    def test_failure_prints_suggestion(self) -> None:
        out = self._capture("S", StageResult(success=False, message="m", suggestion="do this"))
        assert "do this" in out

    def test_dry_run_prefix_on_success(self) -> None:
        out = self._capture("S", StageResult(success=True, message="ok"), dry_run=True)
        assert "[DRY RUN]" in out
        assert "[  OK  ]" in out

    def test_dry_run_prefix_on_failure(self) -> None:
        out = self._capture("S", StageResult(success=False, message="bad", suggestion="x"), dry_run=True)
        assert "[DRY RUN]" in out
        assert "[FAIL]" in out

    def test_no_dry_run_prefix_when_false(self) -> None:
        out = self._capture("S", StageResult(success=True, message="ok"), dry_run=False)
        assert "[DRY RUN]" not in out


# ---------------------------------------------------------------------------
# _stage_credentials
# ---------------------------------------------------------------------------


class TestStageCredentials:
    # Patch at the source module since the import is lazy inside the function
    _RESOLVER = "synth.deploy.agentcore.credentials.CredentialResolver"

    def _mock_resolver(self, creds=None, profile_creds=None) -> MagicMock:
        mock = MagicMock()
        inst = mock.return_value
        inst.resolve.return_value = creds
        inst.resolve_profile.return_value = profile_creds if profile_creds is not None else creds
        inst.mask_account_id.return_value = "****1234"
        return mock

    def test_success_with_env_credentials(self) -> None:
        creds = _FakeCreds("env", "123456781234", None)
        with patch(self._RESOLVER, self._mock_resolver(creds)):
            result = _stage_credentials(None)
        assert result.success
        assert "****1234" in result.message

    def test_success_with_named_profile(self) -> None:
        creds = _FakeCreds("profile:myprofile", "123456781234", "myprofile")
        mock = self._mock_resolver(creds, profile_creds=creds)
        with patch(self._RESOLVER, mock):
            result = _stage_credentials("myprofile")
        assert result.success
        assert "myprofile" in result.message

    def test_failure_when_no_credentials(self) -> None:
        with patch(self._RESOLVER, self._mock_resolver(None)):
            result = _stage_credentials(None)
        assert not result.success
        assert result.suggestion is not None
        assert "aws configure" in result.suggestion.lower()

    def test_failure_when_named_profile_not_found(self) -> None:
        mock = MagicMock()
        mock.return_value.resolve_profile.return_value = None
        with patch(self._RESOLVER, mock):
            result = _stage_credentials("missing-profile")
        assert not result.success
        assert "missing-profile" in result.message

    def test_synth_config_error_returns_failure(self) -> None:
        mock = MagicMock()
        mock.return_value.resolve.side_effect = SynthConfigError(
            "no creds", component="CredentialResolver", suggestion="run aws configure"
        )
        with patch(self._RESOLVER, mock):
            result = _stage_credentials(None)
        assert not result.success

    def test_import_error_handled(self) -> None:
        # Simulate ImportError by making the credentials module unavailable
        import synth.deploy.agentcore.credentials as creds_mod
        with patch.object(creds_mod, "CredentialResolver", side_effect=ImportError("no boto3")):
            result = _stage_credentials(None)
        assert not result.success


# ---------------------------------------------------------------------------
# _stage_dependencies
# ---------------------------------------------------------------------------


class TestStageDependencies:
    def test_success_when_adapter_importable(self) -> None:
        mock_adapter = MagicMock()
        with patch.dict("sys.modules", {"synth.deploy.agentcore.adapter": mock_adapter}):
            result = _stage_dependencies()
        assert result.success

    def test_failure_when_adapter_not_installed(self) -> None:
        with patch("builtins.__import__", side_effect=ImportError("no agentcore")):
            result = _stage_dependencies()
        assert not result.success
        assert "pip install" in result.suggestion


# ---------------------------------------------------------------------------
# _stage_validate_file
# ---------------------------------------------------------------------------


class TestStageValidateFile:
    def test_failure_when_file_not_found(self, tmp_path) -> None:
        result = _stage_validate_file(str(tmp_path / "nonexistent.py"))
        assert not result.success
        assert "not found" in result.message.lower()

    def test_success_when_agent_loads(self, tmp_path) -> None:
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("from unittest.mock import MagicMock\nagent = MagicMock()\nagent.model = 'test'\n")
        result = _stage_validate_file(str(agent_file))
        assert result.success
        assert result.data is not None

    def test_failure_when_no_agent_variable(self, tmp_path) -> None:
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("x = 1\n")
        result = _stage_validate_file(str(agent_file))
        assert not result.success


# ---------------------------------------------------------------------------
# _stage_manifest
# ---------------------------------------------------------------------------


class TestStageManifest:
    def test_success_returns_manifest(self) -> None:
        agent = _make_fake_agent()
        with patch("synth.deploy.agentcore.manifest.generate_manifest", return_value=_make_manifest()):
            result = _stage_manifest(agent)
        assert result.success
        assert result.data is not None
        assert "1 action" in result.message

    def test_failure_on_synth_config_error(self) -> None:
        agent = _make_fake_agent()
        with patch(
            "synth.deploy.agentcore.manifest.generate_manifest",
            side_effect=SynthConfigError("bad", component="X", suggestion="fix"),
        ):
            result = _stage_manifest(agent)
        assert not result.success

    def test_failure_on_unexpected_error(self) -> None:
        agent = _make_fake_agent()
        with patch("synth.deploy.agentcore.manifest.generate_manifest", side_effect=RuntimeError("boom")):
            result = _stage_manifest(agent)
        assert not result.success
        assert result.suggestion is not None


# ---------------------------------------------------------------------------
# _stage_package
# ---------------------------------------------------------------------------


class TestStagePackage:
    def test_skipped_in_dry_run(self) -> None:
        agent = _make_fake_agent()
        result = _stage_package(agent, dry_run=True)
        assert result.success
        assert "dry-run" in result.message.lower() or "skipped" in result.message.lower()

    def test_success_when_package_succeeds(self) -> None:
        agent = _make_fake_agent()
        with patch("synth.deploy.packager.package", return_value=_make_manifest()):
            result = _stage_package(agent, dry_run=False)
        assert result.success

    def test_failure_on_synth_config_error(self) -> None:
        agent = _make_fake_agent()
        with patch(
            "synth.deploy.packager.package",
            side_effect=SynthConfigError("cred found", component="Packager", suggestion="remove creds"),
        ):
            result = _stage_package(agent, dry_run=False)
        assert not result.success
        assert result.suggestion is not None


# ---------------------------------------------------------------------------
# _stage_submit
# ---------------------------------------------------------------------------


class TestStageSubmit:
    def test_skipped_in_dry_run(self) -> None:
        result = _stage_submit(_make_manifest(), "us-east-1", "claude-test", dry_run=True)
        assert result.success
        assert "dry-run" in result.message.lower() or "skipped" in result.message.lower()

    def test_failure_when_cli_not_found(self) -> None:
        """Returns failure when the agentcore CLI binary is not on PATH."""
        with patch("shutil.which", return_value=None):
            result = _stage_submit(_make_manifest(), "us-east-1", "claude-test", dry_run=False)
        assert not result.success
        assert "pip install" in result.suggestion

    def test_failure_on_configure_error(self) -> None:
        """Returns failure when 'agentcore configure' exits non-zero."""
        failed_result = MagicMock()
        failed_result.returncode = 1
        failed_result.stderr = "bad config"
        failed_result.stdout = ""

        with patch("shutil.which", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", return_value=failed_result):
            result = _stage_submit(_make_manifest(), "us-east-1", "claude-test", dry_run=False)
        assert not result.success
        assert result.suggestion is not None

    def test_success_returns_deployed_message(self) -> None:
        """Returns success when both configure and launch succeed."""
        ok_result = MagicMock()
        ok_result.returncode = 0
        ok_result.stdout = "ok"
        ok_result.stderr = ""

        with patch("shutil.which", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", return_value=ok_result):
            result = _stage_submit(
                _make_manifest(), "us-east-1", "claude-test", dry_run=False,
            )
        assert result.success
        assert "deployed" in result.message.lower()


# ---------------------------------------------------------------------------
# run_deploy — full wizard integration via CliRunner
# ---------------------------------------------------------------------------

_SHUTIL_WHICH_PATH = "synth.cli.deploy_cmd.shutil.which"
_SUBPROCESS_RUN_PATH = "synth.cli.deploy_cmd.subprocess.run"
_CREDS_PATH = "synth.deploy.agentcore.credentials.CredentialResolver"
_MANIFEST_PATH = "synth.deploy.agentcore.manifest.generate_manifest"
_PACKAGE_PATH = "synth.deploy.packager.package"
_BOTO3_CLIENT_PATH = "synth.cli.deploy_cmd._boto3_client"


def _successful_subprocess_result(
    agent_name: str = "test-agent",
    region: str = "us-east-1",
) -> MagicMock:
    """Create a mock subprocess.CompletedProcess for a successful CLI run."""
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stdout = f"Agent '{agent_name}' deployed to {region}."
    mock_result.stderr = ""
    return mock_result


def _make_deploy_cli() -> click.BaseCommand:
    """Wrap ``run_deploy`` in a Click command for CliRunner testing."""
    @click.command()
    @click.option("--target", default="agentcore")
    @click.option("--dry-run", is_flag=True)
    @click.argument("file", required=False)
    def cmd(target, dry_run, file):
        run_deploy(target, dry_run, file)
    return cmd


class TestRunDeployWizard:
    """Integration tests for the full Deploy_Wizard stage runner."""

    def test_unknown_target_exits_nonzero(self, tmp_path) -> None:
        runner = CliRunner()
        result = runner.invoke(_make_deploy_cli(), ["--target", "unknown", str(tmp_path / "a.py")])
        assert result.exit_code != 0

    def test_missing_file_exits_nonzero(self) -> None:
        runner = CliRunner()
        result = runner.invoke(_make_deploy_cli(), ["--target", "agentcore"])
        assert result.exit_code != 0

    def test_stage_execution_order_all_succeed(self, tmp_path) -> None:
        """All six stages run in order when all succeed."""
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(
            "from unittest.mock import MagicMock\nagent = MagicMock()\nagent.model='x'\n"
        )

        fake_creds = _FakeCreds("env", "123456781234", None)
        mock_resolver = MagicMock()
        mock_resolver.return_value.resolve.return_value = fake_creds
        mock_resolver.return_value.mask_account_id.return_value = "****1234"

        fake_manifest = _make_manifest()
        mock_client = MagicMock()
        mock_client.create_agent.return_value = {
            "agentArn": "arn:aws:bedrock:us-east-1::agent/XYZ"
        }

        runner = CliRunner()
        with patch(_CREDS_PATH, mock_resolver), \
             patch(_MANIFEST_PATH, return_value=fake_manifest), \
             patch(_PACKAGE_PATH, return_value=fake_manifest), \
             patch("shutil.which", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", return_value=_successful_subprocess_result()):
            result = runner.invoke(
                _make_deploy_cli(), ["--target", "agentcore", str(agent_file)]
            )

        assert result.exit_code == 0, result.output
        assert "[  OK  ]" in result.output
        assert "Deployment complete" in result.output

    def test_halt_on_stage1_failure(self, tmp_path) -> None:
        """When stage 1 (credentials) fails, no subsequent stages run."""
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(
            "from unittest.mock import MagicMock\nagent = MagicMock()\n"
        )

        mock_resolver = MagicMock()
        mock_resolver.return_value.resolve.return_value = None
        manifest_mock = MagicMock()

        runner = CliRunner()
        with patch(_CREDS_PATH, mock_resolver), \
             patch(_MANIFEST_PATH, manifest_mock):
            result = runner.invoke(
                _make_deploy_cli(), ["--target", "agentcore", str(agent_file)]
            )

        assert result.exit_code != 0
        assert "[FAIL]" in result.output
        # generate_manifest should NOT have been called (stage 4 never reached)
        manifest_mock.assert_not_called()

    def test_halt_on_stage3_failure(self, tmp_path) -> None:
        """When stage 3 (file validation) fails, stages 4-6 do not run."""
        nonexistent = str(tmp_path / "missing.py")

        fake_creds = _FakeCreds("env", "123456781234", None)
        mock_resolver = MagicMock()
        mock_resolver.return_value.resolve.return_value = fake_creds
        mock_resolver.return_value.mask_account_id.return_value = "****1234"

        manifest_mock = MagicMock()

        runner = CliRunner()
        with patch(_CREDS_PATH, mock_resolver), \
             patch(_MANIFEST_PATH, manifest_mock):
            result = runner.invoke(
                _make_deploy_cli(), ["--target", "agentcore", nonexistent]
            )

        assert result.exit_code != 0
        assert "[FAIL]" in result.output
        manifest_mock.assert_not_called()

    def test_dry_run_runs_only_stages_1_to_4(self, tmp_path) -> None:
        """``--dry-run`` executes stages 1–4 only; package and submit are skipped."""
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(
            "from unittest.mock import MagicMock\nagent = MagicMock()\nagent.model='x'\n"
        )

        fake_creds = _FakeCreds("env", "123456781234", None)
        mock_resolver = MagicMock()
        mock_resolver.return_value.resolve.return_value = fake_creds
        mock_resolver.return_value.mask_account_id.return_value = "****1234"

        fake_manifest = _make_manifest()
        package_mock = MagicMock(return_value=fake_manifest)
        boto3_mock = MagicMock()

        runner = CliRunner()
        with patch(_CREDS_PATH, mock_resolver), \
             patch(_MANIFEST_PATH, return_value=fake_manifest), \
             patch(_PACKAGE_PATH, package_mock), \
             patch(_BOTO3_CLIENT_PATH, boto3_mock):
            result = runner.invoke(
                _make_deploy_cli(), ["--target", "agentcore", "--dry-run", str(agent_file)]
            )

        assert result.exit_code == 0, result.output
        # package() must NOT have been called (stage 5 skipped)
        package_mock.assert_not_called()
        # boto3 client must NOT have been called (stage 6 skipped)
        boto3_mock.assert_not_called()

    def test_dry_run_prefix_in_output(self, tmp_path) -> None:
        """``[DRY RUN]`` prefix appears in output when --dry-run is set."""
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(
            "from unittest.mock import MagicMock\nagent = MagicMock()\nagent.model='x'\n"
        )

        fake_creds = _FakeCreds("env", "123456781234", None)
        mock_resolver = MagicMock()
        mock_resolver.return_value.resolve.return_value = fake_creds
        mock_resolver.return_value.mask_account_id.return_value = "****1234"

        runner = CliRunner()
        with patch(_CREDS_PATH, mock_resolver), \
             patch(_MANIFEST_PATH, return_value=_make_manifest()):
            result = runner.invoke(
                _make_deploy_cli(), ["--target", "agentcore", "--dry-run", str(agent_file)]
            )

        assert result.exit_code == 0, result.output
        assert "[DRY RUN]" in result.output

    def test_success_summary_contains_arn_region_model(self, tmp_path) -> None:
        """Success summary includes agent ARN, region, and model ID."""
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(
            "from unittest.mock import MagicMock\nagent = MagicMock()\nagent.model='x'\n"
        )
        # Write agentcore.yaml so region/model are read
        (tmp_path / "agentcore.yaml").write_text(
            "aws_region: eu-west-1\nmodel_id: anthropic.claude-3-5-haiku-20241022-v1:0\n"
        )

        fake_creds = _FakeCreds("env", "123456781234", None)
        mock_resolver = MagicMock()
        mock_resolver.return_value.resolve.return_value = fake_creds
        mock_resolver.return_value.mask_account_id.return_value = "****1234"

        fake_manifest = _make_manifest()
        mock_client = MagicMock()
        mock_client.create_agent.return_value = {
            "agentArn": "arn:aws:bedrock:eu-west-1::agent/ABC"
        }

        runner = CliRunner()
        with patch(_CREDS_PATH, mock_resolver), \
             patch(_MANIFEST_PATH, return_value=fake_manifest), \
             patch(_PACKAGE_PATH, return_value=fake_manifest), \
             patch("shutil.which", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", return_value=_successful_subprocess_result()):
            result = runner.invoke(
                _make_deploy_cli(), ["--target", "agentcore", str(agent_file)]
            )

        assert result.exit_code == 0, result.output
        # The success summary includes region and model from agentcore.yaml
        assert "eu-west-1" in result.output
        assert "anthropic.claude-3-5-haiku-20241022-v1:0" in result.output


# ---------------------------------------------------------------------------
# _read_agentcore_yaml
# ---------------------------------------------------------------------------


class TestReadAgentcoreYaml:
    def test_returns_empty_dict_when_no_yaml(self, tmp_path) -> None:
        agent_file = tmp_path / "agent.py"
        agent_file.touch()
        result = _read_agentcore_yaml(str(agent_file))
        assert result == {}

    def test_reads_aws_region_and_model_id(self, tmp_path) -> None:
        agent_file = tmp_path / "agent.py"
        agent_file.touch()
        (tmp_path / "agentcore.yaml").write_text(
            "aws_region: us-west-2\nmodel_id: amazon.nova-pro-v1:0\n"
        )
        result = _read_agentcore_yaml(str(agent_file))
        assert result.get("aws_region") == "us-west-2"
        assert result.get("model_id") == "amazon.nova-pro-v1:0"

    def test_reads_aws_profile(self, tmp_path) -> None:
        agent_file = tmp_path / "agent.py"
        agent_file.touch()
        (tmp_path / "agentcore.yaml").write_text("aws_profile: my-profile\n")
        result = _read_agentcore_yaml(str(agent_file))
        assert result.get("aws_profile") == "my-profile"

    def test_returns_empty_dict_on_parse_error(self, tmp_path) -> None:
        agent_file = tmp_path / "agent.py"
        agent_file.touch()
        (tmp_path / "agentcore.yaml").write_text(":::invalid yaml:::\n")
        # Should not raise — returns empty dict or partial result
        result = _read_agentcore_yaml(str(agent_file))
        assert isinstance(result, dict)

    def test_falls_back_to_minimal_parser_when_yaml_unavailable(self, tmp_path) -> None:
        """When PyYAML is not installed, the minimal key:value parser is used."""
        agent_file = tmp_path / "agent.py"
        agent_file.touch()
        (tmp_path / "agentcore.yaml").write_text(
            "aws_region: ap-southeast-1\nmodel_id: amazon.nova-lite-v1:0\n"
        )
        with patch.dict("sys.modules", {"yaml": None}):
            result = _read_agentcore_yaml(str(agent_file))
        assert result.get("aws_region") == "ap-southeast-1"
        assert result.get("model_id") == "amazon.nova-lite-v1:0"


# ---------------------------------------------------------------------------
# _parse_yaml_minimal
# ---------------------------------------------------------------------------


class TestParseYamlMinimal:
    """Tests for the no-PyYAML fallback parser."""

    def _parse(self, content: str, tmp_path) -> dict:
        from synth.cli.deploy_cmd import _parse_yaml_minimal
        p = tmp_path / "agentcore.yaml"
        p.write_text(content)
        return _parse_yaml_minimal(p)

    def test_parses_simple_key_value(self, tmp_path) -> None:
        result = self._parse("aws_region: us-east-1\n", tmp_path)
        assert result["aws_region"] == "us-east-1"

    def test_skips_comment_lines(self, tmp_path) -> None:
        result = self._parse("# comment\naws_region: us-west-2\n", tmp_path)
        assert "aws_region" in result
        assert result["aws_region"] == "us-west-2"

    def test_skips_blank_lines(self, tmp_path) -> None:
        result = self._parse("\n\nmodel_id: claude-test\n\n", tmp_path)
        assert result["model_id"] == "claude-test"

    def test_strips_quoted_values(self, tmp_path) -> None:
        result = self._parse('aws_profile: "my-profile"\n', tmp_path)
        assert result["aws_profile"] == "my-profile"

    def test_returns_empty_dict_on_empty_file(self, tmp_path) -> None:
        result = self._parse("", tmp_path)
        assert result == {}


# ---------------------------------------------------------------------------
# Additional branch coverage
# ---------------------------------------------------------------------------


class TestPrintStageResultNoSuggestion:
    """Failure with no suggestion should not print a Suggestion line."""

    def test_failure_without_suggestion_no_suggestion_line(self) -> None:
        output: list[str] = []
        with patch("click.echo", side_effect=lambda s, **kw: output.append(str(s))):
            _print_stage_result("S", StageResult(success=False, message="bad"))
        combined = "\n".join(output)
        assert "[FAIL]" in combined
        assert "Suggestion:" not in combined


class TestStageValidateFileSystemExit:
    """_stage_validate_file handles SystemExit from _load_agent."""

    def test_system_exit_from_load_agent_returns_failure(self, tmp_path) -> None:
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("raise SystemExit(1)\n")
        result = _stage_validate_file(str(agent_file))
        assert not result.success
        assert result.suggestion is not None


class TestStagePackageGenericException:
    """_stage_package wraps unexpected exceptions as failures."""

    def test_generic_exception_returns_failure_with_suggestion(self) -> None:
        agent = _make_fake_agent()
        with patch("synth.deploy.packager.package", side_effect=OSError("disk full")):
            result = _stage_package(agent, dry_run=False)
        assert not result.success
        assert result.suggestion is not None
        assert "disk" in result.suggestion.lower() or "permission" in result.suggestion.lower()


class TestStageSubmitSynthConfigError:
    """_stage_submit handles errors from the AgentCore CLI."""

    def test_launch_failure_returns_failure_with_suggestion(self) -> None:
        """When 'agentcore launch' fails, the result includes a suggestion."""
        configure_ok = MagicMock()
        configure_ok.returncode = 0
        configure_ok.stdout = "ok"
        configure_ok.stderr = ""

        launch_fail = MagicMock()
        launch_fail.returncode = 1
        launch_fail.stderr = "bad config"
        launch_fail.stdout = ""

        with patch("shutil.which", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", side_effect=[configure_ok, launch_fail]):
            result = _stage_submit(
                _make_manifest(), "us-east-1", "claude-test", dry_run=False,
            )
        assert not result.success
        assert result.suggestion is not None


# ---------------------------------------------------------------------------
# _stage_readiness
# ---------------------------------------------------------------------------


class TestStageReadiness:
    """Tests for ``_stage_readiness`` — deployment readiness checks."""

    def _run(self, agent: Any, **kwargs: Any) -> tuple[StageResult, str]:
        from synth.cli.deploy_cmd import _stage_readiness

        output: list[str] = []
        with patch("click.echo", side_effect=lambda s, **kw: output.append(str(s))):
            result = _stage_readiness(
                agent,
                region=kwargs.get("region", "us-east-1"),
                aws_profile=kwargs.get("aws_profile"),
            )
        return result, "\n".join(output)

    def test_always_succeeds(self) -> None:
        agent = MagicMock(spec=[])
        result, _ = self._run(agent)
        assert result.success is True

    def test_reports_aws_profile(self) -> None:
        agent = MagicMock(spec=[])
        _, output = self._run(agent, aws_profile="prod")
        assert "Auth: AWS profile 'prod'" in output

    def test_reports_env_credentials(self) -> None:
        agent = MagicMock(spec=[])
        env = {
            "AWS_ACCESS_KEY_ID": "AKIA...",
            "AWS_SECRET_ACCESS_KEY": "secret",
        }
        with patch.dict("os.environ", env):
            _, output = self._run(agent)
        assert "Auth: environment credentials" in output

    def test_reports_iam_role_when_no_creds(self) -> None:
        agent = MagicMock(spec=[])
        with patch.dict("os.environ", {}, clear=True):
            _, output = self._run(agent)
        assert "Auth: IAM role (runtime)" in output

    def test_reports_memory_class_name(self) -> None:
        from synth.memory.base import Memory

        agent = MagicMock(spec=[])
        agent.memory = Memory.thread()
        _, output = self._run(agent)
        assert "Memory: ThreadMemory" in output

    def test_warns_when_no_memory(self) -> None:
        agent = MagicMock(spec=[])
        agent.memory = None
        with patch.dict("os.environ", {}, clear=True):
            result, output = self._run(agent)
        assert "Memory: not configured" in output
        assert "warning" in result.message.lower()

    def test_reports_agentcore_memory_auto(self) -> None:
        agent = MagicMock(spec=[])
        agent.memory = None
        env = {
            "AGENTCORE_MEMORY_ENDPOINT": "https://mem.example.com",
            "AGENTCORE_MEMORY_ID": "mem-123",
        }
        with patch.dict("os.environ", env, clear=True):
            _, output = self._run(agent)
        assert "AgentCoreMemory (auto-configured)" in output

    def test_reports_guards(self) -> None:
        agent = MagicMock(spec=[])
        g1 = MagicMock()
        g1.name = "PIIGuard"
        g2 = MagicMock()
        g2.name = "CostGuard"
        agent.guards = [g1, g2]
        _, output = self._run(agent)
        assert "Guards: PIIGuard, CostGuard (2)" in output

    def test_warns_when_no_guards(self) -> None:
        agent = MagicMock(spec=[])
        agent.guards = []
        with patch.dict("os.environ", {}, clear=True):
            _, output = self._run(agent)
        assert "Guards: none" in output

    def test_reports_tools(self) -> None:
        agent = MagicMock(spec=[])
        agent._registered_tools = {"search": ..., "calc": ...}
        _, output = self._run(agent)
        assert "Tools: calc, search (2)" in output

    def test_reports_many_tools_truncated(self) -> None:
        agent = MagicMock(spec=[])
        agent._registered_tools = {
            f"tool_{i}": ... for i in range(8)
        }
        _, output = self._run(agent)
        assert "+4 more" in output
        assert "(8)" in output

    def test_reports_no_tools(self) -> None:
        agent = MagicMock(spec=[])
        agent._registered_tools = {}
        _, output = self._run(agent)
        assert "Tools: none" in output

    def test_reports_output_schema(self) -> None:
        from pydantic import BaseModel

        class MyOutput(BaseModel):
            answer: str

        agent = MagicMock(spec=[])
        agent.output_schema = MyOutput
        _, output = self._run(agent)
        assert "Output schema: MyOutput" in output

    def test_reports_target_region_and_model(self) -> None:
        agent = MagicMock(spec=[])
        agent.model = "bedrock/claude-sonnet-4-5"
        _, output = self._run(agent)
        assert "Target: us-east-1 / bedrock/claude-sonnet-4-5" in output

    def test_all_configured_no_warnings(self) -> None:
        from synth.memory.base import Memory

        agent = MagicMock(spec=[])
        agent.memory = Memory.thread()
        g = MagicMock()
        g.name = "PII"
        agent.guards = [g]
        agent._registered_tools = {"search": ...}
        agent.output_schema = None
        agent.model = "bedrock/test"

        result, _ = self._run(agent)
        assert "All components configured" in result.message

    def test_mock_agent_does_not_crash(self) -> None:
        """MagicMock agents (from tests) should not raise."""
        agent = MagicMock()
        agent.model = "x"
        result, _ = self._run(agent)
        assert result.success is True

    def test_warns_web_search_without_api_key(self) -> None:
        agent = MagicMock(spec=[])
        agent._registered_tools = {"web_search": ..., "calc": ...}
        agent.guards = []
        agent.memory = None
        with patch.dict("os.environ", {}, clear=True):
            result, output = self._run(agent)
        assert "Search API: web_search tool found but no API key" in output

    def test_reports_search_api_configured(self) -> None:
        agent = MagicMock(spec=[])
        agent._registered_tools = {"web_search": ...}
        agent.guards = []
        agent.memory = None
        env = {"BRAVE_API_KEY": "test-key"}
        with patch.dict("os.environ", env, clear=True):
            _, output = self._run(agent)
        assert "Search API: configured" in output

    def test_no_search_warning_without_search_tool(self) -> None:
        agent = MagicMock(spec=[])
        agent._registered_tools = {"calc": ...}
        agent.guards = []
        agent.memory = None
        with patch.dict("os.environ", {}, clear=True):
            _, output = self._run(agent)
        assert "Search API" not in output
