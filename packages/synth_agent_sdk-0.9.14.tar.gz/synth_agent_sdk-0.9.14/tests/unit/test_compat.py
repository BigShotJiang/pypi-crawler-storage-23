"""Unit tests for ``synth._compat.run_sync``.

Covers:
- Executing a simple async coroutine from a sync context
- Returning the correct value from the coroutine
- Propagating exceptions raised inside the coroutine
"""

from __future__ import annotations

import pytest

from synth._compat import run_sync


# ---------------------------------------------------------------------------
# Tests: run_sync basic behaviour
# ---------------------------------------------------------------------------


class TestRunSync:
    """Verify ``run_sync()`` bridges async → sync correctly."""

    def test_run_sync_executes_simple_coroutine(self) -> None:
        async def _add(a: int, b: int) -> int:
            return a + b

        assert run_sync(_add(2, 3)) == 5

    def test_run_sync_returns_string(self) -> None:
        async def _greet(name: str) -> str:
            return f"Hello, {name}!"

        assert run_sync(_greet("Synth")) == "Hello, Synth!"

    def test_run_sync_returns_none(self) -> None:
        async def _noop() -> None:
            pass

        assert run_sync(_noop()) is None

    def test_run_sync_propagates_exception(self) -> None:
        async def _fail() -> None:
            raise ValueError("boom")

        with pytest.raises(ValueError, match="boom"):
            run_sync(_fail())

    def test_run_sync_propagates_custom_exception(self) -> None:
        class CustomError(Exception):
            pass

        async def _fail() -> None:
            raise CustomError("custom boom")

        with pytest.raises(CustomError, match="custom boom"):
            run_sync(_fail())

    def test_run_sync_handles_async_with_await(self) -> None:
        """Coroutines that await other coroutines work correctly."""

        async def _inner() -> int:
            return 42

        async def _outer() -> int:
            val = await _inner()
            return val + 1

        assert run_sync(_outer()) == 43
