"""Allow ``python -m synth`` to launch the CLI."""

from synth.cli.main import cli

cli()
