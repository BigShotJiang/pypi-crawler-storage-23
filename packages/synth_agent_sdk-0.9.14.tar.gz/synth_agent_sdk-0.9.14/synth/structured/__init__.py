# Structured output: Pydantic schema enforcement, retry parsing
