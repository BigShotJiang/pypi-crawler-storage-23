"""PersistentMemory — Redis-backed conversation memory.

Stores and retrieves thread history from an external Redis backend
using Redis lists.  The ``redis`` package is lazily imported so that
users who don't need Redis don't pay the import cost or require the
package.
"""

from __future__ import annotations

import json

from synth.errors import SynthConfigError
from synth.memory.base import BaseMemory
from synth.types import Message

try:
    import redis.asyncio as aioredis
except ImportError:
    aioredis = None  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# Key helpers
# ---------------------------------------------------------------------------

_KEY_PREFIX = "synth:thread:"


def _thread_key(thread_id: str) -> str:
    """Build the Redis key for a given thread."""
    return f"{_KEY_PREFIX}{thread_id}"


# ---------------------------------------------------------------------------
# PersistentMemory
# ---------------------------------------------------------------------------


class PersistentMemory(BaseMemory):
    """Redis-backed persistent memory backend.

    Messages are stored as JSON strings in a Redis list keyed by
    ``synth:thread:{thread_id}``.  New messages are appended with
    ``RPUSH`` and the full history is retrieved with ``LRANGE``.

    Parameters
    ----------
    url:
        Redis connection URL, e.g. ``"redis://localhost:6379"``.

    Raises
    ------
    SynthConfigError
        If the ``redis`` package is not installed.

    Examples
    --------
    ::

        mem = PersistentMemory(url="redis://localhost:6379")
        await mem.add_messages("t1", [{"role": "user", "content": "hi"}])
        msgs = await mem.get_messages("t1")
    """

    def __init__(self, url: str) -> None:
        if aioredis is None:
            raise SynthConfigError(
                message=(
                    "Redis package is not installed. "
                    "Run: pip install redis"
                ),
                component="PersistentMemory",
                suggestion="pip install redis",
            )
        self._client = aioredis.from_url(url)

    async def get_messages(self, thread_id: str) -> list[Message]:
        """Retrieve all messages for the given thread from Redis.

        Parameters
        ----------
        thread_id:
            Unique identifier for the conversation thread.

        Returns
        -------
        list[Message]
            Ordered list of messages in the thread, or an empty list if the
            thread does not exist.
        """
        raw = await self._client.lrange(_thread_key(thread_id), 0, -1)
        return [json.loads(m) for m in raw]

    async def add_messages(self, thread_id: str, messages: list[Message]) -> None:
        """Append messages to the given thread in Redis.

        Uses a pipeline with ``RPUSH`` to append all messages atomically.

        Parameters
        ----------
        thread_id:
            Unique identifier for the conversation thread.
        messages:
            Messages to append.
        """
        if not messages:
            return
        key = _thread_key(thread_id)
        pipe = self._client.pipeline()
        for msg in messages:
            pipe.rpush(key, json.dumps(msg))
        await pipe.execute()
