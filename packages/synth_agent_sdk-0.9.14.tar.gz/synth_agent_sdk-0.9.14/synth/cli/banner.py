"""Boot sequence / terminal branding for the Synth SDK.

Displays a Fallout-inspired boot sequence with ASCII art, status lines,
and a flicker effect.  Respects ``SYNTH_NO_BANNER``, ``NO_COLOR``, and
TTY detection.  Displays only once per process.
"""

from __future__ import annotations

import os
import random
import shutil
import sys
import time


# Session-level flag — display only once per process
_DISPLAYED = False


# ---------------------------------------------------------------------------
# ANSI colour helpers
# ---------------------------------------------------------------------------

def _supports_color() -> bool:
    """Check if the terminal supports colour output."""
    if os.environ.get("NO_COLOR"):
        return False
    if not hasattr(sys.stdout, "isatty"):
        return False
    return sys.stdout.isatty()


def _bright_green(text: str, color: bool) -> str:
    """Bright green text."""
    return f"\033[92m{text}\033[0m" if color else text


def _dim_green(text: str, color: bool) -> str:
    """Dim green text."""
    return f"\033[32m{text}\033[0m" if color else text


def _bold_yellow(text: str, color: bool) -> str:
    """Bold yellow text."""
    return f"\033[1;33m{text}\033[0m" if color else text


def _error_badge(text: str, color: bool) -> str:
    """Red background, white text badge."""
    return f"\033[41;97m{text}\033[0m" if color else text


def _bold(text: str, color: bool) -> str:
    """Bold text."""
    return f"\033[1m{text}\033[0m" if color else text


def _dim(text: str, color: bool) -> str:
    """Dim/faint text."""
    return f"\033[2m{text}\033[0m" if color else text


def _cyan(text: str, color: bool) -> str:
    """Cyan text for highlights."""
    return f"\033[96m{text}\033[0m" if color else text


# ---------------------------------------------------------------------------
# Boot sequence
# ---------------------------------------------------------------------------

_LOGO = r"""
  ███████╗██╗   ██╗███╗   ██╗████████╗██╗  ██╗ █████╗  ██████╗ ███████╗███╗   ██╗████████╗███████╗██████╗ ██╗  ██╗
  ██╔════╝╚██╗ ██╔╝████╗  ██║╚══██╔══╝██║  ██║██╔══██╗██╔════╝ ██╔════╝████╗  ██║╚══██╔══╝██╔════╝██╔══██╗██║ ██╔╝
  ███████╗ ╚████╔╝ ██╔██╗ ██║   ██║   ███████║███████║██║  ███╗█████╗  ██╔██╗ ██║   ██║   ███████╗██║  ██║█████╔╝
  ╚════██║  ╚██╔╝  ██║╚██╗██║   ██║   ██╔══██║██╔══██║██║   ██║██╔══╝  ██║╚██╗██║   ██║   ╚════██║██║  ██║██╔═██╗
  ███████║   ██║   ██║ ╚████║   ██║   ██║  ██║██║  ██║╚██████╔╝███████╗██║ ╚████║   ██║   ███████║██████╔╝██║  ██╗
  ╚══════╝   ╚═╝   ╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚══════╝╚═════╝ ╚═╝  ╚═╝
"""

_VAULT_BOY = r"""
        _.---._
       /       \
      |  O   O  |
      |    <    |
       \ '---' /
    .--'`.___.`'--.
   /  #           \
  |   #   VAULT    |
  |   #    101     |
   \  #           /
    '-._________.-'
"""

_SYNTH_BLOCK = "SynthAgentSDK"


def display_boot_sequence() -> None:
    """Display the Synth boot sequence.

    Skips if ``SYNTH_NO_BANNER=1`` is set, or if already displayed
    this session.
    """
    global _DISPLAYED  # noqa: PLW0603

    # Check skip conditions
    if os.environ.get("SYNTH_NO_BANNER") == "1":
        return
    if _DISPLAYED:
        return

    _DISPLAYED = True

    color = _supports_color()
    width = shutil.get_terminal_size((80, 24)).columns

    # Top border
    _print_line(_dim_green("=" * width, color), color)
    _print_line("", color)

    # Logo
    for line in _LOGO.strip().splitlines():
        _print_line(_bright_green(line, color), color)

    # Authentication line
    _print_line("", color)
    _print_line(
        _bright_green("  [ AUTHENTICATION: GRANTED ]", color), color,
    )

    # Bottom border
    _print_line(_dim_green("=" * width, color), color)

    # Boot status lines
    _delay()
    _print_line(
        f"  {_bright_green('[   OK   ]', color)} Agent kernel initialised",
        color,
    )
    _delay()
    _print_line(
        f"  {_bright_green('[   OK   ]', color)} Vector embeddings loaded",
        color,
    )
    _delay()
    _print_line(
        f"  {_bright_green('[   OK   ]', color)} Tool-use permissions granted",
        color,
    )

    # ERROR line with flicker
    _delay()
    error_line = (
        f"  {_error_badge('[ ERROR  ]', color)} "
        f"{_bold_yellow('Memory leak in sector 7G — non-critical', color)}"
    )
    if color:
        # Flicker effect: 3 rapid bold toggles
        for _ in range(3):
            sys.stdout.write(f"\r{_bold(error_line, color)}")
            sys.stdout.flush()
            time.sleep(0.05)
            sys.stdout.write(f"\r{error_line}")
            sys.stdout.flush()
            time.sleep(0.05)
        # Clear the flicker line before printing final version
        sys.stdout.write(f"\r{' ' * width}\r")
        sys.stdout.flush()
    _print_line(error_line, color)

    # System ready
    _delay()
    _print_line(
        f"  {_bright_green('>> SYSTEM READY', color)}", color,
    )

    # Closing divider
    _print_line(_dim_green("-" * width, color), color)
    _print_line("", color)

    # Getting started hints
    _print_line(
        f"  {_bright_green('Autonomous agents, engineered.', color)}",
        color,
    )
    try:
        import importlib.metadata as _meta
        _ver = _meta.version("synth-agent-sdk")
    except Exception:  # noqa: BLE001
        _ver = "unknown"
    _print_line(
        f"  {_dim(f'v{_ver}', color)}",
        color,
    )
    _print_line("", color)
    _print_line(
        f"  {_cyan('Get started:', color)}",
        color,
    )
    _print_line(
        f"    {_dim('$', color)} synth create agent my-bot",
        color,
    )
    _print_line(
        f"    {_dim('$', color)} synth run my-bot/agent.py {_dim('\"Hello\"', color)}",
        color,
    )
    _print_line(
        f"    {_dim('$', color)} synth dev my-bot/agent.py",
        color,
    )
    _print_line(
        f"    {_dim('$', color)} synth help",
        color,
    )
    _print_line("", color)
    _print_line(
        f"  {_cyan('Docs:', color)} https://github.com/synth-agent-sdk",
        color,
    )
    _print_line(
        f"  {_dim('Set SYNTH_NO_BANNER=1 to suppress this message.', color)}",
        color,
    )
    _print_line("", color)


def _print_line(text: str, color: bool) -> None:
    """Print a line to stdout."""
    print(text)


def _delay() -> None:
    """Randomised delay between 40–120ms."""
    time.sleep(random.uniform(0.04, 0.12))
