"""CLI: synth dev, run, eval, trace, deploy, doctor, create, help."""

from synth.cli.main import cli

__all__ = ["cli"]
