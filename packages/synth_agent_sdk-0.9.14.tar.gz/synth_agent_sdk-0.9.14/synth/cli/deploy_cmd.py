"""``synth deploy`` command — deploy agent to a target platform.

Implements the Deploy_Wizard: a sequential stage runner that validates
prerequisites, resolves credentials, packages the agent, and submits to
the AgentCore API.  Each stage prints ``[  OK  ]`` or ``[FAIL]`` and the
wizard halts on the first failure.

Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import click

from synth.errors import SynthConfigError


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class StageResult:
    """Result from a single Deploy_Wizard stage.

    Parameters
    ----------
    success:
        Whether the stage completed successfully.
    message:
        Human-readable status message.
    suggestion:
        Corrective action to display on failure.  Should be non-empty when
        ``success`` is ``False`` (Requirement 2.3).
    data:
        Optional payload passed between stages (e.g. loaded agent, manifest).
    """

    success: bool
    message: str
    suggestion: str | None = None
    data: Any = field(default=None, repr=False)


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


def _print_stage_result(
    stage_name: str,
    result: StageResult,
    *,
    dry_run: bool = False,
) -> None:
    """Print a ``[  OK  ]`` or ``[FAIL]`` line for *stage_name*.

    Parameters
    ----------
    stage_name:
        Display name of the stage (e.g. ``"Credential validation"``).
    result:
        The ``StageResult`` returned by the stage function.
    dry_run:
        When ``True``, prefix the line with ``[DRY RUN]`` (Requirement 2.7).
    """
    prefix = click.style("[DRY RUN] ", fg="cyan") if dry_run else ""

    if result.success:
        status = click.style("[  OK  ]", fg="green")
        click.echo(f"  {prefix}{status} {stage_name}: {result.message}")
    else:
        status = click.style("[FAIL]", fg="red")
        click.echo(f"  {prefix}{status}  {stage_name}: {result.message}")
        if result.suggestion:
            click.echo(
                f"         {click.style('Suggestion:', fg='yellow')} {result.suggestion}"
            )


# ---------------------------------------------------------------------------
# Stage functions
# ---------------------------------------------------------------------------


def _stage_credentials(profile: str | None) -> StageResult:
    """Stage 1 — Validate AWS credentials (Requirement 2.4, 2.5).

    Parameters
    ----------
    profile:
        Named AWS profile from ``agentcore.yaml``, or ``None`` to use the
        default credential chain.

    Returns
    -------
    StageResult
        Success with masked account ID, or failure with instructions.
    """
    try:
        from synth.deploy.agentcore.credentials import CredentialResolver

        resolver = CredentialResolver()

        # If a named profile is configured, try it first (Requirement 7.2)
        creds = None
        if profile:
            creds = resolver.resolve_profile(profile)
            if creds is None:
                return StageResult(
                    success=False,
                    message=f"Profile '{profile}' not found.",
                    suggestion=(
                        f"Ensure '{profile}' exists in ~/.aws/credentials "
                        "or run: aws configure --profile " + profile
                    ),
                )

        if creds is None:
            creds = resolver.resolve()

        if creds is None:
            return StageResult(
                success=False,
                message="No AWS credentials found.",
                suggestion=(
                    "Run: aws configure  or  pip install awscli && aws configure"
                ),
            )

        masked = resolver.mask_account_id(creds.account_id)
        profile_info = f" (profile: {creds.profile_name})" if creds.profile_name else ""
        return StageResult(
            success=True,
            message=f"Account {masked} via {creds.source}{profile_info}",
            data=creds,
        )

    except SynthConfigError as exc:
        return StageResult(
            success=False,
            message=str(exc),
            suggestion=exc.suggestion,
        )
    except Exception as exc:
        return StageResult(
            success=False,
            message=f"Credential check failed: {exc}",
            suggestion="Run: aws configure",
        )


def _stage_dependencies() -> StageResult:
    """Stage 2 — Check that ``synth[agentcore]`` is installed (Requirement 2.1).

    Returns
    -------
    StageResult
        Success if the AgentCore adapter can be imported, failure otherwise.
    """
    try:
        from synth.deploy.agentcore.adapter import AgentCoreAdapter  # noqa: F401

        return StageResult(
            success=True,
            message="synth[agentcore] is installed.",
        )
    except ImportError:
        return StageResult(
            success=False,
            message="synth[agentcore] is not installed.",
            suggestion="Run: pip install synth-agent-sdk[agentcore]",
        )


def _stage_validate_file(file: str) -> StageResult:
    """Stage 3 — Load and validate the agent file (Requirement 2.1).

    Parameters
    ----------
    file:
        Path to the agent Python file.

    Returns
    -------
    StageResult
        Success with the loaded agent object, or failure with details.
    """
    if not Path(file).exists():
        return StageResult(
            success=False,
            message=f"File not found: {file}",
            suggestion=f"Check the path and try again: {file}",
        )

    try:
        import sys

        from synth.cli.run_cmd import _load_agent

        # Add the agent file's directory to sys.path so local imports
        # (e.g. "from tools import ...") resolve correctly.
        agent_dir = str(Path(file).resolve().parent)
        if agent_dir not in sys.path:
            sys.path.insert(0, agent_dir)

        agent = _load_agent(file)
        model = getattr(agent, "model", "unknown")
        return StageResult(
            success=True,
            message=f"Agent loaded (model: {model})",
            data=agent,
        )
    except SystemExit:
        return StageResult(
            success=False,
            message=f"Failed to load agent from '{file}'.",
            suggestion="Ensure the file defines an 'agent' variable.",
        )
    except Exception as exc:
        return StageResult(
            success=False,
            message=f"Agent file error: {exc}",
            suggestion="Ensure the file defines an 'agent' variable.",
        )


def _stage_manifest(agent: Any, agent_name: str | None = None) -> StageResult:
    """Stage 4 — Generate the AgentCore manifest (Requirement 2.1).

    Parameters
    ----------
    agent:
        The loaded Synth Agent or Graph instance.
    agent_name:
        Optional agent name override from ``agentcore.yaml``.

    Returns
    -------
    StageResult
        Success with the manifest dict, or failure with details.
    """
    try:
        from synth.deploy.agentcore.manifest import generate_manifest

        # Sanitize user-provided name before passing to manifest
        if agent_name:
            from synth.deploy.agentcore.manifest import _sanitize_for_path

            sanitized = _sanitize_for_path(agent_name)
            if sanitized != agent_name:
                click.echo(click.style(
                    f"  Agent name sanitized: '{agent_name}' → "
                    f"'{sanitized}'",
                    dim=True,
                ))
                agent_name = sanitized

        manifest = generate_manifest(agent, name=agent_name)

        # Validate the final name meets AgentCore requirements
        import re

        final_name = manifest.get("name", "")
        if not re.fullmatch(r"[a-zA-Z][a-zA-Z0-9_]{0,47}", final_name):
            return StageResult(
                success=False,
                message=(
                    f"Agent name '{final_name}' is invalid for "
                    "AgentCore."
                ),
                suggestion=(
                    "Agent names must start with a letter, contain "
                    "only letters/numbers/underscores, and be 1–48 "
                    "characters. Set 'agent_name' in agentcore.yaml."
                ),
            )

        action_count = len(manifest.get("actions", []))
        return StageResult(
            success=True,
            message=f"Manifest generated ({action_count} action(s)).",
            data=manifest,
        )
    except SynthConfigError as exc:
        return StageResult(
            success=False,
            message=str(exc),
            suggestion=exc.suggestion,
        )
    except Exception as exc:
        return StageResult(
            success=False,
            message=f"Manifest generation failed: {exc}",
            suggestion="Check agent configuration and try again.",
        )

def _stage_dockerfile_validation(
    agent_name: str,
    file: str,
) -> StageResult:
    """Validate that the agent name matches a ``.bedrock_agentcore/`` folder.

    Resolves the ``.bedrock_agentcore/`` directory relative to the agent
    file's parent directory.  If the directory does not exist, validation
    is skipped (Requirement 6.5).  If it exists but contains no folder
    matching *agent_name*, the stage fails with the available folder names
    listed as suggestions (Requirements 6.2, 6.3).

    Parameters
    ----------
    agent_name:
        The agent name from ``agentcore.yaml`` or manifest generation.
    file:
        Path to the agent Python file.

    Returns
    -------
    StageResult
        Success when the folder matches or the directory is absent,
        failure with available folder names when there is a mismatch.
    """
    agentcore_dir = Path(file).resolve().parent / ".bedrock_agentcore"

    if not agentcore_dir.is_dir():
        return StageResult(
            success=True,
            message="Skipped (.bedrock_agentcore/ not found).",
        )

    folders = sorted(
        entry.name
        for entry in agentcore_dir.iterdir()
        if entry.is_dir()
    )

    if agent_name in folders:
        return StageResult(
            success=True,
            message=f"Dockerfile folder matches agent name '{agent_name}'.",
        )

    available = ", ".join(folders) if folders else "(none)"
    return StageResult(
        success=False,
        message=(
            f"Agent name '{agent_name}' does not match any folder "
            f"in .bedrock_agentcore/."
        ),
        suggestion=(
            f"Available folders: {available}. Rename the folder to "
            f"'{agent_name}' or update 'agent_name' in agentcore.yaml "
            f"to match an existing folder."
        ),
    )



def _stage_package(agent: Any, dry_run: bool) -> StageResult:
    """Stage 5 — Package the deployment artifact (Requirement 2.1).

    Skipped in dry-run mode (Requirement 2.7).

    Parameters
    ----------
    agent:
        The loaded Synth Agent or Graph instance.
    dry_run:
        When ``True``, this stage is skipped.

    Returns
    -------
    StageResult
        Success with the manifest, or failure with details.
    """
    if dry_run:
        return StageResult(
            success=True,
            message="Skipped (dry-run mode).",
        )

    try:
        from synth.deploy.packager import package

        manifest = package(agent, dry_run=False)
        return StageResult(
            success=True,
            message="Deployment artifact created in dist/.",
            data=manifest,
        )
    except SynthConfigError as exc:
        return StageResult(
            success=False,
            message=str(exc),
            suggestion=exc.suggestion,
        )
    except Exception as exc:
        return StageResult(
            success=False,
            message=f"Packaging failed: {exc}",
            suggestion="Check file permissions and available disk space.",
        )


def _boto3_client(service: str, region: str) -> Any:
    """Create a boto3 client — extracted for testability.

    Parameters
    ----------
    service:
        AWS service name (e.g. ``"bedrock-agentcore"``).
    region:
        AWS region string.

    Returns
    -------
    Any
        A boto3 service client.

    Raises
    ------
    ImportError
        If boto3 is not installed.
    """
    import boto3  # type: ignore[import-untyped]

    return boto3.client(service, region_name=region)


def _stage_submit(
    manifest: dict[str, Any],
    region: str,
    model_id: str,
    dry_run: bool,
    file: str | None = None,
    aws_profile: str | None = None,
) -> StageResult:
    """Stage 6 — Deploy via the AgentCore CLI (Requirement 2.1, 2.6).

    Runs ``agentcore configure`` followed by ``agentcore launch`` to
    deploy the agent to AgentCore Runtime.  Skipped in dry-run mode
    (Requirement 2.7).

    Parameters
    ----------
    manifest:
        The generated agent manifest.
    region:
        AWS region for deployment.
    model_id:
        Bedrock model ID used by the agent.
    dry_run:
        When ``True``, this stage is skipped.
    file:
        Path to the agent Python file.
    aws_profile:
        Named AWS profile to pass to the AgentCore CLI via
        ``AWS_PROFILE`` environment variable.

    Returns
    -------
    StageResult
        Success with deployment info, or failure with details.
    """
    if dry_run:
        return StageResult(
            success=True,
            message="Skipped (dry-run mode).",
        )

    import shutil
    import subprocess

    # Find the agentcore CLI — try PATH first, then look in the same
    # Scripts/bin directory as the current Python interpreter (handles
    # pipx venvs where injected CLIs aren't on the system PATH).
    agentcore_bin = shutil.which("agentcore")
    if not agentcore_bin:
        scripts_dir = Path(sys.executable).parent
        candidate = scripts_dir / ("agentcore.exe" if sys.platform == "win32" else "agentcore")
        if candidate.exists():
            agentcore_bin = str(candidate)

    if not agentcore_bin:
        return StageResult(
            success=False,
            message="AgentCore CLI not found.",
            suggestion=(
                "Install it with: "
                "pip install bedrock-agentcore-starter-toolkit"
            ),
        )

    agent_name = manifest.get("name", "synth_agent")
    entrypoint = file or "agent.py"

    # Build environment for the subprocess — inherit current env and
    # inject the AWS profile so the AgentCore CLI authenticates correctly.
    import os as _os

    sub_env = _os.environ.copy()
    if aws_profile:
        sub_env["AWS_PROFILE"] = aws_profile
    # Prevent unicode errors from AgentCore CLI emoji output on Windows
    sub_env["PYTHONIOENCODING"] = "utf-8"
    # Suppress dependency warnings (e.g. RequestsDependencyWarning)
    # that pollute stderr and mask real errors
    sub_env["PYTHONWARNINGS"] = "ignore"

    try:
        # Step 1: Configure
        result = subprocess.run(
            [agentcore_bin, "configure",
             "--entrypoint", entrypoint,
             "--name", agent_name,
             "--region", region,
             "--non-interactive"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=60,
            env=sub_env,
        )
        if result.returncode != 0:
            err = result.stderr.strip() or result.stdout.strip()
            return StageResult(
                success=False,
                message=f"agentcore configure failed: {err}",
                suggestion="Check agent file and AWS configuration.",
            )

        # Step 2: Launch
        result = subprocess.run(
            [agentcore_bin, "launch",
             "--agent", agent_name,
             "--auto-update-on-conflict"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=300,
            env=sub_env,
        )
        if result.returncode != 0:
            err = result.stderr.strip() or result.stdout.strip()
            return StageResult(
                success=False,
                message=f"agentcore launch failed: {err}",
                suggestion=(
                    "Check AWS credentials, region, and that AgentCore "
                    "is available in your account."
                ),
            )

        return StageResult(
            success=True,
            message=f"Agent '{agent_name}' deployed to {region}.",
            data={
                "agent_name": agent_name,
                "region": region,
                "model_id": model_id,
            },
        )

    except FileNotFoundError:
        return StageResult(
            success=False,
            message="AgentCore CLI not found.",
            suggestion=(
                "Install it with: pip install bedrock-agentcore-starter-toolkit"
            ),
        )
    except subprocess.TimeoutExpired:
        return StageResult(
            success=False,
            message="AgentCore deployment timed out.",
            suggestion="Try running 'agentcore launch' manually.",
        )
    except Exception as exc:
        return StageResult(
            success=False,
            message=f"AgentCore deployment failed: {exc}",
            suggestion=(
                "Check AWS credentials, region, and that AgentCore is "
                "available in your account."
            ),
        )



# ---------------------------------------------------------------------------
# Config reader
# ---------------------------------------------------------------------------


def _stage_readiness(
    agent: Any,
    region: str,
    aws_profile: str | None = None,
) -> StageResult:
    """Stage 6 — Verify AgentCore deployment readiness.

    Inspects the agent configuration and the target AWS environment to
    report on key deployment components: authentication, memory, guards,
    tools, and model access.  Each sub-check is printed as an indented
    detail line so the operator can see exactly what is (and isn't)
    configured before the agent goes live.

    Parameters
    ----------
    agent:
        The loaded Synth Agent instance.
    region:
        AWS region for deployment.
    aws_profile:
        Named AWS profile, if any.

    Returns
    -------
    StageResult
        Always succeeds (informational), with a summary message.
    """
    import os as _os

    details: list[str] = []
    warnings: list[str] = []

    # -- Authentication ---------------------------------------------------
    has_profile = bool(aws_profile)
    has_env_keys = bool(
        _os.environ.get("AWS_ACCESS_KEY_ID")
        and _os.environ.get("AWS_SECRET_ACCESS_KEY")
    )
    if has_profile:
        details.append(f"Auth: AWS profile '{aws_profile}'")
    elif has_env_keys:
        details.append("Auth: environment credentials")
    else:
        details.append("Auth: IAM role (runtime)")

    # -- Memory -----------------------------------------------------------
    memory = getattr(agent, "memory", None)
    if memory is not None and not isinstance(memory, type(agent)):
        mem_cls = type(memory).__name__
        details.append(f"Memory: {mem_cls}")
    else:
        mem_endpoint = _os.environ.get("AGENTCORE_MEMORY_ENDPOINT")
        mem_id = _os.environ.get("AGENTCORE_MEMORY_ID")
        if mem_endpoint and mem_id:
            details.append("Memory: AgentCoreMemory (auto-configured)")
        else:
            warnings.append(
                "Memory: not configured — agent will not retain "
                "conversation history across turns"
            )

    # -- Guards -----------------------------------------------------------
    guards: list[Any] = []
    raw_guards = getattr(agent, "guards", None)
    if isinstance(raw_guards, list):
        guards = raw_guards
    if guards:
        names = [
            getattr(g, "name", type(g).__name__) for g in guards
        ]
        details.append(f"Guards: {', '.join(names)} ({len(guards)})")
    else:
        warnings.append("Guards: none — no input/output guardrails")

    # -- Tools ------------------------------------------------------------
    tools: dict[str, Any] = {}
    raw_tools = getattr(agent, "_registered_tools", None)
    if isinstance(raw_tools, dict):
        tools = raw_tools
    if tools:
        tool_names = sorted(tools.keys())
        if len(tool_names) <= 5:
            details.append(
                f"Tools: {', '.join(tool_names)} ({len(tool_names)})"
            )
        else:
            shown = ", ".join(tool_names[:4])
            details.append(
                f"Tools: {shown} +{len(tool_names) - 4} more "
                f"({len(tool_names)})"
            )
    else:
        details.append("Tools: none")

    # -- Structured output ------------------------------------------------
    schema = getattr(agent, "output_schema", None)
    if schema is not None and hasattr(schema, "__name__"):
        details.append(f"Output schema: {schema.__name__}")

    # -- Web search API key -----------------------------------------------
    if "web_search" in tools or "search_web" in tools:
        has_search_key = any(
            _os.environ.get(k)
            for k in ("BRAVE_API_KEY", "SERPAPI_API_KEY", "TAVILY_API_KEY")
        )
        if has_search_key:
            details.append("Search API: configured")
        else:
            warnings.append(
                "Search API: web_search tool found but no API key set "
                "(BRAVE_API_KEY, SERPAPI_API_KEY, or TAVILY_API_KEY)"
            )

    # -- Playwright browser binaries --------------------------------------
    if "browse_web" in tools or "search_web" in tools:
        try:
            import playwright  # noqa: F401
            details.append("Playwright: installed")
        except ImportError:
            warnings.append(
                "Playwright: not installed — browse_web will use "
                "httpx fallback. Run: pip install playwright && "
                "playwright install chromium"
            )

    # -- Model / region ---------------------------------------------------
    model = getattr(agent, "model", "unknown")
    details.append(f"Target: {region} / {model}")

    # -- Print sub-lines --------------------------------------------------
    for line in details:
        click.echo(
            f"           {click.style('•', dim=True)} {line}"
        )
    for line in warnings:
        click.echo(
            f"           {click.style('•', fg='yellow')} {line}"
        )

    # Build summary
    warn_count = len(warnings)
    if warn_count:
        summary = (
            f"Ready with {warn_count} warning(s) — review above."
        )
    else:
        summary = "All components configured."

    return StageResult(success=True, message=summary)


def _read_agentcore_yaml(file: str) -> dict[str, Any]:
    """Read ``agentcore.yaml`` from the same directory as *file*.

    Parameters
    ----------
    file:
        Path to the agent Python file.

    Returns
    -------
    dict
        Parsed YAML contents, or an empty dict if the file is absent.
    """
    agent_dir = Path(file).parent if file else Path(".")
    yaml_path = agent_dir / "agentcore.yaml"

    if not yaml_path.exists():
        return {}

    try:
        import yaml  # type: ignore[import-untyped]

        with yaml_path.open(encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        return data if isinstance(data, dict) else {}
    except ImportError:
        # PyYAML not available — try a minimal key=value fallback
        return _parse_yaml_minimal(yaml_path)
    except Exception:
        return {}


def _parse_yaml_minimal(path: Path) -> dict[str, Any]:
    """Minimal YAML parser for simple ``key: value`` lines (no PyYAML)."""
    result: dict[str, Any] = {}
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line:
                key, _, value = line.partition(":")
                result[key.strip()] = value.strip().strip('"').strip("'")
    except Exception:
        pass
    return result


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def run_deploy(target: str, dry_run: bool, file: str | None) -> None:
    """Run the Deploy_Wizard for the specified *target*.

    Reads ``agentcore.yaml`` for ``aws_profile``, ``aws_region``, and
    ``model_id``, then executes seven sequential stages.  Halts on the
    first failure (Requirement 2.3).  In dry-run mode, only stages 1–4
    run (Requirement 2.7).

    Parameters
    ----------
    target:
        Deployment target — only ``"agentcore"`` is supported.
    dry_run:
        When ``True``, run stages 1–4 only and prefix output with
        ``[DRY RUN]``.
    file:
        Path to the agent Python file.
    """
    if target != "agentcore":
        click.echo(
            click.style(
                f"Unknown target '{target}'. Supported: agentcore", fg="red"
            ),
            err=True,
        )
        sys.exit(1)

    if not file:
        click.echo(
            click.style("No agent file specified.", fg="red"),
            err=True,
        )
        sys.exit(1)

    # Read agentcore.yaml for persisted config (Requirements 4.7, 7.1, 7.3)
    config = _read_agentcore_yaml(file)
    aws_profile: str | None = config.get("aws_profile") or None
    aws_region: str = config.get("aws_region") or "us-east-1"
    model_id: str = config.get("model_id") or "unknown"

    # Inject AWS config into the environment so that boto3 sessions
    # created during agent loading and deployment pick up the right
    # profile and region automatically.
    import os as _os

    if aws_profile:
        _os.environ.setdefault("AWS_PROFILE", aws_profile)
    _os.environ.setdefault("AWS_DEFAULT_REGION", aws_region)

    if dry_run:
        click.echo(click.style("[DRY RUN] Starting deploy validation...", fg="cyan"))
    else:
        click.echo(click.style("Starting AgentCore deployment...", fg="cyan"))
    click.echo("")

    # ------------------------------------------------------------------
    # Stage 1: Credential validation
    # ------------------------------------------------------------------
    result1 = _stage_credentials(aws_profile)
    _print_stage_result("Credential validation", result1, dry_run=dry_run)
    if not result1.success:
        sys.exit(1)

    # ------------------------------------------------------------------
    # Stage 2: Dependency check
    # ------------------------------------------------------------------
    result2 = _stage_dependencies()
    _print_stage_result("Dependency check", result2, dry_run=dry_run)
    if not result2.success:
        sys.exit(1)

    # ------------------------------------------------------------------
    # Stage 3: Agent file validation
    # ------------------------------------------------------------------
    result3 = _stage_validate_file(file)
    _print_stage_result("Agent file validation", result3, dry_run=dry_run)
    if not result3.success:
        sys.exit(1)

    agent = result3.data

    # Read agent name from config for the manifest
    config_agent_name: str | None = config.get("agent_name") or None

    # ------------------------------------------------------------------
    # Stage 4: Manifest generation
    # ------------------------------------------------------------------
    result4 = _stage_manifest(agent, agent_name=config_agent_name)
    _print_stage_result("Manifest generation", result4, dry_run=dry_run)
    if not result4.success:
        sys.exit(1)

    manifest = result4.data

    # ------------------------------------------------------------------
    # Stage 4b: Dockerfile folder validation (Requirements 6.1, 6.2)
    # ------------------------------------------------------------------
    agent_name = manifest.get("name", "")
    result4b = _stage_dockerfile_validation(agent_name, file)
    _print_stage_result("Dockerfile validation", result4b, dry_run=dry_run)
    if not result4b.success:
        sys.exit(1)

    # Dry-run stops after stage 4 (Requirement 2.7)
    if dry_run:
        click.echo("")
        click.echo(
            click.style("[DRY RUN] Validation passed. No artifact created.", fg="cyan")
        )
        return

    # ------------------------------------------------------------------
    # Stage 5: Artifact packaging
    # ------------------------------------------------------------------
    result5 = _stage_package(agent, dry_run=False)
    _print_stage_result("Artifact packaging", result5, dry_run=False)
    if not result5.success:
        sys.exit(1)

    # ------------------------------------------------------------------
    # Stage 6: Deployment readiness
    # ------------------------------------------------------------------
    result6 = _stage_readiness(agent, aws_region, aws_profile)
    _print_stage_result("Deployment readiness", result6, dry_run=False)
    if not result6.success:
        sys.exit(1)

    # ------------------------------------------------------------------
    # Stage 7: AgentCore API submission
    # ------------------------------------------------------------------
    result7 = _stage_submit(
        manifest, aws_region, model_id,
        dry_run=False, file=file, aws_profile=aws_profile,
    )
    _print_stage_result("AgentCore API submission", result7, dry_run=False)
    if not result7.success:
        sys.exit(1)

    # ------------------------------------------------------------------
    # Success summary (Requirement 2.6)
    # ------------------------------------------------------------------
    click.echo("")
    click.echo(click.style("Deployment complete.", fg="green"))

    submit_data = result7.data or {}
    agent_name = submit_data.get("agent_name", "N/A")
    deployed_region = submit_data.get("region", aws_region)
    deployed_model = submit_data.get("model_id", model_id)

    click.echo(f"  Agent     : {agent_name}")
    click.echo(f"  Region    : {deployed_region}")
    click.echo(f"  Model ID  : {deployed_model}")
