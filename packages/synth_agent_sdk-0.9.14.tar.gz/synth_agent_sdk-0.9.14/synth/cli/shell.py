"""Interactive shell for the Synth SDK.

Launches a persistent REPL when ``synth`` is invoked with no subcommand.
Commands are typed without the ``synth`` prefix — e.g. ``run agent.py "Hi"``
instead of ``synth run agent.py "Hi"``.

Uses ``prompt_toolkit`` (already a core dependency) for readline-style
editing, tab completion, and persistent history.
"""

from __future__ import annotations

import shlex
import sys

from prompt_toolkit import PromptSession
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.history import FileHistory, InMemoryHistory
from prompt_toolkit.styles import Style as PTStyle

from synth.cli.banner import display_boot_sequence


# ---------------------------------------------------------------------------
# Theme
# ---------------------------------------------------------------------------

_PT_STYLE = PTStyle.from_dict({
    "prompt": "#39ff14 bold",
    "completion-menu.completion": "bg:#1a1a1a #39ff14",
    "completion-menu.completion.current": "bg:#39ff14 #000000 bold",
})

# ---------------------------------------------------------------------------
# Available top-level commands (mirrors main.py registrations)
# ---------------------------------------------------------------------------

_COMMANDS: dict[str, str] = {
    "run":     "Execute an agent with a prompt",
    "dev":     "Start local REPL with hot-reload",
    "eval":    "Run evaluation suite against an agent",
    "trace":   "Open stored trace in browser",
    "deploy":  "Deploy agent to a target platform",
    "doctor":  "Check environment, credentials, and dependencies",
    "info":    "Show installation options and extras",
    "init":    "Interactive project setup",
    "bench":   "Benchmark agent performance",
    "help":    "Show the getting-started guide",
    "create":  "Scaffold agents, tools, MCP servers, teams, and UIs",
    "exit":    "Exit the Synth shell",
    "quit":    "Exit the Synth shell",
}

_SUBCOMMANDS: dict[str, list[str]] = {
    "create": ["agent", "team", "tool", "mcp", "ui", "agentcore"],
}

_COMPLETER = WordCompleter(
    list(_COMMANDS.keys()),
    ignore_case=True,
    sentence=True,
)


# ---------------------------------------------------------------------------
# History file
# ---------------------------------------------------------------------------

def _get_history() -> FileHistory | InMemoryHistory:
    """Return a FileHistory if we can write to the home dir, else in-memory."""
    import os
    try:
        history_path = os.path.join(
            os.path.expanduser("~"), ".synth_history",
        )
        return FileHistory(history_path)
    except Exception:
        return InMemoryHistory()


# ---------------------------------------------------------------------------
# Command dispatch
# ---------------------------------------------------------------------------

def _dispatch(line: str) -> None:
    """Parse ``line`` and invoke the matching Click command.

    Parameters
    ----------
    line:
        Raw input string from the prompt (without the ``synth`` prefix).
    """
    # Lazy import to avoid circular dependency
    from synth.cli.main import cli

    try:
        args = shlex.split(line)
    except ValueError as exc:
        _print_error(f"Parse error: {exc}")
        return

    if not args:
        return

    try:
        # standalone_mode=False → returns value instead of calling sys.exit
        cli.main(args=args, standalone_mode=False)
    except SystemExit:
        # Click calls sys.exit(0) on --help; swallow it
        pass
    except Exception as exc:
        _print_error(str(exc))


# ---------------------------------------------------------------------------
# Shell helpers
# ---------------------------------------------------------------------------

def _print_error(msg: str) -> None:
    """Print an error line in red."""
    try:
        from rich.console import Console
        Console().print(f"  [bold red]Error:[/bold red] {msg}")
    except ImportError:
        print(f"  Error: {msg}", file=sys.stderr)


def _print_hint() -> None:
    """Print the one-line usage hint after the boot sequence."""
    try:
        from rich.console import Console
        c = Console()
        c.print(
            "  [bold #39ff14]Synth shell[/bold #39ff14]  "
            "[dim]— type a command to get started, or [bold]help[/bold] "
            "for the guide. [bold]exit[/bold] to quit.[/dim]",
        )
        c.print("")
    except ImportError:
        print("  Synth shell — type a command or 'help'. 'exit' to quit.\n")


def _print_goodbye() -> None:
    """Print exit message."""
    try:
        from rich.console import Console
        Console().print("\n  [dim #39ff14]Goodbye.[/dim #39ff14]\n")
    except ImportError:
        print("\n  Goodbye.\n")


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def launch_shell() -> None:
    """Launch the interactive Synth shell.

    Displays the boot sequence once, then enters a ``prompt_toolkit``
    REPL loop.  Commands are dispatched to the Click CLI without the
    ``synth`` prefix.

    Examples
    --------
    >>> launch_shell()  # doctest: +SKIP
    synth> run agent.py "Hello"
    synth> create agent my-bot
    synth> exit
    """
    display_boot_sequence()
    _print_hint()

    session: PromptSession[str] = PromptSession(
        history=_get_history(),
        completer=_COMPLETER,
        style=_PT_STYLE,
        complete_while_typing=True,
    )

    while True:
        try:
            raw = session.prompt(
                HTML('<style fg="#39ff14" bold="true">synth&gt; </style>'),
            )
        except KeyboardInterrupt:
            # Ctrl+C clears the line — don't exit
            continue
        except EOFError:
            # Ctrl+D exits
            break

        line = raw.strip()
        if not line:
            continue

        if line.lower() in ("exit", "quit"):
            break

        _dispatch(line)

    _print_goodbye()
