"""Agent class — the central abstraction of the Synth SDK.

Composes a provider, optional tools, memory, guards, and structured output
into a single callable unit.  The constructor resolves the provider, registers
tools, and prepares the retry handler.  ``arun()`` implements the core
execution flow; ``run()`` is a sync wrapper (Task 5.3), and streaming
methods are implemented in Task 5.4.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator, Callable, Generator
from typing import Any

from pydantic import BaseModel

from synth._compat import run_sync
from synth.errors import CostLimitError, GuardViolationError, ToolExecutionError
from synth.guards.cost import CostGuard
from synth.tracing.trace import TraceCollector
from synth.providers.base import (
    ProviderDoneEvent,
    ProviderErrorEvent,
    TextChunkEvent,
    ThinkingChunkEvent,
    ToolCallChunkEvent,
)
from synth.providers.retry import RetryHandler
from synth.providers.router import ProviderRouter
from synth.structured.output import StructuredOutputHandler
from synth.tools.executor import ToolExecutor
from synth.tools.toolkit import ToolKit
from synth.types import (
    DoneEvent,
    ErrorEvent,
    GuardContext,
    Message,
    RunResult,
    StreamEvent,
    ThinkingEvent,
    TokenEvent,
    TokenUsage,
    ToolCallEvent,
    ToolCallRecord,
    ToolResultEvent,
)

# Type alias for decorated tool functions (carry ``_tool_schema`` attribute).
ToolFunction = Callable[..., Any]

# Default model used when the caller does not specify one.
_DEFAULT_MODEL = "claude-sonnet-4-5"


def _sanitize_content(text: str) -> str:
    """Ensure message content is non-empty for provider APIs.

    Some providers (e.g. Bedrock Converse) reject content blocks with
    empty or whitespace-only text.  This helper replaces such values
    with a safe placeholder.
    """
    if not text or not text.strip():
        return "(no content)"
    return text


class Agent:
    """A single autonomous unit wrapping an LLM, tools, memory, and guards.

    Parameters
    ----------
    model:
        Model identifier string (e.g. ``"claude-sonnet-4-5"``, ``"gpt-4o"``).
        Defaults to ``"claude-sonnet-4-5"`` when ``None``.
    instructions:
        System-level instructions sent to the model on every call.
    tools:
        A list of ``@tool``-decorated functions and/or ``ToolKit`` instances
        to make available during runs.
    memory:
        Optional memory backend for conversation history.
    guards:
        Optional list of guard instances evaluated on input/output.
    output_schema:
        Optional Pydantic model class for structured output parsing.
    base_url:
        Optional custom endpoint URL forwarded to the provider.
    max_retries:
        Maximum retry attempts for transient provider errors.
    retry_backoff:
        Base delay in seconds for exponential backoff.
    """

    def __init__(
        self,
        model: str | None = None,
        instructions: str = "",
        tools: list[Callable[..., Any] | ToolKit] | None = None,
        memory: Any | None = None,
        guards: list[Any] | None = None,
        output_schema: type[BaseModel] | None = None,
        base_url: str | None = None,
        max_retries: int = 3,
        retry_backoff: float = 1.0,
    ) -> None:
        # Store configuration
        self.model = model or _DEFAULT_MODEL
        self.instructions = instructions
        self.memory = memory
        self.guards = guards or []
        self.output_schema = output_schema
        self.base_url = base_url

        # Resolve provider via router
        router = ProviderRouter()
        self.provider = router.resolve(self.model, base_url=self.base_url)

        # Register tools from individual functions and ToolKits
        registered_tools: dict[str, ToolFunction] = {}
        if tools:
            for t in tools:
                if isinstance(t, ToolKit):
                    registered_tools.update(t.get_tools())
                elif hasattr(t, "_tool_schema"):
                    registered_tools[t._tool_schema["name"]] = t  # type: ignore[union-attr]

        # Create tool executor with all registered tools
        self.tool_executor = ToolExecutor(registered_tools)
        self._registered_tools = registered_tools

        # Create retry handler
        self.retry_handler = RetryHandler(
            max_retries=max_retries,
            retry_backoff=retry_backoff,
        )

    # ------------------------------------------------------------------
    # Guard evaluation
    # ------------------------------------------------------------------

    async def _evaluate_guards(
        self,
        content: str,
        tool_call_names: list[str],
        cumulative_cost: float = 0.0,
        run_id: str | None = None,
        collector: TraceCollector | None = None,
    ) -> None:
        """Evaluate all guards in declaration order. Raise on first violation.

        Parameters
        ----------
        content:
            The text to check (user prompt for input guards, model
            response for output guards).
        tool_call_names:
            Names of tools called so far (empty for input guards).
        cumulative_cost:
            Accumulated cost for the run so far.
        run_id:
            Optional run identifier.
        collector:
            Optional trace collector for recording guard check spans.

        Raises
        ------
        CostLimitError
            When a ``CostGuard`` violation is detected.
        GuardViolationError
            When any other guard violation is detected.
        """
        context = GuardContext(
            cumulative_cost=cumulative_cost,
            tool_calls=tool_call_names,
            run_id=run_id,
        )

        for guard in self.guards:
            if collector is not None:
                async with collector.span(
                    guard.name, "guard_check",
                ) as meta:
                    result = await guard.check(content, context)
                    meta["passed"] = result.passed
            else:
                result = await guard.check(content, context)

            if not result.passed:
                if isinstance(guard, CostGuard):
                    raise CostLimitError(
                        message=result.violation_message or "Cost limit exceeded",
                        component=guard.name,
                        suggestion="Increase the cost limit or reduce token usage.",
                        guard_name=guard.name,
                        violating_content=content[:100],
                        remediation="Increase Guard.max_cost() limit.",
                    )
                raise GuardViolationError(
                    message=result.violation_message or "Guard check failed",
                    component=guard.name,
                    suggestion=f"Review the {guard.name} guard configuration.",
                    guard_name=guard.name,
                    violating_content=content[:100],
                    remediation=result.violation_message or "Fix the violating content.",
                )

    # ------------------------------------------------------------------
    # Execution methods
    # ------------------------------------------------------------------

    def run(
        self,
        prompt: str,
        *,
        thread_id: str | None = None,
        run_id: str | None = None,
    ) -> RunResult:
        """Execute the agent synchronously.

        Delegates to :meth:`arun` via :func:`synth._compat.run_sync`,
        which handles event-loop detection and bridging automatically.

        Parameters
        ----------
        prompt:
            The user prompt to send to the model.
        thread_id:
            Optional thread identifier for memory retrieval/storage.
        run_id:
            Optional run identifier (reserved for checkpointing).

        Returns
        -------
        RunResult
            The complete result including text, tokens, cost, latency,
            and tool call records.
        """
        return run_sync(
            self.arun(prompt, thread_id=thread_id, run_id=run_id),
        )

    async def arun(
        self,
        prompt: str,
        *,
        thread_id: str | None = None,
        run_id: str | None = None,
    ) -> RunResult:
        """Execute the agent asynchronously.

        Execution flow:
        1. Memory retrieval (if configured and thread_id provided)
        2. Build messages with system instructions and user prompt
        3. Inject structured output schema message (if output_schema set)
        4. Input guard evaluation (in declaration order)
        5. Provider call via RetryHandler
        6. Tool execution loop (if model requests tool calls)
        7. Output guard evaluation
        8. Structured output parsing (if output_schema set)
        9. Return RunResult with all fields populated

        Parameters
        ----------
        prompt:
            The user prompt to send to the model.
        thread_id:
            Optional thread identifier for memory retrieval/storage.
        run_id:
            Optional run identifier (reserved for checkpointing).

        Returns
        -------
        RunResult
            The complete result including text, tokens, cost, latency,
            and tool call records.
        """
        import time

        start_time = time.perf_counter()

        # Initialise trace collector
        collector = TraceCollector()
        collector.start()

        # Build messages
        messages: list[Message] = []

        # 1. Memory retrieval
        if self.memory and thread_id:
            prior = await self.memory.get_messages(thread_id)
            messages.extend(prior)

        # Add system instructions
        if self.instructions:
            messages.insert(0, {"role": "system", "content": self.instructions})

        # Structured output: inject schema system message
        handler: StructuredOutputHandler | None = None
        if self.output_schema:
            handler = StructuredOutputHandler(
                self.output_schema,
                max_retries=self.retry_handler.max_retries,
            )
            schema_msg: Message = {
                "role": "system",
                "content": handler.get_system_message(),
            }
            # Insert after instructions if present, otherwise at position 0
            insert_pos = 1 if self.instructions else 0
            messages.insert(insert_pos, schema_msg)

        # Add user prompt
        messages.append({"role": "user", "content": prompt})

        # 2. Get tool schemas
        tool_schemas = (
            [fn._tool_schema for fn in self._registered_tools.values()]
            if self._registered_tools
            else None
        )

        # 3. Input guard evaluation
        await self._evaluate_guards(
            prompt, tool_call_names=[], run_id=run_id,
            collector=collector,
        )

        # 4. Provider call with retry
        tool_call_records: list[ToolCallRecord] = []

        async with collector.span(
            self.model, "llm_call",
        ) as llm_meta:
            response = await self.retry_handler.execute(
                self.provider.complete, messages, tools=tool_schemas,
            )
            llm_meta["total_tokens"] = response.usage.total_tokens
            llm_meta["input_tokens"] = response.usage.input_tokens
            llm_meta["output_tokens"] = response.usage.output_tokens

        # Tool execution loop
        max_tool_rounds = 10
        tool_round = 0
        while response.tool_calls and tool_round < max_tool_rounds:
            tool_round += 1
            # Add assistant message with tool calls to conversation
            messages.append({"role": "assistant", "content": response.text or ""})

            for tc in response.tool_calls:
                async with collector.span(
                    tc.name, "tool_call",
                ) as tc_meta:
                    tc_start = time.perf_counter()
                    try:
                        result = await self.tool_executor.execute(tc.name, tc.args)
                    except ToolExecutionError as exc:
                        result = f"Error: {exc}"
                    tc_end = time.perf_counter()
                    tc_meta["latency_ms"] = (tc_end - tc_start) * 1000

                tool_call_records.append(ToolCallRecord(
                    name=tc.name,
                    args=tc.args,
                    result=result,
                    latency_ms=(tc_end - tc_start) * 1000,
                ))

                # Add tool result to conversation
                messages.append({
                    "role": "tool",
                    "content": _sanitize_content(str(result)),
                    "tool_name": tc.name,
                })

            # Call provider again with updated conversation
            async with collector.span(
                self.model, "llm_call",
            ) as llm_meta:
                response = await self.retry_handler.execute(
                    self.provider.complete, messages, tools=tool_schemas,
                )
                llm_meta["total_tokens"] = response.usage.total_tokens
                llm_meta["input_tokens"] = response.usage.input_tokens
                llm_meta["output_tokens"] = response.usage.output_tokens

        # 5. Output guard evaluation
        await self._evaluate_guards(
            response.text,
            tool_call_names=[tc.name for tc in tool_call_records],
            cumulative_cost=0.0,  # Cost tracking TBD
            run_id=run_id,
            collector=collector,
        )

        # 6. Structured output parsing
        parsed_output = None
        if handler is not None:
            parsed_output = await handler.parse_and_validate(
                response.text, self.provider, messages,
            )

        # 7. Finalise trace and build RunResult
        trace = collector.finalise()
        elapsed_ms = (time.perf_counter() - start_time) * 1000

        run_result = RunResult(
            text=response.text,
            output=parsed_output,
            tokens=response.usage,
            cost=0.0,  # Cost calculation TBD
            latency_ms=elapsed_ms,
            trace=trace,
            tool_calls=tool_call_records,
        )

        # 8. Memory storage
        if self.memory and thread_id:
            await self.memory.add_messages(thread_id, [
                {"role": "user", "content": prompt},
                {"role": "assistant", "content": response.text},
            ])

        return run_result

    def stream(
        self,
        prompt: str,
        *,
        thread_id: str | None = None,
    ) -> Generator[StreamEvent, None, None]:
        """Stream agent responses synchronously.

        Wraps :meth:`astream` by consuming the async generator in a
        dedicated thread with its own event loop and passing events back
        to the caller via a :class:`queue.Queue`.

        Parameters
        ----------
        prompt:
            The user prompt to send to the model.
        thread_id:
            Optional thread identifier for memory retrieval/storage.

        Yields
        ------
        StreamEvent
            Typed events: ``TokenEvent``, ``ToolCallEvent``,
            ``ToolResultEvent``, ``ThinkingEvent``, ``DoneEvent``,
            or ``ErrorEvent``.
        """
        import asyncio
        import queue
        import threading

        q: queue.Queue[StreamEvent | Exception | None] = queue.Queue()

        async def _consume() -> None:
            try:
                async for event in self.astream(
                    prompt, thread_id=thread_id,
                ):
                    q.put(event)
            except Exception as exc:
                q.put(exc)
            finally:
                q.put(None)  # sentinel

        thread = threading.Thread(
            target=lambda: asyncio.run(_consume()),
            daemon=True,
        )
        thread.start()

        while True:
            item = q.get()
            if item is None:
                break
            if isinstance(item, Exception):
                raise item
            yield item

        thread.join()

    async def astream(
        self,
        prompt: str,
        *,
        thread_id: str | None = None,
    ) -> AsyncGenerator[StreamEvent, None]:
        """Stream agent responses asynchronously.

        Yields typed events as the model generates output.  The event
        sequence mirrors the provider stream, with tool calls executed
        inline and their results yielded as ``ToolResultEvent`` objects.

        Parameters
        ----------
        prompt:
            The user prompt to send to the model.
        thread_id:
            Optional thread identifier for memory retrieval/storage.

        Yields
        ------
        StreamEvent
            Typed events in order: ``TokenEvent`` / ``ThinkingEvent``
            for text, ``ToolCallEvent`` + ``ToolResultEvent`` for tool
            invocations, and ``DoneEvent`` on completion.  On error an
            ``ErrorEvent`` is yielded and the generator closes.
        """
        import time

        start_time = time.perf_counter()

        # Initialise trace collector
        collector = TraceCollector()
        collector.start()

        try:
            # Build messages (same as arun)
            messages: list[Message] = []

            if self.memory and thread_id:
                prior = await self.memory.get_messages(thread_id)
                messages.extend(prior)

            if self.instructions:
                messages.insert(
                    0, {"role": "system", "content": self.instructions},
                )

            messages.append({"role": "user", "content": prompt})

            tool_schemas = (
                [fn._tool_schema for fn in self._registered_tools.values()]
                if self._registered_tools
                else None
            )

            tool_call_records: list[ToolCallRecord] = []
            accumulated_text = ""
            total_usage = TokenUsage(
                input_tokens=0, output_tokens=0, total_tokens=0,
            )

            # Stream from provider — may loop if tool calls occur
            while True:
                needs_another_round = False
                stream_usage = TokenUsage(
                    input_tokens=0, output_tokens=0, total_tokens=0,
                )

                async with collector.span(
                    self.model, "llm_call",
                ) as llm_meta:
                    async for event in self.provider.stream(
                        messages, tools=tool_schemas,
                    ):
                        if isinstance(event, TextChunkEvent):
                            accumulated_text += event.text
                            yield TokenEvent(text=event.text)

                        elif isinstance(event, ThinkingChunkEvent):
                            yield ThinkingEvent(text=event.text)

                        elif isinstance(event, ToolCallChunkEvent):
                            yield ToolCallEvent(
                                name=event.name, args=event.args,
                            )

                            async with collector.span(
                                event.name, "tool_call",
                            ) as tc_meta:
                                tc_start = time.perf_counter()
                                result = await self.tool_executor.execute(
                                    event.name, event.args,
                                )
                                tc_end = time.perf_counter()
                                tc_meta["latency_ms"] = (
                                    (tc_end - tc_start) * 1000
                                )

                            tool_call_records.append(ToolCallRecord(
                                name=event.name,
                                args=event.args,
                                result=result,
                                latency_ms=(tc_end - tc_start) * 1000,
                            ))

                            yield ToolResultEvent(
                                name=event.name, result=result,
                            )

                            # Feed tool result back into conversation
                            messages.append(
                                {"role": "assistant", "content": ""},
                            )
                            messages.append(
                                {"role": "tool",
                                 "content": _sanitize_content(str(result))},
                            )
                            needs_another_round = True

                        elif isinstance(event, ProviderDoneEvent):
                            stream_usage = event.usage
                            total_usage = TokenUsage(
                                input_tokens=(
                                    total_usage.input_tokens
                                    + event.usage.input_tokens
                                ),
                                output_tokens=(
                                    total_usage.output_tokens
                                    + event.usage.output_tokens
                                ),
                                total_tokens=(
                                    total_usage.total_tokens
                                    + event.usage.total_tokens
                                ),
                            )

                        elif isinstance(event, ProviderErrorEvent):
                            yield ErrorEvent(error=event.error)
                            return

                    # Attach usage to the LLM span
                    llm_meta["total_tokens"] = stream_usage.total_tokens
                    llm_meta["input_tokens"] = stream_usage.input_tokens
                    llm_meta["output_tokens"] = stream_usage.output_tokens

                if not needs_another_round:
                    break

            # Finalise trace and build RunResult, then yield DoneEvent
            trace = collector.finalise()
            elapsed_ms = (time.perf_counter() - start_time) * 1000

            run_result = RunResult(
                text=accumulated_text,
                output=None,
                tokens=total_usage,
                cost=0.0,
                latency_ms=elapsed_ms,
                trace=trace,
                tool_calls=tool_call_records,
            )

            # Memory storage
            if self.memory and thread_id:
                await self.memory.add_messages(thread_id, [
                    {"role": "user", "content": prompt},
                    {"role": "assistant", "content": accumulated_text},
                ])

            yield DoneEvent(result=run_result)

        except Exception as exc:
            yield ErrorEvent(error=exc)
            return
