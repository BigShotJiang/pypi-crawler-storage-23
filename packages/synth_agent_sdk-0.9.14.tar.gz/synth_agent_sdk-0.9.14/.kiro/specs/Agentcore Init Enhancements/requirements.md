# Requirements Document

## Introduction

This feature enhances the Synth SDK's AgentCore init and deployment workflow across four areas:

1. **AWS Credentials Integration during Init** — detect and surface AWS credentials (from `aws configure` or the AWS Toolkit VS Code extension) during the `synth init` and `synth create agent --provider agentcore` flows, rather than deferring credential setup entirely to the user.
2. **Prescriptive AgentCore Deployment Flow** — after an AgentCore project is created, guide the user through a step-by-step deployment wizard (`synth deploy --target agentcore`) that validates prerequisites, resolves credentials, and confirms each stage before proceeding.
3. **Expanded Init Capabilities — Tool and MCP Creation** — allow users to optionally scaffold a tool file and/or an MCP server as part of the `synth init` wizard, with a click-through sub-wizard for each.
4. **Model Selection with Region and CRIS Validation** — when AgentCore is selected as the provider, prompt the user to choose a Bedrock model, validate that the model is available in the target region, detect whether Cross-Region Inference (CRIS) is required, and write the correct model ID to the project config.

## Glossary

- **Init_Wizard**: The interactive CLI flow started by `synth init` or `synth create agent`.
- **Deploy_Wizard**: The interactive CLI flow started by `synth deploy --target agentcore`.
- **Edit_Wizard**: The interactive CLI flow started by `synth edit agent <file>` for modifying an existing agent's configuration.
- **Doctor**: The `synth doctor` command that checks environment, credentials, dependencies, and project configuration for issues.
- **Packager**: The `synth.deploy.packager` module responsible for bundling agent files into a deployment artifact for AgentCore.
- **AWS_Toolkit**: The AWS Toolkit extension for VS Code, which stores AWS credential profiles accessible via the AWS SDK credential chain.
- **CRIS**: Cross-Region Inference — an AWS Bedrock feature that routes model invocations across regions when a model is not natively available in the selected region. Requires a specific cross-region inference profile ID instead of the base model ID.
- **Credential_Resolver**: The component responsible for detecting, validating, and surfacing AWS credentials from environment variables, `~/.aws/credentials`, or the AWS Toolkit profile store.
- **Model_Catalog**: The in-memory or bundled data structure that maps Bedrock model IDs to their supported regions and CRIS availability.
- **agentconfig**: The `agentcore.yaml` file written to the project directory during init, which stores agent metadata, AWS region, model ID, IAM permissions, and runtime configuration.
- **Region_Validator**: The component that checks whether a given Bedrock model is available in a specified AWS region, consulting the Model_Catalog.
- **Tool_Catalog**: The bundled registry of pre-built `@tool`-decorated implementations available for selection during init (e.g., web search, calculator, HTTP fetch).
- **MCP_Catalog**: The bundled registry of pre-built MCP server templates available for selection during init (e.g., filesystem, GitHub, Slack, database).

---

## Requirements

### Requirement 1: AWS Credentials Detection during Init

**User Story:** As a developer setting up an AgentCore project, I want the init wizard to detect my existing AWS credentials automatically, so that I don't have to configure them separately after project creation.

#### Acceptance Criteria

1. WHEN a user selects AgentCore as the provider in the Init_Wizard, THE Credential_Resolver SHALL check for AWS credentials in the following order: (a) `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` environment variables, (b) `~/.aws/credentials` file, (c) AWS Toolkit VS Code extension credential profiles.
2. WHEN valid AWS credentials are found by the Credential_Resolver, THE Init_Wizard SHALL display the credential source and the associated AWS account ID (masked to last 4 digits) and ask the user to confirm use of those credentials.
3. WHEN no AWS credentials are found by the Credential_Resolver, THE Init_Wizard SHALL display a warning message and provide instructions to run `aws configure` or install the AWS Toolkit extension.
4. WHEN the user declines the detected credentials in the Init_Wizard, THE Init_Wizard SHALL prompt the user to enter an AWS profile name or configure credentials before continuing.
5. IF the Credential_Resolver encounters an error reading the AWS Toolkit profile store, THEN THE Credential_Resolver SHALL log the error at DEBUG level and continue checking the remaining credential sources without surfacing the error to the user.
6. THE Credential_Resolver SHALL NOT log, echo, or include AWS access key values, secret key values, or session tokens in any user-facing output, error messages, or trace data.

---

### Requirement 2: Prescriptive AgentCore Deployment Flow

**User Story:** As a developer deploying an AgentCore agent, I want a guided step-by-step deployment wizard, so that I can deploy confidently without needing to know all the prerequisites upfront.

#### Acceptance Criteria

1. WHEN a user runs `synth deploy --target agentcore <file>`, THE Deploy_Wizard SHALL execute the following sequential stages in order: (a) credential validation, (b) dependency check (`synth[agentcore]` installed), (c) agent file validation, (d) manifest generation, (e) deployment artifact packaging, (f) AgentCore API submission.
2. WHEN a deployment stage completes successfully, THE Deploy_Wizard SHALL print a `[  OK  ]`-prefixed status line for that stage before proceeding to the next.
3. WHEN a deployment stage fails, THE Deploy_Wizard SHALL print a `[FAIL]`-prefixed status line with a human-readable error message and a corrective action suggestion, then halt the deployment.
4. WHEN the credential validation stage runs and no AWS credentials are found, THE Deploy_Wizard SHALL invoke the Credential_Resolver to prompt the user for credentials before proceeding to the next stage.
5. WHEN the AWS Toolkit VS Code extension is detected and contains credential profiles, THE Deploy_Wizard SHALL list the available profiles and prompt the user to select one if no default credentials are already active.
6. WHEN all stages complete successfully, THE Deploy_Wizard SHALL print a summary including the AgentCore agent ARN, the deployed region, and the model ID used.
7. WHEN `--dry-run` is passed, THE Deploy_Wizard SHALL execute stages (a) through (d) only and print `[DRY RUN]`-prefixed output for each, without submitting to the AgentCore API.

---

### Requirement 3: Tool and MCP Creation during Init

**User Story:** As a developer initializing a new Synth project, I want to optionally add tools and/or an MCP server during init — choosing from a catalog of pre-built options or scaffolding custom ones — so that I can set up a complete project in a single guided flow.

#### Acceptance Criteria

1. AFTER the Init_Wizard collects the project name, provider, and instructions, THE Init_Wizard SHALL ask the user whether they want to add tools to the project (yes/no, default: no).
2. WHEN the user selects yes for tool creation, THE Tool_Catalog SHALL present a numbered list of pre-built tool options (e.g., web search, calculator, file reader, HTTP fetch, datetime) plus a "Create custom scaffolding" option.
3. WHEN the user selects one or more pre-built tools from the Tool_Catalog, THE Init_Wizard SHALL include the corresponding ready-to-use tool implementations in `tools.py` and SHALL import and register those tools in the generated `agent.py`.
4. WHEN the user selects "Create custom scaffolding" for tools, THE Init_Wizard SHALL present a sub-wizard that asks for up to 3 tool names and their descriptions, then generate `@tool`-decorated stub functions for each in `tools.py` and register them in `agent.py`.
5. AFTER the tool creation step, THE Init_Wizard SHALL ask the user whether they want to add an MCP server to the project (yes/no, default: no).
6. WHEN the user selects yes for MCP creation, THE MCP_Catalog SHALL present a numbered list of pre-built MCP server options (e.g., filesystem MCP, GitHub MCP, Slack MCP, database MCP) plus a "Create custom scaffolding" option.
7. WHEN the user selects a pre-built MCP server from the MCP_Catalog, THE Init_Wizard SHALL generate the MCP server directory with the corresponding pre-built `server.py` implementation and register the MCP client in `agent.py`.
8. WHEN the user selects "Create custom scaffolding" for MCP, THE Init_Wizard SHALL prompt for an MCP server name (default: `mcp-server`) and present a sub-wizard that asks for up to 3 MCP tool names and their descriptions, then generate `@mcp.tool()`-decorated stub functions in `server.py`.
9. WHEN the user selects no for both tool and MCP creation, THE Init_Wizard SHALL proceed to project generation without creating those files, matching the existing behavior.
10. THE Init_Wizard SHALL display the complete list of files to be created in the confirmation summary before writing any files to disk.

---

### Requirement 4: Model Selection with Region and CRIS Validation

**User Story:** As a developer targeting AWS AgentCore, I want to select a Bedrock model during init and have the system validate regional availability and CRIS requirements, so that my agent is configured with the correct model ID from the start.

#### Acceptance Criteria

1. WHEN a user selects AgentCore as the provider in the Init_Wizard, THE Init_Wizard SHALL prompt the user to select a target AWS region (default: `us-east-1`) before presenting the model selection list.
2. WHEN a target region is selected, THE Region_Validator SHALL filter the Model_Catalog to display only models available in that region or available via CRIS from that region.
3. WHEN the user selects a model that is natively available in the target region, THE Init_Wizard SHALL write the base model ID (e.g., `anthropic.claude-sonnet-4-5-20250514-v1:0`) to the `model` field in `agentcore.yaml` and to the `Agent(model=...)` call in `agent.py`.
4. WHEN the user selects a model that requires CRIS for the target region, THE Init_Wizard SHALL display a notice explaining that CRIS will be used, and SHALL write the cross-region inference profile ID (e.g., `us.anthropic.claude-sonnet-4-5-20250514-v1:0`) to the `model` field in `agentcore.yaml` and to the `Agent(model=...)` call in `agent.py`.
5. THE Model_Catalog SHALL include at minimum the following models: `claude-3-5-haiku`, `claude-3-5-sonnet`, `claude-3-7-sonnet`, `claude-sonnet-4-5`, `claude-opus-4`, `amazon.nova-micro`, `amazon.nova-lite`, `amazon.nova-pro`.
6. WHEN a user runs `synth create agent --provider agentcore <name>`, THE Init_Wizard SHALL apply the same region and model selection flow as described in criteria 1–4.
7. WHEN the selected region and model combination is written to `agentcore.yaml`, THE agentconfig SHALL persist the `aws_region`, `model_id`, and `cris_enabled` fields so that `synth deploy` can read them without re-prompting.
8. IF the Model_Catalog cannot determine availability for a given region, THEN THE Region_Validator SHALL default to showing all models and display a warning that regional availability could not be verified.

---

### Requirement 5: Prescriptive Edit Agent Flow

**User Story:** As a developer with an existing Synth agent project, I want a guided wizard to modify my agent's configuration — changing instructions, swapping models, or adding tools and MCP servers — so that I can make changes safely without manually editing files.

#### Acceptance Criteria

1. THE CLI SHALL expose a `synth edit agent <file>` command that launches the Edit_Wizard for the specified agent file.
2. WHEN the Edit_Wizard starts, THE Edit_Wizard SHALL read the existing `agent.py` and `agentcore.yaml` (if present) and display a summary of the current configuration (model, instructions, registered tools, MCP servers).
3. WHEN the Edit_Wizard displays the current configuration, THE Edit_Wizard SHALL present a menu of editable aspects: (a) instructions, (b) model, (c) tools, (d) MCP servers.
4. WHEN the user selects "instructions", THE Edit_Wizard SHALL display the current instructions text and prompt the user to enter replacement text, then update `agent.py` with the new value.
5. WHEN the user selects "model" and the provider is AgentCore, THE Edit_Wizard SHALL invoke the same region and model selection flow defined in Requirement 4 (criteria 1–4) and update both `agent.py` and `agentcore.yaml` with the new model ID and CRIS setting.
6. WHEN the user selects "model" and the provider is not AgentCore, THE Edit_Wizard SHALL present the available models for that provider and update the `model` argument in `agent.py`.
7. WHEN the user selects "tools", THE Edit_Wizard SHALL present the Tool_Catalog (as defined in Requirement 3) and allow the user to add new tools or remove existing ones, then update `tools.py` and the `tools=[...]` list in `agent.py` accordingly.
8. WHEN the user selects "MCP servers", THE Edit_Wizard SHALL present the MCP_Catalog (as defined in Requirement 3) and allow the user to add a new MCP server or remove an existing one, then update `agent.py` accordingly.
9. BEFORE writing any changes to disk, THE Edit_Wizard SHALL display a diff-style summary of all pending changes and ask the user to confirm.
10. WHEN the user confirms the changes, THE Edit_Wizard SHALL write the updated files atomically (write to a temp file then rename) so that a failure mid-write does not corrupt the existing agent file.
11. IF the specified agent file does not exist, THEN THE Edit_Wizard SHALL display an error message and exit without modifying any files.

---

### Requirement 6: AgentCore Doctor Checks

**User Story:** As a developer working with AgentCore, I want `synth doctor` to validate my AgentCore-specific configuration, so that I can catch misconfiguration before attempting a deployment.

#### Acceptance Criteria

1. WHEN `synth doctor` runs and an `agentcore.yaml` file is present in the current directory, THE Doctor SHALL validate the following fields: `aws_region`, `model_id`, and `cris_enabled`.
2. WHEN the `aws_region` in `agentcore.yaml` is a valid AWS region string, THE Doctor SHALL print an `[  OK  ]` line confirming the region.
3. WHEN the `model_id` in `agentcore.yaml` matches a known entry in the Model_Catalog for the configured region, THE Doctor SHALL print an `[  OK  ]` line confirming the model and its availability.
4. WHEN the `model_id` requires CRIS but `cris_enabled` is `false` or absent, THE Doctor SHALL print a `[FAIL]` line with a suggestion to re-run `synth edit agent agent.py` to correct the model configuration.
5. WHEN the `aws_profile` field is set in `agentcore.yaml`, THE Doctor SHALL verify that the named profile exists in `~/.aws/credentials` or the AWS Toolkit store and print the appropriate `[  OK  ]` or `[FAIL]` status.
6. WHEN no `agentcore.yaml` is found, THE Doctor SHALL skip AgentCore-specific checks silently.

---

### Requirement 7: AWS Profile Persistence

**User Story:** As a developer, I want my chosen AWS profile to be saved to my project config after I select it during init or deploy, so that I don't have to re-select it on every subsequent command.

#### Acceptance Criteria

1. WHEN the Credential_Resolver prompts the user to select an AWS profile during the Init_Wizard or Deploy_Wizard, THE Init_Wizard or Deploy_Wizard SHALL write the selected profile name (not the key values) to the `aws_profile` field in `agentcore.yaml`.
2. WHEN `agentcore.yaml` contains an `aws_profile` field, THE Credential_Resolver SHALL use that named profile as the first credential source to check, before checking environment variables or the default credential chain.
3. WHEN the `synth deploy` command runs and `agentcore.yaml` contains a valid `aws_profile`, THE Deploy_Wizard SHALL use that profile without prompting the user, and SHALL display the profile name in the credential validation stage output.
4. THE Credential_Resolver SHALL NOT write AWS access key values, secret key values, or session tokens to `agentcore.yaml` or any other project file.
5. THE Credential_Resolver SHALL NOT write AWS access key values, secret key values, or session tokens to any log output, trace data, error messages, or standard output at any log level.
6. WHEN the Synth SDK packager bundles a deployment artifact, THE Packager SHALL verify that `agentcore.yaml` contains no credential key fields and SHALL abort packaging with an error if any are detected.

---

### Requirement 8: Credential Security Guarantees

**User Story:** As a security-conscious developer, I want the Synth SDK to enforce that AWS credentials are never persisted or leaked anywhere in the system, so that I can trust the tooling with production credentials.

#### Acceptance Criteria

1. THE Credential_Resolver SHALL resolve AWS credentials at call time from the AWS SDK credential chain only, and SHALL NOT store resolved credential values as instance attributes, module-level variables, or in any serializable object.
2. WHEN any component formats an error message, log entry, or CLI output string, THE component SHALL redact any string that matches the pattern of an AWS access key (20-character uppercase alphanumeric starting with `AKIA` or `ASIA`) or secret key (40-character base64-like string).
3. THE Init_Wizard, Deploy_Wizard, and Edit_Wizard SHALL NOT echo back any credential value entered or detected during their flows, including in confirmation summaries.
4. WHEN `synth deploy` packages a deployment artifact, THE Packager SHALL scan the artifact for files containing strings matching AWS credential patterns and SHALL abort with a `SynthConfigError` if any are found.
5. IF a `.env` file exists in the project directory, THEN THE Packager SHALL exclude it from the deployment artifact without requiring explicit user configuration.
6. THE Credential_Resolver SHALL treat any exception raised while reading credential sources as a non-fatal warning, log it at DEBUG level only, and continue to the next source in the resolution chain.
