# Implementation Plan: AgentCore Init Enhancements

## Overview

Implement the four AgentCore init enhancements plus the Edit Wizard and Doctor checks.
Each task builds incrementally — new modules first, then CLI integration, then wiring.

## Tasks

- [x] 1. Implement `CredentialResolver` in `synth/deploy/agentcore/credentials.py`
  - Create `synth/deploy/agentcore/credentials.py` with `ResolvedCredentials` dataclass
    and `CredentialResolver` class
  - Implement `resolve()` checking sources in order: env vars → `~/.aws/credentials` →
    AWS Toolkit VS Code profiles (`~/.aws/sso/cache/`)
  - Each source wrapped in `try/except`; exceptions logged at `DEBUG` only, resolver
    continues to next source
  - `mask_account_id(account_id: str) -> str` returns `"****" + account_id[-4:]`
  - `resolve_profile(profile_name: str) -> ResolvedCredentials | None` for named profiles
  - Credential values MUST NOT be stored as instance attributes; boto3 session created
    at call time only
  - Implement `redact_credentials(text: str) -> str` — replaces `AKIA`/`ASIA` patterns
    and 40-char base64-like strings with `[REDACTED]`
  - All errors raise `SynthConfigError` with `component="CredentialResolver"`
  - boto3 imported lazily inside methods with `try/except ImportError`
  - _Requirements: 1.1, 1.5, 1.6, 7.2, 7.4, 7.5, 8.1, 8.2, 8.6_

  - [ ]* 1.1 Write property tests for `CredentialResolver`
    - **Property 1: Credential resolution priority order**
    - **Validates: Requirements 1.1, 7.2**
    - **Property 3: Credential resolver fault tolerance**
    - **Validates: Requirements 1.5, 8.6**
    - **Property 4: Credential redaction in all outputs**
    - **Validates: Requirements 1.6, 7.4, 7.5, 8.2, 8.3**
    - File: `tests/property/test_prop_credentials.py`

  - [ ]* 1.2 Write unit tests for `CredentialResolver`
    - **Property 2: Account ID masking**
    - **Validates: Requirements 1.2**
    - Test source priority with mocked env/file/toolkit
    - Test fault tolerance: each source raising an exception independently
    - Test `redact_credentials` with AKIA/ASIA patterns and 40-char secrets
    - File: `tests/unit/test_credentials.py`

- [x] 2. Implement `ModelCatalog` and `RegionValidator` in
  `synth/deploy/agentcore/model_catalog.py`
  - Create `ModelEntry` dataclass: `model_id`, `display_name`, `native_regions`,
    `cris_regions`, `cris_profile_id`
  - Create `ModelCatalog` with `MODELS: list[ModelEntry]` containing at minimum:
    `claude-3-5-haiku`, `claude-3-5-sonnet`, `claude-3-7-sonnet`, `claude-sonnet-4-5`,
    `claude-opus-4`, `amazon.nova-micro`, `amazon.nova-lite`, `amazon.nova-pro`
  - Create `RegionValidator` with:
    - `models_for_region(region: str) -> list[ModelEntry]` — filters by native + CRIS
      availability; returns all models + sets `availability_unknown=True` if region
      not in catalog
    - `requires_cris(model_id: str, region: str) -> bool`
    - `effective_model_id(model_id: str, region: str) -> str` — returns base ID or
      CRIS profile ID
  - _Requirements: 4.2, 4.3, 4.4, 4.5, 4.8_

  - [ ]* 2.1 Write property tests for `RegionValidator`
    - **Property 11: Region filtering correctness**
    - **Validates: Requirements 4.2**
    - **Property 12: Model ID written correctly based on CRIS requirement**
    - **Validates: Requirements 4.3, 4.4, 4.7**
    - File: `tests/property/test_prop_model_catalog.py`

  - [ ]* 2.2 Write unit tests for `ModelCatalog` and `RegionValidator`
    - Verify all 8 required models are present in `ModelCatalog.MODELS`
    - Test `models_for_region` with known regions, unknown regions (returns all + warning)
    - Test `requires_cris` and `effective_model_id` for native vs CRIS cases
    - File: `tests/unit/test_model_catalog.py`

- [x] 3. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 4. Integrate credential detection and region/model selection into `init_cmd.py`
  - After provider selection, if `provider == "agentcore"`:
    1. Call `CredentialResolver().resolve()` and display source + masked account ID;
       prompt user to confirm or enter a different profile name
    2. If no credentials found, display warning with `aws configure` instructions
    3. Prompt for target AWS region (default: `us-east-1`)
    4. Call `RegionValidator.models_for_region(region)` and display numbered model list
    5. Prompt user to select a model; if CRIS required, display CRIS notice
    6. Store `(region, model_id, cris_enabled, aws_profile)` for use in file generation
  - Update `_generate_project()` to write `aws_region`, `model_id`, `cris_enabled`,
    `aws_profile` fields to `agentcore.yaml`
  - Update `_build_agent_code()` to use the selected `model_id` instead of the hardcoded
    default for AgentCore
  - Apply the same flow in `create_cmd.py` `_create_agent()` for `provider == "agentcore"`
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 4.1, 4.2, 4.3, 4.4, 4.6, 4.7, 7.1_

  - [x] 4.1 Write property tests for agentcore.yaml round-trip
    - **Property 13: agentcore.yaml round-trip persistence**
    - **Validates: Requirements 4.7, 7.1**
    - File: `tests/property/test_prop_model_catalog.py` (extend existing file)

  - [x]* 4.2 Write unit tests for init credential + model flow
    - Test credential confirmation prompt (confirm / decline / no credentials)
    - Test region prompt default value
    - Test model list display and selection
    - Test CRIS notice shown when model requires CRIS
    - Test `agentcore.yaml` written with correct fields
    - File: `tests/unit/test_init_wizard.py`

- [x] 5. Add Tool Wizard and MCP Wizard to `init_cmd.py`
  - After instructions prompt (before confirmation summary), add:
    1. `_run_tool_wizard()` — asks yes/no; if yes, presents `_TOOL_CATALOG` numbered list
       plus "Create custom scaffolding"; handles pre-built selection (writes `tools.py`,
       adds imports to `agent.py`) and custom scaffolding (prompts up to 3 tool names +
       descriptions, generates `@tool` stubs)
    2. `_run_mcp_wizard()` — asks yes/no; if yes, presents `_MCP_CATALOG` numbered list
       plus "Create custom scaffolding"; handles pre-built selection (writes
       `<name>/server.py`, registers MCP client in `agent.py`) and custom scaffolding
       (prompts server name + up to 3 MCP tool names, generates `@mcp.tool()` stubs)
  - Update confirmation summary to list all files that will be created (including
    `tools.py` and MCP server directory if selected)
  - Update `_generate_project()` to call both wizards and incorporate results
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 3.9, 3.10_

  - [ ]* 5.1 Write property tests for tool and MCP wizard
    - **Property 7: Catalog rendering completeness**
    - **Validates: Requirements 3.2, 3.6**
    - **Property 8: Pre-built selection generates correct files**
    - **Validates: Requirements 3.3, 3.7**
    - **Property 9: Custom scaffolding generates stubs for all named items**
    - **Validates: Requirements 3.4, 3.8**
    - **Property 10: Confirmation summary lists all files**
    - **Validates: Requirements 3.10**
    - File: `tests/property/test_prop_init_wizard.py`

  - [ ]* 5.2 Write unit tests for tool and MCP wizard
    - Test yes/no prompts default to no
    - Test pre-built tool selection writes correct `tools.py` and `agent.py` imports
    - Test custom tool scaffolding with 1, 2, and 3 tool names
    - Test pre-built MCP selection writes correct `server.py` and `agent.py` registration
    - Test custom MCP scaffolding with 1, 2, and 3 MCP tool names
    - Test no-selection path produces no extra files
    - File: `tests/unit/test_init_wizard.py` (extend)

- [x] 6. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Implement `Deploy_Wizard` in `synth/cli/deploy_cmd.py`
  - Replace the existing thin wrapper with a full stage runner
  - Define `StageResult` dataclass: `success: bool`, `message: str`,
    `suggestion: str | None`
  - Implement `_print_stage_result(stage_name: str, result: StageResult) -> None` —
    prints `[  OK  ]` or `[FAIL]` with message and suggestion
  - Implement six stage functions:
    - `_stage_credentials(profile: str | None) -> StageResult`
    - `_stage_dependencies() -> StageResult`
    - `_stage_validate_file(file: str) -> StageResult`
    - `_stage_manifest(agent) -> StageResult`
    - `_stage_package(agent, dry_run: bool) -> StageResult`
    - `_stage_submit(manifest, region: str, dry_run: bool) -> StageResult`
  - `run_deploy(target, dry_run, file)` reads `agentcore.yaml` for `aws_profile`,
    `aws_region`, `model_id`; runs stages in order; halts on first failure
  - `--dry-run` runs stages 1–4 only, prefixes output with `[DRY RUN]`
  - On full success, print summary: agent ARN, region, model ID
  - All output via `click.echo()` / `click.style()`; errors via `SynthConfigError`
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7_

  - [ ]* 7.1 Write property tests for `Deploy_Wizard`
    - **Property 5: Deploy stage output formatting**
    - **Validates: Requirements 2.2, 2.3**
    - **Property 6: Deploy stage halts on failure**
    - **Validates: Requirements 2.3**
    - File: `tests/property/test_prop_deploy_wizard.py`

  - [ ]* 7.2 Write unit tests for `Deploy_Wizard`
    - Test stage execution order with all stages succeeding
    - Test halt on stage 1 failure (no subsequent stages run)
    - Test halt on stage 3 failure
    - Test `--dry-run` runs only stages 1–4
    - Test `[DRY RUN]` prefix in dry-run mode
    - Test success summary contains ARN, region, model ID
    - Test AWS Toolkit profile listing when profiles detected
    - File: `tests/unit/test_deploy_wizard.py`

- [x] 8. Add credential scan to `synth/deploy/packager.py`
  - Before copying files into the artifact, scan `agentcore.yaml` (if present) for
    strings matching AWS access key (`AKIA`/`ASIA` + 16 alphanumeric chars) or secret
    key (40-char base64-like) patterns using `re`
  - If any credential pattern found, raise `SynthConfigError` with
    `component="Packager"` and a suggestion to remove credentials from the config file
  - Ensure `.env` files are already in `_EXCLUDED` (they are); verify and add a test
  - _Requirements: 7.6, 8.4, 8.5_

  - [ ]* 8.1 Write property tests for packager security scan
    - **Property 15: Packager credential scan rejects credential patterns**
    - **Validates: Requirements 7.6, 8.4**
    - File: `tests/property/test_prop_packager.py`

  - [ ]* 8.2 Write unit tests for packager security
    - Test that `agentcore.yaml` with AKIA key raises `SynthConfigError`
    - Test that `agentcore.yaml` with ASIA key raises `SynthConfigError`
    - Test that clean `agentcore.yaml` passes without error
    - Test that `.env` file is excluded from artifact
    - File: `tests/unit/test_packager_security.py`

- [x] 9. Implement `Edit_Wizard` in `synth/cli/edit_cmd.py`
  - Create `synth/cli/edit_cmd.py` with `run_edit_agent(file: str) -> None`
  - Read `agent.py` and `agentcore.yaml` (if present); parse current model, instructions,
    tools list, MCP registrations from source text using `re` patterns
  - Display current configuration summary
  - Present menu: (a) instructions, (b) model, (c) tools, (d) MCP servers
  - For "model" + AgentCore: invoke `CredentialResolver` + `RegionValidator` flow
    (same as init); update both `agent.py` and `agentcore.yaml`
  - For "model" + other providers: present provider model list; update `agent.py`
  - For "tools": present `_TOOL_CATALOG` (add/remove); update `tools.py` and `agent.py`
  - For "MCP servers": present `_MCP_Catalog` (add/remove); update `agent.py`
  - Before any write: display diff-style summary of all pending changes; prompt confirm
  - Atomic write: write to `tempfile.NamedTemporaryFile` then `os.replace()` to target
  - If `file` does not exist: raise `SynthConfigError` with `component="EditWizard"`
  - Register `synth edit agent <file>` in `synth/cli/main.py`
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8, 5.9, 5.10, 5.11_

  - [ ]* 9.1 Write property tests for `Edit_Wizard`
    - **Property 14: Edit_Wizard always shows diff before writing**
    - **Validates: Requirements 5.9**
    - File: `tests/property/test_prop_edit_wizard.py`

  - [ ]* 9.2 Write unit tests for `Edit_Wizard`
    - Test config reading from `agent.py` and `agentcore.yaml`
    - Test each menu option updates the correct file
    - Test diff summary shown before write
    - Test atomic write: original file intact if write fails
    - Test missing file raises `SynthConfigError`
    - File: `tests/unit/test_edit_wizard.py`

- [x] 10. Add AgentCore Doctor checks to `synth/cli/doctor.py`
  - At the end of `run_doctor()`, check if `agentcore.yaml` exists in the current dir
  - If present, parse and validate:
    - `aws_region`: check it matches a known AWS region pattern; print `[  OK  ]` or
      `[FAIL]`
    - `model_id`: check it exists in `ModelCatalog` for the configured region; print
      `[  OK  ]` or `[FAIL]`
    - `cris_enabled` vs `model_id`: if model requires CRIS but `cris_enabled` is false
      or absent, print `[FAIL]` with suggestion to re-run `synth edit agent agent.py`
    - `aws_profile` (if set): verify profile exists in `~/.aws/credentials` or AWS
      Toolkit store; print `[  OK  ]` or `[FAIL]`
  - If `agentcore.yaml` not present, skip silently
  - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6_

  - [ ]* 10.1 Write property tests for AgentCore Doctor checks
    - **Property 16: Doctor status output correctness**
    - **Validates: Requirements 6.1, 6.2, 6.3, 6.5**
    - File: `tests/property/test_prop_doctor.py`

  - [ ]* 10.2 Write unit tests for AgentCore Doctor checks
    - Test valid `agentcore.yaml` prints `[  OK  ]` for all fields
    - Test invalid region prints `[FAIL]`
    - Test unknown model ID prints `[FAIL]`
    - Test CRIS mismatch (model requires CRIS, `cris_enabled: false`) prints `[FAIL]`
    - Test valid `aws_profile` prints `[  OK  ]`
    - Test missing `aws_profile` in credentials prints `[FAIL]`
    - Test no `agentcore.yaml` skips all AgentCore checks silently
    - File: `tests/unit/test_doctor_agentcore.py`

- [x] 11. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for a faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation at logical boundaries
- Property tests use Hypothesis with `@settings(max_examples=100)`
- Unit tests use `click.testing.CliRunner` for CLI interaction tests and
  `unittest.mock.patch` for filesystem and boto3 calls
- boto3 is always imported lazily inside methods — never at module level
- Credential values must never appear in any output, log, or file at any point
