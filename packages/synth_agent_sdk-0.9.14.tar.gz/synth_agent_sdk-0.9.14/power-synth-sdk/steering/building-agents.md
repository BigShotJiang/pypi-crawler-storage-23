# Building Agents with Synth SDK

## Installation

```bash
# Core SDK
pip install synth-agent-sdk

# With a specific provider
pip install synth-agent-sdk[anthropic]    # Anthropic (Claude)
pip install synth-agent-sdk[openai]       # OpenAI (GPT)
pip install synth-agent-sdk[google]       # Google (Gemini)
pip install synth-agent-sdk[ollama]       # Ollama (local models)
pip install synth-agent-sdk[bedrock]      # AWS Bedrock
pip install synth-agent-sdk[agentcore]    # AWS AgentCore deployment
pip install synth-agent-sdk[all]          # All providers
```

Core dependencies: pydantic, httpx, click, typing-extensions, rich, prompt-toolkit. The rich terminal UI for `synth dev` is included out of the box.

## Quick Project Setup

The fastest way to start a new project:

```bash
# Interactive setup (walks through provider, features, instructions)
synth init

# Or scaffold directly with provider selection
synth create agent my-bot
synth create agent my-bot --provider openai  # skip prompt

# Scaffold tools, MCP servers, teams, or a testing UI
synth create tool my-tools
synth create mcp my-server
synth create team my-team
synth create ui my-ui
```

## Creating an Agent

### Minimal Agent (3 lines)

```python
from synth import Agent

agent = Agent(model="claude-sonnet-4-5", instructions="You are helpful.")
result = agent.run("Hello!")
print(result.text)
```

### Full Agent Configuration

```python
from synth import Agent, tool, ToolKit, Memory, Guard
from pydantic import BaseModel

class ResponseFormat(BaseModel):
    answer: str
    confidence: float

agent = Agent(
    model="claude-sonnet-4-5",         # Required: model string
    instructions="You are an analyst.", # System prompt
    tools=[my_tool, my_toolkit],       # @tool functions or ToolKit instances
    memory=Memory.thread(),            # Conversation memory backend
    guards=[                           # Input/output guardrails
        Guard.no_pii_output(),
        Guard.max_cost(dollars=1.00),
    ],
    output_schema=ResponseFormat,      # Pydantic model for structured output
    base_url=None,                     # Custom endpoint URL
    max_retries=3,                     # Retries for transient errors
    retry_backoff=1.0,                 # Backoff base in seconds
)
```

### Sync vs Async

```python
# Sync (blocks, returns RunResult)
result = agent.run("Hello", thread_id="t1", run_id="r1")

# Async (non-blocking)
result = await agent.arun("Hello", thread_id="t1", run_id="r1")

# Sync streaming (Generator[StreamEvent])
for event in agent.stream("Hello", thread_id="t1"):
    ...

# Async streaming (AsyncGenerator[StreamEvent])
async for event in agent.astream("Hello", thread_id="t1"):
    ...
```

## Agent Execution Flow

1. Memory retrieval (if configured) — prepend context messages
2. Input guard evaluation (in declaration order)
3. Provider call via ProviderRouter with tool schemas
4. Tool execution loop (if model requests tool calls)
5. Output guard evaluation
6. Structured output parsing (if output_schema set)
7. Trace finalization and attachment to RunResult

## Tool System

### Creating Tools

Every `@tool` function needs type annotations on all parameters and a docstring:

```python
from synth import tool

@tool
def search_database(query: str, limit: int = 10) -> list[dict]:
    """Search the database for records matching the query.

    Returns up to `limit` matching records.
    """
    return [{"id": 1, "name": "Result"}]
```

The decorator generates a JSON schema at decoration time and stores it as `fn._tool_schema`.

Supported types: str, int, float, bool, list, dict. Optional[X] parameters are not marked as required.

### Async Tools

Async tool functions are automatically detected and awaited:

```python
@tool
async def fetch_url(url: str) -> str:
    """Fetch content from a URL."""
    async with httpx.AsyncClient() as client:
        resp = await client.get(url)
        return resp.text
```

### ToolKit

Group related tools into a single unit:

```python
from synth import ToolKit

@tool
def create_user(name: str, email: str) -> dict:
    """Create a new user account."""
    return {"id": 1, "name": name, "email": email}

@tool
def delete_user(user_id: int) -> bool:
    """Delete a user by ID."""
    return True

user_tools = ToolKit([create_user, delete_user])
agent = Agent(model="gpt-4o", tools=[user_tools])
```

ToolKit methods:
- `toolkit.get_schemas()` — returns list of JSON schema dicts
- `toolkit.get_tools()` — returns dict mapping name → function

### Tool Errors

- `ToolDefinitionError` — raised at decoration time if annotations or docstring missing
- `ToolExecutionError` — raised at runtime if the tool function throws; includes `tool_name`, `tool_args`, and `original_error`
- `TypeMismatchWarning` — emitted if return value doesn't match declared return type

## Memory

### Thread Memory (In-Process)

Stores messages in a dict keyed by thread_id. Lost when the process exits.

```python
agent = Agent(model="claude-sonnet-4-5", memory=Memory.thread())

# Same thread_id = conversation continues
agent.run("I'm working on Project X", thread_id="session-42")
agent.run("What project am I working on?", thread_id="session-42")
# → "You're working on Project X"

# No thread_id = stateless single-turn
agent.run("Hello")  # No memory retrieval
```

### Persistent Memory (Redis)

Survives process restarts. Stores messages in Redis lists.

```python
agent = Agent(
    model="gpt-4o",
    memory=Memory.persistent("redis://localhost:6379"),
)
```

### Semantic Memory (Vector Embeddings)

Retrieves only the most relevant context chunks using cosine similarity:

```python
agent = Agent(
    model="gpt-4o",
    memory=Memory.semantic(embedder=my_embedding_function),
)
```

### Context Truncation

When a thread's token count approaches the model's context limit, memory automatically summarizes older messages and emits a `ContextTruncationWarning`.

## Guards

Guards are evaluated in declaration order. First violation stops evaluation and raises `GuardViolationError`.

### PII Guard

Scans the full response text for PII patterns (email, phone, SSN, credit card, address):

```python
Guard.no_pii_output()
```

### Cost Guard

Tracks cumulative cost across the run:

```python
Guard.max_cost(dollars=0.50)
# Raises CostLimitError if exceeded
```

### Tool Filter Guard

Blocks tool calls matching glob patterns:

```python
Guard.no_tool_calls(["delete_*", "drop_*"])
# Raises GuardViolationError if agent tries to call delete_user
```

### Custom Guard

Wrap any function as a guard:

```python
def no_profanity(content: str) -> bool:
    """Return False if content contains profanity."""
    return not any(word in content.lower() for word in BAD_WORDS)

Guard.custom(no_profanity)
```

Custom guard functions are wrapped in try/except. An unhandled exception is treated as a violation.

## Structured Output

Force the model to return validated, typed objects:

```python
from pydantic import BaseModel

class ExtractedEntity(BaseModel):
    name: str
    entity_type: str
    confidence: float

agent = Agent(model="claude-sonnet-4-5", output_schema=ExtractedEntity)
result = agent.run("Extract entities from: 'Apple released the iPhone 16'")

entity = result.output  # ExtractedEntity instance
print(entity.name)           # "Apple"
print(entity.entity_type)    # "company"
print(entity.confidence)     # 0.98
```

On parse failure, the SDK retries with a corrective prompt (up to `max_retries`). After exhausting retries, raises `SynthParseError`.

Use constrained Pydantic types (max_length, regex patterns, value ranges) to limit the attack surface of model-generated data.

## Provider Configuration

### Environment Variables

Each provider reads credentials from standard env vars:

| Provider | Env Var |
|----------|---------|
| Anthropic | `ANTHROPIC_API_KEY` |
| OpenAI | `OPENAI_API_KEY` |
| Google | `GOOGLE_API_KEY` |
| Ollama | (none — local) |
| Bedrock | AWS credentials (IAM role, `AWS_ACCESS_KEY_ID`, etc.) |

Missing credentials raise `SynthConfigError` naming the expected env var.

### Custom Endpoints

```python
# OpenAI-compatible local server
agent = Agent(model="my-model", base_url="http://localhost:8000/v1")

# Ollama
agent = Agent(model="ollama/llama3")
```

### Retry Behavior

Transient errors (HTTP 429, 5xx) are retried with exponential backoff:
- Delay: `base * 2^attempt` with jitter
- Configurable via `max_retries` and `retry_backoff` on Agent

## Tracing

Every run automatically produces a trace:

```python
result = agent.run("Hello")

# View in browser
result.trace.show()

# Export as OpenTelemetry JSON
result.trace.export("trace.json")
```

Auto-forward traces by setting `SYNTH_TRACE_ENDPOINT` env var.

Integrations: Langfuse, Datadog, Honeycomb (one-line config each).

## Environment Variables

| Variable | Purpose |
|----------|---------|
| `SYNTH_TRACE_ENDPOINT` | Auto-forward traces to OTEL collector |
| `SYNTH_NO_BANNER` | Skip terminal boot sequence |
| `ANTHROPIC_API_KEY` | Anthropic API key |
| `OPENAI_API_KEY` | OpenAI API key |
| `GOOGLE_API_KEY` | Google API key |
| `AWS_*` | AWS credentials for Bedrock |
