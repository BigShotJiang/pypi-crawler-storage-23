# Main Memory

## About the User

(Empty -- will be populated as you learn about your human.)

## Learned Facts

(Empty -- will be populated as the agent learns.)

## Decisions and Preferences

(Empty -- record important decisions and their reasoning here.)
