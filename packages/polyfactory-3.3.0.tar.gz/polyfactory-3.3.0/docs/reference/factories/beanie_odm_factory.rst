beanie_odm_factory
==================

.. automodule:: polyfactory.factories.beanie_odm_factory
    :members:
