attrs_factory
================

.. automodule:: polyfactory.factories.attrs_factory
    :members:
