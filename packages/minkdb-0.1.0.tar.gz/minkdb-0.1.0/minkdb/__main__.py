"""Entry point for python -m minkdb."""

from minkdb.cli import main

if __name__ == "__main__":
    main()
