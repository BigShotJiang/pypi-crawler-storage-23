"""Mink-db - A metadata-link between iTunes and MusicBrainz."""

__version__ = "0.1.0"
