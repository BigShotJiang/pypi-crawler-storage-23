"""
nodelink
~~~~~~~~
A high-level Python multiplayer library. Just works.

Basic usage::

    from nodelink import Server, Client

    # Server
    server = Server(port=5000)

    @server.on("connect")
    def on_connect(player):
        server.broadcast("joined", {"id": player.id})

    server.start()

    # Client
    client = Client("localhost", 5000)

    @client.on("joined")
    def on_joined(data):
        print(f"Player {data['id']} joined!")

    client.connect()

:copyright: 2024 Marcus
:license: MIT
"""

from .server import Server, ServerState
from .client import Client
from .player import Player
from .room import Room

__version__ = "0.3.0"
__author__ = "Marcus"
__all__ = ["Server", "ServerState", "Client", "Player", "Room"]
