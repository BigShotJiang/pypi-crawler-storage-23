import json
import os
import subprocess
from collections import deque
from contextlib import asynccontextmanager
from datetime import date, datetime, time
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Form, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from neo4j import GraphDatabase
from neo4j.exceptions import ClientError


NEO4J_URI = os.getenv("NEO4J_URI", "bolt://127.0.0.1:7687")
NEO4J_USER = os.getenv("NEO4J_USER", "")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "")
NEO4J_DATABASE = os.getenv("NEO4J_DATABASE", "neo4j")
GRAPH_STATE_KEY = "default"
INTERNAL_APP_LABEL = "faikdev/AppGraphState"
LEGACY_APP_LABEL = "AppGraphState"
BASE_DIR = Path(__file__).resolve().parent
PACKAGE_ASSET_DIR = BASE_DIR / "faik_inventory"
RUNTIME_DIR = BASE_DIR if (BASE_DIR / "configuration").exists() else PACKAGE_ASSET_DIR
STATIC_DIR = RUNTIME_DIR / "static"
FRONTEND_INDEX = STATIC_DIR / "app" / "index.html"
CONFIG_DIR = RUNTIME_DIR / "configuration"


def load_config(filename: str) -> dict[str, Any]:
    with open(CONFIG_DIR / filename) as f:
        return json.load(f)


def load_optional_config(filename: str, default: dict[str, Any] | None = None) -> dict[str, Any]:
    file_path = CONFIG_DIR / filename
    if not file_path.exists():
        return {} if default is None else default
    return load_config(filename)


def unique_strings(values: Any) -> list[str]:
    result: list[str] = []
    if not isinstance(values, list):
        return result
    for value in values:
        cleaned = str(value).strip()
        if cleaned and cleaned not in result:
            result.append(cleaned)
    return result


def normalize_node_types(raw: Any) -> dict[str, dict[str, Any]]:
    if not isinstance(raw, dict):
        return {}
    normalized: dict[str, dict[str, Any]] = {}
    for node_key, value in raw.items():
        entry = value if isinstance(value, dict) else {}
        key = str(entry.get("key", node_key)).strip() or str(node_key).strip()
        if not key:
            continue
        picker = entry.get("picker", {})
        normalized[key] = {
            **entry,
            "key": key,
            "display": str(entry.get("display", key)).strip() or key,
            "group": str(entry.get("group", "Other")).strip() or "Other",
            "fields": entry.get("fields", {}) if isinstance(entry.get("fields"), dict) else {},
            "picker": picker if isinstance(picker, dict) else {},
            "source": unique_strings(entry.get("source", [])),
            "target": unique_strings(entry.get("target", [])),
        }
    return normalized


def normalize_creation_rules(raw: Any) -> dict[str, dict[str, Any]]:
    if not isinstance(raw, dict):
        return {}
    normalized: dict[str, dict[str, Any]] = {}
    for rule_key, value in raw.items():
        if not isinstance(value, dict):
            continue
        node_type_key = str(value.get("node_type_key", rule_key)).strip() or str(rule_key).strip()
        if not node_type_key:
            continue
        relationships = value.get("required_relationships", [])
        if not isinstance(relationships, list):
            relationships = []
        normalized[node_type_key] = {
            "node_type_key": node_type_key,
            "required_relationships": [entry for entry in relationships if isinstance(entry, dict)],
        }
    return normalized


def build_label_form_definitions(node_types: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    definitions: dict[str, dict[str, Any]] = {}
    for node_key, node_type in node_types.items():
        definitions[node_key] = {
            "label": node_type.get("display", node_key),
            "description": node_type.get("description", ""),
            "fields": node_type.get("fields", {}),
        }
    return definitions


def build_node_label_options(node_types: dict[str, dict[str, Any]]) -> dict[str, list[dict[str, str]]]:
    grouped: dict[str, list[dict[str, str]]] = {}
    for node_type in node_types.values():
        group = str(node_type.get("group", "Other")).strip() or "Other"
        grouped.setdefault(group, []).append({
            "key": node_type["key"],
            "display": str(node_type.get("display", node_type["key"])),
        })
    for items in grouped.values():
        items.sort(key=lambda item: item["display"])
    return dict(sorted(grouped.items(), key=lambda item: item[0]))


def default_edge_display_name(edge_key: str) -> str:
    return edge_key.upper()


def ensure_picker_definition(
    picker_definitions: dict[str, dict[str, Any]],
    picker_key: str,
    picker_definition: dict[str, Any],
) -> None:
    picker_definitions[picker_key] = {
        "primary_fields": unique_strings(picker_definition.get("primary_fields", [])),
        "context_fields": unique_strings(picker_definition.get("context_fields", [])),
        "lineage": picker_definition.get("lineage", []) if isinstance(picker_definition.get("lineage", []), list) else [],
    }


def build_picker_display_definitions(
    node_types: dict[str, dict[str, Any]],
    creation_rules: dict[str, dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    definitions: dict[str, dict[str, Any]] = {
        "generic_node": {
            "primary_fields": [
                "name",
                "database_name",
                "schema_name",
                "table_name",
                "column_name",
                "bucket_name",
                "file_name",
                "job_name",
                "execution_id",
                "service_name",
                "endpoint_name",
                "hosting_name",
                "language_name",
                "repository_name",
                "pipeline_name",
                "principal_name",
                "environment_name",
                "host_name",
                "technology_name",
            ],
            "context_fields": [],
            "lineage": [],
        }
    }
    for node_key, node_type in node_types.items():
        ensure_picker_definition(
            definitions,
            f"node_type__{node_key}",
            node_type.get("picker", {}) if isinstance(node_type.get("picker"), dict) else {},
        )
    for node_key, rule in creation_rules.items():
        for relationship in rule.get("required_relationships", []):
            picker_override = relationship.get("picker_override")
            if not isinstance(picker_override, dict):
                continue
            relationship_key = str(relationship.get("relationship_type_key", "")).strip()
            direction = str(relationship.get("direction", "outgoing")).strip() or "outgoing"
            if not relationship_key:
                continue
            picker_key = f"{node_key}__{relationship_key}__{direction}__picker_override"
            ensure_picker_definition(definitions, picker_key, picker_override)
    return definitions


def build_edge_type_definitions(
    node_types: dict[str, dict[str, Any]],
    creation_rules: dict[str, dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    definitions: dict[str, dict[str, Any]] = {}

    def ensure_edge(edge_key: str) -> dict[str, Any]:
        definitions.setdefault(edge_key, {
            "label": default_edge_display_name(edge_key),
            "description": "",
            "source_labels": [],
            "target_labels": [],
        })
        return definitions[edge_key]

    for node_key, node_type in node_types.items():
        for edge_key in unique_strings(node_type.get("source", [])):
            edge = ensure_edge(edge_key)
            if node_key not in edge["source_labels"]:
                edge["source_labels"].append(node_key)
        for edge_key in unique_strings(node_type.get("target", [])):
            edge = ensure_edge(edge_key)
            if node_key not in edge["target_labels"]:
                edge["target_labels"].append(node_key)

    for node_key, rule in creation_rules.items():
        for relationship in rule.get("required_relationships", []):
            edge_key = str(relationship.get("relationship_type_key", "")).strip()
            direction = str(relationship.get("direction", "outgoing")).strip() or "outgoing"
            target_keys = unique_strings(relationship.get("target_node_type_keys", []))
            if not edge_key:
                continue
            edge = ensure_edge(edge_key)
            if direction == "incoming":
                for source_label in target_keys:
                    if source_label not in edge["source_labels"]:
                        edge["source_labels"].append(source_label)
                if node_key not in edge["target_labels"]:
                    edge["target_labels"].append(node_key)
            else:
                if node_key not in edge["source_labels"]:
                    edge["source_labels"].append(node_key)
                for target_label in target_keys:
                    if target_label not in edge["target_labels"]:
                        edge["target_labels"].append(target_label)

    return definitions


def resolve_default_picker_display_key(target_node_type_keys: list[str]) -> str:
    if len(target_node_type_keys) == 1:
        return f"node_type__{target_node_type_keys[0]}"
    return "generic_node"


def build_node_entry_rules(
    creation_rules: dict[str, dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    rules: dict[str, dict[str, Any]] = {}
    for node_type_key, rule in creation_rules.items():
        required_edges: list[dict[str, Any]] = []
        for index, relationship in enumerate(rule.get("required_relationships", []), start=1):
            relationship_key = str(relationship.get("relationship_type_key", "")).strip()
            if not relationship_key:
                continue
            direction = str(relationship.get("direction", "outgoing")).strip() or "outgoing"
            target_node_type_keys = unique_strings(relationship.get("target_node_type_keys", []))
            edge_field_key = str(relationship.get("key", "")).strip() or f"{relationship_key}_{direction}_{index}"
            picker_key = resolve_default_picker_display_key(target_node_type_keys)
            picker_override = relationship.get("picker_override")
            if isinstance(picker_override, dict):
                picker_key = f"{node_type_key}__{relationship_key}__{direction}__picker_override"
            required_edges.append({
                "key": edge_field_key,
                "edge_key": relationship_key,
                "target_label_keys": target_node_type_keys,
                "direction": direction,
                "required": True,
                "mode": str(relationship.get("mode", "multiple")).strip() or "multiple",
                "label": str(relationship.get("label", relationship_key)).strip() or relationship_key,
                "help": str(relationship.get("help", "")).strip(),
                "picker_display": picker_key,
            })
        rules[node_type_key] = {"required_edges": required_edges}
    return rules


def reload_runtime_config() -> None:
    global COMMON_OPTIONS
    global NODE_TYPES
    global CREATION_RULES
    global LABEL_FORM_DEFINITIONS
    global NODE_LABEL_OPTIONS
    global TAG_SELECTOR_DEMO_OPTIONS
    global FIELD_REGISTRY
    global EDGE_TYPE_DEFINITIONS
    global PICKER_DISPLAY_DEFINITIONS
    global NODE_ENTRY_RULES

    COMMON_OPTIONS = load_config("common_options.json")

    node_types_file = CONFIG_DIR / "node_types.json"
    if node_types_file.exists():
        NODE_TYPES = normalize_node_types(load_config("node_types.json"))
        CREATION_RULES = normalize_creation_rules(load_optional_config("creation_rules.json", {}))
        LABEL_FORM_DEFINITIONS = build_label_form_definitions(NODE_TYPES)
        NODE_LABEL_OPTIONS = build_node_label_options(NODE_TYPES)
        PICKER_DISPLAY_DEFINITIONS = build_picker_display_definitions(NODE_TYPES, CREATION_RULES)
        EDGE_TYPE_DEFINITIONS = build_edge_type_definitions(NODE_TYPES, CREATION_RULES)
        NODE_ENTRY_RULES = build_node_entry_rules(CREATION_RULES)
    else:
        # Backward-compatible fallback for legacy split config files.
        LABEL_FORM_DEFINITIONS = load_config("label_form_definitions.json")
        NODE_LABEL_OPTIONS = load_config("node_label_options.json")
        EDGE_TYPE_DEFINITIONS = load_config("edge_type_definitions.json")
        PICKER_DISPLAY_DEFINITIONS = load_config("picker_display_definitions.json")
        NODE_ENTRY_RULES = load_config("node_entry_rules.json")
        NODE_TYPES = {
            key: {
                "key": key,
                "display": definition.get("label", key),
                "group": "Other",
                "fields": definition.get("fields", {}),
                "picker": PICKER_DISPLAY_DEFINITIONS.get(f"node_type__{key}", {}),
                "source": [],
                "target": [],
            }
            for key, definition in LABEL_FORM_DEFINITIONS.items()
        }
        CREATION_RULES = {}

    TAG_SELECTOR_DEMO_OPTIONS = NODE_LABEL_OPTIONS
    FIELD_REGISTRY = build_field_registry(LABEL_FORM_DEFINITIONS)


def build_field_registry(label_form_definitions: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    field_registry: dict[str, dict[str, Any]] = {}
    for label_definition in label_form_definitions.values():
        for field_key, field_definition in label_definition["fields"].items():
            existing = field_registry.get(field_key)
            if existing is None:
                field_registry[field_key] = field_definition
            elif existing["type"] != field_definition["type"]:
                raise ValueError(f"Field '{field_key}' has conflicting types in form definitions.")
    return field_registry


reload_runtime_config()


def make_json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: make_json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [make_json_safe(item) for item in value]
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if hasattr(value, "isoformat"):
        return value.isoformat()
    if hasattr(value, "iso_format"):
        return value.iso_format()
    if hasattr(value, "items"):
        return {key: make_json_safe(item) for key, item in value.items()}
    return value


def parse_properties(raw: str) -> dict[str, Any]:
    raw = raw.strip()
    if not raw:
        return {}
    parsed = json.loads(raw)
    if not isinstance(parsed, dict):
        raise ValueError("Properties must be a JSON object.")
    return parsed


def parse_labels(raw: str) -> list[str]:
    raw = raw.strip()
    if not raw:
        return []
    if raw.startswith("["):
        parsed = json.loads(raw)
        if not isinstance(parsed, list):
            raise ValueError("Labels must be a JSON array or comma-separated string.")
        labels = []
        for item in parsed:
            if not isinstance(item, str):
                raise ValueError("Each label must be a string.")
            cleaned = item.strip()
            if cleaned and cleaned not in labels:
                labels.append(cleaned)
        return labels
    labels = []
    for item in raw.split(","):
        cleaned = item.strip()
        if cleaned and cleaned not in labels:
            labels.append(cleaned)
    return labels


def resolve_label_names(selected_labels: list[str]) -> list[str]:
    resolved = []
    for label in selected_labels:
        definition = LABEL_FORM_DEFINITIONS.get(label)
        display_label = definition["label"] if definition else label
        if display_label not in resolved:
            resolved.append(display_label)
    return resolved


def label_key_to_display(label_key: str) -> str:
    definition = LABEL_FORM_DEFINITIONS.get(label_key)
    return definition["label"] if definition else label_key


def display_labels_for_label_keys(label_keys: list[str]) -> list[str]:
    return [label_key_to_display(label_key) for label_key in label_keys]


def first_present_property(props: dict[str, Any], property_names: list[str]) -> str:
    for property_name in property_names:
        value = props.get(property_name)
        if value is None:
            continue
        cleaned = str(value).strip()
        if cleaned:
            return cleaned
    return ""


def build_node_display(props: dict[str, Any], fallback_id: str) -> str:
    return (
        props.get("name")
        or props.get("database_name")
        or props.get("schema_name")
        or props.get("table_name")
        or props.get("column_name")
        or props.get("bucket_name")
        or props.get("file_name")
        or props.get("job_name")
        or props.get("execution_id")
        or props.get("service_name")
        or props.get("endpoint_name")
        or props.get("hosting_name")
        or props.get("language_name")
        or props.get("repository_name")
        or props.get("pipeline_name")
        or props.get("principal_name")
        or props.get("environment_name")
        or fallback_id
    )


def collect_required_edge_fields(selected_labels: list[str]) -> list[dict[str, Any]]:
    fields: list[dict[str, Any]] = []
    seen_keys: set[str] = set()
    for label in selected_labels:
        rule = NODE_ENTRY_RULES.get(label, {})
        for edge_field in rule.get("required_edges", []):
            field_key = str(edge_field.get("key", "")).strip()
            if not field_key or field_key in seen_keys:
                continue
            seen_keys.add(field_key)
            fields.append({
                "key": field_key,
                "edge_key": edge_field["edge_key"],
                "target_label_keys": list(edge_field.get("target_label_keys", [])),
                "direction": edge_field.get("direction", "outgoing"),
                "required": bool(edge_field.get("required", False)),
                "mode": edge_field.get("mode", "multiple"),
                "label": edge_field.get("label") or edge_field["edge_key"],
                "help": edge_field.get("help", ""),
                "picker_display": edge_field.get("picker_display", "generic_node"),
            })
    return fields


def build_edge_selector_options(selected_labels: list[str]) -> list[dict[str, str]]:
    options = []
    for edge_key, edge_definition in EDGE_TYPE_DEFINITIONS.items():
        if not any(label in edge_definition["source_labels"] for label in selected_labels):
            continue
        options.append({"key": edge_key, "display": edge_definition["label"]})
    options.sort(key=lambda item: item["display"])
    return options


def build_all_edge_options() -> list[dict[str, str]]:
    options = [
        {"key": edge_key, "display": edge_definition["label"]}
        for edge_key, edge_definition in EDGE_TYPE_DEFINITIONS.items()
    ]
    options.sort(key=lambda item: item["display"])
    return options


def resolve_edge_type_names(selected_edge_keys: list[str]) -> list[str]:
    resolved = []
    for edge_key in selected_edge_keys:
        definition = EDGE_TYPE_DEFINITIONS.get(edge_key)
        relationship_type = definition["label"] if definition else edge_key
        if relationship_type not in resolved:
            resolved.append(relationship_type)
    return resolved


def collect_field_definitions(selected_labels: list[str]) -> dict[str, dict[str, Any]]:
    collected: dict[str, dict[str, Any]] = {}
    for label in selected_labels:
        definition = LABEL_FORM_DEFINITIONS.get(label)
        if not definition:
            continue
        for field_key, field_definition in definition["fields"].items():
            merged = dict(collected.get(field_key, field_definition))
            merged.setdefault("labels", [])
            if definition["label"] not in merged["labels"]:
                merged["labels"] = [*merged["labels"], definition["label"]]
            merged["required"] = merged.get("required", False) or field_definition.get("required", False)
            collected[field_key] = merged
    return collected


def parse_selector_value(raw: str, mode: str) -> Any:
    cleaned = raw.strip()
    if not cleaned:
        return [] if mode == "multiple" else ""
    if mode == "multiple":
        if cleaned.startswith("["):
            parsed = json.loads(cleaned)
            if not isinstance(parsed, list) or not all(isinstance(item, str) for item in parsed):
                raise ValueError("Selector values must be a JSON array of strings.")
            return [item.strip() for item in parsed if item.strip()]
        return [item.strip() for item in cleaned.split(",") if item.strip()]
    return cleaned


def parse_edge_targets(form_data: Any, edge_keys: list[str]) -> dict[str, list[str]]:
    targets: dict[str, list[str]] = {}
    for edge_key in edge_keys:
        raw = str(form_data.get(f"edge_target__{edge_key}", "")).strip()
        if not raw:
            continue
        parsed = parse_selector_value(raw, "multiple")
        if isinstance(parsed, list) and parsed:
            targets[edge_key] = parsed
    return targets


def parse_required_edge_targets(form_data: Any, edge_fields: list[dict[str, Any]]) -> dict[str, list[str]]:
    targets: dict[str, list[str]] = {}
    for edge_field in edge_fields:
        raw = str(form_data.get(f"required_edge_target__{edge_field['key']}", "")).strip()
        parsed = parse_selector_value(raw, edge_field.get("mode", "multiple"))
        values = parsed if isinstance(parsed, list) else ([parsed] if parsed else [])
        cleaned_values = [value for value in values if str(value).strip()]
        if edge_field.get("required") and not cleaned_values:
            raise ValueError(f"{edge_field['label']} is required.")
        if cleaned_values:
            targets[edge_field["key"]] = cleaned_values
    return targets


def fetch_node_labels_by_id(app_state: Any, node_id: str) -> list[str]:
    cleaned = node_id.strip()
    if not cleaned:
        return []
    with get_session(app_state) as session:
        record = session.run(
            """
            MATCH (n)
            WHERE elementId(n) = $node_id
            RETURN labels(n) AS labels
            """,
            node_id=cleaned,
        ).single()
    if record is None:
        return []
    return [str(label) for label in record.get("labels", [])]


def fetch_picker_lineage_context(
    app_state: Any,
    node_id: str,
    display_definition: dict[str, Any],
) -> dict[str, str]:
    lineage_steps = display_definition.get("lineage", [])
    if not lineage_steps:
        return {}
    target_labels = list({label_key_to_display(str(step.get("label_key", "")).strip()) for step in lineage_steps if str(step.get("label_key", "")).strip()})
    if not target_labels:
        return {}
    with get_session(app_state) as session:
        rows = make_json_safe(session.run(
            """
            MATCH path = (ancestor)-[*1..6]->(node)
            WHERE elementId(node) = $node_id
              AND any(label IN labels(ancestor) WHERE label IN $target_labels)
            RETURN labels(ancestor) AS labels, properties(ancestor) AS props, length(path) AS depth
            ORDER BY depth ASC
            """,
            node_id=node_id,
            target_labels=target_labels,
        ).data())
    context: dict[str, str] = {}
    for step in lineage_steps:
        label_key = str(step.get("label_key", "")).strip()
        property_name = str(step.get("property", "")).strip()
        if not label_key or not property_name or context.get(label_key):
            continue
        display_label = label_key_to_display(label_key)
        for row in rows:
            row_labels = [str(item) for item in row.get("labels", [])]
            if display_label not in row_labels:
                continue
            value = first_present_property(row.get("props", {}), [property_name, "name"])
            if value:
                context[label_key] = value
                break
    return context


def fetch_default_upstream_names(app_state: Any, node_id: str) -> list[str]:
    with get_session(app_state) as session:
        record = session.run(
            """
            MATCH path = (ancestor)-[*1..6]->(node)
            WHERE elementId(node) = $node_id
            RETURN [n IN nodes(path)[0..-1] | properties(n)] AS ancestor_props, length(path) AS depth
            ORDER BY depth DESC
            LIMIT 1
            """,
            node_id=node_id,
        ).single()
    row = make_json_safe(dict(record)) if record is not None else None
    if not row:
        return []
    names: list[str] = []
    for props in row.get("ancestor_props", []):
        if not isinstance(props, dict):
            continue
        name = build_node_display(props, "")
        cleaned = str(name).strip()
        if cleaned and cleaned not in names:
            names.append(cleaned)
    names.reverse()
    return names


def build_picker_option_display(
    props: dict[str, Any],
    node_id: str,
    display_definition_key: str,
    app_state: Any,
) -> str:
    display_definition = PICKER_DISPLAY_DEFINITIONS.get(display_definition_key, PICKER_DISPLAY_DEFINITIONS["generic_node"])
    primary = first_present_property(props, list(display_definition.get("primary_fields", []))) or build_node_display(props, node_id)
    context_parts = []
    for property_name in display_definition.get("context_fields", []):
        value = props.get(property_name)
        if value is None:
            continue
        cleaned = str(value).strip()
        if cleaned:
            context_parts.append(cleaned)
    lineage_context = fetch_picker_lineage_context(app_state, node_id, display_definition)
    for step in display_definition.get("lineage", []):
        label_key = str(step.get("label_key", "")).strip()
        value = lineage_context.get(label_key)
        if value:
            context_parts.append(value)
    fallback_upstream_names = fetch_default_upstream_names(app_state, node_id)
    if fallback_upstream_names:
        context_parts = fallback_upstream_names
    if not context_parts:
        return primary
    return f"{primary} ({' / '.join(context_parts)})"


def fetch_target_node_options(
    app_state: Any,
    edge_key: str,
    source_labels: list[str],
    query: str = "",
    target_label_keys: list[str] | None = None,
    picker_display: str = "generic_node",
    direction: str = "outgoing",
) -> Any:
    edge_definition = EDGE_TYPE_DEFINITIONS.get(edge_key)
    if not edge_definition:
        return []
    source_side = edge_definition["source_labels"] if direction != "incoming" else edge_definition["target_labels"]
    candidate_side = target_label_keys or (edge_definition["target_labels"] if direction != "incoming" else edge_definition["source_labels"])
    allowed_source_labels = set(source_side) | set(display_labels_for_label_keys(source_side))
    if not any(label in allowed_source_labels for label in source_labels):
        return []
    display_labels = display_labels_for_label_keys(candidate_side)
    cleaned_query = query.strip().lower()
    with get_session(app_state) as session:
        rows = make_json_safe(session.run(
            """
            MATCH (n)
            WHERE any(label IN labels(n) WHERE label IN $target_labels)
              AND (
                $search_query = ""
                OR toLower(
                  coalesce(n.name, "")
                  + " " + coalesce(n.database_name, "")
                  + " " + coalesce(n.schema_name, "")
                  + " " + coalesce(n.table_name, "")
                  + " " + coalesce(n.column_name, "")
                  + " " + coalesce(n.bucket_name, "")
                  + " " + coalesce(n.file_name, "")
                  + " " + coalesce(n.job_name, "")
                  + " " + coalesce(n.execution_id, "")
                  + " " + coalesce(n.service_name, "")
                  + " " + coalesce(n.endpoint_name, "")
                  + " " + coalesce(n.hosting_name, "")
                  + " " + coalesce(n.language_name, "")
                  + " " + coalesce(n.repository_name, "")
                  + " " + coalesce(n.pipeline_name, "")
                  + " " + coalesce(n.principal_name, "")
                  + " " + coalesce(n.environment_name, "")
                  + " " + reduce(acc = "", label IN labels(n) | acc + " " + label)
                  + " " + elementId(n)
                ) CONTAINS $search_query
              )
            RETURN elementId(n) AS id, labels(n) AS labels, properties(n) AS props
            ORDER BY coalesce(properties(n).name, properties(n).table_name, properties(n).service_name, properties(n).job_name, elementId(n))
            LIMIT 50
            """,
            target_labels=display_labels,
            search_query=cleaned_query,
        ).data())

    grouped: dict[str, list[dict[str, str]]] = {}
    for row in rows:
        matching_labels = [label for label in row["labels"] if label in display_labels]
        if not matching_labels:
            continue
        group_label = matching_labels[0]
        props = row.get("props", {})
        display = build_picker_option_display(props, row["id"], picker_display, app_state)
        search_text = f"{display} {' '.join(str(label) for label in row.get('labels', []))} {row['id']}".lower()
        if cleaned_query and cleaned_query not in search_text:
            continue
        grouped.setdefault(group_label, []).append({
            "key": row["id"],
            "display": display,
        })
    return grouped


def build_node_summary(row: dict[str, Any]) -> dict[str, Any]:
    props = row.get("props", {})
    display = build_node_display(props, row["id"])
    return {
        "id": row["id"],
        "labels": row.get("labels", []),
        "display": display,
    }


def create_node_record(app_state: Any, form_data: Any) -> dict[str, Any]:
    label_list = parse_labels(str(form_data.get("labels", "")))
    if not label_list:
        raise ValueError("Enter at least one label.")
    required_edge_fields = collect_required_edge_fields(label_list)
    guided_properties = build_guided_properties(form_data, label_list)
    extra_properties = parse_properties(str(form_data.get("properties", "")))
    props = dict(extra_properties)
    props.update(guided_properties)
    edge_keys = parse_labels(str(form_data.get("planned_edge_types", "")))
    edge_targets = parse_edge_targets(form_data, edge_keys)
    required_edge_targets = parse_required_edge_targets(form_data, required_edge_fields)
    resolved_labels = resolve_label_names(label_list)
    label_fragment = ":".join(quote_identifier(label) for label in resolved_labels)
    query = f"CREATE (n:{label_fragment} $props) RETURN elementId(n) AS id"
    created_relationships: list[dict[str, Any]] = []
    with get_session(app_state) as session:
        result = session.run(query, props=props).single()
        node_id = result["id"]
        relationship_requests = [
            *[
                {"edge_key": edge_key, "target_ids": target_ids, "target_label_keys": None}
                for edge_key, target_ids in edge_targets.items()
            ],
            *[
                {
                    "edge_key": edge_field["edge_key"],
                    "target_ids": required_edge_targets.get(edge_field["key"], []),
                    "target_label_keys": edge_field.get("target_label_keys", []),
                    "direction": edge_field.get("direction", "outgoing"),
                }
                for edge_field in required_edge_fields
            ],
        ]
        for request in relationship_requests:
            edge_definition = EDGE_TYPE_DEFINITIONS.get(request["edge_key"])
            if edge_definition is None:
                continue
            relationship_type = quote_identifier(edge_definition["label"])
            allowed_target_labels = set(display_labels_for_label_keys(request["target_label_keys"] or edge_definition["target_labels"]))
            for target_id in request["target_ids"]:
                target_labels = fetch_node_labels_by_id(app_state, target_id)
                if allowed_target_labels and not any(label in allowed_target_labels for label in target_labels):
                    raise ValueError(f"A selected target is not valid for {edge_definition['label']}.")
                source_id = node_id
                end_id = target_id
                if request.get("direction") == "incoming":
                    source_id = target_id
                    end_id = node_id
                relationship_result = session.run(
                    f"""
                    MATCH (source), (target)
                    WHERE elementId(source) = $source_id AND elementId(target) = $target_id
                    CREATE (source)-[r:{relationship_type}]->(target)
                    RETURN elementId(r) AS id,
                           type(r) AS type,
                           elementId(source) AS start_id,
                           elementId(target) AS end_id,
                           properties(r) AS props
                    """,
                    source_id=source_id,
                    target_id=end_id,
                ).single()
                if relationship_result is not None:
                    created_relationships.append(make_json_safe(dict(relationship_result)))
    return {
        "id": node_id,
        "labels": resolved_labels,
        "props": make_json_safe(props),
        "relationships": created_relationships,
    }


def create_relationship_record(
    app_state: Any,
    start_node_id: str,
    relationship_type: str,
    end_node_id: str,
    properties: str = "",
) -> dict[str, Any]:
    props = parse_properties(properties)
    start_id = start_node_id.strip()
    end_id = end_node_id.strip()
    edge_key = relationship_type.strip()
    edge_definition = EDGE_TYPE_DEFINITIONS.get(edge_key)
    if not start_id:
        raise ValueError("Choose a start node.")
    if not end_id:
        raise ValueError("Choose an end node.")
    if not edge_key:
        raise ValueError("Choose a relationship type.")
    if edge_definition:
        start_labels = fetch_node_labels_by_id(app_state, start_id)
        end_labels = fetch_node_labels_by_id(app_state, end_id)
        allowed_source_labels = set(display_labels_for_label_keys(edge_definition["source_labels"]))
        allowed_target_labels = set(display_labels_for_label_keys(edge_definition["target_labels"]))
        if not any(label in allowed_source_labels for label in start_labels):
            raise ValueError("The selected start node is not valid for that relationship type.")
        if not any(label in allowed_target_labels for label in end_labels):
            raise ValueError("The selected end node is not valid for that relationship type.")
    relationship_name = edge_definition["label"] if edge_definition else relationship_type.strip()
    relationship = quote_identifier(relationship_name)
    params = {
        "start_node_id": start_id,
        "end_node_id": end_id,
        "props": props,
    }
    query = f"""
    MATCH (a), (b)
    WHERE elementId(a) = $start_node_id AND elementId(b) = $end_node_id
    CREATE (a)-[r:{relationship} $props]->(b)
    RETURN elementId(r) AS id,
           type(r) AS type,
           elementId(a) AS start_id,
           elementId(b) AS end_id,
           properties(r) AS props
    """
    with get_session(app_state) as session:
        result = session.run(query, **params).single()
    if result is None:
        raise ValueError("Start or end node was not found.")
    return make_json_safe(dict(result))


def build_guided_properties(form_data: Any, selected_labels: list[str]) -> dict[str, Any]:
    properties: dict[str, Any] = {}
    applicable_fields = collect_field_definitions(selected_labels)
    for field_key, field_definition in applicable_fields.items():
        field_type = field_definition["type"]
        if field_type == "integer_range":
            raw_min = str(form_data.get(f"field__{field_key}__min", "")).strip()
            raw_max = str(form_data.get(f"field__{field_key}__max", "")).strip()
            if field_definition.get("required") and not raw_min and not raw_max:
                raise ValueError(f"{field_definition['label']} is required.")
            if raw_min or raw_max:
                value: dict[str, int] = {}
                if raw_min:
                    value["min"] = int(raw_min)
                if raw_max:
                    value["max"] = int(raw_max)
                properties[field_key] = value
            continue

        raw_value = str(form_data.get(f"field__{field_key}", "")).strip()
        if not raw_value:
            if field_definition.get("required"):
                raise ValueError(f"{field_definition['label']} is required.")
            continue

        if field_type == "integer":
            properties[field_key] = int(raw_value)
        elif field_type == "tag_select":
            parsed = parse_selector_value(raw_value, field_definition.get("mode", "multiple"))
            if field_definition.get("required") and ((isinstance(parsed, list) and not parsed) or parsed == ""):
                raise ValueError(f"{field_definition['label']} is required.")
            properties[field_key] = parsed
        else:
            properties[field_key] = raw_value
    return properties


def quote_identifier(value: str) -> str:
    cleaned = value.strip()
    if not cleaned:
        raise ValueError("Identifier cannot be empty.")
    return f"`{cleaned.replace('`', '``')}`"


def build_auth() -> Any:
    if NEO4J_USER:
        return (NEO4J_USER, NEO4J_PASSWORD)
    return None


def get_session(app_state: Any) -> Any:
    return app_state.driver.session(database=NEO4J_DATABASE)


def visible_node_where(alias: str) -> str:
    return (
        f"none(label IN labels({alias}) "
        f"WHERE label = '{LEGACY_APP_LABEL}' OR label STARTS WITH 'faikdev')"
    )


def sanitize_graph_state(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("Payload must be a JSON object.")

    raw_positions = payload.get("positions", {})
    if not isinstance(raw_positions, dict):
        raise ValueError("positions must be an object keyed by node id.")

    positions: dict[str, dict[str, float]] = {}
    for node_id, position in raw_positions.items():
        if not isinstance(node_id, str) or not node_id.strip():
            raise ValueError("Position keys must be non-empty strings.")
        if not isinstance(position, dict):
            raise ValueError(f"Position for node {node_id} must be an object.")
        x = position.get("x")
        y = position.get("y")
        if not isinstance(x, (int, float)) or not isinstance(y, (int, float)):
            raise ValueError(f"Position for node {node_id} must include numeric x and y values.")
        positions[node_id] = {"x": float(x), "y": float(y)}

    zoom = payload.get("zoom")
    if zoom is not None and not isinstance(zoom, (int, float)):
        raise ValueError("zoom must be numeric.")

    pan = payload.get("pan")
    if pan is not None:
        if not isinstance(pan, dict):
            raise ValueError("pan must be an object.")
        pan_x = pan.get("x")
        pan_y = pan.get("y")
        if not isinstance(pan_x, (int, float)) or not isinstance(pan_y, (int, float)):
            raise ValueError("pan must include numeric x and y values.")
        pan_value: dict[str, float] | None = {"x": float(pan_x), "y": float(pan_y)}
    else:
        pan_value = None

    signature = payload.get("signature")
    if signature is not None and not isinstance(signature, str):
        raise ValueError("signature must be a string.")

    return {
        "signature": signature or "",
        "positions": positions,
        "zoom": float(zoom) if isinstance(zoom, (int, float)) else None,
        "pan": pan_value,
    }


def load_graph_state(app_state: Any) -> dict[str, Any] | None:
    with get_session(app_state) as session:
        record = session.run(
            """
            MATCH (state)
            WHERE elementId(state) IS NOT NULL
              AND state.key = $key
              AND any(label IN labels(state) WHERE label IN [$internal_label, $legacy_label])
            RETURN state.graph_state_json AS graph_state_json,
                   state.updated_at AS updated_at
            """,
            key=GRAPH_STATE_KEY,
            internal_label=INTERNAL_APP_LABEL,
            legacy_label=LEGACY_APP_LABEL,
        ).single()

    if record is None or not record["graph_state_json"]:
        return None

    graph_state = json.loads(record["graph_state_json"])
    sanitized = sanitize_graph_state(graph_state)
    sanitized["updated_at"] = record["updated_at"]
    return sanitized


def save_graph_state(app_state: Any, payload: Any) -> dict[str, Any]:
    graph_state = sanitize_graph_state(payload)
    updated_at = datetime.utcnow().isoformat(timespec="seconds") + "Z"
    with get_session(app_state) as session:
        session.run(
            """
            MATCH (legacy)
            WHERE legacy.key = $key AND $legacy_label IN labels(legacy)
            REMOVE legacy:`AppGraphState`
            SET legacy:`faikdev/AppGraphState`
            """,
            key=GRAPH_STATE_KEY,
            legacy_label=LEGACY_APP_LABEL,
        ).consume()
        record = session.run(
            """
            MERGE (state:`faikdev/AppGraphState` {key: $key})
            SET state.graph_state_json = $graph_state_json,
                state.updated_at = $updated_at
            RETURN state.graph_state_json AS graph_state_json,
                   state.updated_at AS updated_at
            """,
            key=GRAPH_STATE_KEY,
            graph_state_json=json.dumps(graph_state, separators=(",", ":")),
            updated_at=updated_at,
        ).single()

    saved_state = sanitize_graph_state(json.loads(record["graph_state_json"]))
    saved_state["updated_at"] = record["updated_at"]
    return saved_state


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.driver = GraphDatabase.driver(NEO4J_URI, auth=build_auth())
    yield
    app.state.driver.close()


app = FastAPI(lifespan=lifespan)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


def load_graph_data(app_state: Any) -> dict[str, Any]:
    with get_session(app_state) as session:
        nodes = make_json_safe(session.run(
            """
            MATCH (n)
            WHERE """
            + visible_node_where("n")
            + """
            RETURN elementId(n) AS id, labels(n) AS labels, properties(n) AS props
            ORDER BY id DESC
            LIMIT 25
            """
        ).data())
        relationships = make_json_safe(session.run(
            """
            MATCH (a)-[r]->(b)
            WHERE """
            + visible_node_where("a")
            + """
              AND """
            + visible_node_where("b")
            + """
            RETURN elementId(r) AS id,
                   type(r) AS type,
                   elementId(a) AS start_id,
                   elementId(b) AS end_id,
                   labels(a) AS start_labels,
                   labels(b) AS end_labels,
                   properties(r) AS props
            ORDER BY id DESC
            LIMIT 25
            """
        ).data())
        graph_nodes = make_json_safe(session.run(
            """
            MATCH (n)
            WHERE """
            + visible_node_where("n")
            + """
            RETURN elementId(n) AS id, labels(n) AS labels, properties(n) AS props
            LIMIT 100
            """
        ).data())
        graph_relationships = make_json_safe(session.run(
            """
            MATCH (a)-[r]->(b)
            WHERE """
            + visible_node_where("a")
            + """
              AND """
            + visible_node_where("b")
            + """
            RETURN elementId(r) AS id,
                   type(r) AS type,
                   elementId(a) AS source,
                   elementId(b) AS target,
                   properties(r) AS props
            LIMIT 200
            """
        ).data())
    return {
        "nodes": nodes,
        "relationships": relationships,
        "graph_nodes": graph_nodes,
        "graph_relationships": graph_relationships,
    }


def load_full_graph_data(app_state: Any) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    with get_session(app_state) as session:
        graph_nodes = make_json_safe(session.run(
            """
            MATCH (n)
            WHERE """
            + visible_node_where("n")
            + """
            RETURN elementId(n) AS id, labels(n) AS labels, properties(n) AS props
            """
        ).data())
        graph_relationships = make_json_safe(session.run(
            """
            MATCH (a)-[r]->(b)
            WHERE """
            + visible_node_where("a")
            + """
              AND """
            + visible_node_where("b")
            + """
            RETURN elementId(r) AS id,
                   type(r) AS type,
                   elementId(a) AS source,
                   elementId(b) AS target,
                   properties(r) AS props
            """
        ).data())
    return graph_nodes, graph_relationships


def build_collapsed_path_label(hidden_labels: list[str], hidden_node_count: int, hidden_relationship_count: int) -> str:
    if hidden_labels:
        if len(hidden_labels) == 1:
            label = hidden_labels[0]
            if hidden_node_count > 1:
                return f"via {label} x{hidden_node_count}"
            return f"via {label}"
        lead = ", ".join(hidden_labels[:2])
        if len(hidden_labels) > 2:
            lead = f"{lead}, +{len(hidden_labels) - 2}"
        return f"via {lead}"
    if hidden_relationship_count > 0:
        return f"{hidden_relationship_count} hidden hop{'s' if hidden_relationship_count != 1 else ''}"
    return "Collapsed path"


def build_projected_graph(
    app_state: Any,
    selected_label_keys: list[str],
    selected_edge_keys: list[str],
    max_depth: int = 6,
) -> dict[str, Any]:
    graph_nodes, graph_relationships = load_full_graph_data(app_state)
    visible_labels = set(display_labels_for_label_keys(selected_label_keys))
    visible_relationship_types = set(resolve_edge_type_names(selected_edge_keys))
    nodes_by_id = {str(node["id"]): node for node in graph_nodes}
    relationships_by_id = {str(relationship["id"]): relationship for relationship in graph_relationships}

    direct_visible_edges = [
        relationship for relationship in graph_relationships
        if relationship["type"] in visible_relationship_types
    ]
    visible_node_ids = {
        str(node["id"])
        for node in graph_nodes
        if (
            (visible_labels and any(str(label) in visible_labels for label in node.get("labels", [])))
            or (
                not visible_labels
                and visible_relationship_types
                and any(
                    str(node["id"]) in {str(relationship["source"]), str(relationship["target"])}
                    for relationship in direct_visible_edges
                )
            )
        )
    }
    visible_nodes = [node for node in graph_nodes if str(node["id"]) in visible_node_ids]

    adjacency: dict[str, list[tuple[str, str]]] = {node_id: [] for node_id in nodes_by_id}
    for relationship in graph_relationships:
        source_id = str(relationship["source"])
        target_id = str(relationship["target"])
        relationship_id = str(relationship["id"])
        adjacency.setdefault(source_id, []).append((target_id, relationship_id))
        adjacency.setdefault(target_id, []).append((source_id, relationship_id))

    projected_relationships: list[dict[str, Any]] = []
    synthetic_keys: set[tuple[str, str]] = set()

    direct_visible_pairs: set[tuple[str, str]] = set()
    for relationship in graph_relationships:
        source_id = str(relationship["source"])
        target_id = str(relationship["target"])
        if source_id not in visible_node_ids or target_id not in visible_node_ids:
            continue
        if relationship["type"] not in visible_relationship_types:
            continue
        direct_visible_pairs.add(tuple(sorted((source_id, target_id))))
        projected_relationships.append({
            "id": relationship["id"],
            "source": source_id,
            "target": target_id,
            "type": relationship["type"],
            "label": relationship["type"],
            "props": relationship.get("props", {}),
            "metadata": {
                "id": relationship["id"],
                "type": relationship["type"],
                "source": source_id,
                "target": target_id,
                "synthetic": False,
            },
        })

    for start_id in sorted(visible_node_ids):
        queue: deque[tuple[str, list[str], list[str]]] = deque([(start_id, [start_id], [])])
        visited_depth: dict[str, int] = {start_id: 0}
        while queue:
            current_id, path_node_ids, path_relationship_ids = queue.popleft()
            current_depth = len(path_relationship_ids)
            if current_depth >= max_depth:
                continue
            for neighbor_id, relationship_id in adjacency.get(current_id, []):
                next_depth = current_depth + 1
                if next_depth > max_depth:
                    continue
                if neighbor_id in path_node_ids:
                    continue
                relationship = relationships_by_id[relationship_id]
                next_path_node_ids = [*path_node_ids, neighbor_id]
                next_path_relationship_ids = [*path_relationship_ids, relationship_id]
                if neighbor_id in visible_node_ids and neighbor_id != start_id:
                    synthetic_key = tuple(sorted((start_id, neighbor_id)))
                    if synthetic_key in synthetic_keys or synthetic_key in direct_visible_pairs:
                        continue
                    hidden_node_ids = next_path_node_ids[1:-1]
                    hidden_nodes = [nodes_by_id[node_id] for node_id in hidden_node_ids if node_id in nodes_by_id]
                    hidden_labels = []
                    for node in hidden_nodes:
                        for label in node.get("labels", []):
                            cleaned = str(label)
                            if cleaned not in hidden_labels:
                                hidden_labels.append(cleaned)
                    hidden_relationship_types = []
                    selected_direct_edge = (
                        len(next_path_relationship_ids) == 1
                        and relationship["type"] in visible_relationship_types
                    )
                    for path_relationship_id in next_path_relationship_ids:
                        path_relationship = relationships_by_id[path_relationship_id]
                        relationship_type = str(path_relationship["type"])
                        if relationship_type not in visible_relationship_types and relationship_type not in hidden_relationship_types:
                            hidden_relationship_types.append(relationship_type)
                    hidden_relationship_count = len(next_path_relationship_ids) - (
                        1 if selected_direct_edge else 0
                    )
                    if not hidden_node_ids and hidden_relationship_count <= 0:
                        continue
                    projected_relationships.append({
                        "id": f"projection:{start_id}:{neighbor_id}",
                        "source": start_id,
                        "target": neighbor_id,
                        "type": "COLLAPSED_PATH",
                        "label": build_collapsed_path_label(
                            hidden_labels,
                            len(hidden_node_ids),
                            hidden_relationship_count,
                        ),
                        "props": {
                            "hidden_node_count": len(hidden_node_ids),
                            "hidden_relationship_count": hidden_relationship_count,
                        },
                        "metadata": {
                            "id": f"projection:{start_id}:{neighbor_id}",
                            "type": "COLLAPSED_PATH",
                            "source": start_id,
                            "target": neighbor_id,
                            "synthetic": True,
                            "path_node_ids": next_path_node_ids,
                            "path_relationship_ids": next_path_relationship_ids,
                            "hidden_node_ids": hidden_node_ids,
                            "hidden_labels": hidden_labels,
                            "hidden_relationship_types": hidden_relationship_types,
                            "hidden_node_count": len(hidden_node_ids),
                            "hidden_relationship_count": hidden_relationship_count,
                        },
                    })
                    synthetic_keys.add(synthetic_key)
                    continue
                best_depth = visited_depth.get(neighbor_id)
                if best_depth is not None and best_depth <= next_depth:
                    continue
                visited_depth[neighbor_id] = next_depth
                queue.append((neighbor_id, next_path_node_ids, next_path_relationship_ids))

    return {
        "nodes": visible_nodes,
        "relationships": projected_relationships,
        "meta": {
            "selected_label_keys": selected_label_keys,
            "selected_edge_keys": selected_edge_keys,
            "selected_labels": list(visible_labels),
            "selected_relationship_types": list(visible_relationship_types),
            "max_depth": max_depth,
            "visible_node_count": len(visible_nodes),
            "relationship_count": len(projected_relationships),
        },
    }


def build_frontend_bootstrap(
    request: Request,
    message: str | None = None,
    error: str | None = None,
    toast_target_id: str | None = None,
) -> dict[str, Any]:
    context = {
        "message": message,
        "error": error,
        "toast_target_id": toast_target_id,
        "neo4j_uri": NEO4J_URI,
        "neo4j_database": NEO4J_DATABASE,
        "tag_selector_demo_options": TAG_SELECTOR_DEMO_OPTIONS,
        "node_types": make_json_safe(NODE_TYPES),
        "creation_rules": make_json_safe(CREATION_RULES),
        "node_label_options": NODE_LABEL_OPTIONS,
        "edge_type_options": build_all_edge_options(),
        "label_form_definitions": make_json_safe(LABEL_FORM_DEFINITIONS),
        "label_form_definitions_json": json.dumps(make_json_safe(LABEL_FORM_DEFINITIONS), sort_keys=False),
        "edge_type_definitions": make_json_safe(EDGE_TYPE_DEFINITIONS),
        "node_entry_rules": make_json_safe(NODE_ENTRY_RULES),
        "picker_display_definitions": make_json_safe(PICKER_DISPLAY_DEFINITIONS),
        "nodes": [],
        "relationships": [],
        "graph_nodes": [],
        "graph_relationships": [],
        "graph_state": None,
    }
    try:
        context.update(load_graph_data(request.app.state))
    except ClientError as exc:
        if error is None:
            context["error"] = exc.message
    try:
        context["graph_state"] = load_graph_state(request.app.state)
    except (ValueError, json.JSONDecodeError, ClientError) as exc:
        if error is None and not context.get("error"):
            context["error"] = str(exc)
    return make_json_safe(context)


@app.get("/api/bootstrap")
def frontend_bootstrap(
    request: Request,
    message: str | None = None,
    error: str | None = None,
    toast_target_id: str | None = None,
) -> JSONResponse:
    return JSONResponse(
        build_frontend_bootstrap(
            request,
            message=message,
            error=error,
            toast_target_id=toast_target_id,
        )
    )


@app.get("/", response_class=HTMLResponse)
def index(
    request: Request,
    message: str | None = None,
    error: str | None = None,
    toast_target_id: str | None = None,
):
    if not FRONTEND_INDEX.exists():
        return HTMLResponse(
            "<h1>Frontend build missing.</h1><p>Run <code>npm install</code> and <code>npm run build</code>.</p>",
            status_code=503,
        )
    return FileResponse(FRONTEND_INDEX)


@app.get("/api/node-picker-options")
def node_picker_options(
    request: Request,
    edge_type: str = "",
    source_node_id: str = "",
    source_labels: str = "[]",
    query: str = "",
    target_labels: str = "[]",
    picker_display: str = "generic_node",
    direction: str = "outgoing",
) -> dict[str, Any]:
    try:
        if not edge_type.strip():
            return {"options": []}
        labels = fetch_node_labels_by_id(request.app.state, source_node_id) if source_node_id.strip() else parse_labels(source_labels)
        target_label_keys = parse_labels(target_labels)
        return {
            "options": fetch_target_node_options(
                request.app.state,
                edge_type,
                labels,
                query=query,
                target_label_keys=target_label_keys or None,
                picker_display=picker_display,
                direction=direction,
            )
        }
    except (ValueError, json.JSONDecodeError):
        return {"options": []}


@app.get("/api/search-nodes")
def search_nodes(request: Request, query: str = "") -> dict[str, Any]:
    cleaned_query = query.strip().lower()
    with get_session(request.app.state) as session:
        rows = make_json_safe(session.run(
            """
            MATCH (n)
            WHERE $search_query = ""
              OR toLower(
                coalesce(n.name, "")
                + " " + coalesce(n.database_name, "")
                + " " + coalesce(n.schema_name, "")
                + " " + coalesce(n.table_name, "")
                + " " + coalesce(n.column_name, "")
                + " " + coalesce(n.bucket_name, "")
                + " " + coalesce(n.file_name, "")
                + " " + coalesce(n.job_name, "")
                + " " + coalesce(n.execution_id, "")
                + " " + coalesce(n.service_name, "")
                + " " + coalesce(n.endpoint_name, "")
                + " " + coalesce(n.hosting_name, "")
                + " " + coalesce(n.language_name, "")
                + " " + coalesce(n.repository_name, "")
                + " " + coalesce(n.pipeline_name, "")
                + " " + coalesce(n.principal_name, "")
                + " " + coalesce(n.environment_name, "")
                + " " + reduce(acc = "", label IN labels(n) | acc + " " + label)
                + " " + elementId(n)
              ) CONTAINS $search_query
            RETURN elementId(n) AS id, labels(n) AS labels, properties(n) AS props
            ORDER BY coalesce(properties(n).name, properties(n).table_name, properties(n).service_name, properties(n).job_name, elementId(n))
            LIMIT 20
            """,
            search_query=cleaned_query,
        ).data())
    
    options = []
    for row in rows:
        props = row.get("props", {})
        display = build_node_display(props, row["id"])
        options.append({"key": row["id"], "display": display})
    
    return {"options": options}


@app.get("/api/node-summary")
def node_summary(request: Request, node_id: str) -> dict[str, Any]:
    cleaned = node_id.strip()
    if not cleaned:
        return {"found": False}
    with get_session(request.app.state) as session:
        record = session.run(
            """
            MATCH (n)
            WHERE elementId(n) = $node_id
            RETURN elementId(n) AS id, labels(n) AS labels, properties(n) AS props
            """,
            node_id=cleaned,
        ).single()
    if record is None:
        return {"found": False}
    row = make_json_safe(dict(record))
    return {"found": True, "node": build_node_summary(row)}


@app.get("/api/graph-state")
def get_graph_state(request: Request) -> JSONResponse:
    try:
        graph_state = load_graph_state(request.app.state)
        if graph_state is None:
            return JSONResponse({"found": False})
        return JSONResponse({"found": True, "state": make_json_safe(graph_state)})
    except (ValueError, json.JSONDecodeError, ClientError) as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)


@app.get("/api/graph-projection")
def get_graph_projection(
    request: Request,
    labels: str = "",
    edge_types: str = "",
    max_depth: int = 6,
) -> JSONResponse:
    try:
        projection = build_projected_graph(
            request.app.state,
            parse_labels(labels),
            parse_labels(edge_types),
            max_depth=max(1, min(max_depth, 12)),
        )
        return JSONResponse(make_json_safe(projection))
    except (ValueError, json.JSONDecodeError, ClientError) as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)


@app.post("/api/graph-state")
async def save_graph_state_api(request: Request) -> JSONResponse:
    try:
        payload = await request.json()
        graph_state = save_graph_state(request.app.state, payload)
        return JSONResponse({
            "message": "Saved graph state to server.",
            "state": make_json_safe(graph_state),
        })
    except (ValueError, json.JSONDecodeError, ClientError) as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)


@app.post("/nodes")
async def create_node(request: Request):
    try:
        form_data = await request.form()
        created = create_node_record(request.app.state, form_data)
        message = f"Created node {created['id']}."
        return RedirectResponse(
            url=f"/?message={message}&toast_target_id={created['id']}",
            status_code=303,
        )
    except (ValueError, json.JSONDecodeError, ClientError) as exc:
        return RedirectResponse(url=f"/?error={str(exc)}", status_code=303)


@app.post("/relationships")
def create_relationship(
    request: Request,
    start_node_id: str = Form(...),
    relationship_type: str = Form(...),
    end_node_id: str = Form(...),
    properties: str = Form(""),
):
    try:
        created = create_relationship_record(
            request.app.state,
            start_node_id=start_node_id,
            relationship_type=relationship_type,
            end_node_id=end_node_id,
            properties=properties,
        )
        message = f"Created relationship {created['id']}."
        return RedirectResponse(url=f"/?message={message}", status_code=303)
    except (ValueError, json.JSONDecodeError, ClientError) as exc:
        return RedirectResponse(url=f"/?error={str(exc)}", status_code=303)


@app.post("/api/nodes")
async def create_node_api(request: Request):
    try:
        payload = await request.json()
        if not isinstance(payload, dict):
            raise ValueError("Payload must be a JSON object.")
        created = create_node_record(request.app.state, payload)
        return JSONResponse({
            "message": f"Created node {created['id']}.",
            "node": created,
        })
    except (ValueError, json.JSONDecodeError, ClientError) as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)


@app.post("/api/relationships")
async def create_relationship_api(request: Request):
    try:
        payload = await request.json()
        if not isinstance(payload, dict):
            raise ValueError("Payload must be a JSON object.")
        created = create_relationship_record(
            request.app.state,
            start_node_id=str(payload.get("start_node_id", "")),
            relationship_type=str(payload.get("relationship_type", "")),
            end_node_id=str(payload.get("end_node_id", "")),
            properties=str(payload.get("properties", "")),
        )
        return JSONResponse({
            "message": f"Created relationship {created['id']}.",
            "relationship": created,
        })
    except (ValueError, json.JSONDecodeError, ClientError) as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)


@app.post("/api/nodes/{node_id}")
async def update_node(request: Request, node_id: str):
    try:
        payload = await request.json()
        props = payload.get("properties", {})
        if not isinstance(props, dict):
            raise ValueError("Properties must be a JSON object.")
        with get_session(request.app.state) as session:
            result = session.run(
                """
                MATCH (n)
                WHERE elementId(n) = $node_id
                SET n = $props
                RETURN elementId(n) AS id, labels(n) AS labels, properties(n) AS props
                """,
                node_id=node_id,
                props=props,
            ).single()
        if result is None:
            raise ValueError("Node was not found.")
        return JSONResponse(make_json_safe({
            "id": result["id"],
            "labels": result["labels"],
            "props": result["props"],
        }))
    except (ValueError, json.JSONDecodeError, ClientError) as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)


@app.post("/api/relationships/{relationship_id}")
async def update_relationship(request: Request, relationship_id: str):
    try:
        payload = await request.json()
        props = payload.get("properties", {})
        if not isinstance(props, dict):
            raise ValueError("Properties must be a JSON object.")
        with get_session(request.app.state) as session:
            result = session.run(
                """
                MATCH ()-[r]->()
                WHERE elementId(r) = $relationship_id
                SET r = $props
                RETURN elementId(r) AS id,
                       type(r) AS type,
                       elementId(startNode(r)) AS source,
                       elementId(endNode(r)) AS target,
                       properties(r) AS props
                """,
                relationship_id=relationship_id,
                props=props,
            ).single()
        if result is None:
            raise ValueError("Relationship was not found.")
        return JSONResponse(make_json_safe({
            "id": result["id"],
            "type": result["type"],
            "source": result["source"],
            "target": result["target"],
            "props": result["props"],
        }))
    except (ValueError, json.JSONDecodeError, ClientError) as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)


@app.delete("/api/nodes/{node_id}")
async def delete_node(request: Request, node_id: str):
    try:
        with get_session(request.app.state) as session:
            result = session.run(
                """
                MATCH (n)
                WHERE elementId(n) = $node_id
                WITH n, size([(n)-[r]-() | r]) AS relationship_count
                DETACH DELETE n
                RETURN $node_id AS id, relationship_count
                """,
                node_id=node_id,
            ).single()
        if result is None:
            return JSONResponse({"error": "Node was not found."}, status_code=404)
        return JSONResponse(make_json_safe({
            "id": result["id"],
            "deleted_relationship_count": result["relationship_count"],
        }))
    except ClientError as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)


@app.delete("/api/relationships/{relationship_id}")
async def delete_relationship(request: Request, relationship_id: str):
    try:
        with get_session(request.app.state) as session:
            result = session.run(
                """
                MATCH ()-[r]->()
                WHERE elementId(r) = $relationship_id
                DELETE r
                RETURN $relationship_id AS id
                """,
                relationship_id=relationship_id,
            ).single()
        if result is None:
            return JSONResponse({"error": "Relationship was not found."}, status_code=404)
        return JSONResponse({"id": result["id"]})
    except ClientError as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)


@app.get("/api/config")
def get_config_files():
    try:
        configs = {}
        for file in CONFIG_DIR.glob("*.json"):
            with open(file) as f:
                configs[file.name] = f.read()
        return JSONResponse({"configs": configs})
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


@app.post("/api/config/save")
async def save_config_file(request: Request):
    try:
        payload = await request.json()
        filename = payload.get("filename", "").strip()
        content = payload.get("content", "").strip()
        commit_message = payload.get("commit_message", "").strip()
        
        if not filename or not filename.endswith(".json"):
            raise ValueError("Invalid filename")
        if not content:
            raise ValueError("Content cannot be empty")
        if not commit_message:
            raise ValueError("Commit message is required")
        
        # Validate JSON
        parsed = json.loads(content)
        
        # Write file
        file_path = CONFIG_DIR / filename
        with open(file_path, "w") as f:
            json.dump(parsed, f, indent=2)
        
        # Git commit
        subprocess.run(["git", "add", str(file_path)], check=True, cwd=BASE_DIR)
        subprocess.run(
            ["git", "commit", "-m", f"Update {filename}: {commit_message}"],
            check=True,
            cwd=BASE_DIR,
            capture_output=True,
        )

        # Keep runtime config in sync without requiring app restart.
        reload_runtime_config()
        
        return JSONResponse({
            "message": f"Saved and committed {filename}",
            "filename": filename,
        })
    except json.JSONDecodeError as exc:
        return JSONResponse({"error": f"Invalid JSON: {str(exc)}"}, status_code=400)
    except subprocess.CalledProcessError as exc:
        return JSONResponse({"error": f"Git error: {exc.stderr.decode()}"}, status_code=500)
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)
