import argparse
import os

import uvicorn


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the faik-inventory FastAPI server")
    parser.add_argument("--host", default=os.getenv("FAIK_INVENTORY_HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.getenv("FAIK_INVENTORY_PORT", "8000")))
    parser.add_argument("--reload", action="store_true", default=False)
    args = parser.parse_args()

    uvicorn.run("app:app", host=args.host, port=args.port, reload=args.reload)


if __name__ == "__main__":
    main()
