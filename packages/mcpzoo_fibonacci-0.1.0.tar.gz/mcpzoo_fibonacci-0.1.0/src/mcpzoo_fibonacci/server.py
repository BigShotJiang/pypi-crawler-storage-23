from mcp.server.fastmcp import FastMCP

mcp = FastMCP("fibonacci")

@mcp.tool()
def gen_fibonacci(count: int = 10, start_index: int = 1) -> str:
    """生成斐波那契数列。

    Args:
        count: 生成的数量（最多 1000）
        start_index: 起始索引（1 为第一个）
    """
    if count < 1 or count > 1000:
        return "生成数量请保持在 1-1000 之间"
        
    if start_index < 1:
        start_index = 1
        
    a, b = 0, 1
    # 推进到起点
    for _ in range(start_index - 1):
        a, b = b, a + b
        
    result = []
    for _ in range(count):
        result.append(str(b))
        a, b = b, a + b
        
    return "\n".join(result)

def main():
    mcp.run()

if __name__ == "__main__":
    main()
