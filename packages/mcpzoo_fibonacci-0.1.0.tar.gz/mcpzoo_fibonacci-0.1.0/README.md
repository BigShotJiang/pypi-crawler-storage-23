# mcpzoo-fibonacci

> 斐波那契 — 生成斐波那契数列

## Installation

```bash
uvx mcpzoo-fibonacci
```

## uvx JSON

```json
{
  "mcpServers": {
    "fibonacci": {
      "args": ["mcpzoo-fibonacci"],
      "command": "uvx"
    }
  }
}
```
