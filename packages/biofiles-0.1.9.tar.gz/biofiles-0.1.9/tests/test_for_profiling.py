from biofiles.dialects.gencode import GENCODE_DIALECT
from biofiles.gff import GFFReader


def test_profiling() -> None:
    path = "/Users/saluev/bioinf/genomes/hg38/hg38_genomic.gff3"
    reader = GFFReader(path, GENCODE_DIALECT)
    for _ in reader:
        pass
