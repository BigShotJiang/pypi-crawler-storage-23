from __future__ import annotations

import importlib
import json
import types as _types
from typing import Any, Literal, Type, Union, get_args, get_origin

from port_ocean.core.handlers.port_app_config.models import (
    CUSTOM_KIND,
    PortAppConfig,
    ResourceConfig,
    Selector,
)
from port_ocean.utils.misc import get_subclass_class_from_module


def validate_and_get_config_schema(
    config_class: Type[PortAppConfig],
) -> dict[str, Any]:
    """Validate config definitions and return UI schema (kinds + advancedConfig)."""
    models = _get_resource_config_models(config_class)
    _validate_kind_discriminator(config_class)
    kinds = _build_kinds_mapping(models, config_class.allow_custom_kinds)
    advanced_config = _get_advanced_config(config_class)
    return {"kinds": kinds, "advancedConfig": advanced_config}


def _validate_kind_discriminator(config_class: Type[PortAppConfig]) -> None:
    """Validate that ``kind`` is a unique discriminator across the resources union.

    Intended to be called at **class-definition time** (via
    ``PortAppConfig.__init_subclass__``) so that invalid definitions are
    caught at import time rather than at runtime.

    Raises :class:`TypeError` on:
    * duplicate ``Literal`` kind values across union members
    * more than one union member with ``kind: str`` (custom-kind slot)
    """
    models = _get_resource_config_models(config_class)

    seen_literal_kinds: dict[str, str] = {}  # kind_value → model_name
    custom_kind_model: str | None = None

    for model in models:
        if not (isinstance(model, type) and issubclass(model, ResourceConfig)):
            continue

        kind_field = model.__fields__.get("kind")
        if kind_field is None:
            raise TypeError(f"{model.__name__} is missing the required 'kind' field")

        try:
            kind_value = _resolve_kind_value(
                kind_field, model.__name__, allow_custom_kinds=True
            )
        except ValueError as e:
            raise TypeError(str(e)) from e

        if kind_value == CUSTOM_KIND:
            if custom_kind_model is not None:
                raise TypeError(
                    f"Multiple custom kind definitions detected: both "
                    f"{custom_kind_model} and {model.__name__} define "
                    f"'kind: str'. Only one ResourceConfig with "
                    f"'kind: str' is allowed"
                )
            custom_kind_model = model.__name__
        else:
            if kind_value in seen_literal_kinds:
                raise TypeError(
                    f"Duplicate kind '{kind_value}': both "
                    f"{seen_literal_kinds[kind_value]} and {model.__name__} "
                    f"define the same kind value. "
                    f"'kind' must be a unique discriminator across the "
                    f"resources union"
                )
            seen_literal_kinds[kind_value] = model.__name__


def _get_resource_config_models(
    config_class: Type[PortAppConfig],
) -> list[type]:
    """Return the individual ``ResourceConfig`` model types from the
    ``resources`` field annotation.

    Handles both ``list[SingleModel]`` and ``list[Union[A | B | …]]``.
    """
    resources_field = config_class.__fields__.get("resources")
    if resources_field is None:
        return []

    annotation = resources_field.outer_type_
    list_args = get_args(annotation)
    if not list_args:
        return []

    inner = list_args[0]
    return _unwrap_union(inner)


def _unwrap_union(annotation: Any) -> list[type]:
    """Unwrap a ``Union`` (or Python 3.10+ ``X | Y``) into member types."""
    origin = get_origin(annotation)
    if origin is Union:
        return list[type](get_args(annotation))
    if hasattr(_types, "UnionType") and isinstance(annotation, _types.UnionType):
        return list[type](get_args(annotation))
    return [annotation]


def _get_advanced_config(config_class: Type[PortAppConfig]) -> dict[str, Any]:
    """Return metadata for root PortAppConfig fields (except 'resources') from JSON schema."""
    schema = config_class.schema()
    return {k: v for k, v in schema.get("properties", {}).items() if k != "resources"}


def _get_selector_schema(selector_type: Any, model: type) -> dict[str, Any]:
    """Return JSON schema for the selector type, or resolve from model's module, or base Selector."""
    if isinstance(selector_type, type) and hasattr(selector_type, "schema"):
        return selector_type.schema()
    selector_class = get_subclass_class_from_module(
        importlib.import_module(model.__module__), Selector
    )
    if selector_class is not None:
        return selector_class.schema()
    return Selector.schema()


def _build_kinds_mapping(
    models: list[type],
    allow_custom_kinds: bool,
) -> dict[str, dict[str, Any]]:
    """Walk *models*, validate each one's ``kind`` and build the mapping."""
    kinds: dict[str, dict[str, Any]] = {}

    for model in models:
        if not (isinstance(model, type) and issubclass(model, ResourceConfig)):
            continue

        kind_field = model.__fields__.get("kind")
        if kind_field is None:
            raise ValueError(f"{model.__name__} is missing the required 'kind' field")

        kind_value = _resolve_kind_value(kind_field, model.__name__, allow_custom_kinds)
        if kind_value is None:
            raise ValueError(f"{model.__name__}: could not resolve kind value")
        if kind_value != CUSTOM_KIND and kind_value in kinds:
            raise ValueError(
                f"Duplicate kind '{kind_value}' found in resource config models"
            )

        kind_entry = _field_info_to_dict(kind_field.field_info)

        selector_field = model.__fields__.get("selector")
        if selector_field is not None:
            kind_entry["selectors"] = _get_selector_schema(
                selector_field.outer_type_, model
            )

        kinds[kind_value] = kind_entry

    return kinds


def _field_info_to_dict(field_info: Any) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for attr_name, attr_value in field_info.__repr_args__():
        if attr_name is None:
            continue
        # The "extra" slot is Pydantic's catch-all for unknown kwargs passed
        # to Field().  Flatten its contents into the result instead of nesting
        # them under a redundant "extra" key.
        if attr_name == "extra" and isinstance(attr_value, dict):
            for k, v in attr_value.items():
                if _is_json_safe(json, v):
                    result[k] = v
        elif _is_json_safe(json, attr_value):
            result[attr_name] = attr_value
    return result


def _is_json_safe(json_mod: Any, value: Any) -> bool:
    """Return ``True`` if *value* survives ``json.dumps`` without error."""
    try:
        json_mod.dumps(value)
        return True
    except (TypeError, ValueError, OverflowError):
        return False


def _resolve_kind_value(
    kind_field: Any,
    model_name: str,
    allow_custom_kinds: bool,
) -> str:
    """Return the normalised kind string for a single model.

    * ``Literal["x"]`` → ``"x"``
    * ``str`` (when allowed) → ``"__custom__"``
    * ``str`` (when not allowed) → raises ``ValueError``
    * anything else → raises ``ValueError``
    """
    kind_type = kind_field.outer_type_
    kind_origin = get_origin(kind_type)

    if kind_origin is Literal:
        values = get_args(kind_type)
        if len(values) != 1:
            raise ValueError(
                f"{model_name}: kind Literal must contain exactly one string value, "
                f"got {len(values)}: {values}"
            )
        return str(values[0])

    if kind_type is str:
        if not allow_custom_kinds:
            raise ValueError(
                f"{model_name}: custom kinds are not allowed when allow_custom_kinds is False"
            )
        return CUSTOM_KIND

    raise ValueError(
        f"{model_name}: kind must be Literal['value'] or str "
        f"(when allow_custom_kinds=True), got {kind_type}"
    )
