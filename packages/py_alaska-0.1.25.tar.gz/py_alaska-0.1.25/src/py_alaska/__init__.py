# Copyright (c) 2026 동일비전(Dongil Vision Korea). All Rights Reserved.
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  ALASKA v2.0 - py_alaska                                                     ║
║  Multiprocess Task Management Framework                                      ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Version : 2.3.0                                                             ║
║  Date    : 2026-02-27                                                        ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from .core import (
    # Task Decorators & Validation
    rmi_run, rmi_signal, has_run_flag, get_signal_handlers,
    get_rmi_signal_forward, TaskValidator, task, rmi_task,
    _DEFAULT_RESTART_DELAY,
    # Task Manager
    TaskManager, TaskInfo, TaskRuntime, RmiClient, DirectClient,
    # Log
    LogRecord, RmiLogger, LogTask,
    # Signal
    Signal, SignalBroker, SignalClient, PayloadTooLargeError, QoS, PriorityScheduler,
    # Performance
    MethodPerformance, TaskPerformance, SystemPerformance,
    TimingRecorder, PerformanceCollector,
    # Banner
    banner,
    # Profiler
    task_profiler, TaskProfiler, LapRecord,
    # Log Handler
    SafeRotatingFileHandler, QueueFileHandler, QueueFileListener,
    create_safe_file_handler, setup_safe_logging,
    # Config
    gconfig, GConfig,
    ConfigError, ConfigFileNotFoundError, ConfigPathNotFoundError,
    ConfigLockTimeoutError, ConfigValidationError, ConfigParseError,
    ConfigIntegrityError, ConfigSecurityError, ConfigStaleLockError,
    ConfigMandatoryFieldError, ConfigRecoveryError,
    # Errors
    AlaskaError, TaskNotFoundError, SmBlockNotFoundError,
    RmiTimeoutError, TaskRemovedError, InjectionError,
    task_not_found_error, smblock_not_found_error, rmi_timeout_error,
    pickle_error, config_mandatory_field_error,
)

from .sm_infra import (
    SmBlock, SmBlockBuffer, SmBlockHandler, SmValue, SmRingBuffer, SmQueue,
    SmSignalStats, SmSignalRegistry, SmBlackBox, SmLockFreeEvent, SmKernelEvent,
)

# Qt Integration (optional — requires PySide6)
try:
    from .qt import AlaskaApp, ui_thread
except ImportError:
    pass
from .monitor import (
    TaskMonitor,
    HwInfoCollector,
    ExternalLinkManager,
    SlackSender,
    EmailSender,
    WebhookSender,
    HealthReporter,
    ReportScheduler,
)

__version__ = "2.3.0"
__all__ = [
    # Task Decorators & Validation
    "rmi_run", "rmi_signal", "task", "rmi_task", "has_run_flag",
    "get_signal_handlers", "get_rmi_signal_forward", "TaskValidator",
    "_DEFAULT_RESTART_DELAY",
    # Task Manager
    "TaskManager", "TaskInfo", "TaskRuntime", "RmiClient", "DirectClient",
    "TaskMonitor",
    # Log
    "LogRecord", "RmiLogger", "LogTask",
    # Signal
    "Signal", "SignalBroker", "SignalClient", "PayloadTooLargeError", "QoS", "PriorityScheduler",
    # SmBlock & Shared Memory
    "SmBlock", "SmBlockBuffer", "SmBlockHandler", "SmValue", "SmRingBuffer", "SmQueue",
    "SmSignalStats", "SmSignalRegistry", "SmBlackBox", "SmLockFreeEvent", "SmKernelEvent",
    # SysInfo
    "HwInfoCollector",
    # External Link
    "ExternalLinkManager", "SlackSender", "EmailSender",
    "WebhookSender", "HealthReporter", "ReportScheduler",
    # Performance
    "MethodPerformance", "TaskPerformance", "SystemPerformance",
    "TimingRecorder", "PerformanceCollector",
    # Banner
    "banner",
    # Profiler
    "task_profiler", "TaskProfiler", "LapRecord",
    # Safe Logging
    "SafeRotatingFileHandler", "QueueFileHandler", "QueueFileListener",
    "create_safe_file_handler", "setup_safe_logging",
    # Config
    "gconfig", "GConfig",
    "ConfigError", "ConfigFileNotFoundError", "ConfigPathNotFoundError",
    "ConfigLockTimeoutError", "ConfigValidationError", "ConfigParseError",
    "ConfigIntegrityError", "ConfigSecurityError", "ConfigStaleLockError",
    "ConfigMandatoryFieldError", "ConfigRecoveryError",
    # Errors
    "AlaskaError", "TaskNotFoundError", "SmBlockNotFoundError",
    "RmiTimeoutError", "TaskRemovedError", "InjectionError",
    "task_not_found_error", "smblock_not_found_error", "rmi_timeout_error",
    "pickle_error", "config_mandatory_field_error",
]
