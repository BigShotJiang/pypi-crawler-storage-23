"""GOES MCP tool modules."""
