"""Allow running as `python -m whisper_dic`."""

from whisper_dic.cli import main

raise SystemExit(main())
