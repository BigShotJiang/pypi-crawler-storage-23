from yt_transcribe.cli import main

main()
