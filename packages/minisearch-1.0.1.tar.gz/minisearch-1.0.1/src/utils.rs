pub mod automaton;
pub mod fileext;
pub mod hasher;
pub mod trie;
