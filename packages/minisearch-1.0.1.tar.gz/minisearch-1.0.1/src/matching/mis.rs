use crate::core::index::Posting;
use crate::matching::intersect::TokenDocPointer;
use core::cmp::{Ordering, Reverse};
use hashbrown::HashMap;
use nohash_hasher::BuildNoHashHasher;
use std::collections::BinaryHeap;
use std::slice::Iter;

struct TokenPositions<'a> {
    token: u32,
    distance: u16,
    tf: u64,
    positions: Iter<'a, u32>,
}

struct TokenMeta {
    token: u32,
    distance: u16,
    tf: u64,
}

struct TokenPosition {
    position: u32,
    idx: usize,
}

impl Ord for TokenPosition {
    fn cmp(&self, other: &Self) -> Ordering {
        self.position.cmp(&other.position)
    }
}

impl PartialOrd for TokenPosition {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.position.cmp(&other.position))
    }
}

impl PartialEq for TokenPosition {
    fn eq(&self, other: &Self) -> bool {
        self.position == other.position && self.idx == other.idx
    }
}

impl Eq for TokenPosition {}

#[derive(Debug)]
pub struct MisTokenIdx {
    pub token: u32,
    pub token_idx: u32,
    pub tf: u64,
    pub distance: u16,
}

#[derive(Debug)]
pub struct MisResult {
    pub slop: i32,
    pub indexes: Vec<MisTokenIdx>,
}

struct TokenGroupIterator<'a> {
    heap: BinaryHeap<Reverse<TokenPosition>>,
    tokens: Vec<TokenPositions<'a>>,
}

pub struct MinimalIntervalSemanticMatch<'a> {
    min_slop: i32,
    iterators: Vec<TokenGroupIterator<'a>>,
    window: Vec<u32>, // window of token indexes
    slops: Vec<i32>,
    end: bool,
}

impl<'a> TokenGroupIterator<'a> {
    fn new() -> Self {
        Self {
            heap: BinaryHeap::new(),
            tokens: vec![],
        }
    }

    fn add_token_positions(&mut self, mut positions: Iter<'a, u32>, token: u32, distance: u16) {
        match positions.next() {
            Some(val) => {
                self.heap.push(Reverse(TokenPosition {
                    position: *val,
                    idx: self.tokens.len(),
                }));
                self.tokens.push(TokenPositions {
                    token: token,
                    distance: distance,
                    tf: positions.len() as u64 + 1,
                    positions: positions,
                });
            }
            _ => (),
        }
    }

    fn closest(&mut self, target: u32) -> Option<u32> {
        while let Some(pos) = self.heap.peek()
            && pos.0.position <= target
        {
            let pos = self.heap.pop().unwrap();
            while let Some(val) = self.tokens[pos.0.idx].positions.next() {
                if *val > target {
                    self.heap.push(Reverse(TokenPosition {
                        position: *val,
                        idx: pos.0.idx,
                    }));
                    break;
                }
            }
        }

        self.peek()
    }

    fn next(&mut self) -> Option<u32> {
        if let Some(pos) = self.heap.pop() {
            if let Some(val) = self.tokens[pos.0.idx].positions.next() {
                self.heap.push(Reverse(TokenPosition {
                    position: *val,
                    idx: pos.0.idx,
                }));
            }
        }

        self.peek()
    }

    fn peek(&self) -> Option<u32> {
        if let Some(pos) = self.heap.peek() {
            return Some(pos.0.position);
        }

        return None;
    }

    fn last_meta(&self) -> Option<TokenMeta> {
        if let Some(pos) = self.heap.peek() {
            let token = &self.tokens[pos.0.idx];
            return Some(TokenMeta {
                token: token.token.clone(),
                distance: token.distance,
                tf: token.tf,
            });
        }

        return None;
    }
}

impl<'a> MinimalIntervalSemanticMatch<'a> {
    pub fn new(
        index: &'a HashMap<u32, Vec<Posting>, BuildNoHashHasher<u32>>,
        pointers: &Vec<Vec<TokenDocPointer>>,
        min_slop: i32,
    ) -> Self {
        let mut iterators: Vec<TokenGroupIterator> = Vec::with_capacity(pointers.len());
        for group in pointers {
            let mut iterator = TokenGroupIterator::new();
            for pointer in group {
                let positions = match index.get(&pointer.token) {
                    Some(postings) => postings[pointer.doc_idx as usize].positions.iter(),
                    None => continue,
                };

                iterator.add_token_positions(positions, pointer.token, pointer.distance);
            }

            iterators.push(iterator);
        }

        let mut end = false;
        let window = (0..iterators.len())
            .map(|i| match iterators[i].peek() {
                Some(pos) => pos,
                None => {
                    end = true;
                    0
                }
            })
            .collect::<Vec<u32>>();

        let slops = vec![0; iterators.len()];

        Self {
            min_slop: min_slop,
            iterators: iterators,
            window: window,
            slops: slops,
            end: end,
        }
    }
}

impl<'a> Iterator for MinimalIntervalSemanticMatch<'a> {
    type Item = MisResult;

    fn next(&mut self) -> Option<MisResult> {
        let mut idx = 1;
        while !self.end {
            while idx <= self.iterators.len() - 1 {
                let val = match self.iterators[idx].closest(self.window[idx - 1]) {
                    Some(val) => val,
                    None => return None,
                };

                self.window[idx] = val;
                let slop = self.slops[idx - 1]
                    + (self.window[idx - 1] as i32 - (self.window[idx] as i32 - 1)).abs();

                if slop > self.min_slop {
                    break;
                }

                self.slops[idx] = slop;
                idx += 1;
            }

            let mut result = None;
            if idx == self.iterators.len() {
                let mut window = Vec::with_capacity(self.window.len());
                for (iter_idx, token_idx) in self.window.iter().enumerate() {
                    let meta = match self.iterators[iter_idx].last_meta() {
                        Some(meta) => meta,
                        None => break,
                    };

                    window.push((*token_idx, meta.token, meta.tf, meta.distance));
                }

                if window.len() < self.window.len() {
                    break;
                }

                let _ = result.insert(MisResult {
                    slop: self.slops[self.iterators.len() - 1],
                    indexes: window
                        .into_iter()
                        .map(|(token_idx, token, tf, distance)| MisTokenIdx {
                            token: token,
                            token_idx: token_idx,
                            tf: tf,
                            distance: distance,
                        })
                        .collect::<Vec<MisTokenIdx>>(),
                });
            }

            match self.iterators[0].next() {
                Some(val) => {
                    idx = 1;
                    self.window[0] = val
                }
                None => self.end = true,
            };

            if result.is_some() {
                return result;
            }
        }

        None
    }
}
