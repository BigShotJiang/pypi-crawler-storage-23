from .main import MiniSearch
