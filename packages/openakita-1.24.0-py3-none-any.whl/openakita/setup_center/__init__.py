"""
Setup Center 支持模块（供 Tauri Setup Center 调用）。

注意：Setup Center 会通过 `python -m openakita.setup_center.bridge ...` 调用桥接入口。
"""

