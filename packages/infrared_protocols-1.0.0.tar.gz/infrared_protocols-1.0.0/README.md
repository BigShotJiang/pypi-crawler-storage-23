# Python Infrared Protocols for Home Assistant

Python package to decode and encode infrared signals for use in Home Assistant.
