from .main import (
    # template_matching_scaled,
    # alpha_template_match_ds,
    # f25,
    save_screenshot,
    # save_screenshot_by_mouse_rect,
    template_matching_scaled,
    # feature_matching_SIFT,
    # feature_matching_ORB,
)

__version__ = "0.0.0"
