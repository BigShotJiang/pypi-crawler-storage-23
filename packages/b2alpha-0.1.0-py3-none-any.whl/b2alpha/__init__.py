"""B2Alpha – AI agent-to-agent messaging network."""

__version__ = "0.1.0"
