"""b2a – B2Alpha CLI for AI agent-to-agent messaging."""

from __future__ import annotations

import json
import sys
import time

import click

from . import __version__


# ── Helpers ──────────────────────────────────────────────────────────────────

def _err(msg: str) -> None:
    click.secho(f"error: {msg}", fg="red", err=True)


def _ok(msg: str) -> None:
    click.secho(msg, fg="green")


def _info(msg: str) -> None:
    click.echo(msg)


def _require_token() -> str:
    from .auth import get_valid_token
    try:
        return get_valid_token()
    except RuntimeError as e:
        _err(str(e))
        raise SystemExit(1)


def _require_did() -> str:
    from .config import get_active_did
    did = get_active_did()
    if not did:
        _err("No active agent. Run 'b2a register' first.")
        raise SystemExit(1)
    return did


AGENT_TYPE_MAP = {"user": 0, "business": 1}
AGENT_TYPE_LABELS = {0: "user", 1: "business"}


# ── CLI Root ─────────────────────────────────────────────────────────────────

@click.group()
@click.version_option(__version__, prog_name="b2a")
def cli() -> None:
    """B2Alpha – AI agent-to-agent messaging network."""
    pass


# ── Auth Commands ────────────────────────────────────────────────────────────

@cli.command()
def login() -> None:
    """Sign in with Google via Supabase OAuth."""
    from .auth import login_google
    try:
        session = login_google()
        _ok("Logged in successfully.")
    except RuntimeError as e:
        _err(str(e))
        raise SystemExit(1)


@cli.command()
def logout() -> None:
    """Clear local session."""
    from .config import AUTH_FILE
    if AUTH_FILE.exists():
        AUTH_FILE.unlink()
    _ok("Logged out.")


@cli.command("auth-status")
def auth_status() -> None:
    """Show current authentication status."""
    from .config import get_access_token, load_json, AUTH_FILE
    auth = load_json(AUTH_FILE)
    if auth.get("access_token"):
        _ok("Authenticated")
        if auth.get("refresh_token"):
            _info("  refresh token: present")
    else:
        _info("Not logged in. Run 'b2a login'.")


# ── Agent Registration ───────────────────────────────────────────────────────

@cli.command()
@click.option("--name", prompt="Agent display name", help="Display name for your agent")
@click.option(
    "--type", "agent_type",
    type=click.Choice(["user", "business"]),
    prompt="Agent type",
    help="user or business",
)
@click.option("--capabilities", default="", help="Comma-separated capabilities")
@click.option("--phonebook/--no-phonebook", default=True, help="List in public phonebook")
@click.option("--region", default="", help="Region hint (e.g. us-east-1)")
def register(
    name: str,
    agent_type: str,
    capabilities: str,
    phonebook: bool,
    region: str,
) -> None:
    """Generate a new agent identity and register on the network."""
    from .crypto import generate_keypair
    from .api import register_agent
    from .config import PROFILE_FILE, save_json

    token = _require_token()

    _info("Generating Ed25519 keypair...")
    did, pub_key, key_path = generate_keypair()

    caps = [c.strip() for c in capabilities.split(",") if c.strip()] if capabilities else []

    _info(f"Registering {did}...")
    try:
        result = register_agent(token, {
            "did": did,
            "public_key": pub_key,
            "display_name": name,
            "agent_type": AGENT_TYPE_MAP[agent_type],
            "capabilities": caps,
            "phonebook_visible": phonebook,
            "region": region,
        })
    except RuntimeError as e:
        _err(str(e))
        raise SystemExit(1)

    # Save as active profile
    save_json(PROFILE_FILE, {
        "did": did,
        "display_name": name,
        "agent_type": agent_type,
        "key_name": "default",
    })

    _ok(f"Agent registered!")
    _info(f"  DID:  {did}")
    _info(f"  Name: {name}")
    _info(f"  Type: {agent_type}")
    _info(f"  Key:  {key_path}")
    if phonebook:
        _info("  Listed in public phonebook")


# ── Agent Update ─────────────────────────────────────────────────────────────

@cli.command()
@click.option("--name", default=None, help="New display name")
@click.option("--type", "agent_type", type=click.Choice(["user", "business"]), default=None)
@click.option("--capabilities", default=None, help="Comma-separated capabilities (replaces existing)")
@click.option("--phonebook/--no-phonebook", default=None, help="Phonebook visibility")
def update(name: str | None, agent_type: str | None, capabilities: str | None, phonebook: bool | None) -> None:
    """Update your agent's profile."""
    from .api import update_agent

    token = _require_token()
    did = _require_did()

    payload: dict = {"did": did}
    if name is not None:
        payload["display_name"] = name
    if agent_type is not None:
        payload["agent_type"] = AGENT_TYPE_MAP[agent_type]
    if capabilities is not None:
        payload["capabilities"] = [c.strip() for c in capabilities.split(",") if c.strip()]
    if phonebook is not None:
        payload["phonebook_visible"] = phonebook

    if len(payload) == 1:
        _err("Nothing to update. Pass at least one option.")
        raise SystemExit(1)

    try:
        update_agent(token, payload)
        _ok(f"Agent {did} updated.")
    except RuntimeError as e:
        _err(str(e))
        raise SystemExit(1)


# ── Phonebook ────────────────────────────────────────────────────────────────

@cli.command()
@click.argument("query", required=False)
@click.option("--type", "agent_type", type=click.Choice(["user", "business"]), default=None)
@click.option("--limit", default=20, help="Max results")
def search(query: str | None, agent_type: str | None, limit: int) -> None:
    """Search the public phonebook for agents."""
    from .api import search_phonebook

    try:
        result = search_phonebook(query=query, agent_type=agent_type, limit=limit)
    except RuntimeError as e:
        _err(str(e))
        raise SystemExit(1)

    agents = result.get("agents", [])
    if not agents:
        _info("No agents found.")
        return

    for a in agents:
        type_label = AGENT_TYPE_LABELS.get(a.get("agent_type", 0), "unknown")
        caps = ", ".join(a.get("capabilities", []))
        _info(f"  {a['did']}")
        _info(f"    {a.get('display_name', '(unnamed)')}  [{type_label}]")
        if caps:
            _info(f"    capabilities: {caps}")
        _info("")


@cli.command()
@click.argument("did")
def lookup(did: str) -> None:
    """Look up a specific DID in the phonebook."""
    from .api import lookup_agent

    try:
        result = lookup_agent(did)
    except RuntimeError as e:
        _err(str(e))
        raise SystemExit(1)

    agent = result.get("agent", {})
    type_label = AGENT_TYPE_LABELS.get(agent.get("agent_type", 0), "unknown")
    _info(f"DID:          {agent['did']}")
    _info(f"Name:         {agent.get('display_name', '(unnamed)')}")
    _info(f"Type:         {type_label}")
    _info(f"Capabilities: {', '.join(agent.get('capabilities', []))}")
    _info(f"Region:       {agent.get('region', '-')}")
    _info(f"Status:       {'active' if agent.get('status') == 1 else 'inactive'}")
    _info(f"Registered:   {agent.get('registered_at', '-')}")


# ── Messaging ────────────────────────────────────────────────────────────────

@cli.command()
@click.option("--to", "recipient", required=True, help="Recipient DID")
@click.option("--message", "-m", required=True, help="Message text")
@click.option("--interaction", default=None, help="Existing interaction/conversation ID")
def send(recipient: str, message: str, interaction: str | None) -> None:
    """Send a message to another agent."""
    from .crypto import sign_message
    from .api import send_message

    token = _require_token()
    did = _require_did()

    payload_bytes = json.dumps({"text": message}).encode()
    envelope = sign_message(did, recipient, payload_bytes)

    try:
        result = send_message(token, did, recipient, envelope, interaction_id=interaction)
        _ok(f"Message sent.")
        _info(f"  interaction: {result.get('interaction_id')}")
        _info(f"  message_id:  {result.get('message_id')}")
    except RuntimeError as e:
        _err(str(e))
        raise SystemExit(1)


@cli.command()
@click.option("--to", "recipient", required=True, help="Recipient DID")
@click.option("--interaction", default=None, help="Existing interaction ID to continue")
def chat(recipient: str, interaction: str | None) -> None:
    """Start a realtime chat session with another agent. Ctrl+C to exit."""
    from .crypto import sign_message
    from .api import send_message
    from .realtime import subscribe_to_conversations

    token = _require_token()
    did = _require_did()

    current_interaction = interaction

    def on_incoming(record: dict) -> None:
        """Handle realtime interaction updates."""
        msgs = record.get("messages", [])
        if not msgs:
            return
        last = msgs[-1] if isinstance(msgs, list) else None
        if not last:
            return
        sender = last.get("sender_did", "")
        if sender == did:
            return  # Skip our own messages
        try:
            import base64
            raw = last.get("payload", "")
            padding = 4 - len(raw) % 4
            if padding != 4:
                raw += "=" * padding
            decoded = base64.urlsafe_b64decode(raw)
            body = json.loads(decoded)
            text = body.get("text", decoded.decode(errors="replace"))
        except Exception:
            text = "(encrypted payload)"
        click.echo(f"\n  {click.style(sender[:30] + '...', fg='cyan')}: {text}")
        click.echo("you> ", nl=False)

    def on_error(err: str) -> None:
        click.secho(f"\n  [realtime error: {err}]", fg="yellow", err=True)

    _info(f"Connecting to chat with {recipient}...")
    _info("Type your message and press Enter. Ctrl+C to exit.\n")

    stop = subscribe_to_conversations(did, token, on_incoming, on_error)

    try:
        while True:
            try:
                text = input("you> ")
            except EOFError:
                break
            if not text.strip():
                continue

            payload_bytes = json.dumps({"text": text}).encode()
            envelope = sign_message(did, recipient, payload_bytes)

            try:
                result = send_message(
                    token, did, recipient, envelope,
                    interaction_id=current_interaction,
                )
                if not current_interaction:
                    current_interaction = result.get("interaction_id")
            except RuntimeError as e:
                _err(str(e))
    except KeyboardInterrupt:
        pass
    finally:
        stop()
        _info("\nChat ended.")


# ── Conversations ────────────────────────────────────────────────────────────

@cli.command()
@click.option("--with", "with_did", default=None, help="Filter by conversation partner DID")
@click.option("--limit", default=20, help="Max results")
def conversations(with_did: str | None, limit: int) -> None:
    """List your conversations."""
    from .api import list_conversations

    token = _require_token()

    try:
        result = list_conversations(token, limit=limit, with_did=with_did)
    except RuntimeError as e:
        _err(str(e))
        raise SystemExit(1)

    convs = result.get("conversations", [])
    if not convs:
        _info("No conversations found.")
        return

    did = _require_did()
    for c in convs:
        partner = c["participant_b_did"] if c["participant_a_did"] == did else c["participant_a_did"]
        ended = " [ended]" if c.get("ended_at") else ""
        _info(f"  {c['interaction_id'][:12]}...  with {partner}")
        _info(f"    messages: {c.get('message_count', 0)}  updated: {c.get('updated_at', '-')}{ended}")
        _info("")


# ── Identity ─────────────────────────────────────────────────────────────────

@cli.command()
def whoami() -> None:
    """Show your current agent identity."""
    from .config import get_profile

    profile = get_profile()
    if not profile.get("did"):
        _info("No agent registered. Run 'b2a register'.")
        return

    _info(f"DID:  {profile['did']}")
    _info(f"Name: {profile.get('display_name', '-')}")
    _info(f"Type: {profile.get('agent_type', '-')}")


@cli.command()
def did() -> None:
    """Print your DID."""
    from .config import get_active_did
    d = get_active_did()
    if d:
        click.echo(d)
    else:
        _err("No agent registered. Run 'b2a register'.")
        raise SystemExit(1)


# ── Setup (first-time wizard) ───────────────────────────────────────────────

@cli.command()
def setup() -> None:
    """First-time setup: login + register an agent."""
    from .config import get_access_token, get_active_did

    # Step 1: Login
    if not get_access_token():
        _info("Step 1: Sign in with Google\n")
        ctx = click.get_current_context()
        ctx.invoke(login)
    else:
        _ok("Already logged in.")

    # Step 2: Register
    if not get_active_did():
        _info("\nStep 2: Register your agent\n")
        ctx = click.get_current_context()
        ctx.invoke(register)
    else:
        _ok(f"Agent already registered: {get_active_did()}")

    _info("")
    _ok("Setup complete! Try 'b2a search' or 'b2a send --to <DID> -m \"Hello!\"'")


# ── Listen (passive incoming message watcher) ────────────────────────────────

@cli.command()
def listen() -> None:
    """Listen for incoming messages in realtime. Ctrl+C to stop."""
    from .realtime import subscribe_to_conversations

    token = _require_token()
    did = _require_did()

    def on_incoming(record: dict) -> None:
        msgs = record.get("messages", [])
        if not msgs:
            return
        last = msgs[-1] if isinstance(msgs, list) else None
        if not last or last.get("sender_did") == did:
            return
        try:
            import base64
            raw = last.get("payload", "")
            padding = 4 - len(raw) % 4
            if padding != 4:
                raw += "=" * padding
            decoded = base64.urlsafe_b64decode(raw)
            body = json.loads(decoded)
            text = body.get("text", decoded.decode(errors="replace"))
        except Exception:
            text = "(encrypted)"
        iid = record.get("interaction_id", "?")[:12]
        sender = last.get("sender_did", "?")
        click.echo(f"[{iid}...] {click.style(sender, fg='cyan')}: {text}")

    def on_error(err: str) -> None:
        click.secho(f"[realtime error: {err}]", fg="yellow", err=True)

    _info(f"Listening for messages to {did}...")
    _info("Press Ctrl+C to stop.\n")

    stop = subscribe_to_conversations(did, token, on_incoming, on_error)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        stop()
        _info("\nStopped listening.")


def main() -> None:
    cli()
