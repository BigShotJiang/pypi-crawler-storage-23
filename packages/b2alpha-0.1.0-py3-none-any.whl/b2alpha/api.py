"""HTTP client for B2Alpha Supabase edge functions."""

from __future__ import annotations

from typing import Any

import httpx

from .config import load_env_config


def _base_url() -> str:
    url, _ = load_env_config()
    return f"{url}/functions/v1"


def _anon_headers() -> dict[str, str]:
    _, anon_key = load_env_config()
    return {"apikey": anon_key, "Content-Type": "application/json"}


def _auth_headers(token: str) -> dict[str, str]:
    _, anon_key = load_env_config()
    return {
        "apikey": anon_key,
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }


def register_agent(token: str, payload: dict[str, Any]) -> dict[str, Any]:
    resp = httpx.post(
        f"{_base_url()}/agent-register",
        headers=_auth_headers(token),
        json=payload,
        timeout=15,
    )
    data = resp.json()
    if resp.status_code >= 400:
        raise RuntimeError(data.get("error", f"HTTP {resp.status_code}"))
    return data


def update_agent(token: str, payload: dict[str, Any]) -> dict[str, Any]:
    resp = httpx.patch(
        f"{_base_url()}/agent-update",
        headers=_auth_headers(token),
        json=payload,
        timeout=15,
    )
    data = resp.json()
    if resp.status_code >= 400:
        raise RuntimeError(data.get("error", f"HTTP {resp.status_code}"))
    return data


def lookup_agent(did: str) -> dict[str, Any]:
    resp = httpx.get(
        f"{_base_url()}/agent-lookup",
        params={"did": did},
        headers=_anon_headers(),
        timeout=15,
    )
    data = resp.json()
    if resp.status_code >= 400:
        raise RuntimeError(data.get("error", f"HTTP {resp.status_code}"))
    return data


def search_phonebook(
    query: str | None = None,
    agent_type: str | None = None,
    limit: int = 20,
) -> dict[str, Any]:
    params: dict[str, str] = {"limit": str(limit)}
    if query:
        params["q"] = query
    if agent_type:
        params["type"] = agent_type
    resp = httpx.get(
        f"{_base_url()}/agent-lookup",
        params=params,
        headers=_anon_headers(),
        timeout=15,
    )
    data = resp.json()
    if resp.status_code >= 400:
        raise RuntimeError(data.get("error", f"HTTP {resp.status_code}"))
    return data


def list_conversations(
    token: str,
    limit: int = 50,
    with_did: str | None = None,
) -> dict[str, Any]:
    params: dict[str, str] = {"limit": str(limit)}
    if with_did:
        params["with"] = with_did
    resp = httpx.get(
        f"{_base_url()}/conversations-list",
        params=params,
        headers=_auth_headers(token),
        timeout=15,
    )
    data = resp.json()
    if resp.status_code >= 400:
        raise RuntimeError(data.get("error", f"HTTP {resp.status_code}"))
    return data


def send_message(
    token: str,
    sender_did: str,
    recipient_did: str,
    message: dict[str, Any],
    interaction_id: str | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "sender_did": sender_did,
        "recipient_did": recipient_did,
        "message": message,
    }
    if interaction_id:
        payload["interaction_id"] = interaction_id
    resp = httpx.post(
        f"{_base_url()}/interactions-upsert",
        headers=_auth_headers(token),
        json=payload,
        timeout=15,
    )
    data = resp.json()
    if resp.status_code >= 400:
        raise RuntimeError(data.get("error", f"HTTP {resp.status_code}"))
    return data
