def greet(name):
    return "Hello, " + name + "!"

def farewell(name):
    return "Goodbye, " + name + "!"

def make_upper(text):
    return text.upper()

def count_words(text):
    words = text.split()
    return len(words)