# hello-student-giri

A simple demo Python package uploaded to PyPI for learning packaging.

## Installation

```bash
pip install hello-student-giri