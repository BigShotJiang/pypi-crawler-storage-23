###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

from typing import Union

from lhcbstyle import LHCbStyle
import ROOT as R

from triggercalib.core.Model import Model


class Fitter:
    """
    Class for fitting a PDF to data

    Attributes:
        observable (R.RooAbsReal): observable to be used in the fit
        data (R.RooDataSet): data to be fit
        model (Model): model to be used in the fit
        fit_result (R.RooFitResult): result of the fit
    """

    def __init__(
        self,
        observable: R.RooAbsReal,
        data: R.RooDataSet,
        model: Union[dict, Model] = None,
        pdf: R.RooAddPdf = None,
    ):
        """
        Constructor for the `Fitter` class

        Args:
            observable (R.RooAbsReal): observable to be used in the fit
            data (R.RooDataSet): data to be fit
            model (Union[dict, Model], optional): model to be used in the fit. Defaults to None.
            pdf (R.RooAddPdf, optional): extended PDF to be used in the fit. Defaults to None.

        Note:
            Exactly one of model and pdf must be passed.
        """

        assert (model is not None) + (
            pdf is not None
        ) == 1, "Exactly one of model and pdf must be passed"

        self.observable = observable
        self.data = data
        if model is not None:
            if isinstance(model, dict):
                model = Model(observable, n_evts=data.sumEntries(), **model)
        elif pdf is not None:
            model = Model(observable, n_evts=data.sumEntries(), pdf=pdf)

        self.model = model
        self.fit_result = None

    def fit(self, **kwargs):
        """
        Perform a fit of the model to the data.

        Args:
            **kwargs (): additional keyword arguments to be passed to the `fitTo` method of the PDF.

        Note:
            The fit is performed with `Extended=True` and `Save=True`, which are the default values of these arguments.

        Returns:
            (R.RooFitResult): the result of the fit
        """

        kwargs["Extended"] = kwargs.get("Extended", True)
        kwargs["Save"] = kwargs.get("Save", True)
        kwargs["SumW2Error"] = kwargs.get("SumW2Error", True)

        if kwargs["Extended"] is False:
            raise ValueError("Fit must be performed with `Extended=True`")
        if kwargs["Save"] is False:
            raise ValueError("Fit must be performed with `Save=True`")

        self.fit_result = self.model.pdf.fitTo(self.data, **kwargs)
        return self.fit_result

    def plot(self, path: str = None, **kwargs):
        """
        Plot the model and data on a canvas.

        Args:
            path (str, optional): path to save the canvas to. Defaults to None.
            **kwargs (): additional keyword arguments to be passed to the constructor of `R.TCanvas`.

        Returns:
            (R.TCanvas): the canvas on which the plot is drawn.
        """
        total_yield = sum([y.getVal() for y in self.model.yields])

        with LHCbStyle():
            canvas = R.TCanvas("", "", *kwargs.get("aspect", (800, 600)))
            frame = self.observable.frame()
            self.data.plotOn(frame)

            for pdf in self.model.pdfs:
                self.model.pdf.plotOn(
                    frame,
                    Components=[pdf.GetName()],
                    # Normalization=(total_yield, R.RooAbsReal.NumEvent),
                )
            self.model.pdf.plotOn(
                frame, Normalization=(total_yield, R.RooAbsReal.NumEvent)
            )
            frame.Draw()

            if path is not None:
                canvas.SaveAs(path)
        return canvas

    def splot(self):
        """
        Return an sPlot object for extracting per-event background subtraction weights

        Returns:
            (R.RooStats.SPlot): a sPlot object.
        """
        return R.RooStats.SPlot(
            "",
            "",
            self.data,
            self.model.pdf,
            self.model.yields,
        )  # TODO: replace with sweights package
