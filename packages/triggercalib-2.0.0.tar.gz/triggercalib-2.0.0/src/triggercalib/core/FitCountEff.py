###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

import itertools as it
from typing import Dict, List, Union

import ROOT as R

from triggercalib.core.BaseEff import BaseEff
from triggercalib.core.Fitter import Fitter

from triggercalib.utils import helpers, io


class FitCountEff(BaseEff):
    """
    Class for calculating trigger efficiencies using the fit-and-count method to mitigate background contributions.

    This class is a subclass of `BaseEff` and inherits all its methods and properties.

    Attributes:
        fitters (dict): A dictionary containing the fitters for each bin and category.
        fit_results (dict): A dictionary containing the fit results for each category.
        fit_kwargs (dict): A dictionary containing the keyword arguments for the fit.
        plot_kwargs (dict): A dictionary containing the keyword arguments for the plot.
    """

    def __init__(
        self,
        fit_description: Union[Dict[str, List[float]], str] = None,
        pdf: R.RooAddPdf = None,
        observable: R.RooAbsReal = None,
        workspace: Union[R.RooWorkspace, str] = None,
        ws_observable: str = None,
        ws_pdf: str = None,
        fit_kwargs: Dict = {},
        plot_kwargs: Dict = {},
        *args,
        **kwargs,
    ):
        """
        Constructor for the `FitCountEff` class

        Args:
            fit_description (Union[Dict[str, List[float]], str], optional): Description of the fit. Defaults to None.
            pdf (R.RooAddPdf, optional): The PDF used for fitting. Defaults to None.
            observable (R.RooAbsReal, optional): The observable used for fitting. Defaults to None.
            workspace (Union[R.RooWorkspace, str], optional): The workspace used for fitting. Defaults to None.
            ws_observable (str, optional): The observable name in the workspace. Defaults to None.
            ws_pdf (str, optional): The PDF name in the workspace. Defaults to None.
            fit_kwargs (Dict, optional): The keyword arguments for the fit. Defaults to {}.
            plot_kwargs (Dict, optional): The keyword arguments for the plot. Defaults to {}.

        Note:
            Exactly one of fit_description, pdf and observable together, or workspace, ws_pdf and ws_observable together must be passed.
        """
        super().__init__(*args, **kwargs)

        self.fitters = {}

        self.fit_kwargs = fit_kwargs
        self.plot_kwargs = plot_kwargs

        assert (
            int(fit_description is not None)
            + int(pdf is not None and observable is not None)
            + int(
                workspace is not None
                and ws_observable is not None
                and ws_pdf is not None
            )
            == 1
        ), "Exactly one of fit_description, pdf and observable together, or workspace, ws_pdf and ws_observable together must be passed"

        self.fit_description = None
        self.pdf = None
        self.observable = None
        if fit_description is not None:
            if isinstance(fit_description, str):
                fit_description = io.load_config(fit_description)
            self.fit_description = fit_description

            self.observable = R.RooRealVar(
                self.fit_description["data"]["variable"],
                self.fit_description["data"][
                    "label" if "label" in self.fit_description["data"] else "variable"
                ],
                *self.fit_description["data"]["range"],
            )
            obs_lims = self.fit_description["data"]["range"]
            if "cuts" in self.fit_description["data"]:
                for cut in self.fit_description["data"]["cuts"]:
                    self.rdf = self.rdf.Filter(cut)
        else:
            if pdf and observable:
                self.observable = observable
                self.pdf = pdf
            elif (
                (workspace is not None)
                and (ws_observable is not None)
                and (ws_pdf is not None)
            ):
                if isinstance(workspace, str):
                    path, ws_name = workspace.rsplit(":", 1)
                    with R.TFile.Open(path, "READ") as f:
                        ws = f.Get(ws_name)
                        self.observable = ws.var(ws_observable)
                        self.pdf = ws.pdf(ws_pdf)

            obs_lims = [self.observable.getMin(), self.observable.getMax()]

        self.rdf = self.rdf.Filter(
            f"{self.observable.GetName()} > {obs_lims[0]} && {self.observable.GetName()} < {obs_lims[1]}"
        )

        self._fit_count()
        for yield_var in list(self.fitters.values())[0].model.yields:
            self.compute_efficiencies(suffix=yield_var.GetName())

    def _configure_fitters(self):

        # Book construction of datasets
        dataset_ptrs = {}

        observables_list = [self.observable.GetName()]
        if self.weight is not None:  # Make a helper for this
            weight_branch = "total_weight"
            if isinstance(self.weight, List):
                self.rdf = self.rdf.Define(weight_branch, "*".join(self.weight))
            else:
                self.rdf = self.rdf.Define(weight_branch, self.weight)
            observables_list += [weight_branch] + self.weight
        else:
            weight_branch = None

        if not io.is_in_rdf(observables_list, self.rdf):
            raise ValueError(
                f"Could not find all observable(s) {', '.join(observables_list)} not found in the RDataFrame"
            )

        categories = self.get_categories()
        for category in categories:
            count_rdf = (
                self.rdf.Filter(self.trigger_cut(category))
                if category != "sel"
                else self.rdf
            )

            for bin_nums, edges in zip(
                it.product(
                    *[list(range(1, len(edges) + 1)) for edges in self.binning.edges]
                ),
                it.product(*self.binning.edges),
            ):
                bin_cut = " && ".join(
                    f"({self.binning.variables[i]}>{edge_pair[0]} && {self.binning.variables[i]}<{edge_pair[1]})"
                    for i, edge_pair in enumerate(edges)
                )
                dataset_name = (
                    f"{category}_dataset_bin_{'_'.join([str(n) for n in bin_nums])}"
                )

                dataset_ptrs[dataset_name] = count_rdf.Filter(bin_cut).AsNumpy(
                    observables_list, lazy=True
                )  # TODO: replace with R.RooDataSet?

        # Now get the datasets and use to construct the fitters
        datasets = {
            key: helpers.create_dataset(
                ptr.GetValue(), self.observable, weight=weight_branch
            )
            for key, ptr in dataset_ptrs.items()
        }
        for name, dataset in datasets.items():
            self.fitters[name] = Fitter(
                self.observable,
                dataset,
                (
                    self.fit_description["model"]
                    if self.fit_description is not None
                    else None
                ),
                (
                    self.pdf.cloneTree(name.replace("_dataset_bin_", "_pdf_"))
                    if self.pdf is not None
                    else None
                ),
            )

        # And finally now
        for yield_var in self.fitters[name].model.yields:
            for category in categories:
                count_key = f"{category}_count_{'_'.join(self.binning.variables)}_{yield_var.GetName()}"

                self.counts[count_key] = helpers.empty_histogram(
                    count_key, self.binning
                )

    def _fit_count(self):
        self._configure_fitters()
        for name, fitter in self.fitters.items():
            category, binning_string = name.split("_dataset_bin_", 1)
            bin_indices = [int(b) for b in binning_string.split("_")]
            yields = fitter.model.yields

            if fitter.data.sumEntries() > self.min_entries:
                fitter.fit(**self.fit_kwargs)
            else:
                for yield_var in yields:
                    yield_var.setVal(0.0)
                    yield_var.setError(0.0)

            for yield_var in yields:
                count_key = f"{category}_count_{'_'.join(self.binning.variables)}_{yield_var.GetName()}"

                bin_idx = self.counts[count_key].GetBin(*bin_indices)
                self.counts[count_key].SetBinContent(bin_idx, yield_var.getVal())
                self.counts[count_key].SetBinError(bin_idx, yield_var.getError())

        for yield_var in yields:
            self._process_counts(self.observable.GetName(), suffix=yield_var.GetName())

    def write(
        self,
        path,
        prefix: str = "",
        fit_results: bool = True,
        plots: bool = True,
        workspaces: bool = True,
    ):
        additional_objects = {}
        if plots:
            additional_objects["plots"] = {
                name: fitter.plot(**self.plot_kwargs)
                for name, fitter in self.fitters.items()
            }
        if fit_results:
            additional_objects["fit_results"] = {
                name: fitter.fit_result
                for name, fitter in self.fitters.items()
                if fitter.fit_result is not None and fitter.fit_result != R.nullptr
            }
        super().write(path, prefix, additional_objects=additional_objects)
