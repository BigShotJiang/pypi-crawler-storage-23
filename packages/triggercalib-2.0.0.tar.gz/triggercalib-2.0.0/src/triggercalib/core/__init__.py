###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

"""Trigger efficiency calculation module

This module provides the core functionality for calculating trigger efficiencies:

- HltEff: Main class for efficiency calculations with multiple methods
"""

from .Binning import Binning
from .Sideband import Sideband
from .Model import Model
from .Fitter import Fitter

from .SidebandEff import SidebandEff
from .FitCountEff import FitCountEff
from .SWeightsEff import SWeightsEff

__all__ = [
    "Binning",
    "Sideband",
    "Model",
    "Fitter",
    "SidebandEff",
    "FitCountEff",
    "SWeightsEff",
]
