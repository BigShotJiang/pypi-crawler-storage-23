###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

from array import array
import itertools as it
import os
from typing import Dict, List, Literal, Union

import numpy as np
import ROOT as R

from triggercalib.core.Binning import Binning

from triggercalib.utils import helpers, io, stats


class BaseEff:
    """
    Base class for computing trigger efficiencies

    Attributes:
        counts (Dict[str, R.TH1D]): dictionary containing counts per bin for each count category
        efficiencies (Dict[str, R.TH2D]): dictionary containing efficiencies per bin for each efficiency category
        binning (Binning): binning scheme in which to compute the efficiencies
        rdf (ROOT.RDataFrame): ROOT RDataFrame from which to extract the efficiencies
        particle (str): Particle to seek TIS/TOS branches for
        tos (Union[str, List[str]]): Trigger line(s) to be used as TOS
        tis (Union[str, List[str]]): Trigger line(s) to be used as TIS
        trig (Union[str, List[str]]): Trigger line(s) to be used as trigger
        min_entries (float): minimum number of entries in each category required to evaluate trigger efficiency
        uncertainty_method (Literal["poisson", "generalised_wilson", "standard_wilson"]): method with which to evaluate statistical uncertainties
        weight (Union[str, List[str]]): weight branch
        verbose (bool): whether to print additional information
    """

    def __init__(
        self,
        # Configure input files
        path: Union[str, List[str]],
        tree: str,
        # Configure binning
        binning: Union[str, Dict[str, List], Binning],
        # Configure lines of interest
        particle: str,
        tos: Union[str, List[str]],  # <- line(s) to be used as TOS
        tis: Union[str, List[str]],  # <- line(s) to be used as TIS
        # Optional arguments
        cut: str = None,
        trig_effs: bool = True,
        # Add friend
        friend_path: str = None,
        friend_tree: str = None,
        min_entries: float = 50,
        uncertainty_method: Literal[
            "poisson", "generalised_wilson", "standard_wilson"
        ] = "generalised_wilson",
        weight: Union[str, List[str]] = None,
        verbose: bool = False,
    ):
        """
        Constructor for the `BaseEff` class

        Arguments:
            path (Union[str, List[str]]): File(s) to be read in
            tree (str): ROOT TTree(s) to be read in
            binning (Union[str, Dict[str, List[float]], Binning]): Binning scheme to be used
            particle (str): Particle to seek TIS/TOS branches for
            tos (Union[str, List[str]]): Trigger line(s) to be used as TOS
            tis (Union[str, List[str]]): Trigger line(s) to be used as TIS
            cut (str): Selection requirements to be applied
            trig_effs (bool): Whether to calculate trigger efficiencies
            friend_path (str): Path to friend file
            friend_tree (str): Name of friend TTree
            min_entries (float): minimum number of entries in each category required to evaluate trigger efficiency
            uncertainty_method (Literal["poisson", "generalised_wilson", "standard_wilson"]): method with which to evaluate statistical uncertainties
            weight (Union[str, List[str]]): weight branch
            verbose (bool): whether to print additional information
        """

        self.counts = {}
        self.efficiencies = {}

        if isinstance(binning, Binning):
            self.binning = binning
        else:
            if isinstance(binning, str):
                binning = io.load_config(binning)
            self.binning = Binning(**binning)

        self.rdf = io.configure_rdf(
            path, tree, friend_path=friend_path, friend_tree=friend_tree, cut=cut
        )

        branches = {str(col) for col in self.rdf.GetColumnNames()}
        self.particle = particle
        self.tos = helpers.parse_selection(particle, tos, "TOS", branches)
        self.tis = helpers.parse_selection(particle, tis, "TIS", branches)

        trig = helpers.parse_selection(particle, tos, "", branches)
        if trig_effs:
            self.trig = trig
        else:
            self.trig = None

        self.min_entries = min_entries
        self.uncertainty_method = uncertainty_method

        self.weight = None
        if isinstance(weight, List):
            if all(w in branches for w in weight):
                self.weight = weight
        elif weight is not None and weight in branches:
            self.weight = [weight]

        self.verbose = verbose

    def count(self, key):
        return self.counts[key]

    def efficiencies(self, key):
        # TODO: make this more advanced when THNDs implemented
        return self.efficiencies[key]

    def write(self, path, prefix: str = "", additional_objects: Dict = None):
        if "://" not in path:
            os.makedirs(os.path.dirname(path), exist_ok=True)

        object_dict = {
            "counts": self.counts,
            "efficiencies": self.efficiencies,
        }
        if additional_objects is not None:
            object_dict.update(additional_objects)

        with R.TFile.Open(path, "RECREATE") as f:
            for label, objects in object_dict.items():
                obj_dir = f.mkdir(label)
                obj_dir.cd()
                for name, obj in objects.items():
                    if prefix:
                        name = f"{prefix}_{name}"
                        obj.SetName(name)
                    if self.verbose:
                        print(
                            f"Writing object '{name}' to directory '{label}' of file '{path}'"
                        )
                    assert obj is not R.nullptr, f"Could not find object {name}"
                    obj.Write(name)

    def base_efficiency(  # TODO: replace with an Efficiency class when moving to THnDs
        self,
        name: str,
        numerator_hist: R.TH1,
        denominator_hist: R.TH1,
        axis: int = None,
        integrated: bool = False,
    ):
        """Calculate efficiency from two histograms for the TIS or TOS trigger outcome categories

        Args:
            name (str): Name for the efficiency histogram
            numerator_hist (R.TH1): Histogram of passing events
            denominator_hist (R.TH1): Histogram of total events
            axis (int): Optional axis to project onto
            integrated (bool): Whether to calculate as an integrated efficiency

        Returns:
            (TGraphAsymmErrors, TGraph2DAsymmErrors): Efficiency histogram (in 1D or 2D)
        """
        _is_2D = isinstance(numerator_hist, R.TH2)
        xaxis = numerator_hist.GetXaxis()

        if _is_2D:
            yaxis = numerator_hist.GetYaxis()
            eff = R.TGraph2DAsymmErrors()
        else:
            eff = R.TGraphAsymmErrors()

        if integrated:
            numerator_value, numerator_error = helpers.sum_bins(numerator_hist)
            denominator_value, denominator_error = helpers.sum_bins(denominator_hist)
            if numerator_value > denominator_value:
                print(
                    "Bin contains more passing events than total events (efficiency > 1), setting N(passing) to N(total)"
                )
                numerator_value = denominator_value

            if "wilson" in self.uncertainty_method:
                eff_value, eff_low, eff_up = stats.wilson(
                    numerator_value,
                    denominator_value,
                    passed_error=(
                        numerator_error
                        if "generalised" in self.uncertainty_method
                        else None
                    ),
                    total_error=(
                        denominator_error
                        if "generalised" in self.uncertainty_method
                        else None
                    ),
                )
            else:
                eff_value, eff_low, eff_up = stats.poisson(
                    numerator_value,
                    denominator_value,
                    passed_error=numerator_error,
                    total_error=denominator_error,
                )

            x_min = xaxis.GetXmin()
            x_max = xaxis.GetXmax()
            x_center = (x_min + x_max) / 2
            x_low = x_center - x_min
            x_up = x_max - x_center

            if _is_2D:
                yaxis = numerator_hist.GetYaxis()
                y_min = yaxis.GetXmin()
                y_max = yaxis.GetXmax()
                y_center = (y_min + y_max) / 2
                y_low = y_center - y_min
                y_up = y_max - y_center

                eff.AddPoint(x_center, y_center, eff_value)
                eff.SetPointError(0, x_low, x_up, y_low, y_up, eff_low, eff_up)
            else:
                eff.AddPoint(x_center, eff_value)
                eff.SetPointError(0, x_low, x_up, eff_low, eff_up)

        else:
            for n, midpoint_coords in enumerate(it.product(*self.binning.midpoints)):
                coords = [midpoint_coords[axis]] if axis else midpoint_coords

                numerator_bin_num = numerator_hist.FindBin(*coords)
                numerator_value = numerator_hist.GetBinContent(numerator_bin_num)
                numerator_error = numerator_hist.GetBinError(numerator_bin_num)

                denominator_bin_num = denominator_hist.FindBin(*coords)
                denominator_value = denominator_hist.GetBinContent(denominator_bin_num)
                denominator_error = denominator_hist.GetBinError(denominator_bin_num)
                if (
                    numerator_value < self.min_entries
                    or denominator_value < self.min_entries
                ):
                    numerator_value = 0
                    numerator_error = 0

                    denominator_value = 0
                    denominator_error = 0

                if numerator_value > denominator_value:
                    print(
                        "Bin contains more passing events than total events (efficiency > 1), setting N(passing) to N(total)"
                    )
                    numerator_value = denominator_value

                if "wilson" in self.uncertainty_method:
                    eff_value, eff_low, eff_up = stats.wilson(
                        numerator_value,
                        denominator_value,
                        passed_error=(
                            numerator_error
                            if "generalised" in self.uncertainty_method
                            else None
                        ),
                        total_error=(
                            denominator_error
                            if "generalised" in self.uncertainty_method
                            else None
                        ),
                    )
                else:
                    eff_value, eff_low, eff_up = stats.poisson(
                        numerator_value,
                        denominator_value,
                        passed_error=numerator_error,
                        total_error=denominator_error,
                    )

                xbin = xaxis.FindBin(coords[0])
                x_center = xaxis.GetBinCenter(xbin)
                x_low = x_center - xaxis.GetBinLowEdge(xbin)
                x_up = xaxis.GetBinUpEdge(xbin) - x_center

                if _is_2D:
                    ybin = yaxis.FindBin(coords[1])
                    y_center = yaxis.GetBinCenter(ybin)
                    y_low = y_center - yaxis.GetBinLowEdge(ybin)
                    y_up = yaxis.GetBinUpEdge(ybin) - y_center

                    eff.AddPoint(x_center, y_center, eff_value)
                    eff.SetPointError(n, x_low, x_up, y_low, y_up, eff_low, eff_up)
                else:
                    eff.AddPoint(x_center, eff_value)
                    eff.SetPointError(n, x_low, x_up, eff_low, eff_up)

            eff.SetName(name)
            eff.SetTitle(name)

        return eff

    def compute_efficiencies(self, suffix: str = ""):

        if suffix != "":
            suffix = f"_{suffix}"
        axes = [None, 0, 1]
        suffixes = (
            [
                "_".join(self.binning.variables) + suffix,
                list(self.binning.variables)[0] + suffix,
                list(self.binning.variables)[1] + suffix,
            ]
            if len(self.binning.variables) > 1
            else ["_".join(self.binning.variables) + suffix]
        )

        for (
            (axis, _suffix),
            total,
            (efficiency_category, numerator_category, denominator_category),
        ) in it.product(
            zip(axes, suffixes),
            ("", "total_"),
            zip(
                ("tos", "tis", "trig"),
                ("tistos", "tistos", "trig"),
                ("tis", "tos", "sel"),
            ),
        ):

            if (
                not bool(total)
                or axis
                is None  # Skips integrated efficiencies in each axis (the 1D and 2D integrated efficiencies are equivalent)
            ) and (
                numerator_category != "trig"
                or self.trig
                is not None  # Only compute trigger efficiencies if `trig_effs`` was True
            ):
                self.efficiencies[
                    f"{efficiency_category}_{total}efficiency_{_suffix}"
                ] = self.base_efficiency(
                    f"{efficiency_category}_{total}efficiency_{_suffix}",
                    self.counts[f"{numerator_category}_count_{_suffix}"],
                    self.counts[f"{denominator_category}_count_{_suffix}"],
                    axis=axis,
                    integrated=bool(total),
                )

        return

    def rdf_histo(self, rdf: R.RDataFrame, name: str, weight: str = ""):
        """Create a histogram from a branch in a given RDataFrame object

        Args:
            rdf (ROOT.RDataFrame): Input RDataFrame
            name (str): Name for the histogram
            weight (str): Optional weight branch

        Returns:
            (ROOT.RDataFrame): Pointer to booked RDataFrame histogram (1D or 2D)
        """
        if len(self.binning.variables) == 1:
            args = [
                (
                    name,
                    name,
                    len(self.binning.bins[0]) - 1,
                    array("d", self.binning.bins[0]),
                ),
                self.binning.variables[0],
            ]
            if weight:
                args += [weight]

            return rdf.Histo1D(*args)
        elif len(self.binning.variables) == 2:
            args = [
                (
                    name,
                    name,
                    len(self.binning.bins[0]) - 1,
                    array("d", self.binning.bins[0]),
                    len(self.binning.bins[1]) - 1,
                    array("d", self.binning.bins[1]),
                ),
                self.binning.variables[0],
                self.binning.variables[1],
            ]
            if weight:
                args += [weight]

            return rdf.Histo2D(*args)
        raise RuntimeError("Calculations can only be performed in 1D or 2D")

    def trigger_cut(self, category: str):
        """Obtain ROOT cut string for a trigger outcome category

        Args:
            category (str): One of 'tis', 'tos', 'tistos', or 'trig'

        Returns:
            (str): ROOT cut expression for the specified trigger outcome category

        Raises:
            ValueError: If category is not one of the allowed values
        """
        if category == "tis":
            return self.tis
        elif category == "tos":
            return self.tos
        elif category == "tistos":
            return f"({self.tis}) && ({self.tos})"
        elif category == "trig":
            return self.trig
        raise ValueError("Category must be one of 'tis', 'tos', 'tistos' or 'trig'")

    def to_project(
        self, label: str, bin_requirement: bool = True, additional_parts: List = []
    ):
        """Check if a histogram should be projected, based on its label

        Args:
            label (str): Histogram label to check
            bin_requirement (bool): Whether to require binning variables
            additional_parts (List): Additional parts to check against

        Returns:
            (bool): True if the histogram should be projected
        """
        test_parts = [f"_{var}" for var in self.binning.variables]
        if additional_parts:
            test_parts += additional_parts
        return (len(self.binning.variables) > 1 or not bin_requirement) and not any(
            l in label and "_".join(self.binning.variables) not in label
            for l in test_parts
        )

    def _process_counts(self, observable, suffix: str = ""):
        if suffix != "":
            suffix = f"_{suffix}"

        for category in ("tis", "tos"):
            category_name = (
                f"{category}_only_count_{'_'.join(self.binning.variables)}{suffix}"
            )
            self.counts[category_name] = self.counts[
                f"{category}_count_{'_'.join(self.binning.variables)}{suffix}"
            ].Clone(category_name)
            self.counts[category_name].SetTitle(category_name)
            self.counts[category_name].Add(
                self.counts[f"tistos_count_{'_'.join(self.binning.variables)}{suffix}"],
                -1,
            )

        if self.trig is not None:
            # Compute estimate of selected efficiency, the denominator of the trig. efficiency
            sel_hist_name = f"sel_count_{'_'.join(self.binning.variables)}{suffix}"
            self.counts[sel_hist_name] = helpers.empty_histogram(
                sel_hist_name, self.binning
            )

            bin_nums = helpers.bin_nums_from_hist(self.counts[sel_hist_name])
            for n_bin in bin_nums:
                _tistos_name = sel_hist_name.replace("sel", "tistos")
                tistos_n = self.counts[_tistos_name].GetBinContent(n_bin)
                tistos_s = self.counts[_tistos_name].GetBinError(n_bin)

                _tis_name = sel_hist_name.replace("sel", "tis")
                tis_n = self.counts[_tis_name].GetBinContent(n_bin)
                tis_s = self.counts[_tis_name].GetBinError(n_bin)

                _tos_name = sel_hist_name.replace("sel", "tos")
                tos_n = self.counts[_tos_name].GetBinContent(n_bin)
                tos_s = self.counts[_tos_name].GetBinError(n_bin)

                if tistos_n > 0:
                    bin_value = tis_n * tos_n / tistos_n
                    bin_error = np.sqrt(
                        np.abs(tos_n / tistos_n) ** 2 * np.abs(tis_s**2 - tistos_s**2)
                        + np.abs(tis_n / tistos_n) ** 2 * np.abs(tos_s**2 - tistos_s**2)
                        + np.abs(
                            1 - (tis_n - tistos_n) * (tos_n - tistos_n) / tistos_n**2
                        )
                        ** 2
                        * tistos_s**2
                    )
                else:
                    bin_value = 0
                    bin_error = 0

                self.counts[sel_hist_name].SetBinContent(n_bin, bin_value)
                self.counts[sel_hist_name].SetBinError(n_bin, abs(bin_error))

        additional_parts = [observable]
        for count_label, count_hist in dict(self.counts).items():
            if self.to_project(count_label, additional_parts=additional_parts):
                self.counts[
                    count_label.replace(
                        "_".join(self.binning.variables),
                        list(self.binning.variables)[0],
                    )
                ] = count_hist.ProjectionX()
                self.counts[
                    count_label.replace(
                        "_".join(self.binning.variables),
                        list(self.binning.variables)[1],
                    )
                ] = count_hist.ProjectionY()

        return

    def get_categories(self):
        categories = ["tos", "tis", "tistos"]
        if self.trig is not None:
            categories.append("trig")
        return categories
