###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

import itertools as it
from typing import Dict, List, Union

from triggercalib.core.BaseEff import BaseEff
from triggercalib.core.Sideband import Sideband

from triggercalib.utils import io


class SidebandEff(BaseEff):
    """
    Class for calculating trigger efficiencies using the sWeights method to mitigate background contributions.

    This class is a subclass of `BaseEff` and inherits all its methods and properties.

    Attributes:
        sideband (Sideband): An instance of the `Sideband` class representing the sideband configuration.
    """

    def __init__(
        self,
        sideband: Union[Dict[str, List[float]], str, Sideband] = None,
        *args,
        **kwargs,
    ):
        """
        Constructor for the `SidebandEff` class

        Args:
            sideband (Union[Dict[str, List[float]], str, Sideband]): Either a Sideband object, a dictionary of sideband configuration, or a string pointing to a YAML file containing the sideband configuration.
            *args (): Additional positional arguments to be passed to the BaseEff constructor.
            **kwargs (): Additional keyword arguments to be passed to the BaseEff constructor.
        """
        super().__init__(*args, **kwargs)

        if isinstance(sideband, Sideband):
            self.sideband = sideband
        else:
            if isinstance(sideband, str):
                sideband = io.load_config(sideband)
            self.sideband = Sideband(**sideband)

        # First create the required histograms of counts
        self._histogram_counts()

        # And then evaluate the efficiencies
        self.compute_efficiencies()

    def _histogram_counts(self):

        ptrs = {}

        if self.weight is not None:
            weight_branch = "total_weight"
            if isinstance(self.weight, List):
                self.rdf = self.rdf.Define(weight_branch, "*".join(self.weight))
            else:
                self.rdf = self.rdf.Define(weight_branch, self.weight)
        else:
            weight_branch = None

        for category in self.get_categories():
            count_rdf = (
                self.rdf.Filter(self.trigger_cut(category))
                if category != "sel"
                else self.rdf
            )

            for cut_label, cut in zip(
                ("all", "signal", "sideband"),
                (
                    self.sideband.range_cut(),
                    self.sideband.signal_cut(),
                    self.sideband.sideband_cut(),
                ),
            ):
                temp_rdf = count_rdf.Filter(cut)
                ptrs[
                    f"{category}_{cut_label}_count_{'_'.join(self.binning.variables)}"
                ] = self.rdf_histo(
                    temp_rdf,
                    f"{category}_{cut_label}_count_{'_'.join(self.binning.variables)}",
                    weight=weight_branch,
                )

        additional_parts = [self.sideband.variable] if self.sideband else []
        for key, count in ptrs.items():
            hist = count.GetValue()
            self.counts[key] = hist
            if self.to_project(key, additional_parts=additional_parts):
                self.counts[
                    key.replace(
                        "_".join(self.binning.variables), self.binning.variables[0]
                    )
                ] = hist.ProjectionX()
                self.counts[
                    key.replace(
                        "_".join(self.binning.variables), self.binning.variables[1]
                    )
                ] = hist.ProjectionY()

        for key in list(self.counts.keys()):
            if self.to_project(key, bin_requirement=False) and "_signal_" in key:
                new_key = key.replace("_signal_", "_")
                self.counts[new_key] = self.counts[key].Clone(new_key)
                self.counts[new_key].SetTitle(new_key)

                _subtract_hist = self.counts[
                    key.replace("_signal_", "_sideband_")
                ].Clone(f"{new_key}_subtract_hist")

                if "count" in key:
                    self.counts[new_key].Add(_subtract_hist, -1 * self.sideband.scale())
                else:
                    _sideband_count = self.counts[
                        key.replace("_signal_", "_sideband_")
                    ].GetEntries()

                    if _subtract_hist.GetNbinsY() > 1:
                        bin_nums = it.product(
                            (
                                list(range(1, _subtract_hist.GetNbinsX() + 1)),
                                list(range(1, _subtract_hist.GetNbinsY() + 1)),
                            )
                        )
                    else:
                        bin_nums = zip(list(range(1, _subtract_hist.GetNbinsX() + 1)))

                    for b in bin_nums:
                        n_bin = _subtract_hist.GetBin(*b)
                        if (
                            _subtract_hist.GetBinCenter(n_bin) > self.sideband.signal[0]
                            and _subtract_hist.GetBinCenter(n_bin)
                            < self.sideband.signal[1]
                        ):
                            width = (
                                _subtract_hist.GetBinWidth(n_bin)
                                if "count" not in key
                                else None
                            )
                            _subtract_hist.SetBinContent(
                                n_bin, _sideband_count * self.sideband.scale(width)
                            )
                        else:
                            _subtract_hist.SetBinContent(n_bin, 0)

                    self.counts[new_key].Add(_subtract_hist, -1)

        self._process_counts(self.sideband.variable)
