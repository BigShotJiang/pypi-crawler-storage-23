###############################################################################
# (c) Copyright 2024-2026 CERN for the benefit of the LHCb Collaboration      #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

from ctypes import c_double
from typing import Annotated, List, Union

import numpy as np
import ROOT as R


def check_result(
    value: float,
    error: Annotated[List[float], 2],
    sample: str = "example_file.root:Hlt2Test/DecayTree",
    cut: str = "",
    line: str = "Hlt1DummyOne",
    threshold: float = 5.0,
):
    """Check if a test result matches expectations

    Args:
        value (float): Measured value to check
        error (Annotated[List[float], 2]): List of lower and upper uncertainties
        sample (str): Path to input ROOT file and tree
        cut (str): Additional selection criteria
        line (str): Trigger line to check
        threshold (float): Maximum allowed deviation in percent

    Returns:
        (bool): Whether result matches expectations within threshold
    """
    sample_rdf = R.RDataFrame(*reversed(sample.rsplit(":", 1)))
    sample_rdf = sample_rdf.Filter(cut)
    sample_rdf = sample_rdf.Filter("isSignal")
    denominator = sample_rdf.Count()
    numerator = sample_rdf.Filter(f"{line}Decision").Count()

    true_efficiency = numerator.GetValue() / denominator.GetValue()

    result_okay = (
        true_efficiency > value - threshold * error[0]
        and true_efficiency < value + threshold * error[1]
    )

    if not result_okay:
        print(
            f"True efficiency '{true_efficiency:.4f}' does not lie within window [{value - threshold * error[0]:.4f} - {value + threshold * error[1]:.4f}] ({threshold:.1f} sigma threshold)"
        )

    return result_okay, (
        true_efficiency,
        value - threshold * error[0],
        value + threshold * error[1],
    )


def compare_tgraph_to_th(
    tgraph: Union[R.TGraphAsymmErrors, R.TGraph2DAsymmErrors], th: R.TH1
):
    """
    Tool for comparing that a ROOT.TGraph and ROOT.TH1 object contain the same points

    Args:
        tgraph (Union[ROOT.TGraphAsymmErrors, ROOT.TGraph2DAsymmErrors]): ROOT TGraph to compare
        th (ROOT.TH1): ROOT TH1 to compare
    """

    num_points = tgraph.GetN()
    x = c_double(0)
    y = c_double(0)
    z = c_double(0)

    tgraph_vals = []
    tgraph_errs = []

    th_vals = []
    th_errs = []

    for n_point in range(num_points):
        if isinstance(tgraph, R.TGraph2DAsymmErrors):
            tgraph.GetPoint(n_point, x, y, z)
        else:
            tgraph.GetPoint(n_point, x, y)

        n_bin = th.FindBin(x, y)
        th_vals.append(th.GetBinContent(n_bin))
        th_errs.append(th.GetBinError(n_bin))

        if isinstance(tgraph, R.TGraph2DAsymmErrors):
            tgraph_vals.append(z.value)
            tgraph_errs.append(tgraph.GetErrorZ(n_point))
        else:
            tgraph_vals.append(y.value)
            tgraph_errs.append(tgraph.GetErrorY(n_point))

    if not np.array_equal(th_vals, tgraph_vals):
        raise RuntimeError
    if not np.array_equal(th_errs, tgraph_errs):
        raise RuntimeError

    return True
