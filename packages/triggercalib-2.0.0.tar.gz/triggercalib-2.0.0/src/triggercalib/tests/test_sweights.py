###############################################################################
# (c) Copyright 2024-2026 CERN for the benefit of the LHCb Collaboration      #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

import os
import pytest

import numpy as np
import ROOT as R

from triggercalib.utils.tests import check_result

R.gROOT.SetBatch(True)
os.makedirs("results", exist_ok=True)


def test_sweights(example_file):
    from triggercalib import SWeightsEff

    tree, path = example_file
    binning = {"variables": ["observ1"], "bins": [np.linspace(0, 8, 5)]}
    fit_description = {
        "data": {
            "variable": "discrim",
            "range": [5000, 5400],
        },
        "model": {
            "components": {
                "signal": {
                    "function": "BreitWigner",
                    "parameters": {"mean": [5195, 5175, 5225], "width": [8, 4, 24]},
                },
                "background": {
                    "function": "Exponential",
                    "parameters": {"lambda": [-0.001, -0.01, 0]},
                },
            }
        },
    }

    sweights_eff = SWeightsEff(
        path=path,
        tree=tree,
        binning=binning,
        tis="Hlt1DummyOne",
        tos="Hlt1DummyOne",
        particle="P",
        fit_description=fit_description,
    )
    sweights_eff.write("results/output_test_sweights.root")

    hist = sweights_eff.efficiencies["trig_total_efficiency_observ1_N_signal"]
    val = hist.GetPointY(0)
    err_low = hist.GetErrorYlow(0)
    err_high = hist.GetErrorYhigh(0)

    result_okay, (true, lower, upper) = check_result(
        val,
        (err_low, err_high),
        sample=f"{path}:{tree}",
        cut="discrim > 5100 && discrim < 5300 && observ1 > 0 && observ1 < 8",
    )
    if not result_okay:
        print(f"Computed efficiency out of bounds: {true} not in ({lower}-{upper})")
        raise RuntimeError


def test_sweights_sparse(example_sparse_file):
    from triggercalib import SWeightsEff

    tree, path = example_sparse_file
    binning = {"variables": ["observ1"], "bins": [np.linspace(0, 8, 5)]}
    fit_description = {
        "data": {
            "variable": "discrim",
            "range": [5000, 5400],
        },
        "model": {
            "components": {
                "signal": {
                    "function": "BreitWigner",
                    "parameters": {"mean": [5195, 5175, 5225], "width": [8, 4, 24]},
                },
                "background": {
                    "function": "Exponential",
                    "parameters": {"lambda": [-0.001, -0.01, 0]},
                },
            }
        },
    }

    with pytest.raises(RuntimeError):
        sweights_eff = SWeightsEff(
            path=path,
            tree=tree,
            binning=binning,
            tis="Hlt1DummyOne",
            tos="Hlt1DummyOne",
            particle="P",
            fit_description=fit_description,
        )  # TODO: seek output of warning


def test_sweights_weighted(example_file):
    from triggercalib import SWeightsEff

    tree, path = example_file
    binning = {"variables": ["observ1"], "bins": [np.linspace(0, 8, 5)]}
    fit_description = {
        "data": {
            "variable": "discrim",
            "range": [5000, 5400],
        },
        "model": {
            "components": {
                "signal": {
                    "function": "BreitWigner",
                    "parameters": {"mean": [5195, 5175, 5225], "width": [8, 4, 24]},
                },
                "background": {
                    "function": "Exponential",
                    "parameters": {"lambda": [-0.001, -0.01, 0]},
                },
            }
        },
    }

    sweights_eff = SWeightsEff(
        path=path,
        tree=tree,
        binning=binning,
        tis="Hlt1DummyOne",
        tos="Hlt1DummyOne",
        particle="P",
        fit_description=fit_description,
        weight="event_weight",
    )
    sweights_eff.write("results/output_test_sweights_weighted.root")

    hist = sweights_eff.efficiencies["trig_total_efficiency_observ1_N_signal"]
    val = hist.GetPointY(0)
    err_low = hist.GetErrorYlow(0)
    err_high = hist.GetErrorYhigh(0)

    result_okay, (true, lower, upper) = check_result(
        val,
        (err_low, err_high),
        sample=f"{path}:{tree}",
        cut="discrim > 5100 && discrim < 5300 && observ1 > 0 && observ1 < 8",
    )
    if not result_okay:
        print(f"Computed efficiency out of bounds: {true} not in ({lower}-{upper})")
        raise RuntimeError
