###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

import itertools as it
import os

import numpy as np
import ROOT as R

from triggercalib.utils.tests import check_result

os.makedirs("results", exist_ok=True)
R.gROOT.SetBatch(True)


def test_generate_binning(example_file):
    from triggercalib import Binning
    from triggercalib.utils import io

    tree, path = example_file

    rdf = io.configure_rdf(path, tree)
    binning = Binning.generate(
        rdf, ["observ1"], [[0, 8]], [5], cut="discrim > 5000 && discrim < 5400"
    )

    print(binning.edges)
    rdf = rdf.Filter("observ1 > 0 && observ1 < 8")
    rdf = rdf.Filter("discrim > 5000 && discrim < 5400")

    np_array = rdf.AsNumpy(["observ1"])["observ1"]

    all_edges = list(it.product(*binning.edges))
    for edges in all_edges:
        indices = np.ones(len(np_array))
        for edge_set in edges:
            indices = np.logical_and(indices, np_array > edge_set[0])
            indices = np.logical_and(indices, np_array < edge_set[1])

        fraction = np.count_nonzero(indices) / np_array.size
        if fraction < 1 / len(all_edges) - 1 / np.sqrt(np_array.size):
            raise RuntimeError
        if fraction > 1 / len(all_edges) + 1 / np.sqrt(np_array.size):
            raise RuntimeError
