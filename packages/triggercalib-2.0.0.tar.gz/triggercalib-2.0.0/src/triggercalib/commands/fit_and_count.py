###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration.          #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

import argparse
from types import SimpleNamespace


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument("--path", type=str, required=True, nargs="+")
    parser.add_argument("--tree", type=str, required=True)
    parser.add_argument("--binning", type=str, required=True)
    parser.add_argument(
        "--fit-description", type=str, default=None
    )  # TODO: Provide some default models
    parser.add_argument("--workspace", type=str, default=None)

    parser.add_argument("--particle", type=str, required=True)
    parser.add_argument("--tis", type=str, required=True, nargs="+")
    parser.add_argument("--tos", type=str, required=True, nargs="+")

    parser.add_argument("--output", type=str, required=True)

    parser.add_argument("--friend-path", type=str, nargs="+", default=None)
    parser.add_argument("--friend-tree", type=str, default=None)
    parser.add_argument("--cut", type=str, default=None, nargs="+")
    parser.add_argument("--weight", type=str, default=None, nargs="+")
    parser.add_argument("--threads", type=int, default=1)

    return parser.parse_args()


def main(args=None):
    import ROOT as R

    from triggercalib import FitCountEff

    if args is None:
        args = parse_args()
    elif isinstance(args, dict):
        args["fit_description"] = args.get("fit_description", None)
        args["workspace"] = args.get("workspace", None)
        args["threads"] = args.get("threads", 1)
        args["friend_path"] = args.get("friend_path", None)
        args["friend_tree"] = args.get("friend_tree", None)
        args["cut"] = args.get("cut", None)
        args["weight"] = args.get("weight", None)
        args = SimpleNamespace(**args)

    assert (args.fit_description is not None) + (
        args.workspace is not None
    ) == 1, "Exactly one of --fit-description and --workspace must be passed"

    if args.workspace is not None:
        workspace, ws_observable, ws_pdf = args.workspace.rsplit(":", 2)
    else:
        workspace = None
        ws_observable = None
        ws_pdf = None

    if args.threads > 1 and args.friend_path is None and args.friend_tree is None:
        R.EnableImplicitMT(args.threads)

    fitcount_eff = FitCountEff(
        path=args.path,
        tree=args.tree,
        particle=args.particle,
        tis=args.tis,
        tos=args.tos,
        binning=args.binning,
        fit_description=args.fit_description,
        workspace=workspace,
        ws_observable=ws_observable,
        ws_pdf=ws_pdf,
        friend_path=args.friend_path,
        friend_tree=args.friend_tree,
        cut=args.cut,
        weight=args.weight,
        fit_kwargs={
            "NumCPU": args.threads,
        },
    )
    fitcount_eff.write(args.output)

    return


if __name__ == "__main__":
    main()
