::: core.SidebandEff
    options:
        heading_level: 2
        show_root_toc_entry: false

::: core.FitCountEff
    options:
        heading_level: 2
        show_root_toc_entry: false

::: core.SWeightsEff
    options:
        heading_level: 2
        show_root_toc_entry: false

::: core.BaseEff
    options:
        heading_level: 2
        show_root_toc_entry: false


::: core.Binning
    options:
        heading_level: 2
        show_root_toc_entry: false

::: core.Fitter
    options:
        heading_level: 2
        show_root_toc_entry: false

::: core.Model
    options:
        heading_level: 2
        show_root_toc_entry: false

::: core.Sideband
    options:
        heading_level: 2
        show_root_toc_entry: false
