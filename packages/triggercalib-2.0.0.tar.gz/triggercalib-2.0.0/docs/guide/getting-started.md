# Getting started

TriggerCalib is a Python package which can be installed [from PyPI](https://pypi.org/project/triggercalib) using ``pip install triggercalib`` and is compatible with Python 3.6+.
In the near future, TriggerCalib will also be installable with ``conda``.
Most of the dependencies TriggerCalib are handled by ``pip``; however, ``ROOT`` cannot be ``pip install``ed for all recent versions, and so must be included in the environment from which TriggerCalib is run.

TriggerCalib provides a ROOT-based implementation of the TISTOS [^1] method of calculating trigger efficiencies and is designed to run out of the box on your analysis ntuples.
Following the steps of this user guide, TriggerCalib can beconfigured to produce histograms of event counts in TIS/TOS/trigger categories and TIS/TOS/trigger efficiencies for desired HLT1 and/or HLT2 lines, in either 1- or 2-dimensions.

!!! note

    It is recommended that you read through the [introduction](trigger-efficiencies.md) first to understand the TISTOS method and its implementation.
    The [TriggerCalib tutorials](tutorials/index.md) walk through the main functionality of TriggerCalib's efficiency calculators described in the [`triggercalib.core` class reference](../reference/core.md).


[^1]: S. Tolk et al., *Data driven trigger efficiency determination at LHCb* ([LHCb-PUB-2014-039](https://cds.cern.ch/record/1701134/files/LHCb-PUB-2014-039.pdf)), 2014