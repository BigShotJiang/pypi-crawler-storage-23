# Running TriggerCalib

There are two ways to access the trigger efficiency calculators in TriggerCalib:
    
1. From the command line, through `triggercalib.sideband`, `triggercalib.fit_and_count` and `triggercalib.sweights`, which are described below.
2. By importing each calculator and using it within your own scripts, as described in the [TriggerCalib tutorials](tutorials/index.md).

## The TriggerCalib command-line interface
TriggerCalib now has a command-line interface consisting of three methods, configured as follows.

### Sideband-subtraction
Efficiencies using sideband-subtraction can be evaluated using `triggercalib.sideband`, configured as
```bash
triggercalib.sideband \
    --path <path to input file> \
    --tree <name of tree> \
    --binning <path to binning config> \
    --sideband <path to sideband config> \
    --particle <particle name> \
    --tis <list of TIS lines> \
    --tos <list of TOS lines> \
    --output <path of output file> 
```
Optional arguments also allow for implict multithreading (`--threads`), use of friends (`--friend-path` and `--friend-tree`), application of selection cuts (`--cut`) and per-event weights `--weight`.

### Fit-and-count and sWeights
Efficiencies using the fit-and-count and sweights methods can be evaluated using `triggercalib.fit_and_count` and `triggercalib.sweights`, respectively, configured generating fit models from a config as
```bash
triggercalib.fit_and_count OR triggercalib.sweight \
    --path <path to input file> \
    --tree <name of tree> \
    --binning <path to binning config> \
    --fit-description <path to fitter config> \
    --tis <list of TIS lines> \
    --tos <list of TOS lines> \
    --output <path of output file> 
```
or by reading these from a `ROOT.RooWorkspace` as
```bash
triggercalib.fit_and_count OR triggercalib.sweight \
    --path <path to input file> \
    --tree <name of tree> \
    --binning <path to binning config> \
    --workspace <(colon-separated) path to workspace file, name of workspace, name of observable, name of PDF> \
    --tis <list of TIS lines> \
    --tos <list of TOS lines> \
    --output <path of output file> 
```
Optional arguments also allow for implict multithreading and multithreaded fitting (`--threads`), use of friends (`--friend-path` and `--friend-tree`), application of selection cuts (`--cut`) and per-event weights `--weight`.
