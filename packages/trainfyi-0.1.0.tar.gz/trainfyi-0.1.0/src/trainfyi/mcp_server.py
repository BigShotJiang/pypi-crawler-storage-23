"""MCP server for trainfyi."""

from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from trainfyi.api import TrainFYI

mcp = FastMCP("trainfyi")


@mcp.tool()
def search_trainfyi(query: str) -> dict[str, Any]:
    """Search trainfyi.com for content matching the query."""
    with TrainFYI() as api:
        return api.search(query)
