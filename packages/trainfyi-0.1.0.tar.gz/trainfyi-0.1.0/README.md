# trainfyi

Railway stations and train routes API client — [trainfyi.com](https://trainfyi.com)

## Install

```bash
pip install trainfyi
```

## Quick Start

```python
from trainfyi.api import TrainFYI

with TrainFYI() as api:
    results = api.search("tokyo")
    print(results)
```

## License

MIT
