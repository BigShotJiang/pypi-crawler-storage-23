import threading
from pathlib import Path
from typing import Optional, List, Dict

from .manager import PersistConversationManager
from .config import ConversationManagerConfig


def _normalize_storage_path(raw_path: str) -> str:
    """将 storage_path 规范化为绝对路径，用作注册表 key。"""
    return str(Path(raw_path).expanduser().resolve())


class ConversationManagerSingleton:
    """按 storage_path 维度的对话管理器注册表。

    同一个规范化后的 storage_path 复用同一个 PersistConversationManager
    实例（保留缓存收益），不同 storage_path 的实例互相隔离。
    """

    _instances: Dict[str, PersistConversationManager] = {}
    _configs: Dict[str, ConversationManagerConfig] = {}
    _lock = threading.Lock()

    @classmethod
    def get_instance(
        cls, config: Optional[ConversationManagerConfig] = None
    ) -> PersistConversationManager:
        """获取对话管理器实例。

        按 config.storage_path（规范化后的绝对路径）查找/创建实例。
        若 config 为 None，则使用当前工作目录推导的默认配置。

        Args:
            config: 配置对象，如果为 None 则使用默认配置

        Returns:
            PersistConversationManager 实例
        """
        if config is None:
            config = cls._get_default_config()

        storage_key = _normalize_storage_path(config.storage_path)

        instance = cls._instances.get(storage_key)
        if instance is not None:
            return instance

        with cls._lock:
            instance = cls._instances.get(storage_key)
            if instance is not None:
                return instance

            cls._configs[storage_key] = config
            instance = PersistConversationManager(config)
            cls._instances[storage_key] = instance
            return instance

    @classmethod
    def reset_instance(
        cls,
        config: Optional[ConversationManagerConfig] = None,
        storage_path: Optional[str] = None,
    ):
        """重置实例，用于测试或配置更改时。

        Args:
            config: 新的配置对象。若提供，会立即创建新实例。
            storage_path: 仅重置指定 storage_path 对应的实例。
                          若为 None 则重置全部实例。
        """
        with cls._lock:
            if storage_path is not None:
                key = _normalize_storage_path(storage_path)
                cls._instances.pop(key, None)
                cls._configs.pop(key, None)
                if config is not None:
                    new_key = _normalize_storage_path(config.storage_path)
                    instance = PersistConversationManager(config)
                    cls._instances[new_key] = instance
                    cls._configs[new_key] = config
            else:
                cls._instances.clear()
                cls._configs.clear()
                if config is not None:
                    new_key = _normalize_storage_path(config.storage_path)
                    instance = PersistConversationManager(config)
                    cls._instances[new_key] = instance
                    cls._configs[new_key] = config

    @classmethod
    def _get_default_config(cls) -> ConversationManagerConfig:
        """获取默认配置（基于当前工作目录）。"""
        default_storage_path = str(Path.cwd() / ".auto-coder" / "conversations")
        return ConversationManagerConfig(
            storage_path=default_storage_path,
            max_cache_size=100,
            cache_ttl=300.0,
            lock_timeout=10.0,
            backup_enabled=True,
            backup_interval=3600.0,
            max_backups=10,
        )

    @classmethod
    def get_config(
        cls, storage_path: Optional[str] = None
    ) -> Optional[ConversationManagerConfig]:
        """获取指定 storage_path 对应的配置。

        Args:
            storage_path: 要查询的 storage_path。
                          若为 None 则按当前工作目录推导。

        Returns:
            对应的配置对象，如果未初始化则返回 None。
        """
        if storage_path is None:
            storage_path = str(Path.cwd() / ".auto-coder" / "conversations")
        key = _normalize_storage_path(storage_path)
        return cls._configs.get(key)


def get_conversation_manager(
    config: Optional[ConversationManagerConfig] = None,
) -> PersistConversationManager:
    """获取对话管理器实例。

    内部按 storage_path 维度复用实例：同一 storage_path 返回同一个
    PersistConversationManager，不同 storage_path 互相隔离。

    若未提供 config，则以当前工作目录推导默认 storage_path。

    Args:
        config: 可选的配置对象。同一 storage_path 只在首次创建时生效，
                后续调用返回已创建的实例。

    Returns:
        PersistConversationManager: 对话管理器实例

    Example:
        ```python
        # 使用默认配置（当前工作目录下的 .auto-coder/conversations）
        manager = get_conversation_manager()

        # 使用自定义 storage_path
        config = ConversationManagerConfig(
            storage_path="/path/to/my_conversations",
            max_cache_size=200,
            default_namespace="my_project"
        )
        manager = get_conversation_manager(config)

        # 创建对话
        conv_id = manager.create_conversation(
            name="测试对话",
            description="这是一个测试对话"
        )

        # 使用命名空间管理当前对话
        manager.set_current_conversation(conv_id, "my_project")
        current_id = manager.get_current_conversation_id("my_project")
        ```
    """
    return ConversationManagerSingleton.get_instance(config)


def reset_conversation_manager(
    config: Optional[ConversationManagerConfig] = None,
    storage_path: Optional[str] = None,
):
    """重置对话管理器实例。

    用于测试或需要更改配置时重置实例。

    Args:
        config: 新的配置对象，如果为 None 则不立即创建新实例
        storage_path: 仅重置指定 storage_path 的实例。
                      若为 None 则重置全部实例。

    Example:
        ```python
        # 重置全部实例
        reset_conversation_manager()

        # 重置并用新配置创建
        new_config = ConversationManagerConfig(storage_path="./new_path")
        reset_conversation_manager(new_config)

        # 仅重置某个 storage_path 的实例
        reset_conversation_manager(storage_path="/old/path/.auto-coder/conversations")
        ```
    """
    ConversationManagerSingleton.reset_instance(config, storage_path=storage_path)


def get_conversation_manager_config(
    storage_path: Optional[str] = None,
) -> Optional[ConversationManagerConfig]:
    """获取对话管理器使用的配置。

    Args:
        storage_path: 要查询的 storage_path。
                      若为 None 则按当前工作目录推导。

    Returns:
        当前配置对象，如果还未初始化则返回 None
    """
    return ConversationManagerSingleton.get_config(storage_path=storage_path)


def get_current_conversation_id_with_namespace(
    namespace: Optional[str] = None,
) -> Optional[str]:
    """
    获取指定命名空间的当前对话ID

    Args:
        namespace: 命名空间，None表示使用默认命名空间

    Returns:
        当前对话ID，如果未设置返回None

    Example:
        ```python
        # 获取默认命名空间的当前对话ID
        current_id = get_current_conversation_id_with_namespace()

        # 获取特定命名空间的当前对话ID
        project_id = get_current_conversation_id_with_namespace("my_project")
        ```
    """
    manager = get_conversation_manager()
    return manager.get_current_conversation_id(namespace)


def set_current_conversation_with_namespace(
    conversation_id: str, namespace: Optional[str] = None
) -> bool:
    """
    设置指定命名空间的当前对话

    Args:
        conversation_id: 对话ID
        namespace: 命名空间，None表示使用默认命名空间

    Returns:
        True if setting was successful

    Example:
        ```python
        # 设置默认命名空间的当前对话
        set_current_conversation_with_namespace("conv-123")

        # 设置特定命名空间的当前对话
        set_current_conversation_with_namespace("conv-456", "my_project")
        ```
    """
    manager = get_conversation_manager()
    return manager.set_current_conversation(conversation_id, namespace)


def list_conversation_namespaces() -> List[Optional[str]]:
    """
    列出所有已使用的命名空间

    Returns:
        命名空间列表，None 表示默认命名空间

    Example:
        ```python
        namespaces = list_conversation_namespaces()
        for ns in namespaces:
            if ns is None:
                print("默认命名空间")
            else:
                print(f"命名空间: {ns}")
        ```
    """
    manager = get_conversation_manager()
    return manager.list_namespaces()


def get_all_current_conversations_by_namespace() -> Dict[Optional[str], str]:
    """
    获取所有命名空间的当前对话ID

    Returns:
        命名空间到对话ID的映射

    Example:
        ```python
        all_current = get_all_current_conversations_by_namespace()
        for namespace, conv_id in all_current.items():
            ns_name = "默认" if namespace is None else namespace
            print(f"命名空间 '{ns_name}' 的当前对话: {conv_id}")
        ```
    """
    manager = get_conversation_manager()
    return manager.get_all_current_conversations()


def copy_conversation(
    source_conversation_id: str,
    new_name: Optional[str] = None,
    new_description: Optional[str] = None,
    new_conversation_id: Optional[str] = None,
    copy_messages: bool = True,
    copy_metadata: bool = True,
) -> str:
    """
    复制一个会话，生成新的会话ID

    Args:
        source_conversation_id: 源会话ID
        new_name: 新会话名称，如果为None则使用 "源会话名称 (副本)"
        new_description: 新会话描述，如果为None则复制源会话描述
        new_conversation_id: 可选的新会话ID，如果为None则自动生成
        copy_messages: 是否复制消息，默认True
        copy_metadata: 是否复制元数据，默认True

    Returns:
        新会话的ID

    Example:
        ```python
        # 复制会话，自动生成新ID
        new_id = copy_conversation("source-conv-123")

        # 复制会话，指定新名称和ID
        new_id = copy_conversation(
            "source-conv-123",
            new_name="我的会话副本",
            new_conversation_id="my-copy-001"
        )

        # 只复制会话元信息，不复制消息
        new_id = copy_conversation(
            "source-conv-123",
            copy_messages=False
        )
        ```
    """
    manager = get_conversation_manager()
    return manager.copy_conversation(
        source_conversation_id=source_conversation_id,
        new_name=new_name,
        new_description=new_description,
        new_conversation_id=new_conversation_id,
        copy_messages=copy_messages,
        copy_metadata=copy_metadata,
    )


# 便捷别名
get_manager = get_conversation_manager
reset_manager = reset_conversation_manager
get_manager_config = get_conversation_manager_config

# 命名空间相关的便捷别名
get_current_conv_id = get_current_conversation_id_with_namespace
set_current_conv = set_current_conversation_with_namespace
list_namespaces = list_conversation_namespaces
get_all_current_convs = get_all_current_conversations_by_namespace

# 会话操作便捷别名
copy_conv = copy_conversation
