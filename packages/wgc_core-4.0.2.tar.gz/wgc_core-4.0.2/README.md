# wgc-core

Core package for the WGC QA framework. Provides configuration management, logging, exception hierarchy, and file templates.

## Modules

### Config (`wgc_core.config`)

YAML-based configuration system with Python property access:

```python
from wgc_core.config import WGCConfig

# Access config properties
WGCConfig.application.folder        # "C:\Wargaming Game Center\"
WGCConfig.application.binary_name   # "wgc.exe"
WGCConfig.games.folder              # "C:\Games\"
WGCConfig.mocks.http_port           # 8888
WGCConfig.mocks.https_port          # 7771
WGCConfig.wgc_publisher             # "wargaming" | "qihoo" | "steam"
```

Config classes:
- `WGCConfig` — main config (publisher, branch, arch, ports, paths)
- `ApplicationConfig` — WGC binary paths, registry keys, protocols
- `GamesConfig` — game installation paths, metadata versions
- `MocksConfig` — mock server ports and settings
- `TestDataConfig` — test data source folders, dummy games
- `JiraConfig` — Jira integration settings
- `SteamConfig` / `FBConfig` / `GoogleConfig` / `MicrosoftConfig` — external auth configs

### Logger (`wgc_core.logger`)

JSON-configured logging with custom handlers:

```python
from wgc_core.logger import get_logger

log = get_logger(__name__)
log.info("WGC started successfully")
```

Custom handlers:
- `TestDependentRotatingFileHandler` — per-test log files
- `StepsToReproduceFileHandler` — structured reproduction steps

### Exceptions (`wgc_core.exceptions`)

Exception hierarchy for all framework error types:

```python
from wgc_core.exceptions import WGCException, WGCCrash, WGCSanityCheckException

# Base: WGCException
# ├── AnotherInstanceRunning
# ├── WebSocketConnectionClosed
# ├── WGCCrash / ApplicationCrash
# ├── WGCDownloadTimeout
# ├── WGCSanityCheckException
# ├── WGCRunningTimeoutException
# └── ...
```

### File Templates (`wgc_core.file_templates`)

XML/config template files for WGC configuration:

```python
from wgc_core.file_templates import get_file_template, get_file_template_path

# Get template content as string
content = get_file_template('preferences.xml')

# Get absolute path to template file
path = get_file_template_path('wgc_info.1.58.xml')
```

Includes templates for: `preferences.xml`, `game_info.xml`, `wgc_info.xml`, `service.xml`, game metadata, Steam VDF files, and more.

## Install

```bash
pip install wgc-core
```

## Dependencies

- `wgc-clippy` — low-level utilities
- `pyyaml`, `ruamel.yaml` — YAML parsing
- `packaging` — version comparison
