P5

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc
from sklearn.datasets import load_breast_cancer
import matplotlib.pyplot as plt, numpy as np
X, y = load_breast_cancer(return_X_y=True)
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, random_state=42)

model = LogisticRegression().fit(X_tr, y_tr)

y_pred = model.predict(X_te)
y_proba = model.predict_proba(X_te)[:, 1]

print("Confusion Matrix:\n", confusion_matrix(y_te, y_pred))
print("\nClassification Report:\n",
      classification_report(y_te, y_pred))

fpr, tpr, _ = roc_curve(y_te, y_proba)
roc_auc = auc(fpr, tpr)

plt.plot(fpr, tpr, label=f'AUC = {roc_auc:.2f}')
plt.plot([0,1],[0,1],'--')
plt.xlabel("FPR"); plt.ylabel("TPR"); plt.title("ROC Curve")
plt.legend(); plt.show()