P2


from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import load_iris
import pandas as pd

iris = load_iris()
X = iris.data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

kmeans = KMeans(n_clusters=3, init='k-means++', random_state=42, n_init='auto')
clusters = kmeans.fit_predict(X_scaled)

df = pd.DataFrame(X, columns=iris.feature_names)
df['Cluster'] = clusters

print("Cluster Count:\n", df['Cluster'].value_counts())

centers = scaler.inverse_transform(kmeans.cluster_centers_)
print("\nCluster Centers:\n", pd.DataFrame(centers, columns=iris.feature_names))