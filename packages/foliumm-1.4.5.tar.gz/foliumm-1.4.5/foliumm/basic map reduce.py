P8

from collections import defaultdict
text_data = [
    "big data is VERY big",
    "data science is fun",
    "big data WITH science"
]
mapped = [(w,1) for line in text_data for w in line.split()]
print("Mapper:", mapped)
shuffled = defaultdict(list)
for w,c in mapped: shuffled[w].append(c)
print("\nShuffled:", dict(shuffled))
reduced = {w: sum(c) for w,c in shuffled.items()}
print("\nFinal Word Count:")
for w,c in reduced.items(): print(f"{w} : {c}")