P4

from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np, matplotlib.pyplot as plt

X = np.random.rand(100,1) * 10
y = 2*X + np.random.rand(100,1)*2 + 50

X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)

model = LinearRegression().fit(X_tr, y_tr)
y_pred = model.predict(X_te)

print(f"Intercept={model.intercept_[0]:.2f}, Slope={model.coef_[0][0]:.2f}")
print(f"MSE={mean_squared_error(y_te,y_pred):.2f}, R2={r2_score(y_te,y_pred):.2f}")

plt.scatter(X_te, y_te)
plt.plot(X_te, y_pred)
plt.title("Linear Regression")
plt.xlabel("Study Hours")
plt.ylabel("Exam Score")
plt.show()