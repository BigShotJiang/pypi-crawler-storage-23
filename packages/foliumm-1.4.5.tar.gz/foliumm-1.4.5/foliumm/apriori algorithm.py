P3

import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules
from mlxtend.preprocessing import TransactionEncoder

data = [
    ['Milk','Onion','Nutmeg','Kidney Beans','Eggs','Yogurt'],
    ['Dill','Onion','Nutmeg','Kidney Beans','Eggs','Yogurt'],
    ['Milk','Unicorn','Corn','Kidney Beans','Yogurt'],
    ['Corn','Onion','Kidney Beans','Ice cream','Eggs'],
    ['Milk','Apple','Kidney Beans','Eggs']
]

df = pd.DataFrame(
    TransactionEncoder().fit(data).transform(data),
    columns=TransactionEncoder().fit(data).columns_
)

print("Encoded Data:\n", df.head())

freq = apriori(df, min_support=0.6, use_colnames=True)
print("\nFrequent Itemsets:\n", freq)

rules = association_rules(freq, metric="confidence", min_threshold=0.7)\
        .sort_values('lift', ascending=False)

print("\nAssociation Rules:\n",
      rules[['antecedents','consequents','support','confidence','lift']])

if not rules.empty:
    r = rules.iloc[0]
    print(f"\nIf {list(r['antecedents'])} → {list(r['consequents'])} | "
          f"Confidence={r['confidence']:.2f}, Lift={r['lift']:.2f}")