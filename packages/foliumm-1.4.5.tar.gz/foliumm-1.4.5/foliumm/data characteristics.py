P1

import pandas as pd, numpy as np, matplotlib.pyplot as plt, seaborn as sns

df = pd.DataFrame({
    'TransactionID': range(1000),
    'Age': np.random.randint(18, 70, 1000),
    'Income': np.random.normal(5000, 15000, 1000),
    'ProductCategory': np.random.choice(['Electronics','Books','Clothing','Food'], 1000),
    'PurchaseAmount': np.random.uniform(10, 500, 1000),
    'Region': np.random.choice(['A','B','C',None], 1000, p=[0.3,0.3,0.3,0.1])
})

print("\nData Overview:")
print(df.info())
print("\nDescriptive Statistics:\n", df.describe())

sns.histplot(df['Income'], kde=True)
plt.title('Income Distribution')
plt.show()

sns.heatmap(df.select_dtypes(np.number).corr(), annot=True, cmap='coolwarm', fmt='.2f')
plt.title('Correlation Matrix')
plt.show()