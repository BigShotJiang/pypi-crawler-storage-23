P10

import pandas as pd, matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

df = pd.DataFrame({
    'Hours_Studied':[2,4,6,8,10],
    'Attendance':[60,65,70,80,90],
    'Marks':[50,55,65,75,85]
})

X, y = df[['Hours_Studied','Attendance']], df['Marks']
model = LinearRegression().fit(X, y)
pred = model.predict(X)

print("Hours Coef:", round(model.coef_[0],2),
      "| Attendance Coef:", round(model.coef_[1],2),
      "| Intercept:", round(model.intercept_,2))

print("\nActual vs Predicted:")
for a,p in zip(y,pred): print(f"{a} → {p:.2f}")

plt.scatter(y, pred)
plt.plot(y, y)
plt.xlabel("Actual"); plt.ylabel("Predicted")
plt.title("Actual vs Predicted")
plt.show()