P6

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report
import pandas as pd

iris = load_iris()
X_tr, X_te, y_tr, y_te = train_test_split(
    iris.data, iris.target, test_size=0.2, random_state=42
)

params = {
    "max_depth": [2,3,4,5,None],
    "min_samples_split": [2,5,10],
    "min_samples_leaf": [1,2,4],
    "criterion": ["gini","entropy"]
}

grid = GridSearchCV(DecisionTreeClassifier(random_state=42),
                    params, cv=5, scoring="accuracy").fit(X_tr, y_tr)

print("Best Params:", grid.best_params_)
print("\nClassification Report:\n",
      classification_report(y_te, grid.best_estimator_.predict(X_te)))

imp = pd.DataFrame({
    "Feature": iris.feature_names,
    "Importance": grid.best_estimator_.feature_importances_
}).sort_values("Importance", ascending=False)

print("\nFeature Importance:\n", imp)