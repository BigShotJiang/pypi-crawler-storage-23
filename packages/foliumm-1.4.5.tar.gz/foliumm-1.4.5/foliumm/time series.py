P9

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.arima.model import ARIMA
dates = pd.date_range('2020-01-01', periods=365, freq='D')
data = pd.Series(100 + 0.05*np.arange(365) + 10*np.sin(2*np.pi*np.arange(365)/7)
                 + np.random.normal(0,5,365), index=dates)
print(f"ADF Test p-value: {adfuller(data)[1]:.4f}")
decomp = seasonal_decompose(data, model='additive', period=7)
fig, axes = plt.subplots(3, 2, figsize=(15,10))
data.plot(ax=axes[0,0], title='Original')
decomp.trend.plot(ax=axes[0,1], title='Trend')
decomp.seasonal.plot(ax=axes[1,0], title='Seasonal')
decomp.resid.plot(ax=axes[1,1], title='Residual')
plot_acf(data, lags=40, ax=axes[2,0])
plot_pacf(data, lags=40, ax=axes[2,1])
plt.tight_layout()
train, test = data[:-30], data[-30:]
model = ARIMA(train, order=(1,1,1)).fit()
pred = model.forecast(30)
print(f"RMSE: {np.sqrt(((test.values - pred.values)**2).mean()):.2f}")
plt.figure(figsize=(12,4))
plt.plot(train.index, train, label='Train')
plt.plot(test.index, test, label='Test')
plt.plot(pred.index, pred, label='Forecast')
plt.legend()
plt.show()