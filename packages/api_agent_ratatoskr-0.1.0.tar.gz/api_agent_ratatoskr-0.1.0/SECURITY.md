# Security Policy

## Supported Versions

Only the latest release of api-agent receives security updates.

| Version | Supported          |
| ------- | ------------------ |
| Latest  | Yes                |
| Older   | No                 |

## Scope

This policy covers the **api-agent** package itself. It does not cover third-party APIs that api-agent connects to, or vulnerabilities in upstream dependencies that should be reported to their respective maintainers.

## Reporting a Vulnerability

**Please do not open public issues for security vulnerabilities.**

### Preferred: GitHub Security Advisories

Report vulnerabilities through [GitHub Security Advisories](https://github.com/innago-property-management/ratatoskr/security/advisories/new). This allows private discussion and coordinated disclosure.

### Alternative: Email

Send reports to [security@innago.com](mailto:security@innago.com). Include:

- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

## Response Timeline

- **Acknowledgment**: Within 48 hours of report
- **Resolution target**: Within 90 days of acknowledgment
- **Disclosure**: Coordinated with the reporter after a fix is available

## Credit

Security researchers who responsibly disclose vulnerabilities will be credited in the release notes for the version containing the fix, unless they prefer to remain anonymous.
