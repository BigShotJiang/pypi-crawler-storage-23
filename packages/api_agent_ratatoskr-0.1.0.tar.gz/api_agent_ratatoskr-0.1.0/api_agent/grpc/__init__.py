"""gRPC protocol support — reflection-based service discovery and unary RPC execution."""
