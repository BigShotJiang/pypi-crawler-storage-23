"""GraphQL client."""

from .client import execute_query

__all__ = ["execute_query"]
