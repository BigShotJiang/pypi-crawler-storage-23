"""API Agent - MCP server for querying APIs in natural language."""

__version__ = "0.1.0"
