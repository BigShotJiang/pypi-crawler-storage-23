## Summary

<!-- What does this PR do and why? -->

## Changes

<!-- Bulleted list of changes -->

-

## Test Plan

<!-- How did you verify this works? -->

-

## Checklist

- [ ] Tests pass (`uv run pytest tests/ -v`)
- [ ] Linting passes (`uv run ruff check api_agent/`)
- [ ] Type checking passes (`uv run ty check`)
- [ ] Documentation updated (if applicable)
