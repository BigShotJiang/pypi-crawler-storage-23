"""Writers that convert clangir IR to various output formats."""
