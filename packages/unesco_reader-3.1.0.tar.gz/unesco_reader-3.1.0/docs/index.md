```{include} ../README.md
```

```{toctree}
:maxdepth: 1
:hidden:

changelog.md
contributing.md
conduct.md
autoapi/index
```