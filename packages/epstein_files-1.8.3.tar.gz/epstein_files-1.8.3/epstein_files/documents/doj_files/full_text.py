EFTA00009622_TEXT = """<REDACTED> s GJ Test.          7/19/2006

<REDACTED> dob          16 yrs

<REDACTED> - Loxahatchee

2005 <REDACTED>          9th grade

<REDACTED> was outside          asked to date <REDACTED>

1/10/19 <REDACTED>

~~talked in depth~~

met for first time the night before went to JE
11:30 ish 10
do you want to make $200

met my friend Jeff  bighouse

but you have to give massage 45 min + that's all you have to do get $200

<REDACTED> told <REDACTED> + <REDACTED> went to Bathroom
to argue
came back out <REDACTED> called Jeff on the phone.
1 assistant answered the pho...

Page 2
Jeff asst answered phone - <REDACTED> had someone to give massage Lady asked how old I was
she told the lady 18 + went to <REDACTED>

Its $200     didn't care what
<REDACTED> - Lady trying to verify 18 Yes
Graduated from <REDACTED>     Known <REDACTED> for a long time
& the next morning

<REDACTED> + another girl     - going to Mall he <REDACTED> didn't care

<REDACTED> asked dad for $     yeh sure fine ok

House in Palm Beach
all got out of car     gate at back door     security guard the saw us     the <REDACTED> asked us where...
Page 3

<REDACTED> said Jeffrey
Went to kitchen     waited 15 min

JE + asst     walked in back door

shook hands     met both JE asst.
(A) JE     chose gonna go first

JE said how about you
<REDACTED>     upstairs     "asst lady"

walked me up there stripping out all this picture

She pulled out massage table me     front of couch     blanket over table     opened drawer     whole bunch of lotions     + pick some out
She told me keep bra + panties on + get undress

No <REDACTED>     told her I thought a massage keep your clothing

Page 4

stay in the room
I came in the room     HE + shook hands
Came back in the room

JE:     old     50ish

initially     guy golfy     khaki pants pullover

t-shirt + jeans     thong     bra

hesitant     thinking what's going on. I didn't care cause I wanted $200

He laid on massage table     He said grab any 3 lotions

Started to give him

What M.S.     did you go to told     him she was 16 Not     do you like to do     small talk <REDACTED>

Sat on table     15-20 minute conversation     another house in NY

Page 5

He asked if I wanted to make an extra $300
Straddle him

massage over -
but if you're not comfortable giving a massage can I     <REDACTED>     on you     ~~anything~~
<REDACTED>     said ok
JE left + came ba

<REDACTED>     kind of like a <REDACTED>
grabbed that + layed down back on table     ~~old~~ ~~old~~ hands

Give me a     massage on chest use the <REDACTED>     10 minutes or so ( after     a couple ~~of~~ minutes ( on <REDACTED>
(A) <REDACTED> said if he did that he would have to pay her extra money if he >
Page 6

<REDACTED>     not she would have to didn't     tell her     ~~get~~ ~~over~~ do her clothes at He <REDACTED>     you get paid

<REDACTED>

Yes     Saw <REDACTED>

He opened wallet     got the   $200

He told her to write Name + #

after that left the room

I didn't see him <REDACTED>

I was scared to tell

<REDACTED>     her body not his body
Went down by herself    got 1st  No didn't do anything  but <REDACTED>  $200 ~~too~~

Page 7
I figure it was probably because she brought me

What happened     I got $300 I was excited

What did you have to do with him
If you do this you get that
Laughing ~~in~~     Thanks for fully me I was going to ~~much~~ ~~go~~ ~~many~~ Oh sorry.
Didn't plan it

If you ever need money
Oh yeh     - everybody

I did not ever go back to house

at school my best friend I told her if you ever want to make 300.-o massage Told <REDACTED>     <REDACTED>

Page 8
<REDACTED>     telling everybody I confronted her     altercation get into a fight <REDACTED>

Spreading rumors about me Let me see in your purse you don't have to lie Stefand I worked at <REDACTED>

I didn't think it was her business and     why would tell on myself

You don't have to lie I knew what happen
Everything came out

<REDACTED>     then I didn't want to tell them what had happened,

I <REDACTED>

<REDACTED> Family Setty a lot problems

No     the only <REDACTED>     sometimes
Page 9

<REDACTED>     Have you ever da[ting] <REDACTED> Survey -     Yeh
<REDACTED>     not anymore
14 birthday     my dad
I did <REDACTED>     lots of time

$250,000     its a joke
tall skinny     dark hair
Page 10
""".strip()
