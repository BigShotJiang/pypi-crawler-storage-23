"""
Functions that build rich Text links.
"""
from rich.text import Text

from epstein_files.util.constant.strings import ARCHIVE_LINK_COLOR

SUBSTACK_POST_LINK_STYLE = 'bright_cyan'


def link_markup(
    url: str,
    link_text: str = '',
    style: str | None = ARCHIVE_LINK_COLOR,
    underline: bool = True
) -> str:
    link_text = link_text or url.removeprefix('https://')
    style = ((style or '') + (' underline' if underline else '')).strip()
    return (f"[{style}][link={url}]{link_text}[/link][/{style}]")


def link_text_obj(url: str, link_text: str = '', style: str = ARCHIVE_LINK_COLOR) -> Text:
    return Text.from_markup(link_markup(url, link_text, style))


def parenthesize(msg: str | Text, parentheses_style: str = '') -> Text:
    txt = Text(msg) if isinstance(msg, str) else msg
    return Text('(', style=parentheses_style).append(txt).append(')')
