"""Capability system for the Snippbot device agent.

Each capability represents a specific type of operation the device can perform.
Capabilities are discovered at startup and reported to the daemon.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, ClassVar

logger = logging.getLogger(__name__)


@dataclass
class CapabilityResult:
    """Result returned by a capability execution."""

    success: bool
    output: str = ""
    error: str = ""
    exit_code: int = 0
    duration: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "output": self.output,
            "error": self.error,
            "exit_code": self.exit_code,
            "duration": self.duration,
            "metadata": self.metadata,
        }


class BaseCapability(ABC):
    """Abstract base class for device capabilities.

    Subclasses must define ``name`` and ``description`` and implement
    ``execute`` and ``is_available``.
    """

    name: ClassVar[str] = ""
    description: ClassVar[str] = ""

    @abstractmethod
    async def execute(self, action: str, params: dict[str, Any]) -> CapabilityResult:
        """Execute an action within this capability.

        Args:
            action: The specific operation to perform (e.g. "run" for bash).
            params: Parameters for the operation.

        Returns:
            A CapabilityResult describing the outcome.
        """
        ...

    @abstractmethod
    def is_available(self) -> bool:
        """Check whether this capability is usable on the current machine."""
        ...

    def get_metadata(self) -> dict[str, Any]:
        """Return metadata describing this capability for the daemon."""
        return {
            "name": self.name,
            "description": self.description,
            "available": self.is_available(),
        }


class CapabilityRegistry:
    """Registry of all known capabilities.

    Capabilities are registered by name and can be looked up for dispatch.
    """

    def __init__(self) -> None:
        self._capabilities: dict[str, BaseCapability] = {}

    def register(self, capability: BaseCapability) -> None:
        """Register a capability instance."""
        if not capability.name:
            raise ValueError("Capability must have a non-empty name")
        if capability.name in self._capabilities:
            logger.warning("Overwriting existing capability: %s", capability.name)
        self._capabilities[capability.name] = capability
        logger.debug("Registered capability: %s", capability.name)

    def get(self, name: str) -> BaseCapability | None:
        """Look up a capability by name."""
        return self._capabilities.get(name)

    def list_available(self) -> list[BaseCapability]:
        """Return all capabilities that report themselves as available."""
        return [cap for cap in self._capabilities.values() if cap.is_available()]

    def list_all(self) -> list[BaseCapability]:
        """Return all registered capabilities regardless of availability."""
        return list(self._capabilities.values())

    def names(self) -> list[str]:
        """Return the names of all registered capabilities."""
        return list(self._capabilities.keys())

    async def execute(self, name: str, action: str, params: dict[str, Any]) -> CapabilityResult:
        """Look up and execute a capability action.

        Returns an error result if the capability is not found or unavailable.
        """
        cap = self._capabilities.get(name)
        if cap is None:
            return CapabilityResult(
                success=False,
                error=f"Unknown capability: {name}",
                exit_code=1,
            )
        if not cap.is_available():
            return CapabilityResult(
                success=False,
                error=f"Capability not available: {name}",
                exit_code=1,
            )
        return await cap.execute(action, params)


def create_default_registry(
    allowed_paths: list[str] | None = None,
    blocked_env_vars: list[str] | None = None,
) -> CapabilityRegistry:
    """Create a registry pre-populated with the standard capabilities."""
    from snippbot_device.capabilities.bash import BashCapability
    from snippbot_device.capabilities.filesystem import FilesystemCapability
    from snippbot_device.capabilities.system_info import SystemInfoCapability

    registry = CapabilityRegistry()
    registry.register(BashCapability(blocked_env_vars=blocked_env_vars or []))
    registry.register(FilesystemCapability(allowed_paths=allowed_paths or []))
    registry.register(SystemInfoCapability())
    return registry
