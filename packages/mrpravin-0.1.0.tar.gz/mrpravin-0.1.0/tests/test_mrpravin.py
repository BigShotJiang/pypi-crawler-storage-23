"""
mrpravin – Phase 1 test suite
Tests cover: profiler · cleaner · encoder · scaler ·
             pravinDA · pravinDS · pravinML (all methods)
"""
import os, sys, tempfile, warnings
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import pytest

import mrpravin as mr
from mrpravin import MrPravinConfig
from mrpravin.core.profiler import infer_column_types
from mrpravin.core.cleaner  import Cleaner
from mrpravin.core.encoder  import Encoder
from mrpravin.core.scaler   import Scaler
from mrpravin.ml            import pravinML, InputSchema, ValidationReport


# ─────────────────────────────────────────────────────────────────────────────
# Shared fixtures
# ─────────────────────────────────────────────────────────────────────────────

@pytest.fixture
def clf_df():
    np.random.seed(42)
    n = 300
    X1 = np.random.randn(n)
    X2 = np.random.randn(n)
    y  = (X1 + X2 > 0).astype(int)
    return pd.DataFrame({"f1": X1, "f2": X2, "target": y})


@pytest.fixture
def reg_df():
    np.random.seed(0)
    n = 300
    X = np.random.randn(n, 3)
    y = X[:, 0] * 2 + X[:, 1] - X[:, 2] + np.random.randn(n) * 0.1
    df = pd.DataFrame(X, columns=["x1", "x2", "x3"])
    df["y"] = y
    return df


@pytest.fixture
def fast_cfg():
    return MrPravinConfig(
        verbose=False,
        use_xgboost=False,
        use_lightgbm=False,
        n_iter_search=3,
        cv_folds=2,
        random_seed=42,
    )


@pytest.fixture
def trained_clf(clf_df, fast_cfg):
    return mr.pravinDS(clf_df, target="target", cfg=fast_cfg, save_model=None)


@pytest.fixture
def trained_reg(reg_df, fast_cfg):
    return mr.pravinDS(reg_df, target="y", cfg=fast_cfg, save_model=None)


# ─────────────────────────────────────────────────────────────────────────────
# 1. Profiler
# ─────────────────────────────────────────────────────────────────────────────

class TestProfiler:

    def test_numeric(self):
        df = pd.DataFrame({"age": list(range(50)) * 4})
        assert infer_column_types(df)["age"] == "numeric"

    def test_categorical(self):
        df = pd.DataFrame({"color": ["red", "blue", "green", "red"] * 30})
        assert infer_column_types(df)["color"] == "categorical"

    def test_datetime(self):
        dates = ["2021-01-01", "2022-06-15", "2020-03-10",
                 "2023-11-30", "2019-07-04"]
        df = pd.DataFrame({"signup": dates * 20})
        assert infer_column_types(df)["signup"] == "datetime"

    def test_boolean(self):
        df = pd.DataFrame({"flag": [True, False, True, False] * 10})
        assert infer_column_types(df)["flag"] == "boolean"

    def test_id_string(self):
        df = pd.DataFrame({"user_id": [f"u{i}" for i in range(100)]})
        assert infer_column_types(df)["user_id"] == "id"

    def test_float_never_id(self):
        # Float feature columns must never be classified as ID
        df = pd.DataFrame({"salary": np.random.rand(100) * 100_000})
        assert infer_column_types(df)["salary"] == "numeric"


# ─────────────────────────────────────────────────────────────────────────────
# 2. Cleaner
# ─────────────────────────────────────────────────────────────────────────────

class TestCleaner:

    def _clean(self, df, type_map):
        cfg = MrPravinConfig(); rpt = {}
        return Cleaner(cfg).fit_transform(df, type_map, rpt), rpt

    def test_removes_duplicates(self):
        df = pd.DataFrame({"a": [1,2,2,3], "b": ["x","y","y","z"]})
        out, rpt = self._clean(df, {"a":"numeric","b":"categorical"})
        assert rpt["duplicates_removed"] == 1
        assert len(out) == 3

    def test_fills_numeric_missing(self):
        df = pd.DataFrame({"v": [1.0, 2.0, np.nan, 4.0]})
        out, _ = self._clean(df, {"v": "numeric"})
        assert out["v"].isna().sum() == 0

    def test_fills_categorical_missing(self):
        df = pd.DataFrame({"c": ["a","b","a",None,"b"]})
        out, _ = self._clean(df, {"c": "categorical"})
        assert out["c"].isna().sum() == 0

    def test_drops_high_missing_column(self):
        n = 100
        df = pd.DataFrame({
            "a": np.random.randn(n),
            "b": [np.nan]*80 + list(np.random.randn(20))
        })
        out, rpt = self._clean(df, {"a":"numeric","b":"numeric"})
        assert "b" not in out.columns
        assert "b" in rpt["columns_dropped_high_missing"]

    def test_winsorizes_outliers(self):
        df = pd.DataFrame({"x": [1,2,3,4,5,1000]})
        out, _ = self._clean(df, {"x": "numeric"})
        assert out["x"].max() < 1000

    def test_cleans_text(self):
        df = pd.DataFrame({"name": ["  Alice  ", "BOB", "charlie!"]})
        out, _ = self._clean(df, {"name": "categorical"})
        assert out["name"].iloc[0] == "alice"
        assert out["name"].iloc[1] == "bob"


# ─────────────────────────────────────────────────────────────────────────────
# 3. Encoder
# ─────────────────────────────────────────────────────────────────────────────

class TestEncoder:

    def test_onehot_low_cardinality(self):
        df = pd.DataFrame({"c": ["a","b","c"] * 10})
        enc = Encoder(MrPravinConfig(low_cardinality_threshold=15))
        enc.fit(df, {"c":"categorical"}, report={})
        out = enc.transform(df)
        assert "c" not in out.columns
        assert any("c" in col for col in out.columns)

    def test_drops_id_column(self):
        df = pd.DataFrame({
            "id":  [f"x{i}" for i in range(100)],
            "val": np.random.randn(100),
        })
        enc = Encoder(MrPravinConfig())
        enc.fit(df, {"id":"id","val":"numeric"}, report={})
        out = enc.transform(df)
        assert "id" not in out.columns
        assert "val" in out.columns

    def test_frequency_medium_cardinality(self):
        df = pd.DataFrame({"cat": [f"c{i%30}" for i in range(300)]})
        cfg = MrPravinConfig(low_cardinality_threshold=15, medium_cardinality_threshold=50)
        enc = Encoder(cfg)
        enc.fit(df, {"cat":"high_cardinality"}, report={})
        out = enc.transform(df)
        assert out["cat"].dtype in [float, np.float64]

    def test_datetime_generates_features(self):
        df = pd.DataFrame({
            "date": pd.to_datetime(["2021-01-01","2022-06-15","2020-03-10"]*10)
        })
        enc = Encoder(MrPravinConfig())
        enc.fit(df, {"date":"datetime"}, report={})
        out = enc.transform(df)
        assert "date" not in out.columns
        assert "date__year" in out.columns
        assert "date__month" in out.columns


# ─────────────────────────────────────────────────────────────────────────────
# 4. Scaler
# ─────────────────────────────────────────────────────────────────────────────

class TestScaler:

    def test_standard_scaler(self):
        df = pd.DataFrame({"a": np.random.randn(200)})
        out = Scaler(MrPravinConfig(scaler="standard")).fit_transform(df)
        assert abs(out["a"].mean()) < 0.15
        assert abs(out["a"].std() - 1.0) < 0.15

    def test_auto_picks_standard_for_low_skew(self):
        from sklearn.preprocessing import StandardScaler
        df = pd.DataFrame({"x": np.random.randn(300)})
        s  = Scaler(MrPravinConfig(scaler="auto"))
        s.fit(df)
        assert isinstance(s._scaler, StandardScaler)

    def test_auto_picks_robust_for_high_skew(self):
        from sklearn.preprocessing import RobustScaler
        # Exponential distribution → very high positive skew
        df = pd.DataFrame({"x": np.random.exponential(scale=1, size=1000)})
        s  = Scaler(MrPravinConfig(scaler="auto"))
        s.fit(df)
        assert isinstance(s._scaler, RobustScaler)


# ─────────────────────────────────────────────────────────────────────────────
# 5. pravinDA end-to-end
# ─────────────────────────────────────────────────────────────────────────────

class TestPravinDA:

    def _make_df(self):
        np.random.seed(7); n = 120
        df = pd.DataFrame({
            "age":    np.random.randint(18, 65, n).astype(float),
            "salary": np.random.randint(30_000, 100_000, n).astype(float),
            "city":   np.random.choice(["NY","LA","SF","CH"], n),
            "label":  np.random.randint(0, 2, n),
        })
        df.loc[0, "age"] = np.nan
        df.loc[1, "salary"] = 9_999_999
        return pd.concat([df, df.iloc[:3]], ignore_index=True)

    def test_returns_dataframe(self):
        cfg = MrPravinConfig(verbose=False)
        out = mr.pravinDA(self._make_df(), cfg=cfg, target="label")
        assert isinstance(out, pd.DataFrame)
        assert len(out) > 0

    def test_return_report(self):
        cfg = MrPravinConfig(verbose=False)
        df, report = mr.pravinDA(self._make_df(), cfg=cfg,
                                  target="label", return_report=True)
        assert isinstance(report, dict)
        assert report["duplicates_removed"] == 3
        assert "rows_before" in report
        assert "encodings_applied" in report

    def test_dry_run_unchanged(self):
        orig = self._make_df()
        cfg  = MrPravinConfig(verbose=False)
        out  = mr.pravinDA(orig.copy(), cfg=cfg, dry_run=True)
        assert set(out.columns) == set(orig.columns)

    def test_csv_file(self, tmp_path):
        p = tmp_path / "test.csv"
        df = pd.DataFrame({"x": [1,2,3], "y": ["a","b","a"]})
        df.to_csv(p, index=False)
        out = mr.pravinDA(str(p), cfg=MrPravinConfig(verbose=False))
        assert isinstance(out, pd.DataFrame)

    def test_export_json_report(self, tmp_path):
        import json
        p   = str(tmp_path / "report.json")
        cfg = MrPravinConfig(verbose=False)
        mr.pravinDA(self._make_df(), cfg=cfg, export_report=p)
        data = json.loads(open(p).read())
        assert "rows_before" in data

    def test_export_html_report(self, tmp_path):
        p   = str(tmp_path / "report.html")
        cfg = MrPravinConfig(verbose=False)
        mr.pravinDA(self._make_df(), cfg=cfg, export_report=p)
        html = open(p).read()
        assert "<html>" in html and "mrpravin" in html


# ─────────────────────────────────────────────────────────────────────────────
# 6. pravinDS end-to-end
# ─────────────────────────────────────────────────────────────────────────────

class TestPravinDS:

    def test_returns_pravinML_instance(self, trained_clf):
        assert isinstance(trained_clf, pravinML)

    def test_classification_accuracy(self, trained_clf):
        assert trained_clf.metrics["accuracy"] > 0.6

    def test_regression_r2(self, trained_reg):
        assert trained_reg.metrics["r2"] > 0.5

    def test_return_metrics(self, clf_df, fast_cfg):
        model, metrics = mr.pravinDS(
            clf_df, target="target", cfg=fast_cfg,
            return_metrics=True, save_model=None,
        )
        assert isinstance(metrics, dict)
        assert "best_model_name" in metrics
        assert "cv_score" in metrics

    def test_problem_type_detected(self, trained_clf, trained_reg):
        assert "classification" in trained_clf.problem_type
        assert trained_reg.problem_type == "regression"

    def test_model_name_set(self, trained_clf):
        assert isinstance(trained_clf.model_name, str)
        assert len(trained_clf.model_name) > 0

    def test_feature_names_set(self, trained_clf):
        assert isinstance(trained_clf.feature_names, list)
        assert len(trained_clf.feature_names) > 0

    def test_missing_target_raises(self, clf_df, fast_cfg):
        with pytest.raises(ValueError, match="not found"):
            mr.pravinDS(clf_df, target="nonexistent", cfg=fast_cfg, save_model=None)


# ─────────────────────────────────────────────────────────────────────────────
# 7. pravinML – predict
# ─────────────────────────────────────────────────────────────────────────────

class TestPravinMLPredict:

    def test_predict_returns_array(self, trained_clf, clf_df):
        X = clf_df.drop(columns=["target"])
        preds = trained_clf.predict(X)
        assert len(preds) == len(X)

    def test_predict_shape_regression(self, trained_reg, reg_df):
        X = reg_df.drop(columns=["y"])
        preds = trained_reg.predict(X)
        assert preds.shape == (len(X),)

    def test_predict_proba_classification(self, trained_clf, clf_df):
        X = clf_df.drop(columns=["target"]).head(20)
        proba = trained_clf.predict_proba(X)
        assert proba.shape[0] == 20
        assert proba.shape[1] == 2
        assert np.allclose(proba.sum(axis=1), 1.0, atol=1e-5)

    def test_predict_proba_not_available_regression(self, trained_reg, reg_df):
        model = trained_reg
        # LinearRegression has no predict_proba
        if not hasattr(model._model, "predict_proba"):
            with pytest.raises(AttributeError):
                model.predict_proba(reg_df.drop(columns=["y"]))

    def test_predict_from_file(self, trained_clf, clf_df, tmp_path):
        p = tmp_path / "new.csv"
        clf_df.drop(columns=["target"]).to_csv(p, index=False)
        preds = trained_clf.predict(str(p))
        assert len(preds) == len(clf_df)


# ─────────────────────────────────────────────────────────────────────────────
# 8. pravinML – validate
# ─────────────────────────────────────────────────────────────────────────────

class TestPravinMLValidate:

    def test_valid_data_passes(self, trained_clf, clf_df):
        X = clf_df.drop(columns=["target"])
        report = trained_clf.validate(X)
        assert isinstance(report, ValidationReport)
        assert report.is_valid
        assert report.errors == []

    def test_missing_column_is_error(self, trained_clf, clf_df):
        X = clf_df.drop(columns=["target", "f1"])
        report = trained_clf.validate(X)
        assert not report.is_valid
        assert any("f1" in e for e in report.errors)

    def test_extra_column_is_warning(self, trained_clf, clf_df):
        X = clf_df.drop(columns=["target"]).copy()
        X["extra_col"] = 99
        report = trained_clf.validate(X)
        assert report.is_valid               # still valid (extra ignored)
        assert "extra_col" in report.extra_columns

    def test_drift_triggers_warning(self, trained_clf, clf_df):
        X = clf_df.drop(columns=["target"]).copy()
        X["f1"] = X["f1"] * 1000            # massively out of training range
        report = trained_clf.validate(X)
        assert len(report.drift_warnings) > 0

    def test_predict_blocked_on_missing_column(self, trained_clf, clf_df):
        X = clf_df.drop(columns=["target", "f1"])
        with pytest.raises(ValueError, match="schema errors"):
            trained_clf.predict(X, validate=True)

    def test_validation_report_summary_string(self, trained_clf, clf_df):
        X = clf_df.drop(columns=["target"])
        report = trained_clf.validate(X)
        s = report.summary()
        assert "ValidationReport" in s


# ─────────────────────────────────────────────────────────────────────────────
# 9. pravinML – evaluate
# ─────────────────────────────────────────────────────────────────────────────

class TestPravinMLEvaluate:

    def test_evaluate_classification(self, trained_clf, clf_df):
        X = clf_df.drop(columns=["target"])
        y = clf_df["target"]
        m = trained_clf.evaluate(X, y)
        assert "accuracy" in m
        assert 0.0 <= m["accuracy"] <= 1.0

    def test_evaluate_regression(self, trained_reg, reg_df):
        X = reg_df.drop(columns=["y"])
        y = reg_df["y"]
        m = trained_reg.evaluate(X, y)
        assert "r2" in m
        assert "rmse" in m


# ─────────────────────────────────────────────────────────────────────────────
# 10. pravinML – explain
# ─────────────────────────────────────────────────────────────────────────────

class TestPravinMLExplain:

    def test_explain_returns_dict(self, trained_clf):
        imp = trained_clf.explain()
        # LogisticRegression has coef_, tree models have feature_importances_
        assert isinstance(imp, dict)

    def test_explain_top_n(self, trained_clf):
        imp = trained_clf.explain(top_n=1)
        if imp:   # may be empty for models without importance
            assert len(imp) == 1

    def test_explain_sums_to_100(self, trained_clf):
        imp = trained_clf.explain()
        if imp:
            total = sum(imp.values())
            assert abs(total - 100.0) < 1.0

    def test_explain_sorted_descending(self, trained_clf):
        imp = trained_clf.explain()
        if len(imp) > 1:
            vals = list(imp.values())
            assert vals == sorted(vals, reverse=True)


# ─────────────────────────────────────────────────────────────────────────────
# 11. pravinML – benchmark
# ─────────────────────────────────────────────────────────────────────────────

class TestPravinMLBenchmark:

    def test_benchmark_returns_dict(self, trained_clf, clf_df):
        X   = clf_df.drop(columns=["target"]).head(50)
        res = trained_clf.benchmark(X, n_runs=5)
        assert isinstance(res, dict)
        for key in ("p50_ms", "p95_ms", "p99_ms", "mean_ms", "throughput_rows_per_sec"):
            assert key in res
            assert res[key] > 0

    def test_benchmark_batch_size(self, trained_clf, clf_df):
        X   = clf_df.drop(columns=["target"])
        res = trained_clf.benchmark(X, n_runs=5, batch_size=10)
        assert res["batch_rows"] == 10


# ─────────────────────────────────────────────────────────────────────────────
# 12. pravinML – summary (smoke test only – checks it runs without error)
# ─────────────────────────────────────────────────────────────────────────────

class TestPravinMLSummary:

    def test_summary_runs(self, trained_clf, capsys):
        trained_clf.summary()
        captured = capsys.readouterr()
        assert "Model Card" in captured.out
        assert trained_clf.model_name in captured.out

    def test_repr(self, trained_clf):
        r = repr(trained_clf)
        assert "pravinML" in r
        assert trained_clf.model_name in r


# ─────────────────────────────────────────────────────────────────────────────
# 13. pravinML – save / load
# ─────────────────────────────────────────────────────────────────────────────

class TestPravinMLPersistence:

    def test_save_creates_file(self, trained_clf, tmp_path):
        p = str(tmp_path / "model.pkl")
        trained_clf.save(p)
        assert os.path.exists(p)
        assert os.path.getsize(p) > 0

    def test_load_returns_pravinML(self, trained_clf, tmp_path):
        p = str(tmp_path / "model.pkl")
        trained_clf.save(p)
        loaded = mr.pravinML.load(p)
        assert isinstance(loaded, pravinML)

    def test_loaded_model_predicts(self, trained_clf, clf_df, tmp_path):
        p = str(tmp_path / "model.pkl")
        trained_clf.save(p)
        loaded = mr.pravinML.load(p)
        X = clf_df.drop(columns=["target"]).head(10)
        preds = loaded.predict(X)
        assert len(preds) == 10

    def test_save_load_preserves_metrics(self, trained_clf, tmp_path):
        p = str(tmp_path / "model.pkl")
        trained_clf.save(p)
        loaded = mr.pravinML.load(p)
        assert loaded.metrics["accuracy"] == trained_clf.metrics["accuracy"]

    def test_save_load_preserves_schema(self, trained_clf, tmp_path):
        p = str(tmp_path / "model.pkl")
        trained_clf.save(p)
        loaded = mr.pravinML.load(p)
        assert loaded.schema.feature_names == trained_clf.schema.feature_names


# ─────────────────────────────────────────────────────────────────────────────
# 14. InputSchema
# ─────────────────────────────────────────────────────────────────────────────

class TestInputSchema:

    def test_from_dataframe(self):
        df = pd.DataFrame({"a": [1.0,2.0,3.0], "b": ["x","y","x"]})
        s  = InputSchema.from_dataframe(df, "regression", "target")
        assert s.feature_names == ["a","b"]
        assert "min" in s.feature_stats["a"]
        assert s.training_rows == 3

    def test_to_dict(self):
        df = pd.DataFrame({"a": [1.0,2.0]})
        s  = InputSchema.from_dataframe(df, "regression", "y")
        d  = s.to_dict()
        assert "feature_names" in d
        assert "training_rows" in d


# ─────────────────────────────────────────────────────────────────────────────
# 15. Config
# ─────────────────────────────────────────────────────────────────────────────

class TestConfig:

    def test_json_roundtrip(self, tmp_path):
        cfg  = MrPravinConfig(random_seed=99, outlier_method="mad")
        p    = str(tmp_path / "cfg.json")
        cfg.to_json(p)
        cfg2 = MrPravinConfig.from_json(p)
        assert cfg2.random_seed == 99
        assert cfg2.outlier_method == "mad"

    def test_all_defaults_valid(self):
        from mrpravin.config import DEFAULT_CONFIG
        assert DEFAULT_CONFIG.random_seed == 42
        assert DEFAULT_CONFIG.cv_folds == 5
