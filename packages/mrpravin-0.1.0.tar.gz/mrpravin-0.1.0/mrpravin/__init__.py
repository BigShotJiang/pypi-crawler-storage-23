"""
mrpravin
════════
One-line Data Analyst + AutoML library for tabular datasets.

Author  : Pravin MR
Email   : mrpravin000@gmail.com
GitHub  : https://github.com/mr-pravin
Website : https://mrpravin000.vercel.app/
License : MIT

Usage
─────
    import mrpravin as mr

    df    = mr.pravinDA("data.csv")
    model = mr.pravinDS(df, target="label")
    model.summary()
    model.predict(X_new)
    model.explain()
    model.save("model.pkl")
    model = mr.pravinML.load("model.pkl")
"""

import logging

logging.basicConfig(
    format="%(levelname)s  [mrpravin]  %(message)s",
    level=logging.INFO,
)

from mrpravin.ml import pravinML
from mrpravin.pipeline import pravinDA, pravinDS
from mrpravin.config import MrPravinConfig, DEFAULT_CONFIG

__all__ = [
    "pravinDA",
    "pravinDS",
    "pravinML",
    "MrPravinConfig",
    "DEFAULT_CONFIG",
]

__version__   = "0.1.0"
__author__    = "Pravin MR"
__email__     = "mrpravin000@gmail.com"
__github__    = "https://github.com/mr-pravin"
__website__   = "https://mrpravin000.vercel.app/"
__license__   = "MIT"
__copyright__ = "Copyright (c) 2026 Pravin MR"