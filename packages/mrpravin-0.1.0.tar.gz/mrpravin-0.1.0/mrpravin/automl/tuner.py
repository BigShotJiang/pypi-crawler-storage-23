"""
mrpravin.automl.tuner
─────────────────────
Hyperparameter search using RandomizedSearchCV (default) or
Bayesian optimisation via scikit-optimize (optional).
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, Tuple

import numpy as np
from sklearn.model_selection import RandomizedSearchCV

from mrpravin.config import MrPravinConfig

log = logging.getLogger("mrpravin.tuner")

# Per-estimator search spaces
_SEARCH_SPACES: Dict[str, Dict[str, Any]] = {
    "RandomForest": {
        "n_estimators": [50, 100, 200, 300],
        "max_depth": [None, 5, 10, 20],
        "min_samples_split": [2, 5, 10],
        "max_features": ["sqrt", "log2", None],
    },
    "GradientBoosting": {
        "n_estimators": [50, 100, 200],
        "learning_rate": [0.01, 0.05, 0.1, 0.2],
        "max_depth": [3, 4, 5, 7],
        "subsample": [0.7, 0.8, 1.0],
    },
    "XGBoost": {
        "n_estimators": [50, 100, 200],
        "learning_rate": [0.01, 0.05, 0.1, 0.2],
        "max_depth": [3, 5, 7],
        "subsample": [0.7, 0.8, 1.0],
        "colsample_bytree": [0.7, 0.8, 1.0],
    },
    "LightGBM": {
        "n_estimators": [50, 100, 200],
        "learning_rate": [0.01, 0.05, 0.1],
        "num_leaves": [31, 63, 127],
        "subsample": [0.7, 0.8, 1.0],
    },
    "LogisticRegression": {
        "C": [0.001, 0.01, 0.1, 1, 10, 100],
        "penalty": ["l2"],
    },
    "LinearRegression": {},   # no hyperparameters to tune
}


def tune(
    estimator,
    name: str,
    X,
    y,
    scoring: str,
    cfg: MrPravinConfig,
    cv: int = 5,
) -> Tuple[Any, float]:
    """
    Run hyperparameter search on `estimator`.
    Returns (best_estimator, best_score).
    """
    param_grid = _SEARCH_SPACES.get(name, {})

    if not param_grid:
        log.info("No param grid for %s – fitting directly.", name)
        estimator.fit(X, y)
        from sklearn.model_selection import cross_val_score
        scores = cross_val_score(estimator, X, y, cv=cv, scoring=scoring, n_jobs=-1)
        return estimator, float(scores.mean())

    n_iter = min(cfg.n_iter_search, len(param_grid) * 4)

    search = RandomizedSearchCV(
        estimator=estimator,
        param_distributions=param_grid,
        n_iter=n_iter,
        cv=cv,
        scoring=scoring,
        n_jobs=-1,
        random_state=cfg.random_seed,
        refit=True,
        error_score="raise",
    )

    t0 = time.time()
    search.fit(X, y)
    elapsed = time.time() - t0

    log.info(
        "%s: best_score=%.4f  params=%s  (%.1fs)",
        name, search.best_score_, search.best_params_, elapsed,
    )

    return search.best_estimator_, search.best_score_
