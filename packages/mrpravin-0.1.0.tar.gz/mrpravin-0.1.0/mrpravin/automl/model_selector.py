"""
mrpravin.automl.model_selector
──────────────────────────────
Detect problem type and return a set of candidate model pipelines.
"""
from __future__ import annotations

import logging
from typing import Dict, Literal, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import (
    GradientBoostingClassifier, GradientBoostingRegressor,
    RandomForestClassifier, RandomForestRegressor,
)

from mrpravin.config import MrPravinConfig

log = logging.getLogger("mrpravin.model_selector")

ProblemType = Literal["binary_classification", "multiclass_classification", "regression"]


def detect_problem_type(y: pd.Series) -> ProblemType:
    """Infer whether target is regression or classification."""
    if y.dtype == object or str(y.dtype).startswith("category"):
        n_classes = y.nunique()
        ptype: ProblemType = "binary_classification" if n_classes == 2 else "multiclass_classification"
    elif y.nunique() <= 20 and y.nunique() / len(y) < 0.05:
        n_classes = y.nunique()
        ptype = "binary_classification" if n_classes == 2 else "multiclass_classification"
    else:
        ptype = "regression"
    log.info("Problem type detected: %s  (target dtype=%s, n_unique=%d)",
             ptype, y.dtype, y.nunique())
    return ptype


def _try_import_xgb():
    try:
        from xgboost import XGBClassifier, XGBRegressor  # type: ignore
        return XGBClassifier, XGBRegressor
    except ImportError:
        return None, None


def _try_import_lgbm():
    try:
        from lightgbm import LGBMClassifier, LGBMRegressor  # type: ignore
        return LGBMClassifier, LGBMRegressor
    except ImportError:
        return None, None


def get_candidates(
    problem_type: ProblemType,
    cfg: MrPravinConfig,
    random_seed: int = 42,
) -> Dict[str, object]:
    """Return dict of {name: unfitted_estimator}."""
    rs = random_seed

    if "classification" in problem_type:
        candidates = {
            "LogisticRegression": LogisticRegression(
                max_iter=1000, random_state=rs, n_jobs=-1,
                solver="lbfgs",
            ),
            "RandomForest": RandomForestClassifier(
                n_estimators=100, random_state=rs, n_jobs=-1,
            ),
            "GradientBoosting": GradientBoostingClassifier(
                n_estimators=100, random_state=rs,
            ),
        }
        if cfg.use_xgboost:
            XGBClf, _ = _try_import_xgb()
            if XGBClf:
                candidates["XGBoost"] = XGBClf(
                    random_state=rs, eval_metric="logloss",
                    n_estimators=100, verbosity=0,
                )
        if cfg.use_lightgbm:
            LGBMClf, _ = _try_import_lgbm()
            if LGBMClf:
                candidates["LightGBM"] = LGBMClf(
                    random_state=rs, n_estimators=100, verbosity=-1,
                )
    else:
        candidates = {
            "LinearRegression": LinearRegression(n_jobs=-1),
            "RandomForest": RandomForestRegressor(
                n_estimators=100, random_state=rs, n_jobs=-1,
            ),
            "GradientBoosting": GradientBoostingRegressor(
                n_estimators=100, random_state=rs,
            ),
        }
        if cfg.use_xgboost:
            _, XGBReg = _try_import_xgb()
            if XGBReg:
                candidates["XGBoost"] = XGBReg(
                    random_state=rs, n_estimators=100, verbosity=0,
                )
        if cfg.use_lightgbm:
            _, LGBMReg = _try_import_lgbm()
            if LGBMReg:
                candidates["LightGBM"] = LGBMReg(
                    random_state=rs, n_estimators=100, verbosity=-1,
                )

    log.info("Candidate models: %s", list(candidates))
    return candidates
