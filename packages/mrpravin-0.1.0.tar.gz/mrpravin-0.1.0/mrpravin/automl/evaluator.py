"""
mrpravin.automl.evaluator
─────────────────────────
Evaluate the final model on a hold-out test set and return metrics + feature importance.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

log = logging.getLogger("mrpravin.evaluator")


def get_scoring_metric(problem_type: str) -> str:
    if "classification" in problem_type:
        return "f1_weighted"
    return "neg_root_mean_squared_error"


def evaluate(
    model,
    X_test: pd.DataFrame,
    y_test: pd.Series,
    problem_type: str,
    feature_names: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Compute metrics and extract feature importance.
    """
    metrics: Dict[str, Any] = {"problem_type": problem_type}
    y_pred = model.predict(X_test)

    if "classification" in problem_type:
        from sklearn.metrics import (
            accuracy_score, classification_report,
            f1_score, roc_auc_score,
        )
        metrics["accuracy"]        = float(accuracy_score(y_test, y_pred))
        metrics["f1_weighted"]     = float(f1_score(y_test, y_pred, average="weighted"))
        metrics["classification_report"] = classification_report(y_test, y_pred, output_dict=True)

        # ROC-AUC (binary only)
        if problem_type == "binary_classification" and hasattr(model, "predict_proba"):
            try:
                y_prob = model.predict_proba(X_test)[:, 1]
                metrics["roc_auc"] = float(roc_auc_score(y_test, y_prob))
            except Exception:
                pass

    else:
        from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
        metrics["rmse"]            = float(np.sqrt(mean_squared_error(y_test, y_pred)))
        metrics["mae"]             = float(mean_absolute_error(y_test, y_pred))
        metrics["r2"]              = float(r2_score(y_test, y_pred))

    # feature importance
    fi = _extract_feature_importance(model, feature_names)
    if fi is not None:
        metrics["feature_importance"] = fi

    log.info("Evaluation metrics: %s",
             {k: v for k, v in metrics.items()
              if k not in {"classification_report", "feature_importance"}})
    return metrics


def _extract_feature_importance(model, feature_names) -> Optional[Dict[str, float]]:
    """Extract feature_importances_ or coef_ if available."""
    fi_arr = None

    if hasattr(model, "feature_importances_"):
        fi_arr = model.feature_importances_
    elif hasattr(model, "coef_"):
        coef = model.coef_
        if coef.ndim > 1:
            fi_arr = np.abs(coef).mean(axis=0)
        else:
            fi_arr = np.abs(coef)

    if fi_arr is None:
        return None

    if feature_names and len(feature_names) == len(fi_arr):
        fi_dict = dict(zip(feature_names, fi_arr.tolist()))
    else:
        fi_dict = {f"feature_{i}": float(v) for i, v in enumerate(fi_arr)}

    # sort descending
    return dict(sorted(fi_dict.items(), key=lambda x: -x[1]))
