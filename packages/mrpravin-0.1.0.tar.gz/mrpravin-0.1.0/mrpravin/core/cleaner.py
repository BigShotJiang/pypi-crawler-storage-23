"""
mrpravin.core.cleaner
─────────────────────
Handles:
  • duplicate removal
  • text standardisation
  • missing value imputation
  • outlier detection & treatment
  • datetime parsing
  • numeric coercion
"""
from __future__ import annotations

import logging
import re
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from scipy import stats

from mrpravin.config import MrPravinConfig
from mrpravin.core.profiler import ColType

log = logging.getLogger("mrpravin.cleaner")

# ─────────────────────────────────────────────────────────────────────────────
# Text helpers
# ─────────────────────────────────────────────────────────────────────────────

def _clean_text(series: pd.Series) -> pd.Series:
    s = series.astype(str)
    s = s.str.strip()
    s = s.str.lower()
    s = s.str.replace(r"[^\w\s@.\-]", "", regex=True)   # keep alnum + basic symbols
    s = s.str.replace(r"\s+", " ", regex=True)
    s = s.where(series.notna(), other=np.nan)             # restore NaN
    return s


def _validate_email(series: pd.Series) -> pd.Series:
    email_re = re.compile(r"^[\w.\-+]+@[\w.\-]+\.[a-z]{2,}$", re.IGNORECASE)
    def _chk(v):
        if pd.isna(v):
            return np.nan
        return v if email_re.match(str(v)) else np.nan
    return series.apply(_chk)


# ─────────────────────────────────────────────────────────────────────────────
# Outlier helpers
# ─────────────────────────────────────────────────────────────────────────────

def _iqr_bounds(series: pd.Series, k: float = 1.5):
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    return q1 - k * iqr, q3 + k * iqr


def _zscore_mask(series: pd.Series, threshold: float = 3.0) -> pd.Series:
    z = np.abs(stats.zscore(series.dropna()))
    return pd.Series(z, index=series.dropna().index)


def _mad_bounds(series: pd.Series, threshold: float = 3.5):
    median = series.median()
    mad = np.median(np.abs(series - median))
    k = threshold * mad / 0.6745
    return median - k, median + k


# ─────────────────────────────────────────────────────────────────────────────
# Main cleaner
# ─────────────────────────────────────────────────────────────────────────────

class Cleaner:
    """
    Stateful cleaner: fit on training data, transform any DataFrame.
    """

    def __init__(self, cfg: MrPravinConfig):
        self.cfg = cfg
        self._numeric_fill: Dict[str, float] = {}
        self._cat_fill: Dict[str, str] = {}
        self._dt_cols: List[str] = []
        self._outlier_bounds: Dict[str, tuple] = {}
        self._drop_cols: List[str] = []

    # ── fit ──────────────────────────────────────────────────────────

    def fit(
        self,
        df: pd.DataFrame,
        type_map: Dict[str, ColType],
        report: dict,
        deduplicate: bool = True,
    ) -> "Cleaner":
        cfg = self.cfg

        # 1. high-missing columns to drop
        missing_frac = df.isnull().mean()
        self._drop_cols = list(
            missing_frac[missing_frac > cfg.drop_col_missing_threshold].index
        )
        report["columns_dropped_high_missing"] = self._drop_cols
        log.info("Columns to drop (>%.0f%% missing): %s",
                 cfg.drop_col_missing_threshold * 100, self._drop_cols)

        # 2. compute fill values on non-dropped columns
        remaining = [c for c in df.columns if c not in self._drop_cols]
        for col in remaining:
            ctype = type_map.get(col, "categorical")
            s = df[col]
            if ctype == "numeric":
                coerced = pd.to_numeric(s, errors="coerce")
                if cfg.numeric_impute_strategy == "mean":
                    self._numeric_fill[col] = coerced.mean()
                else:  # median (default)
                    self._numeric_fill[col] = coerced.median()

            elif ctype in {"categorical", "boolean", "high_cardinality"}:
                if cfg.categorical_impute_strategy == "unknown":
                    self._cat_fill[col] = "unknown"
                else:
                    mode_val = s.mode()
                    self._cat_fill[col] = mode_val.iloc[0] if not mode_val.empty else "unknown"

            elif ctype == "datetime":
                self._dt_cols.append(col)

        # 3. outlier bounds (numeric cols)
        for col in remaining:
            if type_map.get(col) != "numeric":
                continue
            s = pd.to_numeric(df[col], errors="coerce").dropna()
            if s.empty:
                continue
            method = cfg.outlier_method
            if method == "iqr":
                lo, hi = _iqr_bounds(s, cfg.outlier_iqr_multiplier)
            elif method == "zscore":
                lo = s.mean() - cfg.outlier_zscore_threshold * s.std()
                hi = s.mean() + cfg.outlier_zscore_threshold * s.std()
            elif method == "mad":
                lo, hi = _mad_bounds(s, cfg.outlier_zscore_threshold)
            else:
                lo, hi = _iqr_bounds(s)
            self._outlier_bounds[col] = (lo, hi)

        return self

    # ── transform ────────────────────────────────────────────────────

    def transform(
        self,
        df: pd.DataFrame,
        type_map: Dict[str, ColType],
        report: dict,
        deduplicate: bool = True,
    ) -> pd.DataFrame:
        cfg = self.cfg
        df = df.copy()

        # 1. remove duplicates
        # deduplicate=False when called from pravinDS (already deduped on full df)
        before_dup = len(df)
        if deduplicate:
            df = df.drop_duplicates().reset_index(drop=True)
        report["duplicates_removed"] = before_dup - len(df)

        # 2. drop high-missing columns
        df.drop(columns=[c for c in self._drop_cols if c in df.columns], inplace=True)

        # 3. per-column cleaning
        missing_filled: Dict[str, int] = {}
        outliers_detected: Dict[str, int] = {}

        for col in list(df.columns):
            if col not in type_map:
                continue
            ctype = type_map[col]
            s = df[col]
            n_missing_before = s.isna().sum()

            # ── text columns ────────────────────────────────────────
            if ctype == "text":
                df[col] = _clean_text(s)
                # email heuristic
                if "email" in col.lower() or "mail" in col.lower():
                    df[col] = _validate_email(df[col])
                continue

            # ── datetime parsing ────────────────────────────────────
            if ctype == "datetime":
                try:
                    df[col] = pd.to_datetime(df[col], errors="coerce")
                except Exception:
                    pass
                if cfg.datetime_impute_strategy == "ffill":
                    df[col] = df[col].ffill()
                else:
                    df[col] = df[col].where(df[col].notna())

            # ── numeric ─────────────────────────────────────────────
            elif ctype == "numeric":
                df[col] = pd.to_numeric(df[col], errors="coerce")
                fill_val = self._numeric_fill.get(col, df[col].median())
                df[col] = df[col].fillna(fill_val)

                # outlier treatment
                if col in self._outlier_bounds and cfg.outlier_action != "none":
                    lo, hi = self._outlier_bounds[col]
                    mask = (df[col] < lo) | (df[col] > hi)
                    n_out = int(mask.sum())
                    if n_out > 0:
                        if cfg.outlier_action == "winsorize":
                            df[col] = df[col].clip(lower=lo, upper=hi)
                        elif cfg.outlier_action == "drop":
                            df = df[~mask].reset_index(drop=True)
                        outliers_detected[col] = n_out
                        log.debug("Outliers in '%s': %d (%s)", col, n_out, cfg.outlier_action)

            # ── categorical / boolean / high-cardinality ─────────────
            elif ctype in {"categorical", "boolean", "high_cardinality"}:
                df[col] = _clean_text(df[col].astype(str).where(df[col].notna()))
                fill_val = self._cat_fill.get(col, "unknown")
                df[col] = df[col].fillna(fill_val)

            # ── id columns → leave as-is ─────────────────────────────
            # (encoder will drop them if configured)

            n_filled = n_missing_before - df[col].isna().sum() if col in df.columns else n_missing_before
            if n_filled > 0:
                missing_filled[col] = int(n_filled)

        report["missing_filled"] = missing_filled
        report["outliers_detected"] = outliers_detected
        report["rows_after"] = len(df)
        return df

    def fit_transform(
        self,
        df: pd.DataFrame,
        type_map: Dict[str, ColType],
        report: dict,
        deduplicate: bool = True,
    ) -> pd.DataFrame:
        return self.fit(df, type_map, report, deduplicate).transform(df, type_map, report, deduplicate)