"""
mrpravin.core.profiler
──────────────────────
Column-type inference engine.
Classifies each column into one of:
  numeric | categorical | high_cardinality | datetime | boolean | id | text
"""
from __future__ import annotations

import logging
import re
from typing import Dict, Literal

import numpy as np
import pandas as pd

log = logging.getLogger("mrpravin.profiler")

ColType = Literal[
    "numeric", "categorical", "high_cardinality",
    "datetime", "boolean", "id", "text"
]

_DATE_FORMATS = [
    "%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y",
    "%Y-%m-%d %H:%M:%S", "%d-%m-%Y", "%Y/%m/%d",
    "%b %d, %Y", "%B %d, %Y", "%d %b %Y",
]

_ID_PATTERNS = re.compile(
    r"(^id$|_id$|^uuid|^guid|^key$|^pk$|^index$|^row_num)",
    re.IGNORECASE,
)


def _is_sequential(series: pd.Series, tol: float = 0.05) -> bool:
    """Return True if the integer series looks like a row-number / autoincrement ID."""
    try:
        s = series.dropna().astype(int)
        if len(s) < 10:
            return False
        diff = s.sort_values().diff().dropna()
        return float((diff == 1).mean()) > (1 - tol)
    except Exception:
        return False


def _try_parse_datetime(series: pd.Series, sample_n: int = 200) -> float:
    """Return fraction of non-null values that parse as datetime."""
    sample = series.dropna().astype(str).head(sample_n)
    if len(sample) == 0:
        return 0.0
    successes = 0
    for val in sample:
        parsed = False
        for fmt in _DATE_FORMATS:
            try:
                pd.to_datetime(val, format=fmt)
                parsed = True
                break
            except (ValueError, TypeError):
                pass
        if not parsed:
            try:
                pd.to_datetime(val)
                parsed = True
            except Exception:
                pass
        if parsed:
            successes += 1
    return successes / len(sample)


def _try_numeric(series: pd.Series, sample_n: int = 200) -> float:
    """Return fraction of non-null values convertible to float."""
    sample = series.dropna().head(sample_n)
    if len(sample) == 0:
        return 0.0
    converted = pd.to_numeric(sample, errors="coerce")
    return converted.notna().mean()


def infer_column_types(
    df: pd.DataFrame,
    id_unique_ratio: float = 0.95,
    categorical_unique_ratio: float = 0.50,
    low_cardinality_threshold: int = 15,
) -> Dict[str, ColType]:
    """
    Analyse each column and return a dict mapping column_name → ColType.
    """
    type_map: Dict[str, ColType] = {}
    n_rows = len(df)

    for col in df.columns:
        series = df[col]
        n_unique = series.nunique(dropna=True)
        n_nonnull = series.notna().sum()
        unique_ratio = n_unique / n_rows if n_rows > 0 else 0
        dtype = series.dtype

        # ── boolean ───────────────────────────────────────────────────
        if dtype == bool or set(series.dropna().unique()).issubset({0, 1, True, False}):
            type_map[col] = "boolean"
            continue

        # ── already numeric dtype ─────────────────────────────────────
        if pd.api.types.is_numeric_dtype(dtype):
            # Only treat integer columns as potential IDs,
            # and only when the column name strongly suggests it OR values are sequential.
            # Float columns are NEVER IDs.
            is_float_col = pd.api.types.is_float_dtype(dtype)
            if (not is_float_col
                    and unique_ratio >= id_unique_ratio
                    and n_unique > 50
                    and (_ID_PATTERNS.search(col) or _is_sequential(series))):
                type_map[col] = "id"
            else:
                type_map[col] = "numeric"
            continue

        # ── already datetime dtype ────────────────────────────────────
        if pd.api.types.is_datetime64_any_dtype(dtype):
            type_map[col] = "datetime"
            continue

        # ── object / string columns (including pandas 3.x StringDtype) ──
        is_string_like = (
            dtype == object
            or pd.api.types.is_string_dtype(dtype)
            and not pd.api.types.is_numeric_dtype(dtype)
            and not pd.api.types.is_bool_dtype(dtype)
        )
        if is_string_like:
            # 1. ID-like column name heuristic
            if _ID_PATTERNS.search(col) and unique_ratio >= id_unique_ratio:
                type_map[col] = "id"
                continue

            # 2. Try numeric conversion
            numeric_conf = _try_numeric(series)
            if numeric_conf >= 0.90:
                type_map[col] = "numeric"
                continue

            # 3. Try datetime parsing
            dt_conf = _try_parse_datetime(series)
            if dt_conf >= 0.80:
                type_map[col] = "datetime"
                continue

            # 4. ID by unique ratio
            if unique_ratio >= id_unique_ratio and n_unique > 50:
                type_map[col] = "id"
                continue

            # 5. Boolean-like strings
            bool_vals = {"true", "false", "yes", "no", "1", "0", "t", "f"}
            str_vals = set(series.dropna().astype(str).str.lower().unique())
            if str_vals.issubset(bool_vals):
                type_map[col] = "boolean"
                continue

            # 6. Free text heuristic (long average string length)
            avg_len = series.dropna().astype(str).str.len().mean()
            if avg_len > 50 and unique_ratio > 0.70:
                type_map[col] = "text"
                continue

            # 7. Categorical vs high-cardinality
            if n_unique <= low_cardinality_threshold or unique_ratio < 0.05:
                type_map[col] = "categorical"
            elif unique_ratio <= categorical_unique_ratio:
                type_map[col] = "high_cardinality"
            else:
                type_map[col] = "high_cardinality"
            continue

        # ── fallback ──────────────────────────────────────────────────
        type_map[col] = "categorical"

    if log.isEnabledFor(logging.DEBUG):
        for col, t in type_map.items():
            log.debug("  %-40s → %s", col, t)

    return type_map
