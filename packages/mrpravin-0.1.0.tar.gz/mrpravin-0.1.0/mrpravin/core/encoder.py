"""
mrpravin.core.encoder
─────────────────────
Encoding strategy:
  • ID columns           → drop  (if cfg.drop_id_columns)
  • boolean              → map to 0/1
  • low-card categorical → OneHotEncoder  (≤ low_cardinality_threshold unique values)
  • med-card categorical → Frequency encoding
  • high-card / text     → Frequency encoding  (or target encoding if cfg.encoding_advanced)
  • numeric              → pass through
  • datetime             → extract year / month / day / dayofweek features
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder

from mrpravin.config import MrPravinConfig
from mrpravin.core.profiler import ColType

log = logging.getLogger("mrpravin.encoder")


class Encoder:

    def __init__(self, cfg: MrPravinConfig):
        self.cfg = cfg
        self._ohe_cols: List[str] = []
        self._ohe_encoders: Dict[str, OneHotEncoder] = {}
        self._freq_maps: Dict[str, Dict] = {}
        self._bool_cols: List[str] = []
        self._id_cols: List[str] = []
        self._dt_cols: List[str] = []
        self._target_means: Dict[str, Dict] = {}   # for advanced target encoding
        self._applied: Dict[str, str] = {}          # col → strategy

    # ── fit ──────────────────────────────────────────────────────────

    def fit(
        self,
        df: pd.DataFrame,
        type_map: Dict[str, ColType],
        target_series: Optional[pd.Series] = None,
        report: dict = None,
    ) -> "Encoder":
        cfg = self.cfg
        if report is None:
            report = {}

        for col in df.columns:
            ctype = type_map.get(col, "categorical")

            if ctype == "id":
                self._id_cols.append(col)
                self._applied[col] = "drop_id"
                continue

            if ctype == "boolean":
                self._bool_cols.append(col)
                self._applied[col] = "bool_to_int"
                continue

            if ctype == "datetime":
                self._dt_cols.append(col)
                self._applied[col] = "datetime_features"
                continue

            if ctype == "numeric":
                self._applied[col] = "passthrough"
                continue

            if ctype == "text":
                # drop free-text columns (not useful for ML without NLP)
                self._id_cols.append(col)
                self._applied[col] = "drop_text"
                continue

            # ── categorical / high_cardinality ───────────────────────
            n_unique = df[col].nunique(dropna=True)
            if n_unique <= cfg.low_cardinality_threshold:
                ohe = OneHotEncoder(
                    sparse_output=False, handle_unknown="ignore",
                    drop="if_binary",
                )
                ohe.fit(df[[col]])
                self._ohe_encoders[col] = ohe
                self._ohe_cols.append(col)
                self._applied[col] = "onehot"

            elif n_unique <= cfg.medium_cardinality_threshold:
                freq = df[col].value_counts(normalize=True).to_dict()
                self._freq_maps[col] = freq
                self._applied[col] = "frequency"

            else:
                if cfg.encoding_advanced and target_series is not None:
                    # target encoding – mean of target per category
                    target_means = (
                        pd.DataFrame({"col": df[col], "target": target_series.values})
                        .groupby("col")["target"].mean()
                        .to_dict()
                    )
                    self._target_means[col] = target_means
                    self._applied[col] = "target"
                else:
                    freq = df[col].value_counts(normalize=True).to_dict()
                    self._freq_maps[col] = freq
                    self._applied[col] = "frequency"

        report["encodings_applied"] = self._applied.copy()
        log.info("Encoding plan: %s", self._applied)
        return self

    # ── transform ────────────────────────────────────────────────────

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        drop_cols = []
        add_frames = []

        for col in list(df.columns):
            strategy = self._applied.get(col, "passthrough")

            if strategy in {"drop_id", "drop_text"}:
                drop_cols.append(col)

            elif strategy == "bool_to_int":
                bool_map = {"true": 1, "false": 0, "yes": 1, "no": 0, "1": 1, "0": 0}
                df[col] = (
                    df[col].astype(str).str.lower()
                    .map(bool_map)
                    .fillna(df[col].astype(int, errors="ignore"))
                )

            elif strategy == "onehot":
                ohe = self._ohe_encoders[col]
                encoded = ohe.transform(df[[col]])
                feature_names = ohe.get_feature_names_out([col])
                add_frames.append(pd.DataFrame(encoded, columns=feature_names, index=df.index))
                drop_cols.append(col)

            elif strategy == "frequency":
                freq = self._freq_maps[col]
                global_mean = np.mean(list(freq.values())) if freq else 0.0
                df[col] = df[col].map(freq).fillna(global_mean)

            elif strategy == "target":
                means = self._target_means[col]
                global_mean = np.mean(list(means.values())) if means else 0.0
                df[col] = df[col].map(means).fillna(global_mean)

            elif strategy == "datetime_features":
                try:
                    dt = pd.to_datetime(df[col], errors="coerce")
                    df[f"{col}__year"]       = dt.dt.year
                    df[f"{col}__month"]      = dt.dt.month
                    df[f"{col}__day"]        = dt.dt.day
                    df[f"{col}__dayofweek"]  = dt.dt.dayofweek
                except Exception:
                    pass
                drop_cols.append(col)

            # passthrough / numeric: do nothing

        df = df.drop(columns=[c for c in drop_cols if c in df.columns])
        if add_frames:
            df = pd.concat([df] + add_frames, axis=1)

        # ensure all remaining object columns are converted
        for col in df.select_dtypes(include=["object"]).columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

        return df
