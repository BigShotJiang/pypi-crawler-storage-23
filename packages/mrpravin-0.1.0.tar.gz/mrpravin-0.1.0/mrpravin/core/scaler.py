"""
mrpravin.core.scaler
────────────────────
Auto-selects and applies a numeric scaler.

Auto-selection logic:
  • If distribution is highly skewed (|skew| > 1)  → RobustScaler
  • If distribution has heavy outliers              → RobustScaler
  • Otherwise                                       → StandardScaler
MinMaxScaler available via explicit config.
"""
from __future__ import annotations

import logging
from typing import List

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, RobustScaler, StandardScaler

from mrpravin.config import MrPravinConfig

log = logging.getLogger("mrpravin.scaler")


def _pick_scaler(df: pd.DataFrame, numeric_cols: List[str]):
    """Return an un-fitted sklearn scaler based on distribution analysis."""
    skew_threshold = 1.0
    skewness = df[numeric_cols].skew().abs()
    mean_skew = skewness.mean()

    if mean_skew > skew_threshold:
        log.info("Auto-scaler: RobustScaler (mean |skew|=%.2f)", mean_skew)
        return RobustScaler()
    else:
        log.info("Auto-scaler: StandardScaler (mean |skew|=%.2f)", mean_skew)
        return StandardScaler()


class Scaler:

    def __init__(self, cfg: MrPravinConfig):
        self.cfg = cfg
        self._scaler = None
        self._numeric_cols: List[str] = []

    def fit(self, df: pd.DataFrame) -> "Scaler":
        self._numeric_cols = list(df.select_dtypes(include=["number"]).columns)
        if not self._numeric_cols:
            return self

        if self.cfg.scaler == "auto":
            self._scaler = _pick_scaler(df, self._numeric_cols)
        elif self.cfg.scaler == "standard":
            self._scaler = StandardScaler()
        elif self.cfg.scaler == "robust":
            self._scaler = RobustScaler()
        elif self.cfg.scaler == "minmax":
            self._scaler = MinMaxScaler()

        self._scaler.fit(df[self._numeric_cols])
        return self

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        if self._scaler is None or not self._numeric_cols:
            return df
        # only scale columns that exist in this df
        cols = [c for c in self._numeric_cols if c in df.columns]
        if cols:
            df[cols] = self._scaler.transform(df[cols])
        return df

    def fit_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        return self.fit(df).transform(df)
