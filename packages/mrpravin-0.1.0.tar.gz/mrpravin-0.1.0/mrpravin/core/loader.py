"""
mrpravin.core.loader
────────────────────
Accepts CSV / Excel / JSON / DataFrame and returns a raw DataFrame.
Handles encoding detection, delimiter inference, and chunked reading.
"""
from __future__ import annotations

import io
import logging
import os
from pathlib import Path
from typing import Union

import pandas as pd

log = logging.getLogger("mrpravin.loader")

# optional heavy dep
try:
    import chardet  # type: ignore
    _HAS_CHARDET = True
except ImportError:
    _HAS_CHARDET = False


def _detect_encoding(path: str) -> str:
    if not _HAS_CHARDET:
        return "utf-8"
    with open(path, "rb") as f:
        raw = f.read(100_000)
    result = chardet.detect(raw)
    enc = result.get("encoding") or "utf-8"
    log.debug("Detected encoding: %s (confidence=%.2f)", enc, result.get("confidence", 0))
    return enc


def _infer_delimiter(path: str, encoding: str) -> str:
    """Peek at first line and pick the most common delimiter candidate."""
    candidates = [",", ";", "\t", "|"]
    with open(path, encoding=encoding, errors="replace") as f:
        first_line = f.readline()
    counts = {d: first_line.count(d) for d in candidates}
    best = max(counts, key=counts.get)
    log.debug("Inferred delimiter: %r  (counts=%s)", best, counts)
    return best


def load(
    source: Union[str, Path, pd.DataFrame, io.IOBase],
    chunk_size: Union[int, None] = None,
    sheet_name: Union[str, int] = 0,
) -> pd.DataFrame:
    """
    Load data from various sources into a single DataFrame.

    Parameters
    ----------
    source      : file path (str/Path), file-like object, or existing DataFrame
    chunk_size  : rows per chunk for large CSV files (None = no chunking)
    sheet_name  : Excel sheet to read (default first sheet)
    """
    if isinstance(source, pd.DataFrame):
        log.info("Source is already a DataFrame – returning copy.")
        return source.copy()

    if isinstance(source, io.IOBase):
        log.info("Loading from file-like object (CSV assumed).")
        return pd.read_csv(source)

    path = str(source)
    if not os.path.exists(path):
        raise FileNotFoundError(f"mrpravin: file not found → {path}")

    ext = Path(path).suffix.lower()
    log.info("Loading file: %s  (extension=%s)", path, ext)

    if ext in {".csv", ".tsv", ".txt"}:
        encoding = _detect_encoding(path)
        delimiter = "\t" if ext == ".tsv" else _infer_delimiter(path, encoding)
        if chunk_size:
            chunks = pd.read_csv(
                path, encoding=encoding, sep=delimiter,
                chunksize=chunk_size, on_bad_lines="warn",
                low_memory=True,
            )
            df = pd.concat(chunks, ignore_index=True)
        else:
            df = pd.read_csv(
                path, encoding=encoding, sep=delimiter,
                on_bad_lines="warn", low_memory=False,
            )

    elif ext in {".xlsx", ".xls", ".xlsm"}:
        df = pd.read_excel(path, sheet_name=sheet_name)

    elif ext == ".json":
        try:
            df = pd.read_json(path)
        except ValueError:
            df = pd.read_json(path, lines=True)

    else:
        raise ValueError(f"mrpravin: unsupported file type '{ext}'")

    log.info("Loaded shape: %s", df.shape)
    return df
