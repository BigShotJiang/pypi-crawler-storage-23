"""
mrpravin.core.report
────────────────────
Build, pretty-print, and export the DA cleaning report.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

log = logging.getLogger("mrpravin.report")


def build_report(**kwargs) -> dict:
    """Create a fresh report skeleton, merged with any extra keys."""
    base = {
        "rows_before": 0,
        "rows_after": 0,
        "duplicates_removed": 0,
        "columns_dropped_high_missing": [],
        "missing_filled": {},
        "encodings_applied": {},
        "outliers_detected": {},
        "column_types": {},
        "scaler_used": None,
    }
    base.update(kwargs)
    return base


def pretty_print(report: dict) -> None:
    """Print a human-readable summary."""
    print("\n" + "═" * 55)
    print("  🧹  mrpravin  –  Data Analyst Report")
    print("═" * 55)
    print(f"  Rows before         : {report.get('rows_before', '?')}")
    print(f"  Rows after          : {report.get('rows_after', '?')}")
    print(f"  Duplicates removed  : {report.get('duplicates_removed', 0)}")

    dropped = report.get("columns_dropped_high_missing", [])
    if dropped:
        print(f"  Columns dropped     : {', '.join(dropped)}")

    mf = report.get("missing_filled", {})
    if mf:
        print(f"  Missing filled      : {sum(mf.values())} values across {len(mf)} columns")

    od = report.get("outliers_detected", {})
    if od:
        total_out = sum(od.values())
        print(f"  Outliers treated    : {total_out} values across {len(od)} columns")

    enc = report.get("encodings_applied", {})
    if enc:
        from collections import Counter
        strategy_counts = Counter(enc.values())
        print(f"  Encodings           : {dict(strategy_counts)}")

    sc = report.get("scaler_used")
    if sc:
        print(f"  Scaler              : {sc}")

    print("═" * 55 + "\n")


def export_json(report: dict, path: str) -> None:
    Path(path).write_text(json.dumps(report, indent=2, default=str))
    log.info("Report exported to %s", path)


def export_html(report: dict, path: str) -> None:
    rows = "".join(
        f"<tr><td><b>{k}</b></td><td><pre>{json.dumps(v, indent=2, default=str)}</pre></td></tr>"
        for k, v in report.items()
    )
    html = f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>mrpravin Report</title>
  <style>
    body {{ font-family: sans-serif; margin: 2em; }}
    table {{ border-collapse: collapse; width: 100%; }}
    td {{ border: 1px solid #ccc; padding: 8px; vertical-align: top; }}
    tr:nth-child(even) {{ background: #f9f9f9; }}
    h1 {{ color: #333; }}
    pre {{ white-space: pre-wrap; margin: 0; }}
  </style>
</head>
<body>
  <h1>🧹 mrpravin – Data Analyst Report</h1>
  <table>{rows}</table>
</body>
</html>"""
    Path(path).write_text(html, encoding="utf-8")
    log.info("Report exported to %s", path)