"""
mrpravin – Global configuration
"""
from __future__ import annotations
import json
from dataclasses import dataclass, field, asdict
from typing import Literal, Optional


@dataclass
class MrPravinConfig:
    # ── reproducibility ───────────────────────────────────────────────
    random_seed: int = 42

    # ── missing value thresholds ──────────────────────────────────────
    drop_col_missing_threshold: float = 0.70   # drop col if > 70 % missing
    numeric_impute_strategy: Literal["median", "mean", "knn"] = "median"
    categorical_impute_strategy: Literal["mode", "unknown"] = "mode"
    datetime_impute_strategy: Literal["ffill", "drop"] = "ffill"

    # ── outlier ───────────────────────────────────────────────────────
    outlier_method: Literal["iqr", "zscore", "mad", "isolation_forest"] = "iqr"
    outlier_action: Literal["winsorize", "drop", "none"] = "winsorize"
    outlier_iqr_multiplier: float = 1.5
    outlier_zscore_threshold: float = 3.0

    # ── cardinality thresholds ────────────────────────────────────────
    low_cardinality_threshold: int = 15    # OneHot
    medium_cardinality_threshold: int = 50 # Frequency encode; above → drop or target-encode

    # ── unique-ratio heuristics ───────────────────────────────────────
    id_unique_ratio: float = 0.95          # treat col as ID if unique/total > this
    categorical_unique_ratio: float = 0.50 # treat as high-card if unique/total > this

    # ── encoding ──────────────────────────────────────────────────────
    encoding_advanced: bool = False        # enables target encoding
    drop_id_columns: bool = True

    # ── scaling ───────────────────────────────────────────────────────
    scaler: Literal["auto", "standard", "robust", "minmax"] = "auto"

    # ── automl ────────────────────────────────────────────────────────
    cv_folds: int = 5
    time_budget_seconds: int = 120
    use_xgboost: bool = True
    use_lightgbm: bool = True
    hyperparameter_search: Literal["random", "bayesian"] = "random"
    n_iter_search: int = 30

    # ── dry-run / safety ─────────────────────────────────────────────
    dry_run: bool = False
    warn_target_leakage: bool = True

    # ── reporting ─────────────────────────────────────────────────────
    verbose: bool = True

    def to_json(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2)

    @classmethod
    def from_json(cls, path: str) -> "MrPravinConfig":
        with open(path) as f:
            data = json.load(f)
        return cls(**data)


# module-level default instance
DEFAULT_CONFIG = MrPravinConfig()
