"""
mrpravin.ml
───────────
pravinML  –  Production inference layer returned by pravinDS.

What separates this from a plain model wrapper:

  1. InputSchema   – captures training-time data contract (column names,
                     dtypes, value ranges). Enforced at every prediction.

  2. ValidationReport – before any prediction runs, pravinML checks the
                     incoming data against the schema and emits structured
                     warnings (missing columns, type mismatches, distribution
                     drift). Never silently corrupt inference.

  3. evaluate()    – run the full metric suite on any labelled dataset, not
                     just the original test split.

  4. explain()     – ranked feature importance with percentage contribution.

  5. summary()     – printed model card: architecture, training provenance,
                     schema, metrics, top features. One call, full audit trail.

  6. benchmark()   – measure inference latency (p50 / p95 / p99) on real data
                     before you deploy.

  7. save() / load() – pickle round-trip with integrity check.

Public API (all users ever need):

    model = mr.pravinDS("data.csv", target="price")   # returns pravinML
    model.predict(X_new)
    model.validate(X_new)
    model.explain()
    model.summary()
    model.evaluate(X_holdout, y_holdout)
    model.benchmark(X_new)
    model.save("model.pkl")
    model = mr.pravinML.load("model.pkl")
"""
from __future__ import annotations

import hashlib
import logging
import pickle
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

log = logging.getLogger("mrpravin.ml")


# ─────────────────────────────────────────────────────────────────────────────
# InputSchema  –  training-time data contract
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class InputSchema:
    """
    Captures the exact data contract required at inference time.
    Built automatically from training data by pravinDS.
    """
    feature_names: List[str]
    feature_dtypes: Dict[str, str]          # col → dtype string
    feature_stats: Dict[str, Dict]          # col → {min, max, mean, std, n_unique}
    training_rows: int
    training_cols: int
    problem_type: str
    target_name: str
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @classmethod
    def from_dataframe(
        cls,
        X: pd.DataFrame,
        problem_type: str,
        target_name: str,
    ) -> "InputSchema":
        stats: Dict[str, Dict] = {}
        dtypes: Dict[str, str] = {}

        for col in X.columns:
            s = X[col]
            dtypes[col] = str(s.dtype)
            col_stats: Dict[str, Any] = {"n_unique": int(s.nunique())}

            if pd.api.types.is_numeric_dtype(s):
                col_stats["min"]  = float(s.min())  if s.notna().any() else None
                col_stats["max"]  = float(s.max())  if s.notna().any() else None
                col_stats["mean"] = float(s.mean()) if s.notna().any() else None
                col_stats["std"]  = float(s.std())  if s.notna().any() else None
            else:
                col_stats["top_values"] = s.value_counts().head(5).index.tolist()

            stats[col] = col_stats

        return cls(
            feature_names=list(X.columns),
            feature_dtypes=dtypes,
            feature_stats=stats,
            training_rows=len(X),
            training_cols=len(X.columns),
            problem_type=problem_type,
            target_name=target_name,
        )

    def to_dict(self) -> dict:
        return {
            "feature_names": self.feature_names,
            "feature_dtypes": self.feature_dtypes,
            "feature_stats": self.feature_stats,
            "training_rows": self.training_rows,
            "training_cols": self.training_cols,
            "problem_type": self.problem_type,
            "target_name": self.target_name,
            "created_at": self.created_at,
        }


# ─────────────────────────────────────────────────────────────────────────────
# ValidationReport  –  pre-inference data quality check
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ValidationReport:
    """Result of validating inference data against the training schema."""
    is_valid: bool
    missing_columns: List[str]
    extra_columns: List[str]
    dtype_mismatches: Dict[str, Tuple[str, str]]   # col → (expected, got)
    drift_warnings: Dict[str, Dict]                # col → {train_range, data_range}
    row_count: int
    warnings: List[str]
    errors: List[str]

    def summary(self) -> str:
        lines = [
            f"ValidationReport  rows={self.row_count}  "
            f"valid={self.is_valid}  "
            f"warnings={len(self.warnings)}  "
            f"errors={len(self.errors)}"
        ]
        for e in self.errors:
            lines.append(f"  ERROR   {e}")
        for w in self.warnings:
            lines.append(f"  WARN    {w}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return self.summary()


# ─────────────────────────────────────────────────────────────────────────────
# pravinML  –  production inference layer
# ─────────────────────────────────────────────────────────────────────────────

class pravinML:
    """
    Production ML inference object returned by mr.pravinDS().

    Wraps a trained sklearn estimator with:
      • schema enforcement
      • pre-prediction validation
      • distribution drift detection
      • feature explanation
      • performance benchmarking
      • full model audit trail
    """

    # ── construction ─────────────────────────────────────────────────

    def __init__(
        self,
        model: Any,
        metrics: Dict[str, Any],
        problem_type: str,
        feature_names: List[str],
        schema: InputSchema,
        da_pipeline: tuple,                # (cfg, type_map, cleaner, encoder, scaler)
        model_name: str = "Unknown",
        label_encoder: Any = None,
        training_rows: int = 0,
    ) -> None:
        self._model        = model
        self._metrics      = metrics
        self._problem_type = problem_type
        self._feature_names = feature_names
        self._schema       = schema
        self._da_pipeline  = da_pipeline
        self._model_name   = model_name
        self._label_encoder = label_encoder
        self._training_rows = training_rows
        self._created_at   = datetime.now(timezone.utc).isoformat()
        self._version      = "1.0"

    # ── public properties ────────────────────────────────────────────

    @property
    def metrics(self) -> Dict[str, Any]:
        """Evaluation metrics from the held-out test set."""
        return self._metrics

    @property
    def problem_type(self) -> str:
        """'regression' | 'binary_classification' | 'multiclass_classification'"""
        return self._problem_type

    @property
    def feature_names(self) -> List[str]:
        """Ordered list of feature columns required at inference time."""
        return self._feature_names

    @property
    def schema(self) -> InputSchema:
        """Full training-time data contract."""
        return self._schema

    @property
    def model_name(self) -> str:
        """Name of the winning algorithm (e.g. 'RandomForest')."""
        return self._model_name

    # ── core inference ───────────────────────────────────────────────

    def _prepare(self, X: Union[pd.DataFrame, str, Path]) -> pd.DataFrame:
        """Internal: load → clean → encode → scale → align."""
        from mrpravin.core.loader import load as _load

        if not isinstance(X, pd.DataFrame):
            X = _load(X)

        cfg, type_map, cleaner, encoder, scaler = self._da_pipeline
        dummy: dict = {}
        X = cleaner.transform(X.reset_index(drop=True), type_map, dummy)
        X = encoder.transform(X)
        X = scaler.transform(X)
        X = _align_columns(X, self._feature_names)
        return X

    def predict(
        self,
        X: Union[pd.DataFrame, str, Path],
        validate: bool = True,
        warn_on_drift: bool = True,
    ) -> np.ndarray:
        """
        Predict on new data.

        Parameters
        ----------
        X              : raw DataFrame or file path (auto-cleaned)
        validate       : run schema validation before prediction
        warn_on_drift  : emit warnings when data is out of training distribution

        Returns
        -------
        np.ndarray of predictions
        """
        if isinstance(X, (str, Path)):
            from mrpravin.core.loader import load as _load
            X = _load(X)

        if validate:
            report = self.validate(X)
            if report.errors:
                raise ValueError(
                    f"pravinML.predict() blocked – schema errors detected:\n"
                    + "\n".join(f"  • {e}" for e in report.errors)
                )
            if warn_on_drift and report.warnings:
                for w in report.warnings:
                    log.warning("⚠  %s", w)

        X_prep = self._prepare(X)
        raw    = self._model.predict(X_prep)

        if self._label_encoder is not None:
            try:
                return self._label_encoder.inverse_transform(raw)
            except Exception:
                return raw
        return raw

    def predict_proba(
        self,
        X: Union[pd.DataFrame, str, Path],
        validate: bool = True,
    ) -> np.ndarray:
        """
        Predict class probabilities (classification only).

        Returns
        -------
        np.ndarray  shape (n_samples, n_classes)
        """
        if not hasattr(self._model, "predict_proba"):
            raise AttributeError(
                f"'{self._model_name}' does not support predict_proba. "
                "Use predict() instead."
            )

        if isinstance(X, (str, Path)):
            from mrpravin.core.loader import load as _load
            X = _load(X)

        if validate:
            report = self.validate(X)
            if report.errors:
                raise ValueError(
                    "pravinML.predict_proba() blocked – schema errors:\n"
                    + "\n".join(f"  • {e}" for e in report.errors)
                )

        X_prep = self._prepare(X)
        return self._model.predict_proba(X_prep)

    # ── validation ───────────────────────────────────────────────────

    def validate(self, X: pd.DataFrame) -> ValidationReport:
        """
        Validate inference data against the training schema.

        Checks:
          • Missing required columns
          • Extra unexpected columns
          • Numeric range drift (values outside training min/max)
          • Row count sanity

        Returns
        -------
        ValidationReport  (never raises – caller decides what to do)
        """
        schema      = self._schema
        errors:   List[str] = []
        warnings: List[str] = []
        missing_cols:  List[str] = []
        extra_cols:    List[str] = []
        dtype_mismatches: Dict[str, Tuple[str, str]] = {}
        drift_warnings:   Dict[str, Dict] = {}

        incoming_cols = set(X.columns)
        required_cols = set(schema.feature_names)

        # ── missing columns ───────────────────────────────────────────
        missing_cols = [c for c in schema.feature_names if c not in incoming_cols]
        if missing_cols:
            errors.append(f"Missing required columns: {missing_cols}")

        # ── extra columns ─────────────────────────────────────────────
        extra_cols = [c for c in incoming_cols if c not in required_cols]
        if extra_cols:
            warnings.append(f"Extra columns (will be ignored): {extra_cols}")

        # ── per-column checks ─────────────────────────────────────────
        for col in schema.feature_names:
            if col not in X.columns:
                continue

            s = X[col]
            expected_dtype = schema.feature_dtypes.get(col, "object")
            got_dtype      = str(s.dtype)
            stats          = schema.feature_stats.get(col, {})

            # dtype family check — skip bool columns (arrive as "Yes"/"No" strings,
            # get encoded to int internally — this is expected, not a warning)
            exp_is_numeric = "int" in expected_dtype or "float" in expected_dtype
            got_is_numeric = pd.api.types.is_numeric_dtype(s)
            is_bool_col = s.dropna().astype(str).str.lower().isin(
                {"yes", "no", "true", "false", "1", "0"}
            ).all()
            if exp_is_numeric and not got_is_numeric and not is_bool_col:
                dtype_mismatches[col] = (expected_dtype, got_dtype)
                warnings.append(
                    f"Column '{col}': expected numeric ({expected_dtype}), "
                    f"got {got_dtype}"
                )

            # numeric range drift
            if exp_is_numeric and got_is_numeric and "min" in stats:
                t_min, t_max = stats["min"], stats["max"]
                d_min = float(s.dropna().min()) if s.notna().any() else None
                d_max = float(s.dropna().max()) if s.notna().any() else None

                if d_min is not None and t_min is not None and t_max is not None:
                    range_span  = (t_max - t_min) if t_max != t_min else 1.0
                    drift_lo = d_min < t_min - 0.2 * abs(range_span)
                    drift_hi = d_max > t_max + 0.2 * abs(range_span)

                    if drift_lo or drift_hi:
                        drift_warnings[col] = {
                            "training_range": [t_min, t_max],
                            "inference_range": [d_min, d_max],
                        }
                        warnings.append(
                            f"Distribution drift in '{col}': "
                            f"training [{t_min:.3g}, {t_max:.3g}] vs "
                            f"inference [{d_min:.3g}, {d_max:.3g}]"
                        )

        is_valid = len(errors) == 0
        return ValidationReport(
            is_valid=is_valid,
            missing_columns=missing_cols,
            extra_columns=extra_cols,
            dtype_mismatches=dtype_mismatches,
            drift_warnings=drift_warnings,
            row_count=len(X),
            warnings=warnings,
            errors=errors,
        )

    # ── evaluation ───────────────────────────────────────────────────

    def evaluate(
        self,
        X: Union[pd.DataFrame, str, Path],
        y: pd.Series,
    ) -> Dict[str, Any]:
        """
        Evaluate model on any labelled dataset (not just the original test split).

        Parameters
        ----------
        X : raw features (auto-cleaned)
        y : ground truth labels/values

        Returns
        -------
        metrics dict (same structure as self.metrics)
        """
        from mrpravin.automl.evaluator import evaluate as _evaluate

        if isinstance(X, (str, Path)):
            from mrpravin.core.loader import load as _load
            X = _load(X)

        X_prep = self._prepare(X)
        y      = pd.Series(y).reset_index(drop=True)

        if self._label_encoder is not None:
            try:
                y = pd.Series(self._label_encoder.transform(y))
            except Exception:
                pass

        return _evaluate(self._model, X_prep, y, self._problem_type, self._feature_names)

    # ── explanation ──────────────────────────────────────────────────

    def explain(self, top_n: int = 20) -> Dict[str, float]:
        """
        Return ranked feature importance dict.

        Works for tree-based models (feature_importances_) and
        linear models (coef_). Returns empty dict otherwise.

        Parameters
        ----------
        top_n : number of top features to return

        Returns
        -------
        {feature_name: importance_score}  sorted descending, top_n items
        """
        model = self._model
        fi_arr: Optional[np.ndarray] = None

        if hasattr(model, "feature_importances_"):
            fi_arr = model.feature_importances_
        elif hasattr(model, "coef_"):
            coef = model.coef_
            fi_arr = np.abs(coef).mean(axis=0) if coef.ndim > 1 else np.abs(coef)

        if fi_arr is None:
            log.warning("explain() not available for %s – no feature_importances_ or coef_.",
                        self._model_name)
            return {}

        names = (
            self._feature_names
            if len(self._feature_names) == len(fi_arr)
            else [f"feature_{i}" for i in range(len(fi_arr))]
        )

        total    = fi_arr.sum() or 1.0
        ranked   = sorted(zip(names, fi_arr), key=lambda x: -x[1])
        return {name: round(float(score / total * 100), 4)
                for name, score in ranked[:top_n]}

    # ── benchmarking ─────────────────────────────────────────────────

    def benchmark(
        self,
        X: pd.DataFrame,
        n_runs: int = 100,
        batch_size: Optional[int] = None,
    ) -> Dict[str, float]:
        """
        Measure inference latency on real data.

        Parameters
        ----------
        X          : sample DataFrame (raw, will be cleaned internally)
        n_runs     : number of repeated predictions
        batch_size : rows per batch (None = full X each run)

        Returns
        -------
        {
          "n_runs": ...,
          "batch_rows": ...,
          "p50_ms": ...,
          "p95_ms": ...,
          "p99_ms": ...,
          "mean_ms": ...,
          "throughput_rows_per_sec": ...
        }
        """
        sample = X.head(batch_size) if batch_size else X
        times: List[float] = []

        # warm-up
        self._prepare(sample)

        for _ in range(n_runs):
            t0 = time.perf_counter()
            self._prepare(sample)
            self._model.predict(self._prepare(sample))
            times.append((time.perf_counter() - t0) * 1000)

        arr = np.array(times)
        rows_per_run = len(sample)

        return {
            "n_runs":                  n_runs,
            "batch_rows":              rows_per_run,
            "p50_ms":   round(float(np.percentile(arr, 50)), 3),
            "p95_ms":   round(float(np.percentile(arr, 95)), 3),
            "p99_ms":   round(float(np.percentile(arr, 99)), 3),
            "mean_ms":  round(float(arr.mean()), 3),
            "throughput_rows_per_sec": round(rows_per_run / (arr.mean() / 1000), 1),
        }

    # ── model card / audit trail ─────────────────────────────────────

    def summary(self) -> None:
        """
        Print a complete model card covering:
          – model architecture
          – training provenance
          – input schema
          – evaluation metrics
          – top 10 features
        """
        w = 60
        bar = "═" * w

        print(f"\n{bar}")
        print(f"  🧠  mrpravin  –  Model Card")
        print(bar)

        # identity
        print(f"  Algorithm     : {self._model_name}")
        print(f"  Problem type  : {self._problem_type}")
        print(f"  Target        : {self._schema.target_name}")
        print(f"  Created at    : {self._created_at[:19].replace('T',' ')} UTC")
        print(f"  mrpravin ver  : {self._version}")

        # training provenance
        print(f"\n  ── Training Data ──────────────────────────────────────")
        print(f"  Rows trained on  : {self._training_rows:,}")
        print(f"  Features         : {len(self._feature_names)}")

        # metrics
        print(f"\n  ── Test Metrics ───────────────────────────────────────")
        skip = {"classification_report", "feature_importance",
                "problem_type", "best_model_name"}
        for k, v in self._metrics.items():
            if k in skip:
                continue
            label = k.replace("_", " ").title().ljust(20)
            if isinstance(v, float):
                print(f"  {label}: {v:.4f}")
            else:
                print(f"  {label}: {v}")

        # top features
        importance = self.explain(top_n=10)
        if importance:
            print(f"\n  ── Top Features ───────────────────────────────────────")
            for rank, (feat, pct) in enumerate(importance.items(), 1):
                bar_len = int(pct / 2)
                bar_str = "█" * bar_len
                print(f"  {rank:>2}. {feat:<30} {pct:>6.2f}%  {bar_str}")

        # schema snippet
        print(f"\n  ── Input Schema ({len(self._feature_names)} features) ─────────────────────")
        for col in self._feature_names[:8]:
            dtype = self._schema.feature_dtypes.get(col, "?")
            stats = self._schema.feature_stats.get(col, {})
            if "min" in stats:
                detail = f"range [{stats['min']:.3g}, {stats['max']:.3g}]"
            elif "top_values" in stats:
                top = stats["top_values"][:3]
                detail = f"top values {top}"
            else:
                detail = ""
            print(f"  {col:<30} {dtype:<12} {detail}")

        if len(self._feature_names) > 8:
            print(f"  … and {len(self._feature_names) - 8} more features")

        print(f"{bar}\n")

    # ── persistence ──────────────────────────────────────────────────

    def save(self, path: str = "mrpravin_model.pkl") -> None:
        """
        Persist the complete pravinML object to disk.
        Includes model, preprocessing pipeline, schema, and metrics.
        """
        payload = {
            "version":       self._version,
            "model":         self,
            "checksum":      self._checksum(),
        }
        with open(path, "wb") as f:
            pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)
        size_kb = Path(path).stat().st_size / 1024
        log.info("pravinML saved → %s  (%.1f KB)", path, size_kb)

    @classmethod
    def load(cls, path: str) -> "pravinML":
        """
        Load a saved pravinML object from disk with integrity verification.
        """
        with open(path, "rb") as f:
            payload = pickle.load(f)

        if not isinstance(payload, dict) or "model" not in payload:
            # legacy: direct pickle of the object
            obj = payload
        else:
            obj = payload["model"]
            stored_checksum  = payload.get("checksum", "")
            computed_checksum = obj._checksum()
            if stored_checksum and stored_checksum != computed_checksum:
                log.warning("⚠  Checksum mismatch – model file may be corrupted.")

        log.info("pravinML loaded ← %s", path)
        return obj

    def _checksum(self) -> str:
        """Lightweight fingerprint of model + feature names."""
        key = f"{self._model_name}|{self._feature_names}|{self._problem_type}"
        return hashlib.md5(key.encode()).hexdigest()[:16]

    # ── dunder ───────────────────────────────────────────────────────

    def __repr__(self) -> str:
        m = self._metrics
        if "accuracy" in m:
            score_str = f"accuracy={m['accuracy']:.3f}"
        elif "r2" in m:
            score_str = f"r2={m['r2']:.3f}"
        else:
            score_str = f"cv_score={m.get('cv_score', '?')}"
        return (
            f"pravinML("
            f"model={self._model_name}, "
            f"type={self._problem_type}, "
            f"{score_str}, "
            f"features={len(self._feature_names)})"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Internal utility
# ─────────────────────────────────────────────────────────────────────────────

def _align_columns(df: pd.DataFrame, feature_names: List[str]) -> pd.DataFrame:
    """Add missing columns as 0, drop extra, reorder to match training."""
    for col in feature_names:
        if col not in df.columns:
            df[col] = 0.0
    return df[feature_names]