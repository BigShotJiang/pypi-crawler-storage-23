"""
mrpravin.pipeline
─────────────────
Orchestrates the DA and DS pipelines.

Public entry points (re-exported from mrpravin.__init__):

    pravinDA(source, …)                 → DataFrame [+ optional report]
    pravinDS(source, target, …)         → pravinML
"""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, Optional, Tuple, Union

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

from mrpravin.config import MrPravinConfig, DEFAULT_CONFIG
from mrpravin.core.loader import load
from mrpravin.core.profiler import infer_column_types
from mrpravin.core.cleaner import Cleaner
from mrpravin.core.encoder import Encoder
from mrpravin.core.scaler import Scaler
from mrpravin.core.report import build_report, pretty_print
from mrpravin.automl.model_selector import detect_problem_type, get_candidates
from mrpravin.automl.tuner import tune
from mrpravin.automl.evaluator import evaluate, get_scoring_metric
from mrpravin.ml import pravinML, InputSchema, _align_columns

log = logging.getLogger("mrpravin")


# ─────────────────────────────────────────────────────────────────────────────
# pravinDA  –  Data Analyst pipeline
# ─────────────────────────────────────────────────────────────────────────────

def pravinDA(
    source: Union[str, Path, pd.DataFrame],
    *,
    cfg: MrPravinConfig = DEFAULT_CONFIG,
    return_report: bool = False,
    export_report: Optional[str] = None,
    target: Optional[str] = None,
    dry_run: Optional[bool] = None,
) -> Union[pd.DataFrame, Tuple[pd.DataFrame, dict]]:
    """
    Automated data cleaning and feature engineering.

    Parameters
    ----------
    source        : CSV / Excel / JSON path, or existing DataFrame
    cfg           : MrPravinConfig (defaults to DEFAULT_CONFIG)
    return_report : return (df, report) tuple instead of just df
    export_report : file path to save report (.json or .html)
    target        : target column – excluded from encoding and scaling
    dry_run       : return raw data without any modifications

    Returns
    -------
    Cleaned, ML-ready DataFrame  –  or (DataFrame, report_dict)
    """
    _dry = dry_run if dry_run is not None else cfg.dry_run
    np.random.seed(cfg.random_seed)
    t0 = time.time()

    df     = load(source)
    report = build_report(rows_before=len(df))

    log.info("pravinDA  loaded %d × %d", *df.shape)

    if _dry:
        log.info("[DRY RUN] Returning raw data – no modifications.")
        return (df, report) if return_report else df

    # ── column type inference ─────────────────────────────────────────
    type_map = infer_column_types(
        df,
        id_unique_ratio=cfg.id_unique_ratio,
        categorical_unique_ratio=cfg.categorical_unique_ratio,
        low_cardinality_threshold=cfg.low_cardinality_threshold,
    )
    report["column_types"] = type_map

    # ── clean ─────────────────────────────────────────────────────────
    cleaner = Cleaner(cfg)
    df      = cleaner.fit_transform(df, type_map, report)

    # ── separate target so it is not encoded or scaled ────────────────
    target_series: Optional[pd.Series] = None
    if target and target in df.columns:
        target_series    = df[target].copy()
        df_features      = df.drop(columns=[target])
        encode_type_map  = {k: v for k, v in type_map.items() if k != target}
    else:
        df_features     = df
        encode_type_map = type_map

    # ── encode ────────────────────────────────────────────────────────
    encoder = Encoder(cfg)
    encoder.fit(df_features, encode_type_map, target_series=target_series, report=report)
    df_features = encoder.transform(df_features)

    # pravinDA does NOT scale — scaling is a modelling concern, not cleaning.
    # pravinDS handles scaling internally. This keeps pravinDA output
    # human-readable and lets the two functions chain correctly:
    #   df    = mr.pravinDA("data.csv")   # clean, encoded, human-readable
    #   model = mr.pravinDS(df, target=…)  # scales internally before training
    report["scaler_used"] = "None (scaling handled by pravinDS)"

    # ── re-attach target ──────────────────────────────────────────────
    if target_series is not None:
        df_features[target] = target_series.values

    report["rows_after"] = len(df_features)

    elapsed = time.time() - t0
    if cfg.verbose:
        pretty_print(report)
        log.info("pravinDA  completed in %.2fs", elapsed)

    if export_report:
        from mrpravin.core.report import export_json, export_html
        (export_html if export_report.endswith(".html") else export_json)(
            report, export_report
        )

    return (df_features, report) if return_report else df_features


# ─────────────────────────────────────────────────────────────────────────────
# pravinDS  –  AutoML pipeline  →  returns pravinML
# ─────────────────────────────────────────────────────────────────────────────

def pravinDS(
    source: Union[str, Path, pd.DataFrame],
    target: str,
    *,
    X_test: Optional[pd.DataFrame] = None,
    y_test: Optional[pd.Series]    = None,
    test_size: float               = 0.2,
    cfg: MrPravinConfig            = DEFAULT_CONFIG,
    save_model: Optional[str]      = "mrpravin_model.pkl",
    return_metrics: bool           = False,
) -> Union["pravinML", Tuple["pravinML", dict]]:
    """
    Full AutoML pipeline: clean → encode → scale → select → tune → evaluate.

    Parameters
    ----------
    source        : raw data (file path or DataFrame)
    target        : target column name
    X_test/y_test : optional pre-split test set (skips internal split)
    test_size     : fraction held out for testing (default 0.20)
    cfg           : MrPravinConfig
    save_model    : path to persist the pravinML object (None = skip)
    return_metrics: if True, return (pravinML, metrics_dict)

    Returns
    -------
    pravinML instance  –  or (pravinML, metrics_dict)
    """
    np.random.seed(cfg.random_seed)
    t0 = time.time()

    # ── 1. load & validate ────────────────────────────────────────────
    df = load(source)
    if target not in df.columns:
        raise ValueError(
            f"Target '{target}' not found. "
            f"Available columns: {list(df.columns)}"
        )

    # ── 1b. deduplicate FULL dataset before splitting ─────────────────
    # Must happen here — deduping after split breaks X/y alignment.
    rows_before = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    rows_dropped = rows_before - len(df)
    if rows_dropped > 0:
        log.info("pravinDS  dedup removed %d duplicate rows (%d → %d)",
                 rows_dropped, rows_before, len(df))

    if cfg.warn_target_leakage:
        _check_target_leakage(df, target)

    # ── 2. split BEFORE any fitting (no leakage) ─────────────────────
    y = df[target]
    X = df.drop(columns=[target])

    if X_test is not None and y_test is not None:
        X_train, y_train = X, y
    else:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=cfg.random_seed,
        )
        log.info("pravinDS  split → train %d / test %d", len(X_train), len(X_test))

    problem_type = detect_problem_type(y_train)

    # ── 3. preprocessing pipeline (fit on TRAIN only) ─────────────────
    da_report = build_report(rows_before=len(X_train))

    type_map = infer_column_types(
        X_train,
        id_unique_ratio=cfg.id_unique_ratio,
        categorical_unique_ratio=cfg.categorical_unique_ratio,
        low_cardinality_threshold=cfg.low_cardinality_threshold,
    )

    cleaner  = Cleaner(cfg)
    # deduplicate=False: full df already deduped before split (keeps X/y aligned)
    X_tr     = cleaner.fit_transform(X_train.reset_index(drop=True), type_map, da_report, deduplicate=False)

    encoder  = Encoder(cfg)
    encoder.fit(X_tr, type_map,
                target_series=y_train.reset_index(drop=True),
                report=da_report)
    X_tr     = encoder.transform(X_tr)

    # capture encoded-but-unscaled for schema — drift detection must compare
    # raw inference data vs raw training ranges (not scaled vs raw)
    X_tr_pre_scale = X_tr.copy()

    scaler   = Scaler(cfg)
    X_tr     = scaler.fit_transform(X_tr)

    feature_names = list(X_tr.columns)

    # ── 4. transform test (transform only – no fit) ───────────────────
    dummy   = {}
    X_te    = cleaner.transform(X_test.reset_index(drop=True), type_map, dummy, deduplicate=False)
    X_te    = encoder.transform(X_te)
    X_te    = scaler.transform(X_te)
    X_te    = _align_columns(X_te, feature_names)

    y_train = y_train.reset_index(drop=True)
    y_test  = y_test.reset_index(drop=True)

    # ── 5. encode target labels ───────────────────────────────────────
    le: Optional[LabelEncoder] = None
    if "classification" in problem_type:
        le      = LabelEncoder()
        y_train = pd.Series(le.fit_transform(y_train), name=target)
        y_test  = pd.Series(le.transform(y_test), name=target)

    # ── 6. model selection + hyperparameter tuning ────────────────────
    candidates = get_candidates(problem_type, cfg, cfg.random_seed)
    scoring    = get_scoring_metric(problem_type)

    best_name:  Optional[str] = None
    best_model: Any           = None
    best_score: float         = -np.inf

    for name, estimator in candidates.items():
        log.info("pravinDS  tuning %s …", name)
        try:
            fitted, score = tune(
                estimator, name, X_tr, y_train,
                scoring, cfg, cfg.cv_folds,
            )
            log.info("  %s  CV=%.4f", name, score)
            if score > best_score:
                best_score, best_model, best_name = score, fitted, name
        except Exception as exc:
            log.warning("  %s  failed: %s", name, exc)

    if best_model is None:
        raise RuntimeError(
            "All candidate models failed. Check your data and configuration."
        )

    log.info("pravinDS  winner → %s (CV=%.4f)", best_name, best_score)

    # ── 7. evaluate on held-out test set ─────────────────────────────
    metrics = evaluate(best_model, X_te, y_test, problem_type, feature_names)
    metrics["best_model_name"] = best_name
    metrics["cv_score"]        = float(best_score)

    if cfg.verbose:
        _print_ds_metrics(metrics)

    # ── 8. build InputSchema from pre-scale features ───────────────────
    # Raw (unscaled) ranges so drift detection compares like-for-like.
    schema = InputSchema.from_dataframe(X_tr_pre_scale, problem_type, target)

    # ── 9. wrap into pravinML ─────────────────────────────────────────
    da_pipeline = (cfg, type_map, cleaner, encoder, scaler)

    model = pravinML(
        model         = best_model,
        metrics       = metrics,
        problem_type  = problem_type,
        feature_names = feature_names,
        schema        = schema,
        da_pipeline   = da_pipeline,
        model_name    = best_name,
        label_encoder = le,
        training_rows = len(X_tr),
    )

    if save_model:
        model.save(save_model)

    elapsed = time.time() - t0
    log.info("pravinDS  completed in %.2fs", elapsed)

    return (model, metrics) if return_metrics else model


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _check_target_leakage(df: pd.DataFrame, target: str) -> None:
    """Warn if any feature has suspiciously high correlation with target."""
    y_num = pd.to_numeric(df[target], errors="coerce")
    if y_num.isna().all():
        return
    for col in df.columns:
        if col == target:
            continue
        x_num = pd.to_numeric(df[col], errors="coerce")
        if x_num.isna().all():
            continue
        try:
            corr = x_num.corr(y_num)
            if abs(corr) > 0.98:
                log.warning(
                    "⚠  Possible leakage: '%s' correlation=%.3f with target '%s'",
                    col, corr, target,
                )
        except Exception:
            pass


def _print_ds_metrics(metrics: dict) -> None:
    print("\n" + "═" * 58)
    print("  🤖  mrpravin  –  AutoML Results")
    print("═" * 58)
    print(f"  Best model      : {metrics.get('best_model_name', '?')}")
    print(f"  CV score        : {metrics.get('cv_score', 0):.4f}")
    for k in ("accuracy", "f1_weighted", "roc_auc", "rmse", "mae", "r2"):
        if k in metrics:
            label = k.replace("_", " ").title().ljust(16)
            print(f"  {label}: {metrics[k]:.4f}")
    print("═" * 58 + "\n")