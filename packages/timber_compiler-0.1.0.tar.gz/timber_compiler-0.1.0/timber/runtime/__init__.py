"""Timber runtime — Python ctypes wrapper for compiled C inference."""

from timber.runtime.predictor import TimberPredictor

__all__ = ["TimberPredictor"]
