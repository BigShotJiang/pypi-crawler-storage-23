"""Timber — Classical ML Inference Compiler."""

__version__ = "0.1.0"
