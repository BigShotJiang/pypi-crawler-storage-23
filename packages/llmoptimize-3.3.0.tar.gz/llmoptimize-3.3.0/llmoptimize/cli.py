"""Package CLI entrypoint."""

from server.cli import main


if __name__ == "__main__":
    main()

