# simpleworkernet/scripts/__init__.py
"""
Скрипты для управления SimpleWorkerNet
"""

from .uninstall import cleanup_with_confirmation, cli_main

__all__ = ['cleanup_with_confirmation', 'cli_main']