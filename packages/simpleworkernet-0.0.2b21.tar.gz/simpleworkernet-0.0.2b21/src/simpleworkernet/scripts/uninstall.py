# simpleworkernet/scripts/uninstall.py
"""
Скрипт для очистки данных SimpleWorkerNet
"""
import sys
import shutil
import os
from pathlib import Path
from typing import Optional, List, Tuple


def get_paths() -> dict:
    """
    Возвращает словарь с путями для разных ОС.
    
    Returns:
        Словарь с путями к директориям
    """
    paths = {}
    
    if sys.platform == 'win32':
        # Windows
        app_data = Path(os.environ.get('APPDATA', Path.home() / 'AppData' / 'Roaming'))
        local_app_data = Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData' / 'Local'))
        
        paths['config_dir'] = app_data / 'simpleworkernet'
        paths['cache_dir'] = local_app_data / 'simpleworkernet' / 'cache'
        paths['logs_dir'] = app_data / 'simpleworkernet' / 'logs'
        
    elif sys.platform == 'darwin':
        # macOS
        paths['config_dir'] = Path.home() / 'Library' / 'Application Support' / 'simpleworkernet'
        paths['cache_dir'] = Path.home() / 'Library' / 'Caches' / 'simpleworkernet'
        paths['logs_dir'] = Path.home() / 'Library' / 'Logs' / 'simpleworkernet'
        
    else:
        # Linux/Unix
        paths['config_dir'] = Path.home() / '.config' / 'simpleworkernet'
        paths['cache_dir'] = Path.home() / '.cache' / 'simpleworkernet'
        paths['logs_dir'] = Path.home() / '.local' / 'share' / 'simpleworkernet' / 'logs'
    
    return paths


def cleanup_simpleworkernet(dry_run: bool = False, mode: str = 'all') -> Tuple[bool, List[str]]:
    """
    Очищает все следы SimpleWorkerNet.
    
    Args:
        dry_run: Если True, только показывает, что будет удалено
        mode: Режим очистки ('all', 'logs', 'cache', 'config')
    
    Returns:
        Кортеж (успех, список сообщений)
    """
    messages = []
    paths = get_paths()
    success = True
    
    # 1. Удаление логов
    if mode in ('all', 'logs'):
        logs_dir = paths.get('logs_dir')
        if logs_dir and logs_dir.exists():
            try:
                if not dry_run:
                    shutil.rmtree(logs_dir)
                messages.append(f"Logs directory deleted: {logs_dir}")
            except Exception as e:
                if not dry_run:
                    messages.append(f"Error deleting logs directory: {e}")
                    success = False
        else:
            messages.append(f"Logs directory not found: {logs_dir}")
    
    # 2. Удаление кэша
    if mode in ('all', 'cache'):
        cache_dir = paths.get('cache_dir')
        if cache_dir and cache_dir.exists():
            try:
                if not dry_run:
                    shutil.rmtree(cache_dir)
                messages.append(f"Cache directory deleted: {cache_dir}")
            except Exception as e:
                if not dry_run:
                    messages.append(f"Error deleting cache directory: {e}")
                    success = False
        else:
            messages.append(f"Cache directory not found: {cache_dir}")
    
    # 3. Удаление конфигурации
    if mode in ('all', 'config'):
        config_dir = paths.get('config_dir')
        if config_dir and config_dir.exists():
            try:
                if not dry_run:
                    shutil.rmtree(config_dir)
                messages.append(f"Config directory deleted: {config_dir}")
            except Exception as e:
                if not dry_run:
                    messages.append(f"Error deleting config directory: {e}")
                    success = False
        else:
            messages.append(f"Config directory not found: {config_dir}")
    
    return success, messages


def cleanup_with_confirmation(force: bool = False, mode: str = 'all') -> bool:
    """
    Очистка с запросом подтверждения.
    
    Args:
        force: Если True, не запрашивать подтверждение
        mode: Режим очистки ('all', 'logs', 'cache', 'config')
    
    Returns:
        True при успехе, False при отмене или ошибке
    """
    print("=" * 60)
    print("SimpleWorkerNet Cleanup")
    print("=" * 60)
    
    # Показываем, что будет удалено
    success, messages = cleanup_simpleworkernet(dry_run=True, mode=mode)
    
    print("\nWill be deleted:\n")
    for msg in messages:
        print(f"  {msg}")
    
    if not force:
        print()
        response = input("\nAre you sure you want to delete these data? (y/N): ")
        if response.lower() not in ('y', 'yes', 'да'):
            print("Cleanup cancelled")
            return False
    
    print("\nCleaning up...")
    success, messages = cleanup_simpleworkernet(dry_run=False, mode=mode)
    
    print("\n" + "=" * 60)
    for msg in messages:
        print(f"  {msg}")
    print("=" * 60)
    
    if success:
        print("✅ Cleanup completed successfully")
    else:
        print("⚠️ Cleanup completed with errors")
    
    return success


def cli_main():
    """Точка входа для CLI"""
    import argparse
    
    parser = argparse.ArgumentParser(description="SimpleWorkerNet cleanup tool")
    parser.add_argument('--force', '-f', action='store_true', help='Force cleanup without confirmation')
    parser.add_argument('--logs-only', action='store_true', help='Clean only logs')
    parser.add_argument('--cache-only', action='store_true', help='Clean only cache')
    parser.add_argument('--config-only', action='store_true', help='Clean only configuration')
    parser.add_argument('--dry-run', action='store_true', help='Show what would be deleted without deleting')
    
    args = parser.parse_args()
    
    if args.logs_only:
        mode = 'logs'
    elif args.cache_only:
        mode = 'cache'
    elif args.config_only:
        mode = 'config'
    else:
        mode = 'all'
    
    return 0 if cleanup_with_confirmation(force=args.force, mode=mode) else 1


if __name__ == "__main__":
    sys.exit(cli_main())