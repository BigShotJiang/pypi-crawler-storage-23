# simpleworkernet/__init__.py
"""
SimpleWorkerNet - Python клиент для API WorkerNet с интеллектуальной обработкой данных.
"""

import atexit, sys
from pathlib import Path

from .__version__ import __version__, __author__, __email__, __license__

from .scripts.uninstall import cleanup_with_confirmation as cleanup

# Core
from .core.constants import DEBUG, INFO, WARNING, ERROR
from .core.exceptions import (
    WorkerNetError, WorkerNetConfigError, WorkerNetConnectionError,
    WorkerNetAPIError, WorkerNetCacheError, WorkerNetValidationError,
    WorkerNetSmartDataError
)
from .core.config import ConfigManager, WorkerNetConfig
from .core.logger import log

# Models
from .models.base import BaseModel, BaseCategory, smart_model, collapsed_field
from .models.primitives import vStr, vFlag, GeoPoint, additional_field, additional_data
from .models.operators import Operator, Where

# SmartData
from .smartdata import SmartData
from .core.cache import cache as SmartDataCache

# Utils
from .utils.decorators import api_method, logged_method

# API
from .core.client import WorkerNetClient

# Настройка из конфигурации
config = ConfigManager.get()

# Настраиваем логирование
log.configure(
    level=config.log_level,
    log_to_file=config.log_to_file,
    log_file=config.log_file,
    console_output=config.console_output,
    max_log_files=config.max_log_files
)

if __name__ != "__main__" and not any(arg.endswith('cleanup-simpleworkernet') for arg in sys.argv):
    log.info("=" * 60)
    log.info(f"SimpleWorkerNet v{__version__}")
    log.info("=" * 60)
    log.debug(f"Log level: {config.log_level}")
    log.debug(f"Cache: {'enabled' if config.cache_enabled else 'disabled'}")

    # Инициализация кэша
    if config.cache_enabled:
        cache_path = SmartData.get_cache_path()
        log.info(f"Cache file: {cache_path}")
        
        # Загружаем кэш
        cache_loaded = SmartData.load_cache(preload_only=True)
        
        if not cache_loaded and config.cache_enabled:
            log.info("Creating new cache...")
            
            # Импортируем модели для предзагрузки
            from .models.categories.additional_data import Additional_data
            from .models.categories.address import Address
            from .models.categories.advertising import Advertising
            from .models.categories.attach import Attach
            from .models.categories.billing import Billing
            from .models.categories.cable_route import Cable_route
            from .models.categories.call import Call
            from .models.categories.commutation import Commutation
            from .models.categories.cross import Cross
            from .models.categories.customer import Customer
            from .models.categories.cwdm import Cwdm
            from .models.categories.device import Device
            from .models.categories.employee import Employee
            from .models.categories.fiber import Fiber
            from .models.categories.gps import Gps
            from .models.categories.inventory import Inventory
            from .models.categories.key import Key
            from .models.categories.map import Map
            from .models.categories.module import Module
            from .models.categories.node import Node
            
            models = [
                Additional_data.Get_list,
                Address.Get_locality_type,
                Address.Get_alias,
                Address.Get,
                Address.Get_province,
                Address.Get_district,
                Address.Get_city,
                Address.Get_area,
                Address.Get_street,
                Address.Get_building_structure,
                Address.Get_house,
                Address.Get_level,
                Advertising.Get,
                Cable_route.Get_route,
                Cable_route.GetDuct,
                Commutation.Get_data,
                Cross.Get_list,
                Customer.Abon_hist,
                Customer.Get_customer_group,
                Customer.Get_data,
                Customer.Get_data.Agreement,
                Customer.Get_data.Traffic,
                Customer.Get_data.Phone,
                Customer.Get_data.Address,
                Customer.Get_data.Tariff,
                Customer.Get_data.Service,
                Customer.Get_data.Ip_mac,
                Customer.Get_data.Billing,
                Customer.Msg,
                Cwdm.Get,
                Device.Get_connected_ont_information,
                Device.Get_data,
                Device.Get_current_ont_data,
                Device.Get_iface_info,
                Device.Get_iface_mac,
                Device.Get_mac_list,
                Device.Get_ont_data,
                Device.Get_pon_level_history,
                Employee.Get_data,
                Employee.Get_division,
                Employee.Get_division_list,
                Employee.Get_history,
                Employee.Get_history_type,
                Employee.Get_timesheet_data,
                Fiber.Catalog_cables_get,
                Fiber.Get_fiber,
                Fiber.Get_list,
                Fiber.Map_color_get,
                Gps.Get_info,
                Gps.Get_list,
                Gps.Get_route,
                Inventory.Get_inventory,
                Inventory.Get_inventory_amount,
                Inventory.Get_inventory_catalog,
                Inventory.Get_inventory_section_catalog,
                Inventory.Get_inventory_storage,
                Inventory.Get_operation,
                Key.Get_list,
                Map.Check_entry_point_in_polygon,
                Map.Get,
                Map.Get_poly,
                Module.Get_connect_list,
                Module.Get_device_list,
                Module.Get_house_list,
                Module.Get_services_list,
                Module.Get_street_list,
                Module.Get_system_information,
                Module.Get_tariff_list,
                Module.Get_user_history,
                Module.Get_user_list,
                Module.Get_user_messages,
                Module.Get_user_state_list
            ]
            
            if models:
                log.info(f"Found {len(models)} models")
                SmartData.preload_from_models(*models, recursive=True)
                SmartData.save_cache(force=True)

    # Показываем информацию о сессии
    if config.log_to_file:
        current_log = log.get_session_log_path()
        session_id = log.get_session_id()
        log.info(f"Log file: {current_log}")
        log.info(f"Session ID: {session_id}")
        
        all_logs = log.list_session_logs(sort_by='newest')
        if len(all_logs) > 1:
            log.debug(f"Total log files: {len(all_logs)}")


    def _save_cache():
        """Сохраняет кэш при выходе"""
        try:
            if SmartData.ensure_cache_saved():
                log.info("Cache saved on exit")
        except Exception as e:
            log.error(f"Error saving cache: {e}")


    # Регистрируем сохранение кэша при выходе
    atexit.register(_save_cache)

    log.info("Initialization complete")
    log.info("=" * 60)


__all__ = [
    # Версия
    '__version__', '__author__', '__email__', '__license__',

    # Очистка данных
    'cleanup',
    
    # Клиент
    'WorkerNetClient',
    
    # Исключения
    'WorkerNetError',
    'WorkerNetConfigError',
    'WorkerNetConnectionError',
    'WorkerNetAPIError',
    'WorkerNetCacheError',
    'WorkerNetValidationError',
    'WorkerNetSmartDataError',
    
    # Конфигурация
    'ConfigManager',
    'WorkerNetConfig',
    
    # Логгер
    'log',
    'DEBUG', 'INFO', 'WARNING', 'ERROR',
    
    # SmartData
    'SmartData',
    'SmartDataCache',
    
    # Модели
    'BaseCategory',
    'BaseModel',
    'smart_model',
    'collapsed_field',
    
    # Примитивы
    'vStr',
    'vFlag',
    'GeoPoint',
    
    # Операторы
    'Operator',
    'Where',
    
    # Декораторы
    'api_method',
    'logged_method',

    # Функции
    'additional_field',
    'additional_data',
]