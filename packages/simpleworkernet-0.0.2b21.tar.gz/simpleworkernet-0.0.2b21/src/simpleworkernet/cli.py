#!/usr/bin/env python
# simpleworkernet/cli.py
"""
Интерфейс командной строки для SimpleWorkerNet
"""
import sys
import argparse
from pathlib import Path

from . import __version__
from .scripts.uninstall import cleanup_with_confirmation
from .core.config import ConfigManager
from .core.logger import log


def main():
    """Основная точка входа для CLI"""
    parser = argparse.ArgumentParser(
        description="SimpleWorkerNet command line interface",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        '--version', '-v',
        action='store_true',
        help='Show version'
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Команда cleanup
    cleanup_parser = subparsers.add_parser('cleanup', help='Clean up SimpleWorkerNet data')
    cleanup_parser.add_argument('--force', '-f', action='store_true', help='Force cleanup without confirmation')
    cleanup_parser.add_argument('--logs-only', action='store_true', help='Clean only logs')
    cleanup_parser.add_argument('--cache-only', action='store_true', help='Clean only cache')
    cleanup_parser.add_argument('--config-only', action='store_true', help='Clean only configuration')
    cleanup_parser.add_argument('--dry-run', action='store_true', help='Show what would be deleted without deleting')
    
    # Команда config
    config_parser = subparsers.add_parser('config', help='Manage configuration')
    config_subparsers = config_parser.add_subparsers(dest='config_command')
    
    # config show
    config_show = config_subparsers.add_parser('show', help='Show current configuration')
    
    # config set
    config_set = config_subparsers.add_parser('set', help='Set configuration value')
    config_set.add_argument('key', help='Configuration key')
    config_set.add_argument('value', help='Configuration value')
    
    # config reset
    config_reset = config_subparsers.add_parser('reset', help='Reset configuration to defaults')
    
    # config interactive
    config_interactive = config_subparsers.add_parser('interactive', help='Interactive configuration')
    
    args = parser.parse_args()
    
    if args.version:
        print(f"SimpleWorkerNet version {__version__}")
        return 0
    
    if args.command == 'cleanup':
        return cleanup_command(args)
    
    elif args.command == 'config':
        return config_command(args)
    
    else:
        parser.print_help()
        return 0


def cleanup_command(args):
    """Обработка команды cleanup"""
    from .scripts.uninstall import cleanup_simpleworkernet
    
    # Определяем режим очистки
    if args.logs_only:
        mode = 'logs'
    elif args.cache_only:
        mode = 'cache'
    elif args.config_only:
        mode = 'config'
    else:
        mode = 'all'
    
    if args.dry_run:
        print("\n🔍 DRY RUN MODE - nothing will be deleted\n")
        success, messages = cleanup_simpleworkernet(dry_run=True, mode=mode)
        for msg in messages:
            print(f"  {msg}")
        return 0
    
    if not args.force:
        print("\n⚠️  This will delete all SimpleWorkerNet data!")
        response = input("Are you sure? (y/N): ")
        if response.lower() not in ('y', 'yes', 'да'):
            print("Cleanup cancelled")
            return 1
    
    print("\n🧹 Cleaning up...")
    success, messages = cleanup_simpleworkernet(dry_run=False, mode=mode)
    
    for msg in messages:
        print(f"  {msg}")
    
    if success:
        print("\n✅ Cleanup completed successfully")
        return 0
    else:
        print("\n❌ Cleanup completed with errors")
        return 1


def config_command(args):
    """Обработка команды config"""
    if args.config_command == 'show':
        ConfigManager.show_config()
    elif args.config_command == 'set':
        try:
            # Пробуем преобразовать значение в соответствующий тип
            current_config = ConfigManager.get()
            current_value = getattr(current_config, args.key)
            
            if isinstance(current_value, bool):
                value = args.value.lower() in ('true', 'yes', '1', 'y')
            elif isinstance(current_value, int):
                value = int(args.value)
            elif isinstance(current_value, float):
                value = float(args.value)
            else:
                value = args.value
            
            ConfigManager.update(**{args.key: value})
            ConfigManager.save()
            print(f"✅ Configuration updated: {args.key} = {value}")
        except Exception as e:
            print(f"❌ Error: {e}")
            return 1
    elif args.config_command == 'reset':
        ConfigManager.reset()
        ConfigManager.save()
        print("✅ Configuration reset to defaults")
    elif args.config_command == 'interactive':
        ConfigManager.interactive_configure()
    else:
        ConfigManager.show_config()
    
    return 0


# Для обратной совместимости
cleanup = cleanup_command

if __name__ == "__main__":
    sys.exit(main())