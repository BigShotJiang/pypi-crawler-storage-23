# simpleworkernet/smartdata/__init__.py
"""
SmartData - интеллектуальный контейнер для обработки сложных JSON-структур
"""

from .core import SmartData
from .metadata import MetaData, PathSegment, META_KEY
from .processor import DataProcessor
from .helpers import is_primitive, sort_dict_items

__all__ = [
    'SmartData',
    'MetaData',
    'PathSegment',
    'META_KEY',
    'DataProcessor',
    'is_primitive',
    'sort_dict_items',
]