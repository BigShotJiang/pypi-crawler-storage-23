# simpleworkernet/smartdata/metadata.py
"""
Класс для работы с метаданными SmartData
"""
from __future__ import annotations
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field


@dataclass
class PathSegment:
    """
    Сегмент пути в структуре данных.
    
    Attributes:
        type: Тип сегмента ('col' - схлопнутый ключ, 'idx' - индекс в списке, 'field' - поле модели)
        value: Значение сегмента
    """
    type: str  # 'col', 'idx', 'field'
    value: str
    
    def __str__(self) -> str:
        """Строковое представление: тип:значение"""
        return f"{self.type}:{self.value}"
    
    def to_dict(self) -> Dict[str, str]:
        """Преобразует в словарь для сериализации"""
        return {'type': self.type, 'value': self.value}
    
    @classmethod
    def from_dict(cls, data: Dict[str, str]) -> 'PathSegment':
        """Создает сегмент из словаря"""
        return cls(data['type'], data['value'])


@dataclass
class MetaData:
    """
    Метаданные для элемента SmartData.
    
    Хранит информацию о положении элемента в исходной структуре.
    
    Attributes:
        path: Список сегментов пути
        attributes: Дополнительные атрибуты для расширения
    """
    
    # Путь к элементу в исходной структуре
    path: List[PathSegment] = field(default_factory=list)
    
    # Дополнительные атрибуты (для расширения)
    attributes: Dict[str, Any] = field(default_factory=dict)
    
    def get_path_string(self) -> str:
        """
        Возвращает строковое представление пути.
        
        Returns:
            Строка вида 'type1:value1/type2:value2/...'
        """
        return '/'.join(str(seg) for seg in self.path)
    
    @classmethod
    def from_path_string(cls, path_str: str) -> 'MetaData':
        """
        Создает MetaData из строки пути.
        
        Args:
            path_str: Строка вида 'type1:value1/type2:value2/...'
            
        Returns:
            Объект MetaData
        """
        if not path_str:
            return cls()
        
        segments = []
        for part in path_str.split('/'):
            if part and ':' in part:
                typ, val = part.split(':', 1)
                segments.append(PathSegment(typ, val))
        
        return cls(path=segments)
    
    def get_parent_path(self) -> str:
        """
        Возвращает путь к родительскому элементу.
        
        Returns:
            Строка с путем родителя или пустая строка
        """
        if len(self.path) <= 1:
            return ''
        return '/'.join(str(seg) for seg in self.path[:-1])
    
    def get_last_segment(self) -> Optional[PathSegment]:
        """
        Возвращает последний сегмент пути.
        
        Returns:
            Последний сегмент или None
        """
        return self.path[-1] if self.path else None
    
    def is_root(self) -> bool:
        """Проверяет, является ли элемент корневым"""
        return len(self.path) == 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Преобразует в словарь для сериализации"""
        return {
            'path': [seg.to_dict() for seg in self.path],
            'attributes': self.attributes.copy()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MetaData':
        """Создает из словаря"""
        path = [PathSegment.from_dict(p) for p in data.get('path', [])]
        attrs = data.get('attributes', {})
        return cls(path=path, attributes=attrs)
    
    def __str__(self) -> str:
        return f"MetaData(path='{self.get_path_string()}')"
    
    def __repr__(self) -> str:
        return self.__str__()


# Константа для ключа метаданных в словарях
META_KEY = '__meta__'

# Реэкспорт для удобства
__all__ = ['MetaData', 'PathSegment', 'META_KEY']