# simpleworkernet/smartdata/core.py
"""
Основной класс SmartData - контейнер для обработанных данных
"""
import json
import pickle
import gzip
from typing import (
    TypeVar, Generic, List, Dict, Any, Union, Optional, Callable, Iterator,
    overload, Type
)
from pathlib import Path

from ..core.logger import log
from ..core.cache import cache
from ..core.config import ConfigManager

from .metadata import MetaData, META_KEY
from .processor import DataProcessor
from .helpers import collapse_list, get_base_type

from ..models.operators import Operator, Where


T = TypeVar('T')


class SmartData(Generic[T]):
    """
    Контейнер для интеллектуальной обработки данных.
    
    SmartData получает от процессора подготовленные словари и
    выполняет кастинг ТОЛЬКО для корневых элементов в target_type.
    Вложенные модели создаются автоматически через BaseModel.
    
    Attributes:
        _items: List[T] - список обработанных элементов
        _target_type: Type[T] - целевой тип для корневых элементов
        _metadata_registry: Dict[int, MetaData] - реестр метаданных
        _stats: Dict[str, int] - статистика обработки
    """
    
    # Кэш (синглтон)
    _cache = cache
    
    def __init__(self, data: Any, target_type: Type[T] = Any):
        """
        Инициализирует SmartData.
        
        Args:
            data: Входные данные (любая структура)
            target_type: Целевой тип для корневых элементов
        """
        # Загружаем настройки из конфига
        smartdata_config = ConfigManager.get_smartdata_config()
        max_depth = smartdata_config.get('max_depth', 100)
        self._debug = smartdata_config.get('debug', False)
        
        # Инициализируем атрибуты
        self._target_type = target_type
        self._items: List[T] = []
        self._metadata_registry: Dict[int, MetaData] = {}
        self._stats: Dict[str, int] = {}
        
        # Обрабатываем данные, если они есть
        if data is not None:
            log.debug(f"SmartData init: data type={type(data)}, target={target_type}")
            
            # Создаем процессор для структурных преобразований
            processor = DataProcessor(max_depth=max_depth)
            result = processor.process(
                data=data,
                target_type=target_type,
                cache_func=self._is_valid_field_name if self._cache_enabled() else None
            )
            
            # Сохраняем результаты обработки
            self._metadata_registry = result.metadata_registry
            self._stats = result.stats

            # Кастинг только для корневых элементов
            self._items = self._cast_root_items(result.items, target_type)
            
            log.info(f"SmartData initialized: {len(self._items)} items")
    
    def _cast_root_items(self, items: List[Any], target_type: Type[T]) -> List[T]:
        """Выполняет кастинг только для корневых элементов"""
        if target_type is Any or target_type is None:
            return items
        
        from ..models.base import BaseModel
        
        base_type, is_list = get_base_type(target_type)
        
        is_model = False
        try:
            if isinstance(base_type, type) and issubclass(base_type, BaseModel):
                is_model = True
        except TypeError:
            pass
        
        result = []
        for item in items:
            if isinstance(item, dict):
                try:
                    if is_model:
                        # Просто передаем весь словарь как есть, включая __meta__
                        instance = base_type(**item)
                        result.append(instance)
                    else:
                        result.append(item)
                except Exception as e:
                    log.debug(f"Failed to create {base_type}: {e}")
                    result.append(item)
            else:
                result.append(item)
        
        return result
        
    def _cache_enabled(self) -> bool:
        """Проверяет, включено ли кэширование"""
        config = ConfigManager.get_cache_config()
        return config.get('enabled', True)
    
    def _is_valid_field_name(self, name: str) -> bool:
        """
        Проверяет валидность имени поля с использованием кэша.
        
        Args:
            name: Имя поля для проверки
            
        Returns:
            True если имя является валидным идентификатором Python
        """
        if not self._cache_enabled():
            return name and isinstance(name, str) and name.isidentifier()
        
        try:
            return self.__class__._cache.is_valid_field_name(name)
        except Exception:
            return name and isinstance(name, str) and name.isidentifier()
    
    # ------------------------------------------------------------------------
    # Методы работы с метаданными
    # ------------------------------------------------------------------------
    
    def get_metadata(self, item: Any) -> Optional[MetaData]:
        """
        Возвращает метаданные для элемента.
        
        Args:
            item: Элемент (модель, словарь или примитив)
            
        Returns:
            MetaData или None, если метаданные отсутствуют
        """
        if isinstance(item, dict) and META_KEY in item:
            return item[META_KEY]
        if hasattr(item, '_meta'):
            return item._meta
        return self._metadata_registry.get(id(item))
    
    def get_item_path(self, item: Any) -> str:
        """
        Возвращает путь к элементу в исходной структуре.
        
        Args:
            item: Элемент для которого нужно получить путь
            
        Returns:
            Строка с путем или пустая строка
        """
        meta = self.get_metadata(item)
        return meta.get_path_string() if meta else ''
    
    # ------------------------------------------------------------------------
    # Методы для работы с кэшем
    # ------------------------------------------------------------------------
    
    @classmethod
    def get_cache_path(cls) -> Path:
        """Возвращает путь к файлу кэша"""
        return cls._cache.get_cache_path()
    
    @classmethod
    def save_cache(cls, force: bool = False) -> bool:
        """Сохраняет кэш в файл"""
        return cls._cache.save(force)
    
    @classmethod
    def load_cache(cls, preload_only: bool = False) -> bool:
        """Загружает кэш из файла"""
        return cls._cache.load(preload_only)
    
    @classmethod
    def ensure_cache_saved(cls) -> bool:
        """Гарантирует сохранение кэша"""
        return cls._cache.ensure_saved()
    
    @classmethod
    def clear_cache(cls):
        """Очищает кэш"""
        cls._cache.clear()
    
    @classmethod
    def preload_from_models(cls, *model_classes, recursive: bool = True, **kwargs):
        """
        Предварительно загружает поля из моделей в кэш.
        
        Args:
            *model_classes: Классы моделей для загрузки
            recursive: Загружать рекурсивно вложенные модели
        """
        cls._cache.preload_from_models(*model_classes, recursive=recursive, **kwargs)
    
    @classmethod
    def set_cache_max_size(cls, size: int):
        """Устанавливает максимальный размер кэша"""
        cls._cache.set_max_size(size)
    
    # ------------------------------------------------------------------------
    # Методы работы с конфигурацией
    # ------------------------------------------------------------------------
    
    @classmethod
    def set_max_depth(cls, depth: int):
        """Устанавливает максимальную глубину рекурсии"""
        ConfigManager.update(smartdata_max_depth=depth)
        ConfigManager.save()
        log.info(f"Max depth changed to {depth}")
    
    @classmethod
    def set_debug_mode(cls, enabled: bool):
        """Включает/выключает режим отладки"""
        ConfigManager.update(smartdata_debug=enabled)
        ConfigManager.save()
        log.info(f"Debug mode: {'enabled' if enabled else 'disabled'}")
    
    # ------------------------------------------------------------------------
    # Fluent-интерфейс для фильтрации и трансформации
    # ------------------------------------------------------------------------
    
    def _derived(self, items: List[T]) -> 'SmartData[T]':
        """
        Создает новый экземпляр с теми же настройками.
        
        Args:
            items: Новый список элементов
            
        Returns:
            Новый экземпляр SmartData
        """
        new = self.__class__.__new__(self.__class__)
        new._target_type = self._target_type
        new._items = items
        new._debug = self._debug
        new._metadata_registry = self._metadata_registry
        new._stats = self._stats.copy()
        return new
    
    def filter(self, *conditions, join: str = 'AND') -> 'SmartData[T]':
        """
        Фильтрует элементы по условиям.
        
        Args:
            *conditions: Условия для фильтрации (объекты Where)
            join: 'AND' или 'OR' - как объединять условия
            
        Returns:
            Новый SmartData с отфильтрованными элементами
        """
        from ..models.operators import Where
        filtered = [
            item for item in self._items
            if (join.upper() == 'AND' and all(c.check(item) for c in conditions)) or
               (join.upper() == 'OR' and any(c.check(item) for c in conditions))
        ]
        return self._derived(filtered)
    
    def where(self, key: str, value: Any = None, op: Operator = Operator.EQ) -> 'SmartData[T]':
        """
        Фильтрует по одному условию.
        
        Args:
            key: Имя поля
            value: Значение для сравнения
            op: Оператор сравнения
            
        Returns:
            Новый SmartData с отфильтрованными элементами
        """
        from ..models.operators import Where
        return self.filter(Where(key, value, op))
    
    def sort(self, key: Optional[Callable[[T], Any]] = None, reverse: bool = False) -> 'SmartData[T]':
        """
        Сортирует элементы.
        
        Args:
            key: Функция для получения ключа сортировки
            reverse: Обратный порядок
            
        Returns:
            Новый SmartData с отсортированными элементами
        """
        return self._derived(sorted(self._items, key=key, reverse=reverse))
    
    def limit(self, count: int) -> 'SmartData[T]':
        """
        Ограничивает количество элементов.
        
        Args:
            count: Максимальное количество элементов
            
        Returns:
            Новый SmartData с первыми count элементами
        """
        return self._derived(self._items[:count])
    
    def skip(self, count: int) -> 'SmartData[T]':
        """
        Пропускает первые count элементов.
        
        Args:
            count: Количество элементов для пропуска
            
        Returns:
            Новый SmartData с элементами после пропущенных
        """
        return self._derived(self._items[count:])
    
    def map(self, func: Callable[[T], Any]) -> List[Any]:
        """
        Применяет функцию к каждому элементу.
        
        Args:
            func: Функция для применения
            
        Returns:
            Список результатов применения функции
        """
        return [func(item) for item in self._items]
    
    def group_by(self, key_func: Callable[[T], Any]) -> Dict[Any, 'SmartData[T]']:
        """
        Группирует элементы по ключу.
        
        Args:
            key_func: Функция для получения ключа группы
            
        Returns:
            Словарь {ключ: SmartData} сгруппированных элементов
        """
        groups = {}
        for item in self._items:
            key = key_func(item)
            if key not in groups:
                groups[key] = self._derived([])
            groups[key]._items.append(item)
        return groups
    
    def unique(self, key_func: Optional[Callable[[T], Any]] = None) -> 'SmartData[T]':
        """
        Оставляет только уникальные элементы.
        
        Args:
            key_func: Функция для получения ключа уникальности
            
        Returns:
            Новый SmartData с уникальными элементами
        """
        seen = set()
        unique_items = []
        for item in self._items:
            key = key_func(item) if key_func else item
            if key not in seen:
                seen.add(key)
                unique_items.append(item)
        return self._derived(unique_items)
    
    # ------------------------------------------------------------------------
    # Статистические методы
    # ------------------------------------------------------------------------
    
    def count(self) -> int:
        """Возвращает количество элементов"""
        return len(self._items)
    
    def first(self) -> Optional[T]:
        """Возвращает первый элемент или None"""
        return self._items[0] if self._items else None
    
    def last(self) -> Optional[T]:
        """Возвращает последний элемент или None"""
        return self._items[-1] if self._items else None
    
    def min(self, key_func: Optional[Callable[[T], Any]] = None) -> Optional[T]:
        """
        Возвращает минимальный элемент.
        
        Args:
            key_func: Функция для получения значения для сравнения
            
        Returns:
            Минимальный элемент или None
        """
        if not self._items:
            return None
        if key_func:
            return min(self._items, key=key_func)
        return min(self._items)
    
    def max(self, key_func: Optional[Callable[[T], Any]] = None) -> Optional[T]:
        """
        Возвращает максимальный элемент.
        
        Args:
            key_func: Функция для получения значения для сравнения
            
        Returns:
            Максимальный элемент или None
        """
        if not self._items:
            return None
        if key_func:
            return max(self._items, key=key_func)
        return max(self._items)
    
    def sum(self, key_func: Callable[[T], Union[int, float]]) -> Union[int, float]:
        """
        Суммирует значения элементов.
        
        Args:
            key_func: Функция для получения числового значения
            
        Returns:
            Сумма значений
        """
        return sum(key_func(item) for item in self._items)
    
    def avg(self, key_func: Callable[[T], Union[int, float]]) -> float:
        """
        Вычисляет среднее арифметическое.
        
        Args:
            key_func: Функция для получения числового значения
            
        Returns:
            Среднее значение
        """
        if not self._items:
            return 0.0
        total = self.sum(key_func)
        return total / len(self._items)
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Возвращает статистику обработки.
        
        Returns:
            Словарь со статистикой
        """
        return {
            'total_items': len(self._items),
            'target_type': getattr(self._target_type, '__name__', str(self._target_type)),
            'metadata_count': len(self._metadata_registry),
            'processor_stats': self._stats
        }
    
    # ------------------------------------------------------------------------
    # Методы сериализации
    # ------------------------------------------------------------------------
    
    def to_list(self) -> List[T]:
        """Возвращает список элементов"""
        return self._items.copy()

    def to_dict(self, clear_meta: bool = True, restore_structure: bool = False) -> Any:
        """
        Преобразует SmartData в словарь.
        
        Args:
            clear_meta: Если True, удаляет метаданные из результата
            restore_structure: Если True, восстанавливает исходную структуру на основе метаданных
        """
        if len(self._items) == 1:
            item = self._items[0]
            if hasattr(item, 'to_dict'):
                return item.to_dict(clear_meta=clear_meta, restore_structure=restore_structure)
            elif isinstance(item, dict):
                if clear_meta and META_KEY in item:
                    return {k: v for k, v in item.items() if k != META_KEY}
                return item.copy()
            else:
                return item
        else:
            result = []
            for item in self._items:
                if hasattr(item, 'to_dict'):
                    result.append(item.to_dict(clear_meta=clear_meta, restore_structure=restore_structure))
                elif isinstance(item, dict):
                    if clear_meta and META_KEY in item:
                        result.append({k: v for k, v in item.items() if k != META_KEY})
                    else:
                        result.append(item.copy())
                else:
                    result.append(item)
            return result
    
    @classmethod
    def from_dict(cls, data: Any, target_type: Type[T] = Any) -> 'SmartData[T]':
        """
        Создает SmartData из словаря/списка, сохраняя структуру.
        
        Args:
            data: Входные данные
            target_type: Целевой тип для кастинга
            
        Returns:
            Новый экземпляр SmartData
        """
        return cls(data, target_type)

    def to_file(self, filename: str, format: Optional[str] = None, clear_meta: bool = False):
        """
        Сохраняет данные в файл.
        
        Args:
            filename: Имя файла
            format: Формат ('json', 'pkl', 'gz')
            clear_meta: Удалить метаданные
        """
        path = Path(filename)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        if format is None:
            format = path.suffix.lstrip('.') or 'json'
        
        if format == 'json':
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(self.to_dict(clear_meta), f, indent=2, ensure_ascii=False)
        elif format == 'pkl':
            with open(path, 'wb') as f:
                pickle.dump(self, f)
        elif format == 'gz':
            with gzip.open(path, 'wb') as f:
                pickle.dump(self, f)
        else:
            raise ValueError(f"Unsupported format: {format}")
        
        log.info(f"Data saved to {path}")
    
    @classmethod
    def from_file(cls, filename: str, target_type: Type[T] = Any) -> 'SmartData[T]':
        """
        Загружает данные из файла.
        
        Args:
            filename: Имя файла
            target_type: Целевой тип для кастинга
            
        Returns:
            Экземпляр SmartData
        """
        path = Path(filename)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {filename}")
        
        if path.suffix == '.json':
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return cls(data, target_type)
        elif path.suffix == '.pkl':
            with open(path, 'rb') as f:
                return pickle.load(f)
        elif path.suffix == '.gz':
            with gzip.open(path, 'rb') as f:
                return pickle.load(f)
        else:
            raise ValueError(f"Unsupported format: {path.suffix}")
    
    def flatten(self) -> 'SmartData[Any]':
        """
        Распрямляет вложенные списки в плоский список.
        
        Returns:
            Новый SmartData с распрямленными элементами
        """
        flat_items = collapse_list(self._items, mode='flatten')
        if not isinstance(flat_items, list):
            flat_items = [flat_items]
        return self._derived(flat_items)
    
    # ------------------------------------------------------------------------
    # Массовые операции
    # ------------------------------------------------------------------------
    
    def update_all(self, **kwargs) -> 'SmartData[T]':
        """
        Обновляет все элементы.
        
        Args:
            **kwargs: Пары имя_поля=значение для обновления
            
        Returns:
            self для chain-вызовов
        """
        for item in self._items:
            for key, value in kwargs.items():
                if hasattr(item, key):
                    setattr(item, key, value)
                elif isinstance(item, dict):
                    item[key] = value
        return self
    
    def __setattr__(self, name: str, value: Any):
        """
        Позволяет массово обновлять поля через присваивание.
        
        Пример:
            data.field_name = value  # обновит поле field_name во всех элементах
        """
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            self.update_all(**{name: value})
    
    # ------------------------------------------------------------------------
    # Магические методы
    # ------------------------------------------------------------------------
    
    def __len__(self) -> int:
        return len(self._items)
    
    @overload
    def __getitem__(self, key: int) -> T: ...
    
    @overload
    def __getitem__(self, key: slice) -> 'SmartData[T]': ...
    
    @overload
    def __getitem__(self, key: str) -> List[Any]: ...
    
    def __getitem__(self, key):
        """
        Поддерживает индексацию:
        - data[0] - первый элемент
        - data[1:5] - срез элементов
        - data['field'] - список значений поля
        """
        if isinstance(key, int):
            if key < 0 or key >= len(self._items):
                raise IndexError(f"Index {key} out of range")
            return self._items[key]
        
        if isinstance(key, slice):
            return self._derived(self._items[key])
        
        if isinstance(key, str):
            result = []
            for item in self._items:
                if hasattr(item, '__dict__') and hasattr(item, key):
                    result.append(getattr(item, key, None))
                elif isinstance(item, dict):
                    result.append(item.get(key))
                else:
                    result.append(None)
            return result
        
        raise TypeError(f"Unsupported key type: {type(key).__name__}")
    
    def __getattr__(self, name: str) -> List[Any]:
        """
        Позволяет получать список значений поля через dot-нотацию.
        
        Пример:
            data.field_name  # список значений поля field_name
        """
        if name.startswith('_'):
            return super().__getattribute__(name)
        return self[name]
    
    def __iter__(self) -> Iterator[T]:
        return iter(self._items)
    
    def __contains__(self, item: T) -> bool:
        return item in self._items
    
    def __add__(self, other: Union['SmartData[T]', List[T]]) -> 'SmartData[T]':
        """Объединяет два контейнера"""
        if isinstance(other, SmartData):
            new_items = self._items + other._items
        elif isinstance(other, list):
            new_items = self._items + other
        else:
            raise TypeError(f"Cannot add SmartData with {type(other)}")
        return self._derived(new_items)
    
    def __iadd__(self, other: Union['SmartData[T]', List[T]]) -> 'SmartData[T]':
        """Добавляет элементы в текущий контейнер"""
        if isinstance(other, SmartData):
            self._items.extend(other._items)
        elif isinstance(other, list):
            self._items.extend(other)
        else:
            raise TypeError(f"Cannot add SmartData with {type(other)}")
        return self
    
    def __bool__(self) -> bool:
        return bool(self._items)

    def __eq__(self, other: Any) -> bool:
        """Сравнивает два SmartData контейнера через to_dict()"""
        if not isinstance(other, SmartData):
            return False
            
        # Сравниваем через to_dict() (без метаданных)
        return self.to_dict(clear_meta=True) == other.to_dict(clear_meta=True)
    
    def __repr__(self) -> str:
        type_name = getattr(self._target_type, '__name__', str(self._target_type))
        return f"SmartData[{type_name}](count={len(self._items)}, items={self._items})"