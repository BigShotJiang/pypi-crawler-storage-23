# simpleworkernet/smartdata/helpers.py
"""
Вспомогательные функции для SmartData
"""
import html
import types
from typing import Any, List, Dict, Tuple, Optional, Union, Set, Callable
from urllib.parse import unquote_plus
from dataclasses import is_dataclass, fields
from typing import get_origin, get_args, List as ListType, Dict as DictType, Union as UnionType

from ..core.logger import log
from .metadata import MetaData, META_KEY, PathSegment


# ------------------------------------------------------------------------
# Базовые проверки и преобразования
# ------------------------------------------------------------------------

def is_primitive(value: Any) -> bool:
    """
    Проверяет, является ли значение простым типом.
    
    Args:
        value: Значение для проверки
        
    Returns:
        True для None, int, float, str, bool
    """
    return value is None or isinstance(value, (int, float, str, bool))


def decode_string(value: Any) -> str:
    """
    Декодирует строку из URL и HTML entities.
    
    Args:
        value: Значение для декодирования
        
    Returns:
        Декодированная строка
    """
    if value is None:
        return ""
    return unquote_plus(html.unescape(str(value)), encoding="utf-8")


# ------------------------------------------------------------------------
# Работа со списками (единая функция collapse_list)
# ------------------------------------------------------------------------

def collapse_list(lst: Any, mode: str = 'auto', depth: int = 0, max_depth: int = 100) -> Any:
    """
    Универсальная функция схлопывания списков согласно ПРАВИЛУ 2.
    
    Режимы:
    - 'unpack': только распаковка одинарных матрешек
    - 'flatten': полное распрямление всех уровней
    - 'auto': автоматический режим
    
    Args:
        lst: Входной список
        mode: Режим схлопывания
        depth: Текущая глубина рекурсии
        max_depth: Максимальная глубина рекурсии
        
    Returns:
        Обработанный список
    """
    if not isinstance(lst, list):
        return lst
    
    if len(lst) == 0:
        return lst
    
    if depth > max_depth:
        log.warning(f"Max depth {max_depth} exceeded in collapse_list")
        return lst

    # ПРАВИЛО 2: Распаковываем одинарные матрешки
    while len(lst) == 1 and isinstance(lst[0], list):
        lst = lst[0]
        if len(lst) == 0:
            break
    
    if mode == 'unpack':
        return lst
    
    # Для остальных режимов продолжаем обработку
    result = []
    for item in lst:
        if isinstance(item, list):
            processed = collapse_list(item, mode, depth + 1, max_depth)
            if mode == 'flatten':
                if isinstance(processed, list):
                    result.extend(processed)
                else:
                    result.append(processed)
            else:  # 'auto' или другие режимы
                result.append(processed)
        else:
            result.append(item)
    
    return result


# ------------------------------------------------------------------------
# Работа с ключами
# ------------------------------------------------------------------------

def is_numeric_key(key: str) -> bool:
    """
    Проверяет, является ли ключ числовым (может быть отрицательным).
    
    Args:
        key: Ключ для проверки
        
    Returns:
        True если ключ можно преобразовать в число
    """
    if not key:
        return False
    if key.startswith('-') and key[1:].isdigit():
        return True
    return key.isdigit()


def all_keys_numeric(data: Dict) -> bool:
    """
    Проверяет, все ли ключи числовые.
    
    Args:
        data: Словарь для проверки
        
    Returns:
        True если все ключи (кроме META_KEY) числовые
    """
    for key in data.keys():
        if key == META_KEY:
            continue
        if not is_numeric_key(str(key)):
            return False
    return True


def all_keys_equal_values(data: Dict) -> bool:
    """
    Проверяет, равны ли строковые представления ключей значениям.
    
    Args:
        data: Словарь для проверки
        
    Returns:
        True если каждый ключ равен своему значению (как строка)
    """
    for key, value in data.items():
        if key == META_KEY:
            continue
        if str(key) != str(value):
            return False
    return True


def all_values_are_dicts(data: Dict) -> bool:
    """
    Проверяет, все ли значения - словари.
    
    Args:
        data: Словарь для проверки
        
    Returns:
        True если все значения являются словарями
    """
    for value in data.values():
        if not isinstance(value, dict):
            return False
    return True


def all_values_are_lists_of_dicts(data: Dict) -> bool:
    """
    Проверяет, все ли значения - списки словарей.
    
    Args:
        data: Словарь для проверки
        
    Returns:
        True если все значения являются списками, каждый элемент которых - словарь
    """
    for value in data.values():
        if not isinstance(value, list):
            return False
        for item in value:
            if not isinstance(item, dict):
                return False
    return True


def collect_all_keys(data: Any) -> Set[str]:
    """
    Рекурсивно собирает все ключи из данных.
    
    Args:
        data: Данные для анализа (словарь, список или примитив)
        
    Returns:
        Множество всех найденных ключей
    """
    keys = set()
    
    if isinstance(data, dict):
        keys.update(data.keys())
        for v in data.values():
            keys.update(collect_all_keys(v))
    elif isinstance(data, list):
        for item in data:
            keys.update(collect_all_keys(item))
    
    return keys


# ------------------------------------------------------------------------
# Работа с моделями и типами
# ------------------------------------------------------------------------

def get_model_fields(model_type: Any) -> Set[str]:
    """
    Возвращает имена полей модели.
    
    Args:
        model_type: Класс модели или тип
        
    Returns:
        Множество имен полей
    """
    if not model_type or model_type is Any:
        return set()
    
    if hasattr(model_type, '__annotations__'):
        return set(model_type.__annotations__.keys())
    
    if is_dataclass(model_type):
        return {f.name for f in fields(model_type)}
    
    return set()


def is_model_instance(obj: Any) -> bool:
    """
    Проверяет, является ли объект экземпляром BaseModel.
    
    Args:
        obj: Объект для проверки
        
    Returns:
        True если объект является моделью
    """
    from ..models.base import BaseModel
    return isinstance(obj, BaseModel)


def extract_model_fields(model: Any) -> List[str]:
    """
    Извлекает поля из модели.
    
    Args:
        model: Модель или класс модели
        
    Returns:
        Список имен полей
    """
    from ..models.base import BaseModel
    
    if isinstance(model, type) and issubclass(model, BaseModel):
        if hasattr(model, '__annotations__'):
            return list(model.__annotations__.keys())
    elif is_model_instance(model):
        if hasattr(model, '__dict__'):
            return [k for k in model.__dict__.keys() if not k.startswith('_')]
    elif is_dataclass(model):
        return [f.name for f in fields(model)]
    
    return []


# ------------------------------------------------------------------------
# Работа с метаданными
# ------------------------------------------------------------------------

def build_metadata(path: List[Tuple[str, str]]) -> MetaData:
    """
    Строит объект MetaData из пути.
    
    Args:
        path: Список кортежей (тип, значение)
        
    Returns:
        Объект MetaData
    """
    segments = []
    for typ, val in path:
        if typ in ('col', 'idx', 'field'):
            segments.append(PathSegment(typ, val))
    return MetaData(path=segments)


def attach_metadata(obj: Any, metadata: MetaData) -> Any:
    """
    Прикрепляет метаданные к объекту.
    
    Args:
        obj: Объект (словарь, список или примитив)
        metadata: Метаданные для прикрепления
        
    Returns:
        Объект с прикрепленными метаданными
    """
    if isinstance(obj, dict):
        obj[META_KEY] = metadata
        return obj
    elif isinstance(obj, list):
        return {
            META_KEY: metadata,
            '__type__': 'list',
            'value': obj
        }
    return obj


def extract_metadata(obj: Any, metadata_registry: Optional[Dict[int, MetaData]] = None) -> Tuple[Any, Optional[MetaData]]:
    """
    Извлекает метаданные из объекта.
    
    Args:
        obj: Объект с возможными метаданными
        metadata_registry: Реестр метаданных для примитивов
        
    Returns:
        Кортеж (объект без метаданных, метаданные или None)
    """
    if isinstance(obj, dict):
        if META_KEY in obj:
            metadata = obj[META_KEY]
            clean_obj = {k: v for k, v in obj.items() if k != META_KEY}
            return clean_obj, metadata
        return obj, None
    
    elif isinstance(obj, dict) and '__type__' in obj and META_KEY in obj:
        return obj['value'], obj[META_KEY]
    
    elif metadata_registry and id(obj) in metadata_registry:
        return obj, metadata_registry[id(obj)]
    
    return obj, None


def has_metadata(obj: Any) -> bool:
    """Проверяет, есть ли у объекта метаданные"""
    if isinstance(obj, dict):
        return META_KEY in obj
    return False


def clear_metadata(obj: Any) -> Any:
    """Очищает метаданные из объекта"""
    if isinstance(obj, dict):
        if META_KEY in obj:
            return {k: v for k, v in obj.items() if k != META_KEY}
        if 'value' in obj and META_KEY in obj:
            return obj['value']
    return obj


# ------------------------------------------------------------------------
# Работа со словарями
# ------------------------------------------------------------------------

def sort_dict_items(data: Dict) -> List[Tuple]:
    """
    Сортирует элементы словаря: сначала числовые ключи, затем строковые.
    
    Args:
        data: Словарь для сортировки
        
    Returns:
        Отсортированный список пар (ключ, значение)
    """
    items = list(data.items())
    numeric = []
    other = []
    
    for key, val in items:
        s = str(key)
        if s.isdigit():
            numeric.append((int(s), key, val))
        else:
            other.append((s, key, val))
    
    numeric.sort(key=lambda x: x[0])
    other.sort(key=lambda x: x[0])
    
    result = []
    for _, k, v in numeric:
        result.append((k, v))
    for _, k, v in other:
        result.append((k, v))
    
    return result


def safe_get(data: Union[Dict, List, Any], *keys: Any, default: Any = None) -> Any:
    """
    Безопасно получает значение из вложенной структуры.
    
    Args:
        data: Словарь или список
        *keys: Ключи для доступа
        default: Значение по умолчанию
        
    Returns:
        Значение или default
    """
    current = data
    
    for key in keys:
        if current is None:
            return default
        
        if isinstance(current, dict):
            current = current.get(key)
        elif isinstance(current, (list, tuple)) and isinstance(key, int) and 0 <= key < len(current):
            current = current[key]
        elif hasattr(current, key):
            current = getattr(current, key)
        else:
            return default
    
    return current if current is not None else default


def merge_dicts(dict1: Dict, dict2: Dict, overwrite: bool = True) -> Dict:
    """
    Рекурсивно объединяет два словаря.
    
    Args:
        dict1: Первый словарь
        dict2: Второй словарь
        overwrite: Перезаписывать существующие ключи
        
    Returns:
        Объединенный словарь
    """
    result = dict1.copy()
    
    for key, value in dict2.items():
        if key in result:
            if isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = merge_dicts(result[key], value, overwrite)
            elif overwrite:
                result[key] = value
        else:
            result[key] = value
    
    return result


# ------------------------------------------------------------------------
# Работа с типами
# ------------------------------------------------------------------------

def is_union_type(tp) -> bool:
    """
    Проверяет, является ли тип Union (включая Optional).
    
    Args:
        tp: Тип для проверки
        
    Returns:
        True если тип является Union или Optional
    """
    origin = get_origin(tp)
    return origin is Union or (hasattr(types, "UnionType") and isinstance(tp, types.UnionType))


def is_list_type(tp) -> bool:
    """
    Проверяет, является ли тип списком.
    
    Args:
        tp: Тип для проверки
        
    Returns:
        True если тип является List (или list)
    """
    origin = get_origin(tp)
    return origin is list or origin is List


def get_list_inner_type(tp):
    """
    Возвращает внутренний тип для списка.
    
    Args:
        tp: Тип списка (List[T])
        
    Returns:
        Внутренний тип T или Any, если тип не определен
    """
    if not is_list_type(tp):
        return Any
    args = get_args(tp)
    return args[0] if args else Any


def is_optional_type(tp) -> bool:
    """
    Проверяет, является ли тип Optional (Union с None).
    
    Args:
        tp: Тип для проверки
        
    Returns:
        True если тип является Optional
    """
    if not is_union_type(tp):
        return False
    args = get_args(tp)
    return type(None) in args


def get_union_types(tp):
    """
    Возвращает список типов из Union (исключая None).
    
    Args:
        tp: Union тип
        
    Returns:
        Список типов
    """
    if not is_union_type(tp):
        return [tp]
    return [t for t in get_args(tp) if t is not type(None)]


def get_base_type(target_type: Any) -> Tuple[Any, bool]:
    """
    Возвращает базовый тип и флаг, является ли исходный тип списком.
    
    Args:
        target_type: Целевой тип (может быть List[T] или T)
        
    Returns:
        Кортеж (базовый тип, является_ли_списком)
    """
    if is_list_type(target_type):
        return get_list_inner_type(target_type), True
    return target_type, False


def get_field_type(model_type: Any, field_name: str) -> Any:
    """
    Возвращает тип поля модели с учетом Generic.
    
    Args:
        model_type: Класс модели
        field_name: Имя поля
        
    Returns:
        Тип поля или None
    """
    if not model_type or model_type is Any:
        return None
    
    # Если это Generic тип
    origin = get_origin(model_type)
    if origin is not None:
        # Для List[Type] возвращаем внутренний тип
        if is_list_type(model_type):
            return get_list_inner_type(model_type)
        return model_type
    
    # Обычный класс
    if hasattr(model_type, '__annotations__'):
        return model_type.__annotations__.get(field_name)
    
    return None


# ------------------------------------------------------------------------
# Экспорт
# ------------------------------------------------------------------------

__all__ = [
    # Базовые проверки
    'is_primitive',
    'decode_string',
    
    # Работа со списками
    'collapse_list',
    
    # Работа с ключами
    'is_numeric_key',
    'all_keys_numeric',
    'all_keys_equal_values',
    'all_values_are_dicts',
    'all_values_are_lists_of_dicts',
    'collect_all_keys',
    
    # Работа с моделями
    'get_model_fields',
    'get_field_type',
    'get_base_type',
    'is_model_instance',
    'extract_model_fields',
    
    # Работа с метаданными
    'build_metadata',
    'attach_metadata',
    'extract_metadata',
    'has_metadata',
    'clear_metadata',
    
    # Работа со словарями
    'sort_dict_items',
    'safe_get',
    'merge_dicts',
    
    # Работа с типами
    'is_union_type',
    'is_list_type',
    'get_list_inner_type',
    'is_optional_type',
    'get_union_types',
]