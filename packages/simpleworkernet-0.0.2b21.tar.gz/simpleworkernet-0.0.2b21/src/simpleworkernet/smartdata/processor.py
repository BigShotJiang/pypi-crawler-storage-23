# simpleworkernet/smartdata/processor.py
"""
Процессор данных для SmartData - рекурсивная обработка структур
"""
from typing import Any, List, Dict, Tuple, Optional, Callable, Set, Type, Union
from dataclasses import dataclass, field
from ..core.logger import log
from ..core.exceptions import WorkerNetRecursionError
from .helpers import (
    is_primitive, collapse_list,
    is_numeric_key, all_keys_numeric, all_keys_equal_values,
    all_values_are_dicts, all_values_are_lists_of_dicts,
    collect_all_keys,
    build_metadata
)
from .metadata import MetaData, META_KEY


@dataclass
class ProcessingResult:
    """
    Результат обработки данных.
    
    Attributes:
        items: Список подготовленных словарей (без кастинга)
        metadata_registry: Реестр метаданных для примитивов
        stats: Статистика обработки
        target_type: Целевой тип (если указан)
    """
    items: List[Any]
    metadata_registry: Dict[int, MetaData]
    stats: Dict[str, int]
    target_type: Optional[Type] = None


class DataProcessor:
    """
    Процессор для сложных структур данных.
    
    Отвечает за структурные преобразования согласно правилам:
    1. Числовые ключи → список значений
    2. Распаковка матрешек
    3. Сохранение метаданных
    4. Невалидные ключи → правило 1
    5. Подготовка для кастинга
    6. Схлопывание одиночных контейнеров
    """
    
    def __init__(self, max_depth: int = 100):
        """
        Инициализирует процессор.
        
        Args:
            max_depth: Максимальная глубина рекурсии
        """
        self.max_depth = max_depth
        self._stats = {
            'processed_items': 0,
            'copies_made': 0,
            'recursions': 0,
            'collapsed_levels': 0,
            'lists_unpacked': 0
        }
        log.debug(f"DataProcessor initialized, max_depth={max_depth}")
    
    def process(self, data: Any, target_type: Optional[Type] = None,
                cache_func: Optional[Callable] = None) -> ProcessingResult:
        """
        Основной метод обработки данных.
        
        Args:
            data: Входные данные
            target_type: Целевой тип (для контекста)
            cache_func: Функция для проверки валидности ключей
            
        Returns:
            ProcessingResult с подготовленными данными
        """
        self.reset_stats()
        
        # Подготавливаем входные данные
        data = self._prepare_input(data)
        
        # Реестр метаданных для примитивов
        metadata_registry: Dict[int, MetaData] = {}
        
        # Структурные преобразования
        result = self._process_structural(
            data, [], 0, cache_func, metadata_registry
        )
        
        # Финальное распрямление
        if isinstance(result, list):
            result = collapse_list(result, mode='flatten')
        else:
            result = [result]
        
        log.debug(f"Prepared {len(result)} items for casting")
        log.debug(f"Stats: {self._stats}")
        
        return ProcessingResult(
            items=result,
            metadata_registry=metadata_registry,
            stats=self._stats.copy(),
            target_type=target_type
        )
    
    def get_stats(self) -> Dict[str, int]:
        """Возвращает копию статистики"""
        return self._stats.copy()
    
    def reset_stats(self):
        """Сбрасывает статистику"""
        self._stats = {
            'processed_items': 0,
            'copies_made': 0,
            'recursions': 0,
            'collapsed_levels': 0,
            'lists_unpacked': 0
        }
    
    def _prepare_input(self, data: Any) -> Any:
        """
        Подготавливает входные данные.
        
        - Кортежи → списки
        - Объекты с to_list() → списки
        """
        if isinstance(data, tuple):
            return list(data)
        if hasattr(data, 'to_list') and callable(getattr(data, 'to_list')):
            return data.to_list()
        return data
    
    def _is_valid_key(self, key: str, cache_func: Optional[Callable]) -> bool:
        """
        Проверяет валидность ключа как идентификатора Python.
        
        Args:
            key: Ключ для проверки
            cache_func: Функция для кэшированной проверки
            
        Returns:
            True если ключ валидный
        """
        if key == META_KEY:
            return True
        if cache_func:
            return cache_func(key)
        return key.isidentifier()
    
    def _process_structural(self, data: Any, path: List[Tuple[str, str]], depth: int,
                            cache_func: Optional[Callable],
                            metadata_registry: Dict[int, MetaData]) -> Any:
        """
        Структурные преобразования с сохранением логики схлопывания.
        
        Args:
            data: Текущие данные
            path: Текущий путь в структуре
            depth: Текущая глубина
            cache_func: Функция проверки ключей
            metadata_registry: Реестр метаданных
            
        Returns:
            Обработанные данные
        """
        if depth > self.max_depth:
            raise WorkerNetRecursionError(f"Max depth {self.max_depth} exceeded")
        
        self._stats['recursions'] += 1
        self._stats['processed_items'] += 1
        
        # Примитивы
        if is_primitive(data):
            if path:
                metadata_registry[id(data)] = build_metadata(path)
            return data
        
        # Списки
        if isinstance(data, list):
            return self._process_list_structural(
                data, path, depth, cache_func, metadata_registry
            )
        
        # Словари
        if isinstance(data, dict):
            return self._process_dict_structural(
                data, path, depth, cache_func, metadata_registry
            )
        
        return data

    def _process_dict_structural(self, dct: Dict, path: List[Tuple[str, str]], depth: int,
                                cache_func: Optional[Callable],
                                metadata_registry: Dict[int, MetaData]) -> Any:
        """
        Обрабатывает словарь со схлопыванием контейнеров.
        """

        # --------------------------------------------------------------------
        # ШАГ 1: Числовые ключи
        # --------------------------------------------------------------------
        if all_keys_numeric(dct):
            values = list(dct.values())
            
            # 1.1: Все значения - списки словарей (service)
            if all_values_are_lists_of_dicts(dct):
                self._stats['collapsed_levels'] += 1
                result = []
                for k, values_list in dct.items():
                    for idx, item in enumerate(values_list):
                        new_path = path + [('col', str(k)), ('idx', str(idx))]
                        processed = self._process_structural(
                            item, new_path, depth + 1, cache_func, metadata_registry
                        )
                        if isinstance(processed, list):
                            result.extend(processed)
                        else:
                            result.append(processed)
                return result
            
            # 1.2: Все значения - словари (additional_customer_data)
            elif all(isinstance(v, dict) for v in values):
                self._stats['collapsed_levels'] += 1
                result = []
                for k, v in dct.items():
                    new_path = path + [('col', str(k))]
                    processed = self._process_structural(
                        v, new_path, depth + 1, cache_func, metadata_registry
                    )
                    if isinstance(processed, list):
                        result.extend(processed)
                    else:
                        result.append(processed)
                return result
        
        # --------------------------------------------------------------------
        # ШАГ 3: Схлопывание одиночных контейнеров (traffic, tariff)
        # --------------------------------------------------------------------
        if len(dct) == 1:
            key = next(iter(dct.keys()))
            value = dct[key]
            
            inner_keys = collect_all_keys(value)
            
            valid_inner_keys = {
                k for k in inner_keys 
                if k != META_KEY and self._is_valid_key(str(k), cache_func)
            }
            
            if valid_inner_keys:
                self._stats['collapsed_levels'] += 1
                new_path = path + [('col', str(key))]

                return self._process_structural(
                    value, new_path, depth + 1, cache_func, metadata_registry
                )
        
        # --------------------------------------------------------------------
        # ШАГ 4: Обычный словарь
        # --------------------------------------------------------------------
        result = {}
        for k, v in dct.items():
            if k == META_KEY:
                # Если метаданные уже есть, сохраняем их
                result[k] = v
                continue
            
            path_type = 'field' if self._is_valid_key(str(k), cache_func) else 'col'
            new_path = path + [(path_type, str(k))]
            result[k] = self._process_structural(
                v, new_path, depth + 1, cache_func, metadata_registry
            )
        
        # Добавляем метаданные для этого уровня, если есть путь
        if path:
            result[META_KEY] = build_metadata(path)
            self._stats['copies_made'] += 1
        
        return result

    def _process_list_structural(self, lst: List, path: List[Tuple[str, str]], depth: int,
                                   cache_func: Optional[Callable],
                                   metadata_registry: Dict[int, MetaData]) -> Any:
        """
        Обрабатывает список согласно ПРАВИЛУ 2.
        
        - Распаковывает одинарные матрешки
        - Добавляет метаданные для индексов
        """
        # ПРАВИЛО 2: Распаковка одинарных матрешек
        lst = collapse_list(lst, mode='unpack')
        
        result = []
        for idx, item in enumerate(lst):
            new_path = path + [('idx', str(idx))]
            processed = self._process_structural(
                item, new_path, depth + 1, cache_func, metadata_registry
            )
            if processed is not None:
                result.append(processed)
        
        return result