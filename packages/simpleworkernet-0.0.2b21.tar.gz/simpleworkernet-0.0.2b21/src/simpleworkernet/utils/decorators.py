# simpleworkernet/utils/decorators.py
"""
Декораторы для SimpleWorkerNet
"""
import functools
import time
import threading
import inspect
from typing import TypeVar, Generic, List, Dict, Any, Union, Literal, Type, Optional, Callable, get_type_hints, get_origin, get_args
from functools import wraps
from enum import IntFlag, StrEnum
from pathlib import Path

from ..core.typing import ApiRet, ApiRetBool, ApiRetSData, T
from ..core.logger import log
from ..core.exceptions import WorkerNetAPIError, WorkerNetError
from ..smartdata.core import SmartData

def logged_method(func):
    """
    Декоратор для автоматического логирования вызовов методов.
    
    Логирует вызов метода в debug режиме и ошибки в error режиме.
    
    Args:
        func: Метод для декорирования
        
    Returns:
        Декорированный метод
    """
    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        class_name = self.__class__.__name__
        method_name = func.__name__
        
        # Не логируем слишком частые вызовы
        if method_name not in ['_deep_cast', '_process_structural']:
            log.debug(f"Call: {class_name}.{method_name}()")
        
        try:
            result = func(self, *args, **kwargs)
            return result
        except Exception as e:
            log.error(f"Error in {class_name}.{method_name}(): {e}")
            raise
    
    return wrapper


def api_method(model: Union[Type[T], Type[Any]] = Any) -> Callable:
    """
    Декоратор для методов API категорий.
    
    Преобразует ответ API в SmartData контейнер или в указанную модель.
    
    Args:
        model: Целевая модель для преобразования данных (Any для сырого ответа)
        
    Returns:
        Декорированная функция
        
    Example:
        >>> @api_method(Customer)
        >>> def get_data(self, customer_id: int):
        >>>     return {'customer_id': customer_id}
        
        >>> # Вернет SmartData[Customer]
        >>> customers = client.Customer.get_data(123)
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            log.debug(f"API Method: {self.__class__.__name__}.{func.__name__}()")
            
            # Получаем подготовленные параметры
            prepared_kwargs = func(self, *args, **kwargs)
            final_params = prepared_kwargs if isinstance(prepared_kwargs, dict) else kwargs
            
            try:
                # Получаем метод API
                api_action = getattr(getattr(self._client, self._category), func.__name__)
            except AttributeError as e:
                log.error(f"API error: method {self._category}.{func.__name__} not found")
                raise WorkerNetAPIError(f"API method not found: {self._category}.{func.__name__}")
            
            try:
                # Выполняем запрос
                log.debug(f"API call: {self._category}.{func.__name__}")
                response = api_action(**final_params)
                
                # Если нужно вернуть сырой ответ
                if model is Any or getattr(self, '_is_ret_origin', False):
                    log.debug(f"Returning raw response")
                    return response
                    
            except WorkerNetError as e:
                # Пробрасываем ошибки WorkerNet
                if model is Any:
                    raise
                log.warning(f"API error in {self._category}.{func.__name__}: {e}")
                return None
            except Exception as e:
                # Неожиданная ошибка
                log.error(f"Unexpected error in {self._category}.{func.__name__}: {e}")
                raise WorkerNetAPIError(f"API error: {e}")
            
            # Обработка ответа
            return _process_api_response(response, model, self._category, func.__name__)
            
        return wrapper
    return decorator


def _process_api_response(
    response: Any, 
    model: Type, 
    category: str, 
    action: str
) -> ApiRet:
    """
    Обрабатывает ответ API и преобразует в SmartData.
    
    Args:
        response: Ответ от API
        model: Целевая модель
        category: Категория API
        action: Действие
        
    Returns:
        Обработанный ответ
    """
    log.debug(f"Processing response {category}.{action}")
    
    # Для списков или модулей сразу создаем SmartData
    if isinstance(response, list) or category == 'module':
        result = SmartData(response, model)
        log.debug(f"SmartData created: {len(result)} items")
        return result
    
    # Не словарь - возвращаем как есть
    if not isinstance(response, dict):
        log.debug(f"Response not dict: {type(response)}")
        return response
    
    # Проверяем наличие результата
    result = response.get('result')
    
    # Ищем данные (первый ключ не 'result' и не 'error')
    data_key = None
    for key in response:
        key_lower = str(key).lower()
        if key_lower not in ('result', 'error', 'Error'):
            data_key = key
            break
    
    data = response.get(data_key) if data_key else None
    
    if data is not None:
        log.debug(f"Data found under key '{data_key}'")
        return SmartData(data, model)
    
    # Если данных нет, возвращаем результат
    return result == 'OK' if result is not None else None


def log_method(level: str = 'debug', log_args: bool = True, log_result: bool = False):
    """
    Декоратор для логирования вызовов методов с параметрами.
    
    Args:
        level: Уровень логирования ('debug', 'info', 'warning', 'error')
        log_args: Логировать аргументы
        log_result: Логировать результат
        
    Returns:
        Декорированная функция
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            class_name = args[0].__class__.__name__ if args else ''
            method_name = func.__name__
            full_name = f"{class_name}.{method_name}" if class_name else method_name
            
            if log_args:
                args_str = ", ".join(str(a) for a in args[1:3])
                if len(args) > 3:
                    args_str += f"... (+{len(args)-3})"
                kwargs_str = ", ".join(f"{k}={v}" for k, v in list(kwargs.items())[:3])
                if len(kwargs) > 3:
                    kwargs_str += f"... (+{len(kwargs)-3})"
                
                params = []
                if args_str:
                    params.append(args_str)
                if kwargs_str:
                    params.append(kwargs_str)
                
                call_msg = f"{full_name}({', '.join(params)})"
            else:
                call_msg = full_name
            
            log_method = getattr(log, level.lower())
            log_method(f"Call: {call_msg}")
            
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                
                elapsed = (time.time() - start_time) * 1000
                log.debug(f"Completed in {elapsed:.2f}ms")
                
                if log_result:
                    result_str = str(result)[:100]
                    if len(str(result)) > 100:
                        result_str += "..."
                    log.debug(f"Result: {result_str}")
                
                return result
                
            except Exception as e:
                log.error(f"Error in {full_name}: {e}")
                raise
                
        return wrapper
    return decorator


def retry(max_attempts: int = 3, delay: float = 1.0, backoff: float = 2.0):
    """
    Декоратор для повторных попыток выполнения функции при ошибках.
    
    Args:
        max_attempts: Максимальное количество попыток
        delay: Начальная задержка между попытками (секунды)
        backoff: Множитель задержки (каждая следующая попытка * backoff)
        
    Returns:
        Декорированная функция
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            current_delay = delay
            last_exception = None
            
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    
                    if attempt == max_attempts:
                        log.error(f"All {max_attempts} attempts failed for {func.__name__}: {e}")
                        raise
                    
                    log.warning(f"Attempt {attempt}/{max_attempts} failed: {e}. Retrying in {current_delay:.1f}s")
                    
                    time.sleep(current_delay)
                    current_delay *= backoff
            
            raise last_exception
        return wrapper
    return decorator


def cache_result(ttl_seconds: Optional[int] = None, max_size: int = 100):
    """
    Декоратор для кэширования результатов функции.
    
    Args:
        ttl_seconds: Время жизни кэша в секундах (None - бессрочно)
        max_size: Максимальный размер кэша
        
    Returns:
        Декорированная функция
    """
    cache = {}
    cache_times = {}
    
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Создаем ключ кэша из аргументов
            key = str(args) + str(sorted(kwargs.items()))
            
            # Проверяем наличие в кэше
            if key in cache:
                if ttl_seconds is not None:
                    age = time.time() - cache_times[key]
                    if age < ttl_seconds:
                        log.debug(f"Cache hit for {func.__name__}")
                        return cache[key]
                    else:
                        log.debug(f"Cache expired for {func.__name__}")
                        del cache[key]
                        del cache_times[key]
                else:
                    log.debug(f"Cache hit for {func.__name__}")
                    return cache[key]
            
            # Выполняем функцию
            result = func(*args, **kwargs)
            
            # Ограничиваем размер кэша
            if len(cache) >= max_size:
                # Удаляем самую старую запись
                oldest_key = min(cache_times.keys(), key=lambda k: cache_times[k])
                del cache[oldest_key]
                del cache_times[oldest_key]
                log.debug(f"Cache cleaned: oldest entry removed")
            
            # Сохраняем результат
            cache[key] = result
            cache_times[key] = time.time()
            log.debug(f"Cache miss for {func.__name__}, result saved")
            
            return result
        return wrapper
    return decorator


def deprecated(reason: str = "", alternative: Optional[str] = None):
    """
    Декоратор для пометки устаревших функций.
    
    Args:
        reason: Причина устаревания
        alternative: Альтернативный метод/функция
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            message = f"{func.__name__} is deprecated"
            if reason:
                message += f": {reason}"
            if alternative:
                message += f". Use {alternative} instead"
            
            log.warning(message)
            return func(*args, **kwargs)
        return wrapper
    return decorator


def synchronized(lock=None):
    """
    Декоратор для синхронизации доступа к методу (thread-safe).
    
    Args:
        lock: Объект блокировки (если None, создается новый RLock)
    """
    import threading
    
    if lock is None:
        lock = threading.RLock()
    
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            with lock:
                return func(*args, **kwargs)
        return wrapper
    return decorator


def singleton(cls):
    """
    Декоратор для создания класса-синглтона.
    
    Args:
        cls: Класс для преобразования в синглтон
        
    Returns:
        Класс-синглтон
    """
    instances = {}
    
    @wraps(cls)
    def get_instance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
            log.debug(f"Singleton instance created: {cls.__name__}")
        return instances[cls]
    
    return get_instance


def async_method(func: Callable) -> Callable:
    """
    Декоратор для выполнения метода в отдельном потоке.
    
    Args:
        func: Функция для выполнения
        
    Returns:
        Обертка, запускающая функцию в потоке
    """
    import threading
    
    @wraps(func)
    def wrapper(*args, **kwargs):
        thread = threading.Thread(target=func, args=args, kwargs=kwargs)
        thread.daemon = True
        thread.start()
        log.debug(f"Async thread started for {func.__name__}")
        return thread
    
    return wrapper


def validate_args(**validators):
    """
    Декоратор для валидации аргументов функции.
    
    Args:
        **validators: Словарь {имя_аргумента: функция_валидатор}
        
    Returns:
        Декорированная функция
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            sig = inspect.signature(func)
            bound = sig.bind(*args, **kwargs)
            bound.apply_defaults()
            
            for arg_name, validator in validators.items():
                if arg_name in bound.arguments:
                    value = bound.arguments[arg_name]
                    if not validator(value):
                        raise ValueError(f"Argument '{arg_name}' = {value} failed validation")
            
            return func(*args, **kwargs)
        return wrapper
    return decorator


def timer(log_level: str = 'debug'):
    """
    Декоратор для измерения времени выполнения функции.
    
    Args:
        log_level: Уровень логирования
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            start = time.perf_counter()
            result = func(*args, **kwargs)
            elapsed = (time.perf_counter() - start) * 1000
            
            log_method = getattr(log, log_level)
            log_method(f"{func.__name__} completed in {elapsed:.2f}ms")
            
            return result
        return wrapper
    return decorator


def ensure_session(func: Callable) -> Callable:
    """
    Декоратор для методов API, требующих активной сессии.
    
    Args:
        func: Метод API
        
    Returns:
        Декорированная функция
    """
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if not hasattr(self, '_session') or self._session is None:
            log.debug("Session not active, creating new")
            self.session()
        return func(self, *args, **kwargs)
    return wrapper


def memoize(func: Callable) -> Callable:
    """
    Простой декоратор для мемоизации результатов функции.
    
    Args:
        func: Функция для мемоизации
        
    Returns:
        Декорированная функция
    """
    cache = {}
    
    @wraps(func)
    def wrapper(*args, **kwargs):
        key = str(args) + str(sorted(kwargs.items()))
        if key not in cache:
            cache[key] = func(*args, **kwargs)
            log.debug(f"Memoized {func.__name__}{args}")
        return cache[key]
    
    return wrapper


def abstract_method(func: Callable) -> Callable:
    """
    Декоратор для пометки абстрактного метода.
    
    Args:
        func: Метод класса
        
    Returns:
        Декорированная функция
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        raise NotImplementedError(f"Abstract method {func.__name__} must be implemented")
    
    return wrapper


__all__ = [
    'logged_method',
    'api_method',
    'log_method',
    'retry',
    'cache_result',
    'deprecated',
    'synchronized',
    'singleton',
    'async_method',
    'validate_args',
    'timer',
    'ensure_session',
    'memoize',
    'abstract_method',
]