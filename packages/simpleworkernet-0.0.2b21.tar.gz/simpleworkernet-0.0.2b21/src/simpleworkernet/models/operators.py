import types, json, pickle, gzip, re, os, html, inspect, time, tempfile, hashlib, atexit
from typing import TypeVar, Generic, List, Iterable, Generator, Iterator, Dict, Any, Union, Literal, Type, Optional, Callable, get_type_hints, get_origin, get_args, dataclass_transform
from dataclasses import dataclass, fields, is_dataclass
from urllib.parse import unquote_plus
from functools import wraps
from enum import IntFlag, StrEnum
from pathlib import Path

class Operator(StrEnum):
    """Операторы сравнения"""
    EQ = '=='
    """Равно: =="""
    NE = '!='
    """Не равно: !="""
    GT = '>'
    """Больше: >"""
    LT = '<'
    """Меньше: <"""
    GTE = '>='
    """Больше или равно: >="""
    LTE = '<='
    """Меньше или равно: <="""
    LIKE = 'LIKE'
    """Частичное совпадение"""
    IN = 'IN'
    """Вхождение в список"""
    BETWEEN = 'BETWEEN'
    """проверка диапазона [min, max], включая значения min,max - в любом порядке"""
    REGEX = 'REGEX'
    """поиск по регулярному выражению"""

class Where:
    """Поиск по условиям"""

    def __init__(self, key: str, value: Any, op: Operator = Operator.EQ):
        self.key, self.value, self.op = key, value, op

    def check(self, item: Any) -> bool:

        # Извлекаем значение (атрибут или ключ словаря)
        target = getattr(item, self.key, item.get(self.key) if isinstance(item, dict) else None)

        # Вспомогательная функция для сравнения с приведением типов
        def compare(v1, v2, op_override=None):
            operation = op_override or self.op
            try:
                if operation == Operator.EQ: return v1 == v2
                if operation == Operator.NE: return v1 != v2
                if operation == Operator.GT: return v1 > v2
                if operation == Operator.LT: return v1 < v2
                if operation == Operator.GTE: return v1 >= v2
                if operation == Operator.LTE: return v1 <= v2
                return False
            except TypeError:
                try: 
                    # Пробуем привести v2 к типу v1 и повторить
                    return compare(v1, type(v1)(v2), op_override=operation)
                except: return False

        match self.op:
            case Operator.LIKE: 
                return str(self.value).lower() in str(target).lower()
            case Operator.IN: 
                return target in self.value
            case Operator.REGEX: 
                return bool(re.search(str(self.value), str(target)))
            case Operator.BETWEEN:
                if not isinstance(self.value, (list, tuple)) or len(self.value) != 2:
                    return False
                # Возвращаем True, если target >= v_min И target <= v_max
                return compare(target, min(map(float, self.value)), Operator.GTE) and compare(target, max(map(float, self.value)), Operator.LTE)
            case _: 
                return compare(target, self.value)