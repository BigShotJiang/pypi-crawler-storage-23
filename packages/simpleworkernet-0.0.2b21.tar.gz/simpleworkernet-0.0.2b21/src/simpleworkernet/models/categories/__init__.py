# simpleworkernet/models/categories/__init__.py
"""
Категории API WorkerNet
"""

from .address import Address
from .customer import Customer
from .device import Device
from .employee import Employee
from .fiber import Fiber
from .map import Map
from .module import Module
from .additional_data import Additional_data
from .advertising import Advertising
from .attach import Attach
from .billing import Billing
from .cable_route import Cable_route
from .call import Call
from .commutation import Commutation
from .cross import Cross
from .cwdm import Cwdm
from .gps import Gps
from .inventory import Inventory
from .key import Key
from .node import Node

__all__ = [
    'Address',
    'Customer',
    'Device',
    'Employee',
    'Fiber',
    'Map',
    'Module',
    'Additional_data',
    'Advertising',
    'Attach',
    'Billing',
    'Cable_route',
    'Call',
    'Commutation',
    'Cross',
    'Cwdm',
    'Gps',
    'Inventory',
    'Key',
    'Node',
]