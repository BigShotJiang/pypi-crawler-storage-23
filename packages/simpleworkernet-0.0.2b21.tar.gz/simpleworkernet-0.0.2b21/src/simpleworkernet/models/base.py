# simpleworkernet/models/base.py
"""
Базовые модели данных
"""
import inspect
import types
from typing import Any, Dict, List, Optional, get_type_hints, dataclass_transform
from dataclasses import dataclass, is_dataclass, fields
from functools import wraps

from ..core.logger import log
from ..utils.decorators import logged_method
from ..smartdata.metadata import META_KEY, MetaData, PathSegment
from ..smartdata.helpers import (
    collapse_list, is_primitive,
    is_union_type, is_list_type, get_list_inner_type,
    is_optional_type, get_union_types
)


@dataclass_transform()
def smart_model(cls=None, **kwargs):
    """Декоратор для создания dataclass модели"""
    params = {"init": False, "repr": False}
    params.update(kwargs)
    if cls is None:
        return lambda c: dataclass(c, **params)
    return dataclass(cls, **params)


def collapsed_field(level: int = -1):
    """Декоратор для доступа к схлопнутым ключам"""
    def decorator(func):
        @property
        def getter(self):
            meta = getattr(self, META_KEY, None)
            if not meta or not meta.path:
                return None
            segments = meta.path
            if level == -1:
                selected = segments[-1]
            elif 0 <= level < len(segments):
                selected = segments[level]
            else:
                return None
            return selected.value
        return getter
    return decorator


class BaseModel:
    """
    Базовый класс для всех моделей данных.
    
    Метаданные хранятся в поле __meta__ (META_KEY) как обычное поле модели.
    """
    
    # Кэш аннотаций для быстрого доступа
    _annotations_cache = {}
    
    @logged_method
    def __init__(self, *args, **kwargs):
        log.debug(f"Creating {self.__class__.__name__}")
        
        # Получаем аннотации полей
        hints = self._get_annotations()
        
        # Обрабатываем все поля из kwargs
        for field_name in hints.keys():
            if field_name in kwargs:
                value = kwargs[field_name]
                field_type = hints[field_name]
                is_field_list = is_list_type(field_type)
                
                try:
                    # Для метаданных не делаем глубокий кастинг
                    if field_name == META_KEY:
                        setattr(self, field_name, value)
                        log.debug(f"  → Set metadata: {value}")
                    elif isinstance(value, list) and not is_field_list and len(value) == 1:
                        casted = self._deep_cast(field_type, value[0])
                        setattr(self, field_name, casted)
                    else:
                        casted = self._deep_cast(field_type, value)
                        setattr(self, field_name, casted)
                except Exception as e:
                    log.warning(f"Error casting field {field_name}: {e}")
                    setattr(self, field_name, value)
            else:
                # Поле есть в аннотациях, но отсутствует в данных
                setattr(self, field_name, None)
        
        # Сохраняем дополнительные поля (не из аннотаций)
        for name, value in kwargs.items():
            if name not in hints and name != META_KEY:
                log.debug(f"  → additional field '{name}'")
                setattr(self, name, value)
        
        self._postprocess_object()
    
    def _get_annotations(self) -> Dict[str, Any]:
        """Получает аннотации полей с кэшированием"""
        cls = self.__class__
        if cls not in self._annotations_cache:
            # Получаем оригинальные аннотации
            base_hints = get_type_hints(cls)
            # Добавляем META_KEY, если его там нет
            if META_KEY not in base_hints:
                base_hints[META_KEY] = Optional[MetaData]
            self._annotations_cache[cls] = base_hints
        return self._annotations_cache[cls]

    @logged_method
    def _deep_cast(self, target_t, val):
        """
        Глубокое рекурсивное приведение значения к целевому типу.
        """
        if hasattr(target_t, '__name__'):
            log.debug(f"  🔍 _deep_cast: target={target_t.__name__}, val type={type(val)}")
        
        # Базовые случаи
        if target_t is Any or target_t is type(None) or val is None:
            return val
        
        # Обработка Union/Optional
        if is_union_type(target_t):
            for t in get_union_types(target_t):
                try:
                    return self._deep_cast(t, val)
                except Exception:
                    continue
            if is_optional_type(target_t):
                return None
            return val

        is_target_list = is_list_type(target_t)
        
        if is_target_list:
            inner_t = get_list_inner_type(target_t)
            log.debug(f"     target is List[{inner_t}]")
        else:
            inner_t = target_t
            if hasattr(target_t, '__name__'):
                log.debug(f"     target is {target_t.__name__}")
        
        # ------------------------------------------------------------
        # ШАГ 1: Если значение - словарь, пробуем **kwargs
        # ------------------------------------------------------------
        if isinstance(val, dict):
            log.debug(f"     processing dict with {len(val)} keys")
            
            actual_class = target_t
            if hasattr(target_t, '__origin__') and isinstance(target_t.__origin__, type):
                actual_class = target_t.__origin__
            
            # Пробуем создать через **kwargs
            try:
                result = actual_class(**val)
                log.debug(f"     ✅ **kwargs succeeded")
                return result
            except Exception as e:
                log.debug(f"     ❌ **kwargs failed: {e}")
            
            # Если не получилось, обрабатываем поля рекурсивно
            field_types = {}
            if isinstance(actual_class, type) and hasattr(actual_class, '__annotations__'):
                field_types = actual_class.__annotations__
            
            processed_dict = {}
            for k, v in val.items():
                if k == META_KEY:
                    processed_dict[k] = v
                    continue
                field_type = field_types.get(k, Any)
                processed_dict[k] = self._deep_cast(field_type, v)
            
            # Пробуем создать из обработанного словаря
            try:
                result = actual_class(**processed_dict)
                log.debug(f"     ✅ **processed_dict succeeded")
                return result
            except Exception as e:
                log.debug(f"     ❌ **processed_dict failed: {e}")
            
            return processed_dict
        
        # ------------------------------------------------------------
        # ШАГ 2: Если значение - список
        # ------------------------------------------------------------
        if isinstance(val, list):
            log.debug(f"     processing list of {len(val)} elements")
            
            # Определяем тип элементов списка
            all_dicts = all(isinstance(item, dict) for item in val)
            all_primitives = all(is_primitive(item) for item in val)
            all_lists = all(isinstance(item, list) for item in val)
            
            # СЛУЧАЙ 1: Список словарей
            if all_dicts:
                log.debug(f"     list of dicts")
                result = []
                for item in val:
                    casted = self._deep_cast(inner_t, item)
                    if casted is not None:
                        result.append(casted)
                return result
            
            # СЛУЧАЙ 2: Список списков
            elif all_lists:
                log.debug(f"     list of lists")
                result = []
                for item in val:
                    casted = self._deep_cast(inner_t, item)
                    if casted is not None:
                        result.append(casted)
                return result
            
            # СЛУЧАЙ 3: Плоский список примитивов
            elif all_primitives:
                log.debug(f"     flat list of primitives")
                
                # Если целевой тип - список
                if is_target_list:
                    # Пробуем создать один объект из всего списка
                    try:
                        single_obj = self._deep_cast(inner_t, val)
                        return [single_obj]
                    except Exception as e:
                        log.debug(f"     failed to create from list: {e}")
                        result = []
                        for item in val:
                            casted = self._deep_cast(inner_t, item)
                            if casted is not None:
                                result.append(casted)
                        return result
                else:
                    # Целевой тип - не список
                    try:
                        return target_t(val)
                    except Exception as e:
                        log.debug(f"     failed to create from list: {e}")
                        result = []
                        for item in val:
                            casted = self._deep_cast(inner_t, item)
                            if casted is not None:
                                result.append(casted)
                        if len(result) == 1:
                            return result[0]
                        return result
            
            # СЛУЧАЙ 4: Смешанный список
            else:
                log.debug(f"     mixed list")
                result = []
                for item in val:
                    casted = self._deep_cast(inner_t, item)
                    if casted is not None:
                        result.append(casted)
                
                if not is_target_list and len(result) == 1:
                    return result[0]
                return result
        
        # ------------------------------------------------------------
        # ШАГ 3: Пробуем target_t(val)
        # ------------------------------------------------------------
        try:
            result = target_t(val)
            log.debug(f"     ✅ target_t(val) succeeded")
            return result
        except Exception as e:
            log.debug(f"     ❌ target_t(val) failed: {e}")
        
        # ------------------------------------------------------------
        # ШАГ 4: Базовое приведение
        # ------------------------------------------------------------
        try:
            if isinstance(target_t, type):
                result = target_t(val)
                log.debug(f"     ✅ direct cast succeeded")
                return result
        except Exception as e:
            log.debug(f"     ❌ direct cast failed: {e}")
        
        return val
    
    # ------------------------------------------------------------------------
    # Доступ к метаданным
    # ------------------------------------------------------------------------
    
    @property
    def meta(self) -> Optional[MetaData]:
        """Возвращает метаданные объекта из поля __meta__"""
        return getattr(self, META_KEY, None)
    
    def get_path(self) -> str:
        """Возвращает путь к объекту в исходной структуре"""
        meta = self.meta
        return meta.get_path_string() if meta else ""
    
    def get_collapsed_keys(self, type_filter: str = 'col') -> List[str]:
        """Возвращает список схлопнутых ключей из метаданных"""
        meta = self.meta
        if not meta:
            return []
        return [seg.value for seg in meta.path if type_filter is None or seg.type == type_filter]
    
    # ------------------------------------------------------------------------
    # Безопасный доступ к атрибутам
    # ------------------------------------------------------------------------
    
    def __getattr__(self, name: str) -> Any:
        if name.startswith('__') and name.endswith('__'):
            raise AttributeError(name)
        
        if name in self._get_annotations():
            return None
        
        raise AttributeError(f"'{self.__class__.__name__}' has no attribute '{name}'")
    
    def __setattr__(self, name: str, value: Any):
        super().__setattr__(name, value)
    
    def __getitem__(self, key):
        if isinstance(key, int):
            values = [v for k, v in self.__dict__.items() 
                     if not k.startswith('_') and k != META_KEY]
            return values[key] if key < len(values) else None
        return getattr(self, key)
    
    # ------------------------------------------------------------------------
    # Методы для работы с данными
    # ------------------------------------------------------------------------
    
    def _postprocess_object(self):
        """Постобработка объекта после создания"""
        if not hasattr(self, '__dict__'):
            return
        for key, value in self.__dict__.items():
            if key.startswith('_') or key == META_KEY:
                continue
            setattr(self, key, self._postprocess_value(value))

    def _postprocess_value(self, value):
        """Рекурсивная постобработка значения"""
        if isinstance(value, list):
            return [self._postprocess_value(item) for item in value]
        if isinstance(value, dict):
            return {k: self._postprocess_value(v) for k, v in value.items() if k != META_KEY}
        if isinstance(value, BaseModel):
            value._postprocess_object()
        return value

    def to_dict(self, clear_meta: bool = True, restore_structure: bool = False) -> Dict[str, Any]:
        """
        Преобразует модель в словарь.
        
        Args:
            clear_meta: Если True, удаляет метаданные из результата
            restore_structure: Если True, восстанавливает исходную структуру на основе метаданных
        """
        def _restore_from_meta(obj: Any, meta: Optional[MetaData]) -> Any:
            """Восстанавливает структуру на основе метаданных"""
            if not meta or not meta.path:
                return obj
            
            # Получаем значение объекта
            if hasattr(obj, 'to_dict'):
                value = obj.to_dict(clear_meta=clear_meta, restore_structure=False)
            elif isinstance(obj, dict):
                value = {k: v for k, v in obj.items() if k != META_KEY}
            elif isinstance(obj, list):
                value = [_restore_from_meta(item, None) for item in obj]
            else:
                value = obj
            
            # Строим структуру с конца пути
            current = value
            path_segments = list(meta.path)  # копируем путь
            
            # Для service: path = [field:service, col:14, idx:0]
            # Нужно построить: {col:14: [value]}
            while path_segments:
                segment = path_segments.pop()
                if segment.type == 'col':
                    # Создаем словарь с ключом из col
                    current = {segment.value: current}
                elif segment.type == 'idx':
                    # Создаем список с элементом на позиции idx
                    idx = int(segment.value)
                    lst = [None] * (idx + 1)
                    lst[idx] = current
                    current = lst
                # field пропускаем, так как это имя поля в модели
            
            return current
        
        def _merge_structures(a: Any, b: Any) -> Any:
            """Объединяет две структуры (для нескольких элементов с общим путем)"""
            if a is None:
                return b
            if b is None:
                return a
            
            # Оба словаря
            if isinstance(a, dict) and isinstance(b, dict):
                result = a.copy()
                for key, value in b.items():
                    if key in result:
                        result[key] = _merge_structures(result[key], value)
                    else:
                        result[key] = value
                return result
            
            # Оба списка
            if isinstance(a, list) and isinstance(b, list):
                max_len = max(len(a), len(b))
                result = [None] * max_len
                for i in range(max_len):
                    val_a = a[i] if i < len(a) else None
                    val_b = b[i] if i < len(b) else None
                    if val_a is not None and val_b is not None:
                        result[i] = _merge_structures(val_a, val_b)
                    else:
                        result[i] = val_a if val_a is not None else val_b
                return result
            
            # b имеет приоритет
            return b
        
        def _process_field(name: str, value: Any, meta: Optional[MetaData]) -> Any:
            """Обрабатывает поле с учетом метаданных"""
            if not restore_structure or not meta:
                # Обычная сериализация
                if hasattr(value, 'to_dict'):
                    return value.to_dict(clear_meta=clear_meta, restore_structure=False)
                elif isinstance(value, list):
                    return [_process_field(name, item, None) for item in value]
                elif isinstance(value, dict):
                    if clear_meta and META_KEY in value:
                        return {k: v for k, v in value.items() if k != META_KEY}
                    return value.copy()
                else:
                    return value
            
            # Восстанавливаем структуру по метаданным
            restored = _restore_from_meta(value, meta)
            return restored
        
        # Основная логика
        result = {}
        
        for key, value in self.__dict__.items():
            if key.startswith('_'):
                continue
            
            if key == META_KEY:
                if not clear_meta:
                    result[key] = value
                continue
            
            # Получаем метаданные для этого поля (если есть)
            field_meta = None
            if hasattr(self, META_KEY):
                obj_meta = getattr(self, META_KEY)
                if obj_meta and obj_meta.path:
                    # Ищем в пути сегмент с именем поля
                    for i, segment in enumerate(obj_meta.path):
                        if segment.type == 'field' and segment.value == key:
                            # Метаданные для этого поля - все что после field
                            field_meta = MetaData(path=obj_meta.path[i+1:])
                            break
            
            # Обрабатываем значение
            result[key] = _process_field(key, value, field_meta)
        
        return result
    
    def has_field(self, name: str) -> bool:
        """Проверяет, есть ли поле в аннотациях модели"""
        return name in self._get_annotations()
    
    def get(self, name: str, default: Any = None) -> Any:
        """Безопасно получает значение поля"""
        if not self.has_field(name):
            raise AttributeError(f"'{self.__class__.__name__}' has no field '{name}'")
        return getattr(self, name, default)
    
    def __repr__(self) -> str:
        attrs = []
        for k, v in self.__dict__.items():
            if not k.startswith('_'):
                if k == META_KEY and v:
                    attrs.append(f"meta={v.get_path_string()}")
                elif k != META_KEY:
                    attrs.append(f"{k}={v!r}")
        return f"{self.__class__.__name__}({', '.join(attrs)})"


class BaseCategory:
    """Базовый класс для всех категорий API"""
    
    _is_ret_origin = False
    
    def __init__(self, client: Any):
        self._client = client
        self._category = self.__class__.__name__.lower()
    
    def _request(self, action: str, **params) -> Any:
        self._client._current_category = self._category
        return self._client._exec(action, **params)
    
    @staticmethod
    def _return_original_response(is_ret_origin: bool = True):
        BaseCategory._is_ret_origin = is_ret_origin
    
    def __getattr__(self, name: str):
        def method(**kwargs):
            return self._request(name, **kwargs)
        return method