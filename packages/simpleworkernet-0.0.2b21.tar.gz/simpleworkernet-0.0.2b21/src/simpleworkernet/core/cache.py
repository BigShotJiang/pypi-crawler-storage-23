# simpleworkernet/core/cache.py
"""
Менеджер кэша для SmartData
"""
import time
import pickle
import tempfile
import hashlib
from pathlib import Path
from typing import Dict, Any, List, Optional, Set
from dataclasses import dataclass, field

from .logger import log
from .exceptions import WorkerNetCacheError


@dataclass
class CacheStats:
    """Статистика кэша"""
    hits: int = 0
    misses: int = 0
    numeric_hits: int = 0
    access_count: Dict[str, int] = field(default_factory=dict)
    total_operations: int = 0
    last_save_time: float = 0
    last_load_time: float = 0


class SmartDataCache:
    """
    Менеджер кэша для SmartData.
    
    Кэширует результаты проверки валидности имен полей для оптимизации.
    Реализован как синглтон.
    """
    
    _instance = None
    _field_name_cache: Dict[str, bool] = {}
    _numeric_cache: Dict[str, bool] = {}
    _stats: CacheStats = CacheStats()
    
    # Настройки из конфигурации
    _enabled: bool = True
    _max_size: int = 50000
    _evict_threshold: float = 0.9
    _evict_percent: float = 0.2
    _auto_save_enabled: bool = True
    _cache_dir: Optional[Path] = None
    
    _cache_file: Optional[Path] = None
    _cache_version: str = "1.0"
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._cache_file is None:
            self._init_from_config()
    
    def _init_from_config(self):
        """Инициализирует кэш из конфигурации"""
        from .config import ConfigManager
        config = ConfigManager.get_cache_config()
        
        self._enabled = config.get('enabled', True)
        self._max_size = config.get('max_size', 50000)
        self._evict_threshold = config.get('evict_threshold', 0.9)
        self._evict_percent = config.get('evict_percent', 0.2)
        self._auto_save_enabled = config.get('auto_save', True)
        
        cache_dir = config.get('cache_dir')
        if cache_dir:
            self._cache_dir = Path(cache_dir)
        else:
            temp_dir = Path(tempfile.gettempdir()) / "workernet_cache"
            self._cache_dir = temp_dir
        
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._generate_cache_path()
        
        log.debug(f"Cache initialized: enabled={self._enabled}, max_size={self._max_size}")
    
    def _generate_cache_path(self):
        """Генерирует уникальный путь к файлу кэша"""
        import inspect
        frame = inspect.currentframe()
        while frame:
            if frame.f_code.co_name == '<module>':
                module_path = Path(frame.f_code.co_filename).parent
                break
            frame = frame.f_back
        else:
            module_path = Path.cwd()
        
        hash_str = hashlib.md5(str(module_path).encode()).hexdigest()[:8]
        self._cache_file = self._cache_dir / f"cache_{hash_str}.pkl"
    
    def enable(self):
        """Включает кэширование"""
        self._enabled = True
        log.info("Cache enabled")
    
    def disable(self):
        """Отключает кэширование"""
        self._enabled = False
        log.info("Cache disabled")
    
    def is_enabled(self) -> bool:
        """Проверяет, включено ли кэширование"""
        return self._enabled
    
    def get_cache_path(self) -> Path:
        """Возвращает путь к файлу кэша"""
        return self._cache_file
    
    def save(self, force: bool = False) -> bool:
        """
        Сохраняет кэш в файл.
        
        Args:
            force: Принудительное сохранение даже если автосохранение отключено
            
        Returns:
            True при успехе
        """
        if not self._enabled:
            log.debug("Cache disabled, save skipped")
            return False
        
        if not self._auto_save_enabled and not force:
            log.debug("Auto-save disabled, skipping")
            return False
        
        cache_file = self.get_cache_path()
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        
        cache_data = {
            'version': self._cache_version,
            'timestamp': time.time(),
            'field_name_cache': dict(self._field_name_cache),
            'numeric_cache': dict(self._numeric_cache),
            'access_count': dict(self._stats.access_count),
            'hits': self._stats.hits,
            'misses': self._stats.misses,
            'numeric_hits': self._stats.numeric_hits,
        }
        
        try:
            with open(cache_file, 'wb') as f:
                pickle.dump(cache_data, f)
            
            self._stats.last_save_time = time.time()
            size_kb = cache_file.stat().st_size / 1024
            
            log.info(f"Cache saved: {len(self._field_name_cache)} fields, {size_kb:.1f} KB")
            return True
            
        except Exception as e:
            raise WorkerNetCacheError(f"Error saving cache: {e}")
    
    def load(self, preload_only: bool = False) -> bool:
        """
        Загружает кэш из файла.
        
        Args:
            preload_only: Загрузить только данные, без статистики
            
        Returns:
            True при успехе
        """
        if not self._enabled:
            log.debug("Cache disabled, load skipped")
            return False
        
        cache_file = self.get_cache_path()
        
        if not cache_file.exists():
            log.info("Cache file not found")
            return False
        
        try:
            with open(cache_file, 'rb') as f:
                cache_data = pickle.load(f)
            
            if cache_data.get('version') != self._cache_version:
                log.warning(f"Cache version mismatch")
                return False
            
            self._field_name_cache = cache_data.get('field_name_cache', {})
            self._numeric_cache = cache_data.get('numeric_cache', {})
            
            if not preload_only:
                self._stats.access_count = cache_data.get('access_count', {})
                self._stats.hits = cache_data.get('hits', 0)
                self._stats.misses = cache_data.get('misses', 0)
                self._stats.numeric_hits = cache_data.get('numeric_hits', 0)
            
            self._stats.last_load_time = time.time()
            
            log.info(f"Cache loaded: {len(self._field_name_cache)} fields")
            return True
            
        except Exception as e:
            raise WorkerNetCacheError(f"Error loading cache: {e}")
    
    def ensure_saved(self) -> bool:
        """Гарантирует сохранение кэша (например, при выходе)"""
        if not self._enabled:
            return False
        
        if self._field_name_cache or self._numeric_cache:
            log.debug("Saving cache (forced)")
            return self.save(force=True)
        
        log.debug("Cache empty, no save needed")
        return False
    
    def clear(self):
        """Очищает кэш"""
        fields_before = len(self._field_name_cache)
        numbers_before = len(self._numeric_cache)
        
        self._field_name_cache.clear()
        self._numeric_cache.clear()
        self._stats.access_count.clear()
        self._stats.hits = 0
        self._stats.misses = 0
        self._stats.numeric_hits = 0
        self._stats.total_operations += 1
        
        log.info(f"Cache cleared: removed {fields_before} fields, {numbers_before} numbers")
    
    def is_valid_field_name(self, name: str) -> bool:
        """
        Проверяет, является ли имя валидным идентификатором Python.
        Использует кэш для оптимизации.
        
        Args:
            name: Имя для проверки
            
        Returns:
            True если имя валидное
        """
        if not self._enabled:
            return name and isinstance(name, str) and name.isidentifier()
        
        if not name or not isinstance(name, str):
            return False
        
        self._stats.total_operations += 1
        self._track_access(name)
        
        # Быстрый путь для чисел
        if name.isdigit():
            if name in self._numeric_cache:
                self._stats.numeric_hits += 1
                return False
            self._numeric_cache[name] = False
            self._stats.misses += 1
            self._check_size()
            return False
        
        # Основной кэш
        cached = self._field_name_cache.get(name)
        if cached is not None:
            self._stats.hits += 1
            return cached
        
        result = name.isidentifier()
        self._field_name_cache[name] = result
        self._stats.misses += 1
        self._check_size()
        
        return result
    
    def _track_access(self, name: str):
        """Отслеживает частоту доступа для статистики"""
        if not self._enabled:
            return
        if name not in self._stats.access_count:
            self._stats.access_count[name] = 0
        self._stats.access_count[name] += 1
    
    def _check_size(self):
        """Проверяет размер кэша и при необходимости выполняет вытеснение"""
        if not self._enabled:
            return
        total_size = len(self._field_name_cache) + len(self._numeric_cache)
        if total_size >= self._max_size * self._evict_threshold:
            log.info(f"Cache reached {total_size}/{self._max_size}")
            self._evict_least_used()
    
    def _evict_least_used(self):
        """Удаляет наименее используемые записи"""
        if not self._stats.access_count:
            return
        sorted_items = sorted(self._stats.access_count.items(), key=lambda x: x[1])
        total_to_remove = max(1, int(len(sorted_items) * self._evict_percent))
        to_remove = {name for name, _ in sorted_items[:total_to_remove]}
        
        removed = 0
        for name in to_remove:
            if name in self._field_name_cache:
                del self._field_name_cache[name]
                removed += 1
            if name in self._numeric_cache:
                del self._numeric_cache[name]
                removed += 1
            if name in self._stats.access_count:
                del self._stats.access_count[name]
        
        if removed > 0:
            log.info(f"Cache evicted: removed {removed} least used entries")
    
    def get_stats(self) -> Dict[str, Any]:
        """Возвращает статистику кэша"""
        total = self._stats.hits + self._stats.misses
        return {
            'enabled': self._enabled,
            'total_operations': self._stats.total_operations,
            'total': total,
            'hits': self._stats.hits,
            'misses': self._stats.misses,
            'numeric_hits': self._stats.numeric_hits,
            'field_cache_size': len(self._field_name_cache),
            'numeric_cache_size': len(self._numeric_cache),
            'max_size': self._max_size,
            'hit_rate': (self._stats.hits / total * 100) if total > 0 else 0,
            'last_save': self._stats.last_save_time,
            'last_load': self._stats.last_load_time,
        }

    def preload_from_models(self, *model_classes, recursive: bool = True, max_depth: int = 10):
        """
        Предварительно загружает поля из моделей в кэш.
        
        Args:
            *model_classes: Классы моделей для загрузки
            recursive: Загружать рекурсивно вложенные модели
            max_depth: Максимальная глубина рекурсии
        """
        if not self._enabled:
            log.debug("Cache disabled, preload skipped")
            return
        
        from typing import get_type_hints, get_origin, get_args, List, Dict, Union
        from ..models.base import BaseModel
        
        log.info(f"Preloading {len(model_classes)} models into cache...")
        
        if not model_classes:
            log.warning("No models to preload")
            return
        
        before = len(self._field_name_cache)
        processed = set()
        
        def _unwrap_type(typ) -> type:
            """Извлекает внутренний тип из Generic"""
            origin = get_origin(typ)
            args = get_args(typ)
            if origin is Union:
                for arg in args:
                    if arg is not type(None):
                        return _unwrap_type(arg)
                return typ
            if origin in (list, List) and args:
                return _unwrap_type(args[0])
            if origin in (dict, Dict) and len(args) > 1:
                return _unwrap_type(args[1])
            return typ
        
        def _get_fields(model_class) -> List[str]:
            """Возвращает список полей модели"""
            try:
                if hasattr(model_class, '__annotations__'):
                    return list(model_class.__annotations__.keys())
                elif hasattr(model_class, '__dataclass_fields__'):
                    return list(model_class.__dataclass_fields__.keys())
            except:
                pass
            return []
        
        def process_model(model_class, depth=0):
            """Рекурсивно обрабатывает модель"""
            if id(model_class) in processed:
                return
            processed.add(id(model_class))
            
            fields = _get_fields(model_class)
            log.debug(f"Processing model {model_class.__name__}: {len(fields)} fields")
            
            # Добавляем поля в кэш
            for field in fields:
                if field not in self._field_name_cache:
                    self._field_name_cache[field] = True
                    if field not in self._stats.access_count:
                        self._stats.access_count[field] = 0
            
            if not recursive or depth >= max_depth:
                return
            
            # Обрабатываем вложенные модели
            try:
                hints = get_type_hints(model_class)
                for field_name, field_type in hints.items():
                    inner_type = _unwrap_type(field_type)
                    if (isinstance(inner_type, type) and
                        hasattr(inner_type, '__base__') and
                        inner_type.__base__ == BaseModel):
                        log.debug(f"  Nested model: {inner_type.__name__}")
                        process_model(inner_type, depth + 1)
            except Exception as e:
                log.error(f"Error processing {model_class.__name__}: {e}")
        
        # Обрабатываем каждую модель
        for i, model_class in enumerate(model_classes, 1):
            log.debug(f"Processing model {i}/{len(model_classes)}: {model_class.__name__}")
            try:
                process_model(model_class)
            except Exception as e:
                log.error(f"Error preloading {model_class.__name__}: {e}")
        
        added = len(self._field_name_cache) - before
        if added:
            log.info(f"Added {added} new fields to cache (total: {len(self._field_name_cache)})")
    
    def print_stats(self):
        """Выводит статистику кэша"""
        stats = self.get_stats()
        log.info(f"Cache stats: hits={stats['hits']}, misses={stats['misses']}, "
                f"hit_rate={stats['hit_rate']:.1f}%, size={stats['field_cache_size']}")
    
    def setup_auto_save(self, enable: bool = True):
        """Включает/выключает автосохранение"""
        self._auto_save_enabled = enable
        log.info(f"Cache auto-save: {'enabled' if enable else 'disabled'}")
    
    def set_max_size(self, size: int):
        """Устанавливает максимальный размер кэша"""
        old_size = self._max_size
        self._max_size = max(1000, min(size, 100000))
        log.info(f"Cache max size changed: {old_size} -> {self._max_size}")


# Глобальный экземпляр
cache = SmartDataCache()