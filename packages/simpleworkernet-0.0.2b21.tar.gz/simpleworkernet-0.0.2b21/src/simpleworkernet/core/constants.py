# simpleworkernet/core/constants.py
"""
Константы и функции путей по умолчанию для SimpleWorkerNet
"""
import sys
import os
from pathlib import Path
from typing import Final

# Константы для логирования
DEBUG: Final = 10
INFO: Final = 20
WARNING: Final = 30
ERROR: Final = 40
CRITICAL: Final = 50

# Имя логгера
LOGGER_NAME: Final = "workernet"


def get_default_log_path() -> Path:
    """
    Возвращает путь к файлу лога по умолчанию в зависимости от ОС.
    
    Returns:
        Path: Путь к файлу лога
    """
    if sys.platform == 'win32':
        app_data = Path(os.environ.get('APPDATA', Path.home() / 'AppData'))
        return app_data / 'simpleworkernet' / 'logs' / 'workernet.log'
    elif sys.platform == 'darwin':
        return Path.home() / 'Library' / 'Logs' / 'simpleworkernet' / 'workernet.log'
    else:
        return Path.home() / '.local' / 'share' / 'simpleworkernet' / 'logs' / 'workernet.log'


def get_default_cache_dir() -> Path:
    """
    Возвращает путь к директории кэша по умолчанию в зависимости от ОС.
    
    Returns:
        Path: Путь к директории кэша
    """
    if sys.platform == 'win32':
        local_app_data = Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData' / 'Local'))
        return local_app_data / 'simpleworkernet' / 'cache'
    elif sys.platform == 'darwin':
        return Path.home() / 'Library' / 'Caches' / 'simpleworkernet'
    else:
        return Path.home() / '.cache' / 'simpleworkernet'