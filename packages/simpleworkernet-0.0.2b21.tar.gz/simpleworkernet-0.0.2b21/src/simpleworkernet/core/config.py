# simpleworkernet/core/config.py
"""
Утилита для управления настройками пакета
"""
from __future__ import annotations
import os
import sys
import json
from pathlib import Path
from typing import Optional, Dict, Any, Union, Literal
from dataclasses import dataclass, asdict, field

from .constants import get_default_log_path, get_default_cache_dir
from .constants import DEBUG, INFO, WARNING, ERROR


# Типы для конфигурации с возможностью выбора
LogLevel = Literal['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
CacheEvictStrategy = Literal['lru', 'lfu', 'fifo']
SmartDataMode = Literal['normal', 'aggressive', 'conservative']


def _get_logger():
    """Возвращает экземпляр логгера с отложенным импортом"""
    from .logger import log
    return log


@dataclass
class WorkerNetConfig:
    """
    Конфигурация пакета с аннотированными вариантами выбора.
    
    Attributes:
        log_level: Уровень логирования
        log_to_file: Сохранять логи в файл
        log_file: Путь к файлу логов
        max_log_files: Максимальное количество файлов логов
        console_output: Вывод в консоль
        cache_enabled: Включить кэширование
        cache_max_size: Максимальный размер кэша
        cache_evict_strategy: Стратегия вытеснения
        cache_evict_threshold: Порог вытеснения
        cache_evict_percent: Процент вытеснения
        cache_auto_save: Автосохранение кэша
        cache_dir: Директория кэша
        default_timeout: Таймаут запросов
        max_retries: Максимальное количество повторов
        user_agent: User-Agent для запросов
        smartdata_max_depth: Максимальная глубина рекурсии
        smartdata_mode: Режим обработки
        smartdata_debug: Режим отладки
    """
    
    # Общие настройки
    log_level: LogLevel = 'INFO'
    """Уровень логирования: DEBUG, INFO, WARNING, ERROR, CRITICAL"""
    
    log_to_file: bool = False
    """Сохранять логи в файл"""
    
    log_file: Optional[str] = None
    """Путь к файлу логов"""
    
    max_log_files: int = 50
    """Максимальное количество файлов логов"""
    
    console_output: bool = False
    """Вывод в консоль"""
    
    # Настройки кэша
    cache_enabled: bool = True
    """Включить кэширование"""
    
    cache_max_size: int = 50000
    """Максимальный размер кэша"""
    
    cache_evict_strategy: CacheEvictStrategy = 'lru'
    """Стратегия вытеснения: lru, lfu, fifo"""
    
    cache_evict_threshold: float = 0.9
    """Порог вытеснения (0.0-1.0)"""
    
    cache_evict_percent: float = 0.2
    """Процент вытеснения (0.0-1.0)"""
    
    cache_auto_save: bool = True
    """Автосохранение кэша"""
    
    cache_dir: Optional[str] = None
    """Директория кэша"""
    
    # Настройки API
    default_timeout: int = 30
    """Таймаут запросов в секундах"""
    
    max_retries: int = 3
    """Максимальное количество повторов"""
    
    user_agent: str = "SimpleWorkerNet/1.0"
    """User-Agent для запросов"""
    
    # Настройки SmartData
    smartdata_max_depth: int = 100
    """Максимальная глубина рекурсии"""
    
    smartdata_mode: SmartDataMode = 'normal'
    """Режим обработки: normal, aggressive, conservative"""
    
    smartdata_debug: bool = False
    """Режим отладки SmartData"""
    
    def __post_init__(self):
        """Инициализация после создания"""
        if self.log_file is None:
            self.log_file = str(get_default_log_path())
        
        if self.cache_dir is None:
            self.cache_dir = str(get_default_cache_dir())
    
    def to_dict(self) -> Dict[str, Any]:
        """Преобразует в словарь"""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'WorkerNetConfig':
        """Создает из словаря"""
        valid_keys = cls.__annotations__.keys()
        filtered = {k: v for k, v in data.items() if k in valid_keys}
        return cls(**filtered)
    
    def get_options_for(self, field: str) -> list:
        """
        Возвращает доступные варианты для поля с Literal аннотацией.
        
        Args:
            field: Имя поля
            
        Returns:
            Список доступных вариантов
        """
        if field in self.__annotations__:
            typ = self.__annotations__[field]
            if hasattr(typ, '__args__'):
                return list(typ.__args__)
        return []


class ConfigManager:
    """
    Менеджер конфигурации с сохранением в JSON файл.
    Реализован как синглтон.
    """
    
    _instance = None
    _config: WorkerNetConfig = None
    _config_file: Optional[Path] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._config is None:
            self._init_config()
    
    # ------------------------------------------------------------------------
    # Properties для всех настроек
    # ------------------------------------------------------------------------
    
    @property
    def log_level(self) -> str:
        """Уровень логирования"""
        return self.get().log_level
    
    @log_level.setter
    def log_level(self, value: str):
        self.update(log_level=value)
        self.save(apply_to_logger=True)
    
    @property
    def log_to_file(self) -> bool:
        """Сохранять логи в файл"""
        return self.get().log_to_file
    
    @log_to_file.setter
    def log_to_file(self, value: bool):
        self.update(log_to_file=value)
        self.save(apply_to_logger=True)
    
    @property
    def log_file(self) -> str:
        """Путь к файлу логов"""
        return self.get().log_file
    
    @log_file.setter
    def log_file(self, value: str):
        self.update(log_file=value)
        self.save(apply_to_logger=True)
    
    @property
    def max_log_files(self) -> int:
        """Максимальное количество файлов логов"""
        return self.get().max_log_files
    
    @max_log_files.setter
    def max_log_files(self, value: int):
        self.update(max_log_files=value)
        self.save(apply_to_logger=True)
    
    @property
    def console_output(self) -> bool:
        """Вывод в консоль"""
        return self.get().console_output
    
    @console_output.setter
    def console_output(self, value: bool):
        self.update(console_output=value)
        self.save(apply_to_logger=True)
    
    @property
    def cache_enabled(self) -> bool:
        """Включить кэширование"""
        return self.get().cache_enabled
    
    @cache_enabled.setter
    def cache_enabled(self, value: bool):
        self.update(cache_enabled=value)
        self.save()
        # Применяем к кэшу
        from .cache import cache
        if value:
            cache.enable()
        else:
            cache.disable()
    
    @property
    def cache_max_size(self) -> int:
        """Максимальный размер кэша"""
        return self.get().cache_max_size
    
    @cache_max_size.setter
    def cache_max_size(self, value: int):
        self.update(cache_max_size=value)
        self.save()
        from .cache import cache
        cache.set_max_size(value)
    
    @property
    def cache_evict_strategy(self) -> str:
        """Стратегия вытеснения"""
        return self.get().cache_evict_strategy
    
    @cache_evict_strategy.setter
    def cache_evict_strategy(self, value: str):
        self.update(cache_evict_strategy=value)
        self.save()
    
    @property
    def cache_evict_threshold(self) -> float:
        """Порог вытеснения"""
        return self.get().cache_evict_threshold
    
    @cache_evict_threshold.setter
    def cache_evict_threshold(self, value: float):
        self.update(cache_evict_threshold=value)
        self.save()
    
    @property
    def cache_evict_percent(self) -> float:
        """Процент вытеснения"""
        return self.get().cache_evict_percent
    
    @cache_evict_percent.setter
    def cache_evict_percent(self, value: float):
        self.update(cache_evict_percent=value)
        self.save()
    
    @property
    def cache_auto_save(self) -> bool:
        """Автосохранение кэша"""
        return self.get().cache_auto_save
    
    @cache_auto_save.setter
    def cache_auto_save(self, value: bool):
        self.update(cache_auto_save=value)
        self.save()
        from .cache import cache
        cache.setup_auto_save(value)
    
    @property
    def cache_dir(self) -> str:
        """Директория кэша"""
        return self.get().cache_dir
    
    @cache_dir.setter
    def cache_dir(self, value: str):
        self.update(cache_dir=value)
        self.save()
    
    @property
    def default_timeout(self) -> int:
        """Таймаут запросов в секундах"""
        return self.get().default_timeout
    
    @default_timeout.setter
    def default_timeout(self, value: int):
        self.update(default_timeout=value)
        self.save()
    
    @property
    def max_retries(self) -> int:
        """Максимальное количество повторов"""
        return self.get().max_retries
    
    @max_retries.setter
    def max_retries(self, value: int):
        self.update(max_retries=value)
        self.save()
    
    @property
    def user_agent(self) -> str:
        """User-Agent для запросов"""
        return self.get().user_agent
    
    @user_agent.setter
    def user_agent(self, value: str):
        self.update(user_agent=value)
        self.save()
    
    @property
    def smartdata_max_depth(self) -> int:
        """Максимальная глубина рекурсии"""
        return self.get().smartdata_max_depth
    
    @smartdata_max_depth.setter
    def smartdata_max_depth(self, value: int):
        self.update(smartdata_max_depth=value)
        self.save()
    
    @property
    def smartdata_mode(self) -> str:
        """Режим обработки SmartData"""
        return self.get().smartdata_mode
    
    @smartdata_mode.setter
    def smartdata_mode(self, value: str):
        self.update(smartdata_mode=value)
        self.save()
    
    @property
    def smartdata_debug(self) -> bool:
        """Режим отладки SmartData"""
        return self.get().smartdata_debug
    
    @smartdata_debug.setter
    def smartdata_debug(self, value: bool):
        self.update(smartdata_debug=value)
        self.save()
    
    # ------------------------------------------------------------------------
    # Основные методы
    # ------------------------------------------------------------------------
    
    def clear_all(self) -> bool:
        """Полная очистка всех сохраненных данных"""
        log = _get_logger()
        
        config_file_cleared = self.clear_config_file()
        self._config = WorkerNetConfig()
        
        log.info("Full configuration cleanup completed")
        return config_file_cleared
    
    def clear_config_file(self) -> bool:
        """Удаляет файл конфигурации"""
        log = _get_logger()
        
        if self._config_file and self._config_file.exists():
            try:
                self._config_file.unlink()
                log.info(f"Config file {self._config_file} deleted")
                return True
            except Exception as e:
                log.error(f"Error deleting config file: {e}")
                return False
        return False
    
    def _init_config(self):
        """Инициализирует конфигурацию"""
        if sys.platform == 'win32':
            app_data = Path(os.environ.get('APPDATA', Path.home() / 'AppData' / 'Roaming'))
        else:
            app_data = Path.home() / '.config'
        
        self._config_file = app_data / 'simpleworkernet' / 'config.json'
        self._config_file.parent.mkdir(parents=True, exist_ok=True)
        
        self.load()
    
    def _ensure_log_directory(self):
        """Создает директорию для логов"""
        if self._config and self._config.log_file:
            log_path = Path(self._config.log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
    
    def _ensure_cache_directory(self):
        """Создает директорию для кэша"""
        if self._config and self._config.cache_dir:
            cache_path = Path(self._config.cache_dir)
            cache_path.mkdir(parents=True, exist_ok=True)
    
    def load(self) -> WorkerNetConfig:
        """Загружает конфигурацию из файла"""
        if self._config is not None:
            return self._config
        
        config_data = {}
        
        if self._config_file.exists():
            try:
                with open(self._config_file, 'r', encoding='utf-8') as f:
                    config_data = json.load(f)
            except Exception as e:
                print(f"Warning: Failed to load config: {e}")
        
        self._config = WorkerNetConfig.from_dict(config_data)
        
        self._ensure_log_directory()
        self._ensure_cache_directory()
        
        return self._config
    
    def apply_to_logger(self):
        """Применяет текущую конфигурацию к логгеру"""
        from .logger import log
        config = self.get()
        
        log.set_level(config.log_level)
        log.configure(
            level=config.log_level,
            log_to_file=config.log_to_file,
            log_file=config.log_file,
            console_output=config.console_output,
            max_log_files=config.max_log_files
        )
        
        log.debug("Configuration applied to logger")

    def save(self, apply_to_logger: bool = True) -> bool:
        """
        Сохраняет конфигурацию в файл.
        
        Args:
            apply_to_logger: Применить изменения к логгеру сразу
        """
        log = _get_logger()
        
        if self._config is None:
            return False
        
        config_dict = self._config.to_dict()
        
        self._ensure_log_directory()
        self._ensure_cache_directory()
        
        try:
            with open(self._config_file, 'w', encoding='utf-8') as f:
                json.dump(config_dict, f, indent=2, ensure_ascii=False)
            log.info(f"Configuration saved to {self._config_file}")
            
            if apply_to_logger:
                self.apply_to_logger()
            
            return True
        except Exception as e:
            log.error(f"Error saving to file: {e}")
            return False
    
    def get(self) -> WorkerNetConfig:
        """Возвращает текущую конфигурацию"""
        if self._config is None:
            self.load()
        return self._config
    
    def update(self, **kwargs) -> 'ConfigManager':
        """
        Обновляет параметры конфигурации.
        
        Args:
            **kwargs: Пары имя_параметра=значение
        """
        log = _get_logger()
        
        if self._config is None:
            self._config = WorkerNetConfig()
        
        changes = []
        for key, value in kwargs.items():
            if hasattr(self._config, key):
                old_value = getattr(self._config, key)
                if old_value != value:
                    setattr(self._config, key, value)
                    changes.append(f"{key}: {old_value} -> {value}")
        
        self._ensure_log_directory()
        self._ensure_cache_directory()
        
        if changes:
            log.debug(f"Configuration updated: {', '.join(changes)}")
        
        return self
    
    def reset(self) -> 'ConfigManager':
        """Сбрасывает конфигурацию на значения по умолчанию"""
        log = _get_logger()
        
        old_config = self._config
        self._config = WorkerNetConfig()
        
        self._ensure_log_directory()
        self._ensure_cache_directory()
        
        if old_config:
            log.info("Configuration reset to defaults")
        
        return self
    
    def get_log_config(self) -> Dict[str, Any]:
        """Возвращает настройки для логгера"""
        config = self.get()
        return {
            'level': config.log_level,
            'log_to_file': config.log_to_file,
            'log_file': config.log_file,
            'console_output': config.console_output,
            'max_log_files': config.max_log_files
        }
    
    def get_cache_config(self) -> Dict[str, Any]:
        """Возвращает настройки для кэша"""
        config = self.get()
        return {
            'enabled': config.cache_enabled,
            'max_size': config.cache_max_size,
            'evict_threshold': config.cache_evict_threshold,
            'evict_percent': config.cache_evict_percent,
            'auto_save': config.cache_auto_save,
            'cache_dir': config.cache_dir,
            'evict_strategy': config.cache_evict_strategy
        }
    
    def get_smartdata_config(self) -> Dict[str, Any]:
        """Возвращает настройки для SmartData"""
        config = self.get()
        return {
            'max_depth': config.smartdata_max_depth,
            'debug': config.smartdata_debug,
            'mode': config.smartdata_mode
        }
    
    def get_field_options(self, field_name: str) -> list:
        """Возвращает доступные варианты для поля с Literal аннотацией"""
        config = self.get()
        return config.get_options_for(field_name)
    
    def get_config_schema(self) -> Dict[str, Dict]:
        """Возвращает схему конфигурации с описанием полей"""
        config = self.get()
        schema = {}
        
        for field_name, field_type in WorkerNetConfig.__annotations__.items():
            field_info = {
                'type': str(field_type),
                'current': getattr(config, field_name),
                'description': getattr(WorkerNetConfig, field_name).__doc__ or ''
            }
            
            if hasattr(field_type, '__args__'):
                field_info['options'] = list(field_type.__args__)
            
            schema[field_name] = field_info
        
        return schema
    
    def show_config(self, return_string: bool = False) -> Optional[str]:
        """
        Отображает текущую конфигурацию.
        
        Args:
            return_string: Если True, возвращает строку, иначе выводит в лог
        """
        log = _get_logger()
        config = self.get()
        
        lines = [
            "\n" + "=" * 60,
            "SimpleWorkerNet Configuration",
            "=" * 60,
            f"LOGGING:",
            f"  • Level: {config.log_level}",
            f"  • Log to file: {config.log_to_file}",
            f"  • Log file: {config.log_file}",
            f"  • Console output: {config.console_output}",
            "",
            f"CACHE:",
            f"  • Enabled: {config.cache_enabled}",
            f"  • Directory: {config.cache_dir}",
            f"  • Max size: {config.cache_max_size}",
            f"  • Evict strategy: {config.cache_evict_strategy}",
            f"  • Auto save: {config.cache_auto_save}",
            "",
            f"API:",
            f"  • Timeout: {config.default_timeout}s",
            f"  • Max retries: {config.max_retries}",
            f"  • User agent: {config.user_agent}",
            "",
            f"SmartData:",
            f"  • Max depth: {config.smartdata_max_depth}",
            f"  • Mode: {config.smartdata_mode}",
            f"  • Debug mode: {config.smartdata_debug}",
            "=" * 60
        ]
        
        result = "\n".join(lines)
        
        if return_string:
            return result
        else:
            for line in result.split('\n'):
                if line.strip():
                    log.info(line)
            return None
    
    def check_paths(self):
        """Проверяет существование и доступность путей"""
        log = _get_logger()
        config = self.get()
        
        log.info("Checking paths:")
        log.info("-" * 40)
        
        if config.log_file:
            log_path = Path(config.log_file)
            log.info(f"Log file: {log_path}")
            log.info(f"  • Exists: {'yes' if log_path.exists() else 'no'}")
            if not log_path.parent.exists():
                try:
                    log_path.parent.mkdir(parents=True, exist_ok=True)
                    log.info(f"  • Directory created: yes")
                except Exception as e:
                    log.error(f"  • Error creating: {e}")
        
        if config.cache_dir:
            cache_path = Path(config.cache_dir)
            log.info(f"\nCache directory: {cache_path}")
            log.info(f"  • Exists: {'yes' if cache_path.exists() else 'no'}")
            if not cache_path.exists():
                try:
                    cache_path.mkdir(parents=True, exist_ok=True)
                    log.info(f"  • Directory created: yes")
                except Exception as e:
                    log.error(f"  • Error creating: {e}")
        
        log.info("-" * 40)
    
    def interactive_configure(self):
        """
        Интерактивная настройка конфигурации с выбором из доступных вариантов.
        """
        log = _get_logger()
        config = self.get()
        schema = self.get_config_schema()
        
        print("\n" + "=" * 60)
        print("Interactive SimpleWorkerNet Configuration")
        print("=" * 60)
        
        changes = []
        
        for field_name, info in schema.items():
            current = info['current']
            description = info['description']
            options = info.get('options', [])
            
            print(f"\n{field_name}:")
            if description:
                print(f"  {description}")
            
            if options:
                print(f"  Available options: {', '.join(options)}")
                print(f"  Current: {current}")
                
                while True:
                    value = input(f"  New value (Enter - keep): ").strip()
                    if not value:
                        break
                    if value in options:
                        if value != current:
                            self.update(**{field_name: value})
                            changes.append(f"{field_name}: {current} -> {value}")
                        break
                    else:
                        print(f"  Invalid option. Choose from: {', '.join(options)}")
            else:
                print(f"  Current: {current}")
                print(f"  Type: {info['type']}")
                value = input(f"  New value (Enter - keep): ").strip()
                if value:
                    try:
                        if info['type'] == "<class 'int'>":
                            value = int(value)
                        elif info['type'] == "<class 'float'>":
                            value = float(value)
                        elif info['type'] == "<class 'bool'>":
                            value = value.lower() in ('true', 'yes', '1', 'y')
                        
                        if value != current:
                            self.update(**{field_name: value})
                            changes.append(f"{field_name}: {current} -> {value}")
                    except ValueError as e:
                        print(f"  Invalid value: {e}")
        
        if changes:
            self.save()
            print("\nConfiguration updated")
            for change in changes:
                log.info(f"Config changed: {change}")
        else:
            print("\nNo changes made")


# Глобальный экземпляр
ConfigManager = ConfigManager()