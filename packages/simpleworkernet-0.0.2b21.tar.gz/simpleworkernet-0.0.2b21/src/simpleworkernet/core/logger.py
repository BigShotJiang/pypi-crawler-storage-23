# simpleworkernet/core/logger.py
"""
Модуль логирования для SimpleWorkerNet
"""
import logging
import sys
import tempfile
import datetime
import os
import re
from typing import Optional, Dict, Any, Union, List
from pathlib import Path
from .exceptions import WorkerNetConfigError
from .constants import DEBUG, INFO, WARNING, ERROR, CRITICAL, LOGGER_NAME, get_default_log_path


# Карта уровней
LEVEL_MAP = {
    'DEBUG': DEBUG,
    'INFO': INFO,
    'WARNING': WARNING,
    'ERROR': ERROR,
    'CRITICAL': CRITICAL
}


def get_session_timestamp() -> str:
    """Возвращает временную метку для текущей сессии"""
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")


def get_file_creation_time(file_path: Path) -> float:
    """Возвращает время создания файла в кросс-платформенном формате"""
    stat = file_path.stat()
    if sys.platform == 'win32':
        return stat.st_ctime
    else:
        try:
            return stat.st_birthtime
        except AttributeError:
            return stat.st_ctime


def add_session_to_filename(filepath: Union[str, Path], session_id: Optional[str] = None) -> Path:
    """
    Добавляет временную метку сессии к имени файла.
    
    Args:
        filepath: Исходный путь к файлу
        session_id: Идентификатор сессии (если None, создается новый)
        
    Returns:
        Путь к файлу с добавленной сессией
    """
    path = Path(filepath)
    session = session_id or get_session_timestamp()
    stem = path.stem
    suffix = path.suffix
    new_stem = f"{stem}_{session}"
    new_filename = new_stem + suffix
    return path.parent / new_filename


def cleanup_old_logs(log_dir: Path, max_files: int = 10, pattern: str = "workernet_*.log") -> List[Path]:
    """
    Очищает старые лог-файлы, оставляя только max_files последних.
    
    Args:
        log_dir: Директория с логами
        max_files: Максимальное количество файлов для хранения
        pattern: Шаблон для поиска лог-файлов
        
    Returns:
        Список удаленных файлов
    """
    if not log_dir.exists():
        return []
    
    log_files = list(log_dir.glob(pattern))
    log_files.sort(key=get_file_creation_time)
    
    removed = []
    if len(log_files) > max_files:
        files_to_remove = log_files[:-max_files]
        for file_path in files_to_remove:
            try:
                file_path.unlink()
                removed.append(file_path)
            except Exception:
                pass
    
    return removed


def extract_session_id_from_filename(filename: str, base_name: str) -> Optional[str]:
    """
    Извлекает ID сессии из имени файла.
    
    Args:
        filename: Имя файла
        base_name: Базовое имя файла (без сессии)
        
    Returns:
        ID сессии или None
    """
    pattern = rf"{re.escape(base_name)}_(\d{{8}}_\d{{6}})\.log"
    match = re.search(pattern, filename)
    if match:
        return match.group(1)
    return None


class WorkerNetLogger:
    """
    Логгер для WorkerNet с поддержкой конфигурации.
    Реализован как синглтон с ленивой инициализацией.
    """
    
    _instance = None
    _logger: Optional[logging.Logger] = None
    _level = INFO
    _log_to_file = False
    _log_file: Optional[Path] = None
    _base_log_file: Optional[Path] = None
    _session_id: Optional[str] = None
    _console_handler: Optional[logging.Handler] = None
    _file_handler: Optional[logging.Handler] = None
    _initialized = False
    _max_log_files: int = 10
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def _auto_init(self):
        """Автоматическая инициализация при первом использовании"""
        if self._initialized:
            return
            
        try:
            from .config import ConfigManager
            config = ConfigManager.get_log_config()
            self.configure(
                level=config['level'],
                log_to_file=config['log_to_file'],
                log_file=config['log_file'],
                console_output=config['console_output'],
                max_log_files=config.get('max_log_files', 10)
            )
        except Exception:
            # При ошибке инициализируем с минимальными настройками
            self.configure(level=INFO, log_to_file=False, console_output=False)
    
    def configure(self, 
                  level: Union[int, str] = INFO,
                  log_to_file: bool = False,
                  log_file: Optional[Union[str, Path]] = None,
                  console_output: bool = False,
                  session_id: Optional[str] = None,
                  max_log_files: int = 10):
        """
        Настраивает логирование.
        
        Args:
            level: Уровень логирования
            log_to_file: Сохранять ли логи в файл
            log_file: Путь к файлу логов
            console_output: Выводить ли логи в консоль
            session_id: Идентификатор сессии
            max_log_files: Максимальное количество файлов логов
        """
        # Конвертируем уровень
        if isinstance(level, str):
            level_upper = level.upper()
            if level_upper not in LEVEL_MAP:
                raise WorkerNetConfigError(f"Unknown log level: {level}")
            self._level = LEVEL_MAP[level_upper]
        else:
            self._level = level
        
        self._log_to_file = log_to_file
        self._max_log_files = max_log_files
        self._session_id = session_id or get_session_timestamp()
        
        if log_file:
            self._base_log_file = Path(log_file)
        else:
            self._base_log_file = get_default_log_path()
        
        if log_to_file:
            self._log_file = add_session_to_filename(self._base_log_file, self._session_id)
            try:
                self._log_file.parent.mkdir(parents=True, exist_ok=True)
            except Exception:
                self._log_file = Path(tempfile.gettempdir()) / f"workernet_{self._session_id}.log"
        
        # Создаем или получаем логгер
        if self._logger is None:
            self._logger = logging.getLogger(LOGGER_NAME)
            self._logger.setLevel(self._level)
            self._logger.propagate = False
        else:
            self._logger.setLevel(self._level)
        
        # Очищаем все обработчики перед настройкой
        self._clear_handlers()
        
        # Добавляем обработчики только если нужно
        if console_output:
            self._add_console_handler()
        
        if log_to_file and self._log_file:
            self._add_file_handler()
            self._cleanup_old_logs()
        
        self._initialized = True
        
        # Логируем только если действительно нужно выводить
        if console_output or log_to_file:
            self.info(f"Logger initialized: level={self._level}")
    
    def _clear_handlers(self):
        """Удаляет все обработчики"""
        if self._logger:
            if self._console_handler:
                self._logger.removeHandler(self._console_handler)
                self._console_handler = None
            if self._file_handler:
                self._logger.removeHandler(self._file_handler)
                self._file_handler = None
    
    def _add_console_handler(self):
        """Добавляет консольный обработчик"""
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(self._level)
        console_handler.setFormatter(logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%H:%M:%S'
        ))
        self._logger.addHandler(console_handler)
        self._console_handler = console_handler
    
    def _add_file_handler(self):
        """Добавляет файловый обработчик"""
        try:
            file_handler = logging.FileHandler(self._log_file, encoding='utf-8')
            file_handler.setLevel(self._level)
            file_handler.setFormatter(logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            ))
            self._logger.addHandler(file_handler)
            self._file_handler = file_handler
        except Exception as e:
            print(f"Warning: Failed to create file handler: {e}")
    
    def _cleanup_old_logs(self):
        """Очищает старые лог-файлы"""
        if not self._base_log_file:
            return
        log_dir = self._base_log_file.parent
        base_name = self._base_log_file.stem
        pattern = f"{base_name}_*.log"
        removed = cleanup_old_logs(log_dir, self._max_log_files, pattern)
        if removed:
            self.debug(f"Cleaned up {len(removed)} old log files")
    
    def get_session_log_path(self) -> Optional[Path]:
        """Возвращает путь к файлу лога текущей сессии"""
        return self._log_file
    
    def get_session_id(self) -> Optional[str]:
        """Возвращает идентификатор текущей сессии"""
        return self._session_id
    
    def list_session_logs(self, sort_by: str = 'newest') -> List[Path]:
        """
        Возвращает список всех лог-файлов сессий.
        
        Args:
            sort_by: Способ сортировки ('newest', 'oldest', 'name')
        """
        if not self._base_log_file:
            return []
        log_dir = self._base_log_file.parent
        base_name = self._base_log_file.stem
        pattern = f"{base_name}_*.log"
        files = list(log_dir.glob(pattern))
        
        if sort_by == 'newest':
            files.sort(key=get_file_creation_time, reverse=True)
        elif sort_by == 'oldest':
            files.sort(key=get_file_creation_time)
        elif sort_by == 'name':
            files.sort(key=lambda x: x.name)
        
        return files
    
    def get_session_info(self, file_path: Path) -> Dict[str, Any]:
        """
        Возвращает информацию о сессии по файлу лога.
        
        Args:
            file_path: Путь к файлу лога
        """
        if not self._base_log_file:
            return {}
        
        base_name = self._base_log_file.stem
        session_id = extract_session_id_from_filename(file_path.name, base_name)
        
        try:
            stat = file_path.stat()
            creation_time = get_file_creation_time(file_path)
            mod_time = stat.st_mtime
            size = stat.st_size
            
            return {
                'path': file_path,
                'session_id': session_id,
                'created': datetime.datetime.fromtimestamp(creation_time),
                'modified': datetime.datetime.fromtimestamp(mod_time),
                'size_bytes': size,
                'size_kb': size / 1024
            }
        except Exception as e:
            return {
                'path': file_path,
                'session_id': session_id,
                'error': str(e)
            }
    
    def _get_logger(self) -> logging.Logger:
        """Возвращает логгер с ленивой инициализацией"""
        if self._logger is None:
            self._auto_init()
        return self._logger
    
    def debug(self, message: str, *args, **kwargs):
        """Логирует отладочное сообщение"""
        logger = self._get_logger()
        if logger.isEnabledFor(DEBUG):
            logger.debug(message, *args, **kwargs)
    
    def info(self, message: str, *args, **kwargs):
        """Логирует информационное сообщение"""
        logger = self._get_logger()
        if logger.isEnabledFor(INFO):
            # Фильтруем слишком детальные сообщения
            if any(skip in message for skip in [
                '_deep_cast', 'element', 'processing dict',
                'after collapse_list', 'field', 'processing list'
            ]):
                return
            logger.info(message, *args, **kwargs)
    
    def warning(self, message: str, *args, **kwargs):
        """Логирует предупреждение"""
        logger = self._get_logger()
        if logger.isEnabledFor(WARNING):
            logger.warning(message, *args, **kwargs)
    
    def error(self, message: str, *args, **kwargs):
        """Логирует ошибку"""
        logger = self._get_logger()
        if logger.isEnabledFor(ERROR):
            logger.error(message, *args, **kwargs)
    
    def critical(self, message: str, *args, **kwargs):
        """Логирует критическую ошибку"""
        logger = self._get_logger()
        if logger.isEnabledFor(CRITICAL):
            logger.critical(message, *args, **kwargs)
    
    def exception(self, message: str, *args, **kwargs):
        """Логирует исключение с traceback"""
        logger = self._get_logger()
        if logger.isEnabledFor(ERROR):
            logger.exception(message, *args, **kwargs)
    
    def log_api_call(self, category: str, action: str, params: dict = None):
        """Логирует вызов API"""
        if self._logger and self._logger.isEnabledFor(DEBUG):
            params_str = ""
            if params:
                safe_params = {k: (v if k != 'key' else '***') for k, v in params.items()}
                params_str = f" {safe_params}"
            self.debug(f"API call: {category}.{action}")
    
    def log_api_response(self, category: str, action: str, status_code: int, size: int = None):
        """Логирует ответ API"""
        if self._logger and self._logger.isEnabledFor(DEBUG):
            size_str = f" ({size} bytes)" if size else ""
            self.debug(f"API response: {category}.{action} -> {status_code}")
    
    def log_cache_operation(self, operation: str, details: dict = None):
        """Логирует операцию с кэшем"""
        if self._logger and self._logger.isEnabledFor(INFO):
            if details:
                details_str = " ".join(f"{k}={v}" for k, v in details.items())
                self.info(f"Cache {operation}: {details_str}")
            else:
                self.info(f"Cache {operation}")
    
    def log_smartdata_operation(self, operation: str, details: dict = None):
        """Логирует операцию SmartData"""
        if self._logger and self._logger.isEnabledFor(DEBUG):
            if details:
                details_str = " ".join(f"{k}={v}" for k, v in details.items())
                self.debug(f"SmartData.{operation}: {details_str}")
            else:
                self.debug(f"SmartData.{operation}")
    
    def log_cache_stats(self, stats: Dict[str, Any]):
        """Логирует статистику кэша"""
        if self._logger and self._logger.isEnabledFor(INFO):
            self.info(f"Cache stats: hits={stats.get('hits', 0)}, misses={stats.get('misses', 0)}")
    
    def set_level(self, level: Union[int, str]):
        """Устанавливает уровень логирования"""
        old_level = self._level
        if isinstance(level, str):
            level_upper = level.upper()
            if level_upper not in LEVEL_MAP:
                raise WorkerNetConfigError(f"Unknown log level: {level}")
            self._level = LEVEL_MAP[level_upper]
        else:
            self._level = level
        
        if self._logger:
            self._logger.setLevel(self._level)
            if self._console_handler:
                self._console_handler.setLevel(self._level)
            if self._file_handler:
                self._file_handler.setLevel(self._level)
        
        self.info(f"Log level changed: {old_level} -> {self._level}")
    
    def new_session(self, session_id: Optional[str] = None) -> str:
        """
        Начинает новую сессию логирования.
        
        Args:
            session_id: Идентификатор сессии
            
        Returns:
            ID новой сессии
        """
        if not self._log_to_file:
            self.warning("File logging disabled, new session not created")
            return ""
        
        old_session = self._session_id
        self._session_id = session_id or get_session_timestamp()
        
        if self._base_log_file:
            self._log_file = add_session_to_filename(self._base_log_file, self._session_id)
            if self._file_handler:
                self._logger.removeHandler(self._file_handler)
                self._file_handler = None
            self._add_file_handler()
            self._cleanup_old_logs()
            self.info(f"New logging session: {self._session_id}")
        
        return self._session_id


# Глобальный экземпляр логгера
_logger_instance = None


def get_logger():
    """Возвращает глобальный экземпляр логгера"""
    global _logger_instance
    if _logger_instance is None:
        _logger_instance = WorkerNetLogger()
    return _logger_instance


# Глобальный экземпляр для удобства
log = get_logger()