__version__ = "0.0.2b21"
__author__ = "Andrey Litvinov"
__email__ = "busybeaver.bb@gmail.com"
__license__ = "MIT"