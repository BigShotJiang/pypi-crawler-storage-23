"""Context loaders for Fair Forge generators."""

from .local_markdown import LocalMarkdownLoader

__all__ = ["LocalMarkdownLoader"]
