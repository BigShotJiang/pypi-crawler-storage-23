import logging
from typing import ClassVar

import reflex as rx

import reflex_enterprise as rxe
from reflex_enterprise.auth.cookie import HTTPCookie
from reflex_enterprise.auth.oidc.state import OIDCAuthState
from reflex_enterprise.utils import chain_event_out_of_band

logging.basicConfig(
    level=logging.INFO, format="%(levelname)-7s %(name)-10s: %(message)s"
)
logging.getLogger("httpx").setLevel(logging.WARNING)


class LogAtMixin(rx.State, mixin=True):
    @rx.event
    async def log_at(self):
        """Log the current authentication state."""
        access_token = await self._access_token
        self._logger.info(
            f"Userinfo: {await self.userinfo}, ID Token: {self._id_token}, Access Token: {access_token}"
        )

    @rx.var
    def last_access_token_hash(self) -> str | None:
        """A hash of the last access token for comparison to detect changes."""
        return self._last_access_token_hash


class OktaAuthState(LogAtMixin, OIDCAuthState, rx.State):
    """OIDC Auth State for Okta."""

    __provider__ = "okta"
    _logger: ClassVar[logging.Logger] = logging.getLogger(__provider__)
    _logger.setLevel(logging.DEBUG)

    @rx.event
    def check_if_iframed_cb(self, is_iframed: bool):
        """Callback invoked with the iframe detection result.

        Args:
            is_iframed: True if the page is inside an iframe or cross-origin
                access prevented detection.
        """
        self.is_iframed = True


class DatabricksAuthState(LogAtMixin, OIDCAuthState, rx.State):
    """OIDC Auth State for Databricks."""

    __provider__ = "databricks"
    _requested_scopes: str = "all-apis offline_access openid email profile"
    _logger: ClassVar[logging.Logger] = logging.getLogger(__provider__)
    _logger.setLevel(logging.DEBUG)

    async def _on_refresh_access_token(self, new_access_token: str):
        """Called when the access token is successfully refreshed."""
        self._logger.info(self._format_log_message("Access token refresh callback hit"))
        await chain_event_out_of_band(self, rx.toast("Access token refreshed"))


class FooState(rx.State):
    @rx.event
    def do_nothing(self):
        pass


def user_info_card(auth_cls: type[OIDCAuthState]) -> rx.Component:
    return rx.card(
        rx.cond(
            auth_cls.userinfo.is_not_none(),
            rx.vstack(
                rx.heading(f"{auth_cls.__provider__.title()} User Info", size="4"),
                rx.foreach(
                    auth_cls.userinfo,
                    lambda kv: rx.text(f"{kv[0]}: {kv[1]} "),
                ),
                rx.vstack(
                    rx.badge(
                        rx.moment(auth_cls.userinfo.to(dict)["iat"], unix=True),
                        color_scheme="green",
                    ),
                    rx.badge(
                        rx.moment(auth_cls.userinfo.to(dict)["exp"], unix=True),
                        color_scheme="red",
                    ),
                    rx.badge(auth_cls.last_access_token_hash, color_scheme="blue"),
                    rx.badge(auth_cls.latest_access_token_hash, color_scheme="blue"),
                )
                if auth_cls is DatabricksAuthState
                else rx.fragment(),
                rx.button(
                    "Log AT",
                    on_click=auth_cls.log_at,
                ),
                rx.button("Logout", on_click=auth_cls.redirect_to_logout),
            ),
            auth_cls.get_login_button(),
        ),
    )


def index() -> rx.Component:
    return rx.container(
        rx.color_mode.button(position="top-right"),
        rx.vstack(
            rx.heading("OIDC Demo", size="9"),
            rx.hstack(
                user_info_card(OktaAuthState),
                user_info_card(DatabricksAuthState),
                spacing="2",
            ),
            rx.button(
                "Do Nothing",
                on_click=FooState.do_nothing,
            ),
            rx.button(
                "Cookie Sync",
                on_click=HTTPCookie.sync(),
            ),
        ),
    )


app = rxe.App()
app.add_page(index)

OktaAuthState.register_auth_endpoints()
DatabricksAuthState.register_auth_endpoints()
