"""Mantine Demo app."""
