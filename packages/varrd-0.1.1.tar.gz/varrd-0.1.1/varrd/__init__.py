"""VARRD — Trading edge discovery."""

from varrd.client import VARRD
from varrd._version import __version__

__all__ = ["VARRD", "__version__"]
