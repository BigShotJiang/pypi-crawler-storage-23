"""dictIO Command line interface."""
