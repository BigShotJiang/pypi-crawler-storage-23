# Changelog

All notable changes to this project will be documented in this file. See [commit-and-tag-version](https://github.com/absolute-version/commit-and-tag-version) for commit guidelines.

## [0.0.3](v0.0.3) (2026-02-25)

## [0.0.2](v0.0.2) (2026-02-25)

### Features

* upload artifacts to gh release and add classifiers in pyproject.toml
* add readme, fixes test and change license to mit
