"""Packaged taxonomy catalog data files."""

