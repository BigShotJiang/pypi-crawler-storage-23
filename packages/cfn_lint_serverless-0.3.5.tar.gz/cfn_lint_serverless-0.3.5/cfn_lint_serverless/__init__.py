"""
CloudFormation Lint Rules for Serverless applications
"""
