"""pgvector adapter for PostgreSQL with vector similarity search."""

from hexdag.builtin.adapters.database.pgvector.pgvector_adapter import PgVectorAdapter

__all__ = ["PgVectorAdapter"]
