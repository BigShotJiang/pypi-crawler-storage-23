"""Local adapter implementations that run in-process."""

from .local_observer_manager import LocalObserverManager

__all__ = [
    "LocalObserverManager",
]
