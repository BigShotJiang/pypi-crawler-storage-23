# Volt API

FastAPI-based time series data API with ClickHouse backend for Volt Power Analytics.

## Features

- **Time Series Data**: Retrieve historical and forecast data for power market curves
- **Forward Curves**: Access closing/settlement prices for futures contracts
- **Bulk Queries**: Efficient multi-curve queries in a single request
- **Timezone Support**: Full timezone handling with server-side aggregation
- **Rate Limiting**: Configurable rate limits to prevent abuse
- **Access Control**: Fine-grained permissions by area, group, and usage rights

## Quick Start

### Local Development

```bash
# Clone the repository
git clone https://github.com/voltpoweranalytics/volt-api.git
cd volt-api

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -e ".[dev]"

# Copy environment template and configure
cp .env.example .env
# Edit .env with your ClickHouse credentials

# Run the server
DEV_MODE=true uvicorn volt_api.main:app --reload
```

### Docker

```bash
# Build the image
docker build -t volt-api .

# Run the container
docker run -p 8000:8000 --env-file .env volt-api
```

## API Endpoints

### Health & Info
- `GET /health` - Health check
- `GET /curves` - List available curves
- `GET /areas` - List available areas
- `GET /groups` - List available groups

### Data Retrieval
- `GET /data/actual` - Get historical data for a single curve
- `GET /data/closing` - Get forward curve data
- `GET /data/settlement` - Alias for `/data/closing`
- `GET /data` - Bulk query for multiple curves by ID

### Parameters

| Parameter | Description | Example |
|-----------|-------------|---------|
| `curve_name` | Curve identifier | `price spot no1 entso-e eur/mwh min60 actual` |
| `start_date` | Start date (YYYY-MM-DD) | `2024-01-01` |
| `end_date` | End date (YYYY-MM-DD) | `2024-12-31` |
| `tz` | Timezone | `Europe/Oslo`, `CET` |
| `agg` | Aggregation frequency | `hourly`, `daily`, `monthly` |
| `agg_func` | Aggregation function | `avg`, `sum`, `min`, `max` |

## Authentication

The API supports two authentication methods:

### API Key (Recommended)
```python
import httpx

headers = {"X-API-Key": "volt_your_api_key_here"}
response = httpx.get(
    "https://api.voltpoweranalytics.com/data/actual",
    params={
        "curve_name": "price spot no1 entso-e eur/mwh min60 actual",
        "start_date": "2024-01-01",
        "end_date": "2024-12-31"
    },
    headers=headers
)
data = response.json()
```

### JWT Token (Dashboard Users)
```python
import httpx

headers = {"Authorization": "Bearer your_jwt_token"}
response = httpx.get(
    "https://api.voltpoweranalytics.com/data/actual",
    params={"curve_name": "...", "start_date": "2024-01-01"},
    headers=headers
)
```

## Python Client

```python
from volt_api.client import VoltClient

client = VoltClient(
    base_url="https://api.voltpoweranalytics.com",
    api_key="volt_your_api_key_here"
)

# Get single curve
df = client.get_actual(
    "price spot no1 entso-e eur/mwh min60 actual",
    "2024-01-01", "2024-12-31",
    tz="Europe/Oslo"
)

# Get multiple curves (bulk query - much faster)
df = client.get_actual(
    ["price spot no1 entso-e eur/mwh min60 actual",
     "price spot no2 entso-e eur/mwh min60 actual"],
    "2024-01-01", "2024-12-31"
)

# Get forward curve
df = client.get_closing("price future epad no1 nasdaq eur/mwh m close")
```

## Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=src/volt_api --cov-report=html

# Run specific test file
pytest tests/test_health.py -v
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `CLICKHOUSE_HOST` | ClickHouse server host | Required |
| `CLICKHOUSE_PORT` | ClickHouse server port | `8443` |
| `CLICKHOUSE_USER` | ClickHouse username | `default` |
| `CLICKHOUSE_PASSWORD` | ClickHouse password | Required |
| `DEV_MODE` | Bypass authentication | `false` |
| `RATE_LIMIT_DATA` | Rate limit for data endpoints | `45/minute` |
| `CORS_ORIGINS` | Allowed CORS origins | See `.env.example` |

## Deployment

The API is designed to run on Azure App Service with GitHub Actions CI/CD.

### Manual Deployment

1. Create Azure Web App with container support
2. Configure environment variables in Azure
3. Push to main branch to trigger deployment

### GitHub Actions Secrets

- `AZURE_WEBAPP_PUBLISH_PROFILE_STAGING`
- `AZURE_WEBAPP_PUBLISH_PROFILE_PRODUCTION`

## License

Proprietary - Volt Power Analytics
