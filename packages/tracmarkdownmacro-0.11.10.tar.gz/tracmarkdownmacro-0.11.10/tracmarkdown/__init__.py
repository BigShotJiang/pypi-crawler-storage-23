import pkg_resources

pkg_resources.require('Trac >= 1.0')
