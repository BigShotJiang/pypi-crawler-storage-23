CREATE DATABASE IF NOT EXISTS stationery_store;
USE stationery_store;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS addresses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    address TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    photo VARCHAR(255),
    material VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    manufacturer VARCHAR(255) NOT NULL,
    product_type VARCHAR(100) NOT NULL,
    purpose VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    delivery_address TEXT NOT NULL,
    delivery_date VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS delivery_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS order_items (
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

INSERT INTO products (name, photo, material, price, manufacturer, product_type, purpose) VALUES
('Ручка синяя', 'pen.jpg', 'пластик', 25.00, 'Bic', 'ручки', 'для школьников'),
('Блокнот А5', 'notebook.jpg', 'бумага', 150.00, 'BRAUBERG', 'блокноты', 'офисные принадлежности'),
('Папка-регистратор', 'folder.jpg', 'картон', 350.00, 'Svetocopy', 'папки', 'офисные принадлежности'),
('Карандаш HB', 'pencil.jpg', 'дерево', 15.00, 'Koh-i-Noor', 'карандаши', 'для школьников'),
('Краски акварельные', 'paint.jpg', 'пластик', 280.00, 'Гамма', 'краски', 'художественные материалы'),
('Линейка 30см', 'ruler.jpg', 'пластик', 45.00, 'Hatber', 'линейки', 'для школьников'),
('Степлер', 'stapler.jpg', 'металл', 220.00, 'Brauberg', 'степлеры', 'офисные принадлежности'),
('Степлер', 'stapler.jpg', 'пластик', 95.00, 'Attache', 'степлеры', 'офисные принадлежности');

INSERT INTO delivery_methods (name) VALUES ('Курьер'), ('Самовывоз');
