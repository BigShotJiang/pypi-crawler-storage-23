import os
import sys
from datetime import datetime, timedelta
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QComboBox, QSpinBox, QScrollArea,
    QGridLayout, QDialog, QGroupBox, QListWidget, QListWidgetItem,
    QMessageBox, QStackedWidget, QFrame,
)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QPixmap

try:
    from . import db
except ImportError:
    import db


class AuthDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Вход / Регистрация")
        self.user = None
        layout = QVBoxLayout(self)
        self.login_widget = self._login_form()
        self.register_widget = self._register_form()
        layout.addWidget(self.login_widget)
        layout.addWidget(self.register_widget)

    def _login_form(self):
        w = QGroupBox("Вход")
        l = QVBoxLayout(w)
        l.addWidget(QLabel("Email:"))
        self.login_email = QLineEdit()
        self.login_email.setPlaceholderText("email@example.com")
        l.addWidget(self.login_email)
        l.addWidget(QLabel("Пароль:"))
        self.login_password = QLineEdit()
        self.login_password.setEchoMode(QLineEdit.EchoMode.Password)
        l.addWidget(self.login_password)
        btn = QPushButton("Войти")
        btn.clicked.connect(self._do_login)
        l.addWidget(btn)
        return w

    def _register_form(self):
        w = QGroupBox("Регистрация")
        l = QVBoxLayout(w)
        l.addWidget(QLabel("ФИО:"))
        self.reg_name = QLineEdit()
        l.addWidget(self.reg_name)
        l.addWidget(QLabel("Email:"))
        self.reg_email = QLineEdit()
        l.addWidget(self.reg_email)
        l.addWidget(QLabel("Телефон:"))
        self.reg_phone = QLineEdit()
        l.addWidget(self.reg_phone)
        l.addWidget(QLabel("Пароль:"))
        self.reg_password = QLineEdit()
        self.reg_password.setEchoMode(QLineEdit.EchoMode.Password)
        l.addWidget(self.reg_password)
        btn = QPushButton("Зарегистрироваться")
        btn.clicked.connect(self._do_register)
        l.addWidget(btn)
        return w

    def _do_login(self):
        u = db.login_user(self.login_email.text().strip(), self.login_password.text())
        if u:
            self.user = u
            self.accept()
        else:
            QMessageBox.warning(self, "Ошибка", "Неверный email или пароль")

    def _do_register(self):
        name = self.reg_name.text().strip()
        email = self.reg_email.text().strip()
        phone = self.reg_phone.text().strip()
        pwd = self.reg_password.text()
        if not all([name, email, phone, pwd]):
            QMessageBox.warning(self, "Ошибка", "Заполните все поля")
            return
        if db.register_user(name, email, phone, pwd):
            self.user = db.login_user(email, pwd)
            self.accept()
        else:
            QMessageBox.warning(self, "Ошибка", "Email уже занят")


class CartWidget(QFrame):
    def __init__(self, cart, products_cache, parent=None):
        super().__init__(parent)
        self.cart = cart
        self.products_cache = {p["id"]: p for p in products_cache}
        layout = QVBoxLayout(self)
        self.list = QListWidget()
        layout.addWidget(self.list)
        self.total_label = QLabel("Сумма: 0")
        layout.addWidget(self.total_label)
        self.refresh()

    def refresh(self):
        self.list.clear()
        total = 0
        for pid, qty in list(self.cart.items()):
            p = self.products_cache.get(pid) or db.get_product(pid)
            if not p:
                continue
            w = QWidget()
            h = QHBoxLayout(w)
            h.setContentsMargins(0, 0, 0, 0)
            lab = QLabel(f"{p['name']} x{qty} — {p['price']*qty:.0f} ₽")
            h.addWidget(lab)
            minus_btn = QPushButton("-")
            minus_btn.setFixedWidth(30)
            minus_btn.clicked.connect(lambda c=False, i=pid: self._change(i, -1))
            h.addWidget(minus_btn)
            plus_btn = QPushButton("+")
            plus_btn.setFixedWidth(30)
            plus_btn.clicked.connect(lambda c=False, i=pid: self._change(i, 1))
            h.addWidget(plus_btn)
            del_btn = QPushButton("Удалить")
            del_btn.clicked.connect(lambda c=False, i=pid: self._remove(i))
            h.addWidget(del_btn)
            list_item = QListWidgetItem(self.list)
            list_item.setSizeHint(QSize(200, 40))
            self.list.addItem(list_item)
            self.list.setItemWidget(list_item, w)
            total += p["price"] * qty
        self.total_label.setText(f"Общая сумма заказа: {total:.0f} ₽")

    def _change(self, pid, delta):
        self.cart[pid] = self.cart.get(pid, 0) + delta
        if self.cart[pid] <= 0:
            del self.cart[pid]
        self.refresh()

    def _remove(self, pid):
        if pid in self.cart:
            del self.cart[pid]
        self.refresh()


class CheckoutDialog(QDialog):
    def __init__(self, user, cart, products_cache, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Оформление заказа")
        self.setMinimumSize(450, 400)
        self.user = user
        self.cart = cart
        self.products = {p["id"]: p for p in products_cache}
        self.order_id = None
        layout = QVBoxLayout(self)
        self.stack = QStackedWidget()
        layout.addWidget(self.stack)

        self.btn_row = QHBoxLayout()
        self.btn_back = QPushButton("Назад")
        self.btn_back.clicked.connect(self._prev_step)
        self.btn_next = QPushButton("Далее")
        self.btn_next.clicked.connect(self._next_step)
        self.btn_row.addWidget(self.btn_back)
        self.btn_row.addWidget(self.btn_next)

        self.page_step1 = QWidget()
        pl1 = QVBoxLayout(self.page_step1)
        pl1.addWidget(QLabel("1. Выбор метода оплаты:"))
        self.payment = QComboBox()
        self.payment.addItems(["Наличные", "Банковская карта"])
        self.payment.setMinimumHeight(30)
        pl1.addWidget(self.payment)
        pl1.addWidget(QLabel("2. Адрес доставки (можно сохранить несколько):"))
        addrs = db.get_user_addresses(user["id"])
        self.address_combo = QComboBox()
        for _, addr in addrs:
            self.address_combo.addItem(addr)
        self.address_combo.setEditable(True)
        self.address_combo.setCurrentText("")
        pl1.addWidget(self.address_combo)
        pl1.addWidget(QLabel("(Новый адрес сохранится)"))
        self.stack.addWidget(self.page_step1)

        self.page_step2 = QWidget()
        pl2 = QVBoxLayout(self.page_step2)
        pl2.addWidget(QLabel("3. Проверка содержимого заказа перед отправкой:"))
        self.review_text = QLabel("")
        self.review_text.setWordWrap(True)
        pl2.addWidget(self.review_text)
        self.stack.addWidget(self.page_step2)

        self.page_step3 = QWidget()
        pl3 = QVBoxLayout(self.page_step3)
        self.result_label = QLabel("")
        self.result_label.setWordWrap(True)
        pl3.addWidget(self.result_label)
        btn_close = QPushButton("Закрыть")
        btn_close.clicked.connect(self.accept)
        pl3.addWidget(btn_close)
        self.stack.addWidget(self.page_step3)

        layout.addLayout(self.btn_row)
        self.stack.setCurrentIndex(0)
        self._update_buttons()
        self._update_review()

    def _update_review(self):
        total = 0
        lines = ["Перечень товаров:"]
        for pid, qty in self.cart.items():
            p = self.products.get(pid)
            if p:
                s = p["price"] * qty
                total += s
                lines.append(f"  {p['name']} x{qty} = {s:.0f} ₽")
        lines.append(f"\nСумма заказа: {total:.0f} ₽")
        lines.append(f"\nКонтактные данные: {self.user['full_name']}, {self.user['email']}, {self.user['phone']}")
        self.review_text.setText("\n".join(lines))

    def _update_buttons(self):
        idx = self.stack.currentIndex()
        self.btn_back.setVisible(idx == 1)
        self.btn_next.setVisible(idx < 2)
        if idx == 0:
            self.btn_next.setText("Далее")
        elif idx == 1:
            self.btn_next.setText("Подтвердить заказ")

    def _prev_step(self):
        self.stack.setCurrentIndex(self.stack.currentIndex() - 1)
        self._update_buttons()

    def _next_step(self):
        idx = self.stack.currentIndex()
        if idx == 0:
            addr = self.address_combo.currentText().strip()
            if not addr:
                QMessageBox.warning(self, "Ошибка", "Укажите адрес доставки")
                return
            self.stack.setCurrentIndex(1)
        elif idx == 1:
            addr = self.address_combo.currentText().strip()
            addrs = db.get_user_addresses(self.user["id"])
            addrs_text = [a[1] for a in addrs]
            if addr not in addrs_text:
                db.add_address(self.user["id"], addr)
            total = sum(self.products.get(pid, {}).get("price", 0) * qty for pid, qty in self.cart.items())
            payment = self.payment.currentText()
            delivery_date = (datetime.now() + timedelta(days=3)).strftime("%d.%m.%Y")
            self.order_id = db.create_order(self.user["id"], total, payment, addr, self.cart, delivery_date)
            self.result_label.setText(f"4. Подтверждение заказа:\n\nЗаказ №{self.order_id}\nПримерная дата доставки: {delivery_date}")
            self.stack.setCurrentIndex(2)
        self._update_buttons()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Магазин канцелярии")
        self.user = None
        self.cart = {}
        self.products = []
        db.init_db()
        self._init_ui()
        self._load_products()

    def _init_ui(self):
        cw = QWidget()
        self.setCentralWidget(cw)
        layout = QVBoxLayout(cw)

        top = QHBoxLayout()
        top.addWidget(QLabel("Поиск (название/производитель):"))
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Поиск...")
        self.search_edit.textChanged.connect(self._load_products)
        top.addWidget(self.search_edit)
        top.addWidget(QLabel("Тип:"))
        self.filter_type = QComboBox()
        self.filter_type.addItem("—", None)
        self.filter_type.currentIndexChanged.connect(self._load_products)
        top.addWidget(self.filter_type)
        top.addWidget(QLabel("Материал:"))
        self.filter_material = QComboBox()
        self.filter_material.addItem("—", None)
        self.filter_material.currentIndexChanged.connect(self._load_products)
        top.addWidget(self.filter_material)
        top.addWidget(QLabel("Назначение:"))
        self.filter_purpose = QComboBox()
        self.filter_purpose.addItem("—", None)
        self.filter_purpose.currentIndexChanged.connect(self._load_products)
        top.addWidget(self.filter_purpose)
        top.addWidget(QLabel("Цена от:"))
        self.price_min = QSpinBox()
        self.price_min.setRange(0, 99999)
        self.price_min.setSpecialValueText("—")
        self.price_min.valueChanged.connect(self._load_products)
        top.addWidget(self.price_min)
        top.addWidget(QLabel("до:"))
        self.price_max = QSpinBox()
        self.price_max.setRange(0, 99999)
        self.price_max.setValue(99999)
        self.price_max.setSpecialValueText("—")
        self.price_max.valueChanged.connect(self._load_products)
        top.addWidget(self.price_max)
        layout.addLayout(top)

        types, materials, purposes = db.get_filter_options()
        for t in types:
            self.filter_type.addItem(t, t)
        for m in materials:
            self.filter_material.addItem(m, m)
        for p in purposes:
            self.filter_purpose.addItem(p, p)

        mid = QHBoxLayout()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.catalog_widget = QWidget()
        self.catalog_layout = QGridLayout(self.catalog_widget)
        scroll.setWidget(self.catalog_widget)
        mid.addWidget(scroll, 2)

        right = QVBoxLayout()
        right.addWidget(QLabel("Корзина"))
        self.cart_widget = CartWidget(self.cart, [], self)
        self.cart_widget.setMinimumWidth(280)
        right.addWidget(self.cart_widget)
        btn_row = QHBoxLayout()
        self.auth_btn = QPushButton("Войти")
        self.auth_btn.clicked.connect(self._auth)
        btn_row.addWidget(self.auth_btn)
        self.checkout_btn = QPushButton("Оформить заказ")
        self.checkout_btn.clicked.connect(self._checkout)
        btn_row.addWidget(self.checkout_btn)
        right.addLayout(btn_row)
        mid.addLayout(right, 1)
        layout.addLayout(mid)

    def _load_products(self):
        filters = {}
        t = self.filter_type.currentData()
        if t:
            filters["product_type"] = t
        m = self.filter_material.currentData()
        if m:
            filters["material"] = m
        p = self.filter_purpose.currentData()
        if p:
            filters["purpose"] = p
        if self.price_min.value() > 0:
            filters["price_min"] = self.price_min.value()
        if self.price_max.value() < 99999:
            filters["price_max"] = self.price_max.value()
        s = self.search_edit.text().strip()
        if s:
            filters["search"] = s
        self.products = db.get_products(filters)
        self._render_catalog()
        all_p = {p["id"]: p for p in db.get_all_products()}
        self.cart_widget.products_cache = all_p
        self.cart_widget.refresh()

    def _render_catalog(self):
        for i in reversed(range(self.catalog_layout.count())):
            self.catalog_layout.itemAt(i).widget().setParent(None)
        row, col = 0, 0
        for p in self.products:
            frame = QFrame()
            frame.setFrameStyle(QFrame.Shape.Box)
            fl = QVBoxLayout(frame)
            photo_lbl = QLabel()
            photo_lbl.setFixedSize(80, 80)
            photo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            if p.get("photo") and os.path.exists(p["photo"]):
                px = QPixmap(p["photo"]).scaled(80, 80, Qt.AspectRatioMode.KeepAspectRatio)
                photo_lbl.setPixmap(px)
            else:
                photo_lbl.setText("Фото")
            fl.addWidget(photo_lbl)
            fl.addWidget(QLabel(p["name"]))
            fl.addWidget(QLabel(f"Материал: {p['material']}"))
            fl.addWidget(QLabel(f"Цена: {p['price']:.0f} ₽"))
            fl.addWidget(QLabel(f"Производитель: {p['manufacturer']}"))
            h = QHBoxLayout()
            sp = QSpinBox()
            sp.setRange(1, 99)
            sp.setValue(1)
            h.addWidget(sp)
            add_btn = QPushButton("В корзину")
            add_btn.clicked.connect(lambda c=False, pid=p["id"], spin=sp: self._add_to_cart(pid, spin.value()))
            h.addWidget(add_btn)
            fl.addLayout(h)
            self.catalog_layout.addWidget(frame, row, col)
            col += 1
            if col >= 3:
                col = 0
                row += 1

    def _add_to_cart(self, pid, qty):
        self.cart[pid] = self.cart.get(pid, 0) + qty
        self.cart_widget.refresh()

    def _auth(self):
        d = AuthDialog(self)
        if d.exec() == QDialog.DialogCode.Accepted:
            self.user = d.user
            self.auth_btn.setText(f"Выйти ({self.user['full_name']})")
            self.auth_btn.clicked.disconnect()
            self.auth_btn.clicked.connect(self._logout)

    def _logout(self):
        self.user = None
        self.auth_btn.setText("Войти")
        self.auth_btn.clicked.disconnect()
        self.auth_btn.clicked.connect(self._auth)

    def _checkout(self):
        if not self.cart:
            QMessageBox.information(self, "Корзина пуста", "Добавьте товары в корзину")
            return
        if not self.user:
            d = AuthDialog(self)
            if d.exec() != QDialog.DialogCode.Accepted:
                return
            self.user = d.user
            self.auth_btn.setText(f"Выйти ({self.user['full_name']})")
            self.auth_btn.clicked.disconnect()
            self.auth_btn.clicked.connect(self._logout)
        try:
            d = CheckoutDialog(self.user, self.cart, db.get_all_products(), self)
            d.setModal(True)
            d.raise_()
            d.activateWindow()
            if d.exec() == QDialog.DialogCode.Accepted and d.order_id:
                self.cart.clear()
                self.cart_widget.refresh()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка оформления заказа:\n{e}")


def main():
    app = QApplication(sys.argv)
    try:
        w = MainWindow()
        w.resize(1000, 600)
        w.show()
        sys.exit(app.exec())
    except Exception as e:
        QMessageBox.critical(None, "Ошибка", f"{e}\n\nПроверь: MySQL запущен, init.sql выполнен, переменные KALASH2_DB_*.")
        sys.exit(1)


if __name__ == "__main__":
    main()
