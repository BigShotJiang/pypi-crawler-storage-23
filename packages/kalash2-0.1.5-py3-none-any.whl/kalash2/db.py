import os
import pymysql
from pymysql.cursors import DictCursor

DB_CONFIG = {
    "host": os.environ.get("KALASH2_DB_HOST", "localhost"),
    "user": os.environ.get("KALASH2_DB_USER", "root"),
    "password": os.environ.get("KALASH2_DB_PASSWORD", "anksoonamoon"),
    "database": os.environ.get("KALASH2_DB_NAME", "stationery_store"),
    "charset": "utf8mb4",
}


def _conn():
    return pymysql.connect(cursorclass=DictCursor, **DB_CONFIG)


def init_db():
    pass


def get_products(filters=None):
    conn = _conn()
    c = conn.cursor()
    sql = "SELECT * FROM products WHERE 1=1"
    params = []
    if filters:
        if filters.get("product_type"):
            sql += " AND product_type = %s"
            params.append(filters["product_type"])
        if filters.get("material"):
            sql += " AND material = %s"
            params.append(filters["material"])
        if filters.get("purpose"):
            sql += " AND purpose = %s"
            params.append(filters["purpose"])
        if filters.get("price_min") is not None:
            sql += " AND price >= %s"
            params.append(filters["price_min"])
        if filters.get("price_max") is not None:
            sql += " AND price <= %s"
            params.append(filters["price_max"])
        if filters.get("search"):
            sql += " AND (name LIKE %s OR manufacturer LIKE %s)"
            s = f"%{filters['search']}%"
            params.extend([s, s])
    sql += " ORDER BY name"
    c.execute(sql, params)
    rows = c.fetchall()
    conn.close()
    return list(rows)


def get_product(pid):
    conn = _conn()
    c = conn.cursor()
    c.execute("SELECT * FROM products WHERE id = %s", (pid,))
    row = c.fetchone()
    conn.close()
    return row


def get_all_products():
    conn = _conn()
    c = conn.cursor()
    c.execute("SELECT * FROM products")
    rows = c.fetchall()
    conn.close()
    return list(rows)


def get_filter_options():
    conn = _conn()
    c = conn.cursor()
    c.execute("SELECT DISTINCT product_type FROM products ORDER BY product_type")
    types = [r["product_type"] for r in c.fetchall()]
    c.execute("SELECT DISTINCT material FROM products ORDER BY material")
    materials = [r["material"] for r in c.fetchall()]
    c.execute("SELECT DISTINCT purpose FROM products ORDER BY purpose")
    purposes = [r["purpose"] for r in c.fetchall()]
    conn.close()
    return types, materials, purposes


def register_user(full_name, email, phone, password):
    conn = _conn()
    try:
        c = conn.cursor()
        c.execute(
            "INSERT INTO users (full_name, email, phone, password) VALUES (%s,%s,%s,%s)",
            (full_name, email, phone, password),
        )
        conn.commit()
        return True
    except pymysql.IntegrityError:
        return False
    finally:
        conn.close()


def login_user(email, password):
    conn = _conn()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email = %s AND password = %s", (email, password))
    row = c.fetchone()
    conn.close()
    return row


def get_user_addresses(user_id):
    conn = _conn()
    c = conn.cursor()
    c.execute("SELECT id, address FROM addresses WHERE user_id = %s", (user_id,))
    rows = [(r["id"], r["address"]) for r in c.fetchall()]
    conn.close()
    return rows


def add_address(user_id, address):
    conn = _conn()
    c = conn.cursor()
    c.execute("INSERT INTO addresses (user_id, address) VALUES (%s,%s)", (user_id, address))
    conn.commit()
    conn.close()


def create_order(user_id, total, payment_method, delivery_address, cart, delivery_date):
    conn = _conn()
    c = conn.cursor()
    c.execute(
        "INSERT INTO orders (user_id, total, payment_method, delivery_address, delivery_date) VALUES (%s,%s,%s,%s,%s)",
        (user_id, total, payment_method, delivery_address, delivery_date),
    )
    order_id = c.lastrowid
    for pid, qty in cart.items():
        c.execute("INSERT INTO order_items (order_id, product_id, quantity) VALUES (%s,%s,%s)", (order_id, pid, qty))
    conn.commit()
    conn.close()
    return order_id
