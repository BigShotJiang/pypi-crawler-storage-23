"""Nomenclatures ETNIC : listes de référence des valeurs acceptées par les services."""

TYPES_INTERVENTION_EXTERIEURE: list = [
    "Agence Qualité",
    "Convention",
    "Discriminations positives",
    "EHR",
    "Fonds Européens",
    "Formation des publics infra scolarisés",
    "Formations continuées",
    "Octroi périodes cabinet-projets transver",
    "Octroi périodes supplémentaires-bonus",
    "Personnel non chargé de cours",
    "Réorientation 7TQ/7P",
    "Union Européenne",
    "Validation des compétences",
]
