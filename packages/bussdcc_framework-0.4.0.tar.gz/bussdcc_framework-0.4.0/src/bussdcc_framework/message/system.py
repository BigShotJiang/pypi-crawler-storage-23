from typing import Optional
from dataclasses import dataclass

from bussdcc.message import Message


@dataclass(slots=True)
class SystemIdentityEvent(Message):
    name = "system.identity"

    hostname: str
    model: Optional[str]
    serial: Optional[str]
