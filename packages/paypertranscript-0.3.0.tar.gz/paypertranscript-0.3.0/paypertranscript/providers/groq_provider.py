﻿"""GroqCloud API-Provider für PayPerTranscript.

Implementiert STT (Whisper) und LLM-Formatierung über die GroqCloud API.
"""

import time
from collections.abc import Iterator
from pathlib import Path

import groq

from paypertranscript.core.logging import get_logger
from paypertranscript.providers.base import AbstractLLMProvider, AbstractSTTProvider, ProviderError

log = get_logger("providers.groq")

# Retry-Konfiguration fuer transiente API-Fehler
_MAX_RETRIES = 3
_RETRY_BASE_DELAY = 1.0  # Sekunden (exponential: 1s, 2s, 4s)
_RETRYABLE_ERRORS = (groq.RateLimitError, groq.APITimeoutError, groq.APIConnectionError)

# Minimale WAV-Dateigroesse (44 Bytes = WAV-Header ohne Audio-Daten)
_MIN_WAV_SIZE = 44


class GroqSTTProvider(AbstractSTTProvider):
    """GroqCloud Whisper STT-Provider.

    Nutzt whisper-large-v3-turbo für Speech-to-Text.
    Der Groq-Client wird einmal instanziiert und wiederverwendet
    (Connection Pooling via httpx).
    """

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "whisper-large-v3-turbo",
    ) -> None:
        self._model = model
        try:
            self._client = groq.Groq(api_key=api_key)
        except groq.GroqError as e:
            raise ProviderError(f"Groq-Client konnte nicht erstellt werden: {e}") from e
        log.info("GroqSTTProvider initialisiert (Modell: %s)", self._model)

    def transcribe(self, audio_path: Path, language: str, prompt: str = "") -> str:
        """Transkribiert eine WAV-Datei via GroqCloud Whisper API."""
        if not audio_path.exists():
            raise ProviderError(f"Audio-Datei nicht gefunden: {audio_path}")

        # V05: Audio-Datei validieren (WAV-Header = 44 Bytes, leere Datei vermeiden)
        file_size = audio_path.stat().st_size
        if file_size <= _MIN_WAV_SIZE:
            raise ProviderError(
                f"Audio-Datei ist leer oder beschädigt ({file_size} Bytes)"
            )

        log.info(
            "STT-Anfrage: %s (Sprache: %s, Modell: %s)",
            audio_path.name,
            language,
            self._model,
        )
        if prompt:
            log.info("STT-Prompt: %s", prompt)

        # V01: Retry-Loop fuer transiente Fehler
        last_error: Exception | None = None
        for attempt in range(1, _MAX_RETRIES + 1):
            try:
                with open(audio_path, "rb") as audio_file:
                    transcription = self._client.audio.transcriptions.create(
                        model=self._model,
                        file=audio_file,
                        language=language,
                        prompt=prompt,
                        response_format="text",
                        temperature=0.0,
                    )
                break  # Erfolg
            except groq.AuthenticationError as e:
                raise ProviderError(f"API-Key ungültig: {e}") from e
            except _RETRYABLE_ERRORS as e:
                last_error = e
                if attempt < _MAX_RETRIES:
                    delay = _RETRY_BASE_DELAY * (2 ** (attempt - 1))
                    log.warning(
                        "STT-Versuch %d/%d fehlgeschlagen: %s - Retry in %.1fs",
                        attempt, _MAX_RETRIES, e, delay,
                    )
                    time.sleep(delay)
                else:
                    log.error("STT: Alle %d Versuche fehlgeschlagen", _MAX_RETRIES)
            except groq.APIError as e:
                raise ProviderError(f"GroqCloud API-Fehler: {e}") from e
        else:
            # Alle Retries erschoepft
            e = last_error
            if isinstance(e, groq.RateLimitError):
                raise ProviderError(f"Rate Limit erreicht: {e}") from e
            elif isinstance(e, groq.APITimeoutError):
                raise ProviderError(f"GroqCloud Timeout: {e}") from e
            else:
                raise ProviderError(f"Keine Verbindung zu GroqCloud: {e}") from e

        # response_format="text" gibt direkt einen String zurück
        text = transcription.strip() if isinstance(transcription, str) else transcription.text.strip()

        log.info("STT-Ergebnis: %d Zeichen", len(text))
        return text


class GroqLLMProvider(AbstractLLMProvider):
    """GroqCloud LLM-Provider für Textformatierung.

    Nutzt openai/gpt-oss-20b für kontextabhängige Formatierung.
    Der Groq-Client wird einmal instanziiert und wiederverwendet.
    """

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "openai/gpt-oss-20b",
        temperature: float | None = None,
    ) -> None:
        self._model = model
        self._temperature = temperature
        self._last_usage: dict[str, int] | None = None
        try:
            self._client = groq.Groq(api_key=api_key)
        except groq.GroqError as e:
            raise ProviderError(f"Groq-Client konnte nicht erstellt werden: {e}") from e
        log.info("GroqLLMProvider initialisiert (Modell: %s, Temperature: %s)", self._model, self._temperature)

    @property
    def last_usage(self) -> dict[str, int] | None:
        """Token-Usage der letzten LLM-Anfrage."""
        return self._last_usage

    def _build_messages(
        self, system_prompt: str, text: str
    ) -> list[dict[str, str]]:
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"<transcript>{text}</transcript>"},
        ]

    def _completion_kwargs(self) -> dict:
        """Baut gemeinsame kwargs für chat.completions.create."""
        kwargs: dict = {}
        if self._temperature is not None:
            kwargs["temperature"] = self._temperature
        return kwargs

    def format_text(self, system_prompt: str, text: str) -> str:
        log.info("LLM-Anfrage (non-streaming, Modell: %s, Temperature: %s)", self._model, self._temperature)
        self._last_usage = None

        # V01: Retry-Loop fuer transiente Fehler
        last_error: Exception | None = None
        for attempt in range(1, _MAX_RETRIES + 1):
            try:
                response = self._client.chat.completions.create(
                    model=self._model,
                    messages=self._build_messages(system_prompt, text),
                    stream=False,
                    **self._completion_kwargs(),
                )
                break  # Erfolg
            except groq.AuthenticationError as e:
                raise ProviderError(f"API-Key ungültig: {e}") from e
            except _RETRYABLE_ERRORS as e:
                last_error = e
                if attempt < _MAX_RETRIES:
                    delay = _RETRY_BASE_DELAY * (2 ** (attempt - 1))
                    log.warning(
                        "LLM-Versuch %d/%d fehlgeschlagen: %s - Retry in %.1fs",
                        attempt, _MAX_RETRIES, e, delay,
                    )
                    time.sleep(delay)
                else:
                    log.error("LLM: Alle %d Versuche fehlgeschlagen", _MAX_RETRIES)
            except groq.APIError as e:
                raise ProviderError(f"GroqCloud API-Fehler: {e}") from e
        else:
            e = last_error
            if isinstance(e, groq.RateLimitError):
                raise ProviderError(f"Rate Limit erreicht: {e}") from e
            elif isinstance(e, groq.APITimeoutError):
                raise ProviderError(f"GroqCloud Timeout: {e}") from e
            else:
                raise ProviderError(f"Keine Verbindung zu GroqCloud: {e}") from e

        # Usage-Daten erfassen
        if hasattr(response, "usage") and response.usage:
            self._last_usage = {
                "prompt_tokens": response.usage.prompt_tokens or 0,
                "completion_tokens": response.usage.completion_tokens or 0,
            }

        result = response.choices[0].message.content or ""
        result = result.strip()
        log.info("LLM-Ergebnis: %d Zeichen", len(result))
        return result

    def format_text_stream(self, system_prompt: str, text: str) -> Iterator[str]:
        log.info("LLM-Anfrage (streaming, Modell: %s, Temperature: %s)", self._model, self._temperature)
        self._last_usage = None

        # V01: Retry-Loop fuer transiente Fehler beim Stream-Aufbau
        last_error: Exception | None = None
        for attempt in range(1, _MAX_RETRIES + 1):
            try:
                stream = self._client.chat.completions.create(
                    model=self._model,
                    messages=self._build_messages(system_prompt, text),
                    stream=True,
                    **self._completion_kwargs(),
                )
                break  # Erfolg
            except groq.AuthenticationError as e:
                raise ProviderError(f"API-Key ungültig: {e}") from e
            except _RETRYABLE_ERRORS as e:
                last_error = e
                if attempt < _MAX_RETRIES:
                    delay = _RETRY_BASE_DELAY * (2 ** (attempt - 1))
                    log.warning(
                        "LLM-Stream-Versuch %d/%d fehlgeschlagen: %s - Retry in %.1fs",
                        attempt, _MAX_RETRIES, e, delay,
                    )
                    time.sleep(delay)
                else:
                    log.error("LLM-Stream: Alle %d Versuche fehlgeschlagen", _MAX_RETRIES)
            except groq.APIError as e:
                raise ProviderError(f"GroqCloud API-Fehler: {e}") from e
        else:
            e = last_error
            if isinstance(e, groq.RateLimitError):
                raise ProviderError(f"Rate Limit erreicht: {e}") from e
            elif isinstance(e, groq.APITimeoutError):
                raise ProviderError(f"GroqCloud Timeout: {e}") from e
            else:
                raise ProviderError(f"Keine Verbindung zu GroqCloud: {e}") from e

        # V02: Stream-Iteration in try/except — Verbindungsabbruch waehrend Streaming erkennen
        total_chars = 0
        try:
            for chunk in stream:
                delta = chunk.choices[0].delta.content
                if delta:
                    total_chars += len(delta)
                    yield delta
                # Groq streaming: Usage im letzten Chunk via x_groq
                if (
                    hasattr(chunk, "x_groq")
                    and chunk.x_groq
                    and hasattr(chunk.x_groq, "usage")
                    and chunk.x_groq.usage
                ):
                    usage = chunk.x_groq.usage
                    self._last_usage = {
                        "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
                        "completion_tokens": getattr(usage, "completion_tokens", 0) or 0,
                    }
        except groq.APIError as e:
            raise ProviderError(
                f"LLM-Stream abgebrochen nach {total_chars} Zeichen: {e}"
            ) from e
        except Exception as e:
            raise ProviderError(
                f"LLM-Stream abgebrochen nach {total_chars} Zeichen: {e}"
            ) from e
        log.info("LLM-Stream abgeschlossen: %d Zeichen", total_chars)
