"""PayPerTranscript - Voice-to-Text mit Pay-per-Use Pricing."""

__version__ = "0.3.0"
