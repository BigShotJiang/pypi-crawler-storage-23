"""Pfad-Aufloesung fuer Assets.

Assets liegen im paypertranscript-Package-Verzeichnis unter assets/.
"""

from pathlib import Path

_PACKAGE_DIR = Path(__file__).resolve().parent.parent


def get_assets_dir() -> Path:
    """Gibt den Pfad zum assets/ Verzeichnis zurueck."""
    return _PACKAGE_DIR / "assets"


def get_styles_dir() -> Path:
    """Gibt den Pfad zum assets/styles/ Verzeichnis zurueck."""
    return get_assets_dir() / "styles"


def get_sounds_dir() -> Path:
    """Gibt den Pfad zum assets/sounds/ Verzeichnis zurueck."""
    return get_assets_dir() / "sounds"


def get_icons_dir() -> Path:
    """Gibt den Pfad zum assets/icons/ Verzeichnis zurueck."""
    return get_assets_dir() / "icons"
