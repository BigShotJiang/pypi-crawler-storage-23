"""Logging-System für PayPerTranscript.

Rotierende Log-Dateien in %APPDATA%\\PayPerTranscript\\logs\\,
RotatingFileHandler mit max. 5MB pro Datei, 3 Backups.
"""

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

APP_NAME = "PayPerTranscript"
APPDATA_DIR = Path.home() / "AppData" / "Roaming" / APP_NAME
LOG_DIR = APPDATA_DIR / "logs"

LOG_FORMAT = "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
LOG_FILE = "paypertranscript.log"
MAX_BYTES = 5 * 1024 * 1024  # 5 MB
BACKUP_COUNT = 3


def setup_logging(debug: bool = False) -> None:
    """Initialisiert das Logging-System.

    Args:
        debug: Wenn True, wird DEBUG-Level geloggt, sonst INFO.
    """
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    level = logging.DEBUG if debug else logging.INFO
    formatter = logging.Formatter(LOG_FORMAT, datefmt=LOG_DATE_FORMAT)

    # Root-Logger konfigurieren
    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    # Vorhandene Handler entfernen (bei erneutem Aufruf)
    root_logger.handlers.clear()

    # Datei-Handler (rotierend)
    file_handler = RotatingFileHandler(
        LOG_DIR / LOG_FILE,
        maxBytes=MAX_BYTES,
        backupCount=BACKUP_COUNT,
        encoding="utf-8",
    )
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    # Console-Handler (stderr)
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)


def get_logger(name: str) -> logging.Logger:
    """Gibt einen benannten Logger zurück.

    Args:
        name: Modul-Name (z.B. 'core.config', 'providers.groq').
    """
    return logging.getLogger(f"{APP_NAME}.{name}")
