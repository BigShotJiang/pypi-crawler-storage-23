"""Auto-Update von PyPI - Version pruefen, installieren, neustarten.

Nutzt nur Stdlib (urllib, subprocess) um PySide6-Imports zu vermeiden.
Wird sowohl beim Startup (vor UI-Init) als auch periodisch waehrend der Laufzeit genutzt.
"""

import json
import os
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path

from paypertranscript.core.logging import get_logger

log = get_logger("core.updater")

PYPI_URL = "https://pypi.org/pypi/PayPerTranscript/json"
TIMEOUT = 10  # Sekunden fuer PyPI-Anfrage


def _parse_version(v: str) -> tuple[int, ...]:
    """Parst '0.2.0' zu (0, 2, 0) fuer Vergleich."""
    return tuple(int(x) for x in v.strip().split("."))


def get_latest_version() -> str | None:
    """Fragt PyPI nach der neuesten Version. Gibt None bei Fehler/Timeout."""
    try:
        req = urllib.request.Request(PYPI_URL, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            data = json.loads(resp.read())
        return data["info"]["version"]
    except Exception as e:
        log.warning("PyPI-Version konnte nicht abgefragt werden: %s", e)
        return None


def is_update_available(current: str, latest: str) -> bool:
    """True wenn latest > current (Semver-Vergleich)."""
    try:
        return _parse_version(latest) > _parse_version(current)
    except (ValueError, TypeError):
        return False


def install_update() -> bool:
    """Fuehrt pip install --upgrade aus. Gibt True bei Erfolg."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "paypertranscript"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode == 0:
            log.info("Update erfolgreich installiert")
            return True
        log.error("pip install fehlgeschlagen: %s", result.stderr)
        return False
    except Exception as e:
        log.error("Update-Installation fehlgeschlagen: %s", e)
        return False


def restart_app() -> None:
    """Startet die App neu (neuer Prozess, aktueller wird beendet)."""
    entry = shutil.which("paypertranscript")
    if entry:
        subprocess.Popen([entry])
    else:
        subprocess.Popen([sys.executable, "-m", "paypertranscript"])
    log.info("App wird neu gestartet...")
    sys.exit(0)


def check_and_auto_update() -> bool:
    """Startup-Check: Prueft Config, dann PyPI, dann Install+Restart.

    Liest config.json direkt (ohne ConfigManager), um schwere Imports zu vermeiden.
    Gibt True zurueck wenn ein Neustart erfolgt (wird durch sys.exit nicht erreicht).
    """
    # Config direkt lesen um zu pruefen ob Auto-Update aktiv ist
    config_file = Path(os.environ.get("APPDATA", "")) / "PayPerTranscript" / "config.json"
    if config_file.exists():
        try:
            cfg = json.loads(config_file.read_text(encoding="utf-8"))
            if not cfg.get("updates", {}).get("auto_update", True):
                log.info("Auto-Update deaktiviert - uebersprungen")
                return False
        except Exception:
            pass  # Bei Lesefehler: Default = Update aktiv

    from paypertranscript import __version__

    latest = get_latest_version()
    if latest is None:
        return False

    if not is_update_available(__version__, latest):
        log.info("Kein Update verfuegbar (aktuell: %s, PyPI: %s)", __version__, latest)
        return False

    log.info("Update verfuegbar: %s - %s - installiere...", __version__, latest)
    if install_update():
        restart_app()
        return True  # wird nicht erreicht (sys.exit), aber fuer Typsicherheit

    return False
