"""Audio-Aufnahme für PayPerTranscript.

Callback-basiertes Recording mit sounddevice (16kHz, Mono, int16).
Persistenter Stream - wird einmal erstellt und wiederverwendet.
"""

import threading
import time
from pathlib import Path

import numpy as np
import sounddevice as sd
import soundfile as sf

from paypertranscript.core.logging import get_logger

log = get_logger("core.recorder")

SAMPLE_RATE = 16000
CHANNELS = 1
DTYPE = "int16"
BLOCKSIZE = 1024  # Frames pro Callback (~64ms bei 16kHz)


class AudioRecorder:
    """Nimmt Audio auf via sounddevice InputStream.

    Nutzt einen persistenten Stream mit Callback. Frames werden in einer
    Liste gesammelt und bei Stop mit numpy.concatenate() zusammengeführt.
    """

    def __init__(self) -> None:
        self._frames: list[np.ndarray] = []
        self._is_recording = False
        self._lock = threading.Lock()
        self._stream: sd.InputStream | None = None
        self._start_time: float = 0.0
        self._amplitude: float = 0.0  # Aktuelle Amplitude für Visualizer

    def _audio_callback(
        self,
        indata: np.ndarray,
        frames: int,
        time_info: object,
        status: sd.CallbackFlags,
    ) -> None:
        """Callback des InputStream - sammelt Frames während der Aufnahme."""
        if status:
            log.warning("Audio-Callback Status: %s", status)
        if self._is_recording:
            self._frames.append(indata.copy())
            # Amplitude berechnen (RMS, normalisiert auf 0-1 für int16)
            self._amplitude = float(np.sqrt(np.mean(indata.astype(np.float32) ** 2)) / 32768.0)

    def start_stream(self) -> None:
        """Erstellt und startet den persistenten Audio-Stream."""
        if self._stream is not None:
            log.debug("Audio-Stream existiert bereits")
            return

        try:
            self._stream = sd.InputStream(
                samplerate=SAMPLE_RATE,
                channels=CHANNELS,
                dtype=DTYPE,
                blocksize=BLOCKSIZE,
                callback=self._audio_callback,
            )
            self._stream.start()
            log.info("Audio-Stream gestartet (%.0f Hz, %d Kanal, %s)", SAMPLE_RATE, CHANNELS, DTYPE)
        except sd.PortAudioError as e:
            log.error("Audio-Stream konnte nicht gestartet werden: %s", e)
            self._stream = None
            raise

    def stop_stream(self) -> None:
        """Stoppt und schließt den persistenten Audio-Stream."""
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except sd.PortAudioError as e:
                log.warning("Fehler beim Schließen des Audio-Streams: %s", e)
            self._stream = None
            log.info("Audio-Stream gestoppt")

    def start_recording(self) -> None:
        """Startet die Aufnahme (sammelt ab jetzt Frames)."""
        with self._lock:
            if self._is_recording:
                log.warning("Aufnahme läuft bereits")
                return

            self._frames.clear()
            self._amplitude = 0.0
            self._start_time = time.perf_counter()
            self._is_recording = True
            log.info("Aufnahme gestartet")

    def stop_recording(self) -> np.ndarray | None:
        """Stoppt die Aufnahme und gibt die aufgenommenen Frames zurück.

        Returns:
            NumPy-Array mit Audio-Daten (int16) oder None wenn keine Daten.
        """
        with self._lock:
            if not self._is_recording:
                log.warning("Keine aktive Aufnahme zum Stoppen")
                return None

            self._is_recording = False
            duration = time.perf_counter() - self._start_time
            frames = self._frames.copy()
            self._frames.clear()
            self._amplitude = 0.0

        if not frames:
            log.warning("Aufnahme gestoppt - keine Audio-Daten aufgenommen")
            return None

        audio = np.concatenate(frames)
        actual_duration = len(audio) / SAMPLE_RATE
        log.info(
            "Aufnahme gestoppt - Dauer: %.2fs (%.2fs wall), %d Samples",
            actual_duration,
            duration,
            len(audio),
        )
        return audio

    def save_wav(self, audio: np.ndarray, path: Path) -> Path:
        """Speichert Audio-Daten als WAV-Datei.

        Args:
            audio: NumPy-Array mit Audio-Daten (int16).
            path: Ziel-Pfad für die WAV-Datei.

        Returns:
            Der Pfad zur gespeicherten Datei.
        """
        sf.write(str(path), audio, SAMPLE_RATE, subtype="PCM_16")
        file_size = path.stat().st_size
        duration = len(audio) / SAMPLE_RATE
        log.info(
            "WAV gespeichert: %s (%.2fs, %.1f KB)",
            path.name,
            duration,
            file_size / 1024,
        )
        return path

    @property
    def is_recording(self) -> bool:
        """Gibt zurück, ob gerade aufgenommen wird."""
        return self._is_recording

    @property
    def amplitude(self) -> float:
        """Aktuelle Audio-Amplitude (0.0-1.0) für Visualizer."""
        return self._amplitude

    @property
    def recording_duration(self) -> float:
        """Aktuelle Aufnahmedauer in Sekunden (0 wenn nicht aufgenommen wird)."""
        if self._is_recording:
            return time.perf_counter() - self._start_time
        return 0.0
