"""Einstellungs-Seite fuer das MainWindow.

Konsolidierte Einstellungen in gruppierten Sektionen (ScrollArea).
Alle Aenderungen werden sofort gespeichert (Auto-Save).
"""

import threading

from PySide6.QtCore import QObject, Qt, Signal, Slot
from PySide6.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QRadioButton,
    QScrollArea,
    QSlider,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from paypertranscript.core.config import ConfigManager, load_api_key, save_api_key
from paypertranscript.core.hotkey import HotkeyListener
from paypertranscript.core.logging import get_logger
from paypertranscript.ui.constants import (
    HOLD_PRESETS,
    LANGUAGES,
    LLM_MODEL_DEFAULTS,
    LLM_MODELS,
    STT_MODELS,
    TOGGLE_PRESETS,
)

log = get_logger("ui.pages.settings")


class _ApiTestSignals(QObject):
    """Signals fuer die API-Key-Validierung im Background-Thread."""

    success = Signal()
    failure = Signal(str)


class SettingsPage(QWidget):
    """Einstellungs-Seite mit gruppierten Sektionen."""

    def __init__(
        self,
        config: ConfigManager,
        hotkey_listener: HotkeyListener | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._config = config
        self._hotkey_listener = hotkey_listener
        self._updating = False

        self._api_signals = _ApiTestSignals()
        self._api_signals.success.connect(self._on_api_test_success)
        self._api_signals.failure.connect(self._on_api_test_failure)

        self._setup_ui()
        self._load_values()

    def _setup_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        scroll.setStyleSheet("QScrollArea { background-color: transparent; border: none; }")

        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(28, 28, 28, 28)
        layout.setSpacing(16)

        title = QLabel("Einstellungen")
        title.setProperty("heading", True)
        layout.addWidget(title)

        # === Allgemein ===
        general_group = QGroupBox("Allgemein")
        general_layout = QVBoxLayout(general_group)
        general_layout.setSpacing(10)
        general_layout.setContentsMargins(16, 12, 16, 16)

        # Sprache
        lang_label = QLabel("Transkriptions-Sprache:")
        general_layout.addWidget(lang_label)

        self._lang_combo = QComboBox()
        for code, name in LANGUAGES:
            self._lang_combo.addItem(name, code)
        self._lang_combo.currentIndexChanged.connect(self._on_language_changed)
        general_layout.addWidget(self._lang_combo)

        # Checkboxen
        self._chk_sound = QCheckBox("Sound-Feedback bei Aufnahme")
        self._chk_sound.stateChanged.connect(self._on_sound_changed)
        general_layout.addWidget(self._chk_sound)

        self._chk_autostart = QCheckBox("Autostart mit Windows")
        self._chk_autostart.stateChanged.connect(self._on_autostart_changed)
        general_layout.addWidget(self._chk_autostart)

        self._chk_streaming = QCheckBox("Streaming-Typing (experimentell)")
        self._chk_streaming.setToolTip(
            "Text wird w\u00e4hrend der LLM-Formatierung live Zeichen f\u00fcr Zeichen eingef\u00fcgt.\n"
            "Kann in manchen Anwendungen Probleme verursachen."
        )
        self._chk_streaming.stateChanged.connect(self._on_streaming_changed)
        general_layout.addWidget(self._chk_streaming)

        # Overlay-Position
        overlay_label = QLabel("Overlay-Position:")
        overlay_label.setStyleSheet("margin-top: 8px;")
        general_layout.addWidget(overlay_label)

        self._radio_mouse = QRadioButton("An Maus-Position (Standard)")
        self._radio_center = QRadioButton("Bildschirm-Mitte unten")

        self._overlay_group = QButtonGroup(self)
        self._overlay_group.addButton(self._radio_mouse, 0)
        self._overlay_group.addButton(self._radio_center, 1)
        self._overlay_group.idClicked.connect(self._on_overlay_position_changed)

        general_layout.addWidget(self._radio_mouse)
        general_layout.addWidget(self._radio_center)

        layout.addWidget(general_group)

        # === Hotkeys ===
        hotkey_group = QGroupBox("Hotkeys")
        hotkey_layout = QVBoxLayout(hotkey_group)
        hotkey_layout.setSpacing(8)
        hotkey_layout.setContentsMargins(16, 12, 16, 16)

        hold_label = QLabel("Hold-to-Record (gedr\u00fcckt halten = Aufnahme):")
        hotkey_layout.addWidget(hold_label)

        self._hold_combo = QComboBox()
        for name, _keys in HOLD_PRESETS:
            self._hold_combo.addItem(name)
        self._hold_combo.currentIndexChanged.connect(self._on_hold_hotkey_changed)
        hotkey_layout.addWidget(self._hold_combo)

        hotkey_layout.addSpacing(8)

        toggle_label = QLabel("Toggle-Hotkey (einmal dr\u00fccken = Start/Stop):")
        hotkey_layout.addWidget(toggle_label)

        self._toggle_combo = QComboBox()
        for name, _keys in TOGGLE_PRESETS:
            self._toggle_combo.addItem(name)
        self._toggle_combo.currentIndexChanged.connect(self._on_toggle_hotkey_changed)
        hotkey_layout.addWidget(self._toggle_combo)

        layout.addWidget(hotkey_group)

        # === API ===
        api_group = QGroupBox("API")
        api_layout = QVBoxLayout(api_group)
        api_layout.setSpacing(10)
        api_layout.setContentsMargins(16, 12, 16, 16)

        key_label = QLabel("GroqCloud API-Key:")
        api_layout.addWidget(key_label)

        self._key_input = QLineEdit()
        self._key_input.setPlaceholderText("gsk_...")
        self._key_input.setEchoMode(QLineEdit.EchoMode.Password)
        api_layout.addWidget(self._key_input)

        btn_row = QHBoxLayout()

        self._btn_show_key = QPushButton("Key anzeigen")
        self._btn_show_key.setFixedWidth(120)
        self._btn_show_key.setCheckable(True)
        self._btn_show_key.toggled.connect(self._on_toggle_key_visibility)
        btn_row.addWidget(self._btn_show_key)

        btn_row.addStretch()

        self._btn_save_key = QPushButton("Key speichern")
        self._btn_save_key.setFixedWidth(120)
        self._btn_save_key.clicked.connect(self._on_save_api_key)
        btn_row.addWidget(self._btn_save_key)

        self._btn_test_key = QPushButton("Key testen")
        self._btn_test_key.setFixedWidth(120)
        self._btn_test_key.clicked.connect(self._on_test_api_key)
        btn_row.addWidget(self._btn_test_key)

        api_layout.addLayout(btn_row)

        self._api_status = QLabel("")
        self._api_status.setWordWrap(True)
        api_layout.addWidget(self._api_status)

        api_layout.addSpacing(8)

        stt_label = QLabel("STT-Modell:")
        api_layout.addWidget(stt_label)

        self._stt_combo = QComboBox()
        self._stt_combo.addItems(STT_MODELS)
        self._stt_combo.currentTextChanged.connect(self._on_stt_model_changed)
        api_layout.addWidget(self._stt_combo)

        llm_label = QLabel("LLM-Modell:")
        api_layout.addWidget(llm_label)

        self._llm_combo = QComboBox()
        self._llm_combo.addItems(LLM_MODELS)
        self._llm_combo.currentTextChanged.connect(self._on_llm_model_changed)
        api_layout.addWidget(self._llm_combo)

        api_layout.addSpacing(8)

        # Temperature
        temp_header = QHBoxLayout()
        temp_label = QLabel("LLM Temperature:")
        temp_header.addWidget(temp_label)
        temp_header.addStretch()
        self._temp_value_label = QLabel("Standard")
        self._temp_value_label.setProperty("subheading", True)
        temp_header.addWidget(self._temp_value_label)
        api_layout.addLayout(temp_header)

        self._temp_slider = QSlider(Qt.Orientation.Horizontal)
        self._temp_slider.setRange(0, 20)  # 0..20 → 0.0..2.0 in 0.1-Schritten
        self._temp_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self._temp_slider.setTickInterval(2)
        self._temp_slider.setSingleStep(1)
        self._temp_slider.setPageStep(2)
        self._temp_slider.valueChanged.connect(self._on_temperature_changed)
        api_layout.addWidget(self._temp_slider)

        self._temp_hint = QLabel("")
        self._temp_hint.setProperty("subheading", True)
        self._temp_hint.setWordWrap(True)
        api_layout.addWidget(self._temp_hint)

        api_layout.addSpacing(4)

        hint = QLabel("Modell-\u00c4nderungen werden nach Neustart wirksam.")
        hint.setProperty("subheading", True)
        api_layout.addWidget(hint)

        layout.addWidget(api_group)

        # === Daten & Updates ===
        data_group = QGroupBox("Daten & Updates")
        data_layout = QVBoxLayout(data_group)
        data_layout.setSpacing(10)
        data_layout.setContentsMargins(16, 12, 16, 16)

        retention_label = QLabel("Audio-Dateien behalten:")
        data_layout.addWidget(retention_label)

        retention_row = QHBoxLayout()
        self._retention_spin = QSpinBox()
        self._retention_spin.setRange(0, 720)
        self._retention_spin.setSuffix(" Stunden")
        self._retention_spin.setSpecialValueText("Sofort l\u00f6schen")
        self._retention_spin.valueChanged.connect(self._on_retention_changed)
        retention_row.addWidget(self._retention_spin)
        retention_row.addStretch()
        data_layout.addLayout(retention_row)

        self._chk_transcripts = QCheckBox("Transkripte speichern")
        self._chk_transcripts.setToolTip(
            "Speichert den transkribierten Text in der Tracking-Datei.\n"
            "Deaktiviert = nur Metadaten (Kosten, Dauer etc.) werden gespeichert."
        )
        self._chk_transcripts.stateChanged.connect(self._on_transcripts_changed)
        data_layout.addWidget(self._chk_transcripts)

        data_layout.addSpacing(12)

        self._chk_auto_update = QCheckBox("Automatische Updates")
        self._chk_auto_update.setToolTip(
            "Pr\u00fcft beim Start und periodisch auf neue Versionen.\n"
            "Updates werden automatisch installiert."
        )
        self._chk_auto_update.stateChanged.connect(self._on_auto_update_changed)
        data_layout.addWidget(self._chk_auto_update)

        interval_label = QLabel("Pr\u00fcfintervall:")
        data_layout.addWidget(interval_label)

        interval_row = QHBoxLayout()
        self._interval_spin = QSpinBox()
        self._interval_spin.setRange(1, 168)
        self._interval_spin.setSuffix(" Stunden")
        self._interval_spin.valueChanged.connect(self._on_interval_changed)
        interval_row.addWidget(self._interval_spin)
        interval_row.addStretch()
        data_layout.addLayout(interval_row)

        data_layout.addSpacing(8)

        from paypertranscript import __version__

        version_label = QLabel(f"Installierte Version: {__version__}")
        version_label.setProperty("subheading", True)
        data_layout.addWidget(version_label)

        layout.addWidget(data_group)

        layout.addStretch()

        scroll.setWidget(content)
        outer.addWidget(scroll)

    # -- Werte laden --

    def _load_values(self) -> None:
        self._updating = True

        language = self._config.get("general.language", "de")
        for i in range(self._lang_combo.count()):
            if self._lang_combo.itemData(i) == language:
                self._lang_combo.setCurrentIndex(i)
                break

        self._chk_sound.setChecked(self._config.get("general.sound_enabled", False))
        self._chk_autostart.setChecked(self._config.get("general.autostart", False))
        self._chk_streaming.setChecked(self._config.get("general.streaming_typing", False))

        position = self._config.get("general.overlay_position", "mouse_cursor")
        if position == "bottom_center":
            self._radio_center.setChecked(True)
        else:
            self._radio_mouse.setChecked(True)

        hold = self._config.get("general.hold_hotkey", ["ctrl", "cmd"])
        for i, (_name, keys) in enumerate(HOLD_PRESETS):
            if keys == hold:
                self._hold_combo.setCurrentIndex(i)
                break

        toggle = self._config.get("general.toggle_hotkey")
        for i, (_name, keys) in enumerate(TOGGLE_PRESETS):
            if keys == toggle:
                self._toggle_combo.setCurrentIndex(i)
                break

        api_key = load_api_key() or ""
        self._key_input.setText(api_key)

        stt_model = self._config.get("api.stt_model", "whisper-large-v3-turbo")
        idx = self._stt_combo.findText(stt_model)
        if idx >= 0:
            self._stt_combo.setCurrentIndex(idx)

        llm_model = self._config.get("api.llm_model", "openai/gpt-oss-20b")
        idx = self._llm_combo.findText(llm_model)
        if idx >= 0:
            self._llm_combo.setCurrentIndex(idx)

        llm_temp = self._config.get("api.llm_temperature", 1.0)
        # Fallback fuer alte Configs mit None
        if llm_temp is None:
            model = self._llm_combo.currentText()
            llm_temp = LLM_MODEL_DEFAULTS.get(model, (1.0, 1.0))[0]
        slider_val = round(float(llm_temp) * 10)
        self._temp_slider.setValue(max(0, min(20, slider_val)))
        self._temp_value_label.setText(f"{llm_temp:.1f}")

        self._update_temp_hint()

        self._retention_spin.setValue(self._config.get("data.audio_retention_hours", 24))
        self._chk_transcripts.setChecked(self._config.get("data.save_transcripts", False))

        self._chk_auto_update.setChecked(self._config.get("updates.auto_update", True))
        self._interval_spin.setValue(self._config.get("updates.check_interval_hours", 24))

        self._updating = False

    # -- Callbacks: Allgemein --

    def _on_language_changed(self, index: int) -> None:
        if self._updating:
            return
        code = self._lang_combo.itemData(index)
        self._config.set("general.language", code)
        log.info("Sprache geaendert: %s", code)

    def _on_sound_changed(self, state: int) -> None:
        if self._updating:
            return
        checked = state == Qt.CheckState.Checked.value
        self._config.set("general.sound_enabled", checked)

    def _on_autostart_changed(self, state: int) -> None:
        if self._updating:
            return
        checked = state == Qt.CheckState.Checked.value
        from paypertranscript.core.config import disable_autostart, enable_autostart

        success = enable_autostart() if checked else disable_autostart()
        if success:
            self._config.set("general.autostart", checked)
        else:
            self._updating = True
            self._chk_autostart.setChecked(not checked)
            self._updating = False

    def _on_streaming_changed(self, state: int) -> None:
        if self._updating:
            return
        checked = state == Qt.CheckState.Checked.value
        self._config.set("general.streaming_typing", checked)

    def _on_overlay_position_changed(self, button_id: int) -> None:
        if self._updating:
            return
        position = "mouse_cursor" if button_id == 0 else "bottom_center"
        self._config.set("general.overlay_position", position)
        log.info("Overlay-Position geaendert: %s", position)

    # -- Callbacks: Hotkeys --

    def _on_hold_hotkey_changed(self, index: int) -> None:
        if self._updating:
            return
        _name, keys = HOLD_PRESETS[index]
        self._config.set("general.hold_hotkey", keys)
        if self._hotkey_listener:
            self._hotkey_listener.update_hotkeys(hold_hotkey=keys)
        log.info("Hold-Hotkey geaendert: %s", _name)

    def _on_toggle_hotkey_changed(self, index: int) -> None:
        if self._updating:
            return
        _name, keys = TOGGLE_PRESETS[index]
        self._config.set("general.toggle_hotkey", keys)
        if self._hotkey_listener and keys is not None:
            self._hotkey_listener.update_hotkeys(toggle_hotkey=keys)
        log.info("Toggle-Hotkey geaendert: %s", _name)

    # -- Callbacks: API --

    def _on_toggle_key_visibility(self, checked: bool) -> None:
        if checked:
            self._key_input.setEchoMode(QLineEdit.EchoMode.Normal)
            self._btn_show_key.setText("Key verbergen")
        else:
            self._key_input.setEchoMode(QLineEdit.EchoMode.Password)
            self._btn_show_key.setText("Key anzeigen")

    def _on_save_api_key(self) -> None:
        key = self._key_input.text().strip()
        if not key:
            self._api_status.setText("Bitte API-Key eingeben.")
            self._api_status.setStyleSheet("color: #f87171;")
            return
        try:
            save_api_key(key)
            self._api_status.setText("API-Key gespeichert.")
            self._api_status.setStyleSheet("color: #ffffff;")
            log.info("API-Key im Keyring gespeichert")
        except Exception as e:
            self._api_status.setText(f"Fehler beim Speichern: {e}")
            self._api_status.setStyleSheet("color: #f87171;")
            log.error("API-Key konnte nicht gespeichert werden: %s", e)

    def _on_test_api_key(self) -> None:
        key = self._key_input.text().strip()
        if not key:
            self._api_status.setText("Bitte API-Key eingeben.")
            self._api_status.setStyleSheet("color: #f87171;")
            return

        self._api_status.setText("Wird gepr\u00fcft...")
        self._api_status.setStyleSheet("color: #a0a0a0;")
        self._btn_test_key.setEnabled(False)

        signals = self._api_signals

        def _test() -> None:
            try:
                import groq

                client = groq.Groq(api_key=key)
                client.models.list()
                signals.success.emit()
            except Exception as e:
                signals.failure.emit(str(e))

        threading.Thread(target=_test, daemon=True).start()

    @Slot()
    def _on_api_test_success(self) -> None:
        self._btn_test_key.setEnabled(True)
        self._api_status.setText("API-Key ist g\u00fcltig!")
        self._api_status.setStyleSheet("color: #34d399; font-weight: bold;")

    @Slot(str)
    def _on_api_test_failure(self, message: str) -> None:
        self._btn_test_key.setEnabled(True)
        if "AuthenticationError" in message or "401" in message:
            text = "API-Key ist ung\u00fcltig."
        elif "Connection" in message:
            text = "Keine Verbindung zu GroqCloud."
        else:
            text = f"Fehler: {message}"
        self._api_status.setText(text)
        self._api_status.setStyleSheet("color: #f87171;")

    def _on_stt_model_changed(self, text: str) -> None:
        if self._updating:
            return
        self._config.set("api.stt_model", text)

    def _on_llm_model_changed(self, text: str) -> None:
        if self._updating:
            return
        self._config.set("api.llm_model", text)
        # Slider auf den Standard-Wert des neuen Modells setzen
        default_temp = LLM_MODEL_DEFAULTS.get(text, (1.0, 1.0))[0]
        self._updating = True
        slider_val = round(default_temp * 10)
        self._temp_slider.setValue(max(0, min(20, slider_val)))
        self._temp_value_label.setText(f"{default_temp:.1f}")
        self._updating = False
        self._config.set("api.llm_temperature", default_temp)
        self._update_temp_hint()

    def _on_temperature_changed(self, value: int) -> None:
        if self._updating:
            return
        temp = value / 10.0
        self._temp_value_label.setText(f"{temp:.1f}")
        self._config.set("api.llm_temperature", temp)

    def _update_temp_hint(self) -> None:
        """Zeigt modellspezifischen Temperature-Hinweis."""
        model = self._llm_combo.currentText()
        meta = LLM_MODEL_DEFAULTS.get(model)
        if meta:
            default_temp, recommended_temp = meta
            self._temp_hint.setText(
                f"Standard: {default_temp:.1f} | Empfohlen: {recommended_temp:.1f}"
            )
            self._temp_hint.setVisible(True)
        else:
            self._temp_hint.setVisible(False)

    # -- Callbacks: Daten & Updates --

    def _on_retention_changed(self, value: int) -> None:
        if self._updating:
            return
        self._config.set("data.audio_retention_hours", value)

    def _on_transcripts_changed(self, state: int) -> None:
        if self._updating:
            return
        checked = state == Qt.CheckState.Checked.value
        self._config.set("data.save_transcripts", checked)

    def _on_auto_update_changed(self, state: int) -> None:
        if self._updating:
            return
        checked = state == Qt.CheckState.Checked.value
        self._config.set("updates.auto_update", checked)

    def _on_interval_changed(self, value: int) -> None:
        if self._updating:
            return
        self._config.set("updates.check_interval_hours", value)
