"""Wortlisten-Seite fuer das MainWindow.

Verwaltet die Liste korrekt zu schreibender Woerter (Whisper-Prompt).
"""

from collections.abc import Callable

from PySide6.QtCore import QEvent, QModelIndex, QRect, QSize, Qt
from PySide6.QtGui import QColor, QCursor, QDropEvent, QFont, QMouseEvent, QPainter
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QStyle,
    QStyleOptionViewItem,
    QStyledItemDelegate,
    QVBoxLayout,
    QWidget,
)

from paypertranscript.core.config import ConfigManager
from paypertranscript.core.logging import get_logger

log = get_logger("ui.pages.word_list")

_MAX_PROMPT_CHARS = 896
_PROMPT_PREFIX = "Korrekte Schreibweisen: "


class _WordItemDelegate(QStyledItemDelegate):
    """Delegate with drag-handle (left) and edit icon (right)."""

    _HANDLE_WIDTH = 28
    _EDIT_WIDTH = 36
    # Segoe MDL2 Assets ships with Windows 10/11 and has crisp vector icons
    _ICON_FONT = "Segoe MDL2 Assets"
    _ICON_DRAG = "\uE700"   # GripperBarHorizontal
    _ICON_EDIT = "\uE70F"   # Edit / Pencil

    def paint(
        self, painter: QPainter, option: QStyleOptionViewItem, index: QModelIndex
    ) -> None:
        option.state &= ~QStyle.StateFlag.State_HasFocus

        # --- Background ---
        painter.save()
        if option.state & QStyle.StateFlag.State_Selected:
            painter.fillRect(option.rect, QColor("#2a2a34"))
        elif option.state & QStyle.StateFlag.State_MouseOver:
            painter.fillRect(option.rect, QColor("#121218"))
        painter.restore()

        hovered = bool(option.state & QStyle.StateFlag.State_MouseOver)
        color_on = QColor("#a0a0a0")
        color_off = QColor("#4a4a58")

        icon_font = QFont(self._ICON_FONT, 10)

        # --- Left: drag handle ---
        painter.save()
        handle_rect = QRect(
            option.rect.left(), option.rect.top(),
            self._HANDLE_WIDTH, option.rect.height(),
        )
        painter.setFont(icon_font)
        painter.setPen(color_on if hovered else color_off)
        painter.drawText(handle_rect, Qt.AlignmentFlag.AlignCenter, self._ICON_DRAG)
        painter.restore()

        # --- Center: item text ---
        painter.save()
        text_rect = QRect(
            option.rect.left() + self._HANDLE_WIDTH,
            option.rect.top(),
            option.rect.width() - self._HANDLE_WIDTH - self._EDIT_WIDTH,
            option.rect.height(),
        )
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        painter.setPen(QColor("#ffffff") if selected else QColor("#e0e0e0"))
        painter.setFont(QFont("Segoe UI", 10))
        text = index.data(Qt.ItemDataRole.DisplayRole) or ""
        painter.drawText(
            text_rect,
            Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
            text,
        )
        painter.restore()

        # --- Right: edit icon ---
        painter.save()
        edit_rect = QRect(
            option.rect.right() - self._EDIT_WIDTH,
            option.rect.top(),
            self._EDIT_WIDTH,
            option.rect.height(),
        )
        painter.setFont(icon_font)
        painter.setPen(color_on if hovered else color_off)
        painter.drawText(edit_rect, Qt.AlignmentFlag.AlignCenter, self._ICON_EDIT)
        painter.restore()

    def editorEvent(
        self,
        event: QEvent,
        model: QModelIndex,
        option: QStyleOptionViewItem,
        index: QModelIndex,
    ) -> bool:
        """Cursor change on hover; click handling via viewport event filter."""
        if event.type() == QEvent.Type.MouseMove:
            mouse: QMouseEvent = event  # type: ignore[assignment]
            over_icon = mouse.position().x() >= option.rect.right() - self._EDIT_WIDTH
            view = option.widget
            if view is not None:
                if over_icon:
                    view.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
                else:
                    view.unsetCursor()
            return False
        return super().editorEvent(event, model, option, index)

    def sizeHint(self, option: QStyleOptionViewItem, index: QModelIndex) -> QSize:
        size = super().sizeHint(option, index)
        return QSize(size.width(), max(size.height(), 36))


class _ReorderListWidget(QListWidget):
    """QListWidget that fires a callback after drag & drop reorder."""

    def __init__(self, on_reorder: Callable[[], None], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._on_reorder = on_reorder

    def dropEvent(self, event: QDropEvent) -> None:
        super().dropEvent(event)
        self._on_reorder()


class WordListPage(QWidget):
    """Editor fuer die Wortliste (Whisper Misspelled-Words-Prompt)."""

    def __init__(self, config: ConfigManager, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._config = config
        self._updating = False
        self._setup_ui()
        self._load_words()

    def _setup_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 28, 28, 28)
        layout.setSpacing(12)

        title = QLabel("Wortliste")
        title.setProperty("heading", True)
        layout.addWidget(title)

        desc = QLabel(
            "W\u00f6rter die Whisper korrekt schreiben soll \u2013 "
            "z.\u202fB. deinen Namen, Fachbegriffe oder Produktnamen."
        )
        desc.setProperty("subheading", True)
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # Eingabezeile + Hinzufuegen
        input_row = QHBoxLayout()
        self._word_input = QLineEdit()
        self._word_input.setPlaceholderText("Neues Wort\u2026")
        self._word_input.returnPressed.connect(self._add_word)
        input_row.addWidget(self._word_input)

        btn_add = QPushButton("Hinzuf\u00fcgen")
        btn_add.setProperty("primary", True)
        btn_add.setMinimumWidth(120)
        btn_add.clicked.connect(self._add_word)
        input_row.addWidget(btn_add)
        layout.addLayout(input_row)

        # Wortliste mit Drag & Drop und Stift-Icon
        self._list = _ReorderListWidget(self._save_words)
        self._list.setItemDelegate(_WordItemDelegate(self._list))
        self._list.setMouseTracking(True)
        self._list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self._list.setDefaultDropAction(Qt.DropAction.MoveAction)
        self._list.itemChanged.connect(self._on_word_edited)
        layout.addWidget(self._list, 1)

        # Viewport event filter for reliable edit icon click handling
        self._list.viewport().installEventFilter(self)

        # Entfernen + Token-Counter
        action_row = QHBoxLayout()
        btn_remove = QPushButton("Entfernen")
        btn_remove.setFixedWidth(100)
        btn_remove.clicked.connect(self._remove_word)
        action_row.addWidget(btn_remove)

        action_row.addStretch()

        self._counter_label = QLabel("")
        action_row.addWidget(self._counter_label)
        layout.addLayout(action_row)

    def eventFilter(self, watched: object, event: QEvent) -> bool:
        """Intercept mouse clicks on the edit (pencil) icon."""
        if (
            event.type() == QEvent.Type.MouseButtonRelease
            and watched is self._list.viewport()
        ):
            mouse: QMouseEvent = event  # type: ignore[assignment]
            pos = mouse.position().toPoint()
            index = self._list.indexAt(pos)
            if index.isValid():
                rect = self._list.visualRect(index)
                if mouse.position().x() >= rect.right() - _WordItemDelegate._EDIT_WIDTH:
                    self._list.edit(index)
                    return True
        return super().eventFilter(watched, event)

    def _load_words(self) -> None:
        self._updating = True
        words = self._config.get("words.misspelled_words", [])
        self._list.clear()
        for word in words:
            self._add_list_item(word)
        self._update_counter()
        self._updating = False

    def _add_list_item(self, text: str) -> QListWidgetItem:
        """Create a list item with correct flags for editing and drag & drop."""
        item = QListWidgetItem(text)
        item.setFlags(
            Qt.ItemFlag.ItemIsSelectable
            | Qt.ItemFlag.ItemIsEnabled
            | Qt.ItemFlag.ItemIsEditable
            | Qt.ItemFlag.ItemIsDragEnabled
        )
        self._list.addItem(item)
        return item

    def _save_words(self) -> None:
        words = [self._list.item(i).text() for i in range(self._list.count())]
        self._config.set("words.misspelled_words", words)
        self._update_counter()

    def _add_word(self) -> None:
        word = self._word_input.text().strip()
        if not word:
            return

        for i in range(self._list.count()):
            if self._list.item(i).text().lower() == word.lower():
                self._word_input.clear()
                return

        self._add_list_item(word)
        self._word_input.clear()
        self._word_input.setFocus()
        self._save_words()
        log.info("Wort hinzugefuegt: %s", word)

    def _remove_word(self) -> None:
        current = self._list.currentRow()
        if current < 0:
            return
        item = self._list.takeItem(current)
        if item:
            log.info("Wort entfernt: %s", item.text())
        self._save_words()

    def _on_word_edited(self, item: QListWidgetItem) -> None:
        if self._updating:
            return
        new_text = item.text().strip()
        if not new_text:
            self._list.takeItem(self._list.row(item))
            self._save_words()
            return
        for i in range(self._list.count()):
            other = self._list.item(i)
            if other is not item and other.text().lower() == new_text.lower():
                self._load_words()
                return
        self._save_words()
        log.info("Wort bearbeitet: %s", new_text)

    def _update_counter(self) -> None:
        words = [self._list.item(i).text() for i in range(self._list.count())]
        if words:
            prompt = _PROMPT_PREFIX + ", ".join(words)
        else:
            prompt = ""
        chars_used = len(prompt)
        percentage = (chars_used / _MAX_PROMPT_CHARS) * 100 if _MAX_PROMPT_CHARS > 0 else 0

        self._counter_label.setText(f"{chars_used} / {_MAX_PROMPT_CHARS} Zeichen")

        if percentage > 90:
            self._counter_label.setStyleSheet("color: #f87171;")
        elif percentage > 75:
            self._counter_label.setStyleSheet("color: #f0a500;")
        else:
            self._counter_label.setStyleSheet("color: #ffffff;")
