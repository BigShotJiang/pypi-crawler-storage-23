"""Animierte Basis-Dialoge fuer PayPerTranscript.

Stellt AnimatedDialog bereit: QDialog mit Fade-In-Animation beim Erscheinen,
konsistent mit dem Overlay-Design (OutCubic Easing, 150ms).
"""

from PySide6.QtCore import QEasingCurve, QPropertyAnimation
from PySide6.QtWidgets import QDialog, QWidget


class AnimatedDialog(QDialog):
    """QDialog mit Fade-In-Animation beim Erscheinen."""

    _FADE_IN_MS = 150

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._fade_anim: QPropertyAnimation | None = None

    def showEvent(self, event: object) -> None:
        super().showEvent(event)
        self._fade_in()

    def _fade_in(self) -> None:
        self._fade_anim = QPropertyAnimation(self, b"windowOpacity")
        self._fade_anim.setDuration(self._FADE_IN_MS)
        self._fade_anim.setStartValue(0.0)
        self._fade_anim.setEndValue(1.0)
        self._fade_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._fade_anim.start()
