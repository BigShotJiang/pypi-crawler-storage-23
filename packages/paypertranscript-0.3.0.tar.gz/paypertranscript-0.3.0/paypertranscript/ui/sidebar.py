"""Sidebar-Navigation fuer das MainWindow.

Custom QPainter-gerenderte Sidebar mit geometrischen Icons,
passend zum Overlay-Aesthetic.
"""

import math

from PySide6.QtCore import QPoint, QRect, QSize, Qt, Signal
from PySide6.QtGui import QColor, QCursor, QFont, QMouseEvent, QPainter, QPaintEvent, QPen, QPixmap
from PySide6.QtWidgets import QLabel, QSizePolicy, QWidget

from paypertranscript.core.paths import get_icons_dir


class _NavItem:
    """Einzelner Navigationseintrag."""

    __slots__ = ("label", "page_index")

    def __init__(self, label: str, page_index: int) -> None:
        self.label = label
        self.page_index = page_index


# Navigationseintraege
_NAV_ITEMS = [
    _NavItem("Home", 0),
    _NavItem("Statistiken", 1),
    _NavItem("Einstellungen", 2),
    _NavItem("Wortliste", 3),
    _NavItem("Fenster", 4),
]

_SIDEBAR_BG = QColor("#0e0e14")
_ITEM_HEIGHT = 40
_ICON_SIZE = 16
_TOP_PADDING = 16  # Unter dem Logo
_LOGO_AREA_HEIGHT = 72
_BOTTOM_ICON_SIZE = 14
_BOTTOM_ITEM_HEIGHT = 34

# Bottom layout (von oben nach unten):
# separator(1) + gap(14) + restart(34) + quit(34) + gap(12) + version(18) + padding(12) = 125
_BOTTOM_AREA_HEIGHT = 125

# Hit-test IDs fuer Bottom-Bereich
_HIT_NONE = -1
_HIT_RESTART = -2
_HIT_QUIT = -3
_HIT_UPDATE = -4


class Sidebar(QWidget):
    """Custom-gemalte Sidebar-Navigation."""

    page_changed = Signal(int)
    restart_requested = Signal()
    quit_requested = Signal()
    update_check_requested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._active_index = 0
        self._hover_hit = _HIT_NONE
        self.setFixedWidth(180)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        self.setMouseTracking(True)

        # Logo als QLabel (DPI-korrekt, kein QPainter-Skalierungsproblem)
        logo_size = 48
        self._logo_label = QLabel(self)
        self._logo_label.setFixedSize(logo_size, logo_size)
        self._logo_label.setStyleSheet("background: transparent;")
        self._logo_label.setScaledContents(True)
        logo_path = get_icons_dir() / "app_big.png"
        if logo_path.exists():
            self._logo_label.setPixmap(QPixmap(str(logo_path)))
        lx = (180 - logo_size) // 2
        ly = (_LOGO_AREA_HEIGHT - logo_size) // 2
        self._logo_label.move(lx, ly)

    def set_active(self, index: int) -> None:
        """Setzt den aktiven Navigationseintrag."""
        if 0 <= index < len(_NAV_ITEMS):
            self._active_index = index
            self.update()

    # -- Rect-Berechnungen --

    def _item_rect(self, index: int) -> QRect:
        """Berechnet das Rechteck fuer einen Navigationseintrag."""
        y = _LOGO_AREA_HEIGHT + _TOP_PADDING + index * _ITEM_HEIGHT
        return QRect(0, y, self.width(), _ITEM_HEIGHT)

    def _separator_y(self) -> int:
        """Y-Position der Trennlinie ueber dem Footer."""
        return self.height() - _BOTTOM_AREA_HEIGHT

    def _restart_rect(self) -> QRect:
        """Berechnet das Rechteck fuer den Neustart-Eintrag."""
        return QRect(0, self._separator_y() + 15, self.width(), _BOTTOM_ITEM_HEIGHT)

    def _quit_rect(self) -> QRect:
        """Berechnet das Rechteck fuer den Beenden-Eintrag."""
        return QRect(0, self._separator_y() + 15 + _BOTTOM_ITEM_HEIGHT, self.width(), _BOTTOM_ITEM_HEIGHT)

    def _update_rect(self) -> QRect:
        """Berechnet das Rechteck fuer die klickbare Versionsnummer."""
        return QRect(0, self.height() - 30, self.width(), 18)

    def _hit_test(self, pos: QPoint) -> int:
        """Gibt den Hit-Test-ID zurueck: Nav-Index, _HIT_RESTART, _HIT_QUIT, _HIT_UPDATE oder _HIT_NONE."""
        for i in range(len(_NAV_ITEMS)):
            if self._item_rect(i).contains(pos):
                return i
        if self._restart_rect().contains(pos):
            return _HIT_RESTART
        if self._quit_rect().contains(pos):
            return _HIT_QUIT
        if self._update_rect().contains(pos):
            return _HIT_UPDATE
        return _HIT_NONE

    # -- Events --

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() != Qt.MouseButton.LeftButton:
            return

        hit = self._hit_test(event.pos())

        if hit >= 0 and hit != self._active_index:
            self._active_index = hit
            self.page_changed.emit(hit)
            self.update()
        elif hit == _HIT_UPDATE:
            self.update_check_requested.emit()
        elif hit == _HIT_RESTART:
            self.restart_requested.emit()
        elif hit == _HIT_QUIT:
            self.quit_requested.emit()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        hit = self._hit_test(event.pos())
        if hit != self._hover_hit:
            self._hover_hit = hit
            if hit != _HIT_NONE:
                self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
            else:
                self.setCursor(QCursor(Qt.CursorShape.ArrowCursor))
            self.update()

    def leaveEvent(self, event: object) -> None:
        self._hover_hit = _HIT_NONE
        self.setCursor(QCursor(Qt.CursorShape.ArrowCursor))
        self.update()

    def paintEvent(self, event: QPaintEvent) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w = self.width()
        h = self.height()

        # Hintergrund
        p.fillRect(0, 0, w, h, _SIDEBAR_BG)

        # Logo wird als QLabel-Child gerendert (DPI-korrekt)

        # Nav-Items
        font_normal = QFont("Segoe UI", 10)
        font_bold = QFont("Segoe UI", 10, QFont.Weight.Bold)

        for i, item in enumerate(_NAV_ITEMS):
            rect = self._item_rect(i)
            is_active = (i == self._active_index)
            is_hover = (self._hover_hit == i)

            # Hover-Hintergrund
            if is_hover and not is_active:
                p.fillRect(rect, QColor("#1c1c24"))

            # Aktiver Indikator (weisser Balken links)
            if is_active:
                p.fillRect(0, rect.y() + 8, 3, rect.height() - 16, QColor("#ffffff"))

            # Icon zeichnen
            icon_x = 20
            icon_y = rect.y() + (rect.height() - _ICON_SIZE) // 2
            icon_color = QColor("#ffffff") if is_active else QColor("#a0a0a0")
            self._draw_nav_icon(p, i, icon_x, icon_y, _ICON_SIZE, icon_color)

            # Label
            p.setFont(font_bold if is_active else font_normal)
            p.setPen(QColor("#ffffff") if is_active else QColor("#a0a0a0"))
            text_x = icon_x + _ICON_SIZE + 10
            p.drawText(text_x, rect.y(), rect.width() - text_x - 8, rect.height(),
                        Qt.AlignmentFlag.AlignVCenter, item.label)

        # -- Footer-Bereich --

        sep_y = self._separator_y()

        # Trennlinie
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#2a2a34"))
        p.drawRect(20, sep_y, w - 40, 1)

        # Neustart (Action-Item mit Icon)
        restart_r = self._restart_rect()
        is_restart_hover = (self._hover_hit == _HIT_RESTART)

        if is_restart_hover:
            p.fillRect(restart_r, QColor("#1c1c24"))

        b_icon_x = 20
        b_icon_y = restart_r.y() + (restart_r.height() - _BOTTOM_ICON_SIZE) // 2
        restart_color = QColor("#d0d0d0") if is_restart_hover else QColor("#606060")
        self._draw_restart_icon(p, b_icon_x, b_icon_y, _BOTTOM_ICON_SIZE, restart_color)

        p.setFont(QFont("Segoe UI", 9))
        p.setPen(restart_color)
        b_text_x = b_icon_x + _BOTTOM_ICON_SIZE + 10
        p.drawText(b_text_x, restart_r.y(), restart_r.width() - b_text_x - 8, restart_r.height(),
                    Qt.AlignmentFlag.AlignVCenter, "Neustart")

        # Beenden (Action-Item mit Icon)
        quit_r = self._quit_rect()
        is_quit_hover = (self._hover_hit == _HIT_QUIT)

        if is_quit_hover:
            p.fillRect(quit_r, QColor("#1c1c24"))

        b_icon_y = quit_r.y() + (quit_r.height() - _BOTTOM_ICON_SIZE) // 2
        quit_color = QColor("#f87171") if is_quit_hover else QColor("#606060")
        self._draw_quit_icon(p, b_icon_x, b_icon_y, _BOTTOM_ICON_SIZE, quit_color)

        p.setPen(quit_color)
        p.drawText(b_text_x, quit_r.y(), quit_r.width() - b_text_x - 8, quit_r.height(),
                    Qt.AlignmentFlag.AlignVCenter, "Beenden")

        # Version (klickbar → Update-Check)
        from paypertranscript import __version__

        is_update_hover = (self._hover_hit == _HIT_UPDATE)
        p.setFont(QFont("Segoe UI", 8))

        if is_update_hover:
            p.setPen(QColor("#888888"))
            p.drawText(self._update_rect(), Qt.AlignmentFlag.AlignCenter,
                        f"v{__version__}  \u00b7  Updates pr\u00fcfen")
        else:
            p.setPen(QColor("#484848"))
            p.drawText(self._update_rect(), Qt.AlignmentFlag.AlignCenter, f"v{__version__}")

        p.end()

    # -- Icon-Zeichenmethoden --

    def _draw_nav_icon(self, p: QPainter, index: int, x: int, y: int, size: int, color: QColor) -> None:
        """Zeichnet ein geometrisches Icon fuer den Navigationseintrag."""
        p.setPen(QPen(color, 1.5))
        p.setBrush(Qt.BrushStyle.NoBrush)

        if index == 0:  # Home - Haus
            cx = x + size // 2
            p.drawLine(x + 1, y + size // 2, cx, y + 1)
            p.drawLine(cx, y + 1, x + size - 1, y + size // 2)
            p.drawLine(x + 3, y + size // 2, x + 3, y + size - 1)
            p.drawLine(x + size - 3, y + size // 2, x + size - 3, y + size - 1)
            p.drawLine(x + 3, y + size - 1, x + size - 3, y + size - 1)

        elif index == 1:  # Statistiken - Balkendiagramm
            bar_w = 3
            p.setBrush(color)
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRect(x + 1, y + size - 7, bar_w, 7)
            p.drawRect(x + 6, y + size - 12, bar_w, 12)
            p.drawRect(x + 11, y + size - 9, bar_w, 9)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(color, 1.5))

        elif index == 2:  # Einstellungen - Zahnrad
            cx = x + size // 2
            cy = y + size // 2
            r_outer = size // 2 - 1
            r_inner = size // 4
            p.drawEllipse(QPoint(cx, cy), r_inner, r_inner)
            for angle in [0, 90, 45, 135]:
                rad = math.radians(angle)
                x1 = int(cx + r_inner * math.cos(rad))
                y1 = int(cy - r_inner * math.sin(rad))
                x2 = int(cx + r_outer * math.cos(rad))
                y2 = int(cy - r_outer * math.sin(rad))
                p.drawLine(x1, y1, x2, y2)
                x1 = int(cx - r_inner * math.cos(rad))
                y1 = int(cy + r_inner * math.sin(rad))
                x2 = int(cx - r_outer * math.cos(rad))
                y2 = int(cy + r_outer * math.sin(rad))
                p.drawLine(x1, y1, x2, y2)

        elif index == 3:  # Wortliste - Liste
            line_y = y + 2
            for _ in range(4):
                p.setBrush(color)
                p.setPen(Qt.PenStyle.NoPen)
                p.drawEllipse(x + 1, line_y, 3, 3)
                p.setPen(QPen(color, 1.5))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawLine(x + 6, line_y + 1, x + size - 1, line_y + 1)
                line_y += 4

        elif index == 4:  # Fenster - Gitter/Fenster
            p.drawRect(x + 1, y + 1, size - 2, size - 2)
            cx = x + size // 2
            cy = y + size // 2
            p.drawLine(cx, y + 1, cx, y + size - 1)
            p.drawLine(x + 1, cy, x + size - 1, cy)

    def _draw_restart_icon(self, p: QPainter, x: int, y: int, size: int, color: QColor) -> None:
        """Kreispfeil-Icon fuer Neustart."""
        p.setPen(QPen(color, 1.4))
        p.setBrush(Qt.BrushStyle.NoBrush)

        # 280-Grad-Bogen (Luecke oben)
        arc_rect = QRect(x + 1, y + 1, size - 2, size - 2)
        p.drawArc(arc_rect, 120 * 16, 280 * 16)

        # Pfeilspitze am Bogen-Start (bei ~120° = oben-links)
        cx = x + size / 2
        cy = y + size / 2
        radius = (size - 2) / 2
        ax = cx + radius * math.cos(math.radians(120))
        ay = cy - radius * math.sin(math.radians(120))
        p.drawLine(int(ax), int(ay), int(ax + 4), int(ay - 1))
        p.drawLine(int(ax), int(ay), int(ax + 1), int(ay + 4))

    def _draw_quit_icon(self, p: QPainter, x: int, y: int, size: int, color: QColor) -> None:
        """Power-Icon fuer Beenden."""
        p.setPen(QPen(color, 1.4))
        p.setBrush(Qt.BrushStyle.NoBrush)

        # Offener Kreis (Luecke oben, ~300 Grad)
        arc_rect = QRect(x + 2, y + 2, size - 4, size - 4)
        p.drawArc(arc_rect, 120 * 16, 300 * 16)

        # Vertikaler Strich von Mitte nach oben
        cx = x + size // 2
        p.drawLine(cx, y + 1, cx, y + size // 2 + 1)

    def sizeHint(self) -> QSize:
        return QSize(180, 560)
