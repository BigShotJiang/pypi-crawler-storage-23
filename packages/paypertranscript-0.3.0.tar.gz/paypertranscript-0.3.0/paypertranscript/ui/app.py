"""PySide6 Application Lifecycle für PayPerTranscript.

Zentrale App-Klasse: Single-Instance, Service-Init, Signal-Bridge, System Tray.
"""

import os
import sys

from PySide6.QtCore import QEvent, QObject, QSharedMemory, Qt, QTimer, Signal
from PySide6.QtGui import QCursor, QIcon
from PySide6.QtWidgets import (
    QAbstractButton,
    QAbstractSpinBox,
    QApplication,
    QComboBox,
    QDialog,
    QMessageBox,
    QTabBar,
)

from paypertranscript.core.audio_manager import AudioManager
from paypertranscript.core.config import ConfigManager, load_api_key
from paypertranscript.core.hotkey import HotkeyListener
from paypertranscript.core.logging import get_logger
from paypertranscript.core.paths import get_assets_dir, get_icons_dir, get_styles_dir
from paypertranscript.core.recorder import AudioRecorder
from paypertranscript.core.session_logger import SessionLogger
from paypertranscript.core.window_detector import WindowInfo, get_foreground_window
from paypertranscript.pipeline.transcription import (
    STATUS_DONE,
    STATUS_ERROR,
    STATUS_LLM_FALLBACK,
    STATUS_LLM_START,
    STATUS_STT_START,
    TranscriptionPipeline,
)
from paypertranscript.providers import ProviderError, create_llm_provider, create_stt_provider
from paypertranscript.ui.overlay import StatusOverlay
from paypertranscript.ui.tray import SystemTray

log = get_logger("ui.app")

# Klickbare Widget-Typen, die einen Pointer-Cursor bekommen sollen
_CLICKABLE_TYPES = (QAbstractButton, QComboBox, QTabBar, QAbstractSpinBox)


class _GlobalEventFilter(QObject):
    """Event-Filter: Pointer-Cursor auf klickbare Widgets, Scroll auf ComboBoxen blockieren."""

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if event.type() == QEvent.Type.ChildAdded:
            child = event.child()
            if isinstance(child, _CLICKABLE_TYPES):
                child.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        elif event.type() == QEvent.Type.Wheel and isinstance(obj, QComboBox):
            if obj.parent():
                QApplication.sendEvent(obj.parent(), event)
            return True
        return False


# Minimale Aufnahmedauer in Sekunden (kürzere Aufnahmen werden verworfen)
MIN_RECORDING_DURATION = 0.3
# Schwellwert für Warnung bei langer Aufnahme (Sekunden)
MAX_RECORDING_WARN = 600  # 10 Minuten

# Pfad zum Stylesheet (frozen-aware)
_STYLES_DIR = get_styles_dir()


class AppSignals(QObject):
    """Thread-sichere Qt-Signals für Cross-Thread-Kommunikation."""

    recording_started = Signal()
    recording_stopped = Signal()
    processing_started = Signal()
    formatting_started = Signal()
    processing_done = Signal()
    processing_error = Signal(str)
    done_message = Signal(str)
    update_available = Signal(str)
    update_not_available = Signal()


class PayPerTranscriptApp:
    """Zentrale App-Klasse - verwaltet QApplication, Services und UI."""

    def __init__(self) -> None:
        # QApplication muss ZUERST erstellt werden (vor jedem QWidget/QIcon)
        self._qt_app = QApplication(sys.argv)
        self._qt_app.setApplicationName("PayPerTranscript")
        self._qt_app.setQuitOnLastWindowClosed(False)

        # App-Icon setzen (fuer alle Dialoge)
        icon_path = get_icons_dir() / "app.ico"
        if icon_path.exists():
            self._qt_app.setWindowIcon(QIcon(str(icon_path)))

        # Single-Instance-Check
        self._shared_mem = QSharedMemory("PayPerTranscript-SingleInstance")
        if not self._shared_mem.create(1):
            QMessageBox.warning(
                None,
                "PayPerTranscript",
                "PayPerTranscript läuft bereits.\n\n"
                "Schaue im System Tray (rechts unten in der Taskleiste) nach dem Icon.",
            )
            sys.exit(0)

        # Dark Theme laden
        self._load_stylesheet()

        # Globaler Event-Filter: Pointer-Cursor + Scroll-Schutz fuer ComboBoxen
        self._global_filter = _GlobalEventFilter()
        self._qt_app.installEventFilter(self._global_filter)

        # Signal-Bridge
        self._signals = AppSignals()

        # Config laden
        self._config = ConfigManager()

        # Setup-Wizard bei erstem Start
        if self._config.is_first_run():
            from paypertranscript.ui.setup_wizard import SetupWizard

            log.info("Erster Start erkannt - Setup-Wizard wird angezeigt")
            wizard = SetupWizard(self._config)
            if wizard.exec() != QDialog.DialogCode.Accepted:
                log.info("Setup-Wizard abgebrochen - App wird beendet")
                sys.exit(0)
            self._config.reload()

        # Services initialisieren
        self._init_services()

        # Status-Overlay
        self._overlay = StatusOverlay(self._config)

        # System Tray
        self._tray = SystemTray(
            self._config,
            hotkey_listener=self._hotkey_listener,
            session_logger=self._session_logger,
            get_last_transcription=self._get_last_transcription,
            show_done_overlay=self._overlay.show_done,
            on_update_check=self.trigger_update_check,
            on_perform_update=self.perform_update_and_restart,
            get_last_wav_path=self._get_last_wav_path,
            on_retranscribe_precise=self._retranscribe_precise,
        )

        # Amplitude-Polling-Timer (30fps, laeuft nur waehrend Aufnahme)
        self._amplitude_timer = QTimer()
        self._amplitude_timer.setInterval(33)
        self._amplitude_timer.timeout.connect(self._poll_amplitude)

        self._connect_signals()
        self._tray.show()

        # V04: LLM-Initialisierungs-Warnung als Overlay anzeigen (nach Tray-Erstellung)
        if self._llm_init_warning:
            self._overlay.show_error("LLM deaktiviert")

        # Periodischer Update-Check
        self._update_timer = QTimer()
        check_hours = self._config.get("updates.check_interval_hours", 24)
        self._update_timer.setInterval(check_hours * 3600 * 1000)
        self._update_timer.timeout.connect(self._check_for_update_background)
        if self._config.get("updates.auto_update", True):
            self._update_timer.start()

        # Cleanup bei App-Ende
        self._qt_app.aboutToQuit.connect(self._shutdown)

        log.info("PayPerTranscriptApp initialisiert")

    def _load_stylesheet(self) -> None:
        """Lädt das Dark Theme QSS Stylesheet."""
        qss_file = _STYLES_DIR / "dark.qss"
        if qss_file.exists():
            try:
                stylesheet = qss_file.read_text(encoding="utf-8")
                assets_dir = get_assets_dir().as_posix()
                stylesheet = stylesheet.replace("{{ASSETS_DIR}}", assets_dir)
                self._qt_app.setStyleSheet(stylesheet)
                log.debug("Stylesheet geladen: %s", qss_file)
            except OSError as e:
                log.warning("Stylesheet konnte nicht geladen werden: %s", e)
        else:
            log.warning("Stylesheet nicht gefunden: %s", qss_file)

    def _init_services(self) -> None:
        """Initialisiert alle Core-Services."""
        config = self._config
        log.info("Config geladen: %s", config.get("api.provider"))
        log.info(
            "Sprache: %s, STT-Modell: %s, LLM-Modell: %s",
            config.get("general.language"),
            config.get("api.stt_model"),
            config.get("api.llm_model"),
        )

        # API-Key: Keyring → Env-Var → Groq-SDK Default
        api_key = load_api_key() or os.environ.get("GROQ_API_KEY")

        # Audio-Manager: Sounds vorladen, alte Dateien bereinigen
        self._audio_manager = AudioManager()
        self._audio_manager.preload_sounds()
        retention_hours = config.get("data.audio_retention_hours", 24)
        self._audio_manager.cleanup_old_files(retention_hours)

        # Audio-Recorder: Persistenten Stream starten
        self._recorder = AudioRecorder()
        try:
            self._recorder.start_stream()
        except Exception:
            log.error("Mikrofon konnte nicht initialisiert werden - App wird beendet")
            QMessageBox.critical(
                None,
                "PayPerTranscript - Fehler",
                "Mikrofon konnte nicht initialisiert werden.\n\n"
                "Bitte prüfe, ob ein Mikrofon angeschlossen und aktiviert ist.",
            )
            sys.exit(1)

        # STT-Provider erstellen
        try:
            self._stt_provider = create_stt_provider(
                config.get("api.provider", "groq"),
                model=config.get("api.stt_model", "whisper-large-v3-turbo"),
                api_key=api_key,
            )
        except ProviderError as e:
            log.error("STT-Provider konnte nicht erstellt werden: %s", e)
            QMessageBox.critical(
                None,
                "PayPerTranscript - Fehler",
                f"STT-Provider konnte nicht erstellt werden:\n{e}\n\n"
                "Ist der API-Key korrekt? (Keyring oder GROQ_API_KEY Env-Var)",
            )
            self._recorder.stop_stream()
            sys.exit(1)

        # LLM-Provider erstellen (optional)
        self._llm_provider = None
        self._llm_init_warning: str | None = None
        try:
            self._llm_provider = create_llm_provider(
                config.get("api.provider", "groq"),
                model=config.get("api.llm_model", "openai/gpt-oss-20b"),
                api_key=api_key,
                temperature=config.get("api.llm_temperature"),
            )
        except ProviderError as e:
            log.warning(
                "LLM-Provider konnte nicht erstellt werden: %s - LLM-Formatierung deaktiviert", e
            )
            self._llm_init_warning = (
                "LLM-Formatierung deaktiviert — Rohtext wird eingefügt.\n"
                f"Grund: {e}"
            )

        # Session-Logger
        self._session_logger = SessionLogger()

        # Transkriptions-Pipeline
        self._pipeline = TranscriptionPipeline(
            stt_provider=self._stt_provider,
            config=config,
            llm_provider=self._llm_provider,
            session_logger=self._session_logger,
        )

        # Hotkey-Callbacks und Listener
        self._current_window: WindowInfo | None = None

        hold_hotkey = config.get("general.hold_hotkey")
        toggle_hotkey = config.get("general.toggle_hotkey")

        self._hotkey_listener = HotkeyListener(
            hold_hotkey=hold_hotkey,
            toggle_hotkey=toggle_hotkey,
            on_hold_start=self._on_hold_start,
            on_hold_stop=self._on_hold_stop,
            on_toggle=self._on_toggle,
        )
        self._hotkey_listener.start()

        hold_str = " + ".join(hold_hotkey) if hold_hotkey else "(nicht konfiguriert)"
        toggle_str = " + ".join(toggle_hotkey) if toggle_hotkey else "(nicht konfiguriert)"
        log.info("Hotkeys bereit - Hold: %s, Toggle: %s", hold_str, toggle_str)

    def _get_last_transcription(self) -> str | None:
        """Gibt die letzte Transkription aus der Pipeline zurueck."""
        return self._pipeline.last_transcription

    def _get_last_wav_path(self):
        """Gibt den Pfad der letzten WAV-Datei zurueck (oder None)."""
        path = self._pipeline.last_wav_path
        if path and path.exists():
            return path
        return None

    def _retranscribe_precise(self) -> None:
        """Transkribiert die letzte Aufnahme erneut mit whisper-large-v3."""
        import threading

        wav_path = self._get_last_wav_path()
        if not wav_path:
            self._signals.processing_error.emit("Keine Aufnahme")
            return

        def _worker():
            try:
                self._signals.recording_stopped.emit()  # Overlay: "Transkribiere..."

                api_key = load_api_key() or os.environ.get("GROQ_API_KEY")
                stt = create_stt_provider(
                    self._config.get("api.provider", "groq"),
                    model="whisper-large-v3",
                    api_key=api_key,
                )

                language = self._config.get("general.language", "de")
                words = self._config.get("words.misspelled_words", [])
                from paypertranscript.pipeline.transcription import _build_word_list_prompt
                prompt = _build_word_list_prompt(words)

                text = stt.transcribe(wav_path, language=language, prompt=prompt)
                if not text:
                    self._signals.processing_error.emit("Kein Text erkannt")
                    return

                import pyperclip
                pyperclip.copy(text)
                self._pipeline.last_transcription = text

                self._signals.processing_done.emit()
                self._signals.done_message.emit("Kopiert")
            except ProviderError as e:
                log.error("Re-Transkription fehlgeschlagen: %s", e)
                self._signals.processing_error.emit(f"Re-Transkription fehlgeschlagen: {e}")
            except Exception as e:
                log.error("Re-Transkription: Unerwarteter Fehler: %s", e, exc_info=True)
                self._signals.processing_error.emit("Re-Transkription fehlgeschlagen")

        threading.Thread(target=_worker, daemon=True, name="retranscribe-precise").start()

    def _connect_signals(self) -> None:
        """Verbindet AppSignals mit Tray- und Overlay-Slots."""
        # Tray
        self._signals.recording_started.connect(self._tray.on_recording_started)
        self._signals.recording_stopped.connect(self._tray.on_recording_stopped)
        self._signals.processing_started.connect(self._tray.on_processing_started)
        self._signals.processing_done.connect(self._tray.on_processing_done)
        self._signals.processing_error.connect(self._tray.on_processing_error)

        # Overlay
        self._signals.recording_started.connect(self._overlay.show_recording)
        self._signals.recording_started.connect(self._amplitude_timer.start)
        self._signals.recording_stopped.connect(self._overlay.show_transcribing)
        self._signals.recording_stopped.connect(self._amplitude_timer.stop)
        self._signals.formatting_started.connect(self._overlay.show_formatting)
        self._signals.processing_done.connect(self._overlay.show_done)
        self._signals.processing_error.connect(self._overlay.show_error)

        # Done mit Text (z.B. "Kopiert")
        self._signals.done_message.connect(self._overlay.show_done_message)

        # Update
        self._signals.update_available.connect(self._tray.on_update_available)
        self._signals.update_not_available.connect(self._tray.on_update_not_available)

    # -- Hotkey-Callbacks (laufen in daemon-Threads) --

    def _on_hold_start(self) -> None:
        """Hold-Hotkey gedrückt - Aufnahme starten."""
        if self._recorder.is_recording:
            return
        # Foreground-Window erfassen BEVOR die Aufnahme startet
        self._current_window = get_foreground_window()
        log.info(
            "Foreground-Window: %s - '%s'",
            self._current_window.process_name or "(unbekannt)",
            self._current_window.window_title or "(kein Titel)",
        )
        if self._config.get("general.sound_enabled"):
            self._audio_manager.play_sound("start")
        self._recorder.start_recording()
        self._signals.recording_started.emit()

    def _on_hold_stop(self) -> None:
        """Hold-Hotkey losgelassen - Aufnahme stoppen und verarbeiten."""
        if not self._recorder.is_recording:
            return
        audio = self._recorder.stop_recording()

        if self._config.get("general.sound_enabled"):
            self._audio_manager.play_sound("stop")

        self._signals.recording_stopped.emit()

        if audio is None:
            self._signals.processing_error.emit("Keine Aufnahme")
            return

        actual_duration = len(audio) / 16000
        if actual_duration < MIN_RECORDING_DURATION:
            log.info(
                "Aufnahme zu kurz (%.2fs < %.1fs) - verworfen",
                actual_duration,
                MIN_RECORDING_DURATION,
            )
            self._current_window = None
            self._signals.processing_error.emit("Aufnahme zu kurz")
            return

        # WAV speichern
        wav_path = self._audio_manager.generate_temp_path()
        self._recorder.save_wav(audio, wav_path)
        window = self._current_window
        self._current_window = None
        log.info(
            "Aufnahme bereit für Transkription: %s (Fenster: %s)",
            wav_path.name,
            window.process_name if window else "(unbekannt)",
        )

        # Warnung bei sehr langer Aufnahme
        if actual_duration > MAX_RECORDING_WARN:
            log.warning(
                "Aufnahme sehr lang (%.0fs) - wird trotzdem gesendet",
                actual_duration,
            )

        # Pipeline in Hintergrund-Thread starten (non-blocking)
        self._pipeline.process_async(
            wav_path, window,
            on_status=self._on_pipeline_status,
            audio_duration=actual_duration,
        )

    def _on_toggle(self) -> None:
        """Toggle-Hotkey - Aufnahme starten oder stoppen."""
        if self._recorder.is_recording:
            self._on_hold_stop()
        else:
            self._on_hold_start()

    def _on_pipeline_status(self, status: str, detail: str = "") -> None:
        """Callback von der Pipeline - leitet Status an Qt-Signals weiter."""
        if status == STATUS_STT_START:
            self._signals.processing_started.emit()
        elif status == STATUS_LLM_START:
            self._signals.formatting_started.emit()
        elif status == STATUS_DONE:
            self._signals.processing_done.emit()
        elif status == STATUS_LLM_FALLBACK:
            log.info("LLM-Fallback auf Rohtext: %s", detail)
        elif status == STATUS_ERROR:
            self._signals.processing_error.emit(detail or "Transkription fehlgeschlagen")

    def _poll_amplitude(self) -> None:
        """Pollt die Mikrofon-Amplitude und gibt sie an das Overlay weiter."""
        if self._recorder.is_recording:
            self._overlay.set_amplitude(self._recorder.amplitude)

    # -- Update --

    def _check_for_update_background(self) -> None:
        """Prueft im Hintergrund-Thread auf Updates."""
        import threading

        threading.Thread(target=self._do_update_check, daemon=True).start()

    def _do_update_check(self) -> None:
        """Update-Check (laeuft in daemon-Thread)."""
        from paypertranscript import __version__
        from paypertranscript.core.updater import get_latest_version, is_update_available

        latest = get_latest_version()
        if latest and is_update_available(__version__, latest):
            self._signals.update_available.emit(latest)
        else:
            self._signals.update_not_available.emit()

    def trigger_update_check(self) -> None:
        """Oeffentliche Methode fuer manuellen Check (von Tray aufgerufen)."""
        self._check_for_update_background()

    def perform_update_and_restart(self) -> None:
        """Installiert Update und startet App neu."""
        from paypertranscript.core.updater import install_update, restart_app

        if install_update():
            restart_app()

    # -- Lifecycle --

    def _shutdown(self) -> None:
        """Fährt alle Services sauber herunter."""
        log.info("PayPerTranscript wird beendet...")
        self._update_timer.stop()
        self._amplitude_timer.stop()
        self._overlay.dismiss()
        self._tray.hide()
        self._hotkey_listener.stop()
        self._recorder.stop_stream()
        log.info("PayPerTranscript beendet.")

    def run(self) -> int:
        """Startet die App (blockiert bis Beenden)."""
        log.info("PayPerTranscript UI gestartet")
        return self._qt_app.exec()
