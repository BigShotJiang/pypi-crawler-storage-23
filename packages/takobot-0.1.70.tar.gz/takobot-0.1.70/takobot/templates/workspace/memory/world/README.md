# memory/world/

Deterministic world-watch research artifacts.

- Daily notes: `YYYY-MM-DD.md`
- World model: `model.md`
- Entity/source index: `entities.md`
- Assumptions ledger: `assumptions.md`
