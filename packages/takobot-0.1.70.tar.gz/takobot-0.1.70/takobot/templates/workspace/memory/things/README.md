# things/ — Thing Notes

This directory stores markdown notes about systems, tools, objects, and concepts Tako interacts with.

Guidelines:

- One file per thing (tool/system/concept).
- Note assumptions and known limits clearly.
- No secrets.

