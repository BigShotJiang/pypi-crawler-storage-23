from dbt.tests.adapter.utils.test_null_compare import BaseMixedNullCompare, BaseNullCompare


class TestMixedNullCompareFabric(BaseMixedNullCompare):
    pass


class TestNullCompareFabric(BaseNullCompare):
    pass
