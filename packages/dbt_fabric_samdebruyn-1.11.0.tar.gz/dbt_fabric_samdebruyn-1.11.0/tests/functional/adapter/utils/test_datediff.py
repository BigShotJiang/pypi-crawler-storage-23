from dbt.tests.adapter.utils.test_datediff import BaseDateDiff


class TestDateDiffFabric(BaseDateDiff):
    pass
