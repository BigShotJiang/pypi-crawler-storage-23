from dbt.tests.adapter.utils.test_escape_single_quotes import (
    BaseEscapeSingleQuotesQuote,
)


class TestEscapeSingleQuotesQuoteFabric(BaseEscapeSingleQuotesQuote):
    pass
