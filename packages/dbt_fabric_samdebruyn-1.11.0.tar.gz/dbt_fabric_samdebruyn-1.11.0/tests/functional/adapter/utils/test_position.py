from dbt.tests.adapter.utils.test_position import BasePosition


class TestPositionFabric(BasePosition):
    pass
