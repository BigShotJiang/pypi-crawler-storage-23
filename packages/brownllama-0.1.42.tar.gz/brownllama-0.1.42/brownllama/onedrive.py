"""
Microsoft OneDrive Uploader.

This class uploads the files to Onedrive.
"""

import msal
import requests


class OneDriveUploader:
    """
    Upload CSV files to Microsoft OneDrive via the Microsoft Graph API.

    This class handles authentication using MSAL client credentials flow
    and provides methods to upload files of any size to OneDrive.

    Attributes:
        GRAPH_BASE: Base URL for the Microsoft Graph API.
        CHUNK_SIZE: Size of each chunk in bytes for chunked uploads (10 MB).
        client_id: The Azure AD application (client) ID.
        client_secret: The Azure AD application client secret.
        tenant_id: The Azure AD tenant ID.
        access_token: The OAuth2 access token obtained after authentication.

    """

    GRAPH_BASE: str = "https://graph.microsoft.com/v1.0"
    CHUNK_SIZE: int = 10 * 1024 * 1024  # 10 MB

    def __init__(self, client_id: str, client_secret: str, tenant_id: str) -> None:
        """
        Initialize the OneDriveUploader with Azure AD credentials.

        Args:
            client_id: The Azure AD application (client) ID.
            client_secret: The Azure AD application client secret.
            tenant_id: The Azure AD tenant ID.

        """
        self.client_id = client_id
        self.client_secret = client_secret
        self.tenant_id = tenant_id
        self.access_token: str | None = None

    @property
    def _headers(self) -> dict[str, str]:
        """
        Build the default authorization headers for Graph API requests.

        Returns:
            A dictionary containing the Authorization header with the bearer token.

        Raises:
            Exception: If the client has not been authenticated yet.

        """
        if not self.access_token:
            error_msg = "Not authenticated. Call authenticate() first."
            raise Exception(error_msg)
        return {"Authorization": f"Bearer {self.access_token}"}

    def _chunked_upload(self, content: bytes, remote_path: str) -> dict:
        """
        Upload a large file (>= 4 MB) using a resumable upload session.

        Creates an upload session and sends the file in chunks of
        ``CHUNK_SIZE`` bytes each.

        Args:
            content: The raw bytes of the file to upload.
            remote_path: Destination path in OneDrive.

        Returns:
            The Microsoft Graph API response from the final chunk as a dictionary.

        Raises:
            requests.HTTPError: If any chunk upload or session creation fails.

        """
        url = f"{self.GRAPH_BASE}/me/drive/root:{remote_path}:/createUploadSession"
        session = requests.post(url, headers=self._headers, timeout=600)
        session.raise_for_status()
        upload_url = session.json()["uploadUrl"]

        file_size = len(content)
        resp = None
        for i in range(0, file_size, self.CHUNK_SIZE):
            chunk = content[i : i + self.CHUNK_SIZE]
            content_range = f"bytes {i}-{i + len(chunk) - 1}/{file_size}"
            resp = requests.put(
                upload_url,
                headers={"Content-Range": content_range},
                data=chunk,
                timeout=600,
            )
            resp.raise_for_status()
        if resp is None:
            error_msg = "No chucks were uploaded, content may be empty."
            raise ValueError(error_msg)
        return resp.json()

    def _simple_upload(self, content: bytes, remote_path: str) -> dict:
        """
        Upload a small file (< 4 MB) in a single PUT request.

        Args:
            content: The raw bytes of the file to upload.
            remote_path: Destination path in OneDrive.

        Returns:
            The Microsoft Graph API response as a dictionary.

        Raises:
            requests.HTTPError: If the Graph API returns an error response.

        """
        url = f"{self.GRAPH_BASE}/me/drive/root:{remote_path}:/content"
        resp = requests.put(
            url,
            headers={**self._headers, "Content-Type": "application/octet-stream"},
            data=content,
            timeout=600,
        )
        resp.raise_for_status()
        return resp.json()

    def upload(self, local_path: str, remote_path: str) -> dict:
        """
        Upload a file to OneDrive, choosing the appropriate upload strategy.

        Files smaller than 4 MB are uploaded in a single request. Larger files
        are uploaded using a chunked upload session.

        Args:
            local_path: Path to the local file to upload.
            remote_path: Destination path in OneDrive, e.g. ``/Documents/data.csv``.

        Returns:
            The Microsoft Graph API response as a dictionary containing file
            metadata such as ``id``, ``name``, and ``webUrl``.

        Raises:
            FileNotFoundError: If the local file does not exist.
            requests.HTTPError: If the Graph API returns an error response.

        """
        with open(local_path, "rb") as f:
            content = f.read()

        if len(content) < 4 * 1024 * 1024:
            return self._simple_upload(content, remote_path)

        return self._chunked_upload(content, remote_path)

    def authenticate(self) -> None:
        """
        Acquire an access token using the MSAL client credentials flow.

        Raises:
            Exception: If token acquisition fails due to invalid credentials
                or network issues.

        """
        app = msal.ConfidentialClientApplication(
            self.client_id,
            authority=f"https://login.microsoftonline.com/{self.tenant_id}",
            client_credential=self.client_secret,
        )
        response = app.acquire_token_for_client(
            scopes=["https://graph.microsoft.com/.default"]
        )
        if "access_token" not in response:
            error_msg = f"Authentication failed: {response.get('error_description')}"
            raise Exception(error_msg)

        self.access_token = response["access_token"]


# === Usage ===
if __name__ == "__main__":
    uploader = OneDriveUploader(
        client_id="your-client-id",
        client_secret="your-client-secret",
        tenant_id="your-tenant-id",
    )
    uploader.authenticate()

    result = uploader.upload("data.csv", "/Documents/data.csv")
    print("Uploaded:", result.get("webUrl"))
