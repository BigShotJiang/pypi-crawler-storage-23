# SPDX-FileCopyrightText: 2024 Justin Simon <justin@simonctl.com>
#
# SPDX-License-Identifier: MIT

from scapy.packet import Packet

from .. import EndpointContext, TransportHdrPacket
from ..types import AnyPacketType
from .control import AutobindControlMsg, ControlHdr, ControlHdrPacket
from .types import CompletionCode, CompletionCodes, ContrlCmdCodes


@AutobindControlMsg(ContrlCmdCodes.DiscoveryNotify, is_request=True)
class DiscoveryNotifyRequestPacket(Packet):
    name = "DiscoveryNotify"
    fields_desc = []

    def mysummary(self) -> str | tuple[str, list[AnyPacketType]]:
        return f"{self.name} ()", [ControlHdrPacket, TransportHdrPacket]

    def make_ctrl_reply(self, ctx: EndpointContext) -> tuple[CompletionCode, AnyPacketType]:
        return CompletionCodes.SUCCESS, DiscoveryNotifyResponse()


@AutobindControlMsg(ContrlCmdCodes.DiscoveryNotify, is_request=False)
class DiscoveryNotifyResponsePacket(Packet):
    name = "DiscoveryNotify"
    fields_desc = []

    def mysummary(self) -> str | tuple[str, list[AnyPacketType]]:
        return f"{self.name} ()", [ControlHdrPacket, TransportHdrPacket]


# Keep backward compatibility alias
DiscoveryNotifyPacket = DiscoveryNotifyRequestPacket


def DiscoveryNotify(*args, **kwargs):
    hdr = ControlHdr(rq=True, cmd_code=ContrlCmdCodes.DiscoveryNotify)
    if len(args):
        return DiscoveryNotifyRequestPacket(*args, _underlayer=hdr)
    return DiscoveryNotifyRequestPacket(
        _underlayer=hdr,
    )


def DiscoveryNotifyResponse(*args, **kwargs):
    hdr = ControlHdr(rq=False, cmd_code=ContrlCmdCodes.DiscoveryNotify)
    if len(args) or len(kwargs):
        return DiscoveryNotifyResponsePacket(*args, _underlayer=hdr, **kwargs)
    return DiscoveryNotifyResponsePacket(
        _underlayer=hdr,
    )
