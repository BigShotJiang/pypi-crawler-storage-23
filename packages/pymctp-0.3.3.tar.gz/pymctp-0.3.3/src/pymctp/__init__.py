# SPDX-FileCopyrightText: 2024 Justin Simon <justin@simonctl.com>
#
# SPDX-License-Identifier: MIT

# Import oem namespace to make it available at pymctp.oem
from . import oem  # noqa: F401
