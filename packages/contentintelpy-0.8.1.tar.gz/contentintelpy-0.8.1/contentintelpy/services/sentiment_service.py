import torch
import logging
from typing import Dict, Any, List, Optional
from .base_service import BaseService
from ..utils.model_registry import registry
from ..utils.service_logging import ServiceLogger

logger = logging.getLogger(__name__)

class SentimentService(BaseService):
    """
    Expert-level Service for Sentiment Analysis (Service I).
    Features: CardiffNLP RoBERTa Primary, TextBlob Fallback, Sentiment Gate, Bilingual Output.
    """
    
    def __init__(self):
        super().__init__()
        self.device = "cuda" if torch.cuda.is_available() else "cpu"

    def analyze_with_v2_local(self, text: str) -> Optional[Dict]:
        """TIER 1: RoBERTa GPU Inference"""
        try:
            bundle = registry.get_sentiment_model()
            model = bundle["model"]; tokenizer = bundle["tokenizer"]; device = bundle["device"]
            inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=512).to(device)
            with torch.no_grad():
                outputs = model(**inputs)
                probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
            idx = torch.argmax(probs, dim=1).item()
            sentiment_map = {0: "negative", 1: "neutral", 2: "positive"}
            return {"value": sentiment_map.get(idx, "neutral"), "confidence": round(probs[0][idx].item(), 4), "role": "primary"}
        except Exception: return None

    def __call__(self, text: str, language: Optional[str] = None, text_translated: Optional[str] = None, visual: bool = True) -> Dict[str, Any]:
        """Allows the service to be called directly like a function."""
        return self.analyze(text, language, text_translated, visual=visual)

    def analyze(self, text: str, 
                language: Optional[str] = None, 
                text_translated: Optional[str] = None,
                visual: bool = True) -> Dict[str, Any]:
        """Unified Sentiment Analysis API (Fig 4 in Paper)"""
        log = ServiceLogger() if visual else None
        if log: log.header("Sentiment Analysis Service")

        # 1. Expert Intelligence: Multilingual Bridge
        content = self.ensure_english_content(text, language, text_translated, visual=visual, log=log)
        text_en = content["text"]
        source_lang = content["language"]

        # 2. Primary Engine
        if log: log.log("Primary Engine", "CardiffNLP RoBERTa (Sentiment-Seq)")
        result = self.analyze_with_v2_local(text_en)
        status = "READY_FOR_LOCAL_GPU"
        
        # 3. Fallback Engine
        if result is None:
            if log: log.log("Primary Engine", "FAILED - Switching to TextBlob Fallback")
            from textblob import TextBlob
            polarity = TextBlob(text_en).sentiment.polarity
            label = "positive" if polarity > 0.1 else "negative" if polarity < -0.1 else "neutral"
            result = {"value": label, "confidence": 0.6, "role": "fallback"}
            status = "FALLBACK_TO_TEXTBLOB"

        if log:
            log.log("Tone Analysis", "Separating Factual vs Emotional")
            log.item("detected_tone", result["value"])
            log.item("confidence", f"{result['confidence']:.2f}")

        # 4. Bilingual Mirroring (Paper §3.3.4)
        label_en = result["value"]
        label_source = label_en
        if source_lang != "en" and source_lang != "unknown":
            if log: log.log("Mirroring", f"Translating sentiment label to {source_lang}")
            from .translation_service import TranslationService
            ts = TranslationService()
            label_source = ts.translate(label_en, target=source_lang, source="en")

        # 5. Sentiment Gate
        if log:
            log.header("Sentiment Gate")
            log.eval("Confidence Pass", "SUPPORTED")
            log.success("Sentiment Analysis Service")

        return {
            "en": label_en,
            "source": label_source,
            "label": label_en, # Legacy
            "score": result["confidence"],
            "role": result["role"],
            "status": status
        }
