import logging
from typing import Dict, Any, List, Optional
from .base_service import BaseService
from ..utils.model_registry import registry
from ..utils.service_logging import ServiceLogger

logger = logging.getLogger(__name__)

class CategoryClassificationService(BaseService):
    """
    Expert-level Service for Zero-Shot Classification (Service F).
    Features: BART-Large-MNLI, Multi-label (Top 3), Verification Gate, Bilingual Output.
    """
    DEFAULT_LABELS = ["Politics", "Technology", "Sports", "Business", "Entertainment", "Health"]

    # Keyword heuristic map — used when BART-MNLI fails (paper §3.1.F)
    KEYWORD_MAP = {
        "Politics":      ["government", "election", "parliament", "minister", "president", "policy", "senate", "vote", "law", "political"],
        "Technology":    ["software", "hardware", "ai", "algorithm", "digital", "internet", "cyber", "robot", "tech", "startup", "app", "data"],
        "Sports":        ["football", "cricket", "tennis", "match", "player", "team", "tournament", "score", "olympic", "athlete", "league"],
        "Business":      ["market", "stock", "economy", "trade", "company", "profit", "revenue", "investment", "gdp", "startup", "finance"],
        "Entertainment": ["movie", "music", "celebrity", "film", "award", "actor", "actress", "concert", "streaming", "series", "album"],
        "Health":        ["hospital", "medicine", "disease", "vaccine", "doctor", "patient", "health", "drug", "virus", "treatment", "mental"],
    }

    def __init__(self, candidate_labels: List[str] = None):
        super().__init__()
        self.candidate_labels = candidate_labels or self.DEFAULT_LABELS

    def _keyword_heuristic(self, text: str) -> Dict[str, Any]:
        """Fallback: keyword-based heuristic mapping (paper §3.1.F)"""
        text_lower = text.lower()
        scores = {}
        for label, keywords in self.KEYWORD_MAP.items():
            if label in self.candidate_labels:
                scores[label] = sum(1 for kw in keywords if kw in text_lower)
        
        if not scores or max(scores.values()) == 0:
            top = self.candidate_labels[0]
            return {"category": top, "score": 0.1, "all_categories": {top: 0.1}, "role": "fallback"}

        top_label = max(scores, key=scores.get)
        total = sum(scores.values())
        confidence = round(scores[top_label] / total, 4) if total > 0 else 0.1
        all_norm = {k: round(v / total, 4) for k, v in scores.items() if total > 0}
        return {
            "category": top_label,
            "score": confidence,
            "all_categories": all_norm,
            "role": "fallback"
        }

    def __call__(self, text: str, language: Optional[str] = None, text_translated: Optional[str] = None, visual: bool = True) -> Dict[str, Any]:
        """Allows the service to be called directly like a function."""
        return self.classify(text, language, text_translated, visual=visual)

    def classify(self, text: str, 
                 language: Optional[str] = None, 
                 text_translated: Optional[str] = None,
                 visual: bool = True) -> Dict[str, Any]:
        """Unified Classification API (Fig 4 in Paper)"""
        log = ServiceLogger() if visual else None
        if log: log.header("Classification Service")

        if not text:
            if log: log.log("Input Check", "EMPTY")
            return {}

        # 1. Multi-Lingual Intelligence Bridge
        content = self.ensure_english_content(text, language, text_translated, visual=visual, log=log)
        text_en = content["text"]
        source_lang = content["language"]

        # 2. Primary: facebook/bart-large-mnli
        final_result = None
        if log: log.log("Primary Engine", "BART-Large-MNLI (Zero-Shot)")
        try:
            classifier = registry.get_classifier_pipeline()
            result = classifier(text_en, candidate_labels=self.candidate_labels)
            
            if result:
                top3 = dict(zip(result['labels'][:3], [round(float(s), 4) for s in result['scores'][:3]]))
                if log:
                    log.log("Inference Complete", "Top 3 Categories Identified")
                    for cat, score in top3.items():
                        log.item(cat, f"Conf: {score:.2f}")

                final_result = {
                    "category": result['labels'][0],
                    "score": round(float(result['scores'][0]), 4),
                    "top_3_categories": top3,
                    "all_categories": dict(zip(result['labels'], [round(float(s), 4) for s in result['scores']])),
                    "role": "primary"
                }
        except Exception as e:
            logger.error(f"BART-MNLI Classification Fail: {e}")

        # 3. Fallback: keyword-based heuristic mapping
        if final_result is None:
            if log: log.log("Primary Engine", "FAILED - Switching to Keyword Heuristics")
            final_result = self._keyword_heuristic(text_en)

        # 4. Bilingual Mirroring (Paper §3.3.4)
        cat_en = final_result["category"]
        cat_source = cat_en
        if source_lang != "en" and source_lang != "unknown":
            if log: log.log("Mirroring", f"Translating category label '{cat_en}' to {source_lang}")
            from .translation_service import TranslationService
            ts = TranslationService()
            cat_source = ts.translate(cat_en, target=source_lang, source="en")

        # 5. Verification Gate (Confidence Transparency)
        if log: log.header("Verification Gate")
        if log:
            log.eval("Category Confidence", f"{final_result['score']:.2f}")
            log.success("Verification Gate", f"PASSED (Top: {cat_en})")
            log.success("Classification Service")

        return {
            "en": cat_en,
            "source": cat_source,
            "category": cat_en, # Legacy
            "score": final_result["score"],
            "top_3_categories": final_result.get("top_3_categories"),
            "role": final_result["role"]
        }
