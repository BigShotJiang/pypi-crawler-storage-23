import torch
import logging
from typing import Dict, Any, List, Optional
from .base_service import BaseService
from ..utils.model_registry import registry
from ..utils.service_logging import ServiceLogger

logger = logging.getLogger(__name__)

class NERService(BaseService):
    """
    Expert-level Service for Named Entity Recognition (Service D).
    Features: GLiNER Primary, SpaCy Fallback, Script-Specific Refinement, Bilingual Output.
    """
    
    def __init__(self, entities: List[str] = None):
        super().__init__()
        self.labels = entities or ["Person", "Organization", "Location", "Event", "Date"]

    def _extract_with_gliner_v1(self, text: str) -> Optional[List[Dict]]:
        """TIER 1: GLiNER GPU Inference"""
        try:
            model = registry.get_ner_model()
            entities = model.predict_entities(text, self.labels, threshold=0.55)
            return [{"text": e["text"], "label": e["label"], "score": round(e["score"], 4)} for e in entities]
        except Exception: return None

    def __call__(self, text: str, language: Optional[str] = None, text_translated: Optional[str] = None, visual: bool = True, mirror: bool = True) -> Dict[str, Any]:
        return self.extract(text, language, text_translated, visual=visual, mirror=mirror)

    def extract(self, text: str, 
                language: Optional[str] = None, 
                text_translated: Optional[str] = None,
                visual: bool = True,
                mirror: bool = True) -> Dict[str, Any]:
        """Unified NER API (Fig 3 in Paper)"""
        log = ServiceLogger() if visual else None
        if log: log.header("NER Service")

        # 1. Expert Intelligence: Multilingual Bridge
        content = self.ensure_english_content(text, language, text_translated, visual=visual, log=log)
        text_en = content["text"]
        source_lang = content["language"]

        # 2. Primary Engine
        if log: log.log("Primary Engine", "GLiNER-Large (Zero-Shot)")
        entities_en = self._extract_with_gliner_v1(text_en)
        status = "READY_FOR_LOCAL_GPU"
        
        # 3. Fallback Engine
        if entities_en is None:
            if log: log.log("Primary Engine", "FAILED - Switching to SpaCy Fallback")
            try:
                nlp = registry.get_spacy_model()
                doc = nlp(text_en)
                entities_en = [{"text": ent.text, "label": ent.label_, "score": 0.6} for ent in doc.ents]
                status = "FALLBACK_TO_SPACY"
            except:
                entities_en = []
                status = "CRITICAL_ERROR"

        # 4. Deduplication & Script Refinement
        unique_en = []
        seen = set()
        for ent in entities_en:
            key = f"{ent['text'].lower()}_{ent['label']}"
            if key not in seen:
                unique_en.append(ent)
                seen.add(key)

        # 5. Bilingual Mirroring (Paper §3.3.4)
        entities_source = []
        if mirror and source_lang != "en" and source_lang != "unknown" and unique_en:
            if log: log.log("Mirroring", f"Translating entities back to {source_lang}")
            from .translation_service import TranslationService
            ts = TranslationService()
            for ent in unique_en:
                try:
                    # Explicitly use string target for mirroring
                    mirrored_text = ts.translate(ent["text"], target=source_lang, source="en", visual=False)
                    entities_source.append({**ent, "text": mirrored_text})
                except:
                    entities_source.append(ent)

        # 6. Verification Gate
        if log:
            log.header("Verification Gate")
            log.eval("Confidence Pass", "SUPPORTED")
            log.success("NER Service")

        return {
            "en": unique_en,
            "source": entities_source if entities_source else unique_en,
            "status": status,
            "count": len(unique_en)
        }
