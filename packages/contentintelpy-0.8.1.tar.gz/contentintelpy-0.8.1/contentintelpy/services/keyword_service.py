import torch
import logging
from typing import Dict, Any, List, Optional
from .base_service import BaseService
from ..utils.model_registry import registry
from ..utils.service_logging import ServiceLogger

logger = logging.getLogger(__name__)

class KeywordExtractionService(BaseService):
    """
    Expert-level Service for Keyword Extraction (Service E).
    Features: T5 Primary, KeyBERT Fallback, Verification Gate, Bilingual Output.
    """
    
    def __init__(self, top_n: int = 10):
        super().__init__()
        self.top_n = top_n

    def _extract_with_t5(self, text: str) -> Optional[List[str]]:
        """TIER 1: T5-Keywords GPU Inference"""
        try:
            bundle = registry.get_keyword_model()
            model = bundle["model"]
            tokenizer = bundle["tokenizer"]
            device = bundle["device"]

            input_text = f"extract keywords: {text}"
            inputs = tokenizer(input_text, return_tensors="pt", max_length=512, truncation=True).to(device)
            
            with torch.no_grad():
                outputs = model.generate(
                    **inputs,
                    max_length=100,
                    num_beams=5,
                    num_return_sequences=1,
                    early_stopping=True
                )
            
            keywords_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
            keywords = [kw.strip() for kw in keywords_text.split(",") if kw.strip()]
            return keywords[:self.top_n]
        except Exception as e:
            logger.error(f"T5 Keywords Fail: {e}")
            return None

    def _extract_with_keybert_v1(self, text: str) -> List[str]:
        """TIER 3: KeyBERT Fallback"""
        try:
            model = registry.get_keybert_model()
            keywords = model.extract_keywords(
                text,
                keyphrase_ngram_range=(1, 3),
                stop_words='english',
                use_mmr=True,
                diversity=0.7,
                top_n=self.top_n
            )
            return [kw[0] for kw in keywords if kw[1] > 0.3]
        except Exception as e:
            logger.error(f"KeyBERT Fail: {e}")
            return []

    def __call__(self, text: str, language: Optional[str] = None, text_translated: Optional[str] = None, top_n: Optional[int] = None, visual: bool = True) -> Dict[str, Any]:
        """Allows the service to be called directly like a function."""
        return self.extract(text, language, text_translated, top_n, visual=visual)

    def extract(self, text: str, 
                language: Optional[str] = None, 
                text_translated: Optional[str] = None,
                top_n: Optional[int] = None,
                visual: bool = True) -> Dict[str, Any]:
        """Unified Keyword Extraction API (Fig 4 in Paper)"""
        if top_n: self.top_n = top_n
        log = ServiceLogger() if visual else None
        if log: log.header("Keyword Extraction Service")
        
        # 1. Expert Intelligence: Multilingual Bridge
        content = self.ensure_english_content(text, language, text_translated, visual=visual, log=log)
        text_en = content["text"]
        source_lang = content["language"]

        # 2. Primary Engine
        if log: log.log("Primary Engine", "T5-Transformer (Keywords-Seq2Seq)")
        keywords_en = self._extract_with_t5(text_en)
        status = "READY_FOR_LOCAL_GPU"
        
        # 3. Fallback Engine
        if keywords_en is None:
            if log: log.log("Primary Engine", "FAILED - Switching to KeyBERT Fallback")
            keywords_en = self._extract_with_keybert_v1(text_en)
            status = "FALLBACK_TO_V1_GPU_SAFETY"

        # 4. Deduplication Logic (Case-Insensitive)
        seen = set()
        unique_en = []
        for kw in (keywords_en or []):
            if kw.lower() not in seen:
                unique_en.append(kw)
                seen.add(kw.lower())
        
        # 5. Bilingual Mirroring (Paper §3.3.4)
        keywords_source = []
        if source_lang != "en" and source_lang != "unknown" and unique_en:
            if log: log.log("Mirroring", f"Translating keywords back to {source_lang}")
            from .translation_service import TranslationService
            ts = TranslationService()
            for kw in unique_en:
                try:
                    # Batching would be better, but simple loop for robustness in standalone
                    mirrored = ts.translate(kw, target=source_lang, source="en")
                    keywords_source.append(mirrored)
                except:
                    keywords_source.append(kw)

        if log:
            log.log("Keywords Found", f"{len(unique_en)} unique terms")
            for kw in unique_en[:5]:
                log.item("term", kw)

        # 6. Verification Gate
        if log: log.header("Verification Gate")
        conf = 0.9 if status == "READY_FOR_LOCAL_GPU" else 0.7
        valid_count = len([k for k in unique_en if len(k) > 2])
        
        if log:
            log.eval("Density Check", f"{valid_count}/{len(unique_en) or 1} Significant")
            log.eval("Confidence Score", f"{conf:.2f}")
            log.success("Verification Gate", f"PASSED (Confidence: {conf})")
            log.success("Keyword Extraction Service")

        return {
            "en": unique_en,
            "source": keywords_source if keywords_source else unique_en,
            "confidence": conf,
            "status": status,
            "language_detected": source_lang
        }
