import re
import unicodedata
import hashlib
import logging
from typing import Dict, Any, Optional
from .base_service import BaseService
from ..utils.service_logging import ServiceLogger

logger = logging.getLogger(__name__)

class PreprocessingService(BaseService):
    """
    Expert-level Service for Text Preprocessing (Service A).
    Features: unicodedata (Primary), html.parser (Fallback), Text Quality Gate.
    Paper §4.2: Normalization (Primary) and Artifact Cleaning (Fallback).
    """
    
    def __init__(self):
        super().__init__()
        self.emoji_pattern = re.compile(
            r"[\U0001F000-\U0001FAFF\U00002700-\U000027BF\U00002600-\U000026FF]+",
            flags=re.UNICODE
        )
        self.url_pattern = re.compile(r"http[s]?://\S+", re.IGNORECASE)
        self.html_pattern = re.compile(r"<[^>]+>")
        self.punctuation_map = {
            '\u201c': '"', '\u201d': '"', '\u2018': "'", '\u2019': "'",
            '\u2014': ' - ', '\u2013': ' - ', '--': ' - '
        }

    def _primary_normalize(self, text: str) -> str:
        """PRIMARY: Unicodedata Normalization (Paper §4.2)"""
        return unicodedata.normalize("NFKC", text)

    def _fallback_html_scrub(self, text: str) -> str:
        """FALLBACK: HTML/Artifact Cleaning (Paper §4.2)"""
        try:
            from html import unescape
            text = unescape(text)
            text = self.html_pattern.sub(" ", text)
            return text
        except: return self.html_pattern.sub(" ", text)

    def process(self, text: str, visual: bool = True) -> Dict[str, Any]:
        """Smarter Standalone Flow (Fig 1 in Paper)"""
        log = ServiceLogger() if visual else None
        if log: log.header("Preprocessing Service")

        if not text or not isinstance(text, str):
            if log: log.log("Input Check", "EMPTY")
            return {"text": "", "score": 0.0, "status": "REJECTED"}

        # 1. Normalization (Primary Library)
        if log: log.log("Primary Engine", "unicodedata (NFKC Normalization)")
        text = self._primary_normalize(text)
        
        # 2. Artifact Cleaning (Fallback Structure)
        if log: log.log("Fallback Engine", "html.parser (Artifact Scrubbing)")
        text = self._fallback_html_scrub(text)
        
        # 3. Structural Cleaning
        text = re.sub(r"([।\.!?])(?=[^\s\d])", r"\1\n\n", text)
        for char, repl in self.punctuation_map.items():
            text = text.replace(char, repl)

        text = self.url_pattern.sub(" ", text)
        text = re.sub(r"[^\S\r\n]+", " ", text)
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        text = "\n\n".join(lines)

        cleaned_text = text.strip()

        # Phase 1 Gate: Text Quality Gate (Paper §3.3.1.A)
        if log: log.log("Text Quality Gate", "EVALUATING")
        quality_score = min(len(cleaned_text) / 500, 1.0)
        status = "PASSED" if quality_score >= 0.15 else "REJECTED"
        
        if log:
            log.eval("Quality Score", f"{quality_score:.2f}")
            log.eval("Final Status", status)
            log.success("Preprocessing Service")

        return {
            "text": cleaned_text,
            "score": quality_score,
            "status": status
        }

    def __call__(self, text: str, visual: bool = True) -> Dict[str, Any]:
        return self.process(text, visual=visual)
