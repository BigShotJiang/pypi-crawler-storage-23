from typing import Dict, Any, Optional
import logging
from .base_service import BaseService
from ..utils.service_logging import ServiceLogger
from ..utils.model_registry import registry

logger = logging.getLogger(__name__)

class LanguageDetectionService(BaseService):
    """
    Expert-level Service for Language Identification (Service B).
    Flow: Preprocessed Text -> RID Detect -> ROBERTA Fallback -> Gate.
    """
    def __call__(self, text: str, visual: bool = True) -> Dict[str, Any]:
        """Allows the service to be called directly like a function."""
        return self.detect(text, visual=visual)

    def detect(self, text: str, visual: bool = True) -> Dict[str, Any]:
        """Unified Detection API (Fig 2 in Paper)"""
        log = ServiceLogger() if visual else None
        if log: log.header("Language Detection Service")

        if not text or len(text.strip()) < 5:
            if log: log.log("Input Check", "TOO SHORT")
            return {"language": "unknown", "score": 0.0, "status": "REJECTED"}

        # 1. Primary: langdetect (fast, lightweight)
        try:
            if log: log.log("Primary Engine", "LANGDETECT (Lightweight)")
            from langdetect import detect_langs
            res = detect_langs(text[:512])
            if res and res[0].prob >= 0.7:
                if log: 
                    log.log("Confidence", f"{res[0].prob:.2f}")
                    log.log("Result", f"PRIMARY MATCH ({res[0].lang})")
                
                lang_data = {
                    "language": res[0].lang,
                    "score": round(res[0].prob, 4),
                    "role": "primary",
                    "status": "PASSED"
                }
                if log: log.success("Language Detection")
                return lang_data
        except Exception as e:
            logger.error(f"LangDetect Fail: {e}")

        # 2. Fallback: XLM-RoBERTa (heavy confirmation model)
        try:
            if log: log.log("Fallback Engine", "XLM-ROBERTA (High-Accuracy)")
            detector = registry.get_language_detector()
            result = detector(text[:512])
            if result:
                top = result[0]
                if log: log.log("Result", f"FALLBACK CONFIRMED ({top['label']})")
                
                lang_data = {
                    "language": top['label'],
                    "score": round(float(top['score']), 4),
                    "role": "fallback",
                    "status": "PASSED"
                }
                if log: log.success("Language Detection")
                return lang_data
        except Exception as e:
            logger.error(f"XLM-RoBERTa LID Fail: {e}")

        if log: log.success("Language Detection", "REJECTED")
        return {"language": "en", "score": 0.0, "role": "default", "status": "REJECTED"}
