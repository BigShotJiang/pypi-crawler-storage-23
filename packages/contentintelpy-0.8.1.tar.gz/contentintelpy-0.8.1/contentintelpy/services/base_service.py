from typing import Dict, Any, Optional
import logging
from ..utils.model_registry import registry

logger = logging.getLogger("contentintelpy")

class BaseService:
    """
    Experimental Base for "Expert" Standalone Services.
    Handles its own multilingual logic without needing a Pipeline Node.
    """
    
    def ensure_english_content(self, text: str, 
                              language: Optional[str] = None, 
                              text_translated: Optional[str] = None,
                              visual: bool = False,
                              log: Optional['ServiceLogger'] = None) -> Dict[str, Any]:
        """
        Expert Logic: Ensures English text is available for analysis.
        Returns a dict with 'text' (the one to use), 'language', and 'text_translated'.
        """
        if visual and log:
            log.log("Multilingual Bridge", "CHECKING")

        # 1. Use existing translation if provided
        if text_translated:
            if visual and log: log.log("Translation Source", "PROVIDED")
            return {
                "text": text_translated,
                "language": language or "en",
                "text_translated": text_translated
            }

        # 2. English Mode: Use raw text if already identified as English
        if language == "en":
             if visual and log: log.log("Language Check", "ALREADY ENGLISH")
             return {
                "text": text,
                "language": "en",
                "text_translated": None
            }

        # 3. Dynamic LID: Detect if unknown
        current_lang = language
        if not current_lang:
            try:
                detector = registry.get_language_detector()
                result = detector(text[:512])
                if result:
                    current_lang = result[0]['label']
                    if visual and log: log.log("Detected Language", current_lang)
            except Exception as e:
                logger.warning(f"Internal LID failure in Service: {e}")
                current_lang = "en" # Fallback

        # 4. Handle Translation on-the-fly
        final_text = text
        final_trans = None
        
        if current_lang != "en":
            try:
                if visual and log: log.log("Translation Mode", f"{current_lang} -> en")
                bundle = registry.get_translation_model()
                translator = bundle["translator"]
                src_nllb = registry.get_nllb_code(current_lang)
                tgt_nllb = registry.get_nllb_code("en")
                
                output = translator(text, src_lang=src_nllb, tgt_lang=tgt_nllb, max_length=512)
                if output:
                    final_trans = output[0].get('translation_text', output[0])
                    final_text = final_trans
                    if visual and log: log.log("Translation Status", "SUCCESSFUL")
            except Exception as e:
                logger.warning(f"Internal Translation failure in Service: {e}")
                final_text = text

        return {
            "text": final_text,
            "language": current_lang,
            "text_translated": final_trans
        }

    def translate_back(self, text_en: str, target_lang: str) -> str:
        """Helper for Summarization 'Expert' to mirror language."""
        if not target_lang or target_lang == "en":
            return text_en
            
        try:
            bundle = registry.get_translation_model()
            translator = bundle["translator"]
            src_nllb = registry.get_nllb_code("en")
            tgt_nllb = registry.get_nllb_code(target_lang)
            
            output = translator(text_en, src_lang=src_nllb, tgt_lang=tgt_nllb, max_length=512)
            if output:
                return output[0].get('translation_text', output[0])
        except Exception as e:
            logger.warning(f"Internal Back-Translation failure in Service: {e}")
            
        return text_en
