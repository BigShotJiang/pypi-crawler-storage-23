import importlib
import sys
import os

from .utils.logging import suppress_all_logs
from .utils.reporting import print_report

# Suppress technical noise by default
suppress_all_logs()

from .pipeline.pipeline import Pipeline
from .pipeline.context import PipelineContext
from .pipeline.base_node import Node, GateNode, RouterNode

# Nodes for the default pipeline and custom use
from .nodes.preprocessing_node import PreprocessingNode
from .nodes.language_node import LanguageDetectionNode
from .nodes.ner_node import NERNode
from .nodes.translation_node import TranslationNode
from .nodes.classification_node import CategoryClassificationNode
from .nodes.location_node import LocationExtractionNode
from .nodes.sentiment_node import SentimentNode
from .nodes.keyword_extract_node import KeywordExtractionNode
from .nodes.summarization_node import SummarizationNode
from .nodes.final_gate_node import FinalQualityGate

# Quality Gate Nodes
from .nodes.quality_gates import (
    TextQualityGate,
    TranslationQualityGate,
    CategoryConfidenceGate,
    SummaryQualityGate
)

# Router Nodes
from .nodes.router_node import LanguageRouter

# Core Pipeline Components
from .pipeline.parallel_node import ParallelNode

# Standalone Services for Public API
from .services.sentiment_service import SentimentService
from .services.translation_service import TranslationService
from .services.ner_service import NERService
from .services.summarization_service import SummarizationService
from .services.classification_service import CategoryClassificationService
from .services.keyword_service import KeywordExtractionService
from .services.preprocessing_service import PreprocessingService
from .services.language_service import LanguageDetectionService
from .services.location_service import LocationService

def create_default_pipeline() -> Pipeline:
    """
    Creates the canonical ContentIntelPy DAG Pipeline (4-Phase Smart Workflow).
    Matches the visual log format exactly.
    """
    # Build the Language Router with its routes
    language_router = LanguageRouter()
    language_router.set_routes({
        "translate": [
            TranslationNode(target_lang="en"),
            TranslationQualityGate()
        ],
        "skip_translation": [
             TranslationQualityGate() # To show "(No Translation Required)"
        ]
    })

    nodes = [
        # PHASE 1
        PreprocessingNode(),
        LanguageDetectionNode(),
        TextQualityGate(),
        NERNode(name="NER before translation"),
        language_router,

        # PHASE 2
        ParallelNode([
            CategoryClassificationNode(), # "Classification"
            NERNode(name="NER After translation"),
            KeywordExtractionNode(),      # "Keyword Extraction"
            LocationExtractionNode(),     # "Location Extraction"
            SentimentNode(),              # "Sentiment"
            SummarizationNode()           # "Summarization"
        ], name="Parallel Phase 2", phase_label="PHASE 2: INDEPENDENT TASKS (Parallel Analysis)"),
        
        CategoryConfidenceGate(), # "Verification Gate" in quality_gates.py

        # PHASE 3
        FinalQualityGate(), # "Tiering Logic" in final_gate_node.py

        # PHASE 4
        SummaryQualityGate(), # "Bilingual Quality Check" in quality_gates.py
    ]

    # Industrial Phase Markers
    for n in nodes: n.phase_label = None # Clear existing
    nodes[0].phase_label = "PHASE 1: DEPENDANT TASKS (Sequential)"
    nodes[5].phase_label = "PHASE 2: INDEPENDENT TASKS (Parallel Analysis)"
    nodes[7].phase_label = "PHASE 3: TIERING GATE"
    nodes[8].phase_label = "PHASE 4: BILINGUAL GATE"

    return Pipeline(nodes, is_default=True)

__all__ = [
    # Engine
    "Pipeline",
    "create_default_pipeline",
    "PipelineContext",
    "Node",
    "GateNode",
    "RouterNode",
    "ParallelNode",
    
    # Processing Nodes
    "PreprocessingNode",
    "LanguageDetectionNode",
    "NERNode",
    "TranslationNode",
    "CategoryClassificationNode",
    "LocationExtractionNode",
    "SentimentNode",
    "KeywordExtractionNode",
    "SummarizationNode",

    # Quality Gate Nodes
    "TextQualityGate",
    "TranslationQualityGate",
    "CategoryConfidenceGate",
    "SummaryQualityGate",
    "FinalQualityGate",

    # Router Nodes
    "LanguageRouter",
    
    # Services
    "SentimentService",
    "TranslationService",
    "NERService",
    "SummarizationService",
    "CategoryClassificationService",
    "KeywordExtractionService",
    "PreprocessingService",
    "LanguageDetectionService",
    "LocationService",
    
    # Utilities
    "suppress_all_logs",
    "print_report"
]

