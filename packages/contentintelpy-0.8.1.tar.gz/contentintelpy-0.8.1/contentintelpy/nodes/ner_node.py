from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..services.ner_service import NERService
from typing import List

class NERNode(Node):
    """
    The Captain (DAG Node): Bridges Pipeline Context to NER Expert.
    """
    def __init__(self, labels: List[str] = None, name: str = "NER After translation"):
        super().__init__(name)
        self.service = NERService(entities=labels)

    def get_visual_info(self, context: PipelineContext) -> str:
        entities = context.get("entities", [])
        return f"(Entities: {len(entities)})"

    def process(self, context: PipelineContext) -> PipelineContext:
        """
        Captain's Job: Grab data, call expert, save result.
        """
        text = context.get("text")
        lang = context.get("language")
        trans = context.get("text_translated")

        # The Expert returns a bilingual dict: { "en": [...], "source": [...] }
        res = self.service.extract(text, language=lang, text_translated=trans, visual=False)
        
        if res:
            new_entities = res.get("en", [])
            new_entities_source = res.get("source", [])
            
            # MERGE LOGIC for English:
            existing_entities = context.get("entities", [])
            if existing_entities:
                existing_signatures = {(e["text"].lower().strip(), e["label"]) for e in existing_entities}
                for entity in new_entities:
                    sig = (entity["text"].lower().strip(), entity["label"])
                    if sig not in existing_signatures:
                        existing_entities.append(entity)
                context["entities"] = existing_entities
            else:
                context["entities"] = new_entities

            # Bilingual Storage for Phase 4
            context["entities_source"] = new_entities_source

            # Update NLP quality signal
            if "scores" not in context: context["scores"] = {}
            context["scores"]["nlp_quality"] = min(len(context.get("entities", [])) / 10, 1.0)

        return context
