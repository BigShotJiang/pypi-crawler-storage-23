from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..services.location_service import LocationService
from ..services.ner_service import NERService
from typing import List

class LocationExtractionNode(Node):
    """
    The Captain (DAG Node): Bridges Pipeline Context to Location Expert.
    """
    def __init__(self):
        super().__init__("Location Extraction")
        self.service = LocationService()

    def get_visual_info(self, context: PipelineContext) -> str:
        locs = context.get("locations", [])
        return f"(Locs: {len(locs)})" if locs else "(Locs: 0)"

    def process(self, context: PipelineContext) -> PipelineContext:
        """
        Captain's Job: Grab data, call expert, save result.
        """
        text = context.get("text")
        lang = context.get("language")
        trans = context.get("text_translated")
        entities = context.get("entities", [])
        # The Expert returns: { "en": [...], "source": [...], "status": "PASSED" }
        res = self.service.extract(text, language=lang, text_translated=trans, visual=False, entities_list=entities)
        
        if res:
            context["locations"] = res.get("en", [])
            context["locations_source"] = res.get("source", [])
            
            # Populate quality matrix
            if "scores" not in context: context["scores"] = {}
            context["scores"]["location_quality"] = 0.90 if res.get("en") else 0.40

        return context
