from ..pipeline.base_node import RouterNode
from ..pipeline.context import PipelineContext


class LanguageRouter(RouterNode):
    """
    Router Node: Decides whether to translate based on detected language.
    - If language is English → skip translation (route: "skip_translation")
    - If language is not English → route to translation (route: "translate")
    Ported from Backend v2.0.
    """
    def __init__(self):
        super().__init__("Language Router")

    def get_visual_info(self, context: PipelineContext) -> str:
        lang = context.get("language", "unknown")
        if lang == "en":
            return "Source is English -> Skipping Translation"
        return f"Source is {lang.upper()} -> Routing to Translation"

    def _route(self, context: PipelineContext) -> str:
        lang = context.get("language", "unknown")
        if lang != "en" and lang != "unknown":
            return "translate"
        return "skip_translation"
