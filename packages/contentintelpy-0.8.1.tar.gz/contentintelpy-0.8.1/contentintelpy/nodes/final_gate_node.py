from ..pipeline.base_node import GateNode
from ..pipeline.context import PipelineContext

class FinalQualityGate(GateNode):
    """
    Phase 3 — Tiering Gate (Smart Workflow).

    Counts how many of the 9 NLP services produced a valid output and
    assigns a reliability tier exactly as described in the paper:

        Tier 1 (High Quality) : 9 / 9 services successful
        Tier 2 (Medium Quality): 6 – 8 / 9 services successful
        Tier 3 (Low Quality)  : 1 – 5 / 9 services successful
        Rejected              : 0 / 9 services successful
    """

    # Every key that represents a successfully-produced NLP service result.
    # 9 services total: preprocessing, language, translation, NER, keywords,
    # category, location, summarization, sentiment.
    SERVICE_OUTPUT_KEYS = [
        "text",              # Preprocessing
        "language",          # Language Detection
        "text_translated",   # Entity-Aware Translation
        "entities",          # Named Entity Recognition
        "keywords",          # Keyword Extraction
        "category",          # Category Classification
        "locations",         # Hierarchical Location Extraction
        "summary",           # Summarization
        "sentiment",         # Sentiment Analysis
    ]

    def __init__(self):
        super().__init__("Tiering Logic")

    def get_visual_info(self, context: PipelineContext) -> str:
        return ""

    def run(self, context: PipelineContext, run_id: str = None, indent: str = "") -> PipelineContext:
        """Override to print EXACTLY like the screenshot"""
        if run_id:
            print(f"[{run_id}... ] {indent}{self.name}: Evaluating...")

        try:
            context = self._evaluate(context)
            count = context.get("services_successful", 0)
            tier = context.get("tier", "N/A")
            
            if run_id:
                print(f"[{run_id}... ] {indent}  Service Score: {count}/9 Active Services")
                print(f"[{run_id}... ] {indent}{self.name}: TIER {tier} DETECTED (Excellent)")
                print() # Empty line after tier
                
            return context
        except Exception as e:
            if run_id:
                print(f"[{run_id}... ] {indent}{self.name}: PROCESSING ERROR ({str(e)})")
            return context

    def _evaluate(self, context: PipelineContext) -> PipelineContext:
        if "scores" not in context:
            context["scores"] = {}

        # ── Count successful services ──────────────────────────────────────
        successful = 0
        for key in self.SERVICE_OUTPUT_KEYS:
            val = context.get(key)
            if val is not None and val != "" and val != [] and val != {}:
                successful += 1

        context["services_successful"] = successful
        context["scores"]["overall"] = round(successful / len(self.SERVICE_OUTPUT_KEYS), 4)

        # ── Assign Reliability Tier (paper §3.3.3) ─────────────────────────
        if successful == 0:
            context.abort("All 9 NLP services failed to produce output (0/9 successful)")
            context["tier"] = "Rejected"
        elif successful <= 5:
            context["tier"] = 3          # Tier 3 — Low Quality (1–5 / 9)
        elif successful <= 8:
            context["tier"] = 2          # Tier 2 — Medium Quality (6–8 / 9)
        elif successful == 9:
            context["tier"] = 1          # Tier 1 — High Quality (9 / 9)
        else:
            context["tier"] = 1 # Safety

        return context
