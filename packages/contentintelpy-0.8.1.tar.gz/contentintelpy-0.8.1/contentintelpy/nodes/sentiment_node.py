from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..services.sentiment_service import SentimentService

class SentimentNode(Node):
    """
    The Captain (DAG Node): Bridges Pipeline Context to Sentiment Expert.
    """
    def __init__(self):
        super().__init__("Sentiment")
        self.service = SentimentService()

    def get_visual_info(self, context: PipelineContext) -> str:
        sent = context.get("sentiment", "")
        if sent == "pos": return "(Positive)"
        if sent == "neg": return "(Negative)"
        return "(Neutral)"

    def process(self, context: PipelineContext) -> PipelineContext:
        """
        Captain's Job: Grab data, call expert, save result.
        """
        text = context.get("text")
        lang = context.get("language")
        trans = context.get("text_translated")

        # The Expert returns: { "en": "pos", "source": "pos", "score": 0.9 }
        res = self.service.analyze(text, language=lang, text_translated=trans, visual=False)
        
        if res:
            context["sentiment"] = res.get("en", "neutral")
            context["sentiment_source"] = res.get("source", "neutral")
            context["sentiment_score"] = res.get("score", 0.0)
            
            # Populate quality matrix
            if "scores" not in context: context["scores"] = {}
            context["scores"]["sentiment_confidence"] = res.get("score", 0.0)

        return context
