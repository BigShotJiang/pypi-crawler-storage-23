from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..services.preprocessing_service import PreprocessingService
import hashlib

class PreprocessingNode(Node):
    """
    The Captain (DAG Node): Bridges Pipeline Context to Preprocessing Expert.
    """
    def __init__(self):
        super().__init__("Preprocessing")
        self.service = PreprocessingService()

    def get_visual_info(self, context: PipelineContext) -> str:
        text = context.get("text", "")
        return f"(Length: {len(text)} chars)"

    def process(self, context: PipelineContext) -> PipelineContext:
        """
        Captain's Job: Grab data, call expert, save result.
        """
        text = context.get("text")
        if not text:
            return context

        # The Expert handles the scrubbing (Paper Fig 1 Flow)
        # Standalone Preprocessing now returns a dict with status/score
        res = self.service.process(text, visual=False)
        clean_text = res.get("text", "")
        status = res.get("status", "PASSED")
        score = res.get("score", 0.0)
        
        context["text"] = clean_text
        context["text_hash"] = hashlib.md5(clean_text.encode()).hexdigest()

        # Signal Scoring for Final Gate
        if "scores" not in context: context["scores"] = {}
        context["scores"]["text_quality"] = score
        
        # Hard Halt Policy (Paper §3.3): If processing rejected the text, stop now
        if status == "REJECTED":
            context.abort(f"Preprocessing Rejected: Quality too low (Score: {score:.2f})")
        
        return context
