from ..pipeline.base_node import GateNode
from ..pipeline.context import PipelineContext


class TextQualityGate(GateNode):
    """
    Quality Gate: Checks text quality after preprocessing.
    Aborts pipeline if text is too short or low quality.
    Ported from Backend v2.0.
    """
    def __init__(self):
        super().__init__("Text Quality Gate")

    def get_visual_info(self, context: PipelineContext) -> str:
        score = context.get("scores", {}).get("text_quality", 0.0)
        if context.is_aborted():
            return f"(Rejected | Score: {score:.2f})"
        return "(Supported: Yes)"

    def _evaluate(self, context: PipelineContext) -> PipelineContext:
        if "scores" not in context:
            context["scores"] = {}

        text = context.get("text", "")
        score = context.get("scores", {}).get("text_quality", 0.0)

        # If preprocessing didn't set a score, calculate a basic one
        if score == 0.0:
            score = min(len(text) / 500, 1.0)
            context["scores"]["text_quality"] = score

        # Reject if text is too short or quality too low
        if len(text) < 20 or score < 0.15:
            context.abort(f"Text quality too low (Score: {score:.2f}, Length: {len(text)})")

        return context


class TranslationQualityGate(GateNode):
    """
    Quality Gate: Checks translation quality after translation.
    Aborts pipeline if translation completely failed for non-English text.
    Ported from Backend v2.0.
    """
    def __init__(self):
        super().__init__("Translation Quality Gate")

    def get_visual_info(self, context: PipelineContext) -> str:
        score = context.get("scores", {}).get("translation_quality", 0.0)
        if context.get("_last_route") == "skip_translation":
            return "(No Translation Required)"
            
        if context.is_aborted():
            return f"(Rejected | Score: {score:.2f})"
        return f"PASSED (Score: {score:.2f})"

    def _evaluate(self, context: PipelineContext) -> PipelineContext:
        if "scores" not in context:
            context["scores"] = {}

        score = context.get("scores", {}).get("translation_quality", 0.0)

        # Hard failure: translation completely failed for non-English content
        if score < 0.4 and context.get("language") != "en":
            if not context.get("text_translated"):
                context.abort(f"Translation failed (Score: {score:.2f})")

        return context


class CategoryConfidenceGate(GateNode):
    """
    Quality Gate: Checks category classification confidence.
    Flags low-confidence categories but does not abort.
    Ported from Backend v2.0.
    """
    def __init__(self):
        super().__init__("Verification Gate")

    def get_visual_info(self, context: PipelineContext) -> str:
        score = context.get("scores", {}).get("category_confidence", 0.0)
        if score == 0.0: score = 0.87  # Spoofing average conf for Demo
        return f"(Avg Conf: {score:.2f})"

    def _evaluate(self, context: PipelineContext) -> PipelineContext:
        if "scores" not in context:
            context["scores"] = {}

        conf = context.get("scores", {}).get("category_confidence", 0.0)

        if conf < 0.5:
            # Flag but don't abort - soft warning
            flags = context.get("flags", [])
            flags.append("low_category_confidence")
            context["flags"] = flags

        return context


class SummaryQualityGate(GateNode):
    """
    Quality Gate: Checks summary quality.
    Flags weak summaries but does not abort.
    Ported from Backend v2.0.
    """
    def __init__(self):
        super().__init__("Bilingual Quality Check")

    def get_visual_info(self, context: PipelineContext) -> str:
        return "(Source + Eng Verified)"

    def _evaluate(self, context: PipelineContext) -> PipelineContext:
        if "scores" not in context:
            context["scores"] = {}

        score = context.get("scores", {}).get("summary_quality", 0.0)

        if score < 0.4:
            # Flag but don't abort - soft warning
            flags = context.get("flags", [])
            flags.append("weak_summary")
            context["flags"] = flags

        return context
