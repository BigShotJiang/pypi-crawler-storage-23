from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..services.language_service import LanguageDetectionService

class LanguageDetectionNode(Node):
    """
    The Captain (DAG Node): Bridges Pipeline Context to Language Expert.
    Acts as the 'Stop/Reject' gate for unknown content.
    """
    def __init__(self, min_confidence: float = 0.2):
        super().__init__("Language Detection")
        self.service = LanguageDetectionService()
        self.min_confidence = min_confidence

    def get_visual_info(self, context: PipelineContext) -> str:
        lang = context.get("language", "??")
        score = context.get("language_score", 0.0)
        return f"(Lang: {lang} | Conf: {score:.2f})"

    def process(self, context: PipelineContext) -> PipelineContext:
        """
        Captain's Job: Identify language and decide whether to continue.
        """
        text = context.get("text")
        if not text:
            return context

        # The Expert identifies the language
        result = self.service.detect(text, visual=False)
        
        lang = result.get("language", "unknown")
        score = result.get("score", 0.0)

        context["language"] = lang
        context["language_score"] = score
        
        # Populate quality matrix
        if "scores" not in context: context["scores"] = {}
        context["scores"]["language_confidence"] = score

        # Industrial Safety Gate: Abort if quality is too low
        if lang == "unknown" or score < self.min_confidence:
            context.abort(f"Language detection failed or confidence too low ({score:.2f}).")

        return context
