from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..services.summarization_service import SummarizationService

class SummarizationNode(Node):
    """
    The Captain (DAG Node): Bridges Pipeline Context to Summarization Expert.
    """
    def __init__(self, max_length: int = 150, min_length: int = 40):
        super().__init__("Summarization")
        self.service = SummarizationService(max_length=max_length, min_length=min_length)

    def get_visual_info(self, context: PipelineContext) -> str:
        # Check if it was too short for AI
        summary_data = context.get("summary_data", {})
        if summary_data.get("is_passthrough"):
            return "(Passthrough | Text too short for AI)"
        return "(Completed)"

    def process(self, context: PipelineContext) -> PipelineContext:
        """
        Captain's Job: Grab data, call expert, save result.
        """
        text = context.get("text")
        lang = context.get("language")
        trans = context.get("text_translated")

        # The Expert returns: { "en": "...", "source": "...", "confidence": 0.9 }
        res = self.service.summarize(text, language=lang, text_translated=trans, visual=False)
        
        if res:
            context["summary"] = res.get("en", "")
            context["summary_source"] = res.get("source", "")
            context["summary_data"] = {
                "is_passthrough": res.get("is_passthrough", False),
                "status": res.get("status", "")
            }

            # Signal Scoring for Final Gate
            if "scores" not in context: context["scores"] = {}
            context["scores"]["summary_quality"] = res.get("confidence", 0.0)
        else:
            context.add_error(self.name, "Summarization failed completely")
        
        return context

