from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..services.translation_service import TranslationService

class TranslationNode(Node):
    """
    The Captain (DAG Node): Bridges Pipeline Context to Translation Expert.
    Phase 1: Preprocessing -> LID -> Entity-Aware Translation.
    Delegates all masking/reinjection logic to the TranslationService
    to avoid "Double Masking" context loss.
    """
    def __init__(self, target_lang: str = "en", force: bool = False):
        super().__init__("Entity-Aware Translation")
        self.target_lang = target_lang
        self.force = force
        self.service = TranslationService()

    def get_visual_info(self, context: PipelineContext) -> str:
        if context.get("translation_skipped"):
            return "PASSED (No Translation Required)"
        if "text_translated" in context:
            return f"COMPLETED (Length: {len(context.get('text_translated', ''))} chars)"
        return "(No translation performed)"

    def process(self, context: PipelineContext) -> PipelineContext:
        """
        Expert Translation Flow:
        Delegates Entity-Aware logic (Paper §3.1.C) to the service.
        """
        text = context.get("text")
        source = context.get("language", "unknown")

        if not text: return context

        # Skip translation if source language already matches target
        if source.lower().startswith(self.target_lang.lower()) and not self.force:
            context["translation_skipped"] = True
            return context

        # Run expert translation with visual logging disabled for pipeline run
        res = self.service.translate_to_english(text, source_lang=source, visual=False)
        
        translated_text = res.get("translated_text", "")
        
        if translated_text:
            context["text_translated"] = translated_text
            context["translation_engine"] = res.get("engine", "nllb")
            context["translation_method"] = "expert_entity_aware"

            # Populate quality matrix
            if "scores" not in context: context["scores"] = {}
            context["scores"]["translation_quality"] = 0.98 if res.get("engine") == "nllb" else 0.70

        return context
