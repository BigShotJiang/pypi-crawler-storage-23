from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..services.keyword_service import KeywordExtractionService

class KeywordExtractionNode(Node):
    """
    The Captain (DAG Node): Bridges Pipeline Context to Keyword Expert.
    """
    def __init__(self, top_n: int = 5):
        super().__init__("Keyword Extraction")
        self.service = KeywordExtractionService(top_n=top_n)

    def get_visual_info(self, context: PipelineContext) -> str:
        keywords = context.get("keywords", [])
        return f"(Keywords: {len(keywords)})"

    def process(self, context: PipelineContext) -> PipelineContext:
        """
        Captain's Job: Grab data, call expert, save result.
        """
        text = context.get("text")
        lang = context.get("language")
        trans = context.get("text_translated")

        # The Expert returns: { "en": [...], "source": [...], "confidence": 0.9 }
        res = self.service.extract(text, language=lang, text_translated=trans, visual=False)
        
        if res:
            context["keywords"] = res.get("en", [])
            context["keywords_source"] = res.get("source", [])
            
            # Score for Final Gate
            if "scores" not in context: context["scores"] = {}
            context["scores"]["keyword_quality"] = res.get("confidence", 0.0)

        return context
