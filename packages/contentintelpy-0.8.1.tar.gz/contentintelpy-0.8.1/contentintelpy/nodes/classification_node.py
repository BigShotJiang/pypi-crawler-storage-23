from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..services.classification_service import CategoryClassificationService
from typing import List

class CategoryClassificationNode(Node):
    """
    The Captain (DAG Node): Bridges Pipeline Context to Classification Expert.
    """
    def __init__(self, candidate_labels: List[str] = None):
        super().__init__("Classification")
        self.service = CategoryClassificationService(candidate_labels=candidate_labels)

    def get_visual_info(self, context: PipelineContext) -> str:
        cat = context.get("category", "")
        return f"(Label: {cat})" if cat else ""

    def process(self, context: PipelineContext) -> PipelineContext:
        """
        Captain's Job: Grab data from context, call expert, save result.
        """
        text = context.get("text")
        lang = context.get("language")
        trans = context.get("text_translated")

        # The Expert returns: { "en": "Politics", "source": "राजनीति", "score": 0.9 }
        res = self.service.classify(text, language=lang, text_translated=trans, visual=False)
        
        if res:
            context["category"] = res.get("en")
            context["category_source"] = res.get("source")
            context["category_score"] = res.get("score")
            context["all_categories"] = res.get("all_categories")
            
            # Populate quality matrix
            if "scores" not in context: context["scores"] = {}
            context["scores"]["category_confidence"] = res.get("score", 0.0)

        return context
