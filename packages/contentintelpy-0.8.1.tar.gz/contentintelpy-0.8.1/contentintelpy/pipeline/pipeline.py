from typing import List, Dict, Any
from .base_node import Node
from .context import PipelineContext

class PipelineResult(dict):
    """
    Intelligent Result Object.
    Behaves like a dictionary but provides built-in industrial reporting.
    """
    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)

    def show(self):
        """Displays a professional ASCII Intelligence Report."""
        from ..utils.reporting import print_report
        print_report(self)

    def __repr__(self):
        return f"<PipelineResult: {self.get('category', 'Uncategorized')} | {self.get('language', 'unknown')}>"

class Pipeline:
    """
    DAG execution engine.
    Runs a tailored sequence of Nodes in strict order.
    Industrial DAG visualization is always enabled by default.
    """
    def __init__(self, nodes: List[Node], is_default: bool = False):
        self.nodes = nodes
        self.is_default = is_default

    def run(self, input_data: Dict[str, Any]) -> PipelineResult:
        """
        Execute the pipeline with Industrial High-Visibility logging.
        Factory Pattern: Visual output is enabled for English by default.
        """
        import time
        import uuid

        run_id = uuid.uuid4().hex[:24]
        start_time = time.time()

        context = PipelineContext(input_data)
        
        # Always run visual logging for this demo
        is_visual = True

        if is_visual:
            print(f"[{run_id}... ] DAG PIPELINE START")
            print("-" * 65)
            print()
            context["_run_id_visual"] = run_id

        # Execution loop
        for i, node in enumerate(self.nodes):
            if context.is_aborted():
                if is_visual:
                    print(f"[{run_id}... ] [Aborted] Pipeline stopped: {context.get('abort_reason', 'Unknown')}")
                break

            # Visual Phase Transitions (Dynamic)
            if is_visual and node.phase_label:
                # To prevent repeating "PHASE 1" on every sub-node:
                if getattr(self, "_last_phase", None) != node.phase_label:
                    print(f"{'='*65}")
                    print(node.phase_label)
                    print(f"{'='*65}")
                    print() # Single empty line after header
                    self._last_phase = node.phase_label

            # Execute node with visual tracking
            context = node.run(context, run_id=run_id if is_visual else None)

        duration = int((time.time() - start_time) * 1000)

        if is_visual:
            print("-" * 65)
            # Check for errors and show appropriate status
            errors = context.get("errors", {})
            if context.is_aborted():
                reason = context.get("rejection_reason", "Low quality content")
                print(f"[{run_id}... ] PIPELINE ABORTED ({duration}ms)")
                print(f"[{run_id}... ] Reason: {reason}\n")
            elif errors:
                failed_stages = ", ".join(errors.keys())
                print(f"[{run_id}... ] PIPELINE COMPLETED WITH WARNINGS ({duration}ms)")
                print(f"[{run_id}... ] Failed stages: {failed_stages}\n")
            else:
                print(f"[{run_id}... ] PIPELINE SUCCESSFUL ({duration}ms)\n")

        return PipelineResult(context.to_dict())

