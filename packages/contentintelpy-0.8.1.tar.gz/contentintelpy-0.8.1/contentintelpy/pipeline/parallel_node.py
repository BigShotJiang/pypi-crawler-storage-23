import threading
from typing import List
from .base_node import Node
from .context import PipelineContext

class ParallelNode(Node):
    """
    A special node that executes a child group of nodes concurrently.
    Useful for Phase 3 (Parallel Scanners) and Phase 4 (Deep Analysis).
    """
    def __init__(self, nodes: List[Node], name: str = "ParallelGroup", phase_label: str = None):
        super().__init__(name, phase_label=phase_label)
        self.nodes = nodes

    def run(self, context: PipelineContext, run_id: str = None, indent: str = "") -> PipelineContext:
        """Override run to hide the parallel group itself and just spawn threads."""
        return self.process(context, run_id, indent)

    def process(self, context: PipelineContext, run_id: str = None, indent: str = "") -> PipelineContext:
        """
        Executes all sub-nodes in their own threads with flat indentation.
        """
        threads = []
        
        for i, node in enumerate(self.nodes):
            t = threading.Thread(target=node.run, args=(context, run_id, indent))
            t.start()
            threads.append(t)
            
        # Wait for all to finish
        for t in threads:
            t.join()
            
        return context
