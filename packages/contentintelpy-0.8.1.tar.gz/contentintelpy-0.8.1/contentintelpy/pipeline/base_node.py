from abc import ABC, abstractmethod
from typing import Any
from .context import PipelineContext
import logging

# Configure reusable logger
logger = logging.getLogger("contentintelpy")

class Node(ABC):
    """
    Base class for all NLP processing nodes.
    Enforces the contract: read from context -> process -> write to context -> handle errors.
    """
    def __init__(self, name: str, phase_label: str = None):
        self.name = name
        self.phase_label = phase_label

    def get_visual_info(self, context: PipelineContext) -> str:
        """
        Returns dynamic status info to be displayed in the industrial log.
        e.g. "(Lang: hi | Length: 142)"
        """
        return ""

    def run(self, context: PipelineContext, run_id: str = None, indent: str = "") -> PipelineContext:
        """
        Public execution entry point. Handles error safety and visual logging.
        Strictly respects context.is_aborted() for "Hard Halt" policy (Paper §3.3).
        """
        if context.is_aborted():
            return context

        if run_id:
            print(f"[{run_id}... ] {indent}{self.name}: START")

        try:
            # Execute the core logic
            result = self.process(context)
            
            # Post-execution Check: If node logic itself triggered an abort
            if context.is_aborted() and run_id:
                print(f"[{run_id}... ] {indent}{self.name}: REJECTED - Stopping Pipeline")

            if run_id and not context.is_aborted():
                info = self.get_visual_info(context)
                print(f"[{run_id}... ] {indent}{self.name}: COMPLETED {info}")
                
            return result
        except Exception as e:
            # Soft failure: Log error and continue ONLY IF NOT CRITICAL
            # Phase 1 Nodes (Preprocessing, LID, Translation) are critical
            is_critical = self.name in ["Preprocessing", "Language Detection", "Entity-Aware Translation"]
            
            error_msg = f"{type(e).__name__}: {str(e)}"
            logger.error(f"Node '{self.name}' failed: {error_msg}")
            context.add_error(self.name, error_msg)
            
            if is_critical:
                context.abort(f"Critical Node '{self.name}' failed: {error_msg}")
                if run_id:
                    print(f"[{run_id}... ] {indent}{self.name}: CRITICAL FAILURE - ABORTING")
            else:
                if run_id:
                    print(f"[{run_id}... ] {indent}{self.name}: FAILED (Soft: {error_msg})")
                
            return context

    @abstractmethod
    def process(self, context: PipelineContext) -> PipelineContext:
        """
        Core logic implementation.
        Must mutate context in-place and return it.
        """
        pass

    def ensure_english_content(self, context: PipelineContext) -> str:
        """
        Smart-Node Logic: Ensures English text is available for analysis.
        Follows the "Industrial Safety Net" pattern:
        1. If 'text_translated' exists -> Use it (Silent Skip - Pipeline Mode).
        2. If 'language' is 'en' -> Use raw 'text'.
        3. If missing 'language' -> Detect Language internally.
        4. If not 'en' -> Translate internally Produces 'text_translated' (Standalone Mode).
        """
        # 1. Pipeline Mode: Use existing translation if any node provided it
        if "text_translated" in context and context["text_translated"]:
            return context["text_translated"]

        # 2. English Mode: Use raw text if already identified as English
        if context.get("language") == "en":
             return context.get("text", "")

        # 3. Dynamic LID: Detect if unknown (Standalone Safety)
        if "language" not in context:
            from ..nodes.language_node import LanguageDetectionNode
            # Use process directly to avoid double run log
            LanguageDetectionNode().process(context)
            if context.get("language") == "en":
                 return context.get("text", "")

        # 4. Standalone Mode: Handle Translation on-the-fly
        if context.get("language") != "en" and not context.is_aborted():
            from ..nodes.translation_node import TranslationNode
            # Normalizes context in-place to include 'text_translated'
            TranslationNode(target_lang="en").process(context)
            return context.get("text_translated", context.get("text", ""))

        return context.get("text", "")

class GateNode(Node, ABC):
    """
    Specialized Node for Quality Assessment.
    Calculates a score and may trigger a 'REJECT' signal to abort the pipeline.
    """
    def __init__(self, name: str):
        super().__init__(name)

    def run(self, context: PipelineContext, run_id: str = None, indent: str = "") -> PipelineContext:
        """
        Gate Execution: If evaluation fails thresholds, it sets context to Aborted.
        """
        if run_id:
            print(f"[{run_id}... ] {indent}{self.name}: Evaluating...")

        try:
            context = self._evaluate(context)
            
            if run_id:
                status = "REJECTED" if context.is_aborted() else "PASSED"
                info = self.get_visual_info(context)
                print(f"[{run_id}... ] {indent}{self.name}: {status} {info}")
                
            return context
        except Exception as e:
            error_msg = f"{type(e).__name__}: {str(e)}"
            logger.error(f"Gate '{self.name}' failed: {error_msg}")
            context.add_error(self.name, error_msg)
            if run_id:
                print(f"[{run_id}... ] {indent}{self.name}: PROCESSING ERROR ({error_msg})")
            return context

    @abstractmethod
    def _evaluate(self, context: PipelineContext) -> PipelineContext:
        """
        Logic for scoring and decision making.
        """
        pass

    def process(self, context: PipelineContext) -> PipelineContext:
        # GateNodes use _evaluate instead of process for clarity
        return self._evaluate(context)


class RouterNode(Node, ABC):
    """
    Specialized Node for Routing Decisions.
    Evaluates context and returns a route key that determines which processing path to follow.
    For example: LanguageRouter returns "translate" or "skip_translation".
    """
    def __init__(self, name: str):
        super().__init__(name)
        self.routes_map = {}

    def set_routes(self, routes_map: dict):
        """Set the routes mapping: { "route_key": [list_of_nodes] }"""
        self.routes_map = routes_map

    def run(self, context: PipelineContext, run_id: str = None, indent: str = "") -> PipelineContext:
        """
        Router Execution: Determines route and executes the corresponding nodes.
        Silenced according to reference image visual logging format.
        """
        try:
            route_key = self._route(context)
            context["_last_route"] = route_key

            # Custom behavior for visual logging (Language Router)
            if run_id:
                info = self.get_visual_info(context)
                if info:
                    print(f"[{run_id}... ] {indent}{self.name}: {info}")

            # Execute nodes for the chosen route (no indentation cascade)
            route_nodes = self.routes_map.get(route_key, [])
            for node in route_nodes:
                if context.is_aborted():
                    break
                context = node.run(context, run_id=run_id, indent=indent)

            return context
        except Exception as e:
            error_msg = f"{type(e).__name__}: {str(e)}"
            logger.error(f"Router '{self.name}' failed: {error_msg}")
            context.add_error(self.name, error_msg)
            if run_id:
                print(f"[{run_id}... ] {indent}{self.name}: ROUTING ERROR ({error_msg})")
            return context

    @abstractmethod
    def _route(self, context: PipelineContext) -> str:
        """
        Logic for deciding which route to take.
        Must return a string key matching one of the routes_map keys.
        """
        pass

    def process(self, context: PipelineContext) -> PipelineContext:
        # RouterNodes use _route instead of process
        route_key = self._route(context)
        context["_last_route"] = route_key
        route_nodes = self.routes_map.get(route_key, [])
        for node in route_nodes:
            if context.is_aborted():
                break
            context = node.run(context)
        return context

