import threading
from typing import Any, Dict, Optional

class PipelineContext:
    """
    Mutable state container for the NLP pipeline.
    wraps a dictionary and provides helper methods for safe access and error logging.
    """
    def __init__(self, initial_data: Optional[Dict[str, Any]] = None):
        self._data: Dict[str, Any] = initial_data or {}
        self._lock = threading.Lock()
        self._aborted = False
        if "errors" not in self._data:
            self._data["errors"] = {}

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            self._data[key] = value

    def abort(self, reason: str = "System aborted") -> None:
        """Stops the pipeline execution at the next stage."""
        with self._lock:
            self._aborted = True
            self._data["abort_reason"] = reason

    def is_aborted(self) -> bool:
        with self._lock:
            return self._aborted

    def add_error(self, node_name: str, error_message: str) -> None:
        """Log a soft failure for a specific node."""
        with self._lock:
            if "errors" not in self._data:
                self._data["errors"] = {}
            self._data["errors"][node_name] = error_message

    def has_errors(self) -> bool:
        """Check if any errors have been logged in the current context."""
        with self._lock:
            return len(self._data.get("errors", {})) > 0

    def to_dict(self) -> Dict[str, Any]:
        """Return the raw dictionary state."""
        with self._lock:
            # Inject rejection status for downstream detection
            self._data["rejected"] = self._aborted
            return self._data

    def __getitem__(self, key: str) -> Any:
        with self._lock:
            return self._data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        with self._lock:
            self._data[key] = value

    def __contains__(self, key: str) -> bool:
        with self._lock:
            return key in self._data
