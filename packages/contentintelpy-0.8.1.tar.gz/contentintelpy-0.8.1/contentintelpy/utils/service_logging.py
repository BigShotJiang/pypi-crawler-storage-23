import uuid
import time
from typing import Optional

class ServiceLogger:
    """
    Industrial Service Logger:
    Matches the visual style shown in ContentIntelPy Research Paper.
    Format: [run_id... ] Section Name: Status
    """
    def __init__(self, run_id: Optional[str] = None):
        self.run_id = run_id or uuid.uuid4().hex[:24]
        self._prefix = f"[{self.run_id[:20]}... ]"

    def log(self, message: str, status: Optional[str] = None):
        """Standard log line"""
        if status:
            print(f"{self._prefix} {message}: {status}")
        else:
            print(f"{self._prefix} {message}")

    def item(self, key: str, value: str, indent: int = 2):
        """Indented item with arrow: '  key -> value'"""
        print(f"{self._prefix} {' ' * indent}{key} -> {value}")

    def header(self, title: str):
        """Section header"""
        print(f"\n{self._prefix} {title.upper()}: START")

    def success(self, title: str, details: Optional[str] = None):
        """Completion line"""
        msg = f"{self._prefix} {title.upper()}: COMPLETED"
        if details:
            msg += f" ({details})"
        print(msg)

    def eval(self, name: str, value: str):
        """Evaluation line (e.g. Quality Gate)"""
        print(f"{self._prefix} {name:<25}: {value}")
