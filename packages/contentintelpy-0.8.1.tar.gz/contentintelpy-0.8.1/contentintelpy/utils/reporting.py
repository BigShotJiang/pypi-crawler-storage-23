def print_report(result: dict):
    """
    Industrial Reporting Utility (Phase 4):
    Displays the full contents of a Pipeline result in a professional, 
    bilingual structured format.
    """
    if not result:
        print("! [Reporting] Empty result provided.")
        return

    lang = result.get('language', 'unknown')
    is_multilingual = (lang != 'en' and lang != 'unknown')
    
    print("\n" + "╔" + "═"*78 + "╗")
    print(f"║{'CONTENT INTEL REPORT':^78}║")
    print("╠" + "═"*78 + "╣")
    
    # 1. Base Meta
    def row(label, value_en, value_src=None):
        print(f"║ {label:<15} │ {str(value_en):<60}║")
        if is_multilingual and value_src and value_src != value_en:
            src_label = f"({lang.upper()})"
            print(f"║ {src_label:<15} │ {str(value_src):<60}║")
        print("╟" + "─"*16 + "┼" + "─"*61 + "╢")

    # Header Row
    print(f"║ {'Field':<15} │ {'Bilingual Results':<60}║")
    print("╠" + "═"*16 + "╪" + "═"*61 + "╣")

    # Source Info
    text_snippet = result.get('text', '')[:57] + "..." if len(result.get('text', '')) > 57 else result.get('text', '')
    row("Source Text", text_snippet)
    
    lang_display = f"{lang} (Conf: {result.get('language_score', 0.0):.2f})"
    row("Language", lang_display)
    
    # Insights
    row("Category", result.get('category', 'N/A'), result.get('category_source'))
    
    sentiment_en = result.get('sentiment', 'N/A')
    row("Sentiment", sentiment_en, result.get('sentiment_source'))
    
    # Complex Lists
    entities_en = result.get('entities', [])
    ent_str_en = ", ".join([e.get('text', '') for e in entities_en[:5]]) if entities_en else "None"
    entities_src = result.get('entities_source', [])
    ent_str_src = ", ".join([e.get('text', '') for e in entities_src[:5]]) if entities_src else None
    row("Entities", ent_str_en, ent_str_src)
    
    keywords_en = result.get('keywords', [])
    key_str_en = ", ".join([str(k) for k in keywords_en[:5]]) if keywords_en else "None"
    keywords_src = result.get('keywords_source', [])
    key_str_src = ", ".join([str(k) for k in keywords_src[:5]]) if keywords_src else None
    row("Keywords", key_str_en, key_str_src)
    
    locations_en = result.get('locations', [])
    # If locations are dicts with 'original' field
    if locations_en and isinstance(locations_en[0], dict):
        loc_str_en = ", ".join([l.get('original', '') for l in locations_en[:5]])
    else:
        loc_str_en = ", ".join(locations_en[:5]) if locations_en else "None"
        
    locations_src = result.get('locations_source', [])
    if locations_src and isinstance(locations_src[0], dict):
        loc_str_src = ", ".join([l.get('original', '') for l in locations_src[:5]])
    else:
        loc_str_src = ", ".join(locations_src[:5]) if locations_src else None
    row("Locations", loc_str_en, loc_str_src)

    # Summary
    if result.get('summary'):
        summ_en = result.get('summary')
        summ_en = (summ_en[:57] + "...") if len(summ_en) > 60 else summ_en
        summ_src = result.get('summary_source')
        if summ_src:
            summ_src = (summ_src[:57] + "...") if len(summ_src) > 60 else summ_src
        row("Summary", summ_en, summ_src)

    # Tier info
    tier = result.get('tier', 'N/A')
    tier_label = f"Tier {tier}" if isinstance(tier, int) else tier
    print(f"║ {'Reliability':<15} │ {tier_label:<60}║")
    
    print("╚" + "═"*16 + "╧" + "═"*61 + "╝\n")
