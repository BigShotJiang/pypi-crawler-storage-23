import importlib
import logging

logger = logging.getLogger("contentintelpy.utils")

def ensure_dependency(module_name: str, extra_name: str):
    """
    Attempts to import a module. If it fails, raises an ImportError with a 
    helpful message directing the user to install the appropriate optional extra.
    """
    try:
        return importlib.import_module(module_name)
    except (ImportError, ModuleNotFoundError):
        RED = "\033[91m"
        RESET = "\033[0m"
        msg = f"{RED}Missing optional dependency '{module_name}'. To use this feature, please install it using: pip install \"contentintelpy[{extra_name}]\"{RESET}"
        logger.error(msg)
        # We strip the ANSI codes from the raised exception so it doesn't look messy in logs/tracebacks
        clean_msg = f"Missing optional dependency '{module_name}'. Run: pip install \"contentintelpy[{extra_name}]\""
        raise ImportError(clean_msg) from None
