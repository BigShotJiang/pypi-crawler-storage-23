import os
import warnings
import logging
import sys

def suppress_all_logs():
    """
    Professional log cleaner for production and demos. 
    Suppresses all non-critical logs from Transformers, Torch, and HuggingFace.
    """
    # --- Python warnings ---
    warnings.filterwarnings("ignore")
    warnings.filterwarnings("ignore", category=UserWarning)
    warnings.filterwarnings("ignore", category=FutureWarning)

    # --- Environment Variables ---
    # HuggingFace & Transformers
    os.environ["TRANSFORMERS_NO_ADVISORY_WARNINGS"] = "1"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
    os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
    os.environ["TRANSFORMERS_VERBOSITY"] = "error"
    os.environ["HF_HUB_VERBOSITY"] = "error"
    
    # PyTorch
    os.environ["TORCH_CPP_LOG_LEVEL"] = "ERROR"
    os.environ["TORCH_DISTRIBUTED_DEBUG"] = "OFF"

    # --- Logging levels ---
    logging.getLogger().setLevel(logging.ERROR)

    # Specific noisy libraries
    noisy_libs = [
        "transformers",
        "torch",
        "huggingface_hub",
        "sentence_transformers",
        "gliner",
        "stanza",
        "argostranslate",
        "urllib3",
        "filelock"
    ]
    for lib in noisy_libs:
        logging.getLogger(lib).setLevel(logging.ERROR)

    # Forcefully suppress 'Using `TRANSFORMERS_CACHE` is deprecated'
    # This comes from the library code itself, not just the logger.
    try:
        from transformers import logging as hf_logging
        hf_logging.set_verbosity_error()
    except ImportError:
        pass

    # Special case: Silence stdout/stderr for specific noisy blocks if needed
    # But for a general utility, environment variables are better.
