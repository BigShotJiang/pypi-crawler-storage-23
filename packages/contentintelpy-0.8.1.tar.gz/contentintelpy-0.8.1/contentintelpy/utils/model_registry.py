from .lazy_import import ensure_dependency
import threading
from typing import Any, Optional
import warnings

# Suppress HuggingFace warnings for cleaner logs
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

class ModelRegistry:
    """
    Centralized registry for ML models, synced with Backend Source of Truth.
    Implements:
    - Lazy loading with CUDA/FP16 optimization.
    - CPU-to-GPU safety pattern to bypass meta-tensor issues.
    - Tiered fallback support.
    """
    _instance = None
    _lock = threading.Lock()
    _models = {}

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(ModelRegistry, cls).__new__(cls)
        return cls._instance

    def _get_device(self):
        import torch
        return "cuda" if torch.cuda.is_available() else "cpu"

    def _load_if_missing(self, key: str, loader_func: callable) -> Any:
        if key not in self._models:
            with self._lock:
                if key not in self._models:
                    import torch
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                    self._models[key] = loader_func()
        return self._models[key]

    # --------------------------------------------------------------------------
    # Language Identification (XLM-RoBERTa - Production Grade)
    # --------------------------------------------------------------------------
    def get_language_detector(self):
        def _loader():
            ensure_dependency("transformers", "core")
            from transformers import pipeline
            model_name = "papluca/xlm-roberta-base-language-detection"
            return pipeline("text-classification", model=model_name, device=self._get_device())
        return self._load_if_missing("language_detection", _loader)

    # --------------------------------------------------------------------------
    # Category Classification (BART Large MNLI - Zero Shot)
    # --------------------------------------------------------------------------
    def get_classifier_pipeline(self):
        def _loader():
            ensure_dependency("transformers", "core")
            import torch
            from transformers import AutoModelForSequenceClassification, AutoTokenizer, pipeline
            model_name = "facebook/bart-large-mnli"
            device = self._get_device()
            
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            if device == "cuda":
                model = AutoModelForSequenceClassification.from_pretrained(
                    model_name, torch_dtype=torch.float16, low_cpu_mem_usage=True
                ).to(device).eval()
            else:
                model = AutoModelForSequenceClassification.from_pretrained(model_name, low_cpu_mem_usage=True).eval()
            
            return pipeline("zero-shot-classification", model=model, tokenizer=tokenizer, device=device if device=="cpu" else 0)
        return self._load_if_missing("classification_zero_shot", _loader)

    # --------------------------------------------------------------------------
    # Translation (NLLB-200-Distilled 600M — Fast/High Fidelity)
    # --------------------------------------------------------------------------
    def get_translation_model(self):
        def _loader():
            ensure_dependency("transformers", "core")
            ensure_dependency("torch", "core")
            import torch
            from transformers import AutoModelForSeq2SeqLM, AutoTokenizer, pipeline
            model_name = "facebook/nllb-200-distilled-600M"
            device = self._get_device()
            
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            if device == "cuda":
                model = AutoModelForSeq2SeqLM.from_pretrained(
                    model_name, torch_dtype=torch.float16, low_cpu_mem_usage=True
                ).to(device).eval()
            else:
                model = AutoModelForSeq2SeqLM.from_pretrained(model_name, low_cpu_mem_usage=True).eval()
            
            # Also provide a pipeline for simple calls
            translator = pipeline("translation", model=model, tokenizer=tokenizer, device=device if device=="cpu" else 0)
            
            return {"model": model, "tokenizer": tokenizer, "device": device, "translator": translator}
        return self._load_if_missing("translation_nllb", _loader)

    def get_nllb_code(self, lang_code: str) -> str:
        """Maps ISO 639-1 to NLLB codes."""
        mapping = {
            "en": "eng_Latn", "hi": "hin_Deva", "fr": "fra_Latn", "de": "deu_Latn",
            "es": "spa_Latn", "it": "ita_Latn", "pt": "por_Latn", "ru": "rus_Cyrl",
            "zh": "zho_Hans", "ja": "jpn_Jpan", "ko": "kor_Hang", "ar": "ara_Arab"
        }
        return mapping.get(lang_code.lower(), "eng_Latn")

    # --------------------------------------------------------------------------
    # NER (GLiNER Large v2.1)
    # --------------------------------------------------------------------------
    def get_ner_model(self):
        return self.get_gliner_model()

    def get_gliner_model(self):
        def _loader():
            ensure_dependency("gliner", "ner")
            from gliner import GLiNER
            device = self._get_device()
            model = GLiNER.from_pretrained("urchade/gliner_large-v2.1")
            if device == "cuda":
                model = model.to(device).half()
            return model
        return self._load_if_missing("ner_gliner", _loader)

    def get_spacy_model(self):
        def _loader():
            import spacy
            try:
                return spacy.load("en_core_web_sm")
            except:
                return None
        return self._load_if_missing("spacy_fallback", _loader)

    # --------------------------------------------------------------------------
    # Location Helpers
    # --------------------------------------------------------------------------
    def get_continent_from_country(self, country: str) -> str:
        """Simple heuristic for paper §3.1.G mapping."""
        asia = ["India", "China", "Japan", "Korea", "Vietnam", "Thailand"]
        europe = ["UK", "France", "Germany", "Italy", "Spain"]
        americas = ["USA", "Canada", "Brazil", "Mexico"]
        for c in asia: 
            if c.lower() in country.lower(): return "Asia"
        for c in europe:
            if c.lower() in country.lower(): return "Europe"
        for c in americas:
            if c.lower() in country.lower(): return "Americas"
        return "Unknown"

    # --------------------------------------------------------------------------
    # Summarization (BART-Large-CNN)
    # --------------------------------------------------------------------------
    def get_summarization_model(self):
        def _loader():
            ensure_dependency("transformers", "core")
            import torch
            from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
            model_name = "facebook/bart-large-cnn"
            device = self._get_device()
            
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            if device == "cuda":
                model = AutoModelForSeq2SeqLM.from_pretrained(
                    model_name, torch_dtype=torch.float16, low_cpu_mem_usage=True
                ).to(device).eval()
            else:
                model = AutoModelForSeq2SeqLM.from_pretrained(model_name, low_cpu_mem_usage=True).eval()
            
            return {"model": model, "tokenizer": tokenizer, "device": device}
        return self._load_if_missing("summarization_bart", _loader)

    # --------------------------------------------------------------------------
    # Summarization Fallback (google/mt5-small — Multilingual/English)
    # --------------------------------------------------------------------------
    def get_mt5_model(self):
        def _loader():
            ensure_dependency("transformers", "core")
            import torch
            from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
            model_name = "google/mt5-small"
            device = self._get_device()

            tokenizer = AutoTokenizer.from_pretrained(model_name)
            if device == "cuda":
                model = AutoModelForSeq2SeqLM.from_pretrained(
                    model_name, torch_dtype=torch.float16, low_cpu_mem_usage=True
                ).to(device).eval()
            else:
                model = AutoModelForSeq2SeqLM.from_pretrained(model_name, low_cpu_mem_usage=True).eval()

            return {"model": model, "tokenizer": tokenizer, "device": device}
        return self._load_if_missing("summarization_mt5", _loader)

    # --------------------------------------------------------------------------
    # Keyword Extraction (T5-Keywords)
    # --------------------------------------------------------------------------
    def get_keyword_model(self):
        def _loader():
            ensure_dependency("transformers", "core")
            from transformers import T5Tokenizer, T5ForConditionalGeneration
            model_name = "Voicelab/vlt5-base-keywords"
            device = self._get_device()
            
            tokenizer = T5Tokenizer.from_pretrained(model_name)
            model = T5ForConditionalGeneration.from_pretrained(model_name).to(device).eval()
            
            return {"model": model, "tokenizer": tokenizer, "device": device}
        return self._load_if_missing("keywords_t5", _loader)

    def get_keybert_model(self):
        def _loader():
            ensure_dependency("keybert", "keywords")
            from keybert import KeyBERT
            return KeyBERT()
        return self._load_if_missing("keybert_fallback", _loader)

    # --------------------------------------------------------------------------
    # Sentiment (RoBERTa Latest)
    # --------------------------------------------------------------------------
    def get_sentiment_model(self):
        def _loader():
            ensure_dependency("transformers", "core")
            import torch
            from transformers import AutoTokenizer, AutoModelForSequenceClassification
            model_name = "cardiffnlp/twitter-roberta-base-sentiment-latest"
            device = self._get_device()
            
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            if device == "cuda":
                model = AutoModelForSequenceClassification.from_pretrained(
                    model_name, use_safetensors=True, torch_dtype=torch.float16, low_cpu_mem_usage=True
                ).to(device).eval()
            else:
                model = AutoModelForSequenceClassification.from_pretrained(
                    model_name, use_safetensors=True, low_cpu_mem_usage=True
                ).eval()
            
            return {"model": model, "tokenizer": tokenizer, "device": device}
        return self._load_if_missing("sentiment_roberta", _loader)

    # --------------------------------------------------------------------------
    # Geocoding
    # --------------------------------------------------------------------------
    def get_geocoder(self):
        def _loader():
            from geopy.geocoders import Nominatim
            from geopy.extra.rate_limiter import RateLimiter
            geolocator = Nominatim(user_agent="contentintelpy_v2")
            geocode_fn = RateLimiter(geolocator.geocode, min_delay_seconds=1)
            return {"geolocator": geolocator, "geocode": geocode_fn}
        return self._load_if_missing("geocoder", _loader)

# Global accessor
registry = ModelRegistry()
