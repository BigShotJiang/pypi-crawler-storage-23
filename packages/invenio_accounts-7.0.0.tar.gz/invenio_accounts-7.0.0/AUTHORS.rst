..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Contributors
============

- Alexander Ioannidis
- Alizee Pace
- Bruno Cuc
- Chiara Bigarella
- Diego Rodriguez
- Dinos Kousidis
- Eamonn Maguire
- Esteban J. G. Gabancho
- Harri Hirvonsalo
- Harris Tzovanakis
- Jacopo Notarstefano
- Javier Delgado
- Javier Martin Montull
- Jiri Kuncar
- Krzysztof Nowak
- Lars Holm Nielsen
- Leonardo Rossi
- Liam Kirsh
- Nicolas Harraudeau
- Odd Magnus Trondrud
- Orestis Melkonian
- Rémi Ducceschi
- Sami Hiltunen
- Sebastian Witowski
- Tibor Simko
- Maximilian Moser
- Mojib Wali
