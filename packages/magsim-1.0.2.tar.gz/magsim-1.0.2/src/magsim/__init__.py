from magsim.engine.logging import configure_logging

configure_logging()
