"""AuthFort repositories — database query functions.

Each module provides async functions that operate on SQLAlchemy models via AsyncSession.
"""
