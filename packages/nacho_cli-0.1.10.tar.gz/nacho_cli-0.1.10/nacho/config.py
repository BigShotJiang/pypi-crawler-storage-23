import json
import os
from pathlib import Path

import yaml

DEFAULT_API_URL = "https://nacho.bot/api"
CREDENTIALS_DIR = Path.home() / ".nacho"
CREDENTIALS_FILE = CREDENTIALS_DIR / "credentials"
GLOBAL_CONFIG_FILE = CREDENTIALS_DIR / "config.json"


def get_api_url() -> str:
    return os.environ.get("NACHO_API_URL", DEFAULT_API_URL)


def save_token(token: str) -> None:
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_FILE.write_text(token)
    CREDENTIALS_FILE.chmod(0o600)


def load_token() -> str | None:
    if CREDENTIALS_FILE.exists():
        return CREDENTIALS_FILE.read_text().strip()
    return None


def clear_token() -> None:
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


def load_config(project_dir: Path | None = None) -> dict:
    """Load config: project .nacho/config.json overrides ~/.nacho/config.json."""
    config: dict = {}
    if GLOBAL_CONFIG_FILE.exists():
        try:
            config.update(json.loads(GLOBAL_CONFIG_FILE.read_text()))
        except (json.JSONDecodeError, OSError):
            pass
    project_cfg = (project_dir or Path(".")) / ".nacho" / "config.json"
    if project_cfg.exists():
        try:
            config.update(json.loads(project_cfg.read_text()))
        except (json.JSONDecodeError, OSError):
            pass
    return config


def save_config(data: dict, local: bool = False, project_dir: Path | None = None) -> None:
    """Write config. local=True writes to .nacho/config.json in cwd."""
    if local:
        cfg_dir = (project_dir or Path(".")) / ".nacho"
        cfg_dir.mkdir(parents=True, exist_ok=True)
        cfg_file = cfg_dir / "config.json"
        existing: dict = {}
        if cfg_file.exists():
            try:
                existing = json.loads(cfg_file.read_text())
            except (json.JSONDecodeError, OSError):
                pass
        existing.update(data)
        cfg_file.write_text(json.dumps(existing, indent=2) + "\n")
    else:
        CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
        existing = {}
        if GLOBAL_CONFIG_FILE.exists():
            try:
                existing = json.loads(GLOBAL_CONFIG_FILE.read_text())
            except (json.JSONDecodeError, OSError):
                pass
        existing.update(data)
        GLOBAL_CONFIG_FILE.write_text(json.dumps(existing, indent=2) + "\n")
        GLOBAL_CONFIG_FILE.chmod(0o600)


def get_provider(project_dir: Path | None = None) -> str:
    return load_config(project_dir).get("provider", "")


def load_context_config(path: str = ".") -> dict:
    """Load .nacho.yml from the given directory."""
    config_path = Path(path) / ".nacho.yml"
    if not config_path.exists():
        return {}
    with open(config_path) as f:
        return yaml.safe_load(f) or {}


NACHO_DIR = Path(".nacho")
CONTEXTS_FILE = NACHO_DIR / "contexts.yml"


def load_tracked_contexts(path: str = ".") -> dict:
    """Read .nacho/contexts.yml and return dict keyed by file path."""
    contexts_file = Path(path) / CONTEXTS_FILE
    if not contexts_file.exists():
        return {}
    with open(contexts_file) as f:
        data = yaml.safe_load(f) or {}
    return data.get("contexts", {})


def save_tracked_context(file_path: str, metadata: dict, path: str = ".") -> None:
    """Upsert one entry into .nacho/contexts.yml, creating .nacho/ dir if needed."""
    nacho_dir = Path(path) / NACHO_DIR
    contexts_file = Path(path) / CONTEXTS_FILE

    nacho_dir.mkdir(parents=True, exist_ok=True)

    existing = {}
    if contexts_file.exists():
        with open(contexts_file) as f:
            existing = yaml.safe_load(f) or {}

    contexts = existing.get("contexts", {})
    contexts[file_path] = metadata

    with open(contexts_file, "w") as f:
        yaml.dump({"contexts": contexts}, f, default_flow_style=False)
