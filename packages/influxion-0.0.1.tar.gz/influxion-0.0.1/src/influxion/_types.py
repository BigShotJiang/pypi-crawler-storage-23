"""TypedDict parameter types for the Influxion SDK.

These types are provided as a convenience for callers who want to construct
parameter dicts before passing them to the client. The client methods also
accept individual keyword arguments directly.
"""

from __future__ import annotations

from typing import Any, TypedDict


class _CreateSessionRequired(TypedDict):
    name: str
    project_id: str
    agent_id: str


class CreateSessionParams(_CreateSessionRequired, total=False):
    """Parameters accepted by :meth:`~influxion.InfluxionClient.create_session`."""

    tags: list[str]
    metadata: dict[str, Any]


class UpdateSessionParams(TypedDict, total=False):
    """Parameters accepted by :meth:`~influxion.InfluxionClient.update_session`."""

    success: bool
    failure_message: str
    tags: list[str]
    metadata: dict[str, Any]


class _CreateArtifactRequired(TypedDict):
    session_id: str
    artifact_name: str
    artifact: str


class CreateArtifactParams(_CreateArtifactRequired, total=False):
    """Parameters accepted by :meth:`~influxion.InfluxionClient.create_session_artifact`."""

    artifact_type: str  # "text"; defaults to "text"
    tags: list[str]
    metadata: dict[str, Any]
