# Influxion Python SDK

Instrument your agents with the Influxion SDK to capture sessions and artifacts for evaluation.

## Installation

Install from PyPI:

```bash
pip install -U influxion
```

Or, if installing from source:

```bash
pip install -e ".[dev]"
```

## Quickstart

```python
from influxion import InfluxionClient

client = InfluxionClient(
    api_key="sk-...",   # or set INFLUXION_API_KEY environment variable
)

session_id = client.create_session(
    name="weekly-report-run",
    project_id="<your-project-id>",
    agent_id="report-agent",
    tags=["weekly"],
    metadata={"env": "prod"},
)

try:
    report = run_my_agent()

    client.create_session_artifact(
        session_id=session_id,
        artifact_name="report",
        artifact=report,
        artifact_type="text",
    )

    client.end_session(session_id, success=True)

except Exception as e:
    client.end_session(session_id, success=False, failure_message=str(e))
    raise
```

## Async Usage

```python
from influxion import AsyncInfluxionClient

async with AsyncInfluxionClient() as client:
    session_id = await client.create_session(
        name="my-run",
        project_id="<your-project-id>",
        agent_id="my-agent",
    )
    await client.create_session_artifact(
        session_id=session_id,
        artifact_name="output",
        artifact="...",
    )
    await client.end_session(session_id, success=True)
```

## Configuration

| Parameter | Environment variable | Default |
|-----------|---------------------|---------|
| `api_key` | `INFLUXION_API_KEY` | — (required) |
| `base_url` | `INFLUXION_BASE_URL` | `https://api.influxion.io/v1` |
| `fail_silently` | — | `True` |

`fail_silently=True` (default): call-time errors are logged and methods return `None`
rather than raising. Set `fail_silently=False` during development to surface errors
immediately. `AuthenticationError` at construction always raises regardless.

## Running Tests

```bash
pip install -e ".[dev]"
pytest
```
