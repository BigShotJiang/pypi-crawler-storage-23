"""Shared fixtures for Influxion SDK tests."""

import pytest

from influxion import AsyncInfluxionClient, InfluxionClient

BASE_URL = "https://api.influxion.io/v1"
TEST_API_KEY = "sk-test-key-1234"
TEST_PROJECT_ID = "00000000-0000-0000-0000-000000000001"
TEST_SESSION_ID = "00000000-0000-0000-0000-000000000002"
TEST_ARTIFACT_ID = "00000000-0000-0000-0000-000000000003"


@pytest.fixture
def client():
    """Sync client with fail_silently=False (errors raise in tests)."""
    c = InfluxionClient(api_key=TEST_API_KEY, fail_silently=False)
    yield c
    c.close()


@pytest.fixture
def silent_client():
    """Sync client with fail_silently=True."""
    c = InfluxionClient(api_key=TEST_API_KEY, fail_silently=True)
    yield c
    c.close()


@pytest.fixture
def async_client():
    """Async client with fail_silently=False."""
    return AsyncInfluxionClient(api_key=TEST_API_KEY, fail_silently=False)


@pytest.fixture
def silent_async_client():
    """Async client with fail_silently=True."""
    return AsyncInfluxionClient(api_key=TEST_API_KEY, fail_silently=True)
