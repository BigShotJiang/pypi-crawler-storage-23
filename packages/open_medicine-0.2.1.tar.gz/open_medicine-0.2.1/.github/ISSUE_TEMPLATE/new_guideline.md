---
name: Feature Request — New Guideline
about: Propose adding a new clinical guideline to the retrieval engine
title: "[GUIDELINE] "
labels: enhancement, good first issue
assignees: ''
---

## Guideline Name

(e.g., ESC 2023 Heart Failure Guidelines)

## Organization

(e.g., ESC, AHA, KDIGO, NICE, WHO)

## Primary Reference

- **DOI:** `10.xxxx/...`
- **Year:** 

## Proposed Sections

List the sections to curate from this guideline:

1. (e.g., diagnosis)
2. (e.g., pharmacological_treatment)
3. (e.g., device_therapy)

## Topic Keywords

List keywords for search matching:

- (e.g., heart failure, HFrEF, HFpEF, ejection fraction, SGLT2, sacubitril)

## Why This Guideline?

How does this guideline complement the existing calculator/guideline library?
