# Discharge Criteria for Community Acquired Pneumonia — BTS 2009

## Clinical Stability for Discharge

Patients hospitalized with CAP may be considered for discharge when ALL of the following criteria are met:

1. **Temperature < 37.5°C** for at least 24 hours.
2. **Heart rate < 100 bpm.**
3. **Respiratory rate < 24 breaths/min.**
4. **Systolic BP ≥ 90 mmHg** (without vasopressor support).
5. **SpO2 ≥ 90%** on room air (or at baseline for patients on home oxygen).
6. **Adequate oral intake** and functioning GI tract.
7. **Normal mental status** (return to baseline cognitive function).

## Pre-Discharge Checklist

- Switch from IV to oral antibiotics completed at least 24 hours before discharge.
- Outpatient antibiotic course prescribed to complete the recommended duration.
- Chest X-ray follow-up arranged at 6 weeks (to confirm radiographic resolution and exclude underlying malignancy, especially in patients > 50 years or smokers).
- Smoking cessation advice documented.
- Pneumococcal and influenza vaccination status reviewed and offered if indicated.

## Follow-Up

- **Clinical review:** GP follow-up within 1 week of discharge.
- **Radiographic follow-up:** CXR at 6 weeks. Failure to resolve should prompt investigation for underlying pathology (bronchial carcinoma, TB, immunodeficiency).
- **Readmission risk factors:** Multilobar involvement, pleural effusion, significant comorbidities, poor social support. Consider extended observation or early follow-up for these patients.
