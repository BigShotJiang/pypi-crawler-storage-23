# Antibiotic Therapy for Community Acquired Pneumonia — BTS 2009

## General Principles

- Start empirical antibiotics as soon as CAP diagnosis is made (within 4 hours of admission for inpatients).
- Choice of agent depends on severity (CURB-65) and local resistance patterns.
- Always obtain blood cultures and sputum culture before starting antibiotics in hospitalized patients.

## Recommended Regimens & Actionable Dosing

### Low Severity (CURB-65 0–1, outpatient)
- **First-line:** Amoxicillin 500 mg TDS orally for 5 days.
- **Penicillin allergy:** Doxycycline 200 mg loading dose then 100 mg OD, or clarithromycin 500 mg BD.

### Moderate Severity (CURB-65 2, inpatient ward)
- **First-line:** Amoxicillin 500 mg–1 g TDS orally or IV **PLUS** clarithromycin 500 mg BD orally.
- **Penicillin allergy:** Levofloxacin 500 mg OD or moxifloxacin 400 mg OD (monotherapy).

### High Severity (CURB-65 3–5, inpatient/ICU)
- **First-line:** Co-amoxiclav 1.2 g TDS IV **PLUS** clarithromycin 500 mg BD IV.
- **Alternative:** Ceftriaxone 2 g OD IV **PLUS** clarithromycin 500 mg BD IV.
- **Penicillin allergy:** Levofloxacin 500 mg BD IV.
- **Legionella suspected:** Add levofloxacin or consider monotherapy with levofloxacin.

## Escalation and Treatment Failure
- **Definition of Non-Response:** Failure to improve (respiratory rate, oxygenation, fever) after 48-72 hours of appropriate therapy.
- **Actionable Steps for Non-Response:**
  1. Re-evaluate diagnosis (Is it PE? Heart failure? organizing pneumonia?).
  2. Broaden antibiotic coverage (consider Pseudomonas or MRSA risk factors like recent hospitalization or IV drug use).
  3. Image (Repeat CXR or CT Chest) to rule out complications like Empyema or Lung Abscess.
  4. Escalate care (transfer to ICU for ventilatory support if CURB-65 rises).

## Duration of Therapy & Step-down

- **Uncomplicated low-severity CAP:** 5–7 days (extend if slow response).
- **Moderate to high severity CAP:** 7–10 days.
- **Legionella pneumonia:** 14–21 days.
- Extend if slow clinical response, empyema, lung abscess, or Staphylococcus aureus bacteremia.

### IV to Oral Switch Criteria
Switch from IV to oral antibiotics when ALL of the following are met (usually 48-72h):
1. Temperature < 37.5°C for 24 hours.
2. Clinically improving (respiratory rate < 24, SpO2 > 92% on room air).
3. Functioning GI tract with reliable oral intake.
