# Nephrology Referral Criteria — KDIGO 2024

## When to Refer

Patients with CKD should be referred to nephrology when any of the following are present:

### Mandatory Referral (Grade 1B)
- **eGFR < 30 mL/min/1.73m² (G4-G5):** For preparation of renal replacement therapy and multidisciplinary CKD care.
- **Persistent significant albuminuria:** ACR ≥ 300 mg/g (A3) despite optimized RAS blockade.
- **Acute kidney injury (AKI):** Sudden decline in eGFR > 25% from baseline.
- **Unexplained CKD progression:** Sustained decline in eGFR > 5 mL/min/1.73m² per year.

### Consider Referral
- **Refractory hypertension:** Blood pressure above target despite ≥ 3 antihypertensives including a diuretic.
- **Persistent electrolyte abnormalities:** Hyperkalemia, metabolic acidosis, or hyperphosphatemia resistant to standard management.
- **Recurrent nephrolithiasis:** Especially with associated CKD progression.
- **Hereditary kidney disease:** Suspected polycystic kidney disease, Alport syndrome, or Fabry disease.

## Multidisciplinary Care

For patients with eGFR < 30, a multidisciplinary CKD clinic (nephrologist, dietitian, social worker, access surgeon) is recommended to:
1. Choose modality: hemodialysis, peritoneal dialysis, or preemptive transplant.
2. Establish vascular access or peritoneal catheter well before anticipated dialysis start.
3. Optimize nutrition, anemia management (ESAs, IV iron), and bone-mineral metabolism (phosphate binders, vitamin D).
