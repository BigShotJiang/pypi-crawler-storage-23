# Pre-Test Probability of Pulmonary Embolism — Wells PS et al. 2000

## The Wells Clinical Model for PE

The Wells score is a clinical prediction rule used to categorize a patient's pre-test probability of having a pulmonary embolism (PE). The model assigns points based on the presence of seven key clinical features.

### Clinical Criteria and Point Values

- **Clinical signs and symptoms of DVT**: 3.0 points
  *(minimum of leg swelling and pain with palpation of the deep veins)*
- **An alternative diagnosis is less likely than PE**: 3.0 points
- **Heart rate > 100 beats per minute**: 1.5 points
- **Immobilization for more than 3 days or surgery in the previous 4 weeks**: 1.5 points
- **Previous objectively diagnosed PE or DVT**: 1.5 points
- **Hemoptysis**: 1.0 point
- **Malignancy**: 1.0 point
  *(on treatment, treated in the last 6 months, or palliative)*

These points are summed to generate the total Wells Score, which is then used to risk-stratify the patient and guide further diagnostic testing (e.g., D-dimer vs. direct imaging).

> **OpenMedicine Calculator:** `calculate_wells_pe` — available via MCP for automated scoring.
