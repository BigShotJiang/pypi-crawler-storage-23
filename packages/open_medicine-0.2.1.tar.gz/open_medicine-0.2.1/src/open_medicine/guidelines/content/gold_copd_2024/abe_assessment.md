# ABE Assessment Tool — GOLD 2024

## Exacerbation Risk Assessment

Exacerbation risk is determined by exacerbation history in the past year:
- **Low risk:** 0 or 1 moderate exacerbations (not leading to hospital admission)
- **High risk:** ≥ 2 moderate exacerbations OR ≥ 1 exacerbation leading to hospital admission

## Symptom Burden Assessment

Symptom burden is evaluated using:
- **Modified Medical Research Council (mMRC)** dyspnea scale (0-4)
- **COPD Assessment Test (CAT)** (0-40)

- **Low symptoms:** mMRC 0-1 OR CAT < 10
- **High symptoms:** mMRC ≥ 2 OR CAT ≥ 10

## ABE Groups

Patients are categorized to guide initial pharmacotherapy:

| Group | Exacerbation Risk | Symptom Burden |
| :--- | :--- | :--- |
| **Group A** | Low (0-1 moderate exacerbations) | Low (mMRC 0-1 or CAT < 10) |
| **Group B** | Low (0-1 moderate exacerbations) | High (mMRC ≥ 2 or CAT ≥ 10) |
| **Group E** | High (≥ 2 moderate OR ≥ 1 hospitalization) | Any symptom level |

> **OpenMedicine Calculator:** `calculate_gold_copd` — available via MCP to calculate the combined GOLD COPD assessment.
