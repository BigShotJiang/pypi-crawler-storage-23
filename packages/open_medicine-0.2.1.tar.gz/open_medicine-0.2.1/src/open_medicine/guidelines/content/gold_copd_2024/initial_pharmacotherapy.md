# Initial Pharmacological Treatment — GOLD 2024

## Recommendations by ABE Group

Initial pharmacological treatment should be based on the individual's ABE assessment group:

### Group A
- **Initial Therapy:** Bronchodilator
- **Drug Examples:** 
  - **SABA:** Albuterol (90 mcg) 2 puffs q4-6h prn
  - **LABA:** Salmeterol (50 mcg) 1 inhalation BID OR Indacaterol (75 mcg) 1 inhalation daily
  - **LAMA:** Tiotropium (18 mcg) 1 inhalation daily
- **Details:** Long-acting bronchodilators (LABA or LAMA) are typically preferred for daily symptom relief over short-acting ones, except for patients with very occasional breathlessness. Continue treatment if symptomatic benefit is documented.

### Group B
- **Initial Therapy:** LABA + LAMA
- **Drug Combinations:**
  - Umeclidinium/Vilanterol (62.5/25 mcg) 1 inhalation daily
  - Tiotropium/Olodaterol (2.5/2.5 mcg) 2 inhalations daily
  - Glycopyrrolate/Formoterol (9/4.8 mcg) 2 inhalations BID
- **Details:** Dual bronchodilator therapy is the preferred initial choice. It provides superior bronchodilation and symptom improvement compared to monotherapy. If severe adherence issues exist, monotherapy can be considered, though combination is strongly preferred.

### Group E
- **Initial Therapy:** LABA + LAMA
- **Consider ICS addition:** Consider LABA + LAMA + ICS (Inhaled Corticosteroid) if blood eosinophils ≥ 300 cells/µL.
  - **Triple Therapy Example:** Fluticasone/Umeclidinium/Vilanterol (100/62.5/25 mcg) 1 inhalation daily.
- **Details:** Triple therapy should only be considered for patients with a documented history of exacerbations AND elevated eosinophils (≥300).
- **Contraindication:** ICS monotherapy is strictly contraindicated in COPD due to lack of efficacy and increased risk of pneumonia.

## Follow-up and Escalation
- **Assessment Interval:** Assess response 2-6 weeks after initiation or change in therapy.
- **If Symptoms Persist (Dyspnea):** Ensure proper inhaler technique and adherence. Consider changing inhaler device or active molecules within same class.
- **If Exacerbations Persist (despite LABA/LAMA):** 
  - Check eosinophils. Add ICS if ≥ 300 cells/µL.
  - If eosinophils < 300 cells/µL, consider adding Roflumilast (in patients with chronic bronchitis and FEV1 < 50%) or Azithromycin (primarily in former smokers).
