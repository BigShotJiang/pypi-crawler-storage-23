# Rate Control in Atrial Fibrillation — ACC/AHA 2023

## General Principles

Rate control is recommended as the initial strategy for most patients with AF, particularly those who are asymptomatic or minimally symptomatic.

## Target Heart Rate

- **Lenient rate control** (resting HR < 110 bpm) is a reasonable initial approach (Class IIa).
- **Strict rate control** (resting HR < 80 bpm) should be considered if symptoms persist despite lenient control or if tachycardia-induced cardiomyopathy develops.

## First-Line Agents & Clinical Caveats

*Note: Specific drug dosing should be adjusted based on renal function, blood pressure, and formulation (IR vs ER).*

- **Beta-blockers** (metoprolol, bisoprolol, atenolol, carvedilol):
  - **Indication:** Preferred in patients with prior Myocardial Infarction (MI) or Heart Failure with reduced Ejection Fraction (HFrEF).
  - **Caveat:** Avoid in acute decompensated heart failure or severe bronchospastic airway disease.
- **Non-dihydropyridine calcium channel blockers** (diltiazem, verapamil):
  - **Indication:** Preferred in patients with COPD/asthma where beta-blockers may be problematic.
  - **Contraindication:** Strictly contraindicated in patients with HFrEF (LVEF < 40%) due to negative inotropic effects.
- **Digoxin:** 
  - **Indication:** May be added as a second-line agent for rate control when beta-blockers or CCBs alone are insufficient.
  - **Caveat:** Should not be used as monotherapy for active rate control (only reduces resting heart rate, not exertional heart rate). Requires monitoring for toxicity.

## Special Populations & Escalation

- **HFrEF (LVEF < 40%):** Use beta-blockers and/or digoxin only. **Avoid non-DHP CCBs.**
- **Pre-excitation (WPW):** Avoid AV nodal blocking agents (beta-blockers, CCBs, digoxin). Refer for urgent catheter ablation of accessory pathway.
- **Acute rate control:** IV beta-blockers (e.g., metoprolol 2.5-5 mg IV over 2 min) or IV diltiazem (e.g., 0.25 mg/kg IV over 2 min) for rapid ventricular response. Amiodarone IV if hemodynamically unstable.
- **Refractory Rate Control:** If combined pharmacological therapy fails to control rate/symptoms, consider AV node ablation with permanent pacemaker insertion (ablate and pace strategy).
