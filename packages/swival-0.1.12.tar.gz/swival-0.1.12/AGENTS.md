# Swival Project Conventions

Use uv as the package manager to run python.

This file documents patterns applied consistently across the codebase that may not be obvious to an AI agent.

## Error Handling

- **Tool errors return strings**, not exceptions — all tools return `"error: <message>"` on failure, detected with `result.startswith("error:")`.
- **Library code raises exceptions**: `AgentError` for runtime failures and `ConfigError` (its subclass) for configuration issues; both are defined in `report.py`, not `config.py`.

## Return Value Formats

- **Tools always return strings**; `think`, `todo`, and `snapshot` return JSON strings on success (parse with `json.loads()`), all other tools return plain text.
- **`edit.py:replace()` raises `ValueError`** with messages `"not found"`, `"multiple matches"`, `"no changes"`, or `"old_string must not be empty"`; `tools.py` catches these and converts them to `"error: ..."` strings, so direct tests of `replace()` use `pytest.raises(ValueError)` while tool-dispatch callers see the `"error:"` prefix.

## Output Channels

- **stdout is exclusively the final answer** — never print diagnostics there.
- **All diagnostics go to stderr** via the `fmt` module (`rich.Console(stderr=True)`); use `fmt.info()`, `fmt.warning()`, `fmt.error()` — never `print()`.

## Exit Codes

- `0` = success (agent produced answer), `1` = error (`AgentError` raised), `2` = exhausted (max turns reached without answer).

## Limits and Thresholds

- **Output truncation**: `MAX_OUTPUT_BYTES = 50 * 1024` (50 KB) caps tool results; `MAX_LINE_LENGTH = 2000` characters truncates individual lines.

## Configuration

- **Precedence**: CLI args > project `swival.toml` > global `~/.config/swival/config.toml` > defaults.
- **Unknown config keys warn but don't error**; they are stripped after printing a warning to stderr.
- **Key inversions in `config_to_session_kwargs()`**: `no_read_guard → read_guard`, `no_history → history`, `quiet → verbose` (all booleans inverted).

## State Objects

- **Common pattern**: `ThinkingState`, `TodoState`, `SnapshotState`, and `FileAccessTracker` all implement `reset()` (called by REPL `/clear`); the first three also implement `summary_line() -> str | None` (returns `None` if unused) and accept `verbose: bool = False` as a constructor parameter.
- **`.process(args: dict) -> str`**: `ThinkingState`, `TodoState`, and `SnapshotState` share this dispatch interface — validate input, update state, return a JSON string or `"error: ..."`.

## Messages

- **Message accessor helpers**: always use `_msg_get()`, `_msg_role()`, `_msg_content()`, `_msg_tool_calls()`, `_msg_tool_call_id()`, `_msg_name()` from `_msg.py` — never index messages directly, as they can be `dict` or provider response namespace objects.
- **Mutated in place**: `run_agent_loop()` modifies the messages list directly; compaction replaces contents with `messages[:] = ...` to preserve the reference.

## Data Structures

- **The `_UNSET` sentinel** (defined in `config.py`) distinguishes "CLI flag not provided" from `False`/`None`; it appears **only** in the argparse layer and is swept to real defaults by `apply_config_to_args()` — never in `Session` or downstream code.

## MCP Integration

- **Tool namespacing**: MCP tools are prefixed `mcp__{server_name}__{sanitized_tool_name}`; `dispatch()` routes any name starting with `mcp__` to the MCP manager.
- **Degraded servers**: once a server fails a call it is marked degraded and all subsequent calls return an error immediately without contacting the server.

## Testing

- **Mock LLM messages**: use `types.SimpleNamespace` with `.content`, `.role`, `.tool_calls`; tool call objects need `.id` and `.function` (a `SimpleNamespace` with `.name` and `.arguments`).
- **Direct tool testing**: import `_read_file`, `_write_file`, `_edit_file` from `tools.py` and call with `base_dir=str(tmp_path)`; state objects are tested directly without the agent loop.
- **Session testing**: construct `Session(base_dir=str(tmp_path), history=False)`, then `monkeypatch.setattr(agent, "call_llm", stub)` and `monkeypatch.setattr(agent, "discover_model", lambda *a: ("test-model", None))`.

## Public API

- **Exports** from `__init__.py`: `swival.run()`, `Session`, `Result`, `AgentError`, `ConfigError`.
- **`Session.run()`** is single-shot (fresh state each call); **`Session.ask()`** is multi-turn (shared state); **`Session.reset()`** clears only conversation state — setup is cached and not re-run.
- **`Session` is a context manager**: `__exit__` shuts down the MCP manager; always use `with Session(...) as s:` when MCP servers are configured.
- **`Result`** dataclass fields: `answer: str | None`, `exhausted: bool`, `messages: list[dict]`, `report: dict | None`.

## Runtime State

- **`.swival/` directory** holds all runtime state: `HISTORY.md` (Q&A log), `todo.md` (task list), `repl_history`, `trash/` (soft-deleted files), `cmd_output_*.txt` (auto-deleted after 600 s).
- **Path safety**: functions writing to `.swival/` use a `_safe_*_path()` helper (see `_safe_todo_path()` in `todo.py`, `_safe_history_path()` in `agent.py`) that calls `.resolve()` and `is_relative_to(base)` to block symlink escapes; follow this pattern for any new persistence.
