# LOG

## 2026-02-28

**User asked:** Implement the snapshot feature from `plans/final.md`.

**What I did:** Full implementation of the proactive context collapse feature:

- Created `swival/snapshot.py` — SnapshotState class with save/restore/cancel/status actions, implicit checkpoint resolution (backward scan for user messages or previous restore boundaries), dirty scope tracking (READ_ONLY_TOOLS allowlist), history with prompt injection, and collapse semantics (synthetic recap messages with no orphaned tool_call_ids)
- Added snapshot tool schema to `tools.py` (TOOLS list + dispatch routing)
- Integrated into `agent.py` — dirty tracking after non-readonly tool calls, snapshot nudge after 5+ consecutive read-only turns, recap message scoring (+5) in compaction heuristics, snapshot_state passed through handle_tool_call/run_agent_loop/repl_loop/_repl_clear, summary display at loop end
- Wired `snapshot_state` in `session.py` (_make_per_run_state, _build_loop_kwargs)
- Added snapshot metrics to `report.py` (build_report/finalize accept snapshot_stats)
- Added few-shot guidance to `system_prompt.txt`
- Documented tool API in `docs.md/tools.md`
- Created 55 tests in `tests/test_snapshot.py` covering: save/restore/cancel/status, implicit vs explicit checkpoints, dirty tracking, force override, history cap, prompt injection budget, token savings, dispatch integration, compaction scoring

- All 1226 tests pass, lint clean, format clean

**User asked:** Fix four issues found in review.

**What I did:**

1. **Critical — orphaned tool results after restore.** `_restore()` was collapsing the current turn's assistant message (which contains the snapshot tool_call), then the loop appended the tool result creating an orphan. Fixed by scanning backwards for the last assistant message with tool_calls and excluding it and everything after from the collapse scope. Added 2 integration tests that simulate the actual loop flow (single and mixed tool_call batches).

2. **High — snapshot history not injected into prompts.** `inject_into_prompt()` existed but was never called. Added dynamic injection into the system message at the start of each loop iteration in `run_agent_loop()`. Previous injection is stripped before re-injecting to avoid accumulation. Added 2 tests.

3. **Medium — dirty state bypass on `/continue`.** `run_agent_loop()` unconditionally reset dirty at entry. Fixed by checking whether the last message is a user message (new scope boundary). On `/continue`, the last message is assistant/tool, so dirty state is preserved. Added 2 tests.

4. **Medium — nudge one-shot per run instead of per streak.** `snapshot_nudge_fired` was never reset. Fixed by resetting it when a mutation breaks the read streak, making nudges fire once per streak. Also removed duplicate nudge logic. Added 2 tests.

- All 1234 tests pass, lint clean, format clean

**User asked:** Fix history injection duplication across `/continue` / repeated `run_agent_loop()` calls.

**What I did:** The `_snapshot_history_injected` flag was local to `run_agent_loop()`, resetting to `False` on each invocation. On re-entry the old `[Snapshot history` block in the system message wasn't stripped, causing accumulation. Fixed by removing the flag entirely and always stripping any existing `[Snapshot history` block from the system message before injecting. Added 1 test covering the re-entry scenario.

- All 1235 tests pass, lint clean, format clean

**User asked:** Fix low-risk issue — history-strip marker is plain text that could collide with natural prompt content.

**What I did:** Replaced the plain-text marker `"\n\n[Snapshot history"` with a dedicated sentinel token `<!-- swival:snapshot-history-39a7c -->` (HTML comment with random suffix). The sentinel was already added to `snapshot.py` and `inject_into_prompt()` in the previous step. Completed the fix by:
- Updated `agent.py` to import `SNAPSHOT_HISTORY_SENTINEL` from `snapshot.py` and use it for stripping (replaced `_SNAPSHOT_HISTORY_MARKER` local variable)
- Updated `tests/test_snapshot.py` to import and use `SNAPSHOT_HISTORY_SENTINEL` in all 6 marker references
- All 1235 tests pass, lint clean

**User asked:** Implement the REPL `/save`, `/restore`, `/unsave` commands from `plans/repl-snapshot-commands.md`.

**What I did:** Added three REPL commands for manual snapshot control, leveraging the existing `SnapshotState` machinery:

- Extended `SnapshotState` in `snapshot.py`:
  - Added `explicit_begin_index` field for index-based checkpoints (user-initiated saves happen between turns, not inside tool calls)
  - Added `_generation`/`_save_generation` counter pair for stale-index detection after compaction
  - Refactored `_save` into `_save_common` + `_save`, added `save_at_index(label, index)` method
  - Added `invalidate_index_checkpoint()` method (increments generation)
  - Added `restore_with_autosummary(messages, summarize_fn)` — auto-generates summary via LLM call, falls back to static marker
  - Added `end_idx` kwarg to `_restore` so manual restore can collapse the full tail
  - Extended `_resolve_start` with index branch + generation check
  - Cleared new fields in `_restore`, `_cancel`, `reset`
- Wired into `agent.py`:
  - Added `/save [label]`, `/restore`, `/unsave` command handlers in `repl_loop`
  - Added `_repl_snapshot_save`, `_repl_snapshot_restore`, `_repl_snapshot_unsave` helpers
  - Updated `_repl_compact` to call `invalidate_index_checkpoint()` after compaction
  - Added invalidation call in auto-compaction path (`run_agent_loop` overflow branch)
  - Updated `/help` output with the three new commands
- Added 13 snapshot unit tests and 11 REPL integration tests
- All 1267 tests pass, lint clean, format clean

**User asked:** Fix two review issues: (1) weak summarization prompt in /restore, (2) missing auto-compaction invalidation test.

**What I did:**

1. Replaced the weak prompt in `_repl_snapshot_restore` ("Summarize the following conversation turns concisely.") with the same safety-hardened prompt used by `summarize_turns` — requires factual-only output, preserves key artifacts (file paths, findings, decisions, errors), explicitly forbids instructions/directives. This matters because recap text is injected back into system context via `inject_into_prompt`.

2. Added `test_save_then_autocompact_then_restore_error` — saves an index checkpoint, triggers `ContextOverflowError` in `run_agent_loop` which fires the graduated compaction path, then verifies `_generation` was incremented and `_resolve_start` returns an invalidation error.

- All 1268 tests pass, lint clean, format clean

**User asked:** Make sure all documentation is accurate and up to date including the docs.md directory.

**What I did:**

- `docs.md/usage.md`: Added `/save [label]`, `/restore`, `/unsave` to the REPL Commands section with descriptions of behavior, default label, implicit checkpoint fallback, and compaction invalidation.
- `docs.md/tools.md`: Added a "REPL Commands" subsection under the snapshot tool section, cross-referencing the REPL commands and noting that `/restore` auto-generates the summary via LLM.
- `CLAUDE.md`: Added `snapshot.py` to the Key modules list (was missing).

**User asked:** Explore all context management features and write an extensive report.

**What I did:** Explored the entire codebase in depth — agent.py, snapshot.py, thinking.py, todo.py, mcp_client.py, skills.py, session.py, config.py, tools.py, fetch.py, tracker.py, and system_prompt.txt. Wrote an initial report in `context-management-report.md`.

**User asked:** Merge the two reports (existing `CONTEXT_MANAGEMENT_REPORT.md` and new `context-management-report.md`) into a single definitive report.

**What I did:** Merged both files into `CONTEXT_MANAGEMENT_REPORT.md`, combining the best of each: the code snippets and API-level detail from the original, the concentric rings architecture diagram and lifecycle walkthrough from the new one, plus the output size guards, interventions/nudges, and MCP runtime handling that were only in one or the other. Deleted the duplicate `context-management-report.md`.

**User asked:** Create a new documentation page in docs.md about context management, accurate and high-level (not about code details).

**What I did:** Created `docs.md/context-management.md` — a user-facing documentation page covering Swival's context management in prose without code snippets or line references. Structured around the four-layer architecture (prevention, proactive collapse, reactive compaction, knowledge survival), with sections on output size guards, MCP schema budgets, the snapshot tool, graduated compaction levels, thinking/todo/snapshot persistence, proactive checkpoint summaries, REPL commands, and configuration. Added the page to `build.py` NAV (under "Basics" after "Tools"), cross-referenced from `getting-started.md` ("Where To Go Next") and `tools.md` (snapshot section). Website builds clean, all links OK.

**User asked:** Simplify the code without breaking anything.

**What I did:** Ran three parallel review agents (code reuse, quality, efficiency) on the last 5 commits. Applied 11 safe simplifications:

1. Extracted message accessor helpers (`_msg_get`, `_msg_role`, `_msg_content`, etc.) into `swival/_msg.py` — eliminates duplication between `agent.py` and `snapshot.py` (which had its own copies)
2. Extracted `_SUMMARIZE_SYSTEM_PROMPT` constant in `agent.py` — was duplicated verbatim in `summarize_turns()` and `_repl_snapshot_restore()`
3. Extracted `_clear_explicit()` method in `SnapshotState` — checkpoint clearing code was duplicated in `_restore()`, `cancel()`, and `reset()`
4. Made `SnapshotState.dirty` a `@property` derived from `bool(self.dirty_tools)` — was redundant state always set in tandem
5. Removed double `READ_ONLY_TOOLS` membership check — was checked both in `agent.py` caller and inside `mark_dirty()`
6. Extracted `_show_state_summaries()` helper in `agent.py` — identical 8-line block was copy-pasted at two exit points of `run_agent_loop`
7. Cached `inject_into_prompt()` result — was rebuilding the string from scratch every turn even when history hadn't changed
8. Added `SNAPSHOT_RECAP_PREFIX` constant — replaced magic string `"[snapshot:"` in `score_turn()` with importable constant
9. Replaced list slice with arithmetic for `turns_collapsed` in `_restore()` — avoids allocating a copy of the message list just to get its length
10. Used `_msg_tool_calls()` and `_msg_get()` in `snapshot.py` instead of hand-rolled isinstance/getattr patterns
11. Renamed `_cancel()` to `cancel()` — was being called from `agent.py` as a private method, now properly public

All 1268 tests pass, lint clean.
