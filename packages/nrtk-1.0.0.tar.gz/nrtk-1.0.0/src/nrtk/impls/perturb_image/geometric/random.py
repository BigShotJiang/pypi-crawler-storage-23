"""Random geometric perturbers."""

from nrtk.impls.perturb_image.geometric._random.random_crop_perturber import RandomCropPerturber
from nrtk.impls.perturb_image.geometric._random.random_translation_perturber import RandomTranslationPerturber

# Override __module__ to reflect the public API path for plugin discovery
RandomCropPerturber.__module__ = __name__
RandomTranslationPerturber.__module__ = __name__

__all__ = ["RandomCropPerturber", "RandomTranslationPerturber"]

# Albumentations-based perturbers (optional)
_ALBUMENTATIONS_CLASSES = ["RandomRotationPerturber", "RandomScalePerturber"]

_import_error: ImportError | None = None

try:
    from nrtk.impls.perturb_image._albumentations.random_rotation_perturber import (
        RandomRotationPerturber as RandomRotationPerturber,
    )
    from nrtk.impls.perturb_image._albumentations.random_scale_perturber import (
        RandomScalePerturber as RandomScalePerturber,
    )

    RandomRotationPerturber.__module__ = __name__
    RandomScalePerturber.__module__ = __name__

    __all__ += _ALBUMENTATIONS_CLASSES
except ImportError as _ex:
    _import_error = _ex


def __getattr__(name: str) -> None:
    if name in _ALBUMENTATIONS_CLASSES:
        msg = (
            f"{name} requires the `albumentations` and (`graphics` or `headless`) extras. "
            f"Install with: `pip install nrtk[albumentations,graphics]` or `pip install nrtk[albumentations,headless]`"
        )
        if _import_error is not None:
            msg += (
                f"\n\nIf the extra is already installed, the following upstream error may be the cause:"
                f"\n  {type(_import_error).__name__}: {_import_error}"
            )
        raise ImportError(msg)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
