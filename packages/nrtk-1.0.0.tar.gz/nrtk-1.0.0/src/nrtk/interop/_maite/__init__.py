"""Define the nrtk.interop._maite package."""
