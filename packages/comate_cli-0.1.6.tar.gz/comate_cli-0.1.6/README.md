# comate-cli

Comate terminal CLI package.

## Usage

```bash
uvx comate-cli
```

Or install globally:

```bash
uv tool install comate-cli
comate
```
