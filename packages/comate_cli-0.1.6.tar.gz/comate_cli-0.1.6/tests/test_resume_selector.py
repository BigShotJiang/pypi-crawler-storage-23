from __future__ import annotations

import json
import os
import tempfile
import time
import unittest
from datetime import datetime
from pathlib import Path

from comate_cli.terminal_agent.resume_selector import (
    format_datetime,
    format_relative_time,
    list_resume_sessions,
)


def _write_context_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "\n".join(json.dumps(row, ensure_ascii=False) for row in rows) + "\n",
        encoding="utf-8",
    )


class TestResumeSelector(unittest.TestCase):
    def test_format_datetime(self) -> None:
        self.assertEqual(
            format_datetime(0),
            datetime.fromtimestamp(0).strftime("%Y-%m-%d %H:%M"),
        )

    def test_format_relative_time_boundaries(self) -> None:
        now = 1_000_000.0
        self.assertEqual(format_relative_time(now - 10, now_ts=now), "1分钟前")
        self.assertEqual(format_relative_time(now - 120, now_ts=now), "2分钟前")
        self.assertEqual(format_relative_time(now - 3600, now_ts=now), "1小时前")
        self.assertEqual(format_relative_time(now - 7200, now_ts=now), "2小时前")

    def test_list_resume_sessions_sorted_by_last_active_and_extracts_first_user(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old_path = root / "old-session" / "context.jsonl"
            new_path = root / "new-session" / "context.jsonl"
            invalid_path = root / "invalid-session" / "context.jsonl"

            _write_context_jsonl(
                old_path,
                [
                    {"op": "header_snapshot"},
                    {
                        "op": "conversation_reset",
                        "conversation": {
                            "items": [
                                {
                                    "item_type": "user_message",
                                    "message": {
                                        "role": "user",
                                        "is_meta": True,
                                        "content": "meta",
                                    },
                                },
                                {
                                    "item_type": "user_message",
                                    "message": {
                                        "role": "user",
                                        "is_meta": False,
                                        "content": "old first user",
                                    },
                                },
                            ]
                        },
                    },
                ],
            )
            _write_context_jsonl(
                new_path,
                [
                    {"op": "header_snapshot"},
                    {
                        "op": "conversation_delta",
                        "conversation": {
                            "adds": [
                                {
                                    "item_type": "user_message",
                                    "message": {
                                        "role": "user",
                                        "is_meta": False,
                                        "content": [
                                            {"type": "text", "text": "new first "},
                                            {"type": "text", "text": "user"},
                                        ],
                                    },
                                }
                            ]
                        },
                    },
                ],
            )
            _write_context_jsonl(
                invalid_path,
                [
                    {
                        "op": "conversation_reset",
                        "conversation": {
                            "items": [
                                {
                                    "item_type": "user_message",
                                    "message": {
                                        "role": "user",
                                        "is_meta": False,
                                        "content": "should be ignored without header snapshot",
                                    },
                                }
                            ]
                        },
                    }
                ],
            )

            now = time.time()
            os.utime(old_path, (now - 300, now - 300))
            os.utime(new_path, (now - 10, now - 10))
            os.utime(invalid_path, (now - 5, now - 5))

            sessions = list_resume_sessions(sessions_root=root)

            self.assertEqual([item.session_id for item in sessions], ["new-session", "old-session"])
            self.assertEqual(sessions[0].conversation, "new first user")
            self.assertEqual(sessions[1].conversation, "old first user")
            self.assertGreater(sessions[0].updated_ts, sessions[1].updated_ts)
            self.assertGreater(sessions[0].created_ts, 0)

    def test_list_resume_sessions_keeps_full_conversation_without_fixed_truncation(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            context_path = root / "long-session" / "context.jsonl"
            long_text = "x" * 200
            _write_context_jsonl(
                context_path,
                [
                    {"op": "header_snapshot"},
                    {
                        "op": "conversation_reset",
                        "conversation": {
                            "items": [
                                {
                                    "item_type": "user_message",
                                    "message": {
                                        "role": "user",
                                        "is_meta": False,
                                        "content": long_text,
                                    },
                                }
                            ]
                        },
                    },
                ],
            )

            sessions = list_resume_sessions(sessions_root=root)
            self.assertEqual(len(sessions), 1)
            self.assertEqual(sessions[0].conversation, long_text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
