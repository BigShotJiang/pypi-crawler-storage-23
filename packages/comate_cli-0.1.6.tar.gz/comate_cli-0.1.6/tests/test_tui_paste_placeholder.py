from __future__ import annotations

import asyncio
import unittest
from collections import deque

from comate_cli.terminal_agent.tui import TerminalAgentTUI, UIMode


class _FakeBuffer:
    def __init__(self, text: str) -> None:
        self.text = text
        self.cursor_position = len(text)

    def cancel_completion(self) -> None:
        return None

    def set_document(self, document, bypass_readonly: bool = False) -> None:
        del bypass_readonly
        self.text = document.text
        self.cursor_position = document.cursor_position


class _FakeInputArea:
    def __init__(self, text: str) -> None:
        self.text = text
        self.buffer = _FakeBuffer(text)
        self.buffer.complete_state = None


class _FakeRenderer:
    def __init__(self) -> None:
        self.messages: list[tuple[str, str | None]] = []

    def append_system_message(self, text: str, severity: str | None = None) -> None:
        self.messages.append((text, severity))


def _build_tui(threshold: int = 5) -> TerminalAgentTUI:
    tui = TerminalAgentTUI.__new__(TerminalAgentTUI)
    tui._suppress_input_change_hook = False
    tui._busy = False
    tui._initializing = False
    tui._ui_mode = UIMode.NORMAL
    tui._last_input_len = 0
    tui._last_input_text = ""
    tui._paste_threshold_chars = threshold
    tui._paste_placeholder_text = None
    tui._active_paste_token = None
    tui._paste_payload_by_token = {}
    tui._paste_token_seq = 0
    tui._queued_messages = deque()
    tui._message_queue_max_size = 3
    tui._queued_preview_max_chars = 24
    tui._queued_input_hint = "Press ↑ to edit"
    tui._renderer = _FakeRenderer()
    tui._refresh_layers = lambda: None
    tui._app = None
    tui._invalidate = lambda: None
    tui._input_area = _FakeInputArea("")
    return tui


class TestTUIPastePlaceholder(unittest.TestCase):
    def test_handle_large_paste_replaces_with_placeholder_and_stores_payload(
        self,
    ) -> None:
        tui = _build_tui(threshold=5)
        payload = "abcdefgh"
        buffer = _FakeBuffer(payload)

        handled = tui._handle_large_paste(buffer)

        self.assertTrue(handled)
        self.assertEqual(tui._paste_placeholder_text, "[Pasted Content 8 chars]")
        self.assertEqual(buffer.text, "[Pasted Content 8 chars]")
        self.assertIsNotNone(tui._active_paste_token)
        self.assertEqual(len(tui._paste_payload_by_token), 1)
        token = tui._active_paste_token
        self.assertIsNotNone(token)
        self.assertEqual(tui._paste_payload_by_token[token], payload)

    def test_resolve_submit_uses_payload_for_placeholder_with_whitespace(self) -> None:
        tui = _build_tui(threshold=5)
        payload = "abcdefgh"
        buffer = _FakeBuffer(payload)
        tui._handle_large_paste(buffer)
        placeholder = tui._paste_placeholder_text
        self.assertIsNotNone(placeholder)

        display_text, submit_text = tui._resolve_submit_texts(f"  {placeholder}\n")

        self.assertEqual(display_text, payload)
        self.assertEqual(submit_text, payload)

    def test_handle_large_paste_preserves_existing_prefix_text(self) -> None:
        tui = _build_tui(threshold=5)
        prefix = "abcde"
        payload = "fghijklm"
        buffer = _FakeBuffer(f"{prefix}{payload}")
        tui._last_input_text = prefix
        tui._last_input_len = len(prefix)

        handled = tui._handle_large_paste(buffer)

        self.assertTrue(handled)
        self.assertEqual(buffer.text, f"{prefix}[Pasted Content 8 chars]")
        display_text, submit_text = tui._resolve_submit_texts(buffer.text)
        self.assertEqual(display_text, f"{prefix}{payload}")
        self.assertEqual(submit_text, f"{prefix}{payload}")

    def test_whitespace_change_does_not_clear_active_placeholder_mapping(self) -> None:
        tui = _build_tui(threshold=5)
        payload = "abcdefgh"
        buffer = _FakeBuffer(payload)
        tui._handle_large_paste(buffer)
        token_before = tui._active_paste_token
        placeholder = tui._paste_placeholder_text
        self.assertIsNotNone(token_before)
        self.assertIsNotNone(placeholder)

        buffer.text = f"{placeholder}\n"
        handled = tui._handle_large_paste(buffer)

        self.assertFalse(handled)
        self.assertEqual(tui._active_paste_token, token_before)
        self.assertEqual(tui._paste_placeholder_text, placeholder)
        self.assertEqual(tui._paste_payload_by_token[token_before], payload)

    def test_substantive_placeholder_edit_clears_mapping(self) -> None:
        tui = _build_tui(threshold=5)
        payload = "abcdefgh"
        buffer = _FakeBuffer(payload)
        tui._handle_large_paste(buffer)
        placeholder = tui._paste_placeholder_text
        self.assertIsNotNone(placeholder)

        buffer.text = placeholder.replace("chars", "bytes")
        handled = tui._handle_large_paste(buffer)

        self.assertFalse(handled)
        self.assertIsNone(tui._active_paste_token)
        self.assertIsNone(tui._paste_placeholder_text)
        self.assertEqual(tui._paste_payload_by_token, {})

    def test_resolve_submit_falls_back_to_text_after_mapping_cleared(self) -> None:
        tui = _build_tui(threshold=5)
        payload = "abcdefgh"
        buffer = _FakeBuffer(payload)
        tui._handle_large_paste(buffer)
        placeholder = tui._paste_placeholder_text
        self.assertIsNotNone(placeholder)

        buffer.text = placeholder.replace("chars", "bytes")
        tui._handle_large_paste(buffer)

        display_text, submit_text = tui._resolve_submit_texts(buffer.text)
        self.assertEqual(display_text, buffer.text.strip())
        self.assertEqual(submit_text, buffer.text.strip())

    def test_submit_from_input_sends_original_payload_not_placeholder(self) -> None:
        tui = _build_tui(threshold=5)
        payload = "abcdefgh"
        paste_buffer = _FakeBuffer(payload)
        tui._handle_large_paste(paste_buffer)
        placeholder = tui._paste_placeholder_text
        self.assertIsNotNone(placeholder)

        captured: dict[str, str | None] = {
            "text": None,
            "display_text": None,
        }

        async def _fake_submit_user_message(
            text: str,
            *,
            display_text: str | None = None,
        ) -> None:
            captured["text"] = text
            captured["display_text"] = display_text

        tui._busy = False
        tui._ui_mode = UIMode.NORMAL
        tui._input_area = _FakeInputArea(f"{placeholder}\n")
        tui._execute_command = lambda _: None
        tui._clear_input_area = lambda: None
        tui._submit_user_message = _fake_submit_user_message

        def _run_immediately(coro) -> None:
            asyncio.run(coro)

        tui._schedule_background = _run_immediately

        tui._submit_from_input()

        self.assertEqual(captured["text"], payload)
        self.assertEqual(captured["display_text"], payload)

    def test_submit_from_input_with_prefix_expands_placeholder_segment(self) -> None:
        tui = _build_tui(threshold=5)
        prefix = "abcde"
        payload = "fghijklm"
        tui._last_input_text = prefix
        tui._last_input_len = len(prefix)
        paste_buffer = _FakeBuffer(f"{prefix}{payload}")
        tui._handle_large_paste(paste_buffer)
        expected_display = f"{prefix}[Pasted Content 8 chars]"

        captured: dict[str, str | None] = {
            "text": None,
            "display_text": None,
        }

        async def _fake_submit_user_message(
            text: str,
            *,
            display_text: str | None = None,
        ) -> None:
            captured["text"] = text
            captured["display_text"] = display_text

        tui._busy = False
        tui._ui_mode = UIMode.NORMAL
        tui._input_area = _FakeInputArea(f"{expected_display}\n")
        tui._execute_command = lambda _: None
        tui._clear_input_area = lambda: None
        tui._submit_user_message = _fake_submit_user_message

        def _run_immediately(coro) -> None:
            asyncio.run(coro)

        tui._schedule_background = _run_immediately

        tui._submit_from_input()

        self.assertEqual(captured["text"], f"{prefix}{payload}")
        self.assertEqual(captured["display_text"], f"{prefix}{payload}")

    def test_submit_from_input_busy_enqueues_multiple_messages(self) -> None:
        tui = _build_tui(threshold=5)
        tui._busy = True
        tui._ui_mode = UIMode.NORMAL
        tui._execute_command = lambda _: None
        tui._clear_input_area = lambda: None
        tui._schedule_background = lambda _: None

        tui._input_area = _FakeInputArea("first")
        tui._submit_from_input()
        tui._input_area = _FakeInputArea("second")
        tui._submit_from_input()
        tui._input_area = _FakeInputArea("third")
        tui._submit_from_input()

        self.assertEqual(list(tui._queued_messages), ["first", "second", "third"])

    def test_submit_from_input_busy_rejects_when_queue_is_full(self) -> None:
        tui = _build_tui(threshold=5)
        tui._busy = True
        tui._ui_mode = UIMode.NORMAL
        tui._execute_command = lambda _: None
        tui._clear_input_area = lambda: None
        tui._schedule_background = lambda _: None
        tui._queued_messages.extend(["a", "b", "c"])

        tui._input_area = _FakeInputArea("overflow")
        tui._submit_from_input()

        self.assertEqual(list(tui._queued_messages), ["a", "b", "c"])
        self.assertTrue(tui._renderer.messages)
        message, severity = tui._renderer.messages[-1]
        self.assertIn("消息队列已满", message)
        self.assertEqual(severity, "error")

    def test_submit_from_input_busy_slash_command_still_dispatches(self) -> None:
        tui = _build_tui(threshold=5)
        tui._busy = True
        tui._ui_mode = UIMode.NORMAL
        tui._clear_input_area = lambda: None
        dispatched: list[str] = []

        async def _fake_execute_command(command: str) -> None:
            dispatched.append(command)

        scheduled: list[object] = []

        def _capture_schedule(coro: object) -> None:
            scheduled.append(coro)

        tui._execute_command = _fake_execute_command
        tui._schedule_background = _capture_schedule
        tui._input_area = _FakeInputArea("/help")

        tui._submit_from_input()

        self.assertEqual(list(tui._queued_messages), [])
        self.assertEqual(dispatched, [])
        self.assertEqual(len(scheduled), 1)
        asyncio.run(scheduled[0])
        self.assertEqual(dispatched, ["/help"])

    def test_queue_panel_text_and_height(self) -> None:
        tui = _build_tui(threshold=5)
        tui._queued_messages.extend(["first message", "second\nmessage"])

        fragments = tui._queue_text()
        rendered = "".join(text for _, text in fragments)

        self.assertIn("     > first message", rendered)
        self.assertIn("     > second message", rendered)
        self.assertEqual(tui._queue_height(), 2)

    def test_should_show_queue_panel_when_at_least_one_queued(self) -> None:
        tui = _build_tui(threshold=5)
        self.assertFalse(tui._should_show_queue_panel())

        tui._queued_messages.append("only one")
        self.assertTrue(tui._should_show_queue_panel())

        tui._ui_mode = UIMode.QUESTION
        self.assertFalse(tui._should_show_queue_panel())

    def test_input_placeholder_hint_with_single_queue_shows_preview(self) -> None:
        tui = _build_tui(threshold=5)
        tui._queued_messages.append("single queued message")
        tui._input_area = _FakeInputArea("")

        hint = tui._input_placeholder_hint()
        self.assertIsNotNone(hint)
        assert hint is not None
        self.assertIn("已排队:", hint)
        self.assertIn("single queued message", hint)
        self.assertIn("Press ↑ to edit", hint)

    def test_input_placeholder_hint_with_single_queue_truncates_preview(self) -> None:
        tui = _build_tui(threshold=5)
        tui._queued_preview_max_chars = 12
        tui._queued_messages.append("this is a very very long queued message")
        tui._input_area = _FakeInputArea("")

        hint = tui._input_placeholder_hint()
        self.assertIsNotNone(hint)
        assert hint is not None
        self.assertIn("已排队:", hint)
        self.assertIn("...", hint)

    def test_input_placeholder_hint_with_multi_queue_uses_short_hint(self) -> None:
        tui = _build_tui(threshold=5)
        tui._queued_messages.extend(["one", "two"])
        tui._input_area = _FakeInputArea("")

        hint = tui._input_placeholder_hint()
        self.assertEqual(hint, "Press ↑ to edit")

    def test_input_placeholder_hint_hidden_when_input_not_empty(self) -> None:
        tui = _build_tui(threshold=5)
        tui._queued_messages.append("one")
        tui._input_area = _FakeInputArea("typing")

        hint = tui._input_placeholder_hint()
        self.assertIsNone(hint)


if __name__ == "__main__":
    unittest.main(verbosity=2)
