from __future__ import annotations

import io
import unittest
from pathlib import Path
from unittest.mock import patch

from rich.console import Console

from comate_cli.terminal_agent.logo import print_logo


class TestLogo(unittest.TestCase):
    def _render_logo(self, project_root: Path) -> str:
        stream = io.StringIO()
        console = Console(
            file=stream,
            force_terminal=False,
            color_system=None,
            width=200,
        )
        with patch("comate_cli.terminal_agent.logo._resolve_version", return_value="v9.9.9"):
            print_logo(console, project_root=project_root)
        return stream.getvalue()

    @patch("comate_cli.terminal_agent.logo.Path.home", return_value=Path("/home/tester"))
    def test_print_logo_directory_uses_tilde_for_home(self, _mock_home: object) -> None:
        output = self._render_logo(Path("/home/tester"))
        self.assertIn("v9.9.9", output)
        self.assertIn("directory: ~/", output)

    @patch("comate_cli.terminal_agent.logo.Path.home", return_value=Path("/home/tester"))
    def test_print_logo_directory_uses_absolute_path_when_not_home(
        self, _mock_home: object
    ) -> None:
        output = self._render_logo(Path("/workspace/project"))
        self.assertIn("directory: /workspace/project", output)
        self.assertNotIn("directory: ~/", output)

    @patch("comate_cli.terminal_agent.logo.Path.home", return_value=Path("/home/tester"))
    def test_print_logo_removes_product_grade_copy(self, _mock_home: object) -> None:
        output = self._render_logo(Path("/workspace/project"))
        self.assertNotIn("Product-grade terminal agent UI", output)


if __name__ == "__main__":
    unittest.main(verbosity=2)
