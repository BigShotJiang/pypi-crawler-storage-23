from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from comate_cli.terminal_agent.slash_commands import SlashCommandSpec


@dataclass(frozen=True, slots=True)
class RegisteredSlashCommand:
    spec: SlashCommandSpec
    handler: Callable[[str], Any]
    allow_when_busy: bool = False


class SlashCommandRegistry:
    def __init__(self) -> None:
        self._entries_by_name: dict[str, RegisteredSlashCommand] = {}
        self._entries_by_spec_name: dict[str, RegisteredSlashCommand] = {}

    def register(
        self,
        *,
        spec: SlashCommandSpec,
        handler: Callable[[str], Any],
        allow_when_busy: bool = False,
    ) -> None:
        entry = RegisteredSlashCommand(
            spec=spec,
            handler=handler,
            allow_when_busy=allow_when_busy,
        )
        names = (spec.name, *spec.aliases)
        for name in names:
            if name in self._entries_by_name:
                raise ValueError(f"Duplicate slash command registration: {name}")
        for name in names:
            self._entries_by_name[name] = entry
        self._entries_by_spec_name[spec.name] = entry

    def resolve(self, name: str) -> RegisteredSlashCommand | None:
        return self._entries_by_name.get(name)

    def command_specs(self) -> tuple[SlashCommandSpec, ...]:
        return tuple(entry.spec for entry in self._entries_by_spec_name.values())
