from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from prompt_toolkit.application import Application
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import Layout
from prompt_toolkit.patch_stdout import patch_stdout
from rich.console import Console

from comate_agent_sdk.agent.session_store import default_session_root, default_sessions_dir

from comate_cli.terminal_agent.selection_menu import SelectionMenuUI

logger = logging.getLogger(__name__)

_PAGE_SIZE = 15


@dataclass(frozen=True, slots=True)
class ResumeSessionItem:
    session_id: str
    context_path: Path
    created_ts: float
    updated_ts: float
    conversation: str


def _extract_text_from_content(content: Any) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        text_parts: list[str] = []
        for part in content:
            if not isinstance(part, dict):
                continue
            if part.get("type") != "text":
                continue
            text_parts.append(str(part.get("text", "")))
        return "".join(text_parts).strip()
    return ""


def _extract_user_text_from_item(item: dict[str, Any]) -> str | None:
    if str(item.get("item_type", "")).strip() != "user_message":
        return None

    message = item.get("message")
    if isinstance(message, dict):
        if bool(message.get("is_meta", False)):
            return None
        text = _extract_text_from_content(message.get("content"))
        if text:
            return text

    content_text = str(item.get("content_text", "")).strip()
    if content_text:
        return content_text
    return None


def _extract_created_at_from_item(item: dict[str, Any]) -> float | None:
    raw = item.get("created_at")
    try:
        value = float(raw)
    except Exception:
        return None
    if value <= 0:
        return None
    return value


def _scan_context_jsonl(path: Path) -> tuple[bool, str | None, float | None]:
    has_header_snapshot = False
    first_user_message: str | None = None
    first_user_created_ts: float | None = None

    try:
        with path.open("r", encoding="utf-8") as f:
            for raw_line in f:
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except Exception:
                    continue

                op = str(data.get("op", "")).strip()
                if op == "header_snapshot":
                    has_header_snapshot = True

                if first_user_message is not None:
                    continue

                conversation = data.get("conversation")
                if not isinstance(conversation, dict):
                    continue

                item_candidates: list[dict[str, Any]] = []
                if op == "conversation_reset":
                    items = conversation.get("items")
                    if isinstance(items, list):
                        item_candidates.extend(
                            item for item in items if isinstance(item, dict)
                        )
                elif op == "conversation_delta":
                    adds = conversation.get("adds")
                    if isinstance(adds, list):
                        item_candidates.extend(
                            item for item in adds if isinstance(item, dict)
                        )

                for item in item_candidates:
                    text = _extract_user_text_from_item(item)
                    if text:
                        first_user_message = " ".join(text.split())
                        first_user_created_ts = _extract_created_at_from_item(item)
                        break
    except Exception as exc:
        logger.warning(f"Failed to scan context jsonl: path={path} error={exc}", exc_info=True)
        return False, None, None

    return has_header_snapshot, first_user_message, first_user_created_ts


def _default_sessions_root() -> Path:
    return default_session_root(session_id="placeholder").parent


def format_relative_time(last_active_ts: float, *, now_ts: float | None = None) -> str:
    now = now_ts if now_ts is not None else time.time()
    delta_seconds = max(0, int(now - last_active_ts))
    if delta_seconds < 60:
        return "1分钟前"
    if delta_seconds < 3600:
        minutes = max(1, delta_seconds // 60)
        return f"{minutes}分钟前"
    hours = max(1, delta_seconds // 3600)
    return f"{hours}小时前"


def format_datetime(ts: float) -> str:
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")


def list_resume_sessions(
    *, cwd: Path | None = None, sessions_root: Path | None = None
) -> list[ResumeSessionItem]:
    if sessions_root:
        root = sessions_root
    elif cwd is not None:
        root = default_sessions_dir(cwd)
    else:
        root = _default_sessions_root()
    if not root.exists():
        return []

    rows: list[ResumeSessionItem] = []
    for child in root.iterdir():
        if not child.is_dir():
            continue
        context_path = child / "context.jsonl"
        if not context_path.is_file():
            continue

        has_header_snapshot, first_user_message, first_user_created_ts = _scan_context_jsonl(
            context_path
        )
        if not has_header_snapshot:
            continue

        conversation = first_user_message or "(no user message)"
        try:
            updated_ts = float(context_path.stat().st_mtime)
        except Exception as exc:
            logger.debug(f"Skip session because stat failed: session={child.name} error={exc}")
            continue

        created_ts = float(first_user_created_ts or updated_ts)

        rows.append(
            ResumeSessionItem(
                session_id=str(child.name),
                context_path=context_path,
                created_ts=created_ts,
                updated_ts=updated_ts,
                conversation=conversation,
            )
        )

    rows.sort(key=lambda item: item.updated_ts, reverse=True)
    return rows


def _build_option_label(item: ResumeSessionItem) -> str:
    created_at = format_datetime(item.created_ts)
    updated_at = format_datetime(item.updated_ts)
    return f"{created_at}  {updated_at}  {item.conversation}"


async def select_resume_session_id(console: Console, *, cwd: Path | None = None) -> str | None:
    sessions = list_resume_sessions(cwd=cwd)
    if not sessions:
        console.print("[dim]暂无可恢复会话。[/]")
        return None

    options = [
        {
            "value": item.session_id,
            "label": _build_option_label(item),
            "description": "",
        }
        for item in sessions
    ]

    ui = SelectionMenuUI()
    selected_session_id: str | None = None

    def _on_confirm(value: str) -> None:
        nonlocal selected_session_id
        selected_session_id = value

    def _on_cancel() -> None:
        nonlocal selected_session_id
        selected_session_id = None

    ok = ui.set_options(
        title=f"Created at        Updated at        Conversation ({len(sessions)})",
        options=options,
        on_confirm=_on_confirm,
        on_cancel=_on_cancel,
        page_size=_PAGE_SIZE,
        wrap_navigation=False,
        description_selected_only=False,
        line_wrap=False,
    )
    if not ok:
        console.print("[dim]暂无可恢复会话。[/]")
        return None
    ui.refresh()

    bindings = KeyBindings()

    @bindings.add("up")
    @bindings.add("k")
    def _on_up(event) -> None:
        del event
        ui.move_selection(-1)
        ui.refresh()

    @bindings.add("down")
    @bindings.add("j")
    def _on_down(event) -> None:
        del event
        ui.move_selection(1)
        ui.refresh()

    @bindings.add("enter")
    def _on_enter(event) -> None:
        ui.confirm()
        event.app.exit(result=selected_session_id)

    @bindings.add("escape")
    @bindings.add("c-c")
    def _on_cancel_key(event) -> None:
        ui.cancel()
        event.app.exit(result=None)

    app = Application(
        layout=Layout(container=ui.container, focused_element=ui.focus_target()),
        key_bindings=bindings,
        full_screen=True,  # alternate screen buffer，退出后零 scrollback 残留
        mouse_support=False,
    )

    with patch_stdout(raw=True):
        result = await app.run_async()
    if not isinstance(result, str) or not result.strip():
        console.print("[dim]已取消恢复。[/]")
        return None
    return result
