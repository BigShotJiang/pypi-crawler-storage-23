"""TAPDB Database Connection Manager.

Moonshot Phase 2 policy:
- No surprise commits inside the library
- Callers control transaction boundaries
- Audit username is set per-transaction using `SET LOCAL session.current_username`

Recommended usage:

    with TAPDBConnection() as conn:
        with conn.session_scope(commit=False) as session:
            rows = session.query(...).all()

For write operations:

    with TAPDBConnection() as conn:
        with conn.session_scope(commit=True) as session:
            session.add(obj)
"""

import logging
import os
from contextlib import contextmanager
from typing import Generator, Optional

from sqlalchemy import MetaData, create_engine, text
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session, sessionmaker

logger = logging.getLogger(__name__)
DEFAULT_TAPDB_POSTGRES_PORT = "5533"


class TAPDBConnection:
    """
    TAPDB Database Connection Manager.

    Usage (Phase 2 moonshot):
        # Read-only / query usage
        with TAPDBConnection() as conn:
            with conn.session_scope(commit=False) as session:
                rows = session.query(...).all()

        # Write usage (explicit opt-in commit)
        with TAPDBConnection() as conn:
            with conn.session_scope(commit=True) as session:
                session.add(obj)
                # commits on success, rolls back on exception
    """

    def __init__(
        self,
        db_url: Optional[str] = None,
        db_url_prefix: str = "postgresql://",
        db_hostname: Optional[str] = None,
        db_pass: Optional[str] = None,
        db_user: Optional[str] = None,
        db_name: str = "tapdb",
        app_username: Optional[str] = None,
        echo_sql: Optional[bool] = None,
        pool_size: int = 5,
        max_overflow: int = 10,
        pool_timeout: int = 30,
        pool_recycle: int = 1800,
        engine_type: Optional[str] = None,
        region: str = "us-west-2",
        iam_auth: bool = True,
        secret_arn: Optional[str] = None,
    ):
        """
        Initialize database connection.

        Args:
            db_url: Full database URL (overrides other db_* params)
            db_url_prefix: Database URL prefix (default: postgresql://)
            db_hostname: Database host:port (default: localhost:$PGPORT or 5533)
            db_pass: Database password (default: $PGPASSWORD)
            db_user: Database user (default: $USER)
            db_name: Database name (default: tapdb)
            app_username: Username for audit logging (default: $USER)
            echo_sql: Log SQL statements (default: $ECHO_SQL env var)
            pool_size: Connection pool size
            max_overflow: Max connections above pool_size
            pool_timeout: Seconds to wait for connection
            pool_recycle: Seconds before connection recycled
            engine_type: Connection type — None or "local" for local PG,
                "aurora" for Aurora PostgreSQL with SSL + IAM auth.
            region: AWS region (only used when engine_type="aurora").
            iam_auth: Use IAM database authentication (Aurora only).
            secret_arn: Secrets Manager ARN for password (Aurora fallback).
        """
        self.logger = logging.getLogger(__name__ + ".TAPDBConnection")

        # Resolve defaults from environment
        db_user = db_user or os.environ.get("USER", "tapdb")
        self.app_username = app_username or os.environ.get("USER", "tapdb_orm")

        if echo_sql is None:
            echo_env = os.environ.get("ECHO_SQL", "").lower()
            echo_sql = echo_env in ("true", "1", "yes")

        # Build database URL
        if db_url:
            self._db_url = db_url
        elif engine_type == "aurora":
            from daylily_tapdb.aurora.connection import AuroraConnectionBuilder

            # For Aurora, db_hostname must be the cluster endpoint (host:port
            # or just host).
            if not db_hostname:
                raise ValueError(
                    "db_hostname (Aurora cluster endpoint) is required "
                    "when engine_type='aurora'."
                )
            # Split host:port if provided together
            if ":" in db_hostname:
                host, port_str = db_hostname.rsplit(":", 1)
                port = int(port_str)
            else:
                host = db_hostname
                port = 5432

            self._db_url = AuroraConnectionBuilder.build_connection_url(
                host=host,
                port=port,
                database=db_name,
                user=db_user,
                region=region,
                iam_auth=iam_auth,
                secret_arn=secret_arn,
                password=db_pass,
            )
        else:
            # Local PostgreSQL (original behaviour)
            db_hostname = db_hostname or f"localhost:{os.environ.get('PGPORT', DEFAULT_TAPDB_POSTGRES_PORT)}"
            db_pass = db_pass or os.environ.get("PGPASSWORD", "")
            self._db_url = f"{db_url_prefix}{db_user}:{db_pass}@{db_hostname}/{db_name}"

        # Create engine with connection pooling
        self.engine = create_engine(
            self._db_url,
            echo=echo_sql,
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_timeout=pool_timeout,
            pool_recycle=pool_recycle,
            pool_pre_ping=True,
        )

        # Create session factory
        self._Session = sessionmaker(bind=self.engine)

        # Create metadata and automap base for reflected tables
        metadata = MetaData()
        self.AutomapBase = automap_base(metadata=metadata)

    def _set_session_username(self, session: Session) -> None:
        """Set the per-transaction username for audit logging (no commit)."""
        try:
            session.execute(
                text("SET LOCAL session.current_username = :username"),
                {"username": self.app_username},
            )
        except Exception as e:
            self.logger.warning(f"Could not set session username: {e}")

    def get_session(self) -> Session:
        """
        Get a new session.

        Note: this does NOT set the audit username because Phase 2 requires
        `SET LOCAL`, which is per-transaction. Prefer `session_scope()`.

        Returns:
            New SQLAlchemy Session (caller must close)
        """
        return self._Session()

    @contextmanager
    def session_scope(self, commit: bool = False) -> Generator[Session, None, None]:
        """
        Context manager for scoped session operations.

        Args:
            commit: If True, commit on success. If False, caller manages transaction.

        Yields:
            SQLAlchemy Session

        Example:
            with conn.session_scope(commit=True) as session:
                session.add(obj)
                # Auto-commits on success, rolls back on exception
        """
        session = self._Session()
        trans = session.begin()
        try:
            # Must happen inside a transaction for SET LOCAL.
            self._set_session_username(session)
            yield session
            if commit:
                trans.commit()
            else:
                trans.rollback()
        except Exception:
            trans.rollback()
            raise
        finally:
            session.close()

    def reflect_tables(self) -> None:
        """Reflect database tables into AutomapBase."""
        self.AutomapBase.prepare(autoload_with=self.engine)

    def __enter__(self) -> "TAPDBConnection":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        """Context manager exit - cleanup resources."""
        if exc_type is not None:
            self.logger.warning(f"Exception in context: {exc_type.__name__}: {exc_val}")
        self.close()
        return False

    def close(self) -> None:
        """Dispose engine resources."""
        if self.engine:
            try:
                self.engine.dispose()
            except Exception as e:
                self.logger.warning(f"Error disposing engine: {e}")
