from apibean.jupyter.cli import build_parser, run_from_args

def main():
    parser = build_parser()

    # apicash add it's own options
    parser.prog = "apicash"
    parser.add_argument(
        "--apicash-mode",
        choices=["dev", "prod"],
        default="dev",
    )

    args = parser.parse_args()

    # apicash process it's own options
    if args.apicash_mode == "prod":
        print("🔒 apicash running in prod mode")

    # delegate apibean-jupyter
    run_from_args(args)
