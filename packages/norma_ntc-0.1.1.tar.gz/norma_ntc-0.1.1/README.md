# pyntc

Python library for structural verification according to NTC 2018 (Italian Building Code, D.M. 17/01/2018).

> **Disclaimer**: This library does not replace the professional judgement of the structural engineer. Final verification is the responsibility of the designer.

## Installation

```bash
pip install norma-ntc
```

## Quick start

```python
from pyntc.actions.loads import unit_weight, variable_load, partition_equivalent_load
from pyntc.actions.wind import (
    wind_base_velocity,
    wind_reference_velocity,
    wind_kinetic_pressure,
    wind_exposure_coefficient,
    wind_pressure,
)

# --- Carichi (NTC18 §3.1) ---
gamma = unit_weight("calcestruzzo_armato")          # 25.0 kN/m³
qk, Qk, Hk = variable_load("A")                    # (2.0, 2.0, 1.0)
g2 = partition_equivalent_load(1.5)                  # 0.80 kN/m²

# --- Vento (NTC18 §3.3) ---
v_b = wind_base_velocity(zone=3, altitude=600)       # 29.00 m/s
v_r = wind_reference_velocity(3, 600, 50)            # 29.02 m/s
q_b = wind_kinetic_pressure(v_r)                     # 0.526 kN/m²
c_e = wind_exposure_coefficient(z=15, exposure_category=3)  # 2.407
p   = wind_pressure(q_b, c_e, c_p=0.8)              # 1.014 kN/m²
```

## Modules

### Actions (NTC18 Cap. 3) — input to the solver

| Module | Section | Description |
|--------|---------|-------------|
| `actions.loads` | §3.1 | Dead loads, partitions, variable loads, reduction factors |
| `actions.wind` | §3.3 | Base velocity, return coefficient, kinetic pressure, exposure, wind pressure |
| `actions.snow` | §3.4 | Ground load, shape/exposure coefficients, roof load |
| `actions.seismic` | §3.2 | Return period, damping, soil/topographic amplification, elastic response spectrum |
| `actions.temperature` | §3.5 | Temperature extremes, solar increment, uniform variation |
| `actions.fire` | §3.6 | Standard/hydrocarbon/external curves, design load, explosion, impact |
| `actions.combinations` | §2.5.3 | ψ coefficients, γ factors, SLU/SLE/seismic/exceptional combinations, seismic masses |

### Checks (NTC18 Cap. 4-7) — verification of solver output

| Module | Section | Description |
|--------|---------|-------------|
| `checks.concrete` | Cap. 4-5 | R.C. checks *(planned)* |
| `checks.steel` | Cap. 4 | Steel checks *(planned)* |
| `checks.masonry` | Cap. 7 | Masonry checks *(planned)* |
| `checks.geotechnical` | Cap. 6 | Geotechnical checks *(planned)* |

### Reference functions

| Function | Description |
|----------|-------------|
| `actions.loads.unit_weight(material)` | Unit weight from Tab. 3.1.I [kN/m³] |
| `actions.loads.partition_equivalent_load(weight_per_m)` | Equivalent distributed load §3.1.3 [kN/m²] |
| `actions.loads.variable_load(category)` | Variable loads (qk, Qk, Hk) from Tab. 3.1.II |
| `actions.loads.area_reduction_factor(area, psi_0)` | Reduction factor [3.1.1] |
| `actions.loads.floor_reduction_factor(n_floors, psi_0)` | Reduction factor [3.1.2] |
| `actions.wind.wind_base_velocity(zone, altitude)` | Base velocity v_b [m/s] — Tab. 3.3.I |
| `actions.wind.wind_return_coefficient(return_period)` | Return coefficient c_r — [3.3.3] |
| `actions.wind.wind_reference_velocity(zone, altitude, return_period)` | Reference velocity v_r [m/s] — [3.3.2] |
| `actions.wind.wind_kinetic_pressure(v_r)` | Kinetic pressure q_b [kN/m²] — [3.3.6] |
| `actions.wind.wind_exposure_coefficient(z, exposure_category, c_t)` | Exposure coefficient c_e — [3.3.7] |
| `actions.wind.wind_pressure(q_b, c_e, c_p, c_d)` | Wind pressure p [kN/m²] — [3.3.4] |
| `actions.wind.wind_friction_action(q_b, c_e, c_f)` | Friction action p_f [kN/m²] — [3.3.5] |

## Design principles

- **External solver**: pyntc produces input (actions) and verifies output (checks) — it is NOT a FEM solver
- **Traceability**: every public function is decorated with `@ntc_ref(article=..., table=..., formula=...)` linking back to NTC18
- **SI units**: all quantities in SI, documented in docstrings between `[]`
- **Minimal dependencies**: only `numpy` (core) and `scipy` (optional)

## Development

```bash
pip install -e ".[dev]"
pytest -v
pytest --cov=pyntc
```

## License

MIT
