"""Core utilities: normative traceability and SI constants."""
