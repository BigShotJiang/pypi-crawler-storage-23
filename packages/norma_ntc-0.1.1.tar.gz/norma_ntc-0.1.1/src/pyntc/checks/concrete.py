"""Verifiche calcestruzzo armato — NTC18 Cap. 4, Cap. 5.

Resistenze di calcolo, verifica a flessione, verifica a taglio,
verifica a punzonamento, stati limite di esercizio.
"""
