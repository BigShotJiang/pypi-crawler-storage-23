"""Ponti — NTC18 Cap. 5.

Azioni sui ponti stradali e ferroviari, verifiche di sicurezza,
prove di carico, monitoraggio.
"""
