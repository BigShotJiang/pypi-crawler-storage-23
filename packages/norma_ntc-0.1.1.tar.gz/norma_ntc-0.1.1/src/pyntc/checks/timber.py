"""Verifiche costruzioni di legno — NTC18 §4.4.

Proprieta' dei materiali, resistenze di calcolo, verifiche SLU
(trazione, compressione, flessione, taglio, instabilita'),
verifiche SLE (deformabilita').
"""
