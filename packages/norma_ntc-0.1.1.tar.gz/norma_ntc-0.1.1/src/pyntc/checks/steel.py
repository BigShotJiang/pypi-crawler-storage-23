"""Verifiche acciaio strutturale — NTC18 Cap. 4.

Classificazione sezioni, resistenza a trazione, compressione,
flessione, taglio, instabilita'.
"""
