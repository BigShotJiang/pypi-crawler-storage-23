"""Checks: verifiche strutturali a valle del solutore (NTC18 Cap. 4-7).

Moduli a valle del solutore FEM.
"""
