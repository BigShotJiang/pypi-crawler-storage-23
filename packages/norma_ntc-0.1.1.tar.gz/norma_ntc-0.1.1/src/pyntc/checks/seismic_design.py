"""Progettazione per azioni sismiche — NTC18 Cap. 7.

Regole generali, costruzioni in c.a., acciaio, composte,
legno, muratura. Criteri di gerarchia delle resistenze.
"""
