"""Verifiche muratura — NTC18 Cap. 7.

Resistenze di calcolo, verifica a compressione, pressoflessione,
taglio, ribaltamento.
"""
