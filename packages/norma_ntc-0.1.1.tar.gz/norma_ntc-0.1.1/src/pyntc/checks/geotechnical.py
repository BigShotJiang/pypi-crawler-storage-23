"""Verifiche geotecniche — NTC18 Cap. 6.

Capacita' portante fondazioni superficiali, fondazioni profonde,
stabilita' dei pendii, opere di sostegno.
"""
