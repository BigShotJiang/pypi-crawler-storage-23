# VideoSDK InworldAI Plugin

Agent Framework plugin for TTS services from InworldAI.

## Installation

```bash
pip install videosdk-plugins-inworldai
```
