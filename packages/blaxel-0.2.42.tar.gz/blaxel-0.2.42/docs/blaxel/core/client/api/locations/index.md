Module blaxel.core.client.api.locations
=======================================

Sub-modules
-----------
* blaxel.core.client.api.locations.list_locations