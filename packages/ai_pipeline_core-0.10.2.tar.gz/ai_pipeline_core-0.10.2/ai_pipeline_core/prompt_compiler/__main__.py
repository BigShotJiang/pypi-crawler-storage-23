"""Entry point for: python -m ai_pipeline_core.prompt_compiler render 'ClassName'."""

from .cli import main

raise SystemExit(main())
