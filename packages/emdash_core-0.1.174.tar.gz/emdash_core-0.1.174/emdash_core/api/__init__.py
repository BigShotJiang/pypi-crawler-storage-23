"""API routes for emdash-core."""

from .router import api_router

__all__ = ["api_router"]
