__version__ = "0.1.7"

from t_cinema_core.config import BaseServiceConfig
from pydantic_settings import SettingsConfigDict

__all__ = ["BaseServiceConfig", "SettingsConfigDict", "__version__"]
