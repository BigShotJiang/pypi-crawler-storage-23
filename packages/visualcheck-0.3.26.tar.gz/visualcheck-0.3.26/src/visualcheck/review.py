from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Iterable, Optional

from .utils import ensure_dir

VALID_REVIEW_STATES = {"APPROVED", "REJECTED", "PENDING"}


def _history_root(cfg: dict) -> Path:
    return Path(cfg["__root__"]) / "test_report" / cfg["project"] / "history"


def _review_file(cfg: dict) -> Path:
    return _history_root(cfg) / "reviews.json"


def _load_reviews(path: Path) -> dict:
    try:
        if path.exists():
            data = json.loads(path.read_text())
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {"items": {}}


def _save_reviews(path: Path, data: dict) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(data, indent=2))


def _key(view_id: str, snapshot_id: str) -> str:
    return f"{view_id}::{snapshot_id}"


def set_review(
    cfg: dict,
    *,
    view_id: str,
    snapshot_id: str,
    state: str,
    reviewer: str = "anonymous",
    comment: str = "",
    run_id: str | None = None,
) -> dict:
    st = str(state).strip().upper()
    if st not in VALID_REVIEW_STATES:
        raise ValueError(f"Invalid review state '{state}'. Valid: {sorted(VALID_REVIEW_STATES)}")

    p = _review_file(cfg)
    data = _load_reviews(p)
    items = data.setdefault("items", {})
    key = _key(view_id, snapshot_id)
    item = items.get(key) or {
        "view_id": view_id,
        "snapshot_id": snapshot_id,
        "approvals": {},
        "events": [],
    }
    approvals = item.setdefault("approvals", {})
    approvals[reviewer] = {
        "reviewer": reviewer,
        "state": st,
        "comment": str(comment or ""),
        "run_id": run_id,
        "updated_at": dt.datetime.now().isoformat(timespec="seconds"),
    }
    latest = {
        "view_id": view_id,
        "snapshot_id": snapshot_id,
        "state": st,
        "reviewer": reviewer,
        "comment": str(comment or ""),
        "run_id": run_id,
        "updated_at": dt.datetime.now().isoformat(timespec="seconds"),
    }
    item["latest"] = latest
    item.setdefault("events", []).append(latest)
    item["events"] = item["events"][-300:]
    items[key] = item
    _save_reviews(p, data)
    return latest


def list_reviews(cfg: dict) -> dict:
    p = _review_file(cfg)
    data = _load_reviews(p)
    out = []
    for it in (data.get("items") or {}).values():
        approvals = list((it.get("approvals") or {}).values())
        approved_by = sorted([a["reviewer"] for a in approvals if a.get("state") == "APPROVED"])
        rejected_by = sorted([a["reviewer"] for a in approvals if a.get("state") == "REJECTED"])
        row = {
            "view_id": it.get("view_id"),
            "snapshot_id": it.get("snapshot_id"),
            "latest": it.get("latest") or {},
            "approved_by": approved_by,
            "rejected_by": rejected_by,
            "approvals": approvals,
        }
        out.append(row)
    out.sort(
        key=lambda x: (
            (x.get("latest") or {}).get("updated_at") or "",
            x.get("view_id") or "",
            x.get("snapshot_id") or "",
        ),
        reverse=True,
    )
    items = out
    return {"review_file": str(p), "items": items}


def get_review(cfg: dict, *, view_id: str, snapshot_id: str) -> Optional[dict]:
    p = _review_file(cfg)
    data = _load_reviews(p)
    key = _key(view_id, snapshot_id)
    return (data.get("items") or {}).get(key)


def compute_review_gate(
    cfg: dict,
    *,
    rows: Iterable[dict],
    policy: Optional[dict] = None,
) -> dict:
    gate_cfg = dict((cfg.get("review_gate") or {}))
    if policy:
        gate_cfg.update(policy)
    enabled = bool(gate_cfg.get("enabled", False))
    if not enabled:
        return {"enabled": False, "status": "DISABLED", "summary": {"total": 0, "approved": 0, "pending": 0, "rejected": 0}, "items": []}

    min_approvals = max(1, int(gate_cfg.get("min_approvals", 1)))
    required_reviewers = [str(x).strip() for x in (gate_cfg.get("required_reviewers") or []) if str(x).strip()]
    require_all_changed_rows_reviewed = bool(gate_cfg.get("require_all_changed_rows_reviewed", True))

    review_list = list_reviews(cfg).get("items") or []
    review_index = {f"{r.get('view_id')}::{r.get('snapshot_id')}": r for r in review_list}

    targets = list(rows)
    if require_all_changed_rows_reviewed:
        targets = [r for r in targets if str(r.get("status")) in {"WARN", "FAIL", "NO_BASELINE", "QUARANTINED"}]

    items = []
    approved_n = 0
    pending_n = 0
    rejected_n = 0
    for r in targets:
        view_id = str(r.get("view_id"))
        snapshot_id = str(r.get("snapshot_id"))
        key = _key(view_id, snapshot_id)
        rv = review_index.get(key) or {}
        approvals = rv.get("approvals") or []
        approved_by = sorted([a.get("reviewer") for a in approvals if a.get("state") == "APPROVED" and a.get("reviewer")])
        rejected_by = sorted([a.get("reviewer") for a in approvals if a.get("state") == "REJECTED" and a.get("reviewer")])

        row_status = "PENDING"
        reasons = []
        if rejected_by:
            row_status = "REJECTED"
            reasons.append(f"rejected_by={','.join(rejected_by)}")
        else:
            if required_reviewers:
                missing = [rvw for rvw in required_reviewers if rvw not in approved_by]
                if missing:
                    reasons.append(f"missing_required={','.join(missing)}")
                else:
                    row_status = "APPROVED"
            else:
                if len(approved_by) >= min_approvals:
                    row_status = "APPROVED"
                else:
                    reasons.append(f"need_approvals={min_approvals},have={len(approved_by)}")

        if row_status == "APPROVED":
            approved_n += 1
        elif row_status == "REJECTED":
            rejected_n += 1
        else:
            pending_n += 1

        items.append(
            {
                "view_id": view_id,
                "snapshot_id": snapshot_id,
                "status": row_status,
                "approved_by": approved_by,
                "rejected_by": rejected_by,
                "reasons": reasons,
            }
        )

    status = "PASS" if not pending_n and not rejected_n else "BLOCKED"
    return {
        "enabled": True,
        "status": status,
        "summary": {"total": len(targets), "approved": approved_n, "pending": pending_n, "rejected": rejected_n},
        "policy": {
            "min_approvals": min_approvals,
            "required_reviewers": required_reviewers,
            "require_all_changed_rows_reviewed": require_all_changed_rows_reviewed,
        },
        "items": items,
    }
