from __future__ import annotations

import datetime as _dt
import os
import re
import webbrowser
from pathlib import Path
from typing import Iterable


def now_run_id() -> str:
    return _dt.datetime.now().strftime("%Y%m%d_%H%M%S")


_slug_re = re.compile(r"[^a-zA-Z0-9._-]+")


def slug(s: str) -> str:
    s = s.strip()
    s = _slug_re.sub("_", s)
    return s.strip("_")


def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def iter_pngs(root: Path) -> Iterable[Path]:
    for p in root.rglob("*.png"):
        if p.is_file():
            yield p


def env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return str(raw).strip().lower() in {"1", "true", "yes", "on", "y"}


def auto_open_report_from_env(report_html: str, disabled: bool = False) -> bool:
    if disabled or not env_bool("VISUALCHECK_OPEN_REPORT", default=False):
        return False
    try:
        p = Path(report_html).resolve()
        webbrowser.open_new_tab(p.as_uri())
        return True
    except Exception:
        return False
