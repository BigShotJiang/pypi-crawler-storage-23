from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
from PIL import Image
from skimage.metrics import structural_similarity as ssim

from .utils import ensure_dir, iter_pngs


def _load_rgb(p: Path) -> np.ndarray:
    img = Image.open(p).convert("RGB")
    return np.array(img)


def _resize_to(img: np.ndarray, size_wh: Tuple[int, int]) -> np.ndarray:
    w, h = size_wh
    return cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA)


def _fit_no_scale(img: np.ndarray, size_wh: Tuple[int, int]) -> np.ndarray:
    """Fit image to target size by top-left crop/pad without any scaling distortion."""
    w, h = size_wh
    src_h, src_w = img.shape[:2]
    out = np.zeros((h, w, img.shape[2]), dtype=img.dtype)
    copy_w = min(w, src_w)
    copy_h = min(h, src_h)
    out[:copy_h, :copy_w] = img[:copy_h, :copy_w]
    return out


def diff_images(
    baseline_png: Path,
    current_png: Path,
    diff_png: Path,
    resize_on_mismatch: bool,
    region_rules: Optional[List[dict]] = None,
    suggest_regions: bool = False,
    suggest_min_area: int = 2500,
    suggest_max_regions: int = 5,
) -> dict:
    b = _load_rgb(baseline_png)
    c = _load_rgb(current_png)

    warn = []
    if b.shape != c.shape:
        if resize_on_mismatch:
            warn.append(f"SIZE_MISMATCH_FIT_NO_SCALE baseline={b.shape} current={c.shape}")
            c = _fit_no_scale(c, (b.shape[1], b.shape[0]))
        else:
            warn.append(f"SIZE_MISMATCH baseline={b.shape} current={c.shape}")

    # compute pixel diff %
    diff = cv2.absdiff(b, c)
    diff_gray = cv2.cvtColor(diff, cv2.COLOR_RGB2GRAY)
    # consider pixel different if any channel differs by >0
    diff_mask = diff_gray > 0
    diff_pixels = int(np.count_nonzero(diff_mask))
    total_pixels = int(diff_mask.size)
    pixel_diff_pct = (diff_pixels / total_pixels) * 100.0 if total_pixels else 0.0

    # SSIM on grayscale
    b_gray = cv2.cvtColor(b, cv2.COLOR_RGB2GRAY)
    c_gray = cv2.cvtColor(c, cv2.COLOR_RGB2GRAY)
    ssim_val = float(ssim(b_gray, c_gray, data_range=255))

    region_results = []
    for idx, rr in enumerate(region_rules or []):
        x = int(rr.get("x", 0))
        y = int(rr.get("y", 0))
        w = int(rr.get("width", 0))
        h = int(rr.get("height", 0))
        if w <= 0 or h <= 0:
            continue
        x2 = min(x + w, b.shape[1])
        y2 = min(y + h, b.shape[0])
        x = max(0, x)
        y = max(0, y)
        if x >= x2 or y >= y2:
            continue
        rb = b[y:y2, x:x2]
        rc = c[y:y2, x:x2]
        rdiff = cv2.absdiff(rb, rc)
        rgray = cv2.cvtColor(rdiff, cv2.COLOR_RGB2GRAY)
        rmask = rgray > 0
        rtotal = int(rmask.size)
        rchanged = int(np.count_nonzero(rmask))
        r_pixel_diff_pct = (rchanged / rtotal) * 100.0 if rtotal else 0.0
        rb_gray = cv2.cvtColor(rb, cv2.COLOR_RGB2GRAY)
        rc_gray = cv2.cvtColor(rc, cv2.COLOR_RGB2GRAY)
        r_ssim = float(ssim(rb_gray, rc_gray, data_range=255))
        region_results.append(
            {
                "index": idx,
                "name": rr.get("name") or f"region_{idx}",
                "x": x,
                "y": y,
                "width": x2 - x,
                "height": y2 - y,
                "pixel_diff_pct": r_pixel_diff_pct,
                "ssim": r_ssim,
                "max_pixel_diff_pct": rr.get("max_pixel_diff_pct"),
                "min_ssim": rr.get("min_ssim"),
            }
        )

    suggested_regions: List[dict] = []
    if suggest_regions:
        cc = cv2.connectedComponentsWithStats(diff_mask.astype(np.uint8), connectivity=8)
        _, _, stats, _ = cc
        areas = []
        for i in range(1, stats.shape[0]):
            x, y, w, h, area = stats[i]
            if int(area) < int(suggest_min_area):
                continue
            areas.append((int(area), int(x), int(y), int(w), int(h)))
        areas.sort(reverse=True)
        for area, x, y, w, h in areas[: max(0, int(suggest_max_regions))]:
            x2 = min(x + w, b.shape[1])
            y2 = min(y + h, b.shape[0])
            x = max(0, x)
            y = max(0, y)
            if x >= x2 or y >= y2:
                continue
            rb = b[y:y2, x:x2]
            rc = c[y:y2, x:x2]
            rdiff = cv2.absdiff(rb, rc)
            rgray = cv2.cvtColor(rdiff, cv2.COLOR_RGB2GRAY)
            rmask = rgray > 0
            rtotal = int(rmask.size)
            rchanged = int(np.count_nonzero(rmask))
            r_pixel_diff_pct = (rchanged / rtotal) * 100.0 if rtotal else 0.0
            rb_gray = cv2.cvtColor(rb, cv2.COLOR_RGB2GRAY)
            rc_gray = cv2.cvtColor(rc, cv2.COLOR_RGB2GRAY)
            r_ssim = float(ssim(rb_gray, rc_gray, data_range=255))
            suggested_regions.append(
                {
                    "x": x,
                    "y": y,
                    "width": x2 - x,
                    "height": y2 - y,
                    "area": area,
                    "pixel_diff_pct": r_pixel_diff_pct,
                    "ssim": r_ssim,
                }
            )

    # diff heatmap
    heat = cv2.normalize(diff_gray, None, 0, 255, cv2.NORM_MINMAX)
    heat = cv2.applyColorMap(heat.astype(np.uint8), cv2.COLORMAP_JET)
    overlay = cv2.addWeighted(c[:, :, ::-1], 0.65, heat, 0.35, 0)  # BGR
    ensure_dir(diff_png.parent)
    cv2.imwrite(str(diff_png), overlay)

    return {
        "pixel_diff_pct": pixel_diff_pct,
        "ssim": ssim_val,
        "warnings": warn,
        "region_results": region_results,
        "suggested_regions": suggested_regions,
    }


def diff_folders(
    baseline_dir: Path,
    current_dir: Path,
    out_dir: Path,
    thresholds: Dict[str, float],
    resize_on_mismatch: bool,
    mismatch_level: str,
) -> dict:
    ensure_dir(out_dir)
    results = []

    base_pngs = list(iter_pngs(baseline_dir))
    base_index = {p.relative_to(baseline_dir).as_posix(): p for p in base_pngs}

    for cur in iter_pngs(current_dir):
        rel = cur.relative_to(current_dir).as_posix()
        base = base_index.get(rel)
        if not base:
            results.append({"rel": rel, "status": "NO_BASELINE", "current": str(cur)})
            continue

        diff_png = out_dir / "diff" / rel
        metrics = diff_images(base, cur, diff_png, resize_on_mismatch=resize_on_mismatch)

        mismatch = (metrics["pixel_diff_pct"] > thresholds["max_pixel_diff_pct"]) or (
            metrics["ssim"] < thresholds["min_ssim"]
        )
        status = "PASS"
        if mismatch:
            status = mismatch_level

        results.append(
            {
                "rel": rel,
                "status": status,
                "baseline": str(base),
                "current": str(cur),
                "diff": str(diff_png),
                **metrics,
            }
        )

    report_json = out_dir / "report.json"
    out = {
        "baseline_dir": str(baseline_dir),
        "current_dir": str(current_dir),
        "out_dir": str(out_dir),
        "thresholds": thresholds,
        "resize_on_mismatch": resize_on_mismatch,
        "mismatch_level": mismatch_level,
        "results": results,
    }
    report_json.write_text(json.dumps(out, indent=2))
    return out
