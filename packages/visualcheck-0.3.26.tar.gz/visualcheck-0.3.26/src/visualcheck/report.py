from __future__ import annotations

import json
import os
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET

from jinja2 import Environment, FileSystemLoader, select_autoescape

from .utils import ensure_dir


def _env() -> Environment:
    tpl_dir = Path(__file__).parent / "templates"
    return Environment(
        loader=FileSystemLoader(str(tpl_dir)),
        autoescape=select_autoescape(["html"]),
    )


def write_junit(out_dir: Path, report: dict) -> str:
    results = report.get("results") or []
    failures = sum(1 for r in results if r.get("status") in {"FAIL", "NO_BASELINE"})
    warnings = sum(1 for r in results if r.get("status") in {"WARN", "QUARANTINED"})

    suite = ET.Element(
        "testsuite",
        name=f"{report.get('project', 'visualcheck')}.{report.get('suite', 'suite')}",
        tests=str(len(results)),
        failures=str(failures),
        errors="0",
    )
    if warnings:
        suite.set("skipped", str(warnings))

    for r in results:
        case = ET.SubElement(
            suite,
            "testcase",
            classname=f"{report.get('project', 'visualcheck')}.{r.get('view_id', 'view')}",
            name=str(r.get("snapshot_id", "snapshot")),
        )
        if r.get("status") in {"FAIL", "NO_BASELINE"}:
            msg = f"status={r.get('status')} pixel_diff_pct={r.get('pixel_diff_pct')} ssim={r.get('ssim')}"
            fail = ET.SubElement(case, "failure", message=msg)
            fail.text = f"baseline={r.get('baseline')} current={r.get('current')} diff={r.get('diff')}"
        elif r.get("status") in {"WARN", "QUARANTINED"}:
            ET.SubElement(case, "skipped", message="warning-threshold-breach")

    xml_path = out_dir / "report.junit.xml"
    ET.ElementTree(suite).write(xml_path, encoding="utf-8", xml_declaration=True)
    return str(xml_path)


def _load_json(path: Path, default):
    try:
        if path.exists():
            return json.loads(path.read_text())
    except Exception:
        pass
    return default


def _project_root_from_report_dir(report_dir: Path) -> Path | None:
    # .../test_report/<project>/visual_runs/<run_id>/report
    try:
        if report_dir.name != "report":
            return None
        run_dir = report_dir.parent
        if run_dir.parent.name != "visual_runs":
            return None
        return run_dir.parent.parent
    except Exception:
        return None


def _yaml_group_name(data: dict) -> str:
    """Resolve a stable grouping key from yaml config path for dashboard."""
    cfg_yaml = data.get("config_yaml")
    if isinstance(cfg_yaml, str):
        p = Path(cfg_yaml)
        if p.suffix.lower() in {".yaml", ".yml"}:
            return p.name

    cfg = data.get("config")
    if isinstance(cfg, str):
        p = Path(cfg)
        if p.suffix.lower() in {".yaml", ".yml"}:
            return p.name
    return "unknown.yaml"


def write_dashboard(project_dir: Path) -> str:
    runs_root = project_dir / "visual_runs"
    history_dir = project_dir / "history"
    trends = _load_json(history_dir / "trends.json", {"runs": []})
    trend_runs = list(reversed((trends.get("runs") or [])[-30:]))

    run_rows = []
    if runs_root.exists():
        for run_dir in sorted([p for p in runs_root.iterdir() if p.is_dir()], key=lambda p: p.name, reverse=True):
            rj = run_dir / "report" / "report.json"
            data = _load_json(rj, {})
            cfg_name = _yaml_group_name(data)
            run_rows.append(
                {
                    "run_id": run_dir.name,
                    "status": data.get("status", "UNKNOWN"),
                    "generated_at": data.get("generated_at", "-"),
                    "env": data.get("env", "-"),
                    "suite": data.get("suite", "-"),
                    "config_name": cfg_name,
                    "report_rel": f"visual_runs/{run_dir.name}/report/report.html",
                }
            )

    group_map = {}
    for r in run_rows:
        key = r.get("config_name") or "-"
        if key not in group_map:
            group_map[key] = {
                "group": key,
                "total_runs": 0,
                "latest_run_id": r["run_id"],
                "latest_status": r["status"],
                "latest_generated_at": r["generated_at"],
                "latest_env": r["env"],
                "latest_suite": r["suite"],
                "latest_report_rel": r["report_rel"],
                "status_counts": Counter(),
            }
        g = group_map[key]
        g["total_runs"] += 1
        g["status_counts"][r["status"]] += 1
    group_rows = sorted(
        group_map.values(),
        key=lambda x: str(x.get("latest_run_id", "")),
        reverse=True,
    )
    latest_run = run_rows[0] if run_rows else None
    latest_report_data = {}
    if latest_run:
        latest_report_data = _load_json(
            runs_root / latest_run["run_id"] / "report" / "report.json",
            {},
        )
    latest_top_regressions = list(latest_report_data.get("top_regressions") or [])[:10]
    latest_top_unstable = list(latest_report_data.get("top_unstable") or [])[:10]

    html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>visualcheck dashboard - {project_dir.name}</title>
  <style>
    :root {{
      --bg1: #edf4ff;
      --bg2: #f7fffb;
      --panel: #ffffff;
      --line: #d2def2;
      --text: #12213b;
      --muted: #415677;
      --pass: #127c42;
      --warn: #9a5b00;
      --fail: #b42318;
      --quar: #6f42c1;
      --nobase: #4b5565;
    }}
    body {{
      font-family: "IBM Plex Sans", "Segoe UI", Arial, sans-serif;
      margin: 0;
      padding: 18px;
      background:
        radial-gradient(circle at 0% 0%, #dce9ff 0, transparent 40%),
        radial-gradient(circle at 100% 0%, #e4fff0 0, transparent 35%),
        linear-gradient(180deg, var(--bg1), var(--bg2));
      color: var(--text);
    }}
    h1, h2 {{ margin: 0 0 10px 0; }}
    .card {{
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 12px;
      padding: 12px;
      margin-bottom: 12px;
      box-shadow: 0 8px 20px rgba(17, 44, 96, 0.07);
    }}
    table {{ width: 100%; border-collapse: collapse; background: var(--panel); border: 1px solid var(--line); border-radius: 12px; overflow: hidden; }}
    th, td {{ border-bottom: 1px solid #e7edf8; padding: 8px; font-size: 13px; text-align: left; }}
    th {{ background: #eff5ff; color: #264069; }}
    .controls {{ display: flex; gap: 8px; flex-wrap: wrap; margin: 8px 0 10px; }}
    .controls .ctrl {{ border: 1px solid #bfd0ef; border-radius: 8px; padding: 7px 10px; font-size: 12px; background: #fff; color: #1a325d; min-width: 170px; }}
    .scroll-box {{ max-height: 430px; overflow: auto; border: 1px solid var(--line); border-radius: 10px; }}
    .scroll-box table {{ border: 0; }}
    .chart-wrap {{ border: 1px solid var(--line); border-radius: 10px; padding: 10px; background: #fff; }}
    #trendChart {{ width: 100%; height: 220px; display: block; }}
    .trend-help {{ color: #385271; font-size: 12px; margin: 4px 0 8px; }}
    .trend-legend {{ display: flex; gap: 12px; flex-wrap: wrap; margin: 6px 0 8px; }}
    .trend-legend-item {{ display: inline-flex; align-items: center; gap: 6px; font-size: 12px; color: #2a3e5a; }}
    .trend-swatch {{ width: 10px; height: 10px; border-radius: 2px; display: inline-block; }}
    .trend-details {{ font-size: 12px; color: #1f3b61; background: #f5f9ff; border: 1px solid #d8e6ff; border-radius: 8px; padding: 8px; margin-top: 8px; }}
    .PASS {{ color: var(--pass); font-weight: 700; }}
    .WARN {{ color: var(--warn); font-weight: 700; }}
    .FAIL {{ color: var(--fail); font-weight: 700; }}
    .QUARANTINED {{ color: var(--quar); font-weight: 700; }}
    .NO_BASELINE {{ color: var(--nobase); font-weight: 700; }}
    tr.FAIL td {{ background: #fff5f5; }}
    tr.WARN td {{ background: #fff9ee; }}
    tr.PASS td {{ background: #f3fcf6; }}
    tr.QUARANTINED td {{ background: #f7f2ff; }}
    tr.NO_BASELINE td {{ background: #f5f6f8; }}
    code {{ background: #f2f6ff; padding: 1px 4px; border-radius: 4px; }}
  </style>
</head>
<body>
  <div class="card">
    <h1>visualcheck dashboard</h1>
    <div><b>Project:</b> <code>{project_dir.name}</code></div>
    <div style="margin-top:6px;">Open latest report quickly and inspect recent run history from one place.</div>
    {
        f"<div style='margin-top:10px;'><b>Latest report:</b> <a href='{latest_run['report_rel']}'><code>{latest_run['run_id']}</code></a> "
        f"({latest_run['status']} | {latest_run['generated_at']})</div>"
        if latest_run else
        "<div style='margin-top:10px;'><b>Latest report:</b> No runs found yet.</div>"
    }
  </div>

  <div class="card">
    <h2>Run Groups (by config file)</h2>
    <div style="margin-bottom:8px;color:#49607f;font-size:13px;">Easy view for non-technical users: how many times each config ran and which report is latest.</div>
    <div class="controls">
      <input id="groupSearch" class="ctrl" type="search" placeholder="Search config/env/suite..." />
      <select id="groupSort" class="ctrl">
        <option value="latest_desc">Sort groups: latest run newest</option>
        <option value="latest_asc">Sort groups: latest run oldest</option>
        <option value="runs_desc">Sort groups: total runs high to low</option>
        <option value="runs_asc">Sort groups: total runs low to high</option>
        <option value="name_asc">Sort groups: config A to Z</option>
      </select>
    </div>
    <div class="scroll-box">
    <table id="groupTable">
      <thead><tr><th>Config file</th><th>Total runs</th><th>Latest run</th><th>Status</th><th>Generated</th><th>Env</th><th>Suite</th><th>Status split</th><th>Latest report</th></tr></thead>
      <tbody>
        {''.join(
            f"<tr data-runs='{g['total_runs']}' data-latest='{g['latest_run_id']}' data-name='{g['group'].lower()}'><td><code>{g['group']}</code></td><td><b>{g['total_runs']}</b></td><td><code>{g['latest_run_id']}</code></td><td class='{g['latest_status']}'>{g['latest_status']}</td><td>{g['latest_generated_at']}</td><td>{g['latest_env']}</td><td>{g['latest_suite']}</td><td><code>{json.dumps(dict(g['status_counts']), separators=(',',':'))}</code></td><td><a href='{g['latest_report_rel']}'>open latest</a></td></tr>"
            for g in group_rows
        ) or "<tr><td colspan='9'>No grouped run data yet.</td></tr>"}
      </tbody>
    </table>
    </div>
  </div>

  <div class="card">
    <h2>Latest Runs</h2>
    <div class="controls">
      <input id="runSearch" class="ctrl" type="search" placeholder="Search run/config/env/suite..." />
      <select id="runStatus" class="ctrl">
        <option value="ALL">Status: ALL</option>
        <option value="PASS">PASS</option>
        <option value="WARN">WARN</option>
        <option value="FAIL">FAIL</option>
        <option value="QUARANTINED">QUARANTINED</option>
        <option value="NO_BASELINE">NO_BASELINE</option>
      </select>
      <select id="runSort" class="ctrl">
        <option value="run_desc">Sort runs: newest first</option>
        <option value="run_asc">Sort runs: oldest first</option>
        <option value="name_asc">Sort runs: config A to Z</option>
        <option value="status">Sort runs: status severity</option>
      </select>
    </div>
    <div class="scroll-box">
    <table id="runTable">
      <thead><tr><th>Run ID</th><th>Status</th><th>Generated</th><th>Env</th><th>Suite</th><th>Config</th><th>Report</th></tr></thead>
      <tbody>
        {''.join(
            f"<tr data-run='{r['run_id']}' data-status='{r['status']}' data-config='{r['config_name'].lower()}'><td><code>{r['run_id']}</code></td><td class='{r['status']}'>{r['status']}</td><td>{r['generated_at']}</td><td>{r['env']}</td><td>{r['suite']}</td><td><code>{r['config_name']}</code></td><td><a href='{r['report_rel']}'>open report</a></td></tr>"
            for r in run_rows
        ) or "<tr><td colspan='7'>No runs found yet.</td></tr>"}
      </tbody>
    </table>
    </div>
  </div>

  <div class="card">
    <h2>History Trends</h2>
    <div class="chart-wrap" style="margin-bottom:10px;">
      <div class="trend-help">How to read: each bar is one run (newest at left). Stacked colors show PASS/WARN/FAIL/QUARANTINED/NO_BASELINE counts.</div>
      <div class="trend-legend">
        <span class="trend-legend-item"><span class="trend-swatch" style="background:#2aa85f"></span>PASS</span>
        <span class="trend-legend-item"><span class="trend-swatch" style="background:#cc8a11"></span>WARN</span>
        <span class="trend-legend-item"><span class="trend-swatch" style="background:#d64545"></span>FAIL</span>
        <span class="trend-legend-item"><span class="trend-swatch" style="background:#7b57d1"></span>QUARANTINED</span>
        <span class="trend-legend-item"><span class="trend-swatch" style="background:#6d7582"></span>NO_BASELINE</span>
      </div>
      <canvas id="trendChart" width="1300" height="220"></canvas>
      <div id="trendDetails" class="trend-details">Hover a bar to see exact run details. Click a bar to jump to that row in the table.</div>
    </div>
    <div class="scroll-box">
    <table id="trendTable">
      <thead><tr><th>Run ID</th><th>Status</th><th>Generated</th><th>Commit</th><th>Branch</th><th>Counts</th></tr></thead>
      <tbody>
        {''.join(
            f"<tr id='trend-row-{i}'><td><code>{r.get('run_id','-')}</code></td><td class='{r.get('status','')}'>{r.get('status','-')}</td><td>{r.get('generated_at','-')}</td><td><code>{r.get('commit','-')}</code></td><td>{r.get('branch','-')}</td><td><code>{json.dumps(r.get('counts',{}), separators=(',',':'))}</code></td></tr>"
            for i, r in enumerate(trend_runs)
        ) or "<tr><td colspan='6'>No trend data yet.</td></tr>"}
      </tbody>
    </table>
    </div>
  </div>

  <div class="card">
    <h2>Top Regressions (latest run)</h2>
    <div style="margin-bottom:8px;color:#49607f;font-size:13px;">
      Source run: <code>{latest_run['run_id'] if latest_run else '-'}</code>
    </div>
    <div class="scroll-box">
    <table>
      <thead><tr><th>Snapshot</th><th>View</th><th>Status</th><th>Issue</th><th>Pixel diff %</th><th>SSIM</th><th>Owner</th></tr></thead>
      <tbody>
        {''.join(
            f"<tr><td><code>{r.get('snapshot_id','-')}</code></td><td><code>{r.get('view_id','-')}</code></td><td class='{r.get('status','')}'>{r.get('status','-')}</td><td>{r.get('issue_summary','-')}</td><td>{float(r.get('pixel_diff_pct') or 0):.4f}</td><td>{float(r.get('ssim') or 0):.6f}</td><td>{r.get('owner') or '-'}</td></tr>"
            for r in latest_top_regressions
        ) or "<tr><td colspan='7'>No regression data yet.</td></tr>"}
      </tbody>
    </table>
    </div>
  </div>

  <div class="card">
    <h2>Top Unstable Snapshots</h2>
    <div style="margin-bottom:8px;color:#49607f;font-size:13px;">
      Source run: <code>{latest_run['run_id'] if latest_run else '-'}</code>
    </div>
    <div class="scroll-box">
    <table>
      <thead><tr><th>Snapshot key</th><th>Flake score</th><th>Flaky runs</th><th>Total runs</th></tr></thead>
      <tbody>
        {''.join(
            f"<tr><td><code>{u.get('key','-')}</code></td><td>{float(u.get('flake_score') or 0):.4f}</td><td>{int(u.get('flaky_runs') or 0)}</td><td>{int(u.get('total_runs') or 0)}</td></tr>"
            for u in latest_top_unstable
        ) or "<tr><td colspan='4'>No instability data yet.</td></tr>"}
      </tbody>
    </table>
    </div>
  </div>
  <script>
    (function() {{
      const statusRank = {{ FAIL: 5, NO_BASELINE: 4, WARN: 3, QUARANTINED: 2, PASS: 1 }};
      const groupTable = document.getElementById("groupTable");
      const runTable = document.getElementById("runTable");
      const groupRows = groupTable ? Array.from(groupTable.querySelectorAll("tbody tr")).filter((r) => r.children.length > 1) : [];
      const runRows = runTable ? Array.from(runTable.querySelectorAll("tbody tr")).filter((r) => r.children.length > 1) : [];

      const groupSearch = document.getElementById("groupSearch");
      const groupSort = document.getElementById("groupSort");
      function applyGroups() {{
        if (!groupTable) return;
        const q = (groupSearch?.value || "").trim().toLowerCase();
        const sort = groupSort?.value || "latest_desc";
        const arr = [...groupRows];
        arr.sort((a, b) => {{
          if (sort === "runs_asc") return Number(a.dataset.runs || 0) - Number(b.dataset.runs || 0);
          if (sort === "latest_desc") return String(b.dataset.latest || "").localeCompare(String(a.dataset.latest || ""));
          if (sort === "latest_asc") return String(a.dataset.latest || "").localeCompare(String(b.dataset.latest || ""));
          if (sort === "name_asc") return String(a.dataset.name || "").localeCompare(String(b.dataset.name || ""));
          return Number(b.dataset.runs || 0) - Number(a.dataset.runs || 0);
        }});
        arr.forEach((r) => groupTable.querySelector("tbody").appendChild(r));
        arr.forEach((r) => {{
          const ok = !q || r.textContent.toLowerCase().includes(q);
          r.style.display = ok ? "" : "none";
        }});
      }}

      const runSearch = document.getElementById("runSearch");
      const runStatus = document.getElementById("runStatus");
      const runSort = document.getElementById("runSort");
      function applyRuns() {{
        if (!runTable) return;
        const q = (runSearch?.value || "").trim().toLowerCase();
        const status = runStatus?.value || "ALL";
        const sort = runSort?.value || "run_desc";
        const arr = [...runRows];
        arr.sort((a, b) => {{
          if (sort === "run_asc") return String(a.dataset.run || "").localeCompare(String(b.dataset.run || ""));
          if (sort === "name_asc") return String(a.dataset.config || "").localeCompare(String(b.dataset.config || ""));
          if (sort === "status") return (statusRank[b.dataset.status || ""] || 0) - (statusRank[a.dataset.status || ""] || 0);
          return String(b.dataset.run || "").localeCompare(String(a.dataset.run || ""));
        }});
        arr.forEach((r) => runTable.querySelector("tbody").appendChild(r));
        arr.forEach((r) => {{
          const statusOk = status === "ALL" || (r.dataset.status === status);
          const searchOk = !q || r.textContent.toLowerCase().includes(q);
          r.style.display = statusOk && searchOk ? "" : "none";
        }});
      }}

      groupSearch?.addEventListener("input", applyGroups);
      groupSort?.addEventListener("change", applyGroups);
      runSearch?.addEventListener("input", applyRuns);
      runStatus?.addEventListener("change", applyRuns);
      runSort?.addEventListener("change", applyRuns);
      applyGroups();
      applyRuns();

      const trendRuns = {json.dumps(trend_runs)};
      const canvas = document.getElementById("trendChart");
      const trendDetails = document.getElementById("trendDetails");
      const trendTable = document.getElementById("trendTable");
      if (canvas && trendRuns.length) {{
        const ctx = canvas.getContext("2d");
        const W = canvas.width;
        const H = canvas.height;
        const pad = 32;
        const keys = ["PASS", "WARN", "FAIL", "QUARANTINED", "NO_BASELINE"];
        const bars = [];
        ctx.clearRect(0, 0, W, H);
        const maxTotal = Math.max(...trendRuns.map((r) => {{
          const c = r.counts || {{}};
          return (c.PASS || 0) + (c.WARN || 0) + (c.FAIL || 0) + (c.QUARANTINED || 0) + (c.NO_BASELINE || 0);
        }}), 1);
        const colors = {{
          PASS: "#2aa85f",
          WARN: "#cc8a11",
          FAIL: "#d64545",
          QUARANTINED: "#7b57d1",
          NO_BASELINE: "#6d7582"
        }};
        const n = trendRuns.length;
        const barW = Math.max(6, Math.floor((W - pad * 2) / Math.max(1, n) * 0.72));
        function totalFor(run) {{
          const c = run.counts || {{}};
          return Number(c.PASS || 0) + Number(c.WARN || 0) + Number(c.FAIL || 0) + Number(c.QUARANTINED || 0) + Number(c.NO_BASELINE || 0);
        }}
        trendRuns.forEach((run, i) => {{
          const x = pad + Math.floor((W - pad * 2) * (i + 0.5) / n) - Math.floor(barW / 2);
          let y = H - pad;
          keys.forEach((k) => {{
            const v = Number((run.counts || {{}})[k] || 0);
            if (!v) return;
            const h = Math.max(1, Math.round((v / maxTotal) * (H - pad * 2)));
            y -= h;
            ctx.fillStyle = colors[k];
            ctx.fillRect(x, y, barW, h);
          }});
          bars.push({{ index: i, x, w: barW, run, total: totalFor(run) }});
        }});
        ctx.strokeStyle = "#9bb3dd";
        ctx.beginPath();
        ctx.moveTo(pad, H - pad);
        ctx.lineTo(W - pad, H - pad);
        ctx.stroke();

        function findBar(clientX) {{
          const rect = canvas.getBoundingClientRect();
          const sx = (clientX - rect.left) * (canvas.width / rect.width);
          return bars.find((b) => sx >= b.x && sx <= b.x + b.w) || null;
        }}
        function countsText(run) {{
          const c = run.counts || {{}};
          return keys.map((k) => `${{k}}=${{Number(c[k] || 0)}}`).join(", ");
        }}
        function showBarDetails(bar) {{
          if (!trendDetails || !bar) return;
          trendDetails.textContent = `Run=${{bar.run.run_id || "-"}} | Status=${{bar.run.status || "-"}} | Total checks=${{bar.total}} | ${{countsText(bar.run)}}`;
        }}
        function focusTrendRow(index) {{
          if (!trendTable) return;
          trendTable.querySelectorAll("tbody tr").forEach((row) => {{
            row.style.outline = "";
            row.style.background = "";
          }});
          const row = document.getElementById(`trend-row-${{index}}`);
          if (!row) return;
          row.style.outline = "2px solid #4f7edc";
          row.style.background = "#eef4ff";
          row.scrollIntoView({{ behavior: "smooth", block: "nearest" }});
        }}
        canvas.addEventListener("mousemove", (e) => {{
          const bar = findBar(e.clientX);
          if (bar) showBarDetails(bar);
        }});
        canvas.addEventListener("mouseleave", () => {{
          if (trendDetails) trendDetails.textContent = "Hover a bar to see exact run details. Click a bar to jump to that row in the table.";
        }});
        canvas.addEventListener("click", (e) => {{
          const bar = findBar(e.clientX);
          if (!bar) return;
          showBarDetails(bar);
          focusTrendRow(bar.index);
        }});
      }}
    }})();
  </script>
</body>
</html>
"""
    dashboard_path = project_dir / "dashboard.html"
    dashboard_path.write_text(html, encoding="utf-8")
    return str(dashboard_path)


def write_report(out_dir: Path, report: dict) -> dict:
    ensure_dir(out_dir)
    (out_dir / "report.json").write_text(json.dumps(report, indent=2))

    env = _env()
    tpl = env.get_template("report.html")

    dashboard_path = None
    dashboard_rel = None
    project_dir = _project_root_from_report_dir(out_dir)
    if project_dir is not None:
        dashboard_path = write_dashboard(project_dir)
        try:
            dashboard_rel = os.path.relpath(Path(dashboard_path), out_dir)
        except Exception:
            dashboard_rel = None

    render_data = dict(report)
    render_data["dashboard_rel"] = dashboard_rel
    html = tpl.render(**render_data)
    html_path = out_dir / "report.html"
    html_path.write_text(html, encoding="utf-8")
    junit_path = write_junit(out_dir, report)
    return {
        "report_json": str(out_dir / "report.json"),
        "report_html": str(html_path),
        "report_junit_xml": junit_path,
        "dashboard_html": dashboard_path,
    }
