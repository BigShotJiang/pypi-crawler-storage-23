from __future__ import annotations

import datetime as dt
import json
import shutil
import subprocess
from collections import Counter
from pathlib import Path
from typing import Optional

from rich.console import Console

from .baseline import baseline_a11y_path, ensure_runtime_baseline, resolve_baseline, run_root
from .capture import capture_all, capture_selected
from .diff_engine import diff_images
from .figma import figma_frame_meta
from .report import write_report
from .review import compute_review_gate, list_reviews
from .review_server import ensure_review_server
from .utils import auto_open_report_from_env, ensure_dir, now_run_id, slug

console = Console()


def _log_info(msg: str) -> None:
    console.print(f"[cyan][visualcheck][/cyan] {msg}")


def _log_warn(msg: str) -> None:
    console.print(f"[yellow][visualcheck][/yellow] {msg}")


def _fmt_metrics(row: dict) -> str:
    px = row.get("pixel_diff_pct")
    ssim = row.get("ssim")
    parts = []
    if px is not None:
        parts.append(f"pixel_diff={float(px):.4f}%")
    if ssim is not None:
        parts.append(f"ssim={float(ssim):.6f}")
    return ", ".join(parts) if parts else "metrics=n/a"


def _resolve_workers(workers: int) -> int:
    return max(1, int(workers))


def _load_json(path: Path, default: dict) -> dict:
    try:
        if path.exists():
            return json.loads(path.read_text())
    except Exception:
        pass
    return dict(default)


def _save_json(path: Path, data: dict) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(data, indent=2))


def _git_meta(root: Path) -> dict:
    out = {"commit": "unknown", "branch": "unknown"}
    try:
        out["commit"] = subprocess.check_output(
            ["git", "-C", str(root), "rev-parse", "--short", "HEAD"], text=True
        ).strip()
        out["branch"] = subprocess.check_output(
            ["git", "-C", str(root), "rev-parse", "--abbrev-ref", "HEAD"], text=True
        ).strip()
    except Exception:
        pass
    return out


def _status_rank(status: str) -> int:
    order = {"PASS": 0, "QUARANTINED": 1, "WARN": 2, "FAIL": 3, "NO_BASELINE": 4}
    return order.get(status, 9)


def _choose_consensus(attempts: list[dict], mode: str) -> dict:
    if not attempts:
        return {}
    if mode == "median":
        ranked = sorted(
            attempts,
            key=lambda a: (_status_rank(a.get("status", "")), float(a.get("severity_score") or 0.0)),
        )
        return ranked[len(ranked) // 2]
    if mode == "majority":
        counts = Counter(a.get("status") for a in attempts)
        # Break ties by stricter status.
        winner = sorted(counts.items(), key=lambda kv: (-kv[1], _status_rank(str(kv[0]))))[0][0]
        cand = [a for a in attempts if a.get("status") == winner]
        return sorted(cand, key=lambda a: float(a.get("severity_score") or 0.0))[0]
    # best
    return sorted(
        attempts,
        key=lambda a: (_status_rank(a.get("status", "")), float(a.get("severity_score") or 0.0)),
    )[0]


def _build_issue_summary(row: dict) -> tuple[str, str, float]:
    status = row.get("status")
    px = float(row.get("pixel_diff_pct") or 0.0)
    ssim = float(row.get("ssim") or 1.0)
    thr = row.get("thresholds") or {}
    max_px = float(thr.get("max_pixel_diff_pct", 0.0))
    min_ssim = float(thr.get("min_ssim", 1.0))
    warnings = row.get("warnings") or []

    if status == "NO_BASELINE":
        return ("No baseline available", "Create/approve a baseline first.", 100.0)
    if status == "PASS":
        return ("Within thresholds", "No action needed.", 0.0)

    reasons = []
    if px > max_px:
        reasons.append(f"pixel diff is +{(px - max_px):.3f}% above threshold")
    if ssim < min_ssim:
        reasons.append(f"visual similarity is {(min_ssim - ssim):.4f} below threshold")
    if any("SIZE_MISMATCH" in w for w in warnings):
        reasons.append("baseline/current size mismatch")
    if row.get("region_failures"):
        reasons.append(f"{len(row.get('region_failures') or [])} strict regions failed")
    if row.get("flaky"):
        reasons.append("result is unstable across reruns")
    if any("LAYOUT_SHIFT_SUSPECTED" in w for w in warnings):
        reasons.append("layout appears unstable between attempts")

    issue = "; ".join(reasons) if reasons else "threshold check failed"
    action = "Open slider + diff image and approve only if expected."
    if row.get("flaky"):
        action = "Mark snapshot quarantined or increase stability waits/retries."
    if any("SIZE_MISMATCH" in w for w in warnings):
        action = "Verify viewport/device config and baseline dimensions."
    if row.get("quarantined"):
        action = "Snapshot is quarantined; keep monitoring and fix root cause."

    score = max(0.0, (px - max_px) * 10.0) + max(0.0, (min_ssim - ssim) * 100.0)
    if row.get("flaky"):
        score += 25.0
    return (issue, action, score)


def _root_cause_hint(row: dict) -> str:
    warns = row.get("warnings") or []
    if any("SIZE_MISMATCH" in w for w in warns):
        return "Viewport/device mismatch or responsive layout break."
    if row.get("region_failures"):
        return "Critical UI region changed beyond strict threshold."
    if row.get("flaky"):
        return "Likely dynamic content, animation, or late rendering."
    if row.get("pixel_diff_pct", 0) and row.get("ssim", 1) < 0.98:
        return "Large visual delta; likely real UI change."
    return "Minor visual variance."


def _root_cause_tags(row: dict) -> list[str]:
    tags: list[str] = []
    warns = row.get("warnings") or []
    if any("SIZE_MISMATCH" in w for w in warns):
        tags.append("SIZE_MISMATCH")
    if row.get("region_failures"):
        tags.append("REGION_FAIL")
    if row.get("flaky"):
        tags.append("FLAKY")
    if any("LAYOUT_SHIFT_SUSPECTED" in w for w in warns):
        tags.append("LAYOUT_SHIFT")
    if float(row.get("pixel_diff_pct") or 0) > 5:
        tags.append("LARGE_VISUAL_CHANGE")
    if not tags:
        tags.append("MINOR_VARIANCE")
    return tags


def _load_a11y(path: Optional[Path]) -> Optional[dict]:
    if not path or not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return None


def _a11y_compare(current_path: Optional[Path], baseline_path: Optional[Path]) -> dict:
    cur = _load_a11y(current_path)
    base = _load_a11y(baseline_path)
    if not cur:
        return {"status": "UNAVAILABLE"}
    if not base:
        return {"status": "CURRENT_ONLY", "current": cur}
    fields = ["textLength", "ariaNodeCount", "ariaLabeledCount", "headingCount"]
    delta = {f: int(cur.get(f, 0) or 0) - int(base.get(f, 0) or 0) for f in fields}
    return {"status": "COMPARED", "baseline": base, "current": cur, "delta": delta}


def _resolve_baseline_for_item(
    cfg: dict,
    view_id: str,
    snapshot_id: str,
    current_png: Path,
    current_a11y: Optional[Path] = None,
) -> tuple[Optional[Path], str, bool]:
    item_ref = f"{view_id}/{snapshot_id}"
    baseline_png, baseline_kind = resolve_baseline(
        cfg,
        view_id,
        snapshot_id,
        log=lambda m: _log_info(f"{item_ref}: {m}"),
    )
    created = False
    if baseline_png is None:
        _log_warn(f"{item_ref}: no baseline found, creating runtime baseline from current screenshot")
        baseline_png, kind2 = ensure_runtime_baseline(cfg, view_id, snapshot_id, current_png, current_a11y=current_a11y)
        if kind2 == "runtime_created":
            created = True
            baseline_kind = "runtime_created"
            _log_info(f"{item_ref}: runtime baseline created at {baseline_png}")
        elif kind2 == "none":
            _log_warn(f"{item_ref}: baseline missing and auto-create disabled")
    return baseline_png, baseline_kind, created


def _evaluate_item(
    cfg: dict,
    item: dict,
    thresholds: dict,
    by_snapshot: dict,
    suggest_enabled: bool,
    suggest_min_area: int,
    suggest_max_regions: int,
    resize_on_mismatch: bool,
    mismatch_level: str,
    diff_png: Path,
) -> dict:
    snapshot_id = item["snapshot_id"]
    view_id = item["view_id"]
    current_png = Path(item["png"])
    current_a11y = Path(item["a11y"]) if item.get("a11y") else None

    baseline_png, baseline_kind, created = _resolve_baseline_for_item(
        cfg, view_id, snapshot_id, current_png, current_a11y=current_a11y
    )
    if baseline_png is None:
        row = {
            "snapshot_id": snapshot_id,
            "view_id": view_id,
            "status": "NO_BASELINE",
            "baseline_kind": "none",
            "baseline": None,
            "current": str(current_png),
            "diff": None,
            "pixel_diff_pct": None,
            "ssim": None,
            "warnings": ["BASELINE_MISSING"],
            "signature": item.get("signature") or {},
            "a11y": _a11y_compare(current_a11y, None),
            "thresholds": thresholds,
        }
        issue_summary, action_hint, severity_score = _build_issue_summary(row)
        row["issue_summary"] = issue_summary
        row["action_hint"] = action_hint
        row["severity_score"] = severity_score
        row["root_cause_hint"] = _root_cause_hint(row)
        return row

    snap_cfg = by_snapshot.get(snapshot_id) or {}
    eff_thresholds = {
        "max_pixel_diff_pct": float(snap_cfg.get("max_pixel_diff_pct", thresholds["max_pixel_diff_pct"])),
        "min_ssim": float(snap_cfg.get("min_ssim", thresholds["min_ssim"])),
    }
    region_rules = list(snap_cfg.get("regions") or [])

    metrics = diff_images(
        baseline_png=baseline_png,
        current_png=current_png,
        diff_png=diff_png,
        resize_on_mismatch=resize_on_mismatch,
        region_rules=region_rules,
        suggest_regions=suggest_enabled,
        suggest_min_area=suggest_min_area,
        suggest_max_regions=suggest_max_regions,
    )

    mismatch = (metrics["pixel_diff_pct"] > eff_thresholds["max_pixel_diff_pct"]) or (
        metrics["ssim"] < eff_thresholds["min_ssim"]
    )
    region_failures = []
    for rr in metrics.get("region_results") or []:
        rr_max = rr.get("max_pixel_diff_pct")
        rr_min = rr.get("min_ssim")
        region_bad = False
        if rr_max is not None and rr["pixel_diff_pct"] > float(rr_max):
            region_bad = True
        if rr_min is not None and rr["ssim"] < float(rr_min):
            region_bad = True
        if region_bad:
            region_failures.append(rr)
    mismatch = mismatch or bool(region_failures)
    status = mismatch_level if mismatch else "PASS"

    if created:
        created_level = cfg["baseline"].get("on_created", "INFO")
        metrics["warnings"].append("BASELINE_CREATED")
        if created_level == "WARN" and status == "PASS":
            status = "WARN"
        if created_level == "FAIL":
            status = "FAIL"

    row = {
        "snapshot_id": snapshot_id,
        "view_id": view_id,
        "status": status,
        "baseline_kind": baseline_kind,
        "baseline": str(baseline_png),
        "current": str(current_png),
        "diff": str(diff_png),
        "thresholds": eff_thresholds,
        "signature": item.get("signature") or {},
        "a11y": _a11y_compare(
            current_a11y,
            baseline_a11y_path(
                cfg,
                "runtime" if baseline_kind == "runtime_created" else baseline_kind,
                view_id,
                snapshot_id,
            ),
        ),
        **metrics,
    }
    if region_failures:
        row["warnings"].append(f"REGION_MISMATCH count={len(region_failures)}")
        row["region_failures"] = region_failures
    fig_meta = figma_frame_meta(cfg, snapshot_id=snapshot_id, view_id=view_id)
    if fig_meta:
        row["figma"] = fig_meta
    issue_summary, action_hint, severity_score = _build_issue_summary(row)
    row["issue_summary"] = issue_summary
    row["action_hint"] = action_hint
    row["severity_score"] = severity_score
    row["root_cause_hint"] = _root_cause_hint(row)
    row["root_cause_tags"] = _root_cause_tags(row)
    return row


def _history_root(cfg: dict) -> Path:
    return Path(cfg["__root__"]) / "test_report" / cfg["project"] / "history"


def _config_yaml_path(cfg: dict) -> Optional[str]:
    p = cfg.get("__path__")
    if not p:
        return None
    pp = Path(str(p))
    if pp.suffix.lower() in {".yaml", ".yml"}:
        return str(pp)
    return None


def run_visualcheck(
    cfg: dict,
    env: str,
    run_id: Optional[str] = None,
    headed: bool = False,
    slow_mo_ms: int = 0,
    workers: int = 1,
    capture_only: bool = False,
    capture_out: Optional[Path] = None,
    storage_state: Optional[Path] = None,
) -> dict:
    run_id = run_id or now_run_id()
    rr = run_root(cfg, run_id)
    ensure_dir(rr)
    workers = _resolve_workers(workers)
    _log_info(
        f"run started: project={cfg.get('project')} suite={cfg.get('suite')} env={env} run_id={run_id} workers={workers}"
    )

    current_dir = capture_out if capture_only and capture_out else rr / "current"
    ensure_dir(current_dir)
    _log_info(f"capture started: output={current_dir}")
    cap = capture_all(
        cfg,
        env=env,
        out_dir=current_dir,
        headed=headed,
        slow_mo_ms=slow_mo_ms,
        workers=workers,
        storage_state=storage_state,
    )
    _log_info(f"capture completed: snapshots={len(cap.get('manifest') or [])}")
    if capture_only:
        _log_info("capture-only mode enabled; comparison skipped")
        return {"status": "CAPTURED", "run_id": run_id, **cap}

    compare_cfg = cfg.get("compare") or {}
    thresholds = compare_cfg["thresholds"]
    by_snapshot = compare_cfg.get("by_snapshot") or {}
    suggest_cfg = compare_cfg.get("suggest_ignore_regions") or {}
    suggest_enabled = bool(suggest_cfg.get("enabled", False))
    suggest_min_area = int(suggest_cfg.get("min_area", 2500))
    suggest_max_regions = int(suggest_cfg.get("max_regions", 5))
    resize_on_mismatch = bool(compare_cfg.get("resize_on_mismatch", True))
    mismatch_level = compare_cfg.get("mismatch_level", "WARN")

    stability_cfg = cfg.get("stability") or {}
    reruns_on_warn = int(stability_cfg.get("reruns_on_warn", 0))
    reruns_on_fail = int(stability_cfg.get("reruns_on_fail", 0))
    consensus_mode = str(stability_cfg.get("require_consensus", "best"))

    quarantine_set = set((cfg.get("quarantine") or {}).get("snapshots") or [])
    auto_q_p = _history_root(cfg) / "auto_quarantine.json"
    auto_q = _load_json(auto_q_p, {"items": {}})
    quarantine_set.update(auto_q.get("items", {}).keys())
    owner_map = (cfg.get("owners") or {}).get("by_snapshot") or {}

    diff_dir = rr / "diff"
    ensure_dir(diff_dir)
    attempt_root = rr / "attempts"
    ensure_dir(attempt_root)

    results: list[dict] = []
    overall = "PASS"
    total_items = len(cap["manifest"])
    _log_info(f"comparison started: items={total_items}")

    for idx, item in enumerate(cap["manifest"], start=1):
        item_ref = f"{item['view_id']}/{item['snapshot_id']}"
        _log_info(f"[{idx}/{total_items}] evaluating {item_ref}")
        base_diff = diff_dir / slug(item["view_id"]) / f"{slug(item['snapshot_id'])}.png"
        row = _evaluate_item(
            cfg=cfg,
            item=item,
            thresholds=thresholds,
            by_snapshot=by_snapshot,
            suggest_enabled=suggest_enabled,
            suggest_min_area=suggest_min_area,
            suggest_max_regions=suggest_max_regions,
            resize_on_mismatch=resize_on_mismatch,
            mismatch_level=mismatch_level,
            diff_png=base_diff,
        )
        attempts = [
            {
                "attempt": 0,
                "status": row["status"],
                "pixel_diff_pct": row.get("pixel_diff_pct"),
                "ssim": row.get("ssim"),
                "current": row.get("current"),
                "diff": row.get("diff"),
                "signature": row.get("signature") or {},
                "severity_score": row.get("severity_score", 0.0),
            }
        ]

        reruns = 0
        if row["status"] == "WARN":
            reruns = reruns_on_warn
        elif row["status"] in {"FAIL", "NO_BASELINE"}:
            reruns = reruns_on_fail

        if reruns > 0:
            _log_info(f"{item_ref}: scheduling {reruns} rerun(s) due to status={row['status']}")

        for retry_i in range(reruns):
            rerun_dir = attempt_root / f"{idx:04d}_{slug(item['view_id'])}_{slug(item['snapshot_id'])}" / f"retry_{retry_i+1}"
            _log_info(f"{item_ref}: rerun {retry_i + 1}/{reruns} capture started")
            rec = capture_selected(
                cfg=cfg,
                env=env,
                out_dir=rerun_dir / "current",
                selections=[{"snapshot_id": item["snapshot_id"], "view_id": item["view_id"]}],
                headed=headed,
                slow_mo_ms=slow_mo_ms,
                storage_state=storage_state,
            )
            if not rec["manifest"]:
                _log_warn(f"{item_ref}: rerun {retry_i + 1}/{reruns} capture returned no screenshot")
                continue
            i2 = rec["manifest"][0]
            r2 = _evaluate_item(
                cfg=cfg,
                item=i2,
                thresholds=thresholds,
                by_snapshot=by_snapshot,
                suggest_enabled=suggest_enabled,
                suggest_min_area=suggest_min_area,
                suggest_max_regions=suggest_max_regions,
                resize_on_mismatch=resize_on_mismatch,
                mismatch_level=mismatch_level,
                diff_png=rerun_dir / "diff" / f"{slug(item['snapshot_id'])}.png",
            )
            attempts.append(
                {
                    "attempt": retry_i + 1,
                    "status": r2["status"],
                    "pixel_diff_pct": r2.get("pixel_diff_pct"),
                    "ssim": r2.get("ssim"),
                    "current": r2.get("current"),
                    "diff": r2.get("diff"),
                    "signature": r2.get("signature") or {},
                    "severity_score": r2.get("severity_score", 0.0),
                }
            )
            _log_info(
                f"{item_ref}: rerun {retry_i + 1}/{reruns} status={r2['status']} ({_fmt_metrics(r2)})"
            )
            chosen = _choose_consensus([row, r2], mode=consensus_mode)
            if chosen and chosen.get("current"):
                row = chosen

        sigs = [a.get("signature") or {} for a in attempts]
        sh = {s.get("scrollHeight") for s in sigs if s.get("scrollHeight") is not None}
        tl = {s.get("textLength") for s in sigs if s.get("textLength") is not None}
        if len(sh) > 1 or len(tl) > 1:
            row["warnings"] = list(dict.fromkeys((row.get("warnings") or []) + ["LAYOUT_SHIFT_SUSPECTED"]))

        st_set = {a.get("status") for a in attempts}
        row["flaky"] = len(st_set) > 1
        row["attempts"] = attempts
        row["attempt_count"] = len(attempts)
        row["owner"] = owner_map.get(item["snapshot_id"]) or owner_map.get(f"{item['view_id']}:{item['snapshot_id']}")
        row["root_cause_hint"] = _root_cause_hint(row)
        row["root_cause_tags"] = _root_cause_tags(row)

        if item["snapshot_id"] in quarantine_set and row["status"] in {"WARN", "FAIL", "NO_BASELINE"}:
            row["quarantined"] = True
            row["status"] = "QUARANTINED"
            row["warnings"] = list(dict.fromkeys((row.get("warnings") or []) + ["QUARANTINED_SNAPSHOT"]))

        issue_summary, action_hint, severity_score = _build_issue_summary(row)
        row["issue_summary"] = issue_summary
        row["action_hint"] = action_hint
        row["severity_score"] = severity_score
        _log_info(
            f"{item_ref}: final status={row['status']} baseline={row.get('baseline_kind', 'none')} ({_fmt_metrics(row)})"
        )

        if row["status"] in {"FAIL", "NO_BASELINE"}:
            overall = "FAIL"
        elif row["status"] in {"WARN", "QUARANTINED"} and overall == "PASS":
            overall = "WARN"
        results.append(row)

    report_dir = rr / "report"
    ensure_dir(report_dir / "assets")
    for r in results:
        cur_src = Path(r["current"])
        cur_rel = Path("assets") / "current" / slug(r["view_id"]) / f"{slug(r['snapshot_id'])}.png"
        ensure_dir((report_dir / cur_rel).parent)
        shutil.copy2(cur_src, report_dir / cur_rel)
        r["current_rel"] = cur_rel.as_posix()

        if r.get("baseline"):
            base_src = Path(r["baseline"])
            base_rel = Path("assets") / "baseline" / slug(r["view_id"]) / f"{slug(r['snapshot_id'])}.png"
            ensure_dir((report_dir / base_rel).parent)
            shutil.copy2(base_src, report_dir / base_rel)
            r["baseline_rel"] = base_rel.as_posix()
        else:
            r["baseline_rel"] = None

        if r.get("diff"):
            diff_src = Path(r["diff"])
            diff_rel = Path("assets") / "diff" / slug(r["view_id"]) / f"{slug(r['snapshot_id'])}.png"
            ensure_dir((report_dir / diff_rel).parent)
            shutil.copy2(diff_src, report_dir / diff_rel)
            r["diff_rel"] = diff_rel.as_posix()
        else:
            r["diff_rel"] = None

    suggestions = []
    if suggest_enabled:
        for r in results:
            for reg in (r.get("suggested_regions") or []):
                suggestions.append({"snapshot_id": r["snapshot_id"], "view_id": r["view_id"], **reg})

    top_regressions = sorted(
        results,
        key=lambda x: (
            0 if x["status"] == "FAIL" else (1 if x["status"] in {"WARN", "QUARANTINED"} else 2),
            -float(x.get("severity_score") or 0.0),
            -float(x.get("pixel_diff_pct") or 0.0),
        ),
    )[:10]

    history_root = _history_root(cfg)
    trends_p = history_root / "trends.json"
    flake_p = history_root / "flake_history.json"
    last_p = history_root / "last_results.json"

    git_meta = _git_meta(Path(cfg["__root__"]))
    last_results = _load_json(last_p, {"items": {}})
    last_index = last_results.get("items") or {}
    for r in results:
        key = f"{r['view_id']}::{r['snapshot_id']}"
        prev = last_index.get(key) or {}
        if prev.get("status") == "PASS" and r["status"] in {"WARN", "FAIL", "QUARANTINED"}:
            r["likely_introduced_after"] = prev.get("commit")

    t = _load_json(trends_p, {"runs": []})
    t["runs"].append(
        {
            "run_id": run_id,
            "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
            "status": overall,
            "counts": dict(Counter(r["status"] for r in results)),
            "commit": git_meta.get("commit"),
            "branch": git_meta.get("branch"),
        }
    )
    t["runs"] = t["runs"][-200:]
    _save_json(trends_p, t)

    fh = _load_json(flake_p, {"items": {}})
    f_items = fh.get("items") or {}
    for r in results:
        key = f"{r['view_id']}::{r['snapshot_id']}"
        state = f_items.get(key, {"total_runs": 0, "flaky_runs": 0, "score": 0.0})
        state["total_runs"] += 1
        if r.get("flaky"):
            state["flaky_runs"] += 1
        state["score"] = round(state["flaky_runs"] / max(1, state["total_runs"]), 4)
        f_items[key] = state
        r["flake_score"] = state["score"]
    fh["items"] = f_items
    _save_json(flake_p, fh)

    auto_cfg = (stability_cfg.get("auto_quarantine") or {}) if isinstance(stability_cfg, dict) else {}
    auto_enabled = bool(auto_cfg.get("enabled", False))
    auto_min_score = float(auto_cfg.get("min_flake_score", 0.6))
    auto_min_runs = int(auto_cfg.get("min_runs", 3))
    if auto_enabled:
        aq_items = auto_q.get("items") or {}
        for r in results:
            key = f"{r['view_id']}::{r['snapshot_id']}"
            fstate = f_items.get(key) or {}
            if float(fstate.get("score", 0.0)) >= auto_min_score and int(fstate.get("total_runs", 0)) >= auto_min_runs:
                aq_items[key] = {
                    "view_id": r["view_id"],
                    "snapshot_id": r["snapshot_id"],
                    "flake_score": fstate.get("score"),
                    "total_runs": fstate.get("total_runs"),
                    "updated_at": dt.datetime.now().isoformat(timespec="seconds"),
                }
                if r["status"] in {"WARN", "FAIL", "NO_BASELINE"}:
                    r["status"] = "QUARANTINED"
                    r["quarantined"] = True
                    r["warnings"] = list(dict.fromkeys((r.get("warnings") or []) + ["AUTO_QUARANTINED_FLAKE"]))
        auto_q["items"] = aq_items
        _save_json(auto_q_p, auto_q)

    next_last = {"items": {}}
    for r in results:
        key = f"{r['view_id']}::{r['snapshot_id']}"
        next_last["items"][key] = {
            "status": r["status"],
            "commit": git_meta.get("commit"),
            "run_id": run_id,
        }
    _save_json(last_p, next_last)

    reviews = list_reviews(cfg).get("items") or []
    review_index = {f"{it.get('view_id')}::{it.get('snapshot_id')}": it for it in reviews}
    for r in results:
        rk = f"{r['view_id']}::{r['snapshot_id']}"
        rv = review_index.get(rk)
        if rv:
            r["review"] = rv.get("latest") or rv

    review_gate = compute_review_gate(cfg, rows=results)
    _save_json(history_root / "review_gate_latest.json", review_gate)

    # Recompute overall after late policy/review enrichments.
    overall = "PASS"
    for r in results:
        if r["status"] in {"FAIL", "NO_BASELINE"}:
            overall = "FAIL"
            break
        if r["status"] in {"WARN", "QUARANTINED"} and overall == "PASS":
            overall = "WARN"

    top_unstable = sorted(
        [
            {
                "key": k,
                "flake_score": v.get("score", 0.0),
                "total_runs": v.get("total_runs", 0),
                "flaky_runs": v.get("flaky_runs", 0),
            }
            for k, v in f_items.items()
        ],
        key=lambda x: (-x["flake_score"], -x["flaky_runs"], -x["total_runs"]),
    )[:10]

    browser_channels = sorted(
        {
            str(r.get("view_id", "")).rsplit("@", 1)[1]
            for r in results
            if "@" in str(r.get("view_id", ""))
        }
    )

    report = {
        "project": cfg["project"],
        "suite": cfg["suite"],
        "env": env,
        "run_id": run_id,
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "status": overall,
        "config": cfg.get("__path__"),
        "config_yaml": _config_yaml_path(cfg),
        "thresholds": thresholds,
        "git": git_meta,
        "top_unstable": top_unstable,
        "browser_channels": browser_channels,
        "top_regressions": [
            {
                "snapshot_id": t["snapshot_id"],
                "view_id": t["view_id"],
                "status": t["status"],
                "issue_summary": t.get("issue_summary"),
                "pixel_diff_pct": t.get("pixel_diff_pct"),
                "ssim": t.get("ssim"),
                "owner": t.get("owner"),
                "flake_score": t.get("flake_score"),
            }
            for t in top_regressions
        ],
        "ignore_suggestions": suggestions,
        "history_runs": list(reversed((t.get("runs") or [])[-20:])),
        "results": results,
        "reviews": reviews,
        "review_gate": review_gate,
        "review_gate_policy": (cfg.get("review_gate") or {}),
    }
    paths = write_report(report_dir, report)
    report.update(paths)
    if bool((cfg.get("review_gate") or {}).get("enabled", False)):
        api_base = ensure_review_server(root=Path(cfg["__root__"]), project=str(cfg["project"]))
        if api_base:
            report["review_api_base"] = api_base
            report["review_gate"] = compute_review_gate(cfg, rows=results)
            paths = write_report(report_dir, report)
            report.update(paths)
    _log_info(
        f"run finished: status={overall} report={report.get('report_html')} dashboard={report.get('dashboard_html')}"
    )
    auto_open_report_from_env(
        report.get("dashboard_html") or report["report_html"],
        disabled=bool(cfg.get("__disable_env_report_open__", False)),
    )
    return report
