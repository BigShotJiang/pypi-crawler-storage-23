from __future__ import annotations

import argparse
import json
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Optional

from .review import compute_review_gate, list_reviews, set_review
from .utils import ensure_dir


def _history_root(root: Path, project: str) -> Path:
    return root / "test_report" / project / "history"


def _server_state_file(root: Path, project: str) -> Path:
    return _history_root(root, project) / "review_server.json"


def _load_json(path: Path, default: dict) -> dict:
    try:
        if path.exists():
            return json.loads(path.read_text())
    except Exception:
        pass
    return dict(default)


def _save_json(path: Path, data: dict) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(data, indent=2))


def _is_alive(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=0.7) as r:
            return r.status == 200
    except Exception:
        return False


def _pick_free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    _, port = s.getsockname()
    s.close()
    return int(port)


def ensure_review_server(*, root: Path, project: str) -> Optional[str]:
    state_file = _server_state_file(root, project)
    state = _load_json(state_file, {})
    port = int(state.get("port", 0) or 0)
    if port > 0 and _is_alive(port):
        return f"http://127.0.0.1:{port}"

    port = _pick_free_port()
    cmd = [
        sys.executable,
        "-m",
        "visualcheck.review_server",
        "--root",
        str(root),
        "--project",
        project,
        "--port",
        str(port),
    ]
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    except Exception:
        return None

    for _ in range(15):
        if _is_alive(port):
            _save_json(state_file, {"port": port, "started_at": time.time()})
            return f"http://127.0.0.1:{port}"
        time.sleep(0.2)
    return None


def _cfg(root: Path, project: str, gate_policy: Optional[dict] = None) -> dict:
    return {"__root__": str(root), "project": project, "review_gate": dict(gate_policy or {})}


class _Handler(BaseHTTPRequestHandler):
    server_version = "visualcheck-review/1.0"

    def _json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:  # noqa: N802
        self._json(200, {"ok": True})

    def do_GET(self) -> None:  # noqa: N802
        if self.path.startswith("/api/health"):
            self._json(200, {"ok": True})
            return
        if self.path.startswith("/api/review/list"):
            cfg = _cfg(self.server.root_path, self.server.project, {})
            self._json(200, list_reviews(cfg))
            return
        self._json(404, {"error": "not_found"})

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(length) if length > 0 else b"{}"
        try:
            payload = json.loads(raw.decode("utf-8")) if raw else {}
        except Exception:
            self._json(400, {"error": "invalid_json"})
            return

        if self.path.startswith("/api/review/set"):
            try:
                cfg = _cfg(self.server.root_path, self.server.project, {})
                out = set_review(
                    cfg,
                    view_id=str(payload.get("view_id") or ""),
                    snapshot_id=str(payload.get("snapshot_id") or ""),
                    state=str(payload.get("state") or ""),
                    reviewer=str(payload.get("reviewer") or "anonymous"),
                    comment=str(payload.get("comment") or ""),
                    run_id=str(payload.get("run_id") or "") or None,
                )
                self._json(200, {"status": "OK", "review": out})
            except Exception as exc:
                self._json(400, {"error": str(exc)})
            return

        if self.path.startswith("/api/gate/status"):
            try:
                rows = payload.get("rows") or []
                policy = payload.get("policy") or {}
                cfg = _cfg(self.server.root_path, self.server.project, policy)
                out = compute_review_gate(cfg, rows=rows)
                self._json(200, out)
            except Exception as exc:
                self._json(400, {"error": str(exc)})
            return

        self._json(404, {"error": "not_found"})


def run_server(*, root: Path, project: str, port: int) -> None:
    class _Srv(ThreadingHTTPServer):
        root_path: Path
        project: str

    srv = _Srv(("127.0.0.1", port), _Handler)
    srv.root_path = root
    srv.project = project
    srv.serve_forever()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--project", required=True)
    ap.add_argument("--port", required=True, type=int)
    args = ap.parse_args()
    run_server(root=Path(args.root), project=str(args.project), port=int(args.port))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

