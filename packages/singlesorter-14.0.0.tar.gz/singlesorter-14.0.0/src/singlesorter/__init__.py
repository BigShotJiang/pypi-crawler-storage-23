"""singlesorter package."""

from .sorter import __VERSION__

__all__ = ["__VERSION__"]
