from __future__ import annotations

import asyncio
import importlib.metadata
import locale
import logging
import os
import signal
import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from rich.console import Console

from comate_agent_sdk import Agent
from comate_agent_sdk.agent import AgentConfig, ChatSession
from comate_agent_sdk.context import EnvOptions
from comate_agent_sdk.tools import tool

from comate_cli.terminal_agent.event_renderer import EventRenderer
from comate_cli.terminal_agent.logo import print_logo
from comate_cli.terminal_agent.preflight import run_preflight_if_needed
from comate_cli.terminal_agent.resume_selector import select_resume_session_id
from comate_cli.terminal_agent.rpc_stdio import StdioRPCBridge
from comate_cli.terminal_agent.status_bar import StatusBar
from comate_cli.terminal_agent.tui import TerminalAgentTUI

console = Console()
logger = logging.getLogger(__name__)


def _resolve_cli_project_root() -> Path:
    """Resolve project root: always the current working directory."""
    return Path.cwd().expanduser().resolve()


def _is_chinese_locale() -> bool:
    """判断当前系统 locale 是否为中文环境。"""
    # zh_tw（台湾）和 zh_hk（香港）不走清华镜像源
    _CN_PREFIXES = ("zh_cn", "zh_sg", "zh_mo", "zh_hans")
    for env_var in ("LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"):
        val = os.environ.get(env_var, "").lower()
        if any(val.startswith(p) for p in _CN_PREFIXES):
            return True
    try:
        lang, _ = locale.getlocale()
        if lang:
            lang_lower = lang.lower()
            if any(lang_lower.startswith(p) for p in _CN_PREFIXES):
                return True
    except Exception:
        pass
    return False


async def _check_update() -> str | None:
    """异步检查 comate-cli 是否有新版本，返回提示字符串或 None。

    中文 locale 自动使用腾讯云镜像源，其余使用官方 PyPI。
    """
    package = "comate-cli"
    try:
        current = importlib.metadata.version(package)
    except importlib.metadata.PackageNotFoundError:
        return None

    if _is_chinese_locale():
        url = f"https://mirrors.cloud.tencent.com/pypi/pypi/{package}/json"
        source_label = "tencent"
    else:
        url = f"https://pypi.org/pypi/{package}/json"
        source_label = "pypi"

    try:
        import httpx
        async with httpx.AsyncClient(timeout=3.0) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            latest = resp.json()["info"]["version"]
    except Exception:
        logger.debug(f"update check failed (source={source_label})", exc_info=True)
        return None

    try:
        from importlib.metadata import version as _v
        from packaging.version import Version
        if Version(latest) > Version(current):
            return (
                f"[dim]💡 New version available: [bold cyan]{latest}[/] "
                f"(current: {current})  "
                f"Run [bold]uv tool upgrade {package}[/] to upgrade.[/]"
            )
    except Exception:
        pass
    return None


def _flush_langfuse_if_configured() -> None:
    """Flush Langfuse pending events synchronously to prevent atexit thread-join errors on Ctrl+C."""
    try:
        from langfuse import get_client
        get_client().flush()
    except Exception:
        pass


@contextmanager
def _sigint_guard() -> Iterator[None]:
    """Temporarily ignore SIGINT in critical shutdown windows."""
    if os.name == "nt":
        yield
        return
    if threading.current_thread() is not threading.main_thread():
        yield
        return

    try:
        previous_handler = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        logger.debug("SIGINT guard enabled for shutdown")
    except Exception as exc:
        logger.debug(f"Failed to enable SIGINT guard, fallback to unguarded shutdown: {exc}")
        yield
        return

    try:
        yield
    finally:
        try:
            signal.signal(signal.SIGINT, previous_handler)
            logger.debug("SIGINT guard restored")
        except Exception as exc:
            logger.warning(f"Failed to restore SIGINT handler: {exc}", exc_info=True)


async def _shutdown_session(session: ChatSession, *, label: str) -> None:
    start = time.monotonic()
    try:
        shutdown = getattr(session, "shutdown", None)
        if callable(shutdown):
            await shutdown()
        else:
            await session.close()
    except Exception as exc:
        logger.warning(f"Session shutdown failed ({label}): {exc}", exc_info=True)
        return

    elapsed = time.monotonic() - start
    logger.info(f"Session shutdown completed ({label}) in {elapsed:.3f}s")


async def _graceful_shutdown(*sessions: ChatSession) -> None:
    unique_sessions: list[ChatSession] = []
    seen_ids: set[int] = set()
    for session in sessions:
        sid = id(session)
        if sid in seen_ids:
            continue
        seen_ids.add(sid)
        unique_sessions.append(session)

    start = time.monotonic()
    with _sigint_guard():
        for index, session in enumerate(unique_sessions, start=1):
            label = f"{index}/{len(unique_sessions)} session_id={session.session_id}"
            await _shutdown_session(session, label=label)
        _flush_langfuse_if_configured()

    elapsed = time.monotonic() - start
    logger.info(f"Graceful shutdown completed in {elapsed:.3f}s")


@tool("Add two numbers 涉及到加法运算 必须使用这个工具")
async def add(a: int, b: int) -> int:
    return a + b


def _build_agent(*, project_root: Path | None = None) -> Agent:
    context7_api_key = os.getenv("CONTEXT7_API_KEY")
    exa_api_key = os.getenv("EXA_API_KEY")
    resolved_project_root = project_root or _resolve_cli_project_root()

    exa_tools = (
        "web_search_exa,"
        "web_search_advanced_exa,"
        "get_code_context_exa,"
        "crawling_exa"
    )
    exa_url = "https://mcp.exa.ai/mcp"
    if exa_api_key:
        exa_url = f"{exa_url}?exaApiKey={exa_api_key}&tools={exa_tools}"
    else:
        exa_url = f"{exa_url}?tools={exa_tools}"

    return Agent(
        config=AgentConfig(
            role="software_engineering",
            project_root=resolved_project_root,
            env_options=EnvOptions(system_env=True, git_env=True),
            use_streaming_task=True,  # 启用流式 Task（实时显示嵌套工具调用）
            mcp_servers={
                "context7": {
                    "type": "http",
                    "url": "https://mcp.context7.com/mcp",
                    "headers": {
                        "CONTEXT7_API_KEY": context7_api_key,
                    },
                },
                "wiretext": {
                    "command": "npx",
                    "args": ["-y", "@wiretext/mcp"]
                },
                "exa_search": {
                    "type": "http",
                    "url": exa_url,
                },
            },
        )
    )


def _resolve_session(
    agent: Agent, resume_session_id: str | None, *, cwd: Path | None = None
) -> tuple[ChatSession, str]:
    if resume_session_id:
        return ChatSession.resume(agent, session_id=resume_session_id, cwd=cwd), "resume"
    return ChatSession(agent, cwd=cwd), "new"


def _format_exit_usage_line(usage: object) -> str:
    total_prompt_tokens = int(getattr(usage, "total_prompt_tokens", 0) or 0)
    total_prompt_cached_tokens = int(
        getattr(usage, "total_prompt_cached_tokens", 0) or 0
    )
    total_completion_tokens = int(getattr(usage, "total_completion_tokens", 0) or 0)
    total_reasoning_tokens = int(getattr(usage, "total_reasoning_tokens", 0) or 0)

    input_tokens = max(total_prompt_tokens - total_prompt_cached_tokens, 0)
    total_tokens = input_tokens + total_completion_tokens

    reasoning_part = f" (reasoning {total_reasoning_tokens:,})" if total_reasoning_tokens > 0 else ""
    return (
        f"Token usage: total={total_tokens:,} "
        f"input={input_tokens:,} (+ {total_prompt_cached_tokens:,} cached) "
        f"output={total_completion_tokens:,}{reasoning_part}"
    )


def _format_resume_hint(session_id: str | None) -> str | None:
    if not session_id:
        return None
    return (
        f"[dim]To continue this session, run [bold cyan]comate resume "
        f"{session_id}[/][/]"
    )


async def _preload_mcp_in_tui(session: ChatSession, renderer: EventRenderer) -> None:
    """在 TUI 内部异步加载 MCP，通过 renderer 输出状态消息."""
    if not session._agent.options.mcp_servers:
        return
    try:
        await session._agent.ensure_mcp_tools_loaded()
    except Exception as e:
        renderer.append_system_message(f"MCP init failed: {e}", severity="error")
        return

    mgr = session._agent._mcp_manager
    if mgr is None:
        return

    loaded = mgr.tool_infos
    if loaded:
        count = len(loaded)
        aliases = sorted({i.server_alias for i in loaded})
        renderer.append_system_message(f"MCP loaded: {', '.join(aliases)} ({count} tools)")


async def run(
    *,
    rpc_stdio: bool = False,
    resume_session_id: str | None = None,
    resume_select: bool = False,
) -> None:
    project_root = _resolve_cli_project_root()
    preflight_result = await run_preflight_if_needed(
        console=console,
        project_root=project_root,
        interactive=not rpc_stdio,
    )
    if preflight_result.should_abort_launch:
        return

    agent = _build_agent(project_root=project_root)

    if rpc_stdio and resume_select and not resume_session_id:
        console.print("[red]`comate resume` does not support `--rpc-stdio` without <session_id>[/]")
        return

    if rpc_stdio:
        session, _mode = _resolve_session(agent, resume_session_id, cwd=project_root)
        bridge = StdioRPCBridge(session)
        try:
            await bridge.run()
        finally:
            await _graceful_shutdown(session)
        return

    print_logo(console)

    if resume_select and not resume_session_id:
        selected_session_id = await select_resume_session_id(console, cwd=project_root)
        if not selected_session_id:
            return
        resume_session_id = selected_session_id

    session, mode = _resolve_session(agent, resume_session_id, cwd=project_root)

    # 版本检查：带超时，不阻塞启动
    try:
        update_hint = await asyncio.wait_for(_check_update(), timeout=2.0)
        if update_hint:
            console.print(update_hint)
    except (asyncio.TimeoutError, Exception):
        pass

    # 不再阻塞等待 MCP，改为 TUI 内部异步加载
    status_bar = StatusBar(session)
    status_bar.set_mode(session.get_mode())
    if mode == "resume":
        await status_bar.refresh()

    renderer = EventRenderer(project_root=Path.cwd())

    # 配置 TUI logging handler（将 SDK 日志输出到 TUI）
    from comate_cli.terminal_agent.logging_adapter import setup_tui_logging
    setup_tui_logging(renderer)

    tui = TerminalAgentTUI(session, status_bar, renderer)
    tui.add_resume_history(mode)

    # 把 MCP loading 作为 TUI 内部初始化任务
    async def _mcp_loader() -> None:
        await _preload_mcp_in_tui(session, renderer)

    usage_line: str | None = None
    active_session = session
    try:
        await tui.run(mcp_init=_mcp_loader)
        active_session = tui.session
        try:
            usage = await active_session.get_usage()
            usage_line = _format_exit_usage_line(usage)
        except Exception as exc:
            logger.warning(
                f"Failed to collect usage for exit summary: {exc}",
                exc_info=True,
            )
    finally:
        if active_session is session:
            await _graceful_shutdown(active_session)
        else:
            await _graceful_shutdown(session, active_session)

    if usage_line:
        console.print(f"[dim]{usage_line}[/]")

    initialized_session_id = tui.initialized_session_id
    resume_hint = _format_resume_hint(initialized_session_id)
    if resume_hint is not None:
        console.print(resume_hint)


if __name__ == "__main__":
    asyncio.run(run())
