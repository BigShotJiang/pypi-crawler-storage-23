from __future__ import annotations

import sys
from pathlib import Path


def _ensure_cli_package_on_path() -> None:
    cli_project_root = Path(__file__).resolve().parents[1]
    cli_project_root_str = str(cli_project_root)
    if cli_project_root_str not in sys.path:
        sys.path.insert(0, cli_project_root_str)


_ensure_cli_package_on_path()
