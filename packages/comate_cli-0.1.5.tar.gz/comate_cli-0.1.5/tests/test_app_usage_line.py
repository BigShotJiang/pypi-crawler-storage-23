from __future__ import annotations

import unittest
from types import SimpleNamespace

from comate_cli.terminal_agent.app import _format_exit_usage_line, _format_resume_hint


class TestAppUsageLine(unittest.TestCase):
    def test_format_exit_usage_line_uses_uncached_input_for_total(self) -> None:
        usage = SimpleNamespace(
            total_prompt_tokens=258_784,
            total_prompt_cached_tokens=13_762,
            total_completion_tokens=37_492,
            total_reasoning_tokens=15_587,
        )

        line = _format_exit_usage_line(usage)

        self.assertEqual(
            line,
            (
                "Token usage: total=282,514 "
                "input=245,022 (+ 13,762 cached) "
                "output=37,492 (reasoning 15,587)"
            ),
        )

    def test_format_exit_usage_line_clamps_negative_input(self) -> None:
        usage = SimpleNamespace(
            total_prompt_tokens=100,
            total_prompt_cached_tokens=120,
            total_completion_tokens=5,
            total_reasoning_tokens=0,
        )

        line = _format_exit_usage_line(usage)

        self.assertEqual(
            line,
            "Token usage: total=5 input=0 (+ 120 cached) output=5",
        )

    def test_format_resume_hint_returns_none_when_session_not_initialized(self) -> None:
        self.assertIsNone(_format_resume_hint(None))
        self.assertIsNone(_format_resume_hint(""))

    def test_format_resume_hint_uses_resume_subcommand(self) -> None:
        hint = _format_resume_hint("sess-123")
        self.assertEqual(
            hint,
            (
                "[dim]To continue this session, run [bold cyan]comate resume "
                "sess-123[/][/]"
            ),
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
