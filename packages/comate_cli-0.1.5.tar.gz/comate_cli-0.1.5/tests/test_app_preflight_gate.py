from __future__ import annotations

import unittest
from unittest.mock import AsyncMock, patch

from comate_cli.terminal_agent import app as app_module
from comate_cli.terminal_agent.preflight import PreflightResult


class TestAppPreflightGate(unittest.IsolatedAsyncioTestCase):
    async def test_run_aborts_when_preflight_blocks(self) -> None:
        with (
            patch.object(
                app_module,
                "run_preflight_if_needed",
                AsyncMock(
                    return_value=PreflightResult(
                        status="blocked_non_interactive",
                        detail="missing_llm_config",
                    )
                ),
            ) as preflight_mock,
            patch.object(app_module, "_build_agent") as build_agent_mock,
        ):
            await app_module.run(rpc_stdio=True)

        preflight_mock.assert_awaited_once()
        build_agent_mock.assert_not_called()


if __name__ == "__main__":
    unittest.main(verbosity=2)
