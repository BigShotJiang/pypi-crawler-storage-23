from __future__ import annotations

import asyncio
import unittest
from typing import Any

from comate_agent_sdk.agent.events import SessionInitEvent, StopEvent

from comate_cli.terminal_agent.rpc_protocol import ErrorCodes
from comate_cli.terminal_agent.rpc_stdio import StdioRPCBridge


class _FakeRunController:
    def __init__(self) -> None:
        self.interrupt_calls: list[str] = []

    def interrupt(self, reason: str = "user") -> None:
        self.interrupt_calls.append(reason)


class _FakeSession:
    def __init__(self) -> None:
        self.sent_messages: list[str] = []
        self.run_controller = _FakeRunController()
        self._events: asyncio.Queue[Any] = asyncio.Queue()

    async def send(self, message: str) -> None:
        self.sent_messages.append(message)

    async def push_event(self, event: Any) -> None:
        await self._events.put(event)

    async def events(self):  # noqa: ANN202
        while True:
            event = await self._events.get()
            yield event


class _CaptureBridge(StdioRPCBridge):
    def __init__(self, session: _FakeSession) -> None:
        super().__init__(session)  # type: ignore[arg-type]
        self.payloads: list[dict[str, Any]] = []

    async def _send(self, payload: dict[str, Any]) -> None:
        self.payloads.append(payload)


def _find_response(payloads: list[dict[str, Any]], request_id: int) -> dict[str, Any]:
    for payload in payloads:
        if payload.get("id") == request_id:
            return payload
    raise AssertionError(f"missing response for id={request_id}")


class TestRPCStdioBridge(unittest.IsolatedAsyncioTestCase):
    async def test_initialize_uses_session_init_event_session_id(self) -> None:
        session = _FakeSession()
        bridge = _CaptureBridge(session)
        pump_task = asyncio.create_task(bridge._run_event_pump())

        init_task = asyncio.create_task(bridge._handle_initialize(1))
        await session.push_event(SessionInitEvent(session_id="sid-from-event"))
        await init_task

        response = _find_response(bridge.payloads, 1)
        self.assertEqual(response["result"]["session_id"], "sid-from-event")

        pump_task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await pump_task

    async def test_cancel_interrupts_active_prompt_and_waits_for_stop_event(self) -> None:
        session = _FakeSession()
        bridge = _CaptureBridge(session)
        pump_task = asyncio.create_task(bridge._run_event_pump())
        await session.push_event(SessionInitEvent(session_id="sid-1"))

        await bridge._handle_prompt(10, {"user_input": "hello"})
        self.assertEqual(session.sent_messages, ["hello"])

        await bridge._handle_cancel(11)
        self.assertEqual(session.run_controller.interrupt_calls, ["rpc_cancel"])
        cancel_response = _find_response(bridge.payloads, 11)
        self.assertEqual(cancel_response["result"], {"cancelled": True})

        await session.push_event(StopEvent(reason="interrupted"))
        await asyncio.sleep(0)
        prompt_response = _find_response(bridge.payloads, 10)
        self.assertEqual(
            prompt_response["result"],
            {"status": "cancelled", "stop_reason": "interrupted"},
        )

        pump_task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await pump_task

    async def test_rejects_second_prompt_while_first_is_running(self) -> None:
        session = _FakeSession()
        bridge = _CaptureBridge(session)
        pump_task = asyncio.create_task(bridge._run_event_pump())
        await session.push_event(SessionInitEvent(session_id="sid-2"))

        await bridge._handle_prompt(21, {"user_input": "first"})
        await bridge._handle_prompt(22, {"user_input": "second"})
        conflict_response = _find_response(bridge.payloads, 22)
        self.assertEqual(conflict_response["error"]["code"], ErrorCodes.INVALID_STATE)

        await session.push_event(StopEvent(reason="completed"))
        await asyncio.sleep(0)
        first_response = _find_response(bridge.payloads, 21)
        self.assertEqual(
            first_response["result"],
            {"status": "completed", "stop_reason": "completed"},
        )

        pump_task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await pump_task


if __name__ == "__main__":
    unittest.main(verbosity=2)
