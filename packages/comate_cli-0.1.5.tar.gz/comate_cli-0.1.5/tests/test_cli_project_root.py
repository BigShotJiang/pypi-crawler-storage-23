from __future__ import annotations

import os
import unittest
from pathlib import Path

from comate_cli.terminal_agent.app import _resolve_cli_project_root


class TestCliProjectRoot(unittest.TestCase):
    def test_returns_cwd(self) -> None:
        expected = Path.cwd().expanduser().resolve()
        resolved = _resolve_cli_project_root()
        self.assertEqual(resolved, expected)

    def test_ignores_git_root_above_cwd(self) -> None:
        """即使祖先目录有 .git，也不应向上查找，只用 cwd。"""
        # 无论当前目录层级如何，结果都应等于 cwd
        expected = Path.cwd().expanduser().resolve()
        resolved = _resolve_cli_project_root()
        self.assertEqual(resolved, expected)

    def test_ignores_agent_settings_above_cwd(self) -> None:
        """即使祖先目录有 .agent/settings.json，也不向上查找。"""
        expected = Path.cwd().expanduser().resolve()
        resolved = _resolve_cli_project_root()
        self.assertEqual(resolved, expected)


if __name__ == "__main__":
    unittest.main(verbosity=2)
