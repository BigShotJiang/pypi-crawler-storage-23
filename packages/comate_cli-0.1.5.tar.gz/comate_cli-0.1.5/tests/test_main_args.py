from __future__ import annotations

import unittest
from importlib import import_module

main_module = import_module("comate_cli.main")


class TestMainArgs(unittest.TestCase):
    def test_parse_args_defaults_to_new_session(self) -> None:
        rpc_stdio, resume_session_id, resume_select = main_module._parse_args([])
        self.assertFalse(rpc_stdio)
        self.assertIsNone(resume_session_id)
        self.assertFalse(resume_select)

    def test_parse_args_resume_subcommand(self) -> None:
        rpc_stdio, resume_session_id, resume_select = main_module._parse_args(
            ["resume", "sid-001", "--rpc-stdio"]
        )
        self.assertTrue(rpc_stdio)
        self.assertEqual(resume_session_id, "sid-001")
        self.assertFalse(resume_select)

    def test_parse_args_resume_without_session_id_enters_selection_mode(self) -> None:
        rpc_stdio, resume_session_id, resume_select = main_module._parse_args(
            ["resume"]
        )
        self.assertFalse(rpc_stdio)
        self.assertIsNone(resume_session_id)
        self.assertTrue(resume_select)

    def test_parse_args_rejects_legacy_implicit_session_id(self) -> None:
        with self.assertRaises(main_module._ArgumentError):
            main_module._parse_args(["sid-legacy"])

    def test_parse_args_rejects_resume_without_session_id_with_rpc_stdio(self) -> None:
        with self.assertRaises(main_module._ArgumentError):
            main_module._parse_args(["resume", "--rpc-stdio"])

    def test_parse_args_rejects_unknown_option(self) -> None:
        with self.assertRaises(main_module._ArgumentError):
            main_module._parse_args(["--unknown"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
