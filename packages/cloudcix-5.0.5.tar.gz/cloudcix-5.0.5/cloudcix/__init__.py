"""CloudCIX API Module autodoc test"""
__version__ = '5.0.5'
