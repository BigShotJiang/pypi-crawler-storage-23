# Routine to store methods to calculate the local (individual finite el-
# ement level) residual vector due to body forces