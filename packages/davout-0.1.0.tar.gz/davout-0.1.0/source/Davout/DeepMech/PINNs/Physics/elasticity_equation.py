# Routine to store PINNs' methods for the divergence of the first Piola
# Kirchhoff stress tensor