# Routine to test PINNs with TensorFlow

import tensorflow as tf

import numpy as np

print("Importou tensor flow")