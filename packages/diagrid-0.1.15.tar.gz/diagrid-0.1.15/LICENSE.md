# DIAGRID INC BUSINESS SOURCE LICENSE AGREEMENT

## Business Source License 1.1

**Licensor:** Diagrid Inc  
**Licensed Work:** Diagrid Durable Agent Integration SDK for Python
The Licensed Work is © 2026–Present Diagrid Inc.

---

## Additional Use Grant

You may make production use of the Licensed Work without obtaining a commercial license from Licensor only if all of the following conditions are met:

1. The organization using the Licensed Work:
   - Has fewer than eighty (80) full-time equivalent employees; and  
   - Has less than twenty million U.S. dollars (USD $20,000,000) in annual gross revenue; and  
   - Is not directly or indirectly controlled by, controlling, or under common control with an entity that exceeds either of the above thresholds.

2. The Licensed Work is not:
   - Offered as a managed, hosted, or Software-as-a-Service (SaaS) offering;  
   - Included in, embedded within, or redistributed as part of a product or service whose primary purpose is to provide workflow orchestration, durable execution, agent runtime infrastructure, or similar infrastructure functionality;  
   - Commercially redistributed, sublicensed, or made available to third parties for a fee.

Any production use of the Licensed Work that does not satisfy all of the above conditions requires a valid commercial license from Diagrid Inc.

---

**Change Date:** March 1, 2029  
**Change License:** Apache License, Version 2.0

---

## Notice

The Business Source License (this document, or the "License") is not an Open Source license. However, the Licensed Work will eventually be made available under an Open Source License, as stated in this License.

License text copyright © 2017 MariaDB Corporation Ab, All Rights Reserved.  
"Business Source License" is a trademark of MariaDB Corporation Ab.

---

## Terms

The Licensor hereby grants You the right to copy, modify, create derivative works, redistribute, and make non-production use of the Licensed Work. The Licensor may make an Additional Use Grant, above, permitting limited production use.

Effective on the Change Date, or the fourth anniversary of the first publicly available distribution of a specific version of the Licensed Work under this License, whichever comes first, the Licensor hereby grants you rights under the terms of the Change License, and the rights granted in the paragraph above terminate.

If your use of the Licensed Work does not comply with the requirements currently in effect as described in this License, you must purchase a commercial license from the Licensor, its affiliated entities, or authorized resellers, or you must refrain from using the Licensed Work.

All copies of the original and modified Licensed Work, and derivative works of the Licensed Work, are subject to this License. This License applies separately for each version of the Licensed Work and the Change Date may vary for each version of the Licensed Work released by Licensor.

You must conspicuously display this License on each original or modified copy of the Licensed Work. If you receive the Licensed Work in original or modified form from a third party, the terms and conditions set forth in this License apply to your use of that work.

Any use of the Licensed Work in violation of this License will automatically terminate your rights under this License for the current and all other versions of the Licensed Work.

This License does not grant you any right in any trademark or logo of Licensor or its affiliates (provided that you may use a trademark or logo of Licensor as expressly required by this License).

TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE LICENSED WORK IS PROVIDED ON AN "AS IS" BASIS. LICENSOR HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS, EXPRESS OR IMPLIED, INCLUDING (WITHOUT LIMITATION) WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, AND TITLE.

MariaDB hereby grants you permission to use this License's text to license your works, and to refer to it using the trademark "Business Source License", as long as you comply with the Covenants of Licensor below.

---

## Covenants of Licensor

In consideration of the right to use this License's text and the "Business Source License" name and trademark, Licensor covenants to MariaDB, and to all other recipients of the licensed work to be provided by Licensor:

1. To specify as the Change License the GPL Version 2.0 or any later version, or a license that is compatible with GPL Version 2.0 or a later version. Licensor may specify additional Change Licenses without limitation.

2. To either:
   - (a) specify an additional grant of rights to use that does not impose any additional restriction on the right granted in this License, as the Additional Use Grant; or  
   - (b) insert the text "None".

3. To specify a Change Date.

4. Not to modify this License in any other way.