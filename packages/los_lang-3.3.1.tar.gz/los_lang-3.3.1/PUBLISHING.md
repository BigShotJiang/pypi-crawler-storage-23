# Publishing Guide (PyPI & Releases)

This guide explains how to build, test, and publish **los-lang** to PyPI correctly, ensuring a clean and professional release.

## 1. Prerequisites (Tools)

We use modern standards (`pyproject.toml`). You will need `build` and `twine`.

```bash
# Install build tools
pip install build twine
```

---

## 2. Pre-Flight Check (Do this FIRST)

Before publishing, ensure the codebase is clean and tests pass.

1.  **Run Tests**:
    ```bash
    python run_tests.py
    ```
    *(If this fails, DO NOT publish based on "faith". Fix it.)*

2.  **Verify Documentation**:
    Ensure `README.md` and `CHANGELOG.md` are updated for the new version.

3.  **Check Version**:
    The version in `pyproject.toml` **MUST** match `los/__init__.py`.
    ```bash
    # Check pyproject.toml
    grep "version" pyproject.toml
    
    # Check __init__.py
    grep "__version__" los/__init__.py
    ```

---

## 3. Build the Package

This step generates the distribution files (`.tar.gz` and `.whl`) in the `dist/` directory.

```bash
# Clean previous builds (optional but recommended)
rm -rf dist/

# Build source and wheel
python -m build
```

> **Note**: The `dist/` directory is ignored by `.gitignore`, so it won't pollute the repository.

---

## 4. Publish to PyPI (The Deployment)

### Option A: TestPyPI (Recommended for dry runs)
Upload to the testing server first to catch configuration errors.

```bash
twine upload --repository testpypi dist/*
```
*Install from TestPyPI to verify:* `pip install --index-url https://test.pypi.org/simple/ los-lang`

### Option B: Production PyPI (The Real Deal)
When you are 100% sure.

```bash
twine upload dist/*
```

---

## 5. Using `uv` (Fast Package Management)

`uv` is an ultra-fast Python package installer and resolver (written in Rust). 

**For Users (Consumers):**
Users can install LOS significantly faster using `uv`:

```bash
# 1. Install uv
pip install uv

# 2. Install LOS (blazing fast)
uv pip install los-lang
```

**For Maintainers (You):**
You can use `uv` to manage your local environments or lock dependencies, but for *publishing*, we still stick to the standard `build` + `twine` workflow for maximum compatibility.

---

## 6. GitHub Release (Tagging)

After publishing to PyPI, mark the release on GitHub.

1.  Go to **Releases** > **Draft a new release**.
2.  **Tag version**: `v3.3.1` (match PyPI version).
3.  **Title**: `v3.3.1 - Mathematical Robustness & Core Stability`.
4.  **Description**: Copy the content from `CHANGELOG.md`.

---

## Summary Checklist
- [ ] Tests passed (`python run_tests.py`)
- [ ] Versions match (`pyproject.toml` == `__init__.py`)
- [ ] `dist/` rebuilt (`python -m build`)
- [ ] Uploaded (`twine upload dist/*`)
- [ ] Git Tag created (`v3.3.1`)
