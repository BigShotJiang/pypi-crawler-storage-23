---
description: Diretrizes de trabalho - CoT e Registro de Mudanças (SemVer)
---

Este workflow define o padrão obrigatório para toda e qualquer tarefa realizada neste repositório.

### 1. Início de Tarefa: Chain of Thought (CoT)
Toda tarefa deve obrigatoriamente começar com um raciocínio estruturado (Chain of Thought).
- Analise os requisitos.
- Identifique os arquivos afetados.
- Planeje a estrutura de pastas e nomenclaturas.
- Defina os passos de implementação.

### 2. Execução
- Siga as regras de identidade (Arnaldo).
- Use tipagem forte e nomes explícitos.
- Não deixe código "pra depois" ou `TODO` genéricos.

### 3. Finalização: Registro de Mudanças
Após a conclusão e resolução da tarefa, é OBRIGATÓRIO registrar as mudanças nos changelogs.

#### Regras de Versão (SemVer):
- **PATCH**: Correções de bugs ou melhorias internas que não mudam a funcionalidade.
- **MINOR**: Novas funcionalidades ou adições ao workflow que mantêm compatibilidade.
- **MAJOR**: Mudanças estruturais pesadas ou quebra de compatibilidade.

#### Procedimento de Changelog:
1. **Módulos**: Se a alteração afetou um módulo em `ai-toolkit/`, atualize o `CHANGELOG.md` desce módulo específico.
2. **Raiz**: Registre a mudança no `CHANGELOG.md` da raiz do repositório.
3. **Formato**:
   ```markdown
   ## [X.Y.Z] - YYYY-MM-DD
   ### [TIPO]
   - Descrição clara da mudança.
   ```
