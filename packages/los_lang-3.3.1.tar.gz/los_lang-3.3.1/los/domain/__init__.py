"""
🏗️ Domain Layer - Camada de Domínio
Contém entidades, value objects e use cases centrais do negócio
"""
