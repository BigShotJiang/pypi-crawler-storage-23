"""
🔌 Adapters Layer - Camada de Adaptadores
Interfaces CLI, web e file processing
"""
