"""
CLI adapters
"""

from .los_cli import LOSCli

__all__ = ['LOSCli']
