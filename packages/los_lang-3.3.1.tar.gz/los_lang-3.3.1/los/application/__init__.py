"""
🎯 Application Layer - Camada de Aplicação  
Serviços de aplicação e DTOs
"""
