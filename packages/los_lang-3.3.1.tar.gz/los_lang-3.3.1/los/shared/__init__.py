"""
🤝 Shared Layer - Camada Compartilhada
Utilitários, logging e tratamento de erros usado por todas as camadas
"""
