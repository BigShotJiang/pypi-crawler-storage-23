"""auto-yes: automatically respond 'yes' to interactive CLI prompts."""

__version__ = "0.9.1"
