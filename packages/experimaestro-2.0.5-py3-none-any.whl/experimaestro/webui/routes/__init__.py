"""WebUI route modules"""

from experimaestro.webui.routes import auth, proxy

__all__ = ["auth", "proxy"]
