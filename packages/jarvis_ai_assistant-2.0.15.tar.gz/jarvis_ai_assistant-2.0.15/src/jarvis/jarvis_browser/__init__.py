"""Playwright Browser Module

A command-line tool for browser automation.
Use via execute_script: python -m jarvis.jarvis_browser.cli <command>
"""
