class O1TwoSum:
    """
    An algorithmic O(1) Two Sum solver for streaming data.
    Strictly limited to input integers between 0 and 50.
    """
    def __init__(self):
        # State is held in a single Python integer
        self.register = 0

    def ingest(self, num: int) -> None:
        """Records a number instantly. Algorithmic O(1)."""
        if 0 <= num <= 50:
            self.register |= (1 << num)
        else:
            raise ValueError(f"Input {num} exceeds the hardware-optimized limit of 50.")

    def _reverse_128_bits(self, n: int) -> int:
        """
        Reverses bits using fixed SIMD-style masking.
        Algorithmic O(1) - strictly 7 execution steps.
        """
        n = ((n & 0xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA) >> 1) | ((n & 0x55555555555555555555555555555555) << 1)
        n = ((n & 0xCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC) >> 2) | ((n & 0x33333333333333333333333333333333) << 2)
        n = ((n & 0xF0F0F0F0F0F0F0F0F0F0F0F0F0F0F0F0) >> 4) | ((n & 0x0F0F0F0F0F0F0F0F0F0F0F0F0F0F0F0F) << 4)
        n = ((n & 0xFF00FF00FF00FF00FF00FF00FF00FF00) >> 8) | ((n & 0x00FF00FF00FF00FF00FF00FF00FF00FF) << 8)
        n = ((n & 0xFFFF0000FFFF0000FFFF0000FFFF0000) >> 16) | ((n & 0x0000FFFF0000FFFF0000FFFF0000FFFF) << 16)
        n = ((n & 0xFFFFFFFF00000000FFFFFFFF00000000) >> 32) | ((n & 0x00000000FFFFFFFF00000000FFFFFFFF) << 32)
        n = ((n & 0xFFFFFFFFFFFFFFFF0000000000000000) >> 64) | ((n & 0x0000000000000000FFFFFFFFFFFFFFFF) << 64)
        return n

    def query(self, target: int) -> tuple:
        """
        Finds the pair in algorithmic O(1) time without looping.
        """
        if target < 0 or target > 100:
            return None

        reversed_reg = self._reverse_128_bits(self.register)
        shifted = reversed_reg >> (127 - target)
        overlap = self.register & shifted

        # Prevent a number from summing with itself unless we ingested duplicates
        # (Assuming distinct numbers for this specific bitmask logic)
        if target % 2 == 0:
            overlap &= ~(1 << (target // 2))

        if overlap == 0:
            return None  

        # Isolate the lowest bit using hardware-level logic
        first_num = (overlap & -overlap).bit_length() - 1
        return (first_num, target - first_num)