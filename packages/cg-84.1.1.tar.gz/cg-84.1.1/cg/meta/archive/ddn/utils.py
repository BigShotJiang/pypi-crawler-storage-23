def get_request_log(body: dict):
    return "Sending request with body: \n" + f"{body}"
