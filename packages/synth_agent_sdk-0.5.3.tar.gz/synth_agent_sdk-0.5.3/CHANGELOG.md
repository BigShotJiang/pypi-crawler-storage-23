# Changelog

All notable changes to the Synth SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.3] - 2025-02-19

### Fixed
- **AgentCore deployment pattern**: Updated `agentcore_handler()` to use the correct `BedrockAgentCoreApp` pattern required by AgentCore runtime
- **AgentCore dependencies**: Added `bedrock-agentcore>=0.1.0` to the `agentcore` extra for proper deployment support

### Changed
- `agentcore_handler()` now returns a `BedrockAgentCoreApp` instance instead of a plain function
- Updated all AgentCore scaffolding templates to use `app = agentcore_handler(agent)` pattern

## [0.5.2] - 2025-02-19

### Added
- **Quickstart extra**: New `synth-agent-sdk[quickstart]` installs both Anthropic and OpenAI providers for easy demos
- **First-run welcome message**: Beautiful onboarding experience on first `synth` command with setup guide
- **`synth info` command**: Shows what's included in each installation option (provider, dependencies, models)
- **Enhanced `synth doctor`**: Now suggests specific install commands when providers are missing

### Improved
- **Installation documentation**: Reorganized README to lead with most common use case
- **Error messages**: All provider errors now include clear `pip install` instructions
- **User experience**: Better guidance for new users throughout the installation and setup process

### Changed
- Installation section in README now recommends `synth-agent-sdk[anthropic]` as the starting point

## [0.5.1] - Previous Release

Initial release with core SDK functionality.
