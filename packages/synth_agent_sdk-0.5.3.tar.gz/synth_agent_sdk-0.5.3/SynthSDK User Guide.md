# Synth SDK User Guide

Welcome to Synth — a Python SDK for building AI agents that can think, use tools, remember conversations, and work together. Whether you want a simple chatbot or a complex multi-agent system, Synth gives you the building blocks to make it happen.

This guide walks you through everything from installation to deployment, written for newcomers who may be new to AI agent development.

---

## Table of Contents

1. [What is Synth?](#what-is-synth)
2. [Installation](#installation)
3. [Quick Start — Your First Agent in 3 Lines](#quick-start--your-first-agent-in-3-lines)
4. [Core Concepts](#core-concepts)
5. [Creating an Agent](#creating-an-agent)
6. [Giving Your Agent Tools](#giving-your-agent-tools)
7. [Running Your Agent](#running-your-agent)
8. [Streaming Responses](#streaming-responses)
9. [Choosing a Model Provider](#choosing-a-model-provider)
10. [Conversation Memory](#conversation-memory)
11. [Guards — Safety and Cost Controls](#guards--safety-and-cost-controls)
12. [Structured Output — Getting Typed Data Back](#structured-output--getting-typed-data-back)
13. [Pipelines — Chaining Agents Together](#pipelines--chaining-agents-together)
14. [Graphs — Complex Workflows with Branching](#graphs--complex-workflows-with-branching)
15. [Human-in-the-Loop — Pausing for Approval](#human-in-the-loop--pausing-for-approval)
16. [Agent Teams — Multi-Agent Collaboration](#agent-teams--multi-agent-collaboration)
17. [Tracing and Observability](#tracing-and-observability)
18. [Checkpointing — Resumable Runs](#checkpointing--resumable-runs)
19. [Evaluation — Testing Your Agent](#evaluation--testing-your-agent)
20. [CLI Commands](#cli-commands)
21. [Deploying to AWS AgentCore](#deploying-to-aws-agentcore)
22. [Error Handling](#error-handling)
23. [Environment Variables Reference](#environment-variables-reference)
24. [Frequently Asked Questions](#frequently-asked-questions)

---

## What is Synth?

Synth is a Python library that lets you build AI-powered agents. An "agent" is a program that uses a large language model (like Claude, GPT, or Gemini) to understand instructions, make decisions, and take actions — like calling functions, searching databases, or generating reports.

Think of it this way:
- A regular chatbot just answers questions.
- An agent can answer questions AND do things — look up data, run calculations, send emails, or coordinate with other agents.

Synth handles all the complicated plumbing (talking to AI providers, managing conversations, retrying on errors, tracking costs) so you can focus on what your agent actually does.

---

## Installation

Synth requires Python 3.10 or newer.

### Recommended Installation

Most users should start here:

```bash
pip install synth-agent-sdk[anthropic]     # Anthropic Claude (recommended)
```

### Other Installation Options

```bash
# For tutorials and demos (Claude + GPT)
pip install synth-agent-sdk[quickstart]

# Individual providers
pip install synth-agent-sdk[openai]        # OpenAI GPT only
pip install synth-agent-sdk[google]        # Google Gemini only
pip install synth-agent-sdk[ollama]        # Local Ollama models
pip install synth-agent-sdk[bedrock]       # AWS Bedrock only

# AWS AgentCore deployment
pip install synth-agent-sdk[agentcore]

# Install everything at once
pip install synth-agent-sdk[all]
```

### First-Time Setup

After installation, run `synth` to see a welcome message with setup instructions:

```bash
synth
```

This displays a one-time welcome guide with:
- Provider installation options
- API key setup instructions
- Next steps to get building

To verify your setup:

```bash
synth doctor
```

This checks your Python version, dependencies, API keys, and shows which providers are installed. If any providers are missing, it suggests the exact install command.

### Viewing Package Information

To see what's included in each installation option:

```bash
synth info --extra anthropic
synth info --extra quickstart
synth info --extra all
```

This shows the provider name, dependencies, and available models for each option.

### Setting Up Your API Key

Before using a provider, set the appropriate environment variable with your API key:

```bash
# Anthropic (Claude)
export ANTHROPIC_API_KEY="your-key-here"

# OpenAI (GPT)
export OPENAI_API_KEY="your-key-here"

# Google (Gemini)
export GOOGLE_API_KEY="your-key-here"

# AWS Bedrock — uses standard AWS credentials (IAM role, env vars, or AWS config)
# No Synth-specific key needed.
```

On Windows, use `set` instead of `export`:

```cmd
set ANTHROPIC_API_KEY=your-key-here
```

### Troubleshooting Installation

If you see an error like:
```
SynthConfigError: Provider package 'anthropic' is not installed.
Run: pip install synth-agent-sdk[anthropic]
```

Simply run the suggested command to install the missing provider.

---

## Quick Start — Your First Agent in 3 Lines

```python
from synth import Agent

agent = Agent(model="claude-sonnet-4-5", instructions="You are a helpful assistant.")
result = agent.run("What is the capital of France?")
print(result.text)
# => "The capital of France is Paris."
```

That's it. Three lines to create a working AI agent. Let's break down what happened:

1. We imported the `Agent` class from Synth.
2. We created an agent, telling it which AI model to use and giving it instructions (a "system prompt" that shapes its personality and behavior).
3. We called `agent.run()` with a question. The agent sent it to the AI model and returned the answer inside a `RunResult` object.

---

## Core Concepts

Before diving deeper, here are the key ideas in Synth:

| Concept | What It Is |
|---------|-----------|
| Agent | The main building block. Wraps an AI model with tools, memory, and guards. |
| Tool | A Python function your agent can call to do things (look up data, calculate, etc.). |
| ToolKit | A bundle of related tools grouped together. |
| RunResult | The object returned by `agent.run()` — contains the response text, token usage, cost, latency, and trace. |
| Memory | Lets your agent remember previous conversations across multiple calls. |
| Guard | A safety rule applied to input or output (block PII, limit cost, etc.). |
| Pipeline | Chains multiple agents in sequence — output of one becomes input of the next. |
| Graph | A workflow with branching, loops, and conditional logic. |
| AgentTeam | Multiple specialized agents coordinated by an orchestrator. |
| Trace | A detailed record of everything that happened during a run (for debugging). |
| Checkpoint | A saved snapshot of a run's state, so it can be resumed later. |

---

## Creating an Agent

The `Agent` class is the heart of Synth. Here is every parameter it accepts:

```python
from synth import Agent, tool, ToolKit, Guard, Memory

agent = Agent(
    model="claude-sonnet-4-5",       # Which AI model to use (see "Choosing a Model Provider")
    instructions="You are helpful.",  # System prompt — tells the model how to behave
    tools=[my_tool, my_toolkit],     # Functions and toolkits the agent can call (optional)
    memory=Memory.thread(),          # Conversation memory backend (optional)
    guards=[Guard.no_pii_output()],  # Safety rules (optional)
    output_schema=MyModel,           # Pydantic model for structured output (optional)
    base_url="https://...",          # Custom API endpoint (optional)
    max_retries=3,                   # How many times to retry on transient errors
    retry_backoff=1.0,               # Base delay in seconds between retries
)
```

All parameters except `model` are optional. If you don't provide a `model`, Synth defaults to `claude-sonnet-4-5`.

```python
# This works too — uses the default model
agent = Agent(instructions="You are a poet.")
```

---

## Giving Your Agent Tools

Tools are regular Python functions that your agent can decide to call. You mark them with the `@tool` decorator, and Synth automatically figures out how to describe them to the AI model.

### Creating a Tool

```python
from synth import tool

@tool
def get_weather(city: str) -> str:
    """Get the current weather for a city."""
    # Your real implementation here
    return f"The weather in {city} is sunny, 72°F."
```

Two rules for `@tool` functions:
1. Every parameter must have a type annotation (like `city: str`).
2. The function must have a docstring (the text in triple quotes). This is what the AI model reads to understand what the tool does.

If either is missing, Synth raises a `ToolDefinitionError` immediately — you'll know right away, not at runtime.

### Passing Tools to an Agent

```python
agent = Agent(
    model="claude-sonnet-4-5",
    instructions="You are a weather assistant.",
    tools=[get_weather],
)

result = agent.run("What's the weather in Tokyo?")
print(result.text)
# The agent will call get_weather("Tokyo") and use the result in its answer.
```

### Grouping Tools with ToolKit

If you have many related tools, bundle them into a `ToolKit`:

```python
from synth import ToolKit

@tool
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b

@tool
def multiply(a: int, b: int) -> int:
    """Multiply two numbers."""
    return a * b

math_tools = ToolKit([add, multiply])

agent = Agent(
    model="gpt-4o",
    instructions="You are a math tutor.",
    tools=[math_tools],
)
```

You can mix individual tools and toolkits in the same list:

```python
agent = Agent(tools=[get_weather, math_tools, some_other_tool])
```

### What Happens When a Tool Is Called

When you run your agent, the AI model might decide it needs to call one of your tools. Here's the flow:

1. You call `agent.run("What's the weather in Tokyo?")`.
2. The AI model sees the `get_weather` tool description and decides to call it.
3. Synth executes `get_weather("Tokyo")` and captures the return value.
4. The return value is sent back to the AI model as context.
5. The AI model writes a final answer using the tool's result.
6. You get back a `RunResult` with the full answer.

You can see which tools were called by inspecting `result.tool_calls`:

```python
result = agent.run("What's the weather in Tokyo?")
for tc in result.tool_calls:
    print(f"Tool: {tc.name}, Args: {tc.args}, Result: {tc.result}, Took: {tc.latency_ms:.1f}ms")
```

---

## Running Your Agent

There are two ways to run an agent: synchronous (blocking) and asynchronous (non-blocking).

### Synchronous — `agent.run()`

Use this in scripts, notebooks, or anywhere you just want the answer:

```python
result = agent.run("Explain quantum computing in simple terms.")
print(result.text)        # The model's text response
print(result.tokens)      # TokenUsage(input_tokens=..., output_tokens=..., total_tokens=...)
print(result.cost)        # Estimated cost in USD
print(result.latency_ms)  # How long the call took in milliseconds
print(result.tool_calls)  # List of tools that were called
print(result.trace)       # Detailed execution trace (for debugging)
print(result.output)      # Parsed structured output (if output_schema was set, otherwise None)
```

### Asynchronous — `await agent.arun()`

Use this in async web servers (FastAPI, Starlette), async scripts, or anywhere you're already using `async`/`await`:

```python
import asyncio

async def main():
    agent = Agent(model="claude-sonnet-4-5", instructions="You are helpful.")
    result = await agent.arun("What is 2 + 2?")
    print(result.text)

asyncio.run(main())
```

Both `run()` and `arun()` return the same `RunResult` object. Under the hood, `run()` just calls `arun()` and handles the event loop for you.

---

## Streaming Responses

Instead of waiting for the entire response, you can receive it piece by piece as the model generates it. This is great for building real-time UIs.

### Synchronous Streaming — `agent.stream()`

```python
for event in agent.stream("Write a short poem about coding."):
    if isinstance(event, TokenEvent):
        print(event.text, end="", flush=True)  # Print each token as it arrives
    elif isinstance(event, ToolCallEvent):
        print(f"\n[Calling tool: {event.name}]")
    elif isinstance(event, ToolResultEvent):
        print(f"[Tool result: {event.result}]")
    elif isinstance(event, ThinkingEvent):
        print(f"[Thinking: {event.text}]")
    elif isinstance(event, DoneEvent):
        print(f"\n\nDone! Total tokens: {event.result.tokens.total_tokens}")
    elif isinstance(event, ErrorEvent):
        print(f"\nError: {event.error}")
```

### Asynchronous Streaming — `async for event in agent.astream()`

```python
async for event in agent.astream("Write a haiku."):
    if isinstance(event, TokenEvent):
        print(event.text, end="", flush=True)
```

### Stream Event Types

| Event | When It Happens |
|-------|----------------|
| `TokenEvent` | The model produced a piece of text. |
| `ToolCallEvent` | The model decided to call a tool (before execution). |
| `ToolResultEvent` | A tool finished executing (after execution). |
| `ThinkingEvent` | The model produced a reasoning/thinking token (some models support this). |
| `DoneEvent` | The stream completed successfully. Contains the full `RunResult`. |
| `ErrorEvent` | Something went wrong. Contains the exception. |

Import them from `synth`:

```python
from synth import TokenEvent, ToolCallEvent, ToolResultEvent, ThinkingEvent, DoneEvent, ErrorEvent
```

---

## Choosing a Model Provider

Synth supports multiple AI providers. You switch between them by changing the `model` string — no other code changes needed.

### Supported Providers

| Provider | Model String Examples | Required Extra | API Key Env Var |
|----------|----------------------|----------------|-----------------|
| Anthropic (Claude) | `"claude-sonnet-4-5"`, `"claude-haiku-3-5"` | `synth[anthropic]` | `ANTHROPIC_API_KEY` |
| OpenAI (GPT) | `"gpt-4o"`, `"gpt-4o-mini"` | `synth[openai]` | `OPENAI_API_KEY` |
| Google (Gemini) | `"gemini-2.0-flash"` | `synth[google]` | `GOOGLE_API_KEY` |
| Ollama (Local) | `"ollama/llama3"`, `"ollama/mistral"` | `synth[ollama]` | None (runs locally) |
| AWS Bedrock | `"bedrock/claude-sonnet-4-5"`, `"bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0"` | `synth[bedrock]` | AWS credentials (IAM) |

### Switching Providers

```python
# Use Claude
agent = Agent(model="claude-sonnet-4-5", instructions="You are helpful.")

# Switch to GPT — just change the model string
agent = Agent(model="gpt-4o", instructions="You are helpful.")

# Switch to a local Ollama model — no API key needed
agent = Agent(model="ollama/llama3", instructions="You are helpful.")

# Use AWS Bedrock
agent = Agent(model="bedrock/claude-sonnet-4-5", instructions="You are helpful.")
```

### Custom Endpoints

If you're running a model behind a proxy or using an OpenAI-compatible API, pass `base_url`:

```python
agent = Agent(
    model="my-custom-model",
    base_url="https://my-proxy.example.com/v1",
    instructions="You are helpful.",
)
```

When `base_url` is provided and the model string doesn't match any known prefix, Synth uses an OpenAI-compatible provider pointed at your endpoint.

### Automatic Retries

If the AI provider returns a rate-limit error (HTTP 429) or a server error (HTTP 5xx), Synth automatically retries with exponential backoff. You can configure this:

```python
agent = Agent(
    model="claude-sonnet-4-5",
    max_retries=5,       # Try up to 5 times (default is 3)
    retry_backoff=2.0,   # Start with a 2-second delay (default is 1.0)
)
```

The delay between retries doubles each time (with a bit of randomness added), so: 2s → 4s → 8s → 16s → 32s.

---

## Conversation Memory

By default, each `agent.run()` call is stateless — the agent doesn't remember previous conversations. To give your agent memory, use the `Memory` factory.

### Thread Memory (In-Process)

Stores conversations in memory, grouped by a `thread_id`. Fast and simple, but lost when your program exits.

```python
from synth import Agent, Memory

agent = Agent(
    model="claude-sonnet-4-5",
    instructions="You are a helpful assistant.",
    memory=Memory.thread(),
)

# First message in thread "user-123"
result = agent.run("My name is Alice.", thread_id="user-123")

# Second message in the same thread — the agent remembers the first
result = agent.run("What's my name?", thread_id="user-123")
print(result.text)  # "Your name is Alice."

# Different thread — no memory of Alice
result = agent.run("What's my name?", thread_id="user-456")
print(result.text)  # "I don't know your name."
```

If you don't pass a `thread_id`, the call is treated as a one-off with no memory.

You can set a token limit to prevent memory from growing too large:

```python
memory = Memory.thread(max_tokens=50_000)  # Default is 100,000
```

When the limit is exceeded, older messages are automatically removed and a warning is emitted.

### Persistent Memory (Redis)

Stores conversations in Redis so they survive restarts and can be shared across processes.

```python
agent = Agent(
    model="gpt-4o",
    instructions="You are a support agent.",
    memory=Memory.persistent("redis://localhost:6379"),
)

# Conversations persist across program restarts
result = agent.run("I need help with billing.", thread_id="ticket-789")
```

Requires the `redis` package: `pip install redis`.

### Semantic Memory (Vector Embeddings)

Stores messages as vector embeddings and retrieves the most relevant context using cosine similarity. Useful when you have long conversation histories and only want the most relevant parts.

```python
def my_embedder(text: str) -> list[float]:
    """Your embedding function — could call OpenAI, a local model, etc."""
    # Return a vector representation of the text
    ...

agent = Agent(
    model="gemini-2.0-flash",
    instructions="You are a research assistant.",
    memory=Memory.semantic(embedder=my_embedder),
)
```

---

## Guards — Safety and Cost Controls

Guards are rules that check your agent's input or output before it's returned to you. They run automatically — you just declare them.

### Built-In Guards

```python
from synth import Agent, Guard

agent = Agent(
    model="claude-sonnet-4-5",
    instructions="You are a customer service agent.",
    guards=[
        Guard.no_pii_output(),            # Block responses containing emails, phone numbers, SSNs
        Guard.max_cost(dollars=0.50),      # Stop if the run costs more than $0.50
        Guard.no_tool_calls(["delete_*"]), # Block any tool whose name starts with "delete_"
        Guard.custom(my_check_function),   # Run your own custom check
    ],
)
```

### How Guards Work

- Guards are checked in the order you list them.
- If any guard fails, execution stops immediately and an error is raised.
- Input guards run before the AI model is called.
- Output guards run after the AI model responds.

### Guard Details

**`Guard.no_pii_output()`** — Scans the response for personally identifiable information using pattern matching. Detects email addresses, US phone numbers, and Social Security Numbers. Raises `GuardViolationError` if PII is found.

**`Guard.max_cost(dollars=0.10)`** — Tracks the cumulative cost of the run. If it exceeds the limit, raises `CostLimitError`. Useful for preventing runaway costs in loops or complex workflows.

**`Guard.no_tool_calls(["delete_*", "drop_*"])`** — Blocks tool calls whose names match the given glob patterns. For example, `"delete_*"` blocks `delete_user`, `delete_file`, etc. Raises `GuardViolationError`.

**`Guard.custom(fn)`** — Wraps your own function. The function receives the content string and should return `True` (pass) or `False` (fail). If it raises an exception, that's also treated as a failure.

```python
def no_profanity(content: str) -> bool:
    """Block responses containing profanity."""
    bad_words = ["badword1", "badword2"]
    return not any(word in content.lower() for word in bad_words)

agent = Agent(
    model="claude-sonnet-4-5",
    guards=[Guard.custom(no_profanity)],
)
```

---

## Structured Output — Getting Typed Data Back

Sometimes you don't want a free-form text response — you want structured data you can use directly in your code. Synth can instruct the model to return JSON matching a Pydantic model and parse it automatically.

```python
from pydantic import BaseModel
from synth import Agent

class MovieReview(BaseModel):
    title: str
    rating: float
    summary: str
    recommended: bool

agent = Agent(
    model="claude-sonnet-4-5",
    instructions="You are a movie critic.",
    output_schema=MovieReview,
)

result = agent.run("Review the movie Inception.")
review = result.output  # This is a MovieReview instance, not a string

print(review.title)        # "Inception"
print(review.rating)       # 9.2
print(review.summary)      # "A mind-bending thriller..."
print(review.recommended)  # True
```

If the model's output can't be parsed into your schema, Synth automatically retries with a corrective prompt (up to `max_retries` times). If it still fails, a `SynthParseError` is raised.

The raw text is always available in `result.text`, even when structured output is used.

---

## Pipelines — Chaining Agents Together

A Pipeline runs multiple agents in sequence. The output of each agent becomes the input of the next.

```python
from synth import Agent, Pipeline

researcher = Agent(model="claude-sonnet-4-5", instructions="You research topics thoroughly.")
writer = Agent(model="claude-sonnet-4-5", instructions="You write clear, engaging articles.")
editor = Agent(model="claude-sonnet-4-5", instructions="You edit text for grammar and clarity.")

pipeline = Pipeline([researcher, writer, editor])
result = pipeline.run("The history of the internet")

print(result.text)  # A well-researched, well-written, well-edited article
```

### How It Works

1. `researcher` receives `"The history of the internet"` and produces research notes.
2. `writer` receives the research notes and produces a draft article.
3. `editor` receives the draft and produces the final polished version.
4. You get back the `RunResult` from the last stage.

### Parallel Groups

You can run some agents in parallel within a pipeline using `ParallelGroup`:

```python
from synth.orchestration.pipeline import ParallelGroup

fact_checker = Agent(model="gpt-4o", instructions="You verify facts.")
style_checker = Agent(model="gpt-4o", instructions="You check writing style.")

pipeline = Pipeline([
    writer,
    ParallelGroup([fact_checker, style_checker]),  # These run at the same time
    editor,
])

result = pipeline.run("Write about climate change.")
```

By default, parallel results are joined with newlines. You can provide a custom merge function:

```python
def merge_reviews(results):
    return "FACT CHECK:\n" + results[0].text + "\n\nSTYLE CHECK:\n" + results[1].text

parallel = ParallelGroup([fact_checker, style_checker], merge=merge_reviews)
```

### Pipeline Streaming

Stream events from each stage, labeled with the stage name:

```python
for stage_event in pipeline.stream("Write about AI"):
    print(f"[{stage_event.stage_name}] {stage_event.event}")
```

Each event is a `StageEvent` wrapping a regular `StreamEvent` with the stage name attached.

### Structured Output in Pipelines

If you pass `output_schema` to a pipeline, only the final stage's output is validated:

```python
result = pipeline.run("Summarize AI trends", output_schema=MySummaryModel)
```

### Error Handling

If any stage fails, the pipeline stops and raises a `PipelineError` containing:
- `failed_step` — which step failed (zero-indexed)
- `agent_name` — the name of the failing agent
- `partial_results` — results from all stages that completed before the failure

---

## Graphs — Complex Workflows with Branching

When you need more than a straight line — branching, loops, conditional logic — use a `Graph`. A graph is made of nodes (processing steps) and edges (connections between them).

### Basic Graph

```python
from synth import Graph, node

graph = Graph()

@node(graph)
def classify(state):
    """Classify the incoming request."""
    text = state["text"]
    if "urgent" in text.lower():
        state["priority"] = "high"
    else:
        state["priority"] = "low"
    return state

@node(graph)
def handle_urgent(state):
    """Handle urgent requests."""
    state["response"] = "Escalating to senior support immediately."
    return state

@node(graph)
def handle_normal(state):
    """Handle normal requests."""
    state["response"] = "We'll get back to you within 24 hours."
    return state

# Wire up the edges
graph.set_entry("classify")  # Start here
graph.add_edge("classify", "handle_urgent", when=lambda s: s["priority"] == "high")
graph.add_edge("classify", "handle_normal", when=lambda s: s["priority"] == "low")
graph.add_edge("handle_urgent", Graph.END)  # Graph.END means "stop here"
graph.add_edge("handle_normal", Graph.END)

# Run it
result = graph.run({"text": "This is urgent! Server is down!"})
print(result.output)  # {"text": "...", "priority": "high", "response": "Escalating..."}
```

### Key Concepts

- **Nodes** are functions that receive a state dict (or any object) and return an updated state.
- **Edges** connect nodes. They can be unconditional or conditional (with a `when` function).
- **`Graph.END`** is a special sentinel that means "stop execution and return the result."
- **`graph.set_entry("node_name")`** tells the graph where to start.

### The `@node` Decorator

The `@node` decorator is a shortcut for `graph.add_node()`. You can also add nodes manually:

```python
graph.add_node("my_step", my_function)
```

If you don't provide a name to `@node`, it uses the function's name.

### Conditional Edges

Edges can have conditions. The `when` parameter is a function that receives the current state and returns `True` or `False`:

```python
graph.add_edge("classify", "handle_urgent", when=lambda s: s["priority"] == "high")
graph.add_edge("classify", "handle_normal")  # No condition = default/fallback edge
```

If no edge condition matches at a node, Synth raises a `GraphRoutingError` telling you which node got stuck and what the state looked like.

### Loops

Graphs support loops. A node can have an edge back to an earlier node:

```python
graph.add_edge("review", "draft", when=lambda s: not s["approved"])  # Loop back
graph.add_edge("review", Graph.END, when=lambda s: s["approved"])    # Exit
```

To prevent infinite loops, Synth enforces a `max_iterations` limit (default: 100). If exceeded, a `GraphLoopError` is raised with the full history of which nodes were visited.

```python
result = graph.run(initial_state, max_iterations=50)  # Custom limit
```

### State Validation with Pydantic

You can enforce a schema on the graph state:

```python
from pydantic import BaseModel

class TicketState(BaseModel):
    text: str
    priority: str = ""
    response: str = ""

graph = Graph(state_schema=TicketState)
```

After each node runs, the state is validated against the schema. If it doesn't match, you get a clear validation error.

### Visualizing Your Graph

Generate a Mermaid diagram of your graph structure:

```python
print(graph.visualise())
```

Output:
```
graph TD
    classify["classify"]
    handle_urgent["handle_urgent"]
    handle_normal["handle_normal"]
    END(["END"])
    classify -->|<lambda>| handle_urgent
    classify --> handle_normal
    handle_urgent --> END
    handle_normal --> END
```

Paste this into any Mermaid renderer (GitHub markdown, Mermaid Live Editor, etc.) to see a visual diagram.

### Sync and Async

Like agents, graphs support both sync and async:

```python
# Sync
result = graph.run(initial_state)

# Async
result = await graph.arun(initial_state)
```

---

## Human-in-the-Loop — Pausing for Approval

Sometimes you want a human to review and approve before the workflow continues. Graphs support pausing at specific nodes.

```python
graph = Graph()

@node(graph)
def draft_email(state):
    state["draft"] = "Dear customer, we're sorry about the issue..."
    return state

@node(graph)
def send_email(state):
    # Actually send the email
    state["sent"] = True
    return state

graph.set_entry("draft_email")
graph.add_edge("draft_email", "send_email")
graph.add_edge("send_email", Graph.END)

# Pause after drafting, before sending
graph.with_human_in_the_loop(pause_at=["draft_email"])
graph.with_checkpointing()  # Required — saves state so it can be resumed

# Run the graph
result = graph.run({"customer": "Alice"}, run_id="email-001")
# result is a PausedRun, not a RunResult

print(result.paused_at_node)  # "draft_email"
print(result.state["draft"])  # The draft email text

# Human reviews and approves...
# Resume from where we left off
final_result = graph.resume("email-001", human_input="Looks good, send it.")
print(final_result.output["sent"])  # True
```

### Configuration Options

```python
graph.with_human_in_the_loop(
    pause_at=["draft_email", "review_step"],  # Pause at these nodes
    timeout=3600,                              # Wait up to 1 hour for human input
    fallback="cancel_node",                    # If timeout expires, go to this node instead
)
```

The checkpoint is persisted to disk (or Redis), so `resume()` can be called from a different process or even a different server.

---

## Agent Teams — Multi-Agent Collaboration

An `AgentTeam` coordinates multiple specialized agents under an orchestrator that decides who handles what.

```python
from synth import Agent, AgentTeam

researcher = Agent(
    model="claude-sonnet-4-5",
    instructions="You are an expert researcher. You find and verify facts.",
)
writer = Agent(
    model="claude-sonnet-4-5",
    instructions="You are a skilled writer. You create engaging content.",
)
analyst = Agent(
    model="claude-sonnet-4-5",
    instructions="You are a data analyst. You interpret numbers and trends.",
)

team = AgentTeam(
    orchestrator="claude-sonnet-4-5",  # The model that coordinates the team
    agents=[researcher, writer, analyst],
    strategy="auto",  # Let the orchestrator decide who does what
)

result = team.run("Write a report on renewable energy trends in 2025.")
print(result.answer)           # The final synthesized answer
print(result.contributions)    # Each agent's individual contribution
print(result.total_cost)       # Combined cost across all agents
print(result.total_latency_ms) # Total time taken
```

### Strategies

**`strategy="auto"` (default)** — The orchestrator model receives the task and descriptions of all available agents. It decides which agent to delegate to, collects the result, and can delegate again or synthesize a final answer.

**`strategy="parallel"`** — All agents receive the task at the same time and work concurrently. Results are aggregated into a `TeamResult`.

```python
team = AgentTeam(
    orchestrator="claude-sonnet-4-5",
    agents=[researcher, writer, analyst],
    strategy="parallel",
)
```

### Handoffs

Agents in a team can explicitly hand off to another agent using a special `handoff` tool that Synth injects automatically:

```python
# The orchestrator or any agent can call:
# handoff(target_agent="writer", context="Here are the research notes...")
```

This transfers control to the named agent with the provided context.

### TeamResult

The `TeamResult` object contains:
- `answer` — the final synthesized answer
- `contributions` — a list of `AgentContribution` objects (each with `agent_name` and `result`)
- `message_trace` — the full message history across all agents
- `total_cost` — combined cost
- `total_latency_ms` — total wall-clock time

---

## Tracing and Observability

Every time you run an agent, Synth automatically records a detailed trace of everything that happened — every AI model call, every tool execution, every guard check, with timestamps, token counts, and costs.

### Accessing the Trace

```python
result = agent.run("Summarize this document.")
trace = result.trace

print(f"Total tokens: {trace.total_tokens}")
print(f"Total cost: ${trace.total_cost:.4f}")
print(f"Total latency: {trace.total_latency_ms:.1f}ms")
print(f"Number of spans: {len(trace.spans)}")

# Inspect individual spans
for span in trace.spans:
    print(f"  {span.type}: {span.name} ({span.metadata})")
```

### Viewing Traces in the Browser

Open a visual timeline of the trace in your default browser:

```python
result.trace.show()
```

This generates a self-contained HTML page with a table showing each span's name, type, start time, and duration.

### Exporting Traces

Export the trace as an OpenTelemetry-compatible JSON file:

```python
path = result.trace.export()                    # Auto-named: synth_trace_20260217T...Z.json
path = result.trace.export("my_trace.json")     # Custom path
```

### Automatic Trace Forwarding

Set the `SYNTH_TRACE_ENDPOINT` environment variable to automatically forward all traces to an OpenTelemetry collector:

```bash
export SYNTH_TRACE_ENDPOINT="https://my-otel-collector.example.com/v1/traces"
```

No code changes needed — Synth sends traces automatically after each run.

### Third-Party Integrations

Synth provides adapter stubs for popular observability platforms:

```python
from synth.tracing.integrations import LangfuseIntegration, DatadogIntegration, HoneycombIntegration

# Langfuse
langfuse = LangfuseIntegration(
    public_key="pk-...",
    secret_key="sk-...",
)
langfuse.send(result.trace)

# Datadog
datadog = DatadogIntegration(api_key="dd-...")
datadog.send(result.trace)

# Honeycomb
honeycomb = HoneycombIntegration(api_key="hc-...", dataset="my-agents")
honeycomb.send(result.trace)
```

### Trace Span Types

Each span in a trace has a `type` field:

| Span Type | What It Records |
|-----------|----------------|
| `llm_call` | A call to the AI model (includes token counts). |
| `tool_call` | A tool function execution (includes latency). |
| `guard_check` | A guard evaluation (includes pass/fail). |
| `node_execution` | A graph node execution. |

---

## Checkpointing — Resumable Runs

Checkpointing saves the state of a graph execution after each node, so you can resume from where you left off if something goes wrong.

### Enabling Checkpointing

```python
graph = Graph()
# ... add nodes and edges ...

# Enable checkpointing (saves to .synth/checkpoints/ by default)
graph.with_checkpointing()

# Run with a run_id so the checkpoint can be found later
result = graph.run(initial_state, run_id="my-run-001")
```

### Resuming a Run

```python
# Later (even in a different process)...
result = graph.resume("my-run-001")
```

If no checkpoint exists for the given `run_id`, a `RunNotFoundError` is raised.

### Checkpoint Stores

**Local Disk (default)** — Saves JSON files to `.synth/checkpoints/{run_id}/`. Uses atomic writes (write to a temp file, then rename) to prevent corruption.

```python
graph.with_checkpointing()  # Uses LocalCheckpointStore by default
```

**Redis** — For distributed systems where multiple processes or servers need to share checkpoints.

```python
from synth.checkpointing.redis import RedisCheckpointStore

graph.with_checkpointing(store=RedisCheckpointStore("redis://localhost:6379"))
```

Checkpoint data is always JSON — never pickle or other formats that could execute arbitrary code.

---

## Evaluation — Testing Your Agent

The `Eval` framework lets you run structured tests against your agent to measure quality, detect regressions, and track performance over time.

### Basic Evaluation

```python
from synth import Agent, Eval

agent = Agent(model="claude-sonnet-4-5", instructions="You are a geography expert.")

evaluation = Eval(agent=agent)
evaluation.add_case(input="What is the capital of France?", expected="Paris")
evaluation.add_case(input="What is the capital of Japan?", expected="Tokyo")
evaluation.add_case(input="What is the capital of Brazil?", expected="Brasília")

report = evaluation.run()

print(f"Overall score: {report.overall_score}")
print(f"Total cost: ${report.total_cost:.4f}")
print(f"Total latency: {report.total_latency_ms:.1f}ms")

for case in report.cases:
    status = "PASS" if case.passed else "FAIL"
    print(f"  [{status}] Input: {case.input}, Expected: {case.expected}, Got: {case.actual}")
```

### Scoring Methods

By default, Synth uses:
- **Exact match** — binary 1.0 (match) or 0.0 (no match).
- **Semantic similarity** — cosine similarity of embeddings, giving a score between 0.0 and 1.0.

### Custom Checkers

For more nuanced evaluation, provide a custom checker function:

```python
def check_contains_keyword(output: str, expected: str) -> float:
    """Score 1.0 if the expected keyword appears in the output, 0.0 otherwise."""
    return 1.0 if expected.lower() in output.lower() else 0.0

evaluation.add_case(
    input="Tell me about photosynthesis.",
    expected="chlorophyll",
    checker=check_contains_keyword,
)
```

Custom checkers receive `(output, expected)` and return a float score from 0.0 to 1.0.

### Comparing Reports

Track quality over time by comparing evaluation reports:

```python
baseline_report = evaluation.run()  # Run once as baseline

# ... make changes to your agent ...

new_report = evaluation.run()
comparison = new_report.compare(baseline_report)

print(f"Baseline score: {comparison.baseline_score}")
print(f"Current score: {comparison.current_score}")
print(f"Regressions: {len(comparison.regressions)}")
print(f"Improvements: {len(comparison.improvements)}")
```

---

## CLI Commands

Synth includes a command-line interface for running, testing, debugging, and deploying agents. After installing Synth, the `synth` command is available in your terminal.

### Boot Sequence

Run `synth` with no arguments to see the Fallout-inspired boot sequence:

```bash
synth
```

This displays the SynthAgentSDK ASCII art logo, system status checks, and a `>> SYSTEM READY` confirmation. The boot sequence also appears automatically before any subcommand.

To suppress it, set `SYNTH_NO_BANNER=1` in your environment.

### `synth init` — Interactive Project Setup

The fastest way to start a new project. Walks you through provider selection, feature toggles, and generates everything you need.

```bash
synth init
```

This prompts for:
1. Project name
2. Description
3. Provider (Anthropic, OpenAI, Llama, Gemini, AgentCore)
4. Features (tools, memory, guards, structured output, eval, deploy)
5. Agent instructions

Then generates a tailored project with `agent.py`, `tools.py` (if selected), `synth.toml` config, and `README.md`.

### `synth create` — Scaffold Projects

Scaffold specific project types without the full interactive flow:

```bash
synth create agent my-bot              # Interactive provider selection
synth create agent my-bot -p openai    # Skip prompt, use OpenAI directly
synth create agentcore my-service      # AWS AgentCore deployment project
synth create team my-team              # Multi-agent team + pipeline
synth create tool my-tools             # Standalone tools file with examples
synth create mcp my-server             # MCP server with FastMCP
synth create ui my-ui                  # Local browser-based testing UI
```

**Provider options for `synth create agent`:** anthropic, openai, llama, gemini, agentcore. Each generates the correct model string, pip extra, env var setup, and (for AgentCore) deployment scaffolding.

**`synth create agentcore`** is the recommended way to start an AgentCore project. It creates:
- Agent file with `agentcore_handler` wrapper
- `requirements.txt` with all dependencies
- `agentcore.yaml` with deployment configuration (IAM permissions, runtime settings, environment variables)
- Comprehensive README with local development and deployment instructions

The `agentcore.yaml` file lets you configure:
- Agent name and description
- IAM permissions (least-privilege)
- Runtime settings (memory, timeout)
- Environment variables

**`synth create mcp`** generates a FastMCP server with sample tools and resources, plus the config snippet to register it in your IDE.

**`synth create ui`** generates a local testing UI with a FastAPI bridge server and a terminal-inspired browser interface — chat with your agent, inspect tool calls, and see token/cost/latency metrics in real time.

### `synth run` — Run an Agent

Execute an agent from a Python file with a prompt and print the result.

```bash
synth run my_agent.py "What is the meaning of life?"
```

This loads the agent defined in `my_agent.py`, runs it with the given prompt, and prints the `RunResult` text to stdout. A trace summary (tokens, cost, latency) is printed to stderr so you can pipe the output.

### `synth dev` — Rich Terminal UI

Start an interactive development environment for chatting with your agent.

```bash
synth dev my_agent.py
```

This launches a Fallout-inspired terminal interface with:

- **Streaming responses** — tokens render in real time as the model generates them, with green text typing out like a terminal.
- **Tool call visualization** — each tool call shows the tool name, arguments, result, and latency inline.
- **Slash commands** — type `/help` to see all commands:
  - `/tools` — list registered tools with descriptions and parameters
  - `/reload` — hot-reload the agent from disk without restarting
  - `/trace` — show the last run's trace summary
  - `/export` — export the last trace to JSON
  - `/clear` — clear the conversation
  - `/model` — show current model info
  - `/cost` — show cumulative session cost
  - `/quit` — exit dev mode
- **Markdown rendering** — agent responses are rendered as formatted markdown.
- **Status bar** — persistent bar at the bottom showing model, turn count, total tokens, cumulative cost, and last response latency.
- **Multi-line input** — end a line with `\` to continue on the next line.
- **Command history** — use up/down arrows to recall previous prompts.

### `synth bench` — Benchmark Performance

Run your agent multiple times and get latency/cost statistics.

```bash
synth bench my_agent.py "Hello" --runs 20 --warmup 2
```

This runs the agent 20 times (after 2 warmup runs that aren't counted) and reports:
- **Latency percentiles:** p50, p95, p99, average, min, max
- **Token usage:** average per run, total
- **Cost:** per run, total
- **Reliability:** success rate, error count

Useful for comparing models, measuring the impact of tool changes, or establishing performance baselines before deployment.

### `synth eval` — Run Evaluations

Run an evaluation suite against your agent and print a pass/fail report.

```bash
synth eval my_agent.py --dataset test_cases.json
```

The dataset is a JSON file with test cases. The command prints a table of results and an overall score. It exits with code 0 if the pass rate meets the threshold, or code 1 if it doesn't — making it suitable for CI/CD pipelines.

### `synth trace` — View a Trace

Open a stored trace in the browser trace viewer.

```bash
synth trace <run_id>
```

This looks up the trace for the given run ID and opens it in your default browser.

### `synth deploy` — Deploy to AWS AgentCore

Package and deploy your agent to AWS AgentCore.

```bash
# Deploy to AgentCore
synth deploy --target agentcore my_agent.py

# Validate without actually deploying
synth deploy --target agentcore --dry-run my_agent.py
```

The `--dry-run` flag checks your configuration, IAM permissions, and packaging without deploying. Requires `pip install synth-agent-sdk[agentcore]`.

### `synth doctor` — Diagnose Your Setup

Check your environment for common issues.

```bash
synth doctor
```

This checks:
- Python version (3.10+ required)
- Core dependencies are installed and version-compatible
- Provider API keys are set (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, etc.)
- `SYNTH_TRACE_ENDPOINT` URL format (if set)
- Which optional provider packages are installed

Each check shows `[  OK  ]` or `[FAIL]` with a fix instruction if something is wrong.

If providers are missing, `synth doctor` suggests the exact install commands:

```
Missing provider packages:
  Install all: pip install synth-agent-sdk[all]
  Or individually: pip install synth[anthropic] synth[openai]
```

### `synth info` — View Package Information

Show what's included in each installation option.

```bash
synth info --extra anthropic
synth info --extra quickstart
synth info --extra all
```

This displays:
- Provider name
- Dependencies being installed
- Available models
- Core SDK packages

Useful for understanding what you're installing before running `pip install`.

### `synth help` — Quick Reference

Show a curated getting-started guide with common workflows, provider table, and environment variable reference.

```bash
synth help
```

This is a quick-reference card you can pull up anytime — no need to leave the terminal to check docs.

---

## Deploying to AWS AgentCore

AWS AgentCore is a managed service for running AI agents in production at scale. Synth provides built-in support for packaging and deploying agents to AgentCore.

### Prerequisites

```bash
pip install synth-agent-sdk[agentcore]
```

This installs both `boto3` (for AWS) and `bedrock-agentcore` (the AgentCore runtime SDK).

You also need AWS credentials configured (via IAM role, environment variables, or AWS config).

### Wrapping Your Agent for AgentCore

Use the `agentcore_handler()` function to make your agent compatible with AgentCore's runtime. This creates a `BedrockAgentCoreApp` instance following the AgentCore deployment pattern:

```python
from synth import Agent
from synth.deploy.agentcore import agentcore_handler

agent = Agent(
    model="bedrock/claude-sonnet-4-5",  # Bedrock is natural for AgentCore (uses IAM credentials)
    instructions="You are a customer support agent.",
    tools=[lookup_order, check_inventory],
)

# Creates a BedrockAgentCoreApp instance with the agent registered as an entrypoint
app = agentcore_handler(agent)
```

This wraps your agent so that:
- AgentCore invocation payloads are translated into Synth's `run()` format.
- `RunResult` is translated back into AgentCore's response format.
- Runtime-provided IAM credentials are used automatically (no static keys needed).
- Traces are forwarded to AgentCore's observability infrastructure.

### Local Development with AgentCore CLI

Before deploying, test your agent locally using the AgentCore CLI:

```bash
# Start local development server
agentcore dev

# In another terminal, test your agent
agentcore invoke --dev '{"prompt": "Hello"}'
```

The dev server watches for file changes and automatically reloads your agent.

### Deploying

```bash
# Validate your setup first
synth deploy --target agentcore --dry-run

# Deploy for real
synth deploy --target agentcore
```

The deployer:
1. Discovers your agent entry point.
2. Packages your code and dependencies into a deployment artifact.
3. Generates an agent manifest (name, description, actions, IAM permissions).
4. Deploys to AgentCore.

The packager automatically excludes `.env` files, credential files, and `.synth/checkpoints/` directories from the deployment artifact.

### AgentCore Memory

When running in AgentCore, memory operations are automatically routed to AgentCore's managed memory service. If it's unavailable, the agent falls back to whatever Synth-native memory backend you configured.

### AgentCore Checkpointing

For graph-based agents with checkpointing, AgentCore's managed state persistence is used instead of local disk or self-managed Redis.

---

## Error Handling

Synth provides clear, actionable error messages. Every error tells you what went wrong, which component raised it, and how to fix it.

### Error Types

All Synth errors inherit from `SynthError`. Here are the specific types you might encounter:

| Error | When It Happens |
|-------|----------------|
| `SynthConfigError` | Missing API key, invalid model string, missing provider package. |
| `ToolDefinitionError` | A `@tool` function is missing type annotations or a docstring. Raised at decoration time. |
| `ToolExecutionError` | A tool function raised an exception during execution. Includes the tool name, arguments, and original error. |
| `GuardViolationError` | A guard check failed. Includes the guard name, violating content, and suggested fix. |
| `CostLimitError` | A cost guard limit was exceeded. A subclass of `GuardViolationError`. |
| `SynthParseError` | Structured output couldn't be parsed after all retries. |
| `GraphRoutingError` | No outbound edge condition matched at a graph node. Includes the node name and current state. |
| `GraphLoopError` | A graph exceeded its `max_iterations` limit. Includes the full node visit history. |
| `RunNotFoundError` | No checkpoint found for the given `run_id`. |
| `PipelineError` | A pipeline stage failed. Includes the failed step index, agent name, and partial results from prior stages. |

### Catching Errors

```python
from synth.errors import SynthConfigError, ToolExecutionError, GuardViolationError

try:
    result = agent.run("Do something risky.")
except GuardViolationError as e:
    print(f"Guard '{e.guard_name}' blocked the response: {e.remediation}")
except ToolExecutionError as e:
    print(f"Tool '{e.tool_name}' failed with args {e.tool_args}: {e.original_error}")
except SynthConfigError as e:
    print(f"Configuration issue in {e.component}: {e.suggestion}")
```

Every error has:
- A human-readable message (the string representation)
- `component` — which part of Synth raised it
- `suggestion` — how to fix it

---

## Environment Variables Reference

| Variable | Purpose | Required? |
|----------|---------|-----------|
| `ANTHROPIC_API_KEY` | API key for Anthropic Claude models. | Only if using `claude-*` models. |
| `OPENAI_API_KEY` | API key for OpenAI GPT models. | Only if using `gpt-*` models. |
| `GOOGLE_API_KEY` | API key for Google Gemini models. | Only if using `gemini-*` models. |
| `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` | AWS credentials for Bedrock. | Only if using `bedrock/*` models (or use IAM roles). |
| `SYNTH_TRACE_ENDPOINT` | HTTPS URL of an OpenTelemetry collector. Traces are auto-forwarded here. | No. |
| `SYNTH_NO_BANNER` | Set to `1` to skip the terminal boot sequence. | No. |
| `NO_COLOR` | Set to any value to disable colored terminal output (standard convention). | No. |

---

## Frequently Asked Questions

### Do I need an API key to use Synth?

Yes, for cloud-hosted models. Each provider requires its own API key set as an environment variable. The exception is Ollama, which runs models locally on your machine and needs no API key.

### Can I use Synth in a Jupyter notebook?

Yes. Synth detects when an event loop is already running (as in Jupyter) and handles it automatically. Both `agent.run()` and `await agent.arun()` work in notebooks.

### How do I switch between models?

Just change the `model` string. For example, change `"claude-sonnet-4-5"` to `"gpt-4o"`. Make sure you have the right provider extra installed and the API key set.

### What happens if the AI provider is down?

Synth automatically retries on HTTP 429 (rate limit) and 5xx (server error) responses with exponential backoff. You can configure `max_retries` and `retry_backoff` on the Agent.

### Can I use multiple models in the same application?

Yes. Each Agent has its own model. You can create agents with different models and use them in pipelines, graphs, or teams.

```python
fast_agent = Agent(model="claude-haiku-3-5", instructions="Quick answers only.")
smart_agent = Agent(model="claude-sonnet-4-5", instructions="Detailed analysis.")
```

### How do I debug what my agent is doing?

Every `RunResult` includes a `trace` with detailed information about every step. Use `result.trace.show()` to open a visual timeline in your browser, or inspect `result.trace.spans` programmatically. You can also use `synth dev my_agent.py` for an interactive terminal UI with built-in trace inspection via the `/trace` command.

### How do I start a new project quickly?

Run `synth init` for an interactive setup that walks you through provider selection and feature toggles, or `synth create agent my-bot` for quick scaffolding with provider selection. Both generate a ready-to-run project.

### How do I benchmark my agent's performance?

Use `synth bench my_agent.py "test prompt" --runs 20` to run your agent multiple times and get p50/p95/p99 latency, token usage, and cost statistics.

### Is my data secure?

Synth never logs, traces, or serializes API keys or credentials. Guard implementations run before any side-effecting operation. Checkpoint data uses JSON only (never pickle). All provider calls use HTTPS by default.

### What Python version do I need?

Python 3.10 or newer.

### What are the core dependencies?

Synth keeps its core dependencies minimal:
- `pydantic` — data validation and structured output
- `httpx` — HTTP client
- `click` — CLI framework
- `typing-extensions` — backported typing features
- `rich` — terminal rendering and markdown
- `prompt-toolkit` — interactive input with history and autocomplete

Provider SDKs (anthropic, openai, boto3, etc.) are optional extras installed only when needed.
