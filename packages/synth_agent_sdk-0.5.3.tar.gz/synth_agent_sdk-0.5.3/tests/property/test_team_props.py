"""Property-based tests for AgentTeam orchestration.

**Property 22: Parallel team executes all agents**
**Validates: Requirements 9.3**

**Property 23: TeamResult contains all contributions**
**Validates: Requirements 9.6**
"""

from __future__ import annotations

import asyncio
from unittest.mock import patch

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.agent import Agent
from synth.orchestration.team import AgentTeam
from synth.providers.base import ProviderResponse
from synth.types import TokenUsage
from tests.conftest import MockProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_USAGE = TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15)


def _make_agent(text: str, name: str) -> Agent:
    """Create an Agent backed by a MockProvider returning *text*."""
    provider = MockProvider(
        responses=[ProviderResponse(text=text, usage=_USAGE)],
    )
    with patch("synth.agent.ProviderRouter.resolve", return_value=provider):
        return Agent(instructions=name)


# ---------------------------------------------------------------------------
# Property 22: Parallel team executes all agents
# ---------------------------------------------------------------------------


@settings(max_examples=50)
@given(
    n_agents=st.integers(min_value=1, max_value=5),
)
def test_parallel_team_executes_all_agents(n_agents: int):
    """Property 22: Parallel team executes all agents.

    For any AgentTeam with strategy="parallel" and N agents, calling
    team.run(task) should invoke all N agents and aggregate all N results.

    **Validates: Requirements 9.3**
    """
    agents = [
        _make_agent(f"result_{i}", f"agent_{i}")
        for i in range(n_agents)
    ]
    team = AgentTeam(
        orchestrator="claude-sonnet-4-5",
        agents=agents,
        strategy="parallel",
    )

    result = asyncio.run(team.arun("test task"))

    assert len(result.contributions) == n_agents
    for i, contrib in enumerate(result.contributions):
        assert contrib.result.text == f"result_{i}"


# ---------------------------------------------------------------------------
# Property 23: TeamResult contains all contributions
# ---------------------------------------------------------------------------


@settings(max_examples=50)
@given(
    n_agents=st.integers(min_value=1, max_value=5),
    task_text=st.text(min_size=1, max_size=30),
)
def test_team_result_contains_all_contributions(
    n_agents: int, task_text: str,
):
    """Property 23: TeamResult contains all contributions.

    For any completed AgentTeam run, the TeamResult should contain one
    AgentContribution for each agent that participated, a non-empty
    message trace, and a synthesised answer.

    **Validates: Requirements 9.6**
    """
    agents = [
        _make_agent(f"output_{i}", f"agent_{i}")
        for i in range(n_agents)
    ]
    team = AgentTeam(
        orchestrator="claude-sonnet-4-5",
        agents=agents,
        strategy="parallel",
    )

    result = asyncio.run(team.arun(task_text))

    # One contribution per agent
    assert len(result.contributions) == n_agents

    # Each contribution has an agent name and result
    for contrib in result.contributions:
        assert contrib.agent_name != ""
        assert contrib.result.text != ""

    # Non-empty message trace
    assert len(result.message_trace) > 0

    # Synthesised answer is non-empty
    assert result.answer != ""

    # Latency is positive
    assert result.total_latency_ms > 0
