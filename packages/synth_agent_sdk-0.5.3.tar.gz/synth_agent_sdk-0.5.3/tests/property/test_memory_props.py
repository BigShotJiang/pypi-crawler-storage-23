# Feature: synth-agent-sdk, Property 11 & 12: Memory property tests
"""Property-based tests for the memory system.

**Property 11: Thread memory round-trip**
**Validates: Requirements 5.1, 5.2**

For any sequence of messages added to a thread via ``Memory.thread()``,
retrieving messages for that ``thread_id`` should return all messages in
the order they were added.

**Property 12: Memory truncation on context limit**
**Validates: Requirements 5.6**

For any thread whose total token count exceeds the model's context limit,
the Memory should truncate or summarise older messages such that the
resulting token count fits within the limit, and a
``ContextTruncationWarning`` should be emitted.
"""

from __future__ import annotations

import asyncio
import warnings

from hypothesis import given, settings, assume
from hypothesis import strategies as st

from synth.memory.thread import ThreadMemory, ContextTruncationWarning
from synth.types import Message


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

_ROLES = st.sampled_from(["user", "assistant", "system"])

_CONTENT = st.text(
    alphabet=st.characters(
        whitelist_categories=("L", "N", "Z"),
        whitelist_characters=" .,!?-",
    ),
    min_size=1,
    max_size=200,
)

_message_strategy = st.builds(
    lambda role, content: Message(role=role, content=content),
    role=_ROLES,
    content=_CONTENT,
)

_message_list_strategy = st.lists(_message_strategy, min_size=1, max_size=20)

_thread_id_strategy = st.from_regex(r"[a-z][a-z0-9_]{0,15}", fullmatch=True)


# ---------------------------------------------------------------------------
# Property 11: Thread memory round-trip
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    messages=_message_list_strategy,
    thread_id=_thread_id_strategy,
)
def test_thread_memory_round_trip(messages: list[Message], thread_id: str) -> None:
    """Property 11: For any sequence of messages added to a thread,
    retrieving messages for that thread_id returns all messages in the
    order they were added.

    **Validates: Requirements 5.1, 5.2**
    """
    # Use a large max_tokens so truncation doesn't interfere
    mem = ThreadMemory(max_tokens=1_000_000)

    async def _run() -> list[Message]:
        await mem.add_messages(thread_id, messages)
        return await mem.get_messages(thread_id)

    retrieved = asyncio.run(_run())

    assert len(retrieved) == len(messages)
    for original, stored in zip(messages, retrieved):
        assert stored["role"] == original["role"]
        assert stored["content"] == original["content"]


@settings(max_examples=100)
@given(
    batch_a=_message_list_strategy,
    batch_b=_message_list_strategy,
    thread_id=_thread_id_strategy,
)
def test_thread_memory_round_trip_multiple_adds(
    batch_a: list[Message],
    batch_b: list[Message],
    thread_id: str,
) -> None:
    """Property 11 (multi-add): Adding messages across separate calls
    preserves the full sequence in insertion order.

    **Validates: Requirements 5.1, 5.2**
    """
    mem = ThreadMemory(max_tokens=1_000_000)

    async def _run() -> list[Message]:
        await mem.add_messages(thread_id, batch_a)
        await mem.add_messages(thread_id, batch_b)
        return await mem.get_messages(thread_id)

    retrieved = asyncio.run(_run())
    expected = batch_a + batch_b

    assert len(retrieved) == len(expected)
    for original, stored in zip(expected, retrieved):
        assert stored["role"] == original["role"]
        assert stored["content"] == original["content"]


# ---------------------------------------------------------------------------
# Property 12: Memory truncation on context limit
# ---------------------------------------------------------------------------

# Content long enough that a few messages will exceed a small token limit.
# Token estimation is len(content) // 4, so 40 chars ≈ 10 tokens.
_long_content = st.text(
    alphabet=st.characters(
        whitelist_categories=("L", "N"),
        whitelist_characters=" ",
    ),
    min_size=40,
    max_size=200,
)

_long_message_strategy = st.builds(
    lambda role, content: Message(role=role, content=content),
    role=_ROLES,
    content=_long_content,
)

_long_message_list_strategy = st.lists(
    _long_message_strategy, min_size=2, max_size=15,
)


@settings(max_examples=100)
@given(
    messages=_long_message_list_strategy,
    max_tokens=st.integers(min_value=5, max_value=50),
)
def test_memory_truncation_on_context_limit(
    messages: list[Message],
    max_tokens: int,
) -> None:
    """Property 12: For any thread whose total token count exceeds the
    model's context limit, the Memory truncates older messages so the
    resulting token count fits within the limit (or only 1 message
    remains), and a ContextTruncationWarning is emitted.

    **Validates: Requirements 5.6**
    """
    mem = ThreadMemory(max_tokens=max_tokens)

    total_tokens = sum(len(m["content"]) // 4 for m in messages)
    assume(total_tokens > max_tokens)

    async def _run() -> list[Message]:
        await mem.add_messages("t1", messages)
        return await mem.get_messages("t1")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        retrieved = asyncio.run(_run())

    # Token count of remaining messages fits within the limit,
    # OR only a single message remains (which may itself exceed the limit).
    remaining_tokens = sum(len(m["content"]) // 4 for m in retrieved)
    assert remaining_tokens <= max_tokens or len(retrieved) == 1

    # At least one message must survive truncation
    assert len(retrieved) >= 1

    # A ContextTruncationWarning must have been emitted
    truncation_warnings = [
        w for w in caught if issubclass(w.category, ContextTruncationWarning)
    ]
    assert len(truncation_warnings) >= 1, (
        "Expected ContextTruncationWarning but none was emitted"
    )
