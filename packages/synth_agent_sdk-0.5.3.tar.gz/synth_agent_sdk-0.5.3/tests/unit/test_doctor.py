"""Tests for ``synth.cli.doctor`` — environment and dependency checks."""

from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock, patch

import click
import pytest


# ===================================================================
# run_doctor — main function
# ===================================================================


class TestRunDoctor:
    """Tests for the ``run_doctor`` function."""

    def test_all_checks_pass_with_full_environment(self, capsys):
        """All checks pass when Python 3.10+, core deps, and providers are available."""
        env = {
            "ANTHROPIC_API_KEY": "sk-ant-test",
            "OPENAI_API_KEY": "sk-test",
            "GOOGLE_API_KEY": "test-key",
            "SYNTH_TRACE_ENDPOINT": "https://trace.example.com",
            "AWS_ACCESS_KEY_ID": "AKIATEST",
        }
        
        with patch.dict("os.environ", env, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            # Mock all imports to succeed
            mock_import.return_value = MagicMock(__version__="1.0.0")
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "All checks passed" in captured.out
            assert "[  OK  ]" in captured.out
            assert "[FAIL]" not in captured.out

    def test_python_version_check_passes_on_3_10_plus(self, capsys):
        """Python version check passes on 3.10+."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            mock_import.return_value = MagicMock(__version__="1.0.0")
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            v = sys.version_info
            assert f"Python {v.major}.{v.minor}.{v.micro}" in captured.out
            assert "[  OK  ]" in captured.out

    def test_python_version_check_fails_on_old_version(self, capsys):
        """Python version check fails and increments issue count on Python < 3.10."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("sys.version_info", (3, 9, 0)), \
             patch("synth.cli.doctor.__import__") as mock_import:
            mock_import.return_value = MagicMock(__version__="1.0.0")
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "Python 3.9 — requires 3.10+" in captured.out
            assert "[FAIL]" in captured.out
            assert "issue(s) found" in captured.out

    def test_core_dependencies_check_all_installed(self, capsys):
        """Core dependencies check passes when pydantic, httpx, click are installed."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            def mock_import_fn(name):
                if name in ("pydantic", "httpx", "click"):
                    m = MagicMock()
                    m.__version__ = "2.0.0" if name == "pydantic" else "0.27.0"
                    return m
                raise ImportError(f"No module named '{name}'")
            
            mock_import.side_effect = mock_import_fn
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "pydantic 2.0.0" in captured.out or "pydantic" in captured.out
            assert "httpx" in captured.out
            assert "click" in captured.out

    def test_core_dependency_missing_increments_issues(self, capsys):
        """Missing core dependency increments issue count and shows install command."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            def mock_import_fn(name):
                if name == "pydantic":
                    raise ImportError("No module named 'pydantic'")
                m = MagicMock()
                m.__version__ = "1.0.0"
                return m
            
            mock_import.side_effect = mock_import_fn
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "pydantic not installed" in captured.out
            assert "pip install synth-agent-sdk" in captured.out
            assert "[FAIL]" in captured.out
            assert "issue(s) found" in captured.out

    def test_provider_env_vars_show_ok_when_set(self, capsys):
        """Provider env vars show OK status when set."""
        env = {
            "ANTHROPIC_API_KEY": "sk-ant-test",
            "OPENAI_API_KEY": "sk-test",
            "GOOGLE_API_KEY": "test-key",
        }
        
        with patch.dict("os.environ", env, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            mock_import.return_value = MagicMock(__version__="1.0.0")
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "Anthropic (ANTHROPIC_API_KEY set)" in captured.out
            assert "OpenAI (OPENAI_API_KEY set)" in captured.out
            assert "Google (GOOGLE_API_KEY set)" in captured.out

    def test_provider_env_vars_show_info_when_not_set(self, capsys):
        """Provider env vars show INFO status when not set."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            mock_import.return_value = MagicMock(__version__="1.0.0")
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "Anthropic (ANTHROPIC_API_KEY not set)" in captured.out
            assert "OpenAI (OPENAI_API_KEY not set)" in captured.out
            assert "Google (GOOGLE_API_KEY not set)" in captured.out
            assert "[INFO]" in captured.out

    def test_trace_endpoint_https_passes(self, capsys):
        """SYNTH_TRACE_ENDPOINT with HTTPS passes validation."""
        env = {"SYNTH_TRACE_ENDPOINT": "https://trace.example.com/api"}
        
        with patch.dict("os.environ", env, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            mock_import.return_value = MagicMock(__version__="1.0.0")
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "SYNTH_TRACE_ENDPOINT: https://trace.example.com" in captured.out
            assert "[  OK  ]" in captured.out

    def test_trace_endpoint_http_fails(self, capsys):
        """SYNTH_TRACE_ENDPOINT with HTTP fails validation and increments issues."""
        env = {"SYNTH_TRACE_ENDPOINT": "http://trace.example.com"}
        
        with patch.dict("os.environ", env, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            mock_import.return_value = MagicMock(__version__="1.0.0")
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "SYNTH_TRACE_ENDPOINT should use HTTPS" in captured.out
            assert "[FAIL]" in captured.out
            assert "issue(s) found" in captured.out

    def test_trace_endpoint_not_set_shows_info(self, capsys):
        """SYNTH_TRACE_ENDPOINT not set shows info message."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            mock_import.return_value = MagicMock(__version__="1.0.0")
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "SYNTH_TRACE_ENDPOINT not set (traces local only)" in captured.out
            assert "[INFO]" in captured.out

    def test_optional_packages_installed_show_ok(self, capsys):
        """Optional provider packages show OK when installed."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            def mock_import_fn(name):
                # All packages installed
                m = MagicMock()
                m.__version__ = "1.0.0"
                return m
            
            mock_import.side_effect = mock_import_fn
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "synth[anthropic] installed" in captured.out
            assert "synth[openai] installed" in captured.out
            assert "synth[google] installed" in captured.out
            assert "synth[bedrock] installed" in captured.out

    def test_optional_packages_missing_show_info_and_suggestions(self, capsys):
        """Missing optional packages show INFO and helpful install suggestions."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            def mock_import_fn(name):
                # Core packages installed, optional packages missing
                if name in ("pydantic", "httpx", "click"):
                    m = MagicMock()
                    m.__version__ = "1.0.0"
                    return m
                raise ImportError(f"No module named '{name}'")
            
            mock_import.side_effect = mock_import_fn
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "synth[anthropic] not installed" in captured.out
            assert "synth[openai] not installed" in captured.out
            assert "synth[google] not installed" in captured.out
            assert "synth[bedrock] not installed" in captured.out
            assert "Missing provider packages:" in captured.out
            assert "Install all: pip install synth-agent-sdk[all]" in captured.out
            assert "Or individually: pip install" in captured.out
            assert "synth[anthropic]" in captured.out

    def test_aws_credentials_from_env_vars(self, capsys):
        """AWS credentials detected from environment variables."""
        env = {"AWS_ACCESS_KEY_ID": "AKIATEST"}
        
        with patch.dict("os.environ", env, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            mock_import.return_value = MagicMock(__version__="1.0.0")
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "AWS credentials found (env vars)" in captured.out
            assert "[  OK  ]" in captured.out

    def test_aws_credentials_from_file(self, capsys):
        """AWS credentials detected from ~/.aws/credentials file."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import, \
             patch("os.path.exists") as mock_exists:
            mock_import.return_value = MagicMock(__version__="1.0.0")
            mock_exists.return_value = True
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "AWS credentials found (~/.aws/credentials)" in captured.out
            assert "[  OK  ]" in captured.out

    def test_aws_credentials_not_configured_shows_info(self, capsys):
        """AWS credentials not configured shows info with setup instructions."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import, \
             patch("os.path.exists") as mock_exists:
            mock_import.return_value = MagicMock(__version__="1.0.0")
            mock_exists.return_value = False
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "AWS credentials not configured" in captured.out
            assert "pip install awscli && aws configure" in captured.out
            assert "[INFO]" in captured.out

    def test_missing_providers_list_populated_correctly(self, capsys):
        """Missing providers list is populated and displayed correctly."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            def mock_import_fn(name):
                # Only anthropic and openai missing
                if name in ("anthropic", "openai"):
                    raise ImportError(f"No module named '{name}'")
                m = MagicMock()
                m.__version__ = "1.0.0"
                return m
            
            mock_import.side_effect = mock_import_fn
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "Missing provider packages:" in captured.out
            assert "synth[anthropic]" in captured.out
            assert "synth[openai]" in captured.out
            # Should not show google or bedrock since they're "installed"
            assert captured.out.count("synth[google]") == 1  # Only in the not installed line
            assert captured.out.count("synth[bedrock]") == 1

    def test_no_missing_providers_no_suggestions_shown(self, capsys):
        """When all providers are installed, no missing provider suggestions shown."""
        with patch.dict("os.environ", {}, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            # All packages installed
            mock_import.return_value = MagicMock(__version__="1.0.0")
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "Missing provider packages:" not in captured.out
            assert "Install all: pip install synth-agent-sdk[all]" not in captured.out


# ===================================================================
# Helper functions
# ===================================================================


class TestHelperFunctions:
    """Tests for the helper output functions."""

    def test_ok_prints_green_status(self, capsys):
        """_ok prints a green OK status line."""
        from synth.cli.doctor import _ok
        
        _ok("Test message")
        captured = capsys.readouterr()
        assert "[  OK  ]" in captured.out
        assert "Test message" in captured.out

    def test_fail_prints_red_status(self, capsys):
        """_fail prints a red FAIL status line."""
        from synth.cli.doctor import _fail
        
        _fail("Test error")
        captured = capsys.readouterr()
        assert "[FAIL]" in captured.out
        assert "Test error" in captured.out

    def test_info_prints_yellow_status(self, capsys):
        """_info prints a yellow INFO status line."""
        from synth.cli.doctor import _info
        
        _info("Test info")
        captured = capsys.readouterr()
        assert "[INFO]" in captured.out
        assert "Test info" in captured.out


# ===================================================================
# Integration tests
# ===================================================================


class TestDoctorIntegration:
    """Integration tests for the doctor command."""

    def test_multiple_issues_counted_correctly(self, capsys):
        """Multiple issues are counted and reported correctly."""
        env = {"SYNTH_TRACE_ENDPOINT": "http://insecure.example.com"}
        
        with patch.dict("os.environ", env, clear=True), \
             patch("sys.version_info", (3, 9, 0)), \
             patch("synth.cli.doctor.__import__") as mock_import:
            def mock_import_fn(name):
                if name == "pydantic":
                    raise ImportError("No module named 'pydantic'")
                m = MagicMock()
                m.__version__ = "1.0.0"
                return m
            
            mock_import.side_effect = mock_import_fn
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            # Should have 3 issues: Python version, pydantic missing, HTTP endpoint
            assert "3 issue(s) found" in captured.out

    def test_zero_issues_shows_success_message(self, capsys):
        """Zero issues shows success message in green."""
        env = {
            "ANTHROPIC_API_KEY": "sk-ant-test",
            "SYNTH_TRACE_ENDPOINT": "https://trace.example.com",
        }
        
        with patch.dict("os.environ", env, clear=True), \
             patch("synth.cli.doctor.__import__") as mock_import:
            mock_import.return_value = MagicMock(__version__="1.0.0")
            
            from synth.cli.doctor import run_doctor
            run_doctor()
            
            captured = capsys.readouterr()
            assert "All checks passed" in captured.out
            assert "issue(s) found" not in captured.out
