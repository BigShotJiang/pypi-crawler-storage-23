"""Unit tests for the @tool decorator and JSON schema generation."""

from __future__ import annotations

from typing import Optional

import pytest

from synth.errors import ToolDefinitionError
from synth.tools.decorator import tool


# ---------------------------------------------------------------------------
# Valid function — basic schema generation
# ---------------------------------------------------------------------------


def test_valid_function_produces_schema():
    """Decorating a valid function stores a _tool_schema attribute."""

    @tool
    def greet(name: str, times: int) -> str:
        """Greet someone multiple times."""
        return name * times

    assert hasattr(greet, "_tool_schema")
    schema = greet._tool_schema
    assert schema["name"] == "greet"
    assert schema["description"] == "Greet someone multiple times."
    assert schema["parameters"]["type"] == "object"
    assert "name" in schema["parameters"]["properties"]
    assert "times" in schema["parameters"]["properties"]


def test_schema_has_correct_name():
    @tool
    def my_tool(x: str) -> str:
        """Does something."""
        return x

    assert my_tool._tool_schema["name"] == "my_tool"


def test_schema_has_correct_description():
    @tool
    def lookup(query: str) -> str:
        """Search the knowledge base."""
        return query

    assert my_tool_schema_desc(lookup) == "Search the knowledge base."


def my_tool_schema_desc(fn):
    return fn._tool_schema["description"]


# ---------------------------------------------------------------------------
# Parameter type mapping
# ---------------------------------------------------------------------------


def test_str_maps_to_string():
    @tool
    def fn(x: str) -> str:
        """Doc."""
        return x

    assert fn._tool_schema["parameters"]["properties"]["x"]["type"] == "string"


def test_int_maps_to_integer():
    @tool
    def fn(x: int) -> int:
        """Doc."""
        return x

    assert fn._tool_schema["parameters"]["properties"]["x"]["type"] == "integer"


def test_float_maps_to_number():
    @tool
    def fn(x: float) -> float:
        """Doc."""
        return x

    assert fn._tool_schema["parameters"]["properties"]["x"]["type"] == "number"


def test_bool_maps_to_boolean():
    @tool
    def fn(x: bool) -> bool:
        """Doc."""
        return x

    assert fn._tool_schema["parameters"]["properties"]["x"]["type"] == "boolean"


def test_list_maps_to_array():
    @tool
    def fn(x: list) -> list:
        """Doc."""
        return x

    assert fn._tool_schema["parameters"]["properties"]["x"]["type"] == "array"


def test_dict_maps_to_object():
    @tool
    def fn(x: dict) -> dict:
        """Doc."""
        return x

    assert fn._tool_schema["parameters"]["properties"]["x"]["type"] == "object"


# ---------------------------------------------------------------------------
# Optional parameters
# ---------------------------------------------------------------------------


def test_optional_param_not_in_required():
    @tool
    def fn(name: str, age: Optional[int] = None) -> str:
        """Doc."""
        return name

    schema = fn._tool_schema
    assert "name" in schema["parameters"]["required"]
    assert "age" not in schema["parameters"]["required"]


def test_optional_param_has_inner_type():
    @tool
    def fn(age: Optional[int] = None) -> str:
        """Doc."""
        return ""

    assert fn._tool_schema["parameters"]["properties"]["age"]["type"] == "integer"


def test_param_with_default_not_required():
    @tool
    def fn(name: str, greeting: str = "hello") -> str:
        """Doc."""
        return f"{greeting} {name}"

    schema = fn._tool_schema
    assert "name" in schema["parameters"]["required"]
    assert "greeting" not in schema["parameters"]["required"]


# ---------------------------------------------------------------------------
# Validation errors
# ---------------------------------------------------------------------------


def test_missing_annotation_raises_tool_definition_error():
    with pytest.raises(ToolDefinitionError, match="missing a type annotation"):

        @tool
        def fn(x):
            """Doc."""
            return x


def test_missing_docstring_raises_tool_definition_error():
    with pytest.raises(ToolDefinitionError, match="missing a docstring"):

        @tool
        def fn(x: str) -> str:
            pass


def test_empty_docstring_raises_tool_definition_error():
    with pytest.raises(ToolDefinitionError, match="missing a docstring"):

        @tool
        def fn(x: str) -> str:
            """   """
            pass


def test_error_includes_component_and_suggestion():
    with pytest.raises(ToolDefinitionError) as exc_info:

        @tool
        def fn(x):
            """Doc."""
            return x

    err = exc_info.value
    assert err.component == "@tool"
    assert err.suggestion  # non-empty


# ---------------------------------------------------------------------------
# Multiple parameters
# ---------------------------------------------------------------------------


def test_multiple_params_all_in_schema():
    @tool
    def search(query: str, limit: int, verbose: bool) -> list:
        """Search for items."""
        return []

    props = search._tool_schema["parameters"]["properties"]
    assert set(props.keys()) == {"query", "limit", "verbose"}
    assert props["query"]["type"] == "string"
    assert props["limit"]["type"] == "integer"
    assert props["verbose"]["type"] == "boolean"


def test_all_required_when_no_defaults():
    @tool
    def fn(a: str, b: int, c: float) -> str:
        """Doc."""
        return ""

    assert fn._tool_schema["parameters"]["required"] == ["a", "b", "c"]


# ---------------------------------------------------------------------------
# Decorated function remains callable
# ---------------------------------------------------------------------------


def test_decorated_function_is_still_callable():
    @tool
    def add(a: int, b: int) -> int:
        """Add two numbers."""
        return a + b

    assert add(2, 3) == 5


# ---------------------------------------------------------------------------
# ToolKit tests
# ---------------------------------------------------------------------------

from synth.tools.toolkit import ToolKit


def _make_tools():
    """Helper: create a couple of @tool-decorated functions."""

    @tool
    def add(a: int, b: int) -> int:
        """Add two numbers."""
        return a + b

    @tool
    def greet(name: str) -> str:
        """Say hello."""
        return f"hi {name}"

    return add, greet


def test_toolkit_creation():
    """ToolKit can be created with a list of @tool functions."""
    add, greet = _make_tools()
    tk = ToolKit([add, greet])
    assert tk is not None


def test_toolkit_get_schemas_returns_all():
    """get_schemas() returns a schema dict for every tool."""
    add, greet = _make_tools()
    tk = ToolKit([add, greet])
    schemas = tk.get_schemas()
    assert len(schemas) == 2
    names = {s["name"] for s in schemas}
    assert names == {"add", "greet"}


def test_toolkit_get_tools_returns_dict():
    """get_tools() returns a dict mapping name → function."""
    add, greet = _make_tools()
    tk = ToolKit([add, greet])
    tools = tk.get_tools()
    assert isinstance(tools, dict)
    assert set(tools.keys()) == {"add", "greet"}
    assert tools["add"] is add
    assert tools["greet"] is greet


def test_toolkit_empty():
    """An empty ToolKit works without errors."""
    tk = ToolKit([])
    assert tk.get_schemas() == []
    assert tk.get_tools() == {}


# ---------------------------------------------------------------------------
# ToolExecutor tests
# ---------------------------------------------------------------------------

import asyncio
import warnings

from synth.errors import ToolExecutionError
from synth.tools.executor import ToolExecutor, TypeMismatchWarning


def _make_executor_tools():
    """Helper: create tools and a ToolExecutor."""

    @tool
    def add(a: int, b: int) -> int:
        """Add two numbers."""
        return a + b

    @tool
    def greet(name: str) -> str:
        """Say hello."""
        return f"hi {name}"

    tools = {"add": add, "greet": greet}
    return ToolExecutor(tools), tools


# --- Basic execution -------------------------------------------------------


@pytest.mark.asyncio
async def test_executor_calls_sync_tool():
    """ToolExecutor can execute a sync tool by name and return its result."""
    executor, _ = _make_executor_tools()
    result = await executor.execute("add", {"a": 2, "b": 3})
    assert result == 5


@pytest.mark.asyncio
async def test_executor_calls_sync_tool_string_result():
    executor, _ = _make_executor_tools()
    result = await executor.execute("greet", {"name": "world"})
    assert result == "hi world"


# --- Async tool support ----------------------------------------------------


@pytest.mark.asyncio
async def test_executor_calls_async_tool():
    """ToolExecutor handles async tool functions correctly."""

    @tool
    async def fetch(url: str) -> str:
        """Fetch a URL."""
        return f"response from {url}"

    executor = ToolExecutor({"fetch": fetch})
    result = await executor.execute("fetch", {"url": "https://example.com"})
    assert result == "response from https://example.com"


# --- Exception wrapping ----------------------------------------------------


@pytest.mark.asyncio
async def test_executor_wraps_exception_in_tool_execution_error():
    """Exceptions from tools are wrapped in ToolExecutionError."""

    @tool
    def boom(x: int) -> int:
        """Explode."""
        raise ValueError("kaboom")

    executor = ToolExecutor({"boom": boom})
    with pytest.raises(ToolExecutionError) as exc_info:
        await executor.execute("boom", {"x": 42})

    err = exc_info.value
    assert err.tool_name == "boom"
    assert err.tool_args == {"x": 42}
    assert isinstance(err.original_error, ValueError)
    assert "kaboom" in str(err.original_error)


@pytest.mark.asyncio
async def test_executor_wraps_async_exception():
    """Exceptions from async tools are also wrapped."""

    @tool
    async def async_boom(x: int) -> int:
        """Async explode."""
        raise RuntimeError("async kaboom")

    executor = ToolExecutor({"async_boom": async_boom})
    with pytest.raises(ToolExecutionError) as exc_info:
        await executor.execute("async_boom", {"x": 1})

    err = exc_info.value
    assert err.tool_name == "async_boom"
    assert isinstance(err.original_error, RuntimeError)


# --- ToolExecutionError attributes -----------------------------------------


@pytest.mark.asyncio
async def test_tool_execution_error_has_correct_attributes():
    """ToolExecutionError carries tool_name, tool_args, and original_error."""

    @tool
    def fail(msg: str) -> str:
        """Fail with message."""
        raise TypeError(msg)

    executor = ToolExecutor({"fail": fail})
    with pytest.raises(ToolExecutionError) as exc_info:
        await executor.execute("fail", {"msg": "bad type"})

    err = exc_info.value
    assert err.tool_name == "fail"
    assert err.tool_args == {"msg": "bad type"}
    assert isinstance(err.original_error, TypeError)
    assert str(err.original_error) == "bad type"
    assert err.component == "ToolExecutor"
    assert err.suggestion  # non-empty


# --- Unknown tool ----------------------------------------------------------


@pytest.mark.asyncio
async def test_executor_unknown_tool_raises_error():
    """Calling an unknown tool name raises ToolExecutionError."""
    executor, _ = _make_executor_tools()
    with pytest.raises(ToolExecutionError, match="Unknown tool 'nope'"):
        await executor.execute("nope", {})


@pytest.mark.asyncio
async def test_executor_unknown_tool_error_attributes():
    """Unknown tool error has correct tool_name and tool_args."""
    executor, _ = _make_executor_tools()
    with pytest.raises(ToolExecutionError) as exc_info:
        await executor.execute("missing", {"a": 1})

    err = exc_info.value
    assert err.tool_name == "missing"
    assert err.tool_args == {"a": 1}


# --- TypeMismatchWarning ---------------------------------------------------


@pytest.mark.asyncio
async def test_executor_emits_type_mismatch_warning():
    """TypeMismatchWarning is emitted when return type doesn't match annotation."""

    @tool
    def bad_return(x: int) -> int:
        """Return wrong type."""
        return "not an int"  # type: ignore[return-value]

    executor = ToolExecutor({"bad_return": bad_return})
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = await executor.execute("bad_return", {"x": 1})

    assert result == "not an int"
    assert len(w) == 1
    assert issubclass(w[0].category, TypeMismatchWarning)
    assert "bad_return" in str(w[0].message)
    assert "int" in str(w[0].message)
    assert "str" in str(w[0].message)


@pytest.mark.asyncio
async def test_executor_no_warning_when_type_matches():
    """No warning when the return type matches the annotation."""
    executor, _ = _make_executor_tools()
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = await executor.execute("add", {"a": 1, "b": 2})

    assert result == 3
    type_warnings = [x for x in w if issubclass(x.category, TypeMismatchWarning)]
    assert len(type_warnings) == 0
