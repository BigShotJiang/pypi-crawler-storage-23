"""Tests for ``synth.cli.help_cmd`` — curated help guide output."""

from __future__ import annotations

from unittest.mock import patch

import pytest


# ===================================================================
# _supports_color
# ===================================================================


class TestSupportsColor:
    """Tests for the ``_supports_color`` helper."""

    def test_returns_false_when_no_color_set(self):
        """NO_COLOR env var disables colour."""
        with patch.dict("os.environ", {"NO_COLOR": "1"}):
            from synth.cli.help_cmd import _supports_color

            assert _supports_color() is False

    def test_returns_false_when_stdout_not_tty(self):
        """Non-TTY stdout disables colour."""
        import io

        with patch.dict("os.environ", {}, clear=False), \
             patch("sys.stdout", new=io.StringIO()):
            from synth.cli.help_cmd import _supports_color

            # StringIO has no isatty or returns False
            assert _suppo