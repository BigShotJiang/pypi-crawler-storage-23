"""Unit tests for synth/types.py — core data models."""

from datetime import datetime, timezone

from synth.types import (
    AgentContribution,
    Checkpoint,
    DoneEvent,
    ErrorEvent,
    GuardContext,
    GuardResult,
    Message,
    PausedRun,
    RunResult,
    StageEvent,
    StreamEvent,
    TeamResult,
    ThinkingEvent,
    TokenEvent,
    TokenUsage,
    ToolCallEvent,
    ToolCallRecord,
    ToolResultEvent,
)


# -- TokenUsage ---------------------------------------------------------------


class TestTokenUsage:
    def test_creation(self):
        usage = TokenUsage(input_tokens=100, output_tokens=50, total_tokens=150)
        assert usage.input_tokens == 100
        assert usage.output_tokens == 50
        assert usage.total_tokens == 150

    def test_zero_tokens(self):
        usage = TokenUsage(input_tokens=0, output_tokens=0, total_tokens=0)
        assert usage.total_tokens == 0


# -- ToolCallRecord -----------------------------------------------------------


class TestToolCallRecord:
    def test_creation(self):
        record = ToolCallRecord(
            name="search", args={"query": "hello"}, result="found", latency_ms=42.5
        )
        assert record.name == "search"
        assert record.args == {"query": "hello"}
        assert record.result == "found"
        assert record.latency_ms == 42.5


# -- RunResult -----------------------------------------------------------------


class TestRunResult:
    def test_creation_with_defaults(self):
        tokens = TokenUsage(input_tokens=10, output_tokens=5, total_tokens=15)
        result = RunResult(
            text="Hello!",
            output=None,
            tokens=tokens,
            cost=0.001,
            latency_ms=200.0,
            trace=None,
        )
        assert result.text == "Hello!"
        assert result.output is None
        assert result.tokens.total_tokens == 15
        assert result.cost == 0.001
        assert result.latency_ms == 200.0
        assert result.tool_calls == []

    def test_creation_with_tool_calls(self):
        tokens = TokenUsage(input_tokens=10, output_tokens=5, total_tokens=15)
        record = ToolCallRecord(
            name="calc", args={"x": 1}, result=2, latency_ms=10.0
        )
        result = RunResult(
            text="Done",
            output=None,
            tokens=tokens,
            cost=0.01,
            latency_ms=500.0,
            trace=None,
            tool_calls=[record],
        )
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].name == "calc"

    def test_output_can_hold_any_value(self):
        tokens = TokenUsage(input_tokens=1, output_tokens=1, total_tokens=2)
        result = RunResult(
            text="ok",
            output={"key": "value"},
            tokens=tokens,
            cost=0.0,
            latency_ms=0.0,
            trace=None,
        )
        assert result.output == {"key": "value"}


# -- Stream event types --------------------------------------------------------


class TestTokenEvent:
    def test_creation(self):
        event = TokenEvent(text="Hello")
        assert event.text == "Hello"


class TestToolCallEvent:
    def test_creation(self):
        event = ToolCallEvent(name="search", args={"q": "test"})
        assert event.name == "search"
        assert event.args == {"q": "test"}


class TestToolResultEvent:
    def test_creation(self):
        event = ToolResultEvent(name="search", result=["a", "b"])
        assert event.name == "search"
        assert event.result == ["a", "b"]


class TestThinkingEvent:
    def test_creation(self):
        event = ThinkingEvent(text="Let me think...")
        assert event.text == "Let me think..."


class TestDoneEvent:
    def test_creation(self):
        tokens = TokenUsage(input_tokens=1, output_tokens=1, total_tokens=2)
        run_result = RunResult(
            text="done", output=None, tokens=tokens, cost=0.0, latency_ms=0.0, trace=None
        )
        event = DoneEvent(result=run_result)
        assert event.result.text == "done"


class TestErrorEvent:
    def test_creation(self):
        err = ValueError("something broke")
        event = ErrorEvent(error=err)
        assert isinstance(event.error, ValueError)
        assert str(event.error) == "something broke"


class TestStreamEventUnion:
    def test_token_event_is_stream_event(self):
        event: StreamEvent = TokenEvent(text="hi")
        assert isinstance(event, TokenEvent)

    def test_error_event_is_stream_event(self):
        event: StreamEvent = ErrorEvent(error=RuntimeError("fail"))
        assert isinstance(event, ErrorEvent)


class TestStageEvent:
    def test_creation(self):
        inner = TokenEvent(text="tok")
        stage = StageEvent(stage_name="summarizer", event=inner)
        assert stage.stage_name == "summarizer"
        assert isinstance(stage.event, TokenEvent)


# -- Guard types ---------------------------------------------------------------


class TestGuardContext:
    def test_creation(self):
        ctx = GuardContext(cumulative_cost=0.05, tool_calls=["search", "calc"], run_id="abc")
        assert ctx.cumulative_cost == 0.05
        assert ctx.tool_calls == ["search", "calc"]
        assert ctx.run_id == "abc"

    def test_none_run_id(self):
        ctx = GuardContext(cumulative_cost=0.0, tool_calls=[], run_id=None)
        assert ctx.run_id is None


class TestGuardResult:
    def test_passed(self):
        result = GuardResult(passed=True)
        assert result.passed is True
        assert result.violation_message is None

    def test_failed_with_message(self):
        result = GuardResult(passed=False, violation_message="PII detected")
        assert result.passed is False
        assert result.violation_message == "PII detected"


# -- Checkpoint types ----------------------------------------------------------


class TestCheckpoint:
    def test_creation(self):
        ts = datetime(2025, 1, 1, tzinfo=timezone.utc)
        cp = Checkpoint(run_id="run-1", state={"x": 1}, step=3, node_name="review", timestamp=ts)
        assert cp.run_id == "run-1"
        assert cp.state == {"x": 1}
        assert cp.step == 3
        assert cp.node_name == "review"
        assert cp.timestamp == ts


class TestPausedRun:
    def test_creation(self):
        ts = datetime.now(tz=timezone.utc)
        cp = Checkpoint(run_id="r1", state={}, step=2, node_name="approve", timestamp=ts)
        paused = PausedRun(run_id="r1", paused_at_node="approve", state={}, checkpoint=cp)
        assert paused.run_id == "r1"
        assert paused.paused_at_node == "approve"
        assert paused.checkpoint.step == 2


# -- Team types ----------------------------------------------------------------


class TestAgentContribution:
    def test_creation(self):
        tokens = TokenUsage(input_tokens=5, output_tokens=5, total_tokens=10)
        result = RunResult(
            text="sub-answer", output=None, tokens=tokens, cost=0.01, latency_ms=100.0, trace=None
        )
        contrib = AgentContribution(agent_name="researcher", result=result)
        assert contrib.agent_name == "researcher"
        assert contrib.result.text == "sub-answer"


class TestTeamResult:
    def test_creation(self):
        tokens = TokenUsage(input_tokens=5, output_tokens=5, total_tokens=10)
        result = RunResult(
            text="sub", output=None, tokens=tokens, cost=0.01, latency_ms=50.0, trace=None
        )
        contrib = AgentContribution(agent_name="writer", result=result)
        msg: Message = {"role": "user", "content": "hello"}
        team_result = TeamResult(
            answer="Final answer",
            contributions=[contrib],
            message_trace=[msg],
            total_cost=0.02,
            total_latency_ms=150.0,
        )
        assert team_result.answer == "Final answer"
        assert len(team_result.contributions) == 1
        assert team_result.message_trace[0]["role"] == "user"
        assert team_result.total_cost == 0.02


# -- Message TypedDict ---------------------------------------------------------


class TestMessage:
    def test_creation(self):
        msg: Message = {"role": "assistant", "content": "Hi there"}
        assert msg["role"] == "assistant"
        assert msg["content"] == "Hi there"
