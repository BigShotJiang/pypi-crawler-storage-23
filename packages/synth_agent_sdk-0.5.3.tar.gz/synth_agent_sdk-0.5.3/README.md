# Synth

> Autonomous agents, engineered.

A Python SDK for building production-grade AI agents and multi-agent systems. From a 3-line single agent to complex, stateful, resumable multi-agent graphs — with model-agnostic provider support, streaming, observability, evaluation, and guardrails out of the box.

## Quick Start

```bash
pip install synth-agent-sdk
```

```python
from synth import Agent

agent = Agent(model="claude-sonnet-4-5", instructions="You are a helpful assistant.")
result = agent.run("What is the capital of France?")
print(result.text)
```

## Features

- **Minimal core** — 3 lines to a working agent
- **Tools** — `@tool` decorator auto-generates JSON schemas from type hints
- **Streaming** — typed event stream (`TokenEvent`, `ToolCallEvent`, `DoneEvent`, …)
- **Multi-provider** — Claude, GPT, Gemini, Ollama, AWS Bedrock via a single `model` string
- **Memory** — thread-scoped, persistent (Redis), or semantic (vector) conversation history
- **Guards** — declarative PII filtering, cost limits, tool-call blocking, custom checks
- **Structured output** — Pydantic model validation with automatic retry
- **Pipeline** — chain agents sequentially with optional parallel stages
- **Graph** — directed-graph workflows with conditional edges, loops, and concurrency
- **Agent Teams** — orchestrator-coordinated multi-agent collaboration
- **Tracing** — automatic OpenTelemetry-compatible traces on every run
- **Checkpointing** — resumable runs with local or Redis-backed state persistence
- **Evaluation** — built-in eval framework with exact-match and semantic scoring
- **CLI** — `synth dev`, `synth run`, `synth eval`, `synth trace`, `synth doctor`
- **AWS AgentCore** — deploy to AgentCore with `synth deploy --target agentcore`

## Installation

Most users start here:

```bash
pip install synth-agent-sdk[anthropic]     # Anthropic Claude (recommended)
```

Other options:

```bash
pip install synth-agent-sdk[quickstart]    # Claude + GPT (tutorials/demos)
pip install synth-agent-sdk[openai]        # OpenAI GPT only
pip install synth-agent-sdk[google]        # Google Gemini only
pip install synth-agent-sdk[bedrock]       # AWS Bedrock only
pip install synth-agent-sdk[all]           # All providers
```

Requires Python 3.10+.

If you see a provider error, install the matching extra:
```bash
# Error: "Provider package 'anthropic' is not installed"
pip install synth-agent-sdk[anthropic]
```

## CLI

After installing, run `synth` to see the boot sequence:

```bash
synth
```

Available commands:

```bash
synth create agent my-app              # Scaffold agent with tools
synth create multi-agent my-team       # Scaffold team + pipeline
synth create agentcore my-service      # Scaffold AgentCore project
synth dev my_agent.py                  # Local REPL with hot-reload + trace UI
synth run my_agent.py "prompt"         # Execute agent, print result
synth eval my_agent.py --dataset d     # Run evaluation suite
synth trace <run_id>                   # Open trace in browser
synth deploy --target agentcore        # Deploy to AWS AgentCore
synth doctor                           # Check env, credentials, deps
```

## Documentation

See the [User Guide](SynthSDK%20User%20Guide.md) for a full walkthrough.

## License

MIT
