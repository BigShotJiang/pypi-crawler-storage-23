"""``synth deploy`` command — deploy agent to a target platform."""

from __future__ import annotations

import sys

import click

from synth.errors import SynthConfigError


def run_deploy(target: str, dry_run: bool, file: str | None) -> None:
    """Package and deploy an agent to the specified target."""
    if target != "agentcore":
        click.echo(
            click.style(f"Unknown target '{target}'. Supported: agentcore", fg="red"),
            err=True,
        )
        sys.exit(1)

    try:
        from synth.deploy.agentcore.adapter import AgentCoreAdapter  # noqa: F401
    except ImportError:
        click.echo(
            click.style(
                "synth[agentcore] is not installed. "
                "Run: pip install synth-agent-sdk[agentcore]",
                fg="red",
            ),
            err=True,
        )
        sys.exit(1)

    try:
        from synth.deploy.packager import package

        if file:
            from synth.cli.run_cmd import _load_agent
            agent = _load_agent(file)
        else:
            click.echo(
                click.style("No agent file specified.", fg="red"),
                err=True,
            )
            sys.exit(1)

        manifest = package(agent, dry_run=dry_run)

        if dry_run:
            click.echo(click.style("Dry run — validation passed.", fg="green"))
        else:
            click.echo(click.style("Deployment artifact created.", fg="green"))

        click.echo(f"Agent: {manifest['name']}")
        click.echo(f"Actions: {len(manifest['actions'])}")

    except SynthConfigError as exc:
        click.echo(click.style(f"Error: {exc}", fg="red"), err=True)
        click.echo(click.style(f"Suggestion: {exc.suggestion}", fg="yellow"), err=True)
        sys.exit(1)
