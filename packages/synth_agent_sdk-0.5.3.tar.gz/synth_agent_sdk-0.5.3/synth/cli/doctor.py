"""``synth doctor`` command — check environment and dependencies."""

from __future__ import annotations

import os
import sys

import click


_PROVIDER_ENV_VARS = {
    "Anthropic": "ANTHROPIC_API_KEY",
    "OpenAI": "OPENAI_API_KEY",
    "Google": "GOOGLE_API_KEY",
}

_OPTIONAL_PACKAGES = {
    "anthropic": "synth[anthropic]",
    "openai": "synth[openai]",
    "google.generativeai": "synth[google]",
    "boto3": "synth[bedrock]",
}


def run_doctor() -> None:
    """Check environment variables, credentials, and dependency versions."""
    issues = 0
    missing_providers: list[str] = []

    # 1. Python version
    v = sys.version_info
    if v >= (3, 10):
        _ok(f"Python {v.major}.{v.minor}.{v.micro}")
    else:
        _fail(f"Python {v.major}.{v.minor} — requires 3.10+")
        issues += 1

    # 2. Core dependencies
    for pkg in ("pydantic", "httpx", "click"):
        try:
            mod = __import__(pkg)
            ver = getattr(mod, "__version__", "?")
            _ok(f"{pkg} {ver}")
        except ImportError:
            _fail(f"{pkg} not installed. Run: pip install synth-agent-sdk")
            issues += 1

    # 3. Provider env vars
    for name, var in _PROVIDER_ENV_VARS.items():
        if os.environ.get(var):
            _ok(f"{name} ({var} set)")
        else:
            _info(f"{name} ({var} not set)")

    # 4. SYNTH_TRACE_ENDPOINT
    endpoint = os.environ.get("SYNTH_TRACE_ENDPOINT")
    if endpoint:
        if endpoint.startswith("https://"):
            _ok(f"SYNTH_TRACE_ENDPOINT: {endpoint[:40]}...")
        else:
            _fail("SYNTH_TRACE_ENDPOINT should use HTTPS")
            issues += 1
    else:
        _info("SYNTH_TRACE_ENDPOINT not set (traces local only)")

    # 5. Optional provider packages
    for pkg, extra in _OPTIONAL_PACKAGES.items():
        try:
            __import__(pkg)
            _ok(f"{extra} installed")
        except ImportError:
            _info(f"{extra} not installed")
            missing_providers.append(extra)

    # 6. AWS credentials
    has_aws_env = bool(os.environ.get("AWS_ACCESS_KEY_ID"))
    has_aws_file = os.path.exists(
        os.path.join(os.path.expanduser("~"), ".aws", "credentials"),
    )
    if has_aws_env or has_aws_file:
        source = "env vars" if has_aws_env else "~/.aws/credentials"
        _ok(f"AWS credentials found ({source})")
    else:
        _info(
            "AWS credentials not configured. "
            "Run: pip install awscli && aws configure"
        )

    # Summary
    click.echo("")
    if issues == 0:
        click.echo(click.style("All checks passed.", fg="green"))
    else:
        click.echo(click.style(f"{issues} issue(s) found.", fg="red"))

    # Helpful suggestions for missing providers
    if missing_providers:
        click.echo("")
        click.echo(click.style("Missing provider packages:", fg="yellow"))
        click.echo(f"  Install all: pip install synth-agent-sdk[all]")
        click.echo(f"  Or individually: pip install {' '.join(missing_providers)}")


def _ok(msg: str) -> None:
    """Print an OK status line."""
    click.echo(f"  {click.style('[  OK  ]', fg='green')} {msg}")


def _fail(msg: str) -> None:
    """Print a FAIL status line."""
    click.echo(f"  {click.style('[FAIL]', fg='red')}  {msg}")


def _info(msg: str) -> None:
    """Print an info status line."""
    click.echo(f"  {click.style('[INFO]', fg='yellow')}  {msg}")
