"""Display package installation information.

Shows what's included in each installation option, similar to React's
installation output.
"""

from __future__ import annotations

import os
import sys


def display_package_info(extra: str = "anthropic") -> None:
    """Display what gets installed with a specific extra.

    Parameters
    ----------
    extra:
        The optional extra being installed (anthropic, openai, etc.)
    """
    # Skip if not in a TTY
    if not sys.stdout.isatty():
        return

    no_color = os.environ.get("NO_COLOR") or os.environ.get("SYNTH_NO_BANNER")

    if no_color:
        _display_plain_info(extra)
    else:
        _display_colored_info(extra)


def _display_colored_info(extra: str) -> None:
    """Display colorful package info."""
    GREEN = "\033[92m"
    CYAN = "\033[96m"
    YELLOW = "\033[93m"
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"

    # Package details
    packages = {
        "anthropic": {
            "provider": "Anthropic Claude",
            "deps": ["anthropic>=0.39"],
            "models": ["claude-sonnet-4", "claude-opus-4", "claude-haiku-4"],
        },
        "openai": {
            "provider": "OpenAI GPT",
            "deps": ["openai>=1.0"],
            "models": ["gpt-4o", "gpt-4-turbo", "gpt-3.5-turbo"],
        },
        "google": {
            "provider": "Google Gemini",
            "deps": ["google-generativeai>=0.8"],
            "models": ["gemini-2.0-flash", "gemini-1.5-pro"],
        },
        "bedrock": {
            "provider": "AWS Bedrock",
            "deps": ["boto3>=1.35"],
            "models": ["bedrock/claude-*", "bedrock/llama-*"],
        },
        "quickstart": {
            "provider": "Claude + GPT",
            "deps": ["anthropic>=0.39", "openai>=1.0"],
            "models": ["claude-sonnet-4", "gpt-4o"],
        },
        "all": {
            "provider": "All Providers",
            "deps": [
                "anthropic>=0.39",
                "openai>=1.0",
                "google-generativeai>=0.8",
                "ollama>=0.4",
                "boto3>=1.35",
            ],
            "models": ["All supported models"],
        },
    }

    info = packages.get(extra, packages["anthropic"])

    message = f"""
{GREEN}{BOLD}Installing synth-agent-sdk[{extra}]{RESET}

{BOLD}Provider:{RESET} {CYAN}{info['provider']}{RESET}

{BOLD}Dependencies:{RESET}
"""

    for dep in info["deps"]:
        message += f"  {GREEN}+{RESET} {dep}\n"

    message += f"""
{BOLD}Available Models:{RESET}
"""

    for model in info["models"]:
        message += f"  {CYAN}•{RESET} {model}\n"

    message += f"""
{DIM}Core SDK includes: pydantic, httpx, click, rich, prompt-toolkit{RESET}
"""

    print(message)


def _display_plain_info(extra: str) -> None:
    """Display plain text package info."""
    packages = {
        "anthropic": {
            "provider": "Anthropic Claude",
            "deps": ["anthropic>=0.39"],
            "models": ["claude-sonnet-4", "claude-opus-4", "claude-haiku-4"],
        },
        "openai": {
            "provider": "OpenAI GPT",
            "deps": ["openai>=1.0"],
            "models": ["gpt-4o", "gpt-4-turbo", "gpt-3.5-turbo"],
        },
        "google": {
            "provider": "Google Gemini",
            "deps": ["google-generativeai>=0.8"],
            "models": ["gemini-2.0-flash", "gemini-1.5-pro"],
        },
        "bedrock": {
            "provider": "AWS Bedrock",
            "deps": ["boto3>=1.35"],
            "models": ["bedrock/claude-*", "bedrock/llama-*"],
        },
        "quickstart": {
            "provider": "Claude + GPT",
            "deps": ["anthropic>=0.39", "openai>=1.0"],
            "models": ["claude-sonnet-4", "gpt-4o"],
        },
        "all": {
            "provider": "All Providers",
            "deps": [
                "anthropic>=0.39",
                "openai>=1.0",
                "google-generativeai>=0.8",
                "ollama>=0.4",
                "boto3>=1.35",
            ],
            "models": ["All supported models"],
        },
    }

    info = packages.get(extra, packages["anthropic"])

    message = f"""
Installing synth-agent-sdk[{extra}]

Provider: {info['provider']}

Dependencies:
"""

    for dep in info["deps"]:
        message += f"  + {dep}\n"

    message += """
Available Models:
"""

    for model in info["models"]:
        message += f"  • {model}\n"

    message += """
Core SDK includes: pydantic, httpx, click, rich, prompt-toolkit
"""

    print(message)
