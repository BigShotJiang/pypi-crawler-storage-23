"""``synth create`` command group — scaffold agents, tools, MCPs, and UIs.

Provides interactive project scaffolding with provider selection for agents,
MCP server templates, standalone tool files, multi-agent teams, and a local
testing UI.
"""

from __future__ import annotations

import os
import sys

import click


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _write(path: str, content: str) -> None:
    """Write *content* to *path* with UTF-8 encoding."""
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def _ensure_dir(name: str) -> None:
    """Create project directory or exit if it already exists."""
    if os.path.exists(name):
        click.echo(
            click.style(f"Directory '{name}' already exists.", fg="red"),
        )
        raise SystemExit(1)
    os.makedirs(name)


def _success_banner(name: str, files: list[tuple[str, str]]) -> None:
    """Print a consistent success banner with file listing."""
    click.echo(click.style("Project created successfully!", fg="green"))
    click.echo("")
    click.echo(f"  {click.style(name + '/', fg='cyan')}")
    for fname, desc in files:
        click.echo(f"    {fname:<20s} {desc}")
    click.echo("")


def _next_steps(steps: list[str]) -> None:
    """Print next-steps block."""
    click.echo("  Next steps:")
    for step in steps:
        click.echo(f"    {click.style('>', dim=True)} {step}")
    click.echo("")


# ---------------------------------------------------------------------------
# Provider configuration map
# ---------------------------------------------------------------------------

_PROVIDERS: dict[str, dict[str, str]] = {
    "anthropic": {
        "model": "claude-sonnet-4-5",
        "extra": "anthropic",
        "env_var": "ANTHROPIC_API_KEY",
        "display": "Anthropic (Claude)",
    },
    "openai": {
        "model": "gpt-4o",
        "extra": "openai",
        "env_var": "OPENAI_API_KEY",
        "display": "OpenAI (GPT)",
    },
    "llama": {
        "model": "ollama/llama3.2",
        "extra": "ollama",
        "env_var": "",
        "display": "Llama (via Ollama)",
    },
    "gemini": {
        "model": "gemini/gemini-2.0-flash",
        "extra": "google",
        "env_var": "GOOGLE_API_KEY",
        "display": "Google Gemini",
    },
    "agentcore": {
        "model": "bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0",
        "extra": "agentcore",
        "env_var": "",
        "display": "AWS AgentCore (Bedrock)",
    },
}


# ---------------------------------------------------------------------------
# synth create agent
# ---------------------------------------------------------------------------

_AGENT_TEMPLATE = '''"""{display} agent built with SynthAgentSDK."""

from synth import Agent, tool


@tool
def greet(name: str) -> str:
    """Greet a user by name."""
    return f"Hello, {{name}}!"


@tool
def get_current_time() -> str:
    """Get the current date and time."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


agent = Agent(
    model="{model}",
    instructions=(
        "You are a helpful assistant. Use your tools when appropriate."
    ),
    tools=[greet, get_current_time],
)


if __name__ == "__main__":
    result = agent.run("Hello! What time is it?")
    print(result.text)
'''

_AGENTCORE_AGENT_TEMPLATE = '''"""{display} agent deployed to AWS AgentCore."""

from synth import Agent, tool
from synth.deploy.agentcore import agentcore_handler


@tool
def greet(name: str) -> str:
    """Greet a user by name."""
    return f"Hello, {{name}}! Welcome aboard."


agent = Agent(
    model="{model}",
    instructions=(
        "You are a helpful assistant deployed on AWS AgentCore. "
        "Use the tools available to you to help users."
    ),
    tools=[greet],
)

# AgentCore entry point - creates a BedrockAgentCoreApp instance
# This follows the AgentCore deployment pattern required by the runtime
app = agentcore_handler(agent)

# For local testing with agentcore CLI:
# 1. agentcore dev (starts local server)
# 2. agentcore invoke --dev '{{"prompt": "Hello"}}'
#
# For deployment:
# 1. agentcore configure --entrypoint agent.py
# 2. agentcore launch
'''

_AGENTCORE_REQUIREMENTS = '''# SynthAgentSDK with AgentCore support
synth-agent-sdk[agentcore]>=0.5.2

# Add your additional dependencies here
# httpx>=0.27
# pydantic>=2.0
'''

_AGENTCORE_CONFIG = '''# AgentCore Deployment Configuration
#
# This file is used by: synth deploy --target agentcore
#
# Agent Metadata
agent_name: {name}
agent_description: "AI agent deployed to AWS AgentCore"

# AWS Configuration
aws_region: us-east-1

# IAM Permissions (least-privilege)
# Add only the permissions your agent's tools actually need
permissions:
  - "bedrock:InvokeModel"
  - "bedrock:InvokeModelWithResponseStream"
  # - "s3:GetObject"
  # - "dynamodb:GetItem"
  # - "lambda:InvokeFunction"

# Runtime Configuration
runtime:
  memory_mb: 512
  timeout_seconds: 300
  
# Environment Variables (non-sensitive only)
# Sensitive values should be set via AWS Secrets Manager
environment:
  SYNTH_NO_BANNER: "1"
  # SYNTH_TRACE_ENDPOINT: "https://your-otel-collector/v1/traces"
'''

_AGENT_README = '''# {name}

A {display} agent built with [SynthAgentSDK](https://pypi.org/project/synth-agent-sdk/).

## Setup

```bash
pip install synth-agent-sdk[{extra}]
{env_setup}```

## Run

```bash
synth run agent.py "Hello, who are you?"
synth dev agent.py
synth doctor
```
'''

_AGENTCORE_README = '''# {name}

An AI agent built with [SynthAgentSDK](https://pypi.org/project/synth-agent-sdk/) and deployed to AWS AgentCore.

## Prerequisites

- Python 3.10+
- AWS Account with AgentCore access
- AWS CLI configured

## Setup

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Configure AWS credentials:

```bash
pip install awscli
aws configure
```

3. Review and customize `agentcore.yaml`:
   - Set your agent name and description
   - Add IAM permissions your tools need
   - Configure runtime settings

## Local Development

Test your agent locally before deploying:

```bash
# Run once
synth run agent.py "Hello, who are you?"

# Interactive development
synth dev agent.py

# Check your setup
synth doctor
```

## Deploy to AgentCore

1. Validate your configuration (dry run):

```bash
synth deploy --target agentcore --dry-run agent.py
```

2. Deploy for real:

```bash
synth deploy --target agentcore agent.py
```

This will:
- Package your agent code and dependencies
- Generate an AgentCore manifest with your tools and permissions
- Create a deployment artifact in `dist/`
- Deploy to AWS AgentCore

## Project Structure

```
{name}/
├── agent.py              # Your agent with tools and handler
├── requirements.txt      # Python dependencies
├── agentcore.yaml        # Deployment configuration
└── README.md            # This file
```

## Adding Tools

Tools are regular Python functions decorated with `@tool`:

```python
from synth import tool

@tool
def my_tool(param: str) -> str:
    """Description shown to the LLM."""
    # Your implementation
    return "result"

agent = Agent(
    model="bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0",
    tools=[my_tool],
)
```

## IAM Permissions

If your tools need AWS service access, add permissions to `agentcore.yaml`:

```yaml
permissions:
  - "bedrock:InvokeModel"
  - "s3:GetObject"
  - "dynamodb:Query"
```

Follow least-privilege: only grant what your agent actually needs.

## Memory and State

AgentCore provides managed memory and state persistence. Your agent automatically uses AgentCore's memory service when deployed:

```python
agent = Agent(
    model="bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0",
    memory=Memory.thread(),  # Automatically uses AgentCore memory when deployed
)
```

## Monitoring

Traces are automatically forwarded to AgentCore's observability infrastructure. View them in the AgentCore console.

## Troubleshooting

- **Import errors**: Make sure all dependencies are in `requirements.txt`
- **Permission denied**: Check IAM permissions in `agentcore.yaml`
- **Deployment fails**: Run `synth doctor` to verify your setup
- **Agent not responding**: Check CloudWatch logs in the AgentCore console

## Learn More

- [SynthAgentSDK Documentation](https://github.com/yourusername/synth)
- [AWS AgentCore Documentation](https://docs.aws.amazon.com/bedrock/latest/userguide/agents.html)
'''


def _create_agent(name: str, provider: str) -> None:
    """Scaffold an agent project for the given provider."""
    cfg = _PROVIDERS[provider]
    is_agentcore = provider == "agentcore"

    # Pre-flight checks for AgentCore
    if is_agentcore:
        try:
            import boto3  # noqa: F401
        except ImportError:
            click.echo(click.style(
                "boto3 is not installed. Install it with:\n"
                "  pip install synth-agent-sdk[agentcore]",
                fg="yellow",
            ))
            click.echo("")

        has_aws = bool(
            os.environ.get("AWS_ACCESS_KEY_ID")
            or os.path.exists(
                os.path.join(os.path.expanduser("~"), ".aws", "credentials"),
            )
        )
        if not has_aws:
            click.echo(click.style(
                "AWS credentials not found. Configure them with:\n"
                "  pip install awscli && aws configure",
                fg="yellow",
            ))
            click.echo("")

    # Llama/Ollama check
    if provider == "llama":
        click.echo(click.style(
            "Llama runs locally via Ollama. Make sure Ollama is installed:\n"
            "  https://ollama.com/download\n"
            "  ollama pull llama3.2",
            fg="yellow",
        ))
        click.echo("")

    _ensure_dir(name)

    # Write agent file
    if is_agentcore:
        _write(
            os.path.join(name, "agent.py"),
            _AGENTCORE_AGENT_TEMPLATE.format(**cfg),
        )
        _write(
            os.path.join(name, "requirements.txt"),
            _AGENTCORE_REQUIREMENTS,
        )
        _write(
            os.path.join(name, "agentcore.yaml"),
            _AGENTCORE_CONFIG.format(name=name),
        )
        _write(
            os.path.join(name, "README.md"),
            _AGENTCORE_README.format(name=name),
        )
    else:
        _write(
            os.path.join(name, "agent.py"),
            _AGENT_TEMPLATE.format(**cfg),
        )
        env_setup = (
            f'export {cfg["env_var"]}="your-key-here"\n'
            if cfg["env_var"]
            else ""
        )
        _write(
            os.path.join(name, "README.md"),
            _AGENT_README.format(name=name, env_setup=env_setup, **cfg),
        )

    # Success output
    files = [("agent.py", f'{cfg["display"]} agent')]
    if is_agentcore:
        files.append(("requirements.txt", "Python dependencies"))
        files.append(("agentcore.yaml", "Deployment configuration"))
    files.append(("README.md", "Getting started guide"))
    _success_banner(name, files)

    steps = [f"cd {name}"]
    if is_agentcore:
        steps.append("pip install -r requirements.txt")
        steps.append("aws configure  # Set up AWS credentials")
    else:
        steps.append(f"pip install synth-agent-sdk[{cfg['extra']}]")
    if cfg["env_var"]:
        steps.append(f'export {cfg["env_var"]}="your-key"')
    if provider == "llama":
        steps.append("ollama pull llama3.2")
    steps.append('synth run agent.py "Hello"')
    if is_agentcore:
        steps.append("synth deploy --target agentcore --dry-run agent.py")
        steps.append("synth deploy --target agentcore agent.py")
    _next_steps(steps)


# ---------------------------------------------------------------------------
# synth create tool
# ---------------------------------------------------------------------------

_TOOL_TEMPLATE = '''"""Custom tools for SynthAgentSDK agents.

Each function decorated with ``@tool`` becomes available to the agent.
Rules:
  - Every parameter needs a type annotation.
  - Must have a docstring (this is sent to the LLM as the tool description).
  - Can be sync or async.
"""

from __future__ import annotations

from synth import tool


@tool
def search(query: str, limit: int = 5) -> list[str]:
    """Search for information matching the query.

    Parameters
    ----------
    query:
        The search term.
    limit:
        Maximum number of results to return.
    """
    # TODO: Replace with your real search implementation
    return [f"Result {{i + 1}} for '{{query}}'" for i in range(limit)]


@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression safely.

    Parameters
    ----------
    expression:
        A numeric expression like ``2 + 2`` or ``sqrt(16)``.
    """
    import math
    allowed_names = {k: v for k, v in math.__dict__.items() if not k.startswith("_")}
    try:
        result = eval(expression, {{"__builtins__": {{}}}}, allowed_names)  # noqa: S307
        return str(result)
    except Exception as e:
        return f"Error: {{e}}"


@tool
async def fetch_url(url: str) -> str:
    """Fetch the text content of a URL (async example).

    Parameters
    ----------
    url:
        The URL to fetch.
    """
    import httpx
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, follow_redirects=True, timeout=10.0)
        resp.raise_for_status()
        return resp.text[:2000]
'''


def _create_tool(name: str) -> None:
    """Scaffold a standalone tools file."""
    filename = f"{name}.py" if not name.endswith(".py") else name

    if os.path.exists(filename):
        click.echo(
            click.style(f"File '{filename}' already exists.", fg="red"),
        )
        raise SystemExit(1)

    _write(filename, _TOOL_TEMPLATE)

    click.echo(click.style(f"Tool file created: {filename}", fg="green"))
    click.echo("")
    click.echo("  Use it in your agent:")
    click.echo("")
    click.echo(f"    from {name.replace('.py', '')} import search, calculate, fetch_url")
    click.echo("")
    click.echo("    agent = Agent(")
    click.echo("        model=\"claude-sonnet-4-5\",")
    click.echo("        tools=[search, calculate, fetch_url],")
    click.echo("    )")
    click.echo("")


# ---------------------------------------------------------------------------
# synth create mcp
# ---------------------------------------------------------------------------

_MCP_SERVER_TEMPLATE = '''"""MCP server built with FastMCP.

Run this server:
    python server.py            # stdio transport (default)
    python server.py --sse      # SSE transport for web clients

Register in your MCP config (.kiro/settings/mcp.json):
    {{
        "mcpServers": {{
            "{name}": {{
                "command": "python",
                "args": ["{name}/server.py"]
            }}
        }}
    }}
"""

from __future__ import annotations

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    raise SystemExit(
        "mcp package is not installed. Install it with:\\n"
        "  pip install mcp"
    )

mcp = FastMCP("{name}")


# ---------------------------------------------------------------------------
# Tools — callable functions the LLM can invoke
# ---------------------------------------------------------------------------

@mcp.tool()
def greet(name: str) -> str:
    """Greet a user by name."""
    return f"Hello, {{name}}!"


@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers together."""
    return a + b


# ---------------------------------------------------------------------------
# Resources — data the LLM can read
# ---------------------------------------------------------------------------

@mcp.resource("info://status")
def get_status() -> str:
    """Return the current server status."""
    return "Server is running."


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    transport = "sse" if "--sse" in sys.argv else "stdio"
    mcp.run(transport=transport)
'''

_MCP_README = '''# {name}

An MCP (Model Context Protocol) server built with [FastMCP](https://github.com/jlowin/fastmcp).

## Setup

```bash
pip install mcp
```

## Run

```bash
python server.py          # stdio (for CLI / IDE integration)
python server.py --sse    # SSE (for web clients)
```

## Register

Add to your MCP config (`.kiro/settings/mcp.json`):

```json
{{
    "mcpServers": {{
        "{name}": {{
            "command": "python",
            "args": ["{name}/server.py"]
        }}
    }}
}}
```

## Adding Tools

```python
@mcp.tool()
def my_tool(param: str) -> str:
    """Description shown to the LLM."""
    return "result"
```

## Adding Resources

```python
@mcp.resource("data://my-resource")
def my_resource() -> str:
    """A readable data source for the LLM."""
    return "resource content"
```
'''


def _create_mcp(name: str) -> None:
    """Scaffold an MCP server project."""
    _ensure_dir(name)

    _write(os.path.join(name, "server.py"), _MCP_SERVER_TEMPLATE.format(name=name))
    _write(os.path.join(name, "README.md"), _MCP_README.format(name=name))

    _success_banner(name, [
        ("server.py", "MCP server with sample tools and resources"),
        ("README.md", "Getting started guide"),
    ])
    _next_steps([
        f"cd {name}",
        "pip install mcp",
        "python server.py",
    ])


# ---------------------------------------------------------------------------
# synth create team
# ---------------------------------------------------------------------------

_TEAM_PY = '''"""SynthAgentSDK multi-agent team architecture."""

from synth import Agent, AgentTeam, tool


# --- Specialist agents ---

@tool
def search_web(query: str) -> str:
    """Search the web for information."""
    # TODO: Replace with your real search implementation
    return f"Search results for: {{query}}"


@tool
def write_file(filename: str, content: str) -> str:
    """Write content to a file."""
    # TODO: Replace with your real file writing logic
    return f"Wrote {{len(content)}} chars to {{filename}}"


researcher = Agent(
    model="claude-sonnet-4-5",
    instructions=(
        "You are an expert researcher. Find accurate, up-to-date "
        "information on any topic using your search tool."
    ),
    tools=[search_web],
)

writer = Agent(
    model="claude-sonnet-4-5",
    instructions=(
        "You are a skilled technical writer. Turn research notes into "
        "clear, well-structured documents."
    ),
    tools=[write_file],
)

reviewer = Agent(
    model="claude-sonnet-4-5",
    instructions=(
        "You are a thorough reviewer. Check for accuracy, clarity, "
        "and completeness. Suggest improvements."
    ),
)


# --- Team orchestration ---

team = AgentTeam(
    orchestrator="claude-sonnet-4-5",
    agents=[researcher, writer, reviewer],
    strategy="auto",
)


if __name__ == "__main__":
    result = team.run(
        "Research Python async best practices and write a short guide."
    )
    print(result.answer)
'''

_PIPELINE_PY = '''"""SynthAgentSDK sequential pipeline example."""

from synth import Agent, Pipeline


researcher = Agent(
    model="claude-sonnet-4-5",
    instructions="You research topics and produce detailed notes.",
)

writer = Agent(
    model="claude-sonnet-4-5",
    instructions="You turn research notes into a well-written article.",
)

editor = Agent(
    model="claude-sonnet-4-5",
    instructions="You edit text for grammar, clarity, and conciseness.",
)

pipeline = Pipeline([researcher, writer, editor])


if __name__ == "__main__":
    result = pipeline.run("The future of AI agents in software development")
    print(result.text)
'''

_TEAM_README = '''# {name}

A multi-agent system built with [SynthAgentSDK](https://pypi.org/project/synth-agent-sdk/).

## Setup

```bash
pip install synth-agent-sdk[anthropic]
export ANTHROPIC_API_KEY="your-key-here"
```

## Run

Team mode (orchestrator decides routing):

```bash
synth run team.py "Research and write a guide on Python testing"
```

Pipeline mode (linear chain):

```bash
synth run pipeline.py "The history of open source software"
```
'''


def _create_team(name: str) -> None:
    """Scaffold a multi-agent team project."""
    _ensure_dir(name)

    _write(os.path.join(name, "team.py"), _TEAM_PY)
    _write(os.path.join(name, "pipeline.py"), _PIPELINE_PY)
    _write(os.path.join(name, "README.md"), _TEAM_README.format(name=name))

    _success_banner(name, [
        ("team.py", "Agent team (researcher + writer + reviewer)"),
        ("pipeline.py", "Sequential pipeline (research > write > edit)"),
        ("README.md", "Getting started guide"),
    ])
    _next_steps([
        f"cd {name}",
        "pip install synth-agent-sdk[anthropic]",
        'export ANTHROPIC_API_KEY="your-key"',
        'synth run team.py "Build a REST API guide"',
    ])


# ---------------------------------------------------------------------------
# synth create ui — local testing UI
# ---------------------------------------------------------------------------


def _create_ui(name: str) -> None:
    """Scaffold a local agent testing UI with a FastAPI bridge."""
    from synth.cli._ui_templates import (
        UI_CSS,
        UI_HTML,
        UI_JS,
        UI_README,
        UI_SERVER,
    )

    _ensure_dir(name)

    _write(os.path.join(name, "server.py"), UI_SERVER)
    os.makedirs(os.path.join(name, "static"))
    _write(os.path.join(name, "static", "index.html"), UI_HTML)
    _write(os.path.join(name, "static", "style.css"), UI_CSS)
    _write(os.path.join(name, "static", "app.js"), UI_JS)
    _write(os.path.join(name, "README.md"), UI_README.format(name=name))

    _success_banner(name, [
        ("server.py", "FastAPI bridge (connects UI to your agent)"),
        ("static/", "Dashboard UI (HTML + CSS + JS)"),
        ("README.md", "Getting started guide"),
    ])
    _next_steps([
        f"cd {name}",
        "pip install uvicorn fastapi",
        "# Edit server.py to point AGENT_FILE at your agent",
        "python server.py",
        "# Open http://localhost:8420 in your browser",
    ])
