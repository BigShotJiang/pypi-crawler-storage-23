"""``synth init`` command — interactive project initializer.

Walks the user through a series of prompts to set up a complete
Synth agent project, similar to ``npm init`` but tailored for
AI agent development.
"""

from __future__ import annotations

import os

import click


# ------------------------------------------------------------------
# Provider / feature configuration
# ------------------------------------------------------------------

_PROVIDERS = {
    "anthropic": {
        "model": "claude-sonnet-4-5",
        "extra": "anthropic",
        "env_var": "ANTHROPIC_API_KEY",
        "display": "Anthropic (Claude)",
    },
    "openai": {
        "model": "gpt-4o",
        "extra": "openai",
        "env_var": "OPENAI_API_KEY",
        "display": "OpenAI (GPT)",
    },
    "llama": {
        "model": "ollama/llama3.2",
        "extra": "ollama",
        "env_var": "",
        "display": "Llama (via Ollama)",
    },
    "gemini": {
        "model": "gemini/gemini-2.0-flash",
        "extra": "google",
        "env_var": "GOOGLE_API_KEY",
        "display": "Google Gemini",
    },
    "agentcore": {
        "model": "bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0",
        "extra": "agentcore",
        "env_var": "",
        "display": "AWS AgentCore (Bedrock)",
    },
}

_PROVIDER_CHOICES = click.Choice(
    list(_PROVIDERS.keys()), case_sensitive=False,
)

_FEATURES = {
    "tools": "Custom tool functions",
    "memory": "Conversation memory",
    "guards": "Input/output guards (PII, cost, custom)",
    "structured": "Structured output (Pydantic models)",
    "eval": "Evaluation suite",
    "deploy": "AgentCore deployment handler",
}


# ------------------------------------------------------------------
# Main init flow
# ------------------------------------------------------------------

def run_init() -> None:
    """Run the interactive project initializer."""
    click.echo("")
    click.echo(click.style("  SYNTH INIT", fg="green", bold=True))
    click.echo(click.style(
        "  Interactive project setup\n",
        dim=True,
    ))

    # 1. Project name
    name = click.prompt(
        click.style("  Project name", fg="cyan"),
        default=os.path.basename(os.getcwd()),
    )

    # 2. Description
    description = click.prompt(
        click.style("  Description", fg="cyan"),
        default="An AI agent built with SynthAgentSDK",
    )

    # 3. Provider
    click.echo("")
    click.echo(click.style("  Available providers:", fg="cyan"))
    for key, cfg in _PROVIDERS.items():
        click.echo(f"    {click.style(key, fg='green'):<22s} {cfg['display']}")
    click.echo("")
    provider = click.prompt(
        click.style("  Provider", fg="cyan"),
        type=_PROVIDER_CHOICES,
        default="anthropic",
    )
    cfg = _PROVIDERS[provider.lower()]

    # 4. Features
    click.echo("")
    click.echo(click.style("  Select features:", fg="cyan"))
    selected_features: list[str] = []
    for key, desc in _FEATURES.items():
        if key == "deploy" and provider.lower() != "agentcore":
            continue
        if click.confirm(
            f"    {click.style(desc, dim=True)}",
            default=key in ("tools",),
        ):
            selected_features.append(key)

    # 5. Agent instructions
    click.echo("")
    instructions = click.prompt(
        click.style("  Agent instructions", fg="cyan"),
        default="You are a helpful assistant.",
    )

    # 6. Confirm
    click.echo("")
    click.echo(click.style("  Summary:", fg="green", bold=True))
    click.echo(f"    Name:         {name}")
    click.echo(f"    Provider:     {cfg['display']}")
    click.echo(f"    Model:        {cfg['model']}")
    click.echo(f"    Features:     {', '.join(selected_features) or 'none'}")
    click.echo(f"    Instructions: {instructions[:50]}...")
    click.echo("")

    if not click.confirm(
        click.style("  Create project?", fg="cyan"),
        default=True,
    ):
        click.echo("  Cancelled.")
        return

    # 7. Generate
    _generate_project(
        name=name,
        description=description,
        provider=provider.lower(),
        cfg=cfg,
        features=selected_features,
        instructions=instructions,
    )


# ------------------------------------------------------------------
# Project generation
# ------------------------------------------------------------------

def _generate_project(
    name: str,
    description: str,
    provider: str,
    cfg: dict[str, str],
    features: list[str],
    instructions: str,
) -> None:
    """Generate the project directory and files."""
    if os.path.exists(name):
        click.echo(
            click.style(f"  Directory '{name}' already exists.", fg="red"),
        )
        raise SystemExit(1)

    os.makedirs(name)

    # Build agent.py
    agent_code = _build_agent_code(
        provider, cfg, features, instructions,
    )
    _write(os.path.join(name, "agent.py"), agent_code)

    # Tools file
    if "tools" in features:
        _write(os.path.join(name, "tools.py"), _TOOLS_CODE)

    # Eval dataset
    if "eval" in features:
        _write(
            os.path.join(name, "eval_dataset.json"),
            _EVAL_DATASET,
        )

    # .env.template for agentcore
    if provider == "agentcore":
        _write(os.path.join(name, ".env.template"), _ENV_TEMPLATE)

    # README
    _write(
        os.path.join(name, "README.md"),
        _build_readme(name, description, cfg, features),
    )

    # synth.toml config
    _write(
        os.path.join(name, "synth.toml"),
        _build_config(cfg, features),
    )

    # Success
    click.echo("")
    click.echo(click.style("  Project created!", fg="green", bold=True))
    click.echo("")
    click.echo(f"  {click.style(name + '/', fg='cyan')}")
    for f in os.listdir(name):
        click.echo(f"    {f}")
    click.echo("")
    click.echo("  Next steps:")
    click.echo(f"    {click.style('>', dim=True)} cd {name}")
    click.echo(
        f"    {click.style('>', dim=True)} "
        f"pip install synth-agent-sdk[{cfg['extra']}]",
    )
    if cfg["env_var"]:
        click.echo(
            f"    {click.style('>', dim=True)} "
            f'export {cfg["env_var"]}="your-key"',
        )
    click.echo(
        f'    {click.style(">", dim=True)} '
        f'synth dev agent.py',
    )
    click.echo("")


# ------------------------------------------------------------------
# Code generation helpers
# ------------------------------------------------------------------

def _build_agent_code(
    provider: str,
    cfg: dict[str, str],
    features: list[str],
    instructions: str,
) -> str:
    """Build the agent.py source code."""
    imports = ['from synth import Agent']
    if "tools" in features:
        imports[0] += ', tool'
        imports.append('from tools import search, calculate')
    if "memory" in features:
        imports.append('from synth import Memory')
    if "guards" in features:
        imports.append('from synth import Guard')
    if "structured" in features:
        imports.append('from pydantic import BaseModel')
    if "deploy" in features:
        imports.append(
            'from synth.deploy.agentcore import agentcore_handler',
        )

    lines = [
        f'"""{cfg["display"]} agent built with SynthAgentSDK."""',
        '',
        'from __future__ import annotations',
        '',
    ]
    lines.extend(imports)
    lines.append('')

    # Structured output model
    if "structured" in features:
        lines.extend([
            '',
            'class Response(BaseModel):',
            '    """Structured response from the agent."""',
            '    answer: str',
            '    confidence: float',
            '',
        ])

    # Agent construction
    lines.append('')
    lines.append('agent = Agent(')
    lines.append(f'    model="{cfg["model"]}",')
    lines.append(f'    instructions="{instructions}",')
    if "tools" in features:
        lines.append('    tools=[search, calculate],')
    if "memory" in features:
        lines.append('    memory=Memory.thread(),')
    if "guards" in features:
        lines.append('    guards=[Guard.no_pii_output()],')
    if "structured" in features:
        lines.append('    output_schema=Response,')
    lines.append(')')

    # AgentCore handler
    if "deploy" in features:
        lines.extend([
            '',
            '# AgentCore entry point - creates a BedrockAgentCoreApp instance',
            'app = agentcore_handler(agent)',
        ])

    # Main block
    lines.extend([
        '',
        '',
        'if __name__ == "__main__":',
        '    result = agent.run("Hello! What can you do?")',
        '    print(result.text)',
    ])

    return '\n'.join(lines) + '\n'


_TOOLS_CODE = '''"""Custom tools for the agent."""

from __future__ import annotations

from synth import tool


@tool
def search(query: str, limit: int = 5) -> list[str]:
    """Search for information matching the query."""
    # TODO: Replace with your real search implementation
    return [f"Result {i + 1} for '{query}'" for i in range(limit)]


@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression safely."""
    import math
    allowed = {k: v for k, v in math.__dict__.items() if not k.startswith("_")}
    try:
        result = eval(expression, {"__builtins__": {}}, allowed)  # noqa: S307
        return str(result)
    except Exception as e:
        return f"Error: {e}"
'''

_EVAL_DATASET = '''[
    {
        "input": "What is 2 + 2?",
        "expected": "4"
    },
    {
        "input": "Say hello",
        "expected": "Hello"
    }
]
'''

_ENV_TEMPLATE = '''# AWS Configuration
AWS_DEFAULT_REGION=us-east-1
# AWS_ACCESS_KEY_ID=your-access-key
# AWS_SECRET_ACCESS_KEY=your-secret-key
SYNTH_NO_BANNER=0
'''


def _build_readme(
    name: str,
    description: str,
    cfg: dict[str, str],
    features: list[str],
) -> str:
    """Build the README.md content."""
    lines = [
        f'# {name}',
        '',
        description,
        '',
        '## Setup',
        '',
        '```bash',
        f'pip install synth-agent-sdk[{cfg["extra"]}]',
    ]
    if cfg["env_var"]:
        lines.append(f'export {cfg["env_var"]}="your-key-here"')
    lines.extend([
        '```',
        '',
        '## Run',
        '',
        '```bash',
        'synth dev agent.py',
        'synth run agent.py "Hello"',
        '```',
    ])
    if "eval" in features:
        lines.extend([
            '',
            '## Evaluate',
            '',
            '```bash',
            'synth eval agent.py --dataset eval_dataset.json',
            '```',
        ])
    if "deploy" in features:
        lines.extend([
            '',
            '## Deploy',
            '',
            '```bash',
            'synth deploy --target agentcore agent.py',
            '```',
        ])
    lines.append('')
    return '\n'.join(lines)


def _build_config(
    cfg: dict[str, str],
    features: list[str],
) -> str:
    """Build the synth.toml config file."""
    lines = [
        '# Synth SDK project configuration',
        '',
        '[agent]',
        f'model = "{cfg["model"]}"',
        '',
        '[dev]',
        'hot_reload = true',
        'stream = true',
        '',
    ]
    if "eval" in features:
        lines.extend([
            '[eval]',
            'dataset = "eval_dataset.json"',
            'threshold = 0.5',
            '',
        ])
    return '\n'.join(lines)


def _write(path: str, content: str) -> None:
    """Write content to a file."""
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
