"""ProviderRouter — model string to provider routing.

Uses prefix matching on the model string to resolve the correct
:class:`BaseProvider` subclass.  Provider modules are imported lazily so
that missing optional dependencies surface as clear
:class:`~synth.errors.SynthConfigError` messages with ``pip install``
instructions rather than raw ``ImportError`` tracebacks.
"""

from __future__ import annotations

from typing import Any

from synth.errors import SynthConfigError
from synth.providers.base import BaseProvider


# (module_path, class_name, pip_package, pip_extra)
_ProviderSpec = tuple[str, str, str, str]

# Mapping of model-string prefixes to provider metadata.
# Order matters: first match wins.
_PROVIDER_SPECS: dict[str, _ProviderSpec] = {
    "claude-": ("synth.providers.anthropic", "AnthropicProvider", "anthropic", "anthropic"),
    "gpt-": ("synth.providers.openai", "OpenAIProvider", "openai", "openai"),
    "gemini-": ("synth.providers.google", "GoogleProvider", "google-generativeai", "google"),
    "ollama/": ("synth.providers.ollama", "OllamaProvider", "httpx", "ollama"),
    "bedrock/": ("synth.providers.bedrock", "BedrockProvider", "boto3", "bedrock"),
}

KNOWN_PREFIXES: list[str] = list(_PROVIDER_SPECS.keys())


def _import_provider_class(spec: _ProviderSpec) -> type[BaseProvider]:
    """Lazily import a provider class, raising a friendly error on failure."""
    module_path, class_name, package, extra = spec
    try:
        import importlib

        mod = importlib.import_module(module_path)
        cls = getattr(mod, class_name)
    except (ImportError, AttributeError):
        raise SynthConfigError(
            message=f"Provider package '{package}' is not installed. "
            f"Run: pip install synth-agent-sdk[{extra}]",
            component="ProviderRouter",
            suggestion=f"pip install synth-agent-sdk[{extra}]",
        )
    return cls  # type: ignore[return-value]


class ProviderRouter:
    """Routes model strings to :class:`BaseProvider` instances.

    Prefix-based routing for ``claude-``, ``gpt-``, ``gemini-``,
    ``ollama/``, and ``bedrock/``.  When *base_url* is supplied and no
    prefix matches, a generic :class:`OpenAIProvider`-compatible provider
    is created using that endpoint.
    """

    def resolve(
        self,
        model: str,
        base_url: str | None = None,
        **kwargs: Any,
    ) -> BaseProvider:
        """Resolve a model string to a concrete provider instance.

        Parameters
        ----------
        model:
            Model identifier, e.g. ``"claude-sonnet-4-5"``, ``"gpt-4o"``,
            ``"bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0"``.
        base_url:
            Optional custom endpoint URL.  When provided and no known
            prefix matches, an OpenAI-compatible provider is created
            using this URL.
        **kwargs:
            Extra keyword arguments forwarded to the provider constructor.

        Returns
        -------
        BaseProvider
            A ready-to-use provider instance.

        Raises
        ------
        SynthConfigError
            If the model string doesn't match any known prefix (and no
            *base_url* is given), or if the required provider package is
            not installed.
        """
        # Try prefix matching
        for prefix, spec in _PROVIDER_SPECS.items():
            if model.startswith(prefix):
                cls = _import_provider_class(spec)
                return cls(model=model, base_url=base_url, **kwargs)

        # No prefix matched — fall back to base_url if provided
        if base_url is not None:
            # Use OpenAI-compatible provider for custom endpoints
            openai_spec = _PROVIDER_SPECS["gpt-"]
            cls = _import_provider_class(openai_spec)
            return cls(model=model, base_url=base_url, **kwargs)

        # Nothing matched
        prefixes_str = ", ".join(KNOWN_PREFIXES)
        raise SynthConfigError(
            message=(
                f"Model string '{model}' does not match any known provider. "
                f"Available prefixes: {prefixes_str}. "
                f"Or pass base_url for custom endpoints."
            ),
            component="ProviderRouter",
            suggestion=(
                f"Use one of: {prefixes_str}. "
                f"Or pass base_url for custom endpoints."
            ),
        )
