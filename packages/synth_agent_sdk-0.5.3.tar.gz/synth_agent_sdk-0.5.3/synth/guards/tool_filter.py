"""Tool call filter guard for the Synth SDK.

Blocks tool calls whose names match configured glob patterns.
"""

from __future__ import annotations

import fnmatch

from synth.guards.base import BaseGuard
from synth.types import GuardContext, GuardResult


class ToolFilterGuard(BaseGuard):
    """Guard that blocks tool calls matching glob patterns.

    Uses ``fnmatch.fnmatch()`` to compare each tool call name against the
    configured patterns.

    Parameters
    ----------
    patterns:
        List of glob patterns (e.g. ``["delete_*"]``).
    """

    def __init__(self, patterns: list[str]) -> None:
        super().__init__(name="ToolFilterGuard")
        self.patterns = patterns

    async def check(self, content: str, context: GuardContext) -> GuardResult:
        """Check whether any tool calls match the blocked patterns.

        Parameters
        ----------
        content:
            The text to inspect (unused by this guard).
        context:
            Run context containing ``tool_calls`` made so far.

        Returns
        -------
        GuardResult
            Pass/fail result with violation details if a blocked tool
            was called.
        """
        for tool_name in context.tool_calls:
            for pattern in self.patterns:
                if fnmatch.fnmatch(tool_name, pattern):
                    return GuardResult(
                        passed=False,
                        violation_message=(
                            f"Blocked tool call: '{tool_name}' "
                            f"matches pattern '{pattern}'"
                        ),
                    )
        return GuardResult(passed=True)
