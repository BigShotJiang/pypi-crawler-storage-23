"""Deployment artifact packaging for the Synth SDK.

Packages agent code, dependencies, and configuration into a deployment
artifact suitable for AWS AgentCore.  Supports ``--dry-run`` validation.
"""

from __future__ import annotations

import os
import re
import shutil
import tempfile
from pathlib import Path
from typing import Any

from synth.deploy.agentcore.manifest import generate_manifest
from synth.errors import SynthConfigError


# Directories/files excluded from deployment artifacts
_EXCLUDED = {
    ".env", ".synth", ".hypothesis", ".pytest_cache",
    "__pycache__", ".git", ".venv", "venv",
}


def package(
    agent_or_graph: Any,
    *,
    source_dir: str = ".",
    output_dir: str = "dist",
    dry_run: bool = False,
    name: str | None = None,
    description: str | None = None,
    permissions: list[str] | None = None,
) -> dict[str, Any]:
    """Package an agent for AgentCore deployment.

    Parameters
    ----------
    agent_or_graph:
        The Synth Agent or Graph to package.
    source_dir:
        Root directory of the agent source code.
    output_dir:
        Directory to write the deployment artifact to.
    dry_run:
        If ``True``, validate without creating the artifact.
    name:
        Agent name for the manifest.
    description:
        Agent description for the manifest.
    permissions:
        IAM permissions for the manifest.

    Returns
    -------
    dict
        The generated manifest.

    Raises
    ------
    SynthConfigError
        If validation fails.
    """
    manifest = generate_manifest(
        agent_or_graph,
        name=name,
        description=description,
        permissions=permissions,
    )

    if dry_run:
        return manifest

    src = Path(source_dir)
    dest = Path(output_dir)
    dest.mkdir(parents=True, exist_ok=True)

    # Copy source files, excluding sensitive/unnecessary dirs
    safe_name = re.sub(r'[:/\\*?"<>|]', "-", manifest["name"])
    artifact_dir = dest / safe_name
    if artifact_dir.exists():
        shutil.rmtree(artifact_dir)
    artifact_dir.mkdir(parents=True)

    for item in src.iterdir():
        if item.name in _EXCLUDED:
            continue
        target = artifact_dir / item.name
        if item.is_dir():
            shutil.copytree(item, target, ignore=shutil.ignore_patterns(
                *_EXCLUDED, "*.pyc",
            ))
        else:
            shutil.copy2(item, target)

    # Write manifest
    import json
    manifest_path = artifact_dir / "agentcore_manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, indent=2), encoding="utf-8",
    )

    return manifest
