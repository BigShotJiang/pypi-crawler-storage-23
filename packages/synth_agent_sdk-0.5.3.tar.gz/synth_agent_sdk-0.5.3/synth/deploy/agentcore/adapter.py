"""AgentCore adapter for payload translation.

Translates between AWS AgentCore invocation payloads and Synth's
``run()`` input/output format.
"""

from __future__ import annotations

from typing import Any

from synth._compat import run_sync
from synth.errors import SynthConfigError


class AgentCoreAdapter:
    """Bridge between AgentCore runtime and Synth agents/graphs.

    Parameters
    ----------
    agent_or_graph:
        A Synth ``Agent`` or ``Graph`` instance.
    """

    def __init__(self, agent_or_graph: Any) -> None:
        self._target = agent_or_graph

    def handle_invocation(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Handle an AgentCore invocation synchronously.

        Parameters
        ----------
        payload:
            The AgentCore invocation payload.

        Returns
        -------
        dict
            AgentCore-compatible response.
        """
        return run_sync(self.ahandle_invocation(payload))

    async def ahandle_invocation(
        self, payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Handle an AgentCore invocation asynchronously.

        Parameters
        ----------
        payload:
            The AgentCore invocation payload.

        Returns
        -------
        dict
            AgentCore-compatible response.
        """
        # Validate payload
        prompt = self._extract_prompt(payload)

        # Execute
        result = await self._target.arun(prompt)

        # Translate response
        return {
            "output": {
                "text": result.text,
            },
            "metadata": {
                "tokens": {
                    "input": result.tokens.input_tokens,
                    "output": result.tokens.output_tokens,
                    "total": result.tokens.total_tokens,
                },
                "cost": result.cost,
                "latency_ms": result.latency_ms,
            },
        }

    @staticmethod
    def _extract_prompt(payload: dict[str, Any]) -> str:
        """Extract the prompt from an AgentCore payload.

        Raises ``SynthConfigError`` for malformed payloads.
        """
        if not isinstance(payload, dict):
            raise SynthConfigError(
                message="AgentCore payload must be a dict.",
                component="AgentCoreAdapter",
                suggestion="Check the AgentCore invocation format.",
            )

        # Support common payload shapes
        if "input" in payload:
            inp = payload["input"]
            if isinstance(inp, str):
                return inp
            if isinstance(inp, dict) and "text" in inp:
                return inp["text"]

        if "prompt" in payload:
            return str(payload["prompt"])

        raise SynthConfigError(
            message="AgentCore payload missing 'input' or 'prompt' field.",
            component="AgentCoreAdapter",
            suggestion="Payload must contain 'input' (str or {text: str}) or 'prompt'.",
        )
