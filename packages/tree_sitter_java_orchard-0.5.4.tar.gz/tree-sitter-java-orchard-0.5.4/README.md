# tree-sitter-java-orchard

[![crates][crates]](https://crates.io/crates/tree-sitter-java-orchard)
[![pypi][pypi]](https://pypi.org/project/tree-sitter-java-orchard)
[![npm][npm]](https://www.npmjs.com/package/tree-sitter-java-orchard)

Java grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter).
Forked from https://github.com/tree-sitter/tree-sitter-java to integrate valuable unreviewed PRs.

Contributions are welcome, so are co-maintainers.

[crates]: https://img.shields.io/crates/v/tree-sitter-java-orchard?logo=rust
[pypi]: https://img.shields.io/pypi/v/tree-sitter-java-orchard?logo=pypi&logoColor=ffd242
[npm]: https://img.shields.io/npm/v/tree-sitter-java-orchard?logo=npm
