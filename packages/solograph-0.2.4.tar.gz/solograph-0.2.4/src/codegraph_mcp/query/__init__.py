"""Query helpers for the code graph."""
