"""Output formatters for Solograph (mermaid diagrams, explain)."""
