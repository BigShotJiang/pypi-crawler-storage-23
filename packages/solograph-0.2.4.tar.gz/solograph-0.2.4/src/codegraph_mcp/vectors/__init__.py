"""Vector index for Solograph sessions."""
