"""Allow running as: python -m solograph"""

from .cli import cli

cli()
