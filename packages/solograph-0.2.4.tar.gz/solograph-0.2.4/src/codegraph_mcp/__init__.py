"""Solograph — code intelligence server for Claude Code."""

__version__ = "0.1.0"
