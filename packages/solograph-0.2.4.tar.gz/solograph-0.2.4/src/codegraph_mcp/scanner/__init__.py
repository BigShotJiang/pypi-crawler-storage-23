"""Scanners: extract graph data from projects."""
