"""
Auto-generated types from schemas.

This file enables backward compatibility by exposing all class names
when using `from pymodel.types import *`.

Generated classes:
- AddressType (from address_type)
- ApiKeySecretType (from api_key_secret_type)
- BasicAuthSecretType (from basic_auth_secret_type)
- BearerTokenSecretType (from bearer_token_secret_type)
- BusinessHoursType (from business_hours_type)
- CertificateSecretType (from certificate_secret_type)
- ComputedFieldType (from computed_field_type)
- Condition (from condition)
- ConnectorSourceType (from connector_source_type)
- ConnectorTargetType (from connector_target_type)
- ConnectorTransformType (from connector_transform_type)
- ConnectorTriggerType (from connector_trigger_type)
- CsvFileConfigType (from csv_file_config_type)
- DatabaseConfigType (from database_config_type)
- DatabaseIncrementalType (from database_incremental_type)
- DayHoursType (from day_hours_type)
- DisplayNameMap (from display_name_map)
- DisplayNameMap (from display_name_map)
- EntityRelationship (from entity_relationship)
- FieldMappingType (from field_mapping_type)
- FilterConditionType (from filter_condition_type)
- HttpApiAuthType (from http_api_auth_type)
- HttpApiConfigType (from http_api_config_type)
- HttpApiPaginationType (from http_api_pagination_type)
- HttpApiRateLimitType (from http_api_rate_limit_type)
- HttpApiResponseType (from http_api_response_type)
- HttpApiRetryType (from http_api_retry_type)
- OAuth2SecretType (from oauth2_secret_type)
- PluginCapabilitiesType (from plugin_capabilities_type)
- PluginConfigType (from plugin_config_type)
- Rule (from rule)
- SecretType (from secret_type)
- SessionMetrics (from session_metrics)
- SshKeySecretType (from ssh_key_secret_type)
- StatusWorkflow (from status_workflow)
- WebhookConfigType (from webhook_config_type)
"""

# Import all generated classes
from .address_type import AddressType
from .api_key_secret_type import ApiKeySecretType
from .basic_auth_secret_type import BasicAuthSecretType
from .bearer_token_secret_type import BearerTokenSecretType
from .business_hours_type import BusinessHoursType
from .certificate_secret_type import CertificateSecretType
from .computed_field_type import ComputedFieldType
from .condition import Condition
from .connector_source_type import ConnectorSourceType
from .connector_target_type import ConnectorTargetType
from .connector_transform_type import ConnectorTransformType
from .connector_trigger_type import ConnectorTriggerType
from .csv_file_config_type import CsvFileConfigType
from .database_config_type import DatabaseConfigType
from .database_incremental_type import DatabaseIncrementalType
from .day_hours_type import DayHoursType
from .display_name_map import DisplayNameMap
from .display_name_map import DisplayNameMap
from .entity_relationship import EntityRelationship
from .field_mapping_type import FieldMappingType
from .filter_condition_type import FilterConditionType
from .http_api_auth_type import HttpApiAuthType
from .http_api_config_type import HttpApiConfigType
from .http_api_pagination_type import HttpApiPaginationType
from .http_api_rate_limit_type import HttpApiRateLimitType
from .http_api_response_type import HttpApiResponseType
from .http_api_retry_type import HttpApiRetryType
from .oauth2_secret_type import OAuth2SecretType
from .plugin_capabilities_type import PluginCapabilitiesType
from .plugin_config_type import PluginConfigType
from .rule import Rule
from .secret_type import SecretType
from .session_metrics import SessionMetrics
from .ssh_key_secret_type import SshKeySecretType
from .status_workflow import StatusWorkflow
from .webhook_config_type import WebhookConfigType

# Define __all__ for explicit control of `import *`
__all__ = [
    "AddressType",
    "ApiKeySecretType",
    "BasicAuthSecretType",
    "BearerTokenSecretType",
    "BusinessHoursType",
    "CertificateSecretType",
    "ComputedFieldType",
    "Condition",
    "ConnectorSourceType",
    "ConnectorTargetType",
    "ConnectorTransformType",
    "ConnectorTriggerType",
    "CsvFileConfigType",
    "DatabaseConfigType",
    "DatabaseIncrementalType",
    "DayHoursType",
    "DisplayNameMap",
    "DisplayNameMap",
    "EntityRelationship",
    "FieldMappingType",
    "FilterConditionType",
    "HttpApiAuthType",
    "HttpApiConfigType",
    "HttpApiPaginationType",
    "HttpApiRateLimitType",
    "HttpApiResponseType",
    "HttpApiRetryType",
    "OAuth2SecretType",
    "PluginCapabilitiesType",
    "PluginConfigType",
    "Rule",
    "SecretType",
    "SessionMetrics",
    "SshKeySecretType",
    "StatusWorkflow",
    "WebhookConfigType",
]

# Backward compatibility aliases (if needed)
# Add any legacy name mappings here
