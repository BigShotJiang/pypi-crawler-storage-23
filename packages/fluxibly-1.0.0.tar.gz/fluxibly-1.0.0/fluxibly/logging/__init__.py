"""Structured logging for Fluxibly components."""

from fluxibly.logging.logger import Logger

__all__ = ["Logger"]
