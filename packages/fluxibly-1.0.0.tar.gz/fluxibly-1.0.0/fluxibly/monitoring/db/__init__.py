"""Database layer for monitoring."""
