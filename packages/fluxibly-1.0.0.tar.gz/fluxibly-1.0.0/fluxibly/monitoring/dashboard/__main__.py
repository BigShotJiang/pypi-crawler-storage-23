"""CLI entry point: python -m fluxibly.monitoring.dashboard"""

from __future__ import annotations

import argparse
import sys


def main() -> None:
    # Load .env so MonitoringConfig.from_env() picks up DB settings
    from dotenv import load_dotenv

    load_dotenv()

    parser = argparse.ArgumentParser(
        description="Launch the Fluxibly Monitoring Dashboard.",
    )
    parser.add_argument(
        "--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)"
    )
    parser.add_argument(
        "--port", type=int, default=8555, help="Bind port (default: 8555)"
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable auto-reload for development",
    )
    args = parser.parse_args()

    try:
        import uvicorn  # type: ignore[import-untyped]
    except ImportError:
        print(
            "uvicorn is required to run the monitoring dashboard.\n"
            "Install it with: pip install fluxibly[monitoring]",
            file=sys.stderr,
        )
        sys.exit(1)

    uvicorn.run(
        "fluxibly.monitoring.dashboard.app:create_app",
        factory=True,
        host=args.host,
        port=args.port,
        reload=args.reload,
    )


if __name__ == "__main__":
    main()
