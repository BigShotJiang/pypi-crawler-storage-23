"""Tools module for Fluxibly.

Provides unified tool management across all LLM providers:
- ToolService: Central service for registering, translating, and executing tools
- MCPClientManager: MCP server lifecycle and communication

Tool types supported:
- function: Python callables registered as tools
- mcp: Tools discovered from MCP servers
- web_search: Provider-native web search
- file_search: Provider-native file/vector search
- shell: Shell/code execution
- computer_use: Computer use / browser automation
"""

from fluxibly.tools.executor import ToolService
from fluxibly.tools.handler_loader import find_handler_path, resolve_handler
from fluxibly.tools.mcp_manager import MCPClientManager
from fluxibly.tools.sandbox import (
    SandboxConfig,
    SandboxResult,
    SandboxSession,
    create_shell_tool,
)

__all__ = [
    "MCPClientManager",
    "SandboxConfig",
    "SandboxResult",
    "SandboxSession",
    "ToolService",
    "create_shell_tool",
    "find_handler_path",
    "resolve_handler",
]
