"""LLM module for Fluxibly.

Public API:
- BaseLLM: Abstract base class for custom implementations
- LLMConfig, ReasoningConfig, PricingConfig: Configuration models
- create_llm: Factory function (auto-detects provider from model name)
- register_llm: Register custom LLM providers

Available providers (auto-registered when dependencies are installed):
- openai: OpenAI (Chat + Responses API)
- anthropic: Anthropic Claude (Messages API)
- gemini: Google Gemini (GenerateContent API)
- langchain: LangChain ChatModels (multi-provider)
- litellm: LiteLLM (100+ providers, OpenAI-compatible)
"""

from fluxibly.llm.base import (
    BaseLLM,
    LLMConfig,
    PricingConfig,
    ReasoningConfig,
)
from fluxibly.llm.registry import create_llm, list_providers, register_llm

__all__ = [
    "BaseLLM",
    "LLMConfig",
    "PricingConfig",
    "ReasoningConfig",
    "create_llm",
    "list_providers",
    "register_llm",
]
