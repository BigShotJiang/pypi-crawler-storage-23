"""Fluxibly — Modular Agentic Framework.

Two-layer architecture: LLM (atomic) → Agent (orchestration).
Supports OpenAI, Anthropic, Gemini, LangChain, LiteLLM, and MCP tools.
"""

__version__ = "1.0.0"

# ── Agent Layer ───────────────────────────────────────────────────
from fluxibly.agent import (
    AgentConfig,
    AgentResponse,
    BaseAgent,
    HandoffConfig,
    Runner,
    RunnerResult,
    SimpleAgent,
    create_agent,
    register_agent,
)

# ── Skills ───────────────────────────────────────────────────────
from fluxibly.agent.skills import SkillMetadata, load_skill_metadata

# ── Config ────────────────────────────────────────────────────────
from fluxibly.config import (
    ConfigLoader,
    apply_pricing,
    load_agent_config,
    load_env,
    load_pricing_map,
    load_tool_config,
)

# ── LLM Layer ─────────────────────────────────────────────────────
from fluxibly.llm import (
    BaseLLM,
    LLMConfig,
    PricingConfig,
    ReasoningConfig,
    create_llm,
    register_llm,
)

# ── Logging ───────────────────────────────────────────────────────
from fluxibly.logging import Logger

# ── Monitoring (optional) ────────────────────────────────────
from fluxibly.monitoring import MonitoringConfig

# ── Schema ────────────────────────────────────────────────────────
from fluxibly.schema import (
    Citation,
    ContentItem,
    LLMMetadata,
    LLMOutput,
    LLMResponse,
    TokenUsage,
    ToolCall,
    ToolResult,
)

# ── Tools ─────────────────────────────────────────────────────────
from fluxibly.tools import MCPClientManager, ToolService
from fluxibly.tools.sandbox import SandboxConfig, SandboxSession

__all__ = [
    # LLM
    "BaseLLM",
    "LLMConfig",
    "PricingConfig",
    "ReasoningConfig",
    "create_llm",
    "register_llm",
    # Agent
    "AgentConfig",
    "AgentResponse",
    "BaseAgent",
    "HandoffConfig",
    "Runner",
    "RunnerResult",
    "SimpleAgent",
    "create_agent",
    "register_agent",
    # Skills
    "SkillMetadata",
    "load_skill_metadata",
    # Schema
    "Citation",
    "ContentItem",
    "LLMMetadata",
    "LLMOutput",
    "LLMResponse",
    "TokenUsage",
    "ToolCall",
    "ToolResult",
    # Tools
    "MCPClientManager",
    "SandboxConfig",
    "SandboxSession",
    "ToolService",
    # Config
    "ConfigLoader",
    "apply_pricing",
    "load_agent_config",
    "load_env",
    "load_pricing_map",
    "load_tool_config",
    # Logging
    "Logger",
    # Monitoring
    "MonitoringConfig",
]
