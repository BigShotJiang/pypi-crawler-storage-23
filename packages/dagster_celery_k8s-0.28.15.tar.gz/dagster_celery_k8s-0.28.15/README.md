# dagster-celery-k8s

The docs for `dagster-celery-k8s` can be found
[here](https://docs.dagster.io/integrations/libraries/celery/dagster-celery_k8s).
