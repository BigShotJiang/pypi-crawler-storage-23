# Copyright (c) Meta Platforms, Inc. and affiliates.
"""CPU tests for tritonparse (no GPU required)."""
