#  Copyright (c) Meta Platforms, Inc. and affiliates.

"""Tests for the diff module."""
