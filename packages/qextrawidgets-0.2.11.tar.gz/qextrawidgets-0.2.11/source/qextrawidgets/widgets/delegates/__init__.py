from .grouped_icon_delegate import QGroupedIconDelegate

__all__ = [
    "QGroupedIconDelegate",
]
