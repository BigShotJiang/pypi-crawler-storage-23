
from typing import List
def extract_atom_types(trajectory_file: str) -> List[str]:

    """
    获取.xyz文件第一帧原子类型的列表（保持原始顺序）。

    Args:

        trajectory_file (str): 输入的xyz轨迹文件路径

    Returns:

        element_list (list): 第一个构型中所有原子类型的列表，保持原始顺序

    """
    with open(trajectory_file, 'r', encoding='utf-8') as f:
        n_atoms = int(f.readline().strip())
        f.readline()  # 跳过注释行
        
        types = []
        for _ in range(n_atoms):
            atom_type = f.readline().split()[1] # 假设原子类型在第二列
            if not atom_type.isdigit():  # 过滤数字
                types.append(atom_type)
    
    # 去重但保持顺序
    element_list = []
    seen = set()
    for atom in types:
        if atom not in seen:
            seen.add(atom)
            element_list.append(atom)
    
    return element_list