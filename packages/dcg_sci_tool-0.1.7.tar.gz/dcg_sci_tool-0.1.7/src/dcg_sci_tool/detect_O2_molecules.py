from ovito.data import CutoffNeighborFinder
import numpy as np

def detect_O2_molecules(data,type_names_order):
    """
    识别输入帧的O2分子，输出输入帧中O2分子数量、O2的O原子序号列表、O2分子列表。

    Args:

        data (DataCollection): 结构的ovito数据集合
        
        type_names_order (list): 原子类型名称列表，索引对应原子类型编号

    Returns:

        tuple: O2分子信息

            O2_amount (int): O2分子数量
            
            O2_indexes (list): O2分子中O原子的序号列表

            o2_molecules (list): O2分子列表，每个元素是一个元组，包含两个O原子的序号
                        
    """
    cutoff = 1.5  # O-O键的距离阈值，单位为Å
    particles = data.particles
    if particles is None:
        return [], [], 0
    
    # 获取原子类型  
    types = particles.particle_types[...]
    symbols = np.array([type_names_order[t-1] for t in types])
    
    # 计算邻居列表
    num_atoms = particles.count
    finder = CutoffNeighborFinder(cutoff, data)
    neighbors = {i: [] for i in range(num_atoms)}
    for i in range(num_atoms):
        for neighbor in finder.find(i):
            neighbors[i].append(neighbor.index)
    
    # 识别O₂分子
    counted_O_indices = set()
    o2_molecules = []


    for i in range(num_atoms):
        if symbols[i] != 'O' or i in counted_O_indices:
            continue
        
        bonded_O = [j for j in neighbors[i] if symbols[j] == 'O']
        if len(bonded_O) == 1:
            j = bonded_O[0]
            o2_molecules.append((i, j))
            counted_O_indices.update([i, j])
    
    O2_indexes = [o_index for o2_indexes in o2_molecules for o_index in o2_indexes]
    O2_amount = len(o2_molecules)
    return O2_amount, O2_indexes, o2_molecules