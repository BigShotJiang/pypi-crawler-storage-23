import numpy as np
from ovito.data import CutoffNeighborFinder

def detect_CO_CO2_molecules(data, type_names_order):
    """
    识别当前帧中的CO和CO2分子，返回当前帧中CO和CO2分子的数量，以及构成CO和CO2分子的原子序号列表。

    Args:

        data (DataCollection): 结构的ovito数据集合
        
        type_names_order (list): 原子类型名称列表，索引对应原子类型编号

    Returns:

        tuple: CO和CO2分子信息

            CO_amount (int): CO分子数量

            CO2_amount (int): CO2分子数量

            CO_atoms_indexes (list): CO分子中所有原子的序号列表

            CO2_atoms_indexes (list): CO2分子中所有原子的序号列表

            co_molecules (list): CO分子列表，每个元素是一个元组，包含C原子序号和O原子序号

            co2_molecules (list): CO2分子列表，每个元素是一个元组，包含C原子序号和两个O原子序号
            
    """
    cutoff = 1.5  # C-O成键距离，单位为Å
    particles = data.particles
    if particles is None:
        return 0, 0, [], [], []
    
    # 获取原子类型
    types = particles.particle_types[...]
    symbols = np.array([type_names_order[t-1] for t in types])
    
    # 计算邻居列表
    num_atoms = particles.count
    finder = CutoffNeighborFinder(cutoff, data)
    neighbors = {i: [] for i in range(num_atoms)}
    for i in range(num_atoms):
        for neighbor in finder.find(i):
            neighbors[i].append(neighbor.index)
    
    # 计算当前帧的 CO₂ 和 CO
    CO2_amount = 0
    CO_amount = 0
    CO_atoms_indexes = []
    CO2_atoms_indexes = []
    co_molecules = []  # 存储所有CO分子（C-O对）
    co2_molecules = [] # 存储所有CO2分子（C-O-O三元组）
    
    for i in range(num_atoms):
        if symbols[i] != 'C':
            continue
        
        # 找到与C原子成键的O原子
        bonded_O = [j for j in neighbors[i] if symbols[j] == 'O']
        N_CN_O = len(bonded_O)
        
        if N_CN_O == 2:
            # CO2分子：C原子与2个O原子成键
            CO2_atoms_indexes.extend([i] + bonded_O)# 每个CO2分子第一个原子是C原子，第二、三个原子是O原子
            CO2_amount += 1
            co2_molecules.append((i, bonded_O[0], bonded_O[1])) # 存储CO2分子信息
        elif N_CN_O == 1:
            # CO分子：C原子与1个O原子成键
            CO_atoms_indexes.extend([i] + bonded_O) # 每个CO分子第一个原子是C原子，第二个原子是O原子
            CO_amount += 1
            co_molecules.append((i, bonded_O[0])) # 存储CO分子信息
    
    return CO_amount, CO2_amount, CO_atoms_indexes, CO2_atoms_indexes, co_molecules, co2_molecules