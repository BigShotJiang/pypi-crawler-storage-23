from ovito.data import CutoffNeighborFinder
import numpy as np

def detect_CO_coordinating_to_Pd(data, type_names_order, co_molecules, c_cutoff=3.0, o_cutoff=2.5):
    """
    识别输入帧与Pd配位的CO分子，返回与Pd配位的CO数量、总CO分子数，与Pd配位的CO分子详情列表。

    Args:
        data (DataCollection): 结构的ovito数据集合
        
        type_names_order (list): 原子类型名称列表，索引对应原子类型编号
        
        co_molecules (list): 所有CO分子列表（包含气态），每个元素是一个元组，包含C原子序号和O原子序号
        
        c_cutoff (float): C原子与Pd配位的距离阈值，单位为Å，默认为3.0 Å
        
        o_cutoff (float): O原子与Pd配位的距离阈值，单位为Å，默认为2.5 Å

    Returns:
        tuple: CO分子信息

            co_pd_count (int): 与Pd配位的CO分子数量

            total_co (int): 总CO分子数量

            co_pd_details (list): 与Pd配位的CO分子详情列表，每个元素是一个字典，
                包含'co'键（CO分子的原子序号元组）、'c_pd_neighbors'键（C原子与Pd配位的邻居列表）、
                'o_pd_neighbors'键（O原子与Pd配位的邻居列表）

    """
    particles = data.particles
    if particles is None or not co_molecules:
        return 0, 0, []
    
    types = particles.particle_types[...]
    symbols = np.array([type_names_order[t-1] for t in types])
    
    # 分别计算C原子和O原子使用的邻居列表
    # O原子：使用较短的阈值 (o_cutoff)
    finder_o = CutoffNeighborFinder(o_cutoff, data)
    # C原子：使用较长的阈值 (c_cutoff)
    finder_c = CutoffNeighborFinder(c_cutoff, data)
    
    num_atoms = particles.count
    neighbors_o = {i: [] for i in range(num_atoms)}
    neighbors_c = {i: [] for i in range(num_atoms)}
    
    # 生成邻居列表
    for i in range(num_atoms):
        # O原子阈值邻居列表
        for neighbor in finder_o.find(i):
            neighbors_o[i].append(neighbor.index)
        # C原子阈值邻居列表
        for neighbor in finder_c.find(i):
            neighbors_c[i].append(neighbor.index)
    
    # 计算与Pd配位的CO分子
    co_pd_count = 0
    co_pd_details = []
    
    for c_index, o_index in co_molecules:
        # 检查C原子是否与Pd配位 (使用 c_cutoff)
        c_coordinating_pds = []
        for neighbor_index in neighbors_c[c_index]:
            if symbols[neighbor_index] == 'Pd':
                c_coordinating_pds.append(neighbor_index)
        
        # 检查O原子是否与Pd配位 (使用 o_cutoff)
        o_coordinating_pds = []
        for neighbor_index in neighbors_o[o_index]:
            if symbols[neighbor_index] == 'Pd':
                o_coordinating_pds.append(neighbor_index)
        
        # 如果C或O与Pd配位，则计为与Pd配位的CO分子
        if c_coordinating_pds or o_coordinating_pds:
            co_pd_count += 1
            co_pd_details.append({
                'co': (c_index, o_index),
                'c_pd_neighbors': c_coordinating_pds,
                'o_pd_neighbors': o_coordinating_pds
            })
    
    total_co = len(co_molecules)
    return co_pd_count, total_co, co_pd_details