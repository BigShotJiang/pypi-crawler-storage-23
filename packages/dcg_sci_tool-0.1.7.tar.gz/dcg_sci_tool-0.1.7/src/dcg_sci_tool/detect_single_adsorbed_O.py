from ovito.data import CutoffNeighborFinder
import numpy as np

def detect_single_adsorbed_O(data, type_names_order):
    """
    识别输入帧中单个吸附O原子（没有与C/O成键，与Pd/Au成键的O原子）
    返回与Pd配位的单个吸附O原子数量、单个吸附O原子序号列表。

    Args:
        
        data (DataCollection): 结构的ovito数据集合
        
        type_names_order (list): 原子类型名称列表，索引对应原子类型编号

    Returns:
        tuple: 单个吸附的O原子信息

            single_O_count (int): 与Pd/Au配位的单个吸附O原子数量
            
            single_O_indices (list): 与Pd/Au配位的单个吸附O原子序号列表

    """
    # 定义不同原子对的键长阈值
    cutoff_C = 1.5  # O-C键长阈值
    cutoff_O = 1.5  # O-O键长阈值
    cutoff_Au = 2.5  # O-Au键长阈值
    cutoff_Pd = 2.5  # O-Pd键长阈值
    
    particles = data.particles
    if particles is None:
        return 0, []
    
    types = particles.particle_types[...]
    symbols = np.array([type_names_order[t-1] for t in types])

    # 创建不同原子对的邻居查找器
    finder_C = CutoffNeighborFinder(cutoff_C, data)  # 查找C邻居
    finder_O = CutoffNeighborFinder(cutoff_O, data)  # 查找O邻居
    finder_Au = CutoffNeighborFinder(cutoff_Au, data)  # 查找Au邻居
    finder_Pd = CutoffNeighborFinder(cutoff_Pd, data)  # 查找Pd邻居
    
    num_atoms = particles.count
    single_O_indices = []
    
    for i in range(num_atoms):
        if symbols[i] != 'O':
            continue
        
        # 条件1：检查是否与C原子成键
        has_bonded_C = False
        for neighbor in finder_C.find(i):
            if symbols[neighbor.index] == 'C':
                has_bonded_C = True
                break
        
        if has_bonded_C:
            continue  # 与C成键，不符合条件
        
        # 条件2：检查是否与其他O原子成键
        has_bonded_O = False
        for neighbor in finder_O.find(i):
            if symbols[neighbor.index] == 'O':
                has_bonded_O = True
                break
        
        if has_bonded_O:
            continue  # 与O成键，不符合条件
        
        # 条件3：检查是否与Pd或Au成键
        has_bonded_Pd_Au = False
        
        # 检查与Pd成键
        for neighbor in finder_Pd.find(i):
            if symbols[neighbor.index] == 'Pd':
                has_bonded_Pd_Au = True
                break
        
        # 如果还没有找到与Pd/Au成键，检查与Au成键
        if not has_bonded_Pd_Au:
            for neighbor in finder_Au.find(i):
                if symbols[neighbor.index] == 'Au':
                    has_bonded_Pd_Au = True
                    break
        
        if has_bonded_Pd_Au:
            single_O_indices.append(i)
    
    N_single_O = len(single_O_indices)
    return N_single_O, single_O_indices