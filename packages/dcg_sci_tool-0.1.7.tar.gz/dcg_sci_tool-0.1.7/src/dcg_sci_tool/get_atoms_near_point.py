from ovito.data import DataCollection
import numpy as np


def get_atoms_near_point(data: DataCollection, point: np.ndarray, cutoff: float = 5.0):
    """

    获取距离指定点cutoff范围内的所有原子序号
    
    Args:
        
        data (DataCollection): 结构的ovito数据集合
        
        point (np.ndarray): 指定点坐标
        
        cutoff (float): 截断距离（默认5Å）
    
    Returns:
    
        atoms_within_cutoff (list): 在截断距离内的原子序号列表

    """
    
    # 获取粒子位置
    positions = data.particles.positions[...]
    
    if point.shape != (3,):
        print(f"错误: 指定点坐标维度不正确。期望(3,)，实际{point.shape}")
        return []
    
    # 计算所有原子到指定点的距离
    distances = np.linalg.norm(positions - point, axis=1)
    
    # 找出在截断距离内的原子序号
    atoms_within_cutoff = np.where(distances <= cutoff)[0].tolist()
    
    # 输出信息
    print(f"指定点坐标: {point}")
    print(f"截断距离: {cutoff} Å")
    print(f"指定点周围{cutoff}Å范围内的原子数: {len(atoms_within_cutoff)}")
    print(f"这些原子的序号: {atoms_within_cutoff}")
    
    return atoms_within_cutoff