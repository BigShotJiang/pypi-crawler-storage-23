from dcg_sci_tool import *

def get_reaction_local_structure(data, type_names_order,c_index, o_index, cutoff=6.0):
    """
    获取反应局部结构：以目标C和O原子连线中点为中心，cutoff范围内的所有原子（排除气态分子原子），
    并且如果吸附态CO分子有一个原子在范围内，则添加另一个原子。返回满足条件的原子索引列表。

    Args:
        data (DataCollection): 结构的ovito数据集合
        
        type_names_order (list): 原子类型名称列表，索引对应原子类型编号

        c_index (int): 目标C原子索引

        o_index (int): 目标O原子索引

        cutoff (float): 以C-O连线中点为中心的范围，单位为Å，默认为6.0 Å

    Returns:
        
        final_atom_list (list): 满足条件的原子索引列表
    """ 
    # 2. 检测所有分子类型
    CO_amount, CO2_amount, CO_atoms_indexes, CO2_atoms_indexes, co_molecules, co2_molecules = detect_CO_CO2_molecules(data, type_names_order)
    co_pd_count, total_co, co_pd_details = detect_CO_coordinating_to_Pd(data, type_names_order, co_molecules)

    # 3. 识别气态分子原子
    gases_atoms = identify_gas_molecules_to_delete(data, type_names_order)

    # 4. 识别吸附态CO分子
    # 找出所有吸附态CO分子的原子
    adsorbed_CO_atoms = set()
    for detail in co_pd_details:
        c_idx, o_idx = detail['co']
        adsorbed_CO_atoms.update([c_idx, o_idx])


    # 5. 获取距离目标C和O连线中点6Å范围内的原子

    positions = data.particles.positions[...]

    # 假设前两个是目标C和O原子
    C_coord = positions[c_index]
    O_coord = positions[o_index]

    # 计算连线中点坐标
    midpoint = (C_coord + O_coord) / 2.0

    # 获取距离中点6Å范围内的所有原子
    nearby_atoms = get_atoms_near_point(data, midpoint, cutoff)

    # 6. 排除气态分子原子
    nearby_atoms_without_gases = []
    for i in nearby_atoms:
        if i not in gases_atoms:
            nearby_atoms_without_gases.append(i)

    # 7. 处理吸附态CO分子：如果吸附态CO的一个原子在范围内，则添加另一个原子
    # 创建吸附态CO的配对字典
    co_pairs_dict = {}  # 键为C原子索引，值为对应的O原子索引；键为O原子索引，值为对应的C原子索引
    for c_idx, o_idx in co_molecules:
        if c_idx in adsorbed_CO_atoms:  # 只处理吸附态CO
            co_pairs_dict[c_idx] = o_idx
            co_pairs_dict[o_idx] = c_idx

    # 添加缺失的吸附态CO原子
    final_atom_list = set(nearby_atoms_without_gases)  # 使用集合避免重复

    for atom_idx in nearby_atoms_without_gases:
        if atom_idx in co_pairs_dict:
            # 这个原子属于吸附态CO，找到它的配对原子
            partner_idx = co_pairs_dict[atom_idx]
            # 如果配对原子不在当前列表中，添加它
            if partner_idx not in final_atom_list and partner_idx not in gases_atoms:
                final_atom_list.add(partner_idx)

    # 转换为列表并排序
    final_atom_list = sorted(list(final_atom_list))
    return final_atom_list