# dcg-sci-tool

Scientific computing tools for data analysis.

## 安装 

`pip install dcg-sci-tool`

或指定从官方镜像源安装

`pip install dcg-sci-tool -i https://pypi.org/simple`

## 迭代与发布

### 本地调测

#### from project root
`pip install -e .`  解释参见：`docs/可编辑模式调测.md`

#### or, build & install

```shell
python -m build
## 注意：需要手动删除上一次构建产物

pip install dist/dcg_sci_tool-0.x.x-py3-none-any.whl
```

### 准备发布密钥

将 `PyPI` 发布密钥到 `C:/Users/yourusername/.pypirc`，格式如下：

```toml
[pypi]
  username = __token__
  password = pypi-xxxxxxx
```

### 发布
`twine upload dist/*`