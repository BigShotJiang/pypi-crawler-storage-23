# Changelog

## [0.1.7] - 2026-03-01

### Added
- 新增 `identify_gas_molecules_to_delete` 方法
- 新增 `get_reaction_local_structure` 方法

### Changed
- 规范化各个库函数的解释文本

## [0.1.6] - 2026-03-01

### Added
- 新增 `detect_single_adsorbed_O` 方法


## [0.1.5] - 2026-02-28

### Added
- 新增 `detect_CO_coordinating_to_Pd` 方法

### Changed
- 恢复各函数返回分子元组的功能


## [0.1.4] - 2026-02-28

### Changed
- 删除相关函数冗余入参frame

## [0.1.3] - 2026-02-25

### Fixed
- 修复导出问题

## [0.1.2] - 2026-02-25

### Added
- 新增 `detect_O2_molecules` 方法
- 新增 `detect_CO_CO2_molecules` 方法

## [0.1.1] - 2026-02-24

### Added
- 新增 `extract_atom_types` 方法
- 新增 `sum_to_n` 方法