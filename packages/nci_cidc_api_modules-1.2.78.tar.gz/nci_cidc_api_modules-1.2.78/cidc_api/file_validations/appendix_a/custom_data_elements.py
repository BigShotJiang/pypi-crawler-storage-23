# Acceptance Criteria
# - https://bioappdev.atlassian.net/browse/CIDC-2368
# - https://bioappdev.atlassian.net/browse/CIDC-3492


from cidc_api.models import TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER
from cidc_api.shared.file_handling import get_column_from_appendix_a, get_column_from_first_row
from cidc_api.telemetry import trace_

# pylint: disable=line-too-long, unnecessary-lambda


# In the "Custom Data Elements" tab of the Appendix A file, "Data Category" must be filled out for all rows.
def validate_category(df, _meta):
    category_column = get_column_from_first_row(df, TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER)
    empty_categories = df.loc[df[category_column] == "", category_column]

    errors = []

    if empty_categories.size > 0:
        row_numbers = [n + 1 for n in list(empty_categories.index)]
        errors = [{"error": "Missing Data Category value(s)", "value": {"row_numbers": row_numbers}}]

    return {"errors": errors, "meta": {}}


def validate_cardinality(df, meta):
    cardinality_column_name = "Cardinality"

    # skip validation if cardinality_column_name is missing
    if cardinality_column_name not in df.columns:
        return {
            "errors": [{"error": f"{cardinality_column_name} column is missing; skipping cardinality validation"}],
            "meta": meta,
        }

    category_column = get_column_from_first_row(df, TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER)
    cardinality_column = get_column_from_first_row(df, cardinality_column_name)
    cardinality_by_category = (
        df.iloc[1:].groupby(category_column, as_index=False)[cardinality_column].aggregate(to_set_)
    )
    meta = {**meta, "custom_categories": [], "not_custom_categories": []}

    errors = []

    for category, cardinalities in cardinality_by_category.itertuples(index=False):
        if not category:
            continue

        # When a row in the "Custom Data Elements" tab specifies a custom Data Category, the value for "Cardinality" must be the same for all rows of that Data Category.
        # For example, lesion cannot have one row that says "One row per participant" and another row that says "Multiple rows per participant".
        # Cardinalities do not match for [Data Category] [cell: one per participant] [cell: multiple per participant].
        if len(cardinalities) > 1:
            errors.append(
                {
                    "error": "Cardinalities do not match for category",
                    "value": {"category": category, "cardinalities": sorted(list(cardinalities), key=lambda x: str(x))},
                }
            )

        # Standard Data Category: Cardinality must be blank for categories that are both in appendix A and the Custom Data Elements tab.
        if category in meta["categories"]:
            meta["not_custom_categories"].append(category)

            if cardinalities != {""}:
                errors.append(
                    {
                        "error": "Cardinality must be blank for categories that are both in appendix A and the Custom Data Elements tab",
                        "value": {
                            "category": category,
                            "cardinalities": sorted(list(cardinalities), key=lambda x: str(x)),
                        },
                    }
                )

        # Non-standard Data Category: Cardinality must be present for categories that are not in appendix A tab.
        if category not in meta["categories"]:
            meta["custom_categories"].append(category)

            if cardinalities == {""}:
                errors.append(
                    {
                        "error": "Cardinality must be present for categories that are not in Appendix A tab",
                        "value": {"category": category, "cardinalities": []},
                    }
                )

    return {"errors": errors, "meta": meta}


# participant_id must be a field specified in each custom Data Category.
def validate_participant_id(df, meta):
    data_element_column_name = "Data Element"

    # skip validation if data_element_column_name is missing
    if data_element_column_name not in df.columns:
        return {
            "errors": [{"error": f"{data_element_column_name} column is missing; skipping participant_id validation"}],
            "meta": meta,
        }

    category_column = get_column_from_first_row(df, TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER)
    element_column = get_column_from_first_row(df, data_element_column_name)

    errors = []

    for category in meta["custom_categories"]:
        condition = (df[category_column] == category) & (df[element_column] == "participant_id")
        row_with_participant_id_element = df.loc[condition]

        if row_with_participant_id_element.empty:
            errors.append(
                {
                    "error": "participant_id must be a field specified in each custom Data Category",
                    "value": {"category": category},
                }
            )

    return {"errors": errors, "meta": meta}


# Any specified Custom Data Element must not be the same as any Data Element already known to the system in the same Data Category.
# For example, height could not be a Custom Data Element name in the demographic Data Category, but marital_status could.
def validate_element(df, meta):
    data_element_column_name = "Data Element"

    # skip validation if data_element_column_name is missing
    if data_element_column_name not in df.columns:
        return {
            "errors": [{"error": f"{data_element_column_name} column is missing; skipping elements validation"}],
            "meta": meta,
        }

    category_column = get_column_from_first_row(df, TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER)
    element_column = get_column_from_first_row(df, data_element_column_name)
    my_elements_by_category = df.groupby(category_column, as_index=False)[element_column].aggregate(to_set_)

    errors = []

    for my_category, my_elements in my_elements_by_category.itertuples(index=False):
        if known_elements := meta["elements_by_category"].get(my_category):
            if known_elements != {""} and (duplicate_elements := known_elements.intersection(my_elements)):
                errors.append(
                    {
                        "error": "Custom Data Elements are already known in their category",
                        "value": {"category": my_category, "elements": list(duplicate_elements)},
                    }
                )

    return {"errors": errors, "meta": meta}


# Data Type column should have all values set to string or number
def validate_types(df, meta):
    type_column_name = "Data Type"

    # skip validation if type_column_name is missing
    if type_column_name not in df.columns:
        return {"errors": [{"error": f"{type_column_name} column is missing; skipping types validation"}], "meta": meta}

    allowed_types = ["string", "number"]
    errors = []

    rows_with_invalid_type = df[~df[type_column_name].isin(allowed_types)]
    if not rows_with_invalid_type.empty:
        rows_numbers = [n + 1 for n in list(rows_with_invalid_type.index)]
        invalid_types = list(rows_with_invalid_type[type_column_name].unique())

        errors = [
            {
                "error": f"Invalid types found in {type_column_name} column; only {allowed_types} are accepted",
                "value": {"row_numbers": rows_numbers, "invalid_types": invalid_types},
            }
        ]

    return {"errors": errors, "meta": meta}


def get_rows_after_condition(df, condition):
    condition_met_index = df[condition].index[0]
    rows_afer_condition_df = df.iloc[condition_met_index + 1 :]

    return rows_afer_condition_df


def get_categories(appendix_a_df):
    category_column = appendix_a_df.columns[0]
    condition = appendix_a_df[category_column] == TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER
    categories = get_rows_after_condition(appendix_a_df, condition)

    return sorted(list(categories[category_column].unique()))


def get_elements_by_category(appendix_a_df):
    category_column = appendix_a_df.columns[0]
    element_column = get_column_from_appendix_a(appendix_a_df, "Data Element")
    condition = appendix_a_df[category_column] == TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER
    categories = get_rows_after_condition(appendix_a_df, condition)
    elements_by_category = categories.groupby(category_column, as_index=False)[element_column].aggregate(to_set_)

    return dict(zip(elements_by_category[category_column], elements_by_category[element_column]))


def to_set_(x):
    return set(x)


@trace_()
def validate(custom_element_df, appendix_a_df):
    # skip if empty or have only one row
    if custom_element_df.empty or custom_element_df.shape[0] == 1:
        return {"errors": [], "meta": {}}

    custom_element_df.fillna("", inplace=True)
    categories = get_categories(appendix_a_df)
    elements_by_category = get_elements_by_category(appendix_a_df)
    meta = {"elements_by_category": elements_by_category, "categories": categories}

    errors = []

    for validate_ in [
        validate_category,
        validate_cardinality,
        validate_participant_id,
        validate_element,
        validate_types,
    ]:
        result = validate_(custom_element_df, meta)
        meta = {**meta, **result["meta"]}
        errors.extend(result["errors"])

    return {"errors": errors, "meta": meta}
