Fleche Documentation
====================

Welcome to the **Fleche** library documentation.

* **What is Fleche?**  A lightweight library for ... (provide brief description).
* **Key features** – …
* **Get started** – see the :doc:`installation`.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   helpers
   lazy_call
   digests_as_args
   custom_digests
   configuration
   query

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
