# fleche

fleche is a persistant caching solution for arbitrary python functions.

flèche is French for 'arrow' and also used in fencing as a fast attack.
