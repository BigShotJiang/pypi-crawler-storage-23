import time

import pytest

from fleche import fleche, cache, tags, project, metadata
from fleche.caches import Cache
from fleche.metadata import MetaData, Call
from fleche.storage import Memory


@pytest.fixture
def cache_it() -> Cache:
    values_storage = Memory({})
    calls_storage = Memory({})
    return Cache(values_storage, calls_storage)


def test_fleche_decorator_default_metadata(cache_it: Cache):
    @fleche
    def my_function(a: int, b: int) -> int:
        return a + b

    with cache(cache_it):
        my_function(1, 2)
        time.sleep(0.1)
        my_function(1, 2)  # cache hit, no new entry

        key = my_function.digest(1, 2)
        call = cache().calls.load(key)

    assert "runtime" in call.metadata
    assert call.metadata["runtime"]["walltime"] < 0.1


def test_fleche_decorator_custom_metadata(cache_it: Cache):
    class MyMetadata(MetaData):
        name = "my_meta"
        keys = {"my_key": str}

        def pre(self, call: Call):
            return {"my_key": "my_value"}

    @fleche(meta=(MyMetadata(),))
    def my_function(a: int, b: int) -> int:
        return a + b

    with cache(cache_it):
        my_function(1, 2)
        key = my_function.digest(1, 2)
        call = cache().calls.load(key)

    assert call.metadata.get("my_meta", {}).get("my_key") == "my_value"


def test_metadata_context_manager(cache_it: Cache):
    class MyMetadata(MetaData):
        name = "my_meta"
        keys = {"my_key": str}

        def pre(self, call: Call):
            return {"my_key": "my_value"}

    @fleche
    def my_function(a: int, b: int) -> int:
        return a + b

    with cache(cache_it):
        with metadata(MyMetadata()):
            my_function(1, 2)
        key = my_function.digest(1, 2)
        call = cache().calls.load(key)

    assert call.metadata.get("my_meta", {}).get("my_key") == "my_value"


def test_metadata_context_manager_stacking(cache_it: Cache):
    class MyMetadata1(MetaData):
        name = "my_meta1"
        keys = {"my_key1": str}

        def pre(self, call: Call):
            return {"my_key1": "my_value1"}

    class MyMetadata2(MetaData):
        name = "my_meta2"
        keys = {"my_key2": str}

        def pre(self, call: Call):
            return {"my_key2": "my_value2"}

    @fleche
    def my_function(a: int, b: int) -> int:
        return a + b

    with cache(cache_it):
        with metadata(MyMetadata1()):
            with metadata(MyMetadata2(), stack=True):
                my_function(1, 2)
        key = my_function.digest(1, 2)
        call = cache().calls.load(key)

    assert call.metadata.get("my_meta1", {}).get("my_key1") == "my_value1"
    assert call.metadata.get("my_meta2", {}).get("my_key2") == "my_value2"


def test_metadb_table_filtering(cache_it: Cache):
    class MyMetadata(MetaData):
        name = "my_meta"
        keys = {"my_key": str, "my_other_key": int}

        def pre(self, call: Call):
            if call.arguments.get("b") == 2:
                return {"my_key": "my_value", "my_other_key": 1}
            return {"my_key": "another_value", "my_other_key": 2}

    @fleche(meta=(MyMetadata(),))
    def my_function(a: int, b: int) -> int:
        return a + b

    with cache(cache_it):
        my_function(a=1, b=2)
        my_function(a=2, b=3)

        key1 = my_function.digest(a=1, b=2)
        key2 = my_function.digest(a=2, b=3)
        call1 = cache().calls.load(key1)
        call2 = cache().calls.load(key2)

    assert call1.metadata["my_meta"]["my_key"] in {"my_value", "another_value"}
    assert call2.metadata["my_meta"]["my_key"] in {"my_value", "another_value"}
    # Verify the conditional split
    assert call1.metadata["my_meta"]["my_key"] == "my_value"
    assert call2.metadata["my_meta"]["my_other_key"] == 2


def test_fleche_decorator_and_context_manager(cache_it: Cache):
    class MyMetadata1(MetaData):
        name = "my_meta1"
        keys = {"my_key1": str}

        def pre(self, call: Call):
            return {"my_key1": "my_value1"}

    class MyMetadata2(MetaData):
        name = "my_meta2"
        keys = {"my_key2": str}

        def pre(self, call: Call):
            return {"my_key2": "my_value2"}

    @fleche(meta=(MyMetadata1(),))
    def my_function(a: int, b: int) -> int:
        return a + b

    with cache(cache_it):
        with metadata(MyMetadata2()):
            my_function(1, 2)
        key = my_function.digest(1, 2)
        call = cache().calls.load(key)

    assert call.metadata.get("my_meta1", {}).get("my_key1") == "my_value1"
    assert call.metadata.get("my_meta2", {}).get("my_key2") == "my_value2"


def test_tags():
    values_storage = Memory({})
    calls_storage = Memory({})

    with cache(Cache(values_storage, calls_storage)):

        @fleche
        def my_func(a, b):
            return a + b

        with tags(user="test", project="fleche"):
            my_func(1, 2)
            key1 = my_func.digest(1, 2)
            call1 = cache().calls.load(key1)
            assert call1.metadata.get("tags", {}).get("user") == "test"
            assert call1.metadata.get("tags", {}).get("project") == "fleche"

        with project("example"):
            my_func(2, 1)
            key2 = my_func.digest(2, 1)
            call2 = cache().calls.load(key2)
            assert call2.metadata.get("tags", {}).get("project") == "example"
