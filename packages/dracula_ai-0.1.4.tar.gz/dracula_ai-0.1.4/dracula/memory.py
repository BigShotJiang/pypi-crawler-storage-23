class Memory:
    def __init__(self, max_messages: int = 10):
        self.history = []
        self.max_messages = max_messages

    def add_message(self, role: str, content: str):
        self.history.append({"role": role, "content": content})

        if len(self.history) > self.max_messages:
            self.history.pop(0)

    def get_history(self):
        return self.history

    def clear(self):
        self.history = []
