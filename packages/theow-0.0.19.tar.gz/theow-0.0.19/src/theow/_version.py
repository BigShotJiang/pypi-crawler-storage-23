"""Version information for theow."""

__version__ = "0.0.19"  # x-release-please-version
