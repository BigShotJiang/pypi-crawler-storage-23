import json
from dataclasses import dataclass, field
from datetime import datetime, timezone

from googleapiclient.discovery import build

from .config import get_creds
from .constants import (
    DEFAULT_TASKLIST_ID,
    TASK_CACHE_DIR,
    TASKLIST_CACHE,
)

# ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
# ┃                       Exceptions                         ┃
# ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


class TaskListNotFound(Exception):
    pass


# ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
# ┃                          Types                           ┃
# ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


@dataclass
class TaskGet:
    tasklist_id: str = DEFAULT_TASKLIST_ID


@dataclass
class TaskAdd:
    title: str
    tasklist_id: str = DEFAULT_TASKLIST_ID

    def to_body(self) -> dict[str, str]:
        return {'title': self.title}


@dataclass
class TaskDone:
    task_id: str
    tasklist_id: str = DEFAULT_TASKLIST_ID
    status: str = 'completed'
    completed: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_body(self) -> dict[str, str]:
        return {'status': self.status, 'completed': self.completed}


@dataclass
class TaskClear:
    tasklist_id: str = DEFAULT_TASKLIST_ID


class Service:
    def __init__(self):
        self.service = get_service()

    def get_tasklist(self, from_cache: bool = False):
        if not from_cache or not TASKLIST_CACHE.exists():
            result = self.service.tasklists().list().execute()
            TASKLIST_CACHE.parent.mkdir(parents=True, exist_ok=True)
            with open(TASKLIST_CACHE, 'w') as file:
                json.dump(result, file)
            return result

        with open(TASKLIST_CACHE) as file:
            return json.load(file)

    def get_tasklist_by_title(
        self, list_name: str, from_cache: bool = False
    ) -> dict[str, str]:
        results = self.get_tasklist(from_cache=from_cache)
        items = results.get('items', [])
        items = [item for item in items if item.get('title') == list_name]
        if not items:
            raise TaskListNotFound
        return items[0]

    def get_tasklist_id_by_title(self, list_name: str, from_cache: bool = False) -> str:
        return self.get_tasklist_by_title(list_name, from_cache=from_cache)['id']

    def get_tasklist_title_by_id(self, tasklist_id: str) -> str:
        results = self.get_tasklist(from_cache=True)
        items = results.get('items', [])
        items = [item for item in items if item.get('id') == tasklist_id]
        if not items:
            raise TaskListNotFound
        return items[0]['title']

    def get_tasks(self, task_options: TaskGet, from_cache=False):
        task_cache_file = TASK_CACHE_DIR / (task_options.tasklist_id + '.json')
        if not from_cache or not task_cache_file.exists():
            results = (
                self.service.tasks()
                .list(tasklist=task_options.tasklist_id, showHidden=False)
                .execute()
            )
            task_cache_file.parent.mkdir(parents=True, exist_ok=True)
            with open(task_cache_file, 'w') as file:
                json.dump(results, file)
            return results['items']

        with open(task_cache_file) as file:
            return json.load(file)['items']

    def add_task(
        self,
        task_options: TaskAdd,
    ):
        self.service.tasks().insert(
            tasklist=task_options.tasklist_id, body=task_options.to_body()
        ).execute()

    def done_task(self, task_options: TaskDone):
        response = (
            self.service.tasks()
            .patch(
                tasklist=task_options.tasklist_id,
                task=task_options.task_id,
                body=task_options.to_body(),
            )
            .execute()
        )

    def clear_task(self, task_options: TaskClear):
        self.service.tasks().clear(
            tasklist=task_options.tasklist_id,
        ).execute()


# ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
# ┃                        Functions                         ┃
# ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


def get_service():
    return build("tasks", "v1", credentials=get_creds())
