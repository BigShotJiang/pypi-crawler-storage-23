from platformdirs import PlatformDirs

APP_NAME = 'gtask-cli'
APP_AUTHOR = 'Jobin Nelson'
dirs = PlatformDirs(APP_NAME, APP_AUTHOR)

TOKEN_FILE = dirs.user_data_path / 'token.json'
CREDS_FILE = dirs.user_config_path / 'credentials.json'
TASKLIST_CACHE = dirs.user_cache_path / 'tasklist.json'
TASK_CACHE_DIR = dirs.user_cache_path
DEFAULT_TASKLIST_ID = '@default'
DONE_STATUS = 'completed'

# If modifying these scopes, delete the file token.json.
SCOPES = ["https://www.googleapis.com/auth/tasks.readonly", "https://www.googleapis.com/auth/tasks"]
