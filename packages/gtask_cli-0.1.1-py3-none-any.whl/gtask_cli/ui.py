from .constants import DONE_STATUS


def print_tasks(tasks: list, all: bool = False):
    for i, task in enumerate(tasks, start=1):
        if all or task['status'] != DONE_STATUS:
            print(f'{i}. {task['title']}')

def print_tasklists(tasklists: list):
    for tasklist in tasklists['items']:
        print(f'- {tasklist['title']} ${tasklist["id"]}')
