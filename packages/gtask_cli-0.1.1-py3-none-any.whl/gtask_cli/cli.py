import argparse

from .controller import add_task, clear_task, done_task, get_task

# ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
# ┃                       Validators                         ┃
# ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


def positive_int(value: str) -> int:
    try:
        ivalue = int(value)
    except ValueError as e:
        raise argparse.ArgumentTypeError(f"{value} is not an integer") from e

    if ivalue <= 0:
        raise argparse.ArgumentTypeError(f"{value} is not a positive integer")

    return ivalue


# ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
# ┃                         Parser                           ┃
# ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


def get_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description='CLI for Google Task',
    )
    subparser = parser.add_subparsers(required=True)

    # Get subcommand
    get_task_parser = subparser.add_parser('get', help='List Tasks')
    get_task_parser.add_argument(
        '-o',
        '--output',
        help='Output Format',
    )
    get_task_parser.add_argument(
        '-l',
        '--tasklist',
        help='List task from the tasklist',
    )
    get_task_parser.add_argument(
        '-a',
        '--all',
        action='store_true',
        help='List all task from the tasklist',
    )
    get_task_parser.set_defaults(func=get_task)

    # Add subcommand
    add_task_parser = subparser.add_parser('add')
    add_task_parser.add_argument('title', help='Title of task')
    add_task_parser.add_argument(
        '-l',
        '--tasklist',
        help='Add task to the list specified',
    )
    add_task_parser.set_defaults(func=add_task)

    # Done subcommand
    done_task_parser = subparser.add_parser('done')
    done_task_parser.add_argument(
        'position',
        type=positive_int,
        help='Position of the task',
    )
    done_task_parser.add_argument(
        '-l',
        '--tasklist',
        help='complete task from the list specified',
    )
    done_task_parser.set_defaults(func=done_task)

    # clear subcommand
    clear_task_parser = subparser.add_parser('clear')
    clear_task_parser.add_argument(
        '-l',
        '--tasklist',
        help='complete task from the list specified',
    )
    clear_task_parser.set_defaults(func=clear_task)

    return parser
