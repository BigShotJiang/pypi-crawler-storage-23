from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow

from .constants import CREDS_FILE, SCOPES, TOKEN_FILE


def get_creds_from_token() -> Credentials | None:
    # The file token.json stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if TOKEN_FILE.exists():
        return Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)
    return None


def refresh_token(creds: Credentials | None) -> Credentials:
    # If there are no (valid) credentials available, let the user log in.
    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    else:
        flow = InstalledAppFlow.from_client_secrets_file(CREDS_FILE, SCOPES)
        creds = flow.run_local_server(port=0)
    assert creds
    # Save the credentials for the next run
    TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(TOKEN_FILE, "w") as token:
        token.write(creds.to_json())
    return creds


def get_creds():
    creds = get_creds_from_token()
    if not creds or not creds.valid:
        creds = refresh_token(creds)
    return creds
