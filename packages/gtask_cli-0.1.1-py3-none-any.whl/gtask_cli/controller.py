import argparse
import sys

from gtask_cli.constants import DEFAULT_TASKLIST_ID

from .service import Service, TaskAdd, TaskClear, TaskDone, TaskGet
from .ui import print_tasks

# ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
# ┃                    Helper Functions                      ┃
# ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


def get_tasklist_id(
    service: Service,
    tasklist: str | None,
) -> str:
    return (
        service.get_tasklist_id_by_title(tasklist) if tasklist else DEFAULT_TASKLIST_ID
    )


# ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
# ┃                   Core Implementation                    ┃
# ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


def get_task(args: argparse.ArgumentParser):
    service = Service()
    tasklist_id = get_tasklist_id(service, args.tasklist)
    task_options = TaskGet(tasklist_id)
    tasks = service.get_tasks(task_options)
    print_tasks(tasks, args.all)


def add_task(args: argparse.ArgumentParser):
    service = Service()
    tasklist_id = get_tasklist_id(service, args.tasklist)
    task_add_options = TaskAdd(args.title, tasklist_id)
    service.add_task(task_add_options)


def done_task(args: argparse.ArgumentParser):
    service = Service()
    tasklist_id = get_tasklist_id(service, args.tasklist)
    task_get_options = TaskGet(tasklist_id)
    tasks = service.get_tasks(task_get_options, from_cache=True)
    if args.position > len(tasks):
        tasklist_title = service.get_tasklist_title_by_id(tasklist_id)
        print(
            f'No task in position {args.position} of tasklist {tasklist_title}',
            file=sys.stderr,
        )
        return
    task = tasks[args.position - 1]
    task_done_options = TaskDone(task['id'], tasklist_id)
    service.done_task(task_done_options)


def clear_task(args: argparse.ArgumentParser):
    service = Service()
    tasklist_id = get_tasklist_id(service, args.tasklist)
    task_clear_options = TaskClear(tasklist_id)
    service.clear_task(task_clear_options)
