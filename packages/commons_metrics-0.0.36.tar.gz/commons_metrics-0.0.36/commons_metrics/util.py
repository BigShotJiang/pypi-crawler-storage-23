import boto3
import json

class Util:
    """Utility class for common operations"""
    
    @staticmethod
    def get_secret_aws(secret_name: str, logger, region_name: str):
        """Retrieves a secret from AWS Secrets Manager"""
        try:
            session = boto3.session.Session()
            client = session.client(
                service_name='secretsmanager',
                region_name=region_name
            )

            get_secret_value_response = client.get_secret_value(SecretId=secret_name)
            secret_string = get_secret_value_response['SecretString']
            secret_json = json.loads(secret_string)

            return secret_json

        except Exception as e:
            msg = f"Error getting the secret '{secret_name}': {str(e)}"
            logger.error(msg)
            raise Exception(msg)


