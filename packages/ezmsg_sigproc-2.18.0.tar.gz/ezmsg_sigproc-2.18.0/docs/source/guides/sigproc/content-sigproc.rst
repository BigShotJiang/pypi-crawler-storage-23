ezmsg-sigproc
===============

.. toctree::
    :maxdepth: 1

    architecture
    ../explanations/sigproc
    ../explanations/array_api
