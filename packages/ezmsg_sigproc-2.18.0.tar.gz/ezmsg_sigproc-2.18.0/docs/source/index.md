```{include} ../../README.md
```

```{toctree}
:maxdepth: 2
:caption: Contents:

guides/sigproc/content-sigproc
guides/tutorials/signalprocessing
guides/HybridBuffer
api/index
```

## Indices and tables

- {ref}`genindex`
- {ref}`modindex`
