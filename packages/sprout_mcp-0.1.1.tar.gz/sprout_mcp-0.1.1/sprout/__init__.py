"""Sprout — Model-tiered research MCP server."""
