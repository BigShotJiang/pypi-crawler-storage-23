#!/usr/bin/env python3
"""Legacy AIS multi-date exploratory script placeholder."""

import pytest

pytest.skip(
    "Legacy exploratory AIS script; excluded from automated unit test runs.",
    allow_module_level=True,
)

