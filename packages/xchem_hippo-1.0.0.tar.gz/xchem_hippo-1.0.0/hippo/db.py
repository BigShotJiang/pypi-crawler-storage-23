"""SQLite database wrapper class"""

import mcol
import mrich

import json
import time
import sqlite3
from pathlib import Path
from pprint import pprint
from sqlite3 import Error

from .pose import Pose
from .quote import Quote
from .target import Target
from .feature import Feature
from .compound import Compound
from .reaction import Reaction
from .metadata import MetaData
from .recipe import Recipe, Route
from .tools import inchikey_from_smiles, sanitise_smiles, SanitisationError, strip_sql


class Database:
    """Wrapper to connect to the HIPPO sqlite database.

    .. attention::

            :class:`.Database` objects should not be created directly. Instead use the methods in :class:`.HIPPO` to interact with data in the database. See :doc:`getting_started` and :doc:`insert_elaborations`.

    """

    TABLES = [
        "compound"
        "inspiration"
        "scaffold"
        "reaction"
        "reactant"
        "pose"
        "tag"
        "quote"
        "target"
        "feature"
        "route"
        "component"
        "compound_pattern_bfp"
        "interaction"
        "subsite"
        "subsite_tag"
    ]

    SQL_STRING_PLACEHOLDER = "?"
    SQL_PK_DATATYPE = "INTEGER"
    SQL_SCHEMA_PREFIX = ""

    ERROR_UNIQUE_VIOLATION = sqlite3.IntegrityError

    SQL_CREATE_TABLE_COMPOUND = """
    CREATE TABLE compound(
        compound_id INTEGER PRIMARY KEY,
        compound_inchikey TEXT,
        compound_alias TEXT,
        compound_smiles TEXT,
        compound_base INTEGER,
        compound_mol MOL,
        compound_pattern_bfp bits(2048),
        compound_morgan_bfp bits(2048),
        compound_metadata TEXT,
        FOREIGN KEY (compound_base) REFERENCES compound(compound_id),
        CONSTRAINT UC_compound_inchikey UNIQUE (compound_inchikey)
        CONSTRAINT UC_compound_alias UNIQUE (compound_alias)
        CONSTRAINT UC_compound_smiles UNIQUE (compound_smiles)
    );
    """

    SQL_CREATE_TABLE_POSE = """
    CREATE TABLE pose(
        pose_id INTEGER PRIMARY KEY,
        pose_inchikey TEXT,
        pose_alias TEXT,
        pose_smiles TEXT,
        pose_reference INTEGER,
        pose_path TEXT,
        pose_compound INTEGER,
        pose_target INTEGER,
        pose_mol BLOB,
        pose_fingerprint BLOB,
        pose_energy_score REAL,
        pose_distance_score REAL,
        pose_inspiration_score REAL,
        pose_metadata TEXT,
        FOREIGN KEY (pose_compound) REFERENCES compound(compound_id),
        CONSTRAINT UC_pose_alias UNIQUE (pose_alias)
        CONSTRAINT UC_pose_path UNIQUE (pose_path)
    );
    """

    SQL_INSERT_COMPOUND = """
    INSERT INTO compound(
        compound_inchikey, 
        compound_smiles, 
        compound_mol, 
        compound_pattern_bfp, 
        compound_morgan_bfp, 
        compound_alias
    )
    VALUES(
        :inchikey, 
        :smiles, 
        mol_from_smiles(:smiles), 
        mol_pattern_bfp(mol_from_smiles(:smiles), 2048), 
        mol_morgan_bfp(mol_from_smiles(:smiles), 2, 2048), 
        :alias
    )
    """

    SQL_BULK_INSERT_INTERACTIONS = """
    INSERT OR IGNORE INTO interaction(
        interaction_feature, 
        interaction_pose, 
        interaction_type, 
        interaction_family, 
        interaction_atom_ids, 
        interaction_prot_coord, 
        interaction_lig_coord, 
        interaction_distance, 
        interaction_angle, 
        interaction_energy
    )
    VALUES(?,?,?,?,?,?,?,?,?,?)
    """

    POSE_FIELDS = [
        "pose_id",
        "pose_inchikey",
        "pose_alias",
        "pose_smiles",
        "pose_reference",
        "pose_path",
        "pose_compound",
        "pose_target",
        "pose_mol",
        "pose_fingerprint",
        "pose_energy_score",
        "pose_distance_score",
        "pose_inspiration_score",
    ]

    COMPOUND_PROPERTY_FUNCTIONS = {
        "num_heavy_atoms": "mol_num_hvyatms",
        "formula": "mol_formula",
        "num_rings": "mol_num_rings",
        "molecular_weight": "mol_amw",
    }

    def __init__(
        self,
        path: Path,
        animal: "HIPPO",
        update_legacy: bool = False,
        auto_compute_bfps: bool = True,
        create_blank: bool = True,
        check_legacy: bool = True,
        create_indexes: bool = True,
        update_indexes: bool = True,
        debug: bool = True,
    ) -> None:
        """Database initialisation"""

        self._in_memory = path == ":memory:"
        assert isinstance(path, Path) or self.in_memory

        if debug:
            mrich.debug("hippo.Database.__init__()")

        self._path = path
        self._connection = None
        self._cursor = None
        self._animal = animal
        self._auto_compute_bfps = auto_compute_bfps
        self._engine = "sqlite3"

        if debug:
            mrich.debug(f"Database.path = {self.path}")

        if not self.in_memory:
            try:
                path = path.resolve(strict=True)

            except FileNotFoundError:
                # create a blank database

                if create_blank:
                    self.connect(debug=debug)
                    self.create_blank_db()
                else:
                    raise

            else:
                # connect to existing database
                self.connect(debug=debug)
        else:
            self.connect(debug=debug)
            if create_blank:
                self.create_blank_db()

        if check_legacy:
            self.check_schema(update=update_legacy)

        if create_indexes:
            self.create_indexes(update=update_indexes, debug=debug)

    def check_schema(self, update: bool = False) -> None:
        """Check the database for legacy schema and optionally update

        :param update: update the legacy database?
        """

        if "interaction" not in self.table_names:
            if not update:
                mrich.error("This is a legacy format database (hippo-db < 0.3.23)")
                mrich.error("Existing fingerprints will not be compatible")
                mrich.error("Re-initialise HIPPO object with update_legacy=True to fix")
                raise LegacyDatabaseError("hippo-db < 0.3.23")
            else:
                mrich.warning("This is a legacy format database (hippo-db < 0.3.23)")
                mrich.warning("Clearing legacy fingerprints...")
                self.create_table_interaction()
                self.delete_interactions()

        if "subsite" not in self.table_names or "subsite_tag" not in self.table_names:
            mrich.warning("This is a legacy format database (hippo-db < 0.3.24)")
            self.create_table_subsite()
            self.create_table_subsite_tag()

        if "scaffold" not in self.table_names:
            if not update:
                mrich.error("This is a legacy format database (hippo-db < 0.3.25)")
                mrich.error("Existing base-elab relationships will not be compatible")
                mrich.error("Re-initialise HIPPO object with update_legacy=True to fix")
                raise LegacyDatabaseError("hippo-db < 0.3.25")
            else:
                mrich.warning("This is a legacy format database (hippo-db < 0.3.25)")
                mrich.warning("Migrating compound_base values to scaffold table...")
                self.create_table_scaffold()
                self.migrate_legacy_scaffolds()

        if "route" not in self.table_names:
            self.create_table_route()
            self.create_table_component()

        elif "component_amount" not in self.column_names("component"):
            if not update:
                mrich.error("This is a legacy format database (hippo-db < 0.3.29)")
                mrich.error("Re-initialise HIPPO object with update_legacy=True to fix")
                raise LegacyDatabaseError("hippo-db < 0.3.29")
            else:
                mrich.warning("This is a legacy format database (hippo-db < 0.3.29)")
                mrich.warning("Updating legacy routes...")

            self.update_legacy_routes()

        if "reaction_metadata" not in self.column_names("reaction"):
            if not update:
                mrich.error("This is a legacy format database (hippo-db < 0.3.32)")
                mrich.error("Re-initialise HIPPO object with update_legacy=True to fix")
                raise LegacyDatabaseError("hippo-db < 0.3.32")
            else:
                mrich.warning("This is a legacy format database (hippo-db < 0.3.32)")
                mrich.warning("Updating legacy reaction table...")

            self.update_legacy_reaction_metadata()

        if "pose_inspiration_score" not in self.column_names("pose"):
            if not update:
                mrich.error("This is a legacy format database (hippo-db < 0.3.36)")
                mrich.error("Re-initialise HIPPO object with update_legacy=True to fix")
                raise LegacyDatabaseError("hippo-db < 0.3.36")
            else:
                mrich.warning("This is a legacy format database (hippo-db < 0.3.36)")
                mrich.warning("Updating legacy pose table...")

            self.update_legacy_pose_inspiration_score()

        self.commit()

    def create_indexes(self, update: bool = True, debug: bool = True) -> None:
        """Create and optionally update indexes"""

        INDEXES = [
            ("pose", "pose_inchikey"),
            (
                "pose",
                "pose_smiles",
            ),
            (
                "pose",
                "pose_reference",
            ),
            (
                "pose",
                "pose_target",
            ),
            (
                "inspiration",
                "inspiration_original",
            ),
            (
                "inspiration",
                "inspiration_derivative",
            ),
            (
                "scaffold",
                "scaffold_superstructure",
            ),
            (
                "reaction",
                "reaction_type",
            ),
            (
                "reaction",
                "reaction_product",
            ),
            (
                "reactant",
                "reactant_compound",
            ),
            (
                "tag",
                "tag_compound",
            ),
            (
                "tag",
                "tag_pose",
            ),
            (
                "quote",
                "quote_supplier",
            ),
            (
                "quote",
                "quote_catalogue",
            ),
            (
                "quote",
                "quote_entry",
            ),
            (
                "quote",
                "quote_compound",
            ),
            (
                "route",
                "route_product",
            ),
            # ("subsite", "subsite_name",), # not enough rows to matter?
            (
                "subsite_tag",
                "subsite_tag_pose",
            ),
            (
                "interaction",
                "interaction_pose",
            ),
            # ("interaction", "interaction_type",), # mainly done on interaction_temp
            (
                "component",
                "component_route",
            ),
            (
                "component",
                "component_ref",
            ),
            (
                "component",
                ("component_type", "component_ref", "component_route"),
            ),
        ]

        existing = set(self.index_names())

        for table, column in INDEXES:

            if isinstance(column, tuple):
                name = ["index_", table, *(c.removeprefix(table) for c in column)]
                name = "".join(name)
                col_str = f"({', '.join(column)})"

            else:
                assert column.startswith(table)
                name = f"index_{column}"
                col_str = f"({column})"

            if name in existing:
                continue

            if debug:
                mrich.debug(f"Creating {name}")

            self.execute(
                f"CREATE INDEX IF NOT EXISTS {name} ON {self.SQL_SCHEMA_PREFIX}{table} {col_str}"
            )

        if update:
            if debug:
                mrich.debug("Updating indexes")
            self.execute("ANALYZE")
            self.commit()

    @classmethod
    def copy_from(
        cls,
        source: Path,
        destination: Path,
        animal: "HIPPO",
        update_legacy: bool = False,
        overwrite_existing: bool = False,
        pages: int = 10000,
    ) -> None:
        """Create a :class:`.Database` from an existing one"""

        source = Path(source)

        assert source.exists()

        if destination.exists():
            if overwrite_existing:
                mrich.warning(f"Overwriting {destination}")
            else:
                mrich.error(f"Will not overwrite {destination}")
                mrich.error(f"Set overwrite_existing=True to override")
                raise Exception("Set overwrite_existing=True to override")

        mrich.print(f"Copying {source} --> {destination}")

        def progress(status, remaining, total):
            """print progress"""
            mrich.debug(f"Copied {total-remaining} of {total} pages...")

        src = sqlite3.connect(source)
        dst = sqlite3.connect(destination)
        with dst:
            src.backup(dst, pages=pages, progress=progress)
        dst.close()
        src.close()

        self = cls.__new__(cls)

        self.__init__(path=destination, animal=animal, update_legacy=update_legacy)

        return self

    ### PROPERTIES

    @property
    def path(self) -> Path:
        """Returns the path to the database file"""
        return self._path

    @property
    def engine(self) -> str:
        """Returns the Database engine"""
        return self._engine

    @property
    def in_memory(self) -> bool:
        """Is this database stored in memory"""
        return self._in_memory

    @property
    def connection(self) -> "sqlite3.connection":
        """Returns a ``sqlite3.connection`` to the database"""
        if not self._connection:
            self.connect()
        return self._connection

    @property
    def cursor(self) -> "sqlite3.cursor":
        """Returns a ``sqlite3.cursor``"""
        if not self._cursor:
            self._cursor = self.connection.cursor()
        return self._cursor

    @property
    def total_changes(self) -> int:
        """Return the total number of database rows that have been modified, inserted, or deleted since the database connection was opened."""
        return self.connection.total_changes

    @property
    def table_names(self) -> list[str]:
        """List of all the table names in the database"""
        results = self.execute(
            "SELECT name FROM sqlite_master WHERE type='table';"
        ).fetchall()
        return [n for n, in results]

    @property
    def auto_compute_bfps(self) -> bool:
        """Automatically compute compound binary fingerprints on insertion"""
        return self._auto_compute_bfps

    @auto_compute_bfps.setter
    def auto_compute_bfps(self, b: bool):
        """Automatically compute compound binary fingerprints on insertion"""
        self._auto_compute_bfps = b

    ### PUBLIC METHODS / API CALLS

    def close(self, debug: bool = False) -> None:
        """Close the connection"""
        if debug:
            mrich.debug("hippo.Database.close()")
        if self.connection:
            self.connection.close()
        if debug:
            mrich.success(f"Closed connection to {self.path}")

    def backup(
        self,
        destination: Path | str | None = None,
        pages: int = 10_000,
    ) -> None:
        """Create a backup of the database"""
        return backup(self.path, destination, pages=pages)

    ### GENERAL SQL

    def connect(self, debug: bool = True) -> None:
        """Connect to the database"""

        if debug:
            mrich.debug("hippo.Database.connect()")

        conn = None

        try:
            if sqlite3.threadsafety == 3:  # Serialized, safe to use multithreading
                conn = sqlite3.connect(self.path, check_same_thread=False)
            else:
                conn = sqlite3.connect(self.path)

            if debug:
                mrich.debug(f"{sqlite3.sqlite_version=}")

            conn.enable_load_extension(True)
            conn.load_extension("chemicalite")
            conn.enable_load_extension(False)

            if debug:
                mrich.success("Database connected @", f"[file]{self.path}")

        except sqlite3.OperationalError as e:

            if "cannot open shared object file" in str(e):
                mrich.error("chemicalite package not installed correctly")
            else:
                mrich.error(e)
            raise

        except Error as e:
            mrich.error(e)
            raise

        self._connection = conn
        self._cursor = conn.cursor()

    def execute(
        self,
        sql: str,
        payload: tuple | list | dict | None = None,
        *,
        retry: float | None = 1,
        debug: bool = False,
    ):
        """Execute arbitrary SQL with retry if database is locked."""
        if debug:
            from .tools import strip_sql

            mrich.debug(sql)

        while True:
            try:
                if payload:
                    return self.cursor.execute(sql, payload)
                else:
                    return self.cursor.execute(sql)
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e) and retry:
                    with mrich.clock(
                        f"SQLite Database is locked, waiting {retry} second(s)..."
                    ):
                        time.sleep(retry)
                    mrich.print("[debug]SQLite Database was locked, retrying...")
                    continue  # retry without recursion
                elif "syntax error" in str(e):
                    mrich.error(sql)
                    mrich.error(payload)
                    raise
                else:
                    raise
            except Exception as e:
                # from .tools import strip_sql
                # mrich.error(strip_sql(sql))
                raise

    def executemany(
        self, sql, payload, *, retry: float | None = 1, batch_size: int = None
    ) -> None:
        """Execute arbitrary SQL

        :param sql: SQL query
        :param retry: If truthy, keep trying to executemany every `retry` seconds if the Database is locked
        :param payload: Payload for insertion, etc. (Default value = None)

        """

        if "RETURNING" in sql:
            from .apsw import executemany

            return executemany(self.path, sql, payload)

        if batch_size and batch_size < len(payload):

            from itertools import batched

            batches = list(batched(payload, batch_size))

            n = len(batches)

            for i, batch in enumerate(mrich.track(batches, prefix="batch execution")):
                mrich.set_progress_field("i", i)
                mrich.set_progress_field("n", n)

                self.executemany(sql, batch, batch_size=None, retry=retry)

            return

        try:
            return self.cursor.executemany(sql, payload)
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e) and retry:
                mrich.print("[debug]SQLite Database was locked, waiting...")
                time.sleep(retry)
                return self.executemany(sql=sql, payload=payload, retry=retry)
            else:
                raise
        except Exception as e:
            mrich.print(sql)
            mrich.print(payload[0])
            raise

    def commit(self, *, retry: float | None = 1) -> None:
        """Commit changes to the database

        :param retry: If truthy, keep trying to execute every `retry` seconds if the Database is locked
        """
        try:
            self.connection.commit()
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e) and retry:
                with mrich.clock(
                    f"SQLite Database is locked, waiting {retry} second(s)..."
                ):
                    time.sleep(retry)
                mrich.print("[debug]SQLite Database was locked, retrying...")
                return self.commit()
            else:
                raise

    def rollback(self) -> None:
        """rollback (not relevant for sqlite)"""
        # self.connection.rollback()
        pass

    def get_lastrowid(self) -> int:
        """Get ID of last inserted row"""
        return self.cursor.lastrowid

    ### CREATE TABLES

    def create_blank_db(self) -> None:
        """Create a blank database"""

        with mrich.loading("Creating blank database..."):
            self.create_table_compound()
            self.create_table_pose()
            self.create_table_inspiration()
            self.create_table_reaction()
            self.create_table_reactant()
            self.create_table_tag()
            self.create_table_quote()
            self.create_table_target()
            self.create_table_pattern_bfp()
            self.create_table_feature()
            self.create_table_route()
            self.create_table_component()
            self.create_table_interaction()
            self.create_table_subsite()
            self.create_table_subsite_tag()
            self.create_table_scaffold()
            self.commit()

    def create_table_compound(self) -> None:
        """Create the compound table"""
        mrich.debug("HIPPO.Database.create_table_compound()")

        sql = self.SQL_CREATE_TABLE_COMPOUND

        self.execute(sql)

    def create_table_inspiration(self) -> None:
        """Create the inspiration table"""
        mrich.debug("HIPPO.Database.create_table_inspiration()")

        sql = f"""CREATE TABLE {self.SQL_SCHEMA_PREFIX}inspiration(
            inspiration_original INTEGER,
            inspiration_derivative INTEGER,
            FOREIGN KEY (inspiration_original) REFERENCES {self.SQL_SCHEMA_PREFIX}pose(pose_id),
            FOREIGN KEY (inspiration_derivative) REFERENCES {self.SQL_SCHEMA_PREFIX}pose(pose_id),
            CONSTRAINT UC_inspiration UNIQUE (inspiration_original, inspiration_derivative)
        );
        """

        self.execute(sql)

    def create_table_scaffold(self) -> None:
        """Create the scaffold table"""
        mrich.debug("HIPPO.Database.create_table_scaffold()")

        sql = f"""CREATE TABLE {self.SQL_SCHEMA_PREFIX}scaffold(
            scaffold_base INTEGER,
            scaffold_superstructure INTEGER,
            FOREIGN KEY (scaffold_base) REFERENCES {self.SQL_SCHEMA_PREFIX}compound(compound_id),
            FOREIGN KEY (scaffold_superstructure) REFERENCES {self.SQL_SCHEMA_PREFIX}compound(compound_id),
            CONSTRAINT UC_scaffold UNIQUE (scaffold_base, scaffold_superstructure)
        );
        """

        self.execute(sql)

    def create_table_reaction(self) -> None:
        """Create the reaction table"""
        mrich.debug("HIPPO.Database.create_table_reaction()")

        sql = f"""CREATE TABLE {self.SQL_SCHEMA_PREFIX}reaction(
            reaction_id {self.SQL_PK_DATATYPE} PRIMARY KEY,
            reaction_type TEXT,
            reaction_product INTEGER,
            reaction_product_yield REAL,
            reaction_metadata TEXT,
            FOREIGN KEY (reaction_product) REFERENCES {self.SQL_SCHEMA_PREFIX}compound(compound_id)
        );
        """

        self.execute(sql)

    def create_table_reactant(self) -> None:
        """Create the reactant table"""
        mrich.debug("HIPPO.Database.create_table_reactant()")

        sql = f"""CREATE TABLE {self.SQL_SCHEMA_PREFIX}reactant(
            reactant_amount REAL,
            reactant_reaction INTEGER,
            reactant_compound INTEGER,
            FOREIGN KEY (reactant_reaction) REFERENCES {self.SQL_SCHEMA_PREFIX}reaction(reaction_id),
            FOREIGN KEY (reactant_compound) REFERENCES {self.SQL_SCHEMA_PREFIX}compound(compound_id),
            CONSTRAINT UC_reactant UNIQUE (reactant_reaction, reactant_compound)
        );
        """

        self.execute(sql)

    def create_table_pose(self) -> None:
        """Create the pose table"""
        mrich.debug("HIPPO.Database.create_table_pose()")

        sql = self.SQL_CREATE_TABLE_POSE

        self.execute(sql)

    def create_table_tag(self) -> None:
        """Create the tag table"""
        mrich.debug("HIPPO.Database.create_table_tag()")

        sql = f"""CREATE TABLE {self.SQL_SCHEMA_PREFIX}tag(
            tag_name TEXT,
            tag_compound INTEGER,
            tag_pose INTEGER,
            FOREIGN KEY (tag_compound) REFERENCES {self.SQL_SCHEMA_PREFIX}compound(compound_id),
            FOREIGN KEY (tag_pose) REFERENCES {self.SQL_SCHEMA_PREFIX}pose(pose_id),
            CONSTRAINT UC_tag_compound UNIQUE (tag_name, tag_compound),
            CONSTRAINT UC_tag_pose UNIQUE (tag_name, tag_pose)
        );
        """

        self.execute(sql)

    def create_table_quote(self) -> None:
        """Create the quote table"""
        mrich.debug("HIPPO.Database.create_table_quote()")

        sql = f"""CREATE TABLE {self.SQL_SCHEMA_PREFIX}quote(
            quote_id {self.SQL_PK_DATATYPE} PRIMARY KEY,
            quote_smiles TEXT,
            quote_amount REAL,
            quote_supplier TEXT,
            quote_catalogue TEXT,
            quote_entry TEXT,
            quote_lead_time INTEGER,
            quote_price REAL,
            quote_currency TEXT,
            quote_purity REAL,
            quote_date TEXT,
            quote_compound INTEGER,
            FOREIGN KEY (quote_compound) REFERENCES {self.SQL_SCHEMA_PREFIX}compound(compound_id),
            CONSTRAINT UC_quote UNIQUE (quote_amount, quote_supplier, quote_catalogue, quote_entry)
        );
        """

        self.execute(sql)

    def create_table_target(self) -> None:
        """Create the target table"""
        mrich.debug("HIPPO.Database.create_table_target()")
        sql = f"""CREATE TABLE {self.SQL_SCHEMA_PREFIX}target(
            target_id {self.SQL_PK_DATATYPE} PRIMARY KEY,
            target_name TEXT,
            target_metadata TEXT,
            CONSTRAINT UC_target UNIQUE (target_name)
        );
        """

        self.execute(sql)

    def create_table_feature(self) -> None:
        """Create the feature table"""
        mrich.debug("HIPPO.Database.create_table_feature()")
        sql = f"""CREATE TABLE {self.SQL_SCHEMA_PREFIX}feature(
            feature_id {self.SQL_PK_DATATYPE} PRIMARY KEY,
            feature_family TEXT,
            feature_target INTEGER,
            feature_chain_name TEXT,
            feature_residue_name TEXT,
            feature_residue_number INTEGER,
            feature_atom_names TEXT,
            CONSTRAINT UC_feature UNIQUE (
                feature_family, 
                feature_target, 
                feature_chain_name, 
                feature_residue_number, 
                feature_residue_name, 
                feature_atom_names
            )
        );
        """

        self.execute(sql)

    def create_table_route(self) -> None:
        """Create the route table"""
        mrich.debug("HIPPO.Database.create_table_route()")
        sql = f"""CREATE TABLE {self.SQL_SCHEMA_PREFIX}route(
            route_id {self.SQL_PK_DATATYPE} PRIMARY KEY,
            route_product INTEGER,
            FOREIGN KEY (route_product) REFERENCES {self.SQL_SCHEMA_PREFIX}compound(compound_id)
        );
        """

        self.execute(sql)

    def create_table_component(self) -> None:
        """Create the component table"""
        mrich.debug("HIPPO.Database.create_table_component()")
        sql = f"""CREATE TABLE {self.SQL_SCHEMA_PREFIX}component(
            component_id {self.SQL_PK_DATATYPE} PRIMARY KEY,
            component_route INTEGER,
            component_type INTEGER,
            component_ref INTEGER,
            component_amount REAL,
            FOREIGN KEY (component_route) REFERENCES {self.SQL_SCHEMA_PREFIX}route(route_id),
            CONSTRAINT UC_component UNIQUE (component_route, component_ref, component_type)
        );
        """

        self.execute(sql)

    def create_table_pattern_bfp(self) -> None:
        """Create the pattern_bfp table"""
        mrich.debug("HIPPO.Database.create_table_pattern_bfp()")

        sql = """
        CREATE VIRTUAL TABLE compound_pattern_bfp 
        USING rdtree(compound_id, fp bits(2048))
        """

        self.execute(sql)

    def create_table_interaction(
        self, table: str = "interaction", debug: bool = True
    ) -> None:
        """Create an interaction table"""

        if debug:
            mrich.debug(f"HIPPO.Database.create_table_interaction({table=})")

        sql = f"""
        CREATE TABLE {self.SQL_SCHEMA_PREFIX}{table}(
            interaction_id {self.SQL_PK_DATATYPE} PRIMARY KEY,
            interaction_feature INTEGER NOT NULL,
            interaction_pose INTEGER NOT NULL,
            interaction_type TEXT NOT NULL,
            interaction_family TEXT NOT NULL,
            interaction_atom_ids TEXT NOT NULL,
            interaction_prot_coord TEXT NOT NULL,
            interaction_lig_coord TEXT NOT NULL,
            interaction_distance REAL NOT NULL,
            interaction_angle REAL,
            interaction_energy REAL,
            FOREIGN KEY (interaction_feature) REFERENCES {self.SQL_SCHEMA_PREFIX}feature(feature_id),
            FOREIGN KEY (interaction_pose) REFERENCES {self.SQL_SCHEMA_PREFIX}pose(pose_id),
            CONSTRAINT UC_interaction UNIQUE (
                interaction_feature, 
                interaction_pose, 
                interaction_type, 
                interaction_family, 
                interaction_atom_ids
            )
        );
        """

        self.execute(sql)

    def create_table_subsite(self) -> None:
        """Create the subsite table"""

        mrich.debug("HIPPO.Database.create_table_subsite()")
        sql = f"""CREATE TABLE {self.SQL_SCHEMA_PREFIX}subsite(
            subsite_id {self.SQL_PK_DATATYPE} PRIMARY KEY,
            subsite_target INTEGER NOT NULL,
            subsite_name TEXT NOT NULL,
            subsite_metadata TEXT,
            FOREIGN KEY (subsite_target) REFERENCES {self.SQL_SCHEMA_PREFIX}target(target_id),
            CONSTRAINT UC_subsite UNIQUE (subsite_target, subsite_name)
        );
        """

        self.execute(sql)

    def create_table_subsite_tag(self) -> None:
        """Create the subsite_tag table"""

        mrich.debug("HIPPO.Database.create_table_subsite_tag()")
        sql = f"""CREATE TABLE {self.SQL_SCHEMA_PREFIX}subsite_tag(
            subsite_tag_id {self.SQL_PK_DATATYPE} PRIMARY KEY,
            subsite_tag_ref INTEGER NOT NULL,
            subsite_tag_pose INTEGER NOT NULL,
            subsite_tag_metadata TEXT,
            FOREIGN KEY (subsite_tag_ref) REFERENCES {self.SQL_SCHEMA_PREFIX}subsite(subsite_id),
            FOREIGN KEY (subsite_tag_pose) REFERENCES {self.SQL_SCHEMA_PREFIX}pose(pose_id),
            CONSTRAINT UC_subsite_tag UNIQUE (subsite_tag_ref, subsite_tag_pose)
        );
        """

        self.execute(sql)

    def sql_return_id_str(self, key: str) -> str:
        """SQL suffix to return the lastrowid (for sqlite returns an empty string)"""
        return ""

    ### INSERTION

    def insert_compound(
        self,
        *,
        smiles: str,
        alias: str | None = None,
        tags: None | list[str] = None,
        warn_duplicate: bool = True,
        commit: bool = True,
        metadata: None | dict = None,
        inchikey: str = None,
    ) -> int:
        """Insert an entry into the compound table

        :param smiles: SMILES string
        :param alias: optional alias for the compound (Default value = None)
        :param tags: list of string tags, (Default value = None)
        :param warn_duplicate: print a warning if the compound already exists (Default value = True)
        :param commit: commit the changes to the database (Default value = True)
        :param metadata: dictionary of metadata (Default value = None)
        :param inchikey: provide an InChI-key, otherwise it's calculated from the SMILES, (Default value = None)
        :returns: compound ID

        """

        # generate the inchikey name
        inchikey = inchikey or inchikey_from_smiles(smiles)

        try:
            self.execute(
                self.SQL_INSERT_COMPOUND,
                dict(inchikey=inchikey, smiles=smiles, alias=alias),
            )

        except self.ERROR_UNIQUE_VIOLATION as e:

            constraints = [
                "compound_inchikey",
                "compound_smiles",
                "compound_pattern_bfp",
                "compound_morgan_bfp",
            ]

            message = str(e)

            for constraint in constraints:

                match self.engine:
                    case "sqlite3":
                        test_str = f"UNIQUE constraint failed: compound.{constraint}"
                    case "psycopg":
                        test_str = f'duplicate key value violates unique constraint "uc_{constraint}"'
                    case _:
                        raise NotImplementedError

                if test_str in message:
                    if warn_duplicate:
                        mrich.warning(
                            f"Skipping compound with duplicate {constraint}, {smiles=}"
                        )
                    self.rollback()
                    return None

            else:
                mrich.error(e)

            return None

        except Exception as e:
            mrich.error(e)

        compound_id = self.get_lastrowid()

        if commit:
            self.commit()

        ### register the tags

        if tags:
            for tag in tags:
                self.insert_tag(name=tag, compound=compound_id, commit=commit)

        ### register the binary fingerprints

        if self.auto_compute_bfps:
            result = self.insert_compound_pattern_bfp(compound_id, commit=commit)

            if not result:
                mrich.error("Could not insert compound pattern bfp")

        ### insert metadata

        if metadata:
            self.insert_metadata(
                table="compound", id=compound_id, payload=metadata, commit=commit
            )

        return compound_id

    def insert_compound_pattern_bfp(self, compound_id: int, commit: bool = True) -> int:
        """Insert a compound_pattern_bfp

        :param compound_id: ID of the associated compound
        :param commit: commit the changes to the database (Default value = True)
        :returns: binary fingerprint ID

        """

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}compound_pattern_bfp(compound_id, fp)
        VALUES(?1, ?2)
        """

        (bfp,) = self.select_where(
            "compound_pattern_bfp", "compound", "id", compound_id
        )

        try:
            self.execute(sql, (compound_id, bfp))

        except Exception as e:
            mrich.error(e)

        bfp_id = self.cursor.lastrowid
        if commit:
            self.commit()

        return bfp_id

    def insert_pose(
        self,
        *,
        compound: Compound | int,
        target: Target | int | str,
        path: str,
        inchikey: str | None = None,
        alias: str | None = None,
        reference: int | Pose | None = None,
        tags: None | list = None,
        energy_score: float | None = None,
        distance_score: float | None = None,
        metadata: None | dict = None,
        commit: bool = True,
        warn_duplicate: bool = True,
        resolve_path: bool = True,
    ) -> int:
        """Insert an entry into the pose table

        :param compound: associated :class:`.Compound` object or ID
        :param target: protein :class:`.Target` name or ID
        :param path: path to the molecular structure (.pdb/.mol)
        :param inchikey: provide an InChI-key if available, (Default value = None)
        :param alias: optional alias for the compound (Default value = None)
        :param reference: reference :class:`.Pose` object or ID to use for the protein conformation (Default value = None)
        :param tags: list of string tags, (Default value = None)
        :param energy_score: optional score of the ligand's binding energy (Default value = None)
        :param distance_score: optional score of the ligand's binding position (Default value = None)
        :param metadata: dictionary of metadata (Default value = None)
        :param commit: commit the changes to the database (Default value = True)
        :param warn_duplicate: print a warning if the pose already exists (Default value = True)
        :param resolve_path: try resolving the path (Default value = True)
        :returns: the pose ID

        """

        if isinstance(compound, Compound):
            compound = compound.id

        if isinstance(reference, Pose):
            reference = reference.id

        if isinstance(target, Target):
            target = target.id

        if isinstance(target, str):
            target = self.get_target_id(name=target)
            if not target:
                raise ValueError(f"No such {target=}")
        target_name = self.get_target_name(id=target)

        if resolve_path:
            try:
                path = Path(path)
                path = path.resolve(strict=True)
                path = str(path)

            except FileNotFoundError as e:
                mrich.error(f"Path cannot be resolved: {mcol.file}{path}")
                raise

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}pose(
            pose_inchikey, 
            pose_alias, 
            pose_smiles, 
            pose_compound, 
            pose_target, 
            pose_path, 
            pose_reference, 
            pose_energy_score, 
            pose_distance_score
        )
        VALUES(
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}
        )
        {self.sql_return_id_str('pose')}
        """

        try:
            self.execute(
                sql,
                (
                    inchikey,
                    alias,
                    None,
                    compound,
                    target,
                    path,
                    reference,
                    energy_score,
                    distance_score,
                ),
            )

        except self.ERROR_UNIQUE_VIOLATION as e:

            constraints = [
                "pose_path",
                "pose_alias",
            ]

            message = str(e)

            for constraint in constraints:

                match self.engine:
                    case "sqlite3":
                        test_str = f"UNIQUE constraint failed: pose.{constraint}"
                    case "psycopg":
                        test_str = f'duplicate key value violates unique constraint "uc_{constraint}"'
                    case _:
                        raise NotImplementedError

                if test_str in message:
                    if warn_duplicate:
                        mrich.warning(
                            f"Skipping pose with duplicate {constraint}, {alias=}, {path=}"
                        )
                    self.rollback()
                    return None

            else:
                mrich.error(e)

            return None

        except Exception as e:
            mrich.error(e)
            raise

        pose_id = self.get_lastrowid()

        if commit:
            self.commit()

        if tags:
            for tag in tags:
                self.insert_tag(name=tag, pose=pose_id, commit=commit)

        if metadata:
            self.insert_metadata(
                table="pose", id=pose_id, payload=metadata, commit=commit
            )

        return pose_id

    def insert_tag(
        self,
        *,
        name: str,
        compound: int = None,
        pose: int = None,
        commit: bool = True,
    ) -> None:
        """Insert an entry into the tag table.

        .. attention::
                Exactly one of compound or pose arguments must have a value

        :param name: name of the tag
        :param compound: associated :class:`.Compound` ID
        :param pose: associated :class:`.Pose` ID
        :param commit: commit the changes to the database (Default value = True)
        """

        assert bool(compound) ^ bool(
            pose
        ), "Exactly one of compound or pose arguments must have a value"

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}tag(tag_name, tag_compound, tag_pose)
        VALUES({self.SQL_STRING_PLACEHOLDER}, {self.SQL_STRING_PLACEHOLDER}, {self.SQL_STRING_PLACEHOLDER})
        """

        try:
            self.execute(sql, (name, compound, pose))

        except self.ERROR_UNIQUE_VIOLATION as e:
            return None

        except Exception as e:
            mrich.error(e)

        if commit:
            self.commit()

    def insert_inspiration(
        self,
        *,
        original: Pose | int,
        derivative: Pose | int,
        warn_duplicate: bool = True,
        commit: bool = True,
    ) -> int:
        """Insert an entry into the inspiration table

        :param original: :class:`.Pose` object or ID of the original hit
        :param derivative: :class:`.Pose` object or ID of the derivative hit
        :param warn_duplicate: print a warning if the pose already exists (Default value = True)
        :param commit: commit the changes to the database (Default value = True)
        :returns: the inspiration ID

        """

        if isinstance(original, Pose):
            original = original.id
        if isinstance(derivative, Pose):
            derivative = derivative.id

        assert isinstance(
            original, int
        ), "Must pass an integer ID or Pose object (original)"
        assert isinstance(
            derivative, int
        ), "Must pass an integer ID or Pose object (derivative)"

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}inspiration(inspiration_original, inspiration_derivative)
        VALUES({self.SQL_STRING_PLACEHOLDER}, {self.SQL_STRING_PLACEHOLDER})
        """

        try:
            self.execute(sql, (original, derivative))

        except self.ERROR_UNIQUE_VIOLATION as e:
            if warn_duplicate:
                mrich.warning(
                    f"Skipping existing inspiration: {original=} {derivative=}"
                )
            return None

        except Exception as e:
            mrich.error(e)

        inspiration_id = self.cursor.lastrowid

        if commit:
            self.commit()
        return inspiration_id

    def insert_scaffold(
        self,
        *,
        scaffold: Compound | int,
        superstructure: Compound | int,
        warn_duplicate: bool = True,
        commit: bool = True,
    ) -> int:
        """Insert an entry into the scaffold table

        :param scaffold: :class:`.Compound` object or ID of the scaffold hit
        :param superstructure: :class:`.Compound` object or ID of the superstructure hit
        :param warn_duplicate: print a warning if the pose already exists (Default value = True)
        :param commit: commit the changes to the database (Default value = True)
        :returns: the scaffold row ID

        """

        if isinstance(scaffold, Compound):
            scaffold = scaffold.id
        if isinstance(superstructure, Compound):
            superstructure = superstructure.id

        assert isinstance(
            scaffold, int
        ), f"Must pass an integer ID or Compound object (scaffold) {scaffold=} {type(scaffold)}"
        assert isinstance(
            superstructure, int
        ), f"Must pass an integer ID or Compound object (superstructure) {superstructure=} {type(superstructure)}"

        if scaffold == superstructure:
            # mrich.warning(f"Skipped self-referential scaffold assignment (C{scaffold})")
            return None

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}scaffold(scaffold_base, scaffold_superstructure)
        VALUES({self.SQL_STRING_PLACEHOLDER}, {self.SQL_STRING_PLACEHOLDER})
        """

        try:
            self.execute(sql, (scaffold, superstructure))

        except self.ERROR_UNIQUE_VIOLATION as e:
            if warn_duplicate:
                mrich.warning(
                    f"Skipping existing scaffold: {scaffold=} {superstructure=}"
                )
            return None

        except Exception as e:
            mrich.error(e)

        scaffold_id = self.cursor.lastrowid

        if commit:
            self.commit()
        return scaffold_id

    def insert_reaction(
        self,
        *,
        type: str,
        product: Compound | int,
        product_yield: float = 1.0,
        commit: bool = True,
    ) -> int:
        """Insert an entry into the reaction table

        :param type: string to indicate the reaction type
        :param product: :class:`.Compound` object or ID of the reaction product
        :param product_yield: yield fraction of the reaction product (Default value = 1.0)
        :param commit: commit the changes to the database (Default value = True)
        :returns: the reaction ID

        """

        if isinstance(product, Compound):
            product = product.id

        # assert isinstance(product, Compound), f'incompatible {product=}'
        assert isinstance(type, str), f"incompatible {type=}"

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}reaction(reaction_type, reaction_product, reaction_product_yield)
        VALUES({self.SQL_STRING_PLACEHOLDER}, {self.SQL_STRING_PLACEHOLDER}, {self.SQL_STRING_PLACEHOLDER})
        """

        try:
            self.execute(sql, (type, product, product_yield))

        except Exception as e:
            mrich.error(e)

        reaction_id = self.cursor.lastrowid
        if commit:
            self.commit()
        return reaction_id

    def insert_reactant(
        self,
        *,
        compound: Compound | int,
        reaction: Reaction | int,
        amount: float = 1.0,
        commit: bool = True,
    ) -> int:
        """Insert an entry into the reactant table

        :param compound: :class:`.Compound` object or ID of the reactant
        :param reaction: :class:`.Reaction` object or ID of the reaction
        :param amount: amount (in ``mg``) needed for each unit of product (Default value = 1.0)
        :param commit: commit the changes to the database (Default value = True)
        :returns: the reactant ID

        """

        if isinstance(reaction, int):
            reaction = self.get_reaction(id=reaction)

        if isinstance(compound, int):
            compound = self.get_compound(id=compound)

        assert isinstance(compound, Compound), f"incompatible {compound=}"
        assert isinstance(reaction, Reaction), f"incompatible {reaction=}"

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}reactant(reactant_amount, reactant_reaction, reactant_compound)
        VALUES({self.SQL_STRING_PLACEHOLDER}, {self.SQL_STRING_PLACEHOLDER}, {self.SQL_STRING_PLACEHOLDER})
        """

        try:
            self.execute(sql, (amount, reaction.id, compound.id))

        except self.ERROR_UNIQUE_VIOLATION as e:
            mrich.warning(f"Skipping existing reactant: {reaction=} {compound=}")

        except Exception as e:
            mrich.error(e)

        reactant_id = self.cursor.lastrowid

        if commit:
            self.commit()

        return reactant_id

    def insert_quote(
        self,
        *,
        compound: Compound | int,
        supplier: str,
        catalogue: str | None = None,
        entry: str | None = None,
        amount: float,
        price: float,
        currency: str | None = None,
        purity: float | None = None,
        lead_time: float,
        smiles: str | None = None,
        date: str | None = None,
        commit: bool = True,
    ) -> int | None:
        """Insert an entry into the quote table

        :param compound: associated :class:`.Compound` object or ID
        :param supplier: name of the supplier
        :param catalogue: optional catalogue name
        :param entry: name of the catalogue entry
        :param amount: amount in `mg`
        :param price: price of the compound
        :param currency: currency string ``['GBP', 'EUR', 'USD', None]``
        :param purity: compound purity fraction
        :param lead_time: lead time in days
        :param smiles: quoted SMILES string (Default value = None)
        :param commit: commit the changes to the database (Default value = True)
        :returns: the quote ID

        """

        if not isinstance(compound, int):
            assert isinstance(compound, Compound), f"incompatible {compound=}"
            compound = compound.id

        assert currency in ["GBP", "EUR", "USD", None], f"incompatible {currency=}"

        assert supplier in [
            "MCule",
            "Enamine",
            "Stock",
            "Molport",
        ], f"incompatible {supplier=}"

        smiles = smiles or ""

        payload = [
            smiles,
            amount,
            supplier,
            catalogue,
            entry,
            lead_time,
            price,
            currency,
            purity,
            compound,
        ]

        if date:
            date_str = "?11"
            payload.append(date)
        else:
            date_str = "date()"

        match self.engine:
            case "sqlite3":
                sql = f"""
                INSERT OR REPLACE INTO quote(
                    quote_smiles,
                    quote_amount,
                    quote_supplier,
                    quote_catalogue,
                    quote_entry,
                    quote_lead_time,
                    quote_price,
                    quote_currency,
                    quote_purity,
                    quote_compound,
                    quote_date
                )
                VALUES(
                    ?, 
                    ?, 
                    ?, 
                    ?, 
                    ?, 
                    ?, 
                    ?, 
                    ?, 
                    ?, 
                    ?, 
                    {date_str}
                );
                """
            case "psycopg":
                sql = """
                INSERT OR REPLACE INTO hippo.quote(
                    quote_smiles,
                    quote_amount,
                    quote_supplier,
                    quote_catalogue,
                    quote_entry,
                    quote_lead_time,
                    quote_price,
                    quote_currency,
                    quote_purity,
                    quote_compound,
                    quote_date
                )
                VALUES(
                    %s, 
                    %s, 
                    %s, 
                    %s, 
                    %s, 
                    %s, 
                    %s, 
                    %s, 
                    %s, 
                    %s, 
                    {date_str}
                )
                ON CONFLICT
                DO UPDATE
                    hippo.quote.quote_smiles = EXCLUDED.quote_smiles,
                    hippo.quote.quote_amount = EXCLUDED.quote_amount,
                    hippo.quote.quote_supplier = EXCLUDED.quote_supplier,
                    hippo.quote.quote_catalogue = EXCLUDED.quote_catalogue,
                    hippo.quote.quote_entry = EXCLUDED.quote_entry,
                    hippo.quote.quote_lead_time = EXCLUDED.quote_lead_time,
                    hippo.quote.quote_price = EXCLUDED.quote_price,
                    hippo.quote.quote_currency = EXCLUDED.quote_currency,
                    hippo.quote.quote_purity = EXCLUDED.quote_purity,
                    hippo.quote.quote_compound = EXCLUDED.quote_compound,
                    hippo.quote.quote_date = EXCLUDED.quote_date;
                """.format(date_str=date_str)

        try:
            self.execute(
                sql,
                tuple(payload),
            )

        except sqlite3.InterfaceError as e:
            mrich.error(e)
            mrich.debug(payload)
            raise

        except Exception as e:
            mrich.error(e)
            return None

        quote_id = self.cursor.lastrowid
        if commit:
            self.commit()
        return quote_id

    def insert_target(
        self,
        *,
        name: str,
        warn_duplicate: bool = True,
    ) -> int:
        """Insert an entry into the target table

        :param name: name of the protein target
        :returns: the target ID

        """

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}target(target_name)
        VALUES({self.SQL_STRING_PLACEHOLDER})
        {self.sql_return_id_str("target")}
        """

        try:
            self.execute(sql, (name,))

        except self.ERROR_UNIQUE_VIOLATION as e:
            if warn_duplicate:
                mrich.warning(f"Skipping existing target with {name=}")
            self.rollback()
            return None

        except Exception as e:
            mrich.error(e)
            raise

        target_id = self.get_lastrowid()

        self.commit()
        return target_id

    def insert_feature(
        self,
        *,
        family: str,
        target: int,
        chain_name: str,
        residue_name: str,
        residue_number: int,
        atom_names: list[str],
        warn_duplicate: bool = False,
        commit: bool = True,
    ) -> int:
        """Insert an entry into the feature table

        :param family: feature type string
        :param target: associated :class:`.Target` ID
        :param chain_name: single character name of the chain
        :param residue_name: 3-4 character string name of the residue
        :param residue_number: integer residue number
        :param atom_names: list of atom names
        :param commit: commit the changes to the database (Default value = True)
        :returns: feature ID

        """

        assert len(chain_name) == 1
        assert len(residue_name) <= 4
        for a in atom_names:
            assert len(a) <= 4

        if isinstance(target, str):
            target = self.get_target_id(name=target)
        assert isinstance(target, int)

        from .prolif import FEATURE_FAMILIES

        if family:
            assert family in FEATURE_FAMILIES, f"Unsupported {family=}"
        else:
            family = "Unknown"

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}feature(
            feature_family, 
            feature_target, 
            feature_chain_name, 
            feature_residue_name, 
            feature_residue_number, 
            feature_atom_names
        )
        VALUES(
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}, 
            {self.SQL_STRING_PLACEHOLDER}
        )
        {self.sql_return_id_str('feature')}
        """

        atom_names = " ".join(sorted(atom_names))

        try:
            self.execute(
                sql,
                (family, target, chain_name, residue_name, residue_number, atom_names),
            )

        except self.ERROR_UNIQUE_VIOLATION as e:

            if warn_duplicate:
                mrich.warning(str(e))
                mrich.var("family", family)
                mrich.var("target", target)
                mrich.var("chain_name", chain_name)
                mrich.var("residue_name", residue_name)
                mrich.var("residue_number", residue_number)
                mrich.var("atom_names", atom_names)

            self.rollback()

            return None

        except Exception as e:
            mrich.error(e)

        feature_id = self.get_lastrowid()

        if commit:
            self.commit()
        return feature_id

    def insert_features(
        self,
        dicts: list[dict],
        commit: bool = True,
    ) -> None:
        """Bulk insert entries into the feature table"""

        from .prolif import FEATURE_FAMILIES

        FEATURE_FAMILIES = set(FEATURE_FAMILIES)

        payload = []

        for d in dicts:

            chain_name = d["chain_name"]
            family = d["family"]
            target = d["target"]
            atom_names = d["atom_names"]
            residue_name = d["residue_name"]
            residue_number = d["residue_number"]

            assert len(chain_name) == 1
            assert len(residue_name) <= 4
            for a in atom_names:
                assert len(a) <= 4
            assert isinstance(target, int)

            atom_names = " ".join(sorted(atom_names))

            if family:
                assert family in FEATURE_FAMILIES, f"Unsupported {family=}"
            else:
                family = "Unknown"

            payload.append(
                (family, target, chain_name, residue_name, residue_number, atom_names)
            )

        match self.engine:
            case "sqlite3":

                sql = """
                INSERT OR IGNORE INTO feature(
                    feature_family, 
                    feature_target, 
                    feature_chain_name, 
                    feature_residue_name, 
                    feature_residue_number, 
                    feature_atom_names
                )
                VALUES(?,?,?,?,?,?)
                """

            case "psycopg":

                sql = """
                INSERT INTO hippo.feature(
                    feature_family, 
                    feature_target, 
                    feature_chain_name, 
                    feature_residue_name, 
                    feature_residue_number, 
                    feature_atom_names
                )
                VALUES(%s,%s,%s,%s,%s,%s)
                ON CONFLICT ON CONSTRAINT uc_feature DO NOTHING;
                """

        try:
            self.executemany(
                sql,
                payload,
            )

        # except self.ERROR_UNIQUE_VIOLATION as e:

        # if warn_duplicate:
        #     mrich.warning(str(e))
        #     mrich.var("family", family)
        #     mrich.var("target", target)
        #     mrich.var("chain_name", chain_name)
        #     mrich.var("residue_name", residue_name)
        #     mrich.var("residue_number", residue_number)
        #     mrich.var("atom_names", atom_names)

        # self.rollback()

        # return None

        except Exception as e:
            mrich.error(e)
            raise

        if commit:
            self.commit()

    def insert_metadata(
        self,
        *,
        table: str,
        id: int,
        payload: dict,
        commit: bool = True,
    ) -> None:
        """Insert metadata into an an existing entry in the compound or pose tables

        :param table: table for insertions ``['pose', 'compound', 'subsite', 'subsite_tag']``
        :param id: associated entry ID
        :param payload: metadata dictionary
        :param commit: commit the changes to the database (Default value = True)

        """

        payload = json.dumps(payload)

        self.update(
            table=table, id=id, key=f"{table}_metadata", value=payload, commit=commit
        )

    def insert_route(
        self,
        *,
        product_id: int,
        commit: bool = True,
    ) -> int:
        """Insert an entry into the route table

        :param product_id: :class:`.Compound` ID of the product
        :param commit: commit the changes to the database (Default value = True)
        :returns: route ID

        """

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}route(route_product)
        VALUES({self.SQL_STRING_PLACEHOLDER})
        """

        product_id = int(product_id)

        try:
            self.execute(sql, (product_id,))

        except Exception as e:
            mrich.error(e)

        route_id = self.cursor.lastrowid

        if commit:
            self.commit()

        return route_id

    def insert_component(
        self,
        *,
        route: int,
        ref: int,
        component_type: int,
        amount: float = 1.0,
        commit: bool = True,
    ) -> int:
        """
        ================ ========== ==============
        component_type   table      ref
        ================ ========== ==============
                      1   reaction   reaction
                      2   compound   reactant
                      3   compound   intermediate
        ================ ========== ==============

        :param route: associated :class:`.Route` ID
        :param ref: ID of the :class:`.Reaction` or :class:`.Compound`
        :param component_type: integer specifying the type of the component
        :param commit: commit the changes to the database (Default value = True)
        :returns: the component ID

        """

        match self.engine:
            case "sqlite3":

                sql = """
                INSERT INTO component(component_route, component_type, component_ref, component_amount)
                VALUES(:component_route, :component_type, :component_ref, :component_amount)
                """

            case "psycopg":

                sql = """
                INSERT INTO hippo.component(component_route, component_type, component_ref, component_amount)
                VALUES(%(component_route)s, %(component_type)s, %(component_ref)s, %(component_amount)s)
                """

        route = int(route)
        ref = int(ref)
        component_type = int(component_type)

        if component_type == 1:
            component_amount = None
        else:
            component_amount = float(amount)
            assert component_amount > 0

        try:
            self.execute(
                sql,
                dict(
                    component_route=route,
                    component_type=component_type,
                    component_ref=ref,
                    component_amount=component_amount,
                ),
            )

        except self.ERROR_UNIQUE_VIOLATION as e:

            mrich.warning(
                f"Did not add existing component={ref} (type={component_type}) to {route=}"
            )

            self.rollback()
            return None

        component_id = self.get_lastrowid()

        if commit:
            self.commit()

        return component_id

    def insert_interaction(
        self,
        *,
        feature: Feature | int,
        pose: Pose | int,
        type: str,
        family: str,
        atom_ids: list[int],
        prot_coord: list[float],
        lig_coord: list[float],
        distance: float,
        angle: float | None = None,
        energy: float | None = None,
        warn_duplicate: bool = True,
        commit: bool = True,
        table: str = "interaction",
    ) -> int:
        """Insert an entry into the interaction table

        :param feature: associated :class:`.Feature` object or ID
        :param pose: associated :class:`.Pose` object or ID
        :param type: interaction type
        :param family: ligand feature type
        :param atom_ids: atom indices of ligand feature
        :param prot_coord: ``[x,y,z]`` coordinate of protein feature
        :param lig_coord: ``[x,y,z]`` coordinate of ligand feature
        :param distance: interaction distance ``Angstrom``
        :param angle: optional interaction angle ``degrees``
        :param energy: energy score ``kcal/mol``, defaults to ``None``
        :param warn_duplicate: print a warning if the pose already exists (Default value = True)
        :param commit: commit the changes to the database (Default value = True)
        :param table: the name of the table to insert into (Default value = 'interaction')
        :returns: the interaction ID
        """

        # validation

        if isinstance(feature, Feature):
            feature = feature.id

        if isinstance(pose, Pose):
            pose = pose.id

        from .prolif import FEATURE_FAMILIES, INTERACTION_TYPES

        if family:
            assert family in FEATURE_FAMILIES, f"Unsupported {family=}"
        else:
            family = "Unknown"

        # assert type in INTERACTION_TYPES.values(), f"Unsupported {type=}"

        assert isinstance(atom_ids, list), f"Unsupported {atom_ids=}"
        assert not any(
            [not isinstance(i, int) for i in atom_ids]
        ), f"Unsupported {atom_ids=}"
        atom_ids = json.dumps(atom_ids)

        prot_coord = list(prot_coord) if prot_coord is not None else []
        assert len(prot_coord) == 3 or not prot_coord, f"Unsupported {prot_coord=}"
        assert not any(
            [not isinstance(i, float) for i in prot_coord]
        ), f"Unsupported {prot_coord=}"
        prot_coord = json.dumps(prot_coord)

        lig_coord = list(lig_coord) if lig_coord is not None else []
        assert len(lig_coord) == 3 or not lig_coord, f"Unsupported {lig_coord=}"
        assert not any(
            [not isinstance(i, float) for i in lig_coord]
        ), f"Unsupported {lig_coord=}"
        lig_coord = json.dumps(lig_coord)

        try:
            distance = float(distance)
        except ValueError:
            raise ValueError(f"Unsupported {distance=}")

        try:
            if angle is not None:
                angle = float(angle)
        except ValueError:
            raise ValueError(f"Unsupported {angle=}")

        if energy is not None:
            try:
                energy = float(energy)
            except ValueError:
                raise ValueError(f"Unsupported {energy=}")

        # insertion

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}{table}(
            interaction_feature,
            interaction_pose,
            interaction_type,
            interaction_family,
            interaction_atom_ids,
            interaction_prot_coord,
            interaction_lig_coord,
            interaction_distance,
            interaction_angle,
            interaction_energy
        )
        VALUES(
            {self.SQL_STRING_PLACEHOLDER},
            {self.SQL_STRING_PLACEHOLDER},
            {self.SQL_STRING_PLACEHOLDER},
            {self.SQL_STRING_PLACEHOLDER},
            {self.SQL_STRING_PLACEHOLDER},
            {self.SQL_STRING_PLACEHOLDER},
            {self.SQL_STRING_PLACEHOLDER},
            {self.SQL_STRING_PLACEHOLDER},
            {self.SQL_STRING_PLACEHOLDER},
            {self.SQL_STRING_PLACEHOLDER}
        );
        """

        try:
            self.execute(
                sql,
                (
                    feature,
                    pose,
                    type,
                    family,
                    atom_ids,
                    prot_coord,
                    lig_coord,
                    distance,
                    angle,
                    energy,
                ),
            )

        except self.ERROR_UNIQUE_VIOLATION as e:
            mrich.error(e)
            if warn_duplicate:
                mrich.warning(
                    f"Skipping existing interaction: {feature=} {pose=} {family=} {atom_ids=}"
                )
            return None

        except Exception as e:
            mrich.error(e)

        interaction_id = self.cursor.lastrowid

        if commit:
            self.commit()

        return interaction_id

    def insert_subsite(self, target: int, name: str, commit: bool = True) -> int:
        """Insert an entry into the subsite table

        :param target: protein :class:`.Target` ID
        :param name: name of the protein subsite/subsite
        :returns: the subsite ID

        """

        assert isinstance(target, int)
        assert isinstance(name, str)

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}subsite(subsite_target, subsite_name)
        VALUES({self.SQL_STRING_PLACEHOLDER}, {self.SQL_STRING_PLACEHOLDER})
        """

        try:
            self.execute(sql, (target, name))

        except self.ERROR_UNIQUE_VIOLATION as e:
            mrich.warning(f"Skipping existing subsite for {target=} with {name=}")
            return None

        except Exception as e:
            mrich.error(e)

        subsite_id = self.cursor.lastrowid
        if commit:
            self.commit()

        return subsite_id

    def insert_subsite_tag(
        self,
        *,
        pose_id: int,
        name: str | None,
        target: int | None = None,
        subsite_id: int | None = None,
        commit: bool = True,
    ) -> int:
        """Insert an entry into the subsite_tag table

        :param pose_id: :class:`.Pose` ID
        :param name: name of the protein subsite/pocket
        :param target: protein :class:`.Target` ID, defaults to querying pose table
        :param target: protein Subsite ID, defaults to querying Subsite table
        :returns: the Subsite ID

        """

        if name is not None:
            assert isinstance(name, str)

        assert isinstance(pose_id, int)

        if not target:
            (target,) = self.select_where(
                table="pose", key="id", value=pose_id, query="pose_target"
            )

        assert isinstance(target, int)

        if not subsite_id:
            subsite_id = self.get_subsite_id(name=name, none="quiet")

        if not subsite_id:
            subsite_id = self.insert_subsite(name=name, target=target)

        assert isinstance(subsite_id, int)

        sql = f"""
        INSERT INTO {self.SQL_SCHEMA_PREFIX}subsite_tag(subsite_tag_ref, subsite_tag_pose)
        VALUES({self.SQL_STRING_PLACEHOLDER}, {self.SQL_STRING_PLACEHOLDER})
        """

        try:
            self.execute(sql, (subsite_id, pose_id))

        except self.ERROR_UNIQUE_VIOLATION as e:
            mrich.warning(
                f"Skipping existing subsite_tag for {subsite_id=} with {pose_id=}"
            )
            return None

        except Exception as e:
            mrich.error(e)

        subsite_tag_id = self.cursor.lastrowid
        if commit:
            self.commit()

        return subsite_tag_id

    def register_route(
        self,
        *,
        recipe: "Recipe",
        commit: bool = True,
    ) -> int:
        """
        Insert a single-product :class:`.Recipe` into the :class:`.Database`.

        :param recipe: The :class:`.Recipe` object to be registered
        :param commit: Commit the changes to the :class:`.Database`, defaults to ``True``
        :returns: The :class:`.Route` ID
        """

        assert recipe.num_products == 1

        # register the route
        route_id = self.insert_route(product_id=recipe.product.id, commit=False)

        assert route_id

        # reactions
        for ref in recipe.reactions.ids:
            self.insert_component(
                component_type=1, ref=ref, route=route_id, commit=False
            )

        # reactants
        for ref, amount in recipe.reactants.id_amount_pairs:
            self.insert_component(
                component_type=2, ref=ref, route=route_id, amount=amount, commit=False
            )

        # intermediates
        for ref, amount in recipe.intermediates.id_amount_pairs:
            self.insert_component(
                component_type=3, ref=ref, route=route_id, amount=amount, commit=False
            )

        if commit:
            self.commit()

        return route_id

    ### SELECTION

    def select(
        self,
        query: str,
        table: str,
        multiple: bool = False,
    ) -> tuple | list[tuple]:
        """Wrapper for the SQL SELECT query, in the following syntax:

        ::

                'SELECT {query} FROM {table}'

        :param query: the columns to return
        :param table: the table from which to select
        :param multiple: fetch all results (Default value = False)
        :returns: the result of the query

        """

        sql = f"SELECT {query} FROM {self.SQL_SCHEMA_PREFIX}{table}"

        try:
            self.execute(sql)
        except sqlite3.OperationalError as e:
            mrich.var("sql", sql)
            raise

        if multiple:
            result = self.cursor.fetchall()
        else:
            result = self.cursor.fetchone()

        return result

    def select_where(
        self,
        query: str,
        table: str,
        key: str,
        value: str | None = None,
        multiple: bool = False,
        none: str | None = "error",
        sort: str = None,
        debug: bool = False,
    ) -> tuple | list[tuple]:
        """Select entries where ``key == value``

        Examples
        ========

        Find compound alias with matching ID:

        ::

                animal.db.select_where(
                        query='compound_alias',
                        table='compound',
                        key='id',
                        value='123',
                )

                # the above evaluates to:
                'SELECT compound_id FROM compound WHERE compound_id = 123'

        Find compound aliases with ID below 10 and order alphabetically:

        ::

                animal.db.select_where(
                        query='compound_alias',
                        table='compound',
                        key='compound_id < 10',
                        multiple=True,
                        sort='compound_alias',
                )

                # the above evaluates to:
                'SELECT compound_id FROM compound WHERE compound_id < 10 ORDER BY compound_alias'

        Parameters
        ==========

        :param query: the columns to return
        :param table: the table from which to select
        :param key: column name to match to value, if no ``value`` is provided the key argument should contain the a SQL string to select entries
        :param value: the value to match (Default value = None)
        :param multiple: fetch all results (Default value = False)
        :param none: define the behaviour for no matches, any value other than ``'error'`` will silently return empty data (Default value = 'error')
        :param sort: optionally sort the output (Default value = None)
        :returns: the result of the query

        """

        if isinstance(value, str):
            if "'" in value:
                value = f'"{value}"'
            else:
                value = f"'{value}'"

        if value is not None:
            where_str = f"{table}_{key}={value}"
        else:
            where_str = key

        if sort:
            sql = f"SELECT {query} FROM {self.SQL_SCHEMA_PREFIX}{table} WHERE {where_str} ORDER BY {sort}"
        else:
            sql = (
                f"SELECT {query} FROM {self.SQL_SCHEMA_PREFIX}{table} WHERE {where_str}"
            )

        if debug:
            mrich.print(strip_sql(sql))

        try:
            self.execute(sql)
        except sqlite3.OperationalError as e:
            mrich.var("sql", strip_sql(sql))
            raise

        if multiple:
            result = self.cursor.fetchall()
        else:
            result = self.cursor.fetchone()

        if not result and none == "error":
            mrich.error(f"No entry in {self.SQL_SCHEMA_PREFIX}{table} with {where_str}")
            return None
        elif not result and none == "exception":
            raise ValueError(
                f"No entry in {self.SQL_SCHEMA_PREFIX}{table} with {where_str}"
            )

        # if not result:
        #     raise ValueError(f"No entry in {table} with {where_str}")

        return result

    def select_id_where(
        self,
        table: str,
        key: str,
        value: str | None = None,
        multiple: bool = False,
        none: str | None = "error",
    ) -> tuple | list[tuple]:
        """Select ID's where ``key==value``. Similar to :meth:`.select_where` except the query argument is always ``{table}_id``.

        :param table: the table from which to select
        :param key: column name to match to value, if no ``value`` is provided this
        :param value: the value to match (Default value = None)
        :param multiple: fetch all results (Default value = False)
        :param none: define the behaviour for no matches, any value other than ``'error'`` will silently return empty data (Default value = 'error')
        :returns: the result of the query

        """
        return self.select_where(
            query=f"{table}_id",
            table=table,
            key=key,
            value=value,
            multiple=multiple,
            none=none,
        )

    def select_all_where(
        self,
        table: str,
        key: str,
        value: str | None = None,
        multiple: bool = False,
        none: str | None = "error",
    ) -> tuple | list[tuple]:
        """Select entries where ``key==value``. Similar to :meth:`.select_where` except the query argument is always ``*``.

        :param table: the table from which to select
        :param key: column name to match to value, if no ``value`` is provided this
        :param value: the value to match (Default value = None)
        :param multiple: fetch all results (Default value = False)
        :param none: define the behaviour for no matches, any value other than ``'error'`` will silently return empty data (Default value = 'error')
        :returns: the result of the query

        """
        return self.select_where(
            query="*", table=table, key=key, value=value, multiple=multiple, none=none
        )

    ### DELETION

    def delete_where(
        self,
        table: str,
        key: str,
        value: str | None = None,
        commit: bool = True,
    ) -> None:
        """Delete entries where ``key==value``

        :param table: the table from which to delete
        :param key: column name to match to value, if no ``value`` is provided this
        :param value: the value to match (Default value = None)
        :param commit: commit the changes (Default value = True)

        """

        if value is not None:

            if isinstance(value, str):
                value = f"'{value}'"

            sql = f"DELETE FROM {self.SQL_SCHEMA_PREFIX}{table} WHERE {table}_{key}={value}"

        else:

            sql = f"DELETE FROM {self.SQL_SCHEMA_PREFIX}{table} WHERE {key}"

        try:
            result = self.execute(sql)

        except sqlite3.OperationalError as e:
            mrich.var("sql", sql)
            raise

        if commit:
            self.commit()

    def delete_tag(
        self,
        tag: str,
    ) -> None:
        """Delete all tag entries with the matching name

        :param tag: tag name to match

        """
        self.delete_where(table="tag", key="name", value=tag)

    def delete_interactions(self) -> None:
        """Delete all calculated interactions and set pose_fingerprint appropriately"""

        self.delete_where(table="interaction", key="interaction_id > 0")
        self.update_all(table="pose", key="pose_fingerprint", value=0)

    def delete_features(self) -> None:
        """Delete all protein features"""

        self.delete_where(table="feature", key="feature_id > 0")

    def delete_reactions(self) -> None:
        """Delete all reaction data"""

        tables = ["reaction", "reactant", "route", "component"]

        for table in tables:
            self.execute(f"DELETE FROM {self.SQL_SCHEMA_PREFIX}{table};")
        self.commit()

    def delete_subsites(self) -> None:
        """Delete all protein subsites"""

        self.delete_where(table="subsite", key="subsite_id > 0")
        self.delete_where(table="subsite_tag", key="subsite_tag_id > 0")

    ### UPDATE

    def update(
        self,
        *,
        table: str,
        id: int,
        key: str,
        value,
        commit: bool = True,
    ) -> int:
        """Update a field in a database entry with given ID

        :param table: the table which to update
        :param id: the ID of the entry to update
        :param key: column name to update
        :param value: the value to insert
        :param commit: commit the changes to the database (Default value = True)
        :returns: the ID of the modified entry

        """

        sql = f"""
        UPDATE {self.SQL_SCHEMA_PREFIX}{table}
        SET {key} = {self.SQL_STRING_PLACEHOLDER}
        WHERE {table}_id = {id}
        {self.sql_return_id_str(table)};
        """

        try:
            self.execute(sql, (value,))
        except self.ERROR_UNIQUE_VIOLATION as e:
            mrich.var("sql", sql)
            self.rollback()
            raise

        id = self.get_lastrowid()

        if commit:
            self.commit()

        return id

    def update_all(
        self,
        *,
        table: str,
        key: str,
        value,
        commit: bool = True,
    ) -> None:
        """Update all fields in a table column at once

        :param table: the table which to update
        :param key: column name to update
        :param value: the value to insert
        :param commit: commit the changes to the database (Default value = True)

        """

        sql = f"""
        UPDATE {self.SQL_SCHEMA_PREFIX}{table}
        SET {key} = ?
        """

        try:
            self.execute(sql, (value,))
        except sqlite3.OperationalError as e:
            mrich.var("sql", sql)
            raise

        if commit:
            self.commit()

    def update_pose_mol(self, pose_id: int, mol: "Chem.Mol") -> None:
        """Update the molecule stored for a specific pose"""

        self.update(table="pose", id=pose_id, key="pose_mol", value=mol.ToBinary())

    ### COPYING / MIGRATION

    def copy_temp_interactions(self, source_db: "Database | None" = None) -> None:
        """Copy the records from the 'temp_interaction' table to the 'interaction' table"""

        if source_db is not None:

            sql = """
            SELECT
                interaction_feature,
                interaction_pose,
                interaction_type,
                interaction_family,
                interaction_atom_ids,
                interaction_prot_coord,
                interaction_lig_coord,
                interaction_distance,
                interaction_angle,
                interaction_energy
            FROM temp_interaction
            """

            cursor = source_db.execute(sql)
            records = cursor.fetchall()

            cursor = self.executemany(self.SQL_BULK_INSERT_INTERACTIONS, records)

        else:

            sql = f"""
            INSERT OR IGNORE INTO {self.SQL_SCHEMA_PREFIX}interaction(
                interaction_feature, 
                interaction_pose, 
                interaction_type, 
                interaction_family, 
                interaction_atom_ids, 
                interaction_prot_coord, 
                interaction_lig_coord, 
                interaction_distance, 
                interaction_angle, 
                interaction_energy
            )
            SELECT {self.SQL_SCHEMA_PREFIX}interaction_feature, 
                interaction_pose, 
                interaction_type, 
                interaction_family, 
                interaction_atom_ids, 
                interaction_prot_coord, 
                interaction_lig_coord, 
                interaction_distance, 
                interaction_angle, 
                interaction_energy 
            FROM temp_interaction
            """

            cursor = self.execute(sql)

    def copy_interactions_to_temp(self, pose_id: int) -> int:
        """Copy the records from the 'interaction' table to the 'temp_interaction' table for a given pose_id

        :returns: ID of the last inserted :class:`.Interaction`
        """

        cursor = self.execute(f"""
            INSERT OR IGNORE INTO {self.SQL_SCHEMA_PREFIX}temp_interaction(
                interaction_feature, 
                interaction_pose, 
                interaction_type, 
                interaction_family, 
                interaction_atom_ids, 
                interaction_prot_coord, 
                interaction_lig_coord, 
                interaction_distance, 
                interaction_angle, 
                interaction_energy
            )
            SELECT interaction_feature, 
                interaction_pose, 
                interaction_type, 
                interaction_family, 
                interaction_atom_ids, 
                interaction_prot_coord, 
                interaction_lig_coord, 
                interaction_distance, 
                interaction_angle, 
                interaction_energy 
            FROM {self.SQL_SCHEMA_PREFIX}interaction
            WHERE interaction_pose = {pose_id}
        """)

        return cursor.lastrowid

    def migrate_legacy_scaffolds(self) -> int:
        """Migrate legacy compound_scaffold records from the 'compound' table to the 'scaffold' table

        :returns: ID of the last inserted scaffold record
        """

        mrich.debug("HIPPO.Database.migrate_legacy_scaffolds()")

        cursor = self.execute(f"""
            INSERT INTO {self.SQL_SCHEMA_PREFIX}scaffold(scaffold_base, scaffold_superstructure)
            SELECT compound_base, compound_id FROM compound
            WHERE compound_base IS NOT NULL
            """)

        self.commit()

        return cursor.lastrowid

    def update_legacy_routes(self) -> None:
        """Update legacy component entries"""

        # add column

        sql = f"""
        ALTER TABLE {self.SQL_SCHEMA_PREFIX}component
        ADD component_amount REAL;
        """

        self.execute(sql)

        # set values

        match self.engine:
            case "sqlite3":

                sql = """
                UPDATE component
                SET component_amount = :component_amount
                WHERE component_type = :component_type;
                """

            case "psycopg":

                sql = """
                UPDATE hippo.component
                SET component_amount = %(component_amount)s
                WHERE component_type = %(component_type)s;
                """

        self.execute(sql, dict(component_amount=None, component_type=1))
        self.execute(sql, dict(component_amount=1.0, component_type=2))
        self.execute(sql, dict(component_amount=1.0, component_type=3))

    def update_legacy_reaction_metadata(self) -> None:
        """Add reaction_metadata column"""

        sql = f"""
        ALTER TABLE {self.SQL_SCHEMA_PREFIX}reaction
        ADD reaction_metadata TEXT;
        """

        self.execute(sql)

    def update_legacy_pose_inspiration_score(self) -> None:
        """Add pose_inspiration_score column"""

        sql = f"""
        ALTER TABLE {self.SQL_SCHEMA_PREFIX}pose
        ADD pose_inspiration_score REAL;
        """

        self.execute(sql)

    def update_compound_pattern_bfp_table(self):
        """Update the compound pattern BFP table"""
        self.execute(f"""
            INSERT INTO compound_pattern_bfp
            SELECT c.compound_id, c.compound_pattern_bfp FROM {self.SQL_SCHEMA_PREFIX}compound AS c
            LEFT JOIN compound_pattern_bfp as fp
            ON c.compound_id = fp.compound_id
            WHERE fp.compound_id IS NULL
        """)

    ### BULK CLEANUP

    def prune_duplicate_routes(self) -> None:
        """Remove duplicate routes from the database"""

        from collections import Counter

        sql = f"""
        SELECT route_id, route_product, component_ref, component_type FROM {self.SQL_SCHEMA_PREFIX}route
        INNER JOIN {self.SQL_SCHEMA_PREFIX}component ON route_id = component_route
        """

        records = self.execute(sql).fetchall()

        routes = {}

        for route_id, route_product, component_ref, component_type in records:
            if route_id not in routes:
                routes[route_id] = (route_product, set())

            key = (component_ref, component_type)
            routes[route_id][1].add(key)

        routes = {key: (value[0], tuple(value[1])) for key, value in routes.items()}

        flat_routes = [value for key, value in routes.items()]

        mrich.var("#routes", len(flat_routes))

        counter = Counter(flat_routes)
        duplicates = {item: count for item, count in counter.items() if count > 1}

        mrich.var("products with duplicate routes", len(duplicates))

        if not duplicates:
            mrich.success("No duplicate routes found")
            return None

        delete = set()
        for dupe in duplicates:
            matched_ids = [k for k, v in routes.items() if v == dupe]
            mrich.print(
                "compound", dupe[0], "has", len(matched_ids), "duplicate routes"
            )
            for route_id in matched_ids[1:]:
                delete.add(route_id)

        str_ids = str(tuple(delete)).replace(",)", ")")
        self.delete_where(table="component", key=f"component_route IN {str_ids}")
        self.delete_where(table="route", key=f"route_id IN {str_ids}")

        mrich.success("Deleted", len(delete), "duplicate routes")

        return delete

    def reinitialise_molecules(self):
        """In the case where the Mol binaries in a database are throwing unpickling errors, run this to reinitialise them all from their smiles."""

        mrich.var("#compounds", self.count("compound"))

        sql = f"""
        UPDATE {self.SQL_SCHEMA_PREFIX}compound
        SET compound_mol = {self.SQL_SCHEMA_PREFIX}mol_from_smiles(compound_smiles);
        """

        with mrich.loading("Reinitialising compounds..."):
            self.execute(sql)

        mrich.success("compound_mol records updated")

    def fix_incorrect_pose_compound_assignments(self):
        """Fix pose_compound values that reference incorrect chemical structures"""

        lookup = self.get_compound_id_smiles_dict()
        lookup = {v: k for k, v in lookup.items()}

        count = self.count_where(table="pose", key="mol", value="NOT null")

        match self.engine:
            case "sqlite3":
                sql = """
                SELECT pose_id, pose_compound, mol_to_smiles(mol_from_binary_mol(pose_mol))
                FROM pose
                WHERE pose_mol IS NOT null
                """
            case "psycopg":
                sql = """
                SELECT pose_id, pose_compound, hippo.mol_to_smiles(hippo.mol_from_pkl(pose_mol))
                FROM hippo.pose
                WHERE pose_mol IS NOT null
                """

        c = self.execute(sql)

        fix = set()
        fix_count = 0
        for pose_id, pose_compound, smiles in mrich.track(c, total=count):
            try:
                flat_smiles = sanitise_smiles(smiles)
            except Exception as e:
                mrich.error("Could not sanitise", pose_id, smiles)

            comp_id = lookup.get(flat_smiles)

            if not comp_id:
                mrich.error("No matching compound", pose_id, smiles)
                continue

            if comp_id != pose_compound:
                fix.add((comp_id, pose_id))
                fix_count += 1
                mrich.set_progress_field("#fix", fix_count)

        mrich.var("#fix", len(fix))

        sql = f"""
        UPDATE {self.SQL_SCHEMA_PREFIX}pose
        SET pose_compound = {self.SQL_STRING_PLACEHOLDER}
        WHERE pose_id = {self.SQL_STRING_PLACEHOLDER}
        """

        self.executemany(sql, list(fix))
        self.commit()

    ### BULK REGISTRATION

    def register_compounds(
        self,
        *,
        smiles: list[str],
        radical: str = "warning",
        sanitisation_verbosity: bool = True,
        sanitise: bool = True,
        debug: bool = False,
    ) -> list[tuple[str, str]]:
        """Bulk register compounds"""

        values = []

        if len(smiles) > 1000:
            generator = mrich.track(smiles, prefix="Sanitising...")
        else:
            generator = smiles

        for s in generator:

            if sanitise:
                try:
                    new_smiles = sanitise_smiles(
                        s,
                        sanitisation_failed="error",
                        radical=radical,
                        verbosity=sanitisation_verbosity,
                    )
                except SanitisationError as e:
                    mrich.error(f"Could not sanitise {s=}")
                    mrich.error(str(e))
                    continue
                except AssertionError:
                    mrich.error(f"Could not sanitise {s=}")
                    continue
            else:
                new_smiles = s

            inchikey = inchikey_from_smiles(new_smiles)
            values.append((inchikey, new_smiles))

        if self.auto_compute_bfps:

            sql = f"""
            INSERT OR IGNORE INTO {self.SQL_SCHEMA_PREFIX}compound(
                compound_inchikey, 
                compound_smiles, 
                compound_mol, 
                compound_pattern_bfp, 
                compound_morgan_bfp
            )
            VALUES(
                ?1, 
                ?2, 
                mol_from_smiles(?2), 
                mol_pattern_bfp(mol_from_smiles(?2), 2048), 
                mol_morgan_bfp(mol_from_smiles(?2), 2, 2048)
            )
            """

            self.executemany(sql, values)

        else:

            match self.engine:
                case "sqlite3":
                    sql = """
                    INSERT OR IGNORE INTO compound(compound_inchikey, compound_smiles, compound_mol)
                    VALUES(?1, ?2, mol_from_smiles(?2))
                    """

                    if debug:
                        mrich.debug("Inserting...")

                    self.executemany(sql, values)

                case "psycopg":
                    sql = """
                    INSERT INTO hippo.compound(compound_inchikey, compound_smiles, compound_mol)
                    VALUES(
                        %(inchikey)s, 
                        %(smiles)s, 
                        hippo.mol_from_smiles(%(smiles)s)
                    )
                    ON CONFLICT DO NOTHING;
                    """

                    self.executemany(
                        sql, [dict(inchikey=i, smiles=s) for i, s in values]
                    )

        if self.auto_compute_bfps:
            self.update_compound_pattern_bfp_table()

        self.commit()

        return values

    def register_poses(self, dicts: list[dict]) -> set[int]:
        """Insert or ignore a bunch of poses, also returns a set of Pose IDs

        :param dicts: a list of dictionaries describing the poses to be inserted. See the expected format below:

        dicts = [
            dict(
                alias=...,           # string can be None
                reference_id=...,    # reference pose id
                inchikey=...,        # pre-computed inchikey
                smiles=...,          # SMILEs
                path=...,            # path to mol-file on disk, used for uniqueness check, can be a fake path
                compound_id=...,     # Compound database ID
                target_id=...,       # Target database ID
                mol=...,             # rdkit.Chem.Mol
                energy_score=...,    # float, can be None
                distance_score=...,  # float, can be None
                metadata=...,        # dictionary, can be empty
            )
        ]

        """

        from json import dumps

        ### POSES

        match self.engine:
            case "sqlite3":
                sql = """
                INSERT OR IGNORE INTO pose(
                    pose_inchikey, 
                    pose_smiles, 
                    pose_alias, 
                    pose_reference, 
                    pose_path, 
                    pose_compound, 
                    pose_target, 
                    pose_mol, 
                    pose_energy_score, 
                    pose_distance_score, 
                    pose_metadata
                )
                VALUES(
                    :inchikey, 
                    :smiles, 
                    :alias, 
                    :reference, 
                    :path, 
                    :compound, 
                    :target, 
                    :mol, 
                    :energy_score, 
                    :distance_score, 
                    :metadata
                )
                """

            case "psycopg":
                sql = """
                INSERT INTO hippo.pose(
                    pose_inchikey, 
                    pose_smiles, 
                    pose_alias, 
                    pose_reference, 
                    pose_path, 
                    pose_compound, 
                    pose_target, 
                    pose_mol, 
                    pose_energy_score, 
                    pose_distance_score, 
                    pose_metadata
                )
                VALUES(
                    %(inchikey)s, 
                    %(smiles)s, 
                    %(alias)s, 
                    %(reference)s, 
                    %(path)s, 
                    %(compound)s, 
                    %(target)s, 
                    %(mol)s, 
                    %(energy_score)s, 
                    %(distance_score)s, 
                    %(metadata)s
                )
                ON CONFLICT DO NOTHING;
                """

        values = []
        for i, d in enumerate(dicts):

            alias = d["alias"]
            reference_id = d.get("reference_id")
            if reference_id:
                reference_id = int(reference_id)

            if not alias:
                alias = None

            try:
                values.append(
                    dict(
                        inchikey=str(d["inchikey"]),
                        smiles=str(d["smiles"]),
                        alias=alias,
                        reference=reference_id,
                        path=str(d["path"]),
                        compound=int(d["compound_id"]),
                        target=int(d["target_id"]),
                        mol=d["mol"].ToBinary(),
                        energy_score=float(d["energy_score"]),
                        distance_score=float(d["distance_score"]),
                        metadata=dumps(d["metadata"]),
                    )
                )
            except KeyError as e:
                mrich.error("Skipping", i, str(e))

        self.executemany(sql, values)
        self.commit()

        ### INSPIRATIONS

        lookup = self.get_pose_path_id_dict()

        values = []
        pose_ids = set()

        for i, d in enumerate(dicts):
            if "inspiration_ids" not in d:
                continue
            derivative_id = lookup.get(str(d["path"]))
            if not derivative_id:
                mrich.error("Could not get derivative by path:", str(d["path"]))
                continue
            pose_ids.add(derivative_id)
            for inspiration_id in d["inspiration_ids"]:
                values.append((inspiration_id, derivative_id))

        match self.engine:
            case "sqlite3":
                sql = """
                INSERT OR IGNORE INTO inspiration(inspiration_original, inspiration_derivative)
                VALUES(?1, ?2)
                """

            case "psycopg":
                sql = """
                INSERT INTO hippo.inspiration(inspiration_original, inspiration_derivative)
                VALUES(%s, %s)
                ON CONFLICT DO NOTHING;
                """

        self.executemany(sql, values)
        self.commit()

        return pose_ids

    def calculate_all_scaffolds(self) -> None:
        """Determine and insert records for all substructure/superstructure relationships in the Compound table"""

        n_before = self.count("scaffold")

        mrich.var("#compounds", self.count("compound"))
        mrich.var("#scaffold defs", n_before)

        sql = """
        SELECT compound_id, compound_mol, compound_pattern_bfp 
        FROM compound
        """

        with mrich.loading("Fetching compounds..."):
            records = self.execute(sql).fetchall()

        self.commit()

        sql = """
        INSERT OR IGNORE INTO scaffold
        SELECT ?1, c.compound_id 
        FROM compound AS c, compound_pattern_bfp AS fp
        WHERE c.compound_id = fp.compound_id
        AND c.compound_id <> ?1
        AND mol_is_substruct(c.compound_mol, ?2)
        AND fp.compound_id MATCH rdtree_subset(?3)
        """

        with mrich.loading("Calculating scaffolds..."):
            t1 = time.time()
            self.executemany(sql, records)
            mrich.print("Took", f"{time.time() - t1:.1f}", "seconds")

        self.commit()

        diff = self.count("scaffold") - n_before

        if diff:
            mrich.success(
                "Found", diff, "new substructure-superstructure relationships"
            )
        else:
            mrich.warning(
                "Found", diff, "new substructure-superstructure relationships"
            )

    def calculate_all_murcko_scaffolds(
        self, generic: bool = True
    ) -> "dict | (dict, dict)":
        """Determine Murcko and optionally generic Murcko scaffolds for all Compounds in the Database and add relevant records.

        :param generic: Calculate generic (single bonds and all carbon) scaffolds as well
        """

        n_before = self.count("scaffold")

        mrich.var("#compounds", self.count("compound"))
        mrich.var("#scaffold defs", n_before)

        from rdkit.Chem import MolFromSmiles, MolToSmiles
        from rdkit.Chem.Scaffolds.MurckoScaffold import (
            MurckoScaffoldSmiles,
            MakeScaffoldGeneric,
        )

        compound_records = self.select(
            query="compound_id, compound_smiles", table="compound", multiple=True
        )

        ### CALCULATE SCAFFOLDS

        murcko_data = {}
        generic_data = {}
        generic_to_murcko = {}
        for c_id, smiles in mrich.track(compound_records):

            # murcko

            try:
                murcko_smiles = sanitise_smiles(MurckoScaffoldSmiles(smiles))
            except KeyboardInterrupt:
                raise
            except:
                mrich.error("can't make murcko:", smiles)
                continue

            if murcko_smiles not in murcko_data:
                murcko_data[murcko_smiles] = set()

            murcko_data[murcko_smiles].add(c_id)

            # generic

            if generic:

                try:
                    generic_smiles = sanitise_smiles(
                        MolToSmiles(MakeScaffoldGeneric(MolFromSmiles(murcko_smiles)))
                    )
                except KeyboardInterrupt:
                    raise
                except:
                    mrich.error("can't make generic:", murcko_smiles)
                    continue

                if generic_smiles not in generic_data:
                    generic_data[generic_smiles] = set()

                if generic_smiles not in generic_to_murcko:
                    generic_to_murcko[generic_smiles] = set()

                generic_data[generic_smiles].add(c_id)
                generic_to_murcko[generic_smiles].add(murcko_smiles)

        mrich.var("#murcko scaffolds", len(murcko_data))
        mrich.var("#generic murcko scaffolds", len(generic_data))

        ### REGISTER MURCKOS

        murcko_values = self.register_compounds(
            smiles=murcko_data.keys(), sanitisation_verbosity=False, sanitise=False
        )
        murcko_s2i = {s: i for i, s in murcko_values}

        ### REGISTER GENERICS

        if generic:
            generic_values = self.register_compounds(
                smiles=generic_data.keys(), sanitisation_verbosity=False, sanitise=False
            )
            generic_s2i = {s: i for i, s in generic_values}

        ### TAG MURCKOS

        murcko_ids = self.select_id_where(
            table="compound",
            key=f"compound_inchikey IN {tuple(murcko_s2i.values())}",
            multiple=True,
        )

        match self.engine:
            case "sqlite3":
                sql = """
                INSERT OR IGNORE INTO tag(tag_name, tag_compound) 
                VALUES (?,?)
                """
            case "psycopg":
                sql = """
                INSERT INTO hippo.tag(tag_name, tag_compound) 
                VALUES (%s,%s)
                ON CONFLICT DO NOTHING;
                """

        self.executemany(
            sql,
            [("MurckoScaffold", i) for i, in murcko_ids],
        )

        ### TAG GENERICS

        if generic:

            generic_ids = self.select_id_where(
                table="compound",
                key=f"compound_inchikey IN {tuple(generic_s2i.values())}",
                multiple=True,
            )

            self.executemany(
                sql,
                [("GenericMurckoScaffold", i) for i, in generic_ids],
            )

        ### ADD MURCKO SCAFFOLD RELATIONS

        pairs = []

        murcko_inchikey_lookup = self.get_compound_inchikey_id_dict(murcko_s2i.values())
        for murcko_smiles, c_ids in murcko_data.items():
            murcko_id = murcko_inchikey_lookup[murcko_s2i[murcko_smiles]]
            for c_id in c_ids:
                pairs.append((murcko_id, c_id))

        pairs = [(a, b) for a, b in pairs if a != b]

        mrich.var("#murcko scaffold relations", len(pairs))

        match self.engine:
            case "sqlite3":
                sql = """
                INSERT OR IGNORE INTO scaffold (scaffold_base, scaffold_superstructure) 
                VALUES (?,?)
                """

            case "psycopg":
                sql = """
                INSERT INTO hippo.scaffold (scaffold_base, scaffold_superstructure) 
                VALUES (%s, %s)
                ON CONFLICT DO NOTHING;
                """

        self.executemany(
            sql,
            pairs,
        )

        ### ADD GENERIC SCAFFOLD RELATIONS

        if generic:

            pairs = []

            generic_inchikey_lookup = self.get_compound_inchikey_id_dict(
                generic_s2i.values()
            )
            for generic_smiles, c_ids in generic_data.items():
                generic_id = generic_inchikey_lookup[generic_s2i[generic_smiles]]
                for c_id in c_ids:
                    pairs.append((generic_id, c_id))

            for generic_smiles, murcko_smiles_list in generic_to_murcko.items():
                generic_id = generic_inchikey_lookup[generic_s2i[generic_smiles]]
                for murcko_smiles in murcko_smiles_list:
                    murcko_id = murcko_inchikey_lookup[murcko_s2i[murcko_smiles]]
                    pairs.append((generic_id, murcko_id))

            pairs = [(a, b) for a, b in pairs if a != b]

            mrich.var("#generic murcko scaffold relations", len(pairs))

            self.executemany(
                "INSERT OR IGNORE INTO scaffold (scaffold_base, scaffold_superstructure) VALUES (?,?)",
                pairs,
            )

        self.commit()

        if generic:
            return murcko_data, generic_data
        else:
            return murcko_data

    def set_derivative_subsites(self, commit: bool = True) -> None:
        """Propagate all subsite assignments from inspirations to their derivatives"""

        match self.engine:
            case "sqlite3":
                sql = """
                INSERT OR IGNORE INTO subsite_tag(subsite_tag_ref, subsite_tag_pose)
                SELECT subsite_tag_ref, inspiration_derivative FROM subsite_tag
                INNER JOIN inspiration ON subsite_tag_pose = inspiration_original
                """

            case "psycopg":
                sql = """
                INSERT INTO hippo.subsite_tag(subsite_tag_ref, subsite_tag_pose)
                SELECT subsite_tag_ref, inspiration_derivative FROM hippo.subsite_tag
                INNER JOIN hippo.inspiration ON subsite_tag_pose = inspiration_original
                ON CONFLICT DO NOTHING;
                """

        self.execute(sql)

        if commit:
            self.commit()

    def set_subsites_from_metadata_field(
        self, pose_str_ids: str, field="CanonSites alias"
    ) -> None:
        """Create and assign subsite entries from a metadata field

        :param pose_str_ids: pose_str_ids
        :param field: the metadata field to use

        """

        from json import loads

        records = self.select_where(
            table="pose",
            query="pose_id, pose_target, pose_metadata",
            key=f"pose_id IN {pose_str_ids}",
            multiple=True,
        )

        subsites = set()
        subsite_tags = set()

        for pose_id, pose_target, metadata in records:

            metadata = loads(metadata)

            key = metadata.get(field)

            if not key:
                mrich.warning(field, "not in metadata pose_id=", pose_id)
                continue

            subsites.add((pose_target, key))
            subsite_tags.add((pose_target, key, pose_id))

        match self.engine:
            case "sqlite3":
                sql = """
                INSERT OR IGNORE INTO subsite(subsite_target, subsite_name)
                VALUES(?, ?)
                """
            case "psycopg":
                sql = strip_sql("""
                INSERT INTO hippo.subsite(subsite_target, subsite_name)
                VALUES(%s, %s)
                ON CONFLICT DO NOTHING;
                """)

        self.executemany(sql, sorted(list(subsites)))

        subsite_records = self.select(
            table="subsite",
            query="subsite_id, subsite_target, subsite_name",
            multiple=True,
        )

        subsite_lookup = {(t, name): i for i, t, name in subsite_records}

        match self.engine:
            case "sqlite3":
                sql = """
                INSERT OR IGNORE INTO subsite_tag(subsite_tag_ref, subsite_tag_pose)
                VALUES(?, ?)
                """
            case "psycopg":
                sql = strip_sql("""
                INSERT INTO hippo.subsite_tag(subsite_tag_ref, subsite_tag_pose)
                VALUES(%s, %s)
                ON CONFLICT DO NOTHING;
                """)

        subsite_tags = [
            (subsite_lookup[(t, name)], pose_id) for t, name, pose_id in subsite_tags
        ]

        self.executemany(sql, subsite_tags)

        self.commit()

    ### GETTERS

    def get_compound(
        self,
        *,
        id: int | None = None,
        inchikey: str | None = None,
        alias: str | None = None,
        smiles: str | None = None,
        none: str = "error",
        **kwargs,
    ) -> Compound:
        """Get a :class:`.Compound` using one of the following fields: ['id', 'inchikey', 'alias', 'smiles']

        :param id: the ID to search for (Default value = None)
        :param inchikey: the InChi-Key to search for (Default value = None)
        :param alias: the alias to search for (Default value = None)
        :param smiles: the smiles to search for (Default value = None)
        :returns: the :class:`.Compound` object

        """

        if id is None:
            id = self.get_compound_id(
                inchikey=inchikey, smiles=smiles, alias=alias, none=none, **kwargs
            )

        if not id:
            if none == "error":
                mrich.error(f"Invalid {id=}")
            return None

        query = "compound_id, compound_inchikey, compound_alias, compound_smiles"
        entry = self.select_where(
            query=query, table="compound", key="id", value=id, none=none, **kwargs
        )
        compound = Compound(self._animal, self, *entry, metadata=None, mol=None)
        return compound

    def get_compound_id(
        self,
        *,
        inchikey: str | None = None,
        alias: str | None = None,
        smiles: str | None = None,
        **kwargs,
    ) -> int:
        """Get a compound's ID using one of the following fields: ['inchikey', 'alias', 'smiles']

        :param inchikey: the InChi-Key to search for (Default value = None)
        :param alias: the alias to search for (Default value = None)
        :param smiles: the smiles to search for (Default value = None)
        :returns: the :class:`.Compound` ID

        """

        if inchikey:
            entry = self.select_id_where(
                table="compound", key="inchikey", value=inchikey, **kwargs
            )

        elif alias:
            entry = self.select_id_where(
                table="compound", key="alias", value=alias, **kwargs
            )

        elif smiles:
            entry = self.select_id_where(
                table="compound", key="smiles", value=smiles, **kwargs
            )

        else:
            raise NotImplementedError

        if entry:
            return entry[0]

        return None

    def get_compound_mol(
        self,
        compound_id: int,
    ) -> "Chem.Mol":
        """Get the rdkit.Chem.Mol for a given :class:`.Compound`"""

        from rdkit.Chem import Mol

        (bytestr,) = self.select_where(
            query="mol_to_binary_mol(compound_mol)",
            table="compound",
            key="id",
            value=compound_id,
        )

        return Mol(bytestr)

    def get_compound_computed_property(
        self,
        prop: str,
        compound_id: int,
    ) -> int | str:
        """Use chemicalite to calculate a property from the stored binary molecule

        :param prop: the property to calculate [num_heavy_atoms, formula, num_rings]
        :param compound_id: the compound ID to query
        :returns: the value of the computed property

        """

        function = self.COMPOUND_PROPERTY_FUNCTIONS[prop]

        if not isinstance(function, str):
            function, extra = function
        else:
            extra = ""

        (val,) = self.select_where(
            query=f"{function}(compound_mol{extra})",
            table="compound",
            key="id",
            value=compound_id,
            multiple=False,
        )
        return val

    def get_pose(
        self,
        *,
        id: int | None = None,
        inchikey: str = None,
        alias: str = None,
        debug: bool = False,
    ) -> Pose:
        """Get a pose using one of the following fields: ['id', 'inchikey', 'alias']

        :param id: the ID to search for (Default value = None)
        :param inchikey: the InChi-Key to search for (Default value = None)
        :param alias: the alias to search for (Default value = None)
        :returns: the :class:`.Pose` object

        """

        if id is None:
            id = self.get_pose_id(inchikey=inchikey, alias=alias)

        if isinstance(id, list):
            from .pset import PoseSet

            return PoseSet(self, id)

        if not id:
            mrich.error(f"Invalid {id=}")
            return None

        query = ", ".join(self.POSE_FIELDS)

        entry = self.select_where(query=query, table="pose", key="id", value=id)

        if debug:
            mrich.print(entry)

        pose = Pose(self, *entry)
        return pose

    def get_poses(
        self,
        *,
        ids: list[int],
    ) -> list[Pose]:
        """Get list of initialised :class:`.Pose` objects with given ID's"""

        query = ", ".join(self.POSE_FIELDS)

        str_ids = str(tuple(ids)).replace(",)", ")")

        records = self.select_where(
            query=query, table="pose", key=f"pose_id IN {str_ids}", multiple=True
        )

        poses = [Pose(self, *entry) for entry in records]

        return poses

    def get_pose_id(
        self,
        *,
        inchikey: str | None = None,
        alias: str | None = None,
    ) -> int:
        """Get a pose's ID using one of the following fields: ['inchikey', 'alias', 'smiles']

        :param table: the table from which to get the entry (Default value = 'pose')
        :param inchikey: the InChi-Key to search for (Default value = None)
        :param alias: the alias to search for (Default value = None)
        :returns: the :class:`.Pose` ID

        """

        if inchikey:
            # inchikey might not be unique
            entries = self.select_id_where(
                table="pose", key="inchikey", value=inchikey, multiple=True
            )
            if len(entries) != 1:
                mrich.warning(f"Multiple poses with {inchikey=}")
                return [i for i, in entries]
            else:
                entry = entries[0]

        elif alias:
            entry = self.select_id_where(table="pose", key="alias", value=alias)

        else:
            raise NotImplementedError

        if entry:
            return entry[0]

        return None

    def get_reaction(
        self,
        *,
        id: int | None = None,
        none: str | None = None,
    ) -> Reaction:
        """Get a reaction using its ID

        :param id: the ID to search for (Default value = None)
        :param none: define the behaviour for no matches, any value other than ``'error'`` will silently return empty data (Default value = 'error')
        :returns: the :class:`.Reaction` object

        """

        if not id:
            mrich.error(f"Invalid {id=}")
            return None

        query = "reaction_id, reaction_type, reaction_product, reaction_product_yield"
        entry = self.select_where(
            query=query, table="reaction", key="id", value=id, none=none
        )

        if not entry:
            return None

        reaction = Reaction(self, *entry)
        return reaction

    def get_quote(
        self,
        *,
        id: int | None = None,
        none: str | None = None,
    ) -> Quote:
        """Get a quote using its ID

        :param id: the ID to search for (Default value = None)
        :param none: define the behaviour for no matches, any value other than ``'error'`` will silently return empty data (Default value = 'error')
        :returns: the :class:`.Quote` object

        """

        query = ", ".join(
            [
                "quote_compound",
                "quote_supplier",
                "quote_catalogue",
                "quote_entry",
                "quote_amount",
                "quote_price",
                "quote_currency",
                "quote_lead_time",
                "quote_purity",
                "quote_date",
                "quote_smiles",
                "quote_id",
            ]
        )

        entry = self.select_where(
            query=query, table="quote", key="id", value=id, none=none
        )

        return Quote(
            db=self,
            id=entry[11],
            compound=entry[0],
            supplier=entry[1],
            catalogue=entry[2],
            entry=entry[3],
            amount=entry[4],
            price=entry[5],
            currency=entry[6],
            lead_time=entry[7],
            purity=entry[8],
            date=entry[9],
            smiles=entry[10],
        )

    def get_quote_df(self, ids: list[int]) -> "pd.DataFrame":
        """Get a pandas DataFrame representing quotes with given IDs"""

        from pandas import DataFrame

        str_ids = str(tuple(ids)).replace(",)", ")")

        query = ", ".join(
            [
                "quote_compound",
                "quote_supplier",
                "quote_catalogue",
                "quote_entry",
                "quote_amount",
                "quote_price",
                "quote_currency",
                "quote_lead_time",
                "quote_purity",
                "quote_date",
                "quote_smiles",
                "quote_id",
            ]
        )
        records = self.select_where(
            query=query,
            table="quote",
            key=f"quote_id IN {str_ids}",
            multiple=True,
        )

        data = []

        for entry in records:
            data.append(
                dict(
                    id=entry[11],
                    compound=entry[0],
                    supplier=entry[1],
                    catalogue=entry[2],
                    entry=entry[3],
                    amount=entry[4],
                    price=entry[5],
                    currency=entry[6],
                    lead_time=entry[7],
                    purity=entry[8],
                    date=entry[9],
                    smiles=entry[10],
                )
            )

        return DataFrame(data)

    def get_metadata(
        self,
        *,
        table: str,
        id: int,
    ) -> dict:
        """Get metadata dictionary from a specific table and ID

        :param table: the table from which to get the entry
        :param id: the ID to search for (Default value = None)
        :returns: a dictionary of metadata

        """

        (payload,) = self.select_where(
            query=f"{table}_metadata", table=table, key=f"id", value=id
        )

        if payload:
            payload = json.loads(payload)

        else:
            payload = dict()

        metadata = MetaData(payload)

        metadata._db = self
        metadata._id = id
        metadata._table = table

        return metadata

    def get_target(
        self,
        *,
        id: int,
    ) -> Target:
        """Get target with specific ID

        :param id: the ID of the target to retrieve
        :returns: :class:`.Target` object

        """

        return Target(db=self, id=id, name=self.get_target_name(id=id))

    def get_target_name(
        self,
        *,
        id: int,
    ) -> str:
        """Get the name of a target with given ID

        :param id: the ID of the target to retrieve
        :returns: target name

        """

        table = "target"
        (payload,) = self.select_where(
            query=f"{table}_name", table=table, key="id", value=id
        )
        return payload

    def get_target_id(
        self,
        *,
        name: str,
    ) -> int | None:
        """Get target ID with a given name

        :param name: the protein target name
        :returns: the :class:`.Target` ID

        """

        table = "target"
        entry = self.select_id_where(table=table, key="name", value=name)

        if entry:
            return entry[0]

        return None

    def get_feature(
        self,
        *,
        id: int,
    ) -> Feature:
        """Get a protein interaction :class:`.Feature` with a given ID

        :param id: the protein interaction :class:`.Feature` ID to be retrieved
        :returns: :class:`.Feature` object

        """

        entry = self.select_all_where(table="feature", key="id", value=id)

        return Feature(*entry)

    def get_route(
        self,
        *,
        id: int,
        debug: bool = False,
    ) -> Route:
        """Fetch a :class:`.Route` object stored in the :class:`.Database`.

        :param id: the ID of the :class:`.Route` to be retrieved
        :param debug: increase verbosity for debugging, defaults to False
        :returns: :class:`.Route` object

        """

        from .cset import CompoundSet, IngredientSet
        from .rset import ReactionSet

        (product_id,) = self.select_where(
            table="route", query="route_product", key="id", value=id
        )

        if debug:
            mrich.var("product_id", product_id)

        triples = self.select_where(
            table="component",
            query="component_ref, component_type, component_amount",
            key=f"component_route IS {id} ORDER BY component_id",
            multiple=True,
        )

        reaction_ids = []
        reactant_ids = []
        reactant_amounts = []
        intermediate_ids = []
        intermediate_amounts = []

        for ref, c_type, amount in triples:
            match c_type:
                case 1:
                    reaction_ids.append(ref)
                case 2:
                    reactant_ids.append(ref)
                    reactant_amounts.append(amount)
                case 3:
                    intermediate_ids.append(ref)
                    intermediate_amounts.append(amount)
                case _:
                    raise ValueError(f"Unknown component type {c_type}")

        if debug:
            mrich.var("pairs", pairs)

        products = CompoundSet(self, [product_id])
        reactants = CompoundSet(self, reactant_ids)
        intermediates = CompoundSet(self, intermediate_ids)

        products = IngredientSet.from_compounds(compounds=products, amount=1)
        reactants = IngredientSet.from_compounds(
            compounds=reactants, amount=reactant_amounts
        )
        intermediates = IngredientSet.from_compounds(
            compounds=intermediates, amount=intermediate_amounts
        )

        reactions = ReactionSet(self, reaction_ids)

        recipe = Route(
            self,
            route_id=id,
            product=products,
            reactants=reactants,
            intermediates=intermediates,
            reactions=reactions,
        )

        if debug:
            mrich.var("recipe", recipe)

        return recipe

    def get_route_products(self) -> "CompoundSet | None":
        """Get a :class:`.CompoundSet` of all route products"""
        from .cset import CompoundSet

        records = self.execute(
            f"SELECT DISTINCT route_product FROM {self.SQL_SCHEMA_PREFIX}route"
        ).fetchall()
        if not records:
            return None
        return CompoundSet(self, [i for i, in records])

    def get_route_id_product_dict(self) -> dict[int, int]:
        """Get a dictionary mapping route ID's to their product :class:`.Compound`"""
        records = self.execute("SELECT route_id, route_product FROM route").fetchall()
        return {route_id: route_product for route_id, route_product in records}

    def get_product_id_routes_dict(self) -> dict[int, set[int]]:
        """Get a dictionary mapping product :class:`.Compound` to their route IDs"""
        records = self.execute("SELECT route_id, route_product FROM route").fetchall()

        lookup = {}

        for route_id, route_product in records:

            if route_product not in lookup:
                lookup[route_product] = set()

            lookup[route_product].add(route_id)

        return lookup

    def get_route_id_reactant_ids_dict(self) -> dict[int, set[int]]:
        """Get a dictionary mapping :class:`.Route` ID's to their reactant :class:`.Compound` IDs"""

        sql = """
        SELECT route_id, component_ref FROM route
        INNER JOIN component
        ON component_route = route_id
        WHERE component_type = 2
        """

        c = self.execute(sql)

        lookup = {}
        for route_id, route_reactant in c:
            lookup.setdefault(route_id, set())
            lookup[route_id].add(route_reactant)

        return lookup

    def get_compound_id_pose_ids_dict(self, cset: "CompoundSet") -> dict[int, set]:
        """Get a dictionary mapping :class:`.Compound` ID's to their associated :class:`.Pose` ID's"""
        records = self.execute(
            f"SELECT pose_compound, pose_id FROM {self.SQL_SCHEMA_PREFIX}pose WHERE pose_compound IN {cset.str_ids}"
        ).fetchall()

        d = {}

        for comp_id, pose_id in records:
            d[comp_id] = d.get(comp_id, set())
            d[comp_id].add(pose_id)
        return d

    def get_compound_id_suppliers_dict(
        self, cset: "CompoundSet"
    ) -> dict[int, set[str]]:
        """Get a dictionary mapping :class:`.Compound` ID's to suppliers which stock it"""
        records = self.execute(
            f"SELECT quote_compound, quote_supplier FROM {self.SQL_SCHEMA_PREFIX}quote WHERE quote_compound IN {cset.str_ids}"
        ).fetchall()

        d = {}

        for comp_id, quote_supplier in records:
            d[comp_id] = d.get(comp_id, set())
            d[comp_id].add(quote_supplier)

        return d

    def get_compound_id_smiles_dict(
        self,
        cset: "CompoundSet | None" = None,
    ) -> dict[int, set[str]]:
        """Get a dictionary mapping :class:`.Compound` ID's to suppliers which stock it"""

        if cset:
            sql = f"SELECT compound_id, compound_smiles FROM {self.SQL_SCHEMA_PREFIX}compound WHERE compound_id IN {cset.str_ids}"

        else:
            sql = "SELECT compound_id, compound_smiles FROM compound"

        c = self.execute(sql)

        d = {}
        for comp_id, comp_smiles in c:
            d[comp_id] = comp_smiles

        return d

    def get_compound_inchikey_id_dict(self, inchikeys: list[str]) -> dict[str, int]:
        """Get a dictionary mapping :class:`.Compound` inchikeys to their ID's"""

        inchikey_str = str(tuple(inchikeys)).replace(",)", ")")

        records = self.select_where(
            table="compound",
            multiple=True,
            query="compound_inchikey, compound_id",
            key=f"compound_inchikey IN {inchikey_str}",
        )

        return {
            compound_inchikey: compound_id for compound_inchikey, compound_id in records
        }

    def get_compound_smiles_id_dict(self) -> dict[str, int]:
        """Get a dictionary mapping :class:`.Compound` smiles to their ID's"""

        records = self.select(
            table="compound",
            query="compound_smiles, compound_id",
            multiple=True,
        )

        return {
            compound_smiles: compound_id for compound_smiles, compound_id in records
        }

    def get_compound_id_inchikey_dict(
        self, cset: "CompoundSet | None" = None
    ) -> dict[int, str]:
        """Get a dictionary mapping :class:`.Compound` IDs to their inchikeys"""

        if cset:

            records = self.select_where(
                table="compound",
                multiple=True,
                query="compound_id, compound_inchikey",
                key=f"compound_id IN {cset.str_ids}",
            )

        else:

            records = self.select(
                table="compound",
                multiple=True,
                query="compound_id, compound_inchikey",
            )

        return {
            compound_id: compound_inchikey for compound_id, compound_inchikey in records
        }

    def get_id_metadata_dict(self, *, table: str, ids: list[int]) -> dict[int, dict]:
        """Get a dictionary mapping IDs to metadata dictionaries"""
        from json import loads

        str_ids = str(tuple(ids)).replace(",)", ")")
        records = self.select_where(
            query=f"{table}_id, {table}_metadata",
            table=table,
            key=f"{table}_id IN {str_ids}",
            multiple=True,
        )
        return {i: (loads(m) if m is not None else {}) for i, m in records}

    def get_compound_cluster_dict(
        self,
        cset: "CompoundSet | None" = None,
        *,
        fractions: bool = False,
        max_scaffolds: int | None = None,
        fraction_reference: "CompoundSet | None" = None,
    ) -> dict[tuple, set]:
        """Create a dictionary grouping compounds by their scaffold/base cluster.

        :param cset: :class:`.CompoundSet` subset to query, defaults to all compounds
        :param fractions: Calculate fractional populations for each cluster
        :param max_scaffolds: Define the maximum number of compounds to use as cluster keys
        :param fraction_reference: Use cset to build the cluster map and use fraction_reference to determine the fractional populations
        :returns: A dictionary mapping a tuple of scaffold :class:`.Compound` IDs to a set of superstructure :class:`.Compound` ID's.
        """

        if fractions:
            assert cset is not None

        if (cset is not None and not fractions) or (fraction_reference is not None):
            sql = f"""
            SELECT scaffold_superstructure, scaffold_base FROM {self.SQL_SCHEMA_PREFIX}scaffold
            WHERE scaffold_superstructure IN {cset.str_ids}
            """
        else:
            sql = f"""
            SELECT scaffold_superstructure, scaffold_base FROM {self.SQL_SCHEMA_PREFIX}scaffold
            """

        records = self.execute(sql).fetchall()

        lookup = {}
        for superstructure, scaffold in records:
            group = lookup.setdefault(superstructure, set())
            group.add(scaffold)

        clustered = {}
        for superstructure, scaffolds in lookup.items():
            if max_scaffolds and len(scaffolds) > max_scaffolds:
                continue
            cluster = tuple(scaffolds)
            group = clustered.setdefault(cluster, set())
            group.add(superstructure)

        if fractions:
            if fraction_reference is not None:
                cset = fraction_reference

            fractions = {}
            for cluster, members in clustered.items():
                size = len(members)
                present = sum(1 for c in members if c in cset)
                fractions[cluster] = present / size
            return fractions

        return clustered

    def get_compound_scaffold_dict(self) -> dict[int, set[int]]:
        """Get a dictionary mapping scaffold_base compound ID's to a set of their superstructure IDs"""

        records = self.select(
            table="scaffold",
            query="scaffold_base, scaffold_superstructure",
            multiple=True,
        )

        data = {}
        for scaffold, elab in records:
            if scaffold not in data:
                data[base] = set()
            data[base].add(elab)

        return data

    def get_compound_tag_dict(
        self,
        cset: "CompoundSet | None" = None,
    ) -> dict[int, set[str]]:
        """Get a dictionary mapping compound ID's to their tags"""

        if cset:
            raise NotImplementedError

        records = self.select(
            query="tag_name, tag_compound", table="tag", multiple=True
        )

        data = {}
        for tag_name, compound_id in records:
            if compound_id not in data:
                data[compound_id] = set()
            data[compound_id].add(tag_name)

        # null IDS
        comp_ids = self.select(table="compound", query="compound_id", multiple=True)
        comp_ids = set(q for q, in comp_ids)

        null_ids = comp_ids - set(data.keys())

        for c_id in null_ids:
            data[c_id] = set()

        return data

    def get_pose_tag_dict(
        self,
        pset: "PoseSet | None" = None,
    ) -> dict[int, set[str]]:
        """Get a dictionary mapping pose ID's to their tags"""

        if pset:
            records = self.select_where(
                query="tag_name, tag_pose",
                table="tag",
                key=f"tag_pose IN {pset.str_ids}",
                multiple=True,
            )

        else:
            records = self.select(
                query="tag_name, tag_pose", table="tag", multiple=True
            )

        data = {}
        for tag_name, pose_id in records:
            if pose_id not in data:
                data[pose_id] = set()
            data[pose_id].add(tag_name)

        # null IDS

        if pset:
            null_ids = set(pset.ids) - set(data.keys())

        else:
            pose_ids = self.select(table="pose", query="pose_id", multiple=True)
            pose_ids = set(q for q, in pose_ids)

            null_ids = pose_ids - set(data.keys())

        for c_id in null_ids:
            data[c_id] = set()

        return data

    def get_pose_subsite_names_dict(self) -> dict[int, set[str]]:
        """Get a dictionary mapping pose ID's to their subsite names"""

        lookup = {
            i: n
            for i, n in self.select(
                query="subsite_id, subsite_name", table="subsite", multiple=True
            )
        }

        records = self.select(
            query="subsite_tag_ref, subsite_tag_pose",
            table="subsite_tag",
            multiple=True,
        )

        data = {}
        for subsite_id, pose_id in records:
            data.setdefault(pose_id, set())
            data[pose_id].add(lookup[subsite_id])

        # null IDS
        pose_ids = self.select(table="pose", query="pose_id", multiple=True)
        pose_ids = set(q for q, in pose_ids)

        null_ids = pose_ids - set(data.keys())

        for c_id in null_ids:
            data[c_id] = set()

        return data

    def get_pose_id_interaction_ids_dict(self, pset: "PoseSet") -> dict[int, set]:
        """Get a dictionary mapping :class:`.Pose` ID's to their associated :class:`.Interaction` ID's"""
        records = self.execute(
            f"SELECT interaction_pose, interaction_id FROM {self.SQL_SCHEMA_PREFIX}interaction WHERE interaction_pose IN {pset.str_ids}"
        ).fetchall()

        d = {}

        for pose_id, interaction_id in records:
            d[pose_id] = d.get(pose_id, set())
            d[pose_id].add(interaction_id)
        return d

    def get_pose_alias_id_dict(self, pset: "PoseSet | None" = None) -> dict[str, int]:
        """Get a dictionary mapping :class:`.Pose` aliases to ID's"""

        if pset:
            records = self.execute(f"""
            SELECT pose_id, pose_alias FROM {self.SQL_SCHEMA_PREFIX}pose 
            WHERE pose_alias IS NOT NULL
            AND pose_id IN {pset.str_ids}""").fetchall()

        else:
            records = self.execute("""SELECT pose_id, pose_alias FROM pose 
            WHERE pose_alias IS NOT NULL""").fetchall()

        d = {}
        for pose_id, pose_alias in records:
            d[pose_alias] = pose_id

        return d

    def get_pose_alias_path_dict(self, pset: "PoseSet | None" = None) -> dict[str, str]:
        """Get a dictionary mapping :class:`.Pose` aliases to paths"""

        if pset:
            records = self.execute(f"""
            SELECT pose_alias, pose_path FROM {self.SQL_SCHEMA_PREFIX}pose 
            WHERE pose_id IN {pset.str_ids}""").fetchall()

        else:
            records = self.execute(
                """SELECT pose_alias, pose_path FROM pose """
            ).fetchall()

        d = {}
        for pose_alias, pose_path in records:
            d[pose_alias] = pose_path

        return d

    def get_pose_id_alias_dict(self, pset: "PoseSet | None" = None) -> dict[str, int]:
        """Get a dictionary mapping :class:`.Pose` aliases to ID's"""

        if pset:
            records = self.execute(f"""
            SELECT pose_id, pose_alias FROM {self.SQL_SCHEMA_PREFIX}pose 
            WHERE pose_alias IS NOT NULL
            AND pose_id IN {pset.str_ids}""").fetchall()

        else:
            records = self.execute("""SELECT pose_id, pose_alias FROM pose 
            WHERE pose_alias IS NOT NULL""").fetchall()

        d = {}
        for pose_id, pose_alias in records:
            d[pose_id] = pose_alias

        return d

    def get_pose_path_id_dict(self, pset: "PoseSet | None" = None) -> dict[str, int]:
        """Get a dictionary mapping :class:`.Pose` aliases to ID's"""

        if pset:
            records = self.execute(f"""
            SELECT pose_id, pose_path FROM {self.SQL_SCHEMA_PREFIX}pose 
            WHERE pose_path IS NOT NULL
            AND pose_id IN {pset.str_ids}""").fetchall()

        else:
            records = self.execute(f"""
            SELECT pose_id, pose_path FROM {self.SQL_SCHEMA_PREFIX}pose 
            WHERE pose_path IS NOT NULL""").fetchall()

        d = {}
        for pose_id, pose_path in records:
            d[pose_path] = pose_id

        return d

    def get_pose_id_obj_dict(self, pset: "PoseSet") -> "dict[id, Pose]":
        """Get a dictionary mapping :class:`.Pose` ID's to their objects"""

        query = ", ".join(
            [
                "pose_id",
                "pose_inchikey",
                "pose_alias",
                "pose_smiles",
                "pose_reference",
                "pose_path",
                "pose_compound",
                "pose_target",
                "pose_mol",
                "pose_fingerprint",
                "pose_energy_score",
                "pose_distance_score",
            ]
        )

        records = self.select_where(
            query=query, table="pose", key=f"pose_id IN {pset.str_ids}", multiple=True
        )

        d = {}
        for entry in records:

            (
                pose_id,
                pose_inchikey,
                pose_alias,
                pose_smiles,
                pose_reference,
                pose_path,
                pose_compound,
                pose_target,
                pose_mol,
                pose_fingerprint,
                pose_energy_score,
                pose_distance_score,
            ) = entry

            d[pose_id] = Pose(
                self,
                pose_id,
                pose_inchikey,
                pose_alias,
                pose_smiles,
                pose_reference,
                pose_path,
                pose_compound,
                pose_target,
                pose_mol,
                pose_fingerprint,
                pose_energy_score,
                pose_distance_score,
            )

        return d

    def get_pose_id_interaction_tuples_dict(self, pset: "PoseSet") -> dict[int, set]:
        """Get a dictionary mapping :class:`.Pose` ID's to lists of `(interaction_type, feature_id)` tuples describing their interactions"""

        sql = f"""
        SELECT DISTINCT interaction_pose, feature_id, interaction_type FROM {self.SQL_SCHEMA_PREFIX}interaction 
        INNER JOIN {self.SQL_SCHEMA_PREFIX}feature ON interaction_feature = feature_id
        WHERE interaction_pose IN {pset.str_ids}
        """

        records = self.execute(sql).fetchall()

        ISETS = {}
        for pose_id, feature_id, interaction_type in records:
            values = ISETS.get(pose_id, set())
            values.add((interaction_type, feature_id))
            ISETS[pose_id] = values

        return ISETS

    def get_compound_id_inspiration_ids_dict(self) -> dict[int, set]:
        """Get a dictionary mapping :class:`.Compound` ID's to a set of :class:`Pose` ID's for the inspirations for the whole database"""

        sql = f"""
        SELECT compound_id, pose_id, inspiration_original FROM {self.SQL_SCHEMA_PREFIX}compound
        INNER JOIN {self.SQL_SCHEMA_PREFIX}pose ON compound_id = pose_compound
        INNER JOIN {self.SQL_SCHEMA_PREFIX}inspiration ON pose_id = inspiration_derivative
        """

        with mrich.spinner("Database.get_pose_id_interaction_ids_dict()"):
            records = self.execute(sql).fetchall()

        d = {}

        for compound_id, pose_id, inspiration_id in records:
            d[compound_id] = d.get(compound_id, set())
            d[compound_id].add(inspiration_id)

        return d

    def get_pose_id_inspiration_ids_dict(
        self,
        pset: "PoseSet" = None,
    ) -> dict[int, set]:
        """Get a dictionary mapping :class:`.Pose` ID's to a set of :class:`Pose` ID's for the inspirations for the whole database"""

        if pset:
            sql = f"""
            SELECT pose_id, inspiration_original FROM {self.SQL_SCHEMA_PREFIX}pose
            INNER JOIN {self.SQL_SCHEMA_PREFIX}inspiration ON pose_id = inspiration_derivative
            WHERE pose_id IN {pset.str_ids}
            """

        else:

            sql = f"""
            SELECT pose_id, inspiration_original FROM {self.SQL_SCHEMA_PREFIX}pose
            INNER JOIN {self.SQL_SCHEMA_PREFIX}inspiration ON pose_id = inspiration_derivative
            """

        with mrich.spinner("Database.get_pose_id_interaction_ids_dict()"):
            records = self.execute(sql).fetchall()

        d = {}

        for pose_id, inspiration_id in records:
            d[pose_id] = d.get(pose_id, set())
            d[pose_id].add(inspiration_id)

        return d

    def get_inspiration_tuples(self) -> list[int, int]:
        """Get a dictionary mapping :class:`.Pose` ID's to a set of :class:`Pose` ID's for the inspirations for the whole database"""
        sql = f"""SELECT inspiration_original, inspiration_derivative FROM {self.SQL_SCHEMA_PREFIX}inspiration"""
        return self.execute(sql).fetchall()

    def get_compound_id_obj_dict(self, cset: "CompoundSet") -> "dict[id, Compound]":
        """Get a dictionary mapping :class:`.Compound` ID's to their objects"""

        query = "compound_id, compound_inchikey, compound_alias, compound_smiles"
        records = self.select_where(
            query=query,
            table="compound",
            key=f"compound_id IN {cset.str_ids}",
            multiple=True,
        )

        d = {}
        for entry in records:
            compound_id, compound_inchikey, compound_alias, compound_smiles = entry
            d[compound_id] = Compound(
                self._animal,
                self,
                compound_id,
                compound_inchikey,
                compound_alias,
                compound_smiles,
                metadata=None,
                mol=None,
            )
        return d

    def get_interaction(self, *, id: int, table: str = "interaction") -> "Interaction":
        """Fetch the :class:`.Interaction` object with given ID

        :param id: the ID of the Interaction to retrieve
        :returns: :class:`.Interaction` object

        """

        from .interaction import Interaction

        result = self.select_all_where(table=table, key=f"interaction_id = {id}")

        (
            id,
            feature_id,
            pose_id,
            type,
            family,
            atom_ids,
            prot_coord,
            lig_coord,
            distance,
            angle,
            energy,
        ) = result

        return Interaction(
            db=self,
            id=id,
            feature_id=feature_id,
            pose_id=pose_id,
            type=type,
            family=family,
            atom_ids=atom_ids,
            prot_coord=prot_coord,
            lig_coord=lig_coord,
            distance=distance,
            angle=angle,
            energy=energy,
            table=table,
        )

    def get_reaction_map_from_products(
        self, product_ids: list[int]
    ) -> dict[tuple[str, int], set[int]]:
        """Get a dictionary mapping (reaction_type, product_id) tuples to sets of reactant_ids"""

        str_ids = str(tuple(product_ids)).replace(",)", ")")

        records = self.execute(f"""
            SELECT reaction_type, reaction_product, reaction_id, reactant_compound
            FROM {self.SQL_SCHEMA_PREFIX}reaction INNER JOIN {self.SQL_SCHEMA_PREFIX}reactant
            ON reaction_id = reactant_reaction
            WHERE reaction_product IN {str_ids}
        """).fetchall()

        mapping = {}
        for reaction_type, reaction_product, reaction_id, reactant_compound in records:

            key = (reaction_type, reaction_product)

            if key not in mapping:
                mapping[key] = {}

            if reaction_id not in mapping[key]:
                mapping[key][reaction_id] = set()

            mapping[key][reaction_id].add(reactant_compound)

        return mapping

    def get_possible_reaction_ids(
        self,
        *,
        compound_ids: list[int],
    ) -> list[int]:
        """Given a set of reactant :class:`.Compound` ID's, compute which :class:`.Reaction` objects are possible (all reactants present).

        :param compound_ids: the list of reactant :class:`.Compound` IDs
        :returns: a list of :class:`.Reaction` ID's that are possible with the given reactants

        """

        compound_ids_str = str(tuple(compound_ids)).replace(",)", ")")

        result = self.execute(f"""
            WITH possible_reactants AS 
            (
                SELECT reactant_reaction, CASE 
                    WHEN reactant_compound IN {compound_ids_str} 
                    THEN reactant_compound END AS [possible_reactant] 
                FROM {self.SQL_SCHEMA_PREFIX}reactant
            )

            , possible_reactions AS (
                SELECT reactant_reaction, COUNT(
                    CASE 
                        WHEN possible_reactant IS NULL 
                        THEN 1 END) AS [count_null] 
                    FROM possible_reactants
                GROUP BY reactant_reaction
            )
            
            SELECT reactant_reaction FROM possible_reactions
            WHERE count_null = 0
        """).fetchall()

        return [q for q, in result]

    def get_unsolved_reaction_tree(
        self,
        *,
        product_ids: list[int],
        debug: bool = False,
    ) -> "(CompoundSet, ReactionSet)":
        """Given a set of product :class:`.Compound` IDs, recursively solve for all the reactants (:class:`.CompoundSet`) and reactions (:class:`.ReactionSet`) that could be involved in their synthesis. N.B. This evaluates all synthesis branches.

        :param product_ids: list of product :class:`.Compound` IDs
        :param debug: increase verbosity for debugging, defaults to False
        :returns: a tuple of ``(reactants, reactions)``

        """

        from .cset import CompoundSet
        from .rset import ReactionSet

        all_reactants = set()
        all_reactions = set()

        # print(product_ids)

        # for product_id in product_ids:
        #     all_reactants.add(product_id)

        for i in range(300):

            if debug:
                mrich.var("recursive depth", i + 1)

            if debug:
                mrich.var("#products", len(product_ids))

            product_ids_str = str(tuple(product_ids)).replace(",)", ")")

            reaction_ids = self.select_where(
                table="reaction",
                query="DISTINCT reaction_id",
                key=f"reaction_product in {product_ids_str}",
                multiple=True,
                none="quiet",
            )

            reaction_ids = [q for q, in reaction_ids]

            if not reaction_ids:
                break

            for reaction_id in reaction_ids:
                all_reactions.add(reaction_id)

            if debug:
                mrich.var("#reactions", len(reaction_ids))

            reaction_ids_str = str(tuple(reaction_ids)).replace(",)", ")")

            reactant_ids = self.select_where(
                table="reactant",
                query="DISTINCT reactant_compound",
                key=f"reactant_reaction in {reaction_ids_str}",
                multiple=True,
            )

            if debug:
                mrich.var("#reactants", len(reactant_ids))

            reactant_ids = [q for q, in reactant_ids]

            if not reactant_ids:
                break

            for reactant_id in reactant_ids:
                all_reactants.add(reactant_id)

            product_ids = reactant_ids

        # all intermediates
        ids = self.execute(f"""
            SELECT DISTINCT reaction_product 
            FROM {self.SQL_SCHEMA_PREFIX}reaction 
            INNER JOIN {self.SQL_SCHEMA_PREFIX}reactant 
            ON reaction_product = reactant_compound
            """).fetchall()
        ids = [q for q, in ids]
        intermediates = CompoundSet(self, ids)

        # remove intermediates
        cset = CompoundSet(self, all_reactants)
        all_reactants = cset - intermediates

        # reactions
        all_reactions = ReactionSet(self, all_reactions)

        if debug:
            mrich.var("#all_reactants", len(all_reactants))
            mrich.var("#all_reactions", len(all_reactions))

        return all_reactants, all_reactions

    def get_reaction_price_estimate(
        self,
        *,
        reaction: Reaction,
    ) -> float:
        """Estimate the price of a :class:`.Reaction`

        :param reaction: :class:`.Reaction` object
        :returns: price estimate

        """

        # get reactants for a given reaction

        mrich.warning("Price estimate does not account for branching!")
        reactants, _ = self.get_unsolved_reaction_tree(
            product_ids=reaction.reactant_ids
        )

        # how to make sure that there are no branching reactions?!

        # sum lowest unit price for each reactant

        (price,) = self.execute(f"""
        WITH unit_prices AS 
        (
            SELECT quote_compound, MIN(quote_price/quote_amount) AS unit_price 
            FROM {self.SQL_SCHEMA_PREFIX}quote 
            WHERE quote_compound IN {reactants.str_ids}
            GROUP BY quote_compound
        )
        SELECT SUM(unit_price) FROM unit_prices
        """).fetchone()

        return price

    def get_possible_reaction_product_ids(
        self,
        *,
        reaction_ids: list[int],
    ) -> list[int]:
        """Given a set of :class:`.Reaction` IDs return the :class:`.Compound` IDs of their synthesis products

        :param reaction_ids: :class:`.Reaction` IDs
        :returns: list of :class:`.Compound` IDs

        """
        reaction_ids_str = str(tuple(reaction_ids)).replace(",)", ")")
        return [
            q
            for q, in self.select_where(
                query="DISTINCT reaction_product",
                table="reaction",
                key=f"reaction_id IN {reaction_ids_str}",
                multiple=True,
            )
        ]

    def get_subsite(self, *, id) -> "Subsite":
        """Get protein subsite with a given ID

        :param ID: the subsite ID
        :returns: :class:`.Subsite` object

        """

        from .subsite import Subsite

        results = self.select_where(
            table="subsite",
            key="id",
            value=id,
            multiple=False,
            query="subsite_name, subsite_target",
        )

        if not results:
            mrich.error(f"No subsite with {id=}")
            return None

        name, target = results

        subsite = Subsite(db=self, id=id, name=name, target_id=target)

        return subsite

    def get_subsite_tag(self, *, id) -> "SubsiteTag":
        """Get subsite_tag with a given ID

        :param ID: the subsite_tag ID
        :returns: :class:`.SubsiteTag` object

        """

        from .subsite import SubsiteTag

        subsite_id, pose_id = self.select_where(
            table="subsite_tag",
            key="id",
            value=id,
            multiple=False,
            query="subsite_tag_ref, subsite_tag_pose",
        )

        subsite_tag = SubsiteTag(db=self, id=id, subsite_id=subsite_id, pose_id=pose_id)

        return subsite_tag

    def get_subsite_id(self, *, name: str, **kwargs) -> int | None:
        """Get protein Subsite ID with a given name

        :param name: the protein Subsite name
        :returns: the Subsite ID

        """

        table = "Subsite"
        entry = self.select_id_where(table=table, key="name", value=name, **kwargs)

        if entry:
            return entry[0]

        return None

    def get_subsite_name(self, *, id: str, **kwargs) -> int | None:
        """Get protein :class:`.Subsite` name with a given ID

        :param name: the protein :class:`.Subsite` ID
        :returns: the :class:`.Subsite` ID

        """

        table = "subsite"
        entry = self.select_where(
            query="subsite_name", table=table, key="id", value=id, **kwargs
        )

        if entry:
            return entry[0]

        return None

    def get_scaffold_similarity_dict(
        self, scaffolds: "CompoundSet | None" = None
    ) -> list[dict]:
        """Get a dictionary mapping scaffold :class:`.Compound` IDs to their superstructure's IDs"""

        sql = f"""
        SELECT scaffold_base as a, scaffold_superstructure as b, bfp_tanimoto(c.fp, d.fp) AS t
        FROM {self.SQL_SCHEMA_PREFIX}scaffold
        INNER JOIN compound_pattern_bfp AS c ON a = c.compound_id
        INNER JOIN compound_pattern_bfp AS d ON b = d.compound_id
        """

        if scaffolds:

            sql += f" WHERE a IN {scaffolds.str_ids}"

        records = self.execute(sql).fetchall()

        data = []
        for a, b, s in mrich.track(records):
            data.append(dict(scaffold_id=a, superstructure_id=b, similarity=s))

        return data

    def get_reactant_product_tuples(
        self, compound_ids: list | None = None, deduplicated: bool = True
    ) -> set[tuple[int, int]]:
        """Get tuples of (reactant, product) :class:`.Compound` IDs"""

        sql = f"""
        SELECT reactant_compound, reaction_product 
        FROM {self.SQL_SCHEMA_PREFIX}reactant
        INNER JOIN {self.SQL_SCHEMA_PREFIX}reaction 
        ON reactant_reaction = reaction_id
        """

        if compound_ids:
            str_ids = str(tuple(compound_ids)).replace(",)", ")")
            sql += (
                f"WHERE reactant_compound IN {str_ids} OR reaction_product IN {str_ids}"
            )

        records = self.execute(sql)
        if deduplicated:
            return set((a, b) for a, b in records)
        else:
            return [(a, b) for a, b in records]

    def get_scaffold_tuples(
        self, compound_ids: list | None = None
    ) -> set[tuple[int, int]]:
        """Get tuples of (reactant, product) :class:`.Compound` IDs"""

        sql = f"""
        SELECT scaffold_base, scaffold_superstructure 
        FROM {self.SQL_SCHEMA_PREFIX}scaffold
        """

        if compound_ids:
            str_ids = str(tuple(compound_ids)).replace(",)", ")")
            sql += f"WHERE scaffold_base IN {str_ids} OR scaffold_superstructure IN {str_ids}"

        records = self.execute(sql)
        return set((a, b) for a, b in records)

    ### COMPOUND QUERY

    def query_substructure(
        self,
        query: str,
        *,
        fast: bool = True,
        none: str = "error",
        smarts: bool = False,
    ) -> "CompoundSet":
        """Search for compounds by substructure

        :param query: SMILES string of the substructure
        :param fast: Use pattern binary fingerprint table to improve performance (Default value = True)
        :param none: define the behaviour for no matches, any value other than ``'error'`` will silently return empty data (Default value = 'error')
        :returns: :class:`.CompoundSet` object

        """

        if smarts:
            func = "mol_from_smarts"
        else:
            func = "mol_from_smiles"

        # smiles
        if isinstance(query, str):

            if fast:
                sql = f"""
                SELECT compound.compound_id, compound.compound_inchikey 
                FROM {self.SQL_SCHEMA_PREFIX}compound, compound_pattern_bfp AS bfp 
                WHERE {self.SQL_SCHEMA_PREFIX}compound.compound_id = {self.SQL_SCHEMA_PREFIX}bfp.compound_id 
                AND mol_is_substruct(compound.compound_mol, {func}(?))
                """

            else:
                sql = f"""
                SELECT compound_id, compound_inchikey FROM {self.SQL_SCHEMA_PREFIX}compound 
                WHERE mol_is_substruct(compound_mol, {func}(?))
                """

        else:

            raise NotImplementedError

        try:
            self.execute(sql, (query,))
        except sqlite3.OperationalError as e:
            mrich.var("sql", sql)
            raise

        result = self.cursor.fetchall()

        if not result and none == "error":
            mrich.error(f"No compounds with substructure {query}")
            return None
        elif not result:
            return None

        from .cset import CompoundSet

        if not smarts:
            smiles = query
            try:
                smiles = sanitise_smiles(smiles, sanitisation_failed="error")
            except SanitisationError as e:
                mrich.error(f"Could not sanitise {smiles=}")
                mrich.error(str(e))
                return None
            except AssertionError:
                mrich.error(f"Could not sanitise {smiles=}")
                return None
                return c
            inchikey = inchikey_from_smiles(smiles)

            ids = [i for i, key in result if key != inchikey]
            return CompoundSet(self, ids)

        else:
            return CompoundSet(self, [i for i, _ in result])

    def query_most_similar(
        self,
        query: str,
        subset: "CompoundSet",
        fp="pattern",
        bits=2048,
        morgan_radius=1,
        return_similarity: bool = False,
        none="error",
    ) -> "Compound | (Compound, float)":
        """Search for the most similar compound by tanimoto similarity of binary pattern fingerprints using the chemicalite function `mol_pattern_bfp`

        :param query: SMILES string
        :param return_similarity: return a list of similarity values together with the :class:`.CompoundSet` (Default value = False)
        :param none: define the behaviour for no matches, any value other than ``'error'`` will silently return empty data (Default value = 'error')
        :param subset: optional subset of compounds to search
        :returns: :class:`.Compound` and optionally a similarity values
        """

        from .compound import Compound

        if fp == "pattern" and bits == 2048:
            sql = f"""
            WITH subset AS (
                SELECT compound_id, fp
                FROM {self.SQL_SCHEMA_PREFIX}compound
                JOIN compound_pattern_bfp USING (compound_id)
                WHERE compound_id IN {subset.str_ids}
            )
            
            SELECT compound_id, 
            bfp_tanimoto(mol_pattern_bfp(mol_from_smiles(?1), {bits}), fp) 
            AS similarity
            FROM subset
            ORDER BY similarity DESC
            LIMIT 1
            """

        elif fp == "morgan":

            sql = f"""
            WITH subset AS (
                SELECT compound_id, mol_{fp}_bfp(compound_mol, {morgan_radius}, {bits}) AS fp
                FROM {self.SQL_SCHEMA_PREFIX}compound
                WHERE compound_id IN {subset.str_ids}
            )
            
            SELECT compound_id, 
            bfp_tanimoto(mol_{fp}_bfp(mol_from_smiles(?1), {morgan_radius}, {bits}), fp) 
            AS similarity
            FROM subset
            ORDER BY similarity DESC
            LIMIT 1
            """

        else:

            sql = f"""
            WITH subset AS (
                SELECT compound_id, mol_{fp}_bfp(compound_mol, {bits}) AS fp
                FROM {self.SQL_SCHEMA_PREFIX}compound
                WHERE compound_id IN {subset.str_ids}
            )
            
            SELECT compound_id, bfp_tanimoto(mol_{fp}_bfp(mol_from_smiles(?1), {bits}), fp) 
            AS similarity
            FROM subset
            ORDER BY similarity DESC
            LIMIT 1
            """

        try:
            self.execute(sql, (query,))
        except sqlite3.OperationalError as e:
            mrich.var("sql", sql)
            raise

        compound_id, similarity = self.cursor.fetchone()

        if return_similarity:
            return self.get_compound(id=compound_id), similarity

        return self.get_compound(id=compound_id)

    def query_similarity(
        self,
        query: str,
        threshold: float,
        return_similarity: bool = False,
        subset: "CompoundSet" = None,
        none="error",
    ) -> "CompoundSet | (CompoundSet, list[float])":
        """Search compounds by tanimoto similarity of binary pattern fingerprints using the chemicalite function `mol_pattern_bfp`

        :param query: SMILES string
        :param threshold: similarity threshold to exceed
        :param return_similarity: return a list of similarity values together with the :class:`.CompoundSet` (Default value = False)
        :param none: define the behaviour for no matches, any value other than ``'error'`` will silently return empty data (Default value = 'error')
        :param subset: optional subset of compounds to search
        :returns: :class:`.CompoundSet` and optionally a list of similarity values

        """

        from .cset import CompoundSet

        # smiles
        if subset:

            if return_similarity:
                sql = f"""
                SELECT compound_id, 
                       bfp_tanimoto(mol_pattern_bfp(mol_from_smiles(?1), 2048), 
                       mol_pattern_bfp(compound.compound_mol, 2048)) as t 
                FROM {self.SQL_SCHEMA_PREFIX}compound 
                JOIN compound_pattern_bfp AS mfp 
                USING(compound_id) 
                WHERE mfp.compound_id
                MATCH rdtree_tanimoto(mol_pattern_bfp(mol_from_smiles(?1), 2048), ?2)
                AND compound_id IN {subset.str_ids}
                ORDER BY t DESC
                """
            else:
                sql = f"""
                SELECT compound_id 
                FROM compound_pattern_bfp AS bfp 
                WHERE bfp.compound_id
                MATCH rdtree_tanimoto(mol_pattern_bfp(mol_from_smiles(?1), 2048), ?2)
                AND compound_id IN {subset.str_ids}
                """

        elif isinstance(query, str):

            if return_similarity:
                sql = f"""
                SELECT compound_id, 
                       bfp_tanimoto(mol_pattern_bfp(mol_from_smiles(?1), 2048), 
                       mol_pattern_bfp(compound.compound_mol, 2048)) as t 
                FROM {self.SQL_SCHEMA_PREFIX}compound 
                JOIN compound_pattern_bfp AS mfp 
                USING(compound_id) 
                WHERE mfp.compound_id
                MATCH rdtree_tanimoto(mol_pattern_bfp(mol_from_smiles(?1), 2048), ?2) 
                ORDER BY t DESC
                """
            else:
                sql = f"""
                SELECT compound_id 
                FROM compound_pattern_bfp AS bfp 
                WHERE bfp.compound_id
                MATCH rdtree_tanimoto(mol_pattern_bfp(mol_from_smiles(?1), 2048), ?2)
                """
        else:
            raise NotImplementedError

        try:
            self.execute(sql, (query, threshold))
        except sqlite3.OperationalError as e:
            mrich.var("sql", sql)
            raise

        result = self.cursor.fetchall()

        if not result and none == "error":
            mrich.error(f"No compounds with similarity >= {threshold} to {query}")
            return None

        if return_similarity:
            ids, similarities = zip(*result)
            cset = CompoundSet(self, ids)
            return cset, similarities

        ids = [r for r, in result]
        cset = CompoundSet(self, ids)

        return cset

    def query_exact(
        self,
        query: str,
        threshold: float = 0.989,
    ) -> "CompoundSet":
        """Search for exact match compounds (default similarity > 0.989)

        :param query: SMILES string
        :param threshold: similarity threshold to exceed

        """

        return self.query_similarity(query, 0.989, return_similarity=False)

    ### LOOKUPS / MAPPING

    def create_metadata_id_map(self, *, table: str, key: str) -> dict[str, int]:
        """Create a mapping between metadata[key] values to their respective parent record ID's

        :returns: dictionary mapping metadata[key] values to integer ID's

        """

        pairs = self.execute(f"""
            SELECT {table}_id, {table}_metadata 
            FROM {self.SQL_SCHEMA_PREFIX}{table} 
            WHERE {table}_metadata LIKE '%"{key}": "%'
            """).fetchall()
        from json import loads

        return dict(
            sorted(
                {loads(metadata)[key]: pose_id for pose_id, metadata in pairs}.items()
            )
        )

    ### COUNTING

    def count(
        self,
        table: str,
    ) -> int:
        """Count all entries in a table

        :param table: table to count entries from

        """

        sql = f"SELECT COUNT(1) FROM {self.SQL_SCHEMA_PREFIX}{table};"
        self.execute(sql)
        return self.cursor.fetchone()[0]

    def count_where(
        self,
        table: str,
        key: str,
        value=None,
    ):
        """Count all entries in a table where ``key==value``

        :param table: table to count entries from
        :param key: the key to match as ``{table}_{key} = {value}`` or the SQL string if ``value == None``
        :param value: the value to match (Default value = None)

        """

        if isinstance(value, str):
            if "'" in value:
                value = f'"{value}"'
            else:
                value = f"'{value}'"

        if value is not None:
            where_str = f"{table}_{key}={value}"
        else:
            where_str = key

        sql = f"SELECT COUNT(1) FROM {self.SQL_SCHEMA_PREFIX}{table} WHERE {where_str};"
        self.execute(sql)
        return self.cursor.fetchone()[0]

    ### ID SELECTION

    def min_id(
        self,
        table: str,
    ) -> int:
        """Get the minimal entry ID from a given table

        :param table: the database table to query
        :returns: the smallest entry ID

        """

        (id,) = self.select(table=table, query=f"MIN({table}_id)")
        return id

    def max_id(
        self,
        table: str,
    ) -> int:
        """Get the maximal entry ID from a given table

        :param table: the database table to query
        :returns: the largest entry ID

        """
        (id,) = self.select(table=table, query=f"MAX({table}_id)")
        return id

    def slice_ids(
        self,
        *,
        table: str,
        start: int | None,
        stop: int | None,
        step: int = 1,
        name: bool = False,
    ) -> list[int]:
        """Retrieve ID's matching a slice

        :param table: the database table to query
        :param start: return IDs equal to or larger than this value
        :param stop: return IDs smaller than this value
        :param step: return IDs in increments of this value (Default value = 1)
        :returns: matching IDs

        """

        min_id = self.min_id(table)
        max_id = self.max_id(table)

        start = start or min_id
        stop = stop or max_id + 1
        step = step or 1

        if not (start >= 0 and start <= max_id):
            raise IndexError(
                f"Slice {start=} outside of DB {table}_id range ({min_id}, {max_id})"
            )

        if not (stop >= 0 and stop <= max_id + 1):
            raise IndexError(
                f"Slice {stop=} outside of DB {table}_id range ({min_id}, {max_id})"
            )

        if step != 1:
            raise NotImplementedError(f"Slice {step=} not supported")

        ids = self.select_where(
            table=table,
            query=f"{table}_id",
            key=f"{table}_id >= {start} AND {table}_id < {stop}",
            multiple=True,
        )
        ids = [q for q, in ids]

        if name:
            return ids, f"{table}s[{start}:{stop}]"
        else:
            return ids

    ### PRUNING

    def prune_reactions(
        self,
        reactions: "ReactionSet",
    ) -> list[Reaction]:
        """Remove duplicate reactions

        :param reactions: :class:`.ReactionSet`
        :returns: list of pruned :class:`.Reaction` objects

        """

        pruned = []
        del_list = []

        for i, reaction in enumerate(reactions):

            matches = [r for r in pruned if r == reaction]

            if not matches:
                pruned.append(reaction)

            else:
                del_list.append(reaction)

        for reaction in del_list:
            mrich.warning(f"Deleted duplicate {reaction=}")
            self.delete_where("reaction", "id", reaction.id)

        return pruned

    def remove_metadata_list_item(
        self,
        *,
        table: str,
        key: str,
        value,
        remove_empty: bool = True,
    ) -> None:
        """Remove a specific item from list-like values associated with a given key from all metadata entries in a given table

        :param table: the database table to query
        :param key: the :class:`.Metadata` key to match
        :param value: the value to remove from the list
        :param remove_empty: remove the key from the metadata if the list is empty (Default value = True)

        """

        # get id's with specific metadata key and value
        value_str = json.dumps(value)
        result = self.select_where(
            query=f"{table}_id, {table}_metadata",
            table=table,
            key=f"{table}_metadata LIKE '%\"export\": [%{value_str}%]%'",
            multiple=True,
            none="quiet",
        )

        # loop over all matches
        for id, metadata_str in result:

            # read the metadata
            metadata = json.loads(metadata_str)

            # modify the metadata
            index = metadata[key].index(value)
            metadata[key].pop(index)

            if remove_empty and not metadata[key]:
                del metadata[key]

            # update the database
            metadata_str = json.dumps(metadata)
            self.update(
                table=table,
                id=id,
                key=f"{table}_metadata",
                value=metadata_str,
                commit=False,
            )

        # only runs if non-zero matches
        else:
            # commit the changes
            self.commit()

    ### TABLE INFO

    def print_table(
        self,
        table: str,
    ) -> None:
        """Print a table's entries

        :param table: the table to print

        """

        mrich.print(self.table_df(table))

    def table_df(
        self,
        table: str,
    ) -> "pandas.DataFrame":
        """Get a DataFrame of a table

        :param table: the table to get
        """

        from pandas import DataFrame

        data = []

        column_names = self.column_names(table)

        self.execute(f"SELECT * FROM {self.SQL_SCHEMA_PREFIX}{table}")

        for record in self.cursor:
            d = {}
            for key, value in zip(column_names, record):
                d[key] = value
            data.append(d)

        df = DataFrame(data)
        df = df.set_index(column_names[0])

        return df

    def table_info(
        self,
        table: str,
    ) -> list[tuple]:
        """Print a table's schema

        :param table: the table to print

        """

        self.execute(f"PRAGMA table_info({self.SQL_SCHEMA_PREFIX}{table})")
        return self.cursor.fetchall()

    def column_names(self, table: str) -> list[str]:
        """Get the column names of the given table"""
        table_info = self.table_info(table)
        return [i[1] for i in table_info]

    def index_names(self) -> list[str]:
        """Get the index names"""

        cursor = self.execute("""
            SELECT name
            FROM sqlite_master
            WHERE type = 'index';
        """)

        return [n for n, in cursor]

    ### DUNDERS

    def __str__(self):
        """Unformatted string representation"""
        if self.in_memory:
            return f"Database [IN-MEMORY]"
        else:
            return f"Database @ {self.path.resolve()}"

    def __repr__(self):
        """ANSI Formatted string representation"""
        return f"{mcol.bold}{mcol.underline}{self}{mcol.clear}"

    def __rich__(self) -> str:
        """Representation for mrich"""
        return f"[bold underline]{self}"


class LegacyDatabaseError(Exception):
    """This database is in a legacy format"""

    ...


def backup(
    source: Path | str,
    destination: Path | str | None = None,
    pages: int = 10_000,
) -> "Path":
    """Create a backup of the database"""

    from .tools import dt_hash

    source = Path(source)

    if not destination:
        destination = str(source.resolve()).replace(".sqlite", f"_{dt_hash()}.sqlite")

    destination = Path(destination)

    with mrich.spinner(f"Backing up {source}..."):

        mrich.writing(destination)

        def progress(status, remaining, total):
            """print progress"""
            mrich.debug(f"Copied {total-remaining} of {total} pages...")

        src = sqlite3.connect(source)
        dst = sqlite3.connect(destination)
        with dst:
            src.backup(dst, pages=pages, progress=progress)

        dst.close()

    return destination
