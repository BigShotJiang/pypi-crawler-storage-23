"""Domain layer for business logic and abstractions."""
