"""Domain models for TermTypr."""

from termtypr.domain.models.game_result import GameResult

__all__ = ["GameResult"]
