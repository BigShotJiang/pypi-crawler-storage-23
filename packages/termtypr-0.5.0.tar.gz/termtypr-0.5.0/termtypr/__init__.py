"""TermTypr - A Python CLI application for practicing and improving typing speed."""

__version__ = "0.5.0"
