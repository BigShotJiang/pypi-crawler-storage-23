"""Main entry point for the typing trainer application."""

from termtypr.cli import app

if __name__ == "__main__":
    app()
