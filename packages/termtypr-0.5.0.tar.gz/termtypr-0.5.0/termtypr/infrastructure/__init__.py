"""Infrastructure layer for external dependencies."""
