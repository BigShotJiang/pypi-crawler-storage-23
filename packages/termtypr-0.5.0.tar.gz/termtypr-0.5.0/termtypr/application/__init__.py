"""Application layer, orchestration and business logic."""

from termtypr.application.application_router import ApplicationRouter

__all__ = ["ApplicationRouter"]
