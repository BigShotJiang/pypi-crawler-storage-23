# AGENTS.md

Guidelines for agentic coding agents working in this repository.

## Project Overview

GSD-RLM (Get Shit Done with Reinforcement Learning for Multi-Agent Systems) is a Python package providing YAML-based agent definition with automatic validation, per-agent tool whitelisting, and multi-provider LLM configuration. Built on RLM-Toolkit.

## Build / Test / Lint Commands

```bash
# Install package in editable mode with dev dependencies
pip install -e ".[dev]"

# Run all tests
pytest

# Run tests with coverage
pytest --cov=src/gsd_rlm --cov-report=term-missing

# Run a single test file
pytest tests/test_security/test_secure_agent.py

# Run a single test class
pytest tests/test_security/test_secure_agent.py::TestSecureAgentCreation

# Run a single test function
pytest tests/test_security/test_secure_agent.py::TestSecureAgentCreation::test_secure_agent_creation

# Run tests matching a pattern
pytest -k "test_router"

# Run only async tests
pytest -k "asyncio"

# Run with verbose output
pytest -v tests/test_commands/test_router.py

# Lint with ruff (if available)
ruff check src/

# Format with ruff (if available)
ruff format src/

# Type check (if mypy/pyright available)
pyright src/

# Build package
pip install build
python -m build
```

## Code Style Guidelines

### Imports

```python
# Standard library first (alphabetically sorted)
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Callable, Awaitable

# Third-party imports second (blank line before)
from pydantic import BaseModel, Field, field_validator
from pydantic_settings import BaseSettings
import pytest
from unittest.mock import MagicMock, AsyncMock, patch

# Local imports last (blank line before)
from gsd_rlm.agents.definition import AgentDefinition, LLMProvider
from gsd_rlm.security.trust_zones import TrustZone
```

### Formatting

- Use 4 spaces for indentation (no tabs)
- Max line length: ~100 characters (flexible)
- Use trailing commas in multi-line structures
- Blank line between class methods
- Two blank lines between top-level classes/functions

### Type Annotations

Always use type hints for function signatures:

```python
from typing import Optional, List, Dict, Any

def process_data(
    items: List[str],
    config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    ...

async def execute_task(task_id: str) -> str:
    ...

property def status(self) -> bool:
    ...
```

### Naming Conventions

- **Classes**: PascalCase (`SecureAgent`, `OptimizationScheduler`)
- **Functions/Methods**: snake_case (`get_system_prompt`, `validate_access`)
- **Constants**: UPPER_SNAKE_CASE (`DEFAULT_INTERVAL_SECONDS`, `MIN_TRAINSET_SIZE`)
- **Private methods**: prefix with underscore (`_should_optimize`, `_log_violation`)
- **Protected attributes**: prefix with underscore (`_access_manager`, `_encryptor`)
- **Pydantic models**: PascalCase with fields in snake_case

### Docstrings

Use triple-quoted docstrings with Google-style format:

```python
class SecureAgent:
    """Agent wrapper with trust zone enforcement and encrypted memories.

    Combines memory encryption, trust zone assignment, and access control.

    Example:
        >>> agent = SecureAgent(definition, config, manager)
        >>> agent.zone
        <TrustZone.CONFIDENTIAL: 'confidential'>
    """

    def validate_access(
        self,
        source_agent_id: str,
        target_agent_id: str,
        operation: str = "read",
    ) -> bool:
        """Check if source agent can access target agent's data.

        Args:
            source_agent_id: Agent requesting access.
            target_agent_id: Agent whose data is being accessed.
            operation: Operation being attempted (default: "read").

        Returns:
            True if access is allowed, False if denied.

        Raises:
            ValueError: If agent_id is unknown.
        """
```

### Error Handling

- Use specific exception types
- Include context in error messages
- Use Pydantic validation for input validation
- Log warnings for recoverable issues

```python
# Good
if not self._should_optimize():
    return None

try:
    result = await self._run_optimization()
except RuntimeError as e:
    self._logger.warning(f"Optimization failed: {e}")
    return None

# Pydantic validation
@field_validator("name", "role")
@classmethod
def validate_required_fields(cls, v: str, info) -> str:
    if not v or not v.strip():
        raise ValueError(f"{info.field_name} is required and cannot be empty")
    return v.strip()
```

### Pydantic Models

Always use `model_config` for configuration, prefer `extra = "forbid"`:

```python
from pydantic import BaseModel, Field

class AgentDefinition(BaseModel):
    """YAML agent definition with required fields."""

    model_config = {"extra": "forbid"}  # Reject unknown fields

    name: str = Field(..., min_length=1, description="Agent name")
    role: str = Field(..., min_length=1, description="Agent role")
    timeout: int = Field(default=120, ge=1, le=3600, description="Timeout in seconds")
```

### Async Code

- Use `anyio` for async subprocess and concurrency
- Mark async tests with `@pytest.mark.asyncio`
- Use `AsyncMock` for async function mocks

```python
import anyio

async def _run_async(self, command: str) -> ShellResult:
    with anyio.fail_after(timeout):
        result = await anyio.run_process(command, cwd=self.workdir)
```

### Testing Conventions

```python
# Test file naming: test_<module>.py in tests/<module>/
# Test class naming: Test<Feature>
# Test method naming: test_<scenario> or test_<scenario>_<condition>

class TestSecureAgent:
    """Tests for SecureAgent."""

    @pytest.fixture
    def access_manager(self):
        """Provide a fresh ZoneAccessManager for each test."""
        return ZoneAccessManager()

    def test_can_access_same_agent(self, secure_agent):
        """Agent should always have access to itself."""
        assert secure_agent.can_access("secret-agent") is True

    @pytest.mark.asyncio
    async def test_async_operation(self, mock_component):
        """Async operations should complete successfully."""
        result = await mock_component.run()
        assert result.success is True
```

### File Organization

```
src/gsd_rlm/
  __init__.py           # Public API exports
  agents/
    definition.py       # AgentDefinition, ToolSpec, LLMProvider
    loader.py           # AgentLoader
  cli/
    __init__.py
    init.py             # CLI init command
  commands/
    router.py           # CommandRouter
  config/
    settings.py         # LLMConfig, GSDConfig
  security/
    agent.py            # SecureAgent
    encryption.py       # MemoryEncryptor
  tools/
    shell_tool.py       # GSDShellTool
    file_tools.py       # File operations

tests/
  test_security/
    test_secure_agent.py
  test_commands/
    test_router.py
```

## Key Dependencies

- **pydantic** (>=2.0.0): Data validation and settings management
- **pydantic-settings** (>=2.0.0): Environment variable configuration
- **rlm-toolkit** (>=2.3.0): LLM provider abstraction
- **anyio** (>=4.0.0): Async concurrency (preferred over asyncio directly)
- **typer** (>=0.9.0): CLI framework
- **tenacity** (>=8.0.0): Retry logic
- **networkx** (>=3.0.0): Graph algorithms for dependencies

## Requirements Tags

Code comments reference requirements with tags like:
- `AGENT-01`, `AGENT-03`: Agent definition requirements
- `INT-04`, `INT-06`, `INT-07`: Integration requirements
- `SEC-01` through `SEC-08`: Security requirements

When modifying code, preserve these requirement references in docstrings.
