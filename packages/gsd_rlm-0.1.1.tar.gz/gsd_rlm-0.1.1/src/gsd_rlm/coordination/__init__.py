"""
Coordination module for hybrid runtime orchestration.

This module provides the HybridOrchestrator for coordinating wave-based
parallel execution and AgentChannel for P2P agent communication.

Requirements: EXEC-04 (orchestrator coordination, P2P communication)
"""

from gsd_rlm.coordination.orchestrator import HybridOrchestrator, WaveResult

__all__ = [
    "HybridOrchestrator",
    "WaveResult",
]
