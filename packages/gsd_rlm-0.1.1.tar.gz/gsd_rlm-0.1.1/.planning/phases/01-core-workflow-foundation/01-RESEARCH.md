# Phase 1: Core Workflow Foundation - Research

**Researched:** 2026-02-27
**Domain:** Multi-Agent Orchestration, YAML Configuration, Shell/File Tools, Session Persistence
**Confidence:** HIGH

## Summary

Phase 1 builds the foundational agent execution model on top of RLM-Toolkit v2.3.1, which already provides core agent infrastructure (`Agent`, `AgentMessage`, `MultiAgentRuntime`), LLM provider abstraction (OpenAI, Anthropic, Ollama, etc.), and basic tools. The phase adds YAML-based agent definition, GSD-style shell execution, file-based session persistence, tool whitelisting, and retry/fallback logic.

**Primary recommendation:** Extend RLM-Toolkit's existing `Agent` and `Tool` classes with YAML configuration support, GSD-style shell execution, and file-based session memory. Use Pydantic-YAML for validation, Tenacity for retry logic, and AnyIO for async subprocess execution.

<user_constraints>
## User Constraints (from CONTEXT.md)

### Locked Decisions
- **Agent Definition Format:** YAML files (human-readable, supports comments, easy to hand-edit)
  - Required properties: name, role, goal, backstory — all four must be defined
  - Validation: Strict validation on load — fail fast with clear errors before execution
  - Tool specification: OpenCode's discretion (list format, tool+config, or groups)

- **Tool Configuration Model:**
  - Access model: OpenCode's discretion (allowlist per agent recommended)
  - Parameter restrictions: None — agent gets full tool access, no parameter filtering
  - Tool types: OpenCode's discretion (built-in only vs extensible)
  - Discovery: Definition only — agent only knows about tools in its definition

- **Shell Safety Controls (GSD-style):**
  - Execution model: Direct execution in project directory, like GSD Bash tool
  - Timeout: Configurable (like GSD's timeout parameter)
  - Error handling: Fail on non-zero exit code, agent sees output
  - Confirmation: No confirmation by default — agent is autonomous
  - Safety: No sandbox or whitelist — trust the agent

- **Context Passing Strategy (GSD-style):**
  - Context flow: Full context flow — task outputs + conversation history pass to next task
  - Persistence: File-based (like GSD's .planning/ directory)
  - Context limits: LLM handles its own context — no custom truncation or summarization

### OpenCode's Discretion
- Exact tool specification format (list vs tool+config vs groups)
- Default tool access model specifics
- Built-in only vs extensible tool system
- Session file format (JSON, Markdown, or hybrid)
- Default timeout value for shell commands

### Deferred Ideas (OUT OF SCOPE)
None — discussion stayed within phase scope
</user_constraints>

<phase_requirements>
## Phase Requirements

| ID | Description | Research Support |
|----|-------------|-----------------|
| AGENT-01 | User can define agents with name, role, goal, backstory, and tools | Pydantic-YAML schema + RLM-Toolkit Agent class |
| AGENT-02 | Agents execute tasks sequentially with context passing | RLM-Toolkit MultiAgentRuntime + AgentMessage |
| AGENT-03 | User can configure tool whitelist/blacklist per agent | Extend RLM-Toolkit ToolRegistry with per-agent filtering |
| AGENT-04 | Agents maintain session-level conversation memory | File-based persistence via JSON/Markdown |
| AGENT-06 | System validates agent inputs/outputs against guardrails | Pydantic validation + custom validators |
| AGENT-07 | Agents report progress status during execution | RLM-Toolkit CallbackManager + custom events |
| AGENT-08 | System handles agent failures with retry and fallback logic | Tenacity retry decorators + fallback agents |
| INT-06 | System supports 75+ LLM providers via RLM-Toolkit | RLM-Toolkit already provides this |
| INT-07 | User can configure default provider | RLM-Toolkit RLMConfig + provider selection |
| INT-09 | Agents can read files from project directory | RLM-Toolkit FileReadTool (extend for project scoping) |
| INT-10 | Agents can write and edit files in project directory | RLM-Toolkit FileWriteTool (extend for edit operations) |
| INT-11 | Agents can search files via glob and grep patterns | New GlobTool + GrepTool implementations |
| INT-12 | Agents can execute shell commands | AnyIO subprocess + GSD-style execution |
| INT-13 | Shell commands run with safety controls | Configurable timeout, fail on error, no sandbox (per user decision) |
</phase_requirements>

## Standard Stack

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| rlm-toolkit | 2.3.1 | Agent runtime, LLM providers, tools | Project foundation, already provides Agent, MultiAgentRuntime, Tool base classes |
| pydantic | 2.10.0 | Data validation | Type-safe models with validation, already in RLM-Toolkit |
| pyyaml | 6.0.2 | YAML parsing | Human-readable config files, already in RLM-Toolkit |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| pydantic-yaml | 1.0+ | YAML → Pydantic model parsing with validation | Agent definition files |
| tenacity | 8.2+ | Retry logic with exponential backoff | Agent failure handling (AGENT-08) |
| anyio | 4.0+ | Async subprocess with timeout | Shell execution (INT-12, INT-13) |
| litellm | 1.81+ | Unified LLM interface (alternative) | If RLM-Toolkit providers insufficient |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| pydantic-yaml | pyyaml + manual validation | Pydantic-YAML provides automatic validation, better error messages |
| anyio subprocess | asyncio subprocess directly | AnyIO provides cleaner timeout handling and cross-backend support |
| tenacity | manual retry loops | Tenacity provides declarative retry with backoff strategies |
| rlm-toolkit agents | crewai | RLM-Toolkit already integrated, CrewAI would add dependency weight |

**Installation:**
```bash
pip install pydantic-yaml tenacity anyio
# rlm-toolkit, pydantic, pyyaml already in project
```

## Architecture Patterns

### Recommended Project Structure
```
src/
├── gsd_rlm/
│   ├── __init__.py
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── definition.py      # YAML agent definition models
│   │   ├── loader.py          # YAML file loading + validation
│   │   └── runner.py          # Agent execution wrapper
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── file_tools.py      # Read, Write, Edit, Glob, Grep
│   │   ├── shell_tool.py      # GSD-style shell execution
│   │   └── registry.py        # Per-agent tool whitelisting
│   ├── session/
│   │   ├── __init__.py
│   │   ├── memory.py          # File-based session memory
│   │   └── persistence.py     # JSON/Markdown persistence
│   ├── execution/
│   │   ├── __init__.py
│   │   ├── runner.py          # Sequential task execution
│   │   ├── retry.py           # Tenacity-based retry logic
│   │   └── progress.py        # Progress reporting
│   └── config/
│       ├── __init__.py
│       └── settings.py        # Global + per-agent config
├── agents/                     # YAML agent definition files
│   ├── researcher.yaml
│   ├── planner.yaml
│   └── executor.yaml
└── .gsd-sessions/              # Session persistence directory
    └── session-{id}.json
```

### Pattern 1: YAML Agent Definition with Pydantic-YAML

**What:** Define agents in YAML files with strict validation on load
**When to use:** All agent definitions (AGENT-01)

```python
# Source: pydantic-yaml docs + RLM-Toolkit patterns
from pydantic import BaseModel, Field, field_validator
from pydantic_yaml import parse_yaml_raw_as, to_yaml_str
from typing import List, Optional, Literal
from enum import Enum

class ToolConfig(BaseModel):
    """Tool with optional configuration."""
    name: str
    config: dict = Field(default_factory=dict)

class AgentDefinition(BaseModel):
    """YAML agent definition with required fields."""
    name: str = Field(..., min_length=1, description="Agent name")
    role: str = Field(..., min_length=1, description="Agent role")
    goal: str = Field(..., min_length=1, description="Agent goal")
    backstory: str = Field(..., min_length=1, description="Agent backstory")
    tools: List[ToolConfig] = Field(default_factory=list)
    llm_provider: str = Field(default="ollama/llama3.2")
    timeout: int = Field(default=120, ge=1, le=3600)
    
    @field_validator('name', 'role', 'goal', 'backstory')
    @classmethod
    def not_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError('Field cannot be empty')
        return v.strip()

# Load from YAML
agent_def = parse_yaml_raw_as(AgentDefinition, yaml_content)

# Example YAML file:
# name: Code Reviewer
# role: Senior software engineer
# goal: Review code for quality and security issues
# backstory: |
#   You are a senior software engineer with 15 years of experience.
#   You specialize in code quality, security, and best practices.
# tools:
#   - name: read_file
#   - name: glob
#     config:
#       pattern: "**/*.py"
#   - name: shell
#     config:
#       timeout: 60
# llm_provider: anthropic/claude-3-sonnet
# timeout: 300
```

### Pattern 2: GSD-Style Shell Execution with AnyIO

**What:** Direct shell execution in project directory with configurable timeout
**When to use:** Shell commands (INT-12, INT-13)

```python
# Source: AnyIO docs + GSD Bash tool patterns
import anyio
from dataclasses import dataclass
from typing import Optional
from pathlib import Path

@dataclass
class ShellResult:
    exit_code: int
    stdout: str
    stderr: str
    command: str
    timed_out: bool = False

class GSDShellTool:
    """GSD-style shell execution: direct, shows output, fails on error."""
    
    def __init__(
        self,
        workdir: Path,
        timeout: int = 120,
        fail_on_error: bool = True,
    ):
        self.workdir = workdir
        self.timeout = timeout
        self.fail_on_error = fail_on_error
    
    async def run(self, command: str, timeout: Optional[int] = None) -> ShellResult:
        """Execute shell command with timeout."""
        timeout = timeout or self.timeout
        
        try:
            with anyio.fail_after(timeout):
                result = await anyio.run_process(
                    command,
                    shell=True,
                    cwd=self.workdir,
                    check=False,  # Don't raise on non-zero
                )
                
                return ShellResult(
                    exit_code=result.returncode,
                    stdout=result.stdout.decode('utf-8', errors='replace'),
                    stderr=result.stderr.decode('utf-8', errors='replace'),
                    command=command,
                )
        except TimeoutError:
            return ShellResult(
                exit_code=-1,
                stdout="",
                stderr=f"Command timed out after {timeout} seconds",
                command=command,
                timed_out=True,
            )
    
    def run_sync(self, command: str, timeout: Optional[int] = None) -> ShellResult:
        """Synchronous wrapper."""
        return anyio.run(self.run, command, timeout)
```

### Pattern 3: File-Based Session Memory

**What:** Persist conversation history and task outputs to files for resumable sessions
**When to use:** Session-level memory (AGENT-04)

```python
# Source: GSD .planning patterns + JSON persistence
import json
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict

@dataclass
class SessionMessage:
    role: str  # "user", "agent", "system"
    content: str
    timestamp: str
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}

@dataclass  
class SessionState:
    session_id: str
    agent_name: str
    created_at: str
    updated_at: str
    messages: List[SessionMessage]
    task_outputs: List[Dict[str, Any]]
    current_task: Optional[str] = None

class FileSessionMemory:
    """File-based session persistence for resumable conversations."""
    
    def __init__(self, sessions_dir: Path):
        self.sessions_dir = sessions_dir
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
    
    def _session_file(self, session_id: str) -> Path:
        return self.sessions_dir / f"session-{session_id}.json"
    
    def create(self, session_id: str, agent_name: str) -> SessionState:
        """Create new session."""
        now = datetime.utcnow().isoformat()
        session = SessionState(
            session_id=session_id,
            agent_name=agent_name,
            created_at=now,
            updated_at=now,
            messages=[],
            task_outputs=[],
        )
        self.save(session)
        return session
    
    def load(self, session_id: str) -> Optional[SessionState]:
        """Load existing session."""
        file = self._session_file(session_id)
        if not file.exists():
            return None
        
        with open(file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return SessionState(
            session_id=data['session_id'],
            agent_name=data['agent_name'],
            created_at=data['created_at'],
            updated_at=data['updated_at'],
            messages=[SessionMessage(**m) for m in data['messages']],
            task_outputs=data['task_outputs'],
            current_task=data.get('current_task'),
        )
    
    def save(self, session: SessionState) -> None:
        """Persist session to file."""
        session.updated_at = datetime.utcnow().isoformat()
        file = self._session_file(session.session_id)
        
        data = {
            'session_id': session.session_id,
            'agent_name': session.agent_name,
            'created_at': session.created_at,
            'updated_at': session.updated_at,
            'messages': [asdict(m) for m in session.messages],
            'task_outputs': session.task_outputs,
            'current_task': session.current_task,
        }
        
        with open(file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    def add_message(self, session: SessionState, role: str, content: str) -> None:
        """Add message to conversation history."""
        session.messages.append(SessionMessage(
            role=role,
            content=content,
            timestamp=datetime.utcnow().isoformat(),
        ))
        self.save(session)
    
    def get_context_for_llm(self, session: SessionState, max_messages: int = 50) -> List[Dict]:
        """Get conversation history in LLM format."""
        messages = session.messages[-max_messages:]
        return [{"role": m.role, "content": m.content} for m in messages]
```

### Pattern 4: Retry with Fallback using Tenacity

**What:** Retry failed tasks with exponential backoff, fallback to alternative agent
**When to use:** Agent failure handling (AGENT-08)

```python
# Source: Tenacity docs
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    before_sleep_log,
)
import logging

logger = logging.getLogger(__name__)

class AgentExecutionError(Exception):
    """Raised when agent execution fails."""
    pass

class FallbackExhaustedError(Exception):
    """All fallback agents failed."""
    pass

class RetryableAgent:
    """Agent wrapper with retry and fallback logic."""
    
    def __init__(
        self,
        primary_agent,
        fallback_agents: list = None,
        max_retries: int = 3,
        min_wait: float = 2.0,
        max_wait: float = 30.0,
    ):
        self.primary_agent = primary_agent
        self.fallback_agents = fallback_agents or []
        self.max_retries = max_retries
        self.min_wait = min_wait
        self.max_wait = max_wait
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type(AgentExecutionError),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True,
    )
    def _execute_with_retry(self, agent, message):
        """Execute with exponential backoff retry."""
        try:
            result = agent.process(message)
            if not result:
                raise AgentExecutionError(f"Agent {agent.name} returned no result")
            return result
        except Exception as e:
            logger.warning(f"Agent {agent.name} failed: {e}")
            raise AgentExecutionError(str(e)) from e
    
    def execute(self, message):
        """Execute with retry, then fallback agents."""
        errors = []
        
        # Try primary agent
        try:
            return self._execute_with_retry(self.primary_agent, message)
        except AgentExecutionError as e:
            errors.append(f"Primary agent failed: {e}")
            logger.error(errors[-1])
        
        # Try fallback agents
        for i, fallback in enumerate(self.fallback_agents):
            try:
                logger.info(f"Trying fallback agent {i+1}: {fallback.name}")
                return self._execute_with_retry(fallback, message)
            except AgentExecutionError as e:
                errors.append(f"Fallback {i+1} ({fallback.name}) failed: {e}")
                logger.error(errors[-1])
        
        # All failed
        raise FallbackExhaustedError(
            f"All agents failed:\n" + "\n".join(errors)
        )
```

### Pattern 5: Per-Agent Tool Whitelisting

**What:** Each agent only has access to tools defined in its configuration
**When to use:** Tool access control (AGENT-03)

```python
# Source: RLM-Toolkit ToolRegistry patterns
from rlm_toolkit.tools import Tool, ToolRegistry
from typing import Dict, List, Optional, Set

class AgentToolRegistry:
    """Per-agent tool registry with whitelisting."""
    
    def __init__(self, global_registry: ToolRegistry):
        self.global_registry = global_registry
        self._agent_tools: Dict[str, Set[str]] = {}
        self._tool_configs: Dict[str, Dict[str, dict]] = {}
    
    def configure_agent(
        self,
        agent_id: str,
        allowed_tools: List[str],
        tool_configs: Optional[Dict[str, dict]] = None,
    ) -> None:
        """Configure which tools an agent can use."""
        self._agent_tools[agent_id] = set(allowed_tools)
        self._tool_configs[agent_id] = tool_configs or {}
    
    def get_tool(self, agent_id: str, tool_name: str) -> Optional[Tool]:
        """Get tool for agent if allowed."""
        allowed = self._agent_tools.get(agent_id, set())
        
        if tool_name not in allowed:
            return None
        
        tool = self.global_registry.get(tool_name)
        if not tool:
            return None
        
        # Apply tool-specific config if any
        config = self._tool_configs.get(agent_id, {}).get(tool_name, {})
        if config:
            # Create configured instance
            return self._configure_tool(tool, config)
        
        return tool
    
    def list_tools(self, agent_id: str) -> List[str]:
        """List tools available to agent."""
        return list(self._agent_tools.get(agent_id, set()))
    
    def _configure_tool(self, tool: Tool, config: dict) -> Tool:
        """Apply configuration to tool instance."""
        # Tool-specific configuration logic
        # For example, setting timeout on ShellTool
        if hasattr(tool, 'timeout') and 'timeout' in config:
            tool.timeout = config['timeout']
        return tool
```

### Anti-Patterns to Avoid
- **Centralized orchestrator bottleneck:** Don't create a single orchestrator that all messages pass through; use RLM-Toolkit's decentralized `AgentMessage` with embedded routing
- **In-memory session only:** Don't lose session state on restart; always persist to file
- **Silent failure swallowing:** Don't catch exceptions without logging; use Tenacity's `before_sleep_log`
- **Tool access by convention:** Don't rely on agents "knowing" not to use tools; enforce via whitelist
- **Custom YAML parsing:** Don't write manual YAML validators; use Pydantic-YAML for automatic validation

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| Agent runtime | Custom Agent class | rlm_toolkit.agents.Agent | Already has role, name, trust_zone, process() |
| LLM provider abstraction | Provider switching logic | rlm_toolkit.providers or litellm | 75+ providers, unified interface |
| Tool base class | Custom tool interface | rlm_toolkit.tools.Tool | Already has name, description, run() |
| Retry logic | Manual retry loops | tenacity | Exponential backoff, jitter, stop conditions |
| YAML parsing | Manual YAML validation | pydantic-yaml | Automatic validation, clear error messages |
| Subprocess with timeout | asyncio.run_in_executor | anyio.run_process | Cross-backend, clean timeout handling |
| Message routing | Custom queue system | rlm_toolkit.agents.MessageQueue | Thread-safe, already implemented |

**Key insight:** RLM-Toolkit provides 80% of Phase 1 infrastructure. The research task is identifying what to extend (YAML loading, session persistence, tool whitelisting) vs what to use directly (Agent, MultiAgentRuntime, providers).

## Common Pitfalls

### Pitfall 1: YAML Validation Too Late
**What goes wrong:** Loading YAML files without validation, then failing during execution with cryptic errors
**Why it happens:** Developers skip validation for "simple" configs, errors only surface at runtime
**How to avoid:** Use Pydantic-YAML's `parse_yaml_raw_as()` which validates on load and fails fast with field-level error messages
**Warning signs:** Agent loads successfully but fails when accessing undefined fields

### Pitfall 2: Shell Command Injection
**What goes wrong:** Untrusted input in shell commands executes arbitrary code
**Why it happens:** Using `shell=True` with user-provided strings
**How to avoid:** Per user decision: "trust the agent" - no sandbox, but document that this is intentional. For future security phases, consider command whitelists or argument escaping.
**Warning signs:** Commands constructed from user input without escaping

### Pitfall 3: Session Memory Loss
**What goes wrong:** Long-running sessions lose context on restart
**Why it happens:** Storing session state only in memory
**How to avoid:** Persist every message and task output immediately to file using FileSessionMemory pattern
**Warning signs:** Session state not updated after each agent interaction

### Pitfall 4: Retry Storm
**What goes wrong:** Failed agents retry indefinitely, exhausting API quotas
**Why it happens:** Not setting `stop_after_attempt()` or `stop_after_delay()` in Tenacity
**How to avoid:** Always configure both: `stop=(stop_after_attempt(3) | stop_after_delay(60))`
**Warning signs:** Same error repeating in logs without progress

### Pitfall 5: Context Window Overflow
**What goes wrong:** Session history exceeds LLM context limit
**Why it happens:** Never truncating conversation history
**How to avoid:** Per user decision: "LLM handles its own context" - but implement `get_context_for_llm()` with `max_messages` default for safety
**Warning signs:** LLM requests failing with context length errors

## Code Examples

### Complete Agent Definition Loader

```python
# Source: pydantic-yaml patterns + RLM-Toolkit integration
from pathlib import Path
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator
from pydantic_yaml import parse_yaml_raw_as

from rlm_toolkit.agents import Agent, AgentRole, AgentMessage
from rlm_toolkit.tools import ToolRegistry

class ToolSpec(BaseModel):
    """Tool specification in agent definition."""
    name: str
    config: dict = Field(default_factory=dict)

class AgentDefinition(BaseModel):
    """Complete agent definition from YAML."""
    # Required fields (AGENT-01)
    name: str = Field(..., min_length=1)
    role: str = Field(..., min_length=1)
    goal: str = Field(..., min_length=1)
    backstory: str = Field(..., min_length=1)
    
    # Optional tool configuration (AGENT-03)
    tools: List[ToolSpec] = Field(default_factory=list)
    
    # Execution settings
    llm_provider: str = "ollama/llama3.2"
    timeout: int = Field(default=120, ge=1, le=3600)
    max_retries: int = Field(default=3, ge=0, le=10)
    fallback_agents: List[str] = Field(default_factory=list)
    
    @field_validator('name', 'role', 'goal', 'backstory')
    @classmethod
    def validate_required(cls, v: str, info) -> str:
        if not v or not v.strip():
            raise ValueError(f'{info.field_name} is required and cannot be empty')
        return v.strip()

class AgentLoader:
    """Load and validate agents from YAML files."""
    
    def __init__(self, tools_registry: ToolRegistry):
        self.tools_registry = tools_registry
    
    def load_from_file(self, yaml_path: Path) -> AgentDefinition:
        """Load agent definition from YAML file with validation."""
        if not yaml_path.exists():
            raise FileNotFoundError(f"Agent definition not found: {yaml_path}")
        
        content = yaml_path.read_text(encoding='utf-8')
        
        try:
            return parse_yaml_raw_as(AgentDefinition, content)
        except Exception as e:
            raise ValueError(f"Invalid agent definition in {yaml_path}: {e}") from e
    
    def create_agent(self, definition: AgentDefinition, llm_provider) -> Agent:
        """Create runtime agent from definition."""
        from rlm_toolkit.agents import LLMAgent
        
        system_prompt = f"""You are {definition.name}.

Role: {definition.role}
Goal: {definition.goal}

Background:
{definition.backstory}

Available tools: {', '.join(t.name for t in definition.tools)}
"""
        
        return LLMAgent(
            agent_id=definition.name.lower().replace(' ', '-'),
            name=definition.name,
            llm_provider=llm_provider,
            system_prompt=system_prompt,
            role=AgentRole.CUSTOM,
        )
```

### Sequential Task Execution with Context Passing

```python
# Source: RLM-Toolkit MultiAgentRuntime patterns
from typing import List, Callable, Optional
from rlm_toolkit.agents import AgentMessage, MultiAgentRuntime

class SequentialTaskRunner:
    """Execute tasks sequentially with full context passing (AGENT-02)."""
    
    def __init__(
        self,
        runtime: MultiAgentRuntime,
        session_memory: 'FileSessionMemory',
        on_progress: Optional[Callable[[str, str, str], None]] = None,
    ):
        self.runtime = runtime
        self.session = session_memory
        self.on_progress = on_progress
    
    def run_tasks(
        self,
        tasks: List[str],
        session_id: str,
        agent_ids: List[str],
    ) -> AgentMessage:
        """Execute tasks sequentially, passing context between each."""
        
        # Load or create session
        session = self.session.load(session_id)
        if not session:
            session = self.session.create(session_id, agent_ids[0])
        
        # Build initial message with session context
        message = AgentMessage(
            task_id=session_id,
            content=tasks[0] if tasks else "",
            history=self._session_to_history(session),
            routing=agent_ids,
        )
        
        # Execute each task
        for i, task in enumerate(tasks):
            self._report_progress("starting", task, f"Task {i+1}/{len(tasks)}")
            
            message.content = task
            
            # Run through agent pipeline
            result = self.runtime.run(
                message,
                on_step=self._make_step_callback(session),
            )
            
            # Store task output
            session.task_outputs.append({
                "task": task,
                "result": result.content,
                "routing": result.routing,
            })
            self.session.save(session)
            
            self._report_progress("completed", task, str(result.content)[:100])
            
            # Pass context to next task
            message = result
        
        return message
    
    def _session_to_history(self, session) -> List[dict]:
        """Convert session messages to AgentMessage history format."""
        return [
            {"role": m.role, "content": m.content}
            for m in session.messages
        ]
    
    def _make_step_callback(self, session):
        """Create callback that updates session on each agent step."""
        def callback(message, agent):
            session.messages.append({
                "role": "agent",
                "content": f"[{agent.name}] Processing...",
            })
            self.session.save(session)
        return callback
    
    def _report_progress(self, status: str, task: str, detail: str):
        """Report progress if callback provided (AGENT-07)."""
        if self.on_progress:
            self.on_progress(status, task, detail)
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| Centralized orchestrator | Decentralized P2P (Meta Matrix) | 2025 | 2-15x throughput, no bottleneck |
| Manual retry loops | Tenacity declarative retry | 2020+ | Cleaner code, exponential backoff built-in |
| Custom YAML parsing | Pydantic-YAML validation | 2023+ | Automatic validation, clear errors |
| asyncio subprocess | AnyIO subprocess | 2023+ | Cross-backend, cleaner timeout handling |
| In-memory sessions | File-based persistence | GSD pattern | Resumable sessions, no data loss |

**Deprecated/outdated:**
- `subprocess.run()` without timeout: Use AnyIO with `fail_after()` for proper timeout handling
- Manual context truncation: Per user decision, let LLM handle its own context
- Custom tool interfaces: Use RLM-Toolkit's `Tool` base class

## Open Questions

1. **Tool specification format in YAML**
   - What we know: List format `[tool_name, tool_name]` is simplest
   - What's unclear: Whether to support tool+config objects `[{name: tool, config: {...}}]`
   - Recommendation: Start with simple list format, add config support when needed

2. **Default timeout value**
   - What we know: GSD uses configurable timeout
   - What's unclear: What's a sensible default (60s? 120s? 300s?)
   - Recommendation: 120 seconds as default, configurable per-agent and per-command

3. **Session file format**
   - What we know: JSON is simple, Markdown is human-readable
   - What's unclear: Whether to support hybrid (JSON for machine, Markdown summary for humans)
   - Recommendation: JSON for machine processing, generate Markdown summary on demand

## Sources

### Primary (HIGH confidence)
- `/websites/pydantic-yaml_readthedocs_io_en` - YAML parsing with Pydantic validation
- `/crewaiinc/crewai` - Agent definition patterns (role, goal, backstory, tools)
- `/berriai/litellm` - Multi-provider LLM abstraction (alternative to RLM-Toolkit)
- `/agronholm/anyio` - Async subprocess with timeout
- `/websites/tenacity_readthedocs_io_en` - Retry logic with exponential backoff
- `rlm-toolkit/rlm_toolkit/agents/core.py` - Existing agent infrastructure
- `rlm-toolkit/rlm_toolkit/tools/__init__.py` - Existing tool infrastructure

### Secondary (MEDIUM confidence)
- `rlm-toolkit/pyproject.toml` - Version requirements and dependencies
- `.planning/REQUIREMENTS.md` - Phase 1 requirements mapping
- `.planning/PROJECT.md` - RLM-Toolkit foundation context

### Tertiary (LOW confidence)
- None - all critical information verified from primary sources

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - RLM-Toolkit already provides foundation, researched libraries (Pydantic-YAML, Tenacity, AnyIO) are well-documented
- Architecture: HIGH - Patterns derived from existing RLM-Toolkit code and Context7-verified examples
- Pitfalls: HIGH - Based on documented gotchas from Context7 sources and common multi-agent issues

**Research date:** 2026-02-27
**Valid until:** 30 days - Python ecosystem stable, RLM-Toolkit v2.3.1 is project foundation
