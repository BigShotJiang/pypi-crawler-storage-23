# Phase 1: Core Workflow Foundation - Context

**Gathered:** 2026-02-27
**Status:** Ready for planning

<domain>
## Phase Boundary

Users can define and run agents that execute sequential tasks with persistent state and full file/shell access. This phase delivers the foundational agent execution model — definition, sequential execution, file tools, shell commands, and session memory. Parallel execution, memory systems, and security come in later phases.

</domain>

<decisions>
## Implementation Decisions

### Agent Definition Format
- **Format:** YAML files (human-readable, supports comments, easy to hand-edit)
- **Required properties:** name, role, goal, backstory — all four must be defined
- **Validation:** Strict validation on load — fail fast with clear errors before execution
- **Tool specification:** OpenCode's discretion (list format, tool+config, or groups)

### Tool Configuration Model
- **Access model:** OpenCode's discretion (allowlist per agent recommended)
- **Parameter restrictions:** None — agent gets full tool access, no parameter filtering
- **Tool types:** OpenCode's discretion (built-in only vs extensible)
- **Discovery:** Definition only — agent only knows about tools in its definition

### Shell Safety Controls (GSD-style)
- **Execution model:** Direct execution in project directory, like GSD Bash tool
- **Timeout:** Configurable (like GSD's timeout parameter)
- **Error handling:** Fail on non-zero exit code, agent sees output
- **Confirmation:** No confirmation by default — agent is autonomous
- **Safety:** No sandbox or whitelist — trust the agent

### Context Passing Strategy (GSD-style)
- **Context flow:** Full context flow — task outputs + conversation history pass to next task
- **Persistence:** File-based (like GSD's .planning/ directory)
- **Context limits:** LLM handles its own context — no custom truncation or summarization

### OpenCode's Discretion
- Exact tool specification format (list vs tool+config vs groups)
- Default tool access model specifics
- Built-in only vs extensible tool system
- Session file format (JSON, Markdown, or hybrid)
- Default timeout value for shell commands

</decisions>

<specifics>
## Specific Ideas

- "All aspects should be like GSD" — shell execution, context passing, file-based persistence
- Shell behavior mirrors GSD Bash tool: direct, shows output, fails on error, configurable timeout
- Session memory should be resumable (file-based, not memory-only)

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope

</deferred>

---

*Phase: 01-core-workflow-foundation*
*Context gathered: 2026-02-27*
