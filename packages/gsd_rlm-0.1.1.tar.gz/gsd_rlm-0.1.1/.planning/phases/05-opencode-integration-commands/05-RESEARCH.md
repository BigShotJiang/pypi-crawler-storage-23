# Phase 5: OpenCode Integration + Commands - Research

**Researched:** 2026-02-27
**Domain:** OpenCode skill/command integration, human-in-the-loop checkpoints, spec-driven workflow, git traceability
**Confidence:** HIGH

## Summary

Phase 5 bridges the GSD-RLM multi-agent system with OpenCode's user-facing interface. This involves three main integration points: (1) packaging agent capabilities as OpenCode skills with SKILL.md definitions, (2) implementing /gsd-rlm-* commands that invoke orchestrator entry points, and (3) implementing the checkpoint system for human-in-the-loop interactions.

The GSD system provides an excellent reference pattern: skills are markdown files with YAML frontmatter that define purpose, triggers, tools, and workflow steps. Commands are implemented as workflow markdown files that orchestrate agents through structured phases. The checkpoint system uses three types: human-verify (90%), decision (9%), and human-action (1%).

**Primary recommendation:** Follow GSD patterns for skill/command structure. Create a thin integration layer that maps OpenCode invocations to existing GSD-RLM orchestrator methods, implementing checkpoints as async pause/resume points in the execution flow.

<phase_requirements>

## Phase Requirements

| ID | Description | Research Support |
|----|-------------|------------------|
| INT-01 | Agent capabilities packaged as OpenCode skills (SKILL.md) | SKILL.md format: YAML frontmatter + markdown body with purpose, workflow, scripts |
| INT-02 | Skills define purpose, triggers, tools, and workflow steps | GSD skill pattern: frontmatter (name, description, tools) + sections (workflow, implementation) |
| INT-03 | System discovers and loads skills from skills/ directory | Recursive directory scan, SKILL.md parsing, skill registry pattern |
| INT-04 | User can invoke workflow via /gsd-rlm-* commands | Command → orchestrator entry point mapping, gsd-tools.cjs init pattern |
| INT-05 | Commands map to orchestrator entry points (new-project, plan-phase, execute-phase) | HybridOrchestrator.execute() + init command pattern for context loading |
| INT-08 | System routes requests to appropriate provider based on task type | LLMProvider enum + provider routing via rlm-toolkit |
| INT-14 | System creates atomic git commits per task completion | gsd-tools.cjs commit command pattern, commit message format with phase/plan/task |
| INT-15 | Commits include traceability to phase, plan, and task IDs | Commit message format: `type(phase-plan-task): description` |
| EXEC-05 | System pauses at decision checkpoints for user input | checkpoint:decision pattern with options, context, resume-signal |
| EXEC-06 | System pauses at verification checkpoints for user review | checkpoint:human-verify pattern with what-built, how-to-verify, resume-signal |
| EXEC-07 | System pauses at action checkpoints for manual steps | checkpoint:human-action pattern for auth gates, email verification |
| EXEC-10 | System supports spec-driven development flow (ROADMAP→PLAN→EXECUTE→VERIFY) | Workflow orchestration via markdown files, phase progression tracking |
| EXEC-11 | System validates must-haves against phase goals before completion | VERIFICATION.md template, must_haves.artifacts, must_haves.key_links |
| EXEC-12 | System implements goal-backward verification (truths, artifacts, key_links) | Verification workflow with artifact checking, key link validation |

</phase_requirements>

## Standard Stack

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| pydantic | >=2.0.0 | SKILL.md frontmatter parsing, skill registry models | Already in use for AgentDefinition validation |
| pyyaml | >=6.0 | YAML frontmatter parsing for SKILL.md | Standard for configuration, already in dependencies |
| anyio | >=4.0.0 | Async checkpoint handling, streaming | Already in use for execution engine |
| rlm-toolkit | >=2.3.0 | LLM provider routing, tool base classes | Core dependency for multi-agent runtime |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| tenacity | >=8.0.0 | Retry logic for command execution | When commands need retry with backoff |
| networkx | >=3.0.0 | Skill dependency graph (if skills depend on each other) | For complex skill relationships |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| Custom skill format | JSON Schema | YAML frontmatter more readable, matches GSD patterns |
| Custom command routing | CLI framework (Click/Typer) | GSD uses markdown workflow files, consistent with existing patterns |
| Custom checkpoint state | Database persistence | File-based JSON matches existing SessionMemory pattern |

**Installation:**
```bash
# All dependencies already in pyproject.toml
pip install -e ".[dev]"
```

## Architecture Patterns

### Recommended Project Structure
```
src/gsd_rlm/
├── skills/                    # OpenCode skill definitions
│   ├── __init__.py           # Skill registry
│   ├── discovery.py          # SKILL.md discovery and loading
│   ├── base.py               # Base skill classes
│   └── gsd_rlm/              # GSD-RLM specific skills
│       ├── new_project/
│       │   └── SKILL.md      # /gsd-rlm-new-project skill
│       ├── plan_phase/
│       │   └── SKILL.md      # /gsd-rlm-plan-phase skill
│       └── execute_phase/
│           └── SKILL.md      # /gsd-rlm-execute-phase skill
├── commands/                  # Command implementations
│   ├── __init__.py           # Command registry
│   ├── router.py             # Command → orchestrator routing
│   └── handlers/             # Per-command handlers
│       ├── new_project.py
│       ├── plan_phase.py
│       └── execute_phase.py
├── checkpoints/               # Human-in-the-loop system
│   ├── __init__.py
│   ├── types.py              # CheckpointType enum, Checkpoint dataclass
│   ├── manager.py            # Checkpoint pause/resume logic
│   └── handlers.py           # Per-checkpoint-type handlers
├── workflow/                  # Spec-driven workflow
│   ├── __init__.py
│   ├── spec_loader.py        # ROADMAP/REQUIREMENTS loading
│   ├── phase_tracker.py      # Phase progression tracking
│   └── verification.py       # Goal-backward verification
└── git/                       # Git traceability
    ├── __init__.py
    ├── commits.py            # Atomic commit creation
    └── traceability.py       # Phase/plan/task ID embedding
```

### Pattern 1: SKILL.md Definition Format

**What:** Markdown files with YAML frontmatter that define agent capabilities
**When to use:** For every user-facing agent capability

**Example:**
```markdown
---
name: gsd-rlm-plan-phase
description: Create executable PLAN.md files for a roadmap phase with integrated research and verification
tools:
  read: true
  write: true
  bash: true
  grep: true
  glob: true
  websearch: true
  webfetch: true
  mcp__context7__*: true
color: "#00FFAA"
---

# Plan Phase Skill

<role>
You are a GSD phase planner. You create executable PLAN.md files...
</role>

<purpose>
Create executable phase prompts for a roadmap phase...
</purpose>

<process>
<step name="initialize" priority="first">
Load context via gsd-tools.cjs init...
</step>
...
</process>
```

**Source:** GSD skills pattern from `~/.config/opencode/skills/gsd-oc-select-model/SKILL.md`

### Pattern 2: Command → Orchestrator Routing

**What:** Commands invoke orchestrator entry points with context loading
**When to use:** For all /gsd-rlm-* commands

**Example:**
```python
# src/gsd_rlm/commands/handlers/execute_phase.py
from typing import Dict, Any
from pathlib import Path

from gsd_rlm.coordination.orchestrator import HybridOrchestrator
from gsd_rlm.execution.dependency import DependencyGraph
from gsd_rlm.execution.parallel import WaveRunner


async def execute_phase_command(
    phase: str,
    project_dir: Path,
    config: Dict[str, Any],
) -> Dict[str, Any]:
    """Execute all plans in a phase using wave-based parallel execution.
    
    Maps /gsd-rlm-execute-phase to HybridOrchestrator.execute().
    
    Args:
        phase: Phase number (e.g., "1", "2.1")
        project_dir: Project root directory
        config: Configuration from .planning/config.json
        
    Returns:
        Execution results with wave summaries
    """
    # Load context (matches gsd-tools.cjs init pattern)
    phase_dir = _find_phase_dir(project_dir, phase)
    plans = _discover_plans(phase_dir)
    
    # Build dependency graph
    graph = DependencyGraph()
    for plan in plans:
        graph.add_task(plan.id, depends_on=plan.dependencies)
    
    # Create orchestrator
    runner = WaveRunner(max_concurrent=config.get("max_concurrent", 10))
    orchestrator = HybridOrchestrator(graph, runner)
    
    # Execute with checkpoint support
    results = await orchestrator.execute(
        executor=_make_plan_executor(phase_dir, config),
        on_wave_complete=_handle_wave_checkpoint,
        on_progress=_handle_progress_update,
    )
    
    return {"phase": phase, "waves": results}
```

**Source:** Derived from `gsd_rlm/coordination/orchestrator.py` + GSD workflow patterns

### Pattern 3: Checkpoint System

**What:** Three checkpoint types for human-in-the-loop interaction
**When to use:** At decision, verification, and action points in workflow

**Example:**
```python
# src/gsd_rlm/checkpoints/types.py
from enum import Enum
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


class CheckpointType(str, Enum):
    """Checkpoint types for human-in-the-loop interaction."""
    HUMAN_VERIFY = "human-verify"   # 90% - visual/functional verification
    DECISION = "decision"            # 9% - architectural choices
    HUMAN_ACTION = "human-action"    # 1% - auth gates, email verification


@dataclass
class Checkpoint:
    """A checkpoint that pauses execution for user input."""
    type: CheckpointType
    gate: str  # "blocking" or "non-blocking"
    
    # For human-verify
    what_built: Optional[str] = None
    how_to_verify: Optional[str] = None
    
    # For decision
    decision: Optional[str] = None
    context: Optional[str] = None
    options: Optional[List[Dict[str, str]]] = None
    
    # For human-action
    action: Optional[str] = None
    instructions: Optional[str] = None
    verification: Optional[str] = None
    
    # Common
    resume_signal: str = "Type 'approved' or describe issues"
    
    def format_display(self) -> str:
        """Format checkpoint for display to user."""
        if self.type == CheckpointType.HUMAN_VERIFY:
            return f"""
╔═══════════════════════════════════════════════════════╗
║  CHECKPOINT: Verification Required                    ║
╚═══════════════════════════════════════════════════════╝

Built: {self.what_built}

How to verify:
{self.how_to_verify}

────────────────────────────────────────────────────────
→ YOUR ACTION: {self.resume_signal}
────────────────────────────────────────────────────────
"""
        # ... similar for other types
```

**Source:** `~/.config/opencode/get-shit-done/references/checkpoints.md`

### Pattern 4: Git Traceability

**What:** Atomic commits with embedded phase/plan/task IDs
**When to use:** After each task completion

**Example:**
```python
# src/gsd_rlm/git/commits.py
from dataclasses import dataclass
from typing import Optional
import subprocess


@dataclass
class CommitMetadata:
    """Metadata for atomic git commits with traceability."""
    phase: str       # e.g., "05"
    plan: str        # e.g., "01"
    task: str        # e.g., "03"
    type: str        # e.g., "feat", "fix", "test", "docs"
    description: str # Brief description
    
    def to_message(self) -> str:
        """Generate commit message with traceability.
        
        Format: type(phase-plan-task): description
        
        Example: feat(05-01-03): add checkpoint pause/resume logic
        """
        return f"{self.type}({self.phase}-{self.plan}-{self.task}): {self.description}"


def create_atomic_commit(
    metadata: CommitMetadata,
    files: list[str],
    working_dir: str = ".",
) -> str:
    """Create atomic git commit with traceability.
    
    Args:
        metadata: Commit metadata with phase/plan/task IDs
        files: List of files to commit
        working_dir: Git repository root
        
    Returns:
        Commit hash
    """
    # Stage files
    for file in files:
        subprocess.run(
            ["git", "add", file],
            cwd=working_dir,
            check=True,
            capture_output=True,
        )
    
    # Create commit with traceability
    message = metadata.to_message()
    result = subprocess.run(
        ["git", "commit", "-m", message],
        cwd=working_dir,
        check=True,
        capture_output=True,
        text=True,
    )
    
    # Extract commit hash
    hash_result = subprocess.run(
        ["git", "rev-parse", "--short", "HEAD"],
        cwd=working_dir,
        check=True,
        capture_output=True,
        text=True,
    )
    
    return hash_result.stdout.strip()
```

**Source:** GSD commit patterns from `gsd-tools.cjs` + ROADMAP traceability requirements

### Anti-Patterns to Avoid

- **Blocking on checkpoints in async code:** Don't use `input()` in async functions. Use async queues or event-based signaling.
- **Storing checkpoint state globally:** Each checkpoint should be serializable and restorable from session memory.
- **Hardcoded provider routing:** Use the LLMProvider enum and configuration, not hardcoded provider names.
- **Skipping verification:** The spec-driven flow requires verification before phase completion.

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| YAML frontmatter parsing | Custom regex parser | `pyyaml` + `pydantic` | Edge cases in YAML spec, type safety |
| Git operations | subprocess git commands | GitPython or dulwich | Better error handling, async support |
| LLM provider routing | Custom if/else chains | `rlm_toolkit.providers` | 75+ providers already supported |
| Checkpoint state persistence | Custom file format | Existing `FileSessionMemory` | Consistency with session memory |
| Dependency analysis | Custom graph algorithm | `networkx.DiGraph` | Battle-tested, handles cycles |

**Key insight:** The existing codebase already has session persistence, dependency analysis, and execution orchestration. Phase 5 is primarily integration work, not new infrastructure.

## Common Pitfalls

### Pitfall 1: Checkpoint Blocking in Async Context

**What goes wrong:** Using synchronous `input()` in async execution blocks the entire event loop, preventing other agents from progressing.

**Why it happens:** Checkpoints need user input, but async code expects non-blocking operations.

**How to avoid:** Use async queues or AnyIO event-based signaling:
```python
import anyio
from anyio.abc import ObjectReceiveStream, ObjectSendStream

async def checkpoint_with_user_input(
    checkpoint: Checkpoint,
    request_stream: ObjectSendStream,
    response_stream: ObjectReceiveStream,
) -> str:
    """Non-blocking checkpoint that waits for user response."""
    # Send checkpoint to UI
    async with request_stream:
        await request_stream.send(checkpoint)
    
    # Wait for response (non-blocking)
    async with response_stream:
        response = await response_stream.receive()
    
    return response
```

**Warning signs:** Execution hangs, no progress updates, other agents not running.

### Pitfall 2: Skill Discovery Not Finding Skills

**What goes wrong:** Skills in subdirectories not discovered, or wrong SKILL.md files loaded.

**Why it happens:** Recursive directory walking is tricky, symlinks can cause issues, file naming conflicts.

**How to avoid:** Use explicit skill directory configuration with validation:
```python
def discover_skills(skills_dir: Path) -> list[SkillDefinition]:
    """Discover all SKILL.md files in skills directory."""
    skills = []
    for skill_file in skills_dir.rglob("SKILL.md"):
        skill = load_skill(skill_file)
        if skill.validate():
            skills.append(skill)
        else:
            logger.warning(f"Invalid skill: {skill_file}")
    return skills
```

**Warning signs:** Skills not appearing in registry, wrong skill loaded for command.

### Pitfall 3: Git Commit Traceability Lost

**What goes wrong:** Commits don't include phase/plan/task IDs, audit trails broken.

**Why it happens:** Commit message format not enforced, metadata not passed to commit function.

**How to avoid:** Use strict commit message format with validation:
```python
import re

COMMIT_PATTERN = re.compile(r"^(feat|fix|test|docs|refactor)\((\d+)-(\d+)-(\d+)\): .+$")

def validate_commit_message(message: str) -> bool:
    """Validate commit message has traceability."""
    return bool(COMMIT_PATTERN.match(message))
```

**Warning signs:** `git log` shows commits without traceability pattern.

### Pitfall 4: Provider Routing Fails Silently

**What goes wrong:** Tasks routed to wrong provider, or no provider available, execution fails with cryptic error.

**Why it happens:** Provider routing logic doesn't handle all task types, fallback not configured.

**How to avoid:** Always have fallback provider configured, log routing decisions:
```python
def route_to_provider(task_type: str, config: dict) -> str:
    """Route task to appropriate LLM provider."""
    provider = TASK_PROVIDER_MAP.get(task_type)
    if not provider:
        provider = config.get("default_provider", "ollama")
        logger.info(f"No specific provider for {task_type}, using fallback: {provider}")
    return provider
```

**Warning signs:** Tasks failing with "no provider" errors, unexpected provider usage.

## Code Examples

### Skill Discovery and Loading

```python
# src/gsd_rlm/skills/discovery.py
from pathlib import Path
from typing import List, Optional
from dataclasses import dataclass
import yaml
from pydantic import BaseModel, Field


class SkillFrontmatter(BaseModel):
    """YAML frontmatter for SKILL.md files."""
    name: str = Field(..., min_length=1)
    description: str = Field(..., min_length=1)
    tools: dict[str, bool] = Field(default_factory=dict)
    color: str = Field(default="#00FFAA")


@dataclass
class SkillDefinition:
    """Complete skill definition from SKILL.md."""
    frontmatter: SkillFrontmatter
    content: str  # Markdown body
    path: Path
    
    @classmethod
    def from_file(cls, path: Path) -> "SkillDefinition":
        """Load skill from SKILL.md file."""
        content = path.read_text(encoding="utf-8")
        
        # Parse frontmatter (between --- markers)
        if not content.startswith("---"):
            raise ValueError(f"SKILL.md must start with frontmatter: {path}")
        
        parts = content.split("---", 2)
        if len(parts) < 3:
            raise ValueError(f"Invalid frontmatter format: {path}")
        
        frontmatter_yaml = yaml.safe_load(parts[1])
        frontmatter = SkillFrontmatter(**frontmatter_yaml)
        body = parts[2].strip()
        
        return cls(frontmatter=frontmatter, content=body, path=path)


def discover_skills(skills_dir: Path) -> List[SkillDefinition]:
    """Discover all SKILL.md files in skills directory tree.
    
    Args:
        skills_dir: Root directory for skills
        
    Returns:
        List of validated skill definitions
    """
    skills = []
    
    for skill_file in skills_dir.rglob("SKILL.md"):
        try:
            skill = SkillDefinition.from_file(skill_file)
            skills.append(skill)
        except Exception as e:
            # Log but don't fail - invalid skills are skipped
            print(f"Warning: Failed to load skill {skill_file}: {e}")
    
    return skills
```

**Source:** GSD skill patterns + existing AgentDefinition validation pattern

### Checkpoint Manager

```python
# src/gsd_rlm/checkpoints/manager.py
from typing import Optional, Callable, Awaitable
from dataclasses import asdict
import json
from pathlib import Path

from gsd_rlm.checkpoints.types import Checkpoint, CheckpointType
from gsd_rlm.session.memory import FileSessionMemory


class CheckpointManager:
    """Manages checkpoint pause/resume with session persistence.
    
    Checkpoints are stored in session memory for resumability.
    """
    
    def __init__(
        self,
        session_memory: FileSessionMemory,
        on_checkpoint: Optional[Callable[[Checkpoint], Awaitable[str]]] = None,
    ):
        self.session = session_memory
        self.on_checkpoint = on_checkpoint
    
    async def pause(
        self,
        checkpoint: Checkpoint,
        session_id: str,
    ) -> str:
        """Pause execution at checkpoint, wait for user response.
        
        Args:
            checkpoint: The checkpoint to present to user
            session_id: Session for persistence
            
        Returns:
            User's response (resume signal)
        """
        # Store checkpoint in session for resumability
        session = self.session.load(session_id)
        if session:
            session.metadata["pending_checkpoint"] = asdict(checkpoint)
            self.session.save(session)
        
        # Call handler to present checkpoint and get response
        if self.on_checkpoint:
            response = await self.on_checkpoint(checkpoint)
        else:
            # Default: return "approved" for testing
            response = "approved"
        
        # Clear pending checkpoint
        if session:
            session.metadata.pop("pending_checkpoint", None)
            self.session.save(session)
        
        return response
    
    def resume_pending(self, session_id: str) -> Optional[Checkpoint]:
        """Get pending checkpoint from session for resumption.
        
        Args:
            session_id: Session to check
            
        Returns:
            Pending checkpoint or None
        """
        session = self.session.load(session_id)
        if not session:
            return None
        
        pending = session.metadata.get("pending_checkpoint")
        if pending:
            return Checkpoint(**pending)
        return None
```

**Source:** Checkpoint reference + existing FileSessionMemory pattern

### Spec-Driven Workflow Verification

```python
# src/gsd_rlm/workflow/verification.py
from dataclasses import dataclass
from typing import List, Dict, Any
from pathlib import Path


@dataclass
class MustHaves:
    """Phase completion requirements from PLAN.md."""
    truths: List[str]      # Things that must be TRUE
    artifacts: List[str]   # Files that must exist
    key_links: Dict[str, str]  # Links that must be valid


def verify_phase_completion(
    phase_dir: Path,
    must_haves: MustHaves,
) -> Dict[str, Any]:
    """Verify phase goals are met before marking complete.
    
    Implements goal-backward verification (EXEC-11, EXEC-12).
    
    Args:
        phase_dir: Phase directory
        must_haves: Requirements from PLAN.md must_haves section
        
    Returns:
        Verification results with pass/fail status
    """
    results = {
        "truths": {"passed": 0, "failed": 0, "details": []},
        "artifacts": {"passed": 0, "failed": 0, "details": []},
        "key_links": {"passed": 0, "failed": 0, "details": []},
        "overall_passed": True,
    }
    
    # Check artifacts (files must exist)
    for artifact in must_haves.artifacts:
        path = phase_dir / artifact
        if path.exists():
            results["artifacts"]["passed"] += 1
            results["artifacts"]["details"].append(f"✓ {artifact}")
        else:
            results["artifacts"]["failed"] += 1
            results["artifacts"]["details"].append(f"✗ {artifact} (not found)")
            results["overall_passed"] = False
    
    # Check key_links (links must be valid)
    for name, link in must_haves.key_links.items():
        # For file links, check existence
        if link.startswith("./") or link.startswith("../"):
            path = phase_dir / link
            if path.exists():
                results["key_links"]["passed"] += 1
                results["key_links"]["details"].append(f"✓ {name}: {link}")
            else:
                results["key_links"]["failed"] += 1
                results["key_links"]["details"].append(f"✗ {name}: {link} (not found)")
                results["overall_passed"] = False
        else:
            # For external links, mark as requiring manual verification
            results["key_links"]["details"].append(f"? {name}: {link} (manual check)")
    
    # Truths require manual verification or automated tests
    for truth in must_haves.truths:
        results["truths"]["details"].append(f"? {truth} (requires verification)")
    
    return results
```

**Source:** GSD VERIFICATION.md template + goal-backward verification pattern

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| Manual checkpoint handling | Structured checkpoint types (human-verify/decision/action) | GSD checkpoint.md | Consistent UX, better automation |
| Hardcoded command routing | Init command pattern with JSON context | gsd-tools.cjs | Extensible, testable |
| In-memory skill registry | File-based SKILL.md discovery | GSD skill pattern | Hot-reload, user-extensible |
| Global checkpoint state | Session-persisted checkpoints | This phase | Resumable workflows |

**Deprecated/outdated:**
- `input()` for checkpoints: Use async event-based approach
- Hardcoded provider lists: Use rlm-toolkit's 75+ providers
- Custom git wrappers: Use gsd-tools.cjs commit command

## Open Questions

1. **How should checkpoint responses be collected in OpenCode?**
   - What we know: OpenCode has a question tool for user interaction
   - What's unclear: How to integrate async checkpoint waiting with OpenCode's event loop
   - Recommendation: Use OpenCode's question tool as the checkpoint handler, pass response through async queue

2. **Should skills support inheritance/composition?**
   - What we know: GSD skills are standalone, but GSD-RLM has specialized agents
   - What's unclear: Whether skill composition (skill A uses skill B) is needed
   - Recommendation: Start with flat skills, add composition if needed in Phase 6

3. **How to handle checkpoint timeouts?**
   - What we know: Checkpoints can block indefinitely
   - What's unclear: Whether to auto-approve after timeout, or fail
   - Recommendation: Configurable timeout with "pending" state for later resumption

## Sources

### Primary (HIGH confidence)
- GSD skill patterns: `~/.config/opencode/skills/gsd-oc-select-model/SKILL.md` - SKILL.md format, workflow structure
- GSD checkpoint reference: `~/.config/opencode/get-shit-done/references/checkpoints.md` - Checkpoint types, execution protocol
- GSD workflows: `~/.config/opencode/get-shit-done/workflows/execute-phase.md`, `plan-phase.md` - Command patterns, init flow
- Existing codebase: `src/gsd_rlm/coordination/orchestrator.py` - HybridOrchestrator pattern
- Existing codebase: `src/gsd_rlm/agents/definition.py` - Pydantic validation pattern
- Existing codebase: `src/gsd_rlm/session/memory.py` - FileSessionMemory pattern

### Secondary (MEDIUM confidence)
- GSD tools: `~/.config/opencode/get-shit-done/bin/gsd-tools.cjs` - Commit patterns, init command structure
- GSD templates: `~/.config/opencode/get-shit-done/templates/summary.md` - Frontmatter format, traceability

### Tertiary (LOW confidence)
- None - All patterns verified against existing GSD and codebase

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - All dependencies already in use
- Architecture: HIGH - GSD patterns are well-documented and analyzed
- Pitfalls: HIGH - Based on common async/integration patterns

**Research date:** 2026-02-27
**Valid until:** 30 days - Stable patterns, low risk of obsolescence
