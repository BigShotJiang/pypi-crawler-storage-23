---
phase: 06
plan: 03
subsystem: optimization
tags: [r-zero, self-refinement, challenger-solver, alphazero, dspy]
requires: [06-01, 06-02]
provides: [RZeroLoop, ChallengerFeedback, RefinementResult, RefinementStatus]
affects: [optimization]
tech-stack:
  added:
    - dataclasses for feedback and result tracking
    - async/await for solver and challenger calls
    - Protocol for reward function interface
    - Optional DSPy integration with ChallengerSignature
  patterns:
    - AlphaZero-inspired challenger-solver pattern
    - Iterative refinement with feedback incorporation
    - Best solution tracking across rounds
    - Graceful degradation without DSPy
key-files:
  created:
    - src/gsd_rlm/optimization/rzero.py
    - tests/test_optimization/test_rzero.py
  modified:
    - src/gsd_rlm/optimization/__init__.py
decisions:
  - Use string hints between rounds (not ChallengerFeedback objects) for solver calls
  - Track best solution across all rounds, not just final
  - Return error result with best solution if error occurs mid-loop
  - Use inspect.iscoroutinefunction for Python 3.16+ compatibility
metrics:
  duration: 8 min
  tests_added: 39
  tests_passed: 37
  tests_skipped: 2
  files_created: 2
  files_modified: 1
  lines_added: 1299
---

# Phase 6 Plan 3: R-Zero Challenger-Solver Self-Refinement Summary

## One-Liner

AlphaZero-inspired challenger-solver loop enabling agents to self-refine outputs through iterative critique and improvement.

## Implementation

### ChallengerFeedback Dataclass

Captures critique from challenger to solver:

```python
@dataclass
class ChallengerFeedback:
    critique: str
    alternative_approach: str
    suggested_improvements: List[str] = field(default_factory=list)
    confidence: float = 0.5  # Clamped to [0.0, 1.0]
    timestamp: str = field(default_factory=_utc_now_iso)
```

### RefinementStatus Enum

Four possible states for refinement loop:

- `IN_PROGRESS` - Loop still running
- `THRESHOLD_MET` - Quality threshold reached, early exit
- `MAX_ROUNDS_REACHED` - All rounds completed
- `ERROR` - Exception occurred

### RefinementResult Dataclass

Tracks the full refinement trajectory:

```python
@dataclass
class RefinementResult:
    final_solution: Any
    final_reward: float
    status: RefinementStatus
    rounds_completed: int
    improvement_history: List[float]  # Reward per round
    feedback_history: List[ChallengerFeedback]  # All feedback received
    error_message: Optional[str] = None

    @property
    def improved(self) -> bool:
        """True if final reward > initial reward"""
```

### RZeroLoop Class

The main refinement orchestrator:

```python
class RZeroLoop:
    DEFAULT_MAX_ROUNDS = 3
    DEFAULT_THRESHOLD = 0.9

    def __init__(
        self,
        solver: Any,  # Callable or dspy.Module
        challenger: Optional[Any] = None,
        reward_fn: Optional[RewardFunction] = None,
        max_rounds: int = DEFAULT_MAX_ROUNDS,
        threshold: float = DEFAULT_THRESHOLD,
    ): ...

    async def execute(
        self,
        task: str,
        context: str = "",
        initial_hint: Optional[str] = None,
    ) -> RefinementResult: ...
```

### Execution Flow

1. **Round 0**: Solver produces solution, reward evaluated
2. If reward >= threshold → return immediately (THRESHOLD_MET)
3. If challenger available → get critique and suggestions
4. Format feedback as hint string for next round
5. **Round N**: Solver uses hint to improve solution
6. Track best solution across all rounds
7. Return when threshold met or max rounds reached

### DSPy Integration

Optional `ChallengerSignature` for DSPy-based challengers:

```python
if HAS_DSPY:
    class ChallengerSignature(dspy.Signature):
        solution: str = dspy.InputField()
        context: str = dspy.InputField()
        reward: float = dspy.InputField()
        round_num: int = dspy.InputField()

        critique: str = dspy.OutputField()
        alternative_approach: str = dspy.OutputField()
        improvements: List[str] = dspy.OutputField()
```

## Test Coverage

### Test Classes

| Class | Tests | Description |
|-------|-------|-------------|
| TestChallengerFeedback | 8 | Creation, serialization, defaults, clamping |
| TestRefinementStatus | 2 | Enum values and count |
| TestRefinementResult | 7 | Creation, improved property, serialization |
| TestRZeroLoop | 11 | Core loop behavior, async support |
| TestRZeroLoopEdgeCases | 7 | Error handling, None predictions |
| TestRZeroLoopDSPyIntegration | 3 | Optional DSPy features |
| TestUtilityFunctions | 1 | UTC timestamp helper |

### Key Test Cases

- **Threshold met**: Loop stops immediately when reward >= threshold
- **Max rounds**: Loop completes all rounds when threshold not met
- **Improvement tracking**: History shows reward trajectory
- **Async support**: Both sync and async solvers/challengers work
- **Error handling**: Errors return best solution found with error status
- **Best result tracking**: Returns highest-reward solution even if not threshold

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] Fixed type mismatch in hint passing**
- **Found during:** Test execution (test_stops_on_max_rounds failed)
- **Issue:** `current_hint` variable was used for both string hints and ChallengerFeedback objects, causing `'str' object has no attribute 'critique'` error
- **Fix:** Separated concerns - `current_hint` always string, `current_feedback` stores ChallengerFeedback
- **Files modified:** src/gsd_rlm/optimization/rzero.py
- **Commit:** 5dfb10f

**2. [Rule 1 - Bug] Fixed deprecation warning**
- **Found during:** Test execution
- **Issue:** `asyncio.iscoroutinefunction` deprecated in Python 3.16
- **Fix:** Replaced with `inspect.iscoroutinefunction`
- **Files modified:** src/gsd_rlm/optimization/rzero.py
- **Commit:** 5dfb10f

## Integration Points

- **ExecutionTrace (06-01)**: R-Zero loops can be traced for optimization
- **AgentOptimizer (06-02)**: Can use R-Zero for prompt refinement
- **Memory Systems**: Feedback history can be stored for learning

## Verification Commands

```bash
# Run R-Zero tests
pytest tests/test_optimization/test_rzero.py -v

# Verify imports
python -c "from gsd_rlm.optimization import RZeroLoop, ChallengerFeedback; print('OK')"

# Run all optimization tests
pytest tests/test_optimization/ -v
```

## Commits

| Commit | Message |
|--------|---------|
| 5dfb10f | feat(06-03): add R-Zero challenger-solver self-refinement loop |
| da1a996 | test(06-03): add comprehensive test suite for R-Zero refinement |
| 4900b9e | feat(06-03): export R-Zero classes from optimization module |
