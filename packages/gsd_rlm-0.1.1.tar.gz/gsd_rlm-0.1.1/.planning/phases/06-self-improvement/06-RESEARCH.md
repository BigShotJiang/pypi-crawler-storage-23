# Phase 6: Self-Improvement + Optimization - Research

**Researched:** 2026-02-28
**Domain:** DSPy prompt optimization, R-Zero self-refinement, execution trace collection
**Confidence:** HIGH

## Summary

Phase 6 implements the self-improvement capabilities that allow agents to optimize their performance over time. This involves three core mechanisms: (1) collecting execution traces as training data, (2) using DSPy MIPROv2 to optimize prompts with few-shot examples and instruction refinement, and (3) implementing R-Zero challenger-solver loops for iterative self-refinement on complex tasks.

The DSPy framework provides a mature optimization pipeline via MIPROv2 that bootstraps few-shot examples, proposes new instructions, and uses Bayesian Optimization to find optimal combinations. For self-refinement, DSPy's Refine module offers a feedback loop pattern that can be extended into the R-Zero challenger-solver architecture.

**Primary recommendation:** Implement optimization as a layered system: TraceCollector → TrainingDataset → MIPROv2Optimizer → OptimizedAgent, with R-Zero refinement as an optional post-processing step for complex tasks.

<phase_requirements>

## Phase Requirements

| ID | Description | Research Support |
|----|-------------|-----------------|
| SEC-05 | Agents improve prompts via DSPy MIPROv2 optimization | DSPy MIPROv2 teleprompter with auto modes (light/medium/heavy), Bayesian Optimization, instruction + few-shot optimization |
| SEC-06 | System collects execution traces for optimization training data | Adapt existing H-MEM Episode/Trace system to DSPy Example format; MLflow autologging pattern for trace collection |
| SEC-07 | Agents self-refine through R-Zero challenger-solver loops | DSPy Refine module with reward_fn + threshold pattern; extend with challenger role for AlphaZero-style improvement |
| SEC-08 | Optimization runs periodically or on-demand | Follow ConsolidationJob pattern (threshold + interval triggers); manual trigger via command interface |

</phase_requirements>

## Standard Stack

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| dspy | 2.6+ | Prompt optimization framework | Declarative LM programming with MIPROv2 optimizer |
| dspy.MIPROv2 | 2.6+ | Multi-prompt instruction optimizer | Bayesian Optimization for prompt + few-shot joint optimization |
| dspy.Refine | 2.6+ | Self-refinement module | N-rollout with reward function and feedback generation |
| dspy.Evaluate | 2.6+ | Metric evaluation | Parallel evaluation with configurable threads |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| dspy.BootstrapFewShot | 2.6+ | Few-shot example bootstrapping | When only few-shot optimization needed |
| dspy.ChainOfThought | 2.6+ | Reasoning chain module | For complex reasoning tasks |
| mlflow | 2.0+ | Trace logging and experiment tracking | When observability needed |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| MIPROv2 | BootstrapFewShot | Simpler but no instruction optimization |
| MIPROv2 | COPRO | Older optimizer, less sophisticated |
| DSPy Refine | Custom retry loop | More work, no automatic feedback generation |
| MIPROv2 auto mode | Manual num_trials | More control but requires tuning expertise |

**Installation:**
```bash
pip install dspy-ai>=2.6.0 mlflow>=2.0.0
```

## Architecture Patterns

### Recommended Project Structure
```
src/gsd_rlm/optimization/
├── __init__.py           # Public exports
├── traces.py             # ExecutionTrace dataclass + TraceCollector
├── dataset.py            # OptimizationDataset, dspy.Example conversion
├── optimizer.py          # MIPROv2Optimizer wrapper
├── rzero.py              # ChallengerSolverLoop, RewardFunction
├── scheduler.py          # OptimizationScheduler (threshold + interval)
└── metrics.py            # TaskSuccessMetric, QualityMetric
```

### Pattern 1: DSPy MIPROv2 Optimization Flow
**What:** Three-stage optimization: bootstrap demos → propose instructions → Bayesian search
**When to use:** When agents need improved prompts with few-shot examples
**Example:**
```python
# Source: https://dspy.ai/api/optimizers/MIPROv2
import dspy
from dspy.teleprompt import MIPROv2

# Initialize optimizer with metric
teleprompter = MIPROv2(
    metric=task_success_metric,  # Custom metric function
    auto="medium",  # light/medium/heavy for different optimization depths
    prompt_model=dspy.LM('openai/gpt-4o-mini'),  # For instruction proposal
)

# Compile optimized program from training data
optimized_program = teleprompter.compile(
    student=agent_module,
    trainset=training_examples,  # List[dspy.Example]
)

# Save for reuse
optimized_program.save("optimized_agent.json")
```

### Pattern 2: DSPy Refine Self-Refinement
**What:** Run module N times with feedback loop, return best prediction
**When to use:** For complex tasks where single attempt may fail
**Example:**
```python
# Source: https://dspy.ai/api/modules/Refine
import dspy

def quality_reward(args, pred):
    """Reward function evaluating prediction quality."""
    if pred is None:
        return 0.0
    # Check for completeness, correctness, etc.
    return 1.0 if is_valid(pred) else 0.5

refined_module = dspy.Refine(
    module=agent_module,
    N=3,  # Max attempts
    reward_fn=quality_reward,
    threshold=1.0,  # Stop if reward >= threshold
)

result = refined_module(question="Complex task...")
```

### Pattern 3: R-Zero Challenger-Solver Loop
**What:** Extend Refine with dedicated challenger role for AlphaZero-style improvement
**When to use:** For tasks requiring creative problem-solving or exploring alternatives
**Example:**
```python
# Custom pattern inspired by AlphaZero + DSPy Refine
from dataclasses import dataclass
from typing import List, Optional
import dspy

@dataclass
class ChallengerFeedback:
    alternative_approach: str
    critique: str
    suggested_improvements: List[str]

class RZeroLoop:
    """Challenger-solver loop for self-refinement."""
    
    def __init__(
        self,
        solver: dspy.Module,
        challenger: dspy.Module,
        reward_fn: Callable,
        max_rounds: int = 3,
        threshold: float = 0.9,
    ):
        self.solver = solver
        self.challenger = challenger
        self.reward_fn = reward_fn
        self.max_rounds = max_rounds
        self.threshold = threshold
    
    async def execute(self, **kwargs) -> tuple:
        """Run challenger-solver loop until threshold met."""
        best_result = None
        best_reward = -float('inf')
        feedback = None
        
        for round_num in range(self.max_rounds):
            # Solver attempts with optional feedback
            if feedback:
                kwargs['hint_'] = feedback.suggested_improvements
            result = self.solver(**kwargs)
            reward = self.reward_fn(kwargs, result)
            
            if reward > best_reward:
                best_reward = reward
                best_result = result
            
            if reward >= self.threshold:
                break
            
            # Challenger critiques and proposes alternatives
            feedback = self.challenger(
                solution=result,
                reward=reward,
                round=round_num,
            )
        
        return best_result, best_reward
```

### Pattern 4: Execution Trace Collection
**What:** Collect agent execution traces in DSPy Example format
**When to use:** Building training dataset for optimization
**Example:**
```python
# Adapt H-MEM Episode to DSPy Example
import dspy
from dataclasses import dataclass
from typing import List, Dict, Any

@dataclass
class ExecutionTrace:
    """Trace of agent execution for optimization training."""
    trace_id: str
    agent_id: str
    task_input: Dict[str, Any]  # Input to agent
    task_output: Dict[str, Any]  # Agent output
    success: bool
    context: str  # Context used
    reward: float  # Quality score
    
    def to_dspy_example(self) -> dspy.Example:
        """Convert to DSPy Example for optimization."""
        return dspy.Example(
            question=self.task_input.get('question', ''),
            context=self.context,
            answer=self.task_output.get('answer', ''),
            success=self.success,
        ).with_inputs('question', 'context')

class TraceCollector:
    """Collect and store execution traces."""
    
    def __init__(self, store_path: str):
        self.store_path = store_path
        self.traces: List[ExecutionTrace] = []
    
    def record(
        self,
        agent_id: str,
        task_input: Dict[str, Any],
        task_output: Dict[str, Any],
        success: bool,
        context: str = "",
        reward: float = 0.0,
    ) -> ExecutionTrace:
        """Record an execution trace."""
        trace = ExecutionTrace(
            trace_id=f"trace_{uuid.uuid4().hex[:12]}",
            agent_id=agent_id,
            task_input=task_input,
            task_output=task_output,
            success=success,
            context=context,
            reward=reward,
        )
        self.traces.append(trace)
        self._persist(trace)
        return trace
    
    def get_training_dataset(self) -> List[dspy.Example]:
        """Get all traces as DSPy training dataset."""
        return [t.to_dspy_example() for t in self.traces if t.success]
```

### Pattern 5: Optimization Scheduling
**What:** Schedule periodic or threshold-based optimization runs
**When to use:** Continuous improvement without manual intervention
**Example:**
```python
# Follow ConsolidationJob pattern from gsd_rlm.memory.hmem.consolidation
import asyncio
from datetime import datetime, timezone
from typing import Optional

class OptimizationScheduler:
    """Schedule automatic optimization runs."""
    
    DEFAULT_TRACE_THRESHOLD = 50  # Min traces before optimization
    DEFAULT_INTERVAL_SECONDS = 3600  # 1 hour
    
    def __init__(
        self,
        trace_collector: TraceCollector,
        optimizer: 'MIPROv2Optimizer',
        interval_seconds: int = DEFAULT_INTERVAL_SECONDS,
        trace_threshold: int = DEFAULT_TRACE_THRESHOLD,
    ):
        self.trace_collector = trace_collector
        self.optimizer = optimizer
        self.interval_seconds = interval_seconds
        self.trace_threshold = trace_threshold
        self._running = False
        self._task: Optional[asyncio.Task] = None
    
    async def start(self) -> None:
        """Start background optimization loop."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._optimization_loop())
    
    async def stop(self) -> None:
        """Stop the optimization loop."""
        self._running = False
        if self._task:
            self._task.cancel()
    
    async def run_once(self) -> Optional[dict]:
        """Run optimization once if threshold met."""
        if self._should_optimize():
            return await self._do_optimization()
        return None
    
    def _should_optimize(self) -> bool:
        """Check if optimization should run."""
        unoptimized = len(self.trace_collector.traces)
        return unoptimized >= self.trace_threshold
    
    async def _optimization_loop(self) -> None:
        """Background optimization loop."""
        while self._running:
            try:
                if self._should_optimize():
                    await self._do_optimization()
                await asyncio.sleep(self.interval_seconds)
            except asyncio.CancelledError:
                break
            except Exception:
                await asyncio.sleep(self.interval_seconds)
    
    async def _do_optimization(self) -> dict:
        """Perform optimization run."""
        trainset = self.trace_collector.get_training_dataset()
        result = await self.optimizer.optimize(trainset)
        return result
```

### Anti-Patterns to Avoid

- **Optimizing on all traces:** Only use successful traces for training; failed traces add noise
- **Ignoring validation set:** Always hold out validation data to prevent overfitting
- **Heavy optimization by default:** Start with `auto="light"`, increase only if needed
- **Optimizing too frequently:** Let traces accumulate; optimization has LLM costs
- **Single metric obsession:** Use composite metrics (success + quality + latency)

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| Prompt optimization | Custom prompt tuning logic | dspy.MIPROv2 | Bayesian optimization, instruction proposal, few-shot bootstrapping |
| Self-refinement | Manual retry loops | dspy.Refine | Automatic feedback generation, reward-based selection |
| Trace logging | Custom logging system | mlflow.dspy.autolog() | Standard observability, experiment tracking |
| Metric evaluation | Custom scoring loops | dspy.Evaluate | Parallel execution, progress display, error handling |
| Training data format | Custom example format | dspy.Example | Standard format required by optimizers |

**Key insight:** DSPy provides a complete optimization pipeline. The integration work is primarily about adapting existing H-MEM traces to DSPy Example format and implementing the R-Zero challenger pattern on top of DSPy primitives.

## Common Pitfalls

### Pitfall 1: Insufficient Training Data
**What goes wrong:** MIPROv2 fails or produces poor results with < 10-20 examples
**Why it happens:** Bayesian optimization needs diverse examples to explore prompt space
**How to avoid:** 
- Set `trace_threshold >= 50` before running optimization
- Use `auto="light"` for smaller datasets
- Bootstrap synthetic examples if needed
**Warning signs:** Optimization completes quickly with no improvement; few-shot demos are repetitive

### Pitfall 2: Overfitting to Validation Set
**What goes wrong:** Optimized prompts work on validation but fail in production
**Why it happens:** Too many optimization trials without held-out test set
**How to avoid:**
- Split traces into train/val/test (60/20/20)
- Use `minibatch=True` with `minibatch_full_eval_steps`
- Monitor for score divergence between val and test
**Warning signs:** Val score increases while test score decreases

### Pitfall 3: Reward Function Mismatch
**What goes wrong:** Optimized prompts score well but don't solve actual problems
**Why it happens:** Reward function doesn't capture true success criteria
**How to avoid:**
- Define reward function with domain expert input
- Use composite metrics (success AND quality)
- Test reward function on known good/bad examples
**Warning signs:** High scores but user complaints; optimization converges to trivial solutions

### Pitfall 4: Challenger Becoming Bottleneck
**What goes wrong:** R-Zero loop adds significant latency without quality improvement
**Why it happens:** Challenger called on every round, even for simple tasks
**How to avoid:**
- Only invoke challenger for tasks below threshold
- Cache challenger feedback for similar tasks
- Use lightweight challenger model (gpt-4o-mini)
**Warning signs:** Task latency > 30s; challenger cost > solver cost

### Pitfall 5: Optimization State Loss
**What goes wrong:** Optimized prompts lost on restart, have to re-optimize
**Why it happens:** Not persisting optimized programs
**How to avoid:**
- Always call `optimized_program.save()` after optimization
- Store in version-controlled location
- Track optimization metadata (timestamp, score, trace count)
**Warning signs:** Agent performance varies between restarts

## Code Examples

### Complete Optimization Integration

```python
# Source: Adapted from DSPy docs + existing GSD-RLM patterns
import dspy
from pathlib import Path
from typing import List, Optional, Callable
from dataclasses import dataclass
import asyncio

# 1. Define task success metric
def task_success_metric(example: dspy.Example, pred: dspy.Prediction, trace=None) -> float:
    """Metric for evaluating agent task success."""
    # During bootstrapping (trace is not None), require perfect score
    if trace is not None:
        return 1.0 if pred.success else 0.0
    # During evaluation, return partial score
    return 1.0 if pred.success else 0.0

# 2. Convert H-MEM traces to DSPy Examples
def episode_to_dspy_example(episode) -> Optional[dspy.Example]:
    """Convert H-MEM Episode to DSPy Example."""
    if not episode.success:
        return None  # Skip failed episodes
    
    return dspy.Example(
        question=episode.context,
        context=episode.action,
        answer=episode.outcome,
    ).with_inputs('question', 'context')

# 3. Optimizer wrapper
class AgentOptimizer:
    """Wrap DSPy MIPROv2 for agent optimization."""
    
    def __init__(
        self,
        agent_module: dspy.Module,
        metric: Callable = task_success_metric,
        auto: str = "light",
        prompt_model: Optional[dspy.LM] = None,
    ):
        self.agent_module = agent_module
        self.metric = metric
        self.auto = auto
        self.prompt_model = prompt_model or dspy.settings.lm
    
    def optimize(
        self,
        trainset: List[dspy.Example],
        valset: Optional[List[dspy.Example]] = None,
    ) -> dspy.Module:
        """Run MIPROv2 optimization."""
        optimizer = dspy.MIPROv2(
            metric=self.metric,
            auto=self.auto,
            prompt_model=self.prompt_model,
        )
        
        optimized = optimizer.compile(
            self.agent_module.deepcopy(),
            trainset=trainset,
            valset=valset,
        )
        
        return optimized
    
    def save(self, program: dspy.Module, path: Path) -> None:
        """Save optimized program."""
        program.save(str(path), save_program=False)
    
    def load(self, path: Path) -> dspy.Module:
        """Load optimized program."""
        loaded = self.agent_module.deepcopy()
        loaded.load(str(path))
        return loaded

# 4. R-Zero challenger signature
class ChallengerSignature(dspy.Signature):
    """Critique a solution and propose improvements."""
    solution: str = dspy.InputField(desc="Current solution to critique")
    reward: float = dspy.InputField(desc="Current reward score")
    critique: str = dspy.OutputField(desc="Analysis of solution weaknesses")
    improvements: list[str] = dspy.OutputField(desc="Suggested improvements")

# 5. Integration with existing SequentialTaskRunner
class OptimizingTaskRunner:
    """TaskRunner with automatic optimization support."""
    
    def __init__(
        self,
        base_runner,  # SequentialTaskRunner
        trace_collector: TraceCollector,
        optimizer: AgentOptimizer,
        optimize_threshold: int = 50,
    ):
        self.base_runner = base_runner
        self.trace_collector = trace_collector
        self.optimizer = optimizer
        self.optimize_threshold = optimize_threshold
        self._optimized_module = None
    
    async def run_task(self, task: str, session_id: str, agent_id: str):
        """Run task with trace collection."""
        result = await self.base_runner.run_tasks([task], session_id, [agent_id])
        
        # Record trace
        self.trace_collector.record(
            agent_id=agent_id,
            task_input={"task": task},
            task_output={"result": result.content},
            success=result.success,
        )
        
        # Check for optimization opportunity
        if len(self.trace_collector.traces) >= self.optimize_threshold:
            await self._maybe_optimize()
        
        return result
    
    async def _maybe_optimize(self) -> None:
        """Run optimization if threshold met."""
        trainset = self.trace_collector.get_training_dataset()
        if len(trainset) >= self.optimize_threshold:
            self._optimized_module = self.optimizer.optimize(trainset)
```

### DSPy Evaluate Usage

```python
# Source: https://dspy.ai/api/evaluation/Evaluate
import dspy

# Define metric
def custom_metric(example, pred, trace=None):
    """Evaluate prediction quality."""
    # Perfect match during bootstrapping
    if trace is not None:
        return pred.answer == example.answer
    # Partial credit during evaluation
    return 1.0 if pred.success else 0.0

# Create evaluator
evaluate = dspy.Evaluate(
    devset=test_examples,
    metric=custom_metric,
    num_threads=8,
    display_progress=True,
    display_table=5,
)

# Run evaluation
result = evaluate(optimized_program)
print(f"Score: {result.score:.2f}%")
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| Manual prompt engineering | DSPy MIPROv2 optimization | 2024 | Automated prompt improvement, 10-50% performance gains |
| Single-shot execution | N-rollout with Refine | 2024 | Higher success rate on complex tasks |
| Custom trace logging | MLflow autologging | 2024 | Standard observability, experiment tracking |
| Hand-tuned few-shot | BootstrapFewShot | 2024 | Automatic example selection |

**Deprecated/outdated:**
- COPRO optimizer: Replaced by MIPROv2 with better Bayesian optimization
- Manual prompt templates: Use DSPy signatures for declarative definitions

## Open Questions

1. **R-Zero Integration Depth**
   - What we know: DSPy Refine provides feedback loop pattern
   - What's unclear: How deeply to integrate challenger role vs using separate agent
   - Recommendation: Start with lightweight challenger (same model, different prompt), evolve to dedicated challenger agent if needed

2. **Multi-Agent Optimization**
   - What we know: MIPROv2 optimizes single module
   - What's unclear: How to optimize coordinator + agent ensemble jointly
   - Recommendation: Optimize agents individually first, then coordinator; consider BetterTogether optimizer for joint optimization

3. **Trace Quality Filtering**
   - What we know: Only successful traces should be training data
   - What's unclear: What quality threshold to use for inclusion
   - Recommendation: Start with binary success/failure, add reward-based filtering once metrics are validated

## Validation Architecture

> Note: config.json does not have `workflow.nyquist_validation` enabled. This section is provided for reference but test infrastructure is not required for this phase.

### Test Framework
| Property | Value |
|----------|-------|
| Framework | pytest (existing) |
| Config file | pyproject.toml |
| Quick run command | `pytest tests/test_optimization/ -x -v` |
| Full suite command | `pytest tests/ -v` |
| Estimated runtime | ~30 seconds for optimization tests |

### Phase Requirements → Test Map
| Req ID | Behavior | Test Type | Automated Command | File Exists? |
|--------|----------|-----------|-------------------|-------------|
| SEC-05 | MIPROv2 optimization runs successfully | unit | `pytest tests/test_optimization/test_optimizer.py -x` | ❌ Wave 0 gap |
| SEC-06 | Traces collected in DSPy format | unit | `pytest tests/test_optimization/test_traces.py -x` | ❌ Wave 0 gap |
| SEC-07 | R-Zero loop improves solutions | integration | `pytest tests/test_optimization/test_rzero.py -x` | ❌ Wave 0 gap |
| SEC-08 | Scheduler triggers optimization | unit | `pytest tests/test_optimization/test_scheduler.py -x` | ❌ Wave 0 gap |

### Wave 0 Gaps (must be created before implementation)
- [ ] `tests/test_optimization/__init__.py` — test package init
- [ ] `tests/test_optimization/test_traces.py` — covers SEC-06
- [ ] `tests/test_optimization/test_optimizer.py` — covers SEC-05
- [ ] `tests/test_optimization/test_rzero.py` — covers SEC-07
- [ ] `tests/test_optimization/test_scheduler.py` — covers SEC-08
- [ ] `tests/test_optimization/conftest.py` — shared fixtures (mock DSPy, sample traces)

## Sources

### Primary (HIGH confidence)
- /websites/dspy_ai - MIPROv2 optimizer API, Refine module, Evaluate class
- /llmstxt/dspy_ai_llms_txt - Trace collection, MLflow autologging patterns
- https://dspy.ai/api/optimizers/MIPROv2 - MIPROv2 parameter reference
- https://dspy.ai/tutorials/saving - Program save/load patterns

### Secondary (MEDIUM confidence)
- Existing codebase patterns: ConsolidationJob, SequentialTaskRunner, H-MEM Episode/Trace
- Project decisions from STATE.md: Tenacity retry, AnyIO async, Pydantic validation

### Tertiary (LOW confidence)
- R-Zero concept: Custom extension inspired by AlphaZero; not a standard DSPy pattern
- Multi-agent optimization: BetterTogether optimizer mentioned but not deeply researched

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - DSPy is mature framework with extensive documentation
- Architecture: HIGH - Patterns derived from existing codebase + DSPy best practices
- Pitfalls: HIGH - Common optimization issues well-documented in DSPy community
- R-Zero: MEDIUM - Custom pattern, needs validation during implementation

**Research date:** 2026-02-28
**Valid until:** 30 days - DSPy 2.6+ is stable but 3.0 may introduce changes
