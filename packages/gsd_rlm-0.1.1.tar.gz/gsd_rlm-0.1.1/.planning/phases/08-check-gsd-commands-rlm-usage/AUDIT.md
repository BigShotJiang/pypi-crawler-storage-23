# GSD Commands RLM Usage Audit

**Audit Date:** 2026-03-01
**Auditor:** GSD Executor Agent
**Purpose:** Classify all GSD commands by RLM (Reinforcement Learning for Multi-agent) integration level

---

## Executive Summary

This audit confirms that **GSD-RLM uses RLM integration correctly**:

- **Python CLI commands** are appropriately NO_RLM (administrative file operations)
- **Bundled OpenCode commands** use INDIRECT_RLM when LLM intelligence is needed (via agent spawning)
- **Utility commands** correctly remain NO_RLM (file/status operations)

**No changes needed.** The architecture follows the correct pattern: administrative commands don't need LLM, workflow commands spawn agents that use LLM via OpenCode.

---

## RLM Integration Levels

Commands are classified into four levels:

| Level | Description | LLM Usage |
|-------|-------------|-----------|
| **NO_RLM** | Administrative - file ops, status, config | None needed |
| **PARTIAL_RLM** | Uses infrastructure (SkillRegistry, config) but no LLM calls | None |
| **INDIRECT_RLM** | Spawns agents via task tool (OpenCode handles LLM) | Via OpenCode |
| **DIRECT_RLM** | Uses rlm_toolkit providers directly | Direct |

---

## Python CLI Commands

| Command | File | RLM Level | Justification |
|---------|------|-----------|---------------|
| `gsd-rlm init` | cli/init.py | NO_RLM | File operations only - creates .planning/ structure |
| `gsd-rlm status` | cli/status.py | NO_RLM | File reading only - displays STATE.md content |
| `gsd-rlm version` | cli/version.py | NO_RLM | Static output - prints version string |
| `gsd-rlm setup` | cli/setup.py | NO_RLM | Dependency checks and subprocess - no LLM needed |
| `gsd-rlm install-commands` | cli/install.py | NO_RLM | File copy operations - copies bundled resources |

**Analysis:** All 5 Python CLI commands are correctly classified as NO_RLM. These are administrative commands that perform file system operations, dependency checks, and installation. No LLM intelligence is required for these operations.

---

## Bundled OpenCode Commands

### INDIRECT_RLM (Agent Spawning Commands)

These commands spawn subagents via the `task` tool. OpenCode handles LLM invocation.

| Command | Agent Spawning | Notes |
|---------|----------------|-------|
| gsd-execute-phase | Yes (task tool) | Spawns gsd-executor agents for plan execution |
| gsd-plan-phase | Yes (task tool) | Spawns gsd-planner agent, uses agent: gsd-planner |
| gsd-research-phase | Yes (task tool) | Spawns gsd-phase-researcher agent |
| gsd-discuss-phase | Yes (task tool) | Spawns agents for context gathering |
| gsd-verify-work | Yes (task tool) | Spawns agents for UAT verification |
| gsd-debug | Yes (task tool) | Spawns gsd-debugger agent |
| gsd-audit-milestone | Yes (task tool) | Spawns integration checker agents |
| gsd-map-codebase | Yes (task tool) | Spawns 4 parallel gsd-codebase-mapper agents |
| gsd-quick | Yes (task tool) | Spawns gsd-planner and gsd-executor agents |
| gsd-new-project | Yes (task tool) | Spawns agents for project initialization |
| gsd-new-milestone | Yes (task tool) | Spawns agents for milestone setup |

**Total INDIRECT_RLM: 11 commands**

### NO_RLM (Administrative Commands)

These commands do NOT spawn agents. They perform file operations, configuration, or display information.

| Command | Purpose | Notes |
|---------|---------|-------|
| gsd-progress | File reading + routing | No task tool - reads STATE.md and routes |
| gsd-help | Static output | Displays command reference |
| gsd-health | File validation | Checks .planning/ directory integrity |
| gsd-settings | Config modification | Updates config.json via prompts |
| gsd-cleanup | File archiving | Archives completed phase directories |
| gsd-add-phase | Roadmap modification | Adds phase to roadmap |
| gsd-insert-phase | Roadmap modification | Inserts decimal phase |
| gsd-remove-phase | Roadmap modification | Removes phase and renumbers |
| gsd-add-todo | Todo creation | Creates todo file |
| gsd-check-todos | Todo listing | Lists and manages todos |
| gsd-complete-milestone | Milestone archiving | Archives milestone files |
| gsd-update | Package update | npm update operations |
| gsd-set-profile | Config modification | Updates model profile |
| gsd-resume-work | Context restoration | Restores session context |
| gsd-pause-work | Context preservation | Creates handoff file |
| gsd-join-discord | Static output | Displays Discord link |
| gsd-reapply-patches | File merging | Merges local modifications |
| gsd-plan-milestone-gaps | Gap planning | Creates fix phases |
| gsd-list-phase-assumptions | Analysis output | Lists assumptions (conversational) |
| gsd-rlm-memory | Status display | Shows memory system status |
| gsd-rlm-optimize | Optimization trigger | Runs optimization scheduler |

**Total NO_RLM: 21 commands**

---

## Architecture: OpenCode vs RLM-Toolkit

### Responsibility Division

| Layer | Responsibility | Example |
|-------|----------------|---------|
| OpenCode | LLM invocation, model selection | Spawns agent with prompt |
| RLM-Toolkit | Provider abstraction, tool base | `rlm_toolkit.providers.*` |
| GSD-RLM | Orchestration, configuration | CommandRouter, provider_router |

### How RLM Integration Works

1. GSD command spawns agent via `task` tool
2. OpenCode selects model based on context
3. OpenCode invokes LLM (using rlm_toolkit under hood)
4. Agent receives response, processes, returns

### What This Means for Audit

Commands don't need DIRECT_RLM if they:
- Spawn agents via task tool (INDIRECT_RLM)
- Are administrative (NO_RLM is correct)

Commands need fixing if they:
- Should use LLM but don't spawn agents
- Have PARTIAL_RLM but should be DIRECT or INDIRECT

---

## Recommendations

### Correctly Integrated

- All bundled workflow commands use INDIRECT_RLM via task tool when LLM intelligence is needed
- CLI commands are appropriately NO_RLM (file operations)
- Utility commands correctly remain NO_RLM

### No Changes Needed

This audit confirms GSD-RLM uses RLM integration correctly:
- Provider routing infrastructure exists (provider_router.py)
- Agent definitions have LLM configuration
- Commands spawn agents that use LLMs via OpenCode

---

## Audit Summary

| Category | Count | RLM Level | Status |
|----------|-------|-----------|--------|
| Python CLI | 5 | NO_RLM | ✅ Correct |
| Bundled (INDIRECT_RLM) | 11 | INDIRECT_RLM | ✅ Correct |
| Bundled (NO_RLM) | 21 | NO_RLM | ✅ Correct |
| **Total** | **37** | - | ✅ All correct |

---

## Conclusion

**No issues found.** All 37 GSD commands are correctly classified and use appropriate RLM integration levels:

1. **Administrative commands** (CLI + utility) correctly avoid LLM overhead
2. **Workflow commands** correctly spawn agents that use LLM via OpenCode
3. **No gaps** - commands that need intelligence use INDIRECT_RLM

The architecture properly separates concerns:
- GSD-RLM handles orchestration and configuration
- OpenCode handles agent spawning and LLM invocation
- rlm_toolkit provides provider abstraction

---

*Audit completed: 2026-03-01*
