# Phase 8: Check GSD Commands RLM Usage - Research

**Researched:** 2026-03-01
**Domain:** Codebase audit, RLM integration patterns, multi-agent systems
**Confidence:** HIGH

## Summary

Phase 8 is an **audit phase** to verify that all GSD commands properly use RLM (Reinforcement Learning for Multi-agent) integration. This research identifies what "RLM integration" means in this codebase, catalogs all GSD commands, and classifies them by their current RLM usage level.

**Primary recommendation:** This phase should produce an audit report identifying:
1. Commands that correctly use RLM (providers, routing, agents)
2. Commands that are administrative (don't need RLM)
3. Commands that should use RLM but currently don't

## Standard Stack

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| rlm-toolkit | >=2.3.0 | LLM provider abstraction | Unified interface for 75+ providers via LiteLLM |
| pydantic | >=2.0.0 | Configuration validation | Type-safe agent/provider configuration |
| DSPy | optional | Prompt optimization | MIPROv2 optimizer, R-Zero self-refinement |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| tenacity | >=8.0.0 | Retry logic | LLM call resilience |
| anyio | >=4.0.0 | Async concurrency | Multi-agent parallel execution |

### RLM Integration Points
| Module | Integration Type | Description |
|--------|-----------------|-------------|
| `config/settings.py` | Provider Config | `LLMConfig.get_provider_instance()` creates Ollama, OpenAI, Anthropic providers |
| `commands/provider_router.py` | Task Routing | Routes tasks to providers (planning→claude, execution→ollama) |
| `optimization/optimizer.py` | DSPy MIPROv2 | Prompt optimization with execution traces |
| `optimization/rzero.py` | DSPy Signatures | Challenger-solver self-refinement loops |
| `tools/file_tools.py` | Tool Base | Inherits from `rlm_toolkit.tools.Tool` |
| `tools/shell_tool.py` | Tool Base | Inherits from `rlm_toolkit.tools.Tool` |
| `agents/loader.py` | Agent Creation | Uses `rlm_toolkit.agents.Agent` when available |

## Architecture Patterns

### What "RLM Integration" Means in This Codebase

RLM integration has three levels:

**Level 1 - Configuration (Present):**
- `LLMConfig` with provider settings (Ollama, OpenAI, Anthropic, Google)
- `GSDConfig` with default LLM configuration
- Provider routing by task type

**Level 2 - Tool Integration (Present):**
- File and shell tools inherit from `rlm_toolkit.tools.Tool`
- Tool registry with fallback when rlm_toolkit unavailable

**Level 3 - Agent Execution (Partial):**
- `MultiAgentRuntime` is simplified (can use rlm_toolkit)
- `SequentialTaskRunner` processes through agents
- Optimization uses DSPy when available

### Current Command Architecture

```
GSD-RLM Commands
├── Python CLI (gsd-rlm *)
│   ├── init        → File operations only (NO RLM)
│   ├── status      → File reading only (NO RLM)
│   ├── version     → Print version (NO RLM)
│   ├── setup       → Dependency checks (NO RLM)
│   └── install-commands → File copying (NO RLM)
│
├── Command Handlers (/gsd-rlm-*)
│   ├── new-project → File operations only (NO RLM)
│   ├── plan-phase  → SkillRegistry lookup (PARTIAL)
│   └── execute-phase → HybridOrchestrator (PARTIAL)
│
└── Bundled OpenCode Commands
    └── 14 workflow commands → Invoke OpenCode agents (INDIRECT)
```

### Pattern: Administrative vs Agent Commands

**Administrative commands** (don't need RLM):
- File/directory creation (`init`, `new-project`)
- Status reporting (`status`, `version`)
- Setup/installation (`setup`, `install-commands`)

**Agent commands** (should use RLM):
- Planning (`plan-phase`) - Should invoke planner agent with LLM
- Execution (`execute-phase`) - Should invoke executor agents with LLM
- Research (`research-phase`) - Should invoke researcher agents with LLM

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| LLM calls | Custom HTTP | rlm_toolkit.providers | 75+ providers, retry, streaming |
| Provider selection | Manual routing | provider_router.py | Task-type-based routing |
| Tool definitions | Custom classes | rlm_toolkit.tools.Tool | Standard interface |

## Common Pitfalls

### Pitfall 1: Command Without Provider Config
**What goes wrong:** Command tries to use LLM but has no provider configuration
**Why it happens:** Commands created as file operations later need LLM features
**How to avoid:** Check `GSDConfig.default_llm` is accessible in all agent commands

### Pitfall 2: SkillRegistry Without LLM Invocation
**What goes wrong:** Command looks up skill from registry but never invokes LLM
**Why it happens:** Skill lookup is separate from agent execution
**How to avoid:** After skill lookup, invoke agent with `LLMConfig.get_provider_instance()`

### Pitfall 3: Simplified Runtime Instead of Full RLM
**What goes wrong:** Using `MultiAgentRuntime` simplified version instead of full rlm_toolkit
**Why it happens:** Simplified version works for basic cases
**How to avoid:** Import and use `rlm_toolkit.agents.Agent` when available

## Audit Findings

### GSD Commands by RLM Usage

#### NO RLM (Administrative - Expected)

| Command | Location | Purpose | RLM Needed? |
|---------|----------|---------|-------------|
| `gsd-rlm init` | cli/init.py | Create .planning/ structure | No (file ops) |
| `gsd-rlm status` | cli/status.py | Show project status | No (file read) |
| `gsd-rlm version` | cli/version.py | Print version | No (static) |
| `gsd-rlm setup` | cli/setup.py | Check/install deps | No (subprocess) |
| `gsd-rlm install-commands` | cli/install.py | Copy bundled resources | No (file copy) |
| `/gsd-rlm-new-project` | commands/handlers/new_project.py | Create project files | No (file ops) |

#### PARTIAL RLM (Uses infrastructure but doesn't invoke LLM directly)

| Command | Location | Current State | Gap |
|---------|----------|---------------|-----|
| `/gsd-rlm-plan-phase` | commands/handlers/plan_phase.py | Uses SkillRegistry | Doesn't invoke LLM agent |
| `/gsd-rlm-execute-phase` | commands/handlers/execute_phase.py | Uses HybridOrchestrator | Uses mock executor |

#### INDIRECT RLM (OpenCode workflow commands)

| Command Pattern | Count | RLM Usage |
|-----------------|-------|-----------|
| `/gsd-rlm-*` workflows | 14 | Invoke OpenCode agents (OpenCode handles RLM) |

### Bundled Commands Inventory

**Commands (bundled/commands/gsd-rlm/):**
- gsd-progress.md
- gsd-insert-phase.md
- gsd-help.md
- gsd-health.md
- gsd-execute-phase.md
- gsd-discuss-phase.md
- gsd-debug.md
- gsd-complete-milestone.md
- gsd-cleanup.md
- gsd-check-todos.md
- gsd-audit-milestone.md
- gsd-add-todo.md
- gsd-add-phase.md

**Workflows (bundled/workflows/):** 34 workflow files
**Agents (bundled/agents/):** 11 agent definitions

### RLM Integration Gaps

1. **plan_phase.py:**
   - Current: Generates template PLAN.md content without LLM
   - Gap: Should invoke planner agent with LLM for intelligent planning
   - Line 84-147: `_generate_plan_content()` is pure string formatting

2. **execute_phase.py:**
   - Current: Uses mock `execute_plan()` function
   - Gap: Should invoke agents with LLM providers
   - Lines 161-176: Mock execution returns hardcoded success

3. **No LLM invocation in handlers:**
   - `new_project_command`: File operations only
   - `plan_phase_command`: Template generation only
   - `execute_phase_command`: Mock execution only

### Modules with Correct RLM Usage

| Module | Integration | Evidence |
|--------|-------------|----------|
| config/settings.py | Provider creation | `LLMConfig.get_provider_instance()` |
| commands/provider_router.py | Task routing | `route_to_provider()`, `validate_provider()` |
| optimization/optimizer.py | DSPy | `AgentOptimizer` with MIPROv2 |
| optimization/rzero.py | DSPy | `RZeroLoop`, `ChallengerSignature` |
| tools/file_tools.py | Tool base | `from rlm_toolkit.tools import Tool` |
| tools/shell_tool.py | Tool base | `from rlm_toolkit.tools import Tool` |
| agents/loader.py | Agent creation | `from rlm_toolkit.agents import Agent` |

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| Custom LLM clients | rlm_toolkit providers | Phase 1 | 75+ provider support |
| Static plan templates | Template generation | Phase 5 | Fast but not intelligent |
| Mock execution | HybridOrchestrator | Phase 2 | Parallel execution ready |

**Deprecated/outdated:**
- `MultiAgentRuntime` simplified version: Should use full rlm_toolkit when available

## Open Questions

1. **Should all commands use RLM?**
   - What we know: Administrative commands (init, status, version) don't need LLM
   - What's unclear: Where to draw the line between admin and agent commands
   - Recommendation: Only commands that need intelligence/planning should use RLM

2. **How should plan_phase invoke LLM?**
   - What we know: SkillRegistry has skill definitions, LLMConfig has providers
   - What's unclear: Should handler invoke agent or just prepare context for OpenCode?
   - Recommendation: Handler should prepare context; OpenCode invokes the actual agent

3. **Should bundled commands be audited?**
   - What we know: 14 commands, 34 workflows, 11 agents in bundled/
   - What's unclear: Are these using RLM correctly through OpenCode?
   - Recommendation: Audit bundled agents for provider configuration completeness

## Phase Requirements

Since this is an audit phase, requirements will be derived from the audit findings:

| Audit Area | Description |
|------------|-------------|
| Command Inventory | List all GSD commands with RLM classification |
| Gap Analysis | Identify commands missing expected RLM integration |
| Provider Audit | Verify all agent commands can access provider config |
| Tool Audit | Verify tools inherit from rlm_toolkit correctly |
| Agent Audit | Verify bundled agents have LLM configuration |

## Sources

### Primary (HIGH confidence)
- Codebase analysis: `src/gsd_rlm/` directory structure
- ROADMAP.md: Phase 8 definition and requirements
- REQUIREMENTS.md: RLM-related requirements (INT-06, INT-07, INT-08)

### Secondary (MEDIUM confidence)
- AGENTS.md: Project coding conventions
- STATE.md: Project decisions affecting RLM usage

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - Direct code inspection of rlm_toolkit imports
- Architecture: HIGH - Analyzed all command handlers and CLI
- Audit findings: HIGH - Complete inventory of commands
- Gaps: MEDIUM - Recommendations based on analysis, not user requirements

**Research date:** 2026-03-01
**Valid until:** 30 days (stable codebase)
