# Pitfalls Research: Multi-Agent Development Workflow Systems

**Domain:** Multi-Agent Development Workflow with RLM-Toolkit Integration
**Researched:** 2026-02-27
**Confidence:** HIGH (Context7 verified for AutoGen/CrewAI patterns, RLM-Toolkit codebase analyzed directly)

---

## Critical Pitfalls

### Pitfall 1: Context Degradation / Memory Loss

**What goes wrong:**
Agents lose conversational context during long workflows or after state resets. The agent team cannot recall previous interactions, decisions, or intermediate results. After `agent_team.reset()`, all prior context is lost and agents respond "I don't recall" to queries about previous work.

**Why it happens:**
- Context is stored ephemerally in message history without persistence
- No checkpointing of conversation state between agent handoffs
- Buffer overflow truncates oldest messages when context exceeds limits
- Developers assume memory persists across agent invocations

**How to avoid:**
- Implement explicit state persistence with `save_state()` / `load_state()` pattern
- Use `BufferedChatCompletionContext(buffer_size=N)` to control history retention
- Store critical decisions in H-MEM hierarchical memory (Episode → Trace → Category → Domain)
- Use Memory Bridge for project-level persistent context (L0-L3 hierarchy)
- Never rely on agent "memory" — explicitly pass context in messages

**Warning signs:**
- Agent asks clarifying questions about information it previously received
- Inconsistent responses to the same query across sessions
- `reset()` calls without corresponding `load_state()`
- Context window warnings in logs

**Phase to address:** Phase 1 (Core Workflow) — memory architecture must be foundational

---

### Pitfall 2: Infinite Delegation Loops

**What goes wrong:**
Agents delegate tasks back and forth indefinitely without making progress. Agent A delegates to Agent B, who delegates back to Agent A, creating an endless cycle that consumes resources and never completes.

**Why it happens:**
- All agents have `allow_delegation=True` by default
- No clear hierarchy or chain of command
- Agents lack explicit "terminal" conditions for their tasks
- Routing logic allows circular paths through agents

**How to avoid:**
- Establish clear hierarchy: Manager agents have `allow_delegation=True`, specialists have `allow_delegation=False`
- Implement `MaxMessageTermination(max_messages=N)` as a safety guard
- Add `TextMentionTermination("TERMINATE")` or similar completion signals
- Design acyclic routing graphs — validate routing paths at startup
- Use RLM-Toolkit's `max_iterations` guard in `MultiAgentRuntime`

```python
# Correct pattern:
manager = Agent(role="Manager", allow_delegation=True)
specialist1 = Agent(role="Specialist A", allow_delegation=False)  # No re-delegation
specialist2 = Agent(role="Specialist B", allow_delegation=False)
```

**Warning signs:**
- Same message bouncing between 2-3 agents repeatedly
- Task duration exceeds expected time by 10x+
- Log shows same agent pair exchanging messages in a loop

**Phase to address:** Phase 2 (Hybrid Runtime) — agent coordination architecture

---

### Pitfall 3: Trust Zone Boundary Violations

**What goes wrong:**
Agents access or leak information they shouldn't have access to. Confidential data from one trust zone appears in responses from agents in lower-trust zones. Security boundaries between agents are not enforced.

**Why it happens:**
- Trust zones not configured at agent initialization
- Message routing bypasses zone checks
- Memory sharing between zones without access controls
- `can_access()` checks skipped or incorrectly implemented

**How to avoid:**
- Define zone hierarchy explicitly: `public < internal < confidential < secret`
- Configure `trust_zone` on every agent at initialization
- Use RLM-Toolkit's `SecureAgent` with H-MEM Trust Zones
- Validate `message.trust_zone` before processing in each agent
- Never share memory between zones without explicit `grant_access()`

```python
# Zone level check pattern:
zone_levels = {"public": 0, "internal": 1, "confidential": 2, "secret": 3}
agent_level = zone_levels.get(self.trust_zone, 0)
message_level = zone_levels.get(message.trust_zone, 0)
return agent_level >= message_level
```

**Warning signs:**
- Logs showing "Agent X cannot access message in zone Y" warnings
- Sensitive data appearing in outputs that should be sanitized
- Agents in "public" zone processing "confidential" content

**Phase to address:** Phase 4 (SecureAgent Integration) — security architecture

---

### Pitfall 4: State Serialization Race Conditions

**What goes wrong:**
Concurrent agents modify shared state, causing lost updates, corrupted data, or inconsistent views. Agent A writes to state while Agent B is reading, resulting in partial or incorrect data.

**Why it happens:**
- Parallel agent execution without locking
- State stored in mutable shared objects
- No transaction boundaries around state updates
- Async operations complete out of expected order

**How to avoid:**
- Use immutable message state — never mutate `message.state` directly
- Implement copy-on-write: `new_state = {**message.state, "key": "value"}`
- Add threading locks around shared resources (`threading.Lock()`)
- Use `concurrent.futures.ThreadPoolExecutor` with controlled max_workers
- Design for eventual consistency rather than strong consistency

```python
# Thread-safe state update:
with self._lock:
    self._tasks_completed += 1
```

**Warning signs:**
- Intermittent test failures under load
- State values that don't match expected calculations
- Debug logs showing interleaved state modifications

**Phase to address:** Phase 2 (Hybrid Runtime) — concurrency model

---

### Pitfall 5: Context Window Overflow

**What goes wrong:**
Agents fail when accumulated context exceeds LLM context limits. Long conversations, large file contents, or excessive memory retrieval causes "context too long" errors or silent truncation of critical information.

**Why it happens:**
- Unbounded history accumulation in message.history
- InfiniRetri not configured with compression limits
- Full file contents loaded instead of semantic summaries
- Memory retrieval returns too many results

**How to avoid:**
- Implement buffer limits: `BufferedChatCompletionContext(buffer_size=10)`
- Use semantic routing for context loading (56x compression from RLM-Toolkit)
- Summarize rather than include full content
- Implement tiered context: essential → important → optional
- Monitor context token usage and alert at 80% capacity

**Warning signs:**
- LLM API errors about context length
- Responses that seem to ignore earlier instructions
- Performance degradation as conversation lengthens

**Phase to address:** Phase 3 (InfiniRetri Integration) — infinite context architecture

---

## Technical Debt Patterns

| Shortcut | Immediate Benefit | Long-term Cost | When Acceptable |
|----------|-------------------|----------------|-----------------|
| Skip state persistence | Faster initial development | Lost context on crash, unreproducible workflows | Never |
| Allow all agents to delegate | Simpler coordination | Infinite loops, unpredictable behavior | Never |
| Single trust zone | No access control complexity | Security violations, data leaks | Only for isolated single-user prototypes |
| In-memory queues only | No external dependencies | Lost messages on crash, no scalability | MVP only, replace before production |
| No termination guards | Agents run "until done" | Infinite loops, resource exhaustion | Never |
| Global shared state | Easy data sharing | Race conditions, debugging nightmares | Never |

---

## Integration Gotchas

| Integration | Common Mistake | Correct Approach |
|-------------|----------------|------------------|
| H-MEM | Assuming memory persists across sessions | Explicitly persist and load H-MEM state; use Memory Bridge for cross-session persistence |
| Memory Bridge | Not scoping facts to projects | Always include project context when storing facts; use L0-L3 hierarchy |
| InfiniRetri | Loading full documents into context | Use semantic routing to load only relevant chunks; implement compression |
| OpenCode Skills | Agents not registering as skills | Each agent type needs SKILL.md definition; register in skills directory |
| Git Hooks | Not extracting facts from commits | Configure git post-commit hooks to extract facts to Memory Bridge |
| LLM Providers | Single provider for all agents | Use appropriate provider per task (local for speed, cloud for quality) |

---

## Performance Traps

| Trap | Symptoms | Prevention | When It Breaks |
|------|----------|------------|----------------|
| Unbounded message history | Slower responses, eventual OOM | Buffer limits, summarization, truncation | >50 messages per conversation |
| Synchronous agent chains | Long wait times, idle agents | Parallel wave execution with dependencies | >5 agents in sequence |
| Full memory retrieval | Slow responses, irrelevant context | Top-k limits, semantic filtering | >1000 memory entries |
| No request batching | High latency per agent call | Batch messages in run_batch() | >10 concurrent tasks |
| Missing resilience wrapper | Failed tasks on transient errors | Wrap providers with ResilientProvider | Any production use |

---

## Security Mistakes

| Mistake | Risk | Prevention |
|---------|------|------------|
| Agent-to-agent trust without verification | Malicious agent impersonation | Verify sender identity in each message |
| Unencrypted sensitive memories | Data exposure in storage | Use SecureAgent with encryption enabled |
| Cross-zone memory sharing | Data leakage between trust levels | Enforce zone hierarchy checks; explicit grants |
| Prompt injection via user content | Agent manipulation, data exfiltration | Sanitize all user input; use SENTINEL detection |
| No audit trail | Untraceable security incidents | Log all agent actions with timestamps and zones |

---

## UX Pitfalls

| Pitfall | User Impact | Better Approach |
|---------|-------------|-----------------|
| Silent failures | User doesn't know task failed | Return structured error objects; surface to UI |
| No progress indication | User thinks system is frozen | Emit progress events at each agent step |
| Inconsistent agent outputs | User confused by varying quality | Standardize output schemas; add confidence scores |
| Lost context between sessions | User must re-explain everything | Auto-restore context on session resume |
| Unclear agent responsibilities | User doesn't know who to blame | Tag outputs with agent_id and role |

---

## "Looks Done But Isn't" Checklist

- [ ] **Memory Integration:** Often missing persistence layer — verify H-MEM saves survive restart
- [ ] **Termination Guards:** Often missing max_iterations — verify runtime has safety limits
- [ ] **Trust Zones:** Often configured but not enforced — verify zone checks actually block access
- [ ] **Error Handling:** Often catches exceptions but doesn't propagate — verify errors surface to orchestrator
- [ ] **State Serialization:** Often saves but can't restore — verify load_state() round-trips correctly
- [ ] **Parallel Execution:** Often claims parallelism but runs sequentially — verify actual concurrent execution
- [ ] **Context Compression:** Often configured but not applied — verify InfiniRetri compression ratio

---

## Recovery Strategies

| Pitfall | Recovery Cost | Recovery Steps |
|---------|---------------|----------------|
| Context Degradation | MEDIUM | Re-run workflow from last checkpoint; implement state restoration |
| Infinite Delegation Loop | LOW | Kill process; add termination guards; re-run |
| Trust Zone Violation | HIGH | Audit logs; identify leaked data; rotate secrets; re-architect zones |
| Race Condition | MEDIUM | Identify corrupted state; restore from backup; add locking |
| Context Overflow | LOW | Clear history; implement buffers; re-run with compression |
| Lost Messages | MEDIUM | Check queue persistence; re-send from checkpoint |

---

## Pitfall-to-Phase Mapping

| Pitfall | Prevention Phase | Verification |
|---------|------------------|--------------|
| Context Degradation | Phase 1: Core Workflow | Verify state persistence round-trip |
| Infinite Delegation Loops | Phase 2: Hybrid Runtime | Run loop detection test; verify termination |
| Trust Zone Violations | Phase 4: SecureAgent | Attempt cross-zone access; verify block |
| Race Conditions | Phase 2: Hybrid Runtime | Run concurrent load test; verify consistency |
| Context Overflow | Phase 3: InfiniRetri | Test with 10M+ tokens; verify compression |
| Missing Resilience | Phase 5: Provider Integration | Simulate transient failures; verify retry |
| Prompt Injection | Phase 6: Security Integration | Run SENTINEL red-team tests |

---

## RLM-Toolkit Specific Gotchas

### Agent Message State Mutability
**Issue:** RLM-Toolkit uses stateless agents with state in messages, but Python objects are mutable by default.

**Prevention:**
```python
# WRONG: Direct mutation
message.state["key"] = "value"

# CORRECT: Copy-on-write
new_state = {**message.state, "key": "value"}
message.state = new_state
```

### MultiAgentRuntime max_iterations Default
**Issue:** Default `max_iterations=100` may be too low for complex workflows or too high for quick tasks.

**Prevention:** Configure based on expected workflow complexity; log iteration counts.

### SecureAgent Memory Import Availability
**Issue:** `HMEM_AVAILABLE` and `EVOLVE_AVAILABLE` may be False if optional dependencies not installed.

**Prevention:** Check availability flags before using advanced features; provide fallbacks.

### EvolvingAgent Confidence Thresholds
**Issue:** Self-evolving agents return confidence scores but developers may not use them.

**Prevention:** Always check `solution.confidence` and set minimum thresholds for critical tasks.

---

## Sources

- **Context7/AutoGen:** State persistence, termination conditions, buffered context — https://github.com/microsoft/autogen
- **Context7/CrewAI:** Delegation loops, memory management, context limitations — https://github.com/crewaiinc/crewai
- **Context7/LangChain:** State-based memory, checkpointer patterns, Redis integration — https://docs.langchain.com
- **RLM-Toolkit Codebase:** Agent architecture, SecureAgent, EvolvingAgent, MultiAgentRuntime — Analyzed directly from AISecurity-rlm-v2.3.1/rlm-toolkit/
- **GSD Patterns:** Context engineering, fresh context per agent, atomic commits — ~/.config/opencode/get-shit-done/

---
*Pitfalls research for: Multi-Agent Development Workflow Systems (GSD-RLM)*
*Researched: 2026-02-27*
