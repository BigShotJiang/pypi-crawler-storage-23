---
phase: quick
plan: 003
type: execute
wave: 1
depends_on: []
files_modified: []
autonomous: false
requirements: []
user_setup:
  - service: pypi
    why: "Package publishing"
    env_vars:
      - name: TWINE_USERNAME
        source: "PyPI Account Settings (or use __token__ for API token)"
      - name: TWINE_PASSWORD
        source: "PyPI API Token from Account Settings → API tokens"

must_haves:
  truths:
    - "Package builds successfully with no errors"
    - "dist/ contains wheel and source distribution"
    - "User can upload to PyPI with twine"
  artifacts:
    - path: "dist/gsd_rlm-0.1.0-py3-none-any.whl"
      provides: "Wheel distribution"
    - path: "dist/gsd_rlm-0.1.0.tar.gz"
      provides: "Source distribution"
  key_links: []
---

<objective>
Build gsd-rlm package and prepare for PyPI publication.

Purpose: Package the library for distribution via PyPI.
Output: Built wheel and source distribution ready for upload.
</objective>

<execution_context>
@~\.config\opencode/get-shit-done/workflows/execute-plan.md
@~\.config\opencode/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/STATE.md
@pyproject.toml
</context>

<tasks>

<task type="auto">
  <name>Build the package</name>
  <files>dist/*</files>
  <action>
    Clean the dist/ directory and build the package:
    
    1. Remove existing dist/ contents: `rm -rf dist/*` (or `Remove-Item -Recurse -Force dist\*` on Windows)
    2. Build the package: `python -m build`
    
    This creates:
    - dist/gsd_rlm-0.1.0-py3-none-any.whl (wheel)
    - dist/gsd_rlm-0.1.0.tar.gz (source distribution)
    
    Verify both files exist after build completes.
  </action>
  <verify>
    <automated>ls dist/*.whl dist/*.tar.gz 2>/dev/null || dir dist\*.whl dist\*.tar.gz</automated>
    <manual>Confirm wheel and tar.gz files exist in dist/</manual>
    <sampling_rate>run after this task commits</sampling_rate>
  </verify>
  <done>dist/ contains gsd_rlm-0.1.0-py3-none-any.whl and gsd_rlm-0.1.0.tar.gz</done>
</task>

<task type="checkpoint:human-action" gate="blocking">
  <what-built>Package built successfully in dist/</what-built>
  <how-to-verify>
    **Upload to PyPI (requires your credentials):**
    
    ```bash
    twine upload dist/*
    ```
    
    **Options for authentication:**
    
    1. **API Token (recommended):**
       - Go to https://pypi.org/manage/account/token/
       - Create a new API token
       - Set environment: `TWINE_USERNAME=__token__` and `TWINE_PASSWORD=pypi-...`
    
    2. **Username/Password:**
       - Set `TWINE_USERNAME` and `TWINE_PASSWORD` to your PyPI credentials
    
    **Verify upload:**
    - Visit https://pypi.org/project/gsd-rlm/
    - Confirm version 0.1.0 is visible
  </how-to-verify>
  <resume-signal>Type "published" once upload completes, or describe any errors</resume-signal>
</task>

</tasks>

<verification>
- Build completes without errors
- Both wheel and source distribution created
- User uploads to PyPI successfully
</verification>

<success_criteria>
- dist/gsd_rlm-0.1.0-py3-none-any.whl exists
- dist/gsd_rlm-0.1.0.tar.gz exists
- Package visible at https://pypi.org/project/gsd-rlm/
</success_criteria>

<output>
After completion, create `.planning/quick/003-build-and-publish-gsd-rlm-to-pypi/003-SUMMARY.md`
</output>
