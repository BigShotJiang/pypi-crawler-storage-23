---
phase: quick-001
plan: 01
type: execute
wave: 1
depends_on: []
files_modified:
  - C:\Users\kuk\.config\opencode\get-shit-done\workflows\quick.md
autonomous: true
requirements: []
must_haves:
  truths:
    - "gsd-tools.cjs init command works on Windows PowerShell"
    - "Workflow uses cross-platform path resolution"
  artifacts:
    - path: "C:\Users\kuk\.config\opencode\get-shit-done\workflows\quick.md"
      provides: "Quick workflow orchestration"
      contains: "node.*gsd-tools.cjs"
  key_links:
    - from: "workflows/quick.md"
      to: "gsd-tools.cjs"
      via: "node command invocation"
      pattern: "node.*gsd-tools\\.cjs"
---

<objective>
Fix Windows path resolution issue in quick.md workflow where `~\.config\opencode/...` fails because tilde expansion doesn't work in PowerShell.

Purpose: Enable GSD quick workflow to run on Windows without path errors
Output: Updated quick.md with cross-platform path handling
</objective>

<execution_context>
@~\.config\opencode/get-shit-done/workflows/execute-plan.md
@~\.config\opencode/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/PROJECT.md
@.planning/STATE.md

**Problem Analysis:**
- Error: `Cannot find module 'C:\Users\kuk\Desktop\rlm\Userskuk.configopencodeget-shit-donebingsd-tools.cjs'`
- Root cause: `~` tilde not expanded in PowerShell, backslashes mangled
- Affected lines in quick.md: 46, 225, 395

**Current (broken):**
```bash
INIT=$(node ~\.config\opencode/get-shit-done/bin/gsd-tools.cjs init quick "$DESCRIPTION")
```

**Solution:** Use Node.js `os.homedir()` for cross-platform home directory resolution:
```bash
INIT=$(node -e "console.log(require('os').homedir())")
GSD_TOOLS="${INIT}/.config/opencode/get-shit-done/bin/gsd-tools.cjs"
# Then use "$GSD_TOOLS"
```
</context>

<tasks>

<task type="auto">
  <name>task 1: Fix path resolution in quick.md workflow</name>
  <files>C:\Users\kuk\.config\opencode\get-shit-done\workflows\quick.md</files>
  <action>
Fix the three locations where `~\.config\opencode/...` or `~/.config/opencode/...` paths are used:

1. **Line 46 (Step 2 Initialize):** Replace the single line:
   ```bash
   INIT=$(node ~\.config\opencode/get-shit-done/bin/gsd-tools.cjs init quick "$DESCRIPTION")
   ```
   With cross-platform version:
   ```bash
   GSD_HOME=$(node -e "console.log(require('os').homedir())")
   INIT=$(node "${GSD_HOME}/.config/opencode/get-shit-done/bin/gsd-tools.cjs" init quick "$DESCRIPTION")
   ```

2. **Line 225 (Step 5.5 revision prompt):** Change:
   ```
   prompt="First, read ~\.config\opencode/agents/gsd-planner.md for your role and instructions.\n\n" + revision_prompt,
   ```
   To:
   ```
   prompt="First, read ${GSD_HOME}/.config/opencode/agents/gsd-planner.md for your role and instructions.\n\n" + revision_prompt,
   ```
   NOTE: This requires GSD_HOME to be set earlier. Add after line 46:
   ```bash
   GSD_HOME=$(node -e "console.log(require('os').homedir())")
   ```

3. **Line 395 (Step 8 commit):** Replace:
   ```bash
   node ~\.config\opencode/get-shit-done/bin/gsd-tools.cjs commit "docs(quick-${next_num}): ${DESCRIPTION}" --files ${file_list}
   ```
   With:
   ```bash
   node "${GSD_HOME}/.config/opencode/get-shit-done/bin/gsd-tools.cjs" commit "docs(quick-${next_num}): ${DESCRIPTION}" --files ${file_list}
   ```

**Key rules:**
- Use forward slashes (work on both Windows and Unix)
- Quote paths with `"${GSD_HOME}/..."` to handle spaces in paths
- Define `GSD_HOME` once at the start (after Step 1 or in Step 2)
  </action>
  <verify>
    <automated>node "C:\Users\kuk\.config\opencode\get-shit-done\bin\gsd-tools.cjs" init quick "test" 2>&1 | grep -q '"planner_model"' && echo "PASS" || echo "FAIL"</automated>
    <manual>Verify the workflow file no longer contains bare `~\` or `~/` paths for gsd-tools.cjs</manual>
    <sampling_rate>run after task commits</sampling_rate>
  </verify>
  <done>
    - All three path references in quick.md use `${GSD_HOME}` variable
    - GSD_HOME is defined using `node -e "console.log(require('os').homedir())"`
    - No bare `~/.config` or `~\.config` paths remain for gsd-tools.cjs
    - Paths use forward slashes and are quoted
  </done>
</task>

</tasks>

<verification>
1. Grep quick.md for remaining tilde paths: `grep -n "~.*config.*opencode" quick.md` should only show comments, not executable code
2. Verify GSD_HOME is defined before first use
3. Verify gsd-tools.cjs init command works on Windows
</verification>

<success_criteria>
- quick.md uses cross-platform path resolution via Node.js os.homedir()
- `node gsd-tools.cjs init quick` works on Windows PowerShell
- No tilde (`~`) paths in executable bash commands
</success_criteria>

<output>
After completion, create `.planning/quick/001-fix-missing-module-issue-in-gsd-tools-cj/001-SUMMARY.md`
</output>
