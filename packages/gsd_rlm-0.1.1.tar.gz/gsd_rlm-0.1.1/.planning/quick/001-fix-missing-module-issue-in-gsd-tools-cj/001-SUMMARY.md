---
phase: quick-001
plan: 01
subsystem: workflow
tags: [windows, cross-platform, path-resolution, bugfix]
duration_min: 2
completed_date: 2026-03-02
---

# Quick Task 001: Fix Missing Module Issue in gsd-tools.cjs Summary

## One-liner

Fixed Windows path resolution in quick.md workflow by replacing tilde paths with Node.js `os.homedir()` for cross-platform compatibility.

## Problem

The quick.md workflow used tilde paths (`~\.config\opencode/...`) which don't expand correctly in PowerShell on Windows, causing errors like:
```
Cannot find module 'C:\Users\kuk\Desktop\rlm\Userskuk.configopencodeget-shit-donebingsd-tools.cjs'
```

## Solution

Replaced all tilde-based paths with cross-platform path resolution using Node.js `os.homedir()`:

1. Added `GSD_HOME` variable definition at Step 2:
   ```bash
   GSD_HOME=$(node -e "console.log(require('os').homedir())")
   ```

2. Updated three locations to use `${GSD_HOME}`:
   - Line 46-47: Step 2 initialization
   - Line 226: Step 5.5 revision prompt path
   - Line 396: Step 8 commit command

## Files Modified

| File | Change |
|------|--------|
| `C:\Users\kuk\.config\opencode\get-shit-done\workflows\quick.md` | Added GSD_HOME definition, replaced 3 tilde paths |

## Verification

- [x] No tilde paths remain in executable code
- [x] `gsd-tools.cjs init quick` works on Windows PowerShell
- [x] All paths use forward slashes (cross-platform compatible)
- [x] Paths are quoted to handle spaces

## Deviations from Plan

None - plan executed exactly as written.

## Key Decisions

- Used `node -e "console.log(require('os').homedir())"` for cross-platform home directory resolution
- Defined `GSD_HOME` once at Step 2, reused in all subsequent path references
- Used forward slashes in all paths (works on both Windows and Unix)
