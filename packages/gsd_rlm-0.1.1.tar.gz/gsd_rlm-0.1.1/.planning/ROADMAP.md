# Roadmap: GSD-RLM Multi-Agent Development Workflow

## Overview

This roadmap transforms the GSD-RLM vision into a production-ready multi-agent development workflow system. We progress from foundational agent execution (Phase 1) through parallel coordination (Phase 2), memory systems (Phase 3), security (Phase 4), user-facing integration (Phase 5), and finally self-improvement capabilities (Phase 6). Each phase delivers a coherent, verifiable capability that builds on previous phases.

## Phases

**Phase Numbering:**
- Integer phases (1, 2, 3): Planned milestone work
- Decimal phases (2.1, 2.2): Urgent insertions (marked with INSERTED)

Decimal phases appear between their surrounding integers in numeric order.

- [x] **Phase 1: Core Workflow Foundation** - Agent definition, sequential execution, file/shell tools, state persistence
- [x] **Phase 2: Hybrid Runtime + Coordination** - Wave-based parallel execution, P2P agent communication, dependency resolution
- [x] **Phase 3: Memory Systems + InfiniRetri** - H-MEM hierarchical memory, Memory Bridge, semantic routing, infinite context
- [x] **Phase 4: SecureAgent Integration** - Trust zones, encrypted memories, access control
- [x] **Phase 5: OpenCode Integration + Commands** - Skills, commands, checkpoints, spec-driven workflow, git traceability
- [x] **Phase 6: Self-Improvement + Optimization** - DSPy prompt optimization, R-Zero self-refinement, execution traces
- [x] **Phase 7: Global OpenCode Integration** - pip install, global CLI, bundled skills/commands, any-project usage
- [x] **Phase 8: Check GSD Commands RLM Usage** - Verify all GSD commands use RLM integration

## Phase Details

### Phase 1: Core Workflow Foundation
**Goal**: Users can define and run agents that execute tasks with persistent state and full file/shell access
**Depends on**: Nothing (first phase)
**Requirements**: AGENT-01, AGENT-02, AGENT-03, AGENT-04, AGENT-06, AGENT-07, AGENT-08, INT-06, INT-07, INT-09, INT-10, INT-11, INT-12, INT-13
**Success Criteria** (what must be TRUE):
  1. User can create an agent with custom name, role, goal, backstory, and tool configuration
  2. Agent executes sequential tasks and passes context between them
  3. Agent can read, write, edit, and search project files
  4. Agent can run shell commands (tests, builds, git) with safety controls (whitelist, timeout, sandbox)
  5. Agent session memory persists across task boundaries within a workflow
**Plans**: 5 plans in 3 waves

Plans:
- [x] 01-01-PLAN.md — YAML agent definition with Pydantic validation, tool whitelisting, LLM config (Wave 1)
- [x] 01-02-PLAN.md — Sequential execution with context passing, retry/fallback, validation (Wave 3)
- [x] 01-03-PLAN.md — File tools: Read, Write, Edit, Glob, Grep with project scoping (Wave 1)
- [x] 01-04-PLAN.md — GSD-style shell execution with AnyIO, configurable timeout (Wave 1)
- [x] 01-05-PLAN.md — File-based session memory with JSON persistence, resumable (Wave 2)

### Phase 2: Hybrid Runtime + Coordination
**Goal**: Users can execute multiple agents in parallel with dependency-aware wave scheduling
**Depends on**: Phase 1
**Requirements**: AGENT-05, EXEC-01, EXEC-02, EXEC-03, EXEC-04, EXEC-08, EXEC-09, EXEC-13, EXEC-14, EXEC-15
**Success Criteria** (what must be TRUE):
  1. System analyzes task dependencies and groups independent tasks into parallel waves
  2. Independent tasks execute concurrently while dependent tasks wait for prerequisites
  3. User sees real-time agent reasoning and output as execution progresses
  4. System retries failed tasks with exponential backoff and falls back to alternative agents
  5. Agents can hand off specialized work to other agents with full context preservation
**Plans**: 5 plans in 2 waves

Plans:
- [x] 02-01-PLAN.md — Dependency analysis with NetworkX topological_generations() for wave grouping (Wave 1)
- [x] 02-02-PLAN.md — Parallel execution with AnyIO task groups, HybridOrchestrator, P2P AgentChannel (Wave 2)
- [x] 02-03-PLAN.md — Real-time output streaming with AnyIO memory object streams (Wave 1)
- [x] 02-04-PLAN.md — GracefulDegradation with PartialResult, extended RetryableAgent (Wave 1)
- [x] 02-05-PLAN.md — Agent handoff with HandoffContext preserving conversation/task context (Wave 1)

### Phase 3: Memory Systems + InfiniRetri
**Goal**: Agents have persistent hierarchical memory and can process massive codebases efficiently
**Depends on**: Phase 2
**Requirements**: MEM-01, MEM-02, MEM-03, MEM-04, MEM-05, MEM-06, MEM-07, MEM-08, MEM-09, MEM-10, MEM-11, MEM-12
**Success Criteria** (what must be TRUE):
  1. Agent experiences are stored as H-MEM episodes and consolidated into traces, categories, and domain knowledge
  2. User can resume previous sessions with full context restoration from Memory Bridge
  3. Agents can process documents/codebases with 10M+ tokens via InfiniRetri compression
  4. System routes context queries to relevant memory stores via semantic similarity (56x compression)
  5. Git commits automatically extract facts to Memory Bridge for project-level persistence
**Plans**: 6 plans in 4 waves

Plans:
- [x] 03-01-PLAN.md — H-MEM Episode Storage with SQLite persistence (MEM-01, MEM-11) (Wave 1)
- [x] 03-02-PLAN.md — Memory Consolidation: Trace→Category→Domain (MEM-02, MEM-03, MEM-04) (Wave 2)
- [x] 03-03-PLAN.md — Memory Bridge with L0-L3 hierarchy (MEM-09) (Wave 1)
- [x] 03-04-PLAN.md — InfiniRetri semantic chunking and 56x compression (MEM-06, MEM-07) (Wave 1)
- [x] 03-05-PLAN.md — Memory Router and H-MEM Retrieval (MEM-05, MEM-08) (Wave 3)
- [x] 03-06-PLAN.md — Git hooks and Session Resumption (MEM-10, MEM-12) (Wave 4)

### Phase 4: SecureAgent Integration
**Goal**: Agents operate within trust zone boundaries with encrypted memories
**Depends on**: Phase 3
**Requirements**: SEC-01, SEC-02, SEC-03, SEC-04
**Success Criteria** (what must be TRUE):
  1. Agent memories are encrypted at rest using AES-256-GCM
  2. User can define trust zones (public, internal, confidential, secret) and assign agents to zones
  3. Cross-zone operations are blocked unless explicitly granted by user
  4. Trust zone violations are logged and prevented at runtime
**Plans**: 3 plans in 3 waves

Plans:
- [x] 04-01-PLAN.md — AES-256-GCM encryption and Trust Zone foundation (SEC-01, SEC-02) (Wave 1)
- [x] 04-02-PLAN.md — Access control with grant/revoke and violation logging (SEC-03, SEC-04) (Wave 2)
- [x] 04-03-PLAN.md — SecureAgent integration with EncryptedEpisodeStore (all SEC) (Wave 3)

### Phase 5: OpenCode Integration + Commands
**Goal**: Users invoke the system via OpenCode skills and commands with spec-driven workflow
**Depends on**: Phase 4
**Requirements**: INT-01, INT-02, INT-03, INT-04, INT-05, INT-08, INT-14, INT-15, EXEC-05, EXEC-06, EXEC-07, EXEC-10, EXEC-11, EXEC-12
**Success Criteria** (what must be TRUE):
  1. User can invoke /gsd-rlm-* commands to start workflows (new-project, plan-phase, execute-phase)
  2. System discovers and loads agent capabilities from skills/ directory via SKILL.md definitions
  3. Execution pauses at decision, verification, and action checkpoints for user input/review
  4. System validates deliverables against phase goals (must-haves) before marking phase complete
  5. Git commits include traceability to phase, plan, and task IDs for audit trails
**Plans**: 5 plans in 2 waves

Plans:
- [x] 05-01-PLAN.md — Skill discovery system with SKILL.md parsing and SkillRegistry (INT-01, INT-02, INT-03) (Wave 1)
- [x] 05-02-PLAN.md — Command router and handlers for /gsd-rlm-* commands with provider routing (INT-04, INT-05, INT-08) (Wave 2)
- [x] 05-03-PLAN.md — Checkpoint system with HUMAN_VERIFY, DECISION, HUMAN_ACTION types (EXEC-05, EXEC-06, EXEC-07) (Wave 1)
- [x] 05-04-PLAN.md — Spec-driven workflow with goal-backward verification (EXEC-10, EXEC-11, EXEC-12) (Wave 1)
- [x] 05-05-PLAN.md — Git traceability with atomic commits and phase/plan/task IDs (INT-14, INT-15) (Wave 1)

### Phase 6: Self-Improvement + Optimization
**Goal**: Agents improve their performance through DSPy optimization and R-Zero refinement
**Depends on**: Phase 5
**Requirements**: SEC-05, SEC-06, SEC-07, SEC-08
**Success Criteria** (what must be TRUE):
  1. System collects execution traces as optimization training data automatically
  2. Agents improve prompts via DSPy MIPROv2 optimization on-demand or periodically
  3. Agents self-refine through R-Zero challenger-solver loops for complex tasks
  4. Optimized prompts show measurable improvement in task success rates
**Plans**: 4 plans in 3 waves

Plans:
- [x] 06-01-PLAN.md — ExecutionTrace dataclass and TraceCollector with SQLite persistence, DSPy Example conversion (SEC-06) (Wave 1)
- [x] 06-02-PLAN.md — AgentOptimizer wrapper for DSPy MIPROv2, TaskSuccessMetric, save/load optimized programs (SEC-05) (Wave 2)
- [x] 06-03-PLAN.md — RZeroLoop challenger-solver pattern, ChallengerSignature, ChallengerFeedback, RefinementResult (SEC-07) (Wave 2)
- [x] 06-04-PLAN.md — OptimizationScheduler following ConsolidationJob pattern, OptimizationMetricsTracker (SEC-08) (Wave 3)

### Phase 7: Global OpenCode Integration
**Goal**: Users can install GSD-RLM globally and use it in any project by running OpenCode
**Depends on**: Phase 5, Phase 6
**Requirements**: GLOB-01, GLOB-02, GLOB-03, GLOB-04, GLOB-05, GLOB-06, GLOB-07
**Success Criteria** (what must be TRUE):
  1. User can run `pip install gsd-rlm` to install the package globally
  2. User can run `gsd-rlm init` in any directory to set up .planning/ structure
  3. OpenCode commands `/gsd-rlm-*` are available globally from any project
  4. System works without local installation — all code in global Python package
  5. Skills and workflows are bundled with the package
  6. Configuration is stored in user's home directory (~/.gsd-rlm/)
  7. User can update to new versions via `pip install --upgrade gsd-rlm`
**Plans**: 4 plans in 2 waves

Plans:
- [x] 07-01-PLAN.md — CLI foundation with typer, pyproject.toml entry points, version/status commands (GLOB-01, GLOB-02, GLOB-07) (Wave 1)
- [x] 07-02-PLAN.md — Global configuration with platformdirs for cross-platform user directory management (GLOB-05, GLOB-06) (Wave 1)
- [x] 07-03-PLAN.md — Init command to create .planning/ directory structure in any project (GLOB-02) (Wave 2)
- [x] 07-04-PLAN.md — Install-commands with bundled OpenCode commands and workflows (GLOB-03, GLOB-04) (Wave 2)

### Phase 8: Check GSD Commands RLM Usage
**Goal**: Verify that all GSD commands properly use RLM (Reinforcement Learning for Multi-agent) integration
**Depends on**: Phase 7
**Requirements**: AUDIT-01, AUDIT-02, AUDIT-03, AUDIT-04, AUDIT-05
**Success Criteria** (what must be TRUE):
  1. All GSD commands are audited for RLM usage
  2. Missing RLM integrations are identified
  3. Recommendations for RLM integration improvements are documented
**Plans**: 2 plans in 2 waves

Plans:
- [x] 08-01-PLAN.md — Command audit: inventory all commands and classify by RLM usage (Wave 1)
- [x] 08-02-PLAN.md — Gap analysis: verify provider routing and document findings (Wave 2)

## Progress

**Execution Order:**
Phases execute in numeric order: 1 → 2 → 3 → 4 → 5 → 6 → 7 → 8

| Phase | Plans Complete | Status | Completed |
|-------|----------------|--------|-----------|
| 1. Core Workflow Foundation | 5/5 | Complete | 01-01, 01-02, 01-03, 01-04, 01-05 |
| 2. Hybrid Runtime + Coordination | 5/5 | Complete | 02-01, 02-02, 02-03, 02-04, 02-05 |
| 3. Memory Systems + InfiniRetri | 6/6 | Complete | 03-01, 03-02, 03-03, 03-04, 03-05, 03-06 |
| 4. SecureAgent Integration | 3/3 | Complete | 04-01, 04-02, 04-03 |
| 5. OpenCode Integration + Commands | 5/5 | Complete | 05-01, 05-02, 05-03, 05-04, 05-05 |
| 6. Self-Improvement + Optimization | 4/4 | Complete | 06-01, 06-02, 06-03, 06-04 |
| 7. Global OpenCode Integration | 4/4 | Complete | 07-01, 07-02, 07-03, 07-04 |
| 8. Check GSD Commands RLM Usage | 2/2 | Complete | 08-01, 08-02 |

---
*Roadmap created: 2026-02-27*
*Last updated: 2026-03-01*
*Total phases: 8*
*Total requirements mapped: 65*
