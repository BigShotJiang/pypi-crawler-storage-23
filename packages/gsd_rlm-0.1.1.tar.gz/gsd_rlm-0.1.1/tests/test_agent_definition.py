"""
Tests for agent definition and loader.

This module contains comprehensive tests for:
- AgentDefinition validation
- ToolSpec configuration
- AgentLoader YAML loading
- Error handling

Run with: pytest tests/test_agent_definition.py -v
"""

import pytest
from pathlib import Path
from pydantic import ValidationError

from gsd_rlm.agents.definition import AgentDefinition, ToolSpec, LLMProvider
from gsd_rlm.agents.loader import AgentLoader, AgentLoaderError, load_agent


class TestAgentDefinition:
    """Tests for AgentDefinition model."""

    def test_valid_definition(self):
        """Valid definition should parse correctly."""
        defn = AgentDefinition(
            name="Test Agent",
            role="Tester",
            goal="Test everything",
            backstory="I am a test agent.",
        )
        assert defn.name == "Test Agent"
        assert defn.role == "Tester"
        assert defn.goal == "Test everything"
        assert defn.backstory == "I am a test agent."
        assert defn.llm_provider == LLMProvider.OLLAMA

    def test_required_fields_validation_empty_string(self):
        """Empty required fields should fail validation."""
        with pytest.raises(ValidationError):
            AgentDefinition(name="", role="test", goal="test", backstory="test")

    def test_required_fields_validation_whitespace(self):
        """Whitespace-only required fields should fail validation."""
        with pytest.raises(ValidationError):
            AgentDefinition(name="test", role="   ", goal="test", backstory="test")

    def test_tools_default_empty(self):
        """Tools should default to empty list."""
        defn = AgentDefinition(name="Test", role="Test", goal="Test", backstory="Test")
        assert defn.tools == []

    def test_tools_with_config(self):
        """Tools can have optional config."""
        defn = AgentDefinition(
            name="Test",
            role="Test",
            goal="Test",
            backstory="Test",
            tools=[
                ToolSpec(name="read_file"),
                ToolSpec(name="shell", config={"timeout": 60}),
            ],
        )
        assert len(defn.tools) == 2
        assert defn.tools[0].config == {}
        assert defn.tools[1].config == {"timeout": 60}

    def test_system_prompt_generation(self):
        """System prompt should include all fields."""
        defn = AgentDefinition(
            name="Alice",
            role="Developer",
            goal="Write code",
            backstory="Expert developer",
        )
        prompt = defn.get_system_prompt()
        assert "Alice" in prompt
        assert "Developer" in prompt
        assert "Write code" in prompt
        assert "Expert developer" in prompt

    def test_system_prompt_with_tools(self):
        """System prompt should list tools."""
        defn = AgentDefinition(
            name="Test",
            role="Test",
            goal="Test",
            backstory="Test",
            tools=[ToolSpec(name="read_file"), ToolSpec(name="shell")],
        )
        prompt = defn.get_system_prompt()
        assert "read_file" in prompt
        assert "shell" in prompt

    def test_unknown_fields_rejected(self):
        """Unknown fields should cause validation error."""
        with pytest.raises(ValidationError):
            AgentDefinition(
                name="Test",
                role="Test",
                goal="Test",
                backstory="Test",
                unknown_field="should fail",
            )

    def test_llm_provider_enum(self):
        """LLM provider should accept valid enum values."""
        defn = AgentDefinition(
            name="Test",
            role="Test",
            goal="Test",
            backstory="Test",
            llm_provider="openai",
        )
        assert defn.llm_provider == LLMProvider.OPENAI

    def test_get_agent_id(self):
        """Agent ID should be lowercase and hyphenated."""
        defn = AgentDefinition(
            name="Code Reviewer",
            role="Test",
            goal="Test",
            backstory="Test",
        )
        assert defn.get_agent_id() == "code-reviewer"

    def test_timeout_validation(self):
        """Timeout should be within valid range."""
        # Valid
        defn = AgentDefinition(
            name="Test",
            role="Test",
            goal="Test",
            backstory="Test",
            timeout=60,
        )
        assert defn.timeout == 60

        # Invalid - too low
        with pytest.raises(ValidationError):
            AgentDefinition(
                name="Test", role="Test", goal="Test", backstory="Test", timeout=0
            )

        # Invalid - too high
        with pytest.raises(ValidationError):
            AgentDefinition(
                name="Test", role="Test", goal="Test", backstory="Test", timeout=5000
            )


class TestToolSpec:
    """Tests for ToolSpec model."""

    def test_tool_spec_minimal(self):
        """ToolSpec with just name."""
        spec = ToolSpec(name="read_file")
        assert spec.name == "read_file"
        assert spec.config == {}

    def test_tool_spec_with_config(self):
        """ToolSpec with config."""
        spec = ToolSpec(name="shell", config={"timeout": 60, "shell": "/bin/bash"})
        assert spec.name == "shell"
        assert spec.config["timeout"] == 60
        assert spec.config["shell"] == "/bin/bash"

    def test_tool_spec_empty_name_rejected(self):
        """Empty tool name should fail."""
        with pytest.raises(ValidationError):
            ToolSpec(name="")

    def test_tool_spec_unknown_fields_rejected(self):
        """Unknown fields in ToolSpec should fail."""
        with pytest.raises(ValidationError):
            ToolSpec(name="test", unknown_field="should fail")


class TestAgentLoader:
    """Tests for AgentLoader class."""

    def test_load_example_yaml(self):
        """Load the example agent definition."""
        loader = AgentLoader()
        example_path = Path("agents/example.yaml")

        if example_path.exists():
            defn = loader.load_from_file(example_path)
            assert defn.name == "Code Reviewer"
            assert len(defn.tools) > 0
            assert defn.llm_provider == LLMProvider.OLLAMA

    def test_file_not_found_error(self):
        """Missing file should raise AgentLoaderError."""
        loader = AgentLoader()
        with pytest.raises(AgentLoaderError) as exc_info:
            loader.load_from_file(Path("nonexistent.yaml"))
        assert "not found" in str(exc_info.value)

    def test_invalid_yaml_error(self, tmp_path):
        """Invalid YAML should raise AgentLoaderError."""
        bad_yaml = tmp_path / "bad.yaml"
        bad_yaml.write_text("name: [invalid\nrole: test", encoding="utf-8")

        loader = AgentLoader()
        with pytest.raises(AgentLoaderError):
            loader.load_from_file(bad_yaml)

    def test_missing_required_field_error(self, tmp_path):
        """Missing required field should raise AgentLoaderError."""
        incomplete_yaml = tmp_path / "incomplete.yaml"
        incomplete_yaml.write_text(
            "name: Test\nrole: Test",  # Missing goal and backstory
            encoding="utf-8",
        )

        loader = AgentLoader()
        with pytest.raises(AgentLoaderError) as exc_info:
            loader.load_from_file(incomplete_yaml)
        assert "Invalid agent definition" in str(exc_info.value)

    def test_load_by_name(self, tmp_path):
        """Load agent by name from agents directory."""
        # Create a test agent file
        agent_yaml = tmp_path / "test-agent.yaml"
        agent_yaml.write_text(
            """
name: Test Agent
role: Tester
goal: Test things
backstory: I test things.
""",
            encoding="utf-8",
        )

        loader = AgentLoader(agents_dir=tmp_path)
        defn = loader.load_by_name("test-agent")
        assert defn.name == "Test Agent"

    def test_load_by_name_not_found(self):
        """Loading non-existent agent should raise error."""
        loader = AgentLoader(agents_dir=Path("nonexistent-dir"))
        with pytest.raises(AgentLoaderError) as exc_info:
            loader.load_by_name("missing")
        assert "not found" in str(exc_info.value)


class TestLoadAgentFunction:
    """Tests for load_agent convenience function."""

    def test_load_agent_function(self):
        """load_agent should work as convenience function."""
        example_path = Path("agents/example.yaml")
        if example_path.exists():
            defn = load_agent(example_path)
            assert defn.name == "Code Reviewer"


class TestLLMProvider:
    """Tests for LLMProvider enum."""

    def test_provider_values(self):
        """Check all provider values."""
        assert LLMProvider.OLLAMA.value == "ollama"
        assert LLMProvider.OPENAI.value == "openai"
        assert LLMProvider.ANTHROPIC.value == "anthropic"
        assert LLMProvider.GOOGLE.value == "google"
        assert LLMProvider.CUSTOM.value == "custom"

    def test_provider_from_string(self):
        """Create provider from string."""
        assert LLMProvider("ollama") == LLMProvider.OLLAMA
        assert LLMProvider("openai") == LLMProvider.OPENAI
