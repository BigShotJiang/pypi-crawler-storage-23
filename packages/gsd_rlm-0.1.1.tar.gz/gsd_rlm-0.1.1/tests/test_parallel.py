"""
Comprehensive tests for parallel execution with AnyIO task groups.

Tests cover:
- WaveRunner for parallel wave execution
- HybridOrchestrator for wave coordination
- AgentChannel for P2P agent communication

Requirements: EXEC-02 (parallel execution), EXEC-04 (P2P communication)
"""

import time
import anyio
import pytest

from gsd_rlm.execution.parallel import WaveRunner, TaskResult
from gsd_rlm.execution.dependency import DependencyGraph
from gsd_rlm.coordination.orchestrator import HybridOrchestrator, WaveResult
from gsd_rlm.coordination.p2p_channel import AgentChannel


# =============================================================================
# WaveRunner Tests
# =============================================================================


class TestWaveRunnerEmptyWave:
    """Tests for empty wave handling."""

    @pytest.mark.anyio
    async def test_empty_wave_returns_empty_list(self):
        """Empty task list should return empty results."""
        runner = WaveRunner()

        async def exec_func(tid):
            return f"result-{tid}"

        results = await runner.run_wave([], exec_func)
        assert results == []

    @pytest.mark.anyio
    async def test_empty_wave_no_progress_callbacks(self):
        """Empty wave should not trigger progress callbacks."""
        runner = WaveRunner()
        callback_calls = []

        def on_progress(status, task, detail):
            callback_calls.append((status, task, detail))

        async def exec_func(tid):
            return f"result-{tid}"

        await runner.run_wave([], exec_func, on_progress)
        assert callback_calls == []


class TestWaveRunnerSingleTask:
    """Tests for single task execution."""

    @pytest.mark.anyio
    async def test_single_task_returns_result(self):
        """Single task should return one result."""
        runner = WaveRunner()

        async def exec_func(tid):
            return f"result-{tid}"

        results = await runner.run_wave(["task-1"], exec_func)
        assert len(results) == 1
        assert results[0].task_id == "task-1"
        assert results[0].success is True
        assert results[0].content == "result-task-1"

    @pytest.mark.anyio
    async def test_single_task_progress_callbacks(self):
        """Single task should trigger starting/completed callbacks."""
        runner = WaveRunner()
        callback_calls = []

        def on_progress(status, task, detail):
            callback_calls.append((status, task))

        async def exec_func(tid):
            return f"result-{tid}"

        await runner.run_wave(["task-1"], exec_func, on_progress)
        assert ("starting", "task-1") in callback_calls
        assert ("completed", "task-1") in callback_calls


class TestWaveRunnerParallelExecution:
    """Tests for parallel execution behavior."""

    @pytest.mark.anyio
    async def test_multiple_tasks_run_concurrently(self):
        """Multiple tasks should run concurrently, not sequentially."""
        runner = WaveRunner()
        start_times = {}
        end_times = {}

        async def exec_func(tid):
            start_times[tid] = time.time()
            await anyio.sleep(0.1)
            end_times[tid] = time.time()
            return f"result-{tid}"

        start = time.time()
        results = await runner.run_wave(["a", "b", "c"], exec_func)
        total_time = time.time() - start

        # All 3 tasks running sequentially would take ~0.3s
        # Running concurrently should take ~0.1s
        assert total_time < 0.25, f"Tasks did not run concurrently: {total_time}s"
        assert len(results) == 3
        assert all(r.success for r in results)

    @pytest.mark.anyio
    async def test_results_in_input_order(self):
        """Results should be returned in the same order as input tasks."""
        runner = WaveRunner()

        async def exec_func(tid):
            # Vary execution time to test ordering
            delay = 0.05 if tid == "slow" else 0.01
            await anyio.sleep(delay)
            return f"result-{tid}"

        results = await runner.run_wave(["fast1", "slow", "fast2"], exec_func)
        assert results[0].task_id == "fast1"
        assert results[1].task_id == "slow"
        assert results[2].task_id == "fast2"


class TestWaveRunnerCollectsFailures:
    """Tests for failure collection behavior."""

    @pytest.mark.anyio
    async def test_failures_are_collected_not_raised(self):
        """Task failures should be collected, not raised."""
        runner = WaveRunner()

        async def exec_func(tid):
            if tid == "fail":
                raise ValueError("Task failed!")
            return f"result-{tid}"

        results = await runner.run_wave(["ok", "fail", "also-ok"], exec_func)

        assert len(results) == 3
        assert results[0].success is True
        assert results[1].success is False
        assert results[1].error == "Task failed!"
        assert results[2].success is True

    @pytest.mark.anyio
    async def test_one_failure_does_not_cancel_others(self):
        """One task failing should not cancel other tasks."""
        runner = WaveRunner()
        executed = []

        async def exec_func(tid):
            executed.append(tid)
            if tid == "fail":
                raise ValueError("Task failed!")
            await anyio.sleep(0.05)
            return f"result-{tid}"

        results = await runner.run_wave(["a", "fail", "b"], exec_func)

        # All tasks should have been attempted
        assert set(executed) == {"a", "fail", "b"}
        assert results[0].success is True
        assert results[1].success is False
        assert results[2].success is True

    @pytest.mark.anyio
    async def test_failure_progress_callback(self):
        """Failed tasks should trigger 'failed' progress callback."""
        runner = WaveRunner()
        callback_calls = []

        def on_progress(status, task, detail):
            callback_calls.append((status, task))

        async def exec_func(tid):
            if tid == "fail":
                raise ValueError("Task failed!")
            return f"result-{tid}"

        await runner.run_wave(["ok", "fail"], exec_func, on_progress)
        assert ("failed", "fail") in callback_calls


class TestWaveRunnerMaxConcurrent:
    """Tests for concurrency limiting."""

    @pytest.mark.anyio
    async def test_max_concurrent_limits_parallelism(self):
        """Semaphore should limit concurrent task execution."""
        runner = WaveRunner(max_concurrent=2)
        concurrent_count = 0
        max_concurrent = 0

        async def exec_func(tid):
            nonlocal concurrent_count, max_concurrent
            concurrent_count += 1
            max_concurrent = max(max_concurrent, concurrent_count)
            await anyio.sleep(0.05)
            concurrent_count -= 1
            return f"result-{tid}"

        await runner.run_wave(["a", "b", "c", "d"], exec_func)

        # Max concurrent should be 2 (limited by semaphore)
        assert max_concurrent <= 2, f"Too many concurrent tasks: {max_concurrent}"

    @pytest.mark.anyio
    async def test_no_limit_when_tasks_less_than_max(self):
        """No semaphore overhead when task count <= max_concurrent."""
        runner = WaveRunner(max_concurrent=10)

        async def exec_func(tid):
            await anyio.sleep(0.01)
            return f"result-{tid}"

        results = await runner.run_wave(["a", "b"], exec_func)
        assert len(results) == 2
        assert all(r.success for r in results)


# =============================================================================
# HybridOrchestrator Tests
# =============================================================================


class TestHybridOrchestratorTwoWaves:
    """Tests for wave-based execution."""

    @pytest.mark.anyio
    async def test_two_waves_execute_sequentially(self):
        """Waves should execute sequentially based on dependencies."""
        graph = DependencyGraph()
        graph.add_task("a")
        graph.add_task("b")
        graph.add_task("c", depends_on=["a", "b"])

        runner = WaveRunner()
        orchestrator = HybridOrchestrator(graph, runner)

        execution_order = []

        async def exec_func(tid):
            execution_order.append(tid)
            await anyio.sleep(0.01)
            return f"result-{tid}"

        results = await orchestrator.execute(exec_func)

        assert len(results) == 2  # Two waves
        # Wave 0: a, b (in any order within wave)
        # Wave 1: c (after both a and b)
        assert len(results[0].task_ids) == 2
        assert set(results[0].task_ids) == {"a", "b"}
        assert results[1].task_ids == ["c"]

    @pytest.mark.anyio
    async def test_wave_results_contain_correct_data(self):
        """WaveResult should contain correct results and errors."""
        graph = DependencyGraph()
        graph.add_task("a")
        graph.add_task("b")

        runner = WaveRunner()
        orchestrator = HybridOrchestrator(graph, runner)

        async def exec_func(tid):
            return f"result-{tid}"

        results = await orchestrator.execute(exec_func)

        assert len(results) == 1
        wave_result = results[0]
        assert wave_result.success is True
        assert "a" in wave_result.results
        assert "b" in wave_result.results
        assert wave_result.errors == {}


class TestHybridOrchestratorWaveCallbacks:
    """Tests for wave completion callbacks."""

    @pytest.mark.anyio
    async def test_on_wave_complete_callback(self):
        """on_wave_complete callback should fire after each wave."""
        graph = DependencyGraph()
        graph.add_task("a")
        graph.add_task("b")
        graph.add_task("c", depends_on=["a"])

        runner = WaveRunner()
        orchestrator = HybridOrchestrator(graph, runner)

        callback_waves = []

        def on_wave_complete(wave_result):
            callback_waves.append(wave_result.wave_id)

        async def exec_func(tid):
            return f"result-{tid}"

        await orchestrator.execute(exec_func, on_wave_complete=on_wave_complete)

        assert callback_waves == [0, 1]  # Two waves

    @pytest.mark.anyio
    async def test_on_progress_callback_passed_through(self):
        """on_progress callback should be passed to WaveRunner."""
        graph = DependencyGraph()
        graph.add_task("a")

        runner = WaveRunner()
        orchestrator = HybridOrchestrator(graph, runner)

        progress_calls = []

        def on_progress(status, task, detail):
            progress_calls.append((status, task))

        async def exec_func(tid):
            return f"result-{tid}"

        await orchestrator.execute(exec_func, on_progress=on_progress)

        assert ("starting", "a") in progress_calls
        assert ("completed", "a") in progress_calls


class TestHybridOrchestratorGracefulDegradation:
    """Tests for graceful degradation with partial failures."""

    @pytest.mark.anyio
    async def test_continues_with_partial_success(self):
        """Execution should continue if at least one task succeeds."""
        graph = DependencyGraph()
        graph.add_task("a")
        graph.add_task("b")
        graph.add_task("c", depends_on=["a"])

        runner = WaveRunner()
        orchestrator = HybridOrchestrator(graph, runner)

        async def exec_func(tid):
            if tid == "a":
                raise ValueError("Task A failed!")
            return f"result-{tid}"

        results = await orchestrator.execute(exec_func)

        # Wave 0 has partial failure (a failed, b succeeded)
        assert results[0].success is False
        assert "a" in results[0].errors
        assert "b" in results[0].results


# =============================================================================
# AgentChannel Tests
# =============================================================================


class TestAgentChannelCreate:
    """Tests for channel creation."""

    @pytest.mark.anyio
    async def test_create_channel_returns_receive_stream(self):
        """create_channel should return a MemoryObjectReceiveStream."""
        channel = AgentChannel()
        receive_stream = await channel.create_channel("agent-a", "agent-b")

        assert receive_stream is not None
        await channel.close_all()

    @pytest.mark.anyio
    async def test_has_channel_after_create(self):
        """has_channel should return True after channel creation."""
        channel = AgentChannel()
        await channel.create_channel("agent-a", "agent-b")

        assert channel.has_channel("agent-a", "agent-b") is True
        assert channel.has_channel("agent-b", "agent-a") is False

        await channel.close_all()


class TestAgentChannelSendReceive:
    """Tests for message sending and receiving."""

    @pytest.mark.anyio
    async def test_send_and_receive_message(self):
        """Messages should flow from sender to receiver."""
        channel = AgentChannel()
        receive_stream = await channel.create_channel("agent-a", "agent-b")

        # Send a message
        await channel.send("agent-a", "agent-b", {"type": "test", "data": 42})

        # Receive the message
        message = await receive_stream.receive()

        assert message == {"type": "test", "data": 42}
        await channel.close_all()

    @pytest.mark.anyio
    async def test_multiple_messages_in_order(self):
        """Multiple messages should be received in order."""
        channel = AgentChannel()
        receive_stream = await channel.create_channel("agent-a", "agent-b")

        # Send multiple messages
        for i in range(3):
            await channel.send("agent-a", "agent-b", f"message-{i}")

        # Receive in order
        for i in range(3):
            message = await receive_stream.receive()
            assert message == f"message-{i}"

        await channel.close_all()

    @pytest.mark.anyio
    async def test_send_creates_channel_lazily(self):
        """send() should create channel if it doesn't exist."""
        channel = AgentChannel()

        # Send without creating channel first
        await channel.send("agent-a", "agent-b", "test-message")

        # Channel should now exist
        assert channel.has_channel("agent-a", "agent-b") is True

        await channel.close_all()


class TestAgentChannelClose:
    """Tests for channel closing."""

    @pytest.mark.anyio
    async def test_close_channel_removes_from_active(self):
        """close_channel should remove channel from active list."""
        channel = AgentChannel()
        await channel.create_channel("agent-a", "agent-b")

        assert channel.has_channel("agent-a", "agent-b") is True

        await channel.close_channel("agent-a", "agent-b")

        assert channel.has_channel("agent-a", "agent-b") is False

    @pytest.mark.anyio
    async def test_close_all_removes_all_channels(self):
        """close_all should remove all active channels."""
        channel = AgentChannel()
        await channel.create_channel("agent-a", "agent-b")
        await channel.create_channel("agent-b", "agent-c")

        assert len(channel.get_active_channels()) == 2

        await channel.close_all()

        assert len(channel.get_active_channels()) == 0

    @pytest.mark.anyio
    async def test_close_nonexistent_channel_no_error(self):
        """Closing a non-existent channel should not raise."""
        channel = AgentChannel()

        # Should not raise
        await channel.close_channel("no-such", "channel")


class TestAgentChannelUtilities:
    """Tests for utility methods."""

    @pytest.mark.anyio
    async def test_get_active_channels(self):
        """get_active_channels should return all active channel tuples."""
        channel = AgentChannel()
        await channel.create_channel("a", "b")
        await channel.create_channel("b", "c")

        active = channel.get_active_channels()

        assert len(active) == 2
        assert ("a", "b") in active
        assert ("b", "c") in active

        await channel.close_all()


# =============================================================================
# Integration Tests
# =============================================================================


class TestParallelExecutionIntegration:
    """Integration tests for parallel execution system."""

    @pytest.mark.anyio
    async def test_full_execution_with_communication(self):
        """Test full execution flow with agent communication."""
        # Create dependency graph
        graph = DependencyGraph()
        graph.add_task("analyzer")
        graph.add_task("planner")
        graph.add_task("coder", depends_on=["analyzer", "planner"])

        # Create channel for communication
        channel = AgentChannel()
        await channel.create_channel("analyzer", "coder")
        await channel.create_channel("planner", "coder")

        # Create orchestrator
        runner = WaveRunner()
        orchestrator = HybridOrchestrator(graph, runner)

        # Track messages sent
        sent_messages = []

        async def execute_task(task_id):
            # Simulate work
            await anyio.sleep(0.01)

            # Send message to dependent
            if task_id in ("analyzer", "planner"):
                msg = {"from": task_id, "status": "complete"}
                await channel.send(task_id, "coder", msg)
                sent_messages.append(msg)

            return f"result-{task_id}"

        # Execute
        results = await orchestrator.execute(execute_task)

        # Verify
        assert len(results) == 2  # Two waves
        assert all(wr.success for wr in results)
        assert len(sent_messages) == 2

        await channel.close_all()

    @pytest.mark.anyio
    async def test_three_independent_tasks_parallel(self):
        """Three independent tasks should execute in parallel."""
        runner = WaveRunner()
        start_time = time.time()

        async def exec_func(tid):
            await anyio.sleep(0.1)
            return f"result-{tid}"

        results = await runner.run_wave(["a", "b", "c"], exec_func)
        elapsed = time.time() - start_time

        # All 3 tasks in parallel should take ~0.1s, not 0.3s
        assert elapsed < 0.25
        assert len(results) == 3
        assert all(r.success for r in results)
