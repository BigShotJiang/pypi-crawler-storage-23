"""
Tests for command router functionality.

This module tests the CommandRouter, CommandConfig, and CommandResult
classes for command dispatch and routing.

Requirements: INT-04 (command routing)
"""

import pytest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

from gsd_rlm.commands.router import (
    CommandConfig,
    CommandResult,
    CommandRouter,
    route_command,
    create_router_with_defaults,
)


class TestCommandConfig:
    """Tests for CommandConfig Pydantic model."""

    def test_config_creation(self):
        """Config should be created with all fields."""
        config = CommandConfig(
            command="new-project",
            args={"name": "test"},
            project_dir=Path("."),
            config={"key": "value"},
        )
        assert config.command == "new-project"
        assert config.args == {"name": "test"}
        assert config.project_dir == Path(".")
        assert config.config == {"key": "value"}

    def test_config_defaults(self):
        """Config should have sensible defaults."""
        config = CommandConfig(
            command="test",
            project_dir=Path("."),
        )
        assert config.args == {}
        assert config.config == {}

    def test_config_rejects_empty_command(self):
        """Config should reject empty command."""
        with pytest.raises(Exception):  # ValidationError from Pydantic
            CommandConfig(command="", project_dir=Path("."))

    def test_config_rejects_extra_fields(self):
        """Config should reject unknown fields."""
        with pytest.raises(Exception):  # ValidationError from Pydantic
            CommandConfig(
                command="test",
                project_dir=Path("."),
                unknown_field="value",
            )


class TestCommandResult:
    """Tests for CommandResult dataclass."""

    def test_success_result(self):
        """Success result should be created correctly."""
        result = CommandResult(
            success=True,
            message="Operation completed",
            data={"count": 5},
        )
        assert result.success is True
        assert result.message == "Operation completed"
        assert result.data == {"count": 5}
        assert result.error is None

    def test_failure_result(self):
        """Failure result should be created correctly."""
        result = CommandResult(
            success=False,
            message="Operation failed",
            error="Something went wrong",
        )
        assert result.success is False
        assert result.message == "Operation failed"
        assert result.error == "Something went wrong"
        assert result.data is None

    def test_result_defaults(self):
        """Result should have sensible defaults."""
        result = CommandResult(success=True, message="OK")
        assert result.data is None
        assert result.error is None


class TestCommandRouter:
    """Tests for CommandRouter class."""

    def test_router_initialization(self):
        """Router should initialize with empty handlers."""
        router = CommandRouter()
        assert router.handlers == {}
        assert router.list_commands() == []

    def test_router_with_skills_registry(self):
        """Router should accept optional skills registry."""
        registry = MagicMock()
        router = CommandRouter(skills_registry=registry)
        assert router._skills_registry == registry

    def test_register_handler(self):
        """Handler should be registered correctly."""
        router = CommandRouter()

        async def handler(config: CommandConfig) -> CommandResult:
            return CommandResult(success=True, message="OK")

        router.register("test-command", handler)
        assert "test-command" in router.handlers
        assert router.list_commands() == ["test-command"]

    def test_unregister_handler(self):
        """Handler should be unregistered correctly."""
        router = CommandRouter()

        async def handler(config: CommandConfig) -> CommandResult:
            return CommandResult(success=True, message="OK")

        router.register("test-command", handler)
        assert router.unregister("test-command") is True
        assert router.list_commands() == []

    def test_unregister_nonexistent(self):
        """Unregistering nonexistent handler should return False."""
        router = CommandRouter()
        assert router.unregister("nonexistent") is False

    def test_has_handler(self):
        """has_handler should check handler existence."""
        router = CommandRouter()

        async def handler(config: CommandConfig) -> CommandResult:
            return CommandResult(success=True, message="OK")

        assert router.has_handler("test-command") is False
        router.register("test-command", handler)
        assert router.has_handler("test-command") is True

    @pytest.mark.asyncio
    async def test_route_to_handler(self):
        """Route should dispatch to correct handler."""
        router = CommandRouter()

        async def handler(config: CommandConfig) -> CommandResult:
            return CommandResult(
                success=True,
                message=f"Handled {config.args.get('value', 'none')}",
            )

        router.register("test-command", handler)

        config = CommandConfig(
            command="test-command",
            args={"value": "test-value"},
            project_dir=Path("."),
        )

        result = await router.route(config)
        assert result.success is True
        assert "test-value" in result.message

    @pytest.mark.asyncio
    async def test_route_unknown_command(self):
        """Routing unknown command should return error result."""
        router = CommandRouter()

        config = CommandConfig(
            command="unknown-command",
            args={},
            project_dir=Path("."),
        )

        result = await router.route(config)
        assert result.success is False
        assert "Unknown command" in result.message
        assert result.error is not None

    @pytest.mark.asyncio
    async def test_route_handler_exception(self):
        """Handler exception should be caught and returned as error."""
        router = CommandRouter()

        async def failing_handler(config: CommandConfig) -> CommandResult:
            raise ValueError("Handler error")

        router.register("failing-command", failing_handler)

        config = CommandConfig(
            command="failing-command",
            args={},
            project_dir=Path("."),
        )

        result = await router.route(config)
        assert result.success is False
        assert "Handler error" in result.error

    @pytest.mark.asyncio
    async def test_list_commands(self):
        """list_commands should return all registered commands."""
        router = CommandRouter()

        async def handler1(config: CommandConfig) -> CommandResult:
            return CommandResult(success=True, message="OK")

        async def handler2(config: CommandConfig) -> CommandResult:
            return CommandResult(success=True, message="OK")

        router.register("command-1", handler1)
        router.register("command-2", handler2)

        commands = router.list_commands()
        assert "command-1" in commands
        assert "command-2" in commands
        assert len(commands) == 2


class TestRouteCommand:
    """Tests for route_command convenience function."""

    @pytest.mark.asyncio
    async def test_route_command_convenience(self):
        """route_command should work as convenience function."""
        # This test uses the real handlers, so we mock them
        from unittest.mock import patch

        with patch("gsd_rlm.commands.handlers.register_default_handlers") as mock_reg:
            mock_router = MagicMock()
            mock_router.route = AsyncMock(
                return_value=CommandResult(success=True, message="OK")
            )

            with patch(
                "gsd_rlm.commands.router.CommandRouter", return_value=mock_router
            ):
                result = await route_command(
                    command="test",
                    args={},
                    project_dir=Path("."),
                )

                # Verify route was called
                mock_router.route.assert_called_once()


class TestCreateRouterWithDefaults:
    """Tests for create_router_with_defaults function."""

    def test_create_router_with_defaults(self):
        """Router should be created with default handlers."""
        from unittest.mock import patch

        with patch("gsd_rlm.commands.handlers.register_default_handlers") as mock_reg:
            router = create_router_with_defaults()
            mock_reg.assert_called_once_with(router)


class TestIntegration:
    """Integration tests for command router."""

    @pytest.mark.asyncio
    async def test_full_routing_flow(self):
        """Test complete routing flow with custom handler."""
        router = CommandRouter()

        call_log = []

        async def new_project_handler(config: CommandConfig) -> CommandResult:
            call_log.append(("new-project", config.args))
            project_dir = config.project_dir
            name = config.args.get("name", "unnamed")
            return CommandResult(
                success=True,
                message=f"Created project '{name}' at {project_dir}",
                data={"name": name, "path": str(project_dir)},
            )

        async def plan_handler(config: CommandConfig) -> CommandResult:
            call_log.append(("plan-phase", config.args))
            phase = config.args.get("phase", "1")
            return CommandResult(
                success=True,
                message=f"Created plan for phase {phase}",
                data={"phase": phase},
            )

        router.register("new-project", new_project_handler)
        router.register("plan-phase", plan_handler)

        # Route first command
        result1 = await router.route(
            CommandConfig(
                command="new-project",
                args={"name": "test-project"},
                project_dir=Path("/tmp/test"),
            )
        )
        assert result1.success is True
        assert "test-project" in result1.message

        # Route second command
        result2 = await router.route(
            CommandConfig(
                command="plan-phase",
                args={"phase": "2"},
                project_dir=Path("/tmp/test"),
            )
        )
        assert result2.success is True
        assert "phase 2" in result2.message

        # Verify both handlers were called
        assert len(call_log) == 2
        assert call_log[0] == ("new-project", {"name": "test-project"})
        assert call_log[1] == ("plan-phase", {"phase": "2"})
