"""
Tests for LLM provider routing functionality.

This module tests the provider routing logic for task-type-based
provider selection with fallback support.

Requirements: INT-08 (provider routing)
"""

import pytest
from unittest.mock import patch, MagicMock

from gsd_rlm.commands.provider_router import (
    TASK_PROVIDER_MAP,
    route_to_provider,
    validate_provider,
    get_provider_config,
    get_fallback_provider,
    list_available_providers,
    get_task_provider_map,
)


class TestRouteToProvider:
    """Tests for route_to_provider function."""

    def test_route_planning_task(self):
        """Planning tasks should route to claude."""
        provider = route_to_provider("planning")
        assert provider == "claude"

    def test_route_execution_task(self):
        """Execution tasks should route to ollama."""
        provider = route_to_provider("execution")
        assert provider == "ollama"

    def test_route_verification_task(self):
        """Verification tasks should route to sonnet."""
        provider = route_to_provider("verification")
        assert provider == "sonnet"

    def test_route_research_task(self):
        """Research tasks should route to sonnet."""
        provider = route_to_provider("research")
        assert provider == "sonnet"

    def test_route_unknown_task_default(self):
        """Unknown tasks should use default provider."""
        provider = route_to_provider("unknown_task")
        assert provider == "ollama"  # Default primary

    def test_route_with_config_default_override(self):
        """Config should override default provider."""
        provider = route_to_provider(
            "unknown_task",
            {"default_provider": "sonnet"},
        )
        assert provider == "sonnet"

    def test_route_with_provider_override(self):
        """Provider overrides should take precedence."""
        provider = route_to_provider(
            "planning",
            {"provider_overrides": {"planning": "ollama"}},
        )
        assert provider == "ollama"

    def test_route_all_known_task_types(self):
        """All known task types should have defined providers."""
        for task_type in TASK_PROVIDER_MAP:
            provider = route_to_provider(task_type)
            assert provider is not None
            assert isinstance(provider, str)


class TestValidateProvider:
    """Tests for validate_provider function."""

    def test_validate_unknown_provider(self):
        """Unknown provider should return False."""
        result = validate_provider("nonexistent_provider")
        assert result is False

    def test_validate_case_insensitive(self):
        """Provider validation should be case insensitive."""
        # Both should work the same
        with patch("importlib.import_module") as mock_import:
            mock_import.return_value = MagicMock()
            result1 = validate_provider("OLLAMA")
            result2 = validate_provider("ollama")
            assert result1 == result2


class TestGetProviderConfig:
    """Tests for get_provider_config function."""

    def test_ollama_config(self):
        """Ollama config should have expected defaults."""
        config = get_provider_config("ollama")
        assert config["model"] == "llama3.2"
        assert config["base_url"] == "http://localhost:11434"
        assert config["provider"] == "ollama"

    def test_claude_config(self):
        """Claude config should have expected defaults."""
        config = get_provider_config("claude")
        assert "claude" in config["model"].lower()
        assert config["provider"] == "claude"

    def test_sonnet_config(self):
        """Sonnet config should use Claude model."""
        config = get_provider_config("sonnet")
        assert "sonnet" in config["model"].lower()
        assert config["provider"] == "sonnet"

    def test_config_merge(self):
        """Provided config should merge with defaults."""
        config = get_provider_config(
            "ollama",
            {"base_url": "http://custom:11434", "custom_key": "value"},
        )
        assert config["base_url"] == "http://custom:11434"
        assert config["custom_key"] == "value"
        assert config["model"] == "llama3.2"  # Default preserved

    def test_unknown_provider_config(self):
        """Unknown provider should return minimal config."""
        config = get_provider_config("unknown")
        assert config["provider"] == "unknown"

    def test_config_case_insensitive(self):
        """Config should be case insensitive for provider."""
        config1 = get_provider_config("OLLAMA")
        config2 = get_provider_config("ollama")
        assert config1["model"] == config2["model"]


class TestGetFallbackProvider:
    """Tests for get_fallback_provider function."""

    def test_fallback_from_ollama(self):
        """Fallback from ollama should return sonnet or claude."""
        with patch(
            "gsd_rlm.commands.provider_router.validate_provider"
        ) as mock_validate:
            mock_validate.return_value = True
            fallback = get_fallback_provider("execution", "ollama")
            assert fallback in ["sonnet", "claude"]

    def test_fallback_from_claude(self):
        """Fallback from claude should return sonnet or ollama."""
        with patch(
            "gsd_rlm.commands.provider_router.validate_provider"
        ) as mock_validate:
            mock_validate.return_value = True
            fallback = get_fallback_provider("planning", "claude")
            assert fallback in ["sonnet", "ollama"]

    def test_fallback_no_available(self):
        """Should return None if no fallback available."""
        with patch(
            "gsd_rlm.commands.provider_router.validate_provider"
        ) as mock_validate:
            mock_validate.return_value = False
            fallback = get_fallback_provider("execution", "ollama")
            assert fallback is None


class TestListAvailableProviders:
    """Tests for list_available_providers function."""

    def test_list_providers(self):
        """Should return list of providers."""
        with patch(
            "gsd_rlm.commands.provider_router.validate_provider"
        ) as mock_validate:
            mock_validate.side_effect = lambda p: p in ["ollama", "claude"]
            providers = list_available_providers()
            assert "ollama" in providers
            assert "claude" in providers

    def test_list_empty_if_none_available(self):
        """Should return empty list if no providers available."""
        with patch(
            "gsd_rlm.commands.provider_router.validate_provider"
        ) as mock_validate:
            mock_validate.return_value = False
            providers = list_available_providers()
            assert providers == []


class TestGetTaskProviderMap:
    """Tests for get_task_provider_map function."""

    def test_returns_copy(self):
        """Should return a copy of the mapping."""
        mapping = get_task_provider_map()
        assert isinstance(mapping, dict)
        # Modify should not affect original
        mapping["test"] = "test_provider"
        assert "test" not in TASK_PROVIDER_MAP

    def test_contains_expected_types(self):
        """Should contain expected task types."""
        mapping = get_task_provider_map()
        assert "planning" in mapping
        assert "execution" in mapping
        assert "verification" in mapping
        assert "research" in mapping


class TestIntegration:
    """Integration tests for provider routing."""

    def test_full_routing_flow(self):
        """Test complete routing flow from task to config."""
        # Route task
        provider = route_to_provider("planning")
        assert provider == "claude"

        # Get config
        config = get_provider_config(provider)
        assert config["provider"] == "claude"
        assert "model" in config

    def test_routing_with_fallback(self):
        """Test routing with fallback chain."""
        with patch(
            "gsd_rlm.commands.provider_router.validate_provider"
        ) as mock_validate:
            # First provider fails, fallback succeeds
            mock_validate.side_effect = lambda p: p == "sonnet"

            primary = route_to_provider("execution")
            assert primary == "ollama"

            # Simulate failure and get fallback
            fallback = get_fallback_provider("execution", primary)
            assert fallback == "sonnet"

    def test_custom_config_flow(self):
        """Test custom configuration flow."""
        custom_config = {
            "default_provider": "sonnet",
            "provider_overrides": {
                "testing": "ollama",
            },
        }

        # Custom override
        provider = route_to_provider("testing", custom_config)
        assert provider == "ollama"

        # Default fallback
        provider = route_to_provider("unknown_type", custom_config)
        assert provider == "sonnet"
