"""
Tests for command handlers functionality.

This module tests the new_project, plan_phase, and execute_phase
command handlers.

Requirements: INT-04 (command handlers), INT-05 (orchestrator integration)
"""

import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
import tempfile

from gsd_rlm.commands.router import CommandConfig, CommandResult
from gsd_rlm.commands.handlers.new_project import new_project_command
from gsd_rlm.commands.handlers.plan_phase import (
    plan_phase_command,
    _parse_roadmap_phases,
    _name_to_slug,
)
from gsd_rlm.commands.handlers.execute_phase import (
    execute_phase_command,
    _discover_plans,
    _parse_dependencies,
    _build_dependency_graph,
)


class TestNewProjectCommand:
    """Tests for new_project_command handler."""

    @pytest.mark.asyncio
    async def test_create_project_structure(self):
        """Handler should create .planning/ directory structure."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CommandConfig(
                command="new-project",
                args={"name": "Test Project", "vision": "Test vision"},
                project_dir=Path(tmpdir),
            )

            result = await new_project_command(config)

            assert result.success is True
            assert "Test Project" in result.message

            # Check files created
            planning_dir = Path(tmpdir) / ".planning"
            assert planning_dir.exists()
            assert (planning_dir / "PROJECT.md").exists()
            assert (planning_dir / "ROADMAP.md").exists()
            assert (planning_dir / "STATE.md").exists()
            assert (planning_dir / "phases").exists()

    @pytest.mark.asyncio
    async def test_create_project_with_goals(self):
        """Handler should include goals in PROJECT.md."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CommandConfig(
                command="new-project",
                args={
                    "name": "Test",
                    "goals": ["Goal A", "Goal B", "Goal C"],
                },
                project_dir=Path(tmpdir),
            )

            result = await new_project_command(config)

            assert result.success is True
            project_md = (Path(tmpdir) / ".planning" / "PROJECT.md").read_text()
            assert "Goal A" in project_md
            assert "Goal B" in project_md
            assert "Goal C" in project_md

    @pytest.mark.asyncio
    async def test_create_project_default_name(self):
        """Handler should use default name if not provided."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CommandConfig(
                command="new-project",
                args={},
                project_dir=Path(tmpdir),
            )

            result = await new_project_command(config)

            assert result.success is True
            assert "Untitled Project" in result.message


class TestPlanPhaseCommand:
    """Tests for plan_phase_command handler."""

    def test_name_to_slug(self):
        """_name_to_slug should convert names to URL-safe slugs."""
        assert _name_to_slug("Foundation") == "foundation"
        assert _name_to_slug("Core Workflow") == "core-workflow"
        assert _name_to_slug("Test & Deploy!") == "test-deploy"

    def test_parse_roadmap_phases(self):
        """_parse_roadmap_phases should extract phase info."""
        roadmap = """
# Roadmap

### Phase 1: Foundation

**Objective:** Set up core infrastructure

### Phase 2: Development

**Objective:** Build features
"""
        phases = _parse_roadmap_phases(roadmap)
        assert len(phases) == 2
        assert phases[0]["number"] == 1
        assert phases[0]["name"] == "Foundation"
        assert phases[1]["number"] == 2
        assert phases[1]["name"] == "Development"

    @pytest.mark.asyncio
    async def test_plan_phase_no_roadmap(self):
        """Handler should fail if ROADMAP.md not found."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = CommandConfig(
                command="plan-phase",
                args={"phase": 1},
                project_dir=Path(tmpdir),
            )

            result = await plan_phase_command(config)

            assert result.success is False
            assert "ROADMAP.md not found" in result.message

    @pytest.mark.asyncio
    async def test_plan_phase_creates_plans(self):
        """Handler should create PLAN.md files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create .planning structure
            planning_dir = Path(tmpdir) / ".planning"
            planning_dir.mkdir()
            phases_dir = planning_dir / "phases"
            phases_dir.mkdir()

            # Create ROADMAP.md
            roadmap = planning_dir / "ROADMAP.md"
            roadmap.write_text("""
# Roadmap

### Phase 1: Test Phase

**Objective:** Test objective
""")

            config = CommandConfig(
                command="plan-phase",
                args={"phase": 1, "plan_count": 2},
                project_dir=Path(tmpdir),
            )

            result = await plan_phase_command(config)

            assert result.success is True
            assert result.data["plans_created"] == 2

            # Check plans exist
            phase_dir = phases_dir / "01-test-phase"
            assert (phase_dir / "01-01-PLAN.md").exists()
            assert (phase_dir / "01-02-PLAN.md").exists()

    @pytest.mark.asyncio
    async def test_plan_phase_invalid_phase(self):
        """Handler should fail for invalid phase number."""
        with tempfile.TemporaryDirectory() as tmpdir:
            planning_dir = Path(tmpdir) / ".planning"
            planning_dir.mkdir()

            roadmap = planning_dir / "ROADMAP.md"
            roadmap.write_text("""
### Phase 1: Only Phase
**Objective:** Test
""")

            config = CommandConfig(
                command="plan-phase",
                args={"phase": 99},
                project_dir=Path(tmpdir),
            )

            result = await plan_phase_command(config)

            assert result.success is False
            assert "not found" in result.message


class TestExecutePhaseCommand:
    """Tests for execute_phase_command handler."""

    def test_parse_dependencies(self):
        """_parse_dependencies should extract depends_on."""
        content = """---
phase: 01-test
plan: 02
depends_on:
  - 01-01
  - 01-00
---
"""
        deps = _parse_dependencies(content)
        assert deps == ["01-01", "01-00"]

    def test_parse_dependencies_empty(self):
        """_parse_dependencies should return empty list if no deps."""
        content = """---
phase: 01-test
plan: 01
---
"""
        deps = _parse_dependencies(content)
        assert deps == []

    def test_discover_plans(self):
        """_discover_plans should find PLAN.md files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            phase_dir = Path(tmpdir)
            (phase_dir / "01-01-PLAN.md").write_text("---\nplan: 01\n---")
            (phase_dir / "01-02-PLAN.md").write_text("---\nplan: 02\n---")
            (phase_dir / "01-02-SUMMARY.md").write_text("# Summary")

            plans = _discover_plans(phase_dir)

            assert len(plans) == 2
            assert plans[0]["id"] == "01-01"
            assert plans[1]["id"] == "01-02"

    def test_discover_plans_empty(self):
        """_discover_plans should return empty list if no plans."""
        with tempfile.TemporaryDirectory() as tmpdir:
            plans = _discover_plans(Path(tmpdir))
            assert plans == []

    def test_build_dependency_graph(self):
        """_build_dependency_graph should create valid graph."""
        plans = [
            {"id": "01-01", "depends_on": []},
            {"id": "01-02", "depends_on": ["01-01"]},
            {"id": "01-03", "depends_on": ["01-01", "01-02"]},
        ]

        graph = _build_dependency_graph(plans)
        waves = graph.get_waves()

        assert len(waves) == 3
        assert waves[0] == ["01-01"]
        assert waves[1] == ["01-02"]
        assert waves[2] == ["01-03"]

    @pytest.mark.asyncio
    async def test_execute_phase_no_phase_dir(self):
        """Handler should fail if phase directory not found."""
        with tempfile.TemporaryDirectory() as tmpdir:
            planning_dir = Path(tmpdir) / ".planning"
            planning_dir.mkdir()
            (planning_dir / "phases").mkdir()

            config = CommandConfig(
                command="execute-phase",
                args={"phase": 99},
                project_dir=Path(tmpdir),
            )

            result = await execute_phase_command(config)

            assert result.success is False
            assert "not found" in result.message

    @pytest.mark.asyncio
    async def test_execute_phase_no_plans(self):
        """Handler should fail if no plans found."""
        with tempfile.TemporaryDirectory() as tmpdir:
            planning_dir = Path(tmpdir) / ".planning"
            planning_dir.mkdir()
            phases_dir = planning_dir / "phases"
            phase_dir = phases_dir / "01-empty-phase"
            phase_dir.mkdir(parents=True)

            config = CommandConfig(
                command="execute-phase",
                args={"phase": 1},
                project_dir=Path(tmpdir),
            )

            result = await execute_phase_command(config)

            assert result.success is False
            assert "No plans found" in result.message

    @pytest.mark.asyncio
    async def test_execute_phase_success(self):
        """Handler should execute plans and return results."""
        with tempfile.TemporaryDirectory() as tmpdir:
            planning_dir = Path(tmpdir) / ".planning"
            planning_dir.mkdir()
            phases_dir = planning_dir / "phases"
            phase_dir = phases_dir / "01-test-phase"
            phase_dir.mkdir(parents=True)

            # Create plans
            (phase_dir / "01-01-PLAN.md").write_text("---\nplan: 01\n---")
            (phase_dir / "01-02-PLAN.md").write_text(
                "---\nplan: 02\ndepends_on:\n  - 01-01\n---"
            )

            config = CommandConfig(
                command="execute-phase",
                args={"phase": 1, "max_concurrent": 5},
                project_dir=Path(tmpdir),
            )

            result = await execute_phase_command(config)

            assert result.success is True
            assert result.data["total_plans"] == 2
            assert result.data["plans_succeeded"] == 2
            assert result.data["waves_executed"] == 2


class TestHandlerIntegration:
    """Integration tests for command handlers."""

    @pytest.mark.asyncio
    async def test_full_workflow(self):
        """Test complete workflow: new-project -> plan-phase -> execute-phase."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir)

            # Step 1: Create project
            config1 = CommandConfig(
                command="new-project",
                args={"name": "Integration Test"},
                project_dir=project_dir,
            )
            result1 = await new_project_command(config1)
            assert result1.success is True

            # Step 2: Update ROADMAP with a phase
            planning_dir = project_dir / ".planning"
            roadmap = planning_dir / "ROADMAP.md"
            roadmap.write_text("""
# Roadmap

### Phase 1: Integration

**Objective:** Test integration

### Phase 2: Final

**Objective:** Final phase
""")

            # Step 3: Plan phase
            config2 = CommandConfig(
                command="plan-phase",
                args={"phase": 1, "plan_count": 1},
                project_dir=project_dir,
            )
            result2 = await plan_phase_command(config2)
            assert result2.success is True
            assert result2.data["plans_created"] == 1

            # Step 4: Execute phase
            config3 = CommandConfig(
                command="execute-phase",
                args={"phase": 1},
                project_dir=project_dir,
            )
            result3 = await execute_phase_command(config3)
            assert result3.success is True
            assert result3.data["plans_succeeded"] == 1
