"""Tests for command routing and handlers."""
