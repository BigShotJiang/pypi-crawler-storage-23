"""Tests for checkpoint system."""
