"""
Tests for checkpoint types and dataclass.
"""

import pytest
from gsd_rlm.checkpoints.types import Checkpoint, CheckpointType


class TestCheckpointType:
    """Tests for CheckpointType enum."""

    def test_human_verify_value(self):
        """HUMAN_VERIFY has correct string value."""
        assert CheckpointType.HUMAN_VERIFY == "human-verify"

    def test_decision_value(self):
        """DECISION has correct string value."""
        assert CheckpointType.DECISION == "decision"

    def test_human_action_value(self):
        """HUMAN_ACTION has correct string value."""
        assert CheckpointType.HUMAN_ACTION == "human-action"

    def test_all_types_defined(self):
        """All three checkpoint types are defined."""
        types = list(CheckpointType)
        assert len(types) == 3
        assert CheckpointType.HUMAN_VERIFY in types
        assert CheckpointType.DECISION in types
        assert CheckpointType.HUMAN_ACTION in types


class TestCheckpointHumanVerify:
    """Tests for HUMAN_VERIFY checkpoint type."""

    def test_create_human_verify_checkpoint(self):
        """Can create a valid HUMAN_VERIFY checkpoint."""
        checkpoint = Checkpoint(
            type=CheckpointType.HUMAN_VERIFY,
            gate="blocking",
            checkpoint_id="cp-001",
            session_id="session-123",
            what_built="Created login form with email and password fields",
            how_to_verify="Visit /login and test with valid and invalid credentials",
        )
        assert checkpoint.type == CheckpointType.HUMAN_VERIFY
        assert checkpoint.gate == "blocking"
        assert (
            checkpoint.what_built == "Created login form with email and password fields"
        )

    def test_human_verify_requires_what_built(self):
        """HUMAN_VERIFY checkpoint requires what_built."""
        with pytest.raises(ValueError, match="what_built"):
            Checkpoint(
                type=CheckpointType.HUMAN_VERIFY,
                gate="blocking",
                checkpoint_id="cp-001",
                session_id="session-123",
                how_to_verify="Check the UI",
            )

    def test_human_verify_requires_how_to_verify(self):
        """HUMAN_VERIFY checkpoint requires how_to_verify."""
        with pytest.raises(ValueError, match="how_to_verify"):
            Checkpoint(
                type=CheckpointType.HUMAN_VERIFY,
                gate="blocking",
                checkpoint_id="cp-001",
                session_id="session-123",
                what_built="Built feature X",
            )

    def test_human_verify_format_display(self):
        """HUMAN_VERIFY checkpoint formats correctly for display."""
        checkpoint = Checkpoint(
            type=CheckpointType.HUMAN_VERIFY,
            gate="blocking",
            checkpoint_id="cp-001",
            session_id="session-123",
            what_built="Login form",
            how_to_verify="Visit /login",
        )
        display = checkpoint.format_display()
        assert "## CHECKPOINT REACHED" in display
        assert "**Type:** human-verify" in display
        assert "### What Was Built" in display
        assert "Login form" in display
        assert "### How to Verify" in display
        assert "Visit /login" in display


class TestCheckpointDecision:
    """Tests for DECISION checkpoint type."""

    def test_create_decision_checkpoint(self):
        """Can create a valid DECISION checkpoint."""
        checkpoint = Checkpoint(
            type=CheckpointType.DECISION,
            gate="blocking",
            checkpoint_id="cp-002",
            session_id="session-123",
            decision="Which database to use?",
            context="Need to choose between PostgreSQL and MongoDB",
            options=[
                {
                    "name": "PostgreSQL",
                    "pros": "ACID, mature",
                    "cons": "Schema rigidity",
                },
                {"name": "MongoDB", "pros": "Flexible schema", "cons": "No ACID"},
            ],
        )
        assert checkpoint.type == CheckpointType.DECISION
        assert checkpoint.decision == "Which database to use?"
        assert len(checkpoint.options) == 2

    def test_decision_requires_decision_field(self):
        """DECISION checkpoint requires decision field."""
        with pytest.raises(ValueError, match="decision"):
            Checkpoint(
                type=CheckpointType.DECISION,
                gate="blocking",
                checkpoint_id="cp-002",
                session_id="session-123",
                options=[{"name": "Option A"}],
            )

    def test_decision_requires_options(self):
        """DECISION checkpoint requires options."""
        with pytest.raises(ValueError, match="options"):
            Checkpoint(
                type=CheckpointType.DECISION,
                gate="blocking",
                checkpoint_id="cp-002",
                session_id="session-123",
                decision="Pick one",
            )

    def test_decision_format_display(self):
        """DECISION checkpoint formats correctly for display."""
        checkpoint = Checkpoint(
            type=CheckpointType.DECISION,
            gate="blocking",
            checkpoint_id="cp-002",
            session_id="session-123",
            decision="Database choice",
            context="Scalability matters",
            options=[
                {"name": "PostgreSQL", "pros": "ACID", "cons": "Schema"},
            ],
        )
        display = checkpoint.format_display()
        assert "### Decision Required" in display
        assert "Database choice" in display
        assert "### Context" in display
        assert "### Options" in display
        assert "PostgreSQL" in display


class TestCheckpointHumanAction:
    """Tests for HUMAN_ACTION checkpoint type."""

    def test_create_human_action_checkpoint(self):
        """Can create a valid HUMAN_ACTION checkpoint."""
        checkpoint = Checkpoint(
            type=CheckpointType.HUMAN_ACTION,
            gate="blocking",
            checkpoint_id="cp-003",
            session_id="session-123",
            action="Click verification link in email",
            instructions="Check your inbox for verification email and click the link",
            verification="Run 'auth status' to confirm verification",
        )
        assert checkpoint.type == CheckpointType.HUMAN_ACTION
        assert checkpoint.action == "Click verification link in email"
        assert checkpoint.verification == "Run 'auth status' to confirm verification"

    def test_human_action_requires_action(self):
        """HUMAN_ACTION checkpoint requires action."""
        with pytest.raises(ValueError, match="action"):
            Checkpoint(
                type=CheckpointType.HUMAN_ACTION,
                gate="blocking",
                checkpoint_id="cp-003",
                session_id="session-123",
                instructions="Do something",
            )

    def test_human_action_requires_instructions(self):
        """HUMAN_ACTION checkpoint requires instructions."""
        with pytest.raises(ValueError, match="instructions"):
            Checkpoint(
                type=CheckpointType.HUMAN_ACTION,
                gate="blocking",
                checkpoint_id="cp-003",
                session_id="session-123",
                action="Do something",
            )

    def test_human_action_format_display(self):
        """HUMAN_ACTION checkpoint formats correctly for display."""
        checkpoint = Checkpoint(
            type=CheckpointType.HUMAN_ACTION,
            gate="blocking",
            checkpoint_id="cp-003",
            session_id="session-123",
            action="Verify email",
            instructions="Click link in email",
            verification="Check status",
        )
        display = checkpoint.format_display()
        assert "### Action Required" in display
        assert "Verify email" in display
        assert "### Instructions" in display
        assert "Click link in email" in display
        assert "### How to Verify Completion" in display


class TestCheckpointGate:
    """Tests for checkpoint gate validation."""

    def test_valid_blocking_gate(self):
        """Blocking gate is valid."""
        checkpoint = Checkpoint(
            type=CheckpointType.HUMAN_VERIFY,
            gate="blocking",
            checkpoint_id="cp-001",
            session_id="session-123",
            what_built="Feature",
            how_to_verify="Test it",
        )
        assert checkpoint.gate == "blocking"

    def test_valid_non_blocking_gate(self):
        """Non-blocking gate is valid."""
        checkpoint = Checkpoint(
            type=CheckpointType.HUMAN_VERIFY,
            gate="non-blocking",
            checkpoint_id="cp-001",
            session_id="session-123",
            what_built="Feature",
            how_to_verify="Test it",
        )
        assert checkpoint.gate == "non-blocking"

    def test_invalid_gate_raises_error(self):
        """Invalid gate raises ValueError."""
        with pytest.raises(ValueError, match="Invalid gate"):
            Checkpoint(
                type=CheckpointType.HUMAN_VERIFY,
                gate="invalid",
                checkpoint_id="cp-001",
                session_id="session-123",
                what_built="Feature",
                how_to_verify="Test it",
            )


class TestCheckpointSerialization:
    """Tests for checkpoint serialization and deserialization."""

    def test_to_dict_human_verify(self):
        """HUMAN_VERIFY checkpoint serializes to dict correctly."""
        checkpoint = Checkpoint(
            type=CheckpointType.HUMAN_VERIFY,
            gate="blocking",
            checkpoint_id="cp-001",
            session_id="session-123",
            what_built="Feature",
            how_to_verify="Test it",
            timeout_seconds=300,
        )
        data = checkpoint.to_dict()
        assert data["type"] == "human-verify"
        assert data["gate"] == "blocking"
        assert data["checkpoint_id"] == "cp-001"
        assert data["session_id"] == "session-123"
        assert data["what_built"] == "Feature"
        assert data["how_to_verify"] == "Test it"
        assert data["timeout_seconds"] == 300

    def test_to_dict_decision(self):
        """DECISION checkpoint serializes to dict correctly."""
        checkpoint = Checkpoint(
            type=CheckpointType.DECISION,
            gate="blocking",
            checkpoint_id="cp-002",
            session_id="session-123",
            decision="Pick database",
            context="Need ACID",
            options=[{"name": "PostgreSQL"}],
        )
        data = checkpoint.to_dict()
        assert data["type"] == "decision"
        assert data["decision"] == "Pick database"
        assert data["context"] == "Need ACID"
        assert data["options"] == [{"name": "PostgreSQL"}]

    def test_from_dict_human_verify(self):
        """HUMAN_VERIFY checkpoint deserializes from dict correctly."""
        data = {
            "type": "human-verify",
            "gate": "blocking",
            "checkpoint_id": "cp-001",
            "session_id": "session-123",
            "what_built": "Feature",
            "how_to_verify": "Test it",
            "resume_signal": "Approve?",
            "timeout_seconds": 300,
        }
        checkpoint = Checkpoint.from_dict(data)
        assert checkpoint.type == CheckpointType.HUMAN_VERIFY
        assert checkpoint.gate == "blocking"
        assert checkpoint.checkpoint_id == "cp-001"
        assert checkpoint.what_built == "Feature"
        assert checkpoint.resume_signal == "Approve?"
        assert checkpoint.timeout_seconds == 300

    def test_from_dict_decision(self):
        """DECISION checkpoint deserializes from dict correctly."""
        data = {
            "type": "decision",
            "gate": "blocking",
            "checkpoint_id": "cp-002",
            "session_id": "session-123",
            "decision": "Pick database",
            "context": "Need ACID",
            "options": [{"name": "PostgreSQL"}],
        }
        checkpoint = Checkpoint.from_dict(data)
        assert checkpoint.type == CheckpointType.DECISION
        assert checkpoint.decision == "Pick database"
        assert checkpoint.options == [{"name": "PostgreSQL"}]

    def test_from_dict_human_action(self):
        """HUMAN_ACTION checkpoint deserializes from dict correctly."""
        data = {
            "type": "human-action",
            "gate": "blocking",
            "checkpoint_id": "cp-003",
            "session_id": "session-123",
            "action": "Click link",
            "instructions": "Check email",
            "verification": "Run status",
        }
        checkpoint = Checkpoint.from_dict(data)
        assert checkpoint.type == CheckpointType.HUMAN_ACTION
        assert checkpoint.action == "Click link"
        assert checkpoint.instructions == "Check email"
        assert checkpoint.verification == "Run status"

    def test_roundtrip_serialization(self):
        """Checkpoint can roundtrip through dict serialization."""
        original = Checkpoint(
            type=CheckpointType.HUMAN_VERIFY,
            gate="blocking",
            checkpoint_id="cp-001",
            session_id="session-123",
            what_built="Feature X",
            how_to_verify="Test Y",
            resume_signal="Type yes to continue",
            timeout_seconds=600,
        )
        data = original.to_dict()
        restored = Checkpoint.from_dict(data)
        assert restored.type == original.type
        assert restored.gate == original.gate
        assert restored.checkpoint_id == original.checkpoint_id
        assert restored.session_id == original.session_id
        assert restored.what_built == original.what_built
        assert restored.how_to_verify == original.how_to_verify
        assert restored.resume_signal == original.resume_signal
        assert restored.timeout_seconds == original.timeout_seconds

    def test_from_dict_default_resume_signal(self):
        """from_dict uses default resume_signal if not provided."""
        data = {
            "type": "human-verify",
            "gate": "blocking",
            "checkpoint_id": "cp-001",
            "session_id": "session-123",
            "what_built": "Feature",
            "how_to_verify": "Test it",
        }
        checkpoint = Checkpoint.from_dict(data)
        assert checkpoint.resume_signal == "Type 'approved' or describe issues"


class TestCheckpointDefaultFields:
    """Tests for default field values."""

    def test_default_resume_signal(self):
        """Default resume_signal is set correctly."""
        checkpoint = Checkpoint(
            type=CheckpointType.HUMAN_VERIFY,
            gate="blocking",
            checkpoint_id="cp-001",
            session_id="session-123",
            what_built="Feature",
            how_to_verify="Test it",
        )
        assert checkpoint.resume_signal == "Type 'approved' or describe issues"

    def test_default_timeout_is_none(self):
        """Default timeout_seconds is None."""
        checkpoint = Checkpoint(
            type=CheckpointType.HUMAN_VERIFY,
            gate="blocking",
            checkpoint_id="cp-001",
            session_id="session-123",
            what_built="Feature",
            how_to_verify="Test it",
        )
        assert checkpoint.timeout_seconds is None

    def test_custom_timeout(self):
        """Can set custom timeout."""
        checkpoint = Checkpoint(
            type=CheckpointType.HUMAN_VERIFY,
            gate="blocking",
            checkpoint_id="cp-001",
            session_id="session-123",
            what_built="Feature",
            how_to_verify="Test it",
            timeout_seconds=120,
        )
        assert checkpoint.timeout_seconds == 120
