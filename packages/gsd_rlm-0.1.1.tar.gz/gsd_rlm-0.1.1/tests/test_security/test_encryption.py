"""
Comprehensive tests for AES-256-GCM encryption (SEC-01).

Tests cover:
- MemoryEncryptor key generation
- Encrypt/decrypt roundtrip
- Unique IV generation per encryption
- Associated data binding
- Tamper detection (integrity)
- Wrong key detection
- EncryptedData dataclass
"""

import os

import cryptography.exceptions
import pytest

from gsd_rlm.security import MemoryEncryptor, EncryptedData


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def encryptor() -> MemoryEncryptor:
    """Provide a fresh MemoryEncryptor for testing."""
    return MemoryEncryptor()


@pytest.fixture
def encryptor_with_known_key() -> tuple[MemoryEncryptor, bytes]:
    """Provide an encryptor with a known key for reproducibility tests."""
    key = os.urandom(32)
    return MemoryEncryptor(key), key


# =============================================================================
# MemoryEncryptor Key Generation Tests
# =============================================================================


class TestMemoryEncryptorKeyGeneration:
    """Tests for key generation."""

    def test_memory_encryptor_generate_key(self):
        """generate_key should return 32 bytes (256 bits)."""
        key = MemoryEncryptor.generate_key()

        assert len(key) == 32
        assert isinstance(key, bytes)

    def test_memory_encryptor_generate_key_randomness(self):
        """generate_key should produce different keys each time."""
        key1 = MemoryEncryptor.generate_key()
        key2 = MemoryEncryptor.generate_key()

        assert key1 != key2

    def test_memory_encryptor_auto_key(self):
        """MemoryEncryptor should auto-generate key if not provided."""
        encryptor = MemoryEncryptor()

        assert encryptor.key is not None
        assert len(encryptor.key) == 32

    def test_memory_encryptor_provided_key(self):
        """MemoryEncryptor should use provided key."""
        key = os.urandom(32)
        encryptor = MemoryEncryptor(key)

        assert encryptor.key == key

    def test_memory_encryptor_invalid_key_length(self):
        """MemoryEncryptor should reject keys of wrong length."""
        with pytest.raises(ValueError, match="Key must be 32 bytes"):
            MemoryEncryptor(b"short_key")


# =============================================================================
# MemoryEncryptor Encryption/Decryption Tests
# =============================================================================


class TestMemoryEncryptorEncryption:
    """Tests for encryption and decryption."""

    def test_memory_encryptor_encrypt_decrypt_roundtrip(
        self, encryptor: MemoryEncryptor
    ):
        """Basic encrypt/decrypt should return original plaintext."""
        plaintext = b"Hello, World! This is a secret message."

        encrypted = encryptor.encrypt(plaintext)
        decrypted = encryptor.decrypt(encrypted)

        assert decrypted == plaintext

    def test_memory_encryptor_encrypt_empty(self, encryptor: MemoryEncryptor):
        """Encrypting empty bytes should work."""
        plaintext = b""

        encrypted = encryptor.encrypt(plaintext)
        decrypted = encryptor.decrypt(encrypted)

        assert decrypted == plaintext

    def test_memory_encryptor_encrypt_large_data(self, encryptor: MemoryEncryptor):
        """Encrypting large data should work."""
        plaintext = os.urandom(1024 * 1024)  # 1 MB

        encrypted = encryptor.encrypt(plaintext)
        decrypted = encryptor.decrypt(encrypted)

        assert decrypted == plaintext

    def test_memory_encryptor_unique_iv_per_encryption(
        self, encryptor: MemoryEncryptor
    ):
        """Each encryption should use a unique IV."""
        plaintext = b"Same plaintext encrypted twice"

        encrypted1 = encryptor.encrypt(plaintext)
        encrypted2 = encryptor.encrypt(plaintext)

        # IVs should be different
        assert encrypted1.iv != encrypted2.iv

        # Ciphertexts should be different (due to different IVs)
        assert encrypted1.ciphertext != encrypted2.ciphertext

        # Both should decrypt to the same plaintext
        assert encryptor.decrypt(encrypted1) == plaintext
        assert encryptor.decrypt(encrypted2) == plaintext


# =============================================================================
# MemoryEncryptor Associated Data Tests
# =============================================================================


class TestMemoryEncryptorAssociatedData:
    """Tests for associated data (AAD) binding."""

    def test_memory_encryptor_associated_data(self, encryptor: MemoryEncryptor):
        """Encryption with AAD should bind context to ciphertext."""
        plaintext = b"Secret data"
        aad = b"context:agent:researcher"

        encrypted = encryptor.encrypt(plaintext, associated_data=aad)
        decrypted = encryptor.decrypt(encrypted)

        assert decrypted == plaintext
        assert encrypted.associated_data == aad

    def test_memory_encryptor_aad_tampered_fails(self, encryptor: MemoryEncryptor):
        """Tampering with AAD should cause decryption to fail."""
        plaintext = b"Secret data"
        aad = b"original_context"

        encrypted = encryptor.encrypt(plaintext, associated_data=aad)

        # Tamper with the associated data in the EncryptedData object
        # (this simulates someone trying to change the context)
        tampered = EncryptedData(
            iv=encrypted.iv,
            ciphertext=encrypted.ciphertext,
            associated_data=b"tampered_context",
        )

        with pytest.raises(cryptography.exceptions.InvalidTag):
            encryptor.decrypt(tampered)

    def test_memory_encryptor_missing_aad_fails(self, encryptor: MemoryEncryptor):
        """Decrypting with missing AAD should fail."""
        plaintext = b"Secret data"
        aad = b"required_context"

        encrypted = encryptor.encrypt(plaintext, associated_data=aad)

        # Try to decrypt without providing the AAD
        encrypted_no_aad = EncryptedData(
            iv=encrypted.iv,
            ciphertext=encrypted.ciphertext,
            associated_data=None,
        )

        with pytest.raises(cryptography.exceptions.InvalidTag):
            encryptor.decrypt(encrypted_no_aad)


# =============================================================================
# MemoryEncryptor Tamper Detection Tests
# =============================================================================


class TestMemoryEncryptorTamperDetection:
    """Tests for integrity verification and tamper detection."""

    def test_memory_encryptor_tampered_ciphertext_fails(
        self, encryptor: MemoryEncryptor
    ):
        """Tampering with ciphertext should raise InvalidTag."""
        plaintext = b"Original message"

        encrypted = encryptor.encrypt(plaintext)

        # Tamper with ciphertext by flipping a bit
        tampered_ciphertext = bytearray(encrypted.ciphertext)
        tampered_ciphertext[0] ^= 0x01

        tampered = EncryptedData(
            iv=encrypted.iv,
            ciphertext=bytes(tampered_ciphertext),
            associated_data=encrypted.associated_data,
        )

        with pytest.raises(cryptography.exceptions.InvalidTag):
            encryptor.decrypt(tampered)

    def test_memory_encryptor_tampered_iv_fails(self, encryptor: MemoryEncryptor):
        """Tampering with IV should raise InvalidTag."""
        plaintext = b"Original message"

        encrypted = encryptor.encrypt(plaintext)

        # Tamper with IV by flipping a bit
        tampered_iv = bytearray(encrypted.iv)
        tampered_iv[0] ^= 0x01

        tampered = EncryptedData(
            iv=bytes(tampered_iv),
            ciphertext=encrypted.ciphertext,
            associated_data=encrypted.associated_data,
        )

        with pytest.raises(cryptography.exceptions.InvalidTag):
            encryptor.decrypt(tampered)

    def test_memory_encryptor_wrong_key_fails(self, encryptor_with_known_key: tuple):
        """Decrypting with wrong key should raise InvalidTag."""
        encryptor, _ = encryptor_with_known_key
        plaintext = b"Secret message"

        encrypted = encryptor.encrypt(plaintext)

        # Create new encryptor with different key
        wrong_key = os.urandom(32)
        wrong_encryptor = MemoryEncryptor(wrong_key)

        with pytest.raises(cryptography.exceptions.InvalidTag):
            wrong_encryptor.decrypt(encrypted)


# =============================================================================
# EncryptedData Dataclass Tests
# =============================================================================


class TestEncryptedDataDataclass:
    """Tests for EncryptedData dataclass."""

    def test_encrypted_data_dataclass(self, encryptor: MemoryEncryptor):
        """EncryptedData should have accessible fields."""
        plaintext = b"test data"
        encrypted = encryptor.encrypt(plaintext)

        assert encrypted.iv is not None
        assert encrypted.ciphertext is not None
        assert len(encrypted.iv) == 12  # 96 bits for GCM

    def test_encrypted_data_to_dict(self, encryptor: MemoryEncryptor):
        """EncryptedData.to_dict should serialize correctly."""
        plaintext = b"test data"
        aad = b"context"
        encrypted = encryptor.encrypt(plaintext, associated_data=aad)

        data = encrypted.to_dict()

        assert "iv" in data
        assert "ciphertext" in data
        assert "associated_data" in data
        assert isinstance(data["iv"], str)
        assert isinstance(data["ciphertext"], str)

    def test_encrypted_data_from_dict(self, encryptor: MemoryEncryptor):
        """EncryptedData.from_dict should deserialize correctly."""
        plaintext = b"test data"
        original = encryptor.encrypt(plaintext)

        data = original.to_dict()
        restored = EncryptedData.from_dict(data)

        assert restored.iv == original.iv
        assert restored.ciphertext == original.ciphertext
        assert restored.associated_data == original.associated_data

    def test_encrypted_data_roundtrip_preserves_decryptability(
        self, encryptor: MemoryEncryptor
    ):
        """Serialization roundtrip should preserve decryptability."""
        plaintext = b"Important secret data"
        original = encryptor.encrypt(plaintext)

        # Serialize and deserialize
        data = original.to_dict()
        restored = EncryptedData.from_dict(data)

        # Should still decrypt correctly
        decrypted = encryptor.decrypt(restored)
        assert decrypted == plaintext

    def test_encrypted_data_invalid_iv_length(self):
        """EncryptedData should reject invalid IV length."""
        with pytest.raises(ValueError, match="IV must be 12 bytes"):
            EncryptedData(
                iv=b"short",
                ciphertext=b"some ciphertext",
            )

    def test_encrypted_data_without_associated_data(self, encryptor: MemoryEncryptor):
        """EncryptedData should handle None associated_data."""
        plaintext = b"test data"
        encrypted = encryptor.encrypt(plaintext)  # No AAD

        assert encrypted.associated_data is None

        data = encrypted.to_dict()
        assert data["associated_data"] is None

        restored = EncryptedData.from_dict(data)
        assert restored.associated_data is None
