"""
Comprehensive tests for EncryptedEpisodeStore (SEC-01).

Tests cover:
- Store and retrieve with transparent encryption
- Context is encrypted in DB
- Metadata (tags, embedding) preserved unencrypted
- Batch retrieval methods (session, agent)
- Mixed encrypted/unencrypted episodes
- Tamper detection
"""

import os
import sqlite3
import tempfile

import cryptography.exceptions
import pytest

from gsd_rlm.security import EncryptedEpisodeStore, MemoryEncryptor
from gsd_rlm.memory.hmem import Episode, EpisodeType


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def temp_db_path():
    """Provide a temporary database path that is cleaned up after test."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    yield path
    if os.path.exists(path):
        os.unlink(path)


@pytest.fixture
def encrypted_store(temp_db_path):
    """Provide an EncryptedEpisodeStore with a temp database."""
    return EncryptedEpisodeStore(temp_db_path)


@pytest.fixture
def sample_episode():
    """Provide a sample episode for testing."""
    return Episode(
        episode_id="ep-001",
        agent_id="agent-1",
        session_id="session-1",
        episode_type=EpisodeType.TASK_EXECUTION,
        context="This is sensitive context data",
        action="The action that was taken",
        outcome="The outcome of the action",
        success=True,
        tokens_used=100,
        duration_ms=500,
        tags=["test", "sample"],
        trace_id="trace-001",
    )


@pytest.fixture
def episode_with_embedding():
    """Provide an episode with embedding for metadata preservation tests."""
    return Episode(
        episode_id="ep-002",
        agent_id="agent-1",
        session_id="session-1",
        episode_type=EpisodeType.LEARNING,
        context="Learning context",
        action="Learning action",
        outcome="Learning outcome",
        embedding=[0.1, 0.2, 0.3, 0.4, 0.5],
        tags=["learning"],
    )


# =============================================================================
# Basic Store/Retrieve Tests
# =============================================================================


class TestEncryptedEpisodeStoreBasic:
    """Tests for basic store and retrieve operations."""

    def test_store_and_retrieve_encrypted(self, encrypted_store, sample_episode):
        """Store and retrieve should preserve content."""
        encrypted_store.store(sample_episode)
        retrieved = encrypted_store.get("ep-001")

        assert retrieved is not None
        assert retrieved.episode_id == sample_episode.episode_id
        assert retrieved.agent_id == sample_episode.agent_id
        assert retrieved.context == sample_episode.context
        assert retrieved.action == sample_episode.action
        assert retrieved.outcome == sample_episode.outcome
        assert retrieved.success == sample_episode.success

    def test_retrieve_nonexistent_returns_none(self, encrypted_store):
        """Retrieving nonexistent episode should return None."""
        result = encrypted_store.get("nonexistent")
        assert result is None

    def test_delete_works(self, encrypted_store, sample_episode):
        """Delete should remove episode."""
        encrypted_store.store(sample_episode)
        assert encrypted_store.get("ep-001") is not None

        deleted = encrypted_store.delete("ep-001")
        assert deleted is True
        assert encrypted_store.get("ep-001") is None

    def test_delete_nonexistent_returns_false(self, encrypted_store):
        """Deleting nonexistent episode should return False."""
        deleted = encrypted_store.delete("nonexistent")
        assert deleted is False

    def test_count(self, encrypted_store, sample_episode):
        """Count should return total episodes."""
        assert encrypted_store.count() == 0

        encrypted_store.store(sample_episode)
        assert encrypted_store.count() == 1

        ep2 = Episode(
            episode_id="ep-002",
            agent_id="agent-1",
            session_id="session-1",
            episode_type=EpisodeType.TASK_EXECUTION,
            context="Second episode",
        )
        encrypted_store.store(ep2)
        assert encrypted_store.count() == 2


# =============================================================================
# Encryption Verification Tests
# =============================================================================


class TestEncryptedEpisodeStoreEncryption:
    """Tests for encryption behavior."""

    def test_context_is_encrypted_in_db(
        self, encrypted_store, sample_episode, temp_db_path
    ):
        """Raw DB read should show encrypted data, not plaintext."""
        encrypted_store.store(sample_episode)

        # Read directly from DB
        conn = sqlite3.connect(temp_db_path)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT context, action, outcome FROM episodes WHERE episode_id = ?",
            ("ep-001",),
        )
        row = cursor.fetchone()
        conn.close()

        assert row is not None
        # Context should be base64-encoded encrypted data (not plaintext)
        assert "sensitive context data" not in row[0]
        # Action and outcome should be placeholder
        assert row[1] == "[ENCRYPTED]"
        assert row[2] == "[ENCRYPTED]"

    def test_tags_preserved(self, encrypted_store, sample_episode):
        """Original tags should be kept, 'encrypted' tag added."""
        encrypted_store.store(sample_episode)
        retrieved = encrypted_store.get("ep-001")

        assert retrieved is not None
        assert "test" in retrieved.tags
        assert "sample" in retrieved.tags
        # The 'encrypted' tag should be removed on retrieval
        assert "encrypted" not in retrieved.tags

    def test_metadata_not_encrypted(
        self, encrypted_store, episode_with_embedding, temp_db_path
    ):
        """Embedding and timestamp should be readable in raw DB."""
        encrypted_store.store(episode_with_embedding)

        # Read directly from DB
        conn = sqlite3.connect(temp_db_path)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT embedding, timestamp FROM episodes WHERE episode_id = ?",
            ("ep-002",),
        )
        row = cursor.fetchone()
        conn.close()

        assert row is not None
        # Embedding should be stored as JSON (readable)
        import json

        embedding = json.loads(row[0].decode("utf-8"))
        assert embedding == [0.1, 0.2, 0.3, 0.4, 0.5]
        # Timestamp should be a string
        assert isinstance(row[1], str)

    def test_multiple_episodes(self, encrypted_store):
        """Store multiple episodes, all decrypt correctly."""
        episodes = []
        for i in range(5):
            ep = Episode(
                episode_id=f"ep-{i:03d}",
                agent_id="agent-1",
                session_id="session-1",
                episode_type=EpisodeType.TASK_EXECUTION,
                context=f"Context for episode {i}",
                action=f"Action for episode {i}",
                outcome=f"Outcome for episode {i}",
            )
            episodes.append(ep)
            encrypted_store.store(ep)

        assert encrypted_store.count() == 5

        # Retrieve and verify all
        for i, ep in enumerate(episodes):
            retrieved = encrypted_store.get(f"ep-{i:03d}")
            assert retrieved is not None
            assert retrieved.context == f"Context for episode {i}"
            assert retrieved.action == f"Action for episode {i}"
            assert retrieved.outcome == f"Outcome for episode {i}"


# =============================================================================
# Batch Retrieval Tests
# =============================================================================


class TestEncryptedEpisodeStoreBatchRetrieval:
    """Tests for batch retrieval methods."""

    def test_get_episodes_for_session(self, encrypted_store):
        """Session query should return decrypted episodes."""
        # Create episodes in different sessions
        for i in range(3):
            ep = Episode(
                episode_id=f"ep-s1-{i}",
                agent_id="agent-1",
                session_id="session-1",
                episode_type=EpisodeType.TASK_EXECUTION,
                context=f"S1 Context {i}",
            )
            encrypted_store.store(ep)

        for i in range(2):
            ep = Episode(
                episode_id=f"ep-s2-{i}",
                agent_id="agent-1",
                session_id="session-2",
                episode_type=EpisodeType.TASK_EXECUTION,
                context=f"S2 Context {i}",
            )
            encrypted_store.store(ep)

        # Get session 1 episodes
        s1_episodes = encrypted_store.get_episodes_for_session("session-1")
        assert len(s1_episodes) == 3
        for ep in s1_episodes:
            assert ep.session_id == "session-1"
            assert "S1 Context" in ep.context

        # Get session 2 episodes
        s2_episodes = encrypted_store.get_episodes_for_session("session-2")
        assert len(s2_episodes) == 2
        for ep in s2_episodes:
            assert ep.session_id == "session-2"

    def test_get_episodes_by_agent(self, encrypted_store):
        """Agent query should return decrypted episodes."""
        # Create episodes for different agents
        for i in range(4):
            ep = Episode(
                episode_id=f"ep-a1-{i}",
                agent_id="agent-1",
                session_id="session-1",
                episode_type=EpisodeType.TASK_EXECUTION,
                context=f"A1 Context {i}",
            )
            encrypted_store.store(ep)

        for i in range(2):
            ep = Episode(
                episode_id=f"ep-a2-{i}",
                agent_id="agent-2",
                session_id="session-2",
                episode_type=EpisodeType.TASK_EXECUTION,
                context=f"A2 Context {i}",
            )
            encrypted_store.store(ep)

        # Get agent 1 episodes (default limit 50)
        a1_episodes = encrypted_store.get_episodes_by_agent("agent-1")
        assert len(a1_episodes) == 4

        # Get agent 2 episodes
        a2_episodes = encrypted_store.get_episodes_by_agent("agent-2")
        assert len(a2_episodes) == 2

    def test_get_episodes_by_agent_with_limit(self, encrypted_store):
        """Agent query should respect limit."""
        for i in range(10):
            ep = Episode(
                episode_id=f"ep-limit-{i}",
                agent_id="agent-limit",
                session_id="session-1",
                episode_type=EpisodeType.TASK_EXECUTION,
                context=f"Context {i}",
            )
            encrypted_store.store(ep)

        # Get with limit
        episodes = encrypted_store.get_episodes_by_agent("agent-limit", limit=5)
        assert len(episodes) == 5


# =============================================================================
# Mixed Encryption Tests
# =============================================================================


class TestEncryptedEpisodeStoreMixed:
    """Tests for mixing encrypted and unencrypted episodes."""

    def test_non_encrypted_episode_passthrough(self, temp_db_path):
        """Unencrypted episodes should pass through unchanged."""
        # Create a store and add an encrypted episode
        store = EncryptedEpisodeStore(temp_db_path)
        encrypted_ep = Episode(
            episode_id="ep-encrypted",
            agent_id="agent-1",
            session_id="session-1",
            episode_type=EpisodeType.TASK_EXECUTION,
            context="Encrypted content",
        )
        store.store(encrypted_ep)

        # Now directly add an unencrypted episode to the DB
        conn = sqlite3.connect(temp_db_path)
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO episodes (
                episode_id, agent_id, session_id, episode_type,
                context, action, outcome, success, timestamp, tags
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                "ep-unencrypted",
                "agent-1",
                "session-1",
                "task_execution",
                "Unencrypted context",
                "Unencrypted action",
                "Unencrypted outcome",
                0,
                "2024-01-01T00:00:00+00:00",
                "[]",
            ),
        )
        conn.commit()
        conn.close()

        # Retrieve unencrypted episode - should work
        retrieved = store.get("ep-unencrypted")
        assert retrieved is not None
        assert retrieved.context == "Unencrypted context"
        assert retrieved.action == "Unencrypted action"

        # Encrypted episode should still work
        retrieved_encrypted = store.get("ep-encrypted")
        assert retrieved_encrypted is not None
        assert retrieved_encrypted.context == "Encrypted content"


# =============================================================================
# Tamper Detection Tests
# =============================================================================


class TestEncryptedEpisodeStoreTamperDetection:
    """Tests for integrity verification."""

    def test_tampered_ciphertext_fails(
        self, encrypted_store, sample_episode, temp_db_path
    ):
        """Modified ciphertext should raise error on decryption."""
        encrypted_store.store(sample_episode)

        # Get the current context (base64-encoded encrypted data)
        conn = sqlite3.connect(temp_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT context FROM episodes WHERE episode_id = ?", ("ep-001",))
        row = cursor.fetchone()
        original_context = row[0]
        conn.close()

        # Decode the base64 to get the raw encrypted bytes, tamper with them, re-encode
        import base64

        raw_bytes = base64.b64decode(original_context)
        tampered_bytes = bytearray(raw_bytes)
        # Flip a bit in the ciphertext portion (after the 12-byte IV)
        if len(tampered_bytes) > 13:
            tampered_bytes[13] ^= 0x01
        tampered_context = base64.b64encode(bytes(tampered_bytes)).decode("utf-8")

        # Write the tampered data back
        conn = sqlite3.connect(temp_db_path)
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE episodes SET context = ? WHERE episode_id = ?",
            (tampered_context, "ep-001"),
        )
        conn.commit()
        conn.close()

        # Attempting to retrieve should raise InvalidTag
        with pytest.raises(cryptography.exceptions.InvalidTag):
            encrypted_store.get("ep-001")


# =============================================================================
# Custom Encryptor Tests
# =============================================================================


class TestEncryptedEpisodeStoreCustomEncryptor:
    """Tests for custom encryptor usage."""

    def test_custom_encryptor(self, temp_db_path):
        """Should be able to provide a custom encryptor."""
        key = MemoryEncryptor.generate_key()
        encryptor = MemoryEncryptor(key=key)

        store = EncryptedEpisodeStore(temp_db_path, encryptor=encryptor)

        ep = Episode(
            episode_id="ep-custom",
            agent_id="agent-1",
            session_id="session-1",
            episode_type=EpisodeType.TASK_EXECUTION,
            context="Custom encrypted content",
        )
        store.store(ep)

        retrieved = store.get("ep-custom")
        assert retrieved is not None
        assert retrieved.context == "Custom encrypted content"

    def test_different_encryptors_cannot_decrypt(self, temp_db_path):
        """Store with one encryptor, try to read with another."""
        # Store with first encryptor
        key1 = MemoryEncryptor.generate_key()
        store1 = EncryptedEpisodeStore(
            temp_db_path, encryptor=MemoryEncryptor(key=key1)
        )

        ep = Episode(
            episode_id="ep-cross",
            agent_id="agent-1",
            session_id="session-1",
            episode_type=EpisodeType.TASK_EXECUTION,
            context="Secret content",
        )
        store1.store(ep)

        # Try to read with different encryptor
        key2 = MemoryEncryptor.generate_key()
        store2 = EncryptedEpisodeStore(
            temp_db_path, encryptor=MemoryEncryptor(key=key2)
        )

        with pytest.raises(cryptography.exceptions.InvalidTag):
            store2.get("ep-cross")
