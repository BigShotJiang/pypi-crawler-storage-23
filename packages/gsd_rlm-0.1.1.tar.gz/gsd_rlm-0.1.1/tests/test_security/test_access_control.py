"""
Comprehensive tests for access control (SEC-03, SEC-04).

Tests cover:
- AccessGrant Pydantic model
- ViolationLog dataclass
- ZoneAccessManager with grant/revoke/validate
"""

from datetime import datetime, timezone, timedelta

import pytest
from pydantic import ValidationError

from gsd_rlm.security import (
    ZoneAccessManager,
    AccessGrant,
    ViolationLog,
    TrustZone,
)


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def tmp_manager() -> ZoneAccessManager:
    """Provide a fresh ZoneAccessManager for each test."""
    return ZoneAccessManager()


@pytest.fixture
def assigned_manager() -> ZoneAccessManager:
    """Provide a manager with agents pre-assigned to zones."""
    manager = ZoneAccessManager()
    manager.assign_agent_to_zone("secret-agent", TrustZone.SECRET)
    manager.assign_agent_to_zone("confidential-agent", TrustZone.CONFIDENTIAL)
    manager.assign_agent_to_zone("internal-agent", TrustZone.INTERNAL)
    manager.assign_agent_to_zone("public-agent", TrustZone.PUBLIC)
    return manager


# =============================================================================
# AccessGrant Model Tests
# =============================================================================


class TestAccessGrant:
    """Tests for AccessGrant Pydantic model."""

    def test_access_grant_creation(self):
        """AccessGrant should be created with all fields."""
        grant = AccessGrant(
            grant_id="grant-001",
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            granted_by="user-1",
        )

        assert grant.grant_id == "grant-001"
        assert grant.source_agent_id == "agent-1"
        assert grant.target_agent_id == "agent-2"
        assert grant.granted_by == "user-1"
        assert grant.allowed_operations == {"read"}

    def test_access_grant_not_expired_by_default(self):
        """AccessGrant without expires_at should never be expired."""
        grant = AccessGrant(
            grant_id="grant-001",
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            granted_by="user-1",
        )

        assert grant.is_expired() is False

    def test_access_grant_expired_check_future(self):
        """AccessGrant with future expiration should not be expired."""
        grant = AccessGrant(
            grant_id="grant-001",
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            granted_by="user-1",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
        )

        assert grant.is_expired() is False

    def test_access_grant_expired_check_past(self):
        """AccessGrant with past expiration should be expired."""
        grant = AccessGrant(
            grant_id="grant-001",
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            granted_by="user-1",
            expires_at=datetime.now(timezone.utc) - timedelta(hours=1),
        )

        assert grant.is_expired() is True

    def test_access_grant_extra_forbidden(self):
        """AccessGrant should reject unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            AccessGrant(
                grant_id="grant-001",
                source_agent_id="agent-1",
                target_agent_id="agent-2",
                granted_by="user-1",
                unknown_field="should_fail",  # type: ignore
            )

        assert "extra" in str(exc_info.value).lower()

    def test_access_grant_allowed_operations_default(self):
        """AccessGrant should have default operations as {"read"}."""
        grant = AccessGrant(
            grant_id="grant-001",
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            granted_by="user-1",
        )

        assert grant.allowed_operations == {"read"}

    def test_access_grant_custom_operations(self):
        """AccessGrant should accept custom operations."""
        grant = AccessGrant(
            grant_id="grant-001",
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            granted_by="user-1",
            allowed_operations={"read", "write", "delete"},
        )

        assert grant.allowed_operations == {"read", "write", "delete"}

    def test_access_grant_auto_timestamp(self):
        """AccessGrant should auto-generate UTC timestamp."""
        before = datetime.now(timezone.utc)
        grant = AccessGrant(
            grant_id="grant-001",
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            granted_by="user-1",
        )
        after = datetime.now(timezone.utc)

        assert before <= grant.granted_at <= after
        assert grant.granted_at.tzinfo == timezone.utc

    def test_access_grant_repr(self):
        """AccessGrant repr should be informative."""
        grant = AccessGrant(
            grant_id="grant-001",
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            granted_by="user-1",
        )

        repr_str = repr(grant)
        assert "AccessGrant" in repr_str
        assert "grant-001" in repr_str
        assert "agent-1" in repr_str


# =============================================================================
# ViolationLog Tests
# =============================================================================


class TestViolationLog:
    """Tests for ViolationLog dataclass."""

    def test_violation_log_creation(self):
        """ViolationLog should be created with all fields."""
        violation = ViolationLog(
            timestamp="2024-01-15T10:00:00+00:00",
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            operation="read",
            source_zone=TrustZone.PUBLIC,
            target_zone=TrustZone.SECRET,
            reason="Access denied",
        )

        assert violation.timestamp == "2024-01-15T10:00:00+00:00"
        assert violation.source_agent_id == "agent-1"
        assert violation.target_agent_id == "agent-2"
        assert violation.operation == "read"
        assert violation.source_zone == TrustZone.PUBLIC
        assert violation.target_zone == TrustZone.SECRET
        assert violation.reason == "Access denied"

    def test_violation_log_timestamp_iso_format(self):
        """ViolationLog timestamp should be ISO format string."""
        violation = ViolationLog(
            timestamp=datetime.now(timezone.utc).isoformat(),
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            operation="read",
            source_zone=TrustZone.PUBLIC,
            target_zone=TrustZone.SECRET,
            reason="Test",
        )

        # Should be parseable as ISO format
        parsed = datetime.fromisoformat(violation.timestamp)
        assert parsed is not None


# =============================================================================
# ZoneAccessManager Tests
# =============================================================================


class TestZoneAccessManager:
    """Tests for ZoneAccessManager."""

    def test_assign_agent_to_zone(self, tmp_manager: ZoneAccessManager):
        """Assigning agent to zone should work."""
        tmp_manager.assign_agent_to_zone("agent-1", TrustZone.SECRET)

        assert tmp_manager.get_agent_zone("agent-1") == TrustZone.SECRET

    def test_get_agent_zone(self, tmp_manager: ZoneAccessManager):
        """Getting zone for unassigned agent should return None."""
        assert tmp_manager.get_agent_zone("unknown-agent") is None

    def test_grant_access(self, tmp_manager: ZoneAccessManager):
        """Granting access should create an AccessGrant."""
        grant = tmp_manager.grant_access(
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            granted_by="user-1",
        )

        assert grant.grant_id is not None
        assert grant.source_agent_id == "agent-1"
        assert grant.target_agent_id == "agent-2"
        assert grant.granted_by == "user-1"

    def test_grant_access_with_operations(self, tmp_manager: ZoneAccessManager):
        """Granting access with custom operations should work."""
        grant = tmp_manager.grant_access(
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            granted_by="user-1",
            allowed_operations={"read", "write"},
        )

        assert grant.allowed_operations == {"read", "write"}

    def test_revoke_access_existing(self, tmp_manager: ZoneAccessManager):
        """Revoking existing grant should return True."""
        grant = tmp_manager.grant_access(
            source_agent_id="agent-1",
            target_agent_id="agent-2",
            granted_by="user-1",
        )

        result = tmp_manager.revoke_access(grant.grant_id)

        assert result is True

    def test_revoke_access_nonexistent(self, tmp_manager: ZoneAccessManager):
        """Revoking nonexistent grant should return False."""
        result = tmp_manager.revoke_access("nonexistent-grant-id")

        assert result is False

    def test_validate_access_same_agent(self, assigned_manager: ZoneAccessManager):
        """Same agent should always have access to itself."""
        assert assigned_manager.validate_access("secret-agent", "secret-agent") is True
        assert assigned_manager.validate_access("public-agent", "public-agent") is True

    def test_validate_access_unassigned_agent(self, tmp_manager: ZoneAccessManager):
        """Unassigned agent should be denied and logged."""
        result = tmp_manager.validate_access("unknown-agent", "other-agent")

        assert result is False
        violations = tmp_manager.get_violations()
        assert len(violations) == 1
        assert violations[0].source_agent_id == "unknown-agent"
        assert "not assigned to zone" in violations[0].reason.lower()

    def test_validate_access_hierarchical_allowed(
        self, assigned_manager: ZoneAccessManager
    ):
        """Higher zone should access lower zone data."""
        # SECRET can access CONFIDENTIAL
        assert (
            assigned_manager.validate_access("secret-agent", "confidential-agent")
            is True
        )

        # SECRET can access INTERNAL
        assert (
            assigned_manager.validate_access("secret-agent", "internal-agent") is True
        )

        # SECRET can access PUBLIC
        assert assigned_manager.validate_access("secret-agent", "public-agent") is True

        # CONFIDENTIAL can access INTERNAL
        assert (
            assigned_manager.validate_access("confidential-agent", "internal-agent")
            is True
        )

    def test_validate_access_hierarchical_denied(
        self, assigned_manager: ZoneAccessManager
    ):
        """Lower zone should NOT access higher zone data."""
        # PUBLIC cannot access SECRET
        assert assigned_manager.validate_access("public-agent", "secret-agent") is False

        # PUBLIC cannot access CONFIDENTIAL
        assert (
            assigned_manager.validate_access("public-agent", "confidential-agent")
            is False
        )

        # INTERNAL cannot access SECRET
        assert (
            assigned_manager.validate_access("internal-agent", "secret-agent") is False
        )

    def test_validate_access_explicit_grant(self, tmp_manager: ZoneAccessManager):
        """Explicit grant should allow cross-zone access."""
        tmp_manager.assign_agent_to_zone("public-agent", TrustZone.PUBLIC)
        tmp_manager.assign_agent_to_zone("secret-agent", TrustZone.SECRET)

        # Initially denied
        assert tmp_manager.validate_access("public-agent", "secret-agent") is False

        # Grant access
        tmp_manager.grant_access(
            source_agent_id="public-agent",
            target_agent_id="secret-agent",
            granted_by="admin",
        )

        # Now allowed
        assert tmp_manager.validate_access("public-agent", "secret-agent") is True

    def test_validate_access_expired_grant_ignored(
        self, tmp_manager: ZoneAccessManager
    ):
        """Expired grants should be ignored during validation."""
        tmp_manager.assign_agent_to_zone("public-agent", TrustZone.PUBLIC)
        tmp_manager.assign_agent_to_zone("secret-agent", TrustZone.SECRET)

        # Create expired grant
        tmp_manager.grant_access(
            source_agent_id="public-agent",
            target_agent_id="secret-agent",
            granted_by="admin",
            expires_at=datetime.now(timezone.utc) - timedelta(hours=1),
        )

        # Should still be denied (grant expired)
        assert tmp_manager.validate_access("public-agent", "secret-agent") is False

    def test_validate_access_wrong_operation(self, tmp_manager: ZoneAccessManager):
        """Grant for read should not allow write."""
        tmp_manager.assign_agent_to_zone("public-agent", TrustZone.PUBLIC)
        tmp_manager.assign_agent_to_zone("secret-agent", TrustZone.SECRET)

        # Grant read-only access
        tmp_manager.grant_access(
            source_agent_id="public-agent",
            target_agent_id="secret-agent",
            granted_by="admin",
            allowed_operations={"read"},
        )

        # Read is allowed
        assert (
            tmp_manager.validate_access("public-agent", "secret-agent", "read") is True
        )

        # Write is denied
        assert (
            tmp_manager.validate_access("public-agent", "secret-agent", "write")
            is False
        )

    def test_violation_logged_on_denied(self, tmp_manager: ZoneAccessManager):
        """Violations should be logged on access denial."""
        tmp_manager.assign_agent_to_zone("public-agent", TrustZone.PUBLIC)
        tmp_manager.assign_agent_to_zone("secret-agent", TrustZone.SECRET)

        # Clear any previous violations
        _ = tmp_manager.get_violations()

        # Attempt denied access
        tmp_manager.validate_access("public-agent", "secret-agent")

        violations = tmp_manager.get_violations()
        assert len(violations) >= 1

        # Check violation details
        violation = violations[-1]
        assert violation.source_agent_id == "public-agent"
        assert violation.target_agent_id == "secret-agent"
        assert violation.operation == "read"
        assert violation.source_zone == TrustZone.PUBLIC
        assert violation.target_zone == TrustZone.SECRET

    def test_get_grants_for_agent(self, tmp_manager: ZoneAccessManager):
        """Should return grants where agent is source or target."""
        # Create multiple grants
        g1 = tmp_manager.grant_access("agent-1", "agent-2", "user")
        g2 = tmp_manager.grant_access("agent-3", "agent-1", "user")
        tmp_manager.grant_access("agent-3", "agent-2", "user")

        grants = tmp_manager.get_grants_for_agent("agent-1")

        assert len(grants) == 2
        grant_ids = {g.grant_id for g in grants}
        assert g1.grant_id in grant_ids
        assert g2.grant_id in grant_ids


# =============================================================================
# Integration Tests
# =============================================================================


class TestAccessControlIntegration:
    """Integration tests for access control with trust zones."""

    def test_full_workflow(self):
        """Test complete grant/revoke workflow."""
        manager = ZoneAccessManager()

        # Set up agents
        manager.assign_agent_to_zone("low-agent", TrustZone.PUBLIC)
        manager.assign_agent_to_zone("high-agent", TrustZone.SECRET)

        # High can access low
        assert manager.validate_access("high-agent", "low-agent") is True

        # Low cannot access high
        assert manager.validate_access("low-agent", "high-agent") is False
        assert len(manager.get_violations()) == 1

        # Grant access
        grant = manager.grant_access("low-agent", "high-agent", "admin")
        assert manager.validate_access("low-agent", "high-agent") is True

        # Revoke access
        manager.revoke_access(grant.grant_id)
        assert manager.validate_access("low-agent", "high-agent") is False
        assert len(manager.get_violations()) == 2

    def test_multiple_grants_same_agents(self):
        """Multiple grants for same agent pair should all be checked."""
        manager = ZoneAccessManager()

        manager.assign_agent_to_zone("a1", TrustZone.PUBLIC)
        manager.assign_agent_to_zone("a2", TrustZone.SECRET)

        # Grant read access
        manager.grant_access("a1", "a2", "admin", allowed_operations={"read"})

        # Grant write access (separate grant)
        manager.grant_access("a1", "a2", "admin", allowed_operations={"write"})

        # Both operations should work
        assert manager.validate_access("a1", "a2", "read") is True
        assert manager.validate_access("a1", "a2", "write") is True

        # Delete still denied
        assert manager.validate_access("a1", "a2", "delete") is False
