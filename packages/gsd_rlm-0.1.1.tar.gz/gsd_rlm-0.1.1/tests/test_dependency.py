"""
Tests for dependency analysis system.

This module tests the DependencyGraph class for task dependency
management and wave-based parallel execution grouping.

Requirements: EXEC-01, EXEC-03
"""

import pytest

from gsd_rlm.execution.dependency import DependencyGraph, WaveResult


class TestDependencyGraphEmpty:
    """Tests for empty graph behavior."""

    def test_empty_graph(self):
        """Empty graph should return empty waves."""
        graph = DependencyGraph()
        waves = graph.get_waves()
        assert waves == []

    def test_empty_graph_task_count(self):
        """Empty graph should have zero tasks."""
        graph = DependencyGraph()
        assert graph.get_task_count() == 0

    def test_empty_graph_no_cycles(self):
        """Empty graph should have no cycles."""
        graph = DependencyGraph()
        cycles = graph.detect_cycles()
        assert cycles == []

    def test_empty_graph_validates(self):
        """Empty graph should validate successfully."""
        graph = DependencyGraph()
        assert graph.validate() is True


class TestDependencyGraphSingleTask:
    """Tests for single task graph."""

    def test_single_task(self):
        """Single task should return single wave."""
        graph = DependencyGraph()
        graph.add_task("A")
        waves = graph.get_waves()
        assert waves == [["A"]]

    def test_single_task_dependencies(self):
        """Single task should have no dependencies."""
        graph = DependencyGraph()
        graph.add_task("A")
        deps = graph.get_dependencies("A")
        assert deps == set()

    def test_single_task_dependents(self):
        """Single task should have no dependents."""
        graph = DependencyGraph()
        graph.add_task("A")
        dependents = graph.get_dependents("A")
        assert dependents == set()


class TestDependencyGraphIndependentTasks:
    """Tests for independent tasks (no dependencies)."""

    def test_two_independent_tasks(self):
        """Two tasks with no deps should be in same wave."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B")
        waves = graph.get_waves()
        # Both should be in the same wave (order may vary)
        assert len(waves) == 1
        assert set(waves[0]) == {"A", "B"}

    def test_three_independent_tasks(self):
        """Three independent tasks should be in same wave."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B")
        graph.add_task("C")
        waves = graph.get_waves()
        assert len(waves) == 1
        assert set(waves[0]) == {"A", "B", "C"}


class TestDependencyGraphDependentTasks:
    """Tests for dependent tasks."""

    def test_two_dependent_tasks(self):
        """Task B depends on A should result in two waves."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        waves = graph.get_waves()
        assert len(waves) == 2
        assert waves[0] == ["A"]
        assert waves[1] == ["B"]

    def test_chain_of_dependencies(self):
        """Chain A->B->C should result in three waves."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        graph.add_task("C", depends_on=["B"])
        waves = graph.get_waves()
        assert len(waves) == 3
        assert waves[0] == ["A"]
        assert waves[1] == ["B"]
        assert waves[2] == ["C"]

    def test_diamond_dependency(self):
        """Diamond pattern A->B, A->C, B->D, C->D should result in three waves."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        graph.add_task("C", depends_on=["A"])
        graph.add_task("D", depends_on=["B", "C"])
        waves = graph.get_waves()

        # Wave 0: A
        assert waves[0] == ["A"]

        # Wave 1: B and C (can run in parallel)
        assert len(waves[1]) == 2
        assert set(waves[1]) == {"B", "C"}

        # Wave 2: D (depends on both B and C)
        assert waves[2] == ["D"]


class TestDependencyGraphComplexDAG:
    """Tests for complex dependency scenarios."""

    def test_complex_dag(self):
        """More complex dependency scenario with mixed deps."""
        graph = DependencyGraph()
        # A, B independent
        # C depends on A
        # D depends on A, B
        # E depends on C, D
        graph.add_task("A")
        graph.add_task("B")
        graph.add_task("C", depends_on=["A"])
        graph.add_task("D", depends_on=["A", "B"])
        graph.add_task("E", depends_on=["C", "D"])

        waves = graph.get_waves()

        # Wave 0: A, B (independent)
        assert set(waves[0]) == {"A", "B"}

        # Wave 1: C (needs A), D (needs A and B)
        assert set(waves[1]) == {"C", "D"}

        # Wave 2: E (needs C and D)
        assert waves[2] == ["E"]

    def test_multiple_roots(self):
        """Graph with multiple root tasks."""
        graph = DependencyGraph()
        graph.add_task("R1")
        graph.add_task("R2")
        graph.add_task("R3")
        graph.add_task("C1", depends_on=["R1"])
        graph.add_task("C2", depends_on=["R2", "R3"])

        waves = graph.get_waves()

        # Wave 0: all roots
        assert set(waves[0]) == {"R1", "R2", "R3"}

        # Wave 1: C1 and C2 (can run in parallel)
        assert set(waves[1]) == {"C1", "C2"}


class TestDependencyGraphGetDependencies:
    """Tests for get_dependencies method."""

    def test_get_dependencies_single(self):
        """Get dependencies for task with single dependency."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        deps = graph.get_dependencies("B")
        assert deps == {"A"}

    def test_get_dependencies_multiple(self):
        """Get dependencies for task with multiple dependencies."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B")
        graph.add_task("C", depends_on=["A", "B"])
        deps = graph.get_dependencies("C")
        assert deps == {"A", "B"}

    def test_get_dependencies_none(self):
        """Get dependencies for task with no dependencies."""
        graph = DependencyGraph()
        graph.add_task("A")
        deps = graph.get_dependencies("A")
        assert deps == set()

    def test_get_dependencies_nonexistent_task(self):
        """Get dependencies for nonexistent task should raise KeyError."""
        graph = DependencyGraph()
        with pytest.raises(KeyError):
            graph.get_dependencies("nonexistent")


class TestDependencyGraphGetDependents:
    """Tests for get_dependents method."""

    def test_get_dependents_single(self):
        """Get dependents for task with single dependent."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        dependents = graph.get_dependents("A")
        assert dependents == {"B"}

    def test_get_dependents_multiple(self):
        """Get dependents for task with multiple dependents."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        graph.add_task("C", depends_on=["A"])
        dependents = graph.get_dependents("A")
        assert dependents == {"B", "C"}

    def test_get_dependents_none(self):
        """Get dependents for task with no dependents."""
        graph = DependencyGraph()
        graph.add_task("A")
        dependents = graph.get_dependents("A")
        assert dependents == set()

    def test_get_dependents_nonexistent_task(self):
        """Get dependents for nonexistent task should raise KeyError."""
        graph = DependencyGraph()
        with pytest.raises(KeyError):
            graph.get_dependents("nonexistent")


class TestDependencyGraphCycleDetection:
    """Tests for cycle detection."""

    def test_detect_no_cycles(self):
        """Valid DAG should return empty list for cycles."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        cycles = graph.detect_cycles()
        assert cycles == []

    def test_detect_simple_cycle(self):
        """Simple cycle A->B->A should be detected."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        # Create cycle: A -> B -> A
        graph._graph.add_edge("B", "A")

        cycles = graph.detect_cycles()
        assert len(cycles) > 0
        # Check that A and B are in a cycle
        cycle_nodes = set(cycles[0])
        assert cycle_nodes == {"A", "B"}

    def test_detect_complex_cycle(self):
        """Multi-node cycle should be detected."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        graph.add_task("C", depends_on=["B"])
        # Create cycle: A -> B -> C -> A
        graph._graph.add_edge("C", "A")

        cycles = graph.detect_cycles()
        assert len(cycles) > 0
        cycle_nodes = set(cycles[0])
        assert cycle_nodes == {"A", "B", "C"}

    def test_validate_raises_on_cycle(self):
        """Validate should raise ValueError with cycle info."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        # Create cycle
        graph._graph.add_edge("B", "A")

        with pytest.raises(ValueError) as exc_info:
            graph.validate()

        assert "Circular" in str(exc_info.value)

    def test_get_waves_raises_on_cycle(self):
        """Get waves should raise ValueError on cycle."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        # Create cycle
        graph._graph.add_edge("B", "A")

        with pytest.raises(ValueError) as exc_info:
            graph.get_waves()

        assert "Circular" in str(exc_info.value)


class TestDependencyGraphBulkAdd:
    """Tests for bulk task addition."""

    def test_add_tasks_bulk(self):
        """Bulk addition should work correctly."""
        graph = DependencyGraph()
        graph.add_tasks({"A": [], "B": [], "C": ["A", "B"], "D": ["C"]})

        waves = graph.get_waves()

        # Wave 0: A, B
        assert set(waves[0]) == {"A", "B"}

        # Wave 1: C
        assert waves[1] == ["C"]

        # Wave 2: D
        assert waves[2] == ["D"]

    def test_add_tasks_bulk_with_none_deps(self):
        """Bulk addition with None deps should work."""
        graph = DependencyGraph()
        graph.add_tasks(
            {
                "A": None,
                "B": None,
            }
        )

        waves = graph.get_waves()
        assert len(waves) == 1
        assert set(waves[0]) == {"A", "B"}

    def test_add_tasks_preserves_existing(self):
        """Adding tasks should preserve existing tasks."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_tasks({"B": ["A"]})

        waves = graph.get_waves()
        assert waves[0] == ["A"]
        assert waves[1] == ["B"]


class TestWaveResult:
    """Tests for WaveResult dataclass."""

    def test_wave_result_creation(self):
        """WaveResult should be created with all fields."""
        result = WaveResult(wave_id=0, task_ids=["A", "B"], success=True)
        assert result.wave_id == 0
        assert result.task_ids == ["A", "B"]
        assert result.success is True

    def test_wave_result_defaults(self):
        """WaveResult should have success default to True."""
        result = WaveResult(wave_id=0, task_ids=[])
        assert result.success is True

    def test_wave_result_failure(self):
        """WaveResult can represent failure."""
        result = WaveResult(wave_id=0, task_ids=["A"], success=False)
        assert result.success is False


class TestDependencyGraphUtilityMethods:
    """Tests for utility methods."""

    def test_get_task_count(self):
        """get_task_count should return correct count."""
        graph = DependencyGraph()
        assert graph.get_task_count() == 0

        graph.add_task("A")
        assert graph.get_task_count() == 1

        graph.add_task("B")
        assert graph.get_task_count() == 2

    def test_get_dependency_count(self):
        """get_dependency_count should return correct count."""
        graph = DependencyGraph()
        assert graph.get_dependency_count() == 0

        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        assert graph.get_dependency_count() == 1

        graph.add_task("C", depends_on=["A", "B"])
        assert graph.get_dependency_count() == 3

    def test_has_task(self):
        """has_task should correctly identify tasks."""
        graph = DependencyGraph()
        assert not graph.has_task("A")

        graph.add_task("A")
        assert graph.has_task("A")
        assert not graph.has_task("B")

    def test_get_all_tasks(self):
        """get_all_tasks should return all task IDs."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B")
        graph.add_task("C", depends_on=["A", "B"])

        all_tasks = graph.get_all_tasks()
        assert all_tasks == {"A", "B", "C"}

    def test_clear(self):
        """clear should remove all tasks."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])

        graph.clear()

        assert graph.get_task_count() == 0
        assert graph.get_waves() == []

    def test_get_wave_count(self):
        """get_wave_count should return correct count."""
        graph = DependencyGraph()
        assert graph.get_wave_count() == 0

        graph.add_task("A")
        assert graph.get_wave_count() == 1

        graph.add_task("B", depends_on=["A"])
        assert graph.get_wave_count() == 2

    def test_get_tasks_in_wave(self):
        """get_tasks_in_wave should return tasks in specific wave."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B")
        graph.add_task("C", depends_on=["A", "B"])

        wave0 = graph.get_tasks_in_wave(0)
        assert set(wave0) == {"A", "B"}

        wave1 = graph.get_tasks_in_wave(1)
        assert wave1 == ["C"]

    def test_get_tasks_in_wave_invalid_index(self):
        """get_tasks_in_wave should raise on invalid index."""
        graph = DependencyGraph()
        graph.add_task("A")

        with pytest.raises(IndexError):
            graph.get_tasks_in_wave(5)

    def test_empty_task_id_raises(self):
        """add_task should raise on empty task_id."""
        graph = DependencyGraph()

        with pytest.raises(ValueError):
            graph.add_task("")


class TestDependencyGraphIntegration:
    """Integration tests for DependencyGraph."""

    def test_success_criteria_case_1(self):
        """Given tasks A, B (no deps) and C (depends on A, B) -> waves = [[A, B], [C]]."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B")
        graph.add_task("C", depends_on=["A", "B"])

        waves = graph.get_waves()

        # Wave 0: A and B (independent)
        assert len(waves) == 2
        assert set(waves[0]) == {"A", "B"}
        assert waves[1] == ["C"]

    def test_success_criteria_case_2(self):
        """Given circular dependency A->B->A -> ValueError raised with cycle details."""
        graph = DependencyGraph()
        graph.add_task("A")
        graph.add_task("B", depends_on=["A"])
        # Create cycle
        graph._graph.add_edge("B", "A")

        with pytest.raises(ValueError) as exc_info:
            graph.get_waves()

        error_msg = str(exc_info.value)
        assert "Circular" in error_msg
