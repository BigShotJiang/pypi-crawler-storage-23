"""
Tests for GSD-RLM Session Resumption.

Tests full context restoration for session resumption, including
H-MEM episodes, Memory Bridge facts, and continuation prompts.
"""

import tempfile
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import Mock, patch, AsyncMock, MagicMock
import asyncio

import pytest

from gsd_rlm.memory.integration.session_bridge import (
    SessionResumption,
    ResumptionContext,
)
from gsd_rlm.session.memory import FileSessionMemory, SessionState, SessionMessage
from gsd_rlm.memory.hmem.store import EpisodeStore
from gsd_rlm.memory.hmem.episode import Episode, EpisodeType
from gsd_rlm.memory.bridge.store import MemoryBridge
from gsd_rlm.memory.bridge.facts import BridgeFact, BridgeLevel


# ==============================================================================
# Fixtures
# ==============================================================================


@pytest.fixture
def temp_dir():
    """Create a temporary directory for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def session_memory(temp_dir):
    """Create a FileSessionMemory instance for testing."""
    sessions_dir = temp_dir / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    return FileSessionMemory(sessions_dir)


@pytest.fixture
def episode_store(temp_dir):
    """Create an EpisodeStore instance for testing."""
    db_path = temp_dir / "memory" / "hmem.db"
    return EpisodeStore(str(db_path))


@pytest.fixture
def memory_bridge(temp_dir):
    """Create a MemoryBridge instance for testing."""
    return MemoryBridge(temp_dir)


@pytest.fixture
def session_resumption(session_memory, episode_store, memory_bridge):
    """Create a SessionResumption instance with all components."""
    return SessionResumption(
        session_memory=session_memory,
        episode_store=episode_store,
        memory_bridge=memory_bridge,
    )


@pytest.fixture
def populated_session(session_memory):
    """Create a session with test data."""
    session = session_memory.create("test-session-001", "test-agent")
    session_memory.add_message(session, "user", "Please implement the feature")
    session_memory.add_message(session, "agent", "I'll start by analyzing the code")
    session_memory.add_task_output(
        session,
        task="Analyze codebase structure",
        result={"files": ["main.py", "utils.py"]},
        success=True,
    )
    session.current_task = "Implement feature X"
    session_memory.save(session)
    return session


@pytest.fixture
def populated_episode_store(episode_store):
    """Create an episode store with test episodes."""
    for i in range(5):
        episode = Episode(
            episode_id=f"ep-{i:03d}",
            agent_id="test-agent",
            session_id="test-session-001",
            episode_type=EpisodeType.TASK_EXECUTION,
            context=f"Task context {i}",
            action=f"Task action {i}",
            outcome=f"Task outcome {i}",
            success=i % 2 == 0,  # Alternate success/failure
            tags=[f"tag{i}"],
        )
        episode_store.store(episode)
    return episode_store


@pytest.fixture
def populated_memory_bridge(memory_bridge):
    """Create a memory bridge with test facts."""
    # Store project facts
    project_fact = BridgeFact.create(
        level=BridgeLevel.L2_PROJECT,
        scope_id="project",
        key="python_version",
        value="3.12",
        source="config",
    )
    memory_bridge.store_fact(project_fact)

    # Store phase facts
    phase_fact = BridgeFact.create(
        level=BridgeLevel.L1_PHASE,
        scope_id="03-memory-systems-infiniretri",
        key="phase_progress",
        value={"completed": 5, "total": 6},
        source="roadmap",
    )
    memory_bridge.store_fact(phase_fact)

    return memory_bridge


# ==============================================================================
# ResumptionContext Tests
# ==============================================================================


class TestResumptionContext:
    """Tests for ResumptionContext dataclass."""

    def test_resumption_context_creation(self):
        """Test creating a ResumptionContext instance."""
        context = ResumptionContext(
            session_id="test-001",
            session_data={"agent_name": "test-agent"},
            recent_episodes=[{"action": "test"}],
            project_facts={"key": "value"},
            last_task="Last task",
            next_suggested_actions=["Action 1", "Action 2"],
        )

        assert context.session_id == "test-001"
        assert context.session_data["agent_name"] == "test-agent"
        assert len(context.recent_episodes) == 1
        assert context.project_facts["key"] == "value"
        assert context.last_task == "Last task"
        assert len(context.next_suggested_actions) == 2

    def test_resumption_context_defaults(self):
        """Test ResumptionContext default values."""
        context = ResumptionContext(session_id="test-001")

        assert context.session_data == {}
        assert context.recent_episodes == []
        assert context.relevant_traces == []
        assert context.project_facts == {}
        assert context.phase_facts == {}
        assert context.last_task is None
        assert context.next_suggested_actions == []
        assert context.restored_at  # Should have a timestamp

    def test_resumption_context_to_dict(self):
        """Test converting ResumptionContext to dictionary."""
        context = ResumptionContext(
            session_id="test-001",
            session_data={"key": "value"},
            last_task="Task",
        )

        data = context.to_dict()

        assert data["session_id"] == "test-001"
        assert data["session_data"] == {"key": "value"}
        assert data["last_task"] == "Task"
        assert "restored_at" in data

    def test_resumption_context_from_dict(self):
        """Test creating ResumptionContext from dictionary."""
        data = {
            "session_id": "test-001",
            "session_data": {"agent": "test"},
            "recent_episodes": [{"action": "test"}],
            "project_facts": {"key": "value"},
            "last_task": "Task",
            "next_suggested_actions": ["Action"],
            "restored_at": "2024-01-01T00:00:00Z",
        }

        context = ResumptionContext.from_dict(data)

        assert context.session_id == "test-001"
        assert context.session_data == {"agent": "test"}
        assert len(context.recent_episodes) == 1
        assert context.project_facts["key"] == "value"


# ==============================================================================
# SessionResumption Tests
# ==============================================================================


class TestSessionResumptionInit:
    """Tests for SessionResumption initialization."""

    def test_session_resumption_init(
        self, session_memory, episode_store, memory_bridge
    ):
        """Test SessionResumption initialization."""
        resumption = SessionResumption(
            session_memory=session_memory,
            episode_store=episode_store,
            memory_bridge=memory_bridge,
        )

        assert resumption.session_memory is session_memory
        assert resumption.episode_store is episode_store
        assert resumption.memory_bridge is memory_bridge

    def test_session_resumption_init_none(self):
        """Test SessionResumption with no components."""
        resumption = SessionResumption()

        assert resumption.session_memory is None
        assert resumption.episode_store is None
        assert resumption.memory_bridge is None


class TestSessionResumptionResume:
    """Tests for the resume method."""

    @pytest.mark.asyncio
    async def test_session_resumption_resume(
        self,
        session_resumption,
        populated_session,
        populated_episode_store,
        populated_memory_bridge,
    ):
        """Test full resumption flow."""
        context = await session_resumption.resume("test-session-001")

        assert context.session_id == "test-session-001"
        assert context.session_data["agent_name"] == "test-agent"
        assert len(context.recent_episodes) == 5
        assert "python_version" in context.project_facts
        assert context.last_task is not None

    @pytest.mark.asyncio
    async def test_session_resumption_missing_session(self, session_resumption):
        """Test resumption with missing session."""
        with pytest.raises(ValueError, match="Session not found"):
            await session_resumption.resume("nonexistent-session")

    @pytest.mark.asyncio
    async def test_session_resumption_no_episode_store(
        self, session_memory, populated_session
    ):
        """Test resumption without episode store."""
        resumption = SessionResumption(session_memory=session_memory)
        context = await resumption.resume("test-session-001")

        assert context.recent_episodes == []

    @pytest.mark.asyncio
    async def test_session_resumption_no_memory_bridge(
        self, session_memory, populated_session
    ):
        """Test resumption without memory bridge."""
        resumption = SessionResumption(session_memory=session_memory)
        context = await resumption.resume("test-session-001")

        assert context.project_facts == {}
        assert context.phase_facts == {}


class TestGenerateResumptionPrompt:
    """Tests for generate_resumption_prompt method."""

    def test_generate_resumption_prompt_basic(self, session_resumption):
        """Test basic prompt generation."""
        context = ResumptionContext(
            session_id="test-001",
            last_task="Implement feature X",
            next_suggested_actions=["Continue with tests"],
        )

        prompt = session_resumption.generate_resumption_prompt(context)

        assert "# Session Resumption Context" in prompt
        assert "test-001" in prompt
        assert "Implement feature X" in prompt
        assert "Continue with tests" in prompt

    def test_generate_resumption_prompt_with_episodes(self, session_resumption):
        """Test prompt generation with episodes."""
        context = ResumptionContext(
            session_id="test-001",
            recent_episodes=[
                {"action": "Write tests", "success": True},
                {"action": "Fix bug", "success": False},
            ],
        )

        prompt = session_resumption.generate_resumption_prompt(context)

        assert "## Recent Episodes" in prompt
        assert "Write tests" in prompt

    def test_generate_resumption_prompt_with_facts(self, session_resumption):
        """Test prompt generation with facts."""
        context = ResumptionContext(
            session_id="test-001",
            project_facts={"python_version": "3.12", "framework": "pytest"},
            phase_facts={"progress": "50%"},
        )

        prompt = session_resumption.generate_resumption_prompt(context)

        assert "## Project Facts" in prompt
        assert "python_version" in prompt

    def test_generate_resumption_prompt_continuation(self, session_resumption):
        """Test prompt contains continuation instructions."""
        context = ResumptionContext(
            session_id="test-001",
            last_task="Previous task",
            next_suggested_actions=["Next step"],
        )

        prompt = session_resumption.generate_resumption_prompt(context)

        assert "## Continuation Prompt" in prompt
        assert "resuming a previous session" in prompt


# ==============================================================================
# IntegratedMemorySystem Tests (for Task 3)
# ==============================================================================


class TestIntegratedMemorySystem:
    """Tests for IntegratedMemorySystem facade class."""

    def test_integrated_memory_system_import(self):
        """Test that IntegratedMemorySystem can be imported."""
        from gsd_rlm.session.memory import IntegratedMemorySystem

        assert IntegratedMemorySystem is not None

    def test_integrated_memory_system_init(self, temp_dir):
        """Test IntegratedMemorySystem initialization."""
        from gsd_rlm.session.memory import IntegratedMemorySystem

        # Create planning directory structure
        planning_dir = temp_dir / ".planning"
        planning_dir.mkdir(parents=True, exist_ok=True)
        (planning_dir / "phases").mkdir(parents=True, exist_ok=True)
        (planning_dir / "sessions").mkdir(parents=True, exist_ok=True)

        system = IntegratedMemorySystem(temp_dir)

        assert system.project_root == temp_dir
        assert system.session_memory is not None
        assert system.episode_store is not None
        assert system.memory_bridge is not None

    def test_integrated_memory_record_experience(self, temp_dir):
        """Test recording an experience via IntegratedMemorySystem."""
        from gsd_rlm.session.memory import IntegratedMemorySystem
        from gsd_rlm.memory.hmem.episode import EpisodeType

        # Create planning directory structure
        planning_dir = temp_dir / ".planning"
        planning_dir.mkdir(parents=True, exist_ok=True)
        (planning_dir / "phases").mkdir(parents=True, exist_ok=True)
        (planning_dir / "sessions").mkdir(parents=True, exist_ok=True)

        system = IntegratedMemorySystem(temp_dir)

        episode = system.record_experience(
            session_id="test-session",
            agent_id="test-agent",
            context="User requested a feature",
            action="Analyzed codebase",
            outcome="Found relevant files",
            success=True,
            episode_type=EpisodeType.TASK_EXECUTION,
            tags=["analysis"],
        )

        assert episode.episode_id.startswith("ep-")
        assert episode.session_id == "test-session"
        assert episode.agent_id == "test-agent"
        assert episode.success is True
        assert "analysis" in episode.tags

    def test_integrated_memory_store_fact(self, temp_dir):
        """Test storing a fact via IntegratedMemorySystem."""
        from gsd_rlm.session.memory import IntegratedMemorySystem

        # Create planning directory structure
        planning_dir = temp_dir / ".planning"
        planning_dir.mkdir(parents=True, exist_ok=True)
        (planning_dir / "phases").mkdir(parents=True, exist_ok=True)
        (planning_dir / "sessions").mkdir(parents=True, exist_ok=True)

        system = IntegratedMemorySystem(temp_dir)

        fact = system.store_project_fact(
            key="test_fact",
            value="test_value",
            source="test",
        )

        assert fact.key == "test_fact"
        assert fact.value == "test_value"
        assert fact.source == "test"

    def test_integrated_memory_create_session(self, temp_dir):
        """Test creating a session via IntegratedMemorySystem."""
        from gsd_rlm.session.memory import IntegratedMemorySystem

        # Create planning directory structure
        planning_dir = temp_dir / ".planning"
        planning_dir.mkdir(parents=True, exist_ok=True)
        (planning_dir / "phases").mkdir(parents=True, exist_ok=True)
        (planning_dir / "sessions").mkdir(parents=True, exist_ok=True)

        system = IntegratedMemorySystem(temp_dir)

        session = system.create_session("test-session-001", "test-agent")

        assert session.session_id == "test-session-001"
        assert session.agent_name == "test-agent"

    def test_integrated_memory_list_sessions(self, temp_dir):
        """Test listing sessions via IntegratedMemorySystem."""
        from gsd_rlm.session.memory import IntegratedMemorySystem

        # Create planning directory structure
        planning_dir = temp_dir / ".planning"
        planning_dir.mkdir(parents=True, exist_ok=True)
        (planning_dir / "phases").mkdir(parents=True, exist_ok=True)
        (planning_dir / "sessions").mkdir(parents=True, exist_ok=True)

        system = IntegratedMemorySystem(temp_dir)

        # Create some sessions
        system.create_session("session-1", "agent-1")
        system.create_session("session-2", "agent-2")

        sessions = system.list_sessions()

        assert len(sessions) == 2
        session_ids = [s["session_id"] for s in sessions]
        assert "session-1" in session_ids
        assert "session-2" in session_ids

    @pytest.mark.asyncio
    async def test_integrated_memory_resume_session(self, temp_dir):
        """Test resuming a session via IntegratedMemorySystem."""
        from gsd_rlm.session.memory import IntegratedMemorySystem

        # Create planning directory structure
        planning_dir = temp_dir / ".planning"
        planning_dir.mkdir(parents=True, exist_ok=True)
        (planning_dir / "phases").mkdir(parents=True, exist_ok=True)
        (planning_dir / "sessions").mkdir(parents=True, exist_ok=True)

        system = IntegratedMemorySystem(temp_dir)

        # Create a session
        session = system.create_session("resume-test-session", "test-agent")

        # Resume the session
        context = await system.resume_session("resume-test-session")

        assert context.session_id == "resume-test-session"
        assert context.session_data["agent_name"] == "test-agent"

    @pytest.mark.asyncio
    async def test_integrated_memory_get_context_for_task(self, temp_dir):
        """Test getting context for a task via IntegratedMemorySystem."""
        from gsd_rlm.session.memory import IntegratedMemorySystem

        # Create planning directory structure
        planning_dir = temp_dir / ".planning"
        planning_dir.mkdir(parents=True, exist_ok=True)
        (planning_dir / "phases").mkdir(parents=True, exist_ok=True)
        (planning_dir / "sessions").mkdir(parents=True, exist_ok=True)

        system = IntegratedMemorySystem(temp_dir)

        # Create a session
        system.create_session("context-test-session", "test-agent")

        # Get context for a task
        context = await system.get_context_for_task(
            session_id="context-test-session",
            task="fix the bug",
            max_stores=3,
        )

        assert "assembled_context" in context
        assert "llm_context" in context


# ==============================================================================
# End-to-End Tests
# ==============================================================================


class TestEndToEndResumption:
    """End-to-end tests for session resumption."""

    @pytest.mark.asyncio
    async def test_end_to_end_resumption(
        self,
        temp_dir,
        session_memory,
        episode_store,
        memory_bridge,
    ):
        """Test complete resumption flow from start to finish."""
        # 1. Create and populate session
        session = session_memory.create("e2e-session", "e2e-agent")
        session_memory.add_message(session, "user", "Start the task")
        session_memory.add_task_output(
            session,
            task="Initialize project",
            result={"status": "done"},
            success=True,
        )
        session.current_task = "Implement core feature"
        session_memory.save(session)

        # 2. Create episodes
        for i in range(3):
            episode = Episode(
                episode_id=f"e2e-ep-{i}",
                agent_id="e2e-agent",
                session_id="e2e-session",
                episode_type=EpisodeType.TASK_EXECUTION,
                action=f"E2E action {i}",
                outcome=f"E2E outcome {i}",
                success=True,
            )
            episode_store.store(episode)

        # 3. Store facts
        fact = BridgeFact.create(
            level=BridgeLevel.L2_PROJECT,
            scope_id="project",
            key="project_name",
            value="test-project",
        )
        memory_bridge.store_fact(fact)

        # 4. Resume session
        resumption = SessionResumption(
            session_memory=session_memory,
            episode_store=episode_store,
            memory_bridge=memory_bridge,
        )
        context = await resumption.resume("e2e-session")

        # 5. Verify context
        assert context.session_id == "e2e-session"
        assert len(context.recent_episodes) == 3
        assert context.project_facts.get("project_name") == "test-project"
        assert context.last_task == "Implement core feature"

        # 6. Generate prompt
        prompt = resumption.generate_resumption_prompt(context)
        assert "e2e-session" in prompt
        assert "Implement core feature" in prompt

    @pytest.mark.asyncio
    async def test_resumption_with_failed_episodes(
        self, session_memory, episode_store, populated_session
    ):
        """Test resumption includes failed episodes in suggestions."""
        # Create failed episodes
        for i in range(3):
            episode = Episode(
                episode_id=f"fail-ep-{i}",
                agent_id="test-agent",
                session_id="test-session-001",
                episode_type=EpisodeType.ERROR_RECOVERY,
                action=f"Failed action {i}",
                outcome="Error occurred",
                success=False,
            )
            episode_store.store(episode)

        resumption = SessionResumption(
            session_memory=session_memory,
            episode_store=episode_store,
        )
        context = await resumption.resume("test-session-001")

        # Should suggest retrying failed actions
        assert any(
            "retry" in action.lower() or "failed" in action.lower()
            for action in context.next_suggested_actions
        )
