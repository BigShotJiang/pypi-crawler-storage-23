"""
Comprehensive tests for H-MEM consolidation (Levels 1-3).

Tests for:
- Trace dataclass and serialization
- TraceConsolidator (with and without LLM)
- Category dataclass and CategoryManager
- DomainKnowledge dataclass and DomainKnowledgeExtractor
- Background ConsolidationJob
"""

import asyncio
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from gsd_rlm.memory.hmem.episode import Episode, EpisodeType
from gsd_rlm.memory.hmem.store import EpisodeStore
from gsd_rlm.memory.hmem.trace import Trace, TraceConsolidator
from gsd_rlm.memory.hmem.category import Category, CategoryManager, CategoryType
from gsd_rlm.memory.hmem.domain import DomainKnowledge, DomainKnowledgeExtractor
from gsd_rlm.memory.hmem.consolidation import ConsolidationJob


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def temp_db():
    """Create a temporary database file."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    yield db_path
    # Cleanup
    try:
        os.unlink(db_path)
    except OSError:
        pass


@pytest.fixture
def episode_store(temp_db):
    """Create an EpisodeStore with temp database."""
    return EpisodeStore(db_path=temp_db)


@pytest.fixture
def sample_episode():
    """Create a sample episode for testing."""
    return Episode(
        episode_id="ep_001",
        agent_id="agent_001",
        session_id="session_001",
        episode_type=EpisodeType.TASK_EXECUTION,
        context="Implementing user authentication",
        action="Created login endpoint",
        outcome="Successfully implemented OAuth2 flow",
        success=True,
        tags=["auth", "oauth"],
    )


@pytest.fixture
def sample_episodes():
    """Create multiple sample episodes for testing."""
    episodes = []
    for i in range(5):
        ep = Episode(
            episode_id=f"ep_{i:03d}",
            agent_id="agent_001",
            session_id="session_001",
            episode_type=EpisodeType.TASK_EXECUTION,
            context=f"Task context {i}",
            action=f"Action {i}",
            outcome=f"Outcome {i}",
            success=(i % 2 == 0),  # Alternate success/failure
            tags=[f"tag_{i}"],
        )
        episodes.append(ep)
    return episodes


# =============================================================================
# Trace Dataclass Tests
# =============================================================================


class TestTraceDataclass:
    """Tests for Trace dataclass."""

    def test_trace_creation(self):
        """Test basic Trace creation."""
        trace = Trace(
            trace_id="trace_001",
            agent_id="agent_001",
            session_id="session_001",
            theme="Authentication implementation",
        )

        assert trace.trace_id == "trace_001"
        assert trace.agent_id == "agent_001"
        assert trace.session_id == "session_001"
        assert trace.theme == "Authentication implementation"
        assert trace.episode_ids == []
        assert trace.episode_count == 0
        assert trace.summary == ""
        assert trace.patterns_identified == []
        assert trace.lessons_learned == []
        assert trace.overall_success is False
        assert trace.category_id is None

    def test_trace_to_dict(self):
        """Test Trace serialization to dictionary."""
        trace = Trace(
            trace_id="trace_001",
            agent_id="agent_001",
            session_id="session_001",
            theme="Testing theme",
            episode_ids=["ep_001", "ep_002"],
            summary="Test summary",
            patterns_identified=["pattern1"],
            lessons_learned=["lesson1"],
            overall_success=True,
        )

        data = trace.to_dict()

        assert data["trace_id"] == "trace_001"
        assert data["agent_id"] == "agent_001"
        assert data["session_id"] == "session_001"
        assert data["theme"] == "Testing theme"
        assert data["episode_ids"] == ["ep_001", "ep_002"]
        assert data["summary"] == "Test summary"
        assert data["patterns_identified"] == ["pattern1"]
        assert data["lessons_learned"] == ["lesson1"]
        assert data["overall_success"] is True

    def test_trace_from_dict(self):
        """Test Trace deserialization from dictionary."""
        data = {
            "trace_id": "trace_001",
            "agent_id": "agent_001",
            "session_id": "session_001",
            "theme": "From dict theme",
            "episode_ids": ["ep_001"],
            "episode_count": 1,
            "summary": "From dict summary",
            "patterns_identified": ["p1", "p2"],
            "lessons_learned": ["l1"],
            "overall_success": True,
            "category_id": "cat_001",
        }

        trace = Trace.from_dict(data)

        assert trace.trace_id == "trace_001"
        assert trace.agent_id == "agent_001"
        assert trace.theme == "From dict theme"
        assert trace.episode_ids == ["ep_001"]
        assert trace.patterns_identified == ["p1", "p2"]
        assert trace.category_id == "cat_001"

    def test_trace_is_categorized(self):
        """Trace is_categorized property."""
        trace_no_category = Trace(
            trace_id="trace_001",
            agent_id="agent_001",
            session_id="session_001",
            theme="Test",
        )
        assert trace_no_category.is_categorized is False

        trace_with_category = Trace(
            trace_id="trace_002",
            agent_id="agent_001",
            session_id="session_001",
            theme="Test",
            category_id="cat_001",
        )
        assert trace_with_category.is_categorized is True


# =============================================================================
# Trace Consolidation Tests
# =============================================================================


class TestTraceConsolidation:
    """Tests for TraceConsolidator."""

    @pytest.mark.asyncio
    async def test_consolidate_empty_session(self, episode_store):
        """Test consolidation with no episodes."""
        consolidator = TraceConsolidator(episode_store)
        trace = await consolidator.consolidate_session("empty_session")
        assert trace is None

    @pytest.mark.asyncio
    async def test_consolidate_session_without_llm(
        self, episode_store, sample_episodes
    ):
        """Test consolidation without LLM provider."""
        # Store episodes
        for ep in sample_episodes:
            episode_store.store(ep)

        consolidator = TraceConsolidator(episode_store)
        trace = await consolidator.consolidate_session("session_001")

        assert trace is not None
        assert trace.session_id == "session_001"
        assert trace.agent_id == "agent_001"
        assert len(trace.episode_ids) == 5
        assert trace.episode_count == 5
        assert trace.theme != ""  # Should have some theme
        assert trace.summary != ""  # Should have summary

    @pytest.mark.asyncio
    async def test_consolidate_session_updates_episodes(
        self, episode_store, sample_episodes
    ):
        """Test that consolidation updates episode trace_ids."""
        # Store episodes
        for ep in sample_episodes:
            episode_store.store(ep)

        consolidator = TraceConsolidator(episode_store)
        trace = await consolidator.consolidate_session("session_001")

        # Verify episodes now have trace_id
        for ep_id in trace.episode_ids:
            stored_ep = episode_store.get(ep_id)
            assert stored_ep.trace_id == trace.trace_id
            assert stored_ep.is_consolidated is True

    @pytest.mark.asyncio
    async def test_consolidate_session_already_consolidated(
        self, episode_store, sample_episodes
    ):
        """Test that already consolidated episodes are skipped."""
        # Store episodes and mark as consolidated
        for ep in sample_episodes:
            ep.mark_consolidated("existing_trace")
            episode_store.store(ep)

        consolidator = TraceConsolidator(episode_store)
        trace = await consolidator.consolidate_session("session_001")

        # No unconsolidated episodes, should return None
        assert trace is None


class TestTraceConsolidationWithLLM:
    """Tests for TraceConsolidator with LLM."""

    @pytest.mark.asyncio
    async def test_consolidate_with_mock_llm(self, episode_store, sample_episodes):
        """Test consolidation with mock LLM provider."""
        # Store episodes
        for ep in sample_episodes:
            episode_store.store(ep)

        # Create mock LLM provider
        mock_llm = AsyncMock()
        mock_llm.generate.return_value = json.dumps(
            {
                "theme": "Feature Development Session",
                "summary": "Implemented multiple features successfully",
                "patterns": ["iterative development", "test-driven"],
                "lessons": ["early testing saves time"],
                "overall_success": True,
            }
        )

        consolidator = TraceConsolidator(episode_store, llm_provider=mock_llm)
        trace = await consolidator.consolidate_session("session_001")

        assert trace is not None
        assert trace.theme == "Feature Development Session"
        assert trace.summary == "Implemented multiple features successfully"
        assert "iterative development" in trace.patterns_identified
        assert "early testing saves time" in trace.lessons_learned
        assert trace.overall_success is True

    @pytest.mark.asyncio
    async def test_consolidate_llm_fallback_on_error(
        self, episode_store, sample_episodes
    ):
        """Test that LLM errors fall back to simple aggregation."""
        # Store episodes
        for ep in sample_episodes:
            episode_store.store(ep)

        # Create mock LLM that raises error
        mock_llm = AsyncMock()
        mock_llm.generate.side_effect = Exception("LLM error")

        consolidator = TraceConsolidator(episode_store, llm_provider=mock_llm)
        trace = await consolidator.consolidate_session("session_001")

        # Should still create trace with simple aggregation
        assert trace is not None
        assert trace.session_id == "session_001"


# =============================================================================
# Category Dataclass Tests
# =============================================================================


class TestCategoryDataclass:
    """Tests for Category dataclass."""

    def test_category_creation(self):
        """Test basic Category creation."""
        category = Category(
            category_id="cat_001",
            category_type=CategoryType.DEBUGGING,
            name="Debugging",
            description="Debugging activities",
        )

        assert category.category_id == "cat_001"
        assert category.category_type == CategoryType.DEBUGGING
        assert category.name == "Debugging"
        assert category.trace_ids == []
        assert category.trace_count == 0
        assert category.success_rate == 0.0

    def test_category_to_dict(self):
        """Test Category serialization."""
        category = Category(
            category_id="cat_001",
            category_type=CategoryType.FEATURE_DEVELOPMENT,
            name="Features",
            trace_ids=["trace_001"],
            common_patterns=["pattern1"],
            success_rate=0.8,
        )

        data = category.to_dict()

        assert data["category_id"] == "cat_001"
        assert data["category_type"] == "feature_development"
        assert data["name"] == "Features"
        assert data["trace_ids"] == ["trace_001"]
        assert data["success_rate"] == 0.8

    def test_category_from_dict(self):
        """Test Category deserialization."""
        data = {
            "category_id": "cat_001",
            "category_type": "testing",
            "name": "Testing",
            "description": "Test activities",
            "trace_ids": ["trace_001", "trace_002"],
            "common_patterns": ["unit tests", "integration tests"],
            "success_rate": 0.9,
        }

        category = Category.from_dict(data)

        assert category.category_id == "cat_001"
        assert category.category_type == CategoryType.TESTING
        assert category.name == "Testing"
        assert len(category.trace_ids) == 2

    def test_category_has_domain(self):
        """Test has_domain property."""
        no_domain = Category(
            category_id="cat_001",
            category_type=CategoryType.DEBUGGING,
            name="Debugging",
        )
        assert no_domain.has_domain is False

        with_domain = Category(
            category_id="cat_002",
            category_type=CategoryType.DEBUGGING,
            name="Debugging",
            domain_id="domain_001",
        )
        assert with_domain.has_domain is True


# =============================================================================
# CategoryManager Tests
# =============================================================================


class TestCategoryManager:
    """Tests for CategoryManager."""

    def test_category_manager_init(self, temp_db):
        """Test CategoryManager initialization."""
        manager = CategoryManager(db_path=temp_db)
        assert manager.count() == 0

    def test_get_category_for_episode_type(self, temp_db):
        """Test EpisodeType to CategoryType mapping."""
        manager = CategoryManager(db_path=temp_db)

        assert (
            manager.get_category_for_episode_type(EpisodeType.TASK_EXECUTION)
            == CategoryType.FEATURE_DEVELOPMENT
        )
        assert (
            manager.get_category_for_episode_type(EpisodeType.PROBLEM_SOLVING)
            == CategoryType.DEBUGGING
        )
        assert (
            manager.get_category_for_episode_type(EpisodeType.ERROR_RECOVERY)
            == CategoryType.DEBUGGING
        )
        assert (
            manager.get_category_for_episode_type(EpisodeType.LEARNING)
            == CategoryType.DOCUMENTATION
        )
        assert (
            manager.get_category_for_episode_type(EpisodeType.COLLABORATION)
            == CategoryType.COLLABORATION
        )

    def test_categorize_trace(self, temp_db):
        """Test trace categorization."""
        manager = CategoryManager(db_path=temp_db)

        trace = Trace(
            trace_id="trace_001",
            agent_id="agent_001",
            session_id="session_001",
            theme="Test trace",
            patterns_identified=["test pattern"],
            overall_success=True,
        )

        category = manager.categorize_trace(
            trace, category_type=CategoryType.FEATURE_DEVELOPMENT
        )

        assert category is not None
        assert category.category_type == CategoryType.FEATURE_DEVELOPMENT
        assert trace.trace_id in category.trace_ids
        assert trace.category_id == category.category_id

    def test_get_traces_for_category(self, temp_db):
        """Test retrieving traces for a category."""
        manager = CategoryManager(db_path=temp_db)

        trace = Trace(
            trace_id="trace_001",
            agent_id="agent_001",
            session_id="session_001",
            theme="Test trace",
        )

        category = manager.categorize_trace(trace, category_type=CategoryType.DEBUGGING)

        trace_ids = manager.get_traces_for_category(category.category_id)
        assert "trace_001" in trace_ids

    def test_get_all_categories(self, temp_db):
        """Test retrieving all categories."""
        manager = CategoryManager(db_path=temp_db)

        # Create a category by categorizing a trace
        trace = Trace(
            trace_id="trace_001",
            agent_id="agent_001",
            session_id="session_001",
            theme="Test",
        )
        manager.categorize_trace(trace, CategoryType.DEBUGGING)

        categories = manager.get_all_categories()
        assert len(categories) >= 1


# =============================================================================
# DomainKnowledge Tests
# =============================================================================


class TestDomainKnowledge:
    """Tests for DomainKnowledge dataclass."""

    def test_domain_knowledge_creation(self):
        """Test basic DomainKnowledge creation."""
        domain = DomainKnowledge(
            domain_id="domain_001",
            domain_name="Python Development",
        )

        assert domain.domain_id == "domain_001"
        assert domain.domain_name == "Python Development"
        assert domain.principles == []
        assert domain.best_practices == []
        assert domain.confidence_score == 0.0
        assert domain.evidence_count == 0

    def test_domain_knowledge_to_dict(self):
        """Test DomainKnowledge serialization."""
        domain = DomainKnowledge(
            domain_id="domain_001",
            domain_name="API Design",
            principles=["RESTful design", "Version your APIs"],
            best_practices=["Use proper HTTP methods"],
            confidence_score=0.85,
            evidence_count=10,
        )

        data = domain.to_dict()

        assert data["domain_id"] == "domain_001"
        assert data["domain_name"] == "API Design"
        assert len(data["principles"]) == 2
        assert data["confidence_score"] == 0.85

    def test_domain_knowledge_from_dict(self):
        """Test DomainKnowledge deserialization."""
        data = {
            "domain_id": "domain_001",
            "domain_name": "Testing",
            "principles": ["Test early", "Test often"],
            "anti_patterns": ["Testing in production"],
            "confidence_score": 0.9,
            "evidence_count": 15,
        }

        domain = DomainKnowledge.from_dict(data)

        assert domain.domain_id == "domain_001"
        assert domain.domain_name == "Testing"
        assert len(domain.principles) == 2
        assert "Testing in production" in domain.anti_patterns

    def test_is_high_confidence(self):
        """Test is_high_confidence property."""
        low_confidence = DomainKnowledge(
            domain_id="d1",
            domain_name="Test",
            confidence_score=0.5,
        )
        assert low_confidence.is_high_confidence is False

        high_confidence = DomainKnowledge(
            domain_id="d2",
            domain_name="Test",
            confidence_score=0.8,
        )
        assert high_confidence.is_high_confidence is True

    def test_has_sufficient_evidence(self):
        """Test has_sufficient_evidence property."""
        insufficient = DomainKnowledge(
            domain_id="d1",
            domain_name="Test",
            evidence_count=3,
        )
        assert insufficient.has_sufficient_evidence is False

        sufficient = DomainKnowledge(
            domain_id="d2",
            domain_name="Test",
            evidence_count=7,
        )
        assert sufficient.has_sufficient_evidence is True


# =============================================================================
# DomainKnowledgeExtractor Tests
# =============================================================================


class TestDomainExtraction:
    """Tests for DomainKnowledgeExtractor."""

    def test_get_domain_name(self, temp_db):
        """Test domain name generation."""
        extractor = DomainKnowledgeExtractor()

        category = Category(
            category_id="cat_001",
            category_type=CategoryType.DEBUGGING,
            name="Debugging",
        )

        domain_name = extractor._get_domain_name(category)
        assert "Problem Solving" in domain_name or "Debugging" in domain_name

    @pytest.mark.asyncio
    async def test_extract_without_llm(self, temp_db):
        """Test domain extraction without LLM."""
        extractor = DomainKnowledgeExtractor()

        category = Category(
            category_id="cat_001",
            category_type=CategoryType.FEATURE_DEVELOPMENT,
            name="Features",
            effective_strategies=["Use TDD", "Write clean code"],
            success_rate=0.8,
        )

        traces = [
            Trace(
                trace_id=f"trace_{i}",
                agent_id="agent_001",
                session_id="session_001",
                theme=f"Feature {i}",
                patterns_identified=[f"pattern_{i}"],
                lessons_learned=[f"lesson_{i}"],
                overall_success=True,
            )
            for i in range(5)
        ]

        domain = await extractor.extract_domain_knowledge(category, traces)

        assert domain is not None
        assert domain.evidence_count == 5
        assert len(domain.principles) > 0
        assert len(domain.best_practices) > 0
        assert domain.confidence_score > 0

    @pytest.mark.asyncio
    async def test_extract_with_mock_llm(self, temp_db):
        """Test domain extraction with mock LLM."""
        # Create mock LLM
        mock_llm = AsyncMock()
        mock_llm.generate.return_value = json.dumps(
            {
                "principles": ["SOLID principles", "DRY"],
                "best_practices": ["Unit testing", "Code review"],
                "anti_patterns": ["Spaghetti code"],
                "decision_frameworks": ["Cost-benefit analysis"],
            }
        )

        extractor = DomainKnowledgeExtractor(llm_provider=mock_llm)

        category = Category(
            category_id="cat_001",
            category_type=CategoryType.FEATURE_DEVELOPMENT,
            name="Features",
            success_rate=0.9,
        )

        traces = [
            Trace(
                trace_id=f"trace_{i}",
                agent_id="agent_001",
                session_id="session_001",
                theme=f"Feature {i}",
            )
            for i in range(3)
        ]

        domain = await extractor.extract_domain_knowledge(category, traces)

        assert domain is not None
        assert "SOLID principles" in domain.principles
        assert "Unit testing" in domain.best_practices
        assert "Spaghetti code" in domain.anti_patterns

    def test_calculate_confidence(self):
        """Test confidence calculation."""
        extractor = DomainKnowledgeExtractor()

        category = Category(
            category_id="cat_001",
            category_type=CategoryType.DEBUGGING,
            name="Debugging",
            success_rate=0.8,
        )

        # 5 traces
        traces = [MagicMock() for _ in range(5)]
        confidence = extractor._calculate_confidence(traces, category)
        assert 0 < confidence <= 0.5  # 5/10 * 0.8 = 0.4

        # 10 traces
        traces = [MagicMock() for _ in range(10)]
        confidence = extractor._calculate_confidence(traces, category)
        assert confidence == 0.8  # 1.0 * 0.8


# =============================================================================
# ConsolidationJob Tests
# =============================================================================


class TestConsolidationJob:
    """Tests for ConsolidationJob."""

    @pytest.mark.asyncio
    async def test_consolidation_job_init(self, episode_store):
        """Test ConsolidationJob initialization."""
        consolidator = TraceConsolidator(episode_store)
        job = ConsolidationJob(
            episode_store=episode_store,
            trace_consolidator=consolidator,
        )

        assert job.is_running is False
        assert job.last_consolidation is None

    @pytest.mark.asyncio
    async def test_run_once_no_episodes(self, episode_store):
        """Test run_once with no episodes."""
        consolidator = TraceConsolidator(episode_store)
        job = ConsolidationJob(
            episode_store=episode_store,
            trace_consolidator=consolidator,
        )

        traces_created = await job.run_once()
        assert traces_created == 0

    @pytest.mark.asyncio
    async def test_run_once_with_episodes(self, episode_store, sample_episodes):
        """Test run_once with episodes."""
        for ep in sample_episodes:
            episode_store.store(ep)

        consolidator = TraceConsolidator(episode_store)
        job = ConsolidationJob(
            episode_store=episode_store,
            trace_consolidator=consolidator,
        )

        traces_created = await job.run_once()
        assert traces_created == 1
        assert job.last_consolidation is not None

    @pytest.mark.asyncio
    async def test_should_consolidate_below_threshold(
        self, episode_store, sample_episodes
    ):
        """Test _should_consolidate below threshold."""
        # Store only 5 episodes (below default threshold of 100)
        for ep in sample_episodes:
            episode_store.store(ep)

        consolidator = TraceConsolidator(episode_store)
        job = ConsolidationJob(
            episode_store=episode_store,
            trace_consolidator=consolidator,
            episode_threshold=100,  # Default
        )

        assert job._should_consolidate() is False

    @pytest.mark.asyncio
    async def test_should_consolidate_above_threshold(self, episode_store):
        """Test _should_consolidate above threshold."""
        # Create many episodes
        for i in range(150):
            ep = Episode(
                episode_id=f"ep_{i:04d}",
                agent_id="agent_001",
                session_id=f"session_{i // 50}",  # 3 sessions
                episode_type=EpisodeType.TASK_EXECUTION,
                context=f"Context {i}",
                action=f"Action {i}",
                outcome=f"Outcome {i}",
            )
            episode_store.store(ep)

        consolidator = TraceConsolidator(episode_store)
        job = ConsolidationJob(
            episode_store=episode_store,
            trace_consolidator=consolidator,
            episode_threshold=100,
        )

        assert job._should_consolidate() is True

    @pytest.mark.asyncio
    async def test_start_stop_job(self, episode_store):
        """Test starting and stopping the job."""
        consolidator = TraceConsolidator(episode_store)
        job = ConsolidationJob(
            episode_store=episode_store,
            trace_consolidator=consolidator,
            interval_seconds=1,  # Short interval for testing
        )

        # Start job
        await job.start()
        assert job.is_running is True

        # Let it run briefly
        await asyncio.sleep(0.1)

        # Stop job
        await job.stop()
        assert job.is_running is False

    @pytest.mark.asyncio
    async def test_consolidation_multiple_sessions(self, episode_store):
        """Test consolidation across multiple sessions."""
        # Create episodes in different sessions
        for session_num in range(3):
            for i in range(5):
                ep = Episode(
                    episode_id=f"ep_s{session_num}_{i}",
                    agent_id="agent_001",
                    session_id=f"session_{session_num}",
                    episode_type=EpisodeType.TASK_EXECUTION,
                    context=f"Context s{session_num} {i}",
                    action=f"Action s{session_num} {i}",
                    outcome=f"Outcome s{session_num} {i}",
                )
                episode_store.store(ep)

        consolidator = TraceConsolidator(episode_store)
        job = ConsolidationJob(
            episode_store=episode_store,
            trace_consolidator=consolidator,
        )

        traces_created = await job.run_once()
        assert traces_created == 3  # One trace per session


# =============================================================================
# Additional Coverage Tests
# =============================================================================


class TestTraceConsolidatorEdgeCases:
    """Additional tests for edge cases in TraceConsolidator."""

    @pytest.mark.asyncio
    async def test_build_consolidation_prompt(self, episode_store, sample_episodes):
        """Test prompt building for LLM."""
        consolidator = TraceConsolidator(episode_store)
        prompt = consolidator._build_consolidation_prompt(sample_episodes)

        assert "Episode 1" in prompt
        assert "task_execution" in prompt
        assert "Context:" in prompt
        assert "Action:" in prompt
        assert "Outcome:" in prompt
        assert "JSON" in prompt

    def test_parse_consolidation_response_valid_json(self, episode_store):
        """Test parsing valid JSON response."""
        consolidator = TraceConsolidator(episode_store)

        response = '{"theme": "Test", "summary": "Summary", "patterns": ["p1"], "lessons": ["l1"], "overall_success": true}'
        result = consolidator._parse_consolidation_response(response)

        assert result["theme"] == "Test"
        assert result["summary"] == "Summary"
        assert result["patterns"] == ["p1"]

    def test_parse_consolidation_response_embedded_json(self, episode_store):
        """Test parsing JSON embedded in text."""
        consolidator = TraceConsolidator(episode_store)

        response = 'Here is the result: {"theme": "Embedded", "summary": "S"}'
        result = consolidator._parse_consolidation_response(response)

        assert result["theme"] == "Embedded"

    def test_parse_consolidation_response_invalid(self, episode_store):
        """Test parsing invalid response returns defaults."""
        consolidator = TraceConsolidator(episode_store)

        result = consolidator._parse_consolidation_response("not valid json")

        assert result["theme"] == "Agent activity"
        assert result["patterns"] == []

    def test_simple_aggregation_empty_outcomes(self, episode_store):
        """Test simple aggregation with empty outcomes."""
        consolidator = TraceConsolidator(episode_store)

        trace = Trace(
            trace_id="trace_001",
            agent_id="agent_001",
            session_id="session_001",
            theme="",
        )

        episodes = [
            Episode(
                episode_id=f"ep_{i}",
                agent_id="agent_001",
                session_id="session_001",
                episode_type=EpisodeType.TASK_EXECUTION,
                context="",
                action="",
                outcome="",  # Empty outcome
            )
            for i in range(3)
        ]

        consolidator._simple_aggregation(trace, episodes)

        assert "Task Execution" in trace.theme  # Title case
        assert trace.summary != ""

    @pytest.mark.asyncio
    async def test_consolidate_with_callable_llm(self, episode_store, sample_episodes):
        """Test consolidation with callable LLM provider."""
        for ep in sample_episodes:
            episode_store.store(ep)

        def mock_llm(prompt):
            return '{"theme": "Callable", "summary": "Test", "patterns": [], "lessons": [], "overall_success": true}'

        consolidator = TraceConsolidator(episode_store, llm_provider=mock_llm)
        trace = await consolidator.consolidate_session("session_001")

        assert trace is not None
        assert trace.theme == "Callable"


class TestCategoryManagerEdgeCases:
    """Additional tests for CategoryManager edge cases."""

    def test_get_category_not_found(self, temp_db):
        """Test getting non-existent category."""
        manager = CategoryManager(db_path=temp_db)
        category = manager.get_category("nonexistent")
        assert category is None

    def test_get_categories_by_type_empty(self, temp_db):
        """Test getting categories when none exist."""
        manager = CategoryManager(db_path=temp_db)
        categories = manager.get_categories_by_type(CategoryType.TESTING)
        assert categories == []

    def test_update_category_stats(self, temp_db):
        """Test updating category stats."""
        manager = CategoryManager(db_path=temp_db)

        trace = Trace(
            trace_id="trace_001",
            agent_id="agent_001",
            session_id="session_001",
            theme="Test",
        )

        category = manager.categorize_trace(trace, CategoryType.DEBUGGING)
        category.success_rate = 0.95

        manager.update_category_stats(category)

        # Verify it was persisted
        retrieved = manager.get_category(category.category_id)
        assert retrieved.success_rate == 0.95


class TestDomainExtractorEdgeCases:
    """Additional tests for DomainKnowledgeExtractor edge cases."""

    @pytest.mark.asyncio
    async def test_extract_empty_traces(self):
        """Test extraction with no traces."""
        extractor = DomainKnowledgeExtractor()

        category = Category(
            category_id="cat_001",
            category_type=CategoryType.DEBUGGING,
            name="Debugging",
        )

        domain = await extractor.extract_domain_knowledge(category, [])

        assert domain is not None
        assert domain.evidence_count == 0

    def test_build_extraction_prompt(self):
        """Test extraction prompt building."""
        extractor = DomainKnowledgeExtractor()

        category = Category(
            category_id="cat_001",
            category_type=CategoryType.FEATURE_DEVELOPMENT,
            name="Features",
            common_patterns=["pattern1", "pattern2"],
            effective_strategies=["strategy1"],
        )

        traces = [
            Trace(
                trace_id="trace_001",
                agent_id="agent_001",
                session_id="session_001",
                theme="Feature A",
                summary="Summary A",
                patterns_identified=["p1"],
                lessons_learned=["l1"],
            )
        ]

        prompt = extractor._build_extraction_prompt(category, traces)

        assert "feature_development" in prompt
        assert "pattern1" in prompt
        assert "strategy1" in prompt
        assert "Feature A" in prompt

    def test_parse_extraction_response_valid(self):
        """Test parsing valid extraction response."""
        extractor = DomainKnowledgeExtractor()

        response = '{"principles": ["p1"], "best_practices": ["bp1"], "anti_patterns": ["ap1"], "decision_frameworks": ["df1"]}'
        result = extractor._parse_extraction_response(response)

        assert result["principles"] == ["p1"]
        assert result["best_practices"] == ["bp1"]

    def test_parse_extraction_response_invalid(self):
        """Test parsing invalid extraction response."""
        extractor = DomainKnowledgeExtractor()

        result = extractor._parse_extraction_response("invalid")

        assert result["principles"] == []
        assert result["best_practices"] == []

    @pytest.mark.asyncio
    async def test_extract_with_callable_llm(self):
        """Test extraction with callable LLM."""

        def mock_llm(prompt):
            return '{"principles": ["Callable principle"], "best_practices": [], "anti_patterns": [], "decision_frameworks": []}'

        extractor = DomainKnowledgeExtractor(llm_provider=mock_llm)

        category = Category(
            category_id="cat_001",
            category_type=CategoryType.TESTING,
            name="Testing",
            success_rate=0.8,
        )

        traces = [
            Trace(
                trace_id="trace_001",
                agent_id="agent_001",
                session_id="session_001",
                theme="Test",
            )
        ]

        domain = await extractor.extract_domain_knowledge(category, traces)

        assert "Callable principle" in domain.principles

    def test_aggregate_with_failed_traces(self):
        """Test aggregation with failed traces."""
        extractor = DomainKnowledgeExtractor()

        domain = DomainKnowledge(
            domain_id="domain_001",
            domain_name="Test",
        )

        category = Category(
            category_id="cat_001",
            category_type=CategoryType.DEBUGGING,
            name="Debugging",
            effective_strategies=["strategy1"],
            success_rate=0.5,
        )

        traces = [
            Trace(
                trace_id=f"trace_{i}",
                agent_id="agent_001",
                session_id="session_001",
                theme=f"Test {i}",
                lessons_learned=[f"lesson_{i}"],
                overall_success=(i % 2 == 0),  # Some fail
            )
            for i in range(5)
        ]

        extractor._aggregate_from_traces(domain, traces, category)

        # Should have anti-patterns from failures
        assert len(domain.anti_patterns) > 0

    def test_aggregate_with_high_success_rate(self):
        """Test aggregation with high success rate category."""
        extractor = DomainKnowledgeExtractor()

        domain = DomainKnowledge(
            domain_id="domain_001",
            domain_name="Test",
        )

        category = Category(
            category_id="cat_001",
            category_type=CategoryType.FEATURE_DEVELOPMENT,
            name="Features",
            effective_strategies=["strategy1"],
            success_rate=0.9,  # High success
        )

        traces = [
            Trace(
                trace_id="trace_001",
                agent_id="agent_001",
                session_id="session_001",
                theme="Test",
                overall_success=True,
            )
        ]

        extractor._aggregate_from_traces(domain, traces, category)

        # Should have decision framework from high success
        assert len(domain.decision_frameworks) > 0


class TestDomainKnowledgeMethods:
    """Tests for DomainKnowledge methods."""

    def test_touch_updates_timestamp(self):
        """Test touch() updates updated_at."""
        domain = DomainKnowledge(
            domain_id="domain_001",
            domain_name="Test",
            updated_at="2020-01-01T00:00:00Z",
        )

        old_time = domain.updated_at
        domain.touch()

        assert domain.updated_at != old_time

    def test_post_init_normalizes_lists(self):
        """Test __post_init__ normalizes None lists."""
        domain = DomainKnowledge(
            domain_id="domain_001",
            domain_name="Test",
            principles=None,
            best_practices=None,
        )

        assert domain.principles == []
        assert domain.best_practices == []


class TestTracePostInit:
    """Tests for Trace __post_init__."""

    def test_post_init_normalizes_lists(self):
        """Test __post_init__ normalizes None lists."""
        trace = Trace(
            trace_id="trace_001",
            agent_id="agent_001",
            session_id="session_001",
            theme="Test",
            episode_ids=None,
            patterns_identified=None,
            lessons_learned=None,
        )

        assert trace.episode_ids == []
        assert trace.patterns_identified == []
        assert trace.lessons_learned == []

    def test_post_init_updates_episode_count(self):
        """Test __post_init__ sets episode_count from list."""
        trace = Trace(
            trace_id="trace_001",
            agent_id="agent_001",
            session_id="session_001",
            theme="Test",
            episode_ids=["ep_001", "ep_002", "ep_003"],
            episode_count=0,
        )

        assert trace.episode_count == 3


class TestCategoryPostInit:
    """Tests for Category __post_init__."""

    def test_post_init_normalizes_lists(self):
        """Test __post_init__ normalizes None lists."""
        category = Category(
            category_id="cat_001",
            category_type=CategoryType.DEBUGGING,
            name="Debugging",
            trace_ids=None,
            common_patterns=None,
            typical_challenges=None,
            effective_strategies=None,
        )

        assert category.trace_ids == []
        assert category.common_patterns == []
        assert category.typical_challenges == []
        assert category.effective_strategies == []

    def test_post_init_updates_trace_count(self):
        """Test __post_init__ sets trace_count from list."""
        category = Category(
            category_id="cat_001",
            category_type=CategoryType.DEBUGGING,
            name="Debugging",
            trace_ids=["t1", "t2"],
            trace_count=0,
        )

        assert category.trace_count == 2


class TestConsolidationJobEdgeCases:
    """Additional tests for ConsolidationJob."""

    @pytest.mark.asyncio
    async def test_double_start(self, episode_store):
        """Test starting an already running job."""
        consolidator = TraceConsolidator(episode_store)
        job = ConsolidationJob(
            episode_store=episode_store,
            trace_consolidator=consolidator,
        )

        await job.start()
        assert job.is_running is True

        # Start again - should be no-op
        await job.start()
        assert job.is_running is True

        await job.stop()

    @pytest.mark.asyncio
    async def test_stop_not_running(self, episode_store):
        """Test stopping a job that isn't running."""
        consolidator = TraceConsolidator(episode_store)
        job = ConsolidationJob(
            episode_store=episode_store,
            trace_consolidator=consolidator,
        )

        # Should be safe to stop when not running
        await job.stop()
        assert job.is_running is False


# =============================================================================
# Integration Tests
# =============================================================================


class TestConsolidationIntegration:
    """Integration tests for full consolidation flow."""

    @pytest.mark.asyncio
    async def test_full_consolidation_flow(self, temp_db):
        """Test complete flow: episodes -> traces -> categories -> domain."""
        # Setup stores
        episode_store = EpisodeStore(db_path=temp_db)
        category_manager = CategoryManager(db_path=temp_db)

        # Create and store episodes
        episodes = [
            Episode(
                episode_id=f"ep_{i:03d}",
                agent_id="agent_001",
                session_id="session_001",
                episode_type=EpisodeType.TASK_EXECUTION,
                context=f"Implementing feature {i}",
                action=f"Wrote code {i}",
                outcome=f"Completed {i}",
                success=True,
                tags=["feature", "development"],
            )
            for i in range(10)
        ]

        for ep in episodes:
            episode_store.store(ep)

        # Step 1: Consolidate episodes into traces
        trace_consolidator = TraceConsolidator(episode_store)
        trace = await trace_consolidator.consolidate_session("session_001")

        assert trace is not None
        assert trace.episode_count == 10

        # Step 2: Categorize trace
        category = category_manager.categorize_trace(
            trace, CategoryType.FEATURE_DEVELOPMENT
        )

        assert category is not None
        assert trace.category_id == category.category_id

        # Step 3: Extract domain knowledge
        extractor = DomainKnowledgeExtractor()
        domain = await extractor.extract_domain_knowledge(category, [trace])

        assert domain is not None
        assert domain.evidence_count == 1
        assert len(domain.principles) > 0 or len(domain.best_practices) > 0

    @pytest.mark.asyncio
    async def test_background_job_integration(self, temp_db):
        """Test background job with real components."""
        episode_store = EpisodeStore(db_path=temp_db)
        trace_consolidator = TraceConsolidator(episode_store)

        job = ConsolidationJob(
            episode_store=episode_store,
            trace_consolidator=trace_consolidator,
            interval_seconds=1,
            episode_threshold=5,
        )

        # Add episodes
        for i in range(10):
            ep = Episode(
                episode_id=f"ep_{i:03d}",
                agent_id="agent_001",
                session_id=f"session_{i // 5}",
                episode_type=EpisodeType.TASK_EXECUTION,
                context=f"Context {i}",
                action=f"Action {i}",
                outcome=f"Outcome {i}",
            )
            episode_store.store(ep)

        # Run consolidation
        traces_created = await job.run_once()

        assert traces_created == 2  # 2 sessions

        # Verify episodes are consolidated
        unconsolidated = episode_store.get_unconsolidated_episodes()
        assert len(unconsolidated) == 0
