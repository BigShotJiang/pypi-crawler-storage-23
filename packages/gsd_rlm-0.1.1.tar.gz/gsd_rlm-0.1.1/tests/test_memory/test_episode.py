"""
Comprehensive tests for H-MEM Episode storage (MEM-01, MEM-11).

Tests cover:
- Episode dataclass creation and serialization
- EpisodeType enum values
- EpisodeStore CRUD operations
- Persistence across restarts
- Embedding storage and retrieval
"""

import os
import tempfile
from datetime import datetime
from pathlib import Path

import pytest

from gsd_rlm.memory.hmem import Episode, EpisodeType, EpisodeStore


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def tmp_db_path(tmp_path: Path) -> str:
    """Provide a temporary database path for each test."""
    return str(tmp_path / "test_hmem.db")


@pytest.fixture
def fresh_episode() -> Episode:
    """Provide a fresh episode for testing."""
    return Episode(
        episode_id="ep-test-001",
        agent_id="agent-planner",
        session_id="sess-2024-001",
        episode_type=EpisodeType.TASK_EXECUTION,
        context="User requested code review",
        action="Analyzed code with linter and manual review",
        outcome="Found 3 issues and suggested fixes",
        success=True,
        tokens_used=1500,
        duration_ms=2500,
        tags=["code-review", "quality"],
    )


@pytest.fixture
def episode_with_embedding() -> Episode:
    """Provide an episode with embedding for semantic search tests."""
    return Episode(
        episode_id="ep-embedded-001",
        agent_id="agent-coder",
        session_id="sess-2024-002",
        episode_type=EpisodeType.LEARNING,
        context="Learned new API pattern",
        action="Studied documentation and examples",
        outcome="Understood REST best practices",
        success=True,
        embedding=[0.1, 0.2, 0.3, 0.4, 0.5],
        tags=["learning", "api", "rest"],
    )


# =============================================================================
# EpisodeType Enum Tests
# =============================================================================


class TestEpisodeTypeEnum:
    """Tests for EpisodeType enum."""

    def test_episode_type_has_five_values(self):
        """EpisodeType should have exactly 5 values."""
        types = list(EpisodeType)
        assert len(types) == 5

    def test_episode_type_values(self):
        """EpisodeType should have expected string values."""
        assert EpisodeType.TASK_EXECUTION.value == "task_execution"
        assert EpisodeType.PROBLEM_SOLVING.value == "problem_solving"
        assert EpisodeType.ERROR_RECOVERY.value == "error_recovery"
        assert EpisodeType.LEARNING.value == "learning"
        assert EpisodeType.COLLABORATION.value == "collaboration"

    def test_episode_type_from_string(self):
        """EpisodeType should be creatable from string."""
        ep_type = EpisodeType("task_execution")
        assert ep_type == EpisodeType.TASK_EXECUTION


# =============================================================================
# Episode Dataclass Tests
# =============================================================================


class TestEpisodeDataclass:
    """Tests for Episode dataclass."""

    def test_episode_dataclass_creation(self, fresh_episode: Episode):
        """Episode should be created with all required fields."""
        assert fresh_episode.episode_id == "ep-test-001"
        assert fresh_episode.agent_id == "agent-planner"
        assert fresh_episode.session_id == "sess-2024-001"
        assert fresh_episode.episode_type == EpisodeType.TASK_EXECUTION
        assert fresh_episode.context == "User requested code review"
        assert fresh_episode.action == "Analyzed code with linter and manual review"
        assert fresh_episode.outcome == "Found 3 issues and suggested fixes"
        assert fresh_episode.success is True
        assert fresh_episode.tokens_used == 1500
        assert fresh_episode.duration_ms == 2500
        assert fresh_episode.tags == ["code-review", "quality"]
        assert fresh_episode.embedding is None
        assert fresh_episode.trace_id is None

    def test_episode_serialization(self, fresh_episode: Episode):
        """Episode should serialize to dict and deserialize correctly."""
        data = fresh_episode.to_dict()

        assert data["episode_id"] == "ep-test-001"
        assert data["episode_type"] == "task_execution"
        assert data["success"] is True
        assert data["tags"] == ["code-review", "quality"]

        # Roundtrip
        restored = Episode.from_dict(data)
        assert restored.episode_id == fresh_episode.episode_id
        assert restored.episode_type == fresh_episode.episode_type
        assert restored.context == fresh_episode.context
        assert restored.tags == fresh_episode.tags

    def test_episode_with_embedding_serialization(
        self, episode_with_embedding: Episode
    ):
        """Episode with embedding should serialize correctly."""
        data = episode_with_embedding.to_dict()
        assert data["embedding"] == [0.1, 0.2, 0.3, 0.4, 0.5]

        restored = Episode.from_dict(data)
        assert restored.embedding == [0.1, 0.2, 0.3, 0.4, 0.5]

    def test_episode_default_values(self):
        """Episode should have sensible defaults for optional fields."""
        ep = Episode(
            episode_id="ep-minimal",
            agent_id="agent-1",
            session_id="sess-1",
            episode_type=EpisodeType.TASK_EXECUTION,
        )

        assert ep.context == ""
        assert ep.action == ""
        assert ep.outcome == ""
        assert ep.success is False
        assert ep.tokens_used == 0
        assert ep.duration_ms == 0
        assert ep.embedding is None
        assert ep.tags == []
        assert ep.trace_id is None
        assert ep.timestamp  # Should have auto-generated timestamp

    def test_episode_is_consolidated_property(self, fresh_episode: Episode):
        """is_consolidated should reflect trace_id status."""
        assert fresh_episode.is_consolidated is False

        fresh_episode.trace_id = "trace-001"
        assert fresh_episode.is_consolidated is True

    def test_episode_has_embedding_property(
        self, fresh_episode: Episode, episode_with_embedding: Episode
    ):
        """has_embedding should reflect embedding status."""
        assert fresh_episode.has_embedding is False
        assert episode_with_embedding.has_embedding is True

    def test_episode_add_remove_tags(self, fresh_episode: Episode):
        """add_tag and remove_tag should manage tags correctly."""
        fresh_episode.add_tag("new-tag")
        assert "new-tag" in fresh_episode.tags

        # Adding duplicate should not create duplicate
        fresh_episode.add_tag("new-tag")
        assert fresh_episode.tags.count("new-tag") == 1

        # Remove existing tag
        result = fresh_episode.remove_tag("new-tag")
        assert result is True
        assert "new-tag" not in fresh_episode.tags

        # Remove non-existent tag
        result = fresh_episode.remove_tag("nonexistent")
        assert result is False


# =============================================================================
# EpisodeStore Tests
# =============================================================================


class TestEpisodeStore:
    """Tests for EpisodeStore SQLite persistence."""

    def test_episode_store_init(self, tmp_db_path: str):
        """EpisodeStore should create database file on init."""
        store = EpisodeStore(tmp_db_path)

        assert os.path.exists(tmp_db_path)
        assert store.count() == 0

    def test_episode_store_and_retrieve(self, tmp_db_path: str, fresh_episode: Episode):
        """EpisodeStore should store and retrieve episodes."""
        store = EpisodeStore(tmp_db_path)
        store.store(fresh_episode)

        retrieved = store.get("ep-test-001")

        assert retrieved is not None
        assert retrieved.episode_id == fresh_episode.episode_id
        assert retrieved.agent_id == fresh_episode.agent_id
        assert retrieved.session_id == fresh_episode.session_id
        assert retrieved.episode_type == fresh_episode.episode_type
        assert retrieved.context == fresh_episode.context
        assert retrieved.success == fresh_episode.success
        assert retrieved.tags == fresh_episode.tags

    def test_episode_store_unconsolidated(
        self, tmp_db_path: str, fresh_episode: Episode
    ):
        """get_unconsolidated_episodes should return only unconsolidated."""
        store = EpisodeStore(tmp_db_path)

        # Store unconsolidated episode
        store.store(fresh_episode)

        # Store consolidated episode
        consolidated = Episode(
            episode_id="ep-consolidated",
            agent_id="agent-1",
            session_id="sess-1",
            episode_type=EpisodeType.LEARNING,
            trace_id="trace-001",
        )
        store.store(consolidated)

        unconsolidated = store.get_unconsolidated_episodes()
        assert len(unconsolidated) == 1
        assert unconsolidated[0].episode_id == "ep-test-001"

    def test_episode_store_by_agent(self, tmp_db_path: str):
        """get_episodes_by_agent should return episodes for specific agent."""
        store = EpisodeStore(tmp_db_path)

        # Store episodes for different agents
        for i in range(5):
            ep = Episode(
                episode_id=f"ep-agent1-{i}",
                agent_id="agent-1",
                session_id=f"sess-{i}",
                episode_type=EpisodeType.TASK_EXECUTION,
            )
            store.store(ep)

        for i in range(3):
            ep = Episode(
                episode_id=f"ep-agent2-{i}",
                agent_id="agent-2",
                session_id=f"sess-{i + 10}",
                episode_type=EpisodeType.PROBLEM_SOLVING,
            )
            store.store(ep)

        agent1_episodes = store.get_episodes_by_agent("agent-1", limit=10)
        agent2_episodes = store.get_episodes_by_agent("agent-2", limit=10)

        assert len(agent1_episodes) == 5
        assert len(agent2_episodes) == 3
        assert all(ep.agent_id == "agent-1" for ep in agent1_episodes)

    def test_episode_store_for_session(self, tmp_db_path: str):
        """get_episodes_for_session should return session episodes ordered."""
        store = EpisodeStore(tmp_db_path)

        # Store episodes for same session with different timestamps
        for i in range(3):
            ep = Episode(
                episode_id=f"ep-sess-{i}",
                agent_id="agent-1",
                session_id="session-main",
                episode_type=EpisodeType.TASK_EXECUTION,
                timestamp=f"2024-01-{10 + i:02d}T10:00:00",
            )
            store.store(ep)

        # Store episode for different session
        other_ep = Episode(
            episode_id="ep-other",
            agent_id="agent-1",
            session_id="session-other",
            episode_type=EpisodeType.TASK_EXECUTION,
        )
        store.store(other_ep)

        session_episodes = store.get_episodes_for_session("session-main")

        assert len(session_episodes) == 3
        # Should be ordered by timestamp (oldest first)
        assert session_episodes[0].episode_id == "ep-sess-0"
        assert session_episodes[2].episode_id == "ep-sess-2"

    def test_episode_persistence_across_restarts(self, tmp_db_path: str):
        """Episodes should persist when store is closed and reopened."""
        # First store instance
        store1 = EpisodeStore(tmp_db_path)
        ep = Episode(
            episode_id="ep-persistent",
            agent_id="agent-1",
            session_id="sess-1",
            episode_type=EpisodeType.LEARNING,
            context="Important lesson learned",
        )
        store1.store(ep)
        del store1  # Simulate closing

        # New store instance (simulating restart)
        store2 = EpisodeStore(tmp_db_path)
        retrieved = store2.get("ep-persistent")

        assert retrieved is not None
        assert retrieved.context == "Important lesson learned"

    def test_episode_embedding_storage(
        self, tmp_db_path: str, episode_with_embedding: Episode
    ):
        """Embedding vector should be serialized and deserialized correctly."""
        store = EpisodeStore(tmp_db_path)
        store.store(episode_with_embedding)

        retrieved = store.get("ep-embedded-001")

        assert retrieved is not None
        assert retrieved.embedding is not None
        assert len(retrieved.embedding) == 5
        assert retrieved.embedding == [0.1, 0.2, 0.3, 0.4, 0.5]

    def test_episode_store_delete(self, tmp_db_path: str, fresh_episode: Episode):
        """delete should remove episode from store."""
        store = EpisodeStore(tmp_db_path)
        store.store(fresh_episode)

        assert store.get("ep-test-001") is not None

        result = store.delete("ep-test-001")
        assert result is True
        assert store.get("ep-test-001") is None

        # Delete non-existent should return False
        result = store.delete("nonexistent")
        assert result is False

    def test_episode_store_count(self, tmp_db_path: str):
        """count and count_for_session should return correct counts."""
        store = EpisodeStore(tmp_db_path)

        for i in range(5):
            ep = Episode(
                episode_id=f"ep-{i}",
                agent_id="agent-1",
                session_id="sess-1" if i < 3 else "sess-2",
                episode_type=EpisodeType.TASK_EXECUTION,
            )
            store.store(ep)

        assert store.count() == 5
        assert store.count_for_session("sess-1") == 3
        assert store.count_for_session("sess-2") == 2

    def test_episode_store_upsert(self, tmp_db_path: str):
        """Storing episode with same ID should update (upsert)."""
        store = EpisodeStore(tmp_db_path)

        # Initial store
        ep1 = Episode(
            episode_id="ep-upsert",
            agent_id="agent-1",
            session_id="sess-1",
            episode_type=EpisodeType.TASK_EXECUTION,
            context="Original context",
        )
        store.store(ep1)

        # Update with same ID
        ep2 = Episode(
            episode_id="ep-upsert",
            agent_id="agent-1",
            session_id="sess-1",
            episode_type=EpisodeType.TASK_EXECUTION,
            context="Updated context",
            success=True,
        )
        store.store(ep2)

        assert store.count() == 1  # Should still be 1
        retrieved = store.get("ep-upsert")
        assert retrieved.context == "Updated context"
        assert retrieved.success is True

    def test_episode_store_time_range(self, tmp_db_path: str):
        """get_episodes_by_time_range should filter by timestamp."""
        store = EpisodeStore(tmp_db_path)

        episodes = [
            Episode(
                episode_id=f"ep-time-{i}",
                agent_id="agent-1",
                session_id="sess-1",
                episode_type=EpisodeType.TASK_EXECUTION,
                timestamp=f"2024-01-{15 + i:02d}T10:00:00",
            )
            for i in range(5)
        ]

        for ep in episodes:
            store.store(ep)

        # Query range
        results = store.get_episodes_by_time_range(
            "2024-01-16T00:00:00", "2024-01-18T23:59:59"
        )

        assert len(results) == 3  # 16th, 17th, 18th
        assert results[0].episode_id == "ep-time-1"
        assert results[2].episode_id == "ep-time-3"

    def test_episode_store_all_types(self, tmp_db_path: str):
        """All EpisodeType values should be storable and retrievable."""
        store = EpisodeStore(tmp_db_path)

        for i, ep_type in enumerate(EpisodeType):
            ep = Episode(
                episode_id=f"ep-type-{i}",
                agent_id="agent-1",
                session_id="sess-1",
                episode_type=ep_type,
            )
            store.store(ep)

        for i, ep_type in enumerate(EpisodeType):
            retrieved = store.get(f"ep-type-{i}")
            assert retrieved.episode_type == ep_type

    def test_episode_store_creates_parent_directory(self, tmp_path: Path):
        """EpisodeStore should create parent directories if needed."""
        nested_path = str(tmp_path / "nested" / "deep" / "test.db")
        store = EpisodeStore(nested_path)

        assert os.path.exists(nested_path)
