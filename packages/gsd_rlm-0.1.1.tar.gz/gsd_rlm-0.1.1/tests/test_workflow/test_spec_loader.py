"""
Tests for SpecLoader.

Tests ROADMAP.md and REQUIREMENTS.md parsing
for spec-driven workflow execution.
"""

import pytest
from pathlib import Path
from unittest.mock import Mock, patch

from gsd_rlm.workflow.spec_loader import (
    PhaseSpec,
    SpecLoader,
    load_roadmap,
    load_requirements,
)


class TestPhaseSpec:
    """Tests for PhaseSpec dataclass."""

    def test_create_phase_spec(self):
        """Test creating a PhaseSpec instance."""
        spec = PhaseSpec(
            number="01",
            name="Test Phase",
            goal="Test goal",
            requirements=["REQ-01", "REQ-02"],
            success_criteria=["Criterion 1"],
            depends_on=[],
            plans=["01-01-PLAN.md"],
        )
        assert spec.number == "01"
        assert spec.name == "Test Phase"
        assert spec.goal == "Test goal"
        assert spec.requirements == ["REQ-01", "REQ-02"]
        assert spec.success_criteria == ["Criterion 1"]
        assert spec.status == "not_started"

    def test_phase_spec_default_lists(self):
        """Test PhaseSpec initializes empty lists."""
        spec = PhaseSpec(number="02", name="Phase", goal="Goal")
        assert spec.requirements == []
        assert spec.success_criteria == []
        assert spec.depends_on == []
        assert spec.plans == []


class TestSpecLoader:
    """Tests for SpecLoader class."""

    def test_init(self, tmp_path: Path):
        """Test SpecLoader initialization."""
        loader = SpecLoader(tmp_path)
        assert loader.planning_dir == tmp_path
        assert loader.roadmap is None
        assert loader.requirements is None

    def test_load_roadmap_file_not_found(self, tmp_path: Path):
        """Test load_roadmap raises error if file missing."""
        loader = SpecLoader(tmp_path)
        with pytest.raises(FileNotFoundError):
            loader.load_roadmap()

    def test_load_requirements_file_not_found(self, tmp_path: Path):
        """Test load_requirements raises error if file missing."""
        loader = SpecLoader(tmp_path)
        with pytest.raises(FileNotFoundError):
            loader.load_requirements()

    def test_load_roadmap(self, tmp_path: Path):
        """Test loading ROADMAP.md."""
        roadmap_content = """# Roadmap: Test Project

## Overview
This is a test roadmap.

## Phases

### Phase 1: Foundation
**Goal**: Build foundation
**Depends on**: Nothing
**Requirements**: REQ-01, REQ-02
**Success Criteria** (what must be TRUE):
  1. User can do X
  2. User can do Y

Plans:
- [x] 01-01-PLAN.md — First plan
- [ ] 01-02-PLAN.md — Second plan
"""
        (tmp_path / "ROADMAP.md").write_text(roadmap_content, encoding="utf-8")

        loader = SpecLoader(tmp_path)
        roadmap = loader.load_roadmap()

        assert "phases" in roadmap
        assert "01" in roadmap["phases"]
        assert roadmap["phases"]["01"]["name"] == "Foundation"
        assert roadmap["phases"]["01"]["goal"] == "Build foundation"
        assert "REQ-01" in roadmap["phases"]["01"]["requirements"]
        assert len(roadmap["phases"]["01"]["success_criteria"]) == 2

    def test_load_requirements(self, tmp_path: Path):
        """Test loading REQUIREMENTS.md."""
        requirements_content = """# Requirements: Test Project

**Core Value:** Test value

## v1 Requirements

### Core Agents

- [x] **REQ-01**: First requirement
- [ ] **REQ-02**: Second requirement

## Traceability

| Requirement | Phase | Status |
|-------------|-------|--------|
| REQ-01 | Phase 1 | Complete |
| REQ-02 | Phase 1 | Pending |
"""
        (tmp_path / "REQUIREMENTS.md").write_text(
            requirements_content, encoding="utf-8"
        )

        loader = SpecLoader(tmp_path)
        reqs = loader.load_requirements()

        assert "requirements" in reqs
        assert "REQ-01" in reqs["requirements"]
        assert reqs["requirements"]["REQ-01"]["complete"] is True
        assert reqs["requirements"]["REQ-02"]["complete"] is False

    def test_get_phase(self, tmp_path: Path):
        """Test getting phase by number."""
        roadmap_content = """# Roadmap

### Phase 5: Integration
**Goal**: Integration goal
**Requirements**: INT-01
"""
        (tmp_path / "ROADMAP.md").write_text(roadmap_content, encoding="utf-8")

        loader = SpecLoader(tmp_path)
        loader.load_roadmap()

        phase = loader.get_phase("05")
        assert phase is not None
        assert phase.name == "Integration"
        assert phase.goal == "Integration goal"

        # Test with single digit
        phase = loader.get_phase("5")
        assert phase is not None
        assert phase.name == "Integration"

    def test_get_phase_not_found(self, tmp_path: Path):
        """Test getting non-existent phase."""
        (tmp_path / "ROADMAP.md").write_text("# Roadmap", encoding="utf-8")

        loader = SpecLoader(tmp_path)
        loader.load_roadmap()

        phase = loader.get_phase("99")
        assert phase is None

    def test_list_phases(self, tmp_path: Path):
        """Test listing all phases."""
        roadmap_content = """# Roadmap

### Phase 1: First
**Goal**: Goal 1

### Phase 2: Second
**Goal**: Goal 2

### Phase 3: Third
**Goal**: Goal 3
"""
        (tmp_path / "ROADMAP.md").write_text(roadmap_content, encoding="utf-8")

        loader = SpecLoader(tmp_path)
        loader.load_roadmap()

        phases = loader.list_phases()
        assert phases == ["01", "02", "03"]

    def test_parse_roadmap_with_dependencies(self, tmp_path: Path):
        """Test parsing roadmap with phase dependencies."""
        roadmap_content = """# Roadmap

### Phase 1: Foundation
**Goal**: Foundation
**Depends on**: Nothing

### Phase 2: Extension
**Goal**: Extension
**Depends on**: Phase 1
"""
        (tmp_path / "ROADMAP.md").write_text(roadmap_content, encoding="utf-8")

        loader = SpecLoader(tmp_path)
        loader.load_roadmap()

        phase1 = loader.get_phase("01")
        assert phase1 is not None
        assert phase1.depends_on == []

        phase2 = loader.get_phase("02")
        assert phase2 is not None
        assert phase2.depends_on == ["Phase 1"]

    def test_parse_plans_from_roadmap(self, tmp_path: Path):
        """Test extracting plan files from roadmap."""
        roadmap_content = """# Roadmap

### Phase 1: Test
**Goal**: Test

Plans:
- [x] 01-01-PLAN.md — First plan (Wave 1)
- [ ] 01-02-PLAN.md — Second plan (Wave 2)
- [x] 01-03-PLAN.md — Third plan (Wave 2)
"""
        (tmp_path / "ROADMAP.md").write_text(roadmap_content, encoding="utf-8")

        loader = SpecLoader(tmp_path)
        loader.load_roadmap()

        phase = loader.get_phase("01")
        assert phase is not None
        assert "01-01-PLAN.md" in phase.plans
        assert "01-02-PLAN.md" in phase.plans
        assert "01-03-PLAN.md" in phase.plans


class TestConvenienceFunctions:
    """Tests for module-level convenience functions."""

    def test_load_roadmap_function(self, tmp_path: Path):
        """Test load_roadmap convenience function."""
        (tmp_path / "ROADMAP.md").write_text(
            "# Roadmap\n\n### Phase 1: Test\n**Goal**: Test goal",
            encoding="utf-8",
        )

        roadmap = load_roadmap(tmp_path)
        assert "phases" in roadmap
        assert "01" in roadmap["phases"]

    def test_load_requirements_function(self, tmp_path: Path):
        """Test load_requirements convenience function."""
        (tmp_path / "REQUIREMENTS.md").write_text(
            "# Requirements\n\n**Core Value:** Test\n\n- [x] **REQ-01**: Test",
            encoding="utf-8",
        )

        reqs = load_requirements(tmp_path)
        assert "requirements" in reqs
        assert "REQ-01" in reqs["requirements"]


class TestRealRoadmap:
    """Tests using actual ROADMAP.md format."""

    def test_parse_actual_roadmap_format(self, tmp_path: Path):
        """Test parsing ROADMAP.md with actual project format."""
        roadmap_content = """# Roadmap: GSD-RLM Multi-Agent Development Workflow

## Overview

This roadmap transforms the GSD-RLM vision into a production-ready
multi-agent development workflow system.

## Phases

### Phase 1: Core Workflow Foundation
**Goal**: Users can define and run agents that execute tasks with persistent state
**Depends on**: Nothing (first phase)
**Requirements**: AGENT-01, AGENT-02, AGENT-03, AGENT-04
**Success Criteria** (what must be TRUE):
  1. User can create an agent with custom configuration
  2. Agent executes sequential tasks and passes context
  3. Agent session memory persists across task boundaries

Plans:
- [x] 01-01-PLAN.md — YAML agent definition (Wave 1)
- [x] 01-02-PLAN.md — Sequential execution (Wave 3)

### Phase 2: Hybrid Runtime + Coordination
**Goal**: Users can execute multiple agents in parallel
**Depends on**: Phase 1
**Requirements**: EXEC-01, EXEC-02
**Success Criteria** (what must be TRUE):
  1. System analyzes task dependencies
  2. Independent tasks execute concurrently

Plans:
- [x] 02-01-PLAN.md — Dependency analysis (Wave 1)
"""
        (tmp_path / "ROADMAP.md").write_text(roadmap_content, encoding="utf-8")

        loader = SpecLoader(tmp_path)
        roadmap = loader.load_roadmap()

        # Verify Phase 1
        phase1 = loader.get_phase("01")
        assert phase1 is not None
        assert phase1.name == "Core Workflow Foundation"
        assert "AGENT-01" in phase1.requirements
        assert len(phase1.success_criteria) == 3
        assert phase1.depends_on == []

        # Verify Phase 2
        phase2 = loader.get_phase("02")
        assert phase2 is not None
        assert phase2.name == "Hybrid Runtime + Coordination"
        assert "Phase 1" in phase2.depends_on

    def test_parse_actual_requirements_format(self, tmp_path: Path):
        """Test parsing REQUIREMENTS.md with actual project format."""
        requirements_content = """# Requirements: GSD-RLM

**Core Value:** Transform project ideas into production-ready code

## v1 Requirements

### Core Agents

- [x] **AGENT-01**: User can define agents with name, role, goal
- [x] **AGENT-02**: Agents execute tasks sequentially

### Execution Engine

- [x] **EXEC-01**: System analyzes plan dependencies
- [ ] **EXEC-02**: Independent plans in same wave execute in parallel

## Traceability

| Requirement | Phase | Status |
|-------------|-------|--------|
| AGENT-01 | Phase 1 | Complete |
| AGENT-02 | Phase 1 | Complete |
| EXEC-01 | Phase 2 | Complete |
| EXEC-02 | Phase 2 | Pending |
"""
        (tmp_path / "REQUIREMENTS.md").write_text(
            requirements_content, encoding="utf-8"
        )

        loader = SpecLoader(tmp_path)
        reqs = loader.load_requirements()

        # Verify requirements parsed
        assert "AGENT-01" in reqs["requirements"]
        assert reqs["requirements"]["AGENT-01"]["complete"] is True
        assert reqs["requirements"]["EXEC-02"]["complete"] is False

        # Verify traceability
        assert "AGENT-01" in reqs["traceability"]
        assert reqs["traceability"]["AGENT-01"]["phase"] == "Phase 1"
