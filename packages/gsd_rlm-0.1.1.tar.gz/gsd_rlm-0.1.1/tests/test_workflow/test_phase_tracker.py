"""
Tests for PhaseTracker.

Tests phase progression tracking for
spec-driven workflow execution.
"""

import pytest
from pathlib import Path
from datetime import datetime, timezone

from gsd_rlm.workflow.phase_tracker import (
    PhaseStatus,
    PhaseProgress,
    PhaseTracker,
    _parse_iso_datetime,
)


class TestPhaseStatus:
    """Tests for PhaseStatus enum."""

    def test_status_values(self):
        """Test PhaseStatus enum values."""
        assert PhaseStatus.NOT_STARTED == "not_started"
        assert PhaseStatus.IN_PROGRESS == "in_progress"
        assert PhaseStatus.COMPLETE == "complete"
        assert PhaseStatus.BLOCKED == "blocked"

    def test_status_string_conversion(self):
        """Test converting PhaseStatus to string."""
        assert str(PhaseStatus.IN_PROGRESS) == "in_progress"
        assert PhaseStatus.COMPLETE.value == "complete"


class TestPhaseProgress:
    """Tests for PhaseProgress dataclass."""

    def test_create_phase_progress(self):
        """Test creating PhaseProgress instance."""
        progress = PhaseProgress(
            phase_number="05",
            status=PhaseStatus.IN_PROGRESS,
            plans_total=5,
            plans_complete=2,
            current_plan="05-02",
        )
        assert progress.phase_number == "05"
        assert progress.status == PhaseStatus.IN_PROGRESS
        assert progress.plans_total == 5
        assert progress.plans_complete == 2
        assert progress.current_plan == "05-02"

    def test_progress_percent(self):
        """Test progress percentage calculation."""
        progress = PhaseProgress(phase_number="01", plans_total=4)
        assert progress.progress_percent == 0.0

        progress.plans_complete = 2
        assert progress.progress_percent == 50.0

        progress.plans_complete = 4
        assert progress.progress_percent == 100.0

    def test_progress_percent_zero_total(self):
        """Test progress percentage when total is zero."""
        progress = PhaseProgress(phase_number="01", plans_total=0)
        assert progress.progress_percent == 0.0

    def test_is_complete(self):
        """Test is_complete property."""
        progress = PhaseProgress(phase_number="01")
        assert not progress.is_complete

        progress.status = PhaseStatus.COMPLETE
        assert progress.is_complete

    def test_is_blocked(self):
        """Test is_blocked property."""
        progress = PhaseProgress(phase_number="01")
        assert not progress.is_blocked

        progress.status = PhaseStatus.BLOCKED
        assert progress.is_blocked


class TestParseIsoDatetime:
    """Tests for _parse_iso_datetime helper."""

    def test_parse_with_z_suffix(self):
        """Test parsing ISO datetime with Z suffix."""
        result = _parse_iso_datetime("2026-02-27T12:30:45Z")
        assert result is not None
        assert result.year == 2026
        assert result.month == 2
        assert result.day == 27

    def test_parse_with_timezone(self):
        """Test parsing ISO datetime with timezone."""
        result = _parse_iso_datetime("2026-02-27T12:30:45+00:00")
        assert result is not None
        assert result.year == 2026

    def test_parse_empty_string(self):
        """Test parsing empty string returns None."""
        result = _parse_iso_datetime("")
        assert result is None

    def test_parse_invalid_string(self):
        """Test parsing invalid string returns None."""
        result = _parse_iso_datetime("not-a-date")
        assert result is None


class TestPhaseTracker:
    """Tests for PhaseTracker class."""

    def test_init(self, tmp_path: Path):
        """Test PhaseTracker initialization."""
        tracker = PhaseTracker(tmp_path)
        assert tracker.planning_dir == tmp_path
        assert tracker.progress == {}

    def test_load_empty_planning_dir(self, tmp_path: Path):
        """Test loading with empty planning directory."""
        tracker = PhaseTracker(tmp_path)
        tracker.load()
        assert tracker.progress == {}

    def test_scan_phase_directories(self, tmp_path: Path):
        """Test scanning phase directories."""
        # Create phase directory with plans
        phase_dir = tmp_path / "phases" / "05-test-phase"
        phase_dir.mkdir(parents=True)
        (phase_dir / "05-01-PLAN.md").write_text("# Plan 1", encoding="utf-8")
        (phase_dir / "05-02-PLAN.md").write_text("# Plan 2", encoding="utf-8")
        (phase_dir / "05-01-SUMMARY.md").write_text("# Summary 1", encoding="utf-8")

        tracker = PhaseTracker(tmp_path)
        tracker.load()

        assert "05" in tracker.progress
        progress = tracker.progress["05"]
        assert progress.plans_total == 2
        assert progress.plans_complete == 1

    def test_read_state_md(self, tmp_path: Path):
        """Test reading STATE.md for current position."""
        state_content = """# Project State

## Current Position

Phase: 5 of 6
Plan: 2 of 3 in current phase
Status: In progress
"""
        (tmp_path / "STATE.md").write_text(state_content, encoding="utf-8")

        # Create phase directory
        phase_dir = tmp_path / "phases" / "05-test"
        phase_dir.mkdir(parents=True)
        (phase_dir / "05-01-PLAN.md").write_text("# Plan", encoding="utf-8")

        tracker = PhaseTracker(tmp_path)
        tracker.load()

        assert "05" in tracker.progress
        progress = tracker.progress["05"]
        assert progress.status == PhaseStatus.IN_PROGRESS
        assert progress.current_plan == "05-02"

    def test_start_phase(self, tmp_path: Path):
        """Test starting a phase."""
        tracker = PhaseTracker(tmp_path)
        tracker.start_phase("05")

        assert "05" in tracker.progress
        progress = tracker.progress["05"]
        assert progress.status == PhaseStatus.IN_PROGRESS
        assert progress.started_at is not None

    def test_start_phase_normalizes_number(self, tmp_path: Path):
        """Test starting phase normalizes number."""
        tracker = PhaseTracker(tmp_path)
        tracker.start_phase("5")

        assert "05" in tracker.progress

    def test_complete_plan(self, tmp_path: Path):
        """Test completing a plan."""
        tracker = PhaseTracker(tmp_path)
        tracker.start_phase("05")
        tracker.progress["05"].plans_total = 3

        tracker.complete_plan("05", "05-01")

        progress = tracker.progress["05"]
        assert progress.plans_complete == 1
        assert progress.current_plan == "05-01"

    def test_complete_phase_on_all_plans(self, tmp_path: Path):
        """Test phase auto-completes when all plans done."""
        tracker = PhaseTracker(tmp_path)
        tracker.start_phase("05")
        tracker.progress["05"].plans_total = 2

        tracker.complete_plan("05", "05-01")
        tracker.complete_plan("05", "05-02")

        progress = tracker.progress["05"]
        assert progress.status == PhaseStatus.COMPLETE
        assert progress.completed_at is not None

    def test_complete_phase(self, tmp_path: Path):
        """Test explicitly completing a phase."""
        tracker = PhaseTracker(tmp_path)
        tracker.start_phase("05")

        tracker.complete_phase("05")

        progress = tracker.progress["05"]
        assert progress.status == PhaseStatus.COMPLETE
        assert progress.completed_at is not None

    def test_block_phase(self, tmp_path: Path):
        """Test blocking a phase."""
        tracker = PhaseTracker(tmp_path)
        tracker.block_phase("05", "Waiting for dependency")

        progress = tracker.progress["05"]
        assert progress.status == PhaseStatus.BLOCKED
        assert progress.blocker == "Waiting for dependency"

    def test_get_progress(self, tmp_path: Path):
        """Test getting progress for a phase."""
        tracker = PhaseTracker(tmp_path)
        tracker.start_phase("05")

        progress = tracker.get_progress("05")
        assert progress is not None
        assert progress.status == PhaseStatus.IN_PROGRESS

    def test_get_progress_not_found(self, tmp_path: Path):
        """Test getting progress for non-existent phase."""
        tracker = PhaseTracker(tmp_path)
        progress = tracker.get_progress("99")
        assert progress is None

    def test_list_phases(self, tmp_path: Path):
        """Test listing all phases."""
        tracker = PhaseTracker(tmp_path)
        tracker.start_phase("01")
        tracker.start_phase("02")
        tracker.start_phase("05")

        phases = tracker.list_phases()
        assert phases == ["01", "02", "05"]

    def test_get_active_phase(self, tmp_path: Path):
        """Test getting the active phase."""
        tracker = PhaseTracker(tmp_path)
        tracker.start_phase("01")
        tracker.complete_phase("01")
        tracker.start_phase("05")

        active = tracker.get_active_phase()
        assert active == "05"

    def test_get_active_phase_none(self, tmp_path: Path):
        """Test getting active phase when none active."""
        tracker = PhaseTracker(tmp_path)

        active = tracker.get_active_phase()
        assert active is None

    def test_get_blocked_phases(self, tmp_path: Path):
        """Test getting blocked phases."""
        tracker = PhaseTracker(tmp_path)
        tracker.start_phase("01")
        tracker.block_phase("02", "Blocked")
        tracker.start_phase("03")

        blocked = tracker.get_blocked_phases()
        assert blocked == ["02"]

    def test_get_blocked_phases_empty(self, tmp_path: Path):
        """Test getting blocked phases when none blocked."""
        tracker = PhaseTracker(tmp_path)
        tracker.start_phase("01")

        blocked = tracker.get_blocked_phases()
        assert blocked == []


class TestPhaseTrackerIntegration:
    """Integration tests for PhaseTracker."""

    def test_full_workflow(self, tmp_path: Path):
        """Test full workflow: start -> complete plans -> complete phase."""
        # Create phase directory
        phase_dir = tmp_path / "phases" / "05-test"
        phase_dir.mkdir(parents=True)
        (phase_dir / "05-01-PLAN.md").write_text("# Plan 1", encoding="utf-8")
        (phase_dir / "05-02-PLAN.md").write_text("# Plan 2", encoding="utf-8")
        (phase_dir / "05-03-PLAN.md").write_text("# Plan 3", encoding="utf-8")

        tracker = PhaseTracker(tmp_path)
        tracker.load()

        # Start phase
        tracker.start_phase("05")
        progress = tracker.get_progress("05")
        assert progress.status == PhaseStatus.IN_PROGRESS
        assert progress.plans_total == 3

        # Complete plans one by one
        tracker.complete_plan("05", "05-01")
        assert tracker.get_progress("05").plans_complete == 1

        tracker.complete_plan("05", "05-02")
        assert tracker.get_progress("05").plans_complete == 2

        # Last plan should auto-complete phase
        tracker.complete_plan("05", "05-03")
        progress = tracker.get_progress("05")
        assert progress.status == PhaseStatus.COMPLETE
        assert progress.progress_percent == 100.0

    def test_blocked_workflow(self, tmp_path: Path):
        """Test workflow with blocked phase."""
        tracker = PhaseTracker(tmp_path)

        # Start and block phase
        tracker.start_phase("05")
        tracker.block_phase("05", "Waiting for Phase 4")

        progress = tracker.get_progress("05")
        assert progress.is_blocked
        assert "05" in tracker.get_blocked_phases()

        # Unblock and continue
        tracker.start_phase("05")
        assert not tracker.get_progress("05").is_blocked
