"""
Tests for GSDShellTool.

Tests cover:
- Successful command execution
- Non-zero exit code handling
- Command timeout
- Project directory execution
- ShellResult properties
"""

import pytest
import tempfile
from pathlib import Path
import platform

from gsd_rlm.tools.shell_tool import GSDShellTool, ShellResult


@pytest.fixture
def temp_project():
    """Create a temporary project directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project = Path(tmpdir)
        yield project


class TestGSDShellTool:
    def test_successful_command(self, temp_project):
        """Successful command should return output."""
        tool = GSDShellTool(temp_project, timeout=10)
        result = tool.run("echo hello")

        assert "hello" in result
        assert "failed" not in result.lower()

    def test_command_with_exit_code(self, temp_project):
        """Non-zero exit code should be reported."""
        tool = GSDShellTool(temp_project, timeout=10)
        result = tool.run("exit 1")

        assert "exit code 1" in result

    def test_command_in_project_directory(self, temp_project):
        """Command should execute in project directory."""
        tool = GSDShellTool(temp_project, timeout=10)

        # Create a file in project
        (temp_project / "test.txt").write_text("content")

        # List files and check our file is there
        result = tool.run("ls")
        assert "test.txt" in result

    def test_command_timeout(self, temp_project):
        """Long-running command should timeout."""
        tool = GSDShellTool(temp_project, timeout=1)

        # Use Python to sleep - cross-platform
        result = tool.run('python -c "import time; time.sleep(10)"')

        assert "timed out" in result.lower()

    def test_run_sync_returns_result(self, temp_project):
        """run_sync should return ShellResult object."""
        tool = GSDShellTool(temp_project, timeout=10)
        result = tool.run_sync("echo test")

        assert isinstance(result, ShellResult)
        assert result.exit_code == 0
        assert "test" in result.stdout

    def test_with_timeout_creates_copy(self, temp_project):
        """with_timeout should create new instance."""
        tool = GSDShellTool(temp_project, timeout=10)
        tool2 = tool.with_timeout(30)

        assert tool.timeout == 10
        assert tool2.timeout == 30
        assert tool is not tool2

    def test_stderr_captured(self, temp_project):
        """Stderr should be captured in output."""
        tool = GSDShellTool(temp_project, timeout=10)

        # Write to stderr
        if platform.system() == "Windows":
            result = tool.run("echo error 1>&2")
        else:
            result = tool.run("echo error >&2")

        # Should have output (stdout + stderr combined)
        assert "error" in result.lower() or result  # May be in stdout or stderr

    def test_shell_result_properties(self, temp_project):
        """ShellResult properties should work correctly."""
        # Success case
        success = ShellResult(
            exit_code=0,
            stdout="output",
            stderr="",
            command="test",
        )
        assert success.success is True
        assert success.output == "output"

        # Failure case
        failure = ShellResult(
            exit_code=1,
            stdout="",
            stderr="error message",
            command="test",
        )
        assert failure.success is False
        assert "error message" in failure.output

        # Timeout case
        timeout_result = ShellResult(
            exit_code=-1,
            stdout="",
            stderr="",
            command="test",
            timed_out=True,
        )
        assert timeout_result.success is False
        assert "timed out" in str(timeout_result).lower()


class TestShellResultStr:
    def test_success_format(self):
        """Success result should format nicely."""
        result = ShellResult(
            exit_code=0,
            stdout="Done!",
            stderr="",
            command="echo test",
        )
        s = str(result)
        assert "✓" in s
        assert "Done!" in s

    def test_failure_format(self):
        """Failure result should show exit code."""
        result = ShellResult(
            exit_code=1,
            stdout="",
            stderr="Error!",
            command="exit 1",
        )
        s = str(result)
        assert "✗" in s
        assert "exit 1" in s

    def test_timeout_format(self):
        """Timeout result should indicate timeout."""
        result = ShellResult(
            exit_code=-1,
            stdout="",
            stderr="",
            command="sleep 100",
            timed_out=True,
        )
        s = str(result)
        assert "timed out" in s.lower()
