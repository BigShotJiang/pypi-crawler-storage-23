"""Auto-grouped modules for sensitivity analysis CLI handler."""
