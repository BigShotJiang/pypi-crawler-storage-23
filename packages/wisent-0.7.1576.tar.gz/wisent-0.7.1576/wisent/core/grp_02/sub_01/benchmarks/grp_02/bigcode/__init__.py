import os as _os
_base = _os.path.dirname(__file__)
for _root, _dirs, _files in _os.walk(_base):
    _dirs[:] = sorted(d for d in _dirs if d.startswith(("grp_", "sub_", "mid_")))
    if _root != _base:
        __path__.append(_root)

"""BigCode benchmark utilities and extractors."""

from .bigcode_extractors import get_bigcode_extractor
from .bigcode_integration import (
    BigCodeTaskLoader,
    BigCodeTask,
    BigCodeEvaluator,
    get_bigcode_loader,
    get_bigcode_evaluator,
    is_bigcode_task,
    load_bigcode_task,
    evaluate_bigcode_task,
)

__all__ = [
    'get_bigcode_extractor',
    'BigCodeTaskLoader',
    'BigCodeTask',
    'BigCodeEvaluator',
    'get_bigcode_loader',
    'get_bigcode_evaluator',
    'is_bigcode_task',
    'load_bigcode_task',
    'evaluate_bigcode_task',
]
