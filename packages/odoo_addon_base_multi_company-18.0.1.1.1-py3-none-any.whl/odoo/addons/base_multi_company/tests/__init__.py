# License LGPL-3 - See http://www.gnu.org/licenses/lgpl-3.0.html
from . import test_multi_company_abstract
