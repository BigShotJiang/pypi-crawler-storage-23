from .ele_tagger import tag_ele_quality
from .lpte_tagger import tag_lpte_quality
from .muon_tagger import tag_muon_quality