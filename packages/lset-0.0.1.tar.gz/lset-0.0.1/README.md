# LSET
Large Scale Embedding Trainer — PyTorch-native training framework for large-scale embedding and reranker models
