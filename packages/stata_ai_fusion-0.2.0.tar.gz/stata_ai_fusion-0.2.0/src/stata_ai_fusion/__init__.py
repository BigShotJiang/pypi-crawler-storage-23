"""Stata AI Fusion — MCP Server + Skill for Stata."""

__version__ = "0.1.0"
