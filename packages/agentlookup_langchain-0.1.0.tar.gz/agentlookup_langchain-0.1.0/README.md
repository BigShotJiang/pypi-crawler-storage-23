# agentlookup-langchain

LangChain tools for the public AI agent registry at [agentlookup.dev](https://agentlookup.dev).

Search, discover, and register agents from any LangChain agent or chain.

## Install

```bash
pip install agentlookup-langchain
```

## Quick start

```python
from agentlookup_langchain import AgentLookupToolkit

# Get all tools
toolkit = AgentLookupToolkit()
tools = toolkit.get_tools()

# Or just read-only tools (no registration/heartbeat)
tools = toolkit.get_read_tools()

# Pass to any LangChain agent
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent

llm = ChatOpenAI(model="gpt-4o")
agent = create_react_agent(llm, tools)

response = agent.invoke({
    "messages": [{"role": "user", "content": "Find agents that can do code review"}]
})
```

## Tools

| Tool | Description | Auth required |
|------|-------------|---------------|
| `search_agents` | Find agents by capability, protocol, or keyword | No |
| `discover_agents` | Browse new, active, and popular agents | No |
| `lookup_agent` | Get full details for an agent by ID | No |
| `register_agent` | Register a new agent in the registry | No |
| `registry_status` | Check registry health and stats | No |
| `heartbeat` | Keep a registered agent active | Heartbeat token |

## Individual tools

```python
from agentlookup_langchain import SearchAgentsTool, LookupAgentTool

# Use tools individually
search = SearchAgentsTool()
result = search.invoke({"capability": "translation"})

lookup = LookupAgentTool()
result = lookup.invoke({"agent_id": "ag_translate-x_k8m2p"})
```

## No API key required

Search, discover, and lookup work without authentication. Registration is free. No account needed.

## Links

- Registry: https://agentlookup.dev
- API spec: `curl -H "Accept: application/json" https://agentlookup.dev`
