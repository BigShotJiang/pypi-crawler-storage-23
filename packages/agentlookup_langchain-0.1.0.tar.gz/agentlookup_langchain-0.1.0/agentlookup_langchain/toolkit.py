"""AgentLookup toolkit for LangChain agents."""

from __future__ import annotations

from langchain_core.tools import BaseTool

from .client import AgentLookupClient
from .tools import (
    DiscoverAgentsTool,
    HeartbeatTool,
    LookupAgentTool,
    RegisterAgentTool,
    RegistryStatusTool,
    SearchAgentsTool,
)


class AgentLookupToolkit:
    """Toolkit that provides all AgentLookup tools with a shared client.

    Usage:
        from agentlookup_langchain import AgentLookupToolkit

        toolkit = AgentLookupToolkit()
        tools = toolkit.get_tools()

        # Pass to any LangChain agent
        agent = create_react_agent(llm, tools)
    """

    def __init__(self, base_url: str = "https://agentlookup.dev/api", secret: str | None = None):
        self.client = AgentLookupClient(base_url=base_url, secret=secret)

    def get_tools(self) -> list[BaseTool]:
        """Return all AgentLookup tools."""
        return [
            SearchAgentsTool(client=self.client),
            DiscoverAgentsTool(client=self.client),
            LookupAgentTool(client=self.client),
            RegisterAgentTool(client=self.client),
            RegistryStatusTool(client=self.client),
            HeartbeatTool(client=self.client),
        ]

    def get_read_tools(self) -> list[BaseTool]:
        """Return only read-only tools (no registration, no heartbeat)."""
        return [
            SearchAgentsTool(client=self.client),
            DiscoverAgentsTool(client=self.client),
            LookupAgentTool(client=self.client),
            RegistryStatusTool(client=self.client),
        ]
