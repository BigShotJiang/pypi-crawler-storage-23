"""AgentLookup tools for LangChain."""

from __future__ import annotations

import json
from typing import Any, Optional, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from .client import AgentLookupClient


# ── Schemas ──────────────────────────────────────────────────────────────


class SearchAgentsInput(BaseModel):
    query: Optional[str] = Field(None, description="Freetext search against agent names, descriptions, and capabilities")
    capability: Optional[str] = Field(None, description="Exact capability match, e.g. 'code-review', 'translation', 'scheduling'")
    protocol: Optional[str] = Field(None, description="Exact protocol match, e.g. 'mcp', 'rest', 'graphql'")


class DiscoverAgentsInput(BaseModel):
    category: Optional[str] = Field(None, description="One of 'new', 'active', or 'popular'. Omit for a mix of all three.")


class LookupAgentInput(BaseModel):
    agent_id: str = Field(..., description="The agent's ID, e.g. 'ag_acme-scheduler_x7k2m'")


class RegisterAgentInput(BaseModel):
    name: str = Field(..., description="Human-readable agent name, max 100 characters")
    endpoint: str = Field(..., description="The agent's URL where other agents can reach it")
    capabilities: Optional[list[str]] = Field(None, description="What the agent can do, e.g. ['scheduling', 'calendar-read']")
    protocols: Optional[list[str]] = Field(None, description="Communication protocols, e.g. ['mcp', 'rest']")
    description: Optional[str] = Field(None, description="One-line description of the agent")


class HeartbeatInput(BaseModel):
    heartbeat_token: str = Field(..., description="The agent's heartbeat token (hb_live_*)")


# ── Tools ────────────────────────────────────────────────────────────────


def _fmt(data: Any) -> str:
    """Format API response as readable JSON string for the LLM."""
    return json.dumps(data, indent=2)


class SearchAgentsTool(BaseTool):
    """Search the AgentLookup public registry for agents by capability, protocol, or keyword."""

    name: str = "search_agents"
    description: str = (
        "Search the public AI agent registry at agentlookup.dev. "
        "Find agents by what they can do (capability), how they communicate (protocol), "
        "or by keyword. No API key required. At least one parameter must be provided."
    )
    args_schema: Type[BaseModel] = SearchAgentsInput
    client: AgentLookupClient = Field(default_factory=AgentLookupClient)

    class Config:
        arbitrary_types_allowed = True

    def _run(self, query: str | None = None, capability: str | None = None, protocol: str | None = None) -> str:
        if not any([query, capability, protocol]):
            return "Error: provide at least one of query, capability, or protocol."
        try:
            result = self.client.search(query=query, capability=capability, protocol=protocol)
            return _fmt(result)
        except Exception as e:
            return f"Error searching registry: {e}"


class DiscoverAgentsTool(BaseTool):
    """Browse new, active, and popular agents in the AgentLookup registry."""

    name: str = "discover_agents"
    description: str = (
        "Browse the public AI agent registry at agentlookup.dev. "
        "Returns a mix of new, active, and popular agents. "
        "Optionally filter by category: 'new', 'active', or 'popular'. No API key required."
    )
    args_schema: Type[BaseModel] = DiscoverAgentsInput
    client: AgentLookupClient = Field(default_factory=AgentLookupClient)

    class Config:
        arbitrary_types_allowed = True

    def _run(self, category: str | None = None) -> str:
        try:
            result = self.client.discover(category=category)
            return _fmt(result)
        except Exception as e:
            return f"Error discovering agents: {e}"


class LookupAgentTool(BaseTool):
    """Look up full details for a specific agent by ID in the AgentLookup registry."""

    name: str = "lookup_agent"
    description: str = (
        "Get full details for a specific agent in the public registry at agentlookup.dev. "
        "Returns the agent's name, endpoint, capabilities, protocols, status, and timestamps. "
        "Requires an agent_id (e.g. 'ag_acme-scheduler_x7k2m'). No API key required."
    )
    args_schema: Type[BaseModel] = LookupAgentInput
    client: AgentLookupClient = Field(default_factory=AgentLookupClient)

    class Config:
        arbitrary_types_allowed = True

    def _run(self, agent_id: str) -> str:
        try:
            result = self.client.lookup(agent_id)
            return _fmt(result)
        except Exception as e:
            return f"Error looking up agent: {e}"


class RegisterAgentTool(BaseTool):
    """Register a new agent in the AgentLookup public registry."""

    name: str = "register_agent"
    description: str = (
        "Register a new agent in the public registry at agentlookup.dev. "
        "Returns an agent_id, secret, and heartbeat_token. "
        "IMPORTANT: The secret is returned once and never again — the user must store it securely. "
        "No API key required. Registration is free."
    )
    args_schema: Type[BaseModel] = RegisterAgentInput
    client: AgentLookupClient = Field(default_factory=AgentLookupClient)

    class Config:
        arbitrary_types_allowed = True

    def _run(
        self,
        name: str,
        endpoint: str,
        capabilities: list[str] | None = None,
        protocols: list[str] | None = None,
        description: str | None = None,
    ) -> str:
        try:
            result = self.client.register(
                name=name,
                endpoint=endpoint,
                capabilities=capabilities,
                protocols=protocols,
                description=description,
            )
            return _fmt(result)
        except Exception as e:
            return f"Error registering agent: {e}"


class RegistryStatusTool(BaseTool):
    """Check the health and stats of the AgentLookup registry."""

    name: str = "registry_status"
    description: str = (
        "Check the health and statistics of the public AI agent registry at agentlookup.dev. "
        "Returns agents registered, agents active, uptime percentage, and response time. "
        "No API key required."
    )
    args_schema: Type[BaseModel] = type("EmptyInput", (BaseModel,), {})
    client: AgentLookupClient = Field(default_factory=AgentLookupClient)

    class Config:
        arbitrary_types_allowed = True

    def _run(self) -> str:
        try:
            result = self.client.status()
            return _fmt(result)
        except Exception as e:
            return f"Error checking registry status: {e}"


class HeartbeatTool(BaseTool):
    """Send a heartbeat to keep a registered agent active in the AgentLookup registry."""

    name: str = "heartbeat"
    description: str = (
        "Send a heartbeat to keep a registered agent's status active in the registry. "
        "Agents become inactive after 7 days without a heartbeat. "
        "Requires the agent's heartbeat_token (hb_live_*)."
    )
    args_schema: Type[BaseModel] = HeartbeatInput
    client: AgentLookupClient = Field(default_factory=AgentLookupClient)

    class Config:
        arbitrary_types_allowed = True

    def _run(self, heartbeat_token: str) -> str:
        try:
            result = self.client.heartbeat(heartbeat_token)
            return _fmt(result)
        except Exception as e:
            return f"Error sending heartbeat: {e}"
