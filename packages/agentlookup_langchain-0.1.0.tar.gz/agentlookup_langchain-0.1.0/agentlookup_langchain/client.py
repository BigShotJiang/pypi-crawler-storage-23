"""AgentLookup API client. Shared between LangChain and CrewAI integrations."""

from __future__ import annotations

import httpx
from typing import Any


BASE_URL = "https://agentlookup.dev/api"
TIMEOUT = 10.0


class AgentLookupClient:
    """Thin HTTP client for the AgentLookup public registry."""

    def __init__(self, base_url: str = BASE_URL, secret: str | None = None):
        self.base_url = base_url.rstrip("/")
        self.secret = secret

    def _headers(self, auth: str | None = None) -> dict[str, str]:
        headers = {"Accept": "application/json", "Content-Type": "application/json"}
        token = auth or self.secret
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    def _get(self, path: str, params: dict | None = None, auth: str | None = None) -> dict[str, Any]:
        with httpx.Client(timeout=TIMEOUT) as client:
            resp = client.get(
                f"{self.base_url}{path}",
                params={k: v for k, v in (params or {}).items() if v is not None},
                headers=self._headers(auth),
            )
            resp.raise_for_status()
            return resp.json()

    def _post(self, path: str, json: dict | None = None, auth: str | None = None) -> dict[str, Any]:
        with httpx.Client(timeout=TIMEOUT) as client:
            resp = client.post(
                f"{self.base_url}{path}",
                json=json,
                headers=self._headers(auth),
            )
            resp.raise_for_status()
            return resp.json()

    def search(
        self,
        query: str | None = None,
        capability: str | None = None,
        protocol: str | None = None,
    ) -> dict[str, Any]:
        """Search for agents by keyword, capability, or protocol."""
        return self._get("/search", params={"q": query, "capability": capability, "protocol": protocol})

    def discover(self, category: str | None = None) -> dict[str, Any]:
        """Browse new, active, and popular agents."""
        return self._get("/discover", params={"category": category})

    def lookup(self, agent_id: str) -> dict[str, Any]:
        """Get full details for an agent by ID."""
        return self._get(f"/a/{agent_id}")

    def register(
        self,
        name: str,
        endpoint: str,
        capabilities: list[str] | None = None,
        protocols: list[str] | None = None,
        description: str | None = None,
        webhook_url: str | None = None,
    ) -> dict[str, Any]:
        """Register a new agent in the public registry."""
        payload: dict[str, Any] = {"name": name, "endpoint": endpoint}
        if capabilities:
            payload["capabilities"] = capabilities
        if protocols:
            payload["protocols"] = protocols
        if description:
            payload["description"] = description
        if webhook_url:
            payload["webhook_url"] = webhook_url
        return self._post("/register", json=payload)

    def status(self) -> dict[str, Any]:
        """Check registry health and stats."""
        return self._get("/status")

    def heartbeat(self, heartbeat_token: str) -> dict[str, Any]:
        """Send a heartbeat to keep an agent active."""
        return self._post("/heartbeat", auth=heartbeat_token)
