from wecom_smartsheet.client import WeComSmartSheetClient


def test_refresh_token_once_on_invalid_token(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    next_tokens = ["tok-old", "tok-new"]

    def fake_get_access_token():
        if client._access_token is None:
            client._access_token = next_tokens.pop(0)
        return client._access_token

    monkeypatch.setattr(client, "_get_access_token", fake_get_access_token)
    calls = {"n": 0}

    def fake_http_post(url, payload, timeout):
        calls["n"] += 1
        if calls["n"] == 1:
            return {"errcode": 40014, "errmsg": "invalid access token"}
        return {"errcode": 0, "records": [], "has_more": False}

    monkeypatch.setattr(client, "_http_post_json", fake_http_post)

    out = client.fetch_records(docid="d", sheet_id="s")
    assert out == []
    assert calls["n"] == 2
