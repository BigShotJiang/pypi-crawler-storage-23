from wecom_smartsheet.client import WeComAPIError, WeComSmartSheetClient


def test_post_json_raises_on_api_error(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    monkeypatch.setattr(client, "_get_access_token", lambda: "tok")
    monkeypatch.setattr(
        client, "_http_post_json", lambda url, payload, timeout: {"errcode": 40013, "errmsg": "bad"}
    )
    try:
        client._post_json("/cgi-bin/wedoc/smartsheet/get_records", {"x": 1})
        assert False, "expected WeComAPIError"
    except WeComAPIError as exc:
        assert "40013" in str(exc)


def test_post_json_success(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    monkeypatch.setattr(client, "_get_access_token", lambda: "tok")
    monkeypatch.setattr(
        client, "_http_post_json", lambda url, payload, timeout: {"errcode": 0, "records": []}
    )
    data = client._post_json("cgi-bin/wedoc/smartsheet/get_records", {"x": 1})
    assert data["errcode"] == 0
