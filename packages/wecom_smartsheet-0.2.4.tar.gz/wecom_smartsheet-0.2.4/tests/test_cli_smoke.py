import sys

import wecom_smartsheet_fetch as cli


def test_cli_main_uses_sdk_client(monkeypatch):
    calls = {"json": 0, "csv": 0}

    class FakeClient:
        def __init__(self, corpid, corpsecret, timeout=20):
            assert corpid == "ww"
            assert corpsecret == "sec"

        def fetch_records_to_json(self, **kwargs):
            calls["json"] += 1

        def fetch_records_to_csv(self, **kwargs):
            calls["csv"] += 1

    monkeypatch.setattr(cli, "WeComSmartSheetClient", FakeClient)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "wecom_smartsheet_fetch.py",
            "--corpid",
            "ww",
            "--corpsecret",
            "sec",
            "--docid",
            "doc",
            "--sheet-id",
            "sheet",
            "--output",
            "out.json",
            "--format",
            "json",
        ],
    )
    code = cli.main()
    assert code == 0
    assert calls["json"] == 1
