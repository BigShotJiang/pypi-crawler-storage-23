from wecom_smartsheet.client import WeComSmartSheetClient


def test_client_init_sets_basic_fields():
    client = WeComSmartSheetClient(corpid="ww1", corpsecret="sec1", timeout=30)
    assert client.corpid == "ww1"
    assert client.corpsecret == "sec1"
    assert client.timeout == 30
    assert client._access_token is None


def test_invalid_timeout_raises_value_error():
    try:
        WeComSmartSheetClient(corpid="ww1", corpsecret="sec1", timeout=0)
        assert False, "expected ValueError"
    except ValueError:
        assert True
