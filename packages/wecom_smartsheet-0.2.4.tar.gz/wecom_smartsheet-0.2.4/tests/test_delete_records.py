from wecom_smartsheet.client import WeComSmartSheetClient


def test_delete_single_record(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    monkeypatch.setattr(
        client,
        "_post_json",
        lambda endpoint, payload: {"errcode": 0},
    )
    result = client.delete_records(
        docid="doc123", sheet_id="sheet456", record_ids="rec_001"
    )
    assert result == {"errcode": 0}


def test_delete_multiple_records(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    monkeypatch.setattr(
        client,
        "_post_json",
        lambda endpoint, payload: {"errcode": 0},
    )
    result = client.delete_records(
        docid="doc123",
        sheet_id="sheet456",
        record_ids=["rec_001", "rec_002"],
    )
    assert result == {"errcode": 0}


def test_delete_records_validates_empty_docid():
    client = WeComSmartSheetClient("ww1", "sec1")
    try:
        client.delete_records(docid="", sheet_id="sheet456", record_ids="rec_001")
        assert False, "expected ValueError"
    except ValueError as exc:
        assert "docid" in str(exc).lower()


def test_delete_records_validates_empty_sheet_id():
    client = WeComSmartSheetClient("ww1", "sec1")
    try:
        client.delete_records(docid="doc123", sheet_id="", record_ids="rec_001")
        assert False, "expected ValueError"
    except ValueError as exc:
        assert "sheet_id" in str(exc).lower()


def test_delete_records_validates_none_record_ids():
    client = WeComSmartSheetClient("ww1", "sec1")
    try:
        client.delete_records(docid="doc123", sheet_id="sheet456", record_ids=None)
        assert False, "expected ValueError"
    except ValueError as exc:
        assert "record_ids" in str(exc).lower()


def test_delete_records_validates_empty_list():
    client = WeComSmartSheetClient("ww1", "sec1")
    try:
        client.delete_records(docid="doc123", sheet_id="sheet456", record_ids=[])
        assert False, "expected ValueError"
    except ValueError as exc:
        assert "record_ids" in str(exc).lower()


def test_delete_records_payload_structure(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    captured_payload = {}

    def mock_post_json(endpoint, payload):
        captured_payload.update(payload)
        return {"errcode": 0}

    monkeypatch.setattr(client, "_post_json", mock_post_json)

    client.delete_records(
        docid="doc123",
        sheet_id="sheet456",
        record_ids=["rec_001"],
    )

    assert captured_payload == {
        "docid": "doc123",
        "sheet_id": "sheet456",
        "record_ids": ["rec_001"],
    }
