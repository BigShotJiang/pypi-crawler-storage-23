from wecom_smartsheet.client import WeComSmartSheetClient


def test_write_operations_share_token_management(monkeypatch):
    """Verify all write operations use the same token management"""
    client = WeComSmartSheetClient("ww1", "sec1")

    token_call_count = 0
    def mock_http_get_json(url, timeout):
        nonlocal token_call_count
        token_call_count += 1
        return {"errcode": 0, "access_token": "shared_token"}

    def mock_http_post_json(url, payload, timeout):
        assert "shared_token" in url
        return {"errcode": 0}

    monkeypatch.setattr(client, "_http_get_json", mock_http_get_json)
    monkeypatch.setattr(client, "_http_post_json", mock_http_post_json)

    client.add_records(docid="d1", sheet_id="s1", records={"values": {}})
    client.update_records(docid="d1", sheet_id="s1", records={"record_id": "r1", "values": {}})
    client.delete_records(docid="d1", sheet_id="s1", record_ids="r1")

    assert token_call_count == 1, "Token should be cached and reused"
