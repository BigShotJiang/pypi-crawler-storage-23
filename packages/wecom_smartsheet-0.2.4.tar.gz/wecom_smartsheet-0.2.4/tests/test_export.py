import json
import shutil
from pathlib import Path

from wecom_smartsheet.client import WeComSmartSheetClient


def test_export_json_and_csv(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    monkeypatch.setattr(
        client,
        "fetch_records",
        lambda **kwargs: [{"record_id": "1", "values": {"Name": "Alice"}}],
    )

    work = Path("tests/.tmp/export")
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True, exist_ok=True)
    json_path = work / "out.json"
    csv_path = work / "out.csv"

    client.fetch_records_to_json(docid="d", sheet_id="s", output_path=str(json_path))
    client.fetch_records_to_csv(docid="d", sheet_id="s", output_path=str(csv_path))

    assert json_path.exists()
    assert csv_path.exists()
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert data[0]["record_id"] == "1"
    shutil.rmtree(work)
