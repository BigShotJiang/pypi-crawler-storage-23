from wecom_smartsheet.client import WeComSmartSheetClient


def test_fetch_records_paginated(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    pages = [
        {
            "errcode": 0,
            "records": [{"record_id": "1", "values": {}}],
            "has_more": True,
            "next_offset": "A",
        },
        {"errcode": 0, "records": [{"record_id": "2", "values": {}}], "has_more": False},
    ]

    def fake_post(endpoint, payload):
        return pages.pop(0)

    monkeypatch.setattr(client, "_post_json", fake_post)
    out = client.fetch_records(docid="d", sheet_id="s")
    assert [r["record_id"] for r in out] == ["1", "2"]


def test_fetch_records_invalid_page_size_raises():
    client = WeComSmartSheetClient("ww1", "sec1")
    try:
        client.fetch_records(docid="d", sheet_id="s", page_size=0)
        assert False, "expected ValueError"
    except ValueError:
        assert True
