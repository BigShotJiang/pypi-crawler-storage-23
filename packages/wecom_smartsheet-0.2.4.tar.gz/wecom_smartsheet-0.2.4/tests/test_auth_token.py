from wecom_smartsheet.client import WeComAPIError, WeComSmartSheetClient


def test_get_access_token_cached(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    calls = {"n": 0}

    def fake_get_json(url, timeout):
        calls["n"] += 1
        return {"errcode": 0, "access_token": "tok-1"}

    monkeypatch.setattr(client, "_http_get_json", fake_get_json)
    assert client._get_access_token() == "tok-1"
    assert client._get_access_token() == "tok-1"
    assert calls["n"] == 1


def test_get_access_token_raises_on_api_error(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    monkeypatch.setattr(
        client, "_http_get_json", lambda url, timeout: {"errcode": 1, "errmsg": "bad"}
    )
    try:
        client._get_access_token()
        assert False, "expected WeComAPIError"
    except WeComAPIError:
        assert True
