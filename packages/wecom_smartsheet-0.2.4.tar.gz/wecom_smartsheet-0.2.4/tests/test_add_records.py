from wecom_smartsheet.client import WeComSmartSheetClient


def test_add_single_record(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    monkeypatch.setattr(
        client,
        "_post_json",
        lambda endpoint, payload: {"errcode": 0, "record_ids": ["rec_001"]},
    )
    result = client.add_records(
        docid="doc123", sheet_id="sheet456", records=[{"field1": "value1"}]
    )
    assert result == {"errcode": 0, "record_ids": ["rec_001"]}


def test_add_multiple_records(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    monkeypatch.setattr(
        client,
        "_post_json",
        lambda endpoint, payload: {"errcode": 0, "record_ids": ["rec_001", "rec_002"]},
    )
    result = client.add_records(
        docid="doc123",
        sheet_id="sheet456",
        records=[{"field1": "value1"}, {"field1": "value2"}],
    )
    assert result == {"errcode": 0, "record_ids": ["rec_001", "rec_002"]}


def test_add_records_validates_empty_docid():
    client = WeComSmartSheetClient("ww1", "sec1")
    try:
        client.add_records(docid="", sheet_id="sheet456", records=[{"field1": "value1"}])
        assert False, "expected ValueError"
    except ValueError as exc:
        assert "docid" in str(exc).lower()


def test_add_records_validates_empty_sheet_id():
    client = WeComSmartSheetClient("ww1", "sec1")
    try:
        client.add_records(docid="doc123", sheet_id="", records=[{"field1": "value1"}])
        assert False, "expected ValueError"
    except ValueError as exc:
        assert "sheet_id" in str(exc).lower()


def test_add_records_validates_none_records():
    client = WeComSmartSheetClient("ww1", "sec1")
    try:
        client.add_records(docid="doc123", sheet_id="sheet456", records=None)
        assert False, "expected ValueError"
    except ValueError as exc:
        assert "records" in str(exc).lower()


def test_add_records_validates_empty_list():
    client = WeComSmartSheetClient("ww1", "sec1")
    try:
        client.add_records(docid="doc123", sheet_id="sheet456", records=[])
        assert False, "expected ValueError"
    except ValueError as exc:
        assert "records" in str(exc).lower()


def test_add_records_payload_structure(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    captured_payload = {}

    def mock_post_json(endpoint, payload):
        captured_payload.update(payload)
        return {"errcode": 0, "record_ids": ["rec_001"]}

    monkeypatch.setattr(client, "_post_json", mock_post_json)

    client.add_records(
        docid="doc123",
        sheet_id="sheet456",
        records=[{"field1": "value1"}],
        key_type="CELL_VALUE_KEY_TYPE_FIELD_TITLE",
    )

    assert captured_payload == {
        "docid": "doc123",
        "sheet_id": "sheet456",
        "key_type": "CELL_VALUE_KEY_TYPE_FIELD_TITLE",
        "records": [{"field1": "value1"}],
    }
