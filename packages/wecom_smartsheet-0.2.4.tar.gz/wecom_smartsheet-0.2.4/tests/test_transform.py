from wecom_smartsheet.client import WeComSmartSheetClient


def test_transform_flat_returns_flat_records(monkeypatch):
    client = WeComSmartSheetClient("ww1", "sec1")
    monkeypatch.setattr(
        client,
        "_post_json",
        lambda endpoint, payload: {
            "errcode": 0,
            "records": [{"record_id": "1", "values": {"Name": "Alice", "Meta": {"x": 1}}}],
            "has_more": False,
        },
    )
    out = client.fetch_records(docid="d", sheet_id="s", transform="flat")
    assert out[0]["record_id"] == "1"
    assert out[0]["Name"] == "Alice"
    assert isinstance(out[0]["Meta"], str)


def test_transform_invalid_raises():
    client = WeComSmartSheetClient("ww1", "sec1")
    try:
        client.fetch_records(docid="d", sheet_id="s", transform="bad")
        assert False, "expected ValueError"
    except ValueError:
        assert True
