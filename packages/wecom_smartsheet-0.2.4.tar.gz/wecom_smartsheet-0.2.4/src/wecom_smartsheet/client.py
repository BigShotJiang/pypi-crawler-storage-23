from __future__ import annotations

import json
import time
import csv
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional, Union


BASE_URL = "https://qyapi.weixin.qq.com"
TOKEN_INVALID_ERRCODES = {40014, 42001}


class WeComAPIError(RuntimeError):
    pass


class WeComSmartSheetClient:
    def __init__(self, corpid: str, corpsecret: str, timeout: int = 20) -> None:
        if timeout <= 0:
            raise ValueError("timeout must be > 0")
        self.corpid = corpid
        self.corpsecret = corpsecret
        self.timeout = timeout
        self._access_token: Optional[str] = None

    def _http_get_json(self, url: str, timeout: int) -> Dict[str, Any]:
        req = urllib.request.Request(url=url, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            raise WeComAPIError(f"HTTP {exc.code}: {exc.reason}") from exc
        except urllib.error.URLError as exc:
            raise WeComAPIError(f"Network error: {exc}") from exc

    def _http_post_json(self, url: str, payload: Dict[str, Any], timeout: int) -> Dict[str, Any]:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            url=url,
            data=body,
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            raise WeComAPIError(f"HTTP {exc.code}: {exc.reason}") from exc
        except urllib.error.URLError as exc:
            raise WeComAPIError(f"Network error: {exc}") from exc

    def _get_access_token(self) -> str:
        if self._access_token:
            return self._access_token

        query = urllib.parse.urlencode(
            {"corpid": self.corpid, "corpsecret": self.corpsecret}
        )
        url = f"{BASE_URL}/cgi-bin/gettoken?{query}"
        data = self._http_get_json(url, self.timeout)
        if data.get("errcode", 0) != 0:
            raise WeComAPIError(
                f"gettoken failed, errcode={data.get('errcode')} errmsg={data.get('errmsg')}"
            )
        token = data.get("access_token")
        if not token:
            raise WeComAPIError("gettoken succeeded but access_token is empty")
        self._access_token = token
        return token

    def _post_json(self, endpoint: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        normalized = endpoint if endpoint.startswith("/") else f"/{endpoint}"
        for attempt in range(2):
            access_token = self._get_access_token()
            query = urllib.parse.urlencode({"access_token": access_token})
            url = f"{BASE_URL}{normalized}?{query}"
            data = self._http_post_json(url, payload, self.timeout)
            errcode = int(data.get("errcode", 0))
            if errcode == 0:
                return data
            if errcode in TOKEN_INVALID_ERRCODES and attempt == 0:
                self._access_token = None
                continue
            raise WeComAPIError(
                f"API call failed: endpoint={normalized}, "
                f"errcode={data.get('errcode')} errmsg={data.get('errmsg')}"
            )
        raise WeComAPIError(f"API call failed: endpoint={normalized}, unknown error")

    @staticmethod
    def _extract_records(data: Dict[str, Any]) -> List[Dict[str, Any]]:
        candidates = [
            data.get("records"),
            data.get("record_list"),
            data.get("data", {}).get("records")
            if isinstance(data.get("data"), dict)
            else None,
        ]
        for item in candidates:
            if isinstance(item, list):
                return item
        return []

    @staticmethod
    def _extract_next_offset(data: Dict[str, Any]) -> Optional[Any]:
        for key in ("next_offset", "offset", "next"):
            if key in data:
                return data[key]
        if isinstance(data.get("data"), dict):
            inner = data["data"]
            for key in ("next_offset", "offset", "next"):
                if key in inner:
                    return inner[key]
        return None

    @staticmethod
    def _extract_has_more(data: Dict[str, Any]) -> bool:
        for key in ("has_more", "hasMore"):
            if key in data:
                return bool(data[key])
        if isinstance(data.get("data"), dict):
            inner = data["data"]
            for key in ("has_more", "hasMore"):
                if key in inner:
                    return bool(inner[key])
        return False

    @staticmethod
    def _flatten_record(record: Dict[str, Any]) -> Dict[str, Any]:
        out: Dict[str, Any] = {"record_id": record.get("record_id", "")}
        values = record.get("values", {})
        if not isinstance(values, dict):
            out["values"] = json.dumps(values, ensure_ascii=False)
            return out

        for key, value in values.items():
            if isinstance(value, (dict, list)):
                out[str(key)] = json.dumps(value, ensure_ascii=False)
            else:
                out[str(key)] = value
        return out

    def fetch_records(
        self,
        *,
        docid: str,
        sheet_id: str,
        view_id: Optional[str] = None,
        key_type: str = "CELL_VALUE_KEY_TYPE_FIELD_TITLE",
        page_size: int = 200,
        max_pages: int = 100,
        pause_seconds: float = 0.05,
        transform: str = "raw",
        endpoint: str = "/cgi-bin/wedoc/smartsheet/get_records",
    ) -> List[Dict[str, Any]]:
        if page_size <= 0:
            raise ValueError("page_size must be > 0")
        if max_pages <= 0:
            raise ValueError("max_pages must be > 0")
        if pause_seconds < 0:
            raise ValueError("pause_seconds must be >= 0")
        if transform not in ("raw", "flat"):
            raise ValueError("transform must be 'raw' or 'flat'")

        all_records: List[Dict[str, Any]] = []
        offset: Optional[Any] = None

        for _ in range(max_pages):
            payload: Dict[str, Any] = {
                "docid": docid,
                "sheet_id": sheet_id,
                "key_type": key_type,
                "limit": page_size,
            }
            if view_id:
                payload["view_id"] = view_id
            if offset is not None:
                payload["offset"] = offset

            data = self._post_json(endpoint, payload)
            page_records = self._extract_records(data)
            all_records.extend(page_records)

            has_more = self._extract_has_more(data)
            next_offset = self._extract_next_offset(data)
            if not has_more or next_offset is None:
                break

            offset = next_offset
            if pause_seconds > 0:
                time.sleep(pause_seconds)

        if transform == "flat":
            return [self._flatten_record(rec) for rec in all_records]
        return all_records

    def fetch_records_to_json(
        self,
        *,
        docid: str,
        sheet_id: str,
        output_path: str,
        **kwargs: Any,
    ) -> None:
        records = self.fetch_records(docid=docid, sheet_id=sheet_id, **kwargs)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)

    def fetch_records_to_csv(
        self,
        *,
        docid: str,
        sheet_id: str,
        output_path: str,
        **kwargs: Any,
    ) -> None:
        records = self.fetch_records(docid=docid, sheet_id=sheet_id, **kwargs)
        fieldnames = set()
        rows: List[Dict[str, Any]] = []
        for rec in records:
            if "values" in rec:
                row = {
                    "record_id": rec.get("record_id", ""),
                    "values": json.dumps(rec.get("values", {}), ensure_ascii=False),
                }
            else:
                row = dict(rec)
                row.setdefault("record_id", "")
            rows.append(row)
            fieldnames.update(row.keys())

        with open(output_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=sorted(fieldnames))
            writer.writeheader()
            writer.writerows(rows)

    def add_records(
        self,
        *,
        docid: str,
        sheet_id: str,
        records: Union[Dict[str, Any], List[Dict[str, Any]]],
        key_type: str = "CELL_VALUE_KEY_TYPE_FIELD_TITLE",
    ) -> Dict[str, Any]:
        """Add one or more records to a WeCom smartsheet.

        Args:
            docid: The document ID of the smartsheet.
            sheet_id: The sheet ID within the document.
            records: A single record dict or a list of record dicts to add.
            key_type: The key type for field identification. Defaults to
                "CELL_VALUE_KEY_TYPE_FIELD_TITLE".

        Returns:
            The API response dict containing the result of the add operation,
            typically including record_ids of the newly created records.

        Raises:
            ValueError: When docid is empty, sheet_id is empty, records is None,
                or records list is empty.
            WeComAPIError: When the API call fails or returns an error code.
        """
        if not docid:
            raise ValueError("docid must be non-empty")
        if not sheet_id:
            raise ValueError("sheet_id must be non-empty")
        if records is None:
            raise ValueError("records must not be None")

        if isinstance(records, dict):
            records = [records]

        if not records:
            raise ValueError("records list must not be empty")

        payload = {
            "docid": docid,
            "sheet_id": sheet_id,
            "key_type": key_type,
            "records": records,
        }

        return self._post_json("/cgi-bin/wedoc/smartsheet/add_records", payload)

    def update_records(
        self,
        *,
        docid: str,
        sheet_id: str,
        records: Union[Dict[str, Any], List[Dict[str, Any]]],
        key_type: str = "CELL_VALUE_KEY_TYPE_FIELD_TITLE",
    ) -> Dict[str, Any]:
        """Update one or more records in a WeCom smartsheet.

        Args:
            docid: The document ID of the smartsheet.
            sheet_id: The sheet ID within the document.
            records: A single record dict or a list of record dicts to update.
                Each record must contain a 'record_id' field.
            key_type: The key type for field identification. Defaults to
                "CELL_VALUE_KEY_TYPE_FIELD_TITLE".

        Returns:
            The API response dict containing the result of the update operation,
            typically including record_ids of the updated records.

        Raises:
            ValueError: When docid is empty, sheet_id is empty, records is None,
                records list is empty, or any record is missing 'record_id'.
            WeComAPIError: When the API call fails or returns an error code.
        """
        if not docid:
            raise ValueError("docid must be non-empty")
        if not sheet_id:
            raise ValueError("sheet_id must be non-empty")
        if records is None:
            raise ValueError("records must not be None")

        if isinstance(records, dict):
            records = [records]

        if not records:
            raise ValueError("records list must not be empty")

        for record in records:
            if "record_id" not in record:
                raise ValueError("each record must contain 'record_id'")

        payload = {
            "docid": docid,
            "sheet_id": sheet_id,
            "key_type": key_type,
            "records": records,
        }

        return self._post_json("/cgi-bin/wedoc/smartsheet/update_records", payload)

    def delete_records(
        self,
        *,
        docid: str,
        sheet_id: str,
        record_ids: Union[str, List[str]],
    ) -> Dict[str, Any]:
        """Delete one or more records from a WeCom smartsheet.

        Args:
            docid: The document ID of the smartsheet.
            sheet_id: The sheet ID within the document.
            record_ids: A single record ID string or a list of record ID strings to delete.

        Returns:
            The API response dict containing the result of the delete operation.

        Raises:
            ValueError: When docid is empty, sheet_id is empty, record_ids is None,
                or record_ids list is empty.
            WeComAPIError: When the API call fails or returns an error code.
        """
        if not docid:
            raise ValueError("docid must be non-empty")
        if not sheet_id:
            raise ValueError("sheet_id must be non-empty")
        if record_ids is None:
            raise ValueError("record_ids must not be None")

        if isinstance(record_ids, str):
            record_ids = [record_ids]

        if not record_ids:
            raise ValueError("record_ids list must not be empty")

        payload = {
            "docid": docid,
            "sheet_id": sheet_id,
            "record_ids": record_ids,
        }

        return self._post_json("/cgi-bin/wedoc/smartsheet/delete_records", payload)
