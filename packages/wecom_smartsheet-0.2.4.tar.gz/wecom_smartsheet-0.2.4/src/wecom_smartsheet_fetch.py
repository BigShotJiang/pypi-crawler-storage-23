from __future__ import annotations

import argparse
import sys

from wecom_smartsheet import WeComAPIError, WeComSmartSheetClient


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Fetch WeCom SmartSheet records.")
    parser.add_argument("--corpid", required=True, help="WeCom corp ID")
    parser.add_argument("--corpsecret", required=True, help="WeCom app secret")
    parser.add_argument("--docid", required=True, help="SmartSheet docid")
    parser.add_argument("--sheet-id", required=True, help="SmartSheet sheet_id")
    parser.add_argument("--view-id", default=None, help="Optional view_id")
    parser.add_argument(
        "--endpoint",
        default="/cgi-bin/wedoc/smartsheet/get_records",
        help="API endpoint path (default: /cgi-bin/wedoc/smartsheet/get_records)",
    )
    parser.add_argument(
        "--key-type",
        default="CELL_VALUE_KEY_TYPE_FIELD_TITLE",
        help="CELL_VALUE_KEY_TYPE_* value",
    )
    parser.add_argument("--page-size", type=int, default=200, help="Records per page")
    parser.add_argument("--max-pages", type=int, default=100, help="Max pages to fetch")
    parser.add_argument("--pause-seconds", type=float, default=0.05, help="Pause between pages")
    parser.add_argument("--timeout", type=int, default=20, help="HTTP timeout in seconds")
    parser.add_argument("--output", required=True, help="Output file path")
    parser.add_argument(
        "--format",
        choices=("json", "csv"),
        default="json",
        help="Output format",
    )
    parser.add_argument(
        "--transform",
        choices=("raw", "flat"),
        default="raw",
        help="Record shape: raw records or flattened records",
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    try:
        client = WeComSmartSheetClient(
            corpid=args.corpid,
            corpsecret=args.corpsecret,
            timeout=args.timeout,
        )
        fetch_kwargs = {
            "docid": args.docid,
            "sheet_id": args.sheet_id,
            "view_id": args.view_id,
            "key_type": args.key_type,
            "page_size": args.page_size,
            "max_pages": args.max_pages,
            "pause_seconds": args.pause_seconds,
            "transform": args.transform,
            "endpoint": args.endpoint,
        }

        if args.format == "json":
            client.fetch_records_to_json(output_path=args.output, **fetch_kwargs)
        else:
            client.fetch_records_to_csv(output_path=args.output, **fetch_kwargs)

        print(f"OK: exported records -> {args.output}")
        return 0
    except WeComAPIError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:  # pragma: no cover
        print(f"ERROR: unexpected failure: {exc}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
