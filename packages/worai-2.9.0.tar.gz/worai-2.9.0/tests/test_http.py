from __future__ import annotations

from worai.core.http import DEFAULT_USER_AGENT, build_default_user_agent


def test_default_user_agent_contains_wlbot_worai() -> None:
    ua = build_default_user_agent()
    assert "WLBot/worai-" in ua
    assert "contact: support@wordlift.io" in ua
    assert "Chrome/" in ua


def test_default_user_agent_constant_matches_builder() -> None:
    assert DEFAULT_USER_AGENT == build_default_user_agent()
