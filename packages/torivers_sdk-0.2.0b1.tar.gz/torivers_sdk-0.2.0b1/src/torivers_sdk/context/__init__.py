"""
Context module - Execution context and credential management.

This module provides context objects that are injected into automation
state during execution. These objects allow automations to report progress,
access credentials securely, and interact with the ToRivers platform.
"""

from torivers_sdk.context.actions import ActionClient, ActionError
from torivers_sdk.context.clients import (
    EmailDraft,
    EmailMessage,
    GmailClient,
    GoogleSheetsClient,
    ServiceClient,
    SheetRange,
    SlackChannel,
    SlackClient,
    SlackMessage,
    SpreadsheetInfo,
    get_client_class,
    list_supported_services,
)
from torivers_sdk.context.credentials import (
    CredentialError,
    CredentialNotAllowedError,
    CredentialNotConfiguredError,
    CredentialProxy,
)
from torivers_sdk.context.execution import ExecutionContext
from torivers_sdk.context.mocks import (
    MockCredentialProxy,
    MockGmailClient,
    MockGoogleSheetsClient,
    MockSlackClient,
)
from torivers_sdk.context.progress import (
    ConsoleProgressReporter,
    LogLevel,
    MockProgressReporter,
    ProgressEntry,
    ProgressReporter,
    ProgressReporterBase,
)

__all__ = [
    # Execution context
    "ExecutionContext",
    "ActionClient",
    "ActionError",
    # Credential management
    "CredentialProxy",
    "CredentialError",
    "CredentialNotAllowedError",
    "CredentialNotConfiguredError",
    # Service clients
    "ServiceClient",
    "GmailClient",
    "GoogleSheetsClient",
    "SlackClient",
    # Service client data types
    "EmailMessage",
    "EmailDraft",
    "SpreadsheetInfo",
    "SheetRange",
    "SlackChannel",
    "SlackMessage",
    # Client utilities
    "get_client_class",
    "list_supported_services",
    # Mock clients for testing
    "MockCredentialProxy",
    "MockGmailClient",
    "MockGoogleSheetsClient",
    "MockSlackClient",
    # Progress reporting
    "ProgressReporter",
    "ProgressReporterBase",
    "MockProgressReporter",
    "ConsoleProgressReporter",
    "ProgressEntry",
    "LogLevel",
]
