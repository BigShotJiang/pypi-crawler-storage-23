"""
ToRivers SDK - Build automations for the ToRivers marketplace.

This SDK provides the tools and abstractions needed to create, test, and submit
automations to the ToRivers marketplace. Developers use this SDK to:

- Create LangGraph-based automation workflows
- Access user credentials securely via proxies
- Test automations locally in sandboxed environments
- Submit automations for review and publication

Example:
    from torivers_sdk import Automation, AutomationMetadata, BaseState, StateGraph, START, END

    class MyAutomation(Automation[MyState]):
        def metadata(self) -> AutomationMetadata:
            return AutomationMetadata(
                name="my-automation",
                title="My Automation",
                version="1.0.0",
                description="Does something useful",
            )

        def build_graph(self) -> StateGraph:
            graph = StateGraph(MyState)
            graph.add_node("process", self.process)
            graph.add_edge(START, "process")
            graph.add_edge("process", END)
            return graph

        # Load from YAML manifest
        metadata = AutomationMetadata.from_yaml("automation.yaml")
"""

__version__ = "0.2.0b1"

# Re-export langgraph graph building primitives
from langgraph.graph import END, START, StateGraph

from torivers_sdk.automation.base import Automation
from torivers_sdk.automation.decorators import node, tool
from torivers_sdk.automation.metadata import (
    AutomationKind,
    AutomationMetadata,
    AutomationType,
    ExecutionLimits,
    InputField,
    OutputField,
)
from torivers_sdk.automation.state import BaseState, append_list, last_value, merge_dict
from torivers_sdk.context.actions import ActionClient, ActionError
from torivers_sdk.context.credentials import (
    CredentialError,
    CredentialNotAllowedError,
    CredentialNotConfiguredError,
    CredentialProxy,
)
from torivers_sdk.context.execution import ExecutionContext
from torivers_sdk.context.mocks import MockCredentialProxy
from torivers_sdk.context.progress import (
    ConsoleProgressReporter,
    LogLevel,
    MockProgressReporter,
    ProgressEntry,
    ProgressReporter,
    ProgressReporterBase,
)

__all__ = [
    # Version
    "__version__",
    # LangGraph re-exports
    "StateGraph",
    "START",
    "END",
    # Core automation classes
    "Automation",
    "AutomationKind",
    "AutomationMetadata",
    "AutomationType",
    "ExecutionLimits",
    "InputField",
    "OutputField",
    "BaseState",
    # State reducers
    "merge_dict",
    "append_list",
    "last_value",
    # Decorators
    "node",
    "tool",
    # Context
    "ExecutionContext",
    "ActionClient",
    "ActionError",
    "CredentialProxy",
    "MockCredentialProxy",
    "ProgressReporter",
    "ProgressReporterBase",
    "MockProgressReporter",
    "ConsoleProgressReporter",
    "ProgressEntry",
    "LogLevel",
    # Exceptions
    "CredentialError",
    "CredentialNotAllowedError",
    "CredentialNotConfiguredError",
]
