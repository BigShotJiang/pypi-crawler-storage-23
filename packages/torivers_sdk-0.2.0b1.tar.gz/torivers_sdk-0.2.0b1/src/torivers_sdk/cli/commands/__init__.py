"""
CLI commands module.

This module contains individual command implementations for the
ToRivers SDK CLI. Each command is defined in its own file for
better organization and maintainability.
"""

from torivers_sdk.cli.commands.auth import login, logout, whoami
from torivers_sdk.cli.commands.init import init_project, list_templates
from torivers_sdk.cli.commands.run import run_automation
from torivers_sdk.cli.commands.status import check_status, list_statuses
from torivers_sdk.cli.commands.submit import submit_automation
from torivers_sdk.cli.commands.test import run_tests
from torivers_sdk.cli.commands.validate import validate_automation

__all__ = [
    # Init command
    "init_project",
    "list_templates",
    # Run command
    "run_automation",
    # Test command
    "run_tests",
    # Validate command
    "validate_automation",
    # Submit command
    "submit_automation",
    # Auth commands
    "login",
    "logout",
    "whoami",
    # Status command
    "check_status",
    "list_statuses",
]
