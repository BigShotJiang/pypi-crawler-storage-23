"""
CLI module - Command-line interface for the ToRivers SDK.

This module provides the `torivers` CLI command that developers use
to create, test, validate, and submit automations.
"""

from torivers_sdk.cli.main import cli

__all__ = ["cli"]
