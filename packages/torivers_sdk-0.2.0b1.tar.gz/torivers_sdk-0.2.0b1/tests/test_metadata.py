"""
Tests for AutomationMetadata pricing and schema behavior.
"""

import tempfile

import pytest

from torivers_sdk.automation.metadata import (
    AutomationKind,
    AutomationMetadata,
    AutomationType,
    ExecutionLimits,
    ScheduleConfig,
    WebhookConfig,
)


class TestAutomationMetadata:
    def test_create_minimal_metadata(self) -> None:
        metadata = AutomationMetadata(
            name="test-automation",
            title="Test Automation",
            version="1.0.0",
            description="A test automation for unit tests",
            base_price=1.25,
        )

        assert metadata.name == "test-automation"
        assert metadata.automation_type == AutomationType.STANDARD
        assert metadata.kind == AutomationKind.WORKFLOW
        assert metadata.base_price == 1.25

    def test_requires_base_price(self) -> None:
        with pytest.raises(ValueError):
            AutomationMetadata(
                name="test-automation",
                title="Test Automation",
                version="1.0.0",
                description="A test automation for unit tests",
            )

    def test_rejects_legacy_cost_model_field(self) -> None:
        with pytest.raises(ValueError, match="cost_model"):
            AutomationMetadata.from_dict(
                {
                    "name": "test-automation",
                    "title": "Test Automation",
                    "version": "1.0.0",
                    "description": "A test automation for unit tests",
                    "base_price": 1,
                    "cost_model": {"base_credits": 2},
                }
            )

    def test_scheduled_requires_config(self) -> None:
        with pytest.raises(ValueError, match="schedule_config is required"):
            AutomationMetadata(
                name="test-auto",
                title="Test",
                version="1.0.0",
                description="Test description here",
                base_price=1,
                automation_type=AutomationType.SCHEDULED,
            )

    def test_scheduled_with_config(self) -> None:
        metadata = AutomationMetadata(
            name="test-auto",
            title="Test",
            version="1.0.0",
            description="Test description here",
            base_price=1,
            automation_type=AutomationType.SCHEDULED,
            schedule_config={"cron": "0 9 * * *"},
        )
        assert metadata.automation_type == AutomationType.SCHEDULED
        assert isinstance(metadata.schedule_config, ScheduleConfig)

    def test_webhook_default_config(self) -> None:
        metadata = AutomationMetadata(
            name="test-auto",
            title="Test",
            version="1.0.0",
            description="Test description here",
            base_price=1,
            automation_type=AutomationType.WEBHOOK,
        )
        assert isinstance(metadata.webhook_config, WebhookConfig)

    def test_full_metadata(self) -> None:
        metadata = AutomationMetadata(
            name="email-processor",
            title="Email Processor",
            version="2.1.0",
            description="Processes emails with AI analysis",
            base_price=2.5,
            category="productivity",
            tags=["email", "ai"],
            required_credentials=["gmail"],
            optional_credentials=["slack"],
            limits=ExecutionLimits(max_duration_seconds=600, max_memory_mb=1024),
        )
        assert metadata.base_price == 2.5
        assert metadata.limits.max_duration_seconds == 600


class TestMetadataYaml:
    def test_from_yaml_basic(self) -> None:
        yaml_content = """
name: test-automation
title: Test Automation
version: 1.0.0
description: A test automation for unit tests
base_price: 1.5
category: productivity
tags:
  - test
  - automation
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(yaml_content)
            f.flush()

            metadata = AutomationMetadata.from_yaml(f.name)
            assert metadata.base_price == 1.5
            assert metadata.category == "productivity"

    def test_to_yaml_roundtrip(self) -> None:
        original = AutomationMetadata(
            name="test-auto",
            title="Test Automation",
            version="1.0.0",
            description="Test description here",
            base_price=2,
            category="productivity",
            tags=["test"],
        )

        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            original.to_yaml(f.name)
            loaded = AutomationMetadata.from_yaml(f.name)
            assert loaded.base_price == original.base_price
            assert loaded.name == original.name
