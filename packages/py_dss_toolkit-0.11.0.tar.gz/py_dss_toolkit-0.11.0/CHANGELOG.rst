Changelog
=========

0.11.0 (2026-02-27)
-------------------
* Added Losses results: ``losses_elements`` returns total active and reactive losses per PD element (kW, kvar).
* Added AllLosses results: ``all_losses_elements`` returns total, load, and no-load losses per PD element using ``cktelement.all_losses``.
* Added unit tests for losses_elements and all_losses_elements.

0.10.0 (2026-02-26)
-------------------
* Relaxed dependency constraints to improve compatibility in Google Colab environments.

0.9.0 (2026-02-26)
------------------
* Performance improvements across model, results, and view modules

0.8.0 (2026-02-24)
------------------
* Fixed bug in monitor plotting.
* Added more unit tests and test reorganization (model, results, studies, view)
* Allow user to access dss via dss_tools.dss.
* Interactive view / plot style updates

0.7.0 (2026-02-23)
------------------
Updating to work with py-dss-interface 2.3.0

0.6.0 (2025-10-16)
------------------
* segments_df includes nodes and enabled.

* monitor can plot voltage in pu when connected to element's terminal 2

0.5.0 (2025-09-24)
------------------
* Returns fig and ax objects in the static_view plots.

* Raise an error when there is no Monitor for the results.monitor

0.4.0 (2025-08-20)
------------------
* Added Voltage LL Nodes results. Code provided by Wes

0.0.0 (2021-05-18)
------------------

* First release on PyPI.
