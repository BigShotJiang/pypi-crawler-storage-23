============
Installation
============

At the command line::

    pip install py-dss-toolkit
