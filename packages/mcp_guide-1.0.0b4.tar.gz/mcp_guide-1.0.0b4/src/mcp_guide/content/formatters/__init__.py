"""Content formatters for different output types."""
