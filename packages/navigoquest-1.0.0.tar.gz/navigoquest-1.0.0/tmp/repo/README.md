# shqod

A Python package with mobility inspired tools to analyse the SHQ dataset. 'od' as in Origin-Destination (OD) matrix.

### Installation

`pip install shqod`
