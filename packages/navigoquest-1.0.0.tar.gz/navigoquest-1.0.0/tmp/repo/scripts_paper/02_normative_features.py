import os
from pathlib import Path
import itertools
from multiprocessing import Pool

from tqdm import tqdm

from shqod import LevelsLoader, ODLoader, PathsProcessor, write_feather, norm


data_dir = Path(os.environ["dementia"]) / "data"
grid_dir = data_dir / "maps"

normative_dir = data_dir / "normative"
od_mat_file = normative_dir / "window_odmats.pkl"
paths_dir = normative_dir / "paths"
output_dir = normative_dir / "features"

paths_loader = LevelsLoader(paths_dir)
od_loader = ODLoader.from_file(od_mat_file)

# "window_size": 5,
# "weight_scale": 2.0,  # np.inf
# NB: these params are used to create the file window_odmats.pkl

inner_bdy_radii = {
    1: {"rin": 1, "rout": 2},
    2: {"rin": 1, "rout": 2},
    6: {"rin": 1.5, "rout": 4},
    8: {"rin": 1.5, "rout": 4},
    11: {"rin": 1, "rout": 2},
}

feats = ["dur", "len", "curv", "bdy", "fro", "sup", "match", "mob", "vo"]


def process_level_gender(key):
    lvl, g = key
    df = paths_loader.get(lvl, g, age="24:80").set_index("id")

    lvl_hp = inner_bdy_radii[lvl]

    proc = PathsProcessor(lvl, g, grid_dir, od_loader, **lvl_hp)
    feat_df = proc.get_features(df, feats).reset_index()

    # Write file
    load_name = Path(paths_loader._files[key])
    save_name = (output_dir / load_name.name).with_suffix(".feather")
    write_feather(feat_df, save_name, verbose=True)

    # This should free up memory, though in paralell it might not help much
    paths_loader.loaded.pop(key, None)


if __name__ == "__main__":

    # Configs

    levels = [1, 2, 6, 8, 11]
    genders = ["f", "m"]
    nb_iters = len(levels) * len(genders)

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Run
    with Pool() as p:
        iterable = itertools.product(levels, genders)
        list(tqdm(p.imap(process_level_gender, iterable), total=nb_iters))
        # The outer list is required because the evaluation is lazy

    norm.write_norm_factor(output_dir)
