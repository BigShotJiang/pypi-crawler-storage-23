import os
from pathlib import Path
import itertools
import functools
import multiprocessing

from tqdm import tqdm

from shqod import LevelsLoader, ODLoader, utils


data_dir = Path(os.environ["dementia"]) / "data"
normative_paths_dir = data_dir / "normative" / "paths"
grid_dir = data_dir / "maps"


def precompute_level_gender(od_loader, key, age_range):  # key = level, gender
    out = {}

    low, high = utils.parse_age(age_range)

    for age in range(low, high + 1):
        out[(*key, age)] = od_loader.get_od_matrix_windowed(*key, age)

    return out


def precompute_all(od_loader, levels, genders, age_range):
    part = functools.partial(precompute_level_gender, od_loader, age_range=age_range)
    iterable = itertools.product(levels, genders)
    nb_iters = len(levels) * len(genders)

    with multiprocessing.Pool() as p:
        results = list(tqdm(p.imap(part, iterable), total=nb_iters))

    out = {}
    for d in results:
        out.update(d)  # My implementation of reduce

    return out


if __name__ == "__main__":

    levels = [1, 2, 6, 8, 11]
    genders = ["f", "m"]
    age_range = "24:80"

    paths_loader = LevelsLoader(normative_paths_dir, fmt="feather")
    od_loader = ODLoader(paths_loader=paths_loader, grid_dir=grid_dir)

    results = precompute_all(od_loader, [6], ["f"], "50:51")
    # results need to be used bcs multiprocessing doesnt share the internal dictionary
    od_loader.windowed_data_ = results

    if True:
        filename = normative_paths_dir.parent / "window_odmats.pkl"
        od_loader.to_pickle(filename)
        print("Saved results to: ", filename)

    print("\nDone!\n")
