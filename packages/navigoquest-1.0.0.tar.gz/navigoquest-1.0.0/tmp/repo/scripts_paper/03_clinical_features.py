import os
from pathlib import Path
import itertools
from multiprocessing import Pool

import pandas as pd
from tqdm import tqdm

from shqod import (
    read_path_feather,
    write_feather,
    ODLoader,
    PathsProcessor,
    fill_missing_attempts,
    norm,
)


data_dir = Path(os.environ["dementia"]) / "data"
grid_dir = data_dir / "maps"

normative_dir = data_dir / "normative"
od_mat_file = normative_dir / "window_odmats.pkl"
od_loader = ODLoader.from_file(od_mat_file)

clinical_paths = data_dir / "clinical" / "paths.feather"
clinical_paths_df = read_path_feather(clinical_paths, path_col="trajectory_data")


# "window_size": 5,
# "weight_scale": 2.0,  # np.inf
# NB: these params are used to create the file window_odmats.pkl

inner_bdy_radii = {
    1: {"rin": 1, "rout": 2},
    2: {"rin": 1, "rout": 2},
    6: {"rin": 1.5, "rout": 4},
    8: {"rin": 1.5, "rout": 4},
    11: {"rin": 1, "rout": 2},
}

feats = ["dur", "len", "curv", "bdy", "fro", "sup", "match", "mob", "vo"]


gby = clinical_paths_df.groupby(["level", "gender"])


def process_level_gender(key):
    lvl, g = key
    df = gby.get_group(key).set_index(["id", "group"])

    lvl_hp = inner_bdy_radii[lvl]

    proc = PathsProcessor(lvl, g, grid_dir, od_loader, **lvl_hp)
    feat_df = proc.get_features(df, feats).reset_index()

    return feat_df


if __name__ == "__main__":

    levels = [1, 2, 6, 8, 11]
    genders = ["f", "m"]
    nb_iters = len(levels) * len(genders)

    with Pool() as p:
        iterable = itertools.product(levels, genders)
        features_df = pd.concat(
            tqdm(p.imap(process_level_gender, iterable), total=nb_iters)
        )

    # Post-process the missing AD patients and fill with NA
    idx_cols = ["id", "group", "level"]
    features_df = fill_missing_attempts(
        features_df,
        feats,
        missing_group="ad",
        ref_lvl=6,  # we make sure to use the first level that we care about for features
    )

    # Write file
    filename = clinical_paths.parent / f"features.feather"
    write_feather(features_df, filename, verbose=True)

    # Normed file
    norm_df = norm.normalise_dataframe(features_df)
    filename = clinical_paths.parent / f"normed_features.feather"
    write_feather(norm_df, filename, verbose=True)
