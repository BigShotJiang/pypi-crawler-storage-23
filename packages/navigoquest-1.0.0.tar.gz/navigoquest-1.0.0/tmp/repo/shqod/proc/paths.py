"""Calculate features from paths."""

import warnings
from pathlib import Path
from typing import Dict, Tuple, Union, Optional

import numpy as np
import scipy.sparse as sp
import pandas as pd

# from esig import tosig

from shqod.io import ODLoader, read_level_grid, read_level_flags
from shqod.matrices import mobility_field
from shqod.paths import (
    path_length,
    avg_curvature,
    bdy_affinity,
    frobenius_deviation,
    supremum_deviation,
    sum_match,
    mobility_functional,
    visiting_order,
    smooth,
)
from shqod.utils import _get_iterable


class AbsoluteFeatures:
    def __init__(
        self,
        level: int,
        gender: str,
        grid_dir: Optional[Union[str, Path]] = None,
        bdy_scale: float = 4.0,
        rin: Optional[float] = None,  # I have not good default values to provide
        rout: Optional[float] = None,
        R: float = 3,
    ):

        self.level = level
        self.country = "uk"  # currently not used
        self.gender = gender

        # arguments for boundary affinity
        self.bdy_scale = bdy_scale
        self.rin = rin
        self.rout = rout

        # arguments for visiting order
        self.R = R
        self.flag_coords = None

        if grid_dir:
            grid_dir = Path(grid_dir)
            file = grid_dir / f"level{level:02}.json"
            coords, wd, lg = read_level_grid(file)
            self.grid_coords = coords
            self.grid_size = (wd, lg)
            self.grid_width = wd
            self.grid_length = lg

            self.flag_coords = read_level_flags(file)[::-1]
            # NB: for levels 6, 8 and 11 I've tested the flags are in the reversed
            # order, but I don't know if this will always hold

            inner_bdy_file = grid_dir / f"inner_bdy_level{level:02}.npy"
            if inner_bdy_file.is_file():
                self.inner_bdy = smooth(np.load(inner_bdy_file))
            else:
                warnings.warn(
                    "inner boundary file not found: some features will not work"
                )
        else:
            warnings.warn("'grid_dir' not provided: some features will not work")

        if rin is None or rout is None:
            warnings.warn("'rin/rout' not provided: some features will not work")

    def __str__(self):
        return f"Processor: {self.country} - {self.gender} - {self.level}"

    def _get_len(self, path):
        return path_length(path)

    def _get_curv(self, path):
        return avg_curvature(path)

    def _get_bdy(self, path):
        rin = self.rin
        rout = self.rout
        inner_bdy = getattr(self, "inner_bdy", None)

        if rin is None or rout is None or inner_bdy is None:
            raise ValueError("missing hyperparameters")

        return bdy_affinity(path, inner_bdy, rin=rin, rout=rout, scale=self.bdy_scale)

    def _get_vo(self, path):
        if (flag_coords := self.flag_coords) is None:
            raise ValueError("hyperparameter needed: 'flag_coords'")

        return visiting_order(path, flag_coords, R=self.R, safe_mode=False)

    # def get_sig(self, path):
    #     max_sigdim = getattr(self, "max_sigdim", None)

    #     if max_sigdim is None:
    #         raise ValueError("hyperparameter needed: 'max_sigdim'")

    #     return tosig.stream2logsig(path, self.max_sigdim)

    def _smooth_features(self, path, methods):
        s_path = smooth(path)
        return [method(s_path) for method in methods]

    def get_features(self, df, feat_types):
        """NB: call set_index on df."""

        feat_types = _get_iterable(feat_types)

        for col in feat_types:
            if col not in ("len", "curv", "bdy", "vo"):  # "sig"
                raise NotImplementedError(col)

        dtype = "object" if "vo" in feat_types else "float"
        arr = np.zeros((len(df), len(feat_types)), dtype=dtype)

        w_smoothing = {"curv", "bdy"}

        sm = list(w_smoothing.intersection(feat_types))
        smooth_methods = [getattr(self, f"_get_{feat}") for feat in sm]

        co = list(set(feat_types).difference(w_smoothing))
        coarse_methods = [getattr(self, f"_get_{feat}") for feat in co]

        for i, row in enumerate(df.itertuples(index=False)):
            path = row.trajectory_data
            sm_res = self._smooth_features(path, smooth_methods)
            co_res = [method(path) for method in coarse_methods]
            arr[i] = sm_res + co_res

        if len(feat_types) == 1:
            # The reordering below cannot be done with Iterable feat_types
            feat_types = feat_types[0]

        arr_df = pd.DataFrame(arr, columns=sm + co, index=df.index)[feat_types]
        out = (
            df.drop(columns="trajectory_data")
            .join(arr_df)
            .rename(columns={"duration": "dur"})
        )

        return out


class RelativeFeatures:
    _normative_mat: sp.csr_matrix
    _normative_field: Dict[Tuple[int, int], np.ndarray]

    def __init__(
        self,
        level: int,
        gender: str,
        grid_dir: Union[str, Path],
        od_loader: ODLoader,
        # The two below now below inside od_loader
        # window_size: int = 5,
        # weight_scale: float = 2.0,
    ):

        self.level = level
        self.country = "uk"  # currently not used
        self.gender = gender

        self.loader = od_loader

        file = Path(grid_dir) / f"level{level:02}.json"
        coords, wd, lg = read_level_grid(file)
        self.grid_coords = coords
        self.grid_size = (wd, lg)
        self.grid_width = wd
        self.grid_length = lg

        self.flag_coords = read_level_flags(file)[::-1]
        # NB: for levels 6, 8 and 11 I've tested the flags are in the reversed
        # order, but I don't know if this will always hold

    def __str__(self):
        return f"Normative processor: {self.country} - {self.gender} - {self.level}"

    @property
    def normative_mat(self) -> sp.csr_matrix:
        return self._normative_mat

    @property
    def normative_field(self) -> Dict[Tuple[int, int], np.ndarray]:
        return self._normative_field

    @normative_mat.setter
    def normative_mat(self, mat):
        # Safety checks are disabled
        # assert sp.isspmatrix_csr(mat), "error: invalid format for matrix"
        # size = np.multiply(*self.grid_size)
        # assert mat.shape == (size, size), "error: invalid dimensions for matrix"
        self._normative_mat = mat
        self._normative_field = mobility_field(mat, self.grid_width)

    def _get_fro(self, path):
        return frobenius_deviation(path, self.grid_size, self.normative_mat)

    def _get_sup(self, path):
        return supremum_deviation(path, self.grid_size, self.normative_mat)

    def _get_match(self, path):
        return sum_match(path, self.grid_size, self.normative_mat)

    def _get_mob(self, path):
        return mobility_functional(path, self.normative_field)

    def _get_age_features(self, age_df, feat_types):
        """NB: This call only makes sense if the correct normative_mat has been set."""

        # Safety check disabled
        # if not hasattr(self, "normative_mat"):
        #     raise ValueError("normative OD matrix has not been set")
        #     TODO: not sure this check works because of the @setter

        feat_types = _get_iterable(feat_types)

        for col in feat_types:
            if col not in ("fro", "sup", "match", "mob"):
                raise NotImplementedError(col)

        methods = [getattr(self, f"_get_{feat}") for feat in feat_types]
        arr = np.zeros((len(age_df), len(methods)), dtype=float)

        for i, row in enumerate(age_df.itertuples(index=False)):
            path = row.trajectory_data
            arr[i] = [method(path) for method in methods]

        arr_age_df = pd.DataFrame(arr, columns=feat_types, index=age_df.index)
        drop_cols = ["duration", "dur", "trajectory_data"]

        return age_df.drop(columns=drop_cols, errors="ignore").join(arr_age_df)

    def get_features(self, df, feat_types):
        """NB: call set_index on df."""

        gby = df.groupby("age")
        out = []

        for age, age_df in gby:
            wmat = self.loader.get_od_matrix_windowed(self.level, self.gender, age)
            self.normative_mat = wmat  # this also sets normative_field
            out.append(self._get_age_features(age_df, feat_types))

        return pd.concat(out).reindex(df.index)


class PathsProcessor:
    abs: AbsoluteFeatures
    rel: RelativeFeatures

    def __init__(
        self,
        level: int,
        gender: str,
        grid_dir: Union[str, Path],
        od_loader: ODLoader,
        bdy_scale: float = 4.0,
        rin: Optional[float] = None,  # I have not good default values to provide
        rout: Optional[float] = None,
        R: float = 3,
    ):
        self.abs = AbsoluteFeatures(
            level,
            gender,
            grid_dir=grid_dir,
            bdy_scale=bdy_scale,
            rin=rin,
            rout=rout,
            R=R,
        )

        self.rel = RelativeFeatures(level, gender, grid_dir, od_loader)

    def get_features(self, df, feat_types):
        """NB: call set_index on df."""

        feat_types = _get_iterable(feat_types)
        if (n_feats := len(feat_types)) < 1:
            raise ValueError

        valid = ("dur", "len", "curv", "bdy", "vo", "fro", "sup", "match", "mob")
        for col in feat_types:
            if col not in valid:
                raise NotImplementedError(col)

        absolute = list(set(feat_types).intersection(("len", "curv", "bdy", "vo")))
        relative = list(set(feat_types).intersection(("fro", "sup", "match", "mob")))

        if len(absolute) > 0:
            abs_df = self.abs.get_features(df, absolute)

            if len(relative) > 0:
                rel_df = self.rel.get_features(df, relative)
                out = abs_df.join(rel_df[relative])
            else:
                out = abs_df

        else:  # it must mean that the remaining features are relative
            rel_df = self.rel.get_features(df, relative)
            out = rel_df

        if n_feats == 1:
            # The reordering below cannot be done with Iterable feat_types
            feat_types = feat_types[0]

        return out
