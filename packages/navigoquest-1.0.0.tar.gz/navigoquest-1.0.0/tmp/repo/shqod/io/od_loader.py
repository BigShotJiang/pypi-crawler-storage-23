from pathlib import Path
import pickle
from typing import Tuple, Dict, Union, Optional

import numpy as np
import scipy.sparse as sp
import scipy.stats as st

from shqod.io.loader import LevelsLoader
from shqod.io.grid import read_level_size
from shqod.matrices import od_matrix


class ODLoader:
    data_: Dict[Tuple[int, str, int], sp.csr_matrix]
    windowed_data_: Dict[Tuple[int, str, int], sp.csr_matrix]

    def __init__(
        self,
        windowed_data: Optional[Dict] = None,
        paths_loader: Optional[LevelsLoader] = None,
        grid_dir: Optional[Union[str, Path]] = None,
        window_size: int = 5,
        weight_scale: float = 2.0,
    ):
        self.data_ = {}
        self.windowed_data_ = {}

        if windowed_data is not None and isinstance(windowed_data, dict):
            self.windowed_data_ = windowed_data

        else:
            if paths_loader is None:
                raise ValueError("paths_loader is needed")
            elif grid_dir is None:
                raise ValueError("grid_dir is needed")

        self.grid_dir = Path(grid_dir) if grid_dir else None
        self.loader = paths_loader
        self.window_size = window_size
        self.weight_scale = weight_scale

    @classmethod
    def from_file(cls, filename, **kwargs):
        filename = Path(filename)

        if not filename.is_file():
            raise FileNotFoundError
        elif filename.suffix not in (".pkl", ".pickle"):
            raise ValueError("invalid format")

        with open(filename, "rb") as f:
            windowed_data = pickle.load(f)

        return cls(windowed_data, **kwargs)

    def _grid_size(self, level):
        filename = self.grid_dir / f"level{level:02}.json"
        return read_level_size(filename)

    def _od_matrix(self, key: Tuple[int, str, int]):
        df = self.loader.get(*key)
        N = len(df)

        lvl = key[0]
        mat = od_matrix(df.trajectory_data, self._grid_size(lvl)) / N

        self.data_[key] = mat

        return mat

    def get_od_matrix(self, level: int, gender: str, age: int):
        key = (level, gender, age)
        if key not in self.data_:
            self.data_[key] = self._od_matrix(key)

        return self.data_[key]

    def _od_matrix_windowed(self, level: int, gender: str, age_centre: int):
        window = self.window_size
        scale = self.weight_scale

        ages = range(age_centre - window, age_centre + window + 1)

        if scale == np.inf:
            weights = np.ones(len(ages))
        else:
            weights = st.distributions.norm(age_centre, scale=scale).pdf(ages)
            weights /= weights.sum()

        size = np.multiply(*self._grid_size(level))
        out = sp.csr_matrix((size, size))

        for i, age in enumerate(ages):
            normed_mat = self.get_od_matrix(level, gender, age)  # already divided by N
            out += weights[i] * normed_mat

        return out

    def get_od_matrix_windowed(self, level: int, gender: str, age_centre: int):
        key = (level, gender, age_centre)
        if key not in self.windowed_data_:
            self.windowed_data_[key] = self._od_matrix_windowed(*key)

        return self.windowed_data_[key]

    def to_pickle(self, filename: Union[str, Path]):
        filename = Path(filename)

        if filename.is_file():
            raise ValueError("file already exists")
        elif filename.suffix not in (".pkl", ".pickle"):
            raise ValueError("invalid name; should be pickle")

        with open(filename, "wb") as f:
            pickle.dump(self.windowed_data_, f)
