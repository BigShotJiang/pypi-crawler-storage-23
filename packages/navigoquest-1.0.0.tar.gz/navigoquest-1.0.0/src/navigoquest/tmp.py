import pathlib

from navigoquest.environments import BoundaryEnvironment, CohortEnvironment, UserODMatrix
from navigoquest.metrics import (
    AverageCurvatureMetric,
    BoundaryAffinityMetric,
    ConformityMetric,
    FrobeniusDeviationMetric,
    PathLengthMetric,
    SupremumDeviationMetric,
    VectorConformityMetric,
    VisitingOrderMetric,
)
from navigoquest.paths import PathDataset


data_dir = pathlib.Path("tests/data")

metadata_cols = ["age", "gender"]

dataset = PathDataset.from_level_csv(
    paths_filename=data_dir / "level_6_gb_sample.csv",
    metadata_filename=data_dir / "users_gb_1998.csv",
    # metadata_keep_cols=metadata_cols,
)

paths = list(dataset.filter_by_attributes(age=30, gender="f"))
# print(len(paths))

# for key, paths in dataset.group_by("age", "gender")

# lvl = LevelGrid(data_dir / "level06.json")

env = CohortEnvironment(level=6)  # data_dir / "level06.json"
env.set_od_matrices(dataset, "age", "gender")
# env.transform_od_matrices_to_windowed(half_window=5, scale=2.0)
env.set_mobility_fields()

# env.to_pickle("cohort_env.pkl")


p = paths[0]

# vo = env.visiting_order(p)

mat = UserODMatrix.from_path(p, env)

bdry_env = BoundaryEnvironment(level=6, rin=1.5, rout=5.0, scale=4)

# m = BoundaryAffinityMetric(p, bdry_env)
use_smooth = False

metrics = {
    # "voc": VisitingOrderMetric(p, env),
    # "path_length": PathLengthMetric(p),
    "average_curvature": AverageCurvatureMetric(p, use_smooth=use_smooth),
    "boundary_affinity": BoundaryAffinityMetric(p, bdry_env, use_smooth=use_smooth),
    # "frobenius_deviation": FrobeniusDeviationMetric(mat, env),
    # "supremum_deviation": SupremumDeviationMetric(mat, env),
    # "conformity": ConformityMetric(mat, env),
    # "vector_conformity": VectorConformityMetric(p, env),
}

print(metrics)
print("Done")
