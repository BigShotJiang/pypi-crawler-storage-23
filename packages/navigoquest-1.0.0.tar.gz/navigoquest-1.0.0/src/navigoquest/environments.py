from __future__ import annotations

import itertools
import json
import pathlib
import pickle
from abc import ABC
from dataclasses import dataclass
from typing import Any, Iterable, Protocol

import numpy as np
import scipy.sparse as sp
import scipy.stats as st
from numpy.typing import NDArray
from scipy.spatial import distance_matrix
from sklearn.neighbors import KDTree

from .config import (
    BOUNDARY_RADII,
    DEFAULT_FLAG_RADIUS,
    EXPECTED_VISITING_ORDERS,
    LEVELS_REVERSE_FLAGS,
    ODMATS_AGE_RANGE,
    ODMATS_AGE_WINDOW_HALF_SIZE,
    ODMATS_WEIGHT_STD,
)
from .paths import Path, PathDataset, smooth_path
from .utils import glob_level_environments


GroupKeyT = tuple[Any, ...]


# class Environment(ABC):
#     pass

# --- Contracts ----------------------------------------------------------------


class GridLike(Protocol):
    level: int
    grid: NDArray[np.int32]
    grid_width: int
    grid_length: int
    flags: NDArray[np.int32]
    flag_radius: int  # not used

    def visiting_order(self, path: Path) -> list[int]: ...

    def visiting_order_correctness(self, path: Path) -> bool: ...


class SupportsODMatrix(Protocol):
    def od_matrix(self, paths: Iterable[Path], remove_diag: bool = False) -> sp.csr_matrix: ...


class SupportsBoundaryDistance(Protocol):
    innery_bdry_kdtree: KDTree
    rin: float
    rout: float
    scale: float

    def distances_to_boundary(self, path: Path, use_smooth: bool = True) -> float: ...


# --- Independent functionality that depends on the grid ------------------------


class LevelGridBase(ABC):
    level: int
    grid: NDArray[np.int32]
    grid_width: int
    grid_length: int
    flags: NDArray[np.int32]
    flag_radius: int = DEFAULT_FLAG_RADIUS

    def __init__(self, level: int) -> None:
        """
        Load the grid and flags.

        Parameters
        ----------
        level : int
            Path to the level JSON file. The code expects the level to be in the filename.
        """
        p = pathlib.Path(__file__).parent / f"data/levels/level{level:02}.json"

        # Checks
        if not p.exists():
            raise FileNotFoundError(f"{p} does not exist")

        self.level = level

        # Initialize
        with p.open("r") as f:
            data = json.load(f)["fixed"]

        self.grid_width = int(data["grid_width"])
        self.grid_length = int(data["grid_length"])
        self.grid = np.array(data["grid_data"]).reshape(
            (self.grid_width, self.grid_length), order="F"
        )
        flags = np.array([(d["x"], d["y"]) for d in data["flags"]], dtype=np.int32)
        if self.level in LEVELS_REVERSE_FLAGS:
            flags = flags[::-1]
        self.flags = flags

    def visiting_order(self, path: Path) -> list[int]:
        """Check if the path visits the flags in the correct order."""
        if self.level not in EXPECTED_VISITING_ORDERS:
            raise NotImplementedError(f"Expected order not defined for level {self.level}")

        dmat = distance_matrix(path.smooth_xy, self.flags)
        _, j = (dmat < self.flag_radius).nonzero()

        return [x[0] for x in itertools.groupby(j)]

    def visiting_order_correctness(self, path: Path) -> bool:
        vo = self.visiting_order(path)
        expected = EXPECTED_VISITING_ORDERS[self.level]

        # we allow the expected visiting order to be a nested list to allow for multiple orders
        if isinstance(expected[0], list):
            return vo in expected

        return vo == expected


class ODMatrixMixin:
    def od_matrix(
        self: GridLike, paths: Iterable["Path"], remove_diag: bool = False
    ) -> sp.csr_matrix:
        """
        Compute the origin-destination matrix from a set of paths.

        Parameters
        ----------
        paths : Iterable[Path]
            Paths to aggregate.
        remove_diag : bool
            If True, zero the diagonal.

        Returns
        -------
        sp.csr_matrix
            OD matrix.
        """
        width, height = self.grid_width, self.grid_length
        N = width * height
        out = sp.lil_matrix((N, N), dtype=int)

        for path in paths:
            lex = width * path.xy[:, 1] + path.xy[:, 0]
            for i, j in zip(lex[:-1], lex[1:]):
                out[i, j] += 1

        if remove_diag:
            out[np.diag_indices_from(out)] = 0

        return out.tocsr()


class MobilityFieldMixin:
    def mobility_field(
        self: GridLike, od_mat: sp.csr_matrix
    ) -> dict[tuple[int, int], NDArray[np.int32]]:
        """
        Compute the field at each location (origin) where it is non-zero.

        Parameters
        ----------
        od_mat : sp.csr_matrix
            The orgin-destination (OD) matrix to use as input.

        Returns
        -------
        dict[tuple[int, int], np.ndarray]
            Map (x, y) -> vector field.
        """
        if not sp.issparse(od_mat):
            raise ValueError("od_mat must be sparse")

        width = self.grid_width

        i, j = od_mat.nonzero()
        r_origin = np.vstack((i % width, i // width)).T
        r_dest = np.vstack((j % width, j // width)).T
        u_vec = (r_dest - r_origin).astype(float)

        # unit vectors
        norm = np.linalg.norm(u_vec, axis=1)
        idx = norm > 0
        u_vec[idx] = u_vec[idx] / norm[idx, np.newaxis]

        # unit vectors weighted by the number of trips
        weighted_vec = u_vec * np.asarray(od_mat[i, j]).T

        # sum the vectors grouped by origin using counts of unique elements
        _, idx_uniq, counts = np.unique(i, return_index=True, return_counts=True)
        c = np.cumsum(counts)

        nb_locations = len(idx_uniq)
        Xs = r_origin[idx_uniq]
        Fs = np.zeros((nb_locations, 2))

        start = 0
        for k, end in enumerate(c):
            Fs[k] += weighted_vec[start:end].sum(axis=0)
            start = end

        out: dict[tuple[int, int], NDArray[np.int32]] = {}
        for k in range(len(Xs)):
            out[tuple(Xs[k])] = Fs[k]

        return out


# --- Concrete types -----------------------------------------------------------


@dataclass
class UserODMatrix:
    """OD matrix for a single user/path with associated metadata."""

    norm_mat: sp.csr_matrix
    metadata: dict

    @classmethod
    def from_path(cls, path: Path, level_grid: SupportsODMatrix) -> UserODMatrix:
        mat = level_grid.od_matrix([path])
        return cls(mat, path.metadata)


@dataclass
class AggregateODMatrix:
    mat: sp.csr_matrix
    N: int

    @property
    def norm_mat(self) -> sp.csr_matrix:
        """Matrix normalized by the number of contributing paths."""
        return self.mat / self.N


class MinLevelEnvironment(ODMatrixMixin, LevelGridBase):
    pass


class CohortEnvironment(ODMatrixMixin, MobilityFieldMixin, LevelGridBase):
    _od_matrices: dict[GroupKeyT, AggregateODMatrix] | None = None
    _mobility_fields: dict[GroupKeyT, dict[tuple[int, int], NDArray[np.int32]]] | None = None

    def __init__(self, level: int):
        super().__init__(level=level)

    def to_pickle(self, filename: str | pathlib.Path) -> None:
        if self._od_matrices is None or self._mobility_fields is None:
            raise ValueError("call set_od_matrices() and/or set_mobility_fields()")

        if isinstance(filename, str):
            filename = pathlib.Path(filename)

        with open(filename, "wb") as f:
            pickle.dump(self, f)

    @classmethod
    def from_pickle(cls, filename: str | pathlib.Path) -> CohortEnvironment:
        if isinstance(filename, str):
            filename = pathlib.Path(filename)
        with open(filename, "rb") as f:
            return pickle.load(f)

    @property
    def od_matrices(self) -> dict[GroupKeyT, AggregateODMatrix]:
        if self._od_matrices is None:
            raise ValueError("od_matrices not  initialized; call set_od_matrices() first")
        return self._od_matrices

    @property
    def mobility_fields(self) -> dict[GroupKeyT, dict[tuple[int, int], NDArray[np.int32]]]:
        if self._mobility_fields is None:
            raise ValueError("mobility_fields not initialized; call set_mobility_fields() first")
        return self._mobility_fields

    def set_od_matrices(self, path_dataset: PathDataset, *attributes: str) -> None:
        if self._od_matrices is not None:
            raise ValueError("matrices already set")
        self._od_matrices = {}

        for key, (N, paths) in path_dataset.group_by(*attributes):
            mat = self.od_matrix(paths)
            self._od_matrices[key] = AggregateODMatrix(mat, N)

        return None

    def transform_od_matrices_to_windowed(
        self,
        half_window: int = ODMATS_AGE_WINDOW_HALF_SIZE,
        scale: float = ODMATS_WEIGHT_STD,
        ignore_spill: bool = False,
    ) -> None:
        if self._od_matrices is None:
            raise ValueError("call `set_od_matrices` first")

        new_matrices = {}

        if scale == np.inf:
            weights = np.ones(2 * half_window + 1)
        else:
            weights = st.distributions.norm(0, scale=scale).pdf(
                range(-half_window, half_window + 1)
            )

        weights /= weights.sum()

        for key, agg in self._od_matrices.items():
            age = key[0]  # TODO: only true if age is the first attribute, need to generalize
            if age < ODMATS_AGE_RANGE[0] or age > ODMATS_AGE_RANGE[1]:
                continue

            age_window = range(age - half_window, age + half_window + 1)
            mat = sp.csr_matrix(agg.mat.shape)

            for i, a in enumerate(age_window):
                # Check if key is in the OD matrix entries
                entry_check = (a, key[1]) in self._od_matrices.keys()
                # Ignore this iteration if entry isn't there, and ignore_spill == True.
                if ignore_spill and not entry_check:
                    continue
                # Otherwise continue as normal
                mat += weights[i] * self._od_matrices[(a, key[1])].norm_mat

            new_matrices[key] = AggregateODMatrix(mat, 1)

        self._od_matrices = new_matrices
        return None

    def set_mobility_fields(self) -> None:
        if self._od_matrices is None:
            raise ValueError("call `set_od_matrices` first")
        if self._mobility_fields is not None:
            raise ValueError("mobility fields already set")
        self._mobility_fields = {}

        for key, agg in self._od_matrices.items():
            self._mobility_fields[key] = self.mobility_field(agg.norm_mat)

        return None


class BoundaryEnvironment:
    innery_bdry_kdtree: KDTree
    rin: float
    rout: float
    scale: float

    def __init__(
        self, level: int, rin: float | None = None, rout: float | None = None, scale: float = 4.0
    ) -> None:
        p = pathlib.Path(__file__).parent / f"data/levels/level{level:02}_inner_bdry.npy"
        if not p.exists():
            raise FileNotFoundError(f"{p} does not exist")

        inner_bdry = smooth_path(np.load(p))
        self.inner_bdry_kdtree = KDTree(inner_bdry)

        if rin is None:
            rin = BOUNDARY_RADII[level]["rin"]
        if rout is None:
            rout = BOUNDARY_RADII[level]["rout"]

        self.rin = rin
        self.rout = rout
        self.scale = scale

    def to_pickle(self, filename: str | pathlib.Path) -> None:
        if isinstance(filename, str):
            filename = pathlib.Path(filename)
        with open(filename, "wb") as f:
            pickle.dump(self, f)

    @classmethod
    def from_pickle(cls, filename: str | pathlib.Path) -> BoundaryEnvironment:
        if isinstance(filename, str):
            filename = pathlib.Path(filename)
        with open(filename, "rb") as f:
            return pickle.load(f)

    def distances_to_boundary(self, path: Path, use_smooth: bool = True) -> float:
        xy = path.smooth_xy if use_smooth else path.xy
        ds, _ = self.inner_bdry_kdtree.query(xy, k=1)  # second out arg is indices
        return ds.flatten()  # KDTree returns a column vector


class EnvironmentStore:
    levels: list[int]
    _cohort: dict[int, CohortEnvironment]
    _boundary: dict[int, BoundaryEnvironment]

    def __init__(
        self,
        cohort_dir: str | pathlib.Path,
        boundary_dir: str | pathlib.Path,
        levels: list[int],
    ):
        self.levels = sorted(levels)
        self._cohort: dict[int, CohortEnvironment] = {}
        self._boundary: dict[int, BoundaryEnvironment] = {}

        # Find all available levels
        available_cohort_levels = glob_level_environments(cohort_dir)
        available_boundary_levels = glob_level_environments(boundary_dir)

        # Check that all requested levels are available
        missing_cohort = set(self.levels) - available_cohort_levels.keys()
        missing_boundary = set(self.levels) - available_boundary_levels.keys()

        if missing_cohort:
            raise FileNotFoundError(
                f"Missing cohort environments for levels: {sorted(missing_cohort)}"
            )
        if missing_boundary:
            raise FileNotFoundError(
                f"Missing boundary environments for levels: {sorted(missing_boundary)}"
            )

        # Load only the requested levels
        for lvl in self.levels:
            self._cohort[lvl] = CohortEnvironment.from_pickle(available_cohort_levels[lvl])
            self._boundary[lvl] = BoundaryEnvironment.from_pickle(available_boundary_levels[lvl])

    def get(self, level: int) -> tuple[CohortEnvironment, BoundaryEnvironment]:
        return self._cohort[level], self._boundary[level]


# def breakup_by_flags(path: Path, flags: NDArray[np.int32], R: float = 3) -> list[int]:
#     """
#     Find the last index of the first passage by each flag.

#     Parameters
#     ----------
#     path : Path
#         The path to be split.
#     flags : np.ndarray
#         The coordinates of the flags (ordered).
#     R : float
#         The radius to consider a checkpoint visited.

#     Returns
#     -------
#     List[int]
#         The list with the indices that can be used to split `path`.

#     """
#     out = []
#     offset = 0

#     for f in flags:
#         idx = np.where(np.linalg.norm(path.xy[offset:] - f, 2, axis=1) <= R)[0] + offset
#         max_sets = [
#             max(map(itemgetter(1), g))
#             for _, g in groupby(enumerate(idx), lambda ix: ix[0] - ix[1])
#         ]
#         offset = min(max_sets)
#         out.append(offset)

#     return out

# def od_matrix_brokenup(
#     self, paths: list[Path], R: float = FLAG_RADIUS, remove_diag: bool = False
# ) -> float:
#     """
#     Calculate the OD matrices broken up by the visits to the checkpoints.

#     Parameters
#     ----------
#     paths : list[Path]
#         The paths to be used in counting the number of trips between locations.
#     R : float, optional
#         The radius to consider a checkpoint visited.
#     remove_diag : bool, optional
#         Delete the entries in the diagonal (default is False).

#     Returns
#     -------
#     List[sp.csr_matrix]
#         List of origin-destination (OD) matrices.

#     """
#     width, height = self.grid_width, self.grid_length
#     N = width * height
#     nb_flags = len(self.flags)

#     out = [sp.lil_matrix((N, N), dtype=int) for _ in range(nb_flags)]

#     for path in paths:
#         idx = self.breakup_by_flags(path.xy, self.flags, R=R)

#         for k, chunk in enumerate(np.split(path.xy, idx[:-1])):
#             lex = self.grid_width * chunk[:, 1] + chunk[:, 0]

#             for i, j in zip(lex[:-1], lex[1:]):
#                 out[k][i, j] += 1

#     for k in range(nb_flags):
#         out[k] = out[k].tocsr()

#         if remove_diag:
#             out[k][np.diag_indices_from(out[k])] = 0

#     return out
