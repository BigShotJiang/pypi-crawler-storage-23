from dementia.environments import Environment
from dementia.paths import Path


# class Subject:
#     uuid: str
#     paths: list[Path]
#     metadata: dict


class Experiment:
    # subjects: list[Subject]
    paths: list[Path]
    environment: Environment | None
    metadata: dict | None  # will store level inside

    def __init__(self, paths: list[Path], environment: Environment | None):
        pass
