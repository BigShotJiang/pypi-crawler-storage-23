import pathlib

from navigoquest import EnvironmentStore, PathDataset
from navigoquest.metrics import compute_standard_metrics_by_group


lvl = 6

cols = [
    "path_length",
    "average_curvature",
    "boundary_affinity",
    "frobenius_deviation",
    "supremum_deviation",
    "conformity",
    "vector_conformity",
]


data_dir = pathlib.Path.home() / "Documents/dev/dementia_analysis/data"
cohort_env_dir = data_dir / "env_cohort"
boundary_env_dir = data_dir / "env_boundary"

env_store = EnvironmentStore(cohort_env_dir, boundary_env_dir, [lvl])
cohort_env, _ = env_store.get(lvl)


paths_dir = pathlib.Path("tests/data")

dataset = PathDataset.from_level_csv(
    paths_filename=paths_dir / f"level{lvl:02}_gb_sample.csv",
    metadata_filename=paths_dir / "users_gb_1998.csv",
)

dataset.align_to_odmats_age_range()


if __name__ == "__main__":
    use_smooth = False

    metrics = compute_standard_metrics_by_group(dataset, cohort_env, use_smooth=use_smooth)
    print(metrics[cols].mean(axis=0))

    print("Done")


# use_smooth = True

# path_length            77.194840
# average_curvature       0.077198
# boundary_affinity       0.813482
# frobenius_deviation    12.987593
# supremum_deviation      9.387063
# conformity             -0.196488
# vector_conformity      -0.188898


# use_smooth = False

# path_length            77.194840
# average_curvature       0.278219
# boundary_affinity       0.259886
# frobenius_deviation    12.987593
# supremum_deviation      9.387063
# conformity             -0.196488
# vector_conformity      -0.188898
