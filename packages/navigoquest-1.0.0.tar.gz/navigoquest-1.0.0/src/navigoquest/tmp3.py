import pathlib
import pandas as pd

from navigoquest.environments import MinLevelEnvironment
from navigoquest.metrics import VisitingOrderMetric
from navigoquest.paths import PathDataset


data_dir = pathlib.Path("tests/data")

metadata_cols = ["age", "gender"]

dataset = PathDataset.from_level_csv(
    paths_filename=data_dir / "level08_gb_sample.csv",
    metadata_filename=data_dir / "users_gb_1998.csv",
    # metadata_keep_cols=metadata_cols,
)

# paths = list(dataset.filter_by_attributes(age=30, gender="f"))
paths = dataset.paths
# print(len(paths))


env = MinLevelEnvironment(level=8)

voc = pd.Series([VisitingOrderMetric(p, env) for p in paths])
print(voc.value_counts())

print("Done")
