"""Pure functions for inferring what files to upload from a command.
All functions are pure: same input = same output, no side effects.
"""
import shlex
from pathlib import Path


def infer_upload_files(command: str, cwd: Path) -> list[Path]:
    """Infer which files to upload based on command.
    Pure function: command + directory -> list of paths.
    Strategy:
    1. Extract file references from command tokens
    2. Add common build files (Makefile, pyproject.toml, etc.)
    3. Add source files matching common patterns
    Args:
        command: Command to execute
        cwd: Current working directory
    Returns:
        Sorted list of file paths to upload
    Example:
        >>> infer_upload_files("nvcc kernel.cu -o kernel", Path("/home/user/cuda"))
        [Path("/home/user/cuda/kernel.cu"), Path("/home/user/cuda/Makefile"), ...]
    """
    assert cwd.exists(), f"cwd does not exist: {cwd}"
    assert isinstance(command, str), "command must be a string"
    assert isinstance(cwd, Path), "cwd must be a Path"
    files = set()

    try:
        tokens = shlex.split(command)
    except ValueError:
        tokens = command.split()  # shlex fails on unmatched quotes — fall back to space split
    file_extensions = {
        ".cu",
        ".cuh",
        ".py",
        ".cpp",
        ".c",
        ".h",
        ".hpp",
        ".rs",
        ".go",
    }
    for token in tokens:
        token_path = Path(token)
        if token_path.suffix in file_extensions:
            full_path = cwd / token_path
            if full_path.exists() and full_path.is_file():
                files.add(full_path)

    common_files = [
        "Makefile",
        "CMakeLists.txt",
        "pyproject.toml",
        "setup.py",
        "Cargo.toml",
        "go.mod",
        "requirements.txt",
    ]
    for filename in common_files:
        path = cwd / filename
        if path.exists() and path.is_file():
            files.add(path)

    source_extensions = [".cu", ".cuh", ".h", ".hpp", ".c", ".cpp"]
    for ext in source_extensions:
        for path in cwd.glob(f"*{ext}"):
            if path.is_file():
                files.add(path)
    result = sorted(files)
    return result
