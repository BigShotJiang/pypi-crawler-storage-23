"""Target locking for concurrent access control.

Two mechanisms:
1. Cloud GPU lock: Supabase-backed per-GPU queue with TTL + heartbeat.
   Works across CLI, cloud agents, and multiple machines.
2. File lock: fcntl.flock-based local locks for eval harness pools.
   Only works on a single machine.

Usage (cloud lock — preferred for user targets):
    with cloud_gpu_lock("target-uuid", [0, 1, 2]) as result:
        if result:
            gpu_ids = result["gpu_ids"]
            # Got the lock, run on gpu_ids
            ...
        else:
            # All GPUs busy and queues full
            ...

Usage (file lock — eval harness pool):
    with try_acquire_target("mi300x-1") as acquired:
        if acquired:
            ...
        else:
            ...

    with acquire_from_pool(["mi300x-1", "mi300x-2", "mi300x-3"]) as target:
        if target:
            ...
        else:
            ...
"""

from __future__ import annotations

import atexit
import fcntl
import json
import os
import sys
import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC
from pathlib import Path
from typing import Any


def _emit_gpu_event(event_type: str, **data: dict) -> None:
    """Emit GPU lock event to stderr.

    - TTY + not WAFER_GPU_EVENTS=json: human-friendly one-liner
    - Non-TTY or WAFER_GPU_EVENTS=json: JSON for machine parsing (eval events.jsonl)
    - WAFER_GPU_EVENTS=0: suppress entirely
    """
    if os.environ.get("WAFER_GPU_EVENTS") == "0":
        return

    event = {
        "type": event_type,
        "timestamp": __import__("datetime").datetime.now(UTC).isoformat(),
        "pid": os.getpid(),
        **data,
    }

    if sys.stderr.isatty() and os.environ.get("WAFER_GPU_EVENTS") != "json":
        target = data.get("target", "?")
        gpu_ids = data.get("gpu_ids", [])
        if event_type == "gpu_acquire":
            if gpu_ids:
                ids_str = ",".join(map(str, gpu_ids))
                print(f"[GPU] Acquired {target} (GPU {ids_str})", file=sys.stderr, flush=True)
            else:
                print(f"[GPU] Acquired {target}", file=sys.stderr, flush=True)
        elif event_type == "gpu_release":
            hold_ms = data.get("hold_duration_ms")
            suffix = f" ({hold_ms}ms)" if hold_ms is not None else ""
            print(f"[GPU] Released {target}{suffix}", file=sys.stderr, flush=True)
        else:
            print(f"[GPU] {event_type}: {target}", file=sys.stderr, flush=True)
    else:
        print(f"[GPU_EVENT] {json.dumps(event)}", file=sys.stderr, flush=True)


# Lock directory
LOCKS_DIR = Path.home() / ".wafer" / "locks"


def _ensure_locks_dir() -> None:
    """Ensure locks directory exists."""
    LOCKS_DIR.mkdir(parents=True, exist_ok=True)


def _lock_path(target_name: str) -> Path:
    """Get path to lock file for a target."""
    return LOCKS_DIR / f"{target_name}.lock"


@contextmanager
def try_acquire_target(target_name: str) -> Iterator[bool]:
    """Try to acquire exclusive lock on a target.

    Args:
        target_name: Name of the target to lock

    Yields:
        True if lock was acquired, False if target is busy

    The lock is automatically released when the context exits,
    or if the process crashes.
    """
    _ensure_locks_dir()
    lock_file = _lock_path(target_name)

    # Open or create lock file
    fd = os.open(str(lock_file), os.O_CREAT | os.O_RDWR)

    try:
        # Try non-blocking exclusive lock
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        # Write PID to lock file for debugging
        os.ftruncate(fd, 0)
        os.write(fd, f"{os.getpid()}\n".encode())
        acquire_time = time.time()
        _emit_gpu_event("gpu_acquire", target=target_name)
        try:
            yield True
        finally:
            # Release lock
            hold_duration_ms = (time.time() - acquire_time) * 1000
            _emit_gpu_event(
                "gpu_release",
                target=target_name,
                hold_duration_ms=round(hold_duration_ms, 1),
            )
            fcntl.flock(fd, fcntl.LOCK_UN)
    except BlockingIOError:
        # Lock is held by another process
        yield False
    finally:
        os.close(fd)


@contextmanager
def acquire_from_pool(
    target_names: list[str],
    timeout: float | None = None,
    poll_interval: float = 1.0,
) -> Iterator[str | None]:
    """Acquire first available target from a list.

    Tries each target in order, returns the first one that's available.
    If all targets are busy and timeout is set, waits and retries.

    Args:
        target_names: List of target names to try
        timeout: Max seconds to wait for a target. None = no waiting (fail immediately).
                 Use float('inf') to wait forever.
        poll_interval: Seconds between retries when waiting

    Yields:
        Name of acquired target, or None if all are busy (and timeout expired)

    Example:
        # Wait up to 5 minutes for a target
        with acquire_from_pool(["gpu-1", "gpu-2", "gpu-3"], timeout=300) as target:
            if target:
                print(f"Got {target}")
                run_eval(target)
            else:
                print("All targets busy after timeout")
    """
    _ensure_locks_dir()

    start_time = time.monotonic()

    while True:
        # Try each target in order
        for target_name in target_names:
            lock_file = _lock_path(target_name)
            fd = os.open(str(lock_file), os.O_CREAT | os.O_RDWR)

            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                # Got the lock - write PID and yield
                os.ftruncate(fd, 0)
                os.write(fd, f"{os.getpid()}\n".encode())
                acquire_time = time.time()
                _emit_gpu_event("gpu_acquire", target=target_name, pool=target_names)
                try:
                    yield target_name
                    return  # Success - exit after context
                finally:
                    hold_duration_ms = (time.time() - acquire_time) * 1000
                    _emit_gpu_event(
                        "gpu_release",
                        target=target_name,
                        pool=target_names,
                        hold_duration_ms=round(hold_duration_ms, 1),
                    )
                    fcntl.flock(fd, fcntl.LOCK_UN)
                    os.close(fd)
            except BlockingIOError:
                # This target is busy, try next
                os.close(fd)
                continue

        # All targets busy - check if we should wait
        if timeout is None:
            # No waiting, fail immediately
            break

        elapsed = time.monotonic() - start_time
        if elapsed >= timeout:
            # Timeout expired
            break

        # Wait and retry
        remaining = timeout - elapsed
        print(f"  All targets busy, waiting... ({int(remaining)}s remaining)", file=sys.stderr)
        time.sleep(poll_interval)

    # All targets busy (timeout expired or no waiting)
    yield None


def is_target_locked(target_name: str) -> bool:
    """Check if a target is currently locked.

    Note: This is a point-in-time check - the lock status can change
    immediately after this returns.

    Args:
        target_name: Name of the target to check

    Returns:
        True if target is locked, False if available
    """
    _ensure_locks_dir()
    lock_file = _lock_path(target_name)

    if not lock_file.exists():
        return False

    fd = os.open(str(lock_file), os.O_RDONLY)
    try:
        # Try non-blocking lock
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        # Got it - so it wasn't locked
        fcntl.flock(fd, fcntl.LOCK_UN)
        return False
    except BlockingIOError:
        return True
    finally:
        os.close(fd)


def get_lock_holder(target_name: str) -> int | None:
    """Get PID of process holding lock on a target.

    Args:
        target_name: Name of the target

    Returns:
        PID of lock holder, or None if not locked or unknown
    """
    lock_file = _lock_path(target_name)

    if not lock_file.exists():
        return None

    try:
        content = lock_file.read_text().strip()
        return int(content)
    except (ValueError, OSError):
        return None


def list_locked_targets() -> list[str]:
    """List all currently locked targets.

    Returns:
        List of target names that are currently locked
    """
    _ensure_locks_dir()

    locked = []
    for lock_file in LOCKS_DIR.glob("*.lock"):
        target_name = lock_file.stem
        if is_target_locked(target_name):
            locked.append(target_name)

    return sorted(locked)


# ── Cloud GPU lock (Supabase-backed) ────────────────────────────────────────

_HEARTBEAT_INTERVAL = 60.0


class _HeartbeatThread(threading.Thread):
    """Daemon thread that sends periodic heartbeats for a GPU lock."""

    def __init__(self, target_id: str, queue_id: str) -> None:
        super().__init__(daemon=True)
        self._target_id = target_id
        self._queue_id = queue_id
        self._stop = threading.Event()

    def run(self) -> None:
        from .user_targets_api import poll_gpu_lock

        while not self._stop.wait(_HEARTBEAT_INTERVAL):
            try:
                poll_gpu_lock(self._target_id, self._queue_id)
            except Exception:
                break

    def stop(self) -> None:
        self._stop.set()


@contextmanager
def cloud_gpu_lock(
    target_id: str,
    gpu_ids: list[int] | None = None,
    gpu_count: int | None = None,
    session_id: str | None = None,
    poll_interval: float = 3.0,
    suppress_gpu_events: bool = False,
) -> Iterator[dict[str, Any] | None]:
    """Acquire a cloud GPU lock via the API, with queue waiting.

    Provide either gpu_ids (explicit set) or gpu_count (server picks from pool).

    Yields:
        Dict with {queue_id, gpu_ids, status, position} if acquired, None if all queues full.
        The lock is held for the duration of the context and released on exit.
    """
    from .user_targets_api import acquire_gpu_lock, poll_gpu_lock, release_gpu_lock

    assert gpu_ids is not None or gpu_count is not None
    try:
        result = acquire_gpu_lock(target_id, gpu_ids=gpu_ids, gpu_count=gpu_count, session_id=session_id)
    except RuntimeError as e:
        print(f"  GPU lock error: {e}", file=sys.stderr)
        yield {"_error": str(e)}
        return

    queue_id = result["queue_id"]
    heartbeat: _HeartbeatThread | None = None

    def _cleanup() -> None:
        if heartbeat is not None:
            heartbeat.stop()
        release_gpu_lock(target_id, queue_id)

    atexit.register(_cleanup)

    try:
        if result["status"] == "queued":
            while True:
                time.sleep(poll_interval)
                try:
                    poll = poll_gpu_lock(target_id, queue_id)
                except RuntimeError:
                    yield None
                    return
                if poll["status"] == "active":
                    result = {
                        "queue_id": queue_id,
                        "gpu_ids": poll["gpu_ids"],
                        "status": "active",
                        "position": 0,
                    }
                    break
                print(
                    f"  Waiting for GPUs {poll['gpu_ids']}... (position {poll['position']})",
                    file=sys.stderr,
                )

        heartbeat = _HeartbeatThread(target_id, queue_id)
        heartbeat.start()
        if not suppress_gpu_events:
            _emit_gpu_event("gpu_acquire", target=target_id, gpu_ids=result["gpu_ids"])

        yield result
    finally:
        atexit.unregister(_cleanup)
        if heartbeat is not None:
            heartbeat.stop()
        if not suppress_gpu_events:
            _emit_gpu_event("gpu_release", target=target_id, gpu_ids=result.get("gpu_ids", []))
        release_gpu_lock(target_id, queue_id)
