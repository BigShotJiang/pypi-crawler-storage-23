# Kernel Evaluation

Test correctness and measure speedup against a reference using the unified eval primitive:

```bash
# List available evaluation tasks
wafer tool eval --list-tasks

# Run evaluation for a specific task
wafer tool eval --task gpumode
wafer tool eval --task kernelbench

# Run evaluation on a GPU target (compose with target run)
wafer target run --name dev -- wafer tool eval --task gpumode

# Sync files and run (cd into /workspace/ where synced files land)
wafer target run --name dev --sync ./my-kernel -- bash -c "cd /workspace && wafer tool eval --task kernelbench"
```

## Workspace + Evaluate Integration

Run eval on a workspace by composing `wafer target run` with `wafer tool eval`:

```bash
# Step 1: Create workspace
wafer target init workspace my-workspace -g B200 -e baremetal

# Step 2: Run eval on the workspace
wafer target run --name my-workspace -- wafer tool eval --task gpumode

# Or sync files first and run
wafer target sync my-workspace ./my-kernel
wafer target run --name my-workspace -- wafer tool eval --task kernelbench
```

**Alternative:** Use `wafer target run` with a custom benchmark script:

```bash
wafer target sync my-workspace ./my-kernel
wafer target run --name my-workspace -- "cd /workspace && python run_benchmark.py"
```

## GPUMode Function Signatures

The GPUMode format requires these specific function names:
- `custom_kernel()` — your optimized kernel implementation
- `ref_kernel()` — reference implementation (in reference.py)
- `generate_input()` — input generator (in reference.py)

## Target Configuration

Targets define GPU access methods. Initialize with:

```bash
wafer target init ssh                # Your own GPU via SSH
wafer target init workspace          # Cloud GPU workspace
```

Then use: `wafer target run --name <name> -- wafer tool eval --task gpumode`
