"""AMDGCN ISA parsing and analysis."""

from wafer.core.lib.kernel_scope.amdgcn.analyzer import ISAAnalysis, analyze_isa
from wafer.core.lib.kernel_scope.amdgcn.packed_opportunity_detector import (
    detect_packable_pairs,
    detect_packed_opportunities,
    format_packed_analysis,
    suggest_packed_rewrite,
)
from wafer.core.lib.kernel_scope.amdgcn.parser import parse_isa_file, parse_isa_text
from wafer.core.lib.kernel_scope.amdgcn.types import (
    InstructionCategory,
    InstructionInfo,
    ISAParseResult,
    KernelMetadata,
    PackableOpPair,
    PackableSequence,
    PackedOpportunityAnalysis,
)

__all__ = [
    "parse_isa_file",
    "parse_isa_text",
    "analyze_isa",
    "ISAAnalysis",
    "ISAParseResult",
    "KernelMetadata",
    "InstructionInfo",
    "InstructionCategory",
    # Packed operation opportunity detection
    "detect_packed_opportunities",
    "detect_packable_pairs",
    "format_packed_analysis",
    "suggest_packed_rewrite",
    "PackableOpPair",
    "PackableSequence",
    "PackedOpportunityAnalysis",
]
