"""Trace comparison library for analyzing GPU traces across platforms.

This module provides functionality to compare performance traces from AMD and NVIDIA GPUs,
identifying kernel-level performance differences and fusion opportunities.
"""

from .analyzer import analyze_traces

# from .api import analyze_trace_pair  # TODO: api.py has unimplemented dependencies
from .architecture import ArchitectureType, detect_architecture
from .classifier import Op, classify
from .formatter import (
    format_fusion_json,
    format_fusion_text,
    format_json,
    format_text,
)
from .fusion_analyzer import analyze_fusion_differences
from .graph_formatter import format_graph_comparison_json, format_graph_comparison_text
from .graph_formatter_detailed import format_graph_comparison_detailed
from .graph_matcher import match_traces
from .loader import load_trace

__all__ = [
    "Op",
    "classify",
    "load_trace",
    "analyze_traces",
    # "analyze_trace_pair",  # TODO: not yet implemented
    "detect_architecture",
    "ArchitectureType",
    "analyze_fusion_differences",
    "format_text",
    "format_json",
    "format_fusion_text",
    "format_fusion_json",
    "match_traces",
    "format_graph_comparison_text",
    "format_graph_comparison_json",
    "format_graph_comparison_detailed",
]
