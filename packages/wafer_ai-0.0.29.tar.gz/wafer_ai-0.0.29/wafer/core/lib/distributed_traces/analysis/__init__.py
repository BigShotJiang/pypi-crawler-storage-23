"""Metric computation modules for distributed traces.

This module provides analysis functionality for:
- Bandwidth calculation (achieved vs theoretical)
- Communication/compute overlap analysis
- Straggler detection and scoring
- Hang risk assessment
"""

from wafer.core.lib.distributed_traces.analysis.bandwidth import (
    BandwidthAnalyzer,
    analyze_bandwidth,
    get_theoretical_bandwidth,
)
from wafer.core.lib.distributed_traces.analysis.hang_risk import (
    HangRiskAnalyzer,
    analyze_hang_risk,
)
from wafer.core.lib.distributed_traces.analysis.overlap import (
    OverlapAnalyzer,
    analyze_overlap,
)
from wafer.core.lib.distributed_traces.analysis.straggler import (
    StragglerAnalyzer,
    detect_stragglers,
)

__all__ = [
    # Bandwidth
    "BandwidthAnalyzer",
    "analyze_bandwidth",
    "get_theoretical_bandwidth",
    # Overlap
    "OverlapAnalyzer",
    "analyze_overlap",
    # Straggler
    "StragglerAnalyzer",
    "detect_stragglers",
    # Hang risk
    "HangRiskAnalyzer",
    "analyze_hang_risk",
]
