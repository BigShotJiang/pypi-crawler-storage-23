"""Wafer utilities package for kernel execution and validation."""
from __future__ import annotations

import importlib
from typing import Any

_ATTR_MODULES = {
    "get_api_url": "wafer.core.utils.backend",
    "get_auth_token": "wafer.core.utils.backend",
    "list_captures": "wafer.core.utils.backend",
    "upload_artifact": "wafer.core.utils.backend",
    "upload_capture": "wafer.core.utils.backend",
}


def __getattr__(name: str) -> Any:
    module_path = _ATTR_MODULES.get(name)
    if module_path is not None:
        mod = importlib.import_module(module_path)
        val = getattr(mod, name)
        globals()[name] = val
        return val
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = list(_ATTR_MODULES.keys())
