"""Subagent tool: delegate tasks to Claude or Codex subagents.

Spawns a named subagent (configured in agent TOML) as a subprocess,
streams output via ToolResultDelta, returns final text as ToolResult.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import time
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

import trio

from wafer.cli.agent_config import SubagentConfig
from wafer.core.rollouts.dtypes import (
    Message,
    Tool,
    ToolCall,
    ToolCallContent,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
    ToolResultDelta,
)

SUBAGENT_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="subagent",
        description=(
            "Delegate a task to a named subagent. Subagents are configured "
            "in the agent TOML under [subagents.*]. Use 'plan' subagents for "
            "analysis/planning (read-only) and 'execute' subagents for focused implementation."
        ),
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "agent": {"type": "string", "description": "Name of the subagent (from config)"},
                "prompt": {"type": "string", "description": "Task for the subagent"},
            },
        ),
        required=["agent", "prompt"],
    ),
)


def _build_claude_command(config: SubagentConfig, prompt: str) -> list[str]:
    cmd = ["claude", "-p", prompt, "--output-format", "stream-json", "--verbose"]
    if config.allowed_tools:
        cmd.extend(["--allowedTools", ",".join(config.allowed_tools)])
    if config.model:
        cmd.extend(["--model", config.model])
    return cmd


def _build_codex_command(config: SubagentConfig, prompt: str) -> list[str]:
    cmd = ["codex", "exec", "--json", "--full-auto", "--skip-git-repo-check"]
    if config.model:
        cmd.extend(["-m", config.model])
    if config.sandbox:
        cmd.extend(["--sandbox", config.sandbox])
    cmd.append(prompt)
    return cmd


def _extract_text_from_claude_stream(raw: str) -> str:
    """Extract assistant text from Claude NDJSON stream output."""
    parts: list[str] = []
    for line in raw.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("type") == "assistant":
            msg = event.get("message", {})
            for block in msg.get("content", []):
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(block.get("text", ""))
        elif event.get("type") == "result":
            result_text = event.get("result", "")
            if result_text:
                parts.append(result_text)
    return "\n".join(parts) if parts else raw.strip()


def _extract_text_from_codex_stream(raw: str) -> str:
    """Extract assistant text from Codex NDJSON stream output."""
    parts: list[str] = []
    for line in raw.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("type") != "item.completed":
            continue
        item = event.get("item", {})
        if item.get("type") == "agent_message":
            text = item.get("text", "")
            if text:
                parts.append(text)
    return "\n".join(parts) if parts else raw.strip()


def parse_codex_json(output: str) -> list[Message]:
    """Parse Codex ``exec --json`` output into list[Message].

    Codex emits NDJSON with an item-based event stream:
        {"type": "item.completed", "item": {"type": "agent_message", "text": "..."}}
        {"type": "item.completed", "item": {"type": "command_execution", "command": "ls", ...}}
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("type") != "item.completed":
            continue
        item = event.get("item", {})
        item_type = item.get("type")
        item_id = item.get("id", "")
        if item_type == "agent_message":
            text = item.get("text", "")
            if text:
                messages.append(Message(role="assistant", content=text))
        elif item_type == "command_execution":
            command = item.get("command", "")
            output_text = item.get("aggregated_output") or item.get("output", "")
            messages.append(Message(
                role="assistant",
                content=[ToolCallContent(id=item_id, name="bash", arguments={"command": command})],
            ))
            messages.append(Message(role="tool", content=output_text, tool_call_id=item_id))
        elif item_type == "file_change":
            for change in item.get("changes", []):
                path = change.get("path", "")
                kind = change.get("kind", "update")
                tool_name = "write" if kind in ("add", "update") else "edit"
                messages.append(Message(
                    role="assistant",
                    content=[ToolCallContent(id=item_id, name=tool_name, arguments={"path": path, "kind": kind})],
                ))
                messages.append(Message(
                    role="tool",
                    content=f"{'Wrote' if kind != 'delete' else 'Deleted'} {path}",
                    tool_call_id=item_id,
                ))
    return messages


async def exec_subagent(
    tool_call: ToolCall,
    working_dir: Path,
    subagent_configs: dict[str, SubagentConfig],
    on_output: Callable[[ToolResultDelta], Awaitable[None]] | None = None,
) -> ToolResult:
    """Execute a named subagent as a subprocess."""
    agent_name = tool_call.args.get("agent", "")
    prompt = tool_call.args.get("prompt", "")
    assert agent_name, "subagent 'agent' argument is required"
    assert prompt, "subagent 'prompt' argument is required"

    config = subagent_configs.get(agent_name)
    assert config is not None, (
        f"Unknown subagent '{agent_name}'. "
        f"Available: {sorted(subagent_configs.keys()) if subagent_configs else '(none)'}"
    )

    binary = "claude" if config.backend == "claude" else "codex"
    assert shutil.which(binary), f"'{binary}' CLI not found on PATH. Install it to use {config.backend} subagents."

    if config.backend == "claude":
        cmd = _build_claude_command(config, prompt)
    else:
        cmd = _build_codex_command(config, prompt)

    start = time.perf_counter()
    raw_chunks: list[str] = []

    process = await trio.lowlevel.open_process(
        cmd,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(working_dir),
    )

    try:
        with trio.move_on_after(config.timeout) as cancel_scope:
            assert process.stdout is not None
            buf = ""
            async for chunk in process.stdout:
                text = chunk.decode("utf-8", errors="replace")
                raw_chunks.append(text)
                buf += text
                while "\n" in buf:
                    line, buf = buf.split("\n", 1)
                    if on_output and line.strip():
                        await on_output(ToolResultDelta(
                            tool_call_id=tool_call.id,
                            delta=line + "\n",
                        ))

        if cancel_scope.cancelled_caught:
            process.kill()
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Subagent '{agent_name}' timed out after {config.timeout}s",
            )

        await process.wait()
    except Exception as e:
        process.kill()
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=f"Subagent '{agent_name}' failed: {e}",
        )

    duration = time.perf_counter() - start
    raw_output = "".join(raw_chunks)

    if process.returncode != 0:
        stderr_bytes = b""
        if process.stderr:
            stderr_bytes = await process.stderr.receive_some(65536)
        stderr_text = stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=f"Subagent '{agent_name}' exited {process.returncode} ({duration:.1f}s): {stderr_text[:500]}",
        )

    if config.backend == "claude":
        result_text = _extract_text_from_claude_stream(raw_output)
    else:
        result_text = _extract_text_from_codex_stream(raw_output)

    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=result_text,
    )
