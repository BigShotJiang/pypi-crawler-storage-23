"""Cloud CUDA compiler - Godbolt for CUDA.

Send CUDA C++ code, get PTX/SASS back for inspection.
"""

from wafer.core.tools.compile.compiler import (
    compile_cuda_local,
    compile_cuda_remote,
    request_to_dict,
    response_from_dict,
)
from wafer.core.tools.compile.types import (
    VALID_ARCHITECTURES,
    CompileRequest,
    CompileResponse,
    OutputFormat,
)

__all__ = [
    # Types
    "CompileRequest",
    "CompileResponse",
    "OutputFormat",
    "VALID_ARCHITECTURES",
    # Functions
    "compile_cuda_local",
    "compile_cuda_remote",
    "request_to_dict",
    "response_from_dict",
]
