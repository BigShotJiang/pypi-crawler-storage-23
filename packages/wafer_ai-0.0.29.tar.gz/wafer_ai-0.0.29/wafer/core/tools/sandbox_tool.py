"""Sandbox tool: run commands on the remote GPU machine via persistent tmux session."""
from __future__ import annotations

from wafer.core.rollouts.dtypes import (
    Tool,
    ToolCall,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
)
from wafer.core.sandbox.session import SandboxSession
from wafer.core.tools._output import truncate_output

SANDBOX_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="sandbox",
        description="Run a command on the remote GPU machine. Each command runs in an isolated subshell. Use && to chain multiple commands (e.g. 'cd /tmp && python script.py').",
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "command": {
                    "type": "string",
                    "description": "Command to run on the remote GPU machine",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (default: 180)",
                },
            },
        ),
        required=["command"],
    ),
)


async def exec_sandbox(
    tool_call: ToolCall,
    session: SandboxSession,
) -> ToolResult:
    """Execute sandbox tool call. Returns ToolResult."""
    command = tool_call.args.get("command", "")
    timeout = tool_call.args.get("timeout", 180)
    output, exit_code = await session.run_command(command, timeout)
    output = truncate_output(output)
    if exit_code == -1:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=output,
            error=f"Command timed out after {timeout} seconds",
        )
    if exit_code != 0:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=output,
            error=f"Command exited with code {exit_code}",
        )
    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=output or "(no output)",
    )
