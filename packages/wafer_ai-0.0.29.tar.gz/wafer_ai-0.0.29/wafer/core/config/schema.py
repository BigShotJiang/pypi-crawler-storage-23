"""Configuration schema for Wafer CLI.
Example config.toml:
    [allowlist]
    allow = ["npm run", "cargo build"]
    block = ["rm -rf", "sudo"]
"""
from dataclasses import dataclass, field


@dataclass
class AllowlistConfig:
    """Command allowlist configuration."""
    allow: list[str] = field(default_factory=list)
    block: list[str] = field(default_factory=list)


@dataclass
class WaferConfig:
    """Complete Wafer configuration.
    Attributes:
        allowlist: Command allow/block lists
        source: Where this config was loaded from (for debugging)
    """
    allowlist: AllowlistConfig = field(default_factory=AllowlistConfig)
    source: str | None = None

    @classmethod
    def from_dict(cls, data: dict, source: str | None = None) -> "WaferConfig":
        """Create config from a dictionary (parsed TOML)."""
        allowlist_data = data.get("allowlist", {})

        allowlist_config = AllowlistConfig(
            allow=_validate_string_list(allowlist_data.get("allow", []), "allowlist.allow"),
            block=_validate_string_list(allowlist_data.get("block", []), "allowlist.block"),
        )
        return cls(
            allowlist=allowlist_config,
            source=source,
        )

    def to_dict(self) -> dict:
        """Convert to dictionary (for serialization)."""
        return {
            "allowlist": {
                "allow": self.allowlist.allow,
                "block": self.allowlist.block,
            },
        }


def _validate_string_list(value: object, field_name: str) -> list[str]:
    """Validate that a value is a list of strings."""
    if not isinstance(value, list):
        raise TypeError(f"{field_name} must be a list, got {type(value).__name__}")
    for i, item in enumerate(value):
        if not isinstance(item, str):
            raise TypeError(f"{field_name}[{i}] must be a string, got {type(item).__name__}")
    return value


def _validate_bool(value: object, field_name: str) -> bool:
    """Validate that a value is a boolean."""
    if not isinstance(value, bool):
        raise TypeError(f"{field_name} must be a boolean, got {type(value).__name__}")
    return value
