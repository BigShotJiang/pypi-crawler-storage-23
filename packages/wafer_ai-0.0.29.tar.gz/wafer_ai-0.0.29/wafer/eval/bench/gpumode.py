"""GPUMode bench script.

Runs in a directory containing kernel.py (custom_kernel), reference.py (ref_kernel + generate_input),
and test_cases.json. Outputs JSON to stdout.

Usage: python -m wafer.eval.bench.gpumode [--benchmark] [--seed 42]
"""
from __future__ import annotations

import argparse
import gc
import importlib.util
import json
import statistics
import sys
from pathlib import Path


def _load_module(path: Path, name: str) -> object:
    assert path.exists(), f"File not found: {path}"
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _calculate_timing_stats(times: list[float]) -> dict:
    assert len(times) > 0
    sorted_times = sorted(times)
    n = len(sorted_times)
    median = statistics.median(sorted_times)
    return {
        "median": median,
        "mean": statistics.mean(sorted_times),
        "min": min(sorted_times),
        "max": max(sorted_times),
        "std": statistics.stdev(sorted_times) if n > 1 else 0,
    }


def main() -> None:
    import torch

    if torch.cuda.is_available():
        gc.collect()
        torch.cuda.empty_cache()

    parser = argparse.ArgumentParser(description="GPUMode evaluation")
    parser.add_argument("--impl", default="kernel.py")
    parser.add_argument("--reference", default="reference.py")
    parser.add_argument("--test-cases", default="test_cases.json")
    parser.add_argument("--benchmark", action="store_true")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num-perf-trials", type=int, default=10)
    args = parser.parse_args()

    impl_path = Path(args.impl)
    ref_path = Path(args.reference)
    test_cases_path = Path(args.test_cases)

    assert impl_path.exists(), f"Implementation not found: {impl_path}"
    assert ref_path.exists(), f"Reference not found: {ref_path}"
    assert test_cases_path.exists(), f"Test cases not found: {test_cases_path}"

    test_cases = json.loads(test_cases_path.read_text())
    ref_module = _load_module(ref_path, "reference")
    impl_module = _load_module(impl_path, "implementation")

    ref_kernel = ref_module.ref_kernel  # type: ignore[attr-defined]
    custom_kernel = impl_module.custom_kernel  # type: ignore[attr-defined]
    generate_input = ref_module.generate_input  # type: ignore[attr-defined]

    test_results = []
    all_correct = True
    total_speedup = 0.0

    for i, tc in enumerate(test_cases):
        torch.manual_seed(args.seed)
        inputs = generate_input(**tc)
        if isinstance(inputs, dict):
            ref_out = ref_kernel(**inputs)
            impl_out = custom_kernel(**inputs)
        else:
            ref_out = ref_kernel(*inputs)
            impl_out = custom_kernel(*inputs)

        if isinstance(ref_out, torch.Tensor):
            correct = torch.allclose(ref_out, impl_out, rtol=1e-3, atol=1e-3)
        else:
            correct = True
            for r, n in zip(ref_out, impl_out):
                if isinstance(r, torch.Tensor) and not torch.allclose(r, n, rtol=1e-3, atol=1e-3):
                    correct = False
                    break

        speedup = 0.0
        if args.benchmark and correct:
            for _ in range(5):
                if isinstance(inputs, dict):
                    custom_kernel(**inputs)
                    ref_kernel(**inputs)
                else:
                    custom_kernel(*inputs)
                    ref_kernel(*inputs)
            torch.cuda.synchronize()

            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)

            impl_times = []
            for _ in range(args.num_perf_trials):
                start.record()
                if isinstance(inputs, dict):
                    custom_kernel(**inputs)
                else:
                    custom_kernel(*inputs)
                end.record()
                torch.cuda.synchronize()
                impl_times.append(start.elapsed_time(end))

            ref_times = []
            for _ in range(args.num_perf_trials):
                start.record()
                if isinstance(inputs, dict):
                    ref_kernel(**inputs)
                else:
                    ref_kernel(*inputs)
                end.record()
                torch.cuda.synchronize()
                ref_times.append(start.elapsed_time(end))

            impl_median = statistics.median(impl_times)
            ref_median = statistics.median(ref_times)
            speedup = ref_median / impl_median if impl_median > 0 else 0.0

        test_results.append({"is_correct": correct, "speedup": speedup})
        if not correct:
            all_correct = False
        total_speedup += speedup

    passed = sum(1 for t in test_results if t["is_correct"])
    total = len(test_results)
    geomean_speedup = 0.0
    if args.benchmark and passed > 0:
        speedups = [t["speedup"] for t in test_results if t["is_correct"] and t["speedup"] > 0]
        if speedups:
            import math
            geomean_speedup = math.exp(sum(math.log(s) for s in speedups) / len(speedups))

    result = {
        "all_correct": all_correct,
        "correctness_score": passed / total if total > 0 else 0.0,
        "geomean_speedup": geomean_speedup,
        "passed_tests": passed,
        "total_tests": total,
    }

    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    print(f"EVAL_RESULT_JSON:{json.dumps(result)}")


if __name__ == "__main__":
    main()
