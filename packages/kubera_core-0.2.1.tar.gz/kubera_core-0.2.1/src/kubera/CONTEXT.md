# kubera

Personal asset management backend. Self-hosted on user's PC — all financial data local.

```
cli → core ← api          (one-way deps, cli and api never depend on each other)
```

| Layer | Role | Key tech |
|-------|------|----------|
| core/ | Models, services | SQLAlchemy |
| api/ | HTTP endpoints, auth | FastAPI |
| cli/ | CLI entry point | argparse |

Settings priority: code kwargs > env vars > .env > settings.yaml > defaults.
`secret_token` auto-generates on first use, persists to `.env`. Prefix: `KUBERA_`.
