"""Snapshot router."""

from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, Query, UploadFile
from sqlalchemy.orm import Session

from kubera.api.auth import verify_token
from kubera.api.deps import get_db
from kubera.api.errors import KuberaError
from kubera.api.schemas.common import PaginatedResponse, PaginationParams
from kubera.api.schemas.snapshot import (
    AssetEntryCreate,
    AssetEntryResponse,
    CompareResponse,
    LedgerEntryResponse,
    SnapshotDetailResponse,
    SnapshotSummaryResponse,
    TrendPointResponse,
)
from kubera.core.snapshot.service import SnapshotService

router = APIRouter(
    prefix="/api/v1/snapshots", tags=["snapshots"], dependencies=[Depends(verify_token)]
)


@router.post("/import", response_model=SnapshotSummaryResponse, status_code=201)
async def import_snapshot(
    file: UploadFile,
    password: str | None = Query(None),
    db: Session = Depends(get_db),
):
    svc = SnapshotService(db)
    content = await file.read()
    snapshot = svc.import_from_bytes(
        content, filename=file.filename or "upload.xlsx", password=password
    )
    return SnapshotSummaryResponse.model_validate(snapshot)


@router.get("/trend", response_model=list[TrendPointResponse])
def get_trend(
    start: date | None = Query(None),
    end: date | None = Query(None),
    db: Session = Depends(get_db),
):
    svc = SnapshotService(db)
    return svc.get_trend(start=start, end=end)


@router.get("/compare", response_model=CompareResponse)
def compare_snapshots(
    from_date: date = Query(...),
    to_date: date = Query(...),
    db: Session = Depends(get_db),
):
    svc = SnapshotService(db)
    return svc.compare_snapshots(from_date=from_date, to_date=to_date)


@router.get("", response_model=PaginatedResponse[SnapshotSummaryResponse])
def list_snapshots(
    start: date | None = Query(None),
    end: date | None = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    params = PaginationParams(page=page, size=size)
    svc = SnapshotService(db)
    items, total = svc.list_snapshots(start=start, end=end, offset=params.offset, limit=params.size)
    return PaginatedResponse[SnapshotSummaryResponse].create(
        items=[SnapshotSummaryResponse.model_validate(s) for s in items],
        total=total,
        params=params,
    )


@router.get("/{snapshot_id}/ledger", response_model=PaginatedResponse[LedgerEntryResponse])
def get_ledger_entries(
    snapshot_id: int,
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
):
    params = PaginationParams(page=page, size=size)
    svc = SnapshotService(db)
    items, total = svc.get_ledger_entries(snapshot_id, offset=params.offset, limit=params.size)
    if total == 0:
        # Check if snapshot exists
        snapshot = svc.get_snapshot(snapshot_id)
        if not snapshot:
            raise KuberaError("Snapshot not found", code="SNAPSHOT_NOT_FOUND", status=404)
    return PaginatedResponse[LedgerEntryResponse].create(
        items=[LedgerEntryResponse.model_validate(e) for e in items],
        total=total,
        params=params,
    )


@router.get("/{snapshot_id}", response_model=SnapshotDetailResponse)
def get_snapshot(snapshot_id: int, db: Session = Depends(get_db)):
    svc = SnapshotService(db)
    snapshot = svc.get_snapshot(snapshot_id)
    if not snapshot:
        raise KuberaError("Snapshot not found", code="SNAPSHOT_NOT_FOUND", status=404)
    return SnapshotDetailResponse.model_validate(snapshot)


@router.post("/{snapshot_id}/assets", response_model=AssetEntryResponse, status_code=201)
def add_asset_entry(snapshot_id: int, body: AssetEntryCreate, db: Session = Depends(get_db)):
    svc = SnapshotService(db)
    entry = svc.add_asset_entry(snapshot_id, body.model_dump())
    return AssetEntryResponse.model_validate(entry)


@router.delete("/{snapshot_id}/assets/{entry_id}", status_code=204)
def delete_asset_entry(snapshot_id: int, entry_id: int, db: Session = Depends(get_db)):
    svc = SnapshotService(db)
    deleted = svc.delete_asset_entry(snapshot_id, entry_id)
    if not deleted:
        raise KuberaError("Asset entry not found", code="ENTRY_NOT_FOUND", status=404)


@router.delete("/{snapshot_id}", status_code=204)
def delete_snapshot(snapshot_id: int, db: Session = Depends(get_db)):
    svc = SnapshotService(db)
    deleted = svc.delete_snapshot(snapshot_id)
    if not deleted:
        raise KuberaError("Snapshot not found", code="SNAPSHOT_NOT_FOUND", status=404)
