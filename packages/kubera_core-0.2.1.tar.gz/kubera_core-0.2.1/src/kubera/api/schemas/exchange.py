"""Exchange schemas."""

from __future__ import annotations

from pydantic import BaseModel


class UpbitBalanceResponse(BaseModel):
    currency: str
    balance: str
    locked: str
    avg_buy_price: str
    avg_buy_price_modified: bool
    unit_currency: str
