"""FastAPI application factory."""

from __future__ import annotations

from contextlib import asynccontextmanager

from importlib.metadata import version as get_version

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from kubera.api.errors import KuberaError, kubera_error_handler
from kubera.api.routers import exchange, snapshots
from kubera.core.config import get_settings
from kubera.core.models import Base
from kubera.core.models.base import get_engine


def create_app(settings=None) -> FastAPI:
    """Create and configure the FastAPI application."""
    if settings is None:
        settings = get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        engine = get_engine(app.state.settings.database_url)
        Base.metadata.create_all(engine)
        yield
        engine.dispose()

    app = FastAPI(
        title="Kubera",
        version=get_version("kubera-core"),
        lifespan=lifespan,
    )

    app.state.settings = settings

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.add_exception_handler(KuberaError, kubera_error_handler)

    @app.get("/api/v1/health")
    def health():
        return {"status": "ok"}

    app.include_router(snapshots.router)
    app.include_router(exchange.router)

    return app
