"""esp_pylib: Espressif Python utilities."""

from esp_pylib.__version__ import __version__

__all__ = ['__version__']
