__all__ = ['warning']


def warning(msg: str, *args: object, **kwargs: object) -> None:
    pass
