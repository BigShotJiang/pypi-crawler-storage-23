# __all__ = ['get_serial_port_list']


# def get_serial_port_list() -> List[str]:
