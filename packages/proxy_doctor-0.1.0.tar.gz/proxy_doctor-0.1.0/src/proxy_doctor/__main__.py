"""Allow running as: python3 -m proxy_doctor"""

import sys

from proxy_doctor.cli import main

sys.exit(main())
