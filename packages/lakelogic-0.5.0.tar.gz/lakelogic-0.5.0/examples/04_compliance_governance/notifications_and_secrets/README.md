# Notifications & Secrets

Configure alerts and securely manage credentials.

## Files

- notifications_secrets.ipynb
- notifications_contract.yaml
