"""S3-compatible storage provider using boto3.

Supports AWS S3, MinIO, and other S3-compatible services.
"""

import asyncio
import logging
import os
from pathlib import Path
from typing import Optional

import boto3
from botocore.config import Config as BotoConfig
from botocore.exceptions import ClientError

from .base_storage import BaseStorage
try:
    from ..core_lib.core_lib_config.settings import S3Settings
except ImportError:
    # Fallback for when core_lib_storage is installed as a top-level package
    # (e.g., Tilt local dev Dockerfiles that COPY packages into site-packages)
    from core_lib.core_lib_config.settings import S3Settings

logger = logging.getLogger(__name__)

# Multipart upload threshold: 5 MB
_MULTIPART_THRESHOLD = 5 * 1024 * 1024


class S3Storage(BaseStorage):
    """S3-compatible storage provider using boto3.

    Supports download, upload (with multipart for files >5MB),
    and presigned URL generation.

    Args:
        settings: S3Settings with endpoint, credentials, and bucket.
        default_bucket: Override bucket name (falls back to settings).
    """

    def __init__(
        self,
        settings: Optional[S3Settings] = None,
        default_bucket: Optional[str] = None,
    ):
        if settings is None:
            settings = S3Settings()
        self._settings = settings
        self._default_bucket = default_bucket or settings.S3_BUCKET
        self._client = boto3.client(
            "s3",
            endpoint_url=settings.S3_ENDPOINT_URL,
            aws_access_key_id=settings.S3_ACCESS_KEY_ID,
            aws_secret_access_key=settings.S3_SECRET_ACCESS_KEY,
            config=BotoConfig(
                signature_version="s3v4",
                retries={"max_attempts": 3, "mode": "adaptive"},
            ),
        )
        logger.info(
            "S3Storage initialized",
            extra={
                "endpoint": settings.S3_ENDPOINT_URL,
                "bucket": self._default_bucket,
            },
        )

    def _parse_uri(self, uri: str) -> tuple[str, str]:
        """Parse an S3 URI into (bucket, key).

        Supported formats:
            s3://bucket/path/to/file
            bucket/path/to/file
            path/to/file  (uses default bucket)
        """
        if uri.startswith("s3://"):
            uri = uri[5:]
            parts = uri.split("/", 1)
            if len(parts) == 2:
                return parts[0], parts[1]
            raise ValueError(f"Invalid S3 URI: s3://{uri}")

        if "/" in uri:
            # Check if first segment looks like a bucket name
            first_segment = uri.split("/", 1)[0]
            if first_segment == self._default_bucket:
                return first_segment, uri.split("/", 1)[1]

        # Treat entire URI as key within default bucket
        return self._default_bucket, uri

    async def download(self, uri: str, destination: Path) -> None:
        """Download a file from S3 to a local path.

        Args:
            uri: S3 URI or key (e.g., 's3://bucket/key' or 'path/to/file').
            destination: Local directory or file path. If a directory,
                the filename is extracted from the key.
        """
        bucket, key = self._parse_uri(uri)

        if destination.is_dir():
            dest_file = destination / Path(key).name
        else:
            dest_file = destination
            dest_file.parent.mkdir(parents=True, exist_ok=True)

        logger.info(
            "Downloading from S3",
            extra={"bucket": bucket, "key": key, "destination": str(dest_file)},
        )

        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(
                None,
                self._client.download_file,
                bucket,
                key,
                str(dest_file),
            )
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            logger.error(
                "S3 download failed",
                extra={"bucket": bucket, "key": key, "error_code": error_code},
            )
            raise

        logger.info(
            "S3 download complete",
            extra={"bucket": bucket, "key": key, "size_bytes": dest_file.stat().st_size},
        )

    async def upload(self, source: Path, uri: str) -> None:
        """Upload a local file to S3.

        Uses multipart upload for files >5MB.

        Args:
            source: Local file path.
            uri: S3 URI or key.
        """
        bucket, key = self._parse_uri(uri)
        file_size = source.stat().st_size

        logger.info(
            "Uploading to S3",
            extra={"bucket": bucket, "key": key, "size_bytes": file_size},
        )

        loop = asyncio.get_event_loop()
        try:
            if file_size > _MULTIPART_THRESHOLD:
                from boto3.s3.transfer import TransferConfig

                config = TransferConfig(
                    multipart_threshold=_MULTIPART_THRESHOLD,
                    multipart_chunksize=_MULTIPART_THRESHOLD,
                )
                await loop.run_in_executor(
                    None,
                    lambda: self._client.upload_file(
                        str(source), bucket, key, Config=config
                    ),
                )
            else:
                await loop.run_in_executor(
                    None,
                    self._client.upload_file,
                    str(source),
                    bucket,
                    key,
                )
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            logger.error(
                "S3 upload failed",
                extra={"bucket": bucket, "key": key, "error_code": error_code},
            )
            raise

        logger.info("S3 upload complete", extra={"bucket": bucket, "key": key})

    async def get_presigned_url(self, uri: str, expiration: int = 3600) -> str:
        """Generate a presigned URL for downloading a file from S3.

        Args:
            uri: S3 URI or key.
            expiration: URL validity in seconds (default: 1 hour).

        Returns:
            Presigned URL string.
        """
        bucket, key = self._parse_uri(uri)

        logger.debug(
            "Generating presigned URL",
            extra={"bucket": bucket, "key": key, "expiration": expiration},
        )

        loop = asyncio.get_event_loop()
        url = await loop.run_in_executor(
            None,
            lambda: self._client.generate_presigned_url(
                "get_object",
                Params={"Bucket": bucket, "Key": key},
                ExpiresIn=expiration,
            ),
        )
        return url