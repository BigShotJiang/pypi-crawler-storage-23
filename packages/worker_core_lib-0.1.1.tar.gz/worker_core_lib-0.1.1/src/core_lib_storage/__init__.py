"""Storage provider abstraction layer.

Exports:
    BaseStorage                – abstract interface
    StorageProviderFactory     – registry & factory
    S3Storage                  – Amazon S3 / MinIO provider
    SFTPStorage                – SFTP provider (paramiko)
    GoogleDriveStorage         – Google Drive v3 provider
"""

from core_lib_storage.base_storage import BaseStorage
from core_lib_storage.storage_provider_factory import StorageProviderFactory
from core_lib_storage.s3_storage import S3Storage
from core_lib_storage.sftp_storage import SFTPStorage
from core_lib_storage.gdrive_storage import GoogleDriveStorage

__all__ = [
    "BaseStorage",
    "StorageProviderFactory",
    "S3Storage",
    "SFTPStorage",
    "GoogleDriveStorage",
]