"""ELK event tracking for worker metrics.

Canonical location for the ELK wrapper module.
Import from here, not from ``worker_core_lib.elk``.

Usage::

    from core_lib.core_lib_elk import ElkEventWrapper, MetricCategory

    elk = ElkEventWrapper(worker_name="worker-download")
    async with elk.track_file_processing(operation="download", model_id="m-1") as t:
        await do_work()
        t.set_file_size(1024)
"""

from core_lib.core_lib_elk.elk_wrapper import (
    ElkEventWrapper,
    ElkMetricTracker,
    MetricCategory,
)

__all__ = [
    "ElkEventWrapper",
    "ElkMetricTracker",
    "MetricCategory",
]
