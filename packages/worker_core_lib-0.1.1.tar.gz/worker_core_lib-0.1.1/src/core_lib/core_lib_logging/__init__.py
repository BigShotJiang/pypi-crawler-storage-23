"""
Structured JSON logging for MeshSync workers.

Provides a centralised ``configure_logging()`` function that configures the
Python ``logging`` module to emit **JSON-formatted log lines** with a
consistent schema.

Every log record includes:
- ``timestamp``   — ISO-8601 UTC
- ``level``       — DEBUG / INFO / WARNING / ERROR / CRITICAL
- ``logger``      — logger name (module path)
- ``message``     — human-readable text
- ``correlationId`` — propagated from job data for end-to-end tracing
- ``worker``      — worker service identifier
- ``hostname``    — pod / machine name
- ``environment`` — NODE_ENV / WORKER_ENV value

Usage (in any worker ``main.py``)::

    from core_lib.core_lib_logging import configure_logging, set_correlation_id

    configure_logging(worker_name="worker-thumbnail-generation")

    # Inside job processor:
    set_correlation_id(job.data.get("correlationId"))
    logger.info("Processing thumbnail for model %s", model_id)
"""
from .json_logger import (
    configure_logging,
    set_correlation_id,
    get_correlation_id,
    clear_correlation_id,
    CorrelationIdFilter,
    JsonFormatter,
)

__all__ = [
    "configure_logging",
    "set_correlation_id",
    "get_correlation_id",
    "clear_correlation_id",
    "CorrelationIdFilter",
    "JsonFormatter",
]
