"""Package-backed MCP adapter for lineage tools."""

from src.lineage.mcp_impl import register_lineage_tools

__all__ = ["register_lineage_tools"]
