def hello(name):
    return f"Hello, {name}!"

def get_version():
    return "0.1.0"
