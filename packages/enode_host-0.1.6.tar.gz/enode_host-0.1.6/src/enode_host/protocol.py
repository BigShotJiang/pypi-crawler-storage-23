import enum
import struct
from dataclasses import dataclass
from typing import Optional


class MsgType(enum.IntEnum):
    COMMAND = 0x10
    STATUS = 0x20
    ACK = 0x30
    DATA = 0x40
    PPS = 0x41
    SD_STREAM = 0x50
    SD_DONE = 0x51
    GNSS = 0x60


class CommandId(enum.IntEnum):
    START_DAQ = 0x01
    STOP_DAQ = 0x02
    SET_MODE = 0x03
    START_REALTIME_STREAM = 0x04
    STOP_REALTIME_STREAM = 0x05
    START_SD_STREAM = 0x08
    STOP_SD_STREAM = 0x09
    SD_CLEAR = 0x0A
    SET_DAQ_MODE = 0x0B
    SHUTDOWN = 0x0C
    CHANGE_TIME_SOURCE = 0x0D


class Mode(enum.IntEnum):
    REALTIME = 0
    PAST = 1


class Toggle(enum.IntEnum):
    STOP = 0
    START = 1


class TimeSource(enum.IntEnum):
    GNSS = 0
    RTC = 1
    TRIG = 2


@dataclass
class StatusReport:
    node_type: int
    node_number: int
    level: int
    parent_mac: bytes
    self_mac: bytes
    rssi: int
    acc_model: int = 0
    daq_mode: int = 0
    daq_on: int = 0
    stream_status: int = 0
    bat_vol: Optional[float] = None
    time_source: int = 0


@dataclass
class AccSample:
    cc: int
    ax: float
    ay: float
    az: float


@dataclass
class AccBatch:
    node_type: int
    node_number: int
    samples: list[AccSample]


@dataclass
class PpsReport:
    node_type: int
    node_number: int
    cc: int
    epoch: int


@dataclass
class SdStreamChunk:
    node_type: int
    node_number: int
    file_time: int
    offset: int
    data: bytes


@dataclass
class SdStreamDone:
    node_type: int
    node_number: int
    file_time: int
    status: int


@dataclass
class GnssReport:
    node_type: int
    node_number: int
    latitude: float
    longitude: float
    fix_mode: int
    valid: int


@dataclass
class Ack:
    original_type: int
    status: int
    message: str = ""


def pack_frame(msg_type: int, payload: bytes) -> bytes:
    if len(payload) > 0xFFFF:
        raise ValueError("payload too large")
    header = struct.pack(">BH", int(msg_type), len(payload)
    )
    return header + payload


def build_command(command_id: CommandId, payload: bytes = b"") -> bytes:
    return pack_frame(MsgType.COMMAND, bytes([int(command_id)]) + payload)


def build_ack(original_type: int, status: int, message: str = "") -> bytes:
    msg = message.encode("utf-8")
    payload = struct.pack(">BBH", int(original_type), int(status), len(msg)) + msg
    return pack_frame(MsgType.ACK, payload)


def parse_ack(payload: bytes) -> Ack:
    if len(payload) < 4:
        raise ValueError(f"invalid ack payload length {len(payload)}")
    original_type, status, msg_len = struct.unpack(">BBH", payload[:4])
    message = payload[4:4 + msg_len].decode("utf-8", errors="replace")
    return Ack(original_type=original_type, status=status, message=message)


def build_sd_stream_start(hours: int) -> bytes:
    payload = struct.pack(">H", int(hours))
    return build_command(CommandId.START_SD_STREAM, payload)


def build_sd_stream_stop() -> bytes:
    return build_command(CommandId.STOP_SD_STREAM, b"")


def build_sd_clear() -> bytes:
    return build_command(CommandId.SD_CLEAR, b"")


def build_set_daq_mode(mode: int) -> bytes:
    return build_command(CommandId.SET_DAQ_MODE, bytes([int(mode) & 0xFF]))


def build_change_time_source(source: TimeSource | int) -> bytes:
    return build_command(CommandId.CHANGE_TIME_SOURCE, bytes([int(source) & 0xFF]))


def parse_status(payload: bytes) -> StatusReport:
    if len(payload) not in (16, 18, 19, 20, 24, 25):
        raise ValueError(f"invalid status payload length {len(payload)}")
    node_type = payload[0]
    node_number = payload[1]
    level = payload[2]
    parent_mac = payload[3:9]
    self_mac = payload[9:15]
    rssi = struct.unpack(">b", payload[15:16])[0]
    acc_model = payload[16] if len(payload) >= 18 else 0
    daq_mode = payload[17] if len(payload) >= 18 else 0
    daq_on = payload[18] if len(payload) >= 19 else 0
    stream_status = payload[19] if len(payload) >= 20 else 0
    bat_vol = None
    if len(payload) >= 24:
        bat_vol = struct.unpack(">f", payload[20:24])[0]
    time_source = payload[24] if len(payload) >= 25 else int(TimeSource.GNSS)
    return StatusReport(
        node_type=node_type,
        node_number=node_number,
        level=level,
        parent_mac=parent_mac,
        self_mac=self_mac,
        rssi=rssi,
        acc_model=acc_model,
        daq_mode=daq_mode,
        daq_on=daq_on,
        stream_status=stream_status,
        bat_vol=bat_vol,
        time_source=time_source,
    )


def parse_sd_chunk(payload: bytes) -> SdStreamChunk:
    if len(payload) < 12:
        raise ValueError(f"invalid sd chunk payload length {len(payload)}")
    node_type = payload[0]
    node_number = payload[1]
    file_time = struct.unpack(">I", payload[2:6])[0]
    offset = struct.unpack(">I", payload[6:10])[0]
    size = struct.unpack(">H", payload[10:12])[0]
    if len(payload) < 12 + size:
        raise ValueError("sd chunk length mismatch")
    data = payload[12 : 12 + size]
    return SdStreamChunk(
        node_type=node_type,
        node_number=node_number,
        file_time=file_time,
        offset=offset,
        data=data,
    )


def parse_sd_done(payload: bytes) -> SdStreamDone:
    if len(payload) != 7:
        raise ValueError(f"invalid sd done payload length {len(payload)}")
    node_type = payload[0]
    node_number = payload[1]
    file_time = struct.unpack(">I", payload[2:6])[0]
    status = payload[6]
    return SdStreamDone(
        node_type=node_type,
        node_number=node_number,
        file_time=file_time,
        status=status,
    )


def parse_gnss(payload: bytes) -> GnssReport:
    if len(payload) != 12:
        raise ValueError(f"invalid gnss payload length {len(payload)}")
    node_type = payload[0]
    node_number = payload[1]
    latitude, longitude = struct.unpack(">ff", payload[2:10])
    fix_mode = payload[10]
    valid = payload[11]
    return GnssReport(
        node_type=node_type,
        node_number=node_number,
        latitude=latitude,
        longitude=longitude,
        fix_mode=fix_mode,
        valid=valid,
    )


_ACC_SAMPLE_STRUCT = struct.Struct(">Qfff")
_PPS_STRUCT = struct.Struct(">Qq")


def build_acc_batch(node_type: int, node_number: int, samples: list[AccSample]) -> bytes:
    if len(samples) > 255:
        raise ValueError("too many samples")
    payload = bytearray()
    payload.extend(bytes([node_type, node_number, len(samples)]))
    for sample in samples:
        payload.extend(_ACC_SAMPLE_STRUCT.pack(sample.cc, sample.ax, sample.ay, sample.az))
    return pack_frame(MsgType.DATA, bytes(payload))


def parse_acc_batch(payload: bytes) -> AccBatch:
    if len(payload) < 3:
        raise ValueError("invalid data payload length")
    node_type = payload[0]
    node_number = payload[1]
    count = payload[2]
    expected = 3 + count * _ACC_SAMPLE_STRUCT.size
    if len(payload) != expected:
        raise ValueError(f"invalid data payload length {len(payload)}")
    samples: list[AccSample] = []
    offset = 3
    for _ in range(count):
        cc, ax, ay, az = _ACC_SAMPLE_STRUCT.unpack_from(payload, offset)
        samples.append(AccSample(cc=cc, ax=ax, ay=ay, az=az))
        offset += _ACC_SAMPLE_STRUCT.size
    return AccBatch(node_type=node_type, node_number=node_number, samples=samples)


def build_pps(node_type: int, node_number: int, cc: int, epoch: int) -> bytes:
    payload = bytes([node_type, node_number]) + _PPS_STRUCT.pack(cc, epoch)
    return pack_frame(MsgType.PPS, payload)


def parse_pps(payload: bytes) -> PpsReport:
    if len(payload) != 18:
        raise ValueError(f"invalid PPS payload length {len(payload)}")
    node_type = payload[0]
    node_number = payload[1]
    cc, epoch = _PPS_STRUCT.unpack(payload[2:])
    return PpsReport(node_type=node_type, node_number=node_number, cc=cc, epoch=epoch)


def format_mac(mac: bytes) -> str:
    return ":".join(f"{b:02X}" for b in mac)


def build_set_mode(mode: Mode) -> bytes:
    return build_command(CommandId.SET_MODE, bytes([int(mode)]))


def build_start_daq() -> bytes:
    return build_command(CommandId.START_DAQ)


def build_stop_daq() -> bytes:
    return build_command(CommandId.STOP_DAQ)


def build_shutdown() -> bytes:
    return build_command(CommandId.SHUTDOWN)


def build_realtime_stream(toggle: Toggle) -> bytes:
    command_id = (
        CommandId.START_REALTIME_STREAM if toggle == Toggle.START else CommandId.STOP_REALTIME_STREAM
    )
    return build_command(command_id)
