#!/usr/local/bin/python3
# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version 4.2.1-0-g80c4cb6)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
import wx.grid

import gettext
_ = gettext.gettext

###########################################################################
## Class MyFrame1
###########################################################################

class MyFrame1 ( wx.Frame ):

    def __init__( self, parent ):
        wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = _(u"Wireless Sensor DAQ"), pos = wx.DefaultPosition, size = wx.Size( 1024,600 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )

        self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

        bSizer1 = wx.BoxSizer( wx.VERTICAL )

        bSizer2 = wx.BoxSizer( wx.HORIZONTAL )

        self.m_staticText2 = wx.StaticText( self, wx.ID_ANY, _(u"Sensor Nodes:"), wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticText2.Wrap( -1 )

        bSizer2.Add( self.m_staticText2, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        self.m_textCtrl2 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer2.Add( self.m_textCtrl2, 1, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        self.m_staticText3 = wx.StaticText( self, wx.ID_ANY, _(u"Fs="), wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticText3.Wrap( -1 )

        bSizer2.Add( self.m_staticText3, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        m_choice1Choices = [ _(u"62.5"), _(u"125") ]
        self.m_choice1 = wx.Choice( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, m_choice1Choices, 0 )
        self.m_choice1.SetSelection( 0 )
        bSizer2.Add( self.m_choice1, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        self.m_staticText4 = wx.StaticText( self, wx.ID_ANY, _(u"Hz"), wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticText4.Wrap( -1 )

        bSizer2.Add( self.m_staticText4, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        self.m_button1 = wx.Button( self, wx.ID_ANY, _(u"Start DAQ"), wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer2.Add( self.m_button1, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        self.m_button2 = wx.Button( self, wx.ID_ANY, _(u"Stop DAQ"), wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer2.Add( self.m_button2, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )


        bSizer1.Add( bSizer2, 0, wx.EXPAND, 5 )

        bSizer3 = wx.BoxSizer( wx.HORIZONTAL )

        bSizer4 = wx.BoxSizer( wx.VERTICAL )

        self.m_staticText21 = wx.StaticText( self, wx.ID_ANY, _(u"WiFi Mesh Status"), wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticText21.Wrap( -1 )

        bSizer4.Add( self.m_staticText21, 0, wx.ALL, 5 )

        self.m_grid2 = wx.grid.Grid( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0 )

        # Grid
        self.m_grid2.CreateGrid( 5, 6 )
        self.m_grid2.EnableEditing( True )
        self.m_grid2.EnableGridLines( True )
        self.m_grid2.EnableDragGridSize( True )
        self.m_grid2.SetMargins( 0, 0 )

        # Columns
        self.m_grid2.SetColSize( 0, 70 )
        self.m_grid2.SetColSize( 1, 100 )
        self.m_grid2.SetColSize( 2, 20 )
        self.m_grid2.SetColSize( 3, 40 )
        self.m_grid2.SetColSize( 4, 40 )
        self.m_grid2.SetColSize( 5, 45 )
        self.m_grid2.EnableDragColMove( False )
        self.m_grid2.EnableDragColSize( True )
        self.m_grid2.SetColLabelValue( 0, _(u"Node ID") )
        self.m_grid2.SetColLabelValue( 1, _(u"Status") )
        self.m_grid2.SetColLabelValue( 2, _(u"L") )
        self.m_grid2.SetColLabelValue( 3, _(u"RSSI") )
        self.m_grid2.SetColLabelValue( 4, _(u"PPS") )
        self.m_grid2.SetColLabelValue( 5, _(u"Data") )
        self.m_grid2.SetColLabelSize( wx.grid.GRID_AUTOSIZE )
        self.m_grid2.SetColLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

        # Rows
        self.m_grid2.EnableDragRowSize( True )
        self.m_grid2.SetRowLabelSize( wx.grid.GRID_AUTOSIZE )
        self.m_grid2.SetRowLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

        # Label Appearance

        # Cell Defaults
        self.m_grid2.SetDefaultCellAlignment( wx.ALIGN_LEFT, wx.ALIGN_TOP )
        bSizer4.Add( self.m_grid2, 1, wx.ALL|wx.EXPAND, 5 )


        bSizer3.Add( bSizer4, 0, wx.EXPAND, 5 )

        self.m_notebook2 = wx.Notebook( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_panel1 = wx.Panel( self.m_notebook2, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
        self.m_notebook2.AddPage( self.m_panel1, _(u"Time history plot"), True )
        self.m_panel2 = wx.Panel( self.m_notebook2, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
        self.m_notebook2.AddPage( self.m_panel2, _(u"PSD plot"), False )

        bSizer3.Add( self.m_notebook2, 1, wx.ALL|wx.EXPAND, 5 )


        bSizer1.Add( bSizer3, 1, wx.EXPAND, 5 )

        self.m_textCtrl21 = wx.TextCtrl( self, wx.ID_ANY, _(u"\"test line 1\ntest2 line|\""), wx.DefaultPosition, wx.Size( -1,100 ), 0 )
        bSizer1.Add( self.m_textCtrl21, 0, wx.ALL|wx.EXPAND, 5 )


        self.SetSizer( bSizer1 )
        self.Layout()

        self.Centre( wx.BOTH )

        # Connect Events
        self.m_textCtrl2.Bind( wx.EVT_TEXT, self.test )

    def __del__( self ):
        pass


    # Virtual event handlers, override them in your derived class
    def test( self, event ):
        event.Skip()

import wx
import wx.lib.agw.aui as aui
import wx.lib.mixins.inspection as wit
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
from matplotlib.backends.backend_wxagg import \
    NavigationToolbar2WxAgg as NavigationToolbar
from matplotlib.figure import Figure

class Plot(wx.Panel):
    def __init__(self, parent, id=-1, dpi=None, **kwargs):
        super().__init__(parent, id=id, **kwargs)
        self.figure = Figure(dpi=dpi, figsize=(2, 2))
        self.canvas = FigureCanvas(self, -1, self.figure)
        self.toolbar = NavigationToolbar(self.canvas)
        self.toolbar.Realize()

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.canvas, 1, wx.EXPAND)
        sizer.Add(self.toolbar, 0, wx.LEFT | wx.EXPAND)
        self.SetSizer(sizer)

class PlotNotebook(wx.Panel):
    def __init__(self, parent, id=-1):
        super().__init__(parent, id=id)
        self.nb = aui.AuiNotebook(self)
        sizer = wx.BoxSizer()
        sizer.Add(self.nb, 1, wx.EXPAND)
        self.SetSizer(sizer)

    def add(self, name="plot"):
        page = Plot(self.nb)
        self.nb.AddPage(page, name)
        return page.figure


import wx.grid as gridlib
import configparser
import os

CONFIG_FILE = 'config.ini'

def save_config(options):
    config = configparser.ConfigParser()

    config['Settings'] = {
        'option1': options['option1'],
        'option2': options['option2']
    }

    with open(CONFIG_FILE, 'w') as configfile:
        config.write(configfile)

def load_config():
    config = configparser.ConfigParser()

    if not os.path.exists(CONFIG_FILE):
        # Return default options if config file doesn't exist
        return {
            'option1': 'default_value1',
            'option2': 'default_value2'
        }

    config.read(CONFIG_FILE)
    options = {
        'option1': config.get('Settings', 'option1', fallback='default_value1'),
        'option2': config.get('Settings', 'option2', fallback='default_value2')
    }

    return options

app = wx.App() 
# window = wx.Frame(None, title = "wxPython Frame", size = (300,200)) 
frame1 = MyFrame1(None)


fig1 = Plot(frame1.m_panel1)
# plotter = PlotNotebook(frame1.m_notebook2)
axes1 = fig1.figure.add_subplot()
axes1.plot([1, 2, 3], [2, 1, 4])
fig2 = Plot(frame1.m_panel2)
axes2 = fig2.figure.add_subplot()
axes2.plot([1, 2, 3, 4, 5], [2, 1, 4, 2, 3])

canvas = FigureCanvas(frame1.m_panel1, -1, fig1.figure)
sizer = wx.BoxSizer(wx.VERTICAL)
sizer.Add(canvas, 1, wx.EXPAND)

# Set the sizer for the panel
frame1.m_panel1.SetSizer(sizer)

# Change the background color of cell (1, 1)
attr = gridlib.GridCellAttr()
attr.SetBackgroundColour(wx.Colour(255, 255, 0))  # Yellow
frame1.m_grid2.SetAttr(1, 1, attr)


frame1.Show(True) 
app.MainLoop()