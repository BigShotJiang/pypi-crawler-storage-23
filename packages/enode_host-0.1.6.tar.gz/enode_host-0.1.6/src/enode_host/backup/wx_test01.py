import wx

class MyFrame(wx.Frame):
    def __init__(self):
        super().__init__(None, title="Menu with Tick Marks", size=(300, 200))

        menuBar = wx.MenuBar()
        modeMenu = wx.Menu()

        self.mode_auto = modeMenu.AppendRadioItem(wx.ID_ANY, "Auto")
        self.mode_manual = modeMenu.AppendRadioItem(wx.ID_ANY, "Manual")
        self.mode_custom = modeMenu.AppendRadioItem(wx.ID_ANY, "Custom")

        menuBar.Append(modeMenu, "&Mode")
        self.SetMenuBar(menuBar)

        # Set default ticked item
        self.mode_auto.Check(True)

        # Bind events
        self.Bind(wx.EVT_MENU, self.on_select_mode, self.mode_auto)
        self.Bind(wx.EVT_MENU, self.on_select_mode, self.mode_manual)
        self.Bind(wx.EVT_MENU, self.on_select_mode, self.mode_custom)

    def on_select_mode(self, event):
        selected = "?"
        if self.mode_auto.IsChecked():
            selected = "Auto"
        elif self.mode_manual.IsChecked():
            selected = "Manual"
        elif self.mode_custom.IsChecked():
            selected = "Custom"

        wx.MessageBox(f"You selected: {selected}")

class MyApp(wx.App):
    def OnInit(self):
        frame = MyFrame()
        frame.Show()
        return True

app = MyApp(False)
app.MainLoop()
