# %%
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

import pandas as pd

df = pd.read_hdf("data/daq-2025_0305_1719", key="df")

def select_xrange(self):
    """
    Plots the current DataFrame (with datetime index),
    shows a vertical line following mouse movement (when zoom tool is NOT active),
    and captures two mouse clicks (when zoom tool is NOT active).
    Returns the subset of the DataFrame between those two clicked x-coordinates.
    """
    # Create the plot
    fig, ax = plt.subplots()
    self.plot(ax=ax)

    # Create an initial vertical line at the left edge of our data
    # We'll move it around inside the 'motion_notify_event'
    if len(self.index) == 0:
        print("DataFrame is empty. Returning as-is.")
        return self

    # We'll place the vertical line initially at the first index
    vline = ax.axvline(self.index[0], linestyle='--', color='gray')

    # We'll store the two click times here
    clicked_times = []

    def on_mouse_move(event):
        # Only move the line if we're NOT in "zoom rect" mode
        if fig.canvas.manager.toolbar.mode != 'zoom rect':
            if event.inaxes == ax and event.xdata is not None:
                # Move the vertical line to the current mouse x
                vline.set_xdata(event.xdata)
                fig.canvas.draw_idle()  # Redraw efficiently

    def on_click(event):
        # Only record the click if we're NOT in "zoom rect" mode
        if fig.canvas.manager.toolbar.mode != 'zoom rect':
            if event.inaxes == ax and event.xdata is not None:
                # Convert Matplotlib's float date to a Python datetime
                dt = mdates.num2date(event.xdata)
                clicked_times.append(dt)

                if len(clicked_times) == 2:
                    # We got two clicks—stop the event loop
                    fig.canvas.stop_event_loop()

    # Connect the callbacks
    cid_move = fig.canvas.mpl_connect("motion_notify_event", on_mouse_move)
    cid_click = fig.canvas.mpl_connect("button_press_event", on_click)

    # Show the plot (non‐blocking)
    plt.show(block=False)

    # Start an event loop that blocks until we have two clicks (or the figure is closed).
    fig.canvas.start_event_loop(timeout=-1)

    # Disconnect events and close the figure
    fig.canvas.mpl_disconnect(cid_move)
    fig.canvas.mpl_disconnect(cid_click)
    plt.close(fig)

    # If we didn't get two valid clicks, just return the original DataFrame
    if len(clicked_times) < 2:
        print("Not enough clicks were registered. Returning the original DataFrame.")
        return self

    # Sort the times so t0 < t1
    t0, t1 = sorted(clicked_times)

    # Slice the DataFrame by those two times (inclusive)
    return self.loc[t0 : t1]

# Monkey‐patch the DataFrame class so any DataFrame can call df.select_xrange()
pd.DataFrame.select_xrange = select_xrange


# ----------------------------------------------------------------------------
# Example usage:
if __name__ == "__main__":
    # Create a small example DataFrame with a DatetimeIndex
    # dates = pd.date_range("2023-01-01", periods=30, freq="D")
    # df = pd.DataFrame({"values": range(30)}, index=dates)
    df = pd.read_hdf("data/daq-2025_0305_1719", key="df")
    # Call our new method
    subset = df.select_xrange()
    print("Selected subset:\n", subset)
    