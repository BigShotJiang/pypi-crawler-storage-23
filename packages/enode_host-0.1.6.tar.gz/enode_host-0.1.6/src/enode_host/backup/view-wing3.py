#!/usr/local/bin/python3
# -*- coding: utf-8 -*-

#
# This is the file to construct GUI elements
#


###########################################################################
## Python code generated with wxFormBuilder (version 4.2.1-0-g80c4cb6)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
import wx.grid

import gettext
_ = gettext.gettext

import wx
import wx.lib.agw.aui as aui
import wx.lib.mixins.inspection as wit
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
from matplotlib.backends.backend_wxagg import \
    NavigationToolbar2WxAgg as NavigationToolbar
from matplotlib.figure import Figure
import wx.grid as gridlib
import queues
import datetime
from numpy import empty, where, array, delete, append, ones, nan, floor, shape
import random
import logging
import pandas as pd

logger = logging.getLogger(__name__)

class Plot(wx.Panel):
    def __init__(self, parent, id=-1, dpi=None, **kwargs):
        super().__init__(parent, id=id, **kwargs)
        self.figure = Figure(dpi=dpi, figsize=(2, 2))
        self.canvas = FigureCanvas(self, -1, self.figure)
        self.toolbar = NavigationToolbar(self.canvas)
        self.toolbar.Realize()

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.canvas, 1, wx.EXPAND)
        sizer.Add(self.toolbar, 0, wx.LEFT | wx.EXPAND)
        self.SetSizer(sizer)

class PandasTable(wx.grid.GridTableBase):
    def __init__(self, dataframe):
        wx.grid.GridTableBase.__init__(self)
        self.dataframe = dataframe

    def GetNumberRows(self):
        return self.dataframe.shape[0]

    def GetNumberCols(self):
        return self.dataframe.shape[1]

    def GetValue(self, row, col):
        # Fetch value from pandas DataFrame
        return str(self.dataframe.iat[row, col])

    def SetValue(self, row, col, value):
        # Set value in pandas DataFrame
        self.dataframe.iat[row, col] = value
        self.GetView().ForceRefresh()

    def GetColLabelValue(self, col):
        # Get column names from pandas DataFrame
        return str(self.dataframe.columns[col])

    def GetRowLabelValue(self, row):
        # Optional: Get row indices from pandas DataFrame
        return str(self.dataframe.index[row])

    def update_table(self):
        # msg = wx.grid.GridTableMessage(self, wx.grid.GRIDTABLE_NOTIFY_TABLE_RESET)
        msg = wx.grid.GridTableMessage(self, wx.grid.GRIDTABLE_NOTIFY_ROWS_APPENDED)
        self.GetView().ProcessTableMessage(msg)

    
###########################################################################
## Class View
###########################################################################

class View(wx.Frame):

    def __init__(self, parent):

        wx.Frame.__init__ ( self, None, id = wx.ID_ANY, title = _(u"Wireless Sensor DAQ"), pos = wx.DefaultPosition, size = wx.Size( 1024,600 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )

        self.controller = parent
        self.model = self.controller.model
        self.m_table = None
        self.timehistory_lines = {}
        self.psd_lines = {}
        self.PPS_outdate_check = True 
        self.channel_selection = [False, True, False]
        self.timespan_length = 30 # seconds

        self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

        bSizer1 = wx.BoxSizer( wx.VERTICAL )
        bSizer2 = wx.BoxSizer( wx.HORIZONTAL )

        self.m_staticText2 = wx.StaticText( self, wx.ID_ANY, _(u"Sensor Nodes:"), wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticText2.Wrap(-1)
        bSizer2.Add( self.m_staticText2, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        self.m_textCtrl2 = wx.TextCtrl( self, wx.ID_ANY, self.controller.model.options['node_nums_txt'], wx.DefaultPosition, wx.DefaultSize, 0)        
        bSizer2.Add( self.m_textCtrl2, 1, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        # # Fs selection
        # self.m_staticText3 = wx.StaticText( self, wx.ID_ANY, _(u"Fs="), wx.DefaultPosition, wx.DefaultSize, 0 )
        # self.m_staticText3.Wrap(-1)
        # bSizer2.Add( self.m_staticText3, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        # m_choice1Choices = [ _(u"62.5"), _(u"125") ]
        # self.m_choice1 = wx.Choice( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, m_choice1Choices, 0 )
        # self.m_choice1.SetSelection( 0 )
        # bSizer2.Add( self.m_choice1, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )
        
        # self.m_staticText4 = wx.StaticText( self, wx.ID_ANY, _(u"Hz"), wx.DefaultPosition, wx.DefaultSize, 0 )
        # self.m_staticText4.Wrap(-1)
        # bSizer2.Add( self.m_staticText4, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        # Operation Mode Choice

        self.m_staticText4 = wx.StaticText( self, wx.ID_ANY, _(u"Operation Mode :"), wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticText4.Wrap(-1)
        bSizer2.Add( self.m_staticText4, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        self.m_choice_OperationMode = wx.Choice(self, choices=["Online DAQ", "Standalone - Data Peeking", "Post-DAQ Data Stream", "Maintenance"])
        bSizer2.Add(self.m_choice_OperationMode, 0, wx.ALL | wx.CENTER, 5)
        self.m_choice_OperationMode.SetStringSelection("Online DAQ")

        # Start Button
        self.m_button1 = wx.Button( self, wx.ID_ANY, _(u"Start"), wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer2.Add(self.m_button1, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        # Stop Button
        self.m_button2 = wx.Button( self, wx.ID_ANY, _(u"Stop"), wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer2.Add(self.m_button2, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5 )

        
        bSizer1.Add(bSizer2, 0, wx.EXPAND, 5 )

        bSizer3 = wx.BoxSizer( wx.HORIZONTAL )
        bSizer4 = wx.BoxSizer( wx.VERTICAL )

        self.m_staticText21 = wx.StaticText( self, wx.ID_ANY, _(u"WiFi Mesh Status"), wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticText21.Wrap(-1)

        bSizer4.Add( self.m_staticText21, 0, wx.ALL, 5 )

        self.m_grid2 = wx.grid.Grid( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0 )
        self.mesh_status_data_view()
        
        # Grid
        self.nrows = len(self.controller.model.node_nums)
        # self.m_grid2.CreateGrid(self.nrows, 6)
        # self.m_grid2.EnableEditing( True )
        # self.m_grid2.EnableGridLines( True )
        # self.m_grid2.EnableDragGridSize( True )
        # self.m_grid2.SetMargins( 0, 0 )

        # self.m_grid2.SetColSize( 3, 40 )
        # self.m_grid2.SetColSize( 4, 40 )
        # self.m_grid2.SetColSize( 5, 45 )
        # self.m_grid2.EnableDragColMove( False )
        # self.m_grid2.EnableDragColSize( True )
        # self.m_grid2.SetColLabelValue( 0, _(u"Node ID") )
        # self.m_grid2.SetColLabelValue( 1, _(u"Status") )
        # self.m_grid2.SetColLabelValue( 2, _(u"L") )
        # self.m_grid2.SetColLabelValue( 3, _(u"RSSI") )
        # self.m_grid2.SetColLabelValue( 4, _(u"PPS") )
        # self.m_grid2.SetColLabelValue( 5, _(u"Data") )
        # self.m_grid2.SetColLabelSize( wx.grid.GRID_AUTOSIZE )
        # self.m_grid2.SetColLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

        # # Rows
        # self.m_grid2.EnableDragRowSize( True )
        self.m_grid2.SetRowLabelSize( wx.grid.GRID_AUTOSIZE )
        # self.m_grid2.SetRowLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

        # # Label Appearance

        # # Cell Defaults
        self.m_grid2.SetDefaultCellAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER)
        # self.m_grid2.AutoSizeColumns()
        bSizer4.Add( self.m_grid2, 1, wx.ALL|wx.EXPAND, 5 )

        bSizer3.Add( bSizer4, 0, wx.EXPAND, 5 )

        self.m_notebook2 = wx.Notebook( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_panel1 = wx.Panel( self.m_notebook2, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
        self.m_notebook2.AddPage( self.m_panel1, _(u"Time history plot"), True )
        self.m_panel2 = wx.Panel( self.m_notebook2, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
        self.m_notebook2.AddPage( self.m_panel2, _(u"PSD plot"), False )

        bSizer3.Add( self.m_notebook2, 1, wx.ALL|wx.EXPAND, 5 )

        bSizer1.Add( bSizer3, 1, wx.EXPAND, 5 )

        self.m_textCtrl21 = wx.TextCtrl( self, wx.ID_ANY, _(u"status reporting panel"), wx.DefaultPosition, wx.Size( -1,100 ), wx.TE_MULTILINE )
        bSizer1.Add( self.m_textCtrl21, 0, wx.ALL|wx.EXPAND, 5 )


        self.SetSizer( bSizer1 )
        self.Layout()

        
        # MENU
        self.m_statusBar1 = self.CreateStatusBar(1, wx.STB_SIZEGRIP, wx.ID_ANY)
        self.m_menubar = wx.MenuBar(0)
        self.m_menu_file = wx.Menu()
        self.m_menu_file_open = wx.MenuItem(self.m_menu_file, wx.ID_ANY, _(u"&Open"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_file_save = wx.MenuItem(self.m_menu_file, wx.ID_ANY, _(u"&Save"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_file_quit = wx.MenuItem(self.m_menu_file, wx.ID_ANY, _(u"&Quit"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_file.Append(self.m_menu_file_open)
        self.m_menu_file.Append(self.m_menu_file_save)
        self.m_menu_file.AppendSeparator()
        self.m_menu_file.Append(self.m_menu_file_quit)
        self.m_menubar.Append(self.m_menu_file, _(u"&File"))

        self.m_menu_data = wx.Menu()
        self.m_menu_data_export = wx.MenuItem(self.m_menu_file, wx.ID_ANY, _(u"&Export"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_data.Append(self.m_menu_data_export)
        self.m_menubar.Append(self.m_menu_data, _(u"&Data"))

        self.m_menu_cmd = wx.Menu()
        self.m_menu_cmd_sdclear = wx.MenuItem(self.m_menu_cmd, wx.ID_ANY, _(u"SD &Clear"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_cmd.Append(self.m_menu_cmd_sdclear)
        self.m_menu_cmd_shutdown = wx.MenuItem(self.m_menu_cmd, wx.ID_ANY, _(u"&Shutdown"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_cmd.Append(self.m_menu_cmd_shutdown)
        self.m_menubar.Append(self.m_menu_cmd, _(u"&CMD"))


        self.m_menu_view = wx.Menu()
        self.m_menu_view_clf = wx.MenuItem(self.m_menu_view, wx.ID_ANY, _(u"&Clear Figure"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_view.Append(self.m_menu_view_clf)

        self.m_menu_view_chsel = wx.Menu()
        self.m_menu_view_chsel_x = self.m_menu_view_chsel.AppendCheckItem(wx.ID_ANY, "X")
        self.m_menu_view_chsel_y = self.m_menu_view_chsel.AppendCheckItem(wx.ID_ANY, "Y")
        self.m_menu_view_chsel_z = self.m_menu_view_chsel.AppendCheckItem(wx.ID_ANY, "Z")
        self.m_menu_view_chsel_y.Check(True)
        self.m_menu_view.AppendSubMenu(self.m_menu_view_chsel, "Channel Selection")
        self.Bind(wx.EVT_MENU, self.onChannelToggled, self.m_menu_view_chsel_x)
        self.Bind(wx.EVT_MENU, self.onChannelToggled, self.m_menu_view_chsel_y)
        self.Bind(wx.EVT_MENU, self.onChannelToggled, self.m_menu_view_chsel_z)
        

        self.m_menu_view_timespan = wx.Menu()
        self.m_menu_view_timespan_radio_30s = self.m_menu_view_timespan.AppendRadioItem(wx.ID_ANY, "30 sec")
        self.m_menu_view_timespan_radio_20s = self.m_menu_view_timespan.AppendRadioItem(wx.ID_ANY, "20 sec")
        self.m_menu_view_timespan_radio_10s = self.m_menu_view_timespan.AppendRadioItem(wx.ID_ANY, "10 sec")
        self.m_menu_view_timespan_radio_05s = self.m_menu_view_timespan.AppendRadioItem(wx.ID_ANY, "5 sec")
        self.m_menu_view_timespan_radio_02s = self.m_menu_view_timespan.AppendRadioItem(wx.ID_ANY, "2 sec")
        self.m_menu_view_timespan_radio_30s.Check(True)
        self.m_menu_view.AppendSubMenu(self.m_menu_view_timespan, "Timespan Select")
        self.Bind(wx.EVT_MENU, self.onTimeSpanChange, self.m_menu_view_timespan_radio_30s)
        self.Bind(wx.EVT_MENU, self.onTimeSpanChange, self.m_menu_view_timespan_radio_20s)
        self.Bind(wx.EVT_MENU, self.onTimeSpanChange, self.m_menu_view_timespan_radio_10s)
        self.Bind(wx.EVT_MENU, self.onTimeSpanChange, self.m_menu_view_timespan_radio_05s)
        self.Bind(wx.EVT_MENU, self.onTimeSpanChange, self.m_menu_view_timespan_radio_02s)


        self.m_menubar.Append(self.m_menu_view, _(u"&View"))

        self.m_menu_help = wx.Menu()
        self.m_menu_help_about = wx.MenuItem(self.m_menu_help, wx.ID_ANY, _(u"&Help"), wx.EmptyString, wx.ITEM_NORMAL)
        self.m_menu_help.Append(self.m_menu_help_about)
        self.m_menubar.Append(self.m_menu_help, _(u"&Help"))

        self.SetMenuBar(self.m_menubar) 
        self.Centre( wx.BOTH )

        # FIGURE PANEL

        self.m_fig1 = Plot(self.m_panel1)
        self.axes1 = self.m_fig1.figure.add_subplot()
        self.m_fig2 = Plot(self.m_panel2)
        self.axes2 = self.m_fig2.figure.add_subplot()
        self.init_plot()
        
        canvas1 = FigureCanvas(self.m_panel1, -1, self.m_fig1.figure)
        sizer1 = wx.BoxSizer(wx.VERTICAL)
        sizer1.Add(canvas1, 1, wx.EXPAND)
        
        canvas2 = FigureCanvas(self.m_panel2, -1, self.m_fig2.figure)
        sizer2 = wx.BoxSizer(wx.VERTICAL)
        sizer2.Add(canvas2, 1, wx.EXPAND)

        # Set the sizer for the panel1
        self.m_panel1.SetSizer(sizer1)
        self.m_panel2.SetSizer(sizer2)

        # UPDATE TIMER

        self.timer = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self.gui_update, self.timer)
        self.timer.Start(1000)


        self.timespan_map = {
            self.m_menu_view_timespan_radio_30s.GetId(): 30,
            self.m_menu_view_timespan_radio_20s.GetId(): 20,
            self.m_menu_view_timespan_radio_10s.GetId(): 10,
            self.m_menu_view_timespan_radio_05s.GetId(): 5,
            self.m_menu_view_timespan_radio_02s.GetId(): 2,
        }

    def mesh_status_data_view(self):

        self.m_table = PandasTable(self.controller.model.mesh_status_data)
        self.m_grid2.SetTable(self.m_table, takeOwnership=True)
        # Columns
        self.m_grid2.SetColSize( 0, 70 )  # Node ID
        self.m_grid2.SetColSize( 1, 100 ) # Status
        self.m_grid2.SetColSize( 2, 20 )  # L
        self.m_grid2.SetColSize( 3, 70 )  # Parent
        self.m_grid2.SetColSize( 4, 40 )  # RSSI
        self.m_grid2.SetColSize( 5, 70 )  # Children
        self.m_grid2.SetColSize( 6, 40 )  # PPS
        self.m_grid2.SetColSize( 7, 50 )   # CMD
        self.m_grid2.SetColSize( 8, 0 )   # PPS-time
        self.m_grid2.SetColSize( 9, 0 )   # Parent's MAC
        self.m_grid2.SetColSize(10, 0 )   # Self MAC
        self.m_grid2.SetColSize(11, 0 )   # Conn Report Time
        self.m_grid2.SetColSize(12, 0 )   # inode
        
    def __del__( self ):
        pass

    # Virtual event handlers, override them in your derived class
    def test( self, event ):
        event.Skip()

    # def init_plot(self, parent, id=-1, dpi=None, **kwargs):
    #     wx.Panel.__init__(parent)
    #     self.figure = Figure(dpi=dpi, figsize=(2, 2))
    #     self.canvas = FigureCanvas(self, -1, self.figure)
    #     self.toolbar = NavigationToolbar(self.canvas)
    #     self.toolbar.Realize()

    #     sizer = wx.BoxSizer(wx.VERTICAL)
    #     sizer.Add(self.canvas, 1, wx.EXPAND)
    #     sizer.Add(self.toolbar, 0, wx.LEFT | wx.EXPAND)
    #     self.SetSizer(sizer)

    #     return self.figure

    def getTimeWindow(self, t1):
        Tspan = self.timespan_length
        r =    [datetime.datetime.fromtimestamp(floor(t1.timestamp() / Tspan) * Tspan), 
                datetime.datetime.fromtimestamp(floor(t1.timestamp() / Tspan + 1) * Tspan)]
        # logger.info("{}, {}".format(r[0], r[1]))
        return r
                
    def init_plot(self):

        self.axes1.cla()
        for index, row in self.model.mesh_status_data.iterrows():
            for idx, ch in enumerate(['X', 'Y', 'Z']):
                if self.channel_selection[idx]:
                    NodeID_CH = row['Node ID'] + ch 
                    self.timehistory_lines[NodeID_CH] = self.axes1.plot([], [], label=NodeID_CH)[0]
        self.axes1.set_xlabel('Time')
        self.axes1.set_ylabel('Acceleration (g)')
        self.axes1.grid(True)
        self.axes1.set_ylim(-2, 2)
        self.axes1.legend()
        
        self.axes2.cla()
        for index, row in self.model.mesh_status_data.iterrows():
            for idx, ch in enumerate(['X', 'Y', 'Z']):
                if self.channel_selection[idx]:
                    NodeID_CH = row['Node ID'] + ch 
                    self.psd_lines[NodeID_CH] = self.axes2.semilogy([], [], label=NodeID_CH)[0]
        
        self.axes2.set_xlabel('Frequency (Hz)')
        self.axes2.set_ylabel('ASD (g/sq(Hz))')
        self.axes2.grid(True)
        self.axes2.set_ylim(1e-6, 1e1)
        self.axes2.set_xlim(0, 25)
        self.axes2.legend()
        
    def status_table_update(self):
                        
        t_now = datetime.datetime.now()
        for index, row in self.model.mesh_status_data.iterrows():
            if row['Connection'] == 'disconnected':
                attr = gridlib.GridCellAttr()
                attr.SetBackgroundColour(wx.Colour(255, 0, 0))  # light Red
                self.m_grid2.SetAttr(index, 1, attr)
            else:
                attr = gridlib.GridCellAttr()
                attr.SetBackgroundColour(wx.Colour(255, 255, 255))  # light Red
                self.m_grid2.SetAttr(index, 1, attr)
            
            if isinstance(row['PPS-time'], datetime.datetime) and self.PPS_outdate_check:
                dt = t_now - row['PPS-time']
                if dt.seconds > 10:
                    attr = gridlib.GridCellAttr()
                    attr.SetBackgroundColour(wx.Colour(255, 0, 0))  # light Red
                    self.m_grid2.SetAttr(index, 6, attr)
                else:
                    attr = gridlib.GridCellAttr()
                    attr.SetBackgroundColour(wx.Colour(255, 255, 255))  # light Red
                    self.m_grid2.SetAttr(index, 6, attr)
            
            if row['Connection'] == 'connected' and not isinstance(row['PPS-time'], datetime.datetime):
                attr = gridlib.GridCellAttr()
                attr.SetBackgroundColour(wx.Colour(255, 0, 0))  # light Red
                self.m_grid2.SetAttr(index, 6, attr)

    def table_update(self):

        self.m_grid2.ForceRefresh()
        self.status_table_update()

    def figure_update(self):

        for index, row in self.model.mesh_status_data.iterrows():
            nodeID = row['nodeID']                
            for idx, ch in enumerate(['X', 'Y', 'Z']):
                NodeID_CH = row['Node ID'] + ch 
                if NodeID_CH in self.timehistory_lines.keys() and nodeID in self.model.timehistory_xdata.keys():
                    with self.model.plot_mutex[nodeID]:
                        if len(self.model.timehistory_xdata[nodeID]) > 1:
                            self.timehistory_lines[NodeID_CH].set_xdata(self.model.timehistory_xdata[nodeID])
                            self.timehistory_lines[NodeID_CH].set_ydata(self.model.timehistory_ydata[nodeID][:, idx])
        if self.model.timehistory_xlim:
            self.axes1.set_xlim(self.model.timehistory_xlim)
        try:
            # for nodeID in self.timehistory_lines:
            #     logger.info('draw(): {} / {} / {}'.format(nodeID, shape(self.timehistory_lines[nodeID].get_xdata()), shape(self.timehistory_lines[nodeID].get_ydata())))
            self.m_fig1.figure.canvas.draw()
            # for nodeID in self.timehistory_lines:
            #     logger.info('draw(): {} / {} / {}'.format(nodeID, shape(self.timehistory_lines[nodeID].get_xdata()), shape(self.timehistory_lines[nodeID].get_ydata())))
        except:
            # pass
            raise
        
        for index, row in self.model.mesh_status_data.iterrows():
            nodeID = row['nodeID']
            for idx, ch in enumerate(['X', 'Y', 'Z']):
                NodeID_CH = row['Node ID'] + ch
                if NodeID_CH in self.psd_lines.keys() and nodeID in self.model.psd_ydata.keys():
                    with self.model.plot_mutex[nodeID]:
                        self.psd_lines[NodeID_CH].set_xdata(self.model.psd_xdata)
                        self.psd_lines[NodeID_CH].set_ydata(self.model.psd_ydata[nodeID][:, idx])

        if len(self.model.psd_xdata) > 0:
            self.axes2.set_xlim(0, round(self.model.psd_xdata[-1]))
        try:
            self.m_fig2.figure.canvas.draw()
        except:
            # pass
            raise

        # self.m_fig2.figure.canvas.draw()

    def gui_update(self, event):
        
        self.table_update()
        self.figure_update()


    def onChannelToggled(self, event):
                
        self.channel_selection = [
            self.m_menu_view_chsel_x.IsChecked(),
            self.m_menu_view_chsel_y.IsChecked(),
            self.m_menu_view_chsel_z.IsChecked()
        ]
        
        self.init_plot()

    def onTimeSpanChange(self, event):

        ts = self.timespan_map.get(event.GetId(), None)
        if ts:
            logger.info(f"Timespan selected: {ts} sec")
            self.timespan_length = ts
        
        

