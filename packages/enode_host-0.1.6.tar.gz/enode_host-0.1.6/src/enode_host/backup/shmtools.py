import pandas as pd
from matplotlib.pyplot import *
from numpy import *
import matplotlib.dates as mdates



def detrend(self):
    return self - self.mean()


def subset(self):
    if hasattr(self, 't0') and hasattr(self, 't1'):
        mask = (self.index >= self.t0.replace(tzinfo=None)) & (self.index < self.t1.replace(tzinfo=None))
        return self.loc[mask, :]
    else:
        raise Exception('t0 or t1 doesn''t exist')


# _orig_plot = pd.DataFrame.plot

# def custom_plot(self, *args, **kwargs):
#     if "figsize" not in kwargs:
#         kwargs["figsize"] = (8, 4)
#     elif "grid" not in kwargs:
#         kwargs['grid'] = True
    
#     # Call the original plot method
#     return _orig_plot(self)(*args, **kwargs)

# pd.DataFrame.plot = custom_plot

def select(self):
    fig, ax = subplots()
    self.plot(ax=ax)
    toolbar = fig.canvas.manager.toolbar

    vline = ax.axvline(nan, linestyle="--")

    def on_mouse_move(event):
        if len(toolbar.mode) > 0:
            vline.set_xdata(nan)
        elif event.inaxes == ax and event.xdata is not None:
            vline.set_xdata(event.xdata)
            fig.canvas.draw_idle()  # efficient redraw

    def onclick(event):
        nonlocal self
        # event.xdata and event.ydata give the mouse click in data coordinates
        # print("toolbar.mode", toolbar.mode, ' ', len(toolbar.mode))
        if len(toolbar.mode) == 0:
            if event.button == 1:
                t0 = mdates.num2date(event.xdata)
                self.t0 = t0
                print("x =", event.xdata, ", y =", event.ydata)
            if event.button == 3:
                t1 = mdates.num2date(event.xdata)
                self.t1 = t1
                print("x =", event.xdata, ", y =", event.ydata)
                close()

    # Connect the event to the figure
    fig.canvas.mpl_connect("motion_notify_event", on_mouse_move)
    fig.canvas.mpl_connect('button_press_event', onclick)
    show()

pd.DataFrame.detrend = detrend
pd.DataFrame.select = select
pd.DataFrame.subset = subset

