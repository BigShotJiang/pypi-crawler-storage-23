import wx

class ChoiceExample(wx.Frame):
    def __init__(self, parent, title):
        super(ChoiceExample, self).__init__(parent, title=title, size=(300, 200))
        
        panel = wx.Panel(self)
        sizer = wx.BoxSizer(wx.VERTICAL)
        
        # Create a label
        label = wx.StaticText(panel, label="Pick an option:")
        sizer.Add(label, 0, wx.ALL | wx.CENTER, 10)
        
        # Create a wx.Choice control with a list of strings
        self.choice = wx.Choice(panel, choices=["Option 1", "Option 2", "Option 3"])
        sizer.Add(self.choice, 0, wx.ALL | wx.CENTER, 5)
        
        # Bind the choice selection event
        self.choice.Bind(wx.EVT_CHOICE, self.on_choice)
        
        # Create a label to display the selected item
        self.display_label = wx.StaticText(panel, label="")
        sizer.Add(self.display_label, 0, wx.ALL | wx.CENTER, 10)
        
        panel.SetSizer(sizer)
        self.Centre()
        self.Show()
    
    def on_choice(self, event):
        """
        Event handler for a selection from the wx.Choice control.
        """
        # Get the string corresponding to the selected item
        selection = self.choice.GetString(self.choice.GetSelection())
        print(self.choice.GetSelection())
        
        # Update the display label
        self.display_label.SetLabel(f"Selected: {selection}")
        

class MyApp(wx.App):
    def OnInit(self):
        frame = ChoiceExample(None, title="wx.Choice Example")
        frame.Show()
        return True

if __name__ == "__main__":
    app = MyApp(False)
    app.MainLoop()
