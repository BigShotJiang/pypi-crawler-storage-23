#!/usr/local/bin/python3

#----------------------------------------------
# HOW TO USE THE SYSTEM
#
# 1. please execute this file first, so that the server is ready to receive data from ndoes
# 2. turn on the node(s)
#    - the PPS LED on the display can be believed
#    - please don't believe RSSI, Lv, BAT %, as they are not completed yet.
# 3. Files are saved under data2 folder in HDF 
# 4. Please read example.ipynb for how to load data file and display it
#    - Please notice the time is in UTC to avoid any issues regarding British Summer Time
# 5. For time-sync, never reset the acc node, but power-cycle it. 
#    - there are two buttons on the sensor node: 
#      - one for power next to the USB-c port
#      - the other for reset next to the SD slot
#    - pressing the pwr button for 5 sec will shutdown the node, and pressing it for 1 sec will start the node


import logging
import gui
import mesh
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QColor
import threading
import queues
from numpy import array
import shm_sigproc
import glob
import os 

from matplotlib.pyplot import *



os.makedirs("log", exist_ok = True)
os.makedirs("data", exist_ok = True)
os.makedirs("data2", exist_ok = True)


logging.basicConfig(level=logging.INFO,  # Set the minimum log level
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    handlers=[logging.FileHandler('log/my_log_file.log'), logging.StreamHandler()])
logger = logging.getLogger(__name__)


df = []
psd = []


def begin():

    mesh.begin()
    shm_sigproc.begin()

    app = QtWidgets.QApplication(sys.argv)
    window = gui.MainWindow()    
    app.exec_()



def export():

    global df

    raw_data_dir = 'data2'

    node_IDs = []
    
    import os 
    import pandas as pd


    entries = os.listdir(raw_data_dir)
    files = [f for f in entries if f.endswith('.hd5')]

    # IDENTIFY NODE IDs
    for file in files:
        node_IDs.append(file.split('-')[0])
    node_IDs = sorted(set(node_IDs))

    # READ AND MERGE ALL RAW DATA FILES
    dfs = []
    for node_ID in node_IDs:
        dfs_ = []
        files_ = [f for f in entries if f.endswith('.hd5') and f.startswith(node_ID)]
        for file_ in files_:
            dfs_.append(pd.read_hdf(os.path.join(raw_data_dir, file_)))
        df_ = pd.concat(dfs_, axis = 0)
        df_ = df_.rename(columns={
                                'X': '{}-X'.format(node_ID),
                                'Y': '{}-Y'.format(node_ID),
                                'Z': '{}-Z'.format(node_ID)
                                                })
        dfs.append(df_)

    df = pd.concat(dfs, axis = 1)
    df = df.dropna()
    df.plot(figsize=(24, 6))
    show()

    filename = "data/daq-{}".format(df.index[0].strftime("%Y_%m%d_%H%M"))
    df.to_hdf(filename, key="df")

    

def clear():
    # DELETE TEMPORARIL FILES
    for file in glob.glob("data2/*.hd5"):
        try:
            os.remove(file)
        except Exception as e:
            logger.error(f"Error deleting file {file}: {e}")



if __name__ == '__main__':
    begin()

# thread = threading.Thread(target = main)
# thread.start()
# logger.info("mesh_server started.")

# grid_time = int(datetime.datetime.now().timestamp()/config.TIME_WINDOW_LENGTH_SEC) * config.TIME_WINDOW_LENGTH_SEC

# timeWindow = [datetime.datetime.fromtimestamp(grid_time),
#               datetime.datetime.fromtimestamp(grid_time + config.TIME_WINDOW_LENGTH_SEC)]
# tdata = thp_lines[nodeID-1].get_xdata()
# ydata = thp_lines[nodeID-1].get_ydata()
# idx = where(array(tdata) < timeWindow[0])
# tdata = delete(tdata, idx[0])
# ydata = delete(ydata, idx[0], 0)
# tdata = append(tdata, t)
# ydata = append(ydata, y)
# thp_lines[nodeID - 1].set_xdata(tdata)
# thp_lines[nodeID - 1].set_ydata(ydata)
# sc = window.m_ui.listView
# sc.axes[0].set_xlim(timeWindow[0], timeWindow[1])
# sc.axes[0].xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
# draw()
# # pause(0.05)
# # show(block = False)
# logger.info("len(tdata) = {}".format(len(tdata)))


# for t, y_ in zip(t, y):
#     logger.info("{}, {}, {}, {}".format(t, y_[0], y_[1], y_[2]))

# time.sleep(0.1)
      
