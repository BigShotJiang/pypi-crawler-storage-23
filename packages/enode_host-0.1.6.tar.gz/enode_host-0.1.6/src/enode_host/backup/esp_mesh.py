import socket
import time
import threading
import logging
import struct
import datetime
import getmac 
import os
from queue import Queue
import config
from scipy.interpolate import interp1d
from numpy import where, logical_and, empty, append, array, delete, floor
try:
    from . import queues
except ImportError:
    import queues


# CONFIGURATION
rawFileLength_sec = config.rawFileLength_sec
port = config.port
target_dir = config.target_dir 
from model import packet_size, ChannelType, CmdType

npackets = 63

logger = logging.getLogger(__name__)

class Esp_Mesh():

    def __init__(self, model):
        
        self.model = model
        self.sockets = {}

        thread = threading.Thread(target = self.mesh_svr_begin)
        thread.start()
        logger.info("mesh_server started.")

    def get_ip_address(self):

        try:
            # This will get the local IP address of your machine
            host_name = socket.gethostname()
            ip_address = socket.gethostbyname(host_name)
            return ip_address
        except socket.error as e: 
            print(f"Error: {e}")
            return None
        
    def handle_client(self, client_socket, ip_address):

        logger.info("handle_client called...")
        data = bytearray()
        nodeID = 0   
        # client_socket.settimeout(0)   
        is_socket_stored = False  
                
        while True:
            try:                     
                # Managing Sockets: store the handle for access from outside
                if True:
                    data += client_socket.recv(packet_size * npackets) 
                else:
                    data += client_socket.recv(packet_size * 1) 
                # Storing socket handler for access from outside
                if not is_socket_stored and len(data) >= packet_size:
                    packet = data[:packet_size]
                    rec = struct.unpack('>H', packet[:2])   # B = unsigned char (1byte), 
                                                            # H = unsigned short integer (2byte), 
                    nodeID = rec[0]  # consisting of nodeType (uint8_t) + nodeNUmber (uint8_t) 
                    logger.info('nodeID={}'.format(nodeID))
                    self.sockets[nodeID] = client_socket
                    is_socket_stored = True
                # forward the data to parser
                if is_socket_stored:
                    self.model.data_push(nodeID, data)
                    logger.debug('data_pushed {} bytes'.format(len(data)))
                    data.clear()
                #time.sleep(0.5)

            # except BlockingIOError:
            #     time.sleep(0.1)
            # except socket.timeout:
            #     time.sleep(0.1)
            except Exception as e:
                errnum = e.args[0]
                if errnum in [104, 113, 110] :
                    # 110: connection tiemout
                    # peer closed the connection, then svr closes it as well
                    break
                else:
                    raise
        # delete socket handle if disconnected
        del self.sockets[nodeID]
        logger.info("close()...")        
        client_socket.close()
        # queues.Mesh2GUI.put({'updateType': 1, 'nodeID': nodeID, 'connection': False})

    def mesh_svr_begin(self):

        # Create a socket object
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # print("recv buffer size = {}".format(server_socket.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)))    
        hostname = socket.gethostname()
        # if hostname in ['wing1a', 'wing3.lan']:
        #     host = self.get_ip_address()    
        # else:
        #     host = '192.168.1.104'
        host = '192.168.1.202'
        logger.info(f"ip address= {host}")

        while(True):
            try:
                server_socket.bind((host, port)) # Bind the socket to the host and port
                break
            except:
                print(".")
                time.sleep(1)
        server_socket.listen(20)    # Listen for incoming connections; The argument is the maximum number of queued connections
        logger.info(f"Server is listening on {host}:{port}")
        while True:
            logger.info("Waiting for a connection...")
            client_socket, client_address = server_socket.accept()
            logger.info(f"Accepted connection from {client_address}")
            # Start a new thread to handle the client
            client_handler = threading.Thread(target=self.handle_client, args=(client_socket, client_address,))
            client_handler.start()   

    def send_cmd(self, nodeID, cmd, data0 = 0, data1 = 0):
        
        msg = struct.pack('=BBBBB', cmd, data0, data1, 0, 0)
        logger.info('msg={}'.format(msg))
        self.sockets[nodeID].send(msg)

        
