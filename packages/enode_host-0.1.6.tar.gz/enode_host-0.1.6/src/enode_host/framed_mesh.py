import asyncio
import logging
import threading
from typing import Dict, Optional

from .async_socket import read_frame
from .protocol import (
    MsgType,
    build_command,
    format_mac,
    parse_acc_batch,
    parse_ack,
    parse_pps,
    parse_sd_chunk,
    parse_sd_done,
    parse_status,
    parse_gnss,
)

logger = logging.getLogger(__name__)


class FramedMesh:
    def __init__(self, model, host: str = "0.0.0.0", port: int = 3333):
        self.model = model
        self.host = host
        self.port = port
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.clients: Dict[str, asyncio.StreamWriter] = {}
        self._last_cmd: Dict[str, str] = {}
        self._sd_done_events: Dict[str, threading.Event] = {}
        self._sd_done_lock = threading.Lock()
        self._stat_lock = threading.Lock()
        self._data_frames = 0
        self._data_samples = 0
        self._pps_frames = 0
        self._last_stat = 0.0
        self.thread.start()

    def _run(self) -> None:
        asyncio.set_event_loop(self.loop)
        server = self.loop.run_until_complete(
            asyncio.start_server(self._handle_client, host=self.host, port=self.port)
        )
        addrs = ", ".join(str(sock.getsockname()) for sock in server.sockets or [])
        self._ui_log(f"[gui] framed server listening on {addrs}")
        try:
            self.loop.run_forever()
        finally:
            server.close()
            self.loop.run_until_complete(server.wait_closed())

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = writer.get_extra_info("peername")
        peer_id = f"{peer[0]}:{peer[1]}" if peer else "unknown"
        self._ui_log(f"[gui] connected {peer_id}")
        node_id: Optional[int] = None

        try:
            while True:
                msg_type, payload = await read_frame(reader)
                if msg_type == MsgType.STATUS:
                    status = parse_status(payload)
                    node_id = self.model.make_node_key(status.node_type, status.node_number)
                    self.clients[node_id] = writer
                    self._ui_log(f"[status] node={node_id} level={status.level} rssi={status.rssi}")
                    self.model.enqueue_conn_report(
                        nodeID=node_id,
                        level=status.level,
                        parent_mac=format_mac(status.parent_mac),
                        self_mac=format_mac(status.self_mac),
                        rssi=status.rssi,
                        acc_model=status.acc_model,
                        daq_mode=status.daq_mode,
                        daq_on=status.daq_on,
                        stream_status=status.stream_status,
                        bat_vol=status.bat_vol,
                        time_source=status.time_source,
                        notify=False,
                    )
                elif msg_type == MsgType.DATA:
                    batch = parse_acc_batch(payload)
                    node_id = self.model.make_node_key(batch.node_type, batch.node_number)
                    self.clients[node_id] = writer
                    with self._stat_lock:
                        self._data_frames += 1
                        self._data_samples += len(batch.samples)
                    self.model.record_rx_bytes(node_id, len(payload) + 3, kind="data")
                    self.model.enqueue_acc_batch(node_id, batch.samples)
                elif msg_type == MsgType.PPS:
                    try:
                        pps = parse_pps(payload)
                    except Exception as exc:
                        preview = payload[:12].hex()
                        logger.warning(
                            "[pps] parse failed len=%d head=%s err=%s", len(payload), preview, exc
                        )
                        continue
                    node_id = self.model.make_node_key(pps.node_type, pps.node_number)
                    self.clients[node_id] = writer
                    with self._stat_lock:
                        self._pps_frames += 1
                    self._ui_log(f"[pps] node={node_id} cc={pps.cc} epoch={pps.epoch}")
                    self.model.enqueue_pps(node_id, pps.cc, pps.epoch)
                elif msg_type == MsgType.SD_STREAM:
                    chunk = parse_sd_chunk(payload)
                    node_id = self.model.make_node_key(chunk.node_type, chunk.node_number)
                    self.model.record_rx_bytes(node_id, len(payload) + 3, kind="sd")
                    self.model.handle_sd_chunk(node_id, chunk.file_time, chunk.offset, chunk.data)
                elif msg_type == MsgType.SD_DONE:
                    done = parse_sd_done(payload)
                    node_id = self.model.make_node_key(done.node_type, done.node_number)
                    self.model.handle_sd_done(node_id, done.file_time, done.status)
                    if done.status == 1:
                        self._signal_sd_done(node_id)
                elif msg_type == MsgType.GNSS:
                    gnss = parse_gnss(payload)
                    node_id = self.model.make_node_key(gnss.node_type, gnss.node_number)
                    self.model.update_gnss_position(
                        node_id, gnss.latitude, gnss.longitude, gnss.fix_mode, gnss.valid
                    )
                elif msg_type == MsgType.ACK:
                    try:
                        ack = parse_ack(payload)
                    except Exception as exc:
                        self._ui_log(f"[ack] parse failed len={len(payload)} err={exc}")
                    else:
                        self._ui_log(
                            f"[ack] type=0x{ack.original_type:02X} status={ack.status} msg={ack.message}"
                        )
                        if node_id is not None:
                            label = self._last_cmd.get(node_id, "cmd")
                            msg = f"{label} ack:{ack.status}"
                            if ack.message:
                                msg = f"{msg} {ack.message}"
                            self.model._set_node_fields(node_id, **{"CMD": msg})
            await self._maybe_log_stats()
        except asyncio.IncompleteReadError:
            pass
        finally:
            if node_id is not None and self.clients.get(node_id) is writer:
                self.clients.pop(node_id, None)
            writer.close()
            await writer.wait_closed()
            self._ui_log(f"[gui] disconnected {peer_id}")

    async def _maybe_log_stats(self) -> None:
        now = self.loop.time()
        if self._last_stat == 0.0:
            self._last_stat = now
            return
        if now - self._last_stat < 1.0:
            return
        with self._stat_lock:
            data_frames = self._data_frames
            data_samples = self._data_samples
            pps_frames = self._pps_frames
            self._data_frames = 0
            self._data_samples = 0
            self._pps_frames = 0
        self._ui_log(f"[rate] data_frames/s={data_frames} samples/s={data_samples} pps/s={pps_frames}")
        self._last_stat = now

    def _ui_log(self, msg: str) -> None:
        ui_log = getattr(self.model, "ui_log", None)
        if callable(ui_log):
            ui_log(msg)
        else:
            logger.info("%s", msg)

    async def _send(self, writer: asyncio.StreamWriter, payload: bytes) -> None:
        writer.write(payload)
        await writer.drain()

    def send_command(self, node_id: str, command_payload: bytes, label: str = "cmd") -> bool:
        writer = self.clients.get(node_id)
        if writer is None:
            return False
        try:
            self._mark_cmd_sent(node_id, label)
            future = asyncio.run_coroutine_threadsafe(
                self._send(writer, command_payload), self.loop
            )
            future.result(timeout=2)
            return True
        except Exception:
            self.clients.pop(node_id, None)
            return False

    def _mark_cmd_sent(self, node_id: str, label: str) -> None:
        self._last_cmd[node_id] = label
        self.model._set_node_fields(node_id, **{"CMD": f"{label} sent"})

    def broadcast_command(self, command_payload: bytes, label: str = "cmd") -> int:
        sent = 0
        for node_id, writer in list(self.clients.items()):
            try:
                self._mark_cmd_sent(node_id, label)
                future = asyncio.run_coroutine_threadsafe(
                    self._send(writer, command_payload), self.loop
                )
                future.result(timeout=2)
                sent += 1
            except Exception:
                self.clients.pop(node_id, None)
        return sent

    def _get_sd_event(self, node_id: str) -> threading.Event:
        with self._sd_done_lock:
            ev = self._sd_done_events.get(node_id)
            if ev is None:
                ev = threading.Event()
                self._sd_done_events[node_id] = ev
            return ev

    def _signal_sd_done(self, node_id: str) -> None:
        ev = self._get_sd_event(node_id)
        ev.set()

    def stream_sd_sequential(self, command_payload: bytes, label: str = "sd_stream_start", timeout_s: float = 3600.0) -> None:
        node_ids = sorted(self.clients.keys())
        if not node_ids:
            self._ui_log("[sd] no connected nodes for sequential stream")
            return
        self._ui_log(f"[sd] sequential start for {len(node_ids)} nodes")
        for node_id in node_ids:
            ev = self._get_sd_event(node_id)
            ev.clear()
            ok = self.send_command(node_id, command_payload)
            if not ok:
                self._ui_log(f"[sd] send failed: {node_id}")
                self.model._set_node_fields(node_id, **{"CMD": "sd_stream send failed"})
                continue
            self._mark_cmd_sent(node_id, label)
            self._ui_log(f"[sd] streaming {node_id}")
            if ev.wait(timeout=timeout_s):
                self._ui_log(f"[sd] done {node_id}")
            else:
                self._ui_log(f"[sd] timeout {node_id}")
                self.model._set_node_fields(node_id, **{"CMD": "sd_stream timeout"})
        self._ui_log("[sd] sequential complete")

    @staticmethod
    def build_command_payload(command_id: int, payload: bytes = b"") -> bytes:
        return build_command(command_id, payload)
