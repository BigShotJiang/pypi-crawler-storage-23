import asyncio
import logging
import struct
from dataclasses import dataclass
from typing import Dict, Optional

from .protocol import (
    MsgType,
    build_ack,
    format_mac,
    parse_acc_batch,
    parse_pps,
    parse_sd_chunk,
    parse_sd_done,
    parse_status,
)

logger = logging.getLogger(__name__)


@dataclass
class SocketResponse:
    payload: bytes


async def send_message(host: str, port: int, payload: bytes, timeout: float = 5.0) -> SocketResponse:
    reader: asyncio.StreamReader
    writer: asyncio.StreamWriter

    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port), timeout=timeout
        )
    except asyncio.TimeoutError as exc:
        raise TimeoutError(f"Timed out connecting to {host}:{port}") from exc

    try:
        writer.write(payload)
        await writer.drain()
        data = await asyncio.wait_for(reader.read(4096), timeout=timeout)
        return SocketResponse(payload=data)
    finally:
        writer.close()
        await writer.wait_closed()


def run_client(host: str, port: int, message: str, timeout: float) -> int:
    payload = message.encode("utf-8")
    response = asyncio.run(send_message(host, port, payload, timeout))
    if response.payload:
        print(response.payload.decode("utf-8", errors="replace"))
    return 0


async def read_frame(reader: asyncio.StreamReader) -> Optional[tuple[int, bytes]]:
    header = await reader.readexactly(3)
    msg_type, length = struct.unpack(">BH", header)
    if length == 0:
        return msg_type, b""
    payload = await reader.readexactly(length)
    return msg_type, payload


async def handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, clients: Dict[str, asyncio.StreamWriter]) -> None:
    peer = writer.get_extra_info("peername")
    peer_id = f"{peer[0]}:{peer[1]}" if peer else "unknown"
    clients[peer_id] = writer
    logger.info("[server] connected %s (clients=%d)", peer_id, len(clients))

    try:
        while True:
            msg_type, payload = await read_frame(reader)
            if msg_type == MsgType.STATUS:
                status = parse_status(payload)
                logger.info(
                    "[status] node=%s:%s level=%s parent=%s self=%s rssi=%s",
                    status.node_type,
                    status.node_number,
                    status.level,
                    format_mac(status.parent_mac),
                    format_mac(status.self_mac),
                    status.rssi,
                )
                writer.write(build_ack(MsgType.STATUS, 0, "ok"))
                await writer.drain()
            elif msg_type == MsgType.DATA:
                batch = parse_acc_batch(payload)
                logger.info(
                    "[data] node=%s:%s samples=%d",
                    batch.node_type,
                    batch.node_number,
                    len(batch.samples),
                )
                writer.write(build_ack(MsgType.DATA, 0, "ok"))
                await writer.drain()
            elif msg_type == MsgType.PPS:
                pps = parse_pps(payload)
                logger.info(
                    "[pps] node=%s:%s cc=%s epoch=%s",
                    pps.node_type,
                    pps.node_number,
                    pps.cc,
                    pps.epoch,
                )
                writer.write(build_ack(MsgType.PPS, 0, "ok"))
                await writer.drain()
            elif msg_type == MsgType.SD_STREAM:
                chunk = parse_sd_chunk(payload)
                logger.info(
                    "[sd] node=%s:%s file_time=%s offset=%s size=%d",
                    chunk.node_type,
                    chunk.node_number,
                    chunk.file_time,
                    chunk.offset,
                    len(chunk.data),
                )
                writer.write(build_ack(MsgType.SD_STREAM, 0, "ok"))
                await writer.drain()
            elif msg_type == MsgType.SD_DONE:
                done = parse_sd_done(payload)
                logger.info(
                    "[sd] node=%s:%s file_time=%s status=%s",
                    done.node_type,
                    done.node_number,
                    done.file_time,
                    done.status,
                )
                writer.write(build_ack(MsgType.SD_DONE, 0, "ok"))
                await writer.drain()
            else:
                logger.info("[server] msg_type=0x%02X len=%d", msg_type, len(payload))
                writer.write(build_ack(msg_type, 0, "ok"))
                await writer.drain()
    except asyncio.IncompleteReadError:
        pass
    finally:
        clients.pop(peer_id, None)
        writer.close()
        await writer.wait_closed()
        logger.info("[server] disconnected %s (clients=%d)", peer_id, len(clients))


async def broadcast_messages(
    queue: asyncio.Queue[bytes],
    clients: Dict[str, asyncio.StreamWriter],
) -> None:
    while True:
        payload = await queue.get()
        if not clients:
            logger.info("[server] no clients to broadcast to")
            continue
        for peer_id, writer in list(clients.items()):
            try:
                writer.write(payload)
                await writer.drain()
            except ConnectionError:
                clients.pop(peer_id, None)
        logger.info("[server] broadcast to %d clients", len(clients))


async def run_server(
    host: str,
    port: int,
    on_connect_payload: Optional[bytes],
    command_queue: Optional[asyncio.Queue[bytes]] = None,
) -> None:
    clients: Dict[str, asyncio.StreamWriter] = {}

    async def _client_handler(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        if on_connect_payload:
            writer.write(on_connect_payload)
            await writer.drain()
        await handle_client(reader, writer, clients)

    server = await asyncio.start_server(_client_handler, host=host, port=port)
    addrs = ", ".join(str(sock.getsockname()) for sock in server.sockets or [])
    print(f"[server] listening on {addrs}")

    async with server:
        if command_queue is None:
            await server.serve_forever()
        else:
            broadcaster = asyncio.create_task(broadcast_messages(command_queue, clients))
            try:
                await server.serve_forever()
            finally:
                broadcaster.cancel()
