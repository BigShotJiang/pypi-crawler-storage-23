from numpy import empty, append, array, where, logical_and, delete
from scipy.interpolate import interp1d
try:
    from . import config
except ImportError:
    import config
import struct
import datetime

class Timestamping():
     
    def __init__(self):

        self.CC_ppsEpoch = empty((0, 2), dtype = float)   # array( [[cc0, epoch_PPS0], [cc1, epoch_PPS1]] )
        self.CC_ACC = empty((0, 4), dtype = float)        # array( [[cc, acc_x, acc_y, acc_z], ...])
        self.CC_ACC_RTC = empty((0, 4), dtype = float)    # pending rtc samples before first map
        self.rtc_anchor_cc = None
        self.rtc_anchor_epoch = None
        self.rtc_cc_hz = 10_000_000.0

    def push_cc_acc(self, cc_acc):

        # only add when it is a new data
        if self.CC_ppsEpoch.shape[0] > 1 and cc_acc[0] > self.CC_ppsEpoch[1, 0]:
            self.CC_ACC = append(self.CC_ACC, array([cc_acc]), axis=0) # CC, acc_x, acc_y, acc_z
    
    def push_cc_pps(self, CC, epoch_time):

        # Populating CC_ppsEpoch Table
        self.CC_ppsEpoch = append(self.CC_ppsEpoch, array([[CC, epoch_time]]), axis = 0)
        if len(self.CC_ppsEpoch) == 1:
            return [], []
        elif len(self.CC_ppsEpoch) == 3:
            self.CC_ppsEpoch = self.CC_ppsEpoch[1:, :]  # shifting CC_ppsEpoch            
        
        # timestamping 
        cc0 = self.CC_ppsEpoch[0, 0]
        cc1 = self.CC_ppsEpoch[1, 0]
        idx = where(logical_and(self.CC_ACC[:,0] >= cc0, self.CC_ACC[:,0] < cc1))
        if len(idx[0]) > 0:
            cc_acc = self.CC_ACC[idx[0], :]
            linear_interp = interp1d(self.CC_ppsEpoch[:2, 0], self.CC_ppsEpoch[:2, 1], kind = 'linear')
            x_interp = cc_acc[:, 0]
            y_interp = linear_interp(x_interp)
            t = []
            for i in range(cc_acc.shape[0]):
                epoch = int(y_interp[i])
                suseconds = int((y_interp[i] - epoch) * 1e6)
                t_ = datetime.datetime.fromtimestamp(epoch, tz=datetime.timezone.utc)
                t_ = t_.replace(microsecond = suseconds)
                t.append(t_)
            y = cc_acc[:, 1:4]
            # Delete already timestamped points
            mask = self.CC_ACC[:, 0] >= cc1
            self.CC_ACC = self.CC_ACC[mask,...]
            return t, y
            
        return [], []

    def clear_rtc_anchor(self):
        self.rtc_anchor_cc = None
        self.rtc_anchor_epoch = None
        self.CC_ACC_RTC = empty((0, 4), dtype=float)

    def clear_gnss_state(self):
        self.CC_ppsEpoch = empty((0, 2), dtype=float)
        self.CC_ACC = empty((0, 4), dtype=float)

    def clear_all_state(self):
        self.clear_gnss_state()
        self.clear_rtc_anchor()

    def set_rtc_anchor(self, CC, epoch_time):
        self.rtc_anchor_cc = float(CC)
        self.rtc_anchor_epoch = float(epoch_time)

    def _rtc_cc_to_datetime(self, cc):
        if self.rtc_anchor_cc is None or self.rtc_anchor_epoch is None:
            return None
        delta_sec = (float(cc) - self.rtc_anchor_cc) / self.rtc_cc_hz
        epoch = self.rtc_anchor_epoch + delta_sec
        try:
            return datetime.datetime.fromtimestamp(epoch, tz=datetime.timezone.utc)
        except (OSError, OverflowError, ValueError):
            return None

    def push_cc_acc_rtc(self, cc_acc):
        cc = float(cc_acc[0])
        y = array([[float(cc_acc[1]), float(cc_acc[2]), float(cc_acc[3])]], dtype=float)
        if self.rtc_anchor_cc is None:
            self.CC_ACC_RTC = append(self.CC_ACC_RTC, array([[cc, y[0, 0], y[0, 1], y[0, 2]]]), axis=0)
            return [], empty((0, 3), dtype=float)
        if cc < self.rtc_anchor_cc:
            return [], empty((0, 3), dtype=float)
        t = self._rtc_cc_to_datetime(cc)
        if t is None:
            return [], empty((0, 3), dtype=float)
        return [t], y

    def drain_rtc_pending(self):
        if self.rtc_anchor_cc is None or self.CC_ACC_RTC.shape[0] == 0:
            return [], empty((0, 3), dtype=float)

        pending = self.CC_ACC_RTC
        self.CC_ACC_RTC = empty((0, 4), dtype=float)
        valid_idx = where(pending[:, 0] >= self.rtc_anchor_cc)[0]
        if len(valid_idx) == 0:
            return [], empty((0, 3), dtype=float)

        ts = []
        ys = []
        for i in valid_idx:
            t = self._rtc_cc_to_datetime(pending[i, 0])
            if t is None:
                continue
            ts.append(t)
            ys.append([pending[i, 1], pending[i, 2], pending[i, 3]])
        if len(ts) == 0:
            return [], empty((0, 3), dtype=float)
        return ts, array(ys, dtype=float)
    
    

    # rawFileLength_sec = config.rawFileLength_sec
    # def getGridTime(self, epoch):
    #     return int(epoch / rawFileLength_sec) * rawFileLength_sec
    # # FILE SAVING 
    # if 0:
    #     if epoch_time > 0: 
    #         if fid == -1:
    #             latest_fileName = self.getFileName(streamID, epoch_time)
    #             fid = open(latest_fileName, "wb")
    #         elif self.getFileName(streamID, epoch_time) != latest_fileName:
    #             fid.close()
    #             latest_fileName = self.getFileName(streamID, epoch_time)
    #             fid = open(latest_fileName, "wb")
    #     if fid != -1:
    #         fid.write(packet[2:])
    # data = data[packet_size:]

    # def getFileName(self, streamID, epoch_time):
    #     nodeNumber = (streamID & 0x0FF0) >> 4
    #     streamID_str = 'ACC{}-ACC'.format(nodeNumber)
    #     t = datetime.datetime.fromtimestamp(epoch_time)
    #     return os.path.join(target_dir, '{}-{}'.format(datetime.datetime.strftime(t, '%Y_%m%d_%H%M'), streamID_str))
