#
#
# 2025-02-28 understand and make sure it works
# node_ID vs Node_ID vs nodeID
# 

import logging
from collections import deque
import queue as pyqueue
# import mesh
import sys

import threading
try:
    from . import queues
except ImportError:
    import queues
from numpy import array, append, where, logical_and, delete, floor, empty
from scipy.interpolate import interp1d

try:
    from . import shm_sigproc
except ImportError:
    import shm_sigproc
import glob
import os 

import re
import numpy as np
import configparser
import pandas as pd
from pandas import DataFrame, to_datetime
import struct
import datetime
try:
    from . import timestamping
except ImportError:
    import timestamping
import importlib
importlib.reload(timestamping)
try:
    from . import resampling
except ImportError:
    import resampling
import time 
try:
    from . import psd_recursive
except ImportError:
    import psd_recursive
try:
    import scipy.io as sio
except Exception:
    sio = None
try:
    import hdf5storage as h5s
except Exception:
    h5s = None
try:
    from . import storage
except ImportError:
    import storage
import os 
import pandas as pd
from enum import IntEnum, auto

try:
    from .constants import (
        PACKET_SIZE,
        SPEED_COL,
        RSSI_COL,
        TIME_SOURCE_COL,
        PPS_COL,
        BAT_COL,
        LEVEL_COL,
        RT_STREAM_HD5_DIR,
        RT_STREAM_MERGED_DIR,
        SD_STREAM_DIR,
        SD_STREAM_BIN_DIR,
        SD_STREAM_HD5_DIR,
    )
except ImportError:
    from constants import (
        PACKET_SIZE,
        SPEED_COL,
        RSSI_COL,
        TIME_SOURCE_COL,
        PPS_COL,
        BAT_COL,
        LEVEL_COL,
        RT_STREAM_HD5_DIR,
        RT_STREAM_MERGED_DIR,
        SD_STREAM_DIR,
        SD_STREAM_BIN_DIR,
        SD_STREAM_HD5_DIR,
    )
try:
    from .types import NodeStatus
except Exception:
    try:
        from enode_host.types import NodeStatus
    except Exception:
        NodeStatus = None

df = []
psd = []

logger = logging.getLogger("main." + __name__)
logger.setLevel(logging.DEBUG)

CONFIG_FILE = 'config.ini'


class NodeType(IntEnum):
    ACC = 0 
    DISP = 1
    STR = 2
    TILT = 3 
    TMP = 4
    VEH = 5

class ChannelType(IntEnum):
    CONN_RPT = 0 
    CMD_RESP = 1
    PPS_CC_EPOCH = 2
    ACC_CC_DAQ = 3

class CmdType(IntEnum):
    SET_MODE = 0
    SD_STORAGE_CLEAR = 1
    NOTIFY_PARENT = 2
    NOTIFY_CHILDREN = 3
    SET_STREAM = auto()
    STREAM_START = auto()
    STREAM_STOP = auto()
    GNSS_ON = auto()
    GNSS_OFF = auto()
    CLEAR_SD = auto()
    CHANGE_FS = auto()

class NodeResp(IntEnum):
    OK = 0
    FAIL = 1

class Model():

    def __init__(self, parent):

        self.controller = parent
        self.ui_log = None
        self.options = [] # config.ini
        self.node_nums = [] # [1:3 7:8]
        self.node_nums_map = {}
        self.NodeIDs = []  # ['ACC1', 'ACC2',...]
        self.node_status = {}
        self.node_time_source = {}
        self.rtc_mapping_counts = {}
        self.last_cc_epoch = {}
        # the below two lines may be removed?
        # self.status_table_columns = ['Node ID', 'Connection', 'L', 'RSSI', 'PPS', 'Data']
        # self.node_status = {}
        self.mesh_status_data = pd.DataFrame(columns = ['Node ID',     
                                                        'Connection',
                                                        'Sensor',
                                                        'DAQ Mode',
                                                        'DAQ',
                                                        'Stream',
                                                        SPEED_COL,
                                                        LEVEL_COL, 
                                                        'Parent', 
                                                        RSSI_COL, 
                                                        'Children', 
                                                        TIME_SOURCE_COL,
                                                        PPS_COL, 
                                                        BAT_COL,
                                                        'CMD',       
                                                        #'Children_nodeIDs', # invisable in table
                                                        'PPS-time',   # invisable in table
                                                        'PPS-flash-time', # invisable in table
                                                        'DAQ-time',   # invisible in table
                                                        'Parent MAC', # invisable in table
                                                        'Self MAC',   # invisable in table
                                                        'nodeID',     # invisable in table
                                                        'ConnRptTime',# invisable in table
                                                        'node_number',
                                                        'node_type',
                                                        ])
        self.plot_mutex = {}    # the dict for mutexes for accessing plot x y data dict
        self.timestamper = {}   # the dict for timestamper {1:timestamping.Timestamping(), ...}
        self.resampler = {}     # the dict for resampler   {1:resampling.Resampling(62.5), ...}
        self.timehistory_xdata = {} # {1:[datetime], ...}
        self.timehistory_ydata = {} # {1:ndarray, ...}
        self.timehistory_xlim = []  
        self.full_range_xlim = []
        self.merge_full_range = False
        self.psder = {}             # {1:psd_recursive.PSD_Recursive(1024, 62.5), ...}
        self.psd_xdata = {}         # per-node frequency arrays {node_id: 1d ndarray}
        self.psd_ydata = {}         # psd amplitude {1:ndarray}
        self.merged_timehistory_xdata = {}
        self.merged_timehistory_ydata = {}
        self.merged_timehistory_xlim = []
        self.merged_psd_xdata = []
        self.merged_psd_ydata = {}
        self.merged_node_ids = []
        self.merged_fs = None
        self.gui_dirty = False
        self.plot_dirty = False
        self.plot_dirty_version = 0
        self.conn_report_queue = pyqueue.Queue(maxsize=1000)
        self.data_queue = pyqueue.Queue(maxsize=5000)
        self.speed_bytes = {}
        self.node_fs = {}
        self.node_fs_known = {}
        self.psd_base_nfft = 1024
        self.psd_min_nfft = 256
        self.psd_max_nfft = 16384
        self.psd_target_df = None
        self.speed_last_calc = datetime.datetime.now(datetime.timezone.utc)
        self.timespan_length = 30
        self._pps_count = 0
        self._ts_count = 0
        self._last_rate_log = time.monotonic()
        self._plot_dirty_set = 0
        self._last_plot_debug = time.monotonic()
        self.enable_rate_logging = False
        self.enable_plot_logging = False
        self.pps_flash_sec = 0.3
        self.pps_flash_until = {}
        self.pps_flash_lock = threading.Lock()
        self._rate_timer = threading.Thread(target=self._rate_logger, daemon=True)
        self._rate_timer.start()

        self.Storage = storage.Storage(600) # arg = file_length_in_sec
        self.sd_stream_dir = SD_STREAM_BIN_DIR
        os.makedirs(self.sd_stream_dir, exist_ok=True)
        self.sd_stream_hd5_dir = SD_STREAM_HD5_DIR
        os.makedirs(self.sd_stream_hd5_dir, exist_ok=True)
        self.sd_stream_merged_dir = os.path.join(SD_STREAM_DIR, "merged")
        os.makedirs(self.sd_stream_merged_dir, exist_ok=True)
        os.makedirs(RT_STREAM_HD5_DIR, exist_ok=True)
        os.makedirs(RT_STREAM_MERGED_DIR, exist_ok=True)
        self._sd_stream_handles = {}
        self._sd_stream_lock = threading.Lock()
        self._sd_stream_active = set()
        self.gnss_positions = {}

        self.load_config()
        self.parse_node_nums_txt() 
        self.init_mesh_status_data()
        self.init_other_data()
        self._apply_sampling_rate_from_status()
        
        # Thread for framed connection reports
        self.conn_report_thread = threading.Thread(target=self._conn_report_worker, daemon=True)
        self.conn_report_thread.start()

        self.data_thread = threading.Thread(target=self._data_worker, daemon=True)
        self.data_thread.start()

        # Thread for detecting disconnected nodes without connection reporting
        self.timer = threading.Timer(10, self.on_timer)
        self.timer.start()

        self.acc_model_labels = {
            0: "",
            1: "ADXL355",
            2: "M352",
        }
        self.daq_mode_labels = {
            "ADXL355": [
                "0: 7.813/31.25",
                "1: 15.625/62.5",
                "2: 31.25/125",
            ],
            "M352": [
                "0: 09/50",
                "1: 16/100",
                "2: 16/200",
                "3: 60/200",
            ],
        }

    @staticmethod
    def _node_type_label(node_type) -> str:
        try:
            node_type_int = int(node_type)
        except (TypeError, ValueError):
            return "UNK"
        return {
            0: "ACC",
            1: "DISP",
            2: "STR",
            3: "TILT",
            4: "TMP",
            5: "VEH",
        }.get(node_type_int, f"N{node_type_int}")

    @classmethod
    def make_node_key(cls, node_type, node_number) -> str:
        return f"{cls._node_type_label(node_type)}{int(node_number)}"

    @staticmethod
    def _parse_node_number(node_key: str) -> int:
        match = re.search(r"(\d+)$", str(node_key))
        if match:
            return int(match.group(1))
        return -1

    def _node_number_from_key(self, node_key: str) -> int:
        condition = self.mesh_status_data['nodeID'] == node_key
        if condition.any():
            value = self.mesh_status_data.loc[condition, 'node_number'].iloc[0]
            try:
                return int(value)
            except (TypeError, ValueError):
                pass
        return self._parse_node_number(node_key)

    def _node_type_from_key(self, node_key: str) -> str:
        condition = self.mesh_status_data['nodeID'] == node_key
        if condition.any():
            value = self.mesh_status_data.loc[condition, 'node_type'].iloc[0]
            if isinstance(value, str) and value:
                return value
        match = re.match(r"([A-Za-z]+)", str(node_key))
        return match.group(1) if match else "UNK"

    def _acc_model_label(self, acc_model: int) -> str:
        return self.acc_model_labels.get(int(acc_model), "")

    def _format_daq_mode(self, acc_model_label: str, daq_mode: int) -> str:
        try:
            mode = int(daq_mode)
        except (TypeError, ValueError):
            return ""
        choices = self.daq_mode_labels.get(acc_model_label, [])
        if 0 <= mode < len(choices):
            return choices[mode]
        return str(mode)

    @staticmethod
    def _extract_fs_from_daq_label(daq_mode_label: str):
        if not daq_mode_label:
            return None
        match = re.search(r"/\s*([0-9.]+)", str(daq_mode_label))
        if not match:
            return None
        try:
            return float(match.group(1))
        except ValueError:
            return None

    def _update_sampling_rate(self, node_id: str, fs: float):
        if fs is None or fs <= 0:
            return
        prev = self.node_fs.get(node_id)
        if prev is not None and abs(prev - fs) < 1e-6:
            return
        self.node_fs[node_id] = fs
        self.node_fs_known[node_id] = True
        if node_id in self.resampler:
            self.resampler[node_id].set_fs(fs)
        if node_id in self.psder:
            self.psder[node_id].set_fs(fs)
        self._recompute_psd_nfft()

    def _compute_psd_target_df(self):
        fs_values = [fs for node_id, fs in self.node_fs.items() if self.node_fs_known.get(node_id)]
        if not fs_values:
            return None
        min_fs = min(fs_values)
        if min_fs <= 0:
            return None
        return min_fs / float(self.psd_base_nfft)

    def _choose_nfft(self, fs, target_df):
        if target_df is None or target_df <= 0:
            return self.psd_base_nfft
        nfft = int(round(fs / target_df))
        if nfft < self.psd_min_nfft:
            nfft = self.psd_min_nfft
        elif nfft > self.psd_max_nfft:
            nfft = self.psd_max_nfft
        return nfft

    def _recompute_psd_nfft(self):
        target_df = self._compute_psd_target_df()
        if target_df is None:
            return
        if self.psd_target_df is None or abs(self.psd_target_df - target_df) > 1e-9:
            self.psd_target_df = target_df
            self._ui_log(
                f"[psd] target df={target_df:.6f} Hz (base_nfft={self.psd_base_nfft})"
            )
        for node_id, fs in self.node_fs.items():
            if not self.node_fs_known.get(node_id):
                continue
            nfft = self._choose_nfft(fs, target_df)
            if self.psd_nfft.get(node_id) == nfft:
                continue
            self.psd_nfft[node_id] = nfft
            self.psder[node_id] = psd_recursive.PSD_Recursive(nfft, fs)
            self.psd_xdata.pop(node_id, None)
            self.psd_ydata.pop(node_id, None)
            df = fs / float(nfft)
            self._ui_log(f"[psd] node={node_id} fs={fs:.3f} nfft={nfft} df={df:.6f} Hz")

    def _update_observed_fs(self, node_id, ts_list):
        if not ts_list or len(ts_list) < 2:
            return
        duration = (ts_list[-1] - ts_list[0]).total_seconds()
        if duration <= 0:
            return
        fs_est = (len(ts_list) - 1) / duration
        if fs_est <= 0:
            return
        fs_nom = self.node_fs.get(node_id)
        if fs_nom:
            ratio = fs_est / fs_nom
            if ratio < 0.5 or ratio > 1.5:
                return
        prev = self.node_fs_obs.get(node_id)
        if prev is None:
            self.node_fs_obs[node_id] = fs_est
        else:
            alpha = 0.1
            self.node_fs_obs[node_id] = prev * (1 - alpha) + fs_est * alpha

    def load_config(self):
        config = configparser.ConfigParser()

        if not os.path.exists(CONFIG_FILE):
            # Return default options if config file doesn't exist
            self.options = {
                'acc_nums_txt': '[1:3]',
                'tmp_nums_txt': '[]',
                'str_nums_txt': '[]',
                'veh_nums_txt': '[]',
                'option2': 'default_value2',
                'log_file_pps': 'true',
                'log_file_conn_rpt': 'true',
                'log_terminal_pps': 'true',
                'log_terminal_conn_rpt': 'false',
                'plot_channel_x': 'false',
                'plot_channel_y': 'true',
                'plot_channel_z': 'false',
                'plot_timespan': '30',
                'plot_time_y_auto': 'false',
                'plot_time_ylim': '[-2.0, 2.0]',
                'plot_psd_y_auto': 'false',
                'plot_psd_ylim': '[1e-06, 10.0]',
            }
            return

        config.read(CONFIG_FILE)
        acc_fallback = config.get('Settings', 'node_nums_txt', fallback='[1:3]')
        self.options = {
            'acc_nums_txt': config.get('Settings', 'acc_nums_txt', fallback=acc_fallback),
            'tmp_nums_txt': config.get('Settings', 'tmp_nums_txt', fallback='[]'),
            'str_nums_txt': config.get('Settings', 'str_nums_txt', fallback='[]'),
            'veh_nums_txt': config.get('Settings', 'veh_nums_txt', fallback='[]'),
            'option2': config.get('Settings', 'option2', fallback='default_value2'),
            'log_file_pps': config.get('Logging', 'file_pps', fallback='true'),
            'log_file_conn_rpt': config.get('Logging', 'file_conn_rpt', fallback='true'),
            'log_terminal_pps': config.get('Logging', 'terminal_pps', fallback='true'),
            'log_terminal_conn_rpt': config.get('Logging', 'terminal_conn_rpt', fallback='false'),
            'plot_channel_x': config.get('Plot', 'channel_x', fallback='false'),
            'plot_channel_y': config.get('Plot', 'channel_y', fallback='true'),
            'plot_channel_z': config.get('Plot', 'channel_z', fallback='false'),
            'plot_timespan': config.get('Plot', 'timespan', fallback='30'),
            'plot_time_y_auto': config.get('Plot', 'time_y_auto', fallback='false'),
            'plot_time_ylim': config.get('Plot', 'time_ylim', fallback='[-2.0, 2.0]'),
            'plot_psd_y_auto': config.get('Plot', 'psd_y_auto', fallback='false'),
            'plot_psd_ylim': config.get('Plot', 'psd_ylim', fallback='[1e-06, 10.0]'),
        }
        
    def save_config(self):
        config = configparser.ConfigParser()

        config['Settings'] = {
            'node_nums_txt': self.options['acc_nums_txt'],
            'acc_nums_txt': self.options['acc_nums_txt'],
            'tmp_nums_txt': self.options['tmp_nums_txt'],
            'str_nums_txt': self.options['str_nums_txt'],
            'veh_nums_txt': self.options['veh_nums_txt'],
            'option2': self.options['option2']
        }
        config['Logging'] = {
            'file_pps': self.options.get('log_file_pps', 'true'),
            'file_conn_rpt': self.options.get('log_file_conn_rpt', 'true'),
            'terminal_pps': self.options.get('log_terminal_pps', 'true'),
            'terminal_conn_rpt': self.options.get('log_terminal_conn_rpt', 'false'),
        }
        config['Plot'] = {
            'channel_x': self.options.get('plot_channel_x', 'false'),
            'channel_y': self.options.get('plot_channel_y', 'true'),
            'channel_z': self.options.get('plot_channel_z', 'false'),
            'timespan': self.options.get('plot_timespan', '30'),
            'time_y_auto': self.options.get('plot_time_y_auto', 'false'),
            'time_ylim': self.options.get('plot_time_ylim', '[-2.0, 2.0]'),
            'psd_y_auto': self.options.get('plot_psd_y_auto', 'false'),
            'psd_ylim': self.options.get('plot_psd_ylim', '[1e-06, 10.0]'),
        }

        with open(CONFIG_FILE, 'w') as configfile:
            config.write(configfile)
    
    def parse_node_nums_txt(self):
        
        """
        Parse a MATLAB-style expression into a Python list.
        Supports ranges (e.g., 1:4) and concatenation (e.g., [1:4 7]).
        """
        def parse_expr(expr):
            expr = (expr or "").strip()
            if not expr:
                return []
            expr = expr.strip('[]')
            if not expr:
                return []
            parts = expr.split()
            result = []
            for part in parts:
                if ':' in part:
                    start, end = map(int, part.split(':'))
                    result.extend(range(start, end + 1))
                else:
                    result.append(int(part))
            return result

        node_map = {
            "ACC": parse_expr(self.options.get("acc_nums_txt", "")),
            "TMP": parse_expr(self.options.get("tmp_nums_txt", "")),
            "STR": parse_expr(self.options.get("str_nums_txt", "")),
            "VEH": parse_expr(self.options.get("veh_nums_txt", "")),
        }
        self.node_nums_map = node_map
        all_nums = sorted({n for nums in node_map.values() for n in nums})
        if all_nums:
            self.node_nums = np.array(all_nums)
            logger.info('node_nums=%s', self.node_nums)

    def init_mesh_status_data(self):
        
        self.NodeIDs = []
        self.node_status = {}
        self.node_time_source = {}
        self.rtc_mapping_counts = {}
        self.last_cc_epoch = {}
        self.mesh_status_data = self.mesh_status_data[0:0] # Empty all the rows
        type_order = ("ACC", "TMP", "STR", "VEH")
        for node_type in type_order:
            for node_num in sorted(set(self.node_nums_map.get(node_type, []))):
                node_key = f"{node_type}{node_num}"
                nodeID = node_key
                NodeID = node_key
                self.NodeIDs.append(NodeID)
                if NodeStatus is not None:
                    self.node_status[nodeID] = NodeStatus(
                        node_id=nodeID,
                        node_label=NodeID,
                        connection="waiting",
                    )
                self.node_time_source[nodeID] = "GNSS"
                self.rtc_mapping_counts[nodeID] = 0
                self.last_cc_epoch[nodeID] = None

                new_row = pd.DataFrame({'Node ID': [NodeID], 
                                        'Connection':['waiting'],
                                        'Sensor':[''],
                                        'DAQ Mode':[''],
                                        'DAQ':[''],
                                        'Stream':[''],
                                        SPEED_COL:[''],
                                        LEVEL_COL:[''], 
                                        'Parent':[''],
                                        RSSI_COL:[''], 
                                        'Children':[''],
                                        TIME_SOURCE_COL:[''],
                                        PPS_COL:[''], 
                                        BAT_COL:[''],
                                        'CMD':[''],
                                        #'Children_nodeIDs': [''],
                                        'PPS-time':[''],
                                        'PPS-flash-time':[''],
                                        'DAQ-time':[''],
                                        'Parent MAC':[''],
                                        'Self MAC':[''],
                                        'nodeID': nodeID,
                                        'ConnRptTime':[None],
                                        'node_number':[node_num],
                                        'node_type':[node_type],
                                        })
                self.mesh_status_data = pd.concat([self.mesh_status_data, new_row], ignore_index = True)

        logger.info(self.NodeIDs)

    def init_other_data(self):

        self.plot_mutex.clear()
        self.timestamper.clear()
        self.resampler.clear()
        self.timehistory_xdata.clear()
        self.timehistory_ydata.clear()
        self.timehistory_xlim = []
        self.full_range_xlim = []
        self.merge_full_range = False
        self.psder.clear()
        self.psd_xdata = {}
        self.psd_ydata.clear()
        self.speed_bytes = {}
        self.speed_last_value = {}
        self.speed_last_rx = {}
        self.speed_hist = {}
        self.speed_window_sec = 5.0
        self.speed_last_calc = datetime.datetime.now(datetime.timezone.utc)
        self.node_fs_obs = {}
        self.psd_nfft = {}
        self.node_fs_known = {}

        for index, row in self.mesh_status_data.iterrows():
            nodeID = row['nodeID']
            self.timehistory_xdata[nodeID] = [] # empty((0), dtype = float)
            self.timehistory_ydata[nodeID] = empty((0, 3), dtype = float)
            self.plot_mutex[nodeID] = threading.Lock()
            self.timestamper[nodeID] = timestamping.Timestamping()
            self.resampler[nodeID] = resampling.Resampling(50)            
            self.psder[nodeID] = psd_recursive.PSD_Recursive(1024, 50)
            self.node_fs[nodeID] = 50
            self.node_fs_obs[nodeID] = None
            self.psd_nfft[nodeID] = 1024
            self.node_fs_known[nodeID] = False
            self.speed_bytes[nodeID] = 0
            self.speed_last_value[nodeID] = None
            self.speed_last_rx[nodeID] = None
            self.speed_hist[nodeID] = deque()
            self.pps_flash_until[nodeID] = None

    def clear_plot_data(self):
        # Clear plotted buffers without touching timestamp mapping state.
        self.timehistory_xlim = []
        self.full_range_xlim = []
        self.merge_full_range = False
        self.merged_timehistory_xdata = {}
        self.merged_timehistory_ydata = {}
        self.merged_timehistory_xlim = []
        self.merged_psd_xdata = []
        self.merged_psd_ydata = {}
        self.merged_node_ids = []
        self.merged_fs = None

        for nodeID in list(self.timehistory_xdata.keys()):
            lock = self.plot_mutex.get(nodeID)
            if lock is None:
                continue
            with lock:
                self.timehistory_xdata[nodeID] = []
                self.timehistory_ydata[nodeID] = empty((0, 3), dtype=float)
                self.psd_xdata[nodeID] = []
                self.psd_ydata.pop(nodeID, None)

                fs = self.node_fs.get(nodeID, 50)
                nfft = self.psd_nfft.get(nodeID, self.psd_base_nfft)
                self.psder[nodeID] = psd_recursive.PSD_Recursive(nfft, fs)

                resampler_obj = self.resampler.get(nodeID)
                if resampler_obj is not None:
                    resampler_obj.set_fs(fs)

        self.plot_dirty = True
        self.plot_dirty_version += 1
        self._plot_dirty_set += 1

    def _apply_sampling_rate_from_status(self):
        for _, row in self.mesh_status_data.iterrows():
            node_id = row.get("nodeID") or row.get("Node ID")
            if not node_id:
                continue
            fs = self._extract_fs_from_daq_label(row.get("DAQ Mode", ""))
            if fs:
                self._update_sampling_rate(node_id, fs)
    

    def enqueue_conn_report(self, nodeID, level, parent_mac, self_mac, rssi, acc_model: int = 0, daq_mode: int = 0, daq_on: int = 0, stream_status: int = 0, bat_vol: float | None = None, time_source: int = 0, notify: bool = False):
        try:
            self.conn_report_queue.put_nowait(
                {
                    "nodeID": nodeID,
                    "level": level,
                    "parent_mac": parent_mac,
                    "self_mac": self_mac,
                    "rssi": rssi,
                    "acc_model": acc_model,
                    "daq_mode": daq_mode,
                    "daq_on": daq_on,
                    "stream_status": stream_status,
                    "bat_vol": bat_vol,
                    "time_source": time_source,
                    "notify": notify,
                }
            )
        except pyqueue.Full:
            logger.warning("conn_report_queue full; dropping report for node %s", nodeID)

    def _conn_report_worker(self):
        while True:
            item = self.conn_report_queue.get()
            self.handle_conn_report(
                nodeID=item["nodeID"],
                level=item["level"],
                parent_mac=item["parent_mac"],
                self_mac=item["self_mac"],
                rssi=item["rssi"],
                acc_model=item.get("acc_model", 0),
                daq_mode=item.get("daq_mode", 0),
                daq_on=item.get("daq_on", 0),
                stream_status=item.get("stream_status", 0),
                bat_vol=item.get("bat_vol"),
                time_source=item.get("time_source", 0),
                notify=item["notify"],
            )

    def enqueue_acc_batch(self, nodeID, samples):
        try:
            self.data_queue.put_nowait(("acc_batch", nodeID, samples))
        except pyqueue.Full:
            logger.warning("data_queue full; dropping acc batch for node %s", nodeID)

    def record_rx_bytes(self, nodeID, nbytes, kind: str = "data"):
        if kind not in ("data", "sd"):
            return
        if nodeID in self.speed_bytes:
            self.speed_bytes[nodeID] += nbytes
            self.speed_last_rx[nodeID] = datetime.datetime.now(datetime.timezone.utc)
            hist = self.speed_hist.get(nodeID)
            if hist is not None:
                hist.append((self.speed_last_rx[nodeID], nbytes))

    def enqueue_pps(self, nodeID, cc, epoch):
        try:
            self.data_queue.put_nowait(("pps", nodeID, cc, epoch))
        except pyqueue.Full:
            logger.warning("data_queue full; dropping pps for node %s", nodeID)

    def _data_worker(self):
        while True:
            item = self.data_queue.get()
            kind = item[0]
            try:
                if kind == "acc_batch":
                    _, nodeID, samples = item
                    for sample in samples:
                        self.handle_acc_sample(nodeID, sample.cc, sample.ax, sample.ay, sample.az)
                elif kind == "pps":
                    _, nodeID, cc, epoch = item
                    self.handle_pps(nodeID, cc, epoch)
            except Exception:
                logger.exception("data_worker error kind=%s", kind)

    def update_speed(self, now_utc):
        dt = (now_utc - self.speed_last_calc).total_seconds()
        if dt <= 0:
            return
        for nodeID in list(self.speed_hist.keys()):
            condition = self._node_condition(nodeID)
            connected = False
            if condition is not None:
                try:
                    connected = self.mesh_status_data.loc[condition, "Connection"].iloc[0] == "connected"
                except Exception:
                    connected = False
            if not connected:
                self._set_node_fields(nodeID, mark_dirty=False, **{SPEED_COL: ""})
            else:
                hist = self.speed_hist.get(nodeID)
                if hist is None:
                    self._set_node_fields(nodeID, mark_dirty=False, **{SPEED_COL: "0.0"})
                else:
                    window_start = now_utc - datetime.timedelta(seconds=self.speed_window_sec)
                    while hist and hist[0][0] < window_start:
                        hist.popleft()
                    total = sum(n for _, n in hist)
                    if total == 0:
                        self._set_node_fields(nodeID, mark_dirty=False, **{SPEED_COL: "0.0"})
                    else:
                        kbps = (total / 1024.0) / self.speed_window_sec
                        self._set_node_fields(nodeID, mark_dirty=False, **{SPEED_COL: f"{kbps:.1f}"})
        self.speed_last_calc = now_utc
        self.gui_dirty = True

    def _time_delay_correction(self, ts, node_number):
        if node_number < 17:
            dt = datetime.timedelta(microseconds=(47.59) * 1000)
        else:
            dt = datetime.timedelta(microseconds=(63.875 + 17) * 1000)
        return [t_ - dt for t_ in ts]

    def get_time_window(self, t1):
        tspan = self.timespan_length
        return [
            datetime.datetime.fromtimestamp(
                floor(t1.timestamp() / tspan) * tspan, tz=datetime.timezone.utc
            ),
            datetime.datetime.fromtimestamp(
                floor(t1.timestamp() / tspan + 1) * tspan, tz=datetime.timezone.utc
            ),
        ]

    def _ingest_timestamped_samples(self, nodeID, ts, ys):
        if len(ts) == 0:
            return
        ys_arr = np.asarray(ys, dtype=float)
        if ys_arr.size == 0:
            return
        if ys_arr.ndim == 1:
            ys_arr = ys_arr.reshape(1, -1)
        if ys_arr.shape[1] != 3:
            if ys_arr.size % 3 != 0:
                logger.warning("drop malformed sample block node=%s shape=%s", nodeID, ys_arr.shape)
                return
            ys_arr = ys_arr.reshape(-1, 3)
        n = min(len(ts), ys_arr.shape[0])
        if n <= 0:
            return
        if n != len(ts) or n != ys_arr.shape[0]:
            ts = ts[:n]
            ys_arr = ys_arr[:n, :]

        self._update_observed_fs(nodeID, ts)
        self._ts_count += len(ts)
        self.plot_dirty = True
        self.plot_dirty_version += 1
        self._plot_dirty_set += 1
        with self.plot_mutex[nodeID]:
            self.timehistory_xdata[nodeID] += ts
            self.timehistory_ydata[nodeID] = append(self.timehistory_ydata[nodeID], ys_arr, axis=0)

            if self.merge_full_range:
                window = self.full_range_xlim if self.full_range_xlim else None
            else:
                window = self.get_time_window(ts[-1])
                self.timehistory_xlim = window
            if window:
                index = [i for i, _ in enumerate(self.timehistory_xdata[nodeID]) if _ > window[0]]
                self.timehistory_xdata[nodeID] = [self.timehistory_xdata[nodeID][i] for i in index]
                self.timehistory_ydata[nodeID] = self.timehistory_ydata[nodeID][index, :]

            [trs, yrs] = self.resampler[nodeID].push(ts, ys_arr.tolist())
            if len(trs) > 0 and len(yrs) > 0:
                self.Storage.push(nodeID, trs, yrs)
                yrs_arr = np.asarray(yrs, dtype=float)
                if yrs_arr.ndim == 1:
                    yrs_arr = yrs_arr.reshape(1, -1)
                if yrs_arr.shape[1] == 3:
                    m = min(len(trs), yrs_arr.shape[0])
                    if m > 0:
                        self.psder[nodeID].push(yrs_arr[:m, :], np.asarray(trs[:m]))

            if self.psder[nodeID].isUpdated:
                f, asd = self.psder[nodeID].get_asd()
                fs_nom = self.node_fs.get(nodeID)
                fs_obs = self.node_fs_obs.get(nodeID)
                if fs_nom and fs_obs:
                    f = f * (fs_obs / fs_nom)
                self.psd_xdata[nodeID] = f
                self.psd_ydata[nodeID] = asd

    def handle_pps(self, nodeID, cc, epoch_time):
        try:
            epoch_time_datetime = datetime.datetime.fromtimestamp(epoch_time, tz=datetime.timezone.utc)
        except (OSError, OverflowError, ValueError):
            return
        self.last_cc_epoch[nodeID] = (int(cc), int(epoch_time))
        node_number = self._node_number_from_key(nodeID)
        time_source_label = str(self.node_time_source.get(nodeID, "GNSS") or "GNSS")

        fields = {
            "PPS-time": epoch_time_datetime,
            "PPS-flash-time": epoch_time_datetime,
        }
        if time_source_label.upper() in ("RTC", "TRIG"):
            count = int(self.rtc_mapping_counts.get(nodeID, 0)) + 1
            self.rtc_mapping_counts[nodeID] = count
            fields[PPS_COL] = str(count)
        else:
            fields[PPS_COL] = ""
        self._set_node_fields(nodeID, **fields)
        with self.pps_flash_lock:
            if time_source_label.upper() == "GNSS":
                self.pps_flash_until[nodeID] = epoch_time_datetime + datetime.timedelta(seconds=self.pps_flash_sec)
            else:
                self.pps_flash_until[nodeID] = None

        try:
            self._pps_count += 1
            if time_source_label.upper() in ("RTC", "TRIG"):
                # RTC path: timestamp directly from one CC<->time anchor and 10 MHz assumption.
                self.timestamper[nodeID].set_rtc_anchor(cc, epoch_time)
                ts_, ys = self.timestamper[nodeID].drain_rtc_pending()
            else:
                # GNSS path: interpolate between PPS mappings.
                ts_, ys = self.timestamper[nodeID].push_cc_pps(cc, epoch_time)
            ts = self._time_delay_correction(ts_, node_number)
            if len(ts) > 0:
                self._ingest_timestamped_samples(nodeID, ts, ys)
        except (OSError, OverflowError, ValueError):
            pass
            raise 

    def _ensure_node_row(self, node_id: str) -> None:
        if (self.mesh_status_data['nodeID'] == node_id).any():
            return
        node_num = self._parse_node_number(node_id)
        node_type = self._node_type_from_key(node_id)
        if NodeStatus is not None:
            self.node_status[node_id] = NodeStatus(
                node_id=node_id,
                node_label=node_id,
                connection="waiting",
            )
        self.node_time_source[node_id] = "GNSS"
        self.rtc_mapping_counts[node_id] = 0
        self.last_cc_epoch[node_id] = None
        new_row = pd.DataFrame({
            'Node ID': [node_id],
            'Connection': ['waiting'],
            'Sensor': [''],
            'DAQ Mode': [''],
            'DAQ': [''],
            'Stream': [''],
            SPEED_COL: [''],
            LEVEL_COL: [''],
            'Parent': [''],
            RSSI_COL: [''],
            'Children': [''],
            TIME_SOURCE_COL: [''],
            PPS_COL: [''],
            BAT_COL: [''],
            'CMD': [''],
            'PPS-time': [''],
            'PPS-flash-time': [''],
            'DAQ-time': [''],
            'Parent MAC': [''],
            'Self MAC': [''],
            'nodeID': node_id,
            'ConnRptTime': [None],
            'node_number': [node_num],
            'node_type': [node_type],
        })
        self.mesh_status_data = pd.concat([self.mesh_status_data, new_row], ignore_index=True)

    def merge_sd_files(self) -> None:
        sd_dir = self.sd_stream_dir
        if not os.path.isdir(sd_dir):
            self._ui_log(f"[merge] sd dir missing: {sd_dir}")
            return

        pattern = re.compile(r"^(?P<node>[^-]+)-(?P<ts>\d{4}_\d{2}_\d{2}_\d{2}_\d{2})\.bin$")
        files = []
        for name in os.listdir(sd_dir):
            match = pattern.match(name)
            if not match:
                continue
            node_id = match.group("node")
            try:
                ts = datetime.datetime.strptime(match.group("ts"), "%Y_%m_%d_%H_%M").replace(
                    tzinfo=datetime.timezone.utc
                )
            except ValueError:
                continue
            files.append((node_id, ts, os.path.join(sd_dir, name)))

        if not files:
            self._ui_log("[merge] no sd files found")
            return

        node_ids = sorted({node_id for node_id, _, _ in files})
        for node_id in node_ids:
            self._ensure_node_row(node_id)

        self.init_other_data()
        self._ui_log(f"[merge] merging {len(files)} files for {len(node_ids)} nodes")

        files.sort(key=lambda item: (item[0], item[1]))
        merged_resampled = {node_id: {"t": [], "y": []} for node_id in node_ids}
        merged_ranges = {node_id: {"min": None, "max": None} for node_id in node_ids}
        rec_size = 21
        min_ts = None
        max_ts = None

        for node_id, ts_label, path in files:
            self._ui_log(f"[merge] {node_id} {os.path.basename(path)}")
            node_number = self._node_number_from_key(node_id)
            try:
                with open(path, "rb") as handle:
                    buf = b""
                    while True:
                        chunk = handle.read(rec_size * 1024)
                        if not chunk:
                            break
                        buf += chunk
                        nrec = len(buf) // rec_size
                        if nrec == 0:
                            continue
                        for idx in range(nrec):
                            rec = buf[idx * rec_size : (idx + 1) * rec_size]
                            rec_type = rec[0]
                            cc = struct.unpack_from("<Q", rec, 1)[0]
                            if rec_type == 0:
                                epoch = struct.unpack_from("<q", rec, 9)[0]
                                ts_list, ys = self.timestamper[node_id].push_cc_pps(cc, epoch)
                                ts_list = self._time_delay_correction(ts_list, node_number)
                                if ts_list:
                                    self._update_observed_fs(node_id, ts_list)
                                    with self.plot_mutex[node_id]:
                                        self.timehistory_xdata[node_id] += ts_list
                                        self.timehistory_ydata[node_id] = append(
                                            self.timehistory_ydata[node_id], ys, axis=0
                                        )
                                        trs, yrs = self.resampler[node_id].push(ts_list, ys)
                                        if trs:
                                            merged_resampled[node_id]["t"].extend(trs)
                                            merged_resampled[node_id]["y"].extend(yrs)
                                            node_range = merged_ranges[node_id]
                                            if node_range["min"] is None or trs[0] < node_range["min"]:
                                                node_range["min"] = trs[0]
                                            if node_range["max"] is None or trs[-1] > node_range["max"]:
                                                node_range["max"] = trs[-1]
                                            self.psder[node_id].push(array(yrs), array(trs))
                                            if self.psder[node_id].isUpdated:
                                                f, asd = self.psder[node_id].get_asd()
                                                fs_nom = self.node_fs.get(node_id)
                                                fs_obs = self.node_fs_obs.get(node_id)
                                                if fs_nom and fs_obs:
                                                    f = f * (fs_obs / fs_nom)
                                                self.psd_xdata[node_id] = f
                                                self.psd_ydata[node_id] = asd
                                    if min_ts is None or ts_list[0] < min_ts:
                                        min_ts = ts_list[0]
                                    if max_ts is None or ts_list[-1] > max_ts:
                                        max_ts = ts_list[-1]
                            elif rec_type == 1:
                                ax, ay, az = struct.unpack_from("<fff", rec, 9)
                                self.timestamper[node_id].push_cc_acc([cc, ax, ay, az])
                        buf = buf[nrec * rec_size :]
                    if buf:
                        self._ui_log(f"[merge] {node_id} leftover bytes: {len(buf)}")
            except OSError as exc:
                self._ui_log(f"[merge] failed to read {path}: {exc}")

        chunk_sec = 600
        for node_id, data in merged_resampled.items():
            if not data["t"]:
                continue
            buckets = {}
            for t_, y_ in zip(data["t"], data["y"]):
                ts = int(t_.timestamp())
                grid = (ts // chunk_sec) * chunk_sec
                bucket = buckets.setdefault(grid, {"t": [], "y": []})
                bucket["t"].append(t_)
                bucket["y"].append(y_)
            for grid in sorted(buckets.keys()):
                bucket = buckets[grid]
                if not bucket["t"]:
                    continue
                start_ts = datetime.datetime.fromtimestamp(grid, tz=datetime.timezone.utc)
                name = f"{node_id}-{start_ts.strftime('%Y_%m%d_%H%M')}.hd5"
                path = os.path.join(self.sd_stream_hd5_dir, name)
                df = DataFrame(bucket["y"], columns=["X", "Y", "Z"])
                df.index = to_datetime(bucket["t"])
                df.to_hdf(path, key="df", mode="w")
                self._ui_log(f"[merge] hd5 saved: {path}")

        # merged file across nodes
        merged_frames = []
        for node_id, data in merged_resampled.items():
            if not data["t"]:
                continue
            df_node = DataFrame(data["y"], columns=["X", "Y", "Z"])
            df_node.index = to_datetime(data["t"])
            df_node = df_node.rename(columns={
                "X": f"{node_id}-X",
                "Y": f"{node_id}-Y",
                "Z": f"{node_id}-Z",
            })
            merged_frames.append(df_node)

        if merged_frames:
            merged_df = pd.concat(merged_frames, axis=1).dropna().sort_index()
            if not merged_df.empty:
                os.makedirs(self.sd_stream_merged_dir, exist_ok=True)
                base_name = os.path.join(
                    self.sd_stream_merged_dir,
                    "accm-{}".format(merged_df.index[0].strftime("%Y_%m%d_%H%M")),
                )
                hd5_path = f"{base_name}.hd5"
                merged_df.to_hdf(hd5_path, key="df")
                self._ui_log(f"[merge] merged hd5 saved: {hd5_path}")
                # export MAT alongside merged hd5
                self._build_merged_plot_data(merged_df)
                self._export_merged_mat(merged_df, base_name)
        if min_ts and max_ts:
            self.full_range_xlim = [min_ts, max_ts]
            self.timehistory_xlim = [min_ts, max_ts]
            self.merge_full_range = True
        self.plot_dirty = True
        self.plot_dirty_version += 1
        self._plot_dirty_set += 1
        self.gui_dirty = True
        self._ui_log("[merge] complete")

    def _rate_logger(self):
        while True:
            time.sleep(1.0)
            if self.enable_rate_logging:
                self._ui_log(
                    f"[rate] pps/s={self._pps_count} "
                    f"timestamped_samples/s={self._ts_count} "
                    f"plot_dirty={self.plot_dirty} "
                    f"plot_dirty_set/s={self._plot_dirty_set} "
                    f"plot_version={self.plot_dirty_version}"
                )
            self._pps_count = 0
            self._ts_count = 0
            self._plot_dirty_set = 0
            if self.enable_plot_logging:
                self._log_plot_state()

    def _log_plot_state(self):
        now = time.monotonic()
        if now - self._last_plot_debug < 1.0:
            return
        self._last_plot_debug = now
        max_node = None
        max_len = 0
        max_last = None
        for node_id, xs in self.timehistory_xdata.items():
            try:
                n = len(xs)
                if n > max_len:
                    max_len = n
                    max_node = node_id
                    max_last = xs[-1] if n else None
            except Exception:
                continue
        if max_node is not None:
            print(f"[plot] node={max_node} points={max_len} last={max_last}")
        else:
            print("[plot] no timehistory_xdata")

    def handle_acc_sample(self, nodeID, cc, ax, ay, az):
        self._set_node_fields(nodeID, **{"DAQ-time": datetime.datetime.now()})

        node_number = self._node_number_from_key(nodeID)
        acc_vec = [ax, ay, az]

        time_source_label = str(self.node_time_source.get(nodeID, "GNSS") or "GNSS").upper()
        if time_source_label in ("RTC", "TRIG"):
            ts, ys = self.timestamper[nodeID].push_cc_acc_rtc([cc, acc_vec[0], acc_vec[1], acc_vec[2]])
            if len(ts) > 0:
                ts = self._time_delay_correction(ts, node_number)
                self._ingest_timestamped_samples(nodeID, ts, ys)
            return

        self.timestamper[nodeID].push_cc_acc([cc, acc_vec[0], acc_vec[1], acc_vec[2]])

    def _sd_stream_path(self, node_id, file_time):
        ts = datetime.datetime.fromtimestamp(file_time, tz=datetime.timezone.utc)
        name = ts.strftime("%Y_%m_%d_%H_%M")
        return os.path.join(self.sd_stream_dir, f"{node_id}-{name}.bin")

    def handle_sd_chunk(self, node_id, file_time, offset, data: bytes):
        key = (node_id, file_time)
        path = self._sd_stream_path(node_id, file_time)
        with self._sd_stream_lock:
            fh = self._sd_stream_handles.get(key)
            if fh is None:
                mode = "r+b" if os.path.exists(path) else "wb"
                fh = open(path, mode)
                self._sd_stream_handles[key] = fh
            fh.seek(offset)
            fh.write(data)
        if node_id not in self._sd_stream_active:
            self._sd_stream_active.add(node_id)
            self._set_node_fields(node_id, **{"CMD": "SD streaming"})

    def handle_sd_done(self, node_id, file_time, status: int):
        with self._sd_stream_lock:
            if status == 0:
                key = (node_id, file_time)
                fh = self._sd_stream_handles.pop(key, None)
                if fh:
                    fh.close()
            elif status == 1:
                keys = [k for k in self._sd_stream_handles.keys() if k[0] == node_id]
                for key in keys:
                    fh = self._sd_stream_handles.pop(key, None)
                    if fh:
                        fh.close()
        if status == 1:
            self._sd_stream_active.discard(node_id)
            self._set_node_fields(node_id, **{"CMD": "SD stream done"})

    def update_gnss_position(self, node_id, lat, lon, fix_mode, valid):
        try:
            lat_f = float(lat)
            lon_f = float(lon)
        except (TypeError, ValueError):
            return
        self.gnss_positions[node_id] = {
            "lat": lat_f,
            "lon": lon_f,
            "fix_mode": int(fix_mode),
            "valid": int(valid),
            "ts": datetime.datetime.now(datetime.timezone.utc),
        }

    def notifying_node_identified_parent(self, nodeID, parent_node_number):

        logger.info('notifying parent = %s', parent_node_number)
        msg = struct.pack('=BHBB', CmdType.NOTIFY_PARENT, parent_node_number, 0, 0)
        self.controller.mesh.sockets[nodeID].send(msg)
        return
  
    def notifying_node_identified_children(self, nodeID, child_nodeIDs):

        # NOTIFYING THE NODE OF CHILDREN
        logger.info('notifying children')
        children_bits = 0
        for child_nodeID in child_nodeIDs:
            children_bits |= (1 << (child_nodeID-1))
        children_bits &= 0xFFFFFFFF
        msg = struct.pack('=BI', CmdType.NOTIFY_CHILDREN, children_bits)
        self.controller.mesh.sockets[nodeID].send(msg)
        return
    
    def isParent(self, self_MAC, parent_MAC):

        self_mac =   [int(x, 16) for x in   self_MAC.split(":")]
        parent_mac = [int(x, 16) for x in parent_MAC.split(":")]
        self_mac[5] += 1
        return self_mac == parent_mac

    def handle_conn_report(self, nodeID, level, parent_mac, self_mac, rssi, acc_model: int = 0, daq_mode: int = 0, daq_on: int = 0, stream_status: int = 0, bat_vol: float | None = None, time_source: int = 0, notify: bool = True):
        logger.info('Conn Rpt: L={}, par_MAC={}, self_MAC={}, RSSI={}'.format(level, parent_mac, self_mac, rssi))

        condition = self._node_condition(nodeID)
        if condition is None:
            self._ensure_node_row(nodeID)
            condition = self._node_condition(nodeID)
            if condition is None:
                return

        acc_model_label = self._acc_model_label(acc_model)
        daq_mode_label = self._format_daq_mode(acc_model_label, daq_mode) if acc_model_label else ""
        daq_status = "On" if int(daq_on) == 1 else "Off"
        stream_label = {0: "Off", 1: "RT", 2: "SD"}.get(int(stream_status), "")
        time_source_label = "GNSS"
        if int(time_source) == 1:
            time_source_label = "RTC"
        elif int(time_source) == 2:
            time_source_label = "TRIG"
        prev_time_source = str(self.node_time_source.get(nodeID, "GNSS") or "GNSS")
        self.node_time_source[nodeID] = time_source_label
        status_obj = self.node_status.get(nodeID)
        if status_obj is not None:
            status_obj.time_source = time_source_label
        prev_connection = self.mesh_status_data.loc[condition, "Connection"].iloc[0]
        initial_connect = prev_connection != "connected"
        fs = self._extract_fs_from_daq_label(daq_mode_label)
        if fs:
            self._update_sampling_rate(nodeID, fs)
        fields = {
            "Connection": "connected",
            "ConnRptTime": datetime.datetime.now(),
            LEVEL_COL: level,
            "Parent MAC": parent_mac,
            "Self MAC": self_mac,
            RSSI_COL: rssi,
            "Sensor": acc_model_label,
            "DAQ Mode": daq_mode_label,
            "DAQ": daq_status,
            "Stream": stream_label,
            TIME_SOURCE_COL: time_source_label,
        }
        if time_source_label in ("RTC", "TRIG"):
            if prev_time_source != time_source_label:
                self.rtc_mapping_counts[nodeID] = 0
                timestamper = self.timestamper.get(nodeID)
                if timestamper is not None:
                    timestamper.clear_all_state()
                    last_map = self.last_cc_epoch.get(nodeID)
                    if last_map is not None:
                        last_cc, last_epoch = last_map
                        timestamper.set_rtc_anchor(last_cc, last_epoch)
            count = int(self.rtc_mapping_counts.get(nodeID, 0))
            fields[PPS_COL] = str(count) if count > 0 else ""
        else:
            self.rtc_mapping_counts[nodeID] = 0
            if prev_time_source != "GNSS":
                timestamper = self.timestamper.get(nodeID)
                if timestamper is not None:
                    timestamper.clear_all_state()
            fields[PPS_COL] = ""
        if bat_vol is not None:
            try:
                fields[BAT_COL] = f"{float(bat_vol):3.1f}"
            except (TypeError, ValueError):
                pass
        if initial_connect:
            fields[SPEED_COL] = "0.0"
        self._set_node_fields(
            nodeID,
            **fields,
        )
        if initial_connect:
            self.speed_last_value[nodeID] = 0.0
            self.speed_last_rx[nodeID] = None

        parent_node_key = None
        parent_node_number = None
        parent_label = None
        if level == 1:
            parent_label = 'AP'
        else:
            for index, row in self.mesh_status_data.iterrows():
                if len(row['Self MAC']) > 0 and self.isParent(row['Self MAC'], parent_mac):
                    parent_node_key = row['nodeID']
                    parent_node_number = row.get('node_number')
                    parent_label = row['Node ID']
                    break
        if parent_label is not None:
            self.mesh_status_data.loc[condition, 'Parent'] = parent_label
            if notify:
                if parent_node_number is not None:
                    try:
                        parent_node_number = int(parent_node_number)
                    except (TypeError, ValueError):
                        parent_node_number = None
                if parent_node_number is not None:
                    self.notifying_node_identified_parent(nodeID, parent_node_number)

        child_nodeIDs = []
        for index, row in self.mesh_status_data.iterrows():
            if len(row['Parent MAC']) > 0 and self.isParent(self_mac, row['Parent MAC']):
                try:
                    child_nodeIDs.append(int(row['node_number']))
                except (TypeError, ValueError):
                    pass
        if len(child_nodeIDs) > 0:
            child_NodeIDs = ' '.join(str(x) for x in child_nodeIDs)
            self.mesh_status_data.loc[condition, 'Children'] = child_NodeIDs
            if notify:
                self.notifying_node_identified_children(nodeID, child_nodeIDs)

    def on_timer(self):
        while True:
            time.sleep(5)
            # logger.debug('on_timer() executed.')        
            t_now = datetime.datetime.now()
            for index, row in self.mesh_status_data.iterrows():
                # logger.debug(row['ConnRptTime'] != None)
                if row['ConnRptTime'] != None:
                    dT = t_now - row['ConnRptTime']
                    # logger.debug(dT.seconds)
                    if dT.seconds > 10:
                        self.mesh_status_data.loc[index, 'Connection'] = 'disconnected'
                        for col in [
                            "Sensor",
                            "DAQ Mode",
                            "DAQ",
                            "Stream",
                            SPEED_COL,
                            LEVEL_COL,
                            "Parent",
                            RSSI_COL,
                            "Children",
                            TIME_SOURCE_COL,
                            BAT_COL,
                            "CMD",
                        ]:
                            if col in self.mesh_status_data.columns:
                                self.mesh_status_data.loc[index, col] = ''
                        if PPS_COL in self.mesh_status_data.columns:
                            self.mesh_status_data.loc[index, PPS_COL] = ''
                        node_id = row['nodeID']
                        self.node_time_source[node_id] = "GNSS"
                        self.rtc_mapping_counts[node_id] = 0
                        self.last_cc_epoch[node_id] = None
                        timestamper = self.timestamper.get(node_id)
                        if timestamper is not None:
                            timestamper.clear_all_state()
                        self.mesh_status_data.loc[index, 'PPS-time'] = ''
                        self.mesh_status_data.loc[index, 'PPS-flash-time'] = ''
                        self.mesh_status_data.loc[index, 'Parent MAC'] = ''
                        self.mesh_status_data.loc[index, 'Self MAC'] = ''
                        self.mesh_status_data.loc[index, 'ConnRptTime'] = None
                        self.mesh_status_data.loc[index, 'DAQ-time'] = ''
                        hist = self.speed_hist.get(row['nodeID'])
                        if hist is not None:
                            hist.clear()
                        #self.mesh_status_data.loc[index, 'Children_nodeIDs'] = []
           
    # def getTimeWindow(self, t1):
    #     """Time window with 30 seconds span presenting the latest measurement

    #     Args:
    #         t1 (datetime): the latest timestamp 

    #     Returns:
    #         [ts, te]: datetime ts, te containing t1 in the middle. te-t1 = 30 secs
    #     """
    #     r =    [datetime.datetime.fromtimestamp(floor(t1.timestamp() / 30) * 30), 
    #             datetime.datetime.fromtimestamp(floor(t1.timestamp() / 30 + 1) * 30)]
    #     return r
                
    def _build_merged_plot_data(self, df: pd.DataFrame) -> None:
        self.merged_timehistory_xdata = {}
        self.merged_timehistory_ydata = {}
        self.merged_timehistory_xlim = []
        self.merged_psd_xdata = []
        self.merged_psd_ydata = {}
        self.merged_node_ids = []
        self.merged_fs = None

        if df is None or df.empty:
            return

        try:
            times = pd.to_datetime(df.index).to_pydatetime().tolist()
        except Exception:
            return

        if times:
            self.merged_timehistory_xlim = [times[0], times[-1]]

        node_ids = sorted({col.split('-')[0] for col in df.columns if '-' in col})
        self.merged_node_ids = node_ids

        fs = 50.0
        try:
            dt_series = pd.to_datetime(df.index).to_series().diff().dt.total_seconds().dropna()
            if not dt_series.empty:
                median_dt = float(dt_series.median())
                if median_dt > 0:
                    fs = 1.0 / median_dt
        except Exception:
            fs = 50.0
        self.merged_fs = fs

        for node_id in node_ids:
            cols = [f"{node_id}-X", f"{node_id}-Y", f"{node_id}-Z"]
            if not all(col in df.columns for col in cols):
                continue
            ydata = df[cols].to_numpy()
            self.merged_timehistory_xdata[node_id] = times
            self.merged_timehistory_ydata[node_id] = ydata

            try:
                psder = psd_recursive.PSD_Recursive(1024, fs)
                psder.push(ydata, ts=np.array(times))
                f, asd = psder.get_asd()
                self.merged_psd_xdata = f
                self.merged_psd_ydata[node_id] = asd
            except Exception:
                continue

    def merge_rt_streamed_files(self):

        global df
        raw_data_dir = RT_STREAM_HD5_DIR
        NodeIDs = []

        if not os.path.isdir(raw_data_dir):
            self._ui_log(f"rt-streamed folder missing: {raw_data_dir}")
            return

        entries = os.listdir(raw_data_dir)
        files = [f for f in entries if f.endswith('.hd5')]

        # IDENTIFY NODE IDs
        for file in files:
            NodeIDs.append(file.split('-')[1].split('.')[0])
        NodeIDs = sorted(set(NodeIDs))

        # READ AND MERGE ALL RAW DATA FILES
        dfs = []
        msg = "reading files ... "
        self._ui_log(msg)
                
        for NodeID in NodeIDs:
            dfs_ = []
            files_ = [f for f in entries if f.endswith('{}.hd5'.format(NodeID))]
            for file_ in files_:
                msg = f"reading file {file_} ... "
                self._ui_log(msg)
                dfs_.append(pd.read_hdf(os.path.join(raw_data_dir, file_)))
            df_ = pd.concat(dfs_, axis = 0)
            df_ = df_.rename(columns={
                                    'X': '{}-X'.format(NodeID),
                                    'Y': '{}-Y'.format(NodeID),
                                    'Z': '{}-Z'.format(NodeID)
                                                    })
            dfs.append(df_)

        df = pd.concat(dfs, axis = 1)
        df = df.dropna()
        df = df.sort_index()
        self._build_merged_plot_data(df)

        # df.plot(figsize=(24, 6))
        # show()

        os.makedirs(RT_STREAM_MERGED_DIR, exist_ok=True)
        base_name = os.path.join(RT_STREAM_MERGED_DIR, "accm-{}".format(df.index[0].strftime("%Y_%m%d_%H%M")))
        hd5_path = f"{base_name}.hd5"
        df.to_hdf(hd5_path, key="df")
        msg = f"merged file written to {hd5_path} "
        self._ui_log(msg)
        self._export_merged_mat(df, base_name)

    def clear_rt_streamed_files(self) -> None:
        self._clear_stream_dir(RT_STREAM_HD5_DIR, "[rt-clear]")

    def clear_sd_streamed_files(self) -> None:
        self._clear_stream_dir(SD_STREAM_BIN_DIR, "[sd-clear]")
        self._clear_stream_dir(SD_STREAM_HD5_DIR, "[sd-clear]")

    def _clear_stream_dir(self, directory: str, tag: str) -> None:
        if not os.path.isdir(directory):
            self._ui_log(f"{tag} folder missing: {directory}")
            return
        removed = 0
        errors = 0
        for name in os.listdir(directory):
            path = os.path.join(directory, name)
            if not os.path.isfile(path):
                continue
            try:
                os.remove(path)
                removed += 1
            except Exception:
                errors += 1
        self._ui_log(f"{tag} removed {removed} files from {directory} (errors={errors})")

    def _export_merged_mat(self, df: pd.DataFrame, base_path: str) -> None:
        if df is None or df.empty:
            self._ui_log("[merge] no data; skipping MAT export")
            return
        mat_path = base_path if base_path.endswith(".mat") else f"{base_path}.mat"
        try:
            idx = pd.to_datetime(df.index)
            tz = "UTC"
            if getattr(idx, "tz", None) is not None:
                idx = idx.tz_convert("UTC")
            else:
                tz = "UTC (naive)"
            time_iso = [t.isoformat() for t in idx.to_pydatetime()]
            time_posix = (idx.view("int64") / 1e9).astype(float)
            fs = self.merged_fs if self.merged_fs is not None else 0.0
            columns = df.columns.tolist()
            sanitized = []
            name_map = {}
            for col in columns:
                base = re.sub(r"[^0-9A-Za-z_]", "_", str(col))
                if base == "":
                    base = "var"
                if base[0].isdigit():
                    base = f"v_{base}"
                name = base
                suffix = 1
                while name in name_map.values():
                    name = f"{base}_{suffix}"
                    suffix += 1
                name_map[col] = name
                sanitized.append(name)

            table_struct = {"Time": time_posix}
            data = df.to_numpy()
            for idx_col, col in enumerate(columns):
                table_struct[name_map[col]] = data[:, idx_col]

            meta_struct = {
                "columns_original": np.array(columns, dtype=object),
                "columns_sanitized": np.array(sanitized, dtype=object),
                "time_iso": np.array(time_iso, dtype=object),
                "tz": tz,
                "fs_hz": float(fs),
                "row_time_key": "Time",
            }

            mat_dict = {
                "data": table_struct,
                "meta": meta_struct,
            }
            if h5s is not None:
                h5s.savemat(
                    mat_path,
                    mat_dict,
                    format="7.3",
                    matlab_compatible=True,
                )
                self._ui_log(f"[merge] mat (v7.3) written: {mat_path}")
            elif sio is not None:
                sio.savemat(mat_path, mat_dict, do_compression=True)
                self._ui_log(f"[merge] mat (v5) written: {mat_path}")
            else:
                self._ui_log("[merge] no MAT writer available; install hdf5storage")
        except Exception as exc:
            self._ui_log(f"[merge] failed mat export: {exc}")

    def load_latest_merged_rt(self) -> None:
        self._load_latest_merged(RT_STREAM_MERGED_DIR, "[rt-plot]")

    def load_latest_merged_sd(self) -> None:
        self._load_latest_merged(self.sd_stream_merged_dir, "[sd-plot]")

    def _load_latest_merged(self, directory: str, tag: str) -> None:
        if not os.path.isdir(directory):
            self._ui_log(f"{tag} folder missing: {directory}")
            return
        files = [os.path.join(directory, f) for f in os.listdir(directory) if f.endswith(".hd5")]
        if not files:
            self._ui_log(f"{tag} no merged files found")
            return
        latest = max(files, key=lambda p: os.path.getmtime(p))
        try:
            df = pd.read_hdf(latest)
        except Exception as exc:
            self._ui_log(f"{tag} failed to read {latest}: {exc}")
            return
        if df is None or df.empty:
            self._ui_log(f"{tag} empty file: {latest}")
            return
        df = df.dropna().sort_index()
        self._build_merged_plot_data(df)
        self._ui_log(f"{tag} loaded {os.path.basename(latest)}")

    def update_mesh_status_data(self, nodeID, column, msg):
        self._set_node_fields(nodeID, **{column: msg})

    def _ui_log(self, msg: str) -> None:
        if self.ui_log is not None:
            self.ui_log(msg)
        else:
            logger.info(msg)

    def _node_condition(self, nodeID):
        condition = self.mesh_status_data['nodeID'] == nodeID
        if not condition.any():
            return None
        return condition

    def _set_node_fields(self, nodeID, mark_dirty: bool = True, **fields):
        condition = self._node_condition(nodeID)
        if condition is None:
            # Ensure late-arriving nodes (e.g., PPS before status) get a row.
            self._ensure_node_row(nodeID)
            condition = self._node_condition(nodeID)
            if condition is None:
                return False
        for column, value in fields.items():
            self.mesh_status_data.loc[condition, column] = value
        status = self.node_status.get(nodeID)
        if status is not None:
            column_map = {
                "Node ID": "node_label",
                "Connection": "connection",
                SPEED_COL: "speed_kb_s",
                LEVEL_COL: "level",
                "Parent": "parent",
                RSSI_COL: "rssi_db",
                "Children": "children",
                TIME_SOURCE_COL: "time_source",
                PPS_COL: "pps_age",
                "CMD": "cmd",
                "PPS-time": "pps_time",
                "PPS-flash-time": "pps_flash_time",
                "DAQ-time": "daq_time",
                "Parent MAC": "parent_mac",
                "Self MAC": "self_mac",
                "ConnRptTime": "conn_rpt_time",
            }
            for column, value in fields.items():
                attr = column_map.get(column)
                if not attr:
                    continue
                if attr == "speed_kb_s":
                    if value == "" or value is None:
                        setattr(status, attr, None)
                    else:
                        try:
                            setattr(status, attr, float(value))
                        except (TypeError, ValueError):
                            setattr(status, attr, None)
                elif attr in ("level", "rssi_db"):
                    if value == "" or value is None:
                        setattr(status, attr, None)
                    else:
                        try:
                            setattr(status, attr, int(value))
                        except (TypeError, ValueError):
                            setattr(status, attr, None)
                else:
                    setattr(status, attr, value)
        if mark_dirty:
            self.gui_dirty = True
        return True

# def clear():
#     # DELETE TEMPORARIL FILES
#     for file in glob.glob("data2/*.hd5"):
#         try:
#             os.remove(file)
#         except Exception as e:
#             logger.error(f"Error deleting file {file}: {e}")
