# PSD/ASD CALCULATION CLASS: RECURSIVE VERSION 

# AUTHOR: 
#   K Y KOO (k.y.koo@exeter.ac.uk)
#
# HISTORY
#   - Initial version v1 on 12 Sep 2024
#


from numpy import exp, empty, sqrt, mean, zeros, random, sqrt, arange, sin, stack, pi, append
from scipy.signal import windows
from scipy.fft import fft
from matplotlib.pyplot import figure, clf, semilogy, grid, xlabel, ylabel, legend


class PSD_Recursive():

    def __init__(self, nfft, fs):
        
        self.nfft = nfft
        self.freq  = arange(0, fs/2, fs/nfft)
        self.dt = 1/fs
        self.X = empty((0, 3), dtype=float)
        self.Xf = zeros((nfft, 3), dtype=float)
        self.window = windows.hann(self.nfft) / sqrt(mean(windows.hann(self.nfft)**2))
        self.Lambda = 0.01
        self.w = [exp(-self.Lambda), 1 - exp(-self.Lambda)] # exponential weighting factor
        self.n = 1 # No of terms used to get the weighted averaged PSD
        self.isUpdated = False
        self.last_sample_time = None
        self.last_update_time = None
        self.sample_dt = self.dt

    def push(self, x, ts=None):

        # append
        self.X = append(self.X, x, axis = 0)
        # print(ts[-1])
        if ts is not None and len(ts) >= 1:
            # print(ts[-1])
            self.last_sample_time = ts[-1]
            if len(ts) >= 2:
                self.sample_dt = (ts[-1] - ts[-2]).total_seconds()

        # if len() > nfft, perform fft 
        while self.X.shape[0] > self.nfft:
            
            x_ = self.X[:self.nfft, :].T * self.window
            x_f = fft(x_).T
            # add the result to the Xf with a forgetting factor exp(-lambda)
            weights = self.get_weights()
            self.Xf = self.Xf * weights[0] + abs(x_f)**2 * weights[1]
            self.X = self.X[self.nfft:, :]
            self.isUpdated = True
            if ts is not None and len(ts) > 0:
                self.last_update_time = ts[-1]
        # pass
    
    def get_weights(self):
        
        #          (n-1)/n * exp(-lambda)                 , 1 - (n-1)/n*exp(-lambda)
        weights = [(self.n - 1)/self.n * exp(-self.Lambda), 1 - (self.n - 1)/self.n * exp(-self.Lambda)]
        self.n += 1
        return weights
    
    def get_psd(self):

        self.isUpdated = False
        return self.freq, self.Xf[:int(self.nfft/2), :] * self.dt * 2 / self.nfft
    
    def get_asd(self):

        f, psd = self.get_psd()
        return f, sqrt(psd)

    def seconds_until_next_update(self):
        # Estimate time until enough samples for next FFT window (data-time based).
        remaining = max(self.nfft - self.X.shape[0], 0)
        dt = self.sample_dt if self.sample_dt else self.dt
        return remaining * dt

    def set_fs(self, fs):
        try:
            fs_val = float(fs)
        except (TypeError, ValueError):
            return
        if fs_val <= 0:
            return
        self.freq = arange(0, fs_val / 2, fs_val / self.nfft)
        self.dt = 1 / fs_val
        self.X = empty((0, 3), dtype=float)
        self.Xf = zeros((self.nfft, 3), dtype=float)
        self.window = windows.hann(self.nfft) / sqrt(mean(windows.hann(self.nfft) ** 2))
        self.n = 1
        self.isUpdated = False
        self.last_sample_time = None
        self.last_update_time = None
        self.sample_dt = self.dt

    
        

        

if __name__ == '__main__':

    rng = random.default_rng()

    fs = 10e3
    N = 1e5
    amp = 2*sqrt(2)
    freq = 1234.0
    noise_power = 0.001 * fs / 2
    time = arange(N) / fs
    x = amp*sin(2*pi*freq*time)
    x += rng.normal(scale=sqrt(noise_power), size=time.shape)
    y = amp*sin(2*pi*1000*time)
    z = amp*sin(2*pi*2000*time)
    y += rng.normal(scale=sqrt(noise_power), size=time.shape)
    z += rng.normal(scale=sqrt(noise_power), size=time.shape)

    X = stack((x, y, z), axis = 0).T

    NFFT = 1024

    psd = PSD_Recursive(NFFT, fs)
    for i in range(int(X.shape[0]/2)):
        psd.push(X[2*i:2*(i+1), :])

    figure()
    clf()
    f, psd = psd.get_psd()

    semilogy(f, psd, label=['x', 'y', 'z'])
    grid(True)
    xlabel('Frequency (Hz)')
    ylabel('PSD (g^2/Hz)')
    legend()
