from numpy import ceil
import datetime
from numpy import floor 
import logging
import numpy as np

logger = logging.getLogger(__name__)


class Resampling:
    def __init__(self, SamplingFrequency):
        self.Fs = SamplingFrequency   # Hz
        self.Ts = int(1000/SamplingFrequency)  # msec
        self.t0 = -1
        self.t1 = -1
        self.tk = -1
        self.y0 = []
        self.y1 = []

    def get_fs(self):
        logger.info("fs={}".format(self.Fs))

    def set_fs(self, sampling_frequency):
        try:
            fs = float(sampling_frequency)
        except (TypeError, ValueError):
            return
        if fs <= 0:
            return
        self.Fs = fs
        self.Ts = int(1000 / fs)
        # Reset state to avoid mixing old timing grid with new Fs
        self.t0 = -1
        self.t1 = -1
        self.tk = -1
        self.y0 = []
        self.y1 = []
    
    @staticmethod
    def _as_datetime(value):
        if isinstance(value, datetime.datetime):
            return value
        if hasattr(value, "to_pydatetime"):
            try:
                return value.to_pydatetime()
            except Exception:
                pass
        if isinstance(value, np.datetime64):
            try:
                ts = value.astype("datetime64[us]").astype("int64") / 1e6
                return datetime.datetime.fromtimestamp(ts, tz=datetime.timezone.utc)
            except Exception:
                return None
        try:
            return datetime.datetime.fromtimestamp(float(value), tz=datetime.timezone.utc)
        except Exception:
            return None

    def _coerce_state_time(self, value):
        if value == -1:
            return -1
        if isinstance(value, datetime.datetime):
            return value
        coerced = self._as_datetime(value)
        return coerced if coerced is not None else -1

    def get_next_grid_time(self, t):
        if not isinstance(t, datetime.datetime):
            t = self._as_datetime(t)
            if t is None:
                return None
        tz = t.tzinfo or datetime.timezone.utc
        epoch = int(t.timestamp())
        usec = t.microsecond
        usec_k = (int(usec / (self.Ts * 1000)) + 1) * (self.Ts * 1000)
        if usec_k >= 1000000:
            epoch += 1
            usec_k -= 1000000
        tk = datetime.datetime.fromtimestamp(epoch, tz=tz)
        tk = tk.replace(microsecond = usec_k)
        return tk

    def push(self, t, y):
        t_rs = []
        y_rs = []
        for t_, y_ in zip(t, y):
            t_dt = t_ if isinstance(t_, datetime.datetime) else self._as_datetime(t_)
            if t_dt is None:
                continue
            t_ = t_dt
            self.t0 = self._coerce_state_time(self.t0)
            self.t1 = self._coerce_state_time(self.t1)
            self.tk = self._coerce_state_time(self.tk)
            if self.t0 == -1:
                self.t0 = t_
                self.y0 = y_
                self.tk = self.get_next_grid_time(t_)
                if self.tk is None:
                    self.t0 = -1
                    continue
                # starting tk logging disabled per request
            elif self.tk != -1 and t_ < self.tk:
                self.t0 = t_
                self.y0 = y_
            else:
                self.t1 = t_
                self.y1 = y_
                dt = (self.t1 - self.t0).total_seconds()
                if dt <= 0:
                    self.t0 = self.t1
                    self.y0 = self.y1
                    continue
                while self.tk != -1 and self.tk < self.t1:
                    dt0 = (self.tk - self.t0).total_seconds()
                    dt1 = (self.t1 - self.tk).total_seconds()
                    yk = [y0i * dt1/dt + y1i * dt0/dt for y0i, y1i in zip(self.y0, self.y1)]
                    y_rs.append(yk)
                    # convert timestamp float to datetime
                    t_rs.append(self.tk)
                    # self.tk  += datetime.timedelta(milliseconds = self.Ts)
                    self.tk  = self.get_next_grid_time(self.tk)
                    if self.tk is None:
                        self.tk = -1
                        break
                self.t0 = self.t1
                self.y0 = self.y1

        return t_rs, y_rs





if __name__ == '__main__':

    # TEST 1 
    # a = resampling(100)
    # b = resampling(200)
    # a.get_fs()
    # b.get_fs()

    # TEST 2
    # buf = {}
    # buf[1] = resampling(10)
    # buf[2] = resampling(20)
    # for key in buf.keys():
    #     buf[key].get_fs()

    # # TEST 3
    # if 0:
    #     from numpy import *
    #     from matplotlib.pyplot import *
    #     xi = sort(random.rand(210,1) * 0.5, axis=0)
    #     yi = hstack((sin(2*pi*1*xi), cos(2*pi*1*xi)))
    #     # yi = sin(2*pi*1*xi)
    #     Fs = 70
    #     # print(xi)
    #     TK = []
    #     VK = []
    #     resampler = resampling(Fs)
    #     for idx in range(int(xi.shape[0]/2)):
    #         # print(xi[idx, 0])
    #         t_, v_ = resampler.push(xi[2*idx:2*idx + 1, 0], list(yi[2*idx:2*idx + 1,:]))
    #         for idx, t in enumerate(t_):
    #             TK.append(t_[idx])
    #             VK.append(v_[idx])
    #     TK = array(TK)
    #     VK = array(VK)
    #     # print(TK)
    #     # ion()
    #     figure(1)
    #     # clf()
    #     plot(xi, yi, '.')
    #     plot(TK, VK, 'o-')
    #     show()
    
    # TEST 4
    if 1:
        import datetime 
        from numpy import *
        from matplotlib.pyplot import *

        T = []
        Y = []

        resampler = resampling(62.5)
        t = [datetime.datetime(2024,1,1,0,0,0, i*1000) for i in range(0, 100, 20)]
        y = [[j, j+1] for j in range(5)]
        
        tr, yr = resampler.push(t, y)
        T += tr
        Y += yr

        for t_ in T:
            print(t_)


        figure(1)
        # ion()
        plot(t,y, '.')
        plot(T, Y, 'o-')
        show()
        

        
    
