from queue import Queue
try:
    from . import config
except ImportError:
    import config

Mesh2GUI = Queue(maxsize = 1000)
Mesh2Storage = Queue(maxsize = 1000)
RemoCons = []
for i in range(config.NNODES):
    RemoCons.append(Queue(maxsize = 10))   
