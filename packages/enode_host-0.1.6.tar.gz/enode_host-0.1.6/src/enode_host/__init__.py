"""Host-side utilities for interacting with the ESP-IDF firmware."""
