import argparse
import asyncio
import contextlib
import datetime as dt
import configparser
import logging
import os
import sys
from pathlib import Path
from typing import List, Optional

from .async_socket import run_client, run_server
from .protocol import (
    Mode,
    TimeSource,
    Toggle,
    build_change_time_source,
    build_realtime_stream,
    build_sd_stream_start,
    build_sd_stream_stop,
    build_sd_clear,
    build_set_mode,
    build_shutdown,
    build_start_daq,
    build_stop_daq,
)


def build_command_from_tokens(tokens: List[str]) -> Optional[bytes]:
    if not tokens:
        return None
    cmd = tokens[0].lower()
    if cmd == "start_daq":
        return build_start_daq()
    if cmd == "stop_daq":
        return build_stop_daq()
    if cmd == "set_mode":
        if len(tokens) < 2:
            raise ValueError("set_mode requires realtime|past")
        mode_token = tokens[1].lower()
        if mode_token == "realtime":
            mode = Mode.REALTIME
        elif mode_token == "past":
            mode = Mode.PAST
        else:
            raise ValueError("set_mode requires realtime|past")
        return build_set_mode(mode)
    if cmd == "realtime_stream":
        if len(tokens) < 2:
            raise ValueError("realtime_stream requires start|stop")
        toggle = Toggle.START if tokens[1].lower() == "start" else Toggle.STOP
        return build_realtime_stream(toggle)
    if cmd == "sd_stream":
        if len(tokens) < 2:
            raise ValueError("sd_stream requires start|stop")
        if tokens[1].lower() == "start":
            if len(tokens) < 3:
                raise ValueError("sd_stream start requires hours")
            return build_sd_stream_start(int(tokens[2]))
        return build_sd_stream_stop()
    if cmd == "sd_clear":
        return build_sd_clear()
    if cmd == "shutdown":
        return build_shutdown()
    if cmd == "change_time_source":
        if len(tokens) < 2:
            raise ValueError("change_time_source requires gnss|rtc|trig")
        source_token = tokens[1].lower()
        if source_token == "gnss":
            return build_change_time_source(TimeSource.GNSS)
        if source_token == "rtc":
            return build_change_time_source(TimeSource.RTC)
        if source_token == "trig":
            return build_change_time_source(TimeSource.TRIG)
        raise ValueError("change_time_source requires gnss|rtc|trig")
    raise ValueError(f"unknown command: {cmd}")


def _is_truthy(value: Optional[str]) -> bool:
    if not value:
        return False
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def _setup_logging() -> None:
    config = configparser.ConfigParser()
    log_date = dt.datetime.now().strftime("%Y-%m%d")
    log_name = f"enode-host-{log_date}.log"
    repo_root = Path(__file__).resolve().parents[3]
    logs_dir = repo_root / "logs"
    try:
        logs_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        print(f"[log] failed to create logs dir: {logs_dir} ({exc})", file=sys.stderr)
        return

    log_path = logs_dir / log_name
    log_format = "%(asctime)s %(levelname)s %(name)s: %(message)s"
    formatter = logging.Formatter(log_format, datefmt="%Y-%m-%d %H:%M:%S")

    root = logging.getLogger()
    root.setLevel(logging.INFO)

    config_candidates = [Path.cwd() / "config.ini", repo_root / "python" / "config.ini"]
    config.read([str(path) for path in config_candidates if path.exists()])
    file_pps = config.getboolean("Logging", "file_pps", fallback=True)
    file_conn_rpt = config.getboolean("Logging", "file_conn_rpt", fallback=True)
    console_pps = config.getboolean("Logging", "terminal_pps", fallback=True)
    console_conn_rpt = config.getboolean("Logging", "terminal_conn_rpt", fallback=False)

    class _ConsoleFilter(logging.Filter):
        def filter(self, record: logging.LogRecord) -> bool:
            msg = record.getMessage()
            if not console_pps and msg.startswith("[pps]"):
                return False
            if not console_conn_rpt and msg.startswith("Conn Rpt:"):
                return False
            return True

    class _FileFilter(logging.Filter):
        def filter(self, record: logging.LogRecord) -> bool:
            msg = record.getMessage()
            if not file_pps and msg.startswith("[pps]"):
                return False
            if not file_conn_rpt and msg.startswith("Conn Rpt:"):
                return False
            return True

    want_file = True
    want_console = True
    for handler in root.handlers:
        if isinstance(handler, logging.FileHandler):
            try:
                if Path(handler.baseFilename).resolve() == log_path.resolve():
                    want_file = False
            except OSError:
                pass
            handler.addFilter(_FileFilter())
        elif isinstance(handler, logging.StreamHandler):
            if not isinstance(handler, logging.FileHandler):
                want_console = False
                handler.addFilter(_ConsoleFilter())
        handler.setFormatter(formatter)

    if want_file:
        file_handler = logging.FileHandler(log_path, encoding="utf-8")
        file_handler.setFormatter(formatter)
        file_handler.addFilter(_FileFilter())
        root.addHandler(file_handler)
    if want_console:
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.addFilter(_ConsoleFilter())
        root.addHandler(console_handler)


def _display_available() -> bool:
    # macOS/Windows GUI backends do not rely on X11/Wayland env vars.
    if not sys.platform.startswith("linux"):
        return True

    wayland_display = os.environ.get("WAYLAND_DISPLAY")
    xdg_runtime_dir = os.environ.get("XDG_RUNTIME_DIR")
    if wayland_display and xdg_runtime_dir:
        if Path(xdg_runtime_dir, wayland_display).exists():
            return True

    display = os.environ.get("DISPLAY")
    if not display:
        return False

    host, _, rest = display.rpartition(":")
    if not rest:
        return False

    display_num = rest.split(".", 1)[0]
    if not display_num.isdigit():
        return True

    host = host.lower()
    if host in ("", "unix"):
        return Path(f"/tmp/.X11-unix/X{display_num}").exists()

    return True


def _ensure_gui_display() -> bool:
    if _is_truthy(os.environ.get("ENODE_GUI_FORCE")):
        return True
    if _display_available():
        return True
    print("[gui] no display detected (X11/Wayland).", file=sys.stderr)
    print(
        "[gui] Run `enode-host server ...`, or start an X11/Wayland session, or use `xvfb-run enode-host gui`.",
        file=sys.stderr,
    )
    print("[gui] Set ENODE_GUI_FORCE=1 to try anyway.", file=sys.stderr)
    return False


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="enode-host",
        description="Host-side tools for interacting with the ESP-IDF firmware.",
    )
    parser.add_argument(
        "--ping",
        action="store_true",
        help="Basic sanity check that the CLI is wired up.",
    )

    subparsers = parser.add_subparsers(dest="command")
    server_parser = subparsers.add_parser(
        "server",
        help="Run a TCP server for ESP-IDF nodes.",
    )
    server_parser.add_argument("--host", default="0.0.0.0")
    server_parser.add_argument("--port", type=int, default=3333)
    server_parser.add_argument(
        "--on-connect",
        nargs=argparse.REMAINDER,
        help="Send a protocol command immediately after a client connects.",
    )
    server_parser.add_argument(
        "--interactive",
        action="store_true",
        help="Read commands from stdin and broadcast to all clients.",
    )

    gui_parser = subparsers.add_parser(
        "gui",
        help="Run the wx GUI backed by the framed server.",
    )
    gui_parser.add_argument("--host", default="0.0.0.0")
    gui_parser.add_argument("--port", type=int, default=3333)

    socket_parser = subparsers.add_parser(
        "socket",
        help="Send a message over a TCP socket and print the response.",
    )
    socket_parser.add_argument("host")
    socket_parser.add_argument("port", type=int)
    socket_parser.add_argument("message")
    socket_parser.add_argument("--timeout", type=float, default=5.0)
    return parser


def main() -> int:
    _setup_logging()
    parser = build_parser()
    args = parser.parse_args()

    if args.ping:
        print("pong")
        return 0

    if args.command is None:
        if not _ensure_gui_display():
            return 2
        try:
            from .gui_framed import run_gui
        except Exception as exc:
            import traceback
            print(f"[gui] failed to start: {exc}")
            traceback.print_exc()
            return 2
        run_gui(host="0.0.0.0", port=3333)
        return 0

    if args.command == "server":
        on_connect_payload = None
        if args.on_connect:
            on_connect_payload = build_command_from_tokens(args.on_connect)

        if args.interactive:
            return asyncio.run(run_interactive_server(args.host, args.port, on_connect_payload))

        asyncio.run(run_server(args.host, args.port, on_connect_payload))
        return 0

    if args.command == "gui":
        if not _ensure_gui_display():
            return 2
        try:
            from .gui_framed import run_gui
        except Exception as exc:
            import traceback
            print(f"[gui] failed to start: {exc}")
            traceback.print_exc()
            return 2
        run_gui(host=args.host, port=args.port)
        return 0

    if args.command == "socket":
        return run_client(args.host, args.port, args.message, args.timeout)

    parser.print_help()
    return 0


async def run_interactive_server(host: str, port: int, on_connect_payload: Optional[bytes]) -> int:
    queue: asyncio.Queue[bytes] = asyncio.Queue()
    server_task = asyncio.create_task(run_server(host, port, on_connect_payload, queue))

    try:
        while True:
            line = await asyncio.to_thread(input, "cmd> ")
            if not line:
                continue
            stripped = line.strip()
            if stripped in ("quit", "exit"):
                break
            tokens = stripped.split()
            try:
                payload = build_command_from_tokens(tokens)
            except ValueError as exc:
                print(f"[server] {exc}")
                continue
            if payload is None:
                continue
            await queue.put(payload)
    finally:
        server_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await server_task

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
