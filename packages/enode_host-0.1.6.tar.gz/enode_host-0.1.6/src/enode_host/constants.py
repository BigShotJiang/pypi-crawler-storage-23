"""Shared constants for enode_host."""

import os

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

RT_STREAM_DIR = os.path.join(BASE_DIR, "rt-streamed")
RT_STREAM_HD5_DIR = os.path.join(RT_STREAM_DIR, "hd5")
RT_STREAM_MERGED_DIR = os.path.join(RT_STREAM_DIR, "merged")

SD_STREAM_DIR = os.path.join(BASE_DIR, "sd-streamed")
SD_STREAM_BIN_DIR = os.path.join(SD_STREAM_DIR, "bin")
SD_STREAM_HD5_DIR = os.path.join(SD_STREAM_DIR, "hd5")

PACKET_SIZE = 23

SPEED_COL = "Speed\n(kB/s)"
RSSI_COL = "RSSI\n(dB)"
TIME_SOURCE_COL = "Time\nSource"
PPS_COL = "Time\nMapping"
BAT_COL = "BAT\n(V)"
LEVEL_COL = "Lv"

PPS_AGE_LIMIT_SEC = 10
DAQ_AGE_LIMIT_SEC = 2
PPS_AGE_UPDATE_MS = 1000
GUI_TIMER_MS = 100
