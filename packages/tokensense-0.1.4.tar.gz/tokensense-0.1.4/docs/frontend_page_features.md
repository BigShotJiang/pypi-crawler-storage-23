# TokenSense — Missing Page Features

Features that still need to be added to each page in `design.pen`.

---

## Landing Page

### 1. Integration Logos Row

Shows technology credibility. Add below the demo section, before the footer.

- Logos: **OpenRouter**, **Gemini**, **Actian VectorAI**, **Python**, **FastAPI**

### 2. Footer

The page currently has no footer.

- "TokenSense" wordmark + links to GitHub, Docs, Playground, API Reference
- "Built for the Hackathon · MIT License"

---

## Dashboard

### 1. Token Savings Bar Chart

Add between the existing charts row and the recent queries table.

- Grouped bar chart showing the last 10 queries
- Two bars per query: original `input_tokens` vs `optimized_tokens`
- Legend: "Original Tokens" and "Optimized Tokens"

---

## Docs

### 1. Telemetry Agent in AGENTS Section

The AGENTS sidebar section lists 4 agents but the backend has 5. Add **Telemetry Agent** below "Routing Agent".

---

## Playground

No missing features.
