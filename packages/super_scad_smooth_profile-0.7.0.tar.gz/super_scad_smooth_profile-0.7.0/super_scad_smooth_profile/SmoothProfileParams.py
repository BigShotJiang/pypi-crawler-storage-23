from dataclasses import dataclass

from super_scad.type import Vector2


@dataclass(frozen=True)
class SmoothProfileParams:
    """
    Dataclass for the parameters for creating a smoothing profile widget.
    """
    # ------------------------------------------------------------------------------------------------------------------
    inner_angle: float
    """
    The inner angle between the tow edges. 
    """

    normal_angle: float
    """
    The normal angle of the edges, i.e., the angle of the vector that lies exactly between the two edges and with
    origin at the node.
    """

    position: Vector2
    """
    The position of the node.
    """

    preceding_edge_is_extended_by_eps: bool = False
    """
    Whether the preceding edge is extended by eps.
    """

    succeeding_edge_is_extended_by_eps: bool = False
    """
    Whether the succeeding edge is extended by eps.
    """

# ----------------------------------------------------------------------------------------------------------------------
