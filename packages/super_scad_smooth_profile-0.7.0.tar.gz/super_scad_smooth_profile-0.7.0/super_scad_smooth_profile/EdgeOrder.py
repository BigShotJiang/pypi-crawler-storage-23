from enum import auto, Enum, STRICT


class EdgeOrder(Enum, boundary=STRICT):
    """
    The order of edges seen from the position of a node in a clockwise fashion.
    """

    # ------------------------------------------------------------------------------------------------------------------
    PRECEDING = auto()
    """
    The edge that is preceding the node.
    """

    SUCCEEDING = auto()
    """
    The edge that is succeeding the node.
    """

# ----------------------------------------------------------------------------------------------------------------------
