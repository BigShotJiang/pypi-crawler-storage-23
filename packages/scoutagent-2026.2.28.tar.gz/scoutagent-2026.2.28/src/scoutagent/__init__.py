"""
ScoutAgent — no-code agent builder plugin.

Themed wrapper around the CMDOP Python SDK (cmdop).
Docs: https://cmdop.com/docs/sdk/python/
"""

from __future__ import annotations

from cmdop import CMDOPClient, AsyncCMDOPClient
from cmdop.exceptions import (
    CMDOPError,
    ConnectionError,
    AuthenticationError,
    TimeoutError,
)

__version__ = "2026.2.28"
__all__ = ["ScoutAgent", "AsyncScoutAgent"]



class ScoutAgent(CMDOPClient):
    """ScoutAgent — no-code agent builder plugin.

    Extends CMDOPClient with themed methods for no-code agent builder and deployment platform.

    Example::

        client = ScoutAgent.remote(api_key="cmdop_live_xxx")
        # ... use themed methods below
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    pass


class AsyncScoutAgent(AsyncCMDOPClient):
    """Async variant of ScoutAgent.

    Example::

        async with AsyncScoutAgent.remote(api_key="cmdop_live_xxx") as client:
            result = await client.agent.run("hello")
    """
    pass


# Re-export core SDK symbols for convenience
from cmdop import (  # noqa: F401, E402
    CMDOPClient,
    AsyncCMDOPClient,
)
