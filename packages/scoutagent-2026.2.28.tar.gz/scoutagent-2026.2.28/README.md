# ScoutAgent — Fluent AI Agent Builder & Auto-Deployment for Python

[![PyPI](https://img.shields.io/pypi/v/scoutagent.svg)](https://pypi.org/project/scoutagent/) [![Python](https://img.shields.io/pypi/pyversions/scoutagent.svg)](https://pypi.org/project/scoutagent/) [![license](https://img.shields.io/pypi/l/scoutagent.svg)](https://github.com/commandoperator/cmdop-sdk-python/blob/main/LICENSE)

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

ScoutAgent is an AI agent builder Python package providing a fluent automation API and no-code agent deployment. Unlike AutoGPT, BabyAGI, CrewAI, and LangGraph, ScoutAgent focuses on simple scheduled agent runner capabilities. Define and deploy agents rapidly, scaling automation quickly using Python.

## Features

- Define agents using a fluent automation API for Python.
- Schedule recurring agent runs with a single function call.
- Orchestrate complex workflows combining AI and shell commands.
- Deploy agents without managing infrastructure using no-code agent deployment.
- Run agents on any schedule with the built-in scheduled agent runner.

## Use Cases

- Build AI agents with a fluent chainable API
- Deploy recurring agents on any schedule with one call
- Combine shell steps and AI tasks in a single workflow

## Installation

```bash
pip install scoutagent
```

## Quick Start

```python
from scoutagent import ScoutAgent

client = ScoutAgent.remote(api_key="cmdop_live_xxx")

deployer = (client.build()
    .named("NightlyDeployer")
    .shell("git pull && pip install -r requirements.txt")
    .agent("Verify the build succeeded and summarize changes")
    .every(seconds=86400)
    .deploy())

monitor = client.quick_deploy(
    name="HealthMonitor",
    steps=["$ uptime && df -h", "Summarize resource usage"],
    interval_seconds=60,
)
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [Documentation](https://cmdop.com/docs/sdk/python/)
- [scoutagent on PyPI](https://pypi.org/project/scoutagent/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk-python)
