from __future__ import annotations

CALL_AGENT = "call_agent"
FINISH = "finish"
