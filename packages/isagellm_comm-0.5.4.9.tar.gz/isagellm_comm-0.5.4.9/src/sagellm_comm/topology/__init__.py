"""Topology utilities for sagellm-comm."""

from __future__ import annotations

from sagellm_comm.topology.cache import DeviceDiff, TopologyCache, TopologyDiff
from sagellm_comm.topology.config import NodeConfig, TopologyFileConfig
from sagellm_comm.topology.device import DeviceId
from sagellm_comm.topology.diagnostics import DiagnosticReport, TopologyDiagnostics
from sagellm_comm.topology.discovery import TopologyDiscovery
from sagellm_comm.topology.dynamic import DynamicTopologyManager
from sagellm_comm.topology.link import Link, LinkKind
from sagellm_comm.topology.monitor import TopologyChangeEvent, TopologyChangeType, TopologyMonitor
from sagellm_comm.topology.network_profiler import LinkMetrics, NetworkProfiler
from sagellm_comm.topology.persistence import CachedTopology, TopologyPersistenceCache
from sagellm_comm.topology.region import HierarchicalTopology, RegionAwareTopologyDetector
from sagellm_comm.topology.routing import TopologyRouter
from sagellm_comm.topology.topology_model import (
    Device,
    NoPathError,
    RankError,
    TopologyModel,
)
from sagellm_comm.topology.visualizer import TopologyVisualizer

__all__ = [
    "DeviceId",
    "Link",
    "LinkKind",
    "Device",
    "TopologyModel",
    "RankError",
    "NoPathError",
    "TopologyDiscovery",
    "TopologyMonitor",
    "TopologyChangeEvent",
    "TopologyChangeType",
    "TopologyVisualizer",
    "TopologyCache",
    "TopologyPersistenceCache",
    "CachedTopology",
    "TopologyDiff",
    "DeviceDiff",
    "TopologyFileConfig",
    "NodeConfig",
    "TopologyRouter",
    "NetworkProfiler",
    "LinkMetrics",
    "TopologyDiagnostics",
    "DiagnosticReport",
    "DynamicTopologyManager",
    "RegionAwareTopologyDetector",
    "HierarchicalTopology",
]
