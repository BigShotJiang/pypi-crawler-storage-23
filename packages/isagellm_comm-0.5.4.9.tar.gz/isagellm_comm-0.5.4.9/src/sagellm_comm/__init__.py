"""sagellm-comm: Communication Layer for sageLLM distributed inference.

推荐使用方式 (vLLM v1 style):
    from sagellm_comm import get_comm_backend

    # 自动选择最佳可用后端
    comm = get_comm_backend()

    # 显式指定后端
    comm = get_comm_backend("gloo")   # CPU 或 fallback
    comm = get_comm_backend("nccl")   # CUDA (TODO)
    comm = get_comm_backend("hccl")   # Ascend (TODO)
"""

from __future__ import annotations

from sagellm_comm._version import __version__

# Algorithms (A06: Ring/Tree/Hybrid All-Reduce + selector)
from sagellm_comm.algorithms import (
    AlgorithmSelector,
    AllReduceAlgorithm,
    CommAlgorithm,
    CommAlgorithmRegistry,
    HybridAllReduce,
    RingAllReduce,
    RingCommAlgorithm,
    SelectorConfig,
    TreeAllReduce,
    TreeCommAlgorithm,
)

# MVP: 公共 API 导出
from sagellm_comm.backend import (
    CommBackend,
    CommBackendType,
    CommGroup,
    CommOp,
    TopologyNode,
)

# Mock backend: CPU-first testing (A08 issue #47)
from sagellm_comm.backends.cpu_backend import CpuCommBackend

# Extended collective operations (A06 #40)
from sagellm_comm.collective_ops import AllToAll, Broadcast, ReduceScatter, Scatter

# CommStream/CommEvent async interface (issue #48)
from sagellm_comm.comm_stream import (
    CommEvent,
    CommEventState,
    CommStream,
    create_cpu_comm_stream,
)

# Diagnostics: tracer + profiler (A08 issue #37)
from sagellm_comm.diagnostics import (
    CommOperation,
    CommProfiler,
    CommTracer,
    ProfileReport,
    TraceRecord,
)
from sagellm_comm.gloo_backend import GlooBackend

# Domestic interconnect adapters (Task1.5 baseline)
from sagellm_comm.interconnect import (
    CXLAdapter,
    DomesticInterconnectAdapter,
    InterconnectCurve,
    InterconnectKind,
    InterconnectProfile,
    RDMAAdapter,
    UBAdapter,
    load_curve,
    select_best_available_interconnect,
)

# Overlap utilities (Task1.4 + Task1.8)
from sagellm_comm.overlap import (
    CPUEventHandle,
    CPUStreamHandle,
    DeviceType,
    EventHandle,
    EventState,
    MultiStreamPipeline,
    PipelineResult,
    PipelineStage,
    StageResult,
    StreamHandle,
    StreamPlacement,
    create_cpu_stream,
)

# Registry and factory function (vLLM v1 style)
from sagellm_comm.registry import (
    get_comm_backend,
    is_comm_backend_available,
    list_comm_backends,
    register_comm_backend,
)

# Reliability: retry / fault-tolerance (issue #35)
from sagellm_comm.reliability import (
    CommError,
    PartialFailureError,
    RetryConfig,
    RetryExhaustedError,
    RetryPolicy,
    RetryResult,
    RetryTimeoutError,
    check_partial_failures,
)

# Topology utilities (Phase 2 + A06 enhancements)
from sagellm_comm.topology import (
    CachedTopology,
    Device,
    DeviceDiff,
    DeviceId,
    DiagnosticReport,
    DynamicTopologyManager,
    HierarchicalTopology,
    Link,
    LinkKind,
    LinkMetrics,
    NetworkProfiler,
    NodeConfig,
    NoPathError,
    RankError,
    RegionAwareTopologyDetector,
    TopologyCache,
    TopologyChangeEvent,
    TopologyChangeType,
    TopologyDiagnostics,
    TopologyDiff,
    TopologyDiscovery,
    TopologyFileConfig,
    TopologyModel,
    TopologyMonitor,
    TopologyPersistenceCache,
    TopologyRouter,
    TopologyVisualizer,
)

# Topology detector (MVP)
from sagellm_comm.topology_detector import Topology, TopologyDetector

__all__ = [
    "__version__",
    # =========================================================================
    # Registry (vLLM v1 style) - RECOMMENDED
    # =========================================================================
    "get_comm_backend",  # Factory function to get CommBackend
    "register_comm_backend",  # Register custom backend
    "list_comm_backends",  # List available backends
    "is_comm_backend_available",  # Check if backend is available
    # =========================================================================
    # Backend interfaces
    # =========================================================================
    "CommBackend",
    "CommBackendType",
    "CommGroup",
    "CommOp",
    "TopologyNode",
    # Implementations
    "GlooBackend",
    # Domestic interconnect (Task1.5)
    "DomesticInterconnectAdapter",
    "InterconnectKind",
    "InterconnectProfile",
    "InterconnectCurve",
    "CXLAdapter",
    "UBAdapter",
    "RDMAAdapter",
    "load_curve",
    "select_best_available_interconnect",
    # =========================================================================
    # Overlap (Task1.4 baseline)
    # =========================================================================
    "StreamHandle",
    "EventHandle",
    "EventState",
    "CPUStreamHandle",
    "CPUEventHandle",
    "create_cpu_stream",
    # =========================================================================
    # Overlap (Task1.8 multi-stream pipeline + placement)
    # =========================================================================
    "DeviceType",
    "StreamPlacement",
    "PipelineStage",
    "StageResult",
    "PipelineResult",
    "MultiStreamPipeline",
    # Topology (Phase 2 + A06 enhancements: #27 #29 #30 #31 #32 #42 #43 #44)
    "DeviceId",
    "Link",
    "LinkKind",
    "Device",
    "TopologyModel",
    "RankError",
    "NoPathError",
    "TopologyDiscovery",
    "TopologyMonitor",
    "TopologyChangeEvent",
    "TopologyChangeType",
    "TopologyVisualizer",
    "TopologyCache",
    "TopologyPersistenceCache",
    "CachedTopology",
    "TopologyDiff",
    "DeviceDiff",
    "TopologyFileConfig",
    "NodeConfig",
    "TopologyRouter",
    "NetworkProfiler",
    "LinkMetrics",
    "TopologyDiagnostics",
    "DiagnosticReport",
    "DynamicTopologyManager",
    "RegionAwareTopologyDetector",
    "HierarchicalTopology",
    # Topology Detector (MVP + config-file support #32)
    "Topology",
    "TopologyDetector",
    # =========================================================================
    # Algorithms (A06: Ring/Tree/Hybrid All-Reduce #33 #46)
    # =========================================================================
    "AllReduceAlgorithm",
    "CommAlgorithm",
    "CommAlgorithmRegistry",
    "RingCommAlgorithm",
    "TreeCommAlgorithm",
    "RingAllReduce",
    "TreeAllReduce",
    "HybridAllReduce",
    "AlgorithmSelector",
    "SelectorConfig",
    # =========================================================================
    # Extended collective ops (A06 #40)
    # =========================================================================
    "Broadcast",
    "Scatter",
    "AllToAll",
    "ReduceScatter",
    # =========================================================================
    # Reliability (issue #35)
    # =========================================================================
    "RetryConfig",
    "RetryPolicy",
    "RetryResult",
    "RetryExhaustedError",
    "RetryTimeoutError",
    "CommError",
    "PartialFailureError",
    "check_partial_failures",
    # =========================================================================
    # CommStream / CommEvent (issue #48)
    # =========================================================================
    "CommEvent",
    "CommEventState",
    "CommStream",
    "create_cpu_comm_stream",
    # =========================================================================
    # Diagnostics: tracer + profiler (A08 #37)
    # =========================================================================
    "CommTracer",
    "TraceRecord",
    "CommOperation",
    "CommProfiler",
    "ProfileReport",
    # =========================================================================
    # Mock backend: CPU-first testing (A08 #47)
    # =========================================================================
    "CpuCommBackend",
]
