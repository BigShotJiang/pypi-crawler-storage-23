"""Domestic interconnect adapters (Task1.5 baseline)."""

from __future__ import annotations

from sagellm_comm.interconnect.base import (
    DomesticInterconnectAdapter,
    InterconnectKind,
    InterconnectProfile,
    select_best_available_interconnect,
)
from sagellm_comm.interconnect.curve_loader import InterconnectCurve, load_curve
from sagellm_comm.interconnect.cxl import CXLAdapter
from sagellm_comm.interconnect.rdma import RDMAAdapter
from sagellm_comm.interconnect.ub import UBAdapter

__all__ = [
    "DomesticInterconnectAdapter",
    "InterconnectKind",
    "InterconnectProfile",
    "select_best_available_interconnect",
    "CXLAdapter",
    "UBAdapter",
    "RDMAAdapter",
    "InterconnectCurve",
    "load_curve",
]
