from __future__ import annotations

import asyncio
import inspect
import logging
from typing import TYPE_CHECKING, Annotated, Any

from rtvoice.events import EventBus

if TYPE_CHECKING:
    from rtvoice.subagents import SubAgent


from rtvoice.conversation import ConversationHistory
from rtvoice.events.views import (
    SubAgentCalledEvent,
)
from rtvoice.mcp.server import MCPServer
from rtvoice.realtime.schemas import FunctionTool
from rtvoice.tools.registry import ToolRegistry
from rtvoice.tools.registry.views import Tool
from rtvoice.tools.views import SpecialToolParameters

logger = logging.getLogger(__name__)


class Tools:
    def __init__(self):
        self._registry = ToolRegistry()
        self._context: SpecialToolParameters = SpecialToolParameters()

    def set_context(self, context: SpecialToolParameters) -> None:
        self._context = context

    def action(self, description: str, **kwargs):
        return self._registry.action(description, **kwargs)

    def register_mcp(self, tool: FunctionTool, server: MCPServer) -> None:
        self._registry.register_mcp(tool, server)

    def register_subagent(self, agent: SubAgent) -> None:
        async def _handoff(
            task: Annotated[
                str,
                """
                The task or question to delegate to this agent.
                Be specific and add enough context for the agent to complete the task without further clarification.
                """,
            ],
            event_bus: EventBus,
            conversation_history: ConversationHistory,
        ) -> str:
            await event_bus.dispatch(
                SubAgentCalledEvent(agent_name=agent.name, task=task)
            )

            context = conversation_history.format() if conversation_history else None

            if agent.fire_and_forget:
                asyncio.create_task(agent.run(task, context=context))
                return (
                    agent.result_instructions
                    or "The task has been delegated to the agent and will be completed shortly."
                )
            else:
                result = await agent.run(task, context=context)
                return result.message or ""

        description = agent.description
        if agent.handoff_instructions:
            description = f"{agent.description}\n\nHandoff instructions: {agent.handoff_instructions}"

        safe_name = agent.name.replace(" ", "_")
        result_instructions = agent.result_instructions
        self._registry.action(
            description,
            name=safe_name,
            result_instruction=result_instructions,
            is_subagent=True,
        )(_handoff)

    def get_tool_schema(self) -> list[FunctionTool]:
        return self._registry.get_tool_schema()

    def get_json_tool_schema(self) -> list[dict]:
        return [
            {
                "type": "function",
                "function": tool.model_dump(exclude={"type"}, exclude_none=True),
            }
            for tool in self._registry.get_tool_schema()
        ]

    def get(self, name: str) -> Tool | None:
        return self._registry.get(name)

    async def execute(
        self,
        name: str,
        arguments: dict[str, Any],
    ) -> Any:
        tool = self._registry.get(name)
        if not tool:
            raise KeyError(f"Tool '{name}' not found in registry")

        prepared = self._prepare_arguments(tool, arguments, self._context)
        return await tool.execute(prepared)

    def _prepare_arguments(
        self,
        tool: Tool,
        llm_arguments: dict[str, Any],
        context: SpecialToolParameters,
    ) -> dict[str, Any]:
        signature = inspect.signature(tool.function)
        arguments = llm_arguments.copy()
        injectable = self._injectable_from_context(context)

        for param_name, param in signature.parameters.items():
            if param_name in arguments or param_name in ("self", "cls"):
                continue

            if param_name in injectable and injectable[param_name] is not None:
                arguments[param_name] = injectable[param_name]
            elif param.default is inspect.Parameter.empty:
                raise ValueError(
                    f"Missing required parameter '{param_name}' for tool '{tool.name}'"
                )

        return arguments

    def _injectable_from_context(
        self, context: SpecialToolParameters
    ) -> dict[str, Any]:
        return {
            field: getattr(context, field)
            for field in SpecialToolParameters.model_fields
        }

    def clone(self) -> Tools:
        new = Tools()
        new._registry.tools = {
            name: tool
            for name, tool in self._registry.tools.items()
            if not tool.is_subagent
        }
        return new
