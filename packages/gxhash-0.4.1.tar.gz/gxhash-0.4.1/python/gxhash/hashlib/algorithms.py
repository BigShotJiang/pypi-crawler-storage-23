algorithms_available = {"gxhash32", "gxhash64", "gxhash128"}
algorithms_guaranteed = algorithms_available
