# NeonLink Integration Guide v2 — Multi-Stream Subscriptions (Python + Go)

**Last updated:** 2026-02-27
**Source of truth:** `py3/neonlink/*.py`, `pkg/neonlink/*.go`, `internal/grpc/release.go`, `internal/grpc/subscription.go`, `internal/config/validation/validator.go`, `.env.example`

## 1) Read This First

NeonLink SDK already includes core client-side resiliency mechanisms.
Do **not** build a second wrapper for these inside each microservice.

| Concern | Built into Python SDK | Built into Go SDK | What service code should do |
|---|---|---|---|
| Circuit breaker | Yes (`NeonLinkClient` wraps operations) | Yes (`Client` wraps RPC calls) | Configure thresholds, do not duplicate |
| Multi-stream reconnect/backoff | Yes (`subscribe_many_with_handle`) | Yes (`SubscribeManyWithHandle`) | Monitor terminal outcomes and fail readiness on terminal errors |
| ACK ergonomics | Yes (`acknowledge(message)`) | Yes (`Acknowledge(ctx, msg)` uses `AckContext`) | ACK only after successful processing |
| Failure redelivery during processing | Yes (`release`, `release_by_id`) | Yes (`Release`, `ReleaseByID`) | Call `Release` on processing failure |
| Retry guard | Yes (`evaluate_release_retry_guard` + `release_by_id`) | Yes (`ReleaseByMessageWithRetryGuard`) | Use retry guard on release path |
| DLQ observability | Yes (`get_dlq_status`, `list_dlq_messages_page`) | Yes (`GetDLQStatus`, `ListDLQMessagesPage`) | Use SDK APIs for DLQ reads |
| Backpressure support | Yes (request fields) | Yes (request fields) | Set request flags explicitly |

`RequestRetry` / `Nack` are legacy paths and are not part of the current MessageBroker contract (`neoncontract` `v1.5.7`).

## 2) Shared Rules (Python and Go)

1. Use `auto_ack=False` for business-critical consumers.
2. ACK only after successful processing.
3. On processing failure, call `release` (not `Nack`/`RequestRetry`).
4. If you need message-type filtering, use `message_types` in `SubscribeRequest`.
5. If you need backpressure, set it in `SubscribeRequest`; default is disabled.
6. Route by `header.message_type` in service logic; avoid payload-coupled helper routing.
7. Be aware of head-of-line blocking: when one stream in a multi-stream subscription hits its buffer limit, **all** streams in that subscription pause until the saturated buffer drains.
8. Always use the retry guard (`evaluate_release_retry_guard` / `ReleaseByMessageWithRetryGuard`) on the release path to prevent infinite retry loops.

## 3) Broker Config Required For Production

Set these server-side values in runtime env (`.env`, deployment env, or platform secrets):

```env
APP_ENV=production
GRPC_MAX_DELIVERY_ATTEMPTS=5
GRPC_SUBSCRIPTION_MAX_PROCESSING_TIME_SEC=1800
GRPC_RELEASE_REDELIVERY_CONCURRENCY=32
```

Notes:

1. `GRPC_MAX_DELIVERY_ATTEMPTS` enables poison-message protection and DLQ routing.
2. In `APP_ENV=production`, startup validation rejects `GRPC_MAX_DELIVERY_ATTEMPTS <= 0` and values `> 100`.
3. Recommended starting value is `5`; tune based on workload and DLQ policy.

## 4) Python SDK Integration (Step-by-Step)

### Step 1: Install

```bash
pip install neonlink-client
pip install "neoncontract-gen>=1.5.7"
```

### Step 2: Initialize Client

```python
from neonlink import ConfigBuilder, NeonLinkClient

config = (
    ConfigBuilder()
    .with_service_name("fxrate-service")
    .with_address("neonlink.internal:50051")
    .with_timeout(30.0)
    .with_keepalive(keepalive_time=30.0, keepalive_timeout=10.0, permit_without_stream=False)
    .build()
)

client = NeonLinkClient(config)
```

### Step 3: Publish Message

```python
from messaging.v1 import messaging_pb2
from neonlink import MessageBuilder, with_entity_id, with_user_id, with_data_type

request = (
    MessageBuilder()
    .with_message_type_enum(messaging_pb2.MessageType.MESSAGE_TYPE_ETL_COMPLETION)
    .with_source_service(messaging_pb2.SourceService.SOURCE_SERVICE_ETL)
    .with_idempotency_options(
        with_entity_id("entity-123"),
        with_user_id("user-123"),
        with_data_type(messaging_pb2.DataType.DATA_TYPE_TRANSACTIONS),
    )
    .with_etl_job_context(
        messaging_pb2.ETLJobContext(
            status="completed",
            keys=messaging_pb2.MessageKeys(
                entity_id="entity-123",
                user_id="user-123",
                data_type=messaging_pb2.DataType.DATA_TYPE_TRANSACTIONS,
            ),
        )
    )
    .build()
)
```

### Step 4: Build Multi-Stream Subscribe Request

#### (a) Raw `SubscribeRequest` with backpressure

Leave `stream_name` and `stream_names` **empty** — `subscribe_many_with_handle` populates them from its `stream_names` argument.

```python
from messaging.v1 import messaging_pb2

subscribe_request = messaging_pb2.SubscribeRequest(
    consumer_group="webhook-g1",
    batch_size=50,
    timeout_seconds=30,
    auto_ack=False,
    enable_backpressure=True,
    max_buffer_size=500,
    message_types=[
        messaging_pb2.MessageType.MESSAGE_TYPE_WEBHOOK_INGRESS,
        messaging_pb2.MessageType.MESSAGE_TYPE_GENERIC_EVENT,
    ],
)
```

#### (b) `SubscriptionBuilder` path

`SubscriptionBuilder` does not expose `enable_backpressure` / `max_buffer_size`.
Use this path when backpressure is not needed.

```python
from neonlink import SubscriptionBuilder

subscribe_request = (
    SubscriptionBuilder()
    .with_stream_names("webhooks:ingress", "notifications:outbound")
    .with_consumer_group("webhook-g1")
    .with_batch_size(50)
    .with_timeout(30)
    .build()
)
```

> **Note:** When using the builder with `with_stream_names`, `build()` produces a single request with `stream_names` populated. For `subscribe_many_with_handle`, use the raw request path (a) instead.

### Step 5: Start Multi-Stream Subscription

```python
stream_names = ["webhooks:ingress", "notifications:outbound"]

handle = await client.subscribe_many_with_handle(stream_names, subscribe_request, on_message)

# Monitor terminal outcome (non-blocking)
terminal = await handle.wait()
if terminal is not None:
    # trigger readiness fail / graceful shutdown / restart policy
    raise terminal
```

`MultiSubscriptionHandle` API:

| Property / Method | Description |
|---|---|
| `done` | `asyncio.Future` that resolves with the terminal outcome |
| `await wait(timeout=None)` | Awaits until all streams exit or timeout is reached |
| `await stop()` | Requests graceful termination of all managed streams |
| `stream_names` | List of normalized stream names for this handle |

> **Stream name normalization:** Stream names are trimmed and deduplicated before subscription. `[" foo ", "foo", "bar"]` becomes `["foo", "bar"]`.

### Step 5.1: Head-of-Line Blocking

Multi-stream subscriptions share a single gRPC stream and buffer. When any one stream hits the `max_buffer_size` limit, the server pauses delivery across **all** streams in that subscription until the saturated buffer drains.

**Mitigation strategies:**

- Use separate `MultiSubscriptionHandle` instances for streams with drastically different throughputs (e.g., a high-volume telemetry stream vs. a low-volume config-change stream).
- Tune `max_buffer_size` to accommodate burst patterns. The server default is `1000` when backpressure is enabled and value is `0`.

### Step 5.2: Raw Iterator (Advanced)

For low-level control, `subscribe_many()` returns an async iterator without managed lifecycle. Prefer `subscribe_many_with_handle()` for production use.

```python
stream_names = ["webhooks:ingress", "notifications:outbound"]

subscribe_request = messaging_pb2.SubscribeRequest(
    consumer_group="webhook-g1",
    batch_size=50,
    timeout_seconds=30,
    auto_ack=False,
)

async with NeonLinkClient(config) as client:
    async for msg in client.subscribe_many(stream_names, subscribe_request):
        await client.acknowledge(msg)
```

### Step 6: Handler Pattern with Retry Guard

```python
from neonlink import evaluate_release_retry_guard

async def on_message(msg: messaging_pb2.StreamMessage):
    """Handler receives each message. Errors are logged; stream continues."""
    try:
        # business processing
        await client.acknowledge(msg)
    except Exception:
        if msg is None or not msg.HasField("ack_context"):
            raise

        # Use retry guard — prevents infinite retry loops
        allow_release, retry_count, eff_max, enforceable = evaluate_release_retry_guard(msg, fallback_max_retries=5)
        if not allow_release:
            logger.warning(
                "retry limit reached, skipping release",
                extra={"retry_count": retry_count, "max_retries": eff_max},
            )
            return

        await client.release_by_id(
            redis_message_id=msg.redis_message_id,
            stream_name=msg.ack_context.stream_name,
            consumer_group=msg.ack_context.consumer_group,
            consumer_name=msg.ack_context.consumer_name,
        )
```

`evaluate_release_retry_guard(msg, fallback_max_retries)` returns a 4-tuple:

| Field | Type | Description |
|---|---|---|
| `allow_release` | `bool` | `False` when `retry_count` has reached/exceeded effective max retries |
| `retry_count` | `int` | Current `retry_count` observed in message metadata |
| `effective_max` | `int` | Strictest non-zero retry threshold |
| `enforceable` | `bool` | `False` when `retry_count` is unavailable (cannot enforce on client side) |

Release response statuses:

1. `released_redelivery_queued`: immediate async redelivery pipeline accepted.
2. `released_sweeper_fallback`: release accepted but redelivery semaphore full; sweeper path will reclaim.
3. `codes.ResourceExhausted` error: semaphore full and sweeper inactive; retry `release` with backoff.

### Step 7: DLQ Operations

```python
status = await client.get_dlq_status(include_counts_by_reason=True)
count = await client.get_dlq_count()

# Cursor-first pagination (recommended, matches Go ListDLQMessagesPage)
page = await client.list_dlq_messages_page(limit=50)
for msg in page.messages:
    print(f"{msg.message_id}: {msg.failure_reason}")
# Fetch next page
page = await client.list_dlq_messages_page(limit=50, page_token=page.next_page_token)
```

### Step 8: Graceful Shutdown

```python
# Stop the multi-stream subscription
await handle.stop()

# Close the client connection
await client.close()
```

By-key variant — stop a multi-stream subscription without holding the handle reference:

```python
await client.stop_subscription_many(
    stream_names=["webhooks:ingress", "notifications:outbound"],
    consumer_group="webhook-g1",
    consumer_name="consumer-abc",
)
```

## 5) Go SDK Integration (Step-by-Step)

### Step 1: Install

```bash
go get github.com/LetA-Tech/mcfo-neonlink/pkg/neonlink@latest
go get github.com/LetA-Tech/mcfo-neoncontract/gen/go@latest
```

### Step 2: Initialize Client

```go
package main

import (
	"time"

	"github.com/LetA-Tech/mcfo-neonlink/pkg/neonlink"
	"go.uber.org/zap"
)

func newNeonLinkClient(logger *zap.Logger) (*neonlink.Client, error) {
	cfg := neonlink.NewConfig().
		WithServiceName("fxrate-service").
		WithAddress("neonlink.internal:50051").
		WithTLS(true).
		WithTimeout(30).
		WithBatchSize(10).
		WithKeepAlive(30*time.Second, 10*time.Second)

	// For local/SIT without TLS, use:
	// cfg.WithTLS(false).WithInsecureConnection(true)

	return neonlink.NewClient(cfg, logger)
}
```

### Step 3: Publish Message

```go
import (
	"context"

	"github.com/LetA-Tech/mcfo-neonlink/pkg/neonlink"
	neoncontract "github.com/LetA-Tech/mcfo-neoncontract/gen/go/messaging/v1"
)

func publishETLCompletion(ctx context.Context, client *neonlink.Client) error {
	etlCtx := &neoncontract.ETLJobContext{
		Status: "completed",
		Keys: &neoncontract.MessageKeys{
			EntityId: "entity-123",
			UserId:   "user-123",
			DataType: neoncontract.DataType_DATA_TYPE_TRANSACTIONS,
		},
	}

	req, err := neonlink.NewMessageBuilder().
		WithMessageType(neoncontract.MessageType_MESSAGE_TYPE_ETL_COMPLETION).
		WithSourceService(neoncontract.SourceService_SOURCE_SERVICE_ETL).
		WithIdempotencyFields(
			neonlink.WithEntityID("entity-123"),
			neonlink.WithUserID("user-123"),
			neonlink.WithDataType(neoncontract.DataType_DATA_TYPE_TRANSACTIONS),
		).
		WithETLJobContext(etlCtx, nil).
		Build()
	if err != nil {
		return err
	}

	_, err = client.Publish(ctx, req)
	return err
}
```

### Step 4: Build Multi-Stream Subscribe Request

#### (a) Raw `SubscribeRequest` with backpressure

Use a raw `SubscribeRequest` when you need backpressure fields.
Leave `StreamName` and `StreamNames` **empty** — `SubscribeManyWithHandle` populates them from its `streamNames` argument.

```go
subscribeReq := &neoncontract.SubscribeRequest{
	ConsumerGroup:      "webhook-g1",
	BatchSize:          50,
	TimeoutSeconds:     30,
	AutoAck:            false,
	EnableBackpressure: true,
	MaxBufferSize:      500,
	MessageTypes: []neoncontract.MessageType{
		neoncontract.MessageType_MESSAGE_TYPE_WEBHOOK_INGRESS,
		neoncontract.MessageType_MESSAGE_TYPE_GENERIC_EVENT,
	},
}
```

#### (b) `SubscriptionBuilder` path

`SubscriptionBuilder` provides a fluent API but does not expose `EnableBackpressure` / `MaxBufferSize`.
Use this path when backpressure is not needed.

```go
subscribeReq, err := neonlink.NewSubscriptionBuilder().
	WithStreamNames("webhooks:ingress", "notifications:outbound").
	WithConsumerGroup("webhook-g1").
	WithBatchSize(50).
	WithTimeout(30).
	Build()
if err != nil {
	return err
}
```

> **Note:** When using the builder with `WithStreamNames`, `Build()` produces a single request with `StreamNames` populated. This is suitable for passing directly to `SubscribeWithHandle`. For `SubscribeManyWithHandle`, use the raw request path (a) instead.

### Step 5: Start Multi-Stream Subscription

```go
streamNames := []string{"webhooks:ingress", "notifications:outbound"}

handle, err := client.SubscribeManyWithHandle(ctx, streamNames, subscribeReq, handler)
if err != nil {
	return err
}

// Monitor terminal outcome (non-blocking)
go func() {
	if err := handle.Wait(ctx); err != nil {
		logger.Error("multi-subscription terminated", zap.Error(err))
		// trigger readiness fail / graceful shutdown / restart policy
	}
}()
```

`MultiSubscriptionHandle` API:

| Method | Description |
|---|---|
| `Done() <-chan error` | Channel that receives exactly one terminal outcome, then closes |
| `Wait(ctx) error` | Blocks until all streams exit or ctx is cancelled |
| `Stop()` | Requests graceful termination of all managed streams |
| `StreamNames() []string` | Returns a copy of the normalized stream names for this handle |

> **Stream name normalization:** Stream names are trimmed and deduplicated before subscription. `[" foo ", "foo", "bar"]` becomes `["foo", "bar"]`.

### Step 5.1: Head-of-Line Blocking

Multi-stream subscriptions share a single gRPC stream and buffer. When any one stream hits the `MaxBufferSize` limit, the server pauses delivery across **all** streams in that subscription until the saturated buffer drains.

**Mitigation strategies:**

- Use separate `MultiSubscriptionHandle` instances for streams with drastically different throughputs.
- Tune `MaxBufferSize` to accommodate burst patterns. The server default is `1000` when backpressure is enabled and value is `0`.

### Step 6: Handler Pattern with Retry Guard

```go
type WebhookHandler struct {
	client *neonlink.Client
}

func (h *WebhookHandler) GetHandlerName() string { return "webhook-handler" }

func (h *WebhookHandler) HandleMessage(ctx context.Context, msg *neoncontract.StreamMessage) error {
	if msg == nil || msg.Header == nil {
		return nil
	}

	switch msg.Header.MessageType {
	case neoncontract.MessageType_MESSAGE_TYPE_WEBHOOK_INGRESS:
		// process webhook ingress
	case neoncontract.MessageType_MESSAGE_TYPE_GENERIC_EVENT:
		// process generic event
	default:
		return nil
	}

	processingErr := doBusinessWork(msg)
	if processingErr != nil {
		// Use retry guard — prevents infinite retry loops
		_, releaseErr := h.client.ReleaseByMessageWithRetryGuard(ctx, msg, 5)
		if releaseErr != nil {
			return releaseErr
		}
		return processingErr
	}

	_, ackErr := h.client.Acknowledge(ctx, msg)
	return ackErr
}
```

`ReleaseByMessageWithRetryGuard(ctx, msg, fallbackMaxRetries)` evaluates the retry guard and either releases the message or returns an error when retries are exhausted. The `fallbackMaxRetries` value is used when the message metadata does not carry its own `max_retries` — the **strictest** (lowest non-zero) ceiling wins.

For manual 4-tuple inspection:

```go
allowRelease, retryCount, effectiveMax, enforceable := neonlink.EvaluateReleaseRetryGuard(msg, 5)
if !allowRelease {
	logger.Warn("retry limit reached, skipping release",
		zap.Int32("retry_count", retryCount),
		zap.Int32("max_retries", effectiveMax))
	return processingErr
}
// proceed with manual ReleaseByID...
```

Release response statuses:

1. `released_redelivery_queued`: immediate async redelivery pipeline accepted.
2. `released_sweeper_fallback`: release accepted but redelivery semaphore full; sweeper path will reclaim.
3. `codes.ResourceExhausted` error: semaphore full and sweeper inactive; retry `Release` with backoff.

### Step 7: DLQ Operations

```go
status, err := client.GetDLQStatus(ctx, &neoncontract.DLQStatusRequest{
	IncludeCountsByReason: true,
})
if err != nil {
	return err
}

page, err := client.ListDLQMessagesPage(ctx, 50, "", false)
if err != nil {
	return err
}
_ = status
_ = page.NextPageToken
```

### Step 8: Graceful Shutdown

```go
// Stop the multi-stream subscription
handle.Stop()

// Close the client connection
defer client.Close()
```

`handle.Stop()` requests graceful termination of all streams managed by the handle.
`client.Close()` cancels any remaining active subscriptions and closes the gRPC connection.

## 6) Compatibility Notes

1. `acknowledge` / `Acknowledge` requires `ack_context` in `StreamMessage`.
2. `RequestRetry` / `Nack` have been removed from both SDKs. They are not part of the `neoncontract` `v1.5.7` MessageBroker contract. Use `release` for processing-failure redelivery.
3. `context canceled` at stream shutdown is typically expected when client closes or reconnects.
4. All RPC methods (`publish`, `ack`, `acknowledge`, `release`, `get_dlq_status`, `list_dlq_messages`) are circuit breaker protected in both SDKs.
5. `stream_names` field on `SubscribeRequest` requires `neoncontract` `>= v1.5.7`.
6. `subscribe_many_with_handle` / `SubscribeManyWithHandle` require that the request's `stream_name`/`StreamName` and `stream_names`/`StreamNames` fields are empty — stream selectors are passed as a separate argument.

## 7) Production Checklist (Per Microservice)

1. Uses SDK directly (`neonlink-client` or `pkg/neonlink`), no custom transport wrapper.
2. Uses `subscribe_many_with_handle` / `SubscribeManyWithHandle` for multi-stream consumption.
3. Uses manual ACK (`auto_ack=False`) for critical flows.
4. Uses `acknowledge` after success only.
5. Uses retry-guard-protected release (`evaluate_release_retry_guard` + `release_by_id` / `ReleaseByMessageWithRetryGuard`).
6. Uses cursor-based DLQ reads (`list_dlq_messages_page` / `ListDLQMessagesPage`).
7. Sets backpressure explicitly where needed; understands head-of-line blocking implications.
8. Runs broker with `GRPC_MAX_DELIVERY_ATTEMPTS` configured in production.
9. Calls `handle.stop()` / `handle.Stop()` on graceful shutdown before closing client.

## 8) Anti-Patterns to Reject in Code Review

1. New code that uses `Nack` / `RequestRetry` for normal processing-failure redelivery.
2. Custom retry loop around `subscribe` that ignores SDK reconnect logic.
3. Custom in-memory DLQ queue or ad-hoc Redis key pattern outside NeonLink APIs.
4. Double-ack logic (manual ACK plus `auto_ack=True`).
5. Wrapping SDK with another wrapper that duplicates circuit breaker/backpressure/retry control.
6. Creating N separate `subscribe_with_handle` calls when one `subscribe_many_with_handle` suffices.
7. Using multi-stream subscription for wildly different throughputs without understanding head-of-line blocking.
8. Releasing without retry guard check — allows infinite retry loops that bypass DLQ routing.
9. Setting `stream_name`/`stream_names` on the request when using `subscribe_many_with_handle` / `SubscribeManyWithHandle` — these must be empty; stream names are passed as a separate argument.

## 9) Migration from v1 (Single-Stream → Multi-Stream)

### API Mapping

| v1 (Single-Stream) | v2 (Multi-Stream) | Notes |
|---|---|---|
| `subscribe_with_handle(req, handler)` | `subscribe_many_with_handle(stream_names, req, handler)` | Stream names passed separately; request selectors must be empty |
| `SubscribeWithHandle(ctx, req, handler)` | `SubscribeManyWithHandle(ctx, streamNames, req, handler)` | Same pattern as Python |
| `SubscriptionHandle` | `MultiSubscriptionHandle` | Adds `stream_names` / `StreamNames()` |
| `handle.wait()` / `handle.Wait(ctx)` | Same | Unchanged API |
| `handle.stop()` / `handle.Stop()` | Same | Unchanged API |
| `release_by_id(...)` | `evaluate_release_retry_guard(msg, fallback)` + `release_by_id(...)` | Recommended upgrade; raw `release_by_id` still works |
| `ReleaseByID(ctx, ...)` | `ReleaseByMessageWithRetryGuard(ctx, msg, fallback)` | One-step pattern in Go |
| `SubscriptionBuilder.with_stream_name()` | `SubscriptionBuilder.with_stream_names()` | Clears single stream name; sets multi-stream |
| `SubscriptionBuilder.build()` | `SubscriptionBuilder.build()` | Works with both single and multi-stream |
| N/A | `SubscriptionBuilder.build_many()` / `BuildMany()` | Produces one request per stream (for separate single-stream subscriptions) |
| `stop_subscription(stream, group, consumer)` | `stop_subscription_many(stream_names, group, consumer)` | Python only; Go uses `handle.Stop()` |

### Key Behavioral Changes

- **Single gRPC call:** One `subscribe_many_with_handle` call replaces N separate `subscribe_with_handle` calls. All streams share one gRPC connection with unified reconnect/backoff.
- **Shared reconnect/backoff:** If the connection drops, all streams reconnect together. There is no per-stream reconnect logic.
- **Head-of-line blocking:** Any stream hitting its buffer limit pauses all streams in that subscription. Plan stream groupings accordingly (see Step 5.1).
