"""Tests for NeonLink helpers."""

import json
from unittest.mock import MagicMock

import pytest

from neonlink import MessageBuilder, SubscriptionBuilder
from neonlink.helpers import effective_max_retries, evaluate_release_retry_guard


class TestMessageBuilder:
    """Tests for MessageBuilder."""

    def test_default_values(self):
        builder = MessageBuilder()
        assert builder._message_id is not None
        assert builder._correlation_id is not None
        assert builder._timestamp is not None
        assert builder._stream is None
        assert builder._message_type is None
        assert builder._payload == b""
        assert builder._headers == {}

    def test_with_stream(self):
        builder = MessageBuilder().with_stream("test-stream")
        assert builder._stream == "test-stream"

    def test_with_message_type(self):
        builder = MessageBuilder().with_message_type("TestMessage")
        assert builder._message_type == "TestMessage"

    def test_with_message_id(self):
        builder = MessageBuilder().with_message_id("custom-id")
        assert builder._message_id == "custom-id"

    def test_with_correlation_id(self):
        builder = MessageBuilder().with_correlation_id("corr-123")
        assert builder._correlation_id == "corr-123"

    def test_with_payload(self):
        builder = MessageBuilder().with_payload(b"raw bytes")
        assert builder._payload == b"raw bytes"

    def test_with_json_payload(self):
        builder = MessageBuilder().with_json_payload({"key": "value", "number": 42})
        payload = json.loads(builder._payload)
        assert payload == {"key": "value", "number": 42}

    def test_with_header(self):
        builder = MessageBuilder().with_header("x-custom", "value")
        assert builder._headers == {"x-custom": "value"}

    def test_with_headers(self):
        builder = MessageBuilder().with_headers({"key1": "value1", "key2": "value2"})
        assert builder._headers == {"key1": "value1", "key2": "value2"}

    def test_with_idempotency_key(self):
        builder = MessageBuilder().with_idempotency_key("idem-key-123")
        assert builder._idempotency_key == "idem-key-123"
        assert builder._headers["x-idempotency-key"] == "idem-key-123"

    def test_with_idempotency_fields(self):
        builder = MessageBuilder().with_idempotency_fields("user-123", "action-456")
        assert "x-idempotency-key" in builder._headers
        assert len(builder._headers["x-idempotency-key"]) == 32  # SHA256 truncated

    def test_with_idempotency_fields_with_prefix(self):
        builder = MessageBuilder().with_idempotency_fields(
            "user-123", "action-456", prefix="my-service"
        )
        assert "x-idempotency-key" in builder._headers

    def test_idempotency_fields_deterministic(self):
        """Same fields should produce same idempotency key."""
        builder1 = MessageBuilder().with_idempotency_fields("user-123", "action-456")
        builder2 = MessageBuilder().with_idempotency_fields("user-123", "action-456")
        assert builder1._headers["x-idempotency-key"] == builder2._headers["x-idempotency-key"]

    def test_idempotency_fields_different_for_different_inputs(self):
        """Different fields should produce different keys."""
        builder1 = MessageBuilder().with_idempotency_fields("user-123", "action-456")
        builder2 = MessageBuilder().with_idempotency_fields("user-123", "action-789")
        assert builder1._headers["x-idempotency-key"] != builder2._headers["x-idempotency-key"]

    def test_build_dict(self):
        result = (
            MessageBuilder()
            .with_stream("test-stream")
            .with_message_type("TestMessage")
            .with_json_payload({"key": "value"})
            .build_dict()
        )
        assert result["stream"] == "test-stream"
        assert result["message_type"] == "TestMessage"
        assert json.loads(result["payload"]) == {"key": "value"}

    def test_build_dict_missing_stream(self):
        with pytest.raises(ValueError, match="stream is required"):
            MessageBuilder().with_message_type("TestMessage").build_dict()

    def test_build_dict_missing_message_type(self):
        with pytest.raises(ValueError, match="message_type is required"):
            MessageBuilder().with_stream("test-stream").build_dict()

    def test_builder_is_chainable(self):
        builder = MessageBuilder()
        result = builder.with_stream("test")
        assert result is builder

        result = builder.with_message_type("Test")
        assert result is builder

        result = builder.with_payload(b"data")
        assert result is builder


class TestSubscriptionBuilder:
    """Tests for SubscriptionBuilder."""

    def test_build_single_stream(self):
        request = (
            SubscriptionBuilder()
            .with_stream_name("events")
            .with_consumer_group("workers")
            .with_consumer_name("worker-1")
            .build()
        )
        assert request.stream_name == "events"
        assert list(request.stream_names) == []
        assert request.consumer_group == "workers"
        assert request.consumer_name == "worker-1"

    def test_build_multi_stream(self):
        request = (
            SubscriptionBuilder()
            .with_stream_names("events", "payments", "events")
            .with_consumer_group("workers")
            .build()
        )
        assert request.stream_name == ""
        assert list(request.stream_names) == ["events", "payments"]
        assert request.consumer_group == "workers"

    def test_build_requires_selector_or_message_types(self):
        with pytest.raises(
            ValueError, match="Either stream_name, stream_names, or message_types is required"
        ):
            SubscriptionBuilder().build()

    def test_build_rejects_empty_stream_name_in_multi(self):
        with pytest.raises(ValueError, match="stream names cannot contain empty values"):
            SubscriptionBuilder().with_stream_names("events", " ").build()

    def test_build_many_returns_one_request_per_stream(self):
        reqs = (
            SubscriptionBuilder()
            .with_stream_names("events", "payments", "events")
            .with_consumer_group("workers")
            .with_consumer_name("w-1")
            .with_batch_size(20)
            .with_auto_ack(True)
            .build_many()
        )
        # "events" appears twice but should be deduplicated
        assert len(reqs) == 2
        assert reqs[0].stream_name == "events"
        assert reqs[1].stream_name == "payments"
        # Each should be a single-stream request
        for req in reqs:
            assert list(req.stream_names) == []
            assert req.consumer_group == "workers"
            assert req.consumer_name == "w-1"
            assert req.batch_size == 20
            assert req.auto_ack is True

    def test_build_many_rejects_single_stream_name(self):
        with pytest.raises(ValueError, match="single stream_name configured"):
            SubscriptionBuilder().with_stream_name("events").build_many()

    def test_build_many_rejects_empty_stream_names(self):
        with pytest.raises(ValueError, match="at least one stream name is required"):
            SubscriptionBuilder().with_stream_names().build_many()


class TestEffectiveMaxRetries:
    """Tests for effective_max_retries() helper."""

    def _make_msg(self, max_retries=0, retry_count=0):
        """Create a mock StreamMessage with metadata."""
        msg = MagicMock()
        metadata = MagicMock()
        metadata.max_retries = max_retries
        metadata.retry_count = retry_count
        msg.job_dispatch.metadata = metadata
        return msg

    def test_both_zero_returns_zero(self):
        assert effective_max_retries(None, 0) == 0

    def test_fallback_only(self):
        assert effective_max_retries(None, 5) == 5

    def test_metadata_only(self):
        msg = self._make_msg(max_retries=3)
        assert effective_max_retries(msg, 0) == 3

    def test_strictest_wins_metadata_lower(self):
        msg = self._make_msg(max_retries=3)
        assert effective_max_retries(msg, 10) == 3

    def test_strictest_wins_fallback_lower(self):
        msg = self._make_msg(max_retries=10)
        assert effective_max_retries(msg, 3) == 3

    def test_equal_thresholds(self):
        msg = self._make_msg(max_retries=5)
        assert effective_max_retries(msg, 5) == 5

    def test_none_message(self):
        assert effective_max_retries(None, 7) == 7


class TestEvaluateReleaseRetryGuard:
    """Tests for evaluate_release_retry_guard() helper."""

    def _make_msg(self, max_retries=0, retry_count=0):
        """Create a mock StreamMessage with metadata."""
        msg = MagicMock()
        metadata = MagicMock()
        metadata.max_retries = max_retries
        metadata.retry_count = retry_count
        msg.job_dispatch.metadata = metadata
        return msg

    def test_no_threshold_allows_release(self):
        allow, rc, eff, enforceable = evaluate_release_retry_guard(None, 0)
        assert allow is True
        assert rc == 0
        assert eff == 0
        assert enforceable is False

    def test_threshold_with_no_metadata_not_enforceable(self):
        allow, rc, eff, enforceable = evaluate_release_retry_guard(None, 5)
        assert allow is True
        assert rc == 0
        assert eff == 5
        assert enforceable is False

    def test_below_threshold_allows_release(self):
        msg = self._make_msg(max_retries=5, retry_count=3)
        allow, rc, eff, enforceable = evaluate_release_retry_guard(msg, 0)
        assert allow is True
        assert rc == 3
        assert eff == 5
        assert enforceable is True

    def test_at_threshold_blocks_release(self):
        msg = self._make_msg(max_retries=5, retry_count=5)
        allow, rc, eff, enforceable = evaluate_release_retry_guard(msg, 0)
        assert allow is False
        assert rc == 5
        assert eff == 5
        assert enforceable is True

    def test_above_threshold_blocks_release(self):
        msg = self._make_msg(max_retries=3, retry_count=7)
        allow, rc, eff, enforceable = evaluate_release_retry_guard(msg, 0)
        assert allow is False
        assert rc == 7
        assert eff == 3
        assert enforceable is True

    def test_fallback_threshold_enforced(self):
        msg = self._make_msg(max_retries=0, retry_count=5)
        allow, rc, eff, enforceable = evaluate_release_retry_guard(msg, 5)
        assert allow is False
        assert rc == 5
        assert eff == 5
        assert enforceable is True

    def test_zero_retry_count_not_enforceable(self):
        msg = self._make_msg(max_retries=5, retry_count=0)
        allow, rc, eff, enforceable = evaluate_release_retry_guard(msg, 0)
        assert allow is True
        assert rc == 0
        assert eff == 5
        assert enforceable is False
