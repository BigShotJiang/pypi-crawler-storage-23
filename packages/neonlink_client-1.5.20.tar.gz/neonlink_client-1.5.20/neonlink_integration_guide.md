> **DEPRECATED — v1 (Single-Stream):** This guide covers the legacy single-stream subscription pattern.
> For new integrations, see **[neonlink_integration_guide_v2.md](./neonlink_integration_guide_v2.md)** which covers multi-stream subscriptions exclusively.

---

# NeonLink Integration Guide (Go + Python)

**Last updated:** 2026-02-13  
**Source of truth:** `pkg/neonlink/*.go`, `py3/neonlink/*.py`, `internal/grpc/release.go`, `internal/grpc/subscription.go`, `internal/config/validation/validator.go`, `.env.example`

## 1) Read This First

NeonLink SDK already includes core client-side resiliency mechanisms.  
Do **not** build a second wrapper for these inside each microservice.

| Concern | Built into Go SDK | Built into Python SDK | What service code should do |
|---|---|---|---|
| Circuit breaker | Yes (`Client` wraps RPC calls) | Yes (`NeonLinkClient` wraps operations) | Configure thresholds, do not duplicate |
| Subscription reconnect/backoff | Yes (`SubscribeWithHandle`) | Yes (`subscribe_with_handle`) | Monitor terminal outcomes and fail readiness on terminal errors |
| ACK ergonomics | Yes (`Acknowledge(ctx, msg)` uses `AckContext`) | Yes (`acknowledge(message)`) | ACK only after successful processing |
| Failure redelivery during processing | Yes (`Release`, `ReleaseByID`) | Yes (`release`, `release_by_id`) | Call `Release` on processing failure |
| DLQ observability | Yes (`GetDLQStatus`, `ListDLQMessagesPage`) | Yes (`get_dlq_status`, `list_dlq_messages_page`) | Use SDK APIs for DLQ reads |
| Backpressure support | Yes (request fields) | Yes (request fields) | Set request flags explicitly |

`RequestRetry` / `Nack` are legacy paths and are not part of the current MessageBroker contract (`neoncontract` `v1.5.7`).

## 2) Shared Rules (Go and Python)

1. Use `AutoAck=false` for business-critical consumers.
2. ACK only after successful processing.
3. On processing failure, call `Release` (not `Nack`/`RequestRetry`).
4. If you need message-type filtering, use `MessageTypes` in `SubscribeRequest`.
5. If you need backpressure, set it in `SubscribeRequest`; default is disabled.
6. Route by `header.message_type` in service logic; avoid payload-coupled helper routing.

## 3) Broker Config Required For Production

Set these server-side values in runtime env (`.env`, deployment env, or platform secrets):

```env
APP_ENV=production
GRPC_MAX_DELIVERY_ATTEMPTS=5
GRPC_SUBSCRIPTION_MAX_PROCESSING_TIME_SEC=1800
GRPC_RELEASE_REDELIVERY_CONCURRENCY=32
```

Notes:

1. `GRPC_MAX_DELIVERY_ATTEMPTS` enables poison-message protection and DLQ routing.
2. In `APP_ENV=production`, startup validation rejects `GRPC_MAX_DELIVERY_ATTEMPTS <= 0` and values `> 100`.
3. Recommended starting value is `5`; tune based on workload and DLQ policy.

## 4) Why Logs Show `backpressure_enabled: false`

`internal/grpc/subscription.go` logs `backpressure_enabled` directly from `SubscribeRequest.EnableBackpressure`.

If your logs show:

```text
"backpressure_enabled": false
```

your client sent:

1. `EnableBackpressure = false`, or
2. omitted the field (defaults to `false`).

To enable it, set:

1. `EnableBackpressure = true`
2. `MaxBufferSize > 0` (server default is `1000` when enabled and value is `0`)

## 5) Go SDK Integration (Step-by-Step)

### Step 1: Install

```bash
go get github.com/LetA-Tech/mcfo-neonlink/pkg/neonlink@latest
go get github.com/LetA-Tech/mcfo-neoncontract/gen/go@latest
```

### Step 2: Initialize Client

```go
package main

import (
	"time"

	"github.com/LetA-Tech/mcfo-neonlink/pkg/neonlink"
	"go.uber.org/zap"
)

func newNeonLinkClient(logger *zap.Logger) (*neonlink.Client, error) {
	cfg := neonlink.NewConfig().
		WithServiceName("fxrate-service").
		WithAddress("neonlink.internal:50051").
		WithTLS(true).
		WithTimeout(30).
		WithBatchSize(10).
		WithKeepAlive(30*time.Second, 10*time.Second)

	// For local/SIT without TLS, use:
	// cfg.WithTLS(false).WithInsecureConnection(true)

	return neonlink.NewClient(cfg, logger)
}
```

### Step 3: Publish Message

```go
import (
	"context"

	"github.com/LetA-Tech/mcfo-neonlink/pkg/neonlink"
	neoncontract "github.com/LetA-Tech/mcfo-neoncontract/gen/go/messaging/v1"
)

func publishETLCompletion(ctx context.Context, client *neonlink.Client) error {
	etlCtx := &neoncontract.ETLJobContext{
		Status: "completed",
		Keys: &neoncontract.MessageKeys{
			EntityId: "entity-123",
			UserId:   "user-123",
			DataType: neoncontract.DataType_DATA_TYPE_TRANSACTIONS,
		},
	}

	req, err := neonlink.NewMessageBuilder().
		WithMessageType(neoncontract.MessageType_MESSAGE_TYPE_ETL_COMPLETION).
		WithSourceService(neoncontract.SourceService_SOURCE_SERVICE_ETL).
		WithIdempotencyFields(
			neonlink.WithEntityID("entity-123"),
			neonlink.WithUserID("user-123"),
			neonlink.WithDataType(neoncontract.DataType_DATA_TYPE_TRANSACTIONS),
		).
		WithETLJobContext(etlCtx, nil).
		Build()
	if err != nil {
		return err
	}

	_, err = client.Publish(ctx, req)
	return err
}
```

### Step 4: Subscribe with Manual ACK, Type Filters, and Backpressure

Use raw `SubscribeRequest` when you need backpressure fields.  
`SubscriptionBuilder` does not expose `EnableBackpressure` / `MaxBufferSize`.

```go
subscribeReq := &neoncontract.SubscribeRequest{
	StreamName:         "webhooks:ingress",
	ConsumerGroup:      "webhook-g1",
	BatchSize:          50,
	TimeoutSeconds:     30,
	AutoAck:            false,
	EnableBackpressure: true,
	MaxBufferSize:      500,
	MessageTypes: []neoncontract.MessageType{
		neoncontract.MessageType_MESSAGE_TYPE_WEBHOOK_INGRESS,
		neoncontract.MessageType_MESSAGE_TYPE_GENERIC_EVENT,
	},
}
```

### Step 4.1: Managed Subscription Lifecycle (Recommended)

```go
handle, err := client.SubscribeWithHandle(ctx, subscribeReq, handler)
if err != nil {
	return err
}

go func() {
	if err := handle.Wait(ctx); err != nil {
		logger.Error("subscription terminated", zap.Error(err))
		// trigger readiness fail / graceful shutdown / restart policy
	}
}()
```

### Step 5: Handler Pattern (ACK / Release)

```go
type WebhookHandler struct {
	client *neonlink.Client
}

func (h *WebhookHandler) GetHandlerName() string { return "webhook-handler" }

func (h *WebhookHandler) HandleMessage(ctx context.Context, msg *neoncontract.StreamMessage) error {
	if msg == nil || msg.Header == nil {
		return nil
	}

	// Service-owned routing
	switch msg.Header.MessageType {
	case neoncontract.MessageType_MESSAGE_TYPE_WEBHOOK_INGRESS:
		// process webhook ingress
	case neoncontract.MessageType_MESSAGE_TYPE_GENERIC_EVENT:
		// process config/update generic event
	default:
		return nil
	}

	processingErr := doBusinessWork(msg)
	if processingErr != nil {
		if msg.AckContext == nil {
			return processingErr
		}

		_, releaseErr := h.client.ReleaseByID(
			ctx,
			msg.RedisMessageId,
			msg.AckContext.StreamName,
			msg.AckContext.ConsumerGroup,
			msg.AckContext.ConsumerName,
		)
		if releaseErr != nil {
			return releaseErr
		}
		return processingErr
	}

	_, ackErr := h.client.Acknowledge(ctx, msg)
	return ackErr
}
```

Release response statuses:

1. `released_redelivery_queued`: immediate async redelivery pipeline accepted.
2. `released_sweeper_fallback`: release accepted but redelivery semaphore full; sweeper path will reclaim.
3. `codes.ResourceExhausted` error: semaphore full and sweeper inactive; retry `Release` with backoff.

### Step 6: DLQ Operations

```go
status, err := client.GetDLQStatus(ctx, &neoncontract.DLQStatusRequest{
	IncludeCountsByReason: true,
})
if err != nil {
	return err
}

page, err := client.ListDLQMessagesPage(ctx, 50, "", false)
if err != nil {
	return err
}
_ = status
_ = page.NextPageToken
```

### Step 7: Shutdown

```go
defer client.Close()
```

`Close()` cancels active subscriptions and closes the gRPC connection.

## 6) Python SDK Integration (Step-by-Step)

### Step 1: Install

```bash
pip install neonlink-client
pip install "neoncontract-gen>=1.5.7"
```

### Step 2: Initialize Client

```python
from neonlink import ConfigBuilder, NeonLinkClient

config = (
    ConfigBuilder()
    .with_service_name("fxrate-service")
    .with_address("neonlink.internal:50051")
    .with_timeout(30.0)
    .with_keepalive(keepalive_time=30.0, keepalive_timeout=10.0, permit_without_stream=False)
    .build()
)

client = NeonLinkClient(config)
```

### Step 3: Publish Message

```python
from messaging.v1 import messaging_pb2
from neonlink import MessageBuilder, with_entity_id, with_user_id, with_data_type

request = (
    MessageBuilder()
    .with_message_type_enum(messaging_pb2.MessageType.MESSAGE_TYPE_ETL_COMPLETION)
    .with_source_service(messaging_pb2.SourceService.SOURCE_SERVICE_ETL)
    .with_idempotency_options(
        with_entity_id("entity-123"),
        with_user_id("user-123"),
        with_data_type(messaging_pb2.DataType.DATA_TYPE_TRANSACTIONS),
    )
    .with_etl_job_context(
        messaging_pb2.ETLJobContext(
            status="completed",
            keys=messaging_pb2.MessageKeys(
                entity_id="entity-123",
                user_id="user-123",
                data_type=messaging_pb2.DataType.DATA_TYPE_TRANSACTIONS,
            ),
        )
    )
    .build()
)
```

### Step 4: Subscribe with Manual ACK, Type Filters, and Backpressure

Use `messaging_pb2.SubscribeRequest` directly when setting backpressure fields.

```python
from messaging.v1 import messaging_pb2

subscribe_request = messaging_pb2.SubscribeRequest(
    stream_name="webhooks:ingress",
    consumer_group="webhook-g1",
    batch_size=50,
    timeout_seconds=30,
    auto_ack=False,
    enable_backpressure=True,
    max_buffer_size=500,
    message_types=[
        messaging_pb2.MessageType.MESSAGE_TYPE_WEBHOOK_INGRESS,
        messaging_pb2.MessageType.MESSAGE_TYPE_GENERIC_EVENT,
    ],
)
```

### Step 5: Managed Subscription Lifecycle (Recommended)

```python
from messaging.v1 import messaging_pb2

async def on_message(msg: messaging_pb2.StreamMessage):
    """Handler receives each message. Errors are logged; stream continues."""
    try:
        # business processing
        await client.acknowledge(msg)
    except Exception:
        if msg is None or not msg.HasField("ack_context"):
            raise
        await client.release_by_id(
            redis_message_id=msg.redis_message_id,
            stream_name=msg.ack_context.stream_name,
            consumer_group=msg.ack_context.consumer_group,
            consumer_name=msg.ack_context.consumer_name,
        )

handle = await client.subscribe_with_handle(subscribe_request, on_message)

# Monitor terminal outcome (non-blocking)
terminal = await handle.wait()
if terminal is not None:
    # trigger readiness fail / graceful shutdown / restart policy
    raise terminal
```

### Step 5.1: Raw Iterator Subscribe (Advanced)

For low-level control, `subscribe()` returns an async iterator without
managed lifecycle.  Prefer `subscribe_with_handle()` for production use.

```python
async with NeonLinkClient(config) as client:
    async for msg in client.subscribe(subscribe_request):
        await client.acknowledge(msg)
```

### Step 6: DLQ Operations

```python
status = await client.get_dlq_status(include_counts_by_reason=True)
count = await client.get_dlq_count()

# Cursor-first pagination (recommended, matches Go ListDLQMessagesPage)
page = await client.list_dlq_messages_page(limit=50)
for msg in page.messages:
    print(f"{msg.message_id}: {msg.failure_reason}")
# Fetch next page
page = await client.list_dlq_messages_page(limit=50, page_token=page.next_page_token)
```

## 7) Compatibility Notes

1. `acknowledge` / `Acknowledge` requires `ack_context` in `StreamMessage`.
2. `RequestRetry` / `Nack` have been removed from both SDKs.  They are not part of the `neoncontract` `v1.5.7` MessageBroker contract.  Use `Release` for processing-failure redelivery.
3. `context canceled` at stream shutdown is typically expected when client closes or reconnects.
4. All RPC methods (`publish`, `ack`, `acknowledge`, `release`, `get_dlq_status`, `list_dlq_messages`) are circuit breaker protected in both SDKs.

## 8) Production Checklist (Per Microservice)

1. Uses SDK directly (`pkg/neonlink` or `neonlink-client`), no custom transport wrapper.
2. Uses manual ACK (`AutoAck=false`) for critical flows.
3. Uses `Acknowledge` / `acknowledge` after success only.
4. Uses `Release` / `release` on failure path (`ReleaseByID` / `release_by_id`).
5. Uses cursor-based DLQ reads (`ListDLQMessagesPage` / `list_dlq_messages_page`).
6. Sets backpressure explicitly where needed.
7. Runs broker with `GRPC_MAX_DELIVERY_ATTEMPTS` configured in production.
8. Closes client cleanly on shutdown.

## 9) Anti-Patterns to Reject in Code Review

1. New code that uses `Nack` / `RequestRetry` for normal processing-failure redelivery.
2. Custom retry loop around `Subscribe` that ignores SDK reconnect logic.
3. Custom in-memory DLQ queue or ad-hoc Redis key pattern outside NeonLink APIs.
4. Double-ack logic (manual ACK plus `AutoAck=true`).
5. Wrapping SDK with another wrapper that duplicates circuit breaker/backpressure/retry control.
