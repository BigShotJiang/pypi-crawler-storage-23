class CoordinateError(Exception):
    pass


class PathError(Exception):
    pass
