from .main import entrypoint

entrypoint()
