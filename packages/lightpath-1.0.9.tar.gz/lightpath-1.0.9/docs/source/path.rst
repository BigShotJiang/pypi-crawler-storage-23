BeamPath
***********
.. automodule:: lightpath.path

.. currentmodule:: lightpath.path
.. autoclass:: LightpathState
   :members:
.. autoclass:: BeamPath
   :members:
