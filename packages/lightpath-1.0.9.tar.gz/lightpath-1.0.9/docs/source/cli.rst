Command Line Interface
======================

.. argparse::
    :ref: lightpath.main.create_arg_parser
    :prog: lightpath
