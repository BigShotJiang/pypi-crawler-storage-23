LightController
===============
.. automodule:: lightpath.controller

.. autoclass:: lightpath.LightController
    :members:
