"""
Workflow visualization setup module.

This module provides functionality to set up workflow or agent visualization
"""

from agent_framework import WorkflowAgent
import logging
import time
from typing import Any, Optional


def _get_agent_from_server(agent_server: Any) -> Optional[Any]:
    """
    Extract the agent from an agent server instance.
    
    Args:
        agent_server: The agent server instance
        
    Returns:
        The agent instance, or None if not found
    """
    if hasattr(agent_server, '_agent') and agent_server._agent is not None:
        return agent_server._agent
    
    if hasattr(agent_server, 'agent') and agent_server.agent is not None:
        return agent_server.agent
    
    if hasattr(agent_server, '_workflow_factory') and agent_server._workflow_factory is not None:
        try:
            return agent_server._workflow_factory().as_agent()
        except Exception as e:
            logging.debug("Failed to build workflow agent (%s): %s", type(e).__name__, e)
    
    if hasattr(agent_server, '_build_agent'):
        try:
            return agent_server._build_agent()
        except Exception as e:
            logging.debug("Failed to call _build_agent (%s): %s", type(e).__name__, e)
    
    return None


def configure_agent_server(agent_server):
    """
    Set up workflow or agent visualization for an agent server.
    
    This function configures a health check endpoint and starts a visualization
    server for workflow agents on port 8090.
    
    Args:
        agent_server: The agent server instance to set up visualization for.
                     Should have 'app' (Starlette) attribute. The agent is 
                     extracted using `_get_agent_from_server()` which supports
                     both old and new SDK versions.
    
    Example:
        >>> from azure.ai.agentserver.agentframework import from_agent_framework
        >>> agent_server = from_agent_framework(agent)
        >>> configure_agent_server(agent_server)
        >>> await agent_server.run_async()
    """
    from starlette.applications import Starlette
    from starlette.responses import JSONResponse
    from starlette.routing import Route
    from threading import Thread
    from agentdev.backend.server import TestToolServer
    
    async def health_check(request):
        """Health check endpoint handler."""
        return JSONResponse({"status": "ok"}, status_code=200)
    
    app = agent_server.app
    agent = _get_agent_from_server(agent_server)
    
    if agent is None:
        logging.warning("agentdev: Could not extract agent from server, visualization may be limited")

    app.mount(
        "/agentdev/health",
        Starlette(routes=[Route("/", health_check)])
    )

    entities = []
    if agent is not None:
        if isinstance(agent, WorkflowAgent):
            entities.append(agent.workflow)
        else:
            entities.append(agent)

    test_tool_server = TestToolServer(entities)
    test_tool_server.mount_backend(app)
    def show_startup_message():
        time.sleep(2)
        logging.info("agentdev: Application startup complete")
    thread = Thread(target=show_startup_message)
    thread.daemon = True
    thread.start()
    
    logging.debug("Agent server configured: %s", agent)
