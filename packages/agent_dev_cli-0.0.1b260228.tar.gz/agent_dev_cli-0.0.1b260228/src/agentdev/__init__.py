"""
agentdev Package

Agent Dev CLI - A package for agent debugging and workflow visualization.

This package provides two ways to use agentdev:

1. CLI Wrapper (Recommended - No code changes required):
   
   $ agentdev run my_agent.py
   $ agentdev run workflow.py --port 9000
   
2. Programmatic API (Requires code modification):
   
   from agentdev import configure_agent_server
   configure_agent_server(agent_server)
"""

from .localdebug import configure_agent_server
from ._version import __version__

__all__ = ["configure_agent_server", "__version__"]
