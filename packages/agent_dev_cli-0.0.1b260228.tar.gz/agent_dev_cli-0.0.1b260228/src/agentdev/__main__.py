"""Allow running agentdev as a module: python -m agentdev"""
from agentdev.cli import main

if __name__ == "__main__":
    main()
