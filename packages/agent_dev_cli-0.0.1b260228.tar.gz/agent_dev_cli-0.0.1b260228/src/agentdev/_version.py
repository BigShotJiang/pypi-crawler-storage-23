"""Version information for agentdev package."""
__version__ = "0.0.1b260228"
