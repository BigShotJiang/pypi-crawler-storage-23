# from .few_shot import FewShotLearner as LEA_FEW_SHOT
from .zero_shot import ZeroShotLearner as LEA_ZERO_SHOT
from .transfer_learning import TransferLearningLearner as LEA_TRANSFER_LEARNING
from .meta_learning import MetaLearner as LEA_META_LEARNING
