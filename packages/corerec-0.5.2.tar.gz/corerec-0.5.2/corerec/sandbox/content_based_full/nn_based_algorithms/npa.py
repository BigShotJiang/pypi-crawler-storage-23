# npa implementation
class NPA:
    pass
