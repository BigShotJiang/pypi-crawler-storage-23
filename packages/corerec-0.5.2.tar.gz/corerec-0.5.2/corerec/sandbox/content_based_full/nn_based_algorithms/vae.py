# vae implementation
class VAE:
    pass
