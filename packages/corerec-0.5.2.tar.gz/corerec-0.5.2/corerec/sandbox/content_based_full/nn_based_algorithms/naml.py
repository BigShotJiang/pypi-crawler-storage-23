# naml implementation
class NAML:
    pass
