# nrms implementation
class NRMS:
    pass
