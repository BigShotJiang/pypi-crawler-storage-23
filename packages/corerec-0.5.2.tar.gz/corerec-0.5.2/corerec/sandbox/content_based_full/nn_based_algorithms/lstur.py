# lstur implementation
class LSTUR:
    pass
