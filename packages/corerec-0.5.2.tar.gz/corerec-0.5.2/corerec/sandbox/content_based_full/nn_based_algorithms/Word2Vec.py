class Word2Vec:
    def __init__(self):
        pass

    def train(self):
        pass
