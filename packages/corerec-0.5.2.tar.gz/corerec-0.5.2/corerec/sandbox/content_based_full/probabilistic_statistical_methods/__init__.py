from .lsa import LSA as PRO_LSA
from .lda import LDA as PRO_LDA
from .bayesian import BAYESIAN as PRO_BAYESIAN
from .fuzzy_logic import FUZZY_LOGIC as PRO_FUZZY_LOGIC
