# feature_extraction implementation
import logging
from typing import List, Any

from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.stem import WordNetLemmatizer
import nltk

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class FeatureExtraction:
    def __init__(self, max_features=5000):
        """
        Initializes the FeatureExtraction with a TF-IDF vectorizer.

        Parameters:
        - max_features (int): The maximum number of features (vocabulary size).
        """
        self.max_features = max_features
        self.lemmatizer = WordNetLemmatizer()
        self.vectorizer = TfidfVectorizer(
            max_features=self.max_features,
            stop_words="english",  # Use built-in stop words
            tokenizer=self.tokenize,
        )
        logger.info(f"FeatureExtraction initialized with max_features={self.max_features}.")

    def tokenize(self, text: str) -> List[str]:
        """
        Tokenizes and lemmatizes the input text.

        Parameters:
        - text (str): The text to tokenize.

        Returns:
        - list: A list of processed tokens.

        Note:
        - We do **not** download NLTK data automatically (no network calls on import).
        - If the required NLTK resources are missing, this will raise a clear error
          instructing the user how to install them.
        """
        try:
            tokens = nltk.word_tokenize(text.lower())
        except LookupError as e:
            raise RuntimeError(
                "NLTK resource(s) required for tokenization are missing.\n"
                "Please download them manually, for example:\n"
                "  >>> import nltk\n"
                "  >>> nltk.download('punkt')\n"
                "  >>> nltk.download('wordnet')"
            ) from e

        lemmatized = [
            self.lemmatizer.lemmatize(token) for token in tokens if token.isalpha()
        ]
        logger.debug(f"Tokenized text: {lemmatized}")
        return lemmatized

    def fit_transform(self, documents: List[str]):
        """
        Fits the TF-IDF vectorizer on the documents and transforms them into feature vectors.

        Parameters:
        - documents (list of str): The list of documents to process.

        Returns:
        - sparse matrix: The TF-IDF feature matrix.
        """
        logger.info("Fitting and transforming documents into TF-IDF features.")
        return self.vectorizer.fit_transform(documents)

    def transform(self, documents: List[str]) -> Any:
        """
        Transforms the documents into TF-IDF feature vectors using the already fitted vectorizer.

        Parameters:
        - documents (list of str): The list of documents to transform.

        Returns:
        - sparse matrix: The TF-IDF feature matrix.
        """
        logger.info("Transforming documents into TF-IDF features.")
        if not hasattr(self.vectorizer, 'vocabulary_'):
            raise ValueError("Vectorizer must be fitted before transform. Call fit_transform first.")
        tfidf_matrix = self.vectorizer.transform(documents)  # Use transform, not fit
        return tfidf_matrix

    def get_feature_names(self) -> List[str]:
        """
        Retrieves the feature names (vocabulary) from the vectorizer.

        Returns:
        - list: A list of feature names.
        """
        return self.vectorizer.get_feature_names_out()
