from .multi_modal import MULTI_MODAL as MUL_MULTI_MODAL
from .cross_domain import CROSS_DOMAIN as MUL_CROSS_DOMAIN
from .cross_lingual import CROSS_LINGUAL as MUL_CROSS_LINGUAL
