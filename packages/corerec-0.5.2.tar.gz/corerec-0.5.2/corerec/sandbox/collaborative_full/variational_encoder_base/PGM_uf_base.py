# Probabilistic Graphical Models for Collaborative Filtering


class PGMUFBase:
    pass
