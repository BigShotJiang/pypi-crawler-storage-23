class StandardVAEBase:
    pass
