class VariationalAutoencoderUFBase:
    pass
