# Bayesian Personalized Ranking with Extensions
class BayesianPersonalizedRankingExtensionsBase:
    pass
