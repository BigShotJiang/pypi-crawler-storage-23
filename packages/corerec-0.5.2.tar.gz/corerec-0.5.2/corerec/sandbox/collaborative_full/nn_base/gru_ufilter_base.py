class GRU_ufilter_base:
    def __init__(self):
        pass

    def train(self):
        pass
