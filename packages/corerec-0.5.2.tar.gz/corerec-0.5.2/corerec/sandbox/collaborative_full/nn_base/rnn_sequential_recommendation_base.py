class RNN_sequential_recommendation_base:
    def __init__(self):
        pass

    def train(self):
        pass
