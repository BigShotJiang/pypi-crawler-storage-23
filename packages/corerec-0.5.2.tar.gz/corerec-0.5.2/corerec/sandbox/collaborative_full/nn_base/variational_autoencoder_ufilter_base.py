class VariationalAutoencoderUFilterBase:
    def __init__(self):
        pass

    def train(self):
        pass
