class DeepWalk_base:
    def __init__(self):
        pass

    def train(self):
        pass

    def predict(self):
        pass
