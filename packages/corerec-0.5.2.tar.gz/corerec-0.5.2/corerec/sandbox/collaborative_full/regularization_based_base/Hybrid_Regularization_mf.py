class HybridRegularizationMF:
    pass
