# Self-Attentive Sequential Recommendation (SASRec) (also fits in nn_base)
class SASRecBase:
    pass
