# Sequence-aware Collaborative Filtering (also fits in nn_base)
class SequenceAwareUFBase:
    pass
