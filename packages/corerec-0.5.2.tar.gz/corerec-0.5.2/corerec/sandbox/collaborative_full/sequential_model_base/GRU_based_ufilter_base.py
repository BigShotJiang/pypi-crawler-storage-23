# (also fits in nn_base)
class GRUBasedUFilterBase:
    pass
