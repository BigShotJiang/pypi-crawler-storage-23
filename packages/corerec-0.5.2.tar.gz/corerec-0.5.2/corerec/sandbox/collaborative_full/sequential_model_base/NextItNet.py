# Next Item Recommendation (NextItNet) (also fits in nn_base)
class NextItNetBase:
    pass
