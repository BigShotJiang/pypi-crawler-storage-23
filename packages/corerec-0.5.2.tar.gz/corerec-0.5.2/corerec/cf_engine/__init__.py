# mintos life
# from corerec.engines.content_based import *

# hardcore
from corerec.engines.content_based.context_personalization import (
    context_aware,
    item_profiling,
    user_profiling,
)
from corerec.engines.content_based.embedding_representation_learning import (
    doc2vec,
    personalized_embeddings,
    word2vec,
)
from corerec.engines.content_based.fairness_explainability import (
    explainable,
    fairness_aware,
    privacy_preserving,
)
from corerec.engines.content_based.graph_based_algorithms import (
    gnn,
    graph_filtering,
    semantic_models,
)
from corerec.engines.content_based.hybrid_ensemble_methods import (
    attention_mechanisms,
    ensemble_methods,
    hybrid_collaborative,
)
from corerec.engines.content_based.learning_paradigms import (
    few_shot,
    meta_learning,
    transfer_learning,
    zero_shot,
)
from corerec.engines.content_based.miscellaneous_techniques import (
    cold_start,
    feature_selection,
    noise_handling,
)
from corerec.engines.content_based.multi_modal_cross_domain_methods import (
    cross_domain,
    cross_lingual,
    multi_modal,
)
from corerec.engines.content_based.nn_based_algorithms import (
    AITM,
    CNNRecommender as cnn,
    DKN as dkn,
    DSSM,
    LSTUR as lstur,
    NAML as naml,
    NPA as npa,
    NRMS as nrms,
    RNNRecommender as rnn,
    TDM,
    TransformerRecommender as transformer,
    VAERecommender as vae,
    WideAndDeep as WidenDeep,
    Word2VecNN as Word2Vec,
    YoutubeDNN as Youtube_dnn,
    ContentMIND as TRA_MIND,
)
from corerec.engines.content_based.other_approaches import (
    ontology_based,
    rule_based,
    sentiment_analysis,
)
from corerec.engines.content_based.performance_scalability import (
    feature_extraction,
    load_balancing,
    scalable_algorithms,
)
from corerec.engines.content_based.probabilistic_statistical_methods import (
    bayesian,
    fuzzy_logic,
    lda,
    lsa,
)
from corerec.engines.content_based.traditional_ml_algorithms import (
    decision_tree,
    lightgbm,
    LR,
    svm,
    tfidf,
    vw,
)

# these mpodules are exposed in super-set
from corerec.engines.content_based import cr_contentFilterFactory
from corerec.engines.content_based import tfidf_recommender
from corerec.base_recommender import BaseCorerec

# from corerec.engines.collaborative import mf_base__A


__all__ = [
    "context_aware",
    "item_profiling",
    "user_profiling",
    "doc2vec",
    "personalized_embeddings",
    "word2vec",
    "explainable",
    "fairness_aware",
    "privacy_preserving",
    "gnn",
    "graph_filtering",
    "semantic_models",
    "attention_mechanisms",
    "ensemble_methods",
    "hybrid_collaborative",
    "few_shot",
    "meta_learning",
    "transfer_learning",
    "zero_shot",
    "cold_start",
    "feature_selection",
    "noise_handling",
    "cross_domain",
    "cross_lingual",
    "multi_modal",
    "AITM",
    "cnn",
    "dkn",
    "DSSM",
    "lstur",
    "naml",
    "npa",
    "nrms",
    "rnn",
    "TDM",
    "transformer",
    "vae",
    "WidenDeep",
    "Word2Vec",
    "Youtube_dnn",
    "TRA_MIND",
    "ontology_based",
    "rule_based",
    "sentiment_analysis",
    "feature_extraction",
    "load_balancing",
    "scalable_algorithms",
    "bayesian",
    "fuzzy_logic",
    "lda",
    "lsa",
    "decision_tree",
    "lightgbm",
    "LR",
    "svm",
    "tfidf",
    "vw",
    "cr_contentFilterFactory",
    "tfidf_recommender",
    "BaseCorerec",
]
