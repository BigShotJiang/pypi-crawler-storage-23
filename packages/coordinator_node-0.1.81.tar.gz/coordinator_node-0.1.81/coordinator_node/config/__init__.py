"""Configuration loading and defaults for node template."""
