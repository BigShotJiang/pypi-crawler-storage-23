# schemas

Define challenge-specific JSONB payload models here.

Keep core envelope contracts in `coordinator_core` and embed challenge payloads inside them.
