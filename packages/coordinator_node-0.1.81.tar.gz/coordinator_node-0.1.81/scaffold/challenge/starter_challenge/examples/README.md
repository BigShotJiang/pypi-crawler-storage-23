# examples

Simple public quickstarters for participants.

- `mean_reversion_tracker.py` — fades short-term overextension.
- `trend_following_tracker.py` — follows short-term momentum.
- `volatility_regime_tracker.py` — adapts signal strength across volatility regimes.

All examples return a prediction dictionary with a numeric `value` field.
