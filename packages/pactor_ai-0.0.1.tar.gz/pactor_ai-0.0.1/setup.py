# setup.py 파일 내용
from setuptools import setup, find_packages

setup(
    name="pactor-ai", # 여기서 이름이 결정됩니다!
    version="0.0.1",  # 더미 버전
    description="Agreement infrastructure for AI agents.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Pactor",
    author_email="hello@pactor.ai", # 대표님 이메일로 변경하셔도 됩니다
    url="https://pactor.ai",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)
