# Pactor.ai

Agreement infrastructure for AI agents.
Pactor tracks proposals, counter-proposals, acceptances, and rejections — so agents can negotiate with a shared, auditable state.

*Official package coming soon.*
