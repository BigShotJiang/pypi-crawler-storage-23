Errors
======

All errors are based on ``joserfc.errors.JoseError``.

.. automodule:: joserfc.errors
    :members:
