---
name: telegram
description: Connect, disconnect, or manage the Telegram channel so you can chat with the agent on Telegram.
user_invocable: true
tools: [manage_channel]
---

# Telegram Channel Setup

Use the `manage_channel` tool to connect the agent to Telegram.

## Quick Start

1. **If the user already has a bot token**, run setup then connect:
   - `manage_channel(action="setup", config={"bot_token": "<token>"})`
   - `manage_channel(action="connect", channel_type="telegram")`

2. **If the user needs a token**, walk them through it:
   - Tell them to open Telegram, search for **@BotFather**, send `/newbot`, and follow the prompts
   - Once they paste the token, run setup and connect as above

3. **To check status**: `manage_channel(action="status")`
4. **To disconnect**: `manage_channel(action="disconnect", channel_type="telegram")`

## Actions

| Action | What it does |
|---|---|
| `setup` | Saves the bot token to `~/.emdash/telegram.json` and verifies it with the Telegram API |
| `connect` | Starts long-polling in the background — messages from Telegram flow to the agent |
| `disconnect` | Stops the polling loop and unregisters the channel |
| `status` | Shows which channels are registered, which is primary, and whether they're running |

## Notes

- The bot token comes from Telegram's @BotFather (one-time setup).
- After `connect`, the agent receives messages from authorized Telegram chats and responds through the same channel.
- Configuration is stored in `~/.emdash/telegram.json`.
- If no authorized chats are configured, all chats are allowed (useful during initial setup).
