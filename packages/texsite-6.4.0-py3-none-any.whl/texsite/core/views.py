from django.shortcuts import redirect, render
from django.templatetags.static import static

from texsite.core.models import (
    DEFAULT_THEME,
    SiteBranding,
    get_theme_for_request,
)


def _resolve_error_template(request):
    try:
        theme = get_theme_for_request(request)
    except Exception:
        theme = DEFAULT_THEME
    return f'texsite{theme}/error.html'


def page_not_found(request, exception):
    template = _resolve_error_template(request)
    context = {'error_message': 'Sorry, this page could not be found.'}
    return render(request, template, context=context, status=404)


def server_error(request):
    template = _resolve_error_template(request)
    context = {
        'error_message': (
            'Sorry, there seems to be an error. Please try again soon.'
        )
    }
    return render(request, template, context=context, status=500)


def robots_txt(request):
    context = {'sitemap_url': request.build_absolute_uri('/sitemap.xml')}
    return render(
        request,
        'texsitecore/robots.txt',
        context=context,
        content_type='text/plain',
    )


def favicon_ico(request):
    branding = SiteBranding.for_request(request)
    if branding.favicon:
        rendition = branding.favicon.get_rendition('fill-32x32|format-png')
        return redirect(rendition.url)
    return redirect(static('/favicon/favicon.ico'))
