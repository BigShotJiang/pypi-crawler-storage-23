from django.apps import AppConfig


class TexsiteCoreAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'texsite.core'
    label = 'texsitecore'
    verbose_name = 'texsite core'
