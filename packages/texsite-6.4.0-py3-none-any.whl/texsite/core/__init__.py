default_app_config = 'texsite.core.apps.TexsiteCoreAppConfig'
