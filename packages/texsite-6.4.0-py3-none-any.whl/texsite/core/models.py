from django.db.models import SET_NULL, BooleanField, CharField, ForeignKey
from django.template.response import TemplateResponse
from django.utils.translation import gettext_lazy as _
from wagtail.admin.panels import FieldPanel, MultiFieldPanel
from wagtail.admin.widgets.slug import SlugInput
from wagtail.blocks import RawHTMLBlock, RichTextBlock
from wagtail.contrib.settings.models import BaseSiteSetting, register_setting
from wagtail.fields import StreamField
from wagtail.models import Page
from wagtail.search.index import FilterField

from texsite.core.blocks import (
    ArticleListingBlock,
    CarouselBlock,
    CodeBlock,
    ContactBlock,
    DocumentsBlock,
    ImageBlock,
    PeopleBlock,
    PromotedPagesBlock,
    QuoteBlock,
)


DEFAULT_THEME = 'cleanblog'

THEME_CHOICES = [
    ('cleanblog', 'Clean Blog'),
    ('businesscasual', 'Business Casual'),
    ('freelancer', 'Freelancer'),
    ('xperience', 'Xperience'),
]


def get_theme_for_request(request):
    branding = SiteBranding.for_request(request)
    return branding.theme if branding else DEFAULT_THEME


@register_setting
class SiteBranding(BaseSiteSetting):
    logo = ForeignKey(
        'wagtailimages.Image',
        null=True,
        blank=True,
        on_delete=SET_NULL,
        related_name='+',
        verbose_name=_('logo'),
    )
    favicon = ForeignKey(
        'wagtailimages.Image',
        null=True,
        blank=True,
        on_delete=SET_NULL,
        related_name='+',
        verbose_name=_('favicon'),
    )
    theme = CharField(
        max_length=20,
        choices=THEME_CHOICES,
        default=DEFAULT_THEME,
        verbose_name=_('theme'),
    )

    panels = [
        FieldPanel('theme'),
        FieldPanel('logo'),
        FieldPanel('favicon'),
    ]

    class Meta:
        verbose_name = _('site branding')


class BasePage(Page):
    is_creatable = False

    show_in_footer = BooleanField(
        verbose_name=_('show in footer'),
        default=False,
        help_text=_(
            'Whether a link to this page will appear in automatically '
            'generated footers'
        ),
    )

    search_fields = Page.search_fields + [
        FilterField('show_in_footer'),
    ]
    promote_panels = [
        MultiFieldPanel(
            [
                FieldPanel('slug', widget=SlugInput),
                FieldPanel('seo_title'),
                FieldPanel('search_description'),
            ],
            _('For search engines'),
        ),
        MultiFieldPanel(
            [
                FieldPanel('first_published_at'),
            ],
            _('Timeline'),
        ),
        MultiFieldPanel(
            [
                FieldPanel('show_in_menus'),
                FieldPanel('show_in_footer'),
            ],
            _('For site menus'),
        ),
    ]

    def serve_password_required_response(self, request, form, action_url):
        theme = get_theme_for_request(request)
        context = self.get_context(request)
        context['form'] = form
        context['action_url'] = action_url
        return TemplateResponse(
            request, f'texsite{theme}/login_password.html', context
        )

    @property
    def next_sibling(self):
        return self.get_next_siblings().live().first()

    @property
    def previous_sibling(self):
        return self.get_prev_siblings().live().first()

    class Meta:
        verbose_name = _('Base Page') + ' (' + __package__ + ')'


class UniversalPage(BasePage):
    header_image = ForeignKey(
        'wagtailimages.Image',
        null=True,
        blank=True,
        on_delete=SET_NULL,
        related_name='+',
        verbose_name=_('header image'),
    )
    subtitle = CharField(
        max_length=255,
        blank=True,
        verbose_name=_('subtitle'),
    )
    body = StreamField(
        [
            ('paragraph', RichTextBlock()),
            ('image', ImageBlock()),
            ('quote', QuoteBlock()),
            ('code', CodeBlock()),
            ('carousel', CarouselBlock()),
            ('article_listing', ArticleListingBlock()),
            ('promoted_pages', PromotedPagesBlock()),
            ('documents', DocumentsBlock()),
            ('people', PeopleBlock()),
            ('contact', ContactBlock()),
            ('raw_html', RawHTMLBlock()),
        ],
    )

    content_panels = BasePage.content_panels + [
        MultiFieldPanel(
            [FieldPanel('header_image'), FieldPanel('subtitle')],
            _('Page header'),
        ),
        FieldPanel('body'),
    ]

    @property
    def og_image(self):
        if self.header_image:
            return self.header_image
        for block in self.body:
            if block.block_type == 'image':
                return block.value['image']
            if block.block_type == 'carousel':
                return block.value['images'][0]
        return None

    def get_template(self, request, *args, **kwargs):
        theme = get_theme_for_request(request)
        return f'texsite{theme}/universal_page.html'

    class Meta:
        verbose_name = _('Universal Page') + ' (' + __package__ + ')'
