from django.db import connection, migrations


def hide_root_from_menu(apps, schema_editor):
    cursor = connection.cursor()

    cursor.execute(
        'SELECT s.root_page_id '
        'FROM wagtailcore_site s '
        'JOIN texsitecore_sitebranding b ON b.site_id = s.id '
        "WHERE b.theme = 'businesscasual'"
    )
    for (root_page_id,) in cursor.fetchall():
        cursor.execute(
            'UPDATE wagtailcore_page '
            'SET show_in_menus = 0 '
            'WHERE id = %s AND show_in_menus = 1',
            [root_page_id],
        )


class Migration(migrations.Migration):
    dependencies = [
        ('texsitecore', '0017_freelancer_root_header_image'),
    ]

    operations = [
        migrations.RunPython(
            hide_root_from_menu,
            migrations.RunPython.noop,
        ),
    ]
