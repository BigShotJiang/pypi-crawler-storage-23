from django.db import connection, migrations


def copy_logo_to_header_image(apps, schema_editor):
    cursor = connection.cursor()

    cursor.execute(
        'SELECT s.root_page_id, b.logo_id '
        'FROM wagtailcore_site s '
        'JOIN texsitecore_sitebranding b ON b.site_id = s.id '
        "WHERE b.theme = 'freelancer' AND b.logo_id IS NOT NULL"
    )
    for root_page_id, logo_id in cursor.fetchall():
        cursor.execute(
            'UPDATE texsitecore_universalpage '
            'SET header_image_id = %s '
            'WHERE basepage_ptr_id = %s AND header_image_id IS NULL',
            [logo_id, root_page_id],
        )


class Migration(migrations.Migration):
    dependencies = [
        ('texsitecore', '0016_alter_universalpage_body'),
    ]

    operations = [
        migrations.RunPython(
            copy_logo_to_header_image,
            migrations.RunPython.noop,
        ),
    ]
