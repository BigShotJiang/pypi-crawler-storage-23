from django.db import connection, migrations


def populate_xperience_subtitle(apps, schema_editor):
    cursor = connection.cursor()

    # Get xperience site root paths
    cursor.execute(
        'SELECT s.root_page_id, b.theme '
        'FROM wagtailcore_site s '
        'JOIN texsitecore_sitebranding b ON b.site_id = s.id '
        "WHERE b.theme = 'xperience'"
    )
    root_paths = []
    for root_page_id, _ in cursor.fetchall():
        cursor.execute(
            'SELECT path FROM wagtailcore_page WHERE id = %s', [root_page_id]
        )
        row = cursor.fetchone()
        if row:
            root_paths.append(row[0])

    if not root_paths:
        return

    # Move seo_title → subtitle for xperience pages where seo_title differs
    cursor.execute(
        'SELECT p.id, p.title, p.seo_title '
        'FROM wagtailcore_page p '
        'JOIN texsitecore_universalpage u ON u.basepage_ptr_id = p.id'
    )
    for page_id, title, seo_title in cursor.fetchall():
        if not seo_title or seo_title == title:
            continue

        cursor.execute(
            'SELECT path FROM wagtailcore_page WHERE id = %s', [page_id]
        )
        path = cursor.fetchone()[0]
        if not any(path.startswith(rp) for rp in root_paths):
            continue

        cursor.execute(
            'UPDATE texsitecore_universalpage SET subtitle = %s '
            'WHERE basepage_ptr_id = %s',
            [seo_title, page_id],
        )
        cursor.execute(
            "UPDATE wagtailcore_page SET seo_title = '' WHERE id = %s",
            [page_id],
        )


class Migration(migrations.Migration):
    dependencies = [
        ('texsitecore', '0011_universalpage_subtitle'),
    ]

    operations = [
        migrations.RunPython(
            populate_xperience_subtitle,
            migrations.RunPython.noop,
        ),
    ]
