import json

from django.db import connection, migrations


def populate_headers(apps, schema_editor):
    cursor = connection.cursor()

    # Get theme per site root path
    cursor.execute(
        'SELECT s.root_page_id, b.theme '
        'FROM wagtailcore_site s '
        'JOIN texsitecore_sitebranding b ON b.site_id = s.id'
    )
    site_themes = {}
    for root_page_id, theme in cursor.fetchall():
        cursor.execute(
            'SELECT path FROM wagtailcore_page WHERE id = %s', [root_page_id]
        )
        row = cursor.fetchone()
        if row:
            site_themes[row[0]] = theme

    # Process all UniversalPages
    cursor.execute(
        'SELECT p.id, p.path, u.body '
        'FROM wagtailcore_page p '
        'JOIN texsitecore_universalpage u ON u.basepage_ptr_id = p.id'
    )
    for page_id, path, body_json in cursor.fetchall():
        theme = None
        for root_path, t in site_themes.items():
            if path.startswith(root_path):
                theme = t
                break

        if theme not in ('cleanblog', 'freelancer'):
            continue

        body = json.loads(body_json) if body_json else []
        if not body:
            continue

        header_image_id = None
        subtitle = ''

        if theme == 'cleanblog':
            if body[0].get('type') == 'intro':
                intro = body[0]['value']
                header_image_id = intro.get('keyvisual')
                subtitle = intro.get('slogan', '')

        elif theme == 'freelancer':
            for block in body:
                if block.get('type') == 'intro':
                    intro = block['value']
                    header_image_id = intro.get('keyvisual')
                    subtitle = intro.get('slogan', '')
                    break
                if block.get('type') == 'hero_image':
                    header_image_id = block['value'].get('image')
                    break

        if header_image_id or subtitle:
            cursor.execute(
                'UPDATE texsitecore_universalpage '
                'SET header_image_id = %s, subtitle = %s '
                'WHERE basepage_ptr_id = %s',
                [header_image_id, subtitle, page_id],
            )

        # Purge intro and hero_image blocks from body
        cleaned = [
            b for b in body if b.get('type') not in ('intro', 'hero_image')
        ]
        if len(cleaned) != len(body):
            cursor.execute(
                'UPDATE texsitecore_universalpage SET body = %s '
                'WHERE basepage_ptr_id = %s',
                [json.dumps(cleaned), page_id],
            )


class Migration(migrations.Migration):
    dependencies = [
        ('texsitecore', '0013_universalpage_header_image'),
    ]

    operations = [
        migrations.RunPython(
            populate_headers,
            migrations.RunPython.noop,
        ),
    ]
