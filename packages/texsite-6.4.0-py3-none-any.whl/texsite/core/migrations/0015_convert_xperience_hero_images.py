import json

from django.db import connection, migrations


def _convert_hero_images(body):
    result = []
    i = 0
    while i < len(body):
        block = body[i]

        if block.get('type') == 'hero_image':
            image_id = block['value'].get('image')

            # Check if preceded by a standalone <h2> paragraph
            if result and result[-1].get('type') == 'paragraph':
                prev_value = result[-1]['value']
                stripped = prev_value.strip()
                if stripped.startswith('<h2') and stripped.endswith('</h2>'):
                    h2_html = result.pop()['value']
                    # Prepend h2 to the next paragraph block
                    if (
                        i + 1 < len(body)
                        and body[i + 1].get('type') == 'paragraph'
                    ):
                        body[i + 1]['value'] = h2_html + body[i + 1]['value']

            # Convert hero_image → image
            result.append(
                {
                    'type': 'image',
                    'value': {'image': image_id, 'caption': ''},
                    'id': block.get('id', ''),
                }
            )
        else:
            result.append(block)
        i += 1
    return result


def convert_and_purge(apps, schema_editor):
    cursor = connection.cursor()

    # Get xperience site root paths
    cursor.execute(
        'SELECT s.root_page_id, b.theme '
        'FROM wagtailcore_site s '
        'JOIN texsitecore_sitebranding b ON b.site_id = s.id'
    )
    site_themes = {}
    for root_page_id, theme in cursor.fetchall():
        cursor.execute(
            'SELECT path FROM wagtailcore_page WHERE id = %s', [root_page_id]
        )
        row = cursor.fetchone()
        if row:
            site_themes[row[0]] = theme

    # Process all UniversalPages
    cursor.execute(
        'SELECT p.id, p.path, u.body '
        'FROM wagtailcore_page p '
        'JOIN texsitecore_universalpage u ON u.basepage_ptr_id = p.id'
    )
    for page_id, path, body_json in cursor.fetchall():
        theme = None
        for root_path, t in site_themes.items():
            if path.startswith(root_path):
                theme = t
                break

        body = json.loads(body_json) if body_json else []
        if not body:
            continue

        original = body_json

        # Convert xperience hero_image blocks to image blocks
        if theme == 'xperience':
            body = _convert_hero_images(body)

        # Safety sweep: purge any remaining intro/hero_image blocks
        cleaned = [
            b for b in body if b.get('type') not in ('intro', 'hero_image')
        ]

        new_json = json.dumps(cleaned)
        if new_json != original:
            cursor.execute(
                'UPDATE texsitecore_universalpage SET body = %s '
                'WHERE basepage_ptr_id = %s',
                [new_json, page_id],
            )


class Migration(migrations.Migration):
    dependencies = [
        ('texsitecore', '0014_cleanblog_freelancer_headers'),
    ]

    operations = [
        migrations.RunPython(
            convert_and_purge,
            migrations.RunPython.noop,
        ),
    ]
