import json

from django import template
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from django.core.paginator import Page as PaginatorPage
from django.utils.html import _json_script_escapes
from wagtail.models import Page, Site

from texsite.core.models import BasePage, get_theme_for_request


register = template.Library()


@register.simple_tag
def get_footer_pages(site: Site) -> list[BasePage]:
    return BasePage.objects.in_site(site).live().filter(show_in_footer=True)


@register.simple_tag
def get_menu_pages(site: Site) -> list[BasePage]:
    return BasePage.objects.in_site(site).live().filter(show_in_menus=True)


@register.simple_tag
def get_live_descendant_pages(
    parent: Page, limit: int = 0, newest_first: bool = False
) -> list[Page]:
    order_by = '-first_published_at' if newest_first else 'first_published_at'

    return parent.get_descendants().live().order_by(order_by)[:limit]


@register.simple_tag
def get_paginator(
    requested_page: str, pages: list[Page], per_page: int
) -> PaginatorPage:
    paginator = Paginator(pages, per_page)

    try:
        paginator_page = paginator.page(requested_page)
    except PageNotAnInteger:
        paginator_page = paginator.page(1)
    except EmptyPage:
        paginator_page = paginator.page(paginator.num_pages)

    return paginator_page


@register.filter
def og_locale(language_code: str) -> str:
    parts = language_code.split('-')
    if len(parts) == 2:
        return f'{parts[0]}_{parts[1].upper()}'
    return parts[0]


def _jsonld(data: dict) -> str:
    return json.dumps(data).translate(_json_script_escapes)


@register.simple_tag(takes_context=True)
def get_jsonld_website(context) -> str:
    page = context.get('self')
    if not page:
        return ''
    site = Site.find_for_request(context['request'])
    if page.pk != site.root_page_id:
        return ''
    return _jsonld(
        {
            '@context': 'https://schema.org',
            '@type': 'WebSite',
            'name': site.site_name,
            'url': site.root_page.full_url,
        }
    )


@register.simple_tag(takes_context=True)
def get_jsonld_webpage(context) -> str:
    page = context.get('self')
    if not page:
        return ''
    title = page.seo_title or page.title
    data = {
        '@context': 'https://schema.org',
        '@type': 'WebPage',
        'name': title,
        'url': page.full_url,
    }
    if page.search_description:
        data['description'] = page.search_description
    return _jsonld(data)


@register.simple_tag(takes_context=True)
def get_jsonld_breadcrumbs(context) -> str:
    page = context.get('self')
    if not page:
        return ''
    site = Site.find_for_request(context['request'])
    ancestors = page.get_ancestors(inclusive=True).descendant_of(
        site.root_page, inclusive=True
    )
    if len(ancestors) <= 1:
        return ''
    items = []
    for position, ancestor in enumerate(ancestors, start=1):
        items.append(
            {
                '@type': 'ListItem',
                'position': position,
                'name': ancestor.title,
                'item': ancestor.full_url,
            }
        )
    return _jsonld(
        {
            '@context': 'https://schema.org',
            '@type': 'BreadcrumbList',
            'itemListElement': items,
        }
    )


@register.simple_tag(takes_context=True)
def get_block_template(context, block_type: str) -> str:
    request = context.get('request')
    theme = get_theme_for_request(request)
    return f'texsite{theme}/blocks/{block_type}.html'
