from wagtail.blocks import (
    BooleanBlock,
    CharBlock,
    EmailBlock,
    IntegerBlock,
    ListBlock,
    PageChooserBlock,
    StructBlock,
    TextBlock,
)
from wagtail.documents.blocks import DocumentChooserBlock
from wagtail.images.blocks import ImageChooserBlock


class ImageBlock(StructBlock):
    image = ImageChooserBlock(required=True)
    caption = CharBlock(required=False)

    class Meta:
        icon = 'image'


class QuoteBlock(StructBlock):
    quote = TextBlock(required=True)
    originator = CharBlock(required=False)

    class Meta:
        icon = 'openquote'


class CodeBlock(StructBlock):
    code = TextBlock(required=True)
    language = CharBlock(required=False)

    class Meta:
        icon = 'code'


class PromotedPageBlock(StructBlock):
    page = PageChooserBlock(required=True)
    teaser = ImageChooserBlock(required=True)

    class Meta:
        icon = 'placeholder'


class ArticleListingBlock(StructBlock):
    parent = PageChooserBlock()
    limit = IntegerBlock(required=False, min_value=1)
    newest_first = BooleanBlock(default=True, required=False)

    class Meta:
        icon = 'list-ul'


class CarouselBlock(StructBlock):
    images = ListBlock(ImageChooserBlock(), min_num=2)

    class Meta:
        icon = 'image'


class PromotedPagesBlock(StructBlock):
    pages = ListBlock(PromotedPageBlock())

    class Meta:
        icon = 'pick'


class PersonBlock(StructBlock):
    name = CharBlock(required=True)
    image = ImageChooserBlock(required=True)
    position = CharBlock(required=False)

    class Meta:
        icon = 'user'


class PeopleBlock(StructBlock):
    people = ListBlock(PersonBlock())

    class Meta:
        icon = 'group'


class DocumentsBlock(StructBlock):
    files = ListBlock(DocumentChooserBlock())

    class Meta:
        icon = 'doc-full'


class ContactBlock(StructBlock):
    map = CharBlock(required=False)
    name = CharBlock(required=True)
    phone = CharBlock(required=False)
    mail = EmailBlock(required=False)
    bank = CharBlock(required=False)

    class Meta:
        icon = 'site'
