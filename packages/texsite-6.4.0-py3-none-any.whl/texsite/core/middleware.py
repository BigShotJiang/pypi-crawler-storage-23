from django.http import HttpResponsePermanentRedirect
from wagtail.models import Site


class WwwRedirectMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        host = request.get_host()
        hostname = host.split(':')[0]

        if not hostname.startswith('www.'):
            www_hostname = f'www.{hostname}'
            if Site.objects.filter(hostname=www_hostname).exists():
                return HttpResponsePermanentRedirect(
                    f'{request.scheme}://www.{host}{request.get_full_path()}'
                )

        return self.get_response(request)
