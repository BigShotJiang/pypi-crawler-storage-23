import re

from django import template


register = template.Library()

H2_RE = re.compile(r'<h2[^>]*>(.*?)</h2>', re.IGNORECASE | re.DOTALL)
TAG_RE = re.compile(r'<[^>]+>')


@register.simple_tag
def get_section_nav(page):
    sections = []
    for block in page.body:
        if block.block_type != 'paragraph':
            continue
        match = H2_RE.search(str(block.value))
        if match:
            label = TAG_RE.sub('', match.group(1)).strip()
            if label:
                sections.append({'id': block.id, 'label': label})
    return sections
