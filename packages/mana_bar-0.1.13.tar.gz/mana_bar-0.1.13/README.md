# Mana-bar (法力槽)

Mana-bar 是一个基于命令行的任务流管理工具，旨在帮助你管理不同项目的“精力”或“疲劳值”。通过设定每个项目的疲劳上限和消耗速率，你可以更好地规划和追踪你的工作状态，避免过度劳累。

## 简介

在日常工作中，我们往往会在多个项目之间切换。Mana-bar 引入了“法力值”（Mana）或“疲劳值”的概念：
- 每个项目都有一个**疲劳上限**（Total Fatigue）。
- 当你开始在一个项目上工作时，疲劳值会随着时间积累。
- 不同的项目可以设置不同的**消耗速率**（Rate）。
- 当疲劳值达到上限时，意味着你需要休息或切换到其他项目。
- 疲劳值会随着时间的推移（休息）通过某种机制恢复（当前代码逻辑主要关注记录和显示）。

## 安装

确保你已经安装了 Python 3.10+。

```bash
git clone <repository_url>
cd Mana-bar
pip install .
```

或者使用 `pip` 安装依赖：
```bash
pip install -e .
```

## 使用说明

安装完成后，你可以使用 `mana` 命令来管理你的任务。

### 1. 添加项目 (Add)

开始管理一个新项目之前，你需要先添加它，并设置其疲劳上限和消耗速率。

```bash
mana add <project_name> --total <total_fatigue> --rate <fatigue_rate>
```

- `<project_name>`: 项目名称。
- `--total`, `-t`: 疲劳值上限，默认 156。
- `--rate`, `-r`: 疲劳消耗速率，默认 1.0。

示例：
```bash
mana add coding -t 200 -r 1.5
```

### 2. 开始任务 (Open)

开始在一个项目上工作。

```bash
mana open <project_name> [--task <task_desc>] [--extra <extra_id>]
```

- `<project_name>`: 项目名称。
- `--task`, `-t`: (可选) 任务描述。
- `--extra`, `-e`: (可选) 额外ID。

示例：
```bash
mana open coding -t "Implement README"
```

### 3. 结束任务 (Close)

停止当前项目的计时。

```bash
mana close <project_name>
```

示例：
```bash
mana close coding
```

### 4. 查看项目状态 (Check)

查看指定项目的当前疲劳值状态。

```bash
mana check <project_name>
```

输出将显示一个进度条，指示当前的精力和疲劳状态。

### 5. 查看所有项目 (Checkall)

查看所有项目的状态。

```bash
mana checkall
```

## 开发

本项目使用 [Typer](https://typer.tiangolo.com/) 构建 CLI，使用 [Rich](https://github.com/Textualize/rich) 进行终端美化。

### 依赖安装
```bash
pip install -r requirements.txt
# 或者
pip install .[dev]
```

### 运行测试
```bash
pytest
```

## License

[MIT License](LICENSE)
