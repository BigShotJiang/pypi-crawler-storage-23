from pathlib import Path
import os
import json

CONFIG_DIR = str(Path.home() / ".config" / "mana" / "data")
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")


def get_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)
