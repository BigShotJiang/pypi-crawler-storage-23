from package.entity.project import Project
from package.data.project import add_project as add_project_data
from package.data.init import ensure_db_ready


@ensure_db_ready
def add_project(project_name, total, rate):
    print("hello", total, rate)
    project = Project(
        None, project_name=project_name, fatigue_rate=rate, fatigue_total=total
    )

    add_project_data(project)
