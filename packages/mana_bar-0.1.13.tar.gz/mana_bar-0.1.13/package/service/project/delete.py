from package.data.project import delete_project as delete_project_data
from package.data.init import ensure_db_ready


@ensure_db_ready
def delete_project(project_name):
    delete_project_data(project_name)
