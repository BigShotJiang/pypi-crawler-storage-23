from package.data.project import get_project_name
from package.data.record import (
    get_today_accumulated_fatigue,
)
from rich.console import Console
from rich.table import Table
from rich.progress_bar import ProgressBar
from rich.text import Text
import typer


def show(project_name):
    console = Console()
    project = get_project_name(project_name=project_name)

    if not project:
        typer.secho("找不到此项目", fg=typer.colors.RED, err=True)
        return

    cost = int(get_today_accumulated_fatigue(project.id))

    if cost > project.fatigue_total:
        cost = project.fatigue_total

    rest = project.fatigue_total - cost

    if rest < 0:
        rest = 0

    bar = ProgressBar(
        total=project.fatigue_total,
        completed=rest,
        width=40,
        complete_style="yellow",
        finished_style="green",
    )

    status = (
        Text(f"已暂停", style="red")
        if project.project_status == 0
        else Text(f"进行中", style="green")
    )

    grid = Table.grid(padding=1)
    grid.add_row(
        Text(
            f"{project.project_name}: {rest}/{project.fatigue_total}:",
            style="bold blue",
        ),
        status,
        bar,
        Text(f"{rest/project.fatigue_total:.1%}", style="magenta"),
    )
    console.print(grid)


def list_all():
    results = get_today_accumulated_fatigue()
    console = Console()
    if not results:
        typer.secho("没有记录，请确认", fg=typer.colors.RED, err=True)
    grid = Table.grid(padding=1)
    grid.add_column(justify="right")
    grid.add_column(justify="left")
    grid.add_column(justify="right")
    for r in results:
        rest = int(r["total"] - r["used"])
        if rest < 0:
            rest = 0

        bar = ProgressBar(
            total=r["total"],
            completed=rest,
            width=40,
            complete_style="yellow",
            finished_style="green",
        )
        status = (
            Text(f"已暂停", style="red")
            if r["status"] == 0
            else Text(f"进行中", style="green")
        )
        # 2. 把你要展示的东西，作为“一行”加进去
        grid.add_row(
            Text(
                f"{r['name']}: {rest}/{r['total']}:",
                style="bold blue",
            ),
            status,
            bar,
            Text(f"{rest/r['total']:.1%}", style="magenta"),
        )
    console.print(grid)


# def show(project_name):
#     console = Console()
#     project = get_project_name(project_name=project_name)

#     if not project:
#         print("找不到此项目")
#         return

#     record = get_recent_pending_record_by_project(
#         Record(id=None, project_id=project.id)
#     )
#     achive_duration_mins = int(get_today_accumulated_fatigue() / 60)
#     print("已经消耗的分钟数", achive_duration_mins)
#     costed_rate_fatigue = int(achive_duration_mins * project.fatigue_rate)
#     total = project.fatigue_total
#     if not record:
#         cost = costed_rate_fatigue
#     else:
#         if record.stop != -1:
#             stop_time = record.stop
#         else:
#             stop_time = int(datetime.now().timestamp())
#         start_time = record.start
#         duration_time = stop_time - start_time
#         duration_mins = int(duration_time / 60)
#         cost = int(duration_mins * project.fatigue_rate) + costed_rate_fatigue
#         if cost > total:
#             cost = total

#     completed = total - cost

#     bar = ProgressBar(
#         total=total,
#         completed=completed,
#         width=40,
#         complete_style="yellow",
#         finished_style="green",
#     )

#     grid = Table.grid(padding=1)

#     # 2. 把你要展示的东西，作为“一行”加进去
#     grid.add_row(
#         Text(f"{project.project_name}: {completed}/{total}", style="bold blue"),
#         bar,
#         Text(f"{completed/total:.1%}", style="magenta"),
#     )
#     console.print(grid)
