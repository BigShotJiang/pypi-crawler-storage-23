from package.data.project import get_all_projects
import typer


def complete_project_name(ctx: typer.Context, param, incomplete: str):
    text = incomplete
    projects = get_all_projects()
    choices = [
        p.project_name
        for p in projects
        if isinstance(p.project_name, str) and p.project_name.startswith(text)
    ]

    return choices
