import typer
from package.service.record.start import start
from package.service.record.stop import stop
from package.service.record.show import show, list_all
from package.service.record.complete import complete_project_name
from package.service.project.add import add_project
from package.service.project.delete import delete_project

from typing_extensions import Annotated

app = typer.Typer(help="mana")


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        list_all()


# def start(task_desc, project_name, extra_id):
@app.command()
def open(
    project: Annotated[
        str, typer.Argument(help="project", shell_complete=complete_project_name)
    ],
    task_desc: Annotated[str, typer.Option("--task", "-t", help="task")] = "",
    extra_id: Annotated[str, typer.Option("--extra", "-e", help="extra_id")] = "",
):
    start(project_name=project, task_desc=task_desc, extra_id=extra_id)


@app.command()
def close(
    project: Annotated[
        str, typer.Argument(help="project", shell_complete=complete_project_name)
    ],
):
    stop(project_name=project)


@app.command()
def check(
    project: Annotated[
        str, typer.Argument(help="project", shell_complete=complete_project_name)
    ],
):
    show(project)


@app.command()
def checkall():
    list_all()


@app.command()
def add(
    project: Annotated[str, typer.Argument(help="project")],
    total: Annotated[int, typer.Option("--total", "-t", help="task")] = 156,
    rate: Annotated[float, typer.Option("--extra", "-r", help="extra_id")] = 1.0,
):
    add_project(project_name=project, total=total, rate=rate)


@app.command()
def delete(
    project: Annotated[str, typer.Argument(help="project")],
):
    delete_project(project_name=project)
