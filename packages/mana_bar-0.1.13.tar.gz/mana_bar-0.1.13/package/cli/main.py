from package.cli.app import app
import typer


def main():
    try:
        app()
    except Exception as e:
        typer.secho(f"出现异常: {e}", fg=typer.colors.RED, err=True)


if __name__ == "__main__":
    main()
