Base module to have global discounts applied to either sales or
purchases. It doesn't do much for itself, so account_global_discount or
purchase_global_discount should be installed to benefit from it.
