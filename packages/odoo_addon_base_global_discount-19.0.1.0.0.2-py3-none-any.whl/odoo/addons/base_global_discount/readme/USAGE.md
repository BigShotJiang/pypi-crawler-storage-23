You can assign global discounts to partners as well. You'll need the
proper permission (*Manage Global Discounts*):

1.  Go to a partner that is a company.
2.  Go to the *Sales & Purchases* tab.
3.  In section sale, you can set sale discounts.
4.  In section purchase, you can set purchase discounts.
