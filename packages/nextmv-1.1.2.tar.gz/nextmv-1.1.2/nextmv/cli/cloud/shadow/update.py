"""
This module defines the cloud shadow update command for the Nextmv CLI.
"""

import json
from typing import Annotated

import typer

from nextmv.cli.configuration.config import build_cloud_app
from nextmv.cli.message import in_progress, print_json, success
from nextmv.cli.options import AppIDOption, ProfileOption, ShadowTestIDOption

# Set up subcommand application.
app = typer.Typer()


@app.command()
def update(
    app_id: AppIDOption,
    shadow_test_id: ShadowTestIDOption,
    description: Annotated[
        str | None,
        typer.Option(
            "--description",
            "-d",
            help="Updated description of the shadow test.",
            metavar="DESCRIPTION",
        ),
    ] = None,
    name: Annotated[
        str | None,
        typer.Option(
            "--name",
            "-n",
            help="Updated name of the shadow test.",
            metavar="NAME",
        ),
    ] = None,
    output: Annotated[
        str | None,
        typer.Option(
            "--output",
            "-o",
            help="Saves the updated shadow test information to this location.",
            metavar="OUTPUT_PATH",
        ),
    ] = None,
    profile: ProfileOption = None,
) -> None:
    """
    Update a Nextmv Cloud shadow test.

    Update the name and/or description of a shadow test. Any fields not
    specified will remain unchanged.

    [bold][underline]Examples[/underline][/bold]

    - Update the name of a shadow test.
        $ [dim]nextmv cloud shadow update --app-id hare-app --shadow-test-id carrot-feast \\
            --name "Spring Carrot Harvest"[/dim]

    - Update the description of a shadow test.
        $ [dim]nextmv cloud shadow update --app-id hare-app --shadow-test-id bunny-hop-routes \\
            --description "Optimizing hop paths through the meadow"[/dim]

    - Update both name and description and save the result.
        $ [dim]nextmv cloud shadow update --app-id hare-app --shadow-test-id lettuce-delivery \\
            --name "Warren Lettuce Express" --description "Fast lettuce delivery to all burrows" \\
            --output updated-shadow-test.json[/dim]
    """

    cloud_app = build_cloud_app(app_id=app_id, profile=profile)

    in_progress(msg="Updating shadow test...")
    shadow_test = cloud_app.update_shadow_test(
        shadow_test_id=shadow_test_id,
        name=name,
        description=description,
    )

    shadow_test_dict = shadow_test.to_dict()
    success(
        f"Shadow test [magenta]{shadow_test_id}[/magenta] updated successfully "
        f"in application [magenta]{app_id}[/magenta]."
    )

    if output is not None and output != "":
        with open(output, "w") as f:
            json.dump(shadow_test_dict, f, indent=2)

        success(msg=f"Updated shadow test information saved to [magenta]{output}[/magenta].")

        return

    print_json(shadow_test_dict)
