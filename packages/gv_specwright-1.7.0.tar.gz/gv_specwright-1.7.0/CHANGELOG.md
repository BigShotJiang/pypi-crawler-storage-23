# CHANGELOG

<!-- version list -->

## v1.7.0 (2026-03-04)

### Bug Fixes

- Apply AC updates even when section status is unchanged
  ([#282](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/282),
  [`1219f41`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))

### Chores

- Update uv.lock to match 1.6.0
  ([#282](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/282),
  [`1219f41`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))

### Code Style

- Ruff format ([#282](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/282),
  [`1219f41`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))

### Documentation

- Fix ticket links and set ticket_project on all specs
  ([`b923d39`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b923d3952a9a80af41ee5a77a9800e59a038851a))

- Update spec statuses based on codebase audit
  ([`e85eff1`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/e85eff152ce50c3e571f98dbff1633c8f6cead20))

### Features

- Audit checks off realized ACs and inserts evidence
  ([#282](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/282),
  [`1219f41`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))

- Audit checks off realized ACs and inserts evidence comments
  ([#282](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/282),
  [`1219f41`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/1219f41b49b642dafd2710ce0cb07a07cb47f664))


## v1.6.0 (2026-03-04)

### Bug Fixes

- Address PR review feedback ([#271](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/271),
  [`b344ee7`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))

### Chores

- Regenerate uv.lock for v1.5.0
  ([#271](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/271),
  [`b344ee7`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))

### Code Style

- Ruff format ([#271](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/271),
  [`b344ee7`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))

### Documentation

- Update specs based on #269 ([#270](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/270),
  [`6e9e414`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/6e9e414c8641eb3a6fead2e540f1cc9da405b943))

### Features

- Add production hardening for web app
  ([#271](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/271),
  [`b344ee7`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))

- Production hardening for web app
  ([#271](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/271),
  [`b344ee7`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b344ee717588f0820a872ef5efbd0cbdb98b8dc9))


## v1.5.0 (2026-03-04)

### Bug Fixes

- Address PR review feedback on audit command
  ([#269](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/269),
  [`bc17748`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))

- Address second round of PR review feedback
  ([#269](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/269),
  [`bc17748`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))

### Chores

- Update uv.lock to match current version
  ([#269](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/269),
  [`bc17748`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))

### Documentation

- Add ticket links from specwright sync
  ([`925d4f9`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/925d4f9cb848c35c1dd9894f683b88fbf44c7731))

- Mark Background sections as done, fix parent section statuses
  ([`b284ff5`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b284ff5c889687115cf6846d2b95dc9ac7e71ad3))

- Update spec statuses based on codebase implementation audit
  ([`ff42ab2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ff42ab28687ce2c9866754bac9d773defa8395fb))

### Features

- Add /sw-audit skill for full spec audit workflow
  ([`60c4e72`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/60c4e726c38bb3a9a4b532694016e4fdfc4ec178))

- Add `specwright audit` CLI command for Claude-powered spec status auditing
  ([#269](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/269),
  [`bc17748`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))

- Add specwright audit CLI command
  ([#269](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/269),
  [`bc17748`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/bc17748fafa115b6381229e2e1bd14ad6cca1b08))


## v1.4.5 (2026-03-04)

### Bug Fixes

- **auth**: Decouple auth0_orgs_enabled from auth0_audience
  ([`5a7887b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/5a7887bdb4d668ca408a57cfe85bee4d23db0c61))

- **lint**: Remove unused SyncResult import in test_engine
  ([`7c70fbb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/7c70fbb7d19a2f3ba922743a59ba9951dafeb10b))

- **sync**: Only create tickets for todo/in_progress sections
  ([`449a202`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/449a2020caeee102c32d0e08cf330444b2548dc1))

### Chores

- Remove temporary debug-org endpoint
  ([`a6e1bd6`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a6e1bd65e0437df201c400e8a36c9d6d474e3a27))

### Code Style

- Fix ruff formatting in test_engine.py
  ([`47059c9`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/47059c97de8e8fcac84890becc03089fabc1410e))

### Documentation

- Fix configuration reference to match actual parser
  ([`7ebe983`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/7ebe983bf6ee915c46e4c920852cbb1ce76d6442))

- Update docs for server-proxied sync, device auth, and AUTH0_AUDIENCE
  ([`23e0957`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/23e0957b9686325e15e27cfdbb2251b64a765fce))


## v1.4.4 (2026-03-04)

### Bug Fixes

- **auth**: Resolve org for device auth JWTs without org_id claim
  ([`2b8b8e4`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/2b8b8e4af8e9337d055d660b6535e8249c7d47fe))


## v1.4.3 (2026-03-04)

### Bug Fixes

- **deploy**: Include AUTH0_AUDIENCE in K8s secret
  ([`22cd8c0`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/22cd8c0e6d0d44d850a4ed03332950e8d06942c1))


## v1.4.2 (2026-03-04)

### Bug Fixes

- **auth**: Fail fast on missing AUTH0_AUDIENCE and use correct status codes
  ([`0400cc6`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/0400cc65cc73515d2f68381e7c3d733508832f92))


## v1.4.1 (2026-03-04)

### Bug Fixes

- **ci**: Fail if uv.lock is out of sync with pyproject.toml
  ([`b798442`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b798442c30253cf517659b6e92aeab7b213e7200))

### Chores

- Sync uv.lock with pyproject.toml v1.3.0
  ([`c4fde9c`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/c4fde9cf35ea79dd7f8dfbe007ce6634d90f1aa3))


## v1.4.0 (2026-03-04)

### Bug Fixes

- Address PR security feedback
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

- Address round 2 PR review feedback
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

- **ci**: Prevent duplicate claude review comments
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

### Code Style

- Format test_ticket_routes.py
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))

### Documentation

- Update specs based on #118 ([#120](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/120),
  [`2abefec`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/2abefec28cd029636da9f4e22078d5e16d79e492))

### Features

- Server-proxied ticket sync via GitHub App tokens
  ([#201](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/201),
  [`ce7dfe2`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/ce7dfe23d24c8f123f6831b0f0ebd623c0a4fe6a))


## v1.3.0 (2026-03-01)

### Bug Fixes

- Ruff format on integration conftest
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Address PR review — permissions, marker conflict, coverage paths
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Address round 2 review feedback
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Format integration tests and fix set -e in combine step
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

### Documentation

- Update specs based on #117 ([#119](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/119),
  [`b7a6def`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b7a6defc6c30dbe7095fc27d0902a9ba6aa2410c))

### Features

- **ci**: Add coverage reporting for unit and integration tests
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))

- **ci**: Coverage reporting for unit & integration tests
  ([#118](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/118),
  [`781438b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/781438b3f14049496fa19423d2265e8e73c01916))


## v1.2.0 (2026-03-01)

### Bug Fixes

- Default platform_url to empty, use module-level Settings, drop redundant path
  ([#117](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/117),
  [`a65b2cb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))

- URL-encode spec paths and add links to reanalyze handler
  ([#117](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/117),
  [`a65b2cb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))

### Chores

- Lock updates
  ([`566ee0a`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/566ee0aa09fbbf9d62a67fa0a204541000003be9))

### Code Style

- Fix ruff formatting ([#117](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/117),
  [`a65b2cb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))

### Documentation

- Update specs based on #112 ([#114](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/114),
  [`a47ece3`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a47ece3fc43189a0b043018237d53bd8dd2b9f52))

### Features

- Add Specwright web app links to PR comments
  ([#117](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/117),
  [`a65b2cb`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/a65b2cbfec1032e666ade0f1f8e244df84b7ebe1))


## v1.1.0 (2026-02-28)

### Documentation

- Update install commands to use gv-specwright package name
  ([`8536e8b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/8536e8bdd3261f6cf2a68ed4be41d2ce92008064))

### Features

- **docs-site**: Logo links to main site + gradient wordmark
  ([`7e55c6b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/7e55c6ba18aee0b5569382afcc14793850cf4b13))


## v1.0.3 (2026-02-28)

### Bug Fixes

- Add AUTH0_DEVICE_CLIENT_ID to deploy K8s secret
  ([#116](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/116),
  [`fc8b3a8`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fc8b3a8c21b14a4e9e0cfa21d1942c826976a7c7))


## v1.0.2 (2026-02-28)

### Bug Fixes

- Rename PyPI package to gv-specwright (specwright was taken)
  ([`44e3af3`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/44e3af3397bb8c4deba4da6f4a11edf89edf3433))


## v1.0.1 (2026-02-28)

### Bug Fixes

- Use version tag for pypi-publish action (Docker-based, SHA pinning unsupported)
  ([`b48f730`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b48f730f7f8d066135010f9ff72b8cb1e55e3df9))


## v1.0.0 (2026-02-28)

- Initial Release
