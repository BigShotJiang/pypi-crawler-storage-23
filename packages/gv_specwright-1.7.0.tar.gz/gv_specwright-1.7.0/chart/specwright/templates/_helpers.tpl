{{/*
Expand the name of the chart.
*/}}
{{- define "specwright.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "specwright.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "specwright.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "specwright.labels" -}}
helm.sh/chart: {{ include "specwright.chart" . }}
{{ include "specwright.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "specwright.selectorLabels" -}}
app.kubernetes.io/name: {{ include "specwright.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name
*/}}
{{- define "specwright.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "specwright.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Container image
*/}}
{{- define "specwright.image" -}}
{{- $tag := default .Chart.AppVersion .Values.image.tag -}}
{{- if .Values.image.registry -}}
{{ .Values.image.registry }}/{{ .Values.image.repository }}:{{ $tag }}
{{- else -}}
{{ .Values.image.repository }}:{{ $tag }}
{{- end -}}
{{- end }}

{{/*
Secret name for GitHub App credentials
*/}}
{{- define "specwright.githubSecretName" -}}
{{- if .Values.secrets.githubApp.existingSecret -}}
{{ .Values.secrets.githubApp.existingSecret }}
{{- else -}}
{{ include "specwright.fullname" . }}-github
{{- end -}}
{{- end }}

{{/*
Secret name for Anthropic credentials
*/}}
{{- define "specwright.anthropicSecretName" -}}
{{- if .Values.secrets.anthropic.existingSecret -}}
{{ .Values.secrets.anthropic.existingSecret }}
{{- else -}}
{{ include "specwright.fullname" . }}-anthropic
{{- end -}}
{{- end }}

{{/*
Secret name for Neon DB credentials
*/}}
{{- define "specwright.neonSecretName" -}}
{{- if .Values.secrets.neon.existingSecret -}}
{{ .Values.secrets.neon.existingSecret }}
{{- else -}}
{{ include "specwright.fullname" . }}-neon
{{- end -}}
{{- end }}

{{/*
Secret name for GCP credentials
*/}}
{{- define "specwright.gcpSecretName" -}}
{{- if .Values.secrets.gcp.existingSecret -}}
{{ .Values.secrets.gcp.existingSecret }}
{{- else -}}
{{ include "specwright.fullname" . }}-gcp
{{- end -}}
{{- end }}

{{/*
Secret name for Auth0 credentials
*/}}
{{- define "specwright.auth0SecretName" -}}
{{- if .Values.secrets.auth0.existingSecret -}}
{{ .Values.secrets.auth0.existingSecret }}
{{- else -}}
{{ include "specwright.fullname" . }}-auth0
{{- end -}}
{{- end }}

{{/*
Secret name for MCP API key
*/}}
{{- define "specwright.mcpSecretName" -}}
{{- if .Values.secrets.mcp.existingSecret -}}
{{ .Values.secrets.mcp.existingSecret }}
{{- else -}}
{{ include "specwright.fullname" . }}-mcp
{{- end -}}
{{- end }}

{{/*
Secret name for Jira credentials
*/}}
{{- define "specwright.jiraSecretName" -}}
{{- if .Values.secrets.jira.existingSecret -}}
{{ .Values.secrets.jira.existingSecret }}
{{- else -}}
{{ include "specwright.fullname" . }}-jira
{{- end -}}
{{- end }}

{{/*
Secret name for PostHog credentials
*/}}
{{- define "specwright.posthogSecretName" -}}
{{- if .Values.secrets.posthog.existingSecret -}}
{{ .Values.secrets.posthog.existingSecret }}
{{- else -}}
{{ include "specwright.fullname" . }}-posthog
{{- end -}}
{{- end }}
