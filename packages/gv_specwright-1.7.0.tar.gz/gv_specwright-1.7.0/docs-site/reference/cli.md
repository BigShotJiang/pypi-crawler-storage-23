# CLI Reference

The Specwright CLI provides local spec management commands. Install via `uv` or `pip`.

## Installation

```bash
# With uv (recommended)
uv tool install gv-specwright

# With pip
pip install gv-specwright
```

## Commands

### `specwright login`

Authenticate with the Specwright platform using device authorization flow.

```bash
specwright login
```

Opens a browser for Auth0 device authorization. Tokens are stored at `~/.config/specwright/credentials.json`.

### `specwright init`

Initialize a repository for Specwright.

```bash
specwright init
```

Creates:
- `SPECWRIGHT.yaml` with sensible defaults
- `docs/specs/` directory
- `docs/specs/_template.md` spec template

### `specwright lint`

Validate spec files for format compliance.

```bash
specwright lint [PATH...]
```

| Option | Description |
|--------|-------------|
| `PATH` | Spec files or directories to lint (default: `docs/specs/`) |
| `--strict` | Treat warnings as errors |

Checks: valid frontmatter, status values, section numbering, AC format, status comment syntax.

### `specwright coverage`

Show spec coverage metrics.

```bash
specwright coverage [PATH...]
```

| Option | Description |
|--------|-------------|
| `PATH` | Spec files to analyze (default: `docs/specs/`) |
| `--min N` | Exit with error if coverage below N% |
| `--json` | Output as JSON |

### `specwright validate-config`

Validate `SPECWRIGHT.yaml` syntax and values.

```bash
specwright validate-config [FILE]
```

| Option | Description |
|--------|-------------|
| `FILE` | Config file path (default: `SPECWRIGHT.yaml`) |

### `specwright sync`

Synchronize spec sections with your ticket system (GitHub Issues, Jira, Linear).

```bash
specwright sync [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--reverse` | Pull ticket statuses into spec markdown (reverse sync) |
| `--spec FILE` | Filter to a single spec file |
| `--dry-run` | Preview changes without writing to spec files |
| `--local` | Bypass server proxy and use local `GITHUB_TOKEN` / `gh` CLI directly |

**Default behavior:** If you're logged in (`specwright login`), sync uses the Specwright server as a proxy — the server makes GitHub API calls using its GitHub App installation token. No local `GITHUB_TOKEN` needed.

If you're not logged in or the server proxy is unavailable, sync falls back to local credentials (`GITHUB_TOKEN` env var or `gh` CLI).

Use `--local` to force local credentials even when logged in.

### `specwright audit`

Audit spec section statuses against the codebase using Claude-powered semantic analysis.

```bash
specwright audit [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--dry-run` | Preview recommended changes without writing to spec files |
| `--sync` | Run ticket sync after applying status updates |
| `--spec FILE` | Filter to a single spec file |

**How it works:** For each spec, the command gathers grep evidence from `src/` and `frontend/src/`, then sends section ACs + code snippets to Claude for semantic evaluation. Claude recommends a status for each section (done, in_progress, todo, blocked, deprecated) with confidence levels.

Only medium and high confidence changes are applied. The command updates `<!-- specwright:system:N status:STATE -->` comments in-place.

**Heuristic fallback:** When `ANTHROPIC_API_KEY` is not set, audit falls back to grep-only heuristics. This mode can suggest `todo → in_progress` (when code matches are found) but cannot confirm `done` (requires semantic understanding).

**Example output:**
```
Auth Hardening (docs/specs/auth-hardening.md)
--------------------------------------------------
  5 5-rbac-wiring: todo → done (high)
    All ACs implemented in auth/deps.py and permissions.py
  6 6-session-mgmt: todo → in_progress (medium)
    JWT generation found but refresh endpoint missing

Audit complete: 2 status change(s).
Tokens: 12,450 in / 1,230 out (~$0.06)
```

**Estimated cost:** ~$0.15–0.50 for 10 specs using Claude Sonnet.

### `specwright mcp`

Start the MCP server for coding agent integration.

```bash
specwright mcp
```

Starts a stdio-based MCP server. See [MCP Tools](./mcp) for available tools.

## Environment Variables

| Variable | Description |
|----------|-------------|
| `SPECWRIGHT_CONFIG` | Override config file path (default: `SPECWRIGHT.yaml`) |
| `ANTHROPIC_API_KEY` | API key for agent features |
| `LOG_LEVEL` | Logging level (`debug`, `info`, `warning`, `error`) |

::: warning Provisional
This CLI reference is hand-written and may not reflect the latest commands. It will be auto-generated from source in a future update.
:::
