# gaspatchio

CLI scaffold powered by `uv` + `typer`.

## Quickstart

```bash
uv sync
uv run gspio --help
```

## Install from PyPI

Once published, install in any project with:

```bash
uv add gaspatchio
```

## Installed CLI command

After install (`uv sync`), this command is available:

```bash
gspio --help
```

## Publish to PyPI with uv

### One-time setup (PyPI)

1. Create the `gaspatchio` project on PyPI.
2. In PyPI project settings, configure a Trusted Publisher for this repository and workflow:
   - Workflow file: `.github/workflows/publish-pypi.yml`
   - Environment: leave empty (unless you use one)

### Publish locally

```bash
uv build
uv publish --token "$PYPI_API_TOKEN"
```

### Publish via GitHub Actions (trusted publishing)

- Run the `Publish package to PyPI` workflow manually, or
- Create a GitHub release to trigger it automatically.