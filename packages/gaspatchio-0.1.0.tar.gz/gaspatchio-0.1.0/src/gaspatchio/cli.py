import typer

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
UNDERLINE = "\033[4m"
BLUE = "\033[38;5;39m"
SKY = "\033[38;5;45m"
ORANGE = "\033[38;5;208m"
GOLD = "\033[38;5;220m"


def _coming_soon_epilog() -> str:
    shimmer = f"{GOLD}{BOLD}*{RESET}{GOLD}{DIM}.{RESET}{GOLD}{BOLD}*{RESET}"
    return (
        "\b\n"
        f"{BLUE}   ______                 _{RESET}\n"
        f"{SKY}  / ____/___  ____  _____(_)___  ____ _{RESET}\n"
        f"{SKY} / /   / __ \\/ __ \\/ ___/ / __ \\/ __ `/{RESET}\n"
        f"{BLUE}/ /___/ /_/ / / / / /  / / / / / /_/ /{RESET}\n"
        f"{BLUE}\\____/\\____/_/ /_/_/  /_/_/ /_/\\__, /{RESET}\n"
        f"{BLUE}                               /____/{RESET}\n"
        f"   {shimmer}  {ORANGE}{BOLD}Coming Soon{RESET}  {shimmer}\n"
        f"   {GOLD}{DIM}Still simmering... this CLI will be soup-er soon.{RESET}\n"
        f"        {SKY}{UNDERLINE}https://gaspatchio.dev/{RESET}\n"
    )


COMING_SOON_EPILOG = _coming_soon_epilog()

app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    rich_markup_mode=None,
    help="Gaspatchio CLI",
    epilog=COMING_SOON_EPILOG,
    context_settings={"help_option_names": ["-h", "--help"], "max_content_width": 100, "color": True},
)


@app.callback()
def entrypoint() -> None:
    """CLI root command."""


def main() -> None:
    app()


if __name__ == "__main__":
    main()
