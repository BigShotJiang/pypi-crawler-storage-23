# LDKpark  
A small and fun package.

## Installation  

```bash
pip install LDKpark
```

## Usage  

```python
from LDKpark import add
print(add(1,2)) #3

from LDKpark.games100 import minesweeper
minesweeper.run() #开始游戏：扫雷
minesweeper.close() #结束游戏
```

