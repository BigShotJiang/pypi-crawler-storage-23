"""Allow running as: python -m toonic"""
from toonic.cli import cli_main

if __name__ == '__main__':
    cli_main()
