import json
from unittest.mock import patch

from cog_mcp.resources import FILTER_DOCS, QUERY_DOCS

EXPECTED_TOOL_NAMES = {
    "list_views",
    "get_view_schema",
    "get_filter_docs",
    "get_query_docs",
    "list_instances",
    "search_instances",
    "aggregate_instances",
    "query_instances",
    "ask_documents_question",
    "summarize_document",
    "retrieve_instances",
}


def test_register_tools_exposes_expected_tool_names(tools) -> None:
    assert EXPECTED_TOOL_NAMES.issubset(tools)


def test_discovery_tools_delegate_and_expose_docs(
    tools, cognite_client_mock, sample_config
) -> None:
    with (
        patch("cog_mcp.tools.discovery.fetch_views", return_value='{"items": []}') as fetch_views,
        patch(
            "cog_mcp.tools.discovery.fetch_view_schema", return_value='{"schema": true}'
        ) as fetch_view_schema,
    ):
        views_payload = tools["list_views"]()
        schema_payload = tools["get_view_schema"]("my-space", "MyView", "v1")

    assert json.loads(views_payload) == {"items": []}
    assert json.loads(schema_payload) == {"schema": True}
    fetch_views.assert_called_once_with(cognite_client_mock, sample_config)
    fetch_view_schema.assert_called_once_with(cognite_client_mock, "my-space", "MyView", "v1")
    assert tools["get_filter_docs"]() == FILTER_DOCS
    assert tools["get_query_docs"]() == QUERY_DOCS
