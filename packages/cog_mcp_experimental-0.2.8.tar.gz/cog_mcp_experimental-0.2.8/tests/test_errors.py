import json

from cog_mcp.errors import error_response


def test_error_response_returns_consistent_json_payload() -> None:
    payload = json.loads(error_response("something went wrong"))
    assert payload == {"error": "something went wrong"}
