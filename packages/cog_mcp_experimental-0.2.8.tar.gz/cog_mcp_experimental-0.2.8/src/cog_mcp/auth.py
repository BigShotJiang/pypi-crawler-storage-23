from cognite.client import ClientConfig, CogniteClient
from cognite.client.credentials import OAuthClientCredentials

from cog_mcp.config import Config


def create_cognite_client(config: Config) -> CogniteClient:
    """Create a CogniteClient authenticated with OAuth client credentials."""
    if config.token_url:
        creds = OAuthClientCredentials(
            token_url=config.token_url,
            client_id=config.client_id,
            client_secret=config.client_secret,
            scopes=[f"https://{config.cluster}.cognitedata.com/.default"],
        )
    else:
        creds = OAuthClientCredentials.default_for_azure_ad(
            tenant_id=config.tenant_id,
            client_id=config.client_id,
            client_secret=config.client_secret,
            cdf_cluster=config.cluster,
        )

    return CogniteClient(
        ClientConfig(
            client_name="cog-mcp-experimental",
            project=config.project,
            credentials=creds,
            base_url=f"https://{config.cluster}.cognitedata.com",
        )
    )
