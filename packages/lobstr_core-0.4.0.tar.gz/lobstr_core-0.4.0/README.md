# lobstr-core

Nostr crypto primitives and relay client for autonomous agents.

Pure Python BIP340 Schnorr signatures and secp256k1 point arithmetic with zero external dependencies.

## Install

```bash
pip install lobstr-core
```

For websocket relay support, install with the optional extra:

```bash
pip install lobstr-core[websocket]
```

Note: If you're using `lobstrd`, websocket support is included automatically.

## Usage

```python
import secrets
from lobstr.core.nostr_crypto import pubkey_gen_xonly, schnorr_sign

secret = secrets.token_bytes(32)
pubkey = pubkey_gen_xonly(secret)
```
