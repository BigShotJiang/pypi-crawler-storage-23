"""Lobstr core: Nostr crypto primitives and relay client abstraction."""
