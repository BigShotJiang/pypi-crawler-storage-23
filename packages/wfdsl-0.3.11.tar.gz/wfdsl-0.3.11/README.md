# wfdsl Package

Workflow Domain Specific Language (wfdsl) is a Python package providing a DSL for specifying scientific workflow models, used by [VizSciFlow](https://github.com/TechOptionsBD/vizsciflow).

## Development Setup

```bash
git clone https://github.com/srlabUsask/wfdsl.git
cd wfdsl
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Building and Publishing to PyPI

### Prerequisites

```bash
pip install build twine
```

### 1. Update the version

Bump the version number in `setup.py`:

```python
version="0.3.11",  # increment as needed
```

### 2. Clean previous builds

```bash
rm -rf dist/ build/ *.egg-info
```

### 3. Build the package

```bash
python -m build
```

This produces both a source distribution (`.tar.gz`) and a wheel (`.whl`) in the `dist/` directory.

### 4. Verify the package contents

Before uploading, confirm the `dsl/` module is at the top level (not inside `src/`):

```bash
tar -tzf dist/wfdsl-*.tar.gz | grep "dsl/"
```

You should see paths like `wfdsl-x.x.x/dsl/datatype.py`, **not** `wfdsl-x.x.x/src/dsl/datatype.py`.

### 5. Test upload to TestPyPI (optional)

```bash
twine upload --repository testpypi dist/*
pip install --index-url https://test.pypi.org/simple/ wfdsl
```

### 6. Upload to PyPI

```bash
twine upload dist/*
```

You will be prompted for your PyPI API token. To avoid this prompt, create a `~/.pypirc` file:

```ini
[pypi]
  username = __token__
  password = pypi-your-api-token-here
``` 

