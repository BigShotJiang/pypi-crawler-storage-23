class QuixException(Exception):
    pass
