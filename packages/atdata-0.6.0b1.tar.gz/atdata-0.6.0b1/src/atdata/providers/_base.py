"""Abstract base class for index storage providers.

The ``IndexProvider`` ABC defines the persistence contract that the ``Index``
class delegates to.  Each provider handles storage and retrieval of two entity
types — dataset entries and schema records — using whatever backend it wraps.

Concrete implementations live in sibling modules:
    ``_redis.py``, ``_sqlite.py``, ``_postgres.py``
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Iterable, Iterator

from .._type_utils import parse_semver

if TYPE_CHECKING:
    from ..local import LocalDatasetEntry


def _find_latest_semver(versions: Iterable[str]) -> str | None:
    """Return the highest semantic version string from *versions*, or None."""
    latest: tuple[int, int, int] | None = None
    latest_str: str | None = None
    for version_str in versions:
        try:
            v = parse_semver(version_str)
            if latest is None or v > latest:
                latest = v
                latest_str = version_str
        except ValueError:
            continue
    return latest_str


class IndexProvider(ABC):
    """Storage backend for the ``Index`` class.

    Implementations persist ``LocalDatasetEntry`` objects and schema JSON
    records.  The ``Index`` class owns all business logic (CID generation,
    version bumping, schema building); the provider is a pure persistence
    layer.

    Examples:
        >>> from atdata.providers import create_provider
        >>> provider = create_provider("sqlite", path="/tmp/index.db")
        >>> provider.store_schema("MySample", "1.0.0", '{"name": "MySample"}')
        >>> provider.get_schema_json("MySample", "1.0.0")
        '{"name": "MySample"}'
    """

    # ------------------------------------------------------------------
    # Dataset entry operations
    # ------------------------------------------------------------------

    @abstractmethod
    def store_entry(self, entry: LocalDatasetEntry) -> None:
        """Persist a dataset entry (upsert by CID).

        Args:
            entry: The dataset entry to store.  The entry's ``cid`` property
                is used as the primary key.
        """

    @abstractmethod
    def get_entry_by_cid(self, cid: str) -> LocalDatasetEntry:
        """Load a dataset entry by its content identifier.

        Args:
            cid: Content-addressable identifier.

        Returns:
            The matching ``LocalDatasetEntry``.

        Raises:
            KeyError: If no entry exists for *cid*.
        """

    @abstractmethod
    def get_entry_by_name(self, name: str) -> LocalDatasetEntry:
        """Load a dataset entry by its human-readable name.

        Args:
            name: Dataset name.

        Returns:
            The first matching ``LocalDatasetEntry``.

        Raises:
            KeyError: If no entry exists with *name*.
        """

    @abstractmethod
    def iter_entries(self) -> Iterator[LocalDatasetEntry]:
        """Iterate over all stored dataset entries.

        Yields:
            ``LocalDatasetEntry`` objects in unspecified order.
        """

    # ------------------------------------------------------------------
    # Schema operations
    # ------------------------------------------------------------------

    @abstractmethod
    def store_schema(self, name: str, version: str, schema_json: str) -> None:
        """Persist a schema record (upsert by name + version).

        Args:
            name: Schema name (e.g. ``"MySample"``).
            version: Semantic version string (e.g. ``"1.0.0"``).
            schema_json: JSON-serialized schema record.
        """

    @abstractmethod
    def get_schema_json(self, name: str, version: str) -> str | None:
        """Load a schema's JSON by name and version.

        Args:
            name: Schema name.
            version: Semantic version string.

        Returns:
            The JSON string, or ``None`` if not found.
        """

    @abstractmethod
    def iter_schemas(self) -> Iterator[tuple[str, str, str]]:
        """Iterate over all stored schemas.

        Yields:
            Tuples of ``(name, version, schema_json)``.
        """

    def find_latest_version(self, name: str) -> str | None:
        """Find the latest semantic version for a schema name.

        The default implementation iterates all schemas and compares
        in Python.  Subclasses with indexed storage may override.

        Args:
            name: Schema name to search for.

        Returns:
            The latest version string (e.g. ``"1.2.3"``), or ``None``
            if no schema with *name* exists.
        """
        return _find_latest_semver(
            version for sname, version, _ in self.iter_schemas() if sname == name
        )

    # ------------------------------------------------------------------
    # Label operations
    # ------------------------------------------------------------------

    @abstractmethod
    def store_label(
        self,
        name: str,
        cid: str,
        version: str | None = None,
        description: str | None = None,
    ) -> None:
        """Persist a label mapping a name (+ optional version) to a dataset CID.

        Args:
            name: Human-readable label name (e.g. ``"mnist"``).
            cid: Content identifier of the target dataset entry.
            version: Optional version string (e.g. ``"1.0.0"``).
            description: Optional description of this labeled version.
        """

    @abstractmethod
    def get_label(
        self, name: str, version: str | None = None
    ) -> tuple[str, str | None]:
        """Resolve a label to a dataset CID.

        Args:
            name: Label name.
            version: Specific version to resolve. If ``None``, returns the
                most recently created label with *name*.

        Returns:
            Tuple of ``(cid, version)``.

        Raises:
            KeyError: If no label exists with *name* (and *version*).
        """

    @abstractmethod
    def iter_labels(self) -> Iterator[tuple[str, str, str | None]]:
        """Iterate over all stored labels.

        Yields:
            Tuples of ``(name, cid, version)``.
        """

    # ------------------------------------------------------------------
    # Lens operations
    # ------------------------------------------------------------------

    @abstractmethod
    def store_lens(self, name: str, version: str, lens_json: str) -> None:
        """Persist a lens record (upsert by name + version).

        Args:
            name: Lens name (e.g. ``"image_to_grayscale"``).
            version: Semantic version string (e.g. ``"1.0.0"``).
            lens_json: JSON-serialized lens record.
        """

    @abstractmethod
    def get_lens_json(self, name: str, version: str) -> str | None:
        """Load a lens's JSON by name and version.

        Args:
            name: Lens name.
            version: Semantic version string.

        Returns:
            The JSON string, or ``None`` if not found.
        """

    @abstractmethod
    def iter_lenses(self) -> Iterator[tuple[str, str, str]]:
        """Iterate over all stored lenses.

        Yields:
            Tuples of ``(name, version, lens_json)``.
        """

    def find_latest_lens_version(self, name: str) -> str | None:
        """Find the latest semantic version for a lens name.

        The default implementation iterates all lenses and compares
        in Python.  Subclasses with indexed storage may override.

        Args:
            name: Lens name to search for.

        Returns:
            The latest version string (e.g. ``"1.2.3"``), or ``None``
            if no lens with *name* exists.
        """
        return _find_latest_semver(
            version for lname, version, _ in self.iter_lenses() if lname == name
        )

    def find_lenses_by_schemas(
        self,
        source_schema: str,
        view_schema: str | None = None,
    ) -> list[tuple[str, str, str]]:
        """Find lenses matching source and/or view schema names.

        The default implementation iterates all lenses and filters in
        Python.  Subclasses may override with indexed queries.

        Args:
            source_schema: Source schema name to match.
            view_schema: Optional view schema name to match. If ``None``,
                returns all lenses with the given source schema.

        Returns:
            List of ``(name, version, lens_json)`` tuples for matching lenses.
        """
        results: list[tuple[str, str, str]] = []
        for name, version, lens_json in self.iter_lenses():
            try:
                record = json.loads(lens_json)
            except json.JSONDecodeError:
                continue
            if record.get("source_schema") != source_schema:
                continue
            if view_schema is not None and record.get("view_schema") != view_schema:
                continue
            results.append((name, version, lens_json))
        return results

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Release any resources held by the provider.

        The default implementation is a no-op.  Providers that hold
        connections (SQLite, PostgreSQL) should override this.
        """
