from labelle.lib.render_engines.render_engine import RenderEngineException


class NoContentError(RenderEngineException):
    pass
