__version__ = "0.2.0"
__homepage__ = "https://github.com/yushengyangchem/qcinput"
