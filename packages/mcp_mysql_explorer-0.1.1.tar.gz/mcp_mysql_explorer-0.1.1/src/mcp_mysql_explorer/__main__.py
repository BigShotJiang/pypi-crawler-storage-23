from mcp_mysql_explorer.server import main

main()
