"""MCP MySQL Explorer — Let AI agents query MySQL databases via Model Context Protocol."""

__version__ = "0.1.1"
