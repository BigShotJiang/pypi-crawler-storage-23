import requests

def ask(prompt):
    url = "http://fi8.bot-hosting.net:20163/elos-gpt3"

    try:
        r = requests.get(url, params={"text": prompt}, timeout=10)

        r.raise_for_status()

        data = r.json()
        return data.get("response", "لا يوجد رد")

    except requests.exceptions.RequestException as e:
        return f"خطأ في الاتصال: {e}"