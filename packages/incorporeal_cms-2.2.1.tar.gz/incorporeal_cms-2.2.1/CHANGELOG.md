# CHANGELOG

Included is a summary of changes to the project, by version. Details can be found in the commit history.

## v2.2.1

### Improvements

* The `og:image` tag is now properly inferred from page content when there's an image.
* The description used for `og:description` is also used for the description meta tag.

### Miscellaneous

* Some packaging cleanups in pyproject.toml.

## v2.2.0

### Features

* Support for the following Open Graph tags:
    * `og:description` is now derived from the paragraph more often, in a more idiomatic way.
    * `og:image` code is improved, though it still doesn't get inferred from content yet.
    * `og:logo` is supported, via a config parameter
    * `og:type` is provided, hardcoded to "website" in the base.html template

## v2.1.2

### Features

* An optional license declaration can be added to the footer, with a config "LICENSE" directive.

### Improvements

* Style changes in footnotes, hrs, table colors, footnote links, full width figures.
* Have floats clear their side, to not have a waterfall/ratchet effect when too many floating things are next to each
  other.
* Add borders to the plain style tables.

### Miscellaneous

* One HTML tweak to make the W3C CSS validator happy.
* Some old code from the pre-SSG days has been removed.

## v2.1.1

### Improvements

* Use the h1-as-name feature from v2.1.0 also to generate the page name in breadcrumbs. This changes the behavior on
  pages with an h1 but no Title: meta tag to have a better name, of course, but also changes the behavior on pages with
  neither a h1 nor a Title: meta tag to have a leading slash (e.g. /page-filename) where there previously was not one
  (e.g. just page-filename). This seems like an acceptable trade-off.

### Miscellaneous

* With the minor breadcrumb change, a method used to finagle the breadcrumb no-name name is no longer necessary.

## v2.1.0

### Features

* The page title (also used in the `og:title` header) and the optional description used in the `og:description` header
  can be derived from the contents of the page content, if the markdown meta tags are not supplied. The first `h1` is
  used for the title, and the first `p` is used for the description. This is largely to save some time writing pages
  that one wants to look nice, especially in a social media card, and removes some repetition.

### Miscellaneous

* Requirements bumped, which led to...
* Python 3.9 has been removed from the supported versions.
* Added some miscellaneous unit tests and coverage changes to keep us at 95% (which only dropped for a library reason I
  don't understand).

## v2.0.5

### Features

* The Markdown parser replaces links to e.g. `[Page](page.md)` with a href of `page`, rather than the Markdown source
  specifying a link of `page` explicitly. This allows for some improved site navigation when browsing the Markdown
  files, e.g. when going to files in Vim, or browsing a site in a Git web UI.

### Miscellaneous

* `tox.ini` also runs tests in a Python 3.13 environment now.
* Some trivial bumps to CI requirements.

## v2.0.4

### Bugfixes

* With some significant refactoring, files are now handled better with respect to relative paths, which fixes an issue
  with symlink pages only properly getting resolved to their target if the symlink was in the `pages/` root rather than
  a subdir.

## v2.0.3

### Bugfixes

* Symlinks for a `.md` file that are to be served by the web server also need a `.html` symlink pointed to the generated
  file, since the web server is looking for HTML files when serving paths.

### Miscellaneous

* The project now comes with the GPLv3 "or any later version" clause.

## v2.0.2

### Bugfixes

* Paths for files in the `pages/` root no longer have an extra `./` in them, which made URLs look ugly and also added an
  extra blank breadcrumb in the breadcrumbs.

### Improvements

* `custom-static` in the instance dir is now ignored and has no special handling --- put static files in `pages/static/`
  like all the other files that get copied. This also fixes a bug where the build errored if the directory didn't exist.
* Some README typos fixed.

## v2.0.1

### Improvements

* The `Image` tag in Markdown files no longer requires the full URL to be specified. Now `Config.BASE_HOST` is
  prepended to the tag value, which should be the full path to the image.
* `.files` are skipped when copying files to the SSG output directory.

## v2.0.0

### Features

* The project has been rewritten as a static site generator. This is of course a larger change than one line, so see the
  commit involved for the nitty gritty.
* Notably, this means I am now --- yes :( --- shipping some JavaScript, to handle the style switching, which is all
  client-side now.
* CHANGELOG.md added.
