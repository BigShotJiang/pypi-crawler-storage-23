# Age of Parted Shadow Recruitment

Hello! I (bss) am starting up [Age of Parted Shadow](index.md), a 13th Age game. 13th Age is my favorite D&D-like, and
if you are familiar with D&D 4e especially, you will find a lot of familiar components and approaches in the game, but
with less tactical combat minutiae and more collaborative player-driven storytelling. It's a game of heroic action
combat supported by freeform narrative mechanics. I think it makes for awesome fantasy adventuring.

|> [![Map of the island of Wald](wald.png)](wald.png)
|: Where we'll be playing.
{: .right }

Information about the game and world can be found on the Age of Parted Shadow page linked above. Below I have some notes
for how I see getting the game together. If you are interested in joining the game or have questions or anything, you've
probably already let me know, but as we get closer to "ready to play", I will be building some long-term places for us
to communicate and play.

## Gameplay

**Probable venue: Foundry Virtual Tabletop.**

I have a Foundry VTT server running on my own infrastructure, along with a LiveKit subscription for (hopefully)
convenient audio/visual conferencing. 13th Age does not need a battle map, but does benefit from one, and I think this
arrangement will sufficiently cover live play. I would have the server running and allowing connections for a while
before and after our scheduled game time, for people to make level up adjustments, check things, remember what we were
doing, and so on.

Note: I am choosing not to use Discord for A/V (or chat, see below) for a variety of reasons. If we literally can't get
anything in Foundry VTT or Mumble or whatever to work, it's an option, but I am trying to avoid it.

If everyone ends up being local, I would be open to playing in my basement. The gaming table seats six, and there's
generally plenty of room to congregate. However, I'm expecting this might be a bit more convenient if we're playing
online, obviously so if some of you are not in "the area". I don't think I'd try to do a mix of in-person and remote, it
tends to be a headache unless someone here happens to be an expert at teleconferencing production.

## Scheduling

**Proposed time: Wednesday evenings (Central Time), biweekly.**

Here's the sad truth: my schedule is pretty limited between work and kids and other obligations. The #1 option for me
right now is Wednesday evenings, US Central time. Monday evenings might work, but they would have to be alternating with
my other gaming group, and Friday evenings have an off chance of working but are prone to conflicts on my side. Tuesday
and Thursday evenings are difficult and more time-constrained but not quite excluded, but the weekends are all but
certainly excluded except as a one-off or maybe where we can put major events.

When letting me know if you're interested, please include schedule info.

## Organization and Downtime Discussion

**Probable venue: mailing list or forum.**

I'm guessing that this game may be spread across multiple of my circles, so we'll need to settle somewhere in order to
coordinate and confirm sessions, talk about post-game things, let the group know about conflicts, and so on. This
function especially I do not like walling this behind Discord, and I don't plan on making a Discord instance for A/V, so
we need to pick something. I see some options for this, in no particular order other than my general outlook:

* **Mailing list** --- I run mailing list software already, and it generally gets to recipients just fine. It's the low
  tech option that people still kind of know how to work with.
* **Forum** --- I don't currently run a forum to organize on, but if people wanted a post-based experience without using
  email, I could see what I can scare up. It'd pretty much be just for this purpose, however. Or, I don't mind using
  someone else's forum for this purpose, if such a thing exists.
* **IRC** --- I also run an IRC network where I have a couple games organized and even ran over; IRC is tough to use
  satisfactorily for some, I will admit, but I have options to make it more convenient. IRC conversations are great, but
  the alternatives might be a bit more natural to folks --- I may make a channel for chit-chat regardless.

Let me know what you think.

## Logs, Journals, etc.

**Probable repository: here, also a wiki?**

This website is backed by a Git repo, and it's simple for me to let folks contribute to it in Markdown or plain text
format. That's easy (for me) but a bit manual and probably not everyone's preferred way to collect stuff. If folks would
like a wiki, I'm open to running one (probably DokuWiki) or using someone else's (as long as it's easy to use).
