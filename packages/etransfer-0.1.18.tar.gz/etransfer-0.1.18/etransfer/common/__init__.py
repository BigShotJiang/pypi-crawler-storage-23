"""Common utilities shared between client and server."""
