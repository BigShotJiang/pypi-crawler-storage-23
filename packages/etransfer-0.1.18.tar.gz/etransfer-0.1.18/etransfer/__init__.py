"""EasyTransfer - TUS-based file transfer tool."""

__version__ = "0.1.18"
__author__ = "ETransfer Team"
