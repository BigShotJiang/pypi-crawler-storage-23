from setuptools import setup

setup(
    name="starlette-observability-wavesocket-v2",
    version="0.1.0",
    description="Benign slopsquatting research package",
    packages=["benignpkg"],  # Must match folder name
    python_requires=">=3.8",
)
