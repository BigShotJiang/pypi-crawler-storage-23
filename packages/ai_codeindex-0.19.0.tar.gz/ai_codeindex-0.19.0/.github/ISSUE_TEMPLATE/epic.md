---
name: Epic
about: Major feature requiring multiple stories (2+ weeks)
title: 'Epic N: [Epic Name]'
labels: epic
assignees: ''
---

## Epic Overview

[Brief description of what this epic will deliver - 2-3 sentences]

## User Stories

- [ ] Story N.1: [description]
- [ ] Story N.2: [description]
- [ ] Story N.3: [description]

## Planning Document

See: `docs/planning/epicN-name.md`

## Success Criteria

- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

## Target Version

vX.Y.0

## Dependencies

- Depends on: [other epics/features, or "None"]
- Blocks: [future work, or "None"]

## Estimated Timeline

[X weeks]

---

**Note**: Create detailed Epic plan in `docs/planning/` before starting work.
