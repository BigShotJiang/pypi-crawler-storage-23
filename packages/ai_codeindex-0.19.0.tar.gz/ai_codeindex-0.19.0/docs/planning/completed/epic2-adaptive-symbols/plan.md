# Epic 2: 自适应符号提取 - 详细规划

**创建日期**: 2026-01-26
**负责人**: Development Team
**优先级**: P0 (关键)
**预计时间**: 9-13小时（1-1.5天）

## 📋 Epic概述

### 问题陈述

当前系统对所有文件固定显示15个符号，导致：
- **大文件信息丢失严重**：8,891行文件只显示15个符号（覆盖率0.17%）
- **评分系统价值有限**：精心设计的5维评分系统只能"从15个中选15个"
- **用户体验极差**：平均丢失68%的符号信息

### 目标

实现基于文件大小的自适应符号提取系统：
- 大文件显示更多符号（80-120个）
- 小文件保持合理数量（10-15个）
- 信息覆盖率提升至80%+
- 保持向后兼容性

### 成功标准

- ✅ 8,891行文件显示120个符号（当前15个）
- ✅ 覆盖率从26%提升到80%+
- ✅ 所有测试通过，覆盖率>90%
- ✅ 向后兼容性保持
- ✅ 性能开销<30%

## 🎯 Story分解

### Phase 1: 配置基础 (4-6小时)

#### Story 2.1.1: 自适应配置数据结构设计 ⭐

**描述**: 定义AdaptiveSymbolsConfig数据类和默认配置

**任务**:
- [ ] 创建`src/codeindex/adaptive_config.py`
- [ ] 定义`AdaptiveSymbolsConfig`数据类
  - `enabled: bool = False`
  - `thresholds: dict[str, int]`
  - `limits: dict[str, int]`
  - `min_symbols: int = 5`
  - `max_symbols: int = 200`
- [ ] 定义`DEFAULT_ADAPTIVE_CONFIG`常量
- [ ] 添加完整docstring说明
- [ ] 创建测试文件`tests/test_adaptive_config.py`

**验收标准**:
- ✅ 数据类定义完成，包含所有必要字段
- ✅ DEFAULT_CONFIG包含合理的默认值
- ✅ 完整的docstring文档
- ✅ 测试覆盖率>90%

**估时**: 2-3小时

#### Story 2.1.2: 配置加载和验证

**描述**: 在Config类中加载和验证adaptive_symbols配置

**依赖**: Story 2.1.1

**任务**:
- [ ] 修改`src/codeindex/config.py`
- [ ] 添加`adaptive_symbols`字段到Config类
- [ ] 实现配置加载逻辑（YAML → AdaptiveSymbolsConfig）
- [ ] 实现配置验证：
  - 检查thresholds递增
  - 检查limits合理（min <= limit <= max）
- [ ] 实现配置合并（用户配置 + 默认配置）
- [ ] 向后兼容：enabled=false时使用max_per_file
- [ ] 添加测试用例

**验收标准**:
- ✅ Config能正确加载adaptive_symbols配置
- ✅ 配置验证捕获错误配置
- ✅ 向后兼容测试通过
- ✅ 配置合并逻辑正确
- ✅ 测试覆盖率>90%

**估时**: 2-3小时

### Phase 2: 核心算法 (3-4小时)

#### Story 2.2.1: 自适应选择器实现 ⭐⭐

**描述**: 实现AdaptiveSymbolSelector核心算法

**依赖**: Story 2.1.2

**任务**:
- [ ] 创建`src/codeindex/adaptive_selector.py`
- [ ] 实现`AdaptiveSymbolSelector`类
- [ ] 实现核心方法：
  ```python
  def calculate_limit(file_lines: int, total_symbols: int) -> int
  def _determine_size_category(lines: int) -> str
  def _apply_constraints(limit: int) -> int
  ```
- [ ] 创建测试文件`tests/test_adaptive_selector.py`
- [ ] 实现测试用例：
  - 基础功能测试（5个）
  - 文件大小分类测试（7个）
  - 约束应用测试（3个）
  - 边界情况测试（4个）
  - 真实PHP项目测试（2个）

**算法逻辑**:
```python
def calculate_limit(file_lines, total_symbols):
    # 1. 确定文件大小分类
    category = _determine_size_category(file_lines)

    # 2. 获取对应的符号限制
    limit = config.limits[category]

    # 3. 应用约束
    limit = min(limit, total_symbols)  # 不超过实际符号数
    limit = max(limit, config.min_symbols)  # 至少min个
    limit = min(limit, config.max_symbols)  # 至多max个

    return limit
```

**分类规则**:
```
<100行    → tiny   → 10符号
100-200   → small  → 15符号
200-500   → medium → 30符号
500-1000  → large  → 50符号
1000-2000 → xlarge → 80符号
2000-5000 → huge   → 120符号
>5000     → mega   → 150符号
```

**验收标准**:
- ✅ AdaptiveSymbolSelector类实现完成
- ✅ calculate_limit()返回正确结果
- ✅ 所有文件大小分段测试通过
- ✅ 边界情况处理正确
- ✅ PHP项目测试：8891行→120符号
- ✅ 测试覆盖率>95%

**估时**: 3-4小时

### Phase 3: 集成 (2-3小时)

#### Story 2.2.3: 集成到SmartWriter ⭐⭐⭐

**描述**: 将AdaptiveSymbolSelector集成到SmartWriter

**依赖**: Story 2.2.1

**任务**:
- [ ] 修改`src/codeindex/smart_writer.py`
- [ ] 添加AdaptiveSymbolSelector初始化
- [ ] 替换硬编码的`max_per_file`为动态计算
- [ ] 修改符号选择逻辑：
  ```python
  # 旧代码
  max_symbols = 15

  # 新代码
  file_lines = content.count('\n') + 1
  max_symbols = self.adaptive_selector.calculate_limit(
      file_lines, len(symbols)
  )
  ```
- [ ] 添加日志输出（调试用）
- [ ] 创建集成测试
- [ ] 运行回归测试
- [ ] PHP项目端到端验证

**验收标准**:
- ✅ SmartWriter成功集成AdaptiveSymbolSelector
- ✅ 移除所有硬编码的max_per_file引用
- ✅ 功能测试：小/中/大文件验证通过
- ✅ 回归测试：现有41个测试全部通过
- ✅ PHP项目验证：README_AI.md包含80+符号
- ✅ 测试覆盖率保持>90%

**估时**: 2-3小时

## 🔧 配置设计

### 配置Schema

```yaml
symbols:
  # 传统固定配置（向后兼容）
  max_per_file: 15

  # 新的自适应配置
  adaptive_symbols:
    enabled: true  # 是否启用自适应

    # 文件大小阈值（行数）
    thresholds:
      tiny: 100
      small: 200
      medium: 500
      large: 1000
      xlarge: 2000
      huge: 5000

    # 每个分段的符号数量限制
    limits:
      tiny: 10
      small: 15
      medium: 30
      large: 50
      xlarge: 80
      huge: 120
      mega: 150  # >5000行

    # 全局限制
    min_symbols: 5    # 最少显示符号数
    max_symbols: 200  # 最多显示符号数
```

### 配置示例

**示例1: 启用自适应（使用默认）**
```yaml
symbols:
  adaptive_symbols:
    enabled: true
```

**示例2: 大型项目配置**
```yaml
symbols:
  adaptive_symbols:
    enabled: true
    limits:
      large: 80
      xlarge: 150
      huge: 200
    max_symbols: 250
```

**示例3: 保守配置**
```yaml
symbols:
  adaptive_symbols:
    enabled: true
    limits:
      large: 30
      xlarge: 50
      huge: 80
    max_symbols: 100
```

## 🧪 测试策略

### 测试文件结构

```
tests/
├── test_adaptive_config.py      # Story 2.1.1测试
├── test_config_loading.py       # Story 2.1.2测试（扩展现有）
├── test_adaptive_selector.py    # Story 2.2.1测试
└── test_integration_adaptive.py # Story 2.2.3集成测试
```

### 测试覆盖率目标

| 组件 | 目标覆盖率 |
|------|-----------|
| adaptive_config.py | >90% |
| config.py (新增部分) | >90% |
| adaptive_selector.py | >95% |
| smart_writer.py (修改部分) | >90% |
| **整体** | **>90%** |

### 真实项目验证

**PHP项目**:
- 路径: `~/Projects/php_admin-main-c59644bb607125803a5d14400b64be9068b82488`
- 测试文件: OperateGoods.class.php (8,891行)
- 预期: 显示120个符号（当前15个）
- 覆盖率: 26% → 80%+

**Python项目** (codeindex自身):
- 测试不同大小的源文件
- 验证配置正确加载
- 确保自举可用

## 📊 预期效果

### 符号数量对比

| 文件大小 | 当前 | 改进后 | 提升 |
|---------|------|--------|------|
| 8,891行 | 15 | 120 | +700% |
| 7,924行 | 15 | 120 | +700% |
| 4,888行 | 15 | 80 | +433% |
| 3,521行 | 15 | 50 | +233% |
| 500行 | 15 | 30 | +100% |
| 150行 | 15 | 15 | 0% |

### 覆盖率对比

| 指标 | 当前 | 改进后 | 提升 |
|------|------|--------|------|
| 大文件覆盖率 | 26% | 80%+ | +208% |
| 用户满意度 | 20% | 75%+ | +275% |
| 信息完整度 | 基准 | 3-7x | 显著 |

### 性能影响

| 指标 | 当前 | 改进后 | 变化 |
|------|------|--------|------|
| 解析时间 | 基准 | 基准 | 0% |
| 写入时间 | 基准 | +20% | 可接受 |
| AI处理时间 | 基准 | +10-20% | 可接受 |
| 内存占用 | 基准 | +5% | 可忽略 |

## 🚨 风险和缓解

### 风险1: README_AI.md过长
- **可能性**: 中等
- **缓解**: max_symbols上限（200），用户可配置

### 风险2: AI prompt超限
- **可能性**: 低
- **缓解**: 监控长度，超限时自动降级

### 风险3: 配置错误
- **可能性**: 中等
- **缓解**: 配置验证，详细错误信息，默认值fallback

### 风险4: 破坏现有功能
- **可能性**: 低
- **缓解**: 完整回归测试，向后兼容设计

## 📅 实施计划

### Day 3上午 (4小时)
- ✅ Story 2.1.1: 配置数据结构
- ✅ Story 2.1.2: 配置加载

### Day 3下午 (4小时)
- ✅ Story 2.2.1: 核心算法实现

### Day 4上午 (3小时)
- ✅ Story 2.2.3: SmartWriter集成
- ✅ 集成测试和验证

### Day 4下午 (预留)
- Bug修复
- 文档完善
- 性能优化（如需要）

## ✅ Definition of Done

Epic 2完成的标准：

- [ ] 所有4个Story的验收标准达成
- [ ] 测试覆盖率>90%
- [ ] PHP项目验证：覆盖率26%→80%+
- [ ] 回归测试：现有41个测试全部通过
- [ ] 性能测试：处理时间增加<30%
- [ ] 向后兼容：enabled=false时行为不变
- [ ] 文档更新：
  - [ ] README.md添加自适应符号说明
  - [ ] examples/.codeindex.yaml更新
  - [ ] 配置最佳实践文档
- [ ] 代码审查通过
- [ ] 合并到develop分支

## 🔮 未来扩展

**当前Epic范围** (MVP):
- ✅ 基于文件大小的自适应
- ✅ 配置化阈值和限制
- ✅ 与SmartWriter集成

**未来可能的扩展**:
- 基于文件类型的自适应（Controller vs Model）
- 基于评分分布的动态调整
- 交互式配置生成工具
- 统计分析和配置推荐
- 渐进式显示（折叠/展开）

## 📝 参考文档

- [Phase 1 Agile Plan](./phase1-agile-plan.md)
- [PHP Project Validation Report](../evaluation/php-project-validation.md)
- [Symbol Scorer Documentation](../../src/codeindex/symbol_scorer.py)
- [SmartWriter Documentation](../../src/codeindex/smart_writer.py)

---

**最后更新**: 2026-01-26
**状态**: 规划完成，待开始实施
**下一步**: 开始Story 2.1.1实现
