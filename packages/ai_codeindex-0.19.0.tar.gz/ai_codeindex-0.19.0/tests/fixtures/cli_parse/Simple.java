package com.example.utils;

public class Calculator {
    /**
     * Add two numbers
     */
    public int add(int a, int b) {
        return a + b;
    }
}
