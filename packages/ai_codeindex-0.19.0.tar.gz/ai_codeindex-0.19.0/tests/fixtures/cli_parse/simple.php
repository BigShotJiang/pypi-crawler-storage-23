<?php
namespace App\Utils;

class Calculator {
    /**
     * Add two numbers
     */
    public function add($a, $b) {
        return $a + $b;
    }
}
