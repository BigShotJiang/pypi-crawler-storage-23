package com.example.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {
    /**
     * Get user by ID
     */
    public User getUser(Long id) {
        return null;
    }
}
