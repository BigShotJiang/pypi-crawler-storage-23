def func1(): pass
