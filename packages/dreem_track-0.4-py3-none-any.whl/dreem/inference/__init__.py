"""Tracking Inference using GTR Model."""

from .tracker import Tracker

__all__ = [
    "Tracker",
]
