"""
Exception classes for OpenEvalKit

All custom exceptions inherit from OpenEvalKitError
"""
class OpenEvalKitError(Exception):
    """Base Exception for all OpenEvalKit errors"""
    pass

class ScoringError(OpenEvalKitError):
    """Raised when scoring a run fails"""
    pass

class JudgingError(OpenEvalKitError):
    """Raised when judging a run fails"""
    pass

class DatasetError(OpenEvalKitError):
    """Raised when a dataset operation fails"""
    pass

class ConfigError(OpenEvalKitError):
    """Raised when configuration is invalid"""
    pass

class RateLimitError(OpenEvalKitError):
    """Raised when rate limit is exceeded"""
    pass