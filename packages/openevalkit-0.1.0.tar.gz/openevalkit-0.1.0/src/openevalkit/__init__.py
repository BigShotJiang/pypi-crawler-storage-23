"""
OpenEvalKit: Universal evaluation framework for LLM systems.

Examples:
    >>> from openevalkit import Dataset, evaluate
    >>> from openevalkit.scorers import ExactMatch
    >>> from openevalkit.judges import LLMJudge, LLMConfig, Rubric
    >>> 
    >>> # Evaluate with scorers
    >>> dataset = Dataset.from_jsonl("data.jsonl")
    >>> results = evaluate(dataset, scorers=[ExactMatch()])
    >>> print(results.aggregates)
    >>> 
    >>> # Evaluate with judges
    >>> rubric = Rubric(criteria=["helpfulness"], scale="0-1")
    >>> judge = LLMJudge(LLMConfig(model="gpt-4o"), rubric)
    >>> results = evaluate(dataset, judges=[judge])
"""

# Package version
from openevalkit.__version__ import __version__

# Core classes
from openevalkit.run import Run
from openevalkit.dataset import Dataset
from openevalkit.score import Score
from openevalkit.judgment import Judgment  
from openevalkit.config import EvalConfig

# Main function
from openevalkit import evaluate 

# Results
from openevalkit.result import EvaluationResult

# Cache (optional - for advanced users)
from openevalkit.cache import Cache 

# Make submodules available
from openevalkit import scorers
from openevalkit import judges 
from openevalkit import errors

__all__ = [
    # Version
    "__version__",
    # Core
    "Run",
    "Dataset",
    "Score",
    "Judgment",  
    "EvalConfig",
    # Functions
    "evaluate",
    # Results
    "EvaluationResult",
    # Cache
    "Cache", 
    # Submodules
    "scorers",
    "judges",  
    "errors",
]