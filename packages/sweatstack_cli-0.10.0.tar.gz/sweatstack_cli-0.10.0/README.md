# SweatStack CLI

Command-line interface for [SweatStack](https://sweatstack.no) — the sports data platform for developers.

## Installation

Requires Python 3.11+. We recommend [uv](https://docs.astral.sh/uv/) for installation.

```bash
# Run directly without installing
uvx sweatstack-cli

# Or install as a tool
uv tool install sweatstack-cli

# Or with pip
pip install sweatstack-cli
```

To upgrade:

```bash
uv tool upgrade sweatstack-cli
```

To reinstall (e.g. after a broken install or Python version change):

```bash
uvx --reinstall sweatstack-cli
# or if installed as a tool
uv tool install --reinstall sweatstack-cli
```

## Quick Start

```bash
# Authenticate with SweatStack
sweatstack login

# Create an app and deploy
sweatstack app create "My App" --page my-page --env
sweatstack page deploy
```

## Commands

### Authentication

| Command | Description |
|---------|-------------|
| `sweatstack login` | Authenticate via browser (OAuth2 PKCE) |
| `sweatstack login --force` | Force re-authentication |
| `sweatstack logout` | Remove stored credentials |
| `sweatstack status` | Show auth status, user info, and version |
| `sweatstack --version` | Show version and check for updates |

### Application Management

| Command | Description |
|---------|-------------|
| `sweatstack app create [NAME]` | Create a new private OAuth2 application |
| `sweatstack app link` | Link current directory to an existing application |

#### `app create` options

| Option | Description |
|--------|-------------|
| `--description, -d TEXT` | Application description (max 500 chars) |
| `--page, -p SLUG` | Associate with a SweatStack Page |
| `--secret, -s` | Generate a client secret |
| `--env` | Write credentials to `.env` |
| `--env-file PATH` | Write credentials to a specific file |
| `--json` | Output as JSON |

#### `app link` options

| Option | Description |
|--------|-------------|
| `--force, -f` | Overwrite existing `sweatstack.toml` |

### Project Configuration

Both `app create` and `app link` generate a `sweatstack.toml` in the current directory. Other commands read defaults from this file.

```toml
[app]
name = "My App"
client_id = "abc123"

[page]
slug = "my-page"
directory = "dist"
```

### Page Deployment

Deploy static sites to SweatStack Pages.

```bash
# Deploy using sweatstack.toml defaults (recommended)
sweatstack page deploy

# Or specify slug and directory explicitly
sweatstack page deploy my-page --dir ./dist
```

## License

MIT
