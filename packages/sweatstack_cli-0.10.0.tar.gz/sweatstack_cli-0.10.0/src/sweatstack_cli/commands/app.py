"""Application management commands."""

from __future__ import annotations

import json as json_lib
import sys
from pathlib import Path
from typing import Any, cast

import typer

from sweatstack_cli.api import APIClient
from sweatstack_cli.console import console, stderr_console
from sweatstack_cli.exceptions import APIError, AuthenticationError
from sweatstack_cli.project import CONFIG_FILENAME, write_config

app = typer.Typer(name="app", help="Manage OAuth2 applications.")


def _is_interactive() -> bool:
    """Check if stdin is a TTY (interactive terminal)."""
    return sys.stdin.isatty()


@app.command()
def create(
    name: str | None = typer.Argument(None, help="Application name."),
    description: str | None = typer.Option(
        None,
        "--description",
        "-d",
        help="Application description (max 500 chars).",
    ),
    page: str | None = typer.Option(
        None,
        "--page",
        "-p",
        help="Associate with a SweatStack Page (includes redirect URI).",
    ),
    secret: bool = typer.Option(
        False,
        "--secret",
        "-s",
        help="Generate a client secret.",
    ),
    env: bool = typer.Option(
        False,
        "--env",
        help="Write credentials to .env file.",
    ),
    env_file: Path | None = typer.Option(
        None,
        "--env-file",
        help="Write credentials to specified file.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON.",
    ),
) -> None:
    """Create a new private OAuth2 application."""
    if env and env_file:
        console.print("[red]Error:[/red] --env and --env-file are mutually exclusive.")
        raise typer.Exit(1)

    interactive = _is_interactive()

    # Resolve name
    if name is None:
        if not interactive:
            console.print("[red]Error:[/red] App name is required.")
            raise typer.Exit(1)
        name = typer.prompt("App name")

    # Prompt for optional fields in interactive mode
    if interactive:
        if description is None:
            description = typer.prompt(
                "Description (optional)", default="", show_default=False
            )
            if not description:
                description = None
        if page is None:
            page = typer.prompt(
                "Page slug (optional)", default="", show_default=False
            )
            if not page:
                page = None
        if not secret:
            secret = typer.confirm("Generate client secret?", default=False)

    body: dict[str, str | bool] = {"name": name}

    if description:
        body["description"] = description

    if page:
        body["page"] = page

    if secret:
        body["generate_secret"] = True

    try:
        client = APIClient()
    except AuthenticationError as e:
        console.print(f"[red]Error:[/red] {e}")
        console.print("[dim]Run 'sweatstack login' to authenticate.[/dim]")
        raise typer.Exit(2)

    try:
        result = client.post("/api/v1/applications", json=body)
    except APIError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(3)

    env_path = Path(".env") if env else env_file
    if env_path:
        _write_env_file(env_path, result)

    # Write sweatstack.toml (protect existing file)
    config_path = Path(CONFIG_FILENAME)
    if config_path.exists():
        if not interactive:
            console.print(
                f"[red]Error:[/red] {CONFIG_FILENAME} already exists. "
                "Remove it first or run interactively."
            )
            raise typer.Exit(1)
        console.print(f"[yellow]Warning:[/yellow] {CONFIG_FILENAME} already exists.")
        typer.confirm("Overwrite?", abort=True)

    config_path = write_config(
        app_name=result["name"],
        client_id=result["id"],
        page_slug=page,
    )

    if json_output:
        console.print(json_lib.dumps(result, indent=2))
    else:
        _print_app_created(result, env_path, config_path)


def _write_env_file(path: Path, result: dict[str, str]) -> None:
    """Append credentials to an env file."""
    lines_to_add: list[str] = []
    existing_content = ""

    if path.exists():
        existing_content = path.read_text()

    client_id = result.get("id")
    client_secret = result.get("client_secret")

    if client_id:
        if "SWEATSTACK_CLIENT_ID=" in existing_content:
            stderr_console.print(
                f"[yellow]Warning:[/yellow] SWEATSTACK_CLIENT_ID already exists in {path}, skipping."
            )
        else:
            lines_to_add.append(f"SWEATSTACK_CLIENT_ID={client_id}")

    if client_secret:
        if "SWEATSTACK_CLIENT_SECRET=" in existing_content:
            stderr_console.print(
                f"[yellow]Warning:[/yellow] SWEATSTACK_CLIENT_SECRET already exists in {path}, skipping."
            )
        else:
            lines_to_add.append(f"SWEATSTACK_CLIENT_SECRET={client_secret}")

    if lines_to_add:
        if existing_content and not existing_content.endswith("\n"):
            lines_to_add.insert(0, "")

        with path.open("a") as f:
            f.write("\n".join(lines_to_add) + "\n")


def _print_app_created(result: dict[str, str], env_path: Path | None, config_path: Path) -> None:
    """Pretty-print the created application details."""
    console.print(f"[green]✓[/green] Created application [bold]{result['name']}[/bold]")
    console.print()
    console.print(f"  Client ID:  [cyan]{result['id']}[/cyan]")

    if "client_secret" in result:
        console.print(f"  Secret:     [cyan]{result['client_secret']}[/cyan]")

    if result.get("redirect_uris"):
        console.print()
        console.print("  Redirect URIs:")
        for uri in result["redirect_uris"]:
            console.print(f"    - {uri}")

    console.print()
    console.print(f"[green]✓[/green] Config written to [bold]{config_path}[/bold]")

    if env_path:
        console.print(f"[green]✓[/green] Credentials written to [bold]{env_path}[/bold]")

    if "client_secret" in result and not env_path:
        console.print()
        console.print("[yellow]Save the secret now — it won't be shown again.[/yellow]")


@app.command()
def link(
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Overwrite existing sweatstack.toml.",
    ),
) -> None:
    """Link this directory to an existing application."""
    config_path = Path(CONFIG_FILENAME)

    # Check if config already exists
    if config_path.exists() and not force:
        console.print(f"[yellow]Already linked.[/yellow] {CONFIG_FILENAME} exists.")
        console.print("Use [cyan]--force[/cyan] to overwrite.")
        raise typer.Exit(1)

    # Fetch user's apps
    try:
        client = APIClient()
    except AuthenticationError as e:
        console.print(f"[red]Error:[/red] {e}")
        console.print("[dim]Run 'sweatstack login' to authenticate.[/dim]")
        raise typer.Exit(2)

    try:
        # API returns a list, but client.get is typed as returning dict
        apps = cast(list[dict[str, Any]], client.get("/api/v1/applications"))
    except APIError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(3)

    if not apps:
        console.print("[yellow]No applications found.[/yellow]")
        console.print("Create one with [cyan]sweatstack app create <name>[/cyan]")
        raise typer.Exit(1)

    # Show apps and let user select
    console.print("Link this directory to an existing application.\n")
    console.print("Your applications:")
    for i, app_info in enumerate(apps, 1):
        page_info = f" [dim](page: {app_info['page_slug']})[/dim]" if app_info.get("page_slug") else ""
        console.print(f"  [cyan][{i}][/cyan] {app_info['name']}{page_info}")

    console.print()
    if not sys.stdin.isatty():
        console.print("[red]Error:[/red] Cannot select application in non-interactive mode.")
        raise typer.Exit(1)
    selection = typer.prompt("Select application", type=int)

    if selection < 1 or selection > len(apps):
        console.print("[red]Invalid selection.[/red]")
        raise typer.Exit(1)

    selected = apps[selection - 1]

    # Write config
    write_config(
        app_name=selected["name"],
        client_id=selected["id"],
        page_slug=selected.get("page_slug"),
    )

    console.print()
    console.print(f"[green]✓[/green] Linked to [bold]{selected['name']}[/bold]")
