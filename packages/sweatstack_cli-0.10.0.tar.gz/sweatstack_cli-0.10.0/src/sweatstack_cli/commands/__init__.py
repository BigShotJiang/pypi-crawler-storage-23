"""CLI commands for SweatStack."""
