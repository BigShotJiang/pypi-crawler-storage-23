"""Page commands: deploy and serve static sites."""

from __future__ import annotations

import mimetypes
import socket
import subprocess
import sys
from pathlib import Path

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn

from sweatstack_cli.api import APIClient
from sweatstack_cli.config import get_settings
from sweatstack_cli.console import console
from sweatstack_cli.exceptions import APIError, AuthenticationError
from sweatstack_cli.project import CONFIG_FILENAME, ProjectConfig, update_config, write_config

# URL where users can create pages for their applications
SETTINGS_URL = "https://app.sweatstack.no/settings/api"

app = typer.Typer(
    name="page",
    help="Deploy static sites to SweatStack Pages.",
)


def _collect_files(directory: Path) -> list[tuple[str, tuple[str, bytes, str]]]:
    """
    Collect all files from a directory for multipart upload.

    Returns a list of tuples suitable for httpx files parameter:
    [("files", (filename, content, content_type)), ...]
    """
    files: list[tuple[str, tuple[str, bytes, str]]] = []

    for file_path in directory.rglob("*"):
        if not file_path.is_file():
            continue

        # Get relative path from directory root
        relative_path = file_path.relative_to(directory)

        # Guess content type
        content_type, _ = mimetypes.guess_type(str(file_path))
        if content_type is None:
            content_type = "application/octet-stream"

        # Read file content
        content = file_path.read_bytes()

        # Use relative path as filename to preserve directory structure
        files.append(("files", (str(relative_path), content, content_type)))

    return files


@app.command()
def deploy(
    slug: str | None = typer.Argument(
        None,
        help="Page slug. Reads from sweatstack.toml if not provided.",
    ),
    directory: Path | None = typer.Option(
        None,
        "--dir",
        help="Directory to deploy. Reads from sweatstack.toml if not provided.",
    ),
) -> None:
    """Deploy a static site to SweatStack Pages."""

    # Load config for defaults
    config = ProjectConfig.load()

    # Resolve slug
    page_slug = slug or (config.page.slug if config else None)
    if not page_slug:
        console.print("[red]Error:[/red] No page slug provided.")
        console.print(f"Specify a slug or add it to [bold]{CONFIG_FILENAME}[/bold]")
        raise typer.Exit(1)

    # Resolve directory
    directory_explicit = directory is not None
    if directory is None:
        dir_from_config = config.page.directory if config else None
        if dir_from_config:
            directory = Path(dir_from_config)
        else:
            if not sys.stdin.isatty():
                console.print("[red]Error:[/red] No deploy directory specified.")
                console.print("Use --dir or set it in sweatstack.toml.")
                raise typer.Exit(1)
            dir_input = typer.prompt("Deploy directory", default="public/")
            directory = Path(dir_input)
            directory_explicit = True

    if not directory.exists():
        console.print(f"[red]Error:[/red] Directory '{directory}' does not exist.")
        raise typer.Exit(1)

    if not directory.is_dir():
        console.print(f"[red]Error:[/red] '{directory}' is not a directory.")
        raise typer.Exit(1)

    directory = directory.resolve()

    # Compute relative directory for config and warnings
    try:
        rel_dir = str(directory.relative_to(Path.cwd()))
    except ValueError:
        rel_dir = str(directory)

    # Warn and confirm if deploying with different values than toml
    if config:
        mismatches: list[str] = []
        if config.page.slug and slug and slug != config.page.slug:
            mismatches.append(
                f"Deploying to '{slug}' but "
                f"{CONFIG_FILENAME} has slug '{config.page.slug}'"
            )
        if config.page.directory and rel_dir != config.page.directory.rstrip("/"):
            mismatches.append(
                f"Deploying '{rel_dir}' but "
                f"{CONFIG_FILENAME} has directory '{config.page.directory}'"
            )
        if mismatches:
            for msg in mismatches:
                console.print(f"[yellow]Warning:[/yellow] {msg}")
            if not sys.stdin.isatty():
                raise typer.Exit(1)
            typer.confirm("Continue?", abort=True)

    # Collect files
    files = _collect_files(directory)
    file_count = len(files)

    if file_count == 0:
        console.print(f"[red]Error:[/red] Directory '{directory}' contains no files.")
        raise typer.Exit(1)

    # Check for index.html
    has_index = any(name == "index.html" for _, (name, _, _) in files)
    if not has_index:
        console.print(
            f"[yellow]Warning:[/yellow] No index.html found in '{directory}'. "
            "Your site may not load correctly."
        )

    try:
        client = APIClient()
    except AuthenticationError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(2)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(
            f"Deploying [bold]{page_slug}[/bold] ({file_count} files)...",
            total=None,
        )

        try:
            result = client.put(f"/api/v1/pages/{page_slug}/deploy", files=files)
        except APIError as e:
            error_msg = str(e)

            # Handle 404 - page doesn't exist
            if "(404)" in error_msg:
                console.print(f"[red]Error:[/red] Page '{page_slug}' not found.")
                console.print()
                console.print(
                    f"Create this page first at: [link={SETTINGS_URL}]{SETTINGS_URL}[/link]"
                )
                console.print()
                console.print("[dim]Pages must be created in the SweatStack dashboard[/dim]")
                console.print("[dim]before you can deploy to them.[/dim]")
                raise typer.Exit(1)

            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(3)

    # Save to config after successful deploy
    if config:
        update_kwargs: dict[str, str] = {}
        if not config.page.slug:
            update_kwargs["page_slug"] = page_slug
        if not config.page.directory and directory_explicit:
            update_kwargs["page_directory"] = rel_dir
        if update_kwargs:
            update_config(**update_kwargs)
            console.print(f"[green]✓[/green] Saved to [bold]{CONFIG_FILENAME}[/bold]")
    elif directory_explicit:
        write_config(page_slug=page_slug, page_directory=rel_dir)
        console.print(f"[green]✓[/green] Created [bold]{CONFIG_FILENAME}[/bold]")

    console.print()
    console.print(f"[green]✓[/green] Deployed [bold]{page_slug}[/bold] successfully!")
    console.print(f"  Files: {file_count}")
    console.print(f"  URL:   {result.get('url', 'N/A')}")

    # Nudge to publish if app is private
    application = result.get("application", {})
    if application.get("is_private"):
        app_id = application.get("id")
        if app_id:
            base_url = get_settings().api_url
            console.print()
            console.print("Your app is private. Ready to go public?")
            publish_url = f"{base_url}/applications/{app_id}/publish"
            console.print(f"  {publish_url}")


def _find_available_port(start: int = 8000, max_attempts: int = 100) -> int:
    """Find the first available port starting from `start`."""
    for port in range(start, start + max_attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("localhost", port))
                return port
            except OSError:
                continue
    console.print(f"[red]Error:[/red] No available port found in range {start}-{start + max_attempts - 1}.")
    raise typer.Exit(1)


@app.command(
    context_settings={"allow_extra_args": True, "allow_interspersed_args": False},
)
def serve(
    ctx: typer.Context,
) -> None:
    """Serve the static site locally using Python's http.server.

    Extra arguments are passed through to python -m http.server.
    """
    config = ProjectConfig.load()
    if not config or not config.page.directory:
        console.print(
            f"[red]Error:[/red] No directory configured in {CONFIG_FILENAME}."
        )
        console.print(f"Add a [page] section with a directory to {CONFIG_FILENAME}.")
        raise typer.Exit(1)

    directory = Path(config.page.directory)
    if not directory.is_dir():
        console.print(f"[red]Error:[/red] '{directory}' is not a directory.")
        raise typer.Exit(1)

    extra_args = ctx.args

    # http.server takes port as a positional arg — check if user already passed one
    has_port_arg = any(not arg.startswith("-") for arg in extra_args)
    port_args: list[str] = []
    if not has_port_arg:
        port = _find_available_port()
        port_args = [str(port)]

    cmd = [
        sys.executable, "-m", "http.server",
        "--directory", str(directory),
        *port_args,
        *extra_args,
    ]

    if not has_port_arg:
        console.print(f"Serving [bold]{directory}[/bold] at [cyan]http://localhost:{port}[/cyan]")
    else:
        console.print(f"Serving [bold]{directory}[/bold]")

    try:
        raise SystemExit(subprocess.call(cmd))
    except KeyboardInterrupt:
        pass
