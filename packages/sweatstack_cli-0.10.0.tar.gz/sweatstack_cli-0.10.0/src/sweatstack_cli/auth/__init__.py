"""OAuth2 PKCE authentication for SweatStack CLI."""

from __future__ import annotations

import os
import webbrowser
from typing import TYPE_CHECKING
from urllib.parse import urlencode

import httpx

from sweatstack_cli.auth.callback_server import CallbackServer
from sweatstack_cli.auth.pkce import PKCEChallenge, generate_pkce
from sweatstack_cli.auth.tokens import FileTokenStorage, TokenPair
from sweatstack_cli.config import get_settings
from sweatstack_cli.exceptions import AuthenticationError

if TYPE_CHECKING:
    from sweatstack_cli.auth.tokens import TokenStorage

# Public OAuth2 client ID for CLI applications (designed for public clients)
CLIENT_ID = "5382f68b0d254378"

# Default OAuth2 scopes (offline_access required for refresh tokens)
SCOPES = "offline_access data:read data:write profile"


class Authenticator:
    """
    OAuth2 PKCE authentication flow orchestrator.

    Handles browser-based login, token storage, and automatic refresh.
    Thread-safe for token operations.

    Example:
        auth = Authenticator()
        tokens = auth.login()
        # Later...
        tokens = auth.get_valid_tokens()  # Auto-refreshes if expired
    """

    def __init__(
        self,
        storage: TokenStorage | None = None,
        client_id: str = CLIENT_ID,
        scopes: str = SCOPES,
    ) -> None:
        """
        Initialize authenticator.

        Args:
            storage: Token storage backend. Defaults to FileTokenStorage.
            client_id: OAuth2 client ID.
            scopes: Space-separated OAuth2 scopes.
        """
        self._storage = storage or FileTokenStorage()
        self._client_id = client_id
        self._scopes = scopes
        self._settings = get_settings()

    def login(self, force: bool = False) -> TokenPair:
        """
        Authenticate user via browser OAuth2 PKCE flow.

        Opens the user's default browser to the authorization page.
        Waits for the callback on a local HTTP server.

        Args:
            force: If True, re-authenticate even if valid tokens exist.

        Returns:
            TokenPair with access and refresh tokens.

        Raises:
            AuthenticationError: If authentication fails or times out.
        """
        if not force:
            tokens = self.get_valid_tokens()
            if tokens:
                return tokens

        server = CallbackServer(timeout=120.0)
        redirect_uri = server.get_redirect_uri()

        try:
            pkce = generate_pkce()
            auth_url = self._build_auth_url(redirect_uri, pkce)

            if not webbrowser.open(auth_url):
                raise AuthenticationError(f"Could not open browser. Please visit:\n{auth_url}")

            result = server.wait_for_callback(expected_state=pkce.state)

            tokens = self._exchange_code(
                code=result.code,
                redirect_uri=redirect_uri,
                code_verifier=pkce.verifier,
            )

            self._storage.save(tokens)
            return tokens

        finally:
            server.shutdown()

    def get_valid_tokens(self) -> TokenPair | None:
        """
        Get tokens, refreshing if expired.

        Checks token expiry with a 30-second margin to avoid
        edge cases where token expires during a request.

        Returns:
            Valid TokenPair, or None if not authenticated or refresh fails.
        """
        tokens = self._load_tokens()
        if tokens is None:
            return None

        if tokens.is_expired(margin_seconds=30):
            try:
                tokens = self._refresh_tokens(tokens.refresh_token)
                self._storage.save(tokens)
            except AuthenticationError:
                return None

        return tokens

    def logout(self) -> None:
        """Remove stored credentials."""
        self._storage.delete()

    def _load_tokens(self) -> TokenPair | None:
        """
        Load tokens from environment or persistent storage.

        Environment variables take precedence for CI/CD use cases.
        """
        access = os.environ.get("SWEATSTACK_API_KEY")
        refresh = os.environ.get("SWEATSTACK_REFRESH_TOKEN")

        if access and refresh:
            return TokenPair(access_token=access, refresh_token=refresh)

        return self._storage.load()

    def _build_auth_url(self, redirect_uri: str, pkce: PKCEChallenge) -> str:
        """Construct OAuth2 authorization URL with PKCE challenge."""
        params = {
            "client_id": self._client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": self._scopes,
            "code_challenge": pkce.challenge,
            "code_challenge_method": "S256",
            "state": pkce.state,
        }
        return f"{self._settings.api_url}/oauth/authorize?{urlencode(params)}"

    def _exchange_code(
        self,
        code: str,
        redirect_uri: str,
        code_verifier: str,
    ) -> TokenPair:
        """Exchange authorization code for tokens."""
        with httpx.Client(timeout=30.0) as client:
            response = client.post(
                f"{self._settings.api_url}/api/v1/oauth/token",
                data={
                    "grant_type": "authorization_code",
                    "client_id": self._client_id,
                    "code": code,
                    "code_verifier": code_verifier,
                    "redirect_uri": redirect_uri,
                },
            )

        if response.status_code != 200:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise AuthenticationError(f"Token exchange failed: {detail}")

        data = response.json()
        return TokenPair(
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
        )

    def _refresh_tokens(self, refresh_token: str) -> TokenPair:
        """Refresh expired access token using refresh token."""
        with httpx.Client(timeout=30.0) as client:
            response = client.post(
                f"{self._settings.api_url}/api/v1/oauth/token",
                data={
                    "grant_type": "refresh_token",
                    "client_id": self._client_id,
                    "refresh_token": refresh_token,
                },
            )

        if response.status_code != 200:
            raise AuthenticationError("Token refresh failed — please login again")

        data = response.json()
        return TokenPair(
            access_token=data["access_token"],
            # Some OAuth servers return a new refresh token, some don't
            refresh_token=data.get("refresh_token", refresh_token),
        )


# Re-export commonly used types
__all__ = ["AuthenticationError", "Authenticator", "FileTokenStorage", "TokenPair"]
