"""Shared console instance for consistent terminal output."""

import sys

from rich.console import Console

# Singleton console for consistent output across the CLI
console = Console()

# Separate console for stderr (warnings that shouldn't pollute stdout)
stderr_console = Console(file=sys.stderr)
