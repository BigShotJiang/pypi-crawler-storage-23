"""Project configuration via sweatstack.toml."""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path

CONFIG_FILENAME = "sweatstack.toml"


@dataclass
class PageConfig:
    """Page configuration."""

    slug: str | None = None
    directory: str | None = None


@dataclass
class AppConfig:
    """Application configuration."""

    name: str | None = None
    client_id: str | None = None


@dataclass
class ProjectConfig:
    """Project configuration from sweatstack.toml."""

    app: AppConfig
    page: PageConfig

    @classmethod
    def load(cls, path: Path | None = None) -> ProjectConfig | None:
        """
        Load config from sweatstack.toml in current directory.

        Args:
            path: Optional path to config file. Defaults to ./sweatstack.toml.

        Returns:
            ProjectConfig if file exists and is valid, None otherwise.
        """
        config_path = path or Path(CONFIG_FILENAME)

        if not config_path.exists():
            return None

        try:
            data = tomllib.loads(config_path.read_text(encoding="utf-8"))
        except tomllib.TOMLDecodeError:
            return None

        app_data = data.get("app", {})
        page_data = data.get("page", {})

        return cls(
            app=AppConfig(
                name=app_data.get("name"),
                client_id=app_data.get("client_id"),
            ),
            page=PageConfig(
                slug=page_data.get("slug"),
                directory=page_data.get("directory"),
            ),
        )


def write_config(
    path: Path | None = None,
    *,
    app_name: str | None = None,
    client_id: str | None = None,
    page_slug: str | None = None,
    page_directory: str | None = None,
) -> Path:
    """
    Write sweatstack.toml file.

    Args:
        path: Optional path to config file. Defaults to ./sweatstack.toml.
        app_name: Application name.
        client_id: OAuth2 client ID.
        page_slug: Page slug.
        page_directory: Page directory.

    Returns:
        Path to the written config file.
    """
    config_path = path or Path(CONFIG_FILENAME)

    lines = ["[app]"]
    if app_name:
        lines.append(f'name = "{app_name}"')
    if client_id:
        lines.append(f'client_id = "{client_id}"')

    if page_slug or page_directory:
        lines.append("")
        lines.append("[page]")
        if page_slug:
            lines.append(f'slug = "{page_slug}"')
        if page_directory:
            lines.append(f'directory = "{page_directory}"')

    lines.append("")  # Trailing newline
    config_path.write_text("\n".join(lines), encoding="utf-8")

    return config_path


def update_config(
    path: Path | None = None,
    *,
    page_slug: str | None = None,
    page_directory: str | None = None,
) -> Path | None:
    """Update specific fields in an existing sweatstack.toml without overwriting other values."""
    config_path = path or Path(CONFIG_FILENAME)

    if not config_path.exists():
        return None

    try:
        data = tomllib.loads(config_path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError:
        return None

    app_data = data.get("app", {})
    page_data = data.get("page", {})

    if page_slug is not None:
        page_data["slug"] = page_slug
    if page_directory is not None:
        page_data["directory"] = page_directory

    return write_config(
        path=config_path,
        app_name=app_data.get("name"),
        client_id=app_data.get("client_id"),
        page_slug=page_data.get("slug"),
        page_directory=page_data.get("directory"),
    )
