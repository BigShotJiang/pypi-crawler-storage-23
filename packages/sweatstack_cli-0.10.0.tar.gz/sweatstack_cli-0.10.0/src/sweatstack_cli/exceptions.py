"""CLI exception hierarchy with exit codes."""


class CLIError(Exception):
    """Base for all CLI errors with exit codes."""

    exit_code: int = 1

    def __init__(self, message: str, exit_code: int | None = None):
        super().__init__(message)
        if exit_code is not None:
            self.exit_code = exit_code


class AuthenticationError(CLIError):
    """Authentication failed or user not logged in."""

    exit_code = 2


class APIError(CLIError):
    """API returned an error response."""

    exit_code = 3


class ValidationError(CLIError):
    """Invalid user input."""

    exit_code = 4
