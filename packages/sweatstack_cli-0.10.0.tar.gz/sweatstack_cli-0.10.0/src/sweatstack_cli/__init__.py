"""SweatStack CLI — Command-line interface for the SweatStack platform."""

__version__ = "0.10.0"
