"""Check for newer versions on PyPI."""

from __future__ import annotations

import httpx

from sweatstack_cli import __version__

PYPI_PACKAGE_NAME = "sweatstack-cli"
PYPI_URL = f"https://pypi.org/pypi/{PYPI_PACKAGE_NAME}/json"


def _parse_version(version: str) -> tuple[int, ...]:
    """Parse version string into tuple of integers for comparison."""
    return tuple(int(x) for x in version.split("."))


def get_latest_version(timeout: float = 2.0) -> str | None:
    """
    Fetch the latest version from PyPI.

    Args:
        timeout: Request timeout in seconds. Kept short to avoid
            slowing down the CLI.

    Returns:
        Latest version string, or None if the check fails.
    """
    try:
        with httpx.Client(timeout=timeout) as client:
            response = client.get(PYPI_URL)
            if response.status_code == 200:
                data = response.json()
                version: str = data["info"]["version"]
                return version
    except Exception:
        pass
    return None


def check_for_update() -> tuple[bool, str | None]:
    """
    Check if a newer version is available.

    Returns:
        Tuple of (update_available, latest_version).
        If check fails, returns (False, None).
    """
    latest = get_latest_version()
    if latest is None:
        return False, None

    try:
        current = _parse_version(__version__)
        latest_v = _parse_version(latest)
        return latest_v > current, latest
    except Exception:
        return False, None


def get_update_message() -> str | None:
    """
    Get an update message if a newer version is available.

    Returns:
        Update message string, or None if no update available.
    """
    update_available, latest = check_for_update()
    if not update_available or latest is None:
        return None

    return (
        f"Update available: {latest} (current: {__version__})\n"
        f"Run: [cyan]uv tool upgrade sweatstack-cli[/cyan] [dim](or pip/pipx)[/dim]"
    )
