"""Authenticated HTTP client for SweatStack API."""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from typing import Any

import httpx

from sweatstack_cli.auth import Authenticator
from sweatstack_cli.config import get_settings
from sweatstack_cli.exceptions import APIError, AuthenticationError


class APIClient:
    """
    HTTP client with automatic authentication.

    Handles token refresh transparently before each request.
    All API errors are translated to appropriate exceptions.

    Example:
        client = APIClient()
        user = client.get("/api/v1/oauth/userinfo")
        print(user["name"])
    """

    def __init__(self, authenticator: Authenticator | None = None) -> None:
        """
        Initialize API client.

        Args:
            authenticator: Custom authenticator instance.
                Defaults to a new Authenticator with file storage.
        """
        self._auth = authenticator or Authenticator()
        self._settings = get_settings()

    @contextmanager
    def _http(self) -> Generator[httpx.Client]:
        """
        Provide an authenticated httpx client.

        Raises:
            AuthenticationError: If not authenticated.
        """
        tokens = self._auth.get_valid_tokens()
        if tokens is None:
            raise AuthenticationError("Not authenticated. Run 'sweatstack login' first.")

        with httpx.Client(
            base_url=self._settings.api_url,
            headers={
                "Authorization": f"Bearer {tokens.access_token}",
                "User-Agent": f"sweatstack-cli/{self._settings.version}",
                "Accept": "application/json",
            },
            timeout=30.0,
        ) as client:
            yield client

    def get(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """
        Make authenticated GET request.

        Args:
            path: API path (e.g., "/api/v1/oauth/userinfo").
            **kwargs: Additional arguments passed to httpx.Client.get().

        Returns:
            Parsed JSON response.

        Raises:
            AuthenticationError: If not authenticated or session expired.
            APIError: If API returns an error response.
        """
        with self._http() as client:
            response = client.get(path, **kwargs)
            return self._handle_response(response)

    def post(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """
        Make authenticated POST request.

        Args:
            path: API path.
            **kwargs: Additional arguments passed to httpx.Client.post().

        Returns:
            Parsed JSON response.

        Raises:
            AuthenticationError: If not authenticated or session expired.
            APIError: If API returns an error response.
        """
        with self._http() as client:
            response = client.post(path, **kwargs)
            return self._handle_response(response)

    def put(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """
        Make authenticated PUT request.

        Args:
            path: API path.
            **kwargs: Additional arguments passed to httpx.Client.put().

        Returns:
            Parsed JSON response.

        Raises:
            AuthenticationError: If not authenticated or session expired.
            APIError: If API returns an error response.
        """
        with self._http() as client:
            response = client.put(path, **kwargs)
            return self._handle_response(response)

    def delete(self, path: str, **kwargs: Any) -> dict[str, Any] | None:
        """
        Make authenticated DELETE request.

        Args:
            path: API path.
            **kwargs: Additional arguments passed to httpx.Client.delete().

        Returns:
            Parsed JSON response, or None for 204 No Content.

        Raises:
            AuthenticationError: If not authenticated or session expired.
            APIError: If API returns an error response.
        """
        with self._http() as client:
            response = client.delete(path, **kwargs)
            if response.status_code == 204:
                return None
            return self._handle_response(response)

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """
        Handle API response, raising appropriate errors.

        Args:
            response: HTTP response object.

        Returns:
            Parsed JSON response body.

        Raises:
            AuthenticationError: For 401 responses.
            APIError: For other error responses.
        """
        if response.status_code == 401:
            raise AuthenticationError("Session expired. Run 'sweatstack login' again.")

        if response.status_code >= 400:
            detail = self._extract_error_detail(response)
            raise APIError(f"API error ({response.status_code}): {detail}")

        # Handle empty responses
        if not response.content:
            return {}

        result: dict[str, Any] = response.json()
        return result

    def _extract_error_detail(self, response: httpx.Response) -> str:
        """Extract error message from API response."""
        try:
            data = response.json()
            # FastAPI-style error response
            if "detail" in data:
                detail = data["detail"]
                if isinstance(detail, str):
                    return detail
                if isinstance(detail, list):
                    # Validation errors
                    return "; ".join(
                        f"{err.get('loc', ['?'])[-1]}: {err.get('msg', '?')}" for err in detail
                    )
                return str(detail)
            # Other error formats
            if "error" in data:
                return str(data["error"])
            if "message" in data:
                return str(data["message"])
        except Exception:
            pass

        return response.text or f"HTTP {response.status_code}"
