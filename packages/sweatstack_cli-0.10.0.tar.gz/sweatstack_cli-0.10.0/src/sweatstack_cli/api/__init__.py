"""API client for SweatStack."""

from sweatstack_cli.api.client import APIClient

__all__ = ["APIClient"]
