"""Tests for version check functionality."""

from __future__ import annotations

import httpx
from pytest_httpx import HTTPXMock

from sweatstack_cli.version_check import (
    PYPI_URL,
    check_for_update,
    get_latest_version,
    get_update_message,
)


class TestGetLatestVersion:
    """Tests for get_latest_version function."""

    def test_returns_version_on_success(self, httpx_mock: HTTPXMock) -> None:
        """Should return version string from PyPI response."""
        httpx_mock.add_response(
            url=PYPI_URL,
            json={"info": {"version": "1.2.3"}},
        )

        result = get_latest_version()

        assert result == "1.2.3"

    def test_returns_none_on_http_error(self, httpx_mock: HTTPXMock) -> None:
        """Should return None on HTTP error."""
        httpx_mock.add_response(url=PYPI_URL, status_code=500)

        result = get_latest_version()

        assert result is None

    def test_returns_none_on_timeout(self, httpx_mock: HTTPXMock) -> None:
        """Should return None on timeout."""
        httpx_mock.add_exception(httpx.TimeoutException("timeout"))

        result = get_latest_version()

        assert result is None

    def test_returns_none_on_invalid_json(self, httpx_mock: HTTPXMock) -> None:
        """Should return None on invalid JSON response."""
        httpx_mock.add_response(url=PYPI_URL, json={"invalid": "response"})

        result = get_latest_version()

        assert result is None


class TestCheckForUpdate:
    """Tests for check_for_update function."""

    def test_returns_true_when_update_available(self, httpx_mock: HTTPXMock) -> None:
        """Should return True when newer version is available."""
        httpx_mock.add_response(
            url=PYPI_URL,
            json={"info": {"version": "99.0.0"}},
        )

        update_available, latest = check_for_update()

        assert update_available is True
        assert latest == "99.0.0"

    def test_returns_false_when_up_to_date(self, httpx_mock: HTTPXMock) -> None:
        """Should return False when on latest version."""
        httpx_mock.add_response(
            url=PYPI_URL,
            json={"info": {"version": "0.0.1"}},
        )

        update_available, latest = check_for_update()

        assert update_available is False
        assert latest == "0.0.1"

    def test_returns_false_on_error(self, httpx_mock: HTTPXMock) -> None:
        """Should return False when check fails."""
        httpx_mock.add_response(url=PYPI_URL, status_code=404)

        update_available, latest = check_for_update()

        assert update_available is False
        assert latest is None


class TestGetUpdateMessage:
    """Tests for get_update_message function."""

    def test_returns_message_when_update_available(self, httpx_mock: HTTPXMock) -> None:
        """Should return formatted message when update is available."""
        httpx_mock.add_response(
            url=PYPI_URL,
            json={"info": {"version": "99.0.0"}},
        )

        msg = get_update_message()

        assert msg is not None
        assert "99.0.0" in msg
        assert "sweatstack-cli" in msg

    def test_returns_none_when_up_to_date(self, httpx_mock: HTTPXMock) -> None:
        """Should return None when on latest version."""
        httpx_mock.add_response(
            url=PYPI_URL,
            json={"info": {"version": "0.0.1"}},
        )

        msg = get_update_message()

        assert msg is None

    def test_returns_none_on_error(self, httpx_mock: HTTPXMock) -> None:
        """Should return None when check fails."""
        httpx_mock.add_response(url=PYPI_URL, status_code=500)

        msg = get_update_message()

        assert msg is None
