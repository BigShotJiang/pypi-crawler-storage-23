"""Tests for OAuth callback server."""

from __future__ import annotations

import threading
import time
from http.client import HTTPConnection

import pytest

from sweatstack_cli.auth.callback_server import (
    AuthorizationResult,
    CallbackServer,
)
from sweatstack_cli.exceptions import AuthenticationError


class TestCallbackServer:
    """Tests for CallbackServer class."""

    def test_get_redirect_uri_format(self) -> None:
        """Should return properly formatted redirect URI."""
        server = CallbackServer()
        try:
            uri = server.get_redirect_uri()

            assert uri.startswith("http://localhost:")
            assert uri.endswith("/callback")
            assert 8400 <= int(uri.split(":")[2].split("/")[0]) < 8500
        finally:
            server.shutdown()

    def test_successful_callback(self) -> None:
        """Should handle successful OAuth callback."""
        server = CallbackServer(timeout=5.0)
        redirect_uri = server.get_redirect_uri()
        port = int(redirect_uri.split(":")[2].split("/")[0])

        state = "test_state_123"

        def make_callback():
            time.sleep(0.1)  # Give server time to start listening
            conn = HTTPConnection("localhost", port, timeout=5)
            conn.request("GET", f"/callback?code=auth_code&state={state}")
            response = conn.getresponse()
            assert response.status == 200
            conn.close()

        thread = threading.Thread(target=make_callback)
        thread.start()

        try:
            result = server.wait_for_callback(expected_state=state)

            assert isinstance(result, AuthorizationResult)
            assert result.code == "auth_code"
            assert result.state == state
        finally:
            thread.join(timeout=5)
            server.shutdown()

    def test_state_mismatch(self) -> None:
        """Should raise on state mismatch."""
        server = CallbackServer(timeout=5.0)
        redirect_uri = server.get_redirect_uri()
        port = int(redirect_uri.split(":")[2].split("/")[0])

        def make_callback():
            time.sleep(0.1)
            conn = HTTPConnection("localhost", port, timeout=5)
            conn.request("GET", "/callback?code=auth_code&state=wrong_state")
            conn.getresponse()
            conn.close()

        thread = threading.Thread(target=make_callback)
        thread.start()

        try:
            with pytest.raises(AuthenticationError, match="State parameter mismatch"):
                server.wait_for_callback(expected_state="expected_state")
        finally:
            thread.join(timeout=5)
            server.shutdown()

    def test_error_callback(self) -> None:
        """Should raise on OAuth error response."""
        server = CallbackServer(timeout=5.0)
        redirect_uri = server.get_redirect_uri()
        port = int(redirect_uri.split(":")[2].split("/")[0])

        def make_callback():
            time.sleep(0.1)
            conn = HTTPConnection("localhost", port, timeout=5)
            conn.request(
                "GET", "/callback?error=access_denied&error_description=User+denied+access"
            )
            response = conn.getresponse()
            assert response.status == 400
            conn.close()

        thread = threading.Thread(target=make_callback)
        thread.start()

        try:
            with pytest.raises(AuthenticationError, match="access_denied"):
                server.wait_for_callback(expected_state="state")
        finally:
            thread.join(timeout=5)
            server.shutdown()

    def test_missing_parameters(self) -> None:
        """Should raise on missing code or state."""
        server = CallbackServer(timeout=5.0)
        redirect_uri = server.get_redirect_uri()
        port = int(redirect_uri.split(":")[2].split("/")[0])

        def make_callback():
            time.sleep(0.1)
            conn = HTTPConnection("localhost", port, timeout=5)
            conn.request("GET", "/callback?code=only_code")  # Missing state
            response = conn.getresponse()
            assert response.status == 400
            conn.close()

        thread = threading.Thread(target=make_callback)
        thread.start()

        try:
            with pytest.raises(AuthenticationError, match="Missing code or state"):
                server.wait_for_callback(expected_state="state")
        finally:
            thread.join(timeout=5)
            server.shutdown()

    def test_wait_without_start_raises(self) -> None:
        """Should raise if wait_for_callback called before get_redirect_uri."""
        server = CallbackServer()

        with pytest.raises(RuntimeError, match="Server not started"):
            server.wait_for_callback(expected_state="state")

    def test_shutdown_idempotent(self) -> None:
        """Should allow multiple shutdown calls."""
        server = CallbackServer()
        server.get_redirect_uri()

        server.shutdown()
        server.shutdown()  # Should not raise


class TestAuthorizationResult:
    """Tests for AuthorizationResult dataclass."""

    def test_is_immutable(self) -> None:
        """Should be frozen."""
        result = AuthorizationResult(code="code", state="state")

        with pytest.raises(AttributeError):
            result.code = "new"  # type: ignore[misc]

    def test_attributes(self) -> None:
        """Should store code and state."""
        result = AuthorizationResult(code="auth_code", state="csrf_state")

        assert result.code == "auth_code"
        assert result.state == "csrf_state"
