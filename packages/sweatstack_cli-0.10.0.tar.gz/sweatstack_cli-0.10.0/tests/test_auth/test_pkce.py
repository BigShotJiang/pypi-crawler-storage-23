"""Tests for PKCE implementation."""

from __future__ import annotations

import base64
import hashlib

from sweatstack_cli.auth.pkce import PKCEChallenge, generate_pkce


class TestGeneratePKCE:
    """Tests for generate_pkce function."""

    def test_returns_pkce_challenge(self) -> None:
        """Should return a PKCEChallenge dataclass."""
        result = generate_pkce()
        assert isinstance(result, PKCEChallenge)

    def test_verifier_length_in_range(self) -> None:
        """Verifier should be 43-128 characters per RFC 7636."""
        for _ in range(10):  # Test multiple times due to randomness
            result = generate_pkce()
            assert 43 <= len(result.verifier) <= 128

    def test_verifier_is_base64url(self) -> None:
        """Verifier should only contain base64url characters."""
        result = generate_pkce()
        # base64url alphabet: A-Z, a-z, 0-9, -, _
        allowed = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_")
        assert all(c in allowed for c in result.verifier)

    def test_challenge_is_s256_of_verifier(self) -> None:
        """Challenge should be BASE64URL(SHA256(verifier))."""
        result = generate_pkce()

        # Compute expected challenge
        expected_digest = hashlib.sha256(result.verifier.encode("ascii")).digest()
        expected_challenge = base64.urlsafe_b64encode(expected_digest).rstrip(b"=").decode("ascii")

        assert result.challenge == expected_challenge

    def test_challenge_length(self) -> None:
        """Challenge should be 43 characters (256 bits in base64url without padding)."""
        result = generate_pkce()
        assert len(result.challenge) == 43

    def test_state_is_random(self) -> None:
        """Each call should produce a different state."""
        results = [generate_pkce() for _ in range(10)]
        states = [r.state for r in results]
        assert len(set(states)) == 10, "States should all be unique"

    def test_verifier_is_random(self) -> None:
        """Each call should produce a different verifier."""
        results = [generate_pkce() for _ in range(10)]
        verifiers = [r.verifier for r in results]
        assert len(set(verifiers)) == 10, "Verifiers should all be unique"

    def test_pkce_challenge_is_immutable(self) -> None:
        """PKCEChallenge should be immutable (frozen dataclass)."""
        result = generate_pkce()
        try:
            result.verifier = "new_value"  # type: ignore[misc]
            raise AssertionError("Should have raised FrozenInstanceError")
        except AttributeError:
            pass  # Expected for frozen dataclass
