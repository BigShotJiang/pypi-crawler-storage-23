"""Tests for CLI commands."""

from __future__ import annotations

from typer.testing import CliRunner

from sweatstack_cli.main import app

runner = CliRunner()


class TestCLI:
    """Tests for main CLI application."""

    def test_help(self) -> None:
        """Should show help text."""
        result = runner.invoke(app, ["--help"])

        assert result.exit_code == 0
        assert "SweatStack CLI" in result.stdout
        assert "login" in result.stdout
        assert "logout" in result.stdout
        assert "status" in result.stdout
        assert "page" in result.stdout

    def test_version(self) -> None:
        """Should show version."""
        result = runner.invoke(app, ["--version"])

        assert result.exit_code == 0
        assert "sweatstack-cli" in result.stdout

    def test_short_help(self) -> None:
        """Should support -h for help."""
        result = runner.invoke(app, ["-h"])

        assert result.exit_code == 0
        assert "SweatStack CLI" in result.stdout

    def test_no_args_shows_help(self) -> None:
        """Should show help when invoked without arguments."""
        result = runner.invoke(app, [])

        # no_args_is_help=True causes exit code 2
        assert result.exit_code == 2
        assert "Usage:" in result.stdout


class TestPageCommands:
    """Tests for page subcommands."""

    def test_page_help(self) -> None:
        """Should show page help."""
        result = runner.invoke(app, ["page", "--help"])

        assert result.exit_code == 0
        assert "deploy" in result.stdout

    def test_page_deploy_help(self) -> None:
        """Should show deploy help."""
        result = runner.invoke(app, ["page", "deploy", "--help"])

        assert result.exit_code == 0
        assert "SLUG" in result.stdout
        assert "--dir" in result.stdout
        assert "-d," not in result.stdout


class TestAppCommands:
    """Tests for app subcommands."""

    def test_app_help(self) -> None:
        """Should show app help."""
        result = runner.invoke(app, ["app", "--help"])

        assert result.exit_code == 0
        assert "create" in result.stdout

    def test_app_create_help(self) -> None:
        """Should show create help."""
        result = runner.invoke(app, ["app", "create", "--help"])

        assert result.exit_code == 0
        assert "NAME" in result.stdout
        assert "--page" in result.stdout
        assert "--secret" in result.stdout
        assert "--env" in result.stdout
        assert "--json" in result.stdout
