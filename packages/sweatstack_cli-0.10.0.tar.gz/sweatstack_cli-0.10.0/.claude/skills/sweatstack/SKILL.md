---
name: sweatstack
description: Builds applications integrating with SweatStack sports data platform. Provides OAuth PKCE authentication, API endpoints, and patterns for single-file HTML web apps. Use when building fitness dashboards, athletic data tools, or apps using SweatStack.
---

# SweatStack

Sports data platform providing auth, storage, and wearable integrations for developers.

**Base URL:** `https://app.sweatstack.no`

**Default scopes:** `openid profile data:read`

## Reference

**Webapps:** Single-file HTML apps with vanilla JS. See [webapp.md](webapp.md)

**PyScript webapps:** Python data science in the browser (pandas, sklearn, scipy). Trade-offs and template. See [pyscript.md](pyscript.md)

**CLI:** App management and deployment. See [cli.md](cli.md)

**Auth:** OAuth2/PKCE authentication. See [auth.md](auth.md)

**API:** Endpoints and data formats. See [api.md](api.md)
