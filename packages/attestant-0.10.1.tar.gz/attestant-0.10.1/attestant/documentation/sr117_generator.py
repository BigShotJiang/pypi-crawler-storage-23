"""
SR 11-7 Model Validation Report Generator.

Generates comprehensive model validation documentation compliant with
Federal Reserve Supervisory Guidance SR 11-7 and OCC Bulletin 2011-12.

The report includes all sections required by regulators:
1. Executive Summary
2. Model Purpose and Design
3. Data Quality and Governance
4. Model Development and Methodology
5. Model Performance and Validation
6. Ongoing Monitoring Plan
7. Limitations and Assumptions
8. Governance and Controls

Auto-regenerates when the model or pipeline changes, preventing documentation
drift that causes exam findings.
"""

import time
from typing import Any, Dict, List, Optional

from .base import BaseDocumentGenerator, DocumentSection
from ..fairness.engine import FairLensReport
from ..hydra24_dag import ComputationDAG


class SR117Generator(BaseDocumentGenerator):
    """
    SR 11-7 model validation report generator.

    Produces comprehensive documentation that satisfies Federal Reserve
    and OCC expectations for model validation reports.
    """

    def get_format(self) -> str:
        return "markdown"

    def get_regulation_name(self) -> str:
        return "SR 11-7 / OCC 2011-12"

    def generate(
        self,
        model_name: str,
        model_version: str,
        fairness_report: FairLensReport,
        dag: Optional[ComputationDAG] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate SR 11-7 compliant model validation report.

        Returns a markdown document with all required sections.
        """
        metadata = metadata or {}

        sections = [
            self._section_title_page(model_name, model_version, metadata),
            self._section_executive_summary(fairness_report, metadata),
            self._section_model_purpose(model_name, metadata),
            self._section_model_identity(model_name, model_version, fairness_report, metadata),
            self._section_data_governance(dag, metadata),
            self._section_model_development(metadata),
            self._section_validation_testing(fairness_report, metadata),
            self._section_fairness_analysis(fairness_report),
            self._section_ongoing_monitoring(metadata),
            self._section_limitations(metadata),
            self._section_governance(metadata),
        ]

        return self._format_sections(sections, "markdown")

    def _section_title_page(
        self, model_name: str, model_version: str, metadata: Dict
    ) -> DocumentSection:
        """Generate title page section."""
        timestamp = time.strftime("%B %d, %Y", time.localtime())
        validator = metadata.get("model_validator", "Independent Validation Team")
        owner = metadata.get("model_owner", "Model Risk Management")

        content = f"""
**Model Validation Report**

**Model:** {model_name}
**Version:** {model_version}
**Date:** {timestamp}
**Validator:** {validator}
**Model Owner:** {owner}

**Regulation:** Federal Reserve SR 11-7 / OCC Bulletin 2011-12

**Confidentiality:** Internal Use Only
"""
        return DocumentSection(title="Model Validation Report", content=content, level=1)

    def _section_executive_summary(
        self, fairness_report: FairLensReport, metadata: Dict
    ) -> DocumentSection:
        """Generate executive summary."""
        critical = fairness_report.summary.get("critical", 0)
        warnings = fairness_report.summary.get("warnings", 0)
        di_detected = fairness_report.summary.get("disparate_impact_detected", False)

        validation_status = "APPROVED" if critical == 0 else "CONDITIONAL" if warnings > 0 else "REJECTED"

        content = f"""
### Validation Status: {validation_status}

This report presents the independent validation of the {fairness_report.model_name} model
in accordance with the Federal Reserve's Supervisory Guidance on Model Risk Management
(SR Letter 11-7, April 2011) and OCC Bulletin 2011-12.

**Key Findings:**

- **Critical Issues:** {critical}
- **Warnings:** {warnings}
- **Disparate Impact:** {'Detected' if di_detected else 'Not Detected'}
- **Model Hash:** {fairness_report.summary.get('model_hash', 'N/A')[:16]}
- **Validation Date:** {time.strftime('%Y-%m-%d')}

**Recommendation:**

{self._get_recommendation(fairness_report)}

**Validator Independence:**

The validation was performed by staff independent from model development and model use,
with appropriate expertise in statistical modeling, risk management, and regulatory compliance.
"""
        return DocumentSection(title="1. Executive Summary", content=content, level=2)

    def _section_model_purpose(self, model_name: str, metadata: Dict) -> DocumentSection:
        """Generate model purpose and design section."""
        purpose = metadata.get("model_purpose", "Credit risk assessment")
        industry = metadata.get("industry", "lending")

        content = f"""
**Model Name:** {model_name}

**Intended Purpose:**

{purpose}

**Industry Application:** {industry.title()}

**Business Use Cases:**

The model is used to support credit decisions including:
- Application evaluation and underwriting
- Risk-based pricing
- Portfolio risk management

**Decision Authority:**

This model operates as a {metadata.get('decision_authority', 'decision support tool')}.
{'Human override is required for all final decisions.' if metadata.get('human_override_required') else 'The model provides recommendations that inform final credit decisions.'}

**Regulatory Scope:**

This model is subject to:
- Equal Credit Opportunity Act (ECOA / Regulation B)
- Fair Credit Reporting Act (FCRA)
- SR 11-7 Model Risk Management guidance
- OCC Bulletin 2011-12
"""
        return DocumentSection(title="2. Model Purpose and Design", content=content, level=2)

    def _section_model_identity(
        self, model_name: str, model_version: str, fairness_report: FairLensReport, metadata: Dict
    ) -> DocumentSection:
        """Generate model identity and versioning section."""
        model_id = fairness_report.model_identity
        if model_id is None:
            model_hash = "N/A"
            training_hash = "N/A"
        else:
            model_hash = model_id.model_hash[:16]
            training_hash = model_id.training_data_hash[:16] if model_id.training_data_hash else "N/A"

        content = f"""
**Model Identifier:** {model_name}

**Version:** {model_version}

**Model Hash (SHA-256):** {model_hash}...

**Training Data Hash (SHA-256):** {training_hash}...

**Deployment Date:** {metadata.get('deployment_date', 'Pending validation approval')}

**Model Risk Tier:** {metadata.get('model_risk_tier', 'Not specified').upper()}

The model hash provides cryptographic proof that the model deployed to production
matches the model that underwent validation. This hash is recorded in the audit trail
and can be verified by examiners.
"""
        return DocumentSection(title="3. Model Identity and Versioning", content=content, level=2)

    def _section_data_governance(self, dag: Optional[ComputationDAG], metadata: Dict) -> DocumentSection:
        """Generate data quality and governance section."""
        if dag:
            source_count = len(list(dag.source_nodes))
            protected_count = len(list(dag.protected_sources))
        else:
            source_count = 0
            protected_count = 0

        content = f"""
**Training Data Description:**

{metadata.get('training_data_description', 'Training data consists of historical credit application data with outcomes.')}

**Data Sources:** {source_count if dag else 'Not specified'}

**Protected Data Sources:** {protected_count if dag else 'Not specified'}

**Data Quality Checks:**

The following data quality validations were performed:
- Missing value analysis
- Outlier detection
- Distribution consistency (train/test)
- Class imbalance assessment

**Data Lineage:**

{'Full data lineage is captured in the HYDRA-24 computation graph, enabling complete traceability from raw source data to model predictions.' if dag else 'Data lineage documentation is required for full compliance.'}

**Data Retention:**

Training data and model artifacts are retained for {metadata.get('record_retention_months', 25)} months
in accordance with 12 CFR 1002.12 (ECOA record retention requirements).
"""
        return DocumentSection(title="4. Data Quality and Governance", content=content, level=2)

    def _section_model_development(self, metadata: Dict) -> DocumentSection:
        """Generate model development methodology section."""
        content = f"""
**Development Methodology:**

{metadata.get('development_methodology', 'The model was developed using supervised machine learning techniques with cross-validation and holdout testing.')}

**Model Type:** {metadata.get('model_type', 'Gradient Boosted Trees')}

**Feature Engineering:**

{metadata.get('feature_engineering_description', 'Features were engineered from raw application data, credit bureau data, and alternative data sources.')}

**Hyperparameter Tuning:**

{metadata.get('hyperparameter_tuning', 'Hyperparameters were optimized using grid search with 5-fold cross-validation.')}

**Model Selection Criteria:**

Models were evaluated on:
- Predictive accuracy (AUC, precision, recall)
- Fairness metrics (disparate impact, equalized odds)
- Model interpretability
- Computational efficiency
"""
        return DocumentSection(title="5. Model Development Methodology", content=content, level=2)

    def _section_validation_testing(self, fairness_report: FairLensReport, metadata: Dict) -> DocumentSection:
        """Generate validation and testing section."""
        content = f"""
**Validation Framework:**

This validation follows the three pillars of SR 11-7:
1. Evaluation of conceptual soundness
2. Ongoing monitoring
3. Outcomes analysis

**Performance Metrics:**

{self._create_summary_table(fairness_report)}

**Back-Testing Results:**

{metadata.get('backtesting_results', 'Back-testing results are documented in Appendix A.')}

**Stress Testing:**

{metadata.get('stress_testing', 'Sensitivity analysis and stress testing results are documented in Appendix B.')}

**Challenger Model:**

{metadata.get('challenger_model_name', 'A challenger model was not evaluated for this validation.') if not metadata.get('challenger_model_name') else f"Challenger model: {metadata['challenger_model_name']} (see Appendix C for comparison)"}
"""
        return DocumentSection(title="6. Model Performance and Validation Testing", content=content, level=2)

    def _section_fairness_analysis(self, fairness_report: FairLensReport) -> DocumentSection:
        """Generate fairness and compliance analysis section."""
        content = f"""
**Regulatory Framework:**

This analysis evaluates compliance with:
- Equal Credit Opportunity Act (ECOA / 12 CFR 1002)
- CFPB Circular 2023-03 (Adverse Action in AI)
- CFPB Supervisory Highlights (January 2025)

**Disparate Impact Analysis:**

{self._create_di_table(fairness_report)}

**Proxy Variable Detection:**

{self._create_proxy_table(fairness_report)}

**Less Discriminatory Alternative (LDA) Search:**

{self._format_lda_results(fairness_report)}

**Adverse Action Compliance:**

{self._format_adverse_action(fairness_report)}
"""
        return DocumentSection(title="7. Fairness and Compliance Analysis", content=content, level=2)

    def _section_ongoing_monitoring(self, metadata: Dict) -> DocumentSection:
        """Generate ongoing monitoring plan section."""
        content = f"""
**Monitoring Frequency:** {metadata.get('monitoring_frequency', 'Quarterly')}

**Monitored Metrics:**

1. **Performance Metrics:**
   - Model AUC
   - Precision/Recall
   - Default rate predictions vs actuals

2. **Fairness Metrics:**
   - Disparate impact ratios (four-fifths test)
   - Proxy variable correlations
   - Intersectional disparate impact

3. **Stability Indicators:**
   - Feature distribution drift
   - Population stability index (PSI)
   - Characteristic stability index (CSI)

**Performance Thresholds:**

{metadata.get('performance_thresholds', 'Degradation thresholds trigger re-validation: AUC drop >5%, DI ratio <0.75, PSI >0.25')}

**Escalation Procedures:**

{metadata.get('escalation_procedures', 'Threshold breaches are escalated to the Model Risk Management Committee within 5 business days.')}

**Re-validation Triggers:**

- Material model changes (features, algorithm, training data)
- Performance degradation beyond thresholds
- Regulatory guidance changes
- Annual re-validation (minimum)
"""
        return DocumentSection(title="8. Ongoing Monitoring Plan", content=content, level=2)

    def _section_limitations(self, metadata: Dict) -> DocumentSection:
        """Generate model limitations section."""
        default_assumptions = (
            "- Training data is representative of the application population\n"
            "- Feature relationships are stable over time\n"
            "- Applicant behavior patterns remain consistent"
        )
        default_limitations = (
            "- Model performance may degrade for populations underrepresented in training data\n"
            "- Extreme economic conditions may violate stationarity assumptions\n"
            "- Alternative data sources may have coverage gaps for certain segments"
        )
        default_controls = (
            "Manual review is required for:\n"
            "- Applications with scores near decision boundaries\n"
            "- Unusual or out-of-sample feature values\n"
            "- Applicants from underrepresented segments"
        )
        assumptions = metadata.get('model_assumptions', default_assumptions)
        limitations = metadata.get('model_limitations', default_limitations)
        controls = metadata.get('compensating_controls', default_controls)
        content = f"""
**Model Assumptions:**

{assumptions}

**Known Limitations:**

{limitations}

**Compensating Controls:**

{controls}

**Use Restrictions:**

The model should not be used for:
- Populations significantly different from the training population
- Decision-making without human oversight
- Applications outside the intended credit product scope
"""
        return DocumentSection(title="9. Model Limitations and Use Restrictions", content=content, level=2)

    def _section_governance(self, metadata: Dict) -> DocumentSection:
        """Generate governance and controls section."""
        content = f"""
**Model Risk Management Committee:**

{metadata.get('mrm_committee_name', 'The Model Risk Management Committee oversees all production models.')}

**Board Reporting:**

Model risk is reported to the Board {metadata.get('board_reporting_frequency', 'quarterly')}.

**Approval Authority:**

{'Board approval was obtained on ' + metadata['board_approval_date'] if metadata.get('board_approval_date') else 'Board approval is required before production deployment.'}

**Model Policies:**

{metadata.get('model_policies_documentation', 'Written model risk management policies govern development, validation, and monitoring.')}

**Change Management:**

All model changes are logged and require re-validation assessment. Material changes
trigger full re-validation.

**Audit Trail:**

Complete audit trail is maintained including:
- Model development documentation
- Validation reports
- Monitoring results
- Change logs
- Board approvals
"""
        return DocumentSection(title="10. Governance, Policies, and Controls", content=content, level=2)

    def _format_lda_results(self, fairness_report: FairLensReport) -> str:
        """Format LDA search results."""
        if not fairness_report.lda_candidates:
            return "No Less Discriminatory Alternatives were tested."

        passing = [c for c in fairness_report.lda_candidates if c.passes_four_fifths]

        if not passing:
            return f"Tested {len(fairness_report.lda_candidates)} LDA candidates. None achieved four-fifths compliance."

        best = passing[0]
        return f"""
**LDA Search Results:**

Tested {len(fairness_report.lda_candidates)} alternative configurations.

**Best Less Discriminatory Alternative:**

- **Removed Features:** {', '.join(best.removed_features)}
- **Disparate Impact Improvement:** {best.original_disparity:.2f} → {best.candidate_disparity:.2f}
- **AUC Loss:** {best.auc_loss_pct:.1f}%
- **Recommendation:** {best.recommendation}

Full LDA search results are documented in Appendix D.
"""

    def _format_adverse_action(self, fairness_report: FairLensReport) -> str:
        """Format adverse action results."""
        method = fairness_report.summary.get("explanation_method", "none")
        confidence = fairness_report.summary.get("explanation_confidence", 0.0)
        negative = fairness_report.summary.get("negative_outcomes", 0)

        if method == "none" or method == "zeros":
            return "⚠️ **No explainability method available.** Per-applicant adverse action reasons cannot be generated."

        return f"""
**Explanation Method:** {method.upper()}

**Explanation Fidelity:** {confidence:.1%}

**Denied Applications:** {negative}

Adverse action reason codes are generated using {method} and mapped to FFIEC standardized codes.
Sample adverse action explanations are provided in Appendix E.
"""

    def _get_recommendation(self, fairness_report: FairLensReport) -> str:
        """Generate validator recommendation."""
        critical = fairness_report.summary.get("critical", 0)
        warnings = fairness_report.summary.get("warnings", 0)

        if critical == 0 and warnings == 0:
            return "✓ **APPROVED for production deployment.** The model meets all regulatory requirements."
        elif critical == 0:
            return f"⚠️ **CONDITIONAL APPROVAL.** {warnings} warning(s) should be addressed, but do not block deployment."
        else:
            return f"✗ **DEPLOYMENT BLOCKED.** {critical} critical finding(s) must be resolved before production use."
