"""
Base classes for compliance documentation generation.

Living documentation that auto-regenerates when the model or pipeline changes,
ensuring documentation never drifts from reality.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ..fairness.engine import FairLensReport
from ..hydra24_dag import ComputationDAG


@dataclass
class DocumentSection:
    """A section of a compliance document."""
    title: str
    content: str
    level: int = 1
    subsections: List['DocumentSection'] = None

    def __post_init__(self):
        if self.subsections is None:
            self.subsections = []


class BaseDocumentGenerator(ABC):
    """
    Base class for regulatory compliance document generators.

    Subclasses implement specific regulatory formats:
    - SR11-7Generator: Federal Reserve SR 11-7 model validation reports
    - OCCGenerator: OCC Comptroller's Handbook format
    - EUAIActGenerator: EU AI Act Article 11 technical documentation
    """

    @abstractmethod
    def generate(
        self,
        model_name: str,
        model_version: str,
        fairness_report: FairLensReport,
        dag: Optional[ComputationDAG] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate compliance document.

        Args:
            model_name: Model identifier
            model_version: Semantic version
            fairness_report: FairLens analysis report
            dag: Optional HYDRA-24 computation DAG
            metadata: Additional metadata for the report

        Returns:
            Formatted document as string (markdown or HTML)
        """
        pass

    @abstractmethod
    def get_format(self) -> str:
        """Return document format (markdown, html, pdf, etc.)"""
        pass

    @abstractmethod
    def get_regulation_name(self) -> str:
        """Return the regulation this generator implements."""
        pass

    def _format_sections(self, sections: List[DocumentSection], format: str = "markdown") -> str:
        """Format sections into a document."""
        if format == "markdown":
            return self._format_markdown(sections)
        elif format == "html":
            return self._format_html(sections)
        else:
            raise ValueError(f"Unsupported format: {format}")

    def _format_markdown(self, sections: List[DocumentSection]) -> str:
        """Format sections as markdown."""
        lines = []
        for section in sections:
            lines.append(f"{'#' * section.level} {section.title}\n")
            lines.append(section.content)
            lines.append("")
            if section.subsections:
                lines.append(self._format_markdown(section.subsections))
        return "\n".join(lines)

    def _format_html(self, sections: List[DocumentSection]) -> str:
        """Format sections as HTML."""
        lines = ["<!DOCTYPE html>", "<html>", "<head>",
                 "<meta charset='utf-8'>",
                 "<title>Model Validation Report</title>",
                 "<style>",
                 "body { font-family: Arial, sans-serif; max-width: 900px; margin: 40px auto; }",
                 "h1 { border-bottom: 2px solid #333; }",
                 "h2 { border-bottom: 1px solid #666; margin-top: 30px; }",
                 "table { border-collapse: collapse; width: 100%; margin: 20px 0; }",
                 "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }",
                 "th { background-color: #f2f2f2; }",
                 ".critical { color: #d32f2f; font-weight: bold; }",
                 ".warning { color: #f57c00; }",
                 ".info { color: #1976d2; }",
                 "</style>",
                 "</head>", "<body>"]

        for section in sections:
            h_tag = f"h{min(section.level, 6)}"
            lines.append(f"<{h_tag}>{section.title}</{h_tag}>")
            lines.append(f"<div>{section.content}</div>")
            if section.subsections:
                lines.append(self._format_html(section.subsections))

        lines.append("</body></html>")
        return "\n".join(lines)

    def _create_summary_table(self, fairness_report: FairLensReport) -> str:
        """Create markdown table with fairness summary."""
        lines = [
            "| Metric | Value |",
            "|--------|-------|",
            f"| Total Findings | {fairness_report.summary.get('total_findings', 0)} |",
            f"| Critical Findings | {fairness_report.summary.get('critical', 0)} |",
            f"| Warning Findings | {fairness_report.summary.get('warnings', 0)} |",
            f"| Disparate Impact Detected | {'Yes' if fairness_report.summary.get('disparate_impact_detected') else 'No'} |",
            f"| Proxy Features Detected | {fairness_report.summary.get('proxy_features_detected', 0)} |",
            f"| LDA Passing Candidates | {fairness_report.summary.get('lda_passing_found', 0)} |",
            f"| Explanation Method | {fairness_report.summary.get('explanation_method', 'N/A')} |",
            f"| Explanation Confidence | {fairness_report.summary.get('explanation_confidence', 0):.1%} |",
        ]
        return "\n".join(lines)

    def _create_di_table(self, fairness_report: FairLensReport) -> str:
        """Create disparate impact results table."""
        if not fairness_report.disparate_impact_results:
            return "No disparate impact analysis results available."

        lines = [
            "| Protected Attribute | Worst Ratio | Reference Group | Worst Group | Pass Four-Fifths |",
            "|---------------------|-------------|-----------------|-------------|------------------|",
        ]

        for di in fairness_report.disparate_impact_results:
            pass_mark = "✓" if not di.has_disparate_impact else "✗"
            lines.append(
                f"| {di.protected_attribute} | {di.worst_ratio:.3f} | "
                f"{di.reference_group} | {di.worst_group} | {pass_mark} |"
            )

        return "\n".join(lines)

    def _create_proxy_table(self, fairness_report: FairLensReport) -> str:
        """Create proxy detection results table."""
        if not fairness_report.proxy_results:
            return "No proxy features detected."

        lines = [
            "| Feature | Protected Attribute | Correlation | Risk Level |",
            "|---------|---------------------|-------------|------------|",
        ]

        for proxy in fairness_report.proxy_results[:10]:
            risk = "HIGH" if proxy.is_high_risk else "MEDIUM"
            lines.append(
                f"| {proxy.feature_name} | {proxy.protected_attribute} | "
                f"{proxy.correlation:.3f} | {risk} |"
            )

        if len(fairness_report.proxy_results) > 10:
            lines.append(f"\n*{len(fairness_report.proxy_results) - 10} additional proxy features detected (truncated)*")

        return "\n".join(lines)
