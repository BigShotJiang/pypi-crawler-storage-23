"""HYDRA-24 Dashboard: Flask-based web UIs for provenance and compliance.

Three dashboard applications:
    - server.py:      Provenance DAG dashboard (port 5001)
    - client_app.py:  Client compliance dashboard (port 5003)
    - admin_app.py:   Admin/founder monitoring dashboard (port 5004)

Backend integration::

    from attestant.dashboard import DashboardSync, DashboardStore

    store = DashboardStore(writer_dsn="postgresql://...", reader_dsn="postgresql://...")
    store.connect()

    sync = DashboardSync(store, tenant_id="first_national")
    sync.push(compliance_result=result, model_registry=registry)
"""

from .dashdb import DashboardStore

__all__ = ["DashboardStore"]
