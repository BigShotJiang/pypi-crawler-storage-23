import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

PLAN_LIMITS = {
    "starter":      {"models": 1,  "validations": 3,   "seats": 1,  "api_access": False},
    "professional": {"models": 5,  "validations": 25,  "seats": 3,  "api_access": True},
    "growth":       {"models": 20, "validations": 100, "seats": 10, "api_access": True},
    "enterprise":   {"models": -1, "validations": -1,  "seats": -1, "api_access": True},
}

PLAN_PRICES = {
    "professional": {"monthly": 599, "annual": 499},
    "growth":       {"monthly": 1799, "annual": 1499},
}

OVERAGE_PRICES = {
    "professional": 30,
    "growth":       20,
}

_STRIPE_PRICE_IDS = {
    "professional": {
        "monthly": os.environ.get("STRIPE_PRICE_PROFESSIONAL_MONTHLY", ""),
        "annual":  os.environ.get("STRIPE_PRICE_PROFESSIONAL_ANNUAL", ""),
        "overage": os.environ.get("STRIPE_PRICE_PROFESSIONAL_OVERAGE", ""),
    },
    "growth": {
        "monthly": os.environ.get("STRIPE_PRICE_GROWTH_MONTHLY", ""),
        "annual":  os.environ.get("STRIPE_PRICE_GROWTH_ANNUAL", ""),
        "overage": os.environ.get("STRIPE_PRICE_GROWTH_OVERAGE", ""),
    },
}

_STRIPE_PORTAL_CONFIG_ID = os.environ.get("STRIPE_PORTAL_CONFIG_ID", "")


def current_billing_period() -> int:
    now = datetime.now(timezone.utc)
    return now.year * 100 + now.month


def get_plan_limits(plan: str) -> dict:
    return PLAN_LIMITS.get(plan, PLAN_LIMITS["starter"])


def check_limit(store, tenant_id: str, limit_type: str):
    sub = store.get_subscription(tenant_id)
    plan = sub["plan"] if sub else "starter"
    limits = get_plan_limits(plan)
    maximum = limits.get(limit_type, 0)
    if maximum == -1:
        return True, 0, -1
    period = current_billing_period()
    usage = store.get_usage_this_period(tenant_id, period)
    current = usage.get(limit_type, 0)
    within_limit = current < maximum
    return within_limit, current, maximum


def record_usage(store, tenant_id: str, event_type: str) -> None:
    period = current_billing_period()
    store.increment_usage(tenant_id, event_type, period)
    sub = store.get_subscription(tenant_id)
    customer_id = sub.get("stripe_customer_id", "") if sub else ""
    _fire_stripe_meter_event(tenant_id, event_type, stripe_customer_id=customer_id)


def _fire_stripe_meter_event(tenant_id: str, event_type: str, stripe_customer_id: str = "") -> None:
    stripe_key = os.environ.get("STRIPE_SECRET_KEY", "")
    if not stripe_key or not stripe_customer_id:
        return
    try:
        import stripe
        stripe.api_key = stripe_key
        stripe.billing.MeterEvent.create(
            event_name=f"attestant_{event_type}",
            payload={"stripe_customer_id": stripe_customer_id, "value": "1"},
        )
    except Exception as e:
        logger.warning("Stripe meter event failed: %s", e)


def get_or_create_stripe_customer(store, tenant_id: str, email: str, company_name: str) -> str:
    stripe_key = os.environ.get("STRIPE_SECRET_KEY", "")
    if not stripe_key:
        return ""
    sub = store.get_subscription(tenant_id)
    if sub and sub.get("stripe_customer_id"):
        return sub["stripe_customer_id"]
    try:
        import stripe
        stripe.api_key = stripe_key
        customer = stripe.Customer.create(
            email=email,
            name=company_name,
            metadata={"tenant_id": tenant_id},
        )
        store.upsert_subscription(tenant_id, stripe_customer_id=customer["id"])
        return customer["id"]
    except Exception as e:
        logger.error("Failed to create Stripe customer: %s", e)
        return ""


def get_checkout_url(store, tenant_id: str, plan: str, interval: str,
                     email: str, company: str, success_url: str, cancel_url: str) -> str:
    stripe_key = os.environ.get("STRIPE_SECRET_KEY", "")
    if not stripe_key:
        return success_url
    price_id = _STRIPE_PRICE_IDS.get(plan, {}).get(interval, "")
    if not price_id:
        logger.warning("No Stripe price ID configured for plan=%s interval=%s", plan, interval)
        return success_url
    try:
        import stripe
        stripe.api_key = stripe_key
        customer_id = get_or_create_stripe_customer(store, tenant_id, email, company)
        line_items = [{"price": price_id, "quantity": 1}]
        overage_price_id = _STRIPE_PRICE_IDS.get(plan, {}).get("overage", "")
        if overage_price_id:
            line_items.append({"price": overage_price_id})
        params = {
            "mode": "subscription",
            "line_items": line_items,
            "success_url": success_url,
            "cancel_url": cancel_url,
            "client_reference_id": tenant_id,
        }
        if customer_id:
            params["customer"] = customer_id
        else:
            params["customer_email"] = email
        session = stripe.checkout.Session.create(**params)
        return session["url"]
    except Exception as e:
        logger.error("Stripe checkout session failed: %s", e)
        return success_url


def get_billing_portal_url(store, tenant_id: str, return_url: str) -> str:
    stripe_key = os.environ.get("STRIPE_SECRET_KEY", "")
    if not stripe_key:
        return return_url
    sub = store.get_subscription(tenant_id)
    customer_id = sub.get("stripe_customer_id") if sub else None
    if not customer_id:
        return return_url
    try:
        import stripe
        stripe.api_key = stripe_key
        portal_params = {"customer": customer_id, "return_url": return_url}
        if _STRIPE_PORTAL_CONFIG_ID:
            portal_params["configuration"] = _STRIPE_PORTAL_CONFIG_ID
        session = stripe.billing_portal.Session.create(**portal_params)
        return session["url"]
    except Exception as e:
        logger.error("Stripe billing portal failed: %s", e)
        return return_url


def handle_webhook(payload: bytes, sig_header: str, store) -> dict:
    stripe_key = os.environ.get("STRIPE_SECRET_KEY", "")
    webhook_secret = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
    if not stripe_key or not webhook_secret:
        return {"error": "Stripe not configured"}
    try:
        import stripe
        stripe.api_key = stripe_key
        event = stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
    except Exception as e:
        logger.warning("Stripe webhook validation failed: %s", e)
        return {"error": str(e)}

    event_type = event["type"]
    logger.info("Stripe webhook received: %s", event_type)

    if event_type in ("customer.subscription.created", "customer.subscription.updated"):
        sub_obj = event["data"]["object"]
        customer_id = sub_obj["customer"]
        tenant_id = store.get_tenant_by_stripe_customer(customer_id)
        if tenant_id:
            plan = _plan_from_price(sub_obj)
            store.upsert_subscription(
                tenant_id,
                plan=plan,
                status=sub_obj["status"],
                stripe_subscription_id=sub_obj["id"],
                cancel_at_period_end=sub_obj.get("cancel_at_period_end", False),
                current_period_start=datetime.fromtimestamp(
                    sub_obj["current_period_start"], tz=timezone.utc
                ) if sub_obj.get("current_period_start") else None,
                current_period_end=datetime.fromtimestamp(
                    sub_obj["current_period_end"], tz=timezone.utc
                ) if sub_obj.get("current_period_end") else None,
            )

    elif event_type == "customer.subscription.deleted":
        sub_obj = event["data"]["object"]
        customer_id = sub_obj["customer"]
        tenant_id = store.get_tenant_by_stripe_customer(customer_id)
        if tenant_id:
            store.upsert_subscription(tenant_id, plan="starter", status="canceled")

    elif event_type == "invoice.payment_failed":
        invoice = event["data"]["object"]
        customer_id = invoice["customer"]
        tenant_id = store.get_tenant_by_stripe_customer(customer_id)
        if tenant_id:
            store.insert_alert(tenant_id, {
                "severity": "critical",
                "source": "billing",
                "title": "Payment Failed",
                "description": (
                    f"Invoice payment failed. "
                    f"Please update your payment method to avoid service interruption. "
                    f"Invoice: {invoice.get('hosted_invoice_url', 'N/A')}"
                ),
            })

    return {"received": True, "type": event_type}


def _plan_from_price(sub_obj: dict) -> str:
    items = sub_obj.get("items", {}).get("data", [])
    if not items:
        return "starter"
    price_id = items[0].get("price", {}).get("id", "")
    for plan, intervals in _STRIPE_PRICE_IDS.items():
        if price_id in intervals.values():
            return plan
    return "starter"
