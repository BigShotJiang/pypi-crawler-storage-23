"""
Documentation engine - generates reports, model cards, and compliance docs.
Alias module that imports from documentation.* for backward compatibility.
"""

from enum import Enum
from typing import Any, Dict, List, Optional
from dataclasses import dataclass

from ..documentation.base import DocumentSection


class TemplateType(Enum):
    """Report template types."""
    SR117 = "sr117"
    MODEL_CARD = "model_card"
    BIAS_AUDIT = "bias_audit"
    COMPLIANCE = "compliance"
    EU_AI_ACT = "eu_ai_act"
    ECOA = "ecoa"
    NIST_RMF = "nist_rmf"
    GDPR = "gdpr"


@dataclass
class DocumentReport:
    """Generated documentation report."""
    title: str
    sections: List[DocumentSection]
    template_type: TemplateType
    metadata: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "sections": [s.__dict__ for s in self.sections],
            "template_type": self.template_type.value,
            "metadata": self.metadata
        }


@dataclass
class ModelMetadata:
    """Model metadata for documentation."""
    model_id: str
    model_name: str
    version: str
    domain: str


@dataclass
class PipelineMetadata:
    """Pipeline metadata for documentation."""
    pipeline_id: str
    pipeline_name: str
    status: str


class AutoDocEngine:
    """Auto-documentation engine - generates reports from templates."""

    def __init__(self):
        pass

    def generate_report(
        self,
        template_type: TemplateType,
        model: Optional[ModelMetadata] = None,
        pipeline: Optional[PipelineMetadata] = None,
        **kwargs
    ) -> DocumentReport:
        """Generate a report from template."""
        # Stub implementation - dashboard will generate content from DB
        return DocumentReport(
            title=f"{template_type.value.replace('_', ' ').title()} Report",
            sections=[],
            template_type=template_type,
            metadata={"model": model, "pipeline": pipeline, **kwargs}
        )


__all__ = [
    "AutoDocEngine",
    "DocumentReport",
    "DocumentSection",
    "TemplateType",
    "ModelMetadata",
    "PipelineMetadata",
]
