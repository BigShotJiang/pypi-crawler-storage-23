"""
API Key Management for Attestant

Features:
- Automatic expiration checks
- Proactive renewal notifications (30 days before expiry)
- IP whitelisting
- Usage tracking
- Graceful revocation
"""

import secrets
import hashlib
from datetime import datetime, timedelta
from typing import Optional, Dict, List
import psycopg2


class APIKeyManager:
    """Manage API key lifecycle"""

    def __init__(self, db_conn):
        self.db_conn = db_conn

    def create_key(
        self,
        tenant_id: str,
        tier: str = "standard",
        expires_in_days: int = 365,
        allowed_ips: Optional[List[str]] = None,
        metadata: Optional[Dict] = None,
    ) -> str:
        """
        Create a new API key.

        Args:
            tenant_id: Tenant ID
            tier: Rate limit tier (standard, premium, enterprise)
            expires_in_days: Expiration period (default 1 year)
            allowed_ips: Optional IP whitelist (CIDR notation)
            metadata: Optional metadata dict

        Returns:
            Full API key (pvt_live_...)
        """
        # Generate random key
        random_bytes = secrets.token_bytes(32)
        full_key = "pvt_live_" + secrets.token_urlsafe(32)

        # Hash for storage
        key_hash = hashlib.sha256(full_key.encode()).hexdigest()
        key_prefix = full_key[:10]

        # Calculate expiration
        expires_at = datetime.now() + timedelta(days=expires_in_days)

        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO api_keys (
                    tenant_id, key_hash, key_prefix, expires_at,
                    rate_limit_tier, allowed_ips, metadata
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                RETURNING key_id
                """,
                (
                    tenant_id,
                    key_hash,
                    key_prefix,
                    expires_at,
                    tier,
                    allowed_ips or [],
                    metadata or {},
                ),
            )
            self.db_conn.commit()

        return full_key

    def validate_api_key_security(
        self, api_key: str, request_ip: Optional[str] = None
    ) -> Dict:
        """
        Comprehensive API key validation.

        Returns:
            {
                "valid": bool,
                "error": Optional[str],
                "tenant_id": Optional[str],
                "tier": Optional[str],
                "expires_soon": bool,  # True if expires within 30 days
                "days_until_expiry": Optional[int]
            }
        """
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        key_prefix = api_key[:10]

        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    tenant_id, rate_limit_tier, expires_at,
                    allowed_ips, revoked_at, usage_count
                FROM api_keys
                WHERE key_hash = %s
                """,
                (key_hash,),
            )
            row = cur.fetchone()

        if not row:
            return {"valid": False, "error": "Invalid API key"}

        tenant_id, tier, expires_at, allowed_ips, revoked_at, usage_count = row

        # Check revocation
        if revoked_at:
            return {"valid": False, "error": "API key has been revoked"}

        # Check expiration
        if expires_at and expires_at < datetime.now():
            return {
                "valid": False,
                "error": f"API key expired on {expires_at.strftime('%Y-%m-%d')}. Please contact support to renew.",
            }

        # Check IP whitelist
        if allowed_ips and request_ip:
            if not self._ip_in_whitelist(request_ip, allowed_ips):
                return {
                    "valid": False,
                    "error": f"IP address {request_ip} not in whitelist",
                }

        # Calculate days until expiry
        days_until_expiry = None
        expires_soon = False
        if expires_at:
            days_until_expiry = (expires_at - datetime.now()).days
            expires_soon = days_until_expiry <= 30

        # Update usage tracking
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                UPDATE api_keys
                SET last_used_at = NOW(), usage_count = usage_count + 1
                WHERE key_hash = %s
                """,
                (key_hash,),
            )
            self.db_conn.commit()

        return {
            "valid": True,
            "error": None,
            "tenant_id": tenant_id,
            "tier": tier,
            "expires_soon": expires_soon,
            "days_until_expiry": days_until_expiry,
        }

    def revoke_key(self, key_prefix: str, revoked_by: str, reason: str):
        """Revoke an API key"""
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                UPDATE api_keys
                SET revoked_at = NOW(), revoked_by = %s, revoked_reason = %s
                WHERE key_prefix = %s
                """,
                (revoked_by, reason, key_prefix),
            )
            self.db_conn.commit()

    def get_expiring_keys(self, days: int = 30) -> List[Dict]:
        """
        Get API keys expiring within N days.

        Used for proactive renewal notifications.
        """
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    key_prefix, tenant_id, expires_at,
                    rate_limit_tier, last_used_at
                FROM api_keys
                WHERE expires_at BETWEEN NOW() AND NOW() + INTERVAL '%s days'
                  AND revoked_at IS NULL
                ORDER BY expires_at ASC
                """,
                (days,),
            )
            rows = cur.fetchall()

        return [
            {
                "key_prefix": row[0],
                "tenant_id": row[1],
                "expires_at": row[2],
                "tier": row[3],
                "last_used_at": row[4],
                "days_until_expiry": (row[2] - datetime.now()).days,
            }
            for row in rows
        ]

    def _ip_in_whitelist(self, ip: str, whitelist: List[str]) -> bool:
        """Check if IP is in CIDR whitelist"""
        try:
            import ipaddress

            ip_obj = ipaddress.ip_address(ip)
            for cidr in whitelist:
                if ip_obj in ipaddress.ip_network(cidr, strict=False):
                    return True
            return False
        except Exception:
            return False


def validate_api_key_security(
    api_key: str, request_ip: Optional[str], db_conn
) -> Dict:
    """
    Standalone API key validation function.

    Returns:
        {
            "valid": bool,
            "error": Optional[str],
            "tenant_id": Optional[str],
            "tier": Optional[str],
            "expires_soon": bool,
            "days_until_expiry": Optional[int]
        }
    """
    manager = APIKeyManager(db_conn)
    return manager.validate_api_key_security(api_key, request_ip)
