"""
Multi-Factor Authentication (MFA) for Attestant

TOTP-based (Time-based One-Time Password) MFA with:
- QR code enrollment
- Backup recovery codes
- Graceful degradation if user loses device

Recommended for all admin users in banking environments.
"""

import secrets
import base64
import hashlib
import hmac
import time
import io
from typing import List, Optional, Tuple
import psycopg2


def generate_totp_secret() -> str:
    """Generate a random TOTP secret (base32 encoded)"""
    random_bytes = secrets.token_bytes(20)
    return base64.b32encode(random_bytes).decode("utf-8").rstrip("=")


def generate_backup_codes(count: int = 8) -> List[str]:
    """Generate backup recovery codes"""
    return [secrets.token_hex(4).upper() for _ in range(count)]


def hash_backup_code(code: str) -> str:
    """Hash a backup code for secure storage"""
    return hashlib.sha256(code.encode()).hexdigest()


def verify_totp_code(secret: str, code: str, window: int = 1) -> bool:
    """
    Verify a TOTP code against a secret.

    Args:
        secret: Base32 TOTP secret
        code: 6-digit code from user
        window: Number of time steps to check (1 = ±30 seconds)

    Returns:
        True if code is valid
    """
    if not code or len(code) != 6 or not code.isdigit():
        return False

    try:
        # Decode base32 secret
        key = base64.b32decode(secret + "=" * ((8 - len(secret) % 8) % 8))

        # Current time step (30-second intervals)
        current_step = int(time.time() // 30)

        # Check current step and nearby steps (for clock drift)
        for step in range(current_step - window, current_step + window + 1):
            expected_code = _generate_totp_code(key, step)
            if code == expected_code:
                return True

        return False
    except Exception:
        return False


def _generate_totp_code(key: bytes, time_step: int) -> str:
    """Generate a TOTP code for a given time step"""
    # Convert time step to 8-byte counter
    counter = time_step.to_bytes(8, byteorder="big")

    # HMAC-SHA1
    hmac_hash = hmac.new(key, counter, hashlib.sha1).digest()

    # Dynamic truncation
    offset = hmac_hash[-1] & 0x0F
    code_bytes = hmac_hash[offset : offset + 4]
    code_int = int.from_bytes(code_bytes, byteorder="big") & 0x7FFFFFFF

    # 6-digit code
    return str(code_int % 1000000).zfill(6)


class MFAManager:
    """Manage MFA enrollment and verification"""

    def __init__(self, db_conn):
        self.db_conn = db_conn

    def enroll_user(
        self, user_id: int, tenant_id: str
    ) -> Tuple[str, List[str], str]:
        """
        Enroll a user in MFA.

        Returns:
            (secret, backup_codes, provisioning_uri)
        """
        secret = generate_totp_secret()
        backup_codes = generate_backup_codes()

        # Hash backup codes before storage
        hashed_codes = [hash_backup_code(code) for code in backup_codes]

        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO user_mfa (user_id, tenant_id, secret, backup_codes, enabled)
                VALUES (%s, %s, %s, %s, FALSE)
                ON CONFLICT (user_id) DO UPDATE SET
                    secret = EXCLUDED.secret,
                    backup_codes = EXCLUDED.backup_codes,
                    enabled = FALSE,
                    verified_at = NULL
                """,
                (user_id, tenant_id, secret, hashed_codes),
            )
            self.db_conn.commit()

        # Generate provisioning URI for QR code
        # Format: otpauth://totp/Attestant:user@example.com?secret=SECRET&issuer=Attestant
        provisioning_uri = f"otpauth://totp/Attestant:user_{user_id}?secret={secret}&issuer=Attestant"

        return secret, backup_codes, provisioning_uri

    def verify_enrollment(self, user_id: int, code: str) -> bool:
        """
        Verify MFA setup with first TOTP code.

        Returns:
            True if enrollment successful
        """
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                SELECT secret FROM user_mfa
                WHERE user_id = %s
                """,
                (user_id,),
            )
            row = cur.fetchone()

        if not row:
            return False

        secret = row[0]

        if verify_totp_code(secret, code):
            # Mark as verified and enabled
            with self.db_conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE user_mfa
                    SET enabled = TRUE, verified_at = NOW()
                    WHERE user_id = %s
                    """,
                    (user_id,),
                )
                self.db_conn.commit()
            return True

        return False

    def verify_code(self, user_id: int, code: str, is_backup: bool = False) -> bool:
        """
        Verify a TOTP code or backup code.

        Returns:
            True if code is valid
        """
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                SELECT secret, backup_codes, enabled
                FROM user_mfa
                WHERE user_id = %s
                """,
                (user_id,),
            )
            row = cur.fetchone()

        if not row or not row[2]:  # Not enrolled or not enabled
            return False

        secret, backup_codes, _ = row

        if is_backup:
            # Check backup codes
            code_hash = hash_backup_code(code)
            if code_hash in backup_codes:
                # Remove used backup code
                backup_codes.remove(code_hash)
                with self.db_conn.cursor() as cur:
                    cur.execute(
                        """
                        UPDATE user_mfa
                        SET backup_codes = %s, last_used_at = NOW()
                        WHERE user_id = %s
                        """,
                        (backup_codes, user_id),
                    )
                    self.db_conn.commit()
                return True
            return False
        else:
            # Check TOTP code
            if verify_totp_code(secret, code):
                with self.db_conn.cursor() as cur:
                    cur.execute(
                        """
                        UPDATE user_mfa
                        SET last_used_at = NOW()
                        WHERE user_id = %s
                        """,
                        (user_id,),
                    )
                    self.db_conn.commit()
                return True
            return False

    def is_enrolled(self, user_id: int) -> bool:
        """Check if user has MFA enabled"""
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                SELECT enabled FROM user_mfa
                WHERE user_id = %s
                """,
                (user_id,),
            )
            row = cur.fetchone()

        return row and row[0]

    def disable_mfa(self, user_id: int):
        """Disable MFA for a user (admin action)"""
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                UPDATE user_mfa
                SET enabled = FALSE
                WHERE user_id = %s
                """,
                (user_id,),
            )
            self.db_conn.commit()


def generate_qr_code_data_uri(provisioning_uri: str) -> str:
    """
    Generate a data URI for QR code display.

    Requires: pip install qrcode[pil]

    Returns:
        data:image/png;base64,... URI for embedding in HTML
    """
    try:
        import qrcode

        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(provisioning_uri)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")

        # Convert to data URI
        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        img_data = buffer.getvalue()
        img_base64 = base64.b64encode(img_data).decode()

        return f"data:image/png;base64,{img_base64}"
    except ImportError:
        # If qrcode not installed, return empty string
        # Frontend can fall back to showing secret as text
        return ""
