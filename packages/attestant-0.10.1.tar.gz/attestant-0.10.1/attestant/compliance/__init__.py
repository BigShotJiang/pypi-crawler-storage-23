"""
HYDRA-24 Compliance Engines.

Regulation-specific compliance checking against HYDRA-24 computation
DAGs.  Each engine inspects a ``ComputationDAG`` (and optional metadata)
and returns structured findings with regulatory citations and remediation
recommendations.

Supported regulations:
    - EU AI Act (Regulation (EU) 2024/1689)
    - ECOA / Regulation B (Equal Credit Opportunity Act, 12 CFR 1002)
    - SR 11-7 / OCC 2011-12 (Model Risk Management)
    - Colorado AI Act (SB 24-205)
    - NYC Local Law 144 (AEDT)

Quick start::

    from attestant.compliance import (
        ComplianceReport,
        EUAIActEngine,
        ECOAEngine,
        SR117Engine,
    )

    report = ComplianceReport()
    report.run_engines(
        engines=[EUAIActEngine(), ECOAEngine(), SR117Engine()],
        dag=my_dag,
        metadata=my_metadata,
    )
    print(report.summary())
"""

from .base import (
    CHECK_CATALOG,
    ENGINE_VERSION,
    BaseComplianceEngine,
    CheckDefinition,
    ComplianceFinding,
    ComplianceReport,
    ComplianceResult,
    Severity,
)
from .ecoa import ECOAEngine
from .eu_ai_act import EUAIActEngine
from .sr117 import SR117Engine
from .score import ComplianceScorer, ComplianceScoreResult, ScoreBreakdown
from .cro_features import (
    AttestationManager,
    AttestationStatus,
    Attestation,
    ImpactAssessment,
    PeerBenchmark,
    PeerComparisonResult,
    QuickWin,
    QuickWinRecommender,
    RegulatoryChange,
    RegulatoryChangeAssessor,
    RemediationItem,
    RemediationPriority,
    RemediationQueue,
    RiskHeatmap,
    RiskHeatmapData,
    RiskLevel,
)

__all__ = [
    "CHECK_CATALOG",
    "CheckDefinition",
    "ENGINE_VERSION",
    "Attestation",
    "AttestationManager",
    "AttestationStatus",
    "BaseComplianceEngine",
    "ComplianceFinding",
    "ComplianceReport",
    "ComplianceResult",
    "ComplianceScoreResult",
    "ComplianceScorer",
    "ECOAEngine",
    "EUAIActEngine",
    "ImpactAssessment",
    "PeerBenchmark",
    "PeerComparisonResult",
    "QuickWin",
    "QuickWinRecommender",
    "RegulatoryChange",
    "RegulatoryChangeAssessor",
    "RemediationItem",
    "RemediationPriority",
    "RemediationQueue",
    "RiskHeatmap",
    "RiskHeatmapData",
    "RiskLevel",
    "SR117Engine",
    "ScoreBreakdown",
    "Severity",
]
