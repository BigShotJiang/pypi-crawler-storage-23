"""
Compliance Score: Board-Reportable Risk Metric.

Produces a single 0-100 score that aggregates compliance posture across
all engines, fairness analysis, and governance controls.  Designed for
CRO board presentations and examiner self-assessments.

Scoring methodology:
    - Starts at 100 (fully compliant)
    - Deducts points per CRITICAL finding (weighted by regulation)
    - Deducts points per WARNING finding (lower weight)
    - Bonuses for proactive controls (certifications, monitoring, etc.)
    - Risk-tier adjustments (higher-tier models weighted more)

Grade mapping:
    A  (90-100): Examiner-ready. Minimal findings, strong controls.
    B  (75-89):  Substantially compliant. Some remediation needed.
    C  (60-74):  Material gaps. Prioritised remediation required.
    D  (40-59):  Significant deficiencies. Examiner concern likely.
    F  (0-39):   Critical failures. Immediate action required.

Usage::

    from attestant.compliance import ComplianceReport, ECOAEngine, SR117Engine
    from attestant.compliance.score import ComplianceScorer

    report = ComplianceReport()
    report.run_engines([ECOAEngine(), SR117Engine()], dag, metadata)

    scorer = ComplianceScorer()
    result = scorer.score(report)
    print(f"Score: {result.score}/100 (Grade: {result.grade})")
    print(result.board_summary())
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .base import ComplianceReport, ComplianceResult, Severity


# ---------------------------------------------------------------------------
# Regulation weights (how heavily each regulation impacts the score)
# ---------------------------------------------------------------------------

_REGULATION_WEIGHTS: Dict[str, float] = {
    "ECOA / Reg B": 1.5,          # Fair lending = highest regulatory risk
    "SR 11-7 / OCC 2011-12": 1.3, # Model risk = high examiner focus
    "EU AI Act": 1.2,             # Growing enforcement, Aug 2026 deadline
    "Colorado AI Act": 1.0,       # State law, newer
    "NYC Local Law 144": 1.0,     # Municipal, narrower scope
}

_DEFAULT_WEIGHT = 1.0

# Deduction per finding by severity
_CRITICAL_DEDUCTION = 8.0
_WARNING_DEDUCTION = 3.0

# Proactive control bonuses
_BONUS_CERTIFICATIONS = 3.0
_BONUS_MONITORING = 3.0
_BONUS_FAIRNESS_ANALYSIS = 3.0
_BONUS_DECISION_LOGGING = 2.0
_BONUS_DATA_GOVERNANCE = 2.0
_BONUS_MODEL_INVENTORY = 2.0


# ---------------------------------------------------------------------------
# Score result
# ---------------------------------------------------------------------------

@dataclass
class ScoreBreakdown:
    """Detailed breakdown of how the compliance score was calculated."""
    regulation: str
    weight: float
    critical_count: int
    warning_count: int
    info_count: int
    raw_deduction: float
    weighted_deduction: float
    passed: bool

    def to_dict(self) -> Dict[str, Any]:
        return {
            "regulation": self.regulation,
            "weight": self.weight,
            "critical_count": self.critical_count,
            "warning_count": self.warning_count,
            "info_count": self.info_count,
            "raw_deduction": round(self.raw_deduction, 1),
            "weighted_deduction": round(self.weighted_deduction, 1),
            "passed": self.passed,
        }


@dataclass
class ComplianceScoreResult:
    """Board-reportable compliance score with full breakdown."""
    score: float
    grade: str
    timestamp: datetime
    breakdowns: List[ScoreBreakdown] = field(default_factory=list)
    bonuses_applied: Dict[str, float] = field(default_factory=dict)
    total_deductions: float = 0.0
    total_bonuses: float = 0.0
    engines_evaluated: int = 0
    total_findings: int = 0
    critical_findings: int = 0
    warning_findings: int = 0
    top_risks: List[str] = field(default_factory=list)
    trend: Optional[str] = None  # "improving", "stable", "declining"
    peer_percentile: Optional[int] = None
    peer_tier: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "score": round(self.score, 1),
            "grade": self.grade,
            "timestamp": self.timestamp.isoformat(),
            "engines_evaluated": self.engines_evaluated,
            "total_findings": self.total_findings,
            "critical_findings": self.critical_findings,
            "warning_findings": self.warning_findings,
            "total_deductions": round(self.total_deductions, 1),
            "total_bonuses": round(self.total_bonuses, 1),
            "bonuses_applied": {
                k: round(v, 1) for k, v in self.bonuses_applied.items()
            },
            "breakdowns": [b.to_dict() for b in self.breakdowns],
            "top_risks": self.top_risks,
            "trend": self.trend,
        }
        if self.peer_percentile is not None:
            d["peer_percentile"] = self.peer_percentile
            d["peer_tier"] = self.peer_tier
        return d

    def board_summary(self) -> str:
        """One-page summary suitable for CRO board presentation."""
        lines = [
            f"COMPLIANCE SCORE: {self.score:.0f}/100 (Grade: {self.grade})",
            f"Generated: {self.timestamp.strftime('%Y-%m-%d %H:%M UTC')}",
            "",
            f"Engines Evaluated: {self.engines_evaluated}",
            f"Total Findings: {self.total_findings} "
            f"({self.critical_findings} critical, "
            f"{self.warning_findings} warnings)",
            "",
        ]

        if self.top_risks:
            lines.append("TOP RISKS:")
            for i, risk in enumerate(self.top_risks[:5], 1):
                lines.append(f"  {i}. {risk}")
            lines.append("")

        if self.bonuses_applied:
            lines.append("PROACTIVE CONTROLS:")
            for control, bonus in self.bonuses_applied.items():
                lines.append(f"  + {control} (+{bonus:.0f} pts)")
            lines.append("")

        lines.append("PER-REGULATION STATUS:")
        for bd in self.breakdowns:
            status = "PASS" if bd.passed else "FAIL"
            lines.append(
                f"  {bd.regulation}: {status} "
                f"({bd.critical_count}C / {bd.warning_count}W)"
            )

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Scorer
# ---------------------------------------------------------------------------

class ComplianceScorer:
    """Calculate a board-reportable compliance score from engine results.

    The scorer examines ``ComplianceReport`` output and optional context
    (certifications, monitoring status, etc.) to produce a 0-100 score
    with letter grade.

    Args:
        regulation_weights: Override default per-regulation weights.
        history: Previous scores for trend calculation.
    """

    def __init__(
        self,
        regulation_weights: Optional[Dict[str, float]] = None,
        history: Optional[List[float]] = None,
    ):
        self._weights = regulation_weights or _REGULATION_WEIGHTS
        self._history = history or []

    def score(
        self,
        report: ComplianceReport,
        proactive_controls: Optional[Dict[str, bool]] = None,
    ) -> ComplianceScoreResult:
        """Calculate the compliance score.

        Args:
            report: A ComplianceReport with results from one or more engines.
            proactive_controls: Optional dict of proactive control flags:
                - has_certifications: Active security certifications
                - has_monitoring: Continuous fairness monitoring enabled
                - has_fairness_analysis: FairLens analysis completed
                - has_decision_logging: Per-applicant decision logging
                - has_data_governance: PII detection + retention policies
                - has_model_inventory: Model inventory with hashes

        Returns:
            ComplianceScoreResult with score, grade, and breakdown.
        """
        controls = proactive_controls or {}
        breakdowns: List[ScoreBreakdown] = []
        total_deductions = 0.0
        top_risks: List[str] = []

        for result in report.results:
            weight = self._weights.get(result.regulation_name, _DEFAULT_WEIGHT)
            raw_deduction = (
                result.critical_count * _CRITICAL_DEDUCTION
                + result.warning_count * _WARNING_DEDUCTION
            )
            weighted_deduction = raw_deduction * weight

            breakdowns.append(ScoreBreakdown(
                regulation=result.regulation_name,
                weight=weight,
                critical_count=result.critical_count,
                warning_count=result.warning_count,
                info_count=result.info_count,
                raw_deduction=raw_deduction,
                weighted_deduction=weighted_deduction,
                passed=result.passed,
            ))
            total_deductions += weighted_deduction

            # Collect top risks from critical findings
            for f in result.findings:
                if f.severity == Severity.CRITICAL:
                    risk_text = (
                        f"[{result.regulation_name}] {f.description[:120]}"
                    )
                    top_risks.append(risk_text)

        # Apply bonuses for proactive controls
        bonuses: Dict[str, float] = {}
        if controls.get("has_certifications"):
            bonuses["Active Certifications"] = _BONUS_CERTIFICATIONS
        if controls.get("has_monitoring"):
            bonuses["Continuous Monitoring"] = _BONUS_MONITORING
        if controls.get("has_fairness_analysis"):
            bonuses["FairLens Analysis"] = _BONUS_FAIRNESS_ANALYSIS
        if controls.get("has_decision_logging"):
            bonuses["Decision Logging"] = _BONUS_DECISION_LOGGING
        if controls.get("has_data_governance"):
            bonuses["Data Governance"] = _BONUS_DATA_GOVERNANCE
        if controls.get("has_model_inventory"):
            bonuses["Model Inventory"] = _BONUS_MODEL_INVENTORY

        total_bonuses = sum(bonuses.values())

        # Calculate final score (floor at 0, cap at 100)
        raw_score = 100.0 - total_deductions + total_bonuses
        final_score = max(0.0, min(100.0, raw_score))

        # Determine grade
        grade = self._grade(final_score)

        # Calculate trend
        trend = self._trend(final_score)

        total_critical = sum(b.critical_count for b in breakdowns)
        total_warnings = sum(b.warning_count for b in breakdowns)

        result = ComplianceScoreResult(
            score=final_score,
            grade=grade,
            timestamp=datetime.now(timezone.utc),
            breakdowns=breakdowns,
            bonuses_applied=bonuses,
            total_deductions=total_deductions,
            total_bonuses=total_bonuses,
            engines_evaluated=len(report.results),
            total_findings=report.total_findings,
            critical_findings=total_critical,
            warning_findings=total_warnings,
            top_risks=top_risks[:5],
            trend=trend,
        )

        # Record for future trend calculation
        self._history.append(final_score)

        return result

    @staticmethod
    def _grade(score: float) -> str:
        if score >= 90:
            return "A"
        elif score >= 75:
            return "B"
        elif score >= 60:
            return "C"
        elif score >= 40:
            return "D"
        return "F"

    def _trend(self, current: float) -> Optional[str]:
        if len(self._history) < 1:
            return None
        prev = self._history[-1]
        if current > prev + 2:
            return "improving"
        elif current < prev - 2:
            return "declining"
        return "stable"

    def risk_heatmap(
        self,
        model_reports: Dict[str, "ComplianceReport"],
    ) -> "RiskHeatmapData":
        """Generate regulation-by-model risk heatmap data.

        Convenience method that delegates to RiskHeatmap.generate().

        Args:
            model_reports: Mapping of model_id to ComplianceReport.

        Returns:
            RiskHeatmapData for dashboard visualization.
        """
        from .cro_features import RiskHeatmap
        return RiskHeatmap().generate(model_reports)

    def quick_wins(
        self,
        score_result: ComplianceScoreResult,
        proactive_controls: Optional[Dict[str, bool]] = None,
        max_recommendations: int = 5,
    ) -> List[Dict[str, Any]]:
        """Identify top quick-win actions to improve compliance score.

        Convenience method that delegates to QuickWinRecommender.

        Args:
            score_result: Current compliance score result.
            proactive_controls: Dict of which controls are active.
            max_recommendations: Max number of recommendations.

        Returns:
            List of quick win dicts sorted by impact.
        """
        from .cro_features import QuickWinRecommender
        wins = QuickWinRecommender().recommend(
            score_result, proactive_controls, max_recommendations,
        )
        return [w.to_dict() for w in wins]
