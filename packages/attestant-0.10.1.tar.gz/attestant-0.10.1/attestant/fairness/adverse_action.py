"""
FairLens adverse action reason code generator: produces per-decision
explanations mapping model feature importances to regulatory reason codes.
"""

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .model_adapter import adapt_model

logger = logging.getLogger(__name__)

FFIEC_REASON_CODES: Dict[str, str] = {
    "A01": "Amount owed on accounts is too high",
    "A02": "Level of delinquency on accounts",
    "A03": "Too few bank revolving accounts",
    "A04": "Too many bank or national revolving accounts",
    "A05": "Too many accounts with balances",
    "A06": "Too many consumer finance company accounts",
    "A07": "Account payment history is too poor",
    "A08": "Too many accounts recently opened",
    "A09": "Too many inquiries last 12 months",
    "A10": "Too many accounts opened in last 12 months",
    "B01": "Proportion of balances to credit limits is too high on revolving accounts",
    "B02": "Number of revolving accounts with balances is too high",
    "B03": "Amount owed on revolving accounts is too high",
    "B04": "Time since most recent account opening is too short",
    "C01": "Too few accounts currently paid as agreed",
    "C02": "Time since delinquency is too recent or unknown",
    "C03": "Number of accounts with delinquency is too high",
    "C04": "Amount past due on accounts",
    "C05": "Presence of derogatory public records",
    "D01": "Length of time accounts have been established",
    "D02": "Time since most recent account opening is too short",
    "D03": "Length of time revolving accounts have been established",
    "E01": "Insufficient credit file information",
    "E02": "Not enough accounts with recent activity",
    "E03": "No recent revolving balances",
    "F01": "Income insufficient for amount of credit requested",
    "F02": "Excessive obligations in relation to income",
    "F03": "Unable to verify income",
    "G01": "Length of employment",
    "G02": "Length of time at current address",
    "H01": "Lack of recent installment loan information",
    "H02": "Lack of recent revolving account information",
    "H03": "No recent non-mortgage balance information",
    "I01": "Number of recent inquiries",
    "I02": "Number of established accounts",
}

FEATURE_TO_REASON_MAP: Dict[str, List[str]] = {
    "credit_score": ["E01"],
    "fico": ["E01"],
    "credit_utilization": ["B01", "B03"],
    "utilization": ["B01"],
    "debt_to_income": ["F02"],
    "dti": ["F02"],
    "income": ["F01"],
    "annual_income": ["F01"],
    "monthly_income": ["F01"],
    "loan_amount": ["F01"],
    "amount_requested": ["F01"],
    "delinquency": ["A02", "C02"],
    "delinq": ["A02", "C02"],
    "past_due": ["C04"],
    "late_payment": ["A07"],
    "payment_history": ["A07"],
    "num_open_accounts": ["A08", "I02"],
    "open_accounts": ["A08"],
    "total_accounts": ["I02"],
    "recent_inquiries": ["A09", "I01"],
    "inquiries": ["A09", "I01"],
    "account_age": ["D01", "D03"],
    "credit_age": ["D01"],
    "length_of_credit": ["D01"],
    "employment_length": ["G01"],
    "emp_length": ["G01"],
    "years_employed": ["G01"],
    "revolving_balance": ["B03", "A01"],
    "total_balance": ["A01", "A05"],
    "balance": ["A01"],
    "public_records": ["C05"],
    "bankruptcy": ["C05"],
    "collections": ["C05"],
    "address_length": ["G02"],
    "months_at_address": ["G02"],
    "installment": ["H01"],
}


@dataclass
class AdverseActionReason:
    """A single adverse action reason for an applicant."""
    rank: int
    reason_code: str
    reason_text: str
    feature_name: str
    feature_value: Any
    feature_importance: float
    contribution_direction: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "rank": self.rank,
            "code": self.reason_code,
            "text": self.reason_text,
            "feature": self.feature_name,
            "value": self.feature_value,
            "importance": self.feature_importance,
            "direction": self.contribution_direction,
        }


@dataclass
class ApplicantExplanation:
    """Complete adverse action explanation for one applicant."""
    applicant_index: int
    prediction: int
    probability: float
    reasons: List[AdverseActionReason]
    top_positive_features: List[Tuple[str, float]]
    top_negative_features: List[Tuple[str, float]]
    explanation_method: str = "unknown"
    explanation_confidence: float = 0.0
    low_fidelity_warning: bool = False

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "applicant_index": self.applicant_index,
            "prediction": self.prediction,
            "probability": self.probability,
            "reasons": [r.to_dict() for r in self.reasons],
            "top_positive": [{"feature": f, "importance": v} for f, v in self.top_positive_features],
            "top_negative": [{"feature": f, "importance": v} for f, v in self.top_negative_features],
            "explanation_method": self.explanation_method,
            "explanation_confidence": self.explanation_confidence,
        }
        if self.low_fidelity_warning:
            result["low_fidelity_warning"] = True
        return result


class AdverseActionGenerator:
    """
    Generates per-decision adverse action reason codes.

    Regulatory frameworks require that negative decisions include
    specific reasons for denial. For ML models with hundreds of
    features, this requires computing per-applicant feature importances
    and mapping them to standardized FFIEC reason codes.

    References:
        - 12 CFR 1002.9(a)(2) - Statement of specific reasons
        - 12 CFR 1002.9(b)(2) - Statement of action taken
        - CFPB Circular 2023-03 - Adverse action in AI
        - FFIEC Adverse Action Model Form C-1
    """

    def __init__(
        self,
        max_reasons: int = 4,
        feature_mapping: Optional[Dict[str, List[str]]] = None,
        reason_code_library: Optional[Dict[str, str]] = None,
        min_explanation_fidelity: float = 0.0,
    ):
        """
        Args:
            max_reasons: Maximum adverse action reasons per applicant (FFIEC default: 4).
            feature_mapping: Maps feature names to FFIEC reason codes.
            reason_code_library: Reason code descriptions.
            min_explanation_fidelity: Minimum SHAP R² fidelity score (0-1).
                If SHAP fidelity falls below this threshold, explanations
                are flagged as unreliable per CFPB Circular 2023-03.
                Set to 0.85 for production bank deployments; 0.0 disables.
        """
        self.max_reasons = max_reasons
        self.feature_mapping = feature_mapping or FEATURE_TO_REASON_MAP
        self.reason_code_library = reason_code_library or FFIEC_REASON_CODES
        self.min_explanation_fidelity = min_explanation_fidelity

    def generate(
        self,
        model,
        X: pd.DataFrame,
        predictions: np.ndarray,
        probabilities: Optional[np.ndarray] = None,
        denied_only: bool = True,
    ) -> List[ApplicantExplanation]:
        """
        Generate adverse action explanations for denied applicants.

        Args:
            model: Trained model (any framework: sklearn, PyTorch, TensorFlow, XGBoost, etc.)
            X: Feature data
            predictions: Model predictions (0=negative, 1=positive)
            probabilities: Optional prediction probabilities
            denied_only: If True, only generate for denied applicants

        Returns:
            List of ApplicantExplanation for each applicant
        """
        if model is None:
            raise ValueError("model must not be None")
        if not isinstance(X, pd.DataFrame) or len(X) == 0:
            raise ValueError("X must be a non-empty pandas DataFrame")
        if len(predictions) != len(X):
            raise ValueError(
                f"predictions length ({len(predictions)}) must match X rows ({len(X)})"
            )

        adapted = adapt_model(model)
        importances, method, confidence = self._compute_importances(adapted, X)

        if (
            self.min_explanation_fidelity > 0
            and confidence < self.min_explanation_fidelity
        ):
            logger.warning(
                "SHAP explanation fidelity %.3f is below threshold %.3f "
                "(method=%s). Adverse action reasons may not accurately "
                "reflect model decision factors. CFPB Circular 2023-03 "
                "requires validated explanations.",
                confidence, self.min_explanation_fidelity, method,
            )

        if probabilities is None:
            probabilities = adapted.predict_proba(X)
            if probabilities is None:
                probabilities = np.zeros(len(X))

        is_low_fidelity = (
            self.min_explanation_fidelity > 0
            and confidence < self.min_explanation_fidelity
        )

        explanations = []
        preds = np.asarray(predictions).ravel()

        for i in range(len(X)):
            if denied_only and preds[i] == 1:
                continue

            row_importances = importances[i]
            explanation = self._explain_applicant(
                applicant_index=i,
                prediction=int(preds[i]),
                probability=float(probabilities[i]),
                feature_names=list(X.columns),
                feature_values=X.iloc[i].to_dict(),
                importances=row_importances,
                explanation_method=method,
                explanation_confidence=confidence,
            )
            if is_low_fidelity:
                explanation.low_fidelity_warning = True
            explanations.append(explanation)

        return explanations

    def _compute_importances(
        self, adapted, X: pd.DataFrame
    ) -> Tuple[np.ndarray, str, float]:
        """
        Compute per-sample feature importances.

        Tries SHAP first, falls back to global feature_importances_
        (including linear model coef_).
        Returns (importances, method, confidence) where *method* is one
        of ``"shap"``, ``"feature_importances"``, or ``"zeros"`` and
        *confidence* is a fidelity score in [0, 1] measuring how well
        the explanation approximates actual model output (CFPB Circular
        2023-03 requirement).
        """
        try:
            import shap
            explainer = shap.Explainer(adapted._shap_model, X.sample(min(100, len(X)), random_state=42))
            shap_values = explainer(X)
            if hasattr(shap_values, 'values'):
                vals = shap_values.values
                if len(vals.shape) == 3:
                    vals = vals[:, :, 1]
                confidence = self._shap_fidelity(shap_values, adapted, X)
                return vals, "shap", confidence
        except ImportError:
            pass
        except Exception as exc:
            logger.warning(
                "SHAP explanation failed (falling back to feature importances): %s", exc
            )

        fi = adapted.feature_importances_
        if fi is not None:
            try:
                return np.tile(fi, (len(X), 1)), "feature_importances", 0.5
            except Exception as exc:
                logger.warning("Feature importance extraction failed: %s", exc)

        logger.warning(
            "All explanation methods failed — returning zero importances with "
            "confidence 0.0. Adverse action reason codes will not be reliable."
        )
        return np.zeros((len(X), len(X.columns))), "zeros", 0.0

    @staticmethod
    def _shap_fidelity(shap_values, adapted, X: pd.DataFrame) -> float:
        """Compute SHAP explanation fidelity (R² vs actual model output).

        CFPB Circular 2023-03 requires that adverse action explanations
        be validated for accuracy.  This method measures how closely the
        SHAP base value + feature contributions approximates the real
        model predictions.

        Returns a score in [0, 1]; values > 0.95 are generally
        acceptable for regulatory purposes.
        """
        try:
            vals = shap_values.values
            if len(vals.shape) == 3:
                vals = vals[:, :, 1]

            base = shap_values.base_values
            base_arr = np.array(base)
            if base_arr.ndim > 1:
                base_arr = base_arr[:, 1]
            explained = base_arr.ravel() + vals.sum(axis=1)

            actual = adapted.predict_proba(X)
            if actual is None:
                actual = adapted.predict(X).astype(float)

            ss_res = np.sum((actual - explained) ** 2)
            ss_tot = np.sum((actual - actual.mean()) ** 2)
            if ss_tot == 0:
                return 1.0
            r2 = 1.0 - ss_res / ss_tot
            return float(max(0.0, min(1.0, r2)))
        except Exception:
            return 0.0

    def _explain_applicant(
        self,
        applicant_index: int,
        prediction: int,
        probability: float,
        feature_names: List[str],
        feature_values: Dict[str, Any],
        importances: np.ndarray,
        explanation_method: str = "unknown",
        explanation_confidence: float = 0.0,
    ) -> ApplicantExplanation:
        """Generate explanation for a single applicant.

        Handles two importance modes:
        1. SHAP values (signed): negative values indicate denial drivers.
        2. Global feature_importances_ (all non-negative): values represent
           magnitude only. For denied applicants, the highest-importance
           features are the most influential denial factors, so we sort
           descending by importance and treat them as denial drivers.
        """
        has_negative = bool(np.any(importances < 0))

        if has_negative:
            sorted_indices = np.argsort(importances)
            denial_features = [
                (feature_names[i], float(importances[i]))
                for i in sorted_indices
                if importances[i] < 0
            ]
            positive_features = [
                (feature_names[i], float(importances[i]))
                for i in reversed(sorted_indices)
                if importances[i] > 0
            ][:5]
        else:
            sorted_indices = np.argsort(importances)[::-1]
            denial_features = [
                (feature_names[i], float(importances[i]))
                for i in sorted_indices
                if importances[i] > 0
            ]
            positive_features = []

        reasons = []
        used_codes = set()
        rank = 0

        for feat_name, imp_value in denial_features:
            if rank >= self.max_reasons:
                break

            codes = self._map_to_reason_codes(feat_name)
            code = None
            for c in codes:
                if c not in used_codes:
                    code = c
                    break
            if code is None:
                code = self._generate_generic_code(feat_name)
                if code in used_codes:
                    continue

            used_codes.add(code)
            rank += 1

            reason_text = self.reason_code_library.get(code, f"Factor: {feat_name}")
            direction = "negative" if has_negative else "high_importance"

            reasons.append(AdverseActionReason(
                rank=rank,
                reason_code=code,
                reason_text=reason_text,
                feature_name=feat_name,
                feature_value=feature_values.get(feat_name),
                feature_importance=imp_value,
                contribution_direction=direction,
            ))

        return ApplicantExplanation(
            applicant_index=applicant_index,
            prediction=prediction,
            probability=probability,
            reasons=reasons,
            top_positive_features=positive_features,
            top_negative_features=denial_features[:5],
            explanation_method=explanation_method,
            explanation_confidence=explanation_confidence,
        )

    def _map_to_reason_codes(self, feature_name: str) -> List[str]:
        """Map a feature name to FFIEC reason codes."""
        lower = feature_name.lower().replace(" ", "_")

        for pattern, codes in self.feature_mapping.items():
            if pattern in lower:
                return codes

        return []

    @staticmethod
    def _generate_generic_code(feature_name: str) -> str:
        """Generate a deterministic generic reason code for unmapped features.

        Uses a simple FNV-style hash instead of Python's built-in hash()
        which is randomized across interpreter sessions (PYTHONHASHSEED).
        """
        h = int.from_bytes(feature_name.encode("utf-8", errors="replace")[:8].ljust(8, b"\x00"), "little")
        return f"Z{h % 99 + 1:02d}"
