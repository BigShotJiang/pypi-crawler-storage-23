"""
Universal model adapter for multi-framework fairness analysis.

Wraps models from any ML framework (scikit-learn, PyTorch, TensorFlow/Keras,
XGBoost, LightGBM, CatBoost, etc.) behind a uniform interface so the
FairLens engine can call predict / predict_proba without caring about
the underlying framework.

Usage:
    from attestant.fairness.model_adapter import adapt_model

    adapted = adapt_model(my_pytorch_model)
    preds = adapted.predict(X_test)
    probs = adapted.predict_proba(X_test)
"""

import hashlib
import logging
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def _to_numpy(x) -> np.ndarray:
    """Convert any array-like (tensor, list, ndarray) to numpy."""
    if isinstance(x, np.ndarray):
        return x
    if hasattr(x, "detach"):
        return x.detach().cpu().numpy()
    if hasattr(x, "numpy"):
        return x.numpy()
    return np.asarray(x)


def _is_xgb_booster(model) -> bool:
    """Check if model is a native XGBoost Booster (not sklearn wrapper)."""
    cls = type(model).__module__ + "." + type(model).__qualname__
    return "xgboost" in cls and type(model).__name__ == "Booster"


def _is_lgb_booster(model) -> bool:
    """Check if model is a native LightGBM Booster (not sklearn wrapper)."""
    cls = type(model).__module__ + "." + type(model).__qualname__
    return "lightgbm" in cls and type(model).__name__ == "Booster"


def detect_framework(model) -> str:
    """Detect which ML framework produced a model.

    Returns one of: 'sklearn', 'pytorch', 'tensorflow', 'xgboost',
    'xgboost_booster', 'lightgbm', 'lightgbm_booster', 'catboost',
    or 'unknown'.
    """
    if _is_xgb_booster(model):
        return "xgboost_booster"
    if _is_lgb_booster(model):
        return "lightgbm_booster"

    cls_name = type(model).__module__ + "." + type(model).__qualname__

    if "torch" in cls_name or "torch.nn" in cls_name:
        return "pytorch"
    if "tensorflow" in cls_name or "keras" in cls_name:
        return "tensorflow"
    if "xgboost" in cls_name:
        return "xgboost"
    if "lightgbm" in cls_name:
        return "lightgbm"
    if "catboost" in cls_name:
        return "catboost"
    if "sklearn" in cls_name:
        return "sklearn"

    if hasattr(model, "forward") and hasattr(model, "parameters"):
        return "pytorch"
    if hasattr(model, "get_config") and hasattr(model, "compile"):
        return "tensorflow"

    if hasattr(model, "fit") and hasattr(model, "predict"):
        return "sklearn"

    return "unknown"


def compute_model_hash(model) -> str:
    """Compute a stable SHA-256 hash for any model.

    Tries framework-specific serialisation first, then falls back to
    pickle, then to repr().  The goal is a fingerprint that changes
    when model weights change.
    """
    framework = detect_framework(model)

    try:
        if framework == "pytorch":
            import io, torch
            buf = io.BytesIO()
            torch.save(model.state_dict(), buf)
            return hashlib.sha256(buf.getvalue()).hexdigest()

        if framework == "tensorflow":
            weights = model.get_weights()
            blob = b"".join(w.tobytes() for w in weights)
            return hashlib.sha256(blob).hexdigest()

        if framework == "xgboost_booster":
            import io
            buf = io.BytesIO()
            model.save_raw(raw_format="json", fname=buf)
            return hashlib.sha256(buf.getvalue()).hexdigest()

        if framework == "lightgbm_booster":
            raw = model.model_to_string()
            return hashlib.sha256(raw.encode()).hexdigest()
    except Exception:
        pass

    try:
        import pickle
        blob = pickle.dumps(model)
        return hashlib.sha256(blob).hexdigest()
    except Exception:
        return hashlib.sha256(repr(model).encode()).hexdigest()


class ModelAdapter:
    """Uniform interface over any ML model.

    Attributes:
        model: The original unwrapped model.
        framework: Detected framework name.
    """

    def __init__(self, model, *, framework: Optional[str] = None):
        self.model = model
        self.framework = framework or detect_framework(model)

    # ------------------------------------------------------------------
    # predict  →  1-D numpy array of class labels (0/1 for binary)
    # ------------------------------------------------------------------

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        if self.framework == "pytorch":
            return self._predict_pytorch(X, proba=False)

        if self.framework == "tensorflow":
            return self._predict_tensorflow(X, proba=False)

        if self.framework == "xgboost_booster":
            return self._predict_xgb_booster(X, proba=False)

        if self.framework == "lightgbm_booster":
            return self._predict_lgb_booster(X, proba=False)

        out = _to_numpy(self.model.predict(X))
        return out.ravel()

    # ------------------------------------------------------------------
    # predict_proba  →  1-D numpy array of P(positive class)
    #                    Returns None when not available.
    # ------------------------------------------------------------------

    def predict_proba(self, X: pd.DataFrame) -> Optional[np.ndarray]:
        if self.framework == "pytorch":
            return self._predict_pytorch(X, proba=True)

        if self.framework == "tensorflow":
            return self._predict_tensorflow(X, proba=True)

        if self.framework == "xgboost_booster":
            return self._predict_xgb_booster(X, proba=True)

        if self.framework == "lightgbm_booster":
            return self._predict_lgb_booster(X, proba=True)

        if hasattr(self.model, "predict_proba"):
            try:
                proba = _to_numpy(self.model.predict_proba(X))
                if proba.ndim == 2 and proba.shape[1] >= 2:
                    return proba[:, 1]
                return proba.ravel()
            except Exception:
                pass

        return None

    # ------------------------------------------------------------------
    # feature_importances  →  1-D array or None
    # ------------------------------------------------------------------

    @property
    def feature_importances_(self) -> Optional[np.ndarray]:
        if hasattr(self.model, "feature_importances_"):
            return np.asarray(self.model.feature_importances_)
        if hasattr(self.model, "coef_"):
            return np.abs(np.asarray(self.model.coef_).ravel())

        # XGBoost Booster
        if self.framework == "xgboost_booster":
            try:
                scores = self.model.get_score(importance_type="gain")
                if scores:
                    n_features = int(self.model.num_features())
                    fi = np.zeros(n_features)
                    for key, val in scores.items():
                        idx = int(key.replace("f", "")) if key.startswith("f") else 0
                        if idx < n_features:
                            fi[idx] = val
                    return fi
            except Exception:
                pass

        # LightGBM Booster
        if self.framework == "lightgbm_booster":
            try:
                fi = np.array(
                    self.model.feature_importance(importance_type="gain"),
                    dtype=float,
                )
                return fi
            except Exception:
                pass

        return None

    # ------------------------------------------------------------------
    # fit  (delegates to underlying model; raises for frameworks that
    #       don't support the sklearn .fit() API)
    # ------------------------------------------------------------------

    def fit(self, X: pd.DataFrame, y: np.ndarray) -> "ModelAdapter":
        if not hasattr(self.model, "fit"):
            raise TypeError(
                f"{self.framework} models don't support .fit(). "
                f"LDA search requires an sklearn-compatible model_factory."
            )
        self.model.fit(X, y)
        return self

    # ------------------------------------------------------------------
    # hash
    # ------------------------------------------------------------------

    def model_hash(self) -> str:
        return compute_model_hash(self.model)

    # ------------------------------------------------------------------
    # Pass-through for SHAP: shap.Explainer(adapted) needs the
    # underlying model, so we expose it transparently.
    # ------------------------------------------------------------------

    @property
    def _shap_model(self):
        return self.model

    # ------------------------------------------------------------------
    # XGBoost Booster helpers
    # ------------------------------------------------------------------

    def _predict_xgb_booster(
        self, X: pd.DataFrame, *, proba: bool
    ) -> np.ndarray:
        import xgboost as xgb

        dmat = xgb.DMatrix(X)
        raw = self.model.predict(dmat)
        out = np.asarray(raw).ravel()

        if proba:
            return out
        return (out >= 0.5).astype(int)

    # ------------------------------------------------------------------
    # LightGBM Booster helpers
    # ------------------------------------------------------------------

    def _predict_lgb_booster(
        self, X: pd.DataFrame, *, proba: bool
    ) -> np.ndarray:
        raw = self.model.predict(X)
        out = np.asarray(raw).ravel()

        if proba:
            return out
        return (out >= 0.5).astype(int)

    # ------------------------------------------------------------------
    # PyTorch helpers
    # ------------------------------------------------------------------

    def _predict_pytorch(
        self, X: pd.DataFrame, *, proba: bool
    ) -> np.ndarray:
        import torch

        self.model.eval()
        tensor = torch.tensor(X.values, dtype=torch.float32)
        with torch.no_grad():
            raw = self.model(tensor)
        out = _to_numpy(raw).ravel()

        if out.shape[0] != len(X) and raw.ndim == 2 and raw.shape[1] >= 2:
            out_2d = _to_numpy(raw)
            if proba:
                return self._softmax(out_2d)[:, 1]
            return np.argmax(out_2d, axis=1)

        if proba:
            return self._sigmoid(out)
        return (out >= 0.5).astype(int) if np.all((out >= 0) & (out <= 1)) else (out > 0).astype(int)

    # ------------------------------------------------------------------
    # TensorFlow / Keras helpers
    # ------------------------------------------------------------------

    def _predict_tensorflow(
        self, X: pd.DataFrame, *, proba: bool
    ) -> np.ndarray:
        raw = _to_numpy(self.model.predict(X.values, verbose=0))

        if raw.ndim == 2 and raw.shape[1] >= 2:
            if proba:
                return self._softmax(raw)[:, 1]
            return np.argmax(raw, axis=1)

        out = raw.ravel()
        if proba:
            return self._sigmoid(out)
        return (out >= 0.5).astype(int)

    # ------------------------------------------------------------------
    # Activation helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _sigmoid(x: np.ndarray) -> np.ndarray:
        x = np.clip(x, -500, 500)
        return 1.0 / (1.0 + np.exp(-x))

    @staticmethod
    def _softmax(x: np.ndarray) -> np.ndarray:
        e = np.exp(x - x.max(axis=1, keepdims=True))
        return e / e.sum(axis=1, keepdims=True)


def adapt_model(model) -> ModelAdapter:
    """Wrap any ML model in a ModelAdapter.

    If the model is already a ModelAdapter, returns it unchanged.
    """
    if isinstance(model, ModelAdapter):
        return model
    return ModelAdapter(model)
