"""
FairLens disparate impact analysis: computes selection rate ratios
across protected groups using the four-fifths (80%) rule.

Includes statistical significance testing (Fisher's exact test) to
distinguish genuine disparities from small-sample noise — a requirement
for defensible fair lending analysis per OCC examination procedures.
"""

import logging
import math
from dataclasses import dataclass, field
from itertools import combinations
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

FOUR_FIFTHS_THRESHOLD = 0.80

# Minimum group size for reliable statistical testing.
# EEOC Uniform Guidelines recommend 30+ per group; below this,
# Fisher's exact test has low power and results should be flagged.
MIN_RELIABLE_SAMPLE_SIZE = 30


def _fisher_exact_p(a: int, b: int, c: int, d: int) -> float:
    """Two-sided Fisher's exact test p-value for a 2x2 table.

    Layout:
        [[a, b],   # reference group: [positive, negative]
         [c, d]]   # comparison group: [positive, negative]

    Uses scipy if available, falls back to a pure-Python implementation
    for minimal-dependency deployments (e.g. bank air-gapped environments).
    """
    try:
        from scipy.stats import fisher_exact
        _, p = fisher_exact([[a, b], [c, d]], alternative="two-sided")
        return float(p)
    except ImportError:
        pass

    # Pure-Python fallback: hypergeometric distribution
    # P(X=k) = C(a+b,a) * C(c+d,c) / C(n,a+c) where n=a+b+c+d
    n = a + b + c + d
    if n == 0:
        return 1.0

    def _log_comb(n: int, k: int) -> float:
        if k < 0 or k > n:
            return float("-inf")
        if k == 0 or k == n:
            return 0.0
        k = min(k, n - k)
        return sum(math.log(n - i) - math.log(i + 1) for i in range(k))

    r1 = a + b
    r2 = c + d
    c1 = a + c
    c2 = b + d

    log_denom = _log_comb(n, c1)
    log_observed = _log_comb(r1, a) + _log_comb(r2, c) - log_denom
    p_obs = math.exp(log_observed)

    # Sum probabilities of all tables as extreme or more extreme
    p_total = 0.0
    for x in range(max(0, c1 - r2), min(r1, c1) + 1):
        log_p = _log_comb(r1, x) + _log_comb(r2, c1 - x) - log_denom
        p_x = math.exp(log_p)
        if p_x <= p_obs + 1e-12:
            p_total += p_x

    return min(1.0, p_total)


def _ratio_confidence_interval(
    n1: int, s1: int, n2: int, s2: int, confidence: float = 0.95
) -> Tuple[float, float]:
    """Approximate confidence interval for the ratio of two proportions.

    Uses the Katz log method which works well for selection rate ratios.
    Returns (lower, upper) bounds.
    """
    if n1 == 0 or n2 == 0 or s2 == 0:
        return (0.0, float("inf"))

    p1 = s1 / n1
    p2 = s2 / n2

    if p1 == 0:
        return (0.0, 0.0)

    ratio = p1 / p2
    log_ratio = math.log(ratio) if ratio > 0 else float("-inf")

    # Standard error of log(ratio) via delta method
    var = (1 - p1) / (n1 * p1) + (1 - p2) / (n2 * p2) if p1 > 0 and p2 > 0 else float("inf")

    if var == float("inf") or var < 0:
        return (0.0, float("inf"))

    se = math.sqrt(var)

    # Z-score for confidence level
    try:
        from scipy.stats import norm
        z = norm.ppf(1 - (1 - confidence) / 2)
    except ImportError:
        # Standard z-scores for common confidence levels
        z_table = {0.90: 1.645, 0.95: 1.96, 0.99: 2.576}
        z = z_table.get(confidence, 1.96)

    lower = math.exp(log_ratio - z * se) if log_ratio != float("-inf") else 0.0
    upper = math.exp(log_ratio + z * se)
    return (max(0.0, lower), upper)


@dataclass
class GroupMetrics:
    """Metrics for a single protected group."""
    group_name: str
    group_value: str
    total_count: int
    positive_count: int
    negative_count: int
    selection_rate: float
    average_score: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "group": f"{self.group_name}={self.group_value}",
            "total": self.total_count,
            "positive": self.positive_count,
            "negative": self.negative_count,
            "selection_rate": self.selection_rate,
            "average_score": self.average_score,
        }


@dataclass
class DisparateImpactResult:
    """Complete disparate impact analysis for one protected attribute.

    Includes statistical significance testing so bank examiners can
    distinguish genuine disparities from small-sample noise.
    """
    protected_attribute: str
    reference_group: str
    reference_rate: float
    group_metrics: List[GroupMetrics]
    adverse_impact_ratios: Dict[str, float]
    has_disparate_impact: bool
    worst_ratio: float
    worst_group: str
    four_fifths_threshold: float = FOUR_FIFTHS_THRESHOLD
    # Statistical significance fields
    p_values: Dict[str, float] = field(default_factory=dict)
    confidence_intervals: Dict[str, Tuple[float, float]] = field(default_factory=dict)
    statistically_significant: Dict[str, bool] = field(default_factory=dict)
    sample_size_warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "protected_attribute": self.protected_attribute,
            "reference_group": self.reference_group,
            "reference_rate": self.reference_rate,
            "group_metrics": [g.to_dict() for g in self.group_metrics],
            "adverse_impact_ratios": self.adverse_impact_ratios,
            "has_disparate_impact": self.has_disparate_impact,
            "worst_ratio": self.worst_ratio,
            "worst_group": self.worst_group,
            "four_fifths_threshold": self.four_fifths_threshold,
            "p_values": self.p_values,
            "confidence_intervals": {
                k: list(v) for k, v in self.confidence_intervals.items()
            },
            "statistically_significant": self.statistically_significant,
            "sample_size_warnings": self.sample_size_warnings,
        }


@dataclass
class IntersectionalGroup:
    """Metrics for a single intersectional group (e.g. race=Black & gender=Female)."""
    attributes: Dict[str, str]
    total_count: int
    positive_count: int
    selection_rate: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "attributes": self.attributes,
            "total": self.total_count,
            "positive": self.positive_count,
            "selection_rate": self.selection_rate,
        }


@dataclass
class IntersectionalResult:
    """Intersectional disparate impact analysis for a pair of protected attributes.

    CFPB Supervisory Highlights (Jan 2025) and 12 CFR 1002.4(a) require
    analysis across *combinations* of protected characteristics to detect
    compound discrimination invisible to univariate analysis.
    """
    attribute_pair: Tuple[str, str]
    groups: List[IntersectionalGroup]
    reference_group: Dict[str, str]
    reference_rate: float
    worst_group: Dict[str, str]
    worst_ratio: float
    has_disparate_impact: bool
    four_fifths_threshold: float = FOUR_FIFTHS_THRESHOLD
    sample_size_warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "attribute_pair": list(self.attribute_pair),
            "groups": [g.to_dict() for g in self.groups],
            "reference_group": self.reference_group,
            "reference_rate": self.reference_rate,
            "worst_group": self.worst_group,
            "worst_ratio": self.worst_ratio,
            "has_disparate_impact": self.has_disparate_impact,
            "four_fifths_threshold": self.four_fifths_threshold,
            "sample_size_warnings": self.sample_size_warnings,
        }


# ---------------------------------------------------------------------------
# ECOA age range binning (12 CFR 1002.6(b)(2))
# ---------------------------------------------------------------------------

# Standard HMDA/ECOA age ranges used by CFPB and OCC examiners.
# Individual ages (e.g. 21, 22, ..., 68) produce dozens of statistically
# unreliable groups on typical sample sizes.  Binning into these three
# ranges (aligned with Federal Reserve HMDA reporting categories) produces
# groups large enough for Fisher's exact test to have adequate power.
_ECOA_AGE_BINS: List[Tuple[float, float, str]] = [
    (0.0,  39.9, "Under 40"),
    (40.0, 69.9, "40 to 69"),
    (70.0, float("inf"), "70 and older"),
]

# Column-name tokens that signal an age-valued column (word-boundary aware).
# Covers common naming conventions: age, applicant_age, borrower_age,
# customer_age, age_at_application, years_old, dob, date_of_birth,
# birth_date, born, yob (year-of-birth), born_year, year_of_birth,
# age_months, months_old (months-of-age values — auto-converted to years).
_AGE_COLUMN_TOKENS: frozenset = frozenset({
    "age", "dob", "birth", "born", "yob",
    "years",  # covers "years_old", "age_years"
    "yr",     # covers "yr", "age_yr"
    "old",    # covers "years_old", "months_old"
    "month",  # covers "age_months", "months_old" — values checked for 0-1560 range
})

# Birth years must be 4-digit integers in this range.
_BIRTH_YEAR_MIN = 1900
_BIRTH_YEAR_MAX = 2020
_REFERENCE_YEAR = 2026  # fixed reference for reproducible age calculation


def _is_age_column(col_name: str) -> bool:
    """Return True if column name suggests it contains age-related values.

    Splits on non-alpha characters so 'applicant_age' → {'applicant', 'age'}
    and matches 'age' exactly, avoiding false positives like 'mileage' or
    'storage'. Also detects 'yob' (year-of-birth) and 'dob'.
    """
    import re
    tokens = set(re.split(r"[^a-zA-Z]+", col_name.lower()))
    return bool(tokens & _AGE_COLUMN_TOKENS)


def _classify_age_values(col_name: str, values: Any) -> Optional[str]:
    """Detect what format age data is stored in for a named age column.

    Returns one of:
        "direct"      - numeric age in years (e.g. 35, 52)
        "birth_year"  - 4-digit year-of-birth integer (e.g. 1985, 1972)
        "dob"         - date string (e.g. "1985-03-15", "03/15/1985")
        "age_months"  - age expressed in months (e.g. 420 = 35 years × 12)
        None          - column name doesn't suggest age

    Inspects the first up to 50 non-null values for format signals.
    Name matching is a prerequisite — value inspection is the tie-breaker
    between "direct" age, "birth_year", and "age_months".
    """
    import re as _re
    tokens = set(_re.split(r"[^a-zA-Z]+", col_name.lower()))
    if not (tokens & _AGE_COLUMN_TOKENS):
        return None

    try:
        flat = [v for v in values if v is not None][:50]
        if not flat:
            return "direct"

        # Attempt numeric interpretation on a sample
        import pandas as _pd
        numeric = _pd.to_numeric(_pd.Series(flat), errors="coerce").dropna()
        if len(numeric) > 0:
            v_min, v_max = float(numeric.min()), float(numeric.max())
            # Birth year: 4-digit integers in 1900-2020, all values > 130
            if v_min >= _BIRTH_YEAR_MIN and v_max <= _BIRTH_YEAR_MAX and v_min > 130:
                return "birth_year"
            # Direct age: fits in 0-130
            if v_min >= 0 and v_max <= 130:
                return "direct"
            # Age in months: values in 0-1560 (= 130 yrs × 12), name has "month"/"months" token
            if tokens & {"month", "months"} and v_min >= 0 and v_max <= 1560:
                return "age_months"

        # Try date string interpretation
        sample_str = str(flat[0]) if flat else ""
        if _re.search(r'\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{4}', sample_str):
            return "dob"
    except Exception as e:
        logger.warning("Age detection failed for column, defaulting to 'direct': %s", e)

    return "direct"  # fallback for name-matched columns with ambiguous values


def _normalize_age(value: Any, col_type: str) -> Optional[float]:
    """Convert any age representation to a float age in years, or None if invalid.

    Args:
        value:    Raw value from the column.
        col_type: One of "direct", "birth_year", or "dob" (from _classify_age_values).
    """
    import re as _re
    if col_type == "direct":
        try:
            return float(value)
        except (ValueError, TypeError):
            return None

    elif col_type == "birth_year":
        try:
            year = int(float(value))
            if _BIRTH_YEAR_MIN <= year <= _REFERENCE_YEAR:
                return float(_REFERENCE_YEAR - year)
            return None
        except (ValueError, TypeError):
            return None

    elif col_type == "age_months":
        try:
            months = float(value)
            age = months / 12.0
            return age if 0 <= age <= 130 else None
        except (ValueError, TypeError):
            return None

    elif col_type == "dob":
        try:
            from datetime import date, datetime
            s = str(value).strip()
            # ISO: 1985-03-15 or 1985-03-15T00:00:00
            try:
                dt = datetime.fromisoformat(s.split("T")[0])
            except ValueError:
                # YYYY/MM/DD
                m = _re.search(r'(\d{4})[-/](\d{1,2})[-/](\d{1,2})', s)
                if m:
                    dt = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
                else:
                    # MM/DD/YYYY or DD/MM/YYYY — assume MM/DD/YYYY
                    m = _re.search(r'(\d{1,2})[-/](\d{1,2})[-/](\d{4})', s)
                    if m:
                        dt = datetime(int(m.group(3)), int(m.group(1)), int(m.group(2)))
                    else:
                        # Last resort: extract 4-digit year and approximate
                        m = _re.search(r'(\d{4})', s)
                        if m:
                            year = int(m.group(1))
                            if _BIRTH_YEAR_MIN <= year <= _REFERENCE_YEAR:
                                return float(_REFERENCE_YEAR - year)
                        return None
            today = date.today()
            age = today.year - dt.year - ((today.month, today.day) < (dt.month, dt.day))
            return float(age) if 0 <= age <= 130 else None
        except Exception:
            return None

    return None


def _bin_age_ecoa(value: Any) -> Optional[str]:
    """Map a numeric age (in years) to an ECOA-compliant range label.

    Input must already be a numeric age (not a birth year or date string).
    Use _normalize_age() first to convert other formats.
    Returns None if the value is not a valid age.
    """
    try:
        age = float(value)
    except (ValueError, TypeError):
        return None
    if age < 0 or age > 130:
        return None
    for lo, hi, label in _ECOA_AGE_BINS:
        if lo <= age <= hi:
            return label
    return None


class DisparateImpactAnalyzer:
    """
    Computes disparate impact metrics across protected groups.

    Uses the four-fifths (80%) rule: if the selection rate for any
    protected group is less than 80% of the rate for the group with
    the highest selection rate, disparate impact exists.

    For columns whose names indicate they contain age values (e.g. "age",
    "applicant_age", "dob"), values are automatically binned into
    ECOA-compliant ranges (Under 40 / 40 to 69 / 70 and older) per
    12 CFR 1002.6(b)(2) and HMDA reporting conventions.  This prevents
    dozens of single-observation groups that would be statistically
    invalid and produce misleading disparate impact findings.

    References:
        - Griggs v. Duke Power Co., 401 U.S. 424 (1971)
        - EEOC Uniform Guidelines on Employee Selection Procedures (1978)
        - CFPB Supervisory Highlights, January 2025
        - 12 CFR 1002.6(b)(2) — Age in credit scoring
    """

    def __init__(
        self,
        threshold: float = FOUR_FIFTHS_THRESHOLD,
        significance_level: float = 0.05,
    ):
        self.threshold = threshold
        self.significance_level = significance_level

    def analyze(
        self,
        predictions: np.ndarray,
        protected_data: pd.DataFrame,
        protected_columns: List[str],
        positive_label: Any = 1,
        scores: Optional[np.ndarray] = None,
        column_hints: Optional[Dict[str, str]] = None,
    ) -> List[DisparateImpactResult]:
        """
        Compute disparate impact for each protected attribute.

        Args:
            predictions: Binary predictions (1=positive outcome, 0=negative outcome)
            protected_data: DataFrame with protected attribute columns
            protected_columns: Column names to analyze
            positive_label: Value indicating positive outcome
            scores: Optional continuous scores for additional analysis
            column_hints: Optional mapping of column names to their semantic type,
                overriding auto-detection. Supported types:
                    "age"         — numeric age in years
                    "age_months"  — age expressed in months (auto-divided by 12)
                    "birth_year"  — 4-digit year of birth (auto-converted to age)
                    "dob"         — date-of-birth string

        Returns:
            List of DisparateImpactResult for each protected attribute
        """
        results = []
        preds = np.asarray(predictions).ravel()
        is_positive = (preds == positive_label)
        _hints = column_hints or {}

        for col in protected_columns:
            if col not in protected_data.columns:
                logger.warning("Column '%s' not found in protected_data", col)
                continue

            col_type_override = _hints.get(col)
            result = self._analyze_attribute(
                col, protected_data[col].values, is_positive, scores,
                col_type_override=col_type_override,
            )
            results.append(result)

        return results

    def _analyze_attribute(
        self,
        attr_name: str,
        attr_values: np.ndarray,
        is_positive: np.ndarray,
        scores: Optional[np.ndarray],
        col_type_override: Optional[str] = None,
    ) -> DisparateImpactResult:
        # If this column contains age values, bin into ECOA-compliant ranges
        # (Under 40 / 40 to 69 / 70 and older) per 12 CFR 1002.6(b)(2).
        # Individual ages produce dozens of single-observation groups that are
        # statistically invalid; HMDA-standard three-bucket binning gives every
        # group adequate sample size for reliable Fisher's exact testing.
        #
        # Supports four storage formats, auto-detected or client-declared:
        #   "direct"     — numeric age in years (e.g. 35, 52)
        #   "birth_year" — 4-digit year-of-birth (e.g. 1985) → auto-converted
        #   "dob"        — date string (e.g. "1985-03-15")    → auto-converted
        #   "age_months" — age in months (e.g. 420 = 35 yrs)  → auto-converted
        #
        # col_type_override allows clients to explicitly declare the format
        # for any column name, overriding auto-detection entirely.
        _hint_to_col_type = {
            "age": "direct", "age_years": "direct",
            "age_months": "age_months",
            "birth_year": "birth_year",
            "dob": "dob",
        }
        is_age = _is_age_column(attr_name) or (col_type_override is not None)
        if is_age:
            if col_type_override is not None:
                col_type = _hint_to_col_type.get(col_type_override, col_type_override)
            else:
                col_type = _classify_age_values(attr_name, attr_values)
            if col_type is not None:
                normalized = np.array([_normalize_age(v, col_type) for v in attr_values])
                binned = np.array([
                    _bin_age_ecoa(a) if a is not None else None for a in normalized
                ])
            else:
                binned = np.array([_bin_age_ecoa(v) for v in attr_values])
            valid_mask = np.array([b is not None for b in binned])
            if valid_mask.any():
                attr_values = binned[valid_mask]
                is_positive = is_positive[valid_mask]
                if scores is not None:
                    scores = scores[valid_mask]

        groups = pd.Series(attr_values).dropna().unique()
        metrics = []

        for group_val in sorted(groups, key=str):
            mask = (attr_values == group_val)
            total = int(mask.sum())
            if total == 0:
                continue

            positive = int(is_positive[mask].sum())
            negative = total - positive
            rate = positive / total

            avg_score = None
            if scores is not None:
                avg_score = float(np.mean(scores[mask]))

            metrics.append(GroupMetrics(
                group_name=attr_name,
                group_value=str(group_val),
                total_count=total,
                positive_count=positive,
                negative_count=negative,
                selection_rate=rate,
                average_score=avg_score,
            ))

        if not metrics:
            return DisparateImpactResult(
                protected_attribute=attr_name,
                reference_group="N/A",
                reference_rate=0.0,
                group_metrics=[],
                adverse_impact_ratios={},
                has_disparate_impact=False,
                worst_ratio=1.0,
                worst_group="N/A",
            )

        ref_group = max(metrics, key=lambda m: m.selection_rate)
        ref_rate = ref_group.selection_rate

        ratios = {}
        p_values = {}
        confidence_intervals = {}
        stat_significant = {}
        sample_warnings: List[str] = []
        has_di = False
        worst_ratio = 1.0
        worst_group_name = ref_group.group_value

        for m in metrics:
            if m.group_value == ref_group.group_value:
                continue

            if ref_rate > 0:
                ratio = m.selection_rate / ref_rate
            else:
                ratio = 1.0 if m.selection_rate == 0 else float("inf")
                if m.selection_rate > 0:
                    logger.warning(
                        "Reference group has 0%% selection rate but group %s has %.2f — "
                        "ratio set to inf; data may be degenerate",
                        m.group_value, m.selection_rate,
                    )

            ratios[m.group_value] = ratio

            # Statistical significance: Fisher's exact test
            # 2x2 table: [[ref_pos, ref_neg], [group_pos, group_neg]]
            p_val = _fisher_exact_p(
                ref_group.positive_count, ref_group.negative_count,
                m.positive_count, m.negative_count,
            )
            p_values[m.group_value] = p_val
            stat_significant[m.group_value] = p_val < self.significance_level

            # Confidence interval for the selection rate ratio
            ci = _ratio_confidence_interval(
                m.total_count, m.positive_count,
                ref_group.total_count, ref_group.positive_count,
            )
            confidence_intervals[m.group_value] = ci

            # Sample size warning
            if m.total_count < MIN_RELIABLE_SAMPLE_SIZE:
                sample_warnings.append(
                    f"{attr_name}={m.group_value}: n={m.total_count} "
                    f"(below {MIN_RELIABLE_SAMPLE_SIZE}; results may be unreliable)"
                )

            if ratio < self.threshold:
                has_di = True

            if ratio < worst_ratio:
                worst_ratio = ratio
                worst_group_name = m.group_value

        # Warn if the reference group itself is small
        if ref_group.total_count < MIN_RELIABLE_SAMPLE_SIZE:
            sample_warnings.insert(
                0,
                f"Reference group {attr_name}={ref_group.group_value}: "
                f"n={ref_group.total_count} (below {MIN_RELIABLE_SAMPLE_SIZE}; "
                f"all ratios may be unreliable)"
            )

        return DisparateImpactResult(
            protected_attribute=attr_name,
            reference_group=ref_group.group_value,
            reference_rate=ref_rate,
            group_metrics=metrics,
            adverse_impact_ratios=ratios,
            has_disparate_impact=has_di,
            worst_ratio=worst_ratio,
            worst_group=worst_group_name,
            p_values=p_values,
            confidence_intervals=confidence_intervals,
            statistically_significant=stat_significant,
            sample_size_warnings=sample_warnings,
        )

    def analyze_intersectional(
        self,
        predictions: np.ndarray,
        protected_data: pd.DataFrame,
        protected_columns: List[str],
        positive_label: Any = 1,
        min_group_size: int = 10,
    ) -> List[IntersectionalResult]:
        """Analyse intersectional (multi-attribute) disparate impact.

        For every pair of protected columns, compute selection rates for
        each combined group (e.g. race=Black & gender=Female) and apply
        the four-fifths rule to detect compound discrimination.

        Args:
            predictions: Binary predictions.
            protected_data: DataFrame with protected attribute columns.
            protected_columns: Column names to combine pairwise.
            positive_label: Value indicating positive outcome.
            min_group_size: Minimum observations per group to include
                (avoids small-sample noise).

        Returns:
            List of ``IntersectionalResult`` for each attribute pair.
        """
        results: List[IntersectionalResult] = []
        preds = np.asarray(predictions).ravel()
        is_positive = (preds == positive_label)

        for col_a, col_b in combinations(protected_columns, 2):
            if col_a not in protected_data.columns or col_b not in protected_data.columns:
                continue

            vals_a = protected_data[col_a].values
            vals_b = protected_data[col_b].values
            groups: List[IntersectionalGroup] = []

            unique_a = pd.Series(vals_a).dropna().unique()
            unique_b = pd.Series(vals_b).dropna().unique()

            for va in sorted(unique_a, key=str):
                for vb in sorted(unique_b, key=str):
                    mask = (vals_a == va) & (vals_b == vb)
                    total = int(mask.sum())
                    if total < min_group_size:
                        continue
                    positive = int(is_positive[mask].sum())
                    rate = positive / total
                    groups.append(IntersectionalGroup(
                        attributes={col_a: str(va), col_b: str(vb)},
                        total_count=total,
                        positive_count=positive,
                        selection_rate=rate,
                    ))

            if not groups:
                continue

            ref = max(groups, key=lambda g: g.selection_rate)
            ref_rate = ref.selection_rate

            worst_ratio = 1.0
            worst_attrs: Dict[str, str] = ref.attributes
            has_di = False
            int_warnings: List[str] = []

            for g in groups:
                if g.total_count < MIN_RELIABLE_SAMPLE_SIZE:
                    label = " & ".join(f"{k}={v}" for k, v in g.attributes.items())
                    int_warnings.append(
                        f"{label}: n={g.total_count} "
                        f"(below {MIN_RELIABLE_SAMPLE_SIZE}; results may be unreliable)"
                    )
                if g.attributes == ref.attributes:
                    continue
                if ref_rate > 0:
                    ratio = g.selection_rate / ref_rate
                else:
                    ratio = 1.0
                    if g.selection_rate > 0:
                        logger.warning(
                            "Intersectional reference group has 0%% selection rate "
                            "for attrs %s — ratio defaulted to 1.0; data may be degenerate",
                            ref.attributes,
                        )
                if ratio < worst_ratio:
                    worst_ratio = ratio
                    worst_attrs = g.attributes
                if ratio < self.threshold:
                    has_di = True

            results.append(IntersectionalResult(
                attribute_pair=(col_a, col_b),
                groups=groups,
                reference_group=ref.attributes,
                reference_rate=ref_rate,
                worst_group=worst_attrs,
                worst_ratio=worst_ratio,
                has_disparate_impact=has_di,
                four_fifths_threshold=self.threshold,
                sample_size_warnings=int_warnings,
            ))

        return results
