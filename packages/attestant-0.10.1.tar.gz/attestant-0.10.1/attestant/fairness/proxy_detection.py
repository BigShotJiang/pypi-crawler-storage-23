"""
FairLens proxy variable detection: identifies features that correlate
with protected attributes and traces multi-hop causal chains through
feature engineering pipelines.

Uses data-driven statistical analysis including partial correlations,
chi-squared tests of independence, and BFS-based multi-hop path
discovery to build evidence-based causal chains.
"""

import logging
from collections import deque
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

try:
    from scipy.stats import chi2_contingency
    _HAS_SCIPY = True
except ImportError:
    _HAS_SCIPY = False

PROXY_CORRELATION_THRESHOLD = 0.50
HIGH_PROXY_THRESHOLD = 0.70

KNOWN_PROXY_PATTERNS = {
    # Geographic (all industries)
    "zip_code": ["race", "national_origin", "ethnicity"],
    "zipcode": ["race", "national_origin", "ethnicity"],
    "zip": ["race", "national_origin", "ethnicity"],
    "postal_code": ["race", "national_origin", "ethnicity"],
    "census_tract": ["race", "ethnicity"],
    "census_block": ["race", "ethnicity"],
    "neighborhood": ["race", "ethnicity"],
    "county": ["race", "ethnicity"],
    "city": ["race", "ethnicity"],
    "school_district": ["race"],
    # Name-based (all industries)
    "first_name": ["race", "ethnicity", "sex", "national_origin"],
    "last_name": ["race", "ethnicity", "national_origin"],
    "surname": ["race", "ethnicity", "national_origin"],
    "maiden_name": ["sex", "marital_status"],
    "title": ["sex"],
    "salutation": ["sex"],
    # Cultural/linguistic
    "language": ["national_origin", "ethnicity"],
    "church": ["religion"],
    "religion": ["religion"],
    # Hiring-specific
    "school_name": ["race", "national_origin"],
    "university": ["race", "national_origin"],
    "college": ["race", "national_origin"],
    "alma_mater": ["race", "national_origin"],
    "fraternity": ["race", "sex"],
    "sorority": ["race", "sex"],
    "veteran_status": ["age", "disability"],
    "graduation_year": ["age"],
    "years_experience": ["age"],
    # Insurance-specific
    "vehicle_type": ["race", "age"],
    "home_value": ["race", "national_origin"],
    "property_age": ["race"],
    # Housing-specific
    "school_rating": ["race"],
    "walkability_score": ["race"],
    "transit_score": ["race"],
    # Healthcare-specific
    "primary_language": ["national_origin", "ethnicity"],
    "interpreter_needed": ["national_origin"],
    "insurance_type": ["race", "national_origin"],
    # Education-specific
    "legacy_status": ["race"],
    "legacy": ["race"],
    "parent_alumni": ["race"],
    "feeder_school": ["race", "national_origin"],
    "high_school": ["race", "national_origin"],
    # Digital/communications (emerging proxies)
    "email_domain": ["age", "race"],
    "phone_area_code": ["race", "national_origin"],
    "area_code": ["race", "national_origin"],
    "ip_address": ["race", "national_origin"],
    "ip_geolocation": ["race", "national_origin"],
    "browser_language": ["national_origin", "ethnicity"],
    "device_type": ["age", "race"],
    # Financial behaviour
    "bank_name": ["race", "national_origin"],
    "credit_union": ["race"],
    "payment_method": ["age", "race"],
    "checking_account": ["race"],
    # Additional geographic
    "address": ["race", "national_origin"],
    "state": ["race"],
    "region": ["race", "national_origin"],
    "metro_area": ["race", "ethnicity"],
    "msa": ["race", "ethnicity"],
    "fips_code": ["race", "ethnicity"],
    # Socioeconomic
    "household_income": ["race", "national_origin"],
    "median_income": ["race"],
    "poverty_rate": ["race"],
    "homeownership": ["race"],
    "rent_own": ["race"],
}


@dataclass
class CausalChainLink:
    """One link in a proxy causal chain."""
    feature_name: str
    target_attribute: str
    correlation: float
    mechanism: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "feature": self.feature_name,
            "target": self.target_attribute,
            "correlation": self.correlation,
            "mechanism": self.mechanism,
        }


@dataclass
class ProxyResult:
    """Detection result for a single proxy variable."""
    feature_name: str
    protected_attribute: str
    correlation: float
    is_high_risk: bool
    causal_chain: List[CausalChainLink]
    known_proxy: bool
    recommendation: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "feature": self.feature_name,
            "protected_attribute": self.protected_attribute,
            "correlation": self.correlation,
            "is_high_risk": self.is_high_risk,
            "causal_chain": [c.to_dict() for c in self.causal_chain],
            "known_proxy": self.known_proxy,
            "recommendation": self.recommendation,
        }


class ProxyDetector:
    """
    Detects proxy variables that correlate with protected attributes.

    Goes beyond simple correlation: identifies known proxy patterns
    (zip codes -> race), traces multi-hop causal chains through
    data-driven statistical analysis, and computes feature-level
    risk scores.

    Statistical methods:
    - Pearson correlation (numeric-numeric)
    - Eta-squared / correlation ratio (categorical-numeric)
    - Cramer's V (categorical-categorical)
    - Partial correlations controlling for confounders
    - Chi-squared test of independence (when scipy is available)
    - BFS multi-hop path discovery through association graph

    References:
        - CFPB Supervisory Highlights, January 2025
        - CFPB Circular 2023-03 (Adverse Action in AI)
        - 12 CFR 1002.6(a)
    """

    def __init__(
        self,
        correlation_threshold: float = PROXY_CORRELATION_THRESHOLD,
        high_risk_threshold: float = HIGH_PROXY_THRESHOLD,
        regulation_citation: Optional[str] = None,
    ):
        self.correlation_threshold = correlation_threshold
        self.high_risk_threshold = high_risk_threshold
        self.regulation_citation = regulation_citation or "12 CFR 1002.6(a)"

    def detect(
        self,
        features: pd.DataFrame,
        protected_data: pd.DataFrame,
        protected_columns: List[str],
        feature_columns: Optional[List[str]] = None,
    ) -> List[ProxyResult]:
        """
        Detect proxy variables in model features.

        Args:
            features: DataFrame of model features
            protected_data: DataFrame with protected attribute columns
            protected_columns: Names of protected attribute columns
            feature_columns: Specific features to check (default: all)

        Returns:
            List of ProxyResult for detected proxies, sorted by correlation
        """
        if not isinstance(features, pd.DataFrame) or len(features) == 0:
            raise ValueError("features must be a non-empty pandas DataFrame")
        if not isinstance(protected_data, pd.DataFrame) or len(protected_data) == 0:
            raise ValueError("protected_data must be a non-empty pandas DataFrame")
        if len(features) != len(protected_data):
            raise ValueError(
                f"features rows ({len(features)}) must match protected_data rows ({len(protected_data)})"
            )
        if not protected_columns or not isinstance(protected_columns, list):
            raise ValueError("protected_columns must be a non-empty list of column names")

        results = []

        if feature_columns is None:
            feature_columns = [c for c in features.columns if c not in protected_columns]

        numeric_features = self._encode_for_correlation(features, feature_columns)
        numeric_protected = self._encode_for_correlation(protected_data, protected_columns)

        corr_matrix = self._build_correlation_matrix(numeric_features, numeric_protected)

        for feat_col in feature_columns:
            if feat_col not in features.columns:
                continue

            feat_series = features[feat_col]

            known = self._check_known_proxies(feat_col)

            for prot_col in protected_columns:
                if prot_col not in protected_data.columns:
                    continue

                prot_series = protected_data[prot_col]

                corr = self._compute_correlation(feat_series, prot_series)

                if corr >= self.correlation_threshold or feat_col.lower() in KNOWN_PROXY_PATTERNS:
                    is_high = corr >= self.high_risk_threshold
                    is_known = prot_col in known

                    chain = self._build_causal_chain(
                        feat_col, prot_col, corr, is_known,
                        features=features,
                        protected_data=protected_data,
                        feature_columns=feature_columns,
                        protected_columns=protected_columns,
                        corr_matrix=corr_matrix,
                        numeric_features=numeric_features,
                        numeric_protected=numeric_protected,
                    )

                    recommendation = self._generate_recommendation(
                        feat_col, prot_col, corr, is_high, is_known
                    )

                    results.append(ProxyResult(
                        feature_name=feat_col,
                        protected_attribute=prot_col,
                        correlation=corr,
                        is_high_risk=is_high,
                        causal_chain=chain,
                        known_proxy=is_known,
                        recommendation=recommendation,
                    ))

        results.sort(key=lambda r: r.correlation, reverse=True)
        return results

    def _compute_correlation(
        self, feature: pd.Series, protected: pd.Series
    ) -> float:
        """
        Compute correlation between a feature and protected attribute.

        Handles numeric-numeric, categorical-numeric, and categorical-categorical cases.
        """
        feat_clean = feature.copy()
        prot_clean = protected.copy()

        valid = feat_clean.notna() & prot_clean.notna()
        feat_clean = feat_clean[valid]
        prot_clean = prot_clean[valid]

        if len(feat_clean) < 10:
            return 0.0

        feat_is_numeric = pd.api.types.is_numeric_dtype(feat_clean)
        prot_is_numeric = pd.api.types.is_numeric_dtype(prot_clean)

        if feat_is_numeric and prot_is_numeric:
            return abs(float(feat_clean.corr(prot_clean.astype(float))))

        if feat_is_numeric and not prot_is_numeric:
            return self._correlation_ratio(prot_clean, feat_clean)

        if not feat_is_numeric and prot_is_numeric:
            return self._correlation_ratio(feat_clean, prot_clean)

        return self._cramers_v(feat_clean, prot_clean)

    @staticmethod
    def _correlation_ratio(categories: pd.Series, values: pd.Series) -> float:
        """Eta-squared: proportion of variance explained by categories."""
        combined = pd.DataFrame({"cat": categories, "val": values.astype(float)})
        grouped = combined.groupby("cat")["val"]

        if grouped.ngroups < 2:
            return 0.0

        grand_mean = combined["val"].mean()
        group_stats = grouped.agg(["mean", "count"])
        ss_between = float((group_stats["count"] * (group_stats["mean"] - grand_mean) ** 2).sum())
        ss_total = float(((combined["val"] - grand_mean) ** 2).sum())

        if ss_total == 0:
            return 0.0

        eta_sq = ss_between / ss_total
        return float(np.sqrt(eta_sq))

    @staticmethod
    def _cramers_v(x: pd.Series, y: pd.Series) -> float:
        """Cramer's V for categorical-categorical association."""
        ct = pd.crosstab(x, y)
        n = ct.sum().sum()
        if n == 0:
            return 0.0

        chi2 = 0.0
        row_sums = ct.sum(axis=1)
        col_sums = ct.sum(axis=0)
        for i in ct.index:
            for j in ct.columns:
                expected = row_sums[i] * col_sums[j] / n
                if expected > 0:
                    chi2 += (ct.loc[i, j] - expected) ** 2 / expected

        r, k = ct.shape
        denom = n * (min(r, k) - 1)
        if denom == 0:
            return 0.0

        return float(np.sqrt(chi2 / denom))

    def _check_known_proxies(self, feature_name: str) -> List[str]:
        """Check if a feature name matches known proxy patterns."""
        lower = feature_name.lower().strip().replace(" ", "_")
        for pattern, targets in KNOWN_PROXY_PATTERNS.items():
            if pattern in lower:
                return targets
        return []

    # -------------------------------------------------------------------------
    # Data-Driven Causal Chain Analysis
    # -------------------------------------------------------------------------

    @staticmethod
    def _encode_for_correlation(
        df: pd.DataFrame, columns: List[str],
    ) -> pd.DataFrame:
        """Encode all columns to numeric for correlation matrix computation.

        Numeric columns are kept as-is. Categorical/object columns are
        label-encoded (ordinal encoding) so they can participate in the
        Pearson correlation matrix used for partial-correlation and
        multi-hop path discovery.
        """
        encoded = pd.DataFrame(index=df.index)
        for col in columns:
            if col not in df.columns:
                continue
            series = df[col]
            if pd.api.types.is_numeric_dtype(series):
                encoded[col] = series.astype(float)
            else:
                codes = series.astype("category").cat.codes.astype(float)
                codes[codes < 0] = np.nan
                encoded[col] = codes
        return encoded

    @staticmethod
    def _build_correlation_matrix(
        numeric_features: pd.DataFrame,
        numeric_protected: pd.DataFrame,
    ) -> pd.DataFrame:
        """Build a combined correlation matrix across all features and
        protected attributes for use in partial correlation and multi-hop
        path discovery.
        """
        combined = pd.concat(
            [numeric_features, numeric_protected], axis=1
        )
        return combined.corr().fillna(0.0)

    @staticmethod
    def _compute_partial_correlation(
        x_col: str,
        y_col: str,
        controlling: List[str],
        corr_matrix: pd.DataFrame,
    ) -> Tuple[float, str]:
        """Compute partial correlation between x_col and y_col controlling
        for the variables in ``controlling``.

        Uses the inverse of the correlation sub-matrix (precision matrix)
        approach which requires only numpy.linalg.

        Returns:
            (partial_correlation, method_description)
        """
        all_vars = [x_col, y_col] + list(controlling)
        available = [v for v in all_vars if v in corr_matrix.columns]
        if x_col not in available or y_col not in available:
            return 0.0, "variables_missing"

        controlling_available = [v for v in controlling if v in available]
        if not controlling_available:
            raw = corr_matrix.loc[x_col, y_col]
            return abs(float(raw)), "direct_correlation"

        sub_vars = [x_col, y_col] + controlling_available
        sub_vars = list(dict.fromkeys(sub_vars))

        sub_corr = corr_matrix.loc[sub_vars, sub_vars].values.astype(float)

        try:
            precision = np.linalg.inv(sub_corr)
        except np.linalg.LinAlgError:
            try:
                precision = np.linalg.pinv(sub_corr)
            except np.linalg.LinAlgError:
                return 0.0, "singular_matrix"

        i_x = sub_vars.index(x_col)
        i_y = sub_vars.index(y_col)

        denom = np.sqrt(abs(precision[i_x, i_x] * precision[i_y, i_y]))
        if denom < 1e-12:
            return 0.0, "degenerate_precision"

        partial = -precision[i_x, i_y] / denom
        return abs(float(np.clip(partial, -1.0, 1.0))), "partial_correlation"

    @staticmethod
    def _chi_squared_test(
        x: pd.Series, y: pd.Series,
    ) -> Tuple[Optional[float], Optional[float]]:
        """Compute chi-squared statistic and p-value for two categorical
        series. Returns (chi2_stat, p_value) or (None, None) if scipy
        is not available or the test cannot be performed.
        """
        if not _HAS_SCIPY:
            return None, None

        try:
            ct = pd.crosstab(x, y)
            if ct.shape[0] < 2 or ct.shape[1] < 2:
                return None, None
            chi2_stat, p_value, _, _ = chi2_contingency(ct)
            return float(chi2_stat), float(p_value)
        except Exception:
            return None, None

    def _find_multihop_paths(
        self,
        source: str,
        target: str,
        corr_matrix: pd.DataFrame,
        max_hops: int = 3,
        edge_threshold: float = 0.25,
    ) -> List[List[Tuple[str, str, float]]]:
        """Use BFS to find association paths from ``source`` to ``target``
        through intermediate features in the correlation matrix.

        Each path is a list of (from_node, to_node, correlation) tuples.
        Only edges with absolute correlation >= edge_threshold are considered.

        Returns up to 3 shortest paths.
        """
        if source not in corr_matrix.columns or target not in corr_matrix.columns:
            return []

        all_nodes = list(corr_matrix.columns)

        adj: Dict[str, List[Tuple[str, float]]] = {n: [] for n in all_nodes}
        for i, ni in enumerate(all_nodes):
            for j, nj in enumerate(all_nodes):
                if i >= j:
                    continue
                c = abs(float(corr_matrix.loc[ni, nj]))
                if c >= edge_threshold:
                    adj[ni].append((nj, c))
                    adj[nj].append((ni, c))

        found_paths: List[List[Tuple[str, str, float]]] = []
        queue: deque = deque()
        queue.append((source, [source]))
        visited_set_per_path: deque = deque()
        visited_set_per_path.append({source})

        while queue and len(found_paths) < 3:
            current, path = queue.popleft()
            visited = visited_set_per_path.popleft()

            if len(path) > max_hops + 1:
                continue

            for neighbor, edge_corr in adj.get(current, []):
                if neighbor in visited:
                    continue

                new_path = path + [neighbor]
                new_visited = visited | {neighbor}

                if neighbor == target:
                    edge_list = []
                    for k in range(len(new_path) - 1):
                        from_node = new_path[k]
                        to_node = new_path[k + 1]
                        ec = abs(float(corr_matrix.loc[from_node, to_node]))
                        edge_list.append((from_node, to_node, ec))
                    found_paths.append(edge_list)
                elif len(new_path) <= max_hops + 1:
                    queue.append((neighbor, new_path))
                    visited_set_per_path.append(new_visited)

        return found_paths

    def _build_causal_chain(
        self,
        feature: str,
        protected_attr: str,
        correlation: float,
        is_known: bool,
        features: Optional[pd.DataFrame] = None,
        protected_data: Optional[pd.DataFrame] = None,
        feature_columns: Optional[List[str]] = None,
        protected_columns: Optional[List[str]] = None,
        corr_matrix: Optional[pd.DataFrame] = None,
        numeric_features: Optional[pd.DataFrame] = None,
        numeric_protected: Optional[pd.DataFrame] = None,
    ) -> List[CausalChainLink]:
        """Build data-driven causal chain explaining the proxy relationship.

        Performs:
        1. Direct correlation measurement (already computed, passed in).
        2. Partial correlation controlling for other features to determine
           how much of the association is direct vs. confounded.
        3. Chi-squared test of independence for categorical pairs (scipy).
        4. Multi-hop BFS path discovery through the correlation graph.
        5. Known-pattern boosting as a prior when statistical evidence
           also supports the relationship.
        """
        chain: List[CausalChainLink] = []

        has_data = (
            features is not None
            and protected_data is not None
            and corr_matrix is not None
            and feature_columns is not None
            and protected_columns is not None
        )

        if not has_data:
            if is_known:
                lower = feature.lower()
                if any(geo in lower for geo in ("zip", "census", "county", "city", "neighborhood")):
                    chain.append(CausalChainLink(
                        feature_name=feature,
                        target_attribute=protected_attr,
                        correlation=correlation,
                        mechanism=(
                            f"{feature} has {correlation:.2f} correlation with {protected_attr}; "
                            f"known geographic proxy for demographic attributes "
                            f"(residential segregation patterns)"
                        ),
                    ))
                elif any(name in lower for name in ("name", "surname", "first_name", "last_name")):
                    chain.append(CausalChainLink(
                        feature_name=feature,
                        target_attribute=protected_attr,
                        correlation=correlation,
                        mechanism=(
                            f"{feature} has {correlation:.2f} correlation with {protected_attr}; "
                            f"known name-based proxy for {protected_attr} "
                            f"(cultural naming patterns)"
                        ),
                    ))
                else:
                    chain.append(CausalChainLink(
                        feature_name=feature,
                        target_attribute=protected_attr,
                        correlation=correlation,
                        mechanism=(
                            f"{feature} has {correlation:.2f} correlation with {protected_attr}; "
                            f"known proxy pattern for {protected_attr}"
                        ),
                    ))
            else:
                chain.append(CausalChainLink(
                    feature_name=feature,
                    target_attribute=protected_attr,
                    correlation=correlation,
                    mechanism=f"Statistical correlation of {correlation:.2f} detected",
                ))
            return chain

        other_features = [
            c for c in feature_columns
            if c != feature and c in corr_matrix.columns
        ]

        partial_corr = correlation
        partial_method = "direct_correlation"
        if other_features and feature in corr_matrix.columns and protected_attr in corr_matrix.columns:
            partial_corr, partial_method = self._compute_partial_correlation(
                feature, protected_attr, other_features, corr_matrix,
            )

        chi2_stat = None
        chi2_p = None
        feat_is_numeric = pd.api.types.is_numeric_dtype(features[feature])
        prot_is_numeric = pd.api.types.is_numeric_dtype(protected_data[protected_attr])
        if not feat_is_numeric or not prot_is_numeric:
            feat_for_chi2 = features[feature]
            prot_for_chi2 = protected_data[protected_attr]
            if feat_is_numeric:
                feat_for_chi2 = pd.qcut(features[feature], q=5, duplicates="drop")
            if prot_is_numeric:
                prot_for_chi2 = pd.qcut(protected_data[protected_attr], q=5, duplicates="drop")
            chi2_stat, chi2_p = self._chi_squared_test(feat_for_chi2, prot_for_chi2)

        multihop_paths = self._find_multihop_paths(
            feature, protected_attr, corr_matrix,
            max_hops=3,
            edge_threshold=max(0.15, self.correlation_threshold * 0.5),
        )

        mechanism_parts = []
        mechanism_parts.append(
            f"{feature} has {correlation:.2f} correlation with {protected_attr}"
        )

        if partial_method == "partial_correlation" and other_features:
            if partial_corr > 0.05:
                drop = correlation - partial_corr
                if drop > 0.05:
                    mechanism_parts.append(
                        f"partial correlation controlling for "
                        f"{len(other_features)} feature(s) is {partial_corr:.2f} "
                        f"(drop of {drop:.2f}), suggesting partial confounding"
                    )
                else:
                    mechanism_parts.append(
                        f"partial correlation controlling for "
                        f"{len(other_features)} feature(s) is {partial_corr:.2f}, "
                        f"suggesting direct demographic encoding"
                    )
            else:
                mechanism_parts.append(
                    f"partial correlation drops to {partial_corr:.2f} after "
                    f"controlling for {len(other_features)} feature(s), "
                    f"indicating the association is largely confounded"
                )

        if chi2_stat is not None and chi2_p is not None:
            if chi2_p < 0.001:
                mechanism_parts.append(
                    f"chi-squared test: statistic={chi2_stat:.1f}, "
                    f"p<0.001 (highly significant)"
                )
            elif chi2_p < 0.05:
                mechanism_parts.append(
                    f"chi-squared test: statistic={chi2_stat:.1f}, "
                    f"p={chi2_p:.4f} (significant)"
                )

        if is_known:
            lower = feature.lower()
            if any(geo in lower for geo in ("zip", "census", "county", "city", "neighborhood")):
                mechanism_parts.append(
                    "known geographic proxy for demographic attributes "
                    "(residential segregation patterns)"
                )
            elif any(name in lower for name in ("name", "surname", "first_name", "last_name")):
                mechanism_parts.append(
                    f"known name-based proxy for {protected_attr} "
                    f"(cultural naming patterns)"
                )
            else:
                mechanism_parts.append(
                    f"known proxy pattern for {protected_attr}"
                )

        effective_corr = max(correlation, partial_corr)

        chain.append(CausalChainLink(
            feature_name=feature,
            target_attribute=protected_attr,
            correlation=effective_corr,
            mechanism="; ".join(mechanism_parts),
        ))

        if multihop_paths:
            best_path = max(
                multihop_paths,
                key=lambda p: min(edge[2] for edge in p) if p else 0,
            )
            if len(best_path) > 1:
                for from_node, to_node, edge_corr in best_path:
                    if from_node == feature and to_node == protected_attr:
                        continue
                    chain.append(CausalChainLink(
                        feature_name=from_node,
                        target_attribute=to_node,
                        correlation=edge_corr,
                        mechanism=(
                            f"Multi-hop association path: "
                            f"{from_node} -> {to_node} "
                            f"(correlation={edge_corr:.2f})"
                        ),
                    ))

        return chain

    def _generate_recommendation(
        self,
        feature: str,
        protected_attr: str,
        correlation: float,
        is_high_risk: bool,
        is_known: bool,
    ) -> str:
        if is_high_risk:
            return (
                f"CRITICAL: Remove '{feature}' from the model. "
                f"Correlation of {correlation:.2f} with {protected_attr} "
                f"creates substantial proxy discrimination risk. "
                f"{self.regulation_citation}."
            )
        if is_known:
            return (
                f"HIGH: '{feature}' is a known proxy for {protected_attr}. "
                f"Consider removing or testing a Less Discriminatory Alternative. "
                f"{self.regulation_citation}."
            )
        return (
            f"MEDIUM: '{feature}' correlates {correlation:.2f} with {protected_attr}. "
            f"Monitor and test for disparate impact."
        )
