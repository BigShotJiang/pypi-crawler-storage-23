"""
Storage backends for Attestant provenance.

PostgreSQLStorage uses batch inserts and connection pooling for performance.
The psycopg2 dependency is imported lazily so that modules using only the
abstract base class (e.g., SQLiteStorage) do not require psycopg2.
"""

from abc import ABC, abstractmethod
from collections import deque
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import json
import logging

logger = logging.getLogger(__name__)


@dataclass
class StoredNode:
    """Data class for storing a DAG node."""
    fingerprint: int
    node_type: str
    operation: str
    table_name: Optional[str] = None
    column_name: Optional[str] = None
    pair_id: Optional[int] = None
    is_protected: bool = False
    entity_hash: Optional[int] = None
    chain_hash: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = None
    pipeline_id: Optional[int] = None


@dataclass
class StoredEdge:
    """Data class for storing a DAG edge."""
    parent_fingerprint: int
    child_fingerprint: int
    input_position: int = 0


@dataclass
class StoredRowValue:
    """Data class for storing a per-row value at a DAG node."""
    pipeline_id: int
    row_index: int
    fingerprint: int
    node_operation: str
    value: Optional[float] = None
    column_name: Optional[str] = None
    tenant_id: Optional[str] = None
    text_value: Optional[str] = None


class StorageBackend(ABC):
    """Abstract interface for provenance storage.

    Implementations must support the full provenance lifecycle:
    1. Pipeline creation and completion
    2. DAG storage (nodes + edges)
    3. Source registry
    4. Per-row result storage (audit trail)
    5. Query methods for audit/dashboard
    """

    @abstractmethod
    def connect(self) -> None:
        """Establish connection to storage."""
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """Close connection to storage."""
        pass

    def __enter__(self):
        """Context manager: connect on entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager: disconnect on exit."""
        self.disconnect()
        return False

    # -- Pipeline lifecycle --

    @abstractmethod
    def create_pipeline(self, pipeline_name: str,
                        config: Optional[Dict[str, Any]] = None,
                        git_commit: Optional[str] = None,
                        tenant_id: Optional[str] = None) -> int:
        """Create a pipeline execution record. Returns pipeline_id."""
        pass

    @abstractmethod
    def complete_pipeline(self, pipeline_id: int,
                          status: str = 'completed') -> None:
        """Mark a pipeline as completed or failed."""
        pass

    # -- DAG storage --

    @abstractmethod
    def store_nodes(self, nodes: List[StoredNode]) -> None:
        """Store multiple DAG nodes in a batch."""
        pass

    @abstractmethod
    def store_edges(self, edges: List[StoredEdge]) -> None:
        """Store multiple DAG edges in a batch (resolves fingerprints)."""
        pass

    @abstractmethod
    def store_edges_resolved(self,
                             edges: List[Tuple[int, int, int]]) -> None:
        """Store edges with already-resolved node IDs.

        Args:
            edges: List of (parent_node_id, child_node_id, input_position).
        """
        pass

    @abstractmethod
    def register_source(self, pair_id: int, table: str, column: str,
                       is_protected: bool = False) -> None:
        """Register a source (table, column) pair."""
        pass

    # -- Queries --

    @abstractmethod
    def get_node_by_fingerprint(self, fingerprint: int,
                                pipeline_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
        """Retrieve a node by its fingerprint."""
        pass

    @abstractmethod
    def get_edges_for_node(self, node_id: int) -> List[Dict[str, Any]]:
        """Get all edges where this node is the child."""
        pass

    @abstractmethod
    def get_fingerprint_node_map(self,
                                 pipeline_id: int) -> Dict[int, int]:
        """Return {fingerprint: node_id} for all nodes in a pipeline."""
        pass

    # -- Per-row values (value-level lineage) --

    @abstractmethod
    def store_row_values(self, values: List['StoredRowValue']) -> None:
        """Store per-row values at DAG nodes for value-level lineage."""
        pass

    @abstractmethod
    def get_row_values(self, pipeline_id: int,
                       row_index: int) -> List[Dict[str, Any]]:
        """Retrieve all values for a specific row in a pipeline."""
        pass

    # -- Per-row results (audit trail) --

    @abstractmethod
    def store_results(self, pipeline_id: int,
                      results: List[tuple]) -> None:
        """Store per-row output fingerprints for audit.

        Args:
            pipeline_id: Pipeline execution ID.
            results: List of (row_key, output_name, fingerprint,
                     output_value, input_hash) tuples.
        """
        pass

    @abstractmethod
    def get_results_for_row(self, row_key: str,
                            pipeline_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """Look up provenance results for a specific row."""
        pass

    # -- Integrity verification --

    def verify_dag_integrity(self, pipeline_id: int) -> Dict[str, Any]:
        """Verify the integrity of a stored DAG for audit trail trust.

        Checks:
        1. All edges reference existing nodes
        2. No orphaned nodes (nodes with no edges that aren't sources)
        3. DAG is acyclic
        4. Fingerprints are unique within the pipeline
        5. All source nodes have registered source info

        Returns:
            Dictionary with 'valid' (bool), 'checks' (dict of check results),
            and 'errors' (list of error descriptions).

        This is critical for bank examinations where regulators need to
        trust that the audit trail is complete and internally consistent.
        """
        errors: List[str] = []
        checks: Dict[str, bool] = {}

        fp_map = self.get_fingerprint_node_map(pipeline_id)
        if not fp_map:
            return {
                "valid": False,
                "checks": {},
                "errors": ["No nodes found for pipeline"],
                "pipeline_id": pipeline_id,
            }

        node_ids = set(fp_map.values())

        # Check 1: Fingerprint uniqueness
        checks["fingerprint_uniqueness"] = len(fp_map) == len(node_ids)
        if not checks["fingerprint_uniqueness"]:
            errors.append(
                f"Duplicate fingerprints detected: {len(fp_map)} fingerprints "
                f"map to {len(node_ids)} node IDs"
            )

        # Check 2: Edge referential integrity
        all_edges_valid = True
        edge_count = 0
        nodes_with_parents: set = set()
        nodes_with_children: set = set()
        adjacency: Dict[int, List[int]] = {nid: [] for nid in node_ids}

        for node_id in node_ids:
            parent_edges = self.get_edges_for_node(node_id)
            for edge in parent_edges:
                edge_count += 1
                parent_id = edge["parent_node_id"]
                nodes_with_parents.add(node_id)
                nodes_with_children.add(parent_id)
                if parent_id not in node_ids:
                    all_edges_valid = False
                    errors.append(
                        f"Edge references parent node {parent_id} not in pipeline"
                    )
                else:
                    adjacency[parent_id].append(node_id)

        checks["edge_referential_integrity"] = all_edges_valid

        # Check 3: Acyclicity (topological sort via Kahn's algorithm)
        in_degree: Dict[int, int] = {nid: 0 for nid in node_ids}
        for nid in node_ids:
            for child in adjacency[nid]:
                if child in in_degree:
                    in_degree[child] += 1

        queue = deque(nid for nid, deg in in_degree.items() if deg == 0)
        sorted_count = 0
        while queue:
            current = queue.popleft()
            sorted_count += 1
            for child in adjacency[current]:
                if child in in_degree:
                    in_degree[child] -= 1
                    if in_degree[child] == 0:
                        queue.append(child)

        checks["acyclicity"] = sorted_count == len(node_ids)
        if not checks["acyclicity"]:
            errors.append(
                f"Cycle detected in DAG: only {sorted_count} of "
                f"{len(node_ids)} nodes are reachable via topological sort"
            )

        # Check 4: Source node completeness
        source_nodes = node_ids - nodes_with_parents
        leaf_nodes = node_ids - nodes_with_children

        checks["has_source_nodes"] = len(source_nodes) > 0
        if not checks["has_source_nodes"]:
            errors.append("No source nodes found (all nodes have parents)")

        checks["has_leaf_nodes"] = len(leaf_nodes) > 0
        if not checks["has_leaf_nodes"]:
            errors.append("No leaf nodes found (all nodes have children)")

        valid = all(checks.values())

        return {
            "valid": valid,
            "checks": checks,
            "errors": errors,
            "pipeline_id": pipeline_id,
            "stats": {
                "node_count": len(node_ids),
                "edge_count": edge_count,
                "source_nodes": len(source_nodes),
                "leaf_nodes": len(leaf_nodes),
            },
        }

    # -- Dashboard / stats --

    @abstractmethod
    def get_stats(self) -> Dict[str, Any]:
        """Return counts of nodes, edges, sources, results, etc."""
        pass


class PostgreSQLStorage(StorageBackend):
    """
    PostgreSQL storage backend with connection pooling and batch inserts.

    Requires the ``psycopg2`` package. Install with::

        pip install psycopg2-binary

    Features:
    - Connection pooling (min 2, max 10 connections)
    - Batch inserts (100-1000 nodes per transaction)
    - Prepared statements for efficiency
    - Automatic retry on connection errors
    """

    def __init__(self, connection_string: str, min_conn: int = 2, max_conn: int = 10):
        """
        Initialize PostgreSQL storage.

        Args:
            connection_string: PostgreSQL connection string
            min_conn: Minimum connections in pool
            max_conn: Maximum connections in pool

        Raises:
            ImportError: If psycopg2 is not installed.
        """
        try:
            import psycopg2  # noqa: F401
        except ImportError:
            raise ImportError(
                "PostgreSQLStorage requires psycopg2. "
                "Install with: pip install psycopg2-binary"
            )
        self.connection_string = connection_string
        self.min_conn = min_conn
        self.max_conn = max_conn
        self.pool = None  # type: ignore[assignment]

    def connect(self) -> None:
        """Create connection pool."""
        from psycopg2 import pool as pg_pool
        if self.pool is None:
            self.pool = pg_pool.ThreadedConnectionPool(
                self.min_conn,
                self.max_conn,
                self.connection_string
            )

    def disconnect(self) -> None:
        """Close all connections in pool."""
        if self.pool is not None:
            self.pool.closeall()
            self.pool = None

    def _get_conn(self):
        """Get a connection from the pool."""
        if self.pool is None:
            self.connect()
        return self.pool.getconn()

    def _put_conn(self, conn):
        """Return a connection to the pool."""
        if self.pool is not None:
            self.pool.putconn(conn)

    def store_nodes(self, nodes: List[StoredNode]) -> None:
        """
        Store multiple DAG nodes using batch insert.

        Uses execute_batch for efficiency (5-10x faster than individual inserts).
        """
        from psycopg2.extras import execute_batch

        if not nodes:
            return

        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                execute_batch(
                    cur,
                    """
                    INSERT INTO dag_nodes (
                        fingerprint, node_type, operation,
                        table_name, column_name, pair_id, is_protected,
                        entity_hash, chain_hash, metadata, pipeline_id
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (fingerprint, pipeline_id) DO NOTHING
                    """,
                    [
                        (
                            node.fingerprint,
                            node.node_type,
                            node.operation,
                            node.table_name,
                            node.column_name,
                            node.pair_id,
                            node.is_protected,
                            node.entity_hash,
                            node.chain_hash,
                            json.dumps(node.metadata) if node.metadata else None,
                            node.pipeline_id,
                        )
                        for node in nodes
                    ],
                    page_size=100,
                )
                conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._put_conn(conn)

    def store_edges(self, edges: List[StoredEdge]) -> None:
        """
        Store multiple DAG edges using batch insert.
        """
        from psycopg2.extras import execute_batch

        if not edges:
            return

        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                execute_batch(
                    cur,
                    """
                    INSERT INTO dag_edges (parent_node_id, child_node_id, input_position)
                    SELECT p.node_id, c.node_id, %s
                    FROM dag_nodes p, dag_nodes c
                    WHERE p.fingerprint = %s AND c.fingerprint = %s
                    ON CONFLICT DO NOTHING
                    """,
                    [
                        (edge.input_position, edge.parent_fingerprint, edge.child_fingerprint)
                        for edge in edges
                    ],
                    page_size=100,
                )
                conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._put_conn(conn)

    def register_source(self, pair_id: int, table: str, column: str,
                       is_protected: bool = False) -> None:
        """Register a source pair in the registry."""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO source_registry (pair_id, table_name, column_name, is_protected)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (pair_id) DO UPDATE
                    SET table_name = EXCLUDED.table_name,
                        column_name = EXCLUDED.column_name,
                        is_protected = EXCLUDED.is_protected
                    """,
                    (pair_id, table, column, is_protected)
                )
                conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._put_conn(conn)

    def get_node_by_fingerprint(self, fingerprint: int,
                                pipeline_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
        """
        Retrieve a node by fingerprint.

        If pipeline_id is None, returns the most recent node with this fingerprint.
        """
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                if pipeline_id is not None:
                    cur.execute(
                        """
                        SELECT node_id, fingerprint, node_type, operation,
                               table_name, column_name, pair_id, is_protected,
                               entity_hash, chain_hash, metadata
                        FROM dag_nodes
                        WHERE fingerprint = %s AND pipeline_id = %s
                        """,
                        (fingerprint, pipeline_id)
                    )
                else:
                    cur.execute(
                        """
                        SELECT node_id, fingerprint, node_type, operation,
                               table_name, column_name, pair_id, is_protected,
                               entity_hash, chain_hash, metadata
                        FROM dag_nodes
                        WHERE fingerprint = %s
                        ORDER BY created_at DESC
                        LIMIT 1
                        """,
                        (fingerprint,)
                    )

                row = cur.fetchone()
                if row is None:
                    return None

                return {
                    'node_id': row[0],
                    'fingerprint': row[1],
                    'node_type': row[2],
                    'operation': row[3],
                    'table_name': row[4],
                    'column_name': row[5],
                    'pair_id': row[6],
                    'is_protected': row[7],
                    'entity_hash': row[8],
                    'chain_hash': row[9],
                    'metadata': json.loads(row[10]) if row[10] else None,
                }
        finally:
            self._put_conn(conn)

    def get_edges_for_node(self, node_id: int) -> List[Dict[str, Any]]:
        """Get all parent edges for a node (inputs to this computation)."""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT e.parent_node_id, e.input_position, n.fingerprint
                    FROM dag_edges e
                    JOIN dag_nodes n ON e.parent_node_id = n.node_id
                    WHERE e.child_node_id = %s
                    ORDER BY e.input_position
                    """,
                    (node_id,)
                )
                return [
                    {
                        'parent_node_id': row[0],
                        'input_position': row[1],
                        'parent_fingerprint': row[2],
                    }
                    for row in cur.fetchall()
                ]
        finally:
            self._put_conn(conn)

    def get_source_info(self, pair_id: int) -> Optional[Tuple[str, str, bool]]:
        """Get (table, column, is_protected) for a pair_id."""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT table_name, column_name, is_protected FROM source_registry WHERE pair_id = %s",
                    (pair_id,)
                )
                row = cur.fetchone()
                if row:
                    return (row[0], row[1], row[2])
                return None
        finally:
            self._put_conn(conn)

    def create_pipeline(self, pipeline_name: str, config: Optional[Dict[str, Any]] = None,
                       git_commit: Optional[str] = None,
                       tenant_id: Optional[str] = None) -> int:
        """
        Create a new pipeline execution record.

        Args:
            pipeline_name: Human-readable pipeline name.
            config: Optional pipeline configuration dict.
            git_commit: Optional git commit hash for reproducibility.
            tenant_id: Optional tenant identifier for multi-tenancy.

        Returns:
            pipeline_id for linking DAG nodes to this execution.
        """
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO pipeline_metadata (pipeline_name, config, git_commit, status, tenant_id)
                    VALUES (%s, %s, %s, 'running', %s)
                    RETURNING pipeline_id
                    """,
                    (pipeline_name, json.dumps(config) if config else None, git_commit, tenant_id)
                )
                pipeline_id = cur.fetchone()[0]
                conn.commit()
                return pipeline_id
        except Exception:
            conn.rollback()
            raise
        finally:
            self._put_conn(conn)

    def complete_pipeline(self, pipeline_id: int, status: str = 'completed') -> None:
        """Mark a pipeline execution as completed or failed."""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE pipeline_metadata SET status = %s WHERE pipeline_id = %s",
                    (status, pipeline_id)
                )
                conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._put_conn(conn)

    def store_edges_resolved(self, edges: List[Tuple[int, int, int]]) -> None:
        """Store edges with already-resolved node IDs.

        Skips fingerprint resolution -- caller has already mapped fingerprints
        to node_ids.

        Args:
            edges: List of (parent_node_id, child_node_id, input_position).
        """
        from psycopg2.extras import execute_batch

        if not edges:
            return

        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                execute_batch(
                    cur,
                    """
                    INSERT INTO dag_edges (parent_node_id, child_node_id, input_position)
                    VALUES (%s, %s, %s)
                    ON CONFLICT DO NOTHING
                    """,
                    edges,
                    page_size=100,
                )
                conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._put_conn(conn)

    def get_fingerprint_node_map(self, pipeline_id: int) -> Dict[int, int]:
        """Return {fingerprint: node_id} for all nodes in a pipeline.

        Used to resolve fingerprints to node_ids in bulk before calling
        store_edges_resolved.
        """
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT fingerprint, node_id FROM dag_nodes WHERE pipeline_id = %s",
                    (pipeline_id,)
                )
                return {row[0]: row[1] for row in cur.fetchall()}
        finally:
            self._put_conn(conn)

    def store_row_values(self, values: List[StoredRowValue]) -> None:
        """Store per-row values at DAG nodes."""
        from psycopg2.extras import execute_batch

        if not values:
            return

        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                execute_batch(
                    cur,
                    """
                    INSERT INTO row_values
                        (pipeline_id, row_index, fingerprint, node_operation,
                         column_name, value, text_value, tenant_id)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    [
                        (
                            v.pipeline_id, v.row_index, v.fingerprint,
                            v.node_operation, v.column_name, v.value,
                            v.text_value, v.tenant_id,
                        )
                        for v in values
                    ],
                    page_size=500,
                )
                conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._put_conn(conn)

    def get_row_values(self, pipeline_id: int,
                       row_index: int) -> List[Dict[str, Any]]:
        """Retrieve all values for a specific row in a pipeline."""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT fingerprint, node_operation, column_name, value, text_value
                    FROM row_values
                    WHERE pipeline_id = %s AND row_index = %s
                    ORDER BY value_id
                    """,
                    (pipeline_id, row_index),
                )
                return [
                    {
                        'fingerprint': row[0],
                        'node_operation': row[1],
                        'column_name': row[2],
                        'value': row[3] if row[3] is not None else row[4],
                    }
                    for row in cur.fetchall()
                ]
        finally:
            self._put_conn(conn)

    def store_results(self, pipeline_id: int,
                      results: List[tuple]) -> None:
        """Store per-row pipeline output fingerprints for audit.

        This is the audit trail that links a specific person/row to the
        provenance DAG. Each row records: for row_key X, output Y was
        produced with fingerprint Z (which maps to a DAG node).

        Args:
            pipeline_id: The pipeline execution that produced these results.
            results: List of (row_key, output_name, fingerprint, output_value,
                     input_hash) tuples. row_key is the business identifier
                     (e.g. applicant_id). input_hash is a SHA-256 of the
                     source row values used to produce this output.
        """
        from psycopg2.extras import execute_batch

        if not results:
            return

        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                execute_batch(
                    cur,
                    """
                    INSERT INTO pipeline_results
                        (pipeline_id, row_key, output_name, fingerprint, output_value, input_hash)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """,
                    [(pipeline_id, *row) for row in results],
                    page_size=100,
                )
                conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._put_conn(conn)

    def get_results_for_row(self, row_key: str,
                            pipeline_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """Look up all provenance results for a specific row (e.g. applicant).

        Returns each output produced for this row, its fingerprint, and the
        DAG node that produced it via a LEFT JOIN on dag_nodes.
        """
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                if pipeline_id is not None:
                    cur.execute(
                        """
                        SELECT r.output_name, r.fingerprint, r.output_value,
                               r.pipeline_id, n.node_id, n.node_type, n.operation,
                               n.is_protected
                        FROM pipeline_results r
                        LEFT JOIN dag_nodes n
                            ON r.fingerprint = n.fingerprint AND r.pipeline_id = n.pipeline_id
                        WHERE r.row_key = %s AND r.pipeline_id = %s
                        ORDER BY r.output_name
                        """,
                        (row_key, pipeline_id)
                    )
                else:
                    cur.execute(
                        """
                        SELECT r.output_name, r.fingerprint, r.output_value,
                               r.pipeline_id, n.node_id, n.node_type, n.operation,
                               n.is_protected
                        FROM pipeline_results r
                        LEFT JOIN dag_nodes n
                            ON r.fingerprint = n.fingerprint AND r.pipeline_id = n.pipeline_id
                        WHERE r.row_key = %s
                        ORDER BY r.pipeline_id DESC, r.output_name
                        """,
                        (row_key,)
                    )

                return [
                    {
                        'output_name': row[0],
                        'fingerprint': row[1],
                        'output_value': row[2],
                        'pipeline_id': row[3],
                        'node_id': row[4],
                        'node_type': row[5],
                        'operation': row[6],
                        'is_protected': row[7],
                    }
                    for row in cur.fetchall()
                ]
        finally:
            self._put_conn(conn)

    def get_stats(self) -> Dict[str, Any]:
        """Return counts of nodes, edges, sources, results, pipelines, etc.

        Used by the dashboard to show database health and size.
        """
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) FROM dag_nodes")
                node_count = cur.fetchone()[0]

                cur.execute("SELECT COUNT(*) FROM dag_edges")
                edge_count = cur.fetchone()[0]

                cur.execute("SELECT COUNT(*) FROM source_registry")
                source_count = cur.fetchone()[0]

                cur.execute("SELECT COUNT(*) FROM dag_nodes WHERE is_protected = TRUE")
                protected_count = cur.fetchone()[0]

                cur.execute("SELECT COUNT(*) FROM pipeline_metadata")
                pipeline_count = cur.fetchone()[0]

                cur.execute("SELECT COUNT(*) FROM pipeline_results")
                result_count = cur.fetchone()[0]

                try:
                    cur.execute("SELECT COUNT(*) FROM row_values")
                    row_value_count = cur.fetchone()[0]
                except Exception:
                    row_value_count = 0

                return {
                    'nodes': node_count,
                    'edges': edge_count,
                    'sources': source_count,
                    'protected_nodes': protected_count,
                    'pipelines': pipeline_count,
                    'results': result_count,
                    'row_values': row_value_count,
                }
        finally:
            self._put_conn(conn)
