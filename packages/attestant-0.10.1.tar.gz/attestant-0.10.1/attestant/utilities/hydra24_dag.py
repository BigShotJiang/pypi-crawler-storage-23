"""
HYDRA-24 DAG: Full Computation Graph Reconstruction

Extends HYDRA-24 Enhanced with a complete operation log that enables
reconstruction of the full computation DAG from any result value.

The 24-bit provenance serves as a tamper-proof fingerprint, while the
DAG registry provides full lineage reconstruction.

Key concepts:
- Every computation creates a node in the DAG
- Source data (raw columns) are leaf nodes with no inputs
- Operations (add, mul, merge, etc.) create internal nodes
- Any result can be traced back to its complete derivation

Usage:
    from attestant.hydra24_dag import DAGTracker, wrap_dataframe_dag

    tracker = DAGTracker()
    df = wrap_dataframe_dag(raw_df, tracker, "users.csv")

    result = df['income'] / df['debt']

    # Reconstruct full computation DAG
    dag = tracker.get_dag_for_series(result)

    # Export to various formats
    tracker.to_graphviz(result)
    tracker.to_json(result)
"""

from dataclasses import dataclass, field
from typing import Dict, Set, List, Tuple, Optional, Any, FrozenSet
from enum import Enum, auto
import json
import logging
import threading
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

from .hydra24_simple import (
    ProvenanceTracker, TrackedSeries, TrackedDataFrame,
    OpCode, MAX_PAIRS,
    MODE_01_ENTITY_BITS, MODE_01_CHAIN_BITS,
    _hash_entity,
)


# =============================================================================
# DAG Node Types
# =============================================================================

class NodeType(Enum):
    """Types of nodes in the computation DAG."""
    SOURCE = auto()      # Raw data from a table/column
    CONSTANT = auto()    # Literal constant value
    UNARY = auto()       # Single-input operation (neg, clip, etc.)
    BINARY = auto()      # Two-input operation (add, sub, mul, div)
    AGGREGATE = auto()   # Aggregation (sum, mean, etc.)
    MERGE = auto()       # DataFrame merge/join
    FILTER = auto()      # Row filtering
    CUSTOM = auto()      # Custom operation


@dataclass
class DAGNode:
    """
    A node in the computation DAG.

    Each node represents either:
    - A source column (leaf node)
    - A computation step (internal node)
    """
    node_id: int
    node_type: NodeType
    operation: str                    # Operation name or column name for sources
    inputs: List[int]                 # Node IDs of inputs (empty for sources)
    provenance: int                   # 24-bit HYDRA provenance fingerprint
    metadata: Dict[str, Any] = field(default_factory=dict)

    # For source nodes
    table: Optional[str] = None
    column: Optional[str] = None
    pair_id: Optional[int] = None
    is_protected: bool = False

    # Computed properties
    @property
    def is_source(self) -> bool:
        return self.node_type == NodeType.SOURCE

    @property
    def is_leaf(self) -> bool:
        return len(self.inputs) == 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        if self.table and self.column:
            name = f"{self.table}.{self.column}"
        elif self.operation:
            name = self.operation
        else:
            name = f"node_{self.node_id}"
        return {
            'id': self.node_id,
            'name': name,
            'type': self.node_type.name,
            'operation': self.operation,
            'inputs': self.inputs,
            'provenance': f"0x{self.provenance:06X}",
            'table': self.table,
            'column': self.column,
            'pair_id': self.pair_id,
            'is_protected': self.is_protected,
            'metadata': self.metadata,
        }


@dataclass
class DAGEdge:
    """An edge in the computation DAG."""
    source_id: int      # Input node
    target_id: int      # Output node
    input_index: int    # Which input slot (0 for left, 1 for right in binary ops)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'source': self.source_id,
            'target': self.target_id,
            'input_index': self.input_index,
        }


@dataclass
class ComputationDAG:
    """
    Complete computation graph for a result value.

    Contains all nodes and edges needed to reconstruct
    how a value was derived from source data.
    """
    root_id: int                          # The result node
    nodes: Dict[int, DAGNode]             # All nodes in the DAG
    edges: List[DAGEdge]                  # All edges

    @property
    def depth(self) -> int:
        """Maximum depth from root to any leaf."""
        def node_depth(nid: int, memo: Dict[int, int]) -> int:
            if nid in memo:
                return memo[nid]
            node = self.nodes[nid]
            if node.is_leaf:
                memo[nid] = 0
                return 0
            max_input_depth = max(node_depth(i, memo) for i in node.inputs)
            memo[nid] = max_input_depth + 1
            return memo[nid]

        return node_depth(self.root_id, {})

    @property
    def source_nodes(self) -> List[DAGNode]:
        """All source (leaf) nodes."""
        return [n for n in self.nodes.values() if n.is_source]

    @property
    def protected_sources(self) -> List[DAGNode]:
        """Source nodes from protected tables."""
        return [n for n in self.source_nodes if n.is_protected]

    @property
    def has_protected(self) -> bool:
        """Whether any protected data was used."""
        return len(self.protected_sources) > 0

    @property
    def operation_counts(self) -> Dict[str, int]:
        """Count of each operation type."""
        counts: Dict[str, int] = {}
        for node in self.nodes.values():
            op = node.operation
            counts[op] = counts.get(op, 0) + 1
        return counts

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            'root_id': self.root_id,
            'depth': self.depth,
            'node_count': len(self.nodes),
            'edge_count': len(self.edges),
            'has_protected': self.has_protected,
            'sources': [n.to_dict() for n in self.source_nodes],
            'protected_sources': [n.to_dict() for n in self.protected_sources],
            'operation_counts': self.operation_counts,
            'nodes': {str(k): v.to_dict() for k, v in self.nodes.items()},
            'edges': [e.to_dict() for e in self.edges],
        }

    def to_json(self, indent: int = 2) -> str:
        """Export as JSON string."""
        return json.dumps(self.to_dict(), indent=indent)

    def to_graphviz(self) -> str:
        """Export as Graphviz DOT format."""
        lines = ['digraph ComputationDAG {']
        lines.append('  rankdir=BT;')  # Bottom to top (sources at bottom)
        lines.append('  node [shape=box, style=filled];')
        lines.append('')

        # Define nodes
        for node in self.nodes.values():
            if node.is_source:
                color = '#f59e0b' if node.is_protected else '#22d3ee'
                label = f"{node.table}\\n{node.column}"
                lines.append(f'  n{node.node_id} [label="{label}", fillcolor="{color}"];')
            else:
                color = '#c084fc' if node.node_id == self.root_id else '#4ade80'
                label = node.operation
                lines.append(f'  n{node.node_id} [label="{label}", fillcolor="{color}"];')

        lines.append('')

        # Define edges
        for edge in self.edges:
            lines.append(f'  n{edge.source_id} -> n{edge.target_id};')

        lines.append('}')
        return '\n'.join(lines)


# =============================================================================
# DAG Tracker
# =============================================================================

class DAGTracker(ProvenanceTracker):
    """
    Extended provenance tracker with full DAG reconstruction.

    Inherits all HYDRA-24 Enhanced functionality and adds:
    - Complete operation logging
    - DAG reconstruction from any provenance value
    - Export to Graphviz, JSON, HTML
    - Optional database persistence for litigation evidence
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        tenant_id: Optional[str] = None,
        service_url: str = "",
        pipeline_name: Optional[str] = None
    ):
        """
        Initialize DAG tracker.

        Args:
            api_key: Attestant API key (required for persistence)
            tenant_id: Tenant ID (auto-derived from API key)
            service_url: Attestant hosted service URL
            pipeline_name: Name for this pipeline execution

        Example:
            # Via simplified API (recommended)
            import attestant
            attestant.configure(api_key="hyd_live_abc123")

            # Direct instantiation (advanced)
            tracker = DAGTracker(
                api_key="hyd_live_abc123",
                pipeline_name="loan_approval_v2"
            )
        """
        super().__init__()

        # DAG storage -- protected by _dag_lock for thread safety
        self._dag_lock = threading.Lock()
        self._nodes: Dict[int, DAGNode] = {}
        self._next_node_id = 0

        # Value-level lineage buffer
        self._value_buffer: List = []
        self._value_buffer_lock = threading.Lock()
        self._value_flush_threshold = 5000
        self._nodes_persisted = False
        # Upper bound on in-memory nodes to prevent unbounded growth in
        # long-running pipelines.  Once reached, oldest nodes are evicted
        # and only kept in the persistence layer (if enabled).
        self._max_nodes = 500_000

        # Provenance → node mapping (for lookup)
        # Note: Multiple nodes can have same provenance if they represent
        # the same computation on different rows
        self._prov_to_nodes: Dict[int, List[int]] = {}

        # Source tracking: (table, column) → node_id for that source
        self._source_nodes: Dict[Tuple[str, str], int] = {}

        # Persistence (always enabled with API key)
        self._writer = None
        self._storage = None
        self._pipeline_id = None
        self._pipeline_name = pipeline_name
        self._api_key = api_key
        self._tenant_id = tenant_id
        self._service_url = service_url
        self._dashboard_synced = False

        if api_key:
            self.enable_persistence()

    # -------------------------------------------------------------------------
    # Persistence
    # -------------------------------------------------------------------------

    def enable_persistence(self) -> None:
        """
        Enable persistence to Attestant hosted service.

        Starts background writer thread that batches writes for performance.
        All data is automatically uploaded to your Attestant cloud account.
        """
        from .persistence import HostedStorage, AsyncWriter, WriterConfig

        self._storage = HostedStorage(
            api_url=self._service_url,
            api_key=self._api_key,
            tenant_id=self._tenant_id or "default",
        )

        try:
            self._storage.connect()

            # Create pipeline record with tenant_id
            self._pipeline_id = self._storage.create_pipeline(
                pipeline_name=self._pipeline_name or "unnamed_pipeline",
                config=None,
                git_commit=None,
                tenant_id=self._tenant_id
            )

            # Start async writer
            config = WriterConfig(
                batch_size=100,
                flush_interval=1.0,
                queue_size=10000
            )
            self._writer = AsyncWriter(self._storage, config)
            self._writer.start()

            # Register existing sources
            for table, columns in self._sources.items():
                for column, pair_id in columns.items():
                    is_prot = self.is_protected(table, column)
                    self._writer.register_source(pair_id, table, column, is_prot)

        except Exception as e:
            import warnings
            warnings.warn(
                f"Persistence initialization failed: {e}\n"
                "Continuing in memory-only mode.",
                UserWarning
            )

    def record_row_value(self, row_index: int, fingerprint: int,
                         operation: str, value=None,
                         column_name: Optional[str] = None) -> None:
        """Buffer a per-row value for later persistence."""
        from .persistence.storage import StoredRowValue

        numeric_value = None
        text_value = None
        if value is not None:
            try:
                numeric_value = float(value)
            except (ValueError, TypeError, OverflowError):
                text_value = str(value)

        rv = StoredRowValue(
            pipeline_id=self._pipeline_id or 0,
            row_index=row_index,
            fingerprint=fingerprint,
            node_operation=operation,
            value=numeric_value,
            column_name=column_name,
            tenant_id=self._tenant_id,
            text_value=text_value,
        )
        with self._value_buffer_lock:
            self._value_buffer.append(rv)
            if len(self._value_buffer) >= self._value_flush_threshold and self._writer:
                self._writer.write_row_values(self._value_buffer[:])
                self._value_buffer.clear()

    def disable_persistence(self) -> None:
        """Disable persistence and close connections."""
        if self._writer:
            self._writer.stop()
            self._writer = None

        if self._storage:
            if self._pipeline_id is not None:
                self._storage.complete_pipeline(self._pipeline_id, status='completed')
            self._storage.disconnect()
            self._storage = None

        self._pipeline_id = None

    def flush(self, timeout: float = 30.0) -> bool:
        """
        Flush all pending writes to database.

        Call this before exiting to ensure all data is persisted.

        Args:
            timeout: Max seconds to wait

        Returns:
            True if successful, False if timeout
        """
        if self._writer:
            with self._value_buffer_lock:
                if self._value_buffer:
                    self._writer.write_row_values(self._value_buffer[:])
                    self._value_buffer.clear()
            self._writer.flush(timeout=timeout)

            if not self._nodes_persisted and self._storage and self._pipeline_id:
                self._persist_dag_to_storage()
                self._nodes_persisted = True

            if not self._dashboard_synced:
                self._sync_to_dashboard()
                self._dashboard_synced = True

            return True
        return True

    def _sync_to_dashboard(self) -> None:
        """Sync pipeline results to dashboard tables via the API."""
        if not self._service_url or not self._api_key:
            return
        import urllib.request
        import urllib.error

        nodes_written = getattr(self, '_nodes_written', 0)
        edges_written = getattr(self, '_edges_written', 0)

        # Build sync payload from pipeline data
        payload: Dict = {
            "pipeline": {
                "pipeline_name": self._pipeline_name or "unnamed_pipeline",
                "status": "completed",
                "node_count": nodes_written,
                "edge_count": edges_written,
                "provenance_pipeline_id": self._pipeline_id,
            },
            "model": {
                "model_id": self._pipeline_name or "unnamed_pipeline",
                "name": self._pipeline_name or "Unnamed Pipeline",
                "version": "1.0",
                "status": "production",
                "domain": "credit",
            },
        }

        # Check if any DAG uses protected attributes
        has_protected = False
        protected_sources = []
        for node in self._nodes.values():
            if node.is_protected:
                has_protected = True
                if node.table and node.column:
                    protected_sources.append(f"{node.table}.{node.column}")

        payload["fairness"] = {
            "model_id": self._pipeline_name or "unnamed_pipeline",
            "has_disparate_impact": has_protected,
            "protected_attributes": list(set(protected_sources)),
            "details": {
                "node_count": nodes_written,
                "edge_count": edges_written,
                "protected_sources": list(set(protected_sources)),
            },
        }

        url = self._service_url.rstrip("/") + "/v1/dashboard/sync"
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url, data=body, method="POST",
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                resp.read()
            logger.info("Dashboard sync completed")
        except Exception as e:
            logger.warning("Dashboard sync failed (non-fatal): %s", e)

    def _persist_dag_to_storage(self) -> None:
        """Persist deduplicated nodes and edges to storage."""
        from .persistence.storage import StoredNode

        seen: Dict[int, DAGNode] = {}
        for node in self._nodes.values():
            if node.provenance not in seen:
                seen[node.provenance] = node

        nodes_batch = []
        for node in seen.values():
            _p, entity_hash, chain_hash = self.decode_full(node.provenance)
            nodes_batch.append(StoredNode(
                fingerprint=int(node.provenance),
                node_type=node.node_type.name,
                operation=node.operation,
                table_name=node.table,
                column_name=node.column,
                pair_id=int(node.pair_id) if node.pair_id is not None else None,
                is_protected=bool(node.is_protected),
                entity_hash=int(entity_hash),
                chain_hash=int(chain_hash),
                metadata=node.metadata,
                pipeline_id=self._pipeline_id,
            ))

        if nodes_batch:
            self._storage.store_nodes(nodes_batch)
            self._nodes_written = len(nodes_batch)

        fp_map = self._storage.get_fingerprint_node_map(self._pipeline_id)

        seen_edges: set = set()
        edge_rows = []
        for node in self._nodes.values():
            for i, input_id in enumerate(node.inputs):
                input_node = self._nodes.get(input_id)
                if input_node is None:
                    continue
                edge_key = (int(input_node.provenance), int(node.provenance), i)
                if edge_key in seen_edges:
                    continue
                seen_edges.add(edge_key)
                parent_db_id = fp_map.get(int(input_node.provenance))
                child_db_id = fp_map.get(int(node.provenance))
                if parent_db_id is not None and child_db_id is not None:
                    edge_rows.append((parent_db_id, child_db_id, i))

        if edge_rows:
            self._storage.store_edges_resolved(edge_rows)
            self._edges_written = len(edge_rows)

    def get_persistence_stats(self) -> Optional[dict]:
        """Get statistics about persistence operations."""
        if self._writer:
            stats = self._writer.get_stats()
            if stats:
                stats['nodes_written'] = getattr(self, '_nodes_written', 0)
                stats['edges_written'] = getattr(self, '_edges_written', 0)
            return stats
        return None

    def persist_to_storage(self, storage, pipeline_id: Optional[int] = None) -> int:
        """
        Persist all in-memory nodes and edges to storage in bulk.

        Call this AFTER your pipeline completes to avoid slowing down
        computation. All provenance tracking happens in-memory during
        the pipeline; this method writes everything to the database
        in optimized batch operations.

        Deduplicates before writing: many DAG nodes share the same
        fingerprint (same column, same operation, different rows).
        Only unique nodes and edges are persisted.

        Works with any StorageBackend implementation (SQLite, S3, etc.).

        Args:
            storage: A StorageBackend instance, already connected.
            pipeline_id: Optional pipeline_id. If None, one is created.

        Returns:
            The pipeline_id used for persistence.
        """
        from .persistence.storage import StoredNode

        if pipeline_id is None:
            pipeline_id = storage.create_pipeline(self._pipeline_name or "unnamed")

        # Register sources
        for pair_id_val, (table_name, col_name) in self._id_to_name.items():
            is_prot = self.is_protected(table_name, col_name)
            storage.register_source(pair_id_val, table_name, col_name, is_protected=is_prot)

        # Deduplicate nodes by fingerprint. Multiple in-memory nodes share
        # the same fingerprint (one per row), but they represent the same
        # column/operation. We only need one DB row per unique fingerprint.
        seen_fingerprints: Dict[int, DAGNode] = {}
        for node in self._nodes.values():
            if node.provenance not in seen_fingerprints:
                seen_fingerprints[node.provenance] = node

        nodes_batch = []
        for node in seen_fingerprints.values():
            nodes_batch.append(StoredNode(
                fingerprint=node.provenance,
                node_type=node.node_type.name,
                operation=node.operation,
                table_name=node.table,
                column_name=node.column,
                pair_id=node.pair_id,
                is_protected=node.is_protected,
                pipeline_id=pipeline_id,
            ))

        storage.store_nodes(nodes_batch)

        # Get fingerprint → db_node_id mapping via abstract method
        fp_to_db_id = storage.get_fingerprint_node_map(pipeline_id)

        # Deduplicate edges and resolve to db node IDs
        seen_edges: set = set()
        edge_rows = []
        for node in self._nodes.values():
            for i, input_id in enumerate(node.inputs):
                input_node = self._nodes.get(input_id)
                if input_node is None:
                    continue
                edge_key = (input_node.provenance, node.provenance, i)
                if edge_key in seen_edges:
                    continue
                seen_edges.add(edge_key)

                parent_db_id = fp_to_db_id.get(input_node.provenance)
                child_db_id = fp_to_db_id.get(node.provenance)
                if parent_db_id is not None and child_db_id is not None:
                    edge_rows.append((parent_db_id, child_db_id, i))

        storage.store_edges_resolved(edge_rows)
        storage.complete_pipeline(pipeline_id, 'completed')
        return pipeline_id

    @staticmethod
    def persist_results(storage, pipeline_id: int,
                        row_keys,
                        outputs: Dict[str, 'DAGTrackedSeries'],
                        source_df: Optional[pd.DataFrame] = None) -> None:
        """
        Persist per-row output fingerprints to the pipeline_results table.

        This is the audit link: given applicant_id=457, you can look up
        which fingerprint (and therefore which DAG) produced their risk_score.

        If source_df is provided, a SHA-256 hash of each row's source values
        is stored alongside the result. This enables tamper detection: if
        someone changes the source data after the pipeline ran, you can
        rehash the current data and compare against the stored input_hash.

        Args:
            storage: A connected SQLiteStorage instance.
            pipeline_id: The pipeline that produced these outputs.
            row_keys: Iterable of business identifiers (e.g. applicant_ids)
                      aligned with the output series indices.
            outputs: Dict mapping output name to DAGTrackedSeries.
                     e.g. {"risk_score": risk_score_series, "dti": dti_series}
            source_df: Optional DataFrame of the source data used. If provided,
                       each row is hashed for tamper detection.
        """
        import hashlib

        results = []
        row_keys_list = list(row_keys)

        # Pre-compute per-row input hashes if source data is provided
        row_hashes: Optional[List[str]] = None
        if source_df is not None:
            row_hashes = []
            for i in range(len(row_keys_list)):
                if i < len(source_df):
                    row_bytes = source_df.iloc[i].to_json().encode('utf-8')
                    row_hashes.append(hashlib.sha256(row_bytes).hexdigest())
                else:
                    row_hashes.append(None)

        for output_name, series in outputs.items():
            prov_arr = series._prov
            values = series.values
            for i, row_key in enumerate(row_keys_list):
                fp = int(prov_arr[i]) if i < len(prov_arr) else 0
                val = float(values[i]) if i < len(values) else None
                ih = row_hashes[i] if row_hashes else None
                results.append((str(row_key), output_name, fp, val, ih))

        storage.store_results(pipeline_id, results)

    # -------------------------------------------------------------------------
    # Node Creation
    # -------------------------------------------------------------------------

    def _create_node(self, node_type: NodeType, operation: str,
                     inputs: List[int], provenance: int,
                     **kwargs) -> int:
        """Create a new DAG node and return its ID.

        Thread-safe: protects shared state with ``_dag_lock``.
        Enforces ``_max_nodes`` to prevent unbounded memory growth in
        long-running pipelines.  When the limit is reached, the oldest
        non-source nodes are evicted (source nodes are always retained).
        """
        with self._dag_lock:
            node_id = self._next_node_id
            self._next_node_id += 1

            node = DAGNode(
                node_id=node_id,
                node_type=node_type,
                operation=operation,
                inputs=inputs,
                provenance=provenance,
                **kwargs
            )

            self._nodes[node_id] = node

            # Track provenance → node mapping
            if provenance not in self._prov_to_nodes:
                self._prov_to_nodes[provenance] = []
            self._prov_to_nodes[provenance].append(node_id)

            # Evict oldest non-source nodes when memory bound is reached
            if len(self._nodes) > self._max_nodes:
                self._evict_oldest_nodes()

        return node_id

    def _evict_oldest_nodes(self) -> None:
        """Remove the oldest 10% of non-source nodes to stay under memory bound.

        Must be called while holding ``_dag_lock``.
        """
        evict_count = len(self._nodes) // 10
        evicted = 0
        # Iterate in insertion order (dict preserves order since Python 3.7)
        for nid in list(self._nodes):
            if evicted >= evict_count:
                break
            node = self._nodes[nid]
            if node.node_type == NodeType.SOURCE:
                continue  # Never evict source nodes
            del self._nodes[nid]
            # Clean up prov_to_nodes mapping
            prov_list = self._prov_to_nodes.get(node.provenance)
            if prov_list is not None:
                try:
                    prov_list.remove(nid)
                except ValueError:
                    pass
                if not prov_list:
                    del self._prov_to_nodes[node.provenance]
            evicted += 1

        if evicted > 0:
            logger.info(
                "Evicted %d oldest non-source nodes (limit: %d, current: %d)",
                evicted, self._max_nodes, len(self._nodes),
            )

    def __enter__(self):
        """Context manager support."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Ensure flush on context exit."""
        self.flush()
        if exc_type is None:
            self.disable_persistence()
        else:
            # Mark pipeline as failed
            if self._storage and self._pipeline_id:
                self._storage.complete_pipeline(self._pipeline_id, status='failed')
            self.disable_persistence()
        return False

    def __del__(self):
        """Ensure cleanup on garbage collection."""
        try:
            self.disable_persistence()
        except Exception:
            pass

    def _persist_node(self, node: DAGNode) -> None:
        """Persist a node to database (called from _create_node)."""
        try:
            from .persistence import StoredNode, StoredEdge
        except ImportError:
            logger.error(
                "Persistence module unavailable — provenance data is NOT "
                "being saved to storage. Install attestant with persistence "
                "extras or check your installation."
            )
            return

        # Extract entity and chain hashes from the provenance fingerprint
        _pairs, entity_hash, chain_hash = self.decode_full(node.provenance)

        # Convert DAGNode to StoredNode
        stored_node = StoredNode(
            fingerprint=node.provenance,
            node_type=node.node_type.name,
            operation=node.operation,
            table_name=node.table,
            column_name=node.column,
            pair_id=node.pair_id,
            is_protected=node.is_protected,
            entity_hash=entity_hash,
            chain_hash=chain_hash,
            metadata=node.metadata,
            pipeline_id=self._pipeline_id
        )

        # Write node (non-blocking)
        self._writer.write_node(stored_node)

        # Write edges
        edges = []
        for i, input_id in enumerate(node.inputs):
            input_node = self._nodes.get(input_id)
            if input_node:
                edges.append(StoredEdge(
                    parent_fingerprint=input_node.provenance,
                    child_fingerprint=node.provenance,
                    input_position=i
                ))

        if edges:
            self._writer.write_edges(edges)

    def _start_new_pipeline(self) -> None:
        """Start a new pipeline for the next run after a flush/sync cycle."""
        if self._storage and self._pipeline_id:
            self._storage.complete_pipeline(self._pipeline_id, status='completed')
            self._pipeline_id = self._storage.create_pipeline(
                pipeline_name=self._pipeline_name or "unnamed_pipeline",
                config=None,
                git_commit=None,
                tenant_id=self._tenant_id,
            )
            self._dashboard_synced = False
            self._nodes_persisted = False
            self._source_nodes.clear()
            self._nodes_written = 0
            self._edges_written = 0

    def create_source_node(self, table: str, column: str, provenance: int) -> int:
        """Create a source (leaf) node for a table column."""
        if not table or not column:
            raise ValueError("table and column must be non-empty strings")

        # If we already synced to dashboard, start a new pipeline
        if self._dashboard_synced:
            self._start_new_pipeline()

        key = (table, column)

        # Return existing node if already created
        if key in self._source_nodes:
            return self._source_nodes[key]

        pair_id = self.get_id(table, column)
        is_protected = self.is_protected(table, column)

        node_id = self._create_node(
            node_type=NodeType.SOURCE,
            operation=f"{table}.{column}",
            inputs=[],
            provenance=provenance,
            table=table,
            column=column,
            pair_id=pair_id,
            is_protected=is_protected,
        )

        self._source_nodes[key] = node_id
        return node_id

    def log_unary(self, op_name: str, input_node: int, result_prov: int,
                  metadata: Optional[Dict] = None) -> int:
        """Log a unary operation (single input)."""
        return self._create_node(
            node_type=NodeType.UNARY,
            operation=op_name,
            inputs=[input_node],
            provenance=result_prov,
            metadata=metadata or {},
        )

    def log_binary(self, op_name: str, left_node: int, right_node: int,
                   result_prov: int, metadata: Optional[Dict] = None) -> int:
        """Log a binary operation (two inputs)."""
        return self._create_node(
            node_type=NodeType.BINARY,
            operation=op_name,
            inputs=[left_node, right_node],
            provenance=result_prov,
            metadata=metadata or {},
        )

    def log_merge(self, left_nodes: List[int], right_nodes: List[int],
                  result_prov: int, merge_type: str = "inner",
                  metadata: Optional[Dict] = None) -> int:
        """Log a merge/join operation."""
        all_inputs = left_nodes + right_nodes
        return self._create_node(
            node_type=NodeType.MERGE,
            operation=f"merge_{merge_type}",
            inputs=all_inputs,
            provenance=result_prov,
            metadata={'merge_type': merge_type, **(metadata or {})},
        )

    def log_aggregate(self, op_name: str, input_nodes: List[int],
                      result_prov: int, metadata: Optional[Dict] = None) -> int:
        """Log an aggregation operation."""
        return self._create_node(
            node_type=NodeType.AGGREGATE,
            operation=op_name,
            inputs=input_nodes,
            provenance=result_prov,
            metadata=metadata or {},
        )

    # -------------------------------------------------------------------------
    # DAG Reconstruction
    # -------------------------------------------------------------------------

    def get_node(self, node_id: int) -> Optional[DAGNode]:
        """Get a node by ID."""
        return self._nodes.get(node_id)

    def get_nodes_for_provenance(self, provenance: int) -> List[DAGNode]:
        """Get all nodes with a given provenance."""
        node_ids = self._prov_to_nodes.get(provenance, [])
        return [self._nodes[nid] for nid in node_ids]

    def get_dag(self, root_node_id: int) -> ComputationDAG:
        """
        Reconstruct the full computation DAG from a result node.

        Walks backward from the root to collect all ancestor nodes.
        """
        # Collect all reachable nodes via BFS
        from collections import deque

        visited: Set[int] = set()
        bfs_queue = deque([root_node_id])
        nodes: Dict[int, DAGNode] = {}
        edges: List[DAGEdge] = []

        while bfs_queue:
            node_id = bfs_queue.popleft()
            if node_id in visited:
                continue
            visited.add(node_id)

            node = self._nodes.get(node_id)
            if node is None:
                continue

            nodes[node_id] = node

            # Add edges and queue inputs
            for i, input_id in enumerate(node.inputs):
                edges.append(DAGEdge(source_id=input_id, target_id=node_id, input_index=i))
                if input_id not in visited:
                    bfs_queue.append(input_id)

        return ComputationDAG(root_id=root_node_id, nodes=nodes, edges=edges)

    def get_dag_for_provenance(self, provenance: int) -> Optional[ComputationDAG]:
        """Get DAG for the most recent node with given provenance."""
        nodes = self.get_nodes_for_provenance(provenance)
        if not nodes:
            return None
        # Return DAG for the most recent node (highest ID)
        root = max(nodes, key=lambda n: n.node_id)
        return self.get_dag(root.node_id)

    # -------------------------------------------------------------------------
    # Stats
    # -------------------------------------------------------------------------

    def dag_stats(self) -> Dict[str, Any]:
        """Get DAG statistics."""
        source_count = sum(1 for n in self._nodes.values() if n.is_source)
        protected_count = sum(1 for n in self._nodes.values() if n.is_protected)

        op_counts: Dict[str, int] = {}
        for node in self._nodes.values():
            if not node.is_source:
                op = node.operation
                op_counts[op] = op_counts.get(op, 0) + 1

        return {
            'total_nodes': len(self._nodes),
            'source_nodes': source_count,
            'protected_sources': protected_count,
            'operation_nodes': len(self._nodes) - source_count,
            'operation_counts': op_counts,
            'unique_provenances': len(self._prov_to_nodes),
        }


# =============================================================================
# DAG-Aware Pandas Integration
# =============================================================================

class DAGTrackedSeries(pd.Series):
    """Pandas Series with DAG-tracked provenance."""

    _metadata = ['_prov', '_tracker', '_node_ids']

    def __init__(self, *args, **kwargs):
        prov = kwargs.pop('_prov', None)
        tracker = kwargs.pop('_tracker', None)
        node_ids = kwargs.pop('_node_ids', None)
        super().__init__(*args, **kwargs)
        self._prov = prov if prov is not None else np.zeros(len(self), dtype=np.uint32)
        self._tracker = tracker
        self._node_ids = node_ids if node_ids is not None else np.zeros(len(self), dtype=np.int64)

    @property
    def _constructor(self):
        return DAGTrackedSeries

    def _binop_dag(self, other, np_op, op_name: str, op_code: int):
        """Binary operation with DAG logging."""
        result_values = np_op(self.values, other.values if hasattr(other, 'values') else other)

        if isinstance(other, DAGTrackedSeries) and self._tracker:
            n = len(result_values)
            new_prov = np.zeros(n, dtype=np.uint32)
            new_nodes = np.zeros(n, dtype=np.int64)

            for i in range(n):
                pa = int(self._prov[i]) if i < len(self._prov) else 0
                pb = int(other._prov[i]) if i < len(other._prov) else 0

                # Combine provenance
                combined_prov = self._tracker.combine(pa, pb, op_code)
                new_prov[i] = combined_prov

                # Log to DAG
                left_node = int(self._node_ids[i]) if i < len(self._node_ids) else -1
                right_node = int(other._node_ids[i]) if i < len(other._node_ids) else -1

                if left_node >= 0 and right_node >= 0:
                    new_nodes[i] = self._tracker.log_binary(
                        op_name, left_node, right_node, combined_prov
                    )

                # Record value-level lineage
                try:
                    raw_val = result_values[i]
                    if raw_val is not None and not (isinstance(raw_val, float) and raw_val != raw_val):
                        self._tracker.record_row_value(
                            i, int(combined_prov), op_name, raw_val)
                except Exception:
                    pass

            return DAGTrackedSeries(result_values, index=self.index,
                                    _prov=new_prov, _tracker=self._tracker, _node_ids=new_nodes)
        else:
            return DAGTrackedSeries(result_values, index=self.index,
                                    _prov=self._prov.copy(), _tracker=self._tracker,
                                    _node_ids=self._node_ids.copy())

    def _unop_dag(self, np_op, op_name: str, op_code: int):
        """Unary operation with DAG logging."""
        result_values = np_op(self.values)

        if self._tracker:
            n = len(result_values)
            new_prov = np.zeros(n, dtype=np.uint32)
            new_nodes = np.zeros(n, dtype=np.int64)

            for i in range(n):
                p = int(self._prov[i]) if i < len(self._prov) else 0
                new_prov[i] = self._tracker.update_chain(p, op_code)

                input_node = int(self._node_ids[i]) if i < len(self._node_ids) else -1
                if input_node >= 0:
                    new_nodes[i] = self._tracker.log_unary(op_name, input_node, new_prov[i])

                # Record value-level lineage
                try:
                    raw_val = result_values[i]
                    if raw_val is not None and not (isinstance(raw_val, float) and raw_val != raw_val):
                        self._tracker.record_row_value(
                            i, int(new_prov[i]), op_name, raw_val)
                except Exception:
                    pass

            return DAGTrackedSeries(result_values, index=self.index,
                                    _prov=new_prov, _tracker=self._tracker, _node_ids=new_nodes)
        else:
            return DAGTrackedSeries(result_values, index=self.index,
                                    _prov=self._prov.copy(), _tracker=self._tracker,
                                    _node_ids=self._node_ids.copy())

    def __add__(self, other): return self._binop_dag(other, np.add, "add", OpCode.ADD)
    def __sub__(self, other): return self._binop_dag(other, np.subtract, "sub", OpCode.SUB)
    def __mul__(self, other): return self._binop_dag(other, np.multiply, "mul", OpCode.MUL)
    def __truediv__(self, other): return self._binop_dag(other, np.true_divide, "div", OpCode.DIV)
    def __floordiv__(self, other): return self._binop_dag(other, np.floor_divide, "floordiv", OpCode.DIV)
    def __pow__(self, other): return self._binop_dag(other, np.power, "pow", OpCode.MUL)

    def __radd__(self, other): return self._binop_dag(other, lambda a, b: np.add(b, a), "add", OpCode.ADD)
    def __rsub__(self, other): return self._binop_dag(other, lambda a, b: np.subtract(b, a), "sub", OpCode.SUB)
    def __rmul__(self, other): return self._binop_dag(other, lambda a, b: np.multiply(b, a), "mul", OpCode.MUL)
    def __rtruediv__(self, other): return self._binop_dag(other, lambda a, b: np.true_divide(b, a), "div", OpCode.DIV)

    def __neg__(self): return self._unop_dag(lambda x: -x, "neg", OpCode.NEG)

    def __gt__(self, other): return self._binop_dag(other, lambda a, b: a > b, "gt", OpCode.CMP)
    def __lt__(self, other): return self._binop_dag(other, lambda a, b: a < b, "lt", OpCode.CMP)
    def __ge__(self, other): return self._binop_dag(other, lambda a, b: a >= b, "ge", OpCode.CMP)
    def __le__(self, other): return self._binop_dag(other, lambda a, b: a <= b, "le", OpCode.CMP)

    def clip(self, lower=None, upper=None, **kwargs):
        return self._unop_dag(lambda x: np.clip(x, lower, upper), "clip", OpCode.CLIP)

    def _apply_tracked_unary(self, result_values, result_index, op_name: str, op_code) -> "DAGTrackedSeries":
        """Apply a tracked unary operation, updating provenance for each element.

        Shared by fillna, replace, and similar element-wise transforms.
        """
        if self._tracker:
            n = len(result_values)
            prov_len = len(self._prov)
            node_len = len(self._node_ids)
            new_prov = np.zeros(n, dtype=np.uint32)
            new_nodes = np.zeros(n, dtype=np.int64)
            for i in range(n):
                p = int(self._prov[i]) if i < prov_len else 0
                new_prov[i] = self._tracker.update_chain(p, op_code)
                input_node = int(self._node_ids[i]) if i < node_len else -1
                if input_node >= 0:
                    new_nodes[i] = self._tracker.log_unary(op_name, input_node, new_prov[i])
                # Record value-level lineage
                try:
                    raw_val = result_values[i]
                    if raw_val is not None and not (isinstance(raw_val, float) and raw_val != raw_val):
                        self._tracker.record_row_value(
                            i, int(new_prov[i]), op_name, raw_val)
                except Exception:
                    pass
            return DAGTrackedSeries(result_values, index=result_index,
                                    _prov=new_prov, _tracker=self._tracker, _node_ids=new_nodes)
        return DAGTrackedSeries(result_values, index=result_index,
                                _prov=self._prov.copy(), _tracker=self._tracker,
                                _node_ids=self._node_ids.copy())

    def fillna(self, value=0, **kwargs):
        result = super().fillna(value, **kwargs)
        return self._apply_tracked_unary(result.values, self.index, "fillna", OpCode.FILL)

    def replace(self, *args, **kwargs):
        result = super().replace(*args, **kwargs)
        if isinstance(result, pd.Series):
            return self._apply_tracked_unary(result.values, result.index, "replace", OpCode.MAP)
        return result


class DAGTrackedDataFrame(pd.DataFrame):
    """Pandas DataFrame with DAG-tracked provenance."""

    _metadata = ['_tracker', '_col_prov', '_col_nodes']

    def __init__(self, *args, **kwargs):
        tracker = kwargs.pop('_tracker', None)
        col_prov = kwargs.pop('_col_prov', None)
        col_nodes = kwargs.pop('_col_nodes', None)
        super().__init__(*args, **kwargs)
        self._tracker = tracker
        self._col_prov = col_prov if col_prov is not None else {}
        self._col_nodes = col_nodes if col_nodes is not None else {}

    @property
    def _constructor(self):
        return DAGTrackedDataFrame

    @property
    def _constructor_sliced(self):
        return DAGTrackedSeries

    def __getitem__(self, key):
        result = super().__getitem__(key)
        if isinstance(result, pd.Series):
            prov = self._col_prov.get(key, np.zeros(len(result), dtype=np.uint32))
            nodes = self._col_nodes.get(key, np.zeros(len(result), dtype=np.int64))
            n = len(result)
            if len(prov) != n:
                prov = np.broadcast_to(prov[:1] if len(prov) > 0 else np.array([0], dtype=np.uint32), n).copy()
            if len(nodes) != n:
                nodes = np.broadcast_to(nodes[:1] if len(nodes) > 0 else np.array([0], dtype=np.int64), n).copy()
            return DAGTrackedSeries(result.values, index=result.index,
                                    _prov=prov.copy(), _tracker=self._tracker, _node_ids=nodes.copy())
        return result

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        if isinstance(value, DAGTrackedSeries):
            self._col_prov[key] = value._prov.copy()
            self._col_nodes[key] = value._node_ids.copy()

    def _merge_col_provenance(self, col_prov, col_nodes, result_columns, n, out_prov, out_nodes):
        """Propagate column provenance from one side of a merge into *out_prov*/*out_nodes*."""
        for col, prov in col_prov.items():
            if col in result_columns and col not in out_prov:
                base_prov = int(prov[0]) if len(prov) > 0 else 0
                merged_prov = self._tracker.update_chain(base_prov, OpCode.MERGE) if self._tracker else base_prov
                out_prov[col] = np.full(n, merged_prov, dtype=np.uint32)

                if self._tracker and col in col_nodes:
                    input_node = int(col_nodes[col][0]) if len(col_nodes[col]) > 0 else -1
                    if input_node >= 0:
                        merge_node = self._tracker.log_unary("merge", input_node, merged_prov)
                        out_nodes[col] = np.full(n, merge_node, dtype=np.int64)

    def merge(self, right, *args, **kwargs):
        result = super().merge(right, *args, **kwargs)
        new_prov = {}
        new_nodes = {}
        n = len(result)
        cols = set(result.columns)

        self._merge_col_provenance(self._col_prov, self._col_nodes, cols, n, new_prov, new_nodes)
        if isinstance(right, DAGTrackedDataFrame):
            self._merge_col_provenance(right._col_prov, right._col_nodes, cols, n, new_prov, new_nodes)

        return DAGTrackedDataFrame(result, _tracker=self._tracker,
                                   _col_prov=new_prov, _col_nodes=new_nodes)


# =============================================================================
# Helper Functions
# =============================================================================


def combine_provenances(tracker: DAGTracker, node_ids, op_code=None):
    """Combine provenance from multiple node IDs into a single value.

    Iterates over *node_ids*, fetching each node's provenance from
    *tracker*, and combines them via ``tracker.combine``.  Returns the
    combined provenance (or 0 if no nodes were found).
    """
    from .hydra24_simple import OpCode as _OpCode
    if op_code is None:
        op_code = _OpCode.CUSTOM
    combined = 0
    for nid in node_ids:
        node = tracker.get_node(nid)
        if node is None:
            continue
        if combined == 0:
            combined = node.provenance
        else:
            combined = tracker.combine(combined, node.provenance, op_code)
    return combined


def wrap_dataframe_dag(df: pd.DataFrame, tracker: DAGTracker, table: str,
                       protected=False, include_entity: bool = True) -> DAGTrackedDataFrame:
    """
    Wrap a DataFrame with DAG-tracked provenance.

    Creates source nodes for each column in the DAG.
    Records source values per row for value-level lineage.

    Args:
        protected: True to mark entire table, or list of column names
                   to mark specific columns as protected.
    """
    result = DAGTrackedDataFrame(df, _tracker=tracker)
    n = len(df)

    # Normalize protected: True -> whole table, list -> per-column
    if isinstance(protected, (list, tuple, set)):
        protected_cols = set(str(c) for c in protected)
    else:
        protected_cols = None  # None means use the bool for the whole table

    for col in df.columns:
        col_protected = protected if protected_cols is None else (str(col) in protected_cols)
        pair_id = tracker.register(table, str(col), col_protected)

        # Create provenance and source node for this column
        prov_array = np.zeros(n, dtype=np.uint32)
        node_array = np.zeros(n, dtype=np.int64)

        for i in range(n):
            entity = tracker.entity_from_row(df.index[i]) if include_entity else 0
            entity_6 = entity % (1 << MODE_01_ENTITY_BITS)
            prov = tracker.encode({pair_id}, entity=entity_6, chain=0)
            prov_array[i] = prov

            # Create source node (only once per column, reused for all rows)
            if i == 0:
                source_node = tracker.create_source_node(table, str(col), prov)
            node_array[i] = source_node

            # Record source value for value-level lineage
            try:
                raw_val = df.iloc[i][col]
                if raw_val is not None and not (isinstance(raw_val, float) and raw_val != raw_val):
                    tracker.record_row_value(
                        i, int(prov), f"{table}.{col}", raw_val, column_name=str(col))
            except Exception:
                pass

        result._col_prov[col] = prov_array
        result._col_nodes[col] = node_array

    return result


def get_dag_for_series(series: DAGTrackedSeries, row_index: int = 0) -> Optional[ComputationDAG]:
    """Get the computation DAG for a specific row in a series."""
    if not series._tracker or not hasattr(series, '_node_ids'):
        return None

    if row_index >= len(series._node_ids):
        return None

    node_id = int(series._node_ids[row_index])
    if node_id < 0:
        return None

    return series._tracker.get_dag(node_id)


def dag_audit(series: DAGTrackedSeries, row_index: int = 0) -> Dict[str, Any]:
    """Full audit of a series value including DAG reconstruction."""
    if not series._tracker or len(series) == 0:
        return {'error': 'No tracker or empty series'}

    prov = int(series._prov[row_index])
    tracker = series._tracker

    pairs, entity, chain = tracker.decode_full(prov)

    # Get DAG
    dag = get_dag_for_series(series, row_index)

    result = {
        'provenance': f"0x{prov:06X}",
        'mode': tracker.get_mode(prov),
        'pair_count': len(pairs),
        'pair_ids': sorted(pairs),
        'columns': tracker.explain(prov),
        'tables': tracker.explain_tables(prov),
        'entity': entity,
        'chain': chain,
        'has_protected': tracker.has_protected(prov),
    }

    if dag:
        result['dag'] = {
            'depth': dag.depth,
            'node_count': len(dag.nodes),
            'operation_counts': dag.operation_counts,
            'sources': [(n.table, n.column) for n in dag.source_nodes],
            'protected_sources': [(n.table, n.column) for n in dag.protected_sources],
        }

    return result
