"""
Compliance Exception Tracking for Attestant Governance.

Tracks policy exceptions with expiry dates, approval chains, and
auto-escalation for regulated AI models. Provides a structured way for
CROs to manage temporary compliance deviations that require ongoing
oversight.

In banking, compliance exceptions are temporary waivers where a model
or process operates outside normal policy bounds (e.g., a model deployed
before full validation, or a temporary DI threshold override). Examiners
expect these to be formally tracked with:

- Clear justification and scope
- Approval from appropriate authority level
- Defined expiry dates
- Auto-escalation when approaching or past expiry
- Full audit trail

Usage::

    from attestant.governance.exception_tracker import (
        ComplianceException, ExceptionTracker,
    )

    tracker = ExceptionTracker("./exceptions.db")
    tracker.connect()

    exc = tracker.create(
        model_id="credit_model_v2",
        regulation="SR 11-7 / OCC 2011-12",
        exception_type="deferred_validation",
        justification="Model deployed for shadow scoring only; "
                      "full validation scheduled for Q2",
        requested_by="Jane Smith, Model Owner",
        expires_in_days=90,
    )

    tracker.approve(exc.exception_id, "John Doe, CRO", level=2)

    # Check for expiring/expired exceptions
    alerts = tracker.check_escalations()
"""

from __future__ import annotations

import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, List, Optional


class ExceptionStatus(Enum):
    """Status of a compliance exception."""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
    CLOSED = "closed"


class EscalationLevel(Enum):
    """Escalation urgency for expiring exceptions."""
    NONE = "none"
    APPROACHING = "approaching"   # Within 14 days of expiry
    IMMINENT = "imminent"         # Within 7 days of expiry
    EXPIRED = "expired"           # Past expiry date
    CRITICAL = "critical"         # 30+ days past expiry


@dataclass
class ExceptionApproval:
    """Record of an approval in the exception approval chain."""
    approver_name: str
    approver_title: str
    level: int  # 1=team lead, 2=department head, 3=CRO, 4=board
    approved: bool
    comments: str
    approved_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "approver_name": self.approver_name,
            "approver_title": self.approver_title,
            "level": self.level,
            "approved": self.approved,
            "comments": self.comments,
            "approved_at": self.approved_at.isoformat(),
        }


@dataclass
class ComplianceException:
    """A tracked compliance policy exception."""
    exception_id: str
    model_id: str
    regulation: str
    exception_type: str
    justification: str
    requested_by: str
    status: ExceptionStatus
    risk_accepted: str
    scope: str
    approvals: List[ExceptionApproval] = field(default_factory=list)
    conditions: List[str] = field(default_factory=list)
    created_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    expires_at: Optional[datetime] = None
    closed_at: Optional[datetime] = None

    @property
    def is_active(self) -> bool:
        return self.status in (ExceptionStatus.PENDING, ExceptionStatus.APPROVED)

    @property
    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return datetime.now(timezone.utc) > self.expires_at

    @property
    def days_until_expiry(self) -> Optional[int]:
        if self.expires_at is None:
            return None
        delta = self.expires_at - datetime.now(timezone.utc)
        return delta.days

    @property
    def escalation_level(self) -> EscalationLevel:
        if self.status != ExceptionStatus.APPROVED:
            return EscalationLevel.NONE
        days = self.days_until_expiry
        if days is None:
            return EscalationLevel.NONE
        if days < -30:
            return EscalationLevel.CRITICAL
        if days < 0:
            return EscalationLevel.EXPIRED
        if days <= 7:
            return EscalationLevel.IMMINENT
        if days <= 14:
            return EscalationLevel.APPROACHING
        return EscalationLevel.NONE

    def to_dict(self) -> Dict[str, Any]:
        return {
            "exception_id": self.exception_id,
            "model_id": self.model_id,
            "regulation": self.regulation,
            "exception_type": self.exception_type,
            "justification": self.justification,
            "requested_by": self.requested_by,
            "status": self.status.value,
            "risk_accepted": self.risk_accepted,
            "scope": self.scope,
            "conditions": self.conditions,
            "approvals": [a.to_dict() for a in self.approvals],
            "created_at": self.created_at.isoformat(),
            "expires_at": (
                self.expires_at.isoformat() if self.expires_at else None
            ),
            "closed_at": (
                self.closed_at.isoformat() if self.closed_at else None
            ),
            "days_until_expiry": self.days_until_expiry,
            "escalation_level": self.escalation_level.value,
            "is_active": self.is_active,
        }


@dataclass
class EscalationAlert:
    """An alert generated for an expiring or expired exception."""
    exception_id: str
    model_id: str
    regulation: str
    level: EscalationLevel
    days_until_expiry: int
    message: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "exception_id": self.exception_id,
            "model_id": self.model_id,
            "regulation": self.regulation,
            "level": self.level.value,
            "days_until_expiry": self.days_until_expiry,
            "message": self.message,
        }


class ExceptionTracker:
    """SQLite-backed tracker for compliance policy exceptions.

    Manages the full lifecycle of compliance exceptions: creation,
    multi-level approval, monitoring, escalation, and closure.

    Designed for CRO oversight of temporary compliance deviations.

    Args:
        db_path: Path to SQLite database. Defaults to in-memory.
    """

    def __init__(self, db_path: str = ":memory:"):
        self._db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> None:
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._init_schema()

    def disconnect(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def __enter__(self):
        if self._conn is None:
            self.connect()
        return self

    def __exit__(self, *args):
        self.disconnect()
        return False

    def _init_schema(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS exceptions (
                exception_id TEXT PRIMARY KEY,
                model_id TEXT NOT NULL,
                regulation TEXT NOT NULL,
                exception_type TEXT NOT NULL,
                justification TEXT NOT NULL,
                requested_by TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                risk_accepted TEXT DEFAULT '',
                scope TEXT DEFAULT '',
                conditions TEXT DEFAULT '[]',
                created_at TEXT NOT NULL,
                expires_at TEXT,
                closed_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_exc_status
                ON exceptions (status);
            CREATE INDEX IF NOT EXISTS idx_exc_model
                ON exceptions (model_id);
            CREATE INDEX IF NOT EXISTS idx_exc_expires
                ON exceptions (expires_at);

            CREATE TABLE IF NOT EXISTS exception_approvals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exception_id TEXT NOT NULL REFERENCES exceptions(exception_id),
                approver_name TEXT NOT NULL,
                approver_title TEXT NOT NULL,
                level INTEGER NOT NULL,
                approved BOOLEAN NOT NULL,
                comments TEXT DEFAULT '',
                approved_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_appr_exc
                ON exception_approvals (exception_id);
        """)

    def create(
        self,
        model_id: str,
        regulation: str,
        exception_type: str,
        justification: str,
        requested_by: str,
        risk_accepted: str = "",
        scope: str = "",
        conditions: Optional[List[str]] = None,
        expires_in_days: int = 90,
    ) -> ComplianceException:
        """Create a new compliance exception request.

        Args:
            model_id: ID of the model this exception applies to.
            regulation: Regulation being excepted (e.g., "SR 11-7").
            exception_type: Type of exception (e.g., "deferred_validation",
                "threshold_override", "temporary_bypass").
            justification: Why the exception is needed.
            requested_by: Name and title of the requester.
            risk_accepted: Description of the risk being accepted.
            scope: Scope limitation of the exception.
            conditions: Conditions that must be maintained.
            expires_in_days: Days until the exception expires.

        Returns:
            ComplianceException in PENDING status.
        """
        if self._conn is None:
            self.connect()

        now = datetime.now(timezone.utc)
        expires = now + timedelta(days=expires_in_days)

        exc = ComplianceException(
            exception_id=str(uuid.uuid4())[:12],
            model_id=model_id,
            regulation=regulation,
            exception_type=exception_type,
            justification=justification,
            requested_by=requested_by,
            status=ExceptionStatus.PENDING,
            risk_accepted=risk_accepted,
            scope=scope,
            conditions=conditions or [],
            created_at=now,
            expires_at=expires,
        )

        import json
        self._conn.execute(
            """INSERT INTO exceptions
               (exception_id, model_id, regulation, exception_type,
                justification, requested_by, status, risk_accepted,
                scope, conditions, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                exc.exception_id, exc.model_id, exc.regulation,
                exc.exception_type, exc.justification, exc.requested_by,
                exc.status.value, exc.risk_accepted, exc.scope,
                json.dumps(exc.conditions),
                exc.created_at.isoformat(), exc.expires_at.isoformat(),
            ),
        )
        self._conn.commit()
        return exc

    def approve(
        self,
        exception_id: str,
        approver_name: str,
        approver_title: str = "",
        level: int = 1,
        comments: str = "",
    ) -> ComplianceException:
        """Approve an exception.

        Args:
            exception_id: ID of the exception to approve.
            approver_name: Name of the approver.
            approver_title: Title of the approver.
            level: Approval level (1=team lead, 2=dept head, 3=CRO, 4=board).
            comments: Approval comments.

        Returns:
            Updated ComplianceException.
        """
        if self._conn is None:
            self.connect()

        row = self._conn.execute(
            "SELECT * FROM exceptions WHERE exception_id = ?",
            (exception_id,),
        ).fetchone()
        if row is None:
            raise KeyError(f"Exception {exception_id} not found")

        now = datetime.now(timezone.utc)
        self._conn.execute(
            """INSERT INTO exception_approvals
               (exception_id, approver_name, approver_title, level,
                approved, comments, approved_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                exception_id, approver_name, approver_title,
                level, True, comments, now.isoformat(),
            ),
        )
        self._conn.execute(
            "UPDATE exceptions SET status = 'approved' WHERE exception_id = ?",
            (exception_id,),
        )
        self._conn.commit()

        return self.get(exception_id)

    def reject(
        self,
        exception_id: str,
        approver_name: str,
        approver_title: str = "",
        level: int = 1,
        reason: str = "",
    ) -> ComplianceException:
        """Reject an exception request."""
        if self._conn is None:
            self.connect()

        row = self._conn.execute(
            "SELECT * FROM exceptions WHERE exception_id = ?",
            (exception_id,),
        ).fetchone()
        if row is None:
            raise KeyError(f"Exception {exception_id} not found")

        now = datetime.now(timezone.utc)
        self._conn.execute(
            """INSERT INTO exception_approvals
               (exception_id, approver_name, approver_title, level,
                approved, comments, approved_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                exception_id, approver_name, approver_title,
                level, False, reason, now.isoformat(),
            ),
        )
        self._conn.execute(
            "UPDATE exceptions SET status = 'rejected' WHERE exception_id = ?",
            (exception_id,),
        )
        self._conn.commit()

        return self.get(exception_id)

    def close(self, exception_id: str) -> ComplianceException:
        """Close an exception (resolved or no longer needed)."""
        if self._conn is None:
            self.connect()

        now = datetime.now(timezone.utc)
        self._conn.execute(
            """UPDATE exceptions SET status = 'closed', closed_at = ?
               WHERE exception_id = ?""",
            (now.isoformat(), exception_id),
        )
        self._conn.commit()
        return self.get(exception_id)

    def get(self, exception_id: str) -> ComplianceException:
        """Retrieve an exception by ID."""
        if self._conn is None:
            self.connect()

        row = self._conn.execute(
            "SELECT * FROM exceptions WHERE exception_id = ?",
            (exception_id,),
        ).fetchone()
        if row is None:
            raise KeyError(f"Exception {exception_id} not found")

        return self._row_to_exception(row)

    def get_active(self) -> List[ComplianceException]:
        """Get all active (pending or approved) exceptions."""
        if self._conn is None:
            self.connect()

        rows = self._conn.execute(
            """SELECT * FROM exceptions
               WHERE status IN ('pending', 'approved')
               ORDER BY expires_at ASC""",
        ).fetchall()

        return [self._row_to_exception(r) for r in rows]

    def get_by_model(self, model_id: str) -> List[ComplianceException]:
        """Get all exceptions for a specific model."""
        if self._conn is None:
            self.connect()

        rows = self._conn.execute(
            "SELECT * FROM exceptions WHERE model_id = ? ORDER BY created_at DESC",
            (model_id,),
        ).fetchall()

        return [self._row_to_exception(r) for r in rows]

    def check_escalations(self) -> List[EscalationAlert]:
        """Check for exceptions that need escalation.

        Returns a list of escalation alerts for exceptions that are
        approaching expiry, imminent, expired, or critically overdue.
        """
        active = self.get_active()
        alerts: List[EscalationAlert] = []

        for exc in active:
            level = exc.escalation_level
            if level == EscalationLevel.NONE:
                continue

            days = exc.days_until_expiry or 0
            if level == EscalationLevel.CRITICAL:
                message = (
                    f"CRITICAL: Exception for {exc.model_id} ({exc.regulation}) "
                    f"expired {abs(days)} days ago. Immediate action required."
                )
            elif level == EscalationLevel.EXPIRED:
                message = (
                    f"EXPIRED: Exception for {exc.model_id} ({exc.regulation}) "
                    f"has expired. Model must be brought into compliance or "
                    f"exception renewed."
                )
            elif level == EscalationLevel.IMMINENT:
                message = (
                    f"IMMINENT: Exception for {exc.model_id} ({exc.regulation}) "
                    f"expires in {days} days. Begin renewal or remediation now."
                )
            else:
                message = (
                    f"APPROACHING: Exception for {exc.model_id} ({exc.regulation}) "
                    f"expires in {days} days. Plan renewal or remediation."
                )

            alerts.append(EscalationAlert(
                exception_id=exc.exception_id,
                model_id=exc.model_id,
                regulation=exc.regulation,
                level=level,
                days_until_expiry=days,
                message=message,
            ))

        # Sort by urgency (critical first)
        level_order = {
            EscalationLevel.CRITICAL: 0,
            EscalationLevel.EXPIRED: 1,
            EscalationLevel.IMMINENT: 2,
            EscalationLevel.APPROACHING: 3,
        }
        alerts.sort(key=lambda a: level_order.get(a.level, 4))
        return alerts

    def summary(self) -> Dict[str, Any]:
        """Generate an exception summary for CRO reporting."""
        if self._conn is None:
            self.connect()

        all_rows = self._conn.execute("SELECT * FROM exceptions").fetchall()
        all_exceptions = [self._row_to_exception(r) for r in all_rows]

        active = [e for e in all_exceptions if e.is_active]
        escalations = self.check_escalations()

        return {
            "total_exceptions": len(all_exceptions),
            "active_exceptions": len(active),
            "pending_approval": sum(
                1 for e in active if e.status == ExceptionStatus.PENDING
            ),
            "approved": sum(
                1 for e in active if e.status == ExceptionStatus.APPROVED
            ),
            "escalation_alerts": len(escalations),
            "critical_escalations": sum(
                1 for a in escalations
                if a.level in (EscalationLevel.CRITICAL, EscalationLevel.EXPIRED)
            ),
            "exceptions": [e.to_dict() for e in active],
            "escalations": [a.to_dict() for a in escalations],
        }

    def _row_to_exception(self, row: sqlite3.Row) -> ComplianceException:
        import json

        approval_rows = self._conn.execute(
            """SELECT * FROM exception_approvals
               WHERE exception_id = ? ORDER BY approved_at""",
            (row["exception_id"],),
        ).fetchall()

        approvals = [
            ExceptionApproval(
                approver_name=a["approver_name"],
                approver_title=a["approver_title"],
                level=a["level"],
                approved=bool(a["approved"]),
                comments=a["comments"] or "",
                approved_at=datetime.fromisoformat(a["approved_at"]),
            )
            for a in approval_rows
        ]

        conditions = json.loads(row["conditions"]) if row["conditions"] else []

        return ComplianceException(
            exception_id=row["exception_id"],
            model_id=row["model_id"],
            regulation=row["regulation"],
            exception_type=row["exception_type"],
            justification=row["justification"],
            requested_by=row["requested_by"],
            status=ExceptionStatus(row["status"]),
            risk_accepted=row["risk_accepted"] or "",
            scope=row["scope"] or "",
            conditions=conditions,
            approvals=approvals,
            created_at=datetime.fromisoformat(row["created_at"]),
            expires_at=(
                datetime.fromisoformat(row["expires_at"])
                if row["expires_at"] else None
            ),
            closed_at=(
                datetime.fromisoformat(row["closed_at"])
                if row["closed_at"] else None
            ),
        )
