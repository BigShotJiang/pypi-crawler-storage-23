"""Chat message widgets for the TUI.

MessagePanel — finalized message (king or member), rendered as Markdown.
StreamingPanel — in-progress response, updates as tokens arrive.
WaitingPanel — placeholder before streaming starts.
ErrorPanel — error or timeout display.
ThinkingPanel — collapsible thinking/reasoning tokens.
CommandHintBar — shows matching slash commands as you type.
"""

from __future__ import annotations

import re
import subprocess
import time

from rich.markdown import Markdown as RichMarkdown
from rich.segment import Segment
from rich.style import Style
from textual.message import Message
from textual.widget import Widget
from textual.widgets import LoadingIndicator, Static
from textual.widgets import Markdown as TextualMarkdown

from kingdom.tui.clipboard import ClipboardUnavailableError, copy_to_clipboard

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def format_elapsed(seconds: float) -> str:
    """Format elapsed seconds as a human-friendly duration string.

    Under 60 s  -> "12.3s"
    60 s+       -> "1m 23s"
    60 min+     -> "1h 2m 3s"
    """
    if seconds < 60:
        return f"{seconds:.1f}s"
    total = int(seconds)
    if total < 3600:
        m, s = divmod(total, 60)
        return f"{m}m {s}s"
    h, remainder = divmod(total, 3600)
    m, s = divmod(remainder, 60)
    return f"{h}h {m}m {s}s"


def format_reply_text(sender: str) -> str:
    """Build reply prefix: ``@sender `` with a trailing space.

    Keeps the input clean — the user types their reply directly after the
    @mention instead of having to delete a multi-line quoted block.
    """
    return f"@{sender} "


# Brand-aware colors for known council members.
#
# Rationale:
#   claude  — Anthropic brand orange (warm amber, close to the Claude logo
#             mark; #d97706 is a readable warm orange on both dark and light
#             terminal backgrounds).
#   codex   — OpenAI brand green (#19c37d is the ChatGPT/OpenAI accent
#             green, readable and distinctive from orange/blue).
#
# Adding a new member?  Pick the closest readable, terminal-safe brand color.
# If the brand palette is mostly black/white, choose a distinctive hue that
# won't collide with existing entries.  Both CSS named colors and hex values
# work (Textual accepts either).
BRAND_MEMBER_COLORS: dict[str, str] = {
    "claude": "#d97706",
    "codex": "#19c37d",
}

# Fallback palette for unknown members, indexed by stable hash.
# Deliberately avoids orange, green, and blue tones so unknown members
# remain visually distinct from brand-colored members.  Chosen to be
# readable on both dark and light terminal backgrounds.
FALLBACK_COLORS = [
    "magenta",
    "yellow",
    "red",
    "cyan",
    "mediumpurple",
    "coral",
    "gold",
    "orchid",
    "salmon",
    "turquoise",
    "violet",
    "hotpink",
    "khaki",
    "tomato",
    "deeppink",
    "darkturquoise",
]


def color_for_member(name: str) -> str:
    """Return a deterministic color for a member name.

    Known members get their brand color from BRAND_MEMBER_COLORS.
    Unknown members fall back to a stable hash into FALLBACK_COLORS
    (not affected by PYTHONHASHSEED randomization).
    """
    if name in BRAND_MEMBER_COLORS:
        return BRAND_MEMBER_COLORS[name]
    idx = sum(ord(c) for c in name) % len(FALLBACK_COLORS)
    return FALLBACK_COLORS[idx]


class ColoredMentionMarkdown:
    """Rich renderable that renders Markdown with @mentions in member colors.

    Wraps RichMarkdown and intercepts rendered Segments, splitting any that
    contain @member tokens and applying the member's brand color + bold style.
    """

    def __init__(self, body: str, member_names: list[str]) -> None:
        self.body = body
        # Build a color lookup for known names plus special tokens
        self.member_colors: dict[str, str] = {}
        for name in member_names:
            self.member_colors[name] = color_for_member(name)
        self.member_colors["all"] = "white"
        self.member_colors["king"] = "white"
        # Cache Style objects per color to avoid creating new ones on every render
        self.mention_styles: dict[str, Style] = {
            name: Style(color=color, bold=True) for name, color in self.member_colors.items()
        }
        # Pre-compile pattern
        if self.member_colors:
            names = "|".join(re.escape(n) for n in self.member_colors)
            self.pattern: re.Pattern[str] | None = re.compile(rf"(?<!\w)@({names})(?!\w)")
        else:
            self.pattern = None

    def __rich_console__(self, console, options):
        md = RichMarkdown(self.body)
        for segment in md.__rich_console__(console, options):
            if not isinstance(segment, Segment) or not self.pattern:
                yield segment
                continue

            text = segment.text
            style = segment.style or Style()

            if "@" not in text:
                yield segment
                continue

            parts = self.pattern.split(text)
            if len(parts) == 1:
                yield segment
                continue

            # parts alternates: [before, captured_name, after, ...]
            for i, part in enumerate(parts):
                if not part:
                    continue
                if i % 2 == 1:
                    cached = self.mention_styles.get(part, self.mention_styles.get("all"))
                    try:
                        mention_style = style + cached if cached else style
                    except (AttributeError, TypeError):
                        mention_style = cached or style
                    yield Segment(f"@{part}", mention_style)
                else:
                    yield Segment(part, style)


class MessagePanel(Widget):
    """A finalized message rendered with Textual's native Markdown widget.

    Uses the built-in Markdown widget for proper code-fence scrolling,
    clickable links, and table rendering.  Click on a council member's
    message to reply (prefills input with @mention).  Shift+click copies
    the message body to the clipboard.
    """

    class Reply(Message):
        """Posted when the user clicks a member message to reply."""

        def __init__(self, sender: str, body: str) -> None:
            super().__init__()
            self.sender = sender
            self.body = body

    def __init__(
        self,
        sender: str,
        body: str,
        member_names: list[str] | None = None,
        timestamp: str | None = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.sender = sender
        self.body = body
        self.member_names: list[str] = member_names or []
        self.timestamp_str = timestamp

    def compose(self):
        yield TextualMarkdown(self.body)

    def compose_text(self) -> str:
        """Format the display text (sender shown in border title, not body)."""
        return self.body

    def on_mount(self) -> None:
        if self.sender == "king":
            self.add_class("king")
            self.border_title = "you"
        else:
            color = color_for_member(self.sender)
            self.styles.border = ("round", color)
            title = self.sender
            if self.timestamp_str:
                title = f"{self.sender} · {self.timestamp_str}"
            self.border_title = title
            self.border_subtitle = "click: reply \u00b7 shift: copy"

    def on_click(self, event) -> None:
        """Handle click: reply toggle (default) or copy (shift)."""
        event.stop()
        if self.sender == "king":
            return
        if event.shift:
            self.do_copy()
        else:
            self.post_message(self.Reply(sender=self.sender, body=self.body))

    def do_copy(self) -> None:
        """Copy message body to the system clipboard."""
        try:
            copy_to_clipboard(self.body)
            self.border_subtitle = "copied!"
        except ClipboardUnavailableError:
            self.border_subtitle = "clipboard unavailable"
        except subprocess.CalledProcessError:
            self.border_subtitle = "copy failed"
        self.set_timer(2.0, self.reset_subtitle)

    def reset_subtitle(self) -> None:
        """Reset subtitle back to the action hints after feedback timeout."""
        self.border_subtitle = "click: reply \u00b7 shift: copy"


class StreamingPanel(Widget):
    """An in-progress response that renders streaming Markdown.

    Uses Textual's Markdown widget so formatting (bold, code fences, etc.)
    is visible *during* streaming, not only after finalization.  Markdown
    re-renders are throttled to avoid excessive work on rapid token deltas.
    """

    THROTTLE_SECONDS = 0.10  # max render frequency

    def __init__(self, sender: str, **kwargs) -> None:
        super().__init__(**kwargs)
        self.sender = sender
        self.content_text = ""
        self.md: TextualMarkdown | None = None
        self.last_render_time: float = 0.0
        self.render_pending: bool = False

    def compose(self):
        self.md = TextualMarkdown("")
        yield self.md

    def on_mount(self) -> None:
        color = color_for_member(self.sender)
        self.styles.border = ("round", color)
        self.update_title()

    def update_title(self) -> None:
        n = len(self.content_text)
        self.border_title = f"{self.sender} (streaming \u00b7 {n:,} chars)"

    def update_content(self, text: str) -> None:
        """Replace the streamed text and refresh the display."""
        self.content_text = text
        self.update_title()
        if self.md is None:
            return
        now = time.monotonic()
        if now - self.last_render_time >= self.THROTTLE_SECONDS:
            self.flush_markdown()
        elif not self.render_pending:
            self.render_pending = True
            self.set_timer(self.THROTTLE_SECONDS, self.flush_markdown)

    def flush_markdown(self) -> None:
        """Push current content to the Markdown widget."""
        if self.md is not None:
            self.md.update(self.content_text + " \u258d")
            self.last_render_time = time.monotonic()
            self.render_pending = False


class WaitingPanel(Widget):
    """Animated placeholder shown before streaming starts."""

    def __init__(self, sender: str, **kwargs) -> None:
        super().__init__(**kwargs)
        self.sender = sender

    def compose(self):
        yield LoadingIndicator()

    def on_mount(self) -> None:
        color = color_for_member(self.sender)
        self.styles.border = ("dashed", color)
        self.border_title = f"{self.sender} \u2014 waiting..."


def format_error_body(error: str, sender: str, timed_out: bool, interrupted: bool) -> str:
    """Build a user-friendly error body with context and retry hint.

    Extracts the meaningful part of the error and appends an actionable
    suggestion so the user knows what to try next.
    """
    if interrupted:
        return error  # Already says "*Interrupted*", no extra noise needed

    # Extract the useful detail from the marker format *Error: ...*
    detail = error
    if detail.startswith("*Error:") and detail.endswith("*"):
        detail = detail[len("*Error:") :].rstrip("*").strip()
    elif detail.startswith("*") and detail.endswith("*"):
        detail = detail.strip("* ").strip()

    lines: list[str] = []
    if timed_out:
        lines.append(f"**Timed out** — {detail}")
        lines.append("")
        lines.append(f"Retry: send the message again or `@{sender}` to retry just this member.")
    elif "empty response" in error.lower():
        lines.append("**Empty response** — the agent returned no text.")
        lines.append("")
        lines.append(f"Retry: rephrase your question or `@{sender}` to try again.")
    else:
        lines.append(f"**Error** — {detail}")
        lines.append("")
        lines.append("Retry: send the message again. If it persists, check agent config with `kd council status`.")

    return "\n".join(lines)


class ErrorPanel(Static):
    """An error or timeout display with context and retry hints.

    Shows what failed (timeout, error detail, interruption) and suggests
    retry actions so the user knows how to recover.
    """

    def __init__(self, sender: str, error: str, timed_out: bool = False, **kwargs) -> None:
        super().__init__(**kwargs)
        self.sender = sender
        self.error = error
        self.timed_out = timed_out

    def on_mount(self) -> None:
        interrupted = "*Interrupted" in self.error or "*[Interrupted" in self.error

        if interrupted:
            label = "interrupted"
            self.styles.border = ("round", "yellow")
        elif self.timed_out:
            label = "timed out"
            self.styles.border = ("round", "red")
        else:
            label = "error"
            self.styles.border = ("round", "red")

        self.border_title = f"{self.sender} — {label}"
        body = format_error_body(self.error, self.sender, self.timed_out, interrupted)
        self.update(RichMarkdown(body))


class ThinkingPanel(Static):
    """Collapsible panel for thinking/reasoning tokens.

    Starts expanded while thinking streams in.  Auto-collapses on first answer
    token into a one-line summary.  Click or Enter toggles expanded/collapsed.
    Once the user manually toggles, auto-collapse is disabled (user_pinned).
    """

    def __init__(self, sender: str, **kwargs) -> None:
        super().__init__(**kwargs)
        self.sender = sender
        self.thinking_text = ""
        self.expanded = True
        self.user_pinned = False
        self.start_time = time.monotonic()

    def on_mount(self) -> None:
        color = color_for_member(self.sender)
        self.styles.border = ("dashed", color)
        self.update_display()

    def on_click(self, event) -> None:
        """Toggle expanded/collapsed on click."""
        event.stop()
        self.user_pinned = True
        self.expanded = not self.expanded
        if self.expanded:
            self.remove_class("collapsed")
        else:
            self.add_class("collapsed")
        self.update_display()

    def update_thinking(self, text: str) -> None:
        """Update with new accumulated thinking text."""
        self.thinking_text = text
        if self.expanded:
            self.update_display()

    def collapse(self) -> None:
        """Auto-collapse (called when answer tokens start arriving)."""
        if self.user_pinned:
            return
        self.expanded = False
        self.add_class("collapsed")
        self.update_display()

    def update_display(self) -> None:
        """Refresh the rendered content based on expanded/collapsed state."""
        n = len(self.thinking_text)
        elapsed = time.monotonic() - self.start_time
        if self.expanded:
            self.border_title = f"{self.sender} thinking \u00b7 {n:,} chars \u00b7 {format_elapsed(elapsed)}"
            self.update(self.thinking_text + "\u258d")  # cursor
        else:
            self.border_title = f"\u25b6 {self.sender} thinking \u00b7 {n:,} chars \u00b7 {format_elapsed(elapsed)}"
            self.update("")


# ---------------------------------------------------------------------------
# Slash command definitions and hint bar
# ---------------------------------------------------------------------------

SLASH_COMMANDS: list[tuple[str, str]] = [
    ("/help", "show this help"),
    ("/h", "show this help (shortcut)"),
    ("/copy [member]", "copy last agent response to clipboard"),
    ("/mute <member>", "exclude member from broadcast"),
    ("/mute", "show currently muted members"),
    ("/unmute <member>", "re-include member in broadcast"),
    ("/writable", "toggle writable mode (allow/deny file edits)"),
    ("/writeable", "toggle writable mode (alias)"),
    ("/quit", "quit kd council chat"),
    ("/exit", "quit kd council chat"),
]


def match_commands(prefix: str) -> list[tuple[str, str]]:
    """Return slash commands whose name starts with the given prefix.

    The prefix is compared against the command word (the part before any
    space / argument placeholder).  An empty prefix or bare "/" returns all
    commands.
    """
    prefix = prefix.lower()
    matches = []
    for cmd, desc in SLASH_COMMANDS:
        cmd_word = cmd.split()[0]
        if cmd_word.startswith(prefix):
            matches.append((cmd, desc))
    return matches


def suggest_command(unknown: str) -> str | None:
    """Suggest the closest known command for a mistyped one.

    Returns the command word (e.g. "/writable") or None if nothing is close.
    Uses longest common prefix — needs at least 1 character beyond the "/"
    to count (i.e. prefix length >= 2 including the slash).
    """
    unknown = unknown.lower()
    # Collect unique command words
    seen: set[str] = set()
    candidates: list[str] = []
    for cmd, _desc in SLASH_COMMANDS:
        word = cmd.split()[0]
        if word not in seen:
            seen.add(word)
            candidates.append(word)

    best: str | None = None
    best_prefix_len = 1  # require prefix > 1 char (/ + at least 1 real char)
    for candidate in candidates:
        prefix_len = 0
        for a, b in zip(unknown, candidate, strict=False):
            if a != b:
                break
            prefix_len += 1
        if prefix_len > best_prefix_len:
            best_prefix_len = prefix_len
            best = candidate
    return best


class CommandHintBar(Static):
    """A hint bar that shows matching slash commands above the input area.

    Hidden by default. Call show_hints() with a prefix to display
    matching commands, or hide_hints() to remove it.
    """

    def show_hints(self, prefix: str) -> None:
        """Show commands matching prefix. Hides if none match."""
        matches = match_commands(prefix)
        if not matches:
            self.hide_hints()
            return
        lines = [f"  {cmd}  {desc}" for cmd, desc in matches]
        self.update("\n".join(lines))
        self.add_class("visible")

    def hide_hints(self) -> None:
        """Hide the hint bar."""
        self.remove_class("visible")
        self.update("")

    def first_match(self, prefix: str) -> str | None:
        """Return the command word of the first matching command, or None."""
        matches = match_commands(prefix)
        if not matches:
            return None
        return matches[0][0].split()[0]
