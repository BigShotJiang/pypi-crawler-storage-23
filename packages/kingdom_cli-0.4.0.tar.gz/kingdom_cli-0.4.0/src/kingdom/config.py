"""Configuration system for Kingdom.

Loads agent definitions, council composition, peasant settings, and per-phase
prompts from ``.kd/config.json``. All fields are optional — sensible defaults
are provided for zero-config operation.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, replace
from pathlib import Path

from kingdom.state import state_root

# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class AgentDef:
    """User-facing agent configuration from config.json."""

    backend: str  # claude_code, codex, cursor
    model: str = ""
    prompt: str = ""
    prompts: dict[str, str] = field(default_factory=dict)
    extra_flags: list[str] = field(default_factory=list)


@dataclass
class PromptsConfig:
    """Per-phase default prompts applied to all agents."""

    council: str = ""
    design: str = ""
    review: str = ""
    peasant: str = ""


@dataclass
class AskConfig:
    """Settings for ``kd council ask`` (fire-and-forget queries)."""

    mode: str = "broadcast"
    auto_messages: int = -1


@dataclass
class ChatConfig:
    """Settings for ``kd council chat`` (interactive group chat).

    Modes: natural (default), round_robin, manual, broadcast.
    """

    mode: str = "natural"
    auto_rounds: int = 1


@dataclass
class CouncilConfig:
    """Council composition and settings."""

    members: list[str] = field(default_factory=list)
    timeout: int = 600
    preamble: str = ""
    thinking_visibility: str = "auto"
    writable: bool = False
    ask: AskConfig = field(default_factory=AskConfig)
    chat: ChatConfig = field(default_factory=ChatConfig)


@dataclass
class PeasantConfig:
    """Peasant worker settings."""

    agent: str = "claude"
    max_iterations: int = 50


@dataclass
class KingdomConfig:
    """Top-level configuration, loaded from .kd/config.json."""

    agents: dict[str, AgentDef] = field(default_factory=dict)
    prompts: PromptsConfig = field(default_factory=PromptsConfig)
    council: CouncilConfig = field(default_factory=CouncilConfig)
    peasant: PeasantConfig = field(default_factory=PeasantConfig)


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_AGENTS: dict[str, AgentDef] = {
    "claude": AgentDef(backend="claude_code"),
    "codex": AgentDef(backend="codex"),
}


def default_config() -> KingdomConfig:
    """Return the built-in default configuration."""
    agents = {name: AgentDef(backend=a.backend) for name, a in DEFAULT_AGENTS.items()}
    return KingdomConfig(
        agents=agents,
        prompts=PromptsConfig(),
        council=CouncilConfig(members=list(agents)),
        peasant=PeasantConfig(agent="claude"),
    )


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

VALID_BACKENDS = {"claude_code", "codex", "cursor"}
VALID_AGENT_KEYS = {"backend", "model", "prompt", "prompts", "extra_flags"}
VALID_PROMPTS_KEYS = {"council", "design", "review", "peasant"}
VALID_COUNCIL_KEYS = {
    "members",
    "timeout",
    "preamble",
    "thinking_visibility",
    "writable",
    "ask",
    "chat",
}
VALID_ASK_KEYS = {"mode", "auto_messages"}
VALID_CHAT_KEYS = {"mode", "auto_rounds"}
DEPRECATED_COUNCIL_KEYS = {"auto_messages", "mode", "chat_mode", "chat_auto_rounds"}
VALID_PEASANT_KEYS = {"agent", "max_iterations"}
VALID_TOP_KEYS = {"agents", "prompts", "council", "peasant"}
VALID_AGENT_PROMPT_PHASES = {"council", "design", "review", "peasant"}


def check_unknown_keys(data: dict, valid: set[str], context: str) -> None:
    """Raise ValueError if data contains keys not in valid set."""
    unknown = set(data) - valid
    if unknown:
        raise ValueError(f"Unknown keys in {context}: {', '.join(sorted(unknown))}")


def validate_agent(name: str, data: dict) -> AgentDef:
    """Validate and construct an AgentDef from a raw dict."""
    check_unknown_keys(data, VALID_AGENT_KEYS, f"agents.{name}")

    backend = data.get("backend")
    if not backend:
        raise ValueError(f"Agent '{name}' is missing required field 'backend'")
    if not isinstance(backend, str):
        raise ValueError(f"agents.{name}.backend must be a string, got {type(backend).__name__}")
    if backend not in VALID_BACKENDS:
        raise ValueError(
            f"agents.{name}.backend '{backend}' is not a known backend. Valid backends: {', '.join(sorted(VALID_BACKENDS))}"
        )

    model = data.get("model", "")
    if model and not isinstance(model, str):
        raise ValueError(f"agents.{name}.model must be a string, got {type(model).__name__}")

    prompt = data.get("prompt", "")
    if prompt and not isinstance(prompt, str):
        raise ValueError(f"agents.{name}.prompt must be a string, got {type(prompt).__name__}")

    prompts = data.get("prompts", {})
    if not isinstance(prompts, dict):
        raise ValueError(f"agents.{name}.prompts must be an object, got {type(prompts).__name__}")
    bad_phases = set(prompts) - VALID_AGENT_PROMPT_PHASES
    if bad_phases:
        raise ValueError(f"Unknown prompt phases in agents.{name}.prompts: {', '.join(sorted(bad_phases))}")
    for phase, val in prompts.items():
        if not isinstance(val, str):
            raise ValueError(f"agents.{name}.prompts.{phase} must be a string, got {type(val).__name__}")

    extra_flags = data.get("extra_flags", [])
    if not isinstance(extra_flags, list):
        raise ValueError(f"agents.{name}.extra_flags must be a list, got {type(extra_flags).__name__}")
    for i, flag in enumerate(extra_flags):
        if not isinstance(flag, str):
            raise ValueError(f"agents.{name}.extra_flags[{i}] must be a string, got {type(flag).__name__}")

    return AgentDef(
        backend=backend,
        model=model or "",
        prompt=prompt or "",
        prompts=prompts,
        extra_flags=extra_flags,
    )


def validate_prompts(data: dict) -> PromptsConfig:
    """Validate and construct a PromptsConfig from a raw dict."""
    check_unknown_keys(data, VALID_PROMPTS_KEYS, "prompts")
    for key in VALID_PROMPTS_KEYS:
        val = data.get(key)
        if val is not None and not isinstance(val, str):
            raise ValueError(f"prompts.{key} must be a string, got {type(val).__name__}")
    return PromptsConfig(
        council=data.get("council", ""),
        design=data.get("design", ""),
        review=data.get("review", ""),
        peasant=data.get("peasant", ""),
    )


def validate_ask(data: dict) -> AskConfig:
    """Validate and construct an AskConfig from a raw dict."""
    check_unknown_keys(data, VALID_ASK_KEYS, "council.ask")

    valid_modes = {"broadcast", "sequential"}
    mode = data.get("mode", "broadcast")
    if not isinstance(mode, str):
        raise ValueError(f"council.ask.mode must be a string, got {type(mode).__name__}")
    if mode not in valid_modes:
        raise ValueError(f"council.ask.mode must be one of {', '.join(sorted(valid_modes))}, got '{mode}'")

    auto_messages = data.get("auto_messages", -1)
    if not isinstance(auto_messages, int):
        raise ValueError(f"council.ask.auto_messages must be an integer, got {type(auto_messages).__name__}")
    if auto_messages < -1:
        raise ValueError(
            f"council.ask.auto_messages must be -1 (auto), 0 (disabled), or a positive integer, got {auto_messages}"
        )

    return AskConfig(mode=mode, auto_messages=auto_messages)


def validate_chat(data: dict) -> ChatConfig:
    """Validate and construct a ChatConfig from a raw dict."""
    check_unknown_keys(data, VALID_CHAT_KEYS, "council.chat")

    valid_modes = {"natural", "round_robin", "manual", "broadcast"}
    mode = data.get("mode", "natural")
    if not isinstance(mode, str):
        raise ValueError(f"council.chat.mode must be a string, got {type(mode).__name__}")
    if mode not in valid_modes:
        raise ValueError(f"council.chat.mode must be one of {', '.join(sorted(valid_modes))}, got '{mode}'")

    auto_rounds = data.get("auto_rounds", 1)
    if not isinstance(auto_rounds, int):
        raise ValueError(f"council.chat.auto_rounds must be an integer, got {type(auto_rounds).__name__}")
    if auto_rounds < 0:
        raise ValueError(f"council.chat.auto_rounds must be non-negative, got {auto_rounds}")

    return ChatConfig(mode=mode, auto_rounds=auto_rounds)


def validate_council(data: dict) -> CouncilConfig:
    """Validate and construct a CouncilConfig from a raw dict."""
    # Fail fast on deprecated flat keys
    deprecated = DEPRECATED_COUNCIL_KEYS & set(data)
    if deprecated:
        raise ValueError(
            f"Deprecated council keys: {', '.join(sorted(deprecated))}. "
            "Migrate to nested format:\n"
            "  council:\n"
            "    ask:\n"
            "      mode: broadcast\n"
            "      auto_messages: -1\n"
            "    chat:\n"
            "      mode: broadcast\n"
            "      auto_rounds: 1"
        )

    check_unknown_keys(data, VALID_COUNCIL_KEYS, "council")

    members = data.get("members", [])
    if not isinstance(members, list):
        raise ValueError(f"council.members must be a list, got {type(members).__name__}")
    for i, m in enumerate(members):
        if not isinstance(m, str):
            raise ValueError(f"council.members[{i}] must be a string, got {type(m).__name__}")

    timeout = data.get("timeout", 600)
    if not isinstance(timeout, int):
        raise ValueError(f"council.timeout must be an integer, got {type(timeout).__name__}")
    if timeout <= 0:
        raise ValueError(f"council.timeout must be positive, got {timeout}")

    preamble = data.get("preamble", "")
    if not isinstance(preamble, str):
        raise ValueError(f"council.preamble must be a string, got {type(preamble).__name__}")
    if "preamble" in data and not preamble:
        raise ValueError("council.preamble must be non-empty if specified")

    valid_thinking = {"auto", "show", "hide"}
    thinking_visibility = data.get("thinking_visibility", "auto")
    if not isinstance(thinking_visibility, str):
        raise ValueError(f"council.thinking_visibility must be a string, got {type(thinking_visibility).__name__}")
    if thinking_visibility not in valid_thinking:
        raise ValueError(
            f"council.thinking_visibility must be one of {', '.join(sorted(valid_thinking))}, got '{thinking_visibility}'"
        )

    writable = data.get("writable", False)
    if not isinstance(writable, bool):
        raise ValueError(f"council.writable must be a boolean, got {type(writable).__name__}")

    ask_data = data.get("ask", {})
    if not isinstance(ask_data, dict):
        raise ValueError(f"council.ask must be an object, got {type(ask_data).__name__}")
    ask = validate_ask(ask_data)

    chat_data = data.get("chat", {})
    if not isinstance(chat_data, dict):
        raise ValueError(f"council.chat must be an object, got {type(chat_data).__name__}")
    chat = validate_chat(chat_data)

    return CouncilConfig(
        members=members,
        timeout=timeout,
        preamble=preamble,
        thinking_visibility=thinking_visibility,
        writable=writable,
        ask=ask,
        chat=chat,
    )


def validate_peasant(data: dict) -> PeasantConfig:
    """Validate and construct a PeasantConfig from a raw dict."""
    check_unknown_keys(data, VALID_PEASANT_KEYS, "peasant")

    agent = data.get("agent", "claude")
    if not isinstance(agent, str):
        raise ValueError(f"peasant.agent must be a string, got {type(agent).__name__}")

    max_iterations = data.get("max_iterations", 50)
    if not isinstance(max_iterations, int):
        raise ValueError(f"peasant.max_iterations must be an integer, got {type(max_iterations).__name__}")
    if max_iterations <= 0:
        raise ValueError(f"peasant.max_iterations must be positive, got {max_iterations}")

    return PeasantConfig(agent=agent, max_iterations=max_iterations)


def validate_config(data: dict) -> KingdomConfig:
    """Validate a raw dict and construct a KingdomConfig.

    Merges user-provided agents with built-in defaults. Validates types,
    required fields, and cross-references (council members and peasant agent
    must reference defined agents).

    Raises:
        ValueError: On unknown keys, missing required fields, type errors,
            or invalid cross-references.
    """
    check_unknown_keys(data, VALID_TOP_KEYS, "config")

    # Agents: merge defaults with user overrides
    agents_data = data.get("agents", {})
    if not isinstance(agents_data, dict):
        raise ValueError(f"agents must be an object, got {type(agents_data).__name__}")

    agents: dict[str, AgentDef] = {}
    # Start with defaults
    for name, default in DEFAULT_AGENTS.items():
        if name in agents_data:
            agents[name] = validate_agent(name, agents_data[name])
        else:
            agents[name] = AgentDef(backend=default.backend)
    # Add user-defined agents not in defaults
    for name, agent_data in agents_data.items():
        if name not in agents:
            agents[name] = validate_agent(name, agent_data)

    # Prompts
    prompts_data = data.get("prompts", {})
    if not isinstance(prompts_data, dict):
        raise ValueError(f"prompts must be an object, got {type(prompts_data).__name__}")
    prompts = validate_prompts(prompts_data)

    # Council
    council_data = data.get("council", {})
    if not isinstance(council_data, dict):
        raise ValueError(f"council must be an object, got {type(council_data).__name__}")
    council = validate_council(council_data)

    # Default council members to all agents if not specified
    if not council.members:
        council = replace(council, members=list(agents))

    # Peasant
    peasant_data = data.get("peasant", {})
    if not isinstance(peasant_data, dict):
        raise ValueError(f"peasant must be an object, got {type(peasant_data).__name__}")
    peasant = validate_peasant(peasant_data)

    # Cross-reference validation
    defined = set(agents)
    for member in council.members:
        if member not in defined:
            raise ValueError(
                f"council.members references undefined agent '{member}'. Defined agents: {', '.join(sorted(defined))}"
            )
    if peasant.agent not in defined:
        raise ValueError(
            f"peasant.agent references undefined agent '{peasant.agent}'. Defined agents: {', '.join(sorted(defined))}"
        )

    return KingdomConfig(agents=agents, prompts=prompts, council=council, peasant=peasant)


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------


def load_raw_config(base: Path) -> dict:
    """Return the raw dict from .kd/config.json, or {} if absent/empty."""
    config_path = state_root(base) / "config.json"
    if not config_path.exists():
        return {}
    text = config_path.read_text(encoding="utf-8").strip()
    if not text or text == "{}":
        return {}
    data = json.loads(text)
    return data if isinstance(data, dict) else {}


def load_config(base: Path) -> KingdomConfig:
    """Load configuration from .kd/config.json, falling back to defaults.

    Returns default_config() if the file doesn't exist or is empty.

    Raises:
        ValueError: If the file exists but contains invalid JSON or fails
            validation.
    """
    config_path = state_root(base) / "config.json"
    if not config_path.exists():
        return default_config()

    text = config_path.read_text(encoding="utf-8").strip()
    if not text or text == "{}":
        return default_config()

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in {config_path}: {exc}") from exc

    if not isinstance(data, dict):
        raise ValueError(f"Config must be a JSON object, got {type(data).__name__}")

    return validate_config(data)
