from paytechuz.gateways.paynet.client import PaynetGateway

__all__ = ['PaynetGateway']
