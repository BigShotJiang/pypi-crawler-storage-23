RKF21 (Fehlberg)
================

.. automodule:: pathsim.solvers.rkf21
   :members:
   :show-inheritance:
   :undoc-members:
