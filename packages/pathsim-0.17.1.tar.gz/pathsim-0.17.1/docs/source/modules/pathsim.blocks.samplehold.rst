Sample & Hold
=============

.. automodule:: pathsim.blocks.samplehold
   :members:
   :show-inheritance:
   :undoc-members:
