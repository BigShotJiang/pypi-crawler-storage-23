Register
========

.. automodule:: pathsim.utils.register
   :members:
   :show-inheritance:
   :undoc-members:
