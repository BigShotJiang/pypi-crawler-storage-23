SSPRK22
=======

.. automodule:: pathsim.solvers.ssprk22
   :members:
   :show-inheritance:
   :undoc-members:
