DIRK3
=====

.. automodule:: pathsim.solvers.dirk3
   :members:
   :show-inheritance:
   :undoc-members:
