RKDP87 (Dormand-Prince)
=======================

.. automodule:: pathsim.solvers.rkdp87
   :members:
   :show-inheritance:
   :undoc-members:
