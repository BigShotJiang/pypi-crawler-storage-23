Real-time Plotter
=================

.. automodule:: pathsim.utils.realtimeplotter
   :members:
   :show-inheritance:
   :undoc-members:
