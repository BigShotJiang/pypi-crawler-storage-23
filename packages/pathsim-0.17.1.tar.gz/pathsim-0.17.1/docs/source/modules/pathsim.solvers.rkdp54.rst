RKDP54 (Dormand-Prince)
=======================

.. automodule:: pathsim.solvers.rkdp54
   :members:
   :show-inheritance:
   :undoc-members:
