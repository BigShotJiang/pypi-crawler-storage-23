Noise
=====

.. automodule:: pathsim.blocks.noise
   :members:
   :show-inheritance:
   :undoc-members:
