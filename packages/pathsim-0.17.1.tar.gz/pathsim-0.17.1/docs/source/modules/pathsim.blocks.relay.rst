Relay
=====

.. automodule:: pathsim.blocks.relay
   :members:
   :show-inheritance:
   :undoc-members:
