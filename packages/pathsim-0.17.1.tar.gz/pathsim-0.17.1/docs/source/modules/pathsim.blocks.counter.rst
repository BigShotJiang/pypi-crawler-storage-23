Counter
=======

.. automodule:: pathsim.blocks.counter
   :members:
   :show-inheritance:
   :undoc-members:
