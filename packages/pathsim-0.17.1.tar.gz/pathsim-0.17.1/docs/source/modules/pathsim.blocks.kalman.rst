Kalman Filter
=============

.. automodule:: pathsim.blocks.kalman
   :members:
   :show-inheritance:
   :undoc-members:
