RKF78 (Fehlberg)
================

.. automodule:: pathsim.solvers.rkf78
   :members:
   :show-inheritance:
   :undoc-members:
