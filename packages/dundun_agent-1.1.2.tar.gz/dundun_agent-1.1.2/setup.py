from setuptools import setup, find_packages

setup(
    name="dundun-agent",
    version="1.1.2",
    description="Dundun Agent - AI-powered coding assistant",
    packages=find_packages(where="src", exclude=["integrations.rocketchat", "integrations.rocketchat.*"]),
    package_dir={"": "src"},
    package_data={"": ["*.txt", "*.md"]},
    install_requires=[
        # 基础依赖
        "openai>=1.0.0",
        "anthropic>=0.76.0",
        "httpx>=0.25.0",
        "tiktoken>=0.7.0",
        "pydantic>=2.0.0",
        "typer>=0.9.0",
        "rich>=14.0.0",
        "textual>=0.80.0",
        "prompt_toolkit>=3.0.0",
        "tenacity>=8.0.0",
        "python-dotenv>=1.0.0",
        "pyyaml>=6.0.0",
        "mcp>=1.0.0",
        "aiohttp>=3.9.0",
        # WebSocket 服务器依赖
        "fastapi>=0.104.0",
        "uvicorn[standard]>=0.24.0",
        "websockets>=12.0",
    ],
    entry_points={
        "console_scripts": [
            "dundun=main:main",
        ],
    },
    python_requires=">=3.10",
)
