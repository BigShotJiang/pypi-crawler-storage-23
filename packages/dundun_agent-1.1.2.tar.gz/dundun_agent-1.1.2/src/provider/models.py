"""
模型定义 - 静态内置模型目录（常量表）

注意：该模块仅保留数据结构与常量，不提供查询逻辑。
所有模型查询、合并配置、默认值等逻辑统一由 core.model_manager.ModelManager 提供。
"""

from dataclasses import dataclass
from typing import Dict, List


@dataclass(frozen=True)
class ModelInfo:
    """内置模型信息（静态常量）"""

    provider: str
    type: str
    name: str
    context_window: int


# 结构化模型目录 (按 provider 分组)
MODELS_BY_PROVIDER: Dict[str, List[ModelInfo]] = {
    "openai": [
        # GPT-5 系列 (2025)
        ModelInfo(provider="openai", type="chat", name="gpt-5.2", context_window=400000),
        ModelInfo(provider="openai", type="chat", name="gpt-5.1", context_window=400000),
        ModelInfo(provider="openai", type="code", name="gpt-5.2-codex", context_window=400000),
        ModelInfo(provider="openai", type="code", name="gpt-5-codex", context_window=400000),
    ],
    "anthropic": [
        # Claude 4 系列 (2025)
        ModelInfo(provider="anthropic", type="chat", name="claude-opus-4-6", context_window=200000),
        ModelInfo(provider="anthropic", type="chat", name="claude-sonnet-4-6", context_window=200000),
        ModelInfo(provider="anthropic", type="chat", name="claude-opus-4-5", context_window=200000),
        ModelInfo(provider="anthropic", type="chat", name="claude-sonnet-4-5", context_window=200000),
    ],
    "glm": [
        # GLM-5 系列 (2026)
        ModelInfo(provider="glm", type="chat", name="glm-5", context_window=200000),
        ModelInfo(provider="glm", type="chat", name="glm-4.7", context_window=200000),
        ModelInfo(provider="glm", type="chat", name="glm-4.6", context_window=200000),
    ],
    "google": [
        ModelInfo(provider="google", type="chat", name="gemini-3.1-pro-preview", context_window=1048576),
        ModelInfo(provider="google", type="chat", name="gemini-3-pro-preview", context_window=1048576),
        ModelInfo(provider="google", type="chat", name="gemini-3-flash-preview", context_window=1048576),
        ModelInfo(provider="google", type="chat", name="gemini-2.5-flash", context_window=1048576),
    ],
    "minimax": [
        # M2.5 系列 (2026)
        ModelInfo(provider="minimax", type="chat", name="MiniMax-M2.5", context_window=204800),
        ModelInfo(provider="minimax", type="chat", name="MiniMax-M2.5-highspeed", context_window=204800),
        # M2 / M1 系列
        ModelInfo(provider="minimax", type="chat", name="MiniMax-M2", context_window=204800),
        ModelInfo(provider="minimax", type="chat", name="MiniMax-M1", context_window=204800),
    ],
}

