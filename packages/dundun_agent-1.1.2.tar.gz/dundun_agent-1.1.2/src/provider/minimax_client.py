"""
MiniMax API 客户端

兼容 Anthropic SDK，base_url: https://api.minimaxi.com/anthropic
支持模型: MiniMax-M2.5
"""

from typing import Optional
import httpx
from anthropic import AsyncAnthropic

from .anthropic_client import AnthropicClient


class MinimaxClient(AnthropicClient):
    """
    MiniMax API 客户端

    继承 AnthropicClient，复用 Anthropic SDK 的消息格式和流式处理。
    MiniMax 要求在 Authorization 头中以 Bearer 方式传递 API key，
    而非 Anthropic SDK 默认的 x-api-key 头。
    """

    @property
    def provider(self) -> str:
        """返回提供商名称"""
        return "minimax"

    def _clean_env(self):
        """MiniMax 不需要清理 ANTHROPIC_AUTH_TOKEN"""
        pass

    def _create_sdk_client(self, api_key: str, base_url: Optional[str] = None) -> AsyncAnthropic:
        """覆盖父类，添加 Authorization: Bearer 头以满足 MiniMax 认证要求"""
        client_kwargs = {
            "api_key": api_key,
            "timeout": httpx.Timeout(300.0, connect=30.0),
            "max_retries": 5,
            "default_headers": {
                "Authorization": f"Bearer {api_key}",
            },
        }
        if base_url:
            client_kwargs["base_url"] = base_url
        return AsyncAnthropic(**client_kwargs)
