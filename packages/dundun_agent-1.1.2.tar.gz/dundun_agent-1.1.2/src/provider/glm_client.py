"""
GLM (智谱) API 客户端

继承 OpenAIClient，复用 OpenAI SDK 的消息格式和流式处理。
GLM 使用 OpenAI 兼容 API，但需要在请求头中添加特定参数。
"""

import httpx
from typing import Optional
from openai import AsyncOpenAI

from .openai_client import OpenAIClient


class GLMClient(OpenAIClient):
    """
    GLM (智谱) API 客户端

    继承 OpenAIClient，复用 OpenAI SDK 的消息格式和流式处理。
    GLM 使用 OpenAI 兼容 API。
    """

    def __init__(
        self,
        model: str,
        api_key: str,
        base_url: Optional[str] = None,
        **kwargs
    ):
        """
        初始化 GLM 客户端

        Args:
            model: 模型名称
            api_key: API 密钥
            base_url: API 基础 URL（可选）
            **kwargs: 其他参数
        """
        # GLM 默认 base_url
        if not base_url:
            base_url = "https://open.bigmodel.cn/api/coding/paas/v4"

        # 先调用父类 __init__ 初始化基本属性
        super().__init__(model, api_key, base_url, **kwargs)

        # 覆盖 client，添加 GLM 所需的额外配置
        self.client = AsyncOpenAI(
            api_key=api_key,
            base_url=base_url,
            timeout=httpx.Timeout(300.0, connect=30.0),
            max_retries=5,
        )

    @property
    def provider(self) -> str:
        """返回提供商名称"""
        return "glm"
