"""LLM provider package.

NOTE: Keep this module lightweight.

Avoid importing concrete client implementations or factory at import time to prevent
side effects and circular imports. Import those from their concrete modules:
- provider.factory.ModelClientFactory
- provider.openai_client.OpenAIClient
- provider.anthropic_client.AnthropicClient
- ...

Safe exports here are pure data structures and static model catalog.
"""

from .base import (
    BaseModelClient,
    Message,
    MessageRole,
    SYSTEM_ROLES,
    ToolCall,
    ToolResult,
    ToolDefinition,
    StreamChunk,
    CompletionResponse,
    TokenUsage,
)
from .models import ModelInfo, MODELS_BY_PROVIDER

__all__ = [
    "BaseModelClient",
    "Message",
    "MessageRole",
    "SYSTEM_ROLES",
    "ToolCall",
    "ToolResult",
    "ToolDefinition",
    "StreamChunk",
    "CompletionResponse",
    "TokenUsage",
    "ModelInfo",
    "MODELS_BY_PROVIDER",
]
