"""
Core 模块
包含会话管理、权限系统、上下文管理等核心功能

注意：LLM 客户端已移动到 provider 包，请直接从 provider 导入：
    from provider import BaseModelClient, Message, OpenAIClient, ...
"""

from .session import (
    SessionInfo,
    SessionStorage,
    PersistentSessionManager,
    get_session_manager,
)

from .permission import (
    PermissionAction,
    PermissionRule,
    PermissionRuleset,
    PermissionManager,
    PermissionDeniedError,
    get_permission_manager,
)

# Context 模块已移动到 src/context/
# from context import BaseContext, DefaultContext, ContextConfig

from .prompt import (
    PromptLayer,
    PromptPart,
    SystemPrompt,
    get_system_prompt,
    load_agent_prompt,
    load_utility_prompt,
)

__all__ = [
    # Session
    "SessionInfo",
    "SessionStorage",
    "PersistentSessionManager",
    "get_session_manager",
    # Permission
    "PermissionAction",
    "PermissionRule",
    "PermissionRuleset",
    "PermissionManager",
    "PermissionDeniedError",
    "get_permission_manager",
    # Prompt
    "PromptLayer",
    "PromptPart",
    "SystemPrompt",
    "get_system_prompt",
    "load_agent_prompt",
    "load_utility_prompt",
]
