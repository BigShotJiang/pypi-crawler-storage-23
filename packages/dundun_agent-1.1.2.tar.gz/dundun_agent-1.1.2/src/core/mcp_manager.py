import os
import asyncio
from contextlib import AsyncExitStack
from typing import List, Dict, Any, Callable, Optional

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.client.streamable_http import streamablehttp_client

from .config import MCPConfig, MCPServerConfig
from .logger import log_event
from tools.base import BaseTool
from tools.mcp_tool import MCPTool


class MCPManager:
    def __init__(
        self,
        config: MCPConfig,
        on_tools_updated: Optional[Callable[[List[BaseTool]], None]] = None,
    ):
        self.config = config
        self.exit_stack = AsyncExitStack()
        self.sessions: List[ClientSession] = []
        self.tools: List[BaseTool] = []
        self._on_tools_updated = on_tools_updated
        self._ready = False
        self._ready_event = asyncio.Event()

    @property
    def is_ready(self) -> bool:
        return self._ready

    async def wait_until_ready(self, timeout: float = 30.0) -> bool:
        """等待 MCP 连接就绪，返回是否成功"""
        try:
            await asyncio.wait_for(self._ready_event.wait(), timeout=timeout)
            return True
        except asyncio.TimeoutError:
            return False

    async def connect_all(self):
        """Connect to all enabled MCP servers.

        目标：
        - 单个 server 连接失败/卡住不阻塞其它 server 的 tools 可用性
        - 每个 server 初始化完成后即可更新 tools（增量更新）
        - 并发连接，提升启动速度
        """

        CONNECT_TIMEOUT = 60.0

        async def _connect_one(server_conf: MCPServerConfig):
            if not server_conf.enabled:
                log_event("mcp_server_connect_result", server=server_conf.name, status="disabled")
                return

            status = "unknown"
            error_message: Optional[str] = None

            try:
                if server_conf.type == "stdio":
                    await asyncio.wait_for(
                        self._connect_stdio(server_conf), timeout=CONNECT_TIMEOUT
                    )
                    status = "connected"
                elif server_conf.type in ["streamableHttp", "sse", "http"]:
                    await asyncio.wait_for(
                        self._connect_streamable_http(server_conf), timeout=CONNECT_TIMEOUT
                    )
                    status = "connected"
                else:
                    status = "error"
                    error_message = f"Unknown MCP server type '{server_conf.type}'"
                    log_event(
                        "mcp_server_error",
                        server=server_conf.name,
                        error=error_message,
                    )
                    return

                # 增量 ready：任一 server 成功连上并完成 tool 发现，就可以对外宣告 ready
                if not self._ready:
                    self._ready = True
                    self._ready_event.set()

            except asyncio.TimeoutError:
                status = "timeout"
                error_message = f"Connect timeout ({CONNECT_TIMEOUT}s)"
                log_event(
                    "mcp_server_error",
                    server=server_conf.name,
                    error=error_message,
                )
            except Exception as e:
                status = "error"
                error_message = str(e)
                log_event(
                    "mcp_server_error",
                    server=server_conf.name,
                    error=error_message,
                )
            finally:
                if status == "unknown":
                    status = "error"
                    error_message = error_message or "Connect finished without status (bug)"

                payload: Dict[str, Any] = {
                    "server": server_conf.name,
                    "type": server_conf.type,
                    "status": status,
                }
                if error_message:
                    payload["error"] = error_message
                log_event("mcp_server_connect_result", **payload)

        tasks = [asyncio.create_task(_connect_one(sc)) for sc in self.config.mcp_servers]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        # 全部完成（无论成功/失败）后，确保 waiters 不会永远卡住
        self._ready = True
        self._ready_event.set()

    async def _connect_stdio(self, server_conf: MCPServerConfig):
        """
        Connect to a stdio-based MCP server.
        """
        if not server_conf.command:
            raise ValueError(
                f"MCP server '{server_conf.name}' configured as stdio but missing 'command'"
            )

        env = os.environ.copy()
        if server_conf.env:
            env.update(server_conf.env)

        # Type assertion to satisfy static checkers, since we validated above
        cmd = server_conf.command if server_conf.command else ""

        server_params = StdioServerParameters(
            command=cmd, args=server_conf.args, env=env
        )

        read, write = await self.exit_stack.enter_async_context(
            stdio_client(server_params)
        )
        session = await self.exit_stack.enter_async_context(ClientSession(read, write))

        await session.initialize()
        self.sessions.append(session)

        await self._discover_tools(session, server_conf.name)

        log_event("mcp_server_connected", server=server_conf.name)

    async def _connect_streamable_http(self, server_conf: MCPServerConfig):
        """
        Connect to a streamableHttp/SSE-based MCP server.
        """
        if not server_conf.url:
            raise ValueError(
                f"MCP server '{server_conf.name}' configured as {server_conf.type} but missing 'url'"
            )

        # 支持 headers（用于 API key 等认证）
        headers = server_conf.headers if server_conf.headers else None

        read, write, _ = await self.exit_stack.enter_async_context(
            streamablehttp_client(server_conf.url, headers=headers)
        )
        session = await self.exit_stack.enter_async_context(ClientSession(read, write))

        await session.initialize()
        self.sessions.append(session)

        await self._discover_tools(session, server_conf.name)

        log_event("mcp_server_connected", server=server_conf.name)

    async def _discover_tools(self, session: ClientSession, server_name: str):
        """
        List tools from the session and create MCPTool instances.
        """
        result = await session.list_tools()

        for tool_model in result.tools:
            mcp_tool = MCPTool(
                name=tool_model.name,
                description=f"[{server_name}] {tool_model.description or ''}",
                input_schema=tool_model.inputSchema,
                session=session,
            )
            self.tools.append(mcp_tool)

        # 增量推送：每个 server 完成 tools discover 后立即通知外部（例如 ServerApp）
        if self._on_tools_updated:
            try:
                self._on_tools_updated(list(self.tools))
            except Exception as e:
                # 回调失败不影响 MCP 自身流程
                log_event(
                    "mcp_tools_update_callback_error",
                    server=server_name,
                    error=str(e),
                )

        # 注意：这里记录 tool_count（不记录 schema 细节，避免日志过大）
        try:
            tool_names = [t.name for t in result.tools]
        except Exception:
            tool_names = []
        log_event(
            "mcp_tools_discovered",
            server=server_name,
            tool_count=len(result.tools),
            tool_names=tool_names[:20],
        )

    def get_tools(self) -> List[BaseTool]:
        return self.tools

    async def cleanup(self):
        """
        Close all connections.
        """
        await self.exit_stack.aclose()
