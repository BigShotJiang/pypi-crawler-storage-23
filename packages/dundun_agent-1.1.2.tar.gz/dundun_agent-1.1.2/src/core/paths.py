"""
路径管理模块

统一路径策略：
- 本地 .dundun/ 目录优先
- 全局 ~/.dundun/ 目录兜底
- 不区分 dev/release 模式
"""
from pathlib import Path
from typing import List, Optional


class PathManager:
    """管理配置、数据、Skill 等路径"""

    APP_NAME = "dundun"

    def __init__(self):
        self._local_dir = Path.cwd() / ".dundun"
        self._global_dir = Path.home() / ".dundun"
        # src/ 目录（用于内置 assets，相对于 src/core/paths.py）
        self._src_root = Path(__file__).parent.parent

    def get_local_dir(self) -> Path:
        """获取本地 .dundun/ 目录（当前工作目录下）"""
        self._local_dir.mkdir(parents=True, exist_ok=True)
        return self._local_dir

    def get_global_dir(self) -> Path:
        """获取全局 ~/.dundun/ 目录"""
        self._global_dir.mkdir(parents=True, exist_ok=True)
        return self._global_dir

    def get_data_dir(self) -> Path:
        """
        获取数据目录（todo、session、permission 等）

        固定使用当前目录下的 .dundun/
        """
        return self.get_local_dir()

    def get_explore_dir(self) -> Path:
        """获取探索数据目录，固定 .dundun/"""
        return self.get_local_dir()

    def get_config_file(self, filename: str) -> Path:
        """
        获取配置文件路径

        查找优先级：
        1. .dundun/{filename}（本地）
        2. ~/.dundun/{filename}（全局）

        如果都不存在，返回本地路径（供创建使用）
        """
        local_file = self._local_dir / filename
        if local_file.exists():
            return local_file

        global_file = self._global_dir / filename
        if global_file.exists():
            return global_file

        # 默认返回本地路径
        return local_file

    def get_all_config_files(self, filename: str) -> List[Path]:
        """
        获取所有匹配的配置文件（用于合并场景，如 MCP）

        返回顺序：本地优先，全局其次
        """
        files = []
        local_file = self._local_dir / filename
        if local_file.exists():
            files.append(local_file)

        global_file = self._global_dir / filename
        if global_file.exists():
            files.append(global_file)

        return files

    def get_all_skill_dirs(self) -> List[Path]:
        """
        获取所有 Skill 目录

        查找优先级：
        1. .dundun/skills/（本地）
        2. ~/.dundun/skills/（全局）
        3. ~/.claude/skills/（Claude 生态兼容）
        4. ~/.agents/skills/（通用 agent 生态兼容）
        5. src/assets/skills/（内置）
        """
        dirs = []

        local_skills = self._local_dir / "skills"
        if local_skills.exists():
            dirs.append(local_skills)

        global_skills = self._global_dir / "skills"
        if global_skills.exists():
            dirs.append(global_skills)

        # Claude 生态兼容
        claude_skills = Path.home() / ".claude" / "skills"
        if claude_skills.exists():
            dirs.append(claude_skills)

        # 通用 agent 生态兼容
        agents_skills = Path.home() / ".agents" / "skills"
        if agents_skills.exists():
            dirs.append(agents_skills)

        # 内置 skill 目录（src/assets/skills/）
        builtin_skills = self._src_root / "assets" / "skills"
        if builtin_skills.exists():
            dirs.append(builtin_skills)

        return dirs

    def get_mode_info(self) -> dict:
        """获取当前路径信息"""
        return {
            "local_dir": str(self._local_dir),
            "global_dir": str(self._global_dir),
            "data_dir": str(self.get_data_dir()),
        }


# 全局实例
_path_manager = None


def get_path_manager() -> PathManager:
    """获取全局 PathManager 实例"""
    global _path_manager
    if _path_manager is None:
        _path_manager = PathManager()
    return _path_manager
