"""
会话 ID 生成器 - 支持层级嵌套
"""

import random
import string


class SessionIDGenerator:
    """会话 ID 生成器"""

    # 字符集：0-9, a-z (36个字符)
    CHARSET = string.digits + string.ascii_lowercase
    ID_LENGTH = 8

    @classmethod
    def generate(cls) -> str:
        """
        生成一个新的会话 ID

        Returns:
            str: 8位随机 ID，例如 "a3b5c7d9"
        """
        return ''.join(random.choices(cls.CHARSET, k=cls.ID_LENGTH))

    @classmethod
    def create_subtask_id(cls, parent_id: str) -> str:
        """
        创建子任务 ID（在父 ID 基础上添加层级）

        Args:
            parent_id: 父任务 ID，例如 "a3b5c7d9" 或 "a3b5c7d9.x1y2z3w4"

        Returns:
            str: 子任务 ID，例如 "a3b5c7d9.x1y2z3w4"
        """
        new_segment = cls.generate()
        return f"{parent_id}.{new_segment}"

    @classmethod
    def get_depth(cls, session_id: str) -> int:
        """
        获取会话 ID 的嵌套深度

        Args:
            session_id: 会话 ID

        Returns:
            int: 深度（0 表示根会话，1 表示第一层子任务，以此类推）
        """
        return session_id.count('.')

    @classmethod
    def get_parent_id(cls, session_id: str) -> str:
        """
        获取父会话 ID

        Args:
            session_id: 会话 ID，例如 "a3b5c7d9.x1y2z3w4.m5n6p7q8"

        Returns:
            str: 父会话 ID，例如 "a3b5c7d9.x1y2z3w4"
                 如果是根会话，返回空字符串
        """
        if '.' not in session_id:
            return ""
        return session_id.rsplit('.', 1)[0]

    @classmethod
    def get_root_id(cls, session_id: str) -> str:
        """
        获取根会话 ID

        Args:
            session_id: 会话 ID，例如 "a3b5c7d9.x1y2z3w4.m5n6p7q8"

        Returns:
            str: 根会话 ID，例如 "a3b5c7d9"
        """
        return session_id.split('.')[0]

    @classmethod
    def get_path(cls, session_id: str) -> list[str]:
        """
        获取会话 ID 的完整路径

        Args:
            session_id: 会话 ID，例如 "a3b5c7d9.x1y2z3w4.m5n6p7q8"

        Returns:
            list[str]: 路径列表，例如 ["a3b5c7d9", "x1y2z3w4", "m5n6p7q8"]
        """
        return session_id.split('.')

    @classmethod
    def validate(cls, session_id: str) -> bool:
        """
        验证会话 ID 格式是否正确

        Args:
            session_id: 会话 ID

        Returns:
            bool: 是否有效
        """
        if not session_id:
            return False

        segments = session_id.split('.')
        for segment in segments:
            # 每个段必须是8位
            if len(segment) != cls.ID_LENGTH:
                return False
            # 每个字符必须在字符集中
            if not all(c in cls.CHARSET for c in segment):
                return False

        return True
