import os
import re
import json
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from pathlib import Path
from .paths import get_path_manager

# NOTE: 内置默认 Provider 连接配置与模型目录的合并逻辑已迁移到 core.model_manager.ModelManager。
# core.config 仅负责解析 config.json 并展开环境变量。


# NOTE: 内置模型目录与模型合并逻辑已迁移到 core.model_manager.ModelManager。
# 为避免 core.config 与 provider 包之间循环依赖，这里不再导入/查询内置模型。


class ProviderConfig(BaseModel):
    """单个 Provider 连接配置"""
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    type: str = "openai"  # "openai" 或 "anthropic"

    # Provider 侧的上下文窗口（token 上限）。
    # 设置后会覆盖该 provider 下所有模型（含内置模型）的 context_window，
    # 适用于第三方代理实际窗口与内置值不同的场景。
    context_window: Optional[int] = None

    # 可用模型列表（用于补齐内置未覆盖的模型，以及 UI 选择列表）
    models: List[str] = []


class ProviderSection(BaseModel):
    """provider 配置段"""
    default: str = ""                           # 默认模型名，如 "anthropic/claude-opus-4-6"
    providers: Dict[str, ProviderConfig] = {}   # provider 连接配置


class MCPServerConfig(BaseModel):
    name: str
    type: str = "stdio"  # stdio, sse, http
    enabled: bool = True

    # Stdio specific
    command: Optional[str] = None
    args: List[str] = []
    env: Dict[str, str] = {}

    # SSE/HTTP specific
    url: Optional[str] = None
    headers: Dict[str, str] = {}  # HTTP headers (用于 API key 等)

    description: Optional[str] = None


class MCPConfig(BaseModel):
    mcp_servers: List[MCPServerConfig] = []


class AppConfig(BaseModel):
    provider: ProviderSection


class ConfigLoader:
    def __init__(self):
        pass

    def _expand_env_vars(self, value: str) -> str:
        """
        Replace ${VAR} with environment variable value.
        """
        if not isinstance(value, str):
            return value

        pattern = r"\$\{([a-zA-Z0-9_]+)\}"
        match = re.search(pattern, value)
        if match:
            env_var = match.group(1)
            env_value = os.getenv(env_var)
            if env_value:
                return value.replace(match.group(0), env_value)
            return value
        return value

    def _process_dict(self, data: dict) -> dict:
        """
        Recursively process dictionary to expand env vars.
        """
        for key, value in data.items():
            if isinstance(value, dict):
                self._process_dict(value)
            elif isinstance(value, list):
                for i, item in enumerate(value):
                    if isinstance(item, str):
                        value[i] = self._expand_env_vars(item)
                    elif isinstance(item, dict):
                        self._process_dict(item)
            elif isinstance(value, str):
                data[key] = self._expand_env_vars(value)
        return data

    def _load_file(self, path: str) -> dict:
        """
        加载配置文件，支持 JSON 和 YAML 格式
        """
        with open(path, "r", encoding="utf-8") as f:
            if path.endswith(".json"):
                return json.load(f)
            else:
                import yaml
                return yaml.safe_load(f)

    def _parse_provider_section(self, raw: dict) -> dict:
        """
        解析 provider 段：除了 default 以外的 key 视为 provider 定义。

        注意：本模块仅负责解析 config.json，不做任何“默认值合并/模型合并”。
        默认值与模型目录由 ModelManager 统一提供。
        """
        reserved_keys = {"default"}
        providers = {}
        rest = {}

        for key, value in raw.items():
            if key in reserved_keys:
                rest[key] = value
            elif isinstance(value, dict):
                # 这是一个 provider 定义
                providers[key] = value
            else:
                rest[key] = value

        rest["providers"] = providers
        return rest

    def load_app_config(self, path: str) -> AppConfig:
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"配置文件未找到: {path}\n"
                f"请创建配置文件，参考 .dundun/config.example.json"
            )

        raw_data = self._load_file(path)

        if not raw_data:
            raise ValueError(f"配置文件为空: {path}")

        processed_data = self._process_dict(raw_data)

        # 解析 provider 段（仅解析，不做默认值合并）
        if "provider" in processed_data:
            processed_data["provider"] = self._parse_provider_section(
                processed_data["provider"]
            )

        return AppConfig(**processed_data)

    def load_mcp_config(self, path: str) -> MCPConfig:
        """Load MCP config from JSON/YAML.

        New MCP-style format only:
        {"mcpServers": {"name": {"transport": "stdio"|"sse"|"streamableHttp"|"http", ...}}}
        """
        if not os.path.exists(path):
            return MCPConfig()

        raw_data = self._load_file(path)
        if not raw_data:
            return MCPConfig()

        processed_data = self._process_dict(raw_data)

        if "mcpServers" not in processed_data or not isinstance(processed_data["mcpServers"], dict):
            raise ValueError(
                f"Invalid MCP config format in {path}: expected top-level 'mcpServers' object"
            )

        servers = []
        for name, conf in processed_data["mcpServers"].items():
            if not isinstance(conf, dict):
                raise ValueError(
                    f"Invalid MCP server config for '{name}' in {path}: expected an object"
                )

            normalized = dict(conf)
            normalized.setdefault("name", name)

            # Normalize field naming: transport -> type (internal model)
            if "transport" not in normalized and "type" in normalized:
                raise ValueError(
                    f"Invalid MCP server config for '{name}' in {path}: use 'transport' (not 'type')"
                )
            normalized["type"] = normalized.pop("transport")

            servers.append(MCPServerConfig(**normalized))

        return MCPConfig(mcp_servers=servers)


def load_config(filename: str = "config.json") -> AppConfig:
    """
    加载应用配置

    Args:
        filename: 配置文件名（默认 config.json）

    Returns:
        AppConfig 实例
    """
    path_manager = get_path_manager()
    config_file = path_manager.get_config_file(filename)
    return ConfigLoader().load_app_config(str(config_file))


def load_mcp_config(filename: str = "tools.json") -> MCPConfig:
    """
    加载 MCP 配置

    先加载 .dundun/tools.json，再加载 ~/.dundun/tools.json。

    仅支持新格式（标准 MCP）：
    {"mcpServers": {"name": {...}}}

    合并规则：按 server name 去重，本地（项目内）优先。

    Args:
        filename: 配置文件名（默认 tools.json）

    Returns:
        MCPConfig 实例
    """
    path_manager = get_path_manager()
    config_files = path_manager.get_all_config_files(filename)
    loader = ConfigLoader()

    all_servers = []
    seen_names = set()

    for config_file in config_files:
        mcp_config = loader.load_mcp_config(str(config_file))
        for server in mcp_config.mcp_servers:
            if server.name not in seen_names:
                all_servers.append(server)
                seen_names.add(server.name)

    return MCPConfig(mcp_servers=all_servers)


def load_settings() -> dict:
    """
    加载用户设置（~/.dundun/setting.json）

    Returns:
        设置字典
    """
    path_manager = get_path_manager()
    settings_file = path_manager.get_global_dir() / "setting.json"
    if settings_file.exists():
        try:
            with open(settings_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_settings(settings: dict) -> None:
    """
    保存用户设置到 ~/.dundun/setting.json

    Args:
        settings: 设置字典
    """
    path_manager = get_path_manager()
    settings_file = path_manager.get_global_dir() / "setting.json"
    with open(settings_file, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2, ensure_ascii=False)
