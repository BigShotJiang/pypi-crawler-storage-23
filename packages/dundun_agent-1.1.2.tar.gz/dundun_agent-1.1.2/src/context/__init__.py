"""
Context 模块

提供上下文管理功能，包括：
- Token 统计（优先使用 LLM 返回值）
- 上下文存储
- 自动压缩（Prune + LLM 摘要）

Agent 只需调用 add_message/get_messages，压缩完全自动处理。
"""

from .base import BaseContext, ContextConfig, ChatFn
from .default import DefaultContext

__all__ = [
    "BaseContext",
    "ContextConfig",
    "ChatFn",
    "DefaultContext",
]
