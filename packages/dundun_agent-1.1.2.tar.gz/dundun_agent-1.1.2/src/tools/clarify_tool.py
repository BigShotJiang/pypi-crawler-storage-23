from typing import Any, List, Optional
from pydantic import BaseModel, Field
from .base import BaseTool
from core.interaction import InteractionManager, InteractionType, get_interaction_manager


class ClarifyArgs(BaseModel):
    """Arguments for Clarify tool"""

    question: str = Field(
        ...,
        description="需要询问用户的具体问题或请求。"
    )
    options: Optional[List[str]] = Field(
        default=None,
        description="可选。提供给用户的一组预设选项（例如：['确定', '取消'] 或 ['方案A', '方案B']）。尽量要有且是明确清晰的选项，但最好不要超过3个"
    )
    allow_text_input: bool = Field(
        default=True,
        description="在提供 options 的同时，是否允许用户手动输入其他文字内容。"
    )
    context: Optional[str] = Field(
        default=None,
        description="可选。简述当前 Agent 遇到的困境，帮助用户快速理解背景。"
    )


class ClarifyTool(BaseTool):
    """Tool for asking user clarification when encountering ambiguity or missing information"""

    name = "clarify"
    description = """当遇到歧义、信息缺失或需要用户选择决策时，暂停任务并向人类寻求帮助。该工具会阻塞执行流直到用户通过 UI 提供反馈。

使用场景：
- 不确定用户的具体意图
- 需要用户在多个方案中选择
- 缺少执行任务所需的必要信息
- 遇到不确定的情况需要用户确认

返回：
- 用户选择的选项或输入的内容
- Agent 收到响应后继续执行任务"""
    args_schema = ClarifyArgs

    def __init__(self, session_id: str, interaction_manager: Optional[InteractionManager] = None):
        self.session_id = session_id
        self._interaction_manager = interaction_manager

    @property
    def interaction_manager(self) -> InteractionManager:
        """获取 interaction manager，延迟加载"""
        if self._interaction_manager is None:
            self._interaction_manager = get_interaction_manager()
        return self._interaction_manager

    async def run(
        self,
        question: str,
        options: Optional[List[str]] = None,
        allow_text_input: bool = True,
        context: Optional[str] = None
    ) -> str:
        """Execute the tool - blocks until user provides input"""
        # LLM 可能将 options 序列化为 JSON 字符串而非数组，需要修正
        if isinstance(options, str):
            import json
            try:
                options = json.loads(options)
            except (json.JSONDecodeError, TypeError):
                options = [options]

        # 构建选项列表
        option_items = []
        if options:
            for opt in options:
                option_items.append({"value": str(opt), "label": str(opt)})

        # 调用交互管理器，请求用户输入
        response = await self.interaction_manager.request(
            interaction_type=InteractionType.CLARIFY,
            session_id=self.session_id,
            title="需要澄清",
            message=question,
            metadata={
                "context": context,
                "allow_text_input": allow_text_input,
            },
            options=option_items,
            default_value="",
        )

        # 用户响应（选择或输入）直接作为工具结果返回给大模型
        user_response = response.value
        if not user_response:
            return "用户未提供响应"

        return user_response
