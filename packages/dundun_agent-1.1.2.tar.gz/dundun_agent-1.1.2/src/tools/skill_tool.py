from pathlib import Path
from typing import Type
from pydantic import BaseModel, Field
from .base import BaseTool
from core.skill import get_skill_manager
from core.logger import log_event


class SkillTool(BaseTool):
    """Tool for invoking skills"""

    name = "skill"

    def __init__(self):
        self.manager = get_skill_manager()

    @property
    def args_schema(self) -> Type[BaseModel]:
        """动态生成 args_schema，skill 字段 description 包含可用 skill 名称"""
        skills = self.manager.get_all_skills()
        if skills:
            names = ", ".join(s.name for s in skills)
            field_desc = f"The skill name. Available: {names}"
        else:
            field_desc = "The skill name (no arguments)"

        return type(
            "SkillArgs",
            (BaseModel,),
            {
                "__annotations__": {"skill": str},
                "skill": Field(..., description=field_desc),
            },
        )

    @property
    def description(self) -> str:
        """动态生成 description，包含可用 skill 列表"""
        skills = self.manager.get_all_skills()

        base = """Execute a skill within the main conversation.

Skills provide specialized capabilities and domain knowledge. When users ask you to perform tasks, check if any available skills match the task and invoke them.

How to use skills:
- Invoke skills using this tool with the skill name only (no arguments)
- When you invoke a skill, the skill's prompt will expand and provide detailed instructions
- Only use skills listed in available skills below
- Do not invoke a skill that is already running"""

        if skills:
            skill_list = "\n\nAvailable skills:\n"
            for s in skills:
                skill_list += f"- **{s.name}**: {s.description}\n"
            return base + skill_list
        else:
            return base + "\n\nNo skills currently available."

    @staticmethod
    def _list_skill_dir(skill_path: str) -> str:
        """列出 skill 所在一级目录的文件列表（不递归）"""
        if not skill_path:
            return ""
        skill_dir = Path(skill_path).parent
        if not skill_dir.exists():
            return ""
        try:
            entries = sorted(skill_dir.iterdir())
            lines = [f"目录: {skill_dir}"]
            for entry in entries:
                prefix = "📁" if entry.is_dir() else "📄"
                lines.append(f"  {prefix} {entry.name}")
            return "\n".join(lines)
        except Exception:
            return ""

    async def run(self, skill: str) -> str:
        """Execute the tool"""
        try:
            # Load skill content
            content = self.manager.load_skill_content(skill)

            if not content:
                available_skills = [s.name for s in self.manager.get_all_skills()]
                error_msg = f"Skill '{skill}' not found. Available skills: {', '.join(available_skills)}"

                log_event(
                    "skill_execution",
                    skill_name=skill,
                    skill_path="",
                    result="",
                    error=error_msg
                )

                return error_msg

            # 记录成功的 skill 执行
            skill_info = self.manager.get_skill(skill)
            skill_path = str(skill_info.location) if skill_info else ""

            log_event(
                "skill_execution",
                skill_name=skill,
                skill_path=skill_path,
                result=content,
                error=None
            )

            # 列出 skill 所在一级目录的文件列表
            dir_listing = self._list_skill_dir(skill_path)

            # Return skill content to be injected into the conversation
            result = f"Skill '{skill}' loaded:\n\n{content}"
            if dir_listing:
                result += f"\n\n## Skill 目录文件\n{dir_listing}"
            return result

        except Exception as e:
            error_msg = f"Error loading skill '{skill}': {str(e)}"

            log_event(
                "skill_execution",
                skill_name=skill,
                skill_path="",
                result="",
                error=error_msg
            )

            return error_msg
