from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Optional, Type
from pydantic import BaseModel


@dataclass
class ToolOutput:
    """工具执行结果（携带可选元数据）

    大多数工具直接返回 str 即可。当需要向客户端传递额外信息时
    （如 EditTool 的 start_line），返回此类型。
    """
    content: str
    metadata: Optional[Dict[str, Any]] = None


class BaseTool(ABC):
    """
    Abstract base class for all tools.
    Now supports async execution.
    """

    name: str
    description: str
    args_schema: Type[BaseModel]

    @abstractmethod
    async def run(self, *args, **kwargs) -> Any:
        pass

    @property
    def schema(self) -> Dict[str, Any]:
        """
        Returns the OpenAI function schema for this tool.
        """
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.args_schema.model_json_schema(),
            },
        }
