"""
LSP 模块

提供 Language Server Protocol 客户端实现，
用于代码导航、查找定义、查找引用等操作。
"""

from .client import LSPClient
from .server import ServerConfig, SERVERS
from .manager import LSPManager
from .protocol import (
    Position,
    Range,
    Location,
    DocumentSymbol,
    SymbolInformation,
    Hover,
    Diagnostic,
    SymbolKind,
)

__all__ = [
    "LSPClient",
    "ServerConfig",
    "SERVERS",
    "LSPManager",
    "Position",
    "Range",
    "Location",
    "DocumentSymbol",
    "SymbolInformation",
    "Hover",
    "Diagnostic",
    "SymbolKind",
]
