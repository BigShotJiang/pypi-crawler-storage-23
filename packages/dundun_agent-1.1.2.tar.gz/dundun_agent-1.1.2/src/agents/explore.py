"""
Explore Agent - 快速探索代码库 Agent

特性：
- 快速探索和分析代码库
- 只读工具 + Write（仅用于缓存）
- 较短的迭代次数
- 无需权限检查
"""

from typing import List, Optional

from provider import BaseModelClient
from core.permission import PermissionRuleset
from tools.base import BaseTool
from tools.registry import ToolRegistry
from .base import BaseAgent


class ExploreAgent(BaseAgent):
    """
    Explore Agent - 快速探索代码库 Agent

    特性：
    1. 快速响应：优先使用最快的方法找到答案
    2. 精确搜索：使用 Grep 的正则表达式功能精确定位
    3. 只读模式：仅使用只读工具探索代码库
    """

    # 允许的工具列表（只读）
    ALLOWED_TOOLS = ["read", "glob", "grep", "bash"]

    # ==================== 必须实现 ====================

    @property
    def name(self) -> str:
        return "explore"

    def get_tools(self, registry: ToolRegistry) -> List[BaseTool]:
        """返回只读工具"""
        all_tools = registry.get_all_tools()
        return [t for t in all_tools if t.name.lower() in self.ALLOWED_TOOLS]

    # ==================== 可选覆盖 ====================

    @property
    def max_iterations(self) -> int:
        """探索任务通常不需要太多迭代"""
        return 100

    @property
    def doom_loop_threshold(self) -> int:
        """探索任务的死循环阈值"""
        return 5

    @property
    def enable_permission_check(self) -> bool:
        """探索模式无需权限检查"""
        return False

    @property
    def permission_ruleset(self) -> Optional[PermissionRuleset]:
        return None

    # ==================== 辅助方法 ====================

    def get_capabilities(self) -> dict:
        """获取能力描述"""
        return {
            "name": self.name,
            "description": "快速探索代码库的 Agent",
            "readonly": True,
            "features": [
                "快速代码搜索",
                "代码结构分析",
                "模式识别",
                "返回探索结果",
            ],
            "allowed_tools": self.ALLOWED_TOOLS,
            "tools": [t.name for t in self._tools],
            "max_iterations": self.max_iterations,
        }
