"""
Build Agent - 专业编程 Agent

特性：
- 完整的文件读写权限
- 所有工具可用
- Git 安全操作支持
- 使用 Build Agent 专用权限规则集
"""

from typing import List, Optional

from provider import BaseModelClient
from core.permission import PermissionRuleset, PermissionRule, PermissionAction
from tools.base import BaseTool
from tools.registry import ToolRegistry
from .base import BaseAgent


def _build_agent_ruleset() -> PermissionRuleset:
    """
    构建 Build Agent 专用权限规则集

    Build Agent 具有扩展权限：
    - Write/Edit 工具：项目内文件自动允许，无需授权
    - Bash 命令：更多开发相关命令自动允许

    Returns:
        Build Agent 专用的权限规则集
    """
    return PermissionRuleset(rules=[
        # === 文件写入/编辑：项目内自动允许 ===
        PermissionRule("write", "./**", PermissionAction.ALLOW),
        PermissionRule("edit", "./**", PermissionAction.ALLOW),

        # === 开发常用命令：自动允许 ===
        # Python 开发
        PermissionRule("bash", "python*", PermissionAction.ALLOW),
        PermissionRule("bash", "python3*", PermissionAction.ALLOW),
        PermissionRule("bash", "pip*", PermissionAction.ALLOW),
        PermissionRule("bash", "pip3*", PermissionAction.ALLOW),
        PermissionRule("bash", "pytest*", PermissionAction.ALLOW),
        PermissionRule("bash", "mypy*", PermissionAction.ALLOW),
        PermissionRule("bash", "ruff*", PermissionAction.ALLOW),
        PermissionRule("bash", "black*", PermissionAction.ALLOW),
        PermissionRule("bash", "isort*", PermissionAction.ALLOW),
        PermissionRule("bash", "flake8*", PermissionAction.ALLOW),
        PermissionRule("bash", "pylint*", PermissionAction.ALLOW),
        PermissionRule("bash", "poetry*", PermissionAction.ALLOW),
        PermissionRule("bash", "pdm*", PermissionAction.ALLOW),
        PermissionRule("bash", "uv*", PermissionAction.ALLOW),
        PermissionRule("bash", "conda*", PermissionAction.ALLOW),

        # Node.js 开发
        PermissionRule("bash", "node*", PermissionAction.ALLOW),
        PermissionRule("bash", "npm*", PermissionAction.ALLOW),
        PermissionRule("bash", "npx*", PermissionAction.ALLOW),
        PermissionRule("bash", "yarn*", PermissionAction.ALLOW),
        PermissionRule("bash", "pnpm*", PermissionAction.ALLOW),
        PermissionRule("bash", "bun*", PermissionAction.ALLOW),
        PermissionRule("bash", "deno*", PermissionAction.ALLOW),
        PermissionRule("bash", "tsc*", PermissionAction.ALLOW),
        PermissionRule("bash", "eslint*", PermissionAction.ALLOW),
        PermissionRule("bash", "prettier*", PermissionAction.ALLOW),
        PermissionRule("bash", "jest*", PermissionAction.ALLOW),
        PermissionRule("bash", "vitest*", PermissionAction.ALLOW),

        # Rust 开发
        PermissionRule("bash", "cargo*", PermissionAction.ALLOW),
        PermissionRule("bash", "rustc*", PermissionAction.ALLOW),
        PermissionRule("bash", "rustfmt*", PermissionAction.ALLOW),
        PermissionRule("bash", "clippy*", PermissionAction.ALLOW),

        # Go 开发
        PermissionRule("bash", "go *", PermissionAction.ALLOW),
        PermissionRule("bash", "go build*", PermissionAction.ALLOW),
        PermissionRule("bash", "go test*", PermissionAction.ALLOW),
        PermissionRule("bash", "go run*", PermissionAction.ALLOW),
        PermissionRule("bash", "go mod*", PermissionAction.ALLOW),
        PermissionRule("bash", "go fmt*", PermissionAction.ALLOW),
        PermissionRule("bash", "go vet*", PermissionAction.ALLOW),

        # Java 开发
        PermissionRule("bash", "java*", PermissionAction.ALLOW),
        PermissionRule("bash", "javac*", PermissionAction.ALLOW),
        PermissionRule("bash", "mvn*", PermissionAction.ALLOW),
        PermissionRule("bash", "gradle*", PermissionAction.ALLOW),

        # 构建工具
        PermissionRule("bash", "make*", PermissionAction.ALLOW),
        PermissionRule("bash", "cmake*", PermissionAction.ALLOW),
        PermissionRule("bash", "ninja*", PermissionAction.ALLOW),

        # Docker（只读操作）
        PermissionRule("bash", "docker ps*", PermissionAction.ALLOW),
        PermissionRule("bash", "docker images*", PermissionAction.ALLOW),
        PermissionRule("bash", "docker logs*", PermissionAction.ALLOW),
        PermissionRule("bash", "docker inspect*", PermissionAction.ALLOW),

        # Git 扩展权限（add, checkout, merge 等常用操作）
        PermissionRule("bash", "git add*", PermissionAction.ALLOW),
        PermissionRule("bash", "git checkout*", PermissionAction.ALLOW),
        PermissionRule("bash", "git switch*", PermissionAction.ALLOW),
        PermissionRule("bash", "git merge*", PermissionAction.ALLOW),
        PermissionRule("bash", "git rebase*", PermissionAction.ALLOW),
        PermissionRule("bash", "git stash*", PermissionAction.ALLOW),
        PermissionRule("bash", "git fetch*", PermissionAction.ALLOW),
        PermissionRule("bash", "git pull*", PermissionAction.ALLOW),
        PermissionRule("bash", "git clone*", PermissionAction.ALLOW),
        PermissionRule("bash", "git init*", PermissionAction.ALLOW),
        PermissionRule("bash", "git reset*", PermissionAction.ALLOW),
        PermissionRule("bash", "git restore*", PermissionAction.ALLOW),
        PermissionRule("bash", "git clean*", PermissionAction.ALLOW),

        # 文件操作（项目内）
        PermissionRule("bash", "mkdir*", PermissionAction.ALLOW),
        PermissionRule("bash", "touch*", PermissionAction.ALLOW),
        PermissionRule("bash", "cp*", PermissionAction.ALLOW),
        PermissionRule("bash", "mv*", PermissionAction.ALLOW),
        PermissionRule("bash", "rm*", PermissionAction.ALLOW),
        PermissionRule("bash", "chmod*", PermissionAction.ALLOW),

        # 仍然禁止危险操作
        PermissionRule("bash", "rm -rf /*", PermissionAction.DENY),
        PermissionRule("bash", "rm -rf /", PermissionAction.DENY),
        PermissionRule("bash", "sudo *", PermissionAction.DENY),
        PermissionRule("bash", "chmod 777 *", PermissionAction.DENY),
        PermissionRule("bash", "git push --force*", PermissionAction.DENY),
    ])


class BuildAgent(BaseAgent):
    """
    Build Agent - 专业编程 Agent

    特性：
    1. 完整权限：访问所有开发工具
    2. Git 安全协议：提交前检查，避免破坏性操作
    3. 任务规划：使用 TodoWrite 管理任务进度
    4. 代码质量：测试编写和执行支持
    """

    # ==================== 必须实现 ====================

    @property
    def name(self) -> str:
        return "build"

    def get_tools(self, registry: ToolRegistry) -> List[BaseTool]:
        """返回所有工具"""
        return registry.get_all_tools()

    # ==================== 可选覆盖 ====================

    @property
    def max_iterations(self) -> int:
        return 100

    @property
    def enable_permission_check(self) -> bool:
        return True

    @property
    def permission_ruleset(self) -> Optional[PermissionRuleset]:
        """使用 Build Agent 专用权限规则集"""
        return _build_agent_ruleset()

    # ==================== 辅助方法 ====================

    def get_capabilities(self) -> dict:
        """获取能力描述"""
        return {
            "name": self.name,
            "description": "专业编程 Agent，具备完整的代码开发能力",
            "readonly": False,
            "features": [
                "完整的文件读写权限",
                "Git 操作支持（带安全检查）",
                "任务规划和跟踪",
                "测试编写和执行",
                "代码重构和优化",
            ],
            "tools": [t.name for t in self._tools],
            "max_iterations": self.max_iterations,
        }
