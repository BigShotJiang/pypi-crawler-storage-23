"""
General Agent - 通用 Agent

特性：
- 通用编程能力
- 完整的工具访问
- 需要权限检查
"""

from typing import List, Optional

from provider import BaseModelClient
from core.permission import PermissionRuleset
from tools.base import BaseTool
from tools.registry import ToolRegistry
from .base import BaseAgent


class GeneralAgent(BaseAgent):
    """
    General Agent - 通用 Agent

    特性：
    1. 通用能力：适用于各种软件开发任务
    2. 完整工具：访问所有开发工具
    3. 权限检查：需要用户授权敏感操作
    """

    # ==================== 必须实现 ====================

    @property
    def name(self) -> str:
        return "general"

    def get_tools(self, registry: ToolRegistry) -> List[BaseTool]:
        """返回所有工具"""
        return registry.get_all_tools()

    # ==================== 可选覆盖 ====================

    @property
    def max_iterations(self) -> int:
        return 100

    @property
    def enable_permission_check(self) -> bool:
        return True

    @property
    def permission_ruleset(self) -> Optional[PermissionRuleset]:
        return None

    # ==================== 辅助方法 ====================

    def get_capabilities(self) -> dict:
        """获取能力描述"""
        return {
            "name": self.name,
            "description": "通用 Agent，具备完整的软件开发能力",
            "readonly": False,
            "features": [
                "完整的文件读写权限",
                "命令执行",
                "任务规划和跟踪",
                "代码分析和修改",
            ],
            "tools": [t.name for t in self._tools],
            "max_iterations": self.max_iterations,
        }
