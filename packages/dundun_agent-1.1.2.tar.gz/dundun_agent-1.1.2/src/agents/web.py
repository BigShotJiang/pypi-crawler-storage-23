"""
Web Agent - 浏览器自动化 Agent

特性：
- 浏览器操作能力 (browser-use)
- 任务执行报告生成和优化
- 可作为主 Agent 或子 Agent 使用
- 工具免授权
"""

from typing import List, Optional

from provider import BaseModelClient
from tools.base import BaseTool
from tools.registry import ToolRegistry
from .base import BaseAgent


class WebAgent(BaseAgent):
    """
    Web Agent - 浏览器自动化 Agent

    特性：
    1. 浏览器自动化操作 (browser-use)
    2. 任务执行报告生成和优化
    3. 可作为主 Agent 或子 Agent 使用
    4. 工具免授权（browser_use 和 task_report）
    """

    # ==================== 必须实现 ====================

    @property
    def name(self) -> str:
        return "web"

    def get_tools(self, registry: ToolRegistry) -> List[BaseTool]:
        """返回 Web Agent 专用工具"""
        from tools.browser_tool import BrowserUseTool, TaskReportTool

        return [
            BrowserUseTool(),
            TaskReportTool(),
        ]

    # ==================== 可选覆盖 ====================

    @property
    def max_iterations(self) -> int:
        """浏览器任务通常步数较少"""
        return 50

    @property
    def enable_permission_check(self) -> bool:
        """WebAgent 禁用权限检查（浏览器操作是用户主动触发的）"""
        return False

    # ==================== 辅助方法 ====================

    def get_capabilities(self) -> dict:
        """获取能力描述"""
        return {
            "name": self.name,
            "description": "Web 自动化 Agent，通过浏览器完成用户任务",
            "features": [
                "浏览器自动化操作 (browser-use)",
                "AI 驱动的任务执行",
                "任务执行报告生成和优化",
                "会话持久化",
            ],
            "tools": [t.name for t in self._tools],
            "max_iterations": self.max_iterations,
        }
