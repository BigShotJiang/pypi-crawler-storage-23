"""
Plan Agent - 规划和分析 Agent（只读模式）

特性：
- 只读模式，不能修改文件
- 只能使用只读工具
- 专注于需求分析和方案设计
- 无需权限检查
"""

from typing import List, Optional

from provider import BaseModelClient
from core.permission import PermissionRuleset
from tools.base import BaseTool
from tools.registry import ToolRegistry
from .base import BaseAgent


class PlanAgent(BaseAgent):
    """
    Plan Agent - 规划和分析 Agent（只读模式）

    特性：
    1. 只读模式：只能读取和分析，不能修改文件
    2. 深度分析：全面分析代码库和需求
    3. 任务规划：使用 TodoWrite 制定详细计划
    4. 用户互动：主动询问和澄清需求
    """

    # 只读工具列表
    READONLY_TOOLS = ["read", "glob", "grep", "bash", "todowrite", "todoread", "clarify"]

    # ==================== 必须实现 ====================

    @property
    def name(self) -> str:
        return "plan"

    def get_tools(self, registry: ToolRegistry) -> List[BaseTool]:
        """只返回只读工具"""
        all_tools = registry.get_all_tools()
        return [t for t in all_tools if t.name.lower() in self.READONLY_TOOLS]

    # ==================== 可选覆盖 ====================

    @property
    def max_iterations(self) -> int:
        return 100

    @property
    def enable_permission_check(self) -> bool:
        """只读模式无需权限检查"""
        return False

    @property
    def permission_ruleset(self) -> Optional[PermissionRuleset]:
        return None

    # ==================== 辅助方法 ====================

    def get_capabilities(self) -> dict:
        """获取能力描述"""
        return {
            "name": self.name,
            "description": "规划和分析 Agent，只读模式",
            "readonly": True,
            "features": [
                "代码库分析",
                "需求分析",
                "方案设计",
                "任务规划",
            ],
            "allowed_tools": self.READONLY_TOOLS,
            "tools": [t.name for t in self._tools],
            "max_iterations": self.max_iterations,
        }
