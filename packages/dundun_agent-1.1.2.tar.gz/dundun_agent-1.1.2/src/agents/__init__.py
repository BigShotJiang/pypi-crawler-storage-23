"""
Agents 模块

提供各种 Agent 实现：
- BuildAgent: 专业编程 Agent（完整权限）
- PlanAgent: 规划分析 Agent（只读）
- ExploreAgent: 快速探索 Agent（只读 + 缓存写入）
- GeneralAgent: 通用 Agent
- WebAgent: 浏览器自动化 Agent

使用方式：
1. 直接实例化: agent = BuildAgent(client, tool_registry)
2. 工厂函数: agent = create_agent("build", client, tool_registry)
"""

from typing import Optional

from provider import BaseModelClient
from core.permission import PermissionManager
from tools.registry import ToolRegistry

from .base import BaseAgent, PermissionCallback
from .build import BuildAgent
from .plan import PlanAgent
from .explore import ExploreAgent
from .general import GeneralAgent
from .web import WebAgent


# Agent 类型映射
AGENT_CLASSES = {
    "build": BuildAgent,
    "plan": PlanAgent,
    "explore": ExploreAgent,
    "general": GeneralAgent,
    "web": WebAgent,
}


def create_agent(
    agent_type: str,
    client: BaseModelClient,
    tool_registry: ToolRegistry,
    permission_manager: Optional[PermissionManager] = None,
    permission_callback: Optional[PermissionCallback] = None,
) -> BaseAgent:
    """
    根据类型创建 Agent

    Args:
        agent_type: Agent 类型（build/plan/explore/general）
        client: 模型客户端
        tool_registry: 工具注册表
        permission_manager: 权限管理器
        permission_callback: 权限请求回调函数

    Returns:
        Agent 实例

    Raises:
        ValueError: 未知的 Agent 类型
    """
    agent_class = AGENT_CLASSES.get(agent_type.lower())
    if not agent_class:
        available = ", ".join(AGENT_CLASSES.keys())
        raise ValueError(f"Unknown agent type: {agent_type}. Available: {available}")

    return agent_class(
        client=client,
        tool_registry=tool_registry,
        permission_manager=permission_manager,
        permission_callback=permission_callback,
    )


def list_agent_types() -> list:
    """列出所有可用的 Agent 类型"""
    return list(AGENT_CLASSES.keys())


__all__ = [
    # 基类
    "BaseAgent",
    "PermissionCallback",
    # Agent 类
    "BuildAgent",
    "PlanAgent",
    "ExploreAgent",
    "GeneralAgent",
    "WebAgent",
    # 工厂函数
    "create_agent",
    "list_agent_types",
    "AGENT_CLASSES",
]
