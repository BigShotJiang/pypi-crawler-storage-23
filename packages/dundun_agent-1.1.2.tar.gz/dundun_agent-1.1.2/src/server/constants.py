"""
服务端常量定义

所有魔法数字和字符串常量都在这里定义
"""

from enum import Enum


# ============================================================================
# 服务器配置常量
# ============================================================================

class ServerConfig:
    """服务器配置常量"""
    DEFAULT_HOST = "0.0.0.0"
    DEFAULT_PORT = 8367
    MAX_PORT_ATTEMPTS = 10  # 端口自动切换最大尝试次数
    WS_PING_INTERVAL = 30   # 服务端 WebSocket ping 间隔（秒）
    WS_PING_TIMEOUT = 60    # 服务端 WebSocket ping 超时（秒）


# ============================================================================
# WebSocket 协议常量
# ============================================================================

class MessageType(str, Enum):
    """客户端发送的消息类型"""
    # 用户消息
    USER_MESSAGE = "user_message"
    # 控制命令
    INTERRUPT = "interrupt"
    SWITCH_AGENT = "switch_agent"
    SWITCH_MODEL = "switch_model"
    SET_AUTO_MODE = "set_auto_mode"
    # 权限响应
    PERMISSION_RESPONSE = "permission_response"
    # 交互响应
    INTERACTION_RESPONSE = "interaction_response"
    # 查询命令
    QUERY_TODO = "query_todo"
    QUERY_TOOLS = "query_tools"
    QUERY_SKILLS = "query_skills"
    # 压缩命令
    COMPACT = "compact"
    # 初始化命令
    INIT = "init"
    # 会话切换
    SWITCH_SESSION = "switch_session"


class EventType(str, Enum):
    """服务端发送的事件类型"""
    # 连接事件
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"

    # Agent 输出
    TEXT_CHUNK = "text_chunk"
    TEXT_CHUNK_COMPLETE = "text_chunk_complete"
    THINKING_START = "thinking_start"
    THINKING_END = "thinking_end"

    # 工具调用
    TOOL_CALL_START = "tool_call_start"
    TOOL_CALL_END = "tool_call_end"

    # 任务状态
    TASK_STARTED = "task_started"
    TASK_COMPLETED = "task_completed"
    TASK_INTERRUPTED = "task_interrupted"
    TASK_ERROR = "task_error"

    # 权限请求
    PERMISSION_REQUEST = "permission_request"

    # 交互请求
    INTERACTION_REQUEST = "interaction_request"

    # Agent 切换
    AGENT_SWITCHED = "agent_switched"

    # 模型切换
    MODEL_SWITCHED = "model_switched"

    # 自动模式切换
    AUTO_MODE_CHANGED = "auto_mode_changed"

    # 上下文压缩
    CONTEXT_COMPRESS_START = "context_compress_start"
    CONTEXT_COMPRESS_END = "context_compress_end"

    # 查询响应
    QUERY_TODO_RESPONSE = "query_todo_response"
    QUERY_TOOLS_RESPONSE = "query_tools_response"
    QUERY_SKILLS_RESPONSE = "query_skills_response"
    # 压缩响应
    COMPACT_RESULT = "compact_result"

    # 错误
    ERROR = "error"


# ============================================================================
# Agent 常量
# ============================================================================

class AgentType(str, Enum):
    """Agent 类型"""
    GENERAL = "general"
    BUILD = "build"
    PLAN = "plan"
    EXPLORE = "explore"  # 子 Agent，只读
    WEB = "web"  # 浏览器自动化 Agent


class AgentConfig:
    """Agent 配置常量"""
    # 上下文管理（max_tokens 由 BaseModelClient.get_context_window() 动态获取）
    CONTEXT_THRESHOLD = 0.8
    KEEP_RECENT_MESSAGES = 10
    CHARS_PER_TOKEN = 4

    # 死循环检测
    DOOM_LOOP_THRESHOLD = 3
    DOOM_LOOP_HISTORY_SIZE = 10

    # 工具调用
    MAX_TOOL_ITERATIONS = 100

    # 空响应重试
    EMPTY_RESPONSE_RETRY_PROMPT = "请根据上述工具执行结果，总结并回答用户的原始问题。"


# ============================================================================
# 权限常量
# ============================================================================

class PermissionConfig:
    """权限配置常量"""
    REQUEST_TIMEOUT_SECONDS = 300  # 权限请求超时时间（秒）


# ============================================================================
# 工具常量
# ============================================================================

class ToolConfig:
    """工具配置常量"""
    # 文件操作工具
    FILE_TOOLS = ["read", "write", "edit"]
    # 命令执行工具
    COMMAND_TOOLS = ["bash"]
    # 只读工具（Plan Agent 可用）
    READONLY_TOOLS = ["read", "glob", "grep", "bash", "todowrite", "todoread"]

    # 结果截断
    TOOL_RESULT_PREVIEW_LENGTH = 200
    TOOL_RESULT_MAX_LENGTH = 500


# ============================================================================
# 日志常量
# ============================================================================

class LogConfig:
    """日志配置常量"""
    DEFAULT_LOG_DIR = "logs"
    MAX_LOG_FILE_SIZE = 10 * 1024 * 1024  # 10MB
    BACKUP_COUNT = 5
