"""
输入队列展示条
- InputQueueBar: 处理中时展示待处理输入队列的单行状态条
"""

from textual.widgets import Static
from rich.text import Text

from integrations.cli.styles import Styles


class InputQueueBar(Static):
    """处理中时展示待处理输入队列的单行状态条。

    - 队列为空时自动隐藏（display=False）
    - 只展示第一条内容，超出宽度截断，多余条目用 +N 提示
    - 颜色全部使用 Styles 常量
    """

    DEFAULT_CSS = """
    InputQueueBar {
        height: auto;
        width: 100%;
        padding: 0 1;
        display: none;
    }
    """

    def __init__(self, **kwargs):
        super().__init__("", **kwargs)
        self._queue: list[str] = []

    # ── 公共 API ──────────────────────────────────────────────────────────

    def push(self, text: str) -> None:
        """将一条输入追加到队列末尾，并刷新展示。"""
        self._queue.append(text)
        self._refresh()

    def pop(self) -> str | None:
        """取出队列头部（最早入队）的一条输入，刷新展示。"""
        if not self._queue:
            return None
        item = self._queue.pop(0)
        self._refresh()
        return item

    def clear_queue(self) -> None:
        """清空队列。"""
        self._queue.clear()
        self._refresh()

    @property
    def pending(self) -> list[str]:
        return list(self._queue)

    @property
    def is_empty(self) -> bool:
        return len(self._queue) == 0

    # ── 内部渲染 ──────────────────────────────────────────────────────────

    def _refresh(self) -> None:
        if not self._queue:
            self.display = False
            self.update("")
            return

        self.display = True
        available_width = (self.size.width or 80) - 2  # 减去 padding

        first = self._queue[0].replace("\n", " ").strip()
        rest = len(self._queue) - 1

        # 预留 "+N" 后缀的空间，"队列: " 占 4 字符
        suffix = f"  +{rest}" if rest > 0 else ""
        max_first = max(available_width - len(suffix) - 4, 10)

        if len(first) > max_first:
            first = first[:max_first - 1] + "…"

        text = Text()
        text.append("队列: ", style=Styles.INPUT_QUEUE_LABEL)
        text.append(first, style=Styles.INPUT_QUEUE_TEXT)
        if suffix:
            text.append(suffix, style=Styles.INPUT_QUEUE_BADGE)

        self.update(text)
