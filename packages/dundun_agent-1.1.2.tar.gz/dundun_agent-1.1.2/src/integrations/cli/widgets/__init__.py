"""
integrations.cli.widgets 包

将所有组件重新导出，保持外部 import 路径不变：
    from integrations.cli.widgets import PermissionBar, ClarifyBar, UserInput, ...
"""

from integrations.cli.widgets.markdown import LeftAlignedHeading, LeftAlignedMarkdown
from integrations.cli.widgets.selectable import SelectableStatic, SelectableRichLog
from integrations.cli.widgets.command_list import (
    CommandList,
    COMMAND_SUB_MENUS,
    AUTO_OPTIONS,
    DIRECT_EXECUTE_COMMANDS,
)
from integrations.cli.widgets.input_queue import InputQueueBar
from integrations.cli.widgets.permission import PermissionBar, ClarifyBar
from integrations.cli.widgets.user_input import UserInput

__all__ = [
    "LeftAlignedHeading",
    "LeftAlignedMarkdown",
    "SelectableStatic",
    "SelectableRichLog",
    "CommandList",
    "COMMAND_SUB_MENUS",
    "AUTO_OPTIONS",
    "DIRECT_EXECUTE_COMMANDS",
    "InputQueueBar",
    "PermissionBar",
    "ClarifyBar",
    "UserInput",
]
