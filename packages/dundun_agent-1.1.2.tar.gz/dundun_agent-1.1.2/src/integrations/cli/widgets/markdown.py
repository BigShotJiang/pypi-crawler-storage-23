"""
Markdown 渲染组件
- LeftAlignedHeading: 修复标题居中问题
- LeftAlignedMarkdown: 左对齐 Markdown 渲染器
"""

from rich.panel import Panel
from rich.markdown import Markdown, Heading
from rich import box


class LeftAlignedHeading(Heading):
    """左对齐的 Markdown 标题"""

    def __rich_console__(self, console, options):
        text = self.text
        text.justify = "left"
        if self.tag == "h1":
            yield Panel(
                text,
                box=box.HEAVY,
                style="markdown.h1.border",
            )
        else:
            yield text


class LeftAlignedMarkdown(Markdown):
    """左对齐的 Markdown 渲染器"""

    elements = {
        **Markdown.elements,
        "heading_open": LeftAlignedHeading,
    }
