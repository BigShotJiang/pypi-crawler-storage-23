"""
CLI 交互模块
包含 CLI、TUI、命令处理等接口组件

子模块结构：
- styles: 样式常量 (Styles, Icons)
- widgets: 自定义 Textual 组件 (LeftAlignedMarkdown, PermissionBar, UserInput)
- tools_display: 工具执行展示 (ToolExecution, ToolDisplayManager)
- app: Textual App 主窗口 (DundunApp)
- tui: TUI 兼容层 (EnhancedTUI)
- renderer: 流式渲染管理器 (StreamingRenderer, get_tui, get_streaming_renderer)
- cli: CLI 主入口
- commands: 斜杠命令处理
"""

from integrations.cli.commands import (
    CommandCategory,
    CommandInfo,
    CommandResult,
    CommandHandler,
    get_command_handler,
)

from integrations.cli.styles import Styles, Icons
from integrations.cli.widgets import LeftAlignedMarkdown, PermissionBar, UserInput
from integrations.cli.tools_display import ToolExecution, ToolDisplayManager
from integrations.cli.app import DundunApp
from integrations.cli.tui import EnhancedTUI
from integrations.cli.renderer import StreamingRenderer, get_tui, get_streaming_renderer

__all__ = [
    # Commands
    "CommandCategory",
    "CommandInfo",
    "CommandResult",
    "CommandHandler",
    "get_command_handler",
    # Styles
    "Styles",
    "Icons",
    # Widgets
    "LeftAlignedMarkdown",
    "PermissionBar",
    "UserInput",
    # Tools Display
    "ToolExecution",
    "ToolDisplayManager",
    # App
    "DundunApp",
    # TUI
    "EnhancedTUI",
    # Renderer
    "StreamingRenderer",
    "get_tui",
    "get_streaming_renderer",
]
