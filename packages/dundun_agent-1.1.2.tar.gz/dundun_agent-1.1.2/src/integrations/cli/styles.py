"""
样式常量和图标定义

命名规范：
  - 语义色（Styles.*）：按"所在功能区域 + 用途"命名，方便统一换主题
  - 所有静态颜色字符串均在此文件定义，业务代码不允许出现裸色字符串
"""


class Styles:
    """统一样式定义"""

    # ── 边框 ──────────────────────────────────────────────────────────────────
    BORDER = "#555555"              # 所有边框（输入区上下边框、功能区边框）

    # ── 语义色 ────────────────────────────────────────────────────────────────
    TOOL_NAME = "cyan"              # 工具名称 / Mode 字段值
    FILE_PATH = "blue"              # 文件路径（工具括号内）
    SUCCESS = "green"               # 成功图标 / Model 字段值 / Ctx 低用量
    ERROR = "red"                   # 错误 / AUTO 模式标识 / Ctx 高用量(≥80%)
    WARNING = "green"  # 警告 / Session ID / Ctx 中用量(60-80%) / Running spinner
    NUMBER = "magenta"              # 数字（行数、文件数等）
    DIM = "dim"                     # 辅助文本 / 分隔符 / 标签前缀
    TEXT = "white"                  # 普通文本（状态栏路径值）
    PROMPT = "bold green"           # 输入提示符（›）
    AGENT = "bold cyan"             # Agent 标识（未来扩展用）

    # ── Diff 展示 ─────────────────────────────────────────────────────────────
    ADDED = "green"                 # Diff 新增行前景色
    ADDED_BG = "on #1a2e1a"         # Diff 新增行背景色
    REMOVED = "red"                 # Diff 删除行前景色
    REMOVED_BG = "on #2e1a1a"       # Diff 删除行背景色

    # ── 欢迎页 ────────────────────────────────────────────────────────────────
    WELCOME_TITLE = "bold cyan"     # 欢迎页标题（Dundun Agent）
    WELCOME_SUBTITLE = "italic white"   # 欢迎页副标题
    WELCOME_VERSION = "italic gray50"   # 欢迎页版本信息

    # ── 状态栏 ────────────────────────────────────────────────────────────────
    STATUS_PATH = "white"           # 状态栏：工作路径值
    STATUS_BRANCH = "bold white"  # 状态栏：git 分支名
    STATUS_SESSION_ID = "yellow"    # 状态栏：Session ID 值
    STATUS_AUTO_MODE = "red"        # 状态栏：AUTO 模式标识
    STATUS_AGENT_TYPE = "cyan"      # 状态栏：Agent 类型值
    STATUS_MODEL = "cyan"  # 状态栏：模型名值
    STATUS_CTX_LOW = "green"        # 状态栏：Ctx 低用量（< 60%）
    STATUS_CTX_MID = "yellow"       # 状态栏：Ctx 中用量（60-80%）
    STATUS_CTX_HIGH = "red"         # 状态栏：Ctx 高用量（≥ 80%）
    STATUS_LABEL = "dim"            # 状态栏：所有标签前缀（Session:, Mode:, Model:, Ctx:）

    # ── 输入区 ────────────────────────────────────────────────────────────────
    INPUT_PROMPT_CSS = "green"      # CSS 中 #input-prompt 的 color（Textual CSS 字符串）

    # ── 权限请求面板 ──────────────────────────────────────────────────────────
    PERMISSION_TOOL_NAME = "bold cyan"  # 权限请求中高亮的工具名

    # ── Thinking 动画 ─────────────────────────────────────────────────────────
    THINKING = "bold dark_red"      # Thinking... 动画文字和 spinner 颜色

    # ── 子任务完成头部 ────────────────────────────────────────────────────────
    SUBTASK_SUCCESS_ICON = "bold green"  # 子任务成功时 ⏺ 图标颜色

    # ── 手动压缩完成 ──────────────────────────────────────────────────────────
    COMPACT_SUCCESS = "bold green"  # 手动压缩成功提示
    COMPACT_FAILURE = "bold red"    # 手动压缩失败提示

    # ── 模型切换提示 ──────────────────────────────────────────────────────────
    SWITCH_MODEL_ICON = "bold green"  # 切换模型成功图标（⏺）

    # ── 命令列表 ──────────────────────────────────────────────────────────────
    CMD_LIST_ARROW = "bold cyan"      # 命令列表选中项的三角箭头（▸）

    # ── 输入队列 ──────────────────────────────────────────────────────────────
    INPUT_QUEUE_LABEL = "bold white"  # "队列:" 标签（加粗白色）
    INPUT_QUEUE_TEXT = "dim"          # 队列条目文字（灰色）
    INPUT_QUEUE_BADGE = "dim"         # 队列计数徽章（如 +2）


class Icons:
    """统一图标定义"""
    OPERATION = "⏺"
    RESULT = "⎿"
    SUCCESS = "✔"
    FAILURE = "✗"
    SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    RUNNING = SPINNER_FRAMES[0]  # 默认静态展示时使用第一帧
    PROMPT = "›"
    WARNING = "!"
    QUESTION = "?"
    INFO = "ℹ"
    PENDING = "○"
