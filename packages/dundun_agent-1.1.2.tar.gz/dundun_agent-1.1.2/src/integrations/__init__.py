"""
Integrations 模块

外部交互渠道集成：
- cli: 命令行交互界面（CLI/TUI）
- rocketchat: Rocket.Chat 集成
"""
