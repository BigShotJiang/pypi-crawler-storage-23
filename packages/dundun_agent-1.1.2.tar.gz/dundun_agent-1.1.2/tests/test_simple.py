"""
简单的 WebSocket 测试
"""

import asyncio
import websockets
import json


async def test_simple():
    """简单测试"""
    print("连接到服务器...")

    try:
        async with websockets.connect("ws://localhost:8000/ws/test-simple") as ws:
            print("✅ 连接成功")

            # 发送消息
            message = {
                "type": "user_message",
                "data": {"content": "你好"}
            }
            print(f"发送: {message}")
            await ws.send(json.dumps(message))

            # 接收响应
            print("等待响应...")
            try:
                response = await asyncio.wait_for(ws.recv(), timeout=5.0)
                event = json.loads(response)
                print(f"收到: {event.get('type')}")
                print(f"完整事件: {event}")
            except asyncio.TimeoutError:
                print("❌ 超时，未收到响应")

    except Exception as e:
        print(f"❌ 错误: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(test_simple())
