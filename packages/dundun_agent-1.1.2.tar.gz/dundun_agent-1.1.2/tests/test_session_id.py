"""
测试会话 ID 生成器
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from core.session_id import SessionIDGenerator


def test_generate():
    """测试生成 ID"""
    print("=" * 60)
    print("测试 1: 生成 ID")
    print("=" * 60)

    # 生成 5 个 ID
    for i in range(5):
        session_id = SessionIDGenerator.generate()
        print(f"  ID {i+1}: {session_id}")
        assert len(session_id) == 8, f"ID 长度应该是 8，实际是 {len(session_id)}"
        assert SessionIDGenerator.validate(session_id), f"ID 格式无效: {session_id}"

    print("✅ 测试通过\n")


def test_create_subtask_id():
    """测试创建子任务 ID"""
    print("=" * 60)
    print("测试 2: 创建子任务 ID")
    print("=" * 60)

    # 根会话
    root_id = SessionIDGenerator.generate()
    print(f"  根会话: {root_id}")
    print(f"  深度: {SessionIDGenerator.get_depth(root_id)}")

    # 第一层子任务
    sub1_id = SessionIDGenerator.create_subtask_id(root_id)
    print(f"\n  子任务 1: {sub1_id}")
    print(f"  深度: {SessionIDGenerator.get_depth(sub1_id)}")
    print(f"  父 ID: {SessionIDGenerator.get_parent_id(sub1_id)}")
    print(f"  根 ID: {SessionIDGenerator.get_root_id(sub1_id)}")

    # 第二层子任务
    sub2_id = SessionIDGenerator.create_subtask_id(sub1_id)
    print(f"\n  子任务 2: {sub2_id}")
    print(f"  深度: {SessionIDGenerator.get_depth(sub2_id)}")
    print(f"  父 ID: {SessionIDGenerator.get_parent_id(sub2_id)}")
    print(f"  根 ID: {SessionIDGenerator.get_root_id(sub2_id)}")

    # 第三层子任务
    sub3_id = SessionIDGenerator.create_subtask_id(sub2_id)
    print(f"\n  子任务 3: {sub3_id}")
    print(f"  深度: {SessionIDGenerator.get_depth(sub3_id)}")
    print(f"  父 ID: {SessionIDGenerator.get_parent_id(sub3_id)}")
    print(f"  根 ID: {SessionIDGenerator.get_root_id(sub3_id)}")
    print(f"  路径: {' → '.join(SessionIDGenerator.get_path(sub3_id))}")

    # 验证
    assert SessionIDGenerator.get_depth(root_id) == 0
    assert SessionIDGenerator.get_depth(sub1_id) == 1
    assert SessionIDGenerator.get_depth(sub2_id) == 2
    assert SessionIDGenerator.get_depth(sub3_id) == 3
    assert SessionIDGenerator.get_parent_id(sub1_id) == root_id
    assert SessionIDGenerator.get_parent_id(sub2_id) == sub1_id
    assert SessionIDGenerator.get_root_id(sub3_id) == root_id

    print("\n✅ 测试通过\n")


def test_validate():
    """测试验证 ID"""
    print("=" * 60)
    print("测试 3: 验证 ID")
    print("=" * 60)

    valid_ids = [
        "a3b5c7d9",
        "12345678",
        "abcdefgh",
        "a3b5c7d9.x1y2z3w4",
        "a3b5c7d9.x1y2z3w4.m5n6p7q8",
    ]

    invalid_ids = [
        "",
        "abc",  # 太短
        "abcdefghij",  # 太长
        "ABC12345",  # 包含大写字母
        "a3b5c7d9.",  # 末尾有点
        ".a3b5c7d9",  # 开头有点
        "a3b5c7d9..x1y2z3w4",  # 双点
        "a3b5c7d9.xyz",  # 段长度不对
    ]

    print("  有效 ID:")
    for session_id in valid_ids:
        result = SessionIDGenerator.validate(session_id)
        print(f"    {session_id}: {result}")
        assert result, f"应该是有效的: {session_id}"

    print("\n  无效 ID:")
    for session_id in invalid_ids:
        result = SessionIDGenerator.validate(session_id)
        print(f"    {session_id}: {result}")
        assert not result, f"应该是无效的: {session_id}"

    print("\n✅ 测试通过\n")


def test_visualization():
    """测试可视化层级结构"""
    print("=" * 60)
    print("测试 4: 可视化层级结构")
    print("=" * 60)

    # 创建一个复杂的层级结构
    root = SessionIDGenerator.generate()
    sub1 = SessionIDGenerator.create_subtask_id(root)
    sub1_1 = SessionIDGenerator.create_subtask_id(sub1)
    sub1_2 = SessionIDGenerator.create_subtask_id(sub1)
    sub2 = SessionIDGenerator.create_subtask_id(root)
    sub2_1 = SessionIDGenerator.create_subtask_id(sub2)
    sub2_1_1 = SessionIDGenerator.create_subtask_id(sub2_1)

    def print_tree(session_id, prefix=""):
        """打印树形结构"""
        depth = SessionIDGenerator.get_depth(session_id)
        segments = SessionIDGenerator.get_path(session_id)
        current_segment = segments[-1]

        if depth == 0:
            print(f"{prefix}📋 根会话: {current_segment}")
        else:
            indent = "  " * depth
            print(f"{prefix}{indent}└─ 子任务 (深度 {depth}): {current_segment}")

    print("\n  层级结构:")
    print_tree(root)
    print_tree(sub1)
    print_tree(sub1_1)
    print_tree(sub1_2)
    print_tree(sub2)
    print_tree(sub2_1)
    print_tree(sub2_1_1)

    print("\n  完整 ID 示例:")
    print(f"    最深层级: {sub2_1_1}")
    print(f"    深度: {SessionIDGenerator.get_depth(sub2_1_1)}")
    print(f"    路径: {' → '.join(SessionIDGenerator.get_path(sub2_1_1))}")

    print("\n✅ 测试通过\n")


if __name__ == "__main__":
    test_generate()
    test_create_subtask_id()
    test_validate()
    test_visualization()

    print("=" * 60)
    print("所有测试通过！")
    print("=" * 60)
