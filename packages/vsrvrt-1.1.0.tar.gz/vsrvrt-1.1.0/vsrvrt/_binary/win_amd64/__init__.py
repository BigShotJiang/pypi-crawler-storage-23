"""Windows x64 pre-built binaries."""
