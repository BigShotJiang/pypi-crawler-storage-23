"""Integration tests for live MCP servers."""
