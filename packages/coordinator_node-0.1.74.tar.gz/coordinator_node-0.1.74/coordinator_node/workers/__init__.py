"""Worker entrypoints for predict, score, and report flows."""
