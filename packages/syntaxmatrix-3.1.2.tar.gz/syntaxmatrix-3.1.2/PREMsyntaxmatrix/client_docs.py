# syntaxmatrix/client_docs.py
from __future__ import annotations

import os
import re
import html
from dataclasses import dataclass
from typing import List, Tuple

from flask import abort, render_template
from markupsafe import Markup


@dataclass(frozen=True)
class TocItem:
    level: int
    id: str
    text: str


_slug_rx = re.compile(r"[^a-z0-9\- ]+")
_ws_rx = re.compile(r"\s+")


def _slugify(text: str) -> str:
    t = text.strip().lower()
    t = _slug_rx.sub("", t)
    t = _ws_rx.sub("-", t)
    t = t.strip("-")
    return t or "section"


def _extract_headings(md: str) -> List[Tuple[int, str]]:
    """
    Extract ATX-style markdown headings (#, ##, ###, ...), ignoring fenced code blocks.
    """
    headings: List[Tuple[int, str]] = []
    in_code = False
    for line in md.splitlines():
        if line.strip().startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue

        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if not m:
            continue
        level = len(m.group(1))
        title = m.group(2).strip()
        # Avoid weird headings like "### ----"
        if title and not all(ch in "-_=*" for ch in title):
            headings.append((level, title))
    return headings


def _render_markdown_minimal(md: str, heading_ids: dict[str, str]) -> str:
    """
    Minimal markdown renderer (safe-by-default):
    - headings, paragraphs, bullet lists, code fences, inline code, links, images
    - everything else is HTML-escaped
    """
    lines = md.splitlines()
    out: List[str] = []

    in_code = False
    code_lang = ""
    code_buf: List[str] = []

    in_ul = False

    def flush_ul():
        nonlocal in_ul
        if in_ul:
            out.append("</ul>")
            in_ul = False

    def flush_code():
        nonlocal in_code, code_lang, code_buf
        if not in_code:
            return
        code_text = "\n".join(code_buf)
        out.append(
            f'<pre class="smx-code"><code class="language-{html.escape(code_lang)}">'
            f"{html.escape(code_text)}</code></pre>"
        )
        in_code = False
        code_lang = ""
        code_buf = []

    def inline_fmt(s: str) -> str:
        s = html.escape(s)

        # inline code: `code`
        s = re.sub(r"`([^`]+)`", lambda m: f"<code>{html.escape(m.group(1))}</code>", s)

        # images: ![alt](url)
        s = re.sub(
            r"!\[([^\]]*)\]\(([^)]+)\)",
            lambda m: f'<img alt="{html.escape(m.group(1))}" src="{html.escape(m.group(2))}" />',
            s,
        )

        # links: [text](url)
        s = re.sub(
            r"\[([^\]]+)\]\(([^)]+)\)",
            lambda m: f'<a href="{html.escape(m.group(2))}" target="_blank" rel="noopener noreferrer">{html.escape(m.group(1))}</a>',
            s,
        )

        # bold **text**
        s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)

        # italics *text* (simple)
        s = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", s)

        return s

    # Pre-map heading text to stable IDs (supports duplicates)
    # heading_ids is already built with de-duplication.
    for raw in lines:
        line = raw.rstrip("\n")

        # fenced code blocks
        m_code = re.match(r"^\s*```(\w+)?\s*$", line)
        if m_code:
            flush_ul()
            if in_code:
                flush_code()
            else:
                in_code = True
                code_lang = (m_code.group(1) or "").strip()
                code_buf = []
            continue

        if in_code:
            code_buf.append(line)
            continue

        # headings
        m_h = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m_h:
            flush_ul()
            level = len(m_h.group(1))
            text = m_h.group(2).strip()
            hid = heading_ids.get(text) or _slugify(text)
            out.append(
                f'<h{level} id="{html.escape(hid)}" class="smx-h">{inline_fmt(text)}</h{level}>'
            )
            continue

        # bullet list items (supports "-" or "*")
        m_li = re.match(r"^\s*[-*]\s+(.+)\s*$", line)
        if m_li:
            if not in_ul:
                out.append("<ul>")
                in_ul = True
            out.append(f"<li>{inline_fmt(m_li.group(1).strip())}</li>")
            continue

        # blank line ends lists/paragraph chunks
        if line.strip() == "":
            flush_ul()
            out.append("")
            continue

        # blockquote (single-line)
        m_bq = re.match(r"^\s*>\s+(.+)\s*$", line)
        if m_bq:
            flush_ul()
            out.append(f"<blockquote>{inline_fmt(m_bq.group(1).strip())}</blockquote>")
            continue

        # horizontal rule
        if re.match(r"^\s*---\s*$", line):
            flush_ul()
            out.append("<hr/>")
            continue

        # normal paragraph line
        flush_ul()
        out.append(f"<p>{inline_fmt(line.strip())}</p>")

    flush_ul()
    flush_code()

    return "\n".join(out)


def build_docs_html_and_toc(md: str) -> Tuple[str, List[TocItem]]:
    headings = _extract_headings(md)

    # Build stable unique IDs
    used: dict[str, int] = {}
    heading_ids: dict[str, str] = {}

    toc: List[TocItem] = []
    for level, title in headings:
        base = _slugify(title)
        n = used.get(base, 0)
        used[base] = n + 1
        hid = base if n == 0 else f"{base}-{n+1}"

        # map by raw title (good enough for this README)
        # if duplicates exist with same title, only first maps here; duplicates are still in TOC correctly
        if title not in heading_ids:
            heading_ids[title] = hid

        toc.append(TocItem(level=level, id=hid, text=title))

    html_content = _render_markdown_minimal(md, heading_ids)
    return html_content, toc


def register_client_docs_routes(app, client_dir: str) -> None:
    """
    Call this once during app initialisation.
    Exposes:
      GET /docs
    """
    @app.get("/docs")
    def smx_client_docs():
        readme_path = os.path.join(client_dir, "README.md")
        if not os.path.exists(readme_path):
            abort(404, description="README.md not found in client root")

        with open(readme_path, "r", encoding="utf-8") as f:
            md = f.read()

        docs_html, toc = build_docs_html_and_toc(md)

        return render_template(
            "client_docs.html",
            page_title="System Documentation",
            toc=toc,
            docs_html=Markup(docs_html),
        )
