# kernel_manager.py

import jupyter_client
import nest_asyncio
import io, contextlib
import time   
from functools import wraps
import inspect, pandas as _pd
from functools import wraps
import inspect, pandas as _pd
import io, contextlib
import html as _html
import re as _re

nest_asyncio.apply()

class SyntaxMatrixKernelManager:
    _kernels = {}

    @classmethod
    def start_kernel(cls, session_id):
        if session_id in cls._kernels:
            return cls._kernels[session_id]
        km = jupyter_client.KernelManager()
        km.start_kernel()
        kc = km.client()
        kc.start_channels()
        cls._kernels[session_id] = (km, kc)
        return km, kc

    @classmethod
    def get_kernel(cls, session_id):
        return cls._kernels.get(session_id, (None, None))

    @classmethod
    def shutdown_kernel(cls, session_id):
        km, kc = cls._kernels.pop(session_id, (None, None))
        if kc:
            kc.stop_channels()
        if km:
            km.shutdown_kernel(now=True)

    @classmethod
    def cleanup_all(cls):
        for sid in list(cls._kernels):
            cls.shutdown_kernel(sid)
    
    def _prefer_display_over_to_html(code: str) -> str:
        """
        Convert common 'print(df.to_html())' patterns into IPython display(df).
        Best-effort only; avoids breaking code.
        """
        if not code or "to_html" not in code:
            return code

        # Replace print(X.to_html()) -> display(X)
        code2 = _re.sub(
            r"print\(\s*([A-Za-z_][A-Za-z0-9_\.]*)\s*\.to_html\(\s*\)\s*\)",
            r"display(\1)",
            code,
            flags=_re.IGNORECASE,
        )

        # Replace print(pd.DataFrame(...).to_html()) -> display(pd.DataFrame(...))
        code2 = _re.sub(
            r"print\(\s*(pd\.DataFrame\([^\)]*\))\s*\.to_html\(\s*\)\s*\)",
            r"display(\1)",
            code2,
            flags=_re.IGNORECASE,
        )

        # If we introduced display(), ensure import exists
        if "display(" in code2 and "from IPython.display import display" not in code2:
            code2 = "from IPython.display import display\n" + code2

        return code2


_df_cache = None

def execute_code_in_kernel(kc, code, timeout=120):

    code = SyntaxMatrixKernelManager._prefer_display_over_to_html(code)
    if "display(" in code and "from IPython.display import display" not in code:
        code = "from IPython.display import display\n" + code

    msg_id = kc.execute(
        code,
        user_expressions={"_last": "(_)",},
        allow_stdin=False,
    )
    output_blocks, errors = [], []
    start_time = time.time()

    while True:
        # Block until a message is available; if `timeout` is None this will block.
        try:
            msg = kc.get_iopub_msg(timeout=timeout)
        except Exception:
            break   # only trips if a numeric timeout was provided                             # timeout reached

        if msg["parent_header"].get("msg_id") != msg_id:
            continue

        mtype, content = msg["msg_type"], msg["content"]
        # Stop cleanly when the kernel reports it is idle (execution finished)        
        if mtype == 'status' and content.get('execution_state') == 'idle':
            break

        # if mtype == "stream":
        #     output_blocks.append(f"<pre>{content['text']}</pre>")

        if mtype == "stream":
            raw = content.get("text", "")
            # Remove noisy reprs from printed HTML/Markdown display objects
            lines = [
                ln for ln in raw.splitlines()
                if ("IPython.core.display.HTML object" not in ln
                    and "IPython.core.display.Markdown object" not in ln)
            ]
            txt = "\n".join(lines).strip()
            if txt:
                output_blocks.append(f"<pre>{_html.escape(txt)}</pre>")

        elif mtype in ("execute_result", "display_data"):
            data = content.get("data", {})
            if "text/html" in data:
                 output_blocks.append(data["text/html"])
            elif "image/png" in data:
                 output_blocks.append(
                     f"<img src='data:image/png;base64,{data['image/png']}' "
                     f"style='max-width:100%;'/>"
                 )
       
            else:
                 # Clean up plain-text reprs like "<IPython.core.display.HTML object>"
                txt = data.get("text/plain", "") or ""
                if ("IPython.core.display.HTML object" in txt
                    or "IPython.core.display.Markdown object" in txt):
                    # skip useless reprs entirely
                    continue
                output_blocks.append(f"<pre>{_html.escape(txt)}</pre>")

        elif mtype == "error":
            # keep the traceback html-friendly
            traceback_html = "<br>".join(content["traceback"])
            errors.append(f"<pre style='color:red;'>{traceback_html}</pre>")

    def _smx_strip_display_reprs(text: str) -> str:
        """Remove noisy Jupyter display reprs while keeping line breaks readable."""
        if text is None:
            return ""
        # Strip common display wrappers that sometimes leak into stdout
        text = text.replace("<IPython.core.display.HTML object>", "")
        text = text.replace("<IPython.core.display.Markdown object>", "")
        text = text.replace("<IPython.core.display.Image object>", "")

        # Normalise line endings but KEEP newlines
        text = text.replace("\r\n", "\n").replace("\r", "\n")

        # Collapse runs of spaces/tabs per line (do not flatten newlines)
        lines = []
        for ln in text.split("\n"):
            ln = _re.sub(r"[\t ]{2,}", " ", ln).rstrip()
            lines.append(ln)

        text = "\n".join(lines).strip()

        # Avoid huge blank sections
        text = _re.sub(r"\n{3,}", "\n\n", text)
        return text

    def _sanitize_table_html(table_html: str) -> str:
        """Best-effort sanitiser for DataFrame-style HTML tables (blocks scripts/events)."""
        if not table_html:
            return ""
        # Remove scripts and styles outright
        table_html = _re.sub(
            r"<\s*script[^>]*>.*?<\s*/\s*script\s*>",
            "",
            table_html,
            flags=_re.IGNORECASE | _re.DOTALL,
        )
        table_html = _re.sub(
            r"<\s*style[^>]*>.*?<\s*/\s*style\s*>",
            "",
            table_html,
            flags=_re.IGNORECASE | _re.DOTALL,
        )

        # Drop inline event handlers (onload=, onclick=, etc.)
        table_html = _re.sub(r"\son\w+\s*=\s*\"[^\"]*\"", "", table_html, flags=_re.IGNORECASE)
        table_html = _re.sub(r"\son\w+\s*=\s*\'[^\']*\'", "", table_html, flags=_re.IGNORECASE)

        # Block javascript: URLs
        table_html = _re.sub(r"javascript\s*:", "", table_html, flags=_re.IGNORECASE)
        return table_html.strip()


    def _smx_ensure_table_class(table_html: str) -> str:
        """Ensure DataFrame tables pick up the dashboard's .smx-table styling."""
        if not table_html:
            return ""

        def _inject_class(m):
            tag = m.group(0)

            # If there's already a class="", append smx-table
            if _re.search(r"\bclass\s*=", tag, flags=_re.IGNORECASE):
                tag = _re.sub(
                    r'(class\s*=\s*["\'])([^"\']*)(["\'])',
                    lambda mm: f"{mm.group(1)}{mm.group(2)} smx-table{mm.group(3)}",
                    tag,
                    count=1,
                    flags=_re.IGNORECASE,
                )
            else:
                # add class attr
                tag = tag[:-1] + ' class="smx-table">'

            # Remove noisy border attr if present (optional)
            tag = _re.sub(r'\sborder\s*=\s*["\']?\d+["\']?', "", tag, flags=_re.IGNORECASE)
            return tag

        return _re.sub(r"<table\b[^>]*>", _inject_class, table_html, count=1, flags=_re.IGNORECASE)

    def _smx_wrap_df_table(table_html: str, max_h: int = 460) -> str:
        """
        Wrap table in a scroll box and apply the same table class the dashboard already styles.
        """
        table_html = _smx_ensure_table_class(table_html)
        if not table_html:
            return ""
        return (
            f"<div class='smx-scroll' style='overflow:auto; max-height:{int(max_h)}px;'>"
            f"{table_html}"
            f"</div>"
        )

    def _split_text_and_tables(text: str):
        """Yield (kind, chunk) where kind is 'text' or 'table'."""
        if not text:
            return [("text", "")]
        out = []
        last = 0
        for m in _TABLE_RE.finditer(text):
            if m.start() > last:
                out.append(("text", text[last:m.start()]))
            out.append(("table", m.group(1)))
            last = m.end()
        if last < len(text):
            out.append(("text", text[last:]))
        return out

    _TABLE_RE = _re.compile(r"(<table\b.*?</table>)", flags=_re.IGNORECASE | _re.DOTALL)

    _cleaned_blocks = []
    for blk in output_blocks:
        # pre-wrapped plaintext
        if blk.startswith("<pre>") and blk.endswith("</pre>"):
            inner = blk[5:-6]
            inner = _html.unescape(inner)

            # If stdout contains HTML tables (e.g., DataFrame.to_html()), render them as tables
            # rather than showing the raw <table> markup inside a <pre> block.
            low = inner.lower()
            if "<table" in low and "</table>" in low:
                parts = _split_text_and_tables(inner)
            else:
                parts = [("text", inner)]

            for kind, chunk in parts:
                if not chunk:
                    continue
                if kind == "table":
                    safe_tbl = _sanitize_table_html(chunk)
                    if safe_tbl:
                        _cleaned_blocks.append(_smx_wrap_df_table(safe_tbl))
                else:
                    txt = _smx_strip_display_reprs(chunk)
                    if txt:
                        _cleaned_blocks.append(f"<pre>{_html.escape(txt)}</pre>")

            continue

        # html/img payloads: just remove stray repr tokens if they slipped in
        cleaned = _re.sub(r"<IPython\.core\.display\.[A-Za-z]+\s+object>", "", blk)
        low = cleaned.lower()
        if "<table" in low and "</table>" in low:
            parts = _split_text_and_tables(cleaned)
            for kind, chunk in parts:
                if not chunk:
                    continue
                if kind == "table":
                    safe_tbl = _sanitize_table_html(chunk)
                    wrapped = _smx_wrap_df_table(safe_tbl)
                    if wrapped:
                        _cleaned_blocks.append(wrapped)
                else:
                    # keep non-table html as-is
                    if chunk.strip():
                        _cleaned_blocks.append(chunk)
        else:
            _cleaned_blocks.append(cleaned)
    output_blocks = _cleaned_blocks

    return output_blocks, errors