# syntaxmatrix/themes.py

DEFAULT_THEMES = {
    "light": {  #1
        "background": "#f4f7f9",
        "text_color": "#333",
        "nav_background": "#007acc",
        "nav_text": "#fff",
        "chat_background": "#eef2f7", 
        "chat_border": "#e0e0e0",
        "widget_background": "#dddddd",
        "widget_border": "#007acc",
        "sidebar_background": "#eeeeee",
        "sidebar_text": "#333"
    },
    "dark": {  #2
        "background": "#1e1e1e",
        "text_color": "#fdf6e3",
        "nav_background": "#1e1e1e",
        "nav_text": "#fff",
        "chat_background": "#eef2f7",
        "chat_border": "#555",
        "widget_background": "#444",
        "widget_border": "#689ec3",
        "sidebar_background": "#1e1e1e",
        "sidebar_text": "#333"
    },
    "chark": {  #3
        "background": "#f4f7f9",
        "nav_background": "#123456",
        "nav_text": "#ffffff",
        "chat_border": "#cccccc",
        "chat_background": "#f7f7f7",
        "sidebar_background": "#eeeeee",
        "widget_background": "#dddddd",
        "widget_border": "#123456",
        "text_color": "#010101",
    },
    "github": {  #4
        "background": "#197dc0",
        "text_color": "#010101",
        "nav_background": "#594192",
        "nav_text": "#ffffff",
        "chat_background": "#9ad3e8",
        "chat_border": "#cccccc",
        "widget_background": "#ffffff",
        "widget_border": "#007acc",
        "sidebar_background": "#ffffff",
        "sidebar_text": "#333"
    },
    "solarized-light": {  #5
        "background": "#fdf6e3",
        "text_color": "#657b83",
        "nav_background": "#268bd2",
        "nav_text": "#fdf6e3",
        "chat_background": "#eee8d5",
        "chat_border": "#93a1a1",
        "widget_background": "#eee8d5",
        "widget_border": "#268bd2",
        "sidebar_background": "#eee8d5",
        "sidebar_text": "#657b83"
    },
    "solarized-dark": {  #6
        "background": "#002b36",
        "text_color": "#fdf6e3",
        "nav_background": "#268bd2",
        "nav_text": "#fdf6e3",
        "chat_background": "#073642",
        "chat_border": "#586e75",
        "widget_background": "#073642",
        "widget_border": "#268bd2",
        "sidebar_background": "#67929D",
        "sidebar_text": "#fdf6e3"
    },
    "oceanic-next": {  #7
        "background": "#012940",
        "text_color": "#525455",
        "nav_background": "#1C1F24",
        "nav_text": "#CBCCCE",
        "chat_background": "#2A303C",
        "chat_border": "#4F5B66",
        "widget_background": "#2A303C",
        "widget_border": "#4F5B66",
        "sidebar_background": "#1C1F24",
        "sidebar_text": "#070707"
    },
    "ayu-mirage": {  #8
        "background": "#785876",
        "text_color": "#0F0F0F",
        "nav_background": "#1F2430",
        "nav_text": "#A6ACCD",
        "chat_background": "#1F2430",
        "chat_border": "#4B5263",
        "widget_background": "#1F2430",
        "widget_border": "#4B5263",
        "sidebar_background": "#1F2430",
        "sidebar_text": "#141414"
    },
    "one-dark": {  #9
        "background": "#03740c",
        "text_color": "#1A1A1A",
        "nav_background": "#049cad",
        "nav_text": "#dbdce0",
        "chat_background": "#70F7EE",
        "chat_border": "#6f97ef",
        "widget_background": "#21252b",
        "widget_border": "#3e4451",
        "sidebar_background": "#21252b",
        "sidebar_text": "#252525"
    },

}
