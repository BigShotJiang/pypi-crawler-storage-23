from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Dict, Optional

from .verify import instance_fingerprint, verify_licence_payload
from .catalogue import resolve_entitlements
from syntaxmatrix.project_root import detect_project_root


def _utcnow() -> datetime:
    return datetime.utcnow()


def _iso_utc(dt: datetime) -> str:
    return dt.replace(microsecond=0).isoformat() + "Z"


def _parse_iso_utc(s: str) -> Optional[datetime]:
    if not s:
        return None
    s = str(s).strip()
    if not s:
        return None
    s2 = s.replace(" ", "T")
    if s2.endswith("Z"):
        s2 = s2[:-1]
    try:
        return datetime.fromisoformat(s2)
    except Exception:
        return None


def _safe_json_loads(raw: str, default: Any) -> Any:
    try:
        return json.loads(raw)
    except Exception:
        return default


def _truthy(v: Any) -> bool:
    return str(v).strip().lower() in ("1", "true", "yes", "y", "on")


@dataclass
class PremiumState:
    trial_days: int
    trial_started_at: Optional[str]
    trial_active: bool
    trial_days_left: int
    plan: str
    entitlements: Dict[str, Any]
    source: str  # trial | env | file | db | none
    instance_id: Optional[str] = None
    remote_status: Optional[str] = None
    remote_grace_until: Optional[str] = None


def _fallback_entitlements(plan: str) -> Dict[str, Any]:
    """Hard-coded fallbacks (only used if catalogue files are missing).

    Normal path: entitlements are catalogue-driven so you can add/update values
    without touching Python.
    """
    p = (plan or "").strip().lower()
    if p == "pro":
        return {
            "plan": "pro",
            "docs": True,
            "ml_lab": True,
            "registration": True,
            "theme_toggle": True,
            "branding_controls": True,
            "plugins": True,
            "premium_db_backends": False,
            "audit_export": True,
            "max_users": 10,
            "max_pages": 50,
            "max_upload_mb": 200,
            "max_pdf_pages_per_doc": 300,
            "max_vector_records": 50000,
        }
    if p == "business":
        return {
            "plan": "business",
            "docs": True,
            "ml_lab": True,
            "registration": True,
            "theme_toggle": True,
            "branding_controls": True,
            "plugins": True,
            "premium_db_backends": True,
            "audit_export": True,
            "max_users": 25,
            "max_pages": 150,
            "max_upload_mb": 750,
            "max_pdf_pages_per_doc": 750,
            "max_vector_records": 200000,
        }
    if p == "enterprise":
        return {
            "plan": "enterprise",
            "docs": True,
            "ml_lab": True,
            "registration": True,
            "theme_toggle": True,
            "branding_controls": True,
            "plugins": True,
            "premium_db_backends": True,
            "audit_export": True,
            "max_users": 200,
            "max_pages": 500,
            "max_upload_mb": 2000,
            "max_pdf_pages_per_doc": 2000,
            "max_vector_records": 500000,
        }
    if p == "trial":
        return {
            "plan": "trial",
            "docs": True,
            "ml_lab": True,
            "registration": True,
            "theme_toggle": True,
            "branding_controls": True,
            "plugins": True,
            "premium_db_backends": True,
            "audit_export": True,
            "max_users": 9999,
            "max_pages": 9999,
            "max_upload_mb": 9999,
            "max_pdf_pages_per_doc": 999999,
            "max_vector_records": 999999999,
        }
    return {
        "plan": "free",
        "docs": False,
        "ml_lab": False,
        "registration": False,
        "theme_toggle": False,
        "branding_controls": False,
        "plugins": False,
        "premium_db_backends": False,
        "audit_export": False,
        "max_users": 1,
        "max_pages": 3,
        "max_upload_mb": 5,
        "max_pdf_pages_per_doc": 20,
        "max_vector_records": 1500,
    }


def _catalogue_entitlements(plan: str, *, version: Optional[str] = None, addons: Optional[list] = None) -> Dict[str, Any]:
    """Resolve entitlements from the catalogue (preferred)."""
    try:
        ent = resolve_entitlements(plan_id=plan, version=version, addons=addons)
        # If catalogue is missing or empty, fall back.
        if not isinstance(ent, dict) or len(ent.keys()) <= 2:
            return _fallback_entitlements(plan)
        return ent
    except Exception:
        return _fallback_entitlements(plan)


def free_entitlements() -> Dict[str, Any]:
    return _catalogue_entitlements("free")


def pro_entitlements() -> Dict[str, Any]:
    return _catalogue_entitlements("pro")


def enterprise_entitlements() -> Dict[str, Any]:
    return _catalogue_entitlements("enterprise")


def trial_entitlements() -> Dict[str, Any]:
    return _catalogue_entitlements("trial")


def _choose_preset_for_plan(plan: str) -> Dict[str, Any]:
    p = (plan or "").strip().lower()
    if p == "pro":
        return pro_entitlements()
    if p == "enterprise":
        return enterprise_entitlements()
    if p == "trial":
        return trial_entitlements()
    return free_entitlements()


def _plan_from_entitlements(ent: Dict[str, Any]) -> str:
    plan = str(ent.get("plan") or "").strip().lower()
    return plan or "free"


def _apply_entitlements_to_feature_flags(db: object, ent: Dict[str, Any]) -> None:
    set_setting = getattr(db, "set_setting", None)
    if not callable(set_setting):
        return

    def _as01(b: Any) -> str:
        return "1" if bool(b) else "0"

    set_setting("feature.site_documentation", _as01(ent.get("docs")))
    set_setting("feature.ml_lab", _as01(ent.get("ml_lab")))
    set_setting("feature.registration", _as01(ent.get("registration")))
    set_setting("feature.theme_toggle", _as01(ent.get("theme_toggle")))


def _read_payload_from_env(env_key: str = "SMX_PREMIUM_ENTITLEMENTS") -> Optional[Dict[str, Any]]:
    raw = os.environ.get(env_key)
    if not raw:
        return None
    data = _safe_json_loads(raw, default=None)
    return data if isinstance(data, dict) else None


def _read_payload_from_file(client_dir: str, relpath: str = os.path.join("premium", "licence.json")) -> Optional[Dict[str, Any]]:
    p = os.path.join(client_dir, relpath)
    if not os.path.exists(p):
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def ensure_premium_state(
    *,
    db: object,
    client_dir: str,
    trial_days: int = 7,
    now: Optional[datetime] = None,
    refresh_entitlements: bool = True,
) -> PremiumState:
    # Prefer the detected project root (your current design),
    # but fall back to provided client_dir if detection fails.
    try:
        detected = str(detect_project_root())
        if detected:
            client_dir = detected
    except Exception:
        client_dir = str(client_dir or "")

    get_setting = getattr(db, "get_setting", None)
    set_setting = getattr(db, "set_setting", None)
    if not callable(get_setting) or not callable(set_setting):
        ent = free_entitlements()
        return PremiumState(
            trial_days=int(trial_days or 7),
            trial_started_at=None,
            trial_active=False,
            trial_days_left=0,
            plan=_plan_from_entitlements(ent),
            entitlements=ent,
            source="none",
            instance_id=None,
            remote_status=None,
            remote_grace_until=None,
        )

    try:
        set_setting("premium.client_dir", client_dir)
    except Exception:
        pass

    licence_server = (os.environ.get("SMX_LICENCE_SERVER_URL") or "").strip()
    if not licence_server:
        licence_server = "https://licence.syntaxmatrix.com"

    # How often to sync remote licence state (minutes).
    try:
        sync_minutes = int((os.environ.get("SMX_LICENCE_SYNC_MINUTES") or "10").strip() or "10")
    except Exception:
        sync_minutes = 10
    if sync_minutes < 1:
        sync_minutes = 1

    now_dt = now or _utcnow()

    def _now_iso() -> str:
        return now_dt.replace(microsecond=0).isoformat() + "Z"

    def _sync_due(last_iso: str) -> bool:
        last = _parse_iso_utc(last_iso)
        if not last:
            return True
        return (now_dt - last).total_seconds() >= sync_minutes * 60

    def _post(url: str, payload: dict) -> dict:
        import urllib.request

        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                return json.loads(raw) if raw else {}
        except Exception:
            return {}

    remote_status: Optional[str] = None
    remote_grace_until: Optional[str] = None

    try:
        trial_days_int = int(trial_days)
    except Exception:
        trial_days_int = 14
    if trial_days_int <= 0:
        trial_days_int = 14

    inst_fp = ""
    try:
        inst_fp = instance_fingerprint()
        if inst_fp:
            set_setting("premium.instance_id", inst_fp)
    except Exception:
        inst_fp = ""

    remote_status = (get_setting("premium.remote_status", "") or "").strip().lower() or None
    remote_grace_until = (get_setting("premium.remote_grace_until", "") or "").strip() or None

    if licence_server and refresh_entitlements and inst_fp:
        last_sync = get_setting("premium.last_sync_at", "") or ""
        if _sync_due(last_sync):
            resp = _post(f"{licence_server}/v1/licence", {"instance_fp": inst_fp})
            if isinstance(resp, dict) and resp.get("ok"):
                st = str(resp.get("status") or "").strip().lower() or ""
                if st:
                    remote_status = st
                    try:
                        set_setting("premium.remote_status", st)
                    except Exception:
                        pass

                gu_iso = None
                if resp.get("grace_until_iso"):
                    gu_iso = str(resp.get("grace_until_iso") or "").strip() or None
                elif resp.get("grace_until"):
                    try:
                        gu_ts = int(resp.get("grace_until"))
                        gu_iso = _iso_utc(datetime.utcfromtimestamp(gu_ts))
                    except Exception:
                        gu_iso = None

                remote_grace_until = gu_iso
                try:
                    set_setting("premium.remote_grace_until", gu_iso or "")
                except Exception:
                    pass

                lic_path = os.path.join(client_dir, "premium", "licence.json")
                if st in ("active", "past_due") and isinstance(resp.get("licence"), dict):
                    try:
                        os.makedirs(os.path.dirname(lic_path), exist_ok=True)
                        with open(lic_path, "w", encoding="utf-8") as f:
                            json.dump(resp["licence"], f, ensure_ascii=False, indent=2)
                    except Exception:
                        pass
                elif st == "revoked":
                    try:
                        if os.path.exists(lic_path):
                            os.remove(lic_path)
                    except Exception:
                        pass

                try:
                    set_setting("premium.last_sync_at", _now_iso())
                except Exception:
                    pass

    remote_revoked = (str(remote_status or "").strip().lower() == "revoked")

    # Trial tracking
    started_raw = get_setting("premium.trial_started_at", "") or ""
    started_dt = _parse_iso_utc(started_raw)
    if started_dt is None:
        started_dt = now_dt
        started_raw = _iso_utc(started_dt)
        try:
            set_setting("premium.trial_started_at", started_raw)
        except Exception:
            pass

    elapsed = now_dt - started_dt
    trial_active = elapsed < timedelta(days=trial_days_int)
    days_left = 0
    if trial_active:
        remaining = timedelta(days=trial_days_int) - elapsed
        days_left = max(1, int((remaining.total_seconds() + 86399) // 86400))

    if remote_revoked:
        trial_active = False
        days_left = 0

    try:
        set_setting("premium.trial_days", str(trial_days_int))
        set_setting("premium.trial_active", "1" if trial_active else "0")
    except Exception:
        pass

    source = "none"
    ent: Dict[str, Any] = {}  
    last_err = ""

    allow_unsigned = trial_active or _truthy(os.environ.get("SMX_PREMIUM_ALLOW_UNSIGNED", "0"))

    def _accept_payload(payload: Optional[Dict[str, Any]], src: str) -> Optional[Dict[str, Any]]:
        nonlocal last_err, source
        if not payload:
            return None
        verified = verify_licence_payload(
            payload,
            now=now_dt,
            allow_unsigned=allow_unsigned,
        )
        if not verified.ok:
            last_err = verified.error or "Licence rejected"
            return None
        source = src
        return verified.entitlements

    def _resolve_from_claims(claims: Dict[str, Any]) -> Dict[str, Any]:
        plan_claim = str(claims.get("plan_id") or claims.get("plan") or "free").strip().lower() or "free"
        ver = str(claims.get("entitlement_version") or claims.get("entitlementVersion") or "").strip() or None
        addons = claims.get("addons") if isinstance(claims.get("addons"), list) else None
        overrides = claims.get("entitlements") if isinstance(claims.get("entitlements"), dict) else None

        ent_resolved = _catalogue_entitlements(plan_claim, version=ver, addons=addons)

        if overrides:
            for k, v in overrides.items():
                if k in ("sig", "instance_id", "issued_at", "expires_at"):
                    continue
                ent_resolved[k] = v

        return ent_resolved

    ent = {}
    last_err = ""

    if remote_revoked:
        ent = free_entitlements()
        source = "remote"
        last_err = ""
    else:
        if refresh_entitlements:
            payload = _read_payload_from_file(client_dir)
            claims = _accept_payload(payload, "file") or {}
            if claims:
                ent = _resolve_from_claims(claims)
                source = "file"

        if not ent:
            if trial_active:
                ent = trial_entitlements()
                source = "trial"
            else:
                ent = free_entitlements()
                source = "none"

    try:
        set_setting("premium.last_licence_error", last_err)
    except Exception:
        pass

    plan = _plan_from_entitlements(ent)

    trial_active_eff = trial_active
    days_left_eff = days_left
    if plan in ("pro", "business", "enterprise"):
        trial_active_eff = False
        days_left_eff = 0

    try:
        set_setting("premium.plan", plan)
        set_setting("premium.entitlements", json.dumps(ent, ensure_ascii=False))
    except Exception:
        pass

    try:
        _apply_entitlements_to_feature_flags(db, ent)
    except Exception:
        pass

    return PremiumState(
        trial_days=trial_days_int,
        trial_started_at=started_raw,
        trial_active=trial_active_eff,
        trial_days_left=days_left_eff,
        plan=plan,
        entitlements=ent,
        source=source,
        instance_id=(inst_fp or None),
        remote_status=remote_status,
        remote_grace_until=remote_grace_until,
    )
