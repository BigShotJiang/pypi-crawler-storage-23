"""Premium support.

This package contains runtime plumbing for premium features (entitlements +
plugin loading).

Key idea:
- FeatureGate reads a single entitlement dict from env/db/licence.json
- ensure_premium_state() resolves trial + plan entitlements and writes them
  into app_settings so the rest of the app can safely gate routes + navbar.

Premium implementations (e.g. non-SQLite DB backends) should live in separate,
private distributions.
"""

from .gate import FeatureGate
from .state import ensure_premium_state, PremiumState

__all__ = ["FeatureGate", "ensure_premium_state", "PremiumState"]
