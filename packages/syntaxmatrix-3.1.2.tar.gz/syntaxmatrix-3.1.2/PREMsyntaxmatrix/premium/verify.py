from __future__ import annotations

import base64
import hashlib
import json
import os
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Optional

from syntaxmatrix.project_root import detect_project_root

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
except Exception:
    Ed25519PublicKey = None 

DEFAULT_PUBLIC_KEY_B64 = (
    (os.environ.get("SMX_PREMIUM_PUBLIC_KEY_B64") or "").strip()
    or "Pne3EX_NoOo6pZ4UB87kpXaTf78A6tEfuwoTBZvVRbg"
)

_CACHED_PUBLIC_KEY_B64: Optional[str] = None
SECRET_KEY_FILENAME = ".smx_secret_key"

def _utcnow() -> datetime:
    return datetime.utcnow()


def _resolved_client_dir() -> str:
    return str(detect_project_root())


def _parse_iso_utc(s: str) -> Optional[datetime]:
    if not s:
        return None
    s = str(s).strip()
    if not s:
        return None
    s2 = s.replace(" ", "T")
    if s2.endswith("Z"):
        s2 = s2[:-1]
    try:
        return datetime.fromisoformat(s2)
    except Exception:
        return None


def _b64url_decode(s: str) -> bytes:
    s = (s or "").strip()
    if not s:
        return b""
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode((s + pad).encode("utf-8"))


def _b64url_encode(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode("utf-8").rstrip("=")


def _safe_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _truthy(v: Any) -> bool:
    return str(v).strip().lower() in ("1", "true", "yes", "on", "y")


def instance_fingerprint() -> str:
    client_dir = _resolved_client_dir()
    p = os.path.join(client_dir, SECRET_KEY_FILENAME)
    try:
        secret = open(p, "r", encoding="utf-8").read().strip()
    except Exception:
        return ""
    if not secret:
        return ""
    digest = hashlib.sha256(secret.encode("utf-8")).digest()
    return _b64url_encode(digest)


@dataclass
class VerifiedLicence:
    ok: bool
    entitlements: Dict[str, Any]
    plan: str
    error: str


def _normalise_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    if isinstance(payload.get("entitlements"), dict):
        ent = dict(payload.get("entitlements") or {})
        for k in ("plan_id", "plan", "entitlement_version", "addons"):
            if payload.get(k) is not None and ent.get(k) is None:
                ent[k] = payload.get(k)
        return ent
    return dict(payload)


def _get_public_key_b64() -> str:
    """
    Resolve Ed25519 public key used for licence verification.

    Order:
      1) SMX_PREMIUM_PUBLIC_KEY_B64 env var
      2) in-process cache
      3) <client_dir>/premium/public_key.b64 (cached file)
      4) GET <SMX_LICENCE_SERVER_URL>/v1/public-key (then cache to file)
      5) DEFAULT_PUBLIC_KEY_B64 fallback
    """
    global _CACHED_PUBLIC_KEY_B64

    env = os.environ.get("SMX_PREMIUM_PUBLIC_KEY_B64")
    if env and env.strip():
        _CACHED_PUBLIC_KEY_B64 = env.strip()
        return _CACHED_PUBLIC_KEY_B64
    if _CACHED_PUBLIC_KEY_B64 and _CACHED_PUBLIC_KEY_B64.strip():
        return _CACHED_PUBLIC_KEY_B64.strip()
    client_dir = _resolved_client_dir()
    try:
        p = os.path.join(client_dir, "premium", "public_key.b64")
        if os.path.exists(p):
            key = open(p, "r", encoding="utf-8").read().strip()
            if key:
                _CACHED_PUBLIC_KEY_B64 = key
                return key
    except Exception:
        pass
    licence_server = (os.environ.get("SMX_LICENCE_SERVER_URL") or "").strip()
    if licence_server:
        url = licence_server.rstrip("/") + "/v1/public-key"
        try:
            import urllib.request

            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=10) as resp:
                raw = resp.read().decode("utf-8", errors="replace").strip()

            data = json.loads(raw) if raw else {}
            key = str(data.get("public_key_b64") or "").strip()
            if key:
                _CACHED_PUBLIC_KEY_B64 = key
                try:
                    os.makedirs(os.path.join(client_dir, "premium"), exist_ok=True)
                    with open(os.path.join(client_dir, "premium", "public_key.b64"), "w", encoding="utf-8") as f:
                        f.write(key)
                except Exception:
                    pass
                return key
        except Exception:
            pass
    return (DEFAULT_PUBLIC_KEY_B64 or "").strip()


def _licence_message(payload: Dict[str, Any]) -> bytes:
    body = {k: v for k, v in payload.items() if k != "sig"}
    return _safe_json(body)


def verify_licence_payload(
    payload: Dict[str, Any],
    *,
    now: Optional[datetime] = None,
    allow_unsigned: Optional[bool] = None,
) -> VerifiedLicence:
    if not isinstance(payload, dict) or not payload:
        return VerifiedLicence(False, {}, "free", "Licence payload is empty or not a JSON object")

    allow_unsigned_eff = _truthy(os.environ.get("SMX_PREMIUM_ALLOW_UNSIGNED", "0"))
    if allow_unsigned is not None:
        allow_unsigned_eff = bool(allow_unsigned)

    fp = instance_fingerprint()
    if not fp:
        return VerifiedLicence(False, {}, "free", "Cannot compute instance fingerprint (missing .smx_secret_key)")

    lic_inst = str(payload.get("instance_id") or payload.get("instanceId") or "").strip()
    if not lic_inst:
        if not allow_unsigned_eff:
            return VerifiedLicence(False, {}, "free", "Licence missing instance_id")
    elif lic_inst != fp:
        return VerifiedLicence(False, {}, "free", "Instance mismatch (licence is for a different install)")

    now_dt = now or _utcnow()
    exp_raw = payload.get("expires_at") or payload.get("expiresAt")
    exp_dt = _parse_iso_utc(str(exp_raw)) if exp_raw else None
    if exp_dt and now_dt > exp_dt:
        return VerifiedLicence(False, {}, "free", "Licence has expired")

    sig_b64 = str(payload.get("sig") or "").strip()
    if not sig_b64:
        if not allow_unsigned_eff:
            return VerifiedLicence(False, {}, "free", "Licence is unsigned (sig missing)")
        ent = _normalise_payload(payload)
        plan = str(ent.get("plan_id") or ent.get("plan") or payload.get("plan_id") or payload.get("plan") or "free").strip().lower() or "free"
        return VerifiedLicence(True, ent, plan, "")

    if Ed25519PublicKey is None:
        return VerifiedLicence(False, {}, "free", "cryptography package is required for licence verification")

    pub_b64 = _get_public_key_b64()
    if not pub_b64:
        return VerifiedLicence(False, {}, "free", "Public key not configured (SMX_PREMIUM_PUBLIC_KEY_B64)")

    try:
        pub_bytes = _b64url_decode(pub_b64)
        pub = Ed25519PublicKey.from_public_bytes(pub_bytes)
    except Exception:
        return VerifiedLicence(False, {}, "free", "Public key is invalid")

    try:
        sig = _b64url_decode(sig_b64)
        msg = _licence_message(payload)
        pub.verify(sig, msg)
    except Exception:
        return VerifiedLicence(False, {}, "free", "Signature verification failed")

    ent = _normalise_payload(payload)
    plan = str(ent.get("plan_id") or ent.get("plan") or payload.get("plan_id") or payload.get("plan") or "free").strip().lower() or "free"
    return VerifiedLicence(True, ent, plan, "")
