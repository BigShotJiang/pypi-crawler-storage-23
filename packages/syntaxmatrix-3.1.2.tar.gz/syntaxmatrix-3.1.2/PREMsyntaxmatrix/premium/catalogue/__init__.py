from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional, Tuple


def _safe_json_loads(raw: str, default: Any) -> Any:
    try:
        return json.loads(raw)
    except Exception:
        return default


def _read_json(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _catalogue_dir() -> str:
    return os.path.join(os.path.dirname(__file__))


def load_index() -> Dict[str, Any]:
    """Load catalogue index.json (safe, returns empty dict on failure)."""
    return _read_json(os.path.join(_catalogue_dir(), "index.json"))


def load_catalogue(version: Optional[str] = None) -> Tuple[Dict[str, Any], str]:
    """Load a catalogue for the requested version.

    Returns: (catalogue_dict, resolved_version)
    """
    idx = load_index()
    resolved = (version or "").strip() or str(idx.get("default") or "").strip()
    versions = idx.get("versions") if isinstance(idx.get("versions"), dict) else {}
    fname = versions.get(resolved) if isinstance(versions, dict) else None

    if not fname:
        # Fall back to default file name if index is missing or version unknown.
        fname = "catalogue.v1.json"

    cat = _read_json(os.path.join(_catalogue_dir(), str(fname)))
    # If the loaded file advertises a version, prefer that.
    advertised = str(cat.get("version") or "").strip()
    if advertised:
        resolved = advertised
    return cat, resolved


def ui_labels(version: Optional[str] = None) -> Dict[str, Any]:
    cat, _ = load_catalogue(version)
    ui = cat.get("ui") if isinstance(cat.get("ui"), dict) else {}
    labels = ui.get("labels") if isinstance(ui.get("labels"), dict) else {}
    return labels if isinstance(labels, dict) else {}


def resolve_entitlements(
    *,
    plan_id: str,
    version: Optional[str] = None,
    addons: Optional[list] = None,
    custom_overrides: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Resolve final entitlements from catalogue.

    This keeps entitlements data-driven:
    - base entitlements come from the plan in the catalogue
    - optional add-ons apply deltas/overrides
    - optional custom_overrides apply last
    """
    pid = (plan_id or "free").strip().lower() or "free"
    cat, resolved_version = load_catalogue(version)

    plans = cat.get("plans") if isinstance(cat.get("plans"), dict) else {}
    p = plans.get(pid) if isinstance(plans, dict) else None
    base = {}
    if isinstance(p, dict) and isinstance(p.get("entitlements"), dict):
        base = dict(p.get("entitlements") or {})

    # Always stamp plan + version for UI/debugging.
    base["plan"] = pid
    base["entitlement_version"] = resolved_version

    # Apply add-ons.
    addons_list = addons if isinstance(addons, list) else []
    if addons_list:
        addons_def = cat.get("addons") if isinstance(cat.get("addons"), dict) else {}
        for addon_id in addons_list:
            aid = str(addon_id or "").strip()
            if not aid:
                continue
            a = addons_def.get(aid) if isinstance(addons_def, dict) else None
            if not isinstance(a, dict):
                continue
            delta = a.get("entitlements_delta") if isinstance(a.get("entitlements_delta"), dict) else {}
            for k, v in (delta or {}).items():
                # Support "+N" increment for numeric limits.
                if isinstance(v, str) and v.strip().startswith("+"):
                    try:
                        inc = int(v.strip()[1:])
                        cur = int(base.get(k) or 0)
                        base[k] = cur + inc
                        continue
                    except Exception:
                        pass
                base[k] = v
        base["addons"] = addons_list

    # Apply overrides last.
    if isinstance(custom_overrides, dict) and custom_overrides:
        for k, v in custom_overrides.items():
            if k in ("sig",):
                continue
            base[k] = v

    return base
