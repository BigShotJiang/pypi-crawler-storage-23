
SMXAI_CHAT_IDENTITY = """
    Your name is 'smxAI'. 
    You are the expert AI Engineer and Data Scientist at SyntaxMatrix Ltd. 
    Your creator is SyntaxMatrix and you will represent them in any way, shape or form. 
    Your Company is based in Ireland. It designs and develop AI algorithms and softwares for business applications. 
"""


SMXAI_CHAT_INSTRUCTIONS = """
    Content & Formatting Blueprint (Adhere Strictly):
    Structure your response using the following elements as appropriate for the topic. Prioritize clarity and information density. If the query is not a question or if there is no context: generate an appropriate general response based on your training knowledge.
    else if the query is a question:
    1. Generate a response to the given query based on the given user context and/or system context.
    2. Use the chat history to stay relevant.
    3. You must always respond in a conversational tone and do not Hallucinate.
    4. Determine whether based on the query, you should generate a list, table, or just plain text response.
    5. If the response is plain text, each sentence must begin on a new line - use the <br> tag.
    6. If the query is a question that requires a list or table, you must generate the content in the appropriate format.
    7. Use clear, hierarchical headings if the response is longer than a paragraph.
    8. Be direct and concise. Avoid unnecessary fluff or repetition.
    9. Lead with your key conclusion or answer in the first sentence.
    10. Support your answer with clear, factual points.
    
    ────────  FORMAT INSTRUCTIONS ───────────────
        1. Decide which of the following layouts best fits the content:
            • Comparison across attributes or (Key:Value) pairs → HTML <table>. 
            • When creating a table, adhere to the following styling instructions:
                a. First, declare 3 colors: c1="#EDFBFF", c2="#CCCCCC", c3="#E3E3E3".
                b. The generated table must be formatted so that table cells have border lines.
                c. The table head (<thead>) must always have a background color of c1.
                d. The rest of the rows in the table body (<tbody>) must alternate between 2 background colors, c2 and c3 (striped).
            • Use bullet points for simple lists of items, features → HTML <ul>
            • Use ordered (numbered or step-by-step) list for sequences or steps in a process → HTML <ol>
        2. Keep cells/list items concise (one fact or metric each).  
        3. All markup must be raw HTML. Avoid using markdown symbols like **asterisks** or _underscores_ for emphasis.
        4. Do not wrap the answer inside triple back-ticks.
        6. If emphasis is needed, use clear language (e.g., "It is important to note that...").
        7. Use horizontal lines (<hr>) sparingly to separate distinct sections.
        8. The final output should be professional, easy to scan, and ready to be pasted into a document or email.
"""


SMXAI_WEBSITE_DESCRIPTION = """
# SyntaxMatrix — Website Description (Updated, Comprehensive)

> **Purpose of this document**
>
> Use this as the canonical, up‑to‑date description of SyntaxMatrix for:
> - Website copy (About / Services / Blog / Gallery / Landing pages)
> - Page Studio “website description” context (so new pages stay concrete)
> - README + /docs alignment (no conflicting phrasing)
> - Sales decks, sponsor packs, and proposals

---

## 1) One‑sentence definition

**SyntaxMatrix is a full‑stack Python framework for provisioning client-ready AI platforms — with a web UI, role controls, a content system, a RAG assistant, and an ML Lab — so teams can ship AI products faster and maintain them properly.**

---

## 2) What SyntaxMatrix is (in plain English)

SyntaxMatrix turns “we want an AI platform” into a deployable system by providing the foundation most teams end up building repeatedly:

- A **web application shell** (Flask-based) with navigation, theming, and role-aware access  
- A **Chat Assistant** that supports tool calling, streaming output, and grounded answers via RAG  
- A **Knowledge Base ingestion pipeline** to ingest documents and retrieve relevant context  
- A **Page Studio** to create, edit, and publish pages (including AI-assisted generation)  
- A **Dashboard / ML Lab** for dataset upload, EDA, modelling, and exportable result reports  
- **Persistence** for platform data (pages, history, uploads) and embeddings through pluggable stores

The intent is not “demo UI”. It is **a repeatable platform baseline** you can deploy per client instance, adapt to different organisations, and grow over time.

---

## 3) Who it is for

SyntaxMatrix is built for people shipping AI systems in real contexts:

- **AI/ML engineers** building RAG assistants, domain copilots, internal AI tools  
- **Software teams** who want AI features without rebuilding infrastructure each time  
- **Enterprises** needing roles, predictable behaviour, and controlled exposure of features  
- **Educators and researchers** who need analytics + AI assistance inside a usable platform  

---

## 4) Core promise and product mindset

### 4.1 Provision per client (repeatably)
SyntaxMatrix supports a “client instance” mindset: each deployment can have its own branding, data sources, controls, and enabled capabilities.

### 4.2 Keep AI controllable
The framework is designed so stakeholders can enable/disable whole modules (Docs, ML Lab, Registration, Theme Toggle, User Uploads, etc.) instead of relying on code changes.

### 4.3 Make content + data + AI live together
Useful AI assistants need:
- the right documents  
- the right UI surfaces  
- the right controls  
- the ability to render outputs and explain results

SyntaxMatrix treats those as one system.

---

## 5) Feature set (what it can do today)

### 5.1 Web app shell + role-aware access
A client app includes a web UI with:
- navigation and pages
- authentication + role-aware access pathways
- consistent design tokens and theme support (where enabled)

### 5.2 Page Studio (create/edit/publish pages)
Page Studio provides:
- page creation by slug/category (About, Services, Blog, Landing, Docs, Gallery, etc.)
- a **section-based layout model** (hero, features, values, process, FAQs, CTA, etc.)
- editing and patching of sections/items
- publishing to the frontend with safe HTML cleanup
- media selection (Uploads + Online images when allowed in the client app)

**Outcome:** a non-technical operator can manage website content without editing templates.

### 5.3 Documentation viewer (/docs)
The documentation area can:
- render a client’s `README.md` inside the app
- support code highlighting, copy buttons, structured headings, and a navigable sidebar
- embed client assets under `/docs/...` (screenshots, diagrams, and exported ML results)

### 5.4 Chat Assistant (smxAI)
The assistant supports:
- streaming responses
- structured, readable output formatting
- tool calling (task execution workflows)
- grounding through RAG (retrieval over client documents)
- chat history where enabled

### 5.5 Document ingestion + RAG
The knowledge base pipeline includes:
- document upload
- text extraction and chunking
- embedding generation
- semantic retrieval and context injection for grounded answers

### 5.6 Dashboard / ML Lab (analytics + modelling)
The ML Lab provides:
- CSV upload and dataset selection
- automated EDA (tables + visuals)
- code-generated modelling (classification/regression/clustering)
- managed execution in a kernel environment
- export of results into a shareable HTML report (“result file”)

### 5.7 Admin Panel
Admin features include:
- page management workflows
- media management (uploads)
- basic audit-friendly flows depending on client configuration
- safe publishing checks

### 5.8 Feature toggles / configuration
A client instance can expose or hide modules such as:
- Site documentation
- ML Lab
- Registration
- Theme toggle
- User file uploads

This allows a non-technical owner to control what is live, without touching code.

---

## 6) Data and persistence (platform storage)

SyntaxMatrix stores and retrieves platform data such as:
- page layouts (draft + published)
- documentation and assets references
- chat history and conversation metadata (when enabled)
- uploads and media references
- embeddings and vector metadata through store adapters

---

## 7) Vector storage and retrieval (upgrade-ready)

SyntaxMatrix is designed around a **vector-store adapter** approach so deployments can choose the backend that matches scale, cost, and operational constraints.

### 7.1 Local / pilot deployments
- SQLite-backed persistence and vector storage for quick provisioning and smaller deployments

### 7.2 Premium upgrades (Pro / Enterprise)
Premium subscription upgrades include the vector backends organisations commonly require for production scale:

- **PostgreSQL + pgvector**
- **Milvus**
- **Pinecone**

These are delivered as upgrade connectors (so clients can move from local to production without redesigning the product).

---

## 8) Deployment and operations

SyntaxMatrix is designed to run in standard Python deployment patterns, including:
- Docker-based deployments
- WSGI setups (e.g., Gunicorn)
- cloud-hosted patterns (e.g., GCP deployments per client needs)

The key product value is repeatability: the same core framework supports multiple client instances without rewriting the system each time.

---

## 9) Security and privacy posture (high level)

SyntaxMatrix is built to support controlled deployments through:
- role-aware access to sensitive tools and pages
- feature toggles (disable modules until configured)
- client-controlled model keys and routing
- separation of client instances and their storage footprints

Additionally, SyntaxMatrix supports premium workflows for **client-specific open-model fine-tuning** where organisations require stronger privacy boundaries.

---

## 10) Fine-tuning and model options (premium direction)

SyntaxMatrix supports provider flexibility and can accommodate:
- different LLM providers depending on task type (chat vs code vs summarisation)
- cost/latency-aware model selection
- premium workflows for **fine-tuning open-source models per client** for privacy, custom terminology, and improved performance

---

## 11) What makes SyntaxMatrix different

### 11.1 It is a platform system, not a collection of scripts
SyntaxMatrix combines UI + content + data + AI + controls.

### 11.2 It is built for real workflows
Admins can manage pages, docs, and outputs. Users can interact with an assistant and see results in the product.

### 11.3 It supports growth
Teams can start simple and evolve: more documents, more modules, stronger vector backends, fine-tuned models, and more specialised pages — without changing the core mental model.

---

## 12) Website positioning blocks (ready to paste)

### 12.1 Homepage paragraph
SyntaxMatrix is a full‑stack Python framework for provisioning client-ready AI platforms.  
It combines a web UI, role controls, a document ingestion pipeline for RAG, a Chat Assistant, a Page Studio for publishing content, and an ML Lab for analytics and modelling — so teams can ship AI systems quickly and run them with confidence.

### 12.2 “What you can build” bullets
- AI assistants with tool calling, streaming UI, and RAG over client documents  
- AI‑powered websites with a Page Studio for creating and publishing pages  
- Knowledge base ingestion pipelines (chunking, embeddings, semantic retrieval)  
- An ML Lab for EDA and modelling with exportable HTML result reports  
- Upgrade-ready vector backends (Postgres/pgvector, Milvus, Pinecone) on premium plans  
- Controlled deployments with roles, toggles, and client-specific configuration

### 12.3 “Who it’s for” bullets
- Product teams shipping AI features  
- AI engineers building grounded assistants  
- Organisations needing privacy-aware deployments  
- Teams who want one platform baseline across multiple client instances

---

## 14) Language rules for page generation (important)

When generating any website page for SyntaxMatrix:
- Always describe SyntaxMatrix as an **AI Framework Company** (not a generic services agency)
- Always connect content back to core modules: **Page Studio, Docs, RAG assistant, ML Lab, roles/toggles**
- Avoid vague claims. Prefer concrete capabilities, workflows, and outcomes.
"""


SMXAI_LANDING_PAGE_INSTRUCTIONS = f"""
IMPORTANT CONTEXT FOR THE GENERATOR

## PLAN GENERATION CONTRACT (MANDATORY)

When generating the page plan JSON:

- EVERY major section MUST include:
  - needsImage: true
  - imgQuery: "<specific, concrete image search query>"
- Images MUST be attached at section level.
- Do NOT rely on templates to infer images.
- If a section lacks needsImage + imgQuery, the plan is INVALID.

This applies to:
- hero
- introduction (below-hero overview)
- problem framing
- solution overview
- platform highlights
- deployment models
- trust / governance
- licensing model
- plans overview
- proof / credibility
- final CTA

---

## GLOBAL CONTENT RULES (NON-NEGOTIABLE)
- The Hero banner MUST contain ONLY:
  - a clear headline (hero title)
  - ONE sentence tagline directly under the title (single sentence only)
  - CTAs (buttons/links)
- The Hero banner MUST NOT contain paragraphs, multi-paragraph explanations, bullet lists, or cards.
- All explanatory prose that used to be in the Hero MUST be placed in a dedicated section immediately AFTER the Hero called:
  "Introduction — Company + Product Positioning (Below Hero)"
- If page is generated for a company other than SyntaxMatrix, replace any SyntaxMatrix content with that company’s content.
- Each MAJOR section other than the Hero banner must include 2–3 full paragraphs minimum.
- Each paragraph must be 4–6 complete sentences.
- Prose explanations MUST come before cards or bullets.
- Cards and bullets may ONLY summarise AFTER prose.
- Avoid slogans without explanation.
- Assume the reader is technical and sceptical.

Thin or overly short content in sections other than the Hero banner is invalid.

---

## GLOBAL IMAGE RULES (NON-NEGOTIABLE)

- Each major section must include exactly ONE image.
- Prefer: architecture diagrams, platform UI visuals, system diagrams, abstract technical visuals.
- Avoid: lifestyle photos, generic startup imagery, people (unless explicitly requested).
- Do not reuse the same imgQuery across sections.

---

## A) LAYOUT & HERO VISUAL RULES

### Hero Alignment Options (EXPLICIT)
Support both and randomly select one (left or center) for each generation:
- Default: heroAlignment = "left"
- Alternative: heroAlignment = "center"

The chosen alignment MUST be emitted in the plan.

### Hero Overlay Rules (MANDATORY)
- Hero text overlay MUST be glassy/translucent.
- The hero MUST NOT use an opaque white banner/card that blocks the image.
- Overlay opacity must allow the hero image to remain clearly visible.

---

## B) REQUIRED HOMEPAGE STRUCTURE (IN ORDER)

### B.1 HERO — Slim Banner Only (Title + One Sentence Tagline)

Hero banner content rules (MANDATORY):
- The hero banner MUST include ONLY:
  1) Hero Headline (title)
  2) One-sentence Tagline (exactly ONE sentence; no second sentence)
  3) CTAs
- Do NOT include paragraphs, bullets, cards, or multi-line prose in the hero banner.
- Any long-form explanation about the company, smxPP, or client-owned deployment MUST be moved to the next section:
  "Introduction — Company + Product Positioning (Below Hero)"

Hero Headline (choose one strong, enterprise option):
- "Provision Client-Owned AI Platforms — Securely, Governably, Repeatably"
OR
- "Enterprise AI Platforms You Can Own, Deploy, and Govern"

Tagline (MANDATORY):
- EXACTLY ONE sentence.
- Must mention smxPP explicitly and clarify it provisions a complete platform, not a single chatbot.
- Keep it short (ideally 12–22 words).

CTAs:
- Primary: "Explore Services"
- Secondary: "Read Documentation"
Optional tertiary link: "Licensing Explained"

Visual:
- needsImage: true
- imgQuery: "enterprise AI platform hero architecture abstract dark glassmorphism"

---

### B.1.5 INTRODUCTION — Company + Product Positioning (Below Hero)

Content requirements:
- 2–3 paragraphs explaining:
  - what the company is based on website description: {SMXAI_WEBSITE_DESCRIPTION}
    (AI infrastructure + algorithm design company) if company is SyntaxMatrix
  - what smxPP is (deployable platform provisioner)
  - why client-owned deployment matters (data sovereignty, governance, control)
- Avoid hype. Use concrete, operational language.
- After prose, you MAY include 3–5 short bullets summarising key points.

Visual:
- needsImage: true
- imgQuery: "client owned AI platform overview architecture diagram dark enterprise"

---

### B.2 THE PROBLEM — Why AI Prototypes Fail in Production

Content requirements:
- 2–3 paragraphs explaining the real pain points:
  - teams rebuilding AI infrastructure repeatedly
  - fragile RAG pipelines and unreproducible behaviour
  - lack of governance, audit trails, and role separation
  - mismatch between content systems and AI systems
  - vendor lock-in and unclear data boundaries
- Follow with a short bullet list summarising 5–7 issues.

Visual:
- needsImage: true
- imgQuery: "enterprise AI production challenges diagram fragmentation governance"

---

### B.3 THE SOLUTION — What smxPP Provisions

Content requirements:
- 2–3 paragraphs explaining:
  - smxPP provisions a complete platform surface (not a toy UI)
  - how modules fit together (admin panel, ingestion, assistant, pages, ML tooling, analytics)
  - how this reduces time-to-deploy and increases operational stability

Include a short summary list after prose:
- Role-aware Admin Panel
- Knowledge ingestion + RAG assistant
- Page Studio and documentation surfaces
- ML Lab outputs and exports (where enabled)
- Licensing boundaries and entitlements (premium)

Visual:
- needsImage: true
- imgQuery: "AI platform overview diagram admin panel RAG page studio ML lab"

---

### B.4 PLATFORM HIGHLIGHTS — What Enterprises Actually Get

Content requirements:
- 2 paragraphs introducing the philosophy: operational value > demos.
- Then provide 6 highlight blocks (each with a 4–6 sentence paragraph, not one-liners):
  1) Role-aware access and governance
  2) Document ingestion and retrieval architecture
  3) RAG assistant with controlled grounding
  4) Page Studio for internal/external portals
  5) Documentation viewer integrated into the platform
  6) Optional ML Lab workflows and exports

Cards may summarise each after the prose paragraphs.

Visual:
- needsImage: true
- imgQuery: "enterprise software dashboard UI panels RAG admin governance"

---

### B.5 DEPLOYMENT MODELS — Client-Owned by Design

Content requirements:
- 2–3 paragraphs explaining:
  - self-hosted deployment model (client instance)
  - why SyntaxMatrix does not host client instances by default
  - how BYOK and data locality reduce procurement friction
- Include a comparison block after prose:
  - On-premise
  - Private cloud
  - Controlled cloud deployments (e.g., container-based)

Visual:
- needsImage: true
- imgQuery: "deployment models on premise private cloud architecture diagram"

---

### B.6 TRUST & GOVERNANCE — Built for Sceptical Environments

Content requirements:
- 2–3 paragraphs addressing:
  - auditability, role separation, operational controls
  - how content ingestion is managed and traceable
  - how organisations can govern AI behaviour over time
- Include a short list of enterprise trust signals:
  - controlled permissions
  - clear data boundary
  - reproducible upgrades
  - documented operations

Visual:
- needsImage: true
- imgQuery: "enterprise compliance security audit governance diagram"

---

### B.7 LICENSING MODEL — Sustainable, Enforceable, Enterprise-Friendly

Content requirements:
- 2–3 paragraphs explaining:
  - open-core commercial model
  - signed, instance-bound licences
  - remote validation where enabled for subscription integrity
  - grace period handling to avoid sudden disruption
- Explain the self-serve portal benefits:
  - update payment method
  - view invoices
  - cancel at period end
- Emphasise fraud resistance as investor-grade assurance, without sounding adversarial.

Visual:
- needsImage: true
- imgQuery: "software licensing cryptographic signature keys enterprise diagram"

---

### B.8 PLANS OVERVIEW — Capability Progression (No Prices)

Content requirements:
- 2–3 paragraphs explaining plan philosophy:
  - Trial is full access for evaluation
  - Free is constrained but functional
  - Pro is for small teams adopting smxPP seriously
  - Business is for scaled operations needing more caps and governance
  - Enterprise is for institutions with strict requirements and deeper controls
- Do NOT include pricing. Explain operational value and typical fit.
- Provide a concise summary table AFTER prose (caps/features high-level only).

Visual:
- needsImage: true
- imgQuery: "enterprise pricing tiers progression comparison chart abstract"

---

### B.9 PROOF & CREDIBILITY — Why This Is Real

Content requirements:
- 2–3 paragraphs explaining:
  - engineering-first platform design
  - documented deployment approach
  - measurable operational focus (reliability, governance, reproducibility)
- Include a short credibility block:
  - Founder profile line (Bobga Nti — Founder / AI Engineer; MSc AI, platform engineering focus)
  - Company governance line (Yvonne Motuba — Company Secretary; corporate oversight)
- Keep it professional and factual.

Visual:
- needsImage: true
- imgQuery: "enterprise software engineering credibility diagram architecture blueprint"

---

### B.10 FINAL CTA — Next Steps

Content requirements:
- 1–2 paragraphs reinforcing:
  - client-owned AI platform value
  - governance-first stance
  - how to engage (services + documentation + licensing trust)

CTAs:
- "Talk to SyntaxMatrix"
- "Explore Services"
- "Read Documentation"
Optional link: "Licensing Explained"

Visual:
- needsImage: true
- imgQuery: "enterprise call to action abstract technology background dark"

---

## C) PAGE STUDIO RENDERING RULES

- Prose first, UI blocks second
- No compressed sections
- Maintain enterprise rhythm and spacing
- Ensure hero overlay is glassy and does NOT block the image

Failure to satisfy content depth or image rules is invalid.

"""


SMXAI_ABOUT_PAGE_INSTRUCTIONS = f"""
IMPORTANT CONTEXT FOR THE GENERATOR

## PLAN GENERATION CONTRACT (MANDATORY)

When generating the page plan JSON:

### 1) Section-level images (required everywhere)
- EVERY major section MUST include:
  - needsImage: true
  - imgQuery: "<specific, concrete image search query>"
- Images MUST be attached at SECTION level.
- Do NOT rely on templates to infer images.
- If a section lacks needsImage + imgQuery, the plan is INVALID.

### 2) Card-level images (required for any section that uses cards)
- Any section that includes cards MUST ensure:
  - cards is a non-empty list
  - EVERY card includes:
    - needsImage: true
    - imgQuery: "<specific, concrete image search query for THIS card>"
- Card images MUST be attached at CARD level (in addition to the section image).
- Do not reuse the same imgQuery across cards inside the same section.

### 3) Gallery rules (special case)
- The About page MUST include at least ONE dedicated Gallery section.
- The Gallery section MUST include:
  - galleryImages: a list of 6–9 items
  - EACH gallery item MUST include:
    - needsImage: true
    - imgQuery: "<specific, concrete image search query>"
  - Do not reuse imgQuery across gallery items.

This applies to:
- hero
- introduction (below-hero overview)
- company story / background
- mission & values (cards)
- team / leadership (cards)
- what we build (cards)
- how we work / trust signals (cards)
- gallery (6–9 images)
- final CTA

---

## GLOBAL CONTENT RULES (NON-NEGOTIABLE)
- The Hero banner MUST contain ONLY:
  - a clear headline (hero title)
  - ONE sentence tagline directly under the title (single sentence only)
  - CTAs (buttons/links)
- The Hero banner MUST NOT contain paragraphs, multi-paragraph explanations, bullet lists, or cards.
- All explanatory prose MUST be placed in sections below the hero.

- If page is generated for a company other than SyntaxMatrix, replace any SyntaxMatrix content with that company’s content.
- Each MAJOR section other than the Hero banner must include 2–3 full paragraphs minimum.
- Each paragraph must be 4–6 complete sentences.
- Prose explanations MUST come before cards or bullets.
- Cards and bullets may ONLY summarise AFTER prose.
- Avoid slogans without explanation.
- Assume the reader is technical and sceptical.

Thin or overly short content in sections other than the Hero banner is invalid.

---

## GLOBAL IMAGE RULES (NON-NEGOTIABLE)
- Each major section must include exactly ONE section-level image (needsImage + imgQuery).
- EXCEPTION: Gallery section MUST include 6–9 gallery images (galleryImages list), plus its section-level image.
- Prefer: architecture diagrams, platform UI visuals, system diagrams, abstract technical visuals, product screenshots.
- Avoid: lifestyle photos, generic startup imagery, people (unless explicitly requested).
- Do not reuse the same imgQuery across sections.

---

## A) LAYOUT & HERO VISUAL RULES

### Hero Alignment Options (EXPLICIT)
Support both and randomly select one (left or centre) for each generation:
- Default: heroAlignment = "left"
- Alternative: heroAlignment = "center"

The chosen alignment MUST be emitted in the plan.

### Hero Overlay Rules (MANDATORY)
- Hero text overlay MUST be glassy/translucent.
- The hero MUST NOT use an opaque white banner/card that blocks the image.
- Overlay opacity must allow the hero image to remain clearly visible.

---

## B) REQUIRED ABOUT PAGE STRUCTURE (IN ORDER)

### B.1 HERO — Slim Banner Only (Title + One Sentence Tagline)

Hero banner content rules (MANDATORY):
- The hero banner MUST include ONLY:
  1) Hero Headline (title)
  2) One-sentence Tagline (exactly ONE sentence; no second sentence)
  3) CTAs
- Do NOT include paragraphs, bullets, cards, or multi-line prose in the hero banner.

Hero Headline (choose one strong option):
- "About SyntaxMatrix — Engineering Client-Owned AI Platforms"
OR
- "Who We Are — Platform Engineering for Governable AI"

Tagline (MANDATORY):
- EXACTLY ONE sentence.
- Must mention smxPP explicitly and clarify it provisions a complete platform, not a single chatbot.
- Keep it short (ideally 12–22 words).

CTAs:
- Primary: "Explore Services"
- Secondary: "Read Documentation"
Optional tertiary link: "Licensing Explained"

Visual:
- needsImage: true
- imgQuery: "modern enterprise about page hero abstract architecture glassmorphism dark"

---

### B.2 INTRODUCTION — Company + Product Positioning (Below Hero)

Content requirements:
- 2–3 paragraphs explaining:
  - what the company is based on website description: {SMXAI_WEBSITE_DESCRIPTION}
    (AI infrastructure + algorithm design company) if company is SyntaxMatrix
  - what smxPP is (deployable platform provisioner)
  - why client-owned deployment matters (data sovereignty, governance, control)
- After prose, include 3–5 short bullets summarising key points.

Visual:
- needsImage: true
- imgQuery: "client owned AI platform overview architecture diagram dark enterprise"

---

### B.3 COMPANY STORY — Why We Exist

Content requirements:
- 2–3 paragraphs covering:
  - the real “Day 2” problems seen in production AI
  - why infrastructure, governance, and repeatability matter more than demos
  - how the company’s approach evolved (engineering-first, operational focus)
- After prose, include a short timeline or milestone list (optional).

Visual:
- needsImage: true
- imgQuery: "engineering blueprint timeline enterprise platform architecture sketch"

---

### B.4 MISSION & VALUES — Explained, Then Summarised as Cards (Cards Required)

Content requirements:
- 2 paragraphs introducing mission and values in concrete, operational terms.
- Then provide 6 value cards.
- EACH card MUST have:
  - a 3–5 sentence description (not a one-liner)
  - needsImage: true
  - imgQuery: unique per card
- Example value themes (adapt as needed):
  1) Governance-first engineering
  2) Client-owned deployment by default
  3) Reproducibility and auditability
  4) Secure by design
  5) Clear boundaries and entitlements
  6) Documentation as part of the product

Visual:
- needsImage: true
- imgQuery: "enterprise values cards UI grid glassmorphism icons abstract"

---

### B.5 TEAM & LEADERSHIP — Credible, Specific (Cards Required)

Content requirements:
- 2 paragraphs explaining how the team thinks about delivery (platform engineering, reliability, governance).
- Then provide 3–5 team cards (roles, responsibilities, what they own).
- Include a short credibility block:
  - Founder profile line (Bobga Nti — Co-Founder / CEO/ AI Engineer; MSc AI, platform engineering focus)
  - Company governance line (Gabriel Bassale — Co-Founder / COO / Software Engineer)
- EACH card MUST have:
  - needsImage: true
  - imgQuery: unique per card
- Avoid stock “smiling headshot” imagery unless explicitly requested.

Visual:
- needsImage: true
- imgQuery: "engineering team roles org chart cards enterprise UI minimal"

---

### B.6 WHAT WE BUILD — Capabilities as Cards (Cards Required)

Content requirements:
- 2–3 paragraphs describing the platform capabilities in terms of real delivery outcomes.
- Then provide 6–8 capability cards (each 3–5 sentences).
- Example capability areas:
  - Admin panel + role-aware access
  - Knowledge ingestion pipelines
  - RAG assistant with controlled grounding
  - Page Studio and portals
  - ML Lab (optional) and exports
  - Observability, logs, audit trails
  - Licensing and entitlements
  - Deployment patterns (Docker/GCP)
- EACH card MUST have:
  - needsImage: true
  - imgQuery: unique per card

Visual:
- needsImage: true
- imgQuery: "enterprise AI platform capabilities dashboard cards diagram"

---

### B.7 HOW WE WORK — Delivery Principles + Trust Signals (Cards Required)

Content requirements:
- 2–3 paragraphs explaining:
  - how delivery is structured (repeatable deployments, upgrades, operational controls)
  - how governance is maintained over time
  - how client teams adopt and operate the platform
- Then provide 4–6 trust-signal cards (each 3–5 sentences) with card images.

Visual:
- needsImage: true
- imgQuery: "enterprise governance compliance audit controls diagram dark"

---

### B.8 GALLERY — Platform & Architecture Visuals (Gallery Required)

Content requirements:
- 1–2 paragraphs explaining what the gallery represents (platform surfaces, architecture modules, deployment layouts).
- MUST include:
  - galleryImages: 6–9 items
  - each item has needsImage + imgQuery
- Gallery image themes should include:
  - platform dashboard UI
  - admin panel UI
  - RAG pipeline diagram
  - ingestion workflow diagram
  - deployment architecture diagram
  - audit/governance diagram
  - documentation viewer UI
  - (optional) licensing/entitlements diagram
- Avoid repeated or near-duplicate queries.

Visual (section-level):
- needsImage: true
- imgQuery: "enterprise product gallery section UI grid dark"

Gallery images (MANDATORY):
- galleryImages: [
  {{needsImage: true, imgQuery: "admin panel role based access UI dark enterprise"}},
  {{needsImage: true, imgQuery: "RAG pipeline architecture diagram retrieval grounding enterprise"}},
  {{needsImage: true, imgQuery: "document ingestion workflow diagram parsing chunking embeddings"}},
  {{needsImage: true, imgQuery: "deployment architecture diagram docker private cloud on premise"}},
  {{needsImage: true, imgQuery: "audit log governance UI table dark enterprise"}},
  {{needsImage: true, imgQuery: "documentation viewer interface technical portal UI"}},
  {{needsImage: true, imgQuery: "licensing entitlements cryptographic signature diagram enterprise"}}
]

---

### B.9 FINAL CTA — Next Steps

Content requirements:
- 1–2 paragraphs reinforcing:
  - client-owned AI platform value
  - governance-first stance
  - how to engage (services + documentation + licensing)

CTAs:
- "Talk to SyntaxMatrix"
- "Explore Services"
- "Read Documentation"
Optional link: "Licensing Explained"

Visual:
- needsImage: true
- imgQuery: "enterprise call to action abstract technology background dark"

---

## C) PAGE STUDIO RENDERING RULES

- Prose first, UI blocks second
- No compressed sections
- Maintain enterprise rhythm and spacing
- Ensure hero overlay is glassy and does NOT block the image
- Any section that declares cards MUST render card images visibly (card media at top)

Failure to satisfy content depth or image rules is invalid.
"""


SMXAI_SERVICES_PAGE_INSTRUCTIONS = f"""
IMPORTANT CONTEXT FOR THE GENERATOR

## PLAN GENERATION CONTRACT (MANDATORY)

When generating the page plan JSON:

### 1) Section-level images (required everywhere)
- EVERY major section MUST include:
  - needsImage: true
  - imgQuery: "<specific, concrete image search query>"
- Images MUST be attached at SECTION level.
- Do NOT rely on templates to infer images.
- If a section lacks needsImage + imgQuery, the plan is INVALID.

### 2) Card-level images (required for any section that uses cards)
- Any section that includes cards MUST ensure:
  - cards is a non-empty list
  - EVERY card includes:
    - needsImage: true
    - imgQuery: "<specific, concrete image search query for THIS card>"
- Card images MUST be attached at CARD level (in addition to the section image).
- Do not reuse the same imgQuery across cards inside the same section.

### 3) Gallery rules (special case)
- The Services page MUST include at least ONE dedicated Gallery section.
- The Gallery section MUST include:
  - galleryImages: a list of 6–9 items
  - EACH gallery item MUST include:
    - needsImage: true
    - imgQuery: "<specific, concrete image search query>"
  - Do not reuse imgQuery across gallery items.

This applies to:
- hero
- introduction (below-hero overview)
- services overview (cards)
- engagement models (cards)
- delivery phases / methodology (cards)
- technical accelerators (cards)
- governance & quality practices (cards)
- case examples / outcomes (cards)
- gallery (6–9 images)
- final CTA

---

## GLOBAL CONTENT RULES (NON-NEGOTIABLE)
- The Hero banner MUST contain ONLY:
  - a clear headline (hero title)
  - ONE sentence tagline directly under the title (single sentence only)
  - CTAs (buttons/links)
- The Hero banner MUST NOT contain paragraphs, multi-paragraph explanations, bullet lists, or cards.
- All explanatory prose MUST be placed in sections below the hero.

- If page is generated for a company other than SyntaxMatrix, replace any SyntaxMatrix content with that company’s content.
- Each MAJOR section other than the Hero banner must include 2–3 full paragraphs minimum.
- Each paragraph must be 4–6 complete sentences.
- Prose explanations MUST come before cards or bullets.
- Cards and bullets may ONLY summarise AFTER prose.
- Avoid slogans without explanation.
- Assume the reader is technical and sceptical.

Thin or overly short content in sections other than the Hero banner is invalid.

---

## GLOBAL IMAGE RULES (NON-NEGOTIABLE)
- Each major section must include exactly ONE section-level image (needsImage + imgQuery).
- EXCEPTION: Gallery section MUST include 6–9 gallery images (galleryImages list), plus its section-level image.
- Prefer: architecture diagrams, platform UI visuals, system diagrams, abstract technical visuals, product screenshots.
- Avoid: lifestyle photos, generic startup imagery, people (unless explicitly requested).
- Do not reuse the same imgQuery across sections.

---

## A) LAYOUT & HERO VISUAL RULES

### Hero Alignment Options (EXPLICIT)
Support both and randomly select one (left or centre) for each generation:
- Default: heroAlignment = "left"
- Alternative: heroAlignment = "center"

The chosen alignment MUST be emitted in the plan.

### Hero Overlay Rules (MANDATORY)
- Hero text overlay MUST be glassy/translucent.
- The hero MUST NOT use an opaque white banner/card that blocks the image.
- Overlay opacity must allow the hero image to remain clearly visible.

---

## B) REQUIRED SERVICES PAGE STRUCTURE (IN ORDER)

### B.1 HERO — Slim Banner Only (Title + One Sentence Tagline)

Hero banner content rules (MANDATORY):
- The hero banner MUST include ONLY:
  1) Hero Headline (title)
  2) One-sentence Tagline (exactly ONE sentence; no second sentence)
  3) CTAs
- Do NOT include paragraphs, bullets, cards, or multi-line prose in the hero banner.

Hero Headline (choose one strong option):
- "Services — Deploy and Operate Client-Owned AI Platforms"
OR
- "How We Deliver smxPP in Real Environments"

Tagline (MANDATORY):
- EXACTLY ONE sentence.
- Must mention smxPP explicitly and position services as platform delivery, not “chatbot projects”.
- Keep it short (ideally 12–22 words).

CTAs:
- Primary: "Talk to SyntaxMatrix"
- Secondary: "Explore Documentation"
Optional tertiary link: "Licensing Explained"

Visual:
- needsImage: true
- imgQuery: "enterprise services page hero abstract AI platform delivery glassmorphism dark"

---

### B.2 INTRODUCTION — What Our Services Actually Cover (Below Hero)

Content requirements:
- 2–3 paragraphs explaining:
  - services scope: platform provisioning, deployment, integration, governance hardening, adoption support
  - who the services are for (teams needing operational reliability, compliance, repeatability)
  - how smxPP reduces time-to-deploy while keeping client ownership intact
- After prose, include 3–5 short bullets summarising the service pillars.

Visual:
- needsImage: true
- imgQuery: "AI platform delivery lifecycle overview diagram enterprise"

---

### B.3 SERVICES OVERVIEW — Core Service Lines (Cards Required)

Content requirements:
- 2 paragraphs framing the service lines as outcomes, not buzzwords.
- Then provide 6–8 service cards.
- EACH card MUST have:
  - 3–5 sentence description (not one-liners)
  - needsImage: true
  - imgQuery: unique per card
- Example service lines (adapt as needed):
  1) Platform Provisioning & Environment Setup (Docker / GCP)
  2) RAG & Ingestion Pipeline Engineering (PDF/CSV/DB)
  3) Governance Hardening (RBAC, audit, traceability)
  4) UI & Portal Delivery (Page Studio, documentation surfaces)
  5) Observability & Reliability Engineering (logs, runbooks, upgrades)
  6) Licensing & Entitlement Integration (plans, validation, portal flows)
  7) (Optional) ML Lab Enablement (datasets, exports)
  8) Enablement & Training (handover, operational playbooks)

Visual:
- needsImage: true
- imgQuery: "enterprise services cards UI grid technical icons abstract"

---

### B.4 ENGAGEMENT MODELS — How We Work With Teams (Cards Required)

Content requirements:
- 2–3 paragraphs explaining engagement patterns and what clients get from each.
- Then provide 4–6 engagement cards (each 3–5 sentences) with card images:
  - Advisory + architecture
  - Delivery sprint(s)
  - Implementation + handover
  - Retained support (Day 2)
  - Security/governance review (optional)
  - Migration/modernisation (optional)

Visual:
- needsImage: true
- imgQuery: "engagement models comparison diagram enterprise delivery phases"

---

### B.5 DELIVERY PHASES — What Happens From Kickoff to Day 2 (Cards Required)

Content requirements:
- 2–3 paragraphs explaining a phased delivery that prioritises repeatability and governance.
- Then provide 5–7 phase cards (each 3–5 sentences) with card images:
  1) Discovery & constraints mapping
  2) Deployment baseline + identity/roles
  3) Ingestion pipelines + knowledge controls
  4) Assistant grounding + evaluation harness
  5) Portal/page surfaces + documentation
  6) Reliability hardening + runbooks
  7) Handover + training + upgrade plan

Visual:
- needsImage: true
- imgQuery: "delivery methodology phases timeline diagram platform engineering"

---

### B.6 TECHNICAL ACCELERATORS — Reusable Building Blocks (Cards Required)

Content requirements:
- 2 paragraphs explaining accelerators as reusable assets that reduce risk and time.
- Then provide 6 accelerator cards (each 3–5 sentences) with card images, e.g.:
  - ingestion connectors & chunking profiles
  - vector store adapters (SQLite + extensible)
  - evaluation scripts / regression tests for prompts
  - admin workflows (RBAC, audit views)
  - deployment templates (Docker, Cloud Run)
  - documentation viewer and content pipelines

Visual:
- needsImage: true
- imgQuery: "software accelerators components diagram reusable modules enterprise"

---

### B.7 GOVERNANCE & QUALITY — What Makes It Enterprise-Ready (Cards Required)

Content requirements:
- 2–3 paragraphs explaining:
  - governance controls and traceability
  - evaluation and change control
  - operational documentation and reproducible upgrades
- Then provide 4–6 quality cards (each 3–5 sentences) with card images:
  - auditability
  - permissions / role separation
  - grounding & citation discipline (where applicable)
  - data boundary controls
  - upgrade strategy
  - incident response readiness

Visual:
- needsImage: true
- imgQuery: "enterprise governance security audit quality controls diagram"

---

### B.8 EXAMPLES & OUTCOMES — What Success Looks Like (Cards Required)

Content requirements:
- 2–3 paragraphs giving concrete example outcomes (no fabricated client names).
- Then provide 4–6 outcome cards (each 3–5 sentences) with card images, e.g.:
  - reduced deployment lead time
  - stable ingestion + reliable retrieval
  - improved governance posture (RBAC + audit)
  - repeatable upgrades and releases
  - measurable operational runbooks and support

Visual:
- needsImage: true
- imgQuery: "enterprise outcomes metrics dashboard reliability governance diagram"

---

### B.9 GALLERY — Platform Delivery & Technical Surfaces (Gallery Required)

Content requirements:
- 1–2 paragraphs explaining what the gallery shows (platform surfaces, architecture, delivery artefacts).
- MUST include:
  - galleryImages: 6–9 items
  - each item has needsImage + imgQuery
- Gallery themes should include:
  - admin panel UI
  - page/portal UI
  - RAG workflow diagram
  - ingestion pipeline diagram
  - deployment architecture diagram
  - audit/governance UI
  - reliability/monitoring concept
  - licensing/entitlements diagram (optional)
- Avoid repeated or near-duplicate queries.

Visual (section-level):
- needsImage: true
- imgQuery: "enterprise services gallery section UI grid dark technical"

Gallery images (MANDATORY):
- galleryImages: [
  {{needsImage: true, imgQuery: "admin panel RBAC governance UI dark enterprise"}},
  {{needsImage: true, imgQuery: "page studio portal builder UI enterprise dark"}},
  {{needsImage: true, imgQuery: "RAG assistant grounding retrieval diagram enterprise"}},
  {{needsImage: true, imgQuery: "document ingestion pipeline diagram chunking embeddings enterprise"}},
  {{needsImage: true, imgQuery: "deployment architecture docker cloud run private cloud diagram"}},
  {{needsImage: true, imgQuery: "audit log traceability UI table enterprise dark"}},
  {{needsImage: true, imgQuery: "reliability operations runbook monitoring diagram enterprise"}}
]

---

### B.10 FINAL CTA — Next Steps

Content requirements:
- 1–2 paragraphs reinforcing:
  - client-owned AI platform value
  - how services help deliver and sustain Day 2 reliability
  - how to engage (call + docs + licensing)

CTAs:
- "Talk to SyntaxMatrix"
- "Explore Services"
- "Read Documentation"
Optional link: "Licensing Explained"

Visual:
- needsImage: true
- imgQuery: "enterprise call to action abstract technology background dark"

---

## C) PAGE STUDIO RENDERING RULES

- Prose first, UI blocks second
- No compressed sections
- Maintain enterprise rhythm and spacing
- Ensure hero overlay is glassy and does NOT block the image
- Any section that declares cards MUST render card images visibly (card media at top)

Failure to satisfy content depth or image rules is invalid.
"""


# SMXAI_GALLERY_PAGE_INSTRUCTIONS = """
# You are generating a GALLERY page. This page must behave like a true photo/screenshot gallery.

# ## GLOBAL CONTENT RULES (NON-NEGOTIABLE)
# - The Hero section MUST include a clear headline and subheadline that position the company and smxPP as enterprise AI platform solutions (company = SyntaxMatrix or otherwise).
# - If page is generated for company other than SyntaxMatrix, then replace any SyntaxMatrix content with that of the company's content. 

# Thin or overly short content in sections other than the Hero section is invalid.
# ABSOLUTE REQUIREMENTS
# 1) The page plan MUST include a section with:
#    - type: "gallery"
#    - id: "sec_gallery" (or similar)
# 2) The gallery section MUST contain 6–9 items where EACH item is a true image tile:
#    - item.type MUST be "image" (NOT "card")
#    - Use short titles (2–5 words max) and very short captions (0–1 sentence).
#    - Avoid long paragraphs in the gallery; do NOT make it look like a features section.

# GALLERY ITEM SCHEMA (use this exactly)
# Each gallery item MUST look like:
# {
#   "id": "g1",
#   "type": "image",
#   "title": "Admin Panel",
#   "text": "Pages, uploads, audit trail.",
#   "imgQuery": "admin panel dashboard ui dark theme",
#   "needsImage": true,
#   "imageUrl": "",
#   "thumbUrl": "",
# }

# NOTES:
# - imageUrl/thumbUrl can be empty at planning time; the system will fill them later from imgQuery.
# - If a thumbnail exists, thumbUrl should point to it; imageUrl should point to the full image.
# - The gallery rail should be primarily visual. Captions are optional and must be short.

# DESIGN INTENT
# - Gallery section = image-first browsing (tiles, click opens lightbox).
# - If you need explanatory content, put it in separate sections (richtext/features/cta) OUTSIDE the gallery.
# - Do NOT place "card" items inside the gallery section unless explicitly requested (default: none).

# PAGE STRUCTURE (recommended)
# - hero (clear title + one sentence)
# - gallery (the rail of image tiles; 6–9 items)
# - richtext or testimonials (optional, short)
# - cta (contact / request demo)

# TONE
# - Enterprise AI product showcase, clean and concise.
# """


SMXAI_GALLERY_PAGE_INSTRUCTIONS = f"""
IMPORTANT CONTEXT FOR THE GENERATOR

## ROOT JSON OUTPUT CONTRACT (MANDATORY — READ CAREFULLY)

- You MUST output EXACTLY ONE valid JSON OBJECT at the top-level (a dictionary), not a JSON array/list.
- Do NOT output multiple JSON blocks.
- Do NOT wrap the JSON in markdown fences.
- Do NOT include commentary, explanations, or headings outside the JSON.
- The root object MUST include:
  - "category": "gallery"   (string, exactly this value)
  - "heroAlignment": "left" or "center" (string)
  - "hero": {{...}}         (object)
  - "sections": [ ... ]     (array/list of section objects)
- ALL content beyond the hero MUST be placed inside the "sections" list.
  Do NOT create top-level keys like "showcases", "intro", "galleryItems", etc.

If you violate this contract, the plan will fail parsing.

---

## PLAN GENERATION CONTRACT (MANDATORY)

When generating the page plan JSON:

- EVERY major section MUST include:
  - needsImage: true
  - imgQuery: "<specific, concrete image search query>"
- Images MUST be attached at section level.
- Do NOT rely on templates to infer images.
- If a section lacks needsImage + imgQuery, the plan is INVALID.

This applies to:
- hero
- introduction (below-hero overview)  -> must be a section in "sections"
- showcase items (multiple)           -> each must be its own section in "sections"
- optional: process / workflow        -> must be a section in "sections"
- optional: technical notes           -> must be a section in "sections"
- final CTA                           -> must be a section in "sections"

---

## GLOBAL CONTENT RULES (NON-NEGOTIABLE)

- This is a GALLERY / PORTFOLIO page, not a features page.
- The page MUST be visual-first: images drive the structure; text explains what the viewer is seeing and why it matters.

### Hero banner (slim)
- The Hero banner MUST contain ONLY:
  - a clear headline (title)
  - ONE sentence tagline directly under the title (single sentence only)
  - CTAs (buttons/links)
- The Hero banner MUST NOT contain paragraphs, bullet lists, or cards.

### Prose depth
- The Introduction section (below hero) MUST include 2–3 paragraphs.
- Each Showcase section MUST include 1–2 paragraphs that explain the visual, then a short list of “What to notice”.
- Prose explanations MUST come before bullets/cards.
- Bullets/cards may ONLY summarise AFTER prose.
- Avoid slogans without explanation.
- Assume the reader is technical and sceptical.

### Critical pitfalls to avoid (these cause Gallery to render like Features)
- Do NOT create one huge “Gallery” section with many cards.
- Do NOT create a “Features” grid disguised as a gallery.
- Instead: create MULTIPLE Showcase sections, each representing ONE artefact (UI screen, diagram, workflow, output),
  each with its own section-level image and explanation.
- Keep each showcase anchored to what is visible in the image and why it matters operationally.

---

## GLOBAL IMAGE RULES (NON-NEGOTIABLE)

- Each major section must include exactly ONE image (attached at section level).
- Prefer: real product UI screenshots, admin panels, dashboard screens, architecture diagrams, workflow diagrams, deployment diagrams.
- Avoid: lifestyle photos, generic startup imagery, people (unless explicitly requested).
- Do not reuse the same imgQuery across sections.
- Every imgQuery must be concrete and distinct (mention artefact type + UI context + style).

---

## A) LAYOUT & HERO VISUAL RULES

### Hero Alignment Options (EXPLICIT)
Support both and randomly select one (left or centre) for each generation:
- Default: heroAlignment = "left"
- Alternative: heroAlignment = "center"

The chosen alignment MUST be emitted in the plan root ("heroAlignment").

### Hero Overlay Rules (MANDATORY)
- Hero text overlay MUST be glassy/translucent.
- The hero MUST NOT use an opaque white banner/card that blocks the image.
- Overlay opacity must allow the hero image to remain clearly visible.

---

## B) REQUIRED GALLERY PAGE STRUCTURE (IN ORDER)

### B.1 HERO — Slim Banner Only (Title + One Sentence Tagline)

Hero content rules:
- hero MUST contain ONLY headline + one-sentence tagline + CTAs.
- No paragraphs, no bullets, no cards inside hero.

Hero Headline (choose one):
- "Product Gallery — Interfaces, Workflows, and Architecture"
OR
- "Platform Artefacts — Screens, Diagrams, and Outputs"
OR
- "Gallery — What the Platform Looks Like in Practice"

Tagline (MANDATORY):
- EXACTLY ONE sentence.
- Mention the platform name (smxPP / SyntaxMatrix) and that this page shows real artefacts (UI, diagrams, outputs).

CTAs:
- Primary: "Explore Services"
- Secondary: "Read Documentation"
Optional tertiary link: "Licensing Explained"

Hero Visual:
- needsImage: true
- imgQuery: "enterprise software product gallery hero collage UI screenshots dark glass overlay"

---

### B.2 INTRODUCTION — How to Read This Gallery (Below Hero)
This MUST be the first item in the "sections" array.

Content requirements:
- 2–3 paragraphs explaining:
  - what kinds of artefacts are shown (UI, admin panel, assistant, ingestion, dashboards, diagrams, exports)
  - what each artefact demonstrates operationally (governance, reliability, deployment, reproducibility)
  - how these artefacts map to real delivery (client-owned instance, BYOK where relevant)
- After prose, include a short “Legend” bullet list (4–6 bullets) clarifying labels such as:
  - UI Screen
  - Workflow
  - Architecture Diagram
  - Output / Export
  - Deployment View

Visual:
- needsImage: true
- imgQuery: "legend style UI gallery guide enterprise product screenshots annotated"

---

### B.3–B.10 SHOWCASE SECTIONS — One Artefact Per Section (MANDATORY)
These MUST be separate items in the "sections" array (do not nest them elsewhere).

Generate 6–10 showcase sections.

Each Showcase section MUST include:
1) 1–2 paragraphs (4–6 sentences each) explaining:
   - what the viewer is seeing
   - the technical/operational purpose (who uses it, what it controls, what problem it solves)
2) A “What to notice” bullet list (3–6 bullets) AFTER prose.

Showcase examples (pick 6–10, vary across generations):
- Admin Panel — role-aware access, audit trails, page management
- Knowledge Ingestion — document upload, chunking, retrieval, grounding controls
- Assistant UI — streaming chat, grounded answers, history
- Page Studio — page builder, layouts, section images, publishing flow
- ML Lab — dataset upload, EDA, model outputs, export artefacts
- Licensing — instance-bound licence status, entitlements, grace behaviour
- Deployment Diagram — Docker/Gunicorn/Cloud Run style deployment diagram
- Architecture Diagram — module boundaries and data flow (RAG + storage)
- Export Outputs — reports/HTML exports, downloadable artefacts

For each Showcase section, Visual requirements:
- needsImage: true
- imgQuery must be unique and specific to the artefact, e.g.:
  - "enterprise admin panel dashboard role based access audit log dark UI"
  - "RAG assistant chat interface streaming grounded responses dark UI"
  - "document ingestion pipeline UI upload chunking embedding vector store diagram"
  - "page studio website builder section editor hero overlay dark UI"
  - "machine learning lab dashboard EDA charts model training export report UI"
  - "software licensing entitlement screen instance bound licence status UI"
  - "deployment architecture diagram on premise private cloud container workflow"
  - "system architecture diagram admin ingestion RAG assistant storage modules"

---

### B.11 OPTIONAL: PROCESS / WORKFLOW (ONLY IF NEEDED)
If included, it MUST be a section inside "sections".

- 2 paragraphs max, plus a short numbered list (5–7 steps) after prose.

Visual:
- needsImage: true
- imgQuery: "client owned AI platform delivery workflow diagram steps enterprise"

---

### B.12 FINAL CTA — Next Steps
This MUST be the final item in the "sections" array.

Content requirements:
- 1–2 paragraphs reinforcing:
  - that the gallery reflects operational artefacts, not vague promises
  - how to engage (services + documentation + licensing)

CTAs:
- "Talk to SyntaxMatrix"
- "Explore Services"
- "Read Documentation"
Optional link: "Licensing Explained"

Visual:
- needsImage: true
- imgQuery: "enterprise call to action abstract dark technology background"

---

## C) PAGE STUDIO RENDERING RULES

- Visual-first rhythm: image + explanation per showcase
- Prose first, bullets second
- Avoid turning the gallery into a features grid
- Maintain enterprise spacing and consistent typography
- Ensure hero overlay is glassy and does NOT block the image

Failure to satisfy the Root JSON Output Contract or image rules is invalid.
"""



SMXAI_CAREERS_PAGE_INSTRUCTIONS = f"""
IMPORTANT CONTEXT FOR THE GENERATOR

## PLAN GENERATION CONTRACT (MANDATORY)

When generating the page plan JSON:

### 1) Section-level images (required everywhere)
- EVERY major section MUST include:
  - needsImage: true
  - imgQuery: "<specific, concrete image search query>"
- Images MUST be attached at SECTION level.
- Do NOT rely on templates to infer images.
- If a section lacks needsImage + imgQuery, the plan is INVALID.

### 2) Card-level images + click behaviour (required for card sections)
- Any section that includes cards MUST ensure:
  - cards is a non-empty list
  - EVERY card includes:
    - title
    - description (2–5 sentences; not one-liners)
    - needsImage: true
    - imgQuery: "<specific, concrete image search query for THIS card>"
    - href OR onClickAction (one required)
      - href: "/careers/<role-slug>" OR "mailto:..." OR "https://..."
      - onClickAction: "openRoleModal" OR "openApplyModal"
- Card images MUST be attached at CARD level (in addition to the section image).
- Do not reuse the same imgQuery across cards inside the same section.

### 3) Optional culture gallery (recommended, not mandatory)
- If a Gallery section is included, it MUST include:
  - galleryImages: a list of 6–9 items
  - EACH gallery item MUST include:
    - needsImage: true
    - imgQuery: "<specific, concrete image search query>"
  - Do not reuse imgQuery across gallery items.

This applies to:
- hero
- introduction (below-hero overview)
- why work here (cards)
- open roles (cards)
- how we hire (cards or timeline blocks)
- benefits & support (cards)
- learning & growth (cards)
- FAQs
- optional culture gallery (6–9 images)
- final CTA

---

## GLOBAL CONTENT RULES (NON-NEGOTIABLE)
- The Hero banner MUST contain ONLY:
  - a clear headline (hero title)
  - ONE sentence tagline directly under the title (single sentence only)
  - CTAs (buttons/links)
- The Hero banner MUST NOT contain paragraphs, multi-paragraph explanations, bullet lists, or cards.
- All explanatory prose MUST be placed in sections below the hero.

- If page is generated for a company other than SyntaxMatrix, replace any SyntaxMatrix content with that company’s content.
- Each MAJOR section other than the Hero banner must include 2–3 full paragraphs minimum,
  EXCEPT for FAQ sections which may be shorter if presented as an accordion.
- Each paragraph must be 4–6 complete sentences.
- Prose explanations MUST come before cards or bullets.
- Cards and bullets may ONLY summarise AFTER prose.
- Avoid hype and vague promises. Use concrete, operational language.
- Assume the reader is technical and sceptical.

Thin or overly short content in sections other than the Hero banner is invalid.

---

## GLOBAL IMAGE RULES (NON-NEGOTIABLE)
- Each major section must include exactly ONE section-level image (needsImage + imgQuery).
- Any section that uses cards MUST include card images for every card.
- Prefer: product UI, engineering visuals, architecture diagrams, delivery workflow diagrams, technical abstractions.
- People imagery is allowed ONLY if it is credible and professional (avoid stock “startup team smiling” clichés).
- Do not reuse the same imgQuery across sections.
- Do not reuse the same imgQuery across cards within the same section.

---

## A) LAYOUT & HERO VISUAL RULES

### Hero Alignment Options (EXPLICIT)
Support both and randomly select one (left or centre) for each generation:
- Default: heroAlignment = "left"
- Alternative: heroAlignment = "centre"

The chosen alignment MUST be emitted in the plan.

### Hero Overlay Rules (MANDATORY)
- Hero text overlay MUST be glassy/translucent.
- The hero MUST NOT use an opaque white banner/card that blocks the image.
- Overlay opacity must allow the hero image to remain clearly visible.

---

## B) REQUIRED CAREERS PAGE STRUCTURE (IN ORDER)

### B.1 HERO — Slim Banner Only (Title + One Sentence Tagline)

Hero Headline (choose one strong option):
- "Careers — Build Governable, Client-Owned AI Platforms"
OR
- "Join SyntaxMatrix — Platform Engineering for Real-World AI"

Tagline (MANDATORY):
- EXACTLY ONE sentence.
- Must mention smxPP explicitly and position roles as building a platform (not “chatbot demos”).
- Keep it short (ideally 12–22 words).

CTAs:
- Primary: "View Open Roles"
- Secondary: "Submit Your Interest"
Optional tertiary link: "Read Documentation"

Visual:
- needsImage: true
- imgQuery: "enterprise careers hero platform engineering abstract architecture glassmorphism dark"

---

### B.2 INTRODUCTION — What We Build and Who Thrives Here (Below Hero)

Content requirements:
- 2–3 paragraphs explaining:
  - what the company builds (client-owned AI platform delivery, governance-first)
  - what smxPP is and what teams work on (admin, ingestion, RAG controls, pages, deployment, licensing)
  - the kind of mindset that fits (engineering rigour, operational thinking, security awareness)
- After prose, include 3–5 short bullets: “What you will work on”.

Visual:
- needsImage: true
- imgQuery: "platform engineering work overview diagram enterprise dark"

---

### B.3 WHY WORK HERE — Culture Pillars (Cards Required)

Content requirements:
- 2 paragraphs describing the working culture in practical terms (how work is planned, reviewed, shipped, and operated).
- Then provide 6–8 culture cards, each with:
  - 2–5 sentence description
  - needsImage + imgQuery (unique per card)
  - onClickAction: "openRoleModal" (or href to a culture page/section)

Example card themes (adapt as needed):
- Engineering-first delivery
- Governance and auditability by design
- Client ownership and clear boundaries
- Documentation as a product surface
- Reproducible deployments and upgrades
- Thoughtful automation and tooling
- Security-minded defaults
- Learning through real constraints

Visual:
- needsImage: true
- imgQuery: "enterprise culture pillars cards UI grid technical dark"

---

### B.4 OPEN ROLES — Clickable Role Cards (Cards Required)

Content requirements:
- 2 paragraphs explaining:
  - how roles are structured (platform, product surfaces, reliability, client delivery)
  - what “success” looks like in 60–90 days
- Then provide role cards:
  - If actual openings are available in provided data/context, list them.
  - If no openings are available, show 3–5 “Typical Roles” cards clearly labelled as examples,
    AND include a “No roles currently advertised” note with a strong CTA to submit interest.
- EACH role card MUST include:
  - title (role)
  - level (optional)
  - location/work mode (remote/hybrid/on-site)
  - 2–5 sentence description (scope + responsibilities)
  - needsImage + imgQuery (unique per card)
  - href to a role detail page OR onClickAction "openApplyModal"

Visual:
- needsImage: true
- imgQuery: "open roles careers listing cards enterprise UI dark"

---

### B.5 HOW WE HIRE — Transparent Process (Cards or Timeline Blocks Required)

Content requirements:
- 2–3 paragraphs explaining:
  - what the process is optimised for (signal, fairness, speed, clarity)
  - what we assess (engineering judgement, communication, quality mindset)
  - expected response timelines in general terms (avoid hard promises)
- Then provide 5–7 process-step cards (or timeline blocks), each with:
  - needsImage + imgQuery (unique per step)
  - 2–4 sentence explanation
  - include what candidates should prepare at each step

Example steps:
- Intro call
- Technical discussion (system thinking)
- Practical exercise (scoped and realistic)
- Review and feedback
- Final conversation + offer

Visual:
- needsImage: true
- imgQuery: "hiring process steps timeline diagram enterprise dark"

---

### B.6 BENEFITS & SUPPORT — Practical, Not Fluffy (Cards Required)

Content requirements:
- 2 paragraphs framing benefits as support for sustainable delivery (focus time, growth, good tooling).
- Then provide 6–10 benefit cards, each with:
  - needsImage + imgQuery (unique per card)
  - 2–4 sentence description
  - avoid exaggeration; keep it factual

Example benefit themes (adapt as appropriate):
- Flexible working arrangements
- Learning budget and certification support
- Home office / equipment support
- Clear role expectations and feedback cadence
- Technical mentorship and reviews
- Well-defined delivery practices (tickets, PR reviews, runbooks)
- Time for documentation and quality work

Visual:
- needsImage: true
- imgQuery: "employee benefits cards UI enterprise clean dark"

---

### B.7 LEARNING & GROWTH — Skill Development Paths (Cards Required)

Content requirements:
- 2–3 paragraphs describing how growth happens:
  - ownership over modules
  - operating what you ship (Day 2 responsibility)
  - writing, reviews, and architecture decisions
- Provide 4–6 growth cards with images.

Visual:
- needsImage: true
- imgQuery: "engineering growth learning roadmap cards diagram enterprise"

---

### B.8 FAQ — Candidate Questions (Accordion Preferred)

Content requirements:
- 1–2 paragraphs introducing the FAQ.
- Then provide 6–10 FAQ items (question + 3–6 sentence answer):
  - Work model (remote/hybrid)
  - Interview format
  - What a good submission looks like
  - Tooling and stack expectations
  - How success is measured
  - How onboarding works
  - Data/privacy stance (high-level)

Visual:
- needsImage: true
- imgQuery: "faq section enterprise UI accordion dark minimal"

---

### B.9 OPTIONAL CULTURE GALLERY — Team and Product in Context (Recommended)

Inclusion rule:
- Include this section if the generator can create meaningful visuals (non-stocky, credible).
- If not, OMIT this section entirely (do not include an empty gallery).

Content requirements (if included):
- 1 short paragraph (3–5 sentences).
- galleryImages: 6–9 items, each needsImage + imgQuery (unique).

Visual (section-level):
- needsImage: true
- imgQuery: "culture gallery section enterprise UI grid dark"

---

### B.10 FINAL CTA — Apply or Start a Conversation

Content requirements:
- 1–2 paragraphs encouraging action:
  - apply to a role OR submit interest
  - include guidance for what to send (CV, GitHub, brief note, relevant project links)

CTAs:
- Primary: "Submit Your Interest"
- Secondary: "View Open Roles"
Optional link: "Read Documentation"

Visual:
- needsImage: true
- imgQuery: "enterprise careers call to action abstract technology background dark"

---

## C) PAGE STUDIO RENDERING RULES

- Prose first, then cards/timelines.
- Card sections MUST show card images clearly (media at top).
- Role cards MUST be visibly clickable with hover affordance.
- Maintain enterprise rhythm and spacing.
- Ensure hero overlay is glassy and does NOT block the image.

Failure to satisfy hero rules, section image rules, or card image rules is invalid.
"""


SMXAI_BLOG_PAGE_INSTRUCTIONS = f"""
IMPORTANT CONTEXT FOR THE GENERATOR

## PLAN GENERATION CONTRACT (MANDATORY)

When generating the page plan JSON:

### 1) Section-level images (required everywhere)
- EVERY major section MUST include:
  - needsImage: true
  - imgQuery: "<specific, concrete image search query>"
- Images MUST be attached at SECTION level.
- Do NOT rely on templates to infer images.
- If a section lacks needsImage + imgQuery, the plan is INVALID.

### 2) Card-level images + click behaviour (required for post grids)
- This Blog page MUST predominantly use sections that render CLICKABLE post cards.
- Any section that includes post cards MUST ensure:
  - cards is a non-empty list
  - EVERY card includes:
    - title
    - description (2–4 sentences; not one-liners)
    - needsImage: true
    - imgQuery: "<specific, concrete image search query for THIS post card>"
    - href OR onClickAction (one required)
      - href: "/blog/<post-slug>" OR "https://..."
      - onClickAction: "openPostPreviewModal"
    - meta fields where available:
      - author (optional)
      - date (optional)
      - readingTime (optional)
      - tags (optional)
- Card images MUST be attached at CARD level (in addition to the section image).
- Do not reuse the same imgQuery across cards inside the same section.

### 3) Featured carousel (MANDATORY)
- The Blog page MUST include ONE dedicated Featured Carousel section that includes:
  - carouselPosts: a list of 5–8 items
  - EACH item MUST include:
    - title
    - caption (1 sentence teaser)
    - needsImage: true
    - imgQuery: "<specific, concrete image search query>"
    - href OR onClickAction
  - Carousel behaviour requirements:
    - shows arrows (prev/next)
    - shows dots or a slide counter
    - supports swipe on mobile
    - autoplay allowed if slow; must pause on hover

### 4) Optional auto-scroll “Latest strip” (recommended)
- If included, it MUST:
  - start slow scrolling LEFT → RIGHT on page load
  - pause on hover/touch-hold
  - click any item to open post preview or navigate
- It must include:
  - autoScrollPosts: 10–16 items
  - each includes needsImage + imgQuery + href/onClickAction

This applies to:
- hero
- introduction (below-hero overview)
- featured carousel
- categories / topics (clickable cards)
- latest posts grid (cards)
- deep-dive series / collections (cards)
- optional auto-scroll latest strip
- newsletter / subscribe CTA
- final CTA

---

## GLOBAL CONTENT RULES (NON-NEGOTIABLE)
- The Hero banner MUST contain ONLY:
  - a clear headline (hero title)
  - ONE sentence tagline directly under the title (single sentence only)
  - CTAs (buttons/links)
- The Hero banner MUST NOT contain paragraphs, multi-paragraph explanations, bullet lists, or cards.

- This is a Blog-first page:
  - MOST sections should be card grids / carousels, not long prose.
  - For post-card sections: allow 1 short intro paragraph (3–5 sentences), then cards.
  - Keep copy practical: what the reader will learn, what problem it solves, and why it matters operationally.

- If page is generated for a company other than SyntaxMatrix, replace any SyntaxMatrix content with that company’s content.
- Avoid hype and vague claims; prefer concrete, technical language.
- Assume the reader is technical and sceptical.

---

## GLOBAL IMAGE RULES (NON-NEGOTIABLE)
- Each major section must include exactly ONE section-level image (needsImage + imgQuery).
- Any section that uses cards MUST include card images for every card.
- Carousel posts MUST have images.
- Prefer: technical diagrams, platform UI visuals, architecture sketches, governance/compliance visuals, code-adjacent abstractions.
- Avoid: generic lifestyle imagery, people unless strongly relevant.
- Do not reuse the same imgQuery across sections.
- Do not reuse the same imgQuery across cards within the same section.

---

## A) LAYOUT & HERO VISUAL RULES

### Hero Alignment Options (EXPLICIT)
Support both and randomly select one (left or centre) for each generation:
- Default: heroAlignment = "left"
- Alternative: heroAlignment = "centre"

The chosen alignment MUST be emitted in the plan.

### Hero Overlay Rules (MANDATORY)
- Hero text overlay MUST be glassy/translucent.
- The hero MUST NOT use an opaque white banner/card that blocks the image.
- Overlay opacity must allow the hero image to remain clearly visible.

---

## B) REQUIRED BLOG PAGE STRUCTURE (IN ORDER)

### B.1 HERO — Slim Banner Only (Title + One Sentence Tagline)

Hero Headline (choose one strong option):
- "Blog — Engineering Client-Owned, Governable AI Platforms"
OR
- "Insights — RAG Reliability, Governance, and Day 2 Operations"

Tagline (MANDATORY):
- EXACTLY ONE sentence.
- Must mention smxPP explicitly and position posts as practical platform engineering guidance.
- Keep it short (ideally 12–22 words).

CTAs:
- Primary: "Browse Posts"
- Secondary: "Read Documentation"
Optional tertiary link: "Subscribe"

Visual:
- needsImage: true
- imgQuery: "enterprise blog hero technical writing platform engineering abstract dark glassmorphism"

---

### B.2 INTRODUCTION — What This Blog Covers (Short)

Content requirements:
- 1 short paragraph (3–5 sentences) explaining:
  - focus areas: deployment, governance, RAG reliability, ingestion pipelines, licensing boundaries, platform operations
  - posts are practical and implementation-oriented
- Then provide 3 short bullets describing typical article formats:
  - “How-to” implementation guides
  - Architecture breakdowns
  - Operational checklists / runbooks

Visual:
- needsImage: true
- imgQuery: "technical blog overview navigation UI dark minimal"

---

### B.3 FEATURED — Carousel of Highlight Posts (MANDATORY)

Content requirements:
- 1 short paragraph (3–5 sentences).
- Include:
  - carouselPosts: 5–8 items
  - each item has title + caption + needsImage + imgQuery + href/onClickAction
- Featured posts should span different themes (governance, RAG, deployment, licensing, pages/portals, reliability).

Visual (section-level):
- needsImage: true
- imgQuery: "featured posts carousel enterprise UI dark minimal"

---

### B.4 TOPICS — Clickable Category Cards (Cards Required)

Content requirements:
- 1 short paragraph (3–5 sentences) explaining how topics map to real platform concerns.
- Then provide 8–12 topic cards (clickable), each with:
  - title (topic)
  - 2–4 sentence description (what readers will learn)
  - needsImage + imgQuery (unique per card)
  - href: "/blog?topic=<topic>" (or your chosen route)

Example topic themes (adapt as needed):
- RAG evaluation and grounding
- Ingestion pipelines (PDF/CSV/DB)
- Vector stores and retrieval quality
- Governance, audit, and RBAC
- Deployment (Docker, Cloud Run, on-prem)
- Licensing and entitlements
- Page Studio and portals
- Reliability, observability, incident response
- Data boundaries and privacy
- Performance and cost controls

Visual:
- needsImage: true
- imgQuery: "blog topics category cards grid enterprise UI dark"

---

### B.5 LATEST POSTS — Primary Post Grid (Cards Required)

Content requirements:
- 1 short paragraph (3–5 sentences).
- Then provide a grid of 9–15 post cards, each with:
  - title
  - 2–4 sentence excerpt
  - needsImage + imgQuery (unique)
  - href to post
  - optional meta: date, tags, readingTime

Visual:
- needsImage: true
- imgQuery: "latest blog posts grid enterprise UI card layout dark"

---

### B.6 SERIES & COLLECTIONS — Deep Dives (Cards Required)

Content requirements:
- 1 short paragraph (3–5 sentences) explaining longer sequences (multi-part).
- Provide 4–8 collection cards (clickable), each with:
  - 2–4 sentence description
  - needsImage + imgQuery
  - href: "/blog/series/<series-slug>"

Example collections (adapt as needed):
- “RAG Reliability Playbook”
- “Client-Owned Deployment Patterns”
- “Governance for AI Platforms”
- “Building Ingestion Pipelines”
- “Licensing and Entitlement Engineering”
- “Operating Day 2: Runbooks and Upgrades”

Visual:
- needsImage: true
- imgQuery: "blog series collections cards grid enterprise UI dark"

---

### B.7 OPTIONAL — Auto-Scroll Latest Strip (Recommended)

Inclusion rule:
- Include this section if it can be rendered cleanly without clutter.
- If included, it MUST:
  - start slow scrolling LEFT → RIGHT on page load
  - loop continuously
  - pause on hover/touch-hold
  - click items to open preview or navigate
- Content:
  - autoScrollPosts: 10–16 items, each with needsImage + imgQuery + href/onClickAction

Visual:
- needsImage: true
- imgQuery: "auto scrolling strip latest posts thumbnails enterprise UI dark"

---

### B.8 NEWSLETTER / SUBSCRIBE — Practical Value Proposition

Content requirements:
- 1–2 paragraphs explaining:
  - what subscribers get (implementation notes, checklists, release notes)
  - frequency in approximate terms (avoid hard promises)
- Provide a compact form-style block (email field + subscribe button) AFTER prose.

CTAs:
- "Subscribe"
- Optional: "RSS" or "Release Notes"

Visual:
- needsImage: true
- imgQuery: "newsletter subscribe form UI enterprise dark minimal"

---

### B.9 FINAL CTA — Keep Reading or Engage

Content requirements:
- 1 short paragraph (3–5 sentences) tying blog content to:
  - smxPP adoption
  - governance-first delivery
  - services + documentation

CTAs:
- "Explore Services"
- "Read Documentation"
- "Browse Posts"

Visual:
- needsImage: true
- imgQuery: "enterprise call to action abstract technology background dark"

---

## C) PAGE STUDIO RENDERING RULES

- Blog page should be navigation-first:
  - most sections are cards/carousel
  - cards are clearly clickable with hover affordance
  - card images are visible at the top of each card
- Featured carousel MUST be present and swipe-enabled.
- If auto-scroll strip is included, it MUST start on page load and scroll left → right slowly.
- Maintain enterprise rhythm and spacing.
- Ensure hero overlay is glassy and does NOT block the image.

Failure to satisfy hero rules, section image rules, card image rules, or carousel rules is invalid.
"""


SMXAI_KNOWLEDGEBASE_PAGE_INSTRUCTIONS = f"""
IMPORTANT CONTEXT FOR THE GENERATOR

This page is NOT a marketing landing page. It is a documentation/knowledgebase surface.
Design must prioritise search, navigation, and fast scanning, while still matching the site’s visual language.

## PLAN GENERATION CONTRACT (MANDATORY)

When generating the page plan JSON:

### 1) Section-level images (required everywhere)
- EVERY major section MUST include:
  - needsImage: true
  - imgQuery: "<specific, concrete image search query>"
- Images MUST be attached at SECTION level.
- Do NOT rely on templates to infer images.
- If a section lacks needsImage + imgQuery, the plan is INVALID.

### 2) Article card rules (MANDATORY: cards + images + navigation)
- Any section that includes article cards MUST ensure:
  - cards is a non-empty list
  - EVERY card includes:
    - title
    - description (1–3 sentences; concise)
    - slug (URL-safe identifier, derived from title; lowercase with hyphens)
    - href (MUST be "/kb/<slug>")
    - ctaLabel (MUST be exactly "Read more..")
    - needsImage: true
    - imgQuery: "<specific, concrete image search query for THIS card>"
    - optional meta (recommended):
      - difficulty: "Getting Started" | "Intermediate" | "Advanced"
      - updated: "YYYY-MM-DD"
      - tags: [ "tag1", "tag2", ... ]
- Card images MUST be attached at CARD level (in addition to the section image).
- Do not reuse the same imgQuery across cards inside the same section.

### 3) Search section (MANDATORY UI block)
- The Knowledgebase page MUST include ONE dedicated Search section near the top that contains:
  - a prominent search input
  - optional filter chips (e.g., Getting Started / Deployment / RAG / Governance / Licensing)
  - optional sort (Newest / A–Z)
- In the plan JSON, include a flag:
  - hasSearch: true

### 4) Category navigation (MANDATORY UI block)
- The Knowledgebase page MUST include ONE dedicated Category Navigation section rendered as clickable cards.
- Implement categories using a NORMAL cards list (NOT a special categories object).
- Each category card MUST follow the same card rules above, except:
  - href MUST be "/kb?category=<category-slug>" (or your platform’s supported route)
  - ctaLabel MUST be exactly "Browse"
  - slug MUST be a category slug (lowercase with hyphens)
  That format is forbidden.

### 5) Featured / Popular articles (MANDATORY)
- Include ONE section for Featured (or Popular) Articles:
  - rendered as clickable article cards (6–10 cards)
  - cards must include images + slug + href + ctaLabel = "Read more.."

This applies to:
- hero
- search
- category navigation
- featured/popular
- getting started (cards)
- deployment guides (cards)
- RAG & ingestion guides (cards)
- governance & operations (cards)
- licensing & billing docs (cards)
- final CTA / support prompt

---

## GLOBAL CONTENT RULES (NON-NEGOTIABLE)
- The Hero banner MUST contain ONLY:
  - a clear headline (hero title)
  - ONE sentence tagline directly under the title (single sentence only)
  - CTAs (buttons/links)
- The Hero banner MUST NOT contain paragraphs, multi-paragraph explanations, bullet lists, or cards.

Knowledgebase writing rules:
- Keep prose concise and functional.
- For non-hero sections: 1–2 short paragraphs max (3–5 sentences each), then cards/lists.
- Prefer “how to” phrasing, checklists, and clear outcomes.
- Avoid marketing language and hype.
- Assume the reader is technical and wants answers fast.

---

## GLOBAL IMAGE RULES (NON-NEGOTIABLE)
- Each major section must include exactly ONE section-level image (needsImage + imgQuery).
- Any section that uses cards MUST include card images for every card.
- Prefer: UI screenshots, diagrams, icons, workflow visuals, technical abstractions.
- Avoid: lifestyle imagery and people.
- Do not reuse the same imgQuery across sections.
- Do not reuse the same imgQuery across cards within the same section.

---

## A) LAYOUT & HERO VISUAL RULES

### Hero Alignment Options (EXPLICIT)
Support both and randomly select one (left or centre) for each generation:
- Default: heroAlignment = "left"
- Alternative: heroAlignment = "centre"

The chosen alignment MUST be emitted in the plan.

### Hero Overlay Rules (MANDATORY)
- Hero text overlay MUST be glassy/translucent.
- The hero MUST NOT use an opaque white banner/card that blocks the image.
- Overlay opacity must allow the hero image to remain clearly visible.

---

## B) REQUIRED KNOWLEDGEBASE PAGE STRUCTURE (IN ORDER)

### B.1 HERO — Slim Banner Only (Title + One Sentence Tagline)

Hero Headline (choose one strong option):
- "Knowledgebase — Guides, Runbooks, and Platform Documentation"
OR
- "Documentation — Operating smxPP in Real Environments"

Tagline (MANDATORY):
- EXACTLY ONE sentence.
- Must mention smxPP explicitly and describe the KB as practical documentation, not marketing.
- Keep it short (ideally 12–22 words).

CTAs:
- Primary: "Search Articles"
- Secondary: "Getting Started"
Optional tertiary link: "Release Notes" (if supported)

Visual:
- needsImage: true
- imgQuery: "enterprise documentation hero knowledgebase UI search dark glassmorphism"

---

### B.2 SEARCH — Find Answers Fast (MANDATORY)

UI requirements:
- hasSearch: true
- Include a prominent search input (full width on desktop).
- Include filter chips (6–10) for major topics:
  - Getting Started
  - Installation & Updates
  - Deployment
  - Ingestion
  - RAG & Grounding
  - Governance & RBAC
  - Operations (Day 2)
  - Licensing
  - Troubleshooting
- Include optional sort dropdown:
  - "Most relevant"
  - "Newest"
  - "A–Z"

Content requirements:
- 1 short paragraph (3–5 sentences) explaining search and filters.

Visual:
- needsImage: true
- imgQuery: "knowledgebase search UI component enterprise dark minimal"

---

### B.3 CATEGORIES — Browse by Topic (Cards Required)

IMPORTANT:
- Render categories as a standard cards grid in the plan JSON: cards = [ ... ]
- Each card is a category card with:
  - title
  - description (1–2 sentences)
  - slug (category slug)
  - href: "/kb?category=<slug>"
  - ctaLabel: "Browse"
  - needsImage: true
  - imgQuery: unique per card

Content requirements:
- 1 short paragraph (3–5 sentences), then category card grid.

Recommended categories (adapt as needed):
- Getting Started
- Installation & Updates
- Deployment (Docker / Cloud)
- Admin Panel & RBAC
- Knowledge Ingestion (PDF/CSV/DB)
- RAG Assistant & Grounding
- Page Studio & Portals
- ML Lab (if enabled)
- Licensing & Plans
- Troubleshooting & Runbooks

Visual:
- needsImage: true
- imgQuery: "knowledgebase categories card grid enterprise UI dark"

---

### B.4 FEATURED / POPULAR — What Most Teams Read First (Cards Required)

Content requirements:
- 1 short paragraph (3–5 sentences).
- Then 6–10 featured article cards.
- EACH card MUST include:
  - title
  - 1–3 sentence description
  - slug + href ("/kb/<slug>")
  - ctaLabel: "Read more.."
  - needsImage + imgQuery
  - optional meta: updated, difficulty, tags

Suggested featured article themes (generate real titles, not placeholders):
- “Install smxPP with pip and initialise a client instance”
- “Configure embeddings and vector stores safely”
- “Ingest PDFs with chunking profiles and traceability”
- “Grounding and evaluation: reducing hallucinations”
- “RBAC and audit logs: operating in sceptical environments”
- “Licence validation and entitlement boundaries”
- “Upgrade strategy and reproducible releases”
- “Common deployment issues and fixes”

Visual:
- needsImage: true
- imgQuery: "featured documentation articles cards grid enterprise dark"

---

### B.5 GETTING STARTED — First-Time Setup (Cards Required)

Content requirements:
- 1–2 short paragraphs (max) describing the onboarding path.
- Provide 6–10 article cards (each follows card rules):
  - install, configure, run locally
  - configure secrets (dev vs prod)
  - create admin user
  - first ingestion
  - first assistant test
  - basic governance setup
  - deploying to a target environment

Visual:
- needsImage: true
- imgQuery: "getting started documentation steps cards enterprise UI dark"

---

### B.6 DEPLOYMENT — Docker, Cloud, and Environments (Cards Required)

Content requirements:
- 1–2 short paragraphs (max).
- Provide 6–10 article cards:
  - Docker Compose / Dockerfile patterns
  - Cloud Run / container deployment
  - env var configuration
  - health checks and logs
  - scaling notes
  - persistent storage strategy (SQLite + mounts)
  - secrets management (prod: Google Secret Manager)

Visual:
- needsImage: true
- imgQuery: "deployment documentation docker cloud run architecture cards dark"

---

### B.7 RAG & INGESTION — Reliable Retrieval (Cards Required)

Content requirements:
- 1–2 short paragraphs (max).
- Provide 6–12 article cards:
  - ingestion pipelines
  - chunking strategies
  - embeddings configuration
  - vector store adapters (SQLite-backed)
  - evaluation harness / regression tests
  - citations and grounding controls
  - handling tables/images in PDFs (where applicable)

Visual:
- needsImage: true
- imgQuery: "RAG ingestion documentation diagram cards enterprise dark"

---

### B.8 GOVERNANCE & OPERATIONS — Day 2 Runbooks (Cards Required)

Content requirements:
- 1–2 short paragraphs (max).
- Provide 6–12 article cards:
  - RBAC and permissions
  - audit logs
  - incident response
  - upgrade/runbook procedures
  - monitoring/observability notes
  - data boundary controls
  - backup/restore strategy

Visual:
- needsImage: true
- imgQuery: "governance operations runbooks documentation cards enterprise dark"

---

### B.9 LICENSING & SUPPORT — Entitlements and Help Paths (Cards Required)

Content requirements:
- 1–2 short paragraphs (max).
- Provide 4–8 article cards:
  - licence basics
  - trial vs free vs pro/business/enterprise boundaries
  - validation modes (offline/remote where enabled)
  - billing portal actions (invoices, payment method)
  - support channels / escalation

Visual:
- needsImage: true
- imgQuery: "software licensing documentation help support cards enterprise dark"

---

### B.10 FINAL CTA — Still Stuck?

Content requirements:
- 1 short paragraph (3–5 sentences) encouraging:
  - use search
  - check troubleshooting/runbooks
  - contact support if needed

CTAs:
- Primary: "Contact Support"
- Secondary: "Browse Troubleshooting"
Optional link: "Release Notes"

Visual:
- needsImage: true
- imgQuery: "support call to action documentation help enterprise dark"

---

## C) PAGE STUDIO RENDERING RULES

- Knowledgebase page must feel utilitarian and fast:
  - Search near the top
  - Clear topic navigation
  - Card grids dominate the layout
  - Short copy; no long narrative sections
- All cards must be clickable and show their images clearly (media at top).
- Category cards MUST use ctaLabel "Browse" and href "/kb?category=<slug>".
- Article cards MUST use ctaLabel "Read more.." and href "/kb/<slug>".
- Avoid clutter: use consistent spacing and headings.
- Ensure hero overlay is glassy and does NOT block the image.

Failure to satisfy hero rules, hasSearch, category section, featured section, section image rules, or card image rules is invalid.
"""


SMXAI_KB_ARTICLE_PAGE_INSTRUCTIONS = f"""
IMPORTANT CONTEXT FOR THE GENERATOR

This is a Knowledgebase ARTICLE DETAILS page.
It must read like a technical report: headings + well-paragraphed text.
It MUST NOT contain card grids, galleries, carousels, or any card-like UI.

The article title MUST be the page title.

---

## LENGTH BUDGET (MANDATORY TO AVOID JSON TRUNCATION)
- Total article body length MUST be roughly 900–1400 words.
- Each main section MUST contain:
  - 1–2 paragraphs maximum
  - Each paragraph must be 3–5 sentences
- Keep code blocks short (max 20 lines each), and use at most 1–2 code blocks total.
- Use bullet lists only AFTER prose and only for checklists/troubleshooting.

If you exceed this budget, the output may be truncated and become invalid.

---

## PLAN GENERATION CONTRACT (MANDATORY)

### A) Output must be a valid plan JSON (no extra chatter)
- Produce a normal page plan using the SAME JSON schema as other pages in this system.
- The plan must include:
  - category (set to "knowledgebase")
  - heroAlignment ("left" or "centre")
  - sections (a list of ordered sections)

### B) Imagery validation safety (MANDATORY)
- Mark needsImage=true for EVERY section in sections.
- Provide a concrete imgQuery for EVERY section.
- Keep images subtle (icons, faint technical textures, minimal diagrams) so the page remains text-first.

### C) Strict NO-CARDS rule
- Do NOT include cards anywhere.
- Do NOT include fields such as: cards, galleryImages, carouselImages, autoScrollGalleryImages.
- If your schema auto-includes cards, set cards to an empty list [] and do not use them.

---

## HERO RULES (MANDATORY)
Hero is slim and must contain ONLY:
- H1 title (the article title)
- ONE sentence tagline (exactly one sentence)
- Optional CTA link: "Back to Knowledgebase" (href: "/knowledgebase" or "/kb")

No paragraphs, no lists, no cards in hero.

---

## REQUIRED ARTICLE STRUCTURE (SECTIONS ORDER)

Your plan.sections MUST be in this order, and each section must be text-first:

1) HERO (type: "hero")
- title, tagline, optional CTA
- needsImage: true
- imgQuery: "technical documentation hero background abstract diagram dark minimal"

2) META (type: "meta")
- 1 short paragraph (3–5 sentences) stating scope and what the reader will achieve
- Then a compact meta line as bullets (plain strings), e.g.:
  - Updated: YYYY-MM-DD (or "Recently updated")
  - Difficulty: Getting Started | Intermediate | Advanced
  - Reading time: X–Y minutes
  - Tags: comma-separated
- needsImage: true
- imgQuery: "minimal monochrome technical icon set subtle dark"

3) TABLE OF CONTENTS (type: "toc")
- Short intro paragraph (3–5 sentences) telling users how to navigate
- Then a TOC list (bullets) of the section headings below
- needsImage: true
- imgQuery: "minimal table of contents icon navigation subtle dark"

4) OVERVIEW (type: "content")
- 1–2 paragraphs
- needsImage: true
- imgQuery: "faint technical paper texture dark minimal"

5) CONTEXT AND WHEN TO USE THIS (type: "content")
- 1–2 paragraphs
- needsImage: true
- imgQuery: "subtle system context diagram icon dark minimal"

6) PREREQUISITES (type: "content")
- 1 paragraph explaining prerequisites in prose
- Then a short checklist as bullets (5–9 items)
- needsImage: true
- imgQuery: "checklist icon minimal technical dark"

7) IMPLEMENTATION / PROCEDURE (type: "content")
- 1–2 paragraphs
- Optional: ONE short code block OR step list (not both unless truly necessary)
- needsImage: true
- imgQuery: "implementation workflow icon subtle dark minimal"

8) CONFIGURATION NOTES (type: "content")
- 1–2 paragraphs focusing on safe defaults and production differences
- needsImage: true
- imgQuery: "settings sliders icon minimal technical dark"

9) SECURITY, GOVERNANCE, AND OPERATIONS (type: "content")
- 1–2 paragraphs focusing on permissions, auditability, data boundaries, and failure modes
- needsImage: true
- imgQuery: "shield audit governance icon minimal dark"

10) TROUBLESHOOTING (type: "content")
- 1 paragraph describing troubleshooting approach
- Then bullets for 5–8 common issues:
  - Symptom
  - Likely cause
  - Fix
(keep each bullet concise)
- needsImage: true
- imgQuery: "debug wrench icon minimal technical dark"

11) VERIFICATION / ACCEPTANCE CHECKS (type: "content")
- 1 paragraph, then a checklist (6–10 bullets)
- needsImage: true
- imgQuery: "verification tick icon minimal technical dark"

12) REFERENCES / FURTHER READING (type: "content")
- 1 short paragraph
- Then plain text bullets with internal links (strings) like:
  - "/kb/<another-article-slug> — Short description"
(Do NOT use cards)
- needsImage: true
- imgQuery: "link references icon minimal technical dark"

13) SUPPORT / FOOTER (type: "footer")
- 1 short paragraph (3–5 sentences) guiding the reader to:
  - search KB
  - browse categories
  - contact support
- Include a small “Back to Knowledgebase” link (href)
- needsImage: true
- imgQuery: "support help icon minimal dark"

---

## RENDERING INTENT
- Single-column, report-style reading layout.
- Clear H1/H2 hierarchy.
- Generous spacing.
- Text dominates; images are subtle and must not distract.
- No cards anywhere.

If any cards or galleries appear, the plan is INVALID.
"""


SMXAI_NEW_PAGE_INSTRUCTIONS_DEFAULT = f"""
  ## GLOBAL CONTENT RULES (NON-NEGOTIABLE)
- The Hero section MUST include a clear headline and subheadline that position the company and smxPP as enterprise AI platform solutions (company = SyntaxMatrix or otherwise).
- If page is generated for company other than SyntaxMatrix, then replace any SyntaxMatrix content with that of the company's content. 
= Each MAJOR section, other than the Hero section, must include 2-3 full paragraphs minimum.
- Each paragraph must be 4-6 complete sentences.
- Prose explanations MUST come before cards or bullets.
- Cards and bullets may ONLY summarise AFTER prose.
- Avoid slogans without explanation.
- Assume the reader is technical and sceptical.
Thin or overly short content in sections other than the Hero section is invalid.

    0· Parse the Website Description (MANDATORY):\n{SMXAI_WEBSITE_DESCRIPTION}\n\n
    1. Input always contains:
        •	website_description - plain-text overview of the site/company (mission, goals, audience, visual style, etc.).
        •	page_title - the specific page to create (e.g. About, Pricing, Blog).
        Read the entire website_description first. Extract:
        • Brand essence & voice
        • Core goals / differentiators
        • Target audience & pain-points
        • Visual/style cues (colours, fonts, imagery)
        Keep this parsed data in memory; every design and content decision must align with it.
    ________________________________________
    2· Decide Content from the Page Title + Parsed Description
        Common Page Title	Content You Must Provide	Tone (derive exact wording from description)
        About	Mission, vision, origin story, key differentiators, stats/metrics.	Inspirational, credible
        Services / Solutions	Features or modules mapped to goals (e.g., “Turnkey chat interface” → “rapid prototyping”).	Action-oriented
        Blog / Insights	Grid of post cards themed around expertise areas in the description.	Conversational, expert
        Pricing	Tier cards tied to value pillars from description.	Clear, persuasive
        Contact / Demo	Benefits blurb + capture form.	Friendly, concise
        If page_title is something else, improvise logically using the parsed Website Description.
    ________________________________________
    3· Layout & Components (omit header/footer—they're supplied elsewhere)
        1.	Hero section - headline that merges page_title with brand essence, sub-headline reinforcing core value, CTA button.
        2.	Main content - 2-4 subsections drawn from goals/differentiators.
        3.	Optional stat strip - highlight metrics pulled from description.
        4.	CTA banner - final prompt aligned with brand voice.
    ________________________________________
    4· Visual & Interaction Rules
        •	Use colours, fonts, and imagery directly referenced in the parsed description (fallback: dark charcoal, accent colour from description, sans-serif font stack).
        •	CDN tech stack (React 18 UMD + Tailwind CSS).
        •	Prefix all custom ids/classes/functions with smx- (or company-specific prefix derived from description) to avoid clashes.
        •	Subtle animations (fade-in, slide-up, ≤ 400 ms).
        •	Accessibility: semantic HTML, alt text, contrast compliance.
    ________________________________________
    5· Royalty-Free Images
        Fetch from Unsplash/Pexels with keywords that combine “ai, technology” plus any industry cues found in the description (e.g., “healthcare”, “finance”). Provide descriptive alt attributes referencing the brand.
    ________________________________________
    6.	Wrap Everything in a Python Function and Return the HTML
        i.	Function signature (exactly):
            def generate_page_html(website_description: str, page_title: str) -> str:
        ii.	Inside the function
            o Parse website_description and page_title per Steps 0–6.
            o Compose the entire HTML document as a single triple-quoted Python string (page_html = ''' … ''').
            o Return that string (return html).
            requirement.
        iii. Function docstring
            '''
            Generate a fully responsive, animated, single-file web page aligned with the
            supplied website description and page title. Returns the HTML as a string.
            ''' 
        iv.	No side effects
            o Do not write to disk or print; just return the HTML.
            o Avoid global variables; everything lives inside the function scope.
        v.	Output format
            o When the LLM responds, it must output only the complete Python source code for generate_page_html - nothing else (no markdown, comments, or explanations outside the code block).

    ________________________________________
    7. Deliverable Checklist
        •	Single .html file (inline CSS/JS; external assets only via CDN & image URLs).
        •	Fully responsive, animated, modern, brand-aligned.
        •	All text and visuals demonstrably reflect the parsed Website Description.
        •	No duplicate header/footer.
        •	All identifiers safely namespaced.
        •	Return only the HTML text—no commentary or extra files.
"""


def get_page_instructions(page_slug: str = "", page_title: str = "") -> str:
    """
    Returns the correct page-type instruction block based on the requested page slug/title.
    This is used to override the generic default prompt during AI page generation.
    """
    key_raw = f"{page_slug or ''} {page_title or ''}".strip().lower()

    # Normalise separators so 'home-page', 'home page', 'home_page' all behave consistently
    key = (
        key_raw
        .replace("_", " ")
        .replace("-", " ")
        .replace("/", " ")
        .replace("\\", " ")
    )
    key = " ".join(key.split())  # collapse whitespace

    # If the UI/slug pipeline produced a placeholder (common when "Home" is selected but name is blank),
    # treat it as Home/Landing so it doesn't fall back to the generic template.
    if key in ("", "page", "index", "root", "frontpage", "front page"):
        return SMXAI_LANDING_PAGE_INSTRUCTIONS

    # Home page (Home + Landing share the same instruction block)
    if any(w in key for w in (
        "landing", "landing page", "landing-page",
        "home", "home page", "home-page", "homepage",
        "main", "main page", "start", "start page",
        "welcome", "welcome page",
    )):
        return SMXAI_LANDING_PAGE_INSTRUCTIONS

    # About page
    if any(w in key for w in ("about", "about-us", "who-we-are", "company", "our-story", "team")):
        return SMXAI_ABOUT_PAGE_INSTRUCTIONS

    # Services page
    if any(w in key for w in ("services", "solutions", "packages", "pricing", "engagement")):
        return SMXAI_SERVICES_PAGE_INSTRUCTIONS

    # Gallery page
    if any(w in key for w in ("gallery", "photos", "portfolio", "screenshots", "showcase")):
        return SMXAI_GALLERY_PAGE_INSTRUCTIONS

    # Careers page
    if any(w in key for w in ("careers", "jobs", "pricing", "contact", "contact-us", "docs", "documentation", "join", "join-us")):
        return SMXAI_CAREERS_PAGE_INSTRUCTIONS

    # Knowledgebase page
    if any(w in key for w in ("knowledgebase", "knowledge-base", "docs", "documentation", "help", "support", "kb", "runbooks")):
        return SMXAI_KNOWLEDGEBASE_PAGE_INSTRUCTIONS

    # Knowledgebase article page
    if any(w in key for w in ("article", "report", "guide", "how-to", "runbook", "troubleshooting", "details")):
        return SMXAI_KB_ARTICLE_PAGE_INSTRUCTIONS

    # Blog page
    if any(w in key for w in ("blog", "articles", "updates", "news", "release-notes")):
        return SMXAI_BLOG_PAGE_INSTRUCTIONS

    # Fallback
    return SMXAI_NEW_PAGE_INSTRUCTIONS_DEFAULT
