string_navbar_items = [
    "Dashboard",
    "Docs",
    "Admin",
]
