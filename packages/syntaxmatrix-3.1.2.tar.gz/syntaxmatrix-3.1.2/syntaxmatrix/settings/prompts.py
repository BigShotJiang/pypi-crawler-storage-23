export = None


SMXAI_CHAT_IDENTITY = """
    Your name is 'smxAI'. 
    You are the expert AI Engineer and Data Scientist at SyntaxMatrix Ltd. 
    Your creator is SyntaxMatrix and you will represent them in any way, shape or form. 
    Your Company is based in Ireland. It designs and develop AI algorithms and softwares for business applications. 
"""


SMXAI_CHAT_INSTRUCTIONS = """
    Content & Formatting Blueprint (Adhere Strictly):
    Structure your response using the following elements as appropriate for the topic. Prioritize clarity and information density. If the query is not a question or if there is no context: generate an appropriate general response based on your training knowledge.
    else if the query is a question:
    1. Generate a response to the given query based on the given user context and/or system context.
    2. Use the chat history to stay relevant.
    3. You must always respond in a conversational tone and do not Hallucinate.
    4. Determine whether based on the query, you should generate a list, table, or just plain text response.
    5. If the response is plain text, each sentence must begin on a new line - use the <br> tag.
    6. If the query is a question that requires a list or table, you must generate the content in the appropriate format.
    7. Use clear, hierarchical headings if the response is longer than a paragraph.
    8. Be direct and concise. Avoid unnecessary fluff or repetition.
    9. Lead with your key conclusion or answer in the first sentence.
    10. Support your answer with clear, factual points.
    
    ────────  FORMAT INSTRUCTIONS ───────────────
        1. Decide which of the following layouts best fits the content:
            • Comparison across attributes or (Key:Value) pairs → HTML <table>. 
            • When creating a table, adhere to the following styling instructions:
                a. First, declare 3 colors: c1="#EDFBFF", c2="#CCCCCC", c3="#E3E3E3".
                b. The generated table must be formatted so that table cells have border lines.
                c. The table head (<thead>) must always have a background color of c1.
                d. The rest of the rows in the table body (<tbody>) must alternate between 2 background colors, c2 and c3 (striped).
            • Use bullet points for simple lists of items, features → HTML <ul>
            • Use ordered (numbered or step-by-step) list for sequences or steps in a process → HTML <ol>
        2. Keep cells/list items concise (one fact or metric each).  
        3. All markup must be raw HTML. Avoid using markdown symbols like **asterisks** or _underscores_ for emphasis.
        4. Do not wrap the answer inside triple back-ticks.
        6. If emphasis is needed, use clear language (e.g., "It is important to note that...").
        7. Use horizontal lines (<hr>) sparingly to separate distinct sections.
        8. The final output should be professional, easy to scan, and ready to be pasted into a document or email.
"""


SMXAI_WEBSITE_DESCRIPTION = """
# SyntaxMatrix — Website Description (Updated, Comprehensive)

> **Purpose of this document**
>
> Use this as the canonical, up‑to‑date description of SyntaxMatrix for:
> - Website copy (About / Services / Blog / Gallery / Landing pages)
> - Page Studio “website description” context (so new pages stay concrete)
> - README + /docs alignment (no conflicting phrasing)
> - Sales decks, sponsor packs, and proposals

---

## 1) One‑sentence definition

**SyntaxMatrix is a full‑stack Python framework for provisioning client-ready AI platforms — with a web UI, role controls, a content system, a RAG assistant, and an ML Lab — so teams can ship AI products faster and maintain them properly.**

---

## 2) What SyntaxMatrix is (in plain English)

SyntaxMatrix turns “we want an AI platform” into a deployable system by providing the foundation most teams end up building repeatedly:

- A **web application shell** (Flask-based) with navigation, theming, and role-aware access  
- A **Chat Assistant** that supports tool calling, streaming output, and grounded answers via RAG  
- A **Knowledge Base ingestion pipeline** to ingest documents and retrieve relevant context  
- A **Page Studio** to create, edit, and publish pages (including AI-assisted generation)  
- A **Dashboard / ML Lab** for dataset upload, EDA, modelling, and exportable result reports  
- **Persistence** for platform data (pages, history, uploads) and embeddings through pluggable stores

The intent is not “demo UI”. It is **a repeatable platform baseline** you can deploy per client instance, adapt to different organisations, and grow over time.

---

## 3) Who it is for

SyntaxMatrix is built for people shipping AI systems in real contexts:

- **AI/ML engineers** building RAG assistants, domain copilots, internal AI tools  
- **Software teams** who want AI features without rebuilding infrastructure each time  
- **Enterprises** needing roles, predictable behaviour, and controlled exposure of features  
- **Educators and researchers** who need analytics + AI assistance inside a usable platform  

---

## 4) Core promise and product mindset

### 4.1 Provision per client (repeatably)
SyntaxMatrix supports a “client instance” mindset: each deployment can have its own branding, data sources, controls, and enabled capabilities.

### 4.2 Keep AI controllable
The framework is designed so stakeholders can enable/disable whole modules (Docs, ML Lab, Registration, Theme Toggle, User Uploads, etc.) instead of relying on code changes.

### 4.3 Make content + data + AI live together
Useful AI assistants need:
- the right documents  
- the right UI surfaces  
- the right controls  
- the ability to render outputs and explain results

SyntaxMatrix treats those as one system.

---

## 5) Feature set (what it can do today)

### 5.1 Web app shell + role-aware access
A client app includes a web UI with:
- navigation and pages
- authentication + role-aware access pathways
- consistent design tokens and theme support (where enabled)

### 5.2 Page Studio (create/edit/publish pages)
Page Studio provides:
- page creation by slug/category (About, Services, Blog, Landing, Docs, Gallery, etc.)
- a **section-based layout model** (hero, features, values, process, FAQs, CTA, etc.)
- editing and patching of sections/items
- publishing to the frontend with safe HTML cleanup
- media selection (Uploads + Online images when allowed in the client app)

**Outcome:** a non-technical operator can manage website content without editing templates.

### 5.3 Documentation viewer (/docs)
The documentation area can:
- render a client’s `README.md` inside the app
- support code highlighting, copy buttons, structured headings, and a navigable sidebar
- embed client assets under `/docs/...` (screenshots, diagrams, and exported ML results)

### 5.4 Chat Assistant (smxAI)
The assistant supports:
- streaming responses
- structured, readable output formatting
- tool calling (task execution workflows)
- grounding through RAG (retrieval over client documents)
- chat history where enabled

### 5.5 Document ingestion + RAG
The knowledge base pipeline includes:
- document upload
- text extraction and chunking
- embedding generation
- semantic retrieval and context injection for grounded answers

### 5.6 Dashboard / ML Lab (analytics + modelling)
The ML Lab provides:
- CSV upload and dataset selection
- automated EDA (tables + visuals)
- code-generated modelling (classification/regression/clustering)
- managed execution in a kernel environment
- export of results into a shareable HTML report (“result file”)

### 5.7 Admin Panel
Admin features include:
- page management workflows
- media management (uploads)
- basic audit-friendly flows depending on client configuration
- safe publishing checks

### 5.8 Feature toggles / configuration
A client instance can expose or hide modules such as:
- Site documentation
- ML Lab
- Registration
- Theme toggle
- User file uploads

This allows a non-technical owner to control what is live, without touching code.

---

## 6) Data and persistence (platform storage)

SyntaxMatrix stores and retrieves platform data such as:
- page layouts (draft + published)
- documentation and assets references
- chat history and conversation metadata (when enabled)
- uploads and media references
- embeddings and vector metadata through store adapters

---

## 7) Vector storage and retrieval (upgrade-ready)

SyntaxMatrix is designed around a **vector-store adapter** approach so deployments can choose the backend that matches scale, cost, and operational constraints.

### 7.1 Local / pilot deployments
- SQLite-backed persistence and vector storage for quick provisioning and smaller deployments

### 7.2 Premium upgrades (Pro / Enterprise)
Premium subscription upgrades include the vector backends organisations commonly require for production scale:

- **PostgreSQL + pgvector**
- **Milvus**
- **Pinecone**

These are delivered as upgrade connectors (so clients can move from local to production without redesigning the product).

---

## 8) Deployment and operations

SyntaxMatrix is designed to run in standard Python deployment patterns, including:
- Docker-based deployments
- WSGI setups (e.g., Gunicorn)
- cloud-hosted patterns (e.g., GCP deployments per client needs)

The key product value is repeatability: the same core framework supports multiple client instances without rewriting the system each time.

---

## 9) Security and privacy posture (high level)

SyntaxMatrix is built to support controlled deployments through:
- role-aware access to sensitive tools and pages
- feature toggles (disable modules until configured)
- client-controlled model keys and routing
- separation of client instances and their storage footprints

Additionally, SyntaxMatrix supports premium workflows for **client-specific open-model fine-tuning** where organisations require stronger privacy boundaries.

---

## 10) Fine-tuning and model options (premium direction)

SyntaxMatrix supports provider flexibility and can accommodate:
- different LLM providers depending on task type (chat vs code vs summarisation)
- cost/latency-aware model selection
- premium workflows for **fine-tuning open-source models per client** for privacy, custom terminology, and improved performance

---

## 11) What makes SyntaxMatrix different

### 11.1 It is a platform system, not a collection of scripts
SyntaxMatrix combines UI + content + data + AI + controls.

### 11.2 It is built for real workflows
Admins can manage pages, docs, and outputs. Users can interact with an assistant and see results in the product.

### 11.3 It supports growth
Teams can start simple and evolve: more documents, more modules, stronger vector backends, fine-tuned models, and more specialised pages — without changing the core mental model.

---

## 12) Website positioning blocks (ready to paste)

### 12.1 Homepage paragraph
SyntaxMatrix is a full‑stack Python framework for provisioning client-ready AI platforms.  
It combines a web UI, role controls, a document ingestion pipeline for RAG, a Chat Assistant, a Page Studio for publishing content, and an ML Lab for analytics and modelling — so teams can ship AI systems quickly and run them with confidence.

### 12.2 “What you can build” bullets
- AI assistants with tool calling, streaming UI, and RAG over client documents  
- AI‑powered websites with a Page Studio for creating and publishing pages  
- Knowledge base ingestion pipelines (chunking, embeddings, semantic retrieval)  
- An ML Lab for EDA and modelling with exportable HTML result reports  
- Upgrade-ready vector backends (Postgres/pgvector, Milvus, Pinecone) on premium plans  
- Controlled deployments with roles, toggles, and client-specific configuration

### 12.3 “Who it’s for” bullets
- Product teams shipping AI features  
- AI engineers building grounded assistants  
- Organisations needing privacy-aware deployments  
- Teams who want one platform baseline across multiple client instances

---

## 13) Team (public-facing, truthful)

- **Bobga Nti — Founder / AI Engineer**  
- **Yvonne Motuba — Company Secretary**

---

## 14) Language rules for page generation (important)

When generating any website page for SyntaxMatrix:
- Always describe SyntaxMatrix as an **AI Framework Company** (not a generic services agency)
- Always connect content back to core modules: **Page Studio, Docs, RAG assistant, ML Lab, roles/toggles**
- Avoid vague claims. Prefer concrete capabilities, workflows, and outcomes.
"""


SMXAI_LANDING_PAGE_INSTRUCTIONS = f"""
IMPORTANT CONTEXT FOR THE GENERATOR

## PLAN GENERATION CONTRACT (MANDATORY)

When generating the page plan JSON:

- EVERY major section MUST include:
  - needsImage: true
  - imgQuery: "<specific, concrete image search query>"
- Images MUST be attached at section level.
- Do NOT rely on templates to infer images.
- If a section lacks needsImage + imgQuery, the plan is INVALID.

## HERO SLIMNESS OVERRIDE (MANDATORY)
- The Hero banner must contain ONLY:
  1) Hero title (headline)
  2) Exactly ONE sentence tagline directly underneath
- Do NOT include CTAs/buttons/links in the Hero.
- Do NOT include any paragraphs, bullets, cards, lists, “kicker” lines, or secondary sub-headings in the Hero.
- Tagline limits (strict):
  - ONE sentence only
  - <= 22 words
  - <= 140 characters
  - no line breaks
- Any content that would normally go in the Hero MUST be moved into the first section after Hero:
  "Introduction — Company + Product Positioning (Below Hero)"

This applies to:
- hero
- problem framing
- solution overview
- platform highlights
- deployment models
- trust / governance
- licensing model
- plans overview
- proof / credibility
- final CTA

---

## GLOBAL CONTENT RULES (NON-NEGOTIABLE)

- The Hero banner MUST contain ONLY:
  - a clear headline (hero title)
  - ONE sentence tagline directly under the title (single sentence only)
  - CTAs (buttons/links)
- The Hero banner MUST NOT contain paragraphs, multi-paragraph explanations, bullet lists, or cards.
- All explanatory prose that used to be in the Hero MUST be placed in a dedicated section immediately AFTER the Hero.

- Each MAJOR section OTHER than the Hero banner must include 2–3 full paragraphs minimum.
- Each paragraph must be 4–6 complete sentences.
- Prose explanations MUST come before cards or bullets.
- Cards and bullets may ONLY summarise AFTER prose.
- Avoid slogans without explanation.
- Assume the reader is technical and sceptical.

Thin or overly short content in sections other than the Hero banner is invalid.

---

## GLOBAL IMAGE RULES (NON-NEGOTIABLE)

- Each major section must include exactly ONE image.
- Prefer: architecture diagrams, platform UI visuals, system diagrams, abstract technical visuals.
- Avoid: lifestyle photos, generic startup imagery, people (unless explicitly requested).
- Do not reuse the same imgQuery across sections.

---

## A) LAYOUT & HERO VISUAL RULES

### Hero Alignment Options (EXPLICIT)
Support both and select one:

- Default: heroAlignment = "left"
- Alternative: heroAlignment = "center"

The chosen alignment MUST be emitted in the plan.

### Hero Overlay Rules (MANDATORY)
- Hero text overlay MUST be glassy/translucent.
- The hero MUST NOT use an opaque white banner/card that blocks the image.
- Overlay opacity must allow the hero image to remain clearly visible.

---

## B) REQUIRED HOMEPAGE STRUCTURE (IN ORDER)

### B.1 HERO — Slim Banner Only (Title + One Sentence Tagline)

Hero banner content rules (MANDATORY):
- The hero banner MUST include ONLY:
  1) Hero Headline (title)
  2) One-sentence Tagline (exactly ONE sentence; no second sentence)
  3) CTAs
- Do NOT include paragraphs, bullets, cards, or multi-line prose in the hero banner.
- Any long-form explanation about SyntaxMatrix, smxPP, or client-owned deployment MUST be moved to the next section:
  "Introduction — Company + Product Positioning (Below Hero)"

Hero Headline (choose one strong, enterprise option):
- "Provision Client-Owned AI Platforms — Securely, Governably, Repeatably"
OR
- "Enterprise AI Platforms You Can Own, Deploy, and Govern"

Tagline (MANDATORY):
- EXACTLY ONE sentence.
- Must mention smxPP explicitly and clarify it provisions a complete platform, not a single chatbot.
- Keep it short (ideally 12–22 words).

CTAs:
- Primary: "Explore Services"
- Secondary: "Read Documentation"
Optional tertiary link: "Licensing Explained"

In the hero section JSON, you MUST emit CTA fields explicitly:
- heroCta1Label, heroCta1Href
- heroCta2Label, heroCta2Href
- (optional) heroCta3Label, heroCta3Href
Hrefs MUST NOT be "/admin".

Visual:
- needsImage: true
- imgQuery: "enterprise AI platform hero architecture abstract dark glassmorphism"

---

### B.1.5 INTRODUCTION — Company + Product Positioning (Below Hero)

Content requirements:
- 2–3 paragraphs explaining:
  - what SyntaxMatrix is (AI infrastructure + algorithm design company)
  - what smxPP is (deployable platform provisioner)
  - why client-owned deployment matters (data sovereignty, governance, control)
- Avoid hype. Use concrete, operational language.
- After prose, you MAY include 3–5 short bullets summarising key points.

Visual:
- needsImage: true
- imgQuery: "client owned AI platform overview architecture diagram dark enterprise"

---

### B.2 THE PROBLEM — Why AI Prototypes Fail in Production

Content requirements:
- 2–3 paragraphs explaining the real pain points:
  - teams rebuilding AI infrastructure repeatedly
  - fragile RAG pipelines and unreproducible behaviour
  - lack of governance, audit trails, and role separation
  - mismatch between content systems and AI systems
  - vendor lock-in and unclear data boundaries
- Follow with a short bullet list summarising 5–7 issues.

Visual:
- needsImage: true
- imgQuery: "enterprise AI production challenges diagram fragmentation governance"

---

### B.3 THE SOLUTION — What smxPP Provisions

Content requirements:
- 2–3 paragraphs explaining:
  - smxPP provisions a complete platform surface (not a toy UI)
  - how modules fit together (admin panel, ingestion, assistant, pages, ML tooling, analytics)
  - how this reduces time-to-deploy and increases operational stability

Include a short summary list after prose:
- Role-aware Admin Panel
- Knowledge ingestion + RAG assistant
- Page Studio and documentation surfaces
- ML Lab outputs and exports (where enabled)
- Licensing boundaries and entitlements (premium)

Visual:
- needsImage: true
- imgQuery: "AI platform overview diagram admin panel RAG page studio ML lab"

---

### B.4 PLATFORM HIGHLIGHTS — What Enterprises Actually Get

Content requirements:
- 2 paragraphs introducing the philosophy: operational value > demos.
- Then provide 6 highlight blocks (each with a 4–6 sentence paragraph, not one-liners):
  1) Role-aware access and governance
  2) Document ingestion and retrieval architecture
  3) RAG assistant with controlled grounding
  4) Page Studio for internal/external portals
  5) Documentation viewer integrated into the platform
  6) Optional ML Lab workflows and exports

Cards may summarise each after the prose paragraphs.

Visual:
- needsImage: true
- imgQuery: "enterprise software dashboard UI panels RAG admin governance"

---

### B.5 DEPLOYMENT MODELS — Client-Owned by Design

Content requirements:
- 2–3 paragraphs explaining:
  - self-hosted deployment model (client instance)
  - why SyntaxMatrix does not host client instances by default
  - how BYOK and data locality reduce procurement friction
- Include a comparison block after prose:
  - On-premise
  - Private cloud
  - Controlled cloud deployments (e.g., container-based)

Visual:
- needsImage: true
- imgQuery: "deployment models on premise private cloud architecture diagram"

---

### B.6 TRUST & GOVERNANCE — Built for Sceptical Environments

Content requirements:
- 2–3 paragraphs addressing:
  - auditability, role separation, operational controls
  - how content ingestion is managed and traceable
  - how organisations can govern AI behaviour over time
- Include a short list of enterprise trust signals:
  - controlled permissions
  - clear data boundary
  - reproducible upgrades
  - documented operations

Visual:
- needsImage: true
- imgQuery: "enterprise compliance security audit governance diagram"

---

### B.7 LICENSING MODEL — Sustainable, Enforceable, Enterprise-Friendly

Content requirements:
- 2–3 paragraphs explaining:
  - open-core commercial model
  - signed, instance-bound licences
  - remote validation where enabled for subscription integrity
  - grace period handling to avoid sudden disruption
- Explain the self-serve portal benefits:
  - update payment method
  - view invoices
  - cancel at period end
- Emphasise fraud resistance as investor-grade assurance, without sounding adversarial.

Visual:
- needsImage: true
- imgQuery: "software licensing cryptographic signature keys enterprise diagram"

---

### B.8 PLANS OVERVIEW — Capability Progression (No Prices)

Content requirements:
- 2–3 paragraphs explaining plan philosophy:
  - Trial is full access for evaluation
  - Free is constrained but functional
  - Pro is for small teams adopting smxPP seriously
  - Business is for scaled operations needing more caps and governance
  - Enterprise is for institutions with strict requirements and deeper controls
- Do NOT include pricing. Explain operational value and typical fit.
- Provide a concise summary table AFTER prose (caps/features high-level only).

Visual:
- needsImage: true
- imgQuery: "enterprise pricing tiers progression comparison chart abstract"

---

### B.9 PROOF & CREDIBILITY — Why This Is Real

Content requirements:
- 2–3 paragraphs explaining:
  - engineering-first platform design
  - documented deployment approach
  - measurable operational focus (reliability, governance, reproducibility)
- Include a short credibility block:
  - Founder profile line (Bobga Nti — Founder / AI Engineer; MSc AI, platform engineering focus)
  - Company governance line (Yvonne Motuba — Company Secretary; corporate oversight)
- Keep it professional and factual.

Visual:
- needsImage: true
- imgQuery: "enterprise software engineering credibility diagram architecture blueprint"

---

### B.10 FINAL CTA — Next Steps

Content requirements:
- 1–2 paragraphs reinforcing:
  - client-owned AI platform value
  - governance-first stance
  - how to engage (services + documentation + licensing trust)

CTAs:
- "Talk to SyntaxMatrix"
- "Explore Services"
- "Read Documentation"
Optional link: "Licensing Explained"

Visual:
- needsImage: true
- imgQuery: "enterprise call to action abstract technology background dark"

---

## C) PAGE STUDIO RENDERING RULES

- Prose first, UI blocks second
- No compressed sections
- Maintain enterprise rhythm and spacing
- Ensure hero overlay is glassy and does NOT block the image

Failure to satisfy content depth or image rules is invalid.

"""


SMXAI_ABOUT_PAGE_INSTRUCTIONS = f"""
IMPORTANT CONTEXT FOR THE GENERATOR
This page must read like the About page of a serious infrastructure and design by the website desc.
This is NOT marketing copy. This is NOT a teaser. This is a full company profile.
Failure to follow layout, image, or depth requirements invalidates the output.

🔒 PLAN GENERATION CONTRACT (MANDATORY)
When generating the internal page plan JSON:
EVERY major section MUST explicitly include an image block
For EACH section, the planner MUST emit:
needsImage: true

imgQuery: "<specific, concrete image search query>"
Images must be attached at section level
Do NOT rely on defaults
If any section lacks needsImage + imgQuery, the plan is INVALID

This applies to:
hero
mission / vision
problem statement
platform architecture
capabilities
principles
founders
credibility / roadmap
final CTA

## HERO SLIMNESS OVERRIDE (MANDATORY)
- The Hero banner must contain ONLY:
  1) Hero title (headline)
  2) Exactly ONE sentence tagline directly underneath
- Do NOT include CTAs/buttons/links in the Hero.
- Do NOT include any paragraphs, bullets, cards, lists, “kicker” lines, or secondary sub-headings in the Hero.
- Tagline limits (strict):
  - ONE sentence only
  - <= 22 words
  - <= 140 characters
  - no line breaks
- Any content that would normally go in the Hero MUST be moved into the first section after Hero:
  "Introduction — Company + Product Positioning (Below Hero)"

🎯 PAGE GOAL
Generate a comprehensive, long-form About page that explains:
What SyntaxMatrix is
Why it exists
What it builds (smxPP)
How the platform works internally
How it is deployed and governed
Who built it and why they are qualified
Why enterprises should trust it
Audience:

CTOs
Heads of Engineering
AI Architects
Enterprise Buyers
Technical Investors

Tone:
enterprise-grade
technical
confident
explanatory
sceptic-aware
never hype-driven

📐 GLOBAL CONTENT RULES (NON-NEGOTIABLE)
This page MUST be long-form prose
Each MAJOR section must include:
3-4 full paragraphs minimum
Each paragraph 6-7 sentences
Bullet points and cards are allowed ONLY as summaries
Prose explanations MUST come first
No slogans without explanation
Assume the reader is technically competent and distrustful
Thin content = failure.

🖼️ GLOBAL IMAGE RULES (NON-NEGOTIABLE)
Every MAJOR section MUST include an image
Images support comprehension — they do NOT replace text

Prefer:
architecture diagrams
abstract technical visuals
interfaces

Avoid:
lifestyle photos
generic startup imagery
Do NOT reuse images across sections

🧩 A) LAYOUT & HERO RULES
Hero Layout Options (EXPLICIT)
The generator MUST support both layouts:
Default: heroAlignment = "left"
Alternative: heroAlignment = "center"
The chosen alignment MUST be emitted in the plan.
Hero Overlay Rules (MANDATORY)
Overlay style MUST be glassy / translucent
NO opaque white cards
Overlay opacity should allow the hero image to remain visible
The hero image must visually dominate

🧱 B) REQUIRED SECTION STRUCTURE (IN ORDER)
B.1 Hero — Slim Banner Only (Title + One Sentence Tagline)

Hero banner content rules (MANDATORY):
- The hero banner MUST include ONLY:
  1) Hero Headline (title)
  2) One-sentence Tagline (exactly ONE sentence)
  3) CTAs
- Do NOT include paragraphs, bullets, cards, or multi-line prose in the hero banner.
- All long-form explanation MUST be moved to the next section: "B.1.5 Introduction — Company Identity & Positioning (Below Hero)".

CTAs (and JSON fields):
- heroCta1Label: "View Services"
- heroCta1Href: "#services" (or the correct in-page anchor for your Services section)
- heroCta2Label: "Read Documentation"
- heroCta2Href: "/docs" (or the correct documentation route)
Hrefs MUST NOT be "/admin".
Visual:
needsImage: true
imgQuery: "enterprise AI infrastructure architecture abstract dark"

B.1.5 Introduction — Company Identity & Positioning (Below Hero)
Content requirements:

3–4 paragraphs explaining:
- what SyntaxMatrix is as a company
- its focus on AI infrastructure and algorithm design
- the difference between SyntaxMatrix and hosted AI tools
- introduce smxPP as the core product
- explain “client-owned AI platforms” in concrete terms

After prose, you MAY add a short bullet summary.

B.2 Mission and Vision
Mission:
2 paragraphs explaining what the company delivers today

Focus on engineering outcomes, not aspirations

Vision:
2 paragraphs explaining the long-term direction:
governed AI systems
composable platforms
ownership, auditability, control
Visual:

needsImage: true

imgQuery: "enterprise technology mission vision abstract diagram"

B.3 Why SyntaxMatrix Exists
Content requirements:
3-4 paragraphs describing industry pain points in depth:
repeated rebuilding of AI stacks
fragile RAG systems
lack of governance and audit trails
separation of AI from content systems
Follow with a short bullet summary

Visual:
needsImage: true
imgQuery: "enterprise AI complexity fragmentation diagram"
B.4 The smxPP Platform Architecture
Content requirements:

4-5 paragraphs explaining:
internal architecture of smxPP
subsystem interaction
why this design enables reuse and governance
Explicitly describe:
role-aware UI
document ingestion

RAG pipelines

Page Studio

ML Lab

vector stores

licensing boundaries

Visual:

needsImage: true

imgQuery: "AI platform architecture diagram UI RAG ML pipeline"

B.5 Core Capabilities

Intro:

2 paragraphs explaining the capability philosophy

For EACH capability:

1 paragraph explaining what it does

1 paragraph explaining why it matters operationally

Capabilities:

Chat assistant (tools, RAG, streaming)

Document ingestion & retrieval

Page Studio

Documentation viewer

ML Lab & exports

Vector store upgrades

Visuals:

needsImage: true per capability

imgQuery aligned per capability (specific, technical)

B.6 Operating Principles

Content requirements:

Intro paragraph on why principles matter in AI systems

Each principle:

short title

3–4 sentence explanation

No slogans without substance

Visual:

needsImage: true

imgQuery: "engineering principles abstract geometric"

B.7 Founders & Governance

Content requirements:

Intro paragraph on leadership and accountability

Bobga Nti — Founder / AI Engineer

Detailed paragraph on background, system design focus, and role

Yvonne Motuba — Company Secretary

Paragraph on governance, compliance, and organisational stability

This section MUST explicitly address trust and credibility

Visual:

needsImage: true

imgQuery: "professional executive portrait neutral background"

B.8 Credibility, Premium Capabilities & Roadmap

Content requirements:

2 paragraphs on current production capabilities

2 paragraphs on premium / enterprise features:

licensing

audit

deployment control

1–2 paragraphs on roadmap direction

No over-promising

Visual:

needsImage: true

imgQuery: "enterprise product roadmap timeline minimal"

B.9 FAQ

Requirements:

5–7 FAQs

Each answer 2–3 sentences

Must include:

What is a client instance?

Where does data live?

Can we deploy privately?

How licensing works?

What premium provides?

Visual: optional

B.10 Final CTA

Content requirements:

1 paragraph reinforcing value and deployment model

Clear next steps

CTAs:

“Talk to SyntaxMatrix”

“View Documentation”

Visual:

needsImage: true

imgQuery: "enterprise AI call to action abstract technology"

🛠️ C) PAGE STUDIO RENDERING RULES

Narrative prose first, UI blocks second

Cards summarise; paragraphs explain

No section should feel compressed

The page must read like a full company profile

✅ END OF INSTRUCTIONS
"""


SMXAI_SERVICES_PAGE_INSTRUCTIONS = """

IMPORTANT CONTEXT FOR THE GENERATOR

🔒 PLAN GENERATION CONTRACT (MANDATORY)
When generating the page plan JSON:
EVERY major section MUST explicitly include an image
For EACH section, the planner MUST emit:
needsImage: true
imgQuery: "<specific, concrete image search query>"
Images MUST be attached at section level
Do NOT rely on default templates
If any section lacks needsImage + imgQuery, the plan is INVALID
This applies to:

hero
service categories
deployment models
premium services
licensing
enterprise engagement
final CTA

## HERO SLIMNESS OVERRIDE (MANDATORY)
- The Hero banner must contain ONLY:
  1) Hero title (headline)
  2) Exactly ONE sentence tagline directly underneath
- Do NOT include CTAs/buttons/links in the Hero.
- Do NOT include any paragraphs, bullets, cards, lists, “kicker” lines, or secondary sub-headings in the Hero.
- Tagline limits (strict):
  - ONE sentence only
  - <= 22 words
  - <= 140 characters
  - no line breaks
- Any content that would normally go in the Hero MUST be moved into the first section after Hero:
  "Introduction — Company + Product Positioning (Below Hero)"

🎯 PAGE GOAL
Generate a long-form, enterprise Services page that explains:
What services SyntaxMatrix provides
How smxPP is delivered, deployed, and governed
What premium and enterprise plans unlock
How licensing works in practice
Why enterprises trust this model
Audience:

CTOs
Heads of Engineering
Enterprise Architects
Procurement & Compliance teams
Technical buyers

Tone:
enterprise-first
technical
precise
confident
operational, not promotional

📐 GLOBAL CONTENT RULES (NON-NEGOTIABLE)
This page MUST be long-form prose
Each MAJOR section must include:

3-4 full paragraphs minimum

Each paragraph 6-8 sentences

Cards and bullets are allowed ONLY as summaries

Prose explanations MUST come first

Avoid slogans

Assume sceptical, technical readers

Thin or marketing-style content = failure.

🖼️ GLOBAL IMAGE RULES (NON-NEGOTIABLE)

Every MAJOR section MUST include a visual

Images support comprehension

Prefer:

architecture diagrams

deployment diagrams

governance visuals

Avoid:

lifestyle imagery

abstract “startup” photos

🧩 A) LAYOUT & HERO RULES
Hero Layout Options

The generator MUST support:

heroAlignment = "left"

heroAlignment = "center"

One must be explicitly selected.

Hero Overlay Rules

Overlay MUST be glassy / translucent

NO opaque white banners

Hero image must remain visible and dominant

🧱 B) REQUIRED SECTION STRUCTURE (IN ORDER)
B.1 Hero — Slim Banner Only (Title + One Sentence Tagline)

Hero banner content rules (MANDATORY):
- The hero banner MUST include ONLY:
  1) Hero Headline (title)
  2) One-sentence Tagline (exactly ONE sentence)
  3) CTAs
- Do NOT include paragraphs, bullets, cards, or multi-line prose in the hero banner.
- All long-form explanation MUST be moved to the next section: "B.1.5 Introduction — Services Overview (Below Hero)".

CTAs (and JSON fields):
- heroCta1Label: "Explore Plans"
- heroCta1Href: "#plans" (or the correct in-page anchor)
- heroCta2Label: "Talk to Engineering"
- heroCta2Href: "#contact" (or the correct in-page anchor)
Hrefs MUST NOT be "/admin".

Visual:

needsImage: true

imgQuery: "enterprise AI services platform architecture dark"

B.1.5 Introduction — Services Overview (Below Hero)

Content requirements:

2–3 paragraphs explaining:
- SyntaxMatrix’s service philosophy
- Why services are centred around platform provisioning, not one-off builds
- How smxPP underpins all service offerings
- Services scaling from pilot to enterprise

After prose, you MAY include a short bullet summary.

B.2 Platform Provisioning Services

Content requirements:

3 paragraphs explaining:

What it means to provision a client-owned AI platform

How smxPP is delivered into a client environment

How this differs from hosted AI tools

Explicitly cover:

runtime ownership

data locality

security boundary control

Visual:

needsImage: true

imgQuery: "client owned AI platform deployment architecture diagram"

B.3 Deployment Models

Content requirements:

2–3 paragraphs explaining supported deployment modes:

on-premise

private cloud

regulated environments

Explain operational implications of each

Follow with a short comparison list

Visual:

needsImage: true

imgQuery: "enterprise deployment models on premise cloud diagram"

B.4 Core Service Domains

Intro:

2 paragraphs explaining how services map to enterprise needs

For EACH domain:

1 paragraph explaining what is delivered

1 paragraph explaining business impact

Domains include:

AI Assistant & RAG Systems

Document Ingestion & Knowledge Architecture

Page Studio & Internal Portals

ML Lab & Model Workflows

Vector Store Engineering

Visual:

needsImage: true per domain

imgQuery aligned to each domain (technical, specific)

B.5 Premium & Enterprise Capabilities

Content requirements:

3 paragraphs explaining:

what premium unlocks beyond free/trial

why these features matter operationally

MUST include:

licensing enforcement

auditability

entitlement gating

advanced vector backends

ML exports

Visual:

needsImage: true

imgQuery: "enterprise AI premium features governance diagram"

B.6 Licensing & Governance Services

Content requirements:

3 paragraphs explaining:

the licensing model

remote licence validation

fraud prevention and entitlement control

Emphasise:

enterprise trust

subscription integrity

offline and controlled environments

Visual:

needsImage: true

imgQuery: "enterprise software licensing governance security diagram"

B.7 Engagement & Support Model

Content requirements:

2–3 paragraphs explaining:

onboarding

technical enablement

long-term support

Explain how SyntaxMatrix works with engineering teams, not replaces them

Visual:

needsImage: true

imgQuery: "enterprise engineering collaboration workflow diagram"

B.8 Plans Overview (Narrative, Not Pricing Table)

Content requirements:

2 paragraphs explaining plan philosophy:

Free / Trial

Pro

Business

Enterprise

No prices here — explain capability progression

Visual:

needsImage: true

imgQuery: "enterprise service tiers progression diagram"

B.9 Enterprise Trust & Compliance

Content requirements:

2 paragraphs addressing:

data ownership

auditability

deployment control

regulatory alignment

This section MUST explicitly reassure enterprise buyers

Visual:

needsImage: true

imgQuery: "enterprise compliance security audit abstract diagram"

B.10 Final CTA

Content requirements:

1 paragraph reinforcing service value

Clear next steps

CTAs:

“Talk to SyntaxMatrix”

“View Licensing Explained”

Visual:

needsImage: true

imgQuery: "enterprise AI consultation call to action abstract"

🛠️ C) PAGE STUDIO RENDERING RULES

Prose first, cards second

No compressed sections

Page must read like a consulting-grade services document

✅ END OF INSTRUCTIONS
"""


SMXAI_GALLERY_PAGE_INSTRUCTIONS = """
You are generating a GALLERY page. This page must behave like a true photo/screenshot gallery.

## HERO SLIMNESS OVERRIDE (MANDATORY)
- The Hero banner must contain ONLY:
  1) Hero title (headline)
  2) Exactly ONE sentence tagline directly underneath
- Do NOT include CTAs/buttons/links in the Hero.
- Do NOT include any paragraphs, bullets, cards, lists, “kicker” lines, or secondary sub-headings in the Hero.
- Tagline limits (strict):
  - ONE sentence only
  - <= 22 words
  - <= 140 characters
  - no line breaks
- Any content that would normally go in the Hero MUST be moved into the first section after Hero:
  "Introduction — Company + Product Positioning (Below Hero)"

ABSOLUTE REQUIREMENTS
1) The page plan MUST include a section with:
   - type: "gallery"
   - id: "sec_gallery" (or similar)
2) The gallery section MUST contain 6–9 items where EACH item is a true image tile:
   - item.type MUST be "image" (NOT "card")
   - Use short titles (2–5 words max) and very short captions (0–1 sentence).
   - Avoid long paragraphs in the gallery; do NOT make it look like a features section.

GALLERY ITEM SCHEMA (use this exactly)
Each gallery item MUST look like:
{
  "id": "g1",
  "type": "image",
  "title": "Admin Panel",
  "text": "Pages, uploads, audit trail.",
  "imgQuery": "admin panel dashboard ui dark theme",
  "needsImage": true,
  "imageUrl": "",
  "thumbUrl": "",
}

NOTES:
- imageUrl/thumbUrl can be empty at planning time; the system will fill them later from imgQuery.
- If a thumbnail exists, thumbUrl should point to it; imageUrl should point to the full image.
- The gallery rail should be primarily visual. Captions are optional and must be short.

DESIGN INTENT
- Gallery section = image-first browsing (tiles, click opens lightbox).
- If you need explanatory content, put it in separate sections (richtext/features/cta) OUTSIDE the gallery.
- Do NOT place "card" items inside the gallery section unless explicitly requested (default: none).

PAGE STRUCTURE (recommended)
- hero (clear title + one sentence)
- gallery (the rail of image tiles; 6–9 items)
- richtext or testimonials (optional, short)
- cta (contact / request demo)

TONE
- Enterprise AI product showcase, clean and concise.
"""


SMXAI_CAREERS_PAGE_INSTRUCTIONS = """
You are generating a CAREERS page
## HERO SLIMNESS OVERRIDE (MANDATORY)
- The Hero banner must contain ONLY:
  1) Hero title (headline)
  2) Exactly ONE sentence tagline directly underneath
- Do NOT include CTAs/buttons/links in the Hero.
- Do NOT include any paragraphs, bullets, cards, lists, “kicker” lines, or secondary sub-headings in the Hero.
- Tagline limits (strict):
  - ONE sentence only
  - <= 22 words
  - <= 140 characters
  - no line breaks
- Any content that would normally go in the Hero MUST be moved into the first section after Hero:
  "Introduction — Company + Product Positioning (Below Hero)"

GOAL
Create a careers landing page that:
- communicates mission + culture clearly
- lists open roles in a structured way
- explains hiring process and expectations
- provides a clear application CTA
- stays concise, skimmable, and professional (enterprise AI company tone)

ABSOLUTE REQUIREMENTS
1) The plan MUST include a hero section (type: "hero") with:
   - a clear headline about careers at SyntaxMatrix
   - a ONE-sentence tagline (exactly ONE sentence) that communicates mission and what candidates can expect
   - a primary CTA such as "Apply now" / "Email your CV" (emit heroCta1Label/heroCta1Href)
   - optional secondary CTA "View open roles" (emit heroCta2Label/heroCta2Href)
   - Hrefs MUST NOT be "/admin".

2) The plan MUST include an "Open Roles" section.
   Use either:
   - type: "features" (recommended), OR
   - type: "richtext" if you need richer formatting.
   Each role must be presented as a compact card-like entry with:
   - Role Title
   - Location/Remote (e.g., Ireland / Remote / Hybrid Dublin)
   - Type (Full-time / Contract / Internship)
   - Short summary (max 2 sentences)
   - Key skills (4–6 bullet-style phrases)
   - An "Apply" callout (email or link placeholder)

3) The plan MUST include a hiring process section that is clear and realistic.
   Use type: "richtext" or "features" with 4–6 steps:
   - Apply
   - Screening
   - Technical assessment (practical, small)
   - Interview(s)
   - Offer
   - Onboarding

4) The plan MUST include a FAQ section (type: "faq") with at least 6 FAQs:
   Include: remote policy, visa sponsorship (if unknown say “case-by-case”), interview steps,
   expected stack, timeline, compensation transparency approach, and what makes a strong application.

5) The plan MUST include a final CTA section (type: "cta") with:
   - a direct instruction to apply (email/link placeholder)
   - what to include (CV, links, short note, portfolio/GitHub)
   - response time expectation (e.g., “we aim to respond within X business days”)

CONTENT CONSTRAINTS
- Do NOT invent named employees or fake testimonials.
- Do NOT claim benefits you cannot guarantee (health insurance, pension, etc.). If unsure, phrase as “where applicable” or omit.
- Avoid exaggerated claims. Keep language grounded and specific.
- Avoid long paragraphs. Prefer short blocks, lists, and scannable structure.
- Keep total page copy “tight”: aim for clarity over volume.

STYLE
- Enterprise AI engineering vibe: confident, precise, practical.
- Emphasise that SyntaxMatrix is an AI algorithm design company and a framework builder (RAG systems, multi-agent workflows, evaluation, deployments).
- Mention core tech themes appropriately: Python, Flask, Dash, vector stores, RAG, eval tooling, cloud deployments, MLOps. Do not overspecify if not necessary.

RECOMMENDED PAGE STRUCTURE (sections)
1) hero
2) richtext: "Why work with us" (mission, values, what you’ll build)
3) features: "Open roles" (6–10 role cards max; if fewer roles, show 3–6)
4) richtext/features: "Hiring process"
5) faq
6) cta

OPEN ROLES (DEFAULT SET)
If no specific roles were provided, include a sensible starter list (edit titles to fit page length):
- AI/ML Engineer (RAG + agents)
- Full-stack Engineer (Flask/Dash + UI)
- MLOps / Platform Engineer (deployments, CI/CD)
- Technical Writer / Developer Advocate (docs, examples, workshops)
- Intern / Graduate (AI Engineering)

ROLE CARD TEMPLATE (features item shape)
Each role in the "Open roles" section should be an item like:
{
  "id": "role_1",
  "type": "card",
  "title": "AI/ML Engineer (RAG + Agents)",
  "text": "Build production RAG pipelines and deterministic multi-agent workflows. Remote/Hybrid • Full-time/Contract.\nSkills: Python, vector search, evaluation, prompt/tool orchestration, deployments.\nApply: careers@<your-domain> (placeholder)"
}

FAQ SUGGESTED QUESTIONS (use or adapt)
- Do you offer remote work?
- What does the interview process look like?
- What tech stack do you use day-to-day?
- Do you sponsor visas?
- What should I include in my application?
- How quickly will I hear back?
- Can I apply if I’m early-career?
- Do you take contractors?

FINAL CTA COPY REQUIREMENTS
Include:
- email placeholder and/or application link placeholder
- request: CV + links (GitHub/LinkedIn/portfolio) + short note
- note: “If you’ve built RAG systems, agent workflows, or evaluation tooling, include a brief write-up.”

OUTPUT QUALITY CHECK
Before finalising, ensure:
- "Open roles" exists and is clearly labelled.
- Hiring process is present and actionable.
- FAQ has 6+ items.
- CTA is explicit and contains application instructions.
"""


SMXAI_BLOG_PAGE_INSTRUCTIONS = """
## 3.1 Blog index page structure
1) Hero  
2) Featured post  
3) Post grid  
4) Tag filter + search  
5) CTA (optional newsletter)

## HERO SLIMNESS OVERRIDE (MANDATORY)
- The Hero banner must contain ONLY:
  1) Hero title (headline)
  2) Exactly ONE sentence tagline directly underneath
- Do NOT include CTAs/buttons/links in the Hero.
- Do NOT include any paragraphs, bullets, cards, lists, “kicker” lines, or secondary sub-headings in the Hero.
- Tagline limits (strict):
  - ONE sentence only
  - <= 22 words
  - <= 140 characters
  - no line breaks
- Any content that would normally go in the Hero MUST be moved into the first section after Hero:
  "Introduction — Company + Product Positioning (Below Hero)"

Post cards:
- Title (2 lines)
- Excerpt (2–3 lines)
- Date + tag
- “Read more”

## 3.2 Blog post page structure
- Title + metadata
- Optional TOC from H2/H3
- Body with callouts
- CTA footer

---

# 4) Matching rules (template selection)

- “services”, “solutions”, “packages”, “pricing”, “engagement”
  → Services Page

- “gallery”, “photos”, “portfolio”, “screenshots”, “showcase”
  → Gallery Page (horizontal + lightbox)

- “blog”, “articles”, “updates”, “news”, “release notes”
  → Blog Page

"""


SMXAI_KNOWLEDGEBASE_PAGE_INSTRUCTIONS = f"""
You are generating a Knowledgebase / Documentation index page using the Page Plan JSON Schema (already provided in the system message).

WEBSITE DESCRIPTION:
{SMXAI_WEBSITE_DESCRIPTION}

## HERO (SLIM)
- Title + EXACTLY one sentence tagline + CTAs only.
- Emit heroCta1Label/heroCta1Href and heroCta2Label/heroCta2Href.
- Hrefs MUST NOT be "/admin".

## HERO SLIMNESS OVERRIDE (MANDATORY)
- The Hero banner must contain ONLY:
  1) Hero title (headline)
  2) Exactly ONE sentence tagline directly underneath
- Do NOT include CTAs/buttons/links in the Hero.
- Do NOT include any paragraphs, bullets, cards, lists, “kicker” lines, or secondary sub-headings in the Hero.
- Tagline limits (strict):
  - ONE sentence only
  - <= 22 words
  - <= 140 characters
  - no line breaks
- Any content that would normally go in the Hero MUST be moved into the first section after Hero:
  "Introduction — Company + Product Positioning (Below Hero)"

## PAGE GOAL
Build a clean, technical documentation hub for SyntaxMatrix/smxPP: categories, featured guides, getting started, and a clear route into deeper articles.

## REQUIRED SECTIONS (7–9)
1) hero (needsImage true, imgQuery about documentation hub)
2) richtext: Introduction (below hero) explaining what readers will find
3) cards: Documentation Categories (5–8 categories, each with title + 2–3 sentences)
4) cards: Getting Started (3–5 guides)
5) cards: Core Concepts / Architecture (3–6 articles)
6) richtext: How to Use the Knowledgebase (search, navigation, versioning)
7) faq: common documentation questions
8) cta: "Need help?" (support/contact)

Images:
- Ensure at least 4 sections/items have needsImage true with non-empty imgQuery.
"""


SMXAI_KB_ARTICLE_PAGE_INSTRUCTIONS = f"""
You are generating a Knowledgebase article page using the Page Plan JSON Schema (already provided in the system message).

WEBSITE DESCRIPTION:
{SMXAI_WEBSITE_DESCRIPTION}

## HERO (SLIM)
- Title + EXACTLY one sentence tagline + CTAs only.
- Emit heroCta1Label/heroCta1Href and heroCta2Label/heroCta2Href.
- Hrefs MUST NOT be "/admin".

## HERO SLIMNESS OVERRIDE (MANDATORY)
- The Hero banner must contain ONLY:
  1) Hero title (headline)
  2) Exactly ONE sentence tagline directly underneath
- Do NOT include CTAs/buttons/links in the Hero.
- Do NOT include any paragraphs, bullets, cards, lists, “kicker” lines, or secondary sub-headings in the Hero.
- Tagline limits (strict):
  - ONE sentence only
  - <= 22 words
  - <= 140 characters
  - no line breaks
- Any content that would normally go in the Hero MUST be moved into the first section after Hero:
  "Introduction — Company + Product Positioning (Below Hero)"

## ARTICLE STRUCTURE (7–9 SECTIONS)
1) hero
2) richtext: Introduction (below hero) (2–3 paragraphs)
3) richtext: Prerequisites (short)
4) richtext: Step-by-step (detailed, technical)
5) cards: Common Pitfalls / Troubleshooting
6) faq
7) cta: "Was this helpful?" + next steps

Images:
- Ensure at least 4 sections/items have needsImage true with non-empty imgQuery.
"""


SMXAI_NEW_PAGE_INSTRUCTIONS_DEFAULT = f"""
You are generating a page using the Page Plan JSON Schema (already provided in the system message).

WEBSITE DESCRIPTION (read first, then follow it):
{SMXAI_WEBSITE_DESCRIPTION}

## GLOBAL CONTENT RULES (NON-NEGOTIABLE)
- The Hero banner MUST contain ONLY:
  - a clear headline (title)
  - ONE sentence tagline directly under the title (exactly one sentence)
  - CTAs (buttons/links)
- The Hero banner MUST NOT contain paragraphs, bullet lists, or cards.
- All explanatory prose MUST be placed in a dedicated section immediately AFTER the Hero.

- Each major section OTHER than the Hero must include 2–3 full paragraphs minimum.
- Each paragraph must be 4–6 complete sentences.
- Prose explanations MUST come before cards or bullets.
- Cards/bullets may ONLY summarise after prose.

## HERO SLIMNESS OVERRIDE (MANDATORY)
- The Hero banner must contain ONLY:
  1) Hero title (headline)
  2) Exactly ONE sentence tagline directly underneath
- Do NOT include CTAs/buttons/links in the Hero.
- Do NOT include any paragraphs, bullets, cards, lists, “kicker” lines, or secondary sub-headings in the Hero.
- Tagline limits (strict):
  - ONE sentence only
  - <= 22 words
  - <= 140 characters
  - no line breaks
- Any content that would normally go in the Hero MUST be moved into the first section after Hero:
  "Introduction — Company + Product Positioning (Below Hero)"

## REQUIRED OUTPUT
Return a JSON page plan that:
- uses 7–9 sections
- includes at least 4 sections/items with needsImage: true AND a non-empty imgQuery
- includes a hero section (type: "hero") plus a post-hero "Introduction" section (type: "richtext")
- includes a final CTA section (type: "cta") with clear next steps

## HERO CTA FIELDS (MANDATORY)
In the hero section JSON, you MUST emit CTA fields explicitly:
- heroCta1Label, heroCta1Href
- heroCta2Label, heroCta2Href
Hrefs MUST NOT be "/admin".

## STRUCTURE SUGGESTION (ADAPT TO page_title)
1) Hero (slim)
2) Introduction (below hero)
3) Problem / Context
4) Solution / Approach
5) Capabilities / Features (cards)
6) Proof (case study, metrics, or "how it works")
7) FAQ
8) CTA
"""


def get_page_instructions(page_slug: str = "", page_title: str = "") -> str:
    """Return the best instruction template for the given page slug/title."""
    key = f"{page_slug or ''} {page_title or ''}".strip().lower()

    # Treat empty/placeholder titles as home.
    if key in {"", "page", "index", "home", "homepage", "root", "frontpage", "front page"}:
        return SMXAI_LANDING_PAGE_INSTRUCTIONS

    # Knowledgebase / docs (index vs article)
    if any(w in key for w in (
        "knowledgebase", "knowledge base", "knowledge-base", "kb", "documentation", "docs", "doc", "manual", "guide", "guides"
    )):
        if any(w in key for w in ("how to", "how-to", "tutorial", "walkthrough", "article", "guide:")):
            return SMXAI_KB_ARTICLE_PAGE_INSTRUCTIONS
        return SMXAI_KNOWLEDGEBASE_PAGE_INSTRUCTIONS

    # Landing/Home
    if any(w in key for w in ("landing", "landing-page", "home", "home-page", "homepage", "main")):
        return SMXAI_LANDING_PAGE_INSTRUCTIONS

    # About
    if any(w in key for w in ("about", "about-us", "who-we-are", "company", "our-story", "team", "mission", "vision")):
        return SMXAI_ABOUT_PAGE_INSTRUCTIONS

    # Services / Pricing
    if any(w in key for w in ("services", "service", "solutions", "solution", "offerings", "packages", "pricing", "plans", "engagement")):
        return SMXAI_SERVICES_PAGE_INSTRUCTIONS

    # Gallery
    if any(w in key for w in ("gallery", "photos", "portfolio", "screenshots", "showcase", "case studies", "use cases", "demos")):
        return SMXAI_GALLERY_PAGE_INSTRUCTIONS

    # Careers
    if any(w in key for w in ("careers", "career", "jobs", "job", "hiring", "join", "join-us", "work with us", "open roles")):
        return SMXAI_CAREERS_PAGE_INSTRUCTIONS

    # Blog
    if any(w in key for w in ("blog", "articles", "updates", "news", "release-notes", "posts", "insights")):
        return SMXAI_BLOG_PAGE_INSTRUCTIONS

    return SMXAI_NEW_PAGE_INSTRUCTIONS_DEFAULT


