from __future__ import annotations

import hashlib
import io
import os
import re
from typing import Any, Dict, List, Optional, Tuple
import requests
from bs4 import BeautifulSoup
from PIL import Image


PIXABAY_API_URL = "https://pixabay.com/api/"

# ─────────────────────────────────────────────────────────
# Icons (inline SVG)
# ─────────────────────────────────────────────────────────
_ICON_SVGS: Dict[str, str] = {
    "spark": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">'
             '<path d="M12 2l1.2 6.2L20 12l-6.8 3.8L12 22l-1.2-6.2L4 12l6.8-3.8L12 2z"/></svg>',
    "shield": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">'
              '<path d="M12 2l7 4v6c0 5-3.5 9-7 10-3.5-1-7-5-7-10V6l7-4z"/></svg>',
    "stack": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">'
             '<path d="M12 2l9 5-9 5-9-5 9-5z"/><path d="M3 12l9 5 9-5"/><path d="M3 17l9 5 9-5"/></svg>',
    "chart": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">'
             '<path d="M3 3v18h18"/><path d="M7 14v4"/><path d="M12 10v8"/><path d="M17 6v12"/></svg>',
    "rocket": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">'
              '<path d="M5 13l4 6 6-4c6-4 5-12 5-12S13 2 9 8l-4 5z"/><path d="M9 8l7 7"/>'
              '<path d="M5 13l-2 2"/><path d="M11 19l-2 2"/></svg>',
    "plug": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">'
            '<path d="M9 2v6"/><path d="M15 2v6"/><path d="M7 8h10"/>'
            '<path d="M12 8v7a4 4 0 0 1-4 4H7"/><path d="M12 8v7a4 4 0 0 0 4 4h1"/></svg>',
    "arrow": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">'
             '<path d="M5 12h12"/><path d="M13 6l6 6-6 6"/></svg>',
}


def _slug_title(slug: str) -> str:
    s = (slug or "").strip().replace("_", " ").replace("-", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return (s[:1].upper() + s[1:]) if s else "New page"


def _short_site_desc(desc: str, limit: int = 220) -> str:
    d = (desc or "").strip()
    if not d:
        return ""
    d = re.sub(r"\s+", " ", d).strip()
    if len(d) <= limit:
        return d
    cut = d[:limit]
    # cut at end of sentence if possible
    m = re.search(r"[.!?]\s", cut)
    if m:
        return cut[:m.end()].strip()
    return cut.rstrip() + "…"


def _page_kind(slug: str) -> str:
    s = (slug or "").lower()
    if any(k in s for k in ["service", "services", "solutions", "what-we-do"]):
        return "services"
    if "about" in s or "company" in s:
        return "about"
    if "pricing" in s or "plans" in s:
        return "pricing"
    if "contact" in s or "get-in-touch" in s:
        return "contact"
    if "docs" in s or "documentation" in s:
        return "docs"
    return "generic"


def build_layout_for_page(page_slug: str, website_description: str) -> Dict[str, Any]:
    """
    Returns builder layout JSON with non-placeholder copy that fits the page title.
    Includes optional `imgQuery` fields which we can use to fetch Pixabay images.
    """
    slug = (page_slug or "page").strip().lower()
    title = _slug_title(slug)
    kind = _page_kind(slug)
    site_blurb = _short_site_desc(website_description)

    def sec(_id: str, _type: str, title_: str, text: str, cols: int, items: List[Dict[str, Any]]):
        return {"id": _id, "type": _type, "title": title_, "text": text, "cols": cols, "items": items or []}

    def item(_id: str, _type: str, title_: str, text: str, icon: str = "", img_query: str = ""):
        out = {"id": _id, "type": _type, "title": title_, "text": text, "imageUrl": ""}
        if icon:
            out["icon"] = icon
        if img_query:
            out["imgQuery"] = img_query
        return out

    # Some SyntaxMatrix-aware phrasing (works fine for other clients too)
    if kind == "services":
        hero_text = (
            "Practical AI engineering services: retrieval systems, data workflows, and deployable web UI components."
            if not site_blurb else site_blurb
        )
        return {
            "page": slug,
            "sections": [
                sec(
                    "sec_hero",
                    "hero",
                    title,
                    hero_text,
                    1,
                    [
                        item(
                            "item_hero_img",
                            "card",
                            "Build faster with confidence",
                            "From strategy to deployment, we ship production-grade features with clean, maintainable code.",
                            "rocket",
                            "ai dashboard software team",
                        ),
                    ],
                ),
                sec(
                    "sec_services",
                    "features",
                    "What we can deliver",
                    "Core capabilities tailored to your organisation and your users.",
                    3,
                    [
                        item("svc_1", "card", "RAG systems & search", "Chunking, embeddings, vector stores, and evaluation.", "stack", "vector database ai search"),
                        item("svc_2", "card", "AI assistants in your app", "Streaming chat, tools, history, and guardrails.", "spark", "chatbot interface ai assistant"),
                        item("svc_3", "card", "Admin panel & content ops", "Page management, media handling, audit trails.", "shield", "admin dashboard web app"),
                        item("svc_4", "card", "ML lab & analytics", "EDA, modelling, visualisations, downloadable results.", "chart", "data analytics dashboard charts"),
                        item("svc_5", "card", "Integrations", "SQL databases, storage buckets, PDFs, CSV, APIs.", "plug", "software integration api"),
                        item("svc_6", "card", "Deployment support", "Docker, Gunicorn, GCP Cloud Run patterns.", "rocket", "cloud deployment devops"),
                    ],
                ),
                sec(
                    "sec_process",
                    "features",
                    "How we work",
                    "A simple process that keeps delivery predictable.",
                    3,
                    [
                        item("step_1", "card", "Scope", "Clarify outcomes, constraints, and success checks.", "spark", ""),
                        item("step_2", "card", "Build", "Implement in small milestones with review points.", "stack", ""),
                        item("step_3", "card", "Ship", "Deploy and document so your team can operate it.", "rocket", ""),
                    ],
                ),
                sec(
                    "sec_gallery",
                    "gallery",
                    "In action",
                    "A few visuals that match the theme of this page.",
                    3,
                    [
                        item("gal_1", "card", "Product UI", "Example UI visual.", "", "modern web app interface"),
                        item("gal_2", "card", "Data work", "Example analytics visual.", "", "data visualisation charts"),
                        item("gal_3", "card", "Team", "Example team visual.", "", "software team working"),
                    ],
                ),
                sec(
                    "sec_faq",
                    "faq",
                    "FAQ",
                    "Common questions we get before starting.",
                    2,
                    [
                        item("faq_1", "faq", "Do you work with existing systems?", "Yes. We can integrate with your current stack and data sources.", "", ""),
                        item("faq_2", "faq", "Can we start small?", "Yes. We can begin with one page/module and scale from there.", "", ""),
                    ],
                ),
                sec(
                    "sec_cta",
                    "cta",
                    "Ready to start?",
                    "Tell us what you want this page or feature to achieve, and we'll propose the quickest path.",
                    2,
                    [
                        item("cta_1", "card", "Book a demo", "See a working flow end-to-end.", "arrow", ""),
                        item("cta_2", "card", "Contact us", "Share requirements and timelines.", "arrow", ""),
                    ],
                ),
            ],
        }

    # Generic page (still modern copy)
    hero_text = site_blurb or "A modern page generated from your website description and the page title."
    return {
        "page": slug,
        "sections": [
            sec("sec_hero", "hero", title, hero_text, 1, [
                item("item_hero_img", "card", "A clear headline that matches the page", "Add a short, action-focused summary here.", "spark", f"{title} hero background"),
            ]),
            sec("sec_features", "features", "Highlights", "Three to six key points for this page topic.", 3, [
                item("f1", "card", "Clear value", "Explain the benefit in one sentence.", "spark", f"{title} concept"),
                item("f2", "card", "Trust signals", "Show proof, experience, or credibility.", "shield", f"{title} professional"),
                item("f3", "card", "Next step", "Give people a simple action to take.", "arrow", f"{title} call to action"),
            ]),
            sec("sec_gallery", "gallery", "Gallery", "Relevant imagery for the topic.", 3, [
                item("g1", "card", "Image", "Drop or auto-fetch an image.", "", f"{title} abstract"),
                item("g2", "card", "Image", "Drop or auto-fetch an image.", "", f"{title} modern"),
                item("g3", "card", "Image", "Drop or auto-fetch an image.", "", f"{title} business"),
            ]),
            sec("sec_cta", "cta", "Continue", "A short call-to-action to guide the user.", 2, [
                item("c1", "card", "Get started", "Tell people what to do next.", "arrow", ""),
                item("c2", "card", "Learn more", "Point to documentation or contact.", "arrow", ""),
            ]),
        ],
    }


# ─────────────────────────────────────────────────────────
# Pixabay: search + download once + resize
# ─────────────────────────────────────────────────────────
def _is_pixabay_url(url: str) -> bool:
    u = (url or "").strip().lower()
    return u.startswith("https://") and ("pixabay.com" in u)


def _fetch_bytes(url: str, timeout: int = 20) -> bytes:
    if not _is_pixabay_url(url):
        raise ValueError("Only Pixabay URLs are allowed")
    r = requests.get(url, stream=True, timeout=timeout)
    r.raise_for_status()
    return r.content


def _save_image_bytes(img_bytes: bytes, out_path_no_ext: str, max_width: int = 1920) -> Tuple[str, int, int]:
    img = Image.open(io.BytesIO(img_bytes))
    img.load()

    if img.width > int(max_width or 1920):
        ratio = (int(max_width) / float(img.width))
        new_h = max(1, int(round(img.height * ratio)))
        img = img.resize((int(max_width), new_h), Image.LANCZOS)

    has_alpha = ("A" in img.getbands())
    ext = ".png" if has_alpha else ".jpg"
    out_path = out_path_no_ext + ext
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    if ext == ".jpg":
        rgb = img.convert("RGB") if img.mode != "RGB" else img
        rgb.save(out_path, "JPEG", quality=85, optimise=True, progressive=True)
    else:
        img.save(out_path, "PNG", optimise=True)

    return out_path, int(img.width), int(img.height)


def _pixabay_search(api_key: str, query: str, *, per_page: int = 12, timeout: int = 15) -> List[Dict[str, Any]]:
    if not api_key:
        return []
    q = (query or "").strip()
    q = re.sub(r"\s+", " ", q)[:100]
    if not q:
        return []

    params = {
        "key": api_key,
        "q": q,
        "image_type": "photo",
        "orientation": "horizontal",
        "safesearch": "true",
        "editors_choice": "true",
        "order": "popular",
        "per_page": max(3, min(200, int(per_page or 12))),
        "page": 1,
    }
    r = requests.get(PIXABAY_API_URL, params=params, timeout=timeout)
    r.raise_for_status()
    data = r.json() or {}
    return data.get("hits") or []


def fill_layout_images_from_pixabay(
    layout: Dict[str, Any],
    *,
    api_key: str,
    client_dir: str,
    max_width: int = 1920,
    max_downloads: int = 8,
) -> Dict[str, Any]:
    """
    Mutates/returns layout: fills `imageUrl` fields by downloading images into:
      uploads/media/images/imported/
    Uses `imgQuery` if present.
    """
    if not api_key or not layout:
        return layout

    imported_dir = os.path.join(client_dir, "uploads", "media", "images", "imported")
    os.makedirs(imported_dir, exist_ok=True)

    used_ids = set()
    downloads = 0

    sections = layout.get("sections") if isinstance(layout.get("sections"), list) else []
    for s in sections:
        if downloads >= max_downloads:
            break
        items = s.get("items") if isinstance(s.get("items"), list) else []
        for it in items:
            if downloads >= max_downloads:
                break
            if (it.get("imageUrl") or "").strip():
                continue

            q = (it.get("imgQuery") or "").strip()
            if not q:
                continue

            hits = _pixabay_search(api_key, q)
            if not hits:
                continue

            # choose first unused hit
            chosen = None
            for h in hits:
                pid = int(h.get("id") or 0)
                if pid and pid not in used_ids:
                    chosen = h
                    break
            if not chosen:
                continue

            pid = int(chosen.get("id") or 0)
            used_ids.add(pid)

            web_u = str(chosen.get("webformatURL") or "").strip()
            large_u = str(chosen.get("largeImageURL") or "").strip()

            if not web_u:
                continue

            base = os.path.join(imported_dir, f"pixabay-{pid}")
            # download-once
            existing = None
            for ext in (".jpg", ".png"):
                p = base + ext
                if os.path.exists(p):
                    existing = p
                    break

            if existing:
                rel = os.path.relpath(existing, os.path.join(client_dir, "uploads", "media")).replace("\\", "/")
                it["imageUrl"] = f"/uploads/media/{rel}"
                continue

            # fetch webformat first; if it’s small and large exists, use the larger one
            try:
                b1 = _fetch_bytes(web_u)
                img1 = Image.open(io.BytesIO(b1))
                img1.load()
                chosen_bytes = b1

                if large_u:
                    try:
                        b2 = _fetch_bytes(large_u)
                        img2 = Image.open(io.BytesIO(b2))
                        img2.load()
                        if img2.width > img1.width:
                            chosen_bytes = b2
                    except Exception:
                        pass

                saved_path, _, _ = _save_image_bytes(chosen_bytes, base, max_width=max_width)
                rel = os.path.relpath(saved_path, os.path.join(client_dir, "uploads", "media")).replace("\\", "/")
                it["imageUrl"] = f"/uploads/media/{rel}"
                downloads += 1
            except Exception:
                continue

    return layout

def _make_thumb(full_path: str, thumb_path: str, max_w: int = 640, max_h: int = 420) -> bool:
    """
    Create a JPEG/PNG thumbnail that fits within max_w x max_h, preserving aspect ratio.
    Returns True if created.
    """
    try:
        os.makedirs(os.path.dirname(thumb_path), exist_ok=True)
        with Image.open(full_path) as im:
            im = im.convert("RGB") if im.mode in ("P", "RGBA") else im
            im.thumbnail((max_w, max_h))
            im.save(thumb_path, quality=82, optimize=True)
        return True
    except Exception:
        return False


def _extract_hero_image_url_from_layout(layout: Dict[str, Any]) -> str:
    """Find hero image URL from the saved layout JSON (builder)."""
    sections = layout.get("sections") if isinstance(layout.get("sections"), list) else []
    for s in sections:
        if not isinstance(s, dict):
            continue
        if (s.get("type") or "").lower() != "hero":
            continue

        img_url = (s.get("imageUrl") or "").strip()
        if img_url:
            return img_url

        items = s.get("items") if isinstance(s.get("items"), list) else []
        if items and isinstance(items[0], dict):
            img_url = (items[0].get("imageUrl") or "").strip()
            if img_url:
                return img_url

    return ""


def patch_first_background_image(html: str, new_url: str) -> str:
    """
    Patch ONLY the first background-image/background url(...) found in the existing HTML.
    This avoids regenerating HTML/CSS (which is what is changing your fonts/colours).
    """
    if not html or not new_url:
        return html

    # 1) background-image: url(...)
    pat1 = re.compile(r'background-image\s*:\s*url\((["\']?)[^)]*\1\)', re.IGNORECASE)
    out, n = pat1.subn(f'background-image:url("{new_url}")', html, count=1)
    if n:
        return out

    # 2) background: ... url(...)
    pat2 = re.compile(r'(background\s*:\s*[^;]*url\((["\']?))([^)]+)(\2\))', re.IGNORECASE)
    def _repl(m: re.Match) -> str:
        return m.group(1) + new_url + m.group(4)

    out, n = pat2.subn(_repl, html, count=1)
    if n:
        return out

    # 3) If nothing matched, inject a tiny override (best-effort)
    inject = (
        f'<style id="smx-hero-bg-override">'
        f'.hero-bg{{background-image:url("{new_url}") !important;}}'
        f'.hero{{background-image:url("{new_url}") !important;}}'
        f'</style>'
    )
    if "</head>" in html:
        return html.replace("</head>", inject + "</head>", 1)
    return inject + html


def _set_text(node, new_text: str) -> bool:
    if not node:
        return False
    new_text = (new_text or "").strip()
    if not new_text:
        return False
    node.clear()
    node.append(new_text)
    return True


def _html_escape(s: str) -> str:
    s = s or ""
    return (
        s.replace("&", "&amp;")
         .replace("<", "&lt;")
         .replace(">", "&gt;")
         .replace('"', "&quot;")
         .replace("'", "&#39;")
    )


def patch_section_titles_and_intros(existing_html: str, layout: Dict[str, Any]) -> str:
    """
    Patch ONLY section <h2> titles + the first <p> intro under each <h2>,
    across the whole page, matching sections BY ORDER.
    Does NOT regenerate HTML/CSS.
    """
    if not existing_html or not isinstance(layout, dict):
        return existing_html

    sections = layout.get("sections") if isinstance(layout.get("sections"), list) else []
    layout_non_hero = [
        s for s in sections
        if isinstance(s, dict) and (s.get("type") or "").lower() != "hero"
    ]
    if not layout_non_hero:
        return existing_html

    # Split into <section> blocks (non-greedy)
    sec_pat = re.compile(r"(<section\b[^>]*>)(.*?)(</section>)", re.IGNORECASE | re.DOTALL)
    blocks = list(sec_pat.finditer(existing_html))
    if not blocks:
        return existing_html

    out_parts = []
    last_end = 0
    nonhero_index = 0

    for m in blocks:
        open_tag = m.group(1)
        inner = m.group(2)
        close_tag = m.group(3)

        # Keep everything before this section unchanged
        out_parts.append(existing_html[last_end:m.start()])
        last_end = m.end()

        # Skip hero sections (don’t count them against non-hero layout sections)
        if "hero" in open_tag.lower():
            out_parts.append(open_tag + inner + close_tag)
            continue

        if nonhero_index >= len(layout_non_hero):
            out_parts.append(open_tag + inner + close_tag)
            continue

        s = layout_non_hero[nonhero_index]
        nonhero_index += 1

        new_title = (s.get("title") or "").strip()
        new_text = (s.get("text") or "").strip()

        patched_inner = inner

        # 1) Patch first <h2> inside this section
        if new_title:
            h2_pat = re.compile(r"(<h2\b[^>]*>)(.*?)(</h2>)", re.IGNORECASE | re.DOTALL)
            patched_inner, n_h2 = h2_pat.subn(
                lambda mm: mm.group(1) + _html_escape(new_title) + mm.group(3),
                patched_inner,
                count=1
            )

        # 2) Patch the first <p> AFTER </h2> (section intro)
        if new_text:
            # Only look in the region after the first </h2>, so we don’t edit card paragraphs
            split = re.split(r"(</h2>)", patched_inner, maxsplit=1, flags=re.IGNORECASE)
            if len(split) == 3:
                before_h2 = split[0] + split[1]
                after_h2 = split[2]

                p_pat = re.compile(r"(<p\b[^>]*>)(.*?)(</p>)", re.IGNORECASE | re.DOTALL)
                after_h2, n_p = p_pat.subn(
                    lambda mm: mm.group(1) + _html_escape(new_text) + mm.group(3),
                    after_h2,
                    count=1
                )

                patched_inner = before_h2 + after_h2

        out_parts.append(open_tag + patched_inner + close_tag)

    # Append trailing HTML after the last section
    out_parts.append(existing_html[last_end:])
    return "".join(out_parts)


def patch_page_from_layout(existing_html: str, layout: Dict[str, Any]) -> str:
    """
    Patch ONLY text/image values in the existing HTML using the builder layout JSON.
    Does NOT regenerate HTML/CSS, so it won’t change fonts/palette/structure.
    """
    if not existing_html or not isinstance(layout, dict):
        return existing_html

    soup = BeautifulSoup(existing_html, "html.parser")

    sections = layout.get("sections") if isinstance(layout.get("sections"), list) else []

    # ---------- HERO ----------
    hero_layout = None
    for s in sections:
        if isinstance(s, dict) and (s.get("type") or "").lower() == "hero":
            hero_layout = s
            break

    if hero_layout:
        hero_title = (hero_layout.get("title") or "").strip()
        hero_text = (hero_layout.get("text") or "").strip()
        hero_img = (hero_layout.get("imageUrl") or "").strip()

        # Prefer patching hero background first (your existing logic)
        if hero_img:
            from syntaxmatrix.page_builder_generation import patch_first_background_image
            existing_html = patch_first_background_image(str(soup), hero_img)
            soup = BeautifulSoup(existing_html, "html.parser")

        # Patch hero headline + hero paragraph (without changing structure)
        h1 = soup.find("h1")
        if hero_title and h1:
            _set_text(h1, hero_title)

        # Find the first <p> after the <h1> within the same container
        if hero_text and h1:
            p = None
            for sib in h1.find_all_next(["p"], limit=6):
                # ignore very short “kicker” lines
                txt = sib.get_text(" ", strip=True)
                if len(txt) >= 25:
                    p = sib
                    break
            if p:
                _set_text(p, hero_text)

    # ---------- OTHER SECTIONS (titles + intro text only) ----------
    layout_non_hero = [s for s in sections if isinstance(s, dict) and (s.get("type") or "").lower() != "hero"]

    # Collect candidate section headings in the existing HTML
    headings = []
    for h in soup.find_all(["h2", "h3"]):
        if h.find_parent(["header", "nav", "footer"]) is not None:
            continue
        if not h.get_text(strip=True):
            continue
        headings.append(h)

    for i, s in enumerate(layout_non_hero):
        if i >= len(headings):
            break

        title = (s.get("title") or "").strip()
        text = (s.get("text") or "").strip()

        h = headings[i]
        if title:
            _set_text(h, title)

        if text:
            # patch the first <p> after this heading (within the same section container)
            p = None
            for sib in h.find_all_next(["p"], limit=8):
                if sib.find_parent(["header", "nav", "footer"]) is not None:
                    continue
                # stop if we hit the next heading before finding a paragraph
                if sib.find_previous(["h2", "h3"]) is not h:
                    break
                p = sib
                break
            if p:
                _set_text(p, text)

    return str(soup)


def _css_safe_hex(c: str) -> str:
    c = (c or "").strip()
    m = re.fullmatch(r"#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})", c)
    if not m:
        return ""
    hx = m.group(0).lower()
    if len(hx) == 4:
        hx = "#" + "".join([ch * 2 for ch in hx[1:]])
    return hx


def _hex_to_rgba(hx: str, a: float) -> str:
    hx = _css_safe_hex(hx)
    if not hx:
        return ""
    r = int(hx[1:3], 16)
    g = int(hx[3:5], 16)
    b = int(hx[5:7], 16)
    a = float(a)
    if a < 0:
        a = 0.0
    if a > 1:
        a = 1.0
    return f"rgba({r},{g},{b},{a:.3f})"


def _css_safe_font(ff: str) -> str:
    ff = (ff or "").strip()
    if not ff:
        return ""
    bad = ["{", "}", ";", "<", ">", "\n", "\r"]
    if any(b in ff for b in bad):
        return ""
    return ff


def _theme_style_from_layout(layout: Dict[str, Any]) -> str:
    theme = layout.get("theme") if isinstance(layout.get("theme"), dict) else {}
    if not theme:
        return ""

    font_body = _css_safe_font(theme.get("fontBody") or theme.get("bodyFont") or theme.get("font_body") or "")
    font_head = _css_safe_font(theme.get("fontHeading") or theme.get("headingFont") or theme.get("font_heading") or "")

    accent = _css_safe_hex(theme.get("accent") or "")
    fg = _css_safe_hex(theme.get("fg") or "")
    mut = _css_safe_hex(theme.get("mut") or "")
    bg = _css_safe_hex(theme.get("bg") or "")

    if not any([font_body, font_head, accent, fg, mut, bg]):
        return ""

    lines = []
    lines.append(".smxp{")
    if fg:
        lines.append(f"  --fg:{fg};")
        lines.append("  color:var(--fg);")
    if mut:
        lines.append(f"  --mut:{mut};")
    if bg:
        lines.append(f"  --bg:{bg};")
        lines.append("  background:var(--bg);")
    if font_body:
        lines.append(f"  font-family:{font_body};")
    lines.append("}")

    if font_head:
        lines.append(f".smxp h1,.smxp h2,.smxp h3{{font-family:{font_head};}}")

    if accent:
        soft = _hex_to_rgba(accent, 0.12)
        if soft:
            lines.append(f".smxp .btn{{background:{soft};}}")
        lines.append(f".smxp a{{color:{accent};}}")

    css = "\n".join(lines)
    return f'<style id="smx-theme" data-smx="theme">\\n{css}\\n</style>'

# ─────────────────────────────────────────────────────────
# Compile layout JSON → modern HTML with animations
# ─────────────────────────────────────────────────────────
_ALLOWED_RICH_TAGS = {
    "p", "br", "strong", "b", "em", "i", "u",
    "ul", "ol", "li", "hr",
    "span", "div",
    "a",
}

_ALLOWED_ATTRS = {
    "span": {"style"},
    "div": {"style"},
    "p": {"style"},
    "a": {"href", "target", "rel"},
}

_ALLOWED_STYLE_PROPS = {
    "color",
    "background-color",
    "font-size",
    "font-weight",
    "font-style",
    "text-decoration",
    "text-align",
}

_COLOR_RE = re.compile(r"^(#[0-9a-fA-F]{3,8}|rgb\([^\)]*\)|rgba\([^\)]*\)|hsl\([^\)]*\)|hsla\([^\)]*\))$")
_SIZE_RE = re.compile(r"^\d+(\.\d+)?(px|rem|em|%)$")


def _sanitize_style(style: str) -> str:
    if not style:
        return ""
    out = []
    # split "a:b; c:d"
    for part in style.split(";"):
        if ":" not in part:
            continue
        k, v = part.split(":", 1)
        k = k.strip().lower()
        v = v.strip()
        if k not in _ALLOWED_STYLE_PROPS:
            continue

        if k in ("color", "background-color"):
            if not _COLOR_RE.match(v):
                continue

        if k == "font-size":
            if not _SIZE_RE.match(v):
                continue

        if k == "text-align":
            vv = v.lower()
            if vv not in ("left", "center", "right", "justify"):
                continue
            v = vv

        out.append(f"{k}:{v}")
    return ";".join(out)


def _sanitize_rich_html(html: str) -> str:
    if not html:
        return ""

    soup = BeautifulSoup(html, "html.parser")

    # hard remove scripts/styles
    for bad in soup(["script", "style"]):
        bad.decompose()

    for tag in list(soup.find_all(True)):
        name = (tag.name or "").lower()

        if name not in _ALLOWED_RICH_TAGS:
            tag.unwrap()
            continue

        # strip attrs
        allowed = _ALLOWED_ATTRS.get(name, set())
        attrs = dict(tag.attrs) if tag.attrs else {}
        for a in list(attrs.keys()):
            if a not in allowed:
                tag.attrs.pop(a, None)

        # style sanitise
        if "style" in tag.attrs:
            s = _sanitize_style(tag.get("style") or "")
            if s:
                tag["style"] = s
            else:
                tag.attrs.pop("style", None)

        # link sanitise
        if name == "a":
            href = (tag.get("href") or "").strip()
            low = href.lower()
            if low.startswith("javascript:") or low.startswith("data:"):
                tag.attrs.pop("href", None)
            tag["rel"] = "noopener noreferrer"

            # if target set, ensure it’s safe
            if tag.get("target") and tag.get("target") != "_blank":
                tag.attrs.pop("target", None)

    return str(soup)


def _safe_align(val: str) -> str:
    v = (val or "").strip().lower()
    return v if v in ("left", "center", "right", "justify") else ""


def compile_layout_to_html(layout: Dict[str, Any], *, page_slug: str) -> str:
    page_id = re.sub(r"[^a-z0-9\-]+", "-", (page_slug or "page").lower()).strip("-") or "page"

    css = """
    <style>
        .smxp{
            --r:18px;
            --bd: rgba(148,163,184,.25);
            --fg: #0f172a;
            --mut:#000000;                /* <- darker, readable */
            --card: rgba(255,255,255,.78);
            --bg: #f8fafc;
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
            background: var(--bg);
            overflow-x: clip;
        }
       
        font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; color: var(--fg); }
        @media (prefers-color-scheme: dark){
        .smxp{--fg:#e2e8f0;--card:rgba(2,6,23,.45);--bd:rgba(148,163,184,.18);--mut:#a7b3c6;}
        }
        .smxp a{color:inherit}
        .smxp .wrap{max-width:1120px;margin:0 auto;padding:0 18px}
        .smxp .sec{padding:56px 0}
        .smxp .kicker{color:var(--mut);font-size:.95rem;margin:0 0 8px}
        .smxp h1{font-size:clamp(2rem,3.4vw,3.2rem);line-height:1.08;margin:0 0 12px}
        .smxp h2{font-size:clamp(1.4rem,2.2vw,2rem);margin:0 0 10px}
        .smxp p{margin:0;color:var(--mut);line-height:1.6}
        .smxp .hero{padding:72px 0 46px}
        .smxp .heroGrid{display:grid;grid-template-columns:1.15fr .85fr;gap:18px;align-items:center}
        @media (max-width: 860px){.smxp .heroGrid{grid-template-columns:1fr}}
        .smxp .heroCard{border:1px solid var(--bd);border-radius:var(--r);background:var(--card);padding:14px}
        .smxp .btnRow{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}
        .smxp .btn{display:inline-flex;gap:8px;align-items:center;border-radius:999px;padding:10px 14px;
        border:1px solid var(--bd);text-decoration:none;background:rgba(99,102,241,.12)}
        .smxp .btn:hover{transform:translateY(-1px)}
        .smxp .grid{display:grid;gap:12px}
        /* Mobile: force single-column grids (Page Studio pages only) */
        @media (max-width: 720px){
            .smxp section:not([data-section-type="gallery"]) .grid{
                grid-template-columns: 1fr !important;
            }
        }
        .smxp .card{border:1px solid var(--bd);border-radius:var(--r);background:var(--card);padding:14px;min-width:0}
        .smxp .card h3{
            margin:10px 0 6px;
            font-size:1.05rem;
            line-height:1.25;
            display:-webkit-box;
            -webkit-line-clamp:2;
            -webkit-box-orient:vertical;
            overflow:hidden;
        }
        .smxp .smx-rich{
            margin-top:8px;
            color: var(--mut);
            line-height:1.65;
        }
        .smxp .smx-rich p{margin:0 0 10px}
        .smxp .smx-rich ul, .smxp .smx-rich ol{margin:0 0 10px 22px}
        .smxp .smx-rich hr{
            border:0;
            border-top:1px solid var(--bd);
            margin:14px 0;
        }
        .smxp .card p{
            white-space: pre-wrap;     /* ✅ preserve new lines */
            overflow-wrap: anywhere;
        }
        .smxp .icon{width:20px;height:20px;opacity:.9}
        .smxp img{width:100%;height:auto;border-radius:calc(var(--r) - 6px);display:block}
        .smxp .reveal{opacity:0;transform:translateY(14px);transition:opacity .55s ease, transform .55s ease}
        .smxp .reveal.in{opacity:1;transform:none}

        .smxp .hero{ padding:0; }
        /* Slim hero: keep height compact; content should drive height. */
        .smxp .hero-banner{
            position:relative;
            width:100%;
            min-height:clamp(240px, 36vh, 420px);
            display:flex;
            align-items:flex-end;
            overflow:hidden;
        }
        .smxp .hero-bg{
            position:absolute; inset:0;
            background-position:center;
            background-size:cover;
            background-repeat:no-repeat;
            transform:scale(1.02);
            filter:saturate(1.02);
        }
        .smxp .hero-overlay{
            position:absolute; inset:0;
            background:linear-gradient(90deg,
                rgba(2,6,23,.62) 0%,
                rgba(2,6,23,.40) 42%,
                rgba(2,6,23,.14) 72%,
                rgba(2,6,23,.02) 100%
            );
        }
        @media (max-width: 860px){
            .smxp .hero-overlay{
                background:linear-gradient(180deg,
                rgba(2,6,23,.16) 0%,
                rgba(2,6,23,.55) 70%,
                rgba(2,6,23,.70) 100%
                );
            }
        }
        .smxp .hero-content{ position:relative; width:100%; padding:44px 18px 34px; }
        .smxp .hero-content.align-center{ text-align:center; }
        .smxp .hero-content.align-center .hero-panel{ margin-left:auto; margin-right:auto; }
        .smxp .hero-content.align-center .btnRow{ justify-content:center; }
        @media (max-width: 720px){
            .smxp .hero-content{ padding:38px 16px 28px; }
        }
        .smxp .hero-panel{
            max-width:760px;
            border:1px solid rgba(148,163,184,.30);
            background: rgba(2,6,23,.16);              /* VERY transparent */
            border-radius:var(--r);
            padding:18px;

            -webkit-backdrop-filter: blur(18px) saturate(155%);
            backdrop-filter: blur(18px) saturate(155%);

            box-shadow: 0 18px 45px rgba(2,6,23,.26);
            color: rgba(248,250,252,.96);
        }

        .smxp .hero-panel p{ color: rgba(226,232,240,.84); }
        .smxp .hero-panel h1{
            color: rgba(248,250,252,.98);
            text-shadow: 0 10px 30px rgba(2,6,23,.45);
        }
        .smxp .hero-panel .kicker{
            color: rgba(165,180,252,.95);
            text-transform: uppercase;
            letter-spacing: .18em;
        }

        .smxp .hero-panel .btn{
            background: rgba(15,23,42,.42);
            border-color: rgba(148,163,184,.45);
            color: rgba(248,250,252,.96);
        }
        .smxp .hero-panel .btn-primary{
            background: rgba(79,70,229,.92);
            border-color: rgba(129,140,248,.70);
        }

        /* Section banners should behave like the hero: stable, no drifting */
        .smxp .sec.has-banner{ padding-top: 0; }

        .smxp .sec-banner-img{
            width: 100%;
            height: clamp(240px, 44vh, 520px);
            object-fit: cover;
            display: block;
            border-radius: 0;
            margin: 0 0 18px 0;
        }

        .smxp img{{width:100%;height:auto;border-radius:calc(var(--r) - 6px);display:block}}

        /* Prevent horizontal drift/scroll from 100vw full-bleed blocks */
        .smxp{{ overflow-x:hidden; }}

        /* Full-bleed section banner (stable centring) */
        .smxp .sec-banner{{
            width:100vw;
            position:relative;
            left:50%;
            margin-left:-50vw;
            right:50%;
            margin-right:-50vw;

            height:clamp(240px, 44vh, 520px);
            background-position:center;
            background-size:cover;
            background-repeat:no-repeat;
            border-radius:0;
            margin:10px 0 18px 0;
        }}

        /* Card images: consistent crop */
        .smxp .card-img{{
            width:100%;
            height:170px;
            object-fit:cover;
            border-radius:calc(var(--r) - 6px);
            display:block;
        }}

        /* Full-bleed section image (hero-like) */
        .smxp .sec-media{
            width:100vw;
            margin-left:50%;
            transform:translateX(-50%);
            height:clamp(220px, 42vh, 460px);
            background-position:center;
            background-size:cover;
            background-repeat:no-repeat;
        }

        @media (max-width: 720px){
            .smxp .sec-media{ height:clamp(180px, 34vh, 320px); }
        }

        /* Card images */
        .smxp .card-img{
            width:100%;
            height:180px;
            object-fit:cover;
            border-radius:calc(var(--r) - 6px);
            display:block;
        }

    </style>
    """.strip()

    gallery_css = """
    <style>
        /* Gallery: horizontal rail (ONLY) */
        .smxp section[data-section-type="gallery"] .grid{
            display:flex !important;
            gap:14px;
            overflow-x:auto;
            padding: 6px 2px 12px;
            scroll-snap-type:x mandatory;
            -webkit-overflow-scrolling: touch;
            scrollbar-gutter: stable;
        }
        /* IMAGE tiles (true gallery items) */
        .smxp section[data-section-type="gallery"] .gimg{
            flex: 0 0 auto;
            width: clamp(220px, 30vw, 380px);
            aspect-ratio: 16 / 10;
            scroll-snap-align: start;
            cursor: zoom-in;
            border:1px solid var(--bd);
            border-radius: var(--r);
            background: var(--card);
            overflow:hidden;
            position:relative;
        }
        .smxp section[data-section-type="gallery"] .gimg img{
            width:100%;
            height:100%;
            object-fit: cover;
            border-radius: 0; /* tile already rounds */
        }
        .smxp section[data-section-type="gallery"] .gimg figcaption{
            position:absolute;
            left:0; right:0; bottom:0;
            padding:10px 12px;
            background: linear-gradient(180deg, rgba(2,6,23,0) 0%, rgba(2,6,23,.55) 55%, rgba(2,6,23,.78) 100%);
            color: rgba(255,255,255,.92);
            font-weight: 700;
            font-size: .92rem;
            line-height: 1.2;
            opacity: 0;
            transform: translateY(6px);
            transition: opacity .16s ease, transform .16s ease;
            pointer-events:none;
        }
        .smxp section[data-section-type="gallery"] .gimg:hover figcaption{
            opacity:1;
            transform:none;
        }

        /* CARD items inside a gallery rail stay as content cards (not lightbox) */
        .smxp section[data-section-type="gallery"] .card{
            flex: 0 0 auto;
            width: clamp(260px, 34vw, 420px);
            scroll-snap-align: start;
            cursor: default;
        }

        @media (max-width: 860px){
            .smxp section[data-section-type="gallery"] .gimg{ width: 86vw; }
            .smxp section[data-section-type="gallery"] .card{ width: 86vw; }
        }

        /* Rail nav buttons (injected by JS) */
        .smxp .smx-gallery-wrap{ position:relative; }
        .smxp .smx-gallery-nav{
            position:absolute;
            top:50%;
            transform:translateY(-50%);
            width:38px;
            height:38px;
            border-radius:999px;
            border:1px solid var(--bd);
            background: rgba(255,255,255,.82);
            color: var(--fg);
            display:flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
            z-index: 5;
            box-shadow: 0 10px 24px rgba(15,23,42,.12);
        }
        .smxp .smx-gallery-nav:hover{ transform:translateY(-50%) scale(1.03); }
        .smxp .smx-gallery-nav:active{ transform:translateY(-50%) scale(.98); }
        .smxp .smx-gallery-nav.prev{ left: 10px; }
        .smxp .smx-gallery-nav.next{ right: 10px; }
        .smxp .smx-gallery-nav[disabled]{ opacity:.35; cursor:default; }

        /* Lightbox (“lightbulb”) overlay */
        .smxp .smx-lightbox{
            position:fixed; inset:0;
            display:none;
            align-items:center;
            justify-content:center;
            padding: 20px;
            background: rgba(2,6,23,.72);
            z-index: 9999;
        }
        .smxp .smx-lightbox.open{ display:flex; }

        .smxp .smx-lightbox-panel{
            width:min(1100px, 96vw);
            max-height: 92vh;
            border-radius: 16px;
            border: 1px solid rgba(148,163,184,.28);
            background: rgba(255,255,255,.95);
            overflow:hidden;
            display:flex;
            flex-direction:column;
        }
        .smxp .smx-lightbox-top{
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap: 10px;
            padding: 10px 12px;
            border-bottom: 1px solid rgba(148,163,184,.22);
        }
        .smxp .smx-lightbox-title{ font-weight:700; color: var(--fg); }
        .smxp .smx-lightbox-close{
            border:1px solid rgba(148,163,184,.28);
            background: rgba(255,255,255,.75);
            color: var(--fg);
            border-radius: 12px;
            padding: 8px 10px;
            cursor:pointer;
        }
        .smxp .smx-lightbox-body{
            position:relative;
            padding: 12px;
            display:grid;
            gap: 10px;
        }
        .smxp .smx-lightbox-img{
            width:100%;
            max-height: 68vh;
            object-fit: contain;
            border-radius: 14px;
            background: rgba(0,0,0,.04);
        }
        .smxp .smx-lightbox-caption{
            color: var(--mut);
            line-height: 1.6;
        }
        .smxp .smx-lightbox-arrow{
            position:absolute;
            top:50%;
            transform:translateY(-50%);
            width:44px;
            height:44px;
            border-radius:999px;
            border:1px solid rgba(148,163,184,.28);
            background: rgba(255,255,255,.82);
            color: var(--fg);
            display:flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
        }
        .smxp .smx-lightbox-arrow.prev{ left: 10px; }
        .smxp .smx-lightbox-arrow.next{ right: 10px; }
        .smxp .smx-lightbox-arrow[disabled]{ opacity:.35; cursor:default; }
    </style>
    """.strip()

    js = f"""
    <script>
        (function(){{
        const root = document.getElementById("smxp-{page_id}");
        if(!root) return;
        const els = root.querySelectorAll(".reveal");
        const io = new IntersectionObserver((entries)=>{{
            entries.forEach(e=>{{ if(e.isIntersecting) e.target.classList.add("in"); }});
        }}, {{ threshold: 0.12 }});
        els.forEach(el=>io.observe(el));
        }})();
    </script>
    """.strip()

    gallery_js = f"""
    <script>
        (function(){{
            const root = document.getElementById("smxp-{page_id}") || document.querySelector(".smxp");
            if(!root) return;

            const gallerySecs = root.querySelectorAll('section[data-section-type="gallery"]');
            if(!gallerySecs.length) return;

            // Ensure single lightbox per page
            let lb = root.querySelector(".smx-lightbox");
            if(!lb){{
            lb = document.createElement("div");
            lb.className = "smx-lightbox";
            lb.innerHTML = `
                <div class="smx-lightbox-panel" role="dialog" aria-modal="true">
                <div class="smx-lightbox-top">
                    <div class="smx-lightbox-title"></div>
                    <button class="smx-lightbox-close" type="button">Close</button>
                </div>
                <div class="smx-lightbox-body">
                    <button class="smx-lightbox-arrow prev" type="button" aria-label="Previous">‹</button>
                    <img class="smx-lightbox-img" alt="" />
                    <button class="smx-lightbox-arrow next" type="button" aria-label="Next">›</button>
                    <div class="smx-lightbox-caption"></div>
                </div>
                </div>`;
            root.appendChild(lb);
            }}

            const lbTitle = lb.querySelector(".smx-lightbox-title");
            const lbImg   = lb.querySelector(".smx-lightbox-img");
            const lbCap   = lb.querySelector(".smx-lightbox-caption");
            const btnClose= lb.querySelector(".smx-lightbox-close");
            const btnPrev = lb.querySelector(".smx-lightbox-arrow.prev");
            const btnNext = lb.querySelector(".smx-lightbox-arrow.next");

            let slides = [];
            let idx = 0;
            let lastFocus = null;
            let prevOverflow = "";

            function render(){{
            const s = slides[idx];
            if(!s) return;
            lbImg.src = s.src;
            lbImg.alt = s.title || "image";
            lbTitle.textContent = s.title || "";
            lbCap.textContent = s.caption || "";
            btnPrev.disabled = (idx <= 0);
            btnNext.disabled = (idx >= slides.length - 1);
            }}

            function openAt(i){{
            idx = Math.max(0, Math.min(i, slides.length - 1));
            lastFocus = document.activeElement;
            prevOverflow = document.body.style.overflow;
            document.body.style.overflow = "hidden";
            lb.classList.add("open");
            render();
            btnClose.focus();
            }}

            function close(){{
            lb.classList.remove("open");
            document.body.style.overflow = prevOverflow || "";
            if(lastFocus && lastFocus.focus) lastFocus.focus();
            }}

            function move(d){{
            const ni = idx + d;
            if(ni < 0 || ni >= slides.length) return;
            idx = ni;
            render();
            }}

            btnClose.addEventListener("click", close);
            lb.addEventListener("click", (e)=> {{ if(e.target === lb) close(); }});
            btnPrev.addEventListener("click", ()=> move(-1));
            btnNext.addEventListener("click", ()=> move(+1));

            document.addEventListener("keydown", (e)=> {{
            if(!lb.classList.contains("open")) return;
            if(e.key === "Escape") return close();
            if(e.key === "ArrowLeft") return move(-1);
            if(e.key === "ArrowRight") return move(+1);
            }});

            function ensureNav(sec, rail){{
                let wrap = sec.querySelector(".smx-gallery-wrap");
                if(!wrap){{
                    wrap = document.createElement("div");
                    wrap.className = "smx-gallery-wrap";
                    rail.parentNode.insertBefore(wrap, rail);
                    wrap.appendChild(rail);
                }}

                let prev = wrap.querySelector("button.smx-gallery-nav.prev");
                let next = wrap.querySelector("button.smx-gallery-nav.next");

                if(!prev){{
                    prev = document.createElement("button");
                    prev.className = "smx-gallery-nav prev";
                    prev.type = "button";
                    prev.setAttribute("aria-label","Scroll left");
                    prev.innerHTML = "‹";
                    wrap.appendChild(prev);
                }}
                if(!next){{
                    next = document.createElement("button");
                    next.className = "smx-gallery-nav next";
                    next.type = "button";
                    next.setAttribute("aria-label","Scroll right");
                    next.innerHTML = "›";
                    wrap.appendChild(next);
                }}

                function update(){{
                    const max = rail.scrollWidth - rail.clientWidth;
                    const canScroll = max > 4;
                    prev.style.display = canScroll ? "" : "none";
                    next.style.display = canScroll ? "" : "none";
                    prev.disabled = rail.scrollLeft <= 2;
                    next.disabled = rail.scrollLeft >= (max - 2);
                }}

                prev.addEventListener("click", ()=> {{
                    if(prev.disabled) return;
                    rail.scrollBy({{ left: -Math.max(260, rail.clientWidth * 0.85), behavior:"smooth" }});
                }});
                next.addEventListener("click", ()=> {{
                    if(next.disabled) return;
                    rail.scrollBy({{ left:  Math.max(260, rail.clientWidth * 0.85), behavior:"smooth" }});
                }});

                rail.addEventListener("scroll", update, {{ passive:true }});
                window.addEventListener("resize", update);
                update();
            }}

            function initGallerySection(sec){{
                const rail = sec.querySelector(".grid");
                if(!rail) return;

                ensureNav(sec, rail);

                // Build slides from IMAGE tiles only (cards remain content cards)
                const tiles = Array.from(rail.querySelectorAll('[data-item-type="image"]'));
                if(!tiles.length) return;

                // Build a local slide list for THIS rail
                const localSlides = [];
                tiles.forEach(tile => {{
                    const img = tile.querySelector("img");
                    if(!img) return;

                    const full = (tile.getAttribute("data-full") || img.getAttribute("data-full") || img.getAttribute("src") || "").trim();
                    if(!full) return;

                    const title = (tile.getAttribute("data-title") || "").trim();
                    const caption = (tile.getAttribute("data-caption") || "").trim();

                    const slideIndex = localSlides.length;
                    localSlides.push({{ src: full, title, caption }});

                    tile.dataset.smxSlide = String(slideIndex);

                    // IMPORTANT: don’t double-bind (dynamic inserts / re-init safe)
                    if(tile.dataset.smxBound === "1") return;
                    tile.dataset.smxBound = "1";

                    tile.addEventListener("click", (e)=> {{
                    if(e.target && e.target.closest && e.target.closest("a,button")) return;
                    slides = localSlides; // activate the correct slide set for this rail
                    const i = parseInt(tile.dataset.smxSlide || "0", 10);
                    openAt(i);
                    }});
                }});
            }}

            gallerySecs.forEach(sec => initGallerySection(sec));

            // Re-init when new gallery sections or new tiles are inserted dynamically (Admin editor)
            const obs = new MutationObserver((mutations) => {{
            for(const m of mutations){{
                if(m.type !== "childList") continue;

                // If a gallery section is added, init it
                m.addedNodes && m.addedNodes.forEach(node => {{
                if(!(node instanceof Element)) return;

                if(node.matches && node.matches('section[data-section-type="gallery"]')){{
                    initGallerySection(node);
                    return;
                }}

                // If anything added inside/near a gallery section, init the nearest section
                const sec = node.closest ? node.closest('section[data-section-type="gallery"]') : null;
                if(sec) initGallerySection(sec);
                }});
            }}
            }});

            obs.observe(root, {{ childList: true, subtree: true }});

        }})();
    </script>
    """.strip()


    def esc(s: str) -> str:
        s = s or ""
        s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        s = s.replace('"', "&quot;").replace("'", "&#39;")
        return s
    
    def esc_nl(s: str) -> str:
        # preserve paragraphs in plain text
        return esc(s).replace("\n", "<br>")


    def icon_svg(name: str) -> str:
        svg = _ICON_SVGS.get((name or "").strip().lower())
        if not svg:
            return ""
        return f'<span class="icon">{svg}</span>'

    parts: List[str] = [f'<div class="smxp" id="smxp-{page_id}">', css, gallery_css]
    sections = layout.get("sections") if isinstance(layout.get("sections"), list) else []

    # Map first section id by type (used for default Hero CTA anchors)
    sec_id_by_type: Dict[str, str] = {}
    for _s in sections:
        if not isinstance(_s, dict):
            continue
        _t = str(_s.get("type") or "").lower().strip()
        if not _t or _t in sec_id_by_type:
            continue
        _sid = str(_s.get("id") or "").strip() or f"sec_{_t}"
        sec_id_by_type[_t] = _sid

    def safe_href(h: str) -> str:
        h = (h or "").strip()
        if not h:
            return ""
        low = h.lower()
        if low.startswith("javascript:") or low.startswith("data:"):
            return ""
        return h

    for s in sections:
        stype = (s.get("type") or "section").lower()
        title = esc(s.get("title") or "")
        text = esc_nl(s.get("text") or "")
        items = s.get("items") if isinstance(s.get("items"), list) else []
        sec_dom_id = (s.get("id") or "").strip()
        if not sec_dom_id:
            sec_dom_id = "sec_hero" if stype == "hero" else f"sec_{stype}"

        #############################################################################################################
        # Ensure every section has a stable DOM id so patch_page_publish can target it.
        sec_dom_id = (s.get("id") or "").strip()
        if not sec_dom_id:
            sec_dom_id = "sec_hero" if stype == "hero" else f"sec_{stype}"
        sec_id_attr = f' id="{esc(sec_dom_id)}"'
        
        # HERO
        if stype == "hero":
            # Background image (section-level preferred; fall back to first item imageUrl)
            img_url = (s.get("imageUrl") or "").strip()
            if not img_url and items and isinstance(items[0], dict):
                img_url = (items[0].get("imageUrl") or "").strip()

            bg_style = f"background-image:url('{esc(img_url)}');" if img_url else ""

            # Alignment: left (default) or center/centre
            hero_align = str(layout.get("heroAlignment") or s.get("heroAlignment") or "left").strip().lower()
            align_cls = "align-center" if hero_align in ("center", "centre") else ""

            # ---------------------------
            # Hero CTA buttons
            # ---------------------------
            cta1_label = (s.get("heroCta1Label") or "").strip()
            cta2_label = (s.get("heroCta2Label") or "").strip()

            cta1_href = safe_href(str(s.get("heroCta1Href") or ""))
            cta2_href = safe_href(str(s.get("heroCta2Href") or ""))

            # If labels exist but hrefs are missing, fall back to safe in-page anchors.
            def _default_anchor() -> str:
                for k in ("services", "features", "highlights", "problem", "solution", "story", "introduction", "intro"):
                    if k in sec_id_by_type:
                        return f"#{sec_id_by_type[k]}"
                # final fallback: first non-hero section
                for _sec in sections:
                    if not isinstance(_sec, dict):
                        continue
                    if str(_sec.get("type") or "").lower().strip() == "hero":
                        continue
                    _sid = str(_sec.get("id") or "").strip() or f"sec_{str(_sec.get('type') or 'section').lower().strip()}"
                    return f"#{_sid}"
                return ""

            if cta1_label and not cta1_href:
                cta1_href = _default_anchor()
            if cta2_label and not cta2_href:
                cta2_href = _default_anchor()

            btns = []
            if cta1_label and cta1_href:
                btns.append(
                    f'<a class="btn" data-smx="hero-cta" data-cta="1" href="{esc(cta1_href)}">'
                    f'<span class="icon">{_ICON_SVGS["arrow"]}</span>{esc(cta1_label)}</a>'
                )
            if cta2_label and cta2_href:
                btns.append(
                    f'<a class="btn" data-smx="hero-cta" data-cta="2" href="{esc(cta2_href)}">'
                    f'<span class="icon">{_ICON_SVGS["arrow"]}</span>{esc(cta2_label)}</a>'
                )

            btn_row_html = f'<div class="btnRow">{"".join(btns)}</div>' if btns else ""

            parts.append(
                f'''
                <section{sec_id_attr} class="hero" data-section-type="hero">
                    <div class="hero-banner">
                        <div class="hero-bg" style="{bg_style}"></div>
                        <div class="hero-overlay"></div>
                        <div class="hero-content {align_cls}">
                            <div class="wrap">
                                <div class="hero-panel reveal">
                                    <h1>{title}</h1>
                                    {f'<p style="margin-top:10px">{text}</p>' if text else ''}
                                    {btn_row_html}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                '''.strip()
            )

            continue
        ####################################################################################################
        # Others
        try:
            cols = int(s.get("cols") or 3)
        except Exception:
            cols = 3
        cols = max(1, min(5, cols))

        tiles: List[str] = []
        for it in items:
            if not isinstance(it, dict):
                continue

            it_type = str(it.get("type") or "card").lower().strip()

            title_plain = (it.get("title") or "").strip()
            cap_plain   = (it.get("text") or "").strip()

            it_title = esc(title_plain)
            it_text  = esc_nl(cap_plain)

            full = (it.get("imageUrl") or "").strip()
            thumb = (it.get("thumbUrl") or it.get("thumb_url") or "").strip()
            src = thumb or full  # rail prefers thumb if available

            # IMAGE tiles: true gallery behaviour (thumb in rail, full in lightbox)
            if stype == "gallery" and it_type == "image":
                if not src:
                    continue
                full_for_lb = full or src
                tiles.append(
                    f'''
                    <figure class="gimg reveal"
                            data-item-type="image"
                            data-full="{esc(full_for_lb)}"
                            data-title="{esc(title_plain)}"
                            data-caption="{esc(cap_plain)}">
                        <img loading="lazy" decoding="async"
                            src="{esc(src)}"
                            data-full="{esc(full_for_lb)}"
                            alt="{esc(title_plain or 'image')}">
                        {f'<figcaption>{it_title}</figcaption>' if title_plain else ''}
                    </figure>
                    '''.strip()
                )
                continue

            # Default: render as a content card (Card, FAQ, Quote, etc.)
            ic = icon_svg(it.get("icon") or "")
            img_html = f'<img class="card-img" loading="lazy" decoding="async" src="{esc(full)}" alt="{it_title}">' if full else ""

            title_align = _safe_align(str(it.get("titleAlign") or ""))
            text_align  = _safe_align(str(it.get("textAlign") or ""))

            title_align_css = f"text-align:{title_align};" if title_align else ""
            text_align_css  = f"text-align:{text_align};" if text_align else ""

            raw_html = str(it.get("textHtml") or "").strip()
            if raw_html:
                safe_html = _sanitize_rich_html(raw_html)
                body_html = f'<div class="smx-rich" style="{text_align_css}">{safe_html}</div>'
            else:
                body_html = f'<p style="margin-top:8px;{text_align_css}">{it_text}</p>'

            tiles.append(
                f'''
                <div class="card reveal" data-item-type="{esc(it_type)}">
                {img_html}
                <div style="display:flex;gap:10px;align-items:flex-start;margin-top:{'10px' if img_html else '0'};">
                    {ic}
                    <h3 style="margin:0;{title_align_css}">{it_title}</h3>
                </div>
                {body_html}
                </div>
                '''.strip()
            )

        if tiles:
            if stype == "gallery":
                grid_html = '<div class="grid">' + "\n".join(tiles) + "</div>"
            else:
                grid_html = (
                    f'<div class="grid" style="grid-template-columns:repeat({cols}, minmax(0, 1fr));">'
                    + "\n".join(tiles) +
                    "</div>"
                )
        else:
            grid_html = ""

        
        sec_level_img = (s.get("imageUrl") or "").strip()

        # Section class names
        sec_class_parts = ["sec"]
        if stype == "gallery":
            sec_class_parts.append("sec-gallery")
        if sec_level_img and stype != "hero":
            sec_class_parts.append("has-banner")
        sec_class = " ".join(sec_class_parts)

        # Show section-level image as a full-bleed, full-viewport banner for ANY non-hero section.
        # (Includes gallery sections; gallery items still render as a rail below.)
        sec_media_html = ""
        if sec_level_img and stype != "hero":
            sec_media_html = (
                f'<div class="sec-media reveal" '
                f'style="background-image:url({esc(sec_level_img)});" '
                f'role="img" aria-label="{title}"></div>'
            )

        parts.append(
            f'''
            <section id="{esc(sec_dom_id)}" class="{esc(sec_class)}" data-section-type="{esc(stype or 'section')}">
            {sec_media_html}
            <div class="wrap">
                <h2 class="reveal">{title}</h2>
                {'<p class="reveal" style="margin-bottom:14px;">'+text+'</p>' if text else ''}
                {grid_html}
            </div>
            </section>
            '''.strip()
        )

    parts.append(js)
    parts.append(gallery_js)
    parts.append("</div>")

    return "\n\n".join(parts)


def _layout_non_hero_sections(layout: Dict[str, Any]) -> List[Dict[str, Any]]:
    sections = layout.get("sections") if isinstance(layout.get("sections"), list) else []
    out = []
    for s in sections:
        if not isinstance(s, dict):
            continue
        if (s.get("type") or "").lower() == "hero":
            continue
        out.append(s)
    return out


def _layout_hero_section(layout: Dict[str, Any]) -> Dict[str, Any] | None:
    sections = layout.get("sections") if isinstance(layout.get("sections"), list) else []
    for s in sections:
        if isinstance(s, dict) and (s.get("type") or "").lower() == "hero":
            return s
    return None


def patch_hero_bg_precise(existing_html: str, new_url: str) -> str:
    """
    Patch ONLY the hero background image. Never touches other page content/CSS.
    Looks for:
      1) <div class="hero-bg" style="background-image:...">
      2) <section class="hero ..."> style="background-image:..."
    """
    if not existing_html or not new_url:
        return existing_html

    soup = BeautifulSoup(existing_html, "html.parser")

    # Case 1: hero-bg div
    hero_bg = soup.select_one(".hero-bg")
    if hero_bg:
        style = hero_bg.get("style") or ""
        # remove any prior background-image declarations
        style_parts = [p.strip() for p in style.split(";") if p.strip() and not p.strip().lower().startswith("background-image")]
        style_parts.append(f'background-image:url("{new_url}")')
        hero_bg["style"] = "; ".join(style_parts) + ";"
        return str(soup)

    # Case 2: hero section itself
    hero_sec = None
    for sec in soup.find_all("section"):
        cls = " ".join(sec.get("class") or [])
        if "hero" in cls.split():
            hero_sec = sec
            break

    if hero_sec:
        style = hero_sec.get("style") or ""
        style_parts = [p.strip() for p in style.split(";") if p.strip() and not p.strip().lower().startswith("background-image")]
        style_parts.append(f'background-image:url("{new_url}")')
        hero_sec["style"] = "; ".join(style_parts) + ";"
        return str(soup)

    return existing_html


def patch_section_titles_intros_changed_only(
    existing_html: str,
    old_layout: Dict[str, Any],
    new_layout: Dict[str, Any],
) -> str:
    """
    Patch ONLY section <h2> title + the first intro <p> under it,
    and ONLY for sections whose title/text changed in the layout.
    Mapping is by non-hero section order.
    """
    if not existing_html:
        return existing_html

    old_secs = _layout_non_hero_sections(old_layout or {})
    new_secs = _layout_non_hero_sections(new_layout or {})
    if not new_secs:
        return existing_html

    soup = BeautifulSoup(existing_html, "html.parser")

    # HTML non-hero <section> blocks (skip obvious hero sections)
    html_secs = []
    for sec in soup.find_all("section"):
        cls = " ".join(sec.get("class") or [])
        if "hero" in cls.split():
            continue
        html_secs.append(sec)

    n = min(len(html_secs), len(new_secs))
    if n <= 0:
        return existing_html

    for i in range(n):
        old_s = old_secs[i] if i < len(old_secs) and isinstance(old_secs[i], dict) else {}
        new_s = new_secs[i] if isinstance(new_secs[i], dict) else {}

        old_title = (old_s.get("title") or "").strip()
        new_title = (new_s.get("title") or "").strip()

        old_text = (old_s.get("text") or "").strip()
        new_text = (new_s.get("text") or "").strip()

        sec_tag = html_secs[i]

        # Patch title only if changed and non-empty
        if new_title and new_title != old_title:
            h2 = sec_tag.find("h2")
            if h2:
                h2.clear()
                h2.append(new_title)

        # Patch intro text only if changed and non-empty
        if new_text and new_text != old_text:
            h2 = sec_tag.find("h2")
            if h2:
                p = h2.find_next("p")
                # ensure this <p> is still inside the same section
                if p and p.find_parent("section") is sec_tag:
                    p.clear()
                    p.append(new_text)

    return str(soup)
