SyntaxMatrix Platform Provisioner (SPP)

SyntaxMatrix Platform Provisioner (SPP) is a self-hosted AI platform framework for building, deploying, and operating production-grade AI applications with licensing, governance, and modular extensibility built in.

SPP is designed for developers, educators, research teams, and enterprises who need full control over their AI systems while retaining a clear upgrade path to commercial capabilities.

What is SyntaxMatrix Platform Provisioner?

SPP is an open-core platform provisioner that enables organisations to:

Deploy AI-powered web applications

Provision AI assistants, ML tooling, and admin panels

Enforce feature access via licensing

Maintain full data ownership and self-hosting control

Each client runs their own independent instance.
SyntaxMatrix does not host or operate client environments.

Key Capabilities

Self-Hosted AI Platform
Deploy on your own infrastructure (cloud or on-prem).

Modular Architecture
Enable or disable platform capabilities via entitlements.

Licensing & Entitlements
Commercial features are controlled through a secure licence system.

Admin Panel & Governance
Manage users, content, data ingestion, and configuration.

AI & ML Tooling
Built-in support for AI assistants, retrieval, analytics, and experimentation.

Production-Ready
Designed for real deployments, not demos.

Open-Core Model

SyntaxMatrix Platform Provisioner follows an open-core approach:

Core framework → MIT Licence

Premium features → Commercial Licence

This allows you to:

Start freely

Self-host fully

Upgrade only when advanced capabilities are required

Licensing Overview
Open-Source Components (MIT)

The core platform is released under the MIT Licence, allowing:

Commercial use

Modification

Redistribution

Commercial Licence (Required for Premium Features)

Certain features require a paid subscription, including (but not limited to):

Advanced AI modules

Enterprise-grade limits

Premium admin capabilities

Commercial support tooling

Licence enforcement features

Commercial features are governed by the SyntaxMatrix Commercial Licence Agreement.

Using Premium Features without a valid licence is not permitted.

Subscription & Billing

Subscriptions are managed via Stripe

Licences are validated remotely

Paid plans take effect immediately

Cancellation applies at the end of the billing period

Grace periods may apply for payment issues

All enforcement is automated and transparent.

Self-Hosting Philosophy

SyntaxMatrix is built on a client-owned infrastructure model:

You deploy your own instance

You own your data

You control your environment

You choose when (and if) to upgrade

This architecture is intentional and central to the product’s design.

Typical Use Cases

AI education platforms

Internal enterprise AI tools

Research environments

AI-powered dashboards

Multi-tenant AI services

Regulated or privacy-sensitive deployments

Installation

SPP is distributed via PyPI.

Installation details are intentionally minimal here to avoid coupling the README to internal APIs.
Full setup instructions are provided in the official documentation.

Documentation

Comprehensive documentation covers:

Architecture & design

Licensing model

Deployment workflows

Client-side integration

Security considerations

Documentation is provided separately and kept version-aligned with releases.

Support & Contact

Website: https://syntaxmatrix.com

Licensing: licence@syntaxmatrix.com

Commercial enquiries: info@syntaxmatrix.com

Legal

© SyntaxMatrix Limited
All rights reserved.

Use of Premium Features requires a valid commercial subscription.