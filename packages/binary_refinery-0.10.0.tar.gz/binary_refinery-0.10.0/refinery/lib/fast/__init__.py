"""
This module implements some routines in cython that have to be fast.
"""
