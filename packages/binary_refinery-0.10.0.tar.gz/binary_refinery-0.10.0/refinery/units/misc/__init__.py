"""
Units whose purpose is narrow or very special and does not fit well into any
other category.
"""
