"""
Simple operations on strings, such as concatenation, replacement, slicing,
trimming, etcetera.
"""
