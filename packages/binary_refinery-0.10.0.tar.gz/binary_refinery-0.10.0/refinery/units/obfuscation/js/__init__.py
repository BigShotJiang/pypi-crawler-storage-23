"""
Deobfuscation of JavaScript documents.
"""
