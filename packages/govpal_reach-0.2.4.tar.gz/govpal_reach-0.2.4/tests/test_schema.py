"""Tests for schema migrations (gpr_ namespace, gpr_messages columns)."""

from pathlib import Path


def test_migration_009_adds_subject_and_body_to_gpr_messages() -> None:
    """Migration 009 adds subject TEXT and body TEXT to gpr_messages for full message content."""
    repo_root = Path(__file__).resolve().parent.parent
    path = repo_root / "schema" / "009_gpr_messages_subject_body.sql"
    assert path.exists(), "009_gpr_messages_subject_body.sql must exist"
    sql = path.read_text()
    assert "gpr_messages" in sql
    assert "subject" in sql
    assert "body" in sql
    assert "TEXT" in sql
    assert "ADD COLUMN" in sql
    # TEXT type ensures no truncation for long messages (350–500+ words)
    assert "subject" in sql and "body" in sql


def test_migration_010_adds_gpr_dead_letter_jobs_table() -> None:
    """Migration 010 adds gpr_dead_letter_jobs for failed delivery jobs after retries."""
    repo_root = Path(__file__).resolve().parent.parent
    path = repo_root / "schema" / "010_gpr_dead_letter_jobs.sql"
    assert path.exists(), "010_gpr_dead_letter_jobs.sql must exist"
    sql = path.read_text()
    assert "gpr_dead_letter_jobs" in sql
    assert "original_job_id" in sql
    assert "payload" in sql
    assert "reason" in sql
    assert "message_id" in sql
    assert "representative_id" in sql
    assert "delivery_method" in sql
