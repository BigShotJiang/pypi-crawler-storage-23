"""Static/cached data – boundaries, contacts."""
