"""Shared database connection helper."""

import os
from typing import TYPE_CHECKING

import psycopg

if TYPE_CHECKING:
    from govpal.config import Config

# GovPal Reach application tables are namespaced with this prefix (e.g. gpr_users).
GPR_TABLE_PREFIX = "gpr_"


def gpr_table(base_name: str) -> str:
    """Return the application table name with gpr_ prefix (e.g. users -> gpr_users)."""
    return f"{GPR_TABLE_PREFIX}{base_name}"


def get_connection(
    dsn: str | None = None,
    *,
    config: "Config | None" = None,
) -> psycopg.Connection:
    """
    Return a Postgres connection context manager.

    Uses dsn, then config.database_url, then DATABASE_URL from environment.
    Raises ValueError if none are set.
    """
    resolved_dsn = (
        dsn
        or (getattr(config, "database_url", None) if config else None)
        or os.environ.get("DATABASE_URL")
    )
    if not resolved_dsn:
        raise ValueError("DATABASE_URL or dsn must be set")
    return psycopg.connect(resolved_dsn)
