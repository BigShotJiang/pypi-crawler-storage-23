"""Orchestrator API – compose discovery, identity, delivery."""

import logging
import uuid
from typing import Callable, Protocol

_log = logging.getLogger(__name__)

from govpal.delivery.email.format import (
    format_constituent_email_body,
    format_on_behalf_of_from_name,
    get_honorific_for_rep,
    get_last_name_from_rep,
)
from govpal.delivery.email.interfaces import EmailProvider
from govpal.db import get_connection, gpr_table
from govpal.delivery.queue import DeliveryQueue
from govpal.discovery.interfaces import GeocodingProvider, Rep, RepProvider

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from govpal.config import Config


def _default_geocoding_provider(config: "Config | None" = None) -> GeocodingProvider:
    """Return default geocoding provider. Lazy import to reduce coupling."""
    from govpal.discovery.geocoding import CensusGeocoderProvider

    return CensusGeocoderProvider()


def _default_rep_providers(config: "Config | None" = None) -> list[RepProvider]:
    """Return default rep providers. Lazy import to reduce coupling."""
    from govpal.discovery.google_civic import GoogleCivicProvider
    from govpal.discovery.open_states import OpenStatesProvider

    gapi = config.google_civic_api_key if config else None
    oapi = config.openstates_api_key if config else None
    return [
        GoogleCivicProvider(api_key=gapi or None),
        OpenStatesProvider(api_key=oapi or None),
    ]


def _default_email_provider(config: "Config | None" = None) -> EmailProvider:
    """Return default email provider. GP_DELIVERY_MODE: capture (default)|redirect|live."""
    import os

    mode = (os.environ.get("GP_DELIVERY_MODE") or "").strip().lower()
    # Default to capture so new installs don't send real email until explicitly enabled
    if mode not in ("redirect", "live"):
        from govpal.delivery.email.capturing import get_capturing_provider

        return get_capturing_provider()
    if mode == "redirect":
        raw = (os.environ.get("GP_TEST_RECIPIENTS") or "").strip()
        test_recipients = [r.strip() for r in raw.split(",") if r.strip()]
        from govpal.delivery.email.postmark import PostmarkProvider
        from govpal.delivery.email.redirecting import RedirectingEmailProvider

        token = config.postmark_server_token if config else None
        from_addr = config.postmark_from_address if config else None
        inner = PostmarkProvider(
            server_token=token or None, from_address=from_addr or None
        )
        return RedirectingEmailProvider(inner, test_recipients)
    # mode == "live"
    from govpal.delivery.email.postmark import PostmarkProvider

    token = config.postmark_server_token if config else None
    from_addr = config.postmark_from_address if config else None
    return PostmarkProvider(server_token=token or None, from_address=from_addr or None)


def _default_delivery_queue(config: "Config | None" = None) -> DeliveryQueue:
    """
    Return default delivery queue.
    When config has database_url and GOVPAL_USE_REAL_QUEUE is set (1/true/yes), returns PGQueuerDeliveryQueue.
    Otherwise returns MockDeliveryQueue (no-op).
    Lazy import to reduce coupling.
    """
    import os
    from govpal.delivery.queue import MockDeliveryQueue, PGQueuerDeliveryQueue

    if config and (config.database_url or "").strip():
        use_real = (os.environ.get("GOVPAL_USE_REAL_QUEUE") or "").strip().lower() in (
            "1",
            "true",
            "yes",
        )
        if use_real:
            return PGQueuerDeliveryQueue(config=config)
    return MockDeliveryQueue()


class ConstituentProfile(Protocol):
    """Profile shape needed for send_message_to_representatives (e.g. identity UserProfile)."""

    first_name: str | None
    last_name: str | None
    email: str | None

    def full_address_for_display(self) -> str: ...


def discover_reps_for_address(
    address: str,
    *,
    geocoding_provider: GeocodingProvider | None = None,
    rep_providers: list[RepProvider] | None = None,
    config: "Config | None" = None,
    include_local_discovery: bool = True,
    regions: list[str] | None = None,
) -> list[Rep]:
    """
    Discover representatives for a street address.

    Geocodes the address, then queries Google Civic (by address) and Open States
    (by lat/lng). When include_local_discovery is True and coords are available,
    also resolves regional districts (e.g. LA City Council, County Supervisors,
    Neighborhood Councils) and merges reps from contact_overrides. Merges and
    deduplicates all results.

    Args:
        address: Full street address.
        geocoding_provider: Optional; defaults to CensusGeocoderProvider.
        rep_providers: Optional; defaults to [GoogleCivicProvider, OpenStatesProvider].
        config: Optional; when provided, provider API keys and DB come from config.
        include_local_discovery: If True (default), include regional/local reps when coords fall in a supported region.
        regions: Optional; if provided, only these region names are used for local discovery. If None, uses all supported regions.

    Returns:
        List of rep dicts (merged, deduplicated).
    """
    if not address or not address.strip():
        return []

    geo = geocoding_provider or _default_geocoding_provider(config)
    providers = rep_providers or _default_rep_providers(config)

    coords = geo.geocode(address)

    all_reps: list[Rep] = []

    # Google Civic: by address
    for p in providers:
        try:
            reps = p.get_reps_by_address(address)
            all_reps.extend(reps)
        except Exception as e:
            _log.warning(
                "Provider %s get_reps_by_address failed: %s", type(p).__name__, e
            )

    # Open States (and similar): by coords
    if coords:
        lat, lng = coords
        for p in providers:
            try:
                reps = p.get_reps_by_coords(lat, lng)
                all_reps.extend(reps)
            except Exception as e:
                _log.warning(
                    "Provider %s get_reps_by_coords failed: %s", type(p).__name__, e
                )

        # LA local (and other supported regions): point-in-polygon + contact_overrides
        if include_local_discovery:
            from govpal.discovery.local.registry import get_supported_regions

            regions_to_use = regions if regions is not None else get_supported_regions()
            for region in regions_to_use:
                try:
                    local_reps = _reps_from_local_discovery(lat, lng, region, config)
                    all_reps.extend(local_reps)
                except Exception as e:
                    _log.warning("Local discovery for region %s failed: %s", region, e)

    return _merge_dedupe(all_reps)


def enqueue_messages_for_address(
    address: str,
    message_id: str,
    queue: DeliveryQueue | None = None,
    *,
    discovery_fn: Callable[[str], list[Rep]] | None = None,
    rep_providers: list[RepProvider] | None = None,
    geocoding_provider: GeocodingProvider | None = None,
    config: "Config | None" = None,
) -> list[str]:
    """
    Discover reps for address and enqueue one delivery job per (message, rep, method).

    For each rep, determines delivery_method from contact info:
    - contact_email -> email
    - contact_form_url -> webform
    - mail_only -> not implemented (skipped)

    Args:
        address: Full street address.
        message_id: UUID of the message record.
        queue: Delivery queue; defaults to MockDeliveryQueue (no-op).
        discovery_fn: Optional; if provided, used instead of discover_reps_for_address.
        rep_providers: Passed to discover_reps_for_address if discovery_fn not used.
        geocoding_provider: Passed to discover_reps_for_address if discovery_fn not used.

    Returns:
        List of queue job IDs.
    """
    if not address or not address.strip() or not message_id:
        return []

    q = queue or _default_delivery_queue(config)

    if discovery_fn is not None:
        reps = discovery_fn(address)
    else:
        reps = discover_reps_for_address(
            address,
            geocoding_provider=geocoding_provider,
            rep_providers=rep_providers,
            config=config,
        )

    job_ids: list[str] = []
    for rep in reps:
        delivery_method = delivery_method_for_rep(rep)
        if not delivery_method:
            continue
        rep_id = rep.get("id") or str(uuid.uuid4())
        ids = q.enqueue_delivery(
            message_id=message_id,
            representative_id=str(rep_id),
            delivery_method=delivery_method,
        )
        job_ids.extend(ids)

    return job_ids


def delivery_method_for_rep(rep: Rep) -> str | None:
    """Return 'email', 'webform', or None (mail_only / not supported)."""
    if rep.get("contact_email"):
        return "email"
    if rep.get("contact_form_url"):
        return "webform"
    return None


def create_message(
    user_id: uuid.UUID | str,
    representative_id: uuid.UUID | str,
    delivery_method: str,
    *,
    subject: str | None = None,
    body: str | None = None,
    dsn: str | None = None,
    config: "Config | None" = None,
) -> str:
    """
    Create a message row and return its ID.

    Persists to gpr_messages with status='pending'. Caller can then call
    update_message to set subject/body and enqueue_messages_for_address to queue delivery.

    Args:
        user_id: User UUID (or string).
        representative_id: Representative UUID (or string).
        delivery_method: 'email' or 'webform'.
        subject: Optional subject line.
        body: Optional body text (supports long messages).
        dsn: Optional database URL.
        config: Optional config (database_url used when dsn is None).

    Returns:
        Message ID (UUID string).
    """
    uid = str(user_id) if isinstance(user_id, uuid.UUID) else user_id
    rid = (
        str(representative_id)
        if isinstance(representative_id, uuid.UUID)
        else representative_id
    )
    table = gpr_table("messages")
    with get_connection(dsn, config=config) as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO {table} (user_id, representative_id, delivery_method, status, subject, body)
                VALUES (%s, %s, %s, 'pending', %s, %s)
                RETURNING id
                """,
                (uid, rid, delivery_method, subject, body),
            )
            row = cur.fetchone()
            conn.commit()
    return str(row[0])


def update_message(
    message_id: str | uuid.UUID,
    *,
    subject: str | None = None,
    body: str | None = None,
    dsn: str | None = None,
    config: "Config | None" = None,
) -> bool:
    """
    Update a message's subject and/or body by ID.

    Only the provided fields are updated; omit a field to leave it unchanged.
    If neither subject nor body is provided, returns False (no-op).

    Args:
        message_id: Message UUID (string or UUID).
        subject: New subject; omit to leave unchanged.
        body: New body; omit to leave unchanged.
        dsn: Optional database URL.
        config: Optional config.

    Returns:
        True if at least one row was updated, False if no-op or not found.
    """
    if subject is None and body is None:
        return False
    mid = str(message_id) if isinstance(message_id, uuid.UUID) else message_id
    table = gpr_table("messages")
    updates: list[str] = []
    params: list[str | None] = []
    if subject is not None:
        updates.append("subject = %s")
        params.append(subject)
    if body is not None:
        updates.append("body = %s")
        params.append(body)
    params.append(mid)
    with get_connection(dsn, config=config) as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"UPDATE {table} SET {', '.join(updates)} WHERE id = %s",
                params,
            )
            n = cur.rowcount
            conn.commit()
    return n > 0


def _format_and_send_email_for_rep(
    provider: EmailProvider,
    rep: Rep,
    profile: ConstituentProfile,
    subject: str,
    body: str,
    from_name: str,
    phone: str,
) -> tuple[Rep, bool] | None:
    """
    Format and send one email to a representative. Returns (rep, success) if rep has
    contact_email, None if skipped.
    """
    to_email = (rep.get("contact_email") or "").strip()
    if not to_email:
        return None
    honorific = get_honorific_for_rep(rep)
    rep_last = get_last_name_from_rep(rep)
    address = profile.full_address_for_display()
    first = profile.first_name or ""
    last = profile.last_name or ""
    full_body = format_constituent_email_body(
        body,
        honorific=honorific,
        last_name=rep_last,
        constituent_first=first,
        constituent_last=last,
        address=address,
        phone=phone,
    )
    sent = provider.send(
        to=to_email,
        subject=subject,
        body=full_body,
        from_name=from_name,
        reply_to=profile.email or None,
    )
    return (rep, sent)


def send_message_to_representatives(
    body: str,
    subject: str,
    profile: ConstituentProfile,
    phone: str,
    reps: list[Rep],
    *,
    email_provider: EmailProvider | None = None,
    from_name: str | None = None,
    brand: str | None = None,
    config: "Config | None" = None,
) -> list[tuple[Rep, bool]]:
    """
    Send a message to one or more representatives by email.

    The library adds the dear-representative preamble and the closing (address
    and constituent information). Caller passes only the middle body, subject,
    user profile, and list of reps.

    Only reps with contact_email are sent to; others are skipped.

    Args:
        body: Middle content of the email (no greeting or closing).
        subject: Email subject line.
        profile: Constituent profile (first_name, last_name, email, full_address_for_display).
        phone: Constituent phone (for closing).
        reps: List of representative dicts (contact_email, name, optional honorific).
        email_provider: Optional; defaults to PostmarkProvider().
        from_name: Optional; if None, built from profile and brand.
        brand: Optional; used for from_name when from_name is None.

    Returns:
        List of (rep, success) for each rep that has contact_email.
    """
    provider = email_provider or _default_email_provider(config)
    effective_brand = brand or (config.govpal_email_from_brand if config else None)
    if from_name is None:
        from_name = format_on_behalf_of_from_name(
            profile.first_name or "",
            profile.last_name or "",
            profile.email or "",
            brand=effective_brand,
            config=config,
        )
    results: list[tuple[Rep, bool]] = []
    for rep in reps:
        one = _format_and_send_email_for_rep(
            provider, rep, profile, subject, body, from_name, phone
        )
        if one is not None:
            results.append(one)
    return results


def _merge_dedupe(reps: list[Rep]) -> list[Rep]:
    """Merge reps by normalised name, keeping the first (highest-quality) occurrence.

    Google Civic results come first and carry accurate level/office metadata,
    so first-wins gives us the best data when the same person appears from
    multiple providers.

    Also dedupes by (level, office) to prevent duplicate entries for unique offices
    like "Mayor" when name variations exist (e.g., "Karen Bass" vs "Karen Ruth Bass").
    """
    seen_names: dict[str, Rep] = {}
    seen_offices: set[tuple[str, str]] = set()
    result: list[Rep] = []

    for r in reps:
        name_key = r.get("name", "").strip().lower()
        if not name_key:
            continue

        # Skip if we've seen this exact name
        if name_key in seen_names:
            continue

        # For unique offices (Mayor, etc.), also dedupe by (level, office)
        office = r.get("office", "").strip().lower()
        level = r.get("level", "").strip().lower()
        if office and level:
            office_key = (level, office)
            if office_key in seen_offices:
                continue
            seen_offices.add(office_key)

        seen_names[name_key] = r
        result.append(r)

    return result


# Jurisdiction strings for contact_overrides lookup by layer (Los Angeles only).
_LA_JURISDICTION_BY_LAYER: dict[str, str] = {
    "city": "Los Angeles",
    "county": "Los Angeles County",
    "neighborhood": "Los Angeles",
}


def _contact_override_to_rep(
    override: dict,
    target_type: str,
    jurisdiction: str,
    district: str,
) -> Rep:
    """Convert a ContactOverride row to Rep shape for merge/dedupe and delivery.

    Args:
        override: ContactOverride dict with official_name, email, webform_url, phone
        target_type: "city", "county", "neighborhood", or "mayor"
        jurisdiction: Jurisdiction string (e.g. "Los Angeles", "Los Angeles County")
        district: District identifier (e.g. "11", "3", or "" for city-wide officials)

    Returns:
        Rep dict with level, office, name, and contact fields
    """
    # Map target_type to jurisdiction level and derive office title
    if target_type == "mayor":
        level = "city"
        office = "Mayor"
    elif target_type == "city":
        level = "city"
        office = f"City Council District {district}" if district else "City Council"
    elif target_type == "county":
        level = "county"
        office = f"Board of Supervisors District {district}" if district else "Board of Supervisors"
    elif target_type == "neighborhood":
        level = "neighborhood"
        office = "Neighborhood Council"
    else:
        level = target_type
        office = ""

    return {
        "level": level,
        "office": office,
        "name": override.get("official_name") or "",
        "district": district,
        "jurisdiction": jurisdiction,
        "contact_email": override.get("email"),
        "contact_form_url": override.get("webform_url"),
        "contact_phone": override.get("phone"),
        "data_source": "contact_overrides",
    }


def _reps_from_local_discovery(
    lat: float,
    lng: float,
    region: str,
    config: "Config | None",
) -> list[Rep]:
    """
    Resolve regional districts for (lat, lng) and return reps from contact_overrides.
    Only Los Angeles is supported; other regions return [].
    """
    if region != "Los Angeles":
        return []
    try:
        from govpal.discovery.local.contacts import get_contact_overrides
        from govpal.discovery.local.la import LARegionalSource

        source = LARegionalSource()
        lookup_result = source.lookup(lat, lng)
    except Exception as e:
        _log.warning("LA local lookup failed: %s", e)
        return []

    reps: list[Rep] = []
    layer_keys = [
        ("city", "city_district"),
        ("county", "county_district"),
        ("neighborhood", "neighborhood"),
    ]
    for layer_key, result_key in layer_keys:
        district_val = lookup_result.get(result_key)
        if not district_val:
            continue
        jurisdiction = _LA_JURISDICTION_BY_LAYER.get(layer_key) or region
        try:
            overrides = get_contact_overrides(
                layer_key,
                jurisdiction=jurisdiction,
                district=district_val,
                config=config,
            )
        except Exception as e:
            _log.warning(
                "get_contact_overrides(%s, %s, %s) failed: %s",
                layer_key,
                jurisdiction,
                district_val,
                e,
            )
            continue
        for o in overrides:
            reps.append(
                _contact_override_to_rep(o, layer_key, jurisdiction, district_val)
            )

    # City-wide officials (mayor) - query if address is within city limits
    if lookup_result.get("city_district"):
        jurisdiction_city = _LA_JURISDICTION_BY_LAYER.get("city") or region
        try:
            mayor_overrides = get_contact_overrides(
                "mayor",
                jurisdiction=jurisdiction_city,
                config=config,
            )
            for o in mayor_overrides:
                reps.append(
                    _contact_override_to_rep(o, "mayor", jurisdiction_city, "")
                )
        except Exception as e:
            _log.warning("mayor lookup failed: %s", e)

    return reps
