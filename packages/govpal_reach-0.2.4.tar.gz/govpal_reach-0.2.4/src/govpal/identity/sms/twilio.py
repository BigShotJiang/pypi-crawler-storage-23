"""Twilio SMS + Verify API – SMSProvider impl. (Primary implementation.)"""

import os
from typing import Optional

from govpal.identity.sms.interfaces import SMSProvider


class TwilioProvider(SMSProvider):
    """Twilio implementation: SMS send + Verify API (OTP send/validate)."""

    def __init__(
        self,
        account_sid: str | None = None,
        auth_token: str | None = None,
        phone_number: str | None = None,
        verify_service_sid: str | None = None,
    ) -> None:
        self.account_sid = account_sid or os.environ.get("TWILIO_ACCOUNT_SID", "")
        self.auth_token = auth_token or os.environ.get("TWILIO_AUTH_TOKEN", "")
        self.phone_number = phone_number or os.environ.get("TWILIO_PHONE_NUMBER", "")
        self.verify_service_sid = verify_service_sid or os.environ.get(
            "TWILIO_VERIFY_SERVICE_SID", ""
        )

    def send(self, to: str, message: str) -> bool:
        """Send SMS via Twilio Messages API. Returns True if accepted, False otherwise. Requires TWILIO_PHONE_NUMBER (or phone_number in constructor) as the 'from' number."""
        if not self.account_sid or not self.auth_token or not to:
            return False
        if not self.phone_number:
            raise ValueError(
                "Twilio phone number (TWILIO_PHONE_NUMBER) is required for generic SMS send. "
                "Configure it in env or pass phone_number to TwilioProvider() if you need to send non-OTP messages."
            )
        try:
            from twilio.rest import Client

            client = Client(self.account_sid, self.auth_token)
            client.messages.create(
                from_=self.phone_number,
                to=to,
                body=message,
            )
            return True
        except Exception:
            return False

    def verify_send(
        self, recipient: str, channel: str = "sms"
    ) -> tuple[bool, Optional[str], Optional[str]]:
        """
        Create a Twilio Verify verification (send OTP to recipient).
        Returns (success, verification_sid or None, error_message or None).
        verification_sid is needed for verify_validate.
        """
        if (
            not self.account_sid
            or not self.auth_token
            or not self.verify_service_sid
            or not recipient
        ):
            return (
                False,
                None,
                "Missing Twilio credentials or recipient (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_VERIFY_SERVICE_SID)",
            )
        try:
            from twilio.rest import Client

            client = Client(self.account_sid, self.auth_token)
            verification = client.verify.v2.services(
                self.verify_service_sid
            ).verifications.create(to=recipient, channel=channel)
            sid = getattr(verification, "sid", None)
            return True, sid, None
        except Exception as e:
            err = str(e).strip() or repr(e)
            return False, None, err

    def verify_validate(self, session_id: str, otp: str) -> bool:
        """
        Validate OTP with Twilio Verify. Returns True if verification check is approved.
        """
        if (
            not self.account_sid
            or not self.auth_token
            or not self.verify_service_sid
            or not session_id
            or not otp
        ):
            return False
        try:
            from twilio.rest import Client

            client = Client(self.account_sid, self.auth_token)
            check = client.verify.v2.services(
                self.verify_service_sid
            ).verification_checks.create(verification_sid=session_id, code=otp)
            status = (getattr(check, "status", "") or "").lower()
            return status == "approved"
        except Exception:
            return False
