"""Plivo SMS + Verify API – SMSProvider impl. (Implementation: Phase 3.)"""

import os
from typing import Optional

from govpal.identity.sms.interfaces import SMSProvider


class PlivoProvider(SMSProvider):
    """Plivo implementation: SMS send + Verify API (OTP send/validate)."""

    def __init__(
        self,
        auth_id: str | None = None,
        auth_token: str | None = None,
        src_number: str | None = None,
        verify_app_uuid: str | None = None,
    ) -> None:
        self.auth_id = auth_id or os.environ.get("PLIVO_AUTH_ID", "")
        self.auth_token = auth_token or os.environ.get("PLIVO_AUTH_TOKEN", "")
        self.src_number = src_number or os.environ.get("PLIVO_SRC_NUMBER", "")
        self.verify_app_uuid = verify_app_uuid or os.environ.get(
            "PLIVO_VERIFY_APP_UUID", ""
        )

    def send(self, to: str, message: str) -> bool:
        """Send SMS via Plivo. Returns True if accepted (202), False otherwise."""
        if not self.auth_id or not self.auth_token or not self.src_number or not to:
            return False
        try:
            import plivo

            client = plivo.RestClient(self.auth_id, self.auth_token)
            resp = client.messages.create(
                src=self.src_number,
                dst=to,
                text=message,
            )
            return getattr(resp, "status_code", resp) == 202
        except Exception:
            return False

    def verify_send(
        self, recipient: str, channel: str = "sms"
    ) -> tuple[bool, Optional[str], Optional[str]]:
        """
        Create a Plivo Verify session (send OTP to recipient).
        Returns (success, session_uuid or None, error_message or None).
        session_uuid is needed for verify_validate.
        """
        if (
            not self.auth_id
            or not self.auth_token
            or not self.verify_app_uuid
            or not recipient
        ):
            return (
                False,
                None,
                "Missing Plivo credentials or recipient (PLIVO_AUTH_ID, PLIVO_AUTH_TOKEN, PLIVO_VERIFY_APP_UUID)",
            )
        try:
            import plivo

            client = plivo.RestClient(self.auth_id, self.auth_token)
            response = client.verify_session.create(
                recipient=recipient,
                app_uuid=self.verify_app_uuid,
                channel=channel,
            )
            session_uuid = getattr(response, "session_uuid", None)
            return True, session_uuid, None
        except Exception as e:
            err = str(e).strip() or repr(e)
            return False, None, err

    def verify_validate(self, session_uuid: str, otp: str) -> bool:
        """
        Validate OTP with Plivo Verify. Returns True if session validated successfully.
        """
        if not self.auth_id or not self.auth_token or not session_uuid or not otp:
            return False
        try:
            import plivo

            client = plivo.RestClient(self.auth_id, self.auth_token)
            response = client.verify_session.validate(
                session_uuid=session_uuid,
                otp=otp,
            )
            msg = (getattr(response, "message", "") or "").lower()
            return "validated" in msg and "success" in msg
        except Exception:
            return False
