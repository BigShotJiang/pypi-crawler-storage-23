"""User, UserProfile models. (Implementation: Phase 3.)"""

from dataclasses import dataclass
from datetime import datetime
from uuid import UUID


@dataclass
class User:
    """User row: phone identity and verification state."""

    id: UUID
    phone: str
    phone_verified: bool
    created_at: datetime
    verify_session_uuid: str | None = None

    @classmethod
    def from_row(
        cls,
        id: UUID,
        phone: str,
        phone_verified: bool,
        created_at: datetime,
        verify_session_uuid: str | None = None,
    ) -> "User":
        return cls(
            id=id,
            phone=phone,
            phone_verified=phone_verified,
            created_at=created_at,
            verify_session_uuid=verify_session_uuid,
        )


@dataclass
class UserProfile:
    """User profile with plaintext PII (encrypt on persist, decrypt on load)."""

    user_id: UUID
    first_name: str | None = None
    last_name: str | None = None
    address: str | None = None  # legacy / full display; prefer parts when present
    email: str | None = None
    zip_code: str | None = None  # 5-digit or ZIP+4
    street_address_1: str | None = None
    street_address_2: str | None = None
    city: str | None = None
    state: str | None = None
    updated_at: datetime | None = None

    @classmethod
    def from_row(
        cls,
        user_id: UUID,
        first_name: str | None,
        last_name: str | None,
        address: str | None,
        email: str | None,
        zip_code: str | None,
        updated_at: datetime | None,
        street_address_1: str | None = None,
        street_address_2: str | None = None,
        city: str | None = None,
        state: str | None = None,
    ) -> "UserProfile":
        return cls(
            user_id=user_id,
            first_name=first_name,
            last_name=last_name,
            address=address,
            email=email,
            zip_code=zip_code,
            updated_at=updated_at,
            street_address_1=street_address_1,
            street_address_2=street_address_2,
            city=city,
            state=state,
        )

    def full_address_for_display(self) -> str:
        """Build one-line address for display/email from parts (street, city, state zip)."""
        parts = []
        if self.street_address_1:
            parts.append(self.street_address_1)
        if self.street_address_2:
            parts.append(self.street_address_2)
        if self.city or self.state or self.zip_code:
            loc = ", ".join(filter(None, [self.city, self.state]))
            if self.zip_code:
                loc = f"{loc} {self.zip_code}".strip() if loc else self.zip_code
            if loc:
                parts.append(loc)
        if parts:
            return ", ".join(parts)
        return self.address or ""
