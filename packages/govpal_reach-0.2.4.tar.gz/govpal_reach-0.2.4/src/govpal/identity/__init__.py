"""Identity – users, PII encryption, SMS/OTP, address parsing."""

from govpal.identity.address import parse_address
from govpal.identity.models import User, UserProfile
from govpal.identity.pii import decrypt_field, encrypt_field
from govpal.identity.repository import (
    create_user,
    delete_user_by_phone,
    get_or_create_user,
    get_profile,
    get_user_by_phone,
    update_phone_verified,
    update_verify_session_uuid,
    upsert_profile,
)
from govpal.identity.sms.interfaces import SMSProvider
from govpal.identity.sms.otp import request_otp, verify_otp
from govpal.identity.sms.plivo import PlivoProvider
from govpal.identity.sms.provider import get_sms_provider
from govpal.identity.sms.twilio import TwilioProvider
from govpal.identity.tokens import generate_identity_token, validate_identity_token

__all__ = [
    "User",
    "UserProfile",
    "encrypt_field",
    "decrypt_field",
    "create_user",
    "delete_user_by_phone",
    "get_or_create_user",
    "get_profile",
    "get_user_by_phone",
    "parse_address",
    "update_phone_verified",
    "update_verify_session_uuid",
    "upsert_profile",
    "SMSProvider",
    "TwilioProvider",
    "PlivoProvider",
    "get_sms_provider",
    "request_otp",
    "verify_otp",
    "generate_identity_token",
    "validate_identity_token",
]
