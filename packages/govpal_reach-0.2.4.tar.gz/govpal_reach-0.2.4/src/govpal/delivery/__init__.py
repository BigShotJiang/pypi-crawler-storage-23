"""Delivery – message sending (email, webform). Pluggable DeliveryProvider, EmailProvider."""

from govpal.delivery.email import (
    CapturingEmailProvider,
    EmailProvider,
    PostmarkProvider,
    RedirectingEmailProvider,
    RedirectRecord,
    SentEmail,
    get_capturing_provider,
)

__all__ = [
    "CapturingEmailProvider",
    "EmailProvider",
    "PostmarkProvider",
    "RedirectingEmailProvider",
    "RedirectRecord",
    "SentEmail",
    "get_capturing_provider",
]
