"""Composite DeliveryProvider – routes email and webform by delivery_method."""

import logging

from govpal.delivery.email.format import (
    format_constituent_email_body,
    get_honorific_for_rep,
    get_last_name_from_rep,
)
from govpal.delivery.email.interfaces import EmailProvider
from govpal.delivery.interfaces import (
    DeliveryProvider,
    MessageContent,
    Rep,
    UserProfile,
)
from govpal.delivery.webform.driver import PlaywrightWebformDriver, WebformDriver

_log = logging.getLogger(__name__)

# Default CSS selectors for webform fields (override via form_field_map).
DEFAULT_FORM_FIELD_MAP: dict[str, str] = {
    "subject": "input[name=subject]",
    "body": "textarea[name=body]",
    "email": "input[name=email]",
    "first_name": "input[name=first_name]",
    "last_name": "input[name=last_name]",
}


class CompositeDeliveryProvider(DeliveryProvider):
    """
    Single DeliveryProvider that routes to email (EmailProvider) or webform (WebformDriver).

    For email: formats body with constituent preamble/closing and sends via EmailProvider.
    For webform: builds form_data from message and user_profile using form_field_map and submits via WebformDriver.
    """

    def __init__(
        self,
        *,
        email_provider: EmailProvider | None = None,
        webform_driver: WebformDriver | None = None,
        form_field_map: dict[str, str] | None = None,
    ) -> None:
        self._email_provider = email_provider
        self._webform_driver = webform_driver or PlaywrightWebformDriver()
        self._form_field_map = form_field_map or dict(DEFAULT_FORM_FIELD_MAP)

    def deliver(
        self,
        message: MessageContent,
        rep: Rep,
        user_profile: UserProfile,
        delivery_method: str,
    ) -> bool:
        if delivery_method == "email":
            return self._deliver_email(message, rep, user_profile)
        if delivery_method == "webform":
            return self._deliver_webform(message, rep, user_profile)
        _log.warning("Unknown delivery_method %s", delivery_method)
        return False

    def _deliver_email(
        self,
        message: MessageContent,
        rep: Rep,
        user_profile: UserProfile,
    ) -> bool:
        provider = self._email_provider
        if not provider:
            from govpal.delivery.email.postmark import PostmarkProvider

            provider = PostmarkProvider()
        to_email = (rep.get("contact_email") or "").strip()
        if not to_email:
            return False
        subject = (message.get("subject") or "").strip()
        body = (message.get("body") or "").strip()
        honorific = get_honorific_for_rep(rep)
        rep_last = get_last_name_from_rep(rep)
        first = (user_profile.get("first_name") or "").strip()
        last = (user_profile.get("last_name") or "").strip()
        address = (user_profile.get("address") or "").strip()
        phone = (user_profile.get("phone") or "").strip()
        full_body = format_constituent_email_body(
            body,
            honorific=honorific,
            last_name=rep_last,
            constituent_first=first,
            constituent_last=last,
            address=address,
            phone=phone,
        )
        from_name = f"{first} {last}".strip() or None
        reply_to = (user_profile.get("email") or "").strip() or None
        return provider.send(
            to=to_email,
            subject=subject,
            body=full_body,
            from_name=from_name,
            reply_to=reply_to,
        )

    def _deliver_webform(
        self,
        message: MessageContent,
        rep: Rep,
        user_profile: UserProfile,
    ) -> bool:
        form_url = (rep.get("contact_form_url") or "").strip()
        if not form_url:
            return False
        form_data: dict[str, str] = {}
        map_ = self._form_field_map
        if "subject" in map_:
            form_data[map_["subject"]] = (message.get("subject") or "").strip()
        if "body" in map_:
            form_data[map_["body"]] = (message.get("body") or "").strip()
        if "email" in map_:
            form_data[map_["email"]] = (user_profile.get("email") or "").strip()
        if "first_name" in map_:
            form_data[map_["first_name"]] = (
                user_profile.get("first_name") or ""
            ).strip()
        if "last_name" in map_:
            form_data[map_["last_name"]] = (user_profile.get("last_name") or "").strip()
        return self._webform_driver.submit(form_url, form_data)
