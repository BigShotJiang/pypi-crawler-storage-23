"""PGQueuer wrapper – delivery queue."""

import json
import logging
import os
from typing import TYPE_CHECKING, Protocol

_log = logging.getLogger(__name__)

if TYPE_CHECKING:
    from govpal.config import Config

try:
    import psycopg
    from pgqueuer.db import SyncPsycopgDriver
    from pgqueuer.queries import Queries

    _PGQUEUER_AVAILABLE = True
except ImportError:
    _PGQUEUER_AVAILABLE = False

QUEUE_ENTRYPOINT = "delivery"


class DeliveryQueue(Protocol):
    """Protocol for delivery queue – enqueue jobs for message delivery."""

    def enqueue_delivery(
        self,
        message_id: str,
        representative_id: str,
        delivery_method: str,
    ) -> list[str]:
        """
        Enqueue a delivery job.

        Args:
            message_id: UUID of the message record.
            representative_id: UUID of the representative.
            delivery_method: 'email' or 'webform'.

        Returns:
            List of PGQueuer job IDs.
        """
        ...


class PGQueuerDeliveryQueue:
    """Delivery queue backed by PGQueuer (Postgres)."""

    def __init__(
        self,
        dsn: str | None = None,
        *,
        config: "Config | None" = None,
    ) -> None:
        self.dsn = (
            dsn
            or (getattr(config, "database_url", None) if config else None)
            or os.environ.get("DATABASE_URL", "")
        )

    def enqueue_delivery(
        self,
        message_id: str,
        representative_id: str,
        delivery_method: str,
    ) -> list[str]:
        if not self.dsn:
            return []
        payload = {
            "message_id": message_id,
            "representative_id": representative_id,
            "delivery_method": delivery_method,
        }
        payload_bytes = json.dumps(payload).encode("utf-8")
        if not _PGQUEUER_AVAILABLE:
            return []
        try:
            with psycopg.connect(self.dsn, autocommit=True) as conn:
                driver = SyncPsycopgDriver(conn)
                queries = Queries(driver)
                job_ids = queries.enqueue(QUEUE_ENTRYPOINT, payload_bytes)
                return [str(j) for j in job_ids]
        except Exception as e:
            _log.warning("PGQueuer enqueue failed: %s", e)
            return []


class MockDeliveryQueue:
    """In-memory delivery queue for testing."""

    def __init__(self) -> None:
        self.jobs: list[dict] = []

    def enqueue_delivery(
        self,
        message_id: str,
        representative_id: str,
        delivery_method: str,
    ) -> list[str]:
        job = {
            "message_id": message_id,
            "representative_id": representative_id,
            "delivery_method": delivery_method,
        }
        self.jobs.append(job)
        return [f"mock-{len(self.jobs)}"]
