"""Playwright wrapper – webform automation."""

import logging
from typing import Protocol

_log = logging.getLogger(__name__)

try:
    from playwright.sync_api import sync_playwright

    _PLAYWRIGHT_AVAILABLE = True
except ImportError:
    sync_playwright = None  # type: ignore[misc, assignment]
    _PLAYWRIGHT_AVAILABLE = False


class WebformDriver(Protocol):
    """Protocol for webform submission – fill fields and click submit."""

    def submit(
        self,
        form_url: str,
        form_data: dict[str, str],
        *,
        submit_selector: str = "button[type=submit]",
        timeout_ms: int = 30_000,
    ) -> bool:
        """
        Submit a web form.

        Args:
            form_url: URL of the form page.
            form_data: Dict mapping CSS selector -> value for each field.
            submit_selector: CSS selector for the submit button.
            timeout_ms: Timeout for navigation and actions.

        Returns:
            True if submission succeeded (no exception), False otherwise.
        """
        ...


class PlaywrightWebformDriver:
    """Webform driver using Playwright (headless browser)."""

    def submit(
        self,
        form_url: str,
        form_data: dict[str, str],
        *,
        submit_selector: str = "button[type=submit]",
        timeout_ms: int = 30_000,
    ) -> bool:
        if not _PLAYWRIGHT_AVAILABLE or sync_playwright is None:
            return False
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                page = browser.new_page()
                try:
                    page.goto(form_url, timeout=timeout_ms)
                    for selector, value in form_data.items():
                        page.fill(selector, value, timeout=timeout_ms)
                    page.click(submit_selector, timeout=timeout_ms)
                    return True
                finally:
                    browser.close()
        except Exception as e:
            _log.warning("Webform submission failed: %s", e)
            return False
