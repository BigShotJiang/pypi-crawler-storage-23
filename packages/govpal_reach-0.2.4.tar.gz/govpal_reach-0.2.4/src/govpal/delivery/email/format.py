"""Constituent email body formatter, honorific by level, and constituent info validation."""

import os
from typing import TYPE_CHECKING, TypedDict

from govpal.delivery.interfaces import Rep

if TYPE_CHECKING:
    from govpal.config import Config

# Default brand for "on behalf of" From display name (override via GOVPAL_EMAIL_FROM_BRAND).
DEFAULT_FROM_BRAND = "GovPal Reach"


class ConstituentInfo(TypedDict, total=False):
    """Constituent fields required for sending messages. street_address_2 optional."""

    first_name: str
    last_name: str
    street_address_1: str
    city: str
    state: str
    zip_code: str
    phone: str
    email: str
    street_address_2: str


def parse_full_name(full_name: str) -> tuple[str, str]:
    """
    Parse a full name into first and last. Single name becomes (name, name).
    Returns (first_name, last_name) with leading/trailing whitespace stripped.
    """
    parts = (full_name or "").strip().split()
    if not parts:
        return ("", "")
    if len(parts) == 1:
        return (parts[0], parts[0])
    return (parts[0], " ".join(parts[1:]))


_REQUIRED_CONSTITUENT_FIELDS: list[tuple[str, str]] = [
    ("first_name", "first name"),
    ("last_name", "last name"),
    ("street_address_1", "street address"),
    ("city", "city"),
    ("state", "state"),
    ("zip_code", "ZIP code"),
    ("phone", "phone number"),
    ("email", "email"),
]


def validate_constituent_info_from_dict(
    info: ConstituentInfo,
) -> tuple[bool, str | None]:
    """
    Require all constituent fields before sending a message.
    Returns (True, None) if valid, (False, error_message) if any missing.
    """
    values = {
        "first_name": (info.get("first_name") or "").strip(),
        "last_name": (info.get("last_name") or "").strip(),
        "street_address_1": (info.get("street_address_1") or "").strip(),
        "city": (info.get("city") or "").strip(),
        "state": (info.get("state") or "").strip(),
        "zip_code": (info.get("zip_code") or "").strip(),
        "phone": (info.get("phone") or "").strip(),
        "email": (info.get("email") or "").strip(),
    }
    for key, label in _REQUIRED_CONSTITUENT_FIELDS:
        if not values[key]:
            return False, f"Missing {label} (required for sending messages)"
    return True, None


def validate_constituent_info(
    first_name: str,
    last_name: str,
    street_address_1: str,
    city: str,
    state: str,
    zip_code: str,
    phone: str,
    email: str,
    street_address_2: str | None = None,
) -> tuple[bool, str | None]:
    """
    Require all constituent fields before sending a message.
    Address must be passed as separate fields (street_address_1, city, state, zip_code).
    Returns (True, None) if valid, (False, error_message) if any missing.
    """
    return validate_constituent_info_from_dict(
        {
            "first_name": first_name,
            "last_name": last_name,
            "street_address_1": street_address_1,
            "city": city,
            "state": state,
            "zip_code": zip_code,
            "phone": phone,
            "email": email,
            **(
                {"street_address_2": street_address_2}
                if street_address_2 is not None
                else {}
            ),
        }
    )


def format_on_behalf_of_from_name(
    first_name: str,
    last_name: str,
    email: str,
    *,
    brand: str | None = None,
    config: "Config | None" = None,
) -> str:
    """
    Build the From display name for sending on behalf of a constituent.

    Format: "{brand} (on behalf of {First Last <email>})".
    Brand defaults to config.govpal_email_from_brand (if config given), then
    GOVPAL_EMAIL_FROM_BRAND env var, then DEFAULT_FROM_BRAND.

    Args:
        first_name: Constituent first name.
        last_name: Constituent last name.
        email: Constituent email (in angle brackets).
        brand: Optional brand string; if None, uses config/env or DEFAULT_FROM_BRAND.
        config: Optional Config; when provided, brand fallback uses config.govpal_email_from_brand.

    Returns:
        String suitable for EmailProvider.send(from_name=...).
    """
    first_name = (first_name or "").strip()
    last_name = (last_name or "").strip()
    email = (email or "").strip()
    if brand:
        pass
    elif config and (config.govpal_email_from_brand or "").strip():
        brand = config.govpal_email_from_brand.strip()
    else:
        brand = (
            os.environ.get("GOVPAL_EMAIL_FROM_BRAND", "").strip()
        ) or DEFAULT_FROM_BRAND
    constituent = f"{first_name} {last_name}".strip() or "Constituent"
    return f"{brand} (on behalf of {constituent} <{email}>)"


def format_address_for_display(address: str) -> str:
    """
    Format address for email closing: split on first comma into street and city/state/zip.
    E.g. "820 Indiana Ave, Venice, CA 90291" -> "820 Indiana Ave" then "Venice, CA 90291".
    """
    if not (address or "").strip():
        return ""
    parts = [p.strip() for p in (address or "").split(",", 1) if p.strip()]
    return "\n".join(parts)


def format_phone_for_display(phone: str) -> str:
    """
    Format phone for email closing. US E.164 (+1XXXXXXXXXX) -> (XXX) XXX-XXXX.
    Other numbers returned as-is.
    """
    s = (phone or "").strip()
    if not s:
        return ""
    digits = "".join(c for c in s if c.isdigit())
    if s.startswith("+1") and len(digits) == 11 and digits.startswith("1"):
        ten = digits[1:]
        return f"({ten[0:3]}) {ten[3:6]}-{ten[6:]}"
    if len(digits) == 10 and not s.startswith("+"):
        return f"({digits[0:3]}) {digits[3:6]}-{digits[6:]}"
    return s


# Default honorific by rep level when rep does not have an explicit honorific.
# Local reps may override via representatives.honorific (database) or rep["honorific"].
DEFAULT_HONORIFIC_BY_LEVEL: dict[str, str] = {
    "federal": "Representative",
    "state": "Senator",
    "county": "Supervisor",
    "city": "Councilmember",
    "neighborhood": "Representative",
    "local": "Representative",
    "test": "Representative",
}


def get_honorific_for_rep(rep: Rep) -> str:
    """Return honorific for a rep: rep['honorific'] if set, else default for rep['level']."""
    honorific = rep.get("honorific") or ""
    if honorific.strip():
        return honorific.strip()
    level = (rep.get("level") or "").strip().lower()
    return DEFAULT_HONORIFIC_BY_LEVEL.get(level, "Representative")


def get_last_name_from_rep(rep: Rep) -> str:
    """Return last name for greeting: rep['last_name'] if set, else last word of rep['name']."""
    last = (rep.get("last_name") or "").strip()
    if last:
        return last
    name = (rep.get("name") or "").strip()
    parts = name.split()
    return parts[-1] if parts else "Representative"


def format_constituent_email_body(
    body: str,
    *,
    honorific: str,
    last_name: str,
    constituent_first: str,
    constituent_last: str,
    address: str,
    phone: str,
) -> str:
    """
    Format an email body with greeting and closing.

    Template:
        Dear [HONORIFIC] [LAST_NAME],

        [BODY]

        Thank you for your time.

        Sincerely,

        [FIRST LAST]
        Constituent

        [ADDRESS]
        [PHONE]
    """
    greeting = f"Dear {honorific} {last_name},"
    closing = (
        "Thank you for your time.\n\n"
        "Sincerely,\n\n"
        f"{constituent_first} {constituent_last}\n"
        "Constituent"
    )
    addr_display = format_address_for_display(address)
    phone_display = format_phone_for_display(phone)
    if addr_display:
        closing += f"\n\n{addr_display}"
    if phone_display:
        closing += f"\n\n{phone_display}" if not addr_display else f"\n{phone_display}"
    return f"{greeting}\n\n{body.strip()}\n\n{closing}"
