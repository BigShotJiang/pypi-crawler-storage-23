"""Email providers – ABC EmailProvider, Postmark, Capturing, Redirecting."""

from govpal.delivery.email.capturing import (
    CapturingEmailProvider,
    SentEmail,
    get_capturing_provider,
)
from govpal.delivery.email.interfaces import EmailProvider
from govpal.delivery.email.postmark import PostmarkProvider
from govpal.delivery.email.redirecting import RedirectingEmailProvider, RedirectRecord

__all__ = [
    "CapturingEmailProvider",
    "EmailProvider",
    "PostmarkProvider",
    "RedirectingEmailProvider",
    "RedirectRecord",
    "SentEmail",
    "get_capturing_provider",
]
