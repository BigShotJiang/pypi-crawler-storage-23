"""Postmark – EmailProvider impl."""

import json
import os
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from govpal.delivery.email.interfaces import EmailProvider

POSTMARK_URL = "https://api.postmarkapp.com/email"


class PostmarkProvider(EmailProvider):
    """Postmark email provider."""

    def __init__(
        self,
        server_token: str | None = None,
        from_address: str | None = None,
    ) -> None:
        self.server_token = server_token or os.environ.get("POSTMARK_SERVER_TOKEN", "")
        self.from_address = from_address or os.environ.get("POSTMARK_FROM_ADDRESS", "")

    def send(
        self,
        to: str,
        subject: str,
        body: str,
        *,
        from_name: str | None = None,
        reply_to: str | None = None,
    ) -> bool:
        if not self.server_token or not self.from_address or not to:
            return False
        from_header = self._format_from(from_name)
        payload = {
            "From": from_header,
            "To": to,
            "Subject": subject,
            "TextBody": body,
        }
        if reply_to:
            payload["ReplyTo"] = reply_to
        try:
            body_bytes = json.dumps(payload).encode("utf-8")
            req = Request(
                POSTMARK_URL,
                data=body_bytes,
                method="POST",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "X-Postmark-Server-Token": self.server_token,
                    "User-Agent": "GovPal-Reach/1.0",
                },
            )
            with urlopen(req, timeout=10) as resp:
                if resp.status != 200:
                    return False
                data = json.loads(resp.read().decode("utf-8"))
                return data.get("ErrorCode", 1) == 0
        except (HTTPError, URLError, OSError, ValueError, KeyError):
            return False

    def _format_from(self, from_name: str | None) -> str:
        if not from_name:
            return self.from_address
        # Quote display name when it contains angle brackets so inner <email> is not parsed as address
        if "<" in from_name or ">" in from_name:
            quoted = from_name.replace("\\", "\\\\").replace('"', '\\"')
            return f'"{quoted}" <{self.from_address}>'
        return f"{from_name} <{self.from_address}>"
