"""ABC: EmailProvider."""

from abc import ABC, abstractmethod


class EmailProvider(ABC):
    """Abstract email provider. Current implementation: Postmark."""

    @abstractmethod
    def send(
        self,
        to: str,
        subject: str,
        body: str,
        *,
        from_name: str | None = None,
        reply_to: str | None = None,
    ) -> bool:
        """
        Send an email.

        Args:
            to: Recipient email address.
            subject: Email subject.
            body: Plain or HTML body.
            from_name: Display name for the From header (optional).
            reply_to: Reply-To header (optional; user's email for send-on-behalf).

        Returns:
            True if accepted for delivery, False otherwise.
        """
        pass
