"""CapturingEmailProvider: records emails in memory without sending. For testing and dry-run."""

import logging
import os
from datetime import datetime, timezone
from typing import TypedDict

from govpal.delivery.email.interfaces import EmailProvider

_log = logging.getLogger(__name__)

# Log level mapping: supports both numeric (0-3) and semantic names
_LEVEL_MAP = {"none": 0, "minimal": 1, "basic": 2, "verbose": 3}
_DEFAULT_LEVEL = 2  # basic


def _get_log_level() -> int:
    """Get capture log level from GP_CAPTURE_LOG_LEVEL env var."""
    raw = os.environ.get("GP_CAPTURE_LOG_LEVEL", "").strip().lower()
    if not raw:
        return _DEFAULT_LEVEL
    if raw.isdigit():
        return int(raw)
    return _LEVEL_MAP.get(raw, _DEFAULT_LEVEL)


class SentEmail(TypedDict, total=False):
    """Record of a captured (not sent) email."""

    to: str
    subject: str
    body: str
    from_name: str | None
    reply_to: str | None
    timestamp: str


class CapturingEmailProvider(EmailProvider):
    """
    Records all emails in memory without sending.

    Use for unit tests, dry-runs, and validating recipient selection logic
    without sending real emails. Implements EmailProvider.

    Logging controlled by GP_CAPTURE_LOG_LEVEL env var:
    - 0 / "none": No logging (default for tests)
    - 1 / "minimal": Just to: addresses
    - 2 / "basic": Headers + first line of body (default)
    - 3 / "verbose": Full email on first send, then just to: addresses
    """

    def __init__(self) -> None:
        self.sent: list[SentEmail] = []
        self._verbose_logged: bool = False

    def send(
        self,
        to: str,
        subject: str,
        body: str,
        *,
        from_name: str | None = None,
        reply_to: str | None = None,
    ) -> bool:
        self.sent.append(
            {
                "to": to,
                "subject": subject,
                "body": body,
                "from_name": from_name,
                "reply_to": reply_to,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        )

        # Log based on configured level
        level = _get_log_level()
        if level == 0:
            # No logging
            pass
        elif level == 1:
            # Minimal: just to address
            _log.info(f"[capture] to: {to}")
        elif level == 2:
            # Basic: headers + first line
            first_line = body.splitlines()[0] if body else ""
            _log.info(
                f"[capture] from={from_name} to={to} reply_to={reply_to} "
                f"subject={subject}\n  {first_line}"
            )
        elif level >= 3:
            # Verbose: full email once, then just addresses
            if not self._verbose_logged:
                _log.info(
                    f"[capture] FULL EMAIL:\n"
                    f"  from: {from_name}\n"
                    f"  to: {to}\n"
                    f"  reply_to: {reply_to}\n"
                    f"  subject: {subject}\n"
                    f"  body:\n{body}"
                )
                self._verbose_logged = True
            else:
                _log.info(f"[capture] to: {to}")

        return True

    def get_recipients(self) -> list[str]:
        """Return list of all recipient addresses that would have been sent to."""
        return [e["to"] for e in self.sent]

    def get_emails_to(self, address: str) -> list[SentEmail]:
        """Return all captured emails for the given recipient address."""
        return [e for e in self.sent if e.get("to") == address]

    def clear(self) -> None:
        """Clear the captured emails list and reset verbose logging flag."""
        self.sent.clear()
        self._verbose_logged = False

    def assert_sent_count(self, n: int) -> None:
        """Assert that exactly n emails were captured. Raises AssertionError if not."""
        if len(self.sent) != n:
            raise AssertionError(
                f"Expected {n} emails to be captured, got {len(self.sent)}: "
                f"recipients={self.get_recipients()}"
            )


_capturing_singleton: CapturingEmailProvider | None = None


def get_capturing_provider() -> CapturingEmailProvider:
    """Return the process-level CapturingEmailProvider singleton. Creates on first call."""
    global _capturing_singleton
    if _capturing_singleton is None:
        _capturing_singleton = CapturingEmailProvider()
    return _capturing_singleton
