"""ABC: RepProvider, GeocodingProvider."""

from abc import ABC, abstractmethod
from typing import TypedDict


class Rep(TypedDict, total=False):
    """Normalized rep shape (all providers return this structure)."""

    level: str
    name: str
    office: str
    party: str | None
    district: str
    jurisdiction: str
    contact_email: str | None
    contact_form_url: str | None
    contact_phone: str | None
    photo_url: str | None
    data_source: str
    honorific: str | None
    last_name: str | None


class RepProvider(ABC):
    """Abstract representative lookup provider. Implementations: Google Civic, Open States."""

    @abstractmethod
    def get_reps_by_address(self, address: str) -> list[Rep]:
        """
        Look up representatives for a street address.

        Args:
            address: Full street address (e.g. "123 Main St, Los Angeles, CA 90012").

        Returns:
            List of rep dicts with at least: level, name, contact_email, data_source.
            May include: office, party, district, jurisdiction, contact_form_url, contact_phone, photo_url.
        """
        pass

    @abstractmethod
    def get_reps_by_coords(self, lat: float, lng: float) -> list[Rep]:
        """
        Look up representatives for a latitude/longitude point.

        Args:
            lat: Latitude.
            lng: Longitude.

        Returns:
            List of rep dicts (same shape as get_reps_by_address).
        """
        pass


class GeocodingProvider(ABC):
    """Abstract geocoding provider. Current implementation: Census Geocoder."""

    @abstractmethod
    def geocode(self, address: str) -> tuple[float, float] | None:
        """
        Geocode an address to (latitude, longitude).

        Args:
            address: Full street address.

        Returns:
            (lat, lng) tuple if found, None if not found or error.
        """
        pass
