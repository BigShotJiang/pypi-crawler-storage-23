"""Load open-local-people YAML and produce/upsert contact_overrides rows. Testable; used by setup_la_data script."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import psycopg
import yaml

# Govpal contact_overrides row shape for upsert
CONTACT_OVERRIDE_SOURCE = "open_local_people"

JURISDICTION_CITY = "Los Angeles"
JURISDICTION_COUNTY = "Los Angeles County"


def _contact_detail(details: list[dict], kind: str) -> str | None:
    """First contact_details entry with type=kind; return value or None."""
    if not details:
        return None
    for d in details:
        if d.get("type") == kind:
            return (d.get("value") or "").strip() or None
    return None


def _first_link_url(links: list[dict]) -> str | None:
    """First link url (e.g. district site / webform)."""
    if not links:
        return None
    for lnk in links:
        u = (lnk.get("url") or "").strip()
        if u:
            return u
    return None


def load_city_rows(data_dir: Path) -> list[dict[str, Any]]:
    """Load city officials (councilmembers and mayor) from data/us/ca/los_angeles/city/*.yml (exclude organization.yml). Return list of contact override dicts."""
    city_dir = data_dir / "us" / "ca" / "los_angeles" / "city"
    rows: list[dict[str, Any]] = []
    if not city_dir.is_dir():
        return rows
    for path in city_dir.glob("*.yml"):
        if path.name == "organization.yml":
            continue
        try:
            with open(path, encoding="utf-8") as f:
                data = yaml.safe_load(f)
        except Exception:
            continue
        if not data or not isinstance(data, dict):
            continue
        roles = data.get("roles") or []
        if not roles or not isinstance(roles, list):
            continue
        role = roles[0] if isinstance(roles[0], dict) else None
        if not role:
            continue
        role_type = role.get("type")
        if role_type == "councilmember":
            target_type = "city"
            district = str(role.get("district", "")).strip()
        elif role_type == "mayor":
            target_type = "mayor"
            district = ""
        else:
            continue
        name = (data.get("name") or "").strip() or ""
        contact_details = data.get("contact_details") or []
        links = data.get("links") or []
        email = _contact_detail(contact_details, "email")
        phone = _contact_detail(contact_details, "voice")
        webform_url = _contact_detail(contact_details, "url") or _first_link_url(links)
        rows.append(
            {
                "target_type": target_type,
                "jurisdiction": JURISDICTION_CITY,
                "district": district,
                "official_name": name,
                "email": email,
                "webform_url": webform_url,
                "phone": phone,
                "source": CONTACT_OVERRIDE_SOURCE,
            }
        )
    return rows


def load_county_rows(data_dir: Path) -> list[dict[str, Any]]:
    """Load county supervisor person YAMLs from data/us/ca/los_angeles/county/*.yml (exclude organization.yml)."""
    county_dir = data_dir / "us" / "ca" / "los_angeles" / "county"
    rows: list[dict[str, Any]] = []
    if not county_dir.is_dir():
        return rows
    for path in county_dir.glob("*.yml"):
        if path.name == "organization.yml":
            continue
        try:
            with open(path, encoding="utf-8") as f:
                data = yaml.safe_load(f)
        except Exception:
            continue
        if not data or not isinstance(data, dict):
            continue
        roles = data.get("roles") or []
        if not roles or not isinstance(roles, list):
            continue
        role = roles[0] if isinstance(roles[0], dict) else None
        if not role or role.get("type") != "supervisor":
            continue
        district = role.get("district")
        if district is None:
            district = ""
        district = str(district).strip()
        name = (data.get("name") or "").strip() or ""
        contact_details = data.get("contact_details") or []
        links = data.get("links") or []
        email = _contact_detail(contact_details, "email")
        phone = _contact_detail(contact_details, "voice")
        webform_url = _contact_detail(contact_details, "url") or _first_link_url(links)
        rows.append(
            {
                "target_type": "county",
                "jurisdiction": JURISDICTION_COUNTY,
                "district": district,
                "official_name": name,
                "email": email,
                "webform_url": webform_url,
                "phone": phone,
                "source": CONTACT_OVERRIDE_SOURCE,
            }
        )
    return rows


def load_neighborhood_rows(data_dir: Path) -> list[dict[str, Any]]:
    """Load NC organization.yml from data/us/ca/los_angeles/neighborhood_councils/<slug>/organization.yml. district = official_name (GeoHub match)."""
    nc_root = data_dir / "us" / "ca" / "los_angeles" / "neighborhood_councils"
    rows: list[dict[str, Any]] = []
    if not nc_root.is_dir():
        return rows
    for slug_dir in nc_root.iterdir():
        if not slug_dir.is_dir():
            continue
        org_path = slug_dir / "organization.yml"
        if not org_path.is_file():
            continue
        try:
            with open(org_path, encoding="utf-8") as f:
                data = yaml.safe_load(f)
        except Exception:
            continue
        if not data or not isinstance(data, dict):
            continue
        # district = official_name for GeoHub NC_NAME match
        official_name = (data.get("official_name") or data.get("name") or "").strip()
        if not official_name:
            continue
        name = (data.get("name") or official_name).strip()
        contact_details = data.get("contact_details") or []
        email = _contact_detail(contact_details, "email")
        phone = _contact_detail(contact_details, "voice")
        webform_url = _contact_detail(contact_details, "url")
        rows.append(
            {
                "target_type": "neighborhood",
                "jurisdiction": JURISDICTION_CITY,
                "district": official_name,
                "official_name": name,
                "email": email,
                "webform_url": webform_url,
                "phone": phone,
                "source": CONTACT_OVERRIDE_SOURCE,
            }
        )
    return rows


def load_all_rows(data_dir: Path) -> list[dict[str, Any]]:
    """Load city + county + neighborhood rows from open-local-people data dir."""
    return (
        load_city_rows(data_dir)
        + load_county_rows(data_dir)
        + load_neighborhood_rows(data_dir)
    )


def upsert_contact_overrides(dsn: str, rows: list[dict[str, Any]]) -> int:
    """Insert or update contact_overrides. Uses ON CONFLICT (target_type, jurisdiction, district) DO UPDATE. Returns number of rows upserted."""
    if not rows:
        return 0
    from govpal.db import gpr_table

    table = gpr_table("contact_overrides")
    sql = f"""
    INSERT INTO {table} (target_type, jurisdiction, district, official_name, email, webform_url, phone, source)
    VALUES (%(target_type)s, %(jurisdiction)s, %(district)s, %(official_name)s, %(email)s, %(webform_url)s, %(phone)s, %(source)s)
    ON CONFLICT (target_type, jurisdiction, district) DO UPDATE SET
      official_name = EXCLUDED.official_name,
      email = EXCLUDED.email,
      webform_url = EXCLUDED.webform_url,
      phone = EXCLUDED.phone,
      source = EXCLUDED.source
    """
    with psycopg.connect(dsn) as conn:
        with conn.cursor() as cur:
            for row in rows:
                cur.execute(
                    sql,
                    {
                        "target_type": row.get("target_type") or "",
                        "jurisdiction": row.get("jurisdiction"),
                        "district": row.get("district"),
                        "official_name": row.get("official_name"),
                        "email": row.get("email"),
                        "webform_url": row.get("webform_url"),
                        "phone": row.get("phone"),
                        "source": row.get("source") or CONTACT_OVERRIDE_SOURCE,
                    },
                )
            conn.commit()
    return len(rows)


def sync_contacts_from_path(
    dsn: str,
    open_local_people_path: str | Path,
) -> int:
    """Load all rows from open-local-people path and upsert into contact_overrides. Returns count upserted."""
    path = Path(open_local_people_path)
    data_dir = path / "data"
    if not data_dir.is_dir():
        raise FileNotFoundError(f"open-local-people data dir not found: {data_dir}")
    rows = load_all_rows(data_dir)
    return upsert_contact_overrides(dsn, rows)
