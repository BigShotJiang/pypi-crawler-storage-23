"""LA GeoHub, County, NC – RegionalSource impl. (Phase 4: LA Local.)"""

import json
import logging
from pathlib import Path
from typing import Any

_log = logging.getLogger(__name__)

from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from shapely.geometry import shape
from shapely.prepared import prep

from govpal.discovery.local.base import RegionalSource
from govpal.discovery.local.registry import get_region_config

# ArcGIS REST query: all features as GeoJSON, WGS84
_DEFAULT_OUT_SR = 4326
_USER_AGENT = "GovPal-Reach/1.0"
_TIMEOUT = 30


def _fetch_geojson(query_url: str) -> dict:
    """Request ArcGIS REST query endpoint; return GeoJSON dict. Raises on HTTP/parse error."""
    params = {
        "where": "1=1",
        "outFields": "*",
        "returnGeometry": "true",
        "f": "geojson",
        "outSR": _DEFAULT_OUT_SR,
    }
    url = f"{query_url}/query?{urlencode(params)}"
    req = Request(url, headers={"User-Agent": _USER_AGENT})
    with urlopen(req, timeout=_TIMEOUT) as resp:
        if resp.status != 200:
            raise HTTPError(url, resp.status, resp.reason, resp.headers, None)
        data = json.loads(resp.read().decode("utf-8"))
    return data


def _default_cache_dir() -> Path:
    """Default cache dir: govpal data/boundaries under package.

    Assumes package layout: govpal/discovery/local/la.py -> parent.parent.parent
    is govpal package root. Caller may pass cache_dir to override.
    """
    base = Path(__file__).resolve().parent.parent.parent  # govpal pkg root
    return base / "data" / "boundaries"


def _cache_path(cache_dir: Path, region: str, layer_key: str) -> Path:
    return cache_dir / f"{region.lower().replace(' ', '_')}_{layer_key}.geojson"


def fetch_and_cache_boundaries(
    region: str,
    layer_key: str,
    cache_dir: Path | None = None,
) -> dict:
    """
    Fetch GeoJSON for region/layer from registry endpoint; optionally write to cache_dir.
    Returns GeoJSON dict (features list).
    """
    config = get_region_config(region)
    if not config or layer_key not in config:
        return {"type": "FeatureCollection", "features": []}
    endpoint = config[layer_key]["endpoint"]
    geojson = _fetch_geojson(endpoint)
    cache_dir = cache_dir or _default_cache_dir()
    cache_dir.mkdir(parents=True, exist_ok=True)
    path = _cache_path(cache_dir, region, layer_key)
    with open(path, "w") as f:
        json.dump(geojson, f)
    return geojson


def load_boundaries(
    region: str,
    layer_key: str,
    cache_dir: Path | None = None,
    use_cache_file: bool = True,
) -> list[tuple[Any, dict]]:
    """
    Load boundary features for region/layer. If use_cache_file and cache file exists, read from disk.
    Otherwise fetch from API and optionally cache.
    Returns list of (shapely geometry, properties dict).
    """
    cache_dir = cache_dir or _default_cache_dir()
    path = _cache_path(cache_dir, region, layer_key)
    if use_cache_file and path.exists():
        with open(path) as f:
            geojson = json.load(f)
    else:
        geojson = fetch_and_cache_boundaries(region, layer_key, cache_dir)
    features = geojson.get("features") or []
    result = []
    for f in features:
        geom = f.get("geometry")
        if not geom:
            continue
        try:
            shape_geom = shape(geom)
            if shape_geom.is_empty:
                continue
            result.append((prep(shape_geom), f.get("properties") or {}))
        except Exception as e:
            _log.debug("Skipping invalid geometry: %s", e)
            continue
    return result


class LARegionalSource(RegionalSource):
    """
    LA regional source: Council Districts, Board of Supervisors, Neighborhood Councils.
    Uses LA GeoHub Boundaries MapServer; boundaries cached to data/boundaries or in-memory.
    """

    def __init__(
        self,
        cache_dir: Path | str | None = None,
        use_cache_file: bool = True,
    ) -> None:
        self._cache_dir = Path(cache_dir) if cache_dir else None
        self._use_cache_file = use_cache_file
        self._region = "Los Angeles"
        # In-memory cache: layer_key -> list of (prep geometry, properties)
        self._cache: dict[str, list[tuple[Any, dict]]] = {}

    def _get_layer(self, layer_key: str) -> list[tuple[Any, dict]]:
        if layer_key not in self._cache:
            self._cache[layer_key] = load_boundaries(
                self._region,
                layer_key,
                cache_dir=self._cache_dir,
                use_cache_file=self._use_cache_file,
            )
        return self._cache[layer_key]

    def _find_district(
        self,
        layer_key: str,
        lat: float,
        lng: float,
        name_field: str | None = None,
    ) -> str | None:
        from shapely.geometry import Point

        point = Point(lng, lat)
        config = get_region_config(self._region)
        if config and layer_key in config:
            name_field = name_field or config[layer_key].get("name_field", "DISTRICT")
        else:
            name_field = name_field or "DISTRICT"
        for prep_geom, props in self._get_layer(layer_key):
            if prep_geom.contains(point):
                name = (
                    props.get(name_field)
                    or props.get("name")
                    or props.get("NC_NAME")
                    or props.get("DISTRICT")
                    or str(props.get("OBJECTID", ""))
                )
                return str(name) if name is not None else None
        return None

    def lookup(self, lat: float, lng: float) -> dict[str, str | None]:
        result: dict[str, str | None] = {}
        result["city_district"] = self._find_district("city", lat, lng)
        result["county_district"] = self._find_district("county", lat, lng)
        result["neighborhood"] = self._find_district("neighborhood", lat, lng)
        return result
