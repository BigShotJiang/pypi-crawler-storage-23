"""GeocodingProvider impl (Census Geocoder only)."""

from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from govpal.discovery.interfaces import GeocodingProvider
from govpal.discovery.utils import parse_json

CENSUS_BASE = "https://geocoding.geo.census.gov/geocoder/locations/onelineaddress"


class CensusGeocoderProvider(GeocodingProvider):
    """Census Geocoder – address to (lat, lng). No API key required."""

    def __init__(self, benchmark: str = "Public_AR_Current") -> None:
        self.benchmark = benchmark

    def geocode(self, address: str) -> tuple[float, float] | None:
        if not address or not address.strip():
            return None
        params = {
            "address": address.strip(),
            "benchmark": self.benchmark,
            "format": "json",
        }
        url = f"{CENSUS_BASE}?{urlencode(params)}"
        try:
            req = Request(url, headers={"User-Agent": "GovPal-Reach/1.0"})
            with urlopen(req, timeout=10) as resp:
                if resp.status != 200:
                    return None
                data = parse_json(resp.read())
        except (HTTPError, URLError, OSError, ValueError):
            return None
        return _extract_coords(data)


def _extract_coords(data: dict) -> tuple[float, float] | None:
    try:
        matches = data.get("result", {}).get("addressMatches", [])
        if not matches:
            return None
        coords = matches[0].get("coordinates", {})
        x = coords.get("x")  # longitude
        y = coords.get("y")  # latitude
        if x is None or y is None:
            return None
        return (float(y), float(x))
    except (KeyError, TypeError, ValueError):
        return None
