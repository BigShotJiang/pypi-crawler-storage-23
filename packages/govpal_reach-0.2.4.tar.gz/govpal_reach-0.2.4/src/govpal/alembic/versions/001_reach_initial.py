"""GovPal Reach initial schema (users, profiles, reps, regional, contact_overrides, static_officials, messages).

Idempotent: uses create_table(..., if_not_exists=True). Safe to run after any library update.
Revision ID: 001_reach_initial
Revises:
Create Date: GovPal Reach schema

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "001_reach_initial"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            primary_key=True,
        ),
        sa.Column("phone", sa.String(20), nullable=False),
        sa.Column(
            "phone_verified", sa.Boolean(), server_default=sa.false(), nullable=True
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),
        if_not_exists=True,
    )
    op.create_unique_constraint("users_phone_key", "users", ["phone"])

    op.create_table(
        "user_profiles",
        sa.Column("user_id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("first_name_encrypted", postgresql.BYTEA(), nullable=True),
        sa.Column("last_name_encrypted", postgresql.BYTEA(), nullable=True),
        sa.Column("address_encrypted", postgresql.BYTEA(), nullable=True),
        sa.Column("email_encrypted", postgresql.BYTEA(), nullable=True),
        sa.Column("zip_code", sa.String(10), nullable=True),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),
        sa.PrimaryKeyConstraint("user_id"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        if_not_exists=True,
    )

    op.create_table(
        "representatives",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            primary_key=True,
        ),
        sa.Column("level", sa.String(20), nullable=False),
        sa.Column("office", sa.String(100), nullable=True),
        sa.Column("name", sa.String(200), nullable=True),
        sa.Column("party", sa.String(50), nullable=True),
        sa.Column("district", sa.String(50), nullable=True),
        sa.Column("jurisdiction", sa.String(100), nullable=True),
        sa.Column("contact_email", sa.String(200), nullable=True),
        sa.Column("contact_form_url", sa.String(500), nullable=True),
        sa.Column("contact_phone", sa.String(50), nullable=True),
        sa.Column("photo_url", sa.String(500), nullable=True),
        sa.Column("data_source", sa.String(50), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("last_verified", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),
        if_not_exists=True,
    )
    op.create_index(
        "idx_reps_level_jurisdiction",
        "representatives",
        ["level", "jurisdiction"],
        if_not_exists=True,
    )
    op.create_index(
        "idx_reps_data_source", "representatives", ["data_source"], if_not_exists=True
    )

    op.create_table(
        "regional_sources",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            primary_key=True,
        ),
        sa.Column("region", sa.String(100), nullable=False),
        sa.Column("target_type", sa.String(50), nullable=False),
        sa.Column("api_type", sa.String(50), nullable=True),
        sa.Column("api_endpoint", sa.String(500), nullable=True),
        sa.Column("boundary_layer", sa.String(200), nullable=True),
        sa.Column("config", postgresql.JSONB(), nullable=True),
        sa.Column("active", sa.Boolean(), server_default=sa.true(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),
        if_not_exists=True,
    )

    op.create_table(
        "contact_overrides",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            primary_key=True,
        ),
        sa.Column("target_type", sa.String(50), nullable=False),
        sa.Column("jurisdiction", sa.String(100), nullable=True),
        sa.Column("district", sa.String(50), nullable=True),
        sa.Column("official_name", sa.String(200), nullable=True),
        sa.Column("email", sa.String(200), nullable=True),
        sa.Column("webform_url", sa.String(500), nullable=True),
        sa.Column("phone", sa.String(50), nullable=True),
        sa.Column("address", sa.Text(), nullable=True),
        sa.Column("last_verified", sa.DateTime(timezone=True), nullable=True),
        sa.Column("source", sa.String(50), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),
        if_not_exists=True,
    )

    op.create_table(
        "static_officials",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            primary_key=True,
        ),
        sa.Column("target_type", sa.String(50), nullable=False),
        sa.Column("title", sa.String(100), nullable=True),
        sa.Column("name", sa.String(200), nullable=True),
        sa.Column("email", sa.String(200), nullable=True),
        sa.Column("webform_url", sa.String(500), nullable=True),
        sa.Column("address", sa.Text(), nullable=True),
        sa.Column("effective_date", sa.Date(), nullable=True),
        sa.Column("end_date", sa.Date(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),
        if_not_exists=True,
    )

    op.create_table(
        "messages",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            primary_key=True,
        ),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("representative_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("delivery_method", sa.String(20), nullable=False),
        sa.Column("status", sa.String(20), nullable=False),
        sa.Column("payload_snapshot", postgresql.JSONB(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),
        sa.Column("sent_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.ForeignKeyConstraint(["representative_id"], ["representatives.id"]),
        if_not_exists=True,
    )
    op.create_index(
        "idx_messages_user_created",
        "messages",
        ["user_id", "created_at"],
        if_not_exists=True,
    )
    op.create_index(
        "idx_messages_status",
        "messages",
        ["status"],
        postgresql_where=sa.text("status IN ('pending', 'failed')"),
        if_not_exists=True,
    )


def downgrade() -> None:
    op.drop_index("idx_messages_status", table_name="messages")
    op.drop_index("idx_messages_user_created", table_name="messages")
    op.drop_table("messages")
    op.drop_table("static_officials")
    op.drop_table("contact_overrides")
    op.drop_table("regional_sources")
    op.drop_index("idx_reps_data_source", table_name="representatives")
    op.drop_index("idx_reps_level_jurisdiction", table_name="representatives")
    op.drop_table("representatives")
    op.drop_table("user_profiles")
    op.drop_constraint("users_phone_key", "users", type_="unique")
    op.drop_table("users")
