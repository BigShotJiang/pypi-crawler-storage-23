"""Add address fields to user_profiles. Idempotent (ADD COLUMN IF NOT EXISTS).

Revision ID: 005_reach_user_profile_address_fields
Revises: 004_reach_representatives_honorific
"""

from typing import Sequence, Union

from alembic import op

revision: str = "005_reach_user_profile_address_fields"
down_revision: Union[str, None] = "004_reach_representatives_honorific"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute(
        "ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS street_address_1_encrypted BYTEA"
    )
    op.execute(
        "ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS street_address_2_encrypted BYTEA"
    )
    op.execute(
        "ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS city_encrypted BYTEA"
    )
    op.execute(
        "ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS state_encrypted BYTEA"
    )
    op.execute(
        "COMMENT ON COLUMN user_profiles.street_address_1_encrypted IS 'Street address line 1 (encrypted PII)'"
    )
    op.execute(
        "COMMENT ON COLUMN user_profiles.street_address_2_encrypted IS 'Street address line 2, optional (encrypted PII)'"
    )
    op.execute(
        "COMMENT ON COLUMN user_profiles.city_encrypted IS 'City (encrypted PII)'"
    )
    op.execute(
        "COMMENT ON COLUMN user_profiles.state_encrypted IS 'State code e.g. CA (encrypted PII)'"
    )
    op.execute(
        "COMMENT ON COLUMN user_profiles.zip_code IS 'ZIP or ZIP+4 (e.g. 90291 or 90291-1234)'"
    )


def downgrade() -> None:
    op.drop_column("user_profiles", "street_address_1_encrypted")
    op.drop_column("user_profiles", "street_address_2_encrypted")
    op.drop_column("user_profiles", "city_encrypted")
    op.drop_column("user_profiles", "state_encrypted")
