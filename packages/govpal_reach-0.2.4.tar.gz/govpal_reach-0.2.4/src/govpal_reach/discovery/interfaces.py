from govpal.discovery.interfaces import Rep

__all__ = ["Rep"]
