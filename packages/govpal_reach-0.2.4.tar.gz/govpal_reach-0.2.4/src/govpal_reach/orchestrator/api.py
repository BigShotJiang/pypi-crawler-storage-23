"""Re-export sync api from govpal (for patches like _default_email_provider)."""

from govpal.orchestrator.api import (
    _default_email_provider,
    create_message,
    delivery_method_for_rep,
    discover_reps_for_address,
    enqueue_messages_for_address,
    send_message_to_representatives,
    update_message,
)

__all__ = [
    "_default_email_provider",
    "create_message",
    "delivery_method_for_rep",
    "discover_reps_for_address",
    "enqueue_messages_for_address",
    "send_message_to_representatives",
    "update_message",
]
