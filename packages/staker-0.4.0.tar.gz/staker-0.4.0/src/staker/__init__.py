# Package marker for staker module
