"""fairyfly-therm simulation settings."""
