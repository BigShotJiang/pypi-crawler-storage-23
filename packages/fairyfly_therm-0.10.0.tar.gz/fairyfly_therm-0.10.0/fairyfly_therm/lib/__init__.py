"""Library of materials and conditions."""
