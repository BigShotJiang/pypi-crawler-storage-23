2026-02-26 Version: 1.3.1
- Update API GetInstanceFeatureGate: add response parameters Body.Data.supportCompactionService.


2026-02-25 Version: 1.3.0
- Support API AddGateway.
- Support API DeleteGateway.
- Support API DisableSSLConnection.
- Support API EnableSSLConnection.
- Support API GetInstanceFeatureGate.
- Support API IsolateLeader.
- Support API ListGateway.
- Support API ModifyChargeType.
- Support API ModifyDiskType.
- Support API RestartNodeGroup.
- Support API RestartNodes.
- Support API RestoreInstance.
- Support API ResumeInstance.
- Support API TogglePublicSlb.
- Support API UpdateGateway.


2026-02-25 Version: 1.3.0
- Support API AddGateway.
- Support API DeleteGateway.
- Support API DisableSSLConnection.
- Support API EnableSSLConnection.
- Support API GetInstanceFeatureGate.
- Support API IsolateLeader.
- Support API ListGateway.
- Support API ModifyChargeType.
- Support API ModifyDiskType.
- Support API RestartNodeGroup.
- Support API RestartNodes.
- Support API RestoreInstance.
- Support API ResumeInstance.
- Support API TogglePublicSlb.
- Support API UpdateGateway.


2025-12-05 Version: 1.2.2
- Update API CreateInstanceV1: add request parameters body.DlfCatalogName.
- Update API CreateInstanceV1: add request parameters body.DlfCatalogType.
- Update API CreateInstanceV1: add request parameters body.LinkedRamUserName.
- Update API CreateInstanceV1: add request parameters body.PrincipalType.
- Update API CreateInstanceV1: add request parameters body.RamUserId.
- Update API DescribeNodeGroups: add response parameters Body.Data.$.Tags.


2025-11-25 Version: 1.2.1
- Update API ModifyNodeNumber: add request parameters Parallelism.
- Update API ModifyNodeNumber: add request parameters TerminationGracePeriodSeconds.


2025-10-22 Version: 1.2.0
- Support API DescribeNodeGroups.


2025-09-12 Version: 1.1.1
- Update API CreateInstanceV1: add request parameters body.AgentNodeGroup.
- Update API CreateInstanceV1: add request parameters body.AutoPay.
- Update API CreateInstanceV1: add request parameters body.GatewayType.
- Update API ModifyDiskSize: add request parameters FastMode.


2025-07-30 Version: 1.1.0
- Support API ChangeResourceGroup.
- Support API CreateInstanceV1.
- Support API CreateServiceLinkedRole.
- Support API DescribeInstances.
- Support API TagResources.
- Support API UnTagResources.


2025-07-02 Version: 1.0.1
- Generated python 2022-10-19 for starrocks.

2025-06-30 Version: 1.0.0
- Update API ModifyCu: add request parameters PromotionOptionNo.
- Update API ModifyDiskNumber: add request parameters PromotionOptionNo.
- Update API ModifyDiskPerformanceLevel: add request parameters PromotionOptionNo.
- Update API ModifyDiskSize: add request parameters PromotionOptionNo.
- Update API ModifyNodeNumber: add request parameters PromotionOptionNo.


