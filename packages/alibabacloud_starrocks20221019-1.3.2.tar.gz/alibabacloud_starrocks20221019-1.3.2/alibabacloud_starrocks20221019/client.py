# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import Dict

from alibabacloud_starrocks20221019 import models as main_models
from alibabacloud_tea_openapi import utils_models as open_api_util_models
from alibabacloud_tea_openapi.client import Client as OpenApiClient
from alibabacloud_tea_openapi.utils import Utils
from darabonba.core import DaraCore as DaraCore
from darabonba.runtime import RuntimeOptions

"""
"""
class Client(OpenApiClient):

    def __init__(
        self,
        config: open_api_util_models.Config,
    ):
        super().__init__(config)
        self._endpoint_rule = ''
        self.check_config(config)
        self._endpoint = self.get_endpoint('starrocks', self._region_id, self._endpoint_rule, self._network, self._suffix, self._endpoint_map, self._endpoint)

    def get_endpoint(
        self,
        product_id: str,
        region_id: str,
        endpoint_rule: str,
        network: str,
        suffix: str,
        endpoint_map: Dict[str, str],
        endpoint: str,
    ) -> str:
        if not DaraCore.is_null(endpoint):
            return endpoint
        if not DaraCore.is_null(endpoint_map) and not DaraCore.is_null(endpoint_map.get(region_id)):
            return endpoint_map.get(region_id)
        return Utils.get_endpoint_rules(product_id, region_id, endpoint_rule, network, suffix)

    def add_gateway_with_options(
        self,
        request: main_models.AddGatewayRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.AddGatewayResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fe_node_number):
            query['FeNodeNumber'] = request.fe_node_number
        if not DaraCore.is_null(request.gateway_name):
            query['GatewayName'] = request.gateway_name
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'AddGateway',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/gateway/add',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.AddGatewayResponse(),
            self.call_api(params, req, runtime)
        )

    async def add_gateway_with_options_async(
        self,
        request: main_models.AddGatewayRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.AddGatewayResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fe_node_number):
            query['FeNodeNumber'] = request.fe_node_number
        if not DaraCore.is_null(request.gateway_name):
            query['GatewayName'] = request.gateway_name
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'AddGateway',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/gateway/add',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.AddGatewayResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def add_gateway(
        self,
        request: main_models.AddGatewayRequest,
    ) -> main_models.AddGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.add_gateway_with_options(request, headers, runtime)

    async def add_gateway_async(
        self,
        request: main_models.AddGatewayRequest,
    ) -> main_models.AddGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.add_gateway_with_options_async(request, headers, runtime)

    def change_resource_group_with_options(
        self,
        request: main_models.ChangeResourceGroupRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ChangeResourceGroupResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.new_resource_group_id):
            query['NewResourceGroupId'] = request.new_resource_group_id
        if not DaraCore.is_null(request.region_id):
            query['RegionId'] = request.region_id
        if not DaraCore.is_null(request.resource_type):
            query['ResourceType'] = request.resource_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ChangeResourceGroup',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceGroup/change',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ChangeResourceGroupResponse(),
            self.call_api(params, req, runtime)
        )

    async def change_resource_group_with_options_async(
        self,
        request: main_models.ChangeResourceGroupRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ChangeResourceGroupResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.new_resource_group_id):
            query['NewResourceGroupId'] = request.new_resource_group_id
        if not DaraCore.is_null(request.region_id):
            query['RegionId'] = request.region_id
        if not DaraCore.is_null(request.resource_type):
            query['ResourceType'] = request.resource_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ChangeResourceGroup',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceGroup/change',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ChangeResourceGroupResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def change_resource_group(
        self,
        request: main_models.ChangeResourceGroupRequest,
    ) -> main_models.ChangeResourceGroupResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.change_resource_group_with_options(request, headers, runtime)

    async def change_resource_group_async(
        self,
        request: main_models.ChangeResourceGroupRequest,
    ) -> main_models.ChangeResourceGroupResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.change_resource_group_with_options_async(request, headers, runtime)

    def create_instance_v1with_options(
        self,
        request: main_models.CreateInstanceV1Request,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateInstanceV1Response:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.admin_password):
            body['AdminPassword'] = request.admin_password
        if not DaraCore.is_null(request.agent_node_group):
            body['AgentNodeGroup'] = request.agent_node_group
        if not DaraCore.is_null(request.auto_pay):
            body['AutoPay'] = request.auto_pay
        if not DaraCore.is_null(request.auto_renew):
            body['AutoRenew'] = request.auto_renew
        if not DaraCore.is_null(request.backend_node_groups):
            body['BackendNodeGroups'] = request.backend_node_groups
        if not DaraCore.is_null(request.client_token):
            body['ClientToken'] = request.client_token
        if not DaraCore.is_null(request.dlf_catalog_name):
            body['DlfCatalogName'] = request.dlf_catalog_name
        if not DaraCore.is_null(request.dlf_catalog_type):
            body['DlfCatalogType'] = request.dlf_catalog_type
        if not DaraCore.is_null(request.duration):
            body['Duration'] = request.duration
        if not DaraCore.is_null(request.encrypted):
            body['Encrypted'] = request.encrypted
        if not DaraCore.is_null(request.frontend_node_groups):
            body['FrontendNodeGroups'] = request.frontend_node_groups
        if not DaraCore.is_null(request.gateway_type):
            body['GatewayType'] = request.gateway_type
        if not DaraCore.is_null(request.instance_name):
            body['InstanceName'] = request.instance_name
        if not DaraCore.is_null(request.kms_key_id):
            body['KmsKeyId'] = request.kms_key_id
        if not DaraCore.is_null(request.linked_ram_user_name):
            body['LinkedRamUserName'] = request.linked_ram_user_name
        if not DaraCore.is_null(request.observer_node_groups):
            body['ObserverNodeGroups'] = request.observer_node_groups
        if not DaraCore.is_null(request.oss_accessing_role_name):
            body['OssAccessingRoleName'] = request.oss_accessing_role_name
        if not DaraCore.is_null(request.package_type):
            body['PackageType'] = request.package_type
        if not DaraCore.is_null(request.pay_type):
            body['PayType'] = request.pay_type
        if not DaraCore.is_null(request.pricing_cycle):
            body['PricingCycle'] = request.pricing_cycle
        if not DaraCore.is_null(request.principal_type):
            body['PrincipalType'] = request.principal_type
        if not DaraCore.is_null(request.promotion_option_no):
            body['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.ram_user_id):
            body['RamUserId'] = request.ram_user_id
        if not DaraCore.is_null(request.region_id):
            body['RegionId'] = request.region_id
        if not DaraCore.is_null(request.resource_group_id):
            body['ResourceGroupId'] = request.resource_group_id
        if not DaraCore.is_null(request.run_mode):
            body['RunMode'] = request.run_mode
        if not DaraCore.is_null(request.tags):
            body['Tags'] = request.tags
        if not DaraCore.is_null(request.v_switches):
            body['VSwitches'] = request.v_switches
        if not DaraCore.is_null(request.version):
            body['Version'] = request.version
        if not DaraCore.is_null(request.vpc_id):
            body['VpcId'] = request.vpc_id
        if not DaraCore.is_null(request.zone_id):
            body['ZoneId'] = request.zone_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'CreateInstanceV1',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/cluster/createV1',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateInstanceV1Response(),
            self.call_api(params, req, runtime)
        )

    async def create_instance_v1with_options_async(
        self,
        request: main_models.CreateInstanceV1Request,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateInstanceV1Response:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.admin_password):
            body['AdminPassword'] = request.admin_password
        if not DaraCore.is_null(request.agent_node_group):
            body['AgentNodeGroup'] = request.agent_node_group
        if not DaraCore.is_null(request.auto_pay):
            body['AutoPay'] = request.auto_pay
        if not DaraCore.is_null(request.auto_renew):
            body['AutoRenew'] = request.auto_renew
        if not DaraCore.is_null(request.backend_node_groups):
            body['BackendNodeGroups'] = request.backend_node_groups
        if not DaraCore.is_null(request.client_token):
            body['ClientToken'] = request.client_token
        if not DaraCore.is_null(request.dlf_catalog_name):
            body['DlfCatalogName'] = request.dlf_catalog_name
        if not DaraCore.is_null(request.dlf_catalog_type):
            body['DlfCatalogType'] = request.dlf_catalog_type
        if not DaraCore.is_null(request.duration):
            body['Duration'] = request.duration
        if not DaraCore.is_null(request.encrypted):
            body['Encrypted'] = request.encrypted
        if not DaraCore.is_null(request.frontend_node_groups):
            body['FrontendNodeGroups'] = request.frontend_node_groups
        if not DaraCore.is_null(request.gateway_type):
            body['GatewayType'] = request.gateway_type
        if not DaraCore.is_null(request.instance_name):
            body['InstanceName'] = request.instance_name
        if not DaraCore.is_null(request.kms_key_id):
            body['KmsKeyId'] = request.kms_key_id
        if not DaraCore.is_null(request.linked_ram_user_name):
            body['LinkedRamUserName'] = request.linked_ram_user_name
        if not DaraCore.is_null(request.observer_node_groups):
            body['ObserverNodeGroups'] = request.observer_node_groups
        if not DaraCore.is_null(request.oss_accessing_role_name):
            body['OssAccessingRoleName'] = request.oss_accessing_role_name
        if not DaraCore.is_null(request.package_type):
            body['PackageType'] = request.package_type
        if not DaraCore.is_null(request.pay_type):
            body['PayType'] = request.pay_type
        if not DaraCore.is_null(request.pricing_cycle):
            body['PricingCycle'] = request.pricing_cycle
        if not DaraCore.is_null(request.principal_type):
            body['PrincipalType'] = request.principal_type
        if not DaraCore.is_null(request.promotion_option_no):
            body['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.ram_user_id):
            body['RamUserId'] = request.ram_user_id
        if not DaraCore.is_null(request.region_id):
            body['RegionId'] = request.region_id
        if not DaraCore.is_null(request.resource_group_id):
            body['ResourceGroupId'] = request.resource_group_id
        if not DaraCore.is_null(request.run_mode):
            body['RunMode'] = request.run_mode
        if not DaraCore.is_null(request.tags):
            body['Tags'] = request.tags
        if not DaraCore.is_null(request.v_switches):
            body['VSwitches'] = request.v_switches
        if not DaraCore.is_null(request.version):
            body['Version'] = request.version
        if not DaraCore.is_null(request.vpc_id):
            body['VpcId'] = request.vpc_id
        if not DaraCore.is_null(request.zone_id):
            body['ZoneId'] = request.zone_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'CreateInstanceV1',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/cluster/createV1',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateInstanceV1Response(),
            await self.call_api_async(params, req, runtime)
        )

    def create_instance_v1(
        self,
        request: main_models.CreateInstanceV1Request,
    ) -> main_models.CreateInstanceV1Response:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_instance_v1with_options(request, headers, runtime)

    async def create_instance_v1_async(
        self,
        request: main_models.CreateInstanceV1Request,
    ) -> main_models.CreateInstanceV1Response:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_instance_v1with_options_async(request, headers, runtime)

    def create_service_linked_role_with_options(
        self,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateServiceLinkedRoleResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'CreateServiceLinkedRole',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/user/create_default_role',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateServiceLinkedRoleResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_service_linked_role_with_options_async(
        self,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateServiceLinkedRoleResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'CreateServiceLinkedRole',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/user/create_default_role',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateServiceLinkedRoleResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_service_linked_role(self) -> main_models.CreateServiceLinkedRoleResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_service_linked_role_with_options(headers, runtime)

    async def create_service_linked_role_async(self) -> main_models.CreateServiceLinkedRoleResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_service_linked_role_with_options_async(headers, runtime)

    def delete_gateway_with_options(
        self,
        request: main_models.DeleteGatewayRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteGatewayResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.gateway_id):
            query['GatewayId'] = request.gateway_id
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'DeleteGateway',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/gateway/delete',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteGatewayResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_gateway_with_options_async(
        self,
        request: main_models.DeleteGatewayRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteGatewayResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.gateway_id):
            query['GatewayId'] = request.gateway_id
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'DeleteGateway',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/gateway/delete',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteGatewayResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_gateway(
        self,
        request: main_models.DeleteGatewayRequest,
    ) -> main_models.DeleteGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_gateway_with_options(request, headers, runtime)

    async def delete_gateway_async(
        self,
        request: main_models.DeleteGatewayRequest,
    ) -> main_models.DeleteGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_gateway_with_options_async(request, headers, runtime)

    def describe_instances_with_options(
        self,
        tmp_req: main_models.DescribeInstancesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DescribeInstancesResponse:
        tmp_req.validate()
        request = main_models.DescribeInstancesShrinkRequest()
        Utils.convert(tmp_req, request)
        if not DaraCore.is_null(tmp_req.tag):
            request.tag_shrink = Utils.array_to_string_with_specified_style(tmp_req.tag, 'Tag', 'json')
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.instance_name):
            query['InstanceName'] = request.instance_name
        if not DaraCore.is_null(request.instance_status):
            query['InstanceStatus'] = request.instance_status
        if not DaraCore.is_null(request.page_number):
            query['PageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['PageSize'] = request.page_size
        if not DaraCore.is_null(request.region_id):
            query['RegionId'] = request.region_id
        if not DaraCore.is_null(request.resource_group_id):
            query['ResourceGroupId'] = request.resource_group_id
        if not DaraCore.is_null(request.tag_shrink):
            query['Tag'] = request.tag_shrink
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'DescribeInstances',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/starrocks/describeInstances',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DescribeInstancesResponse(),
            self.call_api(params, req, runtime)
        )

    async def describe_instances_with_options_async(
        self,
        tmp_req: main_models.DescribeInstancesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DescribeInstancesResponse:
        tmp_req.validate()
        request = main_models.DescribeInstancesShrinkRequest()
        Utils.convert(tmp_req, request)
        if not DaraCore.is_null(tmp_req.tag):
            request.tag_shrink = Utils.array_to_string_with_specified_style(tmp_req.tag, 'Tag', 'json')
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.instance_name):
            query['InstanceName'] = request.instance_name
        if not DaraCore.is_null(request.instance_status):
            query['InstanceStatus'] = request.instance_status
        if not DaraCore.is_null(request.page_number):
            query['PageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['PageSize'] = request.page_size
        if not DaraCore.is_null(request.region_id):
            query['RegionId'] = request.region_id
        if not DaraCore.is_null(request.resource_group_id):
            query['ResourceGroupId'] = request.resource_group_id
        if not DaraCore.is_null(request.tag_shrink):
            query['Tag'] = request.tag_shrink
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'DescribeInstances',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/starrocks/describeInstances',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DescribeInstancesResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def describe_instances(
        self,
        request: main_models.DescribeInstancesRequest,
    ) -> main_models.DescribeInstancesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.describe_instances_with_options(request, headers, runtime)

    async def describe_instances_async(
        self,
        request: main_models.DescribeInstancesRequest,
    ) -> main_models.DescribeInstancesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.describe_instances_with_options_async(request, headers, runtime)

    def describe_node_groups_with_options(
        self,
        request: main_models.DescribeNodeGroupsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DescribeNodeGroupsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.cluster_id):
            query['ClusterId'] = request.cluster_id
        if not DaraCore.is_null(request.page_number):
            query['PageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['PageSize'] = request.page_size
        body = {}
        if not DaraCore.is_null(request.component_type):
            body['componentType'] = request.component_type
        if not DaraCore.is_null(request.instance_id):
            body['instanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_ids):
            body['nodeGroupIds'] = request.node_group_ids
        if not DaraCore.is_null(request.node_group_name):
            body['nodeGroupName'] = request.node_group_name
        if not DaraCore.is_null(request.status):
            body['status'] = request.status
        if not DaraCore.is_null(request.tags):
            body['tags'] = request.tags
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query),
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'DescribeNodeGroups',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/nodegroup/describeNodeGroups',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DescribeNodeGroupsResponse(),
            self.call_api(params, req, runtime)
        )

    async def describe_node_groups_with_options_async(
        self,
        request: main_models.DescribeNodeGroupsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DescribeNodeGroupsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.cluster_id):
            query['ClusterId'] = request.cluster_id
        if not DaraCore.is_null(request.page_number):
            query['PageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['PageSize'] = request.page_size
        body = {}
        if not DaraCore.is_null(request.component_type):
            body['componentType'] = request.component_type
        if not DaraCore.is_null(request.instance_id):
            body['instanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_ids):
            body['nodeGroupIds'] = request.node_group_ids
        if not DaraCore.is_null(request.node_group_name):
            body['nodeGroupName'] = request.node_group_name
        if not DaraCore.is_null(request.status):
            body['status'] = request.status
        if not DaraCore.is_null(request.tags):
            body['tags'] = request.tags
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query),
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'DescribeNodeGroups',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/nodegroup/describeNodeGroups',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DescribeNodeGroupsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def describe_node_groups(
        self,
        request: main_models.DescribeNodeGroupsRequest,
    ) -> main_models.DescribeNodeGroupsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.describe_node_groups_with_options(request, headers, runtime)

    async def describe_node_groups_async(
        self,
        request: main_models.DescribeNodeGroupsRequest,
    ) -> main_models.DescribeNodeGroupsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.describe_node_groups_with_options_async(request, headers, runtime)

    def disable_sslconnection_with_options(
        self,
        request: main_models.DisableSSLConnectionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DisableSSLConnectionResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'DisableSSLConnection',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/starrocks/disableSSLConnection',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DisableSSLConnectionResponse(),
            self.call_api(params, req, runtime)
        )

    async def disable_sslconnection_with_options_async(
        self,
        request: main_models.DisableSSLConnectionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DisableSSLConnectionResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'DisableSSLConnection',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/starrocks/disableSSLConnection',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DisableSSLConnectionResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def disable_sslconnection(
        self,
        request: main_models.DisableSSLConnectionRequest,
    ) -> main_models.DisableSSLConnectionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.disable_sslconnection_with_options(request, headers, runtime)

    async def disable_sslconnection_async(
        self,
        request: main_models.DisableSSLConnectionRequest,
    ) -> main_models.DisableSSLConnectionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.disable_sslconnection_with_options_async(request, headers, runtime)

    def enable_sslconnection_with_options(
        self,
        request: main_models.EnableSSLConnectionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.EnableSSLConnectionResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.custom_sslcertificate):
            body['CustomSSLCertificate'] = request.custom_sslcertificate
        if not DaraCore.is_null(request.enable_custom):
            body['EnableCustom'] = request.enable_custom
        if not DaraCore.is_null(request.instance_id):
            body['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.renewal):
            body['Renewal'] = request.renewal
        if not DaraCore.is_null(request.ssl_key_password):
            body['SslKeyPassword'] = request.ssl_key_password
        if not DaraCore.is_null(request.ssl_keystore_password):
            body['SslKeystorePassword'] = request.ssl_keystore_password
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'EnableSSLConnection',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/starrocks/enableSSLConnection',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.EnableSSLConnectionResponse(),
            self.call_api(params, req, runtime)
        )

    async def enable_sslconnection_with_options_async(
        self,
        request: main_models.EnableSSLConnectionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.EnableSSLConnectionResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.custom_sslcertificate):
            body['CustomSSLCertificate'] = request.custom_sslcertificate
        if not DaraCore.is_null(request.enable_custom):
            body['EnableCustom'] = request.enable_custom
        if not DaraCore.is_null(request.instance_id):
            body['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.renewal):
            body['Renewal'] = request.renewal
        if not DaraCore.is_null(request.ssl_key_password):
            body['SslKeyPassword'] = request.ssl_key_password
        if not DaraCore.is_null(request.ssl_keystore_password):
            body['SslKeystorePassword'] = request.ssl_keystore_password
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'EnableSSLConnection',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/starrocks/enableSSLConnection',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.EnableSSLConnectionResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def enable_sslconnection(
        self,
        request: main_models.EnableSSLConnectionRequest,
    ) -> main_models.EnableSSLConnectionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.enable_sslconnection_with_options(request, headers, runtime)

    async def enable_sslconnection_async(
        self,
        request: main_models.EnableSSLConnectionRequest,
    ) -> main_models.EnableSSLConnectionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.enable_sslconnection_with_options_async(request, headers, runtime)

    def get_instance_feature_gate_with_options(
        self,
        request: main_models.GetInstanceFeatureGateRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetInstanceFeatureGateResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'GetInstanceFeatureGate',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/features/featureGate',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetInstanceFeatureGateResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_instance_feature_gate_with_options_async(
        self,
        request: main_models.GetInstanceFeatureGateRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetInstanceFeatureGateResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'GetInstanceFeatureGate',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/features/featureGate',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetInstanceFeatureGateResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_instance_feature_gate(
        self,
        request: main_models.GetInstanceFeatureGateRequest,
    ) -> main_models.GetInstanceFeatureGateResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_instance_feature_gate_with_options(request, headers, runtime)

    async def get_instance_feature_gate_async(
        self,
        request: main_models.GetInstanceFeatureGateRequest,
    ) -> main_models.GetInstanceFeatureGateResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_instance_feature_gate_with_options_async(request, headers, runtime)

    def isolate_leader_with_options(
        self,
        request: main_models.IsolateLeaderRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.IsolateLeaderResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.isolate_leader):
            query['IsolateLeader'] = request.isolate_leader
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'IsolateLeader',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/gateway/isolateLeader',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.IsolateLeaderResponse(),
            self.call_api(params, req, runtime)
        )

    async def isolate_leader_with_options_async(
        self,
        request: main_models.IsolateLeaderRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.IsolateLeaderResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.isolate_leader):
            query['IsolateLeader'] = request.isolate_leader
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'IsolateLeader',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/gateway/isolateLeader',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.IsolateLeaderResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def isolate_leader(
        self,
        request: main_models.IsolateLeaderRequest,
    ) -> main_models.IsolateLeaderResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.isolate_leader_with_options(request, headers, runtime)

    async def isolate_leader_async(
        self,
        request: main_models.IsolateLeaderRequest,
    ) -> main_models.IsolateLeaderResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.isolate_leader_with_options_async(request, headers, runtime)

    def list_gateway_with_options(
        self,
        request: main_models.ListGatewayRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListGatewayResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListGateway',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/gateway/list',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListGatewayResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_gateway_with_options_async(
        self,
        request: main_models.ListGatewayRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListGatewayResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListGateway',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/gateway/list',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListGatewayResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_gateway(
        self,
        request: main_models.ListGatewayRequest,
    ) -> main_models.ListGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_gateway_with_options(request, headers, runtime)

    async def list_gateway_async(
        self,
        request: main_models.ListGatewayRequest,
    ) -> main_models.ListGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_gateway_with_options_async(request, headers, runtime)

    def modify_charge_type_with_options(
        self,
        request: main_models.ModifyChargeTypeRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyChargeTypeResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.auto_renew):
            query['AutoRenew'] = request.auto_renew
        if not DaraCore.is_null(request.billing_instance_ids):
            query['BillingInstanceIds'] = request.billing_instance_ids
        if not DaraCore.is_null(request.duration):
            query['Duration'] = request.duration
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.pricing_cycle):
            query['PricingCycle'] = request.pricing_cycle
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyChargeType',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/cluster/modifyChargeType',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyChargeTypeResponse(),
            self.call_api(params, req, runtime)
        )

    async def modify_charge_type_with_options_async(
        self,
        request: main_models.ModifyChargeTypeRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyChargeTypeResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.auto_renew):
            query['AutoRenew'] = request.auto_renew
        if not DaraCore.is_null(request.billing_instance_ids):
            query['BillingInstanceIds'] = request.billing_instance_ids
        if not DaraCore.is_null(request.duration):
            query['Duration'] = request.duration
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.pricing_cycle):
            query['PricingCycle'] = request.pricing_cycle
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyChargeType',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/cluster/modifyChargeType',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyChargeTypeResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def modify_charge_type(
        self,
        request: main_models.ModifyChargeTypeRequest,
    ) -> main_models.ModifyChargeTypeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.modify_charge_type_with_options(request, headers, runtime)

    async def modify_charge_type_async(
        self,
        request: main_models.ModifyChargeTypeRequest,
    ) -> main_models.ModifyChargeTypeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.modify_charge_type_with_options_async(request, headers, runtime)

    def modify_cu_with_options(
        self,
        request: main_models.ModifyCuRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyCuResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fast_mode):
            query['FastMode'] = request.fast_mode
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyCu',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyCu',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyCuResponse(),
            self.call_api(params, req, runtime)
        )

    async def modify_cu_with_options_async(
        self,
        request: main_models.ModifyCuRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyCuResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fast_mode):
            query['FastMode'] = request.fast_mode
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyCu',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyCu',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyCuResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def modify_cu(
        self,
        request: main_models.ModifyCuRequest,
    ) -> main_models.ModifyCuResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.modify_cu_with_options(request, headers, runtime)

    async def modify_cu_async(
        self,
        request: main_models.ModifyCuRequest,
    ) -> main_models.ModifyCuResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.modify_cu_with_options_async(request, headers, runtime)

    def modify_cu_pre_check_with_options(
        self,
        request: main_models.ModifyCuPreCheckRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyCuPreCheckResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyCuPreCheck',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyCuPreCheck',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyCuPreCheckResponse(),
            self.call_api(params, req, runtime)
        )

    async def modify_cu_pre_check_with_options_async(
        self,
        request: main_models.ModifyCuPreCheckRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyCuPreCheckResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyCuPreCheck',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyCuPreCheck',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyCuPreCheckResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def modify_cu_pre_check(
        self,
        request: main_models.ModifyCuPreCheckRequest,
    ) -> main_models.ModifyCuPreCheckResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.modify_cu_pre_check_with_options(request, headers, runtime)

    async def modify_cu_pre_check_async(
        self,
        request: main_models.ModifyCuPreCheckRequest,
    ) -> main_models.ModifyCuPreCheckResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.modify_cu_pre_check_with_options_async(request, headers, runtime)

    def modify_disk_number_with_options(
        self,
        request: main_models.ModifyDiskNumberRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyDiskNumberResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fast_mode):
            query['FastMode'] = request.fast_mode
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyDiskNumber',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyDiskNumber',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyDiskNumberResponse(),
            self.call_api(params, req, runtime)
        )

    async def modify_disk_number_with_options_async(
        self,
        request: main_models.ModifyDiskNumberRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyDiskNumberResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fast_mode):
            query['FastMode'] = request.fast_mode
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyDiskNumber',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyDiskNumber',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyDiskNumberResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def modify_disk_number(
        self,
        request: main_models.ModifyDiskNumberRequest,
    ) -> main_models.ModifyDiskNumberResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.modify_disk_number_with_options(request, headers, runtime)

    async def modify_disk_number_async(
        self,
        request: main_models.ModifyDiskNumberRequest,
    ) -> main_models.ModifyDiskNumberResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.modify_disk_number_with_options_async(request, headers, runtime)

    def modify_disk_performance_level_with_options(
        self,
        request: main_models.ModifyDiskPerformanceLevelRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyDiskPerformanceLevelResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyDiskPerformanceLevel',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyDiskPerformanceLevel',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyDiskPerformanceLevelResponse(),
            self.call_api(params, req, runtime)
        )

    async def modify_disk_performance_level_with_options_async(
        self,
        request: main_models.ModifyDiskPerformanceLevelRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyDiskPerformanceLevelResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyDiskPerformanceLevel',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyDiskPerformanceLevel',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyDiskPerformanceLevelResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def modify_disk_performance_level(
        self,
        request: main_models.ModifyDiskPerformanceLevelRequest,
    ) -> main_models.ModifyDiskPerformanceLevelResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.modify_disk_performance_level_with_options(request, headers, runtime)

    async def modify_disk_performance_level_async(
        self,
        request: main_models.ModifyDiskPerformanceLevelRequest,
    ) -> main_models.ModifyDiskPerformanceLevelResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.modify_disk_performance_level_with_options_async(request, headers, runtime)

    def modify_disk_size_with_options(
        self,
        request: main_models.ModifyDiskSizeRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyDiskSizeResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fast_mode):
            query['FastMode'] = request.fast_mode
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyDiskSize',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyDiskSize',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyDiskSizeResponse(),
            self.call_api(params, req, runtime)
        )

    async def modify_disk_size_with_options_async(
        self,
        request: main_models.ModifyDiskSizeRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyDiskSizeResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fast_mode):
            query['FastMode'] = request.fast_mode
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyDiskSize',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyDiskSize',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyDiskSizeResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def modify_disk_size(
        self,
        request: main_models.ModifyDiskSizeRequest,
    ) -> main_models.ModifyDiskSizeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.modify_disk_size_with_options(request, headers, runtime)

    async def modify_disk_size_async(
        self,
        request: main_models.ModifyDiskSizeRequest,
    ) -> main_models.ModifyDiskSizeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.modify_disk_size_with_options_async(request, headers, runtime)

    def modify_disk_type_with_options(
        self,
        request: main_models.ModifyDiskTypeRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyDiskTypeResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.target_disk_type):
            query['TargetDiskType'] = request.target_disk_type
        if not DaraCore.is_null(request.target_performance_level):
            query['TargetPerformanceLevel'] = request.target_performance_level
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyDiskType',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyDiskType',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyDiskTypeResponse(),
            self.call_api(params, req, runtime)
        )

    async def modify_disk_type_with_options_async(
        self,
        request: main_models.ModifyDiskTypeRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyDiskTypeResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.target_disk_type):
            query['TargetDiskType'] = request.target_disk_type
        if not DaraCore.is_null(request.target_performance_level):
            query['TargetPerformanceLevel'] = request.target_performance_level
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyDiskType',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyDiskType',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyDiskTypeResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def modify_disk_type(
        self,
        request: main_models.ModifyDiskTypeRequest,
    ) -> main_models.ModifyDiskTypeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.modify_disk_type_with_options(request, headers, runtime)

    async def modify_disk_type_async(
        self,
        request: main_models.ModifyDiskTypeRequest,
    ) -> main_models.ModifyDiskTypeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.modify_disk_type_with_options_async(request, headers, runtime)

    def modify_node_number_with_options(
        self,
        request: main_models.ModifyNodeNumberRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyNodeNumberResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.parallelism):
            query['Parallelism'] = request.parallelism
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        if not DaraCore.is_null(request.termination_grace_period_seconds):
            query['TerminationGracePeriodSeconds'] = request.termination_grace_period_seconds
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyNodeNumber',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyNodeNumber',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyNodeNumberResponse(),
            self.call_api(params, req, runtime)
        )

    async def modify_node_number_with_options_async(
        self,
        request: main_models.ModifyNodeNumberRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyNodeNumberResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.parallelism):
            query['Parallelism'] = request.parallelism
        if not DaraCore.is_null(request.promotion_option_no):
            query['PromotionOptionNo'] = request.promotion_option_no
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        if not DaraCore.is_null(request.termination_grace_period_seconds):
            query['TerminationGracePeriodSeconds'] = request.termination_grace_period_seconds
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyNodeNumber',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyNodeNumber',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyNodeNumberResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def modify_node_number(
        self,
        request: main_models.ModifyNodeNumberRequest,
    ) -> main_models.ModifyNodeNumberResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.modify_node_number_with_options(request, headers, runtime)

    async def modify_node_number_async(
        self,
        request: main_models.ModifyNodeNumberRequest,
    ) -> main_models.ModifyNodeNumberResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.modify_node_number_with_options_async(request, headers, runtime)

    def modify_node_number_pre_check_with_options(
        self,
        request: main_models.ModifyNodeNumberPreCheckRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyNodeNumberPreCheckResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyNodeNumberPreCheck',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyNodeNumberPreCheck',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyNodeNumberPreCheckResponse(),
            self.call_api(params, req, runtime)
        )

    async def modify_node_number_pre_check_with_options_async(
        self,
        request: main_models.ModifyNodeNumberPreCheckRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ModifyNodeNumberPreCheckResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        if not DaraCore.is_null(request.target):
            query['Target'] = request.target
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ModifyNodeNumberPreCheck',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/resourceChange/modifyNodeNumberPreCheck',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ModifyNodeNumberPreCheckResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def modify_node_number_pre_check(
        self,
        request: main_models.ModifyNodeNumberPreCheckRequest,
    ) -> main_models.ModifyNodeNumberPreCheckResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.modify_node_number_pre_check_with_options(request, headers, runtime)

    async def modify_node_number_pre_check_async(
        self,
        request: main_models.ModifyNodeNumberPreCheckRequest,
    ) -> main_models.ModifyNodeNumberPreCheckResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.modify_node_number_pre_check_with_options_async(request, headers, runtime)

    def query_upgradable_versions_with_options(
        self,
        request: main_models.QueryUpgradableVersionsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.QueryUpgradableVersionsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.minor):
            query['Minor'] = request.minor
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'QueryUpgradableVersions',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/starrocks/queryUpgradableVersions',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.QueryUpgradableVersionsResponse(),
            self.call_api(params, req, runtime)
        )

    async def query_upgradable_versions_with_options_async(
        self,
        request: main_models.QueryUpgradableVersionsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.QueryUpgradableVersionsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.minor):
            query['Minor'] = request.minor
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'QueryUpgradableVersions',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/starrocks/queryUpgradableVersions',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.QueryUpgradableVersionsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def query_upgradable_versions(
        self,
        request: main_models.QueryUpgradableVersionsRequest,
    ) -> main_models.QueryUpgradableVersionsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.query_upgradable_versions_with_options(request, headers, runtime)

    async def query_upgradable_versions_async(
        self,
        request: main_models.QueryUpgradableVersionsRequest,
    ) -> main_models.QueryUpgradableVersionsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.query_upgradable_versions_with_options_async(request, headers, runtime)

    def release_instance_with_options(
        self,
        request: main_models.ReleaseInstanceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ReleaseInstanceResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ReleaseInstance',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/cluster/release',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ReleaseInstanceResponse(),
            self.call_api(params, req, runtime)
        )

    async def release_instance_with_options_async(
        self,
        request: main_models.ReleaseInstanceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ReleaseInstanceResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ReleaseInstance',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/cluster/release',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ReleaseInstanceResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def release_instance(
        self,
        request: main_models.ReleaseInstanceRequest,
    ) -> main_models.ReleaseInstanceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.release_instance_with_options(request, headers, runtime)

    async def release_instance_async(
        self,
        request: main_models.ReleaseInstanceRequest,
    ) -> main_models.ReleaseInstanceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.release_instance_with_options_async(request, headers, runtime)

    def restart_instance_with_options(
        self,
        request: main_models.RestartInstanceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.RestartInstanceResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fast_mode):
            query['FastMode'] = request.fast_mode
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'RestartInstance',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/starrocks/restartCluster',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.RestartInstanceResponse(),
            self.call_api(params, req, runtime)
        )

    async def restart_instance_with_options_async(
        self,
        request: main_models.RestartInstanceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.RestartInstanceResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fast_mode):
            query['FastMode'] = request.fast_mode
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'RestartInstance',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/starrocks/restartCluster',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.RestartInstanceResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def restart_instance(
        self,
        request: main_models.RestartInstanceRequest,
    ) -> main_models.RestartInstanceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.restart_instance_with_options(request, headers, runtime)

    async def restart_instance_async(
        self,
        request: main_models.RestartInstanceRequest,
    ) -> main_models.RestartInstanceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.restart_instance_with_options_async(request, headers, runtime)

    def restart_node_group_with_options(
        self,
        request: main_models.RestartNodeGroupRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.RestartNodeGroupResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fast_mode):
            query['FastMode'] = request.fast_mode
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'RestartNodeGroup',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/nodegroup/restart',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.RestartNodeGroupResponse(),
            self.call_api(params, req, runtime)
        )

    async def restart_node_group_with_options_async(
        self,
        request: main_models.RestartNodeGroupRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.RestartNodeGroupResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fast_mode):
            query['FastMode'] = request.fast_mode
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.node_group_id):
            query['NodeGroupId'] = request.node_group_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'RestartNodeGroup',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/nodegroup/restart',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.RestartNodeGroupResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def restart_node_group(
        self,
        request: main_models.RestartNodeGroupRequest,
    ) -> main_models.RestartNodeGroupResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.restart_node_group_with_options(request, headers, runtime)

    async def restart_node_group_async(
        self,
        request: main_models.RestartNodeGroupRequest,
    ) -> main_models.RestartNodeGroupResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.restart_node_group_with_options_async(request, headers, runtime)

    def restart_nodes_with_options(
        self,
        request: main_models.RestartNodesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.RestartNodesResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        body = {}
        if not DaraCore.is_null(request.restart_node_groups):
            body['RestartNodeGroups'] = request.restart_node_groups
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query),
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'RestartNodes',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/restart/restart',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.RestartNodesResponse(),
            self.call_api(params, req, runtime)
        )

    async def restart_nodes_with_options_async(
        self,
        request: main_models.RestartNodesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.RestartNodesResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        body = {}
        if not DaraCore.is_null(request.restart_node_groups):
            body['RestartNodeGroups'] = request.restart_node_groups
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query),
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'RestartNodes',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/restart/restart',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.RestartNodesResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def restart_nodes(
        self,
        request: main_models.RestartNodesRequest,
    ) -> main_models.RestartNodesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.restart_nodes_with_options(request, headers, runtime)

    async def restart_nodes_async(
        self,
        request: main_models.RestartNodesRequest,
    ) -> main_models.RestartNodesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.restart_nodes_with_options_async(request, headers, runtime)

    def restore_instance_with_options(
        self,
        request: main_models.RestoreInstanceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.RestoreInstanceResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.admin_password):
            body['AdminPassword'] = request.admin_password
        if not DaraCore.is_null(request.auto_renew):
            body['AutoRenew'] = request.auto_renew
        if not DaraCore.is_null(request.backup_task_id):
            body['BackupTaskId'] = request.backup_task_id
        if not DaraCore.is_null(request.duration):
            body['Duration'] = request.duration
        if not DaraCore.is_null(request.instance_name):
            body['InstanceName'] = request.instance_name
        if not DaraCore.is_null(request.pay_type):
            body['PayType'] = request.pay_type
        if not DaraCore.is_null(request.pricing_cycle):
            body['PricingCycle'] = request.pricing_cycle
        if not DaraCore.is_null(request.region_id):
            body['RegionId'] = request.region_id
        if not DaraCore.is_null(request.resource_group_id):
            body['ResourceGroupId'] = request.resource_group_id
        if not DaraCore.is_null(request.tags):
            body['Tags'] = request.tags
        if not DaraCore.is_null(request.v_switches):
            body['VSwitches'] = request.v_switches
        if not DaraCore.is_null(request.vpc_id):
            body['VpcId'] = request.vpc_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'RestoreInstance',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/restore/restoreInstance',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.RestoreInstanceResponse(),
            self.call_api(params, req, runtime)
        )

    async def restore_instance_with_options_async(
        self,
        request: main_models.RestoreInstanceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.RestoreInstanceResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.admin_password):
            body['AdminPassword'] = request.admin_password
        if not DaraCore.is_null(request.auto_renew):
            body['AutoRenew'] = request.auto_renew
        if not DaraCore.is_null(request.backup_task_id):
            body['BackupTaskId'] = request.backup_task_id
        if not DaraCore.is_null(request.duration):
            body['Duration'] = request.duration
        if not DaraCore.is_null(request.instance_name):
            body['InstanceName'] = request.instance_name
        if not DaraCore.is_null(request.pay_type):
            body['PayType'] = request.pay_type
        if not DaraCore.is_null(request.pricing_cycle):
            body['PricingCycle'] = request.pricing_cycle
        if not DaraCore.is_null(request.region_id):
            body['RegionId'] = request.region_id
        if not DaraCore.is_null(request.resource_group_id):
            body['ResourceGroupId'] = request.resource_group_id
        if not DaraCore.is_null(request.tags):
            body['Tags'] = request.tags
        if not DaraCore.is_null(request.v_switches):
            body['VSwitches'] = request.v_switches
        if not DaraCore.is_null(request.vpc_id):
            body['VpcId'] = request.vpc_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'RestoreInstance',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/restore/restoreInstance',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.RestoreInstanceResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def restore_instance(
        self,
        request: main_models.RestoreInstanceRequest,
    ) -> main_models.RestoreInstanceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.restore_instance_with_options(request, headers, runtime)

    async def restore_instance_async(
        self,
        request: main_models.RestoreInstanceRequest,
    ) -> main_models.RestoreInstanceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.restore_instance_with_options_async(request, headers, runtime)

    def resume_instance_with_options(
        self,
        request: main_models.ResumeInstanceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ResumeInstanceResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ResumeInstance',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/lifecycle/resumeInstance',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ResumeInstanceResponse(),
            self.call_api(params, req, runtime)
        )

    async def resume_instance_with_options_async(
        self,
        request: main_models.ResumeInstanceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ResumeInstanceResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ResumeInstance',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/lifecycle/resumeInstance',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ResumeInstanceResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def resume_instance(
        self,
        request: main_models.ResumeInstanceRequest,
    ) -> main_models.ResumeInstanceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.resume_instance_with_options(request, headers, runtime)

    async def resume_instance_async(
        self,
        request: main_models.ResumeInstanceRequest,
    ) -> main_models.ResumeInstanceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.resume_instance_with_options_async(request, headers, runtime)

    def tag_resources_with_options(
        self,
        request: main_models.TagResourcesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.TagResourcesResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.region_id):
            body['RegionId'] = request.region_id
        if not DaraCore.is_null(request.resource_id):
            body['ResourceId'] = request.resource_id
        if not DaraCore.is_null(request.resource_type):
            body['ResourceType'] = request.resource_type
        if not DaraCore.is_null(request.tag):
            body['Tag'] = request.tag
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'TagResources',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/tags',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.TagResourcesResponse(),
            self.call_api(params, req, runtime)
        )

    async def tag_resources_with_options_async(
        self,
        request: main_models.TagResourcesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.TagResourcesResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.region_id):
            body['RegionId'] = request.region_id
        if not DaraCore.is_null(request.resource_id):
            body['ResourceId'] = request.resource_id
        if not DaraCore.is_null(request.resource_type):
            body['ResourceType'] = request.resource_type
        if not DaraCore.is_null(request.tag):
            body['Tag'] = request.tag
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'TagResources',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/tags',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.TagResourcesResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def tag_resources(
        self,
        request: main_models.TagResourcesRequest,
    ) -> main_models.TagResourcesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.tag_resources_with_options(request, headers, runtime)

    async def tag_resources_async(
        self,
        request: main_models.TagResourcesRequest,
    ) -> main_models.TagResourcesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.tag_resources_with_options_async(request, headers, runtime)

    def toggle_public_slb_with_options(
        self,
        request: main_models.TogglePublicSlbRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.TogglePublicSlbResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.enable_public_slb):
            query['EnablePublicSlb'] = request.enable_public_slb
        if not DaraCore.is_null(request.gateway_id):
            query['GatewayId'] = request.gateway_id
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'TogglePublicSlb',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/gateway/togglePublicSlb',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.TogglePublicSlbResponse(),
            self.call_api(params, req, runtime)
        )

    async def toggle_public_slb_with_options_async(
        self,
        request: main_models.TogglePublicSlbRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.TogglePublicSlbResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.enable_public_slb):
            query['EnablePublicSlb'] = request.enable_public_slb
        if not DaraCore.is_null(request.gateway_id):
            query['GatewayId'] = request.gateway_id
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'TogglePublicSlb',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/gateway/togglePublicSlb',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.TogglePublicSlbResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def toggle_public_slb(
        self,
        request: main_models.TogglePublicSlbRequest,
    ) -> main_models.TogglePublicSlbResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.toggle_public_slb_with_options(request, headers, runtime)

    async def toggle_public_slb_async(
        self,
        request: main_models.TogglePublicSlbRequest,
    ) -> main_models.TogglePublicSlbResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.toggle_public_slb_with_options_async(request, headers, runtime)

    def un_tag_resources_with_options(
        self,
        tmp_req: main_models.UnTagResourcesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UnTagResourcesResponse:
        tmp_req.validate()
        request = main_models.UnTagResourcesShrinkRequest()
        Utils.convert(tmp_req, request)
        if not DaraCore.is_null(tmp_req.resource_id):
            request.resource_id_shrink = Utils.array_to_string_with_specified_style(tmp_req.resource_id, 'ResourceId', 'json')
        if not DaraCore.is_null(tmp_req.tag_key):
            request.tag_key_shrink = Utils.array_to_string_with_specified_style(tmp_req.tag_key, 'TagKey', 'json')
        query = {}
        if not DaraCore.is_null(request.all):
            query['All'] = request.all
        if not DaraCore.is_null(request.region_id):
            query['RegionId'] = request.region_id
        if not DaraCore.is_null(request.resource_id_shrink):
            query['ResourceId'] = request.resource_id_shrink
        if not DaraCore.is_null(request.resource_type):
            query['ResourceType'] = request.resource_type
        if not DaraCore.is_null(request.tag_key_shrink):
            query['TagKey'] = request.tag_key_shrink
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'UnTagResources',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/tags',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UnTagResourcesResponse(),
            self.call_api(params, req, runtime)
        )

    async def un_tag_resources_with_options_async(
        self,
        tmp_req: main_models.UnTagResourcesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UnTagResourcesResponse:
        tmp_req.validate()
        request = main_models.UnTagResourcesShrinkRequest()
        Utils.convert(tmp_req, request)
        if not DaraCore.is_null(tmp_req.resource_id):
            request.resource_id_shrink = Utils.array_to_string_with_specified_style(tmp_req.resource_id, 'ResourceId', 'json')
        if not DaraCore.is_null(tmp_req.tag_key):
            request.tag_key_shrink = Utils.array_to_string_with_specified_style(tmp_req.tag_key, 'TagKey', 'json')
        query = {}
        if not DaraCore.is_null(request.all):
            query['All'] = request.all
        if not DaraCore.is_null(request.region_id):
            query['RegionId'] = request.region_id
        if not DaraCore.is_null(request.resource_id_shrink):
            query['ResourceId'] = request.resource_id_shrink
        if not DaraCore.is_null(request.resource_type):
            query['ResourceType'] = request.resource_type
        if not DaraCore.is_null(request.tag_key_shrink):
            query['TagKey'] = request.tag_key_shrink
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'UnTagResources',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/tags',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UnTagResourcesResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def un_tag_resources(
        self,
        request: main_models.UnTagResourcesRequest,
    ) -> main_models.UnTagResourcesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.un_tag_resources_with_options(request, headers, runtime)

    async def un_tag_resources_async(
        self,
        request: main_models.UnTagResourcesRequest,
    ) -> main_models.UnTagResourcesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.un_tag_resources_with_options_async(request, headers, runtime)

    def update_gateway_with_options(
        self,
        request: main_models.UpdateGatewayRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateGatewayResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fe_node_number):
            query['FeNodeNumber'] = request.fe_node_number
        if not DaraCore.is_null(request.gateway_id):
            query['GatewayId'] = request.gateway_id
        if not DaraCore.is_null(request.gateway_name):
            query['GatewayName'] = request.gateway_name
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'UpdateGateway',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/gateway/update',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateGatewayResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_gateway_with_options_async(
        self,
        request: main_models.UpdateGatewayRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateGatewayResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fe_node_number):
            query['FeNodeNumber'] = request.fe_node_number
        if not DaraCore.is_null(request.gateway_id):
            query['GatewayId'] = request.gateway_id
        if not DaraCore.is_null(request.gateway_name):
            query['GatewayName'] = request.gateway_name
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'UpdateGateway',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/gateway/update',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateGatewayResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_gateway(
        self,
        request: main_models.UpdateGatewayRequest,
    ) -> main_models.UpdateGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_gateway_with_options(request, headers, runtime)

    async def update_gateway_async(
        self,
        request: main_models.UpdateGatewayRequest,
    ) -> main_models.UpdateGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_gateway_with_options_async(request, headers, runtime)

    def update_instance_name_with_options(
        self,
        request: main_models.UpdateInstanceNameRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateInstanceNameResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.cluster_name):
            query['ClusterName'] = request.cluster_name
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'UpdateInstanceName',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/cluster/update_name',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateInstanceNameResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_instance_name_with_options_async(
        self,
        request: main_models.UpdateInstanceNameRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateInstanceNameResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.cluster_name):
            query['ClusterName'] = request.cluster_name
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'UpdateInstanceName',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/cluster/update_name',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateInstanceNameResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_instance_name(
        self,
        request: main_models.UpdateInstanceNameRequest,
    ) -> main_models.UpdateInstanceNameResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_instance_name_with_options(request, headers, runtime)

    async def update_instance_name_async(
        self,
        request: main_models.UpdateInstanceNameRequest,
    ) -> main_models.UpdateInstanceNameResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_instance_name_with_options_async(request, headers, runtime)

    def upgrade_version_with_options(
        self,
        request: main_models.UpgradeVersionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpgradeVersionResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fast_mode):
            query['FastMode'] = request.fast_mode
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.minor):
            query['Minor'] = request.minor
        if not DaraCore.is_null(request.target_version):
            query['TargetVersion'] = request.target_version
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'UpgradeVersion',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/starrocks/upgradeVersion',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpgradeVersionResponse(),
            self.call_api(params, req, runtime)
        )

    async def upgrade_version_with_options_async(
        self,
        request: main_models.UpgradeVersionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpgradeVersionResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.fast_mode):
            query['FastMode'] = request.fast_mode
        if not DaraCore.is_null(request.instance_id):
            query['InstanceId'] = request.instance_id
        if not DaraCore.is_null(request.minor):
            query['Minor'] = request.minor
        if not DaraCore.is_null(request.target_version):
            query['TargetVersion'] = request.target_version
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'UpgradeVersion',
            version = '2022-10-19',
            protocol = 'HTTPS',
            pathname = f'/webapi/starrocks/upgradeVersion',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpgradeVersionResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def upgrade_version(
        self,
        request: main_models.UpgradeVersionRequest,
    ) -> main_models.UpgradeVersionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.upgrade_version_with_options(request, headers, runtime)

    async def upgrade_version_async(
        self,
        request: main_models.UpgradeVersionRequest,
    ) -> main_models.UpgradeVersionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.upgrade_version_with_options_async(request, headers, runtime)
