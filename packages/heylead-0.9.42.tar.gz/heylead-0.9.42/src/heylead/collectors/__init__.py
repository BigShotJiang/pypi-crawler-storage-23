"""HeyLead signal collectors — proactive LinkedIn signal detection."""
