"""Data ingestion package for ICP generation.

Handles website crawling (Firecrawl), text chunking, and chunk storage.
"""
