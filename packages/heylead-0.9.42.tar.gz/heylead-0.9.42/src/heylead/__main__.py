"""HeyLead CLI entry point.

This module allows running HeyLead as:
    python -m heylead                           # Start MCP server (stdio)
    python -m heylead --transport streamable-http  # Start HTTP server
    python -m heylead init                      # First-time setup
    python -m heylead version                   # Show version
    python -m heylead reset                     # Delete all data
"""

from __future__ import annotations

import sys


def _parse_serve_args(args: list[str]) -> dict:
    """Parse --transport, --host, --port from CLI args."""
    transport = "stdio"
    host = "0.0.0.0"
    port = 8080

    i = 0
    while i < len(args):
        if args[i] == "--transport" and i + 1 < len(args):
            transport = args[i + 1]
            i += 2
        elif args[i] == "--host" and i + 1 < len(args):
            host = args[i + 1]
            i += 2
        elif args[i] == "--port" and i + 1 < len(args):
            port = int(args[i + 1])
            i += 2
        else:
            break
    return {"transport": transport, "host": host, "port": port}


def main() -> None:
    """CLI router — simple arg parsing without pulling in click for MCP mode."""
    args = sys.argv[1:]

    if not args or args[0].startswith("--"):
        # Default: start MCP server (with optional --transport/--host/--port)
        serve_args = _parse_serve_args(args)
        from .server import main as serve
        serve(**serve_args)
        return

    cmd = args[0].lower()

    if cmd == "version" or cmd == "--version" or cmd == "-v":
        from . import __version__
        print(f"HeyLead v{__version__}")

    elif cmd == "init":
        from . import config
        config.ensure_dirs()
        cfg = config.load_config()
        print("✅ HeyLead initialized!")
        print(f"   Config: {config.config_path()}")
        print(f"   Database: {config.db_path()}")
        print(f"   Logs: {config.log_path()}")
        print()
        print("Next steps:")
        print('1. In Cursor, open AI chat (Cmd+L) and say: "Set up my HeyLead profile"')
        print("2. The AI will give you a link — sign in with Google, connect LinkedIn, paste token.")
        print("   No API keys needed!")
        print()
        print("Not using Cursor yet? Install HeyLead with one click:")
        print("   cursor://anysphere.cursor-deeplink/mcp/install?name=heylead&config=eyJjb21tYW5kIjoidXZ4IiwiYXJncyI6WyJoZXlsZWFkIl19")

    elif cmd == "reset":
        confirm = input("⚠️  This will delete ALL HeyLead data. Continue? (yes/no): ")
        if confirm.strip().lower() == "yes":
            from . import config
            from .db.schema import reset_db
            import shutil

            reset_db()

            # Remove legacy cookie file if it exists
            cookie_path = config.cookie_path()
            if cookie_path.exists():
                cookie_path.unlink()

            # Remove config
            cfg_path = config.config_path()
            if cfg_path.exists():
                cfg_path.unlink()

            # Remove logs
            log_dir = config._heylead_home() / "logs"
            if log_dir.exists():
                shutil.rmtree(log_dir)

            print("✅ All HeyLead data deleted.")
        else:
            print("Cancelled.")

    elif cmd == "help" or cmd == "--help" or cmd == "-h":
        print("HeyLead — MCP-native autonomous LinkedIn SDR")
        print()
        print("Usage:")
        print("  heylead                                  Start MCP server (stdio)")
        print("  heylead --transport streamable-http       Start HTTP server")
        print("  heylead --transport sse --port 3000       Start SSE server on port 3000")
        print("  heylead init                              Initialize HeyLead")
        print("  heylead version                           Show version")
        print("  heylead reset                             Delete all data")
        print()
        print("Transport options:")
        print("  --transport <type>   stdio (default), sse, or streamable-http")
        print("  --host <addr>        Bind address for HTTP (default: 0.0.0.0)")
        print("  --port <num>         Port for HTTP (default: 8080)")
        print()
        print("Add to Cursor (one click):")
        print("  cursor://anysphere.cursor-deeplink/mcp/install?name=heylead&config=eyJjb21tYW5kIjoidXZ4IiwiYXJncyI6WyJoZXlsZWFkIl19")
        print()
        print("Or add manually:")
        print("  Cursor:     Settings → MCP → Add → Name: heylead, Command: uvx heylead")
        print("  Claude Code: claude mcp add heylead -- uvx heylead")

    else:
        print(f"Unknown command: {cmd}")
        print("Run 'heylead help' for usage.")
        sys.exit(1)


if __name__ == "__main__":
    main()
