# OneTool Global Templates
# This package contains template config files copied to ~/.onetool/ on first run.
