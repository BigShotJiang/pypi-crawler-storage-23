"""Extension tool templates.

Templates for creating user extension tools that run in worker subprocesses.

Available templates:
- extension.py: Unified template with optional sections for HTTP, API keys, etc.
"""
