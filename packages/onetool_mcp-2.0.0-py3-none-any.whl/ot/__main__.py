"""Run OneTool MCP server when executed as a module."""

from ot.server import main

if __name__ == "__main__":
    main()
