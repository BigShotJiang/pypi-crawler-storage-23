"""OneTool MCP server CLI package.

Entry point for the `ot` command that runs the MCP server over stdio.
"""
