"""Bundled JavaScript assets for the excalidraw tool pack."""
