"""
onetool-util - General-purpose utility tools MCP server.
"""

from __future__ import annotations

__version__ = "1.0.0"
__package_name__ = "onetool-util"

__all__ = ["__package_name__", "__version__"]
