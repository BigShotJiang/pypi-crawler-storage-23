"""Transform - LLM-powered data transformation.

Takes data and a prompt, uses an LLM to transform/process it.

Example:
    ot_llm.transform(
        data=brave.search(query="metal prices", count=10),
        prompt="Extract prices as YAML with fields: metal, price, unit, url",
    )

Supports OpenAI API and OpenRouter (OpenAI-compatible).

**Requires configuration:**
- OPENAI_API_KEY in secrets.yaml
- ot_llm.base_url in onetool.yaml (e.g., https://openrouter.ai/api/v1)
- ot_llm.model in onetool.yaml (e.g., openai/gpt-5-mini)

Tool is not available until all three are configured.
"""

from __future__ import annotations

# Pack for dot notation: ot_llm.transform()
pack = "ot_llm"

__all__ = ["transform", "transform_file"]

# Dependency declarations for CLI validation
__ot_requires__ = {
    "lib": [("openai", "pip install openai")],
    "secrets": ["OPENAI_API_KEY"],
}

from typing import Any

from openai import OpenAI
from pydantic import BaseModel, Field

# Cache clients by (api_key, base_url, timeout) to avoid creating a new
# connection pool on every transform() call.
_client_cache: dict[tuple[str, str, int], OpenAI] = {}

from ot.config import get_secret, get_tool_config
from ot.logging import LogSpan
from ot.paths import resolve_cwd_path


class Config(BaseModel):
    """Pack configuration - discovered by registry."""

    base_url: str = Field(
        default="",
        description="OpenAI-compatible API base URL (e.g., https://openrouter.ai/api/v1)",
    )
    model: str = Field(
        default="",
        description="Model to use for transformation (e.g., openai/gpt-4o-mini)",
    )
    timeout: int = Field(
        default=30,
        description="API timeout in seconds",
    )
    max_tokens: int | None = Field(
        default=None,
        description="Maximum tokens in response (None=no limit)",
    )


def _get_config() -> Config:
    """Get transform pack configuration."""
    return get_tool_config("ot_llm", Config)


def _get_api_config() -> tuple[str | None, str | None, str | None, Config]:
    """Get API configuration from settings.

    Returns:
        Tuple of (api_key, base_url, default_model, config) - api_key/base_url/model
        are None if not configured
    """
    config = _get_config()
    api_key = get_secret("OPENAI_API_KEY")
    base_url = config.base_url or None
    default_model = config.model or None
    return api_key, base_url, default_model, config


def transform(
    *,
    data: Any,
    prompt: str,
    model: str | None = None,
    json_mode: bool = False,
) -> str:
    """Transform data using an LLM.

    Takes any data (typically a string result from another tool call)
    and processes it according to the prompt instructions.

    Args:
        data: Data to transform (will be converted to string if not already)
        prompt: Instructions for how to transform/process the data
        model: AI model to use (uses ot_llm.model from config if not specified)
        json_mode: If True, request JSON output format from the model

    Returns:
        The LLM's response as a string, or error message if not configured

    Examples:
        # Extract structured data from search results
        ot_llm.transform(
            data=brave.search(query="gold price today", count=5),
            prompt="Extract the current gold price in USD/oz as a single number",
        )

        # Convert to YAML format
        ot_llm.transform(
            data=brave.search(query="metal prices", count=10),
            prompt="Return ONLY valid YAML with fields: metal, price, unit, url",
        )

        # Summarize content
        ot_llm.transform(
            data=some_long_text,
            prompt="Summarize this in 3 bullet points"
        )

        # Get JSON output
        ot_llm.transform(
            data=my_data,
            prompt="Extract name and email as JSON",
            json_mode=True
        )
    """
    with LogSpan(span="ot_llm.transform", promptLen=len(prompt)) as s:
        # Validate inputs
        if not prompt or not prompt.strip():
            s.add(error="empty_prompt")
            return "Error: prompt is required and cannot be empty"

        data_str = str(data)
        if not data_str.strip():
            s.add(error="empty_data")
            return "Error: data is required and cannot be empty"

        s.add(dataLen=len(data_str))

        # Get API config
        api_key, base_url, default_model, config = _get_api_config()

        # Check if transform tool is configured
        if not api_key:
            s.add(error="not_configured")
            return (
                "Error: Transform tool not available. "
                "Set OPENAI_API_KEY in secrets.yaml. "
                "See: https://onetool.beycom.online/reference/tools/ot_llm/"
            )

        if not base_url:
            s.add(error="no_base_url")
            return (
                "Error: Transform tool not available. "
                "Set tools.ot_llm.base_url in onetool.yaml "
                "(e.g. https://openrouter.ai/api/v1). "
                "See: https://onetool.beycom.online/reference/tools/ot_llm/"
            )

        # Get or create cached client (avoids new connection pool per call)
        cache_key = (api_key, base_url, config.timeout)
        if cache_key not in _client_cache:
            _client_cache[cache_key] = OpenAI(api_key=api_key, base_url=base_url, timeout=config.timeout)
        client = _client_cache[cache_key]

        # Build the message
        user_message = f"""Data:
{data_str}

Instructions:
{prompt}"""

        used_model = model or default_model
        if not used_model:
            s.add(error="no_model")
            return (
                "Error: Transform tool not available. "
                "Set tools.ot_llm.model in onetool.yaml "
                "(e.g. openai/gpt-4o-mini). "
                "See: https://onetool.beycom.online/reference/tools/ot_llm/"
            )

        s.add(model=used_model, jsonMode=json_mode)

        try:
            # Build API call kwargs
            api_kwargs: dict[str, Any] = {
                "model": used_model,
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a data transformation assistant. Follow the user's instructions precisely. Output ONLY the requested format, no explanations.",
                    },
                    {"role": "user", "content": user_message},
                ],
                "temperature": 0.1,
            }

            if config.max_tokens is not None:
                api_kwargs["max_tokens"] = config.max_tokens

            if json_mode:
                api_kwargs["response_format"] = {"type": "json_object"}

            response = client.chat.completions.create(**api_kwargs)
            result = response.choices[0].message.content or ""
            s.add(outputLen=len(result))

            # Log token usage if available
            if response.usage:
                s.add(
                    inputTokens=response.usage.prompt_tokens,
                    outputTokens=response.usage.completion_tokens,
                    totalTokens=response.usage.total_tokens,
                )

            return result
        except Exception as e:
            error_msg = str(e)
            # Sanitize sensitive info from error messages
            if "api_key" in error_msg.lower() or "sk-" in error_msg:
                error_msg = "Authentication error - check OPENAI_API_KEY in secrets.yaml"
            s.add(error=error_msg)
            return f"Error: {error_msg}"


def transform_file(
    *,
    prompt: str,
    in_file: str,
    out_file: str,
    model: str | None = None,
    json_mode: bool = False,
) -> str:
    """Transform a file's content using an LLM and write to output file.

    Reads the input file, transforms its content according to the prompt,
    and writes the result to the output file.

    Args:
        prompt: Instructions for how to transform/process the content
        in_file: Path to input file (relative to cwd or absolute)
        out_file: Path to output file (relative to cwd or absolute)
        model: AI model to use (uses ot_llm.model from config if not specified)
        json_mode: If True, request JSON output format from the model

    Returns:
        Success message with bytes written, or error message

    Examples:
        # Convert markdown to restructured text
        ot_llm.transform_file(
            prompt="Convert this markdown to reStructuredText format",
            in_file="README.md",
            out_file="README.rst",
        )

        # Extract data as JSON
        ot_llm.transform_file(
            prompt="Extract all URLs and their descriptions as JSON",
            in_file="links.txt",
            out_file="links.json",
            json_mode=True,
        )

        # Translate content
        ot_llm.transform_file(
            prompt="Translate this to Spanish",
            in_file="greeting.txt",
            out_file="greeting_es.txt",
        )
    """
    with LogSpan(
        span="ot_llm.transform_file", promptLen=len(prompt), inFile=in_file, outFile=out_file
    ) as s:
        # Validate prompt
        if not prompt or not prompt.strip():
            s.add(error="empty_prompt")
            return "Error: prompt is required and cannot be empty"

        # Resolve and read input file
        try:
            in_path = resolve_cwd_path(in_file)
            if not in_path.exists():
                s.add(error="in_file_not_found")
                return f"Error: Input file not found: {in_file}"
            if not in_path.is_file():
                s.add(error="in_file_not_file")
                return f"Error: Input path is not a file: {in_file}"
            in_content = in_path.read_text(encoding="utf-8")
        except UnicodeDecodeError as e:
            s.add(error="in_file_decode_error")
            return f"Error: Could not decode input file as UTF-8: {e}"
        except OSError as e:
            s.add(error=f"in_file_read_error: {e}")
            return f"Error: Could not read input file: {e}"

        if not in_content.strip():
            s.add(error="empty_in_file")
            return "Error: Input file is empty"

        s.add(inLen=len(in_content))

        # Transform the content
        result = transform(
            data=in_content,
            prompt=prompt,
            model=model,
            json_mode=json_mode,
        )

        # Check if transform returned an error
        if result.startswith("Error:"):
            s.add(error="transform_failed")
            return result

        # Resolve and write output file
        try:
            out_path = resolve_cwd_path(out_file)
            # Create parent directories if needed
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(result, encoding="utf-8")
            bytes_written = len(result.encode("utf-8"))
            s.add(outLen=bytes_written)
            return f"OK: Transformed {in_file} -> {out_file} ({bytes_written} bytes)"
        except OSError as e:
            s.add(error=f"out_file_write_error: {e}")
            return f"Error: Could not write output file: {e}"
