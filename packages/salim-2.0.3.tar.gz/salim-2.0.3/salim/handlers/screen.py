"""
Screen & UI handlers — screenshot, type, click, scroll, notify, volume, brightness.
Uses HTML parse_mode throughout.
"""
from __future__ import annotations

import asyncio
import html
import io
import platform
import re
import shutil

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async, is_mac, is_linux, is_windows

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

OS = platform.system()


class ScreenHandlers:

    @require_auth
    async def cmd_screenshot(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        delay = 0
        if ctx.args:
            try: delay = int(ctx.args[0])
            except ValueError: pass
        if delay:
            await update.effective_message.reply_text(f"📸 Screenshot in {delay}s...")
            await asyncio.sleep(delay)
        try:
            import pyautogui
            shot = pyautogui.screenshot()
            if len(ctx.args) >= 4:
                try:
                    x, y, w, h = [int(a) for a in ctx.args[:4]]
                    shot = shot.crop((x, y, x + w, y + h))
                except Exception:
                    pass
            buf = io.BytesIO()
            shot.save(buf, format="JPEG", quality=self.config.screenshot_quality, optimize=True)
            buf.seek(0)
            size = buf.getbuffer().nbytes
            w, h = shot.size
            await update.effective_message.reply_photo(photo=buf, caption=f"📸 {w}×{h} · {size // 1024}KB")
        except ImportError:
            await update.effective_message.reply_text(
                "❌ Missing: <code>pip install pyautogui Pillow</code>", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ Screenshot failed: {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_type(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/type &lt;text to type&gt;</code>", parse_mode=H
            )
            return
        text = " ".join(ctx.args)
        try:
            import pyautogui
            pyautogui.write(text, interval=0.03)
            await update.effective_message.reply_text(f"⌨️ Typed: <code>{esc(text[:100])}</code>", parse_mode=H)
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_key(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/key &lt;shortcut&gt;</code>\n"
                "Examples: <code>/key ctrl+c</code>  <code>/key cmd+space</code>  <code>/key enter</code>",
                parse_mode=H
            )
            return
        combo = ctx.args[0].lower()
        try:
            import pyautogui
            if "+" in combo:
                pyautogui.hotkey(*combo.split("+"))
            else:
                pyautogui.press(combo)
            await update.effective_message.reply_text(f"⌨️ Pressed: <code>{esc(combo)}</code>", parse_mode=H)
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_click(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await update.effective_message.reply_text(
                "Usage: <code>/click &lt;x&gt; &lt;y&gt; [left|right|middle] [clicks]</code>", parse_mode=H
            )
            return
        try:
            import pyautogui
            x = int(ctx.args[0]); y = int(ctx.args[1])
            button = ctx.args[2] if len(ctx.args) > 2 else "left"
            clicks = int(ctx.args[3]) if len(ctx.args) > 3 else 1
            pyautogui.click(x, y, button=button, clicks=clicks, interval=0.1)
            await update.effective_message.reply_text(
                f"🖱️ Clicked <code>{esc(button)}×{clicks}</code> at ({x}, {y})", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_scroll(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/scroll &lt;amount&gt;</code> (positive=up, negative=down)", parse_mode=H
            )
            return
        try:
            import pyautogui
            amount = int(ctx.args[0])
            if len(ctx.args) >= 3:
                pyautogui.scroll(amount, x=int(ctx.args[1]), y=int(ctx.args[2]))
            else:
                pyautogui.scroll(amount)
            direction = "up" if amount > 0 else "down"
            await update.effective_message.reply_text(f"🖱️ Scrolled {direction} by {abs(amount)}")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_move(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await update.effective_message.reply_text("Usage: <code>/move &lt;x&gt; &lt;y&gt;</code>", parse_mode=H)
            return
        try:
            import pyautogui
            x, y = int(ctx.args[0]), int(ctx.args[1])
            pyautogui.moveTo(x, y, duration=0.3)
            await update.effective_message.reply_text(f"🖱️ Moved to ({x}, {y})")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_mousepos(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        try:
            import pyautogui
            x, y = pyautogui.position()
            w, h = pyautogui.size()
            await update.effective_message.reply_text(f"🖱️ Mouse: ({x}, {y})\n📐 Screen: {w}×{h}")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_notify(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/notify &lt;title&gt; | &lt;message&gt;</code>", parse_mode=H
            )
            return
        full = " ".join(ctx.args)
        if "|" in full:
            title, msg = full.split("|", 1)
        else:
            title, msg = "Salim", full
        title = title.strip(); msg = msg.strip()

        if is_mac():
            await run_shell_async(f'osascript -e \'display notification "{msg}" with title "{title}"\'')
        elif is_windows():
            await run_shell_async(
                f'powershell -command "Add-Type -AssemblyName System.Windows.Forms; '
                f'[System.Windows.Forms.MessageBox]::Show(\'{msg}\', \'{title}\')"'
            )
        else:
            await run_shell_async(f'notify-send "{title}" "{msg}"')

        await update.effective_message.reply_text(
            f"🔔 Notification sent: <b>{esc(title)}</b>\n<i>{esc(msg)}</i>", parse_mode=H
        )

    @require_auth
    @require_auth
    async def cmd_volume(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /volume            — show current volume
        /volume 50         — set to 50%
        /volume up         — +10%
        /volume down       — -10%
        /volume mute       — toggle mute
        """
        import shutil
        msg = update.effective_message

        async def _get_vol() -> str:
            """Return current volume as a human-readable string."""
            if is_mac():
                out, _ = await run_shell_async(
                    "osascript -e 'output volume of (get volume settings)'"
                )
                return f"{out.strip()}%"
            elif is_linux():
                # Try pactl (PulseAudio/PipeWire) first — most reliable
                if shutil.which("pactl"):
                    out, rc = await run_shell_async(
                        "pactl get-sink-volume @DEFAULT_SINK@"
                    )
                    if rc == 0:
                        import re
                        m = re.search(r"(\d+)%", out)
                        if m:
                            return f"{m.group(1)}%"
                # Fallback: amixer
                if shutil.which("amixer"):
                    out, rc = await run_shell_async(
                        "amixer get Master"
                    )
                    if rc == 0:
                        import re
                        m = re.search(r"\[(\d+)%\]", out)
                        if m:
                            return f"{m.group(1)}%"
                return "unknown"
            else:  # Windows
                out, rc = await run_shell_async(
                    'powershell -NoProfile -Command '
                    '"[math]::Round((Get-Volume).Volume * 100)"'
                )
                if rc == 0 and out.strip().isdigit():
                    return f"{out.strip()}%"
                return "unknown"

        async def _set_vol(level: str) -> tuple[bool, str]:
            """
            Set volume. level is 'up', 'down', 'mute', or '0'-'100'.
            Returns (success, message).
            """
            if is_mac():
                if level == "mute":
                    _, rc = await run_shell_async(
                        "osascript -e 'set volume output muted (not (output muted of (get volume settings)))'"
                    )
                    return rc == 0, "🔇 Mute toggled"
                elif level == "up":
                    _, rc = await run_shell_async(
                        "osascript -e 'set volume output volume "
                        "(output volume of (get volume settings) + 10)'"
                    )
                elif level == "down":
                    _, rc = await run_shell_async(
                        "osascript -e 'set volume output volume "
                        "(output volume of (get volume settings) - 10)'"
                    )
                else:
                    try:
                        v = max(0, min(100, int(level)))
                    except ValueError:
                        return False, f"❌ Invalid level: {level}"
                    _, rc = await run_shell_async(
                        f"osascript -e 'set volume output volume {v}'"
                    )
                return rc == 0, ""

            elif is_linux():
                if shutil.which("pactl"):
                    # pactl — works with PulseAudio and PipeWire
                    if level == "mute":
                        _, rc = await run_shell_async(
                            "pactl set-sink-mute @DEFAULT_SINK@ toggle"
                        )
                        return rc == 0, "🔇 Mute toggled"
                    elif level == "up":
                        _, rc = await run_shell_async(
                            "pactl set-sink-volume @DEFAULT_SINK@ +10%"
                        )
                    elif level == "down":
                        _, rc = await run_shell_async(
                            "pactl set-sink-volume @DEFAULT_SINK@ -10%"
                        )
                    else:
                        try:
                            v = max(0, min(150, int(level)))  # pactl allows >100%
                        except ValueError:
                            return False, f"❌ Invalid level: {level}"
                        _, rc = await run_shell_async(
                            f"pactl set-sink-volume @DEFAULT_SINK@ {v}%"
                        )
                    return rc == 0, ""

                elif shutil.which("amixer"):
                    # amixer ALSA fallback
                    if level == "mute":
                        _, rc = await run_shell_async("amixer set Master toggle")
                        return rc == 0, "🔇 Mute toggled"
                    elif level == "up":
                        _, rc = await run_shell_async("amixer set Master 10%+")
                    elif level == "down":
                        _, rc = await run_shell_async("amixer set Master 10%-")
                    else:
                        try:
                            v = max(0, min(100, int(level)))
                        except ValueError:
                            return False, f"❌ Invalid level: {level}"
                        _, rc = await run_shell_async(f"amixer set Master {v}%")
                    return rc == 0, ""

                return False, "❌ No volume control tool found (install pulseaudio-utils or alsa-utils)"

            else:  # Windows
                if level == "mute":
                    # Toggle mute via nircmd (free) or PowerShell SendKeys
                    if shutil.which("nircmd"):
                        _, rc = await run_shell_async("nircmd mutesysvolume 2")
                        return rc == 0, "🔇 Mute toggled"
                    else:
                        # SendKeys approach: VK_VOLUME_MUTE = 0xAD
                        _, rc = await run_shell_async(
                            'powershell -NoProfile -Command '
                            '"$wsh = New-Object -ComObject wscript.shell; '
                            '$wsh.SendKeys([char]173)"'
                        )
                        return rc == 0, "🔇 Mute toggled"

                elif level in ("up", "down"):
                    sign = "+" if level == "up" else "-"
                    if shutil.which("nircmd"):
                        delta = 6553  # ~10% of 65535
                        action = "changesysvolume"
                        _, rc = await run_shell_async(
                            f"nircmd {action} {sign.replace('+','')}{delta if level == 'up' else delta}"
                        )
                        if rc == 0:
                            return True, ""
                    # PowerShell fallback via SendKeys (VK_VOLUME_UP/DOWN)
                    vk = "175" if level == "up" else "174"
                    _, rc = await run_shell_async(
                        f'powershell -NoProfile -Command '
                        f'"$wsh = New-Object -ComObject wscript.shell; '
                        f'for($i=0;$i -lt 5;$i++){{$wsh.SendKeys([char]{vk})}}"'
                    )
                    return rc == 0, ""

                else:
                    try:
                        v = max(0, min(100, int(level)))
                    except ValueError:
                        return False, f"❌ Invalid level: {level}"
                    # Set exact volume: nircmd is most reliable
                    if shutil.which("nircmd"):
                        nircmd_val = int(v * 655.35)  # 0-65535 scale
                        _, rc = await run_shell_async(f"nircmd setsysvolume {nircmd_val}")
                        return rc == 0, ""
                    # PowerShell fallback using Set-Volume cmdlet (Windows 10+)
                    _, rc = await run_shell_async(
                        f'powershell -NoProfile -Command '
                        f'"Set-Volume -Volume ([Math]::Round({v}/100, 2)) 2>$null"'
                    )
                    if rc == 0:
                        return True, ""
                    # Last resort: WScript COM object (up/down only, no exact set)
                    return False, (
                        "⚠️ Exact volume not supported without nircmd.\n"
                        "Install free nircmd: https://www.nirsoft.net/utils/nircmd.html\n"
                        "Or use <code>/volume up</code> / <code>/volume down</code>"
                    )

        # ── No args: report current volume ────────────────────────────────────
        if not ctx.args:
            vol = await _get_vol()
            await msg.reply_text(
                f"🔊 Current volume: <b>{esc(vol)}</b>\n\n"
                f"Set: <code>/volume 50</code> · <code>/volume up</code> · "
                f"<code>/volume down</code> · <code>/volume mute</code>",
                parse_mode=H
            )
            return

        level = ctx.args[0].lower().strip()
        ok, extra = await _set_vol(level)

        if not ok and extra:
            await msg.reply_text(extra, parse_mode=H)
            return

        # Report new volume after change
        vol_after = await _get_vol()
        label = extra if extra else f"🔊 Volume → <b>{esc(vol_after)}</b>"
        await msg.reply_text(label, parse_mode=H)

    @require_auth
    async def cmd_brightness(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/brightness &lt;0-100&gt;</code>", parse_mode=H
            )
            return

        import shutil
        try:
            level = max(0, min(100, int(ctx.args[0])))
        except ValueError:
            await update.effective_message.reply_text("❌ Level must be 0–100", parse_mode=H)
            return

        msg = update.effective_message

        if is_mac():
            # Strategy 1: `brightness` CLI (brew install brightness  — free, open source)
            if shutil.which("brightness"):
                val = round(level / 100, 2)
                out, rc = await run_shell_async(f"brightness {val}")
                if rc == 0:
                    await msg.reply_text(f"💡 Brightness → <code>{level}%</code>", parse_mode=H)
                    return

            # Strategy 2: m1ddc (Apple Silicon external displays, brew install m1ddc)
            if shutil.which("m1ddc"):
                out, rc = await run_shell_async(f"m1ddc set luminance {level}")
                if rc == 0:
                    await msg.reply_text(f"💡 Brightness → <code>{level}%</code>", parse_mode=H)
                    return

            # Strategy 3: ddcctl (Intel Macs + external displays, brew install ddcctl)
            if shutil.which("ddcctl"):
                out, rc = await run_shell_async(f"ddcctl -d 1 -b {level}")
                if rc == 0:
                    await msg.reply_text(f"💡 Brightness → <code>{level}%</code>", parse_mode=H)
                    return

            # Strategy 4: CoreBrightness via Python (macOS built-in, no install needed)
            py_script = (
                "import subprocess, sys\n"
                "try:\n"
                "    import objc\n"
                "    from CoreFoundation import CFStringCreateWithCString\n"
                "    cb = objc.loadBundle('CoreBrightness', bundle_path='/System/Library/PrivateFrameworks/CoreBrightness.framework', module_globals=globals())\n"
                "    s = CBDisplayManager.sharedDisplayManager()\n"
                f"    s.setMainDisplayBrightness_({level / 100})\n"
                "    sys.exit(0)\n"
                "except Exception as e:\n"
                "    sys.exit(1)\n"
            )
            import sys as _sys
            out, rc = await run_shell_async(f'{_sys.executable} -c "{py_script}"')
            if rc == 0:
                await msg.reply_text(f"💡 Brightness → <code>{level}%</code>", parse_mode=H)
                return

            await msg.reply_text(
                f"⚠️ Could not set brightness on macOS.\n"
                f"Install <code>brightness</code> CLI: <code>brew install brightness</code>\n"
                f"For external monitors: <code>brew install m1ddc</code> (Apple Silicon) "
                f"or <code>brew install ddcctl</code> (Intel)",
                parse_mode=H
            )
            return

        elif is_linux():
            # Strategy 1: /sys/class/backlight (built-in laptop displays)
            backlight_root = "/sys/class/backlight"
            out, _ = await run_shell_async(f"ls {backlight_root} 2>/dev/null")
            device = out.split("\n")[0].strip()
            if device:
                try:
                    max_b, rc = await run_shell_async(
                        f"cat {backlight_root}/{device}/max_brightness"
                    )
                    if rc == 0 and max_b.strip().isdigit():
                        val = int(max_b.strip()) * level // 100
                        _, rc2 = await run_shell_async(
                            f"echo {val} | sudo tee {backlight_root}/{device}/brightness"
                        )
                        if rc2 == 0:
                            await msg.reply_text(
                                f"💡 Brightness → <code>{level}%</code> (via {device})", parse_mode=H
                            )
                            return
                except Exception:
                    pass

            # Strategy 2: xrandr (X11 — gamma-based, works on any connected display)
            if shutil.which("xrandr"):
                val = round(level / 100, 2)
                # Get primary / first connected output name
                out, _ = await run_shell_async(
                    "xrandr | awk '/ connected/{print $1; exit}'"
                )
                output = out.strip()
                if output:
                    _, rc = await run_shell_async(
                        f"xrandr --output {output} --brightness {val}"
                    )
                    if rc == 0:
                        await msg.reply_text(
                            f"💡 Brightness → <code>{level}%</code> (gamma, via xrandr)", parse_mode=H
                        )
                        return

            # Strategy 3: ddcutil (hardware DDC/CI — external monitors, needs i2c-dev)
            if shutil.which("ddcutil"):
                _, rc = await run_shell_async(f"ddcutil setvcp 10 {level}")
                if rc == 0:
                    await msg.reply_text(
                        f"💡 Brightness → <code>{level}%</code> (DDC/CI via ddcutil)", parse_mode=H
                    )
                    return

            await msg.reply_text(
                f"⚠️ Could not set brightness. Tried: backlight sysfs, xrandr, ddcutil.\n"
                f"For external monitors: <code>sudo apt install ddcutil</code>",
                parse_mode=H
            )

        else:  # Windows
            # Strategy 1: WMI (built-in, works for laptop displays)
            _, rc = await run_shell_async(
                f'powershell -NoProfile -Command '
                f'"(Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightnessMethods)'
                f'.WmiSetBrightness(1,{level})"'
            )
            if rc == 0:
                await msg.reply_text(f"💡 Brightness → <code>{level}%</code>", parse_mode=H)
                return

            # Strategy 2: nircmd (free util — works for many external monitors too)
            if shutil.which("nircmd"):
                # nircmd uses 0–128 scale
                val = int(level * 128 / 100)
                _, rc = await run_shell_async(f"nircmd setbrightness {val}")
                if rc == 0:
                    await msg.reply_text(f"💡 Brightness → <code>{level}%</code>", parse_mode=H)
                    return

            await msg.reply_text(
                f"⚠️ WMI brightness control failed (may not be supported on external monitors).\n"
                f"For external monitors install <b>NirCmd</b> (free): https://www.nirsoft.net/utils/nircmd.html",
                parse_mode=H
            )

    @require_auth
    async def cmd_copy(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: <code>/copy &lt;text&gt;</code>", parse_mode=H)
            return
        text = " ".join(ctx.args)
        try:
            import pyperclip
            pyperclip.copy(text)
            await update.effective_message.reply_text(
                f"📋 Copied: <code>{esc(text[:200])}</code>", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_paste(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        try:
            import pyperclip
            content = pyperclip.paste()
            if not content:
                await update.effective_message.reply_text("📋 Clipboard is empty.")
                return
            await update.effective_message.reply_text(
                f"📋 <b>Clipboard</b>\n\n<pre>{esc(content[:2000])}</pre>", parse_mode=H
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(e)}", parse_mode=H)

    @require_auth
    async def cmd_open(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/open &lt;app|file|url&gt;</code>\n"
                "Examples: <code>/open chrome</code>, <code>/open spotify</code>, "
                "<code>/open https://youtube.com</code>, <code>/open ~/Desktop/file.pdf</code>",
                parse_mode=H
            )
            return

        import shutil
        from pathlib import Path

        raw = " ".join(ctx.args).strip()

        # ── Smart app name resolver ──────────────────────────────────────────
        # Maps common natural names → actual executable / app name per OS
        APP_MAP_LINUX = {
            "chrome": ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser"],
            "google chrome": ["google-chrome", "google-chrome-stable", "chromium-browser"],
            "chromium": ["chromium", "chromium-browser"],
            "firefox": ["firefox"],
            "safari": ["safari"],
            "brave": ["brave-browser", "brave"],
            "edge": ["microsoft-edge", "msedge"],
            "opera": ["opera"],
            "browser": ["google-chrome", "firefox", "chromium", "brave-browser"],
            "vscode": ["code"],
            "vs code": ["code"],
            "visual studio code": ["code"],
            "code": ["code"],
            "spotify": ["spotify"],
            "discord": ["discord"],
            "slack": ["slack"],
            "zoom": ["zoom"],
            "telegram": ["telegram-desktop", "telegram"],
            "vlc": ["vlc"],
            "gimp": ["gimp"],
            "obs": ["obs"],
            "obs studio": ["obs"],
            "terminal": ["x-terminal-emulator", "gnome-terminal", "konsole", "xterm"],
            "bash": ["gnome-terminal", "x-terminal-emulator", "xterm"],
            "console": ["gnome-terminal", "x-terminal-emulator"],
            "files": ["nautilus", "thunar", "nemo", "dolphin"],
            "file manager": ["nautilus", "thunar", "nemo"],
            "nautilus": ["nautilus"],
            "finder": ["nautilus"],
            "explorer": ["nautilus", "thunar"],
            "calculator": ["gnome-calculator", "kcalc", "galculator"],
            "settings": ["gnome-control-center", "systemsettings5"],
            "system settings": ["gnome-control-center"],
            "text editor": ["gedit", "kate", "mousepad", "xed"],
            "notepad": ["gedit", "kate", "mousepad"],
            "gedit": ["gedit"],
            "steam": ["steam"],
            "skype": ["skype"],
            "thunderbird": ["thunderbird"],
            "libreoffice": ["libreoffice"],
            "word": ["libreoffice --writer"],
            "excel": ["libreoffice --calc"],
            "powerpoint": ["libreoffice --impress"],
        }

        APP_MAP_MAC = {
            "chrome": "Google Chrome",
            "google chrome": "Google Chrome",
            "chromium": "Chromium",
            "firefox": "Firefox",
            "safari": "Safari",
            "brave": "Brave Browser",
            "edge": "Microsoft Edge",
            "opera": "Opera",
            "browser": "Google Chrome",
            "vscode": "Visual Studio Code",
            "vs code": "Visual Studio Code",
            "visual studio code": "Visual Studio Code",
            "code": "Visual Studio Code",
            "spotify": "Spotify",
            "discord": "Discord",
            "slack": "Slack",
            "zoom": "zoom.us",
            "telegram": "Telegram",
            "vlc": "VLC",
            "gimp": "GIMP",
            "obs": "OBS",
            "obs studio": "OBS",
            "terminal": "Terminal",
            "bash": "Terminal",
            "console": "Terminal",
            "iterm": "iTerm",
            "files": "Finder",
            "file manager": "Finder",
            "finder": "Finder",
            "explorer": "Finder",
            "calculator": "Calculator",
            "settings": "System Preferences",
            "system settings": "System Preferences",
            "preferences": "System Preferences",
            "text editor": "TextEdit",
            "notepad": "TextEdit",
            "textedit": "TextEdit",
            "steam": "Steam",
            "skype": "Skype",
            "thunderbird": "Thunderbird",
            "libreoffice": "LibreOffice",
            "word": "Microsoft Word",
            "excel": "Microsoft Excel",
            "powerpoint": "Microsoft PowerPoint",
            "pages": "Pages",
            "numbers": "Numbers",
            "keynote": "Keynote",
            "xcode": "Xcode",
            "maps": "Maps",
            "music": "Music",
            "photos": "Photos",
        }

        key = raw.lower().strip("'\"")

        # URLs — pass straight through
        if key.startswith(("http://", "https://", "www.")):
            resolved = raw
        # File paths — pass straight through
        elif key.startswith(("/", "~", "./")) or Path(raw).expanduser().exists():
            resolved = str(Path(raw).expanduser())
        # App name lookup
        elif is_mac():
            if key in APP_MAP_MAC:
                resolved = APP_MAP_MAC[key]
                cmd = f"open -a '{resolved}' 2>/dev/null || open '{resolved}'"
            else:
                # Try as-is with `open -a`
                resolved = raw
                cmd = f"open -a '{resolved}' 2>/dev/null || open '{resolved}'"
            out, rc = await run_shell_async(cmd)
            icon = "🚀" if rc == 0 else "❌"
            status = "opened" if rc == 0 else "failed to open"
            await update.effective_message.reply_text(
                f"{icon} {status.title()}: <code>{esc(resolved)}</code>",
                parse_mode=H
            )
            return
        elif is_windows():
            APP_MAP_WINDOWS = {
                # ── Browsers ──────────────────────────────────────────────────
                "chrome":               "chrome",
                "google chrome":        "chrome",
                "chromium":             "chromium",
                "firefox":              "firefox",
                "safari":               "safari",          # rarely installed on Win
                "brave":                "brave",
                "edge":                 "msedge",
                "microsoft edge":       "msedge",
                "opera":                "opera",
                "browser":              "chrome",
                # ── Editors / IDEs ─────────────────────────────────────────────
                "vscode":               "code",
                "vs code":              "code",
                "visual studio code":   "code",
                "code":                 "code",
                "visual studio":        "devenv",
                "notepad":              "notepad",
                "notepad++":            "notepad++",
                "wordpad":              "wordpad",
                "sublime":              "subl",
                "sublime text":         "subl",
                # ── Microsoft Office ───────────────────────────────────────────
                "word":                 "winword",
                "microsoft word":       "winword",
                "excel":                "excel",
                "microsoft excel":      "excel",
                "powerpoint":           "powerpnt",
                "microsoft powerpoint": "powerpnt",
                "outlook":              "outlook",
                "onenote":              "onenote",
                "access":               "msaccess",
                # ── Communication ─────────────────────────────────────────────
                "discord":              "discord",
                "slack":                "slack",
                "zoom":                 "zoom",
                "telegram":             "telegram",
                "teams":                "teams",
                "microsoft teams":      "teams",
                "skype":                "skype",
                "whatsapp":             "whatsapp",
                # ── Media ─────────────────────────────────────────────────────
                "spotify":              "spotify",
                "vlc":                  "vlc",
                "media player":         "wmplayer",
                "windows media player": "wmplayer",
                "itunes":               "itunes",
                "photos":               "ms-photos:",          # ms-uri
                "music":                "ms-windows-music:",
                "movies":               "ms-windows-video:",
                # ── Creative / Dev ────────────────────────────────────────────
                "gimp":                 "gimp-2.10",
                "obs":                  "obs64",
                "obs studio":           "obs64",
                "steam":                "steam",
                "epic":                 "EpicGamesLauncher",
                "epic games":           "EpicGamesLauncher",
                "git":                  "git-gui",
                "github desktop":       "github",
                "postman":              "postman",
                "docker":               "docker desktop",
                # ── Windows built-ins ─────────────────────────────────────────
                "calculator":           "calc",
                "paint":                "mspaint",
                "file explorer":        "explorer",
                "explorer":             "explorer",
                "files":                "explorer",
                "finder":               "explorer",
                "task manager":         "taskmgr",
                "control panel":        "control",
                "settings":             "ms-settings:",        # ms-uri
                "system settings":      "ms-settings:",
                "store":                "ms-windows-store:",
                "camera":               "microsoft.windows.camera:",
                "clock":                "ms-clock:",
                "snipping tool":        "snippingtool",
                "snip":                 "snippingtool",
                "paint 3d":             "ms-paint:",
                "maps":                 "bingmaps:",
                "weather":              "msnweather:",
                "mail":                 "mailto:",
                # ── Terminal ──────────────────────────────────────────────────
                "terminal":             "wt",                  # Windows Terminal
                "windows terminal":     "wt",
                "cmd":                  "cmd",
                "powershell":           "powershell",
                "bash":                 "bash",
                "console":              "wt",
                # ── Utilities ─────────────────────────────────────────────────
                "regedit":              "regedit",
                "task scheduler":       "taskschd.msc",
                "device manager":       "devmgmt.msc",
                "disk management":      "diskmgmt.msc",
                "event viewer":         "eventvwr.msc",
                "services":             "services.msc",
                "thunderbird":          "thunderbird",
                "7zip":                 "7zFM",
                "7-zip":                "7zFM",
                "winrar":               "winrar",
            }

            # ms-uri schemes (ms-settings:, ms-photos:, etc.) need `start`
            MS_URI_PREFIXES = ("ms-", "microsoft.", "bingmaps:", "msnweather:", "mailto:")

            key_w = key.strip("'\"")
            if key_w in APP_MAP_WINDOWS:
                resolved = APP_MAP_WINDOWS[key_w]
            else:
                resolved = raw

            # Choose the right launch mechanism
            if any(resolved.startswith(p) for p in MS_URI_PREFIXES):
                # ms-uri: must use `start` with the URI directly
                cmd = f'powershell -NoProfile -Command "Start-Process \'{resolved}\'"'
            elif resolved.endswith(".msc"):
                # MMC snap-ins
                cmd = f'powershell -NoProfile -Command "Start-Process mmc \\"{resolved}\\""'
            else:
                # Regular executable — use Start-Process so it detaches cleanly
                cmd = (
                    f'powershell -NoProfile -Command '
                    f'"Start-Process \'{resolved}\' -ErrorAction Stop"'
                )

            out, rc = await run_shell_async(cmd, timeout=8)
            if rc == 0:
                await update.effective_message.reply_text(
                    f"🚀 Launched: <code>{esc(resolved)}</code>", parse_mode=H
                )
            else:
                # Last-ditch: fall back to `start` (handles things in PATH that PS misses)
                out2, rc2 = await run_shell_async(f'cmd /c start "" "{resolved}"', timeout=5)
                icon = "🚀" if rc2 == 0 else "❌"
                msg = f"{icon} <code>{esc(resolved)}</code>"
                if rc2 != 0:
                    msg += (
                        f"\n<i>Not found. Is <code>{esc(resolved)}</code> installed "
                        f"and on your PATH?</i>"
                    )
                await update.effective_message.reply_text(msg, parse_mode=H)
            return
        else:
            # Linux: try candidates in order until one works
            resolved = raw
            if key in APP_MAP_LINUX:
                candidates = APP_MAP_LINUX[key]
                # Find first installed candidate
                found = None
                for cand in candidates:
                    exe = cand.split()[0]  # handle "libreoffice --writer"
                    if shutil.which(exe):
                        found = cand
                        break
                if found:
                    resolved = found
                # else fall through with raw input

        # Linux default: use xdg-open for URLs/files, direct exec for apps
        if is_linux():
            if resolved.startswith(("http://", "https://", "www.", "/")):
                cmd = f"xdg-open '{resolved}' >/dev/null 2>&1 &"
            elif Path(resolved).expanduser().exists():
                cmd = f"xdg-open '{Path(resolved).expanduser()}' >/dev/null 2>&1 &"
            else:
                # Launch as application directly
                cmd = f"nohup {resolved} >/dev/null 2>&1 &"

            out, rc = await run_shell_async(cmd, timeout=5)
            # xdg-open launched in background — rc 0 means launched, not necessarily opened
            if rc in (0, -1):  # -1 = timeout (process launched successfully in bg)
                await update.effective_message.reply_text(
                    f"🚀 Launched: <code>{esc(resolved)}</code>", parse_mode=H
                )
            else:
                await update.effective_message.reply_text(
                    f"❌ Could not open <code>{esc(raw)}</code>\n"
                    f"<i>Make sure it's installed: <code>which {esc(raw.split()[0])}</code></i>",
                    parse_mode=H
                )
        else:
            # Fallback for any other OS
            out, rc = await run_shell_async(f"xdg-open '{resolved}' &")
            await update.effective_message.reply_text(
                f"{'🚀' if rc == 0 else '❌'} <code>{esc(resolved)}</code>", parse_mode=H
            )
