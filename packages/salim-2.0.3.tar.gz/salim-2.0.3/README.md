# 🖥️ Salim — Control Your Laptop from Telegram

<p align="center">
  <strong>Type a message on your phone. Your laptop does it.</strong><br>
  Screenshots · Files · Shell · Processes · Power · AI · Documents · Email
</p>

<p align="center">
  <img src="https://img.shields.io/badge/python-3.9+-blue.svg" alt="Python 3.9+">
  <img src="https://img.shields.io/badge/platform-macOS%20%7C%20Linux%20%7C%20Windows-lightgrey" alt="Platform">
  <img src="https://img.shields.io/badge/License-MIT-green.svg" alt="MIT License">
  <img src="https://img.shields.io/badge/AI-NVIDIA%20%7C%20Groq%20%7C%20Z.AI-orange" alt="AI Providers">
</p>

---

## 🤔 What Is This?

Salim turns your laptop into a bot you can control from **anywhere in the world** using Telegram — the free messaging app.

Left your laptop at home? Need to draft a report from your phone? Want to read your emails or create an Excel invoice while commuting?

**Just text your bot.** That's it.

```
You:    "create excel invoice for ABC Company"
Salim:  📎 invoice_abc.xlsx  [sends real file to Telegram]

You:    "email read"
Salim:  📬 Inbox — 5 emails
        [ID:12] Q3 Report — from boss@company.com

You:    "write resignation letter for Ahmed, last day April 30"
Salim:  📎 resignation_letter.docx  [ready-to-send Word file]
```

---

## ⚡ Get Started in 3 Minutes

### Step 1 — Install

```bash
pip install salim
```

Python 3.9 or newer required.

> **Don't have Python?** Download free from [python.org](https://python.org). Then open Terminal and run the command above.

### Step 2 — Run Setup

```bash
salim setup
```

The wizard walks you through:
1. **Get a Telegram bot token** — 30 seconds (instructions shown on screen)
2. **Add your Telegram user ID** — so only *you* can control your laptop
3. **Optionally add AI keys** — for plain English commands (all free)

### Step 3 — Start

```bash
salim start
```

Open Telegram, find your bot, send `/start` — you're in control.

---

## 🤖 AI Mode — Just Type Naturally

With AI configured (optional but recommended — free!), skip commands entirely:

| What you type | What happens |
|---|---|
| `take a screenshot` | 📸 Sends screenshot |
| `how's my RAM?` | 🧠 Shows memory usage |
| `create excel invoice for Acme Corp` | 📎 Sends real .xlsx file |
| `write resignation letter for Ahmed` | 📎 Sends formatted .docx |
| `email read` | 📬 Shows your inbox |
| `email send to boss@co.com subject Report body Done` | ✅ Email sent |
| `mute volume` | 🔇 Mutes speakers |
| `shut down` | 🔒 Asks confirmation, shuts down |

**Three free AI providers:**

| Provider | Where to get key | Speed |
|---|---|---|
| 🟢 **NVIDIA NIM** | [build.nvidia.com](https://build.nvidia.com) | Fast |
| 🟡 **Groq** | [console.groq.com](https://console.groq.com) | Ultra-fast |
| 🔵 **Z.AI** | [z.ai](https://z.ai) | Fast & 100% free |

---

## 📄 Office Agent — Create & Edit Documents

The most powerful feature: create any professional document with one message.

### Create Documents

```
/agent create word Q1 sales report
/agent create excel invoice for ABC Company
/agent create csv employee database
/agent create pdf company profile 2025
/agent create powerpoint project overview 6 slides
```

### Real-World Office Documents

```
/agent write resignation letter for Ahmed, last day April 30
/agent create salary sheet for 15 employees for March 2025
/agent make attendance register for April 2025
/agent build purchase order for 10 laptops at $800 each
/agent write NOC letter for employee John Smith
/agent create employment certificate for Sarah Ahmed
/agent generate project budget for Phase 2 at $50,000
/agent write formal complaint letter to ABC Suppliers
/agent make meeting agenda for Monday board meeting
/agent create staff payroll sheet with deductions
```

Every document is:
- Saved to your Desktop as a real file (.docx, .xlsx, .csv, .pdf, .pptx)
- Sent directly to you in Telegram
- Professionally formatted with headers, tables, footers
- Filled with complete real content — no `[placeholder]` gaps

### Edit Existing Documents

```
/agent edit report.docx add a conclusion section
/agent edit sales.xlsx add column for Q4 targets
/agent edit data.csv delete row 3
/agent add table to report.docx
/agent replace "Manager" with "Director" in letter.docx
/agent add row Ahmed,Sales,5000 to staff.csv
/agent delete paragraph about old policy from contract.docx
```

### Read Documents

```
/agent read contract.docx
/agent read budget.xlsx
/agent read employees.csv
```

### Convert Documents

```
/agent convert report.docx to pdf
/agent convert data.xlsx to csv
```

---

## 📧 Email Integration

Send, read, reply to, and search real emails from Telegram.

### First-Time Setup

```
/agent email setup
```

Follow the on-screen instructions. Works with Gmail, Outlook, Yahoo, and any IMAP/SMTP provider.

### Read Inbox

```
/agent email read
/agent email read 20
```

### Send Email

```
/agent email send to boss@co.com subject Monthly Report body Please see the attached report
/agent email send to hr@co.com subject Leave Request body I need 3 days leave from April 5
```

### Send Email with Attachment

```
/agent email send to ceo@co.com subject Q1 Results body See report attach report.xlsx
```

### Search Emails

```
/agent email search invoice
/agent email search from Ahmed
```

### Reply to Email

```
/agent email reply to 42 Thank you, I will review and get back to you by Friday
```
(Get email ID numbers from `/agent email read`)

---

## 🚨 Smart Alert System

Get notified when your laptop needs attention — with optional call/video prompt buttons.

```
/alert add cpu > 80
/alert add ram > 90
/alert add battery < 20
/alert add disk < 5
/alert add temp > 85
/alert add process nginx
```

### Call/Video Alerts

Add `--call` or `--video` to any alert for urgent notifications with tap-to-call buttons:

```
/alert add cpu > 95 --call
/alert add battery < 10 --video
/alert add process nginx --call
```

When the alert fires, you get an urgent message with a button to immediately open a voice or video call.

### Alert Commands

| Command | What it does |
|---|---|
| `/alert list` | Show all active alerts |
| `/alert del <id>` | Remove an alert |
| `/alert clear` | Remove all alerts |
| `/alert test` | Test with live metrics |

---

## 📱 All Commands

### 🖥️ System Info

| Command | What it does |
|---|---|
| `/info` | Full overview: OS, CPU, RAM, disk, battery, uptime |
| `/cpu` | Per-core CPU usage with visual bar chart |
| `/mem` | RAM and swap usage |
| `/disk` | All drives with used/free space |
| `/battery` | Charge level, plugged in or not |
| `/network` | IP addresses, connection speed |
| `/top` | Live resource monitor (updates 5 times) |

### ⚙️ Processes

| Command | What it does |
|---|---|
| `/ps [name]` | List running programs |
| `/kill <pid>` | Stop a process by ID |
| `/top` | See what's using most CPU/RAM |

### 💻 Shell

| Command | What it does |
|---|---|
| `/run <command>` | Run any terminal command |
| `/runbg <command>` | Run in background, notify when done |
| `/env` | View environment variables |
| `/cron <seconds> <cmd>` | Repeat a command on schedule |

### 📂 Files

| Command | What it does |
|---|---|
| `/ls [path]` | List files in a directory |
| `/find <name>` | Search files by name |
| `/cat <file>` | Read a file's contents |
| `/rm <path>` | Delete file (asks confirmation) |
| `/mv <from> <to>` | Move or rename |
| `/cp <from> <to>` | Copy a file |
| `/download <path>` | Send file from laptop to Telegram |
| `/upload` | Save Telegram file to laptop |
| `/zip <path>` | Create zip archive |

### 📸 Screen & Input

| Command | What it does |
|---|---|
| `/screenshot` | Take and send screenshot |
| `/type <text>` | Type text via keyboard |
| `/key <shortcut>` | Press keyboard shortcut |
| `/click <x> <y>` | Click mouse at coordinates |
| `/open <app>` | Open an app, file, or URL |

### 📄 Document Writer (quick mode)

| Command | What it does |
|---|---|
| `/doc resume for <name>` | Professional CV/resume (.docx) |
| `/doc cover letter for <position>` | Cover letter (.docx) |
| `/doc invoice for <client>` | Invoice with auto-totals (.xlsx) |
| `/doc budget tracker for <month>` | Monthly budget (.xlsx) |
| `/doc salary sheet` | Payroll sheet (.xlsx) |

### 🤖 Autonomous Agent

| Command | What it does |
|---|---|
| `/agent <task>` | Run any complex task |
| `/agenthelp` | Full guide with all examples |
| `/agentstop` | Stop running task |
| `/agentstatus` | Check if task is running |
| `/agentlog` | See last task details |

### 🔋 Power

| Command | What it does |
|---|---|
| `/shutdown` | Shut down (asks confirmation) |
| `/restart` | Restart |
| `/sleep` | Put to sleep |
| `/lock` | Lock screen |

---

## 🔒 Security — Only You Can Control It

- **User whitelist** — Only approved Telegram accounts can send commands
- **Silent rejection** — Strangers get zero response
- **Confirmation dialogs** — Dangerous actions require tap-to-confirm
- **Audit log** — Every command logged with timestamp
- **Secure storage** — Credentials stored locally with strict permissions (chmod 600)

### Adding trusted users

```bash
salim adduser
```

Or add IDs directly to `~/.salim/config.env`:
```
SALIM_ALLOWED_IDS=111222333,444555666
```

> **Find your Telegram user ID:** Message [@userinfobot](https://t.me/userinfobot) and send `/start`.

---

## 🛠️ CLI Commands

```bash
salim setup      # Run setup wizard
salim start      # Start your bot
salim start -v   # Start with detailed logging
salim status     # Check configuration
salim logs       # View command history
salim adduser    # Add authorized user
salim stop       # Stop the bot
```

---

## 🔧 Configuration

Settings saved in `~/.salim/config.env`:

```env
SALIM_BOT_TOKEN=1234567890:ABCdef...
SALIM_ALLOWED_IDS=123456789
SALIM_DOWNLOAD_DIR=/Users/you/Downloads
SALIM_UPLOAD_DIR=/Users/you/Desktop
SALIM_MAX_FILE_MB=50
SALIM_LOG_COMMANDS=true

# AI keys (optional — all free)
SALIM_NVIDIA_API_KEY=nvapi-...
SALIM_GROQ_API_KEY=gsk_...
SALIM_ZAI_API_KEY=...
```

---

## 🚀 Auto-Start at Boot

### macOS

```xml
<!-- ~/Library/LaunchAgents/com.salim.plist -->
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>             <string>com.salim</string>
  <key>ProgramArguments</key>  <array><string>/usr/local/bin/salim</string><string>start</string></array>
  <key>RunAtLoad</key>         <true/>
  <key>KeepAlive</key>         <true/>
</dict>
</plist>
```

```bash
launchctl load ~/Library/LaunchAgents/com.salim.plist
```

### Linux (systemd)

```ini
# /etc/systemd/system/salim.service
[Unit]
Description=Salim Laptop Control Bot
After=network.target

[Service]
Type=simple
User=youruser
ExecStart=/usr/local/bin/salim start
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now salim
```

### Windows (Task Scheduler)

```powershell
$action  = New-ScheduledTaskAction -Execute "salim" -Argument "start"
$trigger = New-ScheduledTaskTrigger -AtLogOn
Register-ScheduledTask -TaskName "Salim" -Action $action -Trigger $trigger -RunLevel Highest
```

---

## 📦 Optional Packages

```bash
pip install pyautogui Pillow pyperclip aiofiles reportlab python-docx openpyxl python-pptx
```

| Package | What it unlocks |
|---|---|
| `pyautogui` | Screenshots, mouse/keyboard control |
| `Pillow` | Screenshot compression |
| `pyperclip` | Clipboard read/write |
| `python-docx` | Word document creation and editing |
| `openpyxl` | Excel file creation and editing |
| `python-pptx` | PowerPoint creation |
| `reportlab` | PDF generation |

---

## ❓ Common Questions

**Do I need technical knowledge?**
Not at all. Run `pip install salim` then `salim setup` — the wizard explains everything.

**Is it safe?**
Yes. Only your approved Telegram accounts can send commands. All others are ignored.

**Does it work on Windows?**
Yes — macOS, Linux, and Windows are all supported.

**Do I need to pay for AI?**
No. All three AI providers (NVIDIA NIM, Groq, Z.AI) have free tiers. Z.AI has no stated limits.

**What document types can it create?**
Word (.docx), Excel (.xlsx), CSV (.csv), PDF (.pdf), and PowerPoint (.pptx). All real files with professional formatting.

**Can it send emails?**
Yes — read, send, reply, and search real emails via IMAP/SMTP. Works with Gmail, Outlook, Yahoo, and more.

---

## 📄 License

MIT — free to use, modify, and share. See [LICENSE](LICENSE).

---

<p align="center">
  Made with ❤️ — Control your world from your pocket.
</p>
