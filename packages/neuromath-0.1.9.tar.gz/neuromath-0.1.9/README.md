# NeuroMath

NeuroMath is a lightweight symbolic mathematical DSL (Domain Specific Language) built on top of SymPy.  
It provides a clean notebook-style computation experience with both CLI and Streamlit GUI support.

---

## ✨ Features

- Symbolic computation
- Variable assignment
- Function definitions
- Differentiation
- Expression evaluation
- Built-in constants (`pi`, `e`)
- CLI interface
- Notebook-style Streamlit GUI
- Lightweight and easy to extend

---

## 📦 Installation

Install from PyPI:

```bash
pip install neuromath

# MathScript Language Reference 📚

A comprehensive guide to built-in functions and operations in MathScript.

## Table of Contents
- [Built-in Functions](#built-in-functions)
- [Math Functions](#math-functions)
- [Symbolic Functions](#symbolic-functions)

---

## Built-in Functions

### Basic Operations

| Function | Description |
|----------|-------------|
| `print(value)` | Print output to console |
| `typeof(value)` | Get type of value |
| `shape(matrix)` | Get matrix dimensions |
| `det(matrix)` | Calculate matrix determinant |
| `trans(matrix)` | Transpose matrix |
| `inv(matrix)` | Calculate matrix inverse |

###  Matrix Operations

| Function | Description |
|----------|-------------|
| `identity(n)` | Create n×n identity matrix |
| `zeroes(rows, cols)` | Create matrix filled with zeros |
| `dot(v1, v2)` | Dot product of vectors |
| `cross(v1, v2)` | Cross product of vectors |
| `norm(v)` | Vector norm/magnitude |
| `unit(v)` | Convert to unit vector |

###  Linear Algebra Functions

| Function | Description |
|----------|-------------|
| `eigenval(matrix)` | Calculate eigenvalues |
| `eigenvec(matrix)` | Calculate eigenvectors |
| `solve_linear(A, b)` | Solve linear system Ax = b |

### Visualization

| Function | Description |
|----------|-------------|
| `plot(f(x), x, start, end)` | Create 2D function plot |
| `plot_surface(f(x,y), x, y, x_start, x_end, y_start, y_end)` | Create 3D surface plot |

---

## Math Functions

### 📐 Trigonometric Functions

| Function | Description |
|----------|-------------|
| `sin(x)` | Sine of angle x |
| `cos(x)` | Cosine of angle x |
| `tan(x)` | Tangent of angle x |
| `arcsin(x)` | Inverse sine (arcsine) |
| `arccos(x)` | Inverse cosine (arccosine) |
| `arctan(x)` | Inverse tangent (arctangent) |

### Exponential & Logarithmic Functions

| Function | Description |
|----------|-------------|
| `exp(x)` | Exponential (e^x) |
| `log(x)` or `ln(x)` | Natural logarithm |
| `sqrt(x)` | Square root |
| `abs(x)` | Absolute value |
| `pow(x, y)` | Power (x^y) |

---

## Symbolic Functions

### Calculus & Algebra

| Function | Description |
|----------|-------------|
| `integrate(f(x), x)` | Perform symbolic integration |
| `diff(f(x), x)` | Perform symbolic differentiation |
| `limit(f(x), x, point)` | Calculate limit at a point |
| `solve(equation, variable)` | Solve algebraic equations |
| `summation(expr, (var, start, end))` | Compute series summation |
| `simplify(expr)` | Simplify mathematical expressions |
| `factor(expr)` | Factor algebraic expressions |

---

## Quick Examples

```mathscript
// Matrix operations
A = identity(3)
B = zeroes(2, 3)
det_A = det(A)

// Calculus
f(x) = x^2 + 3x + 2
derivative = diff(f(x), x)
integral = integrate(f(x), x)

// Visualization
plot(sin(x), x, 0, 2π)
```

---
