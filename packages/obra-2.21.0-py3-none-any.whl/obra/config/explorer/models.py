"""Data models for Configuration Explorer.

Provides the core data structures for representing configuration as a tree
with typed values, change tracking, and metadata for descriptions.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class ConfigSource(Enum):
    """Where a configuration value originates."""

    LOCAL = "local"  # ~/.obra/config-layers/01-user.yaml
    SERVER = "server"  # SaaS config (Firestore)
    DEFAULT = "default"  # Built-in default


class ValueType(Enum):
    """Type of a configuration value."""

    BOOLEAN = "boolean"
    STRING = "string"
    INTEGER = "integer"
    ENUM = "enum"  # String with predefined choices
    OBJECT = "object"  # Nested dict (expandable node)


class SettingTier(Enum):
    """Visibility tier for settings - controls initial UI state."""

    BASIC = "basic"  # Show by default, most users need
    STANDARD = "standard"  # Show by default, common use
    ADVANCED = "advanced"  # Collapsed by default, expert users


@dataclass
class ConfigNode:
    """Single node in the configuration tree.

    Represents either a leaf value (boolean, string, etc.) or a branch
    (object with children). Tracks modification state for staged changes.
    """

    key: str
    path: str  # Full dot-notation path (e.g., "llm.orchestrator.provider")
    value: Any
    value_type: ValueType
    source: ConfigSource
    tier: SettingTier = SettingTier.STANDARD
    description: str | None = None
    default_value: Any = None
    choices: list[str] | None = None  # For enum types
    depends_on: str | None = None  # Path of setting this depends on
    affects: list[str] = field(default_factory=list)  # Paths this setting affects
    stage: str | None = None  # Pipeline stage identifier for grouping
    tags: list[str] = field(default_factory=list)  # Tag metadata for grouping/filtering
    origin: str | None = None  # default/user/project/session/server
    children: list["ConfigNode"] = field(default_factory=list)
    is_modified: bool = False  # Changed from default/server
    is_expanded: bool = True  # UI state
    is_readonly: bool = False  # Read-only fields cannot be edited
    is_using_default: bool = False  # True = "Let Obra choose" (value is resolved default)

    @property
    def is_leaf(self) -> bool:
        """Return True if this node has no children (is a value node)."""
        return self.value_type != ValueType.OBJECT

    @property
    def display_value(self) -> str:
        """Return formatted value for display in tree.

        Booleans show as filled/empty circles for quick visual scanning.
        """
        if self.value_type == ValueType.BOOLEAN:
            return "●" if self.value else "○"
        if self.value is None:
            return "null"
        return str(self.value)

    def get_child(self, key: str) -> Optional["ConfigNode"]:
        """Find a direct child by key name or path segment.

        Args:
            key: The key to search for (also matches path's last segment)

        Returns:
            The child ConfigNode or None if not found
        """
        for child in self.children:
            # Match by key or by path's last segment (handles renamed keys like [Orchestrator])
            path_key = child.path.split(".")[-1] if child.path else ""
            if key in (child.key, path_key):
                return child
        return None


@dataclass
class ConfigTree:
    """Root container for both local and server configurations.

    Manages two separate configuration trees (local and server) and tracks
    pending changes until they are explicitly saved or discarded.
    """

    local_root: ConfigNode
    server_root: ConfigNode
    pending_changes: dict[str, tuple[Any, Any]] = field(default_factory=dict)
    # Maps path -> (old_value, new_value)

    def get_node(self, path: str) -> ConfigNode | None:
        """Traverse tree to find node by dot-notation path.

        Args:
            path: Dot-notation path like "llm.orchestrator.provider"

        Returns:
            The ConfigNode at that path, or None if not found
        """
        from obra.config.explorer.debug import is_debug_enabled, log_get_node

        # Try local tree first
        node = self._find_in_tree(self.local_root, path)
        if node is not None:
            if is_debug_enabled():
                log_get_node(path, True, f"source={node.source.value}, value={node.value!r}")
            return node

        # Fall back to server tree
        node = self._find_in_tree(self.server_root, path)
        if is_debug_enabled():
            if node:
                log_get_node(path, True, f"source={node.source.value}, value={node.value!r}")
            else:
                log_get_node(path, False)
        return node

    def _find_in_tree(self, root: ConfigNode, path: str) -> ConfigNode | None:
        """Find a node in a specific tree by path.

        Args:
            root: Root node to search from
            path: Dot-notation path

        Returns:
            The ConfigNode or None
        """
        parts = path.split(".")
        current = root

        for part in parts:
            found = current.get_child(part)
            if found is None:
                return None
            current = found

        return current

    def set_value(self, path: str, value: Any) -> bool:
        """Stage a value change (doesn't persist until commit).

        Args:
            path: Dot-notation path to the setting
            value: New value to set

        Returns:
            True if the value was staged successfully
        """
        from obra.config.explorer.debug import is_debug_enabled, log_set_value

        node = self.get_node(path)
        if node is None:
            # Node doesn't exist - try to create it
            node = self._create_node_for_path(path, value)
            if node is None:
                if is_debug_enabled():
                    log_set_value(path, None, value, False)
                return False

        old_value = node.value

        # Track the change
        if path not in self.pending_changes:
            self.pending_changes[path] = (node.value, value)
        else:
            # Update the new value, keeping original old value
            original_old = self.pending_changes[path][0]
            self.pending_changes[path] = (original_old, value)

        # Update node state
        node.value = value
        node.is_modified = True
        # Clear is_using_default when explicitly setting a value (unless setting to "default")
        if value != "default":
            node.is_using_default = False

        if is_debug_enabled():
            log_set_value(path, old_value, value, True)

        # Apply cascade logic for fast-config pattern
        self._apply_model_cascade(path, value)

        return True

    def _create_node_for_path(self, path: str, value: Any) -> ConfigNode | None:
        """Create a new node for a path that doesn't exist.

        Used for dynamically created paths like llm.roles.* that may not
        exist in the default config.

        Args:
            path: Dot-notation path for the new node
            value: Value to assign to the new node

        Returns:
            The newly created ConfigNode, or None if parent can't be found/created
        """
        from obra.config.explorer.utils import detect_value_type

        parts = path.split(".")
        if len(parts) < 2:
            return None

        # Find or create parent node
        parent_path = ".".join(parts[:-1])
        key = parts[-1]

        parent = self.get_node(parent_path)
        if parent is None:
            # Try to create parent recursively (for paths like llm.roles.derive)
            parent = self._create_node_for_path(parent_path, {})
            if parent is None:
                return None

        # Create the new leaf node with value=None initially
        # set_value will assign the actual value and track the change properly
        value_type = detect_value_type(value, path, {})
        new_node = ConfigNode(
            key=key,
            path=path,
            value=None,  # Will be set by set_value after creation
            value_type=value_type,
            source=ConfigSource.LOCAL,
            tier=SettingTier.STANDARD,
            origin="user",
            is_modified=True,
        )

        # Add to parent's children
        parent.children.append(new_node)

        # Ensure parent is marked as OBJECT type if it wasn't
        if parent.value_type != ValueType.OBJECT:
            parent.value_type = ValueType.OBJECT
            parent.value = None  # Objects don't have leaf values

        return new_node

    def _apply_model_cascade(self, path: str, value: Any) -> list[str]:
        """Apply cascade logic when provider or model settings change.

        Cascade rules:
        - llm.provider (not 'per-role') → cascades to role providers
        - llm.model (not 'per-tier') → cascades to role models and tiers
        - llm.{role}.model (not 'per-tier') → cascades to tier models

        Returns:
            List of paths that were cascaded (for UI refresh)
        """
        cascaded_paths: list[str] = []

        # Cascade from llm.provider to role-level providers
        if path == "llm.provider" and value != "per-role":
            for role in ("orchestrator", "implementation"):
                child_path = f"llm.{role}.provider"
                if self._cascade_to_child(child_path, value):
                    cascaded_paths.append(child_path)

        # Cascade from llm.model to role-level models
        elif path == "llm.model" and value != "per-tier":
            for role in ("orchestrator", "implementation"):
                child_path = f"llm.{role}.model"
                if self._cascade_to_child(child_path, value):
                    cascaded_paths.append(child_path)
                    # Also cascade to tiers
                    cascaded_paths.extend(self._cascade_to_tiers(f"llm.{role}", value))

        # Cascade from role-level model to tier models
        elif path in ("llm.orchestrator.model", "llm.implementation.model"):
            if value != "per-tier":
                role_prefix = path.rsplit(".model", 1)[0]  # e.g., "llm.orchestrator"
                cascaded_paths.extend(self._cascade_to_tiers(role_prefix, value))

        return cascaded_paths

    def _cascade_to_child(self, child_path: str, value: Any) -> bool:
        """Cascade a value to a child node if it exists."""
        child_node = self.get_node(child_path)
        if child_node is None:
            return False

        # Track the change
        if child_path not in self.pending_changes:
            self.pending_changes[child_path] = (child_node.value, value)
        else:
            old_value = self.pending_changes[child_path][0]
            self.pending_changes[child_path] = (old_value, value)

        child_node.value = value
        child_node.is_modified = True
        return True

    def _cascade_to_tiers(self, role_prefix: str, value: Any) -> list[str]:
        """Cascade a model value to all tier settings under a role."""
        cascaded: list[str] = []
        for tier in ("fast", "medium", "high"):
            tier_path = f"{role_prefix}.tiers.{tier}"
            if self._cascade_to_child(tier_path, value):
                cascaded.append(tier_path)
        return cascaded

    def get_cascade_paths(self, path: str) -> list[str]:
        """Get paths that would be affected by cascading from a given path.

        Used by UI to know which nodes need refreshing after a change.
        """
        paths: list[str] = []
        if path == "llm.provider":
            # Provider cascades to role providers
            for role in ("orchestrator", "implementation"):
                paths.append(f"llm.{role}.provider")
        elif path == "llm.model":
            # Model cascades to role models and tiers
            for role in ("orchestrator", "implementation"):
                paths.append(f"llm.{role}.model")
                for tier in ("fast", "medium", "high"):
                    paths.append(f"llm.{role}.tiers.{tier}")
        elif path in ("llm.orchestrator.model", "llm.implementation.model"):
            # Role model cascades to tiers
            role_prefix = path.rsplit(".model", 1)[0]
            for tier in ("fast", "medium", "high"):
                paths.append(f"{role_prefix}.tiers.{tier}")
        return paths

    def commit_changes(self) -> dict[str, Any]:
        """Return changes dict for API/file submission.

        Returns:
            Dictionary mapping paths to their new values
        """
        return {path: new_val for path, (_, new_val) in self.pending_changes.items()}

    def get_local_changes(self) -> dict[str, Any]:
        """Get only changes that apply to local config.

        Returns:
            Dictionary of local config changes
        """
        changes = {}
        for path, (_, new_val) in self.pending_changes.items():
            node = self.get_node(path)
            if node and node.source == ConfigSource.LOCAL:
                changes[path] = new_val
        return changes

    def get_server_changes(self) -> dict[str, Any]:
        """Get only changes that apply to server config.

        Returns:
            Dictionary of server config changes
        """
        changes = {}
        for path, (_, new_val) in self.pending_changes.items():
            node = self.get_node(path)
            if node and node.source == ConfigSource.SERVER:
                changes[path] = new_val
        return changes

    def discard_changes(self) -> None:
        """Revert all pending changes to their original values."""
        for path, (old_val, _) in self.pending_changes.items():
            node = self.get_node(path)
            if node:
                node.value = old_val
                node.is_modified = False

        self.pending_changes.clear()

    def clear_pending(self) -> None:
        """Clear pending changes without reverting values.

        Use after successful save to mark all changes as committed.
        """
        for path in self.pending_changes:
            node = self.get_node(path)
            if node:
                node.is_modified = False

        self.pending_changes.clear()

    @property
    def has_pending_changes(self) -> bool:
        """Check if there are any unsaved changes."""
        return len(self.pending_changes) > 0

    @property
    def pending_count(self) -> int:
        """Return the number of pending changes."""
        return len(self.pending_changes)
