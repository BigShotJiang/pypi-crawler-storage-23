
class Utubes:
    
    TASK_UID = []
    TASK_CID = []
    USER_UID = []
    USER_CID = []
    USER_TID = []
