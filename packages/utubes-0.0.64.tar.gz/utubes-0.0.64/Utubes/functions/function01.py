import os, asyncio
from ..scripts import Okeys
from ..scripts import Flite
from ..scripts import Scripted
from ..exception import Cancelled
from .collections import THREAD, SMessage
from yt_dlp import YoutubeDL, DownloadError
#=========================================================================================================================

class DownloadER:

    @staticmethod
    async def metadata(link, command):
        with YoutubeDL(command) as ydl:
            try:
                loop = asyncio.get_event_loop()
                moonus = await loop.run_in_executor(THREAD, lambda: ydl.extract_info(link, download=False))
                return SMessage(result=moonus)
            except Exception as errors:
                return SMessage(errors=errors)

#=========================================================================================================================

    @staticmethod
    async def extracts(link, command):
        with YoutubeDL(command) as ydl:
            try:
                loop = asyncio.get_event_loop()
                moonus = await loop.run_in_executor(THREAD, lambda: ydl.extract_info(link, download=False))
                return SMessage(result=moonus)
            except Exception as errors:
                return SMessage(errors=errors)

#=========================================================================================================================

    @staticmethod
    async def filename(link, command, names=Okeys.DATA01):
        with YoutubeDL(command) as ydl:
            try:
                loop = asyncio.get_event_loop()
                meawes = await loop.run_in_executor(THREAD, lambda: ydl.extract_info(link, download=False))
                moonus = await loop.run_in_executor(THREAD, lambda: ydl.prepare_filename(meawes, outtmpl=names))
                return SMessage(result=moonus, extracts=meawes)
            except DownloadError as errors:
                raise Exception(errors)

#=========================================================================================================================

    @staticmethod
    async def download(link, command, progress=None):
        with YoutubeDL(command) as ydl:
            try:
                filelink = [link]
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(THREAD, lambda: ydl.add_progress_hook(progress)) if progress else progress
                await loop.run_in_executor(THREAD, lambda: ydl.download(filelink))
            except DownloadError as errors:
                raise Exception(errors)
            except Cancelled as errors:
                raise Cancelled(errors)
            except Exception as errors:
                raise Exception(errors)

#=========================================================================================================================
