import aiohttp
from urllib.parse import unquote
from urllib.parse import urlparse
from .collections import SMessage
#=========================================================================================================================

class YTFilename:

    @staticmethod
    async def get00(url, **kwords):
        async with aiohttp.ClientSession() as session:
            async with session.get(url, allow_redirects=True, **kwords) as response:
                return dict(response.headers)

#=========================================================================================================================

    @staticmethod
    async def get02(url):
        filename01 = urlparse(url).path.split("/")
        filename02 = filename01[-1]
        filename03 = unquote(filename02)
        filename04 = filename03.replace("/", "-")
        return filename04

#=========================================================================================================================

    @staticmethod
    async def get03(moonues):
        filename01 = moonues.index("filename=") + len("filename=")
        filename02 = moonues[filename01:]
        filename03 = unquote(filename02.strip('"'))
        filename04 = filename03.replace("/", "-")
        return filename04

#=========================================================================================================================

    @staticmethod
    async def get04(onames, cnames):
        filenames = os.path.splitext(cnames)[0] if cnames else os.path.splitext(onames)[0]
        extensios = os.path.splitext(cnames)[1] if cnames else os.path.splitext(onames)[1]
        extension = extensios if extensios else os.path.splitext(onames)[1]
        return str(filenames) + str(extension)

#=========================================================================================================================

    @staticmethod
    async def get01(url):
        try:
            heades = await YTFilename.get00(url)
            moones = heades.get("Content-Disposition", "")
            moonus = await YTFilename.get03(moones) if moones and "filename=" in moones else await YTFilename.get02(url)
            return SMessage(result=moonus, filename=moonus)
        except Exception as errors:
            return SMessage(errors=errors)

#=========================================================================================================================
