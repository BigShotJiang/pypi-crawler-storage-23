
class Ulinks(object):

    DATA02 = ("https://youtu.be",
              "https://youtube.com",
              "https://www.youtu.be",
              "https://www.youtube.com",
              "https://music.youtube.com")

    DATA04 = ("http://mdisk.me", "https://mdisk.me")
    DATA03 = ("https://zee5.com", "https://www.zee5.com")
    DATA06 = ("https://instagram.com", "https://www.instagram.com")
    DATA05 = ("https://jiocinema.com", "https://www.jiocinema.com")
    DATA01 = ("https://mediafire.com", "https://www.mediafire.com")
    DATA07 = ("http://open.spotify.com", "https://open.spotify.com")
