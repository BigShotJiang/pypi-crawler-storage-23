
#=====================================================================

class Scripted(object):

    DATA01 = ""
    DATA11 = " "
    DATA05 = "NA"
    DATA06 = "tmp"
    DATA12 = ".tmp"
    DATA07 = "{}.{}"
    DATA10 = "{}.{}"
    DATA08 = "Unknown"
    DATA09 = "Unknown.tmp"
    ERRORS = "<b>ERROR :</b> {}"
    CANCEL = "<code>Cancelled ⛔<code/>"

#=====================================================================
