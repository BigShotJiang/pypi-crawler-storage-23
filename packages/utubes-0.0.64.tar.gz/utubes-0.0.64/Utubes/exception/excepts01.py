import time
class MLoggers:

    def __init__(self, msg):
        self.mog = ""
        self.msg = msg

    def info(self, msg):
        self.parse(msg)

    def debug(self, msg):
        self.parse(msg)

    def error(self, msg):
        pass

    def warning(self, msg):
        pass

    def edit(self, text):
        if text != self.mog:
            self.mog = text
            try: self.msg.edit(text)
            except Exception: pass
            time.sleep(5)

    def parse(self, text):

        # ===== MERGING =====
        if "[Merger]" in text or "Merging formats" in text:
            self.edit("🔄 Merging audio & video...")

        # ===== CONVERSION =====
        elif "FFmpegVideoConvertor" in text or "Converting video" in text:
            self.edit("🎞 Converting video format...")

        elif "FFmpegAudioConvertor" in text:
            self.edit("🎵 Converting audio format...")

        # ===== AUDIO EXTRACTION =====
        elif "ExtractAudio" in text:
            self.edit("🎧 Extracting audio...")

        # ===== THUMBNAIL =====
        elif "EmbedThumbnail" in text:
            self.edit("🖼 Embedding thumbnail...")

        elif "Writing thumbnail" in text:
            self.edit("🖼 Downloading thumbnail...")

        # ===== METADATA =====
        elif "Metadata" in text:
            self.edit("📝 Writing metadata...")

        elif "Adding metadata" in text:
            self.edit("📝 Adding metadata tags...")

        # ===== SUBTITLES =====
        elif "FFmpegSubtitlesConvertor" in text:
            self.edit("💬 Converting subtitles...")

        elif "Embedding subtitles" in text:
            self.edit("💬 Embedding subtitles...")

        elif "Downloading subtitles" in text:
            self.edit("💬 Downloading subtitles...")

        # ===== CHAPTERS =====
        elif "SplitChapters" in text:
            self.edit("📑 Splitting chapters...")

        elif "Embedding chapters" in text:
            self.edit("📑 Embedding chapters...")

        # ===== FIXUPS =====
        elif "Fixup" in text:
            self.edit("🛠 Fixing media container...")

        # ===== SPONSORBLOCK =====
        elif "SponsorBlock" in text:
            self.edit("✂️ Removing sponsor segments...")

        # ===== FILE MOVE =====
        elif "Moving file" in text:
            self.edit("📦 Finalizing file...")

        # ===== DOWNLOAD ALREADY EXISTS =====
        elif "has already been downloaded" in text:
            self.edit("✅ File already downloaded")

        # ===== DEFAULT FALLBACK =====
        elif "[ffmpeg]" in text.lower():
            self.edit("⚙️ Processing with FFmpeg...")
