"""Trik project templates."""
