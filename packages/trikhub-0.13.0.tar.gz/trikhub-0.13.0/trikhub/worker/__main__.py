"""Entry point for `python -m trikhub.worker`."""

from trikhub.worker.main import run_worker

run_worker()
