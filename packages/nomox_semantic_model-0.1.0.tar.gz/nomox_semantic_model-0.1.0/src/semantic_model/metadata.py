"""Model metadata definitions."""

from datetime import datetime

from pydantic import Field

from semantic_model.base import SemanticBaseModel


class ModelMetadata(SemanticBaseModel):
    """Metadata about the semantic model itself."""

    id: str = Field(..., description="Unique model ID")
    version: str = Field(..., description="Semantic version (e.g., '2.3.1')")
    organization_id: str = Field(..., description="Organization this model belongs to")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    schema_version: str = Field(
        default="1.0.0",
        description="Version of the semantic model schema format",
    )

    def bump_version(self, bump_type: str = "patch") -> "ModelMetadata":
        """Bump the version number.
        
        Args:
            bump_type: One of 'major', 'minor', or 'patch'
            
        Returns:
            New ModelMetadata with bumped version
        """
        major, minor, patch = map(int, self.version.split("."))
        
        if bump_type == "major":
            major += 1
            minor = 0
            patch = 0
        elif bump_type == "minor":
            minor += 1
            patch = 0
        else:  # patch
            patch += 1
        
        return self.model_copy(
            update={
                "version": f"{major}.{minor}.{patch}",
                "updated_at": datetime.utcnow(),
            }
        )
