"""
Semantic Model Package

A comprehensive data model for describing semantics of data sources,
designed to be consumed by LLMs for query generation.

The model is organized into three layers:
- Level 1 (Source-Scoped): DataSource, Table, Column, InternalRelationship
- Level 2 (Cross-Source): SemanticEntity, EntityRelationship, UnifiedAttribute
- Shared: Glossary, Confidence, ExpertOverrides
"""

from semantic_model.model import SemanticModel, create_empty_model
from semantic_model.metadata import ModelMetadata
from semantic_model.indexing import IndexingState, ReindexJob, ReindexTrigger

# Level 1 - Source-scoped models
from semantic_model.sources import (
    DataSource,
    SourceType,
    SourceStatus,
    SourceDependency,
    ConnectionInfo,
    ProfilingMetadata,
)
from semantic_model.tables import (
    Table,
    TableType,
    SemanticRole,
    TemporalInfo,
    TemporalGrain,
    PrimaryKey,
    TableProfiling,
    QueryPattern,
)
from semantic_model.columns import (
    Column,
    SemanticType,
    SemanticCategory,
    AllowedValue,
    ColumnReference,
    ColumnProfiling,
    SampleValue,
)
from semantic_model.relationships import (
    InternalRelationship,
    RelationshipType,
    DetectionMethod,
    JoinHint,
)

# Level 2 - Cross-source models
from semantic_model.entities import (
    SemanticEntity,
    EntityManifestation,
    ManifestationRole,
    KeyMapping,
    KeyMappingType,
    AttributeContribution,
    AttributeQuality,
    UnifiedAttribute,
    AttributeSource,
    ResolutionStrategy,
    IdentityResolution,
    IdentityResolutionStrategy,
    EntityLifecycle,
    LifecycleState,
)
from semantic_model.entity_relationships import (
    EntityRelationship,
    Cardinality,
    JoinPath,
    JoinStep,
)

# Shared models
from semantic_model.confidence import (
    ConfidenceScore,
    LowConfidenceItem,
    ConfidenceObjectType,
)
from semantic_model.glossary import (
    GlossaryTerm,
    GlossaryScope,
    GlossaryCreator,
)
from semantic_model.overrides import (
    ExpertOverride,
    OverrideStatus,
    ReindexScope,
    ExpertFeedback,
    FeedbackItem,
    FeedbackType,
    FeedbackPriority,
)

# Serialization utilities
from semantic_model.serialization import (
    load_model,
    save_model,
    load_model_from_dict,
    model_to_dict,
)

__version__ = "0.1.0"

__all__ = [
    # Root
    "SemanticModel",
    "create_empty_model",
    "ModelMetadata",
    "IndexingState",
    "ReindexJob",
    "ReindexTrigger",
    # Level 1
    "DataSource",
    "SourceType",
    "SourceStatus",
    "SourceDependency",
    "ConnectionInfo",
    "ProfilingMetadata",
    "Table",
    "TableType",
    "SemanticRole",
    "TemporalInfo",
    "TemporalGrain",
    "PrimaryKey",
    "TableProfiling",
    "QueryPattern",
    "Column",
    "SemanticType",
    "SemanticCategory",
    "AllowedValue",
    "ColumnReference",
    "ColumnProfiling",
    "SampleValue",
    "InternalRelationship",
    "RelationshipType",
    "DetectionMethod",
    "JoinHint",
    # Level 2
    "SemanticEntity",
    "EntityManifestation",
    "ManifestationRole",
    "KeyMapping",
    "KeyMappingType",
    "AttributeContribution",
    "AttributeQuality",
    "UnifiedAttribute",
    "AttributeSource",
    "ResolutionStrategy",
    "IdentityResolution",
    "IdentityResolutionStrategy",
    "EntityLifecycle",
    "LifecycleState",
    "EntityRelationship",
    "Cardinality",
    "JoinPath",
    "JoinStep",
    # Shared
    "ConfidenceScore",
    "LowConfidenceItem",
    "ConfidenceObjectType",
    "GlossaryTerm",
    "GlossaryScope",
    "GlossaryCreator",
    "ExpertOverride",
    "OverrideStatus",
    "ReindexScope",
    "ExpertFeedback",
    "FeedbackItem",
    "FeedbackType",
    "FeedbackPriority",
    # Utilities
    "load_model",
    "save_model",
    "load_model_from_dict",
    "model_to_dict",
]
