"""Base types and common utilities used across the semantic model."""

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class SemanticBaseModel(BaseModel):
    """Base model with common configuration for all semantic models."""

    model_config = ConfigDict(
        # Allow population by field name or alias
        populate_by_name=True,
        # Validate on assignment
        validate_assignment=True,
        # Use enum values for serialization
        use_enum_values=False,
        # Extra fields are forbidden
        extra="forbid",
        # Enable JSON schema generation
        json_schema_extra={"examples": []},
    )


class TimestampedModel(SemanticBaseModel):
    """Base model with created/updated timestamps."""

    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class IdentifiableModel(SemanticBaseModel):
    """Base model with a unique identifier."""

    id: str = Field(..., description="Unique identifier")


class NamedModel(IdentifiableModel):
    """Base model with id, name, and description."""

    name: str = Field(..., description="Human-readable name")
    description: str = Field(default="", description="Detailed description")


# Type aliases for clarity
FullyQualifiedName = str  # e.g., "catalog.schema.table"
ColumnId = str
TableId = str
SourceId = str
EntityId = str
SqlExpression = str
JsonPath = str
