from any_llm import __version__

__all__ = ["__version__"]
