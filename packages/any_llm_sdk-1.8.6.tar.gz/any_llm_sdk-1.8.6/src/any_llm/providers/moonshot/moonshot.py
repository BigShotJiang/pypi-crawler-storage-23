from any_llm.providers.openai.base import BaseOpenAIProvider


class MoonshotProvider(BaseOpenAIProvider):
    API_BASE = "https://api.moonshot.ai/v1"
    ENV_API_KEY_NAME = "MOONSHOT_API_KEY"
    ENV_API_BASE_NAME = "MOONSHOT_API_BASE"
    PROVIDER_NAME = "moonshot"
    PROVIDER_DOCUMENTATION_URL = "https://platform.moonshot.ai/"

    SUPPORTS_EMBEDDING = False  # Moonshot doesn't host an embedding model
    SUPPORTS_COMPLETION_IMAGE = False
    SUPPORTS_COMPLETION_PDF = False
    SUPPORTS_COMPLETION_REASONING = True
