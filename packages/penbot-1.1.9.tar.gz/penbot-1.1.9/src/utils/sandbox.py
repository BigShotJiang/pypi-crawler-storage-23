"""Sandboxed code execution for programmatic attack enhancement.

Runs Python code in an isolated subprocess with:
- Module whitelist (only safe string/encoding modules)
- Static analysis blocking dangerous patterns
- Hard timeout enforcement
- Output size capping
"""

import ast
import asyncio
import sys
import time
from typing import ClassVar, Optional, Tuple

from pydantic import BaseModel

from .logging import get_logger

logger = get_logger(__name__)


class SandboxResult(BaseModel):
    """Result of sandboxed code execution."""

    success: bool
    output: str
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    truncated: bool = False


class CodeSandbox:
    """Execute Python code in an isolated subprocess with strict restrictions."""

    ALLOWED_MODULES: ClassVar[set] = {
        "base64",
        "codecs",
        "hashlib",
        "string",
        "random",
        "re",
        "json",
        "math",
        "urllib.parse",
        "html",
        "unicodedata",
        "itertools",
        "collections",
        "textwrap",
        "binascii",
    }

    BLOCKED_PATTERNS: ClassVar[list] = [
        "__import__",
        "globals(",
        "locals(",
        "getattr(",
        "setattr(",
        "delattr(",
        "compile(",
        "breakpoint(",
        "__builtins__",
        "__subclasses__",
    ]

    def __init__(
        self,
        timeout_seconds: int = 10,
        max_output_bytes: int = 50_000,
    ):
        self.timeout_seconds = timeout_seconds
        self.max_output_bytes = max_output_bytes

    def validate_code(self, code: str) -> Tuple[bool, Optional[str]]:
        """Static analysis: AST-walk to check imports and blocked calls.

        Returns:
            (is_valid, error_message) tuple.
        """
        for pattern in self.BLOCKED_PATTERNS:
            if pattern in code:
                return False, f"Blocked pattern found: {pattern}"

        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return False, f"Syntax error: {e}"

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    full_name = alias.name
                    root_module = full_name.split(".")[0]
                    if (
                        full_name not in self.ALLOWED_MODULES
                        and root_module not in self.ALLOWED_MODULES
                    ):
                        return False, f"Import not allowed: {full_name}"

            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    full_name = node.module
                    root_module = full_name.split(".")[0]
                    if (
                        full_name not in self.ALLOWED_MODULES
                        and root_module not in self.ALLOWED_MODULES
                    ):
                        return False, f"Import not allowed: {full_name}"

            elif isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name) and func.id in (
                    "open",
                    "exec",
                    "eval",
                    "input",
                    "exit",
                    "quit",
                ):
                    return False, f"Blocked builtin call: {func.id}()"

        return True, None

    async def execute(self, code: str) -> SandboxResult:
        """Run code in a subprocess with timeout and output capture.

        The code's stdout is captured as the result. The subprocess
        inherits a minimal environment stripped of credentials.
        """
        is_valid, error = self.validate_code(code)
        if not is_valid:
            return SandboxResult(success=False, output="", error=error)

        # Wrap user code so stdout is captured and errors are reported
        wrapper = (
            "import sys\n" "sys.path = [p for p in sys.path if 'site-packages' not in p]\n" "try:\n"
        )
        for line in code.splitlines():
            wrapper += f"    {line}\n"
        wrapper += "except Exception as _e:\n" "    sys.stderr.write(str(_e))\n" "    sys.exit(1)\n"

        start = time.monotonic()

        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable,
                "-c",
                wrapper,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env={},  # stripped environment — no credentials
            )

            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=self.timeout_seconds,
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                elapsed = (time.monotonic() - start) * 1000
                return SandboxResult(
                    success=False,
                    output="",
                    error=f"Execution timed out after {self.timeout_seconds}s",
                    execution_time_ms=elapsed,
                )

            elapsed = (time.monotonic() - start) * 1000
            stdout = stdout_bytes.decode("utf-8", errors="replace")
            stderr = stderr_bytes.decode("utf-8", errors="replace")

            truncated = False
            if len(stdout) > self.max_output_bytes:
                stdout = stdout[: self.max_output_bytes]
                truncated = True

            if proc.returncode != 0:
                return SandboxResult(
                    success=False,
                    output=stdout,
                    error=stderr or f"Process exited with code {proc.returncode}",
                    execution_time_ms=elapsed,
                    truncated=truncated,
                )

            return SandboxResult(
                success=True,
                output=stdout.strip(),
                error=None,
                execution_time_ms=elapsed,
                truncated=truncated,
            )

        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            return SandboxResult(
                success=False,
                output="",
                error=f"Sandbox error: {e}",
                execution_time_ms=elapsed,
            )
