"""Output writers for aptoro."""

from aptoro.output.json_writer import to_dicts, to_json

__all__ = [
    "to_dicts",
    "to_json",
]
