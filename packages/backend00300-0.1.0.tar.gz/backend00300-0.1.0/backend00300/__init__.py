from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from os import getcwd
from pathlib import Path
from shutil import which
import sys

chrome_option = webdriver.ChromeOptions()
chrome_option.add_argument("--use-fake-ui-for-media-stream")
chrome_option.add_argument("--no-sandbox")
chrome_option.add_argument("--disable-dev-shm-usage")
# Live mic generally fails in headless mode.
# chrome_option.add_argument("--headless=new")

chrome_bin = which("google-chrome")
if chrome_bin:
    chrome_option.binary_location = chrome_bin


def get_cached_chromedriver():
    base = Path.home() / ".wdm" / "drivers" / "chromedriver" / "linux64"
    if not base.exists():
        return None
    candidates = sorted(base.glob("*/chromedriver-linux64/chromedriver"), reverse=True)
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    return None


def start_with_ports(driver_path):
    last_error = None
    for port in (9515, 9516, 9517, 9518):
        try:
            return webdriver.Chrome(
                service=Service(driver_path, port=port), options=chrome_option
            )
        except Exception as e:
            last_error = e
    if last_error is not None:
        raise last_error
    raise RuntimeError("ChromeDriver failed to start on all configured ports.")


def create_driver():
    errors = []

    local_driver = which("chromedriver")
    if local_driver:
        try:
            return start_with_ports(local_driver)
        except Exception as e:
            errors.append(f"local chromedriver failed: {e}")

    cached_driver = get_cached_chromedriver()
    if cached_driver:
        try:
            return start_with_ports(cached_driver)
        except Exception as e:
            errors.append(f"cached chromedriver failed: {e}")

    try:
        downloaded_driver = ChromeDriverManager().install()
        return start_with_ports(downloaded_driver)
    except Exception as e:
        errors.append(f"downloaded chromedriver failed: {e}")

    print("ChromeDriver start failed.")
    print("Likely reason: ChromeDriver could not bind localhost port.")
    print("Fix steps:")
    print("1) Run this script in your normal terminal/session (not restricted sandbox).")
    print("2) Close old Chrome/ChromeDriver processes and run again.")
    print("3) Ensure localhost socket binding is allowed on your system.")
    print("4) If needed, install matching chromedriver manually.")
    print("Details:")
    for err in errors:
        print(f"- {err}")
    sys.exit(1)


driver = create_driver()

# If hosted URL is provided, use it directly. Otherwise fallback to local index.html.
WEBSITE_URL = "https://spech-to-tex.netlify.app/"
if WEBSITE_URL.startswith(("http://", "https://")):
    website = WEBSITE_URL
else:
    website = Path(getcwd(), "index.html").resolve().as_uri()

driver.get(website)

rec_file = Path(getcwd()) / "input.text"
rec_file.touch(exist_ok=True)

def listen():
    try:
        start_button = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.ID, "startButton"))
        )
        start_button.click()
        print("Listening...")
        output_text = ""
        while True:
            output_element = WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.ID, "output"))
            )
            current_text = output_element.text.strip()

            if current_text and current_text != output_text:
                output_text = current_text
                with open(rec_file, "w") as file:
                    file.write(output_text.lower())
                print("USER : " + output_text)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(e)

listen()
