from setuptools import setup, find_packages

setup(
    name="backend00300",
    version="0.1.0",
    author="Manas Singh Rajput",
    author_email="singmanassingh123456789@gmail.com, veerendrapratapsingh804@gmail.com",
    description="This is speech to text package created by Manas Singh Rajput",
    packages=find_packages(),
    install_requires=[
        "selenium",
        "webdriver_manager",
    ],
)


