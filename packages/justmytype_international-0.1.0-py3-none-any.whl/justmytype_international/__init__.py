"""JustMyType international meta-pack.

This package has no font pack entry point. Installing it pulls in:
- justmytype-western-core
- justmytype-intl-rtl
- justmytype-intl-south-asia
- justmytype-intl-sea
- justmytype-intl-africa

Those packs register themselves with JustMyType. For East Asian (CJK) fonts,
install justmytype-intl-cjk separately.
"""
