"""RYE MCP Server - MCP transport layer for RYE OS."""

__version__ = "0.1.4"
