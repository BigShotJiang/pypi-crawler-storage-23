from __future__ import annotations

from dataclasses import dataclass

from .input import Input


@dataclass
class EditorState:
    text: str
    cursor: int


class Editor:
    def __init__(self, initial_text: str = "") -> None:
        self._input = Input(initial_text)

    @property
    def state(self) -> EditorState:
        return EditorState(text=self._input.state.value, cursor=self._input.state.cursor)

    def insert(self, text: str) -> None:
        self._input.insert(text)

    def backspace(self) -> None:
        self._input.backspace()


__all__ = ["Editor", "EditorState"]
