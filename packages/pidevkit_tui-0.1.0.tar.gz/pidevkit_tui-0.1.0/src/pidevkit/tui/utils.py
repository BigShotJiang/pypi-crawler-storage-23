from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

_CSI_FINAL_BYTES = set("mGKHJ")
_PUNCTUATION_RE = re.compile(r"""[(){}\[\]<>.,;:'"!?+\-=*/\\|&%^$#@~`]""")


@dataclass(frozen=True)
class ExtractedAnsiCode:
    code: str
    length: int


def _char_width(char: str) -> int:
    if not char:
        return 0
    if unicodedata.combining(char):
        return 0
    category = unicodedata.category(char)
    if category.startswith("C"):
        return 0
    if category.startswith("M"):
        return 0
    return 2 if unicodedata.east_asian_width(char) in {"F", "W"} else 1


def visible_width(text: str) -> int:
    if not text:
        return 0

    is_pure_ascii = True
    for char in text:
        code = ord(char)
        if code < 0x20 or code > 0x7E:
            is_pure_ascii = False
            break
    if is_pure_ascii:
        return len(text)

    clean = text.replace("\t", "   ")
    width = 0
    i = 0
    while i < len(clean):
        ansi_result = extract_ansi_code(clean, i)
        if ansi_result is not None:
            i += ansi_result.length
            continue

        width += _char_width(clean[i])
        i += 1

    return width


def extract_ansi_code(text: str, pos: int) -> ExtractedAnsiCode | None:
    if pos >= len(text) or text[pos] != "\x1b":
        return None

    next_char = text[pos + 1] if pos + 1 < len(text) else ""

    if next_char == "[":
        j = pos + 2
        while j < len(text) and text[j] not in _CSI_FINAL_BYTES:
            j += 1
        if j < len(text):
            return ExtractedAnsiCode(code=text[pos : j + 1], length=j + 1 - pos)
        return None

    if next_char == "]" or next_char == "_":
        j = pos + 2
        while j < len(text):
            if text[j] == "\x07":
                return ExtractedAnsiCode(code=text[pos : j + 1], length=j + 1 - pos)
            if text[j] == "\x1b" and j + 1 < len(text) and text[j + 1] == "\\":
                return ExtractedAnsiCode(code=text[pos : j + 2], length=j + 2 - pos)
            j += 1
        return None

    return None


class AnsiCodeTracker:
    def __init__(self) -> None:
        self.bold = False
        self.dim = False
        self.italic = False
        self.underline = False
        self.blink = False
        self.inverse = False
        self.hidden = False
        self.strikethrough = False
        self.fg_color: str | None = None
        self.bg_color: str | None = None

    def process(self, ansi_code: str) -> None:
        if not ansi_code.endswith("m"):
            return

        match = re.fullmatch(r"\x1b\[([\d;]*)m", ansi_code)
        if match is None:
            return

        params = match.group(1)
        if params in {"", "0"}:
            self._reset()
            return

        parts = params.split(";")
        i = 0
        while i < len(parts):
            raw = parts[i]
            code = int(raw) if raw.isdigit() else None

            if code in {38, 48}:
                if i + 2 < len(parts) and parts[i + 1] == "5":
                    color_code = f"{parts[i]};{parts[i + 1]};{parts[i + 2]}"
                    if code == 38:
                        self.fg_color = color_code
                    else:
                        self.bg_color = color_code
                    i += 3
                    continue
                if i + 4 < len(parts) and parts[i + 1] == "2":
                    color_code = f"{parts[i]};{parts[i + 1]};{parts[i + 2]};{parts[i + 3]};{parts[i + 4]}"
                    if code == 38:
                        self.fg_color = color_code
                    else:
                        self.bg_color = color_code
                    i += 5
                    continue

            if code is None:
                i += 1
                continue

            if code == 0:
                self._reset()
            elif code == 1:
                self.bold = True
            elif code == 2:
                self.dim = True
            elif code == 3:
                self.italic = True
            elif code == 4:
                self.underline = True
            elif code == 5:
                self.blink = True
            elif code == 7:
                self.inverse = True
            elif code == 8:
                self.hidden = True
            elif code == 9:
                self.strikethrough = True
            elif code == 21:
                self.bold = False
            elif code == 22:
                self.bold = False
                self.dim = False
            elif code == 23:
                self.italic = False
            elif code == 24:
                self.underline = False
            elif code == 25:
                self.blink = False
            elif code == 27:
                self.inverse = False
            elif code == 28:
                self.hidden = False
            elif code == 29:
                self.strikethrough = False
            elif code == 39:
                self.fg_color = None
            elif code == 49:
                self.bg_color = None
            elif 30 <= code <= 37 or 90 <= code <= 97:
                self.fg_color = str(code)
            elif 40 <= code <= 47 or 100 <= code <= 107:
                self.bg_color = str(code)

            i += 1

    def _reset(self) -> None:
        self.bold = False
        self.dim = False
        self.italic = False
        self.underline = False
        self.blink = False
        self.inverse = False
        self.hidden = False
        self.strikethrough = False
        self.fg_color = None
        self.bg_color = None

    def clear(self) -> None:
        self._reset()

    def get_active_codes(self) -> str:
        codes: list[str] = []
        if self.bold:
            codes.append("1")
        if self.dim:
            codes.append("2")
        if self.italic:
            codes.append("3")
        if self.underline:
            codes.append("4")
        if self.blink:
            codes.append("5")
        if self.inverse:
            codes.append("7")
        if self.hidden:
            codes.append("8")
        if self.strikethrough:
            codes.append("9")
        if self.fg_color:
            codes.append(self.fg_color)
        if self.bg_color:
            codes.append(self.bg_color)
        if not codes:
            return ""
        return f"\x1b[{';'.join(codes)}m"

    def has_active_codes(self) -> bool:
        return any(
            (
                self.bold,
                self.dim,
                self.italic,
                self.underline,
                self.blink,
                self.inverse,
                self.hidden,
                self.strikethrough,
                self.fg_color is not None,
                self.bg_color is not None,
            )
        )

    def get_line_end_reset(self) -> str:
        if self.underline:
            return "\x1b[24m"
        return ""


def _update_tracker_from_text(text: str, tracker: AnsiCodeTracker) -> None:
    i = 0
    while i < len(text):
        ansi_result = extract_ansi_code(text, i)
        if ansi_result is not None:
            tracker.process(ansi_result.code)
            i += ansi_result.length
        else:
            i += 1


def _split_into_tokens_with_ansi(text: str) -> list[str]:
    tokens: list[str] = []
    current = ""
    pending_ansi = ""
    in_whitespace = False
    i = 0

    while i < len(text):
        ansi_result = extract_ansi_code(text, i)
        if ansi_result is not None:
            pending_ansi += ansi_result.code
            i += ansi_result.length
            continue

        char = text[i]
        char_is_space = char == " "

        if char_is_space != in_whitespace and current:
            tokens.append(current)
            current = ""

        if pending_ansi:
            current += pending_ansi
            pending_ansi = ""

        in_whitespace = char_is_space
        current += char
        i += 1

    if pending_ansi:
        current += pending_ansi

    if current:
        tokens.append(current)

    return tokens


def wrap_text_with_ansi(text: str, width: int) -> list[str]:
    if not text:
        return [""]
    if width <= 0:
        return [""]

    input_lines = text.split("\n")
    result: list[str] = []
    tracker = AnsiCodeTracker()

    for input_line in input_lines:
        prefix = tracker.get_active_codes() if result else ""
        result.extend(_wrap_single_line(prefix + input_line, width))
        _update_tracker_from_text(input_line, tracker)

    return result if result else [""]


def _wrap_single_line(line: str, width: int) -> list[str]:
    if not line:
        return [""]

    if visible_width(line) <= width:
        return [line]

    wrapped: list[str] = []
    tracker = AnsiCodeTracker()
    tokens = _split_into_tokens_with_ansi(line)

    current_line = ""
    current_visible_length = 0

    for token in tokens:
        token_visible_length = visible_width(token)
        is_whitespace = token.strip() == ""

        if token_visible_length > width and not is_whitespace:
            if current_line:
                line_end_reset = tracker.get_line_end_reset()
                if line_end_reset:
                    current_line += line_end_reset
                wrapped.append(current_line)
                current_line = ""
                current_visible_length = 0

            broken = _break_long_word(token, width, tracker)
            wrapped.extend(broken[:-1])
            current_line = broken[-1]
            current_visible_length = visible_width(current_line)
            continue

        total_needed = current_visible_length + token_visible_length
        if total_needed > width and current_visible_length > 0:
            line_to_wrap = current_line.rstrip()
            line_end_reset = tracker.get_line_end_reset()
            if line_end_reset:
                line_to_wrap += line_end_reset
            wrapped.append(line_to_wrap)

            if is_whitespace:
                current_line = tracker.get_active_codes()
                current_visible_length = 0
            else:
                current_line = tracker.get_active_codes() + token
                current_visible_length = token_visible_length
        else:
            current_line += token
            current_visible_length += token_visible_length

        _update_tracker_from_text(token, tracker)

    if current_line:
        wrapped.append(current_line)

    return [wrapped_line.rstrip() for wrapped_line in wrapped] if wrapped else [""]


def _break_long_word(word: str, width: int, tracker: AnsiCodeTracker) -> list[str]:
    lines: list[str] = []
    current_line = tracker.get_active_codes()
    current_width = 0
    segments: list[tuple[str, str]] = []
    i = 0

    while i < len(word):
        ansi_result = extract_ansi_code(word, i)
        if ansi_result is not None:
            segments.append(("ansi", ansi_result.code))
            i += ansi_result.length
            continue

        end = i
        while end < len(word):
            next_ansi = extract_ansi_code(word, end)
            if next_ansi is not None:
                break
            end += 1

        for char in word[i:end]:
            segments.append(("grapheme", char))
        i = end

    for segment_type, value in segments:
        if segment_type == "ansi":
            current_line += value
            tracker.process(value)
            continue

        grapheme = value
        if not grapheme:
            continue

        grapheme_width = visible_width(grapheme)
        if current_width + grapheme_width > width:
            line_end_reset = tracker.get_line_end_reset()
            if line_end_reset:
                current_line += line_end_reset
            lines.append(current_line)
            current_line = tracker.get_active_codes()
            current_width = 0

        current_line += grapheme
        current_width += grapheme_width

    if current_line:
        lines.append(current_line)

    return lines if lines else [""]


def truncate_to_width(text: str, max_width: int, ellipsis: str = "...", pad: bool = False) -> str:
    """
    Truncate text to fit within a visible width budget.

    ANSI escape sequences do not count toward visible width.
    """

    text_visible_width = visible_width(text)
    if text_visible_width <= max_width:
        if not pad:
            return text
        return text + (" " * max(0, max_width - text_visible_width))

    ellipsis_width = visible_width(ellipsis)
    target_width = max_width - ellipsis_width

    if target_width <= 0:
        return ellipsis[:max_width]

    segments: list[tuple[str, str]] = []
    i = 0
    while i < len(text):
        ansi_result = extract_ansi_code(text, i)
        if ansi_result is not None:
            segments.append(("ansi", ansi_result.code))
            i += ansi_result.length
            continue

        end = i
        while end < len(text):
            next_ansi = extract_ansi_code(text, end)
            if next_ansi is not None:
                break
            end += 1

        for char in text[i:end]:
            segments.append(("grapheme", char))
        i = end

    result = ""
    current_width = 0
    for segment_type, value in segments:
        if segment_type == "ansi":
            result += value
            continue

        if not value:
            continue

        grapheme_width = visible_width(value)
        if current_width + grapheme_width > target_width:
            break

        result += value
        current_width += grapheme_width

    truncated = f"{result}\x1b[0m{ellipsis}"
    if not pad:
        return truncated

    truncated_width = visible_width(truncated)
    return truncated + (" " * max(0, max_width - truncated_width))


def is_whitespace_char(char: str) -> bool:
    return bool(re.fullmatch(r"\s", char))


def is_punctuation_char(char: str) -> bool:
    return bool(_PUNCTUATION_RE.fullmatch(char))


def extractAnsiCode(text: str, pos: int) -> ExtractedAnsiCode | None:
    return extract_ansi_code(text, pos)


def visibleWidth(text: str) -> int:
    return visible_width(text)


def wrapTextWithAnsi(text: str, width: int) -> list[str]:
    return wrap_text_with_ansi(text, width)


def truncateToWidth(text: str, max_width: int, ellipsis: str = "...", pad: bool = False) -> str:
    return truncate_to_width(text, max_width, ellipsis, pad)


__all__ = [
    "ExtractedAnsiCode",
    "extract_ansi_code",
    "extractAnsiCode",
    "is_punctuation_char",
    "is_whitespace_char",
    "truncate_to_width",
    "truncateToWidth",
    "visible_width",
    "visibleWidth",
    "wrap_text_with_ansi",
    "wrapTextWithAnsi",
]
