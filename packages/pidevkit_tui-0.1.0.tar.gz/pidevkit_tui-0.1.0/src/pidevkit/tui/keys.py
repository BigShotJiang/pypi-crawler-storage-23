from __future__ import annotations


_KEYMAP = {
    "up": "\x1b[A",
    "down": "\x1b[B",
    "right": "\x1b[C",
    "left": "\x1b[D",
    "enter": "\r",
    "escape": "\x1b",
    "backspace": "\x7f",
}


def matches_key(data: str, key: str) -> bool:
    expected = _KEYMAP.get(key)
    return expected == data


def matchesKey(data: str, key: str) -> bool:
    return matches_key(data, key)


def is_key_release(data: str) -> bool:
    # Kitty protocol key release events typically use CSI ... u with release modifier
    return data.startswith("\x1b[") and data.endswith("u") and ":3" in data


def isKeyRelease(data: str) -> bool:
    return is_key_release(data)


__all__ = ["is_key_release", "isKeyRelease", "matches_key", "matchesKey"]
