from __future__ import annotations

import re
from collections.abc import Callable
from threading import RLock, Timer
from typing import Literal

ESC = "\x1b"
BRACKETED_PASTE_START = "\x1b[200~"
BRACKETED_PASTE_END = "\x1b[201~"

SequenceStatus = Literal["complete", "incomplete", "not-escape"]
EventName = Literal["data", "paste"]
Listener = Callable[[str], None]

_MOUSE_SGR_RE = re.compile(r"^<\d+;\d+;\d+[Mm]$")


def is_complete_sequence(data: str) -> SequenceStatus:
    if not data.startswith(ESC):
        return "not-escape"

    if len(data) == 1:
        return "incomplete"

    after_esc = data[1:]

    if after_esc.startswith("["):
        if after_esc.startswith("[M"):
            return "complete" if len(data) >= 6 else "incomplete"
        return is_complete_csi_sequence(data)

    if after_esc.startswith("]"):
        return is_complete_osc_sequence(data)

    if after_esc.startswith("P"):
        return is_complete_dcs_sequence(data)

    if after_esc.startswith("_"):
        return is_complete_apc_sequence(data)

    if after_esc.startswith("O"):
        return "complete" if len(after_esc) >= 2 else "incomplete"

    if len(after_esc) == 1:
        return "complete"

    return "complete"


def is_complete_csi_sequence(data: str) -> Literal["complete", "incomplete"]:
    if not data.startswith(f"{ESC}["):
        return "complete"

    if len(data) < 3:
        return "incomplete"

    payload = data[2:]
    last_char = payload[-1]
    last_char_code = ord(last_char)

    if 0x40 <= last_char_code <= 0x7E:
        if payload.startswith("<"):
            if _MOUSE_SGR_RE.fullmatch(payload):
                return "complete"

            if last_char in {"M", "m"}:
                parts = payload[1:-1].split(";")
                if len(parts) == 3 and all(part.isdigit() for part in parts):
                    return "complete"

            return "incomplete"

        return "complete"

    return "incomplete"


def is_complete_osc_sequence(data: str) -> Literal["complete", "incomplete"]:
    if not data.startswith(f"{ESC}]"):
        return "complete"

    if data.endswith(f"{ESC}\\") or data.endswith("\x07"):
        return "complete"

    return "incomplete"


def is_complete_dcs_sequence(data: str) -> Literal["complete", "incomplete"]:
    if not data.startswith(f"{ESC}P"):
        return "complete"

    if data.endswith(f"{ESC}\\"):
        return "complete"

    return "incomplete"


def is_complete_apc_sequence(data: str) -> Literal["complete", "incomplete"]:
    if not data.startswith(f"{ESC}_"):
        return "complete"

    if data.endswith(f"{ESC}\\"):
        return "complete"

    return "incomplete"


def extract_complete_sequences(buffer: str) -> tuple[list[str], str]:
    sequences: list[str] = []
    pos = 0

    while pos < len(buffer):
        remaining = buffer[pos:]

        if remaining.startswith(ESC):
            seq_end = 1
            while seq_end <= len(remaining):
                candidate = remaining[:seq_end]
                status = is_complete_sequence(candidate)

                if status == "complete":
                    sequences.append(candidate)
                    pos += seq_end
                    break
                if status == "incomplete":
                    seq_end += 1
                    continue

                sequences.append(candidate)
                pos += seq_end
                break

            if seq_end > len(remaining):
                return sequences, remaining
        else:
            sequences.append(remaining[0])
            pos += 1

    return sequences, ""


class StdinBuffer:
    def __init__(self, timeout: int = 10) -> None:
        self._buffer = ""
        self._timeout_timer: Timer | None = None
        self._timeout_ms = timeout
        self._paste_mode = False
        self._paste_buffer = ""
        self._listeners: dict[EventName, list[Listener]] = {"data": [], "paste": []}
        self._lock = RLock()

    def on(self, event: EventName, listener: Listener) -> StdinBuffer:
        with self._lock:
            self._listeners[event].append(listener)
        return self

    def off(self, event: EventName, listener: Listener) -> StdinBuffer:
        with self._lock:
            listeners = self._listeners[event]
            if listener in listeners:
                listeners.remove(listener)
        return self

    def emit(self, event: EventName, payload: str) -> bool:
        with self._lock:
            listeners = list(self._listeners[event])
        for listener in listeners:
            listener(payload)
        return bool(listeners)

    def process(self, data: str | bytes | bytearray) -> None:
        emitted: list[tuple[EventName, str]] = []
        recursive_input: str | None = None

        with self._lock:
            self._clear_timeout_locked()

            if isinstance(data, (bytes, bytearray)):
                data_bytes = bytes(data)
                if len(data_bytes) == 1 and data_bytes[0] > 127:
                    data_str = f"{ESC}{chr(data_bytes[0] - 128)}"
                else:
                    data_str = data_bytes.decode(errors="replace")
            else:
                data_str = data

            if len(data_str) == 0 and len(self._buffer) == 0:
                emitted.append(("data", ""))
            else:
                self._buffer += data_str

                if self._paste_mode:
                    self._paste_buffer += self._buffer
                    self._buffer = ""

                    end_index = self._paste_buffer.find(BRACKETED_PASTE_END)
                    if end_index != -1:
                        pasted_content = self._paste_buffer[:end_index]
                        remaining = self._paste_buffer[end_index + len(BRACKETED_PASTE_END) :]

                        self._paste_mode = False
                        self._paste_buffer = ""

                        emitted.append(("paste", pasted_content))
                        if remaining:
                            recursive_input = remaining
                else:
                    start_index = self._buffer.find(BRACKETED_PASTE_START)
                    if start_index != -1:
                        if start_index > 0:
                            sequences, _ = extract_complete_sequences(self._buffer[:start_index])
                            emitted.extend(("data", sequence) for sequence in sequences)

                        self._buffer = self._buffer[start_index + len(BRACKETED_PASTE_START) :]
                        self._paste_mode = True
                        self._paste_buffer = self._buffer
                        self._buffer = ""

                        end_index = self._paste_buffer.find(BRACKETED_PASTE_END)
                        if end_index != -1:
                            pasted_content = self._paste_buffer[:end_index]
                            remaining = self._paste_buffer[end_index + len(BRACKETED_PASTE_END) :]

                            self._paste_mode = False
                            self._paste_buffer = ""

                            emitted.append(("paste", pasted_content))
                            if remaining:
                                recursive_input = remaining
                    else:
                        sequences, remainder = extract_complete_sequences(self._buffer)
                        self._buffer = remainder
                        emitted.extend(("data", sequence) for sequence in sequences)

                        if self._buffer:
                            self._start_timeout_locked()

        for event, payload in emitted:
            self.emit(event, payload)

        if recursive_input:
            self.process(recursive_input)

    def flush(self) -> list[str]:
        with self._lock:
            self._clear_timeout_locked()

            if len(self._buffer) == 0:
                return []

            sequences = [self._buffer]
            self._buffer = ""
            return sequences

    def clear(self) -> None:
        with self._lock:
            self._clear_timeout_locked()
            self._buffer = ""
            self._paste_mode = False
            self._paste_buffer = ""

    def get_buffer(self) -> str:
        with self._lock:
            return self._buffer

    def destroy(self) -> None:
        self.clear()

    def addListener(self, event: EventName, listener: Listener) -> StdinBuffer:
        return self.on(event, listener)

    def removeListener(self, event: EventName, listener: Listener) -> StdinBuffer:
        return self.off(event, listener)

    def getBuffer(self) -> str:
        return self.get_buffer()

    def _start_timeout_locked(self) -> None:
        self._timeout_timer = Timer(self._timeout_ms / 1000.0, self._on_timeout)
        self._timeout_timer.daemon = True
        self._timeout_timer.start()

    def _clear_timeout_locked(self) -> None:
        if self._timeout_timer is not None:
            self._timeout_timer.cancel()
            self._timeout_timer = None

    def _on_timeout(self) -> None:
        flushed = self.flush()
        for sequence in flushed:
            self.emit("data", sequence)


def isCompleteSequence(data: str) -> SequenceStatus:
    return is_complete_sequence(data)


def extractCompleteSequences(buffer: str) -> tuple[list[str], str]:
    return extract_complete_sequences(buffer)


__all__ = [
    "BRACKETED_PASTE_END",
    "BRACKETED_PASTE_START",
    "ESC",
    "StdinBuffer",
    "extractCompleteSequences",
    "extract_complete_sequences",
    "isCompleteSequence",
    "is_complete_sequence",
]
