from __future__ import annotations

KITTY_PREFIX = "\x1b_G"
ITERM2_PREFIX = "\x1b]1337;File="


def is_image_line(line: str) -> bool:
    if not line:
        return False

    # Fast path for common case (escape sequence at start).
    if line.startswith(KITTY_PREFIX) or line.startswith(ITERM2_PREFIX):
        return True

    # Regression-safe path: sequence can appear anywhere in long mixed-content lines.
    return KITTY_PREFIX in line or ITERM2_PREFIX in line


def isImageLine(line: str) -> bool:
    return is_image_line(line)


__all__ = [
    "ITERM2_PREFIX",
    "KITTY_PREFIX",
    "is_image_line",
    "isImageLine",
]
