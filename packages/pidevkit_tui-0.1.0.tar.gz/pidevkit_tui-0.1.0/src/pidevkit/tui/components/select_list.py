from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable, Protocol

from ..utils import truncate_to_width


def _normalize_to_single_line(text: str) -> str:
    return re.sub(r"[\r\n]+", " ", text).strip()


@dataclass(frozen=True)
class SelectItem:
    value: str
    label: str
    description: str | None = None


class SelectListTheme(Protocol):
    def selectedPrefix(self, text: str) -> str: ...
    def selectedText(self, text: str) -> str: ...
    def description(self, text: str) -> str: ...
    def scrollInfo(self, text: str) -> str: ...
    def noMatch(self, text: str) -> str: ...


class SelectList:
    def __init__(self, items: list[SelectItem | dict[str, str]], max_visible: int, theme: object) -> None:
        normalized: list[SelectItem] = []
        for item in items:
            if isinstance(item, SelectItem):
                normalized.append(item)
            else:
                normalized.append(
                    SelectItem(
                        value=str(item.get("value", "")),
                        label=str(item.get("label", item.get("value", ""))),
                        description=item.get("description"),
                    )
                )

        self.items = normalized
        self.filtered_items = list(normalized)
        self.selected_index = 0
        self.max_visible = max_visible
        self.theme = theme

        self.on_select: Callable[[SelectItem], None] | None = None
        self.on_cancel: Callable[[], None] | None = None
        self.on_selection_change: Callable[[SelectItem], None] | None = None

    def set_filter(self, filter_text: str) -> None:
        f = filter_text.lower()
        self.filtered_items = [item for item in self.items if item.value.lower().startswith(f)]
        self.selected_index = 0

    def set_selected_index(self, index: int) -> None:
        if not self.filtered_items:
            self.selected_index = 0
            return
        self.selected_index = max(0, min(index, len(self.filtered_items) - 1))

    def invalidate(self) -> None:
        return None

    def render(self, width: int) -> list[str]:
        lines: list[str] = []
        if not self.filtered_items:
            no_match = getattr(self.theme, "noMatch", lambda s: s)
            return [no_match("  No matching commands")]

        start_index = max(
            0,
            min(
                self.selected_index - (self.max_visible // 2),
                len(self.filtered_items) - self.max_visible,
            ),
        )
        end_index = min(start_index + self.max_visible, len(self.filtered_items))

        desc_style = getattr(self.theme, "description", lambda s: s)
        selected_style = getattr(self.theme, "selectedText", lambda s: s)
        scroll_style = getattr(self.theme, "scrollInfo", lambda s: s)

        for i in range(start_index, end_index):
            item = self.filtered_items[i]
            is_selected = i == self.selected_index
            display_value = item.label or item.value
            description = _normalize_to_single_line(item.description) if item.description else None

            if is_selected:
                prefix = "-> "
                max_width = max(1, width - len(prefix))
                base_text = truncate_to_width(display_value, max_width, "")
                if description and width > 40:
                    space_budget = max(1, width - len(prefix) - len(base_text) - 1)
                    desc_text = truncate_to_width(description, space_budget, "")
                    line = selected_style(f"{prefix}{base_text} {desc_text}")
                else:
                    line = selected_style(f"{prefix}{base_text}")
            else:
                prefix = "  "
                max_width = max(1, width - len(prefix))
                base_text = truncate_to_width(display_value, max_width, "")
                if description and width > 40:
                    space_budget = max(1, width - len(prefix) - len(base_text) - 1)
                    desc_text = desc_style(" " + truncate_to_width(description, space_budget, ""))
                    line = f"{prefix}{base_text}{desc_text}"
                else:
                    line = f"{prefix}{base_text}"

            lines.append(line)

        if start_index > 0 or end_index < len(self.filtered_items):
            scroll = f"  ({self.selected_index + 1}/{len(self.filtered_items)})"
            lines.append(scroll_style(truncate_to_width(scroll, max(1, width - 2), "")))

        return lines

    def handle_input(self, key_data: str) -> None:
        if not self.filtered_items:
            return

        if key_data in {"\x1b[A", "k"}:  # up
            self.selected_index = self.selected_index - 1 if self.selected_index > 0 else len(self.filtered_items) - 1
            self._notify_selection_change()
        elif key_data in {"\x1b[B", "j"}:  # down
            self.selected_index = self.selected_index + 1 if self.selected_index < len(self.filtered_items) - 1 else 0
            self._notify_selection_change()
        elif key_data in {"\r", "\n"} and self.on_select:
            selected = self.filtered_items[self.selected_index]
            self.on_select(selected)
        elif key_data in {"\x1b", "\x03"} and self.on_cancel:
            self.on_cancel()

    def _notify_selection_change(self) -> None:
        if not self.on_selection_change:
            return
        selected = self.filtered_items[self.selected_index]
        self.on_selection_change(selected)

    def get_selected_item(self) -> SelectItem | None:
        if not self.filtered_items:
            return None
        return self.filtered_items[self.selected_index]


__all__ = [
    "SelectItem",
    "SelectList",
    "SelectListTheme",
]
