from __future__ import annotations

from dataclasses import dataclass

from ..utils import truncate_to_width, visible_width


@dataclass
class TruncatedText:
    text: str
    padding_x: int = 0
    padding_y: int = 0

    def invalidate(self) -> None:
        # Kept for API parity with the TS component interface.
        return None

    def render(self, width: int) -> list[str]:
        result: list[str] = []
        empty_line = " " * width

        for _ in range(self.padding_y):
            result.append(empty_line)

        available_width = max(1, width - (self.padding_x * 2))
        single_line_text = self.text.split("\n", 1)[0]
        display_text = truncate_to_width(single_line_text, available_width)

        line_with_padding = (" " * self.padding_x) + display_text + (" " * self.padding_x)
        padding_needed = max(0, width - visible_width(line_with_padding))
        result.append(line_with_padding + (" " * padding_needed))

        for _ in range(self.padding_y):
            result.append(empty_line)

        return result

