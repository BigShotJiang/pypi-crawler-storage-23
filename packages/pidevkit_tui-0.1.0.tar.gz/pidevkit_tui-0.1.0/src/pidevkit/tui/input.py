from __future__ import annotations

from dataclasses import dataclass


@dataclass
class InputState:
    value: str = ""
    cursor: int = 0


class Input:
    def __init__(self, value: str = "") -> None:
        self.state = InputState(value=value, cursor=len(value))

    def insert(self, text: str) -> None:
        left = self.state.value[: self.state.cursor]
        right = self.state.value[self.state.cursor :]
        self.state.value = left + text + right
        self.state.cursor += len(text)

    def backspace(self) -> None:
        if self.state.cursor <= 0:
            return
        left = self.state.value[: self.state.cursor - 1]
        right = self.state.value[self.state.cursor :]
        self.state.value = left + right
        self.state.cursor -= 1

    def move_left(self) -> None:
        self.state.cursor = max(0, self.state.cursor - 1)

    def move_right(self) -> None:
        self.state.cursor = min(len(self.state.value), self.state.cursor + 1)


__all__ = ["Input", "InputState"]
