from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

from .terminal_image import is_image_line
from .utils import extract_ansi_code, truncate_to_width, visible_width


class Component(Protocol):
    def render(self, width: int) -> list[str]: ...
    def invalidate(self) -> None: ...


@dataclass
class OverlayEntry:
    component: Component
    options: dict[str, Any] | None
    hidden: bool = False


def _parse_size_value(value: int | str | None, reference_size: int) -> int | None:
    if value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.endswith("%"):
        try:
            percent = float(value[:-1]) / 100.0
        except ValueError:
            return None
        return int(reference_size * percent)
    return None


def _slice_by_columns(text: str, start_col: int, max_cols: int) -> str:
    if max_cols <= 0:
        return ""
    i = 0
    visible = 0
    out = []

    while i < len(text):
        ansi = extract_ansi_code(text, i)
        if ansi is not None:
            out.append(ansi.code)
            i += ansi.length
            continue

        ch = text[i]
        if visible >= start_col and visible < start_col + max_cols:
            out.append(ch)
        visible += 1
        i += 1
        if visible >= start_col + max_cols:
            break

    return "".join(out)


def _truncate_plain_to_columns(text: str, max_cols: int) -> str:
    if visible_width(text) <= max_cols:
        return text
    return truncate_to_width(text, max_cols, ellipsis="", pad=False)


class Container:
    def __init__(self) -> None:
        self.children: list[Component] = []

    def add_child(self, component: Component) -> None:
        self.children.append(component)

    def addChild(self, component: Component) -> None:
        self.add_child(component)

    def render(self, width: int) -> list[str]:
        lines: list[str] = []
        for child in self.children:
            lines.extend(child.render(width))
        return lines

    def invalidate(self) -> None:
        for child in self.children:
            child.invalidate()


class TUI(Container):
    def __init__(self, terminal: Any) -> None:  # noqa: ANN401
        super().__init__()
        self.terminal = terminal
        self._overlay_stack: list[OverlayEntry] = []
        self._running = False
        self._last_viewport: list[str] = []

    def start(self) -> None:
        self._running = True
        self.request_render(True)

    def stop(self) -> None:
        self._running = False

    def request_render(self, force: bool = False) -> None:
        if not self._running and not force:
            return
        self._do_render()

    def requestRender(self, force: bool = False) -> None:
        self.request_render(force)

    def show_overlay(self, component: Component, options: dict[str, Any] | None = None) -> OverlayEntry:
        entry = OverlayEntry(component=component, options=options)
        self._overlay_stack.append(entry)
        return entry

    def showOverlay(self, component: Component, options: dict[str, Any] | None = None) -> OverlayEntry:
        return self.show_overlay(component, options)

    def _resolve_layout(
        self,
        options: dict[str, Any] | None,
        overlay_height: int,
        term_width: int,
        term_height: int,
    ) -> tuple[int, int, int]:
        opt = options or {}
        width = _parse_size_value(opt.get("width"), term_width) or min(80, term_width)
        min_width = opt.get("minWidth")
        if isinstance(min_width, int):
            width = max(width, min_width)
        width = max(1, min(width, term_width))

        if isinstance(opt.get("row"), int):
            row = opt["row"]
        else:
            anchor = opt.get("anchor", "center")
            if anchor in {"top-left", "top-center", "top-right"}:
                row = 0
            elif anchor in {"bottom-left", "bottom-center", "bottom-right"}:
                row = max(0, term_height - overlay_height)
            else:
                row = max(0, (term_height - overlay_height) // 2)

        if isinstance(opt.get("col"), int):
            col = opt["col"]
        else:
            anchor = opt.get("anchor", "center")
            if anchor in {"top-left", "left-center", "bottom-left"}:
                col = 0
            elif anchor in {"top-right", "right-center", "bottom-right"}:
                col = max(0, term_width - width)
            else:
                col = max(0, (term_width - width) // 2)

        row += int(opt.get("offsetY", 0) or 0)
        col += int(opt.get("offsetX", 0) or 0)
        row = max(0, min(row, max(0, term_height - overlay_height)))
        col = max(0, min(col, max(0, term_width - width)))
        return width, row, col

    def _composite_line(self, base_line: str, overlay_line: str, start_col: int, width: int, total_width: int) -> str:
        if is_image_line(base_line):
            return base_line

        overlay = _truncate_plain_to_columns(overlay_line, width)
        before = _slice_by_columns(base_line, 0, start_col)
        after_start = start_col + width
        after = _slice_by_columns(base_line, after_start, max(0, total_width - after_start))

        line = before + overlay + after
        if visible_width(line) > total_width:
            line = _truncate_plain_to_columns(line, total_width)
        return line

    def _composite_overlays(self, lines: list[str], term_width: int, term_height: int) -> list[str]:
        if not self._overlay_stack:
            return lines

        result = list(lines)
        while len(result) < term_height:
            result.append("")

        for entry in self._overlay_stack:
            if entry.hidden:
                continue
            options = entry.options or {}
            width_for_render = _parse_size_value(options.get("width"), term_width) or min(80, term_width)
            min_width = options.get("minWidth")
            if isinstance(min_width, int):
                width_for_render = max(width_for_render, min_width)
            width_for_render = max(1, min(width_for_render, term_width))

            overlay_lines = entry.component.render(width_for_render)
            max_height = _parse_size_value(options.get("maxHeight"), term_height)
            if max_height is not None:
                overlay_lines = overlay_lines[: max(1, max_height)]

            width, row, col = self._resolve_layout(options, len(overlay_lines), term_width, term_height)
            for i, overlay_line in enumerate(overlay_lines):
                idx = row + i
                if idx >= len(result):
                    break
                result[idx] = self._composite_line(result[idx], overlay_line, col, width, term_width)

        return result

    def _do_render(self) -> None:
        width = int(getattr(self.terminal, "columns", 80))
        height = int(getattr(self.terminal, "rows", 24))

        base = self.render(width)
        composited = self._composite_overlays(base, width, height)
        viewport = composited[-height:] if len(composited) > height else composited

        padded: list[str] = []
        for line in viewport:
            padded.append(_truncate_plain_to_columns(line, width).ljust(width))
        while len(padded) < height:
            padded.append(" " * width)

        self._last_viewport = padded
        if hasattr(self.terminal, "set_screen"):
            self.terminal.set_screen(padded)
        elif hasattr(self.terminal, "screen"):
            self.terminal.screen = list(padded)
        elif hasattr(self.terminal, "write"):
            self.terminal.write("\n".join(padded))

    def get_last_viewport(self) -> list[str]:
        return list(self._last_viewport)


__all__ = [
    "Component",
    "Container",
    "TUI",
]
