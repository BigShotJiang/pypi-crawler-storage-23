from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class AutocompleteItem:
    value: str
    label: str
    description: str | None = None


def autocomplete(prefix: str, items: list[AutocompleteItem], max_visible: int = 5) -> list[AutocompleteItem]:
    p = prefix.lower()
    filtered = [item for item in items if item.value.lower().startswith(p)]
    return filtered[:max_visible]


__all__ = ["AutocompleteItem", "autocomplete"]
