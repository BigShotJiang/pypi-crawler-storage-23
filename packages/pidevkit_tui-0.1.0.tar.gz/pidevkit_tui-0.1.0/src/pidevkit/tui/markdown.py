from __future__ import annotations

from .utils import wrap_text_with_ansi


def _normalize_markdown_line(line: str) -> str:
    stripped = line.strip()
    if stripped.startswith("#"):
        return stripped.lstrip("#").strip()
    if stripped.startswith("- "):
        return f"* {stripped[2:].strip()}"
    return line


def render_markdown(text: str, width: int) -> list[str]:
    normalized_lines = [_normalize_markdown_line(line) for line in text.splitlines()]
    rendered: list[str] = []
    for line in normalized_lines:
        rendered.extend(wrap_text_with_ansi(line, width))
    return rendered


__all__ = ["render_markdown"]
