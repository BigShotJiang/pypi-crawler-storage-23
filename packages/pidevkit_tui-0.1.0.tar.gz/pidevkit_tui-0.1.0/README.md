# pidevkit-tui

Lightweight terminal UI components/utilities for interactive workflows.

## Install

```bash
pip install pidevkit-tui
```

## Import

```python
from pidevkit.tui import Input, Container
```
