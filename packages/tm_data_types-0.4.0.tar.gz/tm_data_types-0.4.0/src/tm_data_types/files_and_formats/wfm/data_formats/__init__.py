"""The data formats for .wfm files."""
