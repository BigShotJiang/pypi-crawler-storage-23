"""A collection of classes encapsulating waveform files and their formats."""
