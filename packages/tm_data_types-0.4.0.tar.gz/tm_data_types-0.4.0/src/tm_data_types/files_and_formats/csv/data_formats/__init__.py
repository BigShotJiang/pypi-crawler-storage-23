"""The data formats for .csv files."""
