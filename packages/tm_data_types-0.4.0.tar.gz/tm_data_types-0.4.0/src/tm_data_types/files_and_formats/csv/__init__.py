"""A collection of classes encapsulating .csv files and their formats."""
