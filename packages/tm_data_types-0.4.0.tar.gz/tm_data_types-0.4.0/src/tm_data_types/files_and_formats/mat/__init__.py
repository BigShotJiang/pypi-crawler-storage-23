"""A collection of classes encapsulating .mat files and their formats."""
