"""A collection of classes encapsulating various file formats."""
