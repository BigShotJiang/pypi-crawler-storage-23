"""A collection of waveform data types."""
