"""A collection of data types."""
