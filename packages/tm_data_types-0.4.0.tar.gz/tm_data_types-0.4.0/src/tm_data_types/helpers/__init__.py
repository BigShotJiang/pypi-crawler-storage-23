"""Helper objects for the `tm_data_types` package."""
