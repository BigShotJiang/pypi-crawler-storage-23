import re,time
import requests
from jsonpath import jsonpath
from . import global_func,log
from .caseLog import CaseLogHandler
from .dbClient import DBClient
# 定义脚本中的全局变量
ENV = {}
db = DBClient()

class BaseCase(CaseLogHandler):
    """用例执行基本父类"""

    def __run_script(self, data):
        # 执行前后置脚本，可以在前后置脚本中共享数据
        test = self
        global_var = ENV.get("envs")
        print = self.print_log
        # 定义脚本中的临时变量
        self.env = {}
        # 1、读取前置脚本数据
        setup_scripts = data.get("setup_script")
        # 2、执行字符串中有效的python代码
        exec(setup_scripts)

        response = yield

        # 1、读取后置脚本数据
        teardown_scripts = data.get("teardown_script")
        # 2、执行字符串中有效的python代码
        exec(teardown_scripts)

        yield

    def __setup_script(self, data):
        """前置脚本处理"""
        self.script_hook = self.__run_script(data)
        next(self.script_hook)

    def __teardown_script(self, data, response):
        """后置脚本处理"""
        self.script_hook.send(response)
        """删除生成器对象"""
        delattr(self, "script_hook")


    def execute_function_if_exists(self, value):
        """
        支持带参数函数调用，增加异常兜底（避免返回None）
        """
        if not isinstance(value, str):
            # 非字符串类型直接返回
            return value

        # 匹配函数调用格式：如 gen_random_num(2)、random_mobile()
        func_pattern = r"^(\w+)\((.*)\)$"
        func_match = re.match(func_pattern, value.strip())
        if not func_match:
            return value

        # 提取函数名和参数
        func_name = func_match.group(1)
        func_args_str = func_match.group(2).strip()

        # 从 global_func 模块获取函数
        try:
            func = getattr(global_func, func_name)
            if not callable(func):
                log.warning_log(f"{func_name} 不是可调用函数，返回原格式")
                return value  # 兜底：不返回None
        except AttributeError:
            log.warning_log(f"全局函数 {func_name} 不存在，返回原格式")
            return value  # 兜底：不返回None

        # 解析参数
        func_args = []
        if func_args_str:
            try:
                func_args = eval(f"[{func_args_str}]")
            except Exception as e:
                log.error_log(f"解析函数 {func_name} 参数失败：{str(e)}，返回原格式")
                return value  # 兜底：不返回None

        # 执行函数
        log.info_log(f"执行函数 {func_name}，参数：{func_args}，参数类型：{[type(x) for x in func_args]}")
        try:
            func_result = func(*func_args)
            log.info_log(f"函数 {func_name} 执行结果：{func_result}，类型：{type(func_result)}")
            return func_result
        except Exception as e:
            log.error_log(f"执行 {func_name} 抛出异常：{str(e)}", exc_info=True)
            return value  # 兜底：不返回None

    def replace_data(self, data):
        """替换测试用例中的变量数据"""
        # 1、定义替换数据的规则
        pattern = r"\${(.+?)}"
        # 2、将测试数据转为字符串（统一处理）
        data_str = str(data)
        log.info_log("替换数据原始内容：", data_str)

        # 3、循环替换变量（直到无未解析的${}，或达到最大循环次数）
        max_loop = 100  # 避免死循环
        loop_count = 0
        has_unresolved = True  # 标记是否还有未解析的变量

        while has_unresolved and loop_count < max_loop:
            loop_count += 1
            # 记录替换前的内容，用于判断是否有变化
            original_str = data_str

            # 遍历所有匹配的变量，逐个替换
            for match_data in list(re.finditer(pattern, data_str)):  # list避免迭代时字符串变化
                full_match = match_data.group()  # 完整匹配：如 ${e_Cloud_vendors_name}
                key = match_data.group(1)  # 提取内容：如 e_Cloud_vendors_name

                log.info_log(f"第{loop_count}次匹配：{full_match} → 提取内容：{key}")

                # 步骤1：先从临时变量 self.env 取值
                value = self.env.get(key)
                # 步骤2：临时变量无值 → 从全局变量 ENV["envs"] 取值
                if value is None:
                    value = ENV.get("envs", {}).get(key)
                # 步骤3：仍无值 → 直接使用 key 作为值（如 key 是函数调用：gen_random_num(2)）
                if value is None:
                    log.info_log(f"变量 {key} 无临时/全局值，尝试作为函数调用处理")
                    value = key

                # 核心：执行函数（支持带参数），得到最终替换值
                value_after_exec = self.execute_function_if_exists(value)

                # 替换当前匹配的变量
                data_str = data_str.replace(full_match, str(value_after_exec))
                log.info_log(f"替换结果：{full_match} → {value_after_exec}")

            # 判断是否还有未解析的变量（替换后是否变化）
            has_unresolved = re.search(pattern, data_str) is not None
            if original_str == data_str:
                # 内容无变化，说明无法继续替换，退出循环
                has_unresolved = False

        if loop_count >= max_loop:
            log.warning_log(f"变量替换达到最大循环次数 {max_loop}，强制退出（可能存在循环引用）")

        # 4、还原数据类型（避免所有数据都是字符串）
        try:
            return eval(data_str)
        except (SyntaxError, NameError, TypeError):
            log.error_log(f"数据 {data_str} 无法还原类型，返回字符串格式")
            return data_str

    def __handle_request_data(self, data):
        """处理请求数据"""
        self.name = data.get("title")
        request_data = {}
        # 1、处理请求url
        if data.get("interface").get("url").startswith("http"):
            request_data["url"] = data.get("interface").get("url")
        else:
            request_data["url"] = ENV.get("base_url") + data.get("interface").get("url")
        request_data["method"] = data.get("interface").get("method")
        # 2、处理请求头
        request_data["headers"] = ENV.get("headers")
        request_data["headers"].update(data.get("headers"))
        # 3、处理请求参数
        request_data["params"] = data.get("request").get("params")
        if "application/json" in request_data["headers"].get("Content-Type"):
            request_data["json"] = data.get("request").get("json")
        elif "application/x-www-form-urlencoded" in request_data["headers"].get("Content-Type"):
            request_data["data"] = data.get("request").get("data")
        elif "multipart/form-data" in request_data["headers"].get("Content-Type"):
            request_data["files"] = data.get("request").get("files")
        # 4、替换请求中的变量名 为 具体的变量数据
        request_data = self.replace_data(request_data)
        self.url = request_data["url"]
        self.method = request_data["method"]
        self.request_headers = request_data["headers"]
        return request_data

    def __send_request(self, data):
        """发送请求"""
        request_data = self.__handle_request_data(data)
        self.info_log(request_data)
        response = requests.request(method=request_data.get("method"),
                                    url=request_data.get("url"),
                                    headers=request_data.get("headers"),
                                    params=request_data.get("params"),
                                    data=request_data.get("data"),
                                    json=request_data.get("json"),
                                    files=request_data.get("files"))
        #  获取用例执行的请求和响应信息
        self.request_body = response.request.body
        self.status_code = response.status_code
        self.response_headers = response.headers
        self.response_body = response.text
        self.info_log("请求地址:", self.url)
        self.info_log("请求方法:", self.method)
        self.info_log("请求头:", self.request_headers)
        self.info_log("响应头:", self.response_headers)
        self.info_log("请求体:", self.request_body)
        self.info_log("响应体:", self.response_body)
        return response

    def perform(self, data):
        """执行用例"""
        start_time = time.time()
        try:
            self.__setup_script(data)
            response = self.__send_request(data)
            self.__teardown_script(data, response)
        finally:
            end_time = time.time()
            elapsed_time = end_time - start_time
            self.elapsed_ms = "{} ms".format(int(elapsed_time * 1000))

    def save_env_variable(self, key, value):
        """保存测试运行环境变量"""
        self.info_log(f"保存（临时）环境变量：{key} = {value}")
        self.env[key] = value

    def del_evn_variable(self, key):
        """删除测试运行环境变量"""
        self.info_log(f"删除（临时）环境变量：{key}")
        del self.env[key]

    def save_global_variable(self, key, value):
       """保存测试运行环境的全局变量"""
       self.info_log(f"保存全局变量：{key} = {value}")
       ENV.get("envs")[key] = value

    def del_global_variable(self, key):
        """删除测试运行环境的全局变量"""
        self.info_log(f"删除全局变量：{key}")
        del ENV.get("envs")[key]

    def json_extract(self,obj,ext):
        """通过jsonpath提取一个json数据"""
        self.info_log("----通过jsonpath提取单个数据---")
        res = jsonpath(obj, ext)
        value = res[0] if res else ""
        return value

    def json_extract_list(self,obj,ext):
        """通过jsonpath提取一组json数据"""
        self.info_log("----通过jsonpath提取一组数据---")
        res = jsonpath(obj, ext)
        value = res if res else []
        return value

    def re_extract(self,obj,ext):
        """
        通过正则提取一个数据
        obj: 响应的json数据
        ext: 匹配的正则表达式
        """
        self.info_log("----通过正则提取数据---")
        # 1、判断响应是否为字符串
        if not isinstance(obj,str):
            obj = str(obj)
        # 2、提取匹配正则表达式的第一个数据
        res = re.search(ext,obj)
        value = res.group(1) if res else ""
        return value

    def re_extract_list(self,obj,ext):
        """
        通过正则提取一组数据
        obj: 响应的json数据
        ext: 匹配的正则表达式
        """
        self.info_log("----通过正则提取一组数据---")
        # 1、判断响应是否为字符串
        if not isinstance(obj,str):
            obj = str(obj)
        # 2、提取匹配正则表达式的所有数据
        res = re.findall(ext,obj)
        value = res if res else []
        return value

    def assertion(self,method,expect,actual):
        """
        :param method: 断言比较的方式
        :param expect: 断言的期望结果
        :param actual: 断言的实际结果
        :return:
        """
        # 1、断言的方法
        method_map = {
            "相等": lambda a,b: a == b,
            "相等忽略大小写": lambda a, b: a.lower() == b.lower(),
            "不相等":  lambda a,b: a != b,
            "包含": lambda a,b: a in b,
            "不包含": lambda a,b: a not in b,
            "大于": lambda a,b: a > b,
            "小于": lambda a,b: a < b,
            "大于等于": lambda a,b: a >= b,
            "小于等于": lambda a,b: a <= b,
            "正则匹配": lambda a,b: re.search(a,b)
        }
        # 2、断言操作
        assert_fun = method_map.get(method)
        if assert_fun is None:
            raise Exception("不支持的断言方法")
        else:
            self.debug_log(f"断言比较方法是：{method}")
            self.debug_log(f"预期结果是：{expect}")
            self.debug_log(f"实际结果是：{actual}")
        try:
            assert assert_fun(expect,actual)
        except AssertionError:
            self.error_log(f"断言失败，实际结果({actual}) 不满足({method}) 期望结果({expect})")
            raise AssertionError(f"断言失败，实际结果({actual}) 不满足({method}) 期望结果({expect})")
        else:
            self.info_log(f"断言成功，实际结果({actual}) 满足({method}) 期望结果({expect})")