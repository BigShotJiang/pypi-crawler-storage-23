from ApiEngine.caseLog import CaseLogHandler

log = CaseLogHandler()