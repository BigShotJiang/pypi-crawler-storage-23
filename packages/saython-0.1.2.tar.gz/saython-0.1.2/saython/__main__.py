"""
Allow saython to be executed as a module: python -m saython
"""
from saython.cli import main

if __name__ == "__main__":
    main()
