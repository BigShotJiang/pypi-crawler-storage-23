"""
SAYTHON Framework - Custom Exceptions
"""


class SaythonError(Exception):
    """Base exception for all Saython errors."""
    status_code = 500
    message = "Internal Server Error"

    def __init__(self, message=None, status_code=None):
        self.message = message or self.__class__.message
        self.status_code = status_code or self.__class__.status_code
        super().__init__(self.message)

    def to_dict(self):
        return {"error": self.message, "status": self.status_code}


class NotFound(SaythonError):
    status_code = 404
    message = "Not Found"


class BadRequest(SaythonError):
    status_code = 400
    message = "Bad Request"


class Unauthorized(SaythonError):
    status_code = 401
    message = "Unauthorized"


class Forbidden(SaythonError):
    status_code = 403
    message = "Forbidden"


class MethodNotAllowed(SaythonError):
    status_code = 405
    message = "Method Not Allowed"


class ValidationError(BadRequest):
    def __init__(self, errors: dict):
        self.errors = errors
        super().__init__(message="Validation failed", status_code=400)

    def to_dict(self):
        return {"error": self.message, "status": self.status_code, "details": self.errors}
