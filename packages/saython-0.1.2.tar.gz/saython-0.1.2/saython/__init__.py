"""
SAYTHON - A beginner-friendly Python web framework for CRUD apps.

Quickstart:
    from saython import Saython, Model, Field, auth_required

    app = Saython(__name__)

    class Book(Model):
        title  = Field(str, required=True)
        author = Field(str, required=True)
        year   = Field(int, default=2024)

    app.register(Book)

    @app.get("/hello")
    def hello(req):
        return {"message": "Hello!"}

    if __name__ == "__main__":
        app.run(debug=True)
"""

from saython.app       import Saython
from saython.orm       import Model, Field, configure_db
from saython.auth      import auth_required, admin_required, get_auth_router, User
from saython.router    import Router
from saython.request   import Request
from saython.response  import Response
from saython.exceptions import (
    SaythonError, NotFound, BadRequest, Unauthorized,
    Forbidden, MethodNotAllowed, ValidationError,
)

__version__ = "0.1.2"
__author__ = "Sabbir"
__all__ = [
    "Saython",
    "Model", "Field", "configure_db",
    "auth_required", "admin_required", "get_auth_router", "User",
    "Router",
    "Request", "Response",
    "SaythonError", "NotFound", "BadRequest",
    "Unauthorized", "Forbidden", "MethodNotAllowed", "ValidationError",
]
