from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="saython",
    version="0.1.2",
    description="A beginner-friendly Python web framework for CRUD apps with auth and ORM",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Sabbir",
    python_requires=">=3.9",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "saython=saython.cli:main",
        ],
    },
    install_requires=[],          # zero hard dependencies (pure stdlib)
    extras_require={
        "jwt":      ["PyJWT>=2.0"],
        "bcrypt":   ["bcrypt>=4.0"],
        "postgres": ["psycopg2-binary"],
        "mysql":    ["mysql-connector-python"],
        "all":      ["PyJWT>=2.0", "bcrypt>=4.0"],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Internet :: WWW/HTTP :: WSGI",
        "Topic :: Internet :: WWW/HTTP :: WSGI :: Application",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
    ],
)
