"""
Java Class Analyzer MCP Server (Python版)
"""
