import os
import sys
import subprocess
import json
import zipfile
from typing import List, Dict, Optional, Set
from pathlib import Path


def _is_debug() -> bool:
    return os.environ.get("LOG_LEVEL", "DEBUG").upper() == "DEBUG"


def _log(msg: str) -> None:
    """仅在 DEBUG 模式下输出到 stderr（不污染 MCP stdout）"""
    if _is_debug():
        print(msg, file=sys.stderr)


def _log_always(msg: str) -> None:
    """始终输出到 stderr（不污染 MCP stdout）"""
    print(msg, file=sys.stderr)


class ClassIndexEntry:
    """类索引条目"""

    def __init__(
        self, class_name: str, jar_path: str, package_name: str, simple_name: str
    ):
        self.class_name = class_name
        self.jar_path = jar_path
        self.package_name = package_name
        self.simple_name = simple_name


class ScanResult:
    """扫描结果"""

    def __init__(
        self,
        jar_count: int,
        class_count: int,
        index_path: str,
        sample_entries: List[str],
    ):
        self.jar_count = jar_count
        self.class_count = class_count
        self.index_path = index_path
        self.sample_entries = sample_entries


class DependencyScanner:
    """Maven依赖扫描器"""

    def __init__(self):
        self.index_cache: Dict[str, List[ClassIndexEntry]] = {}

    def get_package_prefixes(self) -> List[str]:
        """
        从环境变量 CLASS_PACKAGE_PREFIXES 读取允许的包名前缀列表。
        多个前缀用逗号分隔，如 "com.example,org.myorg"。
        返回空列表表示不过滤（扫描全部）。
        """
        raw = os.environ.get("CLASS_PACKAGE_PREFIXES", "").strip()
        if not raw:
            return []
        return [p.strip() for p in raw.split(",") if p.strip()]

    def scan_project(
        self, project_path: str, force_refresh: bool = False
    ) -> ScanResult:
        """
        扫描Maven项目的所有依赖，建立类名到JAR包的映射索引
        """
        index_path = os.path.join(project_path, ".mcp-class-index.json")

        # 如果强制刷新，先删除旧的索引文件
        if force_refresh and os.path.exists(index_path):
            _log("强制刷新：删除旧的索引文件")
            os.remove(index_path)

        # 检查缓存
        if not force_refresh and os.path.exists(index_path):
            _log("使用缓存的类索引")
            with open(index_path, "r", encoding="utf-8") as f:
                cached_index = json.load(f)
            return ScanResult(
                cached_index["jarCount"],
                cached_index["classCount"],
                index_path,
                cached_index["sampleEntries"],
            )

        _log("开始扫描Maven依赖...")

        # 读取包名前缀过滤配置
        package_prefixes = self.get_package_prefixes()
        if package_prefixes:
            _log_always(
                f"包名前缀过滤已启用，只索引以下前缀的类: {', '.join(package_prefixes)}"
            )
        else:
            _log(
                "包名前缀过滤未配置，将索引所有类（可通过 CLASS_PACKAGE_PREFIXES 环境变量限制）"
            )

        # 1. 获取Maven依赖树
        dependencies = self.get_maven_dependencies(project_path)
        _log(f"找到 {len(dependencies)} 个依赖JAR包")

        # 2. 解析每个JAR包，建立类索引
        class_index: List[ClassIndexEntry] = []
        processed_jars = 0

        for jar_path in dependencies:
            try:
                classes = self.extract_classes_from_jar(jar_path)
                class_index.extend(classes)
                processed_jars += 1

                if processed_jars % 10 == 0:
                    _log(f"已处理 {processed_jars}/{len(dependencies)} 个JAR包")
            except Exception as e:
                _log(f"处理JAR包失败: {jar_path}, 错误: {e}")

        # 3. 保存索引到文件
        sample_entries = [
            f"{entry.class_name} -> {os.path.basename(entry.jar_path)}"
            for entry in class_index[:10]
        ]

        result = ScanResult(
            processed_jars, len(class_index), index_path, sample_entries
        )

        # 保存索引数据
        index_data = {
            "jarCount": result.jar_count,
            "classCount": result.class_count,
            "indexPath": result.index_path,
            "sampleEntries": result.sample_entries,
            "classIndex": [
                {
                    "className": entry.class_name,
                    "jarPath": entry.jar_path,
                    "packageName": entry.package_name,
                    "simpleName": entry.simple_name,
                }
                for entry in class_index
            ],
            "lastUpdated": __import__("datetime").datetime.now().isoformat(),
        }

        with open(index_path, "w", encoding="utf-8") as f:
            json.dump(index_data, f, indent=2, ensure_ascii=False)

        _log(
            f"扫描完成！处理了 {processed_jars} 个JAR包，索引了 {len(class_index)} 个类"
        )

        return result

    def get_maven_dependencies(self, project_path: str) -> List[str]:
        """
        获取Maven依赖树中的所有JAR包路径
        """
        try:
            # 构建Maven命令路径
            maven_cmd = self.get_maven_command()

            # 执行 mvn dependency:tree 命令
            result = subprocess.run(
                [maven_cmd, "dependency:tree", "-DoutputType=text"],
                cwd=project_path,
                capture_output=True,
                text=True,
                timeout=60,
            )

            if result.returncode != 0:
                raise Exception(f"Maven命令执行失败: {result.stderr}")

            # 解析输出，提取JAR包路径
            jar_paths = set()
            lines = result.stdout.split("\n")

            for line in lines:
                # 匹配类似这样的行: [INFO] +- com.example:my-lib:jar:1.0.0:compile
                if "[INFO]" in line and ":" in line:
                    # 提取依赖坐标
                    parts = line.split()
                    for part in parts:
                        if (
                            part.count(":") >= 4
                        ):  # groupId:artifactId:type:version:scope
                            jar_path = self.resolve_jar_path(part, project_path)
                            if jar_path and os.path.exists(jar_path):
                                jar_paths.add(jar_path)
                            break

            return list(jar_paths)
        except Exception as e:
            _log(f"获取Maven依赖失败: {e}")
            # 如果Maven命令失败，尝试从本地仓库扫描
            return self.scan_local_maven_repo(project_path)

    def scan_local_maven_repo(self, project_path: str) -> List[str]:
        """
        从本地Maven仓库扫描JAR包
        """
        maven_repo_path = self.get_maven_repository_path()

        if not os.path.exists(maven_repo_path):
            raise Exception("Maven本地仓库不存在")

        jar_files: List[str] = []

        for root, dirs, files in os.walk(maven_repo_path):
            for file in files:
                if file.endswith(".jar"):
                    jar_files.append(os.path.join(root, file))

        return jar_files

    def resolve_jar_path(self, dependency: str, project_path: str) -> Optional[str]:
        """
        解析依赖坐标，获取JAR包路径
        """
        parts = dependency.split(":")
        if len(parts) < 4:
            return None

        group_id, artifact_id, type_, version = parts[:4]

        if type_ != "jar":
            return None

        # 使用统一的Maven仓库路径获取方法
        maven_repo_path = self.get_maven_repository_path()
        group_path = group_id.replace(".", "/")
        jar_path = os.path.join(
            maven_repo_path,
            group_path,
            artifact_id,
            version,
            f"{artifact_id}-{version}.jar",
        )

        return jar_path

    def extract_classes_from_jar(self, jar_path: str) -> List[ClassIndexEntry]:
        """
        从JAR包中提取所有类文件信息。
        若配置了 CLASS_PACKAGE_PREFIXES，则只提取包名匹配的类。
        """
        classes: List[ClassIndexEntry] = []
        package_prefixes = self.get_package_prefixes()

        with zipfile.ZipFile(jar_path, "r") as zf:
            for file_info in zf.infolist():
                if (
                    file_info.filename.endswith(".class")
                    and "$" not in file_info.filename
                ):
                    class_name = file_info.filename.replace(".class", "").replace(
                        "/", "."
                    )

                    last_dot_index = class_name.rfind(".")
                    if last_dot_index > 0:
                        package_name = class_name[:last_dot_index]
                        simple_name = class_name[last_dot_index + 1 :]
                    else:
                        package_name = ""
                        simple_name = class_name

                    # 包名前缀过滤：配置了前缀时，只保留匹配的类
                    if package_prefixes and not any(
                        class_name.startswith(prefix) for prefix in package_prefixes
                    ):
                        continue

                    classes.append(
                        ClassIndexEntry(class_name, jar_path, package_name, simple_name)
                    )

        return classes

    def find_jar_for_class(self, class_name: str, project_path: str) -> Optional[str]:
        """
        根据类名查找对应的JAR包路径
        """
        index_path = os.path.join(project_path, ".mcp-class-index.json")

        if not os.path.exists(index_path):
            raise Exception("类索引不存在，请先运行依赖扫描")

        with open(index_path, "r", encoding="utf-8") as f:
            index_data = json.load(f)

        for entry in index_data["classIndex"]:
            if entry["className"] == class_name:
                return entry["jarPath"]

        return None

    def get_all_class_names(self, project_path: str) -> List[str]:
        """
        获取所有已索引的类名
        """
        index_path = os.path.join(project_path, ".mcp-class-index.json")

        if not os.path.exists(index_path):
            return []

        with open(index_path, "r", encoding="utf-8") as f:
            index_data = json.load(f)

        return [entry["className"] for entry in index_data["classIndex"]]

    def get_maven_command(self) -> str:
        """
        获取Maven命令路径
        """
        maven_home = os.environ.get("MAVEN_HOME")
        if maven_home:
            maven_cmd = "mvn.cmd" if os.name == "nt" else "mvn"
            return os.path.join(maven_home, "bin", maven_cmd)
        return "mvn"  # 回退到PATH中的mvn

    def get_maven_repository_path(self) -> str:
        """
        获取Maven本地仓库路径
        """
        # 1. 优先使用环境变量 MAVEN_REPO 指定的仓库路径（支持 ~ 展开）
        maven_repo = os.environ.get("MAVEN_REPO")
        if maven_repo:
            return os.path.expanduser(maven_repo)

        # 2. 使用默认的Maven本地仓库路径
        return os.path.expanduser("~/.m2/repository")
