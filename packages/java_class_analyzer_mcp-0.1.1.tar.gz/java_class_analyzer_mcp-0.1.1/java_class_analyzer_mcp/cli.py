import click
import json
import os
import sys
from .scanner.dependency_scanner import DependencyScanner
from .decompiler.decompiler_service import DecompilerService
from .analyzer.java_class_analyzer import JavaClassAnalyzer


@click.group()
@click.version_option(version="1.0.0")
def cli():
    """Java Class Analyzer MCP Server CLI"""
    pass


@cli.command()
def start():
    """启动MCP服务器"""
    try:
        from .main import mcp

        mcp.run(transport="stdio")
    except Exception as e:
        print(f"启动服务器失败: {e}", file=sys.stderr)
        sys.exit(1)


@cli.command()
@click.option("-o", "--output", required=True, help="输出配置文件路径")
def config(output):
    """生成MCP客户端配置模板"""
    config_template = {
        "mcpServers": {
            "java-class-analyzer": {
                "command": "java-class-analyzer-mcp",
                "args": [],
                "env": {
                    "LOG_LEVEL": "INFO",
                    "MAVEN_REPO": os.path.expanduser("~/.m2/repository"),
                    "JAVA_HOME": os.environ.get("JAVA_HOME", ""),
                    "CFR_PATH": "",
                    "CLASS_PACKAGE_PREFIXES": "",
                },
            }
        }
    }

    with open(output, "w", encoding="utf-8") as f:
        json.dump(config_template, f, indent=2, ensure_ascii=False)

    print(f"配置文件已生成: {output}")


@cli.command()
@click.option(
    "-t",
    "--tool",
    type=click.Choice(["scan", "decompile", "analyze", "all"]),
    required=True,
    help="要测试的工具",
)
@click.option("-p", "--project", required=True, help="项目路径")
@click.option("-c", "--class-name", help="要分析的类名")
@click.option("--no-refresh", is_flag=True, help="不强制刷新依赖索引")
@click.option("--no-cache", is_flag=True, help="不使用反编译缓存")
def test(tool, project, class_name, no_refresh, no_cache):
    """测试工具使用"""
    project_path = os.path.abspath(project)

    if not os.path.exists(project_path):
        print(f"项目路径不存在: {project_path}")
        sys.exit(1)

    # 初始化服务
    scanner = DependencyScanner()
    decompiler = DecompilerService()
    analyzer = JavaClassAnalyzer()

    try:
        if tool == "scan" or tool == "all":
            print("=== 测试依赖扫描 ===")
            result = scanner.scan_project(project_path, not no_refresh)
            print(
                f"扫描完成！处理了 {result.jar_count} 个JAR包，索引了 {result.class_count} 个类"
            )
            print(f"索引文件路径: {result.index_path}")
            print("示例索引条目:")
            for entry in result.sample_entries[:5]:
                print(f"  {entry}")
            print()

        if tool in ["decompile", "analyze", "all"]:
            if not class_name:
                print("请指定要分析的类名")
                sys.exit(1)

            # 确保索引存在
            index_path = os.path.join(project_path, ".mcp-class-index.json")
            if not os.path.exists(index_path):
                print("正在创建类索引...")
                scanner.scan_project(project_path, False)

        if tool == "decompile" or tool == "all":
            print("=== 测试类反编译 ===")
            use_cache = not no_cache
            source_code = decompiler.decompile_class(
                class_name, project_path, use_cache
            )
            print(f"类 {class_name} 的反编译源码:")
            print("=" * 50)
            print(source_code)
            print("=" * 50)
            print()

        if tool == "analyze" or tool == "all":
            print("=== 测试类分析 ===")
            analysis = analyzer.analyze_class(class_name, project_path)

            print(f"类 {class_name} 的分析结果:")
            print(f"包名: {analysis.package_name}")
            print(f"类名: {analysis.class_name}")
            print(f"修饰符: {' '.join(analysis.modifiers)}")
            print(f"父类: {analysis.super_class or '无'}")
            print(f"实现的接口: {', '.join(analysis.interfaces) or '无'}")

            if analysis.fields:
                print(f"\n字段 ({len(analysis.fields)}个):")
                for field in analysis.fields:
                    print(f"  - {' '.join(field.modifiers)} {field.type_} {field.name}")

            if analysis.methods:
                print(f"\n方法 ({len(analysis.methods)}个):")
                for method in analysis.methods:
                    print(
                        f"  - {' '.join(method.modifiers)} {method.return_type} {method.name}({', '.join(method.parameters)})"
                    )
            print()

    except Exception as e:
        print(f"测试失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    cli()
