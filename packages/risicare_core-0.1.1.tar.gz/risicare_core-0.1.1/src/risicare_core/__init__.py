"""
Risicare Core - Core types and taxonomy for agent observability.

This package provides the foundational types used throughout the Risicare SDK:
- Type aliases (TraceID, SpanID, SessionID, etc.)
- Enumerations (SpanKind, SpanStatus, AgentRole, etc.)
- Span types (Span, SpanEvent, SpanLink, etc.)
- Error taxonomy (10 modules, 150 error codes)
- Context propagation utilities
"""

__version__ = "0.1.0"

# Base types
from risicare_core.types.base import (
    AgentID,
    AgentRole,
    EvaluationType,
    FixType,
    MessageType,
    Metadata,
    SemanticPhase,
    SessionID,
    SpanID,
    SpanKind,
    SpanStatus,
    TimeRange,
    Timestamp,
    TraceFlags,
    TraceID,
    generate_agent_id,
    generate_session_id,
    generate_span_id,
    generate_trace_id,
    utc_now,
    validate_span_id,
    validate_trace_id,
)

# Span types
from risicare_core.types.spans import (
    ExceptionInfo,
    LLMAttributes,
    Span,
    SpanEvent,
    SpanLink,
)

# Context propagation
from risicare_core.context import (
    # Context data classes
    AgentContext,
    SessionContext,
    TraceContext,
    # Context accessors
    get_current_agent,
    get_current_context,
    get_current_phase,
    get_current_session,
    get_current_span,
    get_trace_context,
    # Convenience ID accessors
    get_current_session_id,
    get_current_trace_id,
    get_current_span_id,
    get_current_agent_id,
    get_current_parent_span_id,
    # Context setters (internal)
    set_current_span,
    reset_current_span,
    # Context managers
    agent_context,
    async_agent_context,
    async_session_context,
    phase_context,
    restore_trace_context,
    session_context,
    # Patching utilities
    is_asyncio_patched,
    is_executors_patched,
    is_process_patched,
    patch_all,
    patch_asyncio,
    patch_executors,
    patch_process_executors,
    unpatch_all,
    unpatch_asyncio,
    unpatch_executors,
    unpatch_process_executors,
    # Pre-init executor detection (Gap 1 fix)
    get_pre_patch_executor_count,
    set_pre_init_executor_warning,
    # Span registry (async generator workaround)
    get_span_by_id,
    register_span,
    unregister_span,
    extend_span_ttl,
    get_span_registry_stats,
    SpanRegistry,
    # Streaming utilities
    traced_stream,
    traced_stream_sync,
    # Async generator context capture (Gap 3 fix)
    capture_async_generator_context,
    context_preserving_stream,
    stream_with_context,
    # W3C Trace Context
    extract_trace_context,
    inject_trace_context,
    # Testing utilities
    _reset_for_testing as _reset_context_for_testing,
)

# Error taxonomy
from risicare_core.taxonomy import (
    ErrorCode,
    ErrorCategory,
    TaxonomyModule,
    ALL_MODULES,
    get_module,
    get_category,
    get_error_code,
    classify_error,
)

# Observability
from risicare_core.observability import (
    # Configuration
    enable_context_observability,
    disable_context_observability,
    is_observability_enabled,
    # Types
    ContextType,
    ContextOperation,
    # Metrics
    context_metrics,
    # Reporting
    get_context_health_report,
    get_prometheus_metrics,
)

__all__ = [
    # Version
    "__version__",
    # Type aliases
    "TraceID",
    "SpanID",
    "SessionID",
    "AgentID",
    "Timestamp",
    "Metadata",
    # Enumerations
    "SpanKind",
    "SpanStatus",
    "TraceFlags",
    "AgentRole",
    "MessageType",
    "SemanticPhase",
    "EvaluationType",
    "FixType",
    # Data classes
    "TimeRange",
    "SpanEvent",
    "SpanLink",
    "ExceptionInfo",
    "LLMAttributes",
    "Span",
    # ID generation functions
    "generate_trace_id",
    "generate_span_id",
    "generate_session_id",
    "generate_agent_id",
    "utc_now",
    "validate_trace_id",
    "validate_span_id",
    # Context data classes
    "SessionContext",
    "AgentContext",
    "TraceContext",
    # Context accessors
    "get_current_session",
    "get_current_agent",
    "get_current_span",
    "get_current_phase",
    "get_current_context",
    "get_trace_context",
    # Convenience ID accessors
    "get_current_session_id",
    "get_current_trace_id",
    "get_current_span_id",
    "get_current_agent_id",
    "get_current_parent_span_id",
    # Context setters (internal)
    "set_current_span",
    "reset_current_span",
    # Context managers
    "session_context",
    "async_session_context",
    "agent_context",
    "async_agent_context",
    "phase_context",
    "restore_trace_context",
    # Patching utilities
    "patch_executors",
    "unpatch_executors",
    "is_executors_patched",
    "patch_process_executors",
    "unpatch_process_executors",
    "is_process_patched",
    "patch_asyncio",
    "unpatch_asyncio",
    "is_asyncio_patched",
    "patch_all",
    "unpatch_all",
    # Pre-init executor detection
    "get_pre_patch_executor_count",
    "set_pre_init_executor_warning",
    # Span registry
    "register_span",
    "get_span_by_id",
    "unregister_span",
    "extend_span_ttl",
    "get_span_registry_stats",
    "SpanRegistry",
    # Streaming utilities
    "traced_stream",
    "traced_stream_sync",
    # Async generator context capture
    "capture_async_generator_context",
    "context_preserving_stream",
    "stream_with_context",
    # W3C Trace Context
    "inject_trace_context",
    "extract_trace_context",
    # Error taxonomy
    "ErrorCode",
    "ErrorCategory",
    "TaxonomyModule",
    "ALL_MODULES",
    "get_module",
    "get_category",
    "get_error_code",
    "classify_error",
    # Observability
    "enable_context_observability",
    "disable_context_observability",
    "is_observability_enabled",
    "ContextType",
    "ContextOperation",
    "context_metrics",
    "get_context_health_report",
    "get_prometheus_metrics",
]
