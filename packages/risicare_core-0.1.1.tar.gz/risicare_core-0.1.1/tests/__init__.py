"""Test package for risicare-core."""
