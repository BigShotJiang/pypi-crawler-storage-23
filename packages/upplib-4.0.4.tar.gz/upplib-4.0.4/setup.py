import setuptools
import os
import shutil
from setuptools import Command
import requests

with open("README.md", "r") as fh:
    long_description = fh.read()


class CleanCommand(Command):
    user_options = []

    def initialize_options(self):
        pass

    def finalize_options(self):
        pass

    def run(self):
        if os.path.exists('dist'):
            shutil.rmtree('dist')
        if os.path.exists('upplib.egg-info'):
            shutil.rmtree('upplib.egg-info')


def get_version():
    response = requests.get("https://pypi.org/pypi/upplib/json")
    if response.status_code == 200:
        latest_version = response.json()["info"]["version"]
    else:
        raise Exception("unable to obtain the latest version of the library")

    # 1. 列表推导式转换，比 map(int, ...) 更 Pythonic
    parts = [int(x) for x in latest_version.split('.')]

    # 2. 从末尾向前迭代
    for i in range(len(parts) - 1, -1, -1):
        if parts[i] < 9 or i == 0:  # 如果小于9，或者已经是第一位了
            parts[i] += 1
            break
        else:
            parts[i] = 0  # 逢9重置为0，继续向上位进1

    return '.'.join(map(str, parts))


setuptools.setup(
    name="upplib",
    version=get_version(),
    author="Luck",
    author_email="wantwaterfish@gmail.com",
    description="util",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.10',
    install_requires=[
        "python-dateutil>=2.8.2",  # 新增：强大的日期解析库
        "openpyxl>=3.1.2",
        "xlrd>=2.0.1",
        "bs4>=0.0.2",
        "aliyun-log-python-sdk>=0.9.32",
        "huaweicloudsdkcore>=3.1.166",
        "huaweicloudsdklts>=3.1.166",
        "requests>=2.32.3",
        "PyMySQL>=1.1.0",
        "pyarrow>=16.0.0",
        "sqlparse>=0.5.0",
        "redis>=6.4.0",
        "pandas>=2.2.2"
    ],
    license="MIT",
    cmdclass={
        'clean': CleanCommand
    }
)
