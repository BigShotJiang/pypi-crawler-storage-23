"""
Aigie Realtime Module - Backend connector for real-time interception.

This module provides WebSocket-based communication with the Aigie backend
for real-time consultation, fix application, and leveraging historical data.
"""

from .base_ws import BaseWebSocketClient, ConnectionState
from .connector import BackendConnector
from .auto_fix import AutoFixApplicator, FixStrategy, FixResult, FixConfig
from .remediation_engine import (
    RemediationEngine,
    RemediationResult,
    RemediationConfig,
    ErrorClassifier,
)

__all__ = [
    "BaseWebSocketClient",
    "BackendConnector",
    "ConnectionState",
    "AutoFixApplicator",
    "FixStrategy",
    "FixResult",
    "FixConfig",
    "RemediationEngine",
    "RemediationResult",
    "RemediationConfig",
    "ErrorClassifier",
]
