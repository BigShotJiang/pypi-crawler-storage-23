"""Shared utilities for Aigie SDK instrumentation."""
