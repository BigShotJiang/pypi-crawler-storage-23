from py2many.version import __version__  # noqa: F401
