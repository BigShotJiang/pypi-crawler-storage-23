

Tested with: DMD64 D Compiler v2.108.1 https://dlang.org/download.html

