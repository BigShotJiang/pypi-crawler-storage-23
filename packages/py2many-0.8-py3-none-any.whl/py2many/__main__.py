from py2many.cli import main

main()
