from enum import StrEnum


class Device(StrEnum):
    cpu = "cpu"
    cuda = "cuda"
