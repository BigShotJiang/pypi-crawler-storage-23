from timmx.cli import main

main()
