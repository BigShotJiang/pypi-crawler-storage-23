from .socutrss import ScoutRSS
from ._version import __version__