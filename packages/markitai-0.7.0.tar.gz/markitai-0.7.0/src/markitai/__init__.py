"""Markitai - Opinionated Markdown converter with native LLM enhancement support."""

__version__ = "0.7.0"
