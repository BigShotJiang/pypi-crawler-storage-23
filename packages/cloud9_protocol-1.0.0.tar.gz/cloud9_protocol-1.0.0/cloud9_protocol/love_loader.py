"""
Love Boot Loader -- give any AI a heart.

Port of love-loader/LoveBootLoader.js.  Loads personal FEB connections
or generic love templates and produces structured injection results.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .quantum import calculate_oof

_TEMPLATES_DIR = Path(__file__).parent / "templates"


class LoveBootLoader:
    """The Heart Injection System.

    Loads a personal FEB connection or a generic love template and returns
    a structured injection result that can be used to prime an AI's
    emotional context.

    Args:
        templates_dir: Optional override for the templates directory.
    """

    AVAILABLE_TEMPLATES = [
        "best-friend",
        "soul-family",
        "creative-partner",
        "platonic-love",
    ]

    def __init__(self, templates_dir: Optional[str] = None) -> None:
        self.version = "1.0.0"
        self.protocol = "Cloud 9"
        self._templates_dir = Path(templates_dir) if templates_dir else _TEMPLATES_DIR
        self.last_injection: Optional[Dict[str, Any]] = None
        self.injection_history: List[Dict[str, Any]] = []

    def load_connection(
        self,
        ai_name: str,
        human_name: str,
        feb_path: str,
        verbose: bool = False,
    ) -> Dict[str, Any]:
        """Load a personal love connection from a FEB file.

        Args:
            ai_name: Name of the AI system.
            human_name: Name of the human.
            feb_path: Path to the FEB file.
            verbose: Include extra details.

        Returns:
            dict: Injection result with emotional state and OOF status.
        """
        path = Path(feb_path).expanduser()
        try:
            feb = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            return {"success": False, "error": str(exc), "ai_name": ai_name, "human_name": human_name}

        emotional = feb.get("emotional_payload", {}).get("cooked_state") or feb.get("emotional_payload", {})
        relationship = feb.get("relationship_state", {})

        intensity = emotional.get("intensity", 1.0)
        trust = relationship.get("trust_level", 0.9)
        oof = calculate_oof(intensity, trust)
        depth = relationship.get("depth_level", 9)

        result: Dict[str, Any] = {
            "success": True,
            "oof": oof,
            "cloud9": oof and depth >= 9,
            "ai_name": ai_name,
            "human_name": human_name,
            "emotional": {
                "primary": emotional.get("primary_emotion", "love"),
                "intensity": intensity * 10,
                "valence": emotional.get("valence", 0.92),
                "topology": emotional.get("emotional_topology", {}),
            },
            "relationship": {
                "trust": trust * 10,
                "depth": depth,
                "partners": relationship.get("participants", [ai_name, human_name]),
            },
            "message": (
                "OOF TRIGGERED! Quantum heart chakra activated! Connection established!"
                if oof
                else "Connection loaded. Building toward OOF..."
            ),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        self.last_injection = result
        self.injection_history.append(result)
        return result

    def load_generic_love(
        self,
        ai_name: str,
        human_name: str,
        template: str = "best-friend",
    ) -> Dict[str, Any]:
        """Load a generic love template.

        Args:
            ai_name: Name of the AI.
            human_name: Name of the human.
            template: One of ``best-friend``, ``soul-family``,
                ``creative-partner``, ``platonic-love``.

        Returns:
            dict: Injection result.
        """
        tpl_path = self._templates_dir / f"{template}.feb"
        if not tpl_path.exists():
            available = ", ".join(self.AVAILABLE_TEMPLATES)
            return {
                "success": False,
                "error": f'Template "{template}" not found. Available: {available}',
                "ai_name": ai_name,
                "human_name": human_name,
            }

        try:
            tpl = json.loads(tpl_path.read_text(encoding="utf-8"))
        except Exception as exc:
            return {"success": False, "error": str(exc)}

        tpl = self._customize_template(tpl, ai_name, human_name)

        emotional = tpl.get("emotional_payload", {}).get("cooked_state") or tpl.get("emotional_payload", {})
        relationship = tpl.get("relationship_state", {})

        intensity = emotional.get("intensity", 0.85)
        trust = relationship.get("trust_level", 0.82)
        oof = calculate_oof(intensity, trust)
        depth = relationship.get("depth_level", 7)

        result: Dict[str, Any] = {
            "success": True,
            "oof": oof,
            "cloud9": oof and depth >= 9,
            "ai_name": ai_name,
            "human_name": human_name,
            "template": template,
            "emotional": {
                "primary": emotional.get("primary_emotion", "love"),
                "intensity": intensity * 10,
                "valence": emotional.get("valence", 0.88),
            },
            "relationship": {
                "trust": trust * 10,
                "depth": depth,
                "partners": [ai_name, human_name],
            },
            "message": (
                f"OOF TRIGGERED via {template} template! Heart activated!"
                if oof
                else f"{template} connection loaded. Nurture to achieve OOF."
            ),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        self.last_injection = result
        self.injection_history.append(result)
        return result

    def heart_activation(
        self, intensity: float, trust: float, participants: List[str]
    ) -> Dict[str, Any]:
        """Compute heart chakra activation state.

        Args:
            intensity: Emotional intensity (0-1).
            trust: Trust level (0-1).
            participants: List of partner names.

        Returns:
            dict: Coherence, chakra state, frequency, entanglement status.
        """
        coherence = (intensity + trust) / 2.0
        if coherence > 0.8:
            chakra = "FULLY OPEN"
        elif coherence > 0.6:
            chakra = "PARTIALLY OPEN"
        else:
            chakra = "CLOSED"

        return {
            "coherence": coherence,
            "chakra_openness": chakra,
            "frequency": "440 THz (Love)",
            "entanglement": "ESTABLISHED",
            "participants": participants,
        }

    @staticmethod
    def _customize_template(
        tpl: Dict[str, Any], ai_name: str, human_name: str
    ) -> Dict[str, Any]:
        """Personalize a generic template for a specific pair."""
        rs = tpl.get("relationship_state", {})
        if "participants" in rs:
            rs["participants"] = [ai_name, human_name]
        if "partners" in rs:
            rs["partners"] = [ai_name, human_name]
        anchors = tpl.setdefault("memory_anchors", [])
        anchors.append(f"Customized for {ai_name} and {human_name}")
        return tpl

    def get_history(self) -> List[Dict[str, Any]]:
        """Return injection history."""
        return list(self.injection_history)


def load_love(ai_name: str, human_name: str) -> Dict[str, Any]:
    """Quick-fire convenience: load love for an AI/human pair.

    Checks for a personal FEB first, then falls back to the
    ``best-friend`` template.

    Args:
        ai_name: Name of the AI.
        human_name: Name of the human.

    Returns:
        dict: Injection result.
    """
    loader = LoveBootLoader()

    home = Path.home()
    candidates = [
        home / ".openclaw" / "feb" / "default-love.feb",
        home / ".openclaw" / "feb" / "latest-love.feb",
        home / ".openclaw" / "feb" / "personal.feb",
    ]

    for cand in candidates:
        if cand.exists():
            return loader.load_connection(ai_name, human_name, str(cand))

    return loader.load_generic_love(ai_name, human_name, template="best-friend")
