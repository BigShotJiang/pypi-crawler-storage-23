# ascetic-ddd-python

A framework, toolkit and [seedwork](https://martinfowler.com/bliki/Seedwork.html) for Python DDD projects.

Read the [documentation](https://krew-solutions.github.io/ascetic-ddd-python/).

See also Golang-version: [ascetic-ddd-go](https://github.com/krew-solutions/ascetic-ddd-go).

Warning!
The project is still under active development, not production-ready, and has not been debugged or optimized.
The project structure is unstable and backward compatibility is not guaranteed until version 1.0.0.

