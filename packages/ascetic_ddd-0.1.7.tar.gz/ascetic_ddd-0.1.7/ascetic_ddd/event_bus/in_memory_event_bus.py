import collections
import typing

from ascetic_ddd.disposable import Disposable, IDisposable
from ascetic_ddd.event_bus.interfaces import IEventBus, IEventHandler

__all__ = ("InMemoryEventBus",)

SessionT = typing.TypeVar("SessionT")
EventT = typing.TypeVar("EventT")


class InMemoryEventBus(IEventBus[SessionT], typing.Generic[SessionT]):
    def __init__(self) -> None:
        self._subscribers: collections.defaultdict[str, list] = collections.defaultdict(list)

    async def publish(self, session: SessionT, uri: str, event: EventT) -> None:
        for handler in self._subscribers[uri]:
            await handler(session, uri, event)

    async def subscribe(self, uri: str, handler: IEventHandler[SessionT, EventT]) -> IDisposable:
        self._subscribers[uri].append(handler)

        async def callback() -> None:
            await self.unsubscribe(uri, handler)

        return Disposable(callback)

    async def unsubscribe(self, uri: str, handler: IEventHandler[SessionT, EventT]) -> None:
        self._subscribers[uri].remove(handler)
