__all__ = ('DekNotFound',)


class DekNotFound(Exception):
    pass
