__all__ = ('KekNotFound',)


class KekNotFound(Exception):
    pass
