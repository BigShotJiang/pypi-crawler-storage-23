import ast
import os
from dataclasses import dataclass, replace as dataclass_replace

import inflection
from jinja2 import BaseLoader, ChoiceLoader, Environment, FileSystemLoader

from ascetic_ddd.cli.scaffold.ast_merge import merge_modules
from ascetic_ddd.cli.scaffold.model import (
    CollectionType, CompositeVoDef, EntityRef, EnumVoDef, FieldDef,
    IdentityVoDef, PrimitiveType, SimpleVoDef, VoRef,
)
from ascetic_ddd.cli.scaffold.naming import camel_to_snake


TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), 'templates')

VO_TEMPLATE_MAP = {
    IdentityVoDef: 'domain/values/identity_vo.py.j2',
    SimpleVoDef: 'domain/values/simple_vo.py.j2',
    EnumVoDef: 'domain/values/enum_vo.py.j2',
    CompositeVoDef: 'domain/values/composite_vo.py.j2',
}


def _singularize(name):
    return inflection.singularize(name)


def _pluralize(name):
    return inflection.pluralize(name)


def _make_env(templates_dir=None):
    loader: BaseLoader
    if templates_dir:
        loader = ChoiceLoader([
            FileSystemLoader(templates_dir),
            FileSystemLoader(TEMPLATES_DIR),
        ])
    else:
        loader = FileSystemLoader(TEMPLATES_DIR)
    env = Environment(
        loader=loader,
        trim_blocks=True,
        lstrip_blocks=True,
        keep_trailing_newline=True,
    )
    env.filters['singularize'] = _singularize
    env.filters['pluralize'] = _pluralize
    env.filters['snake'] = camel_to_snake
    env.tests['composite_vo'] = lambda vo: isinstance(vo, CompositeVoDef)
    env.tests['enum_vo'] = lambda vo: isinstance(vo, EnumVoDef)
    return env


@dataclass
class _AggregateContext:
    """Per-aggregate state, analogous to EvaluateVisitor's push/pop context."""
    agg: object
    pkg: str
    agg_dir: str
    values_dir: str
    events_dir: str
    used_vos: list
    fields: list
    collection_fields: list
    needs_datetime: bool


class RenderWalker:
    """Walks BoundedContextModel and renders files via Jinja2 templates."""

    def __init__(self, output_dir, package_name=None, templates_dir=None,
                 merge=False):
        self._env = _make_env(templates_dir)
        self._output_dir = output_dir
        self._package_name = package_name
        self._merge = merge
        self._generated = []

    def walk(self, model):
        """Walk the entire model and return list of generated file paths."""
        for agg in model.aggregates:
            self._visit_aggregate(agg, model)
        return self._generated

    # --- visit methods ---

    def _visit_aggregate(self, agg, model):
        ctx = self._make_aggregate_context(agg)
        self._visit_value_objects(ctx)
        self._visit_entities(ctx)
        self._visit_aggregate_module(ctx)
        self._visit_domain_events(ctx)
        self._visit_commands(ctx, model)

    def _visit_value_objects(self, ctx):
        for vo in ctx.agg.value_objects:
            if not vo.import_path:
                self._visit_value_object(vo, ctx.values_dir, ctx.pkg)

        self._render_template(
            'domain/values/__init__.py.j2',
            os.path.join(ctx.values_dir, '__init__.py'),
            value_objects=self._resolve_vo_imports(ctx.agg.value_objects),
            package_prefix=ctx.pkg,
        )

    def _visit_value_object(self, vo, values_dir, pkg):
        self._render_template(
            VO_TEMPLATE_MAP[type(vo)],
            os.path.join(values_dir, '%s.py' % vo.snake_name),
            vo=vo,
            primitive_type=vo.primitive_type,
        )

        if isinstance(vo, CompositeVoDef):
            self._render_template(
                'domain/values/composite_vo_exporter.py.j2',
                os.path.join(
                    values_dir, '%s_exporter.py' % vo.snake_name,
                ),
                vo=vo,
                package_prefix=pkg,
            )

    def _visit_aggregate_module(self, ctx):
        agg = ctx.agg

        # aggregate.py
        self._render_template(
            'domain/aggregate.py.j2',
            os.path.join(ctx.agg_dir, '%s.py' % agg.snake_name),
            agg=agg,
            fields=ctx.fields,
            collection_fields=ctx.collection_fields,
            used_vos=ctx.used_vos,
            package_prefix=ctx.pkg,
            needs_datetime=ctx.needs_datetime,
            entities=agg.entities,
        )

        # aggregate_exporter.py
        self._render_template(
            'domain/aggregate_exporter.py.j2',
            os.path.join(ctx.agg_dir, '%s_exporter.py' % agg.snake_name),
            agg=agg,
            fields=ctx.fields,
            collection_fields=ctx.collection_fields,
            used_vos=ctx.used_vos,
            package_prefix=ctx.pkg,
            entities=agg.entities,
        )

        # aggregate_reconstitutor.py
        reconstitutor_params = _build_reconstitutor_params(ctx.fields)
        self._render_template(
            'domain/aggregate_reconstitutor.py.j2',
            os.path.join(ctx.agg_dir, '%s_reconstitutor.py' % agg.snake_name),
            agg=agg,
            fields=ctx.fields,
            reconstitutor_params=reconstitutor_params,
            used_vos=ctx.used_vos,
            package_prefix=ctx.pkg,
            needs_datetime=ctx.needs_datetime,
            entities=agg.entities,
        )

        # __init__.py
        self._render_template(
            'domain/__init__.py.j2',
            os.path.join(ctx.agg_dir, '__init__.py'),
        )

    def _visit_domain_events(self, ctx):
        for event in ctx.agg.domain_events:
            self._visit_domain_event(event, ctx)

        self._render_template(
            'domain/events/__init__.py.j2',
            os.path.join(ctx.events_dir, '__init__.py'),
        )

    def _visit_domain_event(self, event, ctx):
        ev_used_vos = self._resolve_vo_imports(_collect_used_vos(event.fields))
        ev_collection_fields = [f for f in event.fields if f.is_collection]

        self._render_template(
            'domain/events/domain_event.py.j2',
            os.path.join(ctx.events_dir, '%s.py' % event.snake_name),
            event=event,
            used_vos=ev_used_vos,
            package_prefix=ctx.pkg,
            needs_datetime=_needs_datetime(event.fields),
        )

        self._render_template(
            'domain/events/domain_event_exporter.py.j2',
            os.path.join(ctx.events_dir, '%s_exporter.py' % event.snake_name),
            event=event,
            collection_fields=ev_collection_fields,
            used_vos=ev_used_vos,
            package_prefix=ctx.pkg,
        )

    def _visit_commands(self, ctx, model):
        if not ctx.agg.commands:
            return

        if self._package_name:
            app_pkg = '%s.application' % self._package_name
        else:
            app_pkg = 'application'
        cmds_pkg = '%s.commands' % app_pkg
        cmds_dir = os.path.join(self._output_dir, 'application', 'commands')
        app_dir = os.path.join(self._output_dir, 'application')
        os.makedirs(cmds_dir, exist_ok=True)

        for cmd in ctx.agg.commands:
            self._visit_command(cmd, cmds_dir, cmds_pkg)

        # commands/__init__.py (shared across all aggregates)
        all_commands = []
        for a in model.aggregates:
            all_commands.extend(a.commands)
        self._render_template(
            'application/commands/__init__.py.j2',
            os.path.join(cmds_dir, '__init__.py'),
            commands=all_commands,
            commands_package=cmds_pkg,
        )

        # application/__init__.py
        self._render_template(
            'application/__init__.py.j2',
            os.path.join(app_dir, '__init__.py'),
        )

    def _visit_command(self, cmd, cmds_dir, cmds_pkg):
        self._render_template(
            'application/commands/command.py.j2',
            os.path.join(cmds_dir, '%s_command.py' % cmd.snake_name),
            cmd=cmd,
            needs_datetime=any(
                'datetime' in f.type_name for f in cmd.fields
            ),
            needs_decimal=any(
                'Decimal' in f.type_name for f in cmd.fields
            ),
        )

        self._render_template(
            'application/commands/command_handler.py.j2',
            os.path.join(cmds_dir, '%s_command_handler.py' % cmd.snake_name),
            cmd=cmd,
            commands_package=cmds_pkg,
        )

    def _visit_entities(self, ctx):
        for entity in ctx.agg.entities:
            self._visit_entity(entity, ctx.agg_dir)

    def _visit_entity(self, entity, parent_dir):
        entity_dir = os.path.join(parent_dir, entity.snake_name)
        entity_values_dir = os.path.join(entity_dir, 'values')
        os.makedirs(entity_values_dir, exist_ok=True)

        entity_pkg = self._dir_to_pkg(entity_dir)

        # Generate entity VOs
        for vo in entity.value_objects:
            if not vo.import_path:
                self._visit_value_object(vo, entity_values_dir, entity_pkg)
        self._render_template(
            'domain/values/__init__.py.j2',
            os.path.join(entity_values_dir, '__init__.py'),
            value_objects=entity.value_objects,
            package_prefix=entity_pkg,
        )

        # Generate entity class, exporter, reconstitutor
        fields = entity.fields
        used_vos = _collect_used_vos(fields)
        used_vos = self._resolve_vo_imports(used_vos)
        collection_fields = [f for f in fields if f.is_collection]
        reconstitutor_params = _build_reconstitutor_params(fields)

        self._render_template(
            'domain/entity/entity.py.j2',
            os.path.join(entity_dir, '%s.py' % entity.snake_name),
            entity=entity,
            fields=fields,
            used_vos=used_vos,
            package_prefix=entity_pkg,
            needs_datetime=_needs_datetime(fields),
        )
        self._render_template(
            'domain/entity/entity_exporter.py.j2',
            os.path.join(
                entity_dir, '%s_exporter.py' % entity.snake_name,
            ),
            entity=entity,
            fields=fields,
            collection_fields=collection_fields,
            used_vos=used_vos,
            package_prefix=entity_pkg,
        )
        self._render_template(
            'domain/entity/entity_reconstitutor.py.j2',
            os.path.join(
                entity_dir, '%s_reconstitutor.py' % entity.snake_name,
            ),
            entity=entity,
            fields=fields,
            reconstitutor_params=reconstitutor_params,
            used_vos=used_vos,
            package_prefix=entity_pkg,
            needs_datetime=_needs_datetime(fields),
        )
        self._render_template(
            'domain/__init__.py.j2',
            os.path.join(entity_dir, '__init__.py'),
        )

        # Recurse into nested entities
        for nested in entity.entities:
            self._visit_entity(nested, entity_dir)

    # --- helpers ---

    def _dir_to_pkg(self, dir_path):
        """Derive Python import package from filesystem directory path."""
        rel = os.path.relpath(dir_path, self._output_dir)
        pkg = rel.replace(os.sep, '.')
        if self._package_name:
            return '%s.%s' % (self._package_name, pkg)
        return pkg

    def _resolve_vo_imports(self, used_vos):
        """Resolve relative import_path to absolute."""
        domain_pkg = self._dir_to_pkg(
            os.path.join(self._output_dir, 'domain'),
        )
        result = []
        for vo in used_vos:
            if vo.import_path.startswith('.'):
                vo = dataclass_replace(
                    vo, import_path=domain_pkg + vo.import_path,
                )
            result.append(vo)
        return result

    def _make_aggregate_context(self, agg):
        agg_dir = os.path.join(self._output_dir, 'domain', agg.snake_name)
        values_dir = os.path.join(agg_dir, 'values')
        events_dir = os.path.join(agg_dir, 'events')

        for d in (agg_dir, values_dir, events_dir):
            os.makedirs(d, exist_ok=True)

        pkg = self._dir_to_pkg(agg_dir)
        fields = agg.fields

        return _AggregateContext(
            agg=agg,
            pkg=pkg,
            agg_dir=agg_dir,
            values_dir=values_dir,
            events_dir=events_dir,
            used_vos=self._resolve_vo_imports(_collect_used_vos(fields)),
            fields=fields,
            collection_fields=[f for f in fields if f.is_collection],
            needs_datetime=_needs_datetime(fields),
        )

    def _render_template(self, tpl_name, path, **kwargs):
        tpl = self._env.get_template(tpl_name)
        content = tpl.render(**kwargs)
        content = content.rstrip('\n') + '\n'

        if self._merge and path.endswith('.py') and os.path.exists(path):
            with open(path, 'r') as f:
                existing_src = f.read()
            existing_tree = ast.parse(existing_src)
            generated_tree = ast.parse(content)
            merged = merge_modules(existing_tree, generated_tree)
            ast.fix_missing_locations(merged)
            content = ast.unparse(merged) + '\n'

        with open(path, 'w') as f:
            f.write(content)
        self._generated.append(path)


# --- Public facade ---


def render_bounded_context(model, output_dir, package_name=None,
                           templates_dir=None):
    walker = RenderWalker(output_dir, package_name, templates_dir)
    return walker.walk(model)


def ast_render_bounded_context(model, output_dir, package_name=None,
                               templates_dir=None):
    walker = RenderWalker(output_dir, package_name, templates_dir,
                          merge=True)
    return walker.walk(model)


# --- Shared helpers ---


def _collect_used_vos(fields):
    """Return deduplicated, sorted list of VOs referenced by fields."""
    seen = set()
    result = []
    for f in fields:
        type_ref = f.type_ref
        if isinstance(type_ref, CollectionType):
            type_ref = type_ref.element
        if isinstance(type_ref, VoRef) and type_ref.vo.class_name not in seen:
            seen.add(type_ref.vo.class_name)
            result.append(type_ref.vo)
    return sorted(result, key=lambda vo: vo.class_name)


def _needs_datetime(fields):
    for f in fields:
        if 'datetime' in f.type_name:
            return True
    return False


def _build_reconstitutor_params(fields):
    """Build parameter list for reconstitutor __init__ with primitive types."""
    params = []
    for f in fields:
        params.append(FieldDef(
            name=f.param_name,
            param_name=f.param_name,
            type_ref=PrimitiveType(f.type_ref.primitive_type),
        ))
    return params
