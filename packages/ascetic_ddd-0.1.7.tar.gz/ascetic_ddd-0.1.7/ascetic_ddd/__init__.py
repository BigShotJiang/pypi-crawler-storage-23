"""Copied from https://github.com/emacsway/grade-py."""
