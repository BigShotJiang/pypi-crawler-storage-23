from ascetic_ddd.utils.amemo import amemo
from ascetic_ddd.utils.property import classproperty, setterproperty
