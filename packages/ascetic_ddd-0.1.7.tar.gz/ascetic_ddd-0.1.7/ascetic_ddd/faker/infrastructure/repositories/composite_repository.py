import typing

from ascetic_ddd.faker.domain.providers.interfaces import IAggregateRepository
from ascetic_ddd.session.interfaces import ISession
from ascetic_ddd.faker.domain.specification.interfaces import ISpecification
from ascetic_ddd.faker.infrastructure.distributors.m2o.interfaces import IPgExternalSource
from ascetic_ddd.seedwork.domain.identity.interfaces import IAccessible
from ascetic_ddd.signals.interfaces import IAsyncSignal
from ascetic_ddd.faker.domain.providers.events import AggregateInsertedEvent, AggregateUpdatedEvent


__all__ = ('CompositeRepository', 'CompositeAutoPkRepository',)


T = typing.TypeVar("T")


class CompositeRepository(typing.Generic[T]):
    _external_repository: IAggregateRepository[T]
    _internal_repository: IAggregateRepository[T]

    def __init__(
            self,
            external_repository: IAggregateRepository[T],
            internal_repository: IAggregateRepository[T],
    ):
        self._external_repository = external_repository
        self._internal_repository = internal_repository

    @property
    def table(self) -> str:
        return self._internal_repository.table

    async def insert(self, session: ISession, agg: T):
        await self._internal_repository.insert(session, agg)  # Lock it first.
        await self._external_repository.insert(session, agg)

    async def update(self, session: ISession, agg: T):
        await self._internal_repository.update(session, agg)
        await self._external_repository.update(session, agg)

    async def get(self, session: ISession, id_: IAccessible[typing.Any]) -> T | None:
        return await self._internal_repository.get(session, id_)

    async def find(self, session: ISession, specification: ISpecification) -> typing.Iterable[T]:
        return await self._internal_repository.find(session, specification)

    async def setup(self, session: ISession):
        await self._internal_repository.setup(session)

    async def cleanup(self, session: ISession):
        await self._internal_repository.cleanup(session)

    # Signal delegation to internal_repository

    @property
    def on_inserted(self) -> IAsyncSignal[AggregateInsertedEvent[T]]:
        return self._internal_repository.on_inserted

    @property
    def on_updated(self) -> IAsyncSignal[AggregateUpdatedEvent[T]]:
        return self._internal_repository.on_updated


class CompositeAutoPkRepository(CompositeRepository[T], typing.Generic[T]):

    async def insert(self, session: ISession, agg: T):
        await self._external_repository.insert(session, agg)  # But ID can be undefined!
        await self._internal_repository.insert(session, agg)
