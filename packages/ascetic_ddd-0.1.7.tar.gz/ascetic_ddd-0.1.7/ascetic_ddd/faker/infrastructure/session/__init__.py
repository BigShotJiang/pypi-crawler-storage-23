from ascetic_ddd.faker.infrastructure.session.interfaces import IExternalPgSession, IInternalPgSession

__all__ = ('IExternalPgSession', 'IInternalPgSession')
