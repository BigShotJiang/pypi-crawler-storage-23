"""Lambda filter package for Specification Pattern."""
from ascetic_ddd.specification.domain.lambda_filter.lambda_parser import parse, LambdaParser

__all__ = ["parse", "LambdaParser"]
