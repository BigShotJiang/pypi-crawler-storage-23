from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from rossum_api.domain_logic.resources import Resource
from rossum_api.models.document_relation import DocumentRelation

from rossum_mcp.tools.base import build_filters, graceful_list

if TYPE_CHECKING:
    from fastmcp import FastMCP
    from rossum_api import AsyncRossumAPIClient

logger = logging.getLogger(__name__)


def register_document_relation_tools(mcp: FastMCP, client: AsyncRossumAPIClient) -> None:
    @mcp.tool(
        description="Retrieve document relation details.",
        tags={"document_relations"},
        annotations={"readOnlyHint": True},
    )
    async def get_document_relation(document_relation_id: int) -> DocumentRelation:
        logger.debug(f"Retrieving document relation: document_relation_id={document_relation_id}")
        document_relation: DocumentRelation = await client.retrieve_document_relation(document_relation_id)
        return document_relation

    @mcp.tool(
        description="List document relations with optional filters.; e.g. export/e-invoice links.",
        tags={"document_relations"},
        annotations={"readOnlyHint": True},
    )
    async def list_document_relations(
        id: int | None = None,
        type: str | None = None,
        annotation: int | None = None,
        key: str | None = None,
        documents: int | None = None,
    ) -> list[DocumentRelation]:
        logger.debug(
            f"Listing document relations: id={id}, type={type}, annotation={annotation}, key={key}, documents={documents}"
        )
        filters = build_filters(id=id, type=type, annotation=annotation, key=key, documents=documents)
        result = await graceful_list(client, Resource.DocumentRelation, "document_relation", **filters)
        return result.items
