from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, TypedDict


# ---- Flights ----


@dataclass
class Passengers:
    adults: int
    children: int | None = None
    infants: int | None = None


@dataclass
class SearchFlightsParams:
    origin: str
    destination: str
    departure_date: str
    passengers: Passengers
    return_date: str | None = None
    cabin_class: Literal["economy", "premium_economy", "business", "first"] | None = None


@dataclass
class FlightSegment:
    carrier: str | None = None
    flight_number: str | None = None
    aircraft: str | None = None
    cabin_class: str | None = None
    departing_at: str | None = None
    arriving_at: str | None = None
    origin: str | None = None
    destination: str | None = None


@dataclass
class FlightSlice:
    segments: list[FlightSegment] = field(default_factory=list)
    origin: str | None = None
    destination: str | None = None
    departing_at: str | None = None
    arriving_at: str | None = None
    duration: str | None = None
    stops: int | None = None


@dataclass
class FlightOffer:
    id: str
    slices: list[FlightSlice] = field(default_factory=list)
    passengers: list[dict[str, str]] = field(default_factory=list)
    airline: str | None = None
    total_amount: str | None = None
    currency: str | None = None
    expires_at: str | None = None


@dataclass
class SearchFlightsMeta:
    total_offers: int
    returned: int
    cabin_class: str | None = None


@dataclass
class SearchFlightsResult:
    offers: list[FlightOffer] = field(default_factory=list)
    meta: SearchFlightsMeta | None = None


@dataclass
class SearchLocationsParams:
    query: str
    limit: int | None = None


@dataclass
class GetOfferParams:
    offer_id: str
    include_services: bool | None = None
    include_seat_map: bool | None = None


# ---- Hotels ----


@dataclass
class SearchHotelsParams:
    latitude: float
    longitude: float
    check_in: str
    check_out: str
    guests: int | None = None
    rooms: int | None = None
    radius: int | None = None


@dataclass
class GetHotelQuoteParams:
    rate_id: str


# ---- Trips ----


@dataclass
class ListTripsParams:
    limit: int | None = None
    cursor: str | None = None


@dataclass
class CreateTripParams:
    selected_offer_id: str
    thread_id: str | None = None


@dataclass
class TravelerUpdate:
    first_name: str
    last_name: str
    email: str | None = None


@dataclass
class UpdateTripParams:
    trip_id: str
    name: str | None = None
    start_date: str | None = None
    end_date: str | None = None
    travelers: list[TravelerUpdate] | None = None
    notes: str | None = None


@dataclass
class CancelTripParams:
    trip_id: str
    reason: str | None = None


# ---- Booking ----


@dataclass
class TravelerInfo:
    given_name: str
    family_name: str
    born_on: str
    gender: Literal["m", "f"]
    email: str
    phone_number: str
    type: Literal["adult", "child", "infant_without_seat"] | None = None


@dataclass
class BookFlightParams:
    trip_id: str
    traveler_info: list[TravelerInfo] = field(default_factory=list)


@dataclass
class HotelGuest:
    given_name: str
    family_name: str
    email: str | None = None
    phone: str | None = None


@dataclass
class BookHotelParams:
    trip_id: str
    rate_id: str
    guests: list[HotelGuest] = field(default_factory=list)
    special_requests: str | None = None


# ---- Payments ----


@dataclass
class BaggageServiceId:
    id: str
    quantity: int


@dataclass
class AncillaryServices:
    seat_service_id: str | None = None
    baggage_service_ids: list[BaggageServiceId] | None = None
    cfar_service_id: str | None = None


@dataclass
class CreateCheckoutSessionParams:
    amount: str | int
    currency: str
    trip_id: str | None = None
    offer_id: str | None = None
    services: AncillaryServices | None = None
    success_url: str | None = None
    cancel_url: str | None = None


@dataclass
class PayWithSavedCardParams:
    amount: str | int
    currency: str
    payment_method_id: str
    trip_id: str | None = None
    offer_id: str | None = None
    services: AncillaryServices | None = None


@dataclass
class ManagePaymentMethodParams:
    payment_method_id: str
    action: Literal["delete", "set_default"]


# ---- Orders ----


@dataclass
class ServiceItem:
    id: str
    quantity: int


@dataclass
class OrderPayment:
    type: Literal["balance", "instant"]
    currency: str | None = None
    amount: str | None = None


@dataclass
class AddOrderServicesParams:
    order_id: str
    services: list[ServiceItem] = field(default_factory=list)
    payment: OrderPayment | None = None


@dataclass
class SliceToRemove:
    slice_id: str


@dataclass
class SliceToAdd:
    origin: str
    destination: str
    departure_date: str
    cabin_class: Literal["economy", "premium_economy", "business", "first"] | None = None


@dataclass
class ChangeSlices:
    remove: list[SliceToRemove] = field(default_factory=list)
    add: list[SliceToAdd] = field(default_factory=list)


@dataclass
class CreateChangeRequestParams:
    order_id: str
    slices: ChangeSlices | None = None


@dataclass
class ConfirmFlightChangeParams:
    change_offer_id: str
    payment: OrderPayment | None = None


# ---- Seatmap ----


@dataclass
class SeatPreferences:
    seat_type: Literal["window", "aisle", "middle"] | None = None
    extra_legroom: bool | None = None
    quiet_zone: bool | None = None
    front_of_cabin: bool | None = None
    near_exit: bool | None = None


@dataclass
class GetSeatInfoParams:
    airline_code: str
    aircraft_type: str
    type: Literal["layout", "best", "avoid"]
    cabin_class: Literal["economy", "premium_economy", "business", "first"] | None = None


@dataclass
class GetSeatRecommendationsParams:
    airline_code: str
    aircraft_type: str
    cabin_class: Literal["economy", "premium_economy", "business", "first"] | None = None
    preferences: SeatPreferences | None = None


# ---- Flight Tracking ----


@dataclass
class GetFlightInfoParams:
    flight_number: str
    type: Literal["status", "position"] | None = None
    date: str | None = None


# ---- Travel Info ----


@dataclass
class GetVisaParams:
    passport: str
    destination: str


@dataclass
class GetWeatherParams:
    type: Literal["current", "forecast"] | None = None
    lat: float | None = None
    lon: float | None = None
    location: str | None = None
    days: int | None = None


@dataclass
class ConvertCurrencyParams:
    from_currency: str
    to_currency: str
    amount: float | None = None


# ---- POIs ----


@dataclass
class FindPoisParams:
    lat: float
    lon: float
    query: str | None = None
    radius: int | None = None
    types: str | None = None
    limit: int | None = None


@dataclass
class GenerateItineraryParams:
    lat: float | None = None
    lon: float | None = None
    hotel_id: str | None = None
    date: str | None = None
    interests: list[str] | None = None
    pace: Literal["relaxed", "moderate", "packed"] | None = None
    budget: Literal["budget", "mid", "luxury"] | None = None
    start_time: str | None = None
    end_time: str | None = None


# ---- Claims ----

ClaimType = Literal["delay", "cancellation", "downgrade", "lost_baggage", "damaged_baggage"]


@dataclass
class CheckClaimEligibilityParams:
    booking_id: str
    claim_type: ClaimType


@dataclass
class FileClaimParams:
    booking_id: str
    claim_type: ClaimType
    description: str
    contact_email: str


@dataclass
class ListClaimsParams:
    status: Literal["pending", "in_review", "approved", "rejected", "paid"] | None = None
    limit: int | None = None
    cursor: str | None = None


# ---- Usage ----


@dataclass
class GetUsageParams:
    period: Literal["hour", "day", "week", "month"] | None = None
    endpoint: str | None = None
    api_key_id: str | None = None


# ---- Agent ----


@dataclass
class ChatWithAgentParams:
    thread_id: str
    message: str
    stream: bool | None = None


# ============================================================================
# Response types — TypedDicts matching the gateway's response whitelist.
# Methods that hit passthrough endpoints (allow: ['*']) return Any.
# ============================================================================


# ---- Generic wrapper ----


class ApiResponse(TypedDict):
    success: bool
    data: Any


# ---- Trip response types ----


class TripBooking(TypedDict, total=False):
    id: str
    type: str
    status: str
    bookingReference: str
    totalAmount: str
    baseAmount: str
    markupAmount: str
    currency: str
    paymentProvider: str


class TripDocument(TypedDict, total=False):
    id: str
    type: str
    name: str
    url: str
    filename: str
    createdAt: str


class PackingItem(TypedDict, total=False):
    id: str
    name: str
    isPacked: bool
    category: str
    aiGenerated: bool
    sortOrder: int


class SuggestedPlace(TypedDict, total=False):
    id: str
    name: str
    type: str
    description: str
    imageUrl: str
    latitude: float
    longitude: float
    address: str
    rating: float
    reviewCount: int
    isAdded: bool
    date: str
    price: str
    currency: str
    duration: str
    bookingUrl: str


class TripPaymentMethod(TypedDict, total=False):
    type: str
    brand: str
    last4: str
    expMonth: int
    expYear: int


class TripSummary(TypedDict, total=False):
    id: str
    name: str
    status: str
    tripStatus: str
    destination: str
    destinationCity: str
    destinationCountry: str
    startDate: str
    endDate: str
    destinationSummary: str
    dateRange: str
    coverPhotoUrl: str
    budgetTotal: str
    completeness: int
    createdAt: str
    updatedAt: str
    bookings: list[TripBooking]
    documents: list[TripDocument]
    packingItems: list[PackingItem]


class Trip(TypedDict, total=False):
    id: str
    name: str
    status: str
    tripStatus: str
    destination: str
    destinationCity: str
    destinationCountry: str
    startDate: str
    endDate: str
    destinationSummary: str
    dateRange: str
    coverPhotoUrl: str
    budgetTotal: str
    completeness: int
    createdAt: str
    updatedAt: str
    paymentMethod: TripPaymentMethod
    bookings: list[TripBooking]
    documents: list[TripDocument]
    packingItems: list[PackingItem]
    suggestedPlaces: list[SuggestedPlace]


class Pagination(TypedDict):
    hasMore: bool
    nextCursor: str | None
    limit: int


class ListTripsData(TypedDict):
    trips: list[TripSummary]
    pagination: Pagination


class ListTripsResponse(TypedDict):
    success: bool
    data: ListTripsData


class TripResponse(TypedDict):
    success: bool
    data: Trip


class UpdateTripData(TypedDict, total=False):
    id: str
    name: str
    status: str
    tripStatus: str
    budgetTotal: str
    completeness: int
    updatedAt: str


class UpdateTripResponse(TypedDict):
    success: bool
    data: UpdateTripData


class CancelTripRefund(TypedDict, total=False):
    refundId: str
    amount: str
    currency: str
    status: str


class CancelTripCancellation(TypedDict, total=False):
    bookingId: str
    bookingType: str
    refundAmount: str
    refundCurrency: str
    cancellationId: str


class CancelTripData(TypedDict, total=False):
    tripId: str
    status: str
    message: str
    errors: list[str]
    refund: CancelTripRefund
    cancellations: list[CancelTripCancellation]


class CancelTripResponse(TypedDict):
    success: bool
    data: CancelTripData


class TripDocumentsResponse(TypedDict):
    success: bool
    data: list[TripDocument]


# ---- Booking response types ----


class BookingResultBooking(TypedDict, total=False):
    id: str
    bookingReference: str
    totalAmount: str
    currency: str


class BookingResultDocument(TypedDict, total=False):
    id: str
    type: str
    filename: str


class BookingResultData(TypedDict, total=False):
    tripId: str
    status: str
    message: str
    code: str
    booking: BookingResultBooking
    documents: list[BookingResultDocument]


class BookingResultResponse(TypedDict):
    success: bool
    data: BookingResultData


# ---- Hotel booking response types ----


class HotelBookingData(TypedDict, total=False):
    id: str
    status: str
    confirmationCode: str
    hotel: str
    checkIn: str
    checkOut: str
    totalPrice: str
    currency: str


class HotelBookingResultData(TypedDict):
    booking: HotelBookingData


class HotelBookingResponse(TypedDict):
    success: bool
    data: HotelBookingResultData


# ---- Payment response types ----


class PricingBreakdown(TypedDict, total=False):
    baseAmount: str
    markupAmount: str
    totalAmount: str


class CheckoutSessionData(TypedDict, total=False):
    sessionUrl: str
    sessionId: str
    expiresAt: str
    pricingBreakdown: PricingBreakdown


class CheckoutSessionResponse(TypedDict):
    success: bool
    data: CheckoutSessionData


class PaymentMethodData(TypedDict, total=False):
    id: str
    brand: str
    last4: str
    expMonth: int
    expYear: int
    isDefault: bool


class PaymentMethodsResponse(TypedDict):
    success: bool
    data: list[PaymentMethodData]


class PaymentResultData(TypedDict, total=False):
    paymentIntentId: str
    status: str
    clientSecret: str
    amount: str
    currency: str
    pricingBreakdown: PricingBreakdown


class PaymentResultResponse(TypedDict):
    success: bool
    data: PaymentResultData


class PaymentStatusData(TypedDict, total=False):
    status: str
    amount: str
    currency: str
    createdAt: str


class PaymentStatusResponse(TypedDict):
    success: bool
    data: PaymentStatusData


# ---- Order response types ----


class CancellationQuoteData(TypedDict, total=False):
    id: str
    orderId: str
    refundAmount: str
    refundCurrency: str
    penaltyAmount: str
    penaltyCurrency: str
    expiresAt: str
    status: str


class CancellationQuoteResponse(TypedDict):
    success: bool
    data: CancellationQuoteData


class CancellationConfirmationData(TypedDict, total=False):
    id: str
    orderId: str
    status: str
    refundAmount: str
    refundCurrency: str
    confirmedAt: str


class CancellationConfirmationResponse(TypedDict):
    success: bool
    data: CancellationConfirmationData


class AddServicesData(TypedDict, total=False):
    id: str
    services: list[Any]
    totalAmount: str
    totalCurrency: str
    status: str


class AddServicesResponse(TypedDict):
    success: bool
    data: AddServicesData


class FlightChangeData(TypedDict, total=False):
    id: str
    orderId: str
    status: str
    changeTotalAmount: str
    changeTotalCurrency: str
    newOrderId: str
    confirmedAt: str


class FlightChangeResponse(TypedDict):
    success: bool
    data: FlightChangeData


# ---- POI response types ----


class PoiLocation(TypedDict, total=False):
    lat: float
    lng: float


class Poi(TypedDict, total=False):
    id: str
    name: str
    category: str
    location: PoiLocation
    rating: float
    photos: list[str]
    description: str
    openingHours: str
    priceLevel: int


class PoiSearchData(TypedDict):
    pois: list[Poi]


class PoiSearchResponse(TypedDict):
    success: bool
    data: PoiSearchData


# ---- Location response types ----


class LocationResult(TypedDict, total=False):
    id: str
    name: str
    iata_code: str
    type: str
    city_name: str
    country: str


class LocationsResponse(TypedDict):
    success: bool
    data: list[LocationResult]


# ---- Agent response types ----


class AgentMessageData(TypedDict, total=False):
    role: str
    content: str
    type: str


class AgentMessageResponse(TypedDict):
    success: bool
    data: AgentMessageData


class AgentStreamMessageEvent(TypedDict):
    type: Literal["message"]
    content: str


class AgentStreamToolCallEvent(TypedDict, total=False):
    type: Literal["tool_call"]
    name: str
    arguments: str


class AgentStreamDoneEvent(TypedDict):
    type: Literal["done"]


AgentStreamEvent = AgentStreamMessageEvent | AgentStreamToolCallEvent | AgentStreamDoneEvent
