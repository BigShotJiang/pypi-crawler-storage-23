from __future__ import annotations

import dataclasses
import os
import time
from typing import Any


def generate_idempotency_key() -> str:
    return f"idem_{int(time.time() * 1000)}_{os.urandom(8).hex()}"


def _strip_none(d: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in d.items():
        if v is None:
            continue
        if isinstance(v, dict):
            v = _strip_none(v)
        elif isinstance(v, list):
            v = [_strip_none(i) if isinstance(i, dict) else i for i in v]
        out[k] = v
    return out


def _snake_to_camel(name: str) -> str:
    parts = name.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


def _to_api_dict(obj: Any) -> dict[str, Any]:
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        raw = dataclasses.asdict(obj)
    elif isinstance(obj, dict):
        raw = obj
    else:
        return obj
    converted: dict[str, Any] = {}
    for k, v in raw.items():
        camel = _snake_to_camel(k)
        if isinstance(v, dict):
            v = {_snake_to_camel(dk): dv for dk, dv in v.items() if dv is not None}
        elif isinstance(v, list):
            v = [
                _to_api_dict(i) if (isinstance(i, dict) or dataclasses.is_dataclass(i)) else i
                for i in v
            ]
        converted[camel] = v
    return _strip_none(converted)
