from __future__ import annotations

import asyncio
import dataclasses
import json
import time
from collections.abc import AsyncIterator, Iterator
from typing import Any
from urllib.parse import quote

import httpx

from ._errors import NowahError
from ._types import (
    AddOrderServicesParams,
    BookFlightParams,
    BookHotelParams,
    CancelTripParams,
    ChatWithAgentParams,
    CheckClaimEligibilityParams,
    ConfirmFlightChangeParams,
    ConvertCurrencyParams,
    CreateChangeRequestParams,
    CreateCheckoutSessionParams,
    CreateTripParams,
    FileClaimParams,
    FindPoisParams,
    GenerateItineraryParams,
    GetFlightInfoParams,
    GetHotelQuoteParams,
    GetOfferParams,
    GetSeatInfoParams,
    GetSeatRecommendationsParams,
    GetUsageParams,
    GetVisaParams,
    GetWeatherParams,
    ListClaimsParams,
    ListTripsParams,
    ManagePaymentMethodParams,
    PayWithSavedCardParams,
    SearchFlightsParams,
    SearchFlightsResult,
    SearchHotelsParams,
    SearchLocationsParams,
    UpdateTripParams,
    # Response types
    AgentMessageResponse,
    AgentStreamEvent,
    AddServicesResponse,
    BookingResultResponse,
    CancelTripResponse,
    CancellationConfirmationResponse,
    CancellationQuoteResponse,
    CheckoutSessionResponse,
    FlightChangeResponse,
    HotelBookingResponse,
    ListTripsResponse,
    LocationsResponse,
    PaymentMethodsResponse,
    PaymentResultResponse,
    PaymentStatusResponse,
    PoiSearchResponse,
    TripDocumentsResponse,
    TripResponse,
    UpdateTripResponse,
)
from ._utils import _strip_none, _to_api_dict, generate_idempotency_key

DEFAULT_BASE_URL = "https://claw.nowah.xyz"
MAX_RETRIES = 1
RETRY_BASE_MS = 1000


def _enc(val: str) -> str:
    return quote(val, safe="")


def _query(params: dict[str, Any]) -> dict[str, str]:
    return {k: str(v) for k, v in params.items() if v is not None and v != ""}


def _parse_sse_part(part: str) -> Iterator[AgentStreamEvent]:
    """Parse a single SSE chunk and yield typed events."""
    for line in part.split("\n"):
        if not line.startswith("data: "):
            continue
        payload = line[6:]  # strip "data: "
        if payload == "[DONE]":
            yield {"type": "done"}
            return
        try:
            parsed = json.loads(payload)
            if parsed.get("type") == "tool_call":
                event: AgentStreamEvent = {"type": "tool_call", "name": parsed.get("name", "")}
                if "arguments" in parsed:
                    event["arguments"] = parsed["arguments"]  # type: ignore[typeddict-unknown-key]
                yield event
            else:
                yield {"type": "message", "content": parsed.get("content") or parsed.get("text") or payload}
        except (json.JSONDecodeError, TypeError):
            yield {"type": "message", "content": payload}


def _handle_response(response: httpx.Response) -> Any:
    text = response.text
    if not response.is_success:
        raise NowahError(response.status_code, text)
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return text


# ---------------------------------------------------------------------------
# Sync client
# ---------------------------------------------------------------------------


class NowahClient:
    """Synchronous client for the Nowah Travel API."""

    def __init__(self, api_key: str, *, base_url: str | None = None) -> None:
        self._api_key = api_key
        self._base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    # -- context manager --

    def __enter__(self) -> NowahClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    # -- HTTP primitives --

    def _request_with_retry(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> Any:
        last_error: Exception | None = None
        for attempt in range(MAX_RETRIES + 1):
            try:
                response = self._client.request(
                    method,
                    path,
                    params=params,
                    content=json.dumps(json_body).encode() if json_body is not None else None,
                    headers=extra_headers,
                    timeout=timeout,
                )
                if response.is_success or (400 <= response.status_code < 500):
                    return _handle_response(response)
                # 5xx — retry
                if attempt < MAX_RETRIES:
                    time.sleep(RETRY_BASE_MS / 1000 * (2**attempt))
                    continue
                return _handle_response(response)
            except NowahError:
                raise
            except httpx.TimeoutException:
                last_error = NowahError(
                    0, json.dumps({"error": "Request timed out", "code": "TIMEOUT"})
                )
                if attempt < MAX_RETRIES:
                    time.sleep(RETRY_BASE_MS / 1000 * (2**attempt))
                    continue
            except Exception as exc:
                last_error = NowahError(
                    0,
                    json.dumps({"error": str(exc), "code": "NETWORK_ERROR"}),
                )
                if attempt < MAX_RETRIES:
                    time.sleep(RETRY_BASE_MS / 1000 * (2**attempt))
                    continue
        raise last_error  # type: ignore[misc]

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        return self._request_with_retry("GET", path, params=_query(params) if params else None)

    def _post(
        self,
        path: str,
        body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> Any:
        return self._request_with_retry("POST", path, json_body=body, extra_headers=extra_headers)

    def _patch(self, path: str, body: dict[str, Any] | None = None) -> Any:
        return self._request_with_retry("PATCH", path, json_body=body)

    def _put(self, path: str, body: dict[str, Any] | None = None) -> Any:
        return self._request_with_retry("PUT", path, json_body=body)

    def _delete(self, path: str) -> Any:
        return self._request_with_retry("DELETE", path)

    def _post_streaming(self, path: str, body: dict[str, Any]) -> str:
        result = ""
        try:
            with self._client.stream(
                "POST", path, content=json.dumps(body).encode(), timeout=120.0
            ) as response:
                if not response.is_success:
                    text = response.read().decode()
                    raise NowahError(response.status_code, text)
                for chunk in response.iter_text():
                    result += chunk
        except NowahError:
            raise
        except httpx.TimeoutException:
            raise NowahError(0, json.dumps({"error": "Request timed out", "code": "TIMEOUT"}))
        except Exception as exc:
            raise NowahError(0, json.dumps({"error": str(exc), "code": "NETWORK_ERROR"}))
        return result

    # ---- Flights ----

    def search_flights(self, params: SearchFlightsParams) -> SearchFlightsResult:
        data = self._post("/v1/flights/search", _to_api_dict(params))
        return data  # type: ignore[return-value]

    def search_locations(self, query: str, *, limit: int | None = None) -> LocationsResponse:
        return self._get("/v1/locations/search", {"q": query, "limit": limit})

    def get_offer(self, params: GetOfferParams) -> Any:
        oid = _enc(params.offer_id)
        if params.include_seat_map:
            return self._get(f"/v1/flights/offers/{oid}/full")
        return self._get(f"/v1/flights/offers/{oid}")

    def get_offer_services(self, offer_id: str) -> Any:
        return self._get(f"/v1/flights/offers/{_enc(offer_id)}/services")

    # ---- Hotels ----

    def search_hotels(self, params: SearchHotelsParams) -> Any:
        return self._get("/v1/hotels/search", _to_api_dict(params))

    def get_hotel_quote(self, rate_id: str) -> Any:
        return self._get(f"/v1/hotels/quote/{_enc(rate_id)}")

    # ---- Trips ----

    def list_trips(self, *, limit: int | None = None, cursor: str | None = None) -> ListTripsResponse:
        return self._get("/v1/trips", {"limit": limit, "cursor": cursor})

    def get_trip(self, trip_id: str) -> TripResponse:
        return self._get(f"/v1/trips/{_enc(trip_id)}")

    def create_trip(self, params: CreateTripParams) -> TripResponse:
        return self._post("/v1/trips", {
            "selectedOfferId": params.selected_offer_id,
            "threadId": params.thread_id or f"sdk_{int(time.time() * 1000)}",
        })

    def update_trip(self, params: UpdateTripParams) -> UpdateTripResponse:
        body = _to_api_dict(params)
        body.pop("tripId", None)
        return self._patch(f"/v1/trips/{_enc(params.trip_id)}", body)

    def cancel_trip(self, params: CancelTripParams) -> CancelTripResponse:
        return self._post(f"/v1/trips/{_enc(params.trip_id)}/cancel", {"reason": params.reason})

    def get_trip_documents(self, trip_id: str) -> TripDocumentsResponse:
        return self._get(f"/v1/trips/{_enc(trip_id)}/documents")

    # ---- Booking ----

    def book_flight(self, params: BookFlightParams) -> BookingResultResponse:
        key = generate_idempotency_key()
        travelers = []
        for t in params.traveler_info:
            d = _to_api_dict(t)
            d["title"] = "ms" if t.gender == "f" else "mr"
            travelers.append(d)
        return self._post(
            f"/v1/booking/flights/{_enc(params.trip_id)}",
            {"travelerInfo": travelers},
            extra_headers={"X-Idempotency-Key": key},
        )

    def get_booking_fees(self) -> Any:
        return self._get("/v1/booking/fees")

    def book_hotel(self, params: BookHotelParams) -> HotelBookingResponse:
        key = generate_idempotency_key()
        return self._post(
            f"/v1/booking/hotels/{_enc(params.trip_id)}",
            _strip_none({
                "rateId": params.rate_id,
                "guests": [_to_api_dict(g) for g in params.guests],
                "specialRequests": params.special_requests,
            }),
            extra_headers={"X-Idempotency-Key": key},
        )

    # ---- Payments ----

    def create_checkout_session(self, params: CreateCheckoutSessionParams) -> CheckoutSessionResponse:
        return self._post("/v1/payments/checkout-session", _to_api_dict(params))

    def list_payment_methods(self) -> PaymentMethodsResponse:
        return self._get("/v1/payments/methods")

    def pay_with_saved_card(self, params: PayWithSavedCardParams) -> PaymentResultResponse:
        return self._post("/v1/payments/pay-with-saved-card", _to_api_dict(params))

    def get_payment_status(self, payment_intent_id: str) -> PaymentStatusResponse:
        return self._get(f"/v1/payments/status/{_enc(payment_intent_id)}")

    def manage_payment_method(self, params: ManagePaymentMethodParams) -> Any:
        pid = _enc(params.payment_method_id)
        if params.action == "delete":
            return self._delete(f"/v1/payments/methods/{pid}")
        return self._put(f"/v1/payments/methods/{pid}/default")

    # ---- Orders ----

    def get_cancellation_quote(self, order_id: str) -> CancellationQuoteResponse:
        return self._post(f"/v1/orders/{_enc(order_id)}/cancel-quote")

    def confirm_cancellation(self, cancellation_id: str) -> CancellationConfirmationResponse:
        key = generate_idempotency_key()
        return self._post(
            f"/v1/orders/cancel/{_enc(cancellation_id)}/confirm",
            {},
            extra_headers={"X-Idempotency-Key": key},
        )

    def get_order_services(self, order_id: str) -> Any:
        return self._get(f"/v1/orders/{_enc(order_id)}/services")

    def add_order_services(self, params: AddOrderServicesParams) -> AddServicesResponse:
        key = generate_idempotency_key()
        return self._post(
            f"/v1/orders/{_enc(params.order_id)}/services/add",
            _strip_none({
                "services": [_to_api_dict(s) for s in params.services],
                "payment": _to_api_dict(params.payment) if params.payment else None,
            }),
            extra_headers={"X-Idempotency-Key": key},
        )

    def create_change_request(self, params: CreateChangeRequestParams) -> Any:
        return self._post(
            f"/v1/orders/{_enc(params.order_id)}/change-request",
            {"slices": _to_api_dict(params.slices) if params.slices else {}},
        )

    def confirm_flight_change(self, params: ConfirmFlightChangeParams) -> FlightChangeResponse:
        key = generate_idempotency_key()
        return self._post(
            f"/v1/orders/change-offers/{_enc(params.change_offer_id)}/confirm",
            {"payment": _to_api_dict(params.payment) if params.payment else {}},
            extra_headers={"X-Idempotency-Key": key},
        )

    # ---- Seatmap ----

    def get_seat_info(self, params: GetSeatInfoParams) -> Any:
        airline = _enc(params.airline_code)
        aircraft = _enc(params.aircraft_type)
        if params.type == "layout":
            return self._get(f"/v1/seatmap/configuration/{airline}/{aircraft}")
        segment = "best-seats" if params.type == "best" else "avoid"
        return self._get(
            f"/v1/seatmap/{segment}/{airline}/{aircraft}",
            {"cabinClass": params.cabin_class},
        )

    def get_seat_recommendations(self, params: GetSeatRecommendationsParams) -> Any:
        return self._post("/v1/seatmap/recommendations", _to_api_dict(params))

    # ---- Flight Tracking ----

    def get_flight_info(self, params: GetFlightInfoParams) -> Any:
        segment = "position" if params.type == "position" else "status"
        return self._get(
            f"/v1/flight-tracking/{_enc(params.flight_number)}/{segment}",
            {"date": params.date},
        )

    def get_booking_tracking(self, booking_id: str) -> Any:
        return self._get(f"/v1/flight-tracking/bookings/{_enc(booking_id)}")

    def get_airport_delays(self, airport_code: str) -> Any:
        return self._get(f"/v1/flight-tracking/airports/{_enc(airport_code)}/delays")

    # ---- Travel Info ----

    def get_visa_requirements(self, passport: str, destination: str) -> Any:
        return self._get(f"/v1/visa/{passport}/{destination}")

    def get_weather(self, params: GetWeatherParams) -> Any:
        endpoint = "/v1/weather/current" if params.type == "current" else "/v1/weather/forecast"
        return self._get(endpoint, {
            "lat": params.lat,
            "lon": params.lon,
            "location": params.location,
            "days": params.days if params.type != "current" else None,
        })

    def convert_currency(self, params: ConvertCurrencyParams) -> Any:
        if params.amount is not None:
            return self._get("/v1/currency/convert", {
                "from": params.from_currency,
                "to": params.to_currency,
                "amount": params.amount,
            })
        return self._get(f"/v1/currency/rates/{params.from_currency}/{params.to_currency}")

    def get_safety_info(self, country: str) -> Any:
        return self._get(f"/v1/safety/{country}")

    # ---- POIs ----

    def find_pois(self, params: FindPoisParams) -> PoiSearchResponse:
        if params.query:
            return self._get("/v1/pois/search", {
                "q": params.query,
                "lat": params.lat,
                "lon": params.lon,
                "types": params.types,
                "limit": params.limit,
            })
        return self._get("/v1/pois/nearby", {
            "lat": params.lat,
            "lon": params.lon,
            "radius": params.radius,
            "types": params.types,
            "limit": params.limit,
        })

    def generate_itinerary(self, params: GenerateItineraryParams) -> Any:
        return self._post("/v1/itinerary/generate", _to_api_dict(params))

    # ---- Claims ----

    def check_claim_eligibility(self, params: CheckClaimEligibilityParams) -> Any:
        return self._post("/v1/claims/eligibility", _to_api_dict(params))

    def file_claim(self, params: FileClaimParams) -> Any:
        return self._post("/v1/claims", _to_api_dict(params))

    def list_claims(
        self,
        *,
        status: str | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> Any:
        return self._get("/v1/claims", {"status": status, "limit": limit, "cursor": cursor})

    # ---- Usage ----

    def get_usage_stats(
        self,
        *,
        period: str | None = None,
        endpoint: str | None = None,
        api_key_id: str | None = None,
    ) -> Any:
        return self._get("/v1/usage", {
            "period": period,
            "endpoint": endpoint,
            "apiKeyId": api_key_id,
        })

    # ---- Agent ----

    def chat_with_agent(self, params: ChatWithAgentParams) -> AgentMessageResponse | str:
        if params.stream:
            return self._post_streaming("/v1/agent/chat", {
                "threadId": params.thread_id,
                "message": params.message,
                "stream": True,
            })
        return self._post("/v1/agent/chat", {
            "threadId": params.thread_id,
            "message": params.message,
            "stream": False,
        })

    def chat_with_agent_stream(
        self, *, thread_id: str, message: str
    ) -> Iterator[AgentStreamEvent]:
        """Stream agent chat responses as an iterator of typed events.

        Usage::

            for event in client.chat_with_agent_stream(thread_id=tid, message="Hello"):
                if event["type"] == "message":
                    print(event["content"], end="")
        """
        try:
            with self._client.stream(
                "POST",
                "/v1/agent/chat",
                content=json.dumps({"threadId": thread_id, "message": message, "stream": True}).encode(),
                timeout=120.0,
            ) as response:
                if not response.is_success:
                    text = response.read().decode()
                    raise NowahError(response.status_code, text)

                buffer = ""
                for chunk in response.iter_text():
                    buffer += chunk
                    parts = buffer.split("\n\n")
                    buffer = parts.pop()

                    for part in parts:
                        yield from _parse_sse_part(part)

                # Flush remaining buffer
                if buffer.strip():
                    yield from _parse_sse_part(buffer)
        except NowahError:
            raise
        except httpx.TimeoutException:
            raise NowahError(0, json.dumps({"error": "Request timed out", "code": "TIMEOUT"}))
        except Exception as exc:
            raise NowahError(0, json.dumps({"error": str(exc), "code": "NETWORK_ERROR"}))


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------


class AsyncNowahClient:
    """Asynchronous client for the Nowah Travel API."""

    def __init__(self, api_key: str, *, base_url: str | None = None) -> None:
        self._api_key = api_key
        self._base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    # -- context manager --

    async def __aenter__(self) -> AsyncNowahClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def close(self) -> None:
        await self._client.aclose()

    # -- HTTP primitives --

    async def _request_with_retry(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> Any:
        last_error: Exception | None = None
        for attempt in range(MAX_RETRIES + 1):
            try:
                response = await self._client.request(
                    method,
                    path,
                    params=params,
                    content=json.dumps(json_body).encode() if json_body is not None else None,
                    headers=extra_headers,
                    timeout=timeout,
                )
                if response.is_success or (400 <= response.status_code < 500):
                    return _handle_response(response)
                if attempt < MAX_RETRIES:
                    await asyncio.sleep(RETRY_BASE_MS / 1000 * (2**attempt))
                    continue
                return _handle_response(response)
            except NowahError:
                raise
            except httpx.TimeoutException:
                last_error = NowahError(
                    0, json.dumps({"error": "Request timed out", "code": "TIMEOUT"})
                )
                if attempt < MAX_RETRIES:
                    await asyncio.sleep(RETRY_BASE_MS / 1000 * (2**attempt))
                    continue
            except Exception as exc:
                last_error = NowahError(
                    0,
                    json.dumps({"error": str(exc), "code": "NETWORK_ERROR"}),
                )
                if attempt < MAX_RETRIES:
                    await asyncio.sleep(RETRY_BASE_MS / 1000 * (2**attempt))
                    continue
        raise last_error  # type: ignore[misc]

    async def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        return await self._request_with_retry(
            "GET", path, params=_query(params) if params else None
        )

    async def _post(
        self,
        path: str,
        body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> Any:
        return await self._request_with_retry(
            "POST", path, json_body=body, extra_headers=extra_headers
        )

    async def _patch(self, path: str, body: dict[str, Any] | None = None) -> Any:
        return await self._request_with_retry("PATCH", path, json_body=body)

    async def _put(self, path: str, body: dict[str, Any] | None = None) -> Any:
        return await self._request_with_retry("PUT", path, json_body=body)

    async def _delete(self, path: str) -> Any:
        return await self._request_with_retry("DELETE", path)

    async def _post_streaming(self, path: str, body: dict[str, Any]) -> str:
        result = ""
        try:
            async with self._client.stream(
                "POST", path, content=json.dumps(body).encode(), timeout=120.0
            ) as response:
                if not response.is_success:
                    text = (await response.aread()).decode()
                    raise NowahError(response.status_code, text)
                async for chunk in response.aiter_text():
                    result += chunk
        except NowahError:
            raise
        except httpx.TimeoutException:
            raise NowahError(0, json.dumps({"error": "Request timed out", "code": "TIMEOUT"}))
        except Exception as exc:
            raise NowahError(0, json.dumps({"error": str(exc), "code": "NETWORK_ERROR"}))
        return result

    # ---- Flights ----

    async def search_flights(self, params: SearchFlightsParams) -> SearchFlightsResult:
        data = await self._post("/v1/flights/search", _to_api_dict(params))
        return data  # type: ignore[return-value]

    async def search_locations(self, query: str, *, limit: int | None = None) -> LocationsResponse:
        return await self._get("/v1/locations/search", {"q": query, "limit": limit})

    async def get_offer(self, params: GetOfferParams) -> Any:
        oid = _enc(params.offer_id)
        if params.include_seat_map:
            return await self._get(f"/v1/flights/offers/{oid}/full")
        return await self._get(f"/v1/flights/offers/{oid}")

    async def get_offer_services(self, offer_id: str) -> Any:
        return await self._get(f"/v1/flights/offers/{_enc(offer_id)}/services")

    # ---- Hotels ----

    async def search_hotels(self, params: SearchHotelsParams) -> Any:
        return await self._get("/v1/hotels/search", _to_api_dict(params))

    async def get_hotel_quote(self, rate_id: str) -> Any:
        return await self._get(f"/v1/hotels/quote/{_enc(rate_id)}")

    # ---- Trips ----

    async def list_trips(self, *, limit: int | None = None, cursor: str | None = None) -> ListTripsResponse:
        return await self._get("/v1/trips", {"limit": limit, "cursor": cursor})

    async def get_trip(self, trip_id: str) -> TripResponse:
        return await self._get(f"/v1/trips/{_enc(trip_id)}")

    async def create_trip(self, params: CreateTripParams) -> TripResponse:
        return await self._post("/v1/trips", {
            "selectedOfferId": params.selected_offer_id,
            "threadId": params.thread_id or f"sdk_{int(time.time() * 1000)}",
        })

    async def update_trip(self, params: UpdateTripParams) -> UpdateTripResponse:
        body = _to_api_dict(params)
        body.pop("tripId", None)
        return await self._patch(f"/v1/trips/{_enc(params.trip_id)}", body)

    async def cancel_trip(self, params: CancelTripParams) -> CancelTripResponse:
        return await self._post(
            f"/v1/trips/{_enc(params.trip_id)}/cancel", {"reason": params.reason}
        )

    async def get_trip_documents(self, trip_id: str) -> TripDocumentsResponse:
        return await self._get(f"/v1/trips/{_enc(trip_id)}/documents")

    # ---- Booking ----

    async def book_flight(self, params: BookFlightParams) -> BookingResultResponse:
        key = generate_idempotency_key()
        travelers = []
        for t in params.traveler_info:
            d = _to_api_dict(t)
            d["title"] = "ms" if t.gender == "f" else "mr"
            travelers.append(d)
        return await self._post(
            f"/v1/booking/flights/{_enc(params.trip_id)}",
            {"travelerInfo": travelers},
            extra_headers={"X-Idempotency-Key": key},
        )

    async def get_booking_fees(self) -> Any:
        return await self._get("/v1/booking/fees")

    async def book_hotel(self, params: BookHotelParams) -> HotelBookingResponse:
        key = generate_idempotency_key()
        return await self._post(
            f"/v1/booking/hotels/{_enc(params.trip_id)}",
            _strip_none({
                "rateId": params.rate_id,
                "guests": [_to_api_dict(g) for g in params.guests],
                "specialRequests": params.special_requests,
            }),
            extra_headers={"X-Idempotency-Key": key},
        )

    # ---- Payments ----

    async def create_checkout_session(self, params: CreateCheckoutSessionParams) -> CheckoutSessionResponse:
        return await self._post("/v1/payments/checkout-session", _to_api_dict(params))

    async def list_payment_methods(self) -> PaymentMethodsResponse:
        return await self._get("/v1/payments/methods")

    async def pay_with_saved_card(self, params: PayWithSavedCardParams) -> PaymentResultResponse:
        return await self._post("/v1/payments/pay-with-saved-card", _to_api_dict(params))

    async def get_payment_status(self, payment_intent_id: str) -> PaymentStatusResponse:
        return await self._get(f"/v1/payments/status/{_enc(payment_intent_id)}")

    async def manage_payment_method(self, params: ManagePaymentMethodParams) -> Any:
        pid = _enc(params.payment_method_id)
        if params.action == "delete":
            return await self._delete(f"/v1/payments/methods/{pid}")
        return await self._put(f"/v1/payments/methods/{pid}/default")

    # ---- Orders ----

    async def get_cancellation_quote(self, order_id: str) -> CancellationQuoteResponse:
        return await self._post(f"/v1/orders/{_enc(order_id)}/cancel-quote")

    async def confirm_cancellation(self, cancellation_id: str) -> CancellationConfirmationResponse:
        key = generate_idempotency_key()
        return await self._post(
            f"/v1/orders/cancel/{_enc(cancellation_id)}/confirm",
            {},
            extra_headers={"X-Idempotency-Key": key},
        )

    async def get_order_services(self, order_id: str) -> Any:
        return await self._get(f"/v1/orders/{_enc(order_id)}/services")

    async def add_order_services(self, params: AddOrderServicesParams) -> AddServicesResponse:
        key = generate_idempotency_key()
        return await self._post(
            f"/v1/orders/{_enc(params.order_id)}/services/add",
            _strip_none({
                "services": [_to_api_dict(s) for s in params.services],
                "payment": _to_api_dict(params.payment) if params.payment else None,
            }),
            extra_headers={"X-Idempotency-Key": key},
        )

    async def create_change_request(self, params: CreateChangeRequestParams) -> Any:
        return await self._post(
            f"/v1/orders/{_enc(params.order_id)}/change-request",
            {"slices": _to_api_dict(params.slices) if params.slices else {}},
        )

    async def confirm_flight_change(self, params: ConfirmFlightChangeParams) -> FlightChangeResponse:
        key = generate_idempotency_key()
        return await self._post(
            f"/v1/orders/change-offers/{_enc(params.change_offer_id)}/confirm",
            {"payment": _to_api_dict(params.payment) if params.payment else {}},
            extra_headers={"X-Idempotency-Key": key},
        )

    # ---- Seatmap ----

    async def get_seat_info(self, params: GetSeatInfoParams) -> Any:
        airline = _enc(params.airline_code)
        aircraft = _enc(params.aircraft_type)
        if params.type == "layout":
            return await self._get(f"/v1/seatmap/configuration/{airline}/{aircraft}")
        segment = "best-seats" if params.type == "best" else "avoid"
        return await self._get(
            f"/v1/seatmap/{segment}/{airline}/{aircraft}",
            {"cabinClass": params.cabin_class},
        )

    async def get_seat_recommendations(self, params: GetSeatRecommendationsParams) -> Any:
        return await self._post("/v1/seatmap/recommendations", _to_api_dict(params))

    # ---- Flight Tracking ----

    async def get_flight_info(self, params: GetFlightInfoParams) -> Any:
        segment = "position" if params.type == "position" else "status"
        return await self._get(
            f"/v1/flight-tracking/{_enc(params.flight_number)}/{segment}",
            {"date": params.date},
        )

    async def get_booking_tracking(self, booking_id: str) -> Any:
        return await self._get(f"/v1/flight-tracking/bookings/{_enc(booking_id)}")

    async def get_airport_delays(self, airport_code: str) -> Any:
        return await self._get(f"/v1/flight-tracking/airports/{_enc(airport_code)}/delays")

    # ---- Travel Info ----

    async def get_visa_requirements(self, passport: str, destination: str) -> Any:
        return await self._get(f"/v1/visa/{passport}/{destination}")

    async def get_weather(self, params: GetWeatherParams) -> Any:
        endpoint = "/v1/weather/current" if params.type == "current" else "/v1/weather/forecast"
        return await self._get(endpoint, {
            "lat": params.lat,
            "lon": params.lon,
            "location": params.location,
            "days": params.days if params.type != "current" else None,
        })

    async def convert_currency(self, params: ConvertCurrencyParams) -> Any:
        if params.amount is not None:
            return await self._get("/v1/currency/convert", {
                "from": params.from_currency,
                "to": params.to_currency,
                "amount": params.amount,
            })
        return await self._get(
            f"/v1/currency/rates/{params.from_currency}/{params.to_currency}"
        )

    async def get_safety_info(self, country: str) -> Any:
        return await self._get(f"/v1/safety/{country}")

    # ---- POIs ----

    async def find_pois(self, params: FindPoisParams) -> PoiSearchResponse:
        if params.query:
            return await self._get("/v1/pois/search", {
                "q": params.query,
                "lat": params.lat,
                "lon": params.lon,
                "types": params.types,
                "limit": params.limit,
            })
        return await self._get("/v1/pois/nearby", {
            "lat": params.lat,
            "lon": params.lon,
            "radius": params.radius,
            "types": params.types,
            "limit": params.limit,
        })

    async def generate_itinerary(self, params: GenerateItineraryParams) -> Any:
        return await self._post("/v1/itinerary/generate", _to_api_dict(params))

    # ---- Claims ----

    async def check_claim_eligibility(self, params: CheckClaimEligibilityParams) -> Any:
        return await self._post("/v1/claims/eligibility", _to_api_dict(params))

    async def file_claim(self, params: FileClaimParams) -> Any:
        return await self._post("/v1/claims", _to_api_dict(params))

    async def list_claims(
        self,
        *,
        status: str | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> Any:
        return await self._get(
            "/v1/claims", {"status": status, "limit": limit, "cursor": cursor}
        )

    # ---- Usage ----

    async def get_usage_stats(
        self,
        *,
        period: str | None = None,
        endpoint: str | None = None,
        api_key_id: str | None = None,
    ) -> Any:
        return await self._get("/v1/usage", {
            "period": period,
            "endpoint": endpoint,
            "apiKeyId": api_key_id,
        })

    # ---- Agent ----

    async def chat_with_agent(self, params: ChatWithAgentParams) -> AgentMessageResponse | str:
        if params.stream:
            return await self._post_streaming("/v1/agent/chat", {
                "threadId": params.thread_id,
                "message": params.message,
                "stream": True,
            })
        return await self._post("/v1/agent/chat", {
            "threadId": params.thread_id,
            "message": params.message,
            "stream": False,
        })

    async def chat_with_agent_stream(
        self, *, thread_id: str, message: str
    ) -> AsyncIterator[AgentStreamEvent]:
        """Stream agent chat responses as an async iterator of typed events.

        Usage::

            async for event in await client.chat_with_agent_stream(
                thread_id=tid, message="Hello"
            ):
                if event["type"] == "message":
                    print(event["content"], end="")
        """
        try:
            async with self._client.stream(
                "POST",
                "/v1/agent/chat",
                content=json.dumps({"threadId": thread_id, "message": message, "stream": True}).encode(),
                timeout=120.0,
            ) as response:
                if not response.is_success:
                    text = (await response.aread()).decode()
                    raise NowahError(response.status_code, text)

                buffer = ""
                async for chunk in response.aiter_text():
                    buffer += chunk
                    parts = buffer.split("\n\n")
                    buffer = parts.pop()

                    for part in parts:
                        for event in _parse_sse_part(part):
                            yield event

                # Flush remaining buffer
                if buffer.strip():
                    for event in _parse_sse_part(buffer):
                        yield event
        except NowahError:
            raise
        except httpx.TimeoutException:
            raise NowahError(0, json.dumps({"error": "Request timed out", "code": "TIMEOUT"}))
        except Exception as exc:
            raise NowahError(0, json.dumps({"error": str(exc), "code": "NETWORK_ERROR"}))
