from __future__ import annotations

import json


class NowahError(Exception):
    status: int
    code: str
    retryable: bool

    def __init__(self, status: int, body: str) -> None:
        try:
            parsed = json.loads(body)
        except (json.JSONDecodeError, TypeError):
            parsed = {"error": body}

        err = parsed.get("error", "")
        if isinstance(err, dict):
            message = err.get("message") or json.dumps(err)
            self.code = err.get("code", "UNKNOWN")
        else:
            message = err or parsed.get("message") or f"HTTP {status}"
            self.code = parsed.get("code", "UNKNOWN")

        super().__init__(message)
        self.status = status
        self.retryable = status >= 500
