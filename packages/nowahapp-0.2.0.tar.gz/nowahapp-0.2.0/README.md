# Nowah Python SDK

Official Python SDK for the [Nowah Travel API](https://docs.nowah.xyz).

## Installation

```bash
pip install nowahapp
```

Requires Python 3.9+.

## Quick Start

### Synchronous

```python
from nowah import NowahClient, SearchFlightsParams, Passengers

client = NowahClient("nwh_your_api_key")

results = client.search_flights(SearchFlightsParams(
    origin="JFK",
    destination="LHR",
    departure_date="2026-06-15",
    passengers=Passengers(adults=1),
    cabin_class="economy",
))

for offer in results["offers"]:
    print(f"{offer['airline']} — {offer['totalAmount']} {offer['currency']}")

client.close()
```

### Async

```python
import asyncio
from nowah import AsyncNowahClient, SearchFlightsParams, Passengers

async def main():
    async with AsyncNowahClient("nwh_your_api_key") as client:
        results = await client.search_flights(SearchFlightsParams(
            origin="JFK",
            destination="LHR",
            departure_date="2026-06-15",
            passengers=Passengers(adults=1),
        ))
        print(results)

asyncio.run(main())
```

### Context Manager

```python
from nowah import NowahClient

with NowahClient("nwh_your_api_key") as client:
    trips = client.list_trips(limit=5)
```

## Usage Examples

### Search Locations

```python
locations = client.search_locations("Paris", limit=5)
```

### Hotels

```python
from nowah import SearchHotelsParams

hotels = client.search_hotels(SearchHotelsParams(
    latitude=48.8566,
    longitude=2.3522,
    check_in="2026-07-01",
    check_out="2026-07-05",
    guests=2,
))
```

### Trips

```python
from nowah import CreateTripParams, UpdateTripParams

# Create
trip = client.create_trip(CreateTripParams(selected_offer_id="off_abc123"))

# Update
client.update_trip(UpdateTripParams(
    trip_id=trip["id"],
    name="Summer in Paris",
))

# List
trips = client.list_trips(limit=10, cursor="abc")

# Get
trip = client.get_trip("trip_123")

# Documents
docs = client.get_trip_documents("trip_123")
```

### Book a Flight

```python
from nowah import BookFlightParams, TravelerInfo

booking = client.book_flight(BookFlightParams(
    trip_id="trip_123",
    traveler_info=[
        TravelerInfo(
            given_name="Jane",
            family_name="Doe",
            born_on="1990-01-15",
            gender="f",
            email="jane@example.com",
            phone_number="+14155551234",
        )
    ],
))
```

### Payments

```python
from nowah import CreateCheckoutSessionParams

session = client.create_checkout_session(CreateCheckoutSessionParams(
    trip_id="trip_123",
    amount="499.99",
    currency="USD",
))

methods = client.list_payment_methods()
status = client.get_payment_status("pi_abc123")
```

### Seat Recommendations

```python
from nowah import GetSeatRecommendationsParams, SeatPreferences

recs = client.get_seat_recommendations(GetSeatRecommendationsParams(
    airline_code="BA",
    aircraft_type="777",
    cabin_class="economy",
    preferences=SeatPreferences(seat_type="window", extra_legroom=True),
))
```

### Travel Info

```python
from nowah import GetWeatherParams, ConvertCurrencyParams

weather = client.get_weather(GetWeatherParams(location="Paris", type="forecast", days=5))
rate = client.convert_currency(ConvertCurrencyParams(from_currency="USD", to_currency="EUR", amount=100))
visa = client.get_visa_requirements("US", "FR")
safety = client.get_safety_info("FR")
```

### AI Agent

```python
from nowah import ChatWithAgentParams

response = client.chat_with_agent(ChatWithAgentParams(
    thread_id="thread_abc",
    message="Find me a flight from NYC to London next month",
))

# Streaming
streamed = client.chat_with_agent(ChatWithAgentParams(
    thread_id="thread_abc",
    message="What hotels are near Heathrow?",
    stream=True,
))
```

## Error Handling

```python
from nowah import NowahClient, NowahError

client = NowahClient("nwh_your_api_key")

try:
    trip = client.get_trip("nonexistent")
except NowahError as e:
    print(f"Status: {e.status}")
    print(f"Code: {e.code}")
    print(f"Message: {e}")
    print(f"Retryable: {e.retryable}")
```

## Type Hints

This package ships with a `py.typed` marker (PEP 561) and full type annotations. Works with mypy, pyright, and IDE autocompletion out of the box.

## License

Apache 2.0 — see [LICENSE](LICENSE).
