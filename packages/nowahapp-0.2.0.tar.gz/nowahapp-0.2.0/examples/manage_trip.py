"""
Manage Trip -- list, inspect, update, and cancel trips.

Run with:  NOWAH_API_KEY=sk_... python examples/manage_trip.py
"""

import os

from nowah import NowahClient, UpdateTripParams, CancelTripParams


def main() -> None:
    client = NowahClient(os.environ["NOWAH_API_KEY"])

    # 1. List existing trips
    print("Listing trips...")
    result = client.list_trips(limit=5)
    trips = result["data"]["trips"]
    pagination = result["data"]["pagination"]

    print(f"Showing {len(trips)} trips (hasMore: {pagination['hasMore']})\n")

    if not trips:
        print("No trips found. Create one first with search_and_book.py")
        client.close()
        return

    for t in trips:
        name = t.get("name", "Untitled")
        status = t.get("tripStatus") or t.get("status", "")
        print(f"  [{t['id']}] {name} -- {status}")

    # 2. Get full details of the first trip
    trip_id = trips[0]["id"]
    print(f"\nFetching trip {trip_id}...")
    detail = client.get_trip(trip_id)
    trip = detail["data"]

    print(f"  Name:        {trip.get('name')}")
    print(f"  Status:      {trip.get('tripStatus')}")
    print(f"  Dates:       {trip.get('startDate')} -> {trip.get('endDate')}")
    print(f"  Budget:      {trip.get('budgetTotal', 'N/A')}")
    print(f"  Bookings:    {len(trip.get('bookings', []))}")
    print(f"  Documents:   {len(trip.get('documents', []))}")
    print(f"  Suggestions: {len(trip.get('suggestedPlaces', []))}")

    # 3. Update the trip name
    print("\nRenaming trip...")
    updated = client.update_trip(UpdateTripParams(
        trip_id=trip_id,
        name=f"{trip.get('name', '')} (updated)",
    ))
    print(f"  New name: {updated['data'].get('name')}")
    print(f"  Completeness: {updated['data'].get('completeness')}%")

    # 4. Fetch trip documents
    print("\nFetching documents...")
    docs = client.get_trip_documents(trip_id)
    doc_list = docs["data"]
    if not doc_list:
        print("  No documents yet.")
    else:
        for doc in doc_list:
            print(f"  [{doc.get('type')}] {doc.get('name') or doc.get('filename')}")

    # 5. Cancel the trip (uncomment to actually cancel)
    # print("\nCancelling trip...")
    # cancel = client.cancel_trip(CancelTripParams(trip_id=trip_id, reason="Plans changed"))
    # print(f"  Status: {cancel['data']['status']} -- {cancel['data'].get('message')}")

    print("\nDone!")
    client.close()


if __name__ == "__main__":
    main()
