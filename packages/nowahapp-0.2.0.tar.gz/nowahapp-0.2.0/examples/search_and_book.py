"""
Search & Book -- end-to-end flight booking flow.

Run with:  NOWAH_API_KEY=sk_... python examples/search_and_book.py
"""

import os

from nowah import NowahClient, Passengers, SearchFlightsParams, BookFlightParams, TravelerInfo, CreateTripParams


def main() -> None:
    client = NowahClient(os.environ["NOWAH_API_KEY"])

    # 1. Search for flights
    print("Searching for flights JFK -> LHR...")
    search = client.search_flights(SearchFlightsParams(
        origin="JFK",
        destination="LHR",
        departure_date="2026-06-15",
        passengers=Passengers(adults=1),
        cabin_class="economy",
    ))

    offers = search.offers  # type: ignore[union-attr]
    meta = search.meta  # type: ignore[union-attr]
    print(f"Found {meta.total_offers} offers, returned {len(offers)}")

    if not offers:
        print("No offers found. Try different dates or routes.")
        return

    # 2. Pick the first offer
    offer = offers[0]
    print(f"\nSelected offer: {offer.id}")
    print(f"  Airline: {offer.airline}")
    print(f"  Price:   {offer.total_amount} {offer.currency}")
    for sl in offer.slices:
        print(f"  {sl.origin} -> {sl.destination}  ({sl.stops} stops, {sl.duration})")

    # 3. Create a trip from this offer
    print("\nCreating trip...")
    trip = client.create_trip(CreateTripParams(selected_offer_id=offer.id))
    trip_id = trip["data"]["id"]
    print(f"Trip created: {trip_id} -- \"{trip['data'].get('name', '')}\"")

    # 4. Book the flight with traveler details
    print("\nBooking flight...")
    booking = client.book_flight(BookFlightParams(
        trip_id=trip_id,
        traveler_info=[
            TravelerInfo(
                given_name="Jane",
                family_name="Doe",
                born_on="1990-05-20",
                gender="f",
                email="jane@example.com",
                phone_number="+14155551234",
                type="adult",
            ),
        ],
    ))

    data = booking["data"]
    print(f"Booking status: {data['status']}")
    if "booking" in data:
        b = data["booking"]
        print(f"  Reference: {b.get('bookingReference')}")
        print(f"  Total:     {b.get('totalAmount')} {b.get('currency')}")
    if data.get("documents"):
        filenames = [d.get("filename", "") for d in data["documents"]]
        print(f"  Documents: {', '.join(filenames)}")

    print("\nDone!")
    client.close()


if __name__ == "__main__":
    main()
