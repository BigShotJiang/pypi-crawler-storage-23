"""
Streaming Chat -- connect to the AI agent and handle events in real time.

Run with:  NOWAH_API_KEY=sk_... python examples/streaming_chat.py
"""

import os
import sys
import time

from nowah import NowahClient


def main() -> None:
    client = NowahClient(os.environ["NOWAH_API_KEY"])
    thread_id = f"demo_{int(time.time() * 1000)}"

    print("Streaming agent response...\n")

    # Iterate over each SSE event as it arrives
    for event in client.chat_with_agent_stream(
        thread_id=thread_id,
        message="Find me the cheapest direct flight from NYC to Miami next Friday.",
    ):
        match event["type"]:
            case "message":
                # Print content tokens as they arrive
                sys.stdout.write(event["content"])
                sys.stdout.flush()

            case "tool_call":
                # The agent is invoking a tool (e.g. flight search)
                args = event.get("arguments", "")
                print(f"\n[tool] {event['name']}({args})")

            case "done":
                print("\n\nStream complete.")

    client.close()


if __name__ == "__main__":
    main()
