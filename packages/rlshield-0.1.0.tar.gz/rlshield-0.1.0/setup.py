"""
Minimal setup.py for compatibility with older pip versions.
The real configuration lives in pyproject.toml.
"""
from setuptools import setup

if __name__ == "__main__":
    setup()