"""Chat mode — direct LLM API integration with policy-governed tool use."""
