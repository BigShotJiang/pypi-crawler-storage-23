"""UI components — reusable Textual widgets for the AtlasBridge UI."""
