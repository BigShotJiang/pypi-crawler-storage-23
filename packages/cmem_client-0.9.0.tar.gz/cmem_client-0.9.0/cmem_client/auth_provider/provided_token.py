"""Provided token authentication provider.

This module provides an authentication provider for scenarios where access tokens
are obtained by calling a method on a user-provided object. This enables integration
with custom authentication systems, third-party libraries, or dynamic token generation
logic that is managed outside the cmem-client library.

The ProvidedToken provider delegates token retrieval to a callable method on an
external object, allowing maximum flexibility for custom authentication workflows
while maintaining compatibility with the Corporate Memory client interface.
"""

import logging

from cmem_client.auth_provider.abc import AuthProvider


class ProvidedToken(AuthProvider):
    """Authentication provider that retrieves tokens by calling a method on a provided object.

    This provider enables integration with custom authentication systems by delegating
    token retrieval to a callable method on an external object.

    Attributes:
        provider_object: The object containing the token retrieval method.
        method_name: The name of the method to call for retrieving tokens.
        logger: Logger for the authentication provider.
    """

    provider_object: object
    method_name: str
    logger: logging.Logger

    def __init__(self, provider_object: object, method_name: str):
        """Initialize a Provided Token authentication provider.

        Args:
            provider_object: Object with a callable method that returns access tokens.
            method_name: Name of the method to call on provider_object.

        Raises:
            AttributeError: If provider_object does not have the specified method.
        """
        if not hasattr(provider_object, method_name):
            raise AttributeError(f"Provider object {provider_object} does not have attribute {method_name}")

        self.provider_object = provider_object
        self.method_name = method_name
        self.logger = logging.getLogger(__name__)

    def _get_access_token(self) -> str:
        """Get an access token by calling the configured provider method.

        Returns:
            The access token string from the provider method.
        """
        method = getattr(self.provider_object, self.method_name)
        token = method()
        return str(token)
