from setuptools import find_packages, setup

setup(
    package_dir={"": "src"},
    packages=find_packages(where="src"),
)
