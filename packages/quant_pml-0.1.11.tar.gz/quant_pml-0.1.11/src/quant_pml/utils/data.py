from __future__ import annotations

from pathlib import Path

import pandas as pd


def read_data_df(
    path: str | Path,
    filename: str,
    date_column: str = "date",
    *,
    rename_column: bool = False,
) -> pd.DataFrame:
    if filename.endswith(".parquet"):
        return read_parquet(path, filename)
    if filename.endswith(".csv"):
        return read_csv(path, filename, date_column, rename_column=rename_column)
    msg = f"File extension {filename.rsplit('.', maxsplit=1)[-1]} not supported."
    raise ValueError(msg)


def read_csv(
    path: str | Path,
    filename: str,
    date_column: str = "date",
    *,
    rename_column: bool = False,
) -> pd.DataFrame:
    path = Path(path) if isinstance(path, str) else path
    data = pd.read_csv(path / filename)
    data[date_column] = pd.to_datetime(data[date_column])
    if rename_column:
        data = data.rename(columns={date_column: "date"})
        date_column = "date"
    data.columns = data.columns.astype(str)
    return data.set_index(date_column).sort_index()


def read_parquet(
    path: str | Path,
    filename: str,
) -> pd.DataFrame:
    path = Path(path) if isinstance(path, str) else path
    data = pd.read_parquet(path / filename)
    data.columns = data.columns.astype(str)
    return data.sort_index()


def build_panel_dataset(data: pd.DataFrame) -> pd.DataFrame:
    data_no_duplicates = data.loc[:, ~data.columns.duplicated()]
    data_unstacked = data_no_duplicates.stack()
    data_unstacked.index = data_unstacked.index.set_names(["date", "pmpid"])
    return data_unstacked.sort_index().to_frame("variable")
