from collections.abc import Callable

import numpy as np
import pandas as pd

from quant_pml.dataset.dataset_data import DatasetData


def create_presence_matrix(
    universe_builder_fn: Callable[
        [
            DatasetData,
        ],
        pd.DataFrame,
    ],
    processed_data: DatasetData,
) -> pd.DataFrame:
    presence_matrix = universe_builder_fn(processed_data)
    return build_valid_presence_matrix(presence_matrix)


def build_valid_presence_matrix(init_presence_matrix: pd.DataFrame) -> pd.DataFrame:
    presence_matrix = init_presence_matrix.copy().astype(float)
    presence_matrix[presence_matrix == 0] = np.nan
    presence_matrix = presence_matrix.dropna(axis=1, how="all")

    presence_matrix = presence_matrix.reset_index()
    presence_matrix["date"] = pd.to_datetime(presence_matrix["date"])
    presence_matrix = presence_matrix.set_index("date").iloc[1:]

    return presence_matrix.resample("D").ffill()
