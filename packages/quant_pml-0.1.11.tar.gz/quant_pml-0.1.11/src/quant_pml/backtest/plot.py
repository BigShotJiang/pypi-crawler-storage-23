from __future__ import annotations

import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import numpy as np
import pandas as pd

from quant_pml.utils.pd_date import get_factor_annual


def plot_cumulative_pnls(
    strategy_total: pd.DataFrame | pd.Series,
    buy_hold: pd.DataFrame | pd.Series | None = None,
    *,
    plot_log: bool = False,
    name_strategy: str = "Strategy",
    mkt_name: str = "spx",
) -> None:
    plt.figure(figsize=(14, 8))

    if isinstance(strategy_total, pd.Series):
        strategy_total = strategy_total.to_frame()

    strategy_total = strategy_total.copy()
    buy_hold = buy_hold.copy() if buy_hold is not None else None

    strategy_total.iloc[0, :] = np.zeros((1, strategy_total.shape[1]))
    if buy_hold is not None:
        buy_hold.iloc[0, :] = np.zeros((1, buy_hold.shape[1]))

    strategy_cumulative = strategy_total.add(1).cumprod()
    strategy = strategy_cumulative.to_numpy()

    plt.plot(strategy_cumulative.index, strategy, label=name_strategy)

    if buy_hold is not None:
        buy_hold_cumulative = buy_hold.add(1).cumprod()
        if mkt_name in buy_hold.columns:
            market = buy_hold_cumulative[mkt_name]
            buy_hold_cumulative = buy_hold_cumulative.drop(columns=mkt_name)
            plt.plot(
                market.index,
                market.to_numpy(),
                label=mkt_name.rstrip("-rf"),
                linewidth=6,
            )
        plt.plot(
            buy_hold_cumulative.index,
            buy_hold_cumulative.to_numpy(),
            label=buy_hold_cumulative.columns,
            linestyle="--",
        )
        plt.legend(
            fontsize=16,
            loc="upper left",
            bbox_to_anchor=(1.05, 1),
            borderaxespad=0.0,
        )

    plt.xlabel("Date", fontsize=14)
    if plot_log:
        plt.ylabel("Log Scale Cumulative Pnl", fontsize=14)
        plt.yscale("log")
    else:
        plt.ylabel("Cumulative Pnl", fontsize=14)
    plt.legend(fontsize=16)
    start_date = strategy_total.index.min()
    end_date = strategy_total.index.max()
    plt.title(f"Cumulative Total Returns ({start_date.year}/{start_date.month} - {end_date.year}/{end_date.month})")
    plt.show()


def plot_weights(weights: pd.DataFrame) -> None:
    plt.figure(figsize=(14, 8))

    plt.plot(weights.index, weights.to_numpy(), label="Strategy Weights")
    plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter(1))

    plt.xlabel("Date", fontsize=14)
    plt.ylabel("Weight", fontsize=14)
    plt.legend(fontsize=16)
    plt.show()


def plot_turnover(turnover: pd.Series) -> None:
    plt.figure(figsize=(14, 8))
    dates = turnover.index

    factor_annual = get_factor_annual(dates, from_predefined=False)
    turnover = turnover.copy().to_numpy()

    annualized_turnover = turnover[1:].mean() * factor_annual

    rebal_turnober_idx = turnover != 0
    turnover = turnover[rebal_turnober_idx]
    dates = dates[rebal_turnober_idx]

    plt.plot(dates, turnover, label="Strategy Turnover")
    plt.gca().yaxis.set_major_formatter(mtick.PercentFormatter(1))

    plt.xlabel("Date", fontsize=14)
    plt.ylabel("Turnover", fontsize=14)
    plt.legend(fontsize=16)
    plt.title(f"Annualized Turnover: {annualized_turnover:.2%}")
    plt.show()


def plot_histogram(
    strategy_total: pd.Series,
) -> None:
    plt.figure(figsize=(14, 8))

    plt.hist(strategy_total, bins=50, label="Strategy Returns")

    plt.ylabel("Return", fontsize=14)
    plt.legend(fontsize=16)
    plt.show()


def plot_outperformance(
    strategy_total: pd.Series,
    baseline: pd.Series,
    baseline_name: str = "Baseline",
) -> None:
    dates = strategy_total.index

    strategy_total_r = strategy_total.to_numpy().flatten()
    baseline_total_r = baseline.to_numpy().flatten()

    outperform = strategy_total_r - baseline_total_r
    outperform_rel = outperform / (1 + baseline_total_r)

    plt.figure(figsize=(14, 8))
    plt.plot(dates, np.log(1 + outperform_rel).cumsum())

    plt.xlabel("Date")
    plt.ylabel("Outperformance")
    plt.title(f"Outperformance vs {baseline_name}")

    plt.show()


def plot_rolling_metrics(rolling_sharpe: pd.Series, rolling_alpha: pd.Series, ma_window: int = 21 * 3) -> None:
    dates = rolling_sharpe.index

    ma_sharpe = rolling_sharpe.rolling(window=ma_window, min_periods=1).mean()
    ma_alpha = rolling_alpha.rolling(window=ma_window, min_periods=1).mean()

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 12))

    ax1.plot(dates, rolling_sharpe.to_numpy(), label="1Y Sharpe")
    ax1.plot(dates, ma_sharpe.to_numpy(), label="3M Moving Average Sharpe")
    ax1.plot(dates, np.zeros_like(rolling_sharpe.to_numpy()), linestyle="--", color="r")
    ax1.set_title("Sharpe Ratio")
    ax1.legend()

    ax2.plot(dates, rolling_alpha.to_numpy(), label="1Y Alpha")
    ax2.plot(dates, ma_alpha.to_numpy(), label="3M Moving Average Alpha")
    ax2.plot(dates, np.zeros_like(rolling_alpha.to_numpy()), linestyle="--", color="r")
    ax2.yaxis.set_major_formatter(mtick.PercentFormatter(1))
    ax2.set_title("Alpha Benchmark")
    ax2.legend()

    plt.tight_layout()
    plt.show()
