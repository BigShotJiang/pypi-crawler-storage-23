from dataclasses import dataclass

import pandas as pd


@dataclass
class DatasetData:
    data: pd.DataFrame
    presence_matrix: pd.DataFrame
    mkt_caps: pd.DataFrame | None = None
    dividends: pd.DataFrame | None = None
    volumes: pd.DataFrame | None = None

    targets: pd.DataFrame | None = None

    # Macro features are (T x P_macro), i.e., shared across all assets
    macro_features: pd.DataFrame | None = None
    # Asset-specific features are (T x N x P_asset), i.e., panel data with MultiIndex (asset, date)
    asset_features: pd.DataFrame | None = None
