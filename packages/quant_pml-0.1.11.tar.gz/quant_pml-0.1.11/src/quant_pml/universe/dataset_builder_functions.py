from __future__ import annotations

from collections.abc import Callable
from os import listdir

import pandas as pd

from quant_pml.config.base_experiment_config import BaseExperimentConfig
from quant_pml.config.jkp_experiment_config import JKPExperimentConfig
from quant_pml.config.spx_experiment_config import SPXExperimentConfig
from quant_pml.config.topn_experiment_config import TopNExperimentConfig
from quant_pml.dataset.dataset_data import DatasetData
from quant_pml.universe.universe_builder_functions import (
    avg_volume_filter_universe_builder_fn,
    filter_history,
    mkt_cap_quantile_universe_builder_fn,
    mkt_cap_topn_universe_builder_fn,
)
from quant_pml.utils.data import read_data_df
from quant_pml.utils.universe import create_presence_matrix


def _pre_build_dataset(
    config: BaseExperimentConfig,
) -> DatasetData:
    # TODO(@V): Refactor to accommodate `build_crsp_dataset`
    df_filename = config.PREFIX + config.DF_FILENAME
    pm_filename = config.PREFIX + config.PRESENCE_MATRIX_FILENAME
    mkt_caps_filename = config.PREFIX + config.MKT_CAPS_FILENAME
    dividends_filename = config.PREFIX + config.DIVIDENDS_FILENAME
    volumes_filename = config.PREFIX + config.VOLUMES_FILENAME

    data_df = read_data_df(config.PATH_OUTPUT, df_filename)
    presence_matrix = read_data_df(config.PATH_OUTPUT, pm_filename)

    if mkt_caps_filename in listdir(config.PATH_OUTPUT):
        mkt_caps = read_data_df(config.PATH_OUTPUT, mkt_caps_filename)
    else:
        mkt_caps = None

    if dividends_filename in listdir(config.PATH_OUTPUT):
        dividends = read_data_df(config.PATH_OUTPUT, dividends_filename)
    else:
        dividends = None

    if volumes_filename in listdir(config.PATH_OUTPUT):
        volumes = read_data_df(config.PATH_OUTPUT, volumes_filename)
    else:
        volumes = None

    return DatasetData(
        data=data_df,
        presence_matrix=presence_matrix,
        mkt_caps=mkt_caps,
        dividends=dividends,
        volumes=volumes,
    )


def build_custom_dataset(
    config: BaseExperimentConfig,
    universe_builder_fns: list[
        Callable[
            [
                DatasetData,
            ],
            pd.DataFrame,
        ]
    ],
) -> DatasetData:
    dataset_data = _pre_build_dataset(config=config)

    if len(universe_builder_fns) > 0:
        presence_matrix = dataset_data.presence_matrix
        for universe_builder_fn in universe_builder_fns:
            presence_matrix_filter = create_presence_matrix(universe_builder_fn, dataset_data)

            selection = presence_matrix_filter.columns.intersection(presence_matrix.columns)
            presence_matrix_filter = presence_matrix_filter.loc[
                presence_matrix.index.min() : presence_matrix.index.max(), selection
            ]
            presence_matrix_filter = presence_matrix_filter.reindex(presence_matrix.index, method="ffill")

            selected_pm = presence_matrix[selection]
            selected_pm_filter = presence_matrix_filter[selection]

            assert selected_pm.shape[0] == selected_pm_filter.shape[0], (
                f"Presence matrix filter has different number of rows than presence matrix: {selected_pm_filter.shape[0]} != {selected_pm.shape[0]}"
            )
            assert selected_pm.shape[1] == selected_pm_filter.shape[1], (
                f"Presence matrix filter has different number of columns than presence matrix: {selected_pm_filter.shape[1]} != {selected_pm.shape[1]}"
            )

            presence_matrix = selected_pm * selected_pm_filter.to_numpy()

            dataset_data.presence_matrix = presence_matrix

    return dataset_data


def build_full_dataset(config: BaseExperimentConfig) -> DatasetData:
    return build_custom_dataset(config=config, universe_builder_fns=[])


def build_topn_dataset(config: TopNExperimentConfig) -> DatasetData:
    return build_custom_dataset(
        config=config, universe_builder_fns=[lambda data: mkt_cap_topn_universe_builder_fn(data, topn=config.TOPN)]
    )


def build_research_us_dataset(config: TopNExperimentConfig) -> DatasetData:
    return build_custom_dataset(
        config=config,
        universe_builder_fns=[
            lambda data: filter_history(data, window_size=252, min_percentage_nans=0.025),
            lambda data: mkt_cap_topn_universe_builder_fn(data, topn=config.TOPN),
            lambda data: avg_volume_filter_universe_builder_fn(
                data,
                min_volume=5_000_000,
            ),
        ],
    )


def build_jkp_dataset(config: JKPExperimentConfig) -> DatasetData:
    return build_custom_dataset(
        config=config,
        universe_builder_fns=[
            lambda data: mkt_cap_quantile_universe_builder_fn(data, quantile=config.MCAP_SELECTION_QUANTILE),
        ],
    )


def build_dnk_dataset(config: TopNExperimentConfig) -> DatasetData:
    return build_custom_dataset(
        config=config,
        universe_builder_fns=[
            lambda data: filter_history(data, window_size=252, min_percentage_nans=0.025),
            lambda data: mkt_cap_topn_universe_builder_fn(data, topn=config.TOPN),
        ],
    )


def build_from_existing_dataset(
    config: BaseExperimentConfig,
    presence_matrix: pd.DataFrame,
) -> DatasetData:
    return build_custom_dataset(
        config=config,
        universe_builder_fns=[
            lambda data: presence_matrix,
        ],
    )


def build_spx_dataset(
    config: SPXExperimentConfig,
    spx_presence_matrix: pd.DataFrame,
) -> DatasetData:
    return build_from_existing_dataset(config, spx_presence_matrix)


if __name__ == "__main__":
    from quant_pml.config.topn_experiment_config import TopNExperimentConfig

    TOP_N = 500

    settings = TopNExperimentConfig(topn=TOP_N)
    dataset = build_dnk_dataset(settings)

    print(dataset.presence_matrix.sum(axis=1))
