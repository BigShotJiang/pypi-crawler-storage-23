from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

    import pandas as pd

    from quant_pml.dataset.dataset_data import DatasetData

from pathlib import Path

from quant_pml.utils.data import read_data_df


def _mkt_cap_universe_builder_fn(
    dataset_data: DatasetData,
    mkt_cap_filter_fn: Callable[
        [
            pd.Series,
        ],
        bool,
    ],
) -> pd.DataFrame:

    pm = dataset_data.presence_matrix
    init_mktcaps = dataset_data.mkt_caps

    mktcaps = init_mktcaps.loc[:, pm.columns] * pm.loc[init_mktcaps.index].to_numpy()

    return mktcaps.apply(lambda x: mkt_cap_filter_fn(x), axis=1).astype(float)


def mkt_cap_topn_universe_builder_fn(data: DatasetData, topn: int) -> pd.DataFrame:
    return _mkt_cap_universe_builder_fn(data, lambda x: x >= x.dropna().nlargest(topn).min())


def mkt_cap_quantile_universe_builder_fn(data: DatasetData, quantile: float) -> pd.DataFrame:
    return _mkt_cap_universe_builder_fn(data, lambda x: x >= x.dropna().quantile(quantile))


def avg_volume_filter_universe_builder_fn(
    data: DatasetData,
    min_volume: float,
    window_size: int = 21 * 3,
) -> pd.DataFrame:
    avg_vol = data.volumes.rolling(window=window_size, min_periods=1, closed="left").mean()

    return avg_vol.apply(lambda x: x >= min_volume, axis=1).astype(float)


def filter_history(
    data: DatasetData,
    window_size: int = 252,
    min_percentage_nans: float = 0.025,
) -> pd.DataFrame:
    prices = data.data[data.presence_matrix.columns]
    num_valid_points = prices.rolling(window=window_size, min_periods=1).count(numeric_only=True)
    return num_valid_points >= min_percentage_nans * window_size + 1  # prc => +1 for num of valid returns


def load_precomputed_builder_fn(
    data: DatasetData,
    filename: str,
    path: Path = Path("../data/precomputed_pms/"),
) -> pd.DataFrame:
    return read_data_df(path, filename)
