from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from quant_pml.config.trading_config import TradingConfig
    from quant_pml.strategies.optimization_data import PredictionData, TrainingData

from abc import ABC, abstractmethod

import pandas as pd

from quant_pml.strategies.base_strategy import BaseStrategy


class BaseEstimatedStrategy(BaseStrategy, ABC):
    def __init__(
        self,
        trading_config: TradingConfig,
        window_size: int | None = None,
    ) -> None:
        super().__init__()

        self.trading_config = trading_config
        self.window_size = window_size

    def _fit(self, training_data: TrainingData) -> None:
        ret = training_data.simple_excess_returns[self.available_assets]

        start_date = ret.index[-1] - pd.Timedelta(days=self.window_size) if self.window_size is not None else ret.index[0]

        training_data.simple_excess_returns = training_data.simple_excess_returns[self.available_assets]
        training_data.simple_excess_returns = training_data.simple_excess_returns.loc[start_date:].fillna(0.0)

        training_data.log_excess_returns = (
            training_data.log_excess_returns.loc[start_date:, self.available_assets].fillna(0.0)
            if training_data.log_excess_returns is not None
            else None
        )
        training_data.factors = training_data.factors.loc[start_date:] if training_data.factors is not None else None

        self._fit_estimator(training_data=training_data)

    @abstractmethod
    def _fit_estimator(self, training_data: TrainingData) -> None:
        raise NotImplementedError

    @abstractmethod
    def _optimize(self, prediction_data: PredictionData) -> pd.Series[float]:
        raise NotImplementedError

    def _get_weights(self, prediction_data: PredictionData, weights_: pd.DataFrame) -> pd.DataFrame:
        weights = self._optimize(prediction_data=prediction_data)

        weights_.loc[:, weights.index] = weights.to_numpy()

        # (!!!) Please, use only excess returns to apply this scaling correctly
        return weights_
