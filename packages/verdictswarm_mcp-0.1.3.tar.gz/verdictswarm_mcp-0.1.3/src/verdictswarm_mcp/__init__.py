from .api_client import VerdictSwarmApiClient, VerdictSwarmClient


def main() -> None:
    from .server import mcp

    mcp.run()


__all__ = ["main", "VerdictSwarmApiClient", "VerdictSwarmClient"]
