"""Publish page-level CSS/JS assets from Wagtail CMS to static storage."""
