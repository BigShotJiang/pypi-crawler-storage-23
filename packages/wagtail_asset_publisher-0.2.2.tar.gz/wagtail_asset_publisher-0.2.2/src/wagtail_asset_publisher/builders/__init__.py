"""Asset builders for wagtail-asset-publisher."""
