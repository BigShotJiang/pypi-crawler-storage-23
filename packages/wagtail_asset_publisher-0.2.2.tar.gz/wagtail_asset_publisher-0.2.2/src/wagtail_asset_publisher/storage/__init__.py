"""Storage backends for wagtail-asset-publisher."""
