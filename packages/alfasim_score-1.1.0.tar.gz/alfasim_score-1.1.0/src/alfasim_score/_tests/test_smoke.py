

def test_smoke():
    '''
    This test is temporary and should be removed when first test is added.
    '''
    assert True