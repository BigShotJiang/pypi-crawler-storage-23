"""StockClaw Kit — Lightweight Tool Registry

FastMCP 대체. @registry.tool() 데코레이터 호환 인터페이스.
서버 파일의 register_tools(registry, ...) 호출 패턴.
"""

import asyncio
import json


class ToolRegistry:
    """경량 도구 레지스트리 — .tool() 데코레이터 패턴"""

    def __init__(self, name: str = ""):
        self.name = name
        self._tools: dict = {}  # {name: {"fn": callable, "description": str}}

    def tool(self):
        """@registry.tool() 데코레이터 호환

        두 가지 패턴 모두 지원:
            @registry.tool()
            def my_fn(): ...

            registry.tool()(fn)  # KIS 동적 등록
        """
        def decorator(fn):
            self._tools[fn.__name__] = {
                "fn": fn,
                "description": (fn.__doc__ or "").strip().split("\n")[0],
            }
            return fn
        return decorator

    def list_tools(self) -> list:
        """등록된 도구 목록 반환 [{name, description}, ...]"""
        return [
            {"name": name, "description": info["description"][:100]}
            for name, info in sorted(self._tools.items())
        ]

    def get_tool(self, name: str):
        """이름으로 도구 함수 반환 (없으면 None)"""
        entry = self._tools.get(name)
        return entry["fn"] if entry else None

    def call(self, name: str, params: dict) -> str:
        """도구 호출 → JSON 문자열 반환. sync/async 모두 처리."""
        entry = self._tools.get(name)
        if not entry:
            raise KeyError(f"Tool '{name}' not found")

        fn = entry["fn"]

        if asyncio.iscoroutinefunction(fn):
            result = asyncio.run(fn(**params))
        else:
            result = fn(**params)

        if isinstance(result, dict):
            return json.dumps(result, ensure_ascii=False, indent=2)
        return str(result)
