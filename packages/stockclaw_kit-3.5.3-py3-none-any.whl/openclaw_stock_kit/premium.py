#!/usr/bin/env python3
"""OpenClaw Stock Kit — 프리미엄 모듈

유료 구독자 전용 기능:
  1. 오전장/오후장 브리핑 API 연동
  2. TOP30/메모 엑셀 다운로드
  3. 백테스트 엔진 (종가매매 시나리오)
  4. 매매방법 강의 콘텐츠 조회

라이선스 키 기반 인증:
  - OPENCLAW_LICENSE_KEY 환경변수 또는 settings 페이지에서 입력
  - 키 검증: 서버사이드 검증 (fail-closed — 서버 미연결 + grace 만료 시 비활성화)
"""

import hashlib
import hmac
import json
import logging
import os
import time
import urllib.request
import urllib.error
from pathlib import Path

logger = logging.getLogger("stock-kit.premium")

# ─── 라이선스 검증 ─────────────────────────────────────────

# 라이선스 키 형식: OCKP-XXXXXX-XXXXXX-XXXXXX
_LICENSE_SECRET = os.getenv("OPENCLAW_LICENSE_SECRET", "stockclaw-kit-2026")  # 로컬 HMAC 시드 (환경변수 우선)

# 캐시 구조: server_verified_at = 서버가 마지막으로 OK 응답한 시각
_LICENSE_CACHE = {
    "key": None,
    "result": None,
    "checked_at": 0,           # 마지막 검증 시각
    "server_verified_at": 0,   # 서버가 마지막으로 valid=True 응답한 시각
}
_CACHE_TTL = 3600       # 서버 재확인 주기: 1시간
_GRACE_PERIOD = 86400   # 서버 미연결 시 grace: 24시간


def _verify_license_local(key: str) -> dict:
    """1단계: 로컬 HMAC 형식 검증 (빠른 reject용, 프리미엄 허용 아님)"""
    if not key or not key.startswith("OCKP-"):
        return {"valid": False, "error": "유효하지 않은 키 형식 (OCKP-로 시작해야 합니다)",
                "error_code": "LICENSE_INVALID"}

    parts = key.split("-")
    if len(parts) != 4:
        return {"valid": False, "error": "키 형식 오류 (OCKP-XXXXXX-XXXXXX-XXXXXX)",
                "error_code": "LICENSE_INVALID"}

    payload = f"{parts[1]}-{parts[2]}"
    expected_sig = hmac.new(
        _LICENSE_SECRET.encode(), payload.encode(), hashlib.sha256
    ).hexdigest()[:6].upper()

    if parts[3] != expected_sig:
        return {"valid": False, "error": "라이선스 키가 유효하지 않습니다",
                "error_code": "LICENSE_INVALID"}

    return {"valid": True, "tier": "premium", "key_prefix": parts[1]}


def _verify_license_server(key: str) -> dict:
    """2단계: ai-backend 서버사이드 검증 (source of truth)"""
    url = _get_backend_url() + "/api/license/verify"
    try:
        body = json.dumps({
            "license_key": key,
            "product": "stockclaw-kit-premium",
        }).encode()
        req = urllib.request.Request(
            url, data=body,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            result = json.loads(resp.read().decode())
        # 표준 응답 파싱: ok/data 또는 legacy valid 형식 모두 지원
        data = result.get("data", result)
        if data.get("valid"):
            return {
                "valid": True,
                "tier": data.get("plan", data.get("tier", "premium")),
                "expires": data.get("expires_at", ""),
                "features": data.get("features", []),
                "grace_seconds": data.get("grace_seconds", _GRACE_PERIOD),
                "verified_by": "server",
            }
        return {
            "valid": False,
            "error": data.get("error", result.get("error", {}).get("message", "서버 검증 실패")),
            "error_code": data.get("error_code", result.get("error", {}).get("code", "LICENSE_INVALID")),
        }
    except Exception as e:
        logger.debug(f"[License] 서버 연결 불가: {e}")
        return None  # 서버 미연결 (fallback 판단은 호출자가)


def _verify_license(key: str) -> dict:
    """라이선스 키 검증 (fail-closed 정책)

    1단계: 로컬 HMAC 형식 검증 (빠른 reject)
    2단계: 서버 검증 (source of truth)
    서버 미연결 시:
      - 최근 24시간 이내 서버 OK 이력 있으면 → grace 허용
      - 서버 OK 이력 없으면 → fail-closed (프리미엄 비활성화)
    """
    now = time.time()

    # 캐시 히트 (1시간 이내 + 같은 키)
    if (_LICENSE_CACHE["key"] == key
            and _LICENSE_CACHE["result"]
            and _LICENSE_CACHE["result"].get("valid")
            and (now - _LICENSE_CACHE["checked_at"]) < _CACHE_TTL):
        return _LICENSE_CACHE["result"]

    # 1단계: 로컬 형식 검증 (빠른 reject)
    local_result = _verify_license_local(key)
    if not local_result["valid"]:
        return local_result  # 형식 오류는 서버 호출 불필요

    # 2단계: 서버 검증
    server_result = _verify_license_server(key)

    if server_result is not None:
        # 서버 응답 있음 → 서버 결과가 최종
        _LICENSE_CACHE["key"] = key
        _LICENSE_CACHE["result"] = server_result
        _LICENSE_CACHE["checked_at"] = now
        if server_result.get("valid"):
            _LICENSE_CACHE["server_verified_at"] = now  # OK 시각 기록
        return server_result

    # ── 서버 미연결: fail-closed + grace 판단 ──
    last_server_ok = _LICENSE_CACHE.get("server_verified_at", 0)
    grace = _LICENSE_CACHE.get("result", {}).get("grace_seconds", _GRACE_PERIOD)

    if _LICENSE_CACHE["key"] == key and last_server_ok > 0 and (now - last_server_ok) < grace:
        # 24시간 이내 서버 검증 성공 이력 → grace 허용
        grace_result = dict(_LICENSE_CACHE["result"])
        grace_result["verified_by"] = "grace"
        grace_remaining = int(grace - (now - last_server_ok))
        logger.info(f"[License] 서버 미연결, grace 허용 (잔여 {grace_remaining}초)")
        _LICENSE_CACHE["checked_at"] = now
        return grace_result

    # 서버 미연결 + grace 만료 → fail-closed (보안 우선)
    logger.warning("[License] 서버 미연결 + grace 만료 — 프리미엄 비활성화")
    return {
        "valid": False,
        "error": "라이선스 서버에 연결할 수 없습니다. 네트워크 확인 후 재시도하세요.",
        "error_code": "LICENSE_SERVER_UNREACHABLE",
    }


def _get_license_key() -> str:
    """환경변수 또는 설정 파일에서 라이선스 키 로드"""
    key = os.getenv("OPENCLAW_LICENSE_KEY", "")
    if key:
        return key
    # .env 파일에서 로드 (__main__.py의 load_saved_keys와 동일 경로)
    config_dir = Path(os.getenv(
        "OPENCLAW_STOCK_KIT_HOME",
        Path.home() / ".stockclaw-kit"
    ))
    env_file = config_dir / ".env"
    if env_file.exists():
        try:
            from dotenv import dotenv_values
            keys = dotenv_values(env_file)
            return keys.get("OPENCLAW_LICENSE_KEY", "")
        except Exception:
            pass
    return ""


def _require_premium(func_name: str) -> dict:
    """프리미엄 기능 접근 전 라이선스 확인"""
    key = _get_license_key()
    if not key:
        return {
            "success": False,
            "error": f"[{func_name}] 프리미엄 기능입니다. OPENCLAW_LICENSE_KEY를 설정하세요.",
            "error_code": "LICENSE_MISSING",
            "help": "Settings 페이지에서 라이선스 키를 입력하거나, 환경변수로 설정하세요.",
            "purchase": "https://openclaw.ai/premium",
        }
    result = _verify_license(key)
    if not result["valid"]:
        return {
            "success": False,
            "error": f"[{func_name}] {result['error']}",
            "error_code": result.get("error_code", "LICENSE_INVALID"),
            "purchase": "https://openclaw.ai/premium",
        }
    return None  # 통과


# ─── AI Backend API 연결 ───────────────────────────────────

def _get_backend_url() -> str:
    """ai-backend API URL"""
    return os.getenv("AI_BACKEND_URL", "http://127.0.0.1:4000")


def _backend_get(path: str, timeout: int = 30) -> dict:
    """ai-backend GET 요청"""
    url = _get_backend_url() + path
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return {"success": False, "error": f"HTTP {e.code}: {e.reason}"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _backend_post(path: str, data: dict, timeout: int = 30) -> dict:
    """ai-backend POST 요청"""
    url = _get_backend_url() + path
    try:
        body = json.dumps(data).encode()
        req = urllib.request.Request(
            url, data=body,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return {"success": False, "error": f"HTTP {e.code}: {e.reason}"}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ─── 프리미엄 기능 구현 ───────────────────────────────────

def get_morning_briefing(date: str = "") -> dict:
    """오전장 브리핑 조회

    Args:
        date: 날짜 (YYYY-MM-DD). 빈 문자열이면 최신.

    Returns:
        브리핑 HTML 또는 요약 데이터
    """
    check = _require_premium("오전장 브리핑")
    if check:
        return check

    if date:
        return _backend_get(f"/api/briefing/latest/{date}")
    else:
        return _backend_get("/api/briefing/recent?limit=1")


def get_afternoon_briefing(date: str = "") -> dict:
    """오후장 브리핑 조회"""
    check = _require_premium("오후장 브리핑")
    if check:
        return check

    return _backend_get(f"/api/morning-analysis/session/{date}" if date else "/api/morning-analysis/latest?limit=1")


def get_top30_excel(date: str = "", file_type: str = "top30") -> dict:
    """TOP30/TOP10 엑셀 데이터 조회 및 생성

    Args:
        date: 날짜 (YYYY-MM-DD)
        file_type: "top30" | "top10" | "combined"

    Returns:
        엑셀 데이터 (JSON) 또는 다운로드 경로
    """
    check = _require_premium("TOP30 엑셀")
    if check:
        return check

    if date:
        return _backend_post("/api/top30/generate-excel-advanced", {
            "startDate": date,
            "endDate": date,
            "fileTypes": [file_type],
        })
    else:
        return _backend_get("/api/top30/stats")


def get_memo_excel(date: str = "") -> dict:
    """메모 엑셀 조회/생성"""
    check = _require_premium("메모 엑셀")
    if check:
        return check

    return _backend_post("/api/memo-excel/generate", {"date": date})


def run_backtest(
    strategy: str = "jongga",
    start_date: str = "",
    end_date: str = "",
    params: dict = None,
) -> dict:
    """매매 시나리오 백테스트 실행

    Args:
        strategy: "jongga" (종가매매) | "trailing" (추적손절) | "swing"
        start_date: 시작일 (YYYY-MM-DD)
        end_date: 종료일 (YYYY-MM-DD)
        params: 전략 파라미터 (매수조건, 손절%, 목표% 등)

    Returns:
        백테스트 결과 (수익률, 거래 내역 등)
    """
    check = _require_premium("백테스트")
    if check:
        return check

    return _backend_post("/api/backtest/run", {
        "strategy": strategy,
        "startDate": start_date,
        "endDate": end_date,
        "params": params or {},
    })


def get_trading_course(topic: str = "") -> dict:
    """매매방법 강의 콘텐츠 조회

    Args:
        topic: 주제 (빈 문자열이면 목록 반환)
            - "jongga_basics" : 종가매매 기초
            - "chart_reading" : 차트 읽기
            - "risk_management" : 리스크 관리
            - "live_trading" : 실전 매매 가이드

    Returns:
        강의 콘텐츠 또는 목록
    """
    check = _require_premium("매매 강의")
    if check:
        return check

    if topic:
        return _backend_get(f"/api/course/content/{topic}")
    else:
        return _backend_get("/api/course/list")


# ─── 도구 등록 ────────────────────────────────────────

PREMIUM_FUNCTIONS = {
    "get_morning_briefing": {
        "fn": get_morning_briefing,
        "description": "오전장 브리핑 조회 (프리미엄)",
        "params": {"date": "날짜 YYYY-MM-DD (빈값=최신)"},
    },
    "get_afternoon_briefing": {
        "fn": get_afternoon_briefing,
        "description": "오후장 분석 세션 조회 (프리미엄)",
        "params": {"date": "날짜 YYYY-MM-DD (빈값=최신)"},
    },
    "get_top30_excel": {
        "fn": get_top30_excel,
        "description": "TOP30/TOP10 엑셀 데이터 조회 (프리미엄)",
        "params": {"date": "날짜 YYYY-MM-DD", "file_type": "top30|top10|combined"},
    },
    "get_memo_excel": {
        "fn": get_memo_excel,
        "description": "메모 엑셀 조회/생성 (프리미엄)",
        "params": {"date": "날짜 YYYY-MM-DD"},
    },
    "run_backtest": {
        "fn": run_backtest,
        "description": "매매 시나리오 백테스트 실행 (프리미엄)",
        "params": {
            "strategy": "jongga|trailing|swing",
            "start_date": "시작일 YYYY-MM-DD",
            "end_date": "종료일 YYYY-MM-DD",
            "params": "전략 파라미터 dict",
        },
    },
    "get_trading_course": {
        "fn": get_trading_course,
        "description": "매매방법 강의 콘텐츠 조회 (프리미엄)",
        "params": {"topic": "주제 (빈값=목록)"},
    },
}


def register_premium_tools(registry):
    """프리미엄 도구 등록"""

    @registry.tool()
    def premium_call(function_name: str, params: dict = None) -> dict:
        """프리미엄 기능 호출 (라이선스 키 필요)

        Available functions:
          - get_morning_briefing(date) : 오전장 브리핑
          - get_afternoon_briefing(date) : 오후장 분석
          - get_top30_excel(date, file_type) : TOP30 엑셀
          - get_memo_excel(date) : 메모 엑셀
          - run_backtest(strategy, start_date, end_date, params) : 백테스트
          - get_trading_course(topic) : 매매 강의

        Args:
            function_name: 호출할 함수명
            params: 함수 파라미터 (dict)

        Returns:
            함수 실행 결과
        """
        if function_name not in PREMIUM_FUNCTIONS:
            return {
                "success": False,
                "error": f"Unknown function: {function_name}",
                "available": list(PREMIUM_FUNCTIONS.keys()),
            }
        fn = PREMIUM_FUNCTIONS[function_name]["fn"]
        return fn(**(params or {}))

    @registry.tool()
    def premium_list_functions() -> dict:
        """프리미엄 기능 목록 조회 (라이선스 키 불필요)

        Returns:
            사용 가능한 프리미엄 기능 목록 + 라이선스 상태
        """
        key = _get_license_key()
        license_status = _verify_license(key) if key else {"valid": False, "error": "키 미설정"}

        return {
            "success": True,
            "license": {
                "active": license_status.get("valid", False),
                "tier": license_status.get("tier", "free"),
            },
            "functions": {
                name: {
                    "description": info["description"],
                    "params": info["params"],
                }
                for name, info in PREMIUM_FUNCTIONS.items()
            },
            "purchase": "https://openclaw.ai/premium",
        }

    logger.info("[Premium] 2 tools registered (premium_call, premium_list_functions)")
    return ["premium_call", "premium_list_functions"]
