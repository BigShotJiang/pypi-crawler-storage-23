#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
테마랩 데이터 피드 서버 (readinginvestor.com)
PDR v1 정의: readinginvestor.com API 피드 8개
도구 3개: themalab_call, themalab_list_functions, themalab_get_env_info
Rate Limit: 분당 120회 (sliding window, threading.Lock)
"""

import os, sys, json, threading, time, hashlib
from collections import deque
from datetime import datetime, timezone, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from response import ok_response, error_response, ErrorCode

try:
    import requests as _requests
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False

try:
    import psycopg2
    _HAS_PG = True
except ImportError:
    _HAS_PG = False

_BASE_URL = "https://readinginvestor.com/api/feed"
_USER_AGENT = "stockclaw-kit/3.5"
_TIMEOUT = 15
_RATE_LIMIT_PER_MINUTE = 120
_KST = timezone(timedelta(hours=9))

_API_CATALOG = {
    "ka-002": {
        "name": "종목 뉴스 매칭",
        "required_params": ["stock_code"],
        "optional_params": ["date"],
        "description": "특정 종목코드에 매칭되는 뉴스와 테마이벤트 목록 반환",
        "example": {"stock_code": "005930"},
    },
    "ka-004": {
        "name": "테마별 이벤트",
        "required_params": [],
        "optional_params": ["date", "theme"],
        "description": "테마별 시장 이벤트 요약. date 없으면 오늘 리턴",
        "example": {},
    },
    "ka-005": {
        "name": "종목별 뉴스 통합",
        "required_params": ["stock_code"],
        "optional_params": ["limit"],
        "description": "특정 종목의 여러 뉴스소스 통합 들",
        "example": {"stock_code": "000660"},
    },
    "ka-006": {
        "name": "AI 일일 요약",
        "required_params": [],
        "optional_params": ["date"],
        "description": "AI가 생성한 오늘 시장 요약. 주요 테마와 종목 포함",
        "example": {},
    },
    "ka-007": {
        "name": "뉴욕증시",
        "required_params": [],
        "optional_params": ["date"],
        "description": "전일 뉴욕증시 시세와 주요 뉴스 요약",
        "example": {},
    },
    "ka-008": {
        "name": "주도주시황",
        "required_params": [],
        "optional_params": ["date"],
        "description": "시장 주도주 시황 분석",
        "example": {},
    },
    "ka-009": {
        "name": "장전뉴스",
        "required_params": [],
        "optional_params": ["date"],
        "description": "장 시작 전 주요 뉴스 요약",
        "example": {},
    },
    "ka-010": {
        "name": "오후장 특징종목",
        "required_params": [],
        "optional_params": ["date"],
        "description": "오후장 언급된 특징 종목 목록과 이유",
        "example": {},
    },
}


class _RateLimiter:
    """Sliding window rate limiter: max N calls per 60 seconds."""

    def __init__(self, max_per_minute: int = _RATE_LIMIT_PER_MINUTE):
        self._max = max_per_minute
        self._window = deque()  # timestamps of recent calls
        self._lock = threading.Lock()

    def acquire(self) -> tuple[bool, float]:
        """Returns (allowed, wait_seconds). wait_seconds=0 if allowed."""
        now = time.monotonic()
        with self._lock:
            # remove timestamps older than 60s
            cutoff = now - 60.0
            while self._window and self._window[0] < cutoff:
                self._window.popleft()
            if len(self._window) < self._max:
                self._window.append(now)
                return True, 0.0
            oldest = self._window[0]
            wait = 60.0 - (now - oldest)
            return False, max(0.0, wait)


_rate_limiter = _RateLimiter()
_pg_getter = None


def register_tools(registry, get_pg=None):
    global _pg_getter
    if get_pg is not None:
        _pg_getter = get_pg

    # ------------------------------------------------------------------ helpers

    def _get_pg_conn():
        if _pg_getter is None:
            return None
        try:
            return _pg_getter()
        except Exception:
            return None

    def _call_feed_api(api_id: str, params: dict, api_key: str) -> dict:
        """Call readinginvestor.com feed API and return parsed JSON."""
        if not _HAS_REQUESTS:
            return {"error": "requests 패키지 미설치. pip install requests"}

        url = f"{_BASE_URL}/{api_id}"
        headers = {
            "x-api-key": api_key,
            "User-Agent": _USER_AGENT,
            "Accept": "application/json",
        }
        try:
            resp = _requests.get(url, params=params, headers=headers, timeout=_TIMEOUT)
            if resp.status_code == 401:
                return {"__auth_error__": "401"}
            if resp.status_code == 403:
                return {"__auth_error__": "403"}
            resp.raise_for_status()
            return resp.json()
        except _requests.Timeout:
            return {"__timeout__": True}
        except Exception as e:
            return {"__request_error__": str(e)}

    def _db_save(conn, api_id: str, params: dict, raw: dict):
        """Save raw response to hub_api_responses table."""
        if conn is None or not _HAS_PG:
            return
        try:
            payload_hash = hashlib.md5(
                json.dumps(raw, sort_keys=True, ensure_ascii=False).encode()
            ).hexdigest()
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO hub_api_responses
                        (api_id, params_json, response_json, payload_hash, fetched_at)
                    VALUES (%s, %s, %s, %s, NOW())
                    ON CONFLICT (api_id, payload_hash) DO NOTHING
                    """,
                    (api_id, json.dumps(params, ensure_ascii=False),
                     json.dumps(raw, ensure_ascii=False), payload_hash),
                )
            conn.commit()
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass

    def _db_save_normalized(conn, api_id: str, raw: dict):
        """Upsert into normalized tables based on api_id."""
        if conn is None or not _HAS_PG:
            return
        try:
            with conn.cursor() as cur:
                today_kst = datetime.now(_KST).date().isoformat()

                if api_id in ("ka-002", "ka-004", "ka-005"):
                    items = raw.get("items") or raw.get("data") or []
                    if not isinstance(items, list):
                        items = []
                    for item in items:
                        stock_code = item.get("stock_code") or item.get("code")
                        event_date = item.get("date") or today_kst
                        event_type = item.get("type") or api_id
                        title = item.get("title") or item.get("headline") or ""
                        summary = item.get("summary") or item.get("content") or ""
                        score = item.get("score")
                        cur.execute(
                            """
                            INSERT INTO themalab_stock_events
                                (api_id, stock_code, event_date, event_type,
                                 title, summary, score, created_at)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, NOW())
                            ON CONFLICT (api_id, stock_code, event_date, event_type)
                            DO UPDATE SET title=EXCLUDED.title,
                                          summary=EXCLUDED.summary,
                                          score=EXCLUDED.score,
                                          created_at=NOW()
                            """,
                            (api_id, stock_code, event_date, event_type,
                             title, summary, score),
                        )

                elif api_id in ("ka-006", "ka-007", "ka-008", "ka-009", "ka-010"):
                    summary_text = (
                        raw.get("summary") or raw.get("content")
                        or json.dumps(raw, ensure_ascii=False)[:2000]
                    )
                    report_date = raw.get("date") or today_kst
                    cur.execute(
                        """
                        INSERT INTO themalab_daily_summary
                            (api_id, report_date, summary_text, created_at)
                        VALUES (%s, %s, %s, NOW())
                        ON CONFLICT (api_id, report_date)
                        DO UPDATE SET summary_text=EXCLUDED.summary_text,
                                      created_at=NOW()
                        """,
                        (api_id, report_date, summary_text),
                    )

            conn.commit()
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass

    # ------------------------------------------------------------------ tools

    @registry.tool()
    def themalab_call(api_id: str, params: dict = None) -> dict:
        """
        테마랩 데이터 피드 API를 호출합니다.

        Args:
            api_id: API 식별자. 예) "ka-006" (AI 일일 요약), "ka-002" (종목 뉴스 매칭)
            params: API별 파라미터. 예) {"stock_code": "005930"}

        Returns:
            피드 응답 JSON. error 필드가 있으면 실패.
        """
        if api_id not in _API_CATALOG:
            valid = ", ".join(sorted(_API_CATALOG.keys()))
            return error_response(
                ErrorCode.INVALID_PARAMS,
                f"api_id '{api_id}' 유효하지 않음. 유효값: {valid}",
            )

        meta = _API_CATALOG[api_id]
        params = params or {}

        # validate required params
        missing = [p for p in meta["required_params"] if p not in params]
        if missing:
            return error_response(
                ErrorCode.INVALID_PARAMS,
                f"{api_id} 필수 파라미터 누락: {missing}",
            )

        # check API key
        api_key = os.environ.get("THEMALAB_API_KEY", "").strip()
        if not api_key:
            return error_response(
                "AUTH_MISSING",
                "THEMALAB_API_KEY 환경변수가 설정되지 않았습니다. "
                ".env에 THEMALAB_API_KEY=tt_live_... 형식으로 설정하세요.",
            )

        # rate limit check
        allowed, wait_sec = _rate_limiter.acquire()
        if not allowed:
            return error_response(
                ErrorCode.RATE_LIMITED,
                f"테마랩 API Rate Limit (분당 {_RATE_LIMIT_PER_MINUTE}회). "
                f"{wait_sec:.1f}초 대기 후 재시도하세요.",
            )

        # call API
        raw = _call_feed_api(api_id, params, api_key)

        # handle auth errors
        if "__auth_error__" in raw:
            code = raw["__auth_error__"]
            if code == "401":
                return error_response(
                    "AUTH_INVALID",
                    "THEMALAB_API_KEY가 유효하지 않습니다. 키를 확인하세요.",
                )
            return error_response(
                "AUTH_FORBIDDEN",
                "테마랩 API 접근이 거부되었습니다. 구독 플랜을 확인하세요.",
            )
        if raw.get("__timeout__"):
            return error_response(ErrorCode.TIMEOUT, "테마랩 API 타임아웃 (15s)")
        if "__request_error__" in raw:
            return error_response(ErrorCode.CONNECTION_ERROR, raw["__request_error__"])

        # save to DB (best-effort)
        conn = _get_pg_conn()
        if conn:
            _db_save(conn, api_id, params, raw)
            _db_save_normalized(conn, api_id, raw)

        return ok_response({
            "api_id": api_id,
            "name": meta["name"],
            "params": params,
            "data": raw,
        })

    @registry.tool()
    def themalab_list_functions() -> dict:
        """
        사용 가능한 테마랩 API 목록을 반환합니다.

        Returns:
            api_id 목록, 이름, 필수/선택 파라미터, 설명
        """
        catalog = []
        for aid, meta in sorted(_API_CATALOG.items()):
            catalog.append({
                "api_id": aid,
                "name": meta["name"],
                "required_params": meta["required_params"],
                "optional_params": meta["optional_params"],
                "description": meta["description"],
                "example_params": meta["example"],
            })
        return ok_response({
            "count": len(catalog),
            "rate_limit": f"분당 {_RATE_LIMIT_PER_MINUTE}회",
            "apis": catalog,
        })

    @registry.tool()
    def themalab_get_env_info() -> dict:
        """
        테마랩 API 환경 정보를 확인합니다 (키 노출 없이).

        Returns:
            API 키 설정 여부, 키 형식 (앞 12자 마스크), DB 연결 여부
        """
        api_key = os.environ.get("THEMALAB_API_KEY", "").strip()
        if not api_key:
            key_status = "설정되지 않음"
            key_preview = None
            key_valid_format = False
        else:
            key_status = "설정됨"
            key_preview = api_key[:12] + "..." if len(api_key) > 12 else api_key
            key_valid_format = api_key.startswith("tt_live_") and len(api_key) == 72

        conn = _get_pg_conn()
        db_ok = conn is not None

        return ok_response({
            "api_key_set": bool(api_key),
            "api_key_status": key_status,
            "api_key_preview": key_preview,
            "api_key_valid_format": key_valid_format,
            "key_format_hint": "tt_live_ + 64자 hex (전체 72자)",
            "db_connected": db_ok,
            "requests_available": _HAS_REQUESTS,
            "base_url": _BASE_URL,
            "rate_limit_per_minute": _RATE_LIMIT_PER_MINUTE,
        })

