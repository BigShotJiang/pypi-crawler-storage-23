#!/usr/bin/env python3
"""StockClaw Kit — Watch Engine

Background daemon that polls APIs at intervals, evaluates conditions,
and sends alerts via Telegram/webhook.

Usage:
    stockclaw-kit watch start --config watchlist.json
    stockclaw-kit watch run-once --config watchlist.json
    stockclaw-kit watch init     (create sample config)
"""

import json
import logging
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path

logger = logging.getLogger("watch")

KST = timezone(timedelta(hours=9))


class WatchEngine:
    """Polls registered watchers, evaluates conditions, dispatches alerts."""

    def __init__(self, config, registry):
        self.config = config
        self.registry = registry
        self.state = {}  # {watcher_name: last_alert_epoch}
        self.scan_interval = config.get("scan_interval_sec", 30)
        self.alerts_config = config.get("alerts", {})

    @classmethod
    def from_file(cls, config_path, registry):
        with open(config_path, encoding="utf-8") as f:
            config = json.load(f)
        return cls(config, registry)

    # ── Main loops ────────────────────────────────────────────

    def run_loop(self):
        """Blocking main loop — runs until Ctrl-C or SIGTERM."""
        watchers = self.config.get("watchers", [])
        enabled = [w for w in watchers if w.get("enabled", True)]
        logger.info(f"Watch daemon started. {len(enabled)}/{len(watchers)} watchers enabled.")
        try:
            while True:
                if not self._is_market_hours():
                    logger.debug("Market closed. Sleeping 60s.")
                    time.sleep(60)
                    continue
                self._run_cycle()
                time.sleep(self.scan_interval)
        except KeyboardInterrupt:
            logger.info("Watch daemon stopped (KeyboardInterrupt).")

    def run_once(self):
        """Single cycle — for testing. Returns list of results."""
        logger.info("Running single watch cycle...")
        return self._run_cycle()

    # ── Cycle ─────────────────────────────────────────────────

    def _run_cycle(self):
        results = []
        for watcher in self.config.get("watchers", []):
            if not watcher.get("enabled", True):
                continue
            name = watcher.get("name", "unnamed")
            try:
                raw = self.registry.call(watcher["tool"], watcher.get("params", {}))
                result = json.loads(raw)

                if not result.get("success", False):
                    logger.warning(f"[{name}] tool error: {result.get('error', '?')}")
                    results.append({"watcher": name, "status": "tool_error",
                                    "error": result.get("error")})
                    continue

                matches = self._evaluate(result, watcher.get("condition", {}))

                if matches and self._cooldown_ok(watcher):
                    self._send_alert(watcher, matches)
                    self.state[name] = time.time()
                    results.append({"watcher": name, "status": "alert_sent",
                                    "matches": len(matches)})
                elif matches:
                    results.append({"watcher": name, "status": "cooldown",
                                    "matches": len(matches)})
                else:
                    results.append({"watcher": name, "status": "no_match"})

            except Exception as e:
                logger.warning(f"[{name}] error: {e}")
                results.append({"watcher": name, "status": "error", "error": str(e)})
        return results

    # ── Condition evaluator ───────────────────────────────────

    def _evaluate(self, result, condition):
        if not condition:
            return []

        field = condition.get("field", "")
        op = condition.get("op", ">")
        threshold = float(condition.get("value", 0))

        data = self._find_data_array(result)
        if not data:
            return []

        matches = []
        for item in data:
            raw = item.get(field)
            if raw is None:
                continue
            try:
                val = float(str(raw).replace(",", "").replace("+", "").strip())
            except (ValueError, TypeError):
                continue

            if ((op == ">" and val > threshold) or
                (op == ">=" and val >= threshold) or
                (op == "<" and val < threshold) or
                (op == "<=" and val <= threshold) or
                (op == "==" and val == threshold)):
                matches.append(item)
        return matches

    @staticmethod
    def _find_data_array(result):
        """Locate the list of records inside a tool result."""
        for key in ("data", "items", "output", "records", "results"):
            val = result.get(key)
            if isinstance(val, list) and val:
                return val
        # nested inside 'data' dict
        inner = result.get("data")
        if isinstance(inner, dict):
            for key in ("items", "output", "records"):
                val = inner.get(key)
                if isinstance(val, list) and val:
                    return val
        return []

    # ── Cooldown ──────────────────────────────────────────────

    def _cooldown_ok(self, watcher):
        name = watcher.get("name", "")
        cooldown = watcher.get("cooldown_sec", 300)
        last = self.state.get(name)
        if last is None:
            return True
        return (time.time() - last) >= cooldown

    # ── Alert dispatch ────────────────────────────────────────

    def _send_alert(self, watcher, matches):
        target = self.alerts_config.get("telegram")
        webhook = self.alerts_config.get("webhook")
        alert_type = watcher.get("alert_type", "조건충족")
        name = watcher.get("name", "")

        # Build detail text (top 5)
        lines = []
        for item in matches[:5]:
            sname = (item.get("종목명") or item.get("name") or
                     item.get("stock_name") or "")
            scode = (item.get("종목코드") or item.get("code") or
                     item.get("stock_code") or "")
            price = item.get("현재가", item.get("price", ""))
            change = item.get("등락률", item.get("change_rate", ""))
            lines.append(f"  {sname}({scode}) {price} {change}".strip())
        if len(matches) > 5:
            lines.append(f"  ... 외 {len(matches) - 5}건")
        detail = f"[{name}] {len(matches)}건 감지\n" + "\n".join(lines)

        # Telegram
        if target:
            try:
                first = matches[0] if matches else {}
                self.registry.call("telegram_send_alert", {
                    "target": target,
                    "stock_name": (first.get("종목명") or first.get("name") or name),
                    "stock_code": (first.get("종목코드") or first.get("code") or ""),
                    "alert_type": alert_type,
                    "detail": detail,
                })
                logger.info(f"[{name}] Telegram alert → {target}")
            except Exception as e:
                logger.warning(f"[{name}] Telegram failed: {e}")

        # Webhook
        if webhook:
            try:
                import requests
                requests.post(webhook, json={
                    "watcher": name, "alert_type": alert_type,
                    "matches_count": len(matches), "detail": detail,
                    "matches": matches[:5],
                }, timeout=5)
                logger.info(f"[{name}] Webhook → {webhook}")
            except Exception as e:
                logger.warning(f"[{name}] Webhook failed: {e}")

    # ── Market hours ──────────────────────────────────────────

    @staticmethod
    def _is_market_hours():
        """KST 08:50 ~ 15:40 (weekdays only)."""
        now = datetime.now(KST)
        if now.weekday() >= 5:
            return False
        open_t = now.replace(hour=8, minute=50, second=0, microsecond=0)
        close_t = now.replace(hour=15, minute=40, second=0, microsecond=0)
        return open_t <= now <= close_t


# ── Sample config generator ──────────────────────────────────

def create_sample_config(path):
    """Create sample watchlist.json at *path*."""
    sample = {
        "version": "1.0",
        "scan_interval_sec": 30,
        "alerts": {
            "telegram": "me",
            "webhook": None,
        },
        "watchers": [
            {
                "name": "급등주 스캔",
                "enabled": True,
                "tool": "kiwoom_call_api",
                "params": {"tr_id": "ka10032"},
                "condition": {"field": "등락률", "op": ">", "value": 5},
                "cooldown_sec": 300,
                "alert_type": "급등",
            },
            {
                "name": "삼성전자 목표가 알림",
                "enabled": False,
                "tool": "kiwoom_call_api",
                "params": {"tr_id": "ka10001", "inputs": {"종목코드": "005930"}},
                "condition": {"field": "현재가", "op": ">=", "value": 55000},
                "cooldown_sec": 600,
                "alert_type": "조건충족",
            },
            {
                "name": "외인 대량 순매수",
                "enabled": True,
                "tool": "kiwoom_call_api",
                "params": {"tr_id": "ka10059"},
                "condition": {"field": "순매수량", "op": ">", "value": 100000},
                "cooldown_sec": 600,
                "alert_type": "거래량폭증",
            },
        ],
    }
    Path(path).write_text(
        json.dumps(sample, ensure_ascii=False, indent=2), encoding="utf-8")
    return sample
