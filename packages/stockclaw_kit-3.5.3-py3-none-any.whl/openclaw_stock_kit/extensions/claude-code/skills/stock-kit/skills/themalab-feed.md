# 테마랩 데이터 피드 (themalab-feed)

readinginvestor.com의 데이터 피드 API를 통해 AI 시장 요약, 종목 뉴스 매칭,
테마별 이벤트, 주도주시황 등을 조회한다.

## 기본 호출 형식

```bash
stockclaw-kit call <tool_name> '<JSON>' 2>/dev/null
```

환경 및 API 키 상태 확인:
```bash
stockclaw-kit call themalab_get_env_info '{}' 2>/dev/null
```

---

## 도구 1: themalab_call — 데이터 피드 API 범용 호출

8개 데이터 피드 API를 `api_id`로 분기하여 호출한다.

### 파라미터

| 파라미터 | 타입 | 필수 | 설명 |
|----------|------|------|------|
| `api_id` | string | 필수 | API ID (ka-002 ~ ka-010) |
| `params_json` | string | 선택 | JSON 파라미터 문자열 (기본: "{}") |

### API별 파라미터

| API ID | 기능 | 필수 파라미터 | 선택 파라미터 |
|--------|------|-------------|-------------|
| ka-002 | 종목 뉴스 매칭 | stock_code | limit, since |
| ka-004 | 테마별 이벤트 | — | theme, limit, date |
| ka-005 | 종목별 뉴스 통합 | stock_code | limit, sources |
| ka-006 | AI 일일 요약 | — | date |
| ka-007 | 뉴욕증시 | — | date |
| ka-008 | 주도주시황 | — | date, limit |
| ka-009 | 장전뉴스 | — | date, limit |
| ka-010 | 오후장 특징종목 | — | date, limit |

### CLI 예시

```bash
# AI 일일 요약 (오늘)
stockclaw-kit call themalab_call '{"api_id":"ka-006"}' 2>/dev/null

# 종목 뉴스 매칭 (삼성전자)
stockclaw-kit call themalab_call '{"api_id":"ka-002","params_json":"{\"stock_code\":\"005930\",\"limit\":10}"}' 2>/dev/null

# 장전뉴스
stockclaw-kit call themalab_call '{"api_id":"ka-009"}' 2>/dev/null

# 뉴욕증시
stockclaw-kit call themalab_call '{"api_id":"ka-007"}' 2>/dev/null

# 테마별 이벤트 (2차전지)
stockclaw-kit call themalab_call '{"api_id":"ka-004","params_json":"{\"theme\":\"2차전지\"}"}' 2>/dev/null

# 주도주시황
stockclaw-kit call themalab_call '{"api_id":"ka-008"}' 2>/dev/null

# 오후장 특징종목
stockclaw-kit call themalab_call '{"api_id":"ka-010"}' 2>/dev/null
```

---

## 인증 설정

| 환경변수 | 설명 |
|----------|------|
| `THEMALAB_API_KEY` | readinginvestor.com 데이터 피드 API 키 |

키 형식: `tt_live_` + 64자 hex (총 72자)
발급: https://readinginvestor.com → 프로필 → 내정보 → API 키 탭
Rate Limit: 분당 120회

---

## 사용 시나리오

| 질문 유형 | 권장 API |
|----------|---------|
| "오늘 시장 요약해줘" | ka-006 (AI 일일 요약) |
| "삼성전자 관련 뉴스 뭐 있어?" | ka-002 (종목 뉴스 매칭) |
| "미국장 어땠어?" | ka-007 (뉴욕증시) |
| "오늘 주도주가 뭐야?" | ka-008 (주도주시황) |
| "장전에 무슨 뉴스 있었어?" | ka-009 (장전뉴스) |
| "오후에 특이한 종목 있었어?" | ka-010 (오후장 특징종목) |
| "2차전지 테마 이벤트" | ka-004 (테마별 이벤트) |

### news_search_stock과의 차이

| 비교 | themalab_call (ka-002) | news_search_stock |
|------|----------------------|------------------|
| 데이터 소스 | AI 매칭 + 다중 소스 통합 | 네이버 뉴스 API |
| 분석 수준 | AI 감성분석, 테마 분류 포함 | 원본 뉴스 제공 |
| API 키 | THEMALAB_API_KEY | NAVER_CLIENT_ID |

---

## DB 자동 저장

| API | 정규화 테이블 | 용도 |
|-----|-------------|------|
| ka-002 | `themalab_stock_events` | 종목별 뉴스 매칭 시계열 |
| ka-006 | `themalab_daily_summary` | AI 일일 요약 (일자별 UPSERT) |
| ka-008 | `themalab_leading_stocks` | 주도주시황 추적 |
| 그 외 | `hub_api_responses` | 통합 로그 (JSONB) |
