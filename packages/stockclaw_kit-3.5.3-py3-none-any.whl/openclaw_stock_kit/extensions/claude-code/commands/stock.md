---
name: stock
description: |
  Korean stock data query and analysis command.
  Routes to stock-expert agent for CLI-powered real-time data.

  Examples:
    /stock 삼성전자 현재가
    /stock 급등주 순위
    /stock 내 잔고
    /stock 코스피 지수
    /stock 원달러 환율
argument-hint: "[종목명 또는 질문]"
user-invocable: true
allowed-tools:
  - Bash
  - Read
---

# /stock Command

> Query Korean stock market data via CLI tools

When this command is invoked, delegate the user's query to the `stock-kit:stock-expert` agent.

The agent will:
1. Parse the user's natural language query
2. Determine the best tool to call
3. Execute the tool call
4. Format and present the results

## Quick Reference

| Query | What happens |
|-------|-------------|
| `/stock 삼성전자` | Current price via Kiwoom |
| `/stock 급등주` | Top gainers ranking |
| `/stock 삼성전자 뉴스` | Latest news via Naver |
| `/stock 삼성전자 공시` | DART disclosures |
| `/stock 코스피` | KOSPI index data |
| `/stock 환율` | USD/KRW exchange rate |
| `/stock 잔고` | Account balance |
| `/stock 삼성전자 10주 매수` | Buy order (with confirmation) |
