# 프리미엄 기능

StockClaw Kit 프리미엄 모듈. 라이선스 키 인증 후 6개 고급 함수 사용 가능.

## 라이선스 키 설정

- 형식: `OCKP-XXXXXX-XXXXXX-XXXXXX`
- 구매: https://openclaw.ai/premium
- 입력 방법 (둘 중 하나 선택):
  1. OpenClaw Settings 페이지 → License Key 항목에 입력
  2. 환경변수: `export OPENCLAW_LICENSE_KEY=OCKP-XXXXXX-XXXXXX-XXXXXX`
- **fail-closed 정책**: 서버 미연결 상태에서 grace 기간(24h) 만료 시 기능 비활성화

## 기본 CLI 형식

```bash
stockclaw-kit call premium_call '{"function":"FUNC","params_json":"{...}"}' 2>/dev/null
```

---

## 1. get_morning_briefing — 오전장 브리핑

장전 분석 HTML 또는 요약 데이터 반환. `date` 빈 문자열이면 최신 브리핑.

```bash
# 최신 브리핑
stockclaw-kit call premium_call '{"function":"get_morning_briefing","params_json":"{}"}' 2>/dev/null

# 특정 날짜 지정
stockclaw-kit call premium_call '{"function":"get_morning_briefing","params_json":"{\"date\":\"2026-02-20\"}"}' 2>/dev/null
```

---

## 2. get_afternoon_briefing — 오후장 브리핑

오후장 분석 데이터 반환. `date` 빈 문자열이면 최신.

```bash
# 최신 오후 브리핑
stockclaw-kit call premium_call '{"function":"get_afternoon_briefing","params_json":"{}"}' 2>/dev/null

# 특정 날짜
stockclaw-kit call premium_call '{"function":"get_afternoon_briefing","params_json":"{\"date\":\"2026-02-20\"}"}' 2>/dev/null
```

---

## 3. get_top30_excel — TOP30 주도주 엑셀

`file_type`: `"top30"` | `"top10"` | `"combined"`. 반환: 엑셀 JSON 또는 다운로드 경로.

```bash
# TOP30 전체
stockclaw-kit call premium_call '{"function":"get_top30_excel","params_json":"{\"date\":\"2026-02-20\",\"file_type\":\"top30\"}"}' 2>/dev/null

# TOP10만
stockclaw-kit call premium_call '{"function":"get_top30_excel","params_json":"{\"date\":\"2026-02-20\",\"file_type\":\"top10\"}"}' 2>/dev/null

# TOP30+TOP10 통합본
stockclaw-kit call premium_call '{"function":"get_top30_excel","params_json":"{\"date\":\"2026-02-20\",\"file_type\":\"combined\"}"}' 2>/dev/null
```

---

## 4. get_memo_excel — 메모 엑셀

해당 날짜 메모 엑셀 조회 또는 신규 생성.

```bash
stockclaw-kit call premium_call '{"function":"get_memo_excel","params_json":"{\"date\":\"2026-02-20\"}"}' 2>/dev/null
```

---

## 5. run_backtest — 매매 시나리오 백테스트

`strategy`: `"jongga"` (종가매매) | `"trailing"` (추적손절) | `"swing"`.
반환: 수익률, 거래 내역, 최대낙폭(MDD).

```bash
# 종가매매 — 2025년 전체
stockclaw-kit call premium_call '{"function":"run_backtest","params_json":"{\"strategy\":\"jongga\",\"start_date\":\"2025-01-01\",\"end_date\":\"2025-12-31\",\"params\":{}}"}' 2>/dev/null

# 추적손절 전략
stockclaw-kit call premium_call '{"function":"run_backtest","params_json":"{\"strategy\":\"trailing\",\"start_date\":\"2025-01-01\",\"end_date\":\"2025-12-31\",\"params\":{}}"}' 2>/dev/null

# 스윙 전략
stockclaw-kit call premium_call '{"function":"run_backtest","params_json":"{\"strategy\":\"swing\",\"start_date\":\"2025-01-01\",\"end_date\":\"2025-12-31\",\"params\":{}}"}' 2>/dev/null
```

---

## 6. get_trading_course — 매매방법 강의

`topic` 빈 문자열이면 전체 목록 반환.
Topics: `"jongga_basics"` (종가매매 기초) | `"chart_reading"` (차트 읽기) | `"risk_management"` (리스크 관리) | `"live_trading"` (실전 매매 가이드)

```bash
# 강의 목록 조회
stockclaw-kit call premium_call '{"function":"get_trading_course","params_json":"{\"topic\":\"\"}"}' 2>/dev/null

# 종가매매 기초
stockclaw-kit call premium_call '{"function":"get_trading_course","params_json":"{\"topic\":\"jongga_basics\"}"}' 2>/dev/null

# 리스크 관리
stockclaw-kit call premium_call '{"function":"get_trading_course","params_json":"{\"topic\":\"risk_management\"}"}' 2>/dev/null
```

---

## 오류 코드

| 코드 | 원인 | 조치 |
|------|------|------|
| `LICENSE_MISSING` | 라이선스 키 미설정 | Settings 페이지에서 키 입력 |
| `LICENSE_INVALID` | 키 형식 또는 검증 실패 | 키 재확인 후 재입력 |
| `GRACE_PERIOD` | 서버 미연결 24h 초과 | 네트워크 연결 후 재시도 |
| `NO_DATA` | 해당 날짜 데이터 없음 | 다른 날짜로 재시도 |
