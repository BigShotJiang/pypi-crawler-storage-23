# KIS 해외주식 (kis_overseas_stock) — 34 APIs

한국투자증권 해외주식. 미국·홍콩·중국·일본·베트남 등 주요 해외시장의 시세·주문·계좌를 포함한다.

## 인증
`KIS_APP_KEY` · `KIS_APP_SECRET` · `KIS_ACCOUNT_NO` (한국투자증권 API 포탈 발급)

## 운영 제약
- **Rate Limit**: 조회 8~10/s, 주문 3~5/s 권장. 429 에러 시 지수 백오프 + 서킷 브레이커.
- **차트 데이터**: 1회 최대 **100건**. 3년치 일봉 수집은 기간 쪼개기 + DB 캐싱 필수.
- **주문 시 Hashkey 필수**: POST 주문/정정/취소 시 hashkey 생성 → 헤더 포함.
- **tr_id**: 모의/실전에 따라 다름. 해외 시장별(미국/홍콩/일본 등) tr_id도 다름.
- **주야간 tr_id 변경**: 매수가능금액 등 일부 API는 주간/야간에 따라 tr_id가 다름.
- **실시간 vs 지연**: REST = 조회/배치/히스토리 전용. 실시간(호가/체결)은 WebSocket. 미국 무료시세는 지연일 수 있음.
- **거래소 코드(EXCD)**: `NAS`(나스닥), `NYS`(뉴욕), `AMS`(아멕스) — 종목 마스터로 자동 매핑 권장.
- **미국 거래시간**: 서머타임에 따라 한국시간 기준 변동. 장중 폴링은 장 열렸을 때만.
- **미국 주간주문**: `daytime_order`(장전/장후 거래)는 정규장 `order`와 별도 API.
- **종목 마스터**: 매일 갱신 필요 (상장/분할/합병/심볼 변경 빈번).

## CLI 패턴
```bash
stockclaw-kit call kis_overseas_stock '{"api_type":"API_TYPE","params":{"PARAM":"VALUE"}}' 2>/dev/null
```

## 메타 API
```bash
# 파라미터 스펙 조회
stockclaw-kit call kis_overseas_stock '{"api_type":"find_api_detail","params":{"api_type":"price"}}' 2>/dev/null
# 종목코드 검색
stockclaw-kit call kis_overseas_stock '{"api_type":"find_stock_code","params":{"stock_name":"Apple"}}' 2>/dev/null
```

## market 파라미터 코드

| 코드 | 시장 | 코드 | 시장 |
|---|---|---|---|
| `NAS` | 나스닥 | `HKS` | 홍콩 |
| `NYS` | 뉴욕증권거래소 | `TSE` | 도쿄 |
| `AMS` | 아멕스 | `SHS` | 상해 |
| `HSX` | 호치민 | `SZS` | 심천 |
| `HNX` | 하노이 | | |

---

## 기본시세 (11)

| api_type | 설명 |
|---|---|
| `price` | 해외주식 현재체결가 |
| `price_detail` | 해외주식 현재가상세 |
| `dailyprice` | 해외주식 기간별시세 |
| `inquire_daily_chartprice` | 해외주식 종목/지수/환율기간별시세(일/주/월/년) |
| `inquire_time_itemchartprice` | 해외주식분봉조회 |
| `inquire_asking_price` | 해외주식 현재가 1호가 |
| `quot_inquire_ccnl` | 해외주식 체결추이 |
| `inquire_search` | 해외주식조건검색 |
| `search_info` | 해외주식 상품기본정보 |
| `industry_theme` | 해외주식 업종별시세 |
| `inquire_time_indexchartprice` | 해외지수분봉조회 |

```bash
# 미국주식 현재가 (나스닥)
stockclaw-kit call kis_overseas_stock '{"api_type":"price","params":{"stock_name":"AAPL","market":"NAS"}}' 2>/dev/null
# 기간별시세
stockclaw-kit call kis_overseas_stock '{"api_type":"dailyprice","params":{"stock_name":"TSLA","market":"NAS"}}' 2>/dev/null
# 분봉
stockclaw-kit call kis_overseas_stock '{"api_type":"inquire_time_itemchartprice","params":{"stock_name":"NVDA","market":"NAS"}}' 2>/dev/null
# 홍콩 현재가 (텐센트)
stockclaw-kit call kis_overseas_stock '{"api_type":"price","params":{"stock_name":"00700","market":"HKS"}}' 2>/dev/null
```

## 시세분석 (5)

| api_type | 설명 |
|---|---|
| `updown_rate` | 해외주식 상승율/하락율 |
| `price_fluct` | 해외주식 가격급등락 |
| `trade_vol` | 해외주식 거래량순위 |
| `rights_by_ice` | 해외주식 권리종합 |
| `period_rights` | 해외주식 기간별권리조회 |

```bash
# 나스닥 거래량 상위
stockclaw-kit call kis_overseas_stock '{"api_type":"trade_vol","params":{"market":"NAS"}}' 2>/dev/null
# 가격 급등락
stockclaw-kit call kis_overseas_stock '{"api_type":"price_fluct","params":{"market":"NAS"}}' 2>/dev/null
```

## 주문/계좌 (18) — ⚠️ order* 계열은 실제 거래 발생

| api_type | 설명 |
|---|---|
| `order` | 해외주식 주문 ⚠️ |
| `order_rvsecncl` | 해외주식 정정취소주문 |
| `daytime_order` | 해외주식 미국주간주문 ⚠️ |
| `daytime_order_rvsecncl` | 해외주식 미국주간정정취소 |
| `order_resv` | 해외주식 예약주문접수 ⚠️ |
| `order_resv_list` | 해외주식 예약주문조회 |
| `order_resv_ccnl` | 해외주식 예약주문접수취소 |
| `inquire_balance` | 해외주식 잔고 |
| `inquire_present_balance` | 해외주식 체결기준현재잔고 |
| `inquire_paymt_stdr_balance` | 해외주식 결제기준잔고 |
| `inquire_nccs` | 해외주식 미체결내역 |
| `inquire_ccnl` | 해외주식 주문체결내역 |
| `inquire_psamount` | 해외주식 매수가능금액조회 |
| `inquire_period_trans` | 해외주식 일별거래내역 |
| `inquire_period_profit` | 해외주식 기간손익 |
| `foreign_margin` | 해외증거금 통화별조회 |
| `inquire_algo_ccnl` | 해외주식 지정가체결내역조회 |
| `algo_ordno` | 해외주식 지정가주문번호조회 |

```bash
# 잔고 조회
stockclaw-kit call kis_overseas_stock '{"api_type":"inquire_balance","params":{}}' 2>/dev/null
# 매수가능금액 확인
stockclaw-kit call kis_overseas_stock '{"api_type":"inquire_psamount","params":{"stock_name":"AAPL","market":"NAS"}}' 2>/dev/null
# 매수 ⚠️ (price:"0" = 시장가)
stockclaw-kit call kis_overseas_stock '{"api_type":"order","params":{"stock_name":"AAPL","market":"NAS","order_type":"buy","qty":"1","price":"0"}}' 2>/dev/null
# 매도 ⚠️
stockclaw-kit call kis_overseas_stock '{"api_type":"order","params":{"stock_name":"AAPL","market":"NAS","order_type":"sell","qty":"1","price":"0"}}' 2>/dev/null
# 미국 주간거래(Pre/After market) ⚠️
stockclaw-kit call kis_overseas_stock '{"api_type":"daytime_order","params":{"stock_name":"TSLA","market":"NAS","order_type":"buy","qty":"1","price":"0"}}' 2>/dev/null
```
