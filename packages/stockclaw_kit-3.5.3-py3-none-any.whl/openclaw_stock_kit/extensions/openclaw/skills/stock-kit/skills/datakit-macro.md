# DataKit — ECOS 거시지표 + 환율

한국은행 ECOS API와 한국수출입은행 API를 통해 거시경제 지표 및 환율 데이터를 조회한다.

> **필수 API 키:**
> - `ECOS_API_KEY` — 한국은행 ECOS: https://ecos.bok.or.kr (회원가입 후 발급)
> - `EXIM_API_KEY` — 한국수출입은행: https://www.koreaexim.go.kr (환율 조회용)
>
> 입력: Settings 페이지에서 해당 항목에 입력

**기본 CLI 패턴:**
```bash
stockclaw-kit call datakit_call '{"function":"FUNC","params_json":"{...}"}' 2>/dev/null
```

---

## 1. ecos_indicator — 한국은행 거시지표 (ECOS_API_KEY 필요)

`indicator` 이름으로 지표를 지정한다. 내부적으로 stat_code/item_code로 변환.

| 파라미터 | 타입 | 설명 |
|----------|------|------|
| indicator | string | 지표명 (아래 목록 참조) |
| start | string | 시작일 (월간: `YYYYMM`, 일간: `YYYYMMDD`) |
| end | string | 종료일 (start와 동일 형식) |

### 지원 지표 목록

| indicator 값 | ECOS 코드 | 주기 | 단위 |
|-------------|-----------|------|------|
| `"기준금리"` | 722Y001 / 0101000 | 월간 | % |
| `"CPI"` | 901Y009 / 0 | 월간 | 2020=100 |
| `"GDP성장률"` | 200Y002 / 10111 | 분기 | % |
| `"실업률"` | 901Y027 / 2222 | 월간 | % |
| `"코스피지수"` | 802Y001 / 0001000 | 일간 | pt |

> 날짜 형식: 월간/분기는 `YYYYMM`, 일간은 `YYYYMMDD`

### CLI 예시

**기준금리 (최근 6개월)**
```bash
stockclaw-kit call datakit_call '{"function":"ecos_indicator","params_json":"{\"indicator\":\"기준금리\",\"start\":\"202508\",\"end\":\"202602\"}"}' 2>/dev/null
```

**CPI 소비자물가지수 (최근 1년)**
```bash
stockclaw-kit call datakit_call '{"function":"ecos_indicator","params_json":"{\"indicator\":\"CPI\",\"start\":\"202502\",\"end\":\"202602\"}"}' 2>/dev/null
```

**GDP성장률 (분기)**
```bash
stockclaw-kit call datakit_call '{"function":"ecos_indicator","params_json":"{\"indicator\":\"GDP성장률\",\"start\":\"202401\",\"end\":\"202512\"}"}' 2>/dev/null
```

**실업률 (월간)**
```bash
stockclaw-kit call datakit_call '{"function":"ecos_indicator","params_json":"{\"indicator\":\"실업률\",\"start\":\"202502\",\"end\":\"202602\"}"}' 2>/dev/null
```

**코스피지수 (일간)**
```bash
stockclaw-kit call datakit_call '{"function":"ecos_indicator","params_json":"{\"indicator\":\"코스피지수\",\"start\":\"20260101\",\"end\":\"20260219\"}"}' 2>/dev/null
```

---

## 2. exchange_rate — 환율 조회 (EXIM_API_KEY 필요)

한국수출입은행 기준 환율 데이터. `currency:"all"` 로 전체 통화 일괄 조회 가능.

| 파라미터 | 타입 | 설명 |
|----------|------|------|
| currency | string | 통화코드 또는 `"all"` |

### 지원 통화

| currency 값 | 통화명 |
|-------------|--------|
| `USD` | 미국 달러 |
| `EUR` | 유로 |
| `JPY` | 일본 엔 (100엔 기준) |
| `CNH` | 중국 위안 (역외) |
| `GBP` | 영국 파운드 |
| `AUD` | 호주 달러 |
| `CAD` | 캐나다 달러 |
| `CHF` | 스위스 프랑 |
| `HKD` | 홍콩 달러 |
| `SGD` | 싱가포르 달러 |

반환값: 매매기준율, 전신환매입율, 전신환매도율

### CLI 예시

```bash
# USD 단일 조회
stockclaw-kit call datakit_call '{"function":"exchange_rate","params_json":"{\"currency\":\"USD\"}"}' 2>/dev/null

# 전체 통화 일괄 조회
stockclaw-kit call datakit_call '{"function":"exchange_rate","params_json":"{\"currency\":\"all\"}"}' 2>/dev/null

# JPY (100엔 기준)
stockclaw-kit call datakit_call '{"function":"exchange_rate","params_json":"{\"currency\":\"JPY\"}"}' 2>/dev/null
```

> 주말·공휴일은 직전 영업일 데이터가 반환된다.

---

## 헬퍼 명령어

```bash
# ECOS_API_KEY / EXIM_API_KEY 설정 여부 확인
stockclaw-kit call datakit_get_env_info 2>/dev/null

# 사용 가능한 함수 목록
stockclaw-kit call datakit_list_functions 2>/dev/null
```
