# kiwoom-condition — 조건검색 (WebSocket 기반, 4개 도구)

키움증권 조건검색식을 이용해 종목을 실시간으로 필터링하는 도구 모음이다.
WebSocket 기반으로 동작하며, 일반 REST API(`kiwoom_call_api`)와 다른 전용 도구를 사용한다.

## ⚠️ 키움 WebSocket 연결 공유 정책 (필수)

> **이 도구들은 WebSocket 기반이다.** 키움 서버는 하나의 App Key당 **하나의 WS 세션만 허용**한다.
> 동일 App Key로 새 WS 연결이 생기면 기존 세션이 강제 종료된다 (`R10001`).
>
> **현재 시스템에서 `surge-monitor`가 ka10173 WS 세션을 독점 사용 중이다.**
>
> - `kiwoom_condition_list` (ka10171): 호출할 때마다 **별도 단발성 WS 연결**을 생성 후 즉시 종료. surge-monitor와 충돌 없음.
> - `kiwoom_condition_search` (ka10172): 마찬가지로 단발성 WS. 충돌 없음.
> - `kiwoom_condition_realtime` (ka10173): **⚠️ 새 WS 연결 생성 → surge-monitor 세션 종료 위험!** stock-kit의 `call` 모드는 단발성 조회 후 즉시 종료하므로 실시간 등록 용도로는 부적합. 실시간 모니터링이 필요하면 surge-monitor에 조건을 추가하라.
> - `kiwoom_condition_stop` (ka10174): 단발성 WS. 충돌 없음.
>
> 상세 규칙은 마스터 SKILL.md의 **"키움 토큰/연결 공유 정책"** 참조.

## 사전 요구사항

- KIWOOM_APP_KEY + KIWOOM_SECRET_KEY 환경변수 필요
- 키움증권 HTS에서 조건검색식을 미리 저장해 두어야 한다
- **WebSocket 등록 한도**: 최대 41건 (국내/해외/파생 합산). 끊김 시 자동 재연결+재등록 필요.
- `pip install "stockclaw-kit[kiwoom]"` (websockets>=12 포함)

---

## 도구 목록

| 도구 | 설명 | 주요 파라미터 |
|------|------|--------------|
| kiwoom_condition_list | 저장된 조건검색식 목록 조회 | (없음) |
| kiwoom_condition_search | 조건에 맞는 종목 일회성 조회 | condition_index, condition_name |
| kiwoom_condition_realtime | 실시간 조건검색 등록 | condition_index, condition_name |
| kiwoom_condition_stop | 실시간 조건검색 해제 | condition_index, condition_name |

---

## 사용 흐름

### 1단계: 조건검색식 목록 확인

```bash
stockclaw-kit call kiwoom_condition_list 2>/dev/null
```

응답 예시:
```json
[
  {"index": "0", "name": "급등주"},
  {"index": "1", "name": "거래량급증"},
  {"index": "2", "name": "골든크로스"}
]
```

### 2단계: 조건에 맞는 종목 일회성 조회

```bash
stockclaw-kit call kiwoom_condition_search '{"condition_index":"0","condition_name":"급등주"}' 2>/dev/null
```

응답 예시:
```json
[
  {"종목코드": "A005930", "종목명": "삼성전자", "현재가": "75000", "전일대비": "+500", "등락률": "+0.67%", "거래량": "12345678"},
  {"종목코드": "A000660", "종목명": "SK하이닉스", "현재가": "180000", "전일대비": "+3000", "등락률": "+1.69%", "거래량": "5678901"}
]
```

### 3단계: 실시간 조건검색 등록

```bash
stockclaw-kit call kiwoom_condition_realtime '{"condition_index":"0","condition_name":"급등주"}' 2>/dev/null
```

등록 후 조건을 신규 충족하거나 이탈하는 종목이 실시간으로 수신된다.

### 4단계: 실시간 조건검색 해제

```bash
stockclaw-kit call kiwoom_condition_stop '{"condition_index":"0","condition_name":"급등주"}' 2>/dev/null
```

---

## 응답 필드 설명

실시간 수신 데이터의 주요 필드:

| 필드 | 설명 |
|------|------|
| 9001 | 종목코드 (A+6자리, 예: A005930) |
| 302 | 종목명 |
| 10 | 현재가 |
| 11 | 전일대비 |
| 12 | 등락률 |
| 13 | 거래량 |

종목코드에서 실제 코드 추출: `A005930` → `005930` (앞의 A 제거)

---

## 실전 활용 예시

### 급등주 스캐닝 후 현재가 조회

```bash
# 1. 조건검색식 목록 확인
stockclaw-kit call kiwoom_condition_list 2>/dev/null

# 2. 급등주 조건 종목 조회
stockclaw-kit call kiwoom_condition_search '{"condition_index":"0","condition_name":"급등주"}' 2>/dev/null

# 3. 조회된 종목 중 관심 종목 현재가 확인 (kiwoom-market.md 참조)
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka10001","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

### 실시간 조건검색 등록/해제 패턴

```bash
# 등록
stockclaw-kit call kiwoom_condition_realtime '{"condition_index":"1","condition_name":"거래량급증"}' 2>/dev/null

# 작업 완료 후 반드시 해제
stockclaw-kit call kiwoom_condition_stop '{"condition_index":"1","condition_name":"거래량급증"}' 2>/dev/null
```

---

## 주의사항

- condition_index와 condition_name은 반드시 `kiwoom_condition_list` 조회 결과와 일치해야 한다
- 실시간 조건검색 등록 후 사용이 끝나면 반드시 `kiwoom_condition_stop`으로 해제할 것
- 동시 등록 가능한 조건검색식 수에 키움증권 API 제한이 있을 수 있다
- HTS에 저장된 조건검색식이 없으면 빈 목록이 반환된다
