# kiwoom-specialty — ELW/ETF/대차거래 (23개 API)

키움증권 REST API 중 ELW(주식워런트증권), ETF, 대차거래를 다루는 도구 모음이다.
모든 API는 KIWOOM_APP_KEY + KIWOOM_SECRET_KEY 환경변수가 필요하다.

> **⚠️ 키움 토큰/연결 공유 정책**: 이 도구들은 REST API이므로 자유롭게 호출 가능. 단, 새 WebSocket 연결을 만들지 말 것. 상세 규칙은 마스터 SKILL.md의 "키움 토큰/연결 공유 정책" 참조.

**Rate Limit**: 실전 20회/s, 모의 2회/s. 429 에러 시 지수 백오프 적용.

## 기본 호출 패턴

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"CODE","inputs":{...}}' 2>/dev/null
```

파라미터 스펙 확인:
```bash
stockclaw-kit call kiwoom_api_spec '{"tr_id":"ka10011"}' 2>/dev/null
```

---

## ELW (elw) — 12개

ELW는 특정 기초자산을 미래의 정해진 가격에 사거나 팔 수 있는 권리를 증권화한 상품이다.
종목코드는 5XXXXX 형식(6자리, 5로 시작)이다.

| API 코드 | 설명 |
|----------|------|
| ka10011 | 신주인수권전체시세 |
| ka10048 | ELW 일별민감도지표 |
| ka10050 | ELW 민감도지표 |
| ka30001 | ELW 가격급등락 |
| ka30002 | 거래원별 ELW 순매매상위 |
| ka30003 | ELW LP보유일별추이 |
| ka30004 | ELW 괴리율 |
| ka30005 | ELW 조건검색 |
| ka30009 | ELW 등락율순위 |
| ka30010 | ELW 잔량순위 |
| ka30011 | ELW 근접율 |
| ka30012 | ELW 종목상세정보 |

### ka10011 — 신주인수권전체시세

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka10011","inputs":{"종목코드":"580008"}}' 2>/dev/null
```

현재가, 이론가, 내재변동성, 델타, 감마 등 ELW 전용 지표를 반환한다.

### ka10048 — ELW 일별민감도지표

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka10048","inputs":{"종목코드":"580008"}}' 2>/dev/null
```

### ka10050 — ELW 민감도지표

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka10050","inputs":{"기초자산코드":"005930","권리구분":"콜"}}' 2>/dev/null
```

권리구분: 콜, 풋

### ka30001 — ELW 가격급등락

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka30001","inputs":{"종목코드":"580008"}}' 2>/dev/null
```

발행사, 기초자산, 행사가격, 만기일 등 정적 정보를 반환한다.

### ka30002 — 거래원별 ELW 순매매상위

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka30002","inputs":{"종목코드":"580008"}}' 2>/dev/null
```

델타(Delta), 감마(Gamma), 세타(Theta), 베가(Vega), 로(Rho) 등을 반환한다.

---

## ETF (etf) — 9개

ETF는 특정 지수나 자산을 추종하는 상장 펀드이다.
종목코드는 일반 주식과 동일한 형식(6자리)이다.

| API 코드 | 설명 |
|----------|------|
| ka40001 | ETF 수익율 |
| ka40002 | ETF 종목정보 |
| ka40003 | ETF 일별추이 |
| ka40004 | ETF 전체시세 |
| ka40006 | ETF 시간대별추이 |
| ka40007 | ETF 시간대별체결 |
| ka40008 | ETF 일자별체결 |
| ka40009 | ETF 시간대별체결 |
| ka40010 | ETF 시간대별추이 |

### ka40001 — ETF 수익율

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka40001","inputs":{"종목코드":"069500"}}' 2>/dev/null
```

현재가, NAV, 괴리율, 거래량 등 ETF 전용 지표를 반환한다. (069500=KODEX 200)

### ka40002 — ETF 종목정보

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka40002","inputs":{"종목코드":"069500"}}' 2>/dev/null
```

### ka40003 — ETF 일별추이

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka40003","inputs":{"시장구분":"0"}}' 2>/dev/null
```

### ka40006 — ETF 시간대별추이

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka40006","inputs":{"종목코드":"069500"}}' 2>/dev/null
```

ETF를 구성하는 개별 종목과 비중을 반환한다.

### ka40008 — ETF 일자별체결

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka40008","inputs":{"종목코드":"069500"}}' 2>/dev/null
```

---

## 대차거래 (slb) — 2개

대차거래는 기관·외국인이 공매도를 위해 주식을 빌리는 거래다.
대차잔고 급증은 공매도 세력 유입 신호로 해석된다.

| API 코드 | 설명 |
|----------|------|
| ka10068 | 대차거래추이 |
| ka10069 | 대차거래상위10종목 |

### ka10068 — 대차거래추이

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka10068","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

특정 종목의 대차 잔고 수량 및 추이를 반환한다.

### ka10069 — 대차거래상위10종목

```bash
stockclaw-kit call kiwoom_call_api '{"tr_id":"ka10069","inputs":{"시장구분":"0"}}' 2>/dev/null
```

시장 전체의 대차거래 현황을 반환한다.

---

## API 목록 전체 조회

```bash
stockclaw-kit call kiwoom_list_apis 2>/dev/null
```
