# KIS 파생·채권·ETF/ETN·ELW — 56 APIs

한국투자증권 국내/해외 선물옵션, 장내채권, ETF/ETN, ELW REST API 레퍼런스.

## 인증
`KIS_APP_KEY` · `KIS_APP_SECRET` · `KIS_ACCOUNT_NO` (한국투자증권 API 포탈 발급)

## 운영 제약
- **Rate Limit**: 조회 8~10/s 권장. 주문 3~5/s. 429 에러 시 지수 백오프.
- **주문 시 Hashkey 필수**: POST 주문/정정/취소 시 hashkey 생성 → 헤더 포함.

## 메타 API (모든 툴 공통)
```bash
stockclaw-kit call KIS_TOOL '{"api_type":"find_api_detail","params":{"api_type":"inquire_price"}}' 2>/dev/null
stockclaw-kit call KIS_TOOL '{"api_type":"find_stock_code","params":{"stock_name":"KODEX200"}}' 2>/dev/null
```

---

## 1. 국내선물옵션 (kis_domestic_futureoption) — 20 APIs

```bash
stockclaw-kit call kis_domestic_futureoption '{"api_type":"API_TYPE","params":{}}' 2>/dev/null
```

### 기본시세 (6)
`inquire_price` 시세 · `inquire_asking_price` 시세호가 · `inquire_time_fuopchartprice` 분봉 · `inquire_daily_fuopchartprice` 기간별시세(일/주/월/년) · `exp_price_trend` 일중예상체결추이 · `display_board_top` 기초자산시세

```bash
stockclaw-kit call kis_domestic_futureoption '{"api_type":"inquire_price","params":{"stock_name":"KOSPI200"}}' 2>/dev/null
stockclaw-kit call kis_domestic_futureoption '{"api_type":"inquire_time_fuopchartprice","params":{"stock_name":"KOSPI200"}}' 2>/dev/null
```

### 주문/계좌 (14) — ⚠️ order* 계열은 실제 거래 발생
`order` 주문⚠️ · `order_rvsecncl` 정정취소 · `inquire_balance` 잔고 · `inquire_ngt_balance` (야간)잔고 · `inquire_ccnl` 주문체결내역 · `inquire_ngt_ccnl` (야간)체결내역 · `inquire_psbl_order` 주문가능 · `inquire_psbl_ngt_order` (야간)주문가능 · `inquire_ccnl_bstime` 기준일체결내역 · `inquire_balance_valuation_pl` 잔고평가손익 · `inquire_balance_settlement_pl` 잔고정산손익 · `inquire_deposit` 총자산현황 · `inquire_daily_amount_fee` 기간약정수수료일별 · `ngt_margin_detail` (야간)증거금상세

```bash
stockclaw-kit call kis_domestic_futureoption '{"api_type":"inquire_balance","params":{}}' 2>/dev/null
# 선물 매수 ⚠️
stockclaw-kit call kis_domestic_futureoption '{"api_type":"order","params":{"stock_name":"KOSPI200","order_type":"buy","qty":"1","price":"0"}}' 2>/dev/null
```

---

## 2. 해외선물옵션 (kis_overseas_futureoption) — 19 APIs

```bash
stockclaw-kit call kis_overseas_futureoption '{"api_type":"API_TYPE","params":{}}' 2>/dev/null
```

### 기본시세 (8)
`inquire_price` 선물현재가 · `opt_price` 옵션현재가 · `inquire_asking_price` 선물호가 · `opt_asking_price` 옵션호가 · `inquire_time_futurechartprice` 선물분봉 · `daily_ccnl` 체결추이(일간) · `search_contract_detail` 선물상품기본정보 · `search_opt_detail` 옵션상품기본정보

```bash
stockclaw-kit call kis_overseas_futureoption '{"api_type":"inquire_price","params":{"stock_name":"ES"}}' 2>/dev/null
stockclaw-kit call kis_overseas_futureoption '{"api_type":"opt_price","params":{"stock_name":"ES"}}' 2>/dev/null
```

### 주문/계좌 (11) — ⚠️ order* 계열은 실제 거래 발생
`order` 주문⚠️ · `order_rvsecncl` 정정취소 · `inquire_ccld` 당일주문내역 · `inquire_unpd` 미결제잔고 · `inquire_deposit` 예수금현황 · `inquire_psamount` 주문가능 · `inquire_daily_order` 일별주문내역 · `inquire_daily_ccld` 일별체결내역 · `inquire_period_ccld` 기간손익일별 · `inquire_period_trans` 기간거래내역 · `margin_detail` 증거금상세

```bash
stockclaw-kit call kis_overseas_futureoption '{"api_type":"inquire_unpd","params":{}}' 2>/dev/null
# 해외선물 매수 ⚠️
stockclaw-kit call kis_overseas_futureoption '{"api_type":"order","params":{"stock_name":"ES","order_type":"buy","qty":"1","price":"0"}}' 2>/dev/null
```

---

## 3. 장내채권 (kis_domestic_bond) — 14 APIs

```bash
stockclaw-kit call kis_domestic_bond '{"api_type":"API_TYPE","params":{}}' 2>/dev/null
```

### 기본시세 (7)
`inquire_price` 현재가(시세) · `inquire_asking_price` 현재가(호가) · `inquire_ccnl` 현재가(체결) · `inquire_daily_price` 현재가(일별) · `issue_info` 발행정보 · `search_bond_info` 기본조회 · `avg_unit` 평균단가

### 주문/계좌 (7) — ⚠️ buy/sell은 실제 거래 발생
`buy` 매수⚠️ · `sell` 매도⚠️ · `order_rvsecncl` 정정취소 · `inquire_balance` 잔고 · `inquire_daily_ccld` 주문체결내역 · `inquire_psbl_order` 매수가능 · `inquire_psbl_rvsecncl` 정정취소가능

```bash
stockclaw-kit call kis_domestic_bond '{"api_type":"inquire_price","params":{"stock_name":"국고03875-2803"}}' 2>/dev/null
stockclaw-kit call kis_domestic_bond '{"api_type":"inquire_balance","params":{}}' 2>/dev/null
# 채권 매수 ⚠️
stockclaw-kit call kis_domestic_bond '{"api_type":"buy","params":{"stock_name":"국고03875-2803","qty":"10","price":"0"}}' 2>/dev/null
```

---

## 4. ETF/ETN (kis_etfetn) — 2 APIs

`inquire_price` ETF/ETN현재가 · `nav_comparison_trend` NAV비교추이(종목)

```bash
stockclaw-kit call kis_etfetn '{"api_type":"inquire_price","params":{"stock_name":"KODEX200"}}' 2>/dev/null
stockclaw-kit call kis_etfetn '{"api_type":"nav_comparison_trend","params":{"stock_name":"KODEX200"}}' 2>/dev/null
```

> ETF/ETN 매수·매도 주문은 `kis_domestic_stock`의 `order_cash` 사용.

---

## 5. ELW (kis_elw) — 1 API

`volume_rank` ELW거래량순위

```bash
stockclaw-kit call kis_elw '{"api_type":"volume_rank","params":{}}' 2>/dev/null
```

> ELW 현재가는 `kis_domestic_stock`의 `inquire_elw_price` 사용.
