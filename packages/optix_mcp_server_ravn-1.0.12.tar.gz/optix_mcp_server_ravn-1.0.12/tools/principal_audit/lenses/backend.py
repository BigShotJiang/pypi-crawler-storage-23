"""Backend Developer lens for Principal Audit.

Focuses on API design, data access patterns, business logic organization,
and backend-specific code quality concerns.
"""

from tools.principal_audit.category import FindingCategory, PrincipalLens
from tools.principal_audit.lenses.base import BaseLens, LensConfig, LensRule


class BackendLens(BaseLens):
    """Backend Developer perspective for code quality analysis.

    Focuses on:
    - Service layer complexity
    - Data access patterns
    - API design quality
    - Business logic organization
    """

    @property
    def lens_type(self) -> PrincipalLens:
        return PrincipalLens.BACKEND

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=PrincipalLens.BACKEND,
            display_name="Backend Developer",
            description="API design, data access, business logic patterns",
            complexity_rules=[
                LensRule(
                    id="BE-C001",
                    category=FindingCategory.COMPLEXITY,
                    name="Service Method Complexity",
                    description="Service methods with high cyclomatic complexity",
                    severity_default="high",
                    check_guidance=[
                        "Calculate cyclomatic complexity (>10 is concerning)",
                        "Count decision points (if/switch/try-catch)",
                        "Identify methods with >5 parameters",
                        "Look for deeply nested logic (>3 levels)",
                    ],
                ),
                LensRule(
                    id="BE-C002",
                    category=FindingCategory.COMPLEXITY,
                    name="Controller Complexity",
                    description="API controllers with too much business logic",
                    severity_default="critical",
                    check_guidance=[
                        "Check controller method line count (>50 is high)",
                        "Look for business logic in controllers",
                        "Identify controllers doing data transformation",
                        "Find controllers with multiple service calls",
                    ],
                ),
                LensRule(
                    id="BE-C003",
                    category=FindingCategory.COMPLEXITY,
                    name="Query Complexity",
                    description="Database queries with excessive complexity",
                    severity_default="high",
                    check_guidance=[
                        "Count JOIN operations (>3 is concerning)",
                        "Look for subqueries in WHERE clauses",
                        "Identify queries with >5 conditions",
                        "Check for complex aggregations",
                    ],
                ),
            ],
            dry_rules=[
                LensRule(
                    id="BE-D001",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Duplicated Service Logic",
                    description="Similar business logic in multiple services",
                    severity_default="high",
                    check_guidance=[
                        "Find similar validation patterns across services",
                        "Look for repeated calculation logic",
                        "Identify duplicated error handling",
                        "Check for similar data transformation code",
                    ],
                ),
                LensRule(
                    id="BE-D002",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Repeated Query Patterns",
                    description="Similar database queries in different locations",
                    severity_default="medium",
                    check_guidance=[
                        "Find similar WHERE clause patterns",
                        "Look for repeated JOIN sequences",
                        "Identify duplicated query builders",
                        "Check for similar ORM queries",
                    ],
                ),
                LensRule(
                    id="BE-D003",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Duplicated API Response Handling",
                    description="Similar response formatting across endpoints",
                    severity_default="medium",
                    check_guidance=[
                        "Look for repeated response structures",
                        "Find similar error response patterns",
                        "Identify duplicated pagination logic",
                        "Check for repeated serialization code",
                    ],
                ),
            ],
            coupling_rules=[
                LensRule(
                    id="BE-CP001",
                    category=FindingCategory.COUPLING,
                    name="Service-to-Service Coupling",
                    description="Direct service dependencies instead of events/interfaces",
                    severity_default="high",
                    check_guidance=[
                        "Count direct service injections",
                        "Look for circular service dependencies",
                        "Identify services with >5 dependencies",
                        "Check for missing interface abstractions",
                    ],
                ),
                LensRule(
                    id="BE-CP002",
                    category=FindingCategory.COUPLING,
                    name="Database Schema Coupling",
                    description="Business logic tightly coupled to DB schema",
                    severity_default="high",
                    check_guidance=[
                        "Find raw SQL in service layer",
                        "Look for column names in business logic",
                        "Identify missing repository pattern",
                        "Check for schema assumptions in code",
                    ],
                ),
                LensRule(
                    id="BE-CP003",
                    category=FindingCategory.COUPLING,
                    name="External Service Coupling",
                    description="Direct calls to external APIs without abstraction",
                    severity_default="medium",
                    check_guidance=[
                        "Find HTTP clients in business services",
                        "Look for external URLs in service code",
                        "Identify missing adapter/gateway pattern",
                        "Check for external response structures in core",
                    ],
                ),
            ],
            separation_rules=[
                LensRule(
                    id="BE-S001",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Business Logic in Controllers",
                    description="Controllers containing business rules",
                    severity_default="critical",
                    check_guidance=[
                        "Find if/else business decisions in controllers",
                        "Look for calculations in controller methods",
                        "Identify domain rules in request handlers",
                        "Check for missing service layer extraction",
                    ],
                ),
                LensRule(
                    id="BE-S002",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Data Access in Services",
                    description="Services directly accessing database",
                    severity_default="medium",
                    check_guidance=[
                        "Find SQL/ORM queries in service methods",
                        "Look for transaction management in services",
                        "Identify missing repository pattern",
                        "Check for database-specific code in services",
                    ],
                ),
                LensRule(
                    id="BE-S003",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Infrastructure in Domain",
                    description="Infrastructure concerns mixed with domain logic",
                    severity_default="high",
                    check_guidance=[
                        "Find logging in domain entities",
                        "Look for caching logic in domain",
                        "Identify message queue code in services",
                        "Check for file I/O in business logic",
                    ],
                ),
            ],
            maintainability_rules=[
                LensRule(
                    id="BE-M001",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Missing API Documentation",
                    description="Endpoints without proper documentation",
                    severity_default="medium",
                    check_guidance=[
                        "Check for OpenAPI/Swagger annotations",
                        "Look for undocumented request/response types",
                        "Identify missing error documentation",
                        "Find endpoints without examples",
                    ],
                ),
                LensRule(
                    id="BE-M002",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Inconsistent Error Handling",
                    description="Varying error handling patterns across services",
                    severity_default="high",
                    check_guidance=[
                        "Find different exception types for similar errors",
                        "Look for inconsistent error responses",
                        "Identify mixed error handling strategies",
                        "Check for uncaught exceptions",
                    ],
                ),
                LensRule(
                    id="BE-M003",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Magic Values in Business Logic",
                    description="Hardcoded values in service logic",
                    severity_default="medium",
                    check_guidance=[
                        "Find hardcoded threshold values",
                        "Look for magic numbers in calculations",
                        "Identify string literals for status codes",
                        "Check for hardcoded configuration",
                    ],
                ),
            ],
        )
