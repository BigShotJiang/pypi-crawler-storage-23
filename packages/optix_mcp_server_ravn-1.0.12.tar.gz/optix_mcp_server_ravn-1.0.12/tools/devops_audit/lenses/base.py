"""Base lens class and data structures for DevOps audit lenses."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from tools.devops_audit.domains import DevOpsCategory, DevOpsLens


@dataclass
class LensRule:
    """A single rule within a lens configuration."""

    id: str
    category: DevOpsCategory
    name: str
    description: str
    severity_default: str
    check_guidance: list[str] = field(default_factory=list)


@dataclass
class LensConfig:
    """Configuration for a DevOps audit lens."""

    lens: DevOpsLens
    display_name: str
    description: str
    docker_rules: list[LensRule] = field(default_factory=list)
    cicd_rules: list[LensRule] = field(default_factory=list)
    dependency_rules: list[LensRule] = field(default_factory=list)

    def get_rules_for_category(self, category: DevOpsCategory) -> list[LensRule]:
        """Get rules for a specific category."""
        mapping = {
            DevOpsCategory.DOCKERFILE: self.docker_rules,
            DevOpsCategory.CICD: self.cicd_rules,
            DevOpsCategory.DEPENDENCY: self.dependency_rules,
        }
        return mapping.get(category, [])

    def get_all_rules(self) -> list[LensRule]:
        """Get all rules across all categories."""
        return self.docker_rules + self.cicd_rules + self.dependency_rules

    def get_rule_ids(self) -> set[str]:
        """Get set of all rule IDs."""
        return {rule.id for rule in self.get_all_rules()}


class BaseLens(ABC):
    """Abstract base class for DevOps audit lenses."""

    @property
    @abstractmethod
    def lens_type(self) -> DevOpsLens:
        """Return the lens type enum."""
        pass

    @abstractmethod
    def get_config(self) -> LensConfig:
        """Return the lens configuration with rules."""
        pass

    def get_docker_guidance(self) -> list[list[str]]:
        """Get Docker-specific check guidance."""
        return [rule.check_guidance for rule in self.get_config().docker_rules]

    def get_cicd_guidance(self) -> list[list[str]]:
        """Get CI/CD-specific check guidance."""
        return [rule.check_guidance for rule in self.get_config().cicd_rules]

    def get_dependency_guidance(self) -> list[list[str]]:
        """Get dependency-specific check guidance."""
        return [rule.check_guidance for rule in self.get_config().dependency_rules]

    def get_required_actions(self, category: DevOpsCategory) -> list[str]:
        """Get flattened list of required actions for a category."""
        rules = self.get_config().get_rules_for_category(category)
        actions = []
        for rule in rules:
            actions.extend(rule.check_guidance)
        return actions

    def get_rule_summary(self) -> dict[str, int]:
        """Get count of rules by category."""
        config = self.get_config()
        return {
            "dockerfile": len(config.docker_rules),
            "cicd": len(config.cicd_rules),
            "dependency": len(config.dependency_rules),
            "total": len(config.get_all_rules()),
        }
