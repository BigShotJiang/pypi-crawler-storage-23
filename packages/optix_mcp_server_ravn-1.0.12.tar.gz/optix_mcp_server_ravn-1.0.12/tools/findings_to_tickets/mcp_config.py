import json
import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class MCPServerConfig:
    command: str
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)


def load_mcp_servers_config() -> dict[str, MCPServerConfig]:
    servers: dict[str, MCPServerConfig] = {}

    config_file = Path.home() / ".optix" / "mcp-servers.json"
    if config_file.exists():
        try:
            with open(config_file) as f:
                data = json.load(f)
            for name, cfg in data.items():
                if isinstance(cfg, dict) and "command" in cfg:
                    servers[name] = MCPServerConfig(
                        command=cfg["command"],
                        args=cfg.get("args", []),
                        env=cfg.get("env", {}),
                    )
        except (json.JSONDecodeError, OSError):
            pass

    linear_command = os.environ.get("OPTIX_MCP_LINEAR_COMMAND", "").strip()
    if linear_command:
        args_str = os.environ.get("OPTIX_MCP_LINEAR_ARGS", "")
        args = [a.strip() for a in args_str.split(",") if a.strip()]
        env = {}
        api_key = os.environ.get("OPTIX_MCP_LINEAR_ACCESS_TOKEN", "").strip()
        if api_key:
            env["LINEAR_ACCESS_TOKEN"] = api_key
        servers["linear"] = MCPServerConfig(command=linear_command, args=args, env=env)

    jira_command = os.environ.get("OPTIX_MCP_JIRA_COMMAND", "").strip()
    if jira_command:
        args_str = os.environ.get("OPTIX_MCP_JIRA_ARGS", "")
        args = [a.strip() for a in args_str.split(",") if a.strip()]
        env = {}
        for var, key in [
            ("OPTIX_MCP_JIRA_API_TOKEN", "JIRA_API_TOKEN"),
            ("OPTIX_MCP_JIRA_USER_EMAIL", "JIRA_USER_EMAIL"),
            ("OPTIX_MCP_JIRA_INSTANCE_URL", "JIRA_INSTANCE_URL"),
        ]:
            val = os.environ.get(var, "").strip()
            if val:
                env[key] = val
        servers["jira"] = MCPServerConfig(command=jira_command, args=args, env=env)

    return servers


def get_available_platforms() -> dict[str, bool]:
    servers = load_mcp_servers_config()
    return {
        "linear": "linear" in servers,
        "jira": "jira" in servers,
    }


def get_server_config(platform: str) -> MCPServerConfig | None:
    servers = load_mcp_servers_config()
    return servers.get(platform)
