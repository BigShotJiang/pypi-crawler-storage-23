"""Visual Accessibility lens for Accessibility Audit.

Focuses on accessibility for users with visual impairments:
- Color contrast
- Text sizing and zoom
- Color independence
- Visual clarity
"""

from tools.a11y_audit.domains import A11yLens, AccessibilityStepDomain
from tools.a11y_audit.lenses.base import BaseLens, LensConfig, LensRule


class VisualLens(BaseLens):
    """Visual Accessibility perspective.

    Examines code from the viewpoint of users with low vision or color blindness,
    focusing on color contrast, text sizing, and visual accessibility.
    """

    @property
    def lens_type(self) -> A11yLens:
        return A11yLens.VISUAL

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=A11yLens.VISUAL,
            display_name="Visual Accessibility",
            description="Color contrast, text sizing, color independence, zoom",
            structure_rules=[
                LensRule(
                    id="VIS-S001",
                    domain=AccessibilityStepDomain.STRUCTURE,
                    name="Responsive Design",
                    description="Verify layout adapts to zoom and text sizing",
                    wcag_criterion="1.4.10",
                    wcag_level="AA",
                    severity_default="medium",
                    check_guidance=[
                        "Check layout at 400% zoom",
                        "Verify no horizontal scrolling at 320px width",
                        "Check content reflows properly",
                    ],
                ),
            ],
            aria_rules=[],
            keyboard_rules=[],
            focus_rules=[
                LensRule(
                    id="VIS-F001",
                    domain=AccessibilityStepDomain.FOCUS_MANAGEMENT,
                    name="Focus Indicator Contrast",
                    description="Verify focus indicators are visually distinct",
                    wcag_criterion="2.4.7",
                    wcag_level="AA",
                    severity_default="high",
                    check_guidance=[
                        "Check focus indicator contrast against background",
                        "Verify focus is visible on all backgrounds",
                        "Check focus ring thickness and style",
                    ],
                ),
            ],
            color_rules=[
                LensRule(
                    id="VIS-C001",
                    domain=AccessibilityStepDomain.COLOR_CONTRAST,
                    name="Text Contrast",
                    description="Verify text meets contrast requirements",
                    wcag_criterion="1.4.3",
                    wcag_level="AA",
                    severity_default="critical",
                    check_guidance=[
                        "Check normal text has 4.5:1 contrast ratio",
                        "Check large text has 3:1 contrast ratio",
                        "Verify contrast in all color themes",
                        "Check placeholder text contrast",
                    ],
                ),
                LensRule(
                    id="VIS-C002",
                    domain=AccessibilityStepDomain.COLOR_CONTRAST,
                    name="Non-Text Contrast",
                    description="Verify UI components meet contrast requirements",
                    wcag_criterion="1.4.11",
                    wcag_level="AA",
                    severity_default="high",
                    check_guidance=[
                        "Check button borders have 3:1 contrast",
                        "Verify icon contrast against backgrounds",
                        "Check form input borders are visible",
                        "Verify chart/graph element contrast",
                    ],
                ),
                LensRule(
                    id="VIS-C003",
                    domain=AccessibilityStepDomain.COLOR_CONTRAST,
                    name="Color Independence",
                    description="Verify information not conveyed by color alone",
                    wcag_criterion="1.4.1",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Check error states use more than red color",
                        "Verify links distinguishable without color",
                        "Check required fields have non-color indicator",
                        "Verify charts use patterns, not just colors",
                    ],
                ),
                LensRule(
                    id="VIS-C004",
                    domain=AccessibilityStepDomain.COLOR_CONTRAST,
                    name="Tailwind Color Classes",
                    description="Check Tailwind CSS color combinations",
                    wcag_criterion="1.4.3",
                    wcag_level="AA",
                    severity_default="medium",
                    check_guidance=[
                        "Review text-* and bg-* class combinations",
                        "Check for low contrast Tailwind pairings",
                        "Verify dark mode contrast values",
                    ],
                ),
            ],
            semantic_rules=[
                LensRule(
                    id="VIS-SM001",
                    domain=AccessibilityStepDomain.SEMANTIC_HTML,
                    name="Text Sizing",
                    description="Verify text can be resized without loss of function",
                    wcag_criterion="1.4.4",
                    wcag_level="AA",
                    severity_default="high",
                    check_guidance=[
                        "Check text uses relative units (rem, em)",
                        "Verify 200% text zoom doesn't break layout",
                        "Check no text is clipped when enlarged",
                    ],
                ),
                LensRule(
                    id="VIS-SM002",
                    domain=AccessibilityStepDomain.SEMANTIC_HTML,
                    name="Text Spacing",
                    description="Verify content adapts to text spacing changes",
                    wcag_criterion="1.4.12",
                    wcag_level="AA",
                    severity_default="medium",
                    check_guidance=[
                        "Check line height can be 1.5x",
                        "Verify paragraph spacing can be 2x",
                        "Check letter spacing adjustments work",
                    ],
                ),
            ],
        )
