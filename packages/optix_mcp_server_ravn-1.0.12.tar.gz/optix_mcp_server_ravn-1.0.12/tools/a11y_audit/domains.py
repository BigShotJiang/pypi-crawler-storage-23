"""Accessibility audit step domains and lens definitions."""

from enum import Enum
from typing import Optional


class A11yLens(str, Enum):
    """Available lenses for Accessibility Audit.

    Each lens represents a specialized perspective for accessibility analysis:
    - SCREENREADER: Screen Reader User perspective
    - KEYBOARD: Keyboard-Only User perspective
    - VISUAL: Visual Accessibility (low vision, color blindness)
    - WCAG: WCAG Compliance Auditor perspective
    - COMPREHENSIVE: Full accessibility review (default)
    """

    SCREENREADER = "screenreader"
    KEYBOARD = "keyboard"
    VISUAL = "visual"
    WCAG = "wcag"
    COMPREHENSIVE = "comprehensive"

    @classmethod
    def from_string(cls, value: Optional[str]) -> "A11yLens":
        """Convert string to A11yLens enum.

        Args:
            value: String lens name or None

        Returns:
            A11yLens enum value, defaults to COMPREHENSIVE
        """
        if not value:
            return cls.COMPREHENSIVE
        normalized = value.lower().strip()
        for lens in cls:
            if lens.value == normalized:
                return lens
        return cls.COMPREHENSIVE

    @property
    def display_name(self) -> str:
        """Human-readable name for the lens."""
        names = {
            A11yLens.SCREENREADER: "Screen Reader User",
            A11yLens.KEYBOARD: "Keyboard-Only User",
            A11yLens.VISUAL: "Visual Accessibility",
            A11yLens.WCAG: "WCAG Compliance",
            A11yLens.COMPREHENSIVE: "Comprehensive",
        }
        return names.get(self, self.value.title())

    @property
    def description(self) -> str:
        """Description of what this lens focuses on."""
        descriptions = {
            A11yLens.SCREENREADER: "ARIA labels, semantic HTML, announcements, alt text",
            A11yLens.KEYBOARD: "Tab order, focus management, keyboard shortcuts, traps",
            A11yLens.VISUAL: "Color contrast, text sizing, color independence, zoom",
            A11yLens.WCAG: "WCAG 2.1/2.2 success criteria verification",
            A11yLens.COMPREHENSIVE: "Full accessibility review covering all user needs",
        }
        return descriptions.get(self, "Accessibility analysis")


class AccessibilityStepDomain(Enum):
    """Represents the 6 accessibility audit domains aligned with WCAG principles."""

    STRUCTURE = "structure"
    ARIA_LABELS = "aria_labels"
    KEYBOARD_NAV = "keyboard_nav"
    FOCUS_MANAGEMENT = "focus_management"
    COLOR_CONTRAST = "color_contrast"
    SEMANTIC_HTML = "semantic_html"

    @classmethod
    def from_step_number(cls, step: int) -> "AccessibilityStepDomain":
        """Get domain for a given step number (1-6)."""
        mapping = {
            1: cls.STRUCTURE,
            2: cls.ARIA_LABELS,
            3: cls.KEYBOARD_NAV,
            4: cls.FOCUS_MANAGEMENT,
            5: cls.COLOR_CONTRAST,
            6: cls.SEMANTIC_HTML,
        }
        return mapping.get(step, cls.STRUCTURE)

    def description(self) -> str:
        """Return human-readable description of this domain."""
        descriptions = {
            self.STRUCTURE: "Identify UI framework, component structure, and interactive elements",
            self.ARIA_LABELS: "Check ARIA labels, roles, states, and landmark regions",
            self.KEYBOARD_NAV: "Verify keyboard accessibility, tab order, and keyboard traps",
            self.FOCUS_MANAGEMENT: "Validate focus handling, visible indicators, and focus restoration",
            self.COLOR_CONTRAST: "Check text/background contrast ratios and color accessibility",
            self.SEMANTIC_HTML: "Verify semantic HTML5 elements, headings, and WCAG compliance",
        }
        return descriptions[self]
