"""Compliance Officer lens for Security Audit.

Focuses on regulatory and compliance requirements:
- PII and sensitive data handling
- GDPR, HIPAA, PCI-DSS compliance
- Data retention and consent
- Privacy by design
"""

from tools.security_audit.domains import SecurityLens, SecurityStepDomain
from tools.security_audit.lenses.base import BaseLens, LensConfig, LensRule


class ComplianceLens(BaseLens):
    """Compliance/Privacy Officer security perspective.

    Examines code from the viewpoint of a compliance officer concerned with
    regulatory requirements, data privacy, and audit compliance.
    """

    @property
    def lens_type(self) -> SecurityLens:
        return SecurityLens.COMPLIANCE

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=SecurityLens.COMPLIANCE,
            display_name="Compliance",
            description="Regulatory: PII exposure, GDPR, HIPAA, PCI-DSS, data handling",
            reconnaissance_rules=[
                LensRule(
                    id="CO-R001",
                    domain=SecurityStepDomain.RECONNAISSANCE,
                    name="Data Classification Discovery",
                    description="Identify and classify data types handled",
                    severity_default="info",
                    check_guidance=[
                        "Identify PII data types (names, emails, SSN, etc.)",
                        "Map PHI (Protected Health Information) handling",
                        "Document financial data processing",
                        "Identify data storage locations",
                    ],
                ),
                LensRule(
                    id="CO-R002",
                    domain=SecurityStepDomain.RECONNAISSANCE,
                    name="Regulatory Scope",
                    description="Determine applicable regulatory requirements",
                    severity_default="info",
                    check_guidance=[
                        "Determine if GDPR applies (EU user data)",
                        "Check HIPAA requirements (healthcare data)",
                        "Identify PCI-DSS scope (payment processing)",
                        "Note geographic data residency requirements",
                    ],
                ),
            ],
            auth_rules=[
                LensRule(
                    id="CO-A001",
                    domain=SecurityStepDomain.AUTH_AUTHZ,
                    name="Access Control for Sensitive Data",
                    description="Verify access controls for regulated data",
                    severity_default="high",
                    check_guidance=[
                        "Verify principle of least privilege for PII access",
                        "Check audit logging for sensitive data access",
                        "Review role-based access to regulated data",
                    ],
                ),
                LensRule(
                    id="CO-A002",
                    domain=SecurityStepDomain.AUTH_AUTHZ,
                    name="User Consent Verification",
                    description="Verify consent mechanisms for data processing",
                    severity_default="high",
                    check_guidance=[
                        "Check for consent collection implementation",
                        "Verify consent is stored and can be revoked",
                        "Review data processing based on consent status",
                    ],
                ),
            ],
            input_rules=[
                LensRule(
                    id="CO-I001",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="PII Input Handling",
                    description="Review handling of PII during input",
                    severity_default="high",
                    check_guidance=[
                        "Verify PII validation and sanitization",
                        "Check for PII in logs during input processing",
                        "Review error messages for PII exposure",
                    ],
                ),
            ],
            owasp_rules=[
                LensRule(
                    id="CO-O001",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="Sensitive Data Exposure (A02)",
                    description="Check for improper sensitive data handling",
                    severity_default="critical",
                    check_guidance=[
                        "Verify encryption for PII at rest",
                        "Check encryption in transit (TLS)",
                        "Review data masking implementations",
                        "Check for sensitive data in URLs",
                    ],
                ),
                LensRule(
                    id="CO-O002",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="Logging and Monitoring (A09)",
                    description="Verify audit logging for compliance",
                    severity_default="high",
                    check_guidance=[
                        "Check for security event logging",
                        "Verify PII is masked in logs",
                        "Review log retention periods",
                        "Check for tamper-evident logging",
                    ],
                ),
            ],
            dependency_rules=[
                LensRule(
                    id="CO-D001",
                    domain=SecurityStepDomain.DEPENDENCIES,
                    name="Third-Party Data Sharing",
                    description="Review third-party data sharing practices",
                    severity_default="high",
                    check_guidance=[
                        "Identify data sent to third-party services",
                        "Check analytics tracking for PII",
                        "Review data processing agreements in code comments",
                    ],
                ),
            ],
            compliance_rules=[
                LensRule(
                    id="CO-C001",
                    domain=SecurityStepDomain.COMPLIANCE,
                    name="GDPR Compliance",
                    description="Verify GDPR compliance requirements",
                    severity_default="high",
                    check_guidance=[
                        "Check for data subject rights implementation (access, delete)",
                        "Verify data portability functionality",
                        "Review data processing documentation",
                        "Check for privacy policy references",
                    ],
                ),
                LensRule(
                    id="CO-C002",
                    domain=SecurityStepDomain.COMPLIANCE,
                    name="HIPAA Compliance",
                    description="Verify HIPAA compliance for healthcare data",
                    severity_default="critical",
                    check_guidance=[
                        "Check PHI encryption requirements",
                        "Verify access controls for healthcare data",
                        "Review audit trail implementation",
                        "Check for BAA requirements in integrations",
                    ],
                ),
                LensRule(
                    id="CO-C003",
                    domain=SecurityStepDomain.COMPLIANCE,
                    name="PCI-DSS Compliance",
                    description="Verify PCI-DSS compliance for payment data",
                    severity_default="critical",
                    check_guidance=[
                        "Check for credit card data handling",
                        "Verify tokenization usage",
                        "Review payment processing security",
                        "Check for card data in logs",
                    ],
                ),
                LensRule(
                    id="CO-C004",
                    domain=SecurityStepDomain.COMPLIANCE,
                    name="Data Retention",
                    description="Verify data retention policy implementation",
                    severity_default="medium",
                    check_guidance=[
                        "Check for data retention policies in code",
                        "Verify automated data deletion",
                        "Review backup retention periods",
                    ],
                ),
            ],
        )
