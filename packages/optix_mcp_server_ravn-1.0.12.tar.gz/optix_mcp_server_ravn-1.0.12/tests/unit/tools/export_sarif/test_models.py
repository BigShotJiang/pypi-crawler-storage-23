"""Unit tests for export_sarif data models."""

from pathlib import Path

from tools.export_sarif.models import SarifExportError, SarifExportResponse
from tools.generate_report.models import AuditLens


class TestSarifExportResponse:
    """Tests for SarifExportResponse dataclass."""

    def test_to_dict_contains_all_fields(self):
        response = SarifExportResponse(
            success=True,
            sarif_file_path=Path("/reports/SARIF_SECURITY_1.sarif.json"),
            findings_count=5,
            lens=AuditLens.SECURITY,
            message="SARIF exported successfully",
            rules_count=3,
        )
        data = response.to_dict()

        assert data["success"] is True
        assert data["sarif_file_path"] == "/reports/SARIF_SECURITY_1.sarif.json"
        assert data["findings_count"] == 5
        assert data["lens"] == "SECURITY"
        assert data["message"] == "SARIF exported successfully"
        assert data["rules_count"] == 3

    def test_to_dict_path_converted_to_string(self):
        response = SarifExportResponse(
            success=True,
            sarif_file_path=Path("/project/reports/SARIF_A11Y_2.sarif.json"),
            findings_count=10,
            lens=AuditLens.A11Y,
            message="Done",
        )
        data = response.to_dict()

        assert isinstance(data["sarif_file_path"], str)
        assert data["sarif_file_path"] == "/project/reports/SARIF_A11Y_2.sarif.json"

    def test_default_rules_count_is_zero(self):
        response = SarifExportResponse(
            success=True,
            sarif_file_path=Path("/reports/test.sarif.json"),
            findings_count=0,
            lens=AuditLens.DEVOPS,
            message="No findings",
        )
        assert response.rules_count == 0

    def test_all_lens_types_supported(self):
        for lens in AuditLens:
            response = SarifExportResponse(
                success=True,
                sarif_file_path=Path(f"/reports/SARIF_{lens.value}_1.sarif.json"),
                findings_count=1,
                lens=lens,
                message="Success",
            )
            data = response.to_dict()
            assert data["lens"] == lens.value


class TestSarifExportError:
    """Tests for SarifExportError dataclass."""

    def test_to_dict_contains_all_fields(self):
        error = SarifExportError(
            success=False,
            error="No audit workflow found",
            error_type="NoAuditFound",
        )
        data = error.to_dict()

        assert data["success"] is False
        assert data["error"] == "No audit workflow found"
        assert data["error_type"] == "NoAuditFound"

    def test_default_values(self):
        error = SarifExportError()

        assert error.success is False
        assert error.error == ""
        assert error.error_type == "GeneralError"

    def test_error_types(self):
        error_types = [
            "GeneralError",
            "NoAuditFound",
            "WorkflowIncomplete",
            "PermissionDenied",
            "FileSystemError",
            "RetryExhausted",
            "UnknownLens",
        ]
        for error_type in error_types:
            error = SarifExportError(
                error="Test error",
                error_type=error_type,
            )
            data = error.to_dict()
            assert data["error_type"] == error_type
