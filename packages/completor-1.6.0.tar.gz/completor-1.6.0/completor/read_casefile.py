from __future__ import annotations

import re
from collections.abc import Mapping
from io import StringIO
from typing import Any

import numpy as np
import numpy.typing as npt
import pandas as pd

from completor import input_validation, parse
from completor.constants import Content, Headers, ICVMethod, Keywords, Method, WellData
from completor.exceptions.clean_exceptions import CompletorError
from completor.exceptions.exceptions import CaseReaderFormatError
from completor.logger import logger
from completor.parse import locate_keyword
from completor.utils import clean_file_lines, sort_string_with_assign_first


class ReadCasefile:
    """Class for reading Completor case files.

    This class reads the case/input file of the Completor program.
    It reads the following keywords:
    COMPLETION, SEGMENTLENGTH, JOINTLENGTH, AUTONOMOUS_INFLOW_CONTROL_DEVICE, WELL_SEGMENTS_VALVE,
    INFLOW_CONTROL_DEVICE, DENSITY_DRIVEN, INJECTION_VALVE, DUAL_RATE_CONTROLLED_PRODUCTION, INFLOW_CONTROL_VALVE.
    In the absence of some keywords, the program uses the default values.

    Attributes:
        content (List[str]): List of strings.
        n_content (int): Dimension of content.
        joint_length (float): JOINTLENGTH keyword. Default to 12.0.
        segment_length (float): SEGMENTLENGTH keyword. Default to 0.0.
        pvt_file (str): The pvt file content.
        pvt_file_name (str): The pvt file name.
        completion_table (pd.DataFrame): ....
        wsegaicd_table (pd.DataFrame): AUTONOMOUS_INFLOW_CONTROL_DEVICE.
        wsegsicd_table (pd.DataFrame): INFLOW_CONTROL_DEVICE.
        wsegvalv_table (pd.DataFrame): WELL_SEGMENTS_VALVE.
        wsegicv_table (pd.DataFrame): INFLOW_CONTROL_VALVE.
        wsegdensity_table (pd.DataFrame): DENSITY_DRIVEN.
        wseginjv_table (pd.DataFrame): INJECTION_VALVE.
        wsegdualrcp_table (pd.DataFrame): DUAL_RATE_CONTROLLED_PRODUCTION.
        strict (bool): USE_STRICT. If TRUE it will exit if any lateral is not defined in the case-file. Default to TRUE.
        lat2device (pd.DataFrame): LATERAL_TO_DEVICE.
        gp_perf_devicelayer (bool): GRAVEL_PACKED_PERFORATED_DEVICELAYER. If TRUE all wells with
            gravel pack and perforation completion are given a device layer.
            If FALSE (default) all wells with this type of completions are untouched by Completor.
        python_dependent (bool): PYTHON_DEPENDENT. If TRUE prints pyaction to output.
    """

    def __init__(self, case_file: str, schedule_file: str | None = None, output_file: str | None = None):
        """Initialize ReadCasefile.

        Args:
            case_file: Case/input file name.
            schedule_file: Schedule/well file if not defined in case file.
            output_file: File to write output to.

        """
        self.case_file = case_file.splitlines()
        self.content = clean_file_lines(self.case_file, "--")
        self.n_content = len(self.content)

        # assign default values
        self.joint_length = 12.0
        self.minimum_segment_length: float = 0.0
        self.strict = True
        self.gp_perf_devicelayer = False
        self.python_dependent = False
        self.schedule_file = schedule_file
        self.output_file = output_file
        self.completion_table = pd.DataFrame()
        self.completion_icv_tubing = pd.DataFrame()
        self.pvt_table = pd.DataFrame()
        self.wsegaicd_table = pd.DataFrame()
        self.wsegsicd_table = pd.DataFrame()
        self.wsegvalv_table = pd.DataFrame()
        self.wsegdensity_table = pd.DataFrame()
        self.wseginjv_table = pd.DataFrame()
        self.wsegdualrcp_table = pd.DataFrame()
        self.wsegicv_table = pd.DataFrame()
        self.lat2device = pd.DataFrame()
        self.mapfile: pd.DataFrame | str | None = None
        self.mapper: Mapping[str, str] | None = None

        # Run programs
        self.read_completion()
        self.read_joint_length()
        self.segment_length = self.read_segment_length()
        self.method = self.segmentation_method(self.segment_length)
        self.read_strictness()
        self.read_gp_perf_devicelayer()
        self.read_mapfile()
        self.read_wsegaicd()
        self.read_wsegvalv()
        self.read_wsegsicd()
        self.read_wsegdensity()
        self.read_python_dependent()
        self.read_wseginjv()
        self.read_wsegdualrcp()
        self.read_wsegicv()
        self.read_lat2device()
        self.read_minimum_segment_length()

    def read_completion(self) -> None:
        """Read the COMPLETION keyword in the case file.

        Raises:
            ValueError: If COMPLETION keyword is not defined in the case.
        """
        # Table headers
        header = [
            Headers.WELL,
            Headers.BRANCH,
            Headers.START_MEASURED_DEPTH,
            Headers.END_MEASURED_DEPTH,
            Headers.INNER_DIAMETER,
            Headers.OUTER_DIAMETER,
            Headers.ROUGHNESS,
            Headers.ANNULUS,
            Headers.VALVES_PER_JOINT,
            Headers.DEVICE_TYPE,
            Headers.DEVICE_NUMBER,
        ]
        # Initialize empty table for ICV Control
        self.completion_table = pd.DataFrame(columns=header)
        start_index, end_index = parse.locate_keyword(self.content, Keywords.COMPLETION)
        if start_index == end_index:
            # Check if there is ICV Control keyword
            # It is allowed to have no COMPLETION if there is ICVCONTROL
            start_index_icv_control, end_index_icv_control = locate_keyword(self.content, "ICVCONTROL")
            if start_index_icv_control == end_index_icv_control:
                raise ValueError("No COMPLETION keyword or ICVCONTROL is defined in the case file.")
            else:
                return

        df_temp = self._create_dataframe_with_columns(header, start_index, end_index)
        # Set default value for packer segment
        df_temp = input_validation.set_default_packer_section(df_temp)
        # Set default value for PERF segments
        df_temp = input_validation.set_default_perf_section(df_temp)
        # Give errors if 1* is found for non packer segments
        df_temp = input_validation.check_default_non_packer(df_temp)
        # Fix the data types format
        df_temp = input_validation.set_format_completion(df_temp)
        # Fix the Density based
        df_temp = input_validation.set_density_based(df_temp)
        # Fix the Dual RCP
        df_temp = input_validation.set_dualrcp(df_temp)
        # Check overall user inputs on completion
        input_validation.assess_completion(df_temp)
        df_temp = self.read_icv_tubing(df_temp)
        self.completion_table = df_temp.copy(deep=True)

    def read_icv_tubing(self, df_temp: pd.DataFrame) -> pd.DataFrame:
        """Split the ICV Tubing definition from the completion table.

        Args:
            df_temp: COMPLETION table.

        Returns:
            Updated COMPLETION table.
        """
        if not df_temp.loc[
            (df_temp[Headers.START_MEASURED_DEPTH] == df_temp[Headers.END_MEASURED_DEPTH])
            & (df_temp[Headers.DEVICE_TYPE] == Content.INFLOW_CONTROL_VALVE)
        ].empty:
            # take ICV tubing table
            self.completion_icv_tubing = df_temp.loc[
                (df_temp[Headers.START_MEASURED_DEPTH] == df_temp[Headers.END_MEASURED_DEPTH])
                & (df_temp[Headers.DEVICE_TYPE] == Content.INFLOW_CONTROL_VALVE)
            ].reset_index(drop=True)
            # drop its line
            df_temp = df_temp.drop(
                df_temp.loc[
                    (df_temp[Headers.START_MEASURED_DEPTH] == df_temp[Headers.END_MEASURED_DEPTH])
                    & (df_temp[Headers.DEVICE_TYPE] == Content.INFLOW_CONTROL_VALVE)
                ].index[:]
            ).reset_index(drop=True)
        return df_temp

    def read_lat2device(self) -> None:
        """Read the LATERAL_TO_DEVICE keyword in the case file.

        The keyword takes two arguments, a well name and a branch number.
        The branch will be connected to the device layer in the mother branch.
        If a branch number is not given, the specific branch will be connected to the
        tubing layer in the mother branch. E.g. assume that A-1 is a three branch well
        where branch 2 is connected to the tubing layer in the mother branch and
        branch 3 is connected to the device layer in the mother branch.
        The LATERAL_TO_DEVICE keyword will then look like this:

        LATERAL_TO_DEVICE
        --WELL    BRANCH
        A-1       3
        /
        """
        header = [Headers.WELL, Headers.BRANCH]
        start_index, end_index = parse.locate_keyword(self.content, Keywords.LATERAL_TO_DEVICE)

        if start_index == end_index:
            # set default behaviour (if keyword not in case file)
            self.lat2device = pd.DataFrame([], columns=header)  # empty df
            return
        self.lat2device = self._create_dataframe_with_columns(header, start_index, end_index)
        input_validation.validate_lateral_to_device(self.lat2device, self.completion_table)
        self.lat2device[Headers.BRANCH] = self.lat2device[Headers.BRANCH].astype(np.int64)

    def read_joint_length(self) -> None:
        """Read the JOINTLENGTH keyword in the case file."""
        start_index, end_index = parse.locate_keyword(self.content, Keywords.JOINT_LENGTH)
        if end_index == start_index + 2:
            self.joint_length = float(self.content[start_index + 1])
            if self.joint_length <= 0:
                logger.warning("Invalid joint length. It is set to default 12.0 m")
                self.joint_length = 12.0
        else:
            logger.info("No joint length is defined. It is set to default 12.0 m")

    def read_segment_length(self) -> float | str:
        """Read the SEGMENTLENGTH keyword in the case file.

        Raises:
            CompletorError: If SEGMENTLENGTH is not float or string.
        """
        start_index, end_index = parse.locate_keyword(self.content, Keywords.SEGMENT_LENGTH)
        if end_index == start_index + 2:
            try:
                return float(self.content[start_index + 1])
            except ValueError:
                return self.content[start_index + 1]

        else:
            logger.info(
                "SEGMENTLENGTH keyword undefined, using default strategy 'cells' "
                "to create segments based on the grid dimensions."
            )
            return 0.0

    @staticmethod
    def segmentation_method(segment_length: float | str) -> Method:
        """Determine the method of segmentation, and log the implication to info.

        Args:
            segment_length: The string or number value from the SEGMENTLENGTH keyword.

        Returns:
            The method used to create the segments.

        Raises:
            ValueError: If value of segment_length is invalid.
        """
        if isinstance(segment_length, float):
            if segment_length > 0.0:
                logger.info("Segments are defined per fixed %s meters.", segment_length)
                return Method.FIX
            if segment_length == 0.0:
                logger.info("Segments are defined based on the grid dimensions.")
                return Method.CELLS
            if segment_length < 0.0:
                logger.info(
                    "Segments are defined based on the COMPLETION keyword. "
                    "Attempting to pick segments' measured depth from case file."
                )
                return Method.USER

        if isinstance(segment_length, str):
            if "welsegs" in segment_length.lower() or "infill" in segment_length.lower():
                logger.info(
                    "Segments are defined based on the WELL_SEGMENTS%s keyword. "
                    "Retaining the original tubing segment structure.",
                    Keywords.WELL_SEGMENTS,
                )
                return Method.WELSEGS
            if "cell" in segment_length.lower():
                logger.info("Segment lengths are created based on the grid dimensions.")
                return Method.CELLS
            if "user" in segment_length.lower():
                logger.info(
                    "Segments are defined based on the COMPLETION keyword. "
                    "Attempting to pick segments' measured depth from casefile."
                )
                return Method.USER
        raise CompletorError(
            f"Unrecognized method for SEGMENTLENGTH keyword '{segment_length}'. The value should be one of: "
            f"'{Keywords.WELL_SEGMENTS}', 'CELLS', 'USER'. "
            "Alternatively a negative number for 'USER', zero for 'CELLS', or positive number for 'FIX'.",
        )

    def read_strictness(self) -> None:
        """Read the USE_STRICT keyword in the case file.

        If USE_STRICT = True the program exits if a branch in the schedule file is not defined in the case file.
        The default value is True, meaning that to allow for Completor to ignore missing branches in the case file,
        it has to be set to False.
        This feature was introduced when comparing Completor with a different advanced well modelling
        tool using a complex simulation model.

        Best practice: All branches in all wells should be defined in the case file.
        """
        start_index, end_index = parse.locate_keyword(self.content, Keywords.USE_STRICT)
        if end_index == start_index + 2:
            strict = self.content[start_index + 1]
            if strict.upper() == "FALSE":
                self.strict = False
        logger.info("case-strictness is set to %d", self.strict)

    def read_gp_perf_devicelayer(self) -> None:
        """Read the GRAVEL_PACKED_PERFORATED_DEVICELAYER keyword in the case file.

        If GRAVEL_PACKED_PERFORATED_DEVICELAYER = True the program assigns a device layer to
        wells with GP PERF type completions. If GRAVEL_PACKED_PERFORATED_DEVICELAYER = False, the
        program does not add a device layer to the well. I.e. the well is
        untouched by the program. The default value is False.
        """
        start_index, end_index = parse.locate_keyword(self.content, Keywords.GRAVEL_PACKED_PERFORATED_DEVICELAYER)
        if end_index == start_index + 2:
            gp_perf_devicelayer = self.content[start_index + 1]
            self.gp_perf_devicelayer = gp_perf_devicelayer.upper() == "TRUE"
        logger.info("gp_perf_devicelayer is set to %s", self.gp_perf_devicelayer)

    def read_minimum_segment_length(self) -> None:
        """Read the MINIMUM_SEGMENT_LENGTH keyword in the case file.

        The default value is 0.0, meaning that no segments are lumped by this keyword.
        The program will continue to coalesce segments until all segments are longer than the given minimum.
        """
        start_index, end_index = parse.locate_keyword(self.content, Keywords.MINIMUM_SEGMENT_LENGTH)
        if end_index == start_index + 2:
            min_seg_len = self.content[start_index + 1]
            self.minimum_segment_length = input_validation.validate_minimum_segment_length(min_seg_len)
        logger.info("minimum_segment_length is set to %s", self.minimum_segment_length)

    def read_mapfile(self) -> None:
        """Read the MAP_FILE keyword in the case file (if any) into a mapper."""
        start_index, end_index = parse.locate_keyword(self.content, Keywords.MAP_FILE)
        if end_index == start_index + 2:
            # the content is in between the keyword and the /
            self.mapfile = parse.remove_string_characters(self.content[start_index + 1])
            self.mapper = self._mapper(self.mapfile)

    def read_wsegvalv(self) -> None:
        """Read the WELL_SEGMENTS_VALVE keyword in the case file.

        Raises:
            CompletorError: If WESEGVALV is not defined and VALVE is used in COMPLETION. If the device number is not found.
        """
        start_index, end_index = parse.locate_keyword(self.content, Keywords.WELL_SEGMENTS_VALVE)
        if start_index == end_index:
            if Content.VALVE in self.completion_table[Headers.DEVICE_TYPE]:
                raise CompletorError("WELL_SEGMENTS_VALVE keyword must be defined, if VALVE is used in the completion.")
        else:
            # Table headers
            header = [
                Headers.DEVICE_NUMBER,
                Headers.FLOW_COEFFICIENT,
                Headers.FLOW_CROSS_SECTIONAL_AREA,
                Headers.ADDITIONAL_PIPE_LENGTH_FRICTION_PRESSURE_DROP,
            ]
            try:
                df_temp = self._create_dataframe_with_columns(header, start_index, end_index)
                df_temp[Headers.MAX_FLOW_CROSS_SECTIONAL_AREA] = np.nan
            except CaseReaderFormatError:
                header += [Headers.MAX_FLOW_CROSS_SECTIONAL_AREA]
                df_temp = self._create_dataframe_with_columns(header, start_index, end_index)

            self.wsegvalv_table = input_validation.set_format_wsegvalv(df_temp)
            device_checks = self.completion_table[self.completion_table[Headers.DEVICE_TYPE] == Content.VALVE][
                Headers.DEVICE_NUMBER
            ].to_numpy()
            if not self._check_contents(device_checks, self.wsegvalv_table[Headers.DEVICE_NUMBER].to_numpy()):
                raise CompletorError(
                    f"Not all device in {Keywords.COMPLETION} is specified in {Keywords.WELL_SEGMENTS_VALVE}"
                )

    def read_wsegsicd(self) -> None:
        """Read the INFLOW_CONTROL_DEVICE keyword in the case file.

        Raises:
            CompletorError: If INFLOW_CONTROL_DEVICE is not defined and ICD is used in COMPLETION,
                or if the device number is not found.
                If not all devices in COMPLETION are specified in INFLOW_CONTROL_DEVICE.
        """
        start_index, end_index = parse.locate_keyword(self.content, Keywords.INFLOW_CONTROL_DEVICE)
        if start_index == end_index:
            if Content.INFLOW_CONTROL_DEVICE in self.completion_table[Headers.DEVICE_TYPE]:
                raise CompletorError(
                    f"{Keywords.INFLOW_CONTROL_DEVICE} keyword must be defined, if ICD is used in the completion."
                )
        else:
            # Table headers
            header = [
                Headers.DEVICE_NUMBER,
                Headers.STRENGTH,
                Headers.CALIBRATION_FLUID_DENSITY,
                Headers.CALIBRATION_FLUID_VISCOSITY,
                Headers.WATER_CUT,
            ]
            self.wsegsicd_table = input_validation.set_format_wsegsicd(
                self._create_dataframe_with_columns(header, start_index, end_index)
            )
            # Check if the device in COMPLETION is exist in INFLOW_CONTROL_DEVICE
            device_checks = self.completion_table[
                self.completion_table[Headers.DEVICE_TYPE] == Content.INFLOW_CONTROL_DEVICE
            ][Headers.DEVICE_NUMBER].to_numpy()
            if not self._check_contents(device_checks, self.wsegsicd_table[Headers.DEVICE_NUMBER].to_numpy()):
                raise CompletorError(f"Not all device in COMPLETION is specified in {Keywords.INFLOW_CONTROL_DEVICE}")

    def read_wsegaicd(self) -> None:
        """Read the AUTONOMOUS_INFLOW_CONTROL_DEVICE keyword in the case file.

        Raises:
            ValueError: If invalid entries in AUTONOMOUS_INFLOW_CONTROL_DEVICE.
            CompletorError: If AUTONOMOUS_INFLOW_CONTROL_DEVICE is not defined, and AICD is used in COMPLETION,
                or if the device number is not found.
                If all devices in COMPLETION are not specified in AUTONOMOUS_INFLOW_CONTROL_DEVICE.
        """
        start_index, end_index = parse.locate_keyword(self.content, Keywords.AUTONOMOUS_INFLOW_CONTROL_DEVICE)
        if start_index == end_index:
            if Content.AUTONOMOUS_INFLOW_CONTROL_DEVICE in self.completion_table[Headers.DEVICE_TYPE]:
                raise CompletorError(
                    f"{Keywords.AUTONOMOUS_INFLOW_CONTROL_DEVICE} keyword must be defined, "
                    "if AICD is used in the completion."
                )
        else:
            # Table headers
            header = [
                Headers.DEVICE_NUMBER,
                Headers.STRENGTH,
                Headers.X,
                Headers.Y,
                Headers.A,
                Headers.B,
                Headers.C,
                Headers.D,
                Headers.E,
                Headers.F,
                Headers.AICD_CALIBRATION_FLUID_DENSITY,
                Headers.AICD_FLUID_VISCOSITY,
                Headers.Z,
            ]
            try:
                df_temp = self._create_dataframe_with_columns(header, start_index, end_index)
            except CaseReaderFormatError:
                header.remove(Headers.Z)
                df_temp = self._create_dataframe_with_columns(header, start_index, end_index)
            self.wsegaicd_table = input_validation.set_format_wsegaicd(df_temp)
            device_checks = self.completion_table[
                self.completion_table[Headers.DEVICE_TYPE] == Content.AUTONOMOUS_INFLOW_CONTROL_DEVICE
            ][Headers.DEVICE_NUMBER].to_numpy()
            if not self._check_contents(device_checks, self.wsegaicd_table[Headers.DEVICE_NUMBER].to_numpy()):
                raise CompletorError(
                    f"Not all device in COMPLETION is specified in {Keywords.AUTONOMOUS_INFLOW_CONTROL_DEVICE}"
                )

    def read_wsegdensity(self) -> None:
        """Read the DENSITY keyword in the case file.

        Raises:
            ValueError: If there are invalid entries in DENSITY.
            CompletorError: If not all device in COMPLETION is specified in DENSITY.
                If DENSITY keyword not defined, when DENSITY is used in the completion.
        """
        density_index_start, density_index_end = parse.locate_keyword(self.content, Keywords.DENSITY)
        dar_index_start, dar_index_end = parse.locate_keyword(self.content, Keywords.DENSITY_ACTIVATED_RECOVERY)

        # Determine which keyword is present
        if density_index_start == density_index_end and dar_index_start == dar_index_end:
            if (
                Content.DENSITY in self.completion_table[Headers.DEVICE_TYPE]
                or Content.DENSITY_ACTIVATED_RECOVERY in self.completion_table[Headers.DEVICE_TYPE]
            ):
                raise CompletorError(
                    f"{Keywords.DENSITY} keyword must be defined, if DENSITY is used in the completion."
                )
        else:
            # Table headers
            header = [
                Headers.DEVICE_NUMBER,
                Headers.FLOW_COEFFICIENT,
                Headers.OIL_FLOW_CROSS_SECTIONAL_AREA,
                Headers.GAS_FLOW_CROSS_SECTIONAL_AREA,
                Headers.WATER_FLOW_CROSS_SECTIONAL_AREA,
                Headers.WATER_HOLDUP_FRACTION_LOW_CUTOFF,
                Headers.WATER_HOLDUP_FRACTION_HIGH_CUTOFF,
                Headers.GAS_HOLDUP_FRACTION_LOW_CUTOFF,
                Headers.GAS_HOLDUP_FRACTION_HIGH_CUTOFF,
            ]

            # Get start and end index from correct keyword
            if not density_index_start == density_index_end:
                start_index, end_index = density_index_start, density_index_end
                key = Keywords.DENSITY
                content = Content.DENSITY
            else:
                start_index, end_index = dar_index_start, dar_index_end
                key = Keywords.DENSITY_ACTIVATED_RECOVERY
                content = Content.DENSITY_ACTIVATED_RECOVERY
            # Fix table format
            self.wsegdensity_table = input_validation.set_format_wsegdensity(
                self._create_dataframe_with_columns(header, start_index, end_index)
            )
            device_checks = self.completion_table[self.completion_table[Headers.DEVICE_TYPE] == content][
                Headers.DEVICE_NUMBER
            ].to_numpy()
            if not self._check_contents(device_checks, self.wsegdensity_table[Headers.DEVICE_NUMBER].to_numpy()):
                raise CompletorError(f"Not all device in COMPLETION is specified in {key}")

    def read_wseginjv(self) -> None:
        """Read the INJECTION_VALVE keyword in the case file.

        Raises:
            CompletorError: If INJECTION_VALVE is not defined and INJV is used in COMPLETION,
                or if the device number is not found.
                If not all devices in COMPLETION are specified in INJECTION_VALVE.
        """
        start_index, end_index = parse.locate_keyword(self.content, Keywords.INJECTION_VALVE)
        if start_index == end_index:
            if Content.INJECTION_VALVE in self.completion_table[Headers.DEVICE_TYPE]:
                raise CompletorError(
                    f"{Keywords.INJECTION_VALVE} keyword must be defined, if INJV is used in the completion."
                )
        else:
            # Table headers
            header = [
                Headers.DEVICE_NUMBER,
                Headers.TRIGGER_PARAMETER,
                Headers.TRIGGER_VALUE,
                Headers.FLOW_COEFFICIENT,
                Headers.PRIMARY_FLOW_CROSS_SECTIONAL_AREA,
                Headers.SECONDARY_FLOW_CROSS_SECTIONAL_AREA,
            ]
            self.wseginjv_table = input_validation.set_format_wseginjv(
                self._create_dataframe_with_columns(header, start_index, end_index)
            )
            # Check if the device in COMPLETION is exist in INJECTION_VALVE
            device_checks = self.completion_table[
                self.completion_table[Headers.DEVICE_TYPE] == Content.INJECTION_VALVE
            ][Headers.DEVICE_NUMBER].to_numpy()
            if not self._check_contents(device_checks, self.wseginjv_table[Headers.DEVICE_NUMBER].to_numpy()):
                raise CompletorError(f"Not all device in COMPLETION is specified in {Keywords.INJECTION_VALVE}")

    def read_python_dependent(self) -> None:
        """Read PYTHON keyword. Accepts TRUE or just '/' as True."""
        start_index, end_index = parse.locate_keyword(self.content, Keywords.PYTHON_DEPENDENT)

        if end_index == start_index + 1:
            # Keyword followed directly by '/', no value = True
            self.python_dependent = True
        elif end_index == start_index + 2:
            val = self.content[start_index + 1]
            if val.upper() == "TRUE":
                self.python_dependent = True

    def read_wsegdualrcp(self) -> None:
        """Read the DUALRCP keyword in the case file.

        Raises:
            ValueError: If invalid entries in DUALRCP.
            CompletorError: DUALRCP keyword not defined when DUALRCP is used in completion.
                If all devices in COMPLETION are not specified in DUALRCP.
        """
        dualrcp_index_start, dualrcp_index_end = parse.locate_keyword(
            self.content, Keywords.DUAL_RATE_CONTROLLED_PRODUCTION
        )
        aicv_index_start, aicv_index_end = parse.locate_keyword(self.content, Keywords.AUTONOMOUS_INFLOW_CONTROL_VALVE)

        # Determine which keyword is present
        if dualrcp_index_start == dualrcp_index_end and aicv_index_start == aicv_index_end:
            if (
                Content.DUAL_RATE_CONTROLLED_PRODUCTION in self.completion_table[Headers.DEVICE_TYPE]
                or Content.AUTONOMOUS_INFLOW_CONTROL_VALVE in self.completion_table[Headers.DEVICE_TYPE]
            ):
                raise CompletorError(
                    f"{Keywords.DUAL_RATE_CONTROLLED_PRODUCTION} keyword must be defined, "
                    "if DUALRCP is used in the completion."
                )
        else:
            # Table headers
            header = [
                Headers.DEVICE_NUMBER,
                Headers.DUALRCP_WATER_CUT,
                Headers.DUALRCP_GAS_HOLDUP_FRACTION,
                Headers.DUALRCP_CALIBRATION_FLUID_DENSITY,
                Headers.DUALRCP_FLUID_VISCOSITY,
                Headers.ALPHA_MAIN,
                Headers.X_MAIN,
                Headers.Y_MAIN,
                Headers.A_MAIN,
                Headers.B_MAIN,
                Headers.C_MAIN,
                Headers.D_MAIN,
                Headers.E_MAIN,
                Headers.F_MAIN,
                Headers.ALPHA_PILOT,
                Headers.X_PILOT,
                Headers.Y_PILOT,
                Headers.A_PILOT,
                Headers.B_PILOT,
                Headers.C_PILOT,
                Headers.D_PILOT,
                Headers.E_PILOT,
                Headers.F_PILOT,
            ]
            # Get start and end index from correct keyword
            if not dualrcp_index_start == dualrcp_index_end:
                start_index, end_index = dualrcp_index_start, dualrcp_index_end
                key = Keywords.DUAL_RATE_CONTROLLED_PRODUCTION
                content = Content.DUAL_RATE_CONTROLLED_PRODUCTION
            else:
                start_index, end_index = aicv_index_start, aicv_index_end
                key = Keywords.AUTONOMOUS_INFLOW_CONTROL_VALVE
                content = Content.AUTONOMOUS_INFLOW_CONTROL_VALVE
            # Fix table format
            self.wsegdualrcp_table = input_validation.set_format_wsegdualrcp(
                self._create_dataframe_with_columns(header, start_index, end_index)
            )
            # Check if the device in COMPLETION is exist in DUALRCP
            device_checks = self.completion_table[self.completion_table[Headers.DEVICE_TYPE] == content][
                Headers.DEVICE_NUMBER
            ].to_numpy()
            if not self._check_contents(device_checks, self.wsegdualrcp_table[Headers.DEVICE_NUMBER].to_numpy()):
                raise CompletorError(f"Not all devices in COMPLETION are specified in {key}")

    def read_wsegicv(self) -> None:
        """Read INFLOW_CONTROL_VALVE keyword in the case file.

        Raises:
            ValueError: If invalid entries in INFLOW_CONTROL_VALVE.
            CompletorError: INFLOW_CONTROL_VALVE keyword not defined when ICV is used in completion.
        """

        start_index, end_index = parse.locate_keyword(self.content, Keywords.INFLOW_CONTROL_VALVE)
        if start_index == end_index:
            if Content.INFLOW_CONTROL_VALVE in self.completion_table[Headers.DEVICE_TYPE]:
                raise CompletorError("INFLOW_CONTROL_VALVE keyword must be defined, if ICV is used in the completion")
        else:
            # Table headers
            header = [Headers.DEVICE_NUMBER, Headers.FLOW_COEFFICIENT, Headers.FLOW_CROSS_SECTIONAL_AREA]
            try:
                df_temp = self._create_dataframe_with_columns(header, start_index, end_index)
                df_temp[Headers.MAX_FLOW_CROSS_SECTIONAL_AREA] = np.nan
            except CaseReaderFormatError:
                header += [Headers.MAX_FLOW_CROSS_SECTIONAL_AREA]
                df_temp = self._create_dataframe_with_columns(header, start_index, end_index)
            # Fix format
            self.wsegicv_table = input_validation.set_format_wsegicv(df_temp)
            # Check if the device in COMPLETION exists in INFLOW_CONTROL_VALVE
            device_checks = self.completion_table[
                self.completion_table[Headers.DEVICE_TYPE] == Content.INFLOW_CONTROL_VALVE
            ][Headers.DEVICE_NUMBER].to_numpy()
            if not self._check_contents(device_checks, self.wsegicv_table[Headers.DEVICE_NUMBER].to_numpy()):
                raise CompletorError("Not all device in COMPLETION is specified in INFLOW_CONTROL_VALVE")

    def get_completion(self, well_name: str | None, branch: int) -> pd.DataFrame:
        """Create the COMPLETION table for the selected well and branch.

        Args:
            well_name: Well name.
            branch: Branch/lateral number.

        Returns:
            COMPLETION for that well and branch.
        """
        df_temp = self.completion_table[self.completion_table[Headers.WELL] == well_name]
        df_temp = df_temp[df_temp[Headers.BRANCH] == branch]
        return df_temp

    def check_input(self, well_name: str, well_data: WellData) -> None:
        """Ensure that the completion table (given in the case-file) is complete.

        If one branch is completed, all branches must be completed, unless not 'strict'.
        This function relates to the USE_STRICT <bool> keyword used in the case file.
        When a branch is undefined in the case file, but appears in the schedule file,
        the completion selected by Completor is gravel packed perforations if USE_STRICT is set to False.

        Args:
            well_name: Well name.
            schedule_data: Schedule file data.

        Returns:
            COMPLETION for that well and branch.

        Raises:
            CompletorError: If strict is true and there are undefined branches.
        """
        if sorted(list(well_data.keys())) != Keywords.main_keywords:
            found_keys = set(well_data.keys())
            raise CompletorError(
                f"Well '{well_name}' is missing keyword(s): '{', '.join(set(Keywords.main_keywords) - found_keys)}'!"
            )
        df_completion = self.completion_table[self.completion_table.WELL == well_name]
        # Check that all branches are defined in the case-file.

        # TODO(#173): Use TypedDict for this, and remove the type: ignore.
        branch_nos = set(well_data[Keywords.COMPLETION_SEGMENTS][Headers.BRANCH]).difference(  # type: ignore
            set(df_completion[Headers.BRANCH])
        )
        if len(branch_nos):
            logger.warning("Well %s has branch(es) not defined in case-file", well_name)
            if self.strict:
                raise CompletorError("USE_STRICT True: Define all branches in case file.")

            for branch_no in branch_nos:
                logger.warning("Adding branch %s for Well %s", branch_no, well_name)
                # copy first entry
                lateral = pd.DataFrame(
                    [self.completion_table.loc[self.completion_table.WELL == well_name].iloc[0]],
                    columns=self.completion_table.columns,
                )
                lateral[Headers.START_MEASURED_DEPTH] = 0
                lateral[Headers.END_MEASURED_DEPTH] = 999999
                lateral[Headers.DEVICE_TYPE] = Content.PERFORATED
                lateral[Headers.ANNULUS] = Content.GRAVEL_PACKED
                lateral[Headers.BRANCH] = branch_no
                # add new entry
                self.completion_table = pd.concat([self.completion_table, lateral])

    def connect_to_tubing(self, well_name: str, lateral: int) -> bool:
        """Connect a branch to the tubing- or device-layer.

        Args:
            well_name: Well name.
            lateral: Lateral number.

        Returns:
            TRUE if lateral is connected to tubing layer.
            FALSE if lateral is connected to device layer.
        """
        laterals = self.lat2device[self.lat2device.WELL == well_name].BRANCH
        if lateral in laterals.to_numpy():
            return False
        return True

    def _create_dataframe_with_columns(
        self, header: list[str], start_index: int, end_index: int, keyword: str | None = None
    ) -> pd.DataFrame:
        """Helper method to create a dataframe with given columns' header and content.

        Args:
            header: List of column names.
            start_index: From (but not including) where in `self.content`.
            end_index: to where to include in the body of the table.

        Returns:
            Combined DataFrame.

        Raises:
            CaseReaderFormatError: If keyword is malformed, or has different amount of data than the header.
        """
        if keyword is None:
            keyword = self.content[start_index]
        table_header = " ".join(header)
        # Handle weirdly formed keywords.
        if start_index + 1 == end_index or self.content[start_index + 1].endswith("/"):
            content_str = "\n".join(self.content[start_index + 1 :]) + "\n"
            # (?<=\/) - positive look-behind for slash newline
            # \/{1}   - match exactly one slash
            #  (?=\n) - positive look-ahead for newline
            match = re.search(r"(?<=\/\n{1})\/{1}(?=\n)", content_str)
            if match is None:
                raise CaseReaderFormatError(
                    "Cannot determine correct end of record '/' for keyword.", self.case_file, header, keyword
                )
            end_record = match.span()[0]
            # From keyword to the end (without the last slash)
            content_ = content_str[:end_record].split("/\n")[:-1]
            content_ = [line.strip() for line in content_]
            table_content = "\n".join(content_) + "\n"
        else:
            table_content = "\n".join(self.content[start_index + 1 : end_index])

        header_len = len(table_header.split())
        content_list_len = [len(line.split()) for line in table_content.splitlines()]
        if not all(header_len == x for x in content_list_len):
            message = (
                "Problem with case file. Note that the COMPLETION keyword takes "
                "exactly 11 (eleven) columns. Blank portion is now removed.\n"
            )
            raise CaseReaderFormatError(message, lines=self.case_file, header=header, keyword=keyword)

        table = table_header + "\n" + table_content

        df_temp = pd.read_csv(StringIO(table), sep=" ", dtype="object", index_col=False)
        return parse.remove_string_characters(df_temp)

    @staticmethod
    def _mapper(map_file: str) -> dict[str, str]:
        """Read two-column file and store data as values and keys in a dictionary.

        Used to map between pre-processing tools and reservoir simulator file names.

        Args:
            map_file: Two-column text file.

        Returns:
            Dictionary of key and values taken from the mapfile.
        """
        mapper = {}
        with open(map_file, encoding="utf-8") as lines:
            for line in lines:
                if not line.startswith("--"):
                    keyword_pair = line.strip().split()
                    if len(keyword_pair) == 2:
                        key = keyword_pair[0]
                        value = keyword_pair[1]
                        mapper[key] = value
                    else:
                        logger.warning("Illegal line '%s' in mapfile", keyword_pair)
        return mapper

    @staticmethod
    def _check_contents(values: npt.NDArray[Any], reference: npt.NDArray[Any]) -> bool:
        """Check if all members of a list is in another list.

        Args:
            values: Array to be evaluated.
            reference: Reference array.

        Returns:
            True if members of values are present in reference, false otherwise.
        """
        return all(comp in reference for comp in values)


class ICVReadCasefile(ReadCasefile):
    """Inherited ReadCaseFile from completor with additions for ICV-Control."""

    def __init__(self, case_file: str, user_schedule_file: str | None = None, new_segments: str | None = None):
        """Initialize ICVReadCasefile.

        Args:
            case_file: Case/input file name.
            schedule_file: Schedule file as output from Completor schedule output
            new_segments: Well segment lists from Completor output.

        """
        super().__init__(case_file, user_schedule_file)
        self.icv_table: dict[str, pd.DataFrame] = {}
        self.icv_date = None
        self.icv_control_table = pd.DataFrame()
        self.custom_conditions: dict[ICVMethod, dict[str, Any]] = {}
        self.icv_segments = new_segments

        self.read_icv_control()
        if self.icv_segments:
            self.update_icv_case()
        self.read_icv_table()
        self.read_custom_conditions()
        self.step_table = self.create_step_table()

        self.init_table = self.create_table_from_casefile("INIT")
        self.min_table = self.create_table_from_casefile("MIN")
        self.max_table = self.create_table_from_casefile("MAX")
        self.init_opening_table = self.create_table_from_casefile("OPENING")

    def read_icv_control(self) -> None:
        """This procedure reads the ICVCONTROL keyword in the case file.

        The ICVCONTROL keyword information is stored in a class property
        DataFrame ``self.icv_control_table`` with the following format:
        """
        start_index, end_index = locate_keyword(self.content, "ICVCONTROL")
        if start_index == end_index:
            logger.warning("No ICVCONTROL table is found in the case file.")

        headers = ["WELL", "ICV", "SEGMENT", "AC-TABLE", "STEPS", "ICVDATE", "FREQ", "MIN", "MAX", "OPENING"]
        extended_headers = ["FUD", "FUH", "FUL", "OPERSTEP", "WAITSTEP", "INIT"]
        try:
            df_temp = self._create_dataframe_with_columns(headers, start_index, end_index)
            # Default values for extra headers if not supplied:
            if df_temp.shape[1] == 10:
                df_temp["FUD"] = 1
                df_temp["FUH"] = 10
                df_temp["FUL"] = 0.1
                df_temp["OPERSTEP"] = 2
                df_temp["WAITSTEP"] = 1
                df_temp["INIT"] = 0.01
        except CaseReaderFormatError:
            headers += extended_headers
            df_temp = self._create_dataframe_with_columns(headers, start_index, end_index)
        df_temp = input_validation.set_format_icvcontrol(df_temp)
        self.icv_control_table = df_temp.copy(deep=True)

    def update_icv_case(self) -> None:
        """Read and update the segmentation number in case file based on
        input schedule file.

        Default: False

        """
        df_new_segment = pd.DataFrame(self.icv_segments, columns=["WELL", "NEW_SEGMENT"])
        value_working = df_new_segment.copy(deep=True)
        df_working = self.icv_control_table.copy(deep=True)
        if len(df_working) != len(value_working):
            raise CompletorError(
                f"ICVs defined in ICVCONTROL table are {len(df_working)} while the ICVs found in schedule file "
                f"are {len(value_working)}"
            )
        value_working = df_new_segment.copy(deep=True)
        for well in value_working["WELL"].unique():
            if len(value_working[value_working["WELL"] == well]) == df_working[df_working["WELL"] == well].shape[0]:
                for idx, row in df_working.iterrows():
                    df_working.loc[idx, "SEGMENT"] = value_working.loc[idx, "NEW_SEGMENT"]
            else:
                num_icvs_schedule = len(value_working[value_working["WELL"] == well])
                raise CompletorError(
                    f"Number of ICVs defined in ICVCONTROL for well {well} are not the same as ICVs found "
                    f"in schedule file which are {num_icvs_schedule}."
                )
        self.icv_control_table = df_working

    def read_icv_table(self):
        """This procedure reads the ICVTABLE keyword in the case file.

        The ICVTABLE keyword information is stored in a class property
        DataFrame ``self.icv_control_table`` with the following format:

        The class property DataFrame icv_control_table has the following format:

            .. icv_control_table:
            .. list-table:: icv_control_table
                :widths: 10 10
                :header-rows: 1

               * - Positions
                 - int
               * - Cv
                 - float
               * - Area
                 - float
               * - Opening
                 - str

        """
        start_arr = []
        end_arr = []
        i = 0
        while i < len(self.content):
            start, end = locate_keyword(self.content[i:], "ICVTABLE")
            if start == np.array([-1]):
                break
            start_arr.append(start + i)
            end_arr.append(end + i)
            i += end

        if not start_arr:
            logger.info("No ICVTABLE is found in the case file. Using default steps to adjust openings.")
            return None
        # Table headers
        header = ["POSITION", "CV", "AREA"]
        for start_index, end_index in zip(start_arr, end_arr):
            table_name = self.content[start_index + 1 : start_index + 2]
            table_name = table_name[0].strip("/").split()
            df_temp = self._create_dataframe_with_columns(header, start_index + 1, end_index)
            if df_temp.shape[1] != 3:
                raise CompletorError("Keyword ICVCONTROL is missing data.")
            elif df_temp.isnull().values.any():
                raise CompletorError("Keyword ICVCONTROL is missing data.")

            df_temp = input_validation.set_format_icv_table(df_temp)

            self.icv_table.update({name: df_temp for name in table_name})

    def read_custom_conditions(self) -> dict[ICVMethod, dict[str, Any]]:
        """This procedure reads the CONTROL_CRITERIA keyword in the case file.

        The CONTROL_CRITERIA keyword information is stored in a dictionary:
            "functions": [Method.TYPE],
            "criteria": 1,
            "icvs": ["ICV","ICV"],
            "conditions": 'extra string of conditions'

        Returns:
            A dictionary containing the custom conditions.
        """
        start_arr = []
        end_arr = []
        i = 0
        while i < len(self.content):
            start, end = locate_keyword(self.content[i:], "CONTROL_CRITERIA")
            if start == np.array([-1]):
                break
            start_arr.append(start + i)
            end_arr.append(end + i)
            i += end

        if not start_arr:
            self.custom_conditions = {}
            return self.custom_conditions

        for start, end in zip(start_arr, end_arr):
            self.parse_custom_conditions(self.content[start + 1 : end])

        return self.custom_conditions

    def parse_custom_conditions(self, raw_content: list[str]) -> dict[ICVMethod, dict[str, str | list[int]]]:
        """Parse the raw text input into a dictionary structure.

        Args:
            raw_content: Raw input string, as list of lines.

        Raises:
            ValueError: ValueError if the input data has erroneous format.

        Returns:
            The processed nested dictionary, e.g.
            {
                Method.TYPE: {
                    ICV_NAME: {
                        criteria: [1]
                        content: The text to be inserted to icv_functions.
                    }
                }
            }

        """
        criteria = []
        methods: list[ICVMethod] = []
        icv_map: list[list[str]] = []
        for i, line in enumerate(raw_content):
            keyword, *value = line.rsplit(":", 1)
            if not value:
                value = [""]
            keyword = keyword.strip().lower()
            value = "".join(value).strip()
            # Looking at start of word to accommodate some typos / variations
            if keyword.startswith("func"):
                # Find longes patterns matching UPPERCASE, seperated by underscores
                # (possibly no underscores)
                pattern = r"[A-Z]+\_?[A-Z]+\_?[A-Z]*\b|[A-Z]+\_?[A-Z]*\b"
                tmp = re.findall(pattern, value)
                methods = []
                for possible_method in tmp:
                    try:
                        possible_method = ICVMethod(possible_method)
                        if possible_method not in methods:
                            methods.append(possible_method)
                    except ValueError:
                        logger.warning(f"Unknown function '{possible_method}' in FUNCTION field.")

            elif keyword.startswith("crit"):
                # Make pseudo-floats into integers, e.g. 2.00 -> 2
                malformed_input = re.findall(r"\d+\.\d+", value)
                if malformed_input:
                    logger.warning(f"Found possible floats '{malformed_input}'. Attepting to cast to int!")
                    value = re.sub(r"\.0+", "", value)
                try:
                    if "." in value:
                        raise ValueError
                    tmp = [int(c) for c in re.findall(r"\d+", value)]
                    if not tmp:
                        raise ValueError
                    criteria = tmp
                except ValueError:
                    raise ValueError(
                        "Expected the value in criteria to be an integer, " f"or a list of integers, got '{value}'."
                    )

            elif keyword.startswith("icv"):
                icv_list = (" ".join([icv.strip() for icv in re.sub(r"\[|\]\]", "", value).split(",")])).split("]")
                # Removal of whitespace and maps to sublists
                icv_map = [sublist.strip().split() for sublist in icv_list if sublist]

            else:
                content = ("\n".join(raw_content[i:])).upper()
                break

        if not methods:
            raise ValueError(
                "The contents of CONTROL_CRITERIA was malformed. Missing information in the 'FUNCTION' field!"
            )
        if not any(icv_map):
            for method in methods:
                if method == ICVMethod.UDQ:
                    if method not in self.custom_conditions:
                        self.custom_conditions[method] = {}
                    if "UDQ" not in self.custom_conditions[method]:
                        self.custom_conditions[method]["UDQ"] = {}
                    try:
                        self.custom_conditions[method]["UDQ"]["1"] += "\n" + content
                    except KeyError:
                        self.custom_conditions[method]["UDQ"].update({"1": content})
                    self.custom_conditions[method]["UDQ"]["1"] = "\n".join(
                        self.custom_conditions[method]["UDQ"]["1"].splitlines()
                    )
                    # Ensure that assign get written before defines
                    self.custom_conditions[method]["UDQ"]["1"] = sort_string_with_assign_first(
                        self.custom_conditions[method]["UDQ"]["1"]
                    )
                    self.custom_conditions[method]["UDQ"]["map"] = {"1": {"UDQ": "UDQ"}}
                    return self.custom_conditions
            raise ValueError("The contents of CONTROL_CRITERIA was malformed. Missing information in the 'ICVS' field!")
        if not criteria and ICVMethod.UDQ not in methods:
            logger.warning("Did not find any 'CRITERIA', defaulting to [1]!")
            criteria = [1]

        # Form the dictionary from the gathered data
        for method in methods:
            if self.custom_conditions.get(method) is None:
                self.custom_conditions[method] = {}
            for icv_combo in icv_map:
                if icv_combo != "":
                    icv = icv_combo[0]

                    if self.custom_conditions.get(method, {}).get(icv) is None:
                        self.custom_conditions[method][icv] = {}
                    icv_combo_mapped = {}
                    if "map" not in self.custom_conditions[method][icv]:
                        self.custom_conditions[method][icv]["map"] = {}
                    icv_combo_mapped = {f"X{i}": name for i, name in enumerate(icv_combo)}
                    if method == ICVMethod.UDQ:
                        if len(methods) > 1:
                            raise ValueError("UDQ field needs a seperate CONTROL_CRITERIA keyword.")
                        try:
                            self.custom_conditions[method][icv]["1"] += "\n" + content
                        except KeyError:
                            self.custom_conditions[method][icv].update({"1": content})
                        # Make assign be written before define.
                        self.custom_conditions[method][icv]["1"] = "\n".join(
                            self.custom_conditions[method][icv]["1"].splitlines()
                        )
                        self.custom_conditions[method][icv]["1"] = sort_string_with_assign_first(
                            self.custom_conditions[method][icv]["1"]
                        )
                        self.custom_conditions[method][icv]["map"].update({"1": icv_combo_mapped})
                    else:
                        try:
                            self.custom_conditions[method][icv][str(criteria[0])]
                            # if len(self.custom_conditions[method][icv].keys()) > 1:
                            logger.warning(
                                f"The CONTROL_CRITERIA for ICV '{icv}' "
                                f"method '{method}' criteria '{criteria}' "
                                "seems to be defined more than once."
                            )
                        except KeyError:
                            pass
                        formatted_content = ""
                        for i, line in enumerate(content.splitlines()):
                            # Remove any trailing non-alphanumeric characters
                            # (excluding ')') and extra whitespace
                            line = " ".join(re.sub(r"[^\w\)]*$", "", line).split())
                            # The last line should not end with "AND", remove if present
                            if i == len(content.splitlines()) - 1:
                                last_line = re.sub(r"[^\w\)]*$", "", line).split()
                                if last_line[-1] == "AND":
                                    line = " ".join(last_line[:-1])
                                formatted_content += line + " /"
                            elif re.findall(r"\w+", line)[-1] == "AND":
                                # If the line ends with "AND", add a "/" after it
                                formatted_content += line + " /\n"
                            elif line != "":
                                # Otherwise, add "AND /" after the line
                                formatted_content += line + " AND /\n"

                        self.custom_conditions[method][icv].update({str(crit): formatted_content for crit in criteria})
                        self.custom_conditions[method][icv]["map"].update(
                            {str(crit): icv_combo_mapped for crit in criteria}
                        )
                        for key in icv_combo_mapped.keys():
                            if str(key) not in content:
                                logger.warning(
                                    f"Custom condition warning:\n Function '{method}', "
                                    f"criteria '{criteria}' has "
                                    f"{len(icv_combo_mapped.keys())} ICVs where "
                                    f"{icv_combo_mapped} is not part of the custom "
                                    "content."
                                )
        return self.custom_conditions

    def create_step_table(self) -> pd.DataFrame:
        """Extract the icv name and step values from ICVCONTROL."""
        step_table = pd.DataFrame([self.icv_control_table["STEPS"].to_numpy()], columns=self.icv_control_table["ICV"])
        for i, steps in enumerate(step_table.iloc[0]):
            if steps % 2 != 0:
                logger.warning(
                    f"In the casefile table the number of step was '{steps}' for"
                    f" ICV'{step_table.columns[i]}'. The number of step has to be even,"
                    f" and set to {steps + 1}."
                )
                step_table.iloc[0, i] = steps + 1
        return step_table

    def create_table_from_casefile(self, header_name: str) -> pd.DataFrame:
        """Extract the information from the casefile table.

        Args:
           header_name: Column name / header.

        Returns:
           A DataFrame mapping ICVs to its specific table value.
        """

        return pd.DataFrame([self.icv_control_table[header_name].to_numpy()], columns=self.icv_control_table["ICV"])
