"""Entry point for running dogcat as a module."""

from dogcat.app import main

if __name__ == "__main__":
    main()
