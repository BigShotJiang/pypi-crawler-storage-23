"""Dogcat - Python CLI for issue tracking, inspired by Beads."""
