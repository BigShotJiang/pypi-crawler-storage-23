"""Main Dogcat CLI application."""

from dogcat.cli import app, main

__all__ = ["app", "main"]

if __name__ == "__main__":
    main()
