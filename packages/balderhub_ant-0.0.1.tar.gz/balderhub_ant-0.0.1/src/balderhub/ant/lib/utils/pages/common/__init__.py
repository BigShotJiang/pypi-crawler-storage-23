from .common_70_request_data_page import Common70RequestDataPage
from .common_76_mode_settings_page import Common76ModeSettingsPage


__all__ = [
    'Common70RequestDataPage',
    'Common76ModeSettingsPage'
]
