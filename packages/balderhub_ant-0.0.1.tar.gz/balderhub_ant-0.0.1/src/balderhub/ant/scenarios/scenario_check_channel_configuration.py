

# TODO according to HRM Device Profile section 5.2 we need to make sure that the master channel is configured correctly

# TODO make sure that the device-number is not 0x0000!! (see secion 5.2 - table row `Device Number`)

# TODO validate that sensor toggles the toggle bit every four messages (validation of profile itself?)
