"""
마크다운을 블로거로 변환 및 업로드하는 패키지의 메인 모듈입니다.
"""

from .cli import mdb
from .libs.blogger import get_all_posts
from .libs.web_to_markdown import (
    HTMLFetchError,
    convert_html_to_markdown,
    fetch_html_with_playwright,
)
import sys

sys.modules.setdefault(f"{__name__}.__init__", sys.modules[__name__])

__all__ = [
    "mdb",
    "get_all_posts",
    "HTMLFetchError",
    "convert_html_to_markdown",
    "fetch_html_with_playwright",
]
