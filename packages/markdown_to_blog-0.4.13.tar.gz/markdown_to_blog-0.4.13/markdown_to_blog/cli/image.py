"""
Image upload commands.
"""

import sys
from typing import Optional

import click

from . import add_options, mdb


@mdb.command("upload_image", help="Upload one image file to selected uploader service.")
@click.argument("image_path", type=click.Path(exists=True))
@add_options(["service"])
def run_upload_image(image_path: str, service: Optional[str] = None):
    try:
        from ..libs.image_uploader.orchestrator import ImageUploader

        uploader = ImageUploader(service=service)
        url = uploader.upload(image_path)
        click.echo(f"Uploaded image: {url}")
    except Exception as e:
        click.echo(f"Image upload failed: {str(e)}", err=True)
        sys.exit(1)


@mdb.command(
    "upload_images",
    help="Upload images found in a markdown file to configured uploader service.",
)
@click.option(
    "--input",
    "-i",
    "input_",
    required=True,
    help="Path to markdown file containing image links.",
)
def run_upload_images(input_):
    from ..libs.markdown import upload_markdown_images

    upload_markdown_images(input_)
    click.echo("Image upload completed")
