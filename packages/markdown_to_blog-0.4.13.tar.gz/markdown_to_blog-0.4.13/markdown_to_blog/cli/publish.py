"""CLI publish commands."""

import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable, List, Optional

import click
from loguru import logger

from . import mdb, add_options

_AFTER_CHOICES = ["now", "1m", "10m", "1h", "1d", "1w", "1M"]


def _add_publish_options(
    *,
    include_labels: bool = False,
    include_description: bool = False,
    include_thumbnail: bool = True,
    title_help: str = "Post title. If omitted, use the file's first markdown heading.",
    after_default: Optional[str] = None,
    after_prompt: bool = True,
):
    def decorator(f):
        f = click.option(
            "--title",
            "-t",
            required=False,
            default=None,
            help=title_help,
        )(f)
        f = click.option(
            "--draft",
            "is_draft",
            flag_value=True,
            default=False,
            help="Save as draft instead of publishing.",
        )(f)
        f = click.option(
            "--after",
            "-af",
            type=click.Choice(_AFTER_CHOICES, case_sensitive=True),
            default=after_default,
            prompt=after_prompt,
            help="Publish schedule (now, 1m, 10m, 1h, 1d, 1w, 1M).",
        )(f)
        f = click.option(
            "--after_hour",
            "-ah",
            type=int,
            default=None,
            help="Additional publish delay in hours.",
        )(f)
        f = add_options(["blogid"])(f)
        if include_thumbnail:
            f = click.option("--thumbnail", help="Thumbnail image URL.")(f)
        if include_labels:
            f = click.option(
                "--labels",
                "-l",
                default=None,
                help="Comma separated labels/tags.",
            )(f)
        if include_description:
            f = click.option(
                "--description",
                "-d",
                default=None,
                help="SEO description meta content.",
            )(f)

        return f

    return decorator


def _split_labels(raw_labels: Optional[str]) -> Optional[List[str]]:
    if not raw_labels:
        return None
    return [label.strip() for label in raw_labels.split(",") if label.strip()]


def _normalize_description(description: Optional[str]) -> Optional[str]:
    if description == "":
        return None
    return description


def _get_publish_datetime(after: Optional[str], after_hour: Optional[int]) -> str:
    from ..libs.blogger import get_datetime_after, get_datetime_after_hour

    if after_hour is not None:
        return get_datetime_after_hour(after_hour)
    if after is not None:
        return get_datetime_after(after)
    return get_datetime_after("now")


def _resolve_title(title: Optional[str], filename: str, title_resolver: Callable) -> str:
    if title:
        return title

    resolved_title = title_resolver(filename)
    if isinstance(resolved_title, dict):
        resolved_title = resolved_title.get("title")

    if not resolved_title:
        logger.error(f"title is None: {filename}")
        sys.exit(1)

    return str(resolved_title).replace("# ", "")


def _publish_time_label(after: Optional[str], after_hour: Optional[int]) -> str:
    if after_hour is not None:
        return f"{after_hour} hour(s) later"
    if after == "now" or after is None:
        return "now"
    return f"{after} later"


def _print_publish_success(
    post_info: dict,
    is_draft: bool,
    after: Optional[str],
    after_hour: Optional[int],
    labels: Optional[List[str]],
    description: Optional[str],
    publish_type: str = "publish",
) -> None:
    status = "DRAFT" if is_draft else "PUBLISHED"
    publish_time = _publish_time_label(after, after_hour)
    title = post_info.get("title")
    if title:
        click.echo(
            f"[{publish_type}] Title: {title}. Status: {status}. Post ID: {post_info['id']}, URL: {post_info['url']}"
        )
    else:
        click.echo(f"[{publish_type}] Post ID: {post_info['id']}, URL: {post_info['url']}")
    click.echo(f"Publish time: {publish_time}")
    if labels:
        click.echo(f"labels: {', '.join(labels)}")
    if description:
        click.echo(f"description: {description}")


def _publish_to_blogger(
    title: str,
    filename: str,
    blogid: Optional[str],
    is_draft: bool,
    after: Optional[str],
    after_hour: Optional[int],
    labels: Optional[str],
    description: Optional[str],
    thumbnail: Optional[str],
    uploader: Callable,
    fail_message: str,
    publish_type: str = "publish",
) -> None:
    from ..libs.blogger import get_blogid

    blog_id = blogid if blogid else get_blogid()
    datetime_string = _get_publish_datetime(after, after_hour)
    labels_list = _split_labels(labels)
    description_value = _normalize_description(description)

    try:
        post_info = uploader(
            title,
            filename,
            blog_id,
            is_draft=is_draft,
            datetime_string=datetime_string,
            labels=labels_list,
            search_description=description_value,
            thumbnail=thumbnail,
        )
        if publish_type == "publish":
            post_info["title"] = title
        _print_publish_success(
            post_info,
            is_draft=is_draft,
            after=after,
            after_hour=after_hour,
            labels=labels_list,
            description=description_value,
            publish_type=publish_type,
        )
    except Exception as e:
        click.echo(f"{fail_message}: {str(e)}", err=True)
        sys.exit(1)


@mdb.command("publish", help="Publish a markdown file to Blogger.")
@_add_publish_options(
    include_labels=True,
    include_description=True,
    include_thumbnail=True,
    after_default=None,
    after_prompt=True,
)
@click.argument("filename", type=click.Path(exists=True))
def run_publish(
    title, filename, is_draft, after, after_hour, blogid, labels, description, thumbnail
):
    """Publishes a markdown file."""
    from ..libs.blogger import upload_to_blogspot
    from ..libs.markdown import read_first_header_from_md

    title_value = _resolve_title(title, filename, read_first_header_from_md)
    _publish_to_blogger(
        title_value,
        filename,
        blogid,
        is_draft,
        after,
        after_hour,
        labels,
        description,
        thumbnail,
        uploader=upload_to_blogspot,
        fail_message="Failed to publish markdown post",
    )


@mdb.command("easy_publish", help="Publish markdown with Gemini-generated tags and description.")
@_add_publish_options(
    include_labels=False,
    include_description=False,
    include_thumbnail=True,
    after_default="now",
    after_prompt=False,
)
@click.option(
    "--model",
    "-m",
    default="gemini-2.0-flash",
    help="Gemini model name.",
)
@click.argument("filename", type=click.Path(exists=True))
def run_easy_publish(
    title, filename, is_draft, after, after_hour, blogid, thumbnail, model
):
    """Publishes markdown with AI-generated tags and description."""
    from ..libs.blogger import upload_to_blogspot
    from ..libs.gemini import extract_keywords_and_summary
    from ..libs.markdown import read_first_header_from_md

    title_value = _resolve_title(title, filename, read_first_header_from_md)
    try:
        with open(filename, "r", encoding="utf-8") as file:
            markdown_content = file.read()
        click.echo(f"Running Gemini with model: {model}")
        result = extract_keywords_and_summary(markdown_content, model=model)
        keywords = result.get("keywords", [])
        description = result.get("description")
    except Exception as e:
        click.echo(f"Gemini API call failed: {e}", err=True)
        click.echo("Continue publish without AI generated meta values.")
        keywords = []
        description = None

    ai_labels = ",".join(keywords) if keywords else None
    _publish_to_blogger(
        title_value,
        filename,
        blogid,
        is_draft,
        after,
        after_hour,
        ai_labels,
        description,
        thumbnail,
        uploader=upload_to_blogspot,
        fail_message="Failed to publish markdown post",
    )


@mdb.command("publish_html", help="Publish an HTML file to Blogger.")
@_add_publish_options(
    include_labels=True,
    include_description=True,
    include_thumbnail=True,
    after_default=None,
    after_prompt=True,
    title_help="Post title. If omitted, extract from HTML title.",
)
@click.argument("filename", type=click.Path(exists=True))
def run_publish_html(
    title,
    filename,
    is_draft,
    after,
    after_hour,
    blogid,
    labels,
    description,
    thumbnail,
):
    """Publishes an HTML file directly."""
    from ..libs.blogger import extract_article, upload_html_to_blogspot

    title_value = _resolve_title(title, filename, extract_article)
    _publish_to_blogger(
        title_value,
        filename,
        blogid,
        is_draft,
        after,
        after_hour,
        labels,
        description,
        thumbnail,
        uploader=upload_html_to_blogspot,
        fail_message="Failed to publish html post",
        publish_type="publish_html",
    )


@mdb.command(
    "publish_folder",
    help="Publish markdown files in a folder with scheduled intervals.",
)
@add_options(["blogid", "service", "tui"])
@click.option("--interval", "-i", default=1, help="Publish interval in hours.")
@click.option(
    "--draft",
    is_flag=True,
    default=False,
    help="Publish all files as draft.",
)
@click.option(
    "--labels",
    "-l",
    multiple=True,
    help="Labels to apply to all posts.",
)
@click.argument(
    "folder_path", type=click.Path(exists=True, file_okay=False, dir_okay=True)
)
def run_publish_folder(blogid, interval, service, tui, draft, labels, folder_path):
    """Publish markdown files in folder by schedule."""
    from ..libs.blogger import get_blogid, upload_to_blogspot
    from ..libs.markdown import read_first_header_from_md, upload_markdown_images

    blog_id = blogid if blogid else get_blogid()
    labels_list = list(labels) if labels else None

    try:
        folder = Path(folder_path)
        if not folder.exists() or not folder.is_dir():
            click.echo(f"invalid folder: {folder_path}", err=True)
            sys.exit(1)

        seoul_timezone = timezone(timedelta(hours=9))
        current_dt = datetime.now(seoul_timezone)

        file_list = list(folder.glob("*.md"))
        if not file_list:
            click.echo(f"No markdown file found in: {folder_path}")
            return

        total_files = len(file_list)
        success_count = 0
        error_count = 0

        with click.progressbar(
            file_list, label=f"Publish folder files total={total_files}", show_pos=True
        ) as files:
            for idx, file in enumerate(files, 1):
                file_name = file.name
                try:
                    file_path = file.resolve()
                    file_title = read_first_header_from_md(file_path)
                    file_title = file_title.replace("# ", "") if file_title else file.stem
                    target_dt = current_dt + timedelta(hours=interval * idx)
                    datetime_string = target_dt.isoformat(timespec="seconds")

                    logger.info(f"Uploading images from file: {file_name}")
                    upload_markdown_images(str(file_path))

                    upload_to_blogspot(
                        file_title,
                        file_path,
                        blog_id,
                        is_draft=draft,
                        datetime_string=datetime_string,
                        labels=labels_list,
                    )
                    success_count += 1
                except Exception as e:
                    logger.error(f"Error processing file {file_name}: {str(e)}")
                    error_count += 1

        if success_count == total_files:
            click.echo(f"Published {total_files} files successfully.")
        else:
            click.echo(
                f"Publish result: success {success_count}, fail {error_count} of {total_files}."
            )
    except Exception as e:
        click.echo(f"Failed to publish folder: {str(e)}", err=True)
        sys.exit(1)
