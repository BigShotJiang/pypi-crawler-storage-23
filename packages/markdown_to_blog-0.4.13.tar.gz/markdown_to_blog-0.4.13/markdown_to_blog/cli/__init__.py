"""
CLI 명령어 모듈 - 메인 command group과 공통 유틸리티
"""

import importlib
from typing import Callable, List

import click

from ..libs.click_order import CustomOrderGroup

# 공통 옵션 기본값 및 설명
COMMON_OPTIONS = {
    "tui": {
        "is_flag": True,
        "default": False,
        "help": "TUI(Text User Interface) 모드로 진행 상황을 표시합니다.",
    },
    "blogid": {
        "param": "--blogid",
        "short": "-b",
        "default": None,
        "help": "업로드하려는 블로그 ID 지정. 미지정 시 설정값 사용.",
    },
    "service": {
        "param": "--service",
        "short": "-s",
        "help": "사용할 이미지 업로드 서비스. 미지정 시 랜덤 선택.",
    },
}


class LazyOrderGroup(CustomOrderGroup):
    """Lazy-load command modules to reduce startup time."""

    def __init__(self, *args, **kwargs):
        self._lazy_commands = kwargs.pop("lazy_commands", {})
        super().__init__(*args, **kwargs)

    def get_command(self, ctx, cmd_name):
        command = super().get_command(ctx, cmd_name)
        if command is not None:
            return command

        module_path = self._lazy_commands.get(cmd_name)
        if not module_path:
            return None

        importlib.import_module(module_path)
        return super().get_command(ctx, cmd_name)

    def format_commands(self, ctx, formatter):
        """Avoid importing all commands just to render help text."""
        rows = [(name, "") for name in self.list_commands(ctx)]
        if rows:
            with formatter.section("Commands"):
                formatter.write_dl(rows)


def add_options(options: List[str]) -> Callable:
    """옵션들을 명령어에 일관되게 추가하는 데코레이터 함수"""

    def decorator(f):
        for option_name in reversed(options):
            if option_name == "tui":
                f = click.option("--tui", **COMMON_OPTIONS["tui"])(f)
            elif option_name == "blogid":
                f = click.option(
                    COMMON_OPTIONS["blogid"]["param"],
                    COMMON_OPTIONS["blogid"]["short"],
                    default=COMMON_OPTIONS["blogid"]["default"],
                    help=COMMON_OPTIONS["blogid"]["help"],
                )(f)
            elif option_name == "service":
                from ..libs.image_uploader.registry import get_available_services

                f = click.option(
                    COMMON_OPTIONS["service"]["param"],
                    COMMON_OPTIONS["service"]["short"],
                    type=click.Choice(
                        get_available_services(), case_sensitive=False
                    ),
                    help=COMMON_OPTIONS["service"]["help"],
                )(f)
        return f

    return decorator


@click.command(
    cls=LazyOrderGroup,
    order=[
        "set_blogid",
        "get_blogid",
        "convert",
        "refresh_auth",
        "set_client_secret",
        "backup-posting",
        "sync-posting",
        "update-posting",
        "delete-posting",
        "search-posting",
        "save-as-markdown",
        "publish",
        "easy_publish",
        "upload_image",
        "upload_images",
        "publish_folder",
        "publish_html",
        "list_my_blogs",
    ],
    lazy_commands={
        "set_blogid": "markdown_to_blog.cli.blog",
        "get_blogid": "markdown_to_blog.cli.blog",
        "list_my_blogs": "markdown_to_blog.cli.blog",
        "set_client_secret": "markdown_to_blog.cli.auth",
        "refresh_auth": "markdown_to_blog.cli.auth",
        "convert": "markdown_to_blog.cli.convert",
        "save-as-markdown": "markdown_to_blog.cli.convert",
        "publish": "markdown_to_blog.cli.publish",
        "easy_publish": "markdown_to_blog.cli.publish",
        "publish_html": "markdown_to_blog.cli.publish",
        "publish_folder": "markdown_to_blog.cli.publish",
        "upload_image": "markdown_to_blog.cli.image",
        "upload_images": "markdown_to_blog.cli.image",
        "backup-posting": "markdown_to_blog.cli.posting",
        "sync-posting": "markdown_to_blog.cli.posting",
        "update-posting": "markdown_to_blog.cli.posting",
        "delete-posting": "markdown_to_blog.cli.posting",
        "search-posting": "markdown_to_blog.cli.posting",
    },
)
def mdb():
    """Markdown to Blogger - 마크다운 파일을 블로거에 발행하는 도구."""
    click.echo("markdown to blogger\nresult:\n\n")


__all__ = ["mdb", "add_options", "COMMON_OPTIONS"]
