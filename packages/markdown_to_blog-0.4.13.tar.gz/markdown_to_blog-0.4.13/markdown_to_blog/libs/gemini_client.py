from __future__ import annotations

import os
from typing import Any

from loguru import logger

try:
    import google.generativeai as genai
except ImportError:
    logger.error("google-generativeai 패키지가 설치되지 않았습니다. 설치해주세요: uv sync")
    genai = None

_CONFIGURED_API_KEY: str | None = None
_MODEL_CACHE: dict[tuple[str, str], Any] = {}


def ensure_genai(error_message: str | None = None) -> Any:
    """Return the genai module or raise ImportError if unavailable."""
    if genai is None:
        raise ImportError(
            error_message
            or "google-generativeai 패키지가 설치되지 않았습니다. 설치해주세요: uv sync"
        )
    return genai


def resolve_api_key(api_key: str | None, *, error_message: str) -> str:
    """Resolve API key from parameter or environment."""
    if api_key:
        return api_key
    env_key = os.getenv("GEMINI_API_KEY")
    if env_key:
        return env_key
    raise ValueError(error_message)


def configure_genai(api_key: str) -> None:
    """Configure genai only when API key changes."""
    global _CONFIGURED_API_KEY
    genai_module = ensure_genai()
    if _CONFIGURED_API_KEY != api_key:
        genai_module.configure(api_key=api_key)
        _CONFIGURED_API_KEY = api_key


def get_generative_model(model: str, api_key: str) -> Any:
    """Get or create a cached GenerativeModel instance."""
    configure_genai(api_key)
    cache_key = (api_key, model)
    if cache_key not in _MODEL_CACHE:
        genai_module = ensure_genai()
        _MODEL_CACHE[cache_key] = genai_module.GenerativeModel(model)
    return _MODEL_CACHE[cache_key]
