﻿from __future__ import annotations

from pathlib import Path
from typing import Dict
from urllib.parse import urljoin

from .base import BaseImageUploader, ImageUploadError


class BeeimgUploader(BaseImageUploader):
    service_name = "Beeimg"

    def _upload_to_host(self, image_path: str) -> str:
        file_name = Path(image_path).name
        with open(image_path, "rb") as image_file:
            response = self._request_post(
                "https://beeimg.com/api/v2/upload",
                files={"file": (file_name, image_file)},
            )

        self._ensure_status_ok(response)

        try:
            payload: Dict[str, str] = response.json()
        except Exception as exc:
            raise ImageUploadError(f"{self.service_name} response parse error: {exc}") from exc

        if not isinstance(payload, dict):
            raise ImageUploadError(f"{self.service_name} response format is invalid")

        image_url = payload.get("url")
        if not image_url:
            raise ImageUploadError(f"{self.service_name} response does not include a URL")
        return str(image_url)


class FreeimageMoeUploader(BaseImageUploader):
    service_name = "Freeimage"

    def _upload_to_host(self, image_path: str) -> str:
        file_name = Path(image_path).name
        with open(image_path, "rb") as image_file:
            response = self._request_post(
                "https://freeimage.host/api/1/upload",
                files={"source": (file_name, image_file)},
            )

        self._ensure_status_ok(response)

        try:
            payload = response.json()
        except Exception as exc:
            raise ImageUploadError(f"{self.service_name} response parse error: {exc}") from exc

        if not isinstance(payload, dict):
            raise ImageUploadError(f"{self.service_name} response format is invalid")

        image_obj = payload.get("image")
        if not isinstance(image_obj, dict):
            raise ImageUploadError(f"{self.service_name} response does not include an image object")

        image_url = image_obj.get("url")
        if not image_url:
            raise ImageUploadError(f"{self.service_name} response does not include a URL")
        return str(image_url)


class CatboxUploader(BaseImageUploader):
    service_name = "Catbox"

    def _upload_to_host(self, image_path: str) -> str:
        file_name = Path(image_path).name
        with open(image_path, "rb") as image_file:
            response = self._request_post(
                "https://catbox.moe/user/api.php",
                files={"fileToUpload": (file_name, image_file)},
                data={"reqtype": "fileupload"},
            )

        self._ensure_status_ok(response)

        text = str(response.text).strip()
        if not text.startswith("http://") and not text.startswith("https://"):
            raise ImageUploadError(f"{self.service_name} expected a URL response, got: {text}")
        return text


class TelegraphUploader(BaseImageUploader):
    service_name = "Telegraph"

    def _upload_to_host(self, image_path: str) -> str:
        file_name = Path(image_path).name
        with open(image_path, "rb") as image_file:
            response = self._request_post(
                "https://telegra.ph/upload",
                files={"file": (file_name, image_file)},
            )

        self._ensure_status_ok(response)

        try:
            payload = response.json()
        except Exception as exc:
            raise ImageUploadError(f"{self.service_name} response parse error: {exc}") from exc

        if not payload:
            raise ImageUploadError(f"{self.service_name} response is empty")
        if not isinstance(payload, list) or not payload:
            raise ImageUploadError(f"{self.service_name} response format is invalid")

        source = payload[0].get("src") if isinstance(payload[0], dict) else None
        if not source:
            raise ImageUploadError(f"{self.service_name} response does not include a URL")
        return urljoin("https://telegra.ph", source)


class ImgurUploader(BaseImageUploader):
    service_name = "Imgur"

    def _upload_to_host(self, image_path: str) -> str:
        import os

        import pyimgur

        client_id = os.getenv("IMGUR_CLIENT_ID", "")
        try:
            client = pyimgur.Imgur(client_id)
            uploaded = client.upload_image(image_path, title="SceneStealer")
            link = getattr(uploaded, "link", None)
            if not link:
                raise ImageUploadError("Imgur upload failed: missing image link")
            return str(link)
        except ImageUploadError:
            raise
        except Exception as exc:
            raise ImageUploadError(f"Imgur upload failed: {exc}") from exc


__all__ = [
    "ImageUploadError",
    "BaseImageUploader",
    "BeeimgUploader",
    "CatboxUploader",
    "FreeimageMoeUploader",
    "TelegraphUploader",
    "ImgurUploader",
]
