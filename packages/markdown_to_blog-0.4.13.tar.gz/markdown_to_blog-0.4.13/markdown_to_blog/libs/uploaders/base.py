﻿from __future__ import annotations

from typing import Any

from ..image_uploader.errors import ImageUploadError as CoreImageUploadError


class ImageUploadError(CoreImageUploadError):
    """Base exception for legacy uploader shim."""


class BaseImageUploader:
    """Small compatibility base uploader for direct CLI-style integrations."""

    service_name = ""

    def _request_post(self, url: str, **kwargs) -> Any:
        import requests

        return requests.post(url, **kwargs)

    def _ensure_status_ok(self, response) -> None:
        status_code = getattr(response, "status_code", 0)
        if status_code != 200:
            raise ImageUploadError(f"{self.service_name} API error: HTTP {status_code}")
