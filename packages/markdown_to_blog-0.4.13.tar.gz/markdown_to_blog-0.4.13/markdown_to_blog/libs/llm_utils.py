from __future__ import annotations

import json
import re
from typing import Any

_CODE_FENCE_RE = re.compile(r"```(?:json)?\s*([\s\S]*?)\s*```", re.IGNORECASE)


def extract_first_json_object(text: str) -> str:
    """Extract the first JSON object from an LLM response."""
    payload = str(text).strip()
    if payload.startswith("{") and payload.endswith("}"):
        return payload

    fenced = _CODE_FENCE_RE.search(payload)
    if fenced:
        inner = fenced.group(1).strip()
        if inner.startswith("{") and inner.endswith("}"):
            return inner

    match = re.search(r"\{[\s\S]*\}", payload)
    if not match:
        raise ValueError("LLM 응답에서 JSON 객체를 찾을 수 없습니다.")
    return match.group(0)


def parse_json_response(text: str) -> dict[str, Any]:
    """Parse a JSON object from an LLM response text."""
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
    except Exception:
        pass

    obj = extract_first_json_object(text)
    data2 = json.loads(obj)
    if not isinstance(data2, dict):
        raise ValueError("LLM JSON 응답이 object(dict)가 아닙니다.")
    return data2
