import codecs
import os
from typing import Dict, List, Optional, Tuple

from loguru import logger
from markdown2 import Markdown

from .config_manager import DEFAULT_MARKDOWN_EXTRAS
from .image_uploader.orchestrator import ImageUploader
from .image_uploader.settings import UploadConfig


def convert_markdown(converter: Markdown, text: str):
    return converter.convert(text)


def convert(input_fn, output_fn, is_temp=False):
    with codecs.open(input_fn, "r", "utf_8") as fp:
        markdowner = Markdown(extras=DEFAULT_MARKDOWN_EXTRAS)
        html = markdowner.convert(fp.read())
        with codecs.open(output_fn, "w", "utf_8") as fwp:
            fwp.write(html)


def read_first_header_from_md(file_path) -> Optional[str]:
    with open(file_path, "r", encoding="utf-8") as file:
        for line in file:
            if line.startswith("#"):
                return line.strip()
    return None


def _extract_images_from_markdown(file_path: str) -> List[Tuple[int, str]]:
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Markdown file not found: {file_path}")

    images = []
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            for i, line in enumerate(file):
                if line.startswith("![") and "]" in line:
                    try:
                        image_link = line.split("(")[1].split(")")[0].strip()
                        if image_link:
                            images.append((i, image_link))
                    except IndexError:
                        logger.warning(
                            f"Failed to parse markdown image link at line {i + 1}: {line.strip()}"
                        )
    except IOError as e:
        logger.error(f"Error reading markdown file: {e}")
        raise

    return images


def _replace_image_links(
    content: str,
    image_map: Dict[str, str],
) -> str:
    logger.info("Replacing image links...")
    logger.debug(f"Image map: {image_map}")

    updated_content = content
    for original_link, new_link in image_map.items():
        updated_content = updated_content.replace(f"({original_link})", f"({new_link})")

    return updated_content


def upload_markdown_images(
    file_path: str,
) -> Dict[str, str]:
    logger.info(f"Uploading images from markdown file: {file_path}")

    image_links = _extract_images_from_markdown(file_path)
    if not image_links:
        logger.info(f"No image links found in markdown file: {file_path}")
        return {}

    total_images = len(image_links)
    logger.info(f"Total images found: {total_images}")

    config = UploadConfig()
    uploader = ImageUploader(config=config)
    image_map: Dict[str, str] = {}
    for _, link in image_links:
        try:
            image_map[link] = uploader.upload(link)
        except Exception as e:
            logger.error(f"Image upload failed: {link} -> {e}")

    with open(file_path, "r", encoding="utf-8") as file:
        content = file.read()

    if image_map:
        updated_content = _replace_image_links(content, image_map)
        with open(file_path, "w", encoding="utf-8") as file:
            file.write(updated_content)

        success_count = len(image_map)
        if success_count < total_images:
            logger.warning(f"Image upload result: {success_count}/{total_images} succeeded")
        else:
            logger.info(f"Image upload succeeded: {success_count}/{total_images}")
    else:
        logger.warning("No images were uploaded, file was not changed.")

    return image_map
