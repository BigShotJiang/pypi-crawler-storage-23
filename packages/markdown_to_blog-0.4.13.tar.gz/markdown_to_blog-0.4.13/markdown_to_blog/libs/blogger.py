import codecs
import pathlib
import shutil
from datetime import datetime, timedelta, timezone
from typing import List, Optional

import httplib2
from bs4 import BeautifulSoup
from googleapiclient import discovery, errors
from loguru import logger
from markdown2 import Markdown
from oauth2client.client import flow_from_clientsecrets
from oauth2client.file import Storage
from oauth2client.tools import run_flow

from .config_manager import (
    CLIENT_SECRET_PATH,
    CONFIG_BASE_DIR,
    CREDENTIAL_STORAGE_PATH,
    DEFAULT_MARKDOWN_EXTRAS,
    get_config_manager,
)

SCOPE = "https://www.googleapis.com/auth/blogger"


def _build_post_payload(
    title: str,
    content: str,
    datetime_string: Optional[str],
    labels: Optional[List[str]],
    search_description: Optional[str],
    thumbnail: Optional[str],
) -> dict:
    payload = {
        "title": title,
        "content": content,
        "published": datetime_string,
    }

    if labels:
        payload["labels"] = labels

    if search_description:
        payload["content"] = (
            f'<meta name="description" content="{search_description}"/>\n'
            + payload["content"]
        )

    if thumbnail:
        thumbnail_html = f"""
<div class=\"separator\" style=\"clear: both;\"><a href=\"{thumbnail}\" style=\"display: block; padding: 1em 0; text-align: center; \"><img alt=\"\" border=\"0\" width=\"400\" data-original-height=\"360\" data-original-width=\"640\" src=\"{thumbnail}\"/></a></div>
"""
        payload["content"] = thumbnail_html + payload["content"]

    return payload


def extract_article(fn):
    """
    Extracts the title and content of an article from an HTML file.

    Args:
        fn (str): The path to the HTML file.

    Returns:
        dict: A dictionary containing the extracted title and content.
    """
    with codecs.open(fn, "r", "utf_8") as fp:
        html = fp.read()
        html = html.replace("<!doctype html>", "")
        soup = BeautifulSoup(html, "html.parser")
        title = soup.select("title")[0].text
        article = soup.select("body")[0]
        return {"title": title, "content": article.prettify()}


def authorize_credentials():
    """Authorizes credentials."""
    validate_credential_path()
    storage = Storage(CREDENTIAL_STORAGE_PATH)
    credentials = storage.get()
    if credentials is None or credentials.invalid:
        flow = flow_from_clientsecrets(CLIENT_SECRET_PATH, scope=SCOPE)
        http = httplib2.Http()
        credentials = run_flow(flow, storage, http=http)
    return credentials


def get_blogger_service():
    credentials = authorize_credentials()
    http = credentials.authorize(httplib2.Http())
    discoveryUrl = "https://{api}.googleapis.com/$discovery/rest?version={apiVersion}"
    return discovery.build("blogger", "v3", http=http, discoveryServiceUrl=discoveryUrl)


def list_my_blogs():
    service = get_blogger_service()
    result = service.blogs().listByUser(userId="self").execute()
    blogs = result.get("items", [])
    if not blogs:
        print("No blogs found.")
        return []
    for blog in blogs:
        print(f"Name: {blog.get('name')}")
        print(f"ID: {blog.get('id')}")
        print(f"URL: {blog.get('url')}")
        print("-" * 40)
    return [(blog.get("id"), blog.get("url")) for blog in blogs]


def _get_blogger_connection(blog_id=None):
    validate_credential_path()
    service = get_blogger_service()
    users = service.users()
    thisuser = users.get(userId="self").execute()
    logger.info(f"""This user's display name is: {thisuser["displayName"]}""")
    posts = service.posts()

    if blog_id is None:
        blog_id = get_blogid()

    return service, users, posts, blog_id


def validate_credential_path():
    target_dir = pathlib.Path(CONFIG_BASE_DIR)
    if not target_dir.exists():
        target_dir.mkdir(parents=True, exist_ok=True)

    target_path = pathlib.Path(CREDENTIAL_STORAGE_PATH)
    if not target_path.exists():
        target_path.touch()


def check_config():
    get_config_manager()


def set_blogid(value):
    get_config_manager().set_blog_id(value)
    logger.info(f"Blog id is set to {value}")


def get_blogid():
    return get_config_manager().get_blog_id()


def set_client_secret(fn):
    shutil.copy(fn, CLIENT_SECRET_PATH)
    logger.info(f"Client secret is set to {CLIENT_SECRET_PATH}")


def upload_to_blogspot(
    title,
    fn,
    BLOG_ID,
    is_draft=False,
    datetime_string=None,
    labels=None,
    search_description=None,
    thumbnail=None,
) -> dict:
    _, _, posts, _ = _get_blogger_connection(BLOG_ID)

    with codecs.open(fn, "r", "utf_8") as fp:
        markdowner = Markdown(extras=DEFAULT_MARKDOWN_EXTRAS)
        html = markdowner.convert(fp.read())
        payload = _build_post_payload(
            title=title,
            content=html,
            datetime_string=datetime_string,
            labels=labels,
            search_description=search_description,
            thumbnail=thumbnail,
        )

        output = posts.insert(blogId=BLOG_ID, body=payload, isDraft=is_draft).execute()
        logger.info(
            f"id:{output['id']}, url:{output['url']}, status:{output['status']}"
        )
        return {"id": output["id"], "url": output["url"]}


def upload_html_to_blogspot(
    title,
    fn,
    BLOG_ID,
    is_draft=False,
    datetime_string=None,
    labels=None,
    search_description=None,
    thumbnail=None,
) -> dict:
    _, _, posts, _ = _get_blogger_connection(BLOG_ID)

    with codecs.open(fn, "r", "utf_8") as fp:
        html = fp.read()
        payload = _build_post_payload(
            title=title,
            content=html,
            datetime_string=datetime_string,
            labels=labels,
            search_description=search_description,
            thumbnail=thumbnail,
        )

        output = posts.insert(blogId=BLOG_ID, body=payload, isDraft=is_draft).execute()
        logger.info(
            f"id:{output['id']}, url:{output['url']}, status:{output['status']}"
        )
        return {"id": output["id"], "url": output["url"]}


def get_datetime_after(after_string):
    seoul_timezone = timezone(timedelta(hours=9))
    current_dt = datetime.now(seoul_timezone)

    if after_string and after_string.isdigit():
        return get_datetime_after_hour(int(after_string))

    match after_string:
        case "now":
            target_dt = current_dt
        case "1m":
            target_dt = current_dt + timedelta(minutes=1)
        case "10m":
            target_dt = current_dt + timedelta(minutes=10)
        case "1h":
            target_dt = current_dt + timedelta(hours=1)
        case "1d":
            target_dt = current_dt + timedelta(days=1)
        case "1w":
            target_dt = current_dt + timedelta(days=7)
        case "1M":
            target_dt = current_dt + timedelta(days=30)
        case _:
            target_dt = current_dt

    return target_dt.isoformat(timespec="seconds")


def update_post(
    blog_id: str,
    post_id: str,
    title: str,
    html_content: str,
    is_draft: bool,
    labels: Optional[List[str]] = None,
    search_description: Optional[str] = None,
) -> dict:
    service = get_blogger_service()
    content_to_upload = html_content
    if search_description:
        content_to_upload = (
            f'<meta name="description" content="{search_description}"/>\n{html_content}'
        )

    post_body = {
        "title": title,
        "content": content_to_upload,
        "status": (
            "DRAFT" if is_draft else "LIVE"
        ),
    }

    if labels is not None:
        post_body["labels"] = labels

    try:
        updated_post = (
            service.posts()
            .update(blogId=blog_id, postId=post_id, body=post_body)
            .execute()
        )
        logger.info(
            f"Post {updated_post['id']} updated successfully in blog {blog_id}."
        )
        return updated_post
    except errors.HttpError as e:
        logger.error(
            f"Error updating post {post_id} in blog {blog_id}: {e.resp.status} {e._get_reason()}"
        )
        raise


def delete_post(blog_id: str, post_id: str) -> None:
    service = get_blogger_service()
    try:
        service.posts().delete(blogId=blog_id, postId=post_id).execute()
        logger.info(f"Post {post_id} deleted successfully from blog {blog_id}.")
    except errors.HttpError as e:
        logger.error(
            f"Error deleting post {post_id} from blog {blog_id}: {e.resp.status} {e._get_reason()}"
        )
        raise


def get_all_posts(blog_id: str) -> list:
    service = get_blogger_service()
    all_posts = []
    page_token = None
    while True:
        try:
            posts_request = service.posts().list(
                blogId=blog_id,
                fetchBodies=True,
                status="LIVE",
                pageToken=page_token,
            )
            posts_result = posts_request.execute()
            items = posts_result.get("items", [])
            all_posts.extend(items)
            page_token = posts_result.get("nextPageToken")
            if not page_token:
                break
        except Exception as e:
            logger.error(f"Error fetching posts for blog ID {blog_id}: {e}")
            break
    logger.info(f"Retrieved {len(all_posts)} posts for blog ID {blog_id}.")
    return all_posts


def get_datetime_after_hour(hour):
    if hour is None:
        return get_datetime_after("now")

    seoul_timezone = timezone(timedelta(hours=9))
    current_dt = datetime.now(seoul_timezone)
    target_dt = current_dt + timedelta(hours=hour)
    return target_dt.isoformat(timespec="seconds")
