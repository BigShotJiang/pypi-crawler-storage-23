﻿"""Utility helpers for running uploader subprocesses."""

from __future__ import annotations

import subprocess
import time
from typing import Callable, Optional

from .defaults import (
    PROGRESS_STEP_PERCENT,
    TOTAL_PROGRESS_PERCENT,
    UPLOAD_COMMAND_TIMEOUT_SECONDS,
)
from .errors import ImageUploadError
from .url import URLHandler

OutputCallback = Callable[[str], None]
ProgressCallback = Callable[[int], None]


def _safe_read_line(stream) -> str:
    """Read one line from a stream safely for both real pipes and mocks."""
    if stream is None:
        return ""

    reader = getattr(stream, "readline", None)
    if not callable(reader):
        reader = getattr(stream, "read", None)
    if not callable(reader):
        return ""

    value = reader()
    if value is None:
        return ""
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="replace")
    if not isinstance(value, str):
        return ""
    return value


def run_upload_process(
    process: subprocess.Popen[str],
    *,
    on_output: Optional[OutputCallback] = None,
    on_error_output: Optional[OutputCallback] = None,
    on_progress: Optional[ProgressCallback] = None,
    max_wait_time: int = UPLOAD_COMMAND_TIMEOUT_SECONDS,
    total_progress: int = TOTAL_PROGRESS_PERCENT,
    progress_step: int = PROGRESS_STEP_PERCENT,
) -> str:
    """Run one upload command and return the uploaded image URL."""
    stdout_lines = []
    stderr_lines = []
    start_time = time.time()
    progress_count = 0

    try:
        while True:
            if time.time() - start_time > max_wait_time:
                raise ImageUploadError("이미지 업로드 오류: 업로드가 시간 초과되었습니다")

            if process.stdout is None or process.stderr is None:
                raise ImageUploadError("Process streams are unavailable")

            output = _safe_read_line(process.stdout)
            error = _safe_read_line(process.stderr)

            if not output and not error and process.poll() is not None:
                break

            if error:
                error_msg = error.strip()
                stderr_lines.append(error_msg)
                if on_error_output:
                    on_error_output(error_msg)

            if output:
                line = output.strip()
                stdout_lines.append(line)

                if "Progress:" in line or "Uploading:" in line:
                    progress_count = min(
                        progress_count + progress_step,
                        total_progress,
                    )
                    if on_progress:
                        on_progress(progress_count)

                if on_output:
                    on_output(line)

            if not output and not error and process.poll() is None:
                time.sleep(0.05)

        return_code = process.wait()
        if return_code != 0:
            error_msg = "\n".join(stderr_lines) if stderr_lines else "Unknown process error"
            raise ImageUploadError(
                f"이미지 업로드 오류: 업로드 실패 (종료 코드 {return_code}) - {error_msg}"
            )

        if not stdout_lines:
            raise ImageUploadError("이미지 업로드 오류: 업로드 결과 URL을 찾을 수 없습니다")

        try:
            candidate_urls = [
                line
                for line in stdout_lines
                if line.lower().startswith(("http://", "https://"))
            ]
            url = candidate_urls[-1] if candidate_urls else stdout_lines[-1]
            return URLHandler.normalize_url(url)
        except Exception as exc:
            raise ImageUploadError(f"이미지 업로드 오류: 반환 URL 파싱 실패 - {exc}") from exc

    finally:
        try:
            process.kill()
        except Exception:
            pass
