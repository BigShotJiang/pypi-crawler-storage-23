﻿from __future__ import annotations

import os
import random
import subprocess
import sys
from abc import abstractmethod
from typing import List, Optional, Protocol

from loguru import logger

from .defaults import (
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_DELAY_SECONDS,
    TOTAL_PROGRESS_PERCENT,
    format_upload_log_message,
)
from .errors import ImageUploadError
from .runner import run_upload_process
from .tui import UploadStatus
from .logging import log_operation


class ImageUploadService(Protocol):
    """Uploader protocol."""

    @abstractmethod
    def upload(self, file_path: str) -> str:
        ...


class DefaultImageUploader(ImageUploadService):
    """Default image uploader implementation."""

    def __init__(self, service: Optional[str] = None, use_tui: bool = False):
        self.service = service
        self.max_retries = DEFAULT_MAX_RETRIES
        self.retry_delay = DEFAULT_RETRY_DELAY_SECONDS
        self._used_services = set()
        self._progress_count = 0
        self._total_progress = TOTAL_PROGRESS_PERCENT
        self.use_tui = use_tui
        self.progress_viewer = None

        if self.use_tui:
            logger.remove()
            logger.add(lambda _: None)

    def _init_progress_viewer(self, markdown_file: str, image_files: List[str]):
        if self.use_tui:
            from .tui import ProgressViewer

            self.progress_viewer = ProgressViewer(markdown_file, image_files, True)
            self.progress_viewer.start()

    def _update_progress(
        self,
        image_path: str,
        status: str,
        service: str = "",
        attempt: int = 0,
        progress: int = 0,
        url: str = "",
        error: str = "",
    ):
        if self.progress_viewer:
            self.progress_viewer.update(
                image_path, status, service, attempt, progress, url, error
            )

    @log_operation
    def upload_markdown_images(
        self, markdown_file: str, image_files: List[str]
    ) -> List[str]:
        self._init_progress_viewer(markdown_file, image_files)
        uploaded_urls = []

        try:
            for image_path in image_files:
                try:
                    self._update_progress(image_path, UploadStatus.UPLOADING)
                    url = self.upload(image_path)
                    uploaded_urls.append(url)
                    self._update_progress(image_path, UploadStatus.SUCCESS, url=url)
                except Exception as e:
                    self._update_progress(image_path, UploadStatus.FAILED, error=str(e))
                    raise
        finally:
            if self.progress_viewer:
                self.progress_viewer.stop()

        return uploaded_urls

    def _reset_progress(self):
        self._progress_count = 0
        self._total_progress = TOTAL_PROGRESS_PERCENT

    def _select_next_service(self) -> str:
        from .registry import get_available_services

        available_services = get_available_services()

        if not available_services:
            raise ImageUploadError("사용 가능한 업로드 서비스를 찾을 수 없습니다")

        if self.service:
            if self.service not in available_services:
                raise ImageUploadError(
                    f"요청한 서비스({self.service})는 지원되지 않습니다"
                )
            return self.service

        unused_services = [
            s for s in available_services if s not in self._used_services
        ]
        if not unused_services:
            self._used_services.clear()
            unused_services = available_services

        selected_service = random.choice(unused_services)
        self._used_services.add(selected_service)
        return selected_service

    @log_operation
    def upload(self, file_path: str) -> str:
        try:
            if not os.path.exists(file_path):
                raise ImageUploadError(f"파일이 존재하지 않습니다: {file_path}")

            last_error = None
            self._used_services.clear()
            self._reset_progress()

            for attempt in range(self.max_retries):
                process = None
                attempt_no = attempt + 1
                try:
                    service = self._select_next_service()
                    if not self.use_tui:
                        logger.info(
                            format_upload_log_message(
                                service=service,
                                status="START",
                                attempt=attempt_no,
                                message="업로드 시작",
                            )
                        )

                    if self.progress_viewer:
                        self._update_progress(
                            file_path, UploadStatus.UPLOADING, service=service, attempt=attempt_no
                        )

                    cmd = [
                        sys.executable,
                        "-m",
                        "images_upload_cli",
                        "-h",
                        service,
                        file_path,
                    ]

                    process = subprocess.Popen(
                        cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        shell=False,
                        text=True,
                        universal_newlines=True,
                        env=os.environ.copy(),
                    )

                    def on_output(line: str) -> None:
                        if self.use_tui:
                            return
                        logger.info(
                            format_upload_log_message(
                                service=service,
                                status="PROGRESS",
                                attempt=attempt_no,
                                progress=(self._progress_count, self._total_progress),
                                message=line,
                            )
                        )

                    def on_error_output(line: str) -> None:
                        if not self.use_tui:
                            logger.warning(
                                format_upload_log_message(
                                    service=service,
                                    status="ERROR",
                                    attempt=attempt_no,
                                    progress=(self._progress_count, self._total_progress),
                                    message=line,
                                )
                            )
                        if self.progress_viewer:
                            self._update_progress(
                                file_path,
                                UploadStatus.ERROR,
                                service=service,
                                attempt=attempt_no,
                                progress=self._progress_count,
                                error=line,
                            )

                    def on_progress(progress: int) -> None:
                        self._progress_count = progress
                        if self.progress_viewer:
                            self._update_progress(
                                file_path,
                                UploadStatus.UPLOADING,
                                service=service,
                                attempt=attempt_no,
                                progress=progress,
                            )

                    result = run_upload_process(
                        process=process,
                        on_output=on_output,
                        on_error_output=on_error_output,
                        on_progress=on_progress,
                    )

                    if not self.use_tui:
                        logger.info(
                            format_upload_log_message(
                                service=service,
                                status="SUCCESS",
                                attempt=attempt_no,
                                progress=(self._total_progress, self._total_progress),
                                message=f"업로드 완료: {result}",
                            )
                        )

                    if self.progress_viewer:
                        self._update_progress(
                            file_path,
                            UploadStatus.SUCCESS,
                            service=service,
                            attempt=attempt_no,
                            progress=self._total_progress,
                            url=result,
                        )

                    return result

                except ImageUploadError as e:
                    last_error = e
                    if not self.use_tui:
                        logger.warning(
                            format_upload_log_message(
                                service=service,
                                status="FAIL",
                                attempt=attempt_no,
                                progress=(self._progress_count, self._total_progress),
                                message=str(e),
                            )
                        )

                    if self.progress_viewer:
                        self._update_progress(
                            file_path,
                            UploadStatus.FAILED,
                            service=service,
                            attempt=attempt_no,
                            progress=self._progress_count,
                            error=str(e),
                        )

                    if attempt < self.max_retries - 1:
                        wait_time = self.retry_delay * (attempt + 1)
                        if not self.use_tui:
                            logger.info(
                                format_upload_log_message(
                                    service=service,
                                    status="WAIT",
                                    attempt=attempt_no,
                                    progress=(self._progress_count, self._total_progress),
                                    message=f"{wait_time}초 대기",
                                )
                            )
                        import time as _time

                        _time.sleep(wait_time)
                    continue

                finally:
                    if process:
                        try:
                            process.kill()
                        except Exception:
                            pass

            error_msg = "모든 업로드 시도 실패. 시도한 서비스: " + ", ".join(self._used_services)
            if last_error:
                error_msg += f"\n원인: {str(last_error)}"
            raise ImageUploadError(error_msg)

        finally:
            if self.use_tui:
                logger.remove()
                logger.add(lambda msg: print(msg, end=""))

