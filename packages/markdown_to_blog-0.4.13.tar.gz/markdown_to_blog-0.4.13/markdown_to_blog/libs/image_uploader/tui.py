﻿from typing import List


class ImageUploadStatus:
    """Track upload status for one image item."""

    def __init__(self, image_path: str):
        self.image_path = image_path
        self.status = UploadStatus.PENDING
        self.current_service = ""
        self.attempt = 0
        self.progress = 0
        self.url = ""
        self.error = ""


class UploadStatus:
    PENDING = "PENDING"
    UPLOADING = "UPLOADING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    ERROR = "ERROR"


# Alias for compatibility if any external code still imports _Status.
Status = UploadStatus


_KO_ALIAS = {
    "": UploadStatus.PENDING,
    "대기": UploadStatus.PENDING,
    "업로드중": UploadStatus.UPLOADING,
    "완료": UploadStatus.SUCCESS,
    "실패": UploadStatus.FAILED,
    "오류": UploadStatus.ERROR,
    UploadStatus.PENDING: UploadStatus.PENDING,
    UploadStatus.UPLOADING: UploadStatus.UPLOADING,
    UploadStatus.SUCCESS: UploadStatus.SUCCESS,
    UploadStatus.FAILED: UploadStatus.FAILED,
    UploadStatus.ERROR: UploadStatus.ERROR,
}


__all__ = [
    "ImageUploadStatus",
    "UploadStatus",
    "Status",
    "ProgressViewer",
]


def _normalize_status(value: str) -> str:
    return _KO_ALIAS.get(value, value or UploadStatus.PENDING)


class ProgressViewer:
    """Simple text progress output for batch uploads."""

    def __init__(
        self, markdown_file: str, image_files: List[str], use_tui: bool = True
    ):
        self.markdown_file = markdown_file
        self.image_statuses = {img: ImageUploadStatus(img) for img in image_files}
        self.total_files = len(image_files)
        self.completed_files = 0

        print(f"\nUpload target: {markdown_file}")
        print(f"Total files: {self.total_files}")
        self._print_progress_bar()

    def start(self):
        """Start progress output."""
        pass

    def update(
        self,
        image_path: str,
        status: str,
        service: str = "",
        attempt: int = 0,
        progress: int = 0,
        url: str = "",
        error: str = "",
    ) -> None:
        """Update and render a single image progress row."""
        if image_path not in self.image_statuses:
            return

        status_obj = self.image_statuses[image_path]
        status_obj.status = _normalize_status(status)
        status_obj.current_service = service
        status_obj.attempt = attempt
        status_obj.progress = progress
        status_obj.url = url
        status_obj.error = error

        self.completed_files = sum(
            1
            for s in self.image_statuses.values()
            if s.status in {UploadStatus.SUCCESS, UploadStatus.FAILED}
        )

        self._print_status(image_path)

    def stop(self):
        """Stop and print summary."""
        print("\nUpload done!")
        print(
            f"Success: {sum(1 for s in self.image_statuses.values() if s.status == UploadStatus.SUCCESS)}"
        )
        print(
            f"Failed: {sum(1 for s in self.image_statuses.values() if s.status == UploadStatus.FAILED)}"
        )

    def _print_progress_bar(self):
        """Print the whole-file progress bar."""
        progress = (self.completed_files / self.total_files) * 100 if self.total_files else 0
        bar_width = 50
        filled = int(bar_width * self.completed_files / self.total_files) if self.total_files else 0
        bar = "=" * filled + "-" * (bar_width - filled)
        print(
            f"\rUploading [{bar}] {progress:.1f}% ({self.completed_files}/{self.total_files})",
            end="",
            flush=True,
        )

    def _print_status(self, image_path: str):
        """Print the current status for a single image."""
        status = self.image_statuses[image_path]

        self._print_progress_bar()

        if status.status == UploadStatus.UPLOADING:
            print(f"\nCurrent image: {image_path}")
            print(f"Service: {status.current_service} (attempt {status.attempt})")
            if status.error:
                print(f"error: {status.error}")
        elif status.status == UploadStatus.SUCCESS:
            print(f"\nDone: {image_path} -> {status.url}")
        elif status.status == UploadStatus.FAILED:
            print(f"\nFailed: {image_path} ({status.error})")
