from typing import Optional, Tuple


AVAILABLE_UPLOAD_SERVICES = ("anhmoe", "beeimg", "fastpic", "imagebin", "pixhost", "sxcu")

# Upload retry/polling defaults.
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_DELAY_SECONDS = 5
PROGRESS_STEP_PERCENT = 10
TOTAL_PROGRESS_PERCENT = 100
UPLOAD_COMMAND_TIMEOUT_SECONDS = 300

# Shared log formatting widths.
LOG_FORMAT = {
    "SERVICE": 15,
    "STATUS": 10,
    "ATTEMPT": 8,
    "PROGRESS": 10,
    "MESSAGE": 50,
}


def format_upload_log_message(
    service: str,
    status: str,
    attempt: Optional[int] = None,
    progress: Optional[Tuple[int, int]] = None,
    message: str = "",
) -> str:
    """Create a compact, aligned log line for uploader output."""
    service_part = f"[{service:<{LOG_FORMAT['SERVICE']}s}]"
    status_part = f"[{status:<{LOG_FORMAT['STATUS']}s}]"
    attempt_part = f"[{f'{attempt}/{DEFAULT_MAX_RETRIES}' if attempt is not None else 'N/A':<{LOG_FORMAT['ATTEMPT']}s}]"

    if progress:
        current, total = progress
        progress_part = f"[{current}/{total}]".ljust(LOG_FORMAT["PROGRESS"] + 2)
    else:
        progress_part = " " * (LOG_FORMAT["PROGRESS"] + 2)

    message_part = message[: LOG_FORMAT["MESSAGE"]] + (
        "..." if len(message) > LOG_FORMAT["MESSAGE"] else ""
    )

    return f"{service_part} {status_part} {attempt_part} {progress_part} {message_part}"
