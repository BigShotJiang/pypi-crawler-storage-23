"""Legacy configuration shim for backward-compatible imports.

This module keeps old symbols so older callers do not break.
Runtime configuration is managed by ``markdown_to_blog.libs.config_manager``.
"""

from .libs.config_manager import (  # noqa: F401
    CONFIG_BASE_DIR,
    CONFIG_FILE,
    CREDENTIAL_STORAGE_PATH,
    CLIENT_SECRET_PATH,
    DEFAULT_MARKDOWN_EXTRAS,
    DEFAULT_CONFIG as _DEFAULT_CONFIG,
    get_config_manager,
)

# Legacy names kept to avoid breaking imports from older entry points.
SECTION_GENERAL = "GENERAL"
SECTION_BLOG = "BLOG"
SECTION_BLOGGER = "BLOGGER"
SECTION_IMAGE = "IMAGE"
SECTION_IMGUR = "IMGUR"
SECTION_CLOUDINARY = "CLOUDINARY"

SECTION_GENERAL_LOWER = "general"
SECTION_BLOG_LOWER = "blog"
SECTION_IMAGE_LOWER = "image"

_LEGACY_SECTION_MAP = {
    SECTION_GENERAL: SECTION_GENERAL_LOWER,
    SECTION_BLOG: SECTION_BLOG_LOWER,
    SECTION_IMAGE: SECTION_IMAGE_LOWER,
    SECTION_BLOGGER: SECTION_BLOG_LOWER,
    SECTION_IMGUR: SECTION_IMAGE_LOWER,
    SECTION_CLOUDINARY: SECTION_IMAGE_LOWER,
}


def _normalize_section(section: str) -> str:
    """Normalize legacy section keys to config manager section names."""
    return _LEGACY_SECTION_MAP.get(section, section.lower())


def get(section: str, key: str, default=None):
    """Backward-compatible getter helper."""
    manager = get_config_manager()
    return manager.get(_normalize_section(section), key, default)


def set(section: str, key: str, value=None):
    """Backward-compatible setter helper."""
    manager = get_config_manager()
    manager.set(_normalize_section(section), key, value)


# Backward-compatible placeholders. Keep structure for imports, but keep values in
# the active manager (lowercase sections).
CONFIG_SCHEMA = {}
REQUIRED_CONFIG = {}
DEFAULT_CONFIG = _DEFAULT_CONFIG

ConfigManager = get_config_manager().__class__
