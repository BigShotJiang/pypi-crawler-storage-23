import time
from typing import TYPE_CHECKING, Union
from PySide6.QtCore import QObject, Signal, QTimer
from PySide6.QtWidgets import QMessageBox

from macro_studio.core.execution.manual_task_wrapper import ManualTaskWrapper
from macro_studio.core.execution.task_worker import TaskWorker
from macro_studio.core.types_and_enums import LogLevel, WorkerState
from macro_studio.core.utils import global_logger
from .task_controller import TaskController
from .threaded_controller import ThreadedController
from macro_studio.core.data import Profile, TaskModel


if TYPE_CHECKING:
    from macro_studio.core.data.profile import TaskRelationship

DEADLOCK_TIME_MS = 200
WORKER_MONITOR_RATE_MS = 2000
PULSE_DEADLOCK_DURATION_S = 5.0

class ManualTaskController(TaskController):
    def __init__(self, manager, var_store, relationship: "TaskRelationship", cid: int):
        task_model = manager.profile.tasks.getTaskById(relationship.task_id)
        self.relationship = relationship
        self._wrapper = ManualTaskWrapper(var_store, task_model)
        super().__init__(manager=manager, task_func=self._wrapper.runTask, task_id=cid, repeat=relationship.repeat,
                         unique_name=task_model.name, is_enabled=relationship.is_enabled)

    @property
    def repeat(self):
        return self.relationship.repeat

    @repeat.setter
    def repeat(self, value):
        if self.relationship.repeat == value: return
        self.manager.profile.updateRelationshipState(self.relationship, "repeat", value)

    def isEnabled(self):
        return self.relationship.is_enabled

    def setEnabled(self, enabled: bool):
        self.manager.profile.updateRelationshipState(self.relationship, "is_enabled", enabled)
        return super().setEnabled(enabled)

    def updateModel(self, task_model: "TaskModel"):
        self._wrapper.updateModel(task_model)

    def resetGeneratorAndGetSortKey(self, *args, **kwargs):
        results = super().resetGeneratorAndGetSortKey(**kwargs)
        self._wrapper.resetState()
        return results

class TaskManager(QObject):
    finished_signal = Signal()
    def __init__(self, engine, profile: "Profile"):
        super().__init__()

        self.engine = engine
        self.profile = profile
        self.controllers: dict[str | int, TaskController] = {}
        self.next_cid = 0
        self._loop_delay = 0.001
        self.worker = self._createAndMonitorWorker()

        self.watchdog_timer = QTimer()

        tasks = profile.tasks
        tasks.taskRemoved.connect(self._onManualTaskRemoved)
        tasks.taskSaved.connect(self._onManualTaskSaved)
        tasks.taskRenamed.connect(self._onManualTaskRenamed)
        profile.relationshipCreated.connect(self._onRelationshipCreated)
        self.watchdog_timer.timeout.connect(self._checkWorkerHealth)

        self.profile.loaded.connect(self._onProfileLoaded)

    @property
    def loop_delay(self):
        return self.loop_delay

    @loop_delay.setter
    def loop_delay(self, delay: float):
        self.loop_delay = delay
        self.worker.loop_delay = delay

    def createController(self, task_func, enabled: bool, repeat: bool, task_args, task_kwargs):
        c_id = self.next_cid
        controller = TaskController(self, task_func, c_id, repeat=repeat, is_enabled=enabled,
                                    task_args=task_args, task_kwargs=task_kwargs)
        self._registerController(controller)
        return controller.context

    def createThreadController(self, fun_in_thread, enabled: bool, repeat: bool, task_args, task_kwargs):
        c_id = self.next_cid
        controller = ThreadedController(self, fun_in_thread, c_id, repeat=repeat, is_enabled=enabled, task_args=task_args,
                                        task_kwargs=task_kwargs)
        self._registerController(controller)
        return controller.context

    def getController(self, name_or_id: str | int):
        controller = self.controllers.get(name_or_id)
        return controller.context if controller else None

    def removeController(self, controller):
        self.controllers.pop(controller.name, None)

    def startWorker(self):
        self.worker.clearPauseState(WorkerState.RUNNING)
        self.worker.reloadControllers(self._getEnabledControllers())
        global_logger.log("Starting Macro...")
        self.worker.start()
        self.watchdog_timer.start(WORKER_MONITOR_RATE_MS)

    def stopWorker(self):
        self.worker.clearPauseState(WorkerState.IDLE)
        self.watchdog_timer.stop()
        self.worker.handleStoppedEnd()
        return self._tryShowKillDialog()

    def pauseWorker(self, interrupt):
        """
        Pauses all task execution.
        Args:
            interrupt: Controls how the pause is handled.

                * ``True``: Interrupts the task to **release keys** and **clean up resources** safely.
                * ``False``: **Freezes** the task in place (keys remain held down).
         Returns:
             ``True`` if paused successfully, ``False`` if could not stop the worker.
        """
        if self.worker.pause(interrupt):
            self.watchdog_timer.stop()
            return self._tryShowKillDialog(True)

        return self.worker.isAlive()

    def resumeWorker(self):
        elapsed = self.worker.resume() if self.worker.isAlive() else None
        if elapsed is not None: self.watchdog_timer.start(WORKER_MONITOR_RATE_MS)
        return elapsed

    def _checkWorkerHealth(self):
        if not self.worker.isRunning() or self.worker.isPaused():
            return

        current_time = time.perf_counter()
        time_since_last_pulse = current_time - self.worker.last_heartbeat

        if time_since_last_pulse > PULSE_DEADLOCK_DURATION_S:
            global_logger.log(f"Engine Auto-Protect: A task has held the worker for {time_since_last_pulse:.2f} seconds without yielding.", level=LogLevel.WARN)
            # Try to pause the worker so the deadlock thing will come up
            if self.pauseWorker(False):
                if self.worker.isAlive(): # Somehow the task pulled through, clear the pause
                    self.worker.clearPauseState()
                else:
                    self.engine.cancelExecution()

    def _createAndMonitorWorker(self):
        worker = TaskWorker(self.engine, self._loop_delay)
        for controller in self.controllers.values():
            controller.setScheduler(worker)
        worker.finished_signal.connect(self.finished_signal.emit)
        return worker

    def _tryShowKillDialog(self, is_pause=False):
        if not self.worker.wait(DEADLOCK_TIME_MS):
            msg_box = QMessageBox(self.engine.ui)
            msg_box.setIcon(QMessageBox.Icon.Warning)
            msg_box.setWindowTitle("Potential Task Deadlock Detected")
            msg_box.setText("The task worker is completely unresponsive.")
            msg_box.setInformativeText(f"A task has not yielded for longer than {DEADLOCK_TIME_MS}ms, halting task execution. Do you want to forcefully terminate the worker, or let it continue running?")

            terminate_btn = msg_box.addButton("Force Terminate", QMessageBox.ButtonRole.DestructiveRole)
            _continue_btn = msg_box.addButton("Let it Continue", QMessageBox.ButtonRole.RejectRole)

            msg_box.exec()

            if msg_box.clickedButton() == terminate_btn:
                global_logger.log("User forcefully terminated the worker.", level=LogLevel.ERROR)
                self.worker.terminate()  # The Nuclear Option
                self.worker.wait()  # Wait for the OS to finish burying it
                del self.worker
                self.worker = self._createAndMonitorWorker()
            else:
                self.worker.clearPauseState()
                global_logger.log("User chose to let the deadlocked task continue. Watchdog disabled for the remainder of this run", level=LogLevel.WARN)
                return False # We walk away and let it keep spinning
        elif not is_pause:
            # The worker shut down naturally and safely within the timeframe!
            self.worker.reloadControllers(None)
        return True

    def _getEnabledControllers(self):
        return [controller for controller in self.controllers.values() if controller.isEnabled()]

    def _onProfileLoaded(self):
        stale_keys = []
        for cid in self.controllers:
            if isinstance(cid, str):
                stale_keys.append(cid)

        for cid in stale_keys:
            self._onManualTaskRemoved(cid)

        for relationship in self.profile.task_relationships.values():
            self._onRelationshipCreated(relationship)

    def _registerController(self, controller: TaskController):
        self.next_cid += 1
        self.controllers[controller.name] = controller

    def _onRelationshipCreated(self, relationship: "TaskRelationship"):
        self._registerController(ManualTaskController(self, self.profile.vars, relationship, self.next_cid))

    def _onManualTaskRemoved(self, task: Union[TaskModel, str]):
        task_name = task.name if isinstance(task, TaskModel) else task
        if task_name in self.controllers:
            controller = self.controllers.pop(task_name)
            controller.stop()
            del controller

    def _onManualTaskSaved(self, task_model: "TaskModel"):
        controller = self.controllers.get(task_model.name)
        if isinstance(controller, ManualTaskController):
            controller.updateModel(task_model)
        elif controller is None:
            # Assume it is not added to this profile
            pass
        else:
            print(f"Warning: '{task_model.name}' is a {type(controller).__name__}, not a ManualTaskController.")

    def _onManualTaskRenamed(self, old_name, task_model: "TaskModel"):
        controller = self.controllers.get(old_name)
        if isinstance(controller, ManualTaskController):
            del self.controllers[controller.name]
            controller.name = task_model.name
            self.controllers[task_model.name] = controller
        elif controller is None:
            # Assume it is not added to this profile
            pass
        else:
            print(f"Warning: '{old_name}' is a {type(controller).__name__}, not a ManualTaskController.")