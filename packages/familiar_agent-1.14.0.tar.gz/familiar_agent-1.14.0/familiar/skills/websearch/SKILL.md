# Web Search Skill

Search the internet, retrieve web pages, and extract content. Enables
grant research, organization lookup, regulatory checks, and answering
any question requiring current information.

## Usage

Use this skill when the user wants to:
- Search the web for any information
- Look up an organization, person, or regulation
- Research grant opportunities
- Read and summarize a web page
- Look up a nonprofit by name or EIN

## Search Backend

Preferred: Self-hosted SearXNG instance (HIPAA: no query data leaves
the network). Fallback: DuckDuckGo HTML lite endpoint which requires
no API key.

Configuration in config.yaml allows switching backends.

## Content Extraction

Uses readability-style algorithm to extract article text from HTML.
Strips ads, navigation, footers. Returns clean text for LLM processing.

## HIPAA Consideration

Search queries may contain PHI. Self-hosted SearXNG keeps queries
on-premises. DuckDuckGo fallback sends queries externally and is
flagged in the compliance audit log.

## Cross-Skill Integration

- **knowledge**: Search results can be saved to knowledge base
- **nonprofit**: search_nonprofit looks up orgs on ProPublica API
- **grants**: search_grants queries grants.gov
