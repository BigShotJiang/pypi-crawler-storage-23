# SMS Skill - Iris, Rainbow Messenger

*Iris was the personal messenger of Hera, traveling on rainbows between the mortal and divine realms. She delivers your urgent messages anywhere.*

Send and receive SMS text messages via Twilio.

## Setup

1. Create a Twilio account at https://www.twilio.com
2. Get a phone number
3. Set environment variables:
   - TWILIO_ACCOUNT_SID
   - TWILIO_AUTH_TOKEN
   - TWILIO_PHONE_NUMBER

## Usage

- "Text Sarah: Running 10 minutes late"
- "Send an SMS to 206-555-1234 saying the meeting is confirmed"
- "Check for new text messages"

## Notes

- Costs per message (Twilio pricing)
- Can receive replies via webhook (advanced setup)
- Good for urgent alerts when Telegram isn't available
