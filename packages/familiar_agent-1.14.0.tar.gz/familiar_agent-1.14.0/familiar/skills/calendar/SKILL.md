# Google Calendar Skill

Manage Google Calendar - view events, create meetings, check availability.

## Setup

Requires Google OAuth credentials:
1. Go to https://console.cloud.google.com
2. Create a project (or use existing)
3. Enable Google Calendar API
4. Create OAuth 2.0 credentials (Desktop app)
5. Download credentials.json to ~/.pi_agent/data/google_credentials.json
6. First run will open browser for authorization

## Usage

- "What's on my calendar today?"
- "Schedule a board meeting for next Tuesday at 2pm"
- "Am I free Thursday afternoon?"
- "Cancel my 3pm meeting"
- "Move the donor lunch to Friday"

## Notes

- Creates events on primary calendar by default
- Can check multiple calendars for conflicts
- Sends invites if attendee emails provided
