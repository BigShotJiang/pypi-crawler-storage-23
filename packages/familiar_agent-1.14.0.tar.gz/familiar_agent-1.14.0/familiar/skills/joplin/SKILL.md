# Joplin Notes

Manage notes and notebooks via Joplin Data API.

## Usage

Use this skill when the user asks about their personal notes stored in Joplin — searching, reading, creating, or editing notes and notebooks. Joplin is the user's note-taking app, separate from the agent's own memory system.

## Examples

- "Search my notes for the meeting agenda"
- "Create a Shopping List note"
- "What notebooks do I have?"
- "Show me my note about project ideas"
- "Update my recipe note with the new ingredient"
- "List all my tags in Joplin"
- "Find notes tagged 'work'"

## Important

- Notes are in Markdown format.
- Use `joplin_search_notes` to find notes before trying to get or update them.
- Note IDs are required for `joplin_get_note` and `joplin_update_note` — always search first.

## Disambiguation

These four systems are distinct — do not confuse them:

- **Joplin** (`joplin_*`): The user's personal notes app. "My notes", "my notebooks".
- **Agent memory** (`remember`/`recall`): The agent's own persistent memory across conversations.
- **Knowledge base** (`search_knowledge`): Ingested documents and training data.
- **Saved snippets** (`search_knowledge_base`): Saved code/text snippets.

Also:
- This is **NOT** for cloud files — use Nextcloud (`nextcloud_files_*`) for WebDAV files.
- This is **NOT** for to-do lists in a task manager — Joplin notes are freeform text.

## Setup

Set `JOPLIN_TOKEN` environment variable. Optionally set `JOPLIN_URL` (defaults to `http://localhost:41184`).

## Tools

- `joplin_list_notebooks` — List all notebooks
- `joplin_search_notes` — Search notes by query
- `joplin_get_note` — Get a note's content
- `joplin_create_note` — Create a new note
- `joplin_update_note` — Update an existing note
- `joplin_list_tags` — List all tags
