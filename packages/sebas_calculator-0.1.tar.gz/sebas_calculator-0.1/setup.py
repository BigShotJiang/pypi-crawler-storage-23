from setuptools import setup


setup(
    name="sebas-calculator",
    version="0.1",
    description="A simple calculator that performs basic arithmetic operations.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=["sebas_calculator"],
    install_requires=[
        # No external dependencies
    ],
    python_requires=">=3.6",
    author="Sebastian Torregroza",
    url="https://github.com/Sebas200702/sebas-calculator",
    author_email="sebastorregroza6@gmail.com",
)
