# Sebas-Calculator


Calculadora simple por consola que realiza operaciones aritméticas básicas, desarrollada en Python.

## Operaciones disponibles

| Comando          | Descripción                   |
| ---------------- | ----------------------------- |
| `suma`           | Suma de dos números           |
| `resta`          | Resta de dos números          |
| `multiplicacion` | Multiplicación de dos números |
| `division`       | División de dos números       |
| `salir`          | Terminar el programa          |

## Requisitos

- Python >= 3.6

## Instalación

### Desde PyPI

```bash
pip install sebas-calculator
```

### Desde el código fuente

```bash
git clone https://github.com/sebas-calculator/sebas-calculator.git
cd sebas-calculator
pip install .
```

## Uso

### Como programa de consola

```bash
python -m sebas_calculator
```

El programa te pedirá:

1. La operación a realizar (`suma`, `resta`, `multiplicacion`, `division`).
2. Dos números enteros.
3. Mostrará el resultado en pantalla.

Escribe `salir` para terminar el programa.

### Como librería en tu código

```python
from sebas_calculator.operations import suma, resta, multiplicacion, division

resultado = suma(5, 3)          # 8
resultado = resta(10, 4)        # 6
resultado = multiplicacion(3, 7) # 21
resultado = division(15, 3)     # 5.0
```

También puedes usar la función `operate` para elegir la operación dinámicamente:

```python
from sebas_calculator.operations import operate

resultado = operate("suma", 5, 3)  # 8
```

## Ejemplo

```
Ingrese la operación a realizar (suma, resta, multiplicacion, division) o 'salir' para terminar: suma
Ingrese el primer número: 5
Ingrese el segundo número: 3
El resultado de la suma es: 8
```

## Estructura del proyecto

```
setup.py
sebas-calculator/
    main.py          # Punto de entrada del programa
    operations.py    # Funciones de las operaciones aritméticas
```

## Contribuir

1. Haz un fork del repositorio.
2. Crea una rama para tu feature (`git checkout -b feature/nueva-operacion`).
3. Haz commit de tus cambios (`git commit -m 'Añadir nueva operación'`).
4. Haz push a la rama (`git push origin feature/nueva-operacion`).
5. Abre un Pull Request.

## Licencia

Este proyecto está bajo la licencia MIT. Consulta el archivo [LICENSE](LICENSE) para más detalles.

## Autor

Sebastian Torregroza
