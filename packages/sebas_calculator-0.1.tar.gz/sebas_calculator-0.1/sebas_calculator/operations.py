def suma(number1: int, number2: int):
    """This function performs the addition of two numbers.

    Args:
        number1 (int): The first number to be added.
        number2 (int): The second number to be added.

    Returns:
        _int_: The sum of number1 and number2.
    """
    return number1 + number2


def resta(number1: int, number2: int):
    """This function performs the subtraction of two numbers.

    Args:
        number1 (int): The first number to be subtracted.
        number2 (int):  The second number to be subtracted.

    Returns:
        _int_: The result of the subtraction of number1 and number2.
    """
    return number1 - number2


def multiplicacion(number1: int, number2: int):
    """This function performs the multiplication of two numbers.

    Args:
        number1 (int): The first number to be multiplied.
        number2 (int): The second number to be multiplied.

    Returns:
        _int_: The result of the multiplication of number1 and number2.
    """
    return number1 * number2


def division(number1: int, number2: int):
    """This function performs the division of two numbers.

    Args:
        number1 (int): The first number to be divided.
        number2 (int): The second number to be divided.

    Returns:
        _float_: The result of the division of number1 and number2.
    """
    if number2 == 0:
        return print("Error no es posible dividir entre 0")
    return number1 / number2


operations = {
    "suma": suma,
    "resta": resta,
    "multiplicacion": multiplicacion,
    "division": division,
}


def operate(operation: str, number1: int, number2: int):
    """This function performs the operation on two numbers.

    Args:
        operation (str): The operation to be performed.
        number1 (int): The first number.
        number2 (int): The second number.

    Returns:
        _int_ or _float_: The result of the operation.
    """
    if operation in operations:
        return operations[operation](number1, number2)
    else:
        return print("Operación no válida")


def create_new_operation(operation_name: str, operation_function):
    """This function creates a new operation and adds it to the operations dictionary.

    Args:
        operation_name (str): The name of the new operation.
        operation_function: The function that performs the new operation.
    """
    operations[operation_name] = operation_function
