from operations import operate


def main():
    try:
        """This function is the main function of the program. It prompts the user for the operation and the numbers, and then calls the operate function to perform the operation."""
        is_active = True
        while is_active:
            operation = input(
                "Ingrese la operación a realizar (suma, resta, multiplicacion, division) o 'salir' para terminar: "
            )
            if operation == "salir":
                is_active = False
            else:
                number1 = int(input("Ingrese el primer número: "))
                number2 = int(input("Ingrese el segundo número: "))
        result = operate(operation, number1, number2)
        if result is not None:
            print(f"El resultado de la {operation} es: {result}")
    except ValueError:
        print("Error: Por favor ingrese un número válido.")
    except Exception as e:
        print(f"Error: {e}")
