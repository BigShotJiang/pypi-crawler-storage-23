"""Sebas-Calculator: A simple calculator that performs basic arithmetic operations."""
