### 准备工作
- python 3.10.2
- zlthost.exe
- jsservice(NodeJs服务)
- 根目录下创建main.py(不提交避免频繁冲突)
### 安装依赖
```
numpy == 1.24.2 # 注意:必须指定该版本否则导致pybind11数据返回异常
```
### 关于TA-Lib安装失败的解决办法
使用TA_Lib-0.4.24-cp310-cp310-win_amd64.whl文件直接安装(共享盘)
```
pip install TA_Lib-0.4.24-cp310-cp310-win_amd64.whl
```
### 程序运行
F5运行即可(确保.vscode文件夹下有launch.json文件)

### 回测 tradesetting.json
```
{
  "install_path": "F:\\ZLTClient-Release",
  "strategy_id": "ST-50499F40-10D2-44BF-88D8-347CAF5FCBC8",
  "strategy_name": "",
  "backtest_id": "BT-20250310-2A145DB8-F63D-42BC-9AA5-53CEA798EF93",
  "userid": "F137B9EF-96CD-43AF-A1A3-D3B0C696317C",
  "start": "2025-01-01",
  "end": "2025-02-01",
  "freq": "day",
  "type": "simple_backtest",
  "initial_capital": 1000000,
  "file": "main",
  "env":"local",
  "exec_type": 1,
  "base_tpl_obj": {
    "name": "defaultTpl",
    "zhCnName": "系统默认参数模版",
    "benchmark": "sh000300",
    "match_with_order_book": false,
    "matching_mode": "close",
    "avoid_future": true,
    "open_cache": true,
    "jv_kuan_open_avg_cost_switch": "1",
    "adjust_aqty_by_avail": "3",
    "take_fee_type": "1",
    "slippage": "0.00246",
    "max_trade_ratio": "1.0"
  },
  "ratio_tpl_obj": {
    "name": "defaultTpl",
    "zhCnName": "系统默认费率模版",
    "stock": {
      "open_commission": "3",
      "close_commission": "3",
      "min_commission": "1",
      "stamp_duty_buy": "1",
      "stamp_duty_sell": "1"
    },
    "future": {
      "min_commission": "5",
      "margin_ratio": "0",
      "open_fixed_commission": "3",
      "close_fixed_commission": "3",
      "close_fixed_today_commission": "3"
    },
    "fund": {
      "open_commission": "3",
      "close_commission": "3",
      "min_commission": "3"
    }
  }
}
```

### 仿真 tradesetting.json
```
{
  "pipName": "",
  "install_path": "F://ZLTClient-Release",
  "strategy_id": "ST-50499F40-10D2-44BF-88D8-347CAF5FCBC8",
  "strategy_name": "MS-仿真",
  "backtest_id": "SIM-ST-C358A951-D544-471A-B145-AFBCA73D2F30",
  "userid": "F137B9EF-96CD-43AF-A1A3-D3B0C696317C",
  "start": "2025-04-22",
  "end": "2025-12-30",
  "mode": 3,
  "freq": "min",
  "type": "simulation",
  "file": "main",
  "exec_type": 1,
  "zlt_zh_group":"hyPM/NX+79Uv6Am2BKXcl1mkVSTWk9MVBcS4C0PNmcjTJjCjJMqP0J6+JSatEubeZUPdbcmfihoO/LHdqBvS0iuZUjOxHENzWkaryuFtQ9wZgKL4VUeJcwREmZ9xlYUelnMwaTs9zaCwIpfAUw1fio8eXc+huhWamkXv0ix5CEP91nUMz//Dx5kEJoT8XnvEAYgH8UG6u8e8r0XMF2kPEqd/h3sYQfYDg1fbBELRK6FNQyCBNFMCCTw4oy8tpNeY+q6pqV/8WyYBJmU0TgkZagJfTPYKh54ByFj8453QN/tuhG7fT0CwkMIzo6HSpUxgwJZNcyWCVxR9rmtuYWckm4uvnDhyQ/BYVFzaHJd7+1QMCXXE9ZFVJcpchAEWDgPKIVGQarnsksOJSV1BxCYUDh9XrQEZIGKyaVvgliUP1TS3FjpscYF9zcBdJRkmoQ8WRY5lrEdAGn1X72U3OEphgYmkYgobxZVW95WSpdYU3P8nfv0F1h0FMoZGJlDfcdAZsTXRg5vw9oEQ5EifdhlIBesUsJ2z8k8YrWU8jt36rBwkmK8O/qSrXWts9d41E+/C"
}
```

---

## 包构建与安装

### 前置要求
- Python 3.10 或更高版本
- build 和 twine (用于发布)

### 构建包

```bash
# 安装构建工具
pip install build twine

# 构建分发包
python -m build
```

构建完成后，在 `dist/` 目录下会生成：
- `zltquant-0.1.0.tar.gz` - 源代码分发包
- `zltquant-0.1.0-py3-none-any.whl` - wheel 包

### 本地安装

```bash
# 开发模式安装（可编辑）
pip install -e .

# 或从构建的 wheel 文件安装
pip install dist/zltquant-0.1.0-py3-none-any.whl
```

### 发布到 PyPI

```bash
# 上传到 PyPI (需要配置 pypi token)
python -m twine upload dist/*

# 或上传到 TestPyPI 测试
python -m twine upload --repository testpypi dist/*
```

### 注意事项
- `zltsdk` 是外部依赖，需要单独安装
- 包仅包含 `zltquant/` 目录，不包含其他子模块如 `zltlib`、`zltFactor` 等
```