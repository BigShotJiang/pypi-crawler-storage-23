from setuptools import setup, find_packages

setup(
    name="zltquant",
    use_scm_version=False,
    version="0.1.0",
    packages=find_packages(where="."),
    package_dir={"": "."},
    include_package_data=True,
)
