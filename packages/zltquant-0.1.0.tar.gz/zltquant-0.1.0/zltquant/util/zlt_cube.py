from .calc_sdk_api import get_dpzs_code, get_dpzs_name
from .zlt_util import param_to_dt
from .zlt_panel import Panel
from .zlt_section import Section
from .zlt_security import Security
from . import zlt_object as zltObj
import zltsdk.zltcalc as zltcalc


class Cube():
    '''Cube对象
    - security: 股票代码
    - start_date: 开始日期
    - end_date: 结束日期
    - count: 数量
    - freq: 频率
    - fq: 复权方式
    - fill_suspend: 是否填充停牌数据
    - align: 时间对齐方式(暂不支持)
    - include_now: 是否包含当前数据
    '''

    def __init__(self, security, start_date=None, end_date=None, count=0, freq=None,  fq='pre', fill_suspend=False, align=None, include_now=True):
        self.is_view = False
        if count != 0 and start_date is not None:
            raise ValueError("count 和 start_date 不能同时设置")
        if isinstance(security, str):
            security = [security]
        if isinstance(security, list):
            security = [s.lower() for s in security]
        if freq == None:  # 频率跟随策略频率
            strategy_freq = zltObj._context.backtest_param['frequency']
            if strategy_freq == 'min':
                freq = '1m'
            elif strategy_freq == 'day':
                freq = '1d'
            else:
                freq = strategy_freq
        # 检查开始时间
        if start_date is None and count == 0:
            count = 30  # 默认获取200根Bar数据
            start_date = ""
        elif count != 0:
            start_date = ""
            count = count
        else:
            start_date = param_to_dt(start_date).strftime("%Y-%m-%d %H:%M:%S")

        if end_date is None:
            end_date = zltObj._context.current_dt.strftime("%Y-%m-%d %H:%M:%S")
        else:
            self.is_view = True
            end_date = param_to_dt(end_date).strftime("%Y-%m-%d %H:%M:%S")

        self.start_date = start_date
        self.end_date = end_date
        self.count = count
        self.freq = freq
        self.fq = fq
        self.fill_suspend = fill_suspend
        self.align = align
        self.include_now = include_now
        self.obj = zltcalc.MoreDataCube(security, start_date, end_date,
                                        count, freq,  fq, fill_suspend, align, self.is_view)

    def append(self, security=None):
        if isinstance(security, str):
            security = [security]
        self.obj.Append(security)
        pass

    def delete(self, security=None):
        if isinstance(security, str):
            security = [security]
        self.obj.Delete(security)
        pass

    def update(self, security=None):
        if isinstance(security, str):
            security = [security]
        self.obj.Update(security)
        pass

    def panel(self, col: str):
        return Panel(self.obj.GetPanel(col))

    def load_obj(self, obj):
        self.obj = obj

    @property
    def close(self):
        '''收盘价
        '''
        return self.panel("close")

    @property
    def open(self):
        '''开盘价
        '''
        return self.panel("open")

    @property
    def high(self):
        '''最高价
        '''
        return self.panel("high")

    @property
    def low(self):
        '''最低价
        '''
        return self.panel("low")

    @property
    def vol(self):
        '''成交量
        '''
        return self.panel("volume")

    @property
    def amount(self):
        '''成交额
        '''
        return self.panel("amount")

    @property
    def ipo_date(self):
        '''上市日期 
        '''
        return self.panel("ipo_date")

    @property
    def listing(self):
        '''是否上市
        '''
        return self.panel("listing")

    @property
    def suspend(self):
        '''是否停牌
        '''
        return self.panel("suspend")

    @property
    def st(self):
        '''是否ST
        '''
        return self.panel("st")

    @property
    def predelist(self):
        '''是否预退市
        '''
        return self.panel("predelist")

    @property
    def delisted(self):
        '''是否退市
        '''
        return self.panel("delisted")

    @property
    def index_c(self):
        '''所属大盘收盘价
        '''
        return self.panel("index_c")

    @property
    def index_h(self):
        '''所属大盘最高价
        '''
        return self.panel("index_h")

    @property
    def index_l(self):
        '''所属大盘最低价
        '''
        return self.panel("index_l")

    @property
    def index_o(self):
        '''所属大盘开盘价
        '''
        return self.panel("index_o")

    @property
    def index_v(self):
        '''所属大盘成交量
        '''
        return self.panel("index_v")

    @property
    def index_a(self):
        '''所属大盘成交额
        '''
        return self.panel("index_a")

    @property
    def avg_price(self):
        '''平均价
        '''
        return self.get_panel_data("avg_price", self.start_date, self.end_date, self.count, self.fq, self.fill_suspend)

    @property
    def ups_and_downs(self):
        '''涨跌幅
        '''
        return self.get_panel_data("ups_and_downs", self.start_date, self.end_date, self.count, self.fq, self.fill_suspend)

    @property
    def amplitude(self):
        '''振幅
        '''
        return self.get_panel_data("amplitude", self.start_date, self.end_date, self.count, self.fq, self.fill_suspend)

    @property
    def growth_price(self):
        '''涨幅
        '''
        return self.get_panel_data("growth_price", self.start_date, self.end_date, self.count, self.fq, self.fill_suspend)

    @property
    def vol_ratio(self):
        '''量比
        '''
        return self.get_panel_data1("get_vol_ratio", self.start_date, self.end_date, self.count, self.fq, self.fill_suspend,n=5)

    @property
    def ztprice(self):
        '''涨停价'''
        return self.get_panel_data("zt_price", self.start_date, self.end_date, self.count, self.fq, self.fill_suspend)

    @property
    def dtprice(self):
        '''跌停价'''
        return self.get_panel_data("dt_price", self.start_date, self.end_date, self.count, self.fq, self.fill_suspend)

    @property
    def turnover_rate(self):
        '''换手率
        '''
        return self.get_panel_data("shares", self.start_date, self.end_date, self.count, self.fq, self.fill_suspend)

    @property
    def turnover_rate_z(self):
        '''换手率
        '''
        return self.get_panel_data("free_shares", self.start_date, self.end_date, self.count, self.fq, self.fill_suspend)

    @property
    def is_down(self):
        return self.get_panel_data("is_down", self.start_date, self.end_date, self.count, self.fq, self.fill_suspend)

    @property
    def is_up(self):
        return self.get_panel_data("is_up", self.start_date, self.end_date, self.count, self.fq, self.fill_suspend)

    @property
    def is_equal(self):
        return self.get_panel_data("is_equal", self.start_date, self.end_date, self.count, self.fq, self.fill_suspend)

    @property
    def is_zt(self):
        return Panel(self.obj.GetPanel("is_zt", self.start_date, self.end_date, self.count, self.fill_suspend, False))

    @property
    def is_dt(self):
        return Panel(self.obj.GetPanel("is_dt", self.start_date, self.end_date, self.count, self.fill_suspend, False))

    def check_param(self, start_date, end_date, count, fq):
        if count != 0 and start_date is not None:
            raise ValueError("count 和 start_date 不能同时设置")
        if start_date is None:
            if count == 0 and self.count == 0:
                start_date = self.start_date
            else:
                if count == 0:
                    if self.count:
                        count = self.count
                        start_date = ""
                    else:
                        start_date = self.start_date
                else:
                    start_date = ""
        else:
            start_date = param_to_dt(start_date).strftime("%Y-%m-%d %H:%M:%S")
        if end_date is None:
            if not self.is_view:
                end_date = zltObj._context.current_dt.strftime("%Y-%m-%d %H:%M:%S")
            else:
                end_date = self.end_date
        else:
            end_date = param_to_dt(end_date).strftime("%Y-%m-%d %H:%M:%S")
        if fq is None:
            fq = self.fq
        return start_date, end_date, count, fq

    def get_panel_data(self, col, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        start_date, end_date, count, fq = self.check_param(
            start_date, end_date, count, fq)
        if fill_suspend is None:
            fill_suspend = self.fill_suspend
        return Panel(self.obj.GetPanel(col, start_date, end_date, count, fq, fill_suspend))

    def get_panel_data1(self, col, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, n=1):
        start_date, end_date, count, fq = self.check_param(
            start_date, end_date, count, fq)
        if fill_suspend is None:
            fill_suspend = self.fill_suspend
        return Panel(self.obj.GetPanel(col, start_date, end_date, count, fq, fill_suspend, n))

    def get_open(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("open", start_date, end_date, count, fq, fill_suspend)

    def get_close(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("close", start_date, end_date, count, fq, fill_suspend)

    def get_high(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("high", start_date, end_date, count, fq, fill_suspend)

    def get_low(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("low", start_date, end_date, count, fq, fill_suspend)

    def get_vol(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("volume", start_date, end_date, count, fq, fill_suspend)

    def get_amount(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("amount", start_date, end_date, count, fq, fill_suspend)

    def get_avg_price(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期        
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("avg_price", start_date, end_date, count, fq, fill_suspend)

    def get_ups_and_downs(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期                        
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("ups_and_downs", start_date, end_date, count, fq, fill_suspend)

    def get_amplitude(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期                        
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("amplitude", start_date, end_date, count, fq, fill_suspend)

    def get_growth_price(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期                        
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("growth_price", start_date, end_date, count, fq, fill_suspend)

    def get_is_up(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''收阳
        '''
        return self.get_panel_data("is_up", start_date, end_date, count, fq, fill_suspend)

    def get_is_down(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''收跌
        '''
        return self.get_panel_data("is_down", start_date, end_date, count, fq, fill_suspend)

    def get_is_equal(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''收平
        '''
        return self.get_panel_data("is_equal", start_date, end_date, count, fq, fill_suspend)

    def get_ztprice(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("zt_price", start_date, end_date, count, fq, fill_suspend)

    def get_dtprice(self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("dt_price", start_date, end_date, count, fq, fill_suspend)

    def get_is_zt(self, start_date=None, end_date=None, count=0, exit=False, fill_suspend=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        start_date, end_date, count, fq = self.check_param(
            start_date, end_date, count, "none")
        return Panel(self.obj.GetPanel("is_zt", start_date, end_date, count, fill_suspend, exit))

    def get_is_dt(self, start_date=None, end_date=None, count=0, exit=False, fill_suspend=False, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        '''
        start_date, end_date, count, fq = self.check_param(
            start_date, end_date, count, "none")
        return Panel(self.obj.GetPanel("is_dt", start_date, end_date, count, fill_suspend, exit))

    def get_turnover_rate(self, start_date=None, end_date=None, count=0, fill_suspend=False, fq=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - freq: 频率
        - shares_type: 股票类型
        - fill_suspend: 是否填充停牌数据
        - fq: 复权方式
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("shares", start_date, end_date, count, fq, fill_suspend)

    def get_turnover_rate_z(self, start_date=None, end_date=None, count=0, fill_suspend=False, fq=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - freq: 频率
        - shares_type: 股票类型
        - fill_suspend: 是否填充停牌数据
        - fq: 复权方式
        - df: 是否返回dataframe
        '''
        return self.get_panel_data("free_shares", start_date, end_date, count, fq, fill_suspend)

    def get_index_c(self, start_date=None, end_date=None, count=0, fill_suspend=False, fq=None, df=False):
        return self.panel("index_c")

    def get_index_h(self, start_date=None, end_date=None, count=0, fill_suspend=False, fq=None, df=False):
        return self.panel("index_h")

    def get_index_l(self, start_date=None, end_date=None, count=0, fill_suspend=False, fq=None, df=False):
        return self.panel("index_l")

    def get_index_o(self, start_date=None, end_date=None, count=0, fill_suspend=False, fq=None, df=False):
        return self.panel("index_o")

    def get_index_v(self, start_date=None, end_date=None, count=0, fill_suspend=False, fq=None, df=False):
        return self.panel("index_v")

    def get_index_a(self, start_date=None, end_date=None, count=0, fill_suspend=False, fq=None, df=False):
        return self.panel("index_a")

    def get_fin_data(self, start_date=None, end_date=None, count=0, filed=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - filed: 财务指标
        - df: 是否返回dataframe
        '''
        start_date, end_date, count, fq = self.check_param(
            start_date, end_date, count, "none")
        return Panel(self.obj.GetCwPanel(filed, start_date, end_date, count))

    def get_vol_ratio(self, start_date=None, end_date=None, count=0, fill_suspend=False, fq=None, df=False, n=5):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - freq: 频率
        - shares_type: 股票类型
        - fill_suspend: 是否填充停牌数据
        - fq: 复权方式
        - df: 是否返回dataframe
        '''
        return self.get_panel_data1("get_vol_ratio", start_date, end_date, count, fq, fill_suspend, n=n)

    def get_growth_price_nday(self, n, start_date=None, end_date=None, count=0, fill_suspend=False, fq=None, df=False):
        '''
        - n: 周期
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - freq: 频率
        - shares_type: 股票类型
        - fill_suspend: 是否填充停牌数据
        - fq: 复权方式
        - df: 是否返回dataframe
        '''
        return self.get_panel_data1("get_growth_price_nday", start_date, end_date, count, fq, fill_suspend, n=n)

    def get_average_vol_nday(self, n, start_date=None, end_date=None, count=0, fill_suspend=False, fq=None, df=False):
        '''
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量        
        - fill_suspend: 是否填充停牌数据
        - fq: 复权方式
        - df: 是否返回dataframe
        '''
        return self.get_panel_data1("get_average_vol_nday", start_date, end_date, count, fq, fill_suspend, n=n)

    def Security(self, security: str):
        security = security.lower()
        ptr = self.obj.GetSecurity(security)
        begin = ptr.py_begin_str if ptr.py_begin_str != "" else None
        sec = Security(security, begin, ptr.py_end_str,
                       ptr.py_freq_str, ptr.py_count, ptr.py_fq_str)
        sec.obj = ptr
        return sec

    def Section(self, time=None, cols=None):
        if time is None:
            time = -1
        if not isinstance(time, int):
            time = param_to_dt(time).strftime("%Y-%m-%d %H:%M:%S")
        return Section(self.obj.GetSection(time))

    def sub(self, security):
        ptr = self.obj.Sub(security)
        cb = Cube(security)
        cb.load_obj(ptr)
        return cb

    def Exit(self):
        self.obj.Exit()

    def get_dpzs_code(self):
        return get_dpzs_code(self.obj.GetStocks())

    def get_dpzs_name(self):
        return get_dpzs_name(self.obj.GetStocks())

    # =====财务数据=====
    @property
    def rpt_update_time(self):
        return Panel(self.obj.GetCwPanel("rpt_update_time", self.start_date, self.end_date, self.count))

    @property
    def rpt_period(self):
        return Panel(self.obj.GetCwPanel("rpt_period", self.start_date, self.end_date, self.count))

    @property
    def net_assets(self):
        return Panel(self.obj.GetCwPanel("net_assets", self.start_date, self.end_date, self.count))

    @property
    def total_net_cf(self):
        return Panel(self.obj.GetCwPanel("total_net_cf", self.start_date, self.end_date, self.count))

    @property
    def div_ttm(self):
        return Panel(self.obj.GetCwPanel("div_ttm", self.start_date, self.end_date, self.count))

    @property
    def basic_eps(self):
        return Panel(self.obj.GetCwPanel("basic_eps", self.start_date, self.end_date, self.count))

    @property
    def eps_excl_nonrec(self):
        return Panel(self.obj.GetCwPanel("eps_excl_nonrec", self.start_date, self.end_date, self.count))

    @property
    def undist_profit_ps(self):
        return Panel(self.obj.GetCwPanel("undist_profit_ps", self.start_date, self.end_date, self.count))

    @property
    def nav_ps(self):
        return Panel(self.obj.GetCwPanel("nav_ps", self.start_date, self.end_date, self.count))

    @property
    def roe(self):
        return Panel(self.obj.GetCwPanel("roe", self.start_date, self.end_date, self.count))

    @property
    def op_cf_ps(self):
        return Panel(self.obj.GetCwPanel("op_cf_ps", self.start_date, self.end_date, self.count))

    @property
    def cash(self):
        return Panel(self.obj.GetCwPanel("cash", self.start_date, self.end_date, self.count))

    @property
    def accounts_recv(self):
        return Panel(self.obj.GetCwPanel("accounts_recv", self.start_date, self.end_date, self.count))

    @property
    def prepayments(self):
        return Panel(self.obj.GetCwPanel("prepayments", self.start_date, self.end_date, self.count))

    @property
    def inventory(self):
        return Panel(self.obj.GetCwPanel("inventory", self.start_date, self.end_date, self.count))

    @property
    def curr_assets(self):
        return Panel(self.obj.GetCwPanel("curr_assets", self.start_date, self.end_date, self.count))

    @property
    def long_recv(self):
        return Panel(self.obj.GetCwPanel("long_recv", self.start_date, self.end_date, self.count))

    @property
    def fixed_assets(self):
        return Panel(self.obj.GetCwPanel("fixed_assets", self.start_date, self.end_date, self.count))

    @property
    def goodwill(self):
        return Panel(self.obj.GetCwPanel("goodwill", self.start_date, self.end_date, self.count))

    @property
    def total_noncurr_assets(self):
        return Panel(self.obj.GetCwPanel("total_noncurr_assets", self.start_date, self.end_date, self.count))

    @property
    def total_assets(self):
        return Panel(self.obj.GetCwPanel("total_assets", self.start_date, self.end_date, self.count))

    @property
    def short_loans(self):
        return Panel(self.obj.GetCwPanel("short_loans", self.start_date, self.end_date, self.count))

    @property
    def accounts_pay(self):
        return Panel(self.obj.GetCwPanel("accounts_pay", self.start_date, self.end_date, self.count))

    @property
    def adv_from_cust(self):
        return Panel(self.obj.GetCwPanel("adv_from_cust", self.start_date, self.end_date, self.count))

    @property
    def curr_liab(self):
        return Panel(self.obj.GetCwPanel("curr_liab", self.start_date, self.end_date, self.count))

    @property
    def total_liab(self):
        return Panel(self.obj.GetCwPanel("total_liab", self.start_date, self.end_date, self.count))

    @property
    def paid_in_cap(self):
        return Panel(self.obj.GetCwPanel("paid_in_cap", self.start_date, self.end_date, self.count))

    @property
    def undist_profit(self):
        return Panel(self.obj.GetCwPanel("undist_profit", self.start_date, self.end_date, self.count))

    @property
    def minor_equity(self):
        return Panel(self.obj.GetCwPanel("minor_equity", self.start_date, self.end_date, self.count))

    @property
    def total_equity(self):
        return Panel(self.obj.GetCwPanel("total_equity", self.start_date, self.end_date, self.count))

    @property
    def parent_eq_bs(self):
        return Panel(self.obj.GetCwPanel("parent_eq_bs", self.start_date, self.end_date, self.count))

    @property
    def contract_liab(self):
        return Panel(self.obj.GetCwPanel("contract_liab", self.start_date, self.end_date, self.count))

    @property
    def op_rev(self):
        return Panel(self.obj.GetCwPanel("op_rev", self.start_date, self.end_date, self.count))

    @property
    def op_cost(self):
        return Panel(self.obj.GetCwPanel("op_cost", self.start_date, self.end_date, self.count))

    @property
    def op_profit(self):
        return Panel(self.obj.GetCwPanel("op_profit", self.start_date, self.end_date, self.count))

    @property
    def total_profit(self):
        return Panel(self.obj.GetCwPanel("total_profit", self.start_date, self.end_date, self.count))

    @property
    def profit_aft_tax(self):
        return Panel(self.obj.GetCwPanel("profit_aft_tax", self.start_date, self.end_date, self.count))

    @property
    def net_profit(self):
        return Panel(self.obj.GetCwPanel("net_profit", self.start_date, self.end_date, self.count))

    @property
    def rnd_exp(self):
        return Panel(self.obj.GetCwPanel("rnd_exp", self.start_date, self.end_date, self.count))

    @property
    def net_op_cf(self):
        return Panel(self.obj.GetCwPanel("net_op_cf", self.start_date, self.end_date, self.count))

    @property
    def net_inv_cf(self):
        return Panel(self.obj.GetCwPanel("net_inv_cf", self.start_date, self.end_date, self.count))

    @property
    def current_ratio(self):
        return Panel(self.obj.GetCwPanel("current_ratio", self.start_date, self.end_date, self.count))

    @property
    def quick_ratio(self):
        return Panel(self.obj.GetCwPanel("quick_ratio", self.start_date, self.end_date, self.count))

    @property
    def cash_ratio(self):
        return Panel(self.obj.GetCwPanel("cash_ratio", self.start_date, self.end_date, self.count))

    @property
    def ar_turnover_ratio(self):
        return Panel(self.obj.GetCwPanel("ar_turnover_ratio", self.start_date, self.end_date, self.count))

    @property
    def inv_turnover_ratio(self):
        return Panel(self.obj.GetCwPanel("inv_turnover_ratio", self.start_date, self.end_date, self.count))

    @property
    def wc_turnover_ratio(self):
        return Panel(self.obj.GetCwPanel("wc_turnover_ratio", self.start_date, self.end_date, self.count))

    @property
    def total_asset_turnover(self):
        return Panel(self.obj.GetCwPanel("total_asset_turnover", self.start_date, self.end_date, self.count))

    @property
    def fixed_asset_turnover(self):
        return Panel(self.obj.GetCwPanel("fixed_asset_turnover", self.start_date, self.end_date, self.count))

    @property
    def op_profit_margin(self):
        return Panel(self.obj.GetCwPanel("op_profit_margin", self.start_date, self.end_date, self.count))

    @property
    def gross_profit_margin(self):
        return Panel(self.obj.GetCwPanel("gross_profit_margin", self.start_date, self.end_date, self.count))

    @property
    def net_profit_excl(self):
        return Panel(self.obj.GetCwPanel("net_profit_excl", self.start_date, self.end_date, self.count))

    @property
    def ebit(self):
        return Panel(self.obj.GetCwPanel("ebit", self.start_date, self.end_date, self.count))

    @property
    def ebitda(self):
        return Panel(self.obj.GetCwPanel("ebitda", self.start_date, self.end_date, self.count))

    @property
    def net_op_cf_to_op_rev(self):
        return Panel(self.obj.GetCwPanel("net_op_cf_to_op_rev", self.start_date, self.end_date, self.count))

    @property
    def net_cf_ps(self):
        return Panel(self.obj.GetCwPanel("net_cf_ps", self.start_date, self.end_date, self.count))

    @property
    def net_op_cf_to_net_profit(self):
        return Panel(self.obj.GetCwPanel("net_op_cf_to_net_profit", self.start_date, self.end_date, self.count))

    @property
    def total_shares(self):
        return Panel(self.obj.GetCwPanel("total_shares", self.start_date, self.end_date, self.count))

    @property
    def shareholders_num(self):
        return Panel(self.obj.GetCwPanel("shareholders_num", self.start_date, self.end_date, self.count))

    @property
    def shares_top10_circ_sh(self):
        return Panel(self.obj.GetCwPanel("shares_top10_circ_sh", self.start_date, self.end_date, self.count))

    @property
    def shares_top10_sh(self):
        return Panel(self.obj.GetCwPanel("shares_top10_sh", self.start_date, self.end_date, self.count))

    @property
    def free_shares(self):
        return Panel(self.obj.GetCwPanel("free_shares", self.start_date, self.end_date, self.count))

    @property
    def total_inst_shares(self):
        return Panel(self.obj.GetCwPanel("total_inst_shares", self.start_date, self.end_date, self.count))

    @property
    def qfii_shares(self):
        return Panel(self.obj.GetCwPanel("qfii_shares", self.start_date, self.end_date, self.count))

    @property
    def brokerage_shares(self):
        return Panel(self.obj.GetCwPanel("brokerage_shares", self.start_date, self.end_date, self.count))

    @property
    def fund_shares(self):
        return Panel(self.obj.GetCwPanel("fund_shares", self.start_date, self.end_date, self.count))

    @property
    def social_security_shares(self):
        return Panel(self.obj.GetCwPanel("social_security_shares", self.start_date, self.end_date, self.count))

    @property
    def national_team_shares(self):
        return Panel(self.obj.GetCwPanel("national_team_shares", self.start_date, self.end_date, self.count))

    @property
    def northbound_funds_shares(self):
        return Panel(self.obj.GetCwPanel("northbound_funds_shares", self.start_date, self.end_date, self.count))

    @property
    def employees_num(self):
        return Panel(self.obj.GetCwPanel("employees_num", self.start_date, self.end_date, self.count))
