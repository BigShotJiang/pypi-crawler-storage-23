import zltsdk.zltcalc as zltcalc
from zltquant.util.zlt_zvector import *
import numpy as np
import os

def load(path):
    file_extension = os.path.splitext(path)[1].lower()
    # 根据文件扩展名选择合适的读取方法
    if file_extension == '.csv':
        return zmatrix(pd.read_csv(path))
    elif file_extension == '.txt':# 假设TXT文件使用制表符分隔
        return zmatrix(pd.read_csv(path, sep='\t'))
    elif file_extension == '.json':
        return zmatrix(pd.read_json(path))
    else:
        raise ValueError("Unsupported file extension: {}".format(file_extension))

class zmatrix:
    def __init__(self, data, col_name=None, index=None):
        if(isinstance(data,zltcalc.ZDataFrame)):
            self._zmatrix = data
        elif(isinstance(data,int) or isinstance(data,float) or isinstance(data,str)):
            if(col_name==None or index==None):
                raise TypeError("The Column name or Index is missing while create zmatrix")
            elif(isinstance(index[0],int)):
                data=[[data] * len(index) for _ in range(len(col_name))]
                self._zmatrix = zltcalc.ZDataFrame.create_from_list_int64_index(data, col_name, index)
            elif(isinstance(index[0],str)):
                data=[[data] * len(index) for _ in range(len(col_name))]
                self._zmatrix = zltcalc.ZDataFrame.create_from_list_str_index(data, col_name, index)
        elif(isinstance(data,list)):
            self._zmatrix = self.create_zmatrix_by_list(data,col_name,index)
        elif(isinstance(data,np.ndarray)):
            self._zmatrix = self.create_zmatrix_by_list(data.tolist(),col_name,index)
        elif(isinstance(data,pd.DataFrame)):
            self._zmatrix = self.create_zmatrix_by_list(data.values.tolist(),data.columns.values.tolist(),data.index.values.tolist())
        elif(isinstance(data,dict)):
            self._zmatrix = self.create_zmatrix_by_reg_list(list(data.values()),list(data.keys()),index)
        else:
            self._zmatrix = zltcalc.ZDataFrame.create_from_map(data, index)
        # 1 代表int64_t 索引 , 0 代表string索引
        self._index_type=zltcalc.ZDataFrame.zmatrix_index_type(self._zmatrix)

    def create_zmatrix_by_list(self,data,col_name=None,index=None):
        transposed_list = list(zip(*data))
        transposed_list = [list(row) for row in transposed_list]
        # float int类型混合的情况下会报错,需要修改第一个值为float类型
        for i in transposed_list:
            if isinstance(i[0],str):
                continue
            if(is_float_list(i)):
                i[0] = float(i[0])
        if(col_name==None or len(col_name)==0):
            col_name = [str(i) for i in range(len(transposed_list))]
        if(index==None or len(index)==0):
            return zltcalc.ZDataFrame.create_from_list(transposed_list,col_name)
        elif(isinstance(index[0],str)):
            return zltcalc.ZDataFrame.create_from_list_str_index(transposed_list,col_name,index)
        elif(isinstance(index[0],int)):
            return zltcalc.ZDataFrame.create_from_list_int64_index(transposed_list,col_name,index)
        elif(isinstance(index[0],float)):
            index=[str(i) for i in index]
            return zltcalc.ZDataFrame.create_from_list_str_index(transposed_list,col_name,index)
        else:
            raise TypeError("Unsupported data/index type in zmatrix init")
        
    def create_zmatrix_by_reg_list(self,data,col_name=None,index=None):
        if(col_name==None or len(col_name)==0):
            col_name = [str(i) for i in range(len(data))]
        if(index==None or len(index)==0):
            return zltcalc.ZDataFrame.create_from_list(data,col_name)
        elif(isinstance(index[0],str)):
            return zltcalc.ZDataFrame.create_from_list_str_index(data,col_name,index)
        elif(isinstance(index[0],int)):
            return zltcalc.ZDataFrame.create_from_list_int64_index(data,col_name,index)
        
                
    def groupby(self,index):
        '''
        将数据(zmatrix)划分为不同的群体(group)
        
        用法:
            zmatrix.groupby(index)

        参数:
            index(list,ndarray,zvector):长度必须与zvector的元素个数相等
        
        返回:
            ZMatrixGroupBy
        '''
        return ZMatrixGroupBy(self._zmatrix, index)
    
    @property
    def index(self):
        '''
        返回zmatrix的索引
        
        用法:
            zmatrix.index
        
        返回:
            numpy.ndarray
        '''
        if(self._index_type==1):
            return zltcalc.ZDataFrame.index_int64(self._zmatrix)
        else:
            return zltcalc.ZDataFrame.index_str(self._zmatrix)
    @property
    def col_name(self):
        '''
        返回zmatrix的列名
        
        用法:
            zmatrix.index
        
        返回:
            numpy.ndarray
        '''
        return np.array(zltcalc.ZDataFrame.col_name(self._zmatrix))
    
    def to_ndarray(self):
        '''
        将zmatrix转为numpy.ndarray
        
        用法:
            to_ndarray(zmatrix)

        参数:
            zmatrix
        
        返回:
            numpy.ndarray
        '''
        return np.array(zltcalc.ZDataFrame.to_ndarray(self._zmatrix))
    
    def to_dataframe(self):
        '''
        将zmatrix转为pandas.DataFrame
        
        用法:
            to_dataframe(zmatrix)

        参数:
            zmatrix
        
        返回:
            pandas.DataFrame
        '''
        return pd.DataFrame(self.to_ndarray().T,index=self.index,columns=self.col_name)

    def filter(self,arr):
        '''
        对zmatrix的每一列依次过滤掉其中值不符合条件的元素,返回相同类型的、由符合条件元素组成的新zmatrix
        
        用法:
            zmatrix.filter(arr)
        
        参数:
            arr(zmatrix,list,ndarray):长度必须与zmatrix的每一列的元素个数相等
        
        返回:
            zvector
        '''
        if(isinstance(arr, zvector)):
            return zmatrix(zltcalc.ZDataFrame.filter(self._zmatrix,arr._zvector))
        else:
            return zmatrix(zltcalc.ZDataFrame.filter(self._zmatrix,arr))
    
    def col(self,col_name):
        '''
        返回对应列名的zvector,如果传入多列返回zmatrix
        
        用法:
            zmatrix.col(col_name)
            zmatrix.col([col_name1,col_name2])
        
        参数:
            col_name(str,list):列名
        
        返回:
            zvector,zmatrix
        '''
        if(isinstance(col_name,str)):
            return zvector(zltcalc.ZDataFrame.col(self._zmatrix,col_name))
        else:
            return zmatrix(zltcalc.ZDataFrame.cols(self._zmatrix,col_name))
    
    def row(self,index):
        '''
        返回对应行的zmatrix,如果传入多行也返回zmatrix
        
        用法:
            zmatrix.row(index)
            zmatrix.row([index1,index2])
        
        参数:
            index:zmatrix索引的对应值或者对应值list
        
        返回:
            zmatrix
        '''
        if(isinstance(index,str) or isinstance(index,int)):
            return zmatrix(zltcalc.ZDataFrame.row(self._zmatrix,index))
        else:
            return zmatrix(zltcalc.ZDataFrame.rows(self._zmatrix,index))
    
    def icol(self,n):
        '''
        返回列对应位置的zvector,从0开始,传入多个位置则返回zmatrix
        
        用法:
            zmatrix.icol(n)
            zmatrix.icol([n1,n2])


        例如:
            zmatrix.icol(0) 返回第一列的zvector
        
        参数:
            n(int,list):第几列
        
        返回:
            zvector,zmatrix
        '''
        if(isinstance(n,int)):
            return zvector(zltcalc.ZDataFrame.icol(self._zmatrix,n))
        else:
            return zmatrix(zltcalc.ZDataFrame.icols(self._zmatrix,n))
    
    def irow(self,n):
        '''
        返回行对应位置的zmatrix,从0开始
        
        用法:
            zmatrix.irow(n)
            zmatrix.irow([n1,n2])
        
        参数:
            n(int,list):第几行
        
        返回:
            zmatrix
        '''
        if(isinstance(n,int)):
            return zmatrix(zltcalc.ZDataFrame.irow(self._zmatrix,n))
        else:
            return zmatrix(zltcalc.ZDataFrame.irows(self._zmatrix,n))

    def copy(self):
        '''
        返回Panel的副本
        
        用法:
            Panel.copy()
        
        返回:
            Panel
        '''
        return zmatrix(zltcalc.ZDataFrame.deepcopy(self._zmatrix))   

    def drop(self,col_name,inplace=False):
        '''
        删除对应列名zvector的列,返回相同类型的、已删除对应列名的zmatrix
        
        用法:
            zmatrix.drop(col_name)
        
        参数:
            col_name(str):列名
            inplace(bool):True,直接在原zvector上进行操作,False,返回一个新zvector,默认为False
        返回:
            zmatrix
        '''
        if(inplace):
            self._zmatrix = zltcalc.ZDataFrame.drop(self._zmatrix,col_name)
            return self
        else:
            return zmatrix(zltcalc.ZDataFrame.drop_new(self._zmatrix,col_name))
        
    
    def dropna(self,axis,how,inplace=False):
        '''
        删除zmatrix中的nan值(缺失值)
        
        用法:
            zmatrix.dropna(axis,how,inplace)
        
        参数:
            axis (bool):轴.0表示按行删除;1表示按列删除.
            how (str):筛选方式.'any',表示该行/列只要有一个以上的空值,就删除该行/列;'all',表示该行/列全部都为空值,就删除该行/列
            inplace(bool):True,直接在原zvector上进行操作,False,返回一个新zvector,默认为False
        返回:
            zmatrix
        '''
        if(inplace):
            self._zmatrix = zltcalc.ZDataFrame.dropna(self._zmatrix,axis,how)
            return self
        else:
            return zmatrix(zltcalc.ZDataFrame.dropna_new(self._zmatrix,axis,how))
    
    def fillna(self,method=None,inplace=False):
        '''
        填充zmatrix中的nan值(缺失值)
        
        用法:
            zmatrix.fillna(value,inplace)
        
        参数:
            method('back', 'before', value): before表示用前一行的值填充当前行的空值,back表示用后一行的值填充当前行的空值.若前/后没有值时,用nan填充
            value (float):具体填充的值
            inplace(bool):True,直接在原zvector上进行操作,False,返回一个新zvector,默认为False
        返回:
            zmatrix
        '''
        if(method == None):
            raise ValueError("method can not be None in zmatrix.fillna")
        elif isinstance(method,str):
            if(inplace):
                self._zmatrix = zltcalc.ZDataFrame.fillna_method(self._zmatrix,method)
                return self
            else:
                return zmatrix(zltcalc.ZDataFrame.fillna_method_new(self._zmatrix,method))
        else:
            if(inplace):
                self._zmatrix = zltcalc.ZDataFrame.fillna_value(self._zmatrix,method)
                return self
            else:
                return zmatrix(zltcalc.ZDataFrame.fillna_value_new(self._zmatrix,method))

#region overload

    def __str__(self):
        return zltcalc.ZDataFrame.__str__(self._zmatrix)
    
    def __getitem__(self,index):
        return self.col(index)
    
    def __setitem__(self, index, value):
        if(isinstance(value,zvector)):
            return zltcalc.ZDataFrame.__setitem__(self._zmatrix,index,value._zvector)
        else:
            return zltcalc.ZDataFrame.__setitem__(self._zmatrix,index,zvector(value)._zvector)
        
    def __len__(self):
        return zltcalc.ZDataFrame.__len__(self._zmatrix)
class ZMatrixGroupBy:
    def __init__(self, data, index=None):
        if(isinstance(index,zvector)):
            if(index._dtype=="int" or index.dtype=="int64"):
                self._group = zltcalc.ZDataFrame.df_vec_to_int_group(data, index._zvector)
            elif(index._dtype=="float"):
                self._group=zltcalc.ZDataFrame.df_float_vec_to_str_group(data, index._zvector)
            else:
                self._group = zltcalc.ZDataFrame.df_vec_to_str_group(data,index._zvector)
        elif(isinstance(index,np.ndarray)):
            self._group=zltcalc.ZDataFrame.groupby(data,index.tolist())
        elif(isinstance(index,list)):
            self._group=zltcalc.ZDataFrame.groupby(data,index)
        elif(isinstance(index,str)):
            groupvec=data.__getitem__(index)# groupvec 此时是c中的ZVector对象
            if(groupvec.dtype()=="int"):
                self._group = zltcalc.ZDataFrame.df_vec_to_int_group(data, groupvec)
                # self._group = zltcalc.ZDataFrame.df_name_to_int_group(data, index)
            elif(groupvec.dtype()=="float"):
                self._group=zltcalc.ZDataFrame.df_float_vec_to_str_group(data, groupvec)
            else:
                self._group = zltcalc.ZDataFrame.df_vec_to_str_group(data,groupvec)
        else:
            raise TypeError("The index type is not supported in groupby")

    def __getitem__(self, index):
        return ZVecGroupBy(self._group.__getitem__(index))
    

#endregion

