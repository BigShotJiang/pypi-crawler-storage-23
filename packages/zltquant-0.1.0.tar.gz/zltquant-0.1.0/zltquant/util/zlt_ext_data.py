'''
获取扩展数据
'''
import datetime
from enum import Enum
import json
import pandas as pd
from .zlt_util import RPCMessageProxy, param_to_dt
from . import zlt_object as zltObj
import zltsdk.strategy_bridge as strategy_bridge

MARKETDICT = {
    "1": "sh",
    "2": "sz",
    "3": "hk",
    "4": "us",
    "5": "gb",
    "6": "jp",
    "7": "cn",
    "8": "tw",
    "9": "hk",
}

MARKETDICT1 = {
    "sh": "1",
    "sz": "2",
    "hk": "3",
    "us": "4",
    "gb": "5",
    "jp": "6",
    "cn": "7",
    "tw": "8",
    "hk": "9",
}


def get_edms_ipc_result(api, reqData, func_name):
    """获取node模块的ipc请求结果"""
    rpcMessage = RPCMessageProxy(strategy_bridge.create_ipc_msg())
    rpcMessage.SetMsgType(strategy_bridge.RPCMsgType.RPCMsgType_Json)
    rpcMessage.SetFuncName(f"zltEdms/{func_name}")
    reqData = json.dumps(reqData)
    rpcMessage.SetData(reqData, len(reqData), len(reqData), True)

    try:
        ansMsg = RPCMessageProxy(
            api.InvokeSync(f"zltEdms/{func_name}", rpcMessage.getObj())
        )
        data = ansMsg.Data()
        if data:
            data = json.loads(ansMsg.Data())
            return data
    except Exception as e:
        raise e


def ext_data_batch_ipc(name, output_indicators, frequency, securities, date=None):
    """获取扩展数据

    name: 扩展数据名称
    output_indicators: 指标名称
    frequency: 数据频率
    security: 代码
    date: 截止时间

    返回:
    - data:扩展数据
    """
    # 读取json文件
    folder_path = f'{zltObj._context.backtest_param["install_path"]}\\Public\\ExData\\ExtendDataOuts\\'
    with open(
        f"{folder_path}{name}.json",
        "r",
        encoding="utf-8",
    ) as f:
        if isinstance(output_indicators, str):
            output_indicators = [output_indicators]
        if isinstance(securities, str):
            securities = [securities]
        desc = json.load(f)
        file_path = f"{folder_path}{desc['id']}_{frequency}_spot.zlt"
        file_path = file_path.replace("//", "\\")
        data = {}
        if date == None:
            date = zltObj._context.current_dt
        date = param_to_dt(date)
        date = int(date.timestamp())
        date = date - (date + 8 * 3600) % 86400 # 当天0点
        name_st = "IndValX3"
        if len(desc["value"]) * 2 > 7:
            name_st = "IndValX15"
        elif len(desc["value"]) * 2 > 3:
            name_st = "IndValX7"
        rank_val = []
        for indicators in output_indicators:
            index = desc["value"].index(indicators) + 1
            rankIndex = len(desc["value"]) + index
            rank_val.append((indicators, index, rankIndex))
            data[indicators] = []
        # symbol = int(MARKETDICT1[security[:2]] + security[2:])
        result = get_edms_ipc_result(
            zltObj._context.IPCClient,
            {
                "file_src": file_path,
                "name_st": name_st,
                "index": date,
                "size": 6000,
                "ts_start": 0,
                "ts_end": 0,
            },
            "getIterByIdx",
        )
        if result == None or not result["data"]:
            return data
        for item in result["data"]:
            marketVal = MARKETDICT[str(item["time"])[0]]
            if marketVal + str(item["time"])[1:] not in securities:
                continue
            for item1 in rank_val:
                data[item1[0]].append(
                    {
                        "code": marketVal + str(item["time"])[1:],
                        "value": item[f"val{item1[1]}"] / 10000,
                        "rank": item[f"val{item1[2]}"],
                    }
                )
    for key in data.keys():
        data[key] = pd.DataFrame(data[key])
    if len(output_indicators) == 1:
        return data[output_indicators[0]]
    return data


def ext_data_range_ipc(name, output_indicators, frequency, security, start=None, end=None):
    """获取扩展数据(时序)

    name: 扩展数据名称
    output_indicators: 扩展数据指标名称
    frequency: 数据频率
    security: 股票代码
    start: 开始时间
    end: 结束时间

    返回:
    - data:扩展数据
    """
    # 读取json文件
    folder_path = f'{zltObj._context.backtest_param["install_path"]}\\Public\\ExData\\ExtendDataOuts\\'
    with open(
        f"{folder_path}{name}.json",
        "r",
        encoding="utf-8",
    ) as f:
        if isinstance(output_indicators, str):
            output_indicators = [output_indicators]
        desc = json.load(f)
        file_path = f"{folder_path}{desc['id']}_{frequency}.zlt"
        file_path = file_path.replace("//", "\\")
        data = {}
        if start == None:
            start = zltObj._context.current_dt
        if end == None:
            end = zltObj._context.current_dt

        start = param_to_dt(start)
        end = param_to_dt(end)
        size = (end - start).days + 1
        name_st = "IndValX3"
        if len(desc["value"]) > 3:
            name_st = "IndValX7"
        elif len(desc["value"]) > 7:
            name_st = "IndValX15"
        symbol = int(MARKETDICT1[security[:2]] + security[2:])
        result = get_edms_ipc_result(
            zltObj._context.IPCClient,
            {
                "file_src": file_path,
                "name_st": name_st,
                "index": symbol,
                "size": size,
                "ts_start": int(start.timestamp()),
                "ts_end": int(end.timestamp() + 86400),
            },
            "getIterByIdx",
        )
        if result == None:
            return pd.DataFrame(data)
        rank_val = []
        for indicator in output_indicators:
            index = desc["value"].index(indicator) + 1
            rankIndex = len(desc["value"]) + index
            rank_val.append((indicator, index))
            data[indicator] = []

        time = None
        timeObj = None
        if not result["data"]:
            return pd.DataFrame(data)
        for item in result["data"]:
            marketVal = MARKETDICT[str(item["index"])[0]]
            if time != item["time"]:
                time = item["time"]
                timeObj = datetime.datetime.fromtimestamp(time)
                for item1 in rank_val:
                    data[item1[0]].append(
                        {
                            "code": marketVal + str(item["index"])[1:],
                            "time": timeObj,
                            "value": item[f"val{item1[1]}"] / 10000,
                        }
                    )
    for key in data.keys():
        data[key] = pd.DataFrame(data[key])
    if len(output_indicators) == 1:
        return data[output_indicators[0]]
    return data



class DataType(Enum):
    EX_DATA_TYPE_EXDATA = 1  # 扩展数据
    EX_DATA_TYPE_FACTOR = 2  # 因子数据


class StoreType(Enum):
    EX_STORE_TYPE_SQUE = 1  # 时序
    EX_STORE_TYPE_SPOT = 2  # 截面


class PeriodType(Enum):
    EX_PERIOD_TYPE_DAY = 1  # 日线
    EX_PERIOD_TYPE_MIN = 2  # 分钟线
    EX_PERIOD_TYPE_TIC = 3  # TICK


def ext_data_range(stock, category, name, start_time, end_time, period = "1d", df=False):
    """获取扩展数据(时序)

    stock: 股票代码
    category: 扩展数据分类
    name: 扩展数据名称
    start_time: 开始时间
    end_time: 结束时间
    period: 数据频率
    df: 是否返回DataFrame

    返回:
    - data:扩展数据
    """
    start = param_to_dt(start_time)
    end = param_to_dt(end_time)
    if isinstance(stock, str):
        stock = [stock]
    exdata_attr = strategy_bridge.ExDataAttr()
    exdata_attr.lab_id = -1
    exdata_attr.category = category.encode("gbk")
    exdata_attr.name = name.encode("gbk")
    exdata_attr.data_type = DataType.EX_DATA_TYPE_EXDATA.value
    exdata_attr.store_type = StoreType.EX_STORE_TYPE_SQUE.value
    if period == "1d":
        exdata_attr.period_type = PeriodType.EX_PERIOD_TYPE_DAY.value
    elif period == "1m":
        exdata_attr.period_type = PeriodType.EX_PERIOD_TYPE_MIN.value
    exdata_attr.start_time = int(start.strftime("%Y%m%d"))
    exdata_attr.end_time = int(end.strftime("%Y%m%d"))
    remark = strategy_bridge.getEdmsAttrInfo(exdata_attr)
    if remark == "":
        return None
    remark = json.loads(remark)
    dtype = []
    for item in remark["declare"]:
        dtype.append((item["name"], item["type"]))
    content = strategy_bridge.getEdmsContents(
        stock,
        exdata_attr,
        int(start.timestamp()) * 1000,
        int(end.timestamp()) * 1000,
        remark["declare"],
    )
    if content is None:
        return None
    if df:
        rows = []  # 用于保存每一行数据（字典格式）
        for stock_code, arr in content.items():
            for record in arr:  # arr 可能有多条记录，这里遍历每一条
                row = {
                    "stock_code": stock_code,  # 添加股票代码作为一列
                }
                for item in dtype:
                    row[item[0]] = record[item[0]]
                rows.append(row)

        # 构造 DataFrame
        df = pd.DataFrame(rows)
        df['time'] = df["time"].apply(lambda x : param_to_dt(x / 1000))
        return df
    return content

def ext_data_batch(category, name, end_time, df=False, period = "1d", stock=None):
    """获取扩展数据(截面)

    category: 扩展数据分类
    name: 扩展数据名称
    end_time: 结束时间
    df: 是否返回DataFrame
    period: 频率，"1d"或"1m"

    返回:
    - data:扩展数据
    """
    start = param_to_dt(end_time)
    end = param_to_dt(end_time)
    exdata_attr = strategy_bridge.ExDataAttr()
    exdata_attr.lab_id = -1
    exdata_attr.category = category.encode("gbk")
    exdata_attr.name = name.encode("gbk")
    exdata_attr.data_type = DataType.EX_DATA_TYPE_EXDATA.value
    exdata_attr.store_type = StoreType.EX_STORE_TYPE_SPOT.value
    if period == "1d":
        exdata_attr.period_type = PeriodType.EX_PERIOD_TYPE_DAY.value
    else:
        exdata_attr.period_type = PeriodType.EX_PERIOD_TYPE_MIN.value
    exdata_attr.start_time = int(start.strftime("%Y%m%d"))
    exdata_attr.end_time = int(end.strftime("%Y%m%d"))
    remark = strategy_bridge.getEdmsAttrInfo(exdata_attr)
    if remark == "":
        return None
    remark = json.loads(remark)
    dtype = []
    for item in remark["declare"]:
        dtype.append((item["name"], item["type"]))
    spot = ""
    if period == "1d":
        spot = "15:00"
    else:
        spot = end.strftime("%H:%M")
    content = strategy_bridge.getEdmsContentsSpot(
        1,
        exdata_attr,
        int(start.timestamp()) * 1000,
        int(end.timestamp()) * 1000,
        remark["declare"],
        spot
    )
    if content is None:
        return None
    if df:
        rows = []  # 用于保存每一行数据（字典格式）
        for stock_code, arr in content.items():
            for record in arr:  # arr 可能有多条记录，这里遍历每一条
                row = {
                    # "stock_code": stock_code,  # 添加股票代码作为一列
                }
                for item in dtype:
                    row[item[0]] = record[item[0]]
                rows.append(row)
        
        # 构造 DataFrame
        df = pd.DataFrame(rows)
        if df.empty:
            return None
        df['time'] = df["time"].apply(lambda x : param_to_dt(x / 1000))
        return df
    return content

def ext_data_batch_by_range(category, name, start_time, end_time, df=False, period = "1d", stock=None):
    """获取扩展数据(截面)

    stock: 股票代码
    category: 扩展数据分类
    name: 扩展数据名称
    end_time: 结束时间
    df: 是否返回DataFrame
    period: 频率，"1d"或"1m"

    返回:
    - data:扩展数据
    """
    start = param_to_dt(start_time)
    end = param_to_dt(end_time)
    exdata_attr = strategy_bridge.ExDataAttr()
    exdata_attr.lab_id = -1
    exdata_attr.category = category.encode("gbk")
    exdata_attr.name = name.encode("gbk")
    exdata_attr.data_type = DataType.EX_DATA_TYPE_EXDATA.value
    exdata_attr.store_type = StoreType.EX_STORE_TYPE_SPOT.value
    if period == "1d":
        exdata_attr.period_type = PeriodType.EX_PERIOD_TYPE_DAY.value
    else:
        exdata_attr.period_type = PeriodType.EX_PERIOD_TYPE_MIN.value
    exdata_attr.start_time = int(start.strftime("%Y%m%d"))
    exdata_attr.end_time = int(end.strftime("%Y%m%d"))
    remark = strategy_bridge.getEdmsAttrInfo(exdata_attr)
    if remark == "":
        return None
    remark = json.loads(remark)
    dtype = []
    for item in remark["declare"]:
        dtype.append((item["name"], item["type"]))
    spot = ""
    if period == "1d":
        spot = "15:00"
    else:
        spot = end.strftime("%H:%M")
    content = strategy_bridge.getEdmsContentsSpot(
        1,
        exdata_attr,
        int(start.timestamp()) * 1000,
        int(end.timestamp()) * 1000,
        remark["declare"],
        spot
    )
    if content is None:
        return None
    if df:
        rows = []  # 用于保存每一行数据（字典格式）
        for stock_code, arr in content.items():
            for record in arr:  # arr 可能有多条记录，这里遍历每一条
                row = {
                    # "stock_code": stock_code,  # 添加股票代码作为一列
                }
                for item in dtype:
                    row[item[0]] = record[item[0]]
                rows.append(row)
        
        # 构造 DataFrame
        df = pd.DataFrame(rows)
        if df.empty:
            return None
        df['time'] = df["time"].apply(lambda x : param_to_dt(x / 1000))
        return df
    return content

__all__ = ["ext_data_batch_ipc", "ext_data_range", "ext_data_batch_by_range"]
