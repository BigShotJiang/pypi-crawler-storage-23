'''
量化框架对象申明
'''
import datetime
import json
import os
from .zlt_util import RPCMessageProxy, param_to_dt
import zltsdk.strategy_bridge as strategy_bridge
import sqlite3
from typing import Any


class Context:
    """_context 对象

    属性:
    - portfolio:总账户(Portfolio 对象)
    - subportfolios:子账户 list[]
    - run_params: 运行参数(RunParams对象)
    - universe 股票池
    - previous_date 上一个交易日
    """

    def __init__(self) -> None:
        # c中的上下文对象
        self.sdk_context = None
        # 开发环境
        self.dev = False
        # 测试工程标识
        self.test = False
        # 子账户
        self.subportfolios = []
        # 总账户
        self.portfolio: Portfolio
        self.universe = tuple([])
        self.run_params: RunParams
        self.IPCClient = None
        # 当前订阅的信息
        self.subscribe = {}
        self.sys_benchmark = None
        self.backtest_param = {
            # 开始时间和结束时间
            "start_time": "",
            "end_time": "",
            # 基准
            "benchmark": {},
            # 初始资金
            "initial_cash": None,
            # 初始基准价格
            "init_bench": None,
            # 保证金比例
            "margin_ratio": 3,
            # 滑点类型
            "slippage_type": 0,
            # 滑点
            "slippage": 0.00123,
            # 策略模式
            "strategy_mode": "backtest",
            # 成交比例 默认为:1
            "order_volume_ratio": 1,
            # 是否开启盘口撮合 0:bar 1:tick
            "match_with_order_book": 0,
            "stock_cost": {},
            "fund_cost": {},
            "future_cost": {},
            # node传入路径
            "project_path": "",
            # 启动类型 1: 继续执行 0: 重新启动
            "exec_type": 0,
        }
        self.strategy_info = {
            # 模型名称
            "name": str,
            # 策略ID,自动生成
            "strategy_id": str,
            # 回测ID
            "backtest_id": str,
            # 资金账号
            "fund_account": str,
            # 简称
            "shortcut_code": 3,
            # 模型说明
            "description": 4,
            # 模型分类
            "category": 5,
            # 默认周期
            "default_period": str,
            # 默认品种
            "default_symbol": 7,
            # 复权方式
            "adjustment_type": 8,
            # 快速计算
            "quick_calculation": 9,
            # 刷新间隔
            "refresh_interval": 1,
            # 加密公式
            "encrypted_formula": 1,
            # 凭密码导出公式
            "export_password": 1,
            # 用法注释
            "usage_notes": 1,
            # 用户id
            "userid": 1,
            # 盈利次数
            "win_num": 0,
            # 亏损次数
            "lose_num": 0,
            # 平仓盈亏-赚
            "win_money": 0,
            # 平仓盈亏-亏
            "lose_money": 0,
            # 日志目录
            "logs_path": "",
        }
        # 资金账号
        self.stashNumber = "0"
        # 每日总资产
        self.portfolio_daily = []
        # 每日基准价格
        self.benchmark_daily = []
        # 每日持仓市值
        self.market_value_daily = []
        # 每日买入量
        self.buy_amount_daily = 0
        # 每日卖出量
        self.sell_amount_daily = 0
        # 每日持仓量
        self.turnover_daily = []
        # 每日基准价格cache
        self.all_benchmark = []
        # 日期
        self.daily = []
        # 成交汇总
        self.trade_list = []
        # 自动化测试对比结果写入路径
        self.comp_result_path = None
        # 系统级日志
        self.sys_log = None
        # 回调信号事件
        self.callback_event = {}
        # 最大下单数量
        self.max_order_num = {}
        # 每日回测需要落库的信息
        self.entrust_list = []
        self.position_list = []
        self.profit_list = []
        self.task_thread = None
        # 每日回测的收盘信息 - 自动化测试专用
        self.orders = {}
        self.strategy_positions = {}
        self.result = {}
        # 刷新内存信息变量
        self.pos_visited = False
        self.sub_pos_visited = False
        self.por_visited = False
        # 策略内周频率的数组
        self.run_weekly = []
        # 策略内月频率的数组
        self.run_monthly = []
        # 是否执行main中的init
        self.not_init = True
        # 策略执行完成状态
        self.stop = False
        # 策略执行的当前天数
        self.current_day_index = 0
        # 数据中心对象
        self.datacenter_obj = None
        # 回测db连接对象(线程专用)
        self.bt_db_conn = None
        # 主进程专用
        self.main_db_conn = None
        # 仿真专用
        self.sim_db_conn = None
        # db数据库文件夹路径
        self.db_dir = None
        # 策略状态
        self.status = 0
        # 扩展数据上下文
        self.ext_data_context = None

    @property
    def current_dt(self):
        if self.ext_data_context is None:
            return datetime.datetime.fromtimestamp(self.GetStrategyEngine().Now())
        else:
            return self.ext_data_context.current_dt

    @property
    def previous_date(self):
        if self.ext_data_context is None:
            local_t = param_to_dt(str(self.GetStrategyEngine().LastTradeDay()))
            return local_t.date()
        else:
            return self.ext_data_context.previous_date

    def SetBacktestParams(self, backtest_param):
        """
        设置回测参数
        """
        keys = backtest_param.keys()
        for key in keys:
            self.backtest_param[key] = backtest_param[key]

    def GetBacktestParams(self):
        pass

    def SetParams(self, range, name, value):
        """同步数据给SDK后端"""
        pass

    def GetParams(self, range, name):
        return self.sdk_context.GetParams(range, name)
        # 获取参数
        pass

    def GetCurStrategy(self):
        # 获取当前策略
        pass

    def GetTradeApi(self):
        # 获取交易接口
        pass

    def GetStrategyEngine(self):
        # 获取策略引擎
        pass

    def GetStrategyEstimate(self):
        pass

    def GetLog(self):
        pass

    def GetLogUser(self):
        pass

    def GetSDKContext(self):
        return self.sdk_context

    def GetStrategyResult(self):
        list = []
        for item in self.profit_list:
            obj = {}
            obj.update(
                {
                    "date": item["date"],
                    "strategy_profit": round(item["strategy_profit"], 2),
                    "benchmark_profit": round(item["benchmark_profit"], 2),
                }
            )
            list.append(obj)
        return list


class tempContext:
    def __init__(self, security, current_dt, previous_date, universe):
        self.security = security
        current_dt = param_to_dt(current_dt)
        previous_date = param_to_dt(previous_date).date()
        self.current_dt = current_dt
        self.previous_date = previous_date
        self.universe = universe
        pass


class ExContext:
    """扩展上下文对象"""

    def __init__(self) -> None:
        # IPC通讯对象
        self.exDataIPC = None
        # 策略引擎对象
        self.strategyEngine = None
        # 扩展数据全局复权方式修改
        self.fq_method = None

    def write_data_to_file(self, data_list, file_dst, name_st):
        """
        写入数据到文件
        """
        rpcMessage = RPCMessageProxy(strategy_bridge.create_ipc_msg())
        rpcMessage.SetMsgType(strategy_bridge.RPCMsgType.RPCMsgType_Json)
        rpcMessage.SetFuncName("zltEdms/addDataToFile")
        reqData = {"file_dst": file_dst, "name_st": name_st}
        reqData["add_data_list"] = data_list
        reqData = json.dumps(reqData)
        rpcMessage.SetData(reqData, len(reqData), len(reqData), True)
        try:
            ansMsg = RPCMessageProxy(
                ex_context.exDataIPC.InvokeSync(
                    f"zltEdms/addDataToFile", rpcMessage.getObj()
                )
            )
        except:
            raise Exception("写入文件失败")

    def exit(self):
        self.exDataIPC.Exit()
        self.strategyEngine.Stop()


class FactorContext:
    """因子上下文对象"""

    def __init__(self):
        # 股票集合
        self.security = {}
        # 开始时间
        self.start_date = None
        # 结束时间
        self.end_date = None
        # 交易时间
        self.trade_days = None


class Global:
    """全局g"""

    def __init__(self) -> None:
        pass

    def init(self, is_backtest=False):
        self.is_backtest = is_backtest
        self.has_process_initialize = False
        if is_backtest:  # 回测模式不需要持久化
            return
        folder_path = os.path.join(
            _context.backtest_param["project_path"], "local_data"
        )

        # 如果文件夹不存在，则创建它（包括所有父目录）
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        db_path = os.path.join(
            folder_path, _context.strategy_info["backtest_id"] + ".db"
        )
        # 连接SQLite数据库（如果不存在会自动创建）
        self.__conn = sqlite3.connect(db_path)
        self.__cursor = self.__conn.cursor()

        # 创建cache_data表（如果不存在）
        self.__cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS cache_data (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """
        )
        self.__conn.commit()

        # 初始化时从数据库加载已有的属性
        self._load_attributes()

        if not hasattr(self, "zlt_status"):
            self.zlt_status = "0"  # 0:has_process_initialize赋值阶段 1: 初始化完成 2: 运行中 3: 暂停 4: 停止

    def _load_attributes(self) -> None:
        """从数据库加载所有已存储的属性"""
        self.__cursor.execute(
            "SELECT key, value FROM cache_data where key = 'zlt_status'"
        )
        rows = self.__cursor.fetchall()
        if len(rows) > 0:
            if rows[0][1] != "3" or _context.backtest_param["exec_type"] == 0:
                self.__cursor.execute(
                    "DELETE FROM cache_data where key NOT LIKE 'zlt_sys_%'"
                )
                self.__conn.commit()
        self.__cursor.execute("SELECT key, value FROM cache_data")
        rows = self.__cursor.fetchall()
        for key, value in rows:
            super().__setattr__(key, value)

    def __setattr__(self, name: str, value: Any) -> None:
        """设置属性时同时存入数据库"""
        # 特殊处理数据库连接和游标属性
        if name in (
            "_Global__conn",
            "_Global__cursor",
            "is_backtest",
            "has_process_initialize",
        ):
            super().__setattr__(name, value)
            return

        if self.is_backtest or not self.has_process_initialize:
            # 设置属性值
            super().__setattr__(name, value)
            return

        # 将属性存入数据库
        self.__cursor.execute(
            "INSERT OR REPLACE INTO cache_data (key, value) VALUES (?, ?)",
            (name, str(value)),
        )
        self.__conn.commit()

        # 设置属性值
        super().__setattr__(name, value)

    def __delattr__(self, name: str) -> None:
        if self.is_backtest:
            return
        """删除属性时同时从数据库删除"""
        if name in ("__conn", "__cursor"):
            raise AttributeError(f"Cannot delete {name}")

        self.__cursor.execute("DELETE FROM cache_data WHERE key = ?", (name,))
        self.__conn.commit()

        super().__delattr__(name)

    def __del__(self) -> None:
        if hasattr(self, "is_backtest") and self.is_backtest:
            return
        """析构时关闭数据库连接"""
        if hasattr(self, "__conn"):
            self.__conn.close()


class BTGlobal:
    def __init__(self) -> None:
        pass


class RunParams:
    """策略运行信息

    属性:
    - start_date:回测起始时间
    - end_date:回测结束时间
    - type:回测类型 默认:simple_backtest
    - frequency:回测频率 默认day
    """

    def __init__(
        self,
        start_date="20150101",
        end_date="20151231",
        type="simple_backtest",
        frequency="day",
    ) -> None:
        self.start_date = param_to_dt(start_date).date()
        self.end_date = param_to_dt(end_date).date()
        self.type = type
        self.frequency = frequency

    def __str__(self):
        return f"{self.__class__.__name__}(start_date={self.start_date},end_date={self.end_date},type={self.type},frequency={self.frequency})"


class Position:
    """持仓对象"""

    def __init__(
        self,
        security,
        price,
        acc_avg_cost,
        avg_cost,
        hold_cost,
        init_time,
        transact_time,
        locked_amount,
        total_amount,
        closeable_amount,
        today_amount,
        value,
        side,
        pindex,
    ) -> None:
        self.security = security
        self.price = price
        self.acc_avg_cost = acc_avg_cost
        self.avg_cost = avg_cost
        self.hold_cost = hold_cost
        self.init_time = init_time
        self.transact_time = transact_time
        self.locked_amount = locked_amount
        self.total_amount = total_amount
        self.closeable_amount = closeable_amount
        self.today_amount = today_amount
        self.value = value
        self.side = side
        self.pindex = pindex

    def __str__(self):
        return f"{self.__class__.__name__}(security={self.security},price={self.price},avg_cost={self.avg_cost},locked_amount={self.locked_amount},total_amount={self.total_amount},closeable_amount={self.closeable_amount},today_amount={self.today_amount},value={self.value},side={self.side})"

    def __repr__(self):
        return f"{self.__class__.__name__}(security={self.security},price={self.price},avg_cost={self.avg_cost},locked_amount={self.locked_amount},total_amount={self.total_amount},closeable_amount={self.closeable_amount},today_amount={self.today_amount},value={self.value},side={self.side})"


class PortfolioPosition(dict):
    """总账户持仓"""

    def __getitem__(self, key):
        try:
            return super().__getitem__(key)
        except:
            # 不存在的持仓，返回空持仓
            return Position(
                security=key,
                price=0,
                acc_avg_cost=0,
                avg_cost=0,
                hold_cost=0,
                init_time=None,
                transact_time=None,
                locked_amount=0,
                total_amount=0,
                closeable_amount=0,
                today_amount=0,
                value=0,
                side=None,
                pindex="",
            )


class SubPortfolioPosition(dict):
    """子账号持仓"""

    def __getitem__(self, key):
        try:
            return super().__getitem__(key)
        except:
            return Position(
                security=key,
                price=0,
                acc_avg_cost=0,
                avg_cost=0,
                hold_cost=0,
                init_time=0,
                transact_time=0,
                locked_amount=0,
                total_amount=0,
                closeable_amount=0,
                today_amount=0,
                value=0,
                side="long",
                pindex="",
            )


class PositionsDict(dict):
    def __getitem__(self, key):
        data = self.fetch_data(key)
        # 存储数据到字典中
        self[key] = data
        # 返回字典中的数据
        return data

    def fetch_data(self, key):
        strategyId = _context.strategy_info["backtest_id"]
        fundAccid = _context.strategy_info["fund_account"]
        fundType = "1"
        secType = "1"
        orderTime = int(_context.current_dt.timestamp())
        data = strategy_bridge.TradeQryTakePositionB(
            strategyId, fundAccid, fundType, secType, orderTime
        )
        if data["ansNum"] != 0:
            hold_position = data["data"][0]
            # 这里简单地返回一个示例数据，实际中可能会涉及更复杂的逻辑
            position = Position(
                security=key,
                price=0,
                acc_avg_cost=0,
                avg_cost=hold_position["openAvgPrice"],
                hold_cost=0,
                init_time=None,
                transact_time=None,
                locked_amount=hold_position["settleQty"],
                today_amount=hold_position["todayQuantit"],
                closeable_amount=hold_position["availableQty"],
                total_amount=(hold_position["openQty"] + hold_position["settleQty"]),
                value=0,
                side=None,
                pindex=0,
            )
            return position
        else:
            position = Position(
                security=key,
                price=0,
                acc_avg_cost=0,
                avg_cost=0,
                hold_cost=0,
                init_time=None,
                transact_time=None,
                locked_amount=None,
                today_amount=0,
                closeable_amount=0,
                total_amount=0,
                value=0,
                side=None,
                pindex=0,
            )
            return position

    def __str__(self):
        repr_info = "{"
        for key in self:
            repr_info += f'"{key}:{self[key].__str__()}'
        repr_info += "}"
        return repr_info


class DailyBar:
    def __init__(self, time, security, open, close, high, low, volume, factor) -> None:
        self.security = security
        self.dt = time
        self.open = open
        self.close = close
        self.high = high
        self.low = low
        self.volume = volume
        self.factor = factor

    def __str__(self):
        return f"{self.__class__.__name__}(security={self.security},dt={self.dt},open={self.open},close={self.close},high={self.high},low={self.low},volume={self.volume},factor={self.factor})"


class BarDict(dict):
    def __getitem__(self, key):
        data = self.fetch_data(key)
        # 存储数据到字典中
        self[key] = data
        # 返回字典中的数据
        return data

    def fetch_data(self, key):
        code = key
        end_date = _context.current_dt.strftime("%Y-%m-%d %H:%M:%S")
        fq_ref_date = 0
        fre = _context.run_params.frequency
        npbar = strategy_bridge.get_price_new(
            "", end_date, code, fre, "none", 1, False, False, True, True, fq_ref_date
        )
        time = datetime.datetime.fromtimestamp(npbar["time"][0] / 1000)
        return DailyBar(
            time,
            key,
            npbar["open"][0],
            npbar["close"][0],
            npbar["high"][0],
            npbar["low"][0],
            npbar["volume"][0],
            npbar["factor"][0],
        )


class TickDict(dict):
    def __getitem__(self, key):
        data = self.fetch_data(key)
        # 存储数据到字典中
        self[key] = data
        # 返回字典中的数据
        return data

    def fetch_data(self, key):
        """获取标的最新tick数据

        参数:
        - key: 标的代码

        返回:
        - Tick对象: 包含最新tick数据的对象
        - None: 如果没有今日数据则返回None
        """
        code = key
        end_dt = _context.current_dt
        end_date = end_dt.strftime("%Y%m%d%H%M%S")
        count = 1
        start_dt = ""
        ts = int(end_dt.timestamp())
        # 计算今天0点的时间戳(毫秒)
        today_ts = (ts - (ts + 8 * 60 * 60) % 86400) * 1000

        result = strategy_bridge.get_ticks(code, start_dt, end_date, count, True)
        if len(result) and result[0]["time"] > today_ts:
            return Tick(
                code,
                result[0]["time"],
                result[0]["current"],
                result[0]["open"],
                result[0]["high"],
                result[0]["low"],
                result[0]["volume"],
                result[0]["money"],
                result[0]["a1_v"],
                result[0]["a2_v"],
                result[0]["a3_v"],
                result[0]["a4_v"],
                result[0]["a5_v"],
                result[0]["a1_p"],
                result[0]["a2_p"],
                result[0]["a3_p"],
                result[0]["a4_p"],
                result[0]["a5_p"],
                result[0]["b1_v"],
                result[0]["b2_v"],
                result[0]["b3_v"],
                result[0]["b4_v"],
                result[0]["b5_v"],
                result[0]["b1_p"],
                result[0]["b2_p"],
                result[0]["b3_p"],
                result[0]["b4_p"],
                result[0]["b5_p"],
            )
        else:
            return None


class Portfolio:
    """主账户

    属性:
    - inout_cash:出入金
    - available_cash:可用资金
    - transferable_cash:可转资金
    - locked_cash:冻结资金
    - margin:保证金
    - positions:持仓 list[Position对象]
    - long_positions:持多仓 list[Position对象]
    - short_positions:持空仓 list[Position对象]
    - total_value:总资产
    - returns 总权益的累计收益
    - starting_cash:初始资金
    - positions_value:持仓价值
    """

    def __init__(
        self,
        inout_cash=0.0,
        available_cash=0.0,
        transferable_cash=0.0,
        locked_cash=0.0,
        margin=0.0,
        positions=PortfolioPosition(),
        long_positions=PositionsDict(),
        short_positions=PositionsDict(),
        total_value=0.0,
        returns=0.0,
        starting_cash=0.0,
        positions_value=0.0,
    ) -> None:
        self.inout_cash = inout_cash
        self.available_cash = available_cash
        self.transferable_cash = transferable_cash
        self.locked_cash = locked_cash
        self.margin = margin
        self.positions = positions
        self.long_positions = long_positions
        self.short_positions = short_positions
        self.total_value = total_value
        self.returns = returns
        self.starting_cash = starting_cash
        self.positions_value = positions_value
        self.type = "stock"

    def __getattribute__(self, name: str):
        if name == "type":
            type = _context.subportfolios[0].type
            return type
        if name == "available_cash":
            # 可用资金 = 所有子账号可用资金之和
            available_cash = 0
            subportfolios = _context.subportfolios
            for subportfolio in subportfolios:
                available_cash += subportfolio.available_cash
            return available_cash
        if name == "total_value":
            # 总资产 = 所有子账号总资产之和
            total_value = 0
            subportfolios = _context.subportfolios
            for subportfolio in subportfolios:
                total_value += subportfolio.total_value
            return total_value
        if name == "positions" or name == "long_positions":
            # 持仓 = 所有子账号持仓信息的汇总
            positions = PortfolioPosition()
            subportfolios = _context.subportfolios
            for item in subportfolios:
                for symbol in item.long_positions:
                    obj = item.long_positions[symbol]
                    # 让dict对象存在symbol,随意赋值
                    if obj.total_amount != 0:
                        positions[symbol] = obj
            return positions
        if name == "short_positions":
            # 持空仓 = 所有子账号持空仓信息的汇总
            short_positions = PortfolioPosition()
            subportfolios = _context.subportfolios
            for item in subportfolios:
                for symbol in item.short_positions:
                    obj = item.short_positions[symbol]
                    # 让dict对象存在symbol,随意赋值
                    if obj.total_amount != 0:
                        short_positions[symbol] = obj
            return short_positions
        if name == "positions_value":
            # 持仓价值 = 所有子账号持仓价值之和
            positions_value = 0
            positions = PortfolioPosition()
            subportfolios = _context.subportfolios
            for item in subportfolios:
                for symbol in item.long_positions:
                    obj = item.long_positions[symbol]
                    # 让dict对象存在symbol,随意赋值
                    positions_value += obj.value
            for item in subportfolios:
                for symbol in item.short_positions:
                    obj = item.short_positions[symbol]
                    # 让dict对象存在symbol,随意赋值
                    positions_value += obj.value
            return positions_value
        if name == "returns":
            total_value = 0
            subportfolios = _context.subportfolios
            for subportfolio in subportfolios:
                total_value += subportfolio.total_value
            yesterday_asset = 0
            if len(_context.portfolio_daily) == 0:
                yesterday_asset = 0  # _context.backtest_param["initial_cash"]
            else:
                yesterday_asset = _context.portfolio_daily[-1]
            if yesterday_asset == 0:
                return 0
            return round((total_value - yesterday_asset) / yesterday_asset * 100, 2)
        if name == "transferable_cash":
            """可转资金
            ps: 跟可用有所区别, 一般是第二个工作日才能转出
            """
            return 0.0
        if name == "locked_cash":
            locked_cash = 0
            subportfolios = _context.subportfolios
            for item in subportfolios:
                locked_cash += item.locked_cash
            return locked_cash
        if name == "margin":
            margin = 0
            subportfolios = _context.subportfolios
            for item in subportfolios:
                margin += item.margin
            return margin
        return super().__getattribute__(name)

    def get_position(self):
        """获取当前持仓信息"""
        strategyId = _context.strategy_info["strategy_id"]
        fundAccid = _context.strategy_info["fund_account"]
        tradeTime = int(_context.current_dt.timestamp())
        fundType = str(1)  # 1 股票 2 期货
        secType = str(1)  # 1 股票 2 期货
        data = strategy_bridge.TradeQryTakePositionBForUser(
            strategyId, fundAccid, fundType, secType, tradeTime
        )
        positions = {}
        for symbol in data:
            if symbol["side"] == 1:
                side = "long"
            else:
                side = "short"
            positions[symbol["security"].decode()] = Position(
                security=symbol["security"].decode(),
                price=symbol["price"],
                acc_avg_cost=symbol["acc_avg_cost"],
                avg_cost=symbol["avg_cost"],
                hold_cost=symbol["hold_cost"],
                init_time=symbol["init_time"],
                transact_time=symbol["transact_time"],
                locked_amount=symbol["locked_amount"],
                total_amount=symbol["total_amount"],
                closeable_amount=symbol["closeable_amount"],
                today_amount=symbol["today_amount"],
                value=symbol["value"],
                side=side,
                pindex=0,
            )
        return positions

    def __str__(self):
        return f"{self.__class__.__name__}(type={self.type},inout_cash={self.inout_cash},available_cash={self.available_cash},transferable_cash={self.transferable_cash},locked_cash={self.locked_cash},total_value={self.total_value},positions_value={self.positions_value},long_positions={self.long_positions},short_positions={self.short_positions})"


class SubPortfolio:
    """子账户

    属性:
    - inout_cash:出入金
    - available_cash:可用资金
    - transferable_cash:可转资金
    - locked_cash:冻结资金
    - type: 账户所属类型
    - long_positions:持多仓 list[Position对象]
    - short_positions:持空仓 list[Position对象]
    - total_value:总资产
    - net_value:净资产
    - cash_liability: 融资负债
    - sec_liability: 融券负债
    - interest: 利息总负债
    - maintenance_margin_rate: 维持担保比例
    - available_margin: 融资融券可用保证金
    - margin:保证金
    """

    def __init__(
        self,
        inout_cash=0,
        available_cash=0,
        transferable_cash=0.0,
        pindex=0,
        locked_cash=0.0,
        type="stock",
        long_positions=SubPortfolioPosition(),
        short_positions=SubPortfolioPosition(),
        positions_value=0.0,
        total_value=0.0,
        total_liability=0.0,
        net_value=0.0,
        cash_liability=0.0,
        sec_liability=0.0,
        interest=0.0,
        maintenance_margin_rate=0.0,
        available_margin=0.0,
        margin=0.0,
        base_data=None,
    ) -> None:
        self.base_data = base_data
        self.pindex = pindex
        self.type = type
        self.inout_cash = inout_cash
        self.available_cash = available_cash
        self.transferable_cash = transferable_cash
        self.locked_cash = locked_cash
        self.long_positions = long_positions
        self.short_positions = short_positions
        self.positions_value = positions_value
        self.total_value = total_value
        self.total_liability = total_liability
        self.net_value = net_value
        self.cash_liability = cash_liability
        self.sec_liability = sec_liability
        self.interest = interest
        self.maintenance_margin_rate = maintenance_margin_rate
        self.available_margin = available_margin
        self.margin = margin

    def __getattribute__(self, name: str):
        strategyId = _context.strategy_info["strategy_id"]
        fundAccid = _context.strategy_info["fund_account"]
        tradeTime = int(_context.current_dt.timestamp())
        fundType = str(1)  # 1 股票 2 期货
        secType = str(1)  # 1 股票 2 期货
        if _context.not_init:
            # 若还没执行过main中的init函数使用py层的对象
            return super().__getattribute__(name)
        # 初始化后某些属性直接访问暂存的c层numpy对象
        if name not in ["long_positions", "short_positions", "pindex", "type"]:
            # 判断c层对象是否为空,为空则获取
            base_data = super().__getattribute__("base_data")
            pindex = super().__getattribute__("pindex")
            # 近期访问过不再重新获取除非用户主动刷新
            if base_data is None or not _context.sub_pos_visited:
                ansMsg = strategy_bridge.TradeQryAssetsBForUser(
                    strategyId, fundAccid, fundType, secType, tradeTime
                )
                _context.sub_pos_visited = True
                super().__setattr__("base_data", ansMsg)
            ansMsg = super().__getattribute__("base_data")
            data = ansMsg
            ret = data[name][0]
            return ret
        else:

            def update_positions(pindex):
                """更新持仓信息"""
                long_positions = SubPortfolioPosition()
                short_positions = SubPortfolioPosition()
                ansMsg = strategy_bridge.TradeQryTakePositionBForUser(
                    strategyId, fundAccid, fundType, secType, tradeTime
                )
                data = ansMsg
                for symbol in data:
                    code = symbol["security"].decode()
                    price = round(symbol["price"] + 0.0001, 2)
                    value = round(symbol["value"] + 0.0001, 2)
                    avg_cost = round(symbol["avg_cost"] + 0.0001, 2)
                    if symbol["side"] == 1:
                        side = "long"
                        long_positions[symbol["security"].decode()] = Position(
                            security=code,
                            price=price,
                            acc_avg_cost=symbol["acc_avg_cost"],
                            avg_cost=avg_cost,
                            hold_cost=symbol["hold_cost"],
                            init_time=symbol["init_time"],
                            transact_time=symbol["transact_time"],
                            locked_amount=symbol["locked_amount"],
                            total_amount=symbol["total_amount"],
                            closeable_amount=symbol["closeable_amount"],
                            today_amount=symbol["today_amount"],
                            value=value,
                            side=side,
                            pindex=self.pindex,
                        )
                    elif symbol["side"] == 2:
                        side = "short"
                        short_positions[symbol["security"].decode()] = Position(
                            security=code,
                            price=price,
                            acc_avg_cost=symbol["acc_avg_cost"],
                            avg_cost=avg_cost,
                            hold_cost=symbol["hold_cost"],
                            init_time=symbol["init_time"],
                            transact_time=symbol["transact_time"],
                            locked_amount=symbol["locked_amount"],
                            total_amount=symbol["total_amount"],
                            closeable_amount=symbol["closeable_amount"],
                            today_amount=symbol["today_amount"],
                            value=value,
                            side=side,
                            pindex=self.pindex,
                        )
                _context.pos_visited = True
                return long_positions, short_positions

            if name == "long_positions" or name == "short_positions":
                if not _context.pos_visited:
                    pindex = super().__getattribute__("pindex")
                    long_positions, short_positions = update_positions(pindex)
                    super().__setattr__("long_positions", long_positions)
                    super().__setattr__("short_positions", short_positions)
            return super().__getattribute__(name)

    def __str__(self):
        return f"{self.__class__.__name__}(type={self.type},inout_cash={self.inout_cash},available_cash={self.available_cash},transferable_cash={self.transferable_cash},locked_cash={self.locked_cash},total_value={self.total_value},positions_value={self.positions_value})"

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(type={self.type},inout_cash={self.inout_cash},available_cash={self.available_cash},transferable_cash={self.transferable_cash},locked_cash={self.locked_cash},total_value={self.total_value},positions_value={self.positions_value})"


class SecurityUnitData:
    def __init__(
        self,
        open,
        close,
        low,
        high,
        volume,
        money,
        factor,
        high_limit,
        low_limit,
        avg,
        pre_close,
        paused,
    ) -> None:
        self.open = open
        self.close = close
        self.low = low
        self.high = high
        self.volume = volume
        self.money = money
        self.factor = factor
        self.high_limit = high_limit
        self.low_limit = low_limit
        self.avg = avg
        self.pre_close = pre_close
        self.paused = paused


class Tick:
    def __init__(
        self,
        code,
        time,
        current,
        open,
        high,
        low,
        volume,
        money,
        a1_v,
        a2_v,
        a3_v,
        a4_v,
        a5_v,
        a1_p,
        a2_p,
        a3_p,
        a4_p,
        a5_p,
        b1_v,
        b2_v,
        b3_v,
        b4_v,
        b5_v,
        b1_p,
        b2_p,
        b3_p,
        b4_p,
        b5_p,
    ) -> None:
        self.security = code  # 标的代码
        self.datetime = datetime.datetime.fromtimestamp(time / 1000)  # 发生时间
        self.current = current  # 当前价
        self.open = open  # 当日开盘价
        self.high = high  # 最高价
        self.low = low  # 最低价
        self.volume = volume  # 成交量
        self.money = money  # 成交金额
        # self.position = position
        # a1_v ~ a5_v: 卖一量到卖五量，对于期货，只有卖一量
        # a1_p ~ a5_p: 卖一价到卖五价，对于期货，只有卖一价
        # b1_v ~ b5_v: 买一量到买五量，对于期货，只有买一量
        # b1_p ~ b5_p: 买一价到买五价，对于期货，只有买一价
        self.a1_v = a1_v
        self.a2_v = a2_v
        self.a3_v = a3_v
        self.a4_v = a4_v
        self.a5_v = a5_v
        self.a1_p = a1_p
        self.a2_p = a2_p
        self.a3_p = a3_p
        self.a4_p = a4_p
        self.a5_p = a5_p
        self.b1_v = b1_v
        self.b2_v = b2_v
        self.b3_v = b3_v
        self.b4_v = b4_v
        self.b5_v = b5_v
        self.b1_p = b1_p
        self.b2_p = b2_p
        self.b3_p = b3_p
        self.b4_p = b4_p
        self.b5_p = b5_p

    def __str__(self) -> str:
        return f"Tick({self.datetime}, {self.security}, {self.current},  {self.open}, {self.high}, {self.low}, {self.volume}, {self.money})"

    def __repr__(self) -> str:
        return f"Tick({self.datetime}, {self.security}, {self.current},  {self.open}, {self.high}, {self.low}, {self.volume}, {self.money})"


class Trade:
    def __init__(self, time, security, amount, price, trade_id, order_id) -> None:
        self.time = time
        self.security = security
        self.amount = amount
        self.price = price
        self.trade_id = trade_id
        self.order_id = order_id

    def __str__(self) -> str:
        return f"Trade({{'trade_id': {self.trade_id}, 'order_id': {self.order_id}, 'time': {self.time}, 'amount': {self.amount}, 'price': {self.price})}}"

    def __repr__(self) -> str:
        return f"Trade({{'trade_id': {self.trade_id}, 'order_id': {self.order_id}, 'time': {self.time}, 'amount': {self.amount}, 'price': {self.price})}}"


class Order:
    """订单对象

    - status:
    - add_time: 订单添加时间, [datetime.datetime]对象
    - amount: 下单数量, 不管是买还是卖, 都是正数
    - filled: 已经成交的股票数量, 正数
    - security: 股票代码
    - order_id: 订单ID
    - price: 平均成交价格, 已经成交的股票的平均成交价格(一个订单可能分多次成交)
    - side: 多/空，'long'/'short'
    - action: 开/平， 'open'/'close'
    - commission：交易费用（佣金、税费等）
    - style :订单类型 市价单/限价单
    - pIndex : 子账号
    """

    def __init__(
        self,
        status,
        add_time,
        amount,
        filled,
        security,
        order_id,
        price,
        side,
        action,
        commission,
        style,
        profit,
        pIndex,
    ) -> None:
        self.status = status
        self.add_time = add_time
        self.amount = amount
        self.filled = filled
        self.security = security
        self.order_id = order_id
        self.price = price
        self.side = side
        self.action = action
        self.commission = commission
        self.style = style
        self.profit = profit
        self.pIndex = pIndex

    def __str__(self) -> str:
        style = ""
        if isinstance(self.style, MarketOrderStyle):
            style = "MarketOrderStyle: _limit_price=0.0"
        else:
            style = f"LimitOrderStyle: _limit_price={round(self.style.limit_price + 0.0001,2)}"
        return f"UserOrder({{'order_id':{self.order_id},'status':{self.status},'add_time':{self.add_time},'security':{self.security},'amount':{self.amount},'filled':{self.filled},'side':{self.side},'action':{self.action},'price':{self.price},'commission':{self.commission},'style':{style},'profit':{self.profit}}})"

    def __repr__(self) -> str:
        style = ""
        if isinstance(self.style, MarketOrderStyle):
            style = "MarketOrderStyle: _limit_price=0.0"
        else:
            style = f"LimitOrderStyle: _limit_price={round(self.style.limit_price + 0.0001,2)}"
        return f"UserOrder({{'order_id':{self.order_id},'status':{self.status},'add_time':{self.add_time},'security':{self.security},'amount':{self.amount},'filled':{self.filled},'side':{self.side},'action':{self.action},'price':{self.price},'commission':{self.commission},'style':{style},'profit':{self.profit}}})"


class OrderStatus:
    """订单状态"""

    # 待申报
    prepare = 1

    # 已申报
    already = 2

    # 废单
    cancel = 3

    # 送转股
    share = 4

    # 未成交
    unfilled = 5

    # 部分成交
    partially_filled = 6

    # 部成部撤
    partially_cancelled = 7

    # 全部撤单
    cancelled = 8

    # 全部成交
    filled = 9


class OrderSide:
    """委托单的多/空状态

    - long：多
    - short：空
    """

    # 多
    long = 1
    # 空
    short = 2


class OrderStyle:
    """订单类型

    - market:市价单
    - limit:限价单
    - stop: 止盈止损委托
    """

    limit = 1
    market = 2
    stop = 3


class OrderAction:
    """订单买卖

    - buy：买
    - sell：卖
    """

    buy = 0
    sell = 1


class DividendsEvent:
    def __init__(self, name, pindex, security, side, dividends) -> None:
        pass


class ForcedLiquidationEvent:
    def __init__(self, name, pindex, security, side, amount) -> None:
        pass


class OrderCost:
    """费率对象

    参数:
        - open_tax:开仓印花税
        - close_tax:平仓印花税
        - open_commission:开仓佣金
        - open_fixed_commiission:买入时佣金,按照固定手续费计算时设置该值,仅期货有效
        - close_commission:平仓佣金
        - close_fixed_commiission:卖出时佣金,按照固定手续费计算时设置该值,仅期货有效
        - close_today_commission:平今仓佣金
        - close_fixed_today_commiission:平今时佣金,按照固定手续费计算时设置该值,仅期货有效
        - min_commission:最低佣金
        - max_trade_ratio:最大成交比例
    """

    def __init__(
        self,
        open_tax=0,
        close_tax=0.001,
        open_commission=0.0003,
        open_fixed_commiission=0,
        close_commission=0.0003,
        close_fixed_commiission=0,
        close_today_commission=0,
        close_fixed_today_commiission=0,
        min_commission=5,
        max_trade_ratio=1,
    ) -> None:
        self.open_tax = open_tax
        self.close_tax = close_tax
        self.open_commission = open_commission
        self.open_fixed_commiission = open_fixed_commiission
        self.close_commission = close_commission
        self.close_fixed_commiission = close_fixed_commiission
        self.close_today_commission = close_today_commission
        self.close_fixed_today_commiission = close_fixed_today_commiission
        self.min_commission = min_commission
        self.max_trade_ratio = max_trade_ratio


class MarketOrderStyle:
    """
    市价单
    """

    def __init__(self, limit_price: float):
        self.limit_price = limit_price


class LimitOrderStyle:
    """
    限价单
    """

    def __init__(self, limit_price: float):
        self.limit_price = round(limit_price + 0.0001, 2)


class ParamsError(BaseException):
    pass


class ConfigError(BaseException):
    pass


class HQError(BaseException):
    pass


class TradeError(BaseException):
    pass


class NodeIpcError(BaseException):
    pass


_context = Context()
factor_context = FactorContext()
ex_context = ExContext()
bar_dict = BarDict()
tick_dict = TickDict()
g = Global()


def update_cash_info():
    """更新信息"""
    _context.sub_pos_visited = False
    _context.por_visited = False
    _context.pos_visited = False
