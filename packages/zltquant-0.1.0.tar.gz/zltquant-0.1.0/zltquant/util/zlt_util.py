'''
工具函数
'''
from enum import Enum
from pathlib import Path
import platform
import zltsdk.strategy_bridge as strategy_bridge
import json
from datetime import datetime, time, date, timedelta
import locale

# 系统信息
SYSTEMNAME = platform.system()
# 系统版本
SYSTEMVERSION = platform.release()

# 市场字典
MARKET_DICT = {
    "XSHG": "sh",
    "XSHE": "sz",
    "CCFX": "zj",
    "XDCE": "dl",
    "XSGE": "sq",
    "XZCE": "zz",
}

# 市场字典（ZLT）
MARKET_DICT_ZLT = {
    "sh": "XSHG",
    "sz": "XSHE",
    "bj": "bj",
    "zj": "CCFX",
    "dl": "XDCE",
    "sq": "XSGE",
    "zz": "XZCE",
}


class DataType(Enum):
    """
    数据类型
    """

    EX_DATA_TYPE_EXDATA = 1  # 扩展数据
    EX_DATA_TYPE_FACTOR = 2  # 因子数据


class StoreType(Enum):
    EX_STORE_TYPE_SQUE = 1  # 时序
    EX_STORE_TYPE_SPOT = 2  # 截面


class PeriodType(Enum):
    """
    周期类型
    """

    EX_PERIOD_TYPE_DAY = 1  # 日线
    EX_PERIOD_TYPE_MIN = 2  # 分钟线
    EX_PERIOD_TYPE_TIC = 3  # TICK


class WriteType(Enum):
    """
    写入类型
    """

    WRITE_SEQ = True
    WRITE_SPOT = False


NO_DATA_PTR = 0  # 无数据
NO_DATA_LEN = 0  # 无数据

# 委托类型
ORDER_STYLE = {"market": 2, "limit": 1, "normal": 3}

# 订单状态
ENTRUST_STATUS = {
    "1": "prepare",
    "2": "already",
    "3": "cancel",
    "4": "share",
    "5": "unfilled",
    "6": "partially_filled",
    "7": "partially_cancelled",
    "8": "cancelled",
    "9": "filled",
}

# 定义中国市场的交易时间 - 股票时间
TRADING_SESSIONS = [
    (time(9, 31), time(11, 30)),  # 上午交易时间：9:31 AM - 11:30 AM
    (time(13, 1), time(15, 0)),  # 下午交易时间：1:00 PM - 3:00 PM
]

# 订单操作
ORDER_ACTION = {"0": "open", "1": "close"}


class SECURITY_TYPE(Enum):
    """
    证券类型
    """

    CN_STK_ANY = 0x10  ### < 大陆股票分类
    CN_STK_AMAIN = 0x11  ### < 大陆股票/A股主板
    CN_STK_AKC = 0x12  ### < 大陆股票/A股科创板
    CN_STK_ACY = 0x13  ### < 大陆股票/A股创业板
    CN_STK_B = 0x14  ### < 大陆股票/B股
    CN_STK_OTHER = 0x1F  ### < 大陆股票/其它股票

    CN_BND_ANY = 0x20  ### < 大陆债券
    CN_BND_CGOV = 0x21  ### < 大陆债券/附息国债
    CN_BND_DISC_CGOV = 0x22  ### < 大陆债券/贴现国债
    CN_BND_LGOV = 0x23  ### < 大陆债券/地方政府债
    CN_BND_FIN = 0x24  ### < 大陆债券/金融债
    CN_BND_CORP = 0x25  ### < 大陆债券/企业债（含公司债）
    CN_BND_REPO = 0x26  ### < 大陆债券/质押回购
    CN_BND_CVT = 0x27  ### < 大陆债券/可转公司债
    CN_BND_NPUB = 0x28  ### < 大陆债券/非公开债券
    CN_BND_OTHER = 0x2F  ### < 大陆债券/其它债券

    CN_FND_ANY = 0x30  ### < 大陆基金
    CN_FND_LOF = 0x31  ### < 大陆基金/LOF/上市可交易开放式基金
    CN_FND_ETF = 0x32  ### < 大陆基金/ETF
    CN_FND_INFREIT = 0x3D  ### < 大陆基金/基础设施公募REITs
    CN_FND_JJT = 0x3E  ### < 大陆基金/上证基金通
    CN_FND_OTHER = 0x3F  ### < 大陆基金/其他基金

    CN_IDX_ANY = 0x40  ### < 大陆指数
    CN_IDX = 0x41  ### < 大陆指数/大陆普通指数
    CN_IDX_BND = 0x42  ### < 大陆指数/债券指数
    CN_IDX_H = 0x43  ### < 大陆指数/H股联接指数
    CN_IDX_OTHER = 0x44  ### < 大陆指数/其他指数

    CN_FUT_PR = 0x50  ### < 大陆期货（预留）
    CN_OPT_PR = 0x60  ### < 大陆期权（预留）
    HK_STK_PR = 0x70  ### < 港股（预留)
    CN_OPC = 0xD1  ### < 功能/屏蔽号段功能码
    CN_OTHER = 0xE0  ### < 其他证券
    ZDY_ANY = 0xF0  ### < 自定义品种 系统码表
    ZDY_IDX_SYS = 0xF1  ### < 自定义/系统板块指数
    ZDY_IDX_USR = 0xF2  ### < 自定义/用户板块指数
    ZDY_STK_TL = 0xF3  ### < 自定义/套利品种
    ZDY_STK_COMB = 0xF4  ### < 自定义/组合品种 用户码表

    CN_UNKNOWN = 0xFF  ### < 未知品种


class MyRPCNotify(strategy_bridge.IRPCNotify):
    # 创建Python继承自IRPCNotify接口的类
    def __init__(self):
        strategy_bridge.IRPCNotify.__init__(self)

    def Notify(self, rpcContext, req, ans):
        # 实现Notify方法的逻辑
        pass


class RPCMessageProxy:
    def __init__(self, rpcMessage):
        self._rpcMessage = rpcMessage

    def __del__(self):
        self._rpcMessage.Release()

    def __getattr__(self, name):
        if name == "_rpcMessage":
            return super().__getattribute__(name)
        return getattr(self._rpcMessage, name)

    def getObj(self):
        return self._rpcMessage

    def getObjAdd(self):
        self._rpcMessage.AddRef()
        return self._rpcMessage

    def __getattribute__(self, name):
        return super().__getattribute__(name)

    def __setattr__(self, name, value):
        if name == "_rpcMessage":
            super().__setattr__(name, value)
        else:
            setattr(self._rpcMessage, name, value)


def get_trading_minutes(time_arr):
    """
    获取指定时间段的交易分钟
    """
    trading_minutes = []
    # 遍历每个交易时段
    for session in time_arr:
        start_time = datetime.combine(datetime.today(), session[0])
        end_time = datetime.combine(datetime.today(), session[1])

        # 生成该时段的交易分钟
        while start_time <= end_time:
            trading_minutes.append(start_time.strftime("%H:%M"))
            start_time += timedelta(minutes=1)

    return trading_minutes


def code_jq_to_zlt(symbol):
    """
    聚宽标的转为证量通标的
    """
    [code, market] = symbol.split(".")
    market = MARKET_DICT[market]
    return {"market": market, "code": market + code, "secCd": code}


def zlt_symbol_transform_jq(symbol):
    """
    证量通标的转为聚宽标的
    """
    market_part = symbol[:2]
    number_part = symbol[2:]
    converted_code = f"{number_part}.{MARKET_DICT_ZLT[market_part]}"
    return converted_code


def get_ipc_result(api, reqData, moudule, func_name, ServMode, userid=None):
    """发送ipc请求至其他服务"""
    api_func = f"{moudule}/{func_name}"
    if userid:
        api_func += f"?userid={userid}"
    rpcMessage = RPCMessageProxy(strategy_bridge.create_ipc_msg())
    rpcMessage.SetMsgType(strategy_bridge.RPCMsgType.RPCMsgType_Json)
    rpcMessage.SetFuncName(api_func)
    reqData = json.dumps(reqData)
    rpcMessage.SetData(reqData, len(reqData), len(reqData), True)
    rpcMessage.SetParam("@ServMode", ServMode)
    try:
        ansMsg = RPCMessageProxy(api.InvokeSync(api_func, rpcMessage.getObj()))
        data = ansMsg.Data()
        if data:
            data = json.loads(ansMsg.Data())
            return data
    except Exception as e:
        raise e


def fre_to_timestamp(time, range="smhdwM"):
    """
    频率转为ms
    """
    time_keys_map = {
        "daily": 24 * 60 * 60 * 1000,
        "minute": 1 * 60 * 1000,
        "day": 24 * 60 * 60 * 1000,
        "min": 1 * 60 * 1000,
    }
    if time in time_keys_map:
        return time_keys_map[time]
    else:
        if not isinstance(time, str):
            return time
        unit = time[-1]
        if unit in range:
            number = int(time[:-1])
            if unit == "s":
                return number * 1000
            elif unit == "m":
                if number >= 240:
                    raise BaseException(
                        f"unit必须是xm(x<240),1d(1天),1w(1周),1M(1个月)中一种,实际输入为{time}"
                    )
                return number * 60 * 1000
            elif unit == "h":
                return number * 60 * 60 * 1000
            elif unit == "d":
                return number * 60 * 60 * 1000 * 24
            elif unit == "w":
                return number * 60 * 60 * 1000 * 24 * 7
            elif unit == "M":
                return number * 60 * 60 * 1000 * 24 * 30
        else:
            raise BaseException(
                f"unit必须是xm(x<240),1d(1天),1w(1周),1M(1个月)中一种,实际输入为{time}"
            )


def param_to_dt(time) -> datetime:
    """将时间参数转为datetime对象"""
    # 只在 Windows 7 系统上设置 locale
    if SYSTEMNAME == "Windows" and SYSTEMVERSION == "7":
        try:
            locale.setlocale(
                locale.LC_ALL, "en_US.UTF-8"
            )  # 或者尝试 'en_US' 或 'English'
            locale.setlocale(
                locale.LC_CTYPE, "chinese"
            )  # 注意：'chinese' 可能在某些系统不可用
        except locale.Error as e:
            # 如果设置失败，可以选择打印警告或忽略
            print(f"Warning: Failed to set locale - {e}")
    if isinstance(time, datetime):
        return time
    if isinstance(time, date):
        return datetime.combine(time, datetime.min.time())
    if isinstance(time, str):
        try:
            result = datetime.strptime(time, "%Y-%m-%d %H:%M:%S")
            return result
        except:
            try:
                result = datetime.strptime(time, "%Y/%m/%d %H:%M:%S")
                return result
            except:
                try:
                    result = datetime.strptime(time, "%Y-%m-%d")
                    return result
                except:
                    try:
                        result = datetime.strptime(time, "%Y/%m/%d")
                        return result
                    except:
                        try:
                            result = datetime.strptime(time, "%Y%m%d")
                            return result
                        except:
                            raise BaseException("参数有问题,无法转换!")
    if isinstance(time, int):
        try:
            # 时间戳
            result = datetime.fromtimestamp(time)
            return result
        except:
            raise BaseException("时间格式有误!")
    raise BaseException("参数有问题,无法转换!")


def get_install_path() -> str:
    """获取安装路径"""
    current_file_path = Path(__file__).absolute()
    split_word = "python"
    """获取安装路径"""
    install_path = ""  # 默认调试路径

    try:
        path_parts = str(current_file_path).split(split_word)
        if len(path_parts) > 1:
            install_path = path_parts[0].replace("\\", "/")
        else:
            path_parts = str(current_file_path).split("Python")
            if len(path_parts) > 1:
                install_path = path_parts[0].replace("\\", "/")
            else:
                install_path = "F://ZLTClient-Release"
                print("调试模式，使用默认路径")
        print("install_path:", install_path)
    except Exception as e:
        print(f"路径解析错误: {e}")

    return install_path


def deal_symbol_code(code: str) -> str:
    """
    处理股票代码，将其转换为标准格式
    :param code: 股票代码
    :return: 标准格式的股票代码
    """
    if len(code) == 0:
        return code

    # 处理前两个字符（如果存在）
    first_part = code[:2].lower()

    # 处理剩余字符
    remaining_part = code[2:].upper()

    return first_part + remaining_part

def deal_special_index_code(index_code: str) -> str:
    """
    处理特殊指数代码，将其转换为标准格式
    :param index_code: 指数代码
    :return: 标准格式的指数代码
    """
    if index_code == "sz399300":
        index_code = "sh000300"
    return index_code

__all__ = ["deal_symbol_code", "get_install_path", "param_to_dt", "get_ipc_result"]
