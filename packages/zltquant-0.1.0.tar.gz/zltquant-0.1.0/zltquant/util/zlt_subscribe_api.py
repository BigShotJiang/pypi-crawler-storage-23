'''
订阅相关api
'''
from . import zlt_object as zltObj
import zltsdk.strategy_bridge as strategy_bridge


def subscribe(security, frequency="tick"):
    '''订阅标的的 tick 事件

    参数:
    - security:标的
    - frequency:频率
    '''
    if isinstance(security, str):
        security = [security]
    if frequency != "tick":
        raise Exception("frequency 只能是 tick")
    if zltObj._context.subscribe.get(frequency, None) is None:
        zltObj._context.subscribe[frequency] = {}
    arr = []
    for item in security:
        if zltObj._context.subscribe[frequency].get(item, None) is None:
            zltObj._context.subscribe[frequency][item] = 1
            arr.append(item)
            print(item, "订阅成功")
            # 执行订阅
        else:
            print(item, "已经订阅过了")
    if len(arr) > 0:
        strategy_bridge.SdkSubscribe(arr, frequency)


def unsubscribe(security, frequency="tick"):
    """取消订阅标的的 tick 事件

    参数:
    - security:标的
    - frequency:频率
    """
    if isinstance(security, str):
        security = [security]
    if zltObj._context.subscribe.get(frequency, None) is None:
        print("未订阅任何数据")
        return
    else:
        for item in security:
            # 取消订阅逻辑

            if zltObj._context.subscribe[frequency][item]:
                del zltObj._context.subscribe[frequency][item]
                print("取消订阅:", item)
            continue


def unsubscribe_all():
    """取消订阅所有 tick 事件"""
    if zltObj._context.subscribe.get("tick", None) is None:
        print("未订阅任何数据")
        return
    else:
        for item in zltObj._context.subscribe["tick"]:
            print("取消订阅:", item)
        del zltObj._context.subscribe["tick"]
    pass


__all__ = [
    "subscribe",
    "unsubscribe",
    "unsubscribe_all",
]
