import sqlite3
from .zlt_others import system_log
import os

def create_sim_strategy_db(db_name):
    # 连接数据库
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()
    sql_file = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "sim_strategy.sql"
    )
    # 读取SQL文件
    with open(sql_file, "r", encoding="utf-8") as sql_file:
        sql_script = sql_file.read()

    try:
        # 执行SQL脚本
        cursor.executescript(sql_script)
        conn.commit()
        system_log.info("SQL脚本执行成功")
    except Exception as e:
        conn.rollback()
        system_log.info(f"执行SQL脚本时出错: {e}")
        conn.close()
        raise e


__all__ = [
    "create_sim_strategy_db",
]
