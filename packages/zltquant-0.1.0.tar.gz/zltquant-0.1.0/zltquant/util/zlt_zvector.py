import zltsdk.zltcalc as zltcalc
import numpy as np
import pandas as pd 
np.set_printoptions(precision=4)

def is_float_list(lst):
    return any(type(item) is float for item in lst)

class ZVecGroupBy:
    def __init__(self, vec, index=None):
        if(isinstance(vec, zltcalc.ZVecGroupBy_int64) or isinstance(vec, zltcalc.ZVecGroupBy_str)):
            self._group = vec
        elif(isinstance(index, list)):
            if isinstance(index[0], int):
                self._group = zltcalc.ZVector.zvector_to_group_int64(vec, index)
            elif isinstance(index[0], float):
                self._group = zltcalc.ZVector.zvector_to_group_float(vec, index)
            elif isinstance(index[0], str):
                self._group=zltcalc.ZVector.zvector_to_group_str(vec, index)
        elif isinstance(index, zvector):
            if(index._dtype=="int64" or index._dtype=="int"):
                self._group = zltcalc.ZVector.zvector_to_group_from_int_vec(vec, index._zvector)
            elif(index._dtype=="float"):
                self._group=zltcalc.ZVector.zvector_to_group_from_float_vec(vec, index._zvector)
            else:
                self._group=zltcalc.ZVector.zvector_to_group_from_str_vec(vec,index._zvector)
        elif isinstance(index, np.ndarray):
            # if isinstance(index[0], np.int64) or isinstance(index[0], np.int32) or isinstance(index[0],np.intc):
            if np.issubdtype(index[0].dtype, np.integer):
                self._group = zltcalc.ZVector.zvector_to_group_from_int_array(vec, index)
            elif np.issubdtype(index[0].dtype, np.floating):
                self._group = zltcalc.ZVector.zvector_to_group_from_float_array(vec, index)
            else:
                self._group = zltcalc.ZVector.zvector_to_group_from_str_array(vec, index.tolist())
        else:
            raise TypeError("Unsupported data type")
        self._is_float_index =self._group.is_float_index()
        
    def agg(self, opera,ddof=True):
        '''
        将zvector分组之后的ZVecGroupBy对象进行聚合运算.
        
        用法:
            ZVecGroupBy.agg(opera,ddof)

        参数:
            opera(str,dict):opera,支持的聚合函数有："sum","mean","min","max","count","std","var","median".
            ddof(bool):在对std或var计算时,ddof=1时,使用样本标准差/样本方差,ddof=0时,使用总体标准差/方差.
        
        用法:
            ZVecGroupBy.agg(opera,ddof)

        返回:
            zvector
        '''

        if(isinstance(opera,dict)):
            float_list=list(opera.keys())
            if(self._is_float_index):
                str_list = [str(x) for x in float_list]
                return zvector(self._group.agg_dict(list(opera.values()),str_list,ddof))
            else:
                return zvector(self._group.agg_dict(list(opera.values()),float_list,ddof))
        else:
            return zvector(self._group.agg(opera,ddof))

    # def transform(self, opera):
    #     return zvector(self._group.transform(opera))

    # def apply(self, func):
    #     return zvector(self._group.apply(func))
class zvector:
    def __init__(self, data, index=None):
        '''
        初始化zvector
        
        参数:
            data(list,ndarray,Series,dict,int,float,str): zvector 的数据部分 
            index(list,ndarray): zvector 的索引部分
        
        返回:
            zvector
        '''
        if(index==None and isinstance(data, zltcalc.ZVector)):
            self._zvector = data
        elif(index==None and isinstance(data, np.ndarray)):
            if(isinstance(data[0], str)):
                self._zvector=zltcalc.ZVector.create_vec_np_str(data.tolist())
            else:
                self._zvector = zltcalc.ZVector.create_vec_np(data)        
        elif(index==None and isinstance(data, pd.Series)):
            self._zvector = zltcalc.ZVector.create_vec_series(data)
        elif(index==None and isinstance(data, dict)):
            self._zvector = zltcalc.ZVector.create_vec_any(list(data.values()),list(data.keys()))
        elif(index!=None and isinstance(data, (int, float, str))):
            self._zvector = zltcalc.ZVector.create_vec_sany(data,index)
        elif(index==None):
            if isinstance(data[0],str):
                self._zvector = zltcalc.ZVector.create_vec_by_str(data)
            elif is_float_list(data):
                self._zvector = zltcalc.ZVector.create_vec_by_float(data)
            else:
                self._zvector = zltcalc.ZVector.create_vec_by_int(data)
        else:
            self._zvector = zltcalc.ZVector.create_vec_any(data, index)

        self._dtype=zltcalc.ZVector.dtype(self._zvector)
        self._idtype=zltcalc.ZVector.idtype(self._zvector)

# region zvector_func
    def groupby(self, index):
        '''
        将数据(zvector)划分为不同的群体(group),分组后可进行agg操作
        
        用法:
            zvecotr.groupby(index)

        参数:
            index(list,ndarray,zvector):长度必须与zvector的元素个数相等
        
        返回:
            ZVecGroupBy对象
        '''
        return ZVecGroupBy(self._zvector,index)

    def to_ndarray(self):
        '''
        将zvector转为numpy.ndarray
        
        用法:
            zvector.to_ndarray()

        参数:
            zvector
        
        返回:
            numpy.ndarray
        '''
        if(self._dtype=="int"):
            return zltcalc.ZVector.to_int_ndarray(self._zvector)
        elif(self._dtype=="float"):
            return zltcalc.ZVector.to_float_ndarray(self._zvector)
        elif(self._dtype=="str"):
            return np.array(zltcalc.ZVector.to_str_ndarray(self._zvector))
        else:
            raise TypeError("Unsupported data type : to_ndarray")
        
    def to_series(self):
        '''
        将zvector转为pandas.Series
        
        用法:
            zvector.to_series()

        参数:
            zvector
        
        返回:
            pandas.Series
        '''
        return zltcalc.ZVector.to_series(self._zvector)
    
    @property
    def index(self):
        '''
        返回zvector的索引
        
        用法:
            zvector.index
        
        返回:
            numpy.ndarray
        '''
        if(self._idtype=="int64"):
            if(self._zvector.is_ts()):
                return zltcalc.ZVector.get_index_int64_time(self._zvector)
            else:
                return zltcalc.ZVector.get_index_int64(self._zvector)
            
        elif(self._idtype=="float" or self._idtype=="str"):
            return zltcalc.ZVector.get_index_str(self._zvector)
        else:
            raise TypeError("Unsupported data type : index")


          
    @property
    def values(self):
        '''
        返回zvector的值
        
        用法:
            zvector.values
        
        返回:
            numpy.ndarray
        '''
        if(self._dtype=="int"):
            return zltcalc.ZVector.value_int(self._zvector)
        elif(self._dtype=="float"):
            return zltcalc.ZVector.value_float(self._zvector)
        elif(self._dtype=="str"):
            return zltcalc.ZVector.value_str(self._zvector)
        elif(self._dtype=="double"):
            return zltcalc.ZVector.value_double(self._zvector)
        else:
            raise TypeError("Unsupported data type : value")
        
    @property
    def size(self):
        '''
        返回zvector的元素个数
        
        用法:
            zvector.size
        
        返回:
            int
        '''
        return zltcalc.ZVector.size(self._zvector)
    @property
    def dtype(self):
        '''
        返回zvector的元素类型
        
        用法:
            zvector.dtype
        
        返回:
            string
        '''
        return self._dtype
    # @property
    # def name(self):
    #     return zltcalc.ZVector.name(self._zvector)
    # @name.setter
    # def name(self, new_name):
    #     self._zvector.set_name(new_name)


    def count(self):
        '''
        返回zvector的元素个数
        
        用法:
            zvector.count()
        
        返回:
            int
        '''
        return zltcalc.ZVector.size(self._zvector)
    
    def head(self,n):
        '''
        返回zvector前n个元素组成的zvector
        
        用法:
            zvector.head(n)
            
        参数:
            n(int):返回前n个元素
        
        返回:
            zvector
        '''
        return zvector(zltcalc.ZVector.head(self._zvector,n))
    
    def tail(self,n):
        '''
        返回zvector后n个元素组成的zvector
        
        用法:
            zvector.tail(n)
            
        参数:
            n(int):返回后n个元素
        
        返回:
            zvector
        '''
        return zvector(zltcalc.ZVector.tail(self._zvector,n))
    
    def bottom(self,n):
        '''
        返回zvector降序后的后n个元素组成的zvector
        
        用法:
            zvector.bottom(n)
            
        参数:
            n(int):返回后n个元素
        
        返回:
            zvector
        '''
        return zvector(zltcalc.ZVector.bottom(self._zvector,n))
    
    def top(self,n):
        '''
        返回zvector降序后的前n个元素组成的zvector
        
        用法:
            zvector.top(n)
            
        参数:
            n(int):返回后n个元素
        
        返回:
            zvector
        '''
        return zvector(zltcalc.ZVector.top(self._zvector,n))
    
    def rank(self,ascending=True):
        '''
        返回zvector中每个元素按照一定顺序排序的排名,默认为从小到大的排名
        
        用法:
            zvector.rank(ascending)
            
        参数:
            ascending(bool):ascending = True 为从小到大,ascending = False为从大到小
        
        返回:
            zvector
        '''
        return zvector(zltcalc.ZVector.rank(self._zvector,ascending))
    
    def sort(self,ascending=True):
        '''
        返回按照一定顺序排序后的zvector,默认从小到大排序
        
        用法:
            zvector.sort(ascending)
            
        参数:
            ascending(bool):ascending = True 为从小到大,ascending = False为从大到小
        
        返回:
            zvector
        '''
        return zvector(zltcalc.ZVector.sort(self._zvector,ascending))

    def idxmax(self):
        '''
        返回zvector的最大值的索引
        
        用法:
            zvector.idxmax()
        
        返回:
            zvector对应的索引类型的值
        '''
        return zltcalc.ZVector.idxmax(self._zvector)
    
    def idxmin(self):
        '''
        返回zvector的最小值的索引
        
        用法:
            zvector.idxmin()
        
        返回:
            zvector对应的索引类型的值
        '''
        return zltcalc.ZVector.idxmin(self._zvector)
    
    def idxnrank(self,n,ascending=True):
        '''
        返回zvector中按照一定顺序排名第n个的元素的索引
        
        用法:
            zvector.idxnrank(n,ascending)
        
        参数:
            n(int):第几个
            ascending(bool):ascending = True 为从小到大,ascending = False为从大到小
        
        返回:
            zvector对应的索引类型的值
        '''
        return zltcalc.ZVector.idxnrank(self._zvector,n,ascending)

    def quantile(self,n,ascending=True):
        '''
        返回zvector中处于n分位的元素,默认从小到大排序
        
        用法:
            zvector.quantile(n,ascending)
            
        参数:
            n(int):n分位,n只能为0~1或者在其间的小数,n=0 输出最小的元素,n=1 输出最大的元素
            ascending(bool):ascending = True 为从小到大,ascending = False为从大到小
        
        返回:
            zvector对应类型的值
        '''
        return zltcalc.ZVector.quantile(self._zvector,n,ascending)
    
    def max(self):
        '''
        返回zvector的最大值
        
        用法:
            zvector.max()
        
        返回:
            zvector对应类型的值
        '''
        if(self._dtype == "int64" or self._dtype == "int"):
            return zltcalc.ZVector.max_i(self._zvector)
        elif (self._dtype== "float"):
            return zltcalc.ZVector.max_f(self._zvector)
        else:
            raise TypeError("Unsupported data type")
        
    def min(self):
        '''
        返回zvector的最小值
        
        用法:
            zvector.min()
        
        返回:
            zvector对应类型的值
        '''
        if(self._dtype == "int64" or self._dtype == "int"):
            return zltcalc.ZVector.min_i(self._zvector)
        elif (self._dtype== "float"):
            return zltcalc.ZVector.min_f(self._zvector)
        else:
            raise TypeError("Unsupported data type")
        
    def mean(self):
        '''
        返回zvector的平均值
        
        用法:
            zvector.mean()
        
        返回:
            float
        '''
        return zltcalc.ZVector.mean(self._zvector)
    
    def median(self):
        '''
        返回zvector的中位数
        
        用法:
            zvector.median()
        
        返回:
            float
        '''
        return zltcalc.ZVector.median(self._zvector)
    
    def var(self,ddof=1):
        '''
        返回zvector的方差,默认返回样本方差(ddof=1)
        
        用法:
            zvector.var(ddof)
        
        参数:
            ddof(bool):ddof=1,分母为n-1,返回样本方差,ddof=0,分母为n,返回总体方差
        
        返回:
            float
        '''
        return zltcalc.ZVector.var(self._zvector,ddof)
    
    def std(self,ddof=1):
        '''
        返回zvector的标准差,默认返回样本标准差(ddof=1)
        
        用法:
            zvector.std(ddof)
        
        参数:
            ddof(bool):ddof=1,分母为n-1,返回样本标准差,ddof=0,分母为n,返回总体标准差
        
        返回:
            float
        '''
        return zltcalc.ZVector.std(self._zvector,ddof)
    
    def sum(self):
        '''
        返回zvector中所有值的总和
        
        用法:
            zvector.sum()
        
        返回:
            zvector对应类型的值
        '''
        if(self._dtype == "int64" or self._dtype == "int"):
            return zltcalc.ZVector.sum_i(self._zvector)
        elif (self._dtype== "float"):
            return zltcalc.ZVector.sum_f(self._zvector)
        else:
            raise TypeError("Unsupported data type")
        
    def nrank(self,n,ascending=True):
        '''
        返回zvector中按照一定顺序排名第n个的元素,默认从小到大排序
        
        用法:
            zvector.idxnrank(n,ascending)
        
        参数:
            n(int):第几个
            ascending(bool):ascending = True 为从小到大,ascending = False为从大到小
        
        返回:
            zvector对应位置的值
        '''
        if(self._dtype == "int64" or self._dtype == "int"):
            return zltcalc.ZVector.rank_i(self._zvector,n,ascending)
        elif (self._dtype== "float"):
            return zltcalc.ZVector.rank_f(self._zvector,n,ascending)
        else:
            raise TypeError("Unsupported data type")
    
    def filter(self, arr):
        '''
        过滤掉zvector中值不符合条件的元素,返回相同类型的、由符合条件元素组成的新zvector
        
        用法:
            zvector.filter(arr)
        
        参数:
            arr(zvector,list,ndarray):长度必须与zvector的元素个数相等
        
        返回:
            zvector
        '''
        if(isinstance(arr, zvector)):
            return zvector(zltcalc.ZVector.filter(self._zvector, arr._zvector))
        else:
            return zvector(zltcalc.ZVector.filter(self._zvector, arr))

    def at(self,index):
        '''
        返回对应位置的值
        
        用法:
            zvector.at(index)
        
        参数:
            index(int):支持负数,zvector.at(-1)返回最后一个元素
        
        返回:
            zvector对应位置的值
        '''
        return zltcalc.ZVector.at(self._zvector,index)

    def transform(self, func, inplace=False):
        '''
        对zvector执行传入的函数后返回一个相同形状的zvector
        
        用法:
            zvector.transform(func)
        
        参数:
            func(function):自定义的函数名字,用于转换单个数据的简单函数
            inplace(bool):True,直接在原zvector上进行操作,False,返回一个新zvector,默认为False
        返回:
            zvector
        '''
        if(inplace):
            zltcalc.ZVector.transform(self._zvector, func)
            return self
        else:
            return zvector(zltcalc.ZVector.transform_new(self._zvector, func))
        
    def copy(self):
        '''
        返回zvector的副本
        
        用法:
            zvector.copy()
        
        返回:
            zvector
        '''
        return zvector(zltcalc.ZVector.deepcopy(self._zvector))
    
    def drop(self, index,inplace=False):
        '''
        删除对应索引位置的值和其对应索引
        
        用法:
            zvector.drop(index,inplace)
        
        参数:
            index:zvector对应类型的索引标签,或者对应索引标签的list
            inplace(bool):True,直接在原zvector上进行操作,False,返回一个新zvector,默认为False
        返回:
            zvector
        '''
        if(inplace):
            zltcalc.ZVector.drop(self._zvector, index)
            return self
        else:
            new_vec = zltcalc.ZVector.deepcopy(self._zvector)
            return zvector(zltcalc.ZVector.drop(new_vec, index))
        
    
    def dropna(self,inplace=False):
        '''
        删除zvecotr中的nan值(缺失值)
        
        用法:
            zvector.dropna(inplace)
        
        参数:
            inplace(bool):True,直接在原zvector上进行操作,False,返回一个新zvector,默认为False

        返回:
            zvector
        '''
        if(inplace):
            zltcalc.ZVector.dropna(self._zvector)
            return self
        else:
            new_vec=zltcalc.ZVector.deepcopy(self._zvector)
            return zvector(zltcalc.ZVector.dropna(new_vec))

    def fillna(self,method=None,inplace=False):
        '''
        填充zvector中的nan值(缺失值)
        
        用法:
            zvector.fillna(method,inplace)
        
        参数:
            method('back', 'before', value): before表示用前面的值填充当前的空值,back表示用后面的值填充当前的空值.若前/后没有值时,用nan填充.
            value (float):具体填充的值
            inplace(bool):True,直接在原zvector上进行操作,False,返回一个新zvector,默认为False
        返回:
            zvector
        '''
        if(method == None):
            raise ValueError("method can not be None in zvecotr.fillna")
        elif isinstance(method, str):
            if(inplace):
                zltcalc.ZVector.fillna_method(self._zvector,method)
                return self
            else:
                new_vec=zltcalc.ZVector.deepcopy(self._zvector)
                return zvector(zltcalc.ZVector.fillna_method(new_vec,method))
        else :
            if(inplace):
                zltcalc.ZVector.fillna_value(self._zvector,method)
                return self
            else:
                new_vec=zltcalc.ZVector.deepcopy(self._zvector)
                return zvector(zltcalc.ZVector.fillna_value(new_vec,method))

# endregion

# region operator_overload


    def __getitem__(self, index):
        res=zvector(zltcalc.ZVector.__getitem__(self._zvector, index))
        if(res.size==1):
            return res.values[0]
        else:
            return res
    
    def __setitem__(self, index, value):
        if(self._dtype=="float" and isinstance(value, int)):
            value=float(value)
        return zltcalc.ZVector.__setitem__(self._zvector, index, value)

    def __str__(self):
        return zltcalc.ZVector.__str__(self._zvector)
    
    def __len__(self):
        return zltcalc.ZVector.__len__(self._zvector)
    
    def __add__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__add__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__add__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__add__(self._zvector, other))
        
    def __radd__(self, other):
        return zvector(zltcalc.ZVector.__radd__(self._zvector, other))

    def __mul__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__mul__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__mul__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__mul__(self._zvector, other))

    def __rmul__(self, other):
        return zvector(zltcalc.ZVector.__add__(self._zvector, other))

    def __sub__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__sub__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__sub__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__sub__(self._zvector, other))

    def __rsub__(self, other):
        return zvector(zltcalc.ZVector.__rsub__(self._zvector, other))

    def __truediv__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__truediv__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__truediv__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__truediv__(self._zvector, other))

    def __rtruediv__(self, other):
        return zvector(zltcalc.ZVector.__rtruediv__(self._zvector, other))

    def __floordiv__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__floordiv__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__floordiv__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__floordiv__(self._zvector, other))

    def __rfloordiv__(self, other):
        return zvector(zltcalc.ZVector.__rfloordiv__(self._zvector, other))

    def __mod__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__mod__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__mod__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__mod__(self._zvector, other))

    def __rmod__(self, other):
        return zvector(zltcalc.ZVector.__rmod__(self._zvector, other))

    def __pow__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__pow__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__pow__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__pow__(self._zvector, other))
        
    def __rpow__(self, other):
        return zvector(zltcalc.ZVector.__rpow__(self._zvector, other))


    def __eq__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__eq__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__eq__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__eq__(self._zvector, other))
        
    def __req__(self, other):
        return zvector(zltcalc.ZVector.__req__(self._zvector, other))

    def __ne__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__ne__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__ne__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__ne__(self._zvector, other))

    def __rne__(self, other):
        return zvector(zltcalc.ZVector.__rne__(self._zvector, other))
    
    def __gt__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__gt__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__gt__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__gt__(self._zvector, other))
        
    def __rgt__(self, other):
        return zvector(zltcalc.ZVector.__rgt__(self._zvector, other))
    
    def __lt__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__lt__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__gt__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__lt__(self._zvector, other))

    def __rlt__(self, other):
        return zvector(zltcalc.ZVector.__rlt__(self._zvector, other))
    
    def __ge__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__ge__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__ge__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__ge__(self._zvector, other))
        
    def __rge__(self, other):
        return zvector(zltcalc.ZVector.__rge__(self._zvector, other))

    def __le__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__le__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__le__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__le__(self._zvector, other))

    def __rle__(self, other):
        return zvector(zltcalc.ZVector.__rle__(self._zvector, other))

    def __and__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__and__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__and__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__and__(self._zvector, other))

    def __rand__(self, other):
        return zvector(zltcalc.ZVector.__rand__(self._zvector, other))

    def __or__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__or__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__or__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__or__(self._zvector, other))

    def __ror__(self, other):
        return zvector(zltcalc.ZVector.__ror__(self._zvector, other))
    
    def __xor__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__xor__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__or__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__xor__(self._zvector, other))
        
    def __rxor__(self, other):
        return zvector(zltcalc.ZVector.__rxor__(self._zvector, other))
    
    def __invert__(self):
        return zvector(zltcalc.ZVector.__invert__(self._zvector))
    
    def __rshift__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__rshift__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__rshift__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__rshift__(self._zvector, other))
        
    def __rrshift__(self, other):
        return zvector(zltcalc.ZVector.__rrshift__(self._zvector, other))

    def __lshift__(self, other):
        from .zlt_panel import Panel
        if(isinstance(other, zvector)):
            return zvector(zltcalc.ZVector.__lshift__(self._zvector, other._zvector))
        elif(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__lshift__(other._panel,self._zvector,False))
        else:
            return zvector(zltcalc.ZVector.__lshift__(self._zvector, other))
        
    def __rlshift__(self, other):
        return zvector(zltcalc.ZVector.__rlshift__(self._zvector, other))
    
#endregion