'''
交易dll, 交互api
'''
from . import zlt_object as zltObj
from .zlt_object import Trade, update_cash_info
from datetime import datetime
import zltsdk.strategy_bridge as strategy_bridge

def init_trade_setting(
    feeRatePerson=0.0003,
    slippageType=1,
    slippage=0.00123,
    tradeType=0,
    barCycle=60000,
    orderVolumeRatio=1,
    jvKuanOpenAvgCostSwitch=1,
    adjustAqtyByAvail=3,
    takeFeeType=1,
):
    """初始化策略配置"""
    fundType = str(1)  # 1 股票 2 期货
    logLevel = str(4)
    slippageType = str(slippageType)
    slippage = str(slippage)
    tradeType = str(tradeType)
    orderVolumeRatio = str(orderVolumeRatio)
    jvKuanOpenAvgCostSwitch = str(jvKuanOpenAvgCostSwitch)
    adjustAqtyByAvail = str(adjustAqtyByAvail)
    takeFeeType = str(takeFeeType)
    zltObj._context.SetParams("exParams", "fundType", fundType)
    zltObj._context.SetParams("exParams", "logLevel", logLevel)
    zltObj._context.SetParams("exParams", "slippageType", slippageType)
    zltObj._context.SetParams("exParams", "slippage", slippage)
    zltObj._context.SetParams("exParams", "tradeType", tradeType)
    zltObj._context.SetParams("exParams", "orderVolumeRatio", orderVolumeRatio)
    zltObj._context.SetParams("exParams", "jvKuanOpenAvgCostSwitch", jvKuanOpenAvgCostSwitch)
    zltObj._context.SetParams("exParams", "adjustAqtyByAvail", adjustAqtyByAvail)
    zltObj._context.SetParams("exParams", "takeFeeType", takeFeeType)

def init_trade_info(stashNumber, initial_cash):
    """初始化交易账户"""
    for i in ["stock_cost", "futures_cost", "bond_cost", "fund_cost"]:
        zltObj._context.SetParams(
            "exParams",
            i + "_securityOpenRateAmt",
            str(zltObj._context.backtest_param[i]["securityOpenRateAmt"]),
        )
        zltObj._context.SetParams(
            "exParams",
            i + "_securityOpenRateCount",
            str(zltObj._context.backtest_param[i]["securityOpenRateCount"]),
        )
        zltObj._context.SetParams(
            "exParams",
            i + "_securityCloseRateAmt",
            str(zltObj._context.backtest_param[i]["securityCloseRateAmt"]),
        )
        zltObj._context.SetParams(
            "exParams",
            i + "_securityCloseRateCount",
            str(zltObj._context.backtest_param[i]["securityCloseRateCount"]),
        )
        zltObj._context.SetParams(
            "exParams",
            i + "_securityCloseTodayRate",
            str(zltObj._context.backtest_param[i]["securityCloseTodayRate"]),
        )
        zltObj._context.SetParams(
            "exParams",
            i + "_securityCloseTodayCount",
            str(zltObj._context.backtest_param[i]["securityCloseTodayCount"]),
        )
        zltObj._context.SetParams(
            "exParams",
            i + "_securityStampRate",
            str(zltObj._context.backtest_param[i]["securityStampRate"]),
        )
        zltObj._context.SetParams(
            "exParams",
            i + "_minCommission",
            str(zltObj._context.backtest_param[i]["minCommission"]),
        )
        zltObj._context.SetParams(
            "exParams",
            i + "_securityTransferRate",
            str(zltObj._context.backtest_param[i]["securityTransferRate"]),
        )
        if i == "futures_cost":
            zltObj._context.SetParams(
                "exParams",
                i + "_futuresMarginRate",
                str(zltObj._context.backtest_param[i]["futuresMarginRate"]),
            )

def trade_order(
    code,
    market,
    amount=0,
    price=0,
    order_type=0,
    action=0,
    order_wtlb=2,
    value=0,
    side="long",
    combHedgeFlag="1",
    offsetFlag="2",
    pindex=0,
):
    """提交委托
    - action 0买 1卖
    - order_type
        0或空:普通类型的委托单
        1 order_value(指定目标价值 委托)
        2 order_target(期望的最终数量 委托)
        3 order_target_value(期望的标的最终价值 委托)
    - orderWtlb
        2市价
        1限价
    """
    strategyId = zltObj._context.strategy_info["strategy_id"]
    fundAccid = zltObj._context.strategy_info["fund_account"]
    orderTime = int(zltObj._context.current_dt.timestamp())
    fundType = str(1)  # 1 股票 2 期货
    offsetFlag = "2" if offsetFlag else "1"  #  1 平今 2 平昨
    tradeMode = "1" if side == "long" else "2"  # 1 多 2 空
    ccyCd = str(0)
    result = strategy_bridge.TradeOrderB(
        strategyId,
        fundAccid,
        fundType,
        orderTime,
        market,
        str(order_type),
        str(order_wtlb),
        ccyCd,
        str(price),
        str(amount),
        str(action),
        tradeMode,
        str(value),
        code,
        combHedgeFlag,
        offsetFlag,
    )
    return result


def trade_order_etf(etf_code, amount, trade_type, cash_list, stock_list, pindex=0):
    strategyId = zltObj._context.strategy_info["strategy_id"]
    fundAccid = zltObj._context.strategy_info["fund_account"]
    orderTime = int(zltObj._context.current_dt.timestamp())
    fundType = str(1)  # 1 股票 2 期货
    secType = str(1)  # 1 股票 2 期货
    result = strategy_bridge.TradeOrderEtf(
        strategyId,
        fundAccid,
        etf_code,
        amount,
        trade_type,
        ",".join(cash_list),
        ",".join(stock_list),
        orderTime,
        fundType,
        secType,
    )
    return result


def today_all_entrust_pb(sec_code=None, time=None):
    """获取今日所有委托记录

    参数:
        sec_code:查询特定股票今日的委托记录
    """
    date = int(time.timestamp()) if time else int(zltObj._context.current_dt.timestamp())
    strategyId = zltObj._context.strategy_info["strategy_id"]
    fundAccid = zltObj._context.strategy_info["fund_account"]
    fundType = str(1)  # 1 股票 2 期货
    secType = str(1)  # 1 股票 2 期货
    result = strategy_bridge.TradeQryCollentB(
        strategyId, fundAccid, fundType, secType, sec_code if sec_code else "", 0, date
    )
    return result


def get_daily_asset_pb():
    """获取账户可用资金"""
    strategyId = zltObj._context.strategy_info["strategy_id"]
    fundAccid = zltObj._context.strategy_info["fund_account"]
    tradeTime = int(zltObj._context.current_dt.timestamp())
    fundType = str(1)  # 1 股票 2 期货
    secType = str(1)  # 1 股票 2 期货
    data = strategy_bridge.TradeQryAssetsBForUser(
        strategyId, fundAccid, fundType, secType, tradeTime
    )
    if len(data) == 0:
        raise Exception("获取资产失败")
    openBal = data[0]["available_cash"]
    market_value = data[0]["total_value"] - data[0]["available_cash"]
    zltObj._context.market_value_daily.append(market_value)
    return openBal


def get_today_trades():
    # 获取当天的所有成交记录, 一个订单可能分多次成交
    orderTime = int(zltObj._context.current_dt.timestamp())
    strategyId = zltObj._context.strategy_info["strategy_id"]
    fundAccid = zltObj._context.strategy_info["fund_account"]
    fundType = str(1)  # 1 股票 2 期货
    secType = str(1)  # 1 股票 2 期货
    data = strategy_bridge.TradeQryTrnTradeB(
        orderTime, strategyId, fundAccid, fundType, secType
    )
    result = {}
    for item in data:
        result[item["tradeId"].decode()] = Trade(
            datetime.fromtimestamp(int(item["tradeTime"].decode())),
            item["secCd"].decode(),
            int(item["tradeQty"]),
            float(item["tradePrice"]),
            item["tradeId"].decode(),
            item["orderId"].decode(),
        )
    return result


def cancel_entrust(order_id, pindex):
    """撤单"""
    orderTime = int(zltObj._context.current_dt.timestamp())
    strategyId = zltObj._context.strategy_info["strategy_id"]
    fundAccid = zltObj._context.strategy_info["fund_account"]
    fundType = str(1)  # 1 股票 2 期货
    secType = str(1)  # 1 股票 2 期货
    result = strategy_bridge.TradeCancel(
        orderTime, strategyId, fundAccid, fundType, secType, order_id
    )
    return result


def cancel_all_entrust(order_time):
    """全部撤单"""
    strategyId = zltObj._context.strategy_info["strategy_id"]
    fundAccid = zltObj._context.strategy_info["fund_account"]
    fundType = str(1)  # 1 股票 2 期货
    secType = str(1)  # 1 股票 2 期货
    result = strategy_bridge.TradeCancelAll(
        order_time, strategyId, fundAccid, fundType, secType
    )
    return result


def set_account_cash(cash, pindex):
    """资金调整"""
    orderTime = int(zltObj._context.current_dt.timestamp())
    strategyId = zltObj._context.strategy_info["strategy_id"]
    fundAccid = zltObj._context.strategy_info["fund_account"]
    fundType = str(1)  # 1 股票 2 期货
    secType = str(1)  # 1 股票 2 期货
    handleOpt = 2 if cash > 0 else 1
    cashAmt = cash
    data = strategy_bridge.TradeSetAccountCash(
        orderTime, strategyId, fundAccid, fundType, secType, handleOpt, cashAmt
    )
    if data["errMsg"]["status"] == b"S":
        update_cash_info()
        pass
    return data


def get_trade_detail(pindex, order_id):
    """订单详情

    参数:
    - pindex : 子账号
    - order_id: 订单id

    返回:
    order
    """
    pass

__all__ = [
    "init_trade_info",
    "init_trade_setting",
    "get_daily_asset_pb"
]