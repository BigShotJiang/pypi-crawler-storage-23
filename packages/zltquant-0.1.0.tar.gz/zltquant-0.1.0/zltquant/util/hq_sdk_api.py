import zltsdk.strategy_bridge as strategy_bridge
from .zlt_util import param_to_dt
from . import zlt_object as zltObj


class Bar:
    def __init__(self, last_price, high_limit, low_limit, paused, is_st, day_open, name, industry_code, pre_close, iopv) -> None:
        self.last_price = last_price # 最新价
        self.high_limit = high_limit #涨停价
        self.low_limit = low_limit # 跌停价
        self.paused = paused # 是否停牌
        self.is_st = is_st # 是否st
        self.pre_close = pre_close # 昨收价
        self.day_open = day_open # 当天开盘价
        self.name = name # 股票名称

        self.industry_code = industry_code
        self.iopv = iopv

    def __str__(self) -> str:
        return f"Bar(name={self.name},last_price={self.last_price},high_limit={self.high_limit},low_limit={self.low_limit},paused={self.paused},is_st={self.is_st},day_open={self.day_open},pre_close={self.pre_close},iopv={self.iopv})"

    def __repr__(self) -> str:
        return f"Bar(name={self.name},last_price={self.last_price},high_limit={self.high_limit},low_limit={self.low_limit},paused={self.paused},is_st={self.is_st},day_open={self.day_open},pre_close={self.pre_close},iopv={self.iopv})"


class SecurityInfo():
    def __init__(self, display_name, start_date, end_date, type, security) -> None:
        # 展示名称
        self.display_name = display_name
        # 上市时间
        self.start_date = start_date
        # 退市时间
        self.end_date = end_date
        # 股票类型
        self.type = type
        # 股票代码
        self.security = security

    def __str__(self) -> str:
        return f"SecurityInfo(security='{self.security}',display_name='{self.display_name}',start_date='{self.start_date}',end_date={self.end_date},type={self.type})"

def query_price(codes, date=None):
    """获取股票行情
    """
    timestamp = 0
    if date is None:
        timestamp = int(zltObj._context.current_dt.timestamp())
    else:
        timestamp = int(param_to_dt(date).timestamp())
    result = strategy_bridge.get_current_data(codes, timestamp)
    return result