def neutralize(series, how=None, date=None, axis=1, fillna=None, add_constant=False):
    """中性化
    
    参数:
    - data: pd.Series/pd.DataFrame , 待中性化的序列，序列的 index 为股票的 code
    - how: str list 。中性化使用的因子名称列表。
      财务数据：如 'market_cap', 'net_profit'等；也可以输入对数市值'ln_market_cap' 和 对数流通市值 'ln_circulating_market_cap';
      行业数据：可输入行业分类代码（如 'jq_l1', 'sw_l1'）或行业代码（如 'HY001'）
      风险因子：可以使用的风险因子包括： ['size', 'beta', 'momentum', 'residual_volatility', 'non_linear_size', 'book_to_price_ratio', 'liquidity', 'earnings_yield', 'growth', 'leverage']
      fillna: 缺失值填充方式
      add_constant: 中性化时是否添加常数项, 默认为 False
    - date 日期
    Return: 
    中性化后的因子数据
    """    
    return

def winsorize(series, scale=None, range=None, qrange=None, inclusive=True, inf2nan=True, axis=1):
    """
    去极值

    参数:
    data: pd.Series/pd.DataFrame/np.array, 待缩尾的序列
    scale: 标准差倍数，与 range,qrange 三选一，不可同时使用。会将位于 [mu - scale * sigma, mu + scale * sigma] 边界之外的值替换为边界值
    range: 列表， 缩尾的上下边界。与 scale,qrange 三选一，不可同时使用。
    qrange: 列表，缩尾的上下分位数边界，值应在 0 到 1 之间，如 [0.05, 0.95]。与 scale,range 三选一，不可同时使用。
    inclusive: 是否将位于边界之外的值替换为边界值，默认为 True。如果为 True,则将边界之外的值替换为边界值,否则则替换为 np.nan
    inf2nan: 是否将 np.inf 和 -np.inf 替换成 np.nan,默认为 True如果为 True,在缩尾之前会先将 np.inf 和 -np.inf 替换成 np.nan,缩尾的时候不会考虑 np.nan,否则 inf 被认为是在上界之上，-inf 被认为在下界之下
    axis: 在 data 为 pd.DataFrame 时使用，沿哪个方向做标准化，默认为 1。 0 为对每列做缩尾,1 为对每行做缩尾。
    """    
    return

def winsorize_med(series, scale=1, inclusive=True, inf2nan=True, axis=1):
    """
    中位数去极值
    
    data: pd.Series/pd.DataFrame/np.array, 待缩尾的序列
    scale: 倍数，默认为 1.0。会将位于 [med - scale * distance, med + scale * distance] 边界之外的值替换为边界值/np.nan
    inclusive bool 是否将位于边界之外的值替换为边界值，默认为 True。 如果为 True，则将边界之外的值替换为边界值，否则则替换为 np.nan
    inf2nan: 是否将 np.inf 和 -np.inf 替换成 np.nan，默认为 True。如果为 True，在缩尾之前会先将 np.inf 和 -np.inf 替换成 np.nan，缩尾的时候不会考虑 np.nan，否则 inf 被认为是在上界之上，-inf 被认为在下界之下
    axis: 在 data 为 pd.DataFrame 时使用，沿哪个方向做标准化，默认为 1。0 为对每列做缩尾，1 为对每行做缩尾

    """    
    return

def standardlize(series, inf2nan=True, axis=1):
    """
    标准化(z-score)

    参数:
    data: pd.Series/pd.DataFrame/np.array, 待标准化的序列
    inf2nan: 是否将 np.inf 和 -np.inf 替换成 np.nan。默认为 True
    axis=1: 在 data 为 pd.DataFrame 时使用，如果 series 为 pd.DataFrame，沿哪个方向做标准化。0 为对每列做标准化，1 为对每行做标准化
    
    """
    
    return 