"""
其他工具函数
"""

import zltsdk.strategy_bridge as strategy_bridge
import json
from . import zlt_object as zltObj
import os
import sys
from urllib.request import urlopen, Request


def record(**kwargs):
    """画图函数"""
    pass


def send_message(message, channel="wx"):
    """发送自定义消息"""
    if channel == "wx":
        url = "http://192.168.1.10:3000/zltBusiness/strategy/send-template-message-by-strid"

    # 准备 POST 数据（字典格式）
    data = {
        "strategy_id": "ST-7A2003ED-B52E-43C9-94ED-F9F03D086F0C",
        "strategy_name": "测试策略",
        "event_type": message,
        "adjust_time": "2025-07-16",
    }

    # 1. 转成 JSON 字符串
    json_data = json.dumps(data)

    # 2. 编码为 bytes
    encoded_data = json_data.encode("utf-8")

    # 3. 创建请求对象，并添加请求头 Content-Type
    headers = {"Content-Type": "application/json"}

    req = Request(url, data=encoded_data, method="POST", headers=headers)

    # 3. 发送请求并获取响应
    with urlopen(req) as response:
        # 读取响应内容（bytes），并解码为字符串
        response_text = response.read().decode("utf-8")
        print(response_text)
    pass


def write_file(path, content, append=False):
    """将回测或模拟交易数据写入到投资研究文件中"""
    pass


def read_file(path):
    """在回测或者模拟交易中读取您研究中文件"""
    pass


def create_backtest(
    algorithm_id,
    start_date,
    end_date,
    frequency="day",
    initial_cash=10000,
    initial_positions=None,
    extras=None,
    name=None,
    code="",
    benchmark=None,
    python_version=2,
    use_credit=False,
):
    """通过一个策略ID从研究中创建回测，只能在研究中使用，目前不支持在回测及模拟交易中使用

    参数:
    - algorithm_id: 策略ID
    - start_date: 回测开始日期
    - end_date: 回测结束日期
    - frequency: 数据频率，支持 day, minute, tick
    - initial_cash: 初始资金
    - extras: 额外参数，一个 dict， 用于设置全局的 g 变量，如 extras={'x':1, 'y':2}，则回测中 g.x = 1, g.y = 2，需要注意的是，该参数的值是
    在 initialize 函数执行之后
    才设置给 g 变量的，所以这会覆盖掉 initialize 函数中 g 变量同名属性的值
    - name: 回测名, 用于指定回测名称, 如果没有指定则默认采用策略名作为回测名
    - initial_positions: 初始持仓。持仓会根据价格换成现金加到初始资金中，如果没有给定价格则默认获取股票最近的价格
        initial_positions = [
        {
            'security':'000001.XSHE',
            'amount':'100',
        },
        {
            'security':'000063.XSHE',
            'amount':'100',
            'avg_cost': '1.0'
        },
        ]
    - code：策略代码。现在支持从研究中传入策略代码进行回测。指定之后将使用传入的代码来创建回测。
    - benchmark: 为回测设置基准。默认为None，表示使用策略中原有set_benchmark设置的基准。若不为None，则表示使用当前传入的基准覆盖原策略的基准。benchmark支持的基准同set_benchmark
    - python_version: 创建回测的python的版本，2或者3，默认为2(python2);注意客户端没有这个参数，默认python3的
    - use_credit:是否允许消耗积分新建回测。当每个自然日内编译运行、回测超过免费时间时，继续运行每30分钟需消耗2积分。默认为False，表示不允许消耗积分新建回测，设为True表示接受消耗积分新建回测。需注意，对于已经在运行中的回测，此配置不生效。
    """
    pass


def get_backtest(backtest_id):
    """研究中获取回测与模拟交易信息"""
    pass


def normalize_code():
    """股票代码格式转换"""
    pass


def enable_profile():
    """性能分析"""
    pass


class Log:
    """日志类"""

    def __init__(self) -> None:
        self.log = None

    def init_context(self, log_obj, is_py_log=False, logs_path="", log_level=3):
        self.log = log_obj()
        self.log_level = log_level
        if is_py_log:
            try:
                # py系统策略日志地址初始化
                self.log.Init(
                    strategy_bridge.ZLogLevel.INFO,
                    f"{logs_path}/{zltObj._context.strategy_info['backtest_id']}/strategy_py.log",
                    True,
                )
            except:
                # 回测时，py系统策略日志地址初始化
                print("py系统策略日志地址初始化失败！")
        else:
            try:
                # 用户日志地址初始化
                current_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
                current_dir = current_dir.replace("\\", "\\\\")
                self.log.Init(
                    strategy_bridge.ZLogLevel.TRACE,
                    f"{current_dir}/log/{zltObj._context.strategy_info['backtest_id']}/strategy_user.log",
                    False,
                )
            except:
                # 回测时，用户日志地址初始化
                print("用户日志地址初始化失败！")

    def error(self, *args):
        """错误级别"""
        if "log_level" in self.__dict__ and self.log_level < 6:
            content = []
            for arg in args:
                if isinstance(arg, list):
                    content.append(json.dumps(arg, ensure_ascii=False))
                elif isinstance(arg, object):
                    content.append(str(arg))
                else:
                    content.append(arg)
            self.log.Print(
                strategy_bridge.ZLogLevel.ERR,
                f'[\033[31m{zltObj._context.current_dt.strftime("%Y-%m-%d %H:%M:%S")}\033[37m]'
                + (",").join(content),
            )
        pass

    def warn(self, *args):
        """警告级别"""
        if "log_level" in self.__dict__ and self.log_level < 5:
            content = []
            for arg in args:
                if isinstance(arg, list):
                    content.append(json.dumps(arg, ensure_ascii=False))
                elif isinstance(arg, object):
                    content.append(str(arg))
                else:
                    content.append(arg)
            self.log.Print(
                strategy_bridge.ZLogLevel.WARN,
                f'[\033[33m{zltObj._context.current_dt.strftime("%Y-%m-%d %H:%M:%S")}\033[37m]'
                + (",").join(content),
            )
        pass

    def info(self, *args):
        """info级别"""
        if "log_level" in self.__dict__ and self.log_level < 4:
            content = []
            for arg in args:
                if isinstance(arg, list):
                    content.append(json.dumps(arg, ensure_ascii=False))
                elif isinstance(arg, object):
                    content.append(str(arg))
                else:
                    content.append(arg)
            self.log.Print(
                strategy_bridge.ZLogLevel.INFO,
                (
                    f'[\033[32m{zltObj._context.current_dt.strftime("%Y-%m-%d %H:%M:%S")}\033[37m]'
                    + (",").join(content)
                ).encode(),
            )
        pass

    def debug(self, *args):
        """debug级别"""
        if "log_level" in self.__dict__ and self.log_level < 3:
            content = []
            for arg in args:
                if isinstance(arg, list):
                    content.append(json.dumps(arg, ensure_ascii=False))
                elif isinstance(arg, object):
                    content.append(str(arg))
                else:
                    content.append(arg)
            self.log.Print(
                strategy_bridge.ZLogLevel.INFO,
                (
                    f'[\033[32m{zltObj._context.current_dt.strftime("%Y-%m-%d %H:%M:%S")}\033[37m]'
                    + (",").join(content)
                ).encode(),
            )
            pass

    def set_level(self, level):
        """设置级别
        history: 调用history系列API(history/attribute_history/get_price)产生的log
        strategy: 您自己在策略代码中打的log
        system:系统日志,除以上三类之外的日志
        """
        if level == "error":
            self.log_level = 5
        elif level == "debug":
            self.log_level = 2
        elif level == "warn":
            self.log_level = 4
        elif level == "info":
            self.log_level = 3
        elif level == "off":
            self.log_level = 6


log = Log()
system_log = Log()
