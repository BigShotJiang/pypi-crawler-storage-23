'''
交易相关函数
'''
from . import zlt_object as zltObj
from .zlt_object import (
    OrderStatus,
    MarketOrderStyle,
    LimitOrderStyle,
    Order,
    update_cash_info,
)
from .node_api import record_single
from .zlt_util import ENTRUST_STATUS, ORDER_ACTION
from .zlt_others import log
from .trade_sdk_api import (
    get_trade_detail,
    today_all_entrust_pb,
    trade_order,
    trade_order_etf,
    get_today_trades,
    cancel_entrust,
    set_account_cash,
    cancel_all_entrust,
)
from datetime import datetime


def order(
    security: str,
    amount: int,
    style=MarketOrderStyle(0),
    side="long",
    close_today=False,
    pindex=0,
):
    """买卖标的

    参数:
    - security:标的代码
    - amount:交易数量，正数表示买入，负数表示卖出
    - style:MarketOrder/LimitOrder(市价/限价);默认是marketOrder
    - side:'long'/'short'，操作多单还是空单。默认为多单，股票不支持开空单
    - close_today:平今字段(期货有效)
    - pindex(暂未支持,待定)

    返回:
    - 成功:订单id
    - 失败:None
    """
    # 买卖方向：0买，1卖
    action = 1 if amount < 0 else 0
    isMarketOrder = isinstance(style, MarketOrderStyle)
    tradeType = "市价单" if isMarketOrder else "限价单"
    tradePrice = "0" if isMarketOrder else style.limit_price
    t_type = ""
    if action == 0:
        if side == "long":
            t_type = "({}),订单类型:{},买入开多-数量{}".format(
                security, tradeType, abs(amount)
            )
        else:
            t_type = "({}),订单类型:{},买入开空-数量{}".format(
                security, tradeType, abs(amount)
            )
    else:
        if side == "long":
            t_type = "({}),订单类型:{},卖出平多-数量{}".format(
                security, tradeType, abs(amount)
            )
        else:
            t_type = "({}),订单类型:{},卖出平空-数量{}".format(
                security, tradeType, abs(amount)
            )
    if not isMarketOrder:
        t_type += ",保护限价:{}".format(style.limit_price)
    record_single(
        zltObj._context,
        security,
        t_type,
        "",
        tradeType,
        tradePrice,
        abs(amount),
    )
    # 订单类型：1限价，2市价
    order_wtlb = 2 if isMarketOrder else 1
    anMsg = trade_order(
        code=security,
        market=security[:2],
        amount=abs(amount),
        price=style.limit_price,
        order_type=0,
        action=action,
        order_wtlb=order_wtlb,
        side=side,
        offsetFlag=close_today,
    )
    if anMsg[0]["errMsg"]["status"] == b"S":
        update_cash_info()
        log.info(f"委托成功, 委托号: {anMsg[0]['orderId'].decode()}")
        return anMsg[0]["orderId"].decode()
    else:
        log.error(security + anMsg[0]["errMsg"]["text"].decode())
        return None


def order_etf(
    etf_code, amount=0, trade_type="esg", cash_list=[], stock_list=[], pindex=0
):
    _trade_type = "4"
    if trade_type == "ehh":
        _trade_type = "5"
    _cash_list = [str(i) for i in cash_list]
    _amount = str(amount)
    trade_order_etf(etf_code, _amount, _trade_type, _cash_list, stock_list)


def order_target(
    security: str,
    amount: int,
    style=MarketOrderStyle(0),
    side="long",
    close_today=False,
    pindex=0,
):
    """买卖标的, 使最终标的的数量达到指定的amount

    参数:
    - security:标的代码
    - amount:期望的最终数量
    - style:MarketOrder/LimitOrder(市价/限价);默认是marketOrder
    - side:'long'/'short'，操作多单还是空单。默认为多单，股票、基金暂不支持开空单
    - pindex(暂未支持,待定)
    - close_today:平今字段

    返回:
    - 成功:订单id
    - 失败:None
    """
    # 买卖方向：0买，1卖
    update_cash_info()
    if amount < 0:
        raise Exception("下单数量不能小于0")
    current_num = zltObj._context.portfolio.positions[security].total_amount
    action = 1 if (amount - current_num) <= 0 else 0
    isMarketOrder = isinstance(style, MarketOrderStyle)
    tradeType = "市价单" if isMarketOrder else "限价单"
    tradePrice = "0" if isMarketOrder else style.limit_price
    t_type = ""
    if action == 0:
        if side == "long":
            t_type = "({}),订单类型:{},买入开多-目标持仓{}".format(
                security, tradeType, abs(amount)
            )
        else:
            t_type = "({}),订单类型:{},买入开空-目标持仓{}".format(
                security, tradeType, abs(amount)
            )
    else:
        if side == "long":
            t_type = "({}),订单类型:{},卖出平多-目标持仓{}".format(
                security, tradeType, abs(amount)
            )
        else:
            t_type = "({}),订单类型:{},卖出平空-目标持仓{}".format(
                security, tradeType, abs(amount)
            )
    if not isMarketOrder:
        t_type += ",保护限价:{}".format(style.limit_price)
    if current_num == amount:
        t_type = "({}),当前目标数量与当前持仓数量相同"
    record_single(
        zltObj._context,
        security,
        t_type,
        "",
        tradeType,
        tradePrice,
        0,
    )
    if security.startswith("sh688") and style.limit_price == 0:
        log.warn(f"科创板标的需要输入保护限价,进行下单")
        return
    # 订单类型：1限价，2市价
    order_wtlb = 2 if isMarketOrder else 1
    anMsg = trade_order(
        code=security,
        market=security[:2],
        amount=amount,
        price=style.limit_price,
        order_type=2,
        action=action,
        order_wtlb=order_wtlb,
        side=side,
        offsetFlag=close_today,
    )
    if anMsg[0]["errMsg"]["status"] == b"S":
        update_cash_info()
        log.info(f"委托成功, 委托号: {anMsg[0]['orderId'].decode()}")
        return anMsg[0]["orderId"].decode()
    else:
        log.error(security + anMsg[0]["errMsg"]["text"].decode())
        return None


def order_value(
    security: str,
    value: float,
    style=MarketOrderStyle(0),
    side="long",
    close_today=False,
    pindex=0,
):
    """买卖价值为value的标的

    参数:
    - security:标的代码
    - value:标的价值
    - style:MarketOrder/LimitOrder(市价/限价);默认是marketOrder
    - side:'long'/'short'，操作多单还是空单。默认为多单，股票、基金暂不支持开空单
    - pindex(暂未支持,待定)
    - close_today:平今字段

    返回:
    - 成功:订单id
    - 失败:None
    """

    # 买卖方向：0买，1卖
    action = 1 if value < 0 else 0
    isMarketOrder = isinstance(style, MarketOrderStyle)
    tradeType = "市价单" if isMarketOrder else "限价单"
    tradePrice = "0" if isMarketOrder else style.limit_price
    t_type = ""
    if action == 0:
        if side == "long":
            t_type = "标的{}, 订单类型{}, 买入开多-金额{}".format(
                security, tradeType, abs(value)
            )
        else:
            t_type = "标的{}, 订单类型{}, 买入开空-金额{}".format(
                security, tradeType, abs(value)
            )
    else:
        if side == "long":
            t_type = "标的{}, 订单类型{}, 卖出平多-金额{}".format(
                security, tradeType, abs(value)
            )
        else:
            t_type = "标的{}, 订单类型{}, 卖出平空-金额{}".format(
                security, tradeType, abs(value)
            )
    if not isMarketOrder:
        t_type += ",保护限价:{}".format(style.limit_price)
    record_single(
        zltObj._context,
        security,
        t_type,
        "",
        tradeType,
        tradePrice,
        0,
    )
    if security.startswith("sh688") and style.limit_price == 0:
        log.warn(f"科创板标的需要输入保护限价,进行下单")
        return
    # 订单类型：1限价，2市价
    order_wtlb = 2 if isMarketOrder else 1
    anMsg = trade_order(
        code=security,
        market=security[:2],
        price=style.limit_price,
        order_type=1,
        action=action,
        order_wtlb=order_wtlb,
        value=abs(value),
        side=side,
        offsetFlag=close_today,
    )
    if anMsg[0]["errMsg"]["status"] == b"S":
        update_cash_info()
        log.info(f"委托成功, 委托号: {anMsg[0]['orderId'].decode()}")
        return anMsg[0]["orderId"].decode()
    else:
        log.error(security + anMsg[0]["errMsg"]["text"].decode())
        return None


def order_target_value(
    security: str,
    value: float,
    style=MarketOrderStyle(0),
    side="long",
    close_today=False,
    pindex=0,
):
    """调整标的仓位到value价值,注意使用此接口下单时若指定的标的有未完成的订单,则先前未完成的订单将会被取消

    参数:
    - security:标的代码
    - value:目标价值
    - style:MarketOrder/LimitOrder(市价/限价);默认是marketOrder
    - side:'long'/'short'，操作多单还是空单。默认为多单，股票、基金暂不支持开空单
    - pindex(暂未支持,待定)
    - close_today:平今字段

    返回:
    - 成功:订单id
    - 失败:None
    """
    # 买卖方向：0买，1卖
    action = 1 if value < 0 else 0
    isMarketOrder = isinstance(style, MarketOrderStyle)
    tradeType = "市价" if isMarketOrder else "限价"
    tradePrice = "0" if isMarketOrder else style.limit_price
    t_type = ""
    if action == 0:
        if side == "long":
            t_type = "({}), 订单类型{}, 买入开多-目标持仓金额{}".format(
                security, tradeType, abs(value)
            )
        else:
            t_type = "({}), 订单类型{}, 买入开空-目标持仓金额{}".format(
                security, tradeType, abs(value)
            )
    else:
        if side == "long":
            t_type = "({}), 订单类型{}, 卖出平多-目标持仓金额{}".format(
                security, tradeType, abs(value)
            )
        else:
            t_type = "({}), 订单类型{}, 卖出平空-目标持仓金额{}".format(
                security, tradeType, abs(value)
            )
    if not isMarketOrder:
        t_type += ",保护限价:{}".format(style.limit_price)
    record_single(
        zltObj._context,
        security,
        t_type,
        "",
        tradeType,
        tradePrice,
        0,
    )
    if security.startswith("688") and style.limit_price == 0:
        log.warn(f"科创板标的需要输入保护限价,进行下单。")
        return
    # 订单类型：1限价，2市价
    order_wtlb = 2 if isMarketOrder else 1
    anMsg = trade_order(
        code=security,
        market=security[:2],
        price=style.limit_price,
        order_type=3,
        action=action,
        order_wtlb=order_wtlb,
        value=abs(value),
        side=side,
        offsetFlag=close_today,
    )
    if anMsg[0]["errMsg"]["status"] == b"S":
        update_cash_info()
        log.info(f"委托成功, 委托号: {anMsg[0]['orderId'].decode()}")
        return anMsg[0]["orderId"].decode()
    else:
        log.error(security + anMsg[0]["errMsg"]["text"].decode())
        return None


def change_status_to_enum(status: str):
    """将zlt的状态字段转为OrderStatus枚举类型"""
    if status == "prepare":
        return OrderStatus.prepare
    elif status == "already":
        return OrderStatus.already
    elif status == "cancel":
        return OrderStatus.cancel
    elif status == "share":
        return OrderStatus.share
    elif status == "unfilled":
        return OrderStatus.unfilled
    elif status == "partially_filled":
        return OrderStatus.partially_filled
    elif status == "partially_cancelled":
        return OrderStatus.partially_cancelled
    elif status == "cancelled":
        return OrderStatus.cancelled
    elif status == "filled":
        return OrderStatus.filled


def cancel_order(order):
    """撤单

    参数:
    - order: [Order]对象 | order_id
    """
    order_id = order.order_id
    pindex = 0
    data = cancel_entrust(order_id, pindex)
    if len(data) > 0 and data["errMsg"]["status"] == b"S":
        update_cash_info()
        info = get_trade_detail(pindex, order_id)
        order_info = info["data"][0]
        security = order_info["secCd"]
        if order_info["orderWtlb"] == 1:
            style = LimitOrderStyle(limit_price=order_info["orderPrice"])
        else:
            style = MarketOrderStyle(0)
        status = change_status_to_enum(
            ENTRUST_STATUS[order_info["orderStatus"].decode()]
        )
        ret = Order(
            status=status,
            add_time=datetime.fromtimestamp(int(order_info["orderDate"].decode())),
            amount=order_info["orderQty"].decode(),
            filled=order_info["tradedQty"].decode(),
            security=security.decode(),
            order_id=order_info["orderId"].decode(),
            price=float(order_info["successPrice"].decode()),
            side="long" if order_info["offsetFlag"] == b"1" else "short",
            action=ORDER_ACTION[order_info["orderSide"].decode()],
            commission=order_info["feeAmt"].decode(),
            style=style,
            pIndex=pindex,
        )
        return ret
    else:
        log.error(order_id + "撤单失败!")
        return None


def cancel_all_order() -> bool:
    """撤掉所有订单"""
    order_time = int(zltObj._context.current_dt.timestamp())
    data = cancel_all_entrust(order_time)
    if len(data) > 0 and data["errMsg"]["status"] == b"S":
        update_cash_info()
        return True
    else:
        log.error("撤销所有订单失败!")
        return False


def get_open_orders():
    """获取当天的所有未完成的订单"""
    data = today_all_entrust_pb()
    data = data[data["orderStat"] != b"9"]
    data = data[data["orderStat"] != b"8"]
    data = data[data["orderStat"] != b"4"]
    data = data[data["orderStat"] != b"3"]
    ret = {}
    for entrust in data:
        security = entrust["secCd"]
        if entrust["orderWtlb"] == b"1":
            style = LimitOrderStyle(limit_price=(float(entrust["orderPrice"].decode())))
        else:
            style = MarketOrderStyle(0)
        # pindex = entrust["stashNumber"]
        status = change_status_to_enum(ENTRUST_STATUS[entrust["orderStat"].decode()])
        ret[entrust["orderId"].decode()] = Order(
            status=status,
            add_time=datetime.fromtimestamp(int(entrust["orderTime"].decode())),
            amount=entrust["orderQty"].decode(),
            filled=entrust["tradedQty"].decode(),
            security=security.decode(),
            order_id=entrust["orderId"].decode(),
            price=entrust["successPrice"].decode(),
            side="long" if entrust["offsetFlag"] == b"1" else "short",
            action=ORDER_ACTION[entrust["orderSide"].decode()],
            commission=entrust["commission"].decode(),
            style=style,
            profit=entrust["profitOutQrt"].decode(),
            pIndex=0,
        )
    return ret


def get_orders(order_id=None):
    """获取当天的所有订单

    参数:
    - order_id: 订单id,如果指定,则只返回指定订单信息,否则返回所有订单信息

    返回:
    - 成功: Order对象 | dict{key:订单id, value:Order对象}
    - 失败: None
    """
    sec_code = ""
    data = today_all_entrust_pb(sec_code=sec_code)

    if order_id:
        data = data[data["orderId"] == order_id.encode()]
        entrust = data[0]
        security = entrust["secCd"]
        if entrust["orderWtlb"] == b"1":
            style = LimitOrderStyle(limit_price=(float(entrust["orderPrice"].decode())))
        else:
            style = MarketOrderStyle(0)
        pindex = 0
        status = change_status_to_enum(ENTRUST_STATUS[entrust["orderStat"].decode()])
        return Order(
            status=status,
            add_time=datetime.fromtimestamp(int(entrust["orderTime"].decode())),
            amount=int(entrust["orderQty"].decode()),
            filled=int(entrust["tradedQty"].decode()),
            security=security.decode(),
            order_id=entrust["orderId"].decode(),
            price=float(entrust["successPrice"].decode()),
            side="long" if entrust["offsetFlag"] == b"1" else "short",
            action=ORDER_ACTION[entrust["orderSide"].decode()],
            commission=float(entrust["commission"].decode()),
            style=style,
            profit=float(entrust["profitOutQrt"].decode()),
            pIndex=pindex,
        )
    ret = {}
    for entrust in data:
        security = entrust["secCd"]
        if entrust["orderWtlb"] == b"1":
            style = LimitOrderStyle(limit_price=(float(entrust["orderPrice"].decode())))
        else:
            style = MarketOrderStyle(0)
        pindex = 0
        status = change_status_to_enum(ENTRUST_STATUS[entrust["orderStat"].decode()])
        ret[entrust["orderId"].decode()] = Order(
            status=status,
            add_time=datetime.fromtimestamp(int(entrust["orderTime"].decode())),
            amount=entrust["orderQty"].decode(),
            filled=entrust["tradedQty"].decode(),
            security=security.decode(),
            order_id=entrust["orderId"].decode(),
            price=float(entrust["successPrice"].decode()),
            side="long" if entrust["offsetFlag"] == b"1" else "short",
            action=ORDER_ACTION[entrust["orderSide"].decode()],
            commission=entrust["commission"].decode(),
            style=style,
            profit=float(entrust["profitOutQrt"].decode()),
            pIndex=pindex,
        )
    return ret


def get_trades():
    """获取当天成交订单"""
    data = get_today_trades()
    return data


def inout_cash(cash, pindex=0):
    """账户转入或转出资金,当日的出入金从当日开始记入成本,用于计算收益,即当日结束计算收益时的本金是包含当日出入金金额的；

    参数:
    - cash: 可正可负,正为入金,负为出金。
    - pindex: 在使用set_subportfolios创建了多个仓位时,指定subportfolio 的序号, 从 0 开始, 比如 0为 指定第一个 subportfolio, 1 为指定第二个 subportfolio,默认为0。
    """
    set_account_cash(cash, pindex)
    return


def batch_submit_orders(orders):
    """对一系列标的进行批量委托,委托时会对每一个委托进行验资验券,若其中任一个委托校验失败,则整个委托将会失败

    参数:
    - orders: 一个list,元素是包含订单信息的dict
    """
    tradeApi = zltObj._context.GetTradeApi()
    return


def batch_cancel_orders(orders):
    """对一系列标的进行批量委托,委托时会对每一个委托进行验资验券,若其中任一个委托校验失败,则整个委托将会失败

    参数:
    - orders: 一个list,元素是包含订单信息的dict
    """
    tradeApi = zltObj._context.GetTradeApi()
    return


__all__ = [
    "order",
    "order_etf",
    "order_target",
    "order_value",
    "order_target_value",
    "cancel_order",
    "get_open_orders",
    "get_orders",
    "get_trades",
    "inout_cash",
    "batch_submit_orders",
    "batch_cancel_orders",
    "cancel_all_order",
]
