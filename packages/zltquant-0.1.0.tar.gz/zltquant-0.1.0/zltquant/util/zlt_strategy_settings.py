'''
设置策略全局变量
'''
import json
from . import zlt_object as zltObj
from .zlt_object import OrderCost
from .zlt_util import fre_to_timestamp


def FixedSlippage(num):
    """固定滑点"""
    return {"type": 0, "value": num}


def FixedPercent(num):
    """百分比滑点"""
    return {"type": 1, "value": num}


def StepRelatedSlippage(num):
    """跳数滑点"""
    return {"type": 2, "value": num}

def set_sys_benchmark(security):
    """设置sdk系统回测时间轴参考基准

    参数:
    - security:标的
    - frequency:频率;支持Xm()/Xd()/Xw()/XM()/毫秒级数字 例如: 一分钟:'1m'/ 60 * 1000
    """
    # 不使用行情推送, 使用定时器驱动

    # 订阅标的的 tick 事件
    zltObj._context.sys_benchmark = security
    code = security
    frequency = zltObj._context.run_params.frequency
    zltObj._context.SetParams("exParams", "sys_benchmark", code)
    if frequency == "tick":
        zltObj._context.SetParams("exParams", "frequency", "3000")
    else:
        frequency = fre_to_timestamp(frequency, "mdwM")
        zltObj._context.SetParams("exParams", "frequency", str(frequency))
    # 回测驱动模式
    zltObj._context.SetParams("backtestParams", "driver_by_data", "0")


def set_benchmark(security):
    """设置基准

    参数:
    - security:股票/指数/ETF代码
    """
    if isinstance(security, str):
        _validate_a_stock_code(security, "benchmark")
        zltObj._context.backtest_param["benchmark"][security] = 1
    else:
        zltObj._context.backtest_param["benchmark"] = security
    zltObj._context.SetParams("backtestParams", "benchmark", security)


def _validate_a_stock_code(security, param_name="security"):
    """验证沪深A股代码格式

    参数:
    - security: 标的代码
    - param_name: 参数名称，用于错误提示

    沪深A股代码规则:
    - 沪市主板: 600xxx, 601xxx, 603xxx, 605xxx
    - 沪市科创板: 688xxx
    - 深市主板: 000xxx, 001xxx, 003xxx
    - 深市中小板: 002xxx
    - 深市创业板: 300xxx

    支持: 股票、指数、ETF基金
    """
    if not isinstance(security, str) or len(security) != 9:
        raise ValueError(f"{param_name}代码格式错误，应为9位字符(如'sz000001'), 当前值: {security}")

    prefix = security[:2].lower()
    code = security[2:]

    # 验证前缀
    if prefix not in ["sz", "sh"]:
        raise ValueError(f"{param_name}代码必须以'sz'或'sh'开头, 当前值: {security}")

    # 验证后7位是否为数字
    if not code.isdigit():
        raise ValueError(f"{param_name}代码后7位必须为数字, 当前值: {security}")

    # 验证是否符合沪深A股、指数、ETF的代码规则
    valid_prefixes = []

    # 沪市
    if prefix == "sh":
        # 沪市A股
        valid_prefixes.extend(["600", "601", "603", "605", "688"])  # 主板 + 科创板
        # 沪市指数
        valid_prefixes.extend(["000"])  # 如000001(上证指数)、000300(沪深300)
        valid_prefixes.extend(["888"])  # 如888001(上证指数)
        # 沪市ETF基金
        valid_prefixes.extend(["51", "56", "58", "59"])  # 如510300(沪深300ETF)、512000(券商ETF)

    # 深市
    if prefix == "sz":
        # 深市A股
        valid_prefixes.extend(["000", "001", "002", "003", "300"])  # 主板 + 中小板 + 创业板
        # 深市指数
        valid_prefixes.extend(["399"])  # 如399001(深证成指)、399006(创业板指)
        # 深市ETF基金
        valid_prefixes.extend(["15", "16", "159"])  # 如159919(沪深300ETF)、159915(创业板ETF)

    # 检查代码前缀是否有效
    is_valid = any(code.startswith(p) for p in valid_prefixes)

    if not is_valid:
        raise ValueError(f"{param_name}代码不符合沪深A股/指数/ETF规则, 当前值: {security}")

    return True


def set_order_cost(cost: OrderCost, type="stock", ref=None):
    """指定每笔交易要收取的手续费, 系统会根据用户指定的费率计算每笔交易的手续费

    参数:
    - cost:
        OrderCost 对象
            - open_tax:买入时印花税 (只股票类标的收取,基金与期货不收,目前由交易模块根据回测时间动态调整,设置后没有作用)
            - close_tax:卖出时印花税
            - open_commission:买入时佣金
            - close_commission, 卖出时佣金
            - close_today_commission, 平今仓佣金
            - min_commission, 最低佣金，不包含印花税
    - type:股票、场内基金、场内交易的货币基金、分级A基金、分级B基金、分级母基金、金融期货、期货、债券基金、股票基金、QDII 基金、混合基金，股票 'stock'/基金 'fund'/债券 'bond'/期货 'futures'
    - ref: 参考代码(暂不支持)
    """
    if type not in ["stock", "fund", "futures", "bond"]:
        raise ValueError("type仅支持 'stock', 'fund', 'futures', 'bond'")
    cost_type = {
        "stock": "stock_cost",
        "fund": "fund_cost",
        "futures": "futures_cost",
        "bond": "bond_cost",
    }
    zltObj._context.backtest_param[cost_type[type]]["securityOpenRateAmt"] = str(
        cost.open_commission
    )
    zltObj._context.backtest_param[cost_type[type]]["securityOpenRateCount"] = str(
        cost.open_fixed_commiission
    )
    zltObj._context.backtest_param[cost_type[type]]["securityCloseRateAmt"] = str(
        cost.close_commission
    )
    zltObj._context.backtest_param[cost_type[type]]["securityCloseRateCount"] = str(
        cost.close_fixed_commiission
    )
    zltObj._context.backtest_param[cost_type[type]]["securityCloseTodayRate"] = str(
        cost.close_today_commission
    )
    zltObj._context.backtest_param[cost_type[type]]["securityCloseTodayCount"] = str(
        cost.close_fixed_today_commiission
    )
    zltObj._context.backtest_param[cost_type[type]]["securityStampRate"] = str(cost.close_tax)
    zltObj._context.backtest_param[cost_type[type]]["minCommission"] = str(cost.min_commission)
    zltObj._context.backtest_param[cost_type[type]]["securityTransferRate"] = str(
        0
    )  # 已没有过户费


def set_slippage(object, type=None, ref=None):
    """设置滑点

    参数:
    - object:FixedSlippage,FixedPercent,StepRelatedSlippage
    - type:交易品种,支持股票、基金、金融期货、期货、债券基金、股票基金、QDII 基金、货币基金、混合基金,'stock'/ 'fund' / 'index_futures' （金融期货）/ 'futures'（包含股指期货和商品期货） / 'bond_fund' / 'stock_fund' / 'QDII_fund' / 'money_market_fund' / ‘mixture_fund' 。为None时则应用于全局。当type被设定而ref为None时,表示将滑点应用于交易品种为type的所有交易标的。
    - ref: 标的代码。如要为特定交易标的单独设置滑点,必须同时设置type为交易标的的交易品种。
    """
    value = object["value"]
    type = object["type"]
    zltObj._context.backtest_param["slippage"] = value
    zltObj._context.SetParams("exParams", "slippage", str(value))
    zltObj._context.backtest_param["slippage_type"] = type
    zltObj._context.SetParams("exParams", "slippage_type", str(type))
    return


def set_option(mode, value):
    """设置策略参数

    参数:
        mode:order_volume_ratio 设定成交量比例，根据实际行情限制每个订单的成交量. value: value 是一个 float 值, 默认为1.0, 根据实际行情限制每个订单的成交量.
        mode:match_with_order_book  设定是否使用盘口撮合模式. 此选项只对模拟盘生效，默认关闭  value: True | False
        mode:avoid_future_data  设置回测是否开启避免未来数据模式，默认关闭 value: True | False
        mode:t0_mode T+0模式，A股买入后可以立刻卖出
        mode:always_match_market_order 总是撮合市价单，支持在非交易时间下市价单，按照最新的数据立即撮合
        mode:match_by_signal 强制撮合，仅支持限价单。使用限价单进行委托时将不对委托价格和成交数量进行任何检查而直接成交，当开启此设置项时，市价单的成交价也不会受滑点的影响
        mode:avoid_future_data 设置是否开启避免未来数据模式
        mode:margincash_interest_rate 设置融资利率
        mode:margincash_margin_rate 设置融资保证金比率
        mode:marginsec_interest_rate 设置融券利率
        mode:marginsec_margin_rate 设置融券保证金比率
        mode:futures_margin_rate 设置期货保证金比例
    """
    value = str(value)
    if mode == "order_volume_ratio":
        zltObj._context.backtest_param["order_volume_ratio"] = float(value)
    elif mode == "match_with_order_book":
        zltObj._context.backtest_param["match_with_order_book"] = value
    elif mode == "t0_mode":
        zltObj._context.backtest_param["t0_mode"] = value
    elif mode == "always_match_market_order":
        zltObj._context.backtest_param["always_match_market_order"] = value
    elif mode == "match_by_signal":
        zltObj._context.backtest_param["match_by_signal"] = value
    elif mode == "order_volume_ratio":
        zltObj._context.backtest_param["order_volume_ratio"] = value
    elif mode == "avoid_future_data":
        zltObj._context.backtest_param["avoid_future_data"] = value
    elif mode == "margincash_interest_rate":
        zltObj._context.backtest_param["margincash_interest_rate"] = value
    elif mode == "margincash_margin_rate":
        zltObj._context.backtest_param["margincash_margin_rate"] = value
    elif mode == "marginsec_interest_rate":
        zltObj._context.backtest_param["marginsec_interest_rate"] = value
    elif mode == "marginsec_margin_rate":
        zltObj._context.backtest_param["marginsec_margin_rate"] = value
    elif mode == "futures_margin_rate":
        zltObj._context.backtest_param["futures_margin_rate"] = value
        zltObj._context.backtest_param["futures_cost"]["futuresMarginRate"] = value


def set_universe(security_list):
    """股票池设置

    参数:
    - security_list: 股票列表
    """

    if isinstance(security_list, str):
        security_list = [security_list]
    if not isinstance(security_list, list):
        raise ValueError("security_list 必须为列表或字符串")
    zltObj._context.universe = tuple(security_list)
    zltObj._context.SetParams("backtestParams", "universe", json.dumps(security_list))


def disable_cache():
    """
    关闭缓存
    """
    pass


__all__ = [
    "set_benchmark",
    "set_order_cost",
    "set_slippage",
    "set_option",
    "set_universe",
    "disable_cache",
    "FixedSlippage",
    "FixedPercent",
    "StepRelatedSlippage",
]
