'''
策略定时器执行相关函数
'''
import zltsdk.strategy_bridge as strategy_bridge
from . import zlt_object as zltObj
from .zlt_util import param_to_dt

schedule = {}
week_schedule = {}
mon_schedule = {}
# 控制计时器声明
schedule_list = []
system_functions = {
    "handle_data": None,
    "on_bar": None,
    "handle_tick": None,
    "days_every_bar": [],
    "before_trading_start": {},
    "after_trading_end": {},
    "system_open_function": {},
    "system_morning_close_function": {},
    "system_morning_open_function": {},
    "system_reload_function": {},
    "system_close_function": {},
    "system_mid_open_function": {},
    "system_mid_close_function": {},
    "system_night_open_function": {},
    "system_night_close_function": {},
}


def set_time_task(func, security, add_task):
    times = strategy_bridge.GetTradeTimeRule(security, 0)
    if len(times) == 0:
        raise Exception("没有找到{}的交易时间规则".format(security))
    _times = [
        {"hour": int(time / 3600), "minute": int(time % 3600 / 60)} for time in times
    ]
    size = int(len(_times) / 2)
    for j in range(size):
        idx = j * 2
        beg = _times[idx]["hour"]
        end = _times[idx + 1]["hour"]
        if end < beg:
            for i in range(beg, 24):
                if i == beg:
                    min = _times[idx]["minute"] - 1
                    cron = "0 {}-59 {} * * *".format(min, i)
                else:
                    cron = "0 * {} * * *".format(i)
                add_task(cron, func)
            for i in range(0, end + 1):
                if i == end:
                    cron = "0 0-{} {} * * *".format(
                        _times[idx + 1]["minute"], i)
                else:
                    cron = "0 * {} * * *".format(i)
                add_task(cron, func)
        else:
            for i in range(beg, end + 1):
                if i == beg:
                    min = _times[idx]["minute"] - 1
                    cron = "0 {}-59 {} * * *".format(min, i)
                elif i == end:
                    cron = "0 0-{} {} * * *".format(
                        _times[idx + 1]["minute"], i)
                else:
                    cron = "0 * {} * * *".format(i)
                add_task(cron, func)
        pass


def set_every_bar_day_fre(func, security):
    """设置every_bar定时器"""

    def add_task(cron, func):
        if cron not in schedule:
            schedule[cron] = []
            if cron not in schedule_list:
                schedule_list.append(cron)
                zltObj._context.GetStrategyEngine().Schedule(cron)
        schedule[cron].append(func)

    set_time_task(func, security, add_task)


def set_every_bar_week_fre(func, security):
    def add_task(cron, func):
        if cron not in week_schedule:
            week_schedule[cron] = []
            if cron not in schedule_list:
                schedule_list.append(cron)
                zltObj._context.GetStrategyEngine().Schedule(cron)
        week_schedule[cron].append(func)

    set_time_task(func, security, add_task)


def set_every_bar_mon_fre(func, security):
    def add_task(cron, func):
        if cron not in mon_schedule:
            mon_schedule[cron] = []
            if cron not in schedule_list:
                schedule_list.append(cron)
                zltObj._context.GetStrategyEngine().Schedule(cron)
        mon_schedule[cron].append(func)

    set_time_task(func, security, add_task)


def run_daily(func, time, reference_security=None):
    """每天的某一个时刻执行策略函数

    参数:

    - func:自定义函数
    - time:运行时间
    - reference_security:参考标的
    """
    cron = "0 30 09 * * *"
    if time in ["open", "every_bar"]:
        if reference_security is None:
            reference_security = "sz399300"
        frequency = zltObj._context.run_params.frequency
        if time == "open" or (frequency == "day" and time == "every_bar"):
            if reference_security is None:
                reference_security = "sh000001"
            if reference_security[:2] == "sh" or reference_security[:2] == "sz":
                cron = "0 30 09 * * *"
            else:
                times = strategy_bridge.GetTradeTimeRule(reference_security, 0)
                if len(times) > 0:
                    hour = int(times[0] / 3600)
                    min = int(times[0] % 3600 / 60)
                    cron = "0 {} {} * * *".format(min, hour)
                else:
                    raise Exception(
                        "没有找到{}的交易时间规则".format(reference_security)
                    )
        elif time == "every_bar":
            if frequency == "min":
                set_every_bar_day_fre(func, reference_security)
                return
            else:
                raise Exception("every_bar 仅支持在天/分钟级别使用")
    elif (time.startswith("open+") or time.startswith("open-")) and time.endswith("m"):
        try:
            # 提取分钟数
            minutes = int(time[5:-1])
            if minutes > 99:
                raise ValueError("X的长度不能超过2位")
            # 判断是开盘前还是开盘后
            is_after_open = time.startswith("open+")
            if reference_security is None:
                reference_security = "sh000001"
            if reference_security[:2] == "sh" or reference_security[:2] == "sz":
                # 处理股票市场
                base_hour = 9
                base_minute = 30  # 假设开盘时间为 09:30

                # 计算调整后的分钟和小时
                total_minutes = base_minute + \
                    (minutes if is_after_open else -minutes)
                adjusted_hour = base_hour + total_minutes // 60
                adjusted_minute = total_minutes % 60

                cron = f"0 {adjusted_minute} {adjusted_hour} * * *"
            else:
                # 处理其他市场（如期货）
                times = strategy_bridge.GetTradeTimeRule(reference_security, 0)
                if len(times) > 0:
                    base_hour = int(times[0] / 3600)
                    base_minute = int(times[0] % 3600 / 60)

                    # 计算调整后的分钟和小时
                    total_minutes = base_minute + (
                        minutes if is_after_open else -minutes
                    )
                    adjusted_hour = base_hour + total_minutes // 60
                    adjusted_minute = total_minutes % 60
                    cron = f"0 {adjusted_minute} {adjusted_hour} * * *"
                else:
                    raise Exception(f"没有找到{reference_security}的交易时间规则")
        except ValueError:
            pass
    else:
        if reference_security is not None:
            raise Exception(
                "reference_security 只能在open/open+Xm/open-Xm/every_bar时使用"
            )
        try:
            run_time = time.split(":")
            cron = "0 {} {} * * *".format(run_time[1], run_time[0])
        except:
            raise Exception("time 格式错误，请使用 HH:MM 格式")

    if cron not in schedule:
        schedule[cron] = []
        if cron not in schedule_list:
            schedule_list.append(cron)
            zltObj._context.GetStrategyEngine().Schedule(cron)
    schedule[cron].append(func)


def run_weekly(func, weekday, time="09:30",  reference_security=None, force=False):
    """每周的某一天的某个时刻执行策略函数

    参数:

    -func :自定义函数
    -weekday :第几个交易日
    -time :运行时间
    -reference_security :参考标的
    """
    dates = zltObj._context.GetStrategyEngine().GetTradeList()
    dates = dates.split(",")
    week_group = {}
    week_idx = 0
    week_num = -1
    start_date = int(zltObj._context.run_params.start_date.strftime("%Y%m%d"))
    for item in dates:
        if start_date > int(item):
            continue
        if week_num != param_to_dt(item).isocalendar()[1]:
            week_group[week_idx] = []
            week_idx += 1
            week_num = param_to_dt(item).isocalendar()[1]
        week_group[week_idx - 1].append(item)
    for key in week_group:
        if weekday <= len(week_group[key]):
            zltObj._context.run_weekly.append(week_group[key][weekday - 1])
        else:
            if force and len(week_group[key]) > 0:
                zltObj._context.run_weekly.append(week_group[key][-1])
    cron = "0 30 09 * * *"
    frequency = zltObj._context.run_params.frequency
    if time in ["open", "every_bar"]:
        if reference_security is None:
            reference_security = "sz399300"
        frequency = zltObj._context.run_params.frequency
        if time == "open" or (frequency == "day" and time == "every_bar"):
            if reference_security is None:
                reference_security = "sh000001"
            if reference_security[:2] == "sh" or reference_security[:2] == "sz":
                cron = "0 30 09 * * *"

            else:
                times = strategy_bridge.GetTradeTimeRule(reference_security, 0)
                if len(times) > 0:
                    hour = int(times[0] / 3600)
                    min = int(times[0] % 3600 / 60)
                    cron = "0 {} {} * * *".format(min, hour)
                else:
                    raise Exception(
                        "没有找到{}的交易时间规则".format(reference_security)
                    )

        elif time == "every_bar":
            if frequency == "min":
                set_every_bar_week_fre(func, reference_security)
                return
            else:
                raise Exception("every_bar 仅支持在天/分钟级别使用")
    elif (time.startswith("open+") or time.startswith("open-")) and time.endswith("m"):
        try:
            # 提取分钟数
            minutes = int(time[5:-1])
            if minutes > 99:
                raise ValueError("X的长度不能超过2位")
            # 判断是开盘前还是开盘后
            is_after_open = time.startswith("open+")
            if reference_security is None:
                reference_security = "sh000001"
            if reference_security[:2] == "sh" or reference_security[:2] == "sz":
                # 处理股票市场
                base_hour = 9
                base_minute = 30  # 假设开盘时间为 09:30

                # 计算调整后的分钟和小时
                total_minutes = base_minute + \
                    (minutes if is_after_open else -minutes)
                adjusted_hour = base_hour + total_minutes // 60
                adjusted_minute = total_minutes % 60

                cron = f"0 {adjusted_minute} {adjusted_hour} * * *"
            else:
                # 处理其他市场（如期货）
                times = strategy_bridge.GetTradeTimeRule(reference_security, 0)
                if len(times) > 0:
                    base_hour = int(times[0] / 3600)
                    base_minute = int(times[0] % 3600 / 60)

                    # 计算调整后的分钟和小时
                    total_minutes = base_minute + (
                        minutes if is_after_open else -minutes
                    )
                    adjusted_hour = base_hour + total_minutes // 60
                    adjusted_minute = total_minutes % 60

                    cron = f"0 {adjusted_minute} {adjusted_hour} * * *"
                else:
                    raise Exception(f"没有找到{reference_security}的交易时间规则")
        except ValueError:
            pass
    else:
        if reference_security is not None:
            raise Exception(
                "reference_security 只能在before_open/open/after_market_close/after_close/every_bar时使用"
            )
        try:
            run_time = time.split(":")
            cron = "0 {} {} * * *".format(run_time[1], run_time[0])
        except:
            raise Exception("time 格式错误，请使用 HH:MM 格式")
    if cron not in week_schedule:
        week_schedule[cron] = []
        if cron not in schedule_list:
            schedule_list.append(cron)
            zltObj._context.GetStrategyEngine().Schedule(cron)
    week_schedule[cron].append(func)


def run_monthly(func, monthday, time="09:30",  reference_security=None, force=False):
    """每月的某一天的某个时刻执行策略函数

    参数:

    -func :自定义函数
    -monthday :第几个交易日
    -time :运行时间
    -reference_security :参考标的
    """
    dates = zltObj._context.GetStrategyEngine().GetTradeList()
    dates = dates.split(",")
    filter_date = []
    start_date = int(zltObj._context.run_params.start_date.strftime("%Y%m%d"))
    for item in dates:
        if start_date > int(item):
            continue
        filter_date.append(item)
    dates = filter_date
    month = -1
    sum_day = 0
    is_find = False
    pre_date = None
    for date in dates:
        # 替换成字符串切割
        _month = date[4:6]
        if _month != month:
            # 取最后一个交易日
            if not is_find and pre_date is not None and force:
                zltObj._context.run_monthly.append(pre_date)
            is_find = False
            month = _month
            sum_day += 1
            if sum_day == monthday:
                zltObj._context.run_monthly.append(date)
                is_find = True
                sum_day = 0
        elif not is_find:
            sum_day += 1
            if sum_day == monthday:
                zltObj._context.run_monthly.append(date)
                is_find = True
                sum_day = 0
        pre_date = date

    cron = "0 30 09 * * *"
    frequency = zltObj._context.run_params.frequency
    if time in ["open", "every_bar"]:
        if reference_security is None:
            reference_security = "sz399300"
        frequency = zltObj._context.run_params.frequency
        if time == "open" or (frequency == "day" and time == "every_bar"):
            if reference_security is None:
                reference_security = "sh000001"
            if reference_security[:2] == "sh" or reference_security[:2] == "sz":
                cron = "0 30 09 * * *"
            else:
                times = strategy_bridge.GetTradeTimeRule(reference_security, 0)
                if len(times) > 0:
                    hour = int(times[0] / 3600)
                    min = int(times[0] % 3600 / 60)
                    cron = "0 {} {} * * *".format(min, hour)
                else:
                    raise Exception(
                        "没有找到{}的交易时间规则".format(reference_security)
                    )

        elif time == "every_bar":
            if frequency == "min":
                set_every_bar_mon_fre(func, reference_security)
                return
            else:
                raise Exception("every_bar 仅支持在天/分钟级别使用")
    elif (time.startswith("open+") or time.startswith("open-")) and time.endswith("m"):
        try:
            # 提取分钟数
            minutes = int(time[5:-1])
            if minutes > 99:
                raise ValueError("X的长度不能超过2位")
            # 判断是开盘前还是开盘后
            is_after_open = time.startswith("open+")
            if reference_security is None:
                reference_security = "sh000001"
            if reference_security[:2] == "sh" or reference_security[:2] == "sz":
                # 处理股票市场
                base_hour = 9
                base_minute = 30  # 假设开盘时间为 09:30

                # 计算调整后的分钟和小时
                total_minutes = base_minute + \
                    (minutes if is_after_open else -minutes)
                adjusted_hour = base_hour + total_minutes // 60
                adjusted_minute = total_minutes % 60

                cron = f"0 {adjusted_minute} {adjusted_hour} * * *"
            else:
                # 处理其他市场（如期货）
                times = strategy_bridge.GetTradeTimeRule(reference_security, 0)
                if len(times) > 0:
                    base_hour = int(times[0] / 3600)
                    base_minute = int(times[0] % 3600 / 60)

                    # 计算调整后的分钟和小时
                    total_minutes = base_minute + (
                        minutes if is_after_open else -minutes
                    )
                    adjusted_hour = base_hour + total_minutes // 60
                    adjusted_minute = total_minutes % 60

                    cron = f"0 {adjusted_minute} {adjusted_hour} * * *"
                else:
                    raise Exception(f"没有找到{reference_security}的交易时间规则")
        except ValueError:
            pass
    else:
        if reference_security is not None:
            raise Exception(
                "reference_security 只能在before_open/open/after_market_close/after_close/every_bar时使用"
            )
        try:
            run_time = time.split(":")
            cron = "0 {} {} * * *".format(run_time[1], run_time[0])
        except:
            raise Exception("time 格式错误，请使用 HH:MM 格式")

    if cron not in mon_schedule:
        mon_schedule[cron] = []
        if cron not in schedule_list:
            schedule_list.append(cron)
            zltObj._context.GetStrategyEngine().Schedule(cron)
    mon_schedule[cron].append(func)


__all__ = [
    "run_daily",
    "run_weekly",
    "run_monthly",
    "schedule",
    "schedule_list",
    "mon_schedule",
    "system_functions",
]
