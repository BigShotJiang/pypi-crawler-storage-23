import zltsdk.zltcalc as zltcalc
from .zlt_zvector import zvector

# 时间截面


class Section():
    def __init__(self, section):
        self._zsection = section

    @property
    def index(self):
        '''截面中的标的
        '''
        return self._zsection.GetIndex()

    @property
    def time(self):
        '''截面时间
        '''
        return self._zsection.GetTime()

    @property
    def close(self):
        '''收盘价
        '''
        return zvector(self._zsection.GetCol("close"))

    @property
    def open(self):
        '''开盘价
        '''
        return zvector(self._zsection.GetCol("open"))

    @property
    def high(self):
        '''最高价
        '''
        return zvector(self._zsection.GetCol("high"))

    @property
    def low(self):
        '''最低价
        '''
        return zvector(self._zsection.GetCol("low"))

    @property
    def vol(self):
        '''成交量
        '''
        return zvector(self._zsection.GetCol("volume"))

    @property
    def amount(self):
        '''成交额
        '''
        return zvector(self._zsection.GetCol("amount"))

    @property
    def ipo_date(self):
        '''上市日期
        '''
        return zvector(self._zsection.GetCol("ipo_date"))

    @property
    def listing(self):
        '''上市状态
        '''
        return zvector(self._zsection.GetCol("listing"))

    @property
    def suspend(self):
        '''是否停牌
        '''
        return zvector(self._zsection.GetCol("suspend"))

    @property
    def delisted(self):
        '''是否退市
        '''
        return zvector(self._zsection.GetCol("delisted"))

    @property
    def predelist(self):
        '''是否预退市
        '''
        return zvector(self._zsection.GetCol("predelist"))

    @property
    def st(self):
        '''是否ST
        '''
        return zvector(self._zsection.GetCol("st"))
    
    def get_dpzs_code(self):
        '''获取大盘指数代码'''
        return zvector(self._zsection.GetDpzsCode(False))
    
    def get_dpzs_name(self):
        '''获取大盘指数名称'''
        return zvector(self._zsection.GetDpzsCode(True))

    @property
    def index_c(self):
        return zvector(self._zsection.GetCol("index_c"))
    @property
    def index_h(self):
        return zvector(self._zsection.GetCol("index_h"))
    @property
    def index_l(self):
        return zvector(self._zsection.GetCol("index_l"))
    @property
    def index_o(self):
        return zvector(self._zsection.GetCol("index_o"))
    @property
    def index_v(self):
        return zvector(self._zsection.GetCol("index_v"))
    @property
    def index_a(self):
        return zvector(self._zsection.GetCol("index_a"))

    def get_growth_price_nday(self,n):
        '''近N日涨幅'''
        return zvector(self._zsection.GetColForN("GetNDayGrowthPrice",n))
    
    def get_average_vol_nday(self,n):
        '''近N日平均成交量'''
        return zvector(self._zsection.GetColForN("GetNDayAvgVol",n))

    # 获取某个指标
    def get_indicator(self, col):
        return zvector(self._zsection.GetCol(col))

    # 当前状态

    def is_status(self, status_type):
        return zvector(self._zsection.IsStatus(status_type.value))
    # 上市时间

    def get_listing_days(self):
        return zvector(self._zsection.CountListingDays())
    # 过滤方法

    def filter(self, vec):
        return Section(self._zsection.Filter(vec._zvector))

    def get_category(self):
        return zvector(self._zsection.GetCol("category"))

    @property
    def growth_price(self):
        return zvector(self._zsection.GetCol("growth_price"))
    
    @property
    def avg_price(self):
        return zvector(self._zsection.GetCol("avg_price"))
    
    @property
    def ups_and_downs(self):
        return zvector(self._zsection.GetCol("ups_and_downs"))
    
    @property
    def amplitude(self):
        return zvector(self._zsection.GetCol("amplitude"))
    
    @property
    def turnover_rate(self):
        return zvector(self._zsection.GetCol("shares"))
    
    @property
    def turnover_rate_z(self):
        return zvector(self._zsection.GetCol("free_shares"))
    
    @property
    def vol_ratio(self,n=5):
        return zvector(self._zsection.GetColForN("GetVolRatio",n))
    
    @property
    def ztprice(self):
        return zvector(self._zsection.GetCol("zt_price"))
    
    @property
    def dtprice(self):
        return zvector(self._zsection.GetCol("dt_price"))
    
    @property
    def is_down(self):
        return zvector(self._zsection.GetCol("is_down"))
    
    @property
    def is_equal(self):
        return zvector(self._zsection.GetCol("is_equal"))
    
    @property
    def is_up(self):
        return zvector(self._zsection.GetCol("is_up"))
    
    @property
    def is_zt(self):
        return zvector(self._zsection.GetCol("is_zt"))
    
    @property
    def is_dt(self):
        return zvector(self._zsection.GetCol("is_dt"))

    # ===== 财务数据 =====
    @property
    def rpt_update_time(self):
        return zvector(self._zsection.GetCol("rpt_update_time"))

    @property
    def rpt_period(self):
        return zvector(self._zsection.GetCol("rpt_period"))

    @property
    def net_assets(self):
        return zvector(self._zsection.GetCol("net_assets"))

    @property
    def total_net_cf(self):
        return zvector(self._zsection.GetCol("total_net_cf"))

    @property
    def div_ttm(self):
        return zvector(self._zsection.GetCol("div_ttm"))

    @property
    def basic_eps(self):
        return zvector(self._zsection.GetCol("basic_eps"))

    @property
    def eps_excl_nonrec(self):
        return zvector(self._zsection.GetCol("eps_excl_nonrec"))

    @property
    def undist_profit_ps(self):
        return zvector(self._zsection.GetCol("undist_profit_ps"))

    @property
    def nav_ps(self):
        return zvector(self._zsection.GetCol("nav_ps"))

    @property
    def roe(self):
        return zvector(self._zsection.GetCol("roe"))

    @property
    def op_cf_ps(self):
        return zvector(self._zsection.GetCol("op_cf_ps"))

    @property
    def cash(self):
        return zvector(self._zsection.GetCol("cash"))

    @property
    def accounts_recv(self):
        return zvector(self._zsection.GetCol("accounts_recv"))

    @property
    def prepayments(self):
        return zvector(self._zsection.GetCol("prepayments"))

    @property
    def inventory(self):
        return zvector(self._zsection.GetCol("inventory"))

    @property
    def curr_assets(self):
        return zvector(self._zsection.GetCol("curr_assets"))

    @property
    def long_recv(self):
        return zvector(self._zsection.GetCol("long_recv"))

    @property
    def fixed_assets(self):
        return zvector(self._zsection.GetCol("fixed_assets"))

    @property
    def goodwill(self):
        return zvector(self._zsection.GetCol("goodwill"))

    @property
    def total_noncurr_assets(self):
        return zvector(self._zsection.GetCol("total_noncurr_assets"))

    @property
    def total_assets(self):
        return zvector(self._zsection.GetCol("total_assets"))

    @property
    def short_loans(self):
        return zvector(self._zsection.GetCol("short_loans"))

    @property
    def accounts_pay(self):
        return zvector(self._zsection.GetCol("accounts_pay"))

    @property
    def adv_from_cust(self):
        return zvector(self._zsection.GetCol("adv_from_cust"))

    @property
    def curr_liab(self):
        return zvector(self._zsection.GetCol("curr_liab"))

    @property
    def total_liab(self):
        return zvector(self._zsection.GetCol("total_liab"))

    @property
    def paid_in_cap(self):
        return zvector(self._zsection.GetCol("paid_in_cap"))

    @property
    def undist_profit(self):
        return zvector(self._zsection.GetCol("undist_profit"))

    @property
    def minor_equity(self):
        return zvector(self._zsection.GetCol("minor_equity"))

    @property
    def total_equity(self):
        return zvector(self._zsection.GetCol("total_equity"))

    @property
    def parent_eq_bs(self):
        return zvector(self._zsection.GetCol("parent_eq_bs"))

    @property
    def contract_liab(self):
        return zvector(self._zsection.GetCol("contract_liab"))

    @property
    def op_rev(self):
        return zvector(self._zsection.GetCol("op_rev"))

    @property
    def op_cost(self):
        return zvector(self._zsection.GetCol("op_cost"))

    @property
    def op_profit(self):
        return zvector(self._zsection.GetCol("op_profit"))

    @property
    def total_profit(self):
        return zvector(self._zsection.GetCol("total_profit"))

    @property
    def profit_aft_tax(self):
        return zvector(self._zsection.GetCol("profit_aft_tax"))

    @property
    def net_profit(self):
        return zvector(self._zsection.GetCol("net_profit"))

    @property
    def rnd_exp(self):
        return zvector(self._zsection.GetCol("rnd_exp"))

    @property
    def net_op_cf(self):
        return zvector(self._zsection.GetCol("net_op_cf"))

    @property
    def net_inv_cf(self):
        return zvector(self._zsection.GetCol("net_inv_cf"))

    @property
    def current_ratio(self):
        return zvector(self._zsection.GetCol("current_ratio"))

    @property
    def quick_ratio(self):
        return zvector(self._zsection.GetCol("quick_ratio"))

    @property
    def cash_ratio(self):
        return zvector(self._zsection.GetCol("cash_ratio"))

    @property
    def ar_turnover_ratio(self):
        return zvector(self._zsection.GetCol("ar_turnover_ratio"))

    @property
    def inv_turnover_ratio(self):
        return zvector(self._zsection.GetCol("inv_turnover_ratio"))

    @property
    def wc_turnover_ratio(self):
        return zvector(self._zsection.GetCol("wc_turnover_ratio"))

    @property
    def total_asset_turnover(self):
        return zvector(self._zsection.GetCol("total_asset_turnover"))

    @property
    def fixed_asset_turnover(self):
        return zvector(self._zsection.GetCol("fixed_asset_turnover"))

    @property
    def op_profit_margin(self):
        return zvector(self._zsection.GetCol("op_profit_margin"))

    @property
    def gross_profit_margin(self):
        return zvector(self._zsection.GetCol("gross_profit_margin"))

    @property
    def net_profit_excl(self):
        return zvector(self._zsection.GetCol("net_profit_excl"))

    @property
    def ebit(self):
        return zvector(self._zsection.GetCol("ebit"))

    @property
    def ebitda(self):
        return zvector(self._zsection.GetCol("ebitda"))

    @property
    def net_op_cf_to_op_rev(self):
        return zvector(self._zsection.GetCol("net_op_cf_to_op_rev"))

    @property
    def net_cf_ps(self):
        return zvector(self._zsection.GetCol("net_cf_ps"))

    @property
    def net_op_cf_to_net_profit(self):
        return zvector(self._zsection.GetCol("net_op_cf_to_net_profit"))

    @property
    def total_shares(self):
        return zvector(self._zsection.GetCol("total_shares"))

    @property
    def shareholders_num(self):
        return zvector(self._zsection.GetCol("shareholders_num"))

    @property
    def shares_top10_circ_sh(self):
        return zvector(self._zsection.GetCol("shares_top10_circ_sh"))

    @property
    def shares_top10_sh(self):
        return zvector(self._zsection.GetCol("shares_top10_sh"))

    @property
    def free_shares(self):
        return zvector(self._zsection.GetCol("free_shares"))

    @property
    def total_inst_shares(self):
        return zvector(self._zsection.GetCol("total_inst_shares"))

    @property
    def qfii_shares(self):
        return zvector(self._zsection.GetCol("qfii_shares"))

    @property
    def brokerage_shares(self):
        return zvector(self._zsection.GetCol("brokerage_shares"))

    @property
    def fund_shares(self):
        return zvector(self._zsection.GetCol("fund_shares"))

    @property
    def social_security_shares(self):
        return zvector(self._zsection.GetCol("social_security_shares"))

    @property
    def national_team_shares(self):
        return zvector(self._zsection.GetCol("national_team_shares"))

    @property
    def northbound_funds_shares(self):
        return zvector(self._zsection.GetCol("northbound_funds_shares"))

    @property
    def employees_num(self):
        return zvector(self._zsection.GetCol("employees_num"))
