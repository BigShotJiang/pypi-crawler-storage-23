"""ipc方法"""

import json
import math
import sqlite3
from .zlt_get_data import get_security_info
from .zlt_util import get_ipc_result
from . import zlt_object as zltObj
from . import zlt_others as zltOthers
from datetime import datetime
import zltsdk.strategy_bridge as strategy_bridge
import os


def modify_backtest_status(context, status, progress=0, is_start=None, remarks=""):
    """修改策略转态"""
    pid = os.getpid()
    req = {
        "strategy_id": context.strategy_info["strategy_id"],
        "backtest_id": context.strategy_info["backtest_id"],
        "progress": progress,
        "status": status,
        "remarks": remarks,
        "end_time": int(datetime.now().timestamp()) * 1000,
        "pid": pid,
    }
    if is_start:
        req["is_start"] = is_start
    ansMsg = get_ipc_result(
        context.IPCClient,
        req,
        "zltBacktest",
        "modify-backtest-status",
        "0",
        context.strategy_info["userid"],
    )
    try:
        
        if ansMsg["ErrNo"] != 0:
            zltOthers.system_log.error(f"modify-backtest-status失败,失败码:{ansMsg['ErrNo']}")
        else:
            zltOthers.system_log.info(f"modify-backtest-status成功")
    except:
        zltOthers.system_log.error(f"modify-backtest-status上报失败,回包信息无法解析!")


def record_single(
    context, code, t_type, stk_account, trade_type, trade_price, trade_qty
):
    """
    上报交易下单信号

    在非回测模式下，将交易信号上报到系统记录中。该函数首先检查是否处于回测模式，
    如果是，则直接返回而不执行任何操作。然后获取指定证券代码的信息，并构造一个请求
    字典，包含交易的详细信息，最后通过IPC通信将交易信号上报。

    参数:
    - context: 上下文对象，包含策略信息和IPC客户端等数据。
    - code: 证券代码，字符串类型。
    - t_type: 交易类型，整数类型。
    - stk_account: 股票账户，字符串类型。
    - trade_type: 交易方向，整数类型。
    - trade_price: 交易价格，浮点数类型。
    - trade_qty: 交易数量，整数类型。

    返回值:
    无返回值。
    """
    if zltObj._context.backtest_param["strategy_mode"] == 3:  # 回测模式下不上报信号
        return
    zltOthers.system_log.info("上报交易下单信号")
    info = get_security_info(code)
    db_path = os.path.join(
        zltObj._context.db_dir,
        "strategy_result",
        f"{zltObj._context.backtest_param['backtest_id']}.db",
    )
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    t_type = info.display_name + t_type
    insert_sql = """insert into zlt_trigger_recording (code, cname, t_type, stk_account, market, trade_type, trade_price, trade_qty, trigger_time) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)"""
    data_tuple = (
        code,
        info.display_name,
        t_type,
        stk_account,
        trade_type,
        "",
        trade_price,
        trade_qty,
        int(datetime.now().timestamp()),
    )
    cursor.execute(insert_sql, data_tuple)
    conn.commit()
    conn.close()


import threading
import time

"""
进程上报状态 - 非回测使用
"""


class TimerThread(threading.Thread):
    def __init__(self, interval, function, *args, **kwargs):
        super().__init__()
        self.interval = interval  # 执行间隔(秒)
        self.function = function  # 要执行的函数
        self.args = args  # 位置参数
        self.kwargs = kwargs  # 关键字参数
        self.stop_flag = False  # 停止标志
        self.kill_count = 0  # 添加计数器
        self.last_rept_time = 0  # 上次上报时间

    def run(self):
        while not self.stop_flag:
            self.function(*self.args, kill_count=self.kill_count, **self.kwargs)
            time.sleep(self.interval)

    def stop(self):
        self.stop_flag = True


def get_daily_position(avaliable_cash=0):
    """获取每日持仓
    - costPrice为持仓均价
    - openAvgPrice为开仓均价(聚宽逻辑:卖出时不参与摊薄,计算时只用买入价格求均值)
    """
    strategyId = zltObj._context.strategy_info["backtest_id"]
    fundAccid = zltObj._context.strategy_info["fund_account"]
    fundType = "1"
    secType = "1"
    orderTime = int(zltObj._context.current_dt.timestamp())
    backtest_id = zltObj._context.strategy_info["backtest_id"]
    account_id = backtest_id
    # 获取持仓信息
    market_cap_data = strategy_bridge.TradeQryTakePositionBForUser(
        strategyId, fundAccid, fundType, secType, orderTime
    )
    zltOthers.system_log.info("TradeQryTakePositionBForUser返回的持仓数量", len(market_cap_data))
    price_dict = {}
    total_assets = avaliable_cash
    for item in market_cap_data:
        if math.isnan(item["price"]):
            raise Exception(
                f"获取持仓收盘价,证券代码{item['security']},价格{item['price']}"
            )
        price_dict[item["security"].decode()] = item["price"]
        total_assets += item["value"]
    data = strategy_bridge.TradeQryTakePositionB(
        strategyId, fundAccid, fundType, secType, orderTime
    )
    zltOthers.system_log.info("TradeQryTakePositionB返回的持仓数量", len(data))
    position_list = []
    for detail in data:
        exchange_id = detail["market"].decode()
        instrument_id = detail["secCd"].decode()
        instrument_name = detail["secName"].decode()
        direction = int(detail["tradeModel"])
        quantity = int(detail["openQty"].decode())
        code = detail["secCd"].decode()
        close_price = price_dict[code]
        close_price = round(float(close_price + 0.0001), 2)
        market_value = quantity * close_price
        if direction != 1:
            market_value = float(detail["costAmt"].decode())
        open_avg_price = float(detail["openAvgPrice"].decode())
        position_avg_price = detail["positionAvgPrice"].decode()
        margin = detail["margin"].decode()
        today_quantity = int(detail["todayQuantit"].decode())
        position_ratio = (
            0 if total_assets == 0 else round((market_value / total_assets) * 100, 2)
        )
        if detail["secType"].decode() == "2":
            position_ratio = (
                0
                if total_assets == 0
                else round((float(detail["margin"].decode()) / total_assets) * 100, 2)
            )
        pnl_ratio = 0
        if open_avg_price != 0:
            pnl_ratio = round(
                ((close_price - open_avg_price) / open_avg_price) * 100, 2
            )
        req = {
            "backtest_id": backtest_id,
            "account_id": account_id,
            "date": str(int(zltObj._context.current_dt.timestamp()) * 1000),
            "exchange_id": exchange_id,
            "exchange_name": exchange_id,
            "instrument_id": instrument_id,
            "instrument_name": instrument_name,
            "direction": direction,
            "quantity": quantity,
            "available_quantity": quantity - today_quantity,
            "close_price": detail["orderPriceClose"].decode(),
            "market_value": detail["secValue"].decode(),
            "profit": detail["profit"].decode(),
            "open_avg_price": detail["openAvgPrice"].decode(),
            "position_avg_price": position_avg_price,
            "margin": margin,
            "daily_pnl": detail["todayProfit"].decode(),
            "today_quantity": today_quantity,
            "position_ratio": position_ratio,
            "pnl_ratio": pnl_ratio,
            "cost_price": detail["costPrice"].decode(),
            "total_buy": detail["buyAllAmtToday"].decode(),
            "total_sell": detail["sellAllAmtToday"].decode(),
        }
        position_list.append(req)
    return position_list


def report_strategy_position():
    """
    上报策略持仓信息
    """
    position_list = get_daily_position()
    if len(position_list) == 0:
        zltOthers.system_log.warn(f"持仓为空无需上报")
        return
    try:
        conn = zltObj._context.sim_db_conn
        cursor = conn.cursor()
        delete_sql = """
            DELETE FROM zlt_tmp_daily_position_profit
        """
        cursor.execute(delete_sql)
        for item in position_list:
            insert_sql = """
                INSERT INTO zlt_tmp_daily_position_profit (
                    backtest_id, account_id, date, exchange_id, exchange_name,
                    product_id, product_name, instrument_id, instrument_name, direction,
                    quantity, available_quantity, open_price, close_price, market_value,
                    profit, open_avg_price, position_avg_price, margin, daily_pnl,
                    today_quantity, position_ratio, pnl_ratio, total_buy, total_sell
                ) VALUES (
                    ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
                )
            """
            data_tuple = (
                item["backtest_id"],
                item["account_id"],
                item["date"],
                item["exchange_id"],
                item["exchange_name"],
                "",
                "",
                item["instrument_id"],
                item["instrument_name"],
                item["direction"],
                item["quantity"],
                item["available_quantity"],
                item["cost_price"],
                item["close_price"],
                item["market_value"],
                item["profit"],
                item["open_avg_price"],
                item["position_avg_price"],
                item["margin"],
                item["daily_pnl"],
                item["today_quantity"],
                item["position_ratio"],
                item["pnl_ratio"],
                item["total_buy"],
                item["total_sell"],
            )
            cursor.execute(insert_sql, data_tuple)
        conn.commit()
        return True
    except Exception as e:
        zltOthers.system_log.error(f"执行SQL脚本时出错: {e}")
        return False


def get_entrust_list():
    """获取今日所有委托记录

    参数:
        sec_code:查询特定股票今日的委托记录
    """
    date = int(zltObj._context.current_dt.timestamp())
    strategyId = zltObj._context.strategy_info["strategy_id"]
    fundAccid = zltObj._context.strategy_info["fund_account"]
    fundType = str(1)  # 1 股票 2 期货
    secType = str(1)  # 1 股票 2 期货
    result = strategy_bridge.TradeQryCollentB(
        strategyId, fundAccid, fundType, secType, "", 0, date
    )
    zltOthers.system_log.info("TradeQryCollentB返回的委托数量", len(result))
    entrust_list = []
    for detail in result:
        backtest_id = zltObj._context.strategy_info["backtest_id"]
        account_id = zltObj._context.strategy_info["backtest_id"]
        item = {
            "backtest_id": backtest_id,
            "account_id": account_id,
            "exchange_id": detail["market"].decode(),
            "exchange_name": detail["market"].decode(),
            "product_id": detail["secType"].decode(),
            "product_name": "",
            "instrument_id": detail["secCd"].decode(),
            "instrument_name": detail["secName"].decode(),
            "task_id": "",
            "order_ref": detail["orderId"].decode(),
            "order_price_type": detail["orderWtlb"].decode(),
            "direction": int(detail["orderSide"].decode()) + 1,
            "offset_flag": int(detail["tradeType"].decode()),
            "hedge_flag": "",
            "limit_price": detail["orderPrice"].decode(),
            "volume_total_original": detail["orderQty"].decode(),
            "order_submit_status": "",
            "order_sys_id": detail["orderId"].decode(),
            "order_status": detail["orderStat"].decode(),
            "volume_traded": detail["tradedQty"].decode(),
            "volume_total": int(detail["orderQty"].decode())
            - int(detail["tradedQty"].decode()),
            "error_id": 0,
            "frozen_margin": detail["margin"].decode(),
            "frozen_commission": 0,
            "insert_date": str(
                int(
                    datetime.fromtimestamp(float(detail["orderTime"].decode())).replace(
                        hour=0, minute=0, second=0, microsecond=0
                    ).timestamp()
                )
                * 1000
            ),
            "insert_time": detail["orderTime"].decode() + "000",
            "traded_price": detail["successPrice"].decode(),
            "cancel_amount": 0,
            "opt_name": detail["orderSide"].decode(),
            "trade_amount": detail["tradedAmt"].decode(),
            "entrust_type": 0,
            "cancel_info": "",
            "under_code": detail["secCd"].decode(),
            "covered_flag": 0,
            "compact_no": "",
            "pnl": detail["profitOutQrt"].decode(),
            "commission": detail["commission"].decode(),
            "update_time": detail["tradeTime"].decode() + "000",
        }
        entrust_list.append(item)
    return entrust_list


# 仿真环境上报策略订单
def report_strategy_order():
    """
    上报策略委托信息
    """
    entrust_list = get_entrust_list()
    if len(entrust_list) == 0:
        zltOthers.system_log.warn(f"委托数量为空无需上报")
        return
    # 连接数据库
    try:
        conn = zltObj._context.sim_db_conn
        cursor = conn.cursor()
        delete_sql = """
            DELETE FROM zlt_tmp_entrust
        """
        cursor.execute(delete_sql)
        for item in entrust_list:
            insert_sql = """
                INSERT INTO zlt_tmp_entrust (
                    backtest_id, account_id, exchange_id, exchange_name,
                    product_id, product_name, instrument_id, instrument_name, task_id,
                    order_ref, order_price_type, direction, offset_flag, hedge_flag,
                    limit_price, volume_total_original, order_submit_status, order_sys_id,
                    order_status, volume_traded, volume_total, error_id, frozen_margin,
                    frozen_commission, insert_date, insert_time, update_time, traded_price,
                    cancel_amount, opt_name, trade_amount, entrust_type, cancel_info,
                    under_code, covered_flag, compact_no, pnl, commission
                ) VALUES (
                    ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,
                    ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
                )
            """
            data_tuple = (
                item["backtest_id"],
                item["account_id"],
                item["exchange_id"],
                item["exchange_name"],
                item["product_id"],
                item["product_name"],
                item["instrument_id"],
                item["instrument_name"],
                item["task_id"],
                item["order_ref"],
                item["order_price_type"],
                item["direction"],
                item["offset_flag"],
                item["hedge_flag"],
                item["limit_price"],
                item["volume_total_original"],
                item["order_submit_status"],
                item["order_sys_id"],
                item["order_status"],
                item["volume_traded"],
                item["volume_total"],
                item["error_id"],
                item["frozen_margin"],
                item["frozen_commission"],
                item["insert_date"],
                item["insert_time"],
                item["update_time"],
                item["traded_price"],
                item["cancel_amount"],
                item["opt_name"],
                item["trade_amount"],
                item["entrust_type"],
                item["cancel_info"],
                item["under_code"],  # 移除了键名后的空格
                item["covered_flag"],  # 移除了键名后的空格
                item["compact_no"],  # 移除了键名后的空格
                item["pnl"],  # 移除了键名后的空格
                item["commission"],
            )
            cursor.execute(insert_sql, data_tuple)
        conn.commit()
        return True
    except Exception as e:
        zltOthers.system_log.error(f"执行SQL脚本时出错: {e}")
        return False


# 使用示例
def keep_alive(message, kill_count):
    print("keep_alive 当前策略时间{}".format(datetime.now()))
    req = {"btid": zltObj._context.backtest_param["backtest_id"]}
    ansMsg = get_ipc_result(
        zltObj._context.IPCClient,
        req,
        "zltBacktest",
        "st-keep-live",
        "0",
        zltObj._context.strategy_info["userid"],
    )
    try:
        report_strategy_position()
        report_strategy_order()
        if ansMsg["ErrNo"] != 0:
            zltOthers.system_log.error(f"st-keep-live上报失败,失败码:{ansMsg['ErrNo']}")
            kill_count += 1
        else:
            kill_count = 0
            # 当策略为暂停、完成时退出进程
            zltOthers.system_log.info(f"后台返回策略状态:{ansMsg['Data']['status']}")
            if ansMsg["Data"]["status"] == "7" or ansMsg["Data"]["status"] == "5":
                zltOthers.system_log.error(f"策略进入休眠状态，进程准备退出！")
                zltObj.g.zlt_status = "3"
                os._exit(0)

    except Exception as e:
        zltOthers.system_log.error(
            f"st-keep-live心跳上报失败: {e},继续尝试...,当前尝试次数{kill_count}"
        )
        kill_count += 1
        # 如果在本地运行可以自己退出进程, 在服务器中不退出进程
        if kill_count > 10:
            zltOthers.system_log.error(f"策略上报超过尝试次数10次,进程准备退出!")
            os._exit(0)

    return kill_count  # 返回更新后的计数


# 修改后的线程类，可以更新计数器
class CountableTimerThread(TimerThread):
    def run(self):
        if zltObj._context.backtest_param["strategy_mode"] != 3:
            zltObj._context.sim_db_conn = sqlite3.connect(
                f'{zltObj._context.db_dir}/strategy_tmp_result/{zltObj._context.backtest_param["backtest_id"]}.db'
            )
        while not self.stop_flag:
            # 调用函数并获取更新后的kill_count
            self.kill_count = self.function(
                *self.args, kill_count=self.kill_count, **self.kwargs
            )
            time.sleep(self.interval)


timer_thread = CountableTimerThread(10, keep_alive, "定时任务执行中")
