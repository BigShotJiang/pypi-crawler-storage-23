PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
DROP TABLE IF EXISTS zlt_backtest_profit_detail;
-- 回测收益(实盘模拟盘->策略收益)
CREATE TABLE zlt_backtest_profit_detail (
    backtest_profit_id INTEGER PRIMARY KEY AUTOINCREMENT,
    -- 回测ID
    backtest_id TEXT,
    -- 资金账号ID
    account_id TEXT,
    -- 策略收益
    strategy_profit TEXT,
    -- 策略年化收益
    annualized_profit TEXT,
    -- 超额收益
    excess_profit TEXT,
    -- 基准收益
    benchmark_profit TEXT,
    -- 阿尔法
    alpha TEXT,
    -- 贝塔
    beta TEXT,
    -- 夏普比率
    sharpe_ratio TEXT,
    -- 胜率
    win_rate TEXT,
    -- 盈亏比
    profit_loss_ratio TEXT,
    -- 盈亏比类型 0:比例 1：盈亏金额
    profit_ratio_type TEXT,
    -- 最大回撤
    max_drawdown TEXT,
    -- 索提诺比率
    sortino_ratio TEXT,
    -- 日均超额收益
    daily_excess_profit TEXT,
    -- 超额收益最大回撤
    excess_profit_max_drawdown TEXT,
    -- 超额收益夏普比率
    excess_profit_sharpe_ratio TEXT,
    -- 日胜率
    daily_win_rate TEXT,
    -- 盈利次数
    num_winning_trades INT,
    -- 亏损次数
    num_losing_trades INT,
    -- 信息比率
    information_ratio TEXT,
    -- 策略波动率
    strategy_volatility TEXT,
    -- 基准波动率
    benchmark_volatility TEXT,
    -- 最大回撤区间 开始时间
    start_time TIMESTAMP,
    -- 最大回撤区间 结束时间
    end_time TIMESTAMP,
    -- 总资产
    total_asset TEXT,
    -- 基准价格
    benchmark_price TEXT,
    -- 前一日资产
    pre_total_asset TEXT,
    -- 前一日基准价格
    pre_benchmark_price TEXT,
    -- 换手率
    turnover_rate TEXT,
    -- 仓位
    position_rate TEXT,
    -- 日期
    date TIMESTAMP,
    -- 创建时间
    auto_create_time TIMESTAMP DEFAULT (strftime('%s', 'now') * 1000),
    auto_update_time TIMESTAMP DEFAULT (strftime('%s', 'now') * 1000)
);
CREATE INDEX "bt_profit_idx_end_time" ON "zlt_backtest_profit_detail" ("end_time");
CREATE INDEX "bt_profit_idx_start_time" ON "zlt_backtest_profit_detail" ("start_time");
CREATE INDEX "bt_profit_idx_date" ON "zlt_backtest_profit_detail" ("date");
CREATE INDEX "bt_profit_idx_backtest_id" ON "zlt_backtest_profit_detail" ("backtest_id");
DROP TABLE IF EXISTS zlt_daily_position_profit;
-- 每日持仓收益
CREATE TABLE zlt_daily_position_profit (
    -- 每日持仓收益 ID
    daily_position_profit_id INTEGER PRIMARY KEY AUTOINCREMENT,
    -- 回测 ID
    backtest_id TEXT,
    -- 资金账号ID
    account_id TEXT,
    -- 日期
    date TIMESTAMP,
    -- 证券市场
    exchange_id TEXT,
    -- 交易市场
    exchange_name TEXT,
    -- 品种代码
    product_id TEXT,
    -- 品种名称
    product_name TEXT,
    -- 证券代码
    instrument_id TEXT,
    -- 证券名称，合约名称
    instrument_name TEXT,
    -- 多空
    direction TEXT,
    -- 数量
    quantity TEXT,
    -- 可用数量
    available_quantity TEXT,
    -- 开盘价
    open_price TEXT,
    -- 收盘价/结算价
    close_price TEXT,
    -- 市值/价值
    market_value TEXT,
    -- 盈亏/逐笔浮盈
    profit TEXT,
    -- 开仓均价
    open_avg_price TEXT,
    -- 持仓均价(期货)
    position_avg_price TEXT,
    -- 保证金
    margin TEXT,
    -- 当日盈亏(浮盈)
    daily_pnl TEXT,
    -- 今手数
    today_quantity TEXT,
    -- 仓位占比
    position_ratio TEXT,
    -- 盈亏占比
    pnl_ratio TEXT,
    -- 合计买金额（不含手续费）
    total_buy TEXT,
    -- 合计卖金额（不含手续费）
    total_sell TEXT,
    -- 创建时间
    auto_create_time TIMESTAMP DEFAULT (strftime('%s', 'now') * 1000),
    auto_update_time TIMESTAMP DEFAULT (strftime('%s', 'now') * 1000)
);
CREATE INDEX "bt_daily_idx_profit" ON "zlt_daily_position_profit" ("date");
CREATE INDEX "bt_daily_idx_instrument_id" ON "zlt_daily_position_profit" ("instrument_id");
DROP TABLE IF EXISTS zlt_entrust;
-- 委托单
CREATE TABLE zlt_entrust (
    -- 委托 ID
    entrust_id INTEGER PRIMARY KEY AUTOINCREMENT,
    -- 回测ID
    backtest_id TEXT,
    -- 资金账号ID
    account_id TEXT,
    -- 证券市场
    exchange_id TEXT,
    -- 交易市场
    exchange_name TEXT,
    -- 品种代码
    product_id TEXT,
    -- 品种名称
    product_name TEXT,
    -- 证券代码
    instrument_id TEXT,
    -- 证券名称，合约名称
    instrument_name TEXT,
    -- 任务号
    task_id INT,
    -- 内部委托号，下单引用等于股票的内部委托号
    order_ref TEXT,
    -- 委托价格类型，例如市价单、限价单
    -- OrderType_Unknown = 0,
    -- OrderType_Limit = 1,                                     //限价委托
    -- OrderType_Market = 2,                                    //市价委托
    -- OrderType_Stop = 3,                                      //止损止盈委托
    order_price_type TEXT,
    -- 操作，多空，期货多空，股票买卖永远是 48，其他的 dir 同理
    -- OrderSide_Unknown = 0,
    -- OrderSide_Buy = 1,                                       //买入
    -- OrderSide_Sell = 2,                                      //卖出
    direction TEXT,
    -- 操作，期货开平，股票买卖其实就是开平
    offset_flag TEXT,
    -- 投保
    hedge_flag TEXT,
    -- 委托价格,限价单的限价，就是报价
    limit_price TEXT,
    -- 委托量，最初委托量
    volume_total_original TEXT,
    -- 报单状态，提交状态，股票中不需要报单状态
    order_submit_status TEXT,
    -- 合同编号，委托号
    order_sys_id TEXT,
    -- 委托状态 	
    -- ORDER_PREPARE = 1,//待申报 尚未成交
    -- ORDER_ALREADY = 2,//已申报 
    -- ORDER_CANCEL = 3,//废单
    -- ORDER_SHARE = 4,//送转股
    -- ORDER_UNFILLED = 5, //未成交
    -- ORDER_PARTIALLY_FILLED = 6,// 部分成交
    -- ORDER_PARTIALLY_CANCELLED = 7,// 部成部撤
    -- ORDER_FULLY_CANCELLED = 8,// 全部撤单
    -- ORDER_FULLY_FILLED = 9, // 全部成交
    order_status TEXT,
    -- 成交数量，已成交量
    volume_traded TEXT,
    -- 委托剩余量，当前总委托量，股票的含义是总委托量减去成交量
    volume_total TEXT,
    -- 状态信息 委托拒绝原因
    -- OrderRejectReason_Unknown = 0,                           //未知原因
    -- OrderRejectReason_RiskRuleCheckFailed = 1,               //不符合风控规则 
    -- OrderRejectReason_NoEnoughCash = 2,                      //资金不足
    -- OrderRejectReason_NoEnoughPosition = 3,                  //仓位不足
    -- OrderRejectReason_IllegalAccountId = 4,                  //非法账户ID
    -- OrderRejectReason_IllegalStrategyId = 5,                 //非法策略ID
    -- OrderRejectReason_IllegalSymbol = 6,                     //非法交易代码
    -- OrderRejectReason_IllegalVolume = 7,                     //非法委托量
    -- OrderRejectReason_IllegalPrice = 8,                      //非法委托价
    -- OrderRejectReason_AccountDisabled = 10,                  //交易账号被禁止交易
    -- OrderRejectReason_AccountDisconnected = 11,              //交易账号未连接
    -- OrderRejectReason_AccountLoggedout = 12,                 //交易账号未登录
    -- OrderRejectReason_NotInTradingSession = 13,              //非交易时段
    -- OrderRejectReason_OrderTypeNotSupported = 14,            //委托类型不支持
    -- OrderRejectReason_Throttle = 15,                         //流控限制
    -- OrderRejectReason_SymbolSusppended = 16,                 //交易代码停牌
    -- OrderRejectReason_Internal = 999,                        //内部错误
    -- CancelOrderRejectReason_OrderFinalized = 101,            //委托已完成
    -- CancelOrderRejectReason_UnknownOrder = 102,              //未知委托
    -- CancelOrderRejectReason_BrokerOption = 103,              //柜台设置
    -- CancelOrderRejectReason_AlreadyInPendingCancel = 104,    //委托撤销中
    error_id INT,
    -- 冻结金额，冻结保证金
    frozen_margin TEXT,
    -- 冻结手续费
    frozen_commission TEXT,
    -- 委托日期，报单日期
    insert_date TIMESTAMP,
    -- 委托时间
    insert_time TIMESTAMP,
    -- 最后更新时间/委托,撤单
    update_time TIMESTAMP,
    -- 成交均价
    traded_price TEXT,
    -- 已撤数量
    cancel_amount TEXT,
    -- 买卖标记，展示委托属性的中文
    opt_name TEXT,
    -- 成交金额，成交额，期货 = 均价 * 量 * 合约乘数
    trade_amount TEXT,
    -- 委托类别 OrderBusiness
    -- OrderBusiness_NORMAL = 0,                                //普通交易                                                           
    -- OrderBusiness_IPO_BUY = 100,                             //新股申购                                                         
    -- OrderBusiness_CREDIT_BOM = 200,                          //融资买入(buying on margin)                                       
    -- OrderBusiness_CREDIT_SS = 201,                           //融券卖出(short selling)                                          
    -- OrderBusiness_CREDIT_RSBBS = 202,                        //买券还券(repay share by buying share)                            
    -- OrderBusiness_CREDIT_RCBSS = 203,                        //卖券还款(repay cash by selling share)                            
    -- OrderBusiness_CREDIT_DRS = 204,                          //直接还券(directly repay share)                                   
    -- OrderBusiness_CREDIT_DRC = 211,                          //直接还款(directly repay cash)                                    
    -- OrderBusiness_CREDIT_CPOM = 205,                         //融资平仓(close position on margin)                               
    -- OrderBusiness_CREDIT_CPOSS = 206,                        //融券平仓(close position on short selling)                        
    -- OrderBusiness_CREDIT_BOC = 207,                          //担保品买入(buying on collateral)                                 
    -- OrderBusiness_CREDIT_SOC = 208,                          //担保品卖出(selling on collateral)                                
    -- OrderBusiness_CREDIT_CI = 209,                           //担保品转入(collateral in)                                        
    -- OrderBusiness_CREDIT_CO = 210,                           //担保品转出(collateral out)                                       
    -- OrderBusiness_ETF_BUY = 301,                             //ETF申购(purchase)                                                
    -- OrderBusiness_ETF_RED = 302,                             //ETF赎回(redemption)                                              
    -- OrderBusiness_FUND_SUB = 303,                            //基金认购(subscribing)                                            
    -- OrderBusiness_FUND_BUY = 304,                            //基金申购(purchase)                                               
    -- OrderBusiness_FUND_RED = 305,                            //基金赎回(redemption)                                             
    -- OrderBusiness_FUND_CONVERT = 306,                        //基金转换(convert)                                                
    -- OrderBusiness_FUND_SPLIT = 307,                          //基金分拆(split)                                                  
    -- OrderBusiness_FUND_MERGE = 308,                          //基金合并(merge)                                                  
    -- OrderBusiness_BOND_RRP = 400,                            //债券逆回购(reverse repurchase agreement (RRP) or reverse repo)   
    -- OrderBusiness_BOND_CONVERTIBLE_BUY = 401,                //可转债申购(purchase)                                             
    -- OrderBusiness_BOND_CONVERTIBLE_CALL = 402,               //可转债转股                                                       
    -- OrderBusiness_BOND_CONVERTIBLE_PUT = 403,                //可转债回售                                                       
    -- OrderBusiness_BOND_CONVERTIBLE_PUT_CANCEL = 404          //可转债回售撤销
    entrust_type INT,
    -- 废单原因 
    cancel_info TEXT,
    -- 标的代码
    under_code TEXT,
    -- 备兑标记 '0' - 非备兑，'1' - 备兑
    covered_flag INT,
    -- 合约编号
    compact_no TEXT,
    -- 平仓盈亏
    pnl TEXT,
    -- 手续费
    commission TEXT,
    -- 创建时间
    auto_create_time TIMESTAMP DEFAULT (strftime('%s', 'now') * 1000),
    auto_update_time TIMESTAMP DEFAULT (strftime('%s', 'now') * 1000)
);
CREATE INDEX "entrust_insert_date" ON "zlt_entrust" ("insert_date");
CREATE INDEX "entrust_instrument_id" ON "zlt_entrust" ("instrument_id");
CREATE INDEX "entrust_order_status" ON "zlt_entrust" ("order_status");
DROP TABLE IF EXISTS zlt_trigger_recording;
-- 触发记录
CREATE TABLE zlt_trigger_recording (
    auto_id INTEGER PRIMARY KEY AUTOINCREMENT,
    -- 证券代码/合约代码
    code TEXT,
    -- 名称
    cname TEXT,
    -- 触发动作
    t_type TEXT,
    -- 股东代码
    stk_account TEXT DEFAULT '',
    -- 市场
    market TEXT DEFAULT '',
    -- 委托类型
    trade_type TEXT DEFAULT '',
    -- 委托价格
    trade_price TEXT DEFAULT '',
    -- 委托数量
    trade_qty TEXT DEFAULT '',
    -- 触发时间（时间戳 ms）
    trigger_time TIMESTAMP,
    -- 创建时间
    auto_create_time TIMESTAMP DEFAULT (strftime('%s', 'now') * 1000),
    auto_update_time TIMESTAMP DEFAULT (strftime('%s', 'now') * 1000)
);
CREATE INDEX "zlt_trigger_time" ON "zlt_trigger_recording" ("trigger_time");
CREATE INDEX "zlt_trigger_code" ON "zlt_trigger_recording" ("trigger_code");


-- DROP TABLE IF EXISTS zlt_signal;
-- CREATE TABLE zlt_signal (
--     stock TEXT PRIMARY KEY,
--     time TEXT,
--     signal TEXT
-- );

-- 信号表
DROP TABLE IF EXISTS zlt_signal;
CREATE TABLE zlt_signal (
    auto_id INTEGER PRIMARY KEY AUTOINCREMENT,
    -- 标的
    stock TEXT NOT NULL DEFAULT '',
    -- 如果是0，则exval为解释对象字符串，非0 exval为值
    rtime TIMESTAMP NO DEFAULT 0,
    exval TEXT
);
CREATE INDEX "zlt_signal_idx_stock" ON "zlt_signal" ("stock");
CREATE INDEX "zlt_signal_idx_stock_auto_id" ON "zlt_signal" ("stock", "auto_id");

