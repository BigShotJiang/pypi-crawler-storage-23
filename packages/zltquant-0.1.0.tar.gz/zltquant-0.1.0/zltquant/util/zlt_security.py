from zltsdk import zltcalc
from . import zlt_object as zltObj
from .zlt_util import param_to_dt
from .zlt_zvector import zvector
from enum import Enum


class DP_INFO_TYPE(Enum):
    # 大盘信息
    CODE = 0  # 代码
    NAME = 1  # 名称


def deal_end_date(end_date, freq, security=None):
    """如果是daily数据,需要加上23:59:59"""
    if freq.endswith("d"):
        if isinstance(end_date, str) and len(end_date) == 10:
            date1 = param_to_dt(end_date + " 15:00:00")
            if zltObj._context.current_dt.timestamp() > date1.timestamp():
                end_date = end_date + " 23:59:59"
                return end_date
    return end_date


class Security:
    """Security类
    - secuirty: 证券代码
    - start_date: 开始日期
    - end_date: 结束日期
    - freq: 频率
    - count: 数量
    - fq: 复权方式
    - fill_suspend: 是否填充停牌数据
    - align: 对齐对象
    - paramsObj: 自定义参数对象(框架使用)
    """

    def __init__(
        self,
        security,
        start_date=None,
        end_date=None,
        freq=None,
        count=0,
        fq="pre",
        fill_suspend=False,
        align=None,
    ):
        if start_date is not None and count != 0:
            raise ValueError("start_date 和 count 不能同时被设置!")
        security = security.lower()
        if freq == None:  # 频率跟随策略频率
            strategy_freq = zltObj._context.backtest_param["frequency"]
            if strategy_freq == "min":
                freq = "1m"
            elif strategy_freq == "day":
                freq = "1d"
            else:
                freq = strategy_freq
        self.security = security  # 标的
        self.fq = fq  # 复权方式
        self.fill_suspend = fill_suspend  # 是否填充停牌数据
        self.freq = freq  # 频率
        if align:
            self.start_date = align.start_date
            self.end_date = align.end_date
            self.align_freq = align.freq
            self.count = align.count
            self.obj = zltcalc.SecurityObj(self.security, self.freq, align.obj)
        else:
            # 处理结束时间
            if end_date is None:
                # 结束时间跟随策略当前时间
                end_date = zltObj._context.current_dt.strftime("%Y-%m-%d %H:%M:%S")
            else:
                end_date = deal_end_date(end_date, freq, security)
                end_date = param_to_dt(end_date).strftime("%Y-%m-%d %H:%M:%S")
                # 检查结束时间不可以大于策略当前时间
                # end_date_ts = param_to_dt(
                #     end_date).timestamp()
                # if end_date_ts > zltObj._context.current_dt.timestamp():
                #     raise ValueError(
                #         'end_date 不能大于策略当前时间!')

            # 处理开始时间
            if start_date is None and count == 0:
                count = 30  # 默认往前200根Bar频率
                start_date = ""
            elif start_date is None and count != 0:
                start_date = ""
            else:
                start_date = param_to_dt(start_date).strftime("%Y-%m-%d %H:%M:%S")
                end_date_ts = param_to_dt(end_date).timestamp()
                start_date_ts = param_to_dt(start_date).timestamp()
                if start_date_ts > end_date_ts:
                    raise ValueError("start_date 不能大于 end_date!")
            # 属性赋值
            self.start_date = start_date
            self.end_date = end_date
            self.count = count
            self.obj = zltcalc.SecurityObj(
                self.security, self.start_date, self.end_date, self.freq, self.count
            )
        self.align = align

    def check_param(self, start_date, end_date, count, fq, fill_suspend):
        """检查参数
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        """
        if (start_date is not None and start_date != "") and count != 0:
            raise ValueError("start_date 和 count 不能同时被设置!")
        _end_date = end_date if end_date else self.end_date
        _fq = fq if fq else self.fq
        _start_date = start_date if start_date else self.start_date
        _count = count if count else self.count
        _fill_paused = fill_suspend if fill_suspend else self.fill_suspend
        # 如果开始时间存在,则count无效
        if start_date and self.count:
            _count = 0
        # 如果count存在,则开始时间无效
        if count and self.start_date:
            _start_date = None
        start_t = ""
        if _start_date != None and _start_date != "":
            start_t = param_to_dt(_start_date).strftime("%Y-%m-%d %H:%M:%S")
        end_t = param_to_dt(_end_date).strftime("%Y-%m-%d %H:%M:%S")
        return start_t, end_t, _count, _fq, _fill_paused

    def get_calc_data(
        self, func, start_date=None, end_date=None, count=0, fq=None, fill_suspend=False
    ):
        """获取指标数据"""
        end_date = deal_end_date(
            end_date if end_date else self.end_date, self.freq, self.security
        )
        _start_date, _end_date, _count, _fq, _fill_paused = self.check_param(
            start_date, end_date, count, fq, fill_suspend
        )
        ret = self.obj.Visit(
            func,
            self.security,
            _start_date,
            _end_date,
            _count,
            self.freq,
            _fq,
            _fill_paused,
        )
        return zvector(ret)

    def get_calc_data1(
        self,
        func,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        flag=False,
    ):
        """获取指标数据"""
        end_date = deal_end_date(
            end_date if end_date else self.end_date, self.freq, self.security
        )
        _start_date, _end_date, _count, _fq, _fill_paused = self.check_param(
            start_date, end_date, count, fq, fill_suspend
        )
        ret = self.obj.Visit(
            func,
            self.security,
            _start_date,
            _end_date,
            _count,
            self.freq,
            _fq,
            _fill_paused,
            flag,
        )
        return zvector(ret)

    def get_calc_data2(
        self,
        func,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        n=0,
    ):
        """获取指标数据"""
        end_date = deal_end_date(
            end_date if end_date else self.end_date, self.freq, self.security
        )
        _start_date, _end_date, _count, _fq, _fill_paused = self.check_param(
            start_date, end_date, count, fq, fill_suspend
        )
        ret = self.obj.Visit(
            func,
            self.security,
            _start_date,
            _end_date,
            _count,
            self.freq,
            _fq,
            _fill_paused,
            n,
        )
        return zvector(ret)

    def get_calc_data3(
        self,
        func,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        n=0,
    ):
        """获取指标数据"""
        end_date = deal_end_date(
            end_date if end_date else self.end_date, self.freq, self.security
        )
        _start_date, _end_date, _count, _fq, _fill_paused = self.check_param(
            start_date, end_date, count, fq, fill_suspend
        )
        ret = self.obj.GetIndexInfo(
            func, self.security, _start_date, _end_date, self.freq, _count
        )
        return zvector(ret)

    @property
    def index(self):
        return self.open.index

    @property
    def open(self):
        res = self.get_calc_data(
            "open",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def close(self):
        res = self.get_calc_data(
            "close",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def high(self):
        res = self.get_calc_data(
            "high",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def low(self):
        res = self.get_calc_data(
            "low",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def vol(self):
        res = self.get_calc_data(
            "volume",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def amount(self):
        res = self.get_calc_data(
            "amount",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def avg_price(self):
        res = self.get_calc_data(
            "avg_price",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def ups_and_downs(self):
        res = self.get_calc_data(
            "ups_and_downs",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def amplitude(self):
        res = self.get_calc_data(
            "amplitude",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def growth_price(self):
        res = self.get_calc_data(
            "growth_price",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def turnover_rate(self):
        res = self.get_calc_data(
            "shares",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def turnover_rate_z(self):
        res = self.get_calc_data(
            "free_shares",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def vol_ratio(self):
        res = self.get_calc_data2(
            "GetVolRatio",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
            n=5,
        )
        return res

    @property
    def ztprice(self):
        res = self.get_calc_data(
            "zt_price",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def dtprice(self):
        res = self.get_calc_data(
            "dt_price",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def is_down(self):
        res = self.get_calc_data(
            "is_down",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def is_up(self):
        res = self.get_calc_data(
            "is_up",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def is_equal(self):
        res = self.get_calc_data(
            "is_equal",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )
        return res

    @property
    def is_dt(self):
        res = self.get_calc_data1(
            "is_dt",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
            True,
        )
        return res

    @property
    def is_zt(self):
        return self.get_calc_data1(
            "is_zt",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
            True,
        )

    @property
    def index_c(self):
        return self.get_calc_data3(
            "close",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )

    @property
    def index_o(self):
        return self.get_calc_data3(
            "open",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )

    @property
    def index_h(self):
        return self.get_calc_data3(
            "high",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )

    @property
    def index_l(self):
        return self.get_calc_data3(
            "low",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )

    @property
    def index_v(self):
        return self.get_calc_data3(
            "volume",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )

    @property
    def index_a(self):
        return self.get_calc_data3(
            "amount",
            self.start_date,
            self.end_date,
            self.count,
            self.fq,
            self.fill_suspend,
        )

    def get_index_c(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取所属大盘收盘价"""
        return self.get_calc_data3(
            "close", start_date, end_date, count, fq, fill_suspend
        )

    def get_index_o(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取所属大盘开盘价"""
        return self.get_calc_data3(
            "open", start_date, end_date, count, fq, fill_suspend
        )

    def get_index_h(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取所属大盘最高价"""
        return self.get_calc_data3(
            "high", start_date, end_date, count, fq, fill_suspend
        )

    def get_index_l(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取所属大盘最低价"""
        return self.get_calc_data3("low", start_date, end_date, count, fq, fill_suspend)

    def get_index_v(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取所属大盘成交量"""
        return self.get_calc_data3(
            "volume", start_date, end_date, count, fq, fill_suspend
        )

    def get_index_a(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取所属大盘成交额"""
        return self.get_calc_data3(
            "amount", start_date, end_date, count, fq, fill_suspend
        )

    def get_open(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取开盘价
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        """
        return self.get_calc_data("open", start_date, end_date, count, fq, fill_suspend)

    def get_close(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取收盘价
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        """
        return self.get_calc_data(
            "close", start_date, end_date, count, fq, fill_suspend
        )

    def get_high(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取最高价
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        """
        return self.get_calc_data("high", start_date, end_date, count, fq, fill_suspend)

    def get_low(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取最低价
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fq: 复权方式
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        """
        return self.get_calc_data("low", start_date, end_date, count, fq, fill_suspend)

    def get_vol(
        self, start_date=None, end_date=None, count=0, fill_suspend=False, df=False
    ):
        """获取成交量
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        """
        return self.get_calc_data(
            "volume", start_date, end_date, count, self.fq, fill_suspend
        )

    def get_amount(
        self, start_date=None, end_date=None, count=0, fill_suspend=False, df=False
    ):
        """获取成交额
        - start_date: 开始日期
        - end_date: 结束日期
        - count: 数量
        - fill_suspend: 是否填充停牌数据
        - df: 是否返回dataframe
        """
        return self.get_calc_data(
            "amount", start_date, end_date, count, self.fq, fill_suspend
        )

    def get_avg_price(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取均价"""
        return self.get_calc_data(
            "avg_price", start_date, end_date, count, fq, fill_suspend
        )

    def get_ups_and_downs(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取涨跌(元)"""
        return self.get_calc_data(
            "ups_and_downs", start_date, end_date, count, fq, fill_suspend
        )

    def get_amplitude(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取振幅"""
        return self.get_calc_data(
            "amplitude", start_date, end_date, count, fq, fill_suspend
        )

    def get_growth_price(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取涨跌幅"""
        return self.get_calc_data(
            "growth_price", start_date, end_date, count, fq, fill_suspend
        )

    def get_turnover_rate(
        self,
        start_date=None,
        end_date=None,
        count=0,
        freq=None,
        fill_suspend=False,
        fq=None,
        df=False,
    ):
        """获取换手率"""
        return self.get_calc_data(
            "shares", start_date, end_date, count, fq, fill_suspend
        )

    def get_turnover_rate_z(
        self,
        start_date=None,
        end_date=None,
        count=0,
        freq=None,
        fill_suspend=False,
        fq=None,
        df=False,
    ):
        """获取自由流通股本换手率"""
        return self.get_calc_data(
            "free_shares", start_date, end_date, count, fq, fill_suspend
        )

    def get_growth_price_nday(
        self, n, start_date=None, end_date=None, count=0, fq=None, fill_suspend=True
    ):
        """近N日涨幅"""
        return self.get_calc_data2(
            "GetNDayGrowthPrice", start_date, end_date, count, fq, fill_suspend, n
        )

    def get_average_vol_nday(
        self, n, start_date=None, end_date=None, count=0, fq=None, fill_suspend=True
    ):
        """近N日平均成交量"""
        return self.get_calc_data2(
            "GetNDayAvgVol", start_date, end_date, count, fq, fill_suspend, n
        )

    def get_vol_ratio(
        self, start_date=None, end_date=None, count=0, fq=None, fill_suspend=True
    ):
        """获取量比"""
        return self.get_calc_data2(
            "GetVolRatio", start_date, end_date, count, fq, fill_suspend, n=5
        )

    def get_is_down(self, start_date=None, end_date=None, fq=None, count=0):
        """收阴"""
        return self.get_calc_data(
            "is_down", start_date, end_date, count, fq, fill_suspend=True
        )

    def get_is_up(self, start_date=None, end_date=None, fq=None, count=0):
        """收阳"""
        return self.get_calc_data(
            "is_up", start_date, end_date, count, fq, fill_suspend=True
        )

    def get_is_equal(self, start_date=None, end_date=None, fq=None, count=0):
        """收平"""
        return self.get_calc_data(
            "is_equal", start_date, end_date, count, fq, fill_suspend=True
        )

    def get_is_zt(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fill_suspend=False,
        exit=False,
        df=False,
    ):
        """是否涨停"""
        return self.get_calc_data1(
            "is_zt", start_date, end_date, count, self.fq, fill_suspend, exit
        )

    def get_is_dt(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fill_suspend=False,
        exit=False,
        df=False,
    ):
        """是否跌停"""
        return self.get_calc_data1(
            "is_dt", start_date, end_date, count, self.fq, fill_suspend, exit
        )

    #  ========== 财务数据 ==========

    def get_fin_data(
        self, start_date=None, end_date=None, count=0, fields=None, df=False
    ):
        """获取财务数据"""
        _start_date, _end_date, _count, _fq, _fill_paused = self.check_param(
            start_date, end_date, count, "", True
        )
        if isinstance(fields, str):
            fields = [fields]
        ret = self.obj.GetFinanceData(
            self.security, _start_date, _end_date, self.freq, _count, fields
        )
        return ret

    def get_ztprice(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=False,
        df=False,
    ):
        """获取涨停价"""
        return self.get_calc_data(
            "zt_price", start_date, end_date, count, fq, fill_suspend
        )

    def get_dtprice(
        self,
        start_date=None,
        end_date=None,
        count=0,
        fq=None,
        fill_suspend=True,
        df=False,
    ):
        """获取跌停价"""
        return self.get_calc_data(
            "dt_price", start_date, end_date, count, fq, fill_suspend
        )

    #  ========== 大盘相关 ==========
    def get_dpzs_code(self):
        """获取大盘指数代码"""
        return zltcalc.get_sec_dp_info(self.security, DP_INFO_TYPE.CODE.value)

    def get_dpzs_name(self):
        """获取大盘指数名称"""
        return zltcalc.get_sec_dp_info(self.security, DP_INFO_TYPE.NAME.value)

    def get_advance(self, start_date=None, end_date=None, count=0, freq=None, df=False):
        _start_date, _end_date, _count, _fq, _fill_paused = self.check_param(
            start_date, end_date, count, "none", True
        )
        ret = self.GetAdvance(self.security, _start_date, _end_date, self.freq, _count)
        return ret

    @property
    def ipo_date(self):
        """获取上市日期"""
        return zvector(
            self.obj.GetStatusData(
                "ipo_date", self.security, self.start_date, self.end_date, self.count
            )
        )

    @property
    def listing(self):
        """获取上市状态"""
        return zvector(
            self.obj.GetStatusData(
                "listing", self.security, self.start_date, self.end_date, self.count
            )
        )

    @property
    def suspend(self):
        """获取停牌状态"""
        return zvector(
            self.obj.GetStatusData(
                "suspend", self.security, self.start_date, self.end_date, self.count
            )
        )

    @property
    def st(self):
        """获取ST状态"""
        return zvector(
            self.obj.GetStatusData(
                "st", self.security, self.start_date, self.end_date, self.count
            )
        )

    @property
    def predelist(self):
        """获取退市整理"""
        return zvector(
            self.obj.GetStatusData(
                "predelist", self.security, self.start_date, self.end_date, self.count
            )
        )

    @property
    def delisted(self):
        """获取退市"""
        return zvector(
            self.obj.GetStatusData(
                "delisted", self.security, self.start_date, self.end_date, self.count
            )
        )

    # ========== 财务属性 ==========
    @property
    def rpt_update_time(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "rpt_update_time",
            )
        )

    @property
    def rpt_period(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "rpt_period",
            )
        )

    @property
    def net_assets(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "net_assets",
            )
        )

    @property
    def total_net_cf(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "total_net_cf",
            )
        )

    @property
    def div_ttm(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "div_ttm",
            )
        )

    @property
    def basic_eps(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "basic_eps",
            )
        )

    @property
    def eps_excl_nonrec(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "eps_excl_nonrec",
            )
        )

    @property
    def undist_profit_ps(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "undist_profit_ps",
            )
        )

    @property
    def nav_ps(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "nav_ps",
            )
        )

    @property
    def roe(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "roe",
            )
        )

    @property
    def op_cf_ps(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "op_cf_ps",
            )
        )

    @property
    def cash(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "cash",
            )
        )

    @property
    def accounts_recv(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "accounts_recv",
            )
        )

    @property
    def prepayments(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "prepayments",
            )
        )

    @property
    def inventory(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "inventory",
            )
        )

    @property
    def curr_assets(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "curr_assets",
            )
        )

    @property
    def long_recv(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "long_recv",
            )
        )

    @property
    def fixed_assets(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "fixed_assets",
            )
        )

    @property
    def goodwill(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "goodwill",
            )
        )

    @property
    def total_noncurr_assets(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "total_noncurr_assets",
            )
        )

    @property
    def total_assets(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "total_assets",
            )
        )

    @property
    def short_loans(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "short_loans",
            )
        )

    @property
    def accounts_pay(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "accounts_pay",
            )
        )

    @property
    def adv_from_cust(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "adv_from_cust",
            )
        )

    @property
    def curr_liab(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "curr_liab",
            )
        )

    @property
    def total_liab(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "total_liab",
            )
        )

    @property
    def paid_in_cap(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "paid_in_cap",
            )
        )

    @property
    def undist_profit(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "undist_profit",
            )
        )

    @property
    def minor_equity(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "minor_equity",
            )
        )

    @property
    def total_equity(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "total_equity",
            )
        )

    @property
    def parent_eq_bs(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "parent_eq_bs",
            )
        )

    @property
    def contract_liab(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "contract_liab",
            )
        )

    @property
    def op_rev(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "op_rev",
            )
        )

    @property
    def op_cost(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "op_cost",
            )
        )

    @property
    def op_profit(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "op_profit",
            )
        )

    @property
    def total_profit(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "total_profit",
            )
        )

    @property
    def profit_aft_tax(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "profit_aft_tax",
            )
        )

    @property
    def net_profit(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "net_profit",
            )
        )

    @property
    def rnd_exp(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "rnd_exp",
            )
        )

    @property
    def net_op_cf(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "net_op_cf",
            )
        )

    @property
    def net_inv_cf(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "net_inv_cf",
            )
        )

    @property
    def current_ratio(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "current_ratio",
            )
        )

    @property
    def quick_ratio(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "quick_ratio",
            )
        )

    @property
    def cash_ratio(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "cash_ratio",
            )
        )

    @property
    def ar_turnover_ratio(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "ar_turnover_ratio",
            )
        )

    @property
    def inv_turnover_ratio(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "inv_turnover_ratio",
            )
        )

    @property
    def wc_turnover_ratio(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "wc_turnover_ratio",
            )
        )

    @property
    def total_asset_turnover(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "total_asset_turnover",
            )
        )

    @property
    def fixed_asset_turnover(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "fixed_asset_turnover",
            )
        )

    @property
    def op_profit_margin(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "op_profit_margin",
            )
        )

    @property
    def gross_profit_margin(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "gross_profit_margin",
            )
        )

    @property
    def net_profit_excl(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "net_profit_excl",
            )
        )

    @property
    def ebit(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "ebit",
            )
        )

    @property
    def ebitda(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "ebitda",
            )
        )

    @property
    def net_op_cf_to_op_rev(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "net_op_cf_to_op_rev",
            )
        )

    @property
    def net_cf_ps(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "net_cf_ps",
            )
        )

    @property
    def net_op_cf_to_net_profit(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "net_op_cf_to_net_profit",
            )
        )

    @property
    def total_shares(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "total_shares",
            )
        )

    @property
    def shareholders_num(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "shareholders_num",
            )
        )

    @property
    def shares_top10_circ_sh(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "shares_top10_circ_sh",
            )
        )

    @property
    def shares_top10_sh(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "shares_top10_sh",
            )
        )

    @property
    def free_shares(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "free_shares",
            )
        )

    @property
    def total_inst_shares(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "total_inst_shares",
            )
        )

    @property
    def qfii_shares(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "qfii_shares",
            )
        )

    @property
    def brokerage_shares(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "brokerage_shares",
            )
        )

    @property
    def fund_shares(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "fund_shares",
            )
        )

    @property
    def social_security_shares(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "social_security_shares",
            )
        )

    @property
    def national_team_shares(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "national_team_shares",
            )
        )

    @property
    def northbound_funds_shares(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "northbound_funds_shares",
            )
        )

    @property
    def employees_num(self):
        return zvector(
            self.obj.GetFinanceData(
                self.security,
                self.start_date,
                self.end_date,
                self.freq,
                self.count,
                "employees_num",
            )
        )
