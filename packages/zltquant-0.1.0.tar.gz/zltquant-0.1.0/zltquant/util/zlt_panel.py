import zltsdk.zltcalc as zltcalc
import numpy as np
import pandas as pd
from .zlt_zvector import *
from .zlt_zmatrix import *


class ZPanelGroupBy:
    def __init__(self, vec, index=None):
        if(isinstance(vec,zltcalc.ZPanelGroupBy)):
            self._group=vec
        # elif(isinstance(index, list)):
        #     self._group=zltcalc.ZPanelGroupBy.zpanel_to_group(vec._panel,index)
        else:
            raise TypeError("Unsupported data type")
    
    def agg(self, opera,ddof=True):
        '''
        将Panel分组之后的ZPanelGroupBy对象进行聚合运算.
        
        用法:
            ZPanelGroupBy.agg(opera,ddof)

        参数:
            opera(str,dict):opera,支持的聚合函数有："sum","mean","min","max","count","std","var","median".
            ddof(bool):在对std或var计算时,ddof=1时,使用样本标准差/样本方差,ddof=0时,使用总体标准差/方差.
        
        用法:
            ZPanelGroupBy.agg(opera,ddof)

        返回:
            Panel
        '''
        if(isinstance(opera,dict)):
            return zmatrix(self._group.agg_dict(list(opera.values()),list(opera.keys()),ddof))
        else:
            return zmatrix(self._group.agg(opera,ddof))

    def __getitem__(self, index):
        try:
            index_type=self._group.get_item_type()
            if(index_type=="int"):
                return ZVecGroupBy(self._group.getitem(index))
            elif(index_type=="float"):
                return ZVecGroupBy(self._group.getitem_float(index))
            elif (index_type=="str"):
                return ZVecGroupBy(self._group.getitem_str(index))
            else:
                raise TypeError("Unsupported data type while getitem in panel")
        except Exception as e:
            print("Warning:Cannot find column",index)



    
class Panel():
    def __init__(self, panel_ptr):
        self._panel = zltcalc.Panel(panel_ptr)

    @property
    def index(self):
        return self._panel.index()
    @property
    def col_name(self):
        return np.array(self._panel.col_name())


# region panel_func
    def col(self, col_name):
        '''
        返回对应列名的zvector,如果传入多列返回Panel
        
        用法:
            Panel.col(col_name)
            Panel.col([col_name1,col_name2])
        
        参数:
            col_name(str,list):列名
        
        返回:
            zvector,Panel
        '''
        if(isinstance(col_name, str)):
            return zvector(self._panel.col(col_name))
        else:
            return Panel(self._panel.cols(col_name))
    
    def icol(self, col_index):
        '''
        返回列对应位置的zvector,从0开始,传入多个位置则返回Panel
        
        用法:
            ZPanel.icol(n)
            ZPanel.icol([n1,n2])

        例如:
            ZPanel.icol(0) 返回第一列的zvector
        
        参数:
            n(int,list):第几列
        
        返回:
            zvector,Panel
        '''
        if(isinstance(col_index,int)):
            return zvector(self._panel.icol(col_index))
        else:
            return Panel(self._panel.icols(col_index))
    
    def row(self, index):
        '''
        返回对应行的zvector,如果传入多行返回Panel
        
        用法:
            Panel.row(index)
            Panel.row([index1,index2])])
        
        参数:
            index:股票的对应代码或者对应代码的list
        
        返回:
            zvector,Panel
        '''
        if(isinstance(index, str)):
            return zvector(self._panel.row(index))
        else:
            return Panel(self._panel.rows(index))
        
    def irow(self, row_index):
        '''
        返回行对应位置的zvector,从0开始,传入多个位置则返回Panel
        
        用法:
            ZPanel.irow(n)
            ZPanel.irow([n1,n2])
        
        参数:
            n(int,list):第几行
        
        返回:
            zvector,Panel
        '''
        if(isinstance(row_index,int)):
            return zvector(self._panel.irow(row_index))
        else:
            return Panel(self._panel.irows(row_index))

    def count(self):
        '''
        返回Panel中每列zvector的元素个数
        
        用法:
            Panel.count()
        
        返回:
            zvector
        '''
        return zvector(self._panel.count())
    
    def median(self):
        '''
        返回Panel中每列zvector的中位数
        
        用法:
            Panel.median()
        
        返回:
            zvector
        '''
        return zvector(self._panel.median())
    
    def max(self):
        '''
        返回Panel中每列zvector的最大值
        
        用法:
            Panel.max()
        
        返回:
            zvector
        '''
        return zvector(self._panel.max())

    def min(self):
        '''
        返回Panel中每列zvector的最小值
        
        用法:
            Panel.min()
        
        返回:
            zvector
        '''
        return zvector(self._panel.min())

    def head(self, n):
        '''
        返回Panel每列前n个元素组成的Panel
        
        用法:
            Panel.head(n)
            
        参数:
            n(int):返回前n个元素
        
        返回:
            Panel
        '''
        return Panel(self._panel.head(n))

    def tail(self, n):
        '''
        返回Panel每列后n个元素组成的Panel
        
        用法:
            Panel.tail(n)
            
        参数:
            n(int):返回前n个元素
        
        返回:
            Panel
        '''
        return Panel(self._panel.tail(n))

    def sum(self):
        '''
        返回Panel中每列zvector的总和
        
        用法:
            Panel.sum()
        
        返回:
            zvector
        '''
        return zvector(self._panel.sum())
    
    def mean(self):
        '''
        返回Panel中每列zvector的平均值
        
        用法:
            Panel.sum()
        
        返回:
            zvector
        '''
        return zvector(self._panel.mean())
    
    def std(self,ddof=True):
        '''
        返回Panel中每列zvector的标准差,默认返回样本标准差(ddof=1)
        
        用法:
            Panel.std(ddof)
        
        参数:
            ddof(bool):ddof=1,分母为n-1,返回样本标准差,ddof=0,分母为n,返回总体标准差
        
        返回:
            zvector
        '''
        return zvector(self._panel.std(ddof))
    
    def var(self,ddof=True):
        '''
        返回Panel中每列zvector的方差,默认返回样本方差(ddof=1)
        
        用法:
            Panel.std(ddof)
        
        参数:
            ddof(bool):ddof=1,分母为n-1,返回样本方差,ddof=0,分母为n,返回总体方差
        
        返回:
            zvector
        '''
        return zvector(self._panel.var(ddof))
    
    def rank(self,ascending=True):
        '''
        返回Panel中每列zvector中每个元素按照一定顺序排序的排名,默认为从小到大的排名
        
        用法:
            Panel.rank(ascending)
            
        参数:
            ascending(bool):ascending = True 为从小到大,ascending = False为从大到小
        
        返回:
            Panel
        '''
        return Panel(self._panel.rank(ascending))
    
    def nrank(self,n,ascending=True):
        '''
        返回Panel每列zvector中按照一定顺序排名第n个的元素,默认从小到大排序
        
        用法:
            Panel.idxnrank(n,ascending)
        
        参数:
            n(int):第几个
            ascending(bool):ascending = True 为从小到大,ascending = False为从大到小
        
        返回:
            zvector
        '''
        return zvector(self._panel.nrank(n,ascending))
    
    def quantile(self,n,ascending=True):
        '''
        返回Panel中每列zvector中处于n分位的元素,默认从小到大排序
        
        用法:
            Panel.quantile(n,ascending)
            
        参数:
            n(int):n分位,n只能为0~1或者在其间的小数,n=0 输出最小的元素,n=1 输出最大的元素
            ascending(bool):ascending = True 为从小到大,ascending = False为从大到小
        
        返回:
            zvector
        '''
        return zvector(self._panel.quantile(n,ascending))

    def idxnrank(self,n,ascending=True):
        '''
        返回Panel中每列zvector中按照一定顺序排名第n个的元素的索引
        
        用法:
            Panel.idxnrank(n,ascending)
        
        参数:
            n(int):第几个
            ascending(bool):ascending = True 为从小到大,ascending = False为从大到小
        
        返回:
            zvector
        '''
        return zvector(self._panel.idxnrank(n,ascending))
    
    def idxmax(self):
        '''
        返回Panel中每列zvector的最大值的索引
        
        用法:
            Panel.idxmax()
        
        返回:
            zvector
        '''
        return zvector(self._panel.idxmax())

    def idxmin(self):
        '''
        返回Panel中每列zvector的最小值的索引
        
        用法:
            Panel.idxmin()
        
        返回:
            zvector
        '''
        return zvector(self._panel.idxmin())

    def transform(self,func,inplace=False):
        '''
        对Panel执行传入的函数后返回一个相同形状的Panel
        
        用法:
            Panel.transform(func,inplace)
        
        参数:
            func(function):自定义的函数名字,用于转换单个数据的简单函数
            inplace(bool):True,直接在原Panel上进行操作,False,返回一个新Panel,默认为False

        返回:
            Panel
        '''
        if(inplace):
            self._panel.transform(func)
            return self
        else:
            return Panel(self._panel.transform_new(func))
    
    def to_ndarray(self):
        '''
        将Panel转为numpy.ndarray
        
        用法:
            Panel.to_ndarray()

        参数:
            Panel
        
        返回:
            numpy.ndarray
        '''
        # 转为ndarray时 由于C中数据组织形式,默认输出转置之后的ndarray
        # 返回原样需要再转置一次
        return self._panel.to_ndarray().T
    
    def to_dataframe(self):
        '''
        将zvector转为pandas.DataFrame
        
        用法:
            Panel.to_dataframe()

        参数:
            zvector
        
        返回:
            pandas.Series
        '''
        return pd.DataFrame(self._panel.to_ndarray().T, columns=self.col_name, index=self.index)

    def filter(self,arr):
        '''
        过滤掉Panel中每列zvector中值不符合条件的元素,返回相同类型的、由符合条件元素组成的新Panel
        
        用法:
            Panel.filter(arr)
        
        参数:
            arr(zvector,list,ndarray):长度必须与Panel中一列zvector的元素个数相等
        
        返回:
            Panel
        '''
        if(isinstance(arr, zvector)):
            return Panel(self._panel.filter(arr._zvector))
        else:
            return Panel(self._panel.filter(arr))

    def groupby(self,index):
        '''
        将数据(Panel)划分为不同的群体(group),分组后可进行agg操作
        
        用法:
            Panel.groupby(index)

        参数:
            index(list,ndarray,zvector):长度必须与Panel中一列zvector的元素个数相等
        
        返回:
            ZPanelGroupBy对象
        '''
        if(isinstance(index,zvector)):
            return ZPanelGroupBy(self._panel.groupby(index._zvector))
        elif(isinstance(index,np.ndarray)):
            return ZPanelGroupBy(self._panel.groupby(index.tolist()))
        elif(isinstance(index,str)):
            return ZPanelGroupBy(self._panel.groupby(self.col(index)._zvector))
        else:
            return ZPanelGroupBy(self._panel.groupby(index))
        
    def copy(self):
        '''
        返回Panel的副本
        
        用法:
            Panel.copy()
        
        返回:
            Panel
        '''
        return Panel(self._panel.deepcopy())
    
    def drop(self, col_name,inplace=False):
        '''
        删除对应列名zvector的列,返回相同类型的、已删除对应列名的Panel
        
        用法:
            Panel.drop(col_name)
        
        参数:
            col_name(str):列名
            inplace(bool):True,直接在原Panel上进行操作,False,返回一个新Panel,默认为False
                
        返回:
            Panel
        '''
        if(inplace):
            self._panel.drop(col_name)
            return self
        else:
            return Panel(self._panel.drop_new(col_name))
    
    def dropna(self,axis,how,inplace=False):
        '''
        删除Panel中的nan值(缺失值)
        
        用法:
            Panel.dropna(axis,how,inplace)
        
        参数:
            axis (bool):轴.0表示按行删除;1表示按列删除.
            how (str):筛选方式.'any',表示该行/列只要有一个以上的空值,就删除该行/列;'all',表示该行/列全部都为空值,就删除该行/列
            inplace(bool):True,直接在原Panel上进行操作,False,返回一个新Panel,默认为False
        返回:
            Panel
        '''
        if(inplace):
            self._panel = self._panel.dropna(axis,how)
            return self
        else:
            return Panel(self._panel.dropna_new(axis,how))
    
    def fillna(self,method=None,inplace=False):
        '''
        填充Panel中的nan值(缺失值)
        
        用法:
            Panel.fillna(method,inplace)
        
        参数:
            method('back', 'before',value): before表示用前一行的值填充当前行的空值,back表示用后一行的值填充当前行的空值.若前/后没有值时,用nan填充
            value (float):具体填充的值
            inplace(bool):True,直接在原Panel上进行操作,False,返回一个新Panel,默认为False
        返回:
            Panel
        '''
        if(method == None):
            raise ValueError("method can not be None in Panel.fillna")
        elif isinstance(method,str):
            if(inplace):
                self._panel = self._panel.fillna_method(method)
                return self
            else:
                return Panel(self._panel.fillna_method_new(method))
        else:
            if(inplace):
                self._panel = self._panel.fillna_value(method)
                return self
            else:
                return Panel(self._panel.fillna_value_new(method))
            
    def __getitem__(self, index):
        return self.col(index)
    
    def __setitem__(self, index, value):
        if(isinstance(value,zvector)):
            self._panel.__setitem__(index, value._zvector)
        else:
            self._panel.__setitem__(index, zvector(value)._zvector)
        return self
    
#endregion    

# region operator_overload
    def __str__(self) -> str:
        return self._panel.__str__()
    
    def __len__(self):
        return self._panel.__len__()
    
    def __add__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__add__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__add__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__add__(self._panel, other))
        
    def __radd__(self, other):
            return Panel(zltcalc.Panel.__radd__(self._panel, other))

    def __mul__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__mul__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__mul__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__mul__(self._panel, other))

    def __rmul__(self, other):
        return Panel(zltcalc.Panel.__add__(self._panel, other))

    def __sub__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__sub__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__sub__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__sub__(self._panel, other))

    def __rsub__(self, other):
        return Panel(zltcalc.Panel.__rsub__(self._panel, other))

    def __truediv__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__truediv__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__truediv__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__truediv__(self._panel, other))

    def __rtruediv__(self, other):
        return Panel(zltcalc.Panel.__rtruediv__(self._panel, other))

    def __floordiv__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__floordiv__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__floordiv__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__floordiv__(self._panel, other))

    def __rfloordiv__(self, other):
        return Panel(zltcalc.Panel.__rfloordiv__(self._panel, other))

    def __pow__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__pow__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__pow__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__pow__(self._panel, other))
        
    def __rpow__(self, other):
        return Panel(zltcalc.Panel.__rpow__(self._panel, other))

    def __mod__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__mod__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__mod__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__mod__(self._panel, other))
        
    def __rmod__(self, other):
        return Panel(zltcalc.Panel.__rmod__(self._panel, other))

    def __eq__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__eq__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__eq__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__eq__(self._panel, other))
        
    def __req__(self, other):
        return Panel(zltcalc.Panel.__req__(self._panel, other))

    def __ne__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__ne__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__ne__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__ne__(self._panel, other))

    def __rne__(self, other):
        return Panel(zltcalc.Panel.__rne__(self._panel, other))
    
    def __gt__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__gt__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__gt__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__gt__(self._panel, other))
        
    def __rgt__(self, other):
        return Panel(zltcalc.Panel.__rgt__(self._panel, other))
    
    def __lt__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__lt__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__lt__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__lt__(self._panel, other))

    def __rlt__(self, other):
        return Panel(zltcalc.Panel.__rlt__(self._panel, other))
    
    def __ge__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__ge__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__ge__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__ge__(self._panel, other))
        
    def __rge__(self, other):
        return Panel(zltcalc.Panel.__rge__(self._panel, other))

    def __le__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__le__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__le__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__le__(self._panel, other))

    def __rle__(self, other):
        return Panel(zltcalc.Panel.__rle__(self._panel, other))

    def __and__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__and__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__and__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__and__(self._panel, other))

    def __rand__(self, other):
        return Panel(zltcalc.Panel.__rand__(self._panel, other))

    def __or__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__or__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__or__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__or__(self._panel, other))

    def __ror__(self, other):
        return Panel(zltcalc.Panel.__ror__(self._panel, other))
    
    def __xor__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__xor__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__xor__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__xor__(self._panel, other))
        
    def __rxor__(self, other):
        return Panel(zltcalc.Panel.__rxor__(self._panel, other))
    
    def __invert__(self):
        return Panel(zltcalc.Panel.__invert__(self._panel))
    
    def __rshift__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__rshift__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__rshift__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__rshift__(self._panel, other))
        
    def __rrshift__(self, other):
        return Panel(zltcalc.Panel.__rrshift__(self._zvector, other))

    def __lshift__(self, other):
        if(isinstance(other, Panel)):
            return Panel(zltcalc.Panel.__lshift__(self._panel, other._panel))
        elif(isinstance(other,zvector)):
            return Panel(zltcalc.Panel.__lshift__(self._panel, other._zvector,True))
        else:
            return Panel(zltcalc.Panel.__lshift__(self._panel, other))
        
    def __rlshift__(self, other):
        return Panel(zltcalc.Panel.__rlshift__(self._zvector, other))
# endregion