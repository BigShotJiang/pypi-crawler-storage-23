"""
查询指数相关数据
"""

__version__ = "0.0.1"
__author__ = "zltChenXingHua"

import glob
from operator import eq, ge, gt, le, lt
import re
import pandas as pd
from sqlalchemy import (
    Column,
    Integer,
    Text,
    create_engine,
)
from sqlalchemy.ext.horizontal_shard import ShardedSession
from sqlalchemy.orm import sessionmaker, declarative_base
from . import zlt_others as zltOthers
from . import zlt_object as zltObj
from .zlt_util import param_to_dt, get_install_path, deal_special_index_code
import zltsdk.strategy_bridge as strategy_bridge


# 创建基类
Base = declarative_base()


class IndexWide(Base):
    """指数成分"""

    __tablename__ = "index_const_wide"

    date = Column(Integer, primary_key=True)
    index_code = Column(Text, primary_key=True)
    stock_code = Column(Text)
    weight = Column(Text)


def read_databases(path):
    db_path = f"{path}\index_const_wide_*.db3"
    # 获取所有匹配的数据库文件
    db_files = glob.glob(db_path)

    if not db_files:
        print(f"{path}路径下未加载到指数权重数据")
        zltOthers.system_log.error(f"{path}路径下未加载到指数权重数据")
        return None, None
    shards = {}
    shards_list = []

    for db_file in db_files:
        match = re.search("index_const_wide_(\w{4})", db_file)
        year = match.group(1)
        shards[int(year)] = create_engine(f"sqlite:///{db_file}")
        shards_list.append(int(year))
        pass
    return shards, shards_list


install_path = get_install_path()
shards, shard_year = read_databases(
    "{}\Public\quantdata\libmr_data\db".format(install_path)
)


# 分片选择器
def shard_chooser(mapper, instance, clause=None):
    return


# ID选择器
def identity_chooser(mapper, primary_key, *, query_chooser, **kw):
    return


# 分片查询器
def quick_query_chooser(query, shard_year):
    if hasattr(query.whereclause, "clauses"):
        begin = end = -1
        for clause in query.whereclause.clauses:
            key = clause.left.key
            op = clause.operator
            if key == "date":
                if op == gt or op == ge:
                    begin = int(clause.right.value / 10000)
                elif op == lt or op == le:
                    end = int(clause.right.value / 10000)
                elif op == eq:
                    begin = end = int(clause.right.value / 10000)
        if begin == end and end == -1:
            return shard_year
        elif begin <= end:
            target = [x for x in shard_year if begin <= x <= end]
            return target
        else:
            return shard_year
    else:
        if hasattr(query.whereclause, "left"):
            key = query.whereclause.left.key
            if key == "date":
                op = query.whereclause.operator
                if op == gt or op == ge:
                    target = [
                        x
                        for x in shard_year
                        if x >= int(query.whereclause.right.value / 10000)
                    ]
                    return target
                elif op == lt or op == le:
                    target = [
                        x
                        for x in shard_year
                        if x <= int(query.whereclause.right.value / 10000)
                    ]
                    return target
                elif op == eq:
                    target = [
                        x
                        for x in shard_year
                        if x == int(query.whereclause.right.value / 10000)
                    ]
                    return target
    return shard_year


def query_chooser(query):
    return quick_query_chooser(query, shard_year)


session = None

if shards:
    sessionMk = sessionmaker(
        class_=ShardedSession,
        shards=shards,
        shard_chooser=shard_chooser,
        identity_chooser=identity_chooser,
        query_chooser=query_chooser,
    )

    session = sessionMk()


def get_index_stocks(index_code, date=None) -> list:
    """获取指数成份股

    参数:
    - index_symbol: 指数代码
    - date: 查询日期

    返回:list
    - 股票集合
    """
    if session is None:
        raise Exception("指数权重数据未加载")
    index_code = deal_special_index_code(index_code)
    if date is None:
        date = int(zltObj._context.current_dt.strftime("%Y%m%d"))
    else:
        date = int(param_to_dt(date).strftime("%Y%m%d"))
    db_result = (
        session.query(IndexWide.date, IndexWide.stock_code, IndexWide.weight)
        .filter(IndexWide.index_code == index_code, IndexWide.date <= date)
        .order_by(IndexWide.date.asc())
        .all()
    )
    if len(db_result) == 0:
        return []
    result = db_result[-1]
    stock_code = result[1].split(",")
    return stock_code


def get_index_weights(index_code, date=None):
    """获取指数成分股权重

    参数:
    - index_id: 指数代码
    - date: 查询日期

    返回:
    - code:股票代码
    - date:日期
    - weight:权重
    """
    if session is None:
        raise Exception("指数权重数据未加载")
    index_code = deal_special_index_code(index_code)
    if date is None:
        date = int(zltObj._context.current_dt.strftime("%Y%m%d"))
    else:
        date = int(param_to_dt(date).strftime("%Y%m%d"))
    db_result = (
        session.query(IndexWide.date, IndexWide.stock_code, IndexWide.weight)
        .filter(IndexWide.index_code == index_code, IndexWide.date <= date)
        .order_by(IndexWide.date.asc())
        .all()
    )
    if len(db_result) == 0:
        return pd.DataFrame()
    result = db_result[-1]
    stock_code = result[1].split(",")
    weight = result[2].split(",")
    data = pd.DataFrame({"security": stock_code, "weight": weight})
    data.set_index("security", inplace=True)
    return data


def get_all_index(date=None):
    """获取当前平台支持的指数列表
    参数:
    - date 截止时间

    返回:
    - index_code:指数代码
    - index_name:指数名称
    - start_date:调入时间
    - end_date:调出时间

    """
    if date is None:
        date = int(zltObj._context.current_dt.timestamp())
    else:
        date = int(param_to_dt(date).timestamp())
    data = strategy_bridge.GetIndexList(date)
    df = pd.DataFrame(data, columns=["", "index_name", "start_date", "end_date"])
    df.set_index("", inplace=True)
    df["start_date"] = df["start_date"].apply(
        lambda x: None if x == "0" else param_to_dt(str(x)).date()
    )
    df["end_date"] = df["end_date"].apply(
        lambda x: None if x == "0" else param_to_dt(str(x)).date()
    )

    return df


def get_index(security=None, date=None):
    """获取标的所属指数

    参数:
    - security: 标的代码 str/list[str]
    - date: 查询日期

    返回:
    - 指数
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise Exception("请指定股票池!")
        security = list(zltObj._context.universe)
    timestamp = 0
    if isinstance(security, str):
        security = [security]
    if date is None:
        timestamp = int(zltObj._context.current_dt.timestamp())
        date = int(zltObj._context.current_dt.strftime("%Y%m%d"))
    else:
        timestamp = int(param_to_dt(date).timestamp())
        date = int(param_to_dt(date).strftime("%Y%m%d"))

    data = strategy_bridge.GetIndexBySecurity(security, date, timestamp)
    df = pd.DataFrame(data, columns=["security", "index_code", "index_name"])
    df.set_index("security", inplace=True)
    df.index.name = None
    return df


def get_index_stats(index_code, date=None):
    """获取指数统计数据

    参数:
    - index_id: 指数代码
    - date: 查询日期

    返回:
    - code:股票代码
    """
    pass


__all__ = ["get_index_stocks", "get_index_weights", "get_all_index", "get_index"]

# 查询指数成分股
if 0:
    q = session.query(IndexWide.stock_code, IndexWide.weight, IndexWide.date).filter(
        IndexWide.date > 20250501, IndexWide.index_code == "sz399300"
    )
    df = pd.DataFrame(q.all())
    print(df)
