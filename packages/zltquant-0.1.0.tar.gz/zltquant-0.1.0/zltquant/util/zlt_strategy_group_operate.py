'''
子账户操作
'''

from .zlt_object import SubPortfolio
from . import zlt_object as zltObj



def set_subportfolios(SubPortfolios):
    """初始化策略子账户

    参数:
    - SubPortfolios:子账户对象
    """
    for index, val in enumerate(SubPortfolios):
        cash = val["cash"]
        type = val["type"]
        if index == 0:
            zltObj._context.subportfolios[0] = SubPortfolio(
                inout_cash=cash,
                available_cash=cash,
                transferable_cash=cash,
                pindex=index,
                locked_cash=0,
                type=type,
                total_value=cash,
            )
        else:
            zltObj._context.subportfolios.append(
                SubPortfolio(
                    inout_cash=cash,
                    available_cash=cash,
                    transferable_cash=cash,
                    pindex=index,
                    locked_cash=0,
                    type=type,
                    total_value=cash,
                )
            )


def SubPortfolioConfig(cash, type):
    """子账号配置

    参数:
    - cash: 仓位初始资金
    - type: 可操作标的的类型，'stock' / 'index_futures' / 'futures' / 'stock_margin' / 其中 stock 包括股票和基金，index_futures 指金融期货，futures 包含股指期货和商品期货，stock_margin 为融资融券账户
    """
    return {"cash": cash, "type": type}


def transfer_cash(from_pindex, to_pindex, cash):
    """账户间转移资金

    参数:
    - from_pindex:从子账号
    - to_pindex:到子账号
    - cash:金额
    """
    pass


__all__ = ["set_subportfolios"]
