PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS zlt_tmp_daily_position_profit;
-- 持仓(用于模拟环境获取最新持仓)
CREATE TABLE zlt_tmp_daily_position_profit (
    -- 回测 ID
    backtest_id TEXT,
    -- 资金账号ID
    account_id TEXT,
    -- 日期
    date TIMESTAMP,
    -- 证券市场
    exchange_id TEXT,
    -- 交易市场
    exchange_name TEXT,
    -- 品种代码
    product_id TEXT,
    -- 品种名称
    product_name TEXT,
    -- 证券代码
    instrument_id TEXT,
    -- 证券名称，合约名称
    instrument_name TEXT,
    -- 多空
    direction TEXT,
    -- 数量
    quantity TEXT,
    -- 可用数量
    available_quantity TEXT,
    -- 开盘价
    open_price TEXT,
    -- 收盘价/结算价
    close_price TEXT,
    -- 市值/价值
    market_value TEXT,
    -- 盈亏/逐笔浮盈
    profit TEXT,
    -- 开仓均价
    open_avg_price TEXT,
    -- 持仓均价(期货)
    position_avg_price TEXT,
    -- 保证金
    margin TEXT,
    -- 当日盈亏(浮盈)
    daily_pnl TEXT,
    -- 今手数
    today_quantity TEXT,
    -- 仓位占比
    position_ratio TEXT,
    -- 盈亏占比
    pnl_ratio TEXT,
    -- 合计买金额（不含手续费）
    total_buy TEXT,
    -- 合计卖金额（不含手续费）
    total_sell TEXT,
    -- 创建时间
    auto_create_time TIMESTAMP DEFAULT (strftime('%s', 'now') * 1000),
    auto_update_time TIMESTAMP DEFAULT (strftime('%s', 'now') * 1000)
);

DROP TABLE IF EXISTS zlt_tmp_entrust;
-- 委托单(用于仿真或者实盘获取最新委托列表)
CREATE TABLE zlt_tmp_entrust (
    -- 回测ID
    backtest_id TEXT,
    -- 资金账号ID
    account_id TEXT,
    -- 证券市场
    exchange_id TEXT,
    -- 交易市场
    exchange_name TEXT,
    -- 品种代码
    product_id TEXT,
    -- 品种名称
    product_name TEXT,
    -- 证券代码
    instrument_id TEXT,
    -- 证券名称，合约名称
    instrument_name TEXT,
    -- 任务号
    task_id INT,
    -- 内部委托号，下单引用等于股票的内部委托号
    order_ref TEXT,
    -- 委托价格类型，例如市价单、限价单
    -- OrderType_Unknown = 0,
    -- OrderType_Limit = 1,                                     //限价委托
    -- OrderType_Market = 2,                                    //市价委托
    -- OrderType_Stop = 3,                                      //止损止盈委托
    order_price_type TEXT,
    -- 操作，多空，期货多空，股票买卖永远是 48，其他的 dir 同理
    -- OrderSide_Unknown = 0,
    -- OrderSide_Buy = 1,                                       //买入
    -- OrderSide_Sell = 2,                                      //卖出
    direction TEXT,
    -- 操作，期货开平，股票买卖其实就是开平
    offset_flag TEXT,
    -- 投保
    hedge_flag TEXT,
    -- 委托价格,限价单的限价，就是报价
    limit_price TEXT,
    -- 委托量，最初委托量
    volume_total_original TEXT,
    -- 报单状态，提交状态，股票中不需要报单状态
    order_submit_status TEXT,
    -- 合同编号，委托号
    order_sys_id TEXT,
    -- 委托状态 	
    -- ORDER_PREPARE = 1,//待申报 尚未成交
    -- ORDER_ALREADY = 2,//已申报 
    -- ORDER_CANCEL = 3,//废单
    -- ORDER_SHARE = 4,//送转股
    -- ORDER_UNFILLED = 5, //未成交
    -- ORDER_PARTIALLY_FILLED = 6,// 部分成交
    -- ORDER_PARTIALLY_CANCELLED = 7,// 部成部撤
    -- ORDER_FULLY_CANCELLED = 8,// 全部撤单
    -- ORDER_FULLY_FILLED = 9, // 全部成交
    order_status TEXT,
    -- 成交数量，已成交量
    volume_traded TEXT,
    -- 委托剩余量，当前总委托量，股票的含义是总委托量减去成交量
    volume_total TEXT,
    -- 状态信息 委托拒绝原因
    -- OrderRejectReason_Unknown = 0,                           //未知原因
    -- OrderRejectReason_RiskRuleCheckFailed = 1,               //不符合风控规则 
    -- OrderRejectReason_NoEnoughCash = 2,                      //资金不足
    -- OrderRejectReason_NoEnoughPosition = 3,                  //仓位不足
    -- OrderRejectReason_IllegalAccountId = 4,                  //非法账户ID
    -- OrderRejectReason_IllegalStrategyId = 5,                 //非法策略ID
    -- OrderRejectReason_IllegalSymbol = 6,                     //非法交易代码
    -- OrderRejectReason_IllegalVolume = 7,                     //非法委托量
    -- OrderRejectReason_IllegalPrice = 8,                      //非法委托价
    -- OrderRejectReason_AccountDisabled = 10,                  //交易账号被禁止交易
    -- OrderRejectReason_AccountDisconnected = 11,              //交易账号未连接
    -- OrderRejectReason_AccountLoggedout = 12,                 //交易账号未登录
    -- OrderRejectReason_NotInTradingSession = 13,              //非交易时段
    -- OrderRejectReason_OrderTypeNotSupported = 14,            //委托类型不支持
    -- OrderRejectReason_Throttle = 15,                         //流控限制
    -- OrderRejectReason_SymbolSusppended = 16,                 //交易代码停牌
    -- OrderRejectReason_Internal = 999,                        //内部错误
    -- CancelOrderRejectReason_OrderFinalized = 101,            //委托已完成
    -- CancelOrderRejectReason_UnknownOrder = 102,              //未知委托
    -- CancelOrderRejectReason_BrokerOption = 103,              //柜台设置
    -- CancelOrderRejectReason_AlreadyInPendingCancel = 104,    //委托撤销中
    error_id INT,
    -- 冻结金额，冻结保证金
    frozen_margin TEXT,
    -- 冻结手续费
    frozen_commission TEXT,
    -- 委托日期，报单日期
    insert_date TIMESTAMP,
    -- 委托时间
    insert_time TIMESTAMP,
    -- 最后更新时间/委托,撤单
    update_time TIMESTAMP,
    -- 成交均价
    traded_price TEXT,
    -- 已撤数量
    cancel_amount TEXT,
    -- 买卖标记，展示委托属性的中文
    opt_name TEXT,
    -- 成交金额，成交额，期货 = 均价 * 量 * 合约乘数
    trade_amount TEXT,
    -- 委托类别 OrderBusiness
    -- OrderBusiness_NORMAL = 0,                                //普通交易                                                           
    -- OrderBusiness_IPO_BUY = 100,                             //新股申购                                                         
    -- OrderBusiness_CREDIT_BOM = 200,                          //融资买入(buying on margin)                                       
    -- OrderBusiness_CREDIT_SS = 201,                           //融券卖出(short selling)                                          
    -- OrderBusiness_CREDIT_RSBBS = 202,                        //买券还券(repay share by buying share)                            
    -- OrderBusiness_CREDIT_RCBSS = 203,                        //卖券还款(repay cash by selling share)                            
    -- OrderBusiness_CREDIT_DRS = 204,                          //直接还券(directly repay share)                                   
    -- OrderBusiness_CREDIT_DRC = 211,                          //直接还款(directly repay cash)                                    
    -- OrderBusiness_CREDIT_CPOM = 205,                         //融资平仓(close position on margin)                               
    -- OrderBusiness_CREDIT_CPOSS = 206,                        //融券平仓(close position on short selling)                        
    -- OrderBusiness_CREDIT_BOC = 207,                          //担保品买入(buying on collateral)                                 
    -- OrderBusiness_CREDIT_SOC = 208,                          //担保品卖出(selling on collateral)                                
    -- OrderBusiness_CREDIT_CI = 209,                           //担保品转入(collateral in)                                        
    -- OrderBusiness_CREDIT_CO = 210,                           //担保品转出(collateral out)                                       
    -- OrderBusiness_ETF_BUY = 301,                             //ETF申购(purchase)                                                
    -- OrderBusiness_ETF_RED = 302,                             //ETF赎回(redemption)                                              
    -- OrderBusiness_FUND_SUB = 303,                            //基金认购(subscribing)                                            
    -- OrderBusiness_FUND_BUY = 304,                            //基金申购(purchase)                                               
    -- OrderBusiness_FUND_RED = 305,                            //基金赎回(redemption)                                             
    -- OrderBusiness_FUND_CONVERT = 306,                        //基金转换(convert)                                                
    -- OrderBusiness_FUND_SPLIT = 307,                          //基金分拆(split)                                                  
    -- OrderBusiness_FUND_MERGE = 308,                          //基金合并(merge)                                                  
    -- OrderBusiness_BOND_RRP = 400,                            //债券逆回购(reverse repurchase agreement (RRP) or reverse repo)   
    -- OrderBusiness_BOND_CONVERTIBLE_BUY = 401,                //可转债申购(purchase)                                             
    -- OrderBusiness_BOND_CONVERTIBLE_CALL = 402,               //可转债转股                                                       
    -- OrderBusiness_BOND_CONVERTIBLE_PUT = 403,                //可转债回售                                                       
    -- OrderBusiness_BOND_CONVERTIBLE_PUT_CANCEL = 404          //可转债回售撤销
    entrust_type INT,
    -- 废单原因 
    cancel_info TEXT,
    -- 标的代码
    under_code TEXT,
    -- 备兑标记 '0' - 非备兑，'1' - 备兑
    covered_flag INT,
    -- 合约编号
    compact_no TEXT,
    -- 平仓盈亏
    pnl TEXT,
    -- 手续费
    commission TEXT,
    -- 创建时间
    auto_create_time TIMESTAMP DEFAULT (strftime('%s', 'now') * 1000),
    auto_update_time TIMESTAMP DEFAULT (strftime('%s', 'now') * 1000)
);