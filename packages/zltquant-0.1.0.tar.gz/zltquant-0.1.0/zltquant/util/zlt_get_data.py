'''
获取行情相关数据
'''
import json
import pandas as pd
import zltsdk.strategy_bridge as strategy_bridge
from . import zlt_object as zltObj
from .zlt_object import Tick
from .zlt_util import DataType, StoreType, PeriodType, param_to_dt
from .hq_sdk_api import Bar, SecurityInfo, query_price
from datetime import datetime, date as Date
import numpy as np

new_dtype = [
    ("time", "<i8"),
    ("security", "<U8"),
    ("open", "<f4"),
    ("close", "<f4"),
    ("low", "<f4"),
    ("high", "<f4"),
    ("volume", "<f4"),
    ("money", "<f4"),
    ("pre_close", "<f4"),
    ("status", "<i8"),
    ("open_interest", "<f4"),
]


def get_price(
    security=None,
    start_date=None,
    end_date=None,
    frequency="daily",
    fields=None,
    skip_paused=False,
    fq="pre",
    fq_ref_date=None,
    count=0,
    fill_suspend=True,
    df=False,
    include_now=False,
):
    """获取历史K线数据

    参数:

    - security:标的代码 str|list[str]
    - start_date:开始时间,不能与count同时使用;支持类型:str, datetime, date
    - end_date:截止时间
    - frequency:数据频率 'Xm', 'Xd','daily'(等同于'1d'), 'minute'(等同于'1m'), X是一个正整数, 分别表示X天和X分钟
    - fields:['open', 'close', 'low', 'high', 'volume', 'money', 'pre_close', 'status','open_interest'], 其中status为1表示停牌
    - skip_paused:是否跳过不交易日期(包括停牌, 未上市或者退市后的日期)
    - fq:['pre','none','post'] 前复权 不复权 后复权。默认:前复权
    - count: 与 start_date 二选一，不可同时使用. 数量, 返回的结果集的行数, 即表示获取 end_date 之前几个 frequency 的数据
    - fill_suspend:对于停牌股票的价格处理,默认为True; True表示用pre_close价格填充; False 表示使用nan填充停牌的数据
    - df:True: DataFrame False:numpy。默认为False
    - include_now:是否包含当前时间,即用当前区间仅有的数据合成一根bar。 默认为False

    返回:

    - time:bar时间
    - open:开盘价
    - close:收盘价
    - high:最高价
    - low:最低价
    - volume:成交量
    - money:成交额
    - pre_close:昨收(日线)
    - status:是否停牌
    - open_interest:期权合约数量
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise Exception("请指定股票池!")
        security = list(zltObj._context.universe)
    if count != 0 and start_date != None:
        raise Exception("get_price 不能同时指定 start_date 和 count 两个参数")
    if end_date is None:
        end_date = zltObj._context.current_dt.strftime("%Y-%m-%d %H:%M:%S")
    if start_date is None:
        start_date = ""
    else:
        start_date = param_to_dt(start_date)
        start_date = start_date.strftime("%Y-%m-%d %H:%M:%S")
    end_date = param_to_dt(end_date)
    end_date = end_date.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(fields, str):
        fields = [fields]
    if fq == None:
        fq = "none"
    if zltObj.ex_context.fq_method:
        fq = zltObj.ex_context.fq_method
    if fq_ref_date is None:
        fq_ref_date = int(zltObj._context.current_dt.timestamp())
    else:
        fq_ref_date = int(param_to_dt(fq_ref_date).timestamp())
    if isinstance(security, list):
        arr = np.zeros(0, dtype=new_dtype)
        for sec in security:
            result = strategy_bridge.get_price_new(
                start_date,
                end_date,
                sec,
                frequency,
                fq,
                count,
                skip_paused,
                fill_suspend,
                include_now,
                fq_ref_date,
            )
            # 使用 astype 方法将数组转换为新类型
            converted_data = result.astype(new_dtype)
            # 解码 'security' 字段
            converted_data["security"] = np.char.decode(result["security"], "utf-8")
            arr = np.concatenate((arr, converted_data))
        final_fields = []
        if fields is not None:
            final_fields = ["time", "security"] + fields
            final_fields = list(dict.fromkeys(final_fields))
        final_ret = arr[final_fields] if fields is not None else arr
        if df:
            final_ret = pd.DataFrame(final_ret)
            # final_ret.set_index("security", inplace=True)
            # final_ret.set_index('time', inplace=True) # 耗时增加
            final_ret["time"] = final_ret["time"].apply(
                lambda x: datetime.fromtimestamp(x)
            )
            return final_ret
        else:
            return final_ret
    else:
        result = strategy_bridge.get_price_new(
            start_date,
            end_date,
            security,
            frequency,
            fq,
            count,
            skip_paused,
            fill_suspend,
            include_now,
            fq_ref_date,
        )

        # 使用 astype 方法将数组转换为新类型
        converted_data = result.astype(new_dtype)
        # 解码 'security' 字段
        converted_data["security"] = np.char.decode(result["security"], "utf-8")
        final_fields = []
        if fields is not None:
            final_fields = ["time"] + fields
            final_fields = list(dict.fromkeys(final_fields))
        final_ret = (
            converted_data[final_fields] if fields is not None else converted_data
        )
        if df:
            final_ret = pd.DataFrame(final_ret)
            final_ret["time"] = final_ret["time"].apply(
                lambda x: datetime.fromtimestamp(x)
            )
            return final_ret
        else:

            return final_ret


def get_zbar(
    security=None,
    start_date=None,
    end_date=None,
    frequency="daily",
    fields=None,
    skip_paused=False,
    fq="pre",
    fq_ref_date=None,
    count=0,
    fill_suspend=True,
    df=False,
    include_now=False,
    include_bidding=0,
):
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise Exception("请指定股票池!")
        security = list(zltObj._context.universe)
    if isinstance(security, str):
        security = [security]
    if start_date == None:
        start_ts = 0
    else:
        start_date = param_to_dt(start_date)
        start_ts = int(start_date.timestamp()) * 1000
    if end_date == None:
        end_date = zltObj._context.current_dt
    end_date = param_to_dt(end_date)
    end_ts = int(end_date.timestamp()) * 1000
    fq_type = 0
    if fq == "none":
        fq_type = 0
    elif fq == "post":
        fq_type = 1
    elif fq == "pre":
        fq_type = 2
    fq_ref_date = (
        int(param_to_dt(fq_ref_date).timestamp()) if fq_ref_date is not None else 0
    )
    result = strategy_bridge.GetPrice(
        security,
        start_ts,
        end_ts,
        count,
        fq_type,
        fq_ref_date,
        skip_paused,
        fill_suspend,
        include_now,
        include_bidding,
        frequency,
    )
    # 使用 astype 方法将数组转换为新类型
    converted_data = result.astype(new_dtype)
    # 解码 'security' 字段
    converted_data["security"] = np.char.decode(result["security"], "utf-8")
    final_ret = converted_data[fields] if fields is not None else converted_data
    if df:
        return pd.DataFrame(final_ret)
    return final_ret


def get_last_price(type="min", securities=None, df=False):
    """获取最新截面数据
    参数:
    - type:数据类型, 默认为"min", 可选"min"和"bar"和"tick"
    - securities:标的列表; 传空时查询全市场 str|list[str]
    - df:是否返回DataFrame, 默认为False
    """
    req_type = 1
    if securities is None:
        if len(zltObj._context.universe) == 0:
            raise Exception("请指定股票池!")
        securities = list(zltObj._context.universe)
    if type == "tick":
        if isinstance(securities, list) and len(securities) == 0:
            result = strategy_bridge.GetCurrentPriceTick()
        else:
            result = strategy_bridge.GetCurrentPriceTick(securities)
        if df:
            return pd.DataFrame(result)
        return result
    if type == "min":
        req_type = 1
    elif type == "bar":
        req_type = 2
    if isinstance(securities, list) and len(securities) == 0:
        result = strategy_bridge.GetCurrentPriceBar(req_type)
    else:
        result = strategy_bridge.GetCurrentPriceBar(req_type, securities)

    # 使用 astype 方法将数组转换为新类型
    converted_data = result.astype(new_dtype)
    # 解码 'security' 字段
    converted_data["security"] = np.char.decode(result["security"], "utf-8")
    if df:
        converted_data = pd.DataFrame(converted_data)
        return converted_data
    return converted_data


def history(
    count,
    unit="1d",
    field="close",
    security_list=None,
    df=True,
    skip_paused=False,
    fq="pre",
):
    """从当前时间(策略周期内)开始(不包括当前时间),获取历史数据,可查询多个标的单个数据字段

    参数:

    - count:获取数量
    - unit:数据频率 'Xm', 'Xd','daily'(等同于'1d'), 'minute'(等同于'1m'), X是一个正整数, 分别表示X天和X分钟
    - field:要获取的数据类型,包含:['open', 'close', 'low', 'high', 'volume', 'money', 'pre_close', 'status','open_interest']
    - security_list:要获取数据的股票列表;None表示查询context.universe中所有股票的数据,context.universe 需要使用set_universe进行设定,形如:set_universe(['sz000001', 'sh600000'])。
    - skip_paused: 是否跳过不交易日期(包括停牌, 未上市或者退市后的日期)
    - fq:['pre','none,'post'] 前复权 不复权 后复权. 默认为pre
    - df:True: 返回[pandas.DataFrame], 否则返回一个dict

    返回:
    - time:bar时间
    - open:开盘价
    - close:收盘价
    - high:最高价
    - low:最低价
    - volume:成交量
    - money:成交额
    - pre_close:昨收(日线)
    - status:是否停牌
    - open_interest:期权合约数量
    """
    end_date = zltObj._context.current_dt.strftime("%Y-%m-%d %H:%M:%S")

    if security_list is None:
        if len(zltObj._context.universe) == 0:
            raise Exception("请指定股票池!")
        security_list = list(zltObj._context.universe)

    arr = np.zeros(0, dtype=new_dtype)
    dict_result = {}
    fq_ref_date = int(datetime.now().timestamp())
    times = []
    include_now = True
    fill_suspend = True
    if isinstance(security_list, str):
        security_list = [security_list]

    for sec in security_list:
        result = strategy_bridge.get_price_new(
            "",
            end_date,
            sec,
            unit,
            fq,
            count,
            skip_paused,
            fill_suspend,
            include_now,
            fq_ref_date,
        )
        dict_result[sec] = result[field].tolist()

        # 使用 astype 方法将数组转换为新类型
        converted_data = result.astype(new_dtype)
        # 解码 'security' 字段
        converted_data["security"] = np.char.decode(result["security"], "utf-8")

        arr = np.concatenate((arr, converted_data))
        if not skip_paused and len(times) == 0:
            times = result["time"].tolist()
    if df:
        if not skip_paused:
            dict_result["time"] = times
        tmp = pd.DataFrame()
        for key in dict_result.keys():
            tmp = pd.concat([tmp, pd.DataFrame({key: dict_result[key]})], axis=1)
        if not skip_paused:
            tmp.set_index("time", inplace=True)
        tmp.index.name = None
        return tmp
    else:
        return dict_result


def attribute_history(
    security, count, unit="1d", fields=None, skip_paused=True, df=False, fq="pre"
):
    """描述:获取历史数据，可查询单个标的多个数据字段

    参数:

    - security:股票代码
    - count:获取数量
    - unit:数据频率 'Xm', 'Xd','daily'(等同于'1d'), 'minute'(等同于'1m'), X是一个正整数, 分别表示X天和X分钟
    - fields: 股票属性的list,包含：['open', ' close', 'low', 'high', 'volume', 'money', 'factor', 'high_limit',' low_limit', 'avg', ' pre_close', 'paused','open_interest']
    - skip_paused: 是否跳过不交易日期(包括停牌, 未上市或者退市后的日期)
    - fq:['pre','none,'post'] 前复权 不复权 后复权. 默认为pre
    - df:True: 返回[pandas.DataFrame], 否则返回一个dict

    返回:

    - time:bar时间
    - open:开盘价
    - close:收盘价
    - high:最高价
    - low:最低价
    - volume:成交量
    - money:成交额
    - factor:复权因子(暂不支持)
    - high_limit:涨停价(日线)
    - low_limit:跌停价(日线)
    - avg:均价
    - pre_close:昨收(日线)
    - paused:是否停牌
    - open_interest:期权合约数量
    """
    end_date = zltObj._context.current_dt.strftime("%Y-%m-%d %H:%M:%S")
    fq_ref_date = int(datetime.now().timestamp())
    fill_suspend = True
    include_now = True
    result = strategy_bridge.get_price_new(
        "",
        end_date,
        security,
        unit,
        fq,
        count,
        skip_paused,
        fill_suspend,
        include_now,
        fq_ref_date,
    )
    # 使用 astype 方法将数组转换为新类型
    converted_data = result.astype(new_dtype)
    # 解码 'security' 字段
    converted_data["security"] = np.char.decode(result["security"], "utf-8")
    if df:
        final_ret = (
            converted_data[["time"] + fields] if fields is not None else converted_data
        )
        final_ret = pd.DataFrame(final_ret)
        final_ret.set_index("time", inplace=True)
        return final_ret
    else:
        result_dict = {}
        if fields is None:
            for field in [
                "open",
                "close",
                "low",
                "high",
                "volume",
                "money",
                "factor",
                "high_limit",
                "low_limit",
                "avg",
                "pre_close",
                "paused",
                "open_interest",
            ]:
                result_dict[field] = converted_data[field]
        else:
            for field in fields:
                result_dict[field] = converted_data[field]
        return result_dict


def get_bars(
    security=None,
    count=0,
    unit="1d",
    fields=[
        "open",
        "close",
        "low",
        "high",
        "volume",
        "money",
        "pre_close",
        "status",
        "open_interest",
    ],
    include_now=False,
    end_dt=None,
    fq_ref_date=None,
    df=False,
):
    """获取历史数据(包含快照数据)，可查询单个或多个标的多个数据字段，返回数据格式为 numpy.ndarray或DataFrame

    参数:
    - security:标的代码 str/list[str]
    - count:获取数量
    - unit:数据频率 'Xm', 'Xd','daily'(等同于'1d'), 'minute'(等同于'1m'), X是一个正整数, 分别表示X天和X分钟
    - fields: 股票属性的list,包含：['open', 'close', 'low', 'high', 'volume', 'money',' pre_close', 'status', 'open_interest']
    - include_now: 取值True 或者False。 表示是否包含当前bar
    - end_dt:截止时间
    - fq_ref_date:复权基准日期，支持的类型为datetime.datetime或None,为None时为不复权数据。
    - df: 若是True, 返回[pandas.DataFrame], 否则返回一个numpy.ndarray

    返回:

    - time:bar时间
    - open:开盘价
    - close:收盘价
    - high:最高价
    - low:最低价
    - volume:成交量
    - money:成交额
    - pre_close:昨收(日线)
    - status:是否停牌
    - open_interest:期权合约数量
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise Exception("请指定股票池!")
        security = list(zltObj._context.universe)
    if isinstance(end_dt, datetime) or isinstance(end_dt, Date):
        end_dt = end_dt.strftime("%Y-%m-%d %H:%M:%S")
    if end_dt is None:
        end_dt = zltObj._context.current_dt.strftime("%Y-%m-%d %H:%M:%S")
    fq = "none"
    skip_paused = True
    fill_suspend = False
    include_now = True
    if fq_ref_date is None:
        fq = "pre"
        fq_ref_date = int(zltObj._context.current_dt.timestamp())
    else:
        fq = "pre"
        fq_ref_date = int(param_to_dt(fq_ref_date).timestamp())
    if isinstance(security, list):
        arr = np.zeros(0, dtype=new_dtype)
        for sec in security:
            result = strategy_bridge.get_price_new(
                "",
                end_dt,
                sec,
                unit,
                fq,
                count,
                skip_paused,
                fill_suspend,
                include_now,
                fq_ref_date,
            )
            # 使用 astype 方法将数组转换为新类型
            converted_data = result.astype(new_dtype)
            # 解码 'security' 字段
            converted_data["security"] = np.char.decode(result["security"], "utf-8")
            arr = np.concatenate((arr, converted_data))
        final_ret = arr[["time", "security"] + fields] if fields is not None else arr
        if df:
            final_ret = pd.DataFrame(final_ret)
            final_ret.set_index("time", inplace=True)
        return final_ret
    else:
        result = strategy_bridge.get_price_new(
            "",
            end_dt,
            security,
            unit,
            fq,
            count,
            skip_paused,
            fill_suspend,
            include_now,
            fq_ref_date,
        )
        # 使用 astype 方法将数组转换为新类型
        converted_data = result.astype(new_dtype)
        # 解码 'security' 字段
        converted_data["security"] = np.char.decode(result["security"], "utf-8")
        if df:
            final_ret = (
                converted_data[["time", "security"] + fields]
                if fields is not None
                else converted_data
            )
            final_ret = pd.DataFrame(final_ret)
            final_ret.set_index("time", inplace=True)
            return final_ret
        else:
            return (
                converted_data[["time", "security"] + fields]
                if fields is not None
                else converted_data
            )


def get_current_tick(security=None, date=None, df=False):
    """获取最新的 tick 数据

    参数:
    - security:标的代码
    - dt: datetime格式的时刻。指定时代表返回离指定时刻最近的一条tick。默认为None。
    - df: 默认为False,表示用Tick对象来封装tick数据,df=True的时候,tick数据使用dataframe返回。

    返回:
    Tick对象/pandas.Dataframe
    - time:tick时间
    - open:开盘价(暂未支持)
    - current:最新价
    - high:最高价
    - low:最低价
    - volume:成交总量
    - money:成交总金额
    - 报价:a1_v ~ a5_v, a1_p ~ a5_p, b1_p ~ b5_p, b1_v ~ b5_v
    - status:是否停盘(暂未支持)
    - num_trades:交易手数(暂未支持)
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise Exception("请指定股票池!")
        security = list(zltObj._context.universe)
    end_dt = zltObj._context.current_dt
    if date:
        end_dt = param_to_dt(date)
    end_date = end_dt.strftime("%Y%m%d%H%M%S")
    count = 1
    start_dt = ""
    dict_result = {}
    tmp_dict = {}
    if isinstance(security, str):
        security = [security]
    ts = int(end_dt.timestamp())
    today_ts = (ts - (ts + 8 * 60 * 60) % 86400) * 1000
    for sec in security:
        result = strategy_bridge.get_ticks(sec, start_dt, end_date, count, True)
        if len(result) and result[0]["time"] > today_ts:
            dict_result[sec] = Tick(
                sec,
                result[0]["time"],
                result[0]["current"],
                result[0]["open"],
                result[0]["high"],
                result[0]["low"],
                result[0]["volume"],
                result[0]["money"],
                result[0]["a1_v"],
                result[0]["a2_v"],
                result[0]["a3_v"],
                result[0]["a4_v"],
                result[0]["a5_v"],
                result[0]["a1_p"],
                result[0]["a2_p"],
                result[0]["a3_p"],
                result[0]["a4_p"],
                result[0]["a5_p"],
                result[0]["b1_v"],
                result[0]["b2_v"],
                result[0]["b3_v"],
                result[0]["b4_v"],
                result[0]["b5_v"],
                result[0]["b1_p"],
                result[0]["b2_p"],
                result[0]["b3_p"],
                result[0]["b4_p"],
                result[0]["b5_p"],
            )
            tmp_dict[sec] = result
        else:
            dict_result[sec] = None

    df_result = pd.DataFrame()
    if df:
        for key in tmp_dict.keys():
            # 1. 把 tmp_dict[key] 转成 DataFrame
            df_sec = pd.DataFrame(tmp_dict[key])

            # 2. 添加股票代码列（列名可自定义，如 "stock_code"）
            df_sec["stock_code"] = key

            # 3. 设置多级索引（股票代码 + 原索引）
            df_sec = df_sec.set_index(["stock_code", df_sec.index])

            df_sec.index.names = ["", ""]

            # 4. 合并到 df_result
            df_result = pd.concat([df_result, df_sec])

        return df_result
    else:
        return dict_result


def get_ticks(
    security=None,
    end_date="",
    start_date="",
    count=0,
    fields=None,
    df=False,
):
    """获取股票,期货,50ETF期权,股票指数及场内基金的实时及历史tick数据

    参数:
    - security:标的代码 str/list[str]
    - end_dt:截止时间
    - start_dt:开始时间
    - fields: 选择要获取的行情数据字段，默认为["time", "current", "high", "low", "volume", "money"], 默认的fields没有a1_v~a5_v等数据,需要这些字段的话,需要您在fields中自己添加,即可获取
    - skip:默认为True,过滤掉无成交变化的tick数据;当指定skip=False时,返回的tick数据会保留无成交有盘口变化的tick数据
    - df:默认为False,返回numpy.ndarray格式的tick数据;df=True的时候,返回pandas.Dataframe格式的数据。

    返回:
    numpy.ndarray/pandas.Dataframe
    - time:tick时间
    - open:开盘价(暂未支持)
    - current:最新价
    - high:最高价
    - low:最低价
    - volume:成交总量
    - money:成交总金额
    - 报价:a1_v ~ a5_v, a1_p ~ a5_p, b1_p ~ b5_p, b1_v ~ b5_v
    - status:是否停盘(暂未支持)
    - num_trades:交易手数(暂未支持)
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise Exception("请指定股票池!")
        security = list(zltObj._context.universe)
    if count != 0 and start_date != "":
        raise Exception("get_ticks 不能同时指定 start_date 和 count 两个参数")
    end_date = (
        param_to_dt(end_date).strftime("%Y-%m-%d %H:%M:%S")
        if end_date
        else zltObj._context.current_dt.strftime("%Y-%m-%d %H:%M:%S")
    )
    start_date = (
        param_to_dt(start_date).strftime("%Y-%m-%d %H:%M:%S") if start_date else ""
    )
    if fields is None:
        fields = ["time", "current", "high", "low", "volume", "money"]
    dict_result = {}
    if isinstance(security, str):
        security = [security]
    for sec in security:
        result = strategy_bridge.get_ticks(sec, start_date, end_date, count, False)
        dict_result[sec] = result[fields]
        pass

    df_result = pd.DataFrame()
    if df:
        for key in dict_result.keys():
            # 1. 把 dict_result[key] 转成 DataFrame
            df_sec = pd.DataFrame(dict_result[key])

            # 2. 添加股票代码列（列名可自定义，如 "stock_code"）
            if len(security) > 1:
                df_sec["stock_code"] = key

                # 3. 设置多级索引（股票代码 + 原索引）
                df_sec = df_sec.set_index(["stock_code", df_sec.index])

                df_sec.index.names = ["", ""]

            # 4. 合并到 df_result
            df_result = pd.concat([df_result, df_sec])

        return df_result
    else:
        return dict_result


class CurrentLazyDict(dict):
    """动态加载的字典对象"""

    def fetch_data(self, key):
        ansdata = query_price(key)
        is_st = ansdata.is_st
        high = ansdata.high_limit
        low = ansdata.low_limit
        pause = ansdata.paused
        is_st = ansdata.is_st
        open = ansdata.day_open
        name = ansdata.name.decode("gbk")
        last_price = ansdata.last_price if ansdata.last_price else ansdata.pre_close
        pre_close = ansdata.pre_close
        iopv = ansdata.iopv
        price_paces = ansdata.price_paces
        return Bar(
            round(last_price + 0.0001, price_paces),
            round(high + 0.0001, price_paces),
            round(low + 0.0001, price_paces),
            pause,
            is_st,
            round(open + 0.0001, price_paces),
            name,
            key,
            round(pre_close + 0.0001, price_paces),
            round(iopv + 0.0001, price_paces),
        )

    def __missing__(self, key):
        data = self.fetch_data(key)
        self[key] = data
        return data


def get_current_data():
    """获取当前时间的标的信息

    返回:dict:动态获取标的信息
        {
            last_price : 最新价
            high_limit: 涨停价
            low_limit: 跌停价
            paused: 是否停止或者暂停了交易, 当停牌、未上市或者退市后返回 True
            is_st: 是否是 ST(包括ST, *ST),是则返回 True,否则返回 False
            day_open: 当天开盘价
            name: 股票现在的名称, 可以用这个来判断股票当天是否是 ST, *ST, 是否快要退市
            industry_code: 股票现在所属行业代码(暂不支持)
        }
    """
    if zltObj._context.backtest_param["strategy_mode"] == "research":
        raise NotImplementedError("该功能不支持在研究模式下使用")
    symbol_data = CurrentLazyDict()
    return symbol_data


def get_extras(
    info: str,
    security_list,
    start_date="2015-01-01",
    end_date="2015-12-31",
    df: bool = True,
    count: int = None,
):
    """获取基金单位/累计净值，期货结算价/持仓量等

    参数:
    - info:获取类型['is_st', 'acc_net_value', 'unit_net_value', 'futures_sett_price', 'futures_positions', 'adj_net_value'] 中的一个
    - security_list:股票列表
    - start_date:开始时间
    - end_date:结束时间
    - df:

    返回:
    numpy.ndarray或pandas.Dataframe
    {
      is_st: 是否股改s, st,*st和退市整理期标的
      acc_net_value: 基金累计净值
      unit_net_value: 基金单位净值
      futures_sett_price: 期货结算价
      futures_positions: 期货持仓量
      adj_net_value: 场外基金的复权净值
    }
    """
    if security_list is None:
        if len(zltObj._context.universe) == 0:
            raise Exception("请指定股票池!")
        security_list = list(zltObj._context.universe)
    start_ts = int(param_to_dt(start_date).strftime("%Y%m%d"))
    end_ts = int(param_to_dt(end_date).strftime("%Y%m%d"))
    if count != None:
        start_ts = 0
    else:
        count = 0
    if info == "is_st":
        if df:
            ret = pd.DataFrame(
                strategy_bridge.TimeRangeST(security_list, start_ts, end_ts, count)
            )
            ret["time"] = [param_to_dt(str(ts)) for ts in ret["time"]]
            ret.set_index("time", inplace=True)
            ret.index.name = None
            return ret
        return strategy_bridge.TimeRangeST(security_list, start_ts, end_ts, count)
    pass


def finance_run_query(query_object):
    """查询深沪港通、股东信息、公司概况等数据"""

    return


def macro_run_query(query_object):
    """查询宏观经济数据，详细的数据字段"""
    return


def get_billboard_list(stock_list, start_date, end_date, count):
    """获取龙虎榜数据"""
    return


def get_locked_shares(stock_list, start_date, end_date, forward_count):
    """获取限售解禁数据"""
    return


def get_industry_stocks(industry_code, date=None):
    """获取行业成份股

    参数:
    - industry_code: 行业编码
    - date: 查询日期

    返回:list
    - 成分股列表
    """
    if date is None:
        date = int(zltObj._context.current_dt.timestamp())
    else:
        date = int(param_to_dt(date).timestamp())
    data = strategy_bridge.GetIndustryStock(industry_code, date)
    return data


def get_industry_stats(industry_code, date=None):
    """获取行业统计数据

    参数:
    - industry_code: 行业编码
    - date: 查询日期

    返回:
    - code:股票代码
    """
    pass


def get_all_industry(industry_class="sw_l1", date=None):
    """获取行业列表

    参数:
    - level:
        - sw_l1:申万一级
        - sw_l2:申万二级
        - sw_l3:申万三级
        - zx_l1:中信一级
        - zx_l2:中信二级
        - zx_l3:中信三级
    返回:
    pd
    """
    if date is None:
        date = int(zltObj._context.current_dt.timestamp())
    else:
        date = int(param_to_dt(date).timestamp())
    data = strategy_bridge.GetIndustryList(industry_class, date)
    df = pd.DataFrame(
        data, columns=["industry_code", "industry_name", "start_date"]
    ).set_index("industry_code")
    df["industry_name"] = df["industry_name"].apply(lambda x: x.decode("gbk"))
    df.index.name = None
    return df


def get_concepts():
    """获取概念列表

    参数：
    - 无

    返回:
    - code:概念代码
    - name:概念名称
    - start_date:概念发布时间
    """
    return


def get_security_info(security, date=None):
    """获取单个标的信息

    参数:
    - security: 证券代码

        xxxxxx.XSHG:沪市
        xxxxxx.XSHE:深市
    - date:查询日期,默认回测时间context.current_dt

    返回:
    SecurityInfo对象
    - security: 代码
    - display_name: 股票名称
    - start_date :上市日期
    - end_date: 退市日期
    - type: 标的类型
    """
    timestamp = 0
    if date is None:
        if zltObj._context.backtest_param["strategy_mode"] == "research":
            timestamp = 0
        else:
            timestamp = int(zltObj._context.current_dt.timestamp())
    else:
        timestamp = int(param_to_dt(date).timestamp())

    ret = strategy_bridge.get_security_info(security, timestamp)
    start_date = None
    if ret.start_date != 0:
        start_date = param_to_dt(str(ret.start_date))
    end_date = None
    if ret.end_date != 0:
        tmp = param_to_dt(str(ret.end_date))
        if int(tmp.timestamp()) < timestamp:
            return None
        end_date = tmp.date()
    if start_date and (
        timestamp < start_date.timestamp() and timestamp != 0 and ret.sec_type < 80
    ):
        return None
    if start_date != None:
        start_date = start_date.date()
    return SecurityInfo(
        ret.display_name.decode("gbk"), start_date, end_date, ret.sec_type, security
    )


def get_sectype(security=None):
    """获取标的类型

    参数:
    - security: 标的代码list
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise Exception("请指定股票池!")
        security = list(zltObj._context.universe)
    if isinstance(security, str):
        security = [security]
    ret = strategy_bridge.GetSecType(security)
    res = {"security": security, "type": ret}
    result = pd.DataFrame(res).set_index("security")
    return result


def get_securities_info(security, date=None):
    """查询多个标的基础信息

    参数:
    - code: 证券代码list
        shxxxxxx:沪市
        szxxxxxx:深市
    - date:查询日期,默认回测时间context.current_dt

    返回: dict
    - key:标的代码
    - value: 对象 {
            last_price : 最新价
            high_limit: 涨停价
            low_limit: 跌停价
            paused: 是否停止或者暂停了交易, 当停牌、未上市或者退市后返回 True
            is_st: 是否是 ST(包括ST, *ST), 是则返回 True,否则返回 False
            day_open: 当天开盘价
            name: 股票现在的名称, 可以用这个来判断股票当天是否是 ST, *ST, 是否快要退市
            industry_code: 股票现在所属行业代码,
        }
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise Exception("请指定股票池!")
        security = list(zltObj._context.universe)
    ret = {}
    if isinstance(security, str):
        security = [security]
    for idx, code in enumerate(security):
        ans_data = query_price(code, date)
        is_st = ans_data.is_st
        high = ans_data.high_limit
        low = ans_data.low_limit
        pause = ans_data.paused
        is_st = ans_data.is_st
        open = ans_data.day_open
        name = ans_data.name
        last_price = ans_data.last_price
        price_paces = ans_data.price_paces
        ret[code] = Bar(
            round(last_price + 0.0001, price_paces),
            round(high + 0.0001, price_paces),
            round(low + 0.0001, price_paces),
            pause,
            is_st,
            round(open + 0.0001, price_paces),
            name,
            code,
        )

    return ret


def get_industry(security, date=None):
    """查询某只股票所属的行业

    参数:
    - security:标的代码
    - date:查询日期

    返回:
    dict
    {
        股票代码:{
            行业分类:{
            行业代码: xxxx,
            行业名称: xxxx
            }
        }
    }

    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise Exception("请指定股票池!")
        security = list(zltObj._context.universe)
    if date is None:
        date = int(zltObj._context.current_dt.timestamp())
    else:
        date = int(param_to_dt(date).timestamp())
    if isinstance(security, str):
        security = [security]
    result = strategy_bridge.GetIndustryBySecurity(security, date)
    for sec in result:
        for hy in result[sec]:
            result[sec][hy]["industry_name"] = result[sec][hy]["industry_name"].decode(
                "gbk"
            )
    return result


def get_all_trade_days():
    """获取所有交易日

    返回:
    获取交易日list
    """
    data = strategy_bridge.PyGetTradeDays("", 0, 0, 0)
    data = [param_to_dt(str(item)).date() for item in data]
    return data


def get_symbol_trade_day(security, start_date=None, end_date=None, count=None):
    end_date = int(param_to_dt(end_date).strftime("%Y%m%d"))
    if start_date is not None:
        start_date = int(param_to_dt(start_date).strftime("%Y%m%d"))
        count = 0
    else:
        start_date = 0
    data = strategy_bridge.PyGetTradeDays(security, start_date, end_date, count)
    data = [param_to_dt(str(item)).date() for item in data]
    return data


def get_money_flow(
    security_list, start_date=None, end_date=None, fields=None, count=None
):
    """获取资金流信息净额 : 为正是资金流入, 为负为资金流出;

    参数:
    - security_list:股票池
    - start_date:开始时间
    - end_date:截止时间
    - fields:
      字段名	含义	备注
      date	日期	---
      sec_code	股票代码	---
      change_pct	涨跌幅(%)	---
      net_amount_main	主力净额(万)	主力净额 = 超大单净额 + 大单净额
      net_pct_main	主力净占比(%)	主力净占比 = 主力净额 / 成交额
      net_amount_xl	超大单净额(万)	超大单:大于等于50万股或者100万元的成交单
      net_pct_xl	超大单净占比(%)	超大单净占比 = 超大单净额 / 成交额
      net_amount_l	大单净额(万)	大单:大于等于10万股或者20万元且小于50万股或者100万元的成交单
      net_pct_l	大单净占比(%)	大单净占比 = 大单净额 / 成交额
      net_amount_m	中单净额(万)	中单:大于等于2万股或者4万元且小于10万股或者20万元的成交单
      net_pct_m	中单净占比(%)	中单净占比 = 中单净额 / 成交额
      net_amount_s	小单净额(万)	小单:小于2万股或者4万元的成交单
      net_pct_s	小单净占比(%)	小单净占比 = 小单净额 / 成交额
    - count: 获取数量
    """
    return


def get_call_auction(security, start_date=None, end_date=None, fields=None):
    """获取指定时间区间内集合竞价时的 tick 数据

    参数:
    - security:股票池
    - start_date:开始时间
    - end_date:截止时间
    - fields:
    字段名	说明	字段类型
    time	时间	datetime
    current	当前价	float
    volume	累计成交量（股）	float
    money	累计成交额	float
    b1_v~b5_v	五档买量	float
    b1_p~b5_p	五档买价	float
    a1_v~a5_v	五档卖量	float
    a1_p~a5_p	五档卖价	float

    返回:
    """
    pass


def get_trade_days(security="sh000001", start_date=None, end_date=None, count=None):
    """根据标的获取指定时间范围内的交易日

    参数:
    - security:标的
    - start_date:开始时间
    - end_date:截止时间

    返回:dict
    - key:股票代码
    - value:交易日列表
    """
    if start_date and count:
        raise ValueError("start_date and count 不能被同时设置")
    if end_date is None:
        end_date = zltObj._context.current_dt
    if start_date is None and count is None:
        start_date = "1990-01-01"
    end_date = param_to_dt(end_date)
    if start_date is not None:
        param_to_dt(start_date)
        count = 0
    else:
        start_date = None
    if isinstance(security, str):
        if (
            security[:2] not in ["sh", "sz", "bj", "sq", "zj", "zs", "ds"]
            and security != ""
        ):
            raise ValueError("请输入正确的股票代码")
        return get_symbol_trade_day(security, start_date, end_date, count)
    result = {}
    for sec in security:
        if sec[:2] not in ["sh", "sz", "bj", "sq", "zj", "zs", "ds"]:
            raise ValueError("请输入正确的股票代码")
        result[sec] = get_symbol_trade_day(sec, start_date, end_date, count)
    return result


def get_dominant_future(security, date=None):
    """获取主力合约"""
    return


def get_future_contracts(security, date=None):
    """获取可交易合约列表"""
    if date is None:
        if zltObj._context.backtest_param["strategy_mode"] == "research":
            date = 0
        else:
            date = int(zltObj._context.current_dt.strftime("%Y%m%d"))
        return strategy_bridge.GetFutureContracts(security, date)
    date = int(param_to_dt(date).strftime("%Y%m%d"))
    return strategy_bridge.GetFutureContracts(security, date)


def get_call_auction(security, start_date, end_date=None, fields=None):
    """获取集合竞价数据"""
    start_date = param_to_dt(start_date)
    start_date = start_date.strftime("%Y-%m-%d")
    if end_date is None:
        end_date = zltObj._context.current_dt.strftime("%Y-%m-%d")
    else:
        end_date = param_to_dt(end_date)
        end_date = end_date.strftime("%Y-%m-%d")
    data = strategy_bridge.GetCallAuction(security, start_date, end_date)
    result = pd.DataFrame()
    if isinstance(fields, str):
        fields = [fields]
        if "time" not in fields:
            fields = ["time"] + fields
    if isinstance(security, str):
        security = [security]
    for key in data:
        df = None
        if len(data[key]) > 0:
            df = pd.DataFrame(data[key])
            df.insert(0, "security", key)
            if fields is not None:
                df = df[["security"] + fields]
            result = pd.concat([result, df], ignore_index=True)
    result.reset_index()
    if len(result) > 0:
        result["time"] = result["time"].apply(
            lambda x: datetime.fromtimestamp(x / 1000).date()
        )
    return result


def query_edms(stock, category, name, start_time, end_time, df=False):
    start = param_to_dt(start_time)
    end = param_to_dt(end_time)
    exdata_attr = strategy_bridge.ExDataAttr()
    exdata_attr.lab_id = -1
    exdata_attr.category = category.encode("gbk")
    exdata_attr.name = name.encode("gbk")
    exdata_attr.data_type = DataType.EX_DATA_TYPE_EXDATA.value
    exdata_attr.store_type = StoreType.EX_STORE_TYPE_SQUE.value
    exdata_attr.period_type = PeriodType.EX_PERIOD_TYPE_DAY.value
    exdata_attr.start_time = int(start.strftime("%Y%m%d"))
    exdata_attr.end_time = int(end.strftime("%Y%m%d"))
    remark = strategy_bridge.getEdmsAttrInfo(exdata_attr)
    if remark == "":
        return None
    remark = json.loads(remark)
    dtype = []
    for item in remark["declare"]:
        dtype.append((item["name"], item["type"]))
    content = strategy_bridge.getEdmsContents(
        stock,
        exdata_attr,
        int(start.timestamp()) * 1000,
        int(end.timestamp()) * 1000,
        remark["declare"],
    )
    if content is None:
        return None
    if df:
        rows = []  # 用于保存每一行数据（字典格式）
        for stock_code, arr in content.items():
            for record in arr:  # arr 可能有多条记录，这里遍历每一条
                row = {
                    "security": stock_code,  # 添加股票代码作为一列
                }
                for item in dtype:
                    row[item[0]] = record[item[0]]
                rows.append(row)

        # 构造 DataFrame
        df = pd.DataFrame(rows)
        df["time"] = df["time"].apply(lambda x: param_to_dt(int(x / 1000)))
        return df
    return content


__all__ = [
    "get_price",
    "get_zbar",
    "get_last_price",
    "history",
    "attribute_history",
    "get_bars",
    "get_current_tick",
    "get_ticks",
    "get_current_data",
    "get_security_info",
    "get_all_trade_days",
    "get_trade_days",
    "get_industry",
    "get_all_industry",
    "get_industry_stocks",
    "get_concepts",
    "get_securities_info",
    "get_extras",
    "get_symbol_trade_day",
    "get_industry_stats",
    "get_sectype",
    "get_dominant_future",
    "get_future_contracts",
    "get_call_auction",
]
