import glob
import os
import sqlite3
import pandas as pd
# import zltsdk.zltcalc as zltcalc
import numpy as np
import datetime as dt
from enum import Enum
from .zlt_util import param_to_dt
from zltsdk import strategy_bridge
from .zlt_get_data import get_trade_days
from .zlt_object import ParamsError
from . import zlt_object as zltObj
from .zlt_util import deal_symbol_code


def set_dc_obj(context):
    """给datacube对象设置数据中心"""
    zltcalc.set_context(context)


def set_cube_cfg(start_time, end_time, freq, log_level=strategy_bridge.ZLogLevel.TRACE):
    """设置数据中心配置"""
    install_path = zltObj._context.backtest_param["install_path"]
    log_path = os.path.join(
        zltObj._context.backtest_param["log_path"],
        zltObj._context.strategy_info["backtest_id"],
    )
    zltcalc.InitLog(log_path, log_level)
    zltcalc.get_global_datacube().set_cube_cfg(start_time, end_time, freq, install_path)
    pass


def init_data_cube(log_level=strategy_bridge.ZLogLevel.TRACE):
    """初始化datacube配置"""
    set_dc_obj(zltObj._context.sdk_context)
    strategy_freq = zltObj._context.backtest_param["frequency"]
    freq = ""
    if strategy_freq == "min":
        freq = "1m"
    elif strategy_freq == "day":
        freq = "1d"
    set_cube_cfg(
        zltObj._context.backtest_param["start_time"],
        zltObj._context.backtest_param["end_time"],
        freq,
        log_level,
    )


def clear_cube():
    """释放cube资源"""
    return
    zltcalc.get_global_datacube().Exit()


class STATUS_TYPE(Enum):
    """
    标的状态类型
    """

    ST = 1  # ST
    SUSPEND = 2  # 停牌
    PREDELIST = 3  # 退市整理
    DELISTED = 4  # 退市
    STX = 5  # *ST


# 日期类型
class DAY_TYPE(Enum):
    """
    日期类型
    """

    TRADE = 1  # 交易日
    NORMAL = 2  # 普通日


def reback_result(col, security, df, ret):
    df1 = pd.DataFrame(ret, columns=[col])
    if isinstance(security, str):
        security = [deal_symbol_code(security)]
    if isinstance(security, list):
        security = [deal_symbol_code(s) for s in security]
    df1.set_index(pd.Index(security), inplace=True)
    df1.index.name = None
    return df1
    # return ret


# ========== 状态算子 ==========


def get_ipo_date(security=None):
    """获取标的上市日期

    :param security: 标的代码

    :return: 标的上市日期
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if isinstance(security, str):
        security = [security]
    security = [deal_symbol_code(s) for s in security]
    ret = strategy_bridge.GetIPODate(security)
    times = [dt.datetime.fromtimestamp(ts).date() if ts else None for ts in ret]
    ret = np.array(times)
    return reback_result("ipo_date", security, True, ret)


def get_latest_status_time(security=None, date=None, status_type=STATUS_TYPE.ST):
    """获取标的在指定日期状态的开始时间

    :param security: 标的代码
    :param date: 日期，默认当前日期
    :param status_type: 状态类型,默认ST

    :return: 标的在指定日期状态的开始时间
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if date is None:
        date = zltObj._context.current_dt.date().strftime("%Y-%m-%d")
    else:
        date = param_to_dt(date).strftime("%Y-%m-%d")
    if isinstance(security, str):
        security = [security]
    security = [deal_symbol_code(s) for s in security]
    ret = strategy_bridge.GetLatestStatusTime(security, date, status_type.value)
    times = [dt.datetime.fromtimestamp(ts).date() if ts else None for ts in ret]
    ret = np.array(times)
    return reback_result("latest_status_time", security, True, ret)


def is_listing(security=None, date=None, change=False):
    """判断标的在指定日期是否上市
    :param security: 标的代码
    :param date: 日期，默认当前日期
    :param change: 是否判断是否发生变化
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if date is None:
        date = zltObj._context.current_dt.date().strftime("%Y-%m-%d")
    else:
        date = param_to_dt(date).strftime("%Y-%m-%d")
    if isinstance(security, str):
        security = [security]
    security = [deal_symbol_code(s) for s in security]
    ret = strategy_bridge.IsListing(security, date, change)
    ret = pd.DataFrame(ret, columns=["is_listing"])
    ret["security"] = security
    return ret.set_index("security")


def is_status(security=None, date=None, status_type=STATUS_TYPE.ST, change=False):
    """判断标的当期是否处于某种状态"""
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if date is None:
        date = zltObj._context.current_dt.date().strftime("%Y-%m-%d")
    else:
        date = param_to_dt(date).strftime("%Y-%m-%d")
    if isinstance(security, str):
        security = [security]
    security = [deal_symbol_code(s) for s in security]
    if not isinstance(status_type, list):
        ret = strategy_bridge.IsStatus(security, date, status_type.value, change)
    else:
        ret = pd.DataFrame()
        for stype in status_type:
            tmp = strategy_bridge.IsStatus(security, date, stype.value, change)
            status = ""
            if stype.value == 1:
                status = "ST"
            elif stype.value == 2:
                status = "停牌"
            elif stype.value == 3:
                status = "退市整理"
            elif stype.value == 4:
                status = "退市"
            elif stype.value == 5:
                status = "*ST"
            tmp = reback_result(status, security, True, tmp)
            ret = pd.concat([ret, tmp], axis=1)
        return ret
    return reback_result("is_status", security, True, ret)


def get_latest_status_days(
    security=None, date=None, day_type=DAY_TYPE.TRADE, status_type=STATUS_TYPE.ST
):
    """获取标的当前状态持续的天数"""
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if date is None:
        date = zltObj._context.current_dt.date().strftime("%Y-%m-%d")
    else:
        date = param_to_dt(date).strftime("%Y-%m-%d")
    if isinstance(security, str):
        security = [security]
    ret = strategy_bridge.CountLatestStatusDays(
        security, date, day_type.value, status_type.value
    )
    return reback_result("get_latest_status_days", security, True, ret)


def get_listing_days(security=None, date=None, day_type=DAY_TYPE.NORMAL):
    """获取标的上市的天数"""
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if date is None:
        date = zltObj._context.current_dt.date().strftime("%Y-%m-%d")
    else:
        date = param_to_dt(date).strftime("%Y-%m-%d")
    if isinstance(security, str):
        security = [security]
    ret = strategy_bridge.CountListingDays(security, date, day_type.value)
    return reback_result("get_listing_days", security, True, ret)


def count_status_days(
    security=None,
    start_date=None,
    end_date=None,
    day_type=DAY_TYPE.TRADE,
    status_type=STATUS_TYPE.ST,
):
    """
    获取标的在指定日期状态的持续天数
    :param security: 标的代码
    :param start_date: 开始日期
    :param end_date: 结束日期
    :param day_type: 日期类型
    :param status_type: 状态类型
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if start_date is None:
        start_date = zltObj._context.current_dt.date().strftime("%Y-%m-%d")
    else:
        start_date = param_to_dt(start_date).strftime("%Y-%m-%d")
    if end_date is None:
        end_date = zltObj._context.current_dt.date().strftime("%Y-%m-%d")
    else:
        end_date = param_to_dt(end_date).strftime("%Y-%m-%d")
    if isinstance(security, str):
        security = [security]
    ret = strategy_bridge.CountStatusDays(
        security, start_date, end_date, day_type.value, status_type.value
    )
    return reback_result("count_status_days", security, True, ret)


def count_status_change(
    security=None, start_date=None, end_date=None, status_type=STATUS_TYPE.ST, df=False
):
    """获取状态改变的次数
    :param security: 标的代码
    :param start_date: 开始日期
    :param end_date: 结束日期
    :param status_type: 状态类型
    :param df: 是否返回DataFrame
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if start_date is None:
        start_date = zltObj._context.current_dt.date().strftime("%Y-%m-%d")
    else:
        start_date = param_to_dt(start_date).strftime("%Y-%m-%d")
    if end_date is None:
        end_date = zltObj._context.current_dt.date().strftime("%Y-%m-%d")
    else:
        end_date = param_to_dt(end_date).strftime("%Y-%m-%d")
    if isinstance(security, str):
        security = [security]
    ret = strategy_bridge.CountStatusChange(
        security, start_date, end_date, status_type.value
    )
    return reback_result("count_status_change", security, True, ret)


# ========== 时间算子 ==========


def machinedate():
    return dt.datetime.now().date()


def machinetime():
    return dt.datetime.now()


def machineweek():
    return dt.datetime.now().weekday()


def fromopen():
    """离大盘开盘时间9:30分钟的分钟数"""
    now = zltObj._context.current_dt
    # 定义开盘时间、上午休市时间和下午开盘时间
    open_time = now.replace(hour=9, minute=30, second=0, microsecond=0)
    pause_start = now.replace(hour=11, minute=30, second=0, microsecond=0)
    pause_end = now.replace(hour=13, minute=0, second=0, microsecond=0)
    close_time = now.replace(hour=15, minute=0, second=0, microsecond=0)

    # 如果当前时间在非交易时间（开盘前或收盘后），返回 0
    if now < open_time:
        return 0
    if now >= close_time:
        return 240

    # 如果当前时间在休市时间（11:30-13:00），返回 0
    if pause_start <= now < pause_end:
        return 120

    # 计算距离开盘的分钟数
    if now < pause_start:
        # 当前时间在上午交易时间（9:30-11:30）
        return (now - open_time).seconds // 60
    else:
        # 当前时间在下午交易时间（13:00-15:00）
        return (now - pause_end).seconds // 60 + 120  # 120 分钟是上午的交易时间


def period():
    """获取周期类型"""
    _period = zltObj._context.backtest_param["frequency"]
    if _period == "min":
        return 0
    elif _period == "day":
        return 5
    return None


def time():
    return zltObj._context.current_dt.strftime("%H:%M")


def time2():
    return zltObj._context.current_dt.strftime("%H:%M:%S")


def date():
    return zltObj._context.current_dt.strftime("%Y-%m-%d")


def year():
    return zltObj._context.current_dt.strftime("%Y")


def month():
    return zltObj._context.current_dt.strftime("%m")


def weekday():
    return zltObj._context.current_dt.isocalendar()[2]


def day():
    return zltObj._context.current_dt.strftime("%d")


def hour():
    return zltObj._context.current_dt.strftime("%H")


def minute():
    return zltObj._context.current_dt.strftime("%M")


def weekofyear():
    return zltObj._context.current_dt.isocalendar()[1]


def timetosec(time):
    # 提取小时、分钟和秒
    hours = int(time / 10000)
    minutes = int((time % 10000) / 100)
    seconds = time % 100

    # 计算总秒数
    total_seconds = hours * 3600 + minutes * 60 + seconds
    return total_seconds


def sectotime(time):
    # 计算小时、分钟和秒
    hours = (int)(time / 3600)
    minutes = int((time % 3600) / 60)
    seconds = time % 60

    # 将小时、分钟和秒组合成一个整数时间
    time_int = hours * 10000 + minutes * 100 + seconds
    return time_int


class formula:
    @property
    def MACHINEDATE(self):
        return dt.datetime.now().strftime("%Y-%m-%d")

    @property
    def MACHINETIME(self):
        return dt.datetime.now().strftime("%H:%M:%S")

    @property
    def MACHINEWEEK(self):
        return dt.datetime.now().weekday()

    @property
    def FROMOPEN(self):
        time = zltObj._context.current_dt.strftime("%H%M")
        hour = int(time[:2])
        min = int(time[2:])
        if hour <= 9:
            if hour == 9 and min > 30:
                return None
            return (9 - hour) * 60 + 30 - min
        return None

    @property
    def PERIOD(self):
        return zltObj._context.backtest_param["frequency"]

    @property
    def TIME(self):
        return zltObj._context.current_dt.strftime("%H:%M")

    @property
    def TIME2(self):
        return zltObj._context.current_dt.strftime("%H:%M:%S")

    @property
    def DATE(self):
        return zltObj._context.current_dt.strftime("%Y-%m-%d")

    @property
    def YEAR(self):
        return zltObj._context.current_dt.strftime("%Y")

    @property
    def MONTH(self):
        return zltObj._context.current_dt.strftime("%m")

    @property
    def WEEKDAY(self):
        return zltObj._context.current_dt.isocalendar()[2]

    @property
    def DAY(self):
        return zltObj._context.current_dt.strftime("%d")

    @property
    def HOUR(self):
        return zltObj._context.current_dt.strftime("%H")

    @property
    def MINUTE(self):
        return zltObj._context.current_dt.strftime("%M")

    @property
    def WEEKOFYEAR(self):
        return zltObj._context.current_dt.isocalendar()[1]

    def TIMETOSEC(self, time):
        # 提取小时、分钟和秒
        hours = int(time / 10000)
        minutes = int((time % 10000) / 100)
        seconds = time % 100

        # 计算总秒数
        total_seconds = hours * 3600 + minutes * 60 + seconds
        return total_seconds

    def SECTOTIME(self, time):
        # 计算小时、分钟和秒
        hours = (int)(time / 3600)
        minutes = int((time % 3600) / 60)
        seconds = time % 60

        # 将小时、分钟和秒组合成一个整数时间
        time_int = hours * 10000 + minutes * 100 + seconds
        return time_int

    def TOTALFZNUM(self, security):
        return strategy_bridge.GetTotalFzNum(
            security, (int)(zltObj._context.current_dt.timestamp())
        )


Formula = formula()


def get_trade_day(security="sh000001", date=None):
    """
    获取指定日期的交易日
    - security: 股票代码
    - date: 指定日期，默认当前日期
    """
    if date is None:
        date = zltObj._context.current_dt
    else:
        date = param_to_dt(date)
    if isinstance(security, str):
        ret = strategy_bridge.GetTradeDate(
            security,
            int((date + dt.timedelta(weeks=1)).strftime("%Y%m%d")),
            int(date.strftime("%Y%m%d")),
            int(date.timestamp()),
        )
        if ret == 0:
            return None
        return param_to_dt(str(ret)).date()
    else:
        result = {}
        for sec in security:
            ret = strategy_bridge.GetTradeDate(
                sec,
                int((date + dt.timedelta(weeks=1)).strftime("%Y%m%d")),
                int(date.strftime("%Y%m%d")),
                int(date.timestamp()),
            )
            if ret == 0:
                result[sec] = None
            else:
                result[sec] = param_to_dt(str(ret)).date()
        return result


def count_diff_trade_days(
    security="sh000001", start_date=None, end_date=None, day_type=DAY_TYPE.TRADE
):
    if end_date is None:
        end_date = zltObj._context.current_dt.date().strftime("%Y-%m-%d")
    if start_date is None:
        start_date = "1990-01-01"
    start_t = param_to_dt(start_date).strftime("%Y%m%d")
    end_t = param_to_dt(end_date).strftime("%Y%m%d")
    ret = strategy_bridge.CountDiffTradeDays(security, start_t, end_t, day_type.value)

    if isinstance(security, str):
        if len(ret):
            return ret[0]
        else:
            return None
    else:
        result = {}
        for i in range(len(security)):
            result[security[i]] = ret[i]
        return result


def get_offset_day(security="sh000001", date=None, ndays=0, day_type=DAY_TYPE.TRADE):
    if date is None:
        date = zltObj._context.current_dt.date().strftime("%Y-%m-%d")
    end_t = param_to_dt(date).strftime("%Y-%m-%d")
    ret = strategy_bridge.GetOffsetDays(security, end_t, ndays, day_type.value)
    times = [dt.datetime.fromtimestamp(ts).date() if ts else None for ts in ret]
    ret = np.array(times)
    if isinstance(security, list):
        result = {}
        for i in range(len(security)):
            result[security[i]] = ret[i]
        return result
    else:
        return ret[-1]


def get_dpzs_code(security=None):
    """
    获取股票的所属指数代码
    - security: 股票代码
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if isinstance(security, str):
        security = [security]
    data = strategy_bridge.GetDpInfo(security, "code")
    df = pd.DataFrame(data, columns=["security", "dpzs_code"])
    df.set_index("security", inplace=True)
    df.index.name = None
    return df


def get_dpzs_name(security=None):
    """
    获取股票的所属指数名称
    - security: 股票代码
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if isinstance(security, str):
        security = [security]
    data = strategy_bridge.GetDpInfo(security, "name")
    df = pd.DataFrame(data, columns=["security", "dpzs_name"])
    df["dpzs_name"] = df["dpzs_name"].apply(lambda x: x.decode("gbk"))
    df.set_index("security", inplace=True)
    df.index.name = None
    return df


def get_all_securities(types=[], date=None):
    """获取指定日期的全部股票、基金、债券代码
    - date: 指定日期，默认当前日期
    """
    seen = set()
    unique_list = [x for x in types if not (x in seen or seen.add(x))]
    types = unique_list
    if date is None:
        if zltObj._context.backtest_param["strategy_mode"] == "research":
            timestamp = 0
        else:
            timestamp = int(param_to_dt(date or zltObj._context.current_dt).timestamp())
    else:
        timestamp = int(param_to_dt(date).timestamp())
    for _type in types:
        if _type not in [13, 14, 16, 18, 19, 20, 39, 48, 49, 50, 64, 80]:
            raise RuntimeError("传入的type不在可查询的types中")
    data = strategy_bridge.GetHisAllSec(timestamp, types)
    data = pd.DataFrame(
        data, columns=["security", "display_name", "start_date", "end_date", "type"]
    ).set_index("security")
    data.index.name = None
    data["start_date"] = data["start_date"].apply(
        lambda x: None if x == "0" else param_to_dt(x).date()
    )
    data["end_date"] = data["end_date"].apply(
        lambda x: None if x == "0" else param_to_dt(x).date()
    )
    return data


session_map = {"q1": "03", "q2": "06", "q3": "09", "q4": "12"}


def get_fundamentals(
    security=None,
    fields=None,
    start_quarter=None,
    end_quarter=None,
    report_type=0,
    data_type=2,
):
    """获取基本财务数据
    - security: 股票代码
    - fields: 财务指标
    - start_quarter:str,财报回溯查询的起始报告期,例如'2015q2'代表2015年半年报
    - end_quarter:str,财报回溯查询的结束报告期,例如'2015q4'代表2015年年报
    - report_type:报表类型,int,默认0为全部,按报告期查询可指定以下报表类型:
        - 0-不限
        - 1-一季度报
        - 6-中报
        - 9-前三季报
        - 12-年报
    - data_type:int,返回数据的数据类型:1-合并原始,2-合并调整,默认2
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if fields is None:
        raise ParamsError("请指定字段!")

    if isinstance(security, str):
        security = [security]

    if isinstance(fields, str):
        fields = [fields]
    if session_map.get(start_quarter[4:]) is None:
        raise ValueError(
            "start_quarter 格式有误,应为'yyyy(q1-q4)', 你的参数 {}".format(
                start_quarter
            )
        )
    if session_map.get(end_quarter[4:]) is None:
        raise ValueError(
            "end_quarter 格式有误,应为'yyyy(q1-q4)', 你的参数 {}".format(end_quarter)
        )
    try:
        int(start_quarter[0:4])
    except ValueError:
        raise ValueError(
            "start_quarter 格式有误,应为'yyyy(q1-q4)', 你的参数 {}".format(
                start_quarter
            )
        )
    try:
        int(end_quarter[0:4])
    except ValueError:
        raise ValueError(
            "end_quarter 格式有误,应为'yyyy(q1-q4)', 你的参数 {}".format(end_quarter)
        )
    start_quarter = start_quarter[0:4] + session_map.get(start_quarter[4:])
    end_quarter = end_quarter[0:4] + session_map.get(end_quarter[4:])
    # 定义列名
    # columns = ['security', 'pub_date', 'report_date'] + fields
    columns = ["security", "report_date"] + fields
    data = strategy_bridge.GetFinanceDataMr(
        security, fields, report_type, int(start_quarter), int(end_quarter), data_type
    )
    # 创建 DataFrame
    df = pd.DataFrame(data, columns=columns)
    return df


def get_fundamentals_pit(
    security=None, fields=None, date=None, report_type=0, data_type=2
):
    """获取点时间财务数据
    - security:标的代码,str/list[str]
    - fields:list[str],支持的字段同get_fundamentals
    - date:查询日期,datetime.date/datetime.datetime/'yyyy-mm-dd'/'yyyy-mm-dd hh:mm:ss'/时间戳,截取到日期,默认回测当前时间
    - report_type:报表类型,int,默认0为全部,按报告期查询可指定以下报表类型:
    - 0-不限
    - 1-一季度报
    - 2-二季度报
    - 3-三季度报
    - 4-四季度报
    - 6-中报
    - 9-前三季报
    - 12-年报
    - data_type:int,返回数据的数据类型:1-合并原始,2-合并调整,默认2
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if fields is None:
        raise ParamsError("请指定字段!")
    if isinstance(security, str):
        security = [security]
    if isinstance(fields, str):
        fields = [fields]
    # 定义列名
    columns = ["security", "report_date"] + fields
    if date is None:
        date = int(zltObj._context.current_dt.strftime("%Y%m%d"))
    else:
        date = int(param_to_dt(date).strftime("%Y%m%d"))
    data = strategy_bridge.GetFinanceDataPit(
        security, fields, report_type, date, data_type
    )
    # 创建 DataFrame
    df = pd.DataFrame(data, columns=columns)
    return df


def get_valuation_indicators(security=None, fields=None, date=None):
    """获取点时间估值衍生指标
    - security:标的代码,str/list[str]
    - fields:list[str]
    - date:查询日期,datetime.date/datetime.datetime/'yyyy-mm-dd'/'yyyy-mm-dd hh:mm:ss'/时间戳,截取到日期,默认回测当前时间
    """
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if fields is None:
        raise ParamsError("请指定字段!")
    if isinstance(security, str):
        security = [security]
    if date is None:
        date = int(zltObj._context.current_dt.strftime("%Y%m%d"))
    else:
        date = int(param_to_dt(date).strftime("%Y%m%d"))
    # 定义列名
    columns = ["time", "security"] + list(fields)
    data = strategy_bridge.GetValuationIndicator(security, date, fields)
    df = pd.DataFrame(data, columns=columns)
    return df


def get_valuation_indicators_seq(security=None, field=None, start=None, end=None):
    """获取指定日期范围,标的估值衍生指标
    - security:标的代码,str
    - field:str
    - start:查询日期,datetime.date/datetime.datetime/'yyyy-mm-dd'/'yyyy-mm-dd hh:mm:ss'/时间戳,截取到日期,默认回测当前时间
    - end:查询日期,datetime.date/datetime.datetime/'yyyy-mm-dd'/'yyyy-mm-dd hh:mm:ss'/时间戳,截取到日期,默认回测当前时间
    """
    dates = get_trade_days(start_date=start, end_date=end)
    result = []
    for date in dates:
        day = int(date.strftime("%Y%m%d"))
        data = strategy_bridge.GetValuationIndicator([security], day, [field])
        result = result + data
    df = pd.DataFrame(result, columns=["time", "security", field])
    df["time"] = df["time"].apply(lambda x: param_to_dt(str(x)))
    df.set_index("time", inplace=True)
    return df


def get_efficiency_indicators(security=None, fields=None, date=None):
    """查询指定日期,股票所属上市公司的经营衍生指标数据"""
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if fields is None:
        raise ParamsError("请指定字段!")
    if isinstance(security, str):
        security = [security]
    if date is None:
        date = int(zltObj._context.current_dt.strftime("%Y%m%d"))
    else:
        date = int(param_to_dt(date).strftime("%Y%m%d"))
    # 定义列名
    columns = ["time", "security"] + list(fields)
    data = strategy_bridge.GetEfficiencyIndicators(security, date, fields)
    df = pd.DataFrame(data, columns=columns)
    return df


def get_efficiency_indicators_seq(security=None, field=None, start=None, end=None):
    """获取指定日期范围,股票所属上市公司的经营衍生指标数据"""
    dates = get_trade_days(start_date=start, end_date=end)
    result = []
    for date in dates:
        day = int(date.strftime("%Y%m%d"))
        data = strategy_bridge.GetEfficiencyIndicators([security], day, [field])
        result = result + data
    df = pd.DataFrame(result, columns=["time", "security", field])
    df.set_index("time", inplace=True)
    return df


def get_cash_flow_indicators(security=None, fields=None, date=None):
    """查询指定日期,股票所属上市公司的现金流衍生指标数据"""
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if fields is None:
        raise ParamsError("请指定字段!")
    if isinstance(security, str):
        security = [security]
    if date is None:
        date = int(zltObj._context.current_dt.strftime("%Y%m%d"))
    else:
        date = int(param_to_dt(date).strftime("%Y%m%d"))
    # 定义列名
    columns = ["time", "security"] + list(fields)
    data = strategy_bridge.GetCashFlowIndicators(security, date, fields)
    df = pd.DataFrame(data, columns=columns)
    return df


def get_cash_flow_indicators_seq(security=None, field=None, start=None, end=None):
    """获取指定日期范围,,股票所属上市公司的现金流衍生指标数据"""
    dates = get_trade_days(start_date=start, end_date=end)
    result = []
    for date in dates:
        day = int(date.strftime("%Y%m%d"))
        data = strategy_bridge.GetCashFlowIndicators([security], day, [field])
        result = result + data
    df = pd.DataFrame(result, columns=["time", "security", field])
    df.set_index("time", inplace=True)
    return df


def get_asset_indicators(security=None, fields=None, date=None):
    """查询指定日期,股票所属上市公司的财务衍生指标数据"""
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if fields is None:
        raise ParamsError("请指定字段!")
    if isinstance(security, str):
        security = [security]
    if date is None:
        date = int(zltObj._context.current_dt.strftime("%Y%m%d"))
    else:
        date = int(param_to_dt(date).strftime("%Y%m%d"))
    # 定义列名
    columns = ["time", "security"] + list(fields)
    data = strategy_bridge.GetAssetIndicators(security, date, fields)
    df = pd.DataFrame(data, columns=columns)
    return df


def get_asset_indicators_seq(security=None, field=None, start=None, end=None):
    """获取指定日期范围,,股票所属上市公司的财务衍生指标数据"""
    dates = get_trade_days(start_date=start, end_date=end)
    result = []
    for date in dates:
        day = int(date.strftime("%Y%m%d"))
        data = strategy_bridge.GetAssetIndicators([security], day, [field])
        result = result + data
    df = pd.DataFrame(result, columns=["time", "security", field])
    df.set_index("time", inplace=True)
    return df


def get_growth_indicators(security=None, fields=None, date=None):
    """获取点时间成长指标"""
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if fields is None:
        raise ParamsError("请指定字段!")
    if isinstance(security, str):
        security = [security]
    if date is None:
        date = int(zltObj._context.current_dt.strftime("%Y%m%d"))
    else:
        date = int(param_to_dt(date).strftime("%Y%m%d"))
    # 定义列名
    columns = ["time", "security"] + list(fields)
    data = strategy_bridge.GetGrowthIndicators(security, date, fields)
    df = pd.DataFrame(data, columns=columns)
    return df


def get_growth_indicators_seq(security=None, field=None, start=None, end=None):
    """获取指定日期范围,, 成长指标"""
    dates = get_trade_days(start_date=start, end_date=end)
    result = []
    for date in dates:
        day = int(date.strftime("%Y%m%d"))
        data = strategy_bridge.GetGrowthIndicators([security], day, [field])
        result = result + data
    df = pd.DataFrame(result, columns=["time", "security", field])
    return df


def get_price_limit(security=None, start_date=None, end_date=None, count=0):
    """获取点时间涨跌停价格

    参数:
    security: str or list股票代码
    start_date: str开始时间
    end_date: str结束时间
    count: int获取数量

    return:
    DataFrame
    """

    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if isinstance(security, str):
        security = [security]
    if start_date is not None:
        if count > 0:
            raise Exception("start_date 和 count 不能同时设置")
        start_date = int(param_to_dt(start_date).timestamp())
    if end_date is None:
        end_date = int(zltObj._context.current_dt.timestamp())
    else:
        end_date = int(param_to_dt(end_date).timestamp())
    if count > 0:
        start_date = 0
    # 定义列名
    columns = ["time", "security", "high_limit", "low_limit"]
    data = strategy_bridge.GetPriceLimit(security, start_date, end_date, count)
    for item in data:
        item[0] = param_to_dt(item[0])
        item[2] = np.float32(item[2])  
        item[3] = np.float32(item[3])
    df = pd.DataFrame(data, columns=columns)
    return df


def get_net_value(security=None, end_date=None):
    """获取基金净值"""
    if security is None:
        if len(zltObj._context.universe) == 0:
            raise ParamsError("请指定股票池!")
        security = list(zltObj._context.universe)
    if isinstance(security, str):
        security = [security]
    if end_date is None:
        end_date = int(zltObj._context.current_dt.strftime("%Y%m%d"))
    else:
        end_date = int(param_to_dt(end_date).strftime("%Y%m%d"))
    # 定义列名
    columns = ["security", "date", "net_value"]
    data = strategy_bridge.GetNetValue(security, end_date)
    df = pd.DataFrame(data, columns=columns)
    return df


def get_etf_stocks(etf_code, date=None):
    """获取ETF成分股"""
    market = etf_code[0:2]
    code = etf_code[2:]
    if market not in ["sh", "sz"]:
        raise ParamsError("请输入正确的ETF代码")
    install_path = zltObj._context.backtest_param["install_path"]
    if date is None:
        date = zltObj._context.current_dt
    else:
        date = param_to_dt(date)
    trade_date = get_trade_days(end_date=date, count=1)
    db_path = os.path.join(install_path, "Public", "quantdata", "etf", market)
    if os.path.exists(db_path) == False:
        raise ParamsError("请下载etf数据")
    db_begin_name = market + "_" + trade_date[0].strftime("%Y%m%d") + "_"
    pattern = os.path.join(db_path, f"{db_begin_name}*.db3")
    matched_files = glob.glob(pattern)

    if len(matched_files) == 0:
        raise ParamsError("未找到对应的数据库文件")
    conn = sqlite3.connect(matched_files[0])
    sql = f"SELECT sec_code, weight, sub_flag, pre_rate, creation_cash FROM ETF_Constituent WHERE etf_code = '{code}'"
    cursor = conn.cursor()
    data = cursor.execute(sql).fetchall()
    df = pd.DataFrame(
        data,
        columns=[
            "security",
            "amount",
            "cash_subs_type",
            "cash_subs_sum",
            "cash_premium_rate",
        ],
    )
    df["date"] = date
    df.set_index("date", inplace=True)
    df["security"] = market + df["security"].astype(str)
    return df
