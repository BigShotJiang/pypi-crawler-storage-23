def on_position_warning(context):
    '''仓位提醒
    '''
    print("当前接近满仓,请及时处理")
