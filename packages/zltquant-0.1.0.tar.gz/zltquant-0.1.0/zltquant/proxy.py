import argparse
import ctypes
import json
import zltsdk.strategy_bridge as strategy_bridge
from zltquant.util.zlt_sql_manager import create_sim_strategy_db
from zltquant.util.zlt_strategy_settings import set_sys_benchmark
from .open_close_schedule import init_system_task
from .zlt_schedule import init_callback_func, run_schedule
from zltquant import *
from .util import zlt_object as zltObj
from .util import modify_backtest_status
from zltquant.util import node_api as nodeApi
import os
import sys
import time


class MyStrategy(strategy_bridge.IStrategy):
    # 创建Python继承自IStrategy接口的类
    def __init__(
        self,
        config=None,
    ):
        strategy_bridge.IStrategy.__init__(self)
        # 配置参数
        self.config = config

    def OnInit(self, sdk_context):
        # c层上下文对象
        zltObj._context.sdk_context = sdk_context

        # 初始化日志对象
        zltObj._context.GetLogUser = sdk_context.GetLogUser
        zltObj._context.GetLog = sdk_context.GetLog

        # 策略运行系统日志
        system_log.init_context(
            strategy_bridge.create_log_obj,
            is_py_log=True,
            logs_path=zltObj._context.backtest_param["log_path"],
            log_level=zltObj._context.backtest_param["log_level"],
        )
        zltObj._context.sys_log = system_log

        # 用户日志
        log.init_context(
            strategy_bridge.create_log_obj,
            is_py_log=False,
            logs_path=zltObj._context.backtest_param["log_path"],
            log_level=zltObj._context.backtest_param["log_level"],
        )
        # 绑定策略引擎
        zltObj._context.GetStrategyEngine = sdk_context.GetStrategyEngine
        # 绑定交易api
        zltObj._context.GetTradeApi = sdk_context.GetTradeApi
        # 获取当前策略
        zltObj._context.GetCurStrategy = sdk_context.GetCurStrategy
        # 获取/编辑当前回测参数
        zltObj._context.GetParams = sdk_context.GetParams
        zltObj._context.SetParams = sdk_context.SetParams
        zltObj._context.GetStrategyEstimate = sdk_context.GetStrategyEstimate
        # 获取ipc对象
        zltObj._context.IPCClient = sdk_context.GetRPCClient()
        # 引入用户编写的策略文件
        user_moudle = __import__(self.config["file"])
        # 绑定策略内置函数
        funcs = dir(user_moudle)
        # 初始化策略总账户信息
        initial_cash = zltObj._context.backtest_param["initial_cash"]
        zltObj._context.portfolio = Portfolio(
            inout_cash=initial_cash,
            available_cash=initial_cash,
            starting_cash=initial_cash,
        )
        is_backtest = (
            zltObj._context.backtest_param["type"] == "simple_backtest"
        )  # 当前是否回测模式
        # init_data_cube() # 目前不需要cube相关的函数
        strategy_bridge.init_mr_data()
        zltObj.g.init(is_backtest)
        if "process_initialize" in funcs:
            user_moudle.process_initialize(zltObj._context)  # 重启时必定执行
        zltObj.g.has_process_initialize = True
        if "initialize" in funcs:
            # 回测时使用回测id作为资金账号
            zltObj._context.strategy_info["fund_account"] = zltObj._context.strategy_info[
                "backtest_id"
            ]
            if not is_backtest:
                # 非回测时使用真实资金账号
                # ... 逻辑待补
                # 启动定时任务
                nodeApi.timer_thread.start()
                pass

            jvKuanOpenAvgCostSwitch = "0"
            adjustAqtyByAvail = "0"
            takeFeeType = "0"
            # 如果模板参数设置
            if "base_tpl_obj" in self.config:
                jvKuanOpenAvgCostSwitch = self.config["base_tpl_obj"][
                    "jv_kuan_open_avg_cost_switch"
                ]
                adjustAqtyByAvail = self.config["base_tpl_obj"]["adjust_aqty_by_avail"]
                takeFeeType = self.config["base_tpl_obj"]["take_fee_type"]
            # 初始化交易回测周期等配置
            init_trade_setting(
                slippage=zltObj._context.backtest_param["slippage"],
                tradeType=zltObj._context.backtest_param["trade_type"],
                orderVolumeRatio=zltObj._context.backtest_param["order_volume_ratio"],
                jvKuanOpenAvgCostSwitch=jvKuanOpenAvgCostSwitch,
                adjustAqtyByAvail=adjustAqtyByAvail,
                takeFeeType=takeFeeType,
            )
            # 账号组中插入默认账号
            zltObj._context.subportfolios.append(
                SubPortfolio(
                    inout_cash=initial_cash,
                    available_cash=initial_cash,
                    transferable_cash=initial_cash,
                    pindex=0,
                    type="stock",
                    total_value=initial_cash,
                )
            )
            # 未初始化前使用本地账户信息,兼容其他平台的格式
            zltObj._context.not_init = True
            # 初始化全局变量
            # 仿真模式下执行策略文件中的 initialize 函数,如果已经执行过一次后则不再执行初始化部分,而回测都是重新运行
            if is_backtest:
                user_moudle.initialize(zltObj._context)
            else:
                if zltObj.g.zlt_status != "3":
                    user_moudle.initialize(zltObj._context)
                    zltObj.g.zlt_status = "2"
            # 在c层初始化账号(可能有多个账号)
            for idx, item in enumerate(zltObj._context.subportfolios):
                init_trade_info(idx, item.inout_cash)
            # # 实盘仿真情况下、初始化时获取资金账号的可用资金作为初始资金计算
            # if not is_backtest:
            #     if not hasattr(zltObj.g, "zlt_sys_init_cash"):
            #         cash = get_daily_asset_pb()
            #         if cash:
            #             zltObj.g.zlt_sys_init_cash = get_daily_asset_pb()

            #         else:
            #             raise ConfigError("初始资金获取失败!")
            #     zltObj._context.backtest_param["initial_cash"] = float(zltObj.g.zlt_sys_init_cash)
            zltObj._context.not_init = False
            if zltObj._context.sys_benchmark == None:
                set_sys_benchmark("sz399300")
            # 初始化回调函数
            init_callback_func(user_moudle, funcs)
            # 初始化系统定时任务
            if len(zltObj._context.backtest_param["benchmark"].values()) == 0:
                set_benchmark("sz399300")
            init_system_task()
            # 修改策略状态
            modify_backtest_status(zltObj._context, 1, is_start=1)

    def OnTick(self, sdk_context, tick):
        if "handle_tick" in system_functions:
            if system_functions["handle_tick"] != None:
                system_functions["handle_tick"](zltObj._context, tick)
        # 实现OnTick方法的逻辑
        pass

    def OnBar(self, sdk_context, bar):
        # onbar 和 handle_data 不能共存 onbar优先级更高
        if system_functions["on_bar"] != None:
            # 刷新缓存
            zltObj._context.pos_visited = False
            zltObj._context.por_visited = False
            zltObj._context.sub_pos_visited = False
            system_functions["on_bar"](zltObj._context, bar)
            return
        if zltObj._context.run_params.frequency == "min":
            if system_functions["handle_data"] != None:
                system_functions["handle_data"](zltObj._context, BarDict())
        elif zltObj._context.run_params.frequency == "tick":
            # 定时模式,触发tick事件
            if system_functions["handle_tick"] != None:
                system_functions["handle_tick"](zltObj._context, TickDict())
                

    def OnEventNotify(self, sdk_context, notifyMsg):
        """
        事件通知
        """
        if notifyMsg.FuncName() == "TradeTimeNotice":
            if "on_position_warning" in zltObj._context.callback_event:
                """仓位检查"""
                data = get_daily_asset_pb()
                percent = (data / zltObj._context.backtest_param["initial_cash"]) * 100
                if percent < 30:
                    # 当仓位大于70%,触发提醒
                    zltObj._context.callback_event["on_position_warning"](
                        zltObj._context, 100 - percent
                    )
        # 交易成功
        if notifyMsg.FuncName() == "SuccessTrade":
            if "on_order" in zltObj._context.callback_event:
                """订单撮合成功回调"""
                msg = notifyMsg.Data()
                zltObj._context.callback_event["on_order"](zltObj._context, msg)
        if notifyMsg.FuncName() == "open":
            if zltObj._context.run_params.frequency == "day":
                if system_functions["handle_data"] != None:
                    system_functions["handle_data"](zltObj._context, BarDict())

    def OnHQEventNotify(self, sdk_context, notifyMsg):
        pass

    def OnSchedule(self, sdk_context, cronRule):
        run_schedule(cronRule)

    def OnTimer(self, sdk_context, timerID):
        pass

    def OnError(self, sdk_context, errorCode, errorMsg):
        zltObj._context.IPCClient = sdk_context.GetRPCClient()
        modify_backtest_status(zltObj._context, 2, 0, remarks=errorMsg)

    def OnStop(self, sdk_context):
        """策略结束前回调"""
        if zltObj._context.backtest_param["type"] != "simple_backtest":
            nodeApi.timer_thread.stop()
            nodeApi.timer_thread.join()

        if "on_strategy_end" in system_functions:
            system_functions["on_strategy_end"](zltObj._context)

        clear_cube()
        if hasattr(zltObj._context, "event"):
            start_ts = time.time()  # 记录循环开始时间
            timeout = 10  # 设置超时时间（例如 10 秒）
            while True:
                zltObj._context.event.set()
                if time.time() - start_ts > timeout:
                    print("评估队列提交异常,强制结束")
                    zltObj._context.stop = True  # 设置停止标志
                    zltObj._context.event.set()
                    if zltObj._context.task_thread is not None:
                        zltObj._context.task_thread.join(timeout=1)  # 尝试等待线程退出
                        if zltObj._context.task_thread.is_alive():
                            print("线程未在超时时间内退出.强制退出...")
                            # 可以在这里添加额外的清理逻辑
                    break
                if zltObj._context.current_day_index == len(zltObj._context.profit_list):
                    zltObj._context.stop = True
                    zltObj._context.event.set()
                    if zltObj._context.task_thread != None:
                        zltObj._context.task_thread.join()
                        break
        print(flush=True)
        modify_backtest_status(zltObj._context, 5, 100, False, remarks="策略结束")


def set_trade_fee(config):
    fee_dict = {
        "stock_cost": {
            # 证券类型
            "securitySecType": "1",
            "securityOpenRateAmt": "0.0003",
            "securityOpenRateCount": "0",
            "securityCloseRateAmt": "0.0003",
            "securityCloseRateCount": "0",
            "securityCloseTodayRate": "0.0003",
            "securityCloseTodayCount": "0",
            "securityTransferRate": "0",
            # 印花税
            "securityStampRate": "0.001",
            # 最低佣金
            "minCommission": "5",
        },
        "fund_cost": {
            # 证券类型
            "securitySecType": "3",
            "securityOpenRateAmt": "0.0003",
            "securityOpenRateCount": "0",
            "securityCloseRateAmt": "0.0003",
            "securityCloseRateCount": "0",
            "securityCloseTodayRate": "0",
            "securityCloseTodayCount": "0",
            "securityTransferRate": "0",
            # 印花税
            "securityStampRate": "0",
            # 最低佣金
            "minCommission": "0",
        },
        "futures_cost": {
            # 证券类型
            "securitySecType": "2",
            "securityOpenRateAmt": "0.0003",
            "securityOpenRateCount": "0",
            "securityCloseRateAmt": "0.0003",
            "securityCloseRateCount": "0",
            "securityCloseTodayRate": "0.0003",
            "securityCloseTodayCount": "0",
            # 过户费
            "securityTransferRate": "0",
            # 印花税
            "securityStampRate": "0",
            # 最低佣金
            "minCommission": "0",
            # 保证金
            "futuresMarginRate": "0",
        },
        "bond_cost": {
            # 证券类型
            "securitySecType": "4",
            "securityOpenRateAmt": "0.0003",
            "securityOpenRateCount": "0",
            "securityCloseRateAmt": "0.0003",
            "securityCloseRateCount": "0",
            "securityCloseTodayRate": "0.0003",
            "securityCloseTodayCount": "0",
            "securityTransferRate": "0",
            # 印花税
            "securityStampRate": "0.001",
            # 最低佣金
            "minCommission": "0",
        },
    }
    if "ratio_tpl_obj" in config:
        # 设置股票费率
        if "stock" in config["ratio_tpl_obj"]:
            fee_dict["stock_cost"].update(
                {
                    "securityOpenRateAmt": str(
                        round(
                            int(config["ratio_tpl_obj"]["stock"]["open_commission"])
                            / 10000,
                            4,
                        )
                    ),
                    "securityCloseRateAmt": str(
                        round(
                            int(config["ratio_tpl_obj"]["stock"]["close_commission"])
                            / 10000,
                            4,
                        )
                    ),
                    "securityCloseTodayRate": "0",
                    "minCommission": config["ratio_tpl_obj"]["stock"]["min_commission"],
                    "securityTransferRate": "0",
                    "securityStampRate": str(
                        round(
                            int(config["ratio_tpl_obj"]["stock"]["stamp_duty_sell"])
                            / 1000,
                            3,
                        )
                    ),
                }
            )
        # 设置基金费率
        if "fund" in config["ratio_tpl_obj"]:
            fee_dict["fund_cost"].update(
                {
                    "securityOpenRateAmt": str(
                        round(
                            int(config["ratio_tpl_obj"]["fund"]["open_commission"])
                            / 10000,
                            4,
                        )
                    ),
                    "securityCloseRateAmt": str(
                        round(
                            int(config["ratio_tpl_obj"]["fund"]["close_commission"])
                            / 10000,
                            4,
                        )
                    ),
                    "securityCloseTodayRate": "0",
                    "minCommission": config["ratio_tpl_obj"]["fund"]["min_commission"],
                    "securityTransferRate": "0",
                    "securityStampRate": "0",
                }
            )
        if "bond" in config["ratio_tpl_obj"]:
            fee_dict["bond_cost"].update(
                {
                    "securityOpenRateAmt": str(
                        round(
                            int(config["ratio_tpl_obj"]["bond"]["open_commission"])
                            / 10000,
                            4,
                        )
                    ),
                    "securityCloseRateAmt": str(
                        round(
                            int(config["ratio_tpl_obj"]["bond"]["close_commission"])
                            / 10000,
                            4,
                        )
                    ),
                    "securityCloseTodayRate": "0",
                    "minCommission": config["ratio_tpl_obj"]["bond"]["min_commission"],
                    "securityTransferRate": "0",
                    "securityStampRate": "0",
                }
            )
        # 设置期货费率
        if "future" in config["ratio_tpl_obj"]:
            openRateAmt = 0
            openRateCount = 0
            closeRateAmt = 0
            closeRateCount = 0
            closeTodayRateAmt = 0
            closeTodayRateCount = 0
            if "open_commission" in config["ratio_tpl_obj"]["future"]:
                openRateAmt = str(
                    round(
                        int(config["ratio_tpl_obj"]["future"]["open_commission"])
                        / 10000,
                        4,
                    )
                )
                openRateCount = str(0)
            if "close_commission" in config["ratio_tpl_obj"]["future"]:
                closeRateAmt = str(
                    round(
                        int(config["ratio_tpl_obj"]["future"]["close_commission"])
                        / 10000,
                        4,
                    )
                )
                closeRateCount = str(0)
            if "close_today_commission" in config["ratio_tpl_obj"]["future"]:
                closeTodayRateAmt = str(
                    round(
                        int(config["ratio_tpl_obj"]["future"]["close_today_commission"])
                        / 10000,
                        4,
                    )
                )
                closeTodayRateCount = str(0)
            if "open_fixed_commission" in config["ratio_tpl_obj"]["future"]:
                openRateAmt = str(0)
                openRateCount = str(
                    int(config["ratio_tpl_obj"]["future"]["open_fixed_commission"])
                )
            if "close_fixed_commission" in config["ratio_tpl_obj"]["future"]:
                closeRateAmt = str(0)
                closeRateCount = str(
                    int(config["ratio_tpl_obj"]["future"]["close_fixed_commission"])
                )
            if "close_today_fixed_commission" in config["ratio_tpl_obj"]["future"]:
                closeTodayRateAmt = str(0)
                closeTodayRateCount = str(
                    int(
                        config["ratio_tpl_obj"]["future"][
                            "close_today_fixed_commission"
                        ]
                    )
                )
            fee_dict["futures_cost"].update(
                {
                    "securityOpenRateAmt": openRateAmt,
                    "securityOpenRateCount": openRateCount,
                    "securityCloseRateAmt": closeRateAmt,
                    "securityCloseRateCount": closeRateCount,
                    "securityCloseTodayRate": closeTodayRateAmt,
                    "securityCloseTodayCount": closeTodayRateCount,
                    "minCommission": config["ratio_tpl_obj"]["future"][
                        "min_commission"
                    ],
                    "securityTransferRate": "0",
                    "securityStampRate": "0",
                }
            )

    return fee_dict


def run_main(params=None):
    """运行策略"""
    parser = argparse.ArgumentParser(description="策略运行参数")
    parser.add_argument("--config", type=str, default="./")
    parser.add_argument("--params", type=str, default="")
    args = parser.parse_args()  # 命令行获取参数
    path = args.config
    # 策略文件夹目录
    zltObj._context.backtest_param["project_path"] = path  # 策略文件夹的绝对路径
    config = ""
    try:
        # 读取配置文件
        config_path = os.path.join(path, ".vscode", "tradesetting.json")
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
    except Exception as e:
        raise e
    # 初始化策略运行参数
    try:
        initial_cash = 0  # 初始资金回测用户传入，实盘/仿真由交易模块获取
        userid = config["userid"]  # 用户id
        strategy_id = config["strategy_id"]  # 策略id
        backtest_id = config["backtest_id"]  # 回测id
        start = config["start"]  # 开始时间
        end = config["end"]  # 结束时间
        freq = config["freq"]  # 频率
        install_path = config["install_path"]  # 客户端安转路径
        type = config["type"]  # 策略运行类型
        zlt_zh_group = ""  # 账号组
        backtest_result_path = ""  # 回测数据存储文件夹
        trade_frequency = config.get("trade_frequency", "")  # 撮合频率
        market_ids = config.get("marketIds", ["sh", "sz"])
        mode = 3  # 默认回测模式
        if type == "simple_backtest":  # 回测
            mode = 3
            initial_cash = float(config["initial_capital"])  # 初始资金
            backtest_result_path = "backtestDB"
        else:
            zlt_zh_group = config["zlt_zh_group"]
            # 实盘传递账号组给交易模块使用
            if type == "simulation":  # 仿真
                mode = 1
                backtest_result_path = "simDB"
            elif type == "live":  # 实盘
                mode = 2
                backtest_result_path = "realDB"
        main_folder = os.path.join(install_path, "Users", "db", backtest_result_path)
        strategy_folder = os.path.join(main_folder, strategy_id)

        if not os.path.exists(main_folder):
            os.mkdir(main_folder)

        if not os.path.exists(strategy_folder):
            os.mkdir(strategy_folder)

        # 创建策略运行结果数据库
        zltObj._context.db_dir = strategy_folder
        db_folder = os.path.join(zltObj._context.db_dir, "strategy_result")
        if not os.path.exists(db_folder):
            os.mkdir(db_folder)

        # 创建仿真|实盘实时数据数据库
        if type != "simple_backtest":
            db_folder = os.path.join(strategy_folder, "strategy_tmp_result")
            if not os.path.exists(db_folder):
                os.mkdir(db_folder)
            db_path = os.path.join(db_folder, f"{backtest_id}.db")
            create_sim_strategy_db(db_path)
        # 交易使用字段 1: 留痕 0: 无
        zltObj._context.backtest_param["exec_type"] = config.get("exec_type", 0)
        zltObj._context.backtest_param["write_type"] = config.get("write_type", 0)

    except Exception as e:
        raise e
    try:
        # 是否开启日志 1开启 6关闭
        log_level = config.get("log_level", 2)
        # 参数优化-参数赋值
        try:
            if isinstance(params, dict):
                for key in params:
                    setattr(zltObj.g, key, params[key])
                log_level = 6
        except:
            raise Exception("传入的参数格式错误!仅支持字典格式")
        # 当前策略目录
        current_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
        current_dir = current_dir.replace("\\", "\\\\")
        # 公共日志路径
        logs_path = os.path.join(install_path, "Temporary", "logs", "strategylog")
        # 当前策略运行的环境 本地|云上 控制mr的启动模式
        env = config.get("env", "local")
        backtest_params = {
            "strategy_mode": mode,
            "backtest_id": backtest_id,
            "start_time": start + " 00:00:00",
            "end_time": end + " 23:59:59",
            "trade_time_notice": "true",
            "run_path": current_dir,
            "log_path": logs_path,
            "install_path": install_path,
            "log_level": log_level,
            "frequency": freq,
            "type": type,
            "initial_cash": initial_cash,
            "log_add_sub_dir": 1,
            "env": env,
            "exec_type": str(zltObj._context.backtest_param["exec_type"]),
            "write_type": str(zltObj._context.backtest_param["write_type"]),
            "trade_frequency": trade_frequency,
            "market_ids": ",".join(market_ids),
            "trade_type": config.get("trade_type", 0)
        }
        fee_dict = set_trade_fee(config)
        strategy_info = json.dumps(
            {
                "name": "myStrategy",
                "strategy_id": strategy_id,
            }
        )
        backtest_params["strategy_id"] = strategy_id
        # 策略账号组
        backtest_params["zlt_zh_group"] = zlt_zh_group
        run_params =  {**backtest_params, **fee_dict}
       

        zltObj._context.SetBacktestParams(run_params)
        # 保存当前用户ID
        zltObj._context.strategy_info["userid"] = userid
        # 保存当前策略ID
        zltObj._context.strategy_info["strategy_id"] = strategy_id
        # 保存当前回测ID
        zltObj._context.strategy_info["backtest_id"] = backtest_id
        # 保存当前的初始资金ID
        zltObj._context.backtest_param["initial_cash"] = initial_cash
        # 初始化全局上下文的运行参数
        zltObj._context.run_params = RunParams(
            start_date=start,
            end_date=end,
            type=run_params["type"],
            frequency=run_params["frequency"],
        )
        # 实例化策略对象并初始化context对象
        MyStrategy_Task = MyStrategy(config=config)
        ctypes.addressof(ctypes.c_int.from_address(id(MyStrategy_Task)))

        backtest_params = json.dumps(backtest_params, ensure_ascii=False)
        strategy_bridge.runpy(MyStrategy_Task, strategy_info, backtest_params)
        return zltObj._context.GetStrategyResult()
    except Exception as e:
        # 上报错误信息
        if zltObj._context.backtest_param["strategy_mode"] != 3:
            if nodeApi.timer_thread.is_alive():
                # 非回测需要停止线程
                nodeApi.timer_thread.stop()
                nodeApi.timer_thread.join()
        modify_backtest_status(zltObj._context, 2, remarks=str(e))
        raise e
