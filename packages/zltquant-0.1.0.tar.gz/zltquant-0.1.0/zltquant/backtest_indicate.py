'''
策略评估计算
'''
from statistics import covariance, variance
import numpy as np
from zltquant.util import zlt_object as zltObj
import math

def total_return(start, end):
    '''
    计算收益率
    '''
    if start == 0:
        return 0

    return (end - start) / start


def annualized_return(total_return, strategy_exec_days):
    '''
    计算年化收益率
    '''
    a = total_return
    b = 1+a
    c = b**(250/strategy_exec_days)
    return (c - 1)


def beta_val(strategy_daily_return_arr, benchmark_daily_return_arr):
    '''
    计算beta值
    '''
    if len(strategy_daily_return_arr) < 2:
        return None

    market_variance = variance(benchmark_daily_return_arr)
    # 计算Beta值
    if market_variance == 0:
        return None
    else:
        cov_data = covariance(strategy_daily_return_arr,
                              benchmark_daily_return_arr)
        return cov_data / market_variance


def alpha_val(strategy_annualized_return, benchmark_annualized_return, risk_free_rate, beta):
    '''
    计算alpha值
    '''
    if beta == None:
        return None
    a = strategy_annualized_return
    b = benchmark_annualized_return
    data = a - (risk_free_rate + beta*(b - risk_free_rate))
    return data


def volatility_val(strategy_daily_return_arr, strategy_exec_days):
    '''
    计算波动率
    '''
    # 计算平均回报率
    mean_return = sum(strategy_daily_return_arr) / \
        len(strategy_daily_return_arr)
    # 计算每期回报率与平均回报率之差的平方
    sum_squared_diff = 0
    for x in strategy_daily_return_arr:
        sum_squared_diff += (x-mean_return)**2
    if strategy_exec_days == 1:
        return 0
    val = math.sqrt((250 / (strategy_exec_days - 1)) * (sum_squared_diff))
    return val


def tracking_error_val(strategy_daily_return_arr, benchmark_daily_return_arr, strategy_exec_days):
    '''
    计算策略与基准每日收益差值的年化标准差
    '''
    algo_avg = sum(strategy_daily_return_arr) / len(strategy_daily_return_arr)
    bm_avg = sum(benchmark_daily_return_arr) / len(benchmark_daily_return_arr)
    squared_diff = (np.array(strategy_daily_return_arr) -
                    np.array(benchmark_daily_return_arr) - (algo_avg - bm_avg)) ** 2
    if strategy_exec_days == 1:
        return 0
    return math.sqrt((250 / (strategy_exec_days - 1)) * sum(squared_diff))


def max_drawdown_val(portfolio_arr, date, init_val=0, ei=False):
    '''
    计算最大回撤 时间轴正向的最高点和最低点
    ei是否为超额收益的计算
    '''
    new_list = portfolio_arr
    if ei:
        new_list = [x+1 for x in portfolio_arr]
    max_withdraw = 0
    max_date_end = 0
    max_date_beg = 0
    temp_max_date_end = 0
    max_high_price = init_val
    last_high = new_list[0] if ei else init_val
    for index, current in enumerate(new_list):
        # 遍历所有数据
        if current > last_high:
            last_high = current
            temp_max_date_end = index
            continue
        if abs(last_high - current) > max_withdraw:
            # 找到一个最大值时，保存其位置
            max_withdraw = abs(last_high-current)
            max_date_beg = temp_max_date_end
            max_date_end = index
            max_high_price = last_high
    # 变成百分比
    if max_withdraw == 0:
        return {"max_withdraw": 0, "begin": None, "end": None}
    # 计算超额收益率的最大回测时需要用(1 + 超额收率来计算)
    if ei and last_high < 1:
        return {"max_withdraw": abs(round(portfolio_arr[max_date_end] * 100, 2)), "begin": date[max_date_beg], "end": date[max_date_end]}
    return {"max_withdraw": round((max_withdraw / max_high_price)*100, 2), "begin": date[max_date_beg], "end": date[max_date_end]}


def downside_risk_val(strategy_daily_return_arr, strategy_exec_days):
    '''
    下行波动率
    '''
    if strategy_exec_days == 1:
        return 0

    squared_diff_sum = 0
    total = 0
    for index, x in enumerate(strategy_daily_return_arr):
        # 策略运行至第index日的平均收益率
        total += x
        # _temp = strategy_daily_return_arr[:index+1]
        # val = np.mean(_temp)
        _val = total / (index + 1)
        # print(val, _val)
        # 计算每期回报率与平均回报率之差的平方
        if x < _val:
            squared_diff_sum += ((x-_val)**2)

    return math.sqrt((250 / strategy_exec_days) * squared_diff_sum)


def excess_return_volatilty_val(daily_excess_return_arr, average_excess_return_index, strategy_exec_days):
    '''超额收益波动率
    '''
    squared_diff_sum = 0
    for x in daily_excess_return_arr:
        squared_diff_sum += ((x-average_excess_return_index) ** 2)
    if strategy_exec_days == 1:
        return 0
    return math.sqrt((250 / (strategy_exec_days - 1)) * (squared_diff_sum))


def get_everyday_rate(data, init):
    '''
    计算每日收益
    '''
    ret = []
    if init == 0:
        ret.append(0)
    else:
        ret.append((data[0] - init) / init)
    _len = len(data)
    for idx in range(1, _len):
        val = data[idx - 1]
        if val == 0:
            ret.append(0)
        else:
            ret.append(data[idx]/val - 1)
    return ret

def creat_backtest_indicate(date, portfolio, benchmark, init_cash, init_bench, risk_free_rate=0.04):
    info = {}
    # 风险系数
    info['risk_free_rate'] = risk_free_rate
    # 期初资金
    info['portfolio_value_beg'] = init_cash
    # 期末资金
    last_money = portfolio[-1]
    info["portfolio_value_end"] = last_money
    # 策略收益率
    info['strategy_total_return'] = total_return(init_cash, last_money)
    # 策略执行天数
    info["strategy_exec_days"] = len(portfolio)
    # 策略年化收益率
    info["strategy_annualized_return"] = annualized_return(
        info["strategy_total_return"], info["strategy_exec_days"])
    # 基准收益率
    info["benchmark_total_return"] = total_return(init_bench, benchmark[-1])
    # 基准年化收益率
    info["benchmark_annualized_return"] = annualized_return(
        info["benchmark_total_return"], info["strategy_exec_days"])
    # 策略每日收益率
    info["strategy_daily_return"] = get_everyday_rate(portfolio, init_cash)
    # 基准每日收益率
    info["benchmark_daily_return"] = get_everyday_rate(benchmark, init_bench)
    # 系统性风险 贝塔
    info["beta"] = beta_val(info["strategy_daily_return"],
                            info["benchmark_daily_return"])
    # 非系统性风险 阿尔法
    info["alpha"] = alpha_val(info["strategy_annualized_return"],
                              info["benchmark_annualized_return"], risk_free_rate, info["beta"])
    # 策略波动率
    info["algorithm_volatility"] = volatility_val(
        info["strategy_daily_return"], info["strategy_exec_days"])

    # 基准波动率
    info["benchmark_volatility"] = volatility_val(
        info["benchmark_daily_return"], info["strategy_exec_days"])
    # 夏普比率
    if info["algorithm_volatility"] == 0:
        info["sharp_ratio"] = 0
    else:
        a = info["strategy_annualized_return"]
        b = a - risk_free_rate
        c = b / info["algorithm_volatility"]
        info["sharp_ratio"] = c
    # 策略与基准每日收益差值的年化标准差
    info["tracking_error"] = tracking_error_val(
        info["strategy_daily_return"], info["benchmark_daily_return"], info["strategy_exec_days"])
    # 信息比率
    if info["tracking_error"] == 0:
        info["information_ratio"] = 0
    else:
        info["information_ratio"] = (
            info["strategy_annualized_return"] - info["benchmark_annualized_return"]) / info["tracking_error"]
    # 最大回撤
    info["max_drawdown"] = max_drawdown_val(portfolio, date, init_cash)
    # 下行波动率
    info["downside_risk"] = downside_risk_val(
        info["strategy_daily_return"], info["strategy_exec_days"])
    # 索提诺比率 -- 与聚宽有偏差
    if info["downside_risk"] != 0:
        val = info["strategy_annualized_return"] - risk_free_rate
        info["sortino_rate"] = val / info["downside_risk"]
    else:
        info["sortino_rate"] = 0
    # 超额收益
    if info["benchmark_total_return"] + 1 == 0:
        info["excess_return_index"] = 0
    else:
        info["excess_return_index"] = (
            (info["strategy_total_return"] + 1) / (info["benchmark_total_return"] + 1)) - 1
    # 每日超额收益
    info["daily_excess_return"] = []
    for idx, _val in enumerate(info["benchmark_daily_return"]):
        if _val + 1 == 0:
            info["daily_excess_return"].append(-1)
        else:
            info["daily_excess_return"].append((info["strategy_daily_return"][idx] + 1) /
                                               (_val + 1) - 1)
    # 日均超额收益
    info["average_excess_return_index"] = np.sum(
        info["daily_excess_return"]) / info["strategy_exec_days"]
    # 年化超额收益
    if info["benchmark_annualized_return"] + 1 == 0:
        info["annualized_excess_return"] = 0
    else:
        info["annualized_excess_return"] = (info["strategy_annualized_return"] + 1) / \
            (info["benchmark_annualized_return"] + 1) - 1

    # 超额收益波动率
    info["excess_return_volatilty"] = excess_return_volatilty_val(
        info["daily_excess_return"], info["average_excess_return_index"], info["strategy_exec_days"])
    # 超额收益最大回撤
    sum_excess_return = []
    for index, val in enumerate(portfolio):
        strategy_val = total_return(init_cash, val)
        benchmark_val = total_return(init_bench, benchmark[index])
        s = strategy_val + 1
        b = benchmark_val + 1
        if b == 0:
            excess_return = 0
        else:
            excess_return = s / b - 1
        sum_excess_return.append(excess_return)

    info["ei_max_drawdown"] = max_drawdown_val(
        sum_excess_return, date, ei=True)
    # 超额收益夏普比率
    if info["excess_return_volatilty"] == 0:
        info["ei_sharpe_ratio"] = 0
    else:
        info["ei_sharpe_ratio"] = (
            info["annualized_excess_return"] - risk_free_rate) / info["excess_return_volatilty"]
    # 日胜率（交易天数口径）策略收益率 > 基准收益率的天数/策略执行的天数
    day_win_count = 0
    for index, x in enumerate(info["strategy_daily_return"]):
        if x > info["benchmark_daily_return"][index]:
            day_win_count += 1
    info["win_rate_day"] = day_win_count / \
        info["strategy_exec_days"]
    # 盈利次数
    info["win_num"] = zltObj._context.strategy_info["win_num"]
    # 亏算次数
    info["lose_num"] = zltObj._context.strategy_info["lose_num"]
    # 胜率
    info["win_rate"] = info["win_num"] / \
        (info["win_num"] + info["lose_num"]
         )if (info["win_num"] + info["lose_num"]) > 0 else 0
    # 盈亏比  (卖出交割-买入交割) / 买入交割 使用平仓盈亏计算
    if zltObj._context.strategy_info['lose_money'] == 0:
        info["profit_loss_ratio"] = zltObj._context.strategy_info['win_money']
    else:
        info["profit_loss_ratio"] = abs(zltObj._context.strategy_info['win_money'] /
                                        zltObj._context.strategy_info['lose_money'])

    return info
