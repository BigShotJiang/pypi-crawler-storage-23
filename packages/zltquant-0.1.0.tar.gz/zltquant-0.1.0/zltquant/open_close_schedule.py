"""
收开盘定时任务初始化
"""

import os
from zltquant.util import zlt_others as zltOthers
from zltquant.util.zlt_util import param_to_dt
from zltquant.util import zlt_object as zltObj
from zltquant.util import zlt_strategy_exec as zltExec
from zltquant.util import modify_backtest_status
import zltsdk.strategy_bridge as strategy_bridge
import time


def check_cron(cron):
    """
    检查定时器是否存在 若不存在则订阅
    """
    if cron not in zltExec.schedule_list and cron not in zltExec.schedule:
        zltExec.schedule[cron] = {}
        zltExec.schedule_list.append(cron)
        zltObj._context.GetStrategyEngine().Schedule(cron)
    else:
        zltExec.schedule[cron] = {}


def debounce(wait_time):
    """
    防抖装饰器
    :param wait_time: 防抖时间
    """

    def decorator(func):
        def wrapper(*args, **kwargs):
            if hasattr(wrapper, "last_called"):
                elapsed = time.time() - wrapper.last_called
                if elapsed < wait_time:
                    return
            func(*args, **kwargs)
            wrapper.last_called = time.time()

        return wrapper

    return decorator


@debounce(1)
def change_process():
    """
    刷新运行进度
    """
    date1 = param_to_dt(zltObj._context.backtest_param["start_time"])
    date2 = param_to_dt(zltObj._context.backtest_param["end_time"])
    if (date2 - date1).days != 0:
        process = int(
            (zltObj._context.current_dt - date1).days / (date2 - date1).days * 100
        )
        modify_backtest_status(zltObj._context, 1, process)


def system_morning_close_function(context):
    # zltOthers.system_log.info('早间收盘触发事件')
    pass


def system_morning_open_function(context):
    # zltOthers.system_log.info('早间开盘触发事件')
    pass


def system_mid_close_function(context):
    # zltOthers.system_log.info('午间休市时触发事件')
    pass


def system_mid_open_function(context):
    # zltOthers.system_log.info('午间开盘时触发事件')
    pass


def system_night_close_function(context):
    # zltOthers.system_log.info('晚间收盘时触发事件')
    pass


def on_strategy_end(context):
    """
    策略运行结束->执行策略评估
    """
    pass


def init_system_task():
    """
    初始化内置生命周期内定时任务
    """
    # 每天定时重启无需重新加载行情数据
    # # 重新加载行情数据
    # check_cron("0 0 7 * * *")
    # zltExec.system_functions["system_reload_function"][
    #     "0 0 7 * * *"
    # ] = system_reload_function
    # 收盘任务
    check_cron("0 0 16 * * *")
    zltExec.system_functions["system_close_function"][
        "0 0 16 * * *"
    ] = system_close_function
    pass


def system_reload_function(context):
    """重新载入行情数据"""
    if zltObj._context.backtest_param["type"] != "simple_backtest":
        zltOthers.system_log.error("重新载入行情数据")
        strategy_bridge.ReloadHQ()
        pass


def system_close_function(context):
    """系统运行时--收盘事件"""
    # 回测收益计算
    if context.backtest_param["type"] == "simple_backtest":
        change_process()
        return
    # 仿真收益计算
    else:
        zltOthers.system_log.error("收盘事件触发,评估事件执行完毕!上报状态码:5 ")
        modify_backtest_status(zltObj._context, 5, 0, False, "评估数据写入完成")
         # 停止定时线程
        from zltquant.util import node_api
        if hasattr(node_api, 'timer_thread') and node_api.timer_thread.is_alive():
            node_api.timer_thread.stop()
        
        os._exit(0)
        return
