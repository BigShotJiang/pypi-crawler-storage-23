import argparse
import ctypes
import os
import sys
from zltsdk import strategy_bridge
from datetime import datetime
from .util import *
from zltquant.util import zlt_object as zltObj

def init_research(
    research_name="",
    frequency="tick",
    start_time="",
    end_time="",
    strategy_id="",
    backtest_id="",
    speed_mode=0,
):
    """
    研究模式初始化
    参数:
    - research_name: 研究名称
    - frequency: 研究频率
    - start_time: 研究开始时间
    - end_time: 研究结束时间
    - strategy_id: 策略ID
    - backtest_id: 回测ID
    - speed_mode: 研究速度模式
    """
    install_path = get_install_path()
    strategy_info = {
        "name": research_name,
        "strategy_id": strategy_id,
    }
    current_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
    current_dir = current_dir.replace("\\", "\\\\")
    research_id = (
        backtest_id
        if backtest_id != ""
        else ("RS-" + datetime.now().strftime("%Y%m%d%H%M%S"))
    )
    backtest_params = {
        "strategy_mode": 0,
        "backtest_id": research_id,
        "start_time": start_time,
        "end_time": end_time,
        "trade_time_notice": "true",
        "run_path": install_path + "/Temporary/logs/strategylog/",
        "log_level": 1,
        "type": "reseach",
        "install_path": install_path,
        "frequency": frequency,
        "log_add_sub_dir": 2,
        "trade_mode": 1,  # 向量撮合模式
        "log_path": install_path + "/Temporary/logs/strategylog/",
        "speed_mode": speed_mode,
        "market_ids":"sh,sz"
    }
    strategy_info = json.dumps(strategy_info, ensure_ascii=False)
    backtest_params = json.dumps(backtest_params, ensure_ascii=False)

    sdkContext = strategy_bridge.InitResearchMode(strategy_info, backtest_params)
    strategy_bridge.init_mr_data()

    zltObj._context.sdk_context = sdkContext
    # 配置回测参数
    zltObj._context.backtest_param.update(
        {
            "frequency": frequency,
            "start_time": "",
            "end_time": "",
            "install_path": install_path,
            "run_path": str(current_dir),
            "log_path": f"{install_path}/Temporary/logs/strategylog/",
        }
    )
    zltObj._context.strategy_info["backtest_id"] = research_id
    zltObj._context.backtest_param["strategy_mode"] = "research"
    # 绑定策略引擎
    zltObj._context.GetStrategyEngine = sdkContext.GetStrategyEngine
    zltObj._context.IPCClient = sdkContext.GetRPCClient()
    zltObj.ex_context.strategyEngine = zltObj._context.GetStrategyEngine()
    zltObj.ex_context.exDataIPC = sdkContext.GetRPCClient()
    return zltObj.ex_context


# =======================================================================================================================
# 向量模式
# =======================================================================================================================


def trade_init(strategy_id, backtest_id, start, end):
    """初始化交易信息"""
    strategyId = strategy_id
    fundAccid = backtest_id
    fundType = str(1)  # 1 股票 2 期货
    startTime = str(int(param_to_dt(f"{start} 00:00:00").timestamp()))
    endTime = str(int(param_to_dt(f"{end} 23:59:59").timestamp()))

    logLevel = str(4)
    slippageType = str(0)
    slippage = str(0)
    tradeType = str(0)
    orderVolumeRatio = str(0)
    jvKuanOpenAvgCostSwitch = str(0)
    adjustAqtyByAvail = str(0)
    takeFeeType = str(0)
    ans = strategy_bridge.TradeInit(
        strategyId,
        fundAccid,
        fundType,
        startTime,
        endTime,
        logLevel,
        slippageType,
        slippage,
        tradeType,
        orderVolumeRatio,
        jvKuanOpenAvgCostSwitch,
        adjustAqtyByAvail,
        takeFeeType,
    )


def trade_fee_init(strategy_id, backtest_id, fee_dict):
    """初始化交易费用信息"""
    strategyId = strategy_id
    fundAccid = backtest_id
    reqs = {}
    for i in ["stock_cost", "fund_cost", "futures_cost"]:
        reqs[i] = {
            "securityOpenRateAmt": str(fee_dict[i]["securityOpenRateAmt"]),
            "securityOpenRateCount": str(fee_dict[i]["securityOpenRateCount"]),
            "securityCloseRateAmt": str(fee_dict[i]["securityCloseRateAmt"]),
            "securityCloseRateCount": str(fee_dict[i]["securityCloseRateCount"]),
            "securityCloseTodayRate": str(fee_dict[i]["securityCloseTodayRate"]),
            "securityCloseTodayCount": str(fee_dict[i]["securityCloseTodayCount"]),
            "securityStampRate": str(fee_dict[i]["securityStampRate"]),
            "minCommission": str(fee_dict[i]["minCommission"]),
            "securityTransferRate": str(fee_dict[i]["securityTransferRate"]),
        }
    ans = strategy_bridge.TradeFeeAndAmtInit(strategyId, fundAccid, str(1000000), reqs)


class BarData:
    def __init__(self) -> None:
        self.open = None
        self.close = None
        self.low = None
        self.high = None
        self.volume = None
        self.money = None
        self.pre_close = None
        self.status = None
        self.open_interest = None
        self.time_ptr = None
        self.times_arr = None
        self.stocks = None
        self.max_size = None
        self.count = None
        self.stock_idx = None


class IndResult:
    def __init__(self, out_ind, np, data):
        self.out_ind = out_ind
        self.np = np
        self.data = data


class OrderSide(Enum):
    OrderSide_Buy = 1
    OrderSide_Sell = 2


class TradeModel(Enum):
    TradeModel_Long = 1
    TradeModel_Short = 2


class IndicatorMode(Enum):
    Ind = 0
    Sign = 1
    SignAndInd = 2


class IndOutNum(Enum):
    MA_BullishSignal = 3


class IndOutInd(Enum):
    MA_BullishSignal = ["long", "short"]


class JoinMode(Enum):
    no = 0
    left = 1
    right = 2
    high = 3
    low = 4
    sum = 5
    fill = 6


class zltEngine:
    def __init__(
        self,
        strategy_id,
        backtest_id,
        start,
        end,
        freq,
        initial_cash,
        conn,
        speed_mode,
        sdk_context,
        db_path,
        evaluate,
    ):
        self.strategy_id = strategy_id
        self.backtest_id = backtest_id
        self.start = start
        self.end = end
        self.freq = freq
        self.initial_cash = initial_cash
        self.conn = conn
        self.speed_mode = speed_mode
        self.sdk_context = sdk_context
        self.db_path = db_path
        self.evaluate = evaluate


class ZLTStrategy:
    def __init__(
        self, stocks, start, end, freq, init_cash, conn, engine: zltEngine
    ) -> None:
        self.stocks = stocks
        self.start = start
        self.end = end
        self.freq = freq
        self.init_cash = init_cash
        self.inds = {}
        self.ind = None
        self.need_result = False
        self.conn = conn
        self.engine = engine

    # 保存指标值
    def recoder_signal(self, res, data):
        stock_index = 0
        stocks = data.stocks
        times_arr = data.times_arr
        count = data.count
        total_count = 0
        insert_sql = """
            INSERT INTO zlt_signal (
                stock,
                time,
                signal
            ) VALUES (
                ?,?,?
            )
        """
        cursor = self.conn.cursor()
        for stock_data in stocks:
            numbers = count[stock_index]
            data_tuple = (
                stock_data,
                json.dumps(times_arr[stock_index]),
                json.dumps(
                    list(
                        res[total_count : total_count + numbers + 1].astype(np.float64)
                    )
                ),
            )
            cursor.execute(insert_sql, data_tuple)
            total_count += numbers
            stock_index += 1
        self.conn.commit()
        pass

    # 设置指标值
    def trade_oder(self, out_ind, np_arr, data) -> IndResult:
        self.need_result = True
        self.ind = IndResult(out_ind, np_arr, data)
        return self.ind

    # 获取指标值
    def get_ind_data(self) -> IndResult:
        return self.ind


def GetBarDataByGpu(context: ZLTStrategy, count=0, freq="") -> BarData:
    if freq == "":
        if context.freq == "min":
            freq = "1m"
        elif context.freq == "day":
            freq = "1d"
        else:
            freq = context.freq
    if count > 0:
        num = int(freq[:-1])
        count = num * count
        t_freq = "1" + freq[-1]
        data = strategy_bridge.GetBarDataFromGpu(
            context.stocks, "", context.end, count, t_freq
        )
    else:
        t_freq = "1" + freq[-1]
        data = strategy_bridge.GetBarDataFromGpu(
            context.stocks, context.start, context.end, 0, freq
        )
    return data


def GetBarDataByCpu(context: ZLTStrategy, count=0, freq="") -> BarData:
    if freq == "":
        if context.freq == "min":
            freq = "1m"
        elif context.freq == "day":
            freq = "1d"
        else:
            freq = context.freq
    if count > 0:
        num = int(freq[:-1])
        count = num * count
        t_freq = "1" + freq[-1]
        data = strategy_bridge.GetBarDataFromCpu(
            context.stocks, "", context.end, count, t_freq
        )
    else:
        t_freq = "1" + freq[-1]
        data = strategy_bridge.GetBarDataFromCpu(
            context.stocks, context.start, context.end, 0, t_freq
        )
    return data


def GetTickData(context: ZLTStrategy):
    data = strategy_bridge.GetTickDataFromGpu(
        context.stocks, context.start, context.end
    )
    return data


def transformCTime(BarData: BarData, stock):
    start = time.perf_counter()
    index = BarData.stock_idx[stock]
    obj = BarData.time_ptr[index]
    c_int64_ptr = ctypes.cast(obj, ctypes.POINTER(ctypes.c_uint32))
    # 映射为 NumPy 数组
    np_array = np.ctypeslib.as_array(c_int64_ptr, shape=(BarData.count[index],))
    print(np_array)
    print("3===>转换时间耗时 ", (time.perf_counter() - start) * 1000, "ms")
    return np_array


def initNpMemory(gpu_data, out_ind_num):
    """初始化numpy内存"""
    size = len(gpu_data.stocks) * gpu_data.max_size * out_ind_num
    arr = np.zeros(size, dtype=np.float32)
    buffer_size = size * np.float32(0).itemsize
    return arr, buffer_size


def runSdkMethod(zlt_ind_func, data, mode, resnum, join_method=0, freq=1, *func_params):
    """执行内置函数

    params:
        zlt_ind_func,

        data,

        mode,

        resnum,

        join_method=0,

        freq=1,

        *func_params 指標需要的入參, 不定長可變參數
    """
    # 初始化计算结果数组
    start = time.perf_counter()
    res, size = initNpMemory(data, resnum)
    # print("申请内存耗时", (time.perf_counter() - start) * 1000, "ms")
    result = zlt_ind_func(
        len(data.stocks),
        data.max_size,
        data.count,
        mode,
        res,
        size,
        *func_params,
        join_method,
        freq,
    )
    # print("errno===>", result.error_code, ", errmsg===>", result.error_message)
    return res


def set_trade_fee(config):
    fee_dict = {
        "stock_cost": {
            # 证券类型
            "securitySecType": "1",
            "securityOpenRateAmt": "0.0003",
            "securityOpenRateCount": "0",
            "securityCloseRateAmt": "0.0003",
            "securityCloseRateCount": "0",
            "securityCloseTodayRate": "0.0003",
            "securityCloseTodayCount": "0",
            "securityTransferRate": "0",
            # 印花税
            "securityStampRate": "0.001",
            # 最低佣金
            "minCommission": "5",
        },
        "fund_cost": {
            # 证券类型
            "securitySecType": "3",
            "securityOpenRateAmt": "0.0003",
            "securityOpenRateCount": "0",
            "securityCloseRateAmt": "0.0003",
            "securityCloseRateCount": "0",
            "securityCloseTodayRate": "0",
            "securityCloseTodayCount": "0",
            "securityTransferRate": "0",
            # 印花税
            "securityStampRate": "0",
            # 最低佣金
            "minCommission": "0",
        },
        "futures_cost": {
            # 证券类型
            "securitySecType": "2",
            "securityOpenRateAmt": "0.0003",
            "securityOpenRateCount": "0",
            "securityCloseRateAmt": "0.0003",
            "securityCloseRateCount": "0",
            "securityCloseTodayRate": "0.0003",
            "securityCloseTodayCount": "0",
            # 过户费
            "securityTransferRate": "0",
            # 印花税
            "securityStampRate": "0",
            # 最低佣金
            "minCommission": "0",
            # 保证金
            "futuresMarginRate": "0",
        },
        "bond_cost": {
            # 证券类型
            "securitySecType": "4",
            "securityOpenRateAmt": "0.0003",
            "securityOpenRateCount": "0",
            "securityCloseRateAmt": "0.0003",
            "securityCloseRateCount": "0",
            "securityCloseTodayRate": "0.0003",
            "securityCloseTodayCount": "0",
            "securityTransferRate": "0",
            # 印花税
            "securityStampRate": "0.001",
            # 最低佣金
            "minCommission": "0",
        },
    }
    if "ratio_tpl_obj" in config:
        # 设置股票费率
        if "stock" in config["ratio_tpl_obj"]:
            fee_dict["stock_cost"].update(
                {
                    "securityOpenRateAmt": str(
                        round(
                            int(config["ratio_tpl_obj"]["stock"]["open_commission"])
                            / 10000,
                            4,
                        )
                    ),
                    "securityCloseRateAmt": str(
                        round(
                            int(config["ratio_tpl_obj"]["stock"]["close_commission"])
                            / 10000,
                            4,
                        )
                    ),
                    "securityCloseTodayRate": "0",
                    "minCommission": config["ratio_tpl_obj"]["stock"]["min_commission"],
                    "securityTransferRate": "0",
                    "securityStampRate": str(
                        round(
                            int(config["ratio_tpl_obj"]["stock"]["stamp_duty_sell"])
                            / 1000,
                            3,
                        )
                    ),
                }
            )
        # 设置基金费率
        if "fund" in config["ratio_tpl_obj"]:
            fee_dict["fund_cost"].update(
                {
                    "securityOpenRateAmt": str(
                        round(
                            int(config["ratio_tpl_obj"]["fund"]["open_commission"])
                            / 10000,
                            4,
                        )
                    ),
                    "securityCloseRateAmt": str(
                        round(
                            int(config["ratio_tpl_obj"]["fund"]["close_commission"])
                            / 10000,
                            4,
                        )
                    ),
                    "securityCloseTodayRate": "0",
                    "minCommission": config["ratio_tpl_obj"]["fund"]["min_commission"],
                    "securityTransferRate": "0",
                    "securityStampRate": "0",
                }
            )
        if "bond" in config["ratio_tpl_obj"]:
            fee_dict["bond_cost"].update(
                {
                    "securityOpenRateAmt": str(
                        round(
                            int(config["ratio_tpl_obj"]["bond"]["open_commission"])
                            / 10000,
                            4,
                        )
                    ),
                    "securityCloseRateAmt": str(
                        round(
                            int(config["ratio_tpl_obj"]["bond"]["close_commission"])
                            / 10000,
                            4,
                        )
                    ),
                    "securityCloseTodayRate": "0",
                    "minCommission": config["ratio_tpl_obj"]["bond"]["min_commission"],
                    "securityTransferRate": "0",
                    "securityStampRate": "0",
                }
            )
        # 设置期货费率
        if "future" in config["ratio_tpl_obj"]:
            openRateAmt = 0
            openRateCount = 0
            closeRateAmt = 0
            closeRateCount = 0
            closeTodayRateAmt = 0
            closeTodayRateCount = 0
            if "open_commission" in config["ratio_tpl_obj"]["future"]:
                openRateAmt = str(
                    round(
                        int(config["ratio_tpl_obj"]["future"]["open_commission"])
                        / 10000,
                        4,
                    )
                )
                openRateCount = str(0)
            if "close_commission" in config["ratio_tpl_obj"]["future"]:
                closeRateAmt = str(
                    round(
                        int(config["ratio_tpl_obj"]["future"]["close_commission"])
                        / 10000,
                        4,
                    )
                )
                closeRateCount = str(0)
            if "close_today_commission" in config["ratio_tpl_obj"]["future"]:
                closeTodayRateAmt = str(
                    round(
                        int(config["ratio_tpl_obj"]["future"]["close_today_commission"])
                        / 10000,
                        4,
                    )
                )
                closeTodayRateCount = str(0)
            if "open_fixed_commission" in config["ratio_tpl_obj"]["future"]:
                openRateAmt = str(0)
                openRateCount = str(
                    int(config["ratio_tpl_obj"]["future"]["open_fixed_commission"])
                )
            if "close_fixed_commission" in config["ratio_tpl_obj"]["future"]:
                closeRateAmt = str(0)
                closeRateCount = str(
                    int(config["ratio_tpl_obj"]["future"]["close_fixed_commission"])
                )
            if "close_today_fixed_commission" in config["ratio_tpl_obj"]["future"]:
                closeTodayRateAmt = str(0)
                closeTodayRateCount = str(
                    int(
                        config["ratio_tpl_obj"]["future"][
                            "close_today_fixed_commission"
                        ]
                    )
                )
            fee_dict["futures_cost"].update(
                {
                    "securityOpenRateAmt": openRateAmt,
                    "securityOpenRateCount": openRateCount,
                    "securityCloseRateAmt": closeRateAmt,
                    "securityCloseRateCount": closeRateCount,
                    "securityCloseTodayRate": closeTodayRateAmt,
                    "securityCloseTodayCount": closeTodayRateCount,
                    "minCommission": config["ratio_tpl_obj"]["future"][
                        "min_commission"
                    ],
                    "securityTransferRate": "0",
                    "securityStampRate": "0",
                }
            )

    return fee_dict


def init_engine(userCofig={}, speed_mode=0, evaluate=False) -> zltEngine:
    """初始化引擎"""
    parser = argparse.ArgumentParser(description="策略运行参数")
    parser.add_argument("--config", type=str, default="./")
    parser.add_argument("--params", type=str, default="")
    args = parser.parse_args()  # 命令行获取参数
    path = args.config

    # 策略文件夹目录
    config = ""
    try:
        # 读取配置文件
        config_path = os.path.join(path, ".vscode", "tradesetting.json")
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
    except Exception as e:
        raise e
    # print("策略运行参数===>", config, flush=True)
    # 初始化策略运行参数
    initial_cash = config["initial_capital"]
    userid = config["userid"]  # 用户id
    strategy_id = config["strategy_id"]  # 策略id
    backtest_id = config["backtest_id"]  # 回测id
    start = config["start"]  # 开始时间
    end = config["end"]  # 结束时间
    freq = config["freq"]  # 频率
    install_path = config["install_path"]  # 客户端安转路径
    type = config["type"]  # 策略运行类型
    zlt_zh_group = ""  # 账号组
    backtest_result_path = ""  # 回测数据存储文件夹
    trade_frequency = config.get("trade_frequency", "")  # 撮合频率
    speed_mode = config.get("speed_mode", 0)

    fee_dict = set_trade_fee(config)
    sdkContext = init_research(
        strategy_id=strategy_id, backtest_id=backtest_id, speed_mode=speed_mode
    )
    conn = None
    db_path = None
    main_folder = os.path.join(
        install_path, "Users", "db", "backtestDB", backtest_result_path
    )
    strategy_folder = os.path.join(main_folder, strategy_id)

    if not os.path.exists(main_folder):
        os.mkdir(main_folder)

    if not os.path.exists(strategy_folder):
        os.mkdir(strategy_folder)

    # 创建策略运行结果数据库
    db_folder = os.path.join(strategy_folder, "strategy_result")
    if not os.path.exists(db_folder):
        os.mkdir(db_folder)
    db_path = f"{db_folder}/{backtest_id}.db"
    conn = sqlite3.connect(f"{db_folder}/{backtest_id}.db")
    cursor = conn.cursor()
    sql_file = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "./util", "strategy.sql"
    )
    # 读取SQL文件
    with open(sql_file, "r", encoding="utf-8") as sql_file:
        sql_script = sql_file.read()

    try:
        # 执行SQL脚本
        cursor.executescript(sql_script)
        conn.commit()
        system_log.info("SQL脚本执行成功")
    except Exception as e:
        conn.rollback()
        system_log.info(f"执行SQL脚本时出错: {e}")
        conn.close()
        raise e
    if evaluate:
        trade_init(strategy_id, backtest_id, start, end)
        trade_fee_init(strategy_id, backtest_id, fee_dict)
    strategy_bridge.SetCPartDb(db_path)
    engine = zltEngine(
        strategy_id,
        backtest_id,
        start,
        end,
        freq,
        initial_cash,
        conn,
        speed_mode,
        sdkContext,
        db_path,
        evaluate,
    )
    return engine


def runStrategy(user_func, stocks, engine: zltEngine):
    """执行引擎"""
    context = ZLTStrategy(
        stocks,
        engine.start,
        engine.end,
        engine.freq,
        engine.initial_cash,
        engine.conn,
        engine,
    )

    # 执行指标计算逻辑
    user_func(context)
    # 用户调用交易接口
    if context.need_result and engine.evaluate:
        # 获取用户设置的指标值
        indData = context.get_ind_data()
        t_start = time.perf_counter()
        strategy_bridge.CGPUTradeOrder(
            indData.data,
            indData.np,
            {
                "backtest_id": engine.backtest_id,
                "init_cash": str(engine.initial_cash),  # 初始资金
                "start": engine.start,  # 开始时间
                "end": engine.end,  # 结束时间
                "db_path": engine.db_path,  # 数据库地址
                "hold_freq": "3d",  # 调仓频率
                "hold_max": "3",  # 持仓上限
                "hold_weight": "20",  # 持仓权重
                "order_qty": "200",
            },
        )
        print("3)C层处理信号耗时===>", time.perf_counter() - t_start, "s")
    get_ipc_result(
        engine.sdk_context.exDataIPC,
        {
            "strategy_id": engine.strategy_id,
            "backtest_id": engine.backtest_id,
            "progress": 100,
            "status": 5,
            "end_time": int(datetime.now().timestamp()) * 1000,
        },
        "zltBacktest",
        "modify-backtest-status",
        "0",
    )


def record_stock_result(engine: zltEngine, stocks, times):
    """写入选股结果"""
    result = []
    stock_index = 0
    for stock in stocks:
        result.append([times[stock_index], stock])
        stock_index += 1
    get_ipc_result(
        engine.sdk_context.exDataIPC,
        {
            "key": engine.backtest_id + "_stock_result",
            "val": json.dumps({"desc": ["time", "stock"], "value": result}),
        },
        "zltBacktest",
        "redis/set-redis-data",
        "0",
    )


def record_bar_indicator(
    context: ZLTStrategy, barData: BarData, res, join_freq, signal
):
    strategy_bridge.RecordIndAndSignal(
        barData, res, join_freq, signal, {"db_path": context.engine.db_path}
    )


def orderBarSignal(context: ZLTStrategy, barData: BarData, res, join_freq, ind):
    strategy_bridge.orderBarSignal(
        barData,
        res,
        join_freq,
        ind,
        {
            "backtest_id": context.engine.backtest_id,
            "init_cash": str(context.init_cash),  # 初始资金
            "start": context.start,  # 开始时间
            "end": context.end,  # 结束时间
            "db_path": context.engine.db_path,  # 数据库地址
            "hold_freq": "3d",  # 调仓频率
            "hold_max": "3",  # 持仓上限
            "hold_weight": "20",  # 持仓权重
            "order_qty": "200",
            "is_gpu": "1",
        },
    )


def record_indicator_val(engine: zltEngine, times, stocks, indicator, indicator_val):
    """写入指标值"""
    result = []
    stock_index = 0
    for stock in stocks:
        result.append([times[stock_index], stock, indicator_val[stock_index]])
        stock_index += 1
    desc = ["time", "stock"] + indicator
    get_ipc_result(
        engine.sdk_context.exDataIPC,
        {
            "key": engine.backtest_id + "_indicator_val",
            "val": json.dumps({"desc": desc, "value": result}),
        },
        "zltBacktest",
        "redis/set-redis-data",
        "0",
    )


def orderBySignal(time_list, stock_list, signal_list, price_list, engine: zltEngine):
    strategy_id = engine.strategy_id
    backtest_id = engine.backtest_id
    conn = engine.conn
    start = engine.start
    end = engine.end
    initial_cash = engine.initial_cash
    sdk_context = engine.sdk_context
    if (
        len(time_list) != len(stock_list)
        or len(time_list) != len(signal_list)
        or len(time_list) != len(price_list)
    ):
        raise ValueError(
            "time_list, stock_list, signal_list, price_list 长度不一致, 请检查输入参数"
        )
    df = pd.DataFrame(
        {
            "time": time_list,
            "stock": stock_list,
            "signal": signal_list,
            "price": price_list,
        }
    )
    times = df["time"].to_list()
    stock = df["stock"].to_list()
    singles = df["signal"].to_list()
    prices = df["price"].to_list()
    counts = df["stock"].value_counts().to_list()
    max_size = max(counts)
    strategy_bridge.PyTradeOrder(
        stock,
        counts,
        times,
        singles,
        prices,
        max_size,
        {
            "backtest_id": backtest_id,
            "init_cash": str(initial_cash),  # 初始资金
            "start": start,  # 开始时间
            "end": end,  # 结束时间
            "db_path": engine.db_path,  # 数据库地址
            "hold_freq": "3d",  # 调仓频率
            "hold_max": "3",  # 持仓上限
            "hold_weight": "20",  # 持仓权重
            "order_qty": "200",
        },
    )
    stock_index = 0
    stocks = df["stock"].unique().tolist()
    times_arr = times
    count = counts
    total_count = 0
    insert_sql = """
        INSERT INTO zlt_signal (
            stock,
            time,
            signal
        ) VALUES (
            ?,?,?
        )
    """
    cursor = conn.cursor()
    for stock_data in stocks:
        numbers = count[stock_index]
        data_tuple = (
            stock_data,
            json.dumps(times_arr[stock_index]),
            json.dumps(singles[total_count : total_count + numbers + 1]),
        )
        cursor.execute(insert_sql, data_tuple)
        total_count += numbers
        stock_index += 1
    conn.commit()
    conn.close()

    get_ipc_result(
        sdk_context.exDataIPC,
        {
            "strategy_id": strategy_id,
            "backtest_id": backtest_id,
            "progress": 100,
            "status": 5,
            "end_time": int(datetime.now().timestamp()) * 1000,
        },
        "zltBacktest",
        "modify-backtest-status",
        "0",
    )
    get_ipc_result(
        sdk_context.exDataIPC,
        {"strategyId": strategy_id, "backtestId": backtest_id},
        "zltBacktest",
        "redis/set-protobuf-data-to-redis",
        "0",
    )
    return 0
