from zltquant.open_close_schedule import check_cron
from zltquant.util import zlt_strategy_exec as zltExec
from zltquant.util import zlt_object as zltObj

BEFORE_OPEN = "0 0 09 * * *"
AFTER_TRADE = "0 30 15 * * *"


def init_callback_func(user_moudle, funcs):
    """
    挂载用户策略中调用的回调函数
    """
    # 每天开盘前触发
    if "before_trading_start" in funcs:
        check_cron(BEFORE_OPEN)
        zltExec.system_functions["before_trading_start"][
            BEFORE_OPEN
        ] = user_moudle.before_trading_start
    # 每天交易结束后触发
    if "after_trading_end" in funcs:
        check_cron(AFTER_TRADE)
        zltExec.system_functions["after_trading_end"][
            AFTER_TRADE
        ] = user_moudle.after_trading_end
    # 策略结束触发
    if "on_strategy_end" in funcs:
        zltExec.system_functions["on_strategy_end"] = user_moudle.on_strategy_end
    # tick级别循环
    if "handle_tick" in funcs:
        zltExec.system_functions["handle_tick"] = user_moudle.handle_tick
    # 非tick级别循坏
    if "handle_data" in funcs:
        zltExec.system_functions["handle_data"] = user_moudle.handle_data
    # 行情推送
    if "on_bar" in funcs:
        zltExec.system_functions["on_bar"] = user_moudle.on_bar
    # 交易完成触发
    if "on_order" in funcs:
        zltObj._context.callback_event["on_order"] = user_moudle.on_order
    # 可用资金监控
    if "on_money_less" in funcs:
        zltObj._context.callback_event["on_money_less"] = user_moudle.on_money_less
    # 仓位监控
    if "on_position_warning" in funcs:
        zltObj._context.callback_event["on_position_warning"] = (
            user_moudle.on_position_warning
        )


def run_schedule(cronRule):
    """
    执行计时器任务
    """
    # 系统开盘通知
    if cronRule in zltExec.system_functions["system_open_function"]:
        obj = zltExec.system_functions["system_open_function"][cronRule]
        obj["func"](obj["type"])
    # 用户侧开盘前事件
    if cronRule in zltExec.system_functions["before_trading_start"]:
        zltExec.system_functions["before_trading_start"][cronRule](zltObj._context)
    # 用户侧收盘前事件
    if cronRule in zltExec.system_functions["after_trading_end"]:
        zltExec.system_functions["after_trading_end"][cronRule](zltObj._context)
    # 系统收盘通知
    if cronRule in zltExec.system_functions["system_close_function"]:
        zltExec.system_functions["system_close_function"][cronRule](zltObj._context)
    if cronRule in zltExec.system_functions["system_reload_function"]:
        zltExec.system_functions["system_reload_function"][cronRule](zltObj._context)
    # 其他时段通知事件挂载
    # if cronRule in zltExec.system_functions["system_mid_open_function"]:
    #     zltExec.system_functions["system_mid_open_function"][cronRule](zltObj._context)
    # if cronRule in zltExec.system_functions["system_mid_close_function"]:
    #     zltExec.system_functions["system_mid_close_function"][cronRule](zltObj._context)
    # if cronRule in zltExec.system_functions["system_morning_open_function"]:
    #     zltExec.system_functions["system_morning_open_function"][cronRule](zltObj._context)
    # if cronRule in zltExec.system_functions["system_morning_close_function"]:
    #     zltExec.system_functions["system_morning_close_function"][cronRule](zltObj._context)
    # if cronRule in zltExec.system_functions["system_night_close_function"]:
    #     zltExec.system_functions["system_night_close_function"][cronRule](zltObj._context)

    # 用户侧月级别定时事件
    if cronRule in zltExec.mon_schedule:
        if zltObj._context.current_dt.strftime("%Y%m%d") in zltObj._context.run_monthly:
            for item in zltExec.mon_schedule[cronRule]:
                item(zltObj._context)

    # 用户侧周级别定时事件
    if cronRule in zltExec.week_schedule:
        if zltObj._context.current_dt.strftime("%Y%m%d") in zltObj._context.run_weekly:
            for item in zltExec.week_schedule[cronRule]:
                item(zltObj._context)

    # 其他时间点定时事件
    if cronRule in zltExec.schedule:
        # 同一时间点挂载了多个事件 按照挂载顺序执行
        if isinstance(zltExec.schedule[cronRule], list):
            for item in zltExec.schedule[cronRule]:
                item(zltObj._context)
        else:
            # 其它系统级的事件同一时间点触发
            for item in zltExec.schedule[cronRule].values():
                item(zltObj._context)
                # if item.__name__ in ["handle_data"]:
                #     item(zltObj._context, barDict)
                # else:
                # item(zltObj._context)
