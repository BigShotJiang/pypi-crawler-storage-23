from sqlalchemy import create_engine
import pandas as pd

def get_spot_data(symbol, start_date, end_date):
    # 连接配置
    username = 'read'
    password = ''
    host = '192.168.1.200'
    port = 3306
    database = 'zltdb'

    # 创建连接引擎
    engine = create_engine(f'mysql+pymysql://{username}:{password}@{host}:{port}/{database}?charset=utf8')

    # 查询方法1：使用pandas
    def query_mysql(sql):
        try:
            df = pd.read_sql(sql, engine)
            return df
        except Exception as e:
            print(f"查询错误: {e}")
            return None
    sql = "SELECT * FROM spot_data"
    result_df = query_mysql(sql)
    return result_df
