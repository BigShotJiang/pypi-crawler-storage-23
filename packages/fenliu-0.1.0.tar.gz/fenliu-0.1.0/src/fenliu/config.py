"""Configuration settings for the FenLiu application."""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings."""

    app_name: str = "FenLiu"
    app_version: str = "0.1.0"
    debug: bool = False
    database_url: str = "sqlite:///./fenliu.db"
    default_instance: str = "mastodon.social"
    secret_key: str = "your-secret-key-change-in-production"  # noqa: S105
    # Development placeholder - set via SECRET_KEY env var in production

    # Fediverse API settings
    api_timeout: int = 30
    max_posts_per_fetch: int = 20
    rate_limit_delay: float = 1.0

    # Web interface settings
    posts_per_page: int = 20
    refresh_interval: int = 300  # seconds

    class Config:
        """Pydantic configuration."""

        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
