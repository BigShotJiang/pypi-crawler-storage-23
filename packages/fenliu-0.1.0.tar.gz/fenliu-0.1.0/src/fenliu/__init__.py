"""FenLiu - Fediverse content stream filtering system.

This package implements a web application for monitoring Fediverse hashtags,
filtering spam, allowing human review, learning from feedback, and exporting
quality content for boosting.

Inspired by ancient Chinese water management principles (分流 - "divide the flow").
"""
