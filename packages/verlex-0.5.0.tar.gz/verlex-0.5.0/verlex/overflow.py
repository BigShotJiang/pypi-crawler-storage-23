"""
Automatic cloud offloading when local resources are exceeded.

When CPU, memory, or GPU usage exceeds a configurable threshold, heavy
computations are transparently offloaded to the cheapest cloud provider
via the existing Verlex pipeline (LLM resource analysis -> cheapest
provider selection -> cloud execution -> result back to local).

Two additional optimisations reduce perceived latency:

1.  **Predictive pre-warming** ("start the car") — at ``overflow()``
    time the caller's source is parsed with ``ast`` to predict what
    resource tier will be needed.  A background request fires off to
    ``/v1/pre-warm`` so a VM is already booting while the user's setup
    code runs.

2.  **Smart data offloading** — when a function argument exceeds 50 MB,
    it is uploaded to the backend's ephemeral object store *before*
    the cloudpickle payload is built.  A lightweight resolver wrapper
    downloads the data on the cloud side just before calling the
    original function.  After the result is returned the data is
    flushed (deleted) from the store.

Usage:
    import verlex
    verlex.overflow(fast=True)

    # All functions above are pre-wrapped immediately.
    # If the system is already overloaded when a function is called,
    # it runs in the cloud — even on the very first call.
    data = load_data()
    result = train_model(data)   # system overloaded? -> cloud
    result2 = train_model(data2) # still overloaded? -> cloud again
    evaluate(result2)            # resources free -> runs locally
"""

from __future__ import annotations

import atexit
import functools
import logging
import os
import sys
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

logger = logging.getLogger("verlex.overflow")

_DEFAULT_API_URL = "https://gateway-production-8435.up.railway.app"


# ---------------------------------------------------------------------------
# Helpers  (defined first — used by the main class)
# ---------------------------------------------------------------------------


class _WrapRecord:
    """Bookkeeping for a single wrapped function."""

    __slots__ = ("original", "name", "namespace", "wrapper")

    def __init__(
        self,
        original: Callable[..., Any],
        name: str,
        namespace: dict[str, Any],
        wrapper: Callable[..., Any],
    ) -> None:
        self.original = original
        self.name = name
        self.namespace = namespace
        self.wrapper = wrapper


def _compute_exclude_prefixes() -> Tuple[str, ...]:
    """Return absolute path prefixes for stdlib, site-packages, and verlex."""
    import sysconfig as _sc

    paths: set[str] = set()

    for key in ("stdlib", "platstdlib", "purelib", "platlib"):
        p = _sc.get_paths().get(key, "")
        if p:
            paths.add(os.path.abspath(p))

    try:
        import site

        for sp in site.getsitepackages():
            paths.add(os.path.abspath(sp))
        usp = site.getusersitepackages()
        if isinstance(usp, str):
            paths.add(os.path.abspath(usp))
    except Exception:
        pass

    # Exclude verlex itself.
    paths.add(os.path.dirname(os.path.abspath(__file__)))

    # Sort longest-first so the most specific prefix matches first.
    return tuple(sorted(paths, key=len, reverse=True))


# ---------------------------------------------------------------------------
# Core monitor
# ---------------------------------------------------------------------------


class _OverflowMonitor:
    """Watches CPU / memory / GPU and transparently offloads heavy functions."""

    def __init__(
        self,
        fast: bool,
        threshold: float,
        check_interval: float,
        api_key: Optional[str],
        api_url: Optional[str],
        gpu_threshold: Optional[float] = None,
        # Legacy params (ignored, kept for backward compat)
        priority: bool | None = None,
        flexible: bool | None = None,
    ) -> None:
        self.fast = fast
        self.threshold = threshold
        self.check_interval = check_interval
        self.gpu_threshold = gpu_threshold if gpu_threshold is not None else threshold
        self.api_key = (
            api_key
            or os.environ.get("VERLEX_API_KEY")
            or os.environ.get("GATEWAY_API_KEY")
        )
        self.api_url = api_url or os.environ.get(
            "VERLEX_API_URL", _DEFAULT_API_URL
        )

        # Runtime state -------------------------------------------------------
        self._running = False
        self._overloaded = False
        self._cpu_usage = 0.0
        self._mem_usage = 0.0
        self._gpu_util = 0.0
        self._gpu_mem_util = 0.0
        self._gpu_available = False
        self._nvml_handle: Any = None

        # Function tracking ---------------------------------------------------
        self._call_stack: list[dict[str, Any]] = []
        self._wrapped_functions: Dict[int, _WrapRecord] = {}
        self._heavy_signatures: Set[Tuple[str, str, int]] = set()
        self._scope_wrapped = False

        # Caches --------------------------------------------------------------
        self._filename_cache: Dict[str, bool] = {}

        # Threading -----------------------------------------------------------
        self._lock = threading.Lock()
        self._monitor_thread: Optional[threading.Thread] = None
        self._original_profile: Any = None

        # Gateway client (lazy) -----------------------------------------------
        self._gateway: Any = None
        self._gateway_lock = threading.Lock()

        # Pre-warming result (shared with the GateWay instance) ---------------
        self._warm_result: dict[str, Any] = {}

        # Pre-compute path prefixes to exclude --------------------------------
        self._exclude_prefixes = _compute_exclude_prefixes()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Begin monitoring.  Raises ``ImportError`` if *psutil* is missing."""
        try:
            import psutil  # noqa: F401
        except ImportError:
            raise ImportError(
                "psutil is required for overflow monitoring. "
                "Install it with:  pip install 'verlex[overflow]'"
            )

        if self._running:
            return

        self._init_gpu()

        self._running = True
        self._original_profile = sys.getprofile()
        sys.setprofile(self._profile_hook)

        self._monitor_thread = threading.Thread(
            target=self._resource_loop,
            daemon=True,
            name="verlex-overflow",
        )
        self._monitor_thread.start()

        atexit.register(self.stop)
        if self._gpu_available:
            logger.info(
                "Overflow monitor started  threshold=%.0f%%  gpu_threshold=%.0f%%  fast=%s",
                self.threshold,
                self.gpu_threshold,
                self.fast,
            )
        else:
            logger.info(
                "Overflow monitor started  threshold=%.0f%%  fast=%s  (GPU monitoring: off)",
                self.threshold,
                self.fast,
            )

    def _init_gpu(self) -> None:
        """Try to initialise NVIDIA GPU monitoring via pynvml.

        If pynvml is not installed, no NVIDIA driver is present, or no
        GPU is found, GPU monitoring is silently disabled.
        """
        try:
            import pynvml

            pynvml.nvmlInit()
            device_count = pynvml.nvmlDeviceGetCount()
            if device_count == 0:
                logger.info("pynvml: no NVIDIA GPUs found — GPU monitoring disabled")
                return
            self._nvml_handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            self._gpu_available = True
            name = pynvml.nvmlDeviceGetName(self._nvml_handle)
            if isinstance(name, bytes):
                name = name.decode("utf-8")
            logger.info(
                "GPU monitoring active  device=%s  gpu_threshold=%.0f%%",
                name,
                self.gpu_threshold,
            )
        except ImportError:
            logger.info("pynvml not installed — GPU monitoring disabled")
        except Exception as exc:
            logger.info("GPU monitoring unavailable: %s", exc)

    def stop(self) -> None:
        """Stop monitoring, restore wrapped functions, and close the GateWay.

        The GateWay's ``__exit__`` automatically flushes any remaining
        offloaded data, so there is no need for a separate flush step.
        """
        if not self._running:
            return

        self._running = False

        # Restore the previous profile hook.
        try:
            sys.setprofile(self._original_profile)
        except Exception as exc:
            logger.error("Failed to restore profile hook: %s", exc)

        self._unwrap_all()

        if self._gateway is not None:
            try:
                self._gateway.__exit__(None, None, None)
            except Exception as exc:
                logger.error("Failed to close GateWay client: %s", exc)
            self._gateway = None

        if self._gpu_available:
            try:
                import pynvml

                pynvml.nvmlShutdown()
            except Exception:
                pass
            self._gpu_available = False
            self._nvml_handle = None

        logger.info("Overflow monitor stopped.")

    # ------------------------------------------------------------------
    # Predictive pre-warming  ("start the car")
    # ------------------------------------------------------------------

    def _start_pre_warm(self, source_file: str) -> None:
        """Predict the resource tier from *source_file* and fire a
        background pre-warm request so the VM is booting while the
        user's setup code runs."""
        if not self.api_key:
            return

        from verlex.data_ref import fire_pre_warm, predict_resource_tier

        tier = predict_resource_tier(source_file)
        logger.info("Predicted resource tier: %s  (from %s)", tier, source_file)

        t = threading.Thread(
            target=fire_pre_warm,
            args=(self.api_url, self.api_key, tier, self._warm_result),
            daemon=True,
            name="verlex-prewarm",
        )
        t.start()

    # ------------------------------------------------------------------
    # Background resource sampling
    # ------------------------------------------------------------------

    def _resource_loop(self) -> None:
        """Daemon thread: poll CPU, memory, and (optionally) GPU."""
        import psutil

        # psutil needs a baseline call for accurate CPU readings.
        psutil.cpu_percent(interval=None)

        while self._running:
            try:
                self._cpu_usage = psutil.cpu_percent(interval=self.check_interval)
                self._mem_usage = psutil.virtual_memory().percent

                # GPU sampling (skip if unavailable)
                if self._gpu_available and self._nvml_handle is not None:
                    try:
                        import pynvml

                        util = pynvml.nvmlDeviceGetUtilizationRates(self._nvml_handle)
                        mem_info = pynvml.nvmlDeviceGetMemoryInfo(self._nvml_handle)
                        self._gpu_util = float(util.gpu)
                        self._gpu_mem_util = (
                            (mem_info.used / mem_info.total) * 100.0
                            if mem_info.total > 0
                            else 0.0
                        )
                    except Exception as exc:
                        logger.debug("GPU sampling failed: %s", exc)

                was_overloaded = self._overloaded

                cpu_mem_overloaded = (
                    self._cpu_usage > self.threshold
                    or self._mem_usage > self.threshold
                )

                gpu_overloaded = False
                if self._gpu_available:
                    gpu_overloaded = (
                        self._gpu_util > self.gpu_threshold
                        or self._gpu_mem_util > self.gpu_threshold
                    )

                self._overloaded = cpu_mem_overloaded or gpu_overloaded

                if self._overloaded and not was_overloaded:
                    parts = [
                        f"CPU={self._cpu_usage:.1f}%",
                        f"Memory={self._mem_usage:.1f}%",
                    ]
                    if self._gpu_available:
                        parts.append(f"GPU={self._gpu_util:.1f}%")
                        parts.append(f"GPU-Mem={self._gpu_mem_util:.1f}%")
                    logger.warning(
                        "System overloaded  %s  (threshold=%.0f%%)",
                        "  ".join(parts),
                        self.threshold,
                    )
                elif not self._overloaded and was_overloaded:
                    parts = [
                        f"CPU={self._cpu_usage:.1f}%",
                        f"Memory={self._mem_usage:.1f}%",
                    ]
                    if self._gpu_available:
                        parts.append(f"GPU={self._gpu_util:.1f}%")
                        parts.append(f"GPU-Mem={self._gpu_mem_util:.1f}%")
                    logger.info(
                        "Resources normalised  %s",
                        "  ".join(parts),
                    )
                    # Allow a fresh scope-wrap on the next spike.
                    self._scope_wrapped = False

            except Exception as exc:
                logger.error("Resource sampling failed: %s", exc)
                time.sleep(self.check_interval)

    # ------------------------------------------------------------------
    # Profile hook  (must be *fast* on the happy path)
    # ------------------------------------------------------------------

    def _profile_hook(self, frame: Any, event: str, arg: Any) -> None:  # noqa: C901
        if not self._running:
            return

        filename = frame.f_code.co_filename

        # Fast-path: skip non-user code (stdlib, site-packages, verlex).
        if not self._is_user_code(filename):
            return

        if event == "call":
            self._call_stack.append(
                {
                    "name": frame.f_code.co_name,
                    "filename": filename,
                    "lineno": frame.f_code.co_firstlineno,
                    "start_cpu": self._cpu_usage,
                    "start_mem": self._mem_usage,
                    "start_gpu": self._gpu_util,
                    "start_gpu_mem": self._gpu_mem_util,
                }
            )

            # Already overloaded when a NEW user function starts ->
            # wrap it (effective on the *next* call) and, once, wrap
            # every user function in the caller's scope so that even
            # sequential one-shot functions are intercepted before
            # Python resolves the name.
            if self._overloaded:
                self._try_wrap_from_frame(frame)
                if not self._scope_wrapped and frame.f_back is not None:
                    self._wrap_scope(frame.f_back)
                    self._scope_wrapped = True

        elif event == "return":
            if not self._call_stack:
                return
            info = self._call_stack.pop()

            # Did THIS function cause the spike?
            started_ok = (
                info["start_cpu"] <= self.threshold
                and info["start_mem"] <= self.threshold
            )
            if self._gpu_available:
                started_ok = started_ok and (
                    info["start_gpu"] <= self.gpu_threshold
                    and info["start_gpu_mem"] <= self.gpu_threshold
                )
            if started_ok and self._overloaded:
                sig = (info["name"], info["filename"], info["lineno"])
                self._heavy_signatures.add(sig)
                self._try_wrap_from_frame(frame)

                if not self._scope_wrapped and frame.f_back is not None:
                    self._wrap_scope(frame.f_back)
                    self._scope_wrapped = True

                logger.warning(
                    "Heavy function detected: %s() at %s:%d — wrapped for cloud offload",
                    info["name"],
                    info["filename"],
                    info["lineno"],
                )

    # ------------------------------------------------------------------
    # Filename classification (cached)
    # ------------------------------------------------------------------

    def _is_user_code(self, filename: str) -> bool:
        cached = self._filename_cache.get(filename)
        if cached is not None:
            return cached
        result = self._check_user_code(filename)
        self._filename_cache[filename] = result
        return result

    def _check_user_code(self, filename: str) -> bool:
        if not filename or filename.startswith("<"):
            return False
        abs_path = os.path.abspath(filename)
        for prefix in self._exclude_prefixes:
            if abs_path.startswith(prefix):
                return False
        return True

    # ------------------------------------------------------------------
    # Function wrapping
    # ------------------------------------------------------------------

    def _try_wrap_from_frame(self, frame: Any) -> None:
        """Walk parent frames and wrap the function matching *frame*."""
        func_name = frame.f_code.co_name
        code_obj = frame.f_code
        search = frame.f_back
        while search is not None:
            obj = search.f_globals.get(func_name)
            if (
                obj is not None
                and callable(obj)
                and not getattr(obj, "_overflow_wrapped", False)
                and hasattr(obj, "__code__")
                and obj.__code__ is code_obj
            ):
                self._register_wrap(obj, func_name, search.f_globals)
                return
            search = search.f_back

    def _wrap_scope(self, frame: Any) -> None:
        """Aggressively wrap every user-defined function in *frame*'s globals.

        This ensures that even one-shot sequential functions called while
        the system is still overloaded will be offloaded on their first
        call, because the wrapper is already in the namespace before
        Python resolves the name.
        """
        if frame is None:
            return
        ns = frame.f_globals
        for name, obj in list(ns.items()):
            if (
                callable(obj)
                and hasattr(obj, "__code__")
                and not getattr(obj, "_overflow_wrapped", False)
                and not name.startswith("_")
                and self._is_user_code(obj.__code__.co_filename)
            ):
                self._register_wrap(obj, name, ns)

    def _register_wrap(
        self,
        func_obj: Callable[..., Any],
        func_name: str,
        namespace: dict[str, Any],
    ) -> None:
        with self._lock:
            fid = id(func_obj)
            if fid in self._wrapped_functions:
                return

            wrapper = self._make_wrapper(func_obj)
            namespace[func_name] = wrapper

            self._wrapped_functions[fid] = _WrapRecord(
                original=func_obj,
                name=func_name,
                namespace=namespace,
                wrapper=wrapper,
            )

    def _make_wrapper(self, original: Callable[..., Any]) -> Callable[..., Any]:
        monitor = self

        @functools.wraps(original)
        def _overflow_wrapper(*args: Any, **kwargs: Any) -> Any:
            if monitor._overloaded:
                if monitor._gpu_available:
                    logger.info(
                        "Offloading %s() to cloud  (CPU=%.1f%%  Mem=%.1f%%  GPU=%.1f%%  GPU-Mem=%.1f%%)",
                        original.__name__,
                        monitor._cpu_usage,
                        monitor._mem_usage,
                        monitor._gpu_util,
                        monitor._gpu_mem_util,
                    )
                else:
                    logger.info(
                        "Offloading %s() to cloud  (CPU=%.1f%%  Mem=%.1f%%)",
                        original.__name__,
                        monitor._cpu_usage,
                        monitor._mem_usage,
                    )
                try:
                    result = monitor._cloud_execute(original, args, kwargs)
                    logger.info(
                        "%s() completed in cloud — returning result to local",
                        original.__name__,
                    )
                    return result
                except Exception as exc:
                    logger.warning(
                        "Cloud offload of %s() failed (%s) — falling back to local",
                        original.__name__,
                        exc,
                    )
                    return original(*args, **kwargs)
            return original(*args, **kwargs)

        _overflow_wrapper._overflow_wrapped = True  # type: ignore[attr-defined]
        _overflow_wrapper._original = original  # type: ignore[attr-defined]
        return _overflow_wrapper

    # ------------------------------------------------------------------
    # Cloud execution  (reuses the existing GateWay pipeline)
    # ------------------------------------------------------------------

    def _get_gateway(self) -> Any:
        if self._gateway is None:
            with self._gateway_lock:
                if self._gateway is None:
                    from verlex.client import GateWay

                    try:
                        self._gateway = GateWay(
                            api_key=self.api_key,
                            fast=self.fast,
                            api_url=self.api_url,
                            verbose=False,
                        )
                        self._gateway.__enter__()
                    except Exception:
                        raise
        return self._gateway

    def _cloud_execute(
        self,
        func: Callable[..., Any],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Any:
        """Run *func* through the full Verlex cloud pipeline.

        Data offloading and flush are handled by ``GateWay.run()`` itself.
        """
        gw = self._get_gateway()

        # Forward the pre-warm session id (if it arrived in time).
        warm_id = self._warm_result.get("warm_session_id")
        if warm_id:
            gw._warm_session_id = warm_id

        return gw.run(func, *args, **kwargs)

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def _unwrap_all(self) -> None:
        with self._lock:
            for record in self._wrapped_functions.values():
                try:
                    record.namespace[record.name] = record.original
                except Exception as exc:
                    logger.error("Failed to unwrap %s: %s", record.name, exc)
            self._wrapped_functions.clear()
            self._heavy_signatures.clear()
            self._scope_wrapped = False


# ---------------------------------------------------------------------------
# Module-level singleton & public API
# ---------------------------------------------------------------------------

_active_monitor: Optional[_OverflowMonitor] = None


def overflow(
    fast: bool = False,
    threshold: float = 85.0,
    check_interval: float = 0.5,
    api_key: Optional[str] = None,
    api_url: Optional[str] = None,
    gpu_threshold: Optional[float] = None,
    # Legacy params (ignored, kept for backward compat)
    priority: bool | None = None,
    flexible: bool | None = None,
) -> _OverflowMonitor:
    """Monitor system resources and offload heavy functions to the cloud.

    Call this at the beginning of your script or inside your ``main()``
    function.  All user-defined functions in the caller's scope are
    **immediately wrapped** with a lightweight guard that checks system
    load before every call.  A background thread continuously samples
    CPU, memory, and (when available) GPU usage.

    How it works:

    1. **Predictive pre-warming** — the caller's source file is parsed
       with ``ast`` to detect heavy imports (torch, tensorflow, …).
       A background HTTP request fires off to ``/v1/pre-warm`` so a
       cloud VM starts booting *immediately* — before any function
       has even been called.
    2. **Eager pre-wrapping** — every function visible at the call site
       is wrapped immediately, so even the *first* call to any function
       is intercepted if the system is already overloaded.
    3. **Dynamic wrapping** — functions defined or imported *after* this
       call are detected via ``sys.setprofile`` and wrapped on the fly
       when a spike is detected.
    4. **Smart data offloading** — arguments larger than 50 MB are
       uploaded to an ephemeral data store before cloudpickle
       serialisation.  A lightweight resolver wrapper downloads them
       on the cloud side, and they are flushed after execution.
    5. **Automatic fallback** — once local resources drop below the
       threshold, the wrappers fall through to local execution.

    Args:
        fast: True = Performance mode (immediate), False = Standard (can wait).
        threshold: CPU / memory % that triggers cloud offload (default 85).
        check_interval: Seconds between resource samples (default 0.5).
        api_key: Verlex API key.  Falls back to ``VERLEX_API_KEY`` env var.
        api_url: Override the Verlex API URL.
        gpu_threshold: GPU utilization / memory % that triggers cloud offload.
            If ``None`` (default), uses the same value as *threshold*.
            GPU monitoring requires ``pynvml`` and an NVIDIA GPU; if
            neither is available, this parameter is silently ignored.

    Returns:
        The :class:`_OverflowMonitor` instance.  Call ``.stop()`` to
        disable monitoring early; otherwise it stops automatically at
        process exit.

    Example::

        import verlex
        verlex.overflow(fast=True)

        data = load_data()           # ← VM is already booting
        result = train_model(data)   # if system overloaded → cloud
        result = train_model(data2)  # still overloaded → cloud again
        evaluate(result)             # resources free → runs locally
    """
    global _active_monitor

    if _active_monitor is not None:
        _active_monitor.stop()

    _active_monitor = _OverflowMonitor(
        fast=fast,
        threshold=threshold,
        check_interval=check_interval,
        api_key=api_key,
        api_url=api_url,
        gpu_threshold=gpu_threshold,
    )
    _active_monitor.start()

    # Eagerly pre-wrap all user functions in the caller's module scope.
    caller_frame = sys._getframe(1)
    if caller_frame is not None:
        _active_monitor._wrap_scope(caller_frame)

        # --- Predictive pre-warming ("start the car") ---
        # Parse the caller's source to predict what tier we'll need
        # and fire a background request to boot a VM now.
        source_file = caller_frame.f_code.co_filename
        if source_file and not source_file.startswith("<"):
            _active_monitor._start_pre_warm(source_file)

    return _active_monitor
