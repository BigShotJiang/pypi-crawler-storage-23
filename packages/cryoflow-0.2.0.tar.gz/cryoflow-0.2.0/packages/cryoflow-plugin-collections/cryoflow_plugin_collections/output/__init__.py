"""Output plugins for cryoflow."""

from cryoflow_plugin_collections.output.parquet_writer import ParquetWriterPlugin

__all__ = ['ParquetWriterPlugin']
