# CLITool "cryoflow" Specification

## 1. Overview

A plugin-driven columnar data processing CLI tool built on Polars LazyFrame.
Processes Apache Arrow (IPC/Parquet) format data through a chain of user-defined plugins for data transformation, validation, and output.

## 2. Architecture

### 2.1 Technology Stack

| Category | Library/Technology | Purpose |
| --- | --- | --- |
| **Core** | **Polars** | Data processing engine (LazyFrame-based) |
| **CLI** | **Typer** | CLI interface and command definitions |
| **Plugin** | **pluggy** + **importlib** | Plugin mechanism, hook management, dynamic loading |
| **Config** | **Pydantic** + **TOML** | Configuration definition and validation |
| **Path** | **xdg-base-dirs** | XDG-compliant configuration path resolution |
| **Error** | **returns** | Railway-oriented programming style error handling via Result Monad |
| **Base** | **ABC** (Standard Lib) | Plugin interface definitions |

### 2.2 Data Flow

1. **Config Load**: Load `XDG_CONFIG_HOME/cryoflow/config.toml` and validate with Pydantic.
2. **Plugin Discovery**: Load specified modules via `importlib` and register with `pluggy` based on configuration.
3. **Pipeline Construction**:
   - Execute `InputPlugin` hooks and build a `LabeledDataMap` (label → data dictionary) keyed by each plugin's label.
   - Execute `TransformPlugin` hooks sequentially against the data matching each plugin's label, building the computation graph (LazyFrame).

4. **Execution / Output**:
   - Execute `OutputPlugin` hooks against the data matching each plugin's label. This is where `collect()` or `sink_*()` is first called and processing actually runs.

---

## 3. Interface Design

### 3.1 Data Models (Pydantic)

```python
from typing import Any

from pydantic import BaseModel, Field

class PluginConfig(BaseModel):
    name: str
    module: str  # Path to load with importlib
    enabled: bool = True
    label: str = 'default'  # Label for multi-stream routing
    options: dict[str, Any] = Field(default_factory=dict)  # Plugin-specific configuration

class CryoflowConfig(BaseModel):
    input_plugins: list[PluginConfig]
    transform_plugins: list[PluginConfig]
    output_plugins: list[PluginConfig]
```

> **Implementation Notes**:
> - `GlobalConfig` renamed to `CryoflowConfig` (clearer naming)
> - Uses Python 3.14 built-in types (`list`, `dict`) instead of deprecated `typing.List`, `typing.Dict`
> - `input_path` removed in v0.2.0; data sources are now declared as `InputPlugin` entries
> - `label` added to `PluginConfig` in v0.2.0 for multi-stream label-based routing

### 3.2 Plugin Base Classes (ABC)

While `pluggy` can handle function-based hooks, we use class-based plugins to enforce the contract via ABC and to mandate the `dry_run` method.

```python
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

import polars as pl
from returns.result import Result

# Type alias for data
FrameData = pl.LazyFrame | pl.DataFrame

DEFAULT_LABEL = 'default'

class BasePlugin(ABC):
    """Base class for all plugins"""

    def __init__(self, options: dict[str, Any], config_dir: Path, label: str = DEFAULT_LABEL) -> None:
        self.options = options
        self._config_dir = config_dir
        self.label = label  # Label for multi-stream routing

    @abstractmethod
    def name(self) -> str:
        """Plugin identification name"""
        pass


class InputPlugin(BasePlugin):
    """Input plugin"""

    @abstractmethod
    def execute(self) -> Result[FrameData, Exception]:
        """Load and return data as FrameData"""

    @abstractmethod
    def dry_run(self) -> Result[dict[str, pl.DataType], Exception]:
        """Return schema without loading data"""


class TransformPlugin(BasePlugin):
    """Data transformation plugin"""

    @abstractmethod
    def execute(self, df: FrameData) -> Result[FrameData, Exception]:
        pass

    @abstractmethod
    def dry_run(self, schema: dict[str, pl.DataType]) -> Result[dict[str, pl.DataType], Exception]:
        """Accept schema only and return predicted output schema (or error)"""


class OutputPlugin(BasePlugin):
    """Output plugin"""

    @abstractmethod
    def execute(self, df: FrameData) -> Result[None, Exception]:
        pass

    @abstractmethod
    def dry_run(self, schema: dict[str, pl.DataType]) -> Result[dict[str, pl.DataType], Exception]:
        """Validate schema for output"""
```

### 3.3 Hook Specification (pluggy hookspec)

```python
import pluggy

hookspec = pluggy.HookspecMarker("cryoflow")

class CryoflowSpecs:
    @hookspec
    def register_input_plugins(self) -> list[InputPlugin]:
        """Return instances of input plugins"""

    @hookspec
    def register_transform_plugins(self) -> list[TransformPlugin]:
        """Return instances of transformation plugins"""

    @hookspec
    def register_output_plugins(self) -> list[OutputPlugin]:
        """Return instances of output plugins"""
```

### 3.4 Path Resolution Behavior

All file paths in cryoflow configuration are resolved **relative to the directory containing the configuration file**, not the current working directory. This ensures portability of configuration files and allows moving entire project directories without breaking path references.

#### Resolution Rules

1. **Absolute paths**: Preserved as-is (after normalization with `.resolve()`)
2. **Relative paths**: Resolved relative to the directory containing `config.toml`

#### Configuration Paths

**Plugin option paths** (in `input_plugins.options`, `output_plugins.options`, etc.):
- Must be resolved by plugin implementations using `BasePlugin.resolve_path()`
- Example (InputPlugin):
  ```toml
  [[input_plugins]]
  name = "parquet-scan"
  module = "cryoflow_plugin_collections.input.parquet_scan"
  [input_plugins.options]
  input_path = "data/input.parquet"
  # Plugin must call: self.resolve_path(self.options['input_path'])
  # Resolves to: /project/config/data/input.parquet
  ```
- Example (OutputPlugin):
  ```toml
  [[output_plugins]]
  name = "parquet-writer"
  module = "cryoflow_plugin_collections.output.parquet_writer"
  [output_plugins.options]
  output_path = "data/output.parquet"
  # Plugin must call: self.resolve_path(self.options['output_path'])
  # Resolves to: /project/config/data/output.parquet
  ```

#### Plugin Implementation

Plugins receive a `config_dir` parameter in their constructor, which is automatically set to the directory containing the configuration file:

```python
class BasePlugin(ABC):
    def __init__(self, options: dict[str, Any], config_dir: Path, label: str = DEFAULT_LABEL) -> None:
        self.options = options
        self._config_dir = config_dir
        self.label = label

    def resolve_path(self, path: str | Path) -> Path:
        """Resolve a path relative to the config directory."""
        path = Path(path)
        if not path.is_absolute():
            path = self._config_dir / path
        return path.resolve()
```

Usage in plugin:
```python
class ParquetWriterPlugin(OutputPlugin):
    def execute(self, df: FrameData) -> Result[None, Exception]:
        output_path_opt = self.options.get('output_path')
        # Resolve relative path against config directory
        output_path = self.resolve_path(output_path_opt)
        # ... write to output_path
```

#### Benefits

- **Portability**: Configuration files and data can be moved together as a unit
- **Consistency**: All paths follow the same resolution rules
- **Predictability**: Path resolution is independent of the current working directory

---

## 4. Error Handling Guidelines (returns)

- Use exceptions (`try-except`) only at the lowest level library boundaries (e.g., Polars calls).
- Wrap data passed between plugins in `Result[FrameData, Exception]`.
- In pipeline control, use `flow` or `bind` to immediately halt processing when any `Failure` is returned and pass it to CLI error output.

```python
# Conceptual example
result = (
    load_data(path)
    .bind(plugin_a.execute)
    .bind(plugin_b.execute)
    .bind(output_plugin.execute)
)

if isinstance(result, Failure):
    console.print(f"[red]Error:[/red] {result.failure()}")
    raise typer.Exit(code=1)

```

---

## 5. Plugin Implementation Best Practices

### 5.1 Error Handling

The following patterns are recommended for `execute()` and `dry_run()` methods in plugins.

**Pattern 1: Explicitly return Failure with try-except (Recommended)**

```python
from returns.result import Failure, Success

def execute(self, df: FrameData) -> Result[FrameData, Exception]:
    try:
        column_name = self.options['column_name']
        if column_name not in df.columns:
            return Failure(ValueError(f"Column '{column_name}' not found"))
        # ... process ...
        return Success(transformed_df)
    except Exception as e:
        return Failure(e)
```

**Pattern 2: Auto-conversion with @safe decorator**

```python
from returns.result import safe

@safe
def execute(self, df: FrameData) -> FrameData:
    column_name = self.options['column_name']
    if column_name not in df.columns:
        raise ValueError(f"Column '{column_name}' not found")
    # ... process ...
    return transformed_df
```

In both cases, it is important to include specific information in error messages (column names, expected values, actual values).

### 5.2 dry_run Method Implementation

The `dry_run` method inspects the schema only without processing actual data and returns the predicted output schema.

The signature differs by plugin type:

- **`InputPlugin.dry_run()`**: No arguments. Returns schema without loading data.
- **`TransformPlugin.dry_run(schema)`**: Accepts input schema and returns predicted output schema.
- **`OutputPlugin.dry_run(schema)`**: Accepts input schema, validates output, and returns schema.

Example for `TransformPlugin` / `OutputPlugin`:

```python
def dry_run(self, schema: dict[str, pl.DataType]) -> Result[dict[str, pl.DataType], Exception]:
    """Validate schema and return predicted output schema"""
    column_name = self.options['column_name']

    # Check column existence
    if column_name not in schema:
        return Failure(ValueError(f"Column '{column_name}' not found in schema"))

    # Check type
    dtype = schema[column_name]
    if not dtype.is_numeric():
        return Failure(ValueError(
            f"Column '{column_name}' has type {dtype}, expected numeric type"
        ))

    # Schema remains unchanged, return as is
    return Success(schema)
```

### 5.3 Resource Management

- Polars `scan_*`/`sink_*` methods automatically close file handles
- When implementing custom OutputPlugin, manage file handles using `with` statements

```python
class CustomOutputPlugin(OutputPlugin):
    def execute(self, df: FrameData) -> Result[None, Exception]:
        try:
            output_path = self.options['output_path']
            with open(output_path, 'w') as f:
                # File processing
                pass
            return Success(None)
        except Exception as e:
            return Failure(e)
```

---

## 6. CLI Commands

### 6.0 Global Options

Options common to all commands:

```bash
cryoflow [-v | --version] [-h | --help]
```

- `-v, --version`: Show version and exit
- `-h, --help`: Show help message and exit

### 6.1 run command

Executes the data processing pipeline.

```bash
cryoflow run [-c CONFIG] [-V] [-h]
```

**Options**:
- `-c, --config CONFIG`: Configuration file path (if not specified, uses XDG-compliant default path)
- `-V, --verbose`: Output detailed logs (DEBUG level logs are displayed)
- `-h, --help`: Show help message and exit

**Output Example**:

```
Config loaded: /home/user/.config/cryoflow/config.toml
  input_plugins:     1 plugin(s)
  transform_plugins: 1 plugin(s)
  output_plugins:    1 plugin(s)
    - input_plugin (my.input) [enabled]
    - transform_plugin (my.transform) [enabled]
    - output_plugin (my.output) [enabled]
Loaded 3 plugin(s) successfully.

Executing pipeline...
INFO: Executing 1 transformation plugin(s)...
INFO:   [1/1] transform_plugin
[SUCCESS] Pipeline completed successfully
```

### 6.2 check command

Validates pipeline configuration and schema without processing actual data.

```bash
cryoflow check [-c CONFIG] [-V] [-h]
```

**Options**:
- `-c, --config CONFIG`: Configuration file path
- `-V, --verbose`: Output detailed logs
- `-h, --help`: Show help message and exit

**Output Example**:

```
[CHECK] Config loaded: /home/user/.config/cryoflow/config.toml
[CHECK] Loaded 2 plugin(s) successfully.

[CHECK] Running dry-run validation...

[SUCCESS] Validation completed successfully

Output schema:
  order_id: Int64
  customer_id: Int64
  total_amount: Float64
  order_date: Date
```

**Use cases**:

- Configuration file syntax validation
- Verify plugin loading capability
- Schema validation (confirm transformed column types)
- Pre-flight validation before actual execution

**Limitations**:

- Currently supports a single output plugin only. If multiple output plugins are specified in the configuration, an error will be raised.

---

## 7. Implementation Details

### 7.1 Plugin Loader Behavior

The plugin loader (`cryoflow_core/loader.py`) distinguishes between filesystem paths and dotted module paths using the following conditions:

- **Filesystem Path** (e.g., `./plugins/my_plugin.py`): Contains `'/'` or `'\\'`, ends with `.py`, or starts with `'.'`. Loaded directly via `importlib.util.spec_from_file_location()`.
- **Dotted Module Path** (e.g., `cryoflow_plugin_collections.transform.multiplier`): Loaded via `importlib.import_module()` from installed packages.

This allows plugins to be loaded either from local development files or from installed Python packages, providing flexibility in plugin distribution and development workflows.

### 7.2 Schema Extraction

The method for extracting schema from `FrameData` differs by type:

- **LazyFrame**: Schema is extracted via `collect_schema()` without materializing data.
- **DataFrame**: Schema is extracted via the `schema` property.

In both cases, the schema extraction is non-blocking and does not trigger data loading. This enables efficient dry-run validation without I/O overhead.

```python
@safe
def extract_schema(df: FrameData) -> dict[str, pl.DataType]:
    if isinstance(df, pl.LazyFrame):
        return df.collect_schema()
    else:  # DataFrame
        return df.schema
```

### 7.3 Result Type and Error Propagation

All plugin methods (`execute`, `dry_run`) return `Result[T, Exception]` types from the `returns` library:

```python
# Transform plugin returns the transformed data
Result[FrameData, Exception]

# Output plugin returns None (None indicates successful output)
Result[None, Exception]
```

Errors are propagated through the pipeline using the `bind()` method, which automatically halts processing on the first `Failure` encountered. This implements railway-oriented programming, ensuring predictable error handling across the entire pipeline.

### 7.4 Label-Driven Multi-Stream Processing

Each plugin has a `label` attribute, and plugins with the same label exchange data. This allows multiple independent data streams to be processed in parallel within a single pipeline configuration.

#### Type Aliases

```python
LabeledDataMap = dict[str, Result[FrameData, Exception]]
LabeledSchemaMap = dict[str, Result[dict[str, pl.DataType], Exception]]
```

#### Pipeline Execution Flow

```
Step 1: InputPlugin × N → LabeledDataMap { label: Result[FrameData] }
Step 2: TransformPlugin × N → Apply transforms to data matching each plugin's label
Step 3: OutputPlugin × N → Execute output on data matching each plugin's label
```

If no data exists for a plugin's label, it propagates as `Failure(KeyError(...))`.

#### Configuration Example

```toml
[[input_plugins]]
name = "orders-input"
module = "cryoflow_plugin_collections.input.parquet_scan"
label = "orders"
[input_plugins.options]
input_path = "data/orders.parquet"

[[transform_plugins]]
name = "orders-transform"
module = "my_plugins.transform.orders"
label = "orders"  # Processes only data with "orders" label

[[output_plugins]]
name = "orders-output"
module = "cryoflow_plugin_collections.output.parquet_writer"
label = "orders"  # Outputs only data with "orders" label
[output_plugins.options]
output_path = "data/orders_out.parquet"
```
