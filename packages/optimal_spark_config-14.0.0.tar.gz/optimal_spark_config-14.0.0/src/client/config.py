
from src.utils.utils import launch

def init_config():
    launch()