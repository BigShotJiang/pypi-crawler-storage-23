"""Memory models are persisted in littlehive.db.models for Phase 1."""
