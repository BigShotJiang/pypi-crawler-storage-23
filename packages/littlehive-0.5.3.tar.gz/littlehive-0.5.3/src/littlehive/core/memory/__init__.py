"""Memory stubs."""
