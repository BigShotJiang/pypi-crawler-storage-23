"""Context system stubs."""
