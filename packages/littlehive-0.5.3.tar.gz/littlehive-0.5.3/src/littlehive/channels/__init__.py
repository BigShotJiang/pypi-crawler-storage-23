"""Channel adapters."""
