"""Telegram channel stubs."""
