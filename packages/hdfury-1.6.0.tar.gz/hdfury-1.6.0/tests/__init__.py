"""Tests for the HDFury library."""
