"""
Leeroopedia MCP Server

MCP server for searching Leeroopedia's curated ML/AI knowledge base.
Supports both stdio and SSE transports.
"""

__version__ = "0.1.0"
