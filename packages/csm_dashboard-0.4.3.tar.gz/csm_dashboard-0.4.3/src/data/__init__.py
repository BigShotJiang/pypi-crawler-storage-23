"""Data layer - on-chain and off-chain data fetching."""
