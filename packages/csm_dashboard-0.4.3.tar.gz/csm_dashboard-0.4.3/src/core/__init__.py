"""Core module - configuration, types, and contracts."""
