from .base import KittyCadBaseModel


class DefaultCameraSetOrthographic(KittyCadBaseModel):
    """The response from the `DefaultCameraSetOrthographic` endpoint."""
