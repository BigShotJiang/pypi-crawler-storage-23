from .base import KittyCadBaseModel


class ImportFiles(KittyCadBaseModel):
    """Data from importing the files"""

    object_id: str
