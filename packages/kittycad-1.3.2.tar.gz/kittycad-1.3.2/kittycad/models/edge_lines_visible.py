from .base import KittyCadBaseModel


class EdgeLinesVisible(KittyCadBaseModel):
    """The response from the `EdgeLinesVisible` endpoint."""
