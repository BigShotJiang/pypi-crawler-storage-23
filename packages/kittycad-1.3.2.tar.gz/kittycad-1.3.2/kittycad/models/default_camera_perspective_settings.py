from .base import KittyCadBaseModel


class DefaultCameraPerspectiveSettings(KittyCadBaseModel):
    """The response from the `DefaultCameraPerspectiveSettings` endpoint."""
