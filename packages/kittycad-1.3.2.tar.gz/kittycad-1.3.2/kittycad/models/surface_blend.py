from .base import KittyCadBaseModel


class SurfaceBlend(KittyCadBaseModel):
    """The response from the `SurfaceBlend` endpoint."""
