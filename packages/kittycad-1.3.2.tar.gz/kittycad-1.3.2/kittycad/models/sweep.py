from .base import KittyCadBaseModel


class Sweep(KittyCadBaseModel):
    """The response from the `Sweep` endpoint."""
