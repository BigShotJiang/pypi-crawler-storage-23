from .base import KittyCadBaseModel


class SceneClearAll(KittyCadBaseModel):
    """The response from the `SceneClearAll` endpoint."""
