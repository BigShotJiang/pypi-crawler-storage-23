from .base import KittyCadBaseModel


class EntityDeleteChildren(KittyCadBaseModel):
    """The response from the `EntityDeleteChildren` command."""
