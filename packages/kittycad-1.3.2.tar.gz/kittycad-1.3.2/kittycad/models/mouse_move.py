from .base import KittyCadBaseModel


class MouseMove(KittyCadBaseModel):
    """The response from the `MouseMove` endpoint."""
