"""Seed markdown assets for ph init.\n"""
