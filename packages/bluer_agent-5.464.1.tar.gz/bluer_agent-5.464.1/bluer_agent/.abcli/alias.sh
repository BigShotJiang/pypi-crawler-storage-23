#! /usr/bin/env bash

alias @assistant=bluer_agent_assistant

alias @audio=bluer_agent_audio

alias @chat=bluer_agent_chat

alias @crawl=bluer_agent_crawl

alias @rag=bluer_agent_rag

alias @transcribe=bluer_agent_transcribe

alias @voice=bluer_agent_voice

# ignore
alias @agent=bluer_agent
alias @ai_agent=bluer_agent
