from typing import List, Dict


class List_of_Messages:
    def __init__(self):
        self.messages: List[Dict] = []
