docs = [
    {
        "path": "../docs/chat",
    },
    {
        "path": "../docs/chat/validation.md",
    },
]
