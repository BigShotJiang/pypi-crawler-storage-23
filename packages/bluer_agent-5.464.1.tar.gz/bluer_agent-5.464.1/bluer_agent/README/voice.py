docs = [
    {
        "path": "../docs/voice",
    },
    {
        "path": "../docs/voice/validation.md",
    },
]
