docs = [
    {
        "path": "../docs/transcription",
    },
    {
        "path": "../docs/transcription/validation.md",
    },
]
