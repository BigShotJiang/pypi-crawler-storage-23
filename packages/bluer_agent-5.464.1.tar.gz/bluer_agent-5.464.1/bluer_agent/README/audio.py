docs = [
    {
        "path": f"../docs/audio{suffix}",
    }
    for suffix in [
        "",
        "/basics.md",
        "/conversation.md",
    ]
]
