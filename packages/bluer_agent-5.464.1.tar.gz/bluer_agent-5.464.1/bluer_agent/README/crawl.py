docs = [
    {
        "path": f"../docs/crawl{suffix}",
    }
    for suffix in [
        "",
        "/one.md",
        "/two",
        "/two/one.md",
        "/two/badkoobeh.md",
        "/two/hnpagency.md",
        "/three.md",
    ]
]
