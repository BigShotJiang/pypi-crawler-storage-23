"""Cryopod CLI entry point."""

import click

from cryopod import __version__


@click.group()
@click.version_option(version=__version__, prog_name="cryopod")
def cli():
    """Cryopod - Agent config backup and sync.

    CLI for the cryopod.ai agent configuration backup and sync service.
    """


@cli.command()
def status():
    """Show current sync status."""
    click.echo("Cryopod CLI is installed. Visit https://cryopod.ai to get started.")


def main():
    cli()


if __name__ == "__main__":
    main()
