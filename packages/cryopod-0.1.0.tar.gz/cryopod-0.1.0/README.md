# cryopod

CLI for the [cryopod.ai](https://cryopod.ai) agent config backup and sync service.

## Installation

```bash
pip install cryopod
```

## Usage

```bash
cryopod --help
cryopod status
```
