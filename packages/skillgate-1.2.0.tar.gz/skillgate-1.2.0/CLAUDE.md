# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

SkillGate is the **Agent Capability Firewall** — a runtime-embedded, ecosystem-integrated control plane that governs what AI agents do (tool invocations), not only what they say. It provides deterministic policy enforcement, signed attestation evidence (Ed25519), native CI/CD integration (GitHub Actions, GitLab CI), and deep integration with Claude Code/MCP, Codex CLI, VS Code, and major agent frameworks.

**Phase 1 — COMPLETE, IN PRODUCTION (2026-02-25)**
Core engine, policy, CI/CD, attestations, universal language governance (7 languages), multi-artifact scanning (PDF/DOCX/ZIP), cross-artifact correlation, per-origin policy, Unicode hardening, performance SLO guards, entitlement enforcement, Supabase auth migration, open-core repo split. 1245 unit tests. All production gates green.

**Phase 2 — ACTIVE DEVELOPMENT**
Runtime enforcement engine, Session License Token auth, MCP gateway (Claude Code), Codex CLI bridge, VS Code extension, Claude Code ecosystem depth (hooks, CLAUDE.md governance, sub-agents, plugin registry), agent framework SDKs (PydanticAI/LangChain/CrewAI), observability + SIEM, intelligence + SaaS control plane.
Full plan: [docs/phase2/IMPLEMENTATION-PLAN.md](docs/phase2/IMPLEMENTATION-PLAN.md)

## Mandatory Agent Skills

**Always invoke these skills before starting any non-trivial task in this repo:**

| Skill | When to invoke |
|---|---|
| `token-efficient-coding` | Every coding task — enforces diff-only output, minimal tokens, no restating prompts |
| `python-pro` | Any Python file — enforces Python 3.12+ patterns, async, type annotations, modern stdlib |
| `python-code-style` | New modules or style reviews — ruff config, docstrings, naming conventions |
| `pytest-runner` | After any code change — activates venv correctly before running pytest |
| `production-hardening-gate` | Pre-merge and pre-release — GO/NO-GO readiness checks, security hardening pass |
| `commit-message-standard` | Use this skill to commit the changes with a standard message format |

**Invoke with:** `/token-efficient-coding`, `/python-pro`, `/python-code-style`, `/pytest-runner`, `/production-hardening-gate`

Skills are located at:
- `.codex/skills/production-hardening-gate/SKILL.md` — pre-GA hardening, strict GO/NO-GO

## Build & Development Commands

```bash
# Create virtual environment
python -m venv venv

# Install dependencies in virtual environment
pip install -e ".[dev]"

# Run all tests (pytest-runner skill handles venv activation)
pytest

# Run tests in parallel
pytest -n auto

# Run a single test file
pytest tests/unit/test_rules/test_shell.py

# Run a single test by name
pytest -k "test_subprocess_detection"

# Lint
ruff check .

# Type check (strict mode required)
mypy --strict skillgate/

# Format
ruff format .

# Full CI check (must pass before any merge)
ruff check . && mypy --strict skillgate/ && pytest --cov=skillgate --cov-fail-under=90
```

## Architecture

### Phase 1 (Production) — Static Analysis + Policy Engine

**Pipeline:** Parse → Analyze → Score → Enforce → Report

```
skillgate/
├── cli/              # Typer+Rich CLI layer — commands, formatters (human/json/sarif)
├── core/             # Pure library, zero I/O dependencies
│   ├── parser/       # Bundle discovery, manifest parsing (SKILL.md/skill.json/package.json/pyproject.toml)
│   ├── analyzer/     # Static analysis engine — AST (Python stdlib ast, tree-sitter for JS/TS/Shell) + regex
│   │   └── rules/    # Pluggable detection rules (SG-SHELL-*, SG-NET-*, SG-FS-*, SG-EVAL-*, SG-CRED-*, SG-INJ-*, SG-OBF-*)
│   ├── scorer/       # Weighted risk scoring — score = Σ(weight × severity_multiplier)
│   ├── policy/       # YAML policy enforcement — presets: development/staging/production/strict
│   ├── signer/       # Ed25519 signing via PyNaCl — key management in ~/.skillgate/keys/
│   └── models/       # Pydantic data models (Finding, RiskScore, PolicyResult, ScanReport, etc.)
├── ci/               # CI adapters (GitHub Action action.yml, GitLab template, PR annotations)
├── config/           # Settings, defaults, license validation
└── tests/            # Pyramid: ~65% unit, ~25% integration, ~10% e2e
    └── fixtures/     # safe/, malicious/, policies/ — representative skill samples
```

**Key constraint:** `core/` has zero dependencies on `cli/` or `ci/`. It is a pure library.

### Phase 2 (Active Development) — Runtime Enforcement + Ecosystem

**New modules being built (do not refactor Phase 1 modules without explicit instruction):**

```
skillgate/
├── runtime/          # ToolInvocation model, EnforcementPipeline (7 stages), token buckets, circuit breakers
│   └── sidecar/      # HTTP API: POST /v1/decide, GET /v1/health, GET /v1/entitlements
├── auth/             # Session License Token (SLT) — exchange, cache, offline grace modes A/B/C
├── mcp_gateway/      # Claude Code MCP proxy — tool intercept, AI-BOM, tool poisoning detection
├── ecosystem/        # Claude Code hooks, CLAUDE.md injection, slash commands, memory, sub-agents
├── codex_bridge/     # Codex CLI wrapper — tool proxy, AGENTS.md governance, CI guard mode
├── sdk/              # skillgate-sdk: @enforce decorator, PydanticAI/LangChain/CrewAI integrations
├── observability/    # Prometheus/OTEL metrics, NDJSON audit log (hash-chained), SIEM webhooks
├── intelligence/     # Per-agent risk scoring, anomaly detection, community policy packs
└── control_plane/    # Multi-tenant SaaS: workspaces, RBAC, approvals, policy versioning
```

**Phase 2 boundary rule:** `runtime/` and `sdk/` are public CE (open-core). `auth/` SLT issuance, `control_plane/`, and SIEM connectors are private EE.

## Tech Stack

- **Python 3.12+** (Phase 2 requires 3.12+; Phase 1 supports 3.10+), Typer+Rich (CLI), Pydantic v2 (models/validation), PyNaCl (Ed25519), httpx (async HTTP), PyYAML
- **AST parsing:** stdlib `ast` for Python, `tree-sitter` for JS/TS/Shell
- **Phase 2 additions:** FastAPI (sidecar HTTP), Redis-optional (token buckets at scale), OpenTelemetry SDK, python-jose (JWT/SLT verification)
- **Testing:** pytest + pytest-cov + pytest-xdist | **Linting:** ruff | **Type checking:** mypy (strict) | **Packaging:** hatch/setuptools

## Critical Rules

### Performance & Latency (Priority)
- Phase 1: Cold start <2s, scan 10 files <3s, scan 100 files <10s, memory <256MB
- **Phase 2 (runtime):** Sidecar P95 ≤20ms at 10k/min, P99 ≤50ms; MCP gateway overhead ≤25ms P95; Codex bridge overhead ≤30ms P95
- AST parsing is lazy — only parse files matching initial regex pre-filter
- Rules evaluated in parallel per file; skip files >100KB with warning
- No network calls during local scan (zero network latency); enforcement pipeline must work fully offline

### Security & Rate Limiting
- SkillGate never executes skill or agent code — analysis is purely static or intercept-based
- No skill code leaves the local environment unless user explicitly opts in
- Private signing keys never leave local machine; API keys never in reports
- **Phase 2 SLT contract:** `SKILLGATE_API_KEY` exchanges for a Session License Token (SLT); SLT cached in OS keychain; all components (sidecar, gateway, extension) read SLT locally — no hard API call per command
- SLT verification: RS256 only; `alg: none` attack always rejected; expired SLT triggers graceful limited mode
- Hosted API rate limits: Free 10/min, Pro 60/min, Team 300/min, Enterprise 1000/min
- All hosted communication HTTPS with TLS 1.3; dependencies pinned with hashes
- **Tool poisoning rule:** MCP tool descriptions must be scanned for injection patterns before being exposed to the model

### Resilience & Production Readiness
- Pipeline is fail-fast — parse errors abort before analysis begins
- Exit codes are deterministic: 0=success, 1=policy violation, 2=internal error, 3=invalid input
- **Phase 2 degraded modes:** Mode A (online), Mode B (offline — use cached SLT + policy snapshot), Mode C (SLT expired — limited mode: reads allowed, writes/shell/net blocked; `SG_FAIL_LICENSE_EXPIRED_LIMITED_MODE`)
- Graceful degradation: if LLM unavailable, deterministic analysis still runs
- Every feature ships with tests; no merge without green CI (ruff + mypy + pytest)
- Coverage ≥90% on all core modules; zero false negatives for critical patterns

### Quality Gates (Definition of Done)
- `ruff check` passes (zero errors)
- `mypy --strict` passes (zero errors)
- Unit + integration + E2E + perf tests pass
- Coverage ≥90% on changed modules
- Performance SLOs met (see latency targets above)
- Error paths, edge cases (empty input, huge input, unicode, binary, offline mode) tested
- Self-review with checklist before marking done; no TODO/FIXME without tracking issue
- **Run `/production-hardening-gate` before any pre-release or pre-merge on critical paths**

### Documentation
- Every public API function must have docstrings
- Rule interface: id, name, description, severity, weight, category + `analyze()` method
- Rule IDs follow `SG-{CATEGORY}-{NUMBER}` convention (e.g., SG-SHELL-001)
- Policy schema documented in `skillgate.yml` — version "1" required
- Phase 2 decision codes follow `SG_{TYPE}_{REASON}` convention (e.g., `SG_DENY_BUDGET_EXCEEDED`)

### UI Copy Standards
- All user-facing copy must read as human product writing, not internal process notes.
- Do not expose internal terms such as "source of truth", "entitlement gates", or test/implementation IDs on public pages.
- Avoid ellipses and em dashes in user-facing copy.
- Prefer plain, direct language that a buyer can understand on first read.
- If copy references future capabilities, label it as planned without overpromising implementation status.

### Token-Efficient Coding (Follow `/token-efficient-coding` skill)
- Produce correct, minimal code changes with minimal tokens
- Prefer small targeted edits over full rewrites; no restating prompts
- Bug fix: `file:line` + 1-sentence root cause + unified diff
- Refactor: unified diff only (≤120 lines)
- Code review: exactly 8 bullets: 3 bugs, 3 improvements, 2 questions (≤14 words each)
- Keep reasoning implicit; surface only for concurrency, distributed systems, security, tricky invariants

## Key Design Decisions

- **Deterministic scoring:** `score = Σ(finding.weight × severity_multiplier)` — no ML, no probabilistic components
- **Severity multipliers:** Low=0.5, Medium=1.0, High=1.5, Critical=2.0; score capped at 200 for display
- **Policy resolution order:** Built-in defaults → preset → project skillgate.yml → CLI flags (highest priority)
- **Manifest priority:** SKILL.md > skill.json > package.json > pyproject.toml
- **SARIF 2.1.0** output for GitHub Security tab integration
- **Canonical JSON** (sorted keys, no whitespace) for signing — SHA-256 hash then Ed25519 sign
- **Phase 2 enforcement:** 7-stage pipeline (Normalize → Enrich → Authorize → Evaluate → Decide → Record → Emit); every stage is a pure function; same input = same output guaranteed
- **SLT:** JWT RS256; claims: sub (org_id), tier, entitlements, rate_limits, exp (12–24h); stored in OS keychain only
- **Open-core boundary:** `runtime/`, `sdk/`, `mcp_gateway/`, `codex_bridge/`, `ecosystem/` are public CE; `control_plane/`, `auth/` SLT issuance, SIEM connectors are private EE

## Implementation Plans

- **Phase 1 (complete):** [docs/phase1/IMPLEMENTATION-PLAN.md](docs/phase1/IMPLEMENTATION-PLAN.md) — Sprints 1–7.3, all production gates green
- **Phase 2 (active):** [docs/phase2/IMPLEMENTATION-PLAN.md](docs/phase2/IMPLEMENTATION-PLAN.md) — Sprints 8–15, runtime enforcement through SaaS control plane

## Community Agent Skill: `skillgate-agent-tool`

SkillGate publishes a community agent skill — **`skillgate-agent-tool`** — so developers using Claude Code, Codex CLI, or any MCP-compatible agent can integrate SkillGate's enforcement capabilities directly into their own agent skills and projects.

**What it does:** The `skillgate-agent-tool` skill teaches an agent how to:
1. Call `skillgate scan` to audit a skill bundle before deployment
2. Call `skillgate enforce` to apply policy gates in CI
3. Call `POST /v1/decide` on the local sidecar to make runtime enforcement decisions from within an agent
4. Read and interpret `DecisionRecord` objects (decision_code, reason_codes, budget state)
5. Register tool AI-BOMs via `PUT /v1/registry/{tool_name}`
6. Handle denied invocations gracefully (`SG_DENY_*` codes → surface to user with remediation)

**Publishing targets:**
- [skillsmp.com](https://skillsmp.com) — primary skill marketplace
- [agentskills.io](https://agentskills.io) — agent-focused skill registry
- Claude Code plugin registry (via `skillgate-io/secure-claude-agents` blueprint repo)
- MCP community hub (modelcontextprotocol.io integrations directory)

**Skill location in this repo:** `.codex/skills/skillgate-agent-tool/SKILL.md`

**For agent skill authors:** If you are building a skill that calls SkillGate's sidecar API or SDK, reference the skill with `/skillgate-agent-tool` in your Claude Code session. The skill loads the full API contract, decision code reference, and integration examples so the agent can implement integration correctly without hallucinating API details.

**Community integration pattern (for skill authors using the SDK):**
```python
from skillgate.sdk import enforce, SkillGateClient

@enforce(capabilities=["fs.read", "shell.exec"])
def my_tool(path: str) -> str:
    # SkillGate intercepts this call, evaluates policy,
    # and raises CapabilityDeniedError if denied
    ...
```

## Repo Skills Reference

| Skill file | Purpose |
|---|---|
| `.codex/skills/production-hardening-gate/SKILL.md` | Pre-GA hardening, GO/NO-GO readiness checks |
| `.codex/skills/skillgate-agent-tool/SKILL.md` | Community integration skill — how to call SkillGate from an agent |
