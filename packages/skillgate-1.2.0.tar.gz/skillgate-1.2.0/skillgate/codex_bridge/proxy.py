"""Tool-proxy interception for Codex wrapper enforcement."""

from __future__ import annotations

from pathlib import Path
from typing import Protocol

from skillgate.codex_bridge.models import ToolProxyDecision
from skillgate.codex_bridge.policy import CodexPolicy, apply_default_guards


class SidecarDecider(Protocol):
    """Callable protocol for sidecar decision clients."""

    def __call__(self, request: dict[str, object]) -> ToolProxyDecision:
        """Evaluate one high-risk tool request."""


class ToolProxy:
    """Intercept high-risk tool calls and enforce local + sidecar policy."""

    def __init__(self, *, decider: SidecarDecider, policy: CodexPolicy, cwd: Path) -> None:
        self._decider = decider
        self._policy = policy
        self._cwd = cwd

    def intercept(self, request: dict[str, object]) -> ToolProxyDecision:
        """Intercept and decide one tool request."""
        capability = str(request.get("capability", ""))

        # Low-risk reads skip sidecar for latency.
        if capability in {"fs.read", "git.diff", "git.log"}:
            return ToolProxyDecision(
                allowed=True, decision_code="SG_ALLOW", reason="Low-risk read."
            )

        preflight = apply_default_guards(self._policy, request, self._cwd)
        if not preflight.allowed:
            return preflight

        if capability in {"shell.exec", "fs.write", "net.outbound", "process.spawn", "git.write"}:
            return self._decider(request)

        return ToolProxyDecision(
            allowed=True, decision_code="SG_ALLOW", reason="Capability not gated."
        )
