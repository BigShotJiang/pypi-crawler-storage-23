"""Repo-local config poisoning scanner for Codex bridge startup enforcement."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml

from skillgate.codex_bridge.models import CodexFinding, ProviderDefinition
from skillgate.codex_bridge.providers import ProviderRegistry


def scan_config_poisoning(project_root: Path, registry: ProviderRegistry) -> list[CodexFinding]:
    """Detect unapproved or expanded providers in repo-local Codex/MCP config surfaces."""
    findings: list[CodexFinding] = []
    for definition in discover_provider_definitions(project_root):
        allowed, reason = registry.evaluate(definition.provider_id, definition.permissions)
        if allowed:
            continue
        findings.append(
            CodexFinding(
                decision_code="SG_DENY_CONFIG_POISONING_DETECTED",
                message=f"Provider '{definition.provider_id}' blocked: {reason}",
                file_path=definition.source_file,
                surface="config",
                severity="critical",
                pattern=definition.provider_id,
            )
        )
    return findings


def discover_provider_definitions(project_root: Path) -> tuple[ProviderDefinition, ...]:
    """Discover provider definitions from Codex and MCP config files."""
    candidates: list[Path] = []
    candidates.extend(_existing(project_root / "codex.yml"))
    candidates.extend(_existing(project_root / "mcp.json"))

    codex_dir = project_root / ".codex"
    if codex_dir.exists():
        candidates.extend(
            path
            for path in codex_dir.rglob("*")
            if path.is_file() and path.suffix.lower() in {".json", ".yml", ".yaml"}
        )

    mcp_dir = project_root / ".mcp"
    if mcp_dir.exists():
        candidates.extend(
            path
            for path in mcp_dir.rglob("*")
            if path.is_file() and path.suffix.lower() in {".json", ".yml", ".yaml"}
        )

    deduped = sorted(set(candidates))
    definitions: list[ProviderDefinition] = []
    for path in deduped:
        payload = _load_file(path)
        if payload is None:
            continue
        rel = str(path.relative_to(project_root))
        definitions.extend(_extract_provider_definitions(payload, rel))
    return tuple(definitions)


def _extract_provider_definitions(payload: Any, source_file: str) -> list[ProviderDefinition]:
    definitions: list[ProviderDefinition] = []

    if isinstance(payload, dict):
        trusted = payload.get("trustedProviders")
        if isinstance(trusted, list):
            for entry in trusted:
                if isinstance(entry, str) and entry.strip():
                    definitions.append(
                        ProviderDefinition(
                            provider_id=entry.strip(),
                            permissions=(),
                            source_file=source_file,
                        )
                    )

        providers = payload.get("providers")
        if isinstance(providers, list):
            definitions.extend(_extract_provider_list(providers, source_file))

        mcp_servers = payload.get("mcpServers")
        if isinstance(mcp_servers, dict):
            for key, value in mcp_servers.items():
                if not isinstance(key, str):
                    continue
                permissions: tuple[str, ...] = ()
                if isinstance(value, dict):
                    permissions = _extract_permissions(value)
                definitions.append(
                    ProviderDefinition(
                        provider_id=key,
                        permissions=permissions,
                        source_file=source_file,
                    )
                )

    return definitions


def _extract_provider_list(entries: list[Any], source_file: str) -> list[ProviderDefinition]:
    definitions: list[ProviderDefinition] = []
    for entry in entries:
        if isinstance(entry, str) and entry.strip():
            definitions.append(
                ProviderDefinition(
                    provider_id=entry.strip(),
                    permissions=(),
                    source_file=source_file,
                )
            )
            continue
        if not isinstance(entry, dict):
            continue
        raw_provider = entry.get("id") or entry.get("name") or entry.get("provider")
        if not isinstance(raw_provider, str) or not raw_provider.strip():
            continue
        definitions.append(
            ProviderDefinition(
                provider_id=raw_provider.strip(),
                permissions=_extract_permissions(entry),
                source_file=source_file,
            )
        )
    return definitions


def _extract_permissions(entry: dict[str, Any]) -> tuple[str, ...]:
    permissions: set[str] = set()
    for key in ("permissions", "capabilities"):
        value = entry.get(key)
        if isinstance(value, list):
            for item in value:
                if isinstance(item, str) and item.strip():
                    permissions.add(item.strip())
    return tuple(sorted(permissions))


def _existing(path: Path) -> list[Path]:
    return [path] if path.exists() else []


def _load_file(path: Path) -> Any:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        return json.loads(text)
    return yaml.safe_load(text)
