"""HTTP client for SLT exchange and anonymous trial."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

import httpx


@dataclass(frozen=True)
class ExchangeResponse:
    """Normalized response from SLT exchange endpoints."""

    slt: str
    entitlements: dict[str, int]
    rate_limit_policy: dict[str, dict[str, int]]
    expires_at: datetime
    anonymous: bool


def exchange_api_key(
    *,
    api_base: str,
    api_key: str,
    device_id: str,
    session_info: dict[str, Any] | None = None,
    timeout: float = 10.0,
) -> ExchangeResponse:
    """Exchange API key for SLT."""
    response = httpx.post(
        f"{api_base.rstrip('/')}/api/v1/auth/exchange",
        json={"api_key": api_key, "device_id": device_id, "session_info": session_info or {}},
        timeout=timeout,
    )
    response.raise_for_status()
    data: dict[str, Any] = response.json()
    return ExchangeResponse(
        slt=str(data["slt"]),
        entitlements={str(k): int(v) for k, v in dict(data["entitlements"]).items()},
        rate_limit_policy={
            str(k): {str(x): int(y) for x, y in dict(v).items()}
            for k, v in dict(data["rate_limit_policy"]).items()
        },
        expires_at=datetime.fromisoformat(str(data["expires_at"])),
        anonymous=bool(data.get("anonymous", False)),
    )


def request_anonymous_slt(
    *,
    api_base: str,
    device_id: str,
    timeout: float = 10.0,
) -> ExchangeResponse:
    """Request anonymous trial SLT."""
    response = httpx.post(
        f"{api_base.rstrip('/')}/api/v1/auth/anonymous",
        json={"device_id": device_id},
        timeout=timeout,
    )
    response.raise_for_status()
    data: dict[str, Any] = response.json()
    return ExchangeResponse(
        slt=str(data["slt"]),
        entitlements={str(k): int(v) for k, v in dict(data["entitlements"]).items()},
        rate_limit_policy={
            str(k): {str(x): int(y) for x, y in dict(v).items()}
            for k, v in dict(data["rate_limit_policy"]).items()
        },
        expires_at=datetime.fromisoformat(str(data["expires_at"])),
        anonymous=bool(data.get("anonymous", False)),
    )
