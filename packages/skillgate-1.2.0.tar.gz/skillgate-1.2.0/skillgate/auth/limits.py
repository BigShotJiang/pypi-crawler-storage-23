"""Client-side rate limit configuration from SLT claims."""

from __future__ import annotations

from typing import Any

from skillgate.runtime.token_bucket import TokenBucketConfig


def load_rate_limit_configs(rate_limits: dict[str, Any]) -> dict[str, TokenBucketConfig]:
    """Convert SLT ``rate_limits`` claim to token bucket configs."""
    configs: dict[str, TokenBucketConfig] = {}
    for capability, raw in rate_limits.items():
        if not isinstance(raw, dict):
            continue
        per_minute = int(raw.get("per_minute", 0))
        burst = int(raw.get("burst", 0))
        if per_minute < 1 or burst < 1:
            continue
        capacity = max(per_minute, burst)
        configs[str(capability)] = TokenBucketConfig(
            capacity=capacity,
            refill_per_minute=per_minute,
            burst=burst,
        )
    return configs
