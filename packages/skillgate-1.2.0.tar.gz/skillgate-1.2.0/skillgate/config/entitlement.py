"""Cryptographic API key validation and entitlement resolution.

SECURITY FIX 16.33: Replace format-only validation with cryptographic tokens.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from skillgate.config.license import Tier
from skillgate.core.errors import ConfigError


@dataclass
class Entitlement:
    """Validated entitlement with cryptographic proof."""

    tier: Tier
    user_id: str
    expires_at: datetime | None
    capabilities: set[str]
    rate_limit: int
    source: str  # "local_validation" or "server_attested"

    def is_expired(self) -> bool:
        """Check if entitlement has expired."""
        if self.expires_at is None:
            return False
        return datetime.now(timezone.utc) > self.expires_at

    def has_capability(self, capability: str) -> bool:
        """Check if entitlement includes a capability."""
        return capability in self.capabilities


def _get_signing_secret() -> str:
    """Get API key signing secret from environment."""
    secret = os.environ.get("SKILLGATE_API_KEY_SECRET")
    if not secret:
        # Allow unsigned keys in development only
        env = os.environ.get("SKILLGATE_ENV", "development").lower()
        if env in {"production", "staging"}:
            raise RuntimeError("SKILLGATE_API_KEY_SECRET must be configured in production/staging.")
        return "dev-insecure-signing-secret"
    return secret


def verify_signed_api_key(api_key: str) -> Entitlement:
    """Verify a signed JWT/JWS API key and extract entitlement.

    SECURITY FIX 16.33: Use cryptographic validation instead of prefix-only.

    Expected format: sg_v1_<base64url(payload)>_<base64url(signature)>
    Payload: {"tier": "pro", "user_id": "...", "exp": timestamp, "caps": [...]}
    Signature: HMAC-SHA256(payload, secret)

    Args:
        api_key: The API key to validate

    Returns:
        Validated Entitlement

    Raises:
        ConfigError: If key is invalid or signature doesn't match
    """
    if not api_key.startswith("sg_v1_"):
        raise ConfigError("Invalid API key format")

    try:
        # Parse: sg_v1_<payload>_<signature>
        parts = api_key.split("_", 3)
        if len(parts) != 4 or parts[0] != "sg" or parts[1] != "v1":
            raise ConfigError("Invalid API key structure")

        payload_b64 = parts[2]
        signature_b64 = parts[3]

        # Decode payload
        payload_bytes = base64.urlsafe_b64decode(payload_b64 + "==")  # Add padding
        payload: dict[str, Any] = json.loads(payload_bytes.decode("utf-8"))

        # Verify signature
        secret = _get_signing_secret()
        computed_sig = hmac.new(secret.encode("utf-8"), payload_bytes, hashlib.sha256).digest()
        expected_sig = base64.urlsafe_b64decode(signature_b64 + "==")

        if not hmac.compare_digest(computed_sig, expected_sig):
            raise ConfigError("Invalid API key signature")

        # Extract entitlement
        tier_str = payload.get("tier")
        if tier_str not in {"free", "pro", "team", "enterprise"}:
            raise ConfigError("Invalid tier in API key")

        tier = Tier(tier_str)
        user_id = str(payload.get("user_id", "unknown"))

        exp_timestamp = payload.get("exp")
        expires_at = None
        if exp_timestamp:
            expires_at = datetime.fromtimestamp(exp_timestamp, tz=timezone.utc)

        caps = set(payload.get("caps", []))
        rate_limit = int(payload.get("rate_limit", _default_rate_limit(tier)))

        entitlement = Entitlement(
            tier=tier,
            user_id=user_id,
            expires_at=expires_at,
            capabilities=caps,
            rate_limit=rate_limit,
            source="local_validation",
        )

        if entitlement.is_expired():
            raise ConfigError("API key has expired")

        return entitlement

    except (ValueError, KeyError, json.JSONDecodeError) as exc:
        raise ConfigError(f"Invalid API key: {exc}") from exc


def _default_rate_limit(tier: Tier) -> int:
    """Get default rate limit for tier."""
    from skillgate.config.license import RATE_LIMITS

    return RATE_LIMITS[tier]


def validate_api_key_with_entitlement(api_key: str) -> Entitlement:
    """Validate API key and return entitlement.

    SECURITY FIX 16.33: This is the new entry point for validation.
    Falls back to basic tier extraction for legacy keys in development only.

    Args:
        api_key: The API key to validate

    Returns:
        Validated Entitlement

    Raises:
        ConfigError: If key is invalid
    """
    # Try signed key first (v1 format)
    if api_key.startswith("sg_v1_"):
        return verify_signed_api_key(api_key)

    # Legacy format fallback (only in development)
    env = os.environ.get("SKILLGATE_ENV", "development").lower()
    if env in {"production", "staging"}:
        raise ConfigError(
            "Legacy API key format not supported in production. Use signed keys: sg_v1_*"
        )

    # Basic tier extraction for development (INSECURE - dev only)
    from skillgate.config.license import validate_api_key

    tier = validate_api_key(api_key)

    return Entitlement(
        tier=tier,
        user_id="dev-user",
        expires_at=None,
        capabilities=_default_capabilities(tier),
        rate_limit=_default_rate_limit(tier),
        source="legacy_dev_only",
    )


def _default_capabilities(tier: Tier) -> set[str]:
    """Get default capabilities for tier."""
    if tier == Tier.FREE:
        return {"scan"}
    if tier == Tier.PRO:
        return {"scan", "enforce", "sign"}
    if tier == Tier.TEAM:
        return {"scan", "enforce", "sign", "ci_blocking", "fleet_scan"}
    # Enterprise
    return {"scan", "enforce", "sign", "ci_blocking", "custom_policies", "audit_export"}
