"""FastAPI router for control-plane Sprint 15 endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel, ConfigDict, Field

from skillgate.control_plane.service import (
    ControlPlaneError,
    ControlPlaneService,
)


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ApprovalRequestBody(_StrictModel):
    capability: str = Field(min_length=1)
    workspace_id: str = Field(min_length=1)
    agent_id: str = Field(min_length=1)
    justification: str = Field(min_length=3)
    expires_in_minutes: int = Field(default=60, ge=1, le=60 * 24 * 7)
    role: Literal["org_admin", "workspace_admin", "security_reviewer", "developer"]
    requester_id: str = Field(min_length=1)


class ApprovalActionBody(_StrictModel):
    role: Literal["org_admin", "workspace_admin", "security_reviewer", "developer"]
    approver_id: str = Field(min_length=1)


class PolicyPutBody(_StrictModel):
    role: Literal["org_admin", "workspace_admin", "security_reviewer", "developer"]
    actor_id: str = Field(min_length=1)
    policy: dict[str, object]


class PolicyRollbackBody(_StrictModel):
    role: Literal["org_admin", "workspace_admin", "security_reviewer", "developer"]
    actor_id: str = Field(min_length=1)
    target_version: int = Field(ge=1)


class RetentionDeleteBody(_StrictModel):
    role: Literal["org_admin", "workspace_admin", "security_reviewer", "developer"]
    actor_id: str = Field(min_length=1)


def _cp(request: Request) -> ControlPlaneService:
    service = getattr(request.app.state, "control_plane", None)
    if not isinstance(service, ControlPlaneService):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="control plane unavailable",
        )
    return service


def _raise_control_plane_error(exc: ControlPlaneError) -> None:
    detail = str(exc)
    if "missing permission" in detail or "forbidden" in detail.lower():
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=detail) from exc
    if "not found" in detail.lower():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=detail) from exc
    raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_CONTENT, detail=detail) from exc


def create_control_plane_router() -> APIRouter:
    """Return control-plane router."""
    router = APIRouter(tags=["control-plane"])

    @router.post("/v1/approvals/request")
    def approvals_request(body: ApprovalRequestBody, request: Request) -> dict[str, object]:
        cp = _cp(request)
        try:
            approval = cp.request_approval(
                role=body.role,
                capability=body.capability,
                workspace_id=body.workspace_id,
                agent_id=body.agent_id,
                justification=body.justification,
                expires_in_minutes=body.expires_in_minutes,
                requester_id=body.requester_id,
            )
        except ControlPlaneError as exc:
            _raise_control_plane_error(exc)
        return {
            "id": approval.id,
            "status": approval.status,
            "expires_at": approval.expires_at.isoformat(),
        }

    @router.post("/v1/approvals/{approval_id}/approve")
    def approvals_approve(
        approval_id: str,
        body: ApprovalActionBody,
        request: Request,
    ) -> dict[str, object]:
        cp = _cp(request)
        try:
            approval = cp.set_approval_status(
                role=body.role,
                approval_id=approval_id,
                status="approved",
                approver_id=body.approver_id,
            )
        except ControlPlaneError as exc:
            _raise_control_plane_error(exc)
        return {"id": approval.id, "status": approval.status}

    @router.post("/v1/approvals/{approval_id}/deny")
    def approvals_deny(
        approval_id: str,
        body: ApprovalActionBody,
        request: Request,
    ) -> dict[str, object]:
        cp = _cp(request)
        try:
            approval = cp.set_approval_status(
                role=body.role,
                approval_id=approval_id,
                status="denied",
                approver_id=body.approver_id,
            )
        except ControlPlaneError as exc:
            _raise_control_plane_error(exc)
        return {"id": approval.id, "status": approval.status}

    @router.get("/v1/approvals/pending")
    def approvals_pending(
        request: Request,
        workspace_id: str | None = None,
    ) -> dict[str, object]:
        cp = _cp(request)
        pending = cp.list_pending_approvals(workspace_id=workspace_id)
        return {
            "count": len(pending),
            "items": [
                {
                    "id": item.id,
                    "workspace_id": item.workspace_id,
                    "agent_id": item.agent_id,
                    "capability": item.capability,
                    "expires_at": item.expires_at.isoformat(),
                }
                for item in pending
            ],
        }

    @router.put("/v1/policies/{workspace_id}")
    def policy_put(workspace_id: str, body: PolicyPutBody, request: Request) -> dict[str, object]:
        cp = _cp(request)
        try:
            version = cp.update_policy(
                role=body.role,
                workspace_id=workspace_id,
                changed_by=body.actor_id,
                policy=body.policy,
            )
        except ControlPlaneError as exc:
            _raise_control_plane_error(exc)
        return {
            "workspace_id": workspace_id,
            "version": version.version,
            "diff_keys": list(version.diff_keys),
        }

    @router.post("/v1/policies/{workspace_id}/rollback")
    def policy_rollback(
        workspace_id: str,
        body: PolicyRollbackBody,
        request: Request,
    ) -> dict[str, object]:
        cp = _cp(request)
        try:
            restored = cp.rollback_policy(
                role=body.role,
                workspace_id=workspace_id,
                target_version=body.target_version,
                actor_id=body.actor_id,
            )
        except ControlPlaneError as exc:
            _raise_control_plane_error(exc)
        return {"workspace_id": workspace_id, "version": restored.version}

    @router.delete("/v1/audit/{workspace_id}/before/{before_date}")
    def audit_delete_before(
        workspace_id: str,
        before_date: str,
        body: RetentionDeleteBody,
        request: Request,
    ) -> dict[str, object]:
        cp = _cp(request)
        try:
            before = datetime.fromisoformat(before_date)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail="before_date must be ISO-8601",
            ) from exc
        try:
            deleted = cp.delete_audit_before(
                role=body.role,
                workspace_id=workspace_id,
                before=before,
                actor_id=body.actor_id,
            )
        except ControlPlaneError as exc:
            _raise_control_plane_error(exc)
        return {"workspace_id": workspace_id, "deleted": deleted}

    return router
