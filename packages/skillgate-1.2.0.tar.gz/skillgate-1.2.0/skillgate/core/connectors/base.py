"""Base connector protocol — contract for all intel connectors.

Every connector must implement the ``BaseConnector`` abstract class.
The contract enforces:

1. **Read-only** — connectors never mutate findings or policy state.
2. **Timeout** — ``fetch`` must respect ``config.timeout_seconds``.
3. **Fail-open** — callers wrap ``fetch`` so failures yield empty results.
"""

from __future__ import annotations

import abc

from skillgate.core.connectors.models import ConnectorConfig, ConnectorResult


class BaseConnector(abc.ABC):
    """Abstract base class for intel connectors.

    Subclasses must implement ``fetch`` and ``validate_config``.
    """

    def __init__(self, config: ConnectorConfig) -> None:
        self._config = config

    @property
    def name(self) -> str:
        """Connector name from config."""
        return self._config.name

    @property
    def config(self) -> ConnectorConfig:
        """Read-only access to connector config."""
        return self._config

    @abc.abstractmethod
    def validate_config(self) -> list[str]:
        """Validate connector-specific configuration.

        Returns a list of error messages. Empty list means valid.
        """

    @abc.abstractmethod
    def fetch(self, rule_ids: list[str]) -> ConnectorResult:
        """Fetch enrichment data for the given rule IDs.

        Must complete within ``self._config.timeout_seconds``.
        Implementations should raise on unrecoverable errors;
        the manager layer handles fail-open semantics.

        Args:
            rule_ids: Rule IDs to look up enrichment for.

        Returns:
            ConnectorResult with enrichments keyed by rule_id.
        """
