"""Air-gap entitlement pack handling with expiry/grace enforcement."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from skillgate.core.errors import EntitlementError


@dataclass(frozen=True)
class AirgapPack:
    """Parsed air-gap entitlement pack."""

    token: str
    public_key: str
    expires_at: datetime
    grace_expires_at: datetime | None
    fail_policy: str
    usage_date: str
    usage_used: int
    usage_limit: int
    path: Path


def default_pack_path() -> Path:
    """Resolve default air-gap pack path."""
    raw = os.environ.get("SKILLGATE_AIRGAP_PACK_PATH", ".skillgate/airgap-pack.json").strip()
    return Path(raw)


def load_airgap_pack(path: Path | None = None) -> AirgapPack:
    """Load and validate the configured air-gap pack from disk."""
    pack_path = path or default_pack_path()
    if not pack_path.exists():
        raise EntitlementError(
            f"Air-gap entitlement pack not found at {pack_path}.",
            tier="ENTERPRISE",
        )
    try:
        data_obj = json.loads(pack_path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise EntitlementError(
            f"Invalid air-gap entitlement pack JSON: {exc}",
            tier="ENTERPRISE",
        ) from exc

    data = data_obj if isinstance(data_obj, dict) else {}
    token = _require_string(data, "token")
    public_key = _require_string(data, "public_key")
    expires_at = _parse_utc(_require_string(data, "expires_at"), "expires_at")
    grace_expires_at = _optional_utc(data.get("grace_expires_at"), "grace_expires_at")
    fail_policy = str(data.get("fail_policy", "closed")).strip().lower()
    if fail_policy not in {"open", "closed"}:
        raise EntitlementError(
            "Invalid air-gap fail_policy. Use 'open' or 'closed'.",
            tier="ENTERPRISE",
        )

    usage_obj = data.get("usage")
    usage = usage_obj if isinstance(usage_obj, dict) else {}
    usage_date = str(usage.get("date", datetime.now(timezone.utc).date().isoformat()))
    usage_used = _coerce_non_negative_int(usage.get("used", 0), "usage.used")
    usage_limit = _coerce_non_negative_int(usage.get("limit", 0), "usage.limit")

    return AirgapPack(
        token=token,
        public_key=public_key,
        expires_at=expires_at,
        grace_expires_at=grace_expires_at,
        fail_policy=fail_policy,
        usage_date=usage_date,
        usage_used=usage_used,
        usage_limit=usage_limit,
        path=pack_path,
    )


def enforce_pack_window(pack: AirgapPack, now: datetime | None = None) -> None:
    """Enforce pack expiry/grace/fail-policy semantics."""
    current = now or datetime.now(timezone.utc)
    if current <= pack.expires_at:
        return
    if (
        pack.fail_policy == "open"
        and pack.grace_expires_at is not None
        and current <= pack.grace_expires_at
    ):
        return
    if pack.fail_policy == "open" and pack.grace_expires_at is None:
        return
    raise EntitlementError(
        "Air-gap entitlement pack expired and grace policy does not allow continued enforcement.",
        tier="ENTERPRISE",
    )


def consume_airgap_pack_scan(pack: AirgapPack) -> tuple[int, int]:
    """Consume one scan from air-gap pack usage state and persist."""
    today = datetime.now(timezone.utc).date().isoformat()
    used = pack.usage_used
    limit = pack.usage_limit
    if pack.usage_date != today:
        used = 0

    if limit > 0 and used >= limit:
        raise EntitlementError(
            f"Daily scan quota exceeded ({used}/{limit}). Reason: airgap quota exhausted.",
            tier="ENTERPRISE",
        )

    if limit > 0:
        used += 1

    _write_usage_state(pack.path, usage_date=today, used=used, limit=limit)
    _append_event_log(
        {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event": "consume_scan",
            "mode": "airgap",
            "used": used,
            "limit": limit,
            "pack_path": str(pack.path),
        }
    )
    return used, limit


def _write_usage_state(path: Path, *, usage_date: str, used: int, limit: int) -> None:
    raw_obj = json.loads(path.read_text(encoding="utf-8"))
    data = raw_obj if isinstance(raw_obj, dict) else {}
    data["usage"] = {"date": usage_date, "used": used, "limit": limit}
    path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def _append_event_log(event: dict[str, Any]) -> None:
    raw_path = os.environ.get(
        "SKILLGATE_AIRGAP_EVENT_LOG",
        ".skillgate/airgap-events.jsonl",
    ).strip()
    path = Path(raw_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.open("a", encoding="utf-8").write(json.dumps(event, separators=(",", ":")) + "\n")


def _require_string(data: dict[str, object], key: str) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        raise EntitlementError(f"Missing required air-gap pack field '{key}'.", tier="ENTERPRISE")
    return value.strip()


def _parse_utc(value: str, field: str) -> datetime:
    with_value = value.replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(with_value)
    except ValueError as exc:
        raise EntitlementError(
            f"Invalid {field} in air-gap pack: {exc}",
            tier="ENTERPRISE",
        ) from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _optional_utc(value: object, field: str) -> datetime | None:
    if value is None:
        return None
    return _parse_utc(str(value), field)


def _coerce_non_negative_int(value: object, field: str) -> int:
    parsed: int
    if isinstance(value, bool):
        raise EntitlementError(f"Invalid {field} in air-gap pack.", tier="ENTERPRISE")
    if isinstance(value, int):
        parsed = value
    elif isinstance(value, float):
        parsed = int(value)
    elif isinstance(value, str):
        try:
            parsed = int(value)
        except ValueError as exc:
            raise EntitlementError(f"Invalid {field} in air-gap pack.", tier="ENTERPRISE") from exc
    else:
        raise EntitlementError(f"Invalid {field} in air-gap pack.", tier="ENTERPRISE")
    if parsed < 0:
        raise EntitlementError(f"Invalid {field} in air-gap pack.", tier="ENTERPRISE")
    return parsed
