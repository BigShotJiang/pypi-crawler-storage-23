"""Resilience utilities for entitlement resolution."""

from __future__ import annotations

import logging
from collections.abc import Callable

from skillgate.config.license import Tier
from skillgate.core.entitlement.models import TIER_ENTITLEMENTS, Entitlement, EntitlementSource

logger = logging.getLogger(__name__)


class FailOpenPolicy:
    """Policy that returns FREE-tier entitlement on any resolution failure."""

    def __init__(self) -> None:
        self._fallback = TIER_ENTITLEMENTS[Tier.FREE]()

    def wrap(self, resolver: Callable[[], Entitlement]) -> Entitlement:
        """Execute resolver with fail-open fallback.

        Args:
            resolver: Function that returns an Entitlement

        Returns:
            Entitlement from resolver, or FREE tier on failure
        """
        try:
            return resolver()
        except Exception as e:
            logger.warning(f"Entitlement resolution failed, falling back to FREE tier: {e}")
            return Entitlement(
                tier=Tier.FREE,
                capabilities=self._fallback.capabilities,
                limits=self._fallback.limits,
                source=EntitlementSource.DEFAULT,
            )


# Global fail-open policy
_fail_open_policy = FailOpenPolicy()


def resolve_with_fail_open(resolver: Callable[[], Entitlement]) -> Entitlement:
    """Resolve entitlement with fail-open semantics."""
    return _fail_open_policy.wrap(resolver)
