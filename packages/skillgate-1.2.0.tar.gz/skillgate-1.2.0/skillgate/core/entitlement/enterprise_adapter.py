"""Enterprise on-prem entitlement validation adapter."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

import httpx

from skillgate.config.license import Tier
from skillgate.core.entitlement.models import TIER_ENTITLEMENTS, Entitlement


@dataclass(frozen=True)
class EnterpriseValidationResult:
    """Result from on-prem enterprise entitlement validation."""

    allowed: bool
    reason: str | None = None
    expires_at: datetime | None = None


class EnterpriseValidationAdapter:
    """Contract for enterprise on-prem entitlement validation."""

    async def validate(
        self,
        *,
        user_id: str,
        entitlement: Entitlement,
    ) -> EnterpriseValidationResult:
        """Validate enterprise entitlement in an external control-plane."""
        raise NotImplementedError


class NoOpEnterpriseValidationAdapter(EnterpriseValidationAdapter):
    """Default adapter that always allows enterprise entitlements."""

    async def validate(
        self,
        *,
        user_id: str,
        entitlement: Entitlement,
    ) -> EnterpriseValidationResult:
        _ = user_id
        _ = entitlement
        return EnterpriseValidationResult(allowed=True)


class HttpEnterpriseValidationAdapter(EnterpriseValidationAdapter):
    """HTTP adapter for enterprise on-prem validation endpoint."""

    def __init__(
        self,
        *,
        url: str,
        token: str | None,
        timeout_seconds: float = 3.0,
    ) -> None:
        self._url = url
        self._token = token
        self._timeout_seconds = timeout_seconds

    async def validate(
        self,
        *,
        user_id: str,
        entitlement: Entitlement,
    ) -> EnterpriseValidationResult:
        payload = {
            "user_id": user_id,
            "tier": entitlement.tier.value,
            "capabilities": sorted(cap.value for cap in entitlement.capabilities),
        }
        headers = {"Content-Type": "application/json"}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"

        async with httpx.AsyncClient(timeout=self._timeout_seconds) as client:
            response = await client.post(self._url, json=payload, headers=headers)
            response.raise_for_status()
            data = response.json()

        allowed = bool(data.get("allowed", False))
        reason_obj = data.get("reason")
        reason = str(reason_obj) if reason_obj is not None else None

        expires_at: datetime | None = None
        expires_obj = data.get("expires_at")
        if isinstance(expires_obj, str):
            with_value = expires_obj.replace("Z", "+00:00")
            expires_at = datetime.fromisoformat(with_value)
            if expires_at.tzinfo is not None:
                expires_at = expires_at.replace(tzinfo=None)

        return EnterpriseValidationResult(
            allowed=allowed,
            reason=reason,
            expires_at=expires_at,
        )


def build_enterprise_validation_adapter(
    *,
    onprem_url: str | None,
    onprem_token: str | None,
    timeout_seconds: float,
) -> EnterpriseValidationAdapter:
    """Build enterprise validation adapter from runtime settings."""
    if not onprem_url:
        return NoOpEnterpriseValidationAdapter()
    return HttpEnterpriseValidationAdapter(
        url=onprem_url,
        token=onprem_token,
        timeout_seconds=timeout_seconds,
    )


def apply_enterprise_validation_result(
    entitlement: Entitlement,
    validation: EnterpriseValidationResult,
) -> Entitlement:
    """Apply validation metadata to an entitlement."""
    if entitlement.tier != Tier.ENTERPRISE:
        return entitlement
    if not validation.allowed:
        return TIER_ENTITLEMENTS[Tier.FREE]()
    if validation.expires_at is None:
        return entitlement
    return Entitlement(
        tier=entitlement.tier,
        capabilities=entitlement.capabilities,
        limits=entitlement.limits,
        source=entitlement.source,
        expires_at=validation.expires_at,
        on_prem_validation_url=entitlement.on_prem_validation_url,
    )
