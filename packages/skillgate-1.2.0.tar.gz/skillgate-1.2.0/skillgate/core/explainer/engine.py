"""Explanation engine — LLM-powered explanations with template fallback.

Supports Anthropic and OpenAI backends. Falls back to template-based
explanations when no LLM SDK is installed or no API key is configured.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from urllib.parse import urlparse

import httpx

from skillgate.core.explainer.templates import (
    template_explanation,
    template_explanation_executive,
)
from skillgate.core.models.finding import Finding

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Explanation:
    """An explanation for a finding."""

    rule_id: str
    text: str
    source: str  # "anthropic", "openai", or "template"


_CUSTOM_PROVIDERS = {"azure-openai", "groq", "ollama"}
_REQUEST_TIMEOUT_SECONDS = 8.0
_REQUEST_RETRIES = 2


def _detect_backend() -> str | None:
    """Detect which LLM backend is available.

    Returns backend name or None if no backend is available.
    Checks for API keys in environment variables.
    """
    if os.environ.get("SKILLGATE_EXPLAIN_CUSTOM_PROVIDER"):
        return "custom"

    if os.environ.get("ANTHROPIC_API_KEY"):
        try:
            import anthropic  # noqa: F401

            return "anthropic"
        except ImportError:
            pass

    if os.environ.get("OPENAI_API_KEY"):
        try:
            import openai  # noqa: F401

            return "openai"
        except ImportError:
            pass

    return None


def _template_fallback(findings: list[Finding]) -> list[Explanation]:
    return [
        Explanation(
            rule_id=finding.rule_id,
            text=template_explanation(finding),
            source="template",
        )
        for finding in findings
    ]


def _render_prompt(finding: Finding) -> str:
    return (
        "You are a security expert reviewing code. Explain this security finding "
        "concisely in 2-3 sentences. Include what the risk is and how to fix it.\n\n"
        f"Rule: {finding.rule_id} ({finding.rule_name})\n"
        f"Severity: {finding.severity}\n"
        f"Category: {finding.category}\n"
        f"Message: {finding.message}\n"
        f"File: {finding.file}:{finding.line}\n"
        f"Code: {finding.snippet}\n"
    )


def _custom_timeout_seconds() -> float:
    raw = os.environ.get("SKILLGATE_EXPLAIN_PROVIDER_TIMEOUT_S", "").strip()
    if not raw:
        return _REQUEST_TIMEOUT_SECONDS
    try:
        value = float(raw)
    except ValueError:
        return _REQUEST_TIMEOUT_SECONDS
    return value if value > 0 else _REQUEST_TIMEOUT_SECONDS


def _custom_retries() -> int:
    raw = os.environ.get("SKILLGATE_EXPLAIN_PROVIDER_RETRIES", "").strip()
    if not raw:
        return _REQUEST_RETRIES
    try:
        value = int(raw)
    except ValueError:
        return _REQUEST_RETRIES
    return min(max(value, 0), 5)


def _http_post_json(
    endpoint: str,
    *,
    headers: dict[str, str] | None,
    payload: dict[str, object],
    timeout_seconds: float,
    retries: int,
) -> dict[str, object]:
    attempts = retries + 1
    for attempt in range(attempts):
        try:
            with httpx.Client(timeout=timeout_seconds) as client:
                response = client.post(endpoint, headers=headers, json=payload)
                response.raise_for_status()
                body = response.json()
                if isinstance(body, dict):
                    return body
                return {}
        except Exception:
            if attempt == attempts - 1:
                raise
    return {}


def _extract_openai_style_content(body: dict[str, object]) -> str:
    choices = body.get("choices")
    if not isinstance(choices, list) or not choices:
        return ""
    first = choices[0]
    if not isinstance(first, dict):
        return ""
    message = first.get("message")
    if not isinstance(message, dict):
        return ""
    content = message.get("content")
    return content if isinstance(content, str) else ""


def _extract_ollama_content(body: dict[str, object]) -> str:
    response = body.get("response")
    return response if isinstance(response, str) else ""


def _resolve_custom_provider_env(provider: str) -> tuple[str, str]:
    if provider == "azure-openai":
        return "AZURE_OPENAI_API_KEY", "SKILLGATE_EXPLAIN_CUSTOM_DEPLOYMENT"
    if provider == "groq":
        return "GROQ_API_KEY", "SKILLGATE_EXPLAIN_CUSTOM_MODEL"
    return "", "SKILLGATE_EXPLAIN_CUSTOM_MODEL"


def _custom_provider_request(
    provider: str,
    *,
    endpoint: str,
    finding: Finding,
    timeout_seconds: float,
    retries: int,
) -> str:
    prompt = _render_prompt(finding)
    if provider == "azure-openai":
        key = os.environ.get("AZURE_OPENAI_API_KEY", "").strip()
        deployment = os.environ.get("SKILLGATE_EXPLAIN_CUSTOM_DEPLOYMENT", "").strip()
        api_version = os.environ.get(
            "SKILLGATE_EXPLAIN_AZURE_API_VERSION", "2024-02-15-preview"
        ).strip()
        if not key or not deployment:
            return ""
        normalized = endpoint.rstrip("/")
        request_endpoint = (
            f"{normalized}/openai/deployments/{deployment}/chat/completions"
            f"?api-version={api_version}"
        )
        body = _http_post_json(
            request_endpoint,
            headers={"api-key": key, "Content-Type": "application/json"},
            payload={
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 256,
                "temperature": 0,
            },
            timeout_seconds=timeout_seconds,
            retries=retries,
        )
        return _extract_openai_style_content(body)

    if provider == "groq":
        key = os.environ.get("GROQ_API_KEY", "").strip()
        model = os.environ.get("SKILLGATE_EXPLAIN_CUSTOM_MODEL", "llama-3.1-8b-instant").strip()
        if not key:
            return ""
        normalized = endpoint.rstrip("/")
        request_endpoint = f"{normalized}/openai/v1/chat/completions"
        body = _http_post_json(
            request_endpoint,
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            payload={
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 256,
                "temperature": 0,
            },
            timeout_seconds=timeout_seconds,
            retries=retries,
        )
        return _extract_openai_style_content(body)

    if provider == "ollama":
        model = os.environ.get("SKILLGATE_EXPLAIN_CUSTOM_MODEL", "llama3.1").strip()
        normalized = endpoint.rstrip("/")
        request_endpoint = f"{normalized}/api/generate"
        body = _http_post_json(
            request_endpoint,
            headers={"Content-Type": "application/json"},
            payload={"model": model, "prompt": prompt, "stream": False},
            timeout_seconds=timeout_seconds,
            retries=retries,
        )
        return _extract_ollama_content(body)

    return ""


def _egress_enabled() -> bool:
    return os.environ.get("SKILLGATE_EXPLAIN_EGRESS", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _endpoint_host(url: str) -> str:
    parsed = urlparse(url)
    return parsed.netloc.lower()


def _endpoint_allowed(provider: str, endpoint: str) -> bool:
    if not endpoint:
        return False
    if not _egress_enabled():
        logger.info("Explanation egress disabled for provider=%s", provider)
        return False
    allowlist_raw = os.environ.get("SKILLGATE_EXPLAIN_ENDPOINT_ALLOWLIST", "").strip()
    if not allowlist_raw:
        # Explicit defaults for built-in hosted providers.
        if provider == "anthropic":
            return _endpoint_host(endpoint) == "api.anthropic.com"
        if provider == "openai":
            return _endpoint_host(endpoint) == "api.openai.com"
        # custom provider always requires explicit allowlist.
        return False
    allowlist = {host.strip().lower() for host in allowlist_raw.split(",") if host.strip()}
    return _endpoint_host(endpoint) in allowlist


def _explain_with_anthropic(findings: list[Finding]) -> list[Explanation]:
    """Generate explanations using Anthropic Claude API."""
    endpoint = os.environ.get("ANTHROPIC_BASE_URL", "https://api.anthropic.com")
    if not _endpoint_allowed("anthropic", endpoint):
        return _template_fallback(findings)

    import anthropic

    client = anthropic.Anthropic()
    results: list[Explanation] = []

    for finding in findings:
        prompt = _render_prompt(finding)

        try:
            response = client.messages.create(
                model="claude-sonnet-4-5-20250929",
                max_tokens=256,
                messages=[{"role": "user", "content": prompt}],
            )
            first_block = response.content[0] if response.content else None
            text = getattr(first_block, "text", "")
            results.append(
                Explanation(
                    rule_id=finding.rule_id,
                    text=text,
                    source="anthropic",
                )
            )
        except Exception as e:
            logger.warning("Anthropic API error for %s: %s", finding.rule_id, e)
            results.append(_template_fallback([finding])[0])

    return results


def _explain_with_openai(findings: list[Finding]) -> list[Explanation]:
    """Generate explanations using OpenAI API."""
    endpoint = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com")
    if not _endpoint_allowed("openai", endpoint):
        return _template_fallback(findings)

    import openai

    client = openai.OpenAI()
    results: list[Explanation] = []

    for finding in findings:
        prompt = _render_prompt(finding)

        try:
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                max_tokens=256,
                messages=[{"role": "user", "content": prompt}],
            )
            text = response.choices[0].message.content or ""
            results.append(
                Explanation(
                    rule_id=finding.rule_id,
                    text=text,
                    source="openai",
                )
            )
        except Exception as e:
            logger.warning("OpenAI API error for %s: %s", finding.rule_id, e)
            results.append(_template_fallback([finding])[0])

    return results


def _explain_with_custom(findings: list[Finding]) -> list[Explanation]:
    provider = os.environ.get("SKILLGATE_EXPLAIN_CUSTOM_PROVIDER", "").strip().lower()
    endpoint = os.environ.get("SKILLGATE_EXPLAIN_CUSTOM_BASE_URL", "").strip()
    if not provider:
        logger.info("Custom provider requested but not configured; using template fallback")
        return _template_fallback(findings)
    if provider not in _CUSTOM_PROVIDERS:
        logger.warning("Unsupported custom provider '%s'; using template fallback", provider)
        return _template_fallback(findings)
    key_env, model_env = _resolve_custom_provider_env(provider)
    if key_env and not os.environ.get(key_env, "").strip():
        logger.info(
            "Custom provider key missing for provider=%s; using template fallback",
            provider,
        )
        return _template_fallback(findings)
    if provider != "azure-openai" and not os.environ.get(model_env, "").strip():
        logger.info("Custom provider model missing for provider=%s; using defaults", provider)
    if not _endpoint_allowed("custom", endpoint):
        logger.info(
            "Custom provider endpoint blocked by policy (provider=%s, endpoint=%s); fallback",
            provider,
            endpoint,
        )
        return _template_fallback(findings)
    timeout_seconds = _custom_timeout_seconds()
    retries = _custom_retries()
    results: list[Explanation] = []
    for finding in findings:
        try:
            text = _custom_provider_request(
                provider,
                endpoint=endpoint,
                finding=finding,
                timeout_seconds=timeout_seconds,
                retries=retries,
            )
            if not text:
                results.append(_template_fallback([finding])[0])
                continue
            results.append(
                Explanation(
                    rule_id=finding.rule_id,
                    text=text,
                    source=f"custom:{provider}",
                )
            )
        except Exception as exc:
            logger.warning("Custom provider error for %s (%s): %s", finding.rule_id, provider, exc)
            results.append(_template_fallback([finding])[0])
    return results


def explain_findings(
    findings: list[Finding],
    backend: str | None = None,
    mode: str = "technical",
) -> list[Explanation]:
    """Generate explanations for a list of findings.

    Tries LLM backends in order: Anthropic -> OpenAI -> template fallback.
    If a specific backend is requested but unavailable, falls back to templates.

    Args:
        findings: List of findings to explain.
        backend: Force a specific backend ("anthropic", "openai", "template").
                 None for auto-detection.

    Returns:
        List of Explanation objects, one per finding.
    """
    if not findings:
        return []

    mode_value = mode.strip().lower()
    if mode_value not in {"technical", "executive"}:
        mode_value = "technical"

    if backend == "template":
        template_fn = (
            template_explanation_executive if mode_value == "executive" else template_explanation
        )
        return [
            Explanation(
                rule_id=f.rule_id,
                text=template_fn(f),
                source="template-executive" if mode_value == "executive" else "template",
            )
            for f in findings
        ]

    # Auto-detect or use specified backend
    resolved = backend or _detect_backend()

    if resolved == "anthropic":
        logger.info("Using Anthropic backend for explanations")
        return _explain_with_anthropic(findings)

    if resolved == "openai":
        logger.info("Using OpenAI backend for explanations")
        return _explain_with_openai(findings)

    if resolved == "custom":
        logger.info("Using custom provider backend for explanations")
        return _explain_with_custom(findings)

    # Fallback to templates
    logger.info("No LLM backend available — using template explanations")
    template_fn = (
        template_explanation_executive if mode_value == "executive" else template_explanation
    )
    return [
        Explanation(
            rule_id=f.rule_id,
            text=template_fn(f),
            source="template-executive" if mode_value == "executive" else "template",
        )
        for f in findings
    ]
