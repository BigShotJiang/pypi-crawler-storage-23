"""Performance guards for SkillGate static analysis engine.

Provides deterministic, fail-fast bounds on file sizes, line counts,
and extraction budgets so cold-start latency and memory stay within SLO:
  - Cold start < 2 s
  - 10-file scan < 3 s
  - 100-file scan < 10 s
  - Peak memory < 256 MB

All helpers are stateless and dependency-free (no network I/O).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# ── Default limits ──────────────────────────────────────────────────────────

#: Skip any source file larger than this (matches CLAUDE.md requirement)
MAX_ANALYSIS_FILE_BYTES: int = 100 * 1024  # 100 KB

#: Hard ceiling on lines analysed per file (prevents O(n*rules) blowup)
MAX_ANALYSIS_LINES: int = 10_000

#: Soft ceiling on total extracted-artifact bytes across one bundle scan
MAX_EXTRACTION_BUDGET_BYTES: int = 50 * 1024 * 1024  # 50 MB

#: Scan timeout per-file in seconds (applies when timeout guard is active)
DEFAULT_FILE_TIMEOUT_SECONDS: float = 5.0

#: Warn (but do not abort) if a regex pre-filter scan exceeds this many chars
PREFILTER_WARN_CHARS: int = 200_000


# ── File-level helpers ──────────────────────────────────────────────────────


def should_skip_large_file(content: str, path: str = "") -> bool:
    """Return True and emit a warning if the file exceeds the size limit.

    Args:
        content: Raw file content as a string.
        path: Optional path for log messages.

    Returns:
        True if the file should be skipped, False otherwise.
    """
    byte_len = len(content.encode("utf-8", errors="replace"))
    if byte_len > MAX_ANALYSIS_FILE_BYTES:
        logger.warning(
            "Skipping %s — file too large (%d KB > %d KB limit).",
            path or "(unknown)",
            byte_len // 1024,
            MAX_ANALYSIS_FILE_BYTES // 1024,
        )
        return True
    return False


def truncate_lines_for_analysis(lines: list[str], path: str = "") -> list[str]:
    """Truncate lines list to MAX_ANALYSIS_LINES, warning if truncated.

    Args:
        lines: Source file lines.
        path: Optional path for log messages.

    Returns:
        Original list if within limit, otherwise a truncated copy.
    """
    if len(lines) <= MAX_ANALYSIS_LINES:
        return lines
    logger.warning(
        "Truncating %s to %d lines for analysis (file has %d lines).",
        path or "(unknown)",
        MAX_ANALYSIS_LINES,
        len(lines),
    )
    return lines[:MAX_ANALYSIS_LINES]


# ── Extraction budget tracker ───────────────────────────────────────────────


@dataclass
class ExtractionBudget:
    """Track cumulative extraction cost across archive/document extractors.

    Usage::

        budget = ExtractionBudget()
        if budget.can_accept(len(content)):
            budget.record(len(content))
        else:
            # emit warning, skip artifact
            ...
    """

    max_bytes: int = MAX_EXTRACTION_BUDGET_BYTES
    consumed_bytes: int = 0
    artifacts_accepted: int = 0
    artifacts_rejected: int = 0
    warnings: list[str] = field(default_factory=list)

    @property
    def remaining_bytes(self) -> int:
        """Bytes remaining in the extraction budget."""
        return max(0, self.max_bytes - self.consumed_bytes)

    @property
    def is_exhausted(self) -> bool:
        """True once the byte budget is fully consumed."""
        return self.consumed_bytes >= self.max_bytes

    def can_accept(self, byte_count: int) -> bool:
        """Check if a new artifact of ``byte_count`` bytes fits in budget.

        Args:
            byte_count: Number of bytes to add.

        Returns:
            True if the artifact fits; False if it would exceed the budget.
        """
        return (self.consumed_bytes + byte_count) <= self.max_bytes

    def record(self, byte_count: int, source: str = "") -> None:
        """Record accepted bytes.

        Args:
            byte_count: Number of bytes accepted.
            source: Optional artifact identifier for logging.
        """
        self.consumed_bytes += byte_count
        self.artifacts_accepted += 1
        if self.is_exhausted and source:
            logger.warning("Extraction budget exhausted after accepting %s.", source)

    def reject(self, byte_count: int, source: str = "") -> None:
        """Record a rejected artifact.

        Args:
            byte_count: Number of bytes in the rejected artifact.
            source: Optional artifact identifier for logging and warnings.
        """
        self.artifacts_rejected += 1
        msg = (
            f"Skipped {source or 'artifact'} ({byte_count // 1024} KB): "
            f"extraction budget exhausted "
            f"({self.consumed_bytes // (1024 * 1024)} MB / "
            f"{self.max_bytes // (1024 * 1024)} MB used)."
        )
        self.warnings.append(msg)
        logger.warning(msg)


# ── Scan timer for CI timing diagnostics ───────────────────────────────────


@dataclass
class ScanTimer:
    """Lightweight wall-clock timer for scan-phase latency reporting.

    Usage::

        timer = ScanTimer()
        # ... scan ...
        elapsed = timer.elapsed_ms()
        if elapsed > 10_000:
            logger.warning("Scan exceeded 10 s SLO: %.1f s", elapsed / 1000)
    """

    _start: float = field(default_factory=time.monotonic)

    def elapsed_ms(self) -> float:
        """Return elapsed wall-clock milliseconds since timer was created."""
        return (time.monotonic() - self._start) * 1000.0

    def elapsed_s(self) -> float:
        """Return elapsed wall-clock seconds since timer was created."""
        return time.monotonic() - self._start

    def check_slo(self, max_seconds: float, label: str = "scan") -> bool:
        """Warn and return False if elapsed time exceeds SLO.

        Args:
            max_seconds: SLO threshold in seconds.
            label: Description for the warning message.

        Returns:
            True if within SLO, False if exceeded.
        """
        elapsed = self.elapsed_s()
        if elapsed > max_seconds:
            logger.warning("%s exceeded SLO: %.2f s > %.2f s limit.", label, elapsed, max_seconds)
            return False
        return True
