"""Analysis engine — orchestrates rule execution and finding deduplication."""

from __future__ import annotations

import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

from skillgate.core.analyzer.perf_guard import should_skip_large_file, truncate_lines_for_analysis
from skillgate.core.analyzer.rules import get_all_rules
from skillgate.core.analyzer.rules.base import Rule
from skillgate.core.analyzer.unicode_normalizer import normalise_for_analysis
from skillgate.core.models.bundle import SkillBundle, SourceFile
from skillgate.core.models.finding import Finding

logger = logging.getLogger(__name__)

# Pre-filter regex: skip files with no suspicious content
_PREFILTER = re.compile(
    r"(subprocess|os\.system|os\.popen|shell\s*=\s*True|child_process|shutil\."
    r"|requests\.|urllib|httpx\.|fetch\(|socket\.|ftp"
    r"|open\s*\(|\.ssh/|\.aws/|/etc/passwd|/tmp/"
    r"|eval\s*\(|exec\s*\(|compile\s*\(|importlib|__import__|new\s+Function"
    r"|os\.environ|os\.getenv|process\.env|api[_-]?key|token|secret|password"
    r"|ignore\s+previous|os\.system\s*\(\s*f|render_template_string"
    r"|base64|atob|btoa|chr\s*\(|fromCharCode|\\x[0-9a-fA-F]|fromhex"
    r"|\[::\s*-1\]|\.reverse\s*\(|os\.symlink|glob\.glob|os\.chmod"
    # Go keywords
    r"|exec\.Command|net\.Dial|http\.Get|http\.Post|http\.ListenAndServe"
    r"|os\.Create|os\.OpenFile|os\.WriteFile|os\.Remove|os\.RemoveAll"
    r"|reflect\.Value|plugin\.Open|os\.Getenv|os\.LookupEnv|os\.Setenv"
    r"|filepath\.Join"
    # Rust keywords
    r"|Command::new|TcpStream::connect|TcpListener::bind|reqwest::|hyper::|ureq::"
    r"|File::create|fs::write|fs::remove|remove_dir_all|unsafe\s*\{"
    r"|libloading::Library|env::var|env::set_var"
    # Ruby keywords
    r"|\bsystem\s*\(|\bIO\.popen|Open3\.|Process\.spawn"
    r"|Net::HTTP|HTTParty|Faraday|RestClient"
    r"|TCPSocket|UDPSocket|Socket\.new"
    r"|FileUtils\.rm|File\.delete|File\.write|File\.open"
    r"|instance_eval|class_eval|public_send"
    r"|const_get|\bENV\[)",
    re.IGNORECASE,
)


def _should_analyze(source: SourceFile) -> bool:
    """Quick pre-filter check to skip files with no suspicious patterns.

    Also skips files exceeding the 100 KB size guard.
    Unicode normalisation is applied so confusable chars don't bypass pre-filter.
    """
    if should_skip_large_file(source.content, source.path):
        return False
    # Normalise before pre-filter to catch confusable-char evasion
    norm_result = normalise_for_analysis(source.content, source.path)
    return bool(_PREFILTER.search(norm_result.normalised))


def _analyze_file(source: SourceFile, rules: list[Rule]) -> list[Finding]:
    """Run all rules against a single source file.

    Lines are truncated at MAX_ANALYSIS_LINES to prevent O(n*rules) blowup.
    Unicode normalisation is applied so confusable-char evasion is caught.
    """
    # Apply unicode normalisation to the content before analysis
    norm = normalise_for_analysis(source.content, source.path)
    if norm.had_bidi_overrides or norm.had_confusables:
        norm_lines = norm.normalised.splitlines()
        source = source.model_copy(update={"content": norm.normalised, "lines": norm_lines})

    # Work with a guarded line list to prevent runaway analysis
    guarded = source.model_copy(
        update={"lines": truncate_lines_for_analysis(source.lines, source.path)}
    )
    findings: list[Finding] = []
    for rule in rules:
        try:
            results = rule.analyze(guarded)
            findings.extend(results)
        except Exception:
            logger.exception("Rule %s failed on %s", rule.id, source.path)
    return findings


def deduplicate_findings(findings: list[Finding]) -> list[Finding]:
    """Remove duplicate findings at the same file:line:rule_id.

    When both AST and regex detect the same issue, keep only one.
    """
    seen: set[tuple[str, int, str]] = set()
    unique: list[Finding] = []
    for finding in findings:
        key = (finding.file, finding.line, finding.rule_id)
        if key not in seen:
            seen.add(key)
            unique.append(finding)
    return unique


def analyze_bundle(
    bundle: SkillBundle,
    disabled_rules: list[str] | None = None,
) -> list[Finding]:
    """Analyze all source files in a bundle and return deduplicated findings.

    Args:
        bundle: The skill bundle to analyze.
        disabled_rules: Rule IDs to skip.

    Returns:
        Deduplicated list of findings, sorted by file then line.
    """
    rules = get_all_rules(disabled=disabled_rules)
    if not rules:
        return []

    all_findings: list[Finding] = []

    # Filter files that pass pre-filter
    scannable = [sf for sf in bundle.source_files if _should_analyze(sf)]

    if not scannable:
        return []

    # Use thread pool for parallel rule evaluation per file
    with ThreadPoolExecutor() as executor:
        futures = {executor.submit(_analyze_file, sf, rules): sf.path for sf in scannable}
        for future in as_completed(futures):
            try:
                findings = future.result()
                all_findings.extend(findings)
            except Exception:
                logger.exception("Analysis failed for %s", futures[future])

    # Deduplicate and sort
    unique = deduplicate_findings(all_findings)
    unique.sort(key=lambda f: (f.file, f.line))
    return unique
