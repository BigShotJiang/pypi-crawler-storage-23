"""Unicode and confusable-character normalisation for static analysis.

Attackers can craft payloads that visually resemble ASCII while using
lookalike Unicode codepoints to evade pattern-matching rules.  This
module provides:

1. **NFC/NFKC normalisation** — decomposes multi-codepoint sequences back
   to canonical composed forms (e.g. ``é`` as two codepoints → one).
2. **ASCII confusable folding** — maps commonly-confused Unicode letters to
   their ASCII equivalents using a hand-curated table of high-risk mappings.
3. **Null-byte and control-character stripping** — removes invisible chars
   that can split rule keywords across token boundaries.
4. **Bidirectional control override detection** — flags the use of RTL/LTR
   override codepoints (U+202A–U+202E, U+2066–U+2069) used in "Trojan-
   Source" style attacks.

All operations are deterministic and offline; no network calls.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field

# ── Confusable mapping ───────────────────────────────────────────────────────
# Maps high-risk Unicode letters to their ASCII lookalike.
# Sourced from Unicode Confusables (tr39), focused on code-abuse scenarios.
_CONFUSABLES: dict[str, str] = {
    # Cyrillic
    "\u0430": "a",  # а → a
    "\u0435": "e",  # е → e
    "\u0456": "i",  # і → i
    "\u04cf": "l",  # ӏ → l  (Cyrillic small palochka)
    "\u043e": "o",  # о → o
    "\u0440": "r",  # р → r
    "\u0441": "c",  # с → c
    "\u0445": "x",  # х → x
    "\u0443": "y",  # у → y
    "\u0042": "B",  # (ASCII B — kept for completeness)
    # Greek
    "\u03b1": "a",  # α → a
    "\u03b5": "e",  # ε → e
    "\u03b9": "i",  # ι → i
    "\u03bf": "o",  # ο → o
    "\u03c1": "p",  # ρ → p
    "\u03c5": "u",  # υ → u
    "\u03c7": "x",  # χ → x
    # Fullwidth ASCII
    "\uff41": "a",
    "\uff42": "b",
    "\uff43": "c",
    "\uff44": "d",
    "\uff45": "e",
    "\uff46": "f",
    "\uff47": "g",
    "\uff48": "h",
    "\uff49": "i",
    "\uff4a": "j",
    "\uff4b": "k",
    "\uff4c": "l",
    "\uff4d": "m",
    "\uff4e": "n",
    "\uff4f": "o",
    "\uff50": "p",
    "\uff51": "q",
    "\uff52": "r",
    "\uff53": "s",
    "\uff54": "t",
    "\uff55": "u",
    "\uff56": "v",
    "\uff57": "w",
    "\uff58": "x",
    "\uff59": "y",
    "\uff5a": "z",
    # Mathematical bold/italic (often used in chat)
    "\U0001d41a": "a",
    "\U0001d41b": "b",
    "\U0001d41c": "c",
    "\U0001d41d": "d",
    "\U0001d41e": "e",
    "\U0001d41f": "f",
    "\U0001d420": "g",
    "\U0001d421": "h",
    "\U0001d422": "i",
    "\U0001d423": "j",
    "\U0001d424": "k",
    "\U0001d425": "l",
    "\U0001d426": "m",
    "\U0001d427": "n",
    "\U0001d428": "o",
    "\U0001d429": "p",
    "\U0001d42a": "q",
    "\U0001d42b": "r",
    "\U0001d42c": "s",
    "\U0001d42d": "t",
    "\U0001d42e": "u",
    "\U0001d42f": "v",
    "\U0001d430": "w",
    "\U0001d431": "x",
    "\U0001d432": "y",
    "\U0001d433": "z",
}

_CONFUSABLE_RE = re.compile("[" + "".join(re.escape(k) for k in _CONFUSABLES) + "]")

# ── Bidi override codepoints ─────────────────────────────────────────────────
_BIDI_OVERRIDES: frozenset[str] = frozenset(
    chr(cp)
    for cp in [
        0x202A,
        0x202B,
        0x202C,
        0x202D,
        0x202E,  # LRE/RLE/PDF/LRO/RLO
        0x2066,
        0x2067,
        0x2068,
        0x2069,  # LRI/RLI/FSI/PDI
        0x200F,
        0x200E,  # RLM/LRM
        0x061C,  # ALM
    ]
)

# ── Control character stripping ──────────────────────────────────────────────
# Strip null bytes and C0/C1 control chars EXCEPT common whitespace
_CONTROL_STRIP_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")


# ── Result types ─────────────────────────────────────────────────────────────


@dataclass
class NormalisationResult:
    """Outcome of normalising a content string.

    Attributes:
        normalised: The processed string ready for pattern matching.
        had_bidi_overrides: True if bidi control chars were found.
        had_confusables: True if confusable substitutions were made.
        had_control_chars: True if invisible control chars were stripped.
        warnings: Human-readable warning strings for the report.
    """

    normalised: str
    had_bidi_overrides: bool = False
    had_confusables: bool = False
    had_control_chars: bool = False
    warnings: list[str] = field(default_factory=list)


# ── Core API ─────────────────────────────────────────────────────────────────


def normalise_for_analysis(content: str, path: str = "") -> NormalisationResult:
    """Normalise a source content string for rule matching.

    Applies in order:
    1. NFKC Unicode normalisation (decomposes compatibility forms)
    2. Bidi override detection and stripping
    3. Null/control-char stripping
    4. Confusable folding to ASCII equivalents

    Args:
        content: Raw file content.
        path: Optional file path for warning messages.

    Returns:
        NormalisationResult with the normalised string and flag fields.
    """
    result = NormalisationResult(normalised=content)
    label = path or "(unknown)"

    # 1. NFKC — handles composed chars, compatibility forms
    content = unicodedata.normalize("NFKC", content)

    # 2. Bidi override detection
    bidi_found = any(ch in _BIDI_OVERRIDES for ch in content)
    if bidi_found:
        result.had_bidi_overrides = True
        result.warnings.append(
            f"{label}: bidirectional control override characters detected "
            f"(possible Trojan-Source attack)."
        )
        content = "".join(ch for ch in content if ch not in _BIDI_OVERRIDES)

    # 3. Strip null bytes and control chars
    stripped = _CONTROL_STRIP_RE.sub("", content)
    if stripped != content:
        result.had_control_chars = True
        result.warnings.append(f"{label}: invisible control characters stripped before analysis.")
        content = stripped

    # 4. Confusable folding
    def _fold(m: re.Match[str]) -> str:
        return _CONFUSABLES.get(m.group(0), m.group(0))

    folded = _CONFUSABLE_RE.sub(_fold, content)
    if folded != content:
        result.had_confusables = True
        result.warnings.append(
            f"{label}: Unicode confusable characters normalised to ASCII equivalents."
        )
        content = folded

    result.normalised = content
    return result


def has_bidi_overrides(text: str) -> bool:
    """Quickly check whether text contains bidirectional override codepoints.

    Args:
        text: String to inspect.

    Returns:
        True if any bidi override codepoint is present.
    """
    return any(ch in _BIDI_OVERRIDES for ch in text)


def fold_confusables(text: str) -> str:
    """Apply confusable folding to ``text`` and return the result.

    Args:
        text: String to fold.

    Returns:
        String with confusable Unicode chars replaced by ASCII equivalents.
    """
    return _CONFUSABLE_RE.sub(lambda m: _CONFUSABLES.get(m.group(0), m.group(0)), text)
