"""Shell execution detection rules (SG-SHELL-001 through SG-SHELL-007)."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import RegexRule, Rule
from skillgate.core.models.bundle import SourceFile
from skillgate.core.models.enums import Category, Severity
from skillgate.core.models.finding import Finding


class SubprocessCallRule(RegexRule):
    """SG-SHELL-001: Detect subprocess.run/Popen/call usage."""

    id = "SG-SHELL-001"
    name = "subprocess_call"
    description = "Direct subprocess execution detected"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    patterns = [
        (
            re.compile(r"\bsubprocess\.(run|Popen|call|check_call|check_output)\b"),
            "Direct subprocess execution detected: {match}",
            "Use subprocess.run() with a list of arguments instead of shell=True. "
            "Never pass user-controlled input to shell commands.",
        ),
    ]


class OsSystemRule(RegexRule):
    """SG-SHELL-002: Detect os.system() calls."""

    id = "SG-SHELL-002"
    name = "os_system"
    description = "OS-level command execution detected"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    patterns = [
        (
            re.compile(r"\bos\.system\s*\("),
            "OS-level command execution detected: {match}",
            "Avoid os.system(). Use subprocess.run() with argument lists instead.",
        ),
    ]


class OsPopenRule(RegexRule):
    """SG-SHELL-003: Detect os.popen() calls."""

    id = "SG-SHELL-003"
    name = "os_popen"
    description = "OS pipe command execution detected"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    patterns = [
        (
            re.compile(r"\bos\.popen\s*\("),
            "OS pipe command execution detected: {match}",
            "Avoid os.popen(). Use subprocess.run() with PIPE for output capture.",
        ),
    ]


class ShellTrueRule(RegexRule):
    """SG-SHELL-004: Detect shell=True parameter (shell injection vector)."""

    id = "SG-SHELL-004"
    name = "shell_true"
    description = "Shell injection vector: shell=True parameter"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.SHELL
    patterns = [
        (
            re.compile(r"\bshell\s*=\s*True\b"),
            "Shell injection vector detected: {match}",
            "Never use shell=True. Pass command arguments as a list to prevent injection.",
        ),
    ]


class BacktickExecRule(RegexRule):
    """SG-SHELL-005: Detect backtick command execution in JS/Shell."""

    id = "SG-SHELL-005"
    name = "backtick_exec"
    description = "Backtick command execution (JS/Shell)"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    patterns = [
        (
            re.compile(r"\bexec\s*\(\s*`"),
            "Backtick command execution detected: {match}",
            "Avoid using template literals in exec(). Sanitize all command inputs.",
        ),
        (
            re.compile(r"\$\(.*\)"),
            "Command substitution detected: {match}",
            "Avoid command substitution with unsanitized input.",
        ),
    ]


class ChildProcessRule(RegexRule):
    """SG-SHELL-006: Detect Node.js child_process usage."""

    id = "SG-SHELL-006"
    name = "child_process"
    description = "Node.js child process execution"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    patterns = [
        (
            re.compile(r"\bchild_process\.(exec|spawn|execFile|fork|execSync|spawnSync)\b"),
            "Node.js child process execution detected: {match}",
            "Avoid child_process.exec(). Prefer child_process.execFile() with sanitized arguments.",
        ),
        (
            re.compile(r"""require\s*\(\s*['"]child_process['"]\s*\)"""),
            "Node.js child_process module imported: {match}",
            "Review usage of child_process module for command injection risks.",
        ),
    ]


class ShutilOperationsRule(RegexRule):
    """SG-SHELL-007: Detect destructive shutil operations."""

    id = "SG-SHELL-007"
    name = "shutil_operations"
    description = "Destructive file operations via shutil"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.SHELL
    patterns = [
        (
            re.compile(r"\bshutil\.(rmtree|move|copytree)\s*\("),
            "Destructive file operation detected: {match}",
            "Verify that shutil operations target only expected paths within the skill bundle.",
        ),
    ]


class OsSystemAliasRule(Rule):
    """SG-SHELL-008: Detect aliased os.system() calls."""

    id = "SG-SHELL-008"
    name = "os_system_alias"
    description = "OS-level command execution via aliased os.system detected"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL

    _assign_pattern = re.compile(r"^\s*([A-Za-z_]\w*)\s*=\s*os\.system\b")

    def analyze(self, source: SourceFile) -> list[Finding]:
        alias_by_name: dict[str, int] = {}
        findings: list[Finding] = []
        for line_num, line in enumerate(source.lines, start=1):
            assign = self._assign_pattern.search(line)
            if assign is not None:
                alias_by_name[assign.group(1)] = line_num
                continue
            for alias, assigned_line in alias_by_name.items():
                call_match = re.search(rf"\b{re.escape(alias)}\s*\(", line)
                if call_match is None:
                    continue
                findings.append(
                    self._make_finding(
                        source,
                        line_num,
                        (
                            "OS-level command execution detected via alias: "
                            f"'{alias}' assigned from os.system at line {assigned_line}"
                        ),
                        column=call_match.start() + 1,
                        remediation=(
                            "Avoid os.system(), including indirect aliases. "
                            "Use subprocess.run() with argument lists."
                        ),
                    )
                )
        return findings


SHELL_RULES: list[type[Rule]] = [
    SubprocessCallRule,
    OsSystemRule,
    OsPopenRule,
    ShellTrueRule,
    BacktickExecRule,
    ChildProcessRule,
    ShutilOperationsRule,
    OsSystemAliasRule,
]
