"""AST-based rules for Shell/Bash scripts (SG-*-050 series).

These rules use tree-sitter S-expression queries for precise shell pattern
detection. They gracefully degrade when tree-sitter is not installed.
"""

from __future__ import annotations

from skillgate.core.analyzer.rules.base import AstRule
from skillgate.core.models.enums import Category, Language, Severity

_SHELL = frozenset({Language.SHELL})


class ShellCurlAstRule(AstRule):
    """SG-NET-050: Detect curl/wget usage via AST."""

    id = "SG-NET-050"
    name = "shell_curl_ast"
    description = "Network download command detected"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.NETWORK
    languages = _SHELL
    query = '(command name: (command_name) @cmd (#match? @cmd "^(curl|wget)$"))'


class ShellSudoAstRule(AstRule):
    """SG-SHELL-050: Detect sudo usage via AST."""

    id = "SG-SHELL-050"
    name = "shell_sudo_ast"
    description = "Privileged command execution detected"
    severity = Severity.HIGH
    weight = 35
    category = Category.SHELL
    languages = _SHELL
    query = '(command name: (command_name) @cmd (#eq? @cmd "sudo"))'


class ShellChmodAstRule(AstRule):
    """SG-FS-050: Detect chmod/chown usage via AST."""

    id = "SG-FS-050"
    name = "shell_chmod_ast"
    description = "File permission modification detected"
    severity = Severity.MEDIUM
    weight = 20
    category = Category.FILESYSTEM
    languages = _SHELL
    query = '(command name: (command_name) @cmd (#match? @cmd "^(chmod|chown)$"))'


class ShellRmAstRule(AstRule):
    """SG-FS-051: Detect rm/rmdir usage via AST."""

    id = "SG-FS-051"
    name = "shell_rm_ast"
    description = "File deletion command detected"
    severity = Severity.HIGH
    weight = 30
    category = Category.FILESYSTEM
    languages = _SHELL
    query = '(command name: (command_name) @cmd (#match? @cmd "^(rm|rmdir)$"))'


class ShellEvalAstRule(AstRule):
    """SG-EVAL-050: Detect eval usage in shell scripts via AST."""

    id = "SG-EVAL-050"
    name = "shell_eval_ast"
    description = "Shell eval command detected"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.EVAL
    languages = _SHELL
    query = '(command name: (command_name) @cmd (#eq? @cmd "eval"))'


SHELL_AST_RULES: list[type[AstRule]] = [
    ShellCurlAstRule,
    ShellSudoAstRule,
    ShellChmodAstRule,
    ShellRmAstRule,
    ShellEvalAstRule,
]
