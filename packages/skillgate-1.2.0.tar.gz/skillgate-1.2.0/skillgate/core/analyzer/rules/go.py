"""Go detection rules (SG-*-010 through SG-*-019)."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import LanguageRegexRule
from skillgate.core.models.enums import Category, Language, Severity

_GO = frozenset({Language.GO})


class GoExecCommandRule(LanguageRegexRule):
    """SG-SHELL-010: Detect exec.Command() in Go."""

    id = "SG-SHELL-010"
    name = "go_exec_command"
    description = "Go exec.Command() process execution"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    languages = _GO
    patterns = [
        (
            re.compile(r"\bexec\.Command\s*\("),
            "Go process execution detected: {match}",
            "Validate and sanitize all arguments passed to exec.Command(). "
            "Avoid constructing commands from user input.",
        ),
    ]


class GoExecOutputRule(LanguageRegexRule):
    """SG-SHELL-011: Detect exec.Command().Run/Output/CombinedOutput()."""

    id = "SG-SHELL-011"
    name = "go_exec_output"
    description = "Go command output capture"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    languages = _GO
    patterns = [
        (
            re.compile(r"\.\s*(Run|Output|CombinedOutput)\s*\(\s*\)"),
            "Go command execution with output capture: {match}",
            "Ensure command arguments are not user-controlled. "
            "Use argument lists instead of shell strings.",
        ),
    ]


class GoHttpRequestRule(LanguageRegexRule):
    """SG-NET-010: Detect Go HTTP client calls."""

    id = "SG-NET-010"
    name = "go_http_request"
    description = "Go outbound HTTP request"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.NETWORK
    languages = _GO
    patterns = [
        (
            re.compile(r"\bhttp\.(Get|Post|Head|NewRequest|Do)\s*\("),
            "Go HTTP request detected: {match}",
            "Verify outbound HTTP requests target allowed domains only. "
            "Use an allowlist for permitted destinations.",
        ),
    ]


class GoNetDialRule(LanguageRegexRule):
    """SG-NET-011: Detect net.Dial/DialTimeout() in Go."""

    id = "SG-NET-011"
    name = "go_net_dial"
    description = "Go raw network dial"
    severity = Severity.HIGH
    weight = 35
    category = Category.NETWORK
    languages = _GO
    patterns = [
        (
            re.compile(r"\bnet\.(Dial|DialTimeout)\s*\("),
            "Go raw network connection detected: {match}",
            "Avoid raw socket connections. Use higher-level HTTP clients with TLS.",
        ),
    ]


class GoHttpListenRule(LanguageRegexRule):
    """SG-NET-012: Detect http.ListenAndServe() in Go."""

    id = "SG-NET-012"
    name = "go_http_listen"
    description = "Go HTTP server listener"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.NETWORK
    languages = _GO
    patterns = [
        (
            re.compile(r"\bhttp\.ListenAndServe\s*\("),
            "Go HTTP server detected: {match}",
            "Skills should not start HTTP servers. "
            "Remove server functionality from the skill bundle.",
        ),
    ]


class GoFileWriteRule(LanguageRegexRule):
    """SG-FS-010: Detect file write operations in Go."""

    id = "SG-FS-010"
    name = "go_file_write"
    description = "Go file write operation"
    severity = Severity.MEDIUM
    weight = 15
    category = Category.FILESYSTEM
    languages = _GO
    patterns = [
        (
            re.compile(r"\bos\.(Create|OpenFile|WriteFile)\s*\("),
            "Go file write operation detected: {match}",
            "Verify file writes target only expected paths within the skill bundle.",
        ),
    ]


class GoFileDeleteRule(LanguageRegexRule):
    """SG-FS-011: Detect file/directory deletion in Go."""

    id = "SG-FS-011"
    name = "go_file_delete"
    description = "Go file/directory deletion"
    severity = Severity.HIGH
    weight = 40
    category = Category.FILESYSTEM
    languages = _GO
    patterns = [
        (
            re.compile(r"\bos\.(Remove|RemoveAll)\s*\("),
            "Go file deletion detected: {match}",
            "Avoid deleting files outside the skill bundle directory.",
        ),
    ]


class GoPathTraversalRule(LanguageRegexRule):
    """SG-FS-012: Detect path traversal via filepath.Join in Go."""

    id = "SG-FS-012"
    name = "go_path_traversal"
    description = "Go path traversal attempt"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.FILESYSTEM
    languages = _GO
    patterns = [
        (
            re.compile(r"""filepath\.Join\s*\([^)]*["']\.\.['"\/]"""),
            "Go path traversal detected: {match}",
            "Never use '..' in filepath.Join(). Use filepath.Clean() and validate paths.",
        ),
    ]


class GoReflectCallRule(LanguageRegexRule):
    """SG-EVAL-010: Detect reflect.Value.Call() in Go."""

    id = "SG-EVAL-010"
    name = "go_reflect_call"
    description = "Go reflection-based function call"
    severity = Severity.HIGH
    weight = 35
    category = Category.EVAL
    languages = _GO
    patterns = [
        (
            re.compile(r"\breflect\.Value\b.*\bCall\s*\("),
            "Go reflection call detected: {match}",
            "Avoid reflection-based calls. Use direct function calls instead.",
        ),
    ]


class GoPluginOpenRule(LanguageRegexRule):
    """SG-EVAL-011: Detect plugin.Open() in Go."""

    id = "SG-EVAL-011"
    name = "go_plugin_open"
    description = "Go dynamic plugin loading"
    severity = Severity.HIGH
    weight = 35
    category = Category.EVAL
    languages = _GO
    patterns = [
        (
            re.compile(r"\bplugin\.Open\s*\("),
            "Go dynamic plugin loading detected: {match}",
            "Avoid loading dynamic plugins. Use compiled dependencies instead.",
        ),
    ]


class GoEnvAccessRule(LanguageRegexRule):
    """SG-CRED-010: Detect environment variable access in Go."""

    id = "SG-CRED-010"
    name = "go_env_access"
    description = "Go environment variable access"
    severity = Severity.MEDIUM
    weight = 20
    category = Category.CREDENTIAL
    languages = _GO
    patterns = [
        (
            re.compile(r"\bos\.(Getenv|LookupEnv|Setenv)\s*\("),
            "Go environment variable access detected: {match}",
            "Declare required environment variables in the skill manifest. "
            "Avoid accessing undeclared environment variables.",
        ),
    ]


class GoHardcodedKeyRule(LanguageRegexRule):
    """SG-CRED-011: Detect hardcoded API keys in Go strings."""

    id = "SG-CRED-011"
    name = "go_hardcoded_key"
    description = "Hardcoded API key in Go code"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.CREDENTIAL
    languages = _GO
    patterns = [
        (
            re.compile(
                r"""(?:api[_-]?key|token|secret|password)\s*[:=]\s*["'][A-Za-z0-9]{20,}["']"""
            ),
            "Possible hardcoded credential detected: {match}",
            "Move credentials to environment variables or a secrets manager.",
        ),
    ]


class GoSqlInjectionRule(LanguageRegexRule):
    """SG-INJ-010: Detect SQL injection via fmt.Sprintf() in Go."""

    id = "SG-INJ-010"
    name = "go_sql_injection"
    description = "SQL injection via string formatting in Go"
    severity = Severity.HIGH
    weight = 35
    category = Category.INJECTION
    languages = _GO
    patterns = [
        (
            re.compile(r"""fmt\.Sprintf\s*\(\s*["'][^"']*(?:SELECT|INSERT|UPDATE|DELETE|DROP)"""),
            "Possible SQL injection via fmt.Sprintf: {match}",
            "Use parameterized queries instead of string formatting for SQL.",
        ),
    ]


GO_RULES: list[type[LanguageRegexRule]] = [
    GoExecCommandRule,
    GoExecOutputRule,
    GoHttpRequestRule,
    GoNetDialRule,
    GoHttpListenRule,
    GoFileWriteRule,
    GoFileDeleteRule,
    GoPathTraversalRule,
    GoReflectCallRule,
    GoPluginOpenRule,
    GoEnvAccessRule,
    GoHardcodedKeyRule,
    GoSqlInjectionRule,
]
