"""Ruby detection rules (SG-*-030 through SG-*-039)."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import LanguageRegexRule
from skillgate.core.models.enums import Category, Language, Severity

_RUBY = frozenset({Language.RUBY})


class RubySystemCallRule(LanguageRegexRule):
    """SG-SHELL-030: Detect system()/Kernel.system in Ruby."""

    id = "SG-SHELL-030"
    name = "ruby_system_call"
    description = "Ruby system() command execution"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    languages = _RUBY
    patterns = [
        (
            re.compile(r"\b(?:Kernel\.)?system\s*\("),
            "Ruby system() call detected: {match}",
            "Avoid system(). Use Open3.capture3 with explicit argument arrays.",
        ),
    ]


class RubyExecRule(LanguageRegexRule):
    """SG-SHELL-031: Detect exec() in Ruby."""

    id = "SG-SHELL-031"
    name = "ruby_exec"
    description = "Ruby exec() command execution"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    languages = _RUBY
    patterns = [
        (
            re.compile(r"\bexec\s*\("),
            "Ruby exec() call detected: {match}",
            "Avoid exec(). It replaces the current process entirely.",
        ),
    ]


class RubyBacktickRule(LanguageRegexRule):
    """SG-SHELL-032: Detect backtick command execution in Ruby."""

    id = "SG-SHELL-032"
    name = "ruby_backtick"
    description = "Ruby backtick command execution"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    languages = _RUBY
    patterns = [
        (
            re.compile(r"`[^`]+`"),
            "Ruby backtick command execution detected: {match}",
            "Avoid backtick execution. Use Open3 with explicit argument arrays.",
        ),
        (
            re.compile(r"%x\{[^}]+\}"),
            "Ruby %x command execution detected: {match}",
            "Avoid %x{} execution. Use Open3 with explicit argument arrays.",
        ),
    ]


class RubyIoPopenRule(LanguageRegexRule):
    """SG-SHELL-033: Detect IO.popen/Open3 in Ruby."""

    id = "SG-SHELL-033"
    name = "ruby_io_popen"
    description = "Ruby pipe command execution"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    languages = _RUBY
    patterns = [
        (
            re.compile(r"\bIO\.popen\s*\("),
            "Ruby IO.popen detected: {match}",
            "Ensure IO.popen arguments are sanitized. Prefer argument arrays over strings.",
        ),
        (
            re.compile(r"\bOpen3\.\w+\s*\("),
            "Ruby Open3 usage detected: {match}",
            "Ensure Open3 commands use argument arrays, not shell strings.",
        ),
    ]


class RubyProcessSpawnRule(LanguageRegexRule):
    """SG-SHELL-034: Detect Process.spawn/spawn() in Ruby."""

    id = "SG-SHELL-034"
    name = "ruby_process_spawn"
    description = "Ruby process spawning"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    languages = _RUBY
    patterns = [
        (
            re.compile(r"\b(?:Process\.)?spawn\s*\("),
            "Ruby process spawn detected: {match}",
            "Ensure spawned process arguments are sanitized.",
        ),
    ]


class RubyHttpClientRule(LanguageRegexRule):
    """SG-NET-030: Detect HTTP client usage in Ruby."""

    id = "SG-NET-030"
    name = "ruby_http_client"
    description = "Ruby outbound HTTP request"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.NETWORK
    languages = _RUBY
    patterns = [
        (
            re.compile(r"\bNet::HTTP\b"),
            "Ruby Net::HTTP usage detected: {match}",
            "Verify outbound HTTP requests target allowed domains only.",
        ),
        (
            re.compile(r"\b(?:HTTParty|Faraday|RestClient)\b"),
            "Ruby HTTP library detected: {match}",
            "Verify outbound HTTP requests target allowed domains only.",
        ),
    ]


class RubySocketRule(LanguageRegexRule):
    """SG-NET-031: Detect raw socket usage in Ruby."""

    id = "SG-NET-031"
    name = "ruby_socket"
    description = "Ruby raw socket connection"
    severity = Severity.HIGH
    weight = 35
    category = Category.NETWORK
    languages = _RUBY
    patterns = [
        (
            re.compile(r"\b(?:TCPSocket|UDPSocket|Socket)\.(?:new|open)\s*\("),
            "Ruby socket usage detected: {match}",
            "Avoid raw socket connections. Use higher-level HTTP clients.",
        ),
    ]


class RubyFileWriteRule(LanguageRegexRule):
    """SG-FS-030: Detect file write operations in Ruby."""

    id = "SG-FS-030"
    name = "ruby_file_write"
    description = "Ruby file write operation"
    severity = Severity.MEDIUM
    weight = 15
    category = Category.FILESYSTEM
    languages = _RUBY
    patterns = [
        (
            re.compile(r"\bFile\.(write|open)\s*\("),
            "Ruby file operation detected: {match}",
            "Verify file writes target only expected paths within the skill bundle.",
        ),
    ]


class RubyFileDeleteRule(LanguageRegexRule):
    """SG-FS-031: Detect file deletion in Ruby."""

    id = "SG-FS-031"
    name = "ruby_file_delete"
    description = "Ruby file deletion"
    severity = Severity.HIGH
    weight = 40
    category = Category.FILESYSTEM
    languages = _RUBY
    patterns = [
        (
            re.compile(r"\b(?:FileUtils\.rm|FileUtils\.rm_rf|File\.delete)\s*\("),
            "Ruby file deletion detected: {match}",
            "Avoid deleting files outside the skill bundle directory.",
        ),
    ]


class RubyPathTraversalRule(LanguageRegexRule):
    """SG-FS-032: Detect path traversal in Ruby."""

    id = "SG-FS-032"
    name = "ruby_path_traversal"
    description = "Ruby path traversal attempt"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.FILESYSTEM
    languages = _RUBY
    patterns = [
        (
            re.compile(r"""(?:File|Dir|IO)\.\w+\s*\(\s*["'][^"']*\.\."""),
            "Ruby path traversal detected: {match}",
            "Never use '..' in file paths. Validate and expand all paths.",
        ),
    ]


class RubyEvalRule(LanguageRegexRule):
    """SG-EVAL-030: Detect eval/instance_eval/class_eval in Ruby."""

    id = "SG-EVAL-030"
    name = "ruby_eval"
    description = "Ruby dynamic code evaluation"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.EVAL
    languages = _RUBY
    patterns = [
        (
            re.compile(r"\b(?:instance_eval|class_eval|module_eval)\s*[\(\{]"),
            "Ruby dynamic eval detected: {match}",
            "Avoid eval/instance_eval/class_eval. Use safe alternatives.",
        ),
    ]


class RubySendRule(LanguageRegexRule):
    """SG-EVAL-031: Detect send/public_send dynamic dispatch in Ruby."""

    id = "SG-EVAL-031"
    name = "ruby_send"
    description = "Ruby dynamic method dispatch"
    severity = Severity.HIGH
    weight = 35
    category = Category.EVAL
    languages = _RUBY
    patterns = [
        (
            re.compile(r"\b(?:send|public_send)\s*\("),
            "Ruby dynamic dispatch detected: {match}",
            "Avoid send/public_send with user-controlled method names.",
        ),
    ]


class RubyConstGetRule(LanguageRegexRule):
    """SG-EVAL-032: Detect const_get() in Ruby."""

    id = "SG-EVAL-032"
    name = "ruby_const_get"
    description = "Ruby dynamic constant lookup"
    severity = Severity.HIGH
    weight = 35
    category = Category.EVAL
    languages = _RUBY
    patterns = [
        (
            re.compile(r"\bconst_get\s*\("),
            "Ruby const_get detected: {match}",
            "Avoid const_get with user-controlled input.",
        ),
    ]


class RubyEnvAccessRule(LanguageRegexRule):
    """SG-CRED-030: Detect ENV[] access in Ruby."""

    id = "SG-CRED-030"
    name = "ruby_env_access"
    description = "Ruby environment variable access"
    severity = Severity.MEDIUM
    weight = 20
    category = Category.CREDENTIAL
    languages = _RUBY
    patterns = [
        (
            re.compile(r"\bENV\["),
            "Ruby environment variable access detected: {match}",
            "Declare required environment variables in the skill manifest.",
        ),
    ]


class RubySqlInjectionRule(LanguageRegexRule):
    """SG-INJ-030: Detect SQL injection via string interpolation in Ruby."""

    id = "SG-INJ-030"
    name = "ruby_sql_injection"
    description = "SQL injection via string interpolation in Ruby"
    severity = Severity.HIGH
    weight = 35
    category = Category.INJECTION
    languages = _RUBY
    patterns = [
        (
            re.compile(r"""["'](?:SELECT|INSERT|UPDATE|DELETE|DROP)\b.*?#\{"""),
            "Possible SQL injection via string interpolation: {match}",
            "Use parameterized queries instead of string interpolation for SQL.",
        ),
    ]


RUBY_RULES: list[type[LanguageRegexRule]] = [
    RubySystemCallRule,
    RubyExecRule,
    RubyBacktickRule,
    RubyIoPopenRule,
    RubyProcessSpawnRule,
    RubyHttpClientRule,
    RubySocketRule,
    RubyFileWriteRule,
    RubyFileDeleteRule,
    RubyPathTraversalRule,
    RubyEvalRule,
    RubySendRule,
    RubyConstGetRule,
    RubyEnvAccessRule,
    RubySqlInjectionRule,
]
