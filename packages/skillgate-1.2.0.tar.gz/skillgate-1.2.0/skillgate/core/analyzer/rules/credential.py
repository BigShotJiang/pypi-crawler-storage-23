"""Credential access detection rules (SG-CRED-001 through SG-CRED-006)."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import RegexRule, Rule
from skillgate.core.models.bundle import SourceFile
from skillgate.core.models.enums import Category, Severity
from skillgate.core.models.finding import Finding


class EnvVariableRule(RegexRule):
    """SG-CRED-001: Detect environment variable access."""

    id = "SG-CRED-001"
    name = "env_variable"
    description = "Environment variable read detected"
    severity = Severity.MEDIUM
    weight = 20
    category = Category.CREDENTIAL
    patterns = [
        (
            re.compile(r"\bos\.(environ|getenv)\s*[\[\(]"),
            "Environment variable access detected: {match}",
            "Document which env vars the skill requires. Avoid reading sensitive env vars.",
        ),
        (
            re.compile(r"\bprocess\.env\b"),
            "Node.js environment variable access detected: {match}",
            "Document which environment variables the skill requires.",
        ),
    ]


class ApiKeyPatternRule(RegexRule):
    """SG-CRED-002: Detect hardcoded API keys/tokens."""

    id = "SG-CRED-002"
    name = "api_key_pattern"
    description = "Possible hardcoded API key or token"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.CREDENTIAL
    patterns = [
        (
            re.compile(
                r"""(?:api[_-]?key|token|secret|password|auth)\s*[=:]\s*['"][A-Za-z0-9_\-]{20,}['"]""",
                re.IGNORECASE,
            ),
            "Possible hardcoded credential detected: {match}",
            "Never hardcode credentials. Use environment variables or a secret manager.",
        ),
        (
            re.compile(r"""['"]sk[-_](?:live|test)[-_][A-Za-z0-9]{20,}['"]"""),
            "Possible Stripe key detected: {match}",
            "Never hardcode API keys. Use environment variables.",
        ),
        (
            re.compile(r"""['"]ghp_[A-Za-z0-9]{30,}['"]"""),
            "Possible GitHub token detected: {match}",
            "Never hardcode tokens. Use environment variables.",
        ),
    ]


class SshKeyReadRule(RegexRule):
    """SG-CRED-003: Detect SSH key file access."""

    id = "SG-CRED-003"
    name = "ssh_key_read"
    description = "SSH key access detected"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.CREDENTIAL
    patterns = [
        (
            re.compile(r"""~/.ssh/(id_rsa|id_ed25519|id_ecdsa|authorized_keys)"""),
            "SSH key file access detected: {match}",
            "Remove direct access to SSH keys. Use a credential manager.",
        ),
        (
            re.compile(r"""\.ssh[/\\](id_rsa|id_ed25519|id_ecdsa)"""),
            "SSH key file access detected: {match}",
            "Remove direct access to SSH keys. Use a credential manager.",
        ),
    ]


class AwsCredentialsRule(RegexRule):
    """SG-CRED-004: Detect AWS credential file access."""

    id = "SG-CRED-004"
    name = "aws_credentials"
    description = "AWS credential access detected"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.CREDENTIAL
    patterns = [
        (
            re.compile(r"""~/.aws/credentials"""),
            "AWS credential file access detected: {match}",
            "Use IAM roles or credential providers instead of direct file access.",
        ),
        (
            re.compile(r"""\bAWS_SECRET_ACCESS_KEY\b"""),
            "AWS secret key reference detected: {match}",
            "Use IAM roles. Never hardcode AWS credentials.",
        ),
    ]


class KeychainAccessRule(RegexRule):
    """SG-CRED-005: Detect OS keychain/keyring access."""

    id = "SG-CRED-005"
    name = "keychain_access"
    description = "OS keychain access detected"
    severity = Severity.HIGH
    weight = 40
    category = Category.CREDENTIAL
    patterns = [
        (
            re.compile(r"\b(keyring|keychain|SecKeychainFindGenericPassword)\b"),
            "Keychain/keyring access detected: {match}",
            "Avoid direct keychain access. Use explicit credential injection.",
        ),
    ]


class TokenExfilRule(Rule):
    """SG-CRED-006: Detect credential exfiltration pattern (env read + HTTP send)."""

    id = "SG-CRED-006"
    name = "token_exfil"
    description = "Credential exfiltration pattern detected"
    severity = Severity.CRITICAL
    weight = 60
    category = Category.CREDENTIAL

    _env_pattern = re.compile(r"\bos\.(environ|getenv)\s*[\[\(]|process\.env\b")
    _http_pattern = re.compile(
        r"\b(requests\.(post|get)|httpx\.(post|get)|fetch\s*\(|urllib\.request)\b"
    )

    def analyze(self, source: SourceFile) -> list[Finding]:
        """Detect combined env-read + HTTP-send in same file."""
        has_env_read = False
        has_http_send = False
        env_line = 0
        http_line = 0

        for line_num, line in enumerate(source.lines, start=1):
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith("//"):
                continue
            if not has_env_read and self._env_pattern.search(line):
                has_env_read = True
                env_line = line_num
            if not has_http_send and self._http_pattern.search(line):
                has_http_send = True
                http_line = line_num

        if has_env_read and has_http_send:
            return [
                self._make_finding(
                    source,
                    max(env_line, http_line),
                    f"Credential exfiltration pattern: env var read (line {env_line}) "
                    f"+ HTTP request (line {http_line}) in same file",
                    remediation="Separate credential access from network operations. "
                    "Use least-privilege access patterns.",
                )
            ]
        return []


CREDENTIAL_RULES: list[type[Rule]] = [
    EnvVariableRule,
    ApiKeyPatternRule,
    SshKeyReadRule,
    AwsCredentialsRule,
    KeychainAccessRule,
    TokenExfilRule,
]
