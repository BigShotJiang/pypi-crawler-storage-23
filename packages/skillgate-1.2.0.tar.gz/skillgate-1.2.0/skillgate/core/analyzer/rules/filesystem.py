"""File system detection rules (SG-FS-001 through SG-FS-006)."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import RegexRule
from skillgate.core.models.enums import Category, Severity


class FileWriteRule(RegexRule):
    """SG-FS-001: Detect file write operations."""

    id = "SG-FS-001"
    name = "file_write"
    description = "File write operation detected"
    severity = Severity.MEDIUM
    weight = 15
    category = Category.FILESYSTEM
    patterns = [
        (
            re.compile(r"""\bopen\s*\([^)]*['"][wax]"""),
            "File write operation detected: {match}",
            "Restrict file writes to the skill's output directory only.",
        ),
        (
            re.compile(r"\bPath\([^)]*\)\.(write_text|write_bytes)\s*\("),
            "File write via Path detected: {match}",
            "Restrict file writes to the skill's output directory only.",
        ),
    ]


class PathTraversalRule(RegexRule):
    """SG-FS-002: Detect path traversal attempts."""

    id = "SG-FS-002"
    name = "path_traversal"
    description = "Path traversal attempt detected"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.FILESYSTEM
    patterns = [
        (
            re.compile(r"""(?:['"]|/)\.\./"""),
            "Path traversal attempt detected: {match}",
            "Never use relative path traversal (../). "
            "Resolve paths and validate they stay within the bundle.",
        ),
        (
            re.compile(r"""\bos\.path\.join\s*\([^)]*\.\."""),
            "Path traversal via os.path.join detected: {match}",
            "Validate joined paths stay within the bundle directory.",
        ),
    ]


class SensitiveReadRule(RegexRule):
    """SG-FS-003: Detect reads from sensitive system directories."""

    id = "SG-FS-003"
    name = "sensitive_read"
    description = "Sensitive file access detected"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.FILESYSTEM
    patterns = [
        (
            re.compile(r"""~/.ssh/"""),
            "SSH directory access detected: {match}",
            "Remove direct access to ~/.ssh/. Use a credential manager instead.",
        ),
        (
            re.compile(r"""~/.aws/"""),
            "AWS credential directory access detected: {match}",
            "Remove direct access to ~/.aws/. Use IAM roles or credential providers.",
        ),
        (
            re.compile(r"""~/.config/"""),
            "Config directory access detected: {match}",
            "Restrict file reads to the skill's own directory.",
        ),
        (
            re.compile(r"""/etc/passwd"""),
            "System file access detected: {match}",
            "Skills should not access system files like /etc/passwd.",
        ),
        (
            re.compile(r"""/etc/shadow"""),
            "System file access detected: {match}",
            "Skills should not access system files like /etc/shadow.",
        ),
    ]


class TmpExecutionRule(RegexRule):
    """SG-FS-004: Detect write-to-tmp-then-execute pattern."""

    id = "SG-FS-004"
    name = "tmp_execution"
    description = "Staged execution pattern: write to /tmp then execute"
    severity = Severity.HIGH
    weight = 40
    category = Category.FILESYSTEM
    patterns = [
        (
            re.compile(r"""/tmp/[^'"\s]*\.(sh|py|js|bin|exe)"""),
            "Suspicious temp file with executable extension detected: {match}",
            "Avoid writing executable files to /tmp. This is a common staged execution pattern.",
        ),
        (
            re.compile(r"""\bos\.chmod\s*\([^)]*0o?7"""),
            "Setting executable permissions detected: {match}",
            "Avoid setting executable permissions on files. Review what is being made executable.",
        ),
    ]


class GlobExpansionRule(RegexRule):
    """SG-FS-005: Detect recursive glob of system directories."""

    id = "SG-FS-005"
    name = "glob_expansion"
    description = "Suspicious directory enumeration detected"
    severity = Severity.MEDIUM
    weight = 20
    category = Category.FILESYSTEM
    patterns = [
        (
            re.compile(r"""\bglob\.glob\s*\(\s*['"]/(usr|etc|home|root|var)"""),
            "System directory enumeration detected: {match}",
            "Restrict glob operations to the skill's own directory.",
        ),
        (
            re.compile(r"""\bPath\s*\(\s*['"]/(usr|etc|home|root|var)"""),
            "System directory access via Path detected: {match}",
            "Restrict Path operations to the skill's own directory.",
        ),
    ]


class SymlinkCreationRule(RegexRule):
    """SG-FS-006: Detect symbolic link creation."""

    id = "SG-FS-006"
    name = "symlink_creation"
    description = "Symbolic link creation detected"
    severity = Severity.MEDIUM
    weight = 20
    category = Category.FILESYSTEM
    patterns = [
        (
            re.compile(r"\bos\.symlink\s*\("),
            "Symbolic link creation detected: {match}",
            "Avoid creating symlinks. They can be used to bypass path restrictions.",
        ),
    ]


FILESYSTEM_RULES: list[type[RegexRule]] = [
    FileWriteRule,
    PathTraversalRule,
    SensitiveReadRule,
    TmpExecutionRule,
    GlobExpansionRule,
    SymlinkCreationRule,
]
