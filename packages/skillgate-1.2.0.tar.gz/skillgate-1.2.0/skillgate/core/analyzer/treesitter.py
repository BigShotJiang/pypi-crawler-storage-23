"""Optional tree-sitter integration for AST-based analysis.

This module provides graceful degradation: if tree-sitter and language
grammars are not installed, all functions return safe defaults.
Install with: pip install skillgate[ast]
"""

from __future__ import annotations

import logging
from typing import Any

from skillgate.core.models.enums import Language

logger = logging.getLogger(__name__)

# Lazy-loaded tree-sitter modules
_ts_module: Any = None
_parsers: dict[Language, Any] = {}
_ts_languages: dict[Language, Any] = {}

# Map Language enum to tree-sitter grammar module name
_GRAMMAR_MAP: dict[Language, str] = {
    Language.PYTHON: "tree_sitter_python",
    Language.JAVASCRIPT: "tree_sitter_javascript",
    Language.TYPESCRIPT: "tree_sitter_typescript",
    Language.GO: "tree_sitter_go",
    Language.RUST: "tree_sitter_rust",
    Language.RUBY: "tree_sitter_ruby",
    Language.SHELL: "tree_sitter_bash",
}


def _get_ts() -> Any:
    """Lazy-load tree_sitter module."""
    global _ts_module  # noqa: PLW0603
    if _ts_module is None:
        try:
            import tree_sitter

            _ts_module = tree_sitter
        except ImportError:
            _ts_module = False
    return _ts_module if _ts_module is not False else None


def is_available(language: Language) -> bool:
    """Check if tree-sitter is available for a given language.

    Returns:
        True if tree-sitter and the language grammar are installed.
    """
    ts = _get_ts()
    if ts is None:
        return False
    grammar_name = _GRAMMAR_MAP.get(language)
    if grammar_name is None:
        return False
    try:
        __import__(grammar_name)
        return True
    except ImportError:
        return False


def _get_parser(language: Language) -> Any:
    """Get or create a tree-sitter parser for a language."""
    if language in _parsers:
        return _parsers[language]

    ts = _get_ts()
    if ts is None:
        return None

    grammar_name = _GRAMMAR_MAP.get(language)
    if grammar_name is None:
        return None

    try:
        grammar_mod = __import__(grammar_name)
        lang = ts.Language(grammar_mod.language())
        parser = ts.Parser(lang)
        _parsers[language] = parser
        _ts_languages[language] = lang
        return parser
    except (ImportError, AttributeError, TypeError):
        logger.debug("tree-sitter grammar not available for %s", language)
        return None


def parse(language: Language, source: str) -> Any:
    """Parse source code into a tree-sitter tree.

    Args:
        language: The programming language.
        source: Source code string.

    Returns:
        tree-sitter Tree object, or None if unavailable.
    """
    parser = _get_parser(language)
    if parser is None:
        return None
    return parser.parse(source.encode("utf-8"))


def run_query(
    language: Language,
    source: str,
    query_str: str,
) -> list[tuple[int, int, str]]:
    """Run a tree-sitter S-expression query on source code.

    Args:
        language: The programming language.
        source: Source code string.
        query_str: S-expression query string.

    Returns:
        List of (line_number, column, matched_text) tuples.
        Line numbers are 1-based. Returns empty list if tree-sitter unavailable.
    """
    ts = _get_ts()
    if ts is None:
        return []

    tree = parse(language, source)
    if tree is None:
        return []

    lang = _ts_languages.get(language)
    if lang is None:
        return []

    try:
        query = lang.query(query_str)
        source_bytes = source.encode("utf-8")
        captures = query.captures(tree.root_node)
        results: list[tuple[int, int, str]] = []

        # captures is dict[str, list[Node]] in tree-sitter 0.23+
        if isinstance(captures, dict):
            for nodes in captures.values():
                for node in nodes:
                    text = source_bytes[node.start_byte : node.end_byte].decode("utf-8")
                    results.append((node.start_point[0] + 1, node.start_point[1] + 1, text))
        else:
            # Older tree-sitter: list of (node, capture_name)
            for node, _name in captures:
                text = source_bytes[node.start_byte : node.end_byte].decode("utf-8")
                results.append((node.start_point[0] + 1, node.start_point[1] + 1, text))

        return results
    except Exception:
        logger.debug("tree-sitter query failed for %s", language, exc_info=True)
        return []
