"""SkillGate exception hierarchy."""


class SkillGateError(Exception):
    """Base exception for all SkillGate errors."""


class ParseError(SkillGateError):
    """Failed to parse skill bundle or manifest."""


class AnalysisError(SkillGateError):
    """Failed during analysis phase."""


class PolicyError(SkillGateError):
    """Invalid policy configuration."""


class SigningError(SkillGateError):
    """Failed to sign or verify report."""


class ConfigError(SkillGateError):
    """Invalid configuration."""


class EntitlementError(SkillGateError):
    """Tier entitlement violation or quota exceeded."""

    def __init__(
        self,
        message: str,
        *,
        tier: str | None = None,
        capability: str | None = None,
    ) -> None:
        super().__init__(message)
        self.tier = tier
        self.capability = capability
