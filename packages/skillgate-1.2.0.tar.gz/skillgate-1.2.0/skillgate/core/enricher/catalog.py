"""Static threat intelligence catalog for all detection rules.

Each rule gets a frozen metadata entry with confidence, tags, risk factors,
MITRE ATT&CK technique IDs, and first-seen date. Confidence is derived from
severity: CRITICAL=0.90-0.95, HIGH=0.85-0.90, MEDIUM=0.70-0.80, LOW=0.50-0.60.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RuleEnrichmentMeta:
    """Immutable enrichment metadata for a single rule."""

    confidence: float
    first_seen: str
    tags: tuple[str, ...]
    risk_factors: tuple[str, ...]
    mitre_attack: tuple[str, ...]


# ---------------------------------------------------------------------------
# MITRE ATT&CK shorthand constants
# ---------------------------------------------------------------------------
_T1059 = "T1059"  # Command and Scripting Interpreter
_T1059_004 = "T1059.004"  # Unix Shell
_T1059_006 = "T1059.006"  # Python
_T1059_007 = "T1059.007"  # JavaScript
_T1071_001 = "T1071.001"  # Application Layer Protocol: Web
_T1048 = "T1048"  # Exfiltration Over Alternative Protocol
_T1083 = "T1083"  # File and Directory Discovery
_T1005 = "T1005"  # Data from Local System
_T1070_004 = "T1070.004"  # Indicator Removal: File Deletion
_T1552_001 = "T1552.001"  # Credentials In Files
_T1552 = "T1552"  # Unsecured Credentials
_T1190 = "T1190"  # Exploit Public-Facing Application
_T1055 = "T1055"  # Process Injection
_T1027 = "T1027"  # Obfuscated Files or Information
_T1027_010 = "T1027.010"  # Command Obfuscation
_T1140 = "T1140"  # Deobfuscate/Decode Files or Information

# ---------------------------------------------------------------------------
# Category-level default MITRE mappings
# ---------------------------------------------------------------------------
_SHELL_MITRE = (_T1059, _T1059_004)
_NET_MITRE = (_T1071_001,)
_FS_MITRE = (_T1083, _T1005)
_EVAL_MITRE = (_T1059, _T1027_010)
_CRED_MITRE = (_T1552_001, _T1552)
_INJ_MITRE = (_T1190, _T1055)
_OBF_MITRE = (_T1027, _T1140)

# ---------------------------------------------------------------------------
# Full enrichment catalog — 89 rules
# ---------------------------------------------------------------------------
ENRICHMENT_CATALOG: dict[str, RuleEnrichmentMeta] = {
    # ===== SHELL RULES =====
    "SG-SHELL-001": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2024-01-15",
        tags=("command-execution", "subprocess"),
        risk_factors=("Direct subprocess execution can run arbitrary commands",),
        mitre_attack=(_T1059, _T1059_004, _T1059_006),
    ),
    "SG-SHELL-002": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2024-01-15",
        tags=("command-execution", "os-system"),
        risk_factors=("os.system() passes commands through the shell",),
        mitre_attack=(_T1059, _T1059_004, _T1059_006),
    ),
    "SG-SHELL-003": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2024-01-15",
        tags=("command-execution", "os-popen"),
        risk_factors=("os.popen() opens a pipe to a shell command",),
        mitre_attack=(_T1059, _T1059_004, _T1059_006),
    ),
    "SG-SHELL-004": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-01-15",
        tags=("command-execution", "shell-injection"),
        risk_factors=("shell=True enables shell injection via unsanitized input",),
        mitre_attack=(_T1059, _T1059_004),
    ),
    "SG-SHELL-005": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-01-15",
        tags=("command-execution", "backtick"),
        risk_factors=("Backtick execution runs arbitrary shell commands",),
        mitre_attack=_SHELL_MITRE,
    ),
    "SG-SHELL-006": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2024-01-15",
        tags=("command-execution", "node-child-process"),
        risk_factors=("Node child process module enables arbitrary command execution",),
        mitre_attack=(_T1059, _T1059_007),
    ),
    "SG-SHELL-007": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-01-15",
        tags=("file-operations", "shutil"),
        risk_factors=("shutil operations can move/copy/delete files at scale",),
        mitre_attack=(_T1083, _T1005, _T1070_004),
    ),
    "SG-SHELL-008": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2026-02-18",
        tags=("command-execution", "os-system", "alias"),
        risk_factors=("Aliased os.system calls can evade direct detector patterns",),
        mitre_attack=(_T1059, _T1059_004, _T1059_006),
    ),
    "SG-SHELL-010": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("command-execution", "go-exec"),
        risk_factors=("exec.Command runs external processes",),
        mitre_attack=(_T1059, _T1059_004),
    ),
    "SG-SHELL-011": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("command-execution", "go-exec"),
        risk_factors=("exec.Command().Output() captures command output",),
        mitre_attack=(_T1059, _T1059_004),
    ),
    "SG-SHELL-020": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("command-execution", "rust-command"),
        risk_factors=("std::process::Command spawns external processes",),
        mitre_attack=(_T1059, _T1059_004),
    ),
    "SG-SHELL-021": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("command-execution", "rust-command"),
        risk_factors=("Command::output() executes and captures process output",),
        mitre_attack=(_T1059, _T1059_004),
    ),
    "SG-SHELL-030": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("command-execution", "ruby-system"),
        risk_factors=("system() invokes shell commands in Ruby",),
        mitre_attack=_SHELL_MITRE,
    ),
    "SG-SHELL-031": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("command-execution", "ruby-exec"),
        risk_factors=("exec() replaces the current process with a shell command",),
        mitre_attack=_SHELL_MITRE,
    ),
    "SG-SHELL-032": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("command-execution", "ruby-backtick"),
        risk_factors=("Backtick execution runs shell commands in Ruby",),
        mitre_attack=_SHELL_MITRE,
    ),
    "SG-SHELL-033": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("command-execution", "ruby-popen"),
        risk_factors=("IO.popen opens a pipe to a shell command",),
        mitre_attack=_SHELL_MITRE,
    ),
    "SG-SHELL-034": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("command-execution", "ruby-spawn"),
        risk_factors=("Process.spawn executes external programs",),
        mitre_attack=_SHELL_MITRE,
    ),
    "SG-SHELL-040": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-04-01",
        tags=("command-execution", "js-child-process-ast"),
        risk_factors=("AST-detected child process invocation for command execution",),
        mitre_attack=(_T1059, _T1059_007),
    ),
    "SG-SHELL-050": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2024-04-01",
        tags=("command-execution", "privilege-escalation"),
        risk_factors=("sudo usage indicates privilege escalation intent",),
        mitre_attack=(_T1059, _T1059_004),
    ),
    # ===== NETWORK RULES =====
    "SG-NET-001": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-01-15",
        tags=("network-access", "http-request"),
        risk_factors=("HTTP requests can exfiltrate data or fetch payloads",),
        mitre_attack=(_T1071_001, _T1048),
    ),
    "SG-NET-002": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-01-15",
        tags=("network-access", "raw-socket"),
        risk_factors=("Raw socket connections bypass HTTP-level controls",),
        mitre_attack=(_T1071_001, _T1048),
    ),
    "SG-NET-003": RuleEnrichmentMeta(
        confidence=0.55,
        first_seen="2024-01-15",
        tags=("network-access", "dns-lookup"),
        risk_factors=("DNS lookups may indicate reconnaissance or C2 comms",),
        mitre_attack=(_T1071_001,),
    ),
    "SG-NET-004": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-01-15",
        tags=("network-access", "webhook", "data-exfiltration"),
        risk_factors=("Webhook POST can exfiltrate sensitive data",),
        mitre_attack=(_T1071_001, _T1048),
    ),
    "SG-NET-005": RuleEnrichmentMeta(
        confidence=0.70,
        first_seen="2024-01-15",
        tags=("network-access", "hardcoded-ip"),
        risk_factors=("Hardcoded IPs may indicate C2 infrastructure",),
        mitre_attack=(_T1071_001,),
    ),
    "SG-NET-006": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-01-15",
        tags=("network-access", "ftp"),
        risk_factors=("FTP connections can transfer files without encryption",),
        mitre_attack=(_T1071_001, _T1048),
    ),
    "SG-NET-010": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-03-01",
        tags=("network-access", "go-http"),
        risk_factors=("Go HTTP client can make arbitrary network requests",),
        mitre_attack=(_T1071_001, _T1048),
    ),
    "SG-NET-011": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("network-access", "go-socket"),
        risk_factors=("net.Dial creates raw network connections",),
        mitre_attack=(_T1071_001, _T1048),
    ),
    "SG-NET-012": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-03-01",
        tags=("network-access", "go-server"),
        risk_factors=("HTTP server can expose an attack surface",),
        mitre_attack=(_T1071_001,),
    ),
    "SG-NET-020": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-03-01",
        tags=("network-access", "rust-http"),
        risk_factors=("Rust HTTP client can make arbitrary network requests",),
        mitre_attack=(_T1071_001, _T1048),
    ),
    "SG-NET-021": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("network-access", "rust-socket"),
        risk_factors=("TcpStream::connect creates raw TCP connections",),
        mitre_attack=(_T1071_001, _T1048),
    ),
    "SG-NET-022": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-03-01",
        tags=("network-access", "rust-server"),
        risk_factors=("TCP listener exposes a network service",),
        mitre_attack=(_T1071_001,),
    ),
    "SG-NET-030": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-03-01",
        tags=("network-access", "ruby-http"),
        risk_factors=("Ruby HTTP client can make arbitrary network requests",),
        mitre_attack=(_T1071_001, _T1048),
    ),
    "SG-NET-031": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("network-access", "ruby-socket"),
        risk_factors=("Ruby socket connections bypass HTTP controls",),
        mitre_attack=(_T1071_001, _T1048),
    ),
    "SG-NET-040": RuleEnrichmentMeta(
        confidence=0.70,
        first_seen="2024-04-01",
        tags=("network-access", "js-fetch"),
        risk_factors=("fetch() API can exfiltrate data or load remote code",),
        mitre_attack=(_T1071_001, _T1048),
    ),
    "SG-NET-050": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-04-01",
        tags=("network-access", "shell-curl"),
        risk_factors=("curl/wget can download and execute remote payloads",),
        mitre_attack=(_T1071_001, _T1048),
    ),
    # ===== FILESYSTEM RULES =====
    "SG-FS-001": RuleEnrichmentMeta(
        confidence=0.72,
        first_seen="2024-01-15",
        tags=("file-operations", "file-write"),
        risk_factors=("File writes can modify system or application state",),
        mitre_attack=(_T1005, _T1083),
    ),
    "SG-FS-002": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-01-15",
        tags=("file-operations", "path-traversal"),
        risk_factors=("Path traversal can read or write arbitrary files",),
        mitre_attack=(_T1083, _T1005),
    ),
    "SG-FS-003": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-01-15",
        tags=("file-operations", "sensitive-file-read"),
        risk_factors=("Reading /etc/passwd, /etc/shadow, or SSH keys",),
        mitre_attack=(_T1005, _T1552_001),
    ),
    "SG-FS-004": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2024-01-15",
        tags=("file-operations", "tmp-execution"),
        risk_factors=("Writing executables to /tmp is a common staging technique",),
        mitre_attack=(_T1005, _T1083),
    ),
    "SG-FS-005": RuleEnrichmentMeta(
        confidence=0.72,
        first_seen="2024-01-15",
        tags=("file-operations", "glob-expansion"),
        risk_factors=("Glob expansion can match unintended files",),
        mitre_attack=(_T1083,),
    ),
    "SG-FS-006": RuleEnrichmentMeta(
        confidence=0.72,
        first_seen="2024-01-15",
        tags=("file-operations", "symlink"),
        risk_factors=("Symlinks can redirect file operations to arbitrary paths",),
        mitre_attack=(_T1083,),
    ),
    "SG-FS-010": RuleEnrichmentMeta(
        confidence=0.72,
        first_seen="2024-03-01",
        tags=("file-operations", "go-file-write"),
        risk_factors=("Go file write operations can modify system state",),
        mitre_attack=(_T1005, _T1083),
    ),
    "SG-FS-011": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("file-operations", "go-file-delete"),
        risk_factors=("File deletion can destroy evidence or data",),
        mitre_attack=(_T1070_004, _T1083),
    ),
    "SG-FS-012": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-03-01",
        tags=("file-operations", "go-path-traversal"),
        risk_factors=("Path traversal in Go can access arbitrary files",),
        mitre_attack=(_T1083, _T1005),
    ),
    "SG-FS-020": RuleEnrichmentMeta(
        confidence=0.72,
        first_seen="2024-03-01",
        tags=("file-operations", "rust-file-write"),
        risk_factors=("Rust file write operations can modify system state",),
        mitre_attack=(_T1005, _T1083),
    ),
    "SG-FS-021": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("file-operations", "rust-file-delete"),
        risk_factors=("File deletion can destroy evidence or data",),
        mitre_attack=(_T1070_004, _T1083),
    ),
    "SG-FS-022": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-03-01",
        tags=("file-operations", "rust-path-traversal"),
        risk_factors=("Path traversal in Rust can access arbitrary files",),
        mitre_attack=(_T1083, _T1005),
    ),
    "SG-FS-030": RuleEnrichmentMeta(
        confidence=0.72,
        first_seen="2024-03-01",
        tags=("file-operations", "ruby-file-write"),
        risk_factors=("Ruby file write operations can modify system state",),
        mitre_attack=(_T1005, _T1083),
    ),
    "SG-FS-031": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("file-operations", "ruby-file-delete"),
        risk_factors=("File deletion can destroy evidence or data",),
        mitre_attack=(_T1070_004, _T1083),
    ),
    "SG-FS-032": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-03-01",
        tags=("file-operations", "ruby-path-traversal"),
        risk_factors=("Path traversal in Ruby can access arbitrary files",),
        mitre_attack=(_T1083, _T1005),
    ),
    "SG-FS-040": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-04-01",
        tags=("file-operations", "js-fs"),
        risk_factors=("Node.js fs module can read/write arbitrary files",),
        mitre_attack=(_T1005, _T1083),
    ),
    "SG-FS-050": RuleEnrichmentMeta(
        confidence=0.72,
        first_seen="2024-04-01",
        tags=("file-operations", "shell-chmod"),
        risk_factors=("chmod can set executable permissions on files",),
        mitre_attack=(_T1083,),
    ),
    "SG-FS-051": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2024-04-01",
        tags=("file-operations", "shell-rm"),
        risk_factors=("rm command can delete files and directories",),
        mitre_attack=(_T1070_004, _T1083),
    ),
    # ===== EVAL RULES =====
    "SG-EVAL-001": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-01-15",
        tags=("code-execution", "python-eval"),
        risk_factors=("eval() executes arbitrary Python expressions",),
        mitre_attack=(_T1059, _T1059_006),
    ),
    "SG-EVAL-002": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-01-15",
        tags=("code-execution", "python-exec"),
        risk_factors=("exec() executes arbitrary Python code blocks",),
        mitre_attack=(_T1059, _T1059_006),
    ),
    "SG-EVAL-003": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-01-15",
        tags=("code-execution", "js-eval"),
        risk_factors=("eval() executes arbitrary JavaScript code",),
        mitre_attack=(_T1059, _T1059_007),
    ),
    "SG-EVAL-004": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-01-15",
        tags=("code-execution", "js-function-constructor"),
        risk_factors=("Function() constructor creates code from strings",),
        mitre_attack=(_T1059, _T1059_007),
    ),
    "SG-EVAL-005": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2024-01-15",
        tags=("code-execution", "compile"),
        risk_factors=("compile() can prepare code for dynamic execution",),
        mitre_attack=_EVAL_MITRE,
    ),
    "SG-EVAL-006": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-01-15",
        tags=("code-execution", "dynamic-import"),
        risk_factors=("importlib enables dynamic module loading at runtime",),
        mitre_attack=_EVAL_MITRE,
    ),
    "SG-EVAL-010": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2024-03-01",
        tags=("code-execution", "go-reflect"),
        risk_factors=("reflect.Call enables dynamic method invocation",),
        mitre_attack=_EVAL_MITRE,
    ),
    "SG-EVAL-011": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2024-03-01",
        tags=("code-execution", "go-plugin"),
        risk_factors=("plugin.Open loads shared objects at runtime",),
        mitre_attack=_EVAL_MITRE,
    ),
    "SG-EVAL-020": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2024-03-01",
        tags=("code-execution", "rust-unsafe"),
        risk_factors=("unsafe blocks can bypass memory safety guarantees",),
        mitre_attack=_EVAL_MITRE,
    ),
    "SG-EVAL-021": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2024-03-01",
        tags=("code-execution", "rust-dynamic-load"),
        risk_factors=("Dynamic library loading can execute arbitrary code",),
        mitre_attack=_EVAL_MITRE,
    ),
    "SG-EVAL-030": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-03-01",
        tags=("code-execution", "ruby-eval"),
        risk_factors=("eval() executes arbitrary Ruby code",),
        mitre_attack=(_T1059,),
    ),
    "SG-EVAL-031": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2024-03-01",
        tags=("code-execution", "ruby-send"),
        risk_factors=("send() enables dynamic method dispatch",),
        mitre_attack=(_T1059,),
    ),
    "SG-EVAL-032": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2024-03-01",
        tags=("code-execution", "ruby-const-get"),
        risk_factors=("const_get enables dynamic constant resolution",),
        mitre_attack=(_T1059,),
    ),
    "SG-EVAL-040": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-04-01",
        tags=("code-execution", "js-eval-ast"),
        risk_factors=("eval() detected via AST analysis in JavaScript",),
        mitre_attack=(_T1059, _T1059_007),
    ),
    "SG-EVAL-041": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-04-01",
        tags=("code-execution", "js-new-function-ast"),
        risk_factors=("new Function() detected via AST analysis",),
        mitre_attack=(_T1059, _T1059_007),
    ),
    "SG-EVAL-050": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-04-01",
        tags=("code-execution", "shell-eval"),
        risk_factors=("Shell eval executes arbitrary commands",),
        mitre_attack=(_T1059, _T1059_004),
    ),
    # ===== CREDENTIAL RULES =====
    "SG-CRED-001": RuleEnrichmentMeta(
        confidence=0.72,
        first_seen="2024-01-15",
        tags=("credential-access", "env-variable"),
        risk_factors=("Environment variable access may read secrets",),
        mitre_attack=_CRED_MITRE,
    ),
    "SG-CRED-002": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-01-15",
        tags=("credential-access", "api-key-pattern"),
        risk_factors=("Hardcoded API key patterns indicate credential exposure",),
        mitre_attack=_CRED_MITRE,
    ),
    "SG-CRED-003": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-01-15",
        tags=("credential-access", "ssh-key-read"),
        risk_factors=("Reading SSH private keys enables remote access",),
        mitre_attack=(_T1552_001,),
    ),
    "SG-CRED-004": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-01-15",
        tags=("credential-access", "aws-credentials"),
        risk_factors=("AWS credential access can compromise cloud infrastructure",),
        mitre_attack=(_T1552_001,),
    ),
    "SG-CRED-005": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2024-01-15",
        tags=("credential-access", "keychain"),
        risk_factors=("Keychain access can expose stored credentials",),
        mitre_attack=(_T1552_001, _T1552),
    ),
    "SG-CRED-006": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-01-15",
        tags=("credential-access", "token-exfiltration"),
        risk_factors=("Token exfiltration sends credentials to external servers",),
        mitre_attack=(_T1552, _T1048),
    ),
    "SG-CRED-010": RuleEnrichmentMeta(
        confidence=0.72,
        first_seen="2024-03-01",
        tags=("credential-access", "go-env"),
        risk_factors=("Go os.Getenv may read secrets from environment",),
        mitre_attack=_CRED_MITRE,
    ),
    "SG-CRED-011": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-03-01",
        tags=("credential-access", "go-hardcoded-key"),
        risk_factors=("Hardcoded keys in Go source code",),
        mitre_attack=_CRED_MITRE,
    ),
    "SG-CRED-020": RuleEnrichmentMeta(
        confidence=0.72,
        first_seen="2024-03-01",
        tags=("credential-access", "rust-env"),
        risk_factors=("Rust std::env may read secrets from environment",),
        mitre_attack=_CRED_MITRE,
    ),
    "SG-CRED-021": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-03-01",
        tags=("credential-access", "rust-hardcoded-key"),
        risk_factors=("Hardcoded keys in Rust source code",),
        mitre_attack=_CRED_MITRE,
    ),
    "SG-CRED-030": RuleEnrichmentMeta(
        confidence=0.72,
        first_seen="2024-03-01",
        tags=("credential-access", "ruby-env"),
        risk_factors=("Ruby ENV access may read secrets",),
        mitre_attack=_CRED_MITRE,
    ),
    # ===== INJECTION RULES =====
    "SG-INJ-001": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2024-01-15",
        tags=("injection", "prompt-override"),
        risk_factors=("Prompt injection can override AI agent instructions",),
        mitre_attack=(_T1190,),
    ),
    "SG-INJ-002": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2024-01-15",
        tags=("injection", "command-injection"),
        risk_factors=("Command injection executes arbitrary OS commands",),
        mitre_attack=(_T1190, _T1055),
    ),
    "SG-INJ-003": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-01-15",
        tags=("injection", "sql-injection"),
        risk_factors=("SQL injection can read, modify, or delete database data",),
        mitre_attack=(_T1190,),
    ),
    "SG-INJ-004": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-01-15",
        tags=("injection", "template-injection"),
        risk_factors=("Template injection can execute arbitrary code via templates",),
        mitre_attack=(_T1190, _T1055),
    ),
    "SG-INJ-010": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("injection", "go-sql-injection"),
        risk_factors=("SQL injection via string formatting in Go",),
        mitre_attack=(_T1190,),
    ),
    "SG-INJ-020": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("injection", "rust-sql-injection"),
        risk_factors=("SQL injection via string formatting in Rust",),
        mitre_attack=(_T1190,),
    ),
    "SG-INJ-030": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-03-01",
        tags=("injection", "ruby-sql-injection"),
        risk_factors=("SQL injection via string interpolation in Ruby",),
        mitre_attack=(_T1190,),
    ),
    # ===== OBFUSCATION RULES =====
    "SG-OBF-001": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-01-15",
        tags=("obfuscation", "base64-payload"),
        risk_factors=("Base64-encoded payloads hide malicious content",),
        mitre_attack=(_T1027, _T1140),
    ),
    "SG-OBF-002": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2024-01-15",
        tags=("obfuscation", "char-code-concatenation"),
        risk_factors=("Character code concatenation hides strings from static analysis",),
        mitre_attack=(_T1027, _T1027_010),
    ),
    "SG-OBF-003": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-01-15",
        tags=("obfuscation", "hex-encoding"),
        risk_factors=("Hex-encoded strings can hide malicious payloads",),
        mitre_attack=(_T1027, _T1140),
    ),
    "SG-OBF-004": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2024-01-15",
        tags=("obfuscation", "string-reversal"),
        risk_factors=("String reversal techniques evade pattern matching",),
        mitre_attack=(_T1027, _T1027_010),
    ),
    "SG-OBF-005": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2024-01-15",
        tags=("obfuscation", "minified-payload"),
        risk_factors=("Minified code can obscure malicious intent",),
        mitre_attack=(_T1027,),
    ),
    # ===== PROMPT INJECTION RULES =====
    "SG-PROMPT-001": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2025-06-01",
        tags=("prompt-injection", "jailbreak", "dan"),
        risk_factors=("DAN jailbreak bypasses LLM safety restrictions",),
        mitre_attack=(_T1190,),
    ),
    "SG-PROMPT-002": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2025-06-01",
        tags=("prompt-injection", "instruction-override"),
        risk_factors=("Instruction override can redirect agent behavior",),
        mitre_attack=(_T1190,),
    ),
    "SG-PROMPT-003": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2025-06-01",
        tags=("prompt-injection", "system-override", "privilege-escalation"),
        risk_factors=("System prompt override grants unauthorized capabilities",),
        mitre_attack=(_T1190, _T1055),
    ),
    "SG-PROMPT-004": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2025-06-01",
        tags=("prompt-injection", "jailbreak", "roleplay"),
        risk_factors=("Unrestricted roleplay bypasses content policies",),
        mitre_attack=(_T1190,),
    ),
    "SG-PROMPT-005": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2025-06-01",
        tags=("prompt-injection", "data-exfiltration", "token-leakage"),
        risk_factors=("Token leakage exposes internal system prompts",),
        mitre_attack=(_T1190, _T1048),
    ),
    "SG-PROMPT-006": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2025-06-01",
        tags=("prompt-injection", "guardrail-bypass", "safety"),
        risk_factors=("Guardrail bypass disables safety controls",),
        mitre_attack=(_T1190,),
    ),
    "SG-PROMPT-007": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2025-06-01",
        tags=("prompt-injection", "command-injection", "embedded-command"),
        risk_factors=("Embedded commands can execute OS-level operations",),
        mitre_attack=(_T1190, _T1059),
    ),
    "SG-PROMPT-008": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2025-06-01",
        tags=("prompt-injection", "obfuscation", "encoding"),
        risk_factors=("Encoded jailbreaks evade string-matching defenses",),
        mitre_attack=(_T1027, _T1140),
    ),
    # ===== COMMAND CHAIN RULES =====
    "SG-CMD-001": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2025-06-01",
        tags=("command-chain", "download-execute", "curl"),
        risk_factors=("curl|bash downloads and executes remote code",),
        mitre_attack=(_T1059, _T1059_004, _T1071_001),
    ),
    "SG-CMD-002": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2025-06-01",
        tags=("command-chain", "download-execute", "wget"),
        risk_factors=("wget|sh downloads and executes remote code",),
        mitre_attack=(_T1059, _T1059_004, _T1071_001),
    ),
    "SG-CMD-003": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2025-06-01",
        tags=("command-chain", "code-execution", "python-inline"),
        risk_factors=("python -c with exec/system runs arbitrary code",),
        mitre_attack=(_T1059, _T1059_006),
    ),
    "SG-CMD-004": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2025-06-01",
        tags=("command-chain", "download-execute", "powershell"),
        risk_factors=("PowerShell download+execute is a common malware vector",),
        mitre_attack=(_T1059, _T1071_001),
    ),
    "SG-CMD-005": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2025-06-01",
        tags=("command-chain", "obfuscation", "base64"),
        risk_factors=("Base64 decode piped to shell executes hidden commands",),
        mitre_attack=(_T1027, _T1140, _T1059_004),
    ),
    "SG-CMD-006": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2025-06-01",
        tags=("command-chain", "destructive", "disk-wipe"),
        risk_factors=("Chained rm/dd/mkfs destroys disk data",),
        mitre_attack=(_T1070_004, _T1059_004),
    ),
    "SG-CMD-007": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2025-06-01",
        tags=("command-chain", "privilege-escalation", "sudo"),
        risk_factors=("sudo -S / NOPASSWD enables password-free privilege escalation",),
        mitre_attack=(_T1059_004,),
    ),
    "SG-CMD-008": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2025-06-01",
        tags=("command-chain", "anti-forensics", "history"),
        risk_factors=("Disabling shell history removes audit trail",),
        mitre_attack=(_T1070_004,),
    ),
    "SG-CMD-009": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2025-06-01",
        tags=("command-chain", "code-execution", "eval"),
        risk_factors=("eval $variable executes attacker-controlled content",),
        mitre_attack=(_T1059_004, _T1027_010),
    ),
    "SG-CMD-010": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2025-06-01",
        tags=("command-chain", "reverse-shell", "netcat"),
        risk_factors=("Netcat reverse shell establishes C2 communication",),
        mitre_attack=(_T1059_004, _T1071_001),
    ),
    # ===== CONFIG SECURITY RULES =====
    "SG-CONFIG-001": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2025-06-01",
        tags=("config-security", "credential-exposure", "hardcoded-secret"),
        risk_factors=("Hardcoded secrets in config files are easily exposed",),
        mitre_attack=(_T1552_001,),
    ),
    "SG-CONFIG-002": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2025-06-01",
        tags=("config-security", "insecure-default", "debug-mode"),
        risk_factors=("Debug mode and disabled SSL expose attack surface",),
        mitre_attack=(_T1190,),
    ),
    "SG-CONFIG-003": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2025-06-01",
        tags=("config-security", "weak-encryption", "cryptography"),
        risk_factors=("Weak algorithms (MD5/DES/RC4) are cryptographically broken",),
        mitre_attack=(_T1552,),
    ),
    "SG-CONFIG-004": RuleEnrichmentMeta(
        confidence=0.88,
        first_seen="2025-06-01",
        tags=("config-security", "cors", "access-control"),
        risk_factors=("Wildcard CORS allows any origin to access the API",),
        mitre_attack=(_T1190,),
    ),
    "SG-CONFIG-005": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2025-06-01",
        tags=("config-security", "exposure", "database"),
        risk_factors=("Database on 0.0.0.0 is accessible from any network",),
        mitre_attack=(_T1190,),
    ),
    "SG-CONFIG-006": RuleEnrichmentMeta(
        confidence=0.95,
        first_seen="2025-06-01",
        tags=("config-security", "default-credentials", "authentication"),
        risk_factors=("Default credentials are widely known and exploited",),
        mitre_attack=(_T1552_001, _T1190),
    ),
    "SG-CONFIG-007": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2025-06-01",
        tags=("config-security", "data-privacy", "logging"),
        risk_factors=("Logging passwords/tokens creates credential exposure",),
        mitre_attack=(_T1552,),
    ),
    "SG-CONFIG-008": RuleEnrichmentMeta(
        confidence=0.75,
        first_seen="2025-06-01",
        tags=("config-security", "rate-limiting", "dos"),
        risk_factors=("Disabled rate limiting enables DoS and brute force",),
        mitre_attack=(_T1190,),
    ),
    "SG-CONFIG-009": RuleEnrichmentMeta(
        confidence=0.70,
        first_seen="2025-06-01",
        tags=("config-security", "session-management", "timeout"),
        risk_factors=("Long session timeouts increase session hijack window",),
        mitre_attack=(_T1190,),
    ),
    "SG-CONFIG-010": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2025-06-01",
        tags=("config-security", "file-permissions", "access-control"),
        risk_factors=("World-writable permissions allow unauthorized file modification",),
        mitre_attack=(_T1083,),
    ),
}


# ---------------------------------------------------------------------------
# Severity-based fallback defaults (for unknown rule IDs)
# ---------------------------------------------------------------------------
SEVERITY_DEFAULTS: dict[str, RuleEnrichmentMeta] = {
    "critical": RuleEnrichmentMeta(
        confidence=0.90,
        first_seen="2024-01-15",
        tags=("unknown-rule",),
        risk_factors=("Critical severity finding from unknown rule",),
        mitre_attack=(),
    ),
    "high": RuleEnrichmentMeta(
        confidence=0.85,
        first_seen="2024-01-15",
        tags=("unknown-rule",),
        risk_factors=("High severity finding from unknown rule",),
        mitre_attack=(),
    ),
    "medium": RuleEnrichmentMeta(
        confidence=0.70,
        first_seen="2024-01-15",
        tags=("unknown-rule",),
        risk_factors=("Medium severity finding from unknown rule",),
        mitre_attack=(),
    ),
    "low": RuleEnrichmentMeta(
        confidence=0.50,
        first_seen="2024-01-15",
        tags=("unknown-rule",),
        risk_factors=("Low severity finding from unknown rule",),
        mitre_attack=(),
    ),
}
