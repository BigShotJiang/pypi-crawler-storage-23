"""GitHub CI integration — annotations and action support."""
