"""CI/CD integration adapters for GitHub Actions and GitLab CI."""
