"""Health check endpoint."""

from __future__ import annotations

from fastapi import APIRouter

from skillgate.version import __version__

router = APIRouter(tags=["health"])


@router.get("/health")
async def health_check() -> dict[str, str]:
    """Return service health status."""
    return {"status": "ok", "service": "skillgate-api", "version": __version__}
