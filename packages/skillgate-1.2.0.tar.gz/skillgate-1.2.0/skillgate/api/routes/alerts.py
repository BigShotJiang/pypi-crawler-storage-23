"""Slack alerts integration — webhook-based scan notifications."""

from __future__ import annotations

import ipaddress
import logging
import os
from urllib.parse import urlparse

import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from skillgate.api.db import get_session
from skillgate.api.entitlement import resolve_user_entitlement
from skillgate.api.models import User
from skillgate.api.routes.auth import get_current_user
from skillgate.core.entitlement.models import Capability

router = APIRouter(prefix="/alerts", tags=["alerts"])
logger = logging.getLogger(__name__)


class SlackAlertRequest(BaseModel):
    """Request to send a scan alert to Slack."""

    webhook_url: str | None = Field(
        default=None,
        description="Slack webhook URL. Falls back to SKILLGATE_SLACK_WEBHOOK env var.",
    )
    bundle_name: str
    risk_score: int
    severity: str
    findings_count: int
    policy_passed: bool | None = None
    report_url: str | None = None


class SlackAlertResponse(BaseModel):
    """Response from Slack alert."""

    sent: bool
    error: str | None = None


def _build_slack_message(req: SlackAlertRequest) -> dict[str, object]:
    """Build a Slack Block Kit message from scan results."""
    # Color based on severity
    color_map = {"low": "#36a64f", "medium": "#f2c744", "high": "#e01e5a", "critical": "#ff0000"}
    color = color_map.get(req.severity.lower(), "#808080")

    status = ":white_check_mark: PASSED" if req.policy_passed else ":x: FAILED"
    if req.policy_passed is None:
        status = ":grey_question: No policy"

    fields = [
        {"title": "Bundle", "value": req.bundle_name, "short": True},
        {"title": "Risk Score", "value": str(req.risk_score), "short": True},
        {"title": "Severity", "value": req.severity.upper(), "short": True},
        {"title": "Findings", "value": str(req.findings_count), "short": True},
        {"title": "Policy", "value": status, "short": True},
    ]

    attachment: dict[str, object] = {
        "color": color,
        "title": f"SkillGate Scan: {req.bundle_name}",
        "fields": fields,
        "footer": "SkillGate Security Scanner",
    }

    if req.report_url:
        attachment["title_link"] = req.report_url

    return {"attachments": [attachment]}


def _is_safe_webhook_url(url: str) -> bool:
    """Validate webhook URL to prevent SSRF attacks.

    SECURITY FIX 16.32: Prevent requests to internal networks and localhost.
    Only allow HTTPS URLs to known webhook providers.
    """
    try:
        parsed = urlparse(url)

        # Must be HTTPS
        if parsed.scheme != "https":
            return False

        # Must have a hostname
        if not parsed.hostname:
            return False

        # Check for localhost/loopback
        if parsed.hostname.lower() in {"localhost", "127.0.0.1", "::1", "0.0.0.0"}:
            return False

        # Try to parse as IP address
        try:
            ip = ipaddress.ip_address(parsed.hostname)
            # Block private IP ranges (RFC1918, link-local, etc.)
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
                return False
            # Block multicast and unspecified
            if ip.is_multicast or ip.is_unspecified:
                return False
        except ValueError:
            # Not an IP address, it's a hostname - additional checks
            pass

        # Allowlist known webhook providers
        allowed_domains = {
            "hooks.slack.com",
            "discord.com",
            "hooks.zapier.com",
            "webhook.site",  # For testing
        }

        # Check if hostname ends with allowed domain
        hostname_lower = parsed.hostname.lower()
        is_allowed = any(
            hostname_lower == domain or hostname_lower.endswith(f".{domain}")
            for domain in allowed_domains
        )

        return is_allowed

    except Exception as e:
        logger.warning(f"Webhook URL validation error: {e}")
        return False


@router.post("/slack")
async def send_slack_alert(
    req: SlackAlertRequest,
    user: User = Depends(get_current_user),  # noqa: B008 - SECURITY FIX 16.32: Require auth
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> SlackAlertResponse:
    """Send a scan result notification to Slack.

    SECURITY FIX 16.32: Now requires authentication and validates webhook URLs
    to prevent SSRF attacks and abuse.
    """
    # SECURITY FIX 16.32: Validate webhook URL BEFORE entitlement check.
    # SSRF is a security invariant — it must be enforced regardless of tier.
    webhook_url = req.webhook_url or os.environ.get("SKILLGATE_SLACK_WEBHOOK", "")
    if not webhook_url:
        raise HTTPException(
            status_code=400,
            detail="No Slack webhook URL provided or configured.",
        )

    if not _is_safe_webhook_url(webhook_url):
        raise HTTPException(
            status_code=400,
            detail="Invalid or unsafe webhook URL. Must be HTTPS to an allowed domain.",
        )

    entitlement = await resolve_user_entitlement(user, session)
    if not entitlement.has_capability(Capability.CI_BLOCKING):
        raise HTTPException(
            status_code=403,
            detail="Slack/webhook alerts require Team or Enterprise tier.",
        )

    message = _build_slack_message(req)

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                webhook_url,
                json=message,
                timeout=10.0,
            )
            response.raise_for_status()
            return SlackAlertResponse(sent=True)
    except httpx.HTTPError as e:
        logger.warning("Slack alert failed: %s", e)
        return SlackAlertResponse(sent=False, error=str(e))
