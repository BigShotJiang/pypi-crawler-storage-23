"""Public roadmap endpoints for backend-driven marketing content."""

from __future__ import annotations

from fastapi import APIRouter

from skillgate.api.roadmap_catalog import MarketingRoadmap, marketing_roadmap_payload

router = APIRouter(prefix="/roadmap", tags=["roadmap"])


@router.get("/marketing", response_model=MarketingRoadmap)
async def get_marketing_roadmap() -> MarketingRoadmap:
    """Return roadmap content used by the public web UI."""
    return marketing_roadmap_payload()
