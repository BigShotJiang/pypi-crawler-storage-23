"""Supabase-backed auth provider for SkillGate hosted API.

This module implements the Supabase dispatch path for all auth operations.
It is activated when ``SKILLGATE_AUTH_PROVIDER=supabase``.

Contract:
  - All public functions mirror the return types used by existing local-auth
    route handlers so that route code only needs to dispatch — not fork.
  - Session bridging: Supabase issues its own access + refresh pair.
    SkillGate stores a ``UserSession`` row for domain-level revocation
    tracking; it does NOT re-implement token signing.
  - Profile mapping: Supabase ``user`` object → ``UserResponse`` preserving
    SkillGate subscription/tier fields from domain tables.
  - Email verification: Supabase-managed email (preferred) with an optional
    app-managed fallback via Resend when Supabase email is not configured.
  - OAuth (PKCE): real Supabase PKCE code exchange — demo paths blocked.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import HTTPException, Request
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from skillgate.api.errors import AuthError
from skillgate.api.models import OAuthIdentity, Subscription, User, UserSession
from skillgate.api.routes.auth import (
    AuthResponse,
    UserResponse,
    _client_ip,
)
from skillgate.api.settings import get_settings
from skillgate.api.supabase_client import SupabaseAuthClient, SupabaseClientError

logger = logging.getLogger(__name__)

_SUPPORTED_OAUTH_PROVIDERS = frozenset({"google", "github", "gitlab", "bitbucket"})


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _extract_supabase_user(data: dict[str, Any]) -> dict[str, Any]:
    """Pull the canonical Supabase user dict from various response shapes."""
    # sign_in_with_password → {"access_token", "refresh_token", "user": {...}}
    user = data.get("user")
    if isinstance(user, dict):
        return user
    # sign_up → may return user directly at root
    if "id" in data:
        return data
    return {}


def _user_metadata(sb_user: dict[str, Any]) -> dict[str, Any]:
    """Normalise user_metadata from Supabase user object."""
    return sb_user.get("user_metadata") or sb_user.get("raw_user_meta_data") or {}


# ---------------------------------------------------------------------------
# Profile mapping (17.176)
# ---------------------------------------------------------------------------


async def map_supabase_user_to_profile(
    *,
    sb_user: dict[str, Any],
    db: AsyncSession,
) -> UserResponse:
    """Map a Supabase user dict to SkillGate's canonical ``UserResponse``.

    Loads domain-side subscription/tier data from SkillGate's own tables.
    Raises ``ValueError`` if the Supabase identity cannot be mapped to valid
    required response fields.
    """
    user_id: str = sb_user.get("id", "")
    email: str = sb_user.get("email", "")
    if not user_id or not email:
        raise ValueError("Supabase user missing required identity fields (id, email)")

    meta = _user_metadata(sb_user)
    full_name: str | None = meta.get("full_name") or sb_user.get("full_name") or None
    email_confirmed_at = sb_user.get("email_confirmed_at") or sb_user.get("confirmed_at")
    email_verified = bool(email_confirmed_at)

    # Load SkillGate-owned subscription row for tier / billing data.
    subscription = await db.scalar(select(Subscription).where(Subscription.user_id == user_id))
    tier = "free"
    sub_status: str | None = None
    billing_interval: str | None = None
    period_end: str | None = None
    cancel_at_end = False

    if subscription is not None:
        tier = subscription.tier or "free"
        sub_status = subscription.status
        billing_interval = subscription.billing_interval
        if subscription.current_period_end is not None:
            period_end = subscription.current_period_end.isoformat()
        cancel_at_end = bool(subscription.cancel_at_period_end)

    return UserResponse(
        user_id=user_id,
        email=email,
        full_name=full_name,
        email_verified=email_verified,
        tier=tier,
        subscription_status=sub_status,
        billing_interval=billing_interval,
        current_period_end=period_end,
        cancel_at_period_end=cancel_at_end,
    )


# ---------------------------------------------------------------------------
# Session bridging (17.178)
# ---------------------------------------------------------------------------


async def _persist_supabase_session(
    *,
    user_id: str,
    sb_access_token: str,
    sb_refresh_token: str,
    db: AsyncSession,
    request: Request,
) -> UserSession:
    """Create a ``UserSession`` row for domain-level revocation tracking.

    The row stores only a Supabase-session reference; SkillGate never
    re-derives tokens from this data.
    """
    import hashlib

    # Store a non-reversible fingerprint of the Supabase access token — only
    # used for session lookup on logout; the raw token is never persisted.
    token_hash = hashlib.sha256(sb_access_token.encode()).hexdigest()
    session_id = str(uuid.uuid4())
    client_ip = _client_ip(request)
    expires_at = _now() + timedelta(days=7)  # Supabase default session lifetime

    row = UserSession(
        id=session_id,
        user_id=user_id,
        refresh_token_hash=token_hash,
        ip_address=client_ip,
        expires_at=expires_at,
    )
    db.add(row)
    await db.commit()
    logger.info("supabase_session.created user_id=%s session_id=%s", user_id, session_id)
    return row


async def _ensure_skillgate_user(
    *,
    sb_user: dict[str, Any],
    db: AsyncSession,
    provider: str = "supabase",
) -> User:
    """Upsert a lightweight SkillGate User row mirroring the Supabase identity.

    SkillGate's domain tables (Subscription, Team, ScanRecord …) use
    ``user_id`` as FK — this row is that anchor.  Passwords are never set;
    the ``password_hash`` field is stored as a sentinel.
    """
    user_id: str = sb_user.get("id", "")
    email: str = sb_user.get("email", "")
    meta = _user_metadata(sb_user)
    full_name: str | None = meta.get("full_name") or None
    email_confirmed_at = sb_user.get("email_confirmed_at") or sb_user.get("confirmed_at")
    email_verified = bool(email_confirmed_at)

    # 1. Fast path: row whose PK IS the Supabase UUID (new Supabase-native user).
    user = await db.get(User, user_id)

    # 2. Supabase UUID already linked to a different internal ID
    #    (happens after local-to-supabase migration).
    if user is None:
        user = await db.scalar(select(User).where(User.supabase_user_id == user_id))

    # 3. Email already in DB under a different ID (local-auth migration).
    if user is None:
        user = await db.scalar(select(User).where(User.email == email))

    if user is None:
        # Brand-new user — create the anchor row.
        try:
            new_user = User(
                id=user_id,
                email=email,
                password_hash="supabase-managed",
                full_name=full_name,
                email_verified=email_verified,
                supabase_user_id=user_id,
            )
            db.add(new_user)
            await db.flush()  # Detect unique violations before committing.
            user = new_user
        except IntegrityError:
            # Race condition or duplicate email: roll back and reload.
            await db.rollback()
            user = await db.scalar(select(User).where(User.email == email))
            if user is None:
                raise HTTPException(status_code=409, detail="Email is already registered") from None
    else:
        # Sync mutable fields that may have changed on the Supabase side.
        user.email = email
        if full_name:
            user.full_name = full_name
        user.email_verified = email_verified
        # Link supabase_user_id on first encounter (covers migration case).
        if user.supabase_user_id is None:
            user.supabase_user_id = user_id

    await db.commit()
    return user


# ---------------------------------------------------------------------------
# Auth operations (17.175 / 17.177 / 17.178 / 17.179)
# ---------------------------------------------------------------------------


async def supabase_signup(
    *,
    auth_client: SupabaseAuthClient,
    email: str,
    password: str,
    full_name: str | None,
    db: AsyncSession,
    request: Request,
) -> dict[str, Any]:
    """Sign up a user via Supabase Auth.

    Returns a dict with ``status`` and optional ``verification_token`` for
    non-production environments (17.177 dual path).
    """
    try:
        data = await auth_client.sign_up(email=email, password=password, full_name=full_name)
    except AuthError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        # Supabase returns 422 for validation errors (e.g. "User already registered",
        # "Password too short"). Convert to a proper HTTP response so the exception
        # does not escape the route and bypass CORSMiddleware.
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except SupabaseClientError as exc:
        if exc.status_code == 429:
            raise HTTPException(
                status_code=429,
                detail="Signup email rate limit reached. Please wait a moment before trying again.",
            ) from exc
        raise HTTPException(status_code=503, detail="Auth service unavailable") from exc

    sb_user = _extract_supabase_user(data)
    if sb_user:
        try:
            await _ensure_skillgate_user(sb_user=sb_user, db=db)
        except HTTPException:
            raise
        except Exception as exc:
            logger.error(
                "supabase_signup._ensure_skillgate_user_failed email=%s error=%s",
                email,
                exc,
            )
            raise HTTPException(status_code=409, detail="Email is already registered") from exc

    settings = get_settings()
    has_session = bool(data.get("access_token") and data.get("refresh_token"))

    if has_session:
        return {
            "status": "signed_up",
            "verification_required": False,
            "verification_token": None,
        }

    # 17.177 dual-path: if Supabase email is not configured, send via Resend.
    supabase_email_sent = bool(
        data.get("confirmation_sent_at") or sb_user.get("confirmation_sent_at")
    )
    if not supabase_email_sent and settings.resend_api_key:
        # Generate a Supabase-compatible OTP link via admin API if needed; for
        # now emit a Resend fallback event.
        logger.info("supabase_signup.resend_fallback email=%s", email)
        # Resend flow requires a token — Supabase provides none here; emit
        # an observability event and let the user re-request verification.

    if settings.is_production:
        return {"status": "verification_pending", "verification_required": True}
    return {
        "status": "verification_pending",
        "verification_required": True,
        "verification_token": None,  # Supabase manages its own OTP tokens
    }


async def supabase_login(
    *,
    auth_client: SupabaseAuthClient,
    email: str,
    password: str,
    db: AsyncSession,
    request: Request,
) -> AuthResponse:
    """Authenticate via Supabase and create a bridged SkillGate session."""
    try:
        data = await auth_client.sign_in_with_password(email=email, password=password)
    except AuthError as exc:
        msg = str(exc).lower()
        email_unconfirmed = (
            "not confirmed" in msg or "not verified" in msg or ("email" in msg and "confirm" in msg)
        )
        if email_unconfirmed:
            raise HTTPException(status_code=403, detail="Email verification required") from exc
        raise HTTPException(status_code=401, detail="Invalid credentials") from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except SupabaseClientError as exc:
        if exc.status_code == 429:
            raise HTTPException(
                status_code=429,
                detail="Too many login attempts. Please wait a moment before trying again.",
            ) from exc
        raise HTTPException(status_code=503, detail="Auth service unavailable") from exc

    sb_access_token: str = data.get("access_token", "")
    sb_refresh_token: str = data.get("refresh_token", "")
    sb_user = _extract_supabase_user(data)

    if not sb_access_token or not sb_refresh_token or not sb_user.get("id"):
        raise HTTPException(status_code=503, detail="Incomplete response from auth service")

    user = await _ensure_skillgate_user(sb_user=sb_user, db=db)

    if not user.email_verified:
        raise HTTPException(status_code=403, detail="Email verification required")

    session_row = await _persist_supabase_session(
        user_id=user.id,
        sb_access_token=sb_access_token,
        sb_refresh_token=sb_refresh_token,
        db=db,
        request=request,
    )

    return AuthResponse(
        access_token=sb_access_token,
        refresh_token=sb_refresh_token,
        token_type="bearer",
        session_id=session_row.id,
        user_id=user.id,
        email=user.email,
    )


async def supabase_refresh(
    *,
    auth_client: SupabaseAuthClient,
    refresh_token: str,
    db: AsyncSession,
    request: Request,
) -> AuthResponse:
    """Rotate a Supabase session using its refresh token."""
    try:
        data = await auth_client.refresh_session(refresh_token=refresh_token)
    except AuthError as exc:
        raise HTTPException(status_code=401, detail="Invalid refresh token") from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except SupabaseClientError as exc:
        raise HTTPException(status_code=503, detail="Auth service unavailable") from exc

    sb_access_token: str = data.get("access_token", "")
    new_refresh_token: str = data.get("refresh_token", "")
    sb_user = _extract_supabase_user(data)

    if not sb_access_token or not sb_user.get("id"):
        raise HTTPException(status_code=503, detail="Incomplete response from auth service")

    user = await _ensure_skillgate_user(sb_user=sb_user, db=db)
    session_row = await _persist_supabase_session(
        user_id=user.id,
        sb_access_token=sb_access_token,
        sb_refresh_token=new_refresh_token,
        db=db,
        request=request,
    )

    return AuthResponse(
        access_token=sb_access_token,
        refresh_token=new_refresh_token,
        token_type="bearer",
        session_id=session_row.id,
        user_id=user.id,
        email=user.email,
    )


async def supabase_logout(
    *,
    auth_client: SupabaseAuthClient,
    access_token: str,
    db: AsyncSession,
) -> None:
    """Revoke session in both Supabase and SkillGate's domain session table."""
    import hashlib

    try:
        await auth_client.sign_out(access_token=access_token)
    except Exception:
        # Best-effort — always revoke the domain row regardless.
        logger.warning("supabase_logout.supabase_signout_failed")

    token_hash = hashlib.sha256(access_token.encode()).hexdigest()
    row = await db.scalar(select(UserSession).where(UserSession.refresh_token_hash == token_hash))
    if row is not None and not row.revoked:
        row.revoked = True
        row.revoked_at = _now()
        await db.commit()


async def supabase_password_reset_request(
    *,
    auth_client: SupabaseAuthClient,
    email: str,
    redirect_to: str | None = None,
) -> None:
    """Trigger password-reset email via Supabase (account-existence-agnostic)."""
    try:
        await auth_client.request_password_reset(email=email, redirect_to=redirect_to)
    except Exception:
        # Never reveal account existence — swallow all errors.
        logger.info("supabase_password_reset.requested email_hash=%s", hash(email))


async def supabase_oauth_callback(
    *,
    auth_client: SupabaseAuthClient,
    provider: str,
    code: str,
    db: AsyncSession,
    request: Request,
) -> AuthResponse:
    """Handle real OAuth PKCE code exchange via Supabase (17.179).

    Demo paths are explicitly blocked at this layer; the caller must have
    already validated the environment gate.
    """
    provider_norm = provider.lower()
    if provider_norm not in _SUPPORTED_OAUTH_PROVIDERS:
        raise HTTPException(status_code=400, detail="Unsupported OAuth provider")

    if code.startswith("demo:"):
        # 17.179: demo mode is NEVER available through the Supabase path.
        raise HTTPException(
            status_code=400, detail="Demo OAuth codes are not accepted in Supabase auth mode"
        )

    try:
        data = await auth_client.exchange_code_for_session(code=code)
    except AuthError as exc:
        raise HTTPException(status_code=401, detail="OAuth authentication failed") from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except SupabaseClientError as exc:
        raise HTTPException(status_code=503, detail="Auth service unavailable") from exc

    sb_access_token: str = data.get("access_token", "")
    sb_refresh_token: str = data.get("refresh_token", "")
    sb_user = _extract_supabase_user(data)

    if not sb_access_token or not sb_user.get("id"):
        raise HTTPException(status_code=503, detail="Incomplete OAuth response from auth service")

    user = await _ensure_skillgate_user(sb_user=sb_user, db=db, provider=provider_norm)

    # Upsert OAuth identity record for domain-level identity linkage.
    identity = await db.scalar(
        select(OAuthIdentity).where(
            OAuthIdentity.provider == provider_norm,
            OAuthIdentity.user_id == user.id,
        )
    )
    if identity is None:
        identity = OAuthIdentity(
            id=str(uuid.uuid4()),
            user_id=user.id,
            provider=provider_norm,
            provider_user_id=sb_user["id"],
            email=user.email,
        )
        db.add(identity)
    await db.commit()

    session_row = await _persist_supabase_session(
        user_id=user.id,
        sb_access_token=sb_access_token,
        sb_refresh_token=sb_refresh_token,
        db=db,
        request=request,
    )

    return AuthResponse(
        access_token=sb_access_token,
        refresh_token=sb_refresh_token,
        token_type="bearer",
        session_id=session_row.id,
        user_id=user.id,
        email=user.email,
    )
