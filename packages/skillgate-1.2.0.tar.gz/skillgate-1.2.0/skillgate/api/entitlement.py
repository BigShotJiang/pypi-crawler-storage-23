"""API-side entitlement resolution."""

from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from skillgate.api.settings import get_settings
from skillgate.config.license import Tier
from skillgate.core.entitlement.enterprise_adapter import (
    apply_enterprise_validation_result,
    build_enterprise_validation_adapter,
)
from skillgate.core.entitlement.models import TIER_ENTITLEMENTS, Entitlement, EntitlementSource

if TYPE_CHECKING:
    from skillgate.api.models import User


async def resolve_user_entitlement(user: User, session: AsyncSession) -> Entitlement:
    """Resolve entitlement for a user from database subscription.

    Args:
        user: User object
        session: Database session

    Returns:
        Entitlement based on user's subscription tier
    """
    from skillgate.api.models import Subscription

    stmt = (
        select(Subscription)
        .where(Subscription.user_id == user.id)
        .where(Subscription.status == "active")
        .order_by(Subscription.created_at.desc())
        .limit(1)
    )
    result = await session.execute(stmt)
    subscription = result.scalar_one_or_none()

    if subscription is None:
        return TIER_ENTITLEMENTS[Tier.FREE]()

    try:
        tier = Tier(subscription.tier)
    except ValueError:
        tier = Tier.FREE

    entitlement = TIER_ENTITLEMENTS[tier]()
    resolved = Entitlement(
        tier=entitlement.tier,
        capabilities=entitlement.capabilities,
        limits=entitlement.limits,
        source=EntitlementSource.API_KEY,
        expires_at=subscription.current_period_end,
    )
    if resolved.tier != Tier.ENTERPRISE:
        return resolved

    settings = get_settings()
    adapter = build_enterprise_validation_adapter(
        onprem_url=settings.onprem_entitlement_url,
        onprem_token=settings.onprem_entitlement_token,
        timeout_seconds=settings.onprem_timeout_seconds,
    )
    try:
        validation = await adapter.validate(user_id=str(user.id), entitlement=resolved)
    except Exception:  # noqa: BLE001
        if settings.onprem_fail_open:
            return resolved
        return TIER_ENTITLEMENTS[Tier.FREE]()

    return apply_enterprise_validation_result(resolved, validation)
