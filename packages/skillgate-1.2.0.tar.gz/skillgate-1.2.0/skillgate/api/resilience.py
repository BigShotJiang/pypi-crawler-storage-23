"""External-call resilience primitives (timeout + circuit breaker)."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from threading import Lock
from typing import TypeVar

T = TypeVar("T")


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


@dataclass(slots=True)
class CircuitBreakerSnapshot:
    """Read-only circuit breaker state."""

    state: str
    failures: int
    opened_until: datetime | None


class CircuitBreaker:
    """Simple in-memory circuit breaker for unstable external dependencies."""

    def __init__(
        self,
        *,
        failure_threshold: int = 5,
        recovery_seconds: int = 30,
    ) -> None:
        self._failure_threshold = failure_threshold
        self._recovery_seconds = recovery_seconds
        self._failures = 0
        self._opened_until: datetime | None = None
        self._lock = Lock()

    def allow(self) -> bool:
        with self._lock:
            if self._opened_until is None:
                return True
            if _now() >= self._opened_until:
                self._opened_until = None
                self._failures = 0
                return True
            return False

    def record_success(self) -> None:
        with self._lock:
            self._failures = 0
            self._opened_until = None

    def record_failure(self) -> None:
        with self._lock:
            self._failures += 1
            if self._failures >= self._failure_threshold:
                self._opened_until = _now() + timedelta(seconds=self._recovery_seconds)

    def snapshot(self) -> CircuitBreakerSnapshot:
        with self._lock:
            state = "open" if self._opened_until and _now() < self._opened_until else "closed"
            return CircuitBreakerSnapshot(
                state=state,
                failures=self._failures,
                opened_until=self._opened_until,
            )


async def run_blocking_with_resilience(
    *,
    breaker: CircuitBreaker,
    timeout_seconds: float,
    fn: Callable[[], T],
) -> T:
    """Execute blocking call with timeout and circuit-breaker controls."""
    if not breaker.allow():
        raise RuntimeError("External dependency circuit is open")

    try:
        result = await asyncio.wait_for(asyncio.to_thread(fn), timeout=timeout_seconds)
    except asyncio.TimeoutError as exc:
        breaker.record_failure()
        raise TimeoutError("External dependency call timed out") from exc
    except Exception:
        breaker.record_failure()
        raise

    breaker.record_success()
    return result
