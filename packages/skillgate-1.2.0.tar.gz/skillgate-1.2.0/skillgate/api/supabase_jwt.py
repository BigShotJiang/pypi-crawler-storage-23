"""Supabase JWT verification with JWKS support and bounded TTL cache.

Supports RS256, ES256, and HS256 — enforced via an explicit algorithm allowlist.
Algorithm selection follows JWKS key type when available; falls back to the
shared JWT secret for HS256 (legacy / anon-key environments).

Thread-safety: the module-level ``_JwksCache`` is intentionally designed for
concurrent async access — the underlying httpx call is performed under an
asyncio.Lock so that exactly one refresh races at a time.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import httpx
import jwt
from jwt import InvalidTokenError, PyJWKClient, PyJWKClientError

from skillgate.api.errors import AuthError

logger = logging.getLogger(__name__)

# Algorithms we accept.  No none, no HS384/512 (not issued by Supabase).
_ALLOWED_ALGORITHMS = frozenset({"RS256", "ES256", "HS256"})

# JWKS cache TTL in seconds (5 minutes).
_JWKS_TTL = 300


class _StaticJwkClient(PyJWKClient):
    """PyJWKClient variant that serves pre-fetched JWKS payload."""

    def __init__(self, jwks_url: str, jwks_data: dict[str, Any]) -> None:
        super().__init__(jwks_url)
        self._jwks_data = jwks_data

    def fetch_data(self) -> Any:
        return self._jwks_data


class _JwksCache:
    """Thin wrapper around PyJWKClient with TTL-based refresh."""

    def __init__(self) -> None:
        self._client: PyJWKClient | None = None
        self._url: str | None = None
        self._fetched_at: float = 0.0
        self._lock = asyncio.Lock()

    def _is_stale(self, url: str) -> bool:
        return (
            self._client is None
            or self._url != url
            or (time.monotonic() - self._fetched_at) > _JWKS_TTL
        )

    async def get_signing_key(self, jwks_url: str, token: str, apikey: str | None = None) -> Any:
        """Return the signing key for ``token``, refreshing the JWKS cache if stale."""
        if self._is_stale(jwks_url):
            async with self._lock:
                # Double-checked locking — another coroutine may have refreshed first.
                if self._is_stale(jwks_url):
                    await self._refresh(jwks_url, apikey=apikey)
        assert self._client is not None
        try:
            return self._client.get_signing_key_from_jwt(token)
        except PyJWKClientError as exc:
            raise AuthError("Token signing key not found in JWKS") from exc

    async def _refresh(self, jwks_url: str, apikey: str | None = None) -> None:
        logger.info("supabase_jwt.jwks_refresh url=%s", jwks_url)
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                headers = {}
                if apikey:
                    headers["apikey"] = apikey
                resp = await client.get(jwks_url, headers=headers)
                resp.raise_for_status()
                jwks_data = resp.json()
        except Exception as exc:
            raise AuthError("Failed to fetch Supabase JWKS") from exc
        self._client = _StaticJwkClient(jwks_url, jwks_data)
        self._url = jwks_url
        self._fetched_at = time.monotonic()
        logger.info("supabase_jwt.jwks_refreshed key_count=%d", len(jwks_data.get("keys", [])))


_jwks_cache = _JwksCache()


def _decode_hs256(token: str, secret: str, *, audience: str | None) -> dict[str, Any]:
    """Decode a Supabase HS256 token using the shared JWT secret."""
    options: dict[str, Any] = {"require": ["sub", "exp", "iat"]}
    if not audience:
        options["verify_aud"] = False
    decode_kwargs: dict[str, Any] = {
        "algorithms": ["HS256"],
        "options": options,
    }
    if audience:
        decode_kwargs["audience"] = audience
    return jwt.decode(token, secret, **decode_kwargs)


async def _decode_jwks(
    token: str,
    jwks_url: str,
    *,
    audience: str | None,
    issuer: str | None,
    apikey: str | None = None,
) -> dict[str, Any]:
    """Decode an RS256 / ES256 Supabase token via JWKS lookup."""
    signing_key = await _jwks_cache.get_signing_key(jwks_url, token, apikey=apikey)
    unverified_header = jwt.get_unverified_header(token)
    alg = unverified_header.get("alg", "")
    if alg not in _ALLOWED_ALGORITHMS:
        raise AuthError(f"Algorithm '{alg}' is not permitted")

    options: dict[str, Any] = {"require": ["sub", "exp", "iat"]}
    if not audience:
        options["verify_aud"] = False
    decode_kwargs: dict[str, Any] = {
        "algorithms": list(_ALLOWED_ALGORITHMS),
        "options": options,
        "key": signing_key.key,
    }
    if audience:
        decode_kwargs["audience"] = audience
    if issuer:
        decode_kwargs["issuer"] = issuer
    return jwt.decode(token, **decode_kwargs)


async def verify_supabase_token(
    token: str,
    *,
    jwks_url: str | None = None,
    jwt_secret: str | None = None,
    audience: str | None = None,
    issuer: str | None = None,
    apikey: str | None = None,
) -> dict[str, Any]:
    """Verify a Supabase JWT and return validated claims.

    Priority: JWKS (RS256/ES256) when ``jwks_url`` is provided; falls back to
    HS256 shared-secret verification when ``jwt_secret`` is provided.

    Raises ``AuthError`` (HTTP 401) for any verification failure — no internal
    details are propagated to the caller.
    """
    if not jwks_url and not jwt_secret:
        raise AuthError("No Supabase JWT verification method configured")

    # Peek at header algorithm to route correctly (no signature trust at this point)
    try:
        unverified_header = jwt.get_unverified_header(token)
    except InvalidTokenError as exc:
        raise AuthError("Malformed token") from exc

    alg = unverified_header.get("alg", "")
    if alg not in _ALLOWED_ALGORITHMS:
        raise AuthError(f"Token algorithm '{alg}' is not permitted")

    try:
        if jwks_url and alg in {"RS256", "ES256"}:
            claims = await _decode_jwks(
                token, jwks_url, audience=audience, issuer=issuer, apikey=apikey
            )
        elif jwt_secret:
            claims = _decode_hs256(token, jwt_secret, audience=audience)
        else:
            raise AuthError("No matching verification method for algorithm")
    except AuthError:
        raise
    except InvalidTokenError as exc:
        logger.debug("supabase_jwt.invalid_token reason=%s", exc)
        raise AuthError("Invalid or expired token") from exc
    except Exception as exc:
        logger.warning("supabase_jwt.unexpected_error: %s", type(exc).__name__)
        raise AuthError("Token verification failed") from exc

    # Mandatory claim validation
    subject = claims.get("sub")
    if not isinstance(subject, str) or not subject:
        raise AuthError("Token missing required subject claim")

    return claims


def invalidate_jwks_cache() -> None:
    """Force JWKS cache invalidation on next verification (for testing / key rotation)."""
    _jwks_cache._fetched_at = 0.0
