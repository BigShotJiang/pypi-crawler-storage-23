"""Typed API error envelope helpers."""

from __future__ import annotations

from collections.abc import Mapping

from fastapi.responses import JSONResponse
from pydantic import BaseModel


class AuthError(Exception):
    """Raised by auth verification helpers to signal a deterministic 401.

    The message is safe to log; it MUST NOT contain raw tokens, keys, or
    any material that could leak secret values into log aggregation.
    """


class ErrorPayload(BaseModel):
    """Structured error payload for client and observability use."""

    code: str
    message: str
    request_id: str
    retryable: bool


class ErrorEnvelope(BaseModel):
    """Compatibility-preserving envelope with explicit typed error fields."""

    detail: str
    error: ErrorPayload


def error_code_for_status(status_code: int) -> str:
    """Map HTTP status codes to deterministic error codes."""
    mapping = {
        400: "BAD_REQUEST",
        401: "UNAUTHORIZED",
        403: "FORBIDDEN",
        404: "NOT_FOUND",
        409: "CONFLICT",
        422: "VALIDATION_ERROR",
        429: "RATE_LIMITED",
        500: "INTERNAL_ERROR",
        502: "UPSTREAM_ERROR",
        503: "SERVICE_UNAVAILABLE",
        504: "TIMEOUT",
    }
    return mapping.get(status_code, "UNKNOWN_ERROR")


def is_retryable_status(status_code: int) -> bool:
    """Identify statuses where retry guidance should be true."""
    return status_code in {408, 425, 429, 500, 502, 503, 504}


def error_response(
    *,
    status_code: int,
    message: str,
    request_id: str,
    code: str | None = None,
    retryable: bool | None = None,
    headers: Mapping[str, str] | None = None,
) -> JSONResponse:
    """Build a standardized JSON error response envelope."""
    resolved_code = code or error_code_for_status(status_code)
    resolved_retryable = is_retryable_status(status_code) if retryable is None else retryable
    envelope = ErrorEnvelope(
        detail=message,
        error=ErrorPayload(
            code=resolved_code,
            message=message,
            request_id=request_id,
            retryable=resolved_retryable,
        ),
    )
    return JSONResponse(
        status_code=status_code,
        content=envelope.model_dump(),
        headers=headers or {},
    )
