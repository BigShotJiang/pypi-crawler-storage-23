"""Team/Enterprise entitlement controls."""

from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from skillgate.config.license import Tier
from skillgate.core.entitlement.models import TIER_ENTITLEMENTS, Entitlement

if TYPE_CHECKING:
    from skillgate.api.models import Team, User


async def resolve_team_entitlement(user: User, team: Team, session: AsyncSession) -> Entitlement:
    """Resolve entitlement for a user within a team context.

    Args:
        user: User object
        team: Team object
        session: Database session

    Returns:
        Team's entitlement if user is a member, otherwise FREE
    """
    from skillgate.api.models import TeamMember

    # Check user is team member
    stmt = (
        select(TeamMember).where(TeamMember.team_id == team.id).where(TeamMember.user_id == user.id)
    )
    result = await session.execute(stmt)
    member = result.scalar_one_or_none()

    if member is None:
        return TIER_ENTITLEMENTS[Tier.FREE]()

    # Resolve team's subscription tier
    from skillgate.api.entitlement import resolve_user_entitlement
    from skillgate.api.models import User

    # Use team owner's entitlement
    owner = await session.get(User, team.owner_user_id)
    if owner is None:
        return TIER_ENTITLEMENTS[Tier.FREE]()

    return await resolve_user_entitlement(owner, session)


async def check_team_seat(team_id: int, session: AsyncSession) -> tuple[int, int]:
    """Check team seat usage.

    Args:
        team_id: Team ID
        session: Database session

    Returns:
        Tuple of (used_seats, max_seats)
    """
    from skillgate.api.models import Team, TeamMember

    # Get team with seat limit
    team = await session.get(Team, team_id)
    if team is None:
        return (0, 0)

    team_default = TIER_ENTITLEMENTS[Tier.TEAM]().limits.max_seats
    max_seats = team.max_seats or team_default

    # Count current members
    stmt = select(func.count()).select_from(TeamMember).where(TeamMember.team_id == team_id)
    result = await session.execute(stmt)
    used_seats = result.scalar() or 0

    return (used_seats, max_seats)


async def can_invite_to_team(team_id: int, session: AsyncSession) -> bool:
    """Check if team can accept new members.

    Args:
        team_id: Team ID
        session: Database session

    Returns:
        True if team has available seats
    """
    used, max_seats = await check_team_seat(team_id, session)
    return used < max_seats
