"""Device code storage for OAuth device flow.

Uses Redis in production for distributed storage.
Falls back to in-memory for development/testing.
"""

from __future__ import annotations

import inspect
import json
from datetime import datetime, timedelta, timezone
from typing import Any, cast

import redis.asyncio as redis

from skillgate.api.settings import get_settings

# In-memory fallback for tests
_memory_store: dict[str, dict[str, Any]] = {}

_redis_client: redis.Redis | None = None


async def _get_redis() -> redis.Redis | None:
    """Get Redis client (singleton)."""
    global _redis_client

    if _redis_client is not None:
        return _redis_client

    settings = get_settings()

    # Skip Redis in development if not available
    if not settings.is_production:
        try:
            from_url = cast(Any, redis.from_url)
            client = from_url(
                settings.redis_url,
                decode_responses=True,
            )
            ping_result = client.ping()
            if inspect.isawaitable(ping_result):
                await ping_result
            _redis_client = client
            return _redis_client
        except Exception:
            # Redis not available, use in-memory
            return None

    # Production: Redis is required
    from_url = cast(Any, redis.from_url)
    _redis_client = from_url(
        settings.redis_url,
        decode_responses=True,
    )
    return _redis_client


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _device_key(device_code: str) -> str:
    return f"device_code:{device_code}"


def _user_code_index_key(user_code: str) -> str:
    return f"user_code_index:{user_code}"


async def store_device_code(
    device_code: str,
    user_code: str,
    client_id: str,
    expires_in_seconds: int = 300,
) -> None:
    """Store a new device code."""
    data = {
        "device_code": device_code,
        "user_code": user_code,
        "client_id": client_id,
        "created_at": _now().isoformat(),
        "completed": False,
        "tokens": None,
    }

    client = await _get_redis()

    if client:
        # Redis storage with TTL
        key = _device_key(device_code)
        await client.setex(key, expires_in_seconds, json.dumps(data))
        # Index by user_code for lookup
        await client.setex(
            _user_code_index_key(user_code),
            expires_in_seconds,
            device_code,
        )
    else:
        # In-memory fallback
        _memory_store[device_code] = {
            **data,
            "expires_at": _now() + timedelta(seconds=expires_in_seconds),
        }


async def get_device_code(device_code: str) -> dict[str, Any] | None:
    """Get device code data."""
    client = await _get_redis()

    if client:
        data = await client.get(_device_key(device_code))
        if data:
            result: dict[str, Any] = json.loads(data)
            return result
        return None

    # In-memory fallback
    stored = _memory_store.get(device_code)
    if not stored:
        return None
    if stored.get("expires_at") and stored["expires_at"] <= _now():
        del _memory_store[device_code]
        return None
    return stored


async def get_device_code_by_user_code(user_code: str) -> tuple[str, dict[str, Any]] | None:
    """Find device code by user code."""
    client = await _get_redis()

    if client:
        device_code = await client.get(_user_code_index_key(user_code))
        if device_code:
            data = await get_device_code(device_code)
            if data:
                return device_code, data
        return None

    # In-memory fallback
    for dc, data in list(_memory_store.items()):
        if data.get("user_code") == user_code:
            if data.get("expires_at") and data["expires_at"] <= _now():
                del _memory_store[dc]
                continue
            return dc, data
    return None


async def complete_device_code(device_code: str, tokens: dict[str, Any]) -> None:
    """Mark device code as completed with tokens."""
    client = await _get_redis()

    if client:
        key = _device_key(device_code)
        data = await client.get(key)
        if data:
            parsed = json.loads(data)
            parsed["completed"] = True
            parsed["tokens"] = tokens
            # Keep for a short time after completion for polling
            await client.setex(key, 60, json.dumps(parsed))
    else:
        # In-memory fallback
        if device_code in _memory_store:
            _memory_store[device_code]["completed"] = True
            _memory_store[device_code]["tokens"] = tokens


async def delete_device_code(device_code: str) -> None:
    """Delete a device code."""
    client = await _get_redis()

    if client:
        data = await client.get(_device_key(device_code))
        if data:
            parsed = json.loads(data)
            await client.delete(_device_key(device_code))
            await client.delete(_user_code_index_key(parsed.get("user_code", "")))
    else:
        _memory_store.pop(device_code, None)


# For testing: clear all in-memory data
def _clear_memory_store() -> None:
    """Clear in-memory device codes (for tests)."""
    global _memory_store
    _memory_store = {}
