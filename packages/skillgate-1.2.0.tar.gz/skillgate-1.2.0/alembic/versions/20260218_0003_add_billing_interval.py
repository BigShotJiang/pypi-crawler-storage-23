"""Add billing_interval to subscriptions for monthly/yearly billing.

Revision ID: 20260218_0003
Revises: 20260216_0002
Create Date: 2026-02-18 12:00:00.000000

Sprint 7.2: Commercialization (Tasks 17.41-17.50)
Industry-standard annual billing with 17% discount (2 months free).
"""

import sqlalchemy as sa

from alembic import op

# revision identifiers, used by Alembic.
revision = "20260218_0003"
down_revision = "20260216_0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Add billing_interval column to subscriptions table."""
    # Add billing_interval column with default 'monthly'
    # SQLite requires server_default instead of nullable manipulation
    op.add_column(
        "subscriptions",
        sa.Column(
            "billing_interval",
            sa.String(length=12),
            nullable=False,
            server_default="monthly",
        ),
    )


def downgrade() -> None:
    """Remove billing_interval column from subscriptions table."""
    op.drop_column("subscriptions", "billing_interval")
