"""Supabase auth migration: ownership split and correlation column.

Revision ID: 20260222_0006
Revises: 20260218_0004
Create Date: 2026-02-22 00:00:00

Ownership split (17.180 / 17.181):
  Supabase-owned (managed externally, NOT migrated by Alembic going forward):
    - auth.users            (Supabase internal schema)
    - user_sessions         (Supabase manages token revocation)
    - password_reset_tokens (Supabase manages password-reset flow)
    - email_verification_tokens (Supabase manages OTP flow)
    - oauth_identities      (Supabase manages provider links)
    - auth_rate_limits      (Supabase projects handle auth rate limiting)

  SkillGate-owned (continued Alembic management):
    - users                 (domain anchor row; id = Supabase user UUID)
    - subscriptions
    - api_keys
    - teams / team_members
    - stripe_events
    - scan_records
    - entitlement_usage_ledger
    - entitlement_decision_log

  Correlation: ``users.id`` IS the Supabase Auth user UUID when
  ``SKILLGATE_AUTH_PROVIDER=supabase``.  No additional FK is needed;
  the ``supabase_user_id`` column is added for explicit documentation and
  read-path queries.

IMPORTANT:
  In local-provider mode, ``users.supabase_user_id`` is always NULL and
  must not be used in queries.  All application code must guard on the
  auth provider setting before referencing this column.
"""

from __future__ import annotations

import sqlalchemy as sa

from alembic import op

revision = "20260222_0006"
down_revision = "20260218_0004"
branch_labels = None
depends_on = None

# Tables that are Supabase-owned in hosted mode.  Alembic will not drop them or
# add business-logic columns to them going forward; any schema changes must be
# applied via Supabase SQL migrations.
SUPABASE_OWNED_TABLES = frozenset(
    {
        "user_sessions",
        "password_reset_tokens",
        "email_verification_tokens",
        "oauth_identities",
        "auth_rate_limits",
    }
)


def upgrade() -> None:
    # Add correlation column so domain queries can reference Supabase identity
    # without a join when running in supabase auth mode.
    op.add_column(
        "users",
        sa.Column(
            "supabase_user_id",
            sa.String(length=36),
            nullable=True,
            comment=(
                "Supabase Auth user UUID. Set when SKILLGATE_AUTH_PROVIDER=supabase. "
                "NULL in local-auth mode."
            ),
        ),
    )
    op.create_index(
        "ix_users_supabase_user_id",
        "users",
        ["supabase_user_id"],
        unique=True,
        postgresql_where=sa.text("supabase_user_id IS NOT NULL"),
    )

    # Ownership marker: add a comment to the users table.
    # Postgres-only — silently skipped on SQLite (dev).
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        bind.execute(
            sa.text(
                "COMMENT ON TABLE users IS "
                "'SkillGate domain anchor. In supabase-auth mode, id = Supabase Auth UUID.'"
            )
        )


def downgrade() -> None:
    op.drop_index("ix_users_supabase_user_id", table_name="users")
    op.drop_column("users", "supabase_user_id")
