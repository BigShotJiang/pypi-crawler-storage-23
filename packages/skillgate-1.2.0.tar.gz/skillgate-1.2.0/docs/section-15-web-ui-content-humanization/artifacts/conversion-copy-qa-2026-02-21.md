# Conversion Copy QA (2026-02-21)

## Scope Reviewed

- Pricing page and pricing section.
- Docs hub and docs section top summaries.
- Core marketing sections (`Hero`, `Features`, `CTA`, `SocialProof`).
- Supporting user-facing copy (`About`, `Contact`, `Auth`, utility pages).

## CTA Consistency Check

Current primary CTA set:
- Hero: `Start Free`
- CTA section: `Run Your First Gate`
- Pricing cards: `Get Started Free`, `Start Pro`, `Start Team`, `Contact Sales`
- Header: `Get Started`

Assessment:
- Pass with minor variance:
  - Intent remains clear and actionable.
  - CTA verbs are concrete (`Start`, `Run`, `Contact`).

## Claim-to-Proof Wording Check

Claims retained and tightened:
- Deterministic policy outcomes.
- Runtime enforcement and approvals.
- Signed evidence/attestations and provenance.

Proof-path alignment:
- Docs quick start still maps to runnable flow:
  - `scan -> enforce -> sign/verify`
- Runtime docs map to gateway and policy enforcement path.
- Pricing enterprise claims map to runtime controls and evidence exports.

Assessment:
- Pass.

## Before/After Notes (Representative)

1. Pricing header
- Before: "Pricing Mapped to the SkillGate Control Stack"
- After: "Pricing Mapped to Real Security Control Depth"

2. Pricing progression label
- Before: "Governance Progression"
- After: "Control Progression"

3. Enterprise architecture disclosure
- Before: "View Control Plane Architecture"
- After: "View Runtime Control Path"

4. Docs hub summary
- Before: generic control-plane framing
- After: explicit "first scan to enforced runtime policy with signed evidence"

5. Footer brand line
- Before: generic governance phrase
- After: explicit "security gates ... with signed proof"

## Risk Notes

- Some CTA copy remains intentionally different by funnel stage (`Start Free` vs `Run Your First Gate`), which is acceptable for context-specific intent.
- Product claims were tightened, not expanded; no new unverifiable claims were introduced.
