# SkillGate Implementation Plan (Index)

This index preserves the legacy top-level path used by documentation contract tests.

- Phase 1 implementation plan: `docs/phase1/IMPLEMENTATION-PLAN.md`
- Phase 2 implementation plan: `docs/phase2/IMPLEMENTATION-PLAN.md`

Use the phase-specific plans as the canonical source for execution details.
