# Pricing Migration Plan

**Version:** 1.0.0  
**Last Updated:** 2026-02-18

## Goal

Transition existing Pro/Team customers to updated packaging with no entitlement breakage.

## Migration Strategy

1. Freeze plan-id mapping in backend (`PRICE_IDS`) and verify webhook mapping tests.
2. Enable dual-read compatibility for legacy monthly plan env vars.
3. Reconcile active subscriptions from Stripe before launch.
4. Validate downgrade/upgrade transitions from webhook events.

## Transition Rules

- Existing active subscribers keep current access until `current_period_end`.
- Billing interval updates (monthly/yearly) are sourced from Stripe webhook events only.
- UI success/cancel pages are non-authoritative; entitlement follows webhook state.

## Execution Checklist

- [ ] Run `/payments/reconcile/subscriptions` in staging and production.
- [ ] Verify no subscriptions with null/unknown tier.
- [ ] Verify no stale events override newer subscription state.
- [ ] Run rollback rehearsal and confirm subscriptions converge post-replay.

## Rollback Plan

- Keep old plan IDs mapped during transition window.
- Replay dead-letter webhook events after rollback.
- Re-run reconciliation and compare before/after subscription state counts.
