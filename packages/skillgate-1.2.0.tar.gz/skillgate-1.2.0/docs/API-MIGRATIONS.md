# API Migrations and Local PostgreSQL Workflow

This runbook defines the production-safe migration path for hosted API schema changes.

## 1) Start local PostgreSQL

```bash
docker compose -f docker-compose.postgres.yml up -d
```

## 2) Set API environment

```bash
export SKILLGATE_ENV=development
export SKILLGATE_DATABASE_URL="postgresql+asyncpg://skillgate:skillgate@localhost:5432/skillgate"
export SKILLGATE_JWT_SECRET="dev-local-jwt-secret-with-at-least-32-chars"
export SKILLGATE_API_KEY_PEPPER="dev-local-pepper-with-at-least-32-chars"
```

## 3) Install dependencies

```bash
pip install -e ".[dev,api]"
```

## 4) Rehearse migrations (required before merge)

```bash
alembic upgrade head
alembic downgrade base
alembic upgrade head
```

## 5) Run API tests

```bash
pytest tests/unit/test_api -q
```

## Notes

- Production/staging must use Alembic migrations. Do not rely on runtime `create_all`.
- Local SQLite can auto-initialize schema for convenience (`SKILLGATE_AUTO_INIT_DB=true`).
- In production/staging, set strict CORS origins and strong JWT/API pepper secrets.
