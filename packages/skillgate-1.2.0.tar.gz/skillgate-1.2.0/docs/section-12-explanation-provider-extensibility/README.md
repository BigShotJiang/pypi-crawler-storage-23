# Section 12 Execution Pack: Explanation CLI + Provider Extensibility

## Purpose

This folder is the mandatory execution contract for Section 12:
`Explanation CLI Naming + LLM Provider Extensibility`.

It prevents CLI/provider drift and enforces evidence-backed implementation.

## Scope

- Defines the user-facing CLI contract and compatibility boundaries.
- Defines provider adapter, policy/egress, and fallback requirements.
- Defines tasks, gates, and evidence needed for release claims.

## Completion Promise (Mandatory)

No task is marked `Complete` unless:

1. Scope matches `SPECS.md`.
2. Required tests/checks pass.
3. Evidence artifacts are linked in task records.
4. Backward compatibility and rollback path are documented.

## Document Map

- `BOUNDARIES.md`
- `SPECS.md`
- `TASKS.md`
- `RALPH-LOOP.md`
- `READINESS-GATES.md`
- `VALIDATION-CHECKS.md`
- `AGENT-SKILLS-MANDATORY.md`
- `PER-TASK-RECORDS.md`
- `PR-DESCRIPTION-SECTION12.md`
- `RELEASE-DECISION.md`

## Status Model

- `Not Started`
- `In Progress`
- `Blocked`
- `Ready for Gate`
- `Complete`
