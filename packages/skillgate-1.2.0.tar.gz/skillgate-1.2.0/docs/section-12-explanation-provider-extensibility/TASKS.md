# Task Registry, DoD, and Delivery Order

## Status Board (Section 12)

| Task | Name | Priority | Status | Owner | Notes |
|---|---|---|---|---|---|
| 17.133 | Explanation CLI naming contract | P0 | Complete | TBD | New source/provider flags live; deprecated alias hidden and warning-gated |
| 17.134 | Provider abstraction + registry | P0 | Complete | TBD | Deterministic `openai|anthropic|custom` resolution path shipped |
| 17.135 | Azure/Groq/Ollama adapters | P0 | Complete | TBD | Custom adapter execution path + timeout/retry + safe fallback shipped |
| 17.136 | Endpoint allowlist + network policy | P0 | Complete | TBD | Default-deny egress + endpoint allowlist enforcement active |
| 17.137 | Migration + enterprise operator docs | P0 | Complete | TBD | Migration guide + operator controls and rollback published |

## Definition of Done (Per Task)

1. Scope implemented as `SPECS.md`.
2. Required tests/checks pass in CI and local reproduction.
3. Evidence linked in `PER-TASK-RECORDS.md`.
4. Backward compatibility documented.
5. Rollback/recovery path documented.
6. Security/policy invariants validated.

## 10-Day Delivery Sequence

### Phase A (Days 1-3)

- `17.133` CLI flags and deprecation path
- `17.134` provider abstraction and resolution

### Phase B (Days 4-7)

- `17.135` built-in adapters
- `17.136` endpoint policy/allowlist controls

### Phase C (Days 8-10)

- `17.137` migration/operator documentation
- hardening and defect closure

## Per-Task Completion Ledger

Legend: `Y` = satisfied and linked, `N` = not yet satisfied.

| Task | Spec match | CI + local tests | Evidence links | Backward compatibility note | Rollback/recovery note | Security/policy validation | Status |
|---|---|---|---|---|---|---|---|
| 17.133 | Y | Y | Y | Y | Y | Y | Complete |
| 17.134 | Y | Y | Y | Y | Y | Y | Complete |
| 17.135 | Y | Y | Y | Y | Y | Y | Complete |
| 17.136 | Y | Y | Y | Y | Y | Y | Complete |
| 17.137 | Y | Y | Y | Y | Y | Y | Complete |
