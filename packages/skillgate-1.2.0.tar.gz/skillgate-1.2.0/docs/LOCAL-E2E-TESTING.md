# Local End-to-End Testing (API + Worker + CLI + Web UI)

This guide runs the full stack locally:
- API (`uvicorn`)
- Worker (`arq`)
- CLI (`skillgate`)
- Web UI (`next dev`)

## 1) Prerequisites

- Python 3.10-3.13 (recommended: 3.12)
- Python virtualenv exists at `venv/`
- Docker Desktop running
- Node.js + npm installed

## 2) Start local infra (Postgres + Redis)

```bash
cd /Users/spy/Documents/PY/AI/skillgate
docker compose up -d postgres redis
```

## 3) Install dependencies

```bash
cd /Users/spy/Documents/PY/AI/skillgate
source venv/bin/activate
pip install -e ".[dev,api,worker]"
```

```bash
cd /Users/spy/Documents/PY/AI/skillgate/web-ui
npm ci
```

## 4) Load environment variables

SkillGate code and Alembic read process environment, not `.env` automatically.

```bash
cd /Users/spy/Documents/PY/AI/skillgate
set -a
source .env
set +a
```

If needed, ensure these values exist:

```bash
export SKILLGATE_ENV=development
export SKILLGATE_DATABASE_URL="postgresql+asyncpg://skillgate:skillgate@localhost:5432/skillgate"
export SKILLGATE_REDIS_URL="redis://localhost:6379/0"
export SKILLGATE_JWT_SECRET="dev-local-jwt-secret-with-at-least-32-chars"
export SKILLGATE_API_KEY_PEPPER="dev-local-pepper-with-at-least-32-chars"
```

## 5) Run DB migrations

```bash
cd /Users/spy/Documents/PY/AI/skillgate
source venv/bin/activate
alembic upgrade head
```

## 6) Start API

```bash
cd /Users/spy/Documents/PY/AI/skillgate
source venv/bin/activate
uvicorn skillgate.api.app:create_app --factory --host 0.0.0.0 --port 8000 --reload
```

## 7) Start worker (new terminal)

```bash
cd /Users/spy/Documents/PY/AI/skillgate
source venv/bin/activate
set -a
source .env
set +a
arq skillgate.api.worker.WorkerSettings
```

## 8) Start web UI (new terminal)

```bash
cd /Users/spy/Documents/PY/AI/skillgate/web-ui
export NEXT_PUBLIC_API_URL="http://localhost:8000/api/v1"
npm run dev
```

## 9) Smoke tests

API:

```bash
cd /Users/spy/Documents/PY/AI/skillgate
API_BASE="http://127.0.0.1:8000/api/v1" ./scripts/deploy/smoke_api.sh
```

Web:

```bash
cd /Users/spy/Documents/PY/AI/skillgate
WEB_BASE="http://127.0.0.1:3000" ./scripts/deploy/smoke_web.sh
```

## 10) CLI checks

```bash
cd /Users/spy/Documents/PY/AI/skillgate
source venv/bin/activate
skillgate --version
skillgate scan tests/fixtures/skills/safe/hello-skill
skillgate scan tests/fixtures/skills/malicious/evil-skill --policy production
```

## 11) Focused test runs

API unit tests:

```bash
cd /Users/spy/Documents/PY/AI/skillgate
source venv/bin/activate
pytest tests/unit/test_api -q
```

CLI unit tests:

```bash
cd /Users/spy/Documents/PY/AI/skillgate
source venv/bin/activate
pytest tests/unit/test_cli -q
```

Web UI tests:

```bash
cd /Users/spy/Documents/PY/AI/skillgate/web-ui
npm test
```

## 12) Stop everything

```bash
cd /Users/spy/Documents/PY/AI/skillgate
docker compose stop postgres redis
```

## 13) Troubleshooting

If worker fails with:

`RuntimeError: There is no current event loop in thread 'MainThread'`

you are likely using Python 3.14 with `arq`.
Use Python 3.12 (or 3.13) for this project and recreate `venv`.
