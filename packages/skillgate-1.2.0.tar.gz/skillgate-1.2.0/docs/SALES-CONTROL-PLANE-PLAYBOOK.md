# SkillGate Sales Playbook

## Why Enterprise = Control Plane Infrastructure

SkillGate Enterprise is not a larger scanner plan. It is governance infrastructure for AI agent execution.

### Core Positioning

- Category: AI agent control plane.
- Buyer outcome: deterministic governance, runtime control, and audit-grade trust evidence.
- Procurement frame: risk reduction + compliance readiness + operational control.

### Enterprise Narrative Pillars

1. Runtime enforcement, not static visibility only.
2. Transitive lineage and trust propagation, not isolated findings.
3. Cryptographic provenance (signed AI-BOM and attestations), not unverifiable reports.
4. Governance APIs and policy simulation, not manual rollout guesswork.
5. Private relay/air-gapped modes for regulated environments.

### Objection Handling

| Objection | Response |
|---|---|
| "We already have scanners." | Scanners detect. SkillGate governs execution with deterministic block/allow outcomes. |
| "Why is Enterprise $10K+?" | Enterprise includes runtime control plane primitives: capability budgets, trust DAG, simulation, governance APIs, compliance exports, and private deployment modes. |
| "Can Team do this?" | Team governs CI and fleet risk posture. Enterprise adds runtime and org-wide governance infrastructure. |
| "Is this deployable in restricted environments?" | Yes: private relay and air-gapped enforcement modes are first-class Enterprise capabilities. |

### Qualification Checklist

- Regulated or audit-heavy environment.
- Need runtime enforcement beyond CI blocking.
- Need centralized governance APIs and audit bundles.
- Need org-scale rollout simulation before strict enforcement.
- Need hybrid/private deployment constraints.
