# Boundaries (Fail-Closed)

## In Scope

- The six Section 11 risks from `docs/IMPLEMENTATION-PLAN.md`.
- Mitigations with explicit owner, deadline, and objective evidence.
- Escalation rules when mitigation milestones are missed.

## Out of Scope

- Adding new product features unrelated to listed risk controls.
- Marking risks "mitigated" without measurable evidence.

## Non-Negotiable Constraints

- Risk status must be evidence-backed, not narrative-only.
- Deadline misses require mitigation-plan update within one day.
- High-severity risk gates failing must freeze expansion scope.
