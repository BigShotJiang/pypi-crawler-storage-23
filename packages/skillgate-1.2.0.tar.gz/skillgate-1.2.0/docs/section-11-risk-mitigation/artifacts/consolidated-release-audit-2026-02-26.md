# Consolidated Release Audit (2026-02-26)

Scope: local CI-equivalent gate pack run.

## Step Results
- `lint`: FAIL (exit=1)

## Verdict
- all_green: `false`

## Raw Artifacts
- `docs/section-11-risk-mitigation/artifacts/consolidated-release-audit-2026-02-26.json`
- `docs/section-11-risk-mitigation/artifacts/consolidated-release-audit-2026-02-26.log`
