# Consolidated Release Audit (2026-02-25)

Scope: local CI-equivalent gate pack run.

## Step Results
- `lint`: PASS (exit=0)
- `typecheck`: PASS (exit=0)
- `test`: PASS (exit=0)
- `slo-gates`: PASS (exit=0)
- `reliability-evidence`: PASS (exit=0)
- `packaging`: PASS (exit=0)
- `api-command-matrix`: PASS (exit=0)
- `web-ui`: PASS (exit=0)
- `api-migrations`: FAIL (exit=1)

## Verdict
- all_green: `false`

## Raw Artifacts
- `docs/section-11-risk-mitigation/artifacts/consolidated-release-audit-2026-02-25.json`
- `docs/section-11-risk-mitigation/artifacts/consolidated-release-audit-2026-02-25.log`
