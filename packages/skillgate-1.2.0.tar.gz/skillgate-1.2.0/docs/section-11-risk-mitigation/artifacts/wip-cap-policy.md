# WIP Cap Policy

Date: 2026-02-21

## Policy

- Max active implementation section streams: `1`
- Governance/risk review updates may continue in parallel.

## Current State

- Active implementation stream: Section 13 (installation/docs UX)
- Governance stream: Section 11 risk review

## Enforcement

1. If another section moves to `In Progress`, pause new implementation changes until active stream closes a gate.
2. Update `weekly-risk-review.md` when switching active stream.
