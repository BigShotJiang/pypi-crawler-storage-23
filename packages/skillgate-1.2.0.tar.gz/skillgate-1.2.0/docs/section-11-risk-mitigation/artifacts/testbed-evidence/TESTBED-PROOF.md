# SkillGate Testbed Proof

Source repositories:
- https://github.com/shubhamsaboo/awesome-llm-apps
- https://github.com/sickn33/antigravity-awesome-skills
- https://github.com/openclaw/openclaw (skills corpus at `skills/`)
- https://github.com/HKUDS/nanobot (skills corpus at `nanobot/skills/`)

## Corpus statistics
- awesome-llm-apps corpus size: 496 invocations
- antigravity-awesome-skills corpus size: 2856 invocations
- openclaw/openclaw corpus size: 106 invocations
- HKUDS/nanobot corpus size: 12 invocations
- total testbed size: 3470 invocations

## Authenticated real-sidecar replay (baseline variants)
- awesome-llm-apps replay: total=248, allow=248, error=0, p95=11.38ms
- antigravity replay: total=1428, allow=1428, error=0, p95=8.78ms
- openclaw replay: total=53, allow=53, error=0, p95=10.43ms
- nanobot replay: total=6, allow=6, error=0, p95=55.00ms
- combined authenticated baseline: total=1735, allow=1735, error=0

## Authenticated real-sidecar replay (full variants)
- antigravity replay: total=2856, allow=1428, fail=1428, error=0
- decision split: SG_ALLOW=1428, SG_FAIL_POLICY_UNAVAILABLE=1428
- http status split: 200=2856 (no 500 responses)

## Visual proof assets
- images/awesome-proof-card.svg
- images/antigravity-proof-card.svg
- images/openclaw-proof-card.svg
- images/nanobot-proof-card.svg
- images/testbed-corpus-comparison.svg

## Raw evidence files
- awesome-llm-apps.toolinvocations.jsonl
- antigravity.toolinvocations.jsonl
- openclaw.toolinvocations.jsonl
- nanobot.toolinvocations.jsonl
- awesome-llm-apps.real-sidecar.baseline.report.json
- antigravity.real-sidecar.baseline.report.json
- openclaw.real-sidecar.baseline.report.json
- nanobot.real-sidecar.baseline.report.json
- awesome-llm-apps.real-sidecar.baseline.detail.ndjson
- antigravity.real-sidecar.baseline.detail.ndjson
- openclaw.real-sidecar.baseline.detail.ndjson
- nanobot.real-sidecar.baseline.detail.ndjson
- antigravity.real-sidecar.full.report.json
- antigravity.real-sidecar.full.detail.ndjson

## Risky replay status
- Resolved: risky antigravity replay no longer returns HTTP 500.
- Current behavior: risky variants fail closed with deterministic code `SG_FAIL_POLICY_UNAVAILABLE`.
