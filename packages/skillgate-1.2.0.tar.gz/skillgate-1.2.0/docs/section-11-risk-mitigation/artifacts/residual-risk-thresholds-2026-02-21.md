# Section 11 Residual Risk Closure Thresholds

Date: 2026-02-21

Status policy:

- Risk stays `In Progress` until threshold is met by the target date.
- Risk can move to `Mitigated` only after threshold evidence is linked in
  `docs/section-11-risk-mitigation/PER-TASK-RECORDS.md`.

## Closure Thresholds

| Risk ID | Mitigation-to-Mitigated threshold | Target date |
|---|---|---|
| R11-002 | Four consecutive weekly reviews include claim-ledger pass and updated governance/evidence differentiation deltas with no unbacked claims. | 2026-03-21 |
| R11-004 | `gha_workflow_runs >= 10/week` and `docs_to_setup_conversion >= 0.10` for two consecutive weekly reports. | 2026-03-28 |
| R11-005 | At least two enterprise opportunities complete proof-pack-first evaluation and one converts to paid pilot/PO with signed evidence review completion. | 2026-04-15 |
| R11-006 | WIP-cap compliance >= 90% across four consecutive weeks and contractor trigger checklist remains green (no unowned critical stream). | 2026-04-05 |

## Evidence Sources

- `docs/section-11-risk-mitigation/artifacts/weekly-risk-review.md`
- `docs/section-11-risk-mitigation/artifacts/adoption-kpi-baseline.json`
- `docs/section-11-risk-mitigation/artifacts/consolidated-release-audit-2026-02-21.md`
