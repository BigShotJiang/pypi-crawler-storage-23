# Risk Registry, Mitigation Tasks, and Delivery Order

## Status Board (Section 11)

| Risk ID | Risk | Priority | Status | Owner | Deadline | Notes |
|---|---|---|---|---|---|---|
| R11-001 | Overbuilding before revenue | P0 | Mitigated | Product/Gate Owner | Day 17 | Scope-freeze + governance gate controls are active |
| R11-002 | Detection commoditization risk | P0 | In Progress | Product + Evidence Owner | Day 45 | Governance/enforcement/evidence differentiation shipped; monitor market pressure |
| R11-003 | High false positive rate | P0 | Mitigated | Reliability/Gate Owner | Day 14 | Reliability scorecard and CI threshold gates active |
| R11-004 | Low GitHub Action adoption | P1 | In Progress | DX/Growth Owner | Day 40 | Corrective actions completed; now tracking KPI deltas and adoption trend |
| R11-005 | Enterprise sales cycle length | P1 | In Progress | Product + Sales Owner | Day 90 | Self-serve proof-path and evidence pack improving cycle risk |
| R11-006 | Solo-execution burnout risk | P1 | In Progress | Founder/Execution Owner | Day 120 | Delegation matrix, contractor trigger checklist, and WIP cap policy now active |

## Definition of Done (Per Risk)

A risk can be set to `Mitigated` only if:

1. Mitigation actions are implemented.
2. Evidence links are captured.
3. Owner confirms residual risk level.
4. Fallback path exists if risk reappears.

## Review Cadence

- Weekly risk review with updated status/evidence deltas.
- Any `at_risk` item gets next-day corrective plan update.

## Current Pass Evidence (2026-02-21)

- Risk register snapshot: `docs/section-11-risk-mitigation/artifacts/risk-register.json`
- Weekly review note: `docs/section-11-risk-mitigation/artifacts/weekly-risk-review.md`
- Gate run log: `docs/section-11-risk-mitigation/artifacts/section11-gate-run.log`
- Corrective action plan: `docs/section-11-risk-mitigation/artifacts/corrective-action-plan.md`
- Residual risk closure thresholds: `docs/section-11-risk-mitigation/artifacts/residual-risk-thresholds-2026-02-21.md`
- Consolidated release audit: `docs/section-11-risk-mitigation/artifacts/consolidated-release-audit-2026-02-21.md`

## Residual Risk Closure Thresholds (Mitigation -> Mitigated)

| Risk ID | Threshold | Target Date |
|---|---|---|
| R11-002 | Four consecutive weekly reviews include claim-ledger pass + differentiation delta with no unbacked claims | 2026-03-21 |
| R11-004 | `gha_workflow_runs >= 10/week` and `docs_to_setup_conversion >= 0.10` for two consecutive weekly reports | 2026-03-28 |
| R11-005 | Two enterprise proof-pack evaluations completed and one converts to paid pilot/PO | 2026-04-15 |
| R11-006 | WIP-cap compliance >= 90% across four consecutive weeks and contractor trigger checklist remains green | 2026-04-05 |

## Active Corrective Actions (At-Risk Items)

| Action ID | Risk ID | Owner | Due Date | Status |
|---|---|---|---|---|
| CA-R11-004-1 | R11-004 | DX/Growth Owner | 2026-02-24 | Complete |
| CA-R11-004-2 | R11-004 | DX/Growth Owner | 2026-02-26 | Complete |
| CA-R11-004-3 | R11-004 | DX/Growth Owner | 2026-02-28 | Complete |
| CA-R11-006-1 | R11-006 | Founder/Execution Owner | 2026-02-23 | Complete |
| CA-R11-006-2 | R11-006 | Founder/Execution Owner | 2026-02-27 | Complete |
| CA-R11-006-3 | R11-006 | Founder/Execution Owner | 2026-02-28 | Complete |
