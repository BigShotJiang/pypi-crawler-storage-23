# Validation Checks (Mandatory)

Run from repo root unless noted.

## 1) Static + Type + Core Tests

```bash
./venv/bin/ruff check .
./venv/bin/mypy --strict skillgate/
./venv/bin/pytest -q
```

## 2) Reliability + Docs Claim Gates

```bash
./venv/bin/pytest -m slow tests/slo/ -q
python scripts/quality/check_claim_ledger.py
./venv/bin/pytest tests/docs/test_pricing_launch_controls.py -q
```

## 3) Orchestrator/Governance Focus Checks (as implemented)

Use task-targeted suites for:

- orchestrator lifecycle
- policy-in-the-loop boundaries
- approval verification paths
- evidence/proof pack verification
- schema contract compatibility
- scorer determinism/version replay

All new suites must include both positive and negative path coverage.

## 4) Evidence Artifacts Required Per Task

Each task PR must include:

1. Test output summary (what ran, pass/fail).
2. Linked artifacts (example proof pack or structured fixtures).
3. Determinism statement (how reproducibility was validated).
4. Security invariants check result.

## 5) Fail Conditions

Release is blocked if:

- Any required check fails.
- Any required suite is missing.
- Any claim lacks enforceable proof link.
- Any "temporary bypass" is present without explicit approval and tracking issue.
