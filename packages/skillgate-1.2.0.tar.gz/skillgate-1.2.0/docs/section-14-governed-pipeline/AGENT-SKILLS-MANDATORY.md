# Mandatory Agent Skills and Usage Order

This file defines required skill usage for agents implementing Section 14.

## Mandatory Skills (Current Workspace)

- `token-efficient-coding`
- `python-code-style`
- `python-pro`
- `pytest-runner`
- `skillgate-agent-tool`
- `production-hardening-gate`

## Phase-to-Skill Mapping

### Design + Scope Lock

Required:

- `token-efficient-coding`
- `python-pro`

### Implementation

Required:

- `token-efficient-coding`
- `python-code-style`
- `python-pro`

### Test and Validation

Required:

- `pytest-runner`
- `skillgate-agent-tool`

### Pre-Release Readiness

Required:

- `production-hardening-gate`

## Enforcement Rules

1. No task may be marked `Ready for Gate` without test execution via `pytest-runner`.
2. No runtime-governance change may ship without validation workflows aligned to `skillgate-agent-tool`.
3. No production claim may ship without a final pass aligned to `production-hardening-gate`.
4. If a required skill is unavailable, implementation is blocked until fallback is documented and approved.
5. strictly following the specs: skillgate/docs/section-14-governed-pipeline

## Evidence Rule

PRs must include:

- Skills applied
- Commands executed
- Gate outcomes
- Linked artifacts
