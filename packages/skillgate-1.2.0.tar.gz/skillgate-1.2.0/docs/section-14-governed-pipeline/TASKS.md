# Task Registry, DoD, and Delivery Order

## Status Board (Section 14)

| Task | Name | Priority | Status | Owner | Notes |
|---|---|---|---|---|---|
| 17.109 | Orchestrator service lifecycle core | P0 | Complete | TBD | Core lifecycle engine + retry/timeout logic shipped with evidence records |
| 17.111 | Policy-in-the-loop enforcement | P0 | Complete | TBD | Action-boundary policy checks shipped with evidence records |
| 17.112 | Signed approval checkpoint engine | P0 | Complete | TBD | Signed checkpoint enforcement shipped with evidence records |
| 17.113 | Audit ledger + evidence model | P0 | Complete | TBD | Deterministic signed evidence pack model shipped with evidence records |
| 17.152 | Positioning refresh (governance/enforcement/evidence) | P0 | Complete | TBD | PRD competitive positioning and claim-proof linkage finalized |
| 17.153 | Governance proof pack export | P0 | Complete | TBD | Signed proof-pack export contract finalized and evidenced |
| 17.154 | Reliability evidence pipeline | P0 | Complete | TBD | Reliability scorecard pipeline finalized and evidenced |
| 17.157 | Governance-before-autonomy gate | P0 | Complete | TBD | Governance scope gate finalized and evidenced |
| 17.161 | Canonical finding schema (`FindingV1`) | P0 | Complete | TBD | Canonical finding model shipped with deterministic coverage |
| 17.162 | Versioned deterministic risk model | P0 | Complete | TBD | Deterministic risk model versioning shipped |
| 17.163 | End-to-end governed vertical slice | P0 | Complete | TBD | Governed vertical slice + signed proof export shipped |
| 17.164 | Scope-freeze CI gate | P0 | Complete | TBD | CI scope-freeze contract shipped |
| 17.114 | TriageAgent v1 (read-only) | P1 | Complete | TBD | Deterministic read-only triage artifacts and comment renderer shipped |
| 17.156 | Mandatory write approval path | P1 | Complete | TBD | Explicit write path approval contract shipped (opt-in execution path) |
| 17.158 | Runtime enforcement efficacy corpus | P1 | Complete | TBD | Adversarial runtime corpus and integration tests shipped |

## Definition of Done (Per Task)

A task can be set to `Complete` only if all are true:

1. Scope implemented exactly as spec in `SPECS.md`.
2. Required tests pass in CI and local reproduction.
3. Evidence artifacts generated and linked in PR description.
4. Backward compatibility impact documented.
5. Rollback/recovery path documented.
6. Security and policy invariants validated (no bypass introduced).

## 21-Day Delivery Sequence

### Phase A (Days 1–5)

- `17.161` canonical finding schema
- `17.162` risk model versioning
- `17.109` orchestrator lifecycle
- `17.111` policy-in-loop boundaries

### Phase B (Days 6–10)

- `17.112` approval checkpoint engine
- `17.113` audit/evidence model
- `17.153` proof pack export
- `17.157` autonomy gate

### Phase C (Days 11–15)

- `17.154` reliability evidence pipeline
- `17.152` positioning claim refresh + proof links
- `17.163` governed vertical slice integration

### Phase D (Days 16–21)

- `17.164` scope-freeze CI gate
- Hardening and defect closure for all P0 tasks
- Optional: start `17.114` only if all P0 gates are green

## Completion Promise

We do not promise date-only completion.  
We promise gate-backed completion:

- "Done" means production-ready by evidence.
- Anything not passing gates is explicitly "in progress" or "blocked".

## Gate Evidence (Section 14)

Date: 2026-02-21

Gate run evidence:

- `./venv/bin/ruff check .` passed.
- `./venv/bin/mypy --strict skillgate/` passed.
- `./venv/bin/pytest -q` passed (full suite).
- `./venv/bin/pytest -m slow tests/slo/ -q` passed.
- `python scripts/quality/check_claim_ledger.py` passed.
- `./venv/bin/pytest tests/docs/test_pricing_launch_controls.py -q` passed.
- `python scripts/quality/check_governance_scope_gate.py` passed.
- `python scripts/quality/generate_reliability_scorecard.py` passed.
- Release gate log: `docs/section-14-governed-pipeline/artifacts/section14-release-gate.log`
- Delta hardening gate log: `docs/section-14-governed-pipeline/artifacts/section14-release-gate-delta.log`
- Final decision record: `docs/section-14-governed-pipeline/RELEASE-DECISION.md`

Implementation commits (P0 path):

- `c0eb8a9` — `17.161`, `17.162`
- `eb8c4c1` — `17.109`, `17.111`
- `147b2e4` — `17.112`, `17.113`
- `c210a06` — `17.153`
- `0d6dfb0` — `17.163`
- `f9331f3` — `17.154`, `17.157`, `17.164`
- `e06e38f` — `17.152` + governance-gate naming hardening

Per-task DoD evidence is now tracked in:

- `docs/section-14-governed-pipeline/PR-DESCRIPTION-SECTION14.md`
- `docs/section-14-governed-pipeline/PER-TASK-RECORDS.md`

## Per-Task Completion Ledger (Mandatory Before `Complete`)

Legend: `Y` = satisfied and linked, `N` = not yet satisfied.

| Task | Spec match | CI + local tests | PR evidence links | Backward compatibility note | Rollback/recovery note | Security/policy invariant validation | Status |
|---|---|---|---|---|---|---|---|
| 17.109 | Y | Y | Y | Y | Y | Y | Complete |
| 17.111 | Y | Y | Y | Y | Y | Y | Complete |
| 17.112 | Y | Y | Y | Y | Y | Y | Complete |
| 17.113 | Y | Y | Y | Y | Y | Y | Complete |
| 17.114 | Y | Y | Y | Y | Y | Y | Complete |
| 17.152 | Y | Y | Y | Y | Y | Y | Complete |
| 17.153 | Y | Y | Y | Y | Y | Y | Complete |
| 17.154 | Y | Y | Y | Y | Y | Y | Complete |
| 17.156 | Y | Y | Y | Y | Y | Y | Complete |
| 17.157 | Y | Y | Y | Y | Y | Y | Complete |
| 17.158 | Y | Y | Y | Y | Y | Y | Complete |
| 17.161 | Y | Y | Y | Y | Y | Y | Complete |
| 17.162 | Y | Y | Y | Y | Y | Y | Complete |
| 17.163 | Y | Y | Y | Y | Y | Y | Complete |
| 17.164 | Y | Y | Y | Y | Y | Y | Complete |
