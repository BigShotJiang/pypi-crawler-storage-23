# SkillGate Docs Claims Audit (Corrected)

**Audit date:** 2026-02-28  
**Scope:** Text presented in `skillgate-docs` vs current backend/web-ui/CLI implementation  
**Method:** Runtime + code evidence (not file-presence only)

---

## Executive Summary

| Category | Verified | Partial | Missing |
|---|---:|---:|---:|
| CLI Commands | 20 | 1 | 0 |
| SDK & Integrations | 9 | 1 | 0 |
| Runtime & Observability | 15 | 0 | 0 |
| Enterprise & Control Plane | 10 | 2 | 0 |
| Rules Catalog Surface | 1 | 0 | 0 |

**Overall posture:** High confidence after correction pass.  
**Previous false negatives fixed:** rule count, GitHub Action existence, private relay implementation.

---

## Corrected Findings (Important)

### 1) Rule count mismatch in prior audit was incorrect
- **Prior claim:** 41 rules.
- **Actual:** 120 rules in live registry.
- **Evidence:**
  - Runtime count via `get_all_rules()` = 120
  - `tests/integration/test_multilang_pipeline.py` asserts `len(rules) == 120`
  - `tests/integration/test_performance.py` asserts `len(rules) >= 119`

### 2) GitHub Action is implemented
- **Prior claim:** `action.yml` missing.
- **Actual:** present at `skillgate/ci/github/action.yml`.

### 3) Private relay mode is implemented
- **Prior claim:** not implemented.
- **Actual:** entitlement mode + enforcement paths are implemented.
- **Evidence:**
  - `skillgate/core/entitlement/mode.py`
  - `skillgate/core/entitlement/resolver.py`
  - `skillgate/core/entitlement/usage_authority.py`
  - Runtime tests pass: `tests/unit/test_entitlement/test_usage_authority.py`, `tests/unit/test_entitlement/test_mode.py`

---

## Gap Matrix (Current)

| Claim Area | Status | Evidence | Action |
|---|---|---|---|
| `skillgate keys` supports generate/list/export | **Partial** | only `generate` wired in `skillgate/cli/app.py` + `skillgate/cli/commands/keys.py` | Implement `keys list` and `keys export` |
| Enterprise SAML/OIDC SSO is fully live | **Partial** | helper/config exists (`skillgate/enterprise/sso.py`), full enterprise auth product flow incomplete | Keep docs phrasing as roadmap/partial until end-to-end is shipped |
| OpenClaw-specific dedicated gateway product | **Partial wording** | generic runtime gateway (`skillgate run`) supports OpenClaw workflows, no dedicated `openclaw_gateway` module | Keep wording as “OpenClaw workflows via runtime gateway”, avoid implying separate product module |

---

## skillgate-docs Remediation Completed In This Pass

1. Replaced hardcoded rule counts (`119`, `30+`, etc.) with generated canonical catalog data.
2. Wired all `/rules/*` pages to generated rule registry data (IDs and counts now consistent).
3. Updated quickstart/home/concepts/search index/layout metadata strings to use live totals.
4. Corrected enterprise wording for SSO/SAML/OIDC and support SLA phrasing.
5. Aligned roadmap catalog drift:
   - `ENTERPRISE-SSO-SAML` -> `planned`
   - `ENTERPRISE-RUNTIME-BUDGETS` -> `live`

---

## Runtime Validation Performed

- `./venv/bin/pytest -q tests/unit/test_enterprise/test_sso.py tests/unit/test_control_plane/test_rbac.py tests/unit/test_entitlement/test_mode.py tests/unit/test_entitlement/test_airgap_pack.py tests/unit/test_gateway/test_budget.py tests/integration/test_bom_gate.py` -> **27 passed**
- `./venv/bin/pytest -q tests/unit/test_runtime/test_record.py tests/unit/test_auth/test_slt_rate_limits.py` -> **8 passed**
- `./venv/bin/pytest -q tests/unit/test_entitlement/test_usage_authority.py tests/unit/test_entitlement/test_mode.py` -> **24 passed**
- `npm --prefix skillgate-docs run build` -> **passed**

---

## Next Implementation Priorities

1. Implement `skillgate keys list` and `skillgate keys export`.
2. Add an automated docs claim gate in CI (fail when `skillgate-docs` text drifts from canonical rule catalog and capability status).
3. Keep enterprise SSO wording explicitly “OAuth live, SAML/OIDC roadmap” until full auth flow is production-ready.
