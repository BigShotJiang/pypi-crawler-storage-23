# SkillGate — Technical Specification

**Product:** SkillGate  
**Version:** 1.0.0  
**Status:** Planning  
**Last Updated:** 2026-02-15  
**Classification:** Internal — Confidential  

---

## Table of Contents

1. [Detection Rules Specification](#1-detection-rules-specification)
2. [Risk Scoring Algorithm](#2-risk-scoring-algorithm)
3. [Policy Schema Specification](#3-policy-schema-specification)
4. [Report Format Specification](#4-report-format-specification)
5. [SARIF Output Specification](#5-sarif-output-specification)
6. [Ed25519 Signing Specification](#6-ed25519-signing-specification)
7. [Skill Bundle Format Support](#7-skill-bundle-format-support)
8. [Error Handling Specification](#8-error-handling-specification)
9. [Configuration File Specification](#9-configuration-file-specification)
10. [Performance Budgets](#10-performance-budgets)

---

## 1. Detection Rules Specification

### 1.1 Rule Naming Convention

```
SG-{CATEGORY}-{NUMBER}

Category codes:
  SHELL  — Shell execution
  NET    — Network access
  FS     — File system operations
  EVAL   — Dynamic code evaluation
  CRED   — Credential/secret access
  INJ    — Prompt/command injection
  OBF    — Obfuscation techniques

Number: 001–099 per category
```

### 1.2 Shell Execution Rules

| Rule ID | Name | Pattern | Severity | Weight | Description |
|---|---|---|---|---|---|
| SG-SHELL-001 | subprocess_call | `subprocess.run`, `subprocess.Popen`, `subprocess.call` | High | 40 | Direct subprocess execution |
| SG-SHELL-002 | os_system | `os.system()` | High | 40 | OS-level command execution |
| SG-SHELL-003 | os_popen | `os.popen()` | High | 40 | OS pipe command execution |
| SG-SHELL-004 | shell_true | `shell=True` parameter | Critical | 50 | Shell injection vector |
| SG-SHELL-005 | backtick_exec | `` `command` `` (JS/Shell) | High | 40 | Backtick command execution |
| SG-SHELL-006 | child_process | `child_process.exec`, `child_process.spawn` | High | 40 | Node.js child process |
| SG-SHELL-007 | shutil_operations | `shutil.rmtree`, `shutil.move` | Medium | 25 | Destructive file operations |

### 1.3 Network Access Rules

| Rule ID | Name | Pattern | Severity | Weight | Description |
|---|---|---|---|---|---|
| SG-NET-001 | http_request | `requests.get/post`, `urllib`, `fetch()`, `httpx` | Medium | 25 | Outbound HTTP request |
| SG-NET-002 | socket_connection | `socket.connect`, `socket.socket` | High | 35 | Raw socket connection |
| SG-NET-003 | dns_lookup | `socket.gethostbyname`, DNS resolution | Low | 15 | DNS lookup operation |
| SG-NET-004 | webhook_post | POST to external URL with data payload | High | 35 | Data exfiltration vector |
| SG-NET-005 | hardcoded_ip | IP address literals in code | Medium | 20 | Suspicious hardcoded destination |
| SG-NET-006 | ftp_connection | FTP/SFTP connection patterns | High | 35 | File transfer protocol usage |

### 1.4 File System Rules

| Rule ID | Name | Pattern | Severity | Weight | Description |
|---|---|---|---|---|---|
| SG-FS-001 | file_write | `open(..., 'w')`, `write()`, `Path.write_text()` | Medium | 15 | File write operation |
| SG-FS-002 | path_traversal | `../`, path manipulation outside bundle | Critical | 50 | Path traversal attempt |
| SG-FS-003 | sensitive_read | Read from `~/.ssh/`, `~/.aws/`, `~/.config/` | Critical | 50 | Sensitive file access |
| SG-FS-004 | tmp_execution | Write to `/tmp/` then execute | High | 40 | Staged execution pattern |
| SG-FS-005 | glob_expansion | Recursive glob of system directories | Medium | 20 | Enumeration attempt |
| SG-FS-006 | symlink_creation | `os.symlink()` | Medium | 20 | Symbolic link creation |

### 1.5 Dynamic Eval Rules

| Rule ID | Name | Pattern | Severity | Weight | Description |
|---|---|---|---|---|---|
| SG-EVAL-001 | python_eval | `eval()` | Critical | 50 | Python eval |
| SG-EVAL-002 | python_exec | `exec()` | Critical | 50 | Python exec |
| SG-EVAL-003 | js_eval | `eval()` in JS | Critical | 50 | JavaScript eval |
| SG-EVAL-004 | js_function | `new Function()` | Critical | 50 | Dynamic function creation |
| SG-EVAL-005 | compile | `compile()` in Python | High | 35 | Code compilation |
| SG-EVAL-006 | importlib | `importlib.import_module()` | Medium | 25 | Dynamic import |

### 1.6 Credential Access Rules

| Rule ID | Name | Pattern | Severity | Weight | Description |
|---|---|---|---|---|---|
| SG-CRED-001 | env_variable | `os.environ`, `os.getenv()` | Medium | 20 | Environment variable read |
| SG-CRED-002 | api_key_pattern | Regex: `[A-Za-z0-9]{32,}` in strings | Medium | 25 | Hardcoded API key/token |
| SG-CRED-003 | ssh_key_read | Read from `~/.ssh/` | Critical | 50 | SSH key access |
| SG-CRED-004 | aws_credentials | Read from `~/.aws/credentials` | Critical | 50 | AWS credential access |
| SG-CRED-005 | keychain_access | Keychain/keyring API calls | High | 40 | OS keychain access |
| SG-CRED-006 | token_exfil | Read env var + send HTTP request | Critical | 60 | Credential exfiltration pattern |

### 1.7 Injection Rules

| Rule ID | Name | Pattern | Severity | Weight | Description |
|---|---|---|---|---|---|
| SG-INJ-001 | prompt_override | System prompt manipulation patterns | High | 30 | Prompt injection attempt |
| SG-INJ-002 | command_injection | String concatenation into shell commands | Critical | 50 | Command injection vector |
| SG-INJ-003 | sql_injection | String concatenation into SQL | High | 35 | SQL injection vector |
| SG-INJ-004 | template_injection | Template string with user input | Medium | 25 | Template injection |

### 1.8 Obfuscation Rules

| Rule ID | Name | Pattern | Severity | Weight | Description |
|---|---|---|---|---|---|
| SG-OBF-001 | base64_payload | Base64-encoded strings >50 chars | High | 40 | Possible encoded payload |
| SG-OBF-002 | char_code_concat | `chr()` / `String.fromCharCode()` chains | High | 45 | Character code obfuscation |
| SG-OBF-003 | hex_encoding | Hex-encoded string sequences | Medium | 30 | Hex-encoded content |
| SG-OBF-004 | string_reversal | Reversed strings that decode to commands | High | 40 | String reversal tricks |
| SG-OBF-005 | minified_payload | Single-line >500 chars with no whitespace | Medium | 25 | Possible minified malicious code |

---

## 2. Risk Scoring Algorithm

### 2.1 Scoring Formula

```python
def calculate_score(findings: list[Finding]) -> RiskScore:
    """
    Score = Σ (finding.weight × severity_multiplier(finding.severity))

    Severity multipliers:
      LOW      = 0.5
      MEDIUM   = 1.0
      HIGH     = 1.5
      CRITICAL = 2.0

    Score is capped at 200 for display purposes but raw score is preserved.
    """
    MULTIPLIERS = {
        Severity.LOW: 0.5,
        Severity.MEDIUM: 1.0,
        Severity.HIGH: 1.5,
        Severity.CRITICAL: 2.0,
    }

    total = 0
    breakdown = defaultdict(int)

    for finding in findings:
        weighted = int(finding.weight * MULTIPLIERS[finding.severity])
        total += weighted
        breakdown[finding.category] += weighted

    severity = classify_severity(total)

    return RiskScore(
        total=total,
        severity=severity,
        breakdown=dict(breakdown),
        findings_count=len(findings),
    )
```

### 2.2 Severity Classification

```python
def classify_severity(score: int) -> Severity:
    if score <= 30:
        return Severity.LOW
    elif score <= 60:
        return Severity.MEDIUM
    elif score <= 100:
        return Severity.HIGH
    else:
        return Severity.CRITICAL
```

### 2.3 Scoring Invariants

1. Score is always deterministic: same findings → same score
2. Score is always non-negative
3. Score is additive: more findings → higher score
4. Individual finding contribution is transparent and traceable
5. No ML or probabilistic components in scoring

---

## 3. Policy Schema Specification

### 3.1 Full Schema

```yaml
# skillgate.yml — Policy Configuration
# Schema version: 1

version: "1"                          # Required. Schema version.
name: "production"                    # Required. Policy name.
description: "Production deployment"  # Optional. Description.

# Risk score thresholds
thresholds:
  max_score: 60                       # Block if total score exceeds this
  max_critical_findings: 0            # Block if critical findings exceed this
  max_high_findings: 2                # Block if high findings exceed this
  max_medium_findings: 10             # Block if medium findings exceed this

# Permission controls
permissions:
  allow_shell: false                  # Allow shell execution patterns
  allow_eval: false                   # Allow dynamic eval patterns
  allow_network: true                 # Allow network access
  allowed_domains:                    # Whitelist (only if allow_network: true)
    - "api.example.com"
    - "cdn.example.com"
  blocked_domains:                    # Blacklist (in addition to detection)
    - "*.ngrok.io"
    - "*.requestbin.com"
  allow_filesystem_write: false       # Allow file write operations
  allowed_paths:                      # Path whitelist for filesystem
    - "/tmp/skillgate-*"
    - "./output/"

# Rule configuration
rules:
  disabled:                           # Disable specific rules
    - "SG-NET-003"
    - "SG-FS-005"
  severity_overrides:                 # Override severity for rules
    "SG-FS-002": "critical"
    "SG-NET-001": "low"
  weight_overrides:                   # Override weight for rules
    "SG-SHELL-001": 60
  custom_paths:                       # Load additional rule files
    - "./custom_rules/"

# Enforcement mode
enforcement:
  mode: "enforce"                     # "enforce" (block) or "warn" (report only)
  fail_on_error: true                 # Fail if scanner encounters internal error
```

### 3.2 Policy Validation Rules

1. `version` must be `"1"` (future versions will be backward-compatible)
2. `name` must be a non-empty string, max 64 characters
3. `thresholds.max_score` must be 0–200
4. `thresholds.max_*_findings` must be non-negative integers
5. `permissions.allowed_domains` supports glob patterns
6. `rules.disabled` must reference valid rule IDs
7. `rules.severity_overrides` values must be valid severity levels
8. `enforcement.mode` must be `"enforce"` or `"warn"`

### 3.3 Policy Resolution Order

```
1. Built-in defaults
2. Preset policy (if specified)
3. Project-level skillgate.yml
4. CLI flags (highest priority)
```

---

## 4. Report Format Specification

### 4.1 JSON Report Schema

```json
{
  "$schema": "https://skillgate.io/schemas/report-v1.json",
  "version": "1.0.0",
  "timestamp": "2026-02-15T10:30:00Z",
  "scanner_version": "1.0.0",
  "bundle": {
    "name": "example-skill",
    "version": "0.1.0",
    "hash": "sha256:a1b2c3d4e5f6...",
    "root": "./skills/example-skill",
    "files_scanned": 12,
    "manifest_found": true
  },
  "risk_score": {
    "total": 75,
    "severity": "high",
    "breakdown": {
      "shell": 40,
      "network": 25,
      "credential": 10
    },
    "findings_count": 5
  },
  "findings": [
    {
      "rule_id": "SG-SHELL-001",
      "rule_name": "subprocess_call",
      "severity": "high",
      "category": "shell",
      "message": "Direct subprocess execution detected: subprocess.run() with shell=True",
      "file": "handler.py",
      "line": 42,
      "column": 5,
      "snippet": "    result = subprocess.run(cmd, shell=True, capture_output=True)",
      "weight": 40,
      "remediation": "Use subprocess.run() with a list of arguments instead of shell=True. Never pass user-controlled input to shell commands."
    }
  ],
  "policy": {
    "name": "production",
    "version": "1",
    "passed": false,
    "violations": [
      {
        "rule": "max_score",
        "reason": "Risk score 75 exceeds maximum allowed score of 60",
        "related_finding": null
      },
      {
        "rule": "allow_shell",
        "reason": "Shell execution is not permitted under this policy",
        "related_finding": "SG-SHELL-001"
      }
    ]
  },
  "attestation": null
}
```

---

## 5. SARIF Output Specification

### 5.1 SARIF 2.1.0 Mapping

```json
{
  "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json",
  "version": "2.1.0",
  "runs": [
    {
      "tool": {
        "driver": {
          "name": "SkillGate",
          "version": "1.0.0",
          "informationUri": "https://skillgate.io",
          "rules": [
            {
              "id": "SG-SHELL-001",
              "name": "subprocess_call",
              "shortDescription": {
                "text": "Direct subprocess execution detected"
              },
              "fullDescription": {
                "text": "Detects usage of subprocess.run(), subprocess.Popen(), and subprocess.call() which may execute arbitrary system commands."
              },
              "defaultConfiguration": {
                "level": "warning"
              },
              "helpUri": "https://skillgate.io/rules/SG-SHELL-001",
              "properties": {
                "tags": ["security", "shell", "agent-skill"],
                "security-severity": "7.5"
              }
            }
          ]
        }
      },
      "results": [
        {
          "ruleId": "SG-SHELL-001",
          "level": "warning",
          "message": {
            "text": "subprocess.run() call with shell=True detected. Risk weight: 40."
          },
          "locations": [
            {
              "physicalLocation": {
                "artifactLocation": {
                  "uri": "handler.py",
                  "uriBaseId": "%SRCROOT%"
                },
                "region": {
                  "startLine": 42,
                  "startColumn": 5
                }
              }
            }
          ],
          "fixes": [
            {
              "description": {
                "text": "Use subprocess.run() with a list of arguments instead of shell=True."
              }
            }
          ]
        }
      ]
    }
  ]
}
```

---

## 6. Ed25519 Signing Specification

### 6.1 Key Generation

```
Algorithm: Ed25519
Key format: PEM (PKCS8 for private, SubjectPublicKeyInfo for public)
Storage: ~/.skillgate/keys/
File permissions: 600 (private key), 644 (public key)
```

### 6.2 Signing Process

```
1. Serialize report to canonical JSON (sorted keys, no whitespace)
2. Compute SHA-256 hash of canonical JSON
3. Sign hash with Ed25519 private key
4. Encode signature as base64
5. Append attestation block to report
```

### 6.3 Verification Process

```
1. Extract attestation block from report
2. Remove attestation block to get original report
3. Serialize to canonical JSON
4. Compute SHA-256 hash
5. Verify signature using public key
6. Return pass/fail + signer identity
```

### 6.4 Attestation Block

```json
{
  "attestation": {
    "version": "1",
    "signer_public_key": "MCowBQYDK2VwAyEA...",
    "signature": "base64:MEUCIQDx...",
    "report_hash": "sha256:a1b2c3...",
    "signed_at": "2026-02-15T10:30:01Z",
    "scanner_version": "1.0.0"
  }
}
```

---

## 7. Skill Bundle Format Support

### 7.1 Supported Bundle Structures

**OpenClaw Standard:**
```
skill-name/
├── SKILL.md              # Manifest
├── handler.py            # Entry point
├── requirements.txt      # Dependencies
└── utils/
    └── helpers.py
```

**Node.js Skill:**
```
skill-name/
├── package.json          # Manifest
├── index.js              # Entry point
└── lib/
    └── handler.js
```

**Python Package Skill:**
```
skill-name/
├── pyproject.toml        # Manifest
├── skill.json            # Skill metadata
├── src/
│   └── skill/
│       ├── __init__.py
│       └── handler.py
└── tests/
    └── test_handler.py
```

### 7.2 Manifest Parsing Priority

```
1. SKILL.md (OpenClaw native)
2. skill.json (generic skill metadata)
3. package.json (Node.js skills)
4. pyproject.toml (Python skills)
```

If multiple manifests exist, the parser uses the highest-priority one and logs a warning.

### 7.3 Language Detection

| Extension | Language | AST Parser |
|---|---|---|
| `.py` | Python | `ast` (stdlib) |
| `.js` | JavaScript | `tree-sitter-javascript` |
| `.ts` | TypeScript | `tree-sitter-typescript` |
| `.sh`, `.bash` | Shell | `tree-sitter-bash` |
| `.mjs`, `.cjs` | JavaScript | `tree-sitter-javascript` |

Files with unrecognized extensions are analyzed with regex-only patterns.

---

## 8. Error Handling Specification

### 8.1 Exit Codes

| Code | Meaning | When |
|---|---|---|
| 0 | Success / Policy passed | Scan completed, no policy violations |
| 1 | Policy violation | Scan completed, policy check failed |
| 2 | Internal error | Scanner error (parse failure, I/O error, config error) |
| 3 | Invalid input | Invalid arguments, missing path, bad policy file |

### 8.2 Error Categories

```python
class SkillGateError(Exception):
    """Base exception for all SkillGate errors."""

class ParseError(SkillGateError):
    """Failed to parse skill bundle or manifest."""

class PolicyError(SkillGateError):
    """Invalid policy configuration."""

class SigningError(SkillGateError):
    """Failed to sign or verify report."""

class LicenseError(SkillGateError):
    """License validation failed."""

class ConfigError(SkillGateError):
    """Invalid configuration."""
```

### 8.3 Error Output Format

```json
{
  "error": {
    "code": "PARSE_ERROR",
    "message": "Failed to parse skill manifest: SKILL.md not found",
    "details": {
      "path": "./skills/broken-skill/",
      "expected": ["SKILL.md", "skill.json", "package.json"]
    }
  }
}
```

---

## 9. Configuration File Specification

### 9.1 Global Configuration

Location: `~/.skillgate/config.yml`

```yaml
# Global SkillGate configuration

# License key for Pro/Team features
license_key: "sg_live_abc123..."

# Default output format
output_format: "human"  # human | json | sarif

# Default policy preset
default_policy: "production"

# Signing key path
signing_key_path: "~/.skillgate/keys/signing_key.pem"

# Telemetry (opt-in)
telemetry:
  enabled: false

# LLM explanations (Pro+)
explain:
  enabled: false
  provider: "openai"  # or "anthropic"
  api_key_env: "SKILLGATE_LLM_API_KEY"
```

### 9.2 Environment Variables

| Variable | Description | Priority |
|---|---|---|
| `SKILLGATE_API_KEY` | License/API key | Overrides config file |
| `SKILLGATE_POLICY` | Default policy file/preset | Overrides config file |
| `SKILLGATE_OUTPUT` | Default output format | Overrides config file |
| `SKILLGATE_SIGNING_KEY` | Path to signing key | Overrides config file |
| `SKILLGATE_LOG_LEVEL` | Log level (DEBUG/INFO/WARN/ERROR) | Overrides config file |
| `SKILLGATE_NO_COLOR` | Disable colored output | For CI environments |

---

## 10. Performance Budgets

### 10.1 Scan Performance

| Metric | Budget | Measured On |
|---|---|---|
| Cold start (CLI) | <2s | MacBook Pro M-series |
| Scan 10 files | <3s | Typical skill bundle |
| Scan 100 files | <10s | Large skill bundle |
| Scan 500 files | <30s | Maximum expected size |
| Memory usage | <256MB | Any bundle size |
| Report generation | <500ms | After scan completes |
| Signature generation | <100ms | Ed25519 signing |
| Signature verification | <50ms | Ed25519 verification |

### 10.2 CI Performance

| Metric | Budget |
|---|---|
| GitHub Action total time | <60s (including install) |
| Install time (pip) | <15s |
| PR annotation generation | <2s |
| SARIF upload | <5s |

### 10.3 Optimization Constraints

- No network calls during local scan (zero latency from network)
- AST parsing is lazy (only parse files that match initial regex pre-filter)
- Rules are evaluated in parallel per file
- Large files (>100KB) are skipped with warning

---

*End of Technical Specification — Version 1.0.0*
