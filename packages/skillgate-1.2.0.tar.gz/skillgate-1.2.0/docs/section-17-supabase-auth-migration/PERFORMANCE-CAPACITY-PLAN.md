# Performance and Capacity Plan (Task 17.192)

Version: `v1`
Date: 2026-02-22

## Auth-Critical SLO Budgets

- `POST /auth/login`: p50 <= 180ms, p95 <= 700ms, p99 <= 1500ms
- `POST /auth/refresh`: p50 <= 140ms, p95 <= 500ms, p99 <= 1200ms
- `GET /auth/me`: p50 <= 80ms, p95 <= 350ms, p99 <= 900ms
- `POST /auth/logout`: p50 <= 120ms, p95 <= 400ms, p99 <= 900ms

## Capacity and Concurrency Strategy

- API workers: scale horizontally by CPU and auth request queue depth.
- DB pool defaults (already implemented):
  - pool size `20`
  - max overflow `10`
  - pre-ping enabled
- Read path split: optional read replica for profile/lookup endpoints.
- Supabase egress retries capped (`max_retries=2`) to avoid retry storms.

## Benchmark Scenarios

1. Login burst:
   - 100 RPS for 5 min, mixed success/failure ratio 70/30.
2. Token verification burst:
   - 300 RPS `GET /auth/me` for 10 min with valid JWTs.
3. Refresh rotation:
   - 80 RPS `POST /auth/refresh` for 10 min.
4. Mixed auth profile load:
   - 40% login, 30% refresh, 30% `/auth/me`.

## Alert Thresholds

- p95 breach > 2x budget for 5 min => incident.
- Auth 5xx > 1% for 5 min => automatic rollback trigger.
- Refresh failure > 5% for 5 min => rollback trigger.

## Evidence Source

- Synthetic load profile: `k6/load_test.js`.
- Required artifact: `artifacts/performance-benchmark-report.md`.
