# Boundaries: Supabase Auth Migration

## In Scope

1. Hosted auth provider abstraction with explicit configuration contract.
2. Supabase JWT verification and auth flow integration for hosted API.
3. Data ownership split for auth vs domain tables.
4. Migration scripts and compatibility-mode rollout.
5. Test harness migration to provider-agnostic matrix.
6. Cutover and rollback runbooks with evidence artifacts.

## Out of Scope

1. Core scanner/analyzer runtime behavior changes.
2. CLI deterministic/offline scan semantics changes.
3. Web UI redesign unrelated to auth-provider migration.
4. New billing features beyond parity with existing behavior.

## Hard Constraints (Fail-Closed)

1. No production cutover without compatibility matrix green.
2. No regression on security fixes `16.29`–`16.35`.
3. No unowned table or dual-writer ambiguity after ownership split.
4. No secrets in logs, artifacts, or CI output.
5. No migration step without rollback path.

## Compatibility Requirements

1. Existing API response contracts remain stable unless explicitly versioned.
2. `local` provider remains available until deprecation gate is approved.
3. Existing users can migrate without forced password reset or account lockout.

## Security Requirements

1. JWT validation must enforce issuer, audience, expiry, and algorithm allowlist.
2. Supabase service role usage must be least-privilege and server-only.
3. Rate limiting and abuse controls must remain effective under both providers.
4. Device flow and OAuth callback controls must remain hardened.
