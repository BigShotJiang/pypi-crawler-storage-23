# Validation Checks

Run from `/Users/spy/Documents/PY/AI/skillgate`.

## Core Quality Gates

```bash
./venv/bin/ruff check .
./venv/bin/mypy --strict skillgate/
./venv/bin/pytest -q
```

## Targeted Auth/DB Regression Gates

```bash
./venv/bin/pytest -q tests/unit/test_api/test_auth_api_keys.py
./venv/bin/pytest -q tests/unit/test_api/test_auth_edges.py
./venv/bin/pytest -q tests/unit/test_api/test_security_utils.py
./venv/bin/pytest -q tests/unit/test_api/test_rate_limit.py
./venv/bin/pytest -q tests/defense/test_security_fixes_16_29_35.py
```

## Hosted Path Dependency Gates

```bash
./venv/bin/pytest -q tests/unit/test_api/test_payments_resilience.py
./venv/bin/pytest -q tests/unit/test_api/test_teams_api.py
./venv/bin/pytest -q tests/unit/test_api/test_scans_api.py
./venv/bin/pytest -q tests/unit/test_api/test_hunt_api.py
./venv/bin/pytest -q tests/unit/test_api/test_retroscan_api.py
./venv/bin/pytest -q tests/unit/test_api/test_scan_rate_limit.py
```

## Docs Contract Checks

```bash
./venv/bin/pytest -q tests/docs/test_docs_exist.py
```

## RLS and RPC Contract Checks

```bash
./venv/bin/pytest -q tests/unit/test_api/test_auth_api_keys.py -k "rls or policy or authz"
./venv/bin/pytest -q tests/unit/test_api -k "rpc or function"
```

## Egress, Performance, and Cache Checks

```bash
./venv/bin/pytest -q tests/unit/test_api -k "timeout or retry or circuit"
./venv/bin/pytest -q tests/slo
./venv/bin/pytest -q tests/unit/test_api -k "cache or jwks"
```

## Frontend Contract Checks

```bash
cd web-ui && npx tsc --noEmit
```

## Evidence Location

Store gate evidence in:

- `docs/section-17-supabase-auth-migration/artifacts/`
