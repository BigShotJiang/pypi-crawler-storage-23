# Observability Runbook (16.27)

This runbook defines production metrics, SLOs, and first-response actions for auth + billing.

## SLOs

1. API availability (`/api/v1/health`): 99.9% monthly.
2. Checkout initiation success (`POST /api/v1/payments/checkout`): 99.5% rolling 7d.
3. Stripe webhook processing latency (ingest to processed): p95 < 60s.
4. Auth success rate (`/api/v1/auth/login` valid creds): 99.5% rolling 24h.

## Core Signals

1. Logs
- `request.completed` and `request.failed` in API middleware with `request_id`.
- Stripe webhook logs include `event_id`, `event_type`, `lag_seconds`.

2. Metrics
- `payments_checkout_attempts`
- `payments_checkout_failures`
- `payments_webhook_events`
- `payments_webhook_failures`
- `payments_webhook_lag_seconds`
- `payments_rate_limited`
- `auth_login_attempts`
- `auth_login_failures`
- `auth_rate_limited`

3. Traces
- Stripe external calls wrapped with circuit breaker spans (`stripe.*`).

## Alert Thresholds

1. `payments_webhook_failures > 0` for 10m.
2. `payments_webhook_lag_seconds` p95 > 120s for 15m.
3. `auth_login_failures / auth_login_attempts > 0.30` for 10m.
4. `payments_checkout_failures / payments_checkout_attempts > 0.10` for 10m.
5. Circuit breaker open for Stripe calls > 5m.

## Incident Triage

1. Verify API health:
```bash
curl -fsS "$API_BASE/api/v1/health"
```
2. Inspect dead-letter queue:
```bash
curl -fsS -H "X-Admin-Key: $SKILLGATE_ADMIN_KEY" "$API_BASE/api/v1/payments/webhook/dead-letter?limit=50"
```
3. Replay a failed Stripe event:
```bash
curl -fsS -X POST -H "X-Admin-Key: $SKILLGATE_ADMIN_KEY" "$API_BASE/api/v1/payments/webhook/replay/<event_id>"
```
4. Reconcile subscriptions:
```bash
curl -fsS -X POST -H "X-Admin-Key: $SKILLGATE_ADMIN_KEY" "$API_BASE/api/v1/payments/reconcile/subscriptions?limit=200"
```
5. If Stripe dependency is unstable, keep canary closed and trigger rollback drill:
```bash
RELEASE_ID="$GIT_SHA" DRY_RUN=true ./scripts/deploy/rollback_trigger.sh
```
