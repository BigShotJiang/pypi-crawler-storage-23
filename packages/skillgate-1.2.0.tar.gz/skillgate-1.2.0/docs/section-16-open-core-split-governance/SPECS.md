# Technical Specs (17.165-17.172)

## 17.165 Boundary Freeze

- Source of truth files:
  - `docs/open-core/PUBLIC_PRIVATE_MATRIX_v1.md`
  - `docs/open-core/public-export-policy.json`
- Requirement: every top-level path mapped to one owner: `public-ce`, `private-ee`, `shared-governed`.
- Test: denylist fixture must fail export gate when private assets are introduced.

## 17.166 Public Export CI Gate

- Enforce `python scripts/release/check_public_export.py --strict` in CI for public tags/branches.
- Gate must fail on denylist, ambiguous ownership, or missing policy references.
- Evidence: CI log artifact in section-16 artifacts folder.

## 17.167 Dual-Repo Release Contract

- Deterministic order:
  1. Validate CE tag + changelog + export gate.
  2. Validate EE tag + dependency compatibility matrix.
  3. Publish npm shim (optional channel) with provenance.
  4. Deploy web-ui with version pointers.
- Rollback contract must define reverse order and state checks.

## 17.168 Railway + Netlify Cutover Contract

- API migrations before worker restart.
- Health/smoke checks after each cutover step.
- Rollback trigger criteria are explicit (migration fail, auth callback fail, health endpoint fail).

## 17.169 CI Parity Matrix

- Required gates to preserve across split:
  - lint
  - type checks
  - tests
  - security scans
  - public export checks
- Any missing gate in either repo = NO-GO.

## 17.170 Legal and Policy Hardening

- Terms/Privacy/Legal templates must include explicit clauses for:
  - unauthorized access and hacking attempts
  - exploit development/distribution and malware use
  - bypassing safeguards, limits, licensing, or billing controls
  - suspension/termination and cooperation with lawful requests
- Text must remain customer-readable and enterprise-procurement usable.

## 17.171 Deployment Profile Lock

- Production domains, callback URLs, and CORS origins must be declared and validated.
- Fail-closed defaults: unknown domains are denied.
- Environment profile docs must match deployed config contract.

## 17.172 Split Readiness Report

- Required artifact: `split-readiness-report.md` in artifacts directory.
- Must include risk ledger, open issues, rollback owner, and GO/NO-GO sign-off.
