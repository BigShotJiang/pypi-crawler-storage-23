profile=staging
api_base_url=https://staging-api.skillgate.io/api/v1
web_base_url=https://staging.skillgate.io
cors_origins=https://staging.skillgate.io
oauth_callbacks=https://staging-api.skillgate.io/api/v1/auth/oauth/google/callback,https://staging-api.skillgate.io/api/v1/auth/oauth/github/callback
Environment contract check passed for profile=staging
