# Dual-Repo Release and Rollback Sequence (2026-02-21)

## Release Order (Forward)

```mermaid
flowchart TD
    A[ce_validate\nTag + changelog + public export gate] --> B[ee_validate\nTag + CE/EE compatibility matrix]
    B --> C[npm_publish\nOptional shim publish + provenance]
    C --> D[web_deploy\nDeploy web-ui + version pointers]
```

## Rollback Order (Reverse)

```mermaid
flowchart TD
    D1[web_deploy rollback\nPointer rollback + web healthcheck] --> C1[npm_publish rollback\nDist-tag rollback + wrapper smoke]
    C1 --> B1[ee_validate rollback\nEE rollback tag + matrix recheck]
    B1 --> A1[ce_validate rollback\nCE rollback tag + export gate recheck]
```

## State Check Contract

- Each release step requires explicit state checks and cannot be skipped.
- Rollback uses exact reverse ordering and also requires explicit state checks.
- Contract source of truth: `docs/open-core/dual-repo-release-contract.json`.
- Validator: `scripts/quality/check_dual_repo_release_contract.py`.
