# Dual-Repo Release Contract Validation (2026-02-21)

## Scope

- Contract: `docs/open-core/dual-repo-release-contract.json`
- Validator: `scripts/quality/check_dual_repo_release_contract.py`
- CI wiring: `.github/workflows/ci.yml` (`dual-repo-release-contract` job)

## Deterministic Release Order (Validated)

1. `ce_validate`
2. `ee_validate`
3. `npm_publish`
4. `web_deploy`

## Deterministic Rollback Order (Validated)

1. `web_deploy`
2. `npm_publish`
3. `ee_validate`
4. `ce_validate`

## Required State Checks

- Every release step includes non-empty `state_checks`.
- Every rollback step includes non-empty `state_checks`.
- Release steps require explicit `required_files` and `required_ci_jobs`.
- Referenced required files exist in the repository.
- Referenced CI jobs exist in `.github/workflows/ci.yml`.

## Validation Result

- Command: `./venv/bin/python scripts/quality/check_dual_repo_release_contract.py --output docs/section-16-open-core-split-governance/artifacts/dual-repo-release-contract-validation-2026-02-21.json`
- Result: `ok=true`, `errors=[]`

## Local Test Evidence

- `./venv/bin/pytest tests/unit/test_quality/test_dual_repo_release_contract.py -q`
- Result: `2 passed`
