# Mandatory Agent Skills and Usage Order

This file defines required skill usage for Section 16 execution.

## Mandatory Skills (Current Workspace)

- `token-efficient-coding`
- `python-code-style`
- `pytest-runner`
- `skillgate-agent-tool`
- `production-hardening-gate`

## Phase-to-Skill Mapping

### Design + Boundary Lock

Required:

- `token-efficient-coding`
- `skillgate-agent-tool`

### Implementation

Required:

- `token-efficient-coding`
- `python-code-style`

### Test and Validation

Required:

- `pytest-runner`
- `skillgate-agent-tool`

### Pre-Release Readiness

Required:

- `production-hardening-gate`

## Enforcement Rules

1. No task may be marked `Ready for Gate` without listed validation checks.
2. No split claim may ship without public export gate evidence.
3. No production GO claim may ship without release decision record.
4. If a required skill is unavailable, implementation is blocked until fallback is documented.
5. Strictly follow `/Users/spy/Documents/PY/AI/skillgate/docs/section-16-open-core-split-governance`.
