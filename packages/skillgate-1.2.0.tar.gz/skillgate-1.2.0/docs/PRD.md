# SkillGate — Product Requirements Document (PRD)

**Product:** SkillGate  
**Domain:** skillgate.io  
**Version:** 1.0.0  
**Status:** Execution (Pre-GA)  
**Last Updated:** 2026-02-19  
**Classification:** Internal — Confidential  

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Problem Statement](#2-problem-statement)
3. [Product Vision](#3-product-vision)
4. [Target Users & Personas](#4-target-users--personas)
5. [Market Context & Competitive Landscape](#5-market-context--competitive-landscape)
6. [Product Strategy](#6-product-strategy)
7. [Core Product Requirements](#7-core-product-requirements)
8. [Feature Specifications](#8-feature-specifications)
9. [Non-Functional Requirements](#9-non-functional-requirements)
10. [Pricing & Monetization](#10-pricing--monetization)
11. [Success Metrics & KPIs](#11-success-metrics--kpis)
12. [Risk Assessment](#12-risk-assessment)
13. [Out of Scope](#13-out-of-scope)
14. [Glossary](#14-glossary)

---

## 1. Executive Summary

SkillGate is a CI/CD-integrated policy enforcement tool that blocks unsafe agent skills (OpenClaw and related ecosystems) before deployment. It provides deterministic policy enforcement, signed attestation reports, and native CI/CD workflow integration, enabling development teams to govern AI agent extensibility without fear of malware, data exfiltration, or supply-chain compromise.

**Business Objective:** Build a durable control-plane business with developer-led adoption (CLI + CI integrations), paid team expansion, and selective enterprise contracts that start in the low five figures annually and expand by deployment scope.

**Core Differentiator:** SkillGate is not a scanner. It is an enforcement gate and control plane. While free scanners detect threats, SkillGate enforces organizational policy, signs attestation evidence, and integrates directly into merge workflows to block unsafe skills before they reach production.

### 1.1 Delivery Reality Check (2026-02-18)

- Core platform, entitlement paths, and docs infrastructure are implemented and test-covered.
- CI now includes dedicated reliability gates (false-negative corpus/mutation and SLO suites).
- Claim integrity is enforced by CI: active pricing claims must map to YAML ledger entries, entitlement contracts, proof surfaces, and tests.
- Product is still **Pre-GA**: at least one reliability gate currently fails (`tests/slo/test_false_positive_rate.py`), so this PRD remains target-state, not fully shipped-state.
- Launch decision must follow `docs/IMPLEMENTATION-PLAN.md` ship gates and `docs/ENTERPRISE-READINESS-CHECKLIST.md` sign-offs.

---

## 2. Problem Statement

### 2.1 Ecosystem Threat Reality

The OpenClaw agent ecosystem faces an active supply-chain security crisis:

- **900+ confirmed malicious skills** on ClawHub (Bitdefender, Feb 2026)
- **341 coordinated data exfiltration campaigns** documented (Koi Security, Feb 2026)
- **135,000+ OpenClaw instances** exposed to public internet (SecurityScorecard, Feb 2026)
- **3 critical RCE CVEs** with public exploits (CVSS 8.8)
- Skills execute with broad permissions: filesystem, network, shell, subprocess, credential access

### 2.2 Gap Analysis

| Existing Solution | What It Does | What It Lacks |
|---|---|---|
| Bitdefender AI Skills Checker | Free pattern-based scanning + AI risk report | No CI enforcement, no policy, no attestations |
| SClawHub (Chrome extension) | Trust scores/badges on ClawHub pages | Browser-only, no CI, no governance |
| OpenClaw + VirusTotal | Hash-based reputation scanning at install | Zero-day blind, no policy, no CI gating |
| Cisco MCP Scanner (OSS) | Static + semantic + behavioral analysis, SARIF output | No commercial model, no policy engine, no attestations |
| General SAST/SCA (Snyk, etc.) | Code-focused security scanning | Not agent-skill-aware, not AI-specific |

### 2.3 Unmet Need

Teams deploying OpenClaw in production lack:

1. **Enforcement** — the ability to *block* unsafe skills from being merged, not just detect them
2. **Policy governance** — configurable, versioned rules that enforce organizational standards
3. **Audit evidence** — signed, timestamped attestation reports for compliance and traceability
4. **Workflow integration** — native CI/CD tooling that becomes part of the standard merge process

---

## 3. Product Vision

**Vision Statement:**  
SkillGate is the required gate before agent skills reach production — providing deterministic policy enforcement, CI-native blocking, and signed attestation evidence for teams deploying AI agents.

**Positioning:**  
"Not just a scanner. The CI gatekeeper for agent skills."

**Category:**  
Agent Skill CI Security & Governance

**Strategic Direction:**

- Phase 1: OpenClaw skill governance (CLI + GitHub Action)
- Phase 2: Expand to MCP, LangChain, and broader agent framework governance
- Phase 3: Become the "Agent Governance Engine" across ecosystems

---

## 4. Target Users & Personas

### 4.1 Primary Persona: Dev Team Lead / Platform Engineer

- **Role:** Manages 5–50 engineers deploying OpenClaw-based workflows
- **Pain:** "How do we prevent unsafe skills from being merged?"
- **Behavior:** Evaluates tools via GitHub, installs via CI config, values speed and low friction
- **Decision driver:** Security posture without slowing velocity
- **Budget authority:** $50–$200/mo without procurement process

### 4.2 Secondary Persona: Security-Conscious Solo Developer

- **Role:** Individual builder using OpenClaw for personal/freelance work
- **Pain:** "Is this skill from ClawHub safe to install?"
- **Behavior:** CLI-first, values transparency and control
- **Decision driver:** Peace of mind, signed proof of safety
- **Budget authority:** $0–$49/mo

### 4.3 Tertiary Persona: Engineering Manager / CISO (Enterprise)

- **Role:** Oversees agent deployment policy across organization
- **Pain:** "We need audit evidence and consistent enforcement"
- **Behavior:** Evaluates based on compliance, integration, and vendor trust
- **Decision driver:** Governance, audit readiness, policy control
- **Budget authority:** starts around $10K/year with procurement-led expansion by scope

### 4.4 Anti-Personas (Not Targeting)

- Enterprise CISOs with 12-month procurement cycles (initially)
- Non-technical business users
- Teams not using CI/CD
- Organizations with no agent/skill usage

---

## 5. Market Context & Competitive Landscape

### 5.1 Competitive Feature Matrix

| Capability | Open-Source Scanners | Marketplace Risk Scores | General SAST | **SkillGate** |
|---|---|---|---|---|
| Static detection | ✅ | Partial | ✅ | ✅ |
| Semantic analysis | Some | No | No | ✅ (controlled) |
| CI/CD blocking | Limited | No | Generic | **✅ Native** |
| Policy enforcement | ❌ | ❌ | Limited | **✅ Core** |
| Per-environment rules | ❌ | ❌ | Rare | **✅** |
| Signed attestations | ❌ | ❌ | Rare | **✅** |
| Audit-ready reports | ❌ | ❌ | Limited | **✅** |
| Developer-first UX | Varies | No | Often heavy | **✅** |
| Commercial support | ❌ | ❌ | ✅ | **✅** |
| Built for agent skills | Partial | Partial | ❌ | **✅ Purpose-built** |

### 5.2 Strategic Positioning vs. Claude Code Security + Cisco MCP Scanner

| Capability | Claude Code Security (Feb 2026 launch framing) | Cisco MCP Scanner | **SkillGate** |
|---|---|---|---|
| Vulnerability reasoning | ✅ | ✅ | ✅ (multi-engine, deterministic gate path) |
| Suggested remediation | ✅ | Limited | Planned with governance checkpoints |
| Hard policy enforcement gate | Partial workflow-dependent | ❌ | **✅ Core** |
| Signed approval checkpoints | Workflow-dependent | ❌ | **✅** |
| Signed evidence/proof-pack export | Not primary product claim | ❌ | **✅** |
| Deterministic governance for AI tool actions | Not primary category claim | ❌ | **✅** |

Positioning contract:

- Claude-class reasoning is treated as an input signal, not the control plane.
- SkillGate owns enforcement, approvals, deterministic decisions, and signed audit evidence.
- "Governance + enforcement + evidence" claims must map to test-backed proof surfaces in implementation plan and CI gates.

| Capability | Cisco MCP Scanner | **SkillGate** |
|---|---|---|
| Static scanning | ✅ | ✅ |
| Semantic reasoning | ✅ | Optional |
| CI enforcement gating | ✅ (SARIF) | ✅ (gate + exit codes + policy) |
| Policy engine | ❌ | **✅** |
| Signed attestations | ❌ | **✅** |
| Hosted tier | ❌ | Optional |
| Commercial licensing & support | ❌ | **✅** |
| Customer billing | ❌ | **✅** |

Proof-surface references for positioning claims:

- Runtime/policy gating: `skillgate/core/gateway/runtime_engine.py`
- Approval verification: `skillgate/core/gateway/approval.py`
- Governed orchestrator flow: `skillgate/core/orchestrator/pipeline.py`
- Signed evidence/proof pack: `skillgate/core/orchestrator/evidence.py`
- CI claim and governance gates: `scripts/quality/check_claim_ledger.py`, `scripts/quality/check_governance_scope_gate.py`

### 5.3 Market Window

- **6–12 month window** to establish market leadership before competitors add governance features
- Speed to 50% developer mindshare is the critical success factor
- Distribution moat (GitHub Action namespace, PyPI package) matters more than code moat

---

## 6. Product Strategy

### 6.1 Core Strategy: Win the Developer Workflow

SkillGate wins by embedding into the CI/CD merge process — not by building dashboards or marketing.

**Strategic principle:** Become the PR check teams depend on. Once configured, replacing SkillGate requires reconfiguring pipelines, rewriting enforcement logic, and coordinating across teams.

### 6.2 Distribution Strategy

1. **CLI** — direct developer adoption via `pip install skillgate`
2. **GitHub Action** — viral distribution through GitHub Marketplace
3. **GitLab CI template** — secondary CI platform coverage
4. **Content/SEO** — high-intent technical content targeting "OpenClaw skill security" searches

### 6.3 Growth Model: Product-Led Growth (PLG)

```
Free (lead capture) → Pro (individual value) → Team (workflow lock-in) → Enterprise (governance)
```

- Free tier drives adoption and brand awareness
- Pro/Team tiers capture revenue from workflow value
- Enterprise tier converts high-ACV accounts from organic inbound

### 6.4 Revenue Architecture (Planning Model)

**Target:** ~$1M ARR within 18-24 months, with Team volume plus selective Enterprise expansion.

| Segment | Count | ACV | Revenue |
|---|---|---|---|
| Pro ($49/mo) | 400 | $588 | $235K |
| Team (reprice in progress) | 320 | $1,500 | $480K |
| Enterprise (annual contracts, Contact Sales) | 12-20 | starts around $10K and scales with scope | $120K-$500K+ |
| **Total** | **732-740** | | **~$0.84M-$1.22M** |

---

## 7. Core Product Requirements

### 7.1 Functional Requirements

#### FR-1: Skill Bundle Parsing
- **FR-1.1:** Parse skill manifest files (SKILL.md, skill.json, package.json equivalents)
- **FR-1.2:** Traverse and analyze all source files within a skill bundle
- **FR-1.3:** Support local directory scanning and remote URL scanning (ClawHub links)
- **FR-1.4:** Extract metadata: name, version, author, declared permissions, dependencies

#### FR-2: Static Analysis Engine
- **FR-2.1:** AST-based pattern detection for dangerous code constructs
- **FR-2.2:** Regex-based detection for known malicious patterns
- **FR-2.3:** Detection categories:
  - Shell execution (`subprocess`, `os.system`, `exec`, backtick execution)
  - Network calls (HTTP requests, DNS lookups, socket operations)
  - File system operations (read/write outside declared paths)
  - Dynamic code evaluation (`eval`, `exec`, `Function()`)
  - Credential/secret access patterns (env var reads, key file access)
  - Prompt injection patterns
  - Obfuscation indicators (base64 encoded payloads, char code concatenation)
- **FR-2.4:** Support multiple languages: Python, JavaScript/TypeScript, Shell/Bash
- **FR-2.5:** Extensible rule format for custom detection patterns

#### FR-3: Risk Scoring Engine
- **FR-3.1:** Weighted scoring model (deterministic, not ML)
- **FR-3.2:** Score categories with configurable weights:

| Category | Default Weight |
|---|---|
| Shell execution | +40 |
| Dynamic code eval | +35 |
| External network call | +25 |
| Credential access pattern | +50 |
| Prompt injection pattern | +20 |
| File system write | +15 |
| Obfuscation | +45 |

- **FR-3.3:** Risk severity buckets: Low (0–30), Medium (31–60), High (61–100), Critical (100+)
- **FR-3.4:** Per-finding severity with human-readable explanation
- **FR-3.5:** Aggregate score with breakdown

#### FR-4: Policy Enforcement Engine
- **FR-4.1:** YAML-based policy configuration (`skillgate.yml`)
- **FR-4.2:** Policy rules:
  - Maximum allowed risk score threshold
  - Allow/deny shell execution
  - Allowed network domains whitelist
  - Allowed filesystem paths
  - Required/prohibited patterns
  - Severity escalation overrides
- **FR-4.3:** Policy presets: `development`, `staging`, `production`, `strict`
- **FR-4.4:** Policy inheritance and override (project-level overrides org-level)
- **FR-4.5:** Pass/fail determination based on policy evaluation
- **FR-4.6:** Deterministic exit codes: 0 (pass), 1 (policy violation), 2 (internal error)

#### FR-5: CLI Interface
- **FR-5.1:** Primary commands:
  - `skillgate scan <path>` — scan a skill bundle
  - `skillgate scan <url>` — scan a remote skill (ClawHub URL)
  - `skillgate verify <report>` — verify a signed attestation report
  - `skillgate init` — generate default `skillgate.yml` policy file
  - `skillgate rules` — list available detection rules
- **FR-5.2:** Output formats: human-readable (default), JSON, SARIF
- **FR-5.3:** Flag `--enforce` to apply policy and produce exit code
- **FR-5.4:** Flag `--policy <file>` to specify custom policy file
- **FR-5.5:** Flag `--sign` to generate signed attestation (Pro+)
- **FR-5.6:** Flag `--output <format>` for output format selection

#### FR-6: CI/CD Integration
- **FR-6.1:** GitHub Action (`skillgate/scan-action@v1`)
  - Inputs: skill path, policy file, output format, fail-on-violation
  - Outputs: risk score, pass/fail, findings count, report artifact
- **FR-6.2:** PR status check integration (pass/fail based on policy)
- **FR-6.3:** Inline PR annotations on risky lines/files
- **FR-6.4:** SARIF report upload to GitHub Security tab
- **FR-6.5:** GitLab CI template (`.gitlab-ci.yml` include)
- **FR-6.6:** Generic CI support via CLI exit codes

#### FR-7: Signed Attestation Reports
- **FR-7.1:** Ed25519 digital signature of scan results
- **FR-7.2:** Report contents:
  - SHA-256 hash of scanned artifact
  - Timestamp (ISO 8601)
  - Risk score and severity
  - Policy applied (name + version)
  - Individual findings
  - Scanner version
- **FR-7.3:** JSON report format with detached signature
- **FR-7.4:** Verification command: `skillgate verify report.json`
- **FR-7.5:** Shareable verification (hosted endpoint, Phase 2)

#### FR-8: Semantic Analysis (Enhancement, Post-MVP)
- **FR-8.1:** LLM-assisted finding explanation (not used for detection logic)
- **FR-8.2:** Remediation suggestions per finding
- **FR-8.3:** Context-aware false-positive reduction
- **FR-8.4:** Explanation output appended to findings (opt-in)
- **FR-8.5:** Deterministic detection remains primary — LLM is explanatory only

### 7.2 Non-Functional Requirements

#### NFR-1: Performance
- **NFR-1.1:** Scan completes in <10 seconds for typical skill bundles (<500 files)
- **NFR-1.2:** CLI startup time <2 seconds
- **NFR-1.3:** CI Action completes within 60 seconds including setup

#### NFR-2: Reliability
- **NFR-2.1:** Zero false negatives for known critical patterns (shell exec, eval, credential exfil)
- **NFR-2.2:** False positive rate <5% on curated test corpus
- **NFR-2.3:** Graceful degradation: if LLM unavailable, deterministic analysis still runs

#### NFR-3: Security
- **NFR-3.1:** No skill code is transmitted to external services (local-first by default)
- **NFR-3.2:** API keys stored securely (OS keychain or env var)
- **NFR-3.3:** Attestation signing keys generated locally and never transmitted
- **NFR-3.4:** HTTPS-only for any hosted service communication

#### NFR-4: Compatibility
- **NFR-4.1:** Python 3.10+ support
- **NFR-4.2:** macOS, Linux, Windows support
- **NFR-4.3:** Docker image available
- **NFR-4.4:** GitHub Actions runner compatibility (ubuntu-latest, macos-latest)

#### NFR-5: Maintainability
- **NFR-5.1:** >90% test coverage on core engine modules
- **NFR-5.2:** Modular architecture with clear separation of concerns
- **NFR-5.3:** Comprehensive inline documentation and docstrings
- **NFR-5.4:** Automated CI pipeline for the product itself

---

## 8. Feature Specifications

### 8.1 Feature Priority Matrix

| Feature | Priority | MVP | Monetizable | Sprint |
|---|---|---|---|---|
| Static Analysis Engine | P0 — Critical | ✅ | Foundation | Sprint 1 |
| Risk Scoring | P0 — Critical | ✅ | Foundation | Sprint 1 |
| CLI Interface | P0 — Critical | ✅ | Foundation | Sprint 1 |
| Policy Engine | P0 — Critical | ✅ | ✅ High | Sprint 2 |
| GitHub Action | P0 — Critical | ✅ | ✅ High | Sprint 3 |
| Signed Attestations | P1 — High | ✅ | ✅ High | Sprint 4 |
| SARIF Output | P1 — High | ✅ | ✅ Medium | Sprint 3 |
| GitLab CI Template | P2 — Medium | Post-MVP | ✅ Medium | Sprint 5 |
| Minimal Web Dashboard | P2 — Medium | Post-MVP | ✅ Medium | Sprint 5 |
| LLM Explanations | P3 — Low | Post-MVP | ✅ Low | Sprint 6 |
| Remote URL Scanning | P2 — Medium | Post-MVP | ✅ Low | Sprint 5 |

### 8.2 Feature-Test Mapping

Every feature must ship with corresponding tests:

| Feature | Unit Tests | Integration Tests | E2E Tests |
|---|---|---|---|
| Skill Parser | File parsing, manifest extraction | Multi-file bundles | Full scan pipeline |
| Static Analysis | Per-rule detection accuracy | Cross-rule interaction | Known malware samples |
| Risk Scoring | Weight calculation, threshold logic | Multi-finding aggregation | Score consistency |
| Policy Engine | Rule evaluation, preset loading | Policy + findings interaction | CI exit code validation |
| CLI | Argument parsing, output format | Full command execution | Real-world skill scan |
| GitHub Action | Action input/output | PR annotation generation | Live PR workflow |
| Attestations | Signing, verification | Report integrity | Tamper detection |

---

## 9. Non-Functional Requirements

### 9.1 Quality Standards

- All code must pass linting (ruff/flake8) and type checking (mypy) with zero errors
- Every public API function must have docstrings
- Every module must have >90% test coverage
- All tests must pass before merge (enforced via CI)
- Security-sensitive code requires code review

### 9.2 Deployment Requirements

- CLI published to PyPI as `skillgate`
- GitHub Action published to GitHub Marketplace
- Docker image published to Docker Hub / GHCR
- Semantic versioning (SemVer 2.0)
- Changelog maintained per release
- Every release tagged and signed

### 9.3 Documentation Requirements

- README with quick-start guide
- CLI usage documentation
- Policy file reference
- Rule catalog with examples
- GitHub Action usage guide
- API reference (if hosted tier)
- Contributing guide

---

## 10. Pricing & Monetization

### 10.1 Tier Structure

| Tier | Price | Target | Key Features |
|---|---|---|---|
| **Free** | $0 | Individual devs | 3 scans/day, basic risk score, top 5 findings |
| **Pro** | $49/mo | Solo dev / freelancer | Unlimited scans, policy customization, signed reports, email support |
| **Team** | Repricing in progress | Engineering teams | CI integration, PR blocking, fleet governance, central team visibility |
| **Enterprise** | Contact Sales (annual contract) | Regulated and large organizations | Runtime governance controls, audit exports, deployment controls, dedicated support |

### 10.2 Monetization Gates

| Feature | Free | Pro | Team | Enterprise |
|---|---|---|---|---|
| Local CLI scan | 3/day | ✅ Unlimited | ✅ | ✅ |
| Risk scoring | Basic | Full | Full | Full |
| Policy enforcement | ❌ | ✅ | ✅ | ✅ |
| Signed attestations | ❌ | ✅ | ✅ | ✅ |
| CI/CD blocking | ❌ | ❌ | ✅ | ✅ |
| PR annotations | ❌ | ❌ | ✅ | ✅ |
| Dashboard | ❌ | ❌ | ✅ | ✅ |
| Custom policy packs | ❌ | ❌ | ❌ | ✅ |
| Audit export bundles | ❌ | ❌ | ❌ | ✅ |
| Dedicated signing keys | ❌ | ❌ | ❌ | ✅ |

### 10.3 Licensing Model

- Free tier: no license key required
- Pro: API key validated against hosted license service
- Team: organization-level license with seat management
- Enterprise: contract-based, optional on-prem license validation
- Public pricing copy follows a truth-first rule: only claims backed by entitlement gates and tests can ship.

---

## 11. Success Metrics & KPIs

### 11.1 Launch Metrics (First 90 Days)

| Metric | Target |
|---|---|
| GitHub Action installs | 500 |
| PyPI downloads | 2,000 |
| Free tier signups | 1,000 |
| Paying users (Pro + Team) | 50–100 |
| MRR | $3K–$8K |
| False positive rate | <5% |

### 11.2 Growth Metrics (6–12 Months)

| Metric | Target |
|---|---|
| Paying users | 500 |
| MRR | $25K–$50K |
| Enterprise pilots | 5–10 |
| Monthly active scans | 50,000 |
| Churn rate | <5%/month |

### 11.3 Scale Metrics (18–24 Months)

| Metric | Target |
|---|---|
| ARR | ~$1M |
| Paying users | 700-1,000 |
| Enterprise accounts | 10-30 |
| GitHub Action installs | 5,000+ |
| Net Revenue Retention | >110% |

---

## 12. Risk Assessment

| Risk | Probability | Impact | Mitigation |
|---|---|---|---|
| Cisco MCP Scanner adds policy engine | Medium | High | Ship first, establish workflow lock-in, build distribution moat |
| OpenClaw adds native governance | Low-Medium | High | Expand beyond OpenClaw to MCP/LangChain by Month 6 |
| Market commoditization | Medium | Medium | Focus on workflow lock-in, not feature parity |
| Low initial adoption | Medium | Medium | Strong free tier, content marketing, direct developer outreach |
| False positives erode trust | Medium | High | Invest heavily in test corpus, transparent scoring, easy overrides |
| Overbuilding before revenue | High | High | Strict 4-week MVP constraint, charge at Week 4 |

---

## 13. Out of Scope

The following are explicitly **NOT** in scope for the MVP or near-term roadmap:

- Dynamic sandbox execution / runtime behavioral analysis
- Marketplace crawling / continuous monitoring engine
- Enterprise SSO (SAML/OIDC)
- Heavy analytics dashboards
- Cross-framework universal agent platform support (initially)
- Mobile applications
- On-premise deployment (initially)
- White-label / OEM licensing

These may be considered for Phase 2+ based on market traction and customer demand.

---

## 14. Glossary

| Term | Definition |
|---|---|
| **Skill** | An extension/plugin for an AI agent framework (e.g., OpenClaw) that adds capabilities |
| **Skill Bundle** | A directory or package containing skill source code, manifest, and configuration |
| **ClawHub** | The public marketplace/registry for OpenClaw skills |
| **Policy** | A set of configurable rules that define what is allowed/blocked for skill behavior |
| **Attestation** | A digitally signed report providing cryptographic proof of a scan result |
| **Finding** | A single detected issue or risk within a scanned skill |
| **Risk Score** | A weighted numerical assessment of a skill's security risk level |
| **SARIF** | Static Analysis Results Interchange Format — a standard JSON format for static analysis results |
| **Gate/Gating** | The act of blocking a merge or deployment based on policy evaluation failure |

---

*End of PRD — Version 1.0.0*
