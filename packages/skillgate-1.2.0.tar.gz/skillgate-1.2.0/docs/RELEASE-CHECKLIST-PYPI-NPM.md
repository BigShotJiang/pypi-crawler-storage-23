# Strict Release Checklist (PyPI + npm)

Use this checklist for every release.

## 0) Preconditions

- Branch is merged to `main`.
- Version is correct (`skillgate/version.py` and package metadata).
- Local production gate is green.

## 1) Hard gates that MUST pass first

Required local gate command:

```bash
cd /Users/spy/Documents/PY/AI/skillgate
source venv/bin/activate
./scripts/deploy/local_production_go_deploy.sh --profile production --skip-pypi --skip-npm
```

GitHub CI gates are disabled for release decisions.

## 2) Python package (PyPI) — strict pre-publish validation

From repo root:

```bash
source venv/bin/activate
./scripts/test_package_release.sh
python -m build --sdist --wheel --no-isolation --outdir /tmp/skillgate-dist
python -m twine check /tmp/skillgate-dist/*
pytest -m slow tests/e2e/test_packaging_release.py -v
```

Optional leak sanity for built artifacts:

```bash
tar -tzf /tmp/skillgate-dist/skillgate-*.tar.gz | grep -E "(\.env|id_rsa|secret|token)" || true
python - <<'PY'
import zipfile, glob
wheel = sorted(glob.glob('/tmp/skillgate-dist/skillgate-*.whl'))[-1]
with zipfile.ZipFile(wheel) as z:
    names = z.namelist()
    suspect = [n for n in names if any(k in n.lower() for k in ['.env','id_rsa','secret','token'])]
print('suspect_files=', suspect)
PY
```

Publish commands:

```bash
# TestPyPI (recommended first)
python -m twine upload --repository testpypi /tmp/skillgate-dist/*

# Production PyPI
python -m twine upload /tmp/skillgate-dist/*
```

## 3) npm shim package (`@skillgate-io/cli`) — strict pre-publish validation

From repo root:

```bash
source venv/bin/activate
pytest -m slow tests/e2e/test_npm_shim_wrapper.py -v
```

From `npm-shim/`:

```bash
npm pkg get name version files bin.skillgate engines.node
npm pack --json > /tmp/npm-shim-pack.json
node -e "const fs=require('fs');const d=JSON.parse(fs.readFileSync('/tmp/npm-shim-pack.json','utf8'));const p=d[0];console.log(JSON.stringify({filename:p.filename,integrity:p.integrity,shasum:p.shasum,files:(p.files||[]).map(f=>f.path)},null,2));"
npm publish --access public --provenance --dry-run
```

Tarball must contain only:

- `README.md`
- `bin/skillgate.js`
- `package.json`

Publish command:

```bash
# requires npm auth/token
npm publish --access public --provenance
```

## 4) Public CE governance gates (must stay green)

In the public CE repo:

```bash
python3 scripts/release/check_public_export.py --strict
python3 scripts/quality/check_dual_repo_release_contract.py
```

## 5) Post-publish verification

```bash
# PyPI
python3 -m pip index versions skillgate | head -20

# npm
npm view @skillgate-io/cli version
```

Runtime sanity checks:

```bash
python3 -m pipx install skillgate
skillgate version

npx @skillgate-io/cli version
```

## 6) Rollback readiness

- Keep previous known-good version numbers for both channels.
- PyPI rollback strategy: publish patch forward quickly (PyPI does not allow overwrite).
- npm rollback strategy: update dist-tag or publish patch.
- Re-run CE governance checks after rollback actions.
