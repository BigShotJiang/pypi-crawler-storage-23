# SkillGate Marketing Implementation Backlog

**Scope:** Task mapping and execution tracking for `17.85`-`17.97`  
**Status:** Active (updated 2026-02-19)

## Task-to-File Mapping

| Task | Scope | Concrete Files | Status |
|---|---|---|---|
| 17.85 | Homepage narrative rewrite to control-plane framing | `web-ui/src/components/sections/HeroSection.tsx`, `web-ui/src/app/pricing/page.tsx` | Done |
| 17.86 | Add SkillGate Control Stack visual above pricing | `web-ui/src/components/sections/PricingSection.tsx`, `web-ui/src/lib/pricing.ts` | Done |
| 17.87 | Re-architect pricing hierarchy by control layers | `web-ui/src/components/sections/PricingSection.tsx`, `web-ui/src/lib/pricing.ts` | Done |
| 17.88 | Tier copy refactor (Free/Pro/Team/Enterprise narrative) | `web-ui/src/lib/pricing.ts`, `web-ui/src/components/sections/PricingSection.tsx`, `web-ui/src/app/pricing/page.tsx` | Done |
| 17.89 | Team fleet governance surfacing | `web-ui/src/lib/pricing.ts`, `web-ui/src/__tests__/pricing.test.ts` | Done |
| 17.90 | Enterprise card redesign and strategic label | `web-ui/src/components/sections/PricingSection.tsx`, `web-ui/src/lib/pricing.ts` | Done |
| 17.91 | Expandable deep compare matrix under pricing | `web-ui/src/components/sections/PricingSection.tsx`, `web-ui/src/lib/pricing.ts` | Done |
| 17.92 | Pricing-to-entitlement consistency assertions | `web-ui/src/lib/pricing.ts`, `web-ui/src/__tests__/pricing.test.ts` | Done |
| 17.93 | Enterprise procurement path hardening in pricing/docs links | `web-ui/src/lib/pricing.ts`, `web-ui/src/app/pricing/page.tsx`, `web-ui/src/components/sections/PricingSection.tsx` | Done |
| 17.94 | Conversion instrumentation for control stack and matrix | `web-ui/src/lib/analytics.ts`, `web-ui/src/components/sections/PricingSection.tsx` | Done |
| 17.95 | A/B framework for pricing narrative order | `web-ui/src/components/sections/PricingSection.tsx` | Done |
| 17.96 | Sales enablement package | `docs/SALES-CONTROL-PLANE-PLAYBOOK.md` | Done |
| 17.97 | Launch gate + rollback checklist for pricing repositioning | `docs/PRICING-ROLLOUT-LAUNCH-GATE.md` | Done |

## Validation Matrix

| Area | Validation | Files |
|---|---|---|
| Pricing data contract | Unit tests for tiers, control stack, matrix, and progression | `web-ui/src/__tests__/pricing.test.ts` |
| Analytics payload integrity | Existing analytics unit suite + new event types compile through type checks | `web-ui/src/__tests__/analytics.test.ts`, `web-ui/src/lib/analytics.ts` |
| UI behavior and content | E2E assertions for control-plane hero and pricing stack visibility | `web-ui/e2e/marketing.spec.ts` |

## Remaining Operational Decisions (if needed)

1. Final Enterprise accent palette (amber/red vs alternate brand-safe variant).
2. A/B traffic split policy (current deterministic 50/50 by local assignment).
3. Sales CTA routing (`/contact` flow fields and CRM integration depth).
