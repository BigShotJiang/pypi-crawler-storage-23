# SkillGate Release Checklist - v1.2.0

- Release date (UTC): 2026-02-28
- Release owner: pending
- Release branch/tag: `main` / `v1.2.0` (tag pending)
- Change window: pending

## 1. Pre-flight

- [x] `git status` clean before release prep.
- [x] Version bump prepared for Python (`1.2.0`) and npm shim (`1.2.0`).
- [ ] Changelog/release notes finalized.
- [ ] Rollback plan confirmed.

## 2. Quality Gates

- [x] `./venv/bin/ruff check .`
- [x] `./venv/bin/mypy --strict skillgate`
- [x] `./venv/bin/pytest -q` (2991 passed)
- [x] `npm --prefix web-ui test`
- [x] `npm --prefix web-ui run build`
- [x] `npm --prefix vscode-extension test`

## 3. Package Build + Verify

- [x] Python build: `./venv/bin/python -m build --no-isolation`
- [x] Python artifact check: `./venv/bin/twine check dist/skillgate-1.2.0*`
- [x] npm shim pack: `npm-shim/skillgate-io-cli-1.2.0.tgz`
- [x] .NET pack validated previously (`SkillGate.Client.0.1.0.nupkg`)

## 4. Runtime Smoke

- [x] CLI/API/sidecar test matrix green in local gate run.
- [x] Web UI e2e green (64 passed, 2 skipped).
- [x] Docs and Ask Docs behavior validated in previous integration pass.
- [ ] Final production smoke after publish/deploy.

## 5. Publish

- [ ] Python publish to PyPI.
- [ ] npm publish `@skillgate-io/cli@1.2.0`.
- [ ] NuGet publish decision for `SkillGate.Client`.
- [ ] VS Code extension publish/defer recorded.

## 6. Deploy

- [x] API + worker already deployed from `main` (per operator note).
- [ ] Web UI deployment confirmation.
- [ ] Docs deployment confirmation (Netlify).

## 7. Post-release

- [ ] Verify install docs with real public installs.
- [ ] Monitor telemetry + error budget for 24h.
- [ ] Create release tag and publish release notes.
