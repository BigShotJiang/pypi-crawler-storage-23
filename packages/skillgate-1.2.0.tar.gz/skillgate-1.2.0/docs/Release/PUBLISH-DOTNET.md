# Publish Runbook - .NET Shim (`SkillGate.Client`)

## Scope

Publishes the .NET sidecar client package.

- Package: `SkillGate.Client`
- Registry: NuGet.org
- Project: `dotnet-shim/SkillGate.Client/SkillGate.Client.csproj`

## Preconditions

- NuGet API key is available
- Package version confirmed in `.csproj`
- `dotnet test` green

## Commands

```bash
cd dotnet-shim

# 1) Validate tests
dotnet test SkillGate.Client.Tests/SkillGate.Client.Tests.csproj

# 2) Pack release artifact
dotnet pack SkillGate.Client/SkillGate.Client.csproj -c Release

# 3) Publish to NuGet
# Replace VERSION and API key values before running.
dotnet nuget push SkillGate.Client/bin/Release/SkillGate.Client.VERSION.nupkg \
  --api-key "$NUGET_API_KEY" \
  --source https://api.nuget.org/v3/index.json
```

## Post-publish validation

```bash
dotnet new console -o /tmp/sg-dotnet-check
cd /tmp/sg-dotnet-check
dotnet add package SkillGate.Client
```
