# Claude Code + SkillGate MCP Gateway Integration

## 1. Configure gateway

Create `.skillgate/mcp-gateway.json`:

```json
{
  "servers": [
    {
      "server_id": "filesystem",
      "transport": "http",
      "endpoint": "http://127.0.0.1:8901",
      "trust_level": "verified"
    }
  ],
  "registry": ".skillgate/mcp/registry.json",
  "audit_log": ".skillgate/mcp/audit.jsonl"
}
```

## 2. Approve MCP server

```bash
skillgate mcp allow filesystem \
  --endpoint http://127.0.0.1:8901 \
  --transport http \
  --checksum <sha256> \
  --permissions fs.read,fs.write
```

## 3. Baseline Claude settings

```bash
skillgate mcp settings-check
```

First run creates `.skillgate/settings-baseline.json`.

## 4. Verify plugin attestations

```bash
skillgate mcp attest ./plugins/my_plugin.py
skillgate mcp verify ./plugins/my_plugin.py --policy strict --ci
```

## 5. Runtime verification

```bash
skillgate mcp list
skillgate mcp inspect filesystem
skillgate mcp audit
```

## 6. Troubleshooting

- `SG_DENY_UNTRUSTED_TOOL_PROVIDER`: run `skillgate mcp allow <server> ...`.
- `SG_DENY_TOOL_DESCRIPTION_INJECTION`: sanitize MCP tool metadata and redeploy.
- `SG_DENY_SETTINGS_PERMISSION_EXPANSION`: review `.claude/settings.json` changes and re-baseline intentionally.
- `SG_DENY_PLUGIN_NOT_ATTESTED`: attest plugin and re-verify in strict mode.
