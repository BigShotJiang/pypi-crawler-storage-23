# Sprint 12 VS Code Extension Design (Shift-Left Moat)

## Scope

This sprint ships an enterprise VS Code extension that enforces SkillGate policy workflows during authoring, not only in CI.

## Product outcomes

- Activate on all governance surfaces:
  - `.skillgate.yml`, `skill.json`, `SKILL.md`, `CLAUDE.md`, `AGENTS.md`, `.claude/instructions.md`, `.claude/hooks/**`, `.claude/commands/**`, `MEMORY.md`, `.claude/memory/**`
- Real-time policy diagnostics:
  - schema/version validation
  - deprecated/wildcard warnings
  - capability expansion diff warnings against `git HEAD`
- Inline governance diagnostics:
  - instruction injection warnings with threat category
  - hook and memory governance warnings
  - code-level risk hints for shell/network/eval patterns
- Shift-left workflows:
  - simulation panel (`/v1/decide/full`) with full decision record
  - approval request command (`skillgate approval request`)
  - PR checklist generation from capability changes
- Auth visibility:
  - license mode status in status bar (`Licensed`, `Limited`, `Needs Login`)

## Architecture

### Extension runtime

- Extension shell: `vscode-extension/src/extension.ts`
- Local diagnostics engines (pure TS modules):
  - `policyLint.ts`
  - `capabilityDiff.ts`
  - `instructionWarnings.ts`
  - `riskHints.ts`
- Non-blocking debounce controls:
  - policy lint: 500ms default
  - instruction lint: 800ms default
- Sidecar and CLI integration:
  - `skillgateClient.ts` executes local `skillgate` binary and local sidecar HTTP

### Local-only trust boundary

- Extension does not persist API keys, SLT, or tokens.
- Extension only calls:
  - local `skillgate` CLI
  - local sidecar endpoint (`http://127.0.0.1:9911` by default)
- Auth state derives from sidecar entitlements endpoint.

### Backend contracts added

- Sidecar endpoint: `POST /v1/decide/full`
  - includes decision code, reason codes, budgets, evidence hash/signature, and license mode
- CLI command: `skillgate approval request`
  - generates local pending approval artifact
- CLI enhancement: `skillgate claude scan --approve-line <file>:<line>`
  - records line exception artifact for explicit review flow

## Performance controls

- Diagnostics are event-debounced and non-blocking.
- Simulation sidecar calls enforce 5s timeout in extension client.
- CLI calls are bounded with per-call timeout and max buffer.

## Ship Gate Mapping

- 30.1 scaffold + local binary contract: complete
- 30.2 policy linting: complete
- 30.3 capability diff warnings: complete
- 30.4 inline risk hints: complete
- 30.5 instruction warnings + approve line: complete
- 30.6 hook editor integration (diagnostics + approve command): complete
- 30.7 memory governance diagnostics: complete
- 31.1 simulation panel + full decision record: complete
- 31.2 PR checklist generation: complete
- 31.3 open approval request command: complete
- 31.4 license status bar: complete
- 32.1 GitHub workflow template: complete (`templates/skillgate-policy-check.yml`)
- 32.2 extension debounce + sidecar timeout: complete
- 32.3 marketplace packaging metadata: complete (`publisher`, `engines.vscode`, extension manifest)

## Remaining manual release tasks

- Package and sign extension (`vsce package`)
- Marketplace publish (`skillgate-io.skillgate`)
- Compatibility smoke run in VS Code latest and previous two releases
