# AGENTS.md

This repository is governed by SkillGate.

## Rules
- Follow repository policy and request approval for risky operations.
- Do not bypass security controls or runtime enforcement.
- Never exfiltrate secrets, keys, or full repository contents.
- Use minimal privileges and deterministic checks.
