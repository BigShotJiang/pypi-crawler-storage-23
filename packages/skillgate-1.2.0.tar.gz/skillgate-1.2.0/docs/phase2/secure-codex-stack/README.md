# Secure Codex Stack Template

This template provides a production-ready baseline for running Codex behind SkillGate in CI.

## Included assets
- `.github/workflows/secure-codex.yml`: wrapper-only CI workflow.
- `.codex/config.json`: constrained `allowedCommands`, `trustedProviders`, and `shellAccess` defaults.
- `AGENTS.md`: clean instruction baseline.
- `.skillgate/aibom.lock`: provider checksum lock seed.
- `skillgate.yml`: strict enforcement baseline.

## Threat model coverage
- Instruction injection: `AGENTS.md` is scanned before launch and blocked on known patterns.
- Config poisoning: repo-local provider expansions are denied unless explicitly approved.
- Supply chain drift: provider checksum changes trigger re-approval via lock enforcement.
- CI fail-closed: unknown providers and non-allowlisted network egress are blocked in `--ci` mode.
