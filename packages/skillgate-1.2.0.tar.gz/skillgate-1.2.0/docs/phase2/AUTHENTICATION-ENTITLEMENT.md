Keep the “API key required once per session” model, but you must separate “license/usage validation” from “runtime enforcement correctness.” If you don’t, you’ll create a single point of failure that breaks the whole “capability firewall” story (especially for MCP/Codex local workflows).

Here’s how to adapt the implementation plan without weakening your commercial control.

⸻

1) Keep your current model, but change what depends on it

What should require auth (online)

Control-plane / commercial functions
	•	Creating/rotating org API keys
	•	Fetching tier entitlements and limits
	•	Pulling policy bundles from hosted control plane (if user chooses hosted policies)
	•	Telemetry upload to your SaaS
	•	Integration registry (hosted) access
	•	Team/RBAC approvals (hosted workflow)

What must NOT hard-depend on auth (offline-capable)

Data-plane enforcement
	•	Local policy evaluation (ALLOW/DENY/BUDGET)
	•	Sidecar/gateway decision path for MCP + Codex wrappers
	•	VS Code linting/simulation on local policy files

Because: if your service is down (or user is offline), a security product that can’t enforce policies becomes untrustworthy.

So enforcement should work with:
	•	cached entitlements
	•	cached policy snapshots
	•	a grace window for license validation

⸻

2) Introduce a “Session License Token” (SLT) to replace hard API calls

Right now you do: skillgate login -> validate key -> proceed.

Keep that UX, but make it issue a short-lived signed token that the local components can use without calling you every command.

Flow
	1.	User runs skillgate auth (or any command triggers it).
	2.	CLI calls your service with API key and device/session info.
	3.	Service returns:

	•	Session License Token (SLT) (JWT or PASETO) signed by you
	•	Entitlement payload (tier, limits, features)
	•	Rate-limit policy for client-side enforcement (optional)
	•	Token expiry (e.g., 12–24h)

	4.	CLI stores SLT locally (OS keychain if available; otherwise encrypted file).
	5.	Every SkillGate component (MCP gateway, sidecar, VS Code extension helper) reads SLT locally.

Benefits
	•	No repeated auth chatter
	•	No service dependency for every run
	•	You still control usage via token expiry + renewals

⸻

3) Add “Offline Grace + Fail Modes” (this is critical)

Define explicit modes in your plan and implement them consistently:

Mode A: Online (normal)
	•	SLT valid
	•	Optional live entitlement refresh
	•	Telemetry upload on

Mode B: Offline / Control-plane unavailable
	•	Use cached SLT if not expired
	•	Enforcement continues
	•	Telemetry buffered locally (encrypted spool)
	•	Policy updates paused (unless local policy file)

Mode C: SLT expired + offline

This is the controversial one. You choose based on your product strategy:

Recommended (balanced):
	•	Continue allowing read-only / low-risk actions (fs.read, git.diff) for a short “dead man’s switch” window (e.g., 24–72h)
	•	Block high-risk capabilities (shell.exec, net.outbound, fs.write outside allowlist)
	•	Return explicit decision code: SG_FAIL_LICENSE_EXPIRED_LIMITED_MODE

Strict (commercial-first):
	•	Fail closed for everything when SLT expired.
This will frustrate dev workflows and reduce adoption, especially for OSS-like distribution.

⸻

4) How this changes MCP / Codex / VS Code integration

MCP Gateway
	•	Gateway must start even if your SaaS is unreachable.
	•	It should require either:
	•	valid SLT, or
	•	“local-only policy mode” (if you ever support it)
	•	Gateway enforces rate limits locally (token bucket) using entitlement rules from SLT.

Codex Wrapper
	•	Same: wrapper checks SLT locally; renews in background only when needed.
	•	CI mode should avoid network calls unless explicitly enabled (many CI environments restrict outbound traffic).
	•	If SLT invalid in CI:
	•	fail closed for high-risk actions, but print exact remediation (“set SKILLGATE_API_KEY or prefetch SLT”).

VS Code Extension
	•	Don’t make the extension call your service directly.
	•	Extension talks to local skillgate binary which manages SLT.
	•	This avoids leaking API keys into extension contexts and simplifies security review.

⸻

5) Rate limiting, circuit breaking, and abuse control with this model

You get two layers:

Client-side enforcement (fast, reliable)

From SLT entitlements:
	•	per-minute budgets for shell/fs/net
	•	max invocations per session
	•	max policy evaluations per minute (prevent runaway loops)

Server-side protection (commercial + anti-abuse)

When online:
	•	API key request rate limits
	•	per-org / per-key quotas
	•	anomaly detection on telemetry ingestion

Circuit breaker logic
	•	If auth endpoint fails: don’t block enforcement; just stop trying for a cooldown interval.
	•	Use exponential backoff with jitter.
	•	Store last_successful_auth_at and don’t spam your service.

⸻

6) What to change in the existing IMPLEMENTATION-plan.md

Add/modify these sections:

Add section: “License & Entitlement Architecture”
	•	SLT spec
	•	local storage rules
	•	expiry and renewal
	•	offline grace policy
	•	decision codes related to licensing

Update section 6.5 “Circuit breakers & degraded modes”

Right now it discusses control plane/audit. Extend it:
	•	Control plane unreachable ⇒ use cached SLT & policy snapshots
	•	Auth unreachable ⇒ do not block; renew later
	•	SLT expired ⇒ enter limited mode (your choice)

Update “Sidecar API”

Include:
	•	GET /v1/entitlements (local view)
	•	POST /v1/refresh-license (optional)
	•	Decision responses include entitlement_version and license_mode

⸻

7) One brutal truth: requiring API key for all tiers is OK, but friction is deadly

If every casual user must sign up before trying anything, you will lose a lot of developer-led growth.

Two ways to keep control without killing adoption:

Option 1 (recommended): “Anonymous trial SLT”
	•	Let users run skillgate init without signup
	•	Generate a short-lived anonymous SLT (e.g., 24h) with tight limits
	•	They only need full signup when they exceed it

Option 2: “Local-only community mode”
	•	Local policy lint + simulation works without auth
	•	Runtime enforcement / gateway requires auth
This preserves your moat while enabling zero-friction evaluation.

⸻

8) Concrete implementation checklist (so an agent can build it)

Backend
	•	/auth/exchange endpoint: API key → SLT
	•	SLT signing keys + rotation
	•	Entitlement model per tier
	•	Rate limits per API key

CLI
	•	skillgate auth command
	•	SLT cache + encryption
	•	renewal logic + backoff
	•	standardized license-related errors

Sidecar/Gateway
	•	SLT verification middleware
	•	license modes (online/offline/limited)
	•	local rate limits based on SLT

VS Code
	•	call local binary only
	•	show clear UI when in limited mode or needs login

⸻
