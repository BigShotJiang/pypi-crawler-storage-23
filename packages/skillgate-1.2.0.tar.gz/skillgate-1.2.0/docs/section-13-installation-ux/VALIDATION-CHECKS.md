# Validation Checks (Mandatory)

Run from repo root unless noted.

## 1) Baseline Quality Gates

```bash
./venv/bin/ruff check .
./venv/bin/mypy --strict skillgate/
./venv/bin/pytest -q
```

## 2) Section 13 Contract Checks (As Implemented)

Add and run task-targeted suites for:

- install-spec schema validation and snapshots (`17.139`)
- install docs snippet/link checks (`17.140`, `17.142`)
- version-target behavior checks (`17.141`)
- signed release manifest verification (`17.143`)
- npm shim publish-provenance contract checks (`17.143`): `npm pack` integrity + `npm publish --provenance --dry-run` + wrapper e2e behavior
- docs freshness/version drift CI checks (`17.150`)
- launch checklist enforcement checks (`17.151`)

## 3) Evidence Artifacts Required Per Task

Each task must include:

1. Test/check output summary.
2. Relevant artifact links.
3. Backward compatibility note.
4. Rollback/recovery note.
5. Security/privacy validation result.

## 4) Fail Conditions

Release is blocked if:

- Any required check fails.
- Any install path lacks verified run/verify/uninstall docs.
- Any release integrity claim lacks verification evidence.
- Any docs version/install command drift is detected.
