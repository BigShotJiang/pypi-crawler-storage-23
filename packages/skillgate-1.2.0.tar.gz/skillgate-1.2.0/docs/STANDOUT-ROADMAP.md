# SkillGate — Standout Roadmap (Post Sprint 6)

**Product:** SkillGate  
**Status:** Proposed execution plan  
**Last Updated:** 2026-02-17  
**Purpose:** Define how SkillGate wins decisively by building beyond scanner-style products and shipping a full enterprise docs experience.

---

## 1) Strategy: Win by Being the Enforcement + Evidence Platform

### 1.1 Principles

1. Do not copy threat intel products 1:1.
2. Keep SkillGate differentiated around deterministic gating, policy governance, and provable compliance.
3. Add intelligence features only when they improve CI decisions, auditability, and response speed.
4. Treat docs as product: buyers, engineers, security teams, and legal must all self-serve.

### 1.2 What We Build Better

| Area | Typical ecosystem behavior | SkillGate standout direction |
|---|---|---|
| Detection output | Alert stream | Deterministic pass/fail enforcement with explainable policy reasons |
| Reputation data | Hash/file-centric | Skill/agent behavior + rule lineage + trust score + provenance graph |
| Investigations | Analyst-heavy UI | DevSecOps-native incident timeline tied to commits, pipelines, and attestations |
| Governance | Optional controls | Policy-as-code required in merge/deploy gates |
| Docs | Reference-first | Decision-first docs: onboarding, security, legal, migration, incident playbooks |

---

## 2) Product Expansion Plan (Standout Features)

## 2.1 Phase A — Intelligence That Improves CI Decisions

| ID | Capability | Scope | Acceptance Criteria |
|---|---|---|---|
| SG-INT-1 | Threat Intel Enrichment Layer | Enrich findings with source reputation, first-seen/last-seen, confidence, and actor tags | `scan --json` includes enrichment block; no local-scan latency regression >10% |
| SG-INT-2 | Skill Reputation Registry | Managed registry of known-safe/known-malicious skills with signed metadata | Reputation can be cached locally and validated offline with signature checks |
| SG-INT-3 | Confidence-Aware Policy | Policies can require stricter actions when confidence + severity exceed thresholds | New policy schema fields validated; blocking behavior covered by tests |
| SG-INT-4 | Private Intel Connectors | Pull private indicators from customer SIEM/TIP (read-only connectors) | Connector failures do not break baseline deterministic scan |

## 2.2 Phase B — Hunt and Retrospective Detection

| ID | Capability | Scope | Acceptance Criteria |
|---|---|---|---|
| SG-HUNT-1 | Hunt Query DSL | Query across historical scan corpus by rule, package, maintainer, domain, behavior | CLI + API query parity; pagination and auth checks covered |
| SG-HUNT-2 | Retro-Scan Engine | Re-evaluate historical scans when rules are updated | Rule update triggers async retro-scan job; affected repos notified |
| SG-HUNT-3 | Campaign Clustering | Cluster related malicious skills by shared IOCs/AST fingerprints | Cluster IDs visible in dashboard and report export |
| SG-HUNT-4 | Saved Hunts + Alerts | Teams can save hunt queries and alert on matches | Alert pipeline retries + DLQ + replay tooling tested |

## 2.3 Phase C — Response and Containment

| ID | Capability | Scope | Acceptance Criteria |
|---|---|---|---|
| SG-RESP-1 | Quarantine Actions | Auto-open PR comments/issues and block deployment lanes for high-confidence campaigns | End-to-end integration tests across GitHub/GitLab adapters |
| SG-RESP-2 | Key/Token Exposure Response | Detection path to force API key rotation guidance and runbook links | One-click runbook links from findings; action audit log emitted |
| SG-RESP-3 | Third-Party Signal Feeds | Ingest external malware feeds to update policy recommendations | Feed ingestion idempotent; stale feed guardrails in place |
| SG-RESP-4 | Customer Incident Timeline | Unified timeline of scan, gate decision, webhook, payment/account events | Timeline API returns correlated request IDs and signed event references |

## 2.4 Phase D — Trust and Compliance Moat

| ID | Capability | Scope | Acceptance Criteria |
|---|---|---|---|
| SG-TRUST-1 | Verifiable Trust Score | Transparent trust score formula tied to explainable evidence | Score formula public in docs; every score component traceable |
| SG-TRUST-2 | Continuous Attestation Chains | Chain attestations across repo, pipeline, and deployment artifact | Verification tool validates chain end-to-end |
| SG-TRUST-3 | Compliance Mappings | Built-in mapping for SOC2/ISO/NIST controls to SkillGate evidence | Exportable control evidence pack generated from API |
| SG-TRUST-4 | Customer Data Boundaries | Region-aware storage, tenant isolation checks, and data residency controls | Automated tests validate tenant isolation and region pinning |

---

## 3) Documentation Product Plan (From Single Page to Full Docs Platform)

## 3.1 Information Architecture (Must Build)

1. `/docs/get-started/` — install, first scan, first policy gate, first attestation.
2. `/docs/product/` — core concepts, architecture, rule engine, policy engine.
3. `/docs/cli/` — complete CLI reference with examples and error codes.
4. `/docs/api/` — OpenAPI-backed reference, auth, pagination, webhook contracts.
5. `/docs/integrations/` — GitHub, GitLab, CI templates, SIEM/TIP connectors.
6. `/docs/security/` — threat model, crypto details, hardening defaults, disclosure policy.
7. `/docs/legal/` — DPA, subprocessor list, incident notice template, terms, privacy.
8. `/docs/operations/` — SLOs, runbooks, DR/rollback, on-call and incident response.
9. `/docs/migrations/` — version upgrades, breaking changes, rollback playbooks.
10. `/docs/enterprise/` — procurement answers, architecture questionnaires, trust FAQs.

## 3.2 Docs Experience Requirements

| ID | Requirement | Acceptance Criteria |
|---|---|---|
| DOC-1 | Multi-page docs app (not single-page marketing) | Left-nav hierarchy, full-text search, version switcher |
| DOC-2 | API reference automation | OpenAPI source-of-truth generates docs on CI |
| DOC-3 | Task-based guides | Top 20 user tasks documented with copy-paste commands |
| DOC-4 | Security/legal transparency | Public pages for subprocessors, incident notice, security controls |
| DOC-5 | Docs quality gates | Link checker, markdown lint, code-snippet tests, Lighthouse >=90 |
| DOC-6 | Enterprise navigation | Buyer, security, and legal paths each reachable in <=2 clicks |
| DOC-7 | Change communication | Versioned changelog + migration notes + deprecation timelines |

## 3.3 Docs Engineering Tasks

| ID | Task | Owner | Priority |
|---|---|---|---|
| DOC-T1 | Build docs app shell (Next.js + MDX + search) | Web | P0 |
| DOC-T2 | Define docs content schema + frontmatter standard | DX | P0 |
| DOC-T3 | Add docs CI checks (links, spell, snippet execution, Lighthouse) | Platform | P0 |
| DOC-T4 | Auto-publish API docs from OpenAPI artifacts | API | P1 |
| DOC-T5 | Add diagrams for architecture, event flows, and trust model | Product + Eng | P1 |
| DOC-T6 | Build legal center pages from maintained templates | Legal + Web | P1 |
| DOC-T7 | Add docs analytics (privacy-safe) for content gap detection | Growth | P2 |

---

## 4) Execution Timeline

## 4.1 Sprint 7 (P0 Foundation)

1. SG-INT-1, SG-INT-2.
2. DOC-T1, DOC-T2, DOC-T3.
3. Publish public docs IA and migrate existing markdown into structure.

**Ship Gate:** enrichment integrated into scan output, docs site multi-page live, docs CI required.

## 4.2 Sprint 8 (Hunt + Response)

1. SG-HUNT-1, SG-HUNT-2.
2. SG-RESP-1.
3. DOC-T4, DOC-T6.

**Ship Gate:** hunt queries operational, retro-scan jobs reliable, legal/security docs publicly accessible.

## 4.3 Sprint 9 (Trust Moat)

1. SG-HUNT-3, SG-HUNT-4.
2. SG-TRUST-1, SG-TRUST-2.
3. DOC-T5.

**Ship Gate:** trust score explainable, evidence chains verifiable, enterprise trust docs complete.

## 4.4 Sprint 10 (Enterprise Scale)

1. SG-RESP-2, SG-RESP-3, SG-RESP-4.
2. SG-TRUST-3, SG-TRUST-4.
3. DOC-T7.

**Ship Gate:** enterprise readiness review passed (security, legal, ops, scale).

---

## 5) Commercial Outcome Targets

| Target | 6-Month Goal | 12-Month Goal |
|---|---|---|
| Time-to-value | <15 min from signup to first blocking gate | <10 min |
| Enterprise trust cycle | Security questionnaire response pack in <24h | <4h |
| Investigation speed | Incident triage in <30 min | <10 min |
| Docs success | >=70% self-serve resolution rate | >=85% |
| Product differentiation | >=3 unique capabilities not offered by scanner-only competitors | >=6 |

---

## 6) Risks and Countermeasures

| Risk | Impact | Countermeasure |
|---|---|---|
| Feature bloat away from CI gating core | High | Every feature must map to gate quality, trust evidence, or response time |
| Intelligence feed noise | High | Confidence scoring + suppression workflow + audit trail |
| Docs decay | Medium | Docs owners, CI gates, and docs release checklist |
| Enterprise legal exposure | High | Legal templates, review cadence, and public compliance changelog |

---

## 7) Immediate Next Actions

1. Approve this roadmap as `Sprint 7–10` execution track.
2. Create implementation epics for `SG-INT-*`, `SG-HUNT-*`, `SG-RESP-*`, `SG-TRUST-*`, and `DOC-T*`.
3. Start with Sprint 7 P0: enrichment + multi-page docs platform + docs CI gates.
