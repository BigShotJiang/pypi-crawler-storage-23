# SkillGate Feature Inventory (Basic / Complex / Moat)

Version: 2026-02-22
Source of truth: codebase audit across `skillgate/`, `skillgate/api/`, `skillgate/ci/`, and `web-ui/`

## 1. Classification Model

- Basic: single-purpose, foundational capability with low coupling.
- Complex: multi-component workflows, richer contracts, or cross-module orchestration.
- Moat: difficult-to-copy control-plane/security/attestation/network-effect capabilities.

## 2. Tier Model (Code-Enforced Source of Truth)

Primary source: `skillgate/core/entitlement/models.py`

- Free: `scan` (with limits, requires valid Free API key)
- Pro: Free + `enforce`, `sign`, `explain`
- Team: Pro + `ci_annotations`, `ci_blocking`, `fleet_scan`, `retroscan`, `hunt`
- Enterprise: Team + `custom_policy`, `audit_export`, `key_namespaces`, `runtime_budgets`, `trust_graph`

Important implementation note:
- CLI entitlement-resolved command paths require a valid API key (`SKILLGATE_API_KEY`) across tiers.
- Non-local entitlement modes (`saas`, `private_relay`, `airgap`) additionally require signed entitlement contracts.

## 3. Core Engine Features

### 3.1 Parser and Bundle Ingestion

| Feature | Class | What it does | How implemented | How to use | Tier |
|---|---|---|---|---|---|
| Bundle discovery | Basic | Resolves and validates bundle directories | `skillgate/core/parser/bundle.py` | `skillgate scan <path>` | All |
| Manifest priority resolution | Complex | Parses manifests with priority contract | `skillgate/core/parser/manifest.py` | Include `SKILL.md` / `skill.json` / `package.json` / `pyproject.toml` | All |
| Deterministic bundle hashing | Complex | Stable hash over sorted source files | `skillgate/core/parser/bundle.py` | Appears in scan report `bundle_hash` | All |
| Language detection | Basic | Maps extension to language enum | `skillgate/core/parser/source.py` | Automatic during scan | All |
| Source enumeration with skip dirs | Basic | Recursively scans code while skipping cache/build dirs | `skillgate/core/parser/source.py` | Automatic during scan | All |
| File-size guard (100KB) | Complex | Skips oversized files to protect latency/memory | `skillgate/core/parser/source.py`, `skillgate/core/analyzer/perf_guard.py` | Automatic with warning paths | All |
| Remote bundle fetch | Complex | Supports scanning URL-based bundles | `skillgate/cli/commands/scan.py`, `skillgate/cli/remote.py` | `skillgate scan <http(s)://...>` | All |
| Fleet bundle discovery | Moat | Detects multiple skill bundles in repo/org roots with deterministic ordering and de-dup | `skillgate/core/parser/fleet.py` | `skillgate scan ./agents --fleet` | All |
| Provider selector intake | Complex | Normalizes `github:` / `gitlab:` / `forge:` selectors to fetchable archives | `skillgate/cli/remote.py` | `skillgate scan github:org/repo` | All |
| Markdown extraction | Complex | Fenced-block/text extraction with provenance | `skillgate/core/parser/markdown.py` | Automatic in artifact-aware scans | All |
| Document extraction (PDF/DOCX) | Complex | Safe text-only extraction with timeout/size/page guards | `skillgate/core/parser/document.py` | Include docs inside bundles; install optional deps | All |
| Archive extraction | Complex | Zip/tar traversal with zip-slip/bomb/depth/member guards | `skillgate/core/parser/archive.py` | Include archives in bundles | All |

Remote intake contract (implemented in `skillgate/cli/remote.py`):

- Selector formats:
  - `github:owner/repo`
  - `github:github.company.local/owner/repo`
  - `gitlab:group/repo`
  - `gitlab:gitlab.company.local/group/subgroup/repo`
  - `forge:scm.company.local/org/repo`
- Direct URL normalization:
  - GitHub/GHE repo URLs normalize to tarball archive URLs.
  - GitLab/self-hosted GitLab repo URLs normalize to archive URLs.
- Branch/ref handling:
  - GitHub `/tree/...` and GitLab `/-/tree/...` are parsed and preserved.
  - Branch refs are URL-encoded to safely support branch names containing `/`.

### 3.2 Analyzer and Rules

| Feature | Class | What it does | How implemented | How to use | Tier |
|---|---|---|---|---|---|
| Deterministic rule engine | Basic | Static analysis only, no code execution | `skillgate/core/analyzer/engine.py` + rules | `skillgate scan` | All |
| Pre-filtered analysis | Complex | Regex prefilter avoids parsing irrelevant files | `skillgate/core/analyzer/engine.py` | Automatic | All |
| Parallel per-file rule evaluation | Complex | ThreadPool rule execution for latency | `skillgate/core/analyzer/engine.py` | Automatic | All |
| Unicode normalization hardening | Moat | Detects confusable/bidi evasion before analysis | `skillgate/core/analyzer/unicode_normalizer.py`, engine integration | Automatic | All |
| AST + regex hybrid detection | Complex | Tree-sitter + regex coverage across languages | `skillgate/core/analyzer/treesitter.py`, `skillgate/core/analyzer/rules/*` | Automatic | All |
| Multi-language coverage | Complex | Python/JS/TS/Shell/Go/Rust/Ruby + text/config | Rules registry + source detection | Automatic | All |
| Rule registry and listing | Basic | Enumerates all rules with metadata | `skillgate/cli/commands/rules_cmd.py` | `skillgate rules --output json` | All |
| Rule catalog (119 rules) | Complex | Extensive category coverage | `docs/RULE-CATALOG.md`, rules packages | `skillgate rules` + scan outputs | All |

### 3.3 Scoring and Policy

| Feature | Class | What it does | How implemented | How to use | Tier |
|---|---|---|---|---|---|
| Weighted deterministic risk scoring | Basic | `score = Σ(weight × severity_multiplier)` | `skillgate/core/scorer/engine.py` | Included in reports | All |
| Severity classification and breakdown | Basic | Categorizes total score and per-category contributions | scorer models/engine | Included in reports | All |
| Policy preset resolution | Complex | Defaults + preset + file + CLI merge flow | `skillgate/core/policy/loader.py`, presets/schema | `--policy production|strict|...|path.yml` | All |
| Threshold enforcement | Complex | Max score and severity count thresholds | `skillgate/core/policy/engine.py` | `skillgate scan --enforce` | Pro+ |
| Permission-based policy checks | Complex | shell/eval/network/fs/cred restrictions | `skillgate/core/policy/engine.py` | policy YAML permissions | Pro+ |
| Rule disable/override controls | Complex | Disable rules, severity/weight overrides | `skillgate/core/policy/engine.py` | policy YAML `rules.*` | Pro+ |
| Origin-aware policy filtering | Moat | Per-origin-class filtering/floor/blocked categories | `skillgate/core/policy/engine.py`, artifact provenance models | artifact origin policy config | Pro+ |
| Confidence-aware policy filtering | Moat | Uses enrichment confidence in decision path | `evaluate_policy(... enrichments=...)` | enable confidence settings in policy | Pro+ |
| Fleet policy controls | Complex | Configures fleet roots/exclusions/manifest requirements/fail thresholds/workers | `skillgate/core/policy/schema.py` (`FleetConfig`) + loader | `skillgate.yml` `fleet.*` + `scan --fleet` | All |
| Domain allow/deny restrictions | Complex | Domain extraction + whitelist/blacklist checks | policy engine domain checks | policy permissions | Pro+ |

### 3.4 Signing and Verification

| Feature | Class | What it does | How implemented | How to use | Tier |
|---|---|---|---|---|---|
| Ed25519 key generation | Basic | Creates signing keypair | `skillgate/cli/commands/keys.py`, `core/signer/keys.py` | `skillgate keys generate` | Pro+ |
| Signed scan reports | Moat | Canonical hash + Ed25519 attestation on reports | `skillgate/core/signer/engine.py` | `skillgate scan --sign` | Pro+ |
| Report verification | Complex | Signature and hash integrity verification | `skillgate/cli/commands/verify.py` | `skillgate verify report.json` | Pro+ |
| Explicit-key verification mode | Complex | Verify report with supplied trusted key | signer engine + CLI option | `skillgate verify --public-key <hex>` | Pro+ |

### 3.5 Enrichment and Explanations

| Feature | Class | What it does | How implemented | How to use | Tier |
|---|---|---|---|---|---|
| Static threat enrichment | Complex | Deterministic enrichment metadata per finding | `skillgate/core/enricher/engine.py` + catalog | auto in scan reports | All |
| Connector framework | Complex | Read-only external intel adapters with fail-open semantics | `skillgate/core/connectors/*` | configure connectors, then enrich pipeline | Team+ (operationally) |
| File TIP connector | Basic | Local JSON threat intel source | `skillgate/core/connectors/file_tip.py` | file-based enrichment source | Team+ (operationally) |
| LLM explanations w/ fallback | Complex | Anthropic/OpenAI/template fallback explainers | `skillgate/core/explainer/engine.py` | `skillgate scan --explain` | Pro+ |

## 4. CLI Product Surface

### 4.1 Top-Level Commands

Source: `skillgate/cli/app.py`

- `scan`, `simulate`, `run`, `hunt`, `retroscan`, `rules`, `init`, `verify`, `version`
- Subcommand apps: `keys`, `hooks`, `auth`, `approval`, `gateway`, `bom`, `dag`, `drift`, `reputation`

### 4.2 Feature Inventory (CLI)

Contract note:
- Entitlement-resolved CLI paths require `SKILLGATE_API_KEY` (Free keys included). Tier determines capabilities and limits after key validation.

| Command / Feature | Class | What it does | How implemented | Example usage | Tier |
|---|---|---|---|---|---|
| `scan` | Basic | Main static scan command | `skillgate/cli/commands/scan.py` | `skillgate scan ./skill` | All |
| `scan --output human/json/sarif` | Complex | Multi-format reporting | CLI formatters | `skillgate scan . -o json` | SARIF Team+ gate enforced |
| `scan --enforce` | Complex | Policy violation exits non-zero | scan + policy engine | `skillgate scan . --enforce --policy production` | Pro+ |
| `scan --sign` | Complex | Signed output reports | scan + signer | `skillgate scan . --sign -o json` | Pro+ |
| `scan --watch` | Complex | Rescan on file changes | watchdog integration | `skillgate scan . --watch` | All |
| `scan --mode agent-output/pre-commit` | Complex | Pre-set behavior for runtime and hooks workflows | scan mode logic | `skillgate scan . --mode pre-commit` | All |
| `scan --fleet` | Moat | Repo/org fleet scanning with per-bundle isolation and fleet summary | `skillgate/cli/commands/scan.py` + `core/parser/fleet.py` | `skillgate scan ./agents --fleet -o json` | All |
| `scan --fleet` controls (`--require-skill-manifest`, `--fail-on-any`, `--fail-on-threshold`, `--fleet-workers`) | Complex | Strict structure gating, CI fail semantics, bounded parallel workers | fleet scan execution path + policy fallback | `skillgate scan ./agents --fleet --fail-on-threshold 10` | All |
| `scan --explain` / `--explain-mode executive` | Complex | Adds technical or CISO-style deterministic summaries | explainer integration + mode templates | `skillgate scan . --explain --explain-mode executive` | Pro+ |
| `simulate` + `--org` selector | Moat | Policy dry-run impact over multi-repo selectors with fail-rate/top-violation/noise summaries | `skillgate/cli/commands/simulate.py` | `skillgate simulate --org \"./repos/acme/*\" -p strict` | All |
| `run` | Moat | Runtime wrapper with pre-exec + attested decisions | `skillgate/cli/commands/run.py` + gateway core | `skillgate run --env ci -- codex ...` | env-dependent (dev: all, prod/strict: Pro+, ci: Team+) |
| `gateway check` | Moat | Native hook pre-execution API | `skillgate/cli/commands/gateway.py` | `skillgate gateway check --command "..." --env strict` | same as runtime env capability |
| `gateway scan-output` | Moat | TOP scan of tool output for native hooks | gateway + top guard | `skillgate gateway scan-output --output-text "..."` | same as runtime env capability |
| `approval sign` / `approval verify` | Moat | Signed reviewer approval artifacts and quorum verification for hardened promotions | `skillgate/cli/commands/approval.py` + `core/gateway/approval.py` | `skillgate approval sign ...` / `skillgate approval verify ...` | Team+/Enterprise ops |
| `bom import` | Complex | Imports CycloneDX/BOM material for runtime gate | `skillgate/cli/commands/bom.py` | `skillgate bom import bom.json` | Team+ ops |
| `bom validate` | Complex | Validates runtime identity against AI-BOM + attestation | bom gate | `skillgate bom validate --skill-id ...` | Team+ ops |
| `dag show` | Basic | Displays runtime session artifact JSON | dag command | `skillgate dag show artifact.json` | Team+ ops |
| `dag verify` | Complex | Verifies signed session artifact integrity | dag + session verifier | `skillgate dag verify artifact.json` | Team+ ops |
| `dag risk` | Moat | Transitive lineage depth/blast-radius/path risk + lateral movement + secret exposure radius | dag + lineage analyzer | `skillgate dag risk artifact.json -o json` | Team+ ops |
| `drift baseline` / `drift check` | Moat | Baseline drift workflow with CI fail semantics and fleet-aware mode | `skillgate/cli/commands/drift.py` | `skillgate drift baseline ./agents --fleet` | Team+ ops |
| `reputation verify` | Complex | Verifies signed reputation graph integrity | reputation verifier | `skillgate reputation verify rep.json` | Team+ ops |
| `reputation check` | Moat | Deterministic reputation decision on skill hash | reputation policy | `skillgate reputation check --bundle-hash ...` | Team+ ops |
| `reputation submit` (`--anonymized/--full`) | Moat | Signed local submission outbox for global reputation ingest | `skillgate/cli/commands/reputation.py` | `skillgate reputation submit --bundle-hash ... --anonymized` | Team+ ops |
| `hunt` | Complex | DSL query over historical scan reports | `skillgate/cli/commands/hunt.py` | `skillgate hunt "rule:SG-SHELL-001" -d reports/` | Intended Team+ (not universally hard-gated in CLI) |
| `retroscan` | Complex | Historical diff/replay analysis | `skillgate/cli/commands/retroscan.py` | `skillgate retroscan -d reports/` | Intended Team+ (not universally hard-gated in CLI) |
| `rules` | Basic | Lists registry metadata | rules command | `skillgate rules --category shell` | All |
| `init` | Basic | Generates starter `skillgate.yml` | init command | `skillgate init --preset production` | All |
| `verify` | Basic | Verifies signed scan report files | verify command | `skillgate verify report.json` | Pro+ for signed reports |
| `keys generate` | Basic | Creates keypairs for signing | keys command | `skillgate keys generate` | Pro+ |
| `hooks install/uninstall` | Complex | Git pre-commit integration | hooks command | `skillgate hooks install` | All |
| `auth login/logout/whoami/status` | Complex | API key + OAuth device flow login | auth command | `skillgate auth login` | All |

## 5. Runtime Moat and Control Plane

### 5.1 Runtime Decision Pipeline

| Feature | Class | What it does | How implemented | How to use | Tier |
|---|---|---|---|---|---|
| Deterministic runtime risk classification | Moat | Classifies dangerous commands pre-exec | `skillgate/core/gateway/runtime_engine.py` | via `run` / `gateway check` | env-dependent |
| Entitlement-aware runtime gating | Moat | Maps env to required capabilities (`scan`/`enforce`/`ci_blocking`) | runtime engine + entitlement resolver | set `--env dev|ci|prod|strict` | Free/Pro/Team by env |
| Tool-class allowlist enforcement | Complex | Blocks non-allowed command classes | `gateway/allowlist.py` + runtime engine | `SKILLGATE_ALLOWED_TOOL_CLASSES` | Pro+/Team+ in hardened envs |
| Capability budgets (global/org/session + external domains + domain chains) | Moat | Deterministic over-budget block semantics for tool classes and egress patterns | `gateway/budget.py` | set `SKILLGATE_BUDGET_*` env vars + `--org-id` | Pro+/Team+/Enterprise |
| Hardened sandbox backend requirement | Complex | Requires backend presence in ci/prod/strict | `gateway/sandbox.py` | `SKILLGATE_SANDBOX_BACKEND=process|bwrap|nsjail` | Pro+/Team+ |
| AI-BOM runtime gate | Moat | Identity/hash/attestation checks before execute | `gateway/bom_gate.py` and `run`/`gateway check` integration | pass `--skill-id --skill-hash --scan-attestation` | Team+ ops |
| Approval quorum runtime gate | Moat | Enforces signed approval files with reviewer quorum in hardened environments | `core/gateway/approval.py` + `run`/`gateway check` | `--approval-file --required-reviewers N` | Team+/Enterprise |
| Reputation runtime gate | Moat | Signed reputation graph allow/block decisions | `core/reputation/policy.py` + wrapper integration | `--skill-hash --reputation-store` | Team+ ops |
| TOP (Tool Output Poisoning) guard | Moat | Detect/annotate/sanitize/block poisoned output | `gateway/top_guard.py` + runtime wrappers | enabled by default in `run` | Pro+/Team+ |
| Scope token chain-of-trust | Moat | Signed, time-limited subprocess trust propagation | `gateway/scope.py`, run/gateway commands | automatic via wrapper env vars | Team+ |
| Signed runtime session artifacts | Moat | Signed per-decision and session-level evidence | `gateway/session.py` | `--artifact` and `dag verify/risk` | Team+/Enterprise |
| Lineage DAG risk analytics (v2) | Moat | Max depth/blast radius/high-risk paths plus lateral movement and secret exposure metrics | `gateway/lineage.py`, `dag risk` | `skillgate dag risk artifact.json` | Team+/Enterprise |
| Wrapper bypass quality check | Complex | Scans CI YAML for direct AI-CLI execution bypass | `scripts/quality/check_wrapper_enforcement.py` | run in CI | Team+ |

### 5.2 Reputation Graph Foundation

| Feature | Class | What it does | How implemented | How to use | Tier |
|---|---|---|---|---|---|
| Signed reputation data contract | Moat | Integrity for global skill reputation payloads | `core/reputation/models.py`, `verifier.py` | sign/verify reputation JSON | Team+/Enterprise |
| Offline-first reputation cache | Complex | Local cache with signature verification | `core/reputation/store.py` | `.skillgate/reputation/reputation.json` | Team+/Enterprise |
| Hash redaction for telemetry/log safety | Complex | Redacts hash while keeping correlatability | `core/reputation/redaction.py` + policy messages | automatic in decision reasons/metadata | Team+/Enterprise |
| Signed reputation submission outbox | Moat | Opt-in anonymized/full local export events for later network ingest | `cli/commands/reputation.py` (`submit`) | append `.skillgate/reputation/submissions.ndjson` | Team+/Enterprise |

## 6. Entitlement, Commercialization, and Enterprise Controls

### 6.1 Entitlement Contracts

| Feature | Class | What it does | How implemented | How to use | Tier |
|---|---|---|---|---|---|
| Tier-capability mapping | Complex | Canonical capability matrix | `core/entitlement/models.py` | resolved at runtime | All |
| API key required contract | Complex | Requires valid `SKILLGATE_API_KEY` before runtime entitlement resolution | `core/entitlement/resolver.py` | set `SKILLGATE_API_KEY=sg_free|sg_pro|sg_team|sg_ent...` | All |
| Capability gates | Complex | Fail with upgrade guidance when unavailable | `core/entitlement/gates.py` | integrated in scan/runtime/API | All |
| Free-tier quota tracker | Complex | 3/day local quota with deterministic UTC reset | `core/entitlement/quota.py` | automatic in `scan` local mode with valid Free key | Free |
| Finding cap | Complex | Top-N findings cap for free tier | `cap_findings` + scan integration | automatic in free | Free |
| Seat-limit enforcement | Complex | Team seat cap checks | `check_seat_limit` + teams/scan seat contract | env + API team paths | Team |

### 6.2 Enforcement Modes

| Feature | Class | What it does | How implemented | How to use | Tier |
|---|---|---|---|---|---|
| `local` mode | Basic | Local API-key-derived entitlement/quota | `entitlement/mode.py`, resolver, quota | default | All |
| `saas` mode | Complex | Hosted authority for usage consume decisions | `usage_authority.py` | set `SKILLGATE_ENTITLEMENT_MODE=saas` | Paid |
| `private_relay` mode | Moat | Internal authority endpoint constraint for enterprise | `usage_authority.py` internal URL checks | set mode + internal URL/token | Enterprise |
| `airgap` mode | Moat | Signed offline pack + expiry/grace + usage consumption | `entitlement/airgap.py`, resolver integration | set `SKILLGATE_ENTITLEMENT_MODE=airgap` + pack path | Enterprise |
| Signed entitlement tokens | Moat | Ed25519 signed entitlement claims with replay/nonce checks | `entitlement/resolver.py` | set `SKILLGATE_ENTITLEMENT_TOKEN` + key(s) | Enterprise/Hosted |

### 6.3 Enterprise-Specific Controls

| Feature | Class | What it does | How implemented | How to use | Tier |
|---|---|---|---|---|---|
| Custom policy pack validation hook | Complex | Enterprise-only policy pack gate | `entitlement/enterprise.py` | invoke in enterprise policy pack flow | Enterprise |
| Key namespace isolation | Moat | Team/tier namespaced signing key routing | `entitlement/enterprise.py` | use namespace function in signing paths | Enterprise |
| Audit export formatter | Complex | JSONL/CSV audit exports | `entitlement/enterprise.py` + API route | API `/audit/export` | Enterprise |
| On-prem entitlement adapter contract | Moat | External enterprise validation adapter (NoOp/HTTP) | `entitlement/enterprise_adapter.py` | configure on-prem URL/token | Enterprise |

### 6.4 Pre-GA Tier-Gating Blockers (Must Close Before Claim Expansion)

Status update (2026-02-20): release blockers closed and now CI-enforced.

Status update (2026-02-22): entitlement resolver now enforces API key presence/format for CLI entitlement paths (Free included).

- `hunt` and `retroscan` now enforce Team+ capabilities in both CLI and hosted API paths:
  - CLI: `skillgate/cli/commands/hunt.py`, `skillgate/cli/commands/retroscan.py`
  - API: `skillgate/api/routes/hunt.py`, `skillgate/api/routes/retroscan.py`
  - Regression tests: `tests/unit/test_hunt/test_cli.py`, `tests/unit/test_retroscan/test_cli.py`, `tests/unit/test_api/test_hunt_api.py`, `tests/unit/test_api/test_retroscan_api.py`
- Non-local entitlement authority path now fail-closes on signed token + subject consistency with issuer/audience/nonce observability and incident signaling:
  - Runtime client path: `skillgate/core/entitlement/usage_authority.py`
  - Authority server path: `skillgate/api/routes/entitlements.py`
  - Abuse tests: `tests/unit/test_api/test_entitlements_api.py`, `tests/unit/test_entitlement/test_usage_authority.py`, `tests/unit/test_cli/test_entitlement_gates.py`

Blocker policy (still hard gate):
- Do not add or restore pricing/homepage claims for capabilities unless entitlement gates, API/CLI proof paths, and regression tests are green in CI.
- Treat `17.92` (pricing-entitlement consistency contract tests) as mandatory before any public claim expansion.

## 7. Hosted API Features (`/api/v1/*`)

Base app and platform controls: `skillgate/api/app.py`

- Request ID propagation, standardized error envelope, security headers, CORS hardening, bot mitigation middleware.
- Optional OpenTelemetry instrumentation.
- Redis-backed Stripe circuit breaker integration.

### 7.1 API Surface Inventory

| API Group | Key endpoints | Class | What it does | Tier / access |
|---|---|---|---|---|
| Health | `GET /health` | Basic | Service health probe | Public |
| License | `POST /license/validate`, `GET /license/tiers` | Basic | Tier/validation introspection | All |
| Verify | `POST /verify` | Complex | Signature verification service | All/paid use cases |
| Scans | `POST /scans`, `GET /scans`, `GET /scans/{scan_id}` | Complex | Submit/store/query scan reports | Authenticated |
| Hunt | `POST /hunt` | Complex | Hosted hunt query endpoint | Team+ intent |
| Retroscan | `POST /retroscan`, `GET /retroscan`, `GET /retroscan/{job_id}` | Complex | Hosted retroscan jobs | Team+ intent |
| Usage | `GET /usage/metrics` | Complex | Usage analytics and limits telemetry | Authenticated |
| API Keys | create/list/revoke/rotate/verify under `/api-keys` | Complex | Key lifecycle management | Authenticated |
| Teams | create/get/invite/list/remove under `/teams` | Complex | Team and member operations with seat checks | Team+ |
| Entitlements | `POST /entitlements/consume-scan`, `/reconcile-usage`, `GET /decision-logs` | Moat | Authoritative usage and decision audit ledger | Hosted/Enterprise ops |
| Audit | `GET /audit/export` | Complex | Audit export endpoint | Enterprise (`audit_export`) |
| Alerts | `POST /alerts/slack` | Complex | Secure webhook alert fan-out | Team+/Enterprise |
| Auth | signup/login/refresh/logout/password reset/OAuth/device/email verify/profile/account | Complex | Full account/session identity lifecycle | Authenticated/public mix |
| Payments | checkout/portal/subscription/webhooks/replay/reconcile/sync | Moat | Billing control plane + resilient webhook processing | Paid tiers |

## 8. CI/CD and Ecosystem Integrations

| Feature | Class | What it does | How implemented | How to use | Tier |
|---|---|---|---|---|---|
| GitHub Action | Complex | Install, scan, enforce, annotate, SARIF upload, optional wrapped runtime command | `skillgate/ci/github/action.yml` | use action in workflow | Team+ for annotations/blocking |
| GitLab template | Complex | Scan + enforce + artifacts + optional wrapped runtime command | `skillgate/ci/gitlab/template.yml` | include remote template | Team+ for full value |
| Bitbucket template | Complex | Same CI flow for Bitbucket pipelines | `skillgate/ci/bitbucket/template.yml` | include template step | Team+ for full value |
| Git pre-commit hooks | Basic | Local pre-commit scanning entrypoint | CLI hooks command | `skillgate hooks install` | All |

## 9. Web UI and Documentation Platform Features

### 9.1 Web Product Surface

Source: `web-ui/src/app/**/*`

- Marketing pages: home, pricing, features, about, contact, legal pages.
- Auth pages: signup, login, verify-email, success/cancel flows.
- Dashboard pages: overview, scans, usage, billing, profile, API keys.
- Docs platform pages under `/docs/*` including enterprise-specific sections.

### 9.2 Dashboard and UX Features

| Feature | Class | What it does | How implemented | Tier |
|---|---|---|---|---|
| Dashboard shell + navigation | Basic | Main authenticated product shell | `web-ui/src/components/dashboard/*` | All authenticated |
| API key creation UX | Complex | One-time display + scoped key UX | `CreateKeyForm.tsx`, API routes | Authenticated |
| Usage and billing views | Complex | Tier/usage visibility and upgrade paths | dashboard pages + API usage/payments | Paid-aware |
| Tier gating components | Complex | In-app progressive upgrade gates | `web-ui/src/components/dashboard/TierGate.tsx` | Tier-aware |
| Analytics provider hooks | Complex | Funnel and product instrumentation | `web-ui/src/components/providers/AnalyticsProvider.tsx` | Product analytics |
| Homepage control-plane narrative | Complex | Above-the-fold positioning as governance/control-plane product | `web-ui/src/components/sections/HeroSection.tsx` | All visitors |
| Pricing source-of-truth data model | Complex | Backend-managed pricing catalog with UI fallback contract | `skillgate/api/pricing_catalog.py`, `skillgate/api/routes/pricing.py`, `web-ui/src/lib/pricing.ts` | All visitors/auth users |
| Pricing conversion instrumentation | Complex | Tracks pricing interval/CTA/checkout funnel events with privacy-safe payloads | `web-ui/src/components/sections/PricingSection.tsx`, `web-ui/src/lib/analytics.ts` | Product analytics |
| Enterprise contact routing from pricing | Complex | Routes enterprise CTA to in-product contact flow with source attribution | `web-ui/src/components/sections/PricingSection.tsx`, `web-ui/src/app/contact/page.tsx` | Enterprise prospects |

### 9.3 Docs Platform Coverage

Primary docs nav source: `web-ui/src/lib/docs-nav.ts`

- Core: get started, product.
- SkillGate platform: tool docs, commands, runtime integrations, configuration.
- Reference: CLI, API, agent gateway, integrations, artifact coverage.
- Security/legal: security, legal.
- Enterprise: enterprise hub + security/compliance/deployment/procurement.
- Operations: operations + migrations.

This is a strong base for `docs.skillgate.io`-style platform docs and separate enterprise docs IA.

### 9.4 Control-Plane Narrative and Pricing Conversion (`8.14`) — In-Progress Status

Reference: `docs/IMPLEMENTATION-PLAN.md` section `8.14` (`17.85`–`17.97`).

| Task | Status (Code Audit) | Evidence in Codebase | Inventory/Docs Guidance |
|---|---|---|---|
| 17.85 Homepage narrative rewrite | Implemented | `web-ui/src/components/sections/HeroSection.tsx`, `web-ui/src/components/sections/FeaturesSection.tsx` | Position SkillGate as control-plane/governance in primary landing narrative. |
| 17.86 Control Stack module above pricing | Implemented | Dedicated `SkillGate Control Stack` module with 7 layers and unlock-tier mapping in pricing section (`web-ui/src/components/sections/PricingSection.tsx`, `web-ui/src/lib/pricing.ts`) | Treat stack as shipped UI contract and enforce with component tests. |
| 17.87 Pricing IA by governance layer | Implemented | Pricing page now groups plans by `Static / CI & Fleet / Runtime & Org Control Plane` sections (`web-ui/src/components/sections/PricingSection.tsx`) | Keep layered maturity framing as primary IA for pricing communication. |
| 17.88 Tier copy refactor contract | Partially Implemented | Tier copy now comes from backend pricing catalog with local fallback; full 8.14 alignment still in progress | Keep current copy truth-first and continue strict narrative alignment. |
| 17.89 Team fleet governance surfacing | Implemented | Team pricing card and compare rows explicitly surface fleet governance (`skillgate/api/pricing_catalog.py`, `web-ui/src/lib/pricing.ts`) | Keep fleet claims tied to entitlement proof contract in claim ledger. |
| 17.90 Enterprise column redesign (`AI Agent Control Plane`) | Implemented | Enterprise plan has strategic control-plane badges, differentiated styling, and infrastructure anchors in card body (`web-ui/src/components/sections/PricingSection.tsx`) | Keep enterprise framed as infrastructure tier, not feature upsell. |
| 17.91 Expandable deep compare matrix under pricing | Implemented | Expandable matrix with governance/compliance rows and procurement links is live (`web-ui/src/components/sections/PricingSection.tsx`, `web-ui/src/lib/pricing.ts`) | Keep matrix interaction and a11y behavior covered in tests. |
| 17.92 Pricing/entitlement consistency contract tests | Implemented | YAML claim ledger + CI validator enforce active claim IDs, entitlement key format, live entitlement capability/limit contracts, proof-key references, proof/test path integrity, and YAML-only source (`docs/CLAIM-LEDGER.yaml`, `scripts/quality/check_claim_ledger.py`, `.github/workflows/ci.yml`) | Treat as hard gate: no copy restoration without passing claim-ledger CI. |
| 17.93 Enterprise procurement path hardening | Partially Implemented | Enterprise docs hub/pages exist + pricing routes to enterprise contact (`docs/enterprise/*`, contact flow) | Procurement path exists, but governance API/compliance/deployment callouts need fuller pricing linkage. |
| 17.94 Conversion instrumentation | Implemented | Added control-stack, matrix expand, matrix link, tier CTA, and sales-contact events with experiment metadata (`web-ui/src/components/sections/PricingSection.tsx`, `web-ui/src/lib/analytics.ts`) | Keep analytics payload tests blocking regressions and preserve no-PII contract. |
| 17.95 A/B pricing narrative framework | Implemented | Deterministic variant assignment with query override + persistent seed attribution (`web-ui/src/lib/pricing-experiment.ts`) | Keep experiment attribution deterministic and test-covered. |
| 17.96 Sales enablement package | Implemented | Sales playbook plus dedicated one-pager in docs (`docs/SALES-CONTROL-PLANE-PLAYBOOK.md`, `docs/SALES-ONE-PAGER-CONTROL-PLANE.md`) | Use docs tests as release gate for narrative integrity. |
| 17.97 Pricing repositioning launch gate | Implemented | Launch gate checklist and rollback criteria documented + covered by docs contract tests (`docs/PRICING-ROLLOUT-LAUNCH-GATE.md`, `tests/docs/test_pricing_launch_controls.py`) | Keep go/no-go checklist mandatory before broad narrative rollout. |

## 10. “Basic / Complex / Moat” Rollup by Theme

| Theme | Basic highlights | Complex highlights | Moat highlights |
|---|---|---|---|
| Detection | deterministic scan, rules listing | multi-language AST+regex, artifact extraction | Unicode evasion hardening, provenance-aware filtering |
| Risk and policy | scoring formula | thresholds/permissions/overrides/domain checks | confidence-aware gating + origin-class controls |
| Trust and attestation | key generation, verify command | signed reports + canonical verification | signed runtime sessions, lineage DAG metrics |
| Runtime control plane | simple precheck plumbing | allowlist + sandbox requirement + TOP scan | AI-BOM gate, approval quorum, reputation gate, scope tokens, capability budgets |
| Commercialization | free/pro tiers | team collaboration and CI workflows | enterprise modes (private relay/airgap), signed entitlement claims |
| Hosted platform | health/license endpoints | scans/auth/teams/api-keys/usage | entitlement authority + payment/webhook resilience |

## 11. Direct Implementation Surface Index (Do-Not-Miss Checklist)

### 11.1 CLI command modules

- `skillgate/cli/commands/auth.py`
- `skillgate/cli/commands/approval.py`
- `skillgate/cli/commands/bom.py`
- `skillgate/cli/commands/dag.py`
- `skillgate/cli/commands/drift.py`
- `skillgate/cli/commands/gateway.py`
- `skillgate/cli/commands/hooks.py`
- `skillgate/cli/commands/hunt.py`
- `skillgate/cli/commands/init.py`
- `skillgate/cli/commands/keys.py`
- `skillgate/cli/commands/reputation.py`
- `skillgate/cli/commands/retroscan.py`
- `skillgate/cli/commands/rules_cmd.py`
- `skillgate/cli/commands/run.py`
- `skillgate/cli/commands/scan.py`
- `skillgate/cli/commands/simulate.py`
- `skillgate/cli/commands/verify.py`

### 11.2 Core domains

- Parser: `skillgate/core/parser/*`
- Analyzer/rules: `skillgate/core/analyzer/*`
- Scorer: `skillgate/core/scorer/*`
- Policy: `skillgate/core/policy/*`
- Signer: `skillgate/core/signer/*`
- Gateway/runtime moat: `skillgate/core/gateway/*`
- Reputation: `skillgate/core/reputation/*`
- Entitlement/commercial control plane: `skillgate/core/entitlement/*`
- Enricher + connectors: `skillgate/core/enricher/*`, `skillgate/core/connectors/*`
- Hunt/retroscan engines: `skillgate/core/hunt/*`, `skillgate/core/retroscan/*`

### 11.3 Hosted API route modules

- `skillgate/api/routes/alerts.py`
- `skillgate/api/routes/api_keys.py`
- `skillgate/api/routes/audit.py`
- `skillgate/api/routes/auth.py`
- `skillgate/api/routes/entitlements.py`
- `skillgate/api/routes/health.py`
- `skillgate/api/routes/hunt.py`
- `skillgate/api/routes/license.py`
- `skillgate/api/routes/payments.py`
- `skillgate/api/routes/retroscan.py`
- `skillgate/api/routes/scans.py`
- `skillgate/api/routes/teams.py`
- `skillgate/api/routes/usage.py`
- `skillgate/api/routes/verify.py`

### 11.4 CI templates

- `skillgate/ci/github/action.yml`
- `skillgate/ci/gitlab/template.yml`
- `skillgate/ci/bitbucket/template.yml`
- `scripts/quality/check_wrapper_enforcement.py`

### 11.5 Web UI docs and app routes

- App routes under `web-ui/src/app/`
- Docs IA source: `web-ui/src/lib/docs-nav.ts`
- Pricing feature matrix source: `skillgate/api/pricing_catalog.py` (UI fallback in `web-ui/src/lib/pricing.ts`)
- Tier gate UI logic: `web-ui/src/components/dashboard/TierGate.tsx`

## 12. Recommended Split for New Documentation Site

- Platform docs (`docs.skillgate.io`): sections 3, 4, 7, 8, 9.3.
- Enterprise docs: sections 5, 6, plus enterprise route/workflow details from 7.
- Pricing/tier docs: sections 2 + tier columns in sections 3-9.
- Security posture docs: sections 5 + app security middleware from section 7.

## 13. New Feature Feedback Summary (2026-02-20)

### 13.1 Feature 1: Background Agent Orchestration

Current implementation audit:
- Runtime controls already exist (`run`, `gateway`, approvals, lineage DAG, budgets), but there is no first-class `agent` job surface in CLI/API.
- Durable orchestration (queued/running/paused/approval/completed lifecycle) is not yet a productized control-plane service.

Classification and value summary:

| Capability | Proposed Class | Why it matters | Target tier |
|---|---|---|---|
| `skillgate agent run/ls/logs/approve/pause/cancel` thin CLI client | Complex | Makes long-running automation operable without local process coupling | Team+ |
| Server-side orchestrator with durable jobs and retries | Moat | Converts scanner + runtime controls into true enterprise automation platform | Team+/Enterprise |
| Capability-based tool runtime (repo read/patch/test/network/secrets) | Moat | Enforces least privilege and enables safe autonomy narrative | Enterprise-first |
| Policy gate on every tool invocation | Moat | Differentiator: “agents gated by policy, not trust-by-default” | Team+/Enterprise |
| Immutable audit ledger + replay/evidence export | Moat | Critical for SOC/compliance/procurement workflows | Enterprise |
| Human approval boundaries for write/policy/secret/high-risk actions | Complex | Lowers blast radius and builds operator trust | Team+/Enterprise |
| PR triage and remediation agents | Complex | Reduces reviewer load and operationalizes findings | Team (triage), Enterprise (remediation depth) |

Business fit:
- Free/OSS: suggest-only local assistant remains lightweight.
- Team: background jobs, PR comments/issues, limited remediation PR flows.
- Enterprise: RBAC/SSO approvals, retention/export, private tools/runtime, policy change governance.

### 13.2 Feature 2: Dual-Mode CLI (Session + One-Shot)

Current implementation audit:
- CLI is currently subcommand-first; root invocation prints help/branding and exits.
- No prompt-first REPL/session mode (`skillgate`, `skillgate "<prompt>"`) and no prompt one-shot mode (`skillgate -p "..."`).

Classification and value summary:

| Capability | Proposed Class | Why it matters | Target tier |
|---|---|---|---|
| Session mode (`skillgate`, `skillgate "<prompt>"`) | Complex | Improves triage/policy iteration and explanation workflows | All |
| One-shot prompt mode (`-p/--prompt`) | Complex | Makes scripting/CI/pre-commit workflows frictionless | All |
| `./.skillgate/*` + `~/.skillgate/*` auto-load for instructions/policy | Complex | Supports team-consistent repo defaults plus user-level personalization with deterministic precedence | All |
| Stable `--format text|json|sarif` + `--out` in one-shot | Basic | Required for automation contracts and toolchain interoperability | All |
| Exit code `4` for partial/timeout results (while preserving 0/1/2/3) | Complex | Improves CI observability for incomplete runs | All |
| Explicit `skillgate agent ...` surface for background jobs | Moat | Future-proofs UX without overloading prompt mode semantics | Team+/Enterprise |

Adoption fit:
- Session mode drives product usability and remediation guidance.
- One-shot mode is mandatory for CI/CD and automation adoption.
- Keeping agents explicit avoids ambiguous side effects in interactive prompts.
