# SkillGate .NET Shim

.NET client for SkillGate sidecar runtime policy decisions.

<p>
  <img src="../web-ui/public/images/hero-shield.svg" alt="SkillGate shield" width="64" />
</p>

## Projects

- `SkillGate.Client` - runtime client library
- `SkillGate.Client.Tests` - test suite

## Test and pack

```bash
cd dotnet-shim
dotnet test SkillGate.Client.Tests/SkillGate.Client.Tests.csproj
dotnet pack SkillGate.Client/SkillGate.Client.csproj -c Release
```

## Publish (maintainers)

```bash
cd dotnet-shim
dotnet nuget push SkillGate.Client/bin/Release/SkillGate.Client.VERSION.nupkg \
  --api-key "$NUGET_API_KEY" \
  --source https://api.nuget.org/v3/index.json
```

Runbook: [`../docs/Release/PUBLISH-DOTNET.md`](../docs/Release/PUBLISH-DOTNET.md)
