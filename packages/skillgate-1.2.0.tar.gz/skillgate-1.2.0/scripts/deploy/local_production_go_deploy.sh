#!/usr/bin/env bash
set -euo pipefail

PROFILE="production"
STAMP="$(date +%F)"
SKIP_GATE="false"
SKIP_SMOKE="false"
SKIP_PYPI="false"
SKIP_NPM="false"
PUBLISH_PYPI="false"
PUBLISH_NPM="false"
CLOUD_CLI_DEPLOY="false"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --profile)
      PROFILE="${2:?missing profile}"
      shift 2
      ;;
    --stamp)
      STAMP="${2:?missing stamp}"
      shift 2
      ;;
    --skip-gate)
      SKIP_GATE="true"
      shift
      ;;
    --skip-smoke)
      SKIP_SMOKE="true"
      shift
      ;;
    --skip-pypi)
      SKIP_PYPI="true"
      shift
      ;;
    --skip-npm)
      SKIP_NPM="true"
      shift
      ;;
    --publish-pypi)
      PUBLISH_PYPI="true"
      shift
      ;;
    --publish-npm)
      PUBLISH_NPM="true"
      shift
      ;;
    --cloud-cli-deploy)
      CLOUD_CLI_DEPLOY="true"
      shift
      ;;
    *)
      echo "Unknown arg: $1"
      echo "Usage: $0 [--profile production] [--stamp YYYY-MM-DD] [--skip-gate] [--skip-smoke] [--skip-pypi] [--skip-npm] [--publish-pypi] [--publish-npm] [--cloud-cli-deploy]"
      exit 2
      ;;
  esac
done

if [[ "${GITHUB_ACTIONS:-}" == "true" ]]; then
  echo "This flow is local-only. Do not run in GitHub Actions."
  exit 1
fi

if [[ ! -x "./venv/bin/python" ]]; then
  echo "Missing ./venv/bin/python. Create venv and install dependencies first."
  exit 1
fi

if [[ "${CLOUD_CLI_DEPLOY}" == "true" ]]; then
  if [[ -z "${MIGRATION_CMD:-}" ]]; then
    MIGRATION_CMD="${RAILWAY_MIGRATION_CMD:-}"
  fi
  if [[ -z "${BACKEND_DEPLOY_CMD:-}" ]]; then
    BACKEND_DEPLOY_CMD="${RAILWAY_API_DEPLOY_CMD:-}"
  fi
  if [[ -z "${WORKER_DEPLOY_CMD:-}" ]]; then
    WORKER_DEPLOY_CMD="${RAILWAY_WORKER_DEPLOY_CMD:-}"
  fi
  if [[ -z "${WEB_DEPLOY_CMD:-}" ]]; then
    WEB_DEPLOY_CMD="${NETLIFY_DEPLOY_CMD:-}"
  fi

  if [[ -z "${MIGRATION_CMD:-}" || -z "${BACKEND_DEPLOY_CMD:-}" || -z "${WORKER_DEPLOY_CMD:-}" || -z "${WEB_DEPLOY_CMD:-}" ]]; then
    echo "Cloud CLI deploy mode requires deploy commands."
    echo "Set one of:"
    echo "  - MIGRATION_CMD / BACKEND_DEPLOY_CMD / WORKER_DEPLOY_CMD / WEB_DEPLOY_CMD"
    echo "  - or RAILWAY_MIGRATION_CMD / RAILWAY_API_DEPLOY_CMD / RAILWAY_WORKER_DEPLOY_CMD / NETLIFY_DEPLOY_CMD"
    echo "See: scripts/deploy/.env.cloud-cli.example"
    exit 2
  fi
fi

run_cmd() {
  echo
  echo "[local-go] $*"
  eval "$*"
}

if [[ "${SKIP_GATE}" != "true" ]]; then
  run_cmd "./venv/bin/python scripts/quality/run_local_ci_gate.py --stamp ${STAMP}"
fi

run_cmd "./scripts/deploy/check-env-contract.sh ${PROFILE}"

if [[ -n "${MIGRATION_CMD:-}" ]]; then
  run_cmd "${MIGRATION_CMD}"
fi
if [[ -n "${BACKEND_DEPLOY_CMD:-}" ]]; then
  run_cmd "${BACKEND_DEPLOY_CMD}"
fi
if [[ -n "${WORKER_DEPLOY_CMD:-}" ]]; then
  run_cmd "${WORKER_DEPLOY_CMD}"
fi
if [[ -n "${WEB_DEPLOY_CMD:-}" ]]; then
  run_cmd "${WEB_DEPLOY_CMD}"
fi

if [[ "${SKIP_SMOKE}" != "true" ]]; then
  run_cmd "./scripts/deploy/smoke.sh ${PROFILE}"
fi

run_cmd "./venv/bin/skillgate version"
if [[ -n "${SKILLGATE_API_KEY:-}" ]]; then
  run_cmd "./venv/bin/skillgate scan tests/fixtures/skills/safe/hello-skill"
else
  echo "[local-go] Skipping CLI scan because SKILLGATE_API_KEY is not set."
fi

if [[ "${SKIP_PYPI}" != "true" ]]; then
  run_cmd "./scripts/test_package_release.sh"
  run_cmd "./venv/bin/python -m build --sdist --wheel --no-isolation --outdir /tmp/skillgate-dist"
  run_cmd "./venv/bin/python -m twine check /tmp/skillgate-dist/*"
  run_cmd "./venv/bin/pytest -m slow tests/e2e/test_packaging_release.py -v"

  if [[ "${PUBLISH_PYPI}" == "true" ]]; then
    run_cmd "./venv/bin/python -m twine upload /tmp/skillgate-dist/*"
  else
    echo "[local-go] Skipping PyPI upload (pass --publish-pypi to publish)."
  fi
fi

if [[ "${SKIP_NPM}" != "true" ]]; then
  run_cmd "./venv/bin/pytest -m slow tests/e2e/test_npm_shim_wrapper.py -v"
  run_cmd "(cd npm-shim && npm pkg get name version files bin.skillgate engines.node)"
  run_cmd "(cd npm-shim && npm pack --json > /tmp/npm-shim-pack.json)"
  run_cmd "(cd npm-shim && npm publish --access public --provenance --dry-run)"

  if [[ "${PUBLISH_NPM}" == "true" ]]; then
    run_cmd "(cd npm-shim && npm publish --access public --provenance)"
  else
    echo "[local-go] Skipping npm publish (pass --publish-npm to publish)."
  fi
fi

echo
echo "[local-go] Production local gate and deploy sequence completed."
