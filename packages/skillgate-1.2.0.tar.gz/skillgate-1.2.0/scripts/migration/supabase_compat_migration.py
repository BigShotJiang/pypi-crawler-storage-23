#!/usr/bin/env python3
"""Compatibility migration utility for Section 17.184.

This script migrates local auth data into Supabase-compatible shape using an
operator-provided mapping file.

Key properties:
- Idempotent per-user updates (safe to retry)
- Checkpoint file for resumable execution
- Dry-run summary for preflight validation
- Rollback file generation + rollback execution
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

DEFAULT_DB_URL = "sqlite:///./skillgate.db"
DEFAULT_ARTIFACT_DIR = "docs/section-17-supabase-auth-migration/artifacts"


@dataclass(frozen=True)
class MigrationRow:
    """Single user migration row from the mapping input."""

    user_id: str
    supabase_user_id: str
    email: str | None = None
    full_name: str | None = None
    email_verified: bool | None = None
    revoke_sessions: bool = True


@dataclass(frozen=True)
class MigrationSummary:
    """Serializable migration summary for operator evidence."""

    mode: str
    total_rows: int
    processed_rows: int
    skipped_checkpoint: int
    duplicate_supabase_ids_in_mapping: int
    missing_users: int
    email_mismatch: int
    user_conflicts: int
    already_migrated: int
    users_to_update: int
    users_updated: int
    sessions_to_revoke: int
    sessions_revoked: int

    @property
    def integrity_ok(self) -> bool:
        return (
            self.duplicate_supabase_ids_in_mapping == 0
            and self.missing_users == 0
            and self.email_mismatch == 0
            and self.user_conflicts == 0
        )

    def as_dict(self) -> dict[str, Any]:
        payload = {
            "mode": self.mode,
            "total_rows": self.total_rows,
            "processed_rows": self.processed_rows,
            "skipped_checkpoint": self.skipped_checkpoint,
            "duplicate_supabase_ids_in_mapping": self.duplicate_supabase_ids_in_mapping,
            "missing_users": self.missing_users,
            "email_mismatch": self.email_mismatch,
            "user_conflicts": self.user_conflicts,
            "already_migrated": self.already_migrated,
            "users_to_update": self.users_to_update,
            "users_updated": self.users_updated,
            "sessions_to_revoke": self.sessions_to_revoke,
            "sessions_revoked": self.sessions_revoked,
            "integrity_ok": self.integrity_ok,
        }
        return payload


def _resolve_database_url(input_url: str | None) -> str:
    raw = input_url or os.environ.get("SKILLGATE_DATABASE_URL", DEFAULT_DB_URL)
    if raw.startswith("postgresql+asyncpg://"):
        return raw.replace("postgresql+asyncpg://", "postgresql+psycopg://", 1)
    if raw.startswith("sqlite+aiosqlite:///"):
        return raw.replace("sqlite+aiosqlite:///", "sqlite:///", 1)
    return raw


def _now_naive_utc() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def load_mapping(path: Path) -> list[MigrationRow]:
    """Load migration rows from JSON mapping file.

    Supported shapes:
    - list of row objects
    - {"rows": [...]} object wrapper
    """

    payload = _read_json(path, default=[])
    rows_payload = payload.get("rows", []) if isinstance(payload, dict) else payload
    if not isinstance(rows_payload, list):
        raise ValueError("Mapping file must be a list or an object with a 'rows' list")

    rows: list[MigrationRow] = []
    for index, raw in enumerate(rows_payload):
        if not isinstance(raw, dict):
            raise ValueError(f"Row {index} must be an object")
        user_id = str(raw.get("user_id", "")).strip()
        supabase_user_id = str(raw.get("supabase_user_id", "")).strip()
        if not user_id or not supabase_user_id:
            raise ValueError(f"Row {index} must contain non-empty user_id and supabase_user_id")

        email_raw = raw.get("email")
        full_name_raw = raw.get("full_name")
        email_verified_raw = raw.get("email_verified")
        revoke_sessions_raw = raw.get("revoke_sessions", True)

        email = str(email_raw).strip() if email_raw is not None else None
        full_name = str(full_name_raw) if full_name_raw is not None else None
        email_verified = bool(email_verified_raw) if email_verified_raw is not None else None
        revoke_sessions = bool(revoke_sessions_raw)

        rows.append(
            MigrationRow(
                user_id=user_id,
                supabase_user_id=supabase_user_id,
                email=email,
                full_name=full_name,
                email_verified=email_verified,
                revoke_sessions=revoke_sessions,
            )
        )
    return rows


def load_checkpoint(path: Path) -> dict[str, Any]:
    """Load checkpoint file, creating a default checkpoint shape when absent."""

    payload = _read_json(path, default={})
    completed_user_ids = payload.get("completed_user_ids", [])
    if not isinstance(completed_user_ids, list):
        completed_user_ids = []
    return {
        "schema_version": 1,
        "updated_at": payload.get("updated_at"),
        "completed_user_ids": [str(value) for value in completed_user_ids],
    }


def save_checkpoint(path: Path, payload: dict[str, Any]) -> None:
    """Persist checkpoint payload."""

    payload["updated_at"] = _now_naive_utc().isoformat()
    _write_json(path, payload)


def _mapping_integrity(rows: list[MigrationRow]) -> int:
    seen: set[str] = set()
    duplicates = 0
    for row in rows:
        if row.supabase_user_id in seen:
            duplicates += 1
            continue
        seen.add(row.supabase_user_id)
    return duplicates


def _row_user_state(engine: Engine, user_id: str) -> dict[str, Any] | None:
    with engine.connect() as conn:
        result = (
            conn.execute(
                text(
                    """
                SELECT id, email, supabase_user_id, full_name, email_verified
                FROM users
                WHERE id = :user_id
                """
                ),
                {"user_id": user_id},
            )
            .mappings()
            .first()
        )
        if result is None:
            return None
        return dict(result)


def _open_session_rows(engine: Engine, user_id: str) -> list[dict[str, Any]]:
    with engine.connect() as conn:
        rows = (
            conn.execute(
                text(
                    """
                SELECT id, revoked, revoked_at
                FROM user_sessions
                WHERE user_id = :user_id AND revoked = :revoked
                """
                ),
                {"user_id": user_id, "revoked": False},
            )
            .mappings()
            .all()
        )
    return [dict(item) for item in rows]


def apply_migration(
    *,
    engine: Engine,
    rows: list[MigrationRow],
    checkpoint: dict[str, Any],
    dry_run: bool,
) -> tuple[MigrationSummary, dict[str, Any]]:
    """Apply (or dry-run) migration rows with checkpoint awareness."""

    completed = set(checkpoint.get("completed_user_ids", []))

    processed_rows = 0
    skipped_checkpoint = 0
    missing_users = 0
    email_mismatch = 0
    user_conflicts = 0
    already_migrated = 0
    users_to_update = 0
    users_updated = 0
    sessions_to_revoke = 0
    sessions_revoked = 0

    rollback_users: list[dict[str, Any]] = []
    rollback_sessions: list[dict[str, Any]] = []

    for row in rows:
        if row.user_id in completed:
            skipped_checkpoint += 1
            continue

        user_state = _row_user_state(engine, row.user_id)
        if user_state is None:
            missing_users += 1
            continue

        processed_rows += 1

        if row.email is not None and user_state.get("email") != row.email:
            email_mismatch += 1
            continue

        current_supabase_user_id = user_state.get("supabase_user_id")
        if current_supabase_user_id and current_supabase_user_id != row.supabase_user_id:
            user_conflicts += 1
            continue

        if current_supabase_user_id == row.supabase_user_id:
            already_migrated += 1
        else:
            users_to_update += 1

        session_rows = _open_session_rows(engine, row.user_id) if row.revoke_sessions else []
        sessions_to_revoke += len(session_rows)

        if not dry_run:
            with engine.begin() as conn:
                if current_supabase_user_id != row.supabase_user_id:
                    rollback_users.append(
                        {
                            "id": row.user_id,
                            "supabase_user_id": user_state.get("supabase_user_id"),
                            "full_name": user_state.get("full_name"),
                            "email_verified": user_state.get("email_verified"),
                        }
                    )
                    update_payload: dict[str, Any] = {
                        "user_id": row.user_id,
                        "supabase_user_id": row.supabase_user_id,
                        "updated_at": _now_naive_utc(),
                    }
                    set_clauses = [
                        "supabase_user_id = :supabase_user_id",
                        "updated_at = :updated_at",
                    ]
                    if row.full_name is not None:
                        update_payload["full_name"] = row.full_name
                        set_clauses.append("full_name = :full_name")
                    if row.email_verified is not None:
                        update_payload["email_verified"] = row.email_verified
                        set_clauses.append("email_verified = :email_verified")

                    conn.execute(
                        text(
                            f"""
                            UPDATE users
                            SET {", ".join(set_clauses)}
                            WHERE id = :user_id
                            """
                        ),
                        update_payload,
                    )
                    users_updated += 1

                if row.revoke_sessions and session_rows:
                    rollback_sessions.extend(session_rows)
                    conn.execute(
                        text(
                            """
                            UPDATE user_sessions
                            SET revoked = :revoked,
                                revoked_at = COALESCE(revoked_at, :revoked_at)
                            WHERE user_id = :user_id
                              AND revoked = :not_revoked
                            """
                        ),
                        {
                            "revoked": True,
                            "revoked_at": _now_naive_utc(),
                            "not_revoked": False,
                            "user_id": row.user_id,
                        },
                    )
                    sessions_revoked += len(session_rows)

                completed.add(row.user_id)
                checkpoint["completed_user_ids"] = sorted(completed)

    summary = MigrationSummary(
        mode="dry-run" if dry_run else "apply",
        total_rows=len(rows),
        processed_rows=processed_rows,
        skipped_checkpoint=skipped_checkpoint,
        duplicate_supabase_ids_in_mapping=_mapping_integrity(rows),
        missing_users=missing_users,
        email_mismatch=email_mismatch,
        user_conflicts=user_conflicts,
        already_migrated=already_migrated,
        users_to_update=users_to_update,
        users_updated=users_updated,
        sessions_to_revoke=sessions_to_revoke,
        sessions_revoked=sessions_revoked,
    )
    rollback_payload = {
        "schema_version": 1,
        "generated_at": _now_naive_utc().isoformat(),
        "users": rollback_users,
        "user_sessions": rollback_sessions,
    }
    return summary, rollback_payload


def run_rollback(
    *,
    engine: Engine,
    rollback_payload: dict[str, Any],
    dry_run: bool,
) -> dict[str, Any]:
    """Apply rollback payload generated during migration apply mode."""

    users = rollback_payload.get("users", [])
    sessions = rollback_payload.get("user_sessions", [])

    users_restored = 0
    sessions_restored = 0

    if not dry_run:
        with engine.begin() as conn:
            for item in users:
                conn.execute(
                    text(
                        """
                        UPDATE users
                        SET supabase_user_id = :supabase_user_id,
                            full_name = :full_name,
                            email_verified = :email_verified,
                            updated_at = :updated_at
                        WHERE id = :user_id
                        """
                    ),
                    {
                        "user_id": item.get("id"),
                        "supabase_user_id": item.get("supabase_user_id"),
                        "full_name": item.get("full_name"),
                        "email_verified": item.get("email_verified"),
                        "updated_at": _now_naive_utc(),
                    },
                )
                users_restored += 1

            for item in sessions:
                conn.execute(
                    text(
                        """
                        UPDATE user_sessions
                        SET revoked = :revoked,
                            revoked_at = :revoked_at
                        WHERE id = :session_id
                        """
                    ),
                    {
                        "session_id": item.get("id"),
                        "revoked": item.get("revoked", False),
                        "revoked_at": item.get("revoked_at"),
                    },
                )
                sessions_restored += 1

    return {
        "mode": "dry-run-rollback" if dry_run else "rollback",
        "users_in_payload": len(users),
        "sessions_in_payload": len(sessions),
        "users_restored": users_restored,
        "sessions_restored": sessions_restored,
        "integrity_ok": True,
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--database-url", default=None, help="Database URL (defaults to env)")
    parser.add_argument(
        "--mapping-file",
        default=None,
        help="JSON mapping file with user_id/supabase_user_id rows",
    )
    parser.add_argument(
        "--checkpoint-file",
        default=f"{DEFAULT_ARTIFACT_DIR}/supabase-compat-checkpoint.json",
        help="Checkpoint file for resumable apply",
    )
    parser.add_argument(
        "--summary-file",
        default=f"{DEFAULT_ARTIFACT_DIR}/supabase-compat-summary.json",
        help="Summary output path",
    )
    parser.add_argument(
        "--rollback-file",
        default=f"{DEFAULT_ARTIFACT_DIR}/supabase-compat-rollback.json",
        help="Rollback output/input file",
    )
    parser.add_argument("--dry-run", action="store_true", help="Compute summary without writing DB")
    parser.add_argument(
        "--rollback",
        action="store_true",
        help="Run rollback mode using --rollback-file payload",
    )
    parser.add_argument(
        "--reset-checkpoint",
        action="store_true",
        help="Ignore checkpoint completed_user_ids for this run",
    )
    return parser


def main() -> int:
    args = _parser().parse_args()

    root = Path(__file__).resolve().parents[2]
    os.chdir(root)

    db_url = _resolve_database_url(args.database_url)
    engine = create_engine(db_url, future=True)

    checkpoint_path = Path(args.checkpoint_file)
    summary_path = Path(args.summary_file)
    rollback_path = Path(args.rollback_file)

    if args.rollback:
        rollback_payload = _read_json(rollback_path, default={})
        rollback_summary = run_rollback(
            engine=engine,
            rollback_payload=rollback_payload,
            dry_run=args.dry_run,
        )
        _write_json(summary_path, rollback_summary)
        print(json.dumps(rollback_summary, indent=2, sort_keys=True))
        return 0

    if not args.mapping_file:
        raise SystemExit("--mapping-file is required unless --rollback is used")

    rows = load_mapping(Path(args.mapping_file))
    checkpoint = load_checkpoint(checkpoint_path)
    if args.reset_checkpoint:
        checkpoint["completed_user_ids"] = []

    migration_summary, rollback_payload = apply_migration(
        engine=engine,
        rows=rows,
        checkpoint=checkpoint,
        dry_run=args.dry_run,
    )

    if not args.dry_run:
        save_checkpoint(checkpoint_path, checkpoint)
        _write_json(rollback_path, rollback_payload)

    summary_payload = migration_summary.as_dict()
    _write_json(summary_path, summary_payload)
    print(json.dumps(summary_payload, indent=2, sort_keys=True))

    return 0 if migration_summary.integrity_ok else 1


if __name__ == "__main__":
    sys.exit(main())
