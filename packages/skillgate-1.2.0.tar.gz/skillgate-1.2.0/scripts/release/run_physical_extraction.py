"""Run physical repo extraction workflow for public-ce/private-ee split."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from dataclasses import dataclass
from fnmatch import fnmatch
from pathlib import Path
from typing import Any


def _load_policy(policy_path: Path) -> dict[str, Any]:
    payload = json.loads(policy_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("policy JSON root must be an object")
    return payload


def _git_tracked_files(root: Path) -> list[str]:
    proc = subprocess.run(
        ["git", "-C", str(root), "ls-files"],
        capture_output=True,
        text=True,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"failed to list git tracked files: {proc.stderr.strip()}")
    return [line.strip() for line in proc.stdout.splitlines() if line.strip()]


def _matches(path: str, patterns: list[str]) -> bool:
    return any(fnmatch(path, pattern) for pattern in patterns)


@dataclass(frozen=True)
class Selection:
    public_files: list[str]
    denied_in_public_scope: list[str]
    private_files: list[str]


def select_files(*, tracked_files: list[str], policy: dict[str, Any]) -> Selection:
    scan_cfg = policy.get("scan", {})
    include_globs = [str(p) for p in scan_cfg.get("include_globs", [])]
    ignore_globs = [str(p) for p in scan_cfg.get("ignore_globs", [])]
    deny = [str(p) for p in policy.get("deny", [])]
    allow_exceptions = [str(p) for p in policy.get("allow_exceptions", [])]

    scoped = [path for path in tracked_files if not _matches(path, ignore_globs)]
    if include_globs:
        scoped = [path for path in scoped if _matches(path, include_globs)]

    denied_in_public_scope = [
        path for path in scoped if _matches(path, deny) and not _matches(path, allow_exceptions)
    ]
    public_files = [
        path
        for path in scoped
        if not (_matches(path, deny) and not _matches(path, allow_exceptions))
    ]

    private_files = [
        path
        for path in tracked_files
        if _matches(path, deny) and not _matches(path, allow_exceptions)
    ]

    return Selection(
        public_files=sorted(public_files),
        denied_in_public_scope=sorted(denied_in_public_scope),
        private_files=sorted(private_files),
    )


def export_public_tree(*, root: Path, output_dir: Path, files: list[str]) -> None:
    if output_dir.exists():
        shutil.rmtree(output_dir)
    for rel in files:
        src = root / rel
        dst = output_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("."), help="Repo root")
    parser.add_argument(
        "--policy",
        type=Path,
        default=Path("docs/open-core/public-export-policy.json"),
        help="Policy JSON path",
    )
    parser.add_argument(
        "--public-output-dir",
        type=Path,
        default=Path("/tmp/skillgate-public-ce"),
        help="Output directory for extracted public-ce tree",
    )
    parser.add_argument(
        "--public-manifest-output",
        type=Path,
        default=Path(
            "docs/section-16-open-core-split-governance/artifacts/public-ce-manifest.json"
        ),
        help="JSON manifest output for public-ce file list",
    )
    parser.add_argument(
        "--private-manifest-output",
        type=Path,
        default=Path(
            "docs/section-16-open-core-split-governance/artifacts/private-ee-manifest.json"
        ),
        help="JSON manifest output for private-ee file list",
    )
    parser.add_argument(
        "--skip-export",
        action="store_true",
        help="Only compute manifests; do not copy files",
    )
    args = parser.parse_args()

    root = args.root.resolve()
    policy = _load_policy(args.policy.resolve())
    tracked = _git_tracked_files(root)
    selection = select_files(tracked_files=tracked, policy=policy)

    if selection.denied_in_public_scope:
        preview = "\n".join(selection.denied_in_public_scope[:20])
        raise SystemExit(f"public scope includes denied paths:\n{preview}")

    if not args.skip_export:
        export_public_tree(
            root=root,
            output_dir=args.public_output_dir.resolve(),
            files=selection.public_files,
        )

    public_manifest = {
        "ok": True,
        "policy": str(args.policy),
        "public_output_dir": str(args.public_output_dir),
        "public_file_count": len(selection.public_files),
        "public_files": selection.public_files,
    }
    private_manifest = {
        "ok": True,
        "policy": str(args.policy),
        "private_file_count": len(selection.private_files),
        "private_files": selection.private_files,
    }

    _write_json(args.public_manifest_output, public_manifest)
    _write_json(args.private_manifest_output, private_manifest)
    print(
        json.dumps(
            {
                "ok": True,
                "public_file_count": len(selection.public_files),
                "private_file_count": len(selection.private_files),
                "public_manifest": str(args.public_manifest_output),
                "private_manifest": str(args.private_manifest_output),
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
