from datetime import date
import os
from pprint import pprint

from dotenv import load_dotenv

from tariff_fetch.rateacuity import LoginState, create_context
from tariff_fetch.urdb.rateacuity_history_gas import build_urdb


def main():
    _ = load_dotenv()
    username = os.getenv("RATEACUITY_USERNAME")
    password = os.getenv("RATEACUITY_PASSWORD")
    with create_context() as context:
        state = (
            LoginState(context)
            .login(username or "", password or "")
            .gas()
            .history()
            .select_state("NY")
            .select_utility("Corning Natural Gas")
            .select_schedule("SC 14-AGGREGATE GROUP FIRM TRANSPORTATION-Residential--")
            .set_enddate(date(2025, 12, 1))
            .set_number_of_comparisons(12)
            .set_frequency(1)
        )
        report = state.as_dataframe()
        state.back_to_selections()
        print(report)
        print(report.schema)
        pprint(build_urdb(report))


def main_():
    _ = load_dotenv()
    username = os.getenv("RATEACUITY_USERNAME")
    password = os.getenv("RATEACUITY_PASSWORD")
    with create_context() as context:
        report = (
            LoginState(context)
            .login(username or "", password or "")
            .gas()
            .history()
            .select_state("RI")
            .select_utility("Rhode Island Energy (formally National Grid)")
            .select_schedule("12-RESIDENTIAL HEATING---")
            .set_enddate(date(2025, 12, 1))
            .set_number_of_comparisons(12)
            .set_frequency(1)
            .as_dataframe()
        )
        print(report)
        print(report.schema)
        print(build_urdb(report))


if __name__ == "__main__":
    main()
