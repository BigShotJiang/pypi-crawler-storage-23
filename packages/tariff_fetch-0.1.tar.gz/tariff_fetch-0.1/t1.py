from pathlib import Path
import json
from pprint import pprint
from tariff_fetch.rateacuity.schema import OtherChargesTable, Tariff
from pydantic import TypeAdapter
from tariff_fetch.urdb.rateacuity_gas import build_urdb


def main():
    p = Path("./outputs/RI.json")
    data = json.loads(p.read_bytes())
    ta = TypeAdapter(list[Tariff])
    tariffs = ta.validate_python(data)
    tariff = tariffs[1]
    result = build_urdb(tariff)

    pprint(result)
    # ta = TypeAdapter(OtherChargesSection)
    # result = ta.validate_python(data[0]["sections"][1])

    pass


if __name__ == "__main__":
    main()
