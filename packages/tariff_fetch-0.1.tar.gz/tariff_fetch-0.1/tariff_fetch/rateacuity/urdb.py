from dataclasses import dataclass
from datetime import date
from typing import NamedTuple

from polars import DataFrame

from tariff_fetch.urdb.schema import URDBRate


def build_urdb(df: DataFrame) -> URDBRate:

    pass
