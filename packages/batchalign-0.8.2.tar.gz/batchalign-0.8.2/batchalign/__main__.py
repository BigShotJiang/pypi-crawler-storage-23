from batchalign.cli.cli import batchalign

if __name__ == "__main__":
    batchalign()
