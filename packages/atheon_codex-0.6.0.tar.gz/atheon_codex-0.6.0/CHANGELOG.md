# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [PyPA Versioning Specifications](https://packaging.python.org/en/latest/specifications/version-specifiers/#version-specifiers).

## v0.1.0 - [Unreleased]

----------------------------------------------------------------