# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [0.3.24] - 2026-03-01

### Fixed
- **TokenFactoryError returned as successful text (CRITICAL)** — all 6 MCP tools (`chat`, `image`, `video`, `music`, `research`, `gems`) caught `TokenFactoryError` and returned JSON error strings with `isError: false`. MCP clients treated these as valid data, causing silent failures. Now exceptions propagate through FastMCP which correctly sets `isError: true`.
- **Chrome profile locking from stale processes** — when an existing Chrome instance held the `SingletonLock` on the profile directory, the Token Factory would fail to launch a second instance. Now kills stale Chrome processes and removes `SingletonLock` before launching.
- **Orphaned Chrome processes on exit** — when the MCP server subprocess died, Chrome was never cleaned up. Added `atexit` handler to ensure `shutdown()` runs, and `shutdown()` now cleans up `SingletonLock` files.

### Removed
- `_token_factory_error_response()` helper — no longer needed since errors propagate naturally.

---

## [0.3.23] - 2026-02-26

### Added
- **Nano Banana 2 image generation** — default image model is now Nano Banana 2 (Gemini 3.1 Flash Image), which Google shipped server-side on Feb 26, bringing Pro-level quality (text rendering, world knowledge, subject consistency) at Flash speed. `gemcli image -m pro` uses Nano Banana Pro (Gemini 3 Pro Image) for Pro/Ultra subscribers.
- **Nano Banana 2 quota tracking** — new Feature 21 in `gemcli limits` tracks Nano Banana 2 usage (100/day). Nano Banana Pro quota (Feature 19, 20/day) tracked separately.
- **Gem knowledge file uploads** — attach uploaded files (images, PDFs, documents) as knowledge sources when creating or updating gems via the 2-step `ProcessFile` resumable upload endpoint.
- **Google Drive file attachment for Gems** — attach Google Drive files as knowledge sources to gems. Drive files are processed via the `ProcessFile` batch endpoint.
- **`drive_search` action** for the `gems` MCP tool — search Google Drive directly from the gems workflow.
- **Enhanced gem listing** — `gems list` now shows attached resources (files, Drive docs, notebooks), default tool, and full instructions.
- **Email displayed in profiles** — `gemcli login --check` and `gemcli profile list` now show the Google account email for each profile (extracted from `WIZ_global_data.oPEP7c`).

### Fixed
- **Gem create/update payload format** — corrected the 18-element array structure for gem RPC calls.
- **Gems browser cookie requirement** — Token Factory trigger added to gems MCP tool for BotGuard-gated operations.
- **`login --check` always reporting expired tokens** — `Network.getAllCookies` returns cookies from all domains (youtube.com, doubleclick.net, etc.); same-name cookies from different domains collided in the flat dict, causing Gemini to serve a page without `SNlM0e`. Now filters to only `google.com`-domain cookies before saving, matching the Token Factory's existing behavior.

---

## [0.3.21] - 2026-02-23

### Fixed
- **Image download uses `=s1536` suffix** — the previous `=s2048` suffix caused CDN upscaling artifacts that broke watermark plugin compatibility. Google caps at 1024x1024 regardless, but `=s1536` produces pixel-consistent results that match the plugin's 48px alpha map. Native resolution (512x512) also didn't match the alpha map calibration.

---

## [0.3.20] - 2026-02-23

### Fixed
- **Image generation failing ("No images generated")** — root cause diagnosed via Chrome DevTools MCP capture of the live Gemini web UI:
  1. Added `tool_id=14` (IMAGE_TOOL_ID) at `inner_req_list[49]` — the web UI sends this when "Create image" tool is selected
  2. **Switched default model from Pro to Flash** — the web UI uses Flash for image generation. Pro + tool_id=14 returns empty responses (0 candidates). Flash + BotGuard + tool_id=14 works perfectly.
- Image generation now requires Chrome for BotGuard (same as video/music) but no longer requires the Pro model.

### Changed
- **Image generation default model**: Pro → Flash. Matches the Gemini web UI behavior.

---

## [0.3.19] - 2026-02-23

### Fixed
- **Image generation failing headlessly ("No images generated")** — added `tool_id=14` (IMAGE_TOOL_ID) and `force_token_factory=True` to image generation requests. Without explicit tool activation at `inner_req_list[49]`, Gemini relied on prompt heuristics and returned empty responses, especially in headless/background environments. Same class of bug as the video fix in v0.3.18.

---

## [0.3.18] - 2026-02-23

### Added
- **`VIDEO_TOOL_ID` and `IMAGE_TOOL_ID` constants** — explicit tool activation IDs for `inner_req_list[49]`, matching the codes discovered in `GemDefaultTool` (video=11, image=14, music=21).

### Fixed
- **Video generation producing images instead of videos** — added `tool_id=11` (VIDEO_TOOL_ID) to video generation requests at `inner_req_list[49]`. Without explicit tool activation, Gemini relied on prompt heuristics and frequently routed to image generation instead of Veo 3.1. Music generation already had this correct with `tool_id=21`.

---

## [0.3.17] - 2026-02-23

### Added
- **NotebookLM notebook attachment for Gems** — attach NotebookLM notebooks as knowledge sources when creating or updating gems. Reverse-engineered the `NXpLKc` RPC for listing notebooks and the client-side protobuf token format (no server round-trip needed, unlike Drive/uploaded files).
- **`list_notebooks` action** for the `gems` MCP tool — returns all NotebookLM notebooks with IDs, titles, and source counts.
- **`--notebook` CLI option** for `gemcli gems create` — repeatable flag to attach NotebookLM notebooks by UUID.
- **Notebook resources in gem listing** — `gems list` (CLI/MCP) now shows attached notebooks with source type `"notebook"` and the notebook UUID.

### Fixed
- **Multi-knowledge-entry payload format** — all knowledge entries (files, Drive docs, notebooks) are now wrapped in a single inner array (`[[entry1, entry2, ...]]`) matching the browser's behavior. Previously each entry was wrapped separately, causing only the first entry to be saved when attaching multiple knowledge sources.

---

## [0.3.16] - 2026-02-22

### Changed
- Moved plugins directory from `~/.config/gemcli/plugins/` to `~/.gemini-web-mcp-cli/plugins/` for consistency with existing config layout.

---

## [0.3.15] - 2026-02-22

### Changed
- Re-release after git history cleanup. No functional changes from 0.3.14.

---

## [0.3.14] - 2026-02-22

### Added
- **Usage limits checking** — new `gemcli limits` CLI command and `limits` MCP tool. Reverse-engineered the `qpEbW` RPC to report per-feature usage quotas (video, music, images, prompts, research, etc.) with remaining count and rolling reset time. Requires Chrome for browser cookies.
- **Video quota detection** — `wait_for_completion()` now detects quota rejection messages ("Sorry, I can't generate more videos") and raises `VideoGenerationError` immediately instead of polling for 5 minutes until timeout. MCP returns `status: "quota_exceeded"` to AI agents.
- **LimitsService** (`services/limits.py`) — new service wrapping the `qpEbW` (USAGE_INFO) RPC with `Feature` enum, `FeatureLimit` model, and structured JSON output.
- **Optional plugin directory** (`~/.config/gemcli/plugins/`) — support for drop-in plugins for potential future extensibility.

---

## [0.3.13] - 2026-02-21

### Fixed
- **Sparse protobuf response parsing** — Google A/B tests a compressed JSON format where arrays with many null elements become `[{"field_num": value}]` dicts with 1-based protobuf field numbers. This caused `has_music: false` and `has_video: false` on affected accounts. Fixed `get_nested()` in `parser.py` to handle both formats transparently.

---

## [0.3.12] - 2026-02-21

### Fixed
- Token Factory `at=` access token handling — video and music generation failed because Chrome's live `SNlM0e` token wasn't being included in replayed requests
- Video/music polling 400 errors from token mismatch between Python cache and Chrome session
- Prompt truncation in Token Factory — uses dummy string for BotGuard capture, injects real prompt in Python
- Various CDP and login stability fixes

---

## [0.3.9] - 2026-02-20

### Added
- `gemcli hack claude -m pro` — model selection flag for hack claude sessions
- Model identity injection so Gemini can correctly identify which model it's running as

### Fixed
- Pro model context loss, system prompt refusal, and prompt format issues in hack claude

---

## [0.3.0] - 2026-02-20

### Added
- **File upload support** — upload images, PDFs, documents, audio to Gemini for conversation context (`gemcli chat -f <file>`, MCP `chat` tool `files` parameter)
- **`gemcli hack claude`** — launch Claude Code connected to Gemini models via local Anthropic-compatible API server

### Fixed
- CDP Chrome startup reliability (polling loop, IPv6 resolution)
- Login profile selection terminal input handling
- FastAPI/uvicorn dependency packaging

---

## [0.2.2] - 2026-02-19

### Added
- **Video generation (Veo 3.1)** — `gemcli video`, MCP `video` tool, polling-based async generation
- **CDP page fetch download** — browser-context `fetch()` for media downloads, bypassing partitioned cookie restrictions

### Fixed
- Media download 403 errors from missing partitioned cookies
- Frame merge now preserves music/video/image data across streaming frames

---

## [0.2.0] - 2026-02-18

### Added
- **Music generation (Lyria 3)** — `gemcli music`, MCP `music` tool, 16 style presets, audio/video formats
- **Persistent Chrome daemon** — `gemcli chrome start/stop/status` for background processes
- **BotGuard for tool-based generation** — music requires BotGuard even on Flash model

---

## [0.1.x] - 2026-02-16

### 0.1.0 — Initial Alpha
Full CLI (`gemcli`) and MCP server (`gemini-web-mcp`) for the Gemini web interface: chat, image generation, deep research, gems management, multi-profile support, skill system, diagnostics (`gemcli doctor`), and MCP client setup for 8+ AI tools.

### 0.1.1 — CI/CD + PyPI
GitHub Actions release workflow (test, build, publish). First PyPI release. Lint fixes.

### 0.1.2 — Dependency Fix
Moved `mcp[cli]` to core dependencies for `uv tool install` compatibility.

### 0.1.3 — Skill Path Fix
Fixed OpenClaw skill installation directory path.

---

[0.3.24]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.23...v0.3.24
[0.3.23]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.22...v0.3.23
[0.3.22]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.21...v0.3.22
[0.3.21]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.20...v0.3.21
[0.3.20]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.19...v0.3.20
[0.3.19]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.18...v0.3.19
[0.3.18]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.17...v0.3.18
[0.3.17]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.16...v0.3.17
[0.3.16]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.15...v0.3.16
[0.3.15]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.14...v0.3.15
[0.3.14]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.13...v0.3.14
