# Defect Fixes - Token Factory & MCP Error Handling

## Defect 1: TokenFactoryError isError:false (CRITICAL)
- [x] Remove `_token_factory_error_response` helper function
- [x] chat: `except TokenFactoryError: raise` (before generic `except Exception`)
- [x] image: Remove try/except TokenFactoryError (let propagate)
- [x] video: Remove try/except TokenFactoryError (let propagate)
- [x] music: Remove except TokenFactoryError catch (keep ValueError catch)
- [x] research: Remove try/except TokenFactoryError (let propagate)
- [x] gems: Remove try/except TokenFactoryError (let propagate)

## Defect 2: Chrome Profile SingletonLock (HIGH)
- [x] Add `_kill_stale_chrome()` helper method
- [x] Call it in `ensure_ready()` before launching new Chrome
- [x] Remove stale SingletonLock file before launch

## Defect 3: Orphaned Chrome Cleanup (MEDIUM)
- [x] Add `atexit.register(self.shutdown)` in `__init__`
- [x] Add SingletonLock cleanup to `shutdown()`
