"""Service layer: business logic for each Gemini feature.

All services consume the core GeminiClient. The CLI and MCP server
call these services directly -- they are the single source of truth.
"""
