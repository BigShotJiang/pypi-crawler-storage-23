"""Authentication manager for the Gemini web interface.

Handles:
- Token extraction (SNlM0e, cfb2h, FdrFJe) from the Gemini app page
- Cookie management (__Secure-1PSID, __Secure-1PSIDTS)
- Cookie refresh via RotateCookies endpoint
- 3-layer recovery: CSRF refresh -> disk reload -> headless re-auth
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field

import httpx
from loguru import logger

from .constants import (
    COOKIE_1PSID,
    COOKIE_1PSIDTS,
    COOKIE_REFRESH_COOLDOWN,
    EMAIL_PATTERN,
    GEMINI_HEADERS,
    ROTATE_COOKIES_BODY,
    ROTATE_COOKIES_HEADERS,
    TOKEN_PATTERNS,
    Endpoint,
)
from .exceptions import AuthError
from .profiles import ProfileManager


@dataclass
class AuthTokens:
    """Extracted authentication tokens from the Gemini init page."""

    snlm0e: str = ""  # Access token (at parameter)
    cfb2h: str = ""  # Build label (bl parameter)
    fdrfje: str = ""  # Session ID (f.sid parameter)


@dataclass
class AuthState:
    """Full authentication state for a session."""

    cookies: dict[str, str] = field(default_factory=dict)
    tokens: AuthTokens = field(default_factory=AuthTokens)
    chrome_profile_path: str | None = None
    last_refreshed: float = 0.0
    email: str = ""

    def to_dict(self) -> dict:
        """Serialize to dict for storage in auth.json."""
        d = {
            "cookies": self.cookies,
            "tokens": {
                "snlm0e": self.tokens.snlm0e,
                "cfb2h": self.tokens.cfb2h,
                "fdrfje": self.tokens.fdrfje,
            },
            "chrome_profile_path": self.chrome_profile_path,
            "last_refreshed": self.last_refreshed,
        }
        if self.email:
            d["email"] = self.email
        return d

    @classmethod
    def from_dict(cls, data: dict) -> AuthState:
        """Deserialize from auth.json dict."""
        tokens_data = data.get("tokens", {})
        return cls(
            cookies=data.get("cookies", {}),
            tokens=AuthTokens(
                snlm0e=tokens_data.get("snlm0e", ""),
                cfb2h=tokens_data.get("cfb2h", ""),
                fdrfje=tokens_data.get("fdrfje", ""),
            ),
            chrome_profile_path=data.get("chrome_profile_path"),
            last_refreshed=data.get("last_refreshed", 0.0),
            email=data.get("email", ""),
        )

    @property
    def is_valid(self) -> bool:
        """Check if we have minimum required auth (cookies + access token)."""
        return bool(self.cookies.get(COOKIE_1PSID) and self.tokens.snlm0e)


def extract_tokens(html: str) -> AuthTokens:
    """Extract SNlM0e, cfb2h, and FdrFJe tokens from Gemini app page HTML."""
    tokens = AuthTokens()

    for name, pattern in TOKEN_PATTERNS.items():
        match = re.search(pattern, html)
        if match:
            setattr(tokens, name, match.group(1))

    if not tokens.snlm0e:
        raise AuthError(
            "Failed to extract SNlM0e access token from Gemini page. "
            "Cookies may be expired or invalid."
        )

    return tokens


def extract_email(html: str) -> str:
    """Extract user email from Gemini app page HTML (WIZ_global_data.oPEP7c)."""
    match = re.search(EMAIL_PATTERN, html)
    return match.group(1) if match else ""


async def fetch_tokens(
    cookies: dict[str, str],
    proxy: str | None = None,
) -> tuple[AuthTokens, httpx.Cookies, str]:
    """Fetch the Gemini app page and extract tokens + email.

    Returns (tokens, updated_cookies, email).
    """
    async with httpx.AsyncClient(
        http2=True,
        proxy=proxy,
        headers=GEMINI_HEADERS,
        cookies=cookies,
        follow_redirects=True,
    ) as client:
        response = await client.get(Endpoint.INIT)
        response.raise_for_status()
        tokens = extract_tokens(response.text)
        email = extract_email(response.text)
        return tokens, client.cookies, email


async def rotate_cookies(
    cookies: dict[str, str],
    proxy: str | None = None,
) -> dict[str, str] | None:
    """Refresh __Secure-1PSIDTS via the RotateCookies endpoint.

    Returns updated cookies dict, or None if refresh failed.
    """
    async with httpx.AsyncClient(http2=True, proxy=proxy) as client:
        response = await client.post(
            url=Endpoint.ROTATE_COOKIES,
            headers=ROTATE_COOKIES_HEADERS,
            cookies=cookies,
            content=ROTATE_COOKIES_BODY,
        )

    if response.status_code == 401:
        raise AuthError("Cookie rotation returned 401. Full re-authentication required.")

    response.raise_for_status()

    # Use .jar iteration to avoid CookieConflict with duplicate cookie names
    new_1psidts = None
    for cookie in response.cookies.jar:
        if cookie.name == COOKIE_1PSIDTS:
            new_1psidts = cookie.value
            break
    if new_1psidts:
        updated = dict(cookies)
        updated[COOKIE_1PSIDTS] = new_1psidts
        return updated

    return None


class AuthManager:
    """Manages authentication state with 3-layer recovery.

    Recovery layers:
    1. CSRF refresh: re-fetch tokens from Gemini app page
    2. Disk reload: reload auth.json from disk (may have been refreshed externally)
    3. Headless re-auth: launch Chrome via CDP to re-authenticate
    """

    def __init__(
        self,
        profile_manager: ProfileManager,
        profile_name: str | None = None,
        proxy: str | None = None,
    ):
        self.profile_manager = profile_manager
        self.profile_name = profile_name
        self.proxy = proxy
        self._state: AuthState | None = None

    @property
    def state(self) -> AuthState:
        """Get the current auth state. Raises if not initialized."""
        if self._state is None:
            raise AuthError("AuthManager not initialized. Call load() first.")
        return self._state

    def load(self) -> AuthState:
        """Load auth state from the profile's auth.json."""
        auth_data = self.profile_manager.load_auth(self.profile_name)
        if auth_data:
            self._state = AuthState.from_dict(auth_data)
        else:
            self._state = AuthState()
        return self._state

    def save(self) -> None:
        """Save current auth state to the profile's auth.json."""
        if self._state:
            self.profile_manager.save_auth(
                self._state.to_dict(),
                name=self.profile_name,
            )

    async def refresh_tokens(self) -> AuthTokens:
        """Layer 1: Re-fetch tokens from the Gemini app page."""
        if not self.state.cookies.get(COOKIE_1PSID):
            raise AuthError("No cookies available. Run `gemcli login` first.")

        logger.debug("Refreshing tokens from Gemini app page...")
        tokens, updated_cookies, email = await fetch_tokens(
            self.state.cookies, proxy=self.proxy
        )
        self.state.tokens = tokens

        if email:
            self.state.email = email

        # Iterate over .jar directly to avoid CookieConflict when Google
        # sets the same cookie name for multiple domains (e.g. SIDCC).
        for cookie in updated_cookies.jar:
            self.state.cookies[cookie.name] = cookie.value

        self.state.last_refreshed = time.time()
        self.save()
        logger.debug("Tokens refreshed successfully.")
        return tokens

    async def refresh_cookies(self) -> bool:
        """Refresh __Secure-1PSIDTS via RotateCookies.

        Respects cooldown to avoid 429 errors.
        """
        elapsed = time.time() - self.state.last_refreshed
        if elapsed < COOKIE_REFRESH_COOLDOWN:
            logger.debug(
                f"Cookie refresh cooldown: {COOKIE_REFRESH_COOLDOWN - elapsed:.0f}s remaining"
            )
            return False

        try:
            updated = await rotate_cookies(self.state.cookies, proxy=self.proxy)
            if updated:
                self.state.cookies = updated
                self.state.last_refreshed = time.time()
                self.save()
                logger.debug("Cookies refreshed via RotateCookies.")
                return True
        except AuthError:
            logger.warning("Cookie rotation failed (401). Full re-auth needed.")
            raise
        except Exception as e:
            logger.warning(f"Cookie rotation failed: {e}")

        return False

    async def recover(self) -> AuthState:
        """Attempt 3-layer recovery.

        1. Refresh tokens (re-fetch from Gemini page)
        2. Reload from disk (may have been refreshed by another process)
        3. Full re-auth (requires user interaction or headless Chrome)
        """
        # Layer 1: Try refreshing tokens
        try:
            await self.refresh_tokens()
            if self.state.is_valid:
                return self.state
        except AuthError:
            logger.debug("Layer 1 (token refresh) failed.")

        # Layer 2: Reload from disk
        try:
            self.load()
            if self.state.is_valid:
                logger.debug("Layer 2 (disk reload) succeeded.")
                return self.state
        except Exception:
            logger.debug("Layer 2 (disk reload) failed.")

        # Layer 3: Full re-auth needed
        raise AuthError(
            "All recovery layers exhausted. Run `gemcli login` to re-authenticate."
        )

    def save_cookies(self, cookies: dict[str, str]) -> None:
        """Save cookies from an external source (e.g., CDP extraction)."""
        if self._state is None:
            self._state = AuthState()
        self._state.cookies = cookies
        self._state.last_refreshed = time.time()
        self.save()
