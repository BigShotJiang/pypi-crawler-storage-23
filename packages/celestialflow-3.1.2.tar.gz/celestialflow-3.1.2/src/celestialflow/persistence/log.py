# persistence/log.py
from typing import List
from multiprocessing import Queue as MPQueue
from queue import Empty
from threading import Thread
from time import localtime, strftime
from loguru import logger as loguru_logger

from ..runtime.errors import LogLevelError
from ..runtime.tools import cleanup_mpqueue
from ..runtime.types import TerminationSignal, TERMINATION_SIGNAL
from .constant import LEVEL_DICT


class LogListener:
    """
    日志监听进程，用于将日志写入文件
    """

    def __init__(self):
        now = strftime("%Y-%m-%d", localtime())
        self.log_path = f"logs/task_logger({now}).log"
        self.log_queue = MPQueue()
        self._thread = None

    def start(self):
        loguru_logger.remove()
        loguru_logger.add(
            self.log_path,
            level="TRACE",
            format="{time:YYYY-MM-DD HH:mm:ss} {level} {message}",
            enqueue=True,
        )
        if self._thread is None or not self._thread.is_alive():
            self._thread = Thread(target=self._listen, daemon=True)
            self._thread.start()
        # self.log_queue.put({"level": "DEBUG", "message": "[Listener] Started."})

    def _listen(self):
        while True:
            try:
                record = self.log_queue.get(timeout=0.5)
                if isinstance(record, TerminationSignal):
                    break
                loguru_logger.log(record["level"], record["message"])
            except Empty:
                continue
            # except Exception as e:
            #     loguru_logger.error(f"[Listener] thread error: {type(e).__name__}({e})")

    def get_queue(self):
        return self.log_queue

    def stop(self):
        if self._thread is None:
            return

        self.log_queue.put(TERMINATION_SIGNAL)
        self._thread.join()
        self._thread = None
        cleanup_mpqueue(self.log_queue)
        # self.log_queue.put({"level": "DEBUG", "message": "[Listener] Stopped."})


class LogSinker:
    """
    多进程安全日志包装类，所有日志通过队列发送到监听进程写入
    """

    def __init__(self, log_queue, log_level="SUCCESS"):
        self.log_queue: MPQueue = log_queue
        self.log_level: str = log_level.upper()

        if self.log_level not in LEVEL_DICT:
            raise LogLevelError(self.log_level)

    def _log(self, level: str, message: str):
        level_upper = level.upper()
        if level_upper not in LEVEL_DICT:
            return
        if LEVEL_DICT[level_upper] < LEVEL_DICT[self.log_level]:
            return
        self.log_queue.put({"level": level_upper, "message": message})

    # ==== executor ====
    def start_executor(self, func_name, task_num, execution_mode_desc):
        text = (
            f"'Executor[{func_name}]' start {task_num} tasks by {execution_mode_desc}."
        )
        self._log("INFO", text)

    def end_executor(
        self,
        func_name,
        execution_mode,
        use_time,
        success_num,
        failed_num,
        duplicated_num,
    ):
        self._log(
            "INFO",
            f"'Executor[{func_name}]' end tasks by {execution_mode}. Use {use_time:.2f} second. "
            f"{success_num} tasks successed, {failed_num} tasks failed, {duplicated_num} tasks duplicated.",
        )

    # ==== stage ====
    def start_stage(self, stage_tag, execution_mode, worker_limit):
        text = f"'{stage_tag}' start tasks by {execution_mode}"
        text += f"({worker_limit} workers)." if execution_mode != "serial" else "."
        self._log("INFO", text)

    def end_stage(
        self,
        stage_tag,
        execution_mode,
        use_time,
        success_num,
        failed_num,
        duplicated_num,
    ):
        self._log(
            "INFO",
            f"'{stage_tag}' end tasks by {execution_mode}. Use {use_time:.2f} second. "
            f"{success_num} tasks successed, {failed_num} tasks failed, {duplicated_num} tasks duplicated.",
        )

    # ==== layer ====
    def start_layer(self, layer: List[str], layer_level: int):
        self._log("INFO", f"Layer {layer} start. Layer level: {layer_level}.")

    def end_layer(self, layer: List[str], use_time: float):
        self._log("INFO", f"Layer {layer} end. Use {use_time:.2f} second.")

    # ==== graph ====
    def start_graph(self, structure_list):
        self._log("INFO", f"Starting TaskGraph. Graph structure:")
        for line in structure_list:
            self._log("INFO", line)

    def end_graph(self, use_time):
        self._log("INFO", f"TaskGraph end. Use {use_time:.2f} second.")

    # ==== process ====
    def process_termination_attempt(self, process_name):
        self._log(
            "WARNING",
            f"Process '{process_name}' is still running; attempting graceful termination.",
        )

    def process_termination_timeout(self, process_name):
        self._log(
            "WARNING",
            f"Process '{process_name}' did not exit within the termination timeout.",
        )

    def process_exit(self, process_name, exitcode):
        self._log(
            "DEBUG", f"Process '{process_name}' exited with exit code {exitcode}."
        )

    # ==== task ====
    def task_input(self, func_name, task_info, source, input_id):
        self._log(
            "DEBUG",
            f"In '{func_name}', Task {task_info} input into {source}. [{input_id}*]",
        )

    def task_success(
        self,
        func_name,
        task_info,
        execution_mode,
        result_info,
        use_time,
        parent_id,
        success_id,
    ):
        self._log(
            "SUCCESS",
            f"In '{func_name}', Task {task_info} completed by {execution_mode}. Result is {result_info}. Used {use_time:.2f} seconds. [{parent_id}->{success_id}*]",
        )

    def task_retry(
        self, func_name, task_info, retry_times, exception, parent_id, retry_id
    ):
        self._log(
            "WARNING",
            f"In '{func_name}', Task {task_info} failed {retry_times} times and will retry: ({type(exception).__name__}). [{parent_id}->{retry_id}*]",
        )

    def task_error(self, func_name, task_info, exception, parent_id, error_id):
        exception_text = str(exception).replace("\n", " ")
        self._log(
            "ERROR",
            f"In '{func_name}', Task {task_info} failed and can't retry: ({type(exception).__name__}){exception_text}. [{parent_id}->{error_id}*]",
        )

    def task_duplicate(self, func_name, task_info, parent_id, duplicate_id):
        self._log(
            "SUCCESS",
            f"In '{func_name}', Task {task_info} has been duplicated. [{parent_id}->{duplicate_id}*]",
        )

    # ==== splitter ====
    def split_trace(self, func_name, part_index, part_total, parent_id, split_id):
        self._log(
            "TRACE",
            f"In '{func_name}', Task split part {part_index}/{part_total}. [{parent_id}->{split_id}*]",
        )

    def split_success(self, func_name, task_info, split_count, use_time):
        self._log(
            "SUCCESS",
            f"In '{func_name}', Task {task_info} has split into {split_count} parts. Used {use_time:.2f} seconds.",
        )

    # ==== router ====
    def route_success(
        self, func_name, task_info, target_node, use_time, parent_id, route_id
    ):
        self._log(
            "SUCCESS",
            f"In '{func_name}', Task {task_info} has routed to {target_node}. Used {use_time:.2f} seconds. [{parent_id}->{route_id}*]",
        )

    # ==== queue ====
    def put_item(self, item_type, item_id, queue_tag, stage_tag, direction):
        left, right = (
            (queue_tag, stage_tag) if direction == "in" else (stage_tag, queue_tag)
        )
        edge = f"'{left}' -> '{right}'"
        self._log("TRACE", f"Put {item_type}#{item_id} into Edge({edge}).")

    def put_item_error(self, queue_tag, stage_tag, direction, exception):
        left, right = (
            (queue_tag, stage_tag) if direction == "in" else (stage_tag, queue_tag)
        )
        edge = f"'{left}' -> '{right}'"
        exception_text = str(exception).replace("\n", " ")
        self._log(
            "WARNING",
            f"Put into Edge({edge}): ({type(exception).__name__}){exception_text}.",
        )

    def get_item(self, item_type, item_id, queue_tag, stage_tag, direction="in"):
        left, right = (
            (queue_tag, stage_tag) if direction == "in" else (stage_tag, queue_tag)
        )
        edge = f"'{left}' -> '{right}'"
        self._log("TRACE", f"Get {item_type}#{item_id} from Edge({edge}).")

    def get_item_error(
        self, queue_tag, stage_tag, direction="in", *, exception: Exception
    ):
        left, right = (
            (queue_tag, stage_tag) if direction == "in" else (stage_tag, queue_tag)
        )
        edge = f"'{left}' -> '{right}'"
        exception_text = str(exception).replace("\n", " ")
        self._log(
            "WARNING",
            f"Get from Edge({edge}): ({type(exception).__name__}){exception_text}.",
        )

    # ==== reporter ====
    def stop_reporter(self):
        self._log("DEBUG", "[Reporter] Stopped.")

    def loop_failed(self, exception):
        self._log(
            "ERROR",
            f"[Reporter] Loop error: {type(exception).__name__}({exception}).",
        )

    def pull_interval_failed(self, exception):
        self._log(
            "WARNING",
            f"[Reporter] Pull 'interval' failed: {type(exception).__name__}({exception}).",
        )

    def pull_tasks_failed(self, exception):
        self._log(
            "WARNING",
            f"[Reporter] Pull 'task injection' failed: {type(exception).__name__}({exception}).",
        )

    def inject_tasks_success(self, target_node, task_datas):
        self._log("INFO", f"[Reporter] Inject tasks {task_datas} into '{target_node}'.")

    def inject_tasks_failed(self, target_node, task_datas, exception):
        self._log(
            "WARNING",
            f"[Reporter] Inject tasks {task_datas} into '{target_node}' failed. "
            f"Error: {type(exception).__name__}({exception}).",
        )

    def push_errors_failed(self, exception):
        self._log(
            "WARNING",
            f"[Reporter] Push 'error' failed: {type(exception).__name__}({exception}).",
        )

    def push_status_failed(self, exception):
        self._log(
            "WARNING",
            f"[Reporter] Push 'status' failed: {type(exception).__name__}({exception}).",
        )

    def push_structure_failed(self, exception):
        self._log(
            "WARNING",
            f"[Reporter] Push 'structure' failed: {type(exception).__name__}({exception}).",
        )

    def push_topology_failed(self, exception):
        self._log(
            "WARNING",
            f"[Reporter] Push 'topology' failed: {type(exception).__name__}({exception}).",
        )

    def push_summary_failed(self, exception):
        self._log(
            "WARNING",
            f"[Reporter] Push 'summary' failed: {type(exception).__name__}({exception}).",
        )
