"""
Sample LlamaIndex FunctionTool definitions for eval test extraction.

Used to test --generate-eval-tests --eval-framework llamaindex.
"""

from llama_index.core.tools import FunctionTool


def get_weather(location: str, units: str = "celsius") -> str:
    """Get current weather for a location."""
    return f"Weather in {location}: 72°{units[0]}"


def search_database(query: str, limit: int = 10) -> str:
    """Search the customer database for records matching the query."""
    return f"Found {limit} results for '{query}'"


def multiply(a: int, b: int) -> int:
    """Multiply two integers and return the result."""
    return a * b


# Create tools using FunctionTool.from_defaults()
weather_tool = FunctionTool.from_defaults(get_weather)
db_tool = FunctionTool.from_defaults(fn=search_database)
math_tool = FunctionTool.from_defaults(multiply)
