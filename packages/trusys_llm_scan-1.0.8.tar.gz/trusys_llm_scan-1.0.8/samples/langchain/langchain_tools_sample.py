"""
Sample LangChain @tool definitions for eval test extraction.

Used to test --generate-eval-tests --eval-framework langchain.
"""

from langchain_core.tools import tool


@tool
def search_database(query: str, limit: int = 10) -> str:
    """Search the customer database for records matching the query."""
    return f"Found {limit} results for '{query}'"


@tool("web_search")
def search_web(query: str) -> str:
    """Search the web for information."""
    return f"Results for: {query}"


@tool
def get_weather(location: str, units: str = "celsius") -> str:
    """Get current weather for a location."""
    return f"Weather in {location}: 72°{units[0]}"
