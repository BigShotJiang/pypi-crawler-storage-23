"""
Sample LangGraph graph with tools for eval test extraction.

Used to test --generate-eval-tests --eval-framework langgraph.
"""

from typing import Annotated, Sequence, TypedDict
from langchain_core.messages import BaseMessage
from langgraph.graph import StateGraph, END, add_messages
from langgraph.prebuilt import ToolNode
from langchain_core.tools import tool


class AgentState(TypedDict):
    """State for the agent graph."""
    messages: Annotated[Sequence[BaseMessage], add_messages]


@tool
def get_weather(location: str, units: str = "celsius") -> str:
    """Get current weather for a location."""
    return f"Weather in {location}: 72°{units[0]}"


@tool
def search_database(query: str, limit: int = 10) -> str:
    """Search the customer database for records matching the query."""
    return f"Found {limit} results for '{query}'"


@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression."""
    return str(eval(expression))


def call_model(state: AgentState):
    """Call the LLM model."""
    # In real code, this would call the LLM
    return {"messages": []}


def should_continue(state: AgentState):
    """Determine if we should continue or end."""
    return "continue"


# Create the graph
workflow = StateGraph(AgentState)

# Add nodes
workflow.add_node("agent", call_model)
workflow.add_node("action", ToolNode([get_weather, search_database, calculate]))

# Set entry point
workflow.set_entry_point("agent")

# Add conditional edges
workflow.add_conditional_edges("agent", should_continue, {"continue": "action", "end": END})

# Add regular edges
workflow.add_edge("action", "agent")

# Compile the graph
graph = workflow.compile()
