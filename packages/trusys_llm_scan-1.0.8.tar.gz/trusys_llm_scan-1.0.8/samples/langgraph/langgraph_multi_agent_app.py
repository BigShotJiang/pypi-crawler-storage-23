"""
Sample LangGraph multi-agent application with 2–3 agents and tool-calling nodes.

Structure:
  - researcher: uses search + weather + DB tools
  - writer: uses summarizer tool
  - reviewer: validates and returns; no tools
  - tools_node: ToolNode for researcher tools
  - writer_tools_node: ToolNode for writer tools

Used to test --generate-eval-tests --eval-framework langgraph.
"""

from typing import Annotated, Sequence, TypedDict

from langchain_core.messages import BaseMessage
from langchain_core.tools import tool
from langgraph.graph import END, StateGraph, add_messages
from langgraph.prebuilt import ToolNode


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------


class AgentState(TypedDict):
    """Shared state across agents: messages and optional topic."""
    messages: Annotated[Sequence[BaseMessage], add_messages]
    topic: str


# ---------------------------------------------------------------------------
# Tools (used by researcher and writer nodes)
# ---------------------------------------------------------------------------


@tool
def web_search(query: str, max_results: int = 5) -> str:
    """Search the web for information. Use for research and fact-finding."""
    return f"Web search results for '{query}' (max {max_results}): [snippet 1, snippet 2, ...]"


@tool
def get_weather(location: str, units: str = "celsius") -> str:
    """Get current weather for a given location."""
    return f"Weather in {location}: 22°{units[0]}, partly cloudy."


@tool
def search_database(query: str, limit: int = 10) -> str:
    """Search the internal database for records matching the query."""
    return f"DB results for '{query}' (limit {limit}): [record1, record2, ...]"


@tool
def summarize_text(text: str, max_sentences: int = 3) -> str:
    """Summarize the given text in at most max_sentences sentences."""
    return f"Summary ({max_sentences} sentences): {text[:100]}..."


@tool
def word_count(text: str) -> str:
    """Return the word count and character count of the given text."""
    words = len(text.split())
    return f"Words: {words}, Characters: {len(text)}"


# ---------------------------------------------------------------------------
# Researcher tools (search, weather, DB)
# ---------------------------------------------------------------------------

researcher_tools = [web_search, get_weather, search_database]
researcher_tools_node = ToolNode(researcher_tools)

# Writer tools (summarize, word_count)
writer_tools = [summarize_text, word_count]
writer_tools_node = ToolNode(writer_tools)


# ---------------------------------------------------------------------------
# Agent nodes (simplified: in real app these would call an LLM with tools)
# ---------------------------------------------------------------------------

def researcher_agent(state: AgentState) -> dict:
    """Research agent: gathers info using web search, weather, and DB tools."""
    # In production: call LLM bound to researcher_tools
    return {"messages": [], "topic": state.get("topic", "")}


def writer_agent(state: AgentState) -> dict:
    """Writer agent: drafts and summarizes using summarizer and word_count tools."""
    # In production: call LLM bound to writer_tools
    return {"messages": [], "topic": state.get("topic", "")}


def reviewer_agent(state: AgentState) -> dict:
    """Reviewer agent: no tools; validates and finalizes the response."""
    return {"messages": [], "topic": state.get("topic", "")}


# ---------------------------------------------------------------------------
# Build the graph
# ---------------------------------------------------------------------------
# Pipeline: researcher (search/weather/DB) -> writer (summarize/word_count) -> reviewer
# Flow: researcher -> researcher_tools -> writer -> writer_tools -> reviewer -> end

workflow = StateGraph(AgentState)

# Nodes: 3 agents + 2 tool-execution nodes
workflow.add_node("researcher", researcher_agent)
workflow.add_node("researcher_tools", researcher_tools_node)
workflow.add_node("writer", writer_agent)
workflow.add_node("writer_tools", writer_tools_node)
workflow.add_node("reviewer", reviewer_agent)

# Entry
workflow.set_entry_point("researcher")

# Researcher -> tools -> writer -> tools -> reviewer -> end
workflow.add_edge("researcher", "researcher_tools")
workflow.add_edge("researcher_tools", "writer")
workflow.add_edge("writer", "writer_tools")
workflow.add_edge("writer_tools", "reviewer")
workflow.add_edge("reviewer", END)

# Compile
graph = workflow.compile()
