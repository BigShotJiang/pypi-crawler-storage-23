"""Tests for output formatters."""

import json
import tempfile
from pathlib import Path

import pytest

from llm_scan.models import Category, Finding, Location, ScanResult, Severity
from llm_scan.output.console import ConsoleFormatter
from llm_scan.output.json import JSONFormatter
from llm_scan.output.sarif import SARIFFormatter


@pytest.fixture
def sample_finding():
    """Create a sample finding for testing."""
    return Finding(
        rule_id="llm-code-injection-eval",
        message="LLM output is passed to eval",
        severity=Severity.CRITICAL,
        category=Category.CODE_INJECTION,
        location=Location(
            file_path="test.py",
            start_line=10,
            start_column=5,
            end_line=10,
            end_column=20,
            snippet="eval(llm_output)",
        ),
        cwe="CWE-94",
        remediation="Never execute LLM output as code",
    )


@pytest.fixture
def sample_result(sample_finding):
    """Create a sample scan result for testing."""
    return ScanResult(
        findings=[sample_finding],
        scanned_files=["test.py"],
        rules_loaded=["llm-code-injection.yaml"],
        scan_duration_seconds=1.5,
    )


def test_json_formatter(sample_result):
    """Test JSON formatter."""
    formatter = JSONFormatter()
    json_data = formatter.format(sample_result)

    assert json_data["version"] == "1.0"
    assert json_data["tool"]["name"] == "trusys-llm-scan"
    assert len(json_data["runs"]) == 1
    assert len(json_data["runs"][0]["findings"]) == 1

    finding = json_data["runs"][0]["findings"][0]
    assert finding["rule_id"] == "llm-code-injection-eval"
    assert finding["severity"] == "critical"


def test_sarif_formatter(sample_result):
    """Test SARIF formatter."""
    formatter = SARIFFormatter()
    sarif_data = formatter.format(sample_result)

    assert sarif_data["version"] == "2.1.0"
    assert len(sarif_data["runs"]) == 1
    assert "tool" in sarif_data["runs"][0]
    assert "results" in sarif_data["runs"][0]

    result = sarif_data["runs"][0]["results"][0]
    assert result["ruleId"] == "llm-code-injection-eval"
    assert result["level"] == "error"  # CRITICAL maps to error


def test_sarif_severity_mapping():
    """Test SARIF severity level mapping."""
    formatter = SARIFFormatter()

    test_cases = [
        (Severity.CRITICAL, "error"),
        (Severity.HIGH, "error"),
        (Severity.MEDIUM, "warning"),
        (Severity.LOW, "note"),
        (Severity.INFO, "note"),
    ]

    for severity, expected_level in test_cases:
        finding = Finding(
            rule_id="test",
            message="test",
            severity=severity,
            category=Category.OTHER,
            location=Location(
                file_path="test.py",
                start_line=1,
                start_column=1,
                end_line=1,
                end_column=5,
            ),
        )
        result = ScanResult(
            findings=[finding],
            scanned_files=["test.py"],
            rules_loaded=[],
            scan_duration_seconds=0.1,
        )
        sarif_data = formatter.format(result)
        assert sarif_data["runs"][0]["results"][0]["level"] == expected_level


def test_console_formatter(sample_result):
    """Test console formatter."""
    formatter = ConsoleFormatter()
    output = formatter.format(sample_result, use_color=False)

    assert "llm-code-injection-eval" in output
    assert "test.py" in output
    assert "CRITICAL" in output or "critical" in output


def test_console_formatter_no_findings():
    """Test console formatter with no findings."""
    result = ScanResult(
        findings=[],
        scanned_files=["test.py"],
        rules_loaded=[],
        scan_duration_seconds=0.1,
    )
    formatter = ConsoleFormatter()
    output = formatter.format(result, use_color=False)

    assert "No issues found" in output or "✓" in output


def test_json_formatter_write_file(sample_result, tmp_path):
    """Test JSON formatter file writing."""
    formatter = JSONFormatter()
    output_file = tmp_path / "output.json"
    formatter.write(sample_result, str(output_file))

    assert output_file.exists()
    with open(output_file) as f:
        data = json.load(f)
    assert data["version"] == "1.0"


def test_sarif_formatter_write_file(sample_result, tmp_path):
    """Test SARIF formatter file writing."""
    formatter = SARIFFormatter()
    output_file = tmp_path / "output.sarif"
    formatter.write(sample_result, str(output_file))

    assert output_file.exists()
    with open(output_file) as f:
        data = json.load(f)
    assert data["version"] == "2.1.0"
