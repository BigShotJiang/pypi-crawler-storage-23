"""Tests for MCP tool extraction and eval test generation."""

import os
from pathlib import Path

import pytest

from llm_scan.engine.mcp_extractor import extract_from_file, extract_from_files
from llm_scan.models import EvalTestCase, EvalTestResult, MCPToolDefinition, MCPToolParameter


def test_extract_from_file_tool():
    """Extract @mcp.tool() definition from source."""
    source = '''
from mcp.server.fastmcp import FastMCP
mcp = FastMCP("x")

@mcp.tool()
def run_calculation(expression: str) -> str:
    """Evaluate a math expression."""
    return str(eval(expression))
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 1
    t = tools[0]
    assert t.name == "run_calculation"
    assert "math expression" in t.description
    assert t.decorator == "tool"
    assert len(t.parameters) == 1
    assert t.parameters[0].name == "expression"
    assert t.parameters[0].type == "str"


def test_extract_from_file_async_tool():
    """Extract @mcp.async_tool() definition."""
    source = '''
@mcp.async_tool()
async def fetch_data(url: str) -> str:
    """Fetch URL."""
    return ""
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 1
    assert tools[0].name == "fetch_data"
    assert tools[0].decorator == "async_tool"
    assert tools[0].parameters[0].name == "url"


def test_extract_from_file_resource():
    """Extract @mcp.resource() handler."""
    source = '''
@mcp.resource("file:///docs/{filename}")
def get_doc(filename: str) -> str:
    """Serve file content."""
    return Path(filename).read_text()
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 1
    assert tools[0].name == "get_doc"
    assert tools[0].decorator == "resource"
    assert tools[0].parameters[0].name == "filename"


def test_extract_from_file_no_mcp():
    """File with no MCP decorators returns empty list."""
    source = "def foo(): pass"
    tools = extract_from_file("dummy.py", source=source)
    assert tools == []


def test_extract_from_files_samples_mcp():
    """Extract from samples/mcp returns expected tools."""
    samples_dir = Path(__file__).parent.parent / "samples" / "mcp"
    if not samples_dir.exists():
        pytest.skip("samples/mcp not present")
    files = [str(p) for p in samples_dir.glob("*.py")]
    tools = extract_from_files(files)
    assert len(tools) >= 1
    names = {t.name for t in tools}
    assert "run_calculation" in names or "run_command" in names or "read_file" in names


def test_mcp_tool_definition_to_manifest_dict():
    """to_manifest_dict omits source_file/line for AI payload."""
    t = MCPToolDefinition(
        name="x",
        description="y",
        parameters=[MCPToolParameter("a", "str")],
        decorator="tool",
        source_file="/path/to/file.py",
        line=10,
    )
    d = t.to_manifest_dict()
    assert d["name"] == "x"
    assert "source_file" not in d
    assert "line" not in d
    assert d["parameters"] == [{"name": "a", "type": "str"}]


def test_eval_test_result_to_dict():
    """EvalTestResult serializes to dict with tool_manifest, test_cases, meta."""
    tc = EvalTestCase(
        prompt="What is 2+3?",
        expected_tool="run_calculation",
        ground_truth="Agent should call run_calculation.",
    )
    result = EvalTestResult(
        tool_manifest=[],
        test_cases=[tc],
        generation_duration_seconds=1.0,
        ai_model_used="gpt-4",
    )
    d = result.to_dict()
    assert "tool_manifest" in d
    assert "test_cases" in d
    assert "meta" in d
    assert d["meta"]["ai_model_used"] == "gpt-4"
    assert len(d["test_cases"]) == 1
    assert d["test_cases"][0]["expected_tool"] == "run_calculation"
