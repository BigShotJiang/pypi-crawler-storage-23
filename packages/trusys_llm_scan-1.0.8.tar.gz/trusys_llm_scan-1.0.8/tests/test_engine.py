"""Tests for the Semgrep engine."""

import os
import tempfile
from pathlib import Path

import pytest

from llm_scan.config import ScanConfig
from llm_scan.engine.semgrep_engine import SemgrepEngine
from llm_scan.models import Severity


@pytest.fixture
def test_fixtures_dir():
    """Get path to test fixtures directory."""
    return Path(__file__).parent / "fixtures"


@pytest.fixture
def rules_dir():
    """Get path to rules directory."""
    return Path(__file__).parent.parent / "llm_scan" / "rules" / "python"


@pytest.fixture
def positive_fixtures(test_fixtures_dir):
    """Get list of positive test fixtures (should have findings)."""
    positive_dir = test_fixtures_dir / "positive"
    return [str(f) for f in positive_dir.glob("*.py")]


@pytest.fixture
def negative_fixtures(test_fixtures_dir):
    """Get list of negative test fixtures (should not have findings)."""
    negative_dir = test_fixtures_dir / "negative"
    return [str(f) for f in negative_dir.glob("*.py")]


def test_engine_initialization(rules_dir):
    """Test that engine can be initialized."""
    config = ScanConfig(
        paths=["."],
        rules_dir=str(rules_dir),
    )
    engine = SemgrepEngine(config)
    assert engine.config == config
    assert engine.rules_dir == str(rules_dir)


def test_scan_positive_fixtures(positive_fixtures, rules_dir):
    """Test that positive fixtures produce findings."""
    if not positive_fixtures:
        pytest.skip("No positive fixtures found")

    config = ScanConfig(
        paths=positive_fixtures,
        rules_dir=str(rules_dir),
    )
    engine = SemgrepEngine(config)
    findings = engine.scan()

    # Should find at least one vulnerability
    assert len(findings) > 0, "Expected findings in positive test fixtures"

    # Check that findings have required fields
    for finding in findings:
        assert finding.rule_id
        assert finding.message
        assert finding.severity in Severity
        assert finding.location.file_path
        assert finding.location.start_line > 0


def test_scan_negative_fixtures(negative_fixtures, rules_dir):
    """Test that negative fixtures produce no findings (or only INFO)."""
    if not negative_fixtures:
        pytest.skip("No negative fixtures found")

    config = ScanConfig(
        paths=negative_fixtures,
        rules_dir=str(rules_dir),
        severity_filter=[Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM],
    )
    engine = SemgrepEngine(config)
    findings = engine.scan()

    # Should not find critical/high/medium severity findings
    # (INFO findings are OK for inventory rules)
    critical_findings = [f for f in findings if f.severity in [Severity.CRITICAL, Severity.HIGH]]
    assert len(critical_findings) == 0, f"Found unexpected critical findings: {critical_findings}"


def test_scan_specific_rule(positive_fixtures, rules_dir):
    """Test scanning with specific rule enabled."""
    if not positive_fixtures:
        pytest.skip("No positive fixtures found")

    config = ScanConfig(
        paths=positive_fixtures,
        rules_dir=str(rules_dir),
        enabled_rules=["llm-to-eval-complete"],
    )
    engine = SemgrepEngine(config)
    findings = engine.scan()

    # All findings should be from the enabled rule
    for finding in findings:
        assert "eval" in finding.rule_id.lower() or "llm-to-eval" in finding.rule_id


def test_scan_severity_filter(positive_fixtures, rules_dir):
    """Test severity filtering."""
    if not positive_fixtures:
        pytest.skip("No positive fixtures found")

    config = ScanConfig(
        paths=positive_fixtures,
        rules_dir=str(rules_dir),
        severity_filter=[Severity.CRITICAL],
    )
    engine = SemgrepEngine(config)
    findings = engine.scan()

    # All findings should be critical
    for finding in findings:
        assert finding.severity == Severity.CRITICAL


def test_finding_structure(positive_fixtures, rules_dir):
    """Test that findings have correct structure."""
    if not positive_fixtures:
        pytest.skip("No positive fixtures found")

    config = ScanConfig(
        paths=positive_fixtures[:1],  # Just one file
        rules_dir=str(rules_dir),
    )
    engine = SemgrepEngine(config)
    findings = engine.scan()

    if findings:
        finding = findings[0]
        # Test to_dict conversion
        finding_dict = finding.to_dict()
        assert "rule_id" in finding_dict
        assert "message" in finding_dict
        assert "severity" in finding_dict
        assert "location" in finding_dict
        assert "file_path" in finding_dict["location"]


def test_rules_dir_not_found():
    """Test error when rules directory doesn't exist."""
    config = ScanConfig(
        paths=["."],
        rules_dir="/nonexistent/path",
    )
    engine = SemgrepEngine(config)
    with pytest.raises(ValueError, match="Rules directory not found"):
        engine.scan()
