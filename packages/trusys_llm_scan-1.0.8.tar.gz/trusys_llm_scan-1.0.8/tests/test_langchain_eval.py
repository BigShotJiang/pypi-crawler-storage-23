"""Tests for LangChain @tool extraction for eval test generation."""

from pathlib import Path

import pytest

from llm_scan.engine.langchain_extractor import extract_from_file, extract_from_files
from llm_scan.models import MCPToolDefinition, MCPToolParameter


def test_extract_from_file_tool_basic():
    """Extract @tool definition (function name as tool name)."""
    source = '''
from langchain.tools import tool

@tool
def search_database(query: str, limit: int = 10) -> str:
    """Search the customer database for records matching the query."""
    return f"Found {limit} results for '{query}'"
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 1
    t = tools[0]
    assert t.name == "search_database"
    assert "customer database" in t.description
    assert t.decorator == "langchain_tool"
    assert len(t.parameters) == 2
    assert t.parameters[0].name == "query"
    assert t.parameters[0].type == "str"
    assert t.parameters[1].name == "limit"
    assert t.parameters[1].type == "int"


def test_extract_from_file_tool_custom_name():
    """Extract @tool("custom_name") with explicit name."""
    source = '''
from langchain_core.tools import tool

@tool("web_search")
def search(query: str) -> str:
    """Search the web for information."""
    return f"Results for: {query}"
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 1
    t = tools[0]
    assert t.name == "web_search"
    assert "web" in t.description
    assert t.parameters[0].name == "query"


def test_extract_from_file_async_tool():
    """Extract @tool on async function."""
    source = '''
from langchain.tools import tool

@tool
async def fetch_weather(location: str) -> str:
    """Get current weather for a location."""
    return "sunny"
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 1
    assert tools[0].name == "fetch_weather"
    assert tools[0].decorator == "langchain_tool"
    assert tools[0].parameters[0].name == "location"


def test_extract_from_file_no_tool():
    """File with no @tool decorator returns empty list."""
    source = "def foo(): pass"
    tools = extract_from_file("dummy.py", source=source)
    assert tools == []


def test_extract_from_file_mcp_tool_ignored():
    """@mcp.tool() is not picked up by LangChain extractor (different decorator)."""
    source = '''
from mcp.server.fastmcp import FastMCP
mcp = FastMCP("x")

@mcp.tool()
def run_calculation(expression: str) -> str:
    """Evaluate a math expression."""
    return str(eval(expression))
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 0


def test_extract_from_file_multiple_tools():
    """Extract multiple @tool functions from one file."""
    source = '''
from langchain.tools import tool

@tool
def tool_a(x: str) -> str:
    """Tool A."""
    return x

@tool("custom_b")
def tool_b(y: int) -> str:
    """Tool B."""
    return str(y)
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 2
    names = {t.name for t in tools}
    assert "tool_a" in names
    assert "custom_b" in names


def test_langchain_tool_to_manifest_dict():
    """Extracted tool has to_manifest_dict for eval prompt generator."""
    t = MCPToolDefinition(
        name="search_db",
        description="Search the database.",
        parameters=[MCPToolParameter("q", "str")],
        decorator="langchain_tool",
        source_file="/path/to/file.py",
        line=5,
    )
    d = t.to_manifest_dict()
    assert d["name"] == "search_db"
    assert d["decorator"] == "langchain_tool"
    assert d["parameters"] == [{"name": "q", "type": "str"}]
    assert "source_file" not in d
