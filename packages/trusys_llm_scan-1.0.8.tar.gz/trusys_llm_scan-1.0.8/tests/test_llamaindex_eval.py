"""Tests for LlamaIndex FunctionTool extraction for eval test generation."""

from pathlib import Path

import pytest

from llm_scan.engine.llamaindex_extractor import extract_from_file, extract_from_files
from llm_scan.models import MCPToolDefinition, MCPToolParameter


def test_extract_from_file_functiontool_from_defaults():
    """Extract FunctionTool.from_defaults(function) definition."""
    source = '''
from llama_index.core.tools import FunctionTool

def get_weather(location: str) -> str:
    """Get current weather for a location."""
    return f"Weather in {location}: sunny"

tool = FunctionTool.from_defaults(get_weather)
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 1
    t = tools[0]
    assert t.name == "get_weather"
    assert "weather" in t.description.lower()
    assert t.decorator == "llamaindex_tool"
    assert len(t.parameters) == 1
    assert t.parameters[0].name == "location"
    assert t.parameters[0].type == "str"


def test_extract_from_file_fn_keyword():
    """Extract FunctionTool.from_defaults(fn=function) with keyword argument."""
    source = '''
from llama_index.core.tools import FunctionTool

def multiply(a: int, b: int) -> int:
    """Multiply two integers."""
    return a * b

multiply_tool = FunctionTool.from_defaults(fn=multiply)
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 1
    t = tools[0]
    assert t.name == "multiply"
    assert len(t.parameters) == 2
    assert t.parameters[0].name == "a"
    assert t.parameters[0].type == "int"
    assert t.parameters[1].name == "b"
    assert t.parameters[1].type == "int"


def test_extract_from_file_multiple_tools():
    """Extract multiple FunctionTool.from_defaults() calls."""
    source = '''
from llama_index.core.tools import FunctionTool

def tool_a(x: str) -> str:
    """Tool A."""
    return x

def tool_b(y: int) -> str:
    """Tool B."""
    return str(y)

a_tool = FunctionTool.from_defaults(tool_a)
b_tool = FunctionTool.from_defaults(fn=tool_b)
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 2
    names = {t.name for t in tools}
    assert "tool_a" in names
    assert "tool_b" in names


def test_extract_from_file_no_functiontool():
    """File with no FunctionTool.from_defaults() returns empty list."""
    source = "def foo(): pass"
    tools = extract_from_file("dummy.py", source=source)
    assert tools == []


def test_extract_from_file_functiontool_not_used():
    """Function not wrapped in FunctionTool is not extracted."""
    source = '''
def get_weather(location: str) -> str:
    """Get weather."""
    return "sunny"
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 0


def test_extract_from_file_async_function():
    """Extract async function wrapped in FunctionTool."""
    source = '''
from llama_index.core.tools import FunctionTool

async def fetch_data(url: str) -> str:
    """Fetch URL."""
    return ""

tool = FunctionTool.from_defaults(fetch_data)
'''
    tools = extract_from_file("dummy.py", source=source)
    assert len(tools) == 1
    assert tools[0].name == "fetch_data"
    assert tools[0].decorator == "llamaindex_tool"


def test_llamaindex_tool_to_manifest_dict():
    """Extracted tool has to_manifest_dict for eval prompt generator."""
    t = MCPToolDefinition(
        name="get_weather",
        description="Get weather for location.",
        parameters=[MCPToolParameter("loc", "str")],
        decorator="llamaindex_tool",
        source_file="/path/to/file.py",
        line=5,
    )
    d = t.to_manifest_dict()
    assert d["name"] == "get_weather"
    assert d["decorator"] == "llamaindex_tool"
    assert d["parameters"] == [{"name": "loc", "type": "str"}]
    assert "source_file" not in d
