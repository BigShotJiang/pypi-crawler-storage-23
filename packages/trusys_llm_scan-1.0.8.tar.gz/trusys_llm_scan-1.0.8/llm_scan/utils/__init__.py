"""Utility functions for the LLM scanner."""
