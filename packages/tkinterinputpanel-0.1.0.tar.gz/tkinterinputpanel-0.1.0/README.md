# tkinterInputPanel

A configuration-driven Tkinter input panel designed to eliminate GUI boilerplate. 

Originally developed to streamline the review of scientific measurement data and thermodynamics calculations, `tkinterInputPanel` allows you to generate complete, perfectly aligned input forms using a single Python dictionary. It automatically infers data types, builds the correct widgets (Text Entries, Checkbuttons, Comboboxes), and handles live variable tracing so you can focus on your math and data, not on GUI layout.

## Key Features
* **Zero Layout Boilerplate:** No more manual `.grid()`, `.pack()`, or `.place()` commands for every single input field.
* **Automatic Type Inference:** The panel looks at your default values and automatically creates the correct widget (e.g., a boolean becomes a checkbox, a list becomes a dropdown).
* **Live Synchronization:** Changes in the GUI instantly update your background data dictionary.
* **Custom Callbacks:** Easily hook the panel into your live Matplotlib plots or scientific models so they recalculate the millisecond a parameter is changed.

## Installation

You can install `tkinterInputPanel` directly from PyPI using pip:

```bash
pip install tkinterInputPanel
