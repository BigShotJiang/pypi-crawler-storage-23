# Code Recipes

This directory contains a collection of code examples and recipes for various frameworks and libraries.

## Examples

- **FastAPI DDD**: An implementation of Domain-Driven Design (DDD) using the Ports and Adapters architecture (Hexagonal Architecture) with the FastAPI framework.
