from collections.abc import Callable
from typing import Any, overload

from remedapy.decorator import make_data_last


@overload
def mod(divisor: int, /) -> Callable[[int], int]: ...


@overload
def mod(dividend: int, divisor: int, /) -> int: ...


@make_data_last
def mod(
    a: Any,
    b: Any,
    /,
) -> Any:
    """
    Adds two numbers.

    Alias for `operator.mod` (+) - `__mod__` magic method.

    Parameters
    ----------
    a : int | float | T
        First thing (positional-only).
    b : int | float | T
        Second thing (positional-only).

    Returns
    -------
    reminder: int
        Reminder of the division.

    Examples
    --------
    Data first:
    >>> R.mod(5, 2)
    1

    Data last:
    >>> R.mod(3)(6)
    0
    >>> R.mod(3)(8)
    2

    """
    return a % b
