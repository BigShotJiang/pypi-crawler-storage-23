from collections.abc import Callable
from typing import Any, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def lt(addend: int | float, /) -> Callable[[int | float], bool]: ...


@overload
def lt(addend: T, /) -> Callable[[T], bool]: ...


@overload
def lt(value: int | float, addend: int | float, /) -> bool: ...


@overload
def lt(value: T, addend: T, /) -> bool: ...


@make_data_last
def lt(
    a: Any,
    b: Any,
    /,
) -> Any:
    """
    Compares two values and returns True if the first is less than the second.

    Alias for `operator.lt` (<) - `__lt__` magic method.

    Parameters
    ----------
    a : int | float | T
        First thing (positional-only).
    b : int | float | T
        Second thing (positional-only).

    Returns
    -------
    bool
        True if a is less than b, False otherwise.

    Examples
    --------
    Data first:
    >>> R.lt(2, 3)
    True
    >>> R.lt(3, 3)
    False
    >>> R.lt(4, 3)
    False

    Data last:
    >>> R.lt(3)(2)
    True
    >>> R.lt(3)(3)
    False
    >>> R.lt(3)(5)
    False

    """
    return a < b
