from typing import Protocol, Self

NotSet = object()


class SupportsLt(Protocol):
    def __lt__(self, other: Self, /) -> bool: ...


class SupportsGe(Protocol):
    def __ge__(self, other: Self, /) -> bool: ...


class SupportsGtLt(Protocol):
    def __gt__(self, other: Self, /) -> bool: ...
    def __lt__(self, other: Self, /) -> bool: ...
