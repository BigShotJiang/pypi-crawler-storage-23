from collections.abc import Callable
from typing import Any, TypeGuard, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def is_list() -> Callable[[Any], TypeGuard[list[Any]]]: ...


@overload
def is_list(data: Any, /) -> TypeGuard[list[Any]]: ...


@make_data_last
def is_list(value: Any, /) -> TypeGuard[list[Any]]:
    """
    A function that checks if the passed parameter is a list and narrows its type accordingly.

    Parameters
    ----------
    value: Any
        Value to check.

    Returns
    -------
    result: TypeGuard[bool]
        Whether the value passed is list.

    Examples
    --------
    Data first:
    >>> R.is_list([])
    True
    >>> R.is_list(range(10))
    False
    >>> R.is_list(0)
    False

    Data last:
    >>> R.is_list()([1,2])
    True
    >>> R.is_list()((1,2))
    False

    """
    return isinstance(value, list)
