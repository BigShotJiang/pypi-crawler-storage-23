from collections.abc import Callable
from typing import Any, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def ge(addend: int | float, /) -> Callable[[int | float], bool]: ...


@overload
def ge(addend: T, /) -> Callable[[T], bool]: ...


@overload
def ge(value: int | float, addend: int | float, /) -> bool: ...


@overload
def ge(value: T, addend: T, /) -> bool: ...


@make_data_last
def ge(
    a: Any,
    b: Any,
    /,
) -> Any:
    """
    Compares two values and returns True if the first is greater than or equal to the second.

    Alias for `operator.ge` (>=) - `__ge__` magic method.

    Parameters
    ----------
    a : int | float | T
        First thing (positional-only).
    b : int | float | T
        Second thing (positional-only).

    Returns
    -------
    bool
        True if a is greater than or equal to b, False otherwise.

    Examples
    --------
    Data first:
    >>> R.ge(2, 3)
    False
    >>> R.ge(3, 3)
    True
    >>> R.ge(4, 3)
    True

    Data last:
    >>> R.ge(3)(2)
    False
    >>> R.ge(3)(3)
    True
    >>> R.ge(3)(5)
    True

    """
    return a >= b
