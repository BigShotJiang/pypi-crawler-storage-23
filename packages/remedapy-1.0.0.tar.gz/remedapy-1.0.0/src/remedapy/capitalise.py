from collections.abc import Callable
from typing import overload

from remedapy.decorator import make_data_last


@overload
def capitalise(s: str, /) -> str: ...


@overload
def capitalise() -> Callable[[str], str]: ...


@make_data_last
def capitalise(s: str, /) -> str:
    """
    Make the first character of the string uppercase.

    Parameters
    ----------
    s : str
        String to capitalise (positional-only).

    Returns
    -------
    str
        Capitalised string.

    Examples
    --------
    Data first:
    >>> R.capitalise('hello world')
    'Hello world'
    >>> R.capitalise('')
    ''

    Data last:
    >>> R.capitalise()('hello world')
    'Hello world'
    >>> R.capitalise()('')
    ''

    """
    if not s:
        return s
    return f'{s[0].upper()}{s[1:]}'
