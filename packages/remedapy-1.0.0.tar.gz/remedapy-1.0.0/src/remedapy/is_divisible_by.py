from collections.abc import Callable
from typing import Any, overload

from remedapy.decorator import make_data_last


@overload
def is_divisible_by(divisor: int, /) -> Callable[[int], bool]: ...


@overload
def is_divisible_by(dividend: int, divisor: int, /) -> bool: ...


@make_data_last
def is_divisible_by(
    dividend: Any,
    divisor: Any,
    /,
) -> Any:
    """
    Checks whether the first number is divisible by the second.

    Tantamount to `divisor % dividend == 0`.

    Parameters
    ----------
    dividend : int
        Number to divide (positional-only).
    divisor : int
        Number to divide by (positional-only).

    Returns
    -------
    bool
        Whether the first number is divisible by the second.

    Examples
    --------
    Data first:
    >>> R.is_divisible_by(2, 3)
    False
    >>> R.is_divisible_by(4, 2)
    True

    Data last:
    >>> R.is_divisible_by(3)(2)
    False
    >>> R.is_divisible_by(2)(4)
    True

    """
    return dividend % divisor == 0
