from collections.abc import Callable, Iterable
from typing import TypeVar, overload

from .decorator import make_data_last

T = TypeVar('T')


@overload
def drop_last(it: Iterable[T], n: int, /) -> list[T]: ...


@overload
def drop_last(n: int, /) -> Callable[[Iterable[T]], list[T]]: ...


@make_data_last
def drop_last(iterable: Iterable[T], n: int, /) -> list[T]:
    """
    Returns the list of elements of the iterable skipping the last n elements.

    Parameters
    ----------
    iterable : Iterable[T]
        Input iterable (positional-only).
    n : int
        Number of elements to not yield (positional-only).

    Returns
    -------
    list[T]
        Elements of the iterable skipping the last n elements.

    Examples
    --------
    Data first:
    >>> list(R.drop_last(range(5), 2))
    [0, 1, 2]
    >>> list(R.drop_last([2, 1, 3, 7, 6, 6, 6], 3))
    [2, 1, 3, 7]

    Data last:
    >>> list(R.drop_last([2, 1, 3, 7, 6, 6, 6], 3))
    [2, 1, 3, 7]
    >>> list(R.drop_last(range(10), 8))
    [0, 1]

    """
    list_ = list(iterable)
    return list_[:-n]
