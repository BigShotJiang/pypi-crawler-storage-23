from collections.abc import Callable
from typing import overload

from remedapy.decorator import make_data_last
from remedapy.to_words import to_words


@overload
def to_kebab_case(s: str, /) -> str: ...


@overload
def to_kebab_case() -> Callable[[str], str]: ...


@make_data_last
def to_kebab_case(s: str, /) -> str:
    """
    Makes the string kebab - lowercase, words separated by hyphens.

    Parameters
    ----------
    s : str
        String to kebab case (positional-only).

    Returns
    -------
    str
        Kebab cased string.

    Examples
    --------
    Data first:
    >>> R.to_kebab_case('hello world')
    'hello-world'
    >>> R.to_kebab_case('__HELLO_WORLD__')
    'hello-world'

    Data last:
    >>> R.to_kebab_case()('hello world')
    'hello-world'
    >>> R.to_kebab_case()('__HELLO_WORLD__')
    'hello-world'

    """
    return '-'.join(to_words(s)).lower()
