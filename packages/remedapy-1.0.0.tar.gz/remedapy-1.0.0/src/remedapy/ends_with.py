from collections.abc import Callable
from typing import overload

from remedapy.decorator import make_data_last


@overload
def ends_with(data: str, prefix: str, /) -> bool: ...


@overload
def ends_with(prefix: str, /) -> Callable[[str], bool]: ...


@make_data_last
def ends_with(string: str, suffix: str, /) -> bool:
    """
    Determines whether a string ends with the given suffix.

    Alias for string.endswith(suffix).

    Parameters
    ----------
    string : str
        Input string (positional-only).
    suffix : str
        Suffix to check (positional-only).

    Returns
    -------
    bool
        Whether the string ends with the given suffix.

    Examples
    --------
    Data first:
    >>> R.ends_with('hello world', 'hello')
    False
    >>> R.ends_with('hello world', 'world')
    True

    Data last:
    >>> R.pipe('hello world', R.ends_with('hello'))
    False
    >>> R.pipe('hello world', R.ends_with('world'))
    True

    """
    return string.endswith(suffix)
