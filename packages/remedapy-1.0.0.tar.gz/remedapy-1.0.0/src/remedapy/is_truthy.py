from collections.abc import Callable
from typing import Any, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def is_truthy() -> Callable[[Any], bool]: ...


@overload
def is_truthy(data: Any, /) -> bool: ...


@make_data_last
def is_truthy(value: Any, /) -> bool:
    """
    Returns true if the passed value is truthy.

    Alias to bool(value).

    Truthy in python definition, so falsy are e.g.:
    - 0 (int zero)
    - 0.0 (float zero)
    - '' (empty string)
    - None
    - False
    - [] (empty list)
    - {} (empty dict)
    - set() (empty set)
    - () (empty tuple)
    - range(0) (empty range)

    Parameters
    ----------
    value: Any
        Value to check.

    Returns
    -------
    result: bool
        Whether the value passed is truthy.

    Examples
    --------
    Data first:
    >>> R.is_truthy(3)
    True
    >>> R.is_truthy('asd')
    True
    >>> R.is_truthy([4])
    True
    >>> R.is_truthy(0)
    False
    >>> R.is_truthy('')
    False
    >>> R.is_truthy(None)
    False


    Data last:
    >>> R.is_truthy()(True)
    True
    >>> R.is_truthy()(False)
    False
    >>> R.is_truthy()(1)
    True

    """
    return bool(value)
