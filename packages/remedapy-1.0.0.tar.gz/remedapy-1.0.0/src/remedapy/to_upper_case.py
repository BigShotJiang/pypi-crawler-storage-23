from collections.abc import Callable
from typing import overload

from remedapy.decorator import make_data_last


@overload
def to_upper_case(s: str, /) -> str: ...


@overload
def to_upper_case() -> Callable[[str], str]: ...


@make_data_last
def to_upper_case(s: str, /) -> str:
    """
    Makes the string camel case - no spaces, first letter lowercase, next words capitalised.

    Parameters
    ----------
    s : str
        String to camel case (positional-only).
    preserve_consecutive_uppercase: bool
        Whether to not change words made of consecutive uppercase letters. Default: True.

    Returns
    -------
    str
        Camel cased string.

    Examples
    --------
    Data first:
    >>> R.to_camel_case('hello world')
    'helloWorld'
    >>> R.to_camel_case('__HELLO_WORLD__')
    'helloWorld'
    >>> R.to_camel_case('HasHTML')
    'hasHTML'
    >>> R.to_camel_case('HasHTML', preserve_consecutive_uppercase=False)
    'hasHtml'

    Data last:
    >>> R.to_camel_case()('hello world')
    'helloWorld'
    >>> R.to_camel_case()('__HELLO_WORLD__')
    'helloWorld'
    >>> R.to_camel_case()('HasHTML')
    'hasHTML'
    >>> R.to_camel_case(preserve_consecutive_uppercase=False)('HasHTML')
    'hasHtml'

    """
    return s.upper()
