import inspect
from collections.abc import Callable
from typing import TypeVar, cast, overload

from remedapy.decorator import make_data_last

Key = TypeVar('Key', str, int)
T = TypeVar('T')

Predicate = Callable[[T, Key], bool] | Callable[[T], bool] | Callable[[], bool]


@overload
def pick_by(data: dict[Key, T], predicate: Predicate[T, Key], /) -> dict[Key, T]: ...


@overload
def pick_by(predicate: Predicate[T, Key], /) -> Callable[[dict[Key, T]], dict[Key, T]]: ...


@make_data_last
def pick_by(data: dict[Key, T], predicate: Predicate[T, Key], /) -> dict[Key, T]:
    """
    Creates a new dict by picking key-value pairs satisfying the predicate.

    The predicate can have arity:
    - 0 - accept no arguments
    - 1 - accept value
    - 2 - accept value and key

    Parameters
    ----------
    data: dict[K, V]
        The dict to pick key-value pairs from.
    predicate: Callable[[T, Key], bool] | Callable[[T], bool] | Callable[[], bool]
        The predicate to apply to the key-value pairs.

    Returns
    -------
    dict[K, V]
        The new dict with the picked keys.

    See Also
    --------
    omit_by
    pick

    Examples
    --------
    Data first:
    >>> R.pick_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, lambda v, k: k == k.upper())
    {'A': 3, 'B': 4}
    >>> R.pick_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.gt(2))
    {'A': 3, 'B': 4}
    >>> R.pick_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.constant(False))
    {}
    >>> R.pick_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.constant(True))
    {'a': 1, 'b': 2, 'A': 3, 'B': 4}

    Data last:
    >>> R.pipe({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.pick_by(lambda v, k: k == k.upper()))
    {'A': 3, 'B': 4}

    """
    sig = inspect.signature(predicate)
    param_count = len(sig.parameters.values())
    if param_count > 1:
        predicate = cast(Callable[[T, Key], bool], predicate)
        return {k: v for k, v in data.items() if predicate(v, k)}
    elif param_count == 1:
        predicate = cast(Callable[[T], bool], predicate)
        return {k: v for k, v in data.items() if predicate(v)}
    else:
        predicate = cast(Callable[[], bool], predicate)
        return {k: v for k, v in data.items() if predicate()}
