import remedapy as R


class TestConstant:
    def test_data_last(self):
        # R.constant(value);

        assert list(R.map([1, 2, 3], R.constant('a'))) == ['a', 'a', 'a']
