import remedapy as R


class TestFirst:
    def test_data_first(self):
        # R.first(array)
        assert R.first([1, 2, 3]) == 1
        assert R.first([]) is None

    def test_data_last(self):
        # R.first()(array)

        def gt_3(x: int) -> bool:
            return x > 3

        assert (
            R.pipe(
                [1, 2, 4, 8, 16],
                R.filter(gt_3),
                R.first(),
                R.default_to(0),
                R.add(1),
            )
            == 5
        )
