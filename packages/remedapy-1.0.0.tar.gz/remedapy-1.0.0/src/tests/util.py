from typing import Any


class Spy:
    def __init__(self):
        self.calls: list[tuple[Any, ...]] = []

    def __call__(self, *args: Any) -> None:
        self.calls.append(args)

    def call_no_args(self) -> None:
        self.calls.append(())

    def call_one_int_arg(self, x: int):
        self.calls.append((x,))

    def call_int_str_arg(self, x: int, y: str):
        self.calls.append((x, y))

    def call_int_str_dict_arg(self, x: int, y: str, z: dict[str, int]):
        self.calls.append((x, y, z))
