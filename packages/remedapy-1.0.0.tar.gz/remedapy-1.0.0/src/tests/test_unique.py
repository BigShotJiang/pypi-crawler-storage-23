import remedapy as R


class TestUnique:
    def test_data_first(self):
        # R.unique(array);
        assert list(R.unique([1, 2, 2, 5, 1, 6, 7])) == [1, 2, 5, 6, 7]

    def test_data_last(self):
        # R.tap(fn)(value);

        assert R.pipe([1, 2, 2, 5, 1, 6, 7], R.unique(), R.take(3), list) == [1, 2, 5]
