import remedapy as R


class TestIntersectionWith:
    def test_data_first(self):
        # R.intersection_with(array, other, comparator)
        assert list(
            R.intersection_with(
                [
                    {'id': 1, 'name': 'Ryan'},
                    {'id': 3, 'name': 'Emma'},
                ],
                [3, 5],
                lambda d, x: d['id'] == x,
            ),
        ) == [{'id': 3, 'name': 'Emma'}]

    def test_data_last(self):
        # R.intersection_with(other, comparator)(array)
        def cmp(d: dict[str, int | str], x: int) -> bool:
            return d['id'] == x

        assert list(
            R.intersection_with([3, 5], cmp)(
                [
                    {'id': 1, 'name': 'Ryan'},
                    {'id': 3, 'name': 'Emma'},
                ],
            ),
        ) == [{'id': 3, 'name': 'Emma'}]
