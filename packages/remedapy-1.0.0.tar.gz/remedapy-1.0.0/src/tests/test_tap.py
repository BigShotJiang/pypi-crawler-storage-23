import remedapy as R
from tests.util import Spy


class TestTap:
    def test_data_first(self):
        # R.tap(value, fn);
        spy = Spy()
        assert R.tap('foo', spy) == 'foo'
        assert spy.calls == [('foo',)]

    def test_data_last(self):
        # R.tap(fn)(value);
        spy = Spy()

        def bigger_than_zero(n: int) -> bool:
            return n > 0

        def times_two(n: int) -> int:
            return n * 2

        assert R.pipe(
            [-5, -1, 2, 3],
            R.filter(bigger_than_zero),
            list,
            R.tap(spy),
            R.map(times_two),
            list,
        ) == [4, 6]
        assert spy.calls == [([2, 3],)]
