import remedapy as R


class TestTakeWhile:
    def test_data_first(self):
        # R.take_while(data, predicate)
        assert list(R.take_while([1, 2, 3, 4, 3, 2, 1], R.neq(4))) == [1, 2, 3]

    def test_data_last(self):
        # R.take_while(predicate)(data)
        assert R.pipe([1, 2, 3, 4, 3, 2, 1], R.take_while(R.neq(4)), list) == [1, 2, 3]
