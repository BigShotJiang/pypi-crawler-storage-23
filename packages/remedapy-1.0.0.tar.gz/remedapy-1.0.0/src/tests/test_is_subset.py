import remedapy as R


class TestIsString:
    def test_data_first(self):
        # R.is_string(data);
        assert R.is_subset({1, 2}, {1, 2, 3})
        assert R.is_subset({1, 2, 3}, {1, 2, 3})
        assert not R.is_subset({1, 2}, {1, 4})
        assert R.is_subset({'a': 3}, {'a': 3, 'b': 5})
        assert R.is_subset({'a': 3}, {'a': 3})
        assert not R.is_subset({'a': 4}, {'a': 3, 'b': 5})

    def test_data_last(self):
        # R.is_string()(data);
        assert R.is_subset({1, 2, 3})({1, 2})
        assert not R.is_subset({1, 2})({1, 4})
