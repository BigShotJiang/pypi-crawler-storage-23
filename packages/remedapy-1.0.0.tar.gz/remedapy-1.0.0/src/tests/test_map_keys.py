import remedapy as R


class TestMapKeys:
    def test_data_first(self):
        # R.map_keys(object, fn)
        def glue(key: str, v: int) -> str:
            return f'{key}{v}'

        assert R.map_keys({'a': 1, 'b': 2}, glue) == {'a1': 1, 'b2': 2}
        assert R.map_keys({'a': 1, 'bbb': 2}, R.length) == {1: 1, 3: 2}
        assert R.map_keys({'a': 1, 'bbb': 2}, R.constant('a')) == {'a': 2}

    def test_data_last(self):
        # R.map_keys(fn)(object)
        def glue(key: str, v: int) -> str:
            return f'{key}{v}'

        assert R.pipe({'a': 1, 'b': 2}, R.map_keys(glue)) == {'a1': 1, 'b2': 2}
