import remedapy as R


class TestRandomString:
    def test_data_first(self):
        # R.random_string(length)
        x = R.random_string(5)
        assert len(x) == 5
        assert all(c.isalpha() or c.isdigit() for c in x)

    def test_data_last(self):
        # R.random_string()(length)
        x = R.pipe(5, R.random_string())
        assert len(x) == 5
        assert all(c.isalpha() or c.isdigit() for c in x)
