import remedapy as R


class TestSortedIndexBy:
    def test_data_first(self):
        # R.sorted_index_by(data, item, valueFunction)
        assert R.sorted_index_by([{'age': 20}, {'age': 22}], {'age': 21}, R.prop('age')) == 1  # pyright: ignore[reportArgumentType]
        assert R.sorted_index_by([{'age': 20}, {'age': 21}], {'age': 21}, R.prop('age')) == 1  # pyright: ignore[reportArgumentType]
        assert R.sorted_index_by([{'age': 20}, {'age': 22}], {'age': 24}, R.prop('age')) == 2  # pyright: ignore[reportArgumentType]

    def test_data_last(self):
        # R.sorted_index_by(data, item, valueFunction)
        assert R.sorted_index_by({'age': 21}, R.prop('age'))([{'age': 20}, {'age': 22}]) == 1  # pyright: ignore[reportArgumentType]
