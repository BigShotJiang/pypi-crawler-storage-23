import remedapy as R


class TestFloor:
    def test_data_first(self):
        # R.floor(value, precision);
        assert R.floor(123.9876, 3) == 123.987
        assert R.floor(483.22243, 1) == 483.2
        assert R.floor(483.22243, 0) == 483
        assert R.floor(8541, -1) == 8540
        assert R.floor(456789, -3) == 456000

    def test_data_last(self):
        # R.floor(precision)(value);
        assert R.floor(3)(123.9876) == 123.987
        assert R.floor(1)(483.22243) == 483.2
        assert R.floor(-1)(8541) == 8540
        assert R.floor(-3)(456789) == 456000
