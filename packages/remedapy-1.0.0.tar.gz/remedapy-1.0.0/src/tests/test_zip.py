import remedapy as R


class TestZip:
    def test_data_first(self):
        # R.zip(first, second)
        assert list(R.zip([1, 2], ['a', 'b'])) == [(1, 'a'), (2, 'b')]

    def test_data_last(self):
        # R.zip(second)(first)
        assert list(R.zip(['a', 'b'])([1, 2])) == [(1, 'a'), (2, 'b')]
