import remedapy as R


class TestOmitBy:
    def test_data_first(self):
        # R.omit_by(data, predicate)
        def predicate2(v: int, k: str) -> bool:
            return k == k.upper()

        assert R.omit_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, predicate2) == {'a': 1, 'b': 2}
        assert R.omit_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.gt(2)) == {'a': 1, 'b': 2}
        assert R.omit_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.constant(False)) == {'a': 1, 'b': 2, 'A': 3, 'B': 4}
        assert R.omit_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.constant(True)) == {}

    def test_data_last(self):
        # R.omit_by(fn)(object)
        def predicate2(v: int, k: str) -> bool:
            return k == k.upper()

        assert R.omit_by(predicate2)({'a': 1, 'b': 2, 'A': 3, 'B': 4}) == {'a': 1, 'b': 2}
        assert R.omit_by(R.gt(2))({'a': 1, 'b': 2, 'A': 3, 'B': 4}) == {'a': 1, 'b': 2}
        assert R.omit_by(R.constant(False))({'a': 1, 'b': 2, 'A': 3, 'B': 4}) == {'a': 1, 'b': 2, 'A': 3, 'B': 4}
        assert R.omit_by(R.constant(True))({'a': 1, 'b': 2, 'A': 3, 'B': 4}) == {}
