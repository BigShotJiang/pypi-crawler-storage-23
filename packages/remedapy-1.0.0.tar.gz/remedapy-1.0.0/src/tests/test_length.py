import remedapy as R


class TestLength:
    def test_data_first(self):
        # R.length(array)
        assert R.length([1, 2, 3]) == 3
        assert R.length(x for x in range(3)) == 3

    def test_data_last(self):
        # R.length()(array)
        assert R.pipe([1, 2, 3], R.length()) == 3
