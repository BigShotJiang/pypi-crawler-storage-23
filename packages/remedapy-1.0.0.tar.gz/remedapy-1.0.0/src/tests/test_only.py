import remedapy as R


class TestOnly:
    def test_data_first(self):
        # R.only(array);
        assert R.only([]) is None
        assert R.only([1]) == 1
        assert R.only([1, 2]) is None

    def test_data_last(self):
        # R.only()(array);
        x: list[int] = []
        assert R.pipe(x, R.only()) is None
        assert R.pipe([1], R.only()) == 1
        assert R.pipe([1, 2], R.only()) is None
