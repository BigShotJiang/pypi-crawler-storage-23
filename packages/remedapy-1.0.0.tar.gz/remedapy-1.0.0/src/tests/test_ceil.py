import remedapy as R


class TestCeil:
    def test_data_first(self):
        # R.ceil(value, precision);
        assert R.ceil(123.9876, 3) == 123.988
        assert R.ceil(483.22243, 1) == 483.3
        assert R.ceil(8541, -1) == 8550
        assert R.ceil(456789, -3) == 457000
        x = R.ceil(1.3, 0)
        assert x == 2
        y = R.ceil(1, -1)
        assert y == 10
        x = R.ceil(1.3, 1)
        assert x == 1.3
        x = R.ceil(10, -1)
        assert x == 10
        assert isinstance(x, int)

    def test_data_last(self):
        # R.ceil(precision)(value);
        assert R.ceil(3)(123.9876) == 123.988
        assert R.ceil(1)(483.22243) == 483.3
        assert R.ceil(-1)(8541) == 8550
        assert R.ceil(-3)(456789) == 457000
