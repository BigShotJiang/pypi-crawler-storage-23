import remedapy as R


class TestProp:
    def test_data_first(self):
        # R.prop(data, ...keys);
        assert R.prop({'foo': {'bar': 'baz'}}, 'foo') == {'bar': 'baz'}
        assert R.prop({'foo': {'bar': 'baz'}}, 'foo', 'bar') == 'baz'
        assert R.prop(['cat', 'dog'], 1) == 'dog'

    def test_data_last(self):
        # R.prop(...keys)(data);
        assert R.pipe({'foo': {'bar': 'baz'}}, R.prop('foo')) == {'bar': 'baz'}
        assert R.pipe({'foo': {'bar': 'baz'}}, R.prop('foo', 'bar')) == 'baz'
        assert R.pipe(['cat', 'dog'], R.prop(1)) == 'dog'

    def test_error(self):
        assert R.prop([1], 1) is None
        assert R.prop({'a': 3}, 'b') is None
