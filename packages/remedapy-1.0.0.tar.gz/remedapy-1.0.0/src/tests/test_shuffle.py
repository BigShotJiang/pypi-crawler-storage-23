import remedapy as R


class TestShuffle:
    def test_data_first(self):
        # R.shuffle(array)
        s1 = R.shuffle([4, 2, 7, 5])
        assert len(s1) == 4
        assert set(s1) == {4, 2, 7, 5}

    def test_data_last(self):
        # R.shuffle()(array)
        s1 = R.pipe([4, 2, 7, 5], R.shuffle())
        assert len(s1) == 4
        assert set(s1) == {4, 2, 7, 5}
