import remedapy as R


def is_even(x: int) -> bool:
    return x % 2 == 0


class TestFind:
    def test_data_first(self):
        # R.find_index(data, predicate);
        result = R.find_index([1, 3, 4, 6], is_even)
        assert result == 2
        assert R.find_index([], is_even) == -1
        none = R.find_index([], is_even, default=None)
        assert none is None

    def test_data_last(self):
        # R.find_index(predicate)(data);
        fn = R.find_index(is_even)
        result = R.pipe(
            [1, 3, 4, 6],
            fn,
        )
        assert result == 2
        x: list[int] = []
        assert R.pipe(x, fn) == -1
