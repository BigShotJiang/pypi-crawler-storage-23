import remedapy as R


class TestGroupBy:
    def test_data_first(self):
        # R.group_by(data, callbackfn)
        assert R.group_by([{'a': 'cat'}, {'a': 'dog'}], R.prop('a')) == {'cat': [{'a': 'cat'}], 'dog': [{'a': 'dog'}]}
        assert R.group_by([0, 1], lambda x: 'even' if R.is_even(x) else None) == {'even': [0]}

    def test_data_last(self):
        # R.group_by(callbackfn)(data);
        assert R.pipe(
            [{'a': 'cat'}, {'a': 'dog'}],
            R.group_by(R.prop('a')),
        ) == {'cat': [{'a': 'cat'}], 'dog': [{'a': 'dog'}]}

        def to_key(x: int):
            return 'even' if R.is_even(x) else None

        assert R.pipe(
            [0, 1],
            R.group_by(to_key),
        ) == {'even': [0]}
