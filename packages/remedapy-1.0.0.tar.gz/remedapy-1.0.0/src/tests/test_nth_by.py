import remedapy as R


class TestNthBy:
    def test_data_first(self):
        # R.nth_by(data, index, ...rules);
        assert (
            R.nth_by(
                [
                    2,
                    1,
                    4,
                    5,
                    3,
                ],
                2,
                R.identity(),
            )
            == 3
        )

    def test_data_last(self):
        # R.nth_by(index, ...rules)(data);
        assert (
            R.pipe(
                [
                    2,
                    1,
                    4,
                    5,
                    3,
                ],
                R.nth_by(2, R.identity()),
            )
            == 3
        )
