import remedapy as R


class TestMean:
    def test_data_first(self):
        # R.mean(data);
        assert R.mean([1, 2, 3]) == 2
        assert R.mean([]) == 0

    def test_data_last(self):
        # R.mean()(data);
        assert R.pipe([1, 2, 3], R.mean()) == 2
        x: list[float] = []
        assert R.pipe(x, R.mean) == 0
