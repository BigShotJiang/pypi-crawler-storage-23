import remedapy as R


class TestEndsWith:
    def test_data_first(self):
        # R.ends_with(data, suffix);
        assert not R.ends_with('hello world', 'hello')
        assert R.ends_with('hello world', 'world')

    def test_data_last(self):
        # R.ends_with(suffix)(data);
        assert not R.pipe('hello world', R.ends_with('hello'))
        assert R.pipe('hello world', R.ends_with('world'))
