import remedapy as R


class TestFindLast:
    def test_data_first(self):
        # R.find_last(data, predicate)
        assert R.find_last([1, 3, 4, 6], R.is_odd()) == 3

    def test_data_last(self):
        # R.find_last(predicate)(data)
        assert R.pipe([1, 3, 4, 6], R.find_last(R.is_odd())) == 3
        assert R.pipe([1, 3, 4, 6], R.find_last(R.is_even())) == 6
