import remedapy as R


class TestTimes:
    def test_data_first(self):
        # R.times(count, fn)
        assert list(R.times(5, R.identity())) == [0, 1, 2, 3, 4]
        assert list(R.times(5, R.constant('a'))) == ['a', 'a', 'a', 'a', 'a']

    def test_data_last(self):
        # R.times(fn)(count)
        assert list(R.times(R.identity())(5)) == [0, 1, 2, 3, 4]
        assert list(R.times(R.constant('a'))(5)) == ['a', 'a', 'a', 'a', 'a']
