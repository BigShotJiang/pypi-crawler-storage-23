import remedapy as R


class TestIsString:
    def test_data_first(self):
        # R.is_string(data);
        assert R.is_bool(True)
        assert not R.is_bool(range(10))
        assert not R.is_bool(0)
        assert not R.is_bool(x for x in range(10))

    def test_data_last(self):
        # R.is_string()(data);
        assert R.is_bool()(False)
        assert not R.is_bool()(0)
