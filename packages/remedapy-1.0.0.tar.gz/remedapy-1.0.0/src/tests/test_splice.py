from typing import cast

import remedapy as R


class TestSplice:
    def test_data_first(self):
        # R.splice(items, start, deleteCount, replacement);
        assert list(R.splice([1, 2, 3, 4, 5, 6, 7, 8], 2, 3, [])) == [1, 2, 6, 7, 8]
        assert list(R.splice([1, 2, 3, 4, 5, 6, 7, 8], 2, 3, [9, 10])) == [1, 2, 9, 10, 6, 7, 8]

    def test_data_last(self):
        # R.splice(start, deleteCount, replacement)(items);
        assert R.pipe([1, 2, 3, 4, 5, 6, 7, 8], R.splice(2, 3, cast(list[int], [])), list) == [1, 2, 6, 7, 8]
        assert R.pipe([1, 2, 3, 4, 5, 6, 7, 8], R.splice(2, 3, [9, 10]), list) == [1, 2, 9, 10, 6, 7, 8]
        assert R.pipe((x for x in [1, 2, 3, 4, 5, 6, 7, 8]), R.splice(2, 3, cast(list[int], [])), list) == [
            1,
            2,
            6,
            7,
            8,
        ]
        assert R.pipe((x for x in [1, 2, 3, 4, 5, 6, 7, 8]), R.splice(2, 3, [9, 10]), list) == [1, 2, 9, 10, 6, 7, 8]
