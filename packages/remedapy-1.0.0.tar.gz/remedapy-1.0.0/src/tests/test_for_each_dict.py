import remedapy as R
from tests.util import Spy


class TestForEachObj:
    def test_data_first(self):
        # R.for_each_obj(object, fn)
        x = {'a': 1}
        spy = Spy()
        assert R.for_each_dict(x, spy.call_no_args) == x
        assert spy.calls == [()]
        assert R.for_each_dict(x, spy.call_one_int_arg) == x
        assert spy.calls == [(), (1,)]
        assert R.for_each_dict(x, spy.call_int_str_arg) == x
        assert spy.calls == [(), (1,), (1, 'a')]
        assert R.for_each_dict(x, spy.call_int_str_dict_arg) == x
        assert spy.calls == [(), (1,), (1, 'a'), (1, 'a', x)]

    def test_data_first_no_spy(self):
        x: list[str] = []
        result = R.for_each_dict({'a': 1, 'b': 2, 'c': 3}, lambda v, k: x.append(k + str(v)))
        assert x == ['a1', 'b2', 'c3']
        assert result == {'a': 1, 'b': 2, 'c': 3}

    def test_data_last(self):
        # R.for_each_obj(fn)(object)
        x = {'a': 1}
        spy = Spy()
        assert R.for_each_dict(spy.call_no_args)(x) == x
