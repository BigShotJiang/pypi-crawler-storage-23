import remedapy as R


class TestJoin:
    def test_data_first(self):
        # R.join(data, glue)
        assert R.join([1, 2, 3], ',') == '1,2,3'
        assert R.join(['a', 'b', 'c'], '') == 'abc'
        assert R.join(['hello', 'world'], ' ') == 'hello world'

    def test_data_last(self):
        # R.join(glue)(data)
        assert R.pipe([1, 2, 3], R.join(',')) == '1,2,3'
        assert R.pipe(['a', 'b', 'c'], R.join('')) == 'abc'
        assert R.pipe(['hello', 'world'], R.join(' ')) == 'hello world'
