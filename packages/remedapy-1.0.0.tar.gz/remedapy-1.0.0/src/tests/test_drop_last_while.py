import remedapy as R


class TestDropLastWhile:
    def test_data_first(self):
        # R.drop_last_while(data, predicate)
        assert R.drop_last_while([1, 2, 10, 3, 4], R.lt(10)) == [1, 2, 10]

    def test_data_last(self):
        # R.drop_last_while(predicate)(data)
        assert R.pipe([1, 2, 10, 3, 4], R.drop_last_while(R.lt(10))) == [1, 2, 10]
