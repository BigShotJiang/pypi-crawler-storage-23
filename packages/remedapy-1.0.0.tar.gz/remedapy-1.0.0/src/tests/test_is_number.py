import remedapy as R


class TestIsNumber:
    def test_data_first(self):
        # R.is_string(data);
        assert R.is_number(1)
        assert R.is_number(0.3)
        assert R.is_number(1e10)
        assert not R.is_number('a')

    def test_data_last(self):
        # R.is_string()(data);
        assert R.is_number()(1)
        assert not R.is_string()(1)
