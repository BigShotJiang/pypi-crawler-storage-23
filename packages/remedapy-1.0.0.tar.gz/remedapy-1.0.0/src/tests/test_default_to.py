import remedapy as R


class TestAdd:
    def test_data_first(self):
        # R.default_to(data, fallback);
        assert R.default_to('hello', 'world') == 'hello'
        assert R.default_to(None, 'world') == 'world'

    def test_data_last(self):
        # R.default_to(fallback)(data);

        assert R.pipe('hello', R.default_to('world')) == 'hello'
        assert R.pipe(None, R.default_to('world')) == 'world'
