import remedapy as R
from tests.util import Spy


class TestLazyEvaluation:
    def test_lazy_evaluation(self):
        spy = Spy()
        assert R.pipe([1, 2, 2, 3, 3, 4, 5, 6], R.tap(spy), R.unique(), R.take(3), list) == [1, 2, 3]
        # assert spy.calls == [(1,), (2,), (3,)]
        # there is something wrong with the example https://codeberg.org/Vulwsztyn/remedapy/issues/3
        # (if you run it in js)
