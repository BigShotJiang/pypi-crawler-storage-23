import remedapy as R


class TestFind:
    def test_data_first(self):
        # R.find(data, predicate);
        result = R.find([1, 3, 4, 6], R.is_even)
        assert result == 4
        assert R.find([1, 3, 4, 6], lambda x: x % 2 == 0) == 4
        assert R.find([1, 3, 4, 6], lambda x: 1 < x < 4) == 3

    def test_data_last(self):
        # R.find(predicate)(data);
        fn = R.find(R.is_even)
        result = R.pipe(
            [1, 3, 4, 6],
            fn,
        )
        assert result == 4
