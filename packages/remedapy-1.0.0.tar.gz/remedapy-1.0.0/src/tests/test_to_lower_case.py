import remedapy as R


class TestToLowerCase:
    def test_data_first(self):
        # R.to_lower_case(data);
        assert R.to_lower_case('Hello World') == 'hello world'
        x = R.map(R.to_lower_case)
        assert list(x(['Hello World'])) == ['hello world']

    def test_data_last(self):
        # R.to_lower_case()(data);
        assert R.pipe('Hello World', R.to_lower_case()) == 'hello world'
        x = R.pipe('Hello World', R.to_lower_case)
        assert x == 'hello world'
