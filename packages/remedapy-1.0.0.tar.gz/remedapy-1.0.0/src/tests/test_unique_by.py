import remedapy as R


class TestUniqueBy:
    def test_data_first(self):
        # R.unique_by(data, keyFunction)
        iterable = R.unique_by(
            [{'n': 1}, {'n': 2}, {'n': 2}, {'n': 5}, {'n': 1}, {'n': 6}, {'n': 7}],
            R.prop('n'),
        )
        assert list(iterable) == [{'n': 1}, {'n': 2}, {'n': 5}, {'n': 6}, {'n': 7}]

    def test_data_last(self):
        # R.unique_by(keyFunction)(data)
        assert R.pipe(
            [{'n': 1}, {'n': 2}, {'n': 2}, {'n': 5}, {'n': 1}, {'n': 6}, {'n': 7}],
            R.unique_by(R.prop('n')),
            R.take(3),
            list,
        ) == [{'n': 1}, {'n': 2}, {'n': 5}]
