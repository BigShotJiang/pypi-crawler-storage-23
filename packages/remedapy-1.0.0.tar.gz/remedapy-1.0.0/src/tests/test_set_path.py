import remedapy as R


class TestSetPath:
    def test_data_first(self):
        # R.set_path(obj, path, value)
        assert R.set_path({'a': {'b': 1}}, ['a', 'b'], 2) == {'a': {'b': 2}}
        assert R.set_path({'a': {'b': 1}}, ['a', 'c'], 2) == {'a': {'b': 1, 'c': 2}}

    def test_data_last(self):
        # R.set_path(path, value)(obj)
        assert R.pipe({'a': {'b': 1}}, R.set_path(['a', 'b'], 2)) == {'a': {'b': 2}}
