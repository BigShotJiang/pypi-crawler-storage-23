import remedapy as R


class TestReduce:
    def test_data_first(self):
        # R.reduce(data, callbackfn, initialValue);
        assert R.reduce([1, 2, 3, 4, 5], lambda a, x: a + x) == 15

    def test_data_last(self):
        # R.reduce(callbackfn, initialValue)(data);
        assert R.reduce(R.add)([1, 2, 3, 4, 5]) == 15
        assert R.pipe([1, 2, 3, 4, 5], R.reduce(R.add)) == 15
