import remedapy as R


class TestToCamelCase:
    def test_data_first(self):
        # R.to_camel_case(data);
        # R.to_camel_case(data, { preserve_consecutive_uppercase });
        assert R.to_camel_case('hello world') == 'helloWorld'
        assert R.to_camel_case('__HELLO_WORLD__') == 'helloWorld'
        assert R.to_camel_case('HasHTML') == 'hasHTML'
        assert R.to_camel_case('HasHTML', preserve_consecutive_uppercase=False) == 'hasHtml'

    def test_data_last(self):
        # R.to_camel_case()(data);
        # R.to_camel_case({ preserve_consecutive_uppercase })(data);
        assert R.pipe('hello world', R.to_camel_case()) == 'helloWorld'
        assert R.pipe('__HELLO_WORLD__', R.to_camel_case()) == 'helloWorld'
        assert R.pipe('HasHTML', R.to_camel_case()) == 'hasHTML'
