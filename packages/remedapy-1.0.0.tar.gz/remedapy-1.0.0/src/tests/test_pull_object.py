import remedapy as R


class TestPullObject:
    def test_data_first(self):
        # R.pull_object(data, keyExtractor, valueExtractor);
        assert R.pull_object(
            [{'name': 'john', 'email': 'john@remedajs.com'}, {'name': 'jane', 'email': 'jane@remedajs.com'}],
            R.prop('name'),
            R.prop('email'),
        ) == {'john': 'john@remedajs.com', 'jane': 'jane@remedajs.com'}

    def test_data_last(self):
        # R.pull_object(keyExtractor, valueExtractor)(data);
        assert R.pipe(
            [{'name': 'john', 'email': 'john@remedajs.com'}, {'name': 'jane', 'email': 'jane@remedajs.com'}],
            R.pull_object(R.prop('name'), R.prop('email')),
        ) == {'john': 'john@remedajs.com', 'jane': 'jane@remedajs.com'}
