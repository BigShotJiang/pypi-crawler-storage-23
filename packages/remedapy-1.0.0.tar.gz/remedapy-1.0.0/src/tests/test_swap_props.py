import remedapy as R


class TestSwapProps:
    def test_data_first(self):
        # R.swap_props(data, key1, key2)
        assert R.swap_props({'a': 1, 'b': 2, 'c': 3}, 'a', 'b') == {'a': 2, 'b': 1, 'c': 3}

    def test_data_last(self):
        # R.swap_props(key1, key2)(data)
        assert R.swap_props('a', 'b')({'a': 1, 'b': 2, 'c': 3}) == {'a': 2, 'b': 1, 'c': 3}
