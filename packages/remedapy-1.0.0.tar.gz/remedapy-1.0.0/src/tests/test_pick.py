import remedapy as R


class TestPick:
    def test_data_first(self):
        # R.pick(object, [prop1, prop2])
        assert R.pick({'a': 1, 'b': 2, 'c': 3, 'd': 4}, ['a', 'd']) == {'a': 1, 'd': 4}

    def test_data_last(self):
        # R.pick([prop1, prop2])(object)
        assert R.pipe({'a': 1, 'b': 2, 'c': 3, 'd': 4}, R.pick(['a', 'd'])) == {'a': 1, 'd': 4}
