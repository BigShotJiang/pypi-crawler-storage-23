import remedapy as R


class TestStartsWith:
    def test_data_first(self):
        # R.starts_with(data, prefix);
        assert R.starts_with('hello world', 'hello')
        assert not R.starts_with('hello world', 'world')

    def test_data_last(self):
        # R.starts_with(prefix)(data);
        assert R.pipe('hello world', R.starts_with('hello'))
        assert not R.pipe('hello world', R.starts_with('world'))
