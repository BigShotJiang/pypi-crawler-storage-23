import remedapy as R


class TestAdd:
    def test_data_first(self):
        # R.add(value, addend);
        assert R.ge(10, 5)

    def test_data_last(self):
        # R.add(addend)(value);
        assert R.ge(5)(10)
