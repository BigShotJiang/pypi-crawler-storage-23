from collections.abc import Callable

import remedapy as R


def is_divisible_by(n: int) -> Callable[[int], bool]:
    return lambda x: x % n == 0


fns = [is_divisible_by(3), is_divisible_by(4)]


class TestAllPass:
    def test_data_first(self):
        # R.all_pass(data, fns);
        assert R.all_pass(12, fns)
        assert not R.all_pass(10, fns)

    def test_data_last(self):
        # R.all_pass(fns)(data);
        assert R.all_pass(fns)(12)
        assert not R.all_pass(fns)(10)
