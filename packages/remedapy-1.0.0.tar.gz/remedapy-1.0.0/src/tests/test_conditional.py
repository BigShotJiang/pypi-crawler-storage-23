import remedapy as R


class TestConditional:
    def test_data_first(self):
        # R.conditional(data, ...cases);
        nameOrId: str | int | bool = 3
        r: str = R.conditional(
            nameOrId,
            [(R.is_string, lambda name: f'Hello {name}'), (R.is_number, lambda id: f'Hello ID: {id}')],
        )
        assert r == 'Hello ID: 3'
        r2: str | None = R.conditional(
            nameOrId,
            [
                (R.is_string, lambda name: f'Hello {name}'),
                (R.is_number, lambda id: f'Hello ID: {id}'),
                (R.constant(True), R.constant(None)),
            ],
        )
        assert r2 == 'Hello ID: 3'
        r3: str | None = R.conditional(
            nameOrId,
            [
                (R.is_string, lambda name: f'Hello {name}'),
                (R.is_number, lambda id: f'Hello ID: {id}'),
                R.constant(None),
            ],
        )
        assert r3 == 'Hello ID: 3'
        r4: str = R.conditional(
            nameOrId,
            [
                (R.is_string, lambda name: f'Hello {name}'),
                (R.is_number, lambda id: f'Hello ID: {id}'),
                R.constant(''),
            ],
        )
        assert r4 == 'Hello ID: 3'
        r5: str = R.conditional(
            None,
            [
                (R.is_string, lambda name: f'Hello {name}'),
                (R.is_number, lambda id: f'Hello ID: {id}'),
                R.constant(''),
            ],
        )
        assert r5 == ''

    def test_data_last(self):
        # R.conditional(...cases)(data);
        cond = R.conditional(
            [
                (R.is_string, lambda name: f'Hello {name}'),
                (R.is_number, lambda id: f'Hello ID: {id}'),
            ],
        )
        x: str = cond(3)
        assert x == 'Hello ID: 3'
        cond2 = R.conditional(
            [
                (R.is_string, lambda name: f'Hello {name}'),
                (R.is_number, lambda id: f'Hello ID: {id}'),
                R.constant(None),
            ],
        )
        x2: str | None = cond2('3')
        assert x2 == 'Hello 3'
