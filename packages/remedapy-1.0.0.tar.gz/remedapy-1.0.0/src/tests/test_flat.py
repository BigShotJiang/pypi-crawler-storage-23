import remedapy as R


class TestFlat:
    def test_data_first(self):
        # R.flat(data)
        # R.flat(data, depth)
        assert list(R.flat([[1, 2], [3, 4], [5], [[6]]])) == [1, 2, 3, 4, 5, 6]
        assert list(R.flat([[[1]], [[[2]]]], depth=2)) == [1, [2]]

    def test_data_last(self):
        # R.flat()(data)
        # R.flat(depth)(data)
        assert R.pipe([[1, 2], [3, 4], [5], [[6]]], R.flat(), list) == [1, 2, 3, 4, 5, 6]
        assert R.pipe([[[1]], [[[2]]]], R.flat(depth=2), list) == [1, [2]]
