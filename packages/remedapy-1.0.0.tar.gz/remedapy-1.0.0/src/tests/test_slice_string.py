import remedapy as R


class TestSliceString:
    def test_data_first(self):
        # R.slice_string(data, indexStart, indexEnd)
        assert R.slice_string('abcdefghijkl', 1) == 'bcdefghijkl'
        assert R.slice_string('abcdefghijkl', 4, 7) == 'efg'

    def test_data_last(self):
        # R.slice_string(indexStart, indexEnd)(string)
        assert R.slice_string(1)('abcdefghijkl') == 'bcdefghijkl'
        assert R.slice_string(4, 7)('abcdefghijkl') == 'efg'
