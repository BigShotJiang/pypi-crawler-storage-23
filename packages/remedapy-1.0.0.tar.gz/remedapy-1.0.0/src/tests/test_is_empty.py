import remedapy as R


class TestIsString:
    def test_data_first(self):
        # R.is_string(data);
        assert R.is_empty([])
        assert R.is_empty('')
        assert R.is_empty(())
        assert R.is_empty({})
        assert R.is_empty(set())
        assert not R.is_empty(range(10))
        assert not R.is_empty(0)
        assert not R.is_empty(x for x in range(10))

    def test_data_last(self):
        # R.is_string()(data);
        assert R.is_empty()([])
        assert not R.is_empty()(0)
