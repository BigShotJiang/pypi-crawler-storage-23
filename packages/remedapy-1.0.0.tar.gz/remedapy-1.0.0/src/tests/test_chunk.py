import remedapy as R


class TestChunk:
    def test_data_first(self):
        # R.chunk(array, size)
        assert list(R.chunk(['a', 'b', 'c', 'd'], 2)) == [['a', 'b'], ['c', 'd']]
        assert list(R.chunk(['a', 'b', 'c', 'd'], 3)) == [['a', 'b', 'c'], ['d']]

    def test_data_last(self):
        # R.chunk(size)(array)
        assert list(R.chunk(2)(['a', 'b', 'c', 'd'])) == [['a', 'b'], ['c', 'd']]
        assert list(R.chunk(3)(['a', 'b', 'c', 'd'])) == [['a', 'b', 'c'], ['d']]
