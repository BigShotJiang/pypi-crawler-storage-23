import remedapy as R


class TestLength:
    def test_data_first(self):
        # R.merge_all(objects);
        assert R.merge_all([{'a': 1, 'b': 1}, {'b': 2, 'c': 3}, {'d': 10}]) == {'a': 1, 'b': 2, 'c': 3, 'd': 10}
        assert R.merge_all([]) == {}

    def test_data_last(self):
        # R.merge_all()(objects)
        x: list[dict[str, int]] = []
        assert R.pipe([{'a': 1, 'b': 1}, {'b': 2, 'c': 3}, {'d': 10}], R.merge_all()) == {
            'a': 1,
            'b': 2,
            'c': 3,
            'd': 10,
        }
        assert R.pipe(x, R.merge_all()) == {}
