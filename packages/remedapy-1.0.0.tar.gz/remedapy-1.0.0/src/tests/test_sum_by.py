import remedapy as R


class TestSumBy:
    def test_data_first(self):
        # R.sum_by(array, fn)
        assert (
            R.sum_by(
                [{'a': 5}, {'a': 1}, {'a': 3}],
                R.prop('a'),  # pyright: ignore[reportArgumentType]
            )
            == 9
        )

    def test_data_last(self):
        # R.sum_by(fn)(array)
        assert (
            R.pipe(
                [{'a': 5}, {'a': 1}, {'a': 3}],
                R.sum_by(R.prop('a')),  # pyright: ignore[reportArgumentType]
            )
            == 9
        )
