import remedapy as R


class TestIndexBy:
    def test_data_first(self):
        # R.index_by(array, fn)
        assert R.index_by(['one', 'two', 'three'], R.length) == {3: 'two', 5: 'three'}

    def test_data_last(self):
        # R.index_by(fn)(array)
        assert R.pipe(['one', 'two', 'three'], R.index_by(R.length)) == {3: 'two', 5: 'three'}
