import remedapy as R


class TestMergeDeep:
    def test_data_first(self):
        # R.merge_deep(destination, source)
        assert R.merge_deep({'foo': 'bar', 'x': 1}, {'foo': 'baz', 'y': 2}) == {'foo': 'baz', 'x': 1, 'y': 2}
        assert R.merge_deep({'x': 1, 'y': {'a': 3}}, {'y': {'b': 3}, 'z': 2}) == {'x': 1, 'y': {'a': 3, 'b': 3}, 'z': 2}

    def test_data_last(self):
        # R.merge_deep(source)(destination)
        assert R.pipe(
            {'foo': 'bar', 'x': 1},
            R.merge_deep({'foo': 'baz', 'y': 2}),
        ) == {'foo': 'baz', 'x': 1, 'y': 2}
