import remedapy as R


class TestPathOr:
    def test_data_first(self):
        # R.path_or(object, array, defaultValue)
        assert R.path_or({'x': 10}, ['y'], 2) == 2
        assert R.path_or({'y': 10}, ['y'], 2) == 10
        assert R.path_or({'y': {'x': 10}}, ['y', 'x'], 2) == 10
        assert R.path_or({'y': {'x': 10}}, ['y', 'y'], 2) == 2

    def test_data_last(self):
        # R.path_or(array, defaultValue)(object)
        assert R.pipe({'x': 10}, R.path_or(['y'], 2)) == 2
        assert R.pipe({'y': 10}, R.path_or(['y'], 2)) == 10
