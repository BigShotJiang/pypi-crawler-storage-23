import remedapy as R


class TestOmit:
    def test_data_first(self):
        # R.omit(obj, keys);
        assert R.omit({'a': 1, 'b': 2, 'c': 3, 'd': 4}, ['a', 'd']) == {'b': 2, 'c': 3}

    def test_data_last(self):
        # R.omit(keys)(obj);
        assert R.pipe({'a': 1, 'b': 2, 'c': 3, 'd': 4}, R.omit(['a', 'd'])) == {'b': 2, 'c': 3}
