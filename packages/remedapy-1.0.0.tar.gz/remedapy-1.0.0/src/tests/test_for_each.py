import remedapy as R
from tests.util import Spy


class TestForEach:
    def test_data_first(self):
        # R.for_each(data, callbackfn)
        spy = Spy()
        x: list[int] = list(R.for_each([1, 2, 3], spy))
        assert x == [1, 2, 3]
        assert spy.calls == [(1,), (2,), (3,)]
        spy = Spy()
        list(R.for_each([1, 2, 3], spy.call_no_args))
        assert spy.calls == [(), (), ()]
        x = []
        result = list(R.for_each([1, 2, 3], lambda i: x.append(i * 10)))
        assert result == [1, 2, 3]
        assert x == [10, 20, 30]

    def test_data_last(self):
        # R.for_each(callbackfn)(data)
        spy = Spy()
        assert R.pipe([1, 2, 3], R.for_each(spy.call_one_int_arg), list) == [1, 2, 3]
        assert spy.calls == [(1,), (2,), (3,)]
