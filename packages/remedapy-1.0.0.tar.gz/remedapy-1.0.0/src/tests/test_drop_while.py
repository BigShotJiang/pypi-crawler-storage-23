import remedapy as R


class TestDropWhile:
    def test_data_first(self):
        # R.drop_while(data, predicate)
        assert list(R.drop_while([1, 2, 10, 3, 4], R.lt(10))) == [10, 3, 4]

    def test_data_last(self):
        # R.drop_while(predicate)(data)
        assert R.pipe([1, 2, 10, 3, 4], R.drop_while(R.lt(10)), list) == [10, 3, 4]
