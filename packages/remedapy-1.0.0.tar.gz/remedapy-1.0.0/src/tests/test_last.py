import remedapy as R


class TestLast:
    def test_data_first(self):
        # R.last(array)
        assert R.last([1, 2, 3]) == 3
        assert R.last([]) is None

    def test_data_last(self):
        # R.last()(array)
        def gt_3(x: int) -> bool:
            return x > 3

        assert R.pipe([1, 2, 4, 8, 16], R.filter(gt_3), R.last(), R.default_to(0), R.add(1)) == 17
