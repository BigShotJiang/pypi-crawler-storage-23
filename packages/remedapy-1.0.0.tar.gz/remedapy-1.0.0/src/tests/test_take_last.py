import remedapy as R


class TestTakeLast:
    def test_data_first(self):
        # R.take_last(array, n)
        assert R.take_last([1, 2, 3, 4, 5], 2) == [4, 5]
        assert R.take_last(range(10), 2) == [8, 9]

    def test_data_last(self):
        # R.take_last(n)(array)
        assert R.take_last(2)([1, 2, 3, 4, 5]) == [4, 5]
