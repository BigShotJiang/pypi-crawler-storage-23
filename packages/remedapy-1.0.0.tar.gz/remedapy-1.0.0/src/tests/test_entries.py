import remedapy as R


class TestEntries:
    def test_data_first(self):
        # R.entries(object)
        assert list(R.entries({'a': 1, 'b': 2, 'c': 3})) == [('a', 1), ('b', 2), ('c', 3)]

    def test_data_last(self):
        # R.entries()(object)
        assert R.pipe({'a': 1, 'b': 2, 'c': 3}, R.entries(), list) == [('a', 1), ('b', 2), ('c', 3)]
