import remedapy as R


class TestToTitleCase:
    def test_data_first(self):
        # R.to_title_case(data);
        # R.to_title_case(data, { preserve_consecutive_uppercase });
        assert R.to_title_case('hello world') == 'Hello World'
        assert R.to_title_case('--foo-bar--') == 'Foo Bar'
        assert R.to_title_case('fooBar') == 'Foo Bar'
        assert R.to_title_case('__FOO_BAR__') == 'Foo Bar'
        assert R.to_title_case('XMLHttpRequest') == 'XML Http Request'
        assert R.to_title_case('XMLHttpRequest', preserve_consecutive_uppercase=False) == 'Xml Http Request'

    def test_data_last(self):
        # R.to_title_case()(data);
        # R.to_title_case({ preserve_consecutive_uppercase })(data);
        assert R.pipe('hello world', R.to_title_case()) == 'Hello World'
        assert R.pipe('--foo-bar--', R.to_title_case()) == 'Foo Bar'
        assert R.pipe('fooBar', R.to_title_case()) == 'Foo Bar'
        assert R.pipe('__FOO_BAR__', R.to_title_case()) == 'Foo Bar'
        assert R.pipe('XMLHttpRequest', R.to_title_case()) == 'XML Http Request'
