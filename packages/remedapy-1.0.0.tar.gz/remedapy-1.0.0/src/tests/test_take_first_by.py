import remedapy as R


class TestTakeFirstBy:
    def test_data_first(self):
        # R.take_first_by(data, n, ...rules);
        assert list(R.take_first_by(['aa', 'aaaa', 'a', 'aaa'], 2, R.length)) == ['aa', 'a']
        assert list(R.take_first_by(['aa', 'aaaa', 'a', 'aaa'], 0, R.length)) == []

    def test_data_last(self):
        # R.take_first_by(n, ...rules)(data);
        assert list(R.pipe(['aa', 'aaaa', 'a', 'aaa'], R.take_first_by(2, R.length))) == ['aa', 'a']
