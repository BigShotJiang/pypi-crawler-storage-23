"""Litestar Application Factory.

This module provides the application factory for creating the Litestar
web application with all required configuration.

Features:
- CORS configuration for development
- Exception handlers for domain exceptions
- OpenAPI documentation (Swagger/ReDoc)
- Application lifecycle management
- Dependency injection container integration

Example:
    from framework_m_standard.adapters.web.app import create_app

    app = create_app()

    # Run with uvicorn
    # uvicorn framework_m_standard.adapters.web.app:create_app --factory
"""

# ruff: noqa: E402 - Module imports must come after dotenv loading

import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from importlib.resources import files
from pathlib import Path
from typing import Any

# Load environment variables from .env files (searches up the directory tree)
from dotenv import load_dotenv

# Search for .env file from current directory up to root
_cwd = Path.cwd()
for _parent in [_cwd, *_cwd.parents]:
    _env_file = _parent / ".env"
    if _env_file.exists():
        load_dotenv(_env_file)
        break

from framework_m_core.config import load_config
from framework_m_core.container import Container
from framework_m_core.exceptions import (
    DocTypeNotFoundError,
    DuplicateNameError,
    EntityNotFoundError,
    FrameworkError,
    PermissionDeniedError,
    ValidationError,
)
from litestar import Litestar, get
from litestar.config.cors import CORSConfig
from litestar.exceptions import NotFoundException
from litestar.openapi import OpenAPIConfig
from litestar.openapi.plugins import RedocRenderPlugin, SwaggerRenderPlugin
from litestar.openapi.spec import Components, SecurityScheme
from litestar.response import Redirect, Response
from litestar.static_files import StaticFilesConfig

from framework_m_standard.adapters.db.connection import ConnectionFactory
from framework_m_standard.adapters.db.session import SessionFactory
from framework_m_standard.adapters.web.auth_routes import auth_routes_router
from framework_m_standard.adapters.web.meta_router import create_meta_router
from framework_m_standard.adapters.web.metadata_router import metadata_router
from framework_m_standard.adapters.web.middleware import create_auth_middleware
from framework_m_standard.adapters.web.socket import create_websocket_router
from framework_m_standard.adapters.web.workflow_router import workflow_router

PREFERRED_FRONTEND_DIST_ENV = "FRAMEWORK_M_FRONTEND_DIST"

# =============================================================================
# Exception Handlers
# =============================================================================


def validation_error_handler(
    request: Any, exc: ValidationError
) -> Response[dict[str, Any]]:
    """Handle validation errors with 400 Bad Request.

    Args:
        request: The incoming request
        exc: The validation exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "ValidationError",
            "message": str(exc),
            "details": getattr(exc, "details", None),
        },
        status_code=400,
    )


def permission_denied_handler(
    request: Any, exc: PermissionDeniedError
) -> Response[dict[str, str]]:
    """Handle permission denied errors with 403 Forbidden.

    Args:
        request: The incoming request
        exc: The permission exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "PermissionDenied",
            "message": str(exc),
        },
        status_code=403,
    )


def not_found_handler(
    request: Any, exc: DocTypeNotFoundError | EntityNotFoundError
) -> Response[dict[str, str]]:
    """Handle not found errors with 404 Not Found.

    Args:
        request: The incoming request
        exc: The not found exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "NotFound",
            "message": str(exc),
        },
        status_code=404,
    )


def duplicate_name_handler(
    request: Any, exc: DuplicateNameError
) -> Response[dict[str, str]]:
    """Handle duplicate name errors with 409 Conflict.

    Args:
        request: The incoming request
        exc: The duplicate name exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "Conflict",
            "message": str(exc),
            "doctype": exc.doctype_name,
            "name": exc.name,
        },
        status_code=409,
    )


def framework_error_handler(
    request: Any, exc: FrameworkError
) -> Response[dict[str, str]]:
    """Handle generic framework errors with 500 Internal Server Error.

    Args:
        request: The incoming request
        exc: The framework exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "InternalError",
            "message": str(exc),
        },
        status_code=500,
    )


def litestar_not_found_handler(
    request: Any, exc: NotFoundException
) -> Response[dict[str, Any]]:
    """Handle framework-level 404 errors without noisy uncaught tracebacks.

    This is used for unmatched routes (e.g. `/desk/` in API-only dev mode).
    """
    detail = getattr(exc, "detail", None) or "Not Found"
    return Response(
        content={
            "status_code": 404,
            "detail": str(detail),
        },
        status_code=404,
    )


# =============================================================================
# Route Handlers
# =============================================================================


@get("/health", sync_to_thread=False)
def health_check() -> dict[str, str]:
    """Health check endpoint.

    Returns basic health status for load balancers and monitoring.

    Returns:
        Dict with status information
    """
    return {"status": "healthy"}


@get("/", sync_to_thread=False, include_in_schema=False)
def root_redirect() -> Redirect:
    """Redirect root to /desk/.

    This ensures the Desk UI is accessed at a dedicated path,
    avoiding conflicts with API routes.

    Returns:
        Redirect response to /desk/
    """
    return Redirect(path="/desk/")


@get(["desk", "/desk/"], sync_to_thread=False, include_in_schema=False)
def serve_desk_root() -> Response[bytes]:
    """Serve bundled Desk UI index.html at /desk/.

    This is the entry point for the Desk UI.

    Returns:
        HTML response with Desk UI or 404 error
    """
    return _get_desk_html_response()


@get("/favicon.ico", sync_to_thread=False, include_in_schema=False)
def serve_favicon() -> Response[bytes]:
    """Serve favicon when available, otherwise return a clean 404 response."""
    return _get_favicon_response()


@get("/desk/{path:path}", sync_to_thread=False, include_in_schema=False)
def serve_desk_spa(path: str) -> Response[bytes]:
    """Serve Desk SPA with client-side routing support.

    This catchall route ensures that React Router paths like /desk/doctypes/User
    work correctly when the user refreshes or enters the URL directly.

    Static asset requests (paths with file extensions like .js, .css, .ico)
    are NOT handled here — they are served by StaticFilesConfig instead.

    Args:
        path: The requested path within /desk/

    Returns:
        HTML response with Desk UI index.html, or 404 for static asset paths
    """
    # If the path looks like a static file (has a file extension),
    # don't serve index.html — let StaticFilesConfig handle it.
    # This prevents returning text/html for .js/.css requests.
    last_segment = path.rsplit("/", 1)[-1]
    if "." in last_segment:
        # This is a static file request (e.g., assets/index-xxx.js)
        preferred_dist = _get_preferred_frontend_dist_path()
        if preferred_dist:
            preferred_file = preferred_dist / path
            if preferred_file.exists() and preferred_file.is_file():
                import mimetypes

                content_type = (
                    mimetypes.guess_type(str(preferred_file))[0]
                    or "application/octet-stream"
                )
                return Response(
                    content=preferred_file.read_bytes(),
                    media_type=content_type,
                )

        # Try to serve the actual file from bundled static
        static_path = _get_bundled_static_path()
        if static_path:
            file_path = static_path / path
            if file_path.exists() and file_path.is_file():
                import mimetypes

                content_type = (
                    mimetypes.guess_type(str(file_path))[0]
                    or "application/octet-stream"
                )
                return Response(
                    content=file_path.read_bytes(),
                    media_type=content_type,
                )

        # Fallback to local dev directories
        local_dirs = [
            Path.cwd() / "frontend" / "dist" / path,
            Path.cwd() / "dist" / path,
        ]
        for local_file in local_dirs:
            if local_file.exists() and local_file.is_file():
                import mimetypes

                content_type = (
                    mimetypes.guess_type(str(local_file))[0]
                    or "application/octet-stream"
                )
                return Response(
                    content=local_file.read_bytes(),
                    media_type=content_type,
                )

        return Response(content=b"Not Found", status_code=404)

    # For navigation routes (no file extension), serve index.html
    # The React app will handle the actual routing
    return _get_desk_html_response()


def _get_desk_html_response() -> Response[bytes]:
    """Get the Desk UI HTML response.

    Helper function to serve index.html from bundled static or local dev.

    Returns:
        HTML response with Desk UI or 404 error
    """
    preferred_dist = _get_preferred_frontend_dist_path()
    if preferred_dist:
        preferred_index = preferred_dist / "index.html"
        if preferred_index.exists():
            html = _rewrite_root_asset_urls_for_desk(preferred_index.read_bytes())
            return Response(
                content=html,
                media_type="text/html",
            )

    static_path = _get_bundled_static_path()
    if static_path:
        index_file = static_path / "index.html"
        if index_file.exists():
            html = _rewrite_root_asset_urls_for_desk(index_file.read_bytes())
            return Response(
                content=html,
                media_type="text/html",
            )

    # Fallback to local development
    local_dirs = [
        Path.cwd() / "frontend" / "dist" / "index.html",
        Path.cwd() / "dist" / "index.html",
    ]
    for index_file in local_dirs:
        if index_file.exists():
            html = _rewrite_root_asset_urls_for_desk(index_file.read_bytes())
            return Response(
                content=html,
                media_type="text/html",
            )

    return Response(
        content=b"Desk UI not available. Run 'pnpm build' in frontend/ or install framework-m with bundled UI.",
        status_code=404,
    )


def _rewrite_root_asset_urls_for_desk(html_content: bytes) -> bytes:
    """Rewrite root asset URLs to /desk/* for SPA static serving.

    Some built bundles may emit absolute root asset paths like `/index-*.js`.
    Since Desk is served under `/desk/`, rewrite these to `/desk/index-*.js`.
    """
    import re

    try:
        html = html_content.decode("utf-8")
    except UnicodeDecodeError:
        return html_content

    # 1) Absolute root paths: /index-xxx.js -> /desk/index-xxx.js
    rewritten = re.sub(
        r'(src|href)="/(?!desk/|/)([^"]+)"',
        r'\1="/desk/\2"',
        html,
    )

    # 2) Relative asset paths from index.html: index-xxx.js or ./index-xxx.js
    #    served from /desk should resolve to /desk/index-xxx.js (not /index-xxx.js).
    rewritten = re.sub(
        r'(src|href)="(?:\./)?(?!https?:|data:|/|#)([^"]+)"',
        r'\1="/desk/\2"',
        rewritten,
    )
    return rewritten.encode("utf-8")


def _get_favicon_response() -> Response[bytes]:
    """Get favicon response from preferred, bundled, or local dist paths."""
    search_paths: list[Path] = []

    preferred_dist = _get_preferred_frontend_dist_path()
    if preferred_dist:
        search_paths.append(preferred_dist / "favicon.ico")

    bundled = _get_bundled_static_path()
    if bundled:
        search_paths.append(bundled / "favicon.ico")

    search_paths.extend(
        [
            Path.cwd() / "frontend" / "dist" / "favicon.ico",
            Path.cwd() / "dist" / "favicon.ico",
        ]
    )

    for favicon in search_paths:
        if favicon.exists() and favicon.is_file():
            return Response(content=favicon.read_bytes(), media_type="image/x-icon")

    return Response(content=b"Not Found", status_code=404)


def _parse_local_project_package_name(cwd: Path) -> str | None:
    pyproject = cwd / "pyproject.toml"
    if not pyproject.exists():
        return None

    try:
        import tomllib

        toml_loads = tomllib.loads
    except ModuleNotFoundError:
        import tomli  # type: ignore[import-not-found]

        toml_loads = tomli.loads

    try:
        data = toml_loads(pyproject.read_text(encoding="utf-8"))
        name = data.get("project", {}).get("name")
    except Exception:
        return None

    if isinstance(name, str) and name.strip():
        return name.strip().replace("-", "_")
    return None


def _collect_local_doctype_candidates(cwd: Path) -> list[str]:
    candidates: list[str] = []

    project_package = _parse_local_project_package_name(cwd)
    if project_package:
        candidates.append(f"{project_package}.doctypes")

    src_dir = cwd / "src"
    if not src_dir.exists():
        return candidates

    for package_dir in src_dir.iterdir():
        if (
            package_dir.is_dir()
            and (package_dir / "__init__.py").exists()
            and (package_dir / "doctypes").is_dir()
        ):
            candidates.append(f"{package_dir.name}.doctypes")

    if (src_dir / "doctypes").is_dir():
        candidates.append("doctypes")

    return candidates


def _unique_preserve_order(items: list[str]) -> list[str]:
    seen: set[str] = set()
    unique_items: list[str] = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        unique_items.append(item)
    return unique_items


def _discover_local_project_doctypes(registry: Any) -> int:
    """Discover DocTypes from the current project source tree.

    This supports local app development where the project itself might not be
    installed as a package entry point yet.
    """

    unique_candidates = _unique_preserve_order(
        _collect_local_doctype_candidates(Path.cwd())
    )

    total = 0
    for package_name in unique_candidates:
        count = registry.discover_doctypes(package_name)
        if count > 0:
            print(
                f"Discovered {count} DocType(s) from local project package '{package_name}'"
            )
            total += count

    return total


# =============================================================================
# Application Lifecycle
# =============================================================================


@asynccontextmanager
async def app_lifespan(app: Litestar) -> AsyncGenerator[None, None]:
    """Application lifespan context manager.

    Handles startup and shutdown tasks:
    - Startup: Initialize container, database connections, discover DocTypes
    - Shutdown: Close database connections, cleanup resources

    Args:
        app: The Litestar application instance

    Yields:
        None during the application's running state
    """
    # ==========================================================================
    # Startup
    # ==========================================================================
    container = Container()
    connection_factory = ConnectionFactory()
    session_factory = SessionFactory()

    # Configure database if DATABASE_URL is set
    database_url = os.environ.get("DATABASE_URL")
    if database_url:
        connection_factory.configure({"default": database_url})
        session_factory.configure(connection_factory)

        # Create tables for all registered DocTypes
        from framework_m_core.registry import MetaRegistry
        from sqlalchemy import MetaData

        from framework_m_standard.adapters.db.repository_factory import (
            RepositoryFactory,
        )
        from framework_m_standard.adapters.db.schema_mapper import SchemaMapper

        registry = MetaRegistry.get_instance()
        metadata = MetaData()
        schema_mapper = SchemaMapper()

        # Create table definitions for each registered DocType
        for doctype_name in registry.list_doctypes():
            try:
                doctype_class = registry.get_doctype(doctype_name)
                if doctype_class is not None and doctype_class.get_api_resource():
                    schema_mapper.create_tables(doctype_class, metadata)
            except Exception:
                pass  # Skip doctype if it fails

        # Create all tables in the database
        engine = connection_factory.get_engine("default")
        async with engine.begin() as conn:
            await conn.run_sync(metadata.create_all)

        # Create RepositoryFactory with metadata and session_factory
        repo_factory = RepositoryFactory(metadata, session_factory)
        app.state.repository_factory = repo_factory
    else:
        app.state.repository_factory = None

    # Store container in app state for access in routes
    app.state.container = container

    # Note: DocTypes are registered in create_app() before route creation

    yield

    # ==========================================================================
    # Shutdown
    # ==========================================================================
    # Close database connections
    if database_url:
        await connection_factory.dispose_all()


# =============================================================================
# Application Factory
# =============================================================================


def create_app(serve_static: bool | None = None) -> Litestar:
    """Create and configure the Litestar application.

    This factory function creates a fully configured Litestar app with:
    - CORS configured for development (allows all origins)
    - Exception handlers for domain exceptions
    - OpenAPI documentation with Swagger UI
    - Health check endpoint
    - Application lifecycle management
    - Conditional UI serving (production vs development mode)

    Args:
        serve_static: Whether to serve bundled static UI files.
            - True: Serve UI + API (production mode)
            - False: Serve API only (development mode, Vite serves UI separately)
            - None (default): Auto-detect from M_DEV_MODE env var
                - M_DEV_MODE=true → serve_static=False
                - Otherwise → serve_static=True

    Returns:
        Configured Litestar application instance

    Example:
        # Production mode (serves bundled static files + API)
        app = create_app(serve_static=True)

        # Development mode (API only, Vite dev server serves UI)
        app = create_app(serve_static=False)

        # Auto-detect from environment
        # M_DEV_MODE=true → API only
        # M_DEV_MODE not set → Serve static + API
        app = create_app()
    """
    import os

    # Auto-detect dev mode from environment if serve_static not explicitly set
    if serve_static is None:
        dev_mode = os.environ.get("M_DEV_MODE", "").lower() == "true"
        serve_static = not dev_mode
    # CORS Configuration (development defaults)
    cors_config = CORSConfig(
        allow_origins=["*"],  # TODO: Configure from environment for production
        allow_methods=["*"],
        allow_headers=["*"],
        allow_credentials=True,
    )

    # OpenAPI Configuration
    openapi_config = OpenAPIConfig(
        title="Framework M API",
        version="0.2.0",
        description="A modern, metadata-driven business application framework",
        path="/schema",
        render_plugins=[
            SwaggerRenderPlugin(),
            RedocRenderPlugin(),
        ],
        # Security scheme for header-based authentication
        components=Components(
            security_schemes={
                "HeaderAuth": SecurityScheme(
                    type="apiKey",
                    name="x-user-id",
                    security_scheme_in="header",
                    description="User ID for authentication. Required for protected endpoints.",
                ),
                "RolesHeader": SecurityScheme(
                    type="apiKey",
                    name="x-roles",
                    security_scheme_in="header",
                    description="Comma-separated list of roles (e.g., 'Manager,Employee').",
                ),
            },
        ),
    )

    # Exception Handlers - type: ignore needed for union return types
    exception_handlers = {
        ValidationError: validation_error_handler,
        PermissionDeniedError: permission_denied_handler,
        DocTypeNotFoundError: not_found_handler,
        EntityNotFoundError: not_found_handler,
        NotFoundException: litestar_not_found_handler,
        DuplicateNameError: duplicate_name_handler,
        FrameworkError: framework_error_handler,
    }

    # Static Files Configuration (only in production mode)
    static_files_config = _create_static_files_config() if serve_static else []

    # Auto-discover DocTypes from installed apps via entry points
    from importlib.metadata import entry_points

    from framework_m_core.registry import MetaRegistry

    registry = MetaRegistry.get_instance()

    # First, discover framework's core DocTypes
    core_count = registry.discover_doctypes("framework_m_core.doctypes")
    if core_count > 0:
        print(f"Discovered {core_count} core DocType(s) from framework")

    # Then discover DocTypes from all installed apps registered via entry points
    eps = entry_points(group="framework_m.apps")
    for ep in eps:
        try:
            # Load the app module (returns the app dict with metadata)
            ep.load()

            # Get the module path (e.g., "my_app" from "my_app:app")
            module_path = ep.module.split(":")[0]

            # Try namespaced structure first: <app_name>.doctypes
            doctypes_package = f"{module_path}.doctypes"
            count = registry.discover_doctypes(doctypes_package)

            if count == 0:
                # Fallback: scan the entire module (legacy flat structure)
                count = registry.discover_doctypes(module_path)

            if count > 0:
                print(f"Discovered {count} DocType(s) from app '{ep.name}'")
        except Exception as e:
            # Log but don't fail startup if an app fails to load
            print(f"Warning: Failed to load app '{ep.name}': {e}")

    # Finally, discover local project DocTypes (for non-installed app development)
    _discover_local_project_doctypes(registry)

    # Build route handlers list
    route_handlers: list[Any] = [
        health_check,
        serve_favicon,
        auth_routes_router,
        metadata_router,  # Metadata API including doctype listing for menus
        workflow_router,
    ]

    # Add UI routes only in production mode (when serving static files)
    if serve_static:
        route_handlers.extend(
            [
                root_redirect,  # Redirect / to /desk/
                serve_desk_root,  # Serve Desk UI at /desk/
                serve_desk_spa,  # Catchall for Desk SPA routing
            ]
        )

    # Add auto-CRUD routes for DocTypes with api_resource=True
    try:
        crud_router = create_meta_router()
        route_handlers.append(crud_router)
    except Exception:
        # No DocTypes registered yet, skip CRUD routes
        pass

    # Add WebSocket router for real-time streaming
    websocket_router = create_websocket_router()
    route_handlers.append(websocket_router)

    # Create and return app
    app = Litestar(
        route_handlers=route_handlers,
        middleware=[
            create_auth_middleware(
                require_auth=False,  # Don't require auth by default (for development)
                excluded_paths=["/health", "/schema", "/api/meta"],
            ),
        ],
        cors_config=cors_config,
        openapi_config=openapi_config,
        exception_handlers=exception_handlers,  # type: ignore[arg-type]
        lifespan=[app_lifespan],
        static_files_config=static_files_config,
        debug=True,  # TODO: Configure from environment
    )

    return app


def _get_bundled_static_path() -> Path | None:
    """Get path to bundled Desk static files from package.

    Checks if framework-m package includes bundled static files
    (pre-built Desk UI from CI pipeline).

    Returns:
        Path to bundled static directory, or None if not available
    """
    try:
        # Try to get bundled static files from framework_m package
        static_dir = files("framework_m") / "static"

        # For editable installs, static_dir might be a Traversable
        # Convert to Path and verify it exists
        if hasattr(static_dir, "__fspath__"):
            # It's already path-like, convert to string first for Path constructor
            static_path = Path(str(static_dir))
        else:
            # It's a Traversable, need to resolve it
            # Try to get the actual filesystem path
            try:
                # For Traversable objects in editable installs
                static_path = Path(str(static_dir))
            except Exception:
                # If that fails, try as_file context manager
                import contextlib
                from importlib.resources import as_file

                with contextlib.suppress(Exception), as_file(static_dir) as path:
                    static_path = path
                    if static_path.exists() and static_path.is_dir():
                        # Return a persistent copy since we're exiting the context
                        return Path(str(static_path))
                return None

        # Verify the path exists and is a directory
        if static_path.exists() and static_path.is_dir():
            # Also verify it has the expected structure
            assets_dir = static_path / "assets"
            index_file = static_path / "index.html"
            if assets_dir.exists() or index_file.exists():
                return static_path
    except Exception as e:
        # Log the error for debugging but don't crash
        import sys

        print(f"Warning: Could not locate bundled static files: {e}", file=sys.stderr)

    return None


def _get_preferred_frontend_dist_path() -> Path | None:
    """Get explicitly requested frontend dist path from environment."""
    raw_path = os.environ.get(PREFERRED_FRONTEND_DIST_ENV)
    if not raw_path:
        return None

    path = Path(raw_path)
    if path.exists() and path.is_dir():
        return path

    return None


def _create_static_files_config() -> list[StaticFilesConfig]:
    """Create static files configuration.

    Serves static assets (JS/CSS/images) at /desk/assets/* to avoid conflicts
    with API routes. HTML is served via route handlers for SPA routing support.

    Priority order:
    1. Explicit frontend dist from environment (custom app build)
    2. Bundled static files from framework-m package (pre-built Desk)
    3. Workspace frontend/dist (for monorepo development)
    4. Local development static directories (frontend/dist, dist/, etc.)

    Returns:
        List of StaticFilesConfig instances
    """
    import sys
    from pathlib import Path

    configs: list[StaticFilesConfig] = []

    # Prefer explicit frontend dist path when provided by runtime
    preferred_dist = _get_preferred_frontend_dist_path()
    if preferred_dist:
        preferred_assets_dir = preferred_dist / "assets"
        if preferred_assets_dir.exists():
            print(
                f"[Desk] Using preferred frontend dist from: {preferred_dist}",
                file=sys.stderr,
            )
            configs.append(
                StaticFilesConfig(
                    path="/desk/assets",
                    directories=[preferred_assets_dir],
                    html_mode=False,
                )
            )
            return configs

    # Check for bundled static files first (from PyPI package)
    bundled_path = _get_bundled_static_path()
    if bundled_path:
        print(
            f"[Desk] Using bundled static files from: {bundled_path}", file=sys.stderr
        )
        # Serve static assets (JS/CSS/images) at /desk/assets/*
        # DO NOT use html_mode=True here - HTML is handled by route handlers
        assets_dir = bundled_path / "assets"
        if assets_dir.exists():
            configs.append(
                StaticFilesConfig(
                    path="/desk/assets",
                    directories=[assets_dir],
                    html_mode=False,
                )
            )
            return configs
        else:
            print(
                f"[Desk] Warning: Bundled static path found but no assets/ directory at {assets_dir}",
                file=sys.stderr,
            )

    # Try to find workspace frontend/dist (for monorepo development)
    workspace_frontend_paths = [
        # If running from workspace root
        Path.cwd() / "frontend" / "dist",
        # If running from libs/*/
        Path.cwd() / ".." / ".." / "frontend" / "dist",
        # If running from apps/*/
        Path.cwd() / ".." / ".." / "frontend" / "dist",
    ]

    for frontend_path in workspace_frontend_paths:
        if frontend_path.exists() and frontend_path.is_dir():
            assets_dir = frontend_path / "assets"
            if assets_dir.exists():
                print(
                    f"[Desk] Using workspace frontend from: {frontend_path}",
                    file=sys.stderr,
                )
                configs.append(
                    StaticFilesConfig(
                        path="/desk/assets",
                        directories=[assets_dir],
                        html_mode=False,
                    )
                )
                return configs

    # Fallback to local development directories (current working directory)
    static_dirs = [
        Path.cwd() / "frontend" / "dist",
        Path.cwd() / "dist",
        Path.cwd() / "static" / "dist",
    ]

    # Find first existing directory
    static_path: Path | None = None
    for d in static_dirs:
        if d.exists() and d.is_dir():
            static_path = d
            break

    if static_path is None:
        # No static files found
        print(
            "[Desk] Warning: No static files found. Desk UI will not be available.",
            file=sys.stderr,
        )
        print(
            "[Desk] Run 'pnpm build' in frontend/ directory or install framework-m with bundled UI.",
            file=sys.stderr,
        )
        fallback_assets = Path.cwd() / ".m" / "empty-assets"
        fallback_assets.mkdir(parents=True, exist_ok=True)
        print(
            f"[Desk] Using empty static fallback directory: {fallback_assets}",
            file=sys.stderr,
        )
        return [
            StaticFilesConfig(
                path="/desk/assets",
                directories=[fallback_assets],
                html_mode=False,
            )
        ]

    # Serve local development static assets at /desk/assets/*
    assets_dir = static_path / "assets"
    if assets_dir.exists():
        print(f"[Desk] Using local static files from: {static_path}", file=sys.stderr)
        configs.append(
            StaticFilesConfig(
                path="/desk/assets",
                directories=[assets_dir],
                html_mode=False,
            )
        )

    return configs


def get_asset_url(asset_path: str) -> str:
    """Get the URL for a static asset.

    If CDN is configured, returns CDN URL. Otherwise returns local URL.
    This function can be used in templates to generate asset URLs.

    Args:
        asset_path: Path to the asset (e.g., 'js/main.js')

    Returns:
        Full URL to the asset

    Example:
        >>> get_asset_url('js/main.js')
        'https://cdn.example.com/assets/js/main.js'  # if CDN configured
        '/assets/js/main.js'  # if no CDN
    """
    config = load_config()
    frontend_config = config.get("frontend", {})
    cdn_url = frontend_config.get("cdn_url")

    if cdn_url:
        # Ensure trailing slash
        if not cdn_url.endswith("/"):
            cdn_url += "/"
        return f"{cdn_url}{asset_path.lstrip('/')}"

    return f"/assets/{asset_path.lstrip('/')}"


__all__ = ["create_app"]
