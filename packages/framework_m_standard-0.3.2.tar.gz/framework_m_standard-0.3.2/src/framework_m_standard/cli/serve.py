"""Production CLI Command - m prod (backend + static UI).

This module provides the production server command for Framework M.

Behavior:
- Indie mode: serve bundled or local dist static assets via the Python app
- Enterprise mode: serve API only (static assets should be served by nginx)

Usage:
    m prod                      # Production server
    m prod --port 8080           # Custom port
    m prod --reload              # Auto-reload (not recommended for prod)
    m prod --with-frontend       # Prefer prebuilt frontend/dist static UI
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Annotated

import cyclopts
from framework_m_core.config import get_nested_value, load_config

VALID_DEPLOYMENT_MODES = {"indie", "enterprise"}


def _get_deployment_mode() -> str:
    """Get deployment mode from configuration.

    Reads, in order:
    1. deployment.mode
    2. frontend.mode

    Returns:
        Normalized deployment mode (default: "indie")
    """
    config = load_config()
    mode = get_nested_value(config, "deployment.mode") or get_nested_value(
        config, "frontend.mode"
    )
    if isinstance(mode, str) and mode.strip():
        return mode.strip().lower()
    return "indie"


def _start_backend_only(port: int, reload: bool, host: str, app: str | None) -> None:
    """Start backend serving bundled static Desk.

    Delegates to framework-m-standard's start command.

    Args:
        port: Port to bind to
        reload: Enable auto-reload
        host: Host to bind to
        app: Explicit app path

    Example:
        >>> _start_backend_only(8000, False, "0.0.0.0", None)
        # Starts uvicorn on port 8000
    """
    from framework_m_standard.cli.start import start_command as std_start

    std_start(app=app, host=host, port=port, reload=reload)


def _get_prebuilt_frontend_dist(frontend_dir: Path) -> Path | None:
    """Get prebuilt frontend dist directory if available."""
    dist_dir = frontend_dir / "dist"
    if not dist_dir.exists() or not dist_dir.is_dir():
        return None

    if (dist_dir / "index.html").exists():
        return dist_dir

    return None


def _resolve_prebuilt_frontend_dist(
    frontend_dir: Path,
) -> tuple[Path | None, list[Path]]:
    """Resolve prebuilt dist path from frontend directory candidates.

    For relative `frontend_dir`, this searches from cwd and each parent directory.
    This supports invoking `m prod --with-frontend` from subdirectories while still
    finding the repository-level `frontend/dist` output.
    """
    candidates: list[Path] = []

    if frontend_dir.is_absolute():
        candidates.append(frontend_dir)
    else:
        for base in [Path.cwd(), *Path.cwd().parents]:
            candidates.append((base / frontend_dir).resolve())

    unique_candidates: list[Path] = []
    seen: set[Path] = set()
    for candidate in candidates:
        if candidate in seen:
            continue
        seen.add(candidate)
        unique_candidates.append(candidate)

    for candidate in unique_candidates:
        dist_dir = _get_prebuilt_frontend_dist(candidate)
        if dist_dir:
            return dist_dir, unique_candidates

    return None, unique_candidates


def _start_with_frontend(
    port: int,
    reload: bool,
    host: str,
    app: str | None,
    frontend_dir: Path,
) -> None:
    """Start backend with prebuilt custom frontend if present.

    This command does not build assets. It only prefers already-built
    `frontend/dist` via environment override.
    """
    dist_dir, searched_candidates = _resolve_prebuilt_frontend_dist(frontend_dir)
    if dist_dir:
        print(f"Using prebuilt frontend dist: {dist_dir}")
    else:
        searched = ", ".join(str(path / "dist") for path in searched_candidates[:3])
        if len(searched_candidates) > 3:
            searched += ", ..."
        print(f"No prebuilt frontend dist found. Searched: {searched}")
        print("Falling back to bundled/workspace static resolution.")

    print("Starting backend with static serving from prebuilt/bundled/local dist")
    previous_dist = os.environ.get("FRAMEWORK_M_FRONTEND_DIST")
    previous_dev_mode = os.environ.get("M_DEV_MODE")
    if dist_dir:
        os.environ["FRAMEWORK_M_FRONTEND_DIST"] = str(dist_dir)
    else:
        os.environ.pop("FRAMEWORK_M_FRONTEND_DIST", None)
    os.environ["M_DEV_MODE"] = "false"
    try:
        _start_backend_only(port=port, reload=reload, host=host, app=app)
    finally:
        if previous_dist is None:
            os.environ.pop("FRAMEWORK_M_FRONTEND_DIST", None)
        else:
            os.environ["FRAMEWORK_M_FRONTEND_DIST"] = previous_dist
        if previous_dev_mode is None:
            os.environ.pop("M_DEV_MODE", None)
        else:
            os.environ["M_DEV_MODE"] = previous_dev_mode


def prod_command(
    port: Annotated[
        int,
        cyclopts.Parameter(name="--port", help="Backend port (default: 8000)"),
    ] = 8000,
    reload: Annotated[
        bool,
        cyclopts.Parameter(name="--reload", help="Enable backend auto-reload"),
    ] = False,
    host: Annotated[
        str,
        cyclopts.Parameter(name="--host", help="Host to bind to (default: 0.0.0.0)"),
    ] = "0.0.0.0",
    with_frontend: Annotated[
        bool,
        cyclopts.Parameter(
            name="--with-frontend",
            help="Prefer prebuilt frontend/dist static UI via backend (no build)",
        ),
    ] = False,
    app: Annotated[
        str | None,
        cyclopts.Parameter(name="--app", help="App path (module:attribute format)"),
    ] = None,
    frontend_dir: Annotated[
        Path,
        cyclopts.Parameter(
            name="--frontend-dir",
            help="Frontend directory path (default: ./frontend)",
        ),
    ] = Path("frontend"),
) -> None:
    """Start Framework M in production mode.

    Indie mode serves bundled or local dist static assets via Python.
    Enterprise mode serves API only; static assets should be served by nginx.

    Examples:
        m prod                     # Production server
        m prod --port 3000          # Custom port
        m prod --reload             # Auto-reload (development only)
        m prod --with-frontend      # Use prebuilt custom frontend/dist if present
    """
    if with_frontend:
        _start_with_frontend(
            port=port,
            reload=reload,
            host=host,
            app=app,
            frontend_dir=frontend_dir,
        )
        return

    mode = _get_deployment_mode()
    if mode not in VALID_DEPLOYMENT_MODES:
        print(f"Warning: Unknown deployment mode '{mode}', defaulting to 'indie'.")
        mode = "indie"

    previous_dev_mode = os.environ.get("M_DEV_MODE")
    os.environ["M_DEV_MODE"] = "true" if mode == "enterprise" else "false"

    print(f"Deployment mode: {mode}")
    if mode == "enterprise":
        print("Static assets will NOT be served by the backend.")
        print("Use nginx (or CDN) to serve your built dist directory.")
    else:
        print("Serving Desk UI from bundled wheel or local dist directory.")

    try:
        _start_backend_only(
            port=port,
            reload=reload,
            host=host,
            app=app,
        )
    finally:
        if previous_dev_mode is None:
            os.environ.pop("M_DEV_MODE", None)
        else:
            os.environ["M_DEV_MODE"] = previous_dev_mode


__all__ = [
    "prod_command",
    "_get_prebuilt_frontend_dist",
    "_resolve_prebuilt_frontend_dist",
    "_get_deployment_mode",
    "_start_backend_only",
    "_start_with_frontend",
]
