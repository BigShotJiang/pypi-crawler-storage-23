"""Uvicorn Relay - Internal server helper.

This module provides a small uvicorn wrapper used by production
and development commands. It is not a public CLI command.

Usage:
    m prod                          # Production server
    m dev                           # Development server
"""

from __future__ import annotations

import ast
import os
import subprocess
import sys
from pathlib import Path
from typing import Annotated

import cyclopts

# Default app path - Framework M standard app with Desk UI
DEFAULT_APP_PATH = "framework_m_standard.adapters.web.app:create_app"

# Common app patterns to search for (project-specific apps first)
APP_PATTERNS = [
    "app:app",
    "app.main:app",
    "main:app",
    "src.app:app",
    "src.app.main:app",
]


def _display_host(host: str) -> str:
    """Return browser-friendly host for user-facing URLs."""
    return "localhost" if host in {"0.0.0.0", "::"} else host


def find_app(explicit_app: str | None = None) -> str:
    """Find the Litestar app to run.

    Strategy:
    1. Use explicit --app if provided
    2. Check common project-specific locations (app.py, main.py, etc.)
    3. Fall back to Framework M standard app with Desk UI

    Args:
        explicit_app: Explicit app path if provided

    Returns:
        App path in module:attribute format

    Example:
        >>> find_app("myapp.main:app")
        'myapp.main:app'
        >>> find_app(None)  # Falls back to Framework M standard
        'framework_m_standard.adapters.web.app:create_app'
    """
    if explicit_app:
        return explicit_app

    def detect_asgi_symbol(module_file: Path) -> str | None:
        """Detect ASGI entry symbol in a Python module.

        Returns:
            "app" if a top-level app variable is defined,
            "create_app" if a top-level create_app function is defined,
            otherwise None.
        """
        try:
            source = module_file.read_text(encoding="utf-8")
            tree = ast.parse(source)
        except (OSError, SyntaxError, UnicodeDecodeError):
            return None

        has_create_app = False

        for node in tree.body:
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "app":
                        return "app"
            elif isinstance(node, ast.AnnAssign):
                if isinstance(node.target, ast.Name) and node.target.id == "app":
                    return "app"
            elif (
                isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                and node.name == "create_app"
            ):
                has_create_app = True

        if has_create_app:
            return "create_app"

        return None

    # Try to find app in common project-specific locations
    cwd = Path.cwd()

    candidates: list[tuple[Path, str]] = [
        (cwd / "app.py", "app"),
        (cwd / "app" / "__init__.py", "app"),
        (cwd / "src" / "app" / "__init__.py", "src.app"),
        (cwd / "main.py", "main"),
    ]

    for module_file, module_name in candidates:
        if module_file.exists():
            symbol = detect_asgi_symbol(module_file)
            if symbol:
                return f"{module_name}:{symbol}"

    # Fall back to Framework M standard app with bundled Desk UI
    # This provides "just works" experience for third-party developers
    return DEFAULT_APP_PATH


def get_pythonpath() -> str:
    """Get PYTHONPATH with src/ directory included.

    Returns:
        PYTHONPATH string with src/ prepended

    Example:
        >>> os.environ["PYTHONPATH"] = "/existing"
        >>> get_pythonpath()
        'src:/existing'
    """
    cwd = Path.cwd()
    src_path = cwd / "src"

    paths = []

    # Add src/ if it exists
    if src_path.exists():
        paths.append(str(src_path))

    # Add current directory
    paths.append(str(cwd))

    # Preserve existing PYTHONPATH
    existing = os.environ.get("PYTHONPATH", "")
    if existing:
        paths.append(existing)

    return os.pathsep.join(paths)


def build_uvicorn_command(
    app: str,
    host: str = "0.0.0.0",
    port: int = 8000,
    reload: bool = False,
    workers: int | None = None,
    log_level: str | None = None,
    extra_args: tuple[str, ...] = (),
) -> list[str]:
    """Build the uvicorn command line.

    Args:
        app: App path in module:attribute format
        host: Host to bind to
        port: Port to bind to
        reload: Enable auto-reload
        workers: Number of workers
        log_level: Log level (debug, info, warning, error)
        extra_args: Additional arguments to pass to uvicorn

    Returns:
        Complete command as list of strings
    """
    cmd = [sys.executable, "-m", "uvicorn", app]

    cmd.extend(["--host", host])
    cmd.extend(["--port", str(port)])

    if reload:
        cmd.append("--reload")

    if workers is not None and workers > 1:
        cmd.extend(["--workers", str(workers)])

    if log_level:
        cmd.extend(["--log-level", log_level])

    # Add any extra arguments
    cmd.extend(extra_args)

    return cmd


def start_command(
    app: Annotated[
        str | None,
        cyclopts.Parameter(name="--app", help="App path (module:attribute format)"),
    ] = None,
    host: Annotated[
        str,
        cyclopts.Parameter(name="--host", help="Host to bind to"),
    ] = "0.0.0.0",
    port: Annotated[
        int,
        cyclopts.Parameter(name="--port", help="Port to bind to"),
    ] = 8000,
    reload: Annotated[
        bool,
        cyclopts.Parameter(name="--reload", help="Enable auto-reload for development"),
    ] = False,
    workers: Annotated[
        int | None,
        cyclopts.Parameter(name="--workers", help="Number of worker processes"),
    ] = None,
    log_level: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--log-level", help="Log level (debug, info, warning, error)"
        ),
    ] = None,
) -> None:
    """Start the uvicorn server (internal relay).

    Starts a uvicorn server with the specified configuration.
    Auto-detects the Litestar app if not explicitly provided.

    Examples:
        m prod                            # Production server
        m prod --port 8080                # Custom port
        m dev                             # Development server
        m dev --app myapp.main:app        # Explicit app
    """
    # Find or use explicit app
    app_path = find_app(app)

    # Set up environment
    env = os.environ.copy()
    env["PYTHONPATH"] = get_pythonpath()

    # Build command
    cmd = build_uvicorn_command(
        app=app_path,
        host=host,
        port=port,
        reload=reload,
        workers=workers,
        log_level=log_level,
    )

    print(f"Starting server: {app_path}")
    print(f"  Host: {host}")
    print(f"  Port: {port}")
    print(f"  URL: http://{_display_host(host)}:{port}")
    print(f"  Reload: {reload}")
    if workers:
        print(f"  Workers: {workers}")
    print()

    # Execute uvicorn
    try:
        subprocess.run(cmd, env=env, check=True)
    except subprocess.CalledProcessError as e:
        raise SystemExit(e.returncode) from e
    except KeyboardInterrupt:
        print("\nServer stopped.")


__all__ = [
    "DEFAULT_APP_PATH",
    "build_uvicorn_command",
    "find_app",
    "get_pythonpath",
    "start_command",
]
