"""Bootstrap module for framework-m-standard.

This module contains the default bootstrap steps for SQLAlchemy-based
applications. Bootstrap steps run during application startup in order
(sorted by `order` field).

The default sequence:
1. init_engine (order=10) - Initialize SQLAlchemy engine
2. init_registries (order=20) - Set up MetaRegistry and FieldRegistry
3. sync_schema (order=30) - Create/update database tables
4. init_adapters (order=40) - Bind SQLAlchemy adapters to DI container

MX packages can override these steps by providing their own implementations
with the same name, or add new steps with different order values.
"""

from framework_m_standard.bootstrap.init_adapters import InitAdapters
from framework_m_standard.bootstrap.init_engine import InitEngine
from framework_m_standard.bootstrap.init_registries import InitRegistries
from framework_m_standard.bootstrap.runner import BootstrapRunner
from framework_m_standard.bootstrap.sync_schema import SyncSchema

__all__ = [
    "InitEngine",
    "InitRegistries",
    "SyncSchema",
    "InitAdapters",
    "BootstrapRunner",
]
