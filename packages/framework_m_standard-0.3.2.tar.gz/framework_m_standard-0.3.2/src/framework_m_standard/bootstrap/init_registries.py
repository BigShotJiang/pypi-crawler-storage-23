"""InitRegistries - Initialize MetaRegistry and FieldRegistry.

This bootstrap step ensures that the core registries are initialized
and ready for use. It runs after engine init (order=20) but before
schema sync which depends on these registries.
"""

from typing import Any

from framework_m_core.interfaces.bootstrap import BootstrapProtocol


class InitRegistries:
    """
    Initialize MetaRegistry and FieldRegistry singletons.

    This step ensures that both core registries are initialized and
    ready for use. The registries are singletons, so this step just
    triggers their initialization.

    Order: 20 (after engine init)

    What this step does:
        1. Initialize MetaRegistry (DocType registry)
        2. Initialize FieldRegistry (type mapping registry)
        3. Optionally load DocTypes from installed_apps config
        4. Bind registries to DI container for access

    After this step runs:
        - MetaRegistry is ready to register/retrieve DocTypes
        - FieldRegistry is ready to map Python types to SQLAlchemy types
        - DocTypes from installed_apps are discovered and registered

    MX Override Example (MongoDB):
        class InitMongoRegistries:
            name = "init_registries"
            order = 20

            async def run(self, container: Container) -> None:
                from framework_m_core.registry import MetaRegistry
                from framework_mx_mongo.field_registry import MongoFieldRegistry

                # Use custom MongoDB field registry
                meta_registry = MetaRegistry()
                field_registry = MongoFieldRegistry()  # BSON types

                # Load apps if configured
                apps = container.config.get("installed_apps", default=[])
                if apps:
                    meta_registry.load_apps(apps)

                # Bind to container
                container.meta_registry.override(meta_registry)
                container.field_registry.override(field_registry)
    """

    name = "init_registries"
    order = 20

    async def run(self, container: Any) -> None:
        """
        Initialize registries and load DocTypes.

        Args:
            container: DI container with optional config.installed_apps
        """
        from framework_m_core.registry import MetaRegistry

        from framework_m_standard.adapters.db.field_registry import FieldRegistry

        # Initialize singletons (they auto-initialize, but we ensure it here)
        meta_registry = MetaRegistry.get_instance()
        field_registry = FieldRegistry.get_instance()

        # Load DocTypes from installed apps if configured
        installed_apps = container.config.get("installed_apps", default=[])
        if installed_apps:
            count = meta_registry.load_apps(installed_apps)
            print(
                f"[InitRegistries] Discovered {count} DocTypes from {len(installed_apps)} apps"
            )

        # Bind to container for dependency injection
        if hasattr(container, "meta_registry"):
            container.meta_registry.override(meta_registry)
        else:
            container.config.meta_registry.from_value(meta_registry)

        if hasattr(container, "field_registry"):
            container.field_registry.override(field_registry)
        else:
            container.config.field_registry.from_value(field_registry)


# Verify protocol compliance
assert isinstance(InitRegistries(), BootstrapProtocol)
