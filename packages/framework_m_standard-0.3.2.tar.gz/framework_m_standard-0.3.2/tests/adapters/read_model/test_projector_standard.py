"""Tests for Projector - Event handler that updates Read Models.

Tests the Projector's event handling, subscription/unsubscription,
and doctype filtering logic.
"""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from framework_m_core.interfaces.event_bus import Event
from framework_m_standard.adapters.read_model.projector import Projector


@pytest.fixture
def mock_read_model() -> AsyncMock:
    """Create a mock ReadModel."""
    model = AsyncMock()
    model.project = AsyncMock()
    return model


@pytest.fixture
def mock_event_bus() -> AsyncMock:
    """Create a mock EventBus."""
    bus = AsyncMock()
    bus.subscribe_pattern = AsyncMock(side_effect=lambda p, h: f"sub-{p}")
    bus.unsubscribe = AsyncMock()
    return bus


class TestProjectorInit:
    """Test Projector initialization."""

    def test_default_event_patterns(self, mock_read_model: AsyncMock) -> None:
        """Projector should default to ['doc.*'] event patterns."""
        projector = Projector(read_model=mock_read_model)
        assert projector.event_patterns == ["doc.*"]

    def test_custom_event_patterns(self, mock_read_model: AsyncMock) -> None:
        """Projector should accept custom event patterns."""
        projector = Projector(
            read_model=mock_read_model,
            event_patterns=["doc.created", "doc.updated"],
        )
        assert projector.event_patterns == ["doc.created", "doc.updated"]

    def test_no_doctype_filter(self, mock_read_model: AsyncMock) -> None:
        """Projector should have no doctype filter by default."""
        projector = Projector(read_model=mock_read_model)
        assert projector.doctype_filter is None

    def test_custom_doctype_filter(self, mock_read_model: AsyncMock) -> None:
        """Projector should accept doctype filter."""
        projector = Projector(
            read_model=mock_read_model,
            doctype_filter=["Invoice", "Payment"],
        )
        assert projector.doctype_filter == ["Invoice", "Payment"]

    def test_empty_subscription_ids(self, mock_read_model: AsyncMock) -> None:
        """Projector should start with empty subscription ids."""
        projector = Projector(read_model=mock_read_model)
        assert projector.subscription_ids == []


class TestProjectorHandle:
    """Test Projector event handling."""

    @pytest.mark.asyncio
    async def test_handle_projects_event(self, mock_read_model: AsyncMock) -> None:
        """handle() should project event to read model."""
        projector = Projector(read_model=mock_read_model)
        event = Event(
            type="doc.created", data={"doctype": "Invoice", "name": "INV-001"}
        )

        await projector.handle(event)

        mock_read_model.project.assert_called_once_with(event)

    @pytest.mark.asyncio
    async def test_handle_with_doctype_filter_matching(
        self, mock_read_model: AsyncMock
    ) -> None:
        """handle() should process event when doctype matches filter."""
        projector = Projector(
            read_model=mock_read_model,
            doctype_filter=["Invoice"],
        )
        event = Event(type="doc.created", data={"doctype": "Invoice"})

        await projector.handle(event)

        mock_read_model.project.assert_called_once_with(event)

    @pytest.mark.asyncio
    async def test_handle_with_doctype_filter_not_matching(
        self, mock_read_model: AsyncMock
    ) -> None:
        """handle() should skip event when doctype doesn't match filter."""
        projector = Projector(
            read_model=mock_read_model,
            doctype_filter=["Invoice"],
        )
        event = Event(type="doc.created", data={"doctype": "Payment"})

        await projector.handle(event)

        mock_read_model.project.assert_not_called()

    @pytest.mark.asyncio
    async def test_handle_with_no_data(self, mock_read_model: AsyncMock) -> None:
        """handle() should handle event with no data."""
        projector = Projector(read_model=mock_read_model)
        event = Event(type="doc.created", data=None)

        await projector.handle(event)

        mock_read_model.project.assert_called_once_with(event)

    @pytest.mark.asyncio
    async def test_handle_no_filter_processes_all(
        self, mock_read_model: AsyncMock
    ) -> None:
        """handle() without filter should process all doctypes."""
        projector = Projector(read_model=mock_read_model)

        for doctype in ["Invoice", "Payment", "User"]:
            event = Event(type="doc.created", data={"doctype": doctype})
            await projector.handle(event)

        assert mock_read_model.project.call_count == 3


class TestProjectorSubscribe:
    """Test Projector subscription management."""

    @pytest.mark.asyncio
    async def test_subscribe_registers_patterns(
        self, mock_read_model: AsyncMock, mock_event_bus: AsyncMock
    ) -> None:
        """subscribe() should register all event patterns."""
        projector = Projector(
            read_model=mock_read_model,
            event_patterns=["doc.created", "doc.updated"],
        )

        await projector.subscribe(mock_event_bus)

        assert mock_event_bus.subscribe_pattern.call_count == 2
        assert len(projector.subscription_ids) == 2

    @pytest.mark.asyncio
    async def test_subscribe_stores_subscription_ids(
        self, mock_read_model: AsyncMock, mock_event_bus: AsyncMock
    ) -> None:
        """subscribe() should store subscription IDs for later cleanup."""
        projector = Projector(
            read_model=mock_read_model,
            event_patterns=["doc.created"],
        )

        await projector.subscribe(mock_event_bus)

        assert projector.subscription_ids == ["sub-doc.created"]


class TestProjectorUnsubscribe:
    """Test Projector unsubscription."""

    @pytest.mark.asyncio
    async def test_unsubscribe_removes_subscriptions(
        self, mock_read_model: AsyncMock, mock_event_bus: AsyncMock
    ) -> None:
        """unsubscribe() should remove all subscriptions."""
        projector = Projector(
            read_model=mock_read_model,
            event_patterns=["doc.created", "doc.updated"],
        )

        await projector.subscribe(mock_event_bus)
        await projector.unsubscribe(mock_event_bus)

        assert mock_event_bus.unsubscribe.call_count == 2
        assert projector.subscription_ids == []

    @pytest.mark.asyncio
    async def test_unsubscribe_clears_ids(
        self, mock_read_model: AsyncMock, mock_event_bus: AsyncMock
    ) -> None:
        """unsubscribe() should clear the subscription_ids list."""
        projector = Projector(
            read_model=mock_read_model,
            event_patterns=["doc.*"],
        )

        await projector.subscribe(mock_event_bus)
        assert len(projector.subscription_ids) == 1

        await projector.unsubscribe(mock_event_bus)
        assert len(projector.subscription_ids) == 0


class TestProjectorImport:
    """Test that Projector is properly exported."""

    def test_import_from_package(self) -> None:
        """Projector should be importable from the package."""
        from framework_m_standard.adapters.read_model import Projector as P

        assert P is Projector
