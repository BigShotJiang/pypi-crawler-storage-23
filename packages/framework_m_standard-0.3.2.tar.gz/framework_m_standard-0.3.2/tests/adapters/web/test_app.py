"""Tests for Litestar Application Setup.

TDD tests for the web application factory and configuration.
Tests written FIRST per CONTRIBUTING.md guidelines.
"""

import pytest
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.web.app import create_app
from litestar import Litestar
from litestar.testing import TestClient


@pytest.fixture(autouse=True)
def reset_registry():
    """Clear MetaRegistry before and after each test to avoid DuplicateDocTypeError."""
    MetaRegistry.get_instance()._doctypes.clear()
    yield
    MetaRegistry.get_instance()._doctypes.clear()


class TestAppFactory:
    """Test the application factory function."""

    def test_create_app_returns_litestar_instance(self) -> None:
        """Create_app should return a Litestar application instance."""
        app = create_app()
        assert isinstance(app, Litestar)

    def test_app_has_openapi_configured(self) -> None:
        """App should have OpenAPI documentation configured."""
        app = create_app()
        # OpenAPI config should be present
        assert app.openapi_config is not None
        # Should have a title set
        assert app.openapi_config.title is not None

    def test_app_has_cors_configured_for_development(self) -> None:
        """App should have CORS configured for development mode."""
        app = create_app()
        # CORS middleware should be added
        # In Litestar, CORS is configured via CORSConfig
        assert app.cors_config is not None

    def test_app_has_exception_handlers(self) -> None:
        """App should have custom exception handlers registered."""
        app = create_app()
        # Exception handlers should be configured
        assert app.exception_handlers is not None
        # Should have at least one handler
        assert len(app.exception_handlers) > 0


class TestHealthEndpoint:
    """Test the health check endpoint."""

    def test_health_endpoint_returns_200(self) -> None:
        """Health endpoint should return 200 OK."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/health")
            assert response.status_code == 200

    def test_health_endpoint_returns_status(self) -> None:
        """Health endpoint should return status information."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/health")
            data = response.json()
            assert "status" in data
            assert data["status"] == "healthy"


class TestAppLifecycle:
    """Test application lifecycle hooks."""

    @pytest.mark.asyncio
    async def test_lifespan_context_manager(self) -> None:
        """App should properly handle startup and shutdown."""
        app = create_app()
        # The lifespan context manager should be set
        # Litestar uses on_startup and on_shutdown or lifespan
        # We check that the app can be used as async context manager
        assert app is not None


class TestOpenAPIConfiguration:
    """Test OpenAPI/Swagger documentation configuration."""

    def test_swagger_ui_available(self) -> None:
        """Swagger UI should be available at /schema/swagger."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/schema/swagger")
            # Should redirect or return HTML
            assert response.status_code in [200, 301, 302, 307, 308]

    def test_openapi_schema_available(self) -> None:
        """OpenAPI JSON schema should be available."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/schema/openapi.json")
            assert response.status_code == 200
            data = response.json()
            # Should have OpenAPI version
            assert "openapi" in data
            # Should have info section
            assert "info" in data


class TestServeStaticMode:
    """Test serve_static parameter and M_DEV_MODE detection.

    Tests written FIRST per TDD principles.
    """

    def test_create_app_with_serve_static_true_includes_ui_routes(self) -> None:
        """When serve_static=True, app should include UI routes."""
        app = create_app(serve_static=True)

        # Check that UI routes are registered
        route_paths = [route.path for route in app.routes]

        # Should have root redirect
        assert "/" in route_paths
        # Should have desk routes
        assert "/desk/" in route_paths or "/desk" in route_paths

        # Should have static files config
        assert app.static_files_config is not None
        assert len(app.static_files_config) > 0

    def test_create_app_with_serve_static_false_excludes_ui_routes(self) -> None:
        """When serve_static=False, app should NOT include UI routes."""
        app = create_app(serve_static=False)

        # Should NOT have root redirect to /desk/
        # Note: / might still exist for other purposes, but redirect shouldn't
        # We test by trying to access the endpoint
        with TestClient(app) as client:
            response = client.get("/", follow_redirects=False)
            # Should NOT redirect to /desk/ (would get 404 or other)
            assert response.status_code != 307  # Not a redirect

        # Should NOT have static files config
        assert app.static_files_config == []

    def test_create_app_defaults_to_serve_static_true(self) -> None:
        """When serve_static is not specified, should default to True (production mode)."""
        app = create_app()  # No parameter

        # Should include UI routes (production default)
        route_paths = [route.path for route in app.routes]
        assert "/" in route_paths or any("/desk" in path for path in route_paths)

        # Should have static files config
        assert app.static_files_config is not None

    def test_create_app_detects_m_dev_mode_env_var(self, monkeypatch) -> None:
        """When M_DEV_MODE=true env var is set, should automatically use serve_static=False."""

        # Set M_DEV_MODE environment variable
        monkeypatch.setenv("M_DEV_MODE", "true")

        # Create app without specifying serve_static (should auto-detect)
        app = create_app()

        # Should NOT have static files config (dev mode)
        assert app.static_files_config == []

        # Clean up
        monkeypatch.delenv("M_DEV_MODE")

    def test_dev_mode_still_has_api_routes(self) -> None:
        """When serve_static=False, API routes should still be available."""
        app = create_app(serve_static=False)

        with TestClient(app) as client:
            # Health check should work
            response = client.get("/health")
            assert response.status_code == 200

            # Metadata API should work
            response = client.get("/api/meta/doctypes")
            assert response.status_code == 200

    def test_dev_mode_desk_path_returns_clean_404_json(self) -> None:
        """When serve_static=False, /desk should return structured 404 JSON."""
        app = create_app(serve_static=False)

        with TestClient(app) as client:
            response = client.get("/desk/")
            assert response.status_code == 404
            assert response.json() == {"status_code": 404, "detail": "Not Found"}

    def test_production_mode_has_both_api_and_ui_routes(self) -> None:
        """When serve_static=True, both API and UI routes should be available."""
        app = create_app(serve_static=True)

        with TestClient(app) as client:
            # API routes should work
            response = client.get("/health")
            assert response.status_code == 200

            # UI route should redirect or serve content
            response = client.get("/", follow_redirects=False)
            # Should redirect to /desk/ or serve content
            assert response.status_code in [200, 301, 302, 307, 308]


# =============================================================================
# Tests for Exception Handlers
# =============================================================================


class TestExceptionHandlers:
    """Test custom exception handlers."""

    def test_validation_error_handler(self) -> None:
        """ValidationError should return 400."""
        from unittest.mock import MagicMock

        from framework_m_core.exceptions import ValidationError
        from framework_m_standard.adapters.web.app import validation_error_handler

        exc = ValidationError("Invalid input")
        mock_request = MagicMock()

        response = validation_error_handler(mock_request, exc)

        assert response.status_code == 400

    def test_permission_denied_handler(self) -> None:
        """PermissionDeniedError should return 403."""
        from unittest.mock import MagicMock

        from framework_m_core.exceptions import PermissionDeniedError
        from framework_m_standard.adapters.web.app import permission_denied_handler

        exc = PermissionDeniedError("Access denied")
        mock_request = MagicMock()

        response = permission_denied_handler(mock_request, exc)

        assert response.status_code == 403

    def test_not_found_handler(self) -> None:
        """EntityNotFoundError should return 404."""
        from unittest.mock import MagicMock

        from framework_m_core.exceptions import EntityNotFoundError
        from framework_m_standard.adapters.web.app import not_found_handler

        exc = EntityNotFoundError(doctype_name="Todo", entity_id="TODO-001")
        mock_request = MagicMock()

        response = not_found_handler(mock_request, exc)

        assert response.status_code == 404

    def test_duplicate_name_handler(self) -> None:
        """DuplicateNameError should return 409."""
        from unittest.mock import MagicMock

        from framework_m_core.exceptions import DuplicateNameError
        from framework_m_standard.adapters.web.app import duplicate_name_handler

        exc = DuplicateNameError(doctype_name="Todo", name="TODO-001")
        mock_request = MagicMock()

        response = duplicate_name_handler(mock_request, exc)

        assert response.status_code == 409

    def test_framework_error_handler(self) -> None:
        """FrameworkError should return 500."""
        from unittest.mock import MagicMock

        from framework_m_core.exceptions import FrameworkError
        from framework_m_standard.adapters.web.app import framework_error_handler

        exc = FrameworkError("Internal error")
        mock_request = MagicMock()

        response = framework_error_handler(mock_request, exc)

        assert response.status_code == 500


# =============================================================================
# Tests for Wired Routers
# =============================================================================


class TestWiredRouters:
    """Test that routers are properly wired to the app."""

    def test_auth_endpoint_available(self) -> None:
        """App should have /api/v1/auth/me endpoint."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/api/v1/auth/me")
            assert response.status_code == 200

    def test_metadata_endpoint_available(self) -> None:
        """App should have /api/meta/doctypes endpoint."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/api/meta/doctypes")
            assert response.status_code == 200

    def test_auth_endpoint_returns_user_info(self) -> None:
        """Auth endpoint should return user info structure."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/api/v1/auth/me")
            data = response.json()
            assert "authenticated" in data
            assert "id" in data
            assert "roles" in data

    def test_metadata_endpoint_returns_doctype_list(self) -> None:
        """Metadata endpoint should return doctypes structure."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/api/meta/doctypes")
            data = response.json()
            assert "doctypes" in data
            assert "count" in data


class TestAppMiddleware:
    """Test that middleware is properly configured."""

    def test_app_has_auth_middleware(self) -> None:
        """App should have AuthMiddleware configured."""
        app = create_app()
        # Middleware should be present
        assert app.middleware is not None
        assert len(app.middleware) > 0

    def test_auth_middleware_allows_guest_access(self) -> None:
        """App should allow guest access (require_auth=False)."""
        app = create_app()
        with TestClient(app) as client:
            # Should not return 401 without auth headers
            response = client.get("/api/v1/auth/me")
            assert response.status_code == 200

    def test_auth_headers_are_processed(self) -> None:
        """App should process auth headers when provided."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get(
                "/api/v1/auth/me",
                headers={
                    "x-user-id": "test-user-123",
                    "x-user-email": "test@example.com",
                    "x-roles": "Admin",
                },
            )
            assert response.status_code == 200
            data = response.json()
            assert data["authenticated"] is True
            assert data["id"] == "test-user-123"


# =============================================================================
# Tests for Desk UI Serving Routes
# =============================================================================


class TestRootRedirect:
    """Test the root redirect to /desk/."""

    def test_root_redirects_to_desk(self) -> None:
        """GET / should redirect to /desk/."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/", follow_redirects=False)
            assert response.status_code in [301, 302, 307, 308]
            assert "/desk/" in response.headers.get("location", "")


class TestDeskServing:
    """Test the Desk UI serving routes."""

    def test_desk_root_returns_html(self) -> None:
        """GET /desk/ should return HTML content."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk/")
            # Should return 200 with HTML or 404 if not available
            assert response.status_code in [200, 404]

    def test_desk_without_trailing_slash(self) -> None:
        """GET /desk should also work."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk")
            assert response.status_code in [200, 301, 302, 307, 308, 404]

    def test_desk_spa_navigation_route(self) -> None:
        """GET /desk/doctypes/Invoice should serve index.html for SPA routing."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk/doctypes/Invoice")
            # Should return HTML (SPA route) or 404 if not available
            assert response.status_code in [200, 404]

    def test_desk_spa_static_file_returns_correct_mime(self) -> None:
        """GET /desk/assets/something.js should NOT return text/html."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk/assets/nonexistent.js")
            # Should be 404 (not found), NOT 200 with text/html
            # The key check: if 200, mime should be JS not HTML
            if response.status_code == 200:
                content_type = response.headers.get("content-type", "")
                assert "text/html" not in content_type
            else:
                assert response.status_code == 404

    def test_desk_spa_css_file_not_served_as_html(self) -> None:
        """GET /desk/assets/something.css should NOT return text/html."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk/assets/nonexistent.css")
            if response.status_code == 200:
                content_type = response.headers.get("content-type", "")
                assert "text/html" not in content_type
            else:
                assert response.status_code == 404

    def test_desk_favicon_not_served_as_html(self) -> None:
        """GET /desk/favicon.ico should NOT return text/html."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk/favicon.ico")
            if response.status_code == 200:
                content_type = response.headers.get("content-type", "")
                assert "text/html" not in content_type
            else:
                assert response.status_code == 404

    def test_desk_deep_spa_route(self) -> None:
        """GET /desk/settings/general should serve SPA HTML."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/desk/settings/general")
            assert response.status_code in [200, 404]

    def test_root_favicon_returns_clean_404_or_icon(self) -> None:
        """GET /favicon.ico should not crash and should return icon or clean 404."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/favicon.ico")
            assert response.status_code in [200, 404]


class TestFaviconResponse:
    """Tests for favicon response helper."""

    def test_prefers_explicit_frontend_dist_favicon(
        self, tmp_path, monkeypatch
    ) -> None:
        """Should serve favicon from FRAMEWORK_M_FRONTEND_DIST when available."""
        from framework_m_standard.adapters.web.app import _get_favicon_response

        dist = tmp_path / "frontend" / "dist"
        dist.mkdir(parents=True)
        expected = b"ico-data"
        (dist / "favicon.ico").write_bytes(expected)

        monkeypatch.setenv("FRAMEWORK_M_FRONTEND_DIST", str(dist))
        response = _get_favicon_response()

        assert response.status_code in (None, 200)
        assert response.content == expected


# =============================================================================
# Tests for Desk HTML Response and Static Path
# =============================================================================


class TestDeskHtmlResponse:
    """Test the _get_desk_html_response helper."""

    def test_returns_response(self) -> None:
        """Function should return a Response object."""
        from framework_m_standard.adapters.web.app import _get_desk_html_response
        from litestar import Response

        response = _get_desk_html_response()
        assert isinstance(response, Response)

    def test_response_has_content(self) -> None:
        """Response should have content (either HTML or error message)."""
        from framework_m_standard.adapters.web.app import _get_desk_html_response

        response = _get_desk_html_response()
        assert response.content is not None

    def test_prefers_explicit_frontend_dist_index(self, tmp_path, monkeypatch) -> None:
        """When explicit frontend dist is set, should serve its index.html first."""
        from framework_m_standard.adapters.web.app import _get_desk_html_response

        dist = tmp_path / "frontend" / "dist"
        dist.mkdir(parents=True)
        expected_html = b"<html><body>custom-ui</body></html>"
        (dist / "index.html").write_bytes(expected_html)

        monkeypatch.setenv("FRAMEWORK_M_FRONTEND_DIST", str(dist))
        response = _get_desk_html_response()
        assert response.status_code in (None, 200)
        assert response.content == expected_html

    def test_rewrites_root_asset_urls_for_desk(self, tmp_path, monkeypatch) -> None:
        """Root absolute asset URLs should be rewritten to /desk/* in served HTML."""
        from framework_m_standard.adapters.web.app import _get_desk_html_response

        dist = tmp_path / "frontend" / "dist"
        dist.mkdir(parents=True)
        (dist / "index.html").write_text(
            '<html><head><link href="/index-abc.css"></head><body><script src="/index-abc.js"></script></body></html>',
            encoding="utf-8",
        )

        monkeypatch.setenv("FRAMEWORK_M_FRONTEND_DIST", str(dist))
        response = _get_desk_html_response()

        html = response.content.decode("utf-8")
        assert 'href="/desk/index-abc.css"' in html
        assert 'src="/desk/index-abc.js"' in html

    def test_rewrites_relative_asset_urls_for_desk(self, tmp_path, monkeypatch) -> None:
        """Relative asset URLs should also be rewritten to /desk/* in served HTML."""
        from framework_m_standard.adapters.web.app import _get_desk_html_response

        dist = tmp_path / "frontend" / "dist"
        dist.mkdir(parents=True)
        (dist / "index.html").write_text(
            '<html><head><link href="index-abc.css"></head><body><script src="./index-abc.js"></script></body></html>',
            encoding="utf-8",
        )

        monkeypatch.setenv("FRAMEWORK_M_FRONTEND_DIST", str(dist))
        response = _get_desk_html_response()

        html = response.content.decode("utf-8")
        assert 'href="/desk/index-abc.css"' in html
        assert 'src="/desk/index-abc.js"' in html


class TestBundledStaticPath:
    """Test the _get_bundled_static_path function."""

    def test_returns_path_or_none(self) -> None:
        """Should return a Path or None."""
        from pathlib import Path

        from framework_m_standard.adapters.web.app import _get_bundled_static_path

        result = _get_bundled_static_path()
        assert result is None or isinstance(result, Path)

    def test_static_path_is_directory_if_exists(self) -> None:
        """If path is returned, it should be a directory."""
        from framework_m_standard.adapters.web.app import _get_bundled_static_path

        result = _get_bundled_static_path()
        if result is not None:
            assert result.is_dir()


# =============================================================================
# Tests for Static Files Config
# =============================================================================


class TestStaticFilesConfig:
    """Test the _create_static_files_config function."""

    def test_returns_list(self) -> None:
        """Should return a list of StaticFilesConfig."""
        from framework_m_standard.adapters.web.app import _create_static_files_config

        configs = _create_static_files_config()
        assert isinstance(configs, list)

    def test_bundled_config_has_desk_assets_path(self) -> None:
        """If bundled static with assets/ exists, config should have /desk/assets path."""
        from framework_m_standard.adapters.web.app import (
            _create_static_files_config,
            _get_bundled_static_path,
        )

        configs = _create_static_files_config()
        bundled = _get_bundled_static_path()
        if bundled is not None and (bundled / "assets").exists():
            # At least one config with /desk/assets path
            paths = [c.path for c in configs]
            assert "/desk/assets" in paths

    def test_prefers_explicit_frontend_dist_assets(self, tmp_path, monkeypatch) -> None:
        """When explicit frontend dist is set, assets should come from that dist."""
        from framework_m_standard.adapters.web.app import _create_static_files_config

        dist = tmp_path / "frontend" / "dist"
        assets = dist / "assets"
        assets.mkdir(parents=True)

        monkeypatch.setenv("FRAMEWORK_M_FRONTEND_DIST", str(dist))
        configs = _create_static_files_config()

        assert configs
        assert configs[0].path == "/desk/assets"
        assert assets in configs[0].directories


# =============================================================================
# Tests for get_asset_url
# =============================================================================


class TestGetAssetUrl:
    """Test the get_asset_url function."""

    def test_returns_local_url_without_cdn(self) -> None:
        """Without CDN config, should return local /assets/ path."""
        from unittest.mock import patch

        from framework_m_standard.adapters.web.app import get_asset_url

        # Mock config to return no CDN
        with patch(
            "framework_m_standard.adapters.web.app.load_config",
            return_value={},
        ):
            url = get_asset_url("js/main.js")
            assert url == "/assets/js/main.js"

    def test_returns_cdn_url_with_cdn_config(self) -> None:
        """With CDN config, should return CDN URL."""
        from unittest.mock import patch

        from framework_m_standard.adapters.web.app import get_asset_url

        with patch(
            "framework_m_standard.adapters.web.app.load_config",
            return_value={"frontend": {"cdn_url": "https://cdn.example.com"}},
        ):
            url = get_asset_url("js/main.js")
            assert url == "https://cdn.example.com/js/main.js"

    def test_cdn_url_with_trailing_slash(self) -> None:
        """CDN URL with trailing slash should not double-slash."""
        from unittest.mock import patch

        from framework_m_standard.adapters.web.app import get_asset_url

        with patch(
            "framework_m_standard.adapters.web.app.load_config",
            return_value={"frontend": {"cdn_url": "https://cdn.example.com/"}},
        ):
            url = get_asset_url("js/main.js")
            assert url == "https://cdn.example.com/js/main.js"

    def test_strips_leading_slash_from_asset_path(self) -> None:
        """Asset path with leading slash should be normalized."""
        from unittest.mock import patch

        from framework_m_standard.adapters.web.app import get_asset_url

        with patch(
            "framework_m_standard.adapters.web.app.load_config",
            return_value={},
        ):
            url = get_asset_url("/js/main.js")
            assert url == "/assets/js/main.js"

    def test_cdn_strips_leading_slash_from_asset_path(self) -> None:
        """CDN path should also strip leading slash."""
        from unittest.mock import patch

        from framework_m_standard.adapters.web.app import get_asset_url

        with patch(
            "framework_m_standard.adapters.web.app.load_config",
            return_value={"frontend": {"cdn_url": "https://cdn.example.com"}},
        ):
            url = get_asset_url("/css/style.css")
            assert url == "https://cdn.example.com/css/style.css"
