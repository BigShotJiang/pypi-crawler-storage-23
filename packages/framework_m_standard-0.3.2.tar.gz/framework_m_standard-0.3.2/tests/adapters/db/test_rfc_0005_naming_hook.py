"""Test for RFC-0005: After Naming Hook."""

from typing import Any, ClassVar

import pytest
from framework_m_core import DocType, Field
from framework_m_core.domain.base_controller import BaseController
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from sqlalchemy import Column, MetaData, String, Table, Uuid
from sqlalchemy.ext.asyncio import AsyncSession


# 1. Define DocType and Controller
class RFCInvoice(DocType):
    """Test DocType with naming pattern."""

    title: str = Field(description="Invoice Title")

    class Meta:
        name_pattern: ClassVar[str] = "INV-.####"


class RFCInvoiceController(BaseController[RFCInvoice]):
    """Controller to test hooks."""

    def __init__(self, doc: RFCInvoice) -> None:
        super().__init__(doc)
        self.hooks_called: list[str] = []
        self.name_at_hook: dict[str, str | None] = {}

    async def after_insert(self, context: Any = None) -> None:
        self.hooks_called.append("after_insert")
        self.name_at_hook["after_insert"] = self.doc.name

    async def after_naming(self, context: Any = None) -> None:
        self.hooks_called.append("after_naming")
        self.name_at_hook["after_naming"] = self.doc.name


# 2. Test Class
class TestAfterNamingHook:
    @pytest.fixture
    async def repository(
        self, db_session: AsyncSession
    ) -> GenericRepository[RFCInvoice]:
        """Setup repository with in-memory table."""
        metadata = MetaData()
        table = Table(
            "rfc_invoice",
            metadata,
            Column("id", Uuid, primary_key=True),
            Column("name", String, unique=True),
            Column("title", String),
            Column("parent", String, nullable=True),
            Column("parenttype", String, nullable=True),
            Column("parentfield", String, nullable=True),
            Column("idx", String, nullable=True),
            Column("modified", String, nullable=True),
            Column("creation", String, nullable=True),
            Column("docstatus", String, nullable=True),
            Column("owner", String, nullable=True),
            Column("_version", String, nullable=True),
            Column("modified_by", String, nullable=True),
            Column("deleted_at", String, nullable=True),
        )

        # Create table
        await db_session.run_sync(
            lambda session: metadata.create_all(session.connection())
        )

        return GenericRepository(
            model=RFCInvoice, table=table, controller_class=RFCInvoiceController
        )

    @pytest.mark.asyncio
    async def test_after_naming_hook_called(
        self, repository: GenericRepository[RFCInvoice], db_session: AsyncSession
    ) -> None:
        """Test that after_naming hook is called and has correct name."""

        doc = RFCInvoice(title="Test Invoice")

        # Save should trigger hooks
        await repository.save(db_session, doc)

        # Retrieve controller from repository (mock/spy needed?
        # GenericRepository instantiates controller internally.
        # We need to capture the controller instance or use a spy.
        # Since we can't easily access the internal controller instance,
        # we might need to mock the controller class or use a side effect.

        # Ah, GenericRepository instantiates the controller fresh each time.
        # But wait, `save` creates a controller instance.
        # I need a way to check if hooks were called on THAT instance.
        pass


# Redefine test to handle controller verification
# We can subclass GenericRepository to capture the controller, or patch the controller class.


class CapturingRFCInvoiceController(RFCInvoiceController):
    # Global/Class-level list to capture instances for testing
    instances: ClassVar[list["CapturingRFCInvoiceController"]] = []

    def __init__(self, doc: RFCInvoice) -> None:
        super().__init__(doc)
        CapturingRFCInvoiceController.instances.append(self)

    @classmethod
    def reset(cls):
        cls.instances.clear()


@pytest.mark.asyncio
async def test_after_naming_hook_execution(db_session: AsyncSession):
    # Setup Table
    metadata = MetaData()
    table = Table(
        "rfc_invoice_2",  # unique name
        metadata,
        Column("id", Uuid, primary_key=True),
        Column("name", String, unique=True),
        Column("title", String),
        Column("deleted_at", String, nullable=True),
        Column("modified", String, nullable=True),
        Column("_version", String, nullable=True),
        Column("creation", String, nullable=True),
        Column("modified_by", String, nullable=True),
        Column("owner", String, nullable=True),
        Column("docstatus", String, nullable=True),
        Column("parent", String, nullable=True),
        Column("parenttype", String, nullable=True),
        Column("parentfield", String, nullable=True),
        Column("idx", String, nullable=True),
    )

    await db_session.run_sync(lambda session: metadata.create_all(session.connection()))

    CapturingRFCInvoiceController.reset()

    repo = GenericRepository(
        model=RFCInvoice, table=table, controller_class=CapturingRFCInvoiceController
    )

    doc = RFCInvoice(title="Test Invoice")

    # Save
    await repo.save(db_session, doc)

    assert len(CapturingRFCInvoiceController.instances) > 0
    controller = CapturingRFCInvoiceController.instances[-1]

    # Check if after_naming was called
    assert "after_naming" in controller.hooks_called, (
        "after_naming hook should be called"
    )

    # Verify name availability
    assert controller.name_at_hook["after_naming"] is not None
    assert controller.name_at_hook["after_naming"].startswith("INV-")
