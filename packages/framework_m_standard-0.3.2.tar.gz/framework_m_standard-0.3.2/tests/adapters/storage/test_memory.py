"""Tests for InMemoryStorageAdapter.

Tests for all CRUD operations and edge cases of the in-memory storage adapter.
"""

import pytest
from framework_m_standard.adapters.storage.memory import InMemoryStorageAdapter


@pytest.fixture
def storage() -> InMemoryStorageAdapter:
    """Create a fresh InMemoryStorageAdapter for each test."""
    return InMemoryStorageAdapter()


class TestInMemoryStorageAdapter:
    """Test InMemoryStorageAdapter CRUD operations."""

    @pytest.mark.asyncio
    async def test_save_and_get_file(self, storage: InMemoryStorageAdapter) -> None:
        """Save a file and retrieve it successfully."""
        content = b"Hello, World!"
        path = await storage.save_file("test/file.txt", content, "text/plain")
        assert path == "test/file.txt"

        result = await storage.get_file("test/file.txt")
        assert result == content

    @pytest.mark.asyncio
    async def test_get_file_not_found(self, storage: InMemoryStorageAdapter) -> None:
        """Getting a non-existent file should raise FileNotFoundError."""
        with pytest.raises(FileNotFoundError, match="File not found"):
            await storage.get_file("nonexistent.txt")

    @pytest.mark.asyncio
    async def test_delete_file(self, storage: InMemoryStorageAdapter) -> None:
        """Delete a file successfully."""
        await storage.save_file("test.txt", b"data")
        await storage.delete_file("test.txt")

        assert not await storage.exists("test.txt")

    @pytest.mark.asyncio
    async def test_delete_file_not_found(self, storage: InMemoryStorageAdapter) -> None:
        """Deleting a non-existent file should raise FileNotFoundError."""
        with pytest.raises(FileNotFoundError, match="File not found"):
            await storage.delete_file("nonexistent.txt")

    @pytest.mark.asyncio
    async def test_exists(self, storage: InMemoryStorageAdapter) -> None:
        """Check file existence."""
        assert not await storage.exists("test.txt")
        await storage.save_file("test.txt", b"data")
        assert await storage.exists("test.txt")

    @pytest.mark.asyncio
    async def test_list_files(self, storage: InMemoryStorageAdapter) -> None:
        """List files by prefix."""
        await storage.save_file("uploads/a.txt", b"a")
        await storage.save_file("uploads/b.txt", b"b")
        await storage.save_file("other/c.txt", b"c")

        uploads = await storage.list_files("uploads/")
        assert len(uploads) == 2
        assert "uploads/a.txt" in uploads
        assert "uploads/b.txt" in uploads

    @pytest.mark.asyncio
    async def test_list_files_empty(self, storage: InMemoryStorageAdapter) -> None:
        """List files returns empty for non-matching prefix."""
        await storage.save_file("uploads/a.txt", b"a")
        result = await storage.list_files("nonexistent/")
        assert result == []

    @pytest.mark.asyncio
    async def test_get_metadata(self, storage: InMemoryStorageAdapter) -> None:
        """Get metadata for a stored file."""
        await storage.save_file("test.txt", b"hello", "text/plain")
        metadata = await storage.get_metadata("test.txt")

        assert metadata is not None
        assert metadata.path == "test.txt"
        assert metadata.size == 5
        assert metadata.content_type == "text/plain"
        assert metadata.modified is not None

    @pytest.mark.asyncio
    async def test_get_metadata_not_found(
        self, storage: InMemoryStorageAdapter
    ) -> None:
        """Get metadata for non-existent file returns None."""
        metadata = await storage.get_metadata("nonexistent.txt")
        assert metadata is None

    @pytest.mark.asyncio
    async def test_get_url(self, storage: InMemoryStorageAdapter) -> None:
        """Get URL for a file returns pseudo mem:// URL."""
        url = await storage.get_url("test.txt", expires=3600)
        assert url == "mem://test.txt?expires=3600"

    @pytest.mark.asyncio
    async def test_copy(self, storage: InMemoryStorageAdapter) -> None:
        """Copy a file within storage."""
        await storage.save_file("src.txt", b"content", "text/plain")
        dest = await storage.copy("src.txt", "dest.txt")

        assert dest == "dest.txt"
        assert await storage.get_file("src.txt") == b"content"
        assert await storage.get_file("dest.txt") == b"content"

    @pytest.mark.asyncio
    async def test_copy_not_found(self, storage: InMemoryStorageAdapter) -> None:
        """Copy from non-existent source raises FileNotFoundError."""
        with pytest.raises(FileNotFoundError, match="Source file not found"):
            await storage.copy("nonexistent.txt", "dest.txt")

    @pytest.mark.asyncio
    async def test_move(self, storage: InMemoryStorageAdapter) -> None:
        """Move a file within storage."""
        await storage.save_file("src.txt", b"content", "text/plain")
        dest = await storage.move("src.txt", "dest.txt")

        assert dest == "dest.txt"
        assert not await storage.exists("src.txt")
        assert await storage.get_file("dest.txt") == b"content"

    @pytest.mark.asyncio
    async def test_save_overwrites_existing(
        self, storage: InMemoryStorageAdapter
    ) -> None:
        """Saving to same path overwrites the file."""
        await storage.save_file("test.txt", b"old")
        await storage.save_file("test.txt", b"new")

        result = await storage.get_file("test.txt")
        assert result == b"new"
