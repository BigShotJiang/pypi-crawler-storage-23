"""Tests for prod CLI command.

This module tests the production server command:
- Backend-only mode
- Deployment mode handling
- Prebuilt frontend static serve option
- CLI integration for m prod
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

from framework_m_standard.cli.serve import (
    _get_deployment_mode,
    _get_prebuilt_frontend_dist,
    _resolve_prebuilt_frontend_dist,
    _start_backend_only,
    _start_with_frontend,
    prod_command,
)


class TestDeploymentMode:
    """Tests for _get_deployment_mode helper."""

    @patch("framework_m_standard.cli.serve.load_config", return_value={})
    def test_default_indie(self, _mock_config: MagicMock) -> None:
        """Should default to indie when no config present."""
        assert _get_deployment_mode() == "indie"

    @patch(
        "framework_m_standard.cli.serve.load_config",
        return_value={"deployment": {"mode": "enterprise"}},
    )
    def test_reads_deployment_mode(self, _mock_config: MagicMock) -> None:
        """Should read deployment.mode from config."""
        assert _get_deployment_mode() == "enterprise"

    @patch(
        "framework_m_standard.cli.serve.load_config",
        return_value={"frontend": {"mode": "indie"}},
    )
    def test_reads_frontend_mode(self, _mock_config: MagicMock) -> None:
        """Should read frontend.mode from config."""
        assert _get_deployment_mode() == "indie"

    @patch(
        "framework_m_standard.cli.serve.load_config",
        return_value={"deployment": {"mode": " Enterprise "}},
    )
    def test_normalizes_mode(self, _mock_config: MagicMock) -> None:
        """Should normalize mode casing and whitespace."""
        assert _get_deployment_mode() == "enterprise"


class TestStartBackendOnly:
    """Tests for _start_backend_only helper."""

    @patch("framework_m_standard.cli.start.start_command")
    def test_delegates_to_standard_start(self, mock_std_start: MagicMock) -> None:
        """Should call framework-m-standard's start command."""
        _start_backend_only(
            port=8000,
            reload=True,
            host="0.0.0.0",
            app="custom:app",
        )

        mock_std_start.assert_called_once_with(
            app="custom:app",
            host="0.0.0.0",
            port=8000,
            reload=True,
        )


class TestPrebuiltFrontendDist:
    """Tests for prebuilt frontend dist detection."""

    def test_returns_none_when_dist_missing(self, tmp_path) -> None:
        """Should return None when frontend/dist does not exist."""
        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()

        assert _get_prebuilt_frontend_dist(frontend_dir) is None

    def test_returns_dist_when_index_exists(self, tmp_path) -> None:
        """Should return dist path when index.html is present."""
        frontend_dir = tmp_path / "frontend"
        dist_dir = frontend_dir / "dist"
        dist_dir.mkdir(parents=True)
        (dist_dir / "index.html").write_text("<html></html>")

        assert _get_prebuilt_frontend_dist(frontend_dir) == dist_dir

    def test_resolves_dist_from_parent_when_cwd_is_subdir(self, tmp_path) -> None:
        """Should discover prebuilt dist by searching cwd parent directories."""
        project_root = tmp_path / "project"
        frontend_dir = project_root / "frontend"
        dist_dir = frontend_dir / "dist"
        dist_dir.mkdir(parents=True)
        (dist_dir / "index.html").write_text("<html></html>")

        work_subdir = project_root / "apps" / "studio"
        work_subdir.mkdir(parents=True)

        previous_cwd = os.getcwd()
        try:
            os.chdir(work_subdir)
            resolved_dist, candidates = _resolve_prebuilt_frontend_dist(
                Path("frontend")
            )
        finally:
            os.chdir(previous_cwd)

        assert resolved_dist == dist_dir
        assert frontend_dir in candidates


class TestStartWithFrontend:
    """Tests for _start_with_frontend helper."""

    @patch("framework_m_standard.cli.serve._start_backend_only")
    def test_uses_prebuilt_dist_env_when_available(
        self, mock_backend: MagicMock, tmp_path
    ) -> None:
        """Should set FRAMEWORK_M_FRONTEND_DIST when prebuilt dist exists."""
        frontend_dir = tmp_path / "frontend"
        dist_dir = frontend_dir / "dist"
        dist_dir.mkdir(parents=True)
        (dist_dir / "index.html").write_text("<html></html>")

        previous_dist = os.environ.get("FRAMEWORK_M_FRONTEND_DIST")
        previous_dev_mode = os.environ.get("M_DEV_MODE")
        try:
            _start_with_frontend(
                frontend_dir=frontend_dir,
                port=8000,
                reload=False,
                host="127.0.0.1",
                app="framework_m_standard.adapters.web.app:create_app",
            )
            mock_backend.assert_called_once()
            assert os.environ.get("FRAMEWORK_M_FRONTEND_DIST") == previous_dist
            assert os.environ.get("M_DEV_MODE") == previous_dev_mode
        finally:
            if previous_dist is not None:
                os.environ["FRAMEWORK_M_FRONTEND_DIST"] = previous_dist
            else:
                os.environ.pop("FRAMEWORK_M_FRONTEND_DIST", None)
            if previous_dev_mode is not None:
                os.environ["M_DEV_MODE"] = previous_dev_mode
            else:
                os.environ.pop("M_DEV_MODE", None)


class TestProdCommand:
    """Tests for prod_command behavior."""

    def test_sets_dev_mode_for_enterprise(self) -> None:
        """Enterprise mode should set M_DEV_MODE=true during startup."""
        with (
            patch(
                "framework_m_standard.cli.serve._get_deployment_mode",
                return_value="enterprise",
            ),
            patch("framework_m_standard.cli.serve._start_backend_only") as mock_backend,
        ):
            prod_command()

        assert os.environ.get("M_DEV_MODE") != "true"
        mock_backend.assert_called_once()

    def test_sets_dev_mode_for_indie(self) -> None:
        """Indie mode should set M_DEV_MODE=false during startup."""
        with (
            patch(
                "framework_m_standard.cli.serve._get_deployment_mode",
                return_value="indie",
            ),
            patch("framework_m_standard.cli.serve._start_backend_only") as mock_backend,
        ):
            prod_command()

        assert os.environ.get("M_DEV_MODE") != "true"
        mock_backend.assert_called_once()

    def test_with_frontend_uses_prebuilt_and_starts_backend(self) -> None:
        """with_frontend should use prebuilt frontend if available and start backend."""
        with patch(
            "framework_m_standard.cli.serve._start_with_frontend"
        ) as mock_frontend:
            prod_command(with_frontend=True)

        mock_frontend.assert_called_once()


class TestServeCLIIntegration:
    """Integration tests for m prod command."""

    def test_prod_command_available(self) -> None:
        """m prod command should be registered."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "prod", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "Start Framework M in production mode" in result.stdout

    def test_prod_command_shows_default_values(self) -> None:
        """m prod --help should show default port 8000."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "prod", "--help"],
            capture_output=True,
            text=True,
        )
        assert "8000" in result.stdout
        assert "0.0.0.0" in result.stdout
