"""Tests for bootstrap sequence and individual bootstrap steps.

This module tests the default SQLAlchemy bootstrap sequence:
1. InitEngine (order=10)
2. InitRegistries (order=20)
3. SyncSchema (order=30)
4. InitAdapters (order=40)
"""

import pytest
from framework_m_core.interfaces.bootstrap import BootstrapProtocol
from framework_m_standard.bootstrap import (
    InitAdapters,
    InitEngine,
    InitRegistries,
    SyncSchema,
)


class TestBootstrapProtocolCompliance:
    """Test that all bootstrap steps implement BootstrapProtocol."""

    def test_init_engine_implements_protocol(self) -> None:
        """InitEngine should implement BootstrapProtocol."""
        step = InitEngine()
        assert isinstance(step, BootstrapProtocol)

    def test_init_registries_implements_protocol(self) -> None:
        """InitRegistries should implement BootstrapProtocol."""
        step = InitRegistries()
        assert isinstance(step, BootstrapProtocol)

    def test_sync_schema_implements_protocol(self) -> None:
        """SyncSchema should implement BootstrapProtocol."""
        step = SyncSchema()
        assert isinstance(step, BootstrapProtocol)

    def test_init_adapters_implements_protocol(self) -> None:
        """InitAdapters should implement BootstrapProtocol."""
        step = InitAdapters()
        assert isinstance(step, BootstrapProtocol)


class TestBootstrapStepProperties:
    """Test that bootstrap steps have correct name and order properties."""

    def test_init_engine_has_correct_name(self) -> None:
        """InitEngine should have name 'init_engine'."""
        step = InitEngine()
        assert step.name == "init_engine"

    def test_init_engine_has_correct_order(self) -> None:
        """InitEngine should have order=10."""
        step = InitEngine()
        assert step.order == 10

    def test_init_registries_has_correct_name(self) -> None:
        """InitRegistries should have name 'init_registries'."""
        step = InitRegistries()
        assert step.name == "init_registries"

    def test_init_registries_has_correct_order(self) -> None:
        """InitRegistries should have order=20."""
        step = InitRegistries()
        assert step.order == 20

    def test_sync_schema_has_correct_name(self) -> None:
        """SyncSchema should have name 'sync_schema'."""
        step = SyncSchema()
        assert step.name == "sync_schema"

    def test_sync_schema_has_correct_order(self) -> None:
        """SyncSchema should have order=30."""
        step = SyncSchema()
        assert step.order == 30

    def test_init_adapters_has_correct_name(self) -> None:
        """InitAdapters should have name 'init_adapters'."""
        step = InitAdapters()
        assert step.name == "init_adapters"

    def test_init_adapters_has_correct_order(self) -> None:
        """InitAdapters should have order=40."""
        step = InitAdapters()
        assert step.order == 40


class TestBootstrapStepMethods:
    """Test that bootstrap steps have required run() method."""

    def test_init_engine_has_run_method(self) -> None:
        """InitEngine should have async run() method."""
        step = InitEngine()
        assert hasattr(step, "run")
        assert callable(step.run)

    def test_init_registries_has_run_method(self) -> None:
        """InitRegistries should have async run() method."""
        step = InitRegistries()
        assert hasattr(step, "run")
        assert callable(step.run)

    def test_sync_schema_has_run_method(self) -> None:
        """SyncSchema should have async run() method."""
        step = SyncSchema()
        assert hasattr(step, "run")
        assert callable(step.run)

    def test_init_adapters_has_run_method(self) -> None:
        """InitAdapters should have async run() method."""
        step = InitAdapters()
        assert hasattr(step, "run")
        assert callable(step.run)


class TestBootstrapSequenceOrder:
    """Test that bootstrap steps execute in correct order."""

    def test_steps_sorted_by_order(self) -> None:
        """Bootstrap steps should sort by order property."""
        steps = [
            InitAdapters(),  # order=40
            InitEngine(),  # order=10
            SyncSchema(),  # order=30
            InitRegistries(),  # order=20
        ]

        # Sort by order
        sorted_steps = sorted(steps, key=lambda s: s.order)

        # Verify order
        assert sorted_steps[0].name == "init_engine"
        assert sorted_steps[1].name == "init_registries"
        assert sorted_steps[2].name == "sync_schema"
        assert sorted_steps[3].name == "init_adapters"

    def test_order_values_are_sequential(self) -> None:
        """Order values should be spaced by 10 for easy insertion."""
        steps = [InitEngine(), InitRegistries(), SyncSchema(), InitAdapters()]
        orders = [s.order for s in steps]

        assert orders == [10, 20, 30, 40]
        # Spacing allows MX packages to insert at 15, 25, 35, etc.


class TestBootstrapImports:
    """Test that bootstrap steps are importable."""

    def test_import_from_bootstrap_module(self) -> None:
        """All steps should be importable from framework_m_standard.bootstrap."""
        from framework_m_standard.bootstrap import (
            InitAdapters,
            InitEngine,
            InitRegistries,
            SyncSchema,
        )

        assert InitEngine is not None
        assert InitRegistries is not None
        assert SyncSchema is not None
        assert InitAdapters is not None

    def test_import_individual_modules(self) -> None:
        """Each step should be importable from its own module."""
        from framework_m_standard.bootstrap.init_adapters import InitAdapters
        from framework_m_standard.bootstrap.init_engine import InitEngine
        from framework_m_standard.bootstrap.init_registries import InitRegistries
        from framework_m_standard.bootstrap.sync_schema import SyncSchema

        assert InitEngine is not None
        assert InitRegistries is not None
        assert SyncSchema is not None
        assert InitAdapters is not None


class TestBootstrapEntryPoints:
    """Test that bootstrap steps are registered via entry points."""

    def test_entry_points_registered(self) -> None:
        """Bootstrap steps should be registered in framework_m.bootstrap group."""
        try:
            from importlib.metadata import entry_points

            # Get all bootstrap entry points
            eps = entry_points(group="framework_m.bootstrap")

            # Convert to dict for easier testing
            ep_dict = {ep.name: ep for ep in eps}

            # Verify all four steps are registered
            assert "init_engine" in ep_dict
            assert "init_registries" in ep_dict
            assert "sync_schema" in ep_dict
            assert "init_adapters" in ep_dict

        except ImportError:
            pytest.skip("importlib.metadata not available")

    def test_entry_points_load_correctly(self) -> None:
        """Entry points should load to correct classes."""
        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="framework_m.bootstrap")
            ep_dict = {ep.name: ep for ep in eps}

            # Load and verify each entry point
            init_engine = ep_dict["init_engine"].load()
            assert init_engine is InitEngine

            init_registries = ep_dict["init_registries"].load()
            assert init_registries is InitRegistries

            sync_schema = ep_dict["sync_schema"].load()
            assert sync_schema is SyncSchema

            init_adapters = ep_dict["init_adapters"].load()
            assert init_adapters is InitAdapters

        except ImportError:
            pytest.skip("importlib.metadata not available")


class TestBootstrapDocumentation:
    """Test that bootstrap steps have proper documentation."""

    def test_init_engine_has_docstring(self) -> None:
        """InitEngine should have class docstring."""
        assert InitEngine.__doc__ is not None
        assert len(InitEngine.__doc__) > 0

    def test_init_registries_has_docstring(self) -> None:
        """InitRegistries should have class docstring."""
        assert InitRegistries.__doc__ is not None
        assert len(InitRegistries.__doc__) > 0

    def test_sync_schema_has_docstring(self) -> None:
        """SyncSchema should have class docstring."""
        assert SyncSchema.__doc__ is not None
        assert len(SyncSchema.__doc__) > 0

    def test_init_adapters_has_docstring(self) -> None:
        """InitAdapters should have class docstring."""
        assert InitAdapters.__doc__ is not None
        assert len(InitAdapters.__doc__) > 0

    def test_run_methods_have_docstrings(self) -> None:
        """All run() methods should have docstrings."""
        steps = [InitEngine(), InitRegistries(), SyncSchema(), InitAdapters()]

        for step in steps:
            assert step.run.__doc__ is not None
            assert len(step.run.__doc__) > 0


class TestBootstrapMXPattern:
    """Test that bootstrap steps support MX pattern override."""

    def test_steps_can_be_overridden_by_name(self) -> None:
        """MX packages can override steps with same name."""

        class CustomInitEngine:
            """Custom MongoDB engine init."""

            name = "init_engine"  # Same name overrides default
            order = 10

            async def run(self, container: object) -> None:
                """Init MongoDB engine."""
                pass

        # Both have same name
        default_step = InitEngine()
        custom_step = CustomInitEngine()

        assert default_step.name == custom_step.name
        # MX package would override via entry point

    def test_steps_can_be_inserted_between_defaults(self) -> None:
        """MX packages can insert steps between defaults."""

        class MongoIndexInit:
            """Create MongoDB indexes."""

            name = "mongo_index_init"
            order = 25  # Between init_registries (20) and sync_schema (30)

            async def run(self, container: object) -> None:
                """Create indexes."""
                pass

        steps = [
            InitEngine(),
            InitRegistries(),
            MongoIndexInit(),  # Custom step
            SyncSchema(),
            InitAdapters(),
        ]

        sorted_steps = sorted(steps, key=lambda s: s.order)

        # Verify custom step is in correct position
        assert sorted_steps[2].name == "mongo_index_init"
        assert sorted_steps[1].order < sorted_steps[2].order < sorted_steps[3].order
