"""Tests for Bootstrap steps: InitEngine and InitRegistries.

Tests cover initialization, configuration handling, and DI container binding.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from framework_m_standard.bootstrap.init_engine import InitEngine
from framework_m_standard.bootstrap.init_registries import InitRegistries

# =============================================================================
# Tests for InitEngine
# =============================================================================


class TestInitEngine:
    """Test InitEngine bootstrap step."""

    def test_name(self) -> None:
        """InitEngine should have name 'init_engine'."""
        step = InitEngine()
        assert step.name == "init_engine"

    def test_order(self) -> None:
        """InitEngine should have order 10."""
        step = InitEngine()
        assert step.order == 10

    @pytest.mark.asyncio
    async def test_run_creates_engine(self) -> None:
        """run() should create SQLAlchemy engine from config."""
        step = InitEngine()

        mock_container = MagicMock()
        mock_container.config.database_url.return_value = "sqlite+aiosqlite:///test.db"
        mock_container.config.get = MagicMock(
            side_effect=lambda key, default=None: default
        )

        # Container has engine attribute
        mock_container.engine = MagicMock()

        with patch("sqlalchemy.ext.asyncio.create_async_engine") as mock_create:
            mock_engine = MagicMock()
            mock_create.return_value = mock_engine

            await step.run(mock_container)

            mock_create.assert_called_once()
            mock_container.engine.override.assert_called_once_with(mock_engine)

    @pytest.mark.asyncio
    async def test_run_raises_without_database_url(self) -> None:
        """run() should raise ValueError if database_url not configured."""
        step = InitEngine()

        mock_container = MagicMock()
        mock_container.config.database_url.return_value = None

        with pytest.raises(ValueError, match="database_url must be configured"):
            await step.run(mock_container)

    @pytest.mark.asyncio
    async def test_run_without_engine_attribute(self) -> None:
        """run() should fallback to config storage when container has no engine attr."""
        step = InitEngine()

        mock_container = MagicMock(spec=[])  # No attributes at all
        mock_container.config = MagicMock()
        mock_container.config.database_url.return_value = "sqlite+aiosqlite:///test.db"
        mock_container.config.get = MagicMock(
            side_effect=lambda key, default=None: default
        )

        with patch("sqlalchemy.ext.asyncio.create_async_engine") as mock_create:
            mock_engine = MagicMock()
            mock_create.return_value = mock_engine

            await step.run(mock_container)

            mock_container.config.engine.from_value.assert_called_once_with(mock_engine)

    def test_protocol_compliance(self) -> None:
        """InitEngine should comply with BootstrapProtocol."""
        from framework_m_core.interfaces.bootstrap import BootstrapProtocol

        step = InitEngine()
        assert isinstance(step, BootstrapProtocol)


# =============================================================================
# Tests for InitRegistries
# =============================================================================


class TestInitRegistries:
    """Test InitRegistries bootstrap step."""

    def test_name(self) -> None:
        """InitRegistries should have name 'init_registries'."""
        step = InitRegistries()
        assert step.name == "init_registries"

    def test_order(self) -> None:
        """InitRegistries should have order 20."""
        step = InitRegistries()
        assert step.order == 20

    @pytest.mark.asyncio
    async def test_run_initializes_registries(self) -> None:
        """run() should initialize MetaRegistry and FieldRegistry."""
        step = InitRegistries()

        mock_container = MagicMock()
        mock_container.config.get = MagicMock(
            side_effect=lambda key, default=None: default
        )

        # Container has registry attrs
        mock_container.meta_registry = MagicMock()
        mock_container.field_registry = MagicMock()

        await step.run(mock_container)

        mock_container.meta_registry.override.assert_called_once()
        mock_container.field_registry.override.assert_called_once()

    @pytest.mark.asyncio
    async def test_run_without_installed_apps(self) -> None:
        """run() should work with empty installed_apps config."""
        step = InitRegistries()

        mock_container = MagicMock()
        mock_container.config.get = MagicMock(return_value=[])
        mock_container.meta_registry = MagicMock()
        mock_container.field_registry = MagicMock()

        await step.run(mock_container)

        # Should still override registries
        mock_container.meta_registry.override.assert_called_once()
        mock_container.field_registry.override.assert_called_once()

    @pytest.mark.asyncio
    async def test_run_with_installed_apps(self) -> None:
        """run() should discover DocTypes from installed apps."""
        step = InitRegistries()

        mock_container = MagicMock()
        mock_container.config.get = MagicMock(return_value=["myapp"])
        mock_container.meta_registry = MagicMock()
        mock_container.field_registry = MagicMock()

        with patch("framework_m_core.registry.MetaRegistry") as MockMetaRegistry:
            mock_instance = MagicMock()
            mock_instance.load_apps.return_value = 5
            MockMetaRegistry.get_instance.return_value = mock_instance

            await step.run(mock_container)

            mock_instance.load_apps.assert_called_once_with(["myapp"])

    @pytest.mark.asyncio
    async def test_run_without_registry_attrs_fallback(self) -> None:
        """run() should fallback to config storage when container lacks registry attrs."""
        step = InitRegistries()

        mock_container = MagicMock(spec=[])
        mock_container.config = MagicMock()
        mock_container.config.get = MagicMock(return_value=[])

        await step.run(mock_container)

        # Should use config fallback
        mock_container.config.meta_registry.from_value.assert_called_once()
        mock_container.config.field_registry.from_value.assert_called_once()

    def test_protocol_compliance(self) -> None:
        """InitRegistries should comply with BootstrapProtocol."""
        from framework_m_core.interfaces.bootstrap import BootstrapProtocol

        step = InitRegistries()
        assert isinstance(step, BootstrapProtocol)
