"""Pytest configuration for Standard package."""

import os
from collections.abc import AsyncGenerator
from typing import Any

import pytest
from framework_m_core import DocType, Field
from framework_m_core.container import Container
from framework_m_core.domain.base_controller import BaseController
from framework_m_core.registry import MetaRegistry
from sqlalchemy import MetaData
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

# =============================================================================
# Sample DocTypes for Testing
# =============================================================================


class TestTodo(DocType):
    """Sample Todo DocType for testing."""

    title: str = Field(description="Task title")
    is_completed: bool = False
    priority: int = 1


class TestTodoController(BaseController[TestTodo]):
    """Sample controller for TestTodo."""

    async def validate(self, context: Any = None) -> None:
        """Validate todo has non-empty title."""
        if not self.doc.title.strip():
            raise ValueError("Title cannot be empty")


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def sample_todo() -> TestTodo:
    """Create a sample TestTodo instance."""
    return TestTodo(
        title="Test Task",
        is_completed=False,
        priority=1,
        name="TODO-001",
        owner="test@example.com",
    )


@pytest.fixture
def sample_todo_controller(sample_todo: TestTodo) -> TestTodoController:
    """Create a sample TestTodoController instance."""
    return TestTodoController(sample_todo)


@pytest.fixture
def container() -> Container:
    """Create a fresh Container instance for testing."""
    return Container()


@pytest.fixture
def clean_registry() -> MetaRegistry:
    """Get a clean MetaRegistry instance for testing."""
    registry = MetaRegistry()
    registry.clear()
    return registry


# =============================================================================
# Database Fixtures
# =============================================================================


@pytest.fixture(scope="session")
def database_url() -> str:
    """Database URL for testing."""
    return os.getenv(
        "TEST_DATABASE_URL",
        "sqlite+aiosqlite:///:memory:",
    )


@pytest.fixture
async def test_engine(database_url: str) -> AsyncGenerator[AsyncEngine, None]:
    """Create a test database engine."""
    engine = create_async_engine(database_url, echo=False, pool_pre_ping=True)

    # Enable foreign key constraints for SQLite only
    if "sqlite" in database_url:
        from sqlalchemy import event

        @event.listens_for(engine.sync_engine, "connect")
        def set_sqlite_pragma(dbapi_conn, connection_record):
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

    yield engine
    await engine.dispose()


@pytest.fixture
async def db_session(test_engine: AsyncEngine) -> AsyncGenerator[AsyncSession, None]:
    """Create a test database session with automatic rollback."""
    async_session_maker = async_sessionmaker(
        test_engine, class_=AsyncSession, expire_on_commit=False
    )

    async with async_session_maker() as session, session.begin():
        yield session
        await session.rollback()


@pytest.fixture
async def clean_tables(
    test_engine: AsyncEngine,
) -> AsyncGenerator[MetaData, None]:
    """Create a clean metadata and drop all tables after test."""
    from framework_m_standard.adapters.db.table_registry import TableRegistry

    table_registry = TableRegistry()
    table_registry.reset()

    metadata = MetaData()
    yield metadata

    async with test_engine.begin() as conn:
        await conn.run_sync(metadata.drop_all)
