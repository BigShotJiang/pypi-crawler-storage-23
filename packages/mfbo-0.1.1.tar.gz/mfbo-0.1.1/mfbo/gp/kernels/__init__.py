from .kriging import Kriging

__all__ = ["Kriging"]