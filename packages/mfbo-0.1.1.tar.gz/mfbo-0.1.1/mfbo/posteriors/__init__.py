from .diag_normal import MFDiagNormalPosterior, samples_to_mf_posterior

__all__ = [
    "MFDiagNormalPosterior",
    "samples_to_mf_posterior",
]