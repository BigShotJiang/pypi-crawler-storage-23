"""This module calculates jointly credible differences
between elements of random vectors, represented by
sample vectors drawn from a multivariate distribution.

Input and output data are Pandas DataFrame or Series objects.
Tested with Pandas v. 2.3.0

Method reference:
A. Leijon, G. E. Henter, and M. Dahlquist.
Bayesian analysis of phoneme confusion matrices.
IEEE Transactions on Audio, Speech, and Language Processing 24(3):469–482, 2016,
App. C.

*** Version History:
* Version 1.3.2:
2026-02-22, cred_corr: avoid pandas.FutureWarning about groupby with length-one level
2026-01-12, cred_diff: avoid pandas.FutureWarning about groupby with length-one level
2025-12-26, corrected error with index sorting: force case_axis as columns, use groupby for separation
2025-10-15, improved speed: pandas data -> numpy, wrap to functions in module credibility

* Version 1.3.1:
2025-03-09, minor changes in cred_diff, to avoid Pandas.FutureWarning

* Version 1.3.0:
2023-04-16, New module adapted for Pandas data format.
            Otherwise, same functionality as original module credibility.py
"""
# *** allow user-supplied np.random.Generator for cred_group_diff? ***

import numpy as np
import logging
from samppy import credibility

logger = logging.getLogger(__name__)

RNG = np.random.default_rng()


# ----------------------------------------------------------
def cred_diff(df, diff_axis, case_axis=None,
              p_lim=0.6, threshold=0.):
    """Find a sequence of pairs of jointly credible differences between
    random-vector elements in one or more case conditions.
    Distributions are represented by an array of RELATED SAMPLES.

    Elements are compared between pairs of categories in diff_axis.
    Each vector sample may include different cases,
    represented by one or more dimensions in the case_axis.
    Any row index axis not included in case_axis is handled as i.i.d. samples.

    :param df: a pd.Series or pd.DataFrame instance
        NOTE: Samples are assumed JOINTLY sampled for all vector elements in all case variants.
    :param diff_axis: name or tuple of names of index axes for x values to compare.
    :param case_axis: (optional) name or tuple of names for index axes
        with case categories for which x values in diff_axis are compared separately.
    :param p_lim: (optional) scalar minimum joint credibility for difference to be included
    :param threshold: (optional) scalar minimum absolute difference between elements to be considered.
    :return: list of tuples (((i, j), *c), p),
        meaning that
        prob{ X_i - X_j > threshold in case==*c } AND similar for all preceding tuples } = p,
        where (i, j) are column/index label(s) in x,
        c includes zero, one, or more labels in given case index or indices.
        The approximate probability is estimated from the relative frequency of samples,
        using a Jeffreys prior pseudo-count = 0.5.

    As each successive row includes one new pair in the jointly credible set,
    the joint probability for the sequence of pairs DECREASES with each new pair.
    Therefore, the result rows are automatically ordered
    with strictly non-increasing values of p.
    """
    if case_axis is None:
        case_axis = ()
    if type(case_axis) is not tuple:
        case_axis = (case_axis,)
    if type(diff_axis) is not tuple:
        diff_axis = (diff_axis,)
    df = _prepare_case_columns(df, case_axis)
    if len(case_axis) == 0:
        case_labels = []
    else: # df is pd.DataFrame with df.columns.name(s) == case_axis
        case_labels = df.columns.values
    diff_level = list(diff_axis) if len(diff_axis) > 1 else diff_axis[0]  # avoid pd.FutureWarning
    d_df = {d_key: g_df.to_numpy()
            for (d_key, g_df) in df.groupby(level=diff_level)}
    diff_labels = list(d_df.keys())
    try:
        x = np.stack(list(d_df.values()), axis=0)
    except Exception as e:  # cannot stack! perhaps unequal array shapes ?
        raise RuntimeError(f'cred_diff: Cannot group data by {diff_axis}: ' + str(e))
    if len(case_axis) == 0:  # x.ndim == 2
        res = credibility.cred_diff(x, diff_axis=0, sample_axis=1,
                                    p_lim=p_lim, threshold=threshold)
    else:   # x.ndim == 3
        res = credibility.cred_diff(x, diff_axis=0, sample_axis=1, case_axis=2,
                                    p_lim=p_lim, threshold=threshold)
    return [(_decode_diff(d, diff_labels, case_labels), p)
            for (d, p) in res]


def _prepare_case_columns(df, case_axis):
    """Stack / unstack if necessary to place
    ONLY case_axis as columns levels, and all other levels in the index
    :param df: a pd.DataFrame or pd.Series instance
    :param case_axis: tuple with labels in either df.index.names or df.columns.names
    :return: df with columns corresponding ONLY to case_axis
    """
    if len(case_axis) == 0:
        return df
    try:
        stack_levels = [n for n in df.columns.names if n not in case_axis]
        # columns has names property even if only a single Index with ONE name
    except AttributeError:  # df has no columns, is already a Series
        stack_levels = []
    if len(stack_levels) > 0:
        df = df.stack(level=stack_levels, future_stack=True)
    unstack_levels = [n for n in df.index.names if n in case_axis]
    if len(unstack_levels) > 0:
        df = df.unstack(level=unstack_levels)  # sort=False -> error ?
    # df.columns now have columns with ONLY levels named in case_axis
    # but possibly in incorrect level order
    if len(case_axis) > 1:
         df = df.reorder_levels(case_axis, axis='columns')
    return df


# ---------------------------------------------------------------
def cred_group_diff(x_groups, group_axis, case_axis=None,
                    p_lim=0.6, threshold=0., rng=RNG):
    """Find pairs of jointly credible differences between
    groups with independent scalar or vector-valued random variables,
    represented by UNRELATED sets of samples for each group.

    :param x_groups: dict with elements (group_cat: group_data)
        where group_cat is a label or tuple of labels identifying the group,
        and group_data is a pd.Series or pd.DataFrame instance,
        with each row containing a sample scalar or array,
        with related samples for different case categories.
        group_data must have same structure for all groups.
        Sample array elements are treated as INDEPENDENT across groups,
        but assumed jointly sampled across case categories within each group.
        Thus, the order of samples is UNRELATED across groups,
        but samples are assumed jointly RELATED across case categories within each group.
        ***** Allow x_groups as DataFrame with group labels in index or in column data ? ***
    :param group_axis: name or tuple of names for categories in x_groups.keys()
        len(group_axis) must be same as length of all x_groups.keys()
    :param case_axis: (optional) secondary name or names for index of cases within which differences are considered
    :param p_lim: (optional) scalar minimum joint credibility for difference to be included
    :param threshold: (optional) scalar minimum difference between elements to be considered.
    :param rng: (optional) send to credibility.cred_group_diff ! *******
    :return: list of tuples (((i, j), *c), p),
        meaning that
        prob{ X_i - X_j > threshold in case=*c } AND similar for all preceding tuples } = p,
        where (i, j) are index label(s) in x,
        c includes zero, one, or more labels in given case index or indices.

    Method: Data for each x_group are re-sampled for equal number of samples,
    then handled as usual by cred_diff function.
    Arne Leijon, 2025-12-26
    """
    if type(group_axis) is not tuple:
        group_axis = (group_axis,)
        # ******* not needed ? Keep it, might allow x_groups as pd.DataFrame ? *******
    if case_axis is None:
        case_axis = ()
    if type(case_axis) is not tuple:
        case_axis = (case_axis,)
    group_labels = list(x_groups.keys())
    x_groups = {g_key: _prepare_case_columns(df, case_axis)
                for (g_key, df) in x_groups.items()}  # -> list ?
    if len(case_axis) == 0:  # x_groups[...] is 1D pd.Series
        case_labels = []
    else:  # x_groups[...] is 2D pd.DataFrane
        case_labels = x_groups[group_labels[0]].columns.values
    x_groups = [df.to_numpy() for df in x_groups.values()]
    if len(case_axis) == 0:
        res = credibility.cred_group_diff(x_groups,
                                          case_axis=None, sample_axis=0,
                                          p_lim=p_lim, threshold=threshold)
    else:
        res = credibility.cred_group_diff(x_groups,
                                          case_axis=1, sample_axis=0,
                                          p_lim=p_lim, threshold=threshold)
    return [(_decode_diff(d, group_labels, case_labels), p)
            for (d, p) in res]


# -------------------------------------------------------------------
def cred_corr(df, corr_axis, vector_axis=(), p_lim=0.6):
    """Find set of jointly credible correlations between random vectors or scalars,
    represented by samples from joint distributions.
    :param df: a pd.DataFrame or pd.Series instance,
        with rows containing i.i.d. samples from jointly distributed random variables.
    :param corr_axis: label(s) of axis representing separate random variables / vectors,
        for which credible correlations are to be found.
        May be axis in either columns or index of x.
    :param vector_axis: (optional) label(s) of axis with related vector elements in each sample.
        Row index axis NOT named in corr_axis or vector_axis are used as samples.
    :param p_lim: (optional) scalar minimum joint credibility for difference to be included
    :return: list of tuple((i, j), p, median_corr), where
        (i, j) is the pair of labels along corr_axis for the credibly correlated random variables
        p = the JOINT credibility of this and all previous tuples in the list,
        median_c = the median conditional correlation coefficient, given that
            all previous correlations in the list are credibly non-zero.

    The correlation (cosine) values are calculated WITHOUT subtraction of the mean,
    i.e., vectors are treated as non-normalized directions in multidimensional space.
    For random scalars, each correlation sample is the product, normalized by sample std.deviation.
    For random vectors, each correlation sample is the cosine angle between elements in each pair of vector samples,
        normalized by root mean square across all samples,
        with vector elements stored along vector_axis of x.

    Arne Leijon, 2025-12-26
    """
    def _numpy_to_pandas(res, labels):
        """Convert result from credibility module back to pandas axes indexing labels
        :param res: list of tuples ((i, j), p, median_corr), from credibility.cred_corr
        :param labels: list of labels corresponding to indices i or j in res
        :return: list of tuples ((labels[i], labels[j]), p, median_corr)
            converted to axis labels pandas representation
        """
        return [((labels[i], labels[j]), p, m_corr)
                for ((i, j), p, m_corr) in res]
    # -----------------------------------------------
    if type(corr_axis) is not tuple:
        corr_axis = (corr_axis,)
    if type(vector_axis) is not tuple:
        vector_axis = (vector_axis,)
    x = _prepare_case_columns(df, vector_axis)
    # x is pd.DataFrame with vector elements in columns, or Series if vector_axis is (),
    # index = MultiIndex with levels corr_axis and anything else regarded as samples
    corr_level = list(corr_axis) if len(corr_axis) > 1 else corr_axis[0]  # avoid pd.FutureWarning
    x = {g_key: df
         for (g_key, df) in x.groupby(level=corr_level)}
    corr_labels = list(x.keys())
    try:
        x = np.stack(list(x.values()), axis=0)
    except Exception as e:  # cannot stack! perhaps unequal array shapes ?
        raise RuntimeError(f'cred_corr: Cannot group data by {corr_axis}: ' + str(e))
    if len(vector_axis) == 0:  # each x[i] is 1D array
        res = credibility.cred_corr(x, corr_axis=0, sample_axis=1, p_lim=p_lim)
    else:   # each x[i] is 2D array
        res = credibility.cred_corr(x, corr_axis=0, sample_axis=1, vector_axis=2, p_lim=p_lim)
    return _numpy_to_pandas(res,corr_labels)


# ----------------------------------- module help functions:

def _decode_diff(d, diff_labels, case_labels):
    """Encode ONE difference result from credibility module
    :param d: tuple either (i,j) or (i, j, c), where
            i, j are scalar indices into diff_labels
            c is scalar index into case_labels, if any
    :param diff_labels: sequence of string or tuple of string labels
    :param case_labels: sequence of string or tuple of string labels
    :return: tuple ((d_i, d_j),) OR ((d_i, d_j), c0, c1, ...) for backward compatibility
            ***** future: simply return (diff_labels[i], diff_labels[j], case_labels[c])
            ***** where each element is a tuple if more than one category
    """
    if len(d) == 2:
        (i, j) = d
        return ((diff_labels[i], diff_labels[j]),)
    else:
        (i, j, c) = d
        c_label = case_labels[c]
        if type(c_label) is tuple:
            return ((diff_labels[i], diff_labels[j]), *c_label)  # *** for compat. with v. 1.3.1 ***
        else:
            return ((diff_labels[i], diff_labels[j]), c_label)


# ----------------------------------------------------------- TEST:
if __name__ == '__main__':
    from scipy.stats import norm
    from time import process_time
    from itertools import combinations  # , product, chain
    import pandas as pd

    print('*** Testing cred_diff, cred_group_diff, cred_corr')
    n_samples = 1000
    mu = [[0., 0.5, 1.],
          [0., -1., 0.5],
          [0., -1., -2.]]
    n_mu = 3
    len_x = 3
    x_labels = [f'x{len_x - i}' for i in range(len_x)]  # try reversed order
    case_labels = [c for c in 'ABCDEF'[:n_mu]]  # try reversed order
    x = np.array([norm.rvs(loc=m, size=(n_samples, len_x))
                  for m in mu])
    print('rvs x[case, diff].mean =\n', np.mean(x, axis=1))
    x2 = x.reshape((-1, len_x))
    ind = pd.MultiIndex.from_product([case_labels, range(n_samples)],
                                     names=['Case', '_sample'])
    x = pd.DataFrame(x2, index=ind, columns=x_labels)
    x.columns.set_names('x_element', inplace=True)
    # print('x = \n', x)
    print('x_df.means = ')
    for (c, d) in x.groupby('Case'):
        print(c, d.mean())

    print('\nTest cred_diff:')
    case_axis= 'Case'
    diff_axis= 'x_element'

    t0 = process_time()
    d = cred_diff(x, diff_axis=diff_axis, case_axis=case_axis)
    t1 = process_time()
    print(f'cred_diff_new process_time= {t1-t0:.5g}')
    print('cred_diff_new = ', d)
    # t0 = process_time()
    # d_old = cred_diff_old(x, diff_axis=diff_axis, case_axis=case_axis)
    # t1 = process_time()
    # print(f'cred_diff_old process_time= {t1-t0:.5g}')
    # print('cred_diff_old = ', d_old)

    mu_df = pd.DataFrame(mu,
                         index=pd.Index(case_labels, name='Case'),
                         columns=x_labels)
    true_prob_diff = [norm.cdf(mu_df.loc[c, i] - mu_df.loc[c, j], scale=np.sqrt(2))
                      for (((i,j),c), _) in d]
    # print('true marg. prob. ', true_prob_diff)
    print('true joint prob. ', np.cumprod(true_prob_diff))
    print("""NOTE: the 3rd cred_diff result shows slightly over-estimated credibility
    probably because the largest value is selected in each step,
    and the test data includes three different cases with equal true differences
    """)

    print('\nTest cred_group_diff:')
    n_group_samples = [100, 500, 1000]
    x_groups = {g: pd.DataFrame(norm.rvs(loc=m, size=(ns, len_x)),
                                columns=pd.Index(x_labels, name='X'))
                for (g, m, ns) in zip(case_labels, mu, n_group_samples)}

    # d_old = cred_group_diff_old(x_groups, group_axis='Group', case_axis='X')
    # print('cred_group_diff_old = ', d_old)
    d = cred_group_diff(x_groups, group_axis='Group', case_axis='X')
    print('cred_group_diff_new = ', d)
    mu_df = pd.DataFrame(mu,
                         index=pd.Index(case_labels, name='Group'),
                         columns=x_labels)
    true_prob_diff = [norm.cdf(mu_df.loc[i, c] - mu_df.loc[j, c], scale=np.sqrt(2))
                      for (((i, j), c), _) in d]
    print('true joint prob. = ', np.cumprod(true_prob_diff))

    # -----------------------------------------
    print('\nTest cred_corr:')
    xt = x.stack('x_element')
    xt = xt.unstack('Case')
    # d_old = cred_corr_old(xt, corr_axis='Case', vector_axis='x_element')
    # print('cred_corr_old ', d_old)
    d = cred_corr(xt, corr_axis='Case', vector_axis='x_element')
    print('cred_corr_new ', d)

    cosine = np.array([np.sum(x_i * x_j)
                       / np.sqrt((np.sum(x_i ** 2) + len_x) *
                                 (np.sum(x_j ** 2) + len_x))
                       for (x_i, x_j) in combinations(np.array(mu), 2)])
    print('cosine = ', cosine)
