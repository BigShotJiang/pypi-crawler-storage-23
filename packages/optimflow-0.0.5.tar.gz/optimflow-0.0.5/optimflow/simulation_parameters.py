import logging
import json
from pathlib import Path
from copy import deepcopy

import param

from optimflow.optimisation_parameters import OptimParams
from optimflow.utils import dump_json, load_json, Foldername


class SimulationParams(param.Parameterized):
    @staticmethod
    def _paths_to_serializable(obj):
        """Return a JSON-serializable copy of obj with Path replaced by absolute path str."""
        if isinstance(obj, Path):
            return str(obj.resolve())
        if isinstance(obj, dict):
            return {
                k: SimulationParams._paths_to_serializable(v) for k, v in obj.items()
            }
        if isinstance(obj, list):
            return [SimulationParams._paths_to_serializable(v) for v in obj]
        return obj

    def to_dict(self) -> dict:
        d = {name: getattr(self, name) for name in self.param}
        return self._paths_to_serializable(d)

    @classmethod
    def load_from(cls, dname):
        data = load_json(dname / "params.json")
        allowed = {k: v for k, v in data.items() if k in cls.param}
        others = {k: v for k, v in data.items() if k not in cls.param}
        p = cls(**allowed)
        for k, v in others.items():
            p.param.add_parameter(k, param.Number(v))
        return p

    def save(self, data: dict = None):
        dump_json(self.out_dir / "params.json", self.to_dict())
        if data is not None:
            dump_json(self.out_dir / "infos.json", data)

    def copy(self):
        return deepcopy(self)

    def save_with(self, out: str, optim_params: OptimParams):
        self.out_dir = Path(out)
        for k, v in optim_params.to_dict().items():
            self.param.add_parameter(k, param.Number(v))
        self.save()


log = logging.getLogger(__name__)
