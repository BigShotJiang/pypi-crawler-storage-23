# Changelog

## [1.3] (since 1.2)

### Added

- **`sample` subcommand**: Random sampling of rows — without replacement (default) or with replacement (`-r`). Optional weight column (`-W`), seed for reproducibility (`--seed`).
- **`--head` / `--tail`**: Limit output to the first or last N rows (N can be `inf`).
- **Output column selection**: `-O` / `--output-columns` to select, rename (`newname=oldname`), or exclude (`-col`) columns on output; same syntax as in input file specs.
- **`--rowvar`**: In apply, filter, and aggregate, use a dict variable (e.g. `row`) to refer to columns in formulas, so column names with spaces or special characters work (e.g. `row['unit price']`).
- **`--python-path` / `-p`**: Append directories to Python path for `-b` (before) scripts (e.g. to import local modules).
- **LaTeX output**: Pretty-print as LaTeX tabular (booktabs: `\toprule`, `\midrule`, `\bottomrule`) via output format `latex` / `tex`.
- **Reproducible random sort**: `--seed` for the sort subcommand when using `-R` (shuffle).
- **Less integration**: Output to a tty can be piped through `less`; `--less` / `--no-less` / `-N` control it; `--keep-long-lines` keeps long lines (e.g. `less -S`); `--textwidth` and `--infer-lines` tune pretty-print width and type inference.
- **Man pages**: Generated from CLI parsers (argparse-manpage) and installed with the package.
- **Subcommand aliases**: Short names for subcommands — `agg` (aggregate), `ap` (apply), `c` (cat), `fi` (filter), `jo` (join), `sa` (sample), `so` (sort).

### Changed

- **Output format**: Single option `-F` / `--output-format` with choices `auto` (default), `csv`, `terminal`, `ascii`, `unicode`, `markdown` (or `md`), `latex` (or `tex`). Replaces the previous separate pretty-print flags; `auto` uses terminal format when stdout is a tty, else CSV.
- **Pretty-print implementation**: Table rendering moved to `_pretty_table.py` (streaming-friendly, configurable width); dependency `prettytable` removed. New options `--textwidth` and `--infer-lines` for width and numeric-column inference.
- **Dependencies**: `numpy` and `more-itertools` are now required; `lazy-loader` added; `prettytable` removed.

---

## [1.2] (since 1.1)

### Added

- **Pretty-print output**: Table-style output via `-P` (Unicode), `-T` (terminal with colors), `-A` (ASCII), `-M` (Markdown). Auto-enabled when stdout is a tty; use `-W` for raw CSV, `-D` for dark terminal theme. Dependencies: `prettytable`, `colorama`.
- **UTF-8 BOM**: Input files with a UTF-8 BOM are handled correctly when using the default encoding (`utf8`): the BOM is stripped automatically on read.

---

## [1.1] (since 1.0)

### Changed

- **Build and packaging**: Build system migrated from `setup.py` to `pyproject.toml` (PEP 517). Package version is now generated from Git via setuptools-scm (e.g. tagged releases and dev versions).

### Fixed

- **Version reporting**: `--version` now prints the actual package version instead of being suppressed.

---

## [1.0] (since 0.8)

### Added

- **Configurable encoding**: options `-c` / `--inputenc` and `-C` / `--outputenc` (default: `utf8`) to specify the character encoding for input and output files. Applied to all commands that read or write CSV (aggregate, sort, filter, apply, join, cat). File writes now use the requested encoding explicitly; file reads do as well (stdin/stdout unchanged).
