# Copyright 2019-2026, Jean-Benoist Leger <jb@leger.tf>
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import csv
import sys
import typing
from typing import Iterator, Any, Callable, Literal, Sequence, overload

import lazy_loader  # type: ignore[reportMissingTypeStubs]

from csvspoon._pretty_table import (
    md_pretty_table,
    terminal_pretty_table,
    text_pretty_table,
)
from csvspoon._tools import Iterable_with_first

# Lazy-loaded modules below: any type annotation referring to them must use
# string form (e.g. "np.random.Generator") to avoid loading the module at import.
if typing.TYPE_CHECKING:
    import collections
    import hashlib
    import heapq
    import itertools
    import math
    import more_itertools
    import numpy as np
    import re
    import shutil
else:
    np = lazy_loader.load("numpy")  # type: ignore[reportUnreachable]
    hashlib = lazy_loader.load("hashlib")  # type: ignore[reportUnreachable]
    heapq = lazy_loader.load("heapq")  # type: ignore[reportUnreachable]
    itertools = lazy_loader.load("itertools")  # type: ignore[reportUnreachable]
    collections = lazy_loader.load("collections")  # type: ignore[reportUnreachable]
    math = lazy_loader.load("math")  # type: ignore[reportUnreachable]
    re = lazy_loader.load("re")  # type: ignore[reportUnreachable]
    shutil = lazy_loader.load("shutil")  # type: ignore[reportUnreachable]
    more_itertools = lazy_loader.load("more_itertools")  # type: ignore[reportUnreachable]


class PRNG:
    """Pseudo Random Number Generator"""

    _rng: "np.random.Generator"

    def __init__(self, seed: str | None | Sequence[int]):
        if seed is not None and isinstance(seed, str):
            seed = list(bytearray(hashlib.sha256(seed.encode("utf8")).digest()))
        self._rng = np.random.default_rng(seed)

    def uniform(self) -> float:
        "Uniform RNG"
        return self._rng.uniform()

    def gumbel(self) -> float:
        "Gumbel RNG"
        return -np.log(-np.log(self._rng.uniform()))


class SampledRow(typing.NamedTuple):
    """Class to represent a row and a associated criterion for the sampler"""

    criterion: float
    row: dict[str, str]

    def __lt__(self, oth: object) -> bool:
        if not isinstance(oth, SampledRow):
            return NotImplemented
        return self.criterion < oth.criterion

    def __gt__(self, oth: object) -> bool:
        if not isinstance(oth, SampledRow):
            return NotImplemented
        return self.criterion > oth.criterion


class SampledRowBuilder:
    """Expose a builder of SampledRow with fixed parameters"""

    _weight: str | None
    _revert: bool = False
    _prng: PRNG

    def __init__(
        self, seed: str | None = None, weight: str | None = None, revert: bool = False
    ):
        self._prng = PRNG(seed)
        self._weight = weight
        self._revert = revert

    def get_sampled_row(self, row: dict[str, str], repeat: int = 1) -> list[SampledRow]:
        "Build a SampledRow from a row"
        if self._weight is not None:
            strweight = row[self._weight]
            try:
                weight = float(strweight)
            except ValueError:
                weight = None
            if weight is not None and weight > 0:
                rgv_translate: float = np.log(weight)
            else:
                rgv_translate = -np.inf
        else:
            rgv_translate = 0.0
        mult = -1.0 if self._revert else 1.0
        return [
            SampledRow(mult * (self._prng.gumbel() + rgv_translate), row)
            for _ in range(repeat)
        ]


class CsvFileSpec:
    """A class to parse and store CSV file specifications.

    The specification format is: filename[:column1,column2,...] where the columns part is optional.

    Args:
        filespec (str): The file specification string in the format "filename[:columns]"

    Attributes:
        _filename (str): The CSV filename
        _columns (tuple): The column names to extract, or None if all columns should be used
    """

    _filename: str
    _columns: tuple[str, ...] | None

    def __init__(self, filespec: str) -> None:
        regex = re.compile(r"^(?P<filename>[^:]+)(?::(?P<columns>.+))?$")
        match = regex.match(filespec)
        if not match:
            raise TypeError(
                f"{filespec!r} can not be interpreted as {self.__class__.__name__}"
            )
        self._filename = match["filename"]
        if match["columns"] is not None:
            self._columns = tuple(match["columns"].split(","))
        else:
            self._columns = None

    @property
    def filename(self) -> str:
        """str: Get the CSV filename"""
        return self._filename

    @property
    def columns(self) -> tuple[str, ...] | None:
        """tuple: Get the column names, or None if all columns should be used"""
        return self._columns


class CsvColumnsNotFound(Exception):
    """Exception raised when specified columns are not found in the CSV file."""


class CsvInvalidColumnSpec(Exception):
    """Exception raised when column specification is invalid."""


class ColFormat:
    """A class to handle column formatting.

    Args:
        colfmt (str): Format specification in the form "column:format" where format is a
            Python format string

    Attributes:
        _convert (callable): Function to convert the column value (int, float or identity)
        _colname (str): Name of the column to format
        _fmt (str): Python format string to apply
    """

    _convert: Callable[[str], int | float | str]
    _colname: str
    _fmt: str

    def __init__(
        self,
        colfmt: str = "",
        *,
        _data: tuple[Callable[[str], int | float | str], str, str] | None = None
    ) -> None:
        if _data is not None:
            self._convert, self._colname, self._fmt = _data
            return

        if colfmt.count(":") != 1:
            raise TypeError(f"Not a col format for {self.__class__.__name__}")
        colname, fmt = colfmt.split(":")
        if fmt and fmt[-1] in "bcdoxXn":
            self._convert = int
        elif fmt and fmt[-1] in "eEfFgGn%":
            self._convert = float
        else:
            self._convert = lambda x: x
        self._colname = colname
        self._fmt = "{:%s}" % fmt

    def format(self, row: dict[str, Any]) -> None:
        """Format a column value in the given row.

        Args:
            row (dict): Row containing the column to format

        Raises:
            CsvColumnsNotFound: If the column is not found in the row
        """
        if self._colname not in row:
            raise CsvColumnsNotFound(f"Column {self._colname} is not found.")
        if row[self._colname] is not None:
            row[self._colname] = self._fmt.format(self._convert(row[self._colname]))

    @property
    def colname(self) -> str:
        """str: Get the column name"""
        return self._colname

    @property
    def convert(self) -> Callable[[str], int | float | str]:
        """Callable: Get the conversion function for the column value"""
        return self._convert

    def apply_mapping(self, mapping: dict[str, str]) -> list["ColFormat"]:
        """Adapt this format to a column remapping (e.g. after output column selection).

        When columns are renamed or selected (e.g. via ContentCsv.remap_columns),
        the mapping gives new_col_name -> old_col_name (output -> source). This
        method returns a list of ColFormat instances that apply the same format
        (convert and fmt) to each output column that originally corresponded to
        this format's column (self._colname). If the column was dropped by the
        remap, the list is empty.

        Args:
            mapping: Dict from output column name to source column name (as
                returned by ContentCsv.remap_columns(..., return_mapping=True)).

        Returns:
            List of ColFormat with the same format applied to the remapped
            column names (one per output column whose source is self._colname).
        """
        return [
            ColFormat(_data=(self._convert, k, self._fmt))
            for k, v in mapping.items()
            if v == self._colname
        ]


class NewColFormat(ColFormat):
    """A class to handle new column formatting, extending ColFormat.

    Allows format specification without requiring a format string.
    """

    def __init__(self, colfmt: str) -> None:
        if ":" not in colfmt:
            colfmt += ":"
        ColFormat.__init__(self, colfmt)

    @property
    def colname(self) -> str:
        """str: Get the column name"""
        return self._colname


class ColType:
    """A class to handle column type conversion.

    Args:
        coltype (str): Type specification in the form "column:type"

    Attributes:
        _colname (str): Name of the column
        _typename (str): Name of the type to convert to
        _type: The actual type after building the type from typename
    """

    _colname: str
    _typename: str
    _type: Any

    def __init__(self, coltype: str) -> None:
        if coltype.count(":") != 1:
            raise TypeError(f"Not a col type for {self.__class__.__name__}")
        colname, typename = coltype.split(":")
        self._colname = colname
        self._typename = typename

    def build_type(self, glob: dict[str, Any]) -> None:
        """Build the actual type from the type name.

        Args:
            glob (dict): Global namespace to evaluate the type name in
        """
        self._type = eval(self._typename, glob)

    @property
    def get_coltype(self) -> tuple[str, Any]:
        """tuple: Get the column name and type as a tuple"""
        return (self._colname, self._type)


def _cast_pseudo_numerical(value: str) -> tuple[float, str]:
    """Try to extract a numerical value from the start of a string.

    Args:
        value (str): String to parse

    Returns:
        tuple: (numerical_value, remaining_string) or (inf, original_string) if no number found
    """
    for i in range(len(value), 0, -1):
        substr1, substr2 = value[0:i], value[i:]
        try:
            x = float(substr1)
        except ValueError:
            continue
        return (x, substr2)
    return (math.inf, value)


class NotValidContent(Exception):
    """Raised when CSV/content is not valid for the requested operation."""


def _cat_rowgen(
    gen1: Iterator[dict[str, str]],
    gen2: Iterator[dict[str, str]],
    only1: set[str],
    only2: set[str],
) -> Iterator[dict[str, str]]:
    for row in gen1:
        row.update({k: "" for k in only2})
        yield row
    for row in gen2:
        row.update({k: "" for k in only1})
        yield row


def _join_rowgen(
    gen1: Iterator[dict[str, str]],
    dict_of_oth: dict[tuple[str, ...], list[dict[str, str]]],
    common: set[str],
    left_added_keys: list[str],
    added_keys: list[str],
    left: bool,
    right: bool,
) -> Iterator[dict[str, str]]:
    not_viewed_oth: set[tuple[str, ...]] = set(dict_of_oth.keys()) if right else set()
    for l1 in gen1:
        value = tuple(l1[k] for k in common)
        if value in dict_of_oth:
            if right and value in not_viewed_oth:
                not_viewed_oth.remove(value)
            for l2 in dict_of_oth[value]:
                new_line = l1.copy()
                new_line.update(l2)
                yield new_line
        else:
            if left:
                new_line = dict(l1)
                new_line.update({k: "" for k in added_keys})
                yield new_line
    if right:
        for value in not_viewed_oth:
            for l2 in dict_of_oth[value]:
                new_line = dict(l2)
                new_line.update({k: "" for k in left_added_keys})
                yield new_line


def _aggregate_row_gen(
    new_fieldnames: list[str],
    stored_by_key_data_column: dict[tuple[Any, ...], dict[str, list[Any]]],
    aggregation: list[tuple[str, Callable[[dict[str, list[Any]]], Any]]],
) -> Iterator[dict[str, Any]]:
    fields_aggregation = set(colname for colname, _ in aggregation)
    for store in stored_by_key_data_column.values():
        row = {
            colname: store[colname][0]
            for colname in new_fieldnames
            if colname not in fields_aggregation
        }
        row.update({colname: func(store) for colname, func in aggregation})
        yield row


class ContentCsv:
    """Main class to handle CSV content with various operations.

    Args:
        filespec (CsvFileSpec, optional): Specification of the CSV file to read
        delim (str, optional): CSV delimiter character. Defaults to ","
        encoding (str, optional): File encoding
        _fieldnames (list, optional): Column names for internal use
        _rows (iterator, optional): Row data for internal use

    Attributes:
        _applied (list): List of column transformations to apply
        _types (dict): Column type conversions
        _new_fieldnames (list): Names of newly added columns
        _filters (list): Row filters to apply
        _fieldnames (list): Original column names
        _rows (iterator): Row data
        _valid (bool): Whether the content is still valid
    """

    _applied: list[tuple[str, Callable[[dict[str, Any]], Any]]]
    _types: dict[str, Callable[[str], Any]]
    _new_fieldnames: list[str]
    _filters: list[Callable[[dict[str, Any]], bool]]
    _fieldnames: Sequence[str]
    _rows: Iterator[dict[str, str]]
    _valid: bool

    def __init__(
        self,
        *,
        filespec: CsvFileSpec | None = None,
        delim: str = ",",
        encoding: str | None = None,
        _fieldnames: Sequence[str] | None = None,
        _rows: Iterator[dict[str, str]] | None = None
    ) -> None:
        self._applied = []
        self._types = {}
        self._new_fieldnames = []
        self._filters = []
        if filespec is not None:
            if filespec.columns is None:
                dialect = csv.excel
                dialect.delimiter = delim
                if filespec.filename == "-":
                    f = sys.stdin
                else:
                    actual_encoding = (
                        "utf-8-sig" if encoding in (None, "utf8", "utf-8") else encoding
                    )
                    f = open(  # pylint: disable=consider-using-with
                        filespec.filename, encoding=actual_encoding
                    )
                reader = csv.DictReader(f, dialect=dialect)
                self._fieldnames = list(reader.fieldnames or [])
                self._rows = (dict(row) for row in reader)
                self._valid = True
            else:
                filespec_base = CsvFileSpec(filespec.filename)
                base = ContentCsv(
                    filespec=filespec_base, delim=delim, encoding=encoding
                )
                remapped = base.remap_columns(filespec.columns)
                self._applied = remapped._applied
                self._types = remapped._types
                self._new_fieldnames = remapped._new_fieldnames
                self._filters = remapped._filters
                self._fieldnames = remapped._fieldnames
                self._rows = remapped._rows
                self._valid = remapped._valid
        else:
            if _fieldnames is None or _rows is None:
                raise TypeError(f"{self.__class__.__name__} need filespec")
            # for internal use only
            self._rows = _rows
            self._fieldnames = _fieldnames
            self._valid = True

    @property
    def fieldnames(self) -> tuple[str, ...]:
        """tuple: Get all field names including original and new columns"""
        return tuple(self._fieldnames) + tuple(self._new_fieldnames)

    @property
    def rows(self) -> Iterator[dict[str, str]]:
        """iterator: Get all rows with transformations applied"""
        return self._get_rows()

    @property
    def rows_typed(self) -> Iterator[dict[str, Any]]:
        """iterator: Get all rows with type conversions applied"""
        return self._get_rows(typed=True)

    def _get_rows(self, typed: bool = False) -> Iterator[dict[str, Any]]:
        if not self._valid:
            raise NotValidContent
        self._valid = False
        computed_cols = set(colname for colname, _ in self._applied)
        for row in self._rows:
            typed_row = row
            if self._applied or self._filters or typed:
                typed_row = row.copy()
                typed_row.update(
                    {
                        c: t(row[c])
                        for c, t in self._types.items()
                        if c not in computed_cols
                    }
                )
            for colname, func in self._applied:
                row[colname] = func(typed_row)
                if colname in self._types:
                    typed_row[colname] = self._types[colname](row[colname])
                else:
                    typed_row[colname] = row[colname]
            filter_ok = True
            for func in self._filters:
                if not func(typed_row):
                    filter_ok = False
            if filter_ok:
                if typed:
                    yield typed_row
                else:
                    yield row

    @overload
    def remap_columns(
        self, columns: tuple[str, ...], *, return_mapping: Literal[False] = False
    ) -> "ContentCsv": ...

    @overload
    def remap_columns(
        self, columns: tuple[str, ...], *, return_mapping: Literal[True]
    ) -> tuple["ContentCsv", dict[str, str]]: ...

    def remap_columns(
        self, columns: tuple[str, ...], *, return_mapping: bool = False
    ) -> "ContentCsv | tuple[ContentCsv, dict[str, str]]":
        """Remap columns (select, rename, exclude) and return a new ContentCsv.

        Column spec: names to keep (optionally "newname=oldname"), or "-col" to exclude.

        Args:
            columns: Column specification (e.g. ("a", "b=c", "-d"))
            return_mapping: If True, return (content, fieldnames_map) where
                fieldnames_map is new_col_name -> old_col_name (output -> source).

        Returns:
            ContentCsv, or (ContentCsv, mapping) when return_mapping is True.
        """
        excluded_columns = [col[1:] for col in columns if col.startswith("-")]
        if any("=" in col for col in excluded_columns):
            raise CsvInvalidColumnSpec(
                "a excluded column (starting with '-') can not be renamed (with '=')"
            )
        source_fieldnames = list(self.fieldnames)
        new_col_names, old_col_names = (
            map(
                list,
                more_itertools.unzip(
                    col.split("=") if "=" in col else (col, col)
                    for col in columns
                    if not col.startswith("-")
                ),
            )
            if len(columns) > len(excluded_columns)
            else ([], [])
        )
        cols_not_found = (
            set(old_col_names).union(excluded_columns).difference(source_fieldnames)
        )
        if cols_not_found:
            raise CsvColumnsNotFound(
                f"Columns {cols_not_found} are not found in the current content."
            )
        fieldnames_map = dict(zip(new_col_names, old_col_names))
        if excluded_columns and source_fieldnames:
            fieldnames_map |= {
                col: col
                for col in source_fieldnames
                if col not in old_col_names and col not in excluded_columns
            }
        new_fieldnames = list(fieldnames_map.keys())
        new_rows = (
            {c: row[fieldnames_map[c]] for c in new_fieldnames} for row in self.rows
        )
        result = ContentCsv(_fieldnames=new_fieldnames, _rows=new_rows)
        if return_mapping:
            return (result, fieldnames_map)
        return result

    def add_apply(self, colname: str, func: Callable[[dict[str, Any]], Any]) -> None:
        """Add a transformation to apply to a column.

        Args:
            colname (str): Name of the column (existing or new)
            func (callable): Function to transform the column value
        """
        if colname not in self._fieldnames:
            self._new_fieldnames.append(colname)
        self._applied.append((colname, func))

    def add_filter(self, func: Callable[[dict[str, Any]], bool]) -> None:
        """Add a filter function for rows.

        Args:
            func (callable): Function that returns True for rows to keep
        """
        self._filters.append(func)

    def add_type(self, colname: str, typ: Callable[[str], Any]) -> None:
        """Add a type conversion for a column.

        Args:
            colname (str): Name of the column
            typ: Type to convert to
        """
        self._types[colname] = typ

    def join(
        self,
        oth: "ContentCsv",
        *,
        left: bool = False,
        right: bool = False,
        empty: bool = False
    ) -> "ContentCsv":
        """Join with another CSV content.

        Args:
            oth (ContentCsv): Other CSV content to join with
            left (bool): Perform left outer join
            right (bool): Perform right outer join
            empty (bool): Include rows with empty join keys

        Returns:
            ContentCsv: New content with joined data
        """
        common = set(self.fieldnames).intersection(set(oth.fieldnames))
        dict_of_oth: dict[tuple[str, ...], list[dict[str, str]]] = {}
        for l in oth.rows:
            value = tuple(l[k] for k in common)
            if not empty and all(not bool(x) for x in value):
                continue
            if value not in dict_of_oth:
                dict_of_oth[value] = []
            dict_of_oth[value].append(l)
        left_added_keys = [k for k in self.fieldnames if k not in common]
        added_keys = [k for k in oth.fieldnames if k not in common]
        new_fieldnames = list(self.fieldnames) + added_keys
        return ContentCsv(
            _fieldnames=new_fieldnames,
            _rows=_join_rowgen(
                self.rows, dict_of_oth, common, left_added_keys, added_keys, left, right
            ),
        )

    def concat(self, oth: "ContentCsv") -> "ContentCsv":
        """Concatenate with another CSV content.

        Args:
            oth (ContentCsv): Other CSV content to concatenate

        Returns:
            ContentCsv: New content with concatenated data
        """
        only_self = set(self.fieldnames).difference(set(oth.fieldnames))
        only_oth = set(oth.fieldnames).difference(set(self.fieldnames))
        new_fieldnames = list(self.fieldnames) + [
            k for k in oth.fieldnames if k in only_oth
        ]
        return ContentCsv(
            _fieldnames=new_fieldnames,
            _rows=_cat_rowgen(self.rows, oth.rows, only_self, only_oth),
        )

    def head(self, n: int) -> "ContentCsv":
        """Return a new instance with only the first n rows.

        Args:
            n (int): Number of rows to keep.

        Returns:
            ContentCsv: New content with at most n rows.
        """
        return ContentCsv(
            _fieldnames=self.fieldnames,
            _rows=itertools.islice(self.rows, n),
        )

    def tail(self, n: int) -> "ContentCsv":
        """Return a new instance with only the last n rows.

        Args:
            n (int): Number of rows to keep.

        Returns:
            ContentCsv: New content with at most n rows (from the end).
        """
        return ContentCsv(
            _fieldnames=self.fieldnames,
            _rows=iter(collections.deque(self.rows, maxlen=n)),
        )

    def aggregate(
        self,
        keys: list[str] | None,
        aggregations: list[tuple[str, Callable[[dict[str, list[Any]]], Any]]] | None,
    ) -> "ContentCsv":
        """Aggregate rows by keys.

        Args:
            keys (list): Columns to group by
            aggregations (list): List of (column, function) pairs for aggregation

        Returns:
            ContentCsv: New content with aggregated data
        """
        if aggregations is None:
            aggregations = []
        if keys is None:
            keys = []

        stored_by_key_data_column: dict[tuple[Any, ...], dict[str, list[Any]]] = {}
        for row in self._get_rows(typed=True):
            keyvalue = tuple(row[k] for k in keys)
            if keyvalue not in stored_by_key_data_column:
                store: dict[str, list[Any]] = {
                    colname: [] for colname in self.fieldnames
                }
                stored_by_key_data_column[keyvalue] = store
            else:
                store = stored_by_key_data_column[keyvalue]
            for colname, value in row.items():
                store[colname].append(value)
        new_fieldnames = [
            colname
            for colname in self.fieldnames
            if all(
                len(set(store[colname])) == 1
                for store in stored_by_key_data_column.values()
            )
        ]
        new_fieldnames.extend(
            colname for colname, _ in aggregations if colname not in new_fieldnames
        )
        return ContentCsv(
            _fieldnames=new_fieldnames,
            _rows=_aggregate_row_gen(
                new_fieldnames, stored_by_key_data_column, aggregations
            ),
        )

    def sort(
        self,
        keys: tuple[str, ...] | None = tuple(),
        numeric: bool = False,
        reverse: bool = False,
        random_sort: bool = False,
        seed: str | None = None,
    ) -> "ContentCsv":
        """Sort the content.

        Args:
            keys (list): Columns to sort by
            numeric (bool): Try to sort numerically
            reverse (bool): Sort in reverse order
            random_sort (bool): Add random tie-breaker
            seed: Random seed for reproducibility (when random_sort is True).

        Returns:
            ContentCsv: New content with sorted data
        """
        if keys is None:
            keys = ()
        cast_numeric: Callable[[str], str | tuple[float, str]]
        if numeric:
            cast_numeric = _cast_pseudo_numerical
        else:

            def _identity_str(x: str) -> str:
                return x

            cast_numeric = _identity_str

        append_random: Callable[
            [tuple[str | tuple[float, str], ...]],
            tuple[str | tuple[float, str] | float, ...],
        ]
        if random_sort:
            prng = PRNG(seed)

            def _append_random(
                t: tuple[str | tuple[float, str], ...],
            ) -> tuple[str | tuple[float, str] | float, ...]:
                return t + (prng.uniform(),)

            append_random = _append_random
        else:

            def _identity_tuple(
                t: tuple[str | tuple[float, str], ...],
            ) -> tuple[str | tuple[float, str], ...]:
                return t

            append_random = _identity_tuple

        def key_fun(row: dict[str, str]) -> tuple[str | tuple[float, str] | float, ...]:
            return append_random(tuple(cast_numeric(row[k]) for k in keys))

        return ContentCsv(
            _fieldnames=self.fieldnames,
            _rows=(row for row in sorted(self.rows, key=key_fun, reverse=reverse)),
        )

    def sample_without_replacement(
        self,
        k: int,
        seed: str | None = None,
        weight: str | None = None,
        revert: bool = False,
    ) -> "ContentCsv":
        """Random sampling without replacement in streaming.

        Returns at most k rows.

        Args:
            k: Maximum number of rows to return.
            seed: Random seed for reproducibility.
            weight: Column name used as weight (numeric, > 0). If None,
                sampling is uniform. Non numeric value or negative values are
                treated as null weight.
            revert: If True, return the complement of sampling: the k lines left
            after selecting all others except k.

        Returns:
            ContentCsv with at most k rows.
        """
        if weight is not None and weight not in self.fieldnames:
            raise CsvColumnsNotFound(f"Column {weight!r} not found")

        rowbuilder = SampledRowBuilder(seed=seed, weight=weight, revert=revert)

        queue: list[SampledRow] = []
        for row in self.rows:
            (sampler_row,) = rowbuilder.get_sampled_row(row)
            if len(queue) < k:
                heapq.heappush(queue, sampler_row)
            else:
                heapq.heappushpop(queue, sampler_row)

        result: list[dict[str, str]] = []
        while queue:
            result.append(heapq.heappop(queue).row)

        return ContentCsv(
            _fieldnames=self.fieldnames,
            _rows=(row for row in reversed(result)),
        )

    def sample_with_replacement(
        self,
        k: int,
        seed: str | None = None,
        weight: str | None = None,
    ) -> "ContentCsv":
        """Random sampling with replacement in streaming.

        Returns k rows (each row may appear multiple times).

        Args:
            k: Number of rows to return.
            seed: Random seed for reproducibility.
            weight: Column name used as weight (numeric, > 0). If None,
                sampling is uniform. Non-numeric or negative values are
                treated as null weight.

        Returns:
            ContentCsv with k rows.
        """
        if weight is not None and weight not in self.fieldnames:
            raise CsvColumnsNotFound(f"Column {weight!r} not found")

        rowbuilder = SampledRowBuilder(seed=seed, weight=weight, revert=False)

        rowiter = iter(self.rows)
        firstrow = next(rowiter, None)
        if firstrow is None:
            return ContentCsv(_fieldnames=self._fieldnames, _rows=(x for x in ()))
        content = rowbuilder.get_sampled_row(firstrow, k)
        for row in rowiter:
            for i, new in enumerate(rowbuilder.get_sampled_row(row, k)):
                if new > content[i]:
                    content[i] = new
        return ContentCsv(
            _fieldnames=self.fieldnames, _rows=(cont.row for cont in content)
        )

    def write_csv(
        self, f: Any, *, delim: str = ",", fmt: list[ColFormat] | None = None
    ) -> None:
        """Write content to a CSV file.

        Args:
            f: File-like object to write to
            delim (str): CSV delimiter character
            fmt (list): List of ColFormat objects to apply
        """
        dialect = csv.excel
        dialect.delimiter = delim
        writer = csv.DictWriter(f, self.fieldnames, dialect=dialect)
        writer.writeheader()
        for l in self.rows:
            row = l.copy()
            if fmt:
                for colfmt in fmt:
                    colfmt.format(row)
            writer.writerow(row)

    def _get_row_and_numeric(
        self,
        fmt: list[ColFormat] | None = None,
        infer_lines: int | None = 1000,
    ):
        numeric_columns: set[str] = set()
        for colname, typ in self._types.items():
            if typ in (int, float):
                numeric_columns.add(colname)
        if fmt:
            for colfmt in fmt:
                if colfmt.convert in (int, float):
                    numeric_columns.add(colfmt.colname)

        def get_formatted_rows():
            for l in self.rows:
                row = l.copy()
                if fmt:
                    for colfmt in fmt:
                        colfmt.format(row)
                yield row

        all_rows = Iterable_with_first(get_formatted_rows(), infer_lines)

        for colname in self.fieldnames:
            if colname not in numeric_columns:
                is_numeric = True
                for row in all_rows.first:
                    value = row.get(colname, "")
                    if value:  # Only check non-empty values
                        try:
                            float(str(value))
                        except (ValueError, TypeError):
                            is_numeric = False
                            break
                if is_numeric:
                    numeric_columns.add(colname)
        return all_rows, numeric_columns

    def write_pretty_markdown(
        self,
        f: Any,
        *,
        fmt: list[ColFormat] | None = None,
        infer_lines: int | None = 1000,
        textwidth: int | None = None,
    ) -> None:
        """Write content as a Markdown table (no external dependency).

        Args:
            f: File-like object to write to
            fmt (list): List of ColFormat objects to apply
            infer_lines: Max rows used to infer numeric columns (None = all)
            textwidth: Max total table width including decorations (None = no limit)
        """
        all_rows, numeric_columns = self._get_row_and_numeric(fmt, infer_lines)
        align_left = {h: h not in numeric_columns for h in self.fieldnames}
        md_pretty_table(
            f,
            list(self.fieldnames),
            all_rows,
            align_left,
            max_total_width=textwidth,
        )

    def write_pretty_text(
        self,
        f: Any,
        *,
        fmt: list[ColFormat] | None = None,
        unicode: bool = False,
        infer_lines: int | None = 1000,
        textwidth: int | None = None,
    ) -> None:
        """Write content as a bordered text table (no external dependency).

        Args:
            f: File-like object to write to
            fmt (list): List of ColFormat objects to apply
            unicode (bool): Use Unicode box-drawing characters if True, else ASCII
            infer_lines: Max rows used to infer numeric columns (None = all)
            textwidth: Max total table width including decorations (None = no limit)
        """
        all_rows, numeric_columns = self._get_row_and_numeric(fmt, infer_lines)
        align_left = {h: h not in numeric_columns for h in self.fieldnames}
        text_pretty_table(
            f,
            list(self.fieldnames),
            all_rows,
            align_left,
            unicode=unicode,
            max_total_width=textwidth,
        )

    def write_pretty_latex(
        self,
        f: Any,
        *,
        fmt: list[ColFormat] | None = None,
        infer_lines: int | None = 1000,
    ) -> None:
        """Write content as a LaTeX tabular (booktabs: \\toprule, \\midrule, \\bottomrule).

        Args:
            f: File-like object to write to
            fmt (list): List of ColFormat objects to apply
            infer_lines: Max rows used to infer numeric columns (None = all)
        """
        all_rows, numeric_columns = self._get_row_and_numeric(fmt, infer_lines)

        def latex_escape(s: str) -> str:
            s = str(s)
            for a, b in [
                ("\\", "\\textbackslash "),
                ("&", "\\&"),
                ("%", "\\%"),
                ("$", "\\$"),
                ("#", "\\#"),
                ("_", "\\_"),
                ("{", "\\{"),
                ("}", "\\}"),
            ]:
                s = s.replace(a, b)
            return s

        def sci_notation_to_latex(s: str) -> str:
            """Replace e+02, e-02, e02 by \\cdot10^{...} in string repr."""
            if not s:
                s = ""
            return re.sub(
                r"e([+-]?\d+)",
                lambda m: r"\cdot10^{" + str(int(m.group(1))) + "}",
                s,
            )

        colspec = "".join(
            "r" if col in numeric_columns else "l" for col in self.fieldnames
        )

        def cell_value(col: str, value: str) -> str:
            if col in numeric_columns:
                escaped = sci_notation_to_latex(value)
            else:
                escaped = latex_escape(value)
            return f"${escaped}$" if col in numeric_columns and escaped else escaped

        f.write("\\begin{tabular}{" + colspec + "}\n")
        f.write("\\toprule\n")
        f.write(" & ".join(latex_escape(h) for h in self.fieldnames) + " \\\\\n")
        f.write("\\midrule\n")
        for row in all_rows.all:
            f.write(
                " & ".join(cell_value(col, row[col]) for col in self.fieldnames)
                + " \\\\\n"
            )
        f.write("\\bottomrule\n")
        f.write("\\end{tabular}\n")

    def write_pretty_terminal(
        self,
        f: Any,
        *,
        fmt: list[ColFormat] | None = None,
        light: bool = True,
        infer_lines: int | None = 1000,
        textwidth: int | None = None,
    ) -> None:
        """Write content to pretty table in terminal.

        Args:
            f: File-like object to write to
            fmt (list): List of ColFormat objects to apply
            light (bool): Use light background colors (True) or dark background colors (False)
            infer_lines: Max rows used to infer numeric columns (None = all)
            textwidth: Max total table width including decorations (None = no limit)
        """

        all_rows, numeric_columns = self._get_row_and_numeric(fmt, infer_lines)

        max_cols = None
        if hasattr(f, "isatty") and f.isatty():
            try:
                terminal_size = shutil.get_terminal_size()
                max_cols = terminal_size.columns
            except (OSError, AttributeError):
                max_cols = None
        if textwidth is not None:
            max_cols = min(max_cols, textwidth) if max_cols is not None else textwidth

        terminal_pretty_table(
            f,
            self.fieldnames,
            all_rows,
            {h: False for h in numeric_columns},
            max_cols,
            light=light,
        )

    def write(
        self,
        f: Any,
        *,
        format: Literal[  # noqa: A001  # pylint: disable=redefined-builtin
            "csv", "terminal", "ascii", "unicode", "markdown", "latex"
        ] = "csv",
        format_options: dict[str, Any] | None = None,
        fmt: list[ColFormat] | None = None,
    ):
        """Write content to a CSV file or pretty table.

        Args:
            f: File-like object to write to
            format: Output format. One of: csv, terminal, ascii, unicode, markdown, latex.
            format_options: Options for the chosen format. Common keys:
                delim (str): CSV delimiter (default ","). Used for format "csv".
                dark_background (bool): Use dark background colors for terminal (default False).
                unicode (bool): Use Unicode box-drawing for text table (default False for "ascii").
                infer_lines (int | None): Rows used to infer column types for pretty output
                    (default 1000).
                textwidth (int | None): Max total table width including borders/padding
                    for pretty output (default: terminal width when stdout is a tty).
            fmt: List of ColFormat objects to apply to columns.
        """
        opts = format_options or {}
        delim = opts.get("delim", ",")
        dark_background = opts.get("dark_background", False)
        infer_lines = opts.get("infer_lines", 1000)
        textwidth = opts.get("textwidth")

        if format == "markdown":
            self.write_pretty_markdown(
                f, fmt=fmt, infer_lines=infer_lines, textwidth=textwidth
            )
        elif format in ("ascii", "unicode"):
            self.write_pretty_text(
                f,
                fmt=fmt,
                unicode=(format == "unicode"),
                infer_lines=infer_lines,
                textwidth=textwidth,
            )
        elif format == "latex":
            self.write_pretty_latex(f, fmt=fmt, infer_lines=infer_lines)
        elif format == "terminal":
            self.write_pretty_terminal(
                f,
                fmt=fmt,
                light=not dark_background,
                infer_lines=infer_lines,
                textwidth=textwidth,
            )
        else:
            self.write_csv(f, delim=delim, fmt=fmt)
