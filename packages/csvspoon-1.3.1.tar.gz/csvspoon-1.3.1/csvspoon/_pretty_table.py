# Copyright 2025-2026, Jean-Benoist Leger <jb@leger.tf>
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import typing
from typing import Sequence

import lazy_loader  # type: ignore[reportMissingTypeStubs]

from csvspoon._tools import Iterable_with_first

# Lazy-loaded modules below: any type annotation referring to them must use
# string form to avoid loading the module at import.
if typing.TYPE_CHECKING:
    import colorama
    import math
else:
    colorama = lazy_loader.load("colorama")  # type: ignore[reportUnreachable]
    math = lazy_loader.load("math")  # type: ignore[reportUnreachable]


def _md_escape(s: str) -> str:
    """Escape pipe and newlines for Markdown table cell."""
    if not s:
        s = ""
    return s.replace("\\", "\\\\").replace("|", "\\|").replace("\n", " ")


def _ascii_cell(s: str) -> str:
    if not s:
        s = ""
    return s.replace("\n", " ")


def _total_width_text(bounds: dict[str, int], n: int) -> int:
    """Total line width for text/ascii/unicode table (with borders and padding)."""
    return sum(bounds.values()) + 3 * n + 1


def text_pretty_table(
    f: typing.TextIO,
    headers: Sequence[str],
    rows: Iterable_with_first[dict[str, str]],
    align_left: dict[str, bool],
    unicode: bool = False,
    max_total_width: int | None = None,
) -> None:
    """Write a text table (ASCII or Unicode box-drawing) to f with the given headers and rows."""
    bounds = {
        h: max(
            len(_ascii_cell(h)),
            max((len(_ascii_cell(str(r[h]))) for r in rows.first), default=0),
        )
        for h in headers
    }
    n = len(headers)
    if max_total_width is not None:
        bounds = {h: b + 1 for h, b in bounds.items()}
        sbounds = sum(bounds.values())
        if sbounds < max_total_width:
            factor = min(max_total_width / sbounds, 2) if sbounds > 0 else 2
            bounds = {h: math.ceil(b * factor) for h, b in bounds.items()}
        while _total_width_text(bounds, n) > max_total_width:
            h_max = max(reversed(headers), key=lambda h: bounds[h])
            bounds[h_max] -= 1
            if bounds[h_max] < 1:
                raise ValueError("Table can not be displayed")

    if unicode:
        h_bar, v_bar = "─", "│"
        tl, tr, bl, br = "┌", "┐", "└", "┘"
        ml, mr, cross = "├", "┤", "┼"
        top_j, bot_j = "┬", "┴"
    else:
        h_bar, v_bar = "-", "|"
        tl = tr = bl = br = ml = mr = cross = top_j = bot_j = "+"

    def line(left: str, mid: str, right: str) -> None:
        f.write(
            left + mid.join(h_bar * (bounds[h] + 2) for h in headers) + right + "\n"
        )

    def row(cells: Sequence[str], header: bool = False) -> None:
        f.write(
            v_bar
            + " "
            + (" " + v_bar + " ").join(
                truncate_and_pad(
                    _ascii_cell(cells[i]),
                    bounds[h],
                    align_left.get(h, True),
                    header=header,
                    truncate=True,
                )
                for i, h in enumerate(headers)
            )
            + " "
            + v_bar
            + "\n"
        )

    line(tl, top_j, tr)
    row(headers, header=True)
    line(ml, cross, mr)
    for row_data in rows.all:
        row([row_data[h] for h in headers])
    line(bl, bot_j, br)


def md_pretty_table(
    f: typing.TextIO,
    headers: Sequence[str],
    rows: Iterable_with_first[dict[str, str]],
    align_left: dict[str, bool],
    max_total_width: int | None = None,
) -> None:
    """Write a Markdown table to f with the given headers and rows."""
    bounds = {
        h: max(
            len(_md_escape(h)),
            max((len(_md_escape(str(r[h]))) for r in rows.first), default=0),
        )
        for h in headers
    }
    n = len(headers)
    if max_total_width is not None:
        while _total_width_text(bounds, n) > max_total_width:
            h_max = max(reversed(headers), key=lambda h: bounds[h])
            bounds[h_max] -= 1
            if bounds[h_max] < 1:
                raise ValueError("Table can not be displayed")
    f.write(
        "| "
        + " | ".join(
            truncate_and_pad(
                _md_escape(h),
                bounds[h],
                align_left.get(h, True),
                header=True,
                truncate=False,
            )
            for h in headers
        )
        + " |\n"
    )
    f.write(
        "| "
        + " | ".join(
            (
                ":" + "-" * (bounds[h] - 1)
                if align_left.get(h, True)
                else "-" * (bounds[h] - 1) + ":"
            )
            for h in headers
        )
        + " |\n"
    )
    for row in rows.all:
        f.write(
            "| "
            + " | ".join(
                truncate_and_pad(
                    _md_escape(row[h]),
                    bounds[h],
                    align_left.get(h, True),
                    truncate=False,
                )
                for h in headers
            )
            + " |\n"
        )


def truncate_and_pad(
    value: str,
    length: int,
    align_left: bool = True,
    header: bool = False,  # noqa: ARG001  # pylint: disable=unused-argument  # pyright: ignore[reportUnusedVariable]  # reserved for future use
    truncate: bool = True,
) -> str:
    """Truncate value to length (with ellipsis if truncate), then pad with spaces to length."""
    value = str(value)
    if truncate and len(value) > length:
        value = f"{value[:length-1]}…"
    if len(value) < length:
        if align_left:
            value = value + " " * (length - len(value))
        else:
            value = " " * (length - len(value)) + value
    return value


def _total_width_terminal(bounds: dict[str, int], n: int) -> int:
    """Total line width for terminal table (with padding)."""
    return sum(bounds.values()) + 2 * n


def terminal_pretty_table(
    f: typing.TextIO,
    headers: Sequence[str],
    rows: Iterable_with_first[dict[str, str]],
    align_left: dict[str, bool],
    max_cols: int | None = None,
    light: bool = True,
) -> None:
    """Write a color-styled terminal table to f with the given headers and rows."""
    bounds = {
        h: max(len(h), max((len(str(r[h])) for r in rows.first), default=0))
        for h in headers
    }
    n = len(headers)
    if max_cols is not None:
        bounds = {h: b + 2 for h, b in bounds.items()}
        sbounds = sum(bounds.values())
        if sbounds < max_cols:
            factor = min(max_cols / sbounds, 2) if sbounds > 0 else 2
            bounds = {h: math.ceil(b * factor) for h, b in bounds.items()}
        while _total_width_terminal(bounds, n) > max_cols:
            bounds[max(reversed(headers), key=lambda h: bounds[h])] -= 1
            if any(x < 1 for x in bounds.values()):
                raise ValueError("Table can not be displayed")
    SRESET = colorama.Style.RESET_ALL
    if light:
        header_style = (
            colorama.Back.BLACK + colorama.Fore.LIGHTWHITE_EX + colorama.Style.BRIGHT
        )
        style1 = colorama.Back.LIGHTWHITE_EX + colorama.Fore.BLACK
        style2 = colorama.Back.WHITE + colorama.Fore.BLACK
    else:
        header_style = (
            colorama.Back.WHITE + colorama.Fore.LIGHTBLACK_EX + colorama.Style.BRIGHT
        )
        style1 = colorama.Back.LIGHTBLACK_EX + colorama.Fore.WHITE
        style2 = colorama.Back.BLACK + colorama.Fore.WHITE

    f.write(
        header_style
        + "".join(
            " "
            + truncate_and_pad(h, bounds[h], align_left.get(h, True), header=True)
            + " "
            for h in headers
        )
        + SRESET
        + "\n"
    )

    for i, row in enumerate(rows.all):
        f.write(
            (style1 if i % 2 == 0 else style2)
            + "".join(
                " " + truncate_and_pad(row[h], bounds[h], align_left.get(h, True)) + " "
                for h in headers
            )
            + SRESET
            + "\n"
        )
