# Copyright 2026, Jean-Benoist Leger <jb@leger.tf>
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


import typing
from typing import Iterator, TypeVar, Generic

import lazy_loader  # type: ignore[reportMissingTypeStubs]

# Lazy-loaded modules below: any type annotation referring to them must use
# string form to avoid loading the module at import.
if typing.TYPE_CHECKING:
    import itertools
else:
    itertools = lazy_loader.load("itertools")  # type: ignore[reportUnreachable]

T = TypeVar("T")


class Iterable_with_first(Generic[T]):
    """Iterable wrapper that exposes the first n items separately from the rest.

    Lazy: the first n elements are consumed from the underlying iterator only
    when .first or .all is first iterated.

    Iterable first can be iterated many times.
    """

    _first: list[T] | None
    _after: Iterator[T]
    _n: int | None

    def __init__(self, content: Iterator[T], n: int | None) -> None:
        self._first = None
        self._after = content
        self._n = n

    @property
    def first(self) -> Iterator[T]:
        """Iterator over the first n elements."""
        if self._first is None:
            if self._n is None:
                self._first = list(self._after)
            else:
                self._first = list(itertools.islice(self._after, self._n))
        yield from self._first

    @property
    def all(self) -> Iterator[T]:
        """Iterator over all elements (first n, then the rest)."""
        if self._first is not None:
            yield from self._first
        yield from self._after
