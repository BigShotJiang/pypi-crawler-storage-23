# Copyright 2019-2026, Jean-Benoist Leger <jb@leger.tf>
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import argparse
import io
import os
import typing
import shutil
from typing import Any, Protocol

import lazy_loader  # type: ignore[reportMissingTypeStubs]

try:
    from csvspoon import __version__

    from csvspoon import (
        ColFormat,
        ColType,
        ContentCsv,
        CsvFileSpec,
        NewColFormat,
    )
except ModuleNotFoundError:
    # Allow loading when run from source tree (e.g. build man pages via run_path)
    import sys
    from pathlib import Path

    _root = Path(__file__).resolve().parent.parent
    if str(_root) not in sys.path:
        sys.path.insert(0, str(_root))
    from csvspoon import __version__

    from csvspoon import (
        ColFormat,
        ColType,
        ContentCsv,
        CsvFileSpec,
        NewColFormat,
    )

# Lazy-loaded modules below: any type annotation referring to them must use
# string form to avoid loading the module at import.
if typing.TYPE_CHECKING:
    import functools
    import itertools
    import subprocess
    import sys
    import textwrap

    import argcomplete
else:
    argcomplete = lazy_loader.load("argcomplete")  # type: ignore[reportUnreachable]
    functools = lazy_loader.load("functools")  # type: ignore[reportUnreachable]
    itertools = lazy_loader.load("itertools")  # type: ignore[reportUnreachable]
    subprocess = lazy_loader.load("subprocess")  # type: ignore[reportUnreachable]
    sys = lazy_loader.load("sys")  # type: ignore[reportUnreachable]
    textwrap = lazy_loader.load("textwrap")  # type: ignore[reportUnreachable]


def _normalize_help_text(s: str, width: int | None = None) -> str:
    """Normalize a string for argparse help/description and manpage generation.

    - Preserves double newlines (paragraph breaks).
    - Within each paragraph: replaces newlines and tabs with spaces,
      collapses multiple spaces to a single space, ensures a double space
      after every period that was already followed by a space, strips.
    """
    s = textwrap.dedent(s)
    paragraphs = s.split("\n\n")
    if width is None:

        def wrap(x: str):
            return x

    else:

        def wrap(x: str):
            return "\n".join(textwrap.wrap(x, width=width))

    normalized = (
        wrap(" ".join(p.split()).replace(". ", ".  ").strip()) for p in paragraphs
    )
    return "\n\n".join(normalized)


class _alternatively_NewColFormat_Formula:
    def __init__(self):
        self._alternatively = 0

    def __call__(self, value: str):
        if self._alternatively == 0:
            typ = NewColFormat
        else:
            typ = str
        self._alternatively += 1
        self._alternatively %= 2
        return typ(value)


class _Unambiguous_Choice_with_Aliases:
    names: list[tuple[str, ...]]

    def __init__(self, *args: str | tuple[str, ...]):
        self.names = [(x,) if isinstance(x, str) else x for x in args]

    def __repr__(self):
        choices = ", ".join(
            f"{x!r}" for x in sorted(itertools.chain.from_iterable(self.names))
        )
        return f"Unambiguous choice in {{{choices}}}"

    def __call__(self, value: str):
        selected_names = [
            name[0]
            for name in self.names
            if any(x.lower().startswith(value.lower()) for x in name)
        ]
        if len(selected_names) == 0:
            raise ValueError(f"Invalid value {value!r}")
        if len(selected_names) > 1:
            raise ValueError(f"Ambiguous name {value!r}")
        return selected_names[0]


class PosInt:
    """Argparse type: positive integer."""

    def __call__(self, value: str) -> int:
        try:
            n = int(value)
        except ValueError as exc:
            raise ValueError(f"Expected a positive integer, got {value!r}") from exc
        if n < 1:
            raise ValueError(f"Expected a positive integer, got {value!r}")
        return n

    def __repr__(self):
        return "Positive integer"


class PosIntOrInf:
    """Argparse type: positive integer or 'inf' (stored as None)."""

    def __call__(self, value: str) -> int | None:
        if value.strip().lower() == "inf":
            return None
        try:
            n = int(value)
        except ValueError as exc:
            raise ValueError(
                f"Expected a positive integer or 'inf', got {value!r}"
            ) from exc
        if n < 1:
            raise ValueError(f"Expected a positive integer or 'inf', got {value!r}")
        return n

    def __repr__(self):
        return "Positive integer or inf"


def cli_example_main_doc():
    "documentation function for generate README"
    examples = cli_examples()
    section_doc = {
        "cat": "Concatenate CSV files",
        "apply": "Apply functions to add columns",
        "sort": "Sort CSV file",
        "filter": "Filter CSV from given conditions",
        "join": "Join CSV files",
        "aggregate": "Compute aggregation on CSV file",
        "sample": "Sample rows in CSV file",
    }
    doc = "## Cli example\n"
    for subcommand, section_title in section_doc.items():
        doc += f"### csvspoon {subcommand}: {section_title}\n"
        incode = False
        initem = False
        for l in examples[subcommand].split("\n"):
            l = l.format(command=f"csvspoon {subcommand}")
            if not l:
                continue
            if l.startswith(" " * 2):
                if initem:
                    initem = False
                if not incode:
                    incode = True
                    doc += "```\n"
                doc += l[2:] + "\n"
            else:
                if incode:
                    incode = False
                    doc += "```\n"
                if not initem:
                    initem = True
                    doc += " - "
                else:
                    doc += "   "
                doc += l + "\n"
        if incode:
            doc += "```\n"
    return doc


def cli_examples():
    "CLI examples for epilogs dans README"
    examples = {
        "cat": textwrap.dedent("""\
            Cat two csv files:
              {command} file1.csv file2.csv

            Display a csv file with a high number of columns:
              {command} -S wide_data.csv

            Change delimiter of a csv file:
              {command} -d "\\t" -u ";" file.csv > result.csv

            Change delimiter of a csv file with specified output:
              {command} -o result.csv -d "\\t" -u ";" file.csv

            Reformat two columns of a csv files:
              {command} -f a_colname:5.1f -f another_colname:04d file.csv

            Cat one csv file, keeping only a column:
              {command} file.csv:a_col

            Cat two csv files, renaming a column on the second file:
              {command} file1.csv file2.csv:new_col=old_col,another_col

            Cat a csv file, keeping all columns except one:
              {command} file.csv:-col_to_drop

            Cat a csv file with a renamed column and one excluded (all other cols kept):
              {command} file.csv:display_name=internal_name,-skip_col
            """),
        "join": textwrap.dedent("""\
            Operate NATURAL JOIN on two csv files:
              {command} file1.csv file2.csv

            Operate two NATURAL JOIN on three csv files:
              {command} file1.csv file2.csv file3.csv

            Operate LEFT JOIN on two csv files
              {command} -l file1.csv file2.csv

            Operate RIGHT JOIN on two csv files
              {command} -r file1.csv file2.csv

            Operate OUTER JOIN on two csv files
              {command} -lr file1.csv file2.csv
            """),
        "apply": textwrap.dedent("""\
            Combine text columns by a formula:
              {command} -a name "lastname.upper()+' '+firstname.lower()" file.csv

            Column names with spaces (use --rowvar):
              {command} --rowvar r -a "full name" "r['first name']+' '+r['last name']" file.csv

            Combine text columns by a formula and remove original columns:
              {command} -a name "lastname.upper()+' '+firstname.lower()" \\
                      -O-lastname,-firstname file.csv

            Sum to integer columns:
              {command} -t cola:int -t colb:int -a colsum "cola+colb" file.csv

            Sum to integer columns and format the result:
              {command} -t cola:int -t colb:int -a colsum:05d "cola+colb" file.csv

            Compute complex expression between columns:
              {command} \\
                      -b "import math" \\
                      -t x:float \\
                      -t y:float \\
                      -a norm "math.sqrt(x**2+y**2)" \\
                      file.csv

            Use a custom function from a local module (current dir) for a new column:
              {command} -p . -b "from stuff import myfun" -a new_col "myfun(col1, col2)" file.csv

            Multiple computation can be done reusing newly created columns:
              {command} -t x:int -a x2p1 "x**2+1" -a x2p1m1 "x2p1-1" file.csv
            """),
        "sort": textwrap.dedent("""\
            Sort csv file using column cola:
              {command} -k cola file.csv

            Sort csv file using columns cola and colb:
              {command} -k cola -k colb file.csv

            Sort csv file using numerical mode on column numcol:
              {command} -n -k numcol file.csv

            Shuffle csv file:
              {command} -R file.csv
            """),
        "filter": textwrap.dedent("""\
            Filter csv file using two columns:
              {command} -a "lastname!=firstname" file.csv

            Column name with spaces (use --rowvar):
              {command} --rowvar r -a "r['unit price']>10" file.csv

            Chain filters on csv file:
              {command} \\
                      -a "lastname.startswith('Doe')" \\
                      -a "firstname.starswith('John')" \\
                      file.csv

            Filter csv file with float column price:
              {command} -t price:float -a "price>12.5" file.csv

            Filter csv file with complex expression:
              {command} \\
                      -b "import math" \\
                      -t x:float \\
                      -t y:float \\
                      -t z:float \\
                      -a "math.sqrt(x**2+y**2)>z" \\
                      file.csv
            """),
        "aggregate": textwrap.dedent("""\
            Keeping unique lines, one line per group:
              {command} \\
                      -k group \\
                      file.csv

            Column name with spaces (use --rowvar):
              {command} --rowvar r -k category -a total "sum(r['unit price'])" file.csv

            Computing the total mean grade:
              {command} \\
                      --np \\
                      -t grade:float \\
                      -a meangrade "np.mean(grade)" \\
                      file.csv

            Computing the total mean grade specifing a format:
              {command} \\
                      --np \\
                      -t grade:float \\
                      -a meangrade:.2f "np.mean(grade)" \\
                      file.csv

            Computing the mean grade by group:
              {command} \\
                      --np \\
                      -t grade:float \\
                      -a meangrade "np.mean(grade)" \\
                      -k group \\
                      file.csv

            Computing the mean grade, median, standard deviation by group:
              {command} \\
                      --np \\
                      -t grade:float \\
                      -a meangrade "np.mean(grade)" \\
                      -a mediangrade "np.median(grade)" \\
                      -a stdgrade "np.std(grade)" \\
                      -k group \\
                      file.csv
            """),
        "sample": textwrap.dedent("""\
            Sample 10 rows without replacement:
              {command} -k 10 file.csv

            Weighted sample of 10 rows using column weight:
              {command} -W weight -k 10 file.csv

            Sample 30 rows with replacement:
              {command} -r -k 30 file.csv
            """),
    }
    return examples


class RawDescriptionHelpFormatterMaxWidth(argparse.RawDescriptionHelpFormatter):
    """Set maximum text width."""

    def __init__(self, prog: Any):
        width = min(100, shutil.get_terminal_size().columns - 2)
        argparse.RawDescriptionHelpFormatter.__init__(self, prog, width=width)


# (name, help, aliases, long_description) for each subcommand. Single source of truth
# for help/aliases; long_description only used by full parser, minimal-main uses "See ...(1)".
_SUBCOMMAND_INFOS = (
    (
        "aggregate",
        "Apply a aggregation formula to compute a new column.",
        ["agg"],
        """
            Apply a formula to compute a new column.

            The formula must be a valid python expression evaluated for each
            groupped row. With --rowvar NAME, do not use column names as
            variables; use the dictionary NAME[column_name] instead.

            Only aggregation or column with non ambiguous values are keeped.
            Warning: this method need to store in memory all the input csv file.
            """,
    ),
    (
        "apply",
        "Apply a formula to compute a new column.",
        ["ap"],
        """
            Apply a formula to compute a new column.

            The formula must be a valid python expression evaluated on each row.
            With --rowvar NAME, do not use column names as variables; use the
            dictionary NAME[column_name] instead.

            This method is completely streamed and no data is stored in memory.
            """,
    ),
    (
        "cat",
        "Concatenate csv files.",
        ["c"],
        """
            Concatenate csv files.

            Empty fields added if some columns do not exist in all files.

            This method is completely streamed and no data is stored in memory.
            """,
    ),
    (
        "filter",
        "Filter a csv with a formula.",
        ["fi"],
        """
            Evaluate a formula on each row, and keep only rows where the formula
            is evaluated True.

            The formula must be a valid python expression evaluated on each row.
            With --rowvar NAME, do not use column names as variables; use the
            dictionary NAME[column_name] instead.

            This method is completely streamed and no data is stored in memory.
            """,
    ),
    (
        "join",
        "Operate join on csv files",
        ["jo"],
        """
            Natural join of csv files.

            Joins are performed from left to right.

            Warning: this method need to store in memory all csv except the
                first which is streamed.

            If neither --left or --right specified, inner join is realized. For
            complete outer join, use --left and --right together.
            """,
    ),
    (
        "sample",
        "Random sampling in streaming (with or without replacement).",
        ["sa"],
        """
            Random sampling in streaming.

            Two modes: without replacement (default)
            returns at most k distinct rows; with replacement (-r) returns exactly
            k rows (each row may appear multiple times).

            This method stores only in memory up to k rows.
            """,
    ),
    (
        "sort",
        "Sort csv files.",
        ["so"],
        """
            Sort csv file.

            Warning: this method need to store in memory all the input csv file.
            """,
    ),
)


def getparser(subcommand: str | None = None) -> argparse.ArgumentParser:
    """The parser only. If subcommand is set, return that subcommand's parser instead.
    Use subcommand=\"minimal-main\" for a minimal parser (subcommands only) for the main man page.
    """
    if subcommand == "minimal-main":
        parser = argparse.ArgumentParser(
            description=_normalize_help_text("""
                A tool to manipulate csv files with headers.

                Again, again, and again.
                """),
            epilog=_normalize_help_text("""
                Full documentation for each subcommand is available in
                csvspoon-<subcommand>(1), e.g. csvspoon-aggregate(1), csvspoon-apply(1).
                """),
            formatter_class=RawDescriptionHelpFormatterMaxWidth,
        )
        parser.add_argument(
            "--version",
            action="version",
            version=f"%(prog)s {__version__}",
            help=argparse.SUPPRESS,
        )
        subparsers = parser.add_subparsers(
            dest="subcommand", title="subcommands", required=True
        )
        for name, help_text, aliases, _ in _SUBCOMMAND_INFOS:
            subparsers.add_parser(
                name,
                help=help_text,
                description=f"See csvspoon-{name}(1).",
                formatter_class=RawDescriptionHelpFormatterMaxWidth,
                aliases=aliases,
            )
        return parser

    epilogs = {
        subcommand: (
            "Examples:\n" + textwrap.indent(example, " " * 2).format(command="%(prog)s")
        )
        for subcommand, example in cli_examples().items()
    }

    parser = argparse.ArgumentParser(
        description=_normalize_help_text("""
            A tool to manipulate csv files with headers.

            Again, again, and again.
            """),
        epilog="",
        formatter_class=RawDescriptionHelpFormatterMaxWidth,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
        help=argparse.SUPPRESS,
    )

    common_parser = argparse.ArgumentParser(add_help=False)
    input_group = common_parser.add_argument_group("Input options")
    input_group.add_argument(
        "-d",
        "--delim",
        dest="delim",
        default=",",
        help="Input delimiter. (default: ',')",
    )
    input_group.add_argument(
        "-c",
        "--inputenc",
        dest="inputenc",
        default="utf8",
        help="Input encoding. (default: 'utf8')",
    )
    output_group = common_parser.add_argument_group("Output options")
    output_group.add_argument(
        "-o", "--output", dest="output", help="Output file, else output on stdout."
    )
    output_group.add_argument(
        "-f",
        "--format",
        dest="format",
        action="append",
        default=[],
        type=ColFormat,
        help=_normalize_help_text("""
            Apply a format on a column on output. The argument must be a column
            name followed by a colon and a format specifier. e.g. "a_colname:5d"
            or "a_colname:+07.2f". This option can be specified multiple time to
            format different columns.
            """),
    )
    output_group.add_argument(
        "-O",
        "--output-columns",
        dest="output_columns",
        default=None,
        metavar="COLS",
        help=_normalize_help_text("""
            Output only the given columns, in that order. Same format as after ':'
            in the input: column names, optional renames (newname=oldname),
            optional exclusions (-col). e.g. "a,b,label=id,-skip".
            These transformations are applied after all other processing
            (including the --format option).
            When excluding columns (-col), use -O-col or --output-columns=-col
            (no space, or use =) so that -col is not parsed as a separate option.
            """),
    )
    output_group.add_argument(
        "-F",
        "--output-format",
        dest="output_format",
        default="auto",
        type=_Unambiguous_Choice_with_Aliases(
            "auto",
            "csv",
            ("markdown", "md"),
            ("latex", "tex"),
            "terminal",
            "ascii",
            "unicode",
        ),
        help=_normalize_help_text("""
            Output format. Choices: auto, csv, terminal, ascii, unicode, markdown (or md),
            latex (or tex).

            auto (default): CSV except when output on stdout and stdout is a tty,
            then terminal.
            csv: Raw CSV using the output delimiter (-u/--output-delim).
            terminal: Pretty-print with Unicode box-drawing for a nice display.
            ascii: Pretty-print as text table with ASCII characters only.
            unicode: Pretty-print as text table with Unicode box-drawing characters.
            markdown (md): Pretty-print as a Markdown table.
            latex (tex): Pretty-print as a LaTeX tabular (booktabs).
            """),
    )
    output_group.add_argument(
        "-u",
        "--output-delim",
        dest="odelim",
        default=",",
        help="Output delimiter. (default: ',')",
    )
    output_group.add_argument(
        "-C",
        "--outputenc",
        dest="outputenc",
        default="utf8",
        help="Output encoding. (default: 'utf8')",
    )
    head_tail_group = output_group.add_mutually_exclusive_group()
    head_tail_group.add_argument(
        "-H",
        "--head",
        dest="head",
        default=None,
        type=PosInt(),
        metavar="N",
        help="Output only the first N rows.",
    )
    head_tail_group.add_argument(
        "-T",
        "--tail",
        dest="tail",
        default=None,
        type=PosInt(),
        metavar="N",
        help="Output only the last N rows.",
    )
    output_group.add_argument(
        "-D",
        "--dark-background",
        dest="dark_background",
        action="store_true",
        help=_normalize_help_text("""
            Use dark background colors for terminal output. This option only
            has an effect when terminal pretty-print is used.
            """),
    )
    width_group = output_group.add_mutually_exclusive_group()
    width_group.add_argument(
        "-w",
        "--textwidth",
        dest="textwidth",
        default=None,
        type=PosInt(),
        help=_normalize_help_text("""
            Maximum total width of the table in characters (including borders
            and padding) for pretty output (terminal, ascii, unicode, markdown).
            Content is truncated with "…" when needed. (default: terminal width
            when stdout is a tty, else no limit)
            """),
    )
    width_group.add_argument(
        "-S",
        "--keep-long-lines",
        dest="keep_long_lines",
        action="store_true",
        help=_normalize_help_text("""
            Do not wrap or truncate long lines (mutually exclusive with -w).
            Implies -L in terminal output mode except when -N is specified.
            """),
    )
    output_group.add_argument(
        "--infer-lines",
        dest="infer_lines",
        default=1000,
        type=PosIntOrInf(),
        help=_normalize_help_text("""
            Number of rows used to infer column types and sizes for pretty
            output (markdown, terminal, etc.). Use "inf" for no limit (infer
            on all rows). (default: 1000)
            """),
    )
    less_group = output_group.add_mutually_exclusive_group()
    less_group.add_argument(
        "-L",
        "--less",
        dest="less_mode",
        action="store_const",
        const="yes",
        help=_normalize_help_text("""
            Pipe output through less (only when writing to stdout on a tty).
            Automatically activated if the number of lines exceed the terminal size
            (except when '--no-less' or '-N' is used).
            """),
    )
    less_group.add_argument(
        "-N",
        "--no-less",
        dest="less_mode",
        action="store_const",
        const="no",
        help="Never output through less (only when writing to stdout on a tty).",
    )
    common_parser.set_defaults(less_mode="auto")

    class _GroupWithAddArgument(Protocol):
        """Protocol for argument groups that support add_argument (e.g. ArgumentParser)."""

        def add_argument(self, *args: Any, **kwargs: Any) -> Any:
            """Add an argument to the group."""

    def add_coltyped_arguments(group: _GroupWithAddArgument) -> None:
        """Add column-typing and expression options to an argument group."""
        group.add_argument(
            "-b",
            "--before",
            action="append",
            default=[],
            help=_normalize_help_text("""
                Run the following code before evaluate the expression on each row.
                Can be specified multiple times. (e.g. "import math").
                """),
        )
        group.add_argument(
            "--np",
            action="store_true",
            help=_normalize_help_text("""
                Shortcut to `--before "import numpy as np"`
                """),
        )
        group.add_argument(
            "--sp",
            action="store_true",
            help=_normalize_help_text("""
                Shortcut to `--np --before "import scipy as sp"`
                """),
        )
        group.add_argument(
            "-p",
            "--python-path",
            dest="python_path",
            action="append",
            default=[],
            metavar="PATH",
            help=_normalize_help_text("""
                Append path provided in argument to Python path. Usefull in with -b.
                e.g. -p . -b "import myfunctions".
                """),
        )
        group.add_argument(
            "-t",
            "--type",
            action="append",
            type=ColType,
            default=[],
            help=_normalize_help_text("""
                Apply type conversion on specified command prior to expression. The
                argument must be a column name followed by a valid Python type. See
                "--before" to define non standard type. e.g. "a_column:int" or
                "a_column:float". This option can be specified multiple time to type
                different columns.
                """),
        )
        group.add_argument(
            "-r",
            "--rowvar",
            dest="rowvar",
            default=None,
            metavar="NAME",
            help=_normalize_help_text("""
                When set, row values are not exposed as local variables in
                expressions; instead a single dictionary mapping column names to
                values is exposed under this name. Useful when column names
                contain spaces or special characters. e.g. --rowvar row then
                use row["col name"] in apply/aggregate/filter expressions.
                """),
        )

    def add_seed_argument(group: _GroupWithAddArgument) -> None:
        """Add the --seed option for reproducibility (sample, sort)."""
        group.add_argument(
            "--seed",
            dest="seed",
            default=None,
            metavar="SEED",
            help="Random seed for reproducibility (any string of characters).",
        )

    input_filespec_help = """
        Input file specification. {} Can be a filename (e.g. "file.csv"), or a
        filename followed by a semicolon and column names separated by commas
        (e.g. "file.csv:a_colname,another_colname"). A column can be renamed
        with "new_name=old_name" (e.g. "file.csv:new_col=old_col").
        When column names are specified (and no exclusion is used), only those
        columns are used, in the given order.
        Prefixing a column with "-" excludes it. When at least one column is
        excluded, all columns from the file are kept except the excluded ones;
        columns that are also listed (possibly with a rename) appear under their
        (new) name. Excluded columns cannot be renamed (no "=" after "-col").
        """

    subparsers = parser.add_subparsers(
        dest="subcommand", title="subcommands", required=True
    )

    subparser_by_name: dict[str, argparse.ArgumentParser] = {}
    for name, help_text, aliases, raw_description in _SUBCOMMAND_INFOS:
        subparser_by_name[name] = subparsers.add_parser(
            name,
            help=help_text,
            description=_normalize_help_text(raw_description, width=80),
            parents=(common_parser,),
            epilog=epilogs[name],
            formatter_class=RawDescriptionHelpFormatterMaxWidth,
            aliases=aliases,
        )
    parser_aggregate = subparser_by_name["aggregate"]
    parser_apply = subparser_by_name["apply"]
    parser_cat = subparser_by_name["cat"]
    parser_filter = subparser_by_name["filter"]
    parser_join = subparser_by_name["join"]
    parser_sample = subparser_by_name["sample"]
    parser_sort = subparser_by_name["sort"]

    # --- arguments per subcommand (alphabetical order) ---
    # aggregate
    aggregate_processing = parser_aggregate.add_argument_group("Processing options")
    add_coltyped_arguments(aggregate_processing)
    aggregate_processing.add_argument(
        "-a",
        "--add",
        "--add-aggregation",
        dest="added",
        nargs=2,
        action="append",
        metavar=("COLSPEC", "FORMULA"),
        type=_alternatively_NewColFormat_Formula(),
        help=_normalize_help_text("""
            Append a new column by aggregation of values. Take two argument,
            COLSPEC and FORMULA. COLSPEC is the name of the created column
            obtained the aggregation. The COLSPEC can also contains a colon and a format
            specifier, see "--format" for example. FORMULA must be a valid
            python expression. For each column, list of values to aggregate are
            accessible as local variable (or via the dict given by --rowvar NAME).
            The formula should return a single value.
            e.g. "sum(a_colname) + sum(other_colname)" or with --rowvar r:
            "sum(r['a col']) + sum(r['other col'])".
            See "--type" for typing other columns and "--before" for run code
            before evaluating expression. Can be specified multiple time.
            """),
    )
    aggregate_processing.add_argument(
        "-k",
        "--key",
        dest="keys",
        action="append",
        help=_normalize_help_text("""
            Column used groupping the aggregate. Can be specified multiple time.
            Similar to "GROUP BY" in SQL.
            """),
    )
    parser_aggregate.add_argument(
        "input",
        help=_normalize_help_text(input_filespec_help.format("""
            If no input file is provided, stdin is used as input file.
            """)),
        type=CsvFileSpec,
        nargs="?",
    )

    # apply
    apply_processing = parser_apply.add_argument_group("Processing options")
    add_coltyped_arguments(apply_processing)
    apply_processing.add_argument(
        "-a",
        "--add",
        "--add-column",
        dest="added",
        nargs=2,
        action="append",
        metavar=("COLSPEC", "FORMULA"),
        type=_alternatively_NewColFormat_Formula(),
        help=_normalize_help_text("""
            Append a new column (or update existing one). Take two argument,
            COLSPEC and FORMULA. COLSPEC is the name of the created column
            obtained by appling the formula. The column is remplaced if already
            exists. The COLSPEC can also contains a colon and a format
            specifier, see "--format" for example. FORMULA must be a valid
            python expression. For the current row, columns values are accessible
            as local variable (or via the dict given by --rowvar NAME).
            e.g. "a_colname + other_colname" or "min(a_colname, other_colname)";
            with --rowvar row: row["col name"] + row["other col"].
            See "--type" for typing other columns and "--before" for run code
            before evaluating expression. Can be specified multiple time.
            """),
    )
    parser_apply.add_argument(
        "input",
        help=_normalize_help_text(input_filespec_help.format("""
            If no input file is provided, stdin is used as input file.
            """)),
        type=CsvFileSpec,
        nargs="?",
    )

    # cat
    parser_cat.add_argument(
        "input",
        help=_normalize_help_text(input_filespec_help.format("""
            If no input file is provided, stdin is used as first input file,
            otherwise use explicitly "-" for stdin.
            """)),
        nargs="*",
        type=CsvFileSpec,
    )

    # filter
    filter_processing = parser_filter.add_argument_group("Processing options")
    add_coltyped_arguments(filter_processing)
    filter_processing.add_argument(
        "-a",
        "--add",
        "--add-filter",
        dest="added",
        action="append",
        metavar="FILTER_FORMULA",
        help=_normalize_help_text("""
            FORMULA must be a valid python expression, which is casted to
            bool(). For the current row, columns values are accessible as
            local variable (or via the dict given by --rowvar NAME).
            e.g. "a_colname > other_colname" or "a_colname=='fixedvalue'";
            with --rowvar row: "row['col name'] > row['other col']".
            See "--type" for typing other columns and "--before" for run code
            before evaluating filter expression. Can be specified multiple time.
            """),
    )
    parser_filter.add_argument(
        "input",
        help=_normalize_help_text(input_filespec_help.format("""
            If no input file is provided, stdin is used as input file.
            """)),
        type=CsvFileSpec,
        nargs="?",
    )

    # join
    join_processing = parser_join.add_argument_group("Processing options")
    join_processing.add_argument(
        "-l",
        "--left",
        action="store_true",
        help=_normalize_help_text("""
            Perform left join. If more than two files are provided, each join in
            a left join. Can be used with `-r` to obtain a outer join.
            """),
    )
    join_processing.add_argument(
        "-r",
        "--right",
        action="store_true",
        help=_normalize_help_text("""
            Perform right join. If more than two files are provided, each join in
            a right join. Can be used with `-l` to obtain a outer join.
            """),
    )
    join_processing.add_argument(
        "-e",
        "--empty",
        action="store_true",
        help=_normalize_help_text("""
            Indicate than empty field have to be considered as a value.
            """),
    )
    parser_join.add_argument(
        "input",
        help=_normalize_help_text(input_filespec_help.format("""
            If less than two input files are provided, stdin is used as first
            input file, otherwise use explicitly "-" for stdin.
            """)),
        nargs="+",
        type=CsvFileSpec,
    )

    # sample
    sample_processing = parser_sample.add_argument_group("Processing options")
    sample_processing.add_argument(
        "-W",
        "--weight",
        dest="weight",
        default=None,
        metavar="COL",
        help=_normalize_help_text("""
            Column name used as weight. Non-numeric or negative values are treated as zero.
            If not set, sampling is uniform.
        """),
    )
    sample_mode_group = sample_processing.add_mutually_exclusive_group()
    sample_mode_group.add_argument(
        "-r",
        "--with-replacement",
        dest="with_replacement",
        action="store_true",
        help="Sample with replacement: output exactly k rows (rows may repeat).",
    )
    sample_mode_group.add_argument(
        "-R",
        "--revert",
        dest="revert",
        action="store_true",
        help=_normalize_help_text("""
            Return the complement of sampling: the k lines left after selecting all
            others except k. Incompatible with -r (with replacement).
        """),
    )
    add_seed_argument(sample_processing)
    sample_processing.add_argument(
        "-k",
        dest="k",
        type=PosInt(),
        default=1,
        metavar="K",
        help=_normalize_help_text("""
            Number of rows to return. Without replacement: at most k rows; if the
            input has fewer than k lines, all are selected. With replacement (-r):
            exactly k rows. (default: 1)
        """),
    )
    parser_sample.add_argument(
        "input",
        help=_normalize_help_text(input_filespec_help.format("""
            If no input file is provided, stdin is used as input file.
            """)),
        type=CsvFileSpec,
        nargs="?",
    )

    # sort
    sort_processing = parser_sort.add_argument_group("Processing options")
    sort_processing.add_argument(
        "-k",
        "--key",
        dest="keys",
        action="append",
        help=_normalize_help_text("""
            Column used for sorting. Can be specified multiple time.
            """),
    )
    sort_processing.add_argument(
        "-n",
        "--numeric-sort",
        dest="numeric",
        action="store_true",
        help="Compare according to numerical value.",
    )
    sort_processing.add_argument(
        "-r",
        "--reverse",
        dest="reverse",
        action="store_true",
        help="Reverse the result of comparisons.",
    )
    sort_processing.add_argument(
        "-R",
        "--random-sort",
        dest="random",
        action="store_true",
        help=_normalize_help_text("""
            Shuffle. If key specified, shuffle is performed inside lines with
            the same key.
            """),
    )
    add_seed_argument(sort_processing)
    parser_sort.add_argument(
        "input",
        help=_normalize_help_text(input_filespec_help.format("""
            If no input file is provided, stdin is used as input file.
            """)),
        type=CsvFileSpec,
        nargs="?",
    )

    argcomplete.autocomplete(parser)
    if subcommand is not None:
        if subcommand not in subparsers.choices:
            raise ValueError(f"Unknown subcommand: {subcommand!r}")
        return subparsers.choices[subcommand]
    return parser


def getparser_main() -> argparse.ArgumentParser:
    "Parser for main man page (subcommands overview only)."
    return getparser(subcommand="minimal-main")


def getparser_aggregate() -> argparse.ArgumentParser:
    "Dummy function needed for man page generation"
    return getparser(subcommand="aggregate")


def getparser_apply() -> argparse.ArgumentParser:
    "Dummy function needed for man page generation"
    return getparser(subcommand="apply")


def getparser_cat() -> argparse.ArgumentParser:
    "Dummy function needed for man page generation"
    return getparser(subcommand="cat")


def getparser_filter() -> argparse.ArgumentParser:
    "Dummy function needed for man page generation"
    return getparser(subcommand="filter")


def getparser_join() -> argparse.ArgumentParser:
    "Dummy function needed for man page generation"
    return getparser(subcommand="join")


def getparser_sample() -> argparse.ArgumentParser:
    "Dummy function needed for man page generation"
    return getparser(subcommand="sample")


def getparser_sort() -> argparse.ArgumentParser:
    "Dummy function needed for man page generation"
    return getparser(subcommand="sort")


def parseargs():
    "The parser and the parsing"
    parser = getparser()
    args = parser.parse_args()
    return args


_LESS_HEADER_LINES_BY_FORMAT: dict[str, int] = {
    "terminal": 1,
    "csv": 1,
    "markdown": 2,
    "ascii": 3,
    "unicode": 3,
    "latex": 4,
}


class _LessOrStdoutWriter(io.TextIOBase):
    """
    Writer used only when output goes to stdout on a tty.
    Buffers writes until line count exceeds terminal height, then switches to
    piping to less. If output ends before that, flushes buffer to stdout.
    """

    def __init__(
        self,
        terminal_lines: int,
        outputenc: str,
        use_less_from_start: bool = False,
        header_lines: int = 1,
    ):
        self._terminal_lines = terminal_lines
        self._outputenc = outputenc
        self._use_less_from_start = use_less_from_start
        self._header_lines = header_lines
        self._buffer = ""
        self._pipe: "subprocess.Popen[str] | None" = None
        self._closed = False

    def _current_line_count(self) -> int:
        b = self._buffer
        if not b:
            return 0
        return b.count("\n") + (1 if not b.endswith("\n") else 0)

    def _start_less(self) -> None:
        assert self._pipe is None
        self._pipe = subprocess.Popen(  # pylint: disable=consider-using-with
            [
                "less",
                "-R",
                "-S",
                r"-PsFirst displayed row\: %lt",
                f"--header={self._header_lines}",
            ],
            stdin=subprocess.PIPE,
            text=True,
            encoding=self._outputenc,
        )
        assert self._pipe.stdin is not None

    def _pipe_stdin(self) -> io.TextIOBase:
        assert self._pipe is not None and self._pipe.stdin is not None
        return self._pipe.stdin  # type: ignore[return-value]

    def write(self, s: str) -> int:
        if self._closed:
            raise ValueError("write on closed writer")
        if self._pipe is not None:
            self._pipe_stdin().write(s)
            return len(s)
        if self._use_less_from_start:
            self._start_less()
            self._pipe_stdin().write(s)
            return len(s)
        self._buffer += s
        if self._current_line_count() > self._terminal_lines:
            self._start_less()
            self._pipe_stdin().write(self._buffer)
            self._buffer = ""
        return len(s)

    def finish(self) -> None:
        """Flush buffered output, close the pager if used, and mark the writer closed."""
        if self._closed:
            return
        self._closed = True
        if self._pipe is not None:
            if self._buffer:
                self._pipe_stdin().write(self._buffer)
                self._buffer = ""
            self._pipe_stdin().close()
            self._pipe.wait()
        else:
            if self._buffer:
                sys.stdout.buffer.write(self._buffer.encode(self._outputenc))
            self._buffer = ""

    def __del__(self) -> None:
        try:
            self.finish()
        except BrokenPipeError:
            devnull = os.open(os.devnull, os.O_WRONLY)
            os.dup2(devnull, sys.stdout.fileno())

    def writable(self) -> bool:
        return True


def write_result(args: argparse.Namespace, result: ContentCsv) -> None:
    """Write the CSV result to stdout or the output file, with optional paging
    and format options."""
    if getattr(args, "head", None) is not None:
        result = result.head(args.head)
    elif getattr(args, "tail", None) is not None:
        result = result.tail(args.tail)

    fmt: list[ColFormat] = args.format
    if getattr(args, "output_columns", None) is not None:
        result, mapping = result.remap_columns(
            tuple(args.output_columns.split(",")), return_mapping=True
        )
        fmt = list(itertools.chain.from_iterable(f.apply_mapping(mapping) for f in fmt))

    output_format = args.output_format
    if output_format == "auto":
        if args.output is None and sys.stdout.isatty():
            output_format = "terminal"
        else:
            output_format = "csv"

    textwidth = getattr(args, "textwidth", None)
    if (
        textwidth is None
        and args.output is None
        and sys.stdout.isatty()
        and not args.keep_long_lines
    ):
        try:
            textwidth = os.get_terminal_size().columns
        except (OSError, AttributeError):
            pass
    format_options = {
        "delim": args.odelim,
        "dark_background": args.dark_background,
        "infer_lines": args.infer_lines,
        "textwidth": textwidth,
    }

    less_mode = getattr(args, "less_mode", "auto")
    use_less = (
        args.output is None
        and sys.stdout.isatty()
        and less_mode != "no"
        and (less_mode == "yes" or output_format == "terminal")
    )
    if use_less:
        terminal_lines = os.get_terminal_size().lines
        header_lines = _LESS_HEADER_LINES_BY_FORMAT.get(output_format, 1)
        writer = _LessOrStdoutWriter(
            terminal_lines=terminal_lines,
            outputenc=args.outputenc,
            use_less_from_start=(
                less_mode == "yes" or (less_mode == "auto" and args.keep_long_lines)
            ),
            header_lines=header_lines,
        )
        result.write(
            writer,
            format=output_format,
            format_options=format_options,
            fmt=fmt,
        )
        writer.finish()
        return

    foutput_raw = (
        # pylint: disable=consider-using-with
        open(args.output, mode="bw")
        if args.output is not None
        else sys.stdout.buffer
    )
    foutput = io.TextIOWrapper(foutput_raw, encoding=args.outputenc)
    result.write(
        foutput,
        format=output_format,
        format_options=format_options,
        fmt=fmt,
    )
    if args.output is not None:
        foutput.close()
        foutput_raw.close()


def coltyped_common(
    args: argparse.Namespace, inputstream: ContentCsv
) -> dict[str, Any]:
    """Apply --before code, and column types; return the namespace for later eval."""
    fake_global = {"__name__": "__main__"}
    if args.np or args.sp:
        ast = compile("import numpy as np", "<string>", "exec")
        exec(ast, fake_global)
    if args.sp:
        ast = compile("import scipy as sp", "<string>", "exec")
        exec(ast, fake_global)
    if args.python_path:
        ast = compile("import sys", "<string>", "exec")
        exec(ast, fake_global)
        for path in args.python_path:
            ast = compile(f"sys.path.append({path!r})", "<string>", "exec")
            exec(ast, fake_global)
    for before in args.before:
        ast = compile(before, "<string>", "exec")
        exec(ast, fake_global)
    for t in args.type:
        t.build_type(fake_global)
        inputstream.add_type(*t.get_coltype)
    return fake_global


def expose_rows(args: argparse.Namespace):
    """Return a function that exposes the current row/group dict for formula eval.

    If args.rowvar is set, the store is wrapped as {rowvar: store}; otherwise
    the store is returned as-is.
    """
    rowvar: str | None = getattr(args, "rowvar", None)
    if rowvar is None:

        def expose_direct(store: dict[str, Any]) -> dict[str, Any]:
            return store

        return expose_direct

    def expose_rowvar(store: dict[str, Any]) -> dict[str, dict[str, Any]]:
        return {rowvar: store}

    return expose_rowvar


def main_aggregate(args: argparse.Namespace) -> None:
    """Run the aggregate subcommand: group by keys and compute added columns,
    then write output."""
    if args.input is None:
        args.input = CsvFileSpec("-")
    input_csv = ContentCsv(
        filespec=args.input, delim=args.delim, encoding=args.inputenc
    )
    fake_global = coltyped_common(args, input_csv)
    args_added: list[tuple[NewColFormat, str]] = (
        [] if args.added is None else args.added
    )

    for colspec, _ in args.added:
        args.format.insert(0, colspec)

    expose = expose_rows(args)

    def make_agg(f: str):
        def agg(store: dict[str, list[Any]]) -> Any:
            return eval(f, fake_global, expose(store))

        return agg

    aggregations = [
        (colspec.colname, make_agg(formula)) for colspec, formula in args_added
    ]

    result = input_csv.aggregate(keys=args.keys, aggregations=aggregations)
    write_result(args, result)


def main_sample(args: argparse.Namespace) -> None:
    """Run the sample subcommand: random sampling, then write output."""
    if args.input is None:
        args.input = CsvFileSpec("-")
    content = ContentCsv(filespec=args.input, delim=args.delim, encoding=args.inputenc)
    if args.with_replacement:
        result = content.sample_with_replacement(
            k=args.k,
            seed=args.seed,
            weight=args.weight,
        )
    else:
        result = content.sample_without_replacement(
            k=args.k,
            seed=args.seed,
            weight=args.weight,
            revert=args.revert,
        )
    write_result(args, result)


def main_sort(args: argparse.Namespace) -> None:
    """Run the sort subcommand: sort rows by keys, then write output."""
    if args.input is None:
        args.input = CsvFileSpec("-")
    result = ContentCsv(
        filespec=args.input, delim=args.delim, encoding=args.inputenc
    ).sort(
        keys=args.keys,
        numeric=args.numeric,
        reverse=args.reverse,
        random_sort=args.random,
        seed=args.seed,
    )
    write_result(args, result)


def main_filter(args: argparse.Namespace) -> None:
    """Run the filter subcommand: apply row filter and column expressions, then write output."""
    if args.input is None:
        args.input = CsvFileSpec("-")
    args_added: list[str] = [] if args.added is None else args.added
    result = ContentCsv(filespec=args.input, delim=args.delim, encoding=args.inputenc)
    fake_global = coltyped_common(args, result)

    expose = expose_rows(args)

    for formula in args_added:
        # Closure: outer lambda captures current formula per iteration;
        # inlining would bind the same (last) formula for all filters.
        result.add_filter(
            # noqa: RUF016  # pylint: disable=unnecessary-direct-lambda-call
            func=(lambda f: lambda r: eval(f, fake_global, expose(r)))(formula)
        )
    write_result(args, result)


def main_apply(args: argparse.Namespace) -> None:
    """Run the apply subcommand: add or transform columns with expressions, then write output."""
    if args.input is None:
        args.input = CsvFileSpec("-")
    args_added: list[tuple[NewColFormat, str]] = (
        [] if args.added is None else args.added
    )
    result = ContentCsv(filespec=args.input, delim=args.delim, encoding=args.inputenc)
    fake_global = coltyped_common(args, result)

    expose = expose_rows(args)

    for colspec, formula in args_added:
        # Closure: outer lambda captures current formula per iteration;
        # inlining would bind the same (last) formula for all apply calls.
        result.add_apply(
            colname=colspec.colname,
            func=(
                # noqa: RUF016  # pylint: disable=unnecessary-direct-lambda-call
                (lambda f: lambda r: eval(f, fake_global, expose(r)))(formula)
            ),
        )
        args.format.insert(0, colspec)

    write_result(args, result)


def main_join(args: argparse.Namespace) -> None:
    """Run the join subcommand: join multiple CSVs on keys, then write output."""
    if len(args.input) < 2:
        args.input.insert(0, CsvFileSpec("-"))
    result = functools.reduce(
        lambda x, y: x.join(y, left=args.left, right=args.right, empty=args.empty),
        (
            ContentCsv(filespec=fn, delim=args.delim, encoding=args.inputenc)
            for fn in args.input
        ),
    )
    write_result(args, result)


def main_cat(args: argparse.Namespace) -> None:
    """Run the cat subcommand: concatenate CSV inputs, then write output."""
    if len(args.input) == 0:
        args.input.insert(0, CsvFileSpec("-"))
    result = functools.reduce(
        lambda x, y: x.concat(y),
        (
            ContentCsv(filespec=fn, delim=args.delim, encoding=args.inputenc)
            for fn in args.input
        ),
    )
    write_result(args, result)


def main():
    "Main function for CLI"
    args = parseargs()

    try:
        if args.subcommand == "join":
            main_join(args)
        if args.subcommand == "cat":
            main_cat(args)
        if args.subcommand == "apply":
            main_apply(args)
        if args.subcommand == "sort":
            main_sort(args)
        if args.subcommand == "filter":
            main_filter(args)
        if args.subcommand == "aggregate":
            main_aggregate(args)
        if args.subcommand == "sample":
            main_sample(args)
    except BrokenPipeError:
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        sys.exit(1)


if __name__ == "__main__":
    main()
