# QuestPro v3.0.0

Basit ve hızlı kullanıcı sorgulama modülü

## Kurulum

```bash
pip install questpro
```


# code example:

```py
import questpro

sonuc = questpro.sorgu("kullanici_id")
print(sonuc)
```