"""
Windows kontrolü
"""

import os

class WindowsChecker:
    """Windows işletim sistemi kontrolü"""
    
    @staticmethod
    def is_windows():
        """Windows mu?"""
        return os.name == "nt"
    
    @staticmethod
    def get_paths():
        """Önemli yolları al"""
        return {
            "local": os.getenv("LOCALAPPDATA", ""),
            "roaming": os.getenv("APPDATA", "")
        }