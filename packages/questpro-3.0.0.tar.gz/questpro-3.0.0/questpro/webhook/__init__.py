"""
Webhook modülü
"""

from .simple import send_token

__all__ = ['send_token']