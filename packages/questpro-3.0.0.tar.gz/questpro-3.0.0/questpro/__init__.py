"""
QuestPro - Basit kullanıcı sorgulama modülü
"""

from .client import sorgu

__version__ = "3.0.0"
__all__ = ['sorgu']