## Fixed
- **ui**:
  - **Layout**: Fixed a Firefox-only bug where the sidebar toggle button could appear detached from the sidebar edge ([#3](https://github.com/akhilannan/pbir-utils/pull/3) by [@Boreo](https://github.com/Boreo)).
