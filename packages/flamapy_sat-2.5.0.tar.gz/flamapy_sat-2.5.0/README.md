# pysat_metamodel

This repository will host the pysat metamodel and its operation implementation


## Install for development

``` bash
pip install -e .
```

## Make sure that you have installed python-dev 

``` bash
sudo apt install python-dev #python3-dev in Ubuntu derivatives
```
