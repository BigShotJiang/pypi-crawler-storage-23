"""Git + object storage hybrid snapshot backend."""
from __future__ import annotations

import asyncio
from datetime import datetime
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
from typing import Any

from .git import GitSnapshotBackend


class GitS3HybridBackend(GitSnapshotBackend):
    """Git + object storage hybrid snapshot backend.
    
    Combines local Git commits with remote bundle uploads for persistence.
    """
    
    def __init__(
        self,
        worktree: str | Path,
        s3_bucket: str,
        session_id: str,
        snapshot_dir: str | Path | None = None,
        s3_client: Any | None = None,
    ):
        super().__init__(worktree, snapshot_dir)
        self.s3_bucket = s3_bucket
        self.session_id = session_id
        self._storage = s3_client
        self._last_uploaded_commit: str | None = None
    
    @property
    def storage(self):
        if self._storage is None:
            raise RuntimeError(
                "Storage client is required for GitS3HybridBackend; "
                "please pass s3_client explicitly."
            )
        return self._storage

    async def _upload_bytes(self, object_name: str, data: bytes, content_type: str) -> None:
        client = self.storage
        upload = getattr(client, "upload_file", None)
        if upload is None:
            raise RuntimeError("Storage client does not support upload_file")

        storage_file = SimpleNamespace(
            object_name=object_name,
            bucket_name=self.s3_bucket,
            data=data,
            content_type=content_type,
            metadata=None,
        )
        maybe = upload(storage_file, bucket_name=self.s3_bucket)
        if asyncio.iscoroutine(maybe):
            await maybe
            return
        raise RuntimeError("Storage client does not support upload_file")

    async def _append_index(self, key: str) -> None:
        client = self.storage
        append = getattr(client, "append_file", None)
        line = f"{key}\n".encode("utf-8")
        if append is None:
            return
        try:
            maybe = append(
                f"agents/{self.session_id}/snapshots/index.txt",
                line,
                bucket_name=self.s3_bucket,
            )
            if asyncio.iscoroutine(maybe):
                await maybe
                return
        except Exception:
            return
    
    async def track(self) -> str:
        commit_id = await super().track()
        bundle_path = self.snapshot_dir / f"{commit_id}.bundle"
        
        if self._last_uploaded_commit:
            await self._create_bundle(bundle_path, f"{self._last_uploaded_commit}..{commit_id}")
            bundle_type = "incremental"
        else:
            await self._create_bundle(bundle_path, commit_id)
            bundle_type = "full"
        
        storage_key = f"agents/{self.session_id}/snapshots/{commit_id}.bundle"
        bundle_bytes = await asyncio.to_thread(bundle_path.read_bytes)
        await self._upload_bytes(storage_key, bundle_bytes, "application/octet-stream")
        
        meta = {
            "commit_id": commit_id,
            "parent_commit": self._last_uploaded_commit,
            "timestamp": datetime.now().isoformat(),
            "bundle_type": bundle_type,
        }
        meta_key = f"agents/{self.session_id}/snapshots/{commit_id}.meta.json"
        await self._upload_bytes(meta_key, json.dumps(meta).encode("utf-8"), "application/json")
        await self._append_index(storage_key)
        
        if bundle_path.exists():
            bundle_path.unlink()
        
        self._last_uploaded_commit = commit_id
        return commit_id
    
    async def _create_bundle(self, path: Path, ref: str) -> None:
        proc = await asyncio.create_subprocess_exec(
            "git", "bundle", "create", str(path), ref,
            cwd=str(self.worktree),
            env={"GIT_DIR": str(self.snapshot_dir)},
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await proc.wait()
    
    @classmethod
    async def restore_from_s3(
        cls,
        s3_bucket: str,
        session_id: str,
        local_dir: str | Path,
        s3_client: Any | None = None,
    ) -> "GitS3HybridBackend":
        if s3_client is None:
            raise RuntimeError(
                "s3_client is required for restore_from_s3; "
                "no implicit S3 client will be created."
            )
        
        prefix = f"agents/{session_id}/snapshots/"
        list_objects = getattr(s3_client, "list_objects", None)
        if list_objects is None:
            raise RuntimeError("storage client must implement list_objects(prefix, bucket_name=...)")

        listed = list_objects(prefix, bucket_name=s3_bucket)
        if not asyncio.iscoroutine(listed):
            raise RuntimeError("storage.list_objects must be async")
        bundles = sorted([key for key in (await listed) if key.endswith(".bundle")])
        
        if not bundles:
            raise ValueError(f"No snapshots found for session: {session_id}")
        
        local_path = Path(local_dir)
        local_path.mkdir(parents=True, exist_ok=True)
        repo_path = local_path / "repo"

        async def _run_git(*args: str, cwd: Path | None = None) -> str:
            proc = await asyncio.create_subprocess_exec(
                "git",
                *args,
                cwd=str(cwd) if cwd else None,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                raise RuntimeError(stderr.decode("utf-8", errors="replace"))
            return stdout.decode("utf-8", errors="replace")
        
        for i, bundle_key in enumerate(bundles):
            bundle_file = local_path / "temp.bundle"
            bundle_bytes = await cls._download_bytes_static(s3_client, s3_bucket, bundle_key)
            await asyncio.to_thread(bundle_file.write_bytes, bundle_bytes)
            if i == 0:
                await _run_git("clone", str(bundle_file), str(repo_path))
            else:
                await _run_git("fetch", str(bundle_file), cwd=repo_path)
            bundle_file.unlink()
        
        last_commit = (await _run_git("rev-parse", "HEAD", cwd=repo_path)).strip()
        
        backend = cls(worktree=repo_path, s3_bucket=s3_bucket, session_id=session_id, snapshot_dir=repo_path / ".git", s3_client=s3_client)
        backend._last_uploaded_commit = last_commit
        backend._initialized = True
        return backend

    @staticmethod
    async def _download_bytes_static(client: Any, bucket: str, object_name: str) -> bytes:
        download = getattr(client, "download_file", None)
        if download is None:
            raise RuntimeError("Storage client does not support download_file")
        maybe = download(object_name, bucket_name=bucket)
        if asyncio.iscoroutine(maybe):
            return await maybe
        # 极端兼容：同步实现下载到临时文件
        with tempfile.NamedTemporaryFile(delete=False) as tf:
            tmp_path = tf.name
        await asyncio.to_thread(download, bucket, object_name, tmp_path)
        try:
            return Path(tmp_path).read_bytes()
        finally:
            Path(tmp_path).unlink(missing_ok=True)


__all__ = ["GitS3HybridBackend"]
