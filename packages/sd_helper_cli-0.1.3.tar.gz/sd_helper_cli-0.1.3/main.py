"""Entry point for direct execution."""

from sd_helper.cli import cli

if __name__ == "__main__":
    cli()
