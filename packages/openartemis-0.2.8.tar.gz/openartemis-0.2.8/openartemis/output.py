"""Output writers for JSON, TXT, and SRT per-post files."""

import json
import re
from pathlib import Path
from typing import Any


def sanitize_id(platform: str, raw_id: str) -> str:
    """Create a filesystem-safe identifier from platform and raw ID."""
    safe = re.sub(r"[^\w\-]", "_", str(raw_id))[:64]
    return f"{platform}_{safe}"


def segments_to_srt(segments: list[dict[str, Any]]) -> str:
    """Convert segments with start/end/text to SRT format."""
    lines: list[str] = []
    for i, seg in enumerate(segments, 1):
        start = seg.get("start", 0)
        end = seg.get("end", start + seg.get("duration", 0))
        text = seg.get("text", "").strip()
        if not text:
            continue
        start_srt = _sec_to_srt(start)
        end_srt = _sec_to_srt(end)
        lines.append(f"{i}\n{start_srt} --> {end_srt}\n{text}\n")
    return "\n".join(lines)


def _sec_to_srt(seconds: float) -> str:
    """Convert seconds to SRT timecode HH:MM:SS,mmm."""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds % 1) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def write_post(
    out_dir: Path,
    platform: str,
    post_id: str,
    data: dict[str, Any],
) -> None:
    """Write per-post JSON, TXT, and SRT files."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    base_id = sanitize_id(platform, post_id)
    base_path = out_dir / base_id

    segments = data.get("segments", [])
    full_text = data.get("full_text", "")

    # JSON
    with open(base_path.with_suffix(".json"), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    # TXT
    with open(base_path.with_suffix(".txt"), "w", encoding="utf-8") as f:
        f.write(full_text)

    # SRT
    srt_content = segments_to_srt(segments)
    with open(base_path.with_suffix(".srt"), "w", encoding="utf-8") as f:
        f.write(srt_content)
