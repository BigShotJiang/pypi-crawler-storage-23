"""Agent orchestrator — lead model plans, worker executes with workspace tools."""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from openartemis.agent.agent_tools import (
    execute_agent_tool,
    get_agent_workspace,
    get_all_agent_tools,
)
from openartemis.agent.rl_bot import customize_for_task
from openartemis.config import resolve_artemis_model

LEAD_SYSTEM = """You are a coding lead. Given a user request, create a step-by-step plan to build it.

First commit to ONE stack (e.g. "Vanilla Canvas in a single index.html", "Phaser 3 + Vite", "Pygame"). Do not list alternatives.

Output a JSON object:
{"stack": "your chosen stack in one short sentence", "steps": [
  {"id": 1, "action": "description of what to do", "file": "exact filename e.g. index.html or game.js"},
  ...
]}

Rules:
- Choose exactly one stack and state it. No "either X or Y".
- Every step that creates or edits a file must include "file" with the exact filename (e.g. index.html, style.css, game.js).
- Break into small, concrete steps; each step is one file write or one command.
- For web apps: create index.html, add JS/CSS as needed, then run server. Name every file.
- Max 50 steps. Output ONLY valid JSON, no markdown."""

WORKER_SYSTEM = """You are a coding worker. You execute ONE step at a time using your tools.

Tools: read_file, write_file, list_dir, run_terminal, take_screenshot.

- read_file(path) — read file contents
- write_file(path, content) — write or overwrite file
- list_dir(path) — list directory (default ".")
- run_terminal(command) — run command in workspace (e.g. "python -m http.server 8000")
- take_screenshot(url_or_path) — capture URL or file, get vision feedback (e.g. http://localhost:8000 after starting server)

Execute the step. For web apps: write HTML, start server, then take_screenshot to verify. Be concise."""


def _checkpoint_path(output_path: Path | None) -> Path | None:
    if output_path is None:
        return None
    return output_path.parent / (output_path.stem + ".checkpoint.json")


def run_agent_mode(
    user_request: str,
    lead_model: str = "gpt-4o",
    worker_model: str = "gpt-4o-mini",
    on_status: Callable[[str], None] | None = None,
    max_steps: int = 50,
    output_path: Path | None = None,
    resume_from_checkpoint: bool = False,
) -> str:
    """
    Run agent mode: lead plans, worker executes. Returns final report.
    If resume_from_checkpoint and a checkpoint exists next to output_path, resume from last step.
    """
    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    lead_model = resolve_artemis_model(lead_model) if isinstance(lead_model, str) and "artemis" in lead_model.lower() else lead_model
    worker_model = resolve_artemis_model(worker_model) if isinstance(worker_model, str) and "artemis" in worker_model.lower() else worker_model

    get_agent_workspace().mkdir(parents=True, exist_ok=True)
    status_path = (output_path.with_name(output_path.name + ".status") if output_path else None)
    checkpoint_path = _checkpoint_path(output_path)

    def _status(s: str) -> None:
        if on_status:
            on_status(s)
        if status_path:
            try:
                status_path.parent.mkdir(parents=True, exist_ok=True)
                status_path.write_text(s, encoding="utf-8")
            except Exception:
                pass

    def _write_checkpoint(steps: list, report_parts: list, step_index: int, lead_sys: str, worker_sys: str) -> None:
        if checkpoint_path is None:
            return
        try:
            checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
            checkpoint_path.write_text(json.dumps({
                "user_request": user_request,
                "steps": steps,
                "report_parts": report_parts,
                "step_index": step_index,
                "lead_system": lead_sys,
                "worker_system": worker_sys,
            }, indent=2), encoding="utf-8")
        except Exception:
            pass

    steps: list[dict] = []
    report_parts: list[str] = []
    lead_system = ""
    worker_system = ""
    start_index = 0

    if resume_from_checkpoint and checkpoint_path and checkpoint_path.exists():
        try:
            data = json.loads(checkpoint_path.read_text(encoding="utf-8"))
            steps = data.get("steps", [])
            report_parts = data.get("report_parts", [])
            start_index = min(data.get("step_index", 0), len(steps))
            lead_system = data.get("lead_system", "")
            worker_system = data.get("worker_system", "")
        except (json.JSONDecodeError, OSError):
            start_index = 0
            steps = []

    if not steps:
        _status("Creating plan...")
        customized = customize_for_task(user_request, model=lead_model)
        lead_system = customized["lead"]
        worker_system = customized["worker"]
        resp = client.chat.completions.create(
            model=lead_model,
            messages=[
                {"role": "system", "content": lead_system},
                {"role": "user", "content": user_request},
            ],
        )
        content = (resp.choices[0].message.content or "").strip()
        if content.startswith("```"):
            lines = content.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            content = "\n".join(lines)
        try:
            data = json.loads(content)
            steps = data.get("steps", [])[:max_steps]
        except json.JSONDecodeError:
            return "Could not create plan. Please try rephrasing."
        if not steps:
            return "No steps in plan."
        start_index = 0

    for idx in range(start_index, len(steps)):
        step = steps[idx]
        step_id = step.get("id", 0)
        action = step.get("action", "")
        _status(f"Step {step_id}: {action[:50]}...")
        messages = [
            {"role": "system", "content": worker_system},
            {"role": "user", "content": f"Step {step_id}: {action}"},
        ]
        for _ in range(8):
            resp = client.chat.completions.create(
                model=worker_model,
                messages=messages,
                tools=get_all_agent_tools(),
                tool_choice="auto",
            )
            msg = resp.choices[0].message
            msg_dict = {
                "role": msg.role,
                "content": msg.content or "",
                "tool_calls": [{"id": tc.id, "function": {"name": tc.function.name, "arguments": tc.function.arguments}} for tc in (msg.tool_calls or [])],
            }
            messages.append(msg_dict)

            if not msg.tool_calls:
                report_parts.append(f"Step {step_id}: {msg.content or '(no output)'}")
                break

            for tc in msg.tool_calls:
                name = tc.function.name
                try:
                    args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    args = {}
                result = execute_agent_tool(name, args)
                if name == "write_file":
                    _status(f"Writing {args.get('path', '')}...")
                elif name == "run_terminal":
                    _status(f"Running: {args.get('command', '')[:40]}...")
                elif name == "take_screenshot":
                    _status("Taking screenshot and reviewing...")
                messages.append({"role": "tool", "tool_call_id": tc.id, "content": result})
        else:
            report_parts.append(f"Step {step_id}: (max turns)")
        _write_checkpoint(steps, report_parts, idx + 1, lead_system, worker_system)

    report = "\n\n".join(report_parts)
    _status("Done")

    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            f"# Agent Report — {user_request}\n\n{datetime.now().isoformat()}\n\n---\n\n{report}",
            encoding="utf-8",
        )

    return report
