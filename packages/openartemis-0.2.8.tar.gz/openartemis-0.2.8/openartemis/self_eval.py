"""Self-eval scoring rubric: optional LLM call to score report completeness, citations, clarity."""

import os
from typing import Any


RUBRIC_PROMPT = """You are scoring a research report (1-5 on each dimension, 5 best).

User request: {user_request}

Report (excerpt):
{report_excerpt}

Score each dimension 1-5 and give one sentence of feedback. Reply in this exact format:
COMPLETENESS: <1-5> <one sentence>
CITATIONS: <1-5> <one sentence>
CLARITY: <1-5> <one sentence>
OVERALL: <1-5> <one sentence>
"""


def score_report(report: str, user_request: str, model: str = "gpt-4o-mini", max_excerpt: int = 4000) -> dict[str, Any]:
    """
    Score the report using a fixed rubric. Returns dict with scores (completeness, citations, clarity, overall)
    and feedback text. Returns empty dict on error or if OPENAI_API_KEY missing.
    """
    if not os.environ.get("OPENAI_API_KEY"):
        return {}
    excerpt = (report or "")[:max_excerpt]
    from openai import OpenAI
    client = OpenAI()
    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "user", "content": RUBRIC_PROMPT.format(user_request=user_request[:500], report_excerpt=excerpt)},
            ],
        )
        text = (resp.choices[0].message.content or "").strip()
        scores = {"completeness": 0, "citations": 0, "clarity": 0, "overall": 0, "feedback": text}
        for line in text.split("\n"):
            line = line.strip().upper()
            for key in ("COMPLETENESS", "CITATIONS", "CLARITY", "OVERALL"):
                if line.startswith(key + ":"):
                    try:
                        num = int(line.split(":")[1].strip().split()[0])
                        scores[key.lower()] = max(1, min(5, num))
                    except (ValueError, IndexError):
                        pass
                    break
        return scores
    except Exception:
        return {}


def self_eval_enabled() -> bool:
    return os.environ.get("OPENARTEMIS_SELF_EVAL", "").strip().lower() in ("1", "true", "yes")
