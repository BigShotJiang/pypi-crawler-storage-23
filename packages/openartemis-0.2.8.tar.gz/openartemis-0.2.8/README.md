# OpenArtemis

CLI tool to harvest transcripts from YouTube, TikTok, Instagram, and X (Twitter). User-friendly design inspired by Claude CLI — no coding required.

**Login required.** First run creates an admin account. Other users register and wait for admin approval. Approval requests are emailed to the admin.

**Chat mode** (default): Run `openartemis` for a persistent chat with **Artemis**, an AI that researches for you. Say "research X" or "find out about Y" and Artemis uses tools (transcripts, web search, webpage fetch). Use `/research <query>` for multi-agent deep research. Type `/` for mode menu, `/logout` or `/exit` to quit.

**Harvest mode**: `openartemis harvest` for guided step-by-step transcript download.

**Admin**: `openartemis admin` — manage users, approve requests, view usage. Admins have unlimited API access.

## Requirements

- **Python 3.10+**
- **ffmpeg** (required for yt-dlp and Whisper; must be on PATH)
  - Windows: `winget install ffmpeg` or download from [ffmpeg.org](https://ffmpeg.org)
  - Mac: `brew install ffmpeg`
  - Linux: `apt install ffmpeg` or `dnf install ffmpeg`
- **YouTube Data API key** (for YouTube search; set `YOUTUBE_API_KEY` or use `--youtube-api-key`)
- **ScrapingDog API key** (optional, for faster YouTube transcripts; set `SCRAPINGDOG_API_KEY`)
- **OpenAI API key** (for Artemis chat; set `OPENAI_API_KEY` — never commit your key)
- **Brave Search API key** (optional, for web search; set `BRAVE_SEARCH_API_KEY` — search.brave.com)

## Installation

**From PyPI** (run anywhere):

```bash
pip install openartemis
```

Then run:

```bash
openartemis
```

**Troubleshooting**: If `pip install openartemis` fails with "no matching distribution", ensure Python 3.10+ (`python --version`) and that pip can reach PyPI. Try `pip install --upgrade pip` first.

**From source** (development):

```bash
pip install -e .
playwright install chromium   # For browse_webpage (JS-heavy sites)
```

## Usage

### Interactive mode (no coding required)

Run without arguments for chat (login required):

```bash
openartemis
```

### Command-line mode

```bash
openartemis harvest   # Guided harvest (login required)
```

### Arguments

| Argument | Description | Default |
|----------|-------------|---------|
| `query` | Search query (omit for interactive mode) | - |
| `--platforms`, `-p` | Comma-separated: youtube,tiktok,instagram,x | youtube |
| `--max-results`, `-n` | Max results per platform | 10 |
| `--out-dir`, `-o` | Output directory | ./transcripts |
| `--youtube-api-key` | YouTube Data API key (or YOUTUBE_API_KEY env) | - |
| `--scrapingdog-api-key` | ScrapingDog API key (or SCRAPINGDOG_API_KEY env) | - |
| `--whisper-model`, `-m` | Whisper model: tiny,base,small,medium,large | base |
| `--interactive`, `-i` | Run in interactive mode | - |

### Agent Mode (long-running tasks)

Built for "send one prompt, walk away, come back to results." Agent Mode runs Plan (research), Agent (code + run), or Ask (code Q&A). Output is saved to `~/.openartemis/agent_output/`.

```bash
openartemis agent "Build a flappy bird clone"           # Foreground (see progress)
openartemis agent "Build a flappy bird clone" --background   # Background — run and sleep
openartemis agent-status                                # Check background runs
```

Workspace: `~/.openartemis/agent_workspace/`. Reports: `~/.openartemis/agent_output/{timestamp}_{task}.md`.

### Artemis Detective (multi-agent research)

Tell Artemis what to find — it uses a multi-agent pipeline: one orchestrator plans up to 5 tasks, five workers run in parallel (Brave search, transcript harvest, webpage fetch/browse), then results are synthesized into a report:

```bash
openartemis investigate "Find out everything about what happened to John Smith"
# Or run without args for interactive prompt:
openartemis investigate
```

Options: `--model gpt-4o-mini` (default, cheapest), `--out-dir ./detective_output`

Tools: `harvest_transcripts`, `brave_search`, `fetch_webpage`, `browse_webpage`, `list_transcripts`, `read_transcript`

### Admin panel

```bash
openartemis admin
```

Approve users, view usage, revoke access, create users directly.

### Other commands

```bash
openartemis logout   # Log out
openartemis config   # Show configuration help
```

Shows required env vars and where to get API keys.

### Output

Per-post files in `out_dir`:
- `{platform}_{id}.json` - Metadata + segments + full text
- `{platform}_{id}.txt` - Plain text transcript
- `{platform}_{id}.srt` - SRT subtitles

## Pipeline

- **YouTube**: Data API search → video IDs → ScrapingDog API (if key set) or youtube-transcript-api for captions; if none, download audio via yt-dlp → Whisper
- **TikTok/Instagram/X**: Web search (site: operator) → yt-dlp download + extract audio → Whisper
- **Research**: Multi-agent (orchestrator + 5 workers) — Brave Search, trafilatura (fetch_webpage), Playwright (browse_webpage), transcript harvest

## Auth

- Session expiry: 7 days
- Rate limit: 5 failed logins per 15 min per username
- Password policy: minimum 8 characters

## Token budget (non-admin / SaaS)

To keep usage budget-friendly for non-admin users:

- **OPENARTEMIS_MAX_CREDITS** — Per-session credits cap (e.g. `100`). Admins have no cap.
- **OPENARTEMIS_MAX_TOKENS** — Max tokens per completion (e.g. `2048` or `4096`), limiting response length.

Non-admin chats also send only the last 30 messages to the API (plus system prompt) to reduce input tokens. Run `openartemis config` for the full list of env vars.

## Publishing to PyPI

To publish a new version:

```bash
pip install build twine
python -m build
twine upload dist/*
```
