---
name: Slow Task
cron: "0 0 * * *"
active: true
connector: discord_igtm
---
sleep 10
