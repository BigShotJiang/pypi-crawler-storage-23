if __name__ == "__main__":
    raise Exception(
        "The library is not intended to be run directly. Please import it as a module in your project."
    )
