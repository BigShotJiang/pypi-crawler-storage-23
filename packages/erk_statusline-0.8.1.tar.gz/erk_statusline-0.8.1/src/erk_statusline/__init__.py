"""erk-statusline: Custom status line for Claude Code with robbyrussell theme style."""

__version__ = "0.8.1"
