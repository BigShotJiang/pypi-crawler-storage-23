"""TUI state management."""
