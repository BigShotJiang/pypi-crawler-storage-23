class ReservationError(Exception):
    """Base exception for train reservation."""


class LoginError(ReservationError):
    """Login failed or session expired."""


class SoldOutError(ReservationError):
    """No seats available."""


class NoResultsError(ReservationError):
    """No trains found."""


class NetworkError(ReservationError):
    """Network connection error."""
