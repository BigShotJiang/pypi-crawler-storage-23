# koreantrain

Unified Python API for Korean train reservation — supports both **SRT** and **KTX (Korail)** with a single interface.

## Installation

```bash
pip install koreantrain
```

## Usage

```python
from koreantrain import SRTService, KorailService, Passenger

# SRT
srt = SRTService("id", "pw")
trains = srt.search("수서", "부산", "20260301", "140000", time_limit="200000")
reservation = srt.reserve(trains[0], passengers=[Passenger.adult(2)])
print(reservation)  # [SRT] 03월 01일, 수서~부산(14:00~16:30) 53700원(2석), 구입기한 ...

# Korail (KTX) — same interface
korail = KorailService("id", "pw", train_type="ktx")
trains = korail.search("서울", "부산", "20260301", "140000", time_limit="200000")
reservation = korail.reserve(trains[0], passengers=[Passenger.adult(2)])

# Cancel
srt.cancel(reservation)
```

## Passenger Types

```python
Passenger.adult(count=1)
Passenger.child(count=1)
Passenger.senior(count=1)
Passenger.toddler(count=1)  # Korail only
```

## Seat Type

```python
from koreantrain import SeatType

srt.reserve(train, seat_type=SeatType.SPECIAL_FIRST)
# GENERAL_FIRST (default), GENERAL_ONLY, SPECIAL_FIRST, SPECIAL_ONLY
```

## Error Handling

```python
from koreantrain import LoginError, SoldOutError, NetworkError, ReservationError

try:
    srt.reserve(train)
except SoldOutError:
    print("매진")
except LoginError:
    print("로그인 만료")
except NetworkError:
    print("네트워크 오류")
```

## Dependencies

- [SRTrain](https://github.com/ryanking13/SRT) — SRT API
- [korail2](https://github.com/carpedm20/korail2) — Korail API
