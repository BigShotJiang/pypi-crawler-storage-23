# -*- coding: utf-8 -*-
# Python

"""Copyright (c) Alexander Fedotov.
This source code is licensed under the license found in the
LICENSE file in the root directory of this source tree.
"""
from .config import settings


def machine(): # arg=None):
    token = settings['github_token']
    settings['github_token'] = 'khp-'
    print('machine')


if __name__ == '__main__':
    machine()
    ...
