import { MainLayout } from './components/Layout/MainLayout';
import { Workspace } from './components/Layout/Workspace';


function App() {
  return (
    <MainLayout>
      <Workspace />
    </MainLayout>
  );
}

export default App;
