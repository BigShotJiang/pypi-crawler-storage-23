"""Python API client for cablefyi.com."""

__version__ = "0.1.0"
