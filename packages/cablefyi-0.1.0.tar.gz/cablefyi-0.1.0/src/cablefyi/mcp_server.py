"""MCP server for cablefyi."""

from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from cablefyi.api import CableFYI

mcp = FastMCP("cablefyi")


@mcp.tool()
def search_cablefyi(query: str) -> dict[str, Any]:
    """Search cablefyi.com for content matching the query."""
    with CableFYI() as api:
        return api.search(query)
