# cablefyi

Submarine cables and landing points API client — [cablefyi.com](https://cablefyi.com)

## Install

```bash
pip install cablefyi
```

## Quick Start

```python
from cablefyi.api import CableFYI

with CableFYI() as api:
    results = api.search("atlantic")
    print(results)
```

## License

MIT
