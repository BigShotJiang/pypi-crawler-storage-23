# 1. Core. Import every class/function from the compiled trust_free .so module
from .trust_free import (
    TRUST, 
    TRUSTRegressor, 
    Renet, 
    AdaptiveNetCV, 
    FeatureImportance, 
    turbosolve
)

# 2. Open Source Utilities. This line allows: from trust import datasets
from . import datasets

# 3. Optional: Export functions at top level for convenience
from .datasets import (
    make_correlated_regression,
    make_block_correlated_regression,
    make_toeplitz_regression
)

# 4. Designate the public API
__all__ = [
    'TRUST',
    'TRUSTRegressor', 
    'Renet', 
    'AdaptiveNetCV', 
    'FeatureImportance', 
    'turbosolve',
    'datasets',
    'make_correlated_regression',
    'make_block_correlated_regression',
    'make_toeplitz_regression'
]
