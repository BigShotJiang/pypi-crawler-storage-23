# aptpath-models

Consolidated Django ORM models for the Aptpath platform, published as a reusable pip package.

## Installation

```bash
pip install aptpath-models
```

Or directly from source:

```bash
pip install git+<repo-url>
```

## Usage

Add `aptpath_models` to `INSTALLED_APPS` in your Django settings:

```python
INSTALLED_APPS = [
    ...
    'aptpath_models',
]
```

Import models directly:

```python
from aptpath_models.models import Profile, Company, Internship, LMSCourse
```

## Package structure

```
aptpath_models/
  models/
    base.py              # Abstract base models
    neo4j_nodes.py       # Neo4j StructuredNode classes (neomodel)
    users.py             # MongoUser, MongoEmployer, AptPathAdmin, Profile, Permissions
    skills.py            # MongoSkill, MongoCategories, Language, MongoAccountType, MongoRole
    user_profile.py      # UserEducation, UserExperience, UserCertificate
    company.py           # Company, Employment, Invitation, Notification, Activity
    college.py           # College and related models
    courses.py           # MongoCourse, LMSSystem, CourseTemplates
    jobs.py              # Jobs, MongoApplications, JobTemplates, Assessments, DailyStreak
    learning_path.py     # LearningPath, LearningPathModule and templates
    assessments_tests.py # AptpathTests, Durationmodel and templates
    nav.py               # NavigationItem, NavigationSubheader
    xapi.py              # XAPIStatement
    moodle.py            # MoodleCourse, MoodleCourseCompletion, MoodleUser
    logs.py              # OperationLog (all user types)
    internship.py        # Internship, InternshipBatches, Coupon, LeaveRequest, etc.
    labs.py              # Lab, SkillBuilder, CodingAssessment, StudentTasks, etc.
    lms_partner.py       # LMSCourse, CourseEnrollmentPaymentDetails, UserCourseStatus
    blogs.py             # AptpathBlog, Blog and related content models
    employer_ext.py      # JobV2, JobApplicationsV2, Roles, InternJobProfile
    payment.py           # PaymentDetails
    meetings.py          # Recordings
```

## Requirements

- Django >= 4.2
- psycopg2-binary (PostgreSQL)
- neomodel >= 5.0 (Neo4j graph nodes)
- django-ckeditor (rich text blog content)
