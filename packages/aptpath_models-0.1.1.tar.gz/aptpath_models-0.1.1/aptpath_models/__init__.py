default_app_config = 'aptpath_models.apps.AptpathModelsConfig'
