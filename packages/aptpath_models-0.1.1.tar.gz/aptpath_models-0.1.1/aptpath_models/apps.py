from django.apps import AppConfig


class AptpathModelsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aptpath_models'
    verbose_name = 'Aptpath Models'
