"""
Internship platform models.
Covers internship programs, batches, applications, sessions, badges,
coupons, assessments, tasks, evaluations and announcements.
"""
import uuid

from django.contrib.postgres.fields import ArrayField
from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.utils import timezone

from .base import BaseModel, BaseModelProfile, BaseModelAdmin


# ---------------------------------------------------------------------------
# Reference / lookup tables (must be defined before Internship)
# ---------------------------------------------------------------------------

class BadgeTypes(models.Model):
    NAME_CHOICES = [
        ('level1', 'level1'),
        ('level2', 'level2'),
        ('level3', 'level3'),
    ]

    name = models.CharField(
        max_length=11, choices=NAME_CHOICES, default='level1', null=True, blank=True)
    badge_url = models.FileField(null=True, blank=True)

    def save(self, *args, **kwargs):
        if BadgeTypes.objects.filter(name=self.name).exclude(id=self.id).exists():
            raise ValidationError(
                f"A BadgeType with the name '{self.name}' already exists.")
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.id} - {self.name}"

    class Meta:
        db_table = 'badge-types'
        unique_together = ('name',)


class TechnologyStack(BaseModelProfile):
    name = models.CharField(max_length=100, null=True, blank=True)
    codejudge_test_id = models.IntegerField(null=True, blank=True)
    price = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return f"{self.name} - {self.codejudge_test_id}"

    class Meta:
        db_table = 'technology_stack'


class InternshipLevels(BaseModelProfile):
    name = models.CharField(max_length=100, null=True, blank=True)
    badge_logo = models.FileField(null=True, blank=True)

    def __str__(self):
        return f"{self.name}"

    class Meta:
        db_table = 'internship_level'


class InternCategory(BaseModelProfile):
    name = models.CharField(max_length=100, null=True, blank=True)
    apply_internship_level = models.ManyToManyField(
        InternshipLevels, blank=True, related_name='applicable_internships')
    qualified_internship_level = models.ManyToManyField(
        InternshipLevels, blank=True, related_name='qualified_internships')

    def __str__(self):
        return f"{self.name}"

    class Meta:
        db_table = 'intern_category'


class InternAvailability(BaseModelProfile):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'intern_availability'


class InternshipOffers(models.Model):
    name = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return f"{self.name}"

    class Meta:
        db_table = 'internship_offers'


class RetakeAssessmentDetails(models.Model):
    name = models.CharField(max_length=255, null=True, blank=True)
    amount = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return self.name or f"Assessment {self.id}"

    class Meta:
        db_table = 'retake_assessment_details'


# ---------------------------------------------------------------------------
# Internship (core)
# ---------------------------------------------------------------------------

class Internship(BaseModelAdmin):
    STATUS_CHOICES = (
        ('INPROGRESS', 'inprogress'),
        ('STARTED', 'started'),
        ('COMPLETED', 'completed'),
    )
    TYPE_CHOICES = [
        ('template', 'Template'),
        ('mentor', 'Mentor'),
        ('company', 'Company'),
    ]

    name = models.CharField(max_length=150, null=True, blank=True)
    about = models.CharField(max_length=250, null=True, blank=True)
    skills = models.ManyToManyField('aptpath_models.MongoSkill', blank=True)
    paid = models.BooleanField(default=False)
    amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    mentor = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    internship_logo = models.FileField(blank=True)
    status = models.CharField(max_length=100, choices=STATUS_CHOICES, default='started')
    type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    mentor_approved = models.BooleanField(default=False)
    total_available_slots = models.IntegerField(default=0)
    start_date_time = models.DateTimeField(null=True, blank=True, default=timezone.now)
    end_date_time = models.DateTimeField(null=True, blank=True, default=timezone.now)
    batch_size = models.IntegerField(null=True, blank=True)
    latest_technology = models.BooleanField(default=False)
    badge_type = models.ForeignKey(BadgeTypes, on_delete=models.CASCADE, null=True, blank=True)
    assessment_count = models.IntegerField(default=0)
    labs = models.ManyToManyField('self', null=True, blank=True, symmetrical=False)
    discount_percentage = models.IntegerField(default=0)
    project_duration = models.IntegerField(default=90)
    prereq_deadline = models.IntegerField(default=10)
    project_id = models.CharField(max_length=4, unique=True, editable=False, null=True, blank=True)
    allow_enrollment = models.BooleanField(default=True)
    offer = models.ForeignKey(InternshipOffers, on_delete=models.CASCADE, null=True, blank=True)
    internship_level = models.ManyToManyField(InternshipLevels, blank=True)
    technology_stack = models.ManyToManyField(TechnologyStack, blank=True)
    rating = models.FloatField(default=0.0)
    rating_count = models.IntegerField(default=0)
    project_document = models.FileField(null=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.badge_type:
            badge_type, _ = BadgeTypes.objects.get_or_create(name='level1')
            self.badge_type = badge_type
        if not self.project_id:
            self.project_id = self.generate_project_id()
        super().save(*args, **kwargs)

    @staticmethod
    def generate_project_id():
        last_project = (
            Internship.objects.filter(project_id__isnull=False)
            .order_by('-project_id').first()
        )
        if last_project and last_project.project_id:
            return Internship.increment_project_id(last_project.project_id)
        return 'AAAB'

    @staticmethod
    def increment_project_id(current_id):
        if not current_id:
            return 'AAAB'
        chars = list(current_id)
        for i in range(len(chars) - 1, -1, -1):
            if chars[i] != 'Z':
                chars[i] = chr(ord(chars[i]) + 1)
                return ''.join(chars[:i + 1] + ['A'] * (len(chars) - i - 1))
            chars[i] = 'A'
        return ''.join(['A'] * (len(chars) + 1))

    def __str__(self):
        return f"{self.id} - {self.name} - {self.type}"

    class Meta:
        db_table = 'internship'


# ---------------------------------------------------------------------------
# Internship batches
# ---------------------------------------------------------------------------

class InternshipBatches(BaseModel):
    ENROLLMENT_CONTINUATION_CHOICES = (
        ('continue_enrollment', 'Continue Enrollment'),
        ('pause_enrollment', 'Pause Enrollment'),
    )
    STATUS_CHOICES = (
        ('active', 'Active'),
        ('closed', 'Closed'),
    )

    internship = models.ForeignKey(
        Internship, on_delete=models.CASCADE, null=True, blank=True,
        related_name='internship_batches')
    mentor = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True,
        related_name='internship_mentor')
    batch_no = models.IntegerField(blank=True, null=True)
    batch_name = models.CharField(max_length=100, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    currently_active = models.BooleanField(default=True)
    users_count = models.IntegerField(default=0)
    batch_size = models.IntegerField(default=25)
    start_date = models.DateTimeField(null=True, blank=True)
    end_date = models.DateTimeField(null=True, blank=True)
    enrollment_continuation = models.CharField(
        max_length=20, choices=ENROLLMENT_CONTINUATION_CHOICES,
        default='continue_enrollment')

    class Meta:
        db_table = 'internship-batches'


# ---------------------------------------------------------------------------
# Internship invitations & applications
# ---------------------------------------------------------------------------

class AdminMentorInvitation(BaseModelAdmin):
    TYPE_CHOICES = (
        ('employer', 'Employer'),
        ('admin', 'Admin'),
    )
    STATUS_CHOICES = (
        ('invited', 'Invited'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
    )

    email = models.EmailField()
    invitation_code = models.UUIDField(unique=True, default=uuid.uuid4)
    admin = models.ForeignKey(
        'aptpath_models.AptPathAdmin', on_delete=models.CASCADE, null=True, blank=True)
    mentor = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='invited')
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='admin')
    invited_by = models.ForeignKey(
        'aptpath_models.MongoEmployer', on_delete=models.CASCADE,
        null=True, blank=True, related_name='invited_by_employer')
    internship_batch = models.ForeignKey(
        InternshipBatches, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.email}"

    class Meta:
        db_table = 'admin-mentor-invitation'


class InternshipApplications(BaseModel):
    ACTION_CHOICES = (
        ('Applied', 'Applied'),
        ('Rejected', 'Rejected'),
        ('Accepted', 'Accepted'),
    )
    STATUS_CHOICES = (
        ('active', 'Active'),
        ('discontinued', 'Discontinued'),
        ('dropped_out', 'Dropped_Out'),
    )

    internship = models.ForeignKey(Internship, on_delete=models.SET_NULL, null=True)
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    application_status = models.CharField(
        max_length=100, choices=ACTION_CHOICES, default='Applied', null=True, blank=True)
    date_of_apply = models.DateField(auto_now=True)
    standbox_url = models.URLField(
        max_length=200, null=True, blank=True,
        default='https://codesandbox.io/embed/jovial-rosalind-c4lnnx?fontsize=14&hidenavigation=1&theme=dark')
    jupiternotebook_url = models.URLField(max_length=200, null=True, blank=True)
    batch_no = models.IntegerField(default=0)
    last_visited = models.DateTimeField(default=timezone.now)
    status = models.CharField(
        max_length=20, choices=STATUS_CHOICES, default='active', null=True, blank=True)

    def __str__(self):
        return (f"{self.internship} - {self.profile} - "
                f"{self.application_status} - {self.batch_no}")

    class Meta:
        db_table = 'internship_applications'
        unique_together = ('internship', 'profile')


# ---------------------------------------------------------------------------
# Featured / home-page associations
# ---------------------------------------------------------------------------

class MeetOurMentors(models.Model):
    mentor = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.mentor}"

    class Meta:
        db_table = 'meet-our-mentors'


class CompanyAssociated(models.Model):
    company = models.ForeignKey(
        'aptpath_models.Company', on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.company}"

    class Meta:
        db_table = 'company-associated'


class CollegeAssociated(models.Model):
    college = models.ForeignKey(
        'aptpath_models.College', on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.college}"

    class Meta:
        db_table = 'college-associated'


# ---------------------------------------------------------------------------
# Likes, ratings, certificates, signatures
# ---------------------------------------------------------------------------

class InternshipLikeStatus(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    liked_status = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.id} - {self.profile} - {self.internship} - {self.liked_status}"

    class Meta:
        db_table = 'internship_like_status'


class InternshipRatings(models.Model):
    RATING_CHOICES = [(i, str(i)) for i in range(6)]

    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    batch = models.ForeignKey(InternshipBatches, on_delete=models.CASCADE, null=True, blank=True)
    rating = models.IntegerField(choices=RATING_CHOICES, default=0)

    class Meta:
        db_table = 'internship-ratings'


class Signature(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    signature = models.FileField(blank=True)

    def __str__(self):
        return f"{self.id} - {self.profile}"

    class Meta:
        db_table = 'signature'


class InternshipCertificate(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    issue_date = models.DateTimeField(null=True, blank=True)
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    batch = models.ForeignKey(InternshipBatches, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.id} - {self.profile}"

    class Meta:
        db_table = 'internship-certificate'


class InternshipCourseLikedStatus(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    course = models.ForeignKey(
        'aptpath_models.LMSCourse', on_delete=models.CASCADE, null=True, blank=True)
    liked_status = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.id} - {self.profile} - {self.course} - {self.liked_status}"

    class Meta:
        db_table = 'internship-course-liked-status'


class InternshipUserCourseCompletion(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    lms_course_id = models.IntegerField(blank=True, null=True)
    modules_completed = models.IntegerField(blank=True, null=True)
    total_modules = models.IntegerField(blank=True, null=True)
    courses = models.ManyToManyField('aptpath_models.LMSCourse', blank=True)
    last_visited = models.DateTimeField(default=timezone.now, null=True)

    class Meta:
        db_table = 'internship-user-course-completion'


# ---------------------------------------------------------------------------
# Payment / cart
# ---------------------------------------------------------------------------

class PaymentHistory(models.Model):
    PAYMENT_STATUS_CHOICES = (
        ('paid', 'paid'),
        ('cancelled', 'cancelled'),
    )
    PAYMENT_TYPE_CHOICES = (
        ('credit', 'credit'),
        ('debit', 'debit'),
    )

    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_status = models.CharField(
        max_length=100, choices=PAYMENT_STATUS_CHOICES, null=True, blank=True)
    payment_type = models.CharField(
        max_length=100, choices=PAYMENT_TYPE_CHOICES, null=True, blank=True)
    payment_date = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.id} - {self.profile} - {self.internship}"

    class Meta:
        db_table = 'payment-history'


class InternshipCart(models.Model):
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    course = models.ForeignKey(
        'aptpath_models.LMSCourse', on_delete=models.CASCADE, null=True, blank=True)
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    tech_stack = models.ForeignKey(TechnologyStack, on_delete=models.CASCADE, null=True, blank=True)
    retake_assessment = models.ForeignKey(
        RetakeAssessmentDetails, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.id} - {self.profile} - {self.internship}"

    class Meta:
        db_table = 'internship_cart'


# ---------------------------------------------------------------------------
# Sessions & attendance
# ---------------------------------------------------------------------------

class InternshipSession(models.Model):
    title = models.CharField(max_length=200, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    session_material = models.FileField(null=True, blank=True)
    project = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    start_date = models.DateTimeField(null=True, blank=True)
    end_date = models.DateTimeField()
    batch = models.IntegerField(default=0)
    color = models.CharField(max_length=10, null=True, blank=True)
    meeting_url = models.URLField(max_length=1000, blank=True, null=True)
    meeting_id = models.CharField(
        max_length=500, blank=True, null=True,
        help_text='Microsoft Teams Online Meeting ID for direct updates')

    def __str__(self):
        return (f"{self.id} - {self.project_id} - {self.project.name} - "
                f"{self.start_date} - {self.end_date} - {self.batch}")

    class Meta:
        db_table = 'internship-session'


class SessionAttendance(models.Model):
    STATUS_CHOICES = [
        ('present', 'Present'),
        ('absent', 'Absent'),
        ('leave', 'Leave'),
    ]

    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    InternshipSession = models.ForeignKey(
        InternshipSession, on_delete=models.CASCADE, null=True, blank=True)
    attendance = models.CharField(max_length=11, choices=STATUS_CHOICES, null=True, blank=True)
    created_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return (f"{self.id} - {self.profile} - "
                f"{self.InternshipSession} - {self.attendance}")

    class Meta:
        db_table = 'session-attendance'


# ---------------------------------------------------------------------------
# Feedback, notes, trending, testimonials
# ---------------------------------------------------------------------------

class InternshipNotes(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    notes = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.id} - {self.profile}"

    class Meta:
        db_table = 'internship-notes'


class InternshipFeedback(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    feedback_text = models.TextField(null=True, blank=True)
    feedback_rating = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return f"{self.id} - {self.profile}"

    class Meta:
        db_table = 'internship-feedback'


class TrendingInternships(models.Model):
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    zscore = models.FloatField(default=0.0)

    def __str__(self):
        return f"{self.id} - {self.internship} - {self.zscore}"

    class Meta:
        db_table = 'trending_internships'


class Testimonials(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    feedback = models.TextField(null=True, blank=True)
    rating = models.FloatField(default=0.0)

    def __str__(self):
        return f"{self.id} - {self.profile} - {self.feedback}"

    class Meta:
        db_table = 'testimonials'


class InternshipInterested(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.id} - {self.profile} - {self.internship}"

    class Meta:
        db_table = 'internship_interested'


class InternSkilledCourses(models.Model):
    profile = models.ForeignKey('aptpath_models.Profile', on_delete=models.CASCADE)
    course = models.ForeignKey('aptpath_models.LMSCourse', on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.id} - {self.profile} - {self.course}"

    class Meta:
        db_table = 'interns_skilled_courses'


# ---------------------------------------------------------------------------
# Intern assessment & category determination
# ---------------------------------------------------------------------------

class InternAssessment(BaseModelProfile):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    technology_stack = models.ForeignKey(
        TechnologyStack, on_delete=models.CASCADE, null=True, blank=True)
    assessment_url = models.CharField(max_length=300, null=True, blank=True)
    assessment_id = models.UUIDField(null=True, blank=True)
    status = models.CharField(max_length=100, null=True, blank=True)
    function_program_score = models.IntegerField(null=True, blank=True)
    program_quality_score = models.IntegerField(null=True, blank=True)
    intern_category = models.ForeignKey(
        InternCategory, on_delete=models.CASCADE, null=True, blank=True)
    intern_availability = models.ForeignKey(
        InternAvailability, on_delete=models.CASCADE, null=True, blank=True)
    assessement_completed_at = models.DateTimeField(null=True, blank=True)
    assessement_expires_at = models.DateTimeField(null=True, blank=True)
    show_progressor_popup = models.BooleanField(default=False)

    class Meta:
        db_table = 'intern_assessment'


# ---------------------------------------------------------------------------
# Badges, tokens
# ---------------------------------------------------------------------------

class Badges(models.Model):
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    badge_type = models.ForeignKey(BadgeTypes, on_delete=models.CASCADE, null=True, blank=True)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return (f"{self.id} - {self.internship_id} - "
                f"{self.profile} - {self.date} - {self.badge_type}")

    class Meta:
        db_table = 'badges'


class ProfileTokens(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    token_amount = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.id} - {self.profile} - {self.token_amount}"

    class Meta:
        db_table = 'profile-tokens'


class ProfileTokenTransactions(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    problem = models.ForeignKey(
        'aptpath_models.LabSubModule', on_delete=models.CASCADE, null=True, blank=True)
    received_time = models.DateTimeField(default=timezone.now, null=True)
    tokens_recieved = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return (f"{self.id} - {self.profile} - {self.problem_id} - "
                f"{self.received_time} - {self.tokens_recieved}")

    class Meta:
        db_table = 'profile-token-transactions'


# ---------------------------------------------------------------------------
# Discount, website data, announcements, coupons
# ---------------------------------------------------------------------------

class CollegeDiscount(models.Model):
    college = models.ForeignKey(
        'aptpath_models.College', on_delete=models.CASCADE, null=True, blank=True)
    internship = models.ManyToManyField(Internship, blank=True)
    discount_percentage = models.IntegerField(null=True, blank=True)
    offer = models.ForeignKey(InternshipOffers, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.id} - {self.college} - {self.discount_percentage} - {self.offer}"

    class Meta:
        db_table = 'college_discount'


class WebsiteData(models.Model):
    projects = models.IntegerField(null=True, blank=True)
    mentors = models.IntegerField(null=True, blank=True)
    interns = models.IntegerField(null=True, blank=True)
    rating = models.FloatField(null=True, blank=True)
    sessions = models.IntegerField(null=True, blank=True)
    courses = models.IntegerField(null=True, blank=True)
    hours_mentored = models.IntegerField(null=True, blank=True)
    flash_message = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'website_data'


class OffersAnnouncementsTemplates(BaseModelAdmin):
    TYPE_CHOICES = [
        ('offer', 'Offer'),
        ('announcement', 'Announcement'),
        ('event', 'Event'),
    ]

    template_name = models.CharField(max_length=100, null=True, blank=True)
    type = models.CharField(max_length=100, choices=TYPE_CHOICES, null=True, blank=True)
    image = models.FileField(null=True, blank=True)

    def __str__(self):
        return f"{self.id} - {self.template_name} - {self.type}"

    class Meta:
        db_table = 'offers_announcements_templates'


class OffersAnnouncements(BaseModelAdmin):
    template = models.ForeignKey(
        OffersAnnouncementsTemplates, on_delete=models.CASCADE, null=True, blank=True)
    title = models.CharField(max_length=100, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    tech_stack = models.ManyToManyField(TechnologyStack, blank=True)
    intern_category = models.ManyToManyField(InternCategory, blank=True)

    def __str__(self):
        return f"{self.id} - {self.title} - {self.start_date} - {self.end_date}"

    class Meta:
        db_table = 'offers_announcements'


class VoiceOfTrust(BaseModelAdmin):
    username = models.CharField(max_length=100, null=True, blank=True)
    college_name = models.CharField(max_length=100, null=True, blank=True)
    designation = models.CharField(max_length=100, null=True, blank=True)
    photo_url = models.FileField(null=True, blank=True)
    feedback = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'voice_of_trust'


class Coupon(BaseModelAdmin):
    TYPE_CHOICES = (
        ('eligibility', 'Eligibility'),
        ('campaign', 'Campaign'),
    )

    coupon_type = models.CharField(max_length=20, choices=TYPE_CHOICES, null=True, blank=True)
    coupon_code = models.CharField(max_length=20, unique=True)
    discount_percentage = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    intern_category = models.ManyToManyField(InternCategory, null=True, blank=True)
    tech_stack = models.ManyToManyField(TechnologyStack, null=True, blank=True)

    def __str__(self):
        return self.coupon_code

    def save(self, *args, **kwargs):
        if self.coupon_code:
            self.coupon_code = self.coupon_code.upper()
        super().save(*args, **kwargs)

    class Meta:
        db_table = 'coupon'


class CouponUsage(models.Model):
    coupon = models.ForeignKey(Coupon, on_delete=models.CASCADE, null=True, blank=True)
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    course = models.ForeignKey(
        'aptpath_models.LMSCourse', on_delete=models.CASCADE, null=True, blank=True)
    used_on = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return (f"{self.id} - {self.coupon} - {self.profile} - "
                f"{self.project} - {self.course} - {self.used_on}")

    class Meta:
        db_table = 'coupon_usage'


class AutomatedEmailNotifications(models.Model):
    EMAIL_TYPE_CHOICES = [
        ('missing_tech_stack_email', 'Missing Tech Stack email'),
        ('pending_assessment_email', 'Pending Assessment email'),
        ('no_project_application_email', 'No Project Application email'),
        ('absence_from_learning_sessions_email', 'Absence from Learning Sessions email'),
        ('pending_task_evaluation', 'Pending Task Evaluation'),
    ]

    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE,
        related_name='automated_email_notifications', null=True, blank=True)
    email_type = models.CharField(
        max_length=50, choices=EMAIL_TYPE_CHOICES, blank=True, null=True)
    unsubscribe = models.BooleanField(default=False)
    count = models.PositiveIntegerField(default=1)
    last_email_sent = models.DateTimeField(auto_now_add=True)
    uuid = models.UUIDField(default=uuid.uuid4, unique=True)

    class Meta:
        db_table = 'automated_email_notifications'


# ---------------------------------------------------------------------------
# Leave request
# ---------------------------------------------------------------------------

class LeaveRequest(BaseModelProfile):
    ROLE_CHOICES = (
        ('intern', 'Intern'),
        ('mentor', 'Mentor'),
    )
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )

    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.SET_NULL,
        blank=True, null=True, related_name='leave_requests')
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, null=True, blank=True)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    reason = models.TextField()
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    batch = models.ForeignKey(InternshipBatches, on_delete=models.CASCADE, null=True, blank=True)
    substitute_mentor = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.SET_NULL,
        blank=True, null=True, related_name='substitute_mentor')
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    attachment = models.FileField(upload_to='leave_attachments/', null=True, blank=True)

    def __str__(self):
        return f"{self.profile} - {self.role} - {self.status}"

    class Meta:
        db_table = 'leave_request'


# ---------------------------------------------------------------------------
# Company internships & performance
# ---------------------------------------------------------------------------

class CompanyInternships(BaseModelProfile):
    STATUS_CHOICES = (
        ('pending_approval', 'Pending Approval'),
        ('live', 'Live'),
        ('pause', 'Pause'),
        ('archived', 'Archived'),
    )

    company = models.ForeignKey(
        'aptpath_models.Company', on_delete=models.SET_NULL, null=True, blank=True)
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.SET_NULL, null=True, blank=True)
    internship = models.ForeignKey(Internship, on_delete=models.SET_NULL, null=True, blank=True)
    new_tech_stack = models.CharField(max_length=100, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending_approval')
    minimum_enrollment = models.IntegerField(null=True, blank=True)
    fixed_date = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return (f"{self.company} - {self.profile} - {self.internship} - "
                f"{self.new_tech_stack} - ({self.status})")

    class Meta:
        db_table = 'company_internships'


# ---------------------------------------------------------------------------
# Final project evaluation
# ---------------------------------------------------------------------------

class FinalProjectEvaluation(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    project = models.ForeignKey(Internship, on_delete=models.CASCADE, null=True, blank=True)
    batch = models.IntegerField(blank=True, null=True)
    technical_skills = models.IntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(70)], null=True, blank=True)
    attendance_marks = models.IntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(10)], null=True, blank=True)
    communication_skills = models.IntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(10)], null=True, blank=True)
    participation_marks = models.IntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(10)], null=True, blank=True)
    corporate_fit = models.BooleanField(default=False)
    remarks = models.TextField(null=True, blank=True)
    total_percentage = models.IntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(100)], null=True, blank=True)

    class Meta:
        db_table = 'final_project_evaluation'


# ---------------------------------------------------------------------------
# Forgot password
# ---------------------------------------------------------------------------

class ForgotPasswordInvitation(models.Model):
    email = models.EmailField()
    uuid_token = models.UUIDField(default=uuid.uuid4, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'forgot_password_invitation'


class OtherTechStack(BaseModelProfile):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    preferred_tech_stack = models.CharField(max_length=150, null=True, blank=True)

    class Meta:
        db_table = 'other_tech_stack'
