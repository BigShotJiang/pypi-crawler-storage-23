from django.db import models


class BaseModel(models.Model):
    """Base model for MongoUser-owned records."""
    created_by = models.ForeignKey(
        'aptpath_models.MongoUser',
        on_delete=models.SET_NULL,
        related_name='created_%(class)s_set',
        blank=True, null=True, default=None,
    )
    created_date = models.DateTimeField(auto_now_add=True)
    modified_date = models.DateTimeField(auto_now=True)
    modified_by = models.ForeignKey(
        'aptpath_models.MongoUser',
        on_delete=models.SET_NULL,
        related_name='modified_%(class)s_set',
        blank=True, null=True, default=None,
    )
    active = models.BooleanField(default=True)
    neo_id = models.IntegerField(null=True, blank=True)

    class Meta:
        abstract = True


class BaseModelEmployer(models.Model):
    """Base model for MongoEmployer-owned records."""
    created_by = models.ForeignKey(
        'aptpath_models.MongoEmployer',
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_%(class)s_set',
        default=None, blank=True,
    )
    created_date = models.DateTimeField(auto_now_add=True)
    modified_date = models.DateTimeField(auto_now=True)
    modified_by = models.ForeignKey(
        'aptpath_models.MongoEmployer',
        on_delete=models.SET_NULL,
        null=True,
        related_name='modified_%(class)s_set',
        default=None, blank=True,
    )
    active = models.BooleanField(default=True)
    neo_id = models.IntegerField(null=True, blank=True)

    class Meta:
        abstract = True


class BaseModelProfile(models.Model):
    """Base model for Profile-owned records."""
    created_by = models.ForeignKey(
        'aptpath_models.Profile',
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_%(class)s_set',
        default=None, blank=True,
    )
    created_date = models.DateTimeField(auto_now_add=True)
    modified_date = models.DateTimeField(auto_now=True)
    deleted_date = models.DateTimeField(blank=True, null=True)
    modified_by = models.ForeignKey(
        'aptpath_models.Profile',
        on_delete=models.SET_NULL,
        null=True,
        related_name='modified_%(class)s_set',
        default=None, blank=True,
    )
    active = models.BooleanField(default=True)
    neo_id = models.IntegerField(null=True, blank=True)

    class Meta:
        abstract = True


class BaseModelAdmin(models.Model):
    """Base model for AptPathAdmin-owned records (also covers BaseModelAptpathAdmin)."""
    created_by = models.ForeignKey(
        'aptpath_models.AptPathAdmin',
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_%(class)s_set',
        default=None, blank=True,
    )
    created_date = models.DateTimeField(auto_now_add=True)
    modified_date = models.DateTimeField(auto_now=True)
    modified_by = models.ForeignKey(
        'aptpath_models.AptPathAdmin',
        on_delete=models.SET_NULL,
        null=True,
        related_name='modified_%(class)s_set',
        default=None, blank=True,
    )
    active = models.BooleanField(default=True)
    neo_id = models.IntegerField(null=True, blank=True)

    class Meta:
        abstract = True


# Alias used in internship app
BaseModelAptpathAdmin = BaseModelAdmin


class GenericModel(models.Model):
    """Timestamp-only abstract base (used by LMS partner models)."""
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True
