"""xAPI statement model for learning record tracking."""
from django.db import models


class XAPIStatement(models.Model):
    actor = models.JSONField()
    verb = models.JSONField()
    object = models.JSONField()
    context = models.JSONField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'xapi_statement'
