"""aptpath_models.models — flat export of all consolidated Django models."""

from .base import (
    BaseModel,
    BaseModelEmployer,
    BaseModelProfile,
    BaseModelAdmin,
    BaseModelAptpathAdmin,
    GenericModel,
)

from .neo4j_nodes import (
    NeoCollege,
    AccountType,
    Skill,
    Job,
    NeoCourse,
    Learner,
    LearningPathNeo,
    Employer,
    NeoCompany,
    Category,
    Education,
    Certificate,
    Experience,
    Application,
    AptpathTestsNeo,
    ActivityNeo,
    LearningPathModuleNeo,
)

from .users import (
    CustomUserManager,
    MongoUser,
    MongoUserDetail,
    MongoEmployer,
    AptPathAdmin,
    Profile,
    Permissions,
    UserInvitation,
)

from .skills import (
    MongoAccountType,
    Language,
    MongoSkill,
    MongoCategories,
    MongoRole,
)

from .user_profile import (
    UserEducation,
    UserExperience,
    UserCertificate,
)

from .company import (
    Company,
    Employment,
    Invitation,
    Notification,
    Activity,
    EmployerInvitationLog,
)

from .college import (
    College,
    OperationLogCollege,
    CollegeInvitation,
    CollegeDepartment,
    CollegeDegree,
    CollegeAdmin,
    CollegeAdminInvitation,
    AssociatedCollege,
    OtherCollege,
)

from .courses import (
    LMSSystem,
    MongoCourse,
    HiddenCourses,
    UserCourseCompletion,
    CourseTemplates,
    CompanyCourseTemplates,
)

from .jobs import (
    Benefits,
    ExperienceJobForm,
    EmplomentTypes,
    Jobs,
    MongoApplications,
    JobTemplates,
    CompanyJobTemplates,
    Interviewer,
    InterviewDetails,
    Assessments,
    Sessionstreak,
    DailyStreak,
)

from .learning_path import (
    LearningPath,
    LearningPathModule,
    LearningPathTemplates,
    LearningPathModuleTemplates,
    CompanyLearningPathTemplates,
)

from .assessments_tests import (
    Durationmodel,
    AptpathTests,
    AptpathTestsTemplates,
    CompanyTestsTemplates,
)

from .nav import (
    IconChoices,
    NavigationItem,
    NavigationSubheader,
)

from .xapi import XAPIStatement

from .moodle import (
    MoodleCourse,
    MoodleCourseCompletion,
    MoodleUser,
)

from .logs import (
    OperationLog,
    OperationLogEmployer,
    OperationLogAptpathAdmin,
)

from .internship import (
    BadgeTypes,
    TechnologyStack,
    InternshipLevels,
    InternCategory,
    InternAvailability,
    InternshipOffers,
    RetakeAssessmentDetails,
    Internship,
    InternshipBatches,
    AdminMentorInvitation,
    InternshipApplications,
    MeetOurMentors,
    CompanyAssociated,
    CollegeAssociated,
    InternshipLikeStatus,
    InternshipRatings,
    Signature,
    InternshipCertificate,
    InternshipCourseLikedStatus,
    InternshipUserCourseCompletion,
    PaymentHistory,
    InternshipCart,
    InternshipSession,
    SessionAttendance,
    InternshipNotes,
    InternshipFeedback,
    TrendingInternships,
    Testimonials,
    InternshipInterested,
    InternSkilledCourses,
    InternAssessment,
    Badges,
    ProfileTokens,
    ProfileTokenTransactions,
    CollegeDiscount,
    WebsiteData,
    OffersAnnouncementsTemplates,
    OffersAnnouncements,
    VoiceOfTrust,
    Coupon,
    CouponUsage,
    AutomatedEmailNotifications,
    LeaveRequest,
    CompanyInternships,
    FinalProjectEvaluation,
    ForgotPasswordInvitation,
    OtherTechStack,
)

from .labs import (
    Lab,
    SkillBuilder,
    CodingAssessment,
    TestCase,
    McqQuestion,
    McqOption,
    WrittenAssessment,
    LabModule,
    LabSubModule,
    LabSubmoduleProgress,
    TaskDetails,
    Attachments,
    StudentTaskBlueprint,
    StudentTasks,
    StudentTasksPerformanceQuestions,
    StudentTasksPerformanceQuestionScore,
    StudentTaskFeedback,
)

from .lms_partner import (
    LearningManagementSystemPartner,
    AiCertsCategory,
    AicertsNewsletter,
    LMSCourse,
    CourseEnrollmentPaymentDetails,
    UserCourseStatus,
    AICertsContactUs,
    LMSCountryPrices,
    LMSStates,
    InternshipSuggestedCourses,
)

from .blogs import (
    AptpathBlogType,
    AptpathBlog,
    AptpathBlogContent,
    BlogType,
    Blog,
    BlogContent,
)

from .employer_ext import (
    InternshipPerformance,
    Roles,
    InternJobProfile,
    JobDepartment,
    JobMode,
    JobV2,
    JobApplicationsV2,
    InternProfileViewByCompany,
)

from .payment import PaymentDetails

from .meetings import Recordings

__all__ = [
    # base
    'BaseModel', 'BaseModelEmployer', 'BaseModelProfile', 'BaseModelAdmin',
    'BaseModelAptpathAdmin', 'GenericModel',
    # neo4j
    'NeoCollege', 'AccountType', 'Skill', 'Job', 'NeoCourse', 'Learner',
    'LearningPathNeo', 'Employer', 'NeoCompany', 'Category', 'Education',
    'Certificate', 'Experience', 'Application', 'AptpathTestsNeo', 'ActivityNeo',
    'LearningPathModuleNeo',
    # users
    'CustomUserManager', 'MongoUser', 'MongoUserDetail', 'MongoEmployer',
    'AptPathAdmin', 'Profile', 'Permissions', 'UserInvitation',
    # skills
    'MongoAccountType', 'Language', 'MongoSkill', 'MongoCategories', 'MongoRole',
    # user_profile
    'UserEducation', 'UserExperience', 'UserCertificate',
    # company
    'Company', 'Employment', 'Invitation', 'Notification', 'Activity',
    'EmployerInvitationLog',
    # college
    'College', 'OperationLogCollege', 'CollegeInvitation', 'CollegeDepartment',
    'CollegeDegree', 'CollegeAdmin', 'CollegeAdminInvitation', 'AssociatedCollege',
    'OtherCollege',
    # courses
    'LMSSystem', 'MongoCourse', 'HiddenCourses', 'UserCourseCompletion',
    'CourseTemplates', 'CompanyCourseTemplates',
    # jobs
    'Benefits', 'ExperienceJobForm', 'EmplomentTypes', 'Jobs', 'MongoApplications',
    'JobTemplates', 'CompanyJobTemplates', 'Interviewer', 'InterviewDetails',
    'Assessments', 'Sessionstreak', 'DailyStreak',
    # learning_path
    'LearningPath', 'LearningPathModule', 'LearningPathTemplates',
    'LearningPathModuleTemplates', 'CompanyLearningPathTemplates',
    # assessments_tests
    'Durationmodel', 'AptpathTests', 'AptpathTestsTemplates', 'CompanyTestsTemplates',
    # nav
    'IconChoices', 'NavigationItem', 'NavigationSubheader',
    # xapi
    'XAPIStatement',
    # moodle
    'MoodleCourse', 'MoodleCourseCompletion', 'MoodleUser',
    # logs
    'OperationLog', 'OperationLogEmployer', 'OperationLogAptpathAdmin',
    # internship
    'BadgeTypes', 'TechnologyStack', 'InternshipLevels', 'InternCategory',
    'InternAvailability', 'InternshipOffers', 'RetakeAssessmentDetails', 'Internship',
    'InternshipBatches', 'AdminMentorInvitation', 'InternshipApplications',
    'MeetOurMentors', 'CompanyAssociated', 'CollegeAssociated', 'InternshipLikeStatus',
    'InternshipRatings', 'Signature', 'InternshipCertificate',
    'InternshipCourseLikedStatus', 'InternshipUserCourseCompletion', 'PaymentHistory',
    'InternshipCart', 'InternshipSession', 'SessionAttendance', 'InternshipNotes',
    'InternshipFeedback', 'TrendingInternships', 'Testimonials', 'InternshipInterested',
    'InternSkilledCourses', 'InternAssessment', 'Badges', 'ProfileTokens',
    'ProfileTokenTransactions', 'CollegeDiscount', 'WebsiteData',
    'OffersAnnouncementsTemplates', 'OffersAnnouncements', 'VoiceOfTrust', 'Coupon',
    'CouponUsage', 'AutomatedEmailNotifications', 'LeaveRequest', 'CompanyInternships',
    'FinalProjectEvaluation', 'ForgotPasswordInvitation', 'OtherTechStack',
    # labs
    'Lab', 'SkillBuilder', 'CodingAssessment', 'TestCase', 'McqQuestion', 'McqOption',
    'WrittenAssessment', 'LabModule', 'LabSubModule', 'LabSubmoduleProgress',
    'TaskDetails', 'Attachments', 'StudentTaskBlueprint', 'StudentTasks',
    'StudentTasksPerformanceQuestions', 'StudentTasksPerformanceQuestionScore',
    'StudentTaskFeedback',
    # lms_partner
    'LearningManagementSystemPartner', 'AiCertsCategory', 'AicertsNewsletter',
    'LMSCourse', 'CourseEnrollmentPaymentDetails', 'UserCourseStatus', 'AICertsContactUs',
    'LMSCountryPrices', 'LMSStates', 'InternshipSuggestedCourses',
    # blogs
    'AptpathBlogType', 'AptpathBlog', 'AptpathBlogContent',
    'BlogType', 'Blog', 'BlogContent',
    # employer_ext
    'InternshipPerformance', 'Roles', 'InternJobProfile', 'JobDepartment', 'JobMode',
    'JobV2', 'JobApplicationsV2', 'InternProfileViewByCompany',
    # payment
    'PaymentDetails',
    # meetings
    'Recordings',
]
