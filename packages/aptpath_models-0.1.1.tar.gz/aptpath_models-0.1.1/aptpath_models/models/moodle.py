"""
Read-only mirror models for Moodle's PostgreSQL tables.
These are used to query Moodle data from Django without modifying schema.
"""
from django.db import models


class MoodleCourse(models.Model):
    id = models.BigAutoField(primary_key=True, db_column='id')
    category = models.BigIntegerField(default=0)
    sortorder = models.BigIntegerField(default=0)
    fullname = models.CharField(max_length=254, default='')
    shortname = models.CharField(max_length=255, default='')
    idnumber = models.CharField(max_length=100, default='')
    summary = models.TextField(blank=True, null=True)
    summaryformat = models.SmallIntegerField(default=0)
    format = models.CharField(max_length=21, default='topics')
    showgrades = models.BooleanField(default=True)
    newsitems = models.SmallIntegerField(default=1)
    startdate = models.BigIntegerField(default=0)
    enddate = models.BigIntegerField(default=0)
    relativedatesmode = models.BooleanField(default=False)
    marker = models.BigIntegerField(default=0)
    maxbytes = models.BigIntegerField(default=0)
    legacyfiles = models.SmallIntegerField(default=0)
    showreports = models.SmallIntegerField(default=0)
    visible = models.BooleanField(default=True)
    visibleold = models.BooleanField(default=True)
    downloadcontent = models.BooleanField(blank=True, null=True)
    groupmode = models.SmallIntegerField(default=0)
    groupmodeforce = models.SmallIntegerField(default=0)
    defaultgroupingid = models.BigIntegerField(default=0)
    lang = models.CharField(max_length=30, default='')
    calendartype = models.CharField(max_length=30, default='')
    theme = models.CharField(max_length=50, default='')
    timecreated = models.BigIntegerField(default=0)
    timemodified = models.BigIntegerField(default=0)
    requested = models.BooleanField(default=False)
    enablecompletion = models.BooleanField(default=False)
    completionnotify = models.BooleanField(default=False)
    cacherev = models.BigIntegerField(default=0)
    originalcourseid = models.BigIntegerField(blank=True, null=True)
    showactivitydates = models.BooleanField(default=False)
    showcompletionconditions = models.BooleanField(blank=True, null=True)

    class Meta:
        db_table = 'mdl_course'


class MoodleCourseCompletion(models.Model):
    complete_id = models.BigAutoField(primary_key=True, db_column='id')
    userid = models.BigIntegerField(default=0)
    course = models.BigIntegerField(default=0)
    timeenrolled = models.BigIntegerField(default=0)
    timestarted = models.BigIntegerField(default=0)
    timecompleted = models.BigIntegerField(null=True, default=None)
    reaggregate = models.BigIntegerField(default=0)

    class Meta:
        db_table = 'mdl_course_completions'
        unique_together = [('userid', 'course')]
        indexes = [
            models.Index(fields=['userid']),
            models.Index(fields=['course']),
            models.Index(fields=['timecompleted']),
        ]


class MoodleUser(models.Model):
    auth = models.CharField(max_length=20, default='manual')
    confirmed = models.BooleanField(default=False)
    policyagreed = models.BooleanField(default=False)
    deleted = models.BooleanField(default=False)
    suspended = models.BooleanField(default=False)
    mnethostid = models.BigIntegerField(default=0)
    username = models.CharField(max_length=100, default='')
    password = models.CharField(max_length=255, default='')
    idnumber = models.CharField(max_length=255, default='')
    firstname = models.CharField(max_length=100, default='')
    lastname = models.CharField(max_length=100, default='')
    email = models.CharField(max_length=100, default='')
    emailstop = models.BooleanField(default=False)
    phone1 = models.CharField(max_length=20, default='')
    phone2 = models.CharField(max_length=20, default='')
    institution = models.CharField(max_length=255, default='')
    department = models.CharField(max_length=255, default='')
    address = models.CharField(max_length=255, default='')
    city = models.CharField(max_length=120, default='')
    country = models.CharField(max_length=2, default='')
    lang = models.CharField(max_length=30, default='en')
    calendartype = models.CharField(max_length=30, default='gregorian')
    theme = models.CharField(max_length=50, default='')
    timezone = models.CharField(max_length=100, default='99')
    firstaccess = models.BigIntegerField(default=0)
    lastaccess = models.BigIntegerField(default=0)
    lastlogin = models.BigIntegerField(default=0)
    currentlogin = models.BigIntegerField(default=0)
    lastip = models.CharField(max_length=45, default='')
    secret = models.CharField(max_length=15, default='')
    picture = models.BigIntegerField(default=0)
    description = models.TextField(null=True)
    descriptionformat = models.SmallIntegerField(default=1)
    mailformat = models.BooleanField(default=True)
    maildigest = models.BooleanField(default=False)
    maildisplay = models.SmallIntegerField(default=2)
    autosubscribe = models.BooleanField(default=True)
    trackforums = models.BooleanField(default=False)
    timecreated = models.BigIntegerField(default=0)
    timemodified = models.BigIntegerField(default=0)
    trustbitmask = models.BigIntegerField(default=0)
    imagealt = models.CharField(max_length=255, null=True)
    lastnamephonetic = models.CharField(max_length=255, null=True)
    firstnamephonetic = models.CharField(max_length=255, null=True)
    middlename = models.CharField(max_length=255, null=True)
    alternatename = models.CharField(max_length=255, null=True)
    moodlenetprofile = models.CharField(max_length=255, null=True)

    class Meta:
        db_table = 'mdl_user'
