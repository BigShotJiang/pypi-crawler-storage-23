from django.db import models
from django.core.exceptions import ValidationError

from .base import BaseModel, BaseModelEmployer


class MongoAccountType(BaseModel):
    account_name = models.CharField(max_length=100)
    account_description = models.CharField(max_length=100)
    account_id = models.IntegerField(unique=True)

    def __str__(self):
        return self.account_name

    class Meta:
        db_table = 'account-types'


class Language(BaseModel):
    name = models.CharField(max_length=150)

    def __str__(self):
        return self.name


class MongoSkill(BaseModelEmployer):
    name = models.CharField(max_length=100)
    company = models.ForeignKey(
        'aptpath_models.Company', on_delete=models.CASCADE, null=True, blank=True)

    def save(self, *args, **kwargs):
        if MongoSkill.objects.filter(name=self.name).exclude(id=self.id).exists():
            raise ValidationError(f"A Skill with the name '{self.name}' already exists.")
        super().save(*args, **kwargs)

    def __str__(self):
        if self.company:
            return f"{self.id} - {self.name} - {self.company}"
        return f"{self.id} - {self.name}"

    class Meta:
        db_table = 'skills'
        unique_together = ('name',)


class MongoCategories(BaseModel):
    category_name = models.CharField(max_length=100)
    category_image = models.FileField(blank=True, null=True)

    def __str__(self):
        return self.category_name

    class Meta:
        db_table = 'categories'
        unique_together = ('category_name',)


class MongoRole(BaseModel):
    role_name = models.CharField(max_length=100)

    class Meta:
        db_table = 'roles'
