"""Learning path and module models."""
from django.db import models

from .base import BaseModelEmployer


class LearningPath(BaseModelEmployer):
    role_name = models.CharField(max_length=100, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    role_level = models.CharField(max_length=100, null=True, blank=True)
    is_enabled = models.BooleanField(default=True)
    learning_path_module = models.ManyToManyField(
        'aptpath_models.LearningPathModule', null=True, blank=True)

    def __str__(self):
        return f"{self.role_name}  - {self.is_enabled}"

    class Meta:
        db_table = 'learning_path'


class LearningPathModule(BaseModelEmployer):
    TYPE_CHOICES = (
        ('COURSE', 'course'),
        ('TEST', 'test'),
        ('ACTIVITY', 'activity'),
    )

    type = models.CharField(max_length=100, null=True, blank=True, choices=TYPE_CHOICES)
    course = models.ForeignKey(
        'aptpath_models.MongoCourse', on_delete=models.SET_NULL, null=True, blank=True)
    test = models.ForeignKey(
        'aptpath_models.AptpathTests', on_delete=models.SET_NULL, null=True, blank=True)
    activity = models.ForeignKey(
        'aptpath_models.Activity', on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.type

    class Meta:
        db_table = 'learning_path_module'


class LearningPathTemplates(BaseModelEmployer):
    TEMPLATE_TYPE_CHOICES = (
        ('aptpath', 'aptpath'),
        ('company', 'company'),
    )

    role_name = models.CharField(max_length=100, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    role_level = models.CharField(max_length=100, null=True, blank=True)
    is_enabled = models.BooleanField(default=True)
    learning_path_module = models.ManyToManyField(
        'aptpath_models.LearningPathModuleTemplates', null=True, blank=True)
    template_type = models.CharField(
        max_length=100, null=True, blank=True,
        choices=TEMPLATE_TYPE_CHOICES, default='company')

    def __str__(self):
        return f"{self.role_name}  - {self.is_enabled}"

    class Meta:
        db_table = 'learning_path_templates'


class LearningPathModuleTemplates(BaseModelEmployer):
    TYPE_CHOICES = (
        ('COURSE', 'course'),
        ('TEST', 'test'),
        ('ACTIVITY', 'activity'),
    )

    type = models.CharField(max_length=100, null=True, blank=True, choices=TYPE_CHOICES)
    course = models.ForeignKey(
        'aptpath_models.MongoCourse', on_delete=models.SET_NULL, null=True, blank=True)
    test = models.ForeignKey(
        'aptpath_models.AptpathTests', on_delete=models.SET_NULL, null=True, blank=True)
    activity = models.ForeignKey(
        'aptpath_models.Activity', on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.type

    class Meta:
        db_table = 'learning_path_module_templates'


class CompanyLearningPathTemplates(BaseModelEmployer):
    company = models.ForeignKey(
        'aptpath_models.Company', on_delete=models.CASCADE, null=True, blank=True)
    learningpath_template = models.ForeignKey(
        LearningPathTemplates, on_delete=models.CASCADE, null=True, blank=True)
    is_enabled = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.company} - {self.learningpath_template} - {self.is_enabled}"

    class Meta:
        db_table = 'company-learningpath-templates'
