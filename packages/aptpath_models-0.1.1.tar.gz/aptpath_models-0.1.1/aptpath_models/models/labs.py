"""
Lab, skill-builder, module, sub-module, assessment and task models.
"""
from django.core.exceptions import ValidationError
from django.db import models

from .base import BaseModelAdmin


# ---------------------------------------------------------------------------
# Lab & SkillBuilder
# ---------------------------------------------------------------------------

class Lab(BaseModelAdmin):
    name = models.CharField(max_length=255, null=True, blank=True)
    about = models.TextField(null=True, blank=True)
    logo = models.FileField(blank=True)
    estimated_time = models.PositiveIntegerField(null=True, blank=True)
    skills = models.ManyToManyField('aptpath_models.MongoSkill', blank=True)
    tech_stack = models.ManyToManyField('aptpath_models.TechnologyStack', blank=True)

    class Meta:
        db_table = 'lab'


class SkillBuilder(BaseModelAdmin):
    TYPE_CHOICES = [
        ('mandatory', 'Mandatory'),
        ('optional', 'Optional'),
    ]

    tech_stack = models.ForeignKey(
        'aptpath_models.TechnologyStack',
        on_delete=models.CASCADE, related_name='skill_builders')
    type = models.CharField(max_length=10, choices=TYPE_CHOICES, null=True, blank=True)
    order = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.tech_stack.name} - {self.type} - {self.order}"

    class Meta:
        db_table = 'skill_builder'


# ---------------------------------------------------------------------------
# Assessments (coding, MCQ, written)
# ---------------------------------------------------------------------------

class CodingAssessment(models.Model):
    title = models.CharField(max_length=200, null=True, blank=True)
    problem_statement = models.TextField(null=True, blank=True)
    constraint = models.TextField(null=True, blank=True)
    starter_code = models.TextField(null=True, blank=True)
    handlerFunction = models.TextField(null=True, blank=True)
    starterFunctionName = models.TextField(null=True, blank=True)
    order = models.IntegerField(null=True, blank=True)
    token_amout = models.IntegerField(default=0)
    test_cases = models.JSONField(null=True, blank=True)

    def __str__(self):
        if self.token_amout:
            return f"{self.id} - {self.title} - {self.token_amout}"
        return f"{self.id} - {self.title}"

    def clean(self):
        super().clean()
        if self.test_cases:
            if not isinstance(self.test_cases, list):
                raise ValidationError('Test cases must be a list of dictionaries.')
            for case in self.test_cases:
                if not isinstance(case, dict):
                    raise ValidationError('Each test case must be a dictionary.')

    class Meta:
        db_table = 'coding-assessment'


class TestCase(models.Model):
    TYPE_CHOICES = [
        ('sample', 'Sample'),
        ('hidden', 'Hidden'),
    ]

    input = models.TextField(null=True, blank=True)
    output = models.TextField(null=True, blank=True)
    explanation = models.TextField(null=True, blank=True)
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, null=True, blank=True)
    coding_assessment = models.ForeignKey(
        CodingAssessment, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.id} - {self.type}"

    class Meta:
        db_table = 'testcase'


class McqQuestion(models.Model):
    question = models.TextField()
    multiple_answer = models.BooleanField(default=False)
    token_amout = models.IntegerField(default=1)

    def __str__(self):
        return f"{self.id} - {self.question}"

    class Meta:
        db_table = 'mcq-question'


class McqOption(models.Model):
    question = models.ForeignKey(McqQuestion, on_delete=models.CASCADE)
    option = models.TextField()
    is_answer = models.BooleanField(default=False, null=True, blank=True)

    def __str__(self):
        return f"{self.id} - {self.question_id} - {self.option}"

    class Meta:
        db_table = 'mcq-option'


class WrittenAssessment(models.Model):
    question = models.TextField()
    answer = models.TextField(null=True, blank=True)
    token_amout = models.IntegerField(default=1)

    def __str__(self):
        return f"{self.id} - {self.question}"

    class Meta:
        db_table = 'written-assesment'


# ---------------------------------------------------------------------------
# Lab modules & sub-modules
# ---------------------------------------------------------------------------

class LabModule(models.Model):
    TYPE_CHOICES = [
        ('lab', 'Lab'),
        ('notes', 'Notes'),
    ]
    LAB_TYPE_CHOICES = [
        ('standbox', 'Standbox'),
        ('jupiternotebook', 'Jupyter Notebook'),
    ]

    name = models.CharField(max_length=150, null=True, blank=True)
    lab = models.ForeignKey(Lab, on_delete=models.CASCADE, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    type = models.CharField(max_length=5, choices=TYPE_CHOICES, null=True, blank=True)
    lab_type = models.CharField(max_length=15, choices=LAB_TYPE_CHOICES, null=True, blank=True)
    order = models.IntegerField(default=0)

    class Meta:
        db_table = 'internship-module'


class LabSubModule(models.Model):
    TYPE_CHOICES = [
        ('description', 'Description'),
        ('example', 'Example'),
        ('coding_assessment', 'Coding'),
        ('mcq', 'MCQ'),
        ('written', 'Written'),
        ('video', 'Video'),
    ]

    title = models.CharField(max_length=150, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    module = models.ForeignKey(LabModule, on_delete=models.CASCADE, null=True, blank=True)
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, null=True, blank=True)
    coding_problem = models.ForeignKey(
        CodingAssessment, on_delete=models.CASCADE, blank=True, null=True)
    mcqs = models.ForeignKey(McqQuestion, on_delete=models.CASCADE, blank=True, null=True)
    written_assessment = models.ForeignKey(
        WrittenAssessment, on_delete=models.CASCADE, blank=True, null=True)
    video_url = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'internship-submodule'


class LabSubmoduleProgress(models.Model):
    STATUS_CHOICES = [
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
    ]

    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    lab = models.ForeignKey(Lab, on_delete=models.CASCADE, null=True, blank=True)
    submodule = models.ForeignKey(LabSubModule, on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, null=True, blank=True)
    marks = models.CharField(max_length=10, null=True, blank=True)
    comments = models.TextField(null=True, blank=True)
    internship = models.ForeignKey(
        'aptpath_models.Internship', on_delete=models.CASCADE, null=True, blank=True)

    class Meta:
        db_table = 'internship-submodule-progress'


# ---------------------------------------------------------------------------
# Student tasks
# ---------------------------------------------------------------------------

class TaskDetails(models.Model):
    STATUS_CHOICES = [
        ('not started', 'Not Started'),
        ('ongoing', 'Ongoing'),
        ('completed', 'Completed'),
        ('missed', 'Missed'),
    ]

    title = models.CharField(max_length=150, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    assigned_by = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(max_length=11, choices=STATUS_CHOICES, null=True, blank=True)
    task_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.id} - {self.title} - {self.assigned_by} - {self.status}"

    class Meta:
        db_table = 'task_details'


class Attachments(models.Model):
    tasks = models.ForeignKey(TaskDetails, on_delete=models.CASCADE, null=True, blank=True)
    attachments = models.FileField(blank=True)

    def __str__(self):
        return f"{self.id} - {self.tasks.title}"

    class Meta:
        db_table = 'attachments'


class StudentTaskBlueprint(BaseModelAdmin):
    STATUS_CHOICES = [
        ('open', 'Open'),
        ('close', 'Close'),
    ]

    title = models.CharField(max_length=150, null=False, blank=False, default='Task Title')
    description = models.TextField(null=True, blank=True)
    mentor = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(max_length=11, choices=STATUS_CHOICES, default='open')
    start_date = models.DateTimeField(null=True, blank=True)
    end_date = models.DateTimeField(null=True, blank=True)
    project = models.ForeignKey(
        'aptpath_models.Internship', on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.id} - {self.mentor} - {self.status}"

    class Meta:
        db_table = 'student_task_blueprint'


class StudentTasks(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('completed', 'Completed'),
    ]

    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    student_task_blueprint = models.ForeignKey(
        StudentTaskBlueprint, on_delete=models.CASCADE, null=True, blank=True)
    internship = models.ForeignKey(
        'aptpath_models.Internship', on_delete=models.CASCADE, null=True, blank=True)
    batch = models.ForeignKey(
        'aptpath_models.InternshipBatches', on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(
        max_length=11, choices=STATUS_CHOICES, default='pending', null=True, blank=True)
    marks = models.IntegerField(default=0)
    total_marks = models.IntegerField(default=50)
    created_date = models.DateTimeField(auto_now_add=True)
    file_submitted_date = models.DateTimeField(null=True, blank=True)
    file = models.FileField(null=True, blank=True)
    note = models.TextField(null=True, blank=True)
    evaluated = models.BooleanField(default=False)
    start_date = models.DateTimeField(null=True, blank=True)
    end_date = models.DateTimeField(null=True, blank=True)
    code_link = models.URLField(max_length=200, null=True, blank=True)
    merge_request = models.BooleanField(default=False)
    feedback = models.TextField(null=True, blank=True)
    rejcted_count = models.IntegerField(default=0)

    def __str__(self):
        return (f"{self.id} - {self.profile} - "
                f"{self.student_task_blueprint} - {self.internship}")

    class Meta:
        db_table = 'student_tasks'


class StudentTasksPerformanceQuestions(models.Model):
    question = models.TextField()
    marks = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.id} - {self.question}"

    class Meta:
        db_table = 'student_tasks_performance_questions'


class StudentTasksPerformanceQuestionScore(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, related_name='student_profile')
    mentor = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, related_name='mentor_profile')
    student_tasks_performance_question = models.ForeignKey(
        StudentTasksPerformanceQuestions, on_delete=models.CASCADE, null=True, blank=True)
    student_task = models.ForeignKey(StudentTasks, on_delete=models.CASCADE, null=True, blank=True)
    score = models.IntegerField()

    def __str__(self):
        return (f"{self.student_task_id} - {self.profile} - "
                f"{self.mentor} - {self.student_tasks_performance_question_id}")

    class Meta:
        db_table = 'student_tasks_performance_questions_score'


class StudentTaskFeedback(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE,
        related_name='student_feedback_profile')
    mentor = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE,
        related_name='mentor_feedback_profile')
    student_task = models.ForeignKey(StudentTasks, on_delete=models.CASCADE, null=True, blank=True)
    feedback = models.TextField()

    def __str__(self):
        return f"{self.id} - {self.student_task_id} - {self.feedback}"

    class Meta:
        db_table = 'student_task_feedback'
