"""Employer extension models: job profiles, job postings, and applications."""
from django.db import models
from django.db.models import Max
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.postgres.fields import ArrayField

from .base import BaseModelEmployer, BaseModelAdmin


class InternshipPerformance(models.Model):
    company = models.OneToOneField(
        'aptpath_models.Company',
        on_delete=models.CASCADE,
        related_name='performance_record',
        primary_key=True,
    )
    previous_completion_rate = models.DecimalField(
        max_digits=5, decimal_places=2, null=True, blank=True)
    current_completion_rate = models.DecimalField(
        max_digits=5, decimal_places=2, default=0.00)
    last_updated = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'internship_performance'

    def __str__(self):
        return f"Performance for {self.company} - Current: {self.current_completion_rate}%"


class Roles(models.Model):
    tech_stack = models.ForeignKey(
        'aptpath_models.TechnologyStack', on_delete=models.CASCADE, related_name='roles')
    skills = models.ManyToManyField('aptpath_models.MongoSkill', related_name='role_set')
    role_name = models.CharField(max_length=255)

    class Meta:
        db_table = 'tech_roles'

    def __str__(self):
        return self.role_name


class InternJobProfile(models.Model):
    YEAR_OF_STUDY_CHOICES = [
        ('1st Year', '1st Year'),
        ('2nd Year', '2nd Year'),
        ('3rd Year', '3rd Year'),
        ('4th Year', '4th Year'),
        ('5th Year+', '5th Year+'),
    ]
    WORK_TYPE_CHOICES = [
        ('remote', 'Remote'),
        ('hybrid', 'Hybrid'),
        ('onsite', 'Onsite'),
        ('any', 'Any'),
    ]
    WORK_MODE_CHOICES = [
        ('full-time', 'Full-time'),
        ('part-time', 'Part-time'),
        ('freelance', 'Freelance'),
        ('contract', 'Contract'),
        ('any', 'Any'),
    ]
    AVAILABILITY_CHOICES = [
        ('Immediate', 'Immediate'),
        ('1 month', '1 month'),
        ('2 months', '2 months'),
        ('3 months', '3 months'),
        ('flexible', 'Flexible'),
    ]

    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, related_name='job_profile')
    location = models.CharField(max_length=150, blank=True, null=True)
    education = models.ForeignKey(
        'aptpath_models.UserEducation', on_delete=models.CASCADE, related_name='intern_job_education')
    year_of_study = models.CharField(max_length=20, choices=YEAR_OF_STUDY_CHOICES)
    gpa = models.FloatField(null=True, blank=True)
    resume = models.FileField()
    linkedin_link = models.URLField(null=True, blank=True)
    github_link = models.URLField(null=True, blank=True)
    portfolio_link = models.URLField(null=True, blank=True)
    personal_link = models.URLField(null=True, blank=True)
    work_type = models.CharField(max_length=20, choices=WORK_TYPE_CHOICES)
    work_mode = models.CharField(max_length=20, choices=WORK_MODE_CHOICES, default='any')
    availability = models.CharField(max_length=20, choices=AVAILABILITY_CHOICES)
    preferred_location = ArrayField(
        models.CharField(max_length=100), blank=True, null=True, default=list)
    open_to_any_location = models.BooleanField(default=False, null=True, blank=True)
    professsional_bio = models.TextField(null=True, blank=True)
    intern_role = models.ForeignKey(
        Roles, on_delete=models.SET_NULL, related_name='intern_job_profiles', null=True, blank=True)

    class Meta:
        db_table = 'intern_job_profile'

    def __str__(self):
        return f"InternJobProfile-{self.id}"


class JobDepartment(BaseModelAdmin):
    name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = 'job_department'

    def __str__(self):
        return self.name if self.name else f"JobDepartment-{self.id}"


class JobMode(BaseModelAdmin):
    name = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        db_table = 'job_mode'

    def __str__(self):
        return self.name if self.name else f"JobMode-{self.id}"


class JobV2(BaseModelEmployer):
    job_title = models.CharField(max_length=200, null=True, blank=True)
    department = models.ForeignKey(
        JobDepartment, on_delete=models.SET_NULL, null=True, blank=True)
    job_description = models.TextField(null=True, blank=True)
    intern_level = models.ForeignKey(
        'aptpath_models.InternCategory', on_delete=models.SET_NULL, null=True, blank=True)
    experience_level = models.ForeignKey(
        'aptpath_models.ExperienceJobForm', on_delete=models.SET_NULL, null=True, blank=True)
    job_mode = models.ForeignKey(
        JobMode, on_delete=models.SET_NULL, null=True, blank=True)
    job_type = models.ForeignKey(
        'aptpath_models.EmplomentTypes', on_delete=models.SET_NULL, null=True, blank=True)
    salary = models.CharField(max_length=30, null=True, blank=True)
    number_of_positions = models.IntegerField(null=True, blank=True)
    tech_stack_skills = models.ManyToManyField('aptpath_models.MongoSkill', blank=True)
    mandatory_courses = models.ManyToManyField('aptpath_models.LMSCourse', blank=True)
    company = models.ForeignKey(
        'aptpath_models.Company', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='jobs_v2')

    class Meta:
        db_table = 'jobs_v2'

    def __str__(self):
        return self.job_title if self.job_title else f"JobV2-{self.id}"


class JobApplicationsV2(BaseModelEmployer):
    APPLICATION_STATUS_CHOICES = [
        ('Applied', 'Applied'),
        ('Shortlisted', 'Shortlisted'),
        ('Qualified', 'Qualified'),
        ('Hired', 'Hired'),
        ('Onhold', 'On Hold'),
        ('Offered', 'Offered'),
        ('Rejected', 'Rejected'),
        ('Accepted', 'Accepted'),
        ('Declined', 'Declined'),
    ]

    job = models.ForeignKey(
        JobV2, on_delete=models.SET_NULL, null=True, blank=True, related_name='applications')
    applicant = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='job_applications')
    application_status = models.CharField(
        max_length=100, choices=APPLICATION_STATUS_CHOICES,
        default='Applied', null=True, blank=True)
    date_of_apply = models.DateField(auto_now_add=True, null=True, blank=True)
    interview_date = models.DateTimeField(null=True, blank=True)
    offer_date = models.DateField(null=True, blank=True)
    rejection_reason = models.TextField(null=True, blank=True)
    notes = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'applications_v2'

    def __str__(self):
        job_title = self.job.job_title if self.job and self.job.job_title else 'N/A'
        applicant_name = self.applicant.get_full_name() if self.applicant else 'N/A'
        status = self.application_status if self.application_status else 'N/A'
        return f"{job_title} - {applicant_name} - {status}"


class InternProfileViewByCompany(models.Model):
    intern_profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    company = models.ForeignKey(
        'aptpath_models.Company', on_delete=models.SET_NULL, null=True, blank=True)
    employer = models.ManyToManyField('aptpath_models.MongoEmployer', blank=True)
    intern_count_per_company = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = 'intern_profile_view_per_company'
        unique_together = ['intern_profile', 'company']

    def __str__(self):
        company_name = self.company.name if self.company else 'Unknown Company'
        return f"{company_name} viewed profile {self.intern_profile_id}"


@receiver(post_save, sender=InternProfileViewByCompany)
def update_intern_count_per_company(sender, instance, created, **kwargs):
    if created and instance.company_id:
        qs = InternProfileViewByCompany.objects.filter(
            company=instance.company).exclude(pk=instance.pk)
        result = qs.aggregate(max_count=Max('intern_count_per_company'))
        prev_max = result['max_count']
        instance.intern_count_per_company = (prev_max or 0) + 1
        instance.save(update_fields=['intern_count_per_company'])
