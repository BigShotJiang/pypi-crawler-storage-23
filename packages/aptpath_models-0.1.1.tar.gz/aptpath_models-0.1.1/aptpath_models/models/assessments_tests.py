"""Test definitions: AptpathTests, duration models, and templates."""
from django.db import models

from .base import BaseModelEmployer


class Durationmodel(models.Model):
    TEST_CHOICES = (
        ('technical', 'Technical'),
        ('aptitude', 'Aptitude'),
        ('coding', 'Coding'),
    )

    test_types = models.CharField(max_length=20, choices=TEST_CHOICES, null=True, blank=True)
    no_of_questions = models.IntegerField(null=True, blank=True, default=0)
    duration = models.IntegerField(null=True, blank=True, default=0)
    logo = models.FileField(blank=True, null=True)

    def __str__(self):
        return str(self.test_types)

    class Meta:
        db_table = 'duration_test'


class AptpathTests(BaseModelEmployer):
    TEST_CHOICES = (
        ('public', 'Public'),
        ('assessment', 'Assessment'),
    )

    test_id = models.IntegerField(null=True, blank=True)
    test_types = models.CharField(max_length=20, choices=TEST_CHOICES, default='public')
    name = models.CharField(max_length=100, null=True, blank=True)
    test_duration = models.IntegerField(null=True, blank=True)
    test_description = models.TextField(null=True, blank=True)
    duration = models.ManyToManyField(Durationmodel, blank=True)

    def __str__(self):
        return f"{self.id} - {self.test_id} - {self.name} - {self.created_by}"

    class Meta:
        db_table = 'aptpath_tests'


class AptpathTestsTemplates(BaseModelEmployer):
    TEMPLATE_TYPE_CHOICES = (
        ('aptpath', 'aptpath'),
        ('company', 'company'),
    )
    TEST_CHOICES = (
        ('public', 'Public'),
        ('assessment', 'Assessment'),
    )

    test_id = models.IntegerField(null=True, blank=True)
    test_types = models.CharField(max_length=20, choices=TEST_CHOICES, default='public')
    name = models.CharField(max_length=100, null=True, blank=True)
    test_duration = models.IntegerField(null=True, blank=True)
    test_description = models.TextField(null=True, blank=True)
    duration = models.ManyToManyField(Durationmodel, blank=True)
    template_type = models.CharField(
        max_length=100, null=True, blank=True,
        choices=TEMPLATE_TYPE_CHOICES, default='company')

    def __str__(self):
        return f"{self.id} - {self.name} - {self.created_by}"

    class Meta:
        db_table = 'aptpath_tests_templates'


class CompanyTestsTemplates(BaseModelEmployer):
    company = models.ForeignKey(
        'aptpath_models.Company', on_delete=models.CASCADE, null=True, blank=True)
    test_template = models.ForeignKey(
        AptpathTestsTemplates, on_delete=models.CASCADE, null=True, blank=True)
    is_enabled = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.company} - {self.test_template} - {self.is_enabled}"

    class Meta:
        db_table = 'company-test-templates'
