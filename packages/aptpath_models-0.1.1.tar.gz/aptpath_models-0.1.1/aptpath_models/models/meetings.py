"""Online meeting and recording models."""
from django.db import models


class Recordings(models.Model):
    file_name = models.CharField(max_length=500)
    storage_url = models.TextField(null=True, blank=True)
    subject = models.CharField(max_length=500)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    mentor = models.ForeignKey(
        'aptpath_models.Profile',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='recordings',
    )
    project = models.ForeignKey(
        'aptpath_models.Internship', on_delete=models.SET_NULL, null=True, blank=True)
    batch = models.IntegerField(blank=True, null=True)
    session_id = models.ForeignKey(
        'aptpath_models.InternshipSession', on_delete=models.SET_NULL, null=True, blank=True)
    meetings_data = models.JSONField(null=True, blank=True)

    class Meta:
        ordering = ['-uploaded_at']

    def __str__(self):
        return f"{self.subject} - {self.project}"
