"""Payment gateway models."""
from django.db import models
from django.db.models import JSONField

from .base import BaseModelProfile


class PaymentDetails(BaseModelProfile):
    ITEM_TYPE_CHOICES = [
        ('course', 'Course'),
        ('project', 'Project'),
        ('assessment', 'Assessment'),
        ('tech_stack', 'Tech Stack'),
    ]
    PAYMENT_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('successfull', 'Successfull'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded'),
    ]

    order_id = models.CharField(max_length=250, default='', null=True)
    payment_id = models.CharField(max_length=250, default='', null=True)
    signature = models.TextField(default='', null=True, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    status = models.CharField(max_length=50, choices=PAYMENT_STATUS_CHOICES, default='pending')
    payment_method = models.CharField(max_length=250, default='', null=True)
    transaction_date = models.DateTimeField(auto_now_add=True)
    transaction_id = models.TextField(null=True, blank=True)
    user = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    currency = models.CharField(max_length=10, default='INR')
    gateway_response = models.TextField(null=True, blank=True)
    refund_status = models.CharField(
        max_length=50,
        choices=[('not_refunded', 'Not Refunded'), ('refunded', 'Refunded')],
        default='not_refunded',
    )
    reference_number = models.CharField(max_length=250, null=True, blank=True)
    item_type = models.CharField(max_length=50, choices=ITEM_TYPE_CHOICES)
    item_id = models.PositiveIntegerField()
    item_data = JSONField(null=True, blank=True)
    invoice_link = models.URLField(max_length=1000, blank=True, null=True)

    class Meta:
        db_table = 'payment_details'
