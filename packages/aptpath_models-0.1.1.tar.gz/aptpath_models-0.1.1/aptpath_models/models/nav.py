"""Navigation item and subheader models."""
from django.contrib.postgres.fields import ArrayField
from django.db import models


class IconChoices(models.TextChoices):
    JOB = 'job', 'ic_job'
    BLOG = 'blog', 'ic_blog'
    CHAT = 'chat', 'ic_chat'
    MAIL = 'mail', 'ic_mail'
    USER = 'user', 'ic_user'
    FILE = 'file', 'ic_file'
    LOCK = 'lock', 'ic_lock'
    TOUR = 'tour', 'ic_tour'
    ORDER = 'order', 'ic_order'
    LABEL = 'label', 'ic_label'
    BLANK = 'blank', 'ic_blank'
    KANBAN = 'kanban', 'ic_kanban'
    FOLDER = 'folder', 'ic_folder'
    BANKING = 'banking', 'ic_banking'
    BOOKING = 'booking', 'ic_booking'
    INVOICE = 'invoice', 'ic_invoice'
    PRODUCT = 'product', 'ic_product'
    CALENDAR = 'calendar', 'ic_calendar'
    DISABLED = 'disabled', 'ic_disabled'
    EXTERNAL = 'external', 'ic_external'
    MENU_ITEM = 'menuItem', 'ic_menu_item'
    ECOMMERCE = 'ecommerce', 'ic_ecommerce'
    ANALYTICS = 'analytics', 'ic_analytics'
    DASHBOARD = 'dashboard', 'ic_dashboard'
    SETTING = 'setting', 'ic_setting'


class NavigationItem(models.Model):
    title = models.CharField(max_length=100)
    path = models.CharField(max_length=200)
    icon = models.CharField(
        max_length=20, choices=IconChoices.choices, default=IconChoices.DASHBOARD)
    access = ArrayField(models.CharField(max_length=50))
    enable = models.BooleanField(default=True)
    parent = models.ForeignKey(
        'self', null=True, blank=True,
        related_name='children', on_delete=models.CASCADE)
    order = models.IntegerField(default=0)

    def __str__(self):
        if self.parent:
            return f"{self.title} - {self.access} - {self.parent} - {self.order}"
        return f"{self.title} - {self.access} - {self.order}"


class NavigationSubheader(models.Model):
    title = models.CharField(max_length=100, null=True, blank=True)
    items = models.ManyToManyField(NavigationItem)

    def __str__(self):
        return self.title or 'Root Navigation'
