"""Jobs, applications, assessments and related models."""
from django.contrib.postgres.fields import ArrayField
from django.db import models
from django.utils import timezone

from .base import BaseModel, BaseModelEmployer


class Benefits(BaseModel):
    name = models.CharField(null=True, blank=True, max_length=100)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'benefits'


class ExperienceJobForm(BaseModel):
    name = models.CharField(null=True, blank=True, max_length=100)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'job_experience'


class EmplomentTypes(BaseModel):
    name = models.CharField(null=True, blank=True, max_length=100)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'employment-types'


class Jobs(BaseModelEmployer):
    PUBLISH_CHOICES = (
        ('DRAFT', 'draft'),
        ('PUBLISHED', 'published'),
    )

    employer = models.ForeignKey(
        'aptpath_models.MongoEmployer', on_delete=models.SET_NULL, null=True)
    company = models.ForeignKey(
        'aptpath_models.Company', on_delete=models.CASCADE, null=True, blank=True)
    category = models.ManyToManyField('aptpath_models.MongoCategories', blank=True)
    job_title = models.CharField(max_length=200, null=True, blank=True)
    position_summary = models.TextField(null=True, blank=True)
    job_mode = models.CharField(max_length=100, null=True, blank=True)
    keywords = models.ManyToManyField('aptpath_models.MongoSkill', blank=True)
    job_description = models.TextField(null=True, blank=True)
    role_responsibility = models.TextField(null=True, blank=True)
    city = models.CharField(max_length=100, null=True, blank=True)
    state = models.CharField(max_length=100, null=True, blank=True)
    full_address = models.CharField(max_length=200, null=True, blank=True)
    post_date = models.DateField(auto_now_add=True)
    end_date = models.DateField()
    learning_path = models.ForeignKey(
        'aptpath_models.LearningPath', on_delete=models.SET_NULL, null=True)
    active = models.BooleanField(default=True)
    salary = models.PositiveIntegerField(null=True, blank=True)
    salary_type = models.CharField(max_length=100, null=True, blank=True)
    negotiable = models.BooleanField(default=True)
    publish = models.CharField(
        max_length=100, null=True, blank=True, choices=PUBLISH_CHOICES)
    benefits = models.ManyToManyField(Benefits, null=True, blank=True)
    locations = ArrayField(models.CharField(max_length=100), blank=True, null=True)
    experience = models.ForeignKey(
        ExperienceJobForm, on_delete=models.SET_NULL, null=True)
    employment_types = models.ManyToManyField(EmplomentTypes, null=True, blank=True)
    applicants = models.ManyToManyField('aptpath_models.MongoApplications', null=True, blank=True)
    role = models.CharField(max_length=100, null=True, blank=True)
    tests = models.ManyToManyField('aptpath_models.AptpathTests', null=True, blank=True)
    no_of_openings = models.IntegerField(null=True, blank=True, default=0)
    college = models.ManyToManyField('aptpath_models.College', null=True, blank=True)
    is_template = models.BooleanField(default=False)
    template_enabled = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.id} - {self.job_title} - {self.employer}"

    class Meta:
        db_table = 'jobs'


class MongoApplications(BaseModel):
    ACTION_CHOICES = (
        ('Applied', 'Applied'),
        ('Rejected', 'Rejected'),
        ('Shortlisted', 'Shortlisted'),
        ('Offered', 'Offered'),
        ('Interviewed', 'Interviewed'),
    )

    job = models.ForeignKey(Jobs, on_delete=models.SET_NULL, null=True)
    applicant = models.ForeignKey(
        'aptpath_models.MongoUser', on_delete=models.SET_NULL, null=True)
    application_status = models.CharField(
        max_length=100, choices=ACTION_CHOICES, default='Applied', null=True, blank=True)
    date_of_apply = models.DateField(auto_now=True)
    active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.job} - {self.applicant} - {self.application_status} - {self.date_of_apply}"

    class Meta:
        db_table = 'applications'


class JobTemplates(BaseModelEmployer):
    PUBLISH_CHOICES = (
        ('DRAFT', 'draft'),
        ('PUBLISHED', 'published'),
    )
    TEMPLATE_TYPE_CHOICES = (
        ('aptpath', 'aptpath'),
        ('company', 'company'),
    )

    employer = models.ForeignKey(
        'aptpath_models.MongoEmployer', on_delete=models.SET_NULL, null=True)
    company = models.ForeignKey(
        'aptpath_models.Company', on_delete=models.CASCADE, null=True, blank=True)
    category = models.ManyToManyField('aptpath_models.MongoCategories', blank=True)
    job_title = models.CharField(max_length=200, null=True, blank=True)
    position_summary = models.TextField(null=True, blank=True)
    job_mode = models.CharField(max_length=100, null=True, blank=True)
    keywords = models.ManyToManyField('aptpath_models.MongoSkill', blank=True)
    job_description = models.TextField(null=True, blank=True)
    role_responsibility = models.TextField(null=True, blank=True)
    city = models.CharField(max_length=100, null=True, blank=True)
    state = models.CharField(max_length=100, null=True, blank=True)
    full_address = models.CharField(max_length=200, null=True, blank=True)
    post_date = models.DateField(auto_now_add=True)
    end_date = models.DateField()
    learning_path = models.ForeignKey(
        'aptpath_models.LearningPath', on_delete=models.SET_NULL, null=True)
    active = models.BooleanField(default=True)
    salary = models.PositiveIntegerField(null=True, blank=True)
    salary_type = models.CharField(max_length=100, null=True, blank=True)
    negotiable = models.BooleanField(default=True)
    publish = models.CharField(
        max_length=100, null=True, blank=True, choices=PUBLISH_CHOICES)
    benefits = models.ManyToManyField(Benefits, null=True, blank=True)
    locations = ArrayField(models.CharField(max_length=100), blank=True, null=True)
    experience = models.ForeignKey(ExperienceJobForm, on_delete=models.SET_NULL, null=True)
    employment_types = models.ManyToManyField(EmplomentTypes, null=True, blank=True)
    applicants = models.ManyToManyField(MongoApplications, null=True, blank=True)
    role = models.CharField(max_length=100, null=True, blank=True)
    tests = models.ManyToManyField('aptpath_models.AptpathTests', null=True, blank=True)
    no_of_openings = models.IntegerField(null=True, blank=True, default=0)
    college = models.ManyToManyField('aptpath_models.College', null=True, blank=True)
    template_type = models.CharField(
        max_length=100, null=True, blank=True,
        choices=TEMPLATE_TYPE_CHOICES, default='company')

    def __str__(self):
        return f"{self.id} - {self.job_title} - {self.employer}"

    class Meta:
        db_table = 'job-templates'


class CompanyJobTemplates(BaseModelEmployer):
    company = models.ForeignKey(
        'aptpath_models.Company', on_delete=models.CASCADE, null=True, blank=True)
    job_template = models.ForeignKey(JobTemplates, on_delete=models.CASCADE, null=True, blank=True)
    is_enabled = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.company} - {self.job_template} - {self.is_enabled}"

    class Meta:
        db_table = 'company-job-templates'


class Interviewer(BaseModelEmployer):
    user = models.ForeignKey(
        'aptpath_models.MongoEmployer', on_delete=models.SET_NULL, null=True)
    codejudge_id = models.IntegerField(null=True, blank=True)

    def __str__(self):
        if self.user:
            return self.user.email
        return ''

    class Meta:
        db_table = 'interviewer'


class InterviewDetails(BaseModelEmployer):
    STATUS_CHOICES = (
        ('scheduled', 'Scheduled'),
        ('completed', 'Completed'),
    )

    title = models.CharField(max_length=50, null=True, blank=True)
    email = models.EmailField(verbose_name='InterviewDetails', max_length=255)
    resume = models.FileField(blank=True, null=True)
    check_calender = models.BooleanField(default=True)
    infinite_duration = models.BooleanField(default=False)
    audio_video = models.BooleanField(default=True)
    check_recording = models.BooleanField(default=True)
    description = models.CharField(max_length=600, null=True, blank=True)
    start_time = models.DateTimeField(default=timezone.now, null=True)
    end_time = models.DateTimeField(default=timezone.now, null=True)
    learner = models.ForeignKey(
        'aptpath_models.MongoUser', on_delete=models.SET_NULL, null=True,
        related_name='interviews_as_learner')
    employer = models.ForeignKey(
        'aptpath_models.MongoEmployer', on_delete=models.SET_NULL, null=True,
        related_name='interviews_as_employer')
    interviewer = models.ForeignKey(Interviewer, on_delete=models.SET_NULL, null=True)
    codejudge_id = models.IntegerField(null=True, blank=True)
    test_uuid = models.CharField(max_length=50, null=True, blank=True)
    job = models.ForeignKey(
        Jobs, on_delete=models.SET_NULL, null=True, related_name='interviews_as_learner')
    duration_seconds_overall = models.IntegerField(default=0)
    duration_hours = models.IntegerField(default=0)
    duration_minutes = models.IntegerField(default=0)
    duration_seconds = models.IntegerField(default=0)
    candidate_Interview_url = models.URLField(null=True, blank=True)
    interviewer_Interview_url = models.URLField(null=True, blank=True)
    status = models.CharField(
        null=True, max_length=20, choices=STATUS_CHOICES, default='scheduled')

    def __str__(self):
        return f"{self.employer} - {self.job} - {self.start_time}"

    class Meta:
        db_table = 'interview_details'


class Assessments(BaseModel):
    assessment_id = models.CharField(null=True, blank=True, max_length=100)
    user = models.ForeignKey('aptpath_models.MongoUser', on_delete=models.SET_NULL, null=True)
    test = models.ForeignKey('aptpath_models.AptpathTests', on_delete=models.SET_NULL, null=True)
    assessment_url = models.URLField(null=True, blank=True)
    job = models.ForeignKey(Jobs, on_delete=models.SET_NULL, null=True)
    total_score = models.FloatField(null=True, blank=True)
    best_total_score = models.FloatField(null=True, blank=True)
    time_taken = models.CharField(null=True, blank=True, max_length=100)
    questions_attempted = models.IntegerField(null=True, blank=True)
    question_count = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return f"{self.user} - {self.job} - {self.assessment_id}"

    class Meta:
        db_table = 'assessments'


class Sessionstreak(BaseModel):
    user = models.ForeignKey('aptpath_models.MongoUser', on_delete=models.SET_NULL, null=True)
    current_streak = models.IntegerField(default=1)
    best_streak = models.IntegerField(default=1)
    last_login_time = models.DateTimeField(null=True, blank=True, default=timezone.now)
    active = models.BooleanField(default=True)

    class Meta:
        db_table = 'session_streak'


class DailyStreak(models.Model):
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    date = models.DateField(auto_now=True)

    class Meta:
        db_table = 'daily_streak'
