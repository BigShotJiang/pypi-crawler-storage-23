from setuptools import setup, find_packages

setup(
    name='ajo',                    # Your package name
    version='0.1',                        # Version number
    packages=find_packages(),             # Automatically find packages
    install_requires=[],                  # List dependencies if any
    author='Ajo Joji',                   # Your name
    author_email='ajojoji2002@gmail.com',# Your email
    description='A brief description of your package',
    url='https://github.com/ajo-joji', # Your project URL
)
