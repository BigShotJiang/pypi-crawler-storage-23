# ObjectVision-Naman 🚀

Real-time Object Detection Library built using OpenCV DNN and SSD MobileNet v3.

## 📌 Features

- Real-time webcam detection
- Pre-trained COCO model
- Non-Maximum Suppression (NMS)
- Easy-to-use ObjectDetector class

## 📦 Installation

```bash
pip install objectvision-naman

🚀 Usage Example
import cv2
from objectvision_naman import ObjectDetector

detector = ObjectDetector()

cap = cv2.VideoCapture(0)

while True:
    success, img = cap.read()
    img = detector.detect(img)
    cv2.imshow("Detection", img)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

🧠 Model Used
💠SSD MobileNet v3
💠COCO Dataset

👨‍💻 Author
Naman Lohiya