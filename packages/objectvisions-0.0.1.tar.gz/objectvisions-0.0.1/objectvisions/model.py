import cv2
import os

def load_model():
    base_path = os.path.abspath(os.path.dirname(__file__))

    weightsPath = os.path.join(base_path, "frozen_inference_graph.pb")
    configPath = os.path.join(base_path, "ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt")

    if not os.path.exists(weightsPath):
        raise FileNotFoundError(f"Model file not found at {weightsPath}")

    if not os.path.exists(configPath):
        raise FileNotFoundError(f"Config file not found at {configPath}")

    net = cv2.dnn_DetectionModel(weightsPath, configPath)
    net.setInputSize(320, 320)
    net.setInputScale(1.0 / 127.5)
    net.setInputMean((127.5, 127.5, 127.5))
    net.setInputSwapRB(True)

    return net