import cv2
import numpy as np
from .model import load_model
from .utils import load_class_names

class ObjectDetector:
    def __init__(self, threshold=0.65, nms_threshold=0.35):
        self.threshold = threshold
        self.nms_threshold = nms_threshold
        
        self.net = load_model()
        self.classNames = load_class_names()

    def detect(self, img):
        classIds, confs, bbox = self.net.detect(img, confThreshold=self.threshold)

        if len(bbox) == 0:
            return img

        bbox = list(bbox)
        confs = list(np.array(confs).reshape(1, -1)[0])
        confs = list(map(float, confs))

        indices = cv2.dnn.NMSBoxes(bbox, confs, self.threshold, self.nms_threshold)

        for i in indices:
            if len(indices.shape) > 1:
                i = i[0]

            box = bbox[i]
            x, y, w, h = box
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)

            classId = classIds[i][0] if len(classIds[i].shape) > 0 else classIds[i]
            cv2.putText(img,
                        self.classNames[classId - 1].upper(),
                        (x + 10, y + 30),
                        cv2.FONT_HERSHEY_COMPLEX,
                        1,
                        (0, 255, 0),
                        2)
        return img