import os

def load_class_names():
    base_path = os.path.dirname(__file__)
    classFile = os.path.join(base_path, "coco.names")

    with open(classFile, 'rt') as f:
        classNames = f.read().rstrip('\n').split('\n')

    return classNames