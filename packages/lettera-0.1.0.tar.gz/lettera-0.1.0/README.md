# Lettera

A typewriter-inspired journaling application that enforces forward-only writing to preserve raw thinking.

Named after the Olivetti Lettera series of portable typewriters—functional, beautiful, no-nonsense.

## Philosophy

- **The raw dump is the valuable artifact** — your unfiltered thoughts matter
- **Visible corrections reveal the thinking process** — strikethrough instead of delete
- **Closure is psychological, not enforced** — the ritual marks completion without forcing exit
- **Minimalism removes friction, not capability** — maximum content, minimum chrome

## Features

- **Typewriter mode** — No backspace, no delete. You can move the cursor freely and type over existing text (overtype mode), just like a real typewriter where you can move the carriage back and type over mistakes.
- **Strikethrough** — Move cursor to start position and press `Ctrl+X` to strike the next character through using Unicode combining characters (v̶i̶s̶i̶b̶l̶e̶ ̶i̶n̶ ̶p̶l̶a̶i̶n̶ ̶t̶e̶x̶t̶), one character at a time, until the end of the line.
- **Closure ritual** — Press `Ctrl+S` for a calming fade-to-black animation that marks psychological completion.
- **Manual save** — Press `Ctrl+S` to save your entry (also triggers the closure ritual).
- **Archive** — Browse and continue past entries with `Ctrl+O`.
- **Timestamped entries** — Each session creates a new markdown file (`YYYY-MM-DDTHH-mm-ss.md`).

# GUI Design

- Typewritter methaphore.
- Begin the app with a fresh new page.
- Menu of shortcuts at the bottom
- Minimalist style with lettera 22 teal colors.
- Header with the name of the app (Lettera) and the current time.
- Show if there are unsaved changes in bottom status bar.

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Arrow keys` | Move cursor freely (overtype mode - typing replaces existing text) |
| `Ctrl+X` | Strike through text |
| `Ctrl+S` | Save the current file|
| `Ctrl+N` | New page (new timestamped file) |
| `Ctrl+O` | Open archive |
| `Ctrl+Q` | Quit with closure ritual (fade animation) |
| `Esc` | Return from archive to editor |

## File I/O

File naming: YYYY-MM-DD-Thh-mm-ss.md in configured directory

```
~/.lettera/
  entries/
    2025-02-15.md
    2025-02-14.md
  config.toml
```

## Config file

~/.lettera/config.json

```
{
  "entriesDir": "path to entries"
}
```

## Installation

```bash
# From source (dev mode)
make setup
make run

# Build wheel and install
make dist
pip3 install dist/lettera-*.whl
lettera
```

### macOS App Bundle

```bash
make dist
pip3 install dist/lettera-*.whl
make app
# → dist/Lettera.app  (drag to /Applications or double-click)
```

## Tech Stack

Python 3
Textual https://textual.textualize.io/



