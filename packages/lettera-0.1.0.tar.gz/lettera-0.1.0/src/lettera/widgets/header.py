"""Header widget for Lettera."""

from datetime import datetime
from textual.widgets import Static
from textual.reactive import reactive


class HeaderBar(Static):
    """Header bar with app name and current time."""

    current_time = reactive("")

    def __init__(self, *args, **kwargs):
        """Initialize header bar."""
        super().__init__(*args, **kwargs)
        self.update_time()

    def on_mount(self) -> None:
        """Set up timer to update time."""
        self.set_interval(1.0, self.update_time)

    def update_time(self) -> None:
        """Update the current time display."""
        self.current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def render(self) -> str:
        """Render the header."""
        return f"Lettera — {self.current_time}"
