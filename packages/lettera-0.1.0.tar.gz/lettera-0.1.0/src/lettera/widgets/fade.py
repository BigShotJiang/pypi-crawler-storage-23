"""Fade overlay widget for closure ritual."""

import asyncio
from textual.widgets import Static
from textual.message import Message


class FadeOverlay(Static):
    """Full-screen fade overlay for closure ritual animation.

    Animates a three-phase fade:
    1. Fade in (400ms): opacity 0 → 1
    2. Hold (200ms): stay at full opacity
    3. Fade out (400ms): opacity 1 → 0
    """

    DEFAULT_CSS = """
    FadeOverlay {
        display: none;
        layer: overlay;
        width: 100%;
        height: 100%;
        background: $background;
        color: $background;
        opacity: 0;
    }

    FadeOverlay.visible {
        display: block;
    }
    """

    class FadeComplete(Message):
        """Posted when fade animation completes."""
        pass

    async def animate(self) -> None:
        """Run the fade animation sequence."""
        # Show the overlay
        self.add_class("visible")

        # Phase 1: Fade in (400ms)
        self.styles.opacity = 0.0
        self.styles.animate("opacity", 1.0, duration=0.4)
        await asyncio.sleep(0.4)

        # Phase 2: Hold (200ms)
        await asyncio.sleep(0.2)

        # Phase 3: Fade out (400ms)
        self.styles.animate("opacity", 0.0, duration=0.4)
        await asyncio.sleep(0.4)

        # Hide the overlay
        self.remove_class("visible")

        # Notify that animation is complete
        self.post_message(self.FadeComplete())
