"""Type definitions for Lettera."""

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


@dataclass
class EntryMeta:
    """Metadata for a journal entry."""

    path: Path
    filename: str
    created: datetime

    def display_name(self) -> str:
        """Format entry for display in archive."""
        return self.created.strftime("%Y-%m-%d %H:%M:%S")

    @property
    def display_date(self) -> str:
        """Format date for grouping (e.g., 'February 14, 2026')."""
        return self.created.strftime("%B %d, %Y")

    @property
    def relative_time(self) -> str:
        """Return a human-readable relative time (e.g., '5 min ago', '2 days ago')."""
        delta = datetime.now() - self.created
        seconds = int(delta.total_seconds())
        if seconds < 60:
            return "just now"
        if seconds < 3600:
            n = seconds // 60
            return f"{n} min ago"
        if seconds < 86400:
            n = seconds // 3600
            return f"{n} hour{'s' if n != 1 else ''} ago"
        if seconds < 7 * 86400:
            n = seconds // 86400
            return f"{n} day{'s' if n != 1 else ''} ago"
        if seconds < 30 * 86400:
            n = seconds // (7 * 86400)
            return f"{n} week{'s' if n != 1 else ''} ago"
        n = seconds // (30 * 86400)
        return f"{n} month{'s' if n != 1 else ''} ago"
