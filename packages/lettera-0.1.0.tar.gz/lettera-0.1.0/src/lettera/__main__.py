"""Entry point for Lettera application."""

from .app import LetteraApp


def main():
    """Run the Lettera application."""
    app = LetteraApp()
    app.run()


if __name__ == "__main__":
    main()
