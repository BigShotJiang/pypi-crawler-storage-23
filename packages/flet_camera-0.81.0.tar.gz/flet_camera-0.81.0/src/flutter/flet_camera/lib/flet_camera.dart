library flet_camera;

export 'src/extension.dart';
