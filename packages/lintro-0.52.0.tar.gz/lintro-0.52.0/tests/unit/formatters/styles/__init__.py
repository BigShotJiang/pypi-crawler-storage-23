"""Unit tests for formatter styles."""

from __future__ import annotations
