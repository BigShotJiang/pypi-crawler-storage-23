from .globals_checker import ChecksTransformer

def globals_checker_present(shell):
    return any(map(lambda x: isinstance(x, ChecksTransformer), shell.ast_transformers))

def no_vscode_cell_ids(shell):
    return not shell.parent_header['metadata']['cellId'].startswith("vscode-notebook-cell")

def check_notebook():
    ip_shell = get_ipython()
    return globals_checker_present(ip_shell) and no_vscode_cell_ids(ip_shell)
