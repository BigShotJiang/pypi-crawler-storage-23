_notebook_log_error("""{err_msg}""")

