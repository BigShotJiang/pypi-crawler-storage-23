
# Notebook Checker

A collection of additional checks to run in student notebooks.

## Globals checker

Checks notebook files for the use of globals inside functions. The checker
parses each cell's AST as it is run, and injects code into the AST to ensure
that when a function is called, that any free variables are only of the type
callable, type or module. If a function tries to access any other type of
variable, i.e. stored data, outside of the function's scope, then the checker
logs an error message, informing the user.

This check can be started with the magic function: `%start_checks`

## Student logger

Logs student progress while the notebook is being exectuted, including current
cell ID, timestamp at which the cell is executed, and the cell contents.

This check can be started with the magic function: `%register_student`
