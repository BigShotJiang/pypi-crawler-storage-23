#!/usr/bin/env python3
"""Minimal setup.py for backwards compatibility with older pip versions.

All configuration is in pyproject.toml. This file only exists to support
editable installs with pip < 21.3.
"""
from setuptools import setup

setup()
