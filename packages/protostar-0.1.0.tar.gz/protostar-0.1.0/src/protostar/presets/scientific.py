"""Dependency presets for data analysis and scientific computing."""

SCIENTIFIC_PACKAGES = [
    "numpy",
    "matplotlib",
    "seaborn",
    "pandas",
    "scipy",
    "ipykernel",
]
