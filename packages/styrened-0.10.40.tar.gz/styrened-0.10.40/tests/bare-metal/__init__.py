"""Bare-metal test infrastructure for styrened.

This package provides SSH-based testing on physical hardware devices.
"""
