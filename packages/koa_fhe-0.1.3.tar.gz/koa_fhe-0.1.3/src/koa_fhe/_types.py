"""Result types for Koa FHE client. No FHE dependencies."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Stats:
    """Timing stats for an FHE operation."""
    server_ms: float
    roundtrip_ms: float


@dataclass(frozen=True)
class CompareResult:
    """Result of an encrypted comparison (a > b?)."""
    greater: bool
    stats: Stats


@dataclass(frozen=True)
class ArithmeticResult:
    """Result of encrypted arithmetic (add or multiply)."""
    value: int
    stats: Stats


@dataclass(frozen=True)
class RigidityResult:
    """Result of encrypted schedule rigidity analysis."""
    hamming_distance: int
    rigidity_score: float
    severity: str
    stats: Stats


@dataclass(frozen=True)
class ScheduleAnalysis:
    """Full time crystal objective — rigidity + fairness + constraints."""
    objective: float
    rigidity_score: float
    fairness_score: float
    constraint_score: float
    hamming_distance: int
    churn_vector: list[int]
    severity: str
    alpha: float
    beta: float
    stats: Stats


@dataclass(frozen=True)
class WorkloadPrediction:
    """Result of encrypted ML inference (XGBoost workload scoring)."""
    predictions: list[float]
    stats: Stats


@dataclass(frozen=True)
class ServiceHealth:
    """Health status from the FHE service."""
    status: str
    circuits: list[str]
    version: str
    evaluations: int
    uptime_seconds: float


# --- Integrity / Fraud Proof Types ---


@dataclass(frozen=True)
class TrapQuery:
    """A single trap query with known-correct answer.

    Trap queries are indistinguishable from real queries under FHE because
    the server only sees ciphertext. The client knows the plaintext inputs
    and the expected result, so it can verify correctness.
    """
    circuit: str
    circuit_hash: str
    inputs: dict
    expected: int | bool | list[int]
    actual: int | bool | list[int]
    passed: bool
    stats: Stats
    timestamp: float


@dataclass(frozen=True)
class IntegrityProof:
    """On-chain submittable proof of incorrect computation.

    Contains everything needed for the slashing contract to verify that
    Koa returned a wrong result: the plaintext inputs, expected output,
    actual output, and the circuit hash identifying the exact circuit
    version that was called.

    The contract can recompute the expected result on-chain (for simple
    circuits like add/multiply/threshold) or delegate to a verifier.
    """
    circuit: str
    circuit_hash: str
    inputs: dict
    expected: int | bool
    actual: int | bool
    timestamp: float
    server_ms: float


@dataclass
class IntegrityResult:
    """Result of a ``verify_integrity()`` run.

    Attributes:
        passed: True if all trap queries returned correct results.
        queries: Individual trap query results.
        proofs: Non-empty only if integrity violations were found.
            Each proof is suitable for on-chain slashing submission.
        total_ms: Total wall-clock time for all trap queries.
    """
    passed: bool
    queries: list[TrapQuery] = field(default_factory=list)
    proofs: list[IntegrityProof] = field(default_factory=list)
    total_ms: float = 0.0
