"""Allow `python -m koa_fhe` as an alternative to the `koa-fhe` entry point."""

from ._cli import main

main()
