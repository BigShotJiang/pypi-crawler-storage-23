"""Coral EdgeTPU backend adapter wrapping ``pyzm.ml.coral_edgetpu.Tpu``."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from pyzm.ml.backends.base import MLBackend
from pyzm.models.config import ModelConfig
from pyzm.models.detection import BBox, Detection

if TYPE_CHECKING:
    import numpy as np

logger = logging.getLogger("pyzm.ml")


class CoralBackend(MLBackend):
    """Wraps :class:`pyzm.ml.coral_edgetpu.Tpu` in the v2 backend interface."""

    def __init__(self, config: ModelConfig) -> None:
        self._config = config
        self._model: object | None = None

    # -- MLBackend interface --------------------------------------------------

    @property
    def name(self) -> str:
        return self._config.name or "coral_edgetpu"

    @property
    def is_loaded(self) -> bool:
        return self._model is not None

    @property
    def needs_exclusive_lock(self) -> bool:
        return not self._config.disable_locks

    def acquire_lock(self) -> None:
        if self._model is not None:
            self._model.acquire_lock()

    def release_lock(self) -> None:
        if self._model is not None:
            self._model.release_lock()

    def load(self) -> None:
        from pyzm.ml.coral_edgetpu import Tpu  # lazy import

        options = self._build_options()
        logger.info(
            "%s: loading Coral EdgeTPU model (processor=tpu, weights=%s)",
            self.name, self._config.weights,
        )
        self._model = Tpu(options=options)
        self._model.load_model()
        logger.debug("%s: running on tpu", self.name)

    def detect(self, image: "np.ndarray") -> list[Detection]:
        if self._model is None:
            self.load()

        assert self._model is not None
        boxes, labels, confidences, _model_tags = self._model.detect(image=image)

        detections: list[Detection] = []
        for box, label, conf in zip(boxes, labels, confidences):
            if conf < self._config.min_confidence:
                logger.debug(
                    "%s: dropping %s (%.2f < %.2f)",
                    self.name, label, conf, self._config.min_confidence,
                )
                continue
            detections.append(
                Detection(
                    label=label,
                    confidence=conf,
                    bbox=BBox(x1=box[0], y1=box[1], x2=box[2], y2=box[3]),
                    model_name=self.name,
                    detection_type="object",
                )
            )
        return detections

    # -- internal helpers -----------------------------------------------------

    def _build_options(self) -> dict:
        return {
            "name": self.name,
            "object_weights": self._config.weights,
            "object_labels": self._config.labels,
            "object_min_confidence": self._config.min_confidence,
            # Disable per-frame locking in the Tpu class; the Detector
            # now holds the lock across the entire multi-frame session
            # via acquire_lock()/release_lock().
            "disable_locks": "yes" if self._config.disable_locks else "no",
            "auto_lock": False,
            "tpu_max_processes": self._config.max_processes,
            "tpu_max_lock_wait": self._config.max_lock_wait,
        }
