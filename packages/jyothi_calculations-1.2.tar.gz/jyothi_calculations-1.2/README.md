# calculation

thins packge would have been provided to to perform calculations automatically
