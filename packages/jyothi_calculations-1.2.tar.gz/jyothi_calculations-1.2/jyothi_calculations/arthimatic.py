class Arthimatic:

    def __init__(self ):
        self.ans = 0


    def add(self,*args : (int)):
        ''' this function is taking multiple arguments 
            and returns their's sum 
        '''
        
        for i in args:
            self.ans += i
        return self.ans


    def mul(self,*args :(int)):
        ''' this function is taking multiple arguments 
            and returns their's multiplication
        '''
        for i in args:
            self.ans *= i
        return self.ans 


    def sub(self,*args :(int)): 
        ''' this function is taking multiple arguments 
            and returns their's multiplication
        '''

        a = list(args)
        a.sort(reversed = True)
        self.ans = a[0]

        for i in a[1:]:
            self.ans -= i
        return self.ans




        