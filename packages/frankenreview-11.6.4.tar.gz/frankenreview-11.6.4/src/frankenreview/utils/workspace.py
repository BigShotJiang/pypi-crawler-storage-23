"""
Frankenreview v11 - Workspace Management (workspace.py)

Manages the per-repo .frankenreview/ folder for all artifacts:
- dumps/     - XML code snapshots
- review.md  - Latest review output
- SKILL.md   - AI agent skill descriptor (auto-generated)

This module handles folder creation and automatic .gitignore updates.
"""

import os
from pathlib import Path

# The canonical folder name for Frankenreview artifacts
FR_FOLDER_NAME = ".frankenreview"


def get_fr_folder(project_root: str) -> Path:
    """
    Get the .frankenreview folder path for a project.
    
    Args:
        project_root: Root path of the project
        
    Returns:
        Path to the .frankenreview folder
    """
    return Path(project_root) / FR_FOLDER_NAME


def ensure_fr_folder(project_root: str) -> Path:
    """
    Ensure the .frankenreview folder exists and is gitignored.
    
    Creates the folder structure:
    .frankenreview/
    ├── dumps/          # XML code snapshots
    ├── state.json      # VS Code extension state
    └── latest_prompt.txt
    
    Args:
        project_root: Root path of the project
        
    Returns:
        Path to the .frankenreview folder
    """
    fr_folder = get_fr_folder(project_root)
    
    # Create folder structure
    fr_folder.mkdir(parents=True, exist_ok=True)
    (fr_folder / "dumps").mkdir(exist_ok=True)
    
    # Auto-add to .gitignore if it exists
    _ensure_gitignored(project_root)
    
    # Auto-generate SKILL.md for Agents
    _ensure_skill_md(fr_folder)
    
    return fr_folder


def _ensure_skill_md(fr_folder: Path) -> None:
    """
    Ensure SKILL.md exists for AI Agents.
    """
    skill_path = fr_folder / "SKILL.md"
    if skill_path.exists():
        return

    content = """---
name: Frankenreview
description: Agentic Code Review, Deep Research, and Repository Intelligence Tool.
---

# Frankenreview

Frankenreview is a powerful, multi-layered tool designed for AI agents to perform high-precision code reviews, deep research, and repository analysis. It leverages Google AI Studio's Gemini models (via a Chrome bridge) to process massive contexts that exceed typical API limits.

## Capabilities

### 1. Code Review (`-r`)
Performs a comprehensive, one-shot code review of the current repository.
- **Command**: `frankenreview -r`
- **Output**: `.frankenreview/review.md`
- **Context**: Automatically dumps the repo (xml) and prunes garbage files.
- **Shorthand**: `frankenreview --consolidation` (Runs review with `consolidation` prompt)

### 2. Deep Research (`--research`)
Conducts in-depth research on a topic, synthesizing information from multiple sources.
- **Command**: `frankenreview --research --prompt "topic or file.md"`
- **Output**: `.frankenreview/research_<timestamp>.md`

### 3. Interactive Chat (`--open-chat`)
Opens an AI Studio chat session for manual or scripted interaction.
- **Upload files**: `frankenreview --open-chat --attach file.txt`
- **Send prompt**: `frankenreview --open-chat --prompt "Analyze this"`
- **Combined**: `frankenreview --open-chat --attach code.txt --prompt "Review this"`
- **Session persistence**: Resumes last chat if no new attachments.

### 4. Repository Intelligence (`--token-eaters`, `--discover-selectors`)
Analyzes the codebase to identify token-heavy files and self-repairs UI selectors.
- **Token Analysis**: `frankenreview --token-eaters` (Identifies large/garbage files)
- **Self-Repair**: `frankenreview --discover-selectors` (Updates config.yaml with fresh UI selectors)

### 5. Chrome Management
Frankenreview requires a specific Chrome debugging instance.
- **Start**: `frankenreview --start-chrome` (Required once before use)
- **Stop**: `frankenreview --stop-chrome`
- **Auto-start**: If Chrome isn't running, the tool will offer to start it with a 5s timeout.

### 6. Structured JSON Mode (`--json`)
Appends schema instructions to force the AI to output parseable JSON.
- **Command**: `frankenreview -r --json`
- **Use Case**: CI/CD pipelines, automated agents, and programmatic parsing.

### 7. Model Failover
Automatic model switching on rate limits with configurable fallback chain.
- **Default chain**: gemini-flash-latest -> gemini-3-flash-preview -> gemini-2.5-pro -> gemini-2.5-flash
- **Override**: `frankenreview -r --model gemini-2.5-pro`

## Workflow for Agents

1.  **Initialize**:
    ```bash
    frankenreview --start-chrome
    ```
    *Check if Chrome is already running on port 9222.*

2.  **Optimize Context**:
    ```bash
    frankenreview --token-eaters
    ```
    *Read output to identify and add garbage to `.gitignore` or `config.yaml` prune list.*

3.  **Execute Task**:
    *   **For Code Review (Markdown)**:
        ```bash
        frankenreview -r
        ```
    *   **For Code Review (Structured JSON)**:
        ```bash
        frankenreview -r --json
        ```
    *   **For Research**:
        ```bash
        frankenreview --research --prompt "Analyze the security architecture of X"
        ```
    *   **For Interactive Chat**:
        ```bash
        frankenreview --open-chat --attach context.txt --prompt "Review this code"
        ```

4.  **Process Output**:
    Read the generated Markdown or JSON report from `.frankenreview/`.

## Error Handling

| Error | Fix |
| :--- | :--- |
| `Chrome not found / Connection refused` | Run `frankenreview --start-chrome`. Ensure no other Chrome instances block port 9222. |
| `Selector not found` | Run `frankenreview --discover-selectors` to update UI mappings. |
| `Model not found` | Check `frankenreview --available-models`. |
| `Rate Limit` | Automatic model failover handles this. Or wait and retry manually. |
| `Unsupported file format` | XML files are auto-converted to TXT. Use `.txt` for other formats. |

## Limitations

- **Dependencies**: Requires `playwright` and a running Chrome instance.
- **Auth**: Must be logged into Google AI Studio in the Chrome window.
- **Concurrency**: Single-threaded browser interaction. Do not run multiple reviews in parallel on the same port.
"""
    try:
        with open(skill_path, 'w', encoding='utf-8') as f:
            f.write(content)
    except Exception:
        pass


def get_dump_dir(project_root: str) -> Path:
    """
    Get the dumps directory for a project.
    
    Args:
        project_root: Root path of the project
        
    Returns:
        Path to the dumps directory
    """
    fr_folder = ensure_fr_folder(project_root)
    return fr_folder / "dumps"


def _ensure_gitignored(project_root: str) -> bool:
    """
    Ensure .frankenreview/ is in .gitignore if the file exists.
    
    Args:
        project_root: Root path of the project
        
    Returns:
        True if .gitignore was updated, False otherwise
    """
    gitignore_path = Path(project_root) / ".gitignore"
    
    if not gitignore_path.exists():
        return False
    
    # Read existing .gitignore
    try:
        with open(gitignore_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            lines = content.splitlines()
    except Exception:
        return False
    
    # Check if already ignored (various formats)
    ignore_patterns = [
        FR_FOLDER_NAME,
        f"{FR_FOLDER_NAME}/",
        f"/{FR_FOLDER_NAME}",
        f"/{FR_FOLDER_NAME}/",
    ]
    
    for pattern in ignore_patterns:
        if pattern in lines or pattern.strip() in [l.strip() for l in lines]:
            return False  # Already ignored
    
    # Add to .gitignore
    try:
        with open(gitignore_path, 'a', encoding='utf-8') as f:
            # Add newline if file doesn't end with one
            if content and not content.endswith('\n'):
                f.write('\n')
            f.write(f"\n# Frankenreview artifacts\n{FR_FOLDER_NAME}/\n")
        return True
    except Exception:
        return False



def get_config_path(project_root: str) -> Path:
    """
    Get the canonical config.yaml path for a project.

    Args:
        project_root: Root path of the project

    Returns:
        Path to config.yaml in the .frankenreview folder
    """
    return ensure_fr_folder(project_root) / "config.yaml"


# Session URL Management (v11.5)
SESSION_URL_FILE = "last_chat_url.txt"


def get_session_url_path(project_root: str) -> Path:
    """
    Get the path to the session URL file.
    
    Args:
        project_root: Root path of the project
        
    Returns:
        Path to the last_chat_url.txt file
    """
    return get_fr_folder(project_root) / SESSION_URL_FILE


def save_session_url(project_root: str, url: str) -> None:
    """
    Save the current chat URL for session continuation.
    
    Args:
        project_root: Root path of the project
        url: The AI Studio chat URL to save
    """
    session_path = get_session_url_path(project_root)
    session_path.parent.mkdir(parents=True, exist_ok=True)
    session_path.write_text(url, encoding='utf-8')


def load_session_url(project_root: str) -> str | None:
    """
    Load a saved chat URL for session continuation.
    
    Args:
        project_root: Root path of the project
        
    Returns:
        The saved URL or None if no session exists
    """
    session_path = get_session_url_path(project_root)
    if session_path.exists():
        url = session_path.read_text(encoding='utf-8').strip()
        return url if url else None
    return None


def delete_session_url(project_root: str) -> bool:
    """
    Delete the saved session URL file.
    
    Args:
        project_root: Root path of the project
        
    Returns:
        True if file was deleted, False if it didn't exist
    """
    session_path = get_session_url_path(project_root)
    if session_path.exists():
        session_path.unlink()
        return True
    return False