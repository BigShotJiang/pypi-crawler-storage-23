"""
Frankenreview Output Utilities
Production-grade terminal output with Unicode symbols and ASCII fallbacks.
"""

import sys
import os

# ANSI Escape Codes
CLEAR_LINE = "\033[2K"  # Clear entire line
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"

# Colors
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
CYAN = "\033[36m"
WHITE = "\033[37m"


def supports_unicode():
    """
    Check if terminal supports Unicode character output.
    
    Checks stdout encoding and LANG environment variable to determine
    if Unicode symbols can be safely displayed.
    
    Returns:
        bool: True if Unicode is supported, False otherwise
    """
    # Check for UTF-8 encoding
    encoding = getattr(sys.stdout, 'encoding', '') or ''
    if 'utf' in encoding.lower():
        return True
    # Check LANG environment variable
    lang = os.environ.get('LANG', '')
    if 'UTF-8' in lang or 'utf-8' in lang:
        return True
    return False


class Output:
    """Production-grade terminal output with Unicode/ASCII fallbacks."""
    
    # Unicode symbols (research-backed production choices)
    UNICODE_ICONS = {
        'ok': '✔',      # Heavy check mark
        'err': '✖',     # Heavy multiplication X
        'warn': '⚠',    # Warning sign
        'info': 'ℹ',    # Information source
        'wait': '○',    # White circle  
        'run': '▶',     # Play symbol
        'file': '◆',    # Black diamond
        'think': '◉',   # Fisheye (thinking)
        'gen': '→',     # Arrow (generating)
        'debug': '◇',   # White diamond
        'meter': '●',   # Black circle
    }
    
    # ASCII fallbacks for older terminals
    ASCII_ICONS = {
        'ok': '+',
        'err': 'x',
        'warn': '!',
        'info': 'i',
        'wait': '.',
        'run': '>',
        'file': 'f',
        'think': '*',
        'gen': '>',
        'debug': 'd',
        'meter': '#',
    }
    
    def __init__(self, verbose=False, use_color=True):
        self.verbose = verbose
        self.use_color = use_color and sys.stdout.isatty()
        self.use_unicode = supports_unicode()
        self.icons = self.UNICODE_ICONS if self.use_unicode else self.ASCII_ICONS
        self._last_was_progress = False
    
    def _color(self, text, color):
        if self.use_color:
            return f"{color}{text}{RESET}"
        return text
    
    def _icon(self, key):
        icon = self.icons.get(key, '?')
        return f"[{icon}]"
    
    def info(self, msg):
        """Standard info message."""
        self._end_progress()
        print(f"   {self._icon('info')} {msg}")
    
    def ok(self, msg):
        """Success message."""
        self._end_progress()
        print(f"   {self._color(self._icon('ok'), GREEN)} {msg}")
    
    def warn(self, msg):
        """Warning message."""
        self._end_progress()
        print(f"   {self._color(self._icon('warn'), YELLOW)} {msg}")
    
    def err(self, msg):
        """Error message."""
        self._end_progress()
        print(f"   {self._color(self._icon('err'), RED)} {msg}")
    
    def wait(self, msg):
        """Waiting/processing message."""
        self._end_progress()
        print(f"   {self._icon('wait')} {msg}")
    
    def file(self, msg):
        """File operation message."""
        self._end_progress()
        print(f"   {self._icon('file')} {msg}")
    
    def debug(self, msg):
        """Debug message (only if verbose)."""
        if self.verbose:
            self._end_progress()
            print(f"   {self._color(self._icon('debug'), DIM)} {msg}")
    
    def progress(self, msg):
        """Progress message that updates in place."""
        sys.stdout.write(f"{CLEAR_LINE}\r   {self._icon('meter')} {msg}")
        sys.stdout.flush()
        self._last_was_progress = True
    
    def _end_progress(self):
        """End a progress line with newline if needed."""
        if self._last_was_progress:
            print()
            self._last_was_progress = False
    
    def section(self, title):
        """Print a section header."""
        self._end_progress()
        print(f"\n   --- {title} ---")
    
    def done(self):
        """Ensure progress line is properly terminated."""
        self._end_progress()


# Global instance
out = Output()
