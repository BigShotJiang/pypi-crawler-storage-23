#!/usr/bin/env python3
"""
Frankenreview Linter
Checks syntax for multiple file types in the repository.
Usage: python -m frankenreview.linter [path]
"""

import os
import sys
import ast
import json
import subprocess
from pathlib import Path

# Optional imports
try:
    import yaml
except ImportError:
    yaml = None

try:
    import xml.etree.ElementTree as ET
except ImportError:
    ET = None

def check_python(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            source = f.read()
        ast.parse(source, filename=path)
    except SyntaxError as e:
        return f"{path}:{e.lineno}: SyntaxError: {e.msg}"
    except Exception as e:
        return f"{path}:0: Error: {str(e)}"
    return None

def check_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            json.load(f)
    except json.JSONDecodeError as e:
        return f"{path}:{e.lineno}: JSONError: {e.msg}"
    except Exception as e:
        return f"{path}:0: Error: {str(e)}"
    return None

def check_yaml(path):
    if not yaml:
        return None
    try:
        with open(path, 'r', encoding='utf-8') as f:
            list(yaml.safe_load_all(f))
    except yaml.YAMLError as e:
        # YAML errors are complex object
        line = 0
        if hasattr(e, 'problem_mark'):
            line = e.problem_mark.line + 1
        return f"{path}:{line}: YAMLError: {str(e).splitlines()[0]}"
    except Exception as e:
        return f"{path}:0: Error: {str(e)}"
    return None

def check_xml(path):
    if not ET:
        return None
    try:
        ET.parse(path)
    except ET.ParseError as e:
        code, line = e.code, e.position[0]
        return f"{path}:{line}: XMLError: {code}"
    except Exception as e:
        return f"{path}:0: Error: {str(e)}"
    return None

def check_shell(path):
    # Use bash -n if available
    try:
        subprocess.run(["bash", "-n", str(path)], check=True, capture_output=True)
    except subprocess.CalledProcessError as e:
        # bash -n outputs to stderr: "file: line X: error"
        msg = e.stderr.decode().strip().split('\n')[0]
        return f"{path}:0: ShellError: {msg}" # Line number extraction is hard without regex
    except FileNotFoundError:
        pass
    except Exception:
        pass
    return None

def lint_file(path):
    ext = path.suffix.lower()
    if ext == '.py':
        return check_python(path)
    elif ext == '.json':
        return check_json(path)
    elif ext in ['.yaml', '.yml']:
        return check_yaml(path)
    elif ext == '.xml':
        return check_xml(path)
    elif ext == '.sh':
        return check_shell(path)
    return None

def main():
    if len(sys.argv) > 1:
        root_dir = Path(sys.argv[1])
    else:
        root_dir = Path.cwd()
    
    if not root_dir.exists():
        print(f"Error: Path {root_dir} does not exist.")
        sys.exit(1)
        
    print(f"Linting {root_dir}...")
    
    errors = []
    
    # Simple exclusion list
    excludes = {'.git', 'env', 'venv', '__pycache__', 'node_modules', 'dist', 'build', 'dumps', 'deleted', 'temp'}
    
    for root, dirs, files in os.walk(root_dir):
        # Prune dirs
        dirs[:] = [d for d in dirs if d not in excludes]
        
        for name in files:
            path = Path(root) / name
            error = lint_file(path)
            if error:
                print(error)
                errors.append(error)
                
    if errors:
        print(f"\n[x] Found {len(errors)} errors.")
        sys.exit(1)
    else:
        print("\n[+] No syntax errors found.")
        sys.exit(0)

if __name__ == "__main__":
    main()
