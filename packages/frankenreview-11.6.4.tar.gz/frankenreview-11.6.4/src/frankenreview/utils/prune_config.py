"""
Frankenreview v11 - Prune Configuration Management (prune_config.py)

Provides CLI-accessible functions for managing prune lists (dirs, files, extensions)
that control what gets excluded from code review dumps.

This module handles reading/writing to config.yaml for persistent changes.
"""

import os
import yaml
from pathlib import Path
from typing import List, Literal

# Categories for prune lists
PruneCategory = Literal["dirs", "files", "exts"]


def _get_config_path() -> Path:
    """
    Get the path to config.yaml.
    
    Returns:
        Path to config.yaml
    """
    current_dir = Path(__file__).parent
    # src/frankenreview/utils -> src/frankenreview -> src -> ROOT
    project_root = current_dir.parent.parent.parent
    return project_root / "config.yaml"


def _load_config() -> dict:
    """
    Load the full config.yaml.
    
    Returns:
        Config dictionary
    """
    config_path = _get_config_path()
    if not config_path.exists():
        return {}
    
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f) or {}


def _save_config(config: dict) -> None:
    """
    Save the config dictionary back to config.yaml.
    
    Args:
        config: Config dictionary to save
    """
    config_path = _get_config_path()
    with open(config_path, 'w', encoding='utf-8') as f:
        yaml.dump(config, f, default_flow_style=False, allow_unicode=True, sort_keys=False)


def _get_list_key(category: PruneCategory) -> str:
    """
    Get the config key for a prune category.
    
    Args:
        category: "dirs", "files", or "exts"
        
    Returns:
        Config key name
    """
    return {
        "dirs": "prune_dirs",
        "files": "prune_files",
        "exts": "prune_exts"
    }[category]


def get_prune_list(category: PruneCategory) -> List[str]:
    """
    Get the current prune list for a category.
    
    Args:
        category: "dirs", "files", or "exts"
        
    Returns:
        List of items in that prune category
    """
    config = _load_config()
    key = _get_list_key(category)
    return config.get(key, [])


def add_to_prune_list(category: PruneCategory, item: str) -> bool:
    """
    Add an item to a prune list (persistent).
    
    Args:
        category: "dirs", "files", or "exts"
        item: Item to add
        
    Returns:
        True if added, False if already exists
    """
    config = _load_config()
    key = _get_list_key(category)
    
    current_list = config.get(key, [])
    if current_list is None:
        current_list = []
    
    # Normalize item
    item = item.strip()
    if category == "exts" and not item.startswith("."):
        item = "." + item
    
    if item in current_list:
        return False  # Already exists
    
    current_list.append(item)
    config[key] = current_list
    _save_config(config)
    return True


def remove_from_prune_list(category: PruneCategory, item: str) -> bool:
    """
    Remove an item from a prune list (persistent).
    
    Args:
        category: "dirs", "files", or "exts"
        item: Item to remove
        
    Returns:
        True if removed, False if not found
    """
    config = _load_config()
    key = _get_list_key(category)
    
    current_list = config.get(key, [])
    if current_list is None:
        current_list = []
    
    # Normalize item
    item = item.strip()
    if category == "exts" and not item.startswith("."):
        item = "." + item
    
    if item not in current_list:
        return False  # Not found
    
    current_list.remove(item)
    config[key] = current_list
    _save_config(config)
    return True


def list_prune_config() -> str:
    """
    Generate a formatted string of the current prune configuration.
    
    Returns:
        Formatted prune configuration string
    """
    config = _load_config()
    
    prune_dirs = config.get("prune_dirs", [])
    prune_files = config.get("prune_files", [])
    prune_exts = config.get("prune_exts", [])
    
    lines = []
    lines.append("=" * 60)
    lines.append("FRANKENREVIEW PRUNE CONFIGURATION")
    lines.append("=" * 60)
    lines.append("")
    
    # Directories
    lines.append(f"PRUNE_DIRS ({len(prune_dirs)} items):")
    lines.append("-" * 40)
    if prune_dirs:
        for d in sorted(prune_dirs):
            lines.append(f"  {d}/")
    else:
        lines.append("  (none)")
    lines.append("")
    
    # Files
    lines.append(f"PRUNE_FILES ({len(prune_files)} items):")
    lines.append("-" * 40)
    if prune_files:
        for f in sorted(prune_files):
            lines.append(f"  {f}")
    else:
        lines.append("  (none)")
    lines.append("")
    
    # Extensions
    lines.append(f"PRUNE_EXTS ({len(prune_exts)} items):")
    lines.append("-" * 40)
    if prune_exts:
        for e in sorted(prune_exts):
            lines.append(f"  {e}")
    else:
        lines.append("  (none)")
    lines.append("")
    
    lines.append("=" * 60)
    lines.append("Use --prune-add-* and --prune-remove-* to modify these lists.")
    lines.append("=" * 60)
    
    return "\n".join(lines)
