"""
High-level browser actions for AI Studio.
Handles chat deletion and other UI workflows.
"""
import time


class ActionMixin:
    """Mixin providing high-level browser actions."""
    
    def delete_chat_from_url(self, continue_url: str) -> bool:
        """
        Navigate to a saved chat URL and delete it.
        
        Used by the --delete-chat CLI flag for session cleanup.
        
        Args:
            continue_url: The AI Studio chat URL to navigate to and delete.
            
        Returns:
            True if deletion successful, False otherwise.
        """
        print(f"   [>] Navigating to saved chat...")
        
        # Find or create a page
        if len(self.context.pages) == 0:
            page = self.context.new_page()
        else:
            page = self.context.pages[0]
        
        page.goto(continue_url)
        time.sleep(2.0)
        
        return self.delete_current_chat(page)
    
    def delete_current_chat(self, page):
        """
        Delete the current chat after extracting the review.
        
        Flow:
        1. Check if chat has content (empty chats cannot be deleted)
        2. Click 'View more actions' button (top-right menu)
        3. Click 'Delete prompt' option (if enabled)
        4. Wait for confirmation dialog
        5. Click confirm 'Delete' button
        6. Verify the chat was deleted (URL changed to new_chat)
        
        Args:
            page: Playwright page object of the current chat
            
        Returns:
            bool: True if deletion successful, False otherwise
        """
        print("   [~] Cleaning up: Deleting current chat...")
        
        try:
            # Check if chat has content (at least 1 message block)
            message_blocks = page.locator("ms-prompt-chip, ms-chat-turn, .prompt-container").count()
            if message_blocks < 1:
                print("   [i] Chat is empty, nothing to delete.")
                return True  # Nothing to delete is considered success
            
            # Store current URL to verify deletion
            current_url = page.url
            chat_id = current_url.split('/')[-1] if '/prompts/' in current_url else None
            
            # Step 1: Click the 'View more actions' menu button
            menu_sel = self.selectors.get('chat_menu_button', "button[aria-label='View more actions']")
            menu_btn = page.locator(menu_sel)
            
            if menu_btn.count() == 0:
                print("   [!] Could not find 'View more actions' button")
                return False
            
            menu_btn.first.click()
            time.sleep(0.5)  # Wait for menu to open
            
            # Step 2: Click 'Delete prompt' option (check if enabled)
            delete_sel = self.selectors.get('delete_prompt_button', "button[aria-label='Delete prompt']")
            delete_btn = page.locator(delete_sel)
            
            if delete_btn.count() == 0:
                print("   [!] Could not find 'Delete prompt' option")
                page.keyboard.press('Escape')
                return False
            
            # Check if delete button is enabled
            is_disabled = delete_btn.first.get_attribute('aria-disabled')
            if is_disabled == 'true':
                print("   [i] Delete button is disabled (chat may be empty or not deletable).")
                page.keyboard.press('Escape')
                return True  # Not an error, just nothing to delete
            
            delete_btn.first.click()
            time.sleep(0.5)  # Wait for dialog to appear
            
            # Step 3: Wait for confirmation dialog
            dialog_sel = self.selectors.get('dialog_container', "mat-dialog-container")
            try:
                page.wait_for_selector(dialog_sel, timeout=5000)
            except Exception:
                print("   [!] Confirmation dialog did not appear")
                return False
            
            # Step 4: Click confirm 'Delete' button
            confirm_sel = self.selectors.get('dialog_confirm_button', "mat-dialog-container button.ms-button-primary")
            confirm_btn = page.locator(confirm_sel)
            
            if confirm_btn.count() == 0:
                print("   [!] Could not find confirm button in dialog")
                # Close dialog by pressing Escape
                page.keyboard.press('Escape')
                return False
            
            confirm_btn.first.click()
            time.sleep(1.0)  # Wait for deletion to complete
            
            # Step 5: Verify deletion (page should navigate or show different content)
            new_url = page.url
            if chat_id and chat_id not in new_url:
                print(f"   [+] Chat deleted successfully")
                return True
            elif 'new_chat' in new_url or current_url != new_url:
                print(f"   [+] Chat deleted successfully")
                return True
            else:
                # Alternative verification: check if dialog is gone
                if page.locator(dialog_sel).count() == 0:
                    print(f"   [+] Chat cleanup completed")
                    return True
                print("   [!] Could not verify chat deletion")
                return False
                
        except Exception as e:
            print(f"   [!] Error during chat deletion: {e}")
            return False



