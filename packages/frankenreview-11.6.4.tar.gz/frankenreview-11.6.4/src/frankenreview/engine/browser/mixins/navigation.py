"""
Navigation and model selection for AI Studio.
Handles model name extraction and UI-based model switching.
"""
import time


class NavMixin:
    """Mixin providing navigation and model selection capabilities."""
    def _get_active_model_name(self, page):
        """
        Extract the currently selected model name from the AI Studio UI.
        
        Args:
            page: Playwright page object connected to AI Studio
            
        Returns:
            str: Model name (e.g., "Gemini Flash Latest"), "Unknown" if not found,
                 or "Error" on exception
        """
        try:
            # Prefer ms-model-selector button span.title as checked in selector discovery
            el = page.locator("ms-model-selector button span.title").first
            if el.count() > 0:
                name = el.inner_text().strip()
                if name: return name
            
            # Fallback to config selector
            fallback_sel = self.selectors.get('model_name', "ms-model-selector .title")
            el = page.locator(fallback_sel).first
            if el.count() > 0:
                return el.inner_text().strip()
            
            return "Unknown"
        except Exception:
            return "Error"


    def _select_model_via_ui(self, page, requested_model):
        """
        Programmatically select a model via the AI Studio UI dropdown.
        Used when URL parameters fail to correctly set the active model.
        """
        if not requested_model:
            return False

        print(f"   [i] Verifying model selection: {requested_model}...")
        
        # 1. Check if already selected (normalize names for comparison)
        current = self._get_active_model_name(page).lower()
        # Remove version suffixes and "latest" for loose matching
        match_target = requested_model.lower().replace("-latest", "").replace("-preview", "").replace("-exp", "")
        
        if match_target in current.replace(" ", "-"):
            print(f"   [+] Model '{requested_model}' already active in UI.")
            return True

        print(f"   [>] Selecting model '{requested_model}' via UI...")
        try:
            # 2. Open Model Selector - try multiple selector patterns
            model_selector_patterns = [
                "ms-model-selector button",
                "[data-test-id='model-selector'] button",
                "button[aria-label*='Model']",
                "button[aria-label*='model']",
                ".model-selector button",
                "button:has-text('Gemini')"
            ]
            
            model_btn = None
            for pattern in model_selector_patterns:
                try:
                    loc = page.locator(pattern).first
                    if loc.count() > 0 and loc.is_visible():
                        model_btn = loc
                        break
                except Exception:
                    continue
            
            if not model_btn:
                print("   [!] Could not find model selector button.")
                return False
            
            model_btn.click(force=True)
            time.sleep(1.5)
            
            # 2b. Click "All" tab to show all models (not just "Featured")
            all_tab = page.locator('button:has-text("All"), mat-button-toggle:has-text("All")').first
            if all_tab.count() > 0:
                all_tab.click(force=True)
                time.sleep(0.5)

            # 3. Search for the model
            search_sel = "input[placeholder*='Search'], mat-form-field input"
            search_box = page.locator(search_sel).first
            if search_box.count() > 0:
                search_box.fill(requested_model)
                time.sleep(1.5)
            
            # 4. Click the matching model item
            # We look for a button.content-button that contains the model ID text
            item_sel = f"button.content-button:has-text('{requested_model}')"
            item = page.locator(item_sel).first
            
            if item.count() > 0:
                item.click()
                print(f"   [+] Clicked model item: {requested_model}")
                time.sleep(2.0)
                
                # Verify
                new_model = self._get_active_model_name(page)
                print(f"   [i] New Active Model (UI): {new_model}")
                return True
            else:
                # Fallback: try clicking first result if search was specific enough
                first_result = page.locator("button.content-button").first
                if first_result.count() > 0:
                    first_result.click()
                    print(f"   [!] Specific item not found. Clicked first search result.")
                    time.sleep(2.0)
                    return True
                
                print(f"   [!] Could not find model item for '{requested_model}'")
                # Close the modal if it's still open (click outside or Esc)
                page.keyboard.press("Escape")
                return False

        except Exception as e:
            print(f"   [x] UI Model Selection failed: {e}")
            try: page.keyboard.press("Escape")
            except Exception: pass
            return False

