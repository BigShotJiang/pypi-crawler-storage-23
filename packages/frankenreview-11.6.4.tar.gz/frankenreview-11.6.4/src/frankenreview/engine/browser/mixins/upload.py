"""
File upload and paste utilities for browser automation.
Handles XML file preparation, upload mechanisms, text truncation,
and automatic format conversion for unsupported file types.
"""
import os
import time
import base64
import shutil
import tempfile

# File extensions that AI Studio rejects in chat mode
UNSUPPORTED_EXTENSIONS = {'.xml'}

# Mapping of unsupported extension -> safe replacement extension
CONVERSION_MAP = {
    '.xml': '.txt',
}


class UploadMixin:
    """Mixin providing file upload and paste capabilities."""

    def _convert_files_for_upload(self, file_paths):
        """
        Convert unsupported file formats to compatible ones before upload.
        Currently handles XML -> TXT conversion.

        Args:
            file_paths: List of absolute file paths

        Returns:
            List of file paths (converted copies where needed), and a
            list of (original, converted) tuples for reporting.
        """
        converted_paths = []
        conversions = []  # (original_path, converted_path)

        for fp in file_paths:
            ext = os.path.splitext(fp)[1].lower()
            if ext in CONVERSION_MAP:
                target_ext = CONVERSION_MAP[ext]
                basename = os.path.basename(fp)
                new_name = os.path.splitext(basename)[0] + target_ext

                # Create temp copy with new extension
                temp_dir = getattr(self, 'temp_dir', tempfile.gettempdir())
                converted_path = os.path.join(temp_dir, new_name)
                shutil.copy2(fp, converted_path)

                converted_paths.append(converted_path)
                conversions.append((fp, converted_path))
                print(f"   [~] Converted {basename} -> {new_name} (format not supported by AI Studio)")
            else:
                converted_paths.append(fp)

        return converted_paths, conversions

    def _save_xml_to_file(self, xml_content, filename="code_snapshot.txt"):
        """Save XML content to a temporary file for upload."""
        filepath = os.path.join(self.temp_dir, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(xml_content)
        return filepath


    def _simulate_file_paste(self, page, filepath):
        """
        Simulate a 'paste' event containing the file.
        This bypasses the OS file dialog and 'Upload' button interactions by directly 
        injecting the file into the textarea via a synthetic ClipboardEvent.
        """
        try:
            # 1. Read file content and mime type (guess based on extension)
            with open(filepath, 'rb') as f:
                content = f.read()
            
            filename = os.path.basename(filepath)
            mime_type = 'text/plain'
            if filename.endswith('.xml'):
                mime_type = 'text/xml'
            elif filename.endswith('.json'):
                mime_type = 'application/json'
                
            # Convert content to base64 for safe transport to JS
            import base64
            b64_content = base64.b64encode(content).decode('utf-8')
            
            # 2. Execute JS to create File object and dispatch paste event
            js_code = """({b64_content, filename, mime_type}) => {
                try {
                    // Convert base64 back to blob/file
                    const byteCharacters = atob(b64_content);
                    const byteNumbers = new Array(byteCharacters.length);
                    for (let i = 0; i < byteCharacters.length; i++) {
                        byteNumbers[i] = byteCharacters.charCodeAt(i);
                    }
                    const byteArray = new Uint8Array(byteNumbers);
                    const file = new File([byteArray], filename, { type: mime_type });
                    
                    // Create DataTransfer and add file
                    const dataTransfer = new DataTransfer();
                    dataTransfer.items.add(file);
                    
                    // Find the textarea
                    const textarea = document.querySelector('textarea[aria-label="Enter a prompt"]');
                    if (!textarea) return "Error: Textarea not found";
                    
                    textarea.focus();
                    
                    // Dispatch paste event
                    const pasteEvent = new ClipboardEvent('paste', {
                        clipboardData: dataTransfer,
                        bubbles: true,
                        cancelable: true
                    });
                    
                    textarea.dispatchEvent(pasteEvent);
                    return "Success";
                } catch (e) {
                    return "Error: " + e.toString();
                }
            }"""
            
            result = page.evaluate(js_code, {'b64_content': b64_content, 'filename': filename, 'mime_type': mime_type})
            
            if result == "Success":
                # CRITICAL: Verify the file was actually attached by checking for attachment chip
                time.sleep(2)
                verify_script = """() => {
                    // Check for attachment chips (common patterns in AI Studio)
                    const chips = document.querySelectorAll('[class*="attachment"], [class*="chip"], [class*="file-"], .prompt-attachment');
                    if (chips.length > 0) return true;
                    
                    // Check for file name appearing in any element
                    const elements = document.body.innerText;
                    return elements.includes('.xml') || elements.includes('code_snapshot');
                }"""
                
                is_attached = page.evaluate(verify_script)
                if is_attached:
                    print(f"   [+] File '{filename}' attached successfully (verified)")
                    return True
                else:
                    print(f"   [!] JS paste dispatched but file not attached (UI didn't accept it)")
                    return False
            else:
                print(f"   [!] JS Paste Simulation failed: {result}")
                return False
                
        except Exception as e:
            print(f"   [!] Python simulation wrapper failed: {e}")
            return False

    def _try_file_upload(self, page, file_paths):
        """
        Upload multiple files directly using Playwright's set_input_files().
        Auto-detects and removes unsupported files from the upload area.
        
        Args:
            page: Playwright page
            file_paths: List of absolute file paths to upload
            
        Returns:
            True if at least one file uploaded successfully, False otherwise
        """
        print(f"   [f] Uploading {len(file_paths)} files...")
        
        try:
            # Step 0: Convert unsupported formats (XML -> TXT)
            file_paths, conversions = self._convert_files_for_upload(file_paths)
            filenames_for_log = [os.path.basename(fp) for fp in file_paths]
            
            # Step 1: Click the Insert button to make the hidden file input appear
            insert_selector = self.selectors.get('attach_button', "button[aria-label^='Insert']")
            
            try:
                page.wait_for_selector(insert_selector, state="visible", timeout=5000)
            except Exception:
                print(f"   [!] Insert button not found/visible ({insert_selector})")
                return False

            insert_btn = page.locator(insert_selector).first
            insert_btn.click()
            
            # Step 2: Wait for the hidden file input to appear
            file_input_selector = "input.file-input"
            try:
                page.wait_for_selector(file_input_selector, state="attached", timeout=3000)
                print("   [+] File input appeared in DOM")
            except Exception:
                print("   [!] File input did not appear after clicking Insert")
                page.keyboard.press("Escape")
                return False
            
            # Step 3: Set files via Playwright
            page.set_input_files(file_input_selector, file_paths)
            print(f"   [+] Files set via Playwright set_input_files()")
            
            # Step 4: Close menu
            page.keyboard.press("Escape")
            
            # Step 5: Wait for file processing and detect unsupported files
            filenames = [os.path.basename(fp) for fp in file_paths]
            max_wait = 15  # Increased wait for processing
            start_wait = time.monotonic()
            verify_result = None
            
            while time.monotonic() - start_wait < max_wait:
                verify_result = page.evaluate("""(filenames) => {
                    const result = {
                        found: false, 
                        loading: false, 
                        unsupported: [],
                        supported: [],
                        containerCount: 0
                    };
                    
                    // Find all media containers (more specific selectors)
                    const mediaContainers = document.querySelectorAll(
                        '[data-test-id="prompt-media-container"], ' +
                        '.prompt-media-item-container'
                    );
                    result.containerCount = mediaContainers.length;
                    
                    for (const container of mediaContainers) {
                        const text = container.textContent.toLowerCase();
                        const hasError = container.classList.contains('has-error') || 
                                        text.includes('unsupported file');
                        
                        // Extract filename from the container
                        const nameEl = container.querySelector('.name, [title]');
                        let fname = nameEl ? (nameEl.title || nameEl.textContent).trim() : '';
                        
                        // "Generated File..." prefix indicates file is still processing
                        const isGeneratedPlaceholder = fname.toLowerCase().startsWith('generated file');
                        const isLoading = text.includes('generating') || 
                                         text.includes('uploading') ||
                                         isGeneratedPlaceholder;
                        
                        if (isLoading) {
                            result.loading = true;
                        } else if (hasError && fname) {
                            result.unsupported.push(fname);
                        } else if (fname && !isGeneratedPlaceholder) {
                            result.supported.push(fname);
                        }
                    }
                    
                    // Check if all uploaded files are accounted for
                    const allFilesProcessed = filenames.every(fn => {
                        const fnLower = fn.toLowerCase();
                        return result.unsupported.some(u => u.toLowerCase() === fnLower) || 
                               result.supported.some(s => s.toLowerCase() === fnLower);
                    });
                    
                    result.found = allFilesProcessed && !result.loading;
                    return result;
                }""", filenames)
                
                # If still loading, wait and continue
                if verify_result.get('loading'):
                    time.sleep(0.5)
                    continue
                
                # If no containers yet, wait for them to appear
                if verify_result.get('containerCount', 0) == 0:
                    time.sleep(0.5)
                    continue
                    
                # If found (files processed), break
                if verify_result.get('found'):
                    break
                    
                time.sleep(0.5)
            
            # ALWAYS do final verification check - AI Studio may delay marking errors
            # Wait 4 seconds to give AI Studio time to process and mark unsupported files
            time.sleep(4)
            verify_result = page.evaluate("""(filenames) => {
                const result = {unsupported: [], supported: [], debug: []};
                const mediaContainers = document.querySelectorAll(
                    '[data-test-id="prompt-media-container"], .prompt-media-item-container'
                );
                for (const container of mediaContainers) {
                    const hasError = container.classList.contains('has-error') || 
                                    container.textContent.toLowerCase().includes('unsupported file');
                    
                    // More robust filename extraction - try multiple strategies
                    let fname = '';
                    // Strategy 1: Look for .name element with title attribute
                    const nameElWithTitle = container.querySelector('.name[title]');
                    if (nameElWithTitle) {
                        fname = nameElWithTitle.getAttribute('title') || '';
                    }
                    // Strategy 2: Look for any element with title matching expected patterns
                    if (!fname) {
                        const titleEl = container.querySelector('[title*="."]');
                        if (titleEl) {
                            fname = titleEl.getAttribute('title') || '';
                        }
                    }
                    // Strategy 3: Match against known filenames in text
                    if (!fname) {
                        const containerText = container.textContent;
                        for (const expectedName of filenames) {
                            if (containerText.includes(expectedName)) {
                                fname = expectedName;
                                break;
                            }
                        }
                    }
                    
                    result.debug.push({hasError, fname, text: container.textContent.substring(0, 80)});
                    
                    if (hasError && fname) {
                        result.unsupported.push(fname);
                    } else if (fname && !fname.toLowerCase().startsWith('generated file')) {
                        result.supported.push(fname);
                    }
                }
                return result;
            }""", filenames)
            
            # Step 6: Handle unsupported files
            unsupported = verify_result.get('unsupported', []) if verify_result else []
            if unsupported:
                for fname in unsupported:
                    print(f"   [!] Unsupported file: {fname} (removing)")
                
                # Remove unsupported file attachments
                removed = self._remove_unsupported_files(page)
                if removed > 0:
                    print(f"   [+] Removed {removed} unsupported file(s)")
            
            # Check if any files were successfully uploaded
            supported = verify_result.get('supported', [])
            if supported:
                print(f"   [+] File attachment verified: {len(supported)} file(s)")
                return True
            elif not unsupported:
                # No verification but also no errors - assume success
                time.sleep(2)
                print(f"   [!] File set but UI verification inconclusive (continuing)")
                return True
            else:
                # All files were unsupported
                print(f"   [x] All files unsupported. Use .txt extension for XML content.")
                return False
                
        except Exception as e:
            print(f"   [!] File upload failed: {e}")
            page.keyboard.press("Escape")
            return False


    def _remove_unsupported_files(self, page):
        """
        Remove unsupported file attachments from the input area.
        
        Args:
            page: Playwright page
            
        Returns:
            Number of files removed
        """
        try:
            # Find all containers with has-error class and click their remove buttons
            removed = page.evaluate("""() => {
                let count = 0;
                const errorContainers = document.querySelectorAll(
                    '.prompt-media-item-container.has-error, ' +
                    '[data-test-id="prompt-media-container"].has-error'
                );
                
                for (const container of errorContainers) {
                    const removeBtn = container.querySelector(
                        'button[aria-label="Remove media"], ' +
                        'button[aria-label*="Remove"], ' +
                        '.action-button'
                    );
                    if (removeBtn) {
                        removeBtn.click();
                        count++;
                    }
                }
                return count;
            }""")
            
            if removed > 0:
                time.sleep(0.5)  # Brief wait after removal
            
            return removed
        except Exception:
            return 0


    def _truncate_for_paste(self, xml_content):
        """
        Truncate XML content to safe size for browser paste operations.
        
        Args:
            xml_content: Full XML string to potentially truncate
            
        Returns:
            str: Original content if under limit, or truncated with marker
        """
        if len(xml_content) > self.max_paste_size:
            return xml_content[:self.max_paste_size] + "\n\n<!-- CONTENT TRUNCATED FOR BROWSER SAFETY -->\n"
        return xml_content


    def _get_clipboard_content(self):
        """
        Retrieve current content from system clipboard.
        
        Returns:
            str: Clipboard text content, or None on failure/unavailable
        """
        try:
            import pyperclip
            return pyperclip.paste()
        except ImportError:
            print("   [!] pyperclip not installed, cannot read clipboard")
            return None
        except Exception as e:
            print(f"   [!] Clipboard read error: {e}")
            return None

