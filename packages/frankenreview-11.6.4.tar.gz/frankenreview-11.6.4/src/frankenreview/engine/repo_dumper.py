"""
Frankenreview v11 - Repository Dumper (repo_dumper.py)
Layer 4: Creates XML dumps of repository contents for code review.

This module creates structured XML dumps of repository code, intelligently
filtering out binary files, build artifacts, and noise while preserving
the essential codebase structure.

Features:
- Smart file filtering (ignores .git, node_modules, etc.)
- Binary file detection
- Outlier detection (skips abnormally large files)
- Jupyter notebook conversion to Markdown
- XML-structured output for LLM consumption
- Security hardening (prunes secrets and sensitive files)
"""

import os
import sys
import subprocess
import fnmatch
from pathlib import Path
import shutil
import time
import concurrent.futures
from dataclasses import dataclass, field
from typing import List, Dict, Set, Optional, Tuple, Any
from xml.sax.saxutils import escape, quoteattr
# Try to import nbformat/nbconvert for Jupyter notebooks
try:
    import nbformat
    from nbconvert import MarkdownExporter
    NOTEBOOK_SUPPORT = True
except ImportError:
    NOTEBOOK_SUPPORT = False


# ---------- Default Settings ----------
DEFAULT_OUTPUT_DIR = "dumps"

# Directories we never descend into
PRUNE_DIRS = {
    # Version control
    ".git", ".hg", ".svn", ".idea", ".vscode", ".kiro", ".build",
    # Caches
    "__pycache__", ".mypy_cache", ".pytest_cache", ".cache", ".ruff_cache",
    # Dependencies
    "node_modules", ".next", ".nuxt", "dist", "build", "coverage",
    "venv", ".venv", "env", "site-packages", ".aider.tags.cache.v4",
    # Platform specific
    "Pods", "DerivedData", ".gradle", "target",
    # Project internal
    "repo2txt_clean", "repo2txt_out", "repo_dump", "tests",
    "docker", "Docs_build", "examples", "demo", "Tests",
    ".app", "deleted", "archive", "old", "backup", "bak",
    "public", "assets", "migrations", "dumps",
    # VS Code extension output
    "vscode-extension", "out",
    # Scraped/downloaded garbage
    "GoogleAIStudio", "Google AI Studio_files", "docs",
    # Frankenreview internal
    ".frankenreview", "context", "dumps_test"
}

# Files to skip by exact name
PRUNE_FILENAMES = {
    # System
    ".DS_Store", "Thumbs.db",
    # Config/Lock files (that are usually noise)
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml", "poetry.lock",
    "Gemfile.lock", "composer.lock", "cargo.lock",
    # Secrets & Sensitive Data (Hardening)
    ".env", ".env.local", ".env.development", ".env.production", ".env.test",
    "credentials.json", "service_account.json", "secrets.yaml",
    "id_rsa", "id_dsa", "id_ed25519", ".pem", ".key",
    # Frankenreview internals
    "review.md", "task.md", "implementation_plan.md", "walkthrough.md",
    "project_evaluation.md", "checklist.md", "last_response_dump.html"
}


# Skip by extension (binary, noisy, or garbage)
SKIP_EXTS = {
    # Archives
    ".zip", ".gz", ".bz2", ".xz", ".tar", ".rar", ".7z",
    # Media
    ".mp4", ".mp3", ".mov", ".wav", ".avi", ".wmv", ".webm", ".flv",
    # Binary/compiled
    ".so", ".dll", ".dylib", ".node", ".wasm", ".class", ".o", ".a",
    ".exe", ".bin", ".pack", ".db", ".sqlite", ".pkl", ".onnx", ".icns",
    # Fonts
    ".plist", ".eot", ".ttf", ".woff", ".woff2",
    # Web garbage (scraped pages, generated HTML, etc.)
    ".htm", ".mhtml", ".webarchive",
    # Minified/generated
    ".min.js", ".min.css", ".map",
    # Office
    ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    # Lock files
    ".lock",
}

# Content-filtered extensions (include in tree but not content)
SKIP_CONTENT_EXTS = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".pdf", ".csv", ".tsv"
}

MAX_BYTES = 5_000_000  # 5MB per-file limit to avoid memory exhaustion
OUTLIER_P95_FACTOR = 5.0
OUTLIER_MIN_LINES = 10000

@dataclass
class RepoFile:
    relpath: str
    abs_path: str
    size: int
    line_count: int = 0
    token_estimate: int = 0
    is_ipynb: bool = False
    is_binary: bool = False
    skip_reason: Optional[str] = None

class RepoScanner:
    """
    Unified high-performance repository scanner.
    Uses os.scandir for single-pass directory traversal and parallel metadata collection.
    """
    def __init__(self, repo_path: str, prune_dirs: list = None, prune_files: list = None, prune_exts: list = None):
        self.repo_root = Path(repo_path).resolve()
        self.prune_dirs = set(prune_dirs) if prune_dirs else PRUNE_DIRS
        self.prune_filenames = set(prune_files) if prune_files else PRUNE_FILENAMES
        self.prune_exts = set(prune_exts) if prune_exts else SKIP_EXTS
        self.git_ignored = get_git_ignored(self.repo_root)
        
        # Performance metrics
        self.scan_time = 0
        self.meta_time = 0
        
        # Results
        self.files: List[RepoFile] = []
        self.tree_entries: List[str] = []

    def scan(self, parallel: bool = True):
        """Perform recursive scan and metadata collection."""
        start_scan = time.time()
        candidates = []
        
        # Step 1: Rapid recursive walk (scandir is 2-20x faster than os.walk)
        self._recursive_walk(self.repo_root, candidates)
        self.scan_time = time.time() - start_scan
        
        # Step 2: Parallel metadata enrichment
        start_meta = time.time()
        if parallel and candidates:
            with concurrent.futures.ThreadPoolExecutor() as executor:
                # Process in batches to balance overhead vs parallelism
                results = list(executor.map(self._enrich_metadata, candidates))
                self.files = [f for f in results if f is not None]
        else:
            self.files = [self._enrich_metadata(c) for c in candidates]
            self.files = [f for f in self.files if f is not None]
            
        self.meta_time = time.time() - start_meta
        return self.files

    def _recursive_walk(self, current_dir: Path, candidates: List[Tuple[Path, str]]):
        """Internal recursive walker using scandir."""
        try:
            with os.scandir(current_dir) as it:
                for entry in it:
                    if entry.is_dir():
                        if entry.name in self.prune_dirs or entry.name.startswith("."):
                            continue
                        # If directory is gitignored, we might still want to show it in tree but skip context
                        # For now, if it's in prune_dirs, we skip entirely.
                        self._recursive_walk(Path(entry.path), candidates)
                    elif entry.is_file():
                        fpath = Path(entry.path)
                        relpath = str(fpath.relative_to(self.repo_root))
                        
                        # Tree entry for ALL non-pruned files
                        self.tree_entries.append(relpath)
                        
                        # Filter for context dump
                        if entry.name in self.prune_filenames:
                            continue
                        
                        ext = fpath.suffix.lower()
                        if ext in self.prune_exts:
                            continue
                            
                        if self.git_ignored and relpath in self.git_ignored:
                            # Only dump gitignored if they aren't standard noise exts
                            if ext in SKIP_CONTENT_EXTS:
                                continue
                                
                        if entry.stat().st_size > MAX_BYTES:
                            continue
                            
                        candidates.append((fpath, relpath))
        except (PermissionError, FileNotFoundError):
            pass

    def _enrich_metadata(self, candidate: Tuple[Path, str]) -> Optional[RepoFile]:
        """Collect deep metadata (binary check, line count, tokens) for a file."""
        fpath, relpath = candidate
        try:
            stat = fpath.stat()
            repo_file = RepoFile(relpath=relpath, abs_path=str(fpath), size=stat.st_size)
            
            # 1. Binary Check
            is_binary = False
            try:
                with open(fpath, "rb") as rb:
                    chunk = rb.read(8192) # Larger chunk for better detection
                    if b"\x00" in chunk:
                        is_binary = True
            except Exception:
                is_binary = True # Assume binary if we can't read it
            
            repo_file.is_binary = is_binary
            if is_binary:
                return repo_file
                
            # 2. Line Count and Content Sampling
            line_count = 0
            char_count = 0
            is_ipynb = fpath.suffix.lower() == ".ipynb"
            repo_file.is_ipynb = is_ipynb
            
            if is_ipynb:
                if NOTEBOOK_SUPPORT:
                    md = convert_ipynb_to_md(fpath)
                    if md:
                        line_count = len(md.splitlines())
                        char_count = len(md)
            else:
                try:
                    with open(fpath, "r", encoding="utf-8", errors="ignore") as fh:
                        content = fh.read()
                        line_count = len(content.splitlines())
                        char_count = len(content)
                except Exception as read_err:
                    print(f"   [!] Skipped '{fpath.name}': {read_err}")
                    return None
            
            repo_file.line_count = line_count
            
            # 3. Token Estimation (Optimized Heuristic)
            # Tiktoken is slow to import/initialize in threads, so we use a calibrated heuristic
            # Gemini typically does ~3.5 to 3.8 chars per token for code.
            repo_file.token_estimate = int(char_count / 3.7)
            
            return repo_file
        except Exception:
            return None

    def get_token_report(self) -> str:
        """Generate a formatted token report from scanned data."""
        valid_files = [f for f in self.files if not f.is_binary]
        if not valid_files:
            return "No valid files found for analysis."
            
        total_tokens = sum(f.token_estimate for f in valid_files)
        total_files = len(valid_files)
        repo_name = self.repo_root.name
        
        # 1. Top 10 Files
        sorted_files = sorted(valid_files, key=lambda x: x.token_estimate, reverse=True)
        
        # 2. Folder Aggregates
        folder_stats = {}
        for f in valid_files:
            parts = f.relpath.split(os.sep)
            folder = parts[0] + "/" if len(parts) > 1 else "(root)/"
            if folder not in folder_stats:
                folder_stats[folder] = {"tokens": 0, "files": 0}
            folder_stats[folder]["tokens"] += f.token_estimate
            folder_stats[folder]["files"] += 1
            
        sorted_folders = sorted(folder_stats.items(), key=lambda x: x[1]["tokens"], reverse=True)
        
        # Build Output
        lines = []
        lines.append("")
        lines.append("╔════════════════════════════════════════════════════════════════╗")
        lines.append("║  FRANKENREVIEW TOKEN EATERS ANALYSIS (Turbo)                   ║")
        lines.append("╚════════════════════════════════════════════════════════════════╝")
        lines.append("")
        lines.append(f"Repository: {repo_name}")
        lines.append(f"Total: ~{total_tokens:,} tokens from {total_files} files")
        scan_ms = self.scan_time * 1000
        meta_ms = self.meta_time * 1000
        lines.append(f"Scan: {scan_ms:.1f}ms | Metadata: {meta_ms:.1f}ms | Total: {scan_ms + meta_ms:.1f}ms")
        lines.append("")
        
        lines.append("TOP 10 FILES (by token count):")
        lines.append("─" * 66)
        lines.append(f" {'#':>2}   {'Tokens':>10}   {'%':>5}   File")
        lines.append("─" * 66)
        
        for i, item in enumerate(sorted_files[:10], 1):
            pct = (item.token_estimate / total_tokens * 100) if total_tokens > 0 else 0
            lines.append(f" {i:>2}   {item.token_estimate:>10,}   {pct:>4.1f}%   {item.relpath}")
            
        lines.append("")
        lines.append("TOP 10 FOLDERS (by token count):")
        lines.append("─" * 66)
        lines.append(f" {'#':>2}   {'Tokens':>10}   {'%':>5}   {'Files':>5}   Folder")
        lines.append("─" * 66)
        
        for i, (folder, data) in enumerate(sorted_folders[:10], 1):
            pct = (data["tokens"] / total_tokens * 100) if total_tokens > 0 else 0
            lines.append(f" {i:>2}   {data['tokens']:>10,}   {pct:>4.1f}%   {data['files']:>5}   {folder}")
            
        lines.append("")
        lines.append("TIP: Use --prune-add-dir or --prune-add-file to exclude heavy items.")
        lines.append("─" * 66)
        
        return "\n".join(lines)
# --------------------------------


def cleanup_dumps(dump_dir: str = None, max_age_hours: float = 24.0, keep_latest: bool = True) -> int:
    """
    Clean up old dump files and debug screenshots to prevent stale cache issues.
    
    Args:
        dump_dir: Directory containing dumps (defaults to 'dumps' in project root)
        max_age_hours: Delete files older than this (default 24 hours)
        keep_latest: If True, always keep the most recent .xml file per repo
        
    Returns:
        Number of files deleted
    """
    import time
    import glob
    
    if dump_dir is None:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(os.path.dirname(current_dir))
        dump_dir = os.path.join(project_root, DEFAULT_OUTPUT_DIR)
    
    if not os.path.exists(dump_dir):
        return 0
    
    deleted_count = 0
    now = time.time()
    max_age_seconds = max_age_hours * 3600
    
    # Group XML files by repo name to keep latest
    xml_files = {}
    for f in glob.glob(os.path.join(dump_dir, "*.xml")):
        repo_name = os.path.basename(f).replace(".xml", "")
        mtime = os.path.getmtime(f)
        if repo_name not in xml_files or mtime > xml_files[repo_name][1]:
            xml_files[repo_name] = (f, mtime)
    
    # Delete old XML files (but keep latest per repo if requested)
    for f in glob.glob(os.path.join(dump_dir, "*.xml")):
        mtime = os.path.getmtime(f)
        repo_name = os.path.basename(f).replace(".xml", "")
        
        is_latest = keep_latest and xml_files.get(repo_name, (None, 0))[0] == f
        is_old = (now - mtime) > max_age_seconds
        
        if is_old and not is_latest:
            try:
                os.remove(f)
                deleted_count += 1
            except Exception:
                pass
    
    # Always delete old debug screenshots (older than max_age)
    for pattern in ["debug-*.png", "*.tokens.csv"]:
        for f in glob.glob(os.path.join(dump_dir, pattern)):
            try:
                mtime = os.path.getmtime(f)
                if (now - mtime) > max_age_seconds:
                    os.remove(f)
                    deleted_count += 1
            except Exception:
                pass
    
    return deleted_count


def cleanup_current_dump(dump_path: str) -> bool:
    """
    Delete a specific dump file after use.
    
    Args:
        dump_path: Path to the dump file to delete
        
    Returns:
        True if deleted successfully
    """
    try:
        if os.path.exists(dump_path):
            os.remove(dump_path)
            return True
    except Exception:
        pass
    return False


def human(n: int) -> str:
    """Format number with commas"""
    return f"{n:,}"


def should_skip_dir(dirname: str, prune_dirs: list = None) -> bool:
    """Check if directory should be skipped"""
    prune_set = set(prune_dirs) if prune_dirs else PRUNE_DIRS
    return dirname.strip() in prune_set


def should_skip_file(path: Path, repo_root: Path, git_ignored=None, prune_files: list = None, prune_exts: list = None) -> tuple:
    """Check if file should be skipped. Returns (skip, reason)"""
    git_ignored = git_ignored or set()
    prune_files_set = set(prune_files) if prune_files else PRUNE_FILENAMES
    prune_exts_set = set(prune_exts) if prune_exts else SKIP_EXTS
    name = path.name
    
    if name in prune_files_set:
        return True, "prune_name"
    
    ext = path.suffix.lower()
    if ext in prune_exts_set:
        return True, f"ext:{ext}"
    
    try:
        rel = str(path.relative_to(repo_root))
    except Exception:
        rel = str(path)

    if git_ignored and rel in git_ignored:
        if name in prune_files_set or ext in prune_exts_set or ext in SKIP_CONTENT_EXTS:
            return True, "gitignored"
    
    try:
        size = path.stat().st_size
    except FileNotFoundError:
        return True, "missing"
    
    if size > MAX_BYTES:
        return True, f"size>{MAX_BYTES}"
    
    return False, ""


def percentile(sorted_list, p: float):
    """Calculate percentile of sorted list"""
    if not sorted_list:
        return 0
    k = (len(sorted_list) - 1) * p / 100.0
    f = int(k)
    c = min(f + 1, len(sorted_list) - 1)
    if f == c:
        return sorted_list[f]
    d0 = sorted_list[f] * (c - k)
    d1 = sorted_list[c] * (k - f)
    return d0 + d1


def get_git_ignored(repo_root: Path) -> set:
    """Return set of gitignored file paths relative to repo_root"""
    ignored = set()
    try:
        out = subprocess.check_output([
            "git", "-C", str(repo_root), "ls-files",
            "--others", "--ignored", "--exclude-standard", "-z"
        ], stderr=subprocess.DEVNULL)
        for p in out.decode('utf-8', errors='ignore').split('\0'):
            if p:
                ignored.add(p)
    except Exception:
        # Fallback to manual .gitignore parsing
        gitignore = repo_root / '.gitignore'
        if gitignore.exists():
            try:
                with open(gitignore, 'r', encoding='utf-8', errors='ignore') as f:
                    patterns = [l.strip() for l in f if l.strip() and not l.startswith('#')]
                
                for dirpath, _, filenames in os.walk(repo_root):
                    for fname in filenames:
                        rel = os.path.relpath(os.path.join(dirpath, fname), repo_root)
                        for pat in patterns:
                            if pat.endswith('/'):
                                if rel.startswith(pat.rstrip('/')):
                                    ignored.add(rel)
                                    break
                            elif fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(fname, pat):
                                ignored.add(rel)
                                break
            except Exception:
                pass
    return ignored


def build_tree_entries(repo_root: Path, git_ignored=None, prune_dirs: list = None, prune_files: list = None) -> list:
    """Build list of files for repository tree"""
    git_ignored = git_ignored or set()
    entries = []
    
    for p in repo_root.rglob('*'):
        if not p.is_file():
            continue
        try:
            rel = p.relative_to(repo_root)
        except Exception:
            rel = p
        
        parts = [str(x) for x in rel.parts]
        if any(part.startswith('.') for part in parts):
            continue
            
        # Helper manual check for prune dirs in path (rglob does not follow skip logic)
        # Note: This is an approximation for tree display
        if prune_dirs:
            if any(part in prune_dirs for part in parts):
                continue
        elif any(part in PRUNE_DIRS for part in parts):
            continue
        
        rels = str(rel)
        if git_ignored and rels in git_ignored:
            continue
        
        entries.append(rels)
    
    return sorted(entries)


def compute_outlier_threshold(line_counts: list) -> float:
    """Compute threshold for outlier detection"""
    if len(line_counts) < 12:
        return float("inf")
    sl = sorted(line_counts)
    p95 = percentile(sl, 95.0)
    return max(OUTLIER_MIN_LINES, int(p95 * OUTLIER_P95_FACTOR))


def render_tree(repo_name: str, rel_paths: list, include_dirs=None) -> str:
    """Render pretty tree of files"""
    root = {}
    for rp in sorted(rel_paths):
        parts = rp.split(os.sep)
        cur = root
        for d in parts[:-1]:
            cur = cur.setdefault(d, {})
        cur.setdefault("_files", []).append(parts[-1])

    if include_dirs:
        for idir in include_dirs:
            if not idir:
                continue
            parts = idir.split(os.sep)
            cur = root
            for d in parts:
                cur = cur.setdefault(d, {})

    lines = [f"{repo_name}/"]
    
    def walk(node, prefix=""):
        dirs = sorted(k for k in node.keys() if k != "_files")
        files = sorted(node.get("_files", []))
        
        for i, d in enumerate(dirs):
            last = (i == len(dirs) - 1) and (not files)
            branch = "└── " if last else "├── "
            lines.append(prefix + branch + d + "/")
            walk(node[d], prefix + ("    " if last else "│   "))
        
        for j, f in enumerate(files):
            last = (j == len(files) - 1)
            branch = "└── " if last else "├── "
            lines.append(prefix + branch + f)
    
    walk(root)
    return "\n".join(lines)


def convert_ipynb_to_md(ipynb_path: Path) -> str:
    """Convert Jupyter Notebook to Markdown"""
    if not NOTEBOOK_SUPPORT:
        return ""
    try:
        with open(ipynb_path, "r", encoding="utf-8") as f:
            notebook = nbformat.read(f, as_version=4)
        exporter = MarkdownExporter()
        body, _ = exporter.from_notebook_node(notebook)
        return body
    except Exception as e:
        print(f"[!] Error converting {ipynb_path}: {e}")
        return ""


def analyze_token_eaters(repo_path: str, prune_dirs: list = None, prune_files: list = None, prune_exts: list = None) -> str:
    """
    Analyze repository to find top token-consuming files and folders.
    Now uses the Turbo RepoScanner for maximum efficiency.
    """
    scanner = RepoScanner(repo_path, prune_dirs, prune_files, prune_exts)
    scanner.scan(parallel=True)
    return scanner.get_token_report()


def dump_repo(repo_path: str, output_dir: str = None, prune_dirs: list = None, prune_files: list = None, prune_exts: list = None, prune_changelogs: bool = False) -> str:
    """
    Create an XML dump of a repository using the optimized RepoScanner.
    """
    repo_root = Path(repo_path).resolve()
    repo_name = repo_root.name
    
    import uuid
    sys_uuid = uuid.uuid4().hex
    
    if output_dir is None:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(os.path.dirname(current_dir))
        output_dir = os.path.join(project_root, DEFAULT_OUTPUT_DIR)
    
    out_path = Path(output_dir) / f"{repo_name}.xml"
    
    # 1. High Performance Scan
    scanner = RepoScanner(repo_path, prune_dirs, prune_files, prune_exts)
    files = scanner.scan(parallel=True)
    
    # 2. Outlier Detection
    line_counts = [f.line_count for f in files if not f.is_binary]
    thr = compute_outlier_threshold(line_counts)
    
    kept = []
    skipped_outliers = []
    for f in files:
        if not f.is_binary and f.line_count > thr:
            f.skip_reason = f"lines>{thr}"
            skipped_outliers.append(f)
        else:
            kept.append(f)

    # 3. Tree Generation (Fast)
    tree_txt = render_tree(repo_name, scanner.tree_entries)

    # 4. Filtered files for summary
    skipped_rules_count = len([f for f in files if f.skip_reason]) # Logic check: scanner filter doesn't set skip_reason yet
    # Actually, RepoScanner already filters files. We only have 'kept' candidates in scanner.files.
    
    # 5. Write XML output
    out_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(out_path, "w", encoding="utf-8") as out:
        out.write(f'<repository_context name="{repo_name}">\n')
        
        from datetime import datetime
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        summary = (f"Summary: tree {human(len(scanner.tree_entries))} files | "
                   f"contents_dumped {human(len(kept))} files | "
                   f"skipped_outliers {human(len(skipped_outliers))} "
                   f"(threshold = {human(thr)} lines) | "
                   f"Scan: {scanner.scan_time * 1000:.1f}ms Meta: {scanner.meta_time * 1000:.1f}ms | "
                   f"Generated: {timestamp}")
        out.write(f"<!-- {summary} -->\n\n")

        out.write(f"<!-- REPO_UUID:{sys_uuid} -->\n")
        out.write("<file_tree>\n")
        out.write(tree_txt)
        out.write("\n</file_tree>\n\n")

        # File contents
        for f in sorted(kept, key=lambda x: x.relpath):
            if f.is_binary: continue
            
            rp = f.relpath
            import base64
            b64_rp = base64.b64encode(rp.encode('utf-8')).decode('utf-8')
            out.write(f'<!-- START_FILE:{sys_uuid}:{b64_rp} -->\n')
            out.write(f'<file path={quoteattr(rp)}>\n')

            if f.is_ipynb:
                try:
                    md = convert_ipynb_to_md(Path(f.abs_path))
                    if md:
                        for line in md.splitlines():
                            out.write(escape(line) + "\n")
                except Exception:
                    out.write("<!-- ipynb conversion failed -->\n")
            else:
                try:
                    is_changelog = prune_changelogs and "CHANGELOG" in rp.upper() and rp.upper().endswith(".MD")
                    
                    with open(f.abs_path, "r", encoding="utf-8", errors="ignore") as fh:
                        if is_changelog:
                            lines = fh.readlines()
                            if len(lines) > 50:
                                out.write(f"<!-- PRUNED: Truncated {len(lines)} lines to last 50 for AI context hygiene -->\n")
                                lines = lines[-50:]
                            for line in lines:
                                 out.write(escape(line))
                        else:
                            # Stream in larger chunks for speed
                            while True:
                                chunk = fh.read(65536)
                                if not chunk: break
                                out.write(escape(chunk))
                except Exception:
                    out.write("<!-- read_error or permission denied -->\n")

            out.write(f"\n</file>\n")
            out.write(f'<!-- END_FILE:{sys_uuid}:{b64_rp} -->\n\n')

        # Skipped outliers
        if skipped_outliers:
            out.write("<skipped_files>\n")
            out.write("  <!-- Outliers (too many lines): -->\n")
            for f in sorted(skipped_outliers, key=lambda x: x.relpath):
                out.write(f'  <item path="{f.relpath}" reason="{f.skip_reason}" />\n')
            out.write("</skipped_files>\n")

        out.write("</repository_context>")
        
    return str(out_path)

    print(f"[+] Wrote {out_path}")
    return str(out_path)


def main():
    """CLI entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Create a compact XML dump of a repository.'
    )
    parser.add_argument('repo', nargs='?', default='.', 
                        help='Path to repository (default: current dir)')
    parser.add_argument('--output', default=None, 
                        help='Output directory for dumps')
    args = parser.parse_args()
    
    dump_repo(args.repo, args.output)


if __name__ == "__main__":
    main()
