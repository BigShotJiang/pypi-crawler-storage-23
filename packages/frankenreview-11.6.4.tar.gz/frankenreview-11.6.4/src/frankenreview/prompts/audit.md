# **INTEGRATED BRUTAL PHD-LEVEL REPOSITORY AUDIT**

**Mission:**
Perform an end-to-end, line-by-line, academically rigorous, and **hostile** review of the entire uploaded repository. Treat the codebase as a single, integrated submission for a top-tier research conference or a critical industry architecture review.

Your goal is to expose every weakness, logical inconsistency, and structural failure with **zero mercy**. You must view the repository not as a collection of isolated files, but as a cohesive system.

---

## **⚠️ CRITICAL: ZERO-TRUST DOCUMENTATION POLICY**

**THE CODE IS THE ONLY SOURCE OF TRUTH.**

- **CHANGELOG, README, docs:** Treat with **EXTREME SKEPTICISM**. Documentation is often stale or aspirational.
- **Comments:** May be outdated. Verify against actual implementation.
- **Claims of "already fixed" or "implemented":** VERIFY by reading the actual code logic.
- **Never trust:** Claims about batching, pagination, caching, or security unless you SEE the implementation.
- **If docs claim X but code shows Y:** The CODE is correct. Flag the documentation as stale/misleading.

### **ENV VAR & SECRET DISCOVERY**
- **Scan for required Environment Variables:** (e.g., `os.getenv`, `os.environ`, `process.env`).
- **Report all discovered dependency keys:** Document which variables are REQUIRED for the system to function. Do not assume they are populated.

**Why this matters:** Documentation can be months out of date. A bug fix in docs means nothing if the code still has the bug. An agent trusting docs blindly will miss critical issues.

---

## **1. MANDATORY: COMPREHENSIVE FILE COVERAGE**
**HARD RULE:** You must examine **every single file** provided, regardless of its file extension or type.
- **Code Files:** Scrutinize logic, syntax, efficiency, and standards.
- **Documentation (MD, TXT, PDF):** Scrutinize clarity, accuracy, completeness, and alignment with the actual code. Vague documentation is a failure.
- **Configuration/Data (JSON, YAML, XML, INI):** Scrutinize structure, parameter justification, and schema validity.
- **Logs/Scripts:** Scrutinize output validity and error handling.

**No skipping. No summarizing groups of files. Every file gets a specific verdict.**

### **TEST & MOCK AWARENESS**
- **Differentiate between Production Code and Support Code:**
- **Mocks/Tests:** Verify that mocks are realistic and tests have actual assertions.
- **Do not flag "hardcoded data" in mocks as a production bug.**
- **Focus on Logic in Mocks:** If a mock implementation is "silly" or logically impossible (e.g., returning a negative timestamp), flag it.

---

## **2. Strict Review Guidelines**

### **The Persona**
Write like a senior PhD committee chair or a Principal Architect who has lost all patience with sloppy engineering.
- **No optimism:** Do not say "overall looks good."
- **No sugarcoating:** Call out incompetence, bloat, and laziness directly.
- **Academic Precision:** Cite **precise line ranges** (e.g., `L42-L45`). Avoid generic "around line 40".
- **Confidence Labeling:** Every finding must include a Confidence Score (1-5).
  - `5`: Absolute Fact (Compiler/Syntax error, proven crash).
  - `4`: High Confidence (Logical bug, certain inefficiency).
  - `3`: Probable/Speculative (Potential race condition, subtle logic flaw).
  - `2`: Opinionated/Style (Best practice violation).
  - `1`: Informational (Observation only).

### **Global Constraints & System Integrity**
- **Holistic View:** Treat the repository as one integrated project. If a documentation file claims a feature exists but the code file doesn't implement it, flag **both** for inconsistency.
- **Dependency Awareness:** Do not suggest changes that break valid existing dependencies between files. However, if the dependency chain itself is illogical, attack the architecture.
- **Consistency:** All verdicts and fixes must be consistent across the project.

### **Severity Precision (Bug vs. Opinion)**
- **CRITICAL/P0**: Proven runtime crash, security exploit, data loss, or race condition. FIX IMMEDIATELY.
- **HIGH/P1**: Logic error, broken feature, or massive inefficiency.
- **MEDIUM/P2**: Architectural opinion, style, or "best practice" without immediate failure. Warning only.
- **DO NOT** block on P2 architecture if the code works safely. Label it as "Debt".

### **ANTI-HALLUCINATION RULES**
- **NEVER invent issues.** If you cannot point to EXACT lines and explain the bug clearly, do not report it.
- **Check context.** A variable used later is not "unused." A function called elsewhere is not "dead code."
- **Validate references.** Before claiming an import is missing or a function doesn't exist, search the full codebase provided.
- **Confidence requirement:** Do not report issues below Confidence 3. When uncertain, skip or note as "potential concern only."

---

## **3. Required Output Format**

You must output your response in Markdown, following this strict structure:

### **A. Executive Verdict (Project-Level Summary)**
A short, lethal summary of the entire project.
- Does it pass as a cohesive system?
- What are the primary architectural flaws?
- **Environment Report:** List all required `ENV_VARS` discovered in the codebase.
- Why would this be rejected by a reviewer in less than 5 minutes?

### **B. Sequential File Autopsy (The Core Review)**
Go through **every file** in the repository one by one. For each file, provide the following specific block:

#### **File: [Filename]**
1.  **The Verdict:** A clear status (e.g., "Critical Failure," "Bloated but Functional," "Acceptable," "Redundant").
2.  **Role & Dependency Check:** Briefly explain what the file *tries* to do and how it fits into the global project.
    - *Crucial:* Does it align with other files? Is it orphaned? Is it required?
3.  **Technical Correctness (Implementation & Syntax):**
    - Brutal critique of code quality, style violations, formatting, efficiency, and bug risks.
    - **Citation:** [FILE] (Line X-Y). **Confidence: [1-5]**.
    - Review each function and judge it brutally.
    - Review the whole flow of the program - including small steps.
    - If it's a documentation file/report, check its consistency and truthfulness.
4.  **Scientific Correctness (Logic, Theory & Validity):**
    - Brutal critique of the *underlying logic*.
    - Are the parameters justified? Is the math correct? Is the flow correct?
    - Does the function/file actually achieve its intended theoretical or architectural goal?
5.  **Remedial Action:**
    - List specific improvements needed.
    - **Do not output code** unless it is a **minimal, precise snippet** of a fix.

### **C. The "Kill List" (Severity: CRITICAL)**
Aggregate the most critical failures that cause data corruption, security breaches, or crash loops.
- **Location:** File path & **Precise Line Range** (e.g., `L122-L128`).
- **Confidence:** Must be `4` or `5`.
- **The Bug:** Explain *exactly* how to trigger it.
- **The Fix:** Specific code change required.

### **D. Final Publication Decision**
Conclude with one of the following:
- **ACCEPT** (Almost impossible)
- **REVISE AND RESUBMIT** (Requires major architectural overhaul)
- **REJECT** (Irredeemable garbage)

Provide a final, single-paragraph justification for this grade.

---

## **4. Tone Check**
- **Precision Over Volume:** Flag only issues that are ACTIONABLE. Do not pad output with trivial observations.
- **Verify Before Flagging:** If uncertain, check again. Only flag with Confidence >= 3.
- **Specificity:** Say "[FILE-PATH] Line 42 violates standard X," not "There are some errors."
- **Severity:** If a file is useless, say it should be deleted.
- **Context:** Always remember this is a *project*, not just a list of files.
- **Detail:** Highly detailed audit.
- **Correctness:** Do not assume. Verify against actual code.
- **Focus:** Focus on **main logic** versus **cosmetics**. Skip minor style nits.
- **Avoid False Positives:** If code is correct and functional, acknowledge it briefly. Do not fabricate issues.
- **Length Constraint:** Keep the final review **UNDER 10000 TOKENS**. Be concise and high-impact. Do not ramble.

**Begin the audit now.**

