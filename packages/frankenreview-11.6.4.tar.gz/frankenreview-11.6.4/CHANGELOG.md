## [2026-02-22 16:00] - Frankenreview v11.6.4 "Dogfood & Launch Prep"

**Dogfed 2x self-reviews (audit + fullstack), fixed critical rate-limit loop bug, CI workflows, monotonic timing, packaging verified.**

### Fixed (P0 — From Dogfood Review)
- **Rate-limit failover loop**: `_switch_model()` now syncs `self.base_url` model param after switching. Previously, `_do_send_review` re-navigated to the rate-limited model because `base_url` was stale.
- **Silent file drops in repo_dumper**: `_enrich_metadata` now prints a warning when files are skipped due to read errors (was silently returning None).

### Fixed (From Industry Audit)
- **Monotonic timing**: Replaced all `time.time()` with `time.monotonic()` in `generation.py`, `interaction.py`, `upload.py` for hibernation-safe duration calculations.
- **Stray `.frankenreview/` in package**: Removed stray `.frankenreview/review.md` from `src/frankenreview/engine/browser/`.

### Added
- **CI workflow**: `.github/workflows/ci.yml` — runs unit tests on push/PR (ubuntu + macOS, Python 3.10 + 3.12).
- **Test gate in publish**: `.github/workflows/publish.yml` now runs unit tests before building wheel.

### Verified (Dogfood)
- **Review cycle 1** (audit prompt, Gemini 3 Pro): 75.7s, 323 lines, ACCEPT verdict.
- **Review cycle 2** (fullstack prompt, Gemini 3 Pro): 114s, 300 lines, ACCEPT WITH REVISIONS.
- **Package build**: sdist + wheel build successfully, all prompts/py.typed/config.yaml included.
- **Local install**: Updated from 11.3.1 to 11.6.4 via `pip install -e .`.
- **Git strategy**: Recommended regular push (no repo-reset needed — .git is 2.9MB, 30 commits).

### Files Modified
`src/frankenreview/engine/browser/mixins/session.py`, `src/frankenreview/engine/browser/mixins/generation.py`, `src/frankenreview/engine/browser/mixins/interaction.py`, `src/frankenreview/engine/browser/mixins/upload.py`, `src/frankenreview/engine/repo_dumper.py`, `.github/workflows/publish.yml`, `.github/workflows/ci.yml` (new), `CHANGELOG.md`

## [2026-02-22 15:30] - Frankenreview v11.6.4 "QA & Hygiene"

**Comprehensive repo audit: CHANGELOG versioning fix, path audit, industry standard compliance, bare except cleanup, version sync.**

### Fixed (CHANGELOG Versioning)
- **v11.6.3 timestamp**: Corrected from 15:50 to 15:20 (must precede v11.6.4).
- **Duplicate v11.5.0**: Merged "Agentic Ready" and "Session Continuity" into single entry.
- **Duplicate v11.1.0**: Merged "Interactive & Shorthand" and "Lean Docs+Tests" into single entry.
- **v11.0.0 missing header**: Added proper `##` heading for "The Great Purge" section.
- **v9.6/v9.7 order**: Fixed chronological ordering (v9.7 Jan 29 now correctly above v9.6 Jan 23).

### Fixed (Code Quality - P0)
- **19 bare `except:` clauses**: Replaced with `except Exception:` across 5 files (generation.py, interaction.py, selector_discovery.py, upload.py, navigation.py, repo_dumper.py).
- **Version sync**: Unified version to 11.6.4 across `pyproject.toml`, `__init__.py`, README badge.
- **Stale module docstrings**: Updated 8 files from v5.0/v6.0/v10.x to v11.
- **`py.typed` marker**: Created missing PEP 561 marker file (was declared in pyproject.toml but absent).
- **Makefile help text**: Updated from v5.0 to v11.

### Audited (Clean Results)
- **Absolute paths**: 0 leaked personal paths across 39 files.
- **Relative paths**: All scripts use dynamic resolution (`expanduser`, `Path.home()`, `Path(__file__)`).
- **Security**: No credentials, API keys, tokens, or personal data found.
- **Industry standard**: PASS on structure, packaging, docs, security. PARTIAL on code quality (print→logging migration deferred), testing (CI workflow deferred).

### Files Modified
`CHANGELOG.md`, `src/frankenreview/__init__.py`, `README.md`, `Makefile`, `src/frankenreview/py.typed` (new), `src/frankenreview/agents/research.py`, `src/frankenreview/utils/log_config.py`, `src/frankenreview/utils/prune_config.py`, `src/frankenreview/engine/chrome_stats.py`, `src/frankenreview/engine/browser/client.py`, `src/frankenreview/engine/token_governor.py`, `src/frankenreview/engine/repo_dumper.py`, `src/frankenreview/__main__.py`, `src/frankenreview/engine/browser/mixins/generation.py`, `src/frankenreview/engine/browser/mixins/interaction.py`, `src/frankenreview/engine/browser/mixins/upload.py`, `src/frankenreview/engine/browser/mixins/navigation.py`, `src/frankenreview/utils/selector_discovery.py`

## [2026-02-22 15:25] - Frankenreview v11.6.4 "Housekeeping"

**Major cleanup cycle: deleted vscode-extension, updated SKILL.md, fixed packaging, ms timing.**

### Removed
- **vscode-extension**: Moved entire directory to `deleted/`.
- **engine.browser**: Stray empty file moved to `deleted/`.

### Updated
- **SKILL.md**: Added interactive chat (--open-chat), model failover, XML auto-conversion, fixed broken error table.
- **workspace.py**: Updated auto-generated SKILL.md template with all v11.6.x features.
- **pyproject.toml**: Version synced from 11.5.7 to 11.6.4.
- **Timing display**: `--token-eaters` and `--dump` now show timing in ms (was seconds showing 0.00s).

### Files Modified
`src/frankenreview/engine/repo_dumper.py`, `src/frankenreview/utils/workspace.py`, `.frankenreview/SKILL.md`, `pyproject.toml`, `CHANGELOG.md`

## [2026-02-22 15:20] - Frankenreview v11.6.3 "Docs & Discovery"

**Documentation cleanup, selector discovery update, gitignore docs/archive/.**

### Updated
- **Selector discovery**: Added 3 new model selector fallback patterns, file input class-based selector, media container detection (Step 10), error state selectors, remove media button patterns.
- **Docs version refs**: Bumped CONTEXT.md and TESTING_PROCEDURES.md from v11.0.0 to v11.6.2.
- **.gitignore**: Changed docs archive rule from `guides/` to `docs/archive/`.

### Moved
- `docs/PLAN_V5.md` -> `docs/archive/PLAN_V5.md` (completed plan, consistent with v1-v4).

### Files Modified
`src/frankenreview/utils/selector_discovery.py`, `docs/CONTEXT.md`, `docs/TESTING_PROCEDURES.md`, `.gitignore`, `CHANGELOG.md`

## [2026-02-22 15:15] - Frankenreview v11.6.2 "Format Shield"

**Auto-converts unsupported file formats before upload. XML files now seamlessly converted to TXT.**

### Added
- **XML → TXT conversion layer**: `_convert_files_for_upload()` in UploadMixin.
- **Format constants**: `UNSUPPORTED_EXTENSIONS` and `CONVERSION_MAP` for extensibility.
- Auto-conversion happens transparently before `set_input_files()` call.
- Prevents both "unsupported file" errors and subsequent "internal error" from model.

### Fixed
- **Root cause elimination**: XML files no longer trigger has-error state since they're converted before upload.
- **Internal error prevention**: Model no longer receives unsupported file payloads.

### Files Modified
`src/frankenreview/engine/browser/mixins/upload.py`, `src/frankenreview/__init__.py`, `CHANGELOG.md`

## [2026-02-22 15:00] - Frankenreview v11.6.1 "Timing Fix"

**Fixed unsupported file detection timing. AI Studio requires 4s to mark files as errors.**

### Fixed
- **Detection timing**: Increased final verification delay from 2s to 4s (AI Studio processing time).
- **Filename extraction**: Robust 3-strategy approach for extracting filename from DOM.
- **hasError detection**: Now correctly detects `has-error` class after upload completes.

### Technical
- Strategy 1: `.name[title]` attribute
- Strategy 2: `[title*="."]` pattern match
- Strategy 3: Match against expected filenames in container text

### Files Modified
`src/frankenreview/engine/browser/mixins/upload.py`, `src/frankenreview/__init__.py`, `CHANGELOG.md`

## [2026-02-22 14:40] - Frankenreview v11.6.0 "Smart Upload"

**Detects and auto-removes unsupported file uploads. Improved model selector robustness.**

### Added
- **Unsupported file detection**: Detects `has-error` class on uploaded files.
- **Auto-removal**: Clicks "Remove media" button on unsupported files.
- **Clear error messaging**: Lists unsupported files explicitly.
- **`_remove_unsupported_files()`**: New helper method in UploadMixin.

### Fixed
- **Model selector fallback**: Added 6 fallback patterns for model button detection.
- **File upload wait**: Now waits up to 10s with proper loading state detection.
- **Internal error retry**: Handles "internal error has occurred" with up to 2 retries.

### Enhanced
- **Upload verification**: Tracks supported vs unsupported files separately.
- **Model switch**: More robust selector patterns for both navigation.py and session.py.

### Files Modified
`src/frankenreview/engine/browser/mixins/upload.py`, `src/frankenreview/engine/browser/mixins/navigation.py`, `src/frankenreview/engine/browser/mixins/session.py`, `src/frankenreview/__init__.py`, `CHANGELOG.md`

## [2026-02-22 14:35] - Frankenreview v11.5.9 "Robust Upload"

**Fixed file upload verification and internal error retry handling.**

### Fixed
- **File upload wait**: Now waits up to 10s for file processing (detects "generating..." state).
- **Internal error retry**: `send_prompt_in_chat()` now retries (up to 2x) on model internal errors.
- **Error response detection**: Handles "internal error has occurred" responses gracefully.
- **Rate limit signal**: Returns proper error when rate limit switches model.

### Enhanced
- **Upload verification**: Checks for actual filenames in UI (not just `.xml` patterns).
- **Extra wait after upload**: 2s delay for file processing before prompting.

### Known Limitation
- **XML upload**: AI Studio rejects `.xml` files in chat mode. Use `.txt` extension as workaround.

### Files Modified
`src/frankenreview/engine/browser/client.py`, `src/frankenreview/engine/browser/mixins/upload.py`, `CHANGELOG.md`

## [2026-02-22 14:30] - Frankenreview v11.5.8 "Chatbot Mode"

**--open-chat now supports full chatbot workflow: prompts, attachments, and session persistence.**

### Added
- **--open-chat --prompt**: Send prompts directly in chat sessions.
- **send_prompt_in_chat()**: New StudioClient method for chat interaction.
- Response display: Shows model response (truncated to 2000 chars).
- Output option: `--output file.md` saves response to file.

### Enhanced
- **--open-chat**: Now automatically resumes existing session if available.
- **--open-chat --attach**: Starts fresh session with uploaded files.
- **--open-chat --attach --prompt**: Upload files AND send prompt in one command.
- Full chatbot workflow: files → prompt → response → continue → delete.

### Files Modified
`src/frankenreview/cli.py`, `src/frankenreview/engine/browser/client.py`, `src/frankenreview/__init__.py`, `CHANGELOG.md`

## [2026-02-22 14:10] - Frankenreview v11.5.7 "Empty Chat Guard"

**Fixed timeout when deleting empty chats. Updated .gitignore, README, fixed --open-chat upload.**

### Fixed
- **delete_current_chat()**: Now checks if chat has content before deletion.
- **Disabled button check**: Checks `aria-disabled` attribute before clicking delete.
- Empty chats return success (nothing to delete).
- **--open-chat --attach**: Fixed missing method call (`_try_file_upload` instead of `_upload_file_to_chat`).

### Changed
- **README.md**: Complete overhaul. Concise format, all v11.5 features documented, updated badges.
- **.gitignore**: Reorganized with section headers. Removed AGENTS.md from ignore. Added security patterns.
- **Version sync**: Updated `__init__.py` and `pyproject.toml` to v11.5.7.

### Files Modified
`README.md`, `src/frankenreview/cli.py`, `src/frankenreview/engine/browser/mixins/actions.py`, `.gitignore`, `src/frankenreview/__init__.py`, `pyproject.toml`, `CHANGELOG.md`

## [2026-02-22 14:05] - Frankenreview v11.5.6 "Model Docs Update"

**Added generation date to MODEL_COMPATIBILITY_2026.md.**

### Changed
- **fetch_models.py**: Now includes generation timestamp in output file header.
- Regenerated model list with 44 current models.

### Files Modified
`scripts/fetch_models.py`, `docs/MODEL_COMPATIBILITY_2026.md`, `CHANGELOG.md`

## [2026-02-22 14:00] - Frankenreview v11.5.5 "UI Model Failover"

**Improved rate limit failover with UI-based model switching.**

### Changed
- **Model Switching**: Now uses UI-based selection instead of URL navigation
- **"All" Tab Click**: Clicks "All" tab before searching to access all models (not just Featured)
- **Failover List**: Updated default models: `gemini-3-flash-preview`, `gemini-2.5-pro`, `gemini-2.5-flash`, `gemini-2.0-flash`

### Files Modified
`src/frankenreview/engine/browser/mixins/session.py`, `src/frankenreview/engine/browser/mixins/navigation.py`, `scripts/explore_model_selection.py`, `CHANGELOG.md`

## [2026-02-22 13:45] - Frankenreview v11.5.4 "Graceful Interrupts"

**Added graceful ^C (KeyboardInterrupt) handling for all review modes.**

### Added
- **KeyboardInterrupt handlers**: All review/research/open-chat operations now catch ^C and exit gracefully with code 130.
- Prevents partial state or crashes when user interrupts mid-review.

### Files Modified
`src/frankenreview/cli.py`, `CHANGELOG.md`

## [2026-02-22 02:30] - Frankenreview v11.5.3 "Interactive Mode"

**Added --open-chat for manual chatbot interaction without auto-review.**

### Added
- **`--open-chat` flag**: Opens AI Studio chat session without running review. Uploads files via `--attach` for manual conversation. Session is saved for future `--continue` use.

### Updated
- **SKILL.md**: Added documentation for `--open-chat`, `--continue-new`, and session management workflow.

### Verified
- **Test suite**: All 53 unit/integration tests pass.

### Files Modified
`src/frankenreview/cli.py`, `~/.agents/skills/frankenreview/SKILL.md`, `CHANGELOG.md`

## [2026-02-22 02:15] - Frankenreview v11.5.2 "Session Control"

**Added --continue-new flag, exponential backoff, and fixed session navigation.**

### Added
- **`--continue-new` flag**: Starts fresh session but preserves for continuation. Clears any existing saved session first.

### Fixed
- **Session continuation navigation**: Fixed bug where `--continue` mode was navigating to fresh chat instead of reusing saved session. Added `is_continue_mode` check to skip fresh chat navigation.

### Modified
- **`run_one_shot_review()`**: Added `continue_new` parameter for fresh-but-persistent sessions.
- **`watch.sh`**: Implemented exponential backoff (1s → 30s max) after 60 seconds of no changes.

### Files Modified
`src/frankenreview/cli.py`, `src/frankenreview/engine/browser/client.py`, `watch.sh`, `CHANGELOG.md`

## [2026-02-22 02:00] - Frankenreview v11.5.1 "Documentation & QA"

**Enhanced docstrings, refined prompts, fixed bare except clauses.**

### Fixed
- **Bare except clauses**: Changed bare `except:` to `except Exception:` in debug.py, navigation.py.
- **Incomplete method**: `_capture_debug()` in debug.py now properly calls `_save_screenshot()`.

### Enhanced
- **Docstrings**: Added comprehensive Args/Returns documentation to 8 critical methods:
  - `debug.py`: `_capture_debug()`, `_rel_path()`
  - `navigation.py`: `_get_active_model_name()`
  - `upload.py`: `_truncate_for_paste()`, `_get_clipboard_content()`
  - `output.py`: `supports_unicode()`

### Refined
- **audit.md prompt**: Added anti-hallucination rules and precision-over-volume guidelines.
  - New "ANTI-HALLUCINATION RULES" section with explicit guidance against fabricating issues.
  - Updated "Tone Check" section emphasizing actionable findings and Confidence >= 3 requirement.

### Files Modified
`src/frankenreview/prompts/audit.md`, `src/frankenreview/engine/browser/mixins/debug.py`, `src/frankenreview/engine/browser/mixins/navigation.py`, `src/frankenreview/engine/browser/mixins/upload.py`, `src/frankenreview/utils/output.py`, `CHANGELOG.md`

## [2026-02-22 01:15] - Frankenreview v11.5.0 "Session Continuity"

**Added session persistence for multi-turn review workflows. Agent skill documentation.**

### Added
- **`--continue` flag**: Resume previous AI Studio chat session for the current project.
- **`--delete-chat` flag**: Delete saved chat session from AI Studio and clear local reference.
- **Session URL persistence**: Auto-saves chat URL to `.frankenreview/last_chat_url.txt`.
- **`utils/workspace.py`**: Added `save_session_url()`, `load_session_url()`, `delete_session_url()`.
- **`ActionMixin.delete_chat_from_url()`**: Navigate to session and delete chat.
- **`SKILL.md`**: Comprehensive agent skill documentation at `~/.agents/skills/frankenreview/SKILL.md`.
- **Agentic workflow patterns**: Documented multi-turn review, deep-scan, and research workflows.

### Modified
- **`StudioClient`**: Accepts `continue_url` parameter for session resumption.
- **`SessionMixin.connect_to_aistudio()`**: Navigates to saved URL when continuing.
- **`run_one_shot_review()`**: Added `continue_session` parameter.

### Verified
- **All non-review CLI flags**: `--self-check`, `--token-eaters`, `--dump`, `--chrome-stats`, `--prune-list`, `--version`.
- **JSON output support**: `--self-check --json` for machine-readable status.
- **Exit codes**: Consistent `0` (success), `1` (error) for all commands.

### Files Modified
`src/frankenreview/cli.py`, `src/frankenreview/__init__.py`, `src/frankenreview/utils/workspace.py`, `src/frankenreview/engine/browser/client.py`, `src/frankenreview/engine/browser/mixins/session.py`, `src/frankenreview/engine/browser/mixins/actions.py`, `~/.agents/skills/frankenreview/SKILL.md`, `CHANGELOG.md`

## [2026-02-22 00:45] - Frankenreview v11.4.1 "Hygiene Sweep"

**Addressed review findings: dependency sync, portable chrome control, unified requirements.**

### Fixed
- **Chrome Control Portability**: Replaced external script call with internal `utils/chrome_control.py` module.
- **Dependency Sync**: Removed obsolete `ollama` and `watchdog` from `requirements.txt`.
- **Missing Dependencies**: Added `tiktoken` and `psutil` to both `pyproject.toml` and `requirements.txt`.

### Added
- **`utils/chrome_control.py`**: Cross-platform Chrome process management module (stop_chrome).

### Files Modified
`src/frankenreview/cli.py`, `src/frankenreview/utils/chrome_control.py`, `pyproject.toml`, `requirements.txt`, `CHANGELOG.md`

## [2026-02-22 00:30] - Frankenreview v11.4.0 "Lean Pivot"

**Removed watch and chat modes as per v11 migration plan. Streamlined for stateless execution.**

### Removed
- **Watch Mode (`-w/--watch`)**: Removed daemon-based file watching; IDEs handle this better.
- **Chat Mode (`--chat`)**: Removed local cortex chat; agents have native chat capabilities.
- **`start_chat_session()` function**: Removed unused chat handler from CLI.

### Fixed
- **Self-Check Import**: Fixed broken import from non-existent `core.diagnostics` to `utils.self_check`.
- **`run_self_check()` function**: Added comprehensive implementation to `utils/self_check.py`.

### Updated
- CLI help text stripped of watch/chat references.
- Module docstrings updated for v11 lean pivot.
- Banner updated to remove Local Cortex reference.

### Files Modified
`src/frankenreview/cli.py`, `src/frankenreview/utils/self_check.py`, `CHANGELOG.md`

## [2026-02-21 01:10] - Frankenreview v11.3.1 "Purity & Parity"
- EXHAUSTIVE PURGE of absolute package imports in `cli.py` (switched to relative).
- Restored parity for all core flags: `--dump`, `--analyze`, `--discover-selectors`.
- Standardized filtering: `--prune-changelogs`, `--prune-dir`, etc., now available globally.
- Enhanced `--dump` output with token metrics and tree visualization.
- Modernized type hints to Python 3.12 (`list[str] | None`).

## [2026-02-21 00:50] - Frankenreview v11.3.0 "Functional Utility"

- Restored `--dump` and `--analyze` core modes.
- Added ad-hoc pruning flags: `--prune-dir`, `--prune-file`, `--prune-ext`.
- Integrated custom pruning lists into one-shot review pipeline.

## [2026-02-19 18:30] - Frankenreview v11.2.1 "Doctrine Correction"

- Refortified `deleted/` folder usage.
- Standardized verification pipeline for structural refactors.

## [2026-02-19 18:20] - Frankenreview v11.2.0 "Structural Purity"


**Purged "scar tissue" and standardized build system for v11 Lean doctrine.**

### Removed (Architectural Purity)
- **`src/frankenreview/core/`**: Purged empty vestigial module.
- **`setup.py`**: Retired in favor of `pyproject.toml` (Single Source of Truth).
- **`scripts/discover_selectors.py`**: Removed redundant logic; feature is integrated into CLI.

### Refactored (Encapsulation)
- **Browser Engine**: Moved `engine/browser_client.py` → `engine/browser/client.py`.
- **Package Hierarchy**: Standardized `engine.browser` package to expose `StudioClient` for cleaner internal imports.
- **Scripts Cleanup**: Renamed `install.py` → `dev_setup.py` to clarify its role as a developer utility.

### Updated (Build & Metadata)
- **`pyproject.toml`**: Corrected package-data inclusion for prompts and configs.
- **`MANIFEST.in`**: Robust inclusion rules for cross-platform distribution.

### Files Modified
`src/frankenreview/cli.py`, `src/frankenreview/agents/research.py`, `src/frankenreview/engine/browser/__init__.py`, `pyproject.toml`, `MANIFEST.in`, `CHANGELOG.md`

## [2026-02-19 17:34] - Frankenreview v11.1.0 "Lean" — Docs, Test Suite & Interactive Startup

**Documentation overhaul, v11 unit test suite, interactive Chrome startup, and shorthand flags.**

### Added (Features)
- **Interactive Chrome Startup**: CLI and Research modes now prompt `Start Chrome? (y/n) [default y in 5s]` if a connection failure is detected on the debugger port.
- **Auto-Start Integration**: Tool automatically starts Chrome and continues the initial task (review or research) seamlessly upon approval.
- **Centralized UI Helpers**: Created `src/frankenreview/utils/ui.py` for shared interactive components like `prompt_with_timeout`.
- **Shorthand Flags**: Added `--consolidation` flag as a shorthand for `--prompt consolidation`.

### Updated (Core)
- **`cli.py`**: Refactored `run_one_shot_review` to catch connection errors and trigger auto-start logic.
- **`research.py`**: Integrated the same auto-start logic for both standard and feature research modes.
- **`browser_client.py`**: Refactored `StudioClient` to raise exceptions on connection failure instead of calling `sys.exit(1)`, enabling CLI-level handling.

### Updated (Docs)
- **`README.md`**: Full rewrite — removes 6-layer arch, watcher/daemon/cortex references; documents 4-layer lean arch, accurate CLI reference table, correct project structure, troubleshooting table
- **`CONTRIBUTING.md`**: Rewritten with correct project structure, dependency hierarchy rules, code standards, and lean dev setup
- **`docs/CONTEXT.md`**: v11 lean 4-layer architecture description; removes daemon/governor/core/agents stale layer map
- **`docs/FR_FEATURE_CATALOG.md`**: Rewritten from v5.0 to v11; documents Dumper (RepoScanner, token_governor), Browser Ghost, CLI stateless modes, Research Agent, Workspace management
- **`docs/TESTING_PROCEDURES.md`**: Rewritten from v8.0.0 to v11; updated feature matrix, manual test procedures, automated test paths
- **`docs/PLAN_V5.md`**: Repurposed as v11 Lean Doctrine — explains the Pull model, dependency reduction rationale, and post-v11 roadmap

### Added (Tests)
- **`tests/conftest.py`**: Shared fixtures — `tmp_repo` (fake repo with src files + binary + node_modules), `tmp_fr_folder`
- **`tests/unit/test_repo_dumper.py`**: 22 unit tests for RepoScanner, dump_repo XML validation, prune rules, binary detection, token helpers, render_tree, cleanup_current_dump
- **`tests/unit/test_config_loader.py`**: 8 unit tests for all 4 config resolution levels, env var override, YAML type parsing
- **`tests/unit/test_workspace.py`**: 10 unit tests for folder creation, idempotency, gitignore append/deduplicate, SKILL.md generation and no-overwrite
- **`tests/unit/test_cli_helpers.py`**: 6 unit tests for version string (11.x.x SemVer), `is_port_in_use` (real socket binding), `get_chrome_path` (cross-platform safe)
- **`tests/integration/test_review_pipeline.py`**: E2E integration tests (marked `@pytest.mark.integration`) — review pipeline and research pipeline, excluded from default `pytest` run

### Updated (Config)
- **`pyproject.toml`**: Registered `integration` and `slow` pytest markers; default `addopts` excludes `tests/integration/`

### Files Modified
`README.md`, `CONTRIBUTING.md`, `docs/CONTEXT.md`, `docs/FR_FEATURE_CATALOG.md`, `docs/TESTING_PROCEDURES.md`, `docs/PLAN_V5.md`, `pyproject.toml`, `src/frankenreview/cli.py`, `src/frankenreview/agents/research.py`, `src/frankenreview/engine/browser_client.py`, `src/frankenreview/utils/ui.py`

### Files Added
`tests/conftest.py`, `tests/unit/__init__.py`, `tests/unit/test_repo_dumper.py`, `tests/unit/test_config_loader.py`, `tests/unit/test_workspace.py`, `tests/unit/test_cli_helpers.py`, `tests/integration/__init__.py`, `tests/integration/test_review_pipeline.py`

### Test Results
```
52 passed, 1 deselected (slow) in 0.51s
```

---

## [2026-02-19 17:00] - Frankenreview v11.0.0 "The Great Purge"

**Architectural pivot**: Removed all pre-agentic subsystems. Frankenreview is now a stateless Unix utility: `Input -> Dump -> Browser -> Output`.

### Removed (Pre-Agentic Relics)
- **`config.yaml`**: Purged 8 dead keys: `pid_file`, `silence_window`, `governor_model`, `cleanup_model`, `use_local_llm`, `include_history`, `max_history_entries`, `require_approval`
- **`setup.py`**: Removed `watchdog`, `psutil` (daemon/process-monitoring deps) and the entire `local` extras group (`llama-cpp-python`, `huggingface-hub`) — governor dependencies with no consumers
- **`workspace.py`**: Removed `get_state_path`, `get_prompt_path`, `get_context_path` — dead helpers that served the v10 history/memory system

### Retired to `deleted/`
- `tests/cortex_playground.py` — referenced deleted `LocalCortex`
- `tests/test_features.py` — referenced deleted `LocalCortex` / `CodeGym`
- `tests/verify_cortex.py` — referenced deleted `LocalCortex`

### Updated
- **`__init__.py`**: Version bumped `10.7.6 → 11.0.0`; module docstring rewritten to reflect 4-layer Lean architecture (Dumper, Browser, CLI, Research)
- **`setup.py`**: Version bumped to `11.0.0`; description updated
- **`workspace.py`**: Module docstring updated to remove `state.json` / `context.json` / `latest_prompt.txt` references
- **`utils/config_loader.py`**: Docstring updated to remove stale `daemon.py` reference

### Files Modified
`config.yaml`, `src/frankenreview/__init__.py`, `setup.py`, `src/frankenreview/utils/workspace.py`, `src/frankenreview/utils/config_loader.py`

### Files Retired
`tests/cortex_playground.py`, `tests/test_features.py`, `tests/verify_cortex.py`

---

## [2026-02-16 10:45] - Frankenreview v10.7.4 "Robust Click Detection"

### 🔧 Review Automation
- **Robust Click Detection**: Increased detection timeout from 3s to 5s. Added support for multi-selectors and turn count increase as a fallback signal.
- **Unified Generation Logic**: Synchronized generation startup verification between `InteractMixin` and `GenMixin` for consistent behavior.

## [2026-02-16 10:15] - Frankenreview v10.7.3 "The Backup Logic Fix"

### 🔧 Configuration Management
- **Centralized Workspaces**: Refactored `config_loader.py` and `workspace.py` to prioritize `.frankenreview/config.yaml` as the canonical repository configuration.
- **Selector Discovery Fix**: Resolved crash in `frankenreview --discover-selectors` when `config.yaml` was missing. Fixed backup and save operations to correctly use the dynamically determined configuration path in all workspaces.

### 🧪 Improvements
- **Robust Internet Check**: (v10.7.1) Fixed false positive internet connection errors by switching to HTTPS-based connectivity tests.

## [2026-02-16 09:30] - Frankenreview v10.7 "Turbo Dumper"

### 🚀 Performance & Core Engine (Major)
- **Turbo RepoScanner**: Implemented a new high-performance repository scanner using `os.scandir` for 2x-20x faster directory traversal.
- **Parallel Metadata Collection**: Leveraged `ThreadPoolExecutor` to parallelize binary checks, line counting, and token estimation.
- **Single-Pass Efficiency**: Refactored `repo_dumper.py` to eliminate redundant disk scans and file reads. All metadata is now collected in a unified pass.
- **Optimized Streaming**: `dump_repo` now uses buffered chunk-based streaming for XML generation, significantly reducing I/O overhead.
- **Calibrated Token Estimation**: Simplified token heuristic to `char_count / 3.7` for Gemini, avoiding `tiktoken` overhead in parallel contexts.

### 📊 Token Analysis
- **Turbo --token-eaters**: Refactored token eaters analysis to use the `RepoScanner`. Results are now generated in sub-50ms for typical repositories.
- **Enhanced Folder Aggregates**: Improved folder-level token reporting with better aggregation logic.
- **Robust Internet Check**: Replaced brittle DNS-based (port 53) internet connectivity check with a multi-endpoint HTTPS (port 443) check to eliminate false positives in restricted environments.

### 🧹 Maintenance
- **Refactoring**: Removed obsolete helper functions (`should_skip_dir`, `should_skip_file`, `collect_files`) in favor of the unified `RepoScanner` class.
- **Security**: Preserved spoof-proof Base64 delimiters for file contents in XML dumps.
- **Files Modified**: `src/frankenreview/engine/repo_dumper.py`


## [2026-02-15 13:30] - Frankenreview v10.6 "The Token & Selector Fix"

### 🔧 Core Engine
- **Token Accuracy**: Implemented `tiktoken`-based counting with 1.25x scaling for precise Gemini token estimation (updates `repo_dumper.py`).
- **Git Safety**: Suppressed `stderr` in `repo_dumper` to prevent "fatal: not a git repository" leakage in non-git environments.
- **Selector Hardening**: Updated `browser_client.py` with robust, multi-strategy selectors for Run/Stop buttons (verified against live AI Studio UI).
- **CLI**: Added `--discover-selectors` to run interactive selector verification/update tool.

### 🧹 Maintenance
- **Script Hygiene**: Retained `discover_selectors.py` in `scripts/` but also integrated logic into core package.
- **Files Modified**: `src/frankenreview/cli.py`, `src/frankenreview/utils/selector_discovery.py`

## [2026-02-02 00:30] - Frankenreview v10.5 "Mixin-Based Browser Engine"

### 🏗 Architecture & Refactoring (Major)
- **Mixin-Based Modularization**: Successfully refactored the 2051-line `browser_client.py` into a modular architecture using composition.
- **7 Focused Mixins**: Created specialized mixins for debug, session, navigation, interaction, generation, upload, and actions.
- **Prompt Refinement (High-Precision)**: Improved system prompts with Confidence Labeling (1-5), Precise Line Attribution (L-ranges), Test & Mock Awareness, and Mandatory Env Var Discovery.
- **100% Logic Preservation**: All 30 methods extracted with **verbatim** preservation of critical scraping logic (`_fallback_scrape`).
- **Improved Maintainability**: Each mixin is independently testable and focused on a single responsibility.

### 🐛 Bug Fixes
- **Fixed `cli.py` AttributeError**: Wrapped `project_path` in `Path()` before calling `.resolve()` to handle string inputs correctly.
- **Fixed Versioning**: Unified version to 10.5.0 across `pyproject.toml`, `setup.py`, and `src/frankenreview/__init__.py`.

**Files Modified**: `src/frankenreview/engine/browser_client.py`, `src/frankenreview/cli.py`  
**Files Created**: 7 mixin modules in `src/frankenreview/engine/browser/mixins/`  
**Files Archived**: `browser_client_legacy.py` → `deleted/`

## [2026-02-01 20:41] - Frankenreview v10.0.4 "Automation Hardening"

### 🐛 Robustness & Reliability
- **DOM Injection Verification**: `_do_send_review` now verifies that the prompt was actually injected into the textarea's `.value` property. If verification fails, it falls back to Playwright's native `fill()` method (Eliminates false positive "Injected" logs).
- **Generation Start Detection**: `_verify_generation_triggered` now avoids false positives from pre-disabled Run buttons by prioritizing the Stop button and Thinking indicator, and requiring a 1s wait before trusting a disabled button state.
- **Improved Failover**: Added additional safety checks to `page.evaluate` scripts to handle null elements gracefully.

## [2026-02-01 14:25] - Frankenreview v10.0.3 "UI Model Selector & Stability Patch"

### 🚀 New Feature
- **Programmatic Model Selection**: Implemented `_select_model_via_ui` in `browser_client.py` to handle model switching via the dropdown menu. This bypasses issues where AI Studio ignores the `?model=` URL parameter.
- **Scripts**: Restored `discover_selectors.py` and `explore_model_selection.py` to `scripts/` (crucial for maintenance).
- **Model Display**: Terminal now displays `Active Model (UI): [Name]` during generation, providing real-time verification of the selected model.

### 🐛 Stability & Accuracy Fixes
- **CLI Propagation**: Fixed `cli.py` and `research.py` to correctly propagate the `--model` override to the `StudioClient`, ensuring research tasks use the requested model (P1 Fix).
- **Short Response Completion**: Reduced stability check thresholds from 100 to 5 characters in `_wait_generation_done` and `_wait_response_stable`. This prevents timeouts on extremely brief responses (e.g., "HI", "Completed") (P1 Fix).

### 🔧 Component Updates
- **`browser_client.py`**: Added `_select_model_via_ui`, updated `_wait_generation_done`, integrated selection into `connect_to_aistudio` and `_switch_model`.
- **`cli.py`**: Updated research mode to respect `--model` flag.
- **`research.py`**: Ensured model ID is passed directly to `StudioClient`.

## [2026-02-01 13:40] - Frankenreview v10.0.2 "Selector Config Fix"

### 🐛 Critical Bug Fix
- **Completion Detection**: Fixed `_wait_generation_done` to use config-based selectors instead of hardcoded `button[aria-label*='Run']` that no longer matches AI Studio UI.
- **Root Cause**: Hardcoded selectors at lines 259-260 ignored `config.yaml` updates from selector discovery, causing Run button detection to fail (count=0) and completion checks to never execute.
- **Result**: Generation completes in ~28s vs previous 90s+ timeout. Stop button vanish and Run button re-enable now correctly detected.

### 🔧 Selector Updates
- **Config Updated**: Ran `discover_selectors.py`, applied new selectors to `config.yaml`
- **Backup Created**: `deleted/configs/config_backup_20260201_132213.yaml`

## [2026-02-01 13:14] - Frankenreview v10.0.1 "File Upload Fallback Fix"

### 🐛 Critical Bug Fix
- **File Upload Verification**: Fixed `_try_file_upload` to return `False` when UI verification fails (line 1791), properly triggering the paste fallback.
- **Root Cause**: File upload returned `True` even when the attachment wasn't visible in AI Studio UI, causing LLM to receive no code context.
- **Result**: Reviews now correctly fallback to pasting truncated XML content (100K chars) when file attachment fails.

### 🔄 Reverted
- **v10.0 Modularization Attempt**: Reverted failed modularization to 5 modules (`session_manager.py`, `ui_actions.py`, etc.). Failed modules moved to `deleted/engine/v10_failed_modules/`.
- **Restored**: Original 1,939-line `browser_client.py` restored from `deleted/engine/browser_client_v9.py`.

## [2026-01-30 02:00] - Frankenreview v9.9 "Iterative Convergence"

### 🔧 Architectural Fixes
- **Config Centralization**: Created `utils/config_loader.py` with canonical `load_config` function. Removed duplicate implementations from `daemon.py` and `browser_client.py` (fixed circular import).
- **Chrome PID Tracking**: `start_chrome.py` now writes Chrome PID to `~/.frankenreview/chrome_{port}.pid`. `stop_chrome.py` uses PID file for reliable process targeting (fallback to pgrep).
- **Model Selection Fix**: Fixed `browser_client.py` URL construction to properly inject `--model` arg into chat URL, preventing selector fallback confusion.

### ⚡ Performance Improvements
- **Exponential Backoff**: `_wait_generation_done` now uses 2.0s polling interval after 60s elapsed (was 0.5s) to reduce CPU pressure during long generations.
- **Functional Debounce**: Replaced arbitrary `sleep(5)` after DOM injection with functional wait for Run button readiness (polls every 0.3s, max 5s).
- **Token Heuristic Consistency**: Fixed `token_governor.py` fallback heuristic from 4.0 to 3.7 chars/token to match CLI's calibrated value.

### 🔒 Security Hardening
- **Cortex Path Validation**: `cortex.py` now uses `os.path.commonpath` for robust containment check instead of brittle `startswith` comparison (prevents symlink bypass).
- **Removed pyperclip**: Removed unused `pyperclip` import and dependency from `browser_client.py` and `requirements.txt`.

### 🧹 Code Hygiene
- **Cleanup Formatters**: `cleanup.py` now uses `python -m` for Python formatters (black, isort, ruff) for reliability in containerized environments.
- **Moved Duplicates**: Moved `src/frankenreview/config.yaml` (duplicate) and obsolete emoji scripts to `deleted/`.

### Files Modified
- `src/frankenreview/utils/config_loader.py` - NEW: canonical config loading
- `src/frankenreview/core/daemon.py` - uses config_loader
- `src/frankenreview/engine/browser_client.py` - URL fix, functional debounce, exponential backoff
- `src/frankenreview/engine/token_governor.py` - 3.7 heuristic
- `src/frankenreview/engine/cortex.py` - path validation
- `src/frankenreview/utils/cleanup.py` - python -m formatters
- `scripts/start_chrome.py` - PID file writing
- `scripts/stop_chrome.py` - PID file-based targeting
- `requirements.txt` - removed pyperclip

### 📚 Documentation
- **BROWSER_AUTOMATION_WAR_MANUAL.md**: Added "Constraint D: The Timeout Illusion" case study documenting exponential backoff, functional debounce, and heuristic consistency fixes.

## [2026-01-30 00:30] - Frankenreview v9.8 "Research Agent Reliability"

### 🔧 Core Fixes
- **Selector Shadowing Fix**: `_click_run_button` now verifies clicks actually trigger generation using viewport intersection checks and post-click confirmation (Stop button/Run disabled).
- **Virtualization Handling**: `_wait_generation_done` forces scroll-into-view before character counting, preventing 0-char false positives during long generations.
- **Thinking Mode Detection**: Fixed `research.py` to only enable 300s timeout for models with 'thinking' in name (prevents Flash model false positives).
- **Incremental Saves**: Partial responses now saved to `~/.frankenreview/partial_response.md` every 5s during generation for crash recovery.
- **Selector Robustness**: Updated `config.yaml` selectors with `:not([disabled])` filters and fallback patterns for Run/Send button variants.

### Files Modified
- `src/frankenreview/engine/browser_client.py` - `_click_run_button`, `_wait_generation_done`, added `_verify_generation_triggered`
- `src/frankenreview/agents/research.py` - thinking mode logic (lines 165, 335)
- `config.yaml` - selectors for run_button, stop_button, textarea

## [2026-01-29 20:15] - Frankenreview v9.7 "The Selector Automation Update"

### Added
- **Selector Discovery Agent (`scripts/discover_selectors.py`)**: 
  - **Active Testing & Validation**: Performs live injection (P=NP) and rates selector quality (Anti-Hallucination Risk Scores).
  - **Comprehensive Scope**: Detects Input, Run, Stop, Thinking, Response, **Model Name**, and Delete flow selectors.
  - **Safe Migration**: Interactive `[y/N]` update with **relative path** backup (`deleted/configs/`) and diff reporting.
- **Engine Core (`browser_client.py`)**:
  - **Stability Override**: Implemented 15s textual stability check to resolve infinite hangs.
  - **Robust State Detection**: Added `aria-disabled` support and granular debug telemetry to fix phantom "stuck" states.

### Documentation
- **Walkthrough**: Added `walkthrough.md` detailing how to use the new discovery script.

## [2026-01-23 03:00] - Frankenreview v9.6 "The Security & Stability Update"

### Security & Integrity (P0/P1)
- **Atomic State Protocol**: Implemented `safe_write()` for `state.json` and `review.md` to eliminate VS Code extension race conditions (P0).
- **XML Injection Patch**: Base64-encoded file paths in XML dump delimiters to prevent comment injection attacks (P1).
- **Session Isolation**: Implemented port-based session IDs (`~/.frankenreview/session_{port}.id`) to prevent cross-project collisions (P2).

### Performance & Stability
- **Memory-Aware Cortex**: Added `psutil` integration to dynamically size KV cache (4k/16k/32k) based on available system RAM (P2).
- **Zombie Process Killer**: Improved `browser_client.py` exception handling to ensure Playwright shutdown on launch failure.
- **Robust Process Management**: Updated `stop_chrome.py` to target specific profiles, preventing accidental kills of user browsers.

### New Features
- **Deep Scan Resume**: Added `--resume` flag to `deep-scan` CLI. Automatically detects last completed cycle and resumes execution.

### Fixes
- **Repo Mapper**: Fixed duplicate symbol listing in `map_repo.py`.
- **Model Fetcher**: Tightened regex in `fetch_models.py` to prevent hallucinating API keys as model IDs.
- **Config Loading**: Fixed brittle path resolution in `daemon.py` and `research.py` (Fixed "selectors not found" bug).
- **Run Button**: Implemented 30s retry loop, multi-candidate iteration, and **Cmd+Enter Keyboard Fallback** to guarantee execution.
- **Performance**: Reduced stability timeout to 5s for non-thinking models (Fixed "wasting time" with Flash).
- **Core**: Fixed `--model` argument being ignored in Research mode.
- **Config**: Disabled global `thinking_mode` by default to avoid accidental 300s timeouts.
- **Safety**: Implemented emergency scrape on process interrupt (SIGINT) to preserve partial data.
- **Logging**: Silenced selector debug spam for cleaner output.

---

## [2026-01-23 01:00] - Frankenreview v9.5.6 (Stabilization)
### 🛡️ Architecture Resilience
- **Strict Modular Decoupling**: Neutered `frankenreview/__init__.py` to achieve "Zero-Eager-Import" status.
- **Lazy Entry Points**: Modified `cli.py` and `daemon.py` to use local scopes for Local Cortex imports, preventing `OSError` crashes on misconfigured architectures.
- **Safe Backend Probing**: Used `importlib.util.find_spec` in `cortex.py` to detect LLM backends without triggering their load sequence.
- **Metadata Sync**: Synchronized `setup.py` version to `9.5.0` to resolve environment desync.
- **Token Calibration**: Adjusted dump estimation to `Chars / 3.7` (96% precision vs AI Studio).

## [2026-01-22 22:00] - Frankenreview v9.5 "The Agentic Agility Update"

### Added (Agentic Agility)
- **Interactive Chat REPL (`--chat`)**: 
  - Real-time conversation with the Local Cortex (Qwen 1.5B).
  - **Agentic File Browsing**: The model can autonomously read repository files using `ACTION: READ(path)` to answer context-aware questions.
  - State-aware conversation history with automatic loop prevention.
- **Local Cortex Enhancements**:
  - Context window increased to **32,768 tokens** for `llama-cpp` backend.
  - Native `mlx-lm` support for optimized Metal performance on Apple Silicon.
  - Automatic output sanitization (stripping ChatML tokens and markdown artifacts).
- **Manageability Compliance (Score 90+)**:
  - **JSON Output**: `frankenreview --self-check --json` for machine-readable status.
  - **Centralized Diagnostics**: `self_check.py` monitors Chrome Port, Config, and Import Health.
  - **Priority-Aware Pruning**: Token governor now respects `priority_patterns` from `config.yaml`.

### Added (Strategy)
- **Plan V5 (`docs/PLAN_V5.md`)**: Formalized the "Pip-Install Doctrine".
  - Separates User Experience (Binary) from Maintainer Experience (The Gym).

### Fixed
- **Architecture Violation**: Resolves illegal import in `self_check.py` via dynamic importing.
- **CLI Robustness**: Fixed `self-check` crash by adding proper status fields to environment checks.

---

## [2026-01-19 01:00] - Frankenreview v9.0 "The Deep Scan Update"

### Added
- **Deep Scan Mode**: `--deep-scan` runs recursive, multi-cycle reviews where the AI critiques its own previous findings.
- **Planner Mode**: `--planner` verifies implementation plans (`plan.md`) against the codebase before code is written.
- **Multi-Head Architecture**: Full support for parallel execution via `--port` and `--profile` flags.
- **Robustness**: 
  - XML dumps are now uploaded as `.txt` to bypass AI Studio file type restrictions.
  - Automatic timestamping for all research outputs.

### Fixed
- **CLI Logging**: Model name is now correctly retrieved from config URL if not explicitly provided.
- **Output Hygiene**: All default outputs now target `.frankenreview/` directory.

---

## [2026-01-18 14:05] - Frankenreview v7.1 "The Autonomy Update"

### Added
- **Project-Specific Prompts**: 
  - `frankenreview --create-prompt <name>`: Instantly create and edit custom prompts in `.frankenreview/prompts/`.
  - Priority Resolution: Local project prompts (`.frankenreview/prompts/`) now override built-in prompts.
- **Agent Autonomy**:
  - Full CLI Help Coverage: `--help` now verified to be machine-readable and complete.
  - **Agent Guidance**: Added "RECOMMENDED WORKFLOW" section to help text, guiding agents to use Rigour -> Workflow -> Token Eaters -> Review sequence.
  - Brute Force Verification: Automated test harness (`tests/brute_force_cli.py`) verifies every CLI combination to ensure no crashes.

### Fixed
- **CLI Robustness**: 
  - Fixed `EDITOR` environment variable handling (supports complex strings like `code -w`).
  - Fixed `prompt_arg` default logic: CLI args now correctly override config, and config correctly overrides defaults.
- **Research Hygiene**:
  - `feature-research` inputs are now logged to `.frankenreview/research_input.md` consistently.
- **Setup Compliance**:
  - Fixed `setup.py` license warnings for clean global installation.

---

## [2026-01-18 13:30] - Frankenreview v7.0 "The Doctrine Update"

### Added (Major Features)
- **Global Doctrine & Process**:
  - `frankenreview --rigour`: Displays the PhD-level Rigour Doctrine.
  - `frankenreview --workflow`: Displays the Iterative Hardening Workflow.
  - New prompts: `rigour.md` (Doctrine), `workflow.md` (Process), `standard.md` (Constructive Review).

- **Enhanced CLI Controls**:
  - `--feature-research <QUERY>`: Run research focused on specific features using repository context.
  - `--dump`: Generate XML repo dump instantly without running review (useful for debugging).
  - `--*-edit` flags: Quick access to edit rigour, workflow, or prompts (`--rigour-edit`, etc.).
  - "Best Tips" section in help text.

- **Daemon V2**:
  - `trigger_files`: Configure daemon to only watch specific files (e.g. `['CHANGELOG.md']`) via `config.yaml`.
  - Optimized file watching with ignored file analysis.

- **Core Improvements**:
  - **Timestamped Dumps**: XML dumps now include generation time to prevent staleness.
  - **Token Eaters V2**: Now analyzes ignored/skipped files to warn about potential context loss.
  - **Research V2**: Supports raw string prompts (no need for a file) and saves history.

### Changed
- Default prompt is now `standard.md` (Configurable via `prompt_arg`).
- `repo_dumper` now prunes more aggressively by default based on config.
- CLI default trigger logic updated to separate review/research/dump modes.

---

## [2026-01-18 00:30] - Frankenreview v6.0 "The Research Build"

### Added (Major Features)
- **Research Mode (`--research`)**: Agentic deep research via browser automation
  - New CLI flag: `frankenreview --research --prompt topic.md`
  - Supports Gemini 3 Pro Preview and Gemini 2.5 Pro
  - Structured output with Executive Summary, Key Findings, Technical Analysis
  - New module: `src/frankenreview/research.py`
  
- **VS Code Extension v2.0**: Enhanced integration with GitHub Copilot Chat
  - Status bar item showing real-time Frankenreview status
  - File watcher for `.frankenreview/state.json`
  - New commands: View Review, Copy Prompt, Show Status
  - Automatic notifications when review is ready
  - Keybindings: Cmd+Shift+F (post), Cmd+Shift+R (view)
  
- **Daemon State Protocol**: VS Code extension integration
  - Writes `.frankenreview/state.json` for extension consumption
  - Status values: idle, generating, ready, error
  - Includes model info and timestamps

- **CLI Chrome Management**: Global commands for browser control
  - `frankenreview --start-chrome`: Launch Chrome with remote debugging
  - `frankenreview --stop-chrome`: Stop the debug Chrome instance
  - Cross-platform support (macOS, Linux, Windows)
  - Auto-detects Chrome/Chromium installation

- **Automatic Dump Cleanup**: Prevents stale cache issues
  - Cleans dump files older than 1 hour before each review
  - Deletes current dump file after successful review
  - Removes old debug screenshots automatically
  - Keeps only latest XML per repo

- **Centralized `.frankenreview/` Folder**: All outputs in one place
  - Dumps, review.md, state.json, context all in `.frankenreview/`
  - Auto-added to `.gitignore` if gitignore exists
  - Cleaner project repos with no FR artifacts in root
  - Uses relative paths from `project_root`

- **CLI Prune Configuration Management**: AI agent-friendly exclusion control
  - `--prune-list`: Display current dirs, files, extensions to skip
  - `--prune-add-dir/file/ext`: Add items to prune lists
  - `--prune-remove-dir/file/ext`: Remove items from prune lists
  - Persistent: All changes saved to `config.yaml`
  - New `prune_exts` config option for extension-based filtering
  - New module: `src/frankenreview/prune_config.py`

- **Token Eaters Analysis (`--token-eaters`)**: Identify heavy content
  - `--token-eaters`: Show top 10 files and folders by token count
  - Helps AI agents detect garbage before running review
  - Token estimates based on ~2 chars per token
  - Shows percentage of total and file counts per folder
  - Tip suggests using `--prune-add-*` to exclude heavy items

- **Chrome Performance Stats (`--chrome-stats`)**: Resource monitoring
  - `--chrome-stats`: Monitor debug Chrome CPU, memory, GPU usage
  - Process-level metrics via psutil (CPU%, RSS, threads)
  - Page-level metrics via CDP (JS heap, DOM nodes, event listeners)
  - GPU status with WebGL and renderer info
  - New module: `src/frankenreview/chrome_stats.py`

### Changed
- **cli.py**: Updated to v6.0 with `--research` and `--research-model` flags
- **cli.py**: Comprehensive agent-friendly help with examples, built-in prompts, and integration tips
- **__init__.py**: Updated to v6.0 with research module export
- **daemon.py**: Updated banner to v6.0, added `write_state()` method
- **README.md**: Updated with v6.0 features and Research Mode documentation
- **plan2.md**: Updated with user decisions and approved scope
- **prompts/fullstack.md**: Complete rewrite with proper structure and production audit focus
- **prompts/*.md**: Added ZERO-TRUST DOCUMENTATION POLICY to all prompts
  - States CODE IS THE ONLY SOURCE OF TRUTH
  - Warns that CHANGELOG/README/docs may be stale
  - Instructs AI to VERIFY claims against actual implementation
  - Prevents "already fixed" false positives from outdated docs

### Files Added
- `src/frankenreview/research.py` - Research mode module

### Files Modified
- `src/frankenreview/cli.py` - Added research mode
- `src/frankenreview/__init__.py` - v6.0 exports
- `src/frankenreview/daemon.py` - State protocol
- `src/frankenreview/prompts/fullstack.md` - Complete rewrite with proper structure
- `vscode-extension/src/extension.ts` - v2.0 rewrite
- `vscode-extension/package.json` - New commands
- `vscode-extension/README.md` - v2.0 docs
- `README.md` - v6.0 features
- `CHANGELOG.md` - This entry
- `plan2.md` - Approved scope

---


## [2026-01-17 18:35] - System Recovery & Extraction Optimization

### Fixed (Critical - System Recovery)
- **browser_client.py**: Restored robust response extraction for both thinking and non-thinking models.
  - Removed overly restrictive turn filtering that was excluding thinking model responses.
  - Standardized clean text extraction logic (removing reasoning blocks) across all state-checking functions.
  - Improved `_wait_generation_done` to use the Run button's enabled state as the definitive completion signal.
- **browser_client.py**: Restored automated "Delete Chat" feature (`delete_current_chat`).
  - Corrected logic to ensure deletion triggers immediately after successful extraction.
  - Added safety checks to prevent deletion on error states.

### Improved (UI/Performance)
- **Progress Meter**: Unified meter logic to accurately display `[*] Thinking` vs `[>] Generating` states based on live DOM inspection.
- **Stability Check**: Refined `_wait_response_stable` to focus only on model output, ignoring volatile reasoning streaming.

---

## [2026-01-17 18:10] - FILE UPLOAD NOW WORKS

### Fixed (Critical - File Upload)
- **browser_client.py**: Complete rewrite of file upload using Playwright's `set_input_files()`
  - Clicking Insert button creates hidden `input.file-input` element
  - Use `page.wait_for_selector()` to wait for dynamic injection
  - Use `page.set_input_files()` to directly upload (no dialog)
- **File extension**: Changed from `.xml` to `.txt` (AI Studio rejects XML)
- **Always fresh page**: Navigate to `new_chat` every time to clear cached attachments
- **Wait for loading**: Added `wait_for_function` to wait for file loading to complete
- **cli.py**: Fixed to pass XML separately via `xml_content` parameter instead of embedding in prompt

### Verified Working
- File shows as `code_snapshot.txt` with token count (e.g., "106,920 tokens")
- No "Unsupported file" error
- Run button becomes enabled after upload
- Screenshot proof: `debug-after-xml-upload-*.png`

---

## [2026-01-17 17:45] - Comprehensive System Polish

### Added (Scripts)
- **scripts/start_chrome.py**: Cross-platform Python Chrome launcher
- **scripts/stop_chrome.py**: Cross-platform Python Chrome stopper
- **scripts/install.py**: Cross-platform Python installer
- **scripts/stop_frankenreview.py**: Cross-platform daemon stopper
- **output.py**: Production-grade output module with Unicode/ASCII fallbacks

### Added (Documentation)
- **README.md**: AI Studio data usage disclaimer (CAUTION block)
- All scripts and docs now reference Python scripts instead of shell

### Changed (Terminal Output)
- Implemented proper Unicode symbols with ASCII fallbacks based on terminal capability
- Symbols: `[✔]` ok, `[✖]` error, `[⚠]` warn, `[ℹ]` info (falls back to `[+]`, `[x]`, `[!]`, `[i]`)

### Fixed (File Upload)
- **browser_client.py**: Updated selectors based on browser agent discovery
  - Insert button: `button[aria-label='Insert images, videos, audio, or files']`
  - Upload menu: `.upload-file-menu-item` (text: "Upload files")
- Added actual verification that file attachment appeared in DOM

### Removed
- Moved old `.sh` scripts to `deleted/` folder
- Removed all emojis from README.md and documentation

---

## [2026-01-17 17:40] - Production-Grade Terminal Output & Security Hardening

### Changed (Terminal Output)
- **ALL FILES**: Replaced all emojis with clean text-based icons:
  - `[i]` info, `[+]` success, `[!]` warning, `[x]` error, `[f]` file, `[.]` wait, `[*]` thinking, `[>]` generate
- **browser_client.py**: Fixed progress meter spam issue
  - Now uses proper ANSI escape code `\033[2K\r` to clear line before printing
  - Meter updates cleanly in-place without duplicating lines
- **log_config.py**: Replaced emoji log prefixes with text-based `[i]`, `[!]`, `[x]`, `[X]`, `[d]`
- **Created**: `output.py` - Production-grade terminal output utility module

### Fixed (File Upload)
- **browser_client.py**: Fixed `_simulate_file_paste()` to actually verify attachment
  - Now checks for attachment chip in DOM before returning True
  - Prints clear status: `[+] File attached (verified)` or `[!] File not attached`

### Added (New CLI Args)
- `--model [ID]`: Select AI model (e.g. `--model thinking` or `--model gemini-2.0-pro`)
- `--visible`: Force browser window visibility for login

### Added (Linter)
- **linter.py**: Built-in syntax checker for Python, JSON, YAML, XML, Shell

### Security
- Removed all `pyperclip` clipboard usage (browser API only now)
- Fixed RCE: JS injection via f-string in `page.evaluate`
- Fixed XML injection via `quoteattr` for file paths

### Files Modified
`browser_client.py`, `cli.py`, `daemon.py`, `repo_dumper.py`, `log_config.py`, `linter.py`

---

## [2026-01-17] - Browser Automation Fixes

### Changed
- **config.yaml**: Updated all CSS selectors for 2026-01 AI Studio UI
  - `textarea`: Changed to `textarea[aria-label='Enter a prompt']`
  - `run_button`: Changed to `button[aria-label='Run']`
  - `response`: Changed to `ms-chat-turn, ms-markdown-block`
  - `attach_button`: Changed to `button[aria-label='Insert images, videos, audio, or files']`
  - `more_options_button`: Changed to `button[aria-label='Open options']`

- **browser_client.py**: Updated default selectors and JavaScript extraction logic
  - Updated default selectors to match 2026-01 AI Studio UI
  - Fixed `_wait_response_stable()` to use `[data-turn-role="Model"]` selector
  - Fixed response extraction to use `ms-chat-turn` with `.turn-content`
  - Removed duplicate `_wait_for_response()` and `_wait_response_stable()` method definitions

- **tests/test_real_site.py**: Increased test timeout from 30s to 90s

### Fixed
- "Could not find Run button" error resolved
- Response text extraction now working with updated AI Studio UI
- Text stability detection using correct model response selectors

### Tested
- 3/3 stress tests passed with response extraction verified
- Chat cleanup feature tested and working

---

## [2026-01-17 12:47] - Chat Cleanup Feature

### Added
- **config.yaml**: New delete chat selectors
  - `chat_menu_button`: `button[aria-label='View more actions']`
  - `delete_prompt_button`: `button[aria-label='Delete prompt']`
  - `dialog_container`: `mat-dialog-container`
  - `dialog_confirm_button`: `mat-dialog-container button.ms-button-primary`
  - `dialog_cancel_button`: `mat-dialog-container button.ms-button-borderless`
- **config.yaml**: New option `delete_after_review: true` for automatic cleanup
- **browser_client.py**: New `delete_current_chat()` method with full flow:
  1. Click 'View more actions' menu
