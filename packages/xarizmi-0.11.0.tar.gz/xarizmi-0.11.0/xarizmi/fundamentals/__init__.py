"""Module for fundamental analysis"""
