"""Exceptions for Accounting"""


class AccountingError(Exception):
    pass


class BalanceSheetMainGroupException(AccountingError):
    pass
