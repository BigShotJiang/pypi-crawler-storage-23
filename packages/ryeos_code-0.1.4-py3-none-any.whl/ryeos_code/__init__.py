"""RYE OS Code Bundle — git, npm, typescript, LSP, and diagnostics tools."""
