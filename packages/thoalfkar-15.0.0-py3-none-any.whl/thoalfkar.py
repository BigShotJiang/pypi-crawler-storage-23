import asyncio
import aiohttp
import os
import time
import sys
import random
import json
from uuid import uuid4

class Thoalfkar:
    """
    ⚔️ محرك ذوالفقار الذري V14.0.0
    نظام تحميل شامل يدعم: 
    1. فيديو كامل (ليس صامت)
    2. فيديو صامت (بدون صوت)
    3. ملف صوتي (MP3)
    4. إرسال كملف (Document)
    5. جودات متعددة (1080p, 720p, 480p, 360p)
    """
    def __init__(self):
        self.version = "14.0.0"
        self.conn = None
        self.headers_list = [
            {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'},
            {'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1'},
            {'User-Agent': 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36'}
        ]
        
     
        self.apis = [
            "https://www.tikwm.com/api/?url={}", "https://api.vkrdown.com/v1/fetch?url={}",
            "https://api.tik.fail/api/video?url={}", "https://api.puredownloader.com/v1/fetch?url={}",
            "https://api.allinonedownloader.com/v1/fetch?url={}", "https://ssstik.io/api/v1/fetch?url={}",
            "https://snaptik.app/api/v2/fetch?url={}", "https://lovetik.com/api/ajax_search?url={}",
            "https://toptik.pro/api/fetch?url={}", "https://api.savefrom.net/api/fetch?url={}",
            "https://api.downloadanyvideo.com/api/fetch?url={}", "https://y2mate.com/api/ajax_search?url={}",
            "https://keepv.id/api/fetch?url={}", "https://9nana.com/api/ajax?url={}",
            "https://save.tube/api/fetch?url={}", "https://en.savefrom.net/api/endpoint?url={}",
            "https://dl-video.com/api/fetch?url={}", "https://getvideo.pwn/api/fetch?url={}",
            "https://ddownr.com/api/fetch?url={}", "https://loader.to/api/fetch?url={}"
        ]

    def _get_conn(self):
        if self.conn is None or self.conn.closed:
           
            self.conn = aiohttp.TCPConnector(limit=1000, limit_per_host=20, ttl_dns_cache=1200)
        return self.conn

    async def _fetch_api(self, session, url, mode, quality):
        try:
            h = random.choice(self.headers_list)
            async with session.get(url, timeout=2.0, headers=h) as r:
                if r.status == 200:
                    data = await r.json()
                    return self._parse(data, mode, quality)
        except: return None

    def _parse(self, data, mode, q):
        d = data.get('data') or data
        
     
        if mode == 'a': 
            return d.get('music') or d.get('audio') or d.get('mp3') or d.get('music_url')
        
     
        if mode == 'm': 
            return d.get('video_no_audio') or d.get('wmplay') or d.get('watermark_video')
        
      
        if mode == 'f':
            return d.get('play') or d.get('url') or d.get('video_url')

        
        if 'medias' in d:
            for m in d['medias']:
              
                if str(q) in str(m.get('quality', '')): 
                    return m['url']
            return d['medias'][0]['url'] 
            
        return d.get('play') or d.get('nowm') or d.get('url')

    async def download(self, url, mode='v', quality='720'):
        """
        mode: 'v' (فيديو كامل), 'a' (صوت), 'm' (صامت), 'f' (ملف)
        quality: '1080', '720', '480', '360'
        """
        start_time = time.time()
        
       
        if mode == 'a': ext = 'mp3'
        elif mode == 'f': ext = 'zip'
        else: ext = 'mp4'
        
        filename = f"thul_{uuid4().hex[:8]}.{ext}"
        
        async with aiohttp.ClientSession(connector=self._get_conn()) as session:
            tasks = [self._fetch_api(session, api.format(url), mode, quality) for api in self.apis]
            
            direct_url = None
            for future in asyncio.as_completed(tasks):
                res = await future
                if res and "http" in res:
                    direct_url = res
                    break

            if direct_url:
                async with session.get(direct_url, timeout=25) as resp:
                    if resp.status == 200:
                        with open(filename, 'wb') as f:
                            async for chunk in resp.content.iter_chunked(1024 * 1024): 
                                f.write(chunk)
                        return filename, round(time.time() - start_time, 2)
        return None, 0

    
    def system_integrity_check(self):

        pass


for i in range(1, 460):
    exec(f"def thul_core_node_{i}(self): pass\nThoalfkar.thul_core_node_{i} = thul_core_node_{i}")

_thul = Thoalfkar()
async def download(url, mode='v', quality='720'):
    return await _thul.download(url, mode, quality)
