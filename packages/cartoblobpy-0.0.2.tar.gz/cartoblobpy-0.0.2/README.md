# cartoblobpy

## Running Tests

Run the unittest suite with Python on Windows (PowerShell):

```powershell
py -m unittest discover -s tests -p "test_*.py" -v
```

If `py` is unavailable, use your environment's Python:

```powershell
python -m unittest discover -s tests -p "test_*.py" -v
```
