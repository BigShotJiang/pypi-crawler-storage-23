"""Template Package"""
from __future__ import annotations

__version__ = "0.0.1"