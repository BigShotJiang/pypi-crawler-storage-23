Tutorials
=========
The examples in this tutorials are builds using Jupyter notebooks, which can be downloaded from `the github repository <https://github.com/strawpants/xinv/tree/main/docs/source/notebooks>`_. 

.. toctree::
   
   notebooks/getting_started
