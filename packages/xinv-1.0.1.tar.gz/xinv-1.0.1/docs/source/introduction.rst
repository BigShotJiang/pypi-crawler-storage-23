Introduction
============

The **xinv** package facilitates building and solving inverse problems using Xarray

Philosophy
-----------

under construction




