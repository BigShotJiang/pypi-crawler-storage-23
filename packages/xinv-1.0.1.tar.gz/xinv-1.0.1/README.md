# xinv or X-inverse
Xarray accessors for working with inverse problems

under construction
