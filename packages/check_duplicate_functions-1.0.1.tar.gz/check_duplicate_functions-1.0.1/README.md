# check-duplicate-functions

Detect duplicate function names in Python files using AST parsing.

## Features

- Detects duplicate function names (module-level and in classes)
- AST-based; handles async functions and type annotations
- Excludes special methods (`__init__`, `__str__`, etc.)
- No external dependencies

## Requirements

- Python 3.8+
- Standard library only

## Installation

```bash
pip install check-duplicate-functions
```

## Usage

```bash
check-duplicate-functions <python_file_path>
```

### Examples

```bash
check-duplicate-functions my_script.py
check-duplicate-functions src/utils.py
```

## Output

- **No duplicates**: Exits with code 0 (no output)
- **Duplicates found**: Prints each duplicate name and line numbers, e.g.  
  `[DUPLICATE] 'my_function' appears on lines: 10, 25, 42`
- **Errors**: Prints message and exits with code 1

## Exit codes

- `0` — Success
- `1` — Error (bad args, file not found, syntax error, etc.)

## Author

Pandiyaraj Karuppasamy
