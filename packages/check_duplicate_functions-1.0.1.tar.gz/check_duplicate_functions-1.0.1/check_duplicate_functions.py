#!/usr/bin/env python3
"""
Python script to detect duplicate function names in Python files.

This script analyzes Python source files using AST (Abstract Syntax Tree) parsing
to identify duplicate function definitions. It can detect:
- Duplicate function names at module level
- Duplicate method names within classes
- Functions with identical signatures (potential code duplication)
- Special methods (like __init__, __str__, etc.) are excluded from duplicate checks
  as they can legitimately appear in multiple classes

Usage:
    python check_duplicate_functions.py <python_file_path>

Example:
    python check_duplicate_functions.py my_script.py

Exit codes:
    0 - Success (no duplicates found or script completed successfully)
    1 - Error (file not found, syntax error, or other issues)
"""

__version__ = "1.0.1"

import ast
import os
import sys
from collections import Counter, defaultdict
from typing import Dict


class FunctionAnalyzer(ast.NodeVisitor):
    """
    AST visitor to extract function definitions from Python code.
    
    This class traverses the Abstract Syntax Tree of a Python file to collect
    information about all function definitions, including their names, line numbers,
    signatures, and class context.
    
    Attributes:
        functions: List of tuples containing function information:
            (name, line_number, signature, class_context, is_method, is_special_method)
        function_lines: Dictionary mapping function names to lists of line numbers
            where they are defined (excludes special methods)
        function_signatures: Dictionary mapping function names to lists of their
            signatures (excludes special methods)
        class_stack: Stack to track the current class context during AST traversal
    """

    def __init__(self):
        """Initialize the FunctionAnalyzer with empty data structures."""
        self.functions = []
        # function_name -> list of line numbers where function is defined
        self.function_lines = {}
        # function_name -> list of signatures (for detecting identical signatures)
        self.function_signatures = {}
        # Track current class context during AST traversal
        self.class_stack = []

    def visit_FunctionDef(self, node):
        """
        Visit regular (synchronous) function definitions.
        
        Args:
            node: AST node representing a function definition
        """
        self._add_function(node.name, node.lineno, self._get_signature(node))
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node):
        """
        Visit async function definitions.
        
        Args:
            node: AST node representing an async function definition
        """
        self._add_function(f"async {node.name}", node.lineno, self._get_signature(node))
        self.generic_visit(node)

    def visit_ClassDef(self, node):
        """
        Visit class definitions to track class context for methods.
        
        This method maintains a stack of class names to provide context
        for nested class definitions and their methods.
        
        Args:
            node: AST node representing a class definition
        """
        self.class_stack.append(node.name)
        self.generic_visit(node)
        self.class_stack.pop()

    def _add_function(self, name: str, lineno: int, signature: str):
        """
        Add function to the tracking lists with context information.
        
        This method stores function information including whether it's a method,
        whether it's a special method (like __init__), and its class context.
        Special methods are excluded from duplicate checking since they can
        legitimately appear in multiple classes.
        
        Args:
            name: Function name (may include "async " prefix for async functions)
            lineno: Line number where the function is defined
            signature: String representation of the function signature
        """
        # Determine if function is defined within a class (method)
        class_context = self.class_stack[-1] if self.class_stack else None
        is_method = class_context is not None
        # Check if this is a special method (dunder method)
        is_special_method = name.startswith("__") and name.endswith("__")

        # Store complete function information
        func_info = (
            name,
            lineno,
            signature,
            class_context,
            is_method,
            is_special_method,
        )
        self.functions.append(func_info)

        # For duplicate checking, exclude special methods like __init__, __str__, etc.
        # since they can legitimately appear in multiple classes
        if not is_special_method:
            # Track line numbers for each function name
            if name not in self.function_lines:
                self.function_lines[name] = []
            self.function_lines[name].append(lineno)

            # Track signatures for detecting identical function signatures
            if name not in self.function_signatures:
                self.function_signatures[name] = []
            self.function_signatures[name].append(signature)

    def _get_signature(self, node) -> str:
        """
        Extract function signature as a string representation.
        
        This method constructs a complete function signature including:
        - Regular arguments with optional type annotations
        - *args (variable positional arguments)
        - **kwargs (variable keyword arguments)
        - Keyword-only arguments
        - Return type annotation
        
        Args:
            node: AST node representing a function definition
            
        Returns:
            String representation of the function signature, e.g.:
            "(arg1: str, arg2: int, *args, **kwargs) -> bool"
        """
        args = []
        
        # Process regular positional arguments
        if node.args.args:
            for arg in node.args.args:
                arg_str = arg.arg
                if arg.annotation:
                    arg_str += f": {self._get_annotation_name(arg.annotation)}"
                args.append(arg_str)

        # Handle *args (variable positional arguments)
        if node.args.vararg:
            vararg_str = f"*{node.args.vararg.arg}"
            if node.args.vararg.annotation:
                vararg_str += f": {self._get_annotation_name(node.args.vararg.annotation)}"
            args.append(vararg_str)

        # Handle **kwargs (variable keyword arguments)
        if node.args.kwarg:
            kwarg_str = f"**{node.args.kwarg.arg}"
            if node.args.kwarg.annotation:
                kwarg_str += f": {self._get_annotation_name(node.args.kwarg.annotation)}"
            args.append(kwarg_str)

        # Handle keyword-only arguments (arguments after * or *args)
        if node.args.kwonlyargs:
            for arg in node.args.kwonlyargs:
                arg_str = arg.arg
                if arg.annotation:
                    arg_str += f": {self._get_annotation_name(arg.annotation)}"
                args.append(arg_str)

        signature = f"({', '.join(args)})"

        # Add return type annotation if present
        if node.returns:
            signature += f" -> {self._get_annotation_name(node.returns)}"

        return signature

    def _get_annotation_name(self, annotation) -> str:
        """
        Convert AST annotation node to string representation.
        
        This method recursively processes type annotations from the AST,
        handling various annotation types including:
        - Simple names (e.g., 'str', 'int')
        - Attribute access (e.g., 'typing.List', 'collections.abc.Iterable')
        - Subscripts (e.g., 'List[str]', 'Dict[str, int]')
        - Literal types (e.g., 'Literal["value"]')
        - Compatibility with older Python versions (ast.Index)
        
        Args:
            annotation: AST node representing a type annotation
            
        Returns:
            String representation of the type annotation
        """
        if isinstance(annotation, ast.Name):
            # Simple type name like 'str', 'int', 'bool'
            return annotation.id
        elif isinstance(annotation, ast.Attribute):
            # Attribute access like 'typing.List', 'collections.abc.Iterable'
            return f"{self._get_annotation_name(annotation.value)}.{annotation.attr}"
        elif isinstance(annotation, ast.Subscript):
            # Generic types like 'List[str]', 'Dict[str, int]'
            return f"{self._get_annotation_name(annotation.value)}[{self._get_annotation_name(annotation.slice)}]"
        elif isinstance(annotation, ast.Index):
            # Compatibility with older Python versions (< 3.9)
            return self._get_annotation_name(annotation.value)
        elif isinstance(annotation, ast.Constant):
            # Literal types and constants
            return repr(annotation.value)
        else:
            # Fallback for any other annotation types
            return str(annotation)


def analyze_file(file_path: str) -> Dict:
    """
    Analyze a Python file for duplicate function names.
    
    This function reads a Python file, parses it into an AST, and analyzes
    all function definitions to identify duplicates. It handles various
    error cases including file not found, permission errors, encoding issues,
    and syntax errors.
    
    Args:
        file_path: Path to the Python file to analyze
        
    Returns:
        Dictionary containing analysis results with the following keys:
        - 'duplicates': Dictionary mapping function names to sorted lists of
          line numbers where duplicates are found (excludes special methods)
        - 'all_functions': List of tuples containing all function information:
          (name, line_number, signature, class_context, is_method, is_special_method)
        - 'duplicate_signatures': Dictionary mapping signatures to lists of
          function names that share identical signatures
        - 'total_functions': Total number of functions found (including special methods)
        - 'unique_function_names': Number of unique function names (excluding special methods)
        - 'special_methods': List of special methods (dunder methods) found
        - 'error': Error message string (only present if an error occurred)
    """
    # Read the source file with error handling
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            source_code = f.read()
    except FileNotFoundError:
        return {"error": f"File not found: {file_path}"}
    except PermissionError:
        return {"error": f"Permission denied: {file_path}"}
    except UnicodeDecodeError:
        return {"error": f"Encoding error reading file: {file_path}"}

    # Parse the source code into an AST
    try:
        tree = ast.parse(source_code, filename=file_path)
    except SyntaxError as e:
        return {"error": f"Syntax error in {file_path}: {e}"}

    # Analyze the AST to extract function information
    analyzer = FunctionAnalyzer()
    analyzer.visit(tree)

    # Find duplicate function names (functions with the same name defined multiple times)
    duplicates = {}
    for func_name, lines in analyzer.function_lines.items():
        if len(lines) > 1:
            duplicates[func_name] = sorted(lines)

    # Find functions with identical signatures (potential code duplication or overloads)
    duplicate_signatures = defaultdict(list)
    for func_name, signatures in analyzer.function_signatures.items():
        sig_counter = Counter(signatures)
        for sig, count in sig_counter.items():
            if count > 1:
                duplicate_signatures[sig].extend([func_name] * count)

    return {
        "duplicates": duplicates,
        "all_functions": analyzer.functions,
        "duplicate_signatures": dict(duplicate_signatures),
        "total_functions": len(analyzer.functions),
        "unique_function_names": len(analyzer.function_lines),
        # Extract special methods (functions where is_special_method=True, index 5 in tuple)
        "special_methods": [f for f in analyzer.functions if f[5]],
    }


def print_analysis_results(file_path: str, results: Dict):
    """
    Print the analysis results in a readable format.
    
    This function only prints output when duplicates are found or errors occur.
    If no duplicates are found, the function produces no output (silent success).
    
    Args:
        file_path: Path to the analyzed file (for context in error messages)
        results: Dictionary containing analysis results from analyze_file()
    """
    # Print error messages if any occurred during analysis
    if "error" in results:
        print(f"[ERROR] {results['error']}")

    # Print duplicate function names and their line numbers
    duplicates = results.get("duplicates", {})
    if duplicates:
        for func_name, lines in duplicates.items():
            print(f"[DUPLICATE] '{func_name}' appears on lines: {', '.join(map(str, lines))}")


def main():
    """
    Main function to handle command line arguments and orchestrate the analysis.
    
    This function:
    1. Validates command line arguments
    2. Checks if the file exists
    3. Warns if the file doesn't have a .py extension
    4. Analyzes the file for duplicate functions
    5. Prints the results
    
    Exit codes:
        0: Success (no duplicates found or analysis completed)
        1: Error (invalid arguments, file not found, or analysis error)
    """
    # Validate command line arguments
    if len(sys.argv) != 2:
        print("Usage: python check_duplicate_functions.py <python_file_path>")
        print("Example: python check_duplicate_functions.py my_script.py")
        sys.exit(1)

    file_path = sys.argv[1]

    # Check if file exists
    if not os.path.isfile(file_path):
        print(f"[ERROR] File not found: {file_path}")
        sys.exit(1)

    # Warn if file doesn't have .py extension (but continue anyway)
    if not file_path.endswith(".py"):
        print(f"[WARNING] File doesn't have .py extension: {file_path}")

    # Perform analysis and print results
    results = analyze_file(file_path)
    print_analysis_results(file_path, results)


if __name__ == "__main__":
    """
    Entry point for the script when run directly.
    
    Wraps main() in a try-except block to handle any unexpected errors
    and ensure proper exit codes.
    """
    try:
        main()
    except Exception as e:
        print(f"[ERROR] Unexpected error: {str(e)}")
        sys.exit(1)
