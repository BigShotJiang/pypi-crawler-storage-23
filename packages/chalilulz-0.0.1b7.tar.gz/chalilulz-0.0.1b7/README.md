# chalilulz

<p align="center">
  <img src="https://img.shields.io/badge/python-3.8+-blue.svg" alt="Python 3.8+">
  <img src="https://img.shields.io/badge/LLM-Cli-orange.svg" alt="LLM CLI">
  <img src="https://img.shields.io/badge/Open-Source-green.svg" alt="Open Source">
  <img src="https://img.shields.io/badge/Platform-Cross--Platform-yellow.svg" alt="Cross Platform">
</p>

<p align="center">
  <strong>Agentic coding CLI with multi-provider LLM support</strong><br>
  <em>OpenRouter · Ollama · Mistral · Groq · Gemini</em>
</p>

---

## Features

- **Multi-Provider Support** — Seamlessly switch between OpenRouter, Ollama, Mistral, Groq, and Gemini
- **Streaming Responses** — Token-by-token output directly in the terminal
- **Agent Safety Guardrails** — 25-round max agent loop guard and interactive `[y/N]` prompts before executing dangerous tools (like `bash`, `rm`, `write`)
- **Interactive REPL** — Supports `readline` tab-completion for `/commands` and local file paths!
- **Context Window Truncation** — Dynamic bounding up to ~60k tokens to prevent API capacity errors
- **Session Persistence** — Use `/save <name>` and `/load <name>` to seamlessly pause and resume work
- **Gorgeous ANSI Rendering** — Renders markdown blocks, bold headings (`#`), and list items (`-`) natively
- **Agent Skills** — Load custom system instruction sets from `.skills/` directory
- **Zero Dependencies** — Pure Python standard library inside — no massive packages required

---

## Installation

### Quick Install (pip)

```bash
# Install globally via git
pip install git+https://github.com/ForgedInFiles/chalilulz.git

# Or install locally (editable mode)
git clone https://github.com/ForgedInFiles/chalilulz.git
cd chalilulz
pip install -e .
```

### Requirements

- Python 3.8 or higher
- API keys for your chosen provider (optional for local Ollama)

---

## Quick Start

```bash
# After installation, run from anywhere
chalilulz

# Or set a specific model
chalilulz --model openrouter:arcee-ai/trinity-large-preview:free

# Run with Ollama (default)
chalilulz --model ollama:llama2

# Run with Mistral
chalilulz --model mistral:mistral-small-latest --mistral-key $MISTRAL_API_KEY

# Run with Groq
chalilulz --model groq:llama-3.1-70b-versatile --groq-key $GROQ_API_KEY

# Auto-approve tool execution
chalilulz --yes
```

---

## Configuration

You can configure persistent defaults by creating `~/.config/chalilulz/config.json`:

```json
{
  "model": "openrouter:anthropic/claude-3.5-sonnet",
  "ollama_host": "http://localhost:11434",
  "mistral_key": "YOUR_MISTRAL_KEY",
  "yes": false
}
```

Or you can use Environment Variables:

| Variable | Description |
|----------|-------------|
| `OPENROUTER_API_KEY` | API key for OpenRouter |
| `MISTRAL_API_KEY` | API key for Mistral AI |
| `GROQ_API_KEY` | API key for Groq |
| `GOOGLE_API_KEY` | API key for Gemini |
| `CHALILULZ_MODEL` | Default model (e.g., `openrouter:arcee-ai/trinity-large-preview:free`) |
| `CHALILULZ_OLLAMA_HOST` | Ollama host (default: `http://localhost:11434`) |

---

## Available Tools

| Tool | Description |
|------|-------------|
| `read` | Read files with line numbers |
| `write` | Write/create files (auto mkdir) |
| `edit` | Replace a unique string in files |
| `multi_edit` | Apply large non-contiguous patches to files via JSON array |
| `glob` | Find files by glob pattern sorted by mtime (ignores `.git/`, `node_modules/`, etc) |
| `grep` | Search files by regex |
| `bash` | Execute shell commands |
| `ls` | List directory contents |
| `mkdir` | Create directories recursively |
| `rm` | Delete files or directories |
| `mv` | Move/rename files |
| `cp` | Copy files or directories |
| `find` | Recursive find by name pattern |
| `load_skill` | Load full skill instructions by name |

---

## REPL Commands

During an active session, you can use the following commands:
- `/model <slug>` - Switch provider/model live (e.g., `/model ollama:codellama`)
- `/save <name>` - Save the current session context to `~/.local/share/chalilulz/sessions/`
- `/load <name>` - Load a previously saved session context
- `/yes` - Enable auto-approval for dangerous tool execution (`bash`, `rm`, `write`, `edit`)
- `/no` - Disable auto-approval (default behavior)
- `/skills list` - List available `.skills/` bundles
- `/c` - Clear the terminal
- `/q` or `exit` - Quit application
- `/help` - Show command help

---

## License

MIT License — Feel free to use, modify, and distribute.

---

<p align="center">
  Built with love for developers who love CLI tools
</p>
