"""BM25-based search engine for the textual documentation index.

Wraps :pypi:`rank_bm25` to provide ranked retrieval over :class:`DocEntry`
objects produced by :class:`~textual_docs_mcp.indexer.TextualIndexer`.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Sequence

import numpy as np
from rank_bm25 import BM25Okapi

from textual_docs_mcp.models import Category, DocEntry, SearchResult

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tokeniser
# ---------------------------------------------------------------------------
# Simple but effective: lowercase, extract word tokens ≥ 3 chars, drop stop-
# words.  We intentionally keep identifiers (snake_case, PascalCase) intact.
# ---------------------------------------------------------------------------

_STOPWORDS: frozenset[str] = frozenset(
    {
        "the", "a", "an", "is", "it", "in", "on", "of", "to", "for", "with",
        "that", "this", "and", "or", "be", "as", "at", "from", "by", "are",
        "was", "were", "have", "has", "had", "will", "would", "can", "could",
        "should", "may", "must", "not", "also", "its", "you", "use", "your",
        "how", "what", "when", "where", "which", "who", "all", "any",
    }
)

_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9_]{1,}")


def tokenise(text: str) -> list[str]:
    """Convert *text* into a list of normalised tokens."""
    tokens = _TOKEN_RE.findall(text.lower())
    return [t for t in tokens if t not in _STOPWORDS]


# ---------------------------------------------------------------------------
# Snippet extraction
# ---------------------------------------------------------------------------

def _extract_snippet(content: str, query_tokens: set[str], window: int = 400) -> str:
    """Return a short snippet from *content* centred on the best match."""
    lower = content.lower()
    best_pos = 0
    best_hits = 0

    # Slide a window and count query token hits
    step = window // 2
    for start in range(0, max(1, len(lower) - window), step):
        chunk = lower[start : start + window]
        hits = sum(1 for t in query_tokens if t in chunk)
        if hits > best_hits:
            best_hits = hits
            best_pos = start

    snippet = content[best_pos : best_pos + window].strip()
    if best_pos > 0:
        snippet = "…" + snippet
    if best_pos + window < len(content):
        snippet = snippet + "…"
    return snippet


# ---------------------------------------------------------------------------
# BM25Search
# ---------------------------------------------------------------------------


class BM25Search:
    """Pre-built BM25 index over a list of :class:`DocEntry` objects.

    Parameters
    ----------
    entries:
        The list of documents to index, typically from
        :class:`~textual_docs_mcp.indexer.TextualIndexer`.
    """

    def __init__(self, entries: Sequence[DocEntry]) -> None:
        self._entries: list[DocEntry] = list(entries)
        logger.info("Building BM25 index over %d documents …", len(self._entries))
        corpus = [tokenise(e.title + " " + e.content) for e in self._entries]
        self._index = BM25Okapi(corpus)
        logger.info("BM25 index ready.")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def search(
        self,
        query: str,
        *,
        max_results: int = 5,
        category: Category | None = None,
    ) -> list[SearchResult]:
        """Return ranked search results for *query*.

        Parameters
        ----------
        query:
            Natural-language query string.
        max_results:
            Maximum number of results to return (capped at :data:`MAX_SEARCH_RESULTS`).
        category:
            If given, restrict results to documents with this category.
        """
        q_tokens = tokenise(query)
        if not q_tokens:
            return []

        raw_scores: np.ndarray = self._index.get_scores(q_tokens)

        # Build (score, index) pairs and optionally filter by category
        scored: list[tuple[float, int]] = []
        for idx, score in enumerate(raw_scores):
            if category is not None and self._entries[idx].category != category:
                continue
            scored.append((float(score), idx))

        # Sort descending by score
        scored.sort(key=lambda t: t[0], reverse=True)

        q_token_set = set(q_tokens)
        results: list[SearchResult] = []
        for score, idx in scored[:max_results]:
            if score <= 0.0:
                break
            entry = self._entries[idx]
            snippet = _extract_snippet(entry.content, q_token_set)
            results.append(SearchResult(entry=entry, score=score, snippet=snippet))

        return results

    def get_by_slug(self, slug: str, category: Category | None = None) -> DocEntry | None:
        """Retrieve a document by its exact slug (case-insensitive).

        Optionally restrict the lookup to a given category.
        """
        target = slug.lower()
        for entry in self._entries:
            if entry.slug == target and (category is None or entry.category == category):
                return entry
        return None

    def fuzzy_get(self, name: str, category: Category | None = None) -> DocEntry | None:
        """Try to find the best matching document for a human-readable *name*.

        Checks (in order):
        1. Exact slug match.
        2. Title contains the normalised name.
        3. Slug contains the normalised name.
        """
        normalised = name.lower().replace(" ", "_").replace("-", "_")
        slug_style = normalised.replace("_", "-")

        # 1. Exact slug match
        exact = self.get_by_slug(slug_style, category) or self.get_by_slug(normalised, category)
        if exact:
            return exact

        # 2. Title substring
        for entry in self._entries:
            if category is not None and entry.category != category:
                continue
            if normalised in entry.title.lower().replace(" ", "_"):
                return entry

        # 3. Slug substring
        for entry in self._entries:
            if category is not None and entry.category != category:
                continue
            if normalised in entry.slug or slug_style in entry.slug:
                return entry

        return None

    def list_by_category(self, category: Category) -> list[DocEntry]:
        """Return all documents belonging to *category*, sorted by title."""
        return sorted(
            (e for e in self._entries if e.category == category),
            key=lambda e: e.title.lower(),
        )
