"""Runtime loader for the bundled Textual documentation data.

Reads the compressed NDJSON bundle that ships with this package
(``textual_docs_mcp/data/docs.ndjson.gz``) and returns a list of
:class:`~textual_docs_mcp.models.DocEntry` objects ready to be passed to
:class:`~textual_docs_mcp.search.BM25Search`.

This module has **no dependency on a local Textual repository clone** — it
works purely from the data that was embedded at package build time.
"""

from __future__ import annotations

import gzip
import io
import json
import logging
from importlib.resources import files
from pathlib import Path

from textual_docs_mcp.models import DocEntry

logger = logging.getLogger(__name__)

_BUNDLE_FILENAME = "docs.ndjson.gz"


def load_entries() -> list[DocEntry]:
    """Load all :class:`DocEntry` objects from the bundled data file.

    Returns
    -------
    list[DocEntry]
        All indexed documentation entries, deserialized from the compressed
        NDJSON bundle included with the package.

    Raises
    ------
    FileNotFoundError
        If the bundle file is missing (i.e. ``build_bundle.py`` has not been run).
    """
    data_pkg = files("textual_docs_mcp.data")
    bundle = data_pkg.joinpath(_BUNDLE_FILENAME)

    try:
        raw = bundle.read_bytes()
    except FileNotFoundError as exc:
        raise FileNotFoundError(
            f"Documentation bundle not found: {_BUNDLE_FILENAME!r}. "
            "Run 'python scripts/build_bundle.py' to generate it."
        ) from exc

    entries: list[DocEntry] = []
    with gzip.open(io.BytesIO(raw)) as gz:
        for raw_line in gz:
            stripped = raw_line.strip()
            if not stripped:
                continue
            record: dict[str, object] = json.loads(stripped)
            # path is stored as a string; Pydantic coerces it to Path
            record["path"] = Path(str(record["path"]))
            entries.append(DocEntry.model_validate(record))

    logger.info("Loaded %d documentation entries from bundle.", len(entries))
    return entries
