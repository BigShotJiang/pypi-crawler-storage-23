"""Build-time document indexer for the Textual repository.

This module is used exclusively by the bundle-generation script
(``scripts/build_bundle.py``) to read documentation and examples from a
local Textual repository clone and produce a list of :class:`DocEntry`
objects that are then serialised to the package data bundle.

It is **not** imported or used at runtime by the MCP server.  Configure the
repo path via the ``TEXTUAL_REPO_PATH`` environment variable or rely on the
auto-detection fallback for local development.
"""

from __future__ import annotations

import logging
import os
import re
from collections.abc import Iterator
from pathlib import Path

import frontmatter

from textual_docs_mcp.models import Category, DocEntry

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Repo path resolution (build-time only)
# ---------------------------------------------------------------------------

_ENV_VAR = "TEXTUAL_REPO_PATH"
_PACKAGE_ROOT = Path(__file__).parent          # src/textual_docs_mcp/
_PROJECT_ROOT = _PACKAGE_ROOT.parent.parent    # project root

# Maximum characters for a search result excerpt
_EXCERPT_CHARS: int = 600

# ---------------------------------------------------------------------------
# Category mapping: sub-directory name → Category
# ---------------------------------------------------------------------------
_DIR_TO_CATEGORY: dict[str, Category] = {
    "guide": Category.GUIDE,
    "widgets": Category.WIDGET,
    "api": Category.API,
    "events": Category.EVENT,
    "styles": Category.STYLE,
    "css_types": Category.CSS_TYPE,
    "how-to": Category.HOW_TO,
    "reference": Category.REFERENCE,
}

_ROOT_FILE_CATEGORIES: dict[str, Category] = {
    "getting_started": Category.GUIDE,
    "tutorial": Category.TUTORIAL,
    "faq": Category.FAQ,
    "widget_gallery": Category.WIDGET,
}

# Markdown code-block fence pattern (strip when extracting excerpts)
_CODE_FENCE = re.compile(r"```.*?```", re.DOTALL)

# Snippet injection pattern used in Textual docs (--8<--)
_SNIPPET_INCLUDE = re.compile(r'-{2,}8<-{2,}.*?-{2,}8<-{2,}|--8<-- ".*?"', re.DOTALL)

# Admonition shortcodes that add noise
_ADMONITION = re.compile(r"!!!(.*?)(?=\n\S|\Z)", re.DOTALL)


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def resolve_repo_path() -> Path:
    """Return a validated path to the local Textual repository.

    Resolution order:
    1. ``TEXTUAL_REPO_PATH`` environment variable
    2. Development fallback paths (not for end users)

    Raises :exc:`FileNotFoundError` if no valid path can be found.
    """
    env_val = os.environ.get(_ENV_VAR)
    if env_val:
        path = Path(env_val)
        if path.is_dir():
            return path.resolve()
        raise FileNotFoundError(
            f"{_ENV_VAR!r} is set to {env_val!r} but that directory does not exist."
        )

    for candidate in (
        _PROJECT_ROOT / "repos" / "textual",
        Path.cwd() / "repos" / "textual",
    ):
        if candidate.is_dir():
            return candidate.resolve()

    raise FileNotFoundError(
        "Cannot locate a local Textual repository clone for bundle generation. "
        f"Set the {_ENV_VAR!r} environment variable to its absolute path."
    )


# ---------------------------------------------------------------------------
# Content processing helpers
# ---------------------------------------------------------------------------


def _extract_title(content: str, path: Path) -> str:
    """Extract the document title from its first H1 heading or fallback to filename."""
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("# "):
            return stripped[2:].strip()
    return path.stem.replace("_", " ").replace("-", " ").title()


def _make_excerpt(content: str) -> str:
    """Produce a short plain-text excerpt from the document content."""
    text = _CODE_FENCE.sub("", content)
    text = _SNIPPET_INCLUDE.sub("", text)
    text = _ADMONITION.sub("", text)
    text = re.sub(r"#{1,6}\s+", "", text)
    text = re.sub(r"[*_`]{1,3}", "", text)
    text = re.sub(r"\n{2,}", "\n", text).strip()
    return text[:_EXCERPT_CHARS]


def _make_slug(path: Path) -> str:
    """Create a URL-style slug from a file path stem."""
    return path.stem.lower().replace(" ", "-")


# ---------------------------------------------------------------------------
# File parsers
# ---------------------------------------------------------------------------


def _parse_markdown_file(path: Path, category: Category) -> DocEntry | None:
    """Parse a single Markdown file into a :class:`DocEntry`."""
    try:
        post = frontmatter.load(str(path))
        content: str = post.content
        meta: dict[str, object] = post.metadata
    except Exception:  # noqa: BLE001  # frontmatter parse failures are non-fatal
        logger.warning("Failed to parse frontmatter in %s", path)
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            logger.error("Cannot read file: %s", path)
            return None
        meta = {}

    if not content.strip() or content.strip() == "_template":
        return None

    title: str = (
        str(meta.get("title") or meta.get("name") or "") or _extract_title(content, path)
    )

    return DocEntry(
        title=title,
        slug=_make_slug(path),
        path=path,
        category=category,
        content=content,
        excerpt=_make_excerpt(content),
        language="markdown",
    )


def _parse_python_file(path: Path) -> DocEntry | None:
    """Parse a Python example file into a :class:`DocEntry`."""
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        logger.error("Cannot read file: %s", path)
        return None

    if not source.strip():
        return None

    docstring_match = re.match(r'"""(.*?)"""', source, re.DOTALL)
    description = docstring_match.group(1).strip() if docstring_match else ""

    return DocEntry(
        title=path.stem.replace("_", " ").title(),
        slug=_make_slug(path),
        path=path,
        category=Category.EXAMPLE,
        content=source,
        excerpt=(description or source)[:_EXCERPT_CHARS],
        language="python",
    )


# ---------------------------------------------------------------------------
# Main indexer class
# ---------------------------------------------------------------------------


class TextualIndexer:
    """Read a local Textual repository into a list of :class:`DocEntry` objects.

    Parameters
    ----------
    repo_path:
        Absolute path to the Textual repository root.  Defaults to the
        result of :func:`resolve_repo_path` if not supplied.
    """

    def __init__(self, repo_path: Path | None = None) -> None:
        self._repo_path: Path = repo_path or resolve_repo_path()
        self._docs_path: Path = self._repo_path / "docs"
        self._examples_path: Path = self._repo_path / "examples"
        self._entries: list[DocEntry] = []
        self._built: bool = False

    @property
    def entries(self) -> list[DocEntry]:
        """Return all indexed entries, building the index if needed."""
        if not self._built:
            self.build()
        return self._entries

    def build(self) -> None:
        """Scan the textual repository and populate the entry list."""
        logger.info("Building documentation index from %s ...", self._repo_path)
        self._entries = list(self._iter_all_entries())
        self._built = True
        logger.info("Index built: %d documents", len(self._entries))

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _iter_all_entries(self) -> Iterator[DocEntry]:
        yield from self._iter_doc_subdirs()
        yield from self._iter_root_docs()
        yield from self._iter_examples()

    def _iter_doc_subdirs(self) -> Iterator[DocEntry]:
        doc_subdirs = {
            "guide": Category.GUIDE,
            "widgets": Category.WIDGET,
            "api": Category.API,
            "events": Category.EVENT,
            "styles": Category.STYLE,
            "css_types": Category.CSS_TYPE,
            "how-to": Category.HOW_TO,
            "reference": Category.REFERENCE,
        }
        for dir_name, category in doc_subdirs.items():
            directory = self._docs_path / dir_name
            if not directory.is_dir():
                logger.debug("Skipping missing sub-directory: %s", directory)
                continue
            for md_file in sorted(directory.glob("*.md")):
                if md_file.stem.startswith("_"):
                    continue
                entry = _parse_markdown_file(md_file, category)
                if entry is not None:
                    yield entry

    def _iter_root_docs(self) -> Iterator[DocEntry]:
        root_files: list[tuple[Path, Category]] = [
            (self._docs_path / "getting_started.md", Category.GUIDE),
            (self._docs_path / "tutorial.md", Category.TUTORIAL),
            (self._docs_path / "FAQ.md", Category.FAQ),
            (self._docs_path / "widget_gallery.md", Category.WIDGET),
        ]
        for doc_path, category in root_files:
            if not doc_path.is_file():
                logger.debug("Skipping missing root doc: %s", doc_path)
                continue
            entry = _parse_markdown_file(doc_path, category)
            if entry is not None:
                yield entry

    def _iter_examples(self) -> Iterator[DocEntry]:
        if not self._examples_path.is_dir():
            logger.debug("Examples directory not found: %s", self._examples_path)
            return
        for py_file in sorted(self._examples_path.glob("*.py")):
            entry = _parse_python_file(py_file)
            if entry is not None:
                yield entry
