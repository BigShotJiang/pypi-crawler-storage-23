"""Pydantic data models for textual-docs-mcp."""

from __future__ import annotations

from enum import StrEnum
from pathlib import Path

from pydantic import BaseModel, Field, field_validator


class Category(StrEnum):
    """Document category within the Textual documentation set."""

    GUIDE = "guide"
    WIDGET = "widget"
    API = "api"
    EVENT = "event"
    STYLE = "style"
    CSS_TYPE = "css_type"
    HOW_TO = "how_to"
    EXAMPLE = "example"
    TUTORIAL = "tutorial"
    REFERENCE = "reference"
    FAQ = "faq"
    OTHER = "other"


class DocEntry(BaseModel):
    """A single indexed documentation or example entry."""

    title: str = Field(description="Human-readable title of the document.")
    slug: str = Field(description="URL-style slug derived from the file name (no extension).")
    path: Path = Field(description="Absolute filesystem path of the source file.")
    category: Category = Field(description="High-level category of this document.")
    content: str = Field(description="Full text content of the document.")
    excerpt: str = Field(description="Short excerpt used for search result previews.")
    language: str = Field(
        default="markdown",
        description="Content language: 'markdown' or 'python'.",
    )

    @field_validator("slug")
    @classmethod
    def normalise_slug(cls, v: str) -> str:
        """Ensure slug is always lowercase."""
        return v.lower()

    model_config = {"frozen": True}


class SearchResult(BaseModel):
    """A single search result with relevance metadata."""

    entry: DocEntry = Field(description="The matched document entry.")
    score: float = Field(description="BM25 relevance score (higher = more relevant).")
    snippet: str = Field(description="Context snippet showing the most relevant passage.")

    model_config = {"frozen": True}
