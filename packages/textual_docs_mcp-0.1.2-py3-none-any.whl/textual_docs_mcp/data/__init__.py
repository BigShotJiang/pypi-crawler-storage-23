"""Package data directory for textual-docs-mcp.

Contains ``docs.ndjson.gz`` — the pre-built documentation bundle generated
by ``scripts/build_bundle.py``.
"""
