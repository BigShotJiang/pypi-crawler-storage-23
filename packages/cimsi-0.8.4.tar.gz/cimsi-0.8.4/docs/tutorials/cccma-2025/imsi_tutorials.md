# IMSI Tutorials

The tutorials here consist of Jupyter notebooks and contain shell code that can be executed. This does require a bit of setup of the bash kernel.

## Setting up Jupyter notebooks and bash_kernel in VSCode

Open VSCode and remotely connect to the HPC system. Open the Folder where you've downloaded this repository. Click the gear icon in the lower left corner of VSCode and then "Extensions", and install/enable the Jupyter extension.

Next install a Python kernel for the Jupyter notebook. You can do this by navigating to one of the `.ipynb` notebooks and clicking the "Select Kernel" button in the upper right. Select "Python Environments...", then "+ Create Python Environment", then "Venv". Select a Python 3 version for the interpreter--this can be a version found on the system or your own installation. You may be asked for a `requirements.txt` file but it is not necessary to use one. You'll end with a `.venv` file in the open folder of your VSCode session. 

Open a terminal (in VSCode or otherwise), navigate to the open folder, and activate the new environment:
```
source .venv/bin/activate
```

Then execute these commands to install the bash kernel:
``` 
pip install bash_kernel
python -m bash_kernel.install
```

You may need to exit and restart VSCode before you can select the bash kernel. Open one of the tutorial notebooks and click "Select Kernel" again. Now "Bash" should appear as an option--select that and the cells within the notebook should now be executable.

## Jupyter notebooks in Thinlinc