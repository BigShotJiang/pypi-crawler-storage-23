from pathlib import Path
import pytest
from imsi.utils import general

@pytest.fixture
def sample_dir(tmp_path: Path) -> Path:
    (tmp_path / 'a.txt').write_text('a')
    subfolder = tmp_path / 'subfolder'
    subfolder.mkdir()
    (subfolder / 'b.ext').write_text('b')
    return tmp_path

@pytest.mark.parametrize(
    "root, subfolder, greedy, expected",
    [
        ('/path/to', '/path/to/folder', False, True),
        ('/path/to', '/other/path', False, False),
        ('/path/to', '/path/to', False, False),
        ('/path/to', '/path/to', True, True),
        ('/path/to', '/path/to/file.txt', False, True),
        ('/path/to/file1.txt', '/path/to/file2.txt', False, False),
    ],
)
def test_is_root_of(root, subfolder, greedy, expected):
    result = general.is_root_of(root, subfolder, greedy=greedy)
    assert result is expected

def test_list_dir_contents_all(sample_dir: Path):
    ls = general.list_dir_contents(sample_dir)
    assert ls == list(sorted(sample_dir.rglob('*')))

def test_list_dir_contents_txt_only(sample_dir: Path):
    ls = general.list_dir_contents(sample_dir, extensions=['.txt'], keep_folders=False)
    assert ls == list(sorted([p for p in sample_dir.rglob('*') if p.suffix == '.txt']))
    assert (sample_dir / 'a.txt') in ls

def test_list_dir_contents_no_folders(sample_dir: Path):
    ls = general.list_dir_contents(sample_dir, keep_folders=False)
    assert ls == list(sorted([p for p in sample_dir.rglob('*') if not p.is_dir()]))
    assert (sample_dir / 'a.txt') in ls
    assert (sample_dir / 'subfolder') not in ls
