import pytest

from imsi.utils import dict_tools


def test_nested_get_success():
    d = {'a': {'b': {'c': 2}}}
    assert dict_tools.nested_get(d, ['a', 'b', 'c']) == 2

def test_nested_get_strict_missing_key():
    d = {'a': {'b': 1}}
    with pytest.raises(KeyError, match='c'):
        dict_tools.nested_get(d, ['a', 'b', 'c'], strict=True)

def test_nested_get_nostrict_missing_key():
    d = {'a': {'b': 1}}
    assert dict_tools.nested_get(d, ['a', 'b', 'c'], strict=False) is None

def test_nested_get_nostrict_custom_default():
    d = {'a': {'b': 1}}
    fallback = 'custom'
    assert dict_tools.nested_get(d, ['a', 'b', 'c'], strict=False, default=fallback) == fallback

def test_nested_get_nokeys():
    d = {'a': {'b': 1}}
    assert dict_tools.nested_get(d, []) == d
