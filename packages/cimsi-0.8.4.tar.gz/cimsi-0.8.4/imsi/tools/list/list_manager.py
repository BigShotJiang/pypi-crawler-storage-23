import pandas as pd
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.tree import Tree
from typing import Iterable, Callable, Hashable

from imsi.config_manager.config_manager import database_factory
from imsi.utils.dict_tools import nested_get
from imsi.utils.general import list_dir_contents


_PANEL_COLUMN_COLOURS = ['magenta', 'cyan', 'default']

list_template = """\
{source}|{path}
{options}
"""

def _filter_dataframe(
    df: pd.DataFrame,
    filters: dict[Hashable, str | None],
    match_fn: Callable[[pd.Series, str], pd.Series] = lambda col, val: col == val,
) -> pd.DataFrame:
    for column, value in filters.items():
        if value is not None:
            df = df[match_fn(df[column], value)]
    return df


def _load_model_experiment_pairs(imsi_config_path: Path) -> pd.DataFrame:
    experiments_db = database_factory(imsi_config_path / "experiments")
    experiments = experiments_db.get_config("experiments")

    data = []
    for experiment in experiments:
        models = experiments_db.get_parsed_config("experiments", experiment).get("supported_models", [])
        for model in models:
            data.append((model, experiment))

    df = pd.DataFrame(data, columns=["model", "experiment"]) if data else pd.DataFrame()

    return df


def gather_choices_df(
    repo_paths: Iterable[Path],
    repo_sources: Iterable[str],
    relative_imsi_config_path: Path,
    filter_model: str = None,
    filter_experiment: str = None,
) -> pd.DataFrame:

    all_rows = []
    for repo, source in zip(repo_paths, repo_sources):
        imsi_config_path = repo / relative_imsi_config_path
        df = _load_model_experiment_pairs(imsi_config_path)

        if df.empty:
            continue

        df["repo"] = str(repo)
        df["source"] = source

        filters = {
            "model": filter_model,
            "experiment": filter_experiment,
        }
        df = _filter_dataframe(df, filters)

        if not df.empty:
            all_rows.append(df)

    if not all_rows:
        return pd.DataFrame()

    return pd.concat(all_rows, ignore_index=True)


def _fill_plain_template(info_from_repos):
    # info_from_repos is a list of dicts a that contain:
    #   path : path to the repository
    #   source : the type of source of the repo (e.g. .rc)
    #   options : the list of relevant options from the source
    # newline separation between blocks
    return('\n'.join(
            [
                list_template.format(
                    source=info['source'],
                    path=info['path'],
                    options=' '.join(sorted(info['options']))
                    )
                    for info in info_from_repos
            ]
        )
    )

def _create_panel_repo_title(repo, source):
    return f"[green]{repo}[/green] ({source})"


def _create_panel(contents, title=None):
    return Panel(contents, title=title, border_style="cyan")


def render_choices_table(df: pd.DataFrame, plain=True) -> None:
    """
    Render available models/experiments grouped by site/source,
    always showing full model names.
    """

    if df.empty:
        console.print("[red]No matching configurations found.[/red]")
        return

    grouped_data = []
    for (source, repo), df_group in df.groupby(["source", "repo"]):
        if plain:
            grouped = df_group['model'] + '|' + df_group['experiment']
        else:
            grouped = df_group.groupby("model")["experiment"].apply(
                lambda exps: ", ".join(sorted(set(exps)))
            )
        grouped_data.append({
            'path': repo,
            'source': source,
            'options': grouped
            })

    # Render each group
    if plain:
        print(_fill_plain_template(grouped_data))
    else:
        console = Console()
        for group in grouped_data:
            table = Table(show_header=True, box=None, padding=(0, 1))

            table.add_column("Model", justify="left", style=_PANEL_COLUMN_COLOURS[0], no_wrap=True)
            table.add_column("Supported Experiments", justify="left", style=_PANEL_COLUMN_COLOURS[1], overflow="fold")

            for model, experiments in group['options'].items():
                table.add_row(model, experiments)

            panel_title = _create_panel_repo_title(group['path'], group['source'])
            console.print(_create_panel(table, title=panel_title))


def build_tree(
        root: Path, tree: Tree, exts: set[str] | None = None,
        show_exts: bool=False,
        with_rel_stems: bool=False,
        branch_color='default'
) -> None:
    """Create a tree of files under folders recursively.

    Parameters:
        root:
            Path from which to start building the tree
        exts:
            Set of extensions to include (filter). If None or empty, include all files.
        with_rel_stems:
            If True, includes the relative path to the file starting from root on the
            row of the file (useful for users to copy + paste).
        branch_color:
            Color to render the branches.

    Returns:
        Tree of the directory, with formatting.
    """
    # FUTURE: consider generalizing this out of needing rich.tree
    ls = sorted(root.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
    for path in ls:
        if path.is_dir():
            branch = tree.add(f"[{branch_color}]{path.name}/[/]")
            build_tree(path, branch, exts,
                       show_exts=show_exts, with_rel_stems=with_rel_stems,
                       branch_color=branch_color
                       )
        else:
            if exts and path.suffix not in exts:
                    continue
            item = path.name if show_exts else path.with_suffix('').name
            if with_rel_stems:
                item = f'{item}  [dim]->  {root.name}/{item}[/]'
            tree.add(item)

    return tree


def create_dir_tree(root_dir: str, exts=None) -> None:
    """
    Print a tree for `root_dir`.

    Parameters:
        root_dir:
            Path to directory from which to build the directory tree.
        extensions:
            List of file extensions to include (filter). If None provided,
            all files are shown. E.g. ['.yaml'].
    Returns:
        Tree of the directory with formatting
    """
    root_path = Path(root_dir)
    if not root_path.is_dir():
        raise ValueError("root_dir must be a folder")
    tree = Tree(f"[bold]{root_path.resolve().name}[/]")
    ls_tree = build_tree(root_path, tree, exts=['.yaml'],
                         show_exts=False, with_rel_stems=True,
                         branch_color=_PANEL_COLUMN_COLOURS[0]
                         )
    return ls_tree


def _get_config_block_from_imsi_config(imsi_config_path, internal_config_map):
    # get the config from the imsi-config folder; including nested blocks
    config_name = internal_config_map[0] if isinstance(internal_config_map, list) else internal_config_map
    blocks_db = database_factory(imsi_config_path / config_name)
    data = blocks_db.get_config(config_name)

    # handle special case for nested mapping
    if isinstance(internal_config_map, list):
        data = nested_get(data, internal_config_map[1:])

    return data

def show_list_choices_combinations(
    repo_paths: Iterable[Path],
    repo_sources: Iterable[str],
    relative_imsi_config_path: Path,
    filter_model: str = None,
    filter_experiment: str = None,
    plain: bool = True,
):
    """Render a console of grouped choices. model/experiments only."""

    df = gather_choices_df(
        repo_paths=repo_paths,
        repo_sources=repo_sources,
        relative_imsi_config_path=relative_imsi_config_path,
        filter_model=filter_model,
        filter_experiment=filter_experiment
    )
    render_choices_table(df, plain=plain)


def show_list_choices(
        component: str,
        block: str | list,
        repo_paths: Iterable[Path],
        repo_sources: Iterable[str],
        relative_imsi_config_path: Path,
        plain: bool = True
):
    """Render a console with a simple list of contents"""

    # gather options
    all_repo_options = []
    for repo, source in zip(repo_paths, repo_sources):
        imsi_config_path = repo / relative_imsi_config_path
        all_repo_options.append({
            'path': str(repo),
            'source': source,
            'options': list(_get_config_block_from_imsi_config(imsi_config_path, block).keys())
            })

    # display options
    if plain:
        print(_fill_plain_template(all_repo_options))
    else:
        console = Console()
        for info in all_repo_options:
            data_list = f'[bold]{component}[/]\n  ' + '\n  '.join(sorted(info['options']))
            panel_title = _create_panel_repo_title(info['path'], info['source'])
            console.print(_create_panel(data_list, title=panel_title))


def show_list_dirs(
        directory: str | Path,
        repo_paths: Iterable[Path],
        repo_sources: Iterable[str],
        relative_imsi_config_path: Path,
        plain: bool = True,
        ):
    """Render a console representing a dir tree"""

    if plain:
        all_repo_options = []
        for repo, source in zip(repo_paths, repo_sources):
            directory_path = repo / relative_imsi_config_path / directory
            rel_paths = list_dir_contents(directory_path, extensions=['.yaml'], keep_folders=False)
            all_repo_options.append({
                'path': str(repo),
                'source': source,
                'options': [str(p.relative_to(directory_path).with_suffix('')) for p in rel_paths]
            })
        print(_fill_plain_template(all_repo_options))
    else:
        console = Console()
        for repo, source in zip(repo_paths, repo_sources):
            directory_path = repo / relative_imsi_config_path / directory
            panel_title = _create_panel_repo_title(repo, source)
            if directory_path.exists():
                tree = create_dir_tree(directory_path)
                console.print(_create_panel(tree, title=panel_title))
            else:
                console.print(
                    _create_panel(f"[red]No directory found for {directory}.[/red]",
                                title=panel_title)
                    )
