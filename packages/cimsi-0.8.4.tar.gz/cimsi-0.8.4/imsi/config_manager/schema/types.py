from typing import Annotated
from pydantic.functional_validators import BeforeValidator
from imsi.tools.time_manager.cftime_utils import get_date_type, parse_time
from re import match

def coerce_date(date: str | int) -> str:
    calendar = 'noleap'    # assume (FUTURE)

    # if the user only specifies the year, it can be read in as an int, so convert to string
    if isinstance(date, int):
        date = f'{date:04}'

    # ignore the case that this is a config-level var replacement
    if match('^{{.*}}$', date):
        return date

    # calendar object is needed for parse_time
    calendar_obj = get_date_type(calendar)
    try:
        parse_time(date, calendar_obj)
    except ValueError:
        raise ValueError(f"Invalid date format for '{date}'. Date must be specified in ISO-8601 compliant format.")

    # return the original string
    return date

# Custom type that enforces the date is iso8601-compliant
DateCoerce = Annotated[
    str, BeforeValidator(lambda v: coerce_date(v))
]
