from typing import Optional, Union, List

from pydantic import Field, BaseModel, ConfigDict, model_validator

from imsi.config_manager.schema.types import DateCoerce


class Experiment(BaseModel):
    """Experiment configuration Pydantic model"""

    model_config = ConfigDict(extra='allow')
    name: Optional[str] = Field(None, description='Experiment name')
    experiment_id: str
    subexperiment_id: str
    activity_id: str
    mip_era: str
    model_type: str
    start_time: DateCoerce = Field(
        ..., description='Start time of the experiment'
    )
    end_time: DateCoerce = Field(
        ..., description='End time of the experiment'
    )
    parent_runid: str
    parent_branch_time: str
    inherits_from: Optional[Union[List[str], str]] = None
    supported_models: List[str]
    flow: Optional[str] = None # overrides flow specified in model

    def validate_model_name(self, model_name: str):
        if model_name not in self.supported_models:
            raise ValueError(
                f"For the selected experiment '{self.name}', the selected model '{model_name}' "
                f'is not supported. Valid models for this experiment are: {self.supported_models}.'
            )

    @model_validator(mode='after')
    def validate_model_times(self):
        # lexicographic comparison works for times as strings
        if self.start_time > self.end_time:
            raise ValueError('ERROR: start_time must be before or the same as end_time')
        return self
