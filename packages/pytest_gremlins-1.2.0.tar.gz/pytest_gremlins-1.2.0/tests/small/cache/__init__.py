"""Tests for the cache module."""
