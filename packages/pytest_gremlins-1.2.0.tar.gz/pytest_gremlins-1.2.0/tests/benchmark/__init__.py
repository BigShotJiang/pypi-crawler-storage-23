"""Tests for the benchmark infrastructure."""
