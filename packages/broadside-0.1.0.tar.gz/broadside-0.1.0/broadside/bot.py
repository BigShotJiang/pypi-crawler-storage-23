
from .gateway import Gateway
from .context import Context

class Bot:
    def __init__(self, ws_url, username, prefix="!"):
        self.ws_url = ws_url
        self.username = username
        self.prefix = prefix

        self.commands = {}
        self.events = {}

        self.gateway = Gateway(self)

    def command(self, name=None):
        def decorator(func):
            cmd_name = name or func.__name__
            self.commands[cmd_name] = func
            return func
        return decorator

    def event(self, func):
        self.events[func.__name__] = func
        return func

    async def send(self, content):
        await self.gateway.send({
            "username": self.username,
            "content": content
        })

    async def _dispatch(self, event, *args):
        if event in self.events:
            await self.events[event](*args)

    async def _handle_message(self, message):
        if message.get("username") == self.username:
            return

        await self._dispatch("on_message", message)

        content = message.get("content", "")
        if not content.startswith(self.prefix):
            return

        parts = content[len(self.prefix):].split()
        if not parts:
            return

        name = parts[0]
        args = parts[1:]

        if name in self.commands:
            ctx = Context(self, message)
            await self.commands[name](ctx, *args)

    async def run(self):
        await self.gateway.connect()