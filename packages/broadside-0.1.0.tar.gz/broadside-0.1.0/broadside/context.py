class Context:
    def __init__(self, bot, message):
        self.bot = bot
        self.message = message