import websockets
import json
import asyncio
class Gateway:
    def __init__(self, bot):
        self.bot = bot
        self.ws = None

    async def connect(self):
        print(f"connecting to {self.bot.ws_url} with name {self.bot.username}")
        
        try:
            self.ws = await websockets.connect(self.bot.ws_url)
            
            await self.bot._dispatch("on_connect")
            
            asyncio.create_task(self._heartbeat())
            await self.listen()
        except Exception as e:
            print(f"failed to connect: {e}")

    async def _heartbeat(self):
        while True:
            try:
                await asyncio.sleep(20)
                await self.ws.send(json.dumps({"_ping": 1}))
            except Exception as e:
                print(f"heartbeat failed: {e}")
                break

    async def listen(self):
        async for raw in self.ws:
            data = json.loads(raw)
            await self.bot._handle_message(data)

    async def send(self, payload):
        await self.ws.send(json.dumps(payload))