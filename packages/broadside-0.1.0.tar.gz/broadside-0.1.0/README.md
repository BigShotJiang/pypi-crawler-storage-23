# broadside.py

python bot