"""Platform-specific handlers for TLS library classification and extraction."""
