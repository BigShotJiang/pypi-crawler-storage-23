"""TLSLibHunter package metadata."""

__version__ = "0.1.4"
__author__ = "Daniel Baier"
__license__ = "MIT"
__description__ = "Identify and extract TLS/SSL libraries from running processes"
