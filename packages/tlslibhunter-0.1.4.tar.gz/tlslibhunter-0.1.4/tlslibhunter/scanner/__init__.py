"""Scanner module for TLS library detection."""
