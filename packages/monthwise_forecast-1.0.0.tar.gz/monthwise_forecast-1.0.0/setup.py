from setuptools import setup, find_packages

setup(
    name="monthwise-forecast",
    version="1.0.0",
    description="A practical, transparent demand forecasting method that treats each calendar month independently.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Priyankan",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20",
        "pandas>=1.3",
        "scipy>=1.7",
        "python-dateutil>=2.8",
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
)