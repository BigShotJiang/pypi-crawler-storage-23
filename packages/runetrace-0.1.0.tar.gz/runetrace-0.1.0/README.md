Runetrace

Runetrace is a serverless LLM observability SDK.

Track token usage, latency, and behavior with a single decorator.
