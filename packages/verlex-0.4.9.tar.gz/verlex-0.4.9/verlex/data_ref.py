"""
Data offloading and pre-warming helpers for the Verlex execution pipeline.

These utilities are shared by both the manual ``GateWay.run()`` path and the
automatic ``overflow()`` path so that every cloud execution benefits from:

* **Smart data offloading** — arguments larger than ``SIZE_THRESHOLD`` are
  uploaded to the backend's ephemeral object store *before* cloudpickle
  serialisation.  A self-contained resolver wrapper downloads them on the
  cloud side.
* **Predictive pre-warming** — AST analysis of the caller's source predicts
  the resource tier so a VM can start booting immediately.
* **Flush lifecycle** — uploaded data is cleaned up after execution completes
  and again when the ``GateWay`` context exits.
"""

from __future__ import annotations

import ast
import functools
import hashlib
import logging
import os
import sys
import threading
from pathlib import Path
from typing import Any, Callable, Optional

logger = logging.getLogger("verlex.data_ref")


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Arguments larger than this are uploaded to object storage rather than
# being inlined in the cloudpickle payload sent via the job submission.
SIZE_THRESHOLD: int = 50 * 1024 * 1024  # 50 MB

# Heavy-import sets used by the pre-warming predictor to estimate
# what resource tier the user's script will need.
GPU_IMPORTS: frozenset[str] = frozenset({
    "torch", "tensorflow", "tf", "jax", "cupy", "cuml",
    "cudf", "pycuda", "triton", "torchaudio", "torchvision",
    "transformers", "diffusers", "accelerate", "bitsandbytes",
    "xformers", "flash_attn", "vllm", "deepspeed",
})

MEDIUM_IMPORTS: frozenset[str] = frozenset({
    "numpy", "pandas", "scipy", "sklearn", "scikit_learn",
    "xgboost", "lightgbm", "catboost", "polars", "dask",
    "ray", "modin", "vaex", "pyarrow", "h5py", "zarr",
    "networkx", "statsmodels", "sympy",
})


# ---------------------------------------------------------------------------
# Size estimation
# ---------------------------------------------------------------------------


def estimate_arg_size(obj: Any) -> int:
    """Return a fast byte-size estimate for *obj*.

    Uses type-specific introspection where available so that we never
    have to serialize the object just to decide whether to offload it.
    """
    try:
        # _RemoteFile (local file wrapped for transfer)
        if hasattr(obj, "_data") and hasattr(obj, "_filename"):
            return len(obj._data)

        # numpy ndarray
        if hasattr(obj, "nbytes"):
            return int(obj.nbytes)

        # pandas DataFrame / Series
        if hasattr(obj, "memory_usage"):
            usage = obj.memory_usage(deep=True)
            return int(usage.sum() if hasattr(usage, "sum") else usage)

        # raw bytes / bytearray
        if isinstance(obj, (bytes, bytearray)):
            return len(obj)

        # strings
        if isinstance(obj, str):
            return len(obj)

        # lists / dicts / tuples — recurse one level for a rough count
        if isinstance(obj, (list, tuple)):
            total = sys.getsizeof(obj)
            for item in obj:
                total += _shallow_size(item)
            return total

        if isinstance(obj, dict):
            total = sys.getsizeof(obj)
            for k, v in obj.items():
                total += _shallow_size(k) + _shallow_size(v)
            return total

        return sys.getsizeof(obj)
    except Exception:
        return 0


def _shallow_size(obj: Any) -> int:
    """One-level size helper (no recursion to avoid blowup)."""
    if hasattr(obj, "nbytes"):
        return int(obj.nbytes)
    if isinstance(obj, (bytes, bytearray, str)):
        return len(obj)
    return sys.getsizeof(obj)


# ---------------------------------------------------------------------------
# Predictive pre-warming
# ---------------------------------------------------------------------------


def predict_resource_tier(source_file: str) -> str:
    """Parse *source_file* with ``ast`` and return a resource tier string.

    The tier is determined by which heavy libraries the script imports:

    * ``"gpu"``    — torch, tensorflow, jax, …
    * ``"medium"`` — numpy / pandas / scipy family
    * ``"small"``  — everything else
    """
    try:
        with open(source_file, "r", encoding="utf-8", errors="replace") as fh:
            tree = ast.parse(fh.read(), filename=source_file)
    except Exception:
        return "medium"  # safe default

    found: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                found.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom) and node.module:
            found.add(node.module.split(".")[0])

    if found & GPU_IMPORTS:
        return "gpu"
    if found & MEDIUM_IMPORTS:
        return "medium"
    return "small"


def fire_pre_warm(
    api_url: str,
    api_key: str,
    tier: str,
    result_holder: dict[str, Any],
) -> None:
    """Background thread target: POST ``/v1/pre-warm`` and store the session id."""
    try:
        import httpx

        resp = httpx.post(
            f"{api_url}/v1/pre-warm",
            json={"tier": tier},
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0,
        )
        if resp.status_code == 200:
            data = resp.json()
            result_holder["warm_session_id"] = data.get("warm_session_id")
            result_holder["status"] = data.get("status", "warming")
            logger.info(
                "Pre-warm request sent  tier=%s  session=%s",
                tier,
                result_holder.get("warm_session_id", "?"),
            )
        else:
            logger.warning("Pre-warm request failed: %d %s", resp.status_code, resp.text[:200])
    except Exception as exc:
        logger.warning("Pre-warm request error: %s", exc)


# ---------------------------------------------------------------------------
# Data offloading
# ---------------------------------------------------------------------------


class DataOffloader:
    """Manages uploading large arguments and flushing them after execution.

    This class is instantiated once per ``GateWay`` session and shared by
    all execution paths (``run()``, ``run_async()``, ``overflow()``).
    """

    def __init__(self, api_url: str, api_key: str) -> None:
        self.api_url = api_url
        self.api_key = api_key
        self._pending_keys: list[str] = []
        self._keys_lock = threading.Lock()
        self._upload_cache: dict[str, str] = {}

    def offload_large_args(
        self,
        func: Callable[..., Any],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> tuple[Callable[..., Any], tuple[Any, ...], dict[str, Any], list[str]]:
        """Upload large arguments and return a resolver wrapper.

        Returns ``(cloud_func, modified_args, modified_kwargs, data_keys)``
        where *cloud_func* downloads offloaded data before calling *func*.
        """
        arg_refs: dict[int, str] = {}
        kwarg_refs: dict[str, str] = {}
        data_keys: list[str] = []

        modified_args = list(args)
        modified_kwargs = dict(kwargs)

        for i, arg in enumerate(args):
            if estimate_arg_size(arg) < SIZE_THRESHOLD:
                continue
            data_key = self._upload(arg)
            if data_key is None:
                continue
            arg_refs[i] = data_key
            data_keys.append(data_key)
            modified_args[i] = None

        for key, val in kwargs.items():
            if estimate_arg_size(val) < SIZE_THRESHOLD:
                continue
            data_key = self._upload(val)
            if data_key is None:
                continue
            kwarg_refs[key] = data_key
            data_keys.append(data_key)
            modified_kwargs[key] = None

        if not data_keys:
            return func, args, kwargs, []

        logger.info("Offloaded %d arg(s) to backend data store", len(data_keys))

        # Build a self-contained wrapper that cloudpickle will serialize
        # and send to the cloud VM.  It downloads offloaded data via HTTP
        # (the UUID key *is* the auth — same as a pre-signed URL).
        _original_func = func
        _arg_refs = dict(arg_refs)
        _kwarg_refs = dict(kwarg_refs)
        _api_url = self.api_url

        @functools.wraps(func)
        def _resolving_wrapper(*call_args: Any, **call_kwargs: Any) -> Any:
            import cloudpickle as _cp
            import httpx as _hx

            resolved_args = list(call_args)
            resolved_kwargs = dict(call_kwargs)

            for idx, dk in _arg_refs.items():
                resp = _hx.get(f"{_api_url}/v1/data/{dk}", timeout=600.0)
                resp.raise_for_status()
                resolved_args[idx] = _cp.loads(resp.content)

            for kw, dk in _kwarg_refs.items():
                resp = _hx.get(f"{_api_url}/v1/data/{dk}", timeout=600.0)
                resp.raise_for_status()
                resolved_kwargs[kw] = _cp.loads(resp.content)

            return _original_func(*resolved_args, **resolved_kwargs)

        return _resolving_wrapper, tuple(modified_args), modified_kwargs, data_keys

    def _upload(self, arg: Any) -> Optional[str]:
        """Serialise *arg* and upload to ``/v1/data/upload``.

        Returns the ``data_key`` on success, ``None`` on failure.
        """
        try:
            import cloudpickle

            serialized = cloudpickle.dumps(arg)
        except Exception as exc:
            logger.warning("Cannot serialise arg for offload: %s", exc)
            return None

        content_hash = hashlib.sha256(serialized).hexdigest()
        cached_key = self._upload_cache.get(content_hash)
        if cached_key is not None:
            logger.debug("Upload cache hit hash=%s → key=%s", content_hash[:12], cached_key)
            return cached_key

        try:
            import httpx

            resp = httpx.post(
                f"{self.api_url}/v1/data/upload",
                content=serialized,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/octet-stream",
                },
                timeout=300.0,
            )
            if resp.status_code != 200:
                logger.warning("Data upload failed: %d %s", resp.status_code, resp.text[:200])
                return None

            data_key = resp.json().get("data_key")
            if data_key:
                self._upload_cache[content_hash] = data_key
                with self._keys_lock:
                    self._pending_keys.append(data_key)
            return data_key

        except Exception as exc:
            logger.warning("Data upload error: %s", exc)
            return None

    def flush_keys(self, keys: list[str]) -> None:
        """DELETE each key from the backend data store (best-effort)."""
        if not keys:
            return
        try:
            import httpx
        except ImportError:
            return

        for dk in keys:
            try:
                httpx.delete(
                    f"{self.api_url}/v1/data/{dk}",
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    timeout=10.0,
                )
            except Exception:
                pass

        with self._keys_lock:
            remaining = set(self._pending_keys) - set(keys)
            self._pending_keys = list(remaining)

        logger.debug("Flushed %d data key(s)", len(keys))

    def flush_all(self) -> None:
        """Flush every pending data key."""
        with self._keys_lock:
            keys = list(self._pending_keys)
        if keys:
            logger.info("Flushing %d remaining data key(s)…", len(keys))
            self.flush_keys(keys)
            self._upload_cache.clear()


# ---------------------------------------------------------------------------
# Local file → remote file transfer
# ---------------------------------------------------------------------------


class _RemoteFile(os.PathLike):
    """Carries local file bytes so they're available on the remote VM.

    On the client side this stores the raw bytes.  After cloudpickle
    deserialises it on the remote VM, any path-like access (``open()``,
    ``Path()``, ``str()``) materialises the bytes to a temp file.
    """

    def __init__(self, data: bytes, filename: str) -> None:
        self._data = data
        self._filename = filename
        self._path: str | None = None

    # -- materialise on first access ------------------------------------------

    def _materialize(self) -> str:
        if self._path is None:
            import tempfile

            tmpdir = tempfile.mkdtemp(prefix="verlex_files_")
            self._path = os.path.join(tmpdir, self._filename)
            with open(self._path, "wb") as fh:
                fh.write(self._data)
        return self._path

    def __fspath__(self) -> str:
        return self._materialize()

    def __str__(self) -> str:
        return self._materialize()

    def __repr__(self) -> str:
        return f"RemoteFile({self._filename!r}, {len(self._data)} bytes)"


class _RemoteDir(os.PathLike):
    """Carries a local directory (zipped) so it's available on the remote VM.

    On the client side this zips all files in the directory into bytes.
    After cloudpickle deserialises it on the remote VM, any path-like
    access materialises the directory by extracting the zip to a temp path.
    """

    def __init__(self, data: bytes, dirname: str, file_count: int) -> None:
        self._data = data
        self._dirname = dirname
        self._file_count = file_count
        self._path: str | None = None

    def _materialize(self) -> str:
        if self._path is None:
            import tempfile
            import zipfile
            import io

            tmpdir = tempfile.mkdtemp(prefix="verlex_dirs_")
            self._path = os.path.join(tmpdir, self._dirname)
            with zipfile.ZipFile(io.BytesIO(self._data), "r") as zf:
                zf.extractall(self._path)
        return self._path

    def __fspath__(self) -> str:
        return self._materialize()

    def __str__(self) -> str:
        return self._materialize()

    def __repr__(self) -> str:
        return f"RemoteDir({self._dirname!r}, {self._file_count} files, {len(self._data)} bytes)"


def _zip_directory(dir_path: Path) -> tuple[bytes, int]:
    """Zip all files in a directory into bytes. Returns (zip_bytes, file_count)."""
    import zipfile
    import io

    buf = io.BytesIO()
    file_count = 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _dirs, files in os.walk(dir_path):
            for fname in files:
                full = os.path.join(root, fname)
                arcname = os.path.relpath(full, dir_path)
                zf.write(full, arcname)
                file_count += 1
    return buf.getvalue(), file_count


def _is_local_file(obj: Any) -> bool:
    """Return True if *obj* is a Path or string pointing to an existing file."""
    if isinstance(obj, Path):
        return obj.is_file()
    if isinstance(obj, str) and len(obj) < 4096:
        # Skip URLs and overly-long strings
        if obj.startswith(("http://", "https://", "s3://", "gs://")):
            return False
        return os.path.isfile(obj)
    return False


def _is_local_dir(obj: Any) -> bool:
    """Return True if *obj* is a Path or string pointing to an existing directory."""
    if isinstance(obj, Path):
        return obj.is_dir()
    if isinstance(obj, str) and len(obj) < 4096:
        if obj.startswith(("http://", "https://", "s3://", "gs://")):
            return False
        return os.path.isdir(obj)
    return False


def _resolve_one(obj: Any) -> Any:
    """Replace a local file or directory path with a _RemoteFile/_RemoteDir wrapper."""
    # Check file first
    if isinstance(obj, Path) and obj.is_file():
        return _RemoteFile(obj.read_bytes(), obj.name)
    if isinstance(obj, str) and os.path.isfile(obj):
        return _RemoteFile(
            Path(obj).read_bytes(),
            os.path.basename(obj),
        )
    # Check directory
    if isinstance(obj, Path) and obj.is_dir():
        zip_bytes, file_count = _zip_directory(obj)
        return _RemoteDir(zip_bytes, obj.name, file_count)
    if isinstance(obj, str) and os.path.isdir(obj):
        zip_bytes, file_count = _zip_directory(Path(obj))
        return _RemoteDir(zip_bytes, os.path.basename(obj.rstrip("/\\")), file_count)
    return obj


def resolve_file_args(
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> tuple[tuple[Any, ...], dict[str, Any], int]:
    """Walk *args* / *kwargs* and replace local file/dir paths with wrappers.

    Recurses one level into lists, tuples, and dicts so that
    ``[Path("a.jpg"), Path("b.jpg")]`` is handled.

    Returns ``(new_args, new_kwargs, files_found)``.
    """
    files_found = 0

    def _walk(obj: Any, depth: int = 0) -> Any:
        nonlocal files_found
        if _is_local_file(obj):
            files_found += 1
            return _resolve_one(obj)
        if _is_local_dir(obj):
            files_found += 1
            return _resolve_one(obj)
        # Recurse one level into containers
        if depth > 0:
            return obj
        if isinstance(obj, (list, tuple)):
            resolved = [_walk(item, depth + 1) for item in obj]
            return type(obj)(resolved)
        if isinstance(obj, dict):
            return {k: _walk(v, depth + 1) for k, v in obj.items()}
        return obj

    new_args = tuple(_walk(a) for a in args)
    new_kwargs = {k: _walk(v) for k, v in kwargs.items()}
    return new_args, new_kwargs, files_found
