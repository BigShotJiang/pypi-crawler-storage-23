"""
Verlex Client - Thin HTTP client for Verlex cloud execution.

All logic runs on the Verlex backend. This client just serializes
functions and sends them to the API.

Every execution path (``run()``, ``run_async()``, ``overflow()``)
goes through the same pipeline that automatically:

* **Offloads large arguments** (>50 MB) to an ephemeral data store so
  cloudpickle payloads stay small.
* **Pre-warms cloud VMs** when a tier hint is provided (or inferred
  from the caller's source code).
* **Flushes uploaded data** after each job completes and again when the
  ``GateWay`` context exits.
"""

from __future__ import annotations

import base64
import inspect
import json
import os
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, TypeVar

import cloudpickle
import httpx

from verlex.data_ref import DataOffloader, fire_pre_warm, predict_resource_tier, resolve_file_args
from verlex.errors import (
    ExecutionError,
    InsufficientCreditsError,
    InvalidAPIKeyError,
    JobFailedError,
    JobTimeoutError,
    NetworkError,
    NotAuthenticatedError,
    RateLimitError,
    SerializationError,
)

T = TypeVar("T")

# Default API URL
DEFAULT_API_URL = "https://gateway-production-8435.up.railway.app"

# Global session state
_current_session: AuthSession | None = None


# ---------------------------------------------------------------------------
# Progress bar (rich when available, plain-text fallback)
# ---------------------------------------------------------------------------

# Map job status → (progress %, message) for when backend doesn't send progress
_STATUS_PROGRESS: dict[str, tuple[float, str]] = {
    "pending": (0.05, "Pending..."),
    "queued": (0.10, "Queued..."),
    "provisioning": (0.20, "Provisioning VM..."),
    "running": (0.60, "Running function..."),
}


class _ProgressBar:
    """Terminal progress bar — uses rich if available, plain text fallback.

    Includes client-side interpolation: when the backend progress stalls
    (e.g. during VM boot), the bar creeps forward slowly so the user sees
    continuous movement.  It never exceeds 89% on its own — only the
    backend can push it to 90%+ and 100%.
    """

    _INTERPOLATION_CAP = 0.89  # never interpolate past this

    def __init__(self, verbose: bool) -> None:
        self._verbose = verbose
        self._rich_progress: Any = None
        self._task: Any = None
        self._last_pct = -1
        self._backend_progress = 0.0  # last value from backend
        self._display_progress = 0.0  # what we're showing (may be interpolated)
        self._last_backend_time = 0.0  # when backend last changed
        if not verbose:
            return
        try:
            from rich.progress import (
                BarColumn,
                Progress,
                TaskProgressColumn,
                TextColumn,
                TimeElapsedColumn,
            )

            self._rich_progress = Progress(
                TextColumn("  "),
                BarColumn(bar_width=30),
                TaskProgressColumn(),
                TextColumn("{task.description}"),
                TimeElapsedColumn(),
                transient=True,
            )
        except ImportError:
            pass

    def start(self) -> None:
        self._last_backend_time = time.time()
        if self._rich_progress:
            self._rich_progress.start()
            self._task = self._rich_progress.add_task("Submitting...", total=100)

    def update(self, progress: float | None, message: str | None) -> None:
        if not self._verbose:
            return
        now = time.time()
        backend_val = progress if progress is not None else self._backend_progress

        # Backend sent a new (higher) value — snap to it
        if backend_val > self._backend_progress:
            self._backend_progress = backend_val
            self._display_progress = backend_val
            self._last_backend_time = now
        else:
            # No new backend value — interpolate slowly
            # Creep ~1% every 2 seconds, capped at _INTERPOLATION_CAP
            elapsed = now - self._last_backend_time
            creep = elapsed * 0.005  # 0.5% per second
            interpolated = self._backend_progress + creep
            cap = min(self._INTERPOLATION_CAP, self._backend_progress + 0.15)
            self._display_progress = min(interpolated, cap)

        pct = int(self._display_progress * 100)
        if pct == self._last_pct:
            return
        self._last_pct = pct
        desc = message or ""
        if self._rich_progress and self._task is not None:
            self._rich_progress.update(self._task, completed=pct, description=desc)
        else:
            bar_len = pct // 4
            bar = "\u2588" * bar_len + "\u2591" * (25 - bar_len)
            print(f"\r   [{bar}] {pct:3d}%  {desc:<30s}", end="", flush=True)

    def pause(self) -> None:
        """Temporarily hide progress bar so print output appears cleanly."""
        if self._rich_progress:
            self._rich_progress.stop()
        elif self._verbose and self._last_pct >= 0:
            print("\r" + " " * 60 + "\r", end="", flush=True)

    def resume(self) -> None:
        """Re-show progress bar after a pause."""
        if self._rich_progress:
            self._rich_progress.start()
        elif self._verbose and self._last_pct >= 0:
            pct = self._last_pct
            bar_len = pct // 4
            bar = "\u2588" * bar_len + "\u2591" * (25 - bar_len)
            print(f"\r   [{bar}] {pct:3d}%  {'':30s}", end="", flush=True)

    def finish(self) -> None:
        if self._last_pct < 0:
            return  # never started or already finished
        self._last_pct = -1
        if self._rich_progress:
            if self._task is not None:
                self._rich_progress.update(self._task, completed=100, description="Done")
            self._rich_progress.stop()
        elif self._verbose:
            print()  # newline after the \r progress line


@dataclass
class AuthSession:
    """Authentication session state."""

    api_key: str
    user_id: str | None = None
    email: str | None = None
    tier: str = "free"
    fast: bool = False


@dataclass
class JobResult:
    """Result of a cloud execution."""

    value: Any
    job_id: str
    provider: str | None = None
    region: str | None = None
    instance_type: str | None = None
    execution_time_seconds: float = 0.0
    cost: float = 0.0

    def __repr__(self) -> str:
        return f"JobResult(value={self.value!r}, job_id='{self.job_id}', cost=${self.cost:.4f})"


class GateWay:
    """
    Verlex GateWay - Run your code in the cloud.

    Usage:
        >>> import verlex
        >>>
        >>> with verlex.GateWay(api_key="gw_xxx") as gw:
        ...     result = gw.run(my_function, arg1, arg2)
        ...     print(result)

    Pricing:
        fast=True:  Performance mode — immediate execution, premium pricing
        fast=False: Standard mode — up to 10 min wait, lower pricing
    """

    def __init__(
        self,
        api_key: str | None = None,
        fast: bool = False,
        api_url: str | None = None,
        timeout: int = 3600,
        verbose: bool = True,
    ):
        """
        Initialize GateWay client.

        Args:
            api_key: Your Verlex API key. If not provided, uses VERLEX_API_KEY env var.
            fast: True = immediate execution (Performance), False = standard pricing
            api_url: API URL (defaults to https://api.verlex.dev)
            timeout: Default job timeout in seconds
            verbose: Print status messages
        """
        self.api_key = api_key or os.getenv("VERLEX_API_KEY")
        self.fast = fast
        self.api_url = api_url or os.getenv("VERLEX_API_URL", DEFAULT_API_URL)
        self.default_timeout = timeout
        self.verbose = verbose

        self._client: httpx.Client | None = None
        self._session: AuthSession | None = None
        self._active = False
        self._jobs: list[str] = []
        self._jobs_lock = threading.Lock()

        # Data offloader (initialized in __enter__ once api_key is confirmed)
        self._offloader: DataOffloader | None = None

        # Pre-warming state
        self._warm_result: dict[str, Any] = {}
        self._warm_session_id: str | None = None

    def __enter__(self) -> GateWay:
        """Enter context - authenticate and prepare client."""
        if not self.api_key:
            raise NotAuthenticatedError(
                "No API key provided. Either pass api_key parameter or set VERLEX_API_KEY environment variable."
            )

        if self.verbose:
            print("Verlex - Initializing cloud execution...")

        # Create HTTP client
        self._client = httpx.Client(
            base_url=self.api_url,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(120.0, connect=30.0),
        )

        # Validate API key (retry on transient network errors / cold starts)
        max_retries = 3
        last_exc: Exception | None = None
        for attempt in range(max_retries):
            try:
                response = self._client.get("/v1/auth/validate")
                if response.status_code == 401:
                    self._client.close()
                    raise InvalidAPIKeyError("Invalid API key")
                elif response.status_code == 200:
                    data = response.json()
                    self._session = AuthSession(
                        api_key=self.api_key,
                        user_id=data.get("user_id"),
                        email=data.get("email"),
                        tier=data.get("tier", "free"),
                        fast=self.fast,
                    )
                    break
                else:
                    self._client.close()
                    raise NetworkError(
                        f"Unexpected response from Verlex API: {response.status_code} - {response.text}"
                    )
            except httpx.RequestError as e:
                last_exc = e
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                self._client.close()
                raise NetworkError(f"Failed to connect to Verlex API: {e}") from e
            except Exception:
                self._client.close()
                raise

        self._active = True
        self._offloader = DataOffloader(api_url=self.api_url, api_key=self.api_key)

        if self.verbose:
            mode = "performance" if self.fast else "standard"
            print(f"   Ready | Mode: {mode}")

        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        """Exit context - flush uploaded data and cleanup."""
        self._active = False

        # Flush any data that was uploaded but never cleaned up.
        if self._offloader:
            self._offloader.flush_all()
            self._offloader = None

        if self._client:
            self._client.close()
            self._client = None

        if self.verbose and self._jobs:
            print(f"\nVerlex session complete. Jobs: {len(self._jobs)}")

        return False

    def _ensure_active(self) -> None:
        """Ensure we're inside an active context."""
        if not self._active:
            raise RuntimeError(
                "GateWay must be used as a context manager:\n"
                "    with verlex.GateWay(api_key='...') as gw:\n"
                "        result = gw.run(my_function)"
            )

    def pre_warm(self, tier: str | None = None, source_file: str | None = None) -> None:
        """Start pre-warming a cloud VM in the background.

        Call this early (e.g. right after entering the context manager)
        so the VM is booting while your setup code runs.

        Args:
            tier: Explicit resource tier (``"small"``, ``"medium"``, ``"gpu"``).
                  If not provided, *source_file* is analysed to predict the tier.
            source_file: Path to the user's script.  If omitted, the caller's
                         file is used automatically.
        """
        self._ensure_active()
        if not self.api_key:
            return

        if tier is None:
            if source_file is None:
                frame = inspect.currentframe()
                caller = frame.f_back if frame else None
                source_file = caller.f_code.co_filename if caller else None
            if source_file:
                tier = predict_resource_tier(source_file)
            else:
                tier = "medium"

        t = threading.Thread(
            target=fire_pre_warm,
            args=(self.api_url, self.api_key, tier, self._warm_result),
            daemon=True,
            name="verlex-prewarm",
        )
        t.start()

    def run(
        self,
        func: Callable[..., T],
        *args,
        gpu: str | None = None,
        gpu_count: int = 1,
        cpu: int | None = None,
        memory: str | None = None,
        timeout: int | None = None,
        **kwargs,
    ) -> T:
        """
        Execute a function in the cloud and return the result.

        Large arguments (>50 MB) are automatically offloaded to a
        temporary data store before serialisation and flushed after the
        job completes.

        Args:
            func: The function to execute remotely
            *args: Arguments to pass to the function
            gpu: GPU type (e.g., "T4", "A100", "H100")
            gpu_count: Number of GPUs (default: 1)
            cpu: CPU cores (auto-detected if not specified)
            memory: Memory (e.g., "16GB", auto-detected if not specified)
            timeout: Timeout in seconds
            **kwargs: Keyword arguments to pass to the function

        Returns:
            The return value of the function
        """
        self._ensure_active()

        # 0. Resolve local file paths → _RemoteFile wrappers.
        #    This reads file bytes on the client so they travel with the payload.
        args, kwargs, n_files = resolve_file_args(args, kwargs)
        if n_files and self.verbose:
            print(f"   {n_files} local file(s) will be transferred to the cloud")

        # 1. Offload large arguments (if any).
        data_keys: list[str] = []
        if self._offloader:
            func, args, kwargs, data_keys = self._offloader.offload_large_args(
                func, args, kwargs,
            )

        # 2. Pick up warm session id (if pre_warm() was called earlier).
        warm_id = self._warm_result.get("warm_session_id") or self._warm_session_id
        if warm_id:
            self._warm_session_id = warm_id

        job_id = None
        try:
            # 3. Submit and wait.
            job_id = self._submit_job(func, args, kwargs, gpu, gpu_count, cpu, memory, timeout)
            result = self._wait_for_job(job_id, timeout or self.default_timeout)
        except KeyboardInterrupt:
            # Ctrl+C: cancel the remote job (retries if offline)
            if job_id:
                if self.verbose:
                    print("\nCancelling remote job...")
                cancelled = self._cancel_job_remote(job_id)
                if self.verbose:
                    if cancelled:
                        print("Job cancelled on server. VM will be terminated.")
                    else:
                        print(f"Could not cancel job on server. Cancel manually: job {job_id}")
            raise
        finally:
            # 4. Flush offloaded data regardless of success / failure.
            if data_keys and self._offloader:
                self._offloader.flush_keys(data_keys)

        return result

    def _submit_job(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        gpu: str | None = None,
        gpu_count: int = 1,
        cpu: int | None = None,
        memory: str | None = None,
        timeout: int | None = None,
    ) -> str:
        """
        Submit a job and return the job_id (internal method for AsyncJob).

        Returns:
            The job_id of the submitted job
        """
        # Serialize the function
        try:
            payload = cloudpickle.dumps((func, args, kwargs))
            payload_b64 = base64.b64encode(payload).decode("utf-8")
        except Exception as e:
            raise SerializationError(f"Failed to serialize function: {e}") from e

        # Extract source code on the client side (where the file exists)
        # so the server can pass it to the LLM analyzer for resource recommendations.
        import inspect
        import textwrap
        source_code: str | None = None
        try:
            source_code = textwrap.dedent(inspect.getsource(func))
        except (OSError, TypeError):
            pass  # Source unavailable (e.g. built-in or interactive)

        # Build request matching backend JobSubmission schema
        effective_timeout = timeout or self.default_timeout

        resources: dict[str, Any] = {}
        if gpu:
            resources["gpu"] = gpu
            resources["gpu_count"] = gpu_count
        if cpu:
            resources["cpu"] = cpu
        if memory:
            resources["memory"] = memory

        # Send client Python version so the server can match the container runtime
        import sys
        python_version = f"{sys.version_info.major}.{sys.version_info.minor}"

        request_data = {
            "function": {
                "payload": payload_b64,
                "type": "cloudpickle",
                "python_version": python_version,
                "source_code": source_code,
            },
            "resources": resources,
            "estimate": {
                "estimated_duration_seconds": min(effective_timeout, 300),
            },
            "fast": self.fast,
        }

        # Attach warm session if overflow pre-warming set one
        warm_id = getattr(self, "_warm_session_id", None)
        if warm_id:
            request_data["warm_session_id"] = warm_id

        # Submit job
        try:
            response = self._client.post(
                "/v1/jobs/submit",
                json=request_data,
                timeout=60.0,  # Longer timeout for job submission
            )
        except httpx.RequestError as e:
            raise NetworkError(f"Failed to submit job: {e}") from e

        if response.status_code == 401:
            raise InvalidAPIKeyError("Invalid API key")
        elif response.status_code == 402:
            data = response.json()
            raise InsufficientCreditsError(
                required=data.get("required", 0),
                available=data.get("available", 0),
            )
        elif response.status_code == 429:
            raise RateLimitError(retry_after=int(response.headers.get("Retry-After", 60)))
        elif response.status_code != 200:
            raise ExecutionError(f"Job submission failed: {response.text}")

        data = response.json()
        job_id = data.get("job_id")

        # Validate job_id is present to prevent None-related errors
        if not job_id:
            raise ExecutionError("API response missing job_id")

        # Thread-safe append
        with self._jobs_lock:
            self._jobs.append(job_id)

        return job_id

    def _wait_for_job(self, job_id: str, timeout: int) -> Any:
        """Poll for job completion and return result."""
        start_time = time.time()
        poll_interval = 0.5
        consecutive_errors = 0
        max_consecutive_errors = 5

        bar = _ProgressBar(self.verbose)
        bar.start()

        # Output streaming: a fast background thread polls output every 0.5s
        # independently of the (slower) status polling loop.
        output_thread: threading.Thread | None = None
        output_stop = threading.Event()

        try:
            while True:
                elapsed = time.time() - start_time
                if elapsed > timeout:
                    raise JobTimeoutError(job_id, timeout)

                try:
                    response = self._client.get(f"/v1/jobs/{job_id}")
                    consecutive_errors = 0  # Reset on success
                except httpx.RequestError as e:
                    consecutive_errors += 1
                    if consecutive_errors >= max_consecutive_errors:
                        raise NetworkError(f"Failed to check job status after {max_consecutive_errors} retries: {e}") from e
                    time.sleep(min(poll_interval * 2, 10.0))
                    continue

                if response.status_code == 429:
                    retry_after = 1
                    try:
                        retry_after = int(response.json().get("retry_after", 1))
                    except Exception:
                        pass
                    time.sleep(max(retry_after, 1))
                    poll_interval = min(poll_interval * 2, 5.0)
                    continue

                if response.status_code != 200:
                    raise ExecutionError(f"Failed to get job status: {response.text}")

                data = response.json()
                status = data.get("status")

                # Update progress bar
                progress = data.get("progress")
                progress_message = data.get("progress_message")
                if progress is None and status in _STATUS_PROGRESS:
                    progress, progress_message = _STATUS_PROGRESS[status]
                bar.update(progress, progress_message)

                # Start fast output polling thread once job is running
                if self.verbose and output_thread is None and status in ("running", "completed", "failed"):
                    output_thread = threading.Thread(
                        target=self._output_poll_loop,
                        args=(job_id, bar, output_stop),
                        daemon=True,
                    )
                    output_thread.start()

                if status == "completed":
                    # Signal output thread to do one final drain, then stop
                    output_stop.set()
                    if output_thread and output_thread.is_alive():
                        output_thread.join(timeout=5.0)

                    bar.update(1.0, "Done")
                    bar.finish()

                    result_b64 = data.get("result")
                    if result_b64 is None:
                        try:
                            result_response = self._client.get(f"/v1/jobs/{job_id}/result")
                        except httpx.RequestError as e:
                            raise NetworkError(f"Failed to fetch job result: {e}") from e
                        if result_response.status_code != 200:
                            raise ExecutionError(f"Failed to get result: {result_response.text}")
                        result_b64 = result_response.json().get("result")

                    if result_b64:
                        try:
                            result_bytes = base64.b64decode(result_b64)
                            return cloudpickle.loads(result_bytes)
                        except Exception as e:
                            raise SerializationError(f"Failed to deserialize result: {e}") from e
                    return None

                elif status == "failed":
                    output_stop.set()
                    if output_thread and output_thread.is_alive():
                        output_thread.join(timeout=3.0)
                    bar.finish()
                    error_msg = data.get("error", "Unknown error")
                    logs = data.get("logs", "")
                    raise JobFailedError(job_id, error_msg, logs)

                elif status in ("pending", "queued", "provisioning", "running"):
                    time.sleep(poll_interval)
                    # Grow interval slowly for status checks (output has its own fast loop)
                    poll_interval = min(poll_interval * 1.1, 3.0)
                else:
                    raise ExecutionError(f"Unknown job status: {status}")
        except BaseException:
            output_stop.set()
            if output_thread and output_thread.is_alive():
                output_thread.join(timeout=1.0)
            bar.finish()
            raise

    def _output_poll_loop(self, job_id: str, bar: _ProgressBar, stop: threading.Event):
        """Background thread: fast-poll output endpoint and print lines immediately."""
        offset = 0
        while not stop.is_set():
            offset = self._poll_output(job_id, offset, bar)
            # Wait 0.5s, but check stop event every 100ms for fast shutdown
            for _ in range(5):
                if stop.is_set():
                    break
                time.sleep(0.1)
        # Final drain — pick up any lines written between last poll and stop signal
        self._poll_output(job_id, offset, bar)

    def _poll_output(self, job_id: str, offset: int, bar: _ProgressBar) -> int:
        """Fetch new output lines and print user output to the terminal.

        Returns the updated offset for the next poll.
        """
        try:
            resp = self._client.get(
                f"/v1/jobs/{job_id}/output",
                params={"offset": offset},
                timeout=5.0,
            )
            if resp.status_code != 200:
                return offset
            out = resp.json()
            entries = out.get("entries", [])
            for entry in entries:
                text = entry.get("text", "")
                if not text:
                    continue
                # Only show user output lines (prefixed [Output] by backend)
                if text.startswith("[Output] "):
                    bar.pause()
                    print(text[9:], end="")  # strip prefix, keep original newline
                    bar.resume()
            return out.get("current_index", offset)
        except Exception:
            return offset

    def _cancel_job_remote(self, job_id: str, max_attempts: int = 10) -> bool:
        """Send cancel request to server, retrying if offline.

        If the network is down (user pressed Ctrl+C while offline), this
        retries every 2 seconds until the cancel goes through or max_attempts
        is exhausted.  Returns True if the server acknowledged the cancel.
        """
        for attempt in range(1, max_attempts + 1):
            try:
                resp = self._client.post(
                    f"/v1/jobs/{job_id}/cancel",
                    timeout=10.0,
                )
                if resp.status_code == 200:
                    return True
                # Server responded but cancel failed — don't retry
                return False
            except (httpx.RequestError, httpx.TimeoutException):
                if attempt < max_attempts:
                    time.sleep(2.0)
                continue
        return False

    def run_async(self, func: Callable[..., T], *args, **kwargs) -> AsyncJob[T]:
        """
        Submit a function for async execution (non-blocking).

        Returns an AsyncJob that can be awaited or polled.

        Args:
            func: The function to execute
            *args: Arguments to pass to the function
            **kwargs: Keyword arguments

        Returns:
            AsyncJob object
        """
        self._ensure_active()
        return AsyncJob(self, func, args, kwargs)

    def analyze(self, func: Callable) -> dict[str, Any]:
        """
        Analyze a function to get resource recommendations.

        Args:
            func: The function to analyze

        Returns:
            Dictionary with CPU, memory, GPU recommendations
        """
        self._ensure_active()

        try:
            payload = cloudpickle.dumps(func)
            payload_b64 = base64.b64encode(payload).decode("utf-8")
        except Exception as e:
            raise SerializationError(f"Failed to serialize function: {e}") from e

        try:
            response = self._client.post(
                "/v1/analyze",
                json={"payload": payload_b64},
            )
        except httpx.RequestError as e:
            raise NetworkError(f"Failed to analyze function: {e}") from e

        if response.status_code != 200:
            raise ExecutionError(f"Analysis failed: {response.text}")

        return response.json()

    def estimate_cost(
        self,
        func: Callable,
        duration_hours: float = 1.0,
    ) -> dict[str, float]:
        """
        Estimate execution cost.

        Args:
            func: The function to estimate
            duration_hours: Estimated duration in hours

        Returns:
            Dictionary with cost estimates
        """
        self._ensure_active()

        try:
            payload = cloudpickle.dumps(func)
            payload_b64 = base64.b64encode(payload).decode("utf-8")
        except Exception as e:
            raise SerializationError(f"Failed to serialize function: {e}") from e

        try:
            response = self._client.post(
                "/v1/estimate",
                json={
                    "payload": payload_b64,
                    "duration_hours": duration_hours,
                },
            )
        except httpx.RequestError as e:
            raise NetworkError(f"Failed to estimate cost: {e}") from e

        if response.status_code != 200:
            raise ExecutionError(f"Estimation failed: {response.text}")

        return response.json()

    @property
    def jobs(self) -> list[str]:
        """Get list of job IDs submitted in this session."""
        return self._jobs.copy()


class AsyncJob:
    """Handle for an asynchronously submitted job."""

    def __init__(
        self,
        gateway: GateWay,
        func: Callable,
        args: tuple,
        kwargs: dict,
    ):
        self._gateway = gateway
        self._func = func
        self._args = args
        self._kwargs = kwargs
        self._result: Any | None = None
        self._error: Exception | None = None
        self._completed = False
        self._started = False
        self._thread: threading.Thread | None = None
        self._job_id: str | None = None

    def start(self) -> AsyncJob:
        """Start the job execution in background."""
        if self._started:
            return self

        self._started = True
        self._thread = threading.Thread(target=self._execute, daemon=True)
        self._thread.start()
        return self

    def _execute(self) -> None:
        """Execute the job."""
        try:
            # Submit the job and capture job_id directly (no race condition)
            self._job_id = self._gateway._submit_job(
                self._func,
                self._args,
                self._kwargs,
            )

            # Wait for the job to complete
            self._result = self._gateway._wait_for_job(
                self._job_id,
                self._gateway.default_timeout,
            )
        except Exception as e:
            self._error = e
        finally:
            self._completed = True

    def result(self, timeout: float | None = None) -> Any:
        """
        Wait for and return the result.

        Args:
            timeout: Maximum time to wait in seconds

        Returns:
            The function's return value

        Raises:
            TimeoutError: If timeout exceeded
            Exception: If execution failed
        """
        if not self._started:
            self.start()

        if self._thread:
            self._thread.join(timeout=timeout)

        if not self._completed:
            raise TimeoutError(f"Job did not complete within {timeout} seconds")

        if self._error:
            raise self._error

        return self._result

    @property
    def completed(self) -> bool:
        """Check if the job has completed."""
        return self._completed

    @property
    def job_id(self) -> str | None:
        """Get the job ID."""
        return self._job_id

    def cancel(self) -> bool:
        """
        Cancel the job locally and on the server (terminates the VM).

        Returns:
            True if cancellation was successful, False if already completed
        """
        if self._completed:
            return False

        self._error = ExecutionError("Job was cancelled")
        self._completed = True

        # Cancel on the server to terminate the VM / container
        if self._job_id:
            self._gateway._cancel_job_remote(self._job_id)

        return True

    def __del__(self):
        """Cleanup when AsyncJob is garbage collected."""
        # Mark as completed to allow thread to exit cleanly if it's checking
        self._completed = True


# Module-level convenience functions


def auth(api_key: str | None = None, fast: bool = False) -> AuthSession:
    """
    Authenticate with Verlex API.

    Args:
        api_key: Your Verlex API key
        fast: True = immediate execution (Performance), False = standard

    Returns:
        AuthSession object
    """
    global _current_session

    api_key = api_key or os.getenv("VERLEX_API_KEY")
    if not api_key:
        raise NotAuthenticatedError("No API key provided")

    _current_session = AuthSession(
        api_key=api_key,
        fast=fast,
    )
    return _current_session


def get_session() -> AuthSession | None:
    """Get the current authentication session."""
    return _current_session


def logout() -> None:
    """Clear the current session."""
    global _current_session
    _current_session = None
    print("Logged out.")


def whoami() -> dict[str, Any] | None:
    """Show current authenticated user."""
    if not _current_session:
        print("Not authenticated. Run verlex.auth() first.")
        return None

    api_url = os.getenv("VERLEX_API_URL", DEFAULT_API_URL)

    try:
        response = httpx.get(
            f"{api_url}/v1/auth/validate",
            headers={"Authorization": f"Bearer {_current_session.api_key}"},
            timeout=10.0,
        )
        if response.status_code == 200:
            data = response.json()
            print(f"Authenticated as: {data.get('email', 'user')}")
            print(f"Tier: {data.get('tier', 'free')}")
            return data
        else:
            print("Failed to get user info")
            return None
    except httpx.RequestError as e:
        print(f"Network error: {e}")
        return None


# Convenience function for quick one-off execution
def cloud(
    func: Callable[..., T],
    *args,
    api_key: str | None = None,
    fast: bool = False,
    verbose: bool = True,
    **kwargs,
) -> T:
    """
    Quick one-liner to run a function in the cloud.

    Args:
        func: Function to execute
        *args: Arguments for the function
        api_key: Verlex API key (optional if env var set)
        fast: True = immediate execution (Performance), False = standard
        verbose: Show progress bar and status messages
        **kwargs: Keyword arguments for the function

    Returns:
        The function's return value
    """
    with GateWay(api_key=api_key, fast=fast, verbose=verbose) as gw:
        return gw.run(func, *args, **kwargs)
