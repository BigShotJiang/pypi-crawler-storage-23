import pandas as pd

path = "/Volumes/ChenDisk/experiment/results/tap/11.23005.avi/particle_without_list.csv"
df = pd.read_csv(path)
print(df)
