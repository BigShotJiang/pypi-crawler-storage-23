"""Mean Squared Displacement (MSD) 计算工具。

MSD(tau) = <|r(t+tau) - r(t)|^2>，用于刻画轨迹的扩散/迁移行为。
基于 FFT 的 O(N log N) 实现。
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from funlog import getLogger

logger = getLogger("funfluid")


def _auto_corr_fft_2d(arr: np.ndarray) -> np.ndarray:
    """用 2D FFT 一次算各维度自相关之和，用于 msd_fft 中的 S2 项。

    自相关 C(tau) = <x(t)*x(t+tau)> 通过 FFT 实现：ifft(|fft(x)|^2)，再按滞后归一化。
    """
    N = len(arr)
    # 零填充到 2N 避免循环卷积
    F = np.fft.fft(arr, n=2 * N, axis=0)
    PSD = F * np.conj(F)
    res = np.fft.ifft(PSD, axis=0).real[:N]
    # 各滞后的有效样本数：N, N-1, ..., 1（保持 (N,1) 以便与 (N,d) 广播）
    n = (N - np.arange(N))[:, np.newaxis]
    return (res / n).sum(axis=1)


def msd_fft(arr: np.ndarray) -> np.ndarray:
    """基于 FFT 的 MSD，复杂度 O(N log N)。公式 MSD(m) = S1(m) - 2*S2(m)。

    Args:
        arr: (N, d) 轨迹坐标。

    Returns:
        长度 N 的数组，第 k 个元素为滞后 k 帧的 MSD。
    """
    N = len(arr)
    # D[i] = |r_i|^2，用于 S1 中的距离平方和
    D = np.square(arr).sum(axis=1)

    # S2: 各维度自相关之和（与 <r(t)·r(t+tau)> 相关）
    S2 = _auto_corr_fft_2d(arr)

    # S1: 与 <|r(t+tau)|^2 + |r(t)|^2> 相关的项，用前缀/后缀和向量化
    # Q(m) = 2*sum(D) - sum(D[:m]) - sum(D[N-m:])，再除以 (N-m) 得 S1(m)
    total_D = D.sum()
    cumsum_left = np.concatenate([[0], np.cumsum(D)])
    cumsum_right = np.concatenate(
        [np.cumsum(D[::-1])[::-1], [0]]
    )  # [i] = sum(D[i:]), [N]=0
    Q = 2 * total_D - cumsum_left[:N] - cumsum_right[N - np.arange(N)]
    S1 = Q / (N - np.arange(N))

    return S1 - 2 * S2


def cul_msd(
    df: pd.DataFrame,
    col_time: str = "t",
    col_x: str = "x",
    col_y: str = "y",
    fill_missing: bool = False,
) -> pd.DataFrame:
    """从轨迹 DataFrame 计算 MSD 与等效速度 v = sqrt(MSD)/t。

    支持连续非整数时间（如 0.5, 0.6, 0.7, ...）：按时间排序后直接计算，
    输出中的 col_time 为相对首帧的 elapsed time（t - t0），v = sqrt(msd) / elapsed_time。

    Args:
        df: 至少包含时间列与 x,y 坐标列的 DataFrame。
        col_time: 时间列名（可为连续非整数）。
        col_x: x 坐标列名。
        col_y: y 坐标列名。
        fill_missing: 若 True 且时间为整数 1..t_max，则用左连接补全缺失帧（保持旧行为）；
            否则按现有时间点排序后计算，不补全。

    Returns:
        含 col_time（elapsed time）、msd、v 的 DataFrame；仅保留 msd>0 且 elapsed time>0 的行。
    """
    t_vals = df[col_time].values
    is_integer_time = np.issubdtype(t_vals.dtype, np.integer) or np.all(
        np.equal(np.mod(t_vals, 1), 0)
    )
    t_max = np.max(t_vals)

    if fill_missing and is_integer_time and t_max >= 1:
        # 整数时间且需补全：用 1..t_max-1 左连接
        grid = np.arange(1, int(t_max), dtype=t_vals.dtype)
        df_work = pd.merge(
            pd.DataFrame({col_time: grid}),
            df,
            on=col_time,
            how="left",
        )
        arr = df_work[[col_x, col_y]].values
        t_out = df_work[col_time].values.astype(float)
    else:
        # 连续/非整数时间或不需要补全：按时间排序，不插值
        df_work = df.sort_values(col_time).reset_index(drop=True)
        arr = df_work[[col_x, col_y]].values
        t_out = df_work[col_time].values.astype(float)
        # 输出时间为相对首帧的 elapsed time
        t_out = t_out - t_out[0]

    msd = msd_fft(arr)
    msd_df = pd.DataFrame({col_time: t_out, "msd": msd})
    msd_df = msd_df[msd_df["msd"] > 0].reset_index(drop=True)
    t_span = msd_df[col_time].values
    msd_df["v"] = np.sqrt(msd_df["msd"].values) / np.where(t_span > 0, t_span, np.nan)
    msd_df = msd_df[msd_df[col_time] > 0]
    return msd_df


def cul_msd_multi(
    df: pd.DataFrame,
    col_id: str = "path_id",
    col_time: str = "t",
    col_x: str = "x",
    col_y: str = "y",
    tol: float = 1e-9,
    aggregate_std: bool = False,
) -> pd.DataFrame:
    """多条路径的 MSD：按路径 ID 分组计算，要求各路径时间间隔 dt 相同，再按 lag 合并。

    合并时按「有效位移对数」加权：lag k 时路径 j 有 (N_j - k) 对位移参与其 MSD，
    权重即为此数，MSD(k) = Σ_j [ MSD_j(k) · (N_j - k) ] / Σ_j (N_j - k)，
    等价于把所有路径的位移平方池化后做一次均值（不再对均值再取均值）。

    例如第一条路径 t=0.5,0.6,...,2.0（dt=0.1），第二条 t=1.5,1.6,...,3.0（dt=0.1），
    输出 elapsed time = 0, dt, 2*dt, ...

    Args:
        df: 含多段轨迹的 DataFrame，每段由 col_id 区分。
        col_id: 路径 ID 列名（如 "path_id"）。
        col_time: 时间列名。
        col_x: x 坐标列名。
        col_y: y 坐标列名。
        tol: 判定时间间隔一致时的数值容差。
        aggregate_std: 若 True，额外输出 msd_std（同权重的加权标准差）。

    Returns:
        含 col_time（elapsed = lag*dt）、msd（加权池化 MSD）、v 的 DataFrame；
        若 aggregate_std=True 则含 msd_std。仅保留 msd>0 且 elapsed>0 的行。

    Raises:
        ValueError: 某条路径内时间间隔不一致，或各路径间 dt 不一致。
    """
    grouped = df.groupby(col_id)
    paths_msd = []
    dts = []
    for pid, g in grouped:
        g = g.sort_values(col_time).reset_index(drop=True)
        t = g[col_time].values.astype(float)
        dt_arr = np.diff(t)
        if len(dt_arr) == 0:
            continue
        if not np.allclose(dt_arr, dt_arr[0], rtol=0, atol=tol):
            raise ValueError(f"路径 {pid} 时间间隔不一致，无法合并")
        dts.append(dt_arr[0])
        arr = g[[col_x, col_y]].values
        msd = msd_fft(arr)
        paths_msd.append(msd)

    if not paths_msd:
        return pd.DataFrame()

    dts = np.array(dts)
    if not np.allclose(dts, dts[0], rtol=0, atol=tol):
        raise ValueError("各路径时间间隔 dt 不一致，无法合并")
    common_dt = float(dts[0])

    n_paths = len(paths_msd)
    path_lengths = np.array([len(m) for m in paths_msd])
    max_len = int(np.max(path_lengths))
    # 按有效对数加权：lag k 时权重 w_j = (N_j - k)，MSD(k) = sum(MSD_j(k)*w_j) / sum(w_j)
    msd_matrix = np.full((n_paths, max_len), np.nan)
    for j in range(n_paths):
        msd_matrix[j, : path_lengths[j]] = paths_msd[j]

    weighted_msd = np.full(max_len, np.nan)
    for k in range(max_len):
        weights = np.where(path_lengths > k, path_lengths - k, 0).astype(float)
        total_w = weights.sum()
        if total_w > 0:
            valid = path_lengths > k
            weighted_msd[k] = (msd_matrix[valid, k] * weights[valid]).sum() / total_w

    if aggregate_std:
        weighted_std = np.full(max_len, np.nan)
        for k in range(max_len):
            weights = np.where(path_lengths > k, path_lengths - k, 0).astype(float)
            total_w = weights.sum()
            if total_w > 0:
                valid = path_lengths > k
                mu = weighted_msd[k]
                weighted_std[k] = np.sqrt(
                    (weights[valid] * (msd_matrix[valid, k] - mu) ** 2).sum() / total_w
                )

    elapsed = np.arange(max_len, dtype=float) * common_dt
    out = pd.DataFrame({col_time: elapsed, "msd": weighted_msd})
    if aggregate_std:
        out["msd_std"] = weighted_std
    out = out[out["msd"] > 0].reset_index(drop=True)
    t_span = out[col_time].values
    out["v"] = np.sqrt(out["msd"].values) / np.where(t_span > 0, t_span, np.nan)
    out = out[out[col_time] > 0]
    return out


def example_cul_msd(
    seed: int = 42,
    dt: float = 0.1,
    single_len: int = 160,
    n_paths: int = 200,
) -> None:
    """示例：生成单路径与多路径轨迹数据，并分别调用 cul_msd / cul_msd_multi。

    单路径：t = 0.5, 0.6, ..., 0.5 + (single_len-1)*dt，二维随机游走。
    多路径：path_id=0 为 0.5～0.5+(single_len-1)*dt，path_id=1 为 1.5～1.5+(single_len-1)*dt，
    间隔均为 dt，用于演示 cul_msd_multi 的合并。
    会打印单路径与多路径 MSD 结果的前 5 行。

    Args:
        seed: 随机种子。
        dt: 时间步长（两条路径相同）。
        single_len: 单路径点数；多路径每条长度同此。
        n_paths: 多路径示例中的路径条数（2 则 0.5 起、1.5 起各一条）。
    """
    rng = np.random.default_rng(seed)

    # 单路径：连续非整数时间 0.5, 0.5+dt, ...
    t_single = 0.5 + np.arange(single_len) * dt
    steps = rng.standard_normal((single_len, 2)) * 0.5
    xy_single = np.cumsum(steps, axis=0)
    single_df = pd.DataFrame(
        {
            "t": t_single,
            "x": xy_single[:, 0],
            "y": xy_single[:, 1],
        }
    )

    # 多路径：相同 dt，不同起始时间
    multi_dfs = []
    for i in range(n_paths):
        t0 = 0.5 + i * 1.0
        t_path = t0 + np.arange(single_len) * dt
        steps = rng.standard_normal((single_len, 2)) * 0.5
        xy = np.cumsum(steps, axis=0)
        multi_dfs.append(
            pd.DataFrame(
                {
                    "path_id": i,
                    "t": t_path,
                    "x": xy[:, 0],
                    "y": xy[:, 1],
                }
            )
        )
    multi_df = pd.concat(multi_dfs, ignore_index=True)

    single_msd = cul_msd(single_df, col_time="t", col_x="x", col_y="y")
    multi_msd = cul_msd_multi(
        multi_df,
        col_id="path_id",
        col_time="t",
        col_x="x",
        col_y="y",
        aggregate_std=True,
    )

    print("单路径 MSD (前 10 行):")
    print(single_msd.head(10))
    print("\n多路径 MSD (前 10 行):")
    print(multi_msd.head(10))


if __name__ == "__main__":
    example_cul_msd()
