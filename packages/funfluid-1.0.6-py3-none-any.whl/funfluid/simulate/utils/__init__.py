from .tecplot import read_tecplot_point
