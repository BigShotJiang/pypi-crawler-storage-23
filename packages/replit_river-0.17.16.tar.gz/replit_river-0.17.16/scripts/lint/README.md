uv run lint, in lieu of https://github.com/astral-sh/uv/issues/5903
