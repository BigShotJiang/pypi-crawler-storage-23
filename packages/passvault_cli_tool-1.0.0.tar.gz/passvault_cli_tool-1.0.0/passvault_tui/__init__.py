"""PassVault TUI - Terminal User Interface for password management."""

__version__ = "0.1.0"
