"""Utils package for PassVault."""
from .logger import setup_logger

logger = setup_logger("PASSVAULT")