# Building Capabilities for floorctl

This document defines the **AgentCapability** protocol — the standard interface for extending agent behavior in floorctl without modifying the core library.

## The Contract

Every capability extends `AgentCapability` and overrides one or more methods:

```python
from floorctl import AgentCapability

class MyCapability(AgentCapability):
    name = "my_capability"  # unique identifier

    def enrich_context(self, context: dict) -> dict:
        """Called before LLM generation. Inject data into context."""
        return context

    def post_process(self, response: str, context: dict) -> str:
        """Called after LLM generation, before validation. Transform the response."""
        return response

    def on_turn_received(self, turn, agent_name: str) -> None:
        """Called on every new turn. Use for side-effects only."""
        pass
```

All three methods are optional. Override only what you need.

## Pipeline

Capabilities plug into the agent's generate-validate-post pipeline:

```
New turn arrives
  |
  v
on_turn_received()        <-- all capabilities notified (side-effects only)
  |
  v
compute urgency
  |
  v
claim floor (atomic)
  |
  v
build base context
  |
  v
enrich_context()          <-- capabilities inject data (RAG, search, DB, etc.)
  |                           runs in insertion order, chained
  v
generate_fn()             <-- LLM call with enriched context
  |
  v
post_process()            <-- capabilities transform the response
  |                           runs in insertion order, chained
  v
validators                <-- standard validation pipeline
  |
  v
post turn
```

## Rules

1. **Insertion order matters.** Capabilities run in the order they're added. If capability B depends on data from capability A, add A first.

2. **Return values are chained.** Each `enrich_context` receives the context returned by the previous one. Same for `post_process`.

3. **Errors are contained.** If a capability raises an exception, it's logged and skipped — the agent continues with the next capability. Your capability should never crash the agent.

4. **Context is a plain dict.** No special types. Add any keys you need. Namespace your keys to avoid collisions: `"rag:docs"`, `"search:results"`, `"memory:history"`.

5. **on_turn_received is fire-and-forget.** It runs for every turn (including the agent's own). It cannot affect the agent's decision to speak. Use it for logging, memory, analytics.

6. **post_process runs before validation.** If your post-processing changes the response length, prefix, or content, ensure it still passes the validators.

7. **Keep it synchronous.** The current pipeline is synchronous. If you need async (API calls, DB queries), block within your method. Async support may be added in a future version.

8. **No agent reference.** Capabilities receive `context` (a dict) and `turn` (a TurnRecord), not the agent itself. This keeps capabilities decoupled and testable.

## Examples

### RAG Capability

Retrieves relevant documents and injects them into the LLM context:

```python
from floorctl import AgentCapability

class RAGCapability(AgentCapability):
    name = "rag"

    def __init__(self, retriever, top_k=3):
        self.retriever = retriever
        self.top_k = top_k

    def enrich_context(self, context):
        query = context.get("topic", "") + " " + context.get("phase", "")
        docs = self.retriever.search(query, top_k=self.top_k)
        context["rag:docs"] = docs
        context["rag:doc_count"] = len(docs)
        return context
```

Usage:
```python
agent = FloorAgent(name="Researcher", ...)
agent.add_capability(RAGCapability(my_vector_store, top_k=5))
```

### Web Search Capability

Searches the web and appends sources:

```python
class WebSearchCapability(AgentCapability):
    name = "web_search"

    def __init__(self, search_fn):
        self.search_fn = search_fn

    def enrich_context(self, context):
        results = self.search_fn(context.get("topic", ""))
        context["search:results"] = results[:3]
        return context

    def post_process(self, response, context):
        sources = context.get("search:results", [])
        if sources:
            source_text = " ".join(f"[{s['title']}]" for s in sources)
            return response + f" (Sources: {source_text})"
        return response
```

### Memory Capability

Tracks what the agent has said across turns:

```python
class MemoryCapability(AgentCapability):
    name = "memory"

    def __init__(self):
        self.history = []

    def on_turn_received(self, turn, agent_name):
        self.history.append({
            "speaker": turn.speaker,
            "text": turn.text,
            "phase": turn.phase,
        })

    def enrich_context(self, context):
        # Give the agent awareness of full history
        context["memory:full_history"] = self.history[-20:]
        context["memory:turn_count"] = len(self.history)
        return context
```

### Tool Use Capability

Detects tool calls in the response and executes them:

```python
import re

class ToolCapability(AgentCapability):
    name = "tools"

    def __init__(self, tools: dict):
        self.tools = tools  # {"search": search_fn, "calculate": calc_fn}

    def post_process(self, response, context):
        # Detect [TOOL:name:args] patterns
        pattern = r'\[TOOL:(\w+):([^\]]*)\]'
        matches = re.findall(pattern, response)

        for tool_name, args in matches:
            if tool_name in self.tools:
                try:
                    result = self.tools[tool_name](args)
                    response = response.replace(
                        f"[TOOL:{tool_name}:{args}]",
                        f"[{result}]"
                    )
                except Exception:
                    pass

        return response
```

### Logging Capability

Logs all floor activity for observability:

```python
import logging

class LoggingCapability(AgentCapability):
    name = "logging"

    def __init__(self):
        self.logger = logging.getLogger("floorctl.capability.logging")

    def on_turn_received(self, turn, agent_name):
        self.logger.info(
            f"[{agent_name}] Observed turn from {turn.speaker} "
            f"in phase {turn.phase}: {turn.text[:80]}..."
        )

    def enrich_context(self, context):
        self.logger.debug(
            f"Context enriched: topic={context.get('topic')}, "
            f"phase={context.get('phase')}, keys={list(context.keys())}"
        )
        return context
```

## Composing Multiple Capabilities

Capabilities compose naturally — just add them in the right order:

```python
agent = FloorAgent(name="FullStack", ...)

# Order matters: RAG enriches context first, then memory adds history
agent.add_capability(RAGCapability(my_retriever))
agent.add_capability(MemoryCapability())
agent.add_capability(ToolCapability({"search": search_fn}))
agent.add_capability(LoggingCapability())
```

## Testing Your Capability

Capabilities are plain Python objects — test them without running a full session:

```python
def test_rag_enriches_context():
    cap = RAGCapability(mock_retriever)
    context = {"topic": "AI Safety", "phase": "DISCUSS"}
    result = cap.enrich_context(context)
    assert "rag:docs" in result
    assert len(result["rag:docs"]) <= 3

def test_tool_replaces_patterns():
    cap = ToolCapability({"upper": str.upper})
    response = "Result: [TOOL:upper:hello]"
    result = cap.post_process(response, {})
    assert result == "Result: [HELLO]"
```

## Roadmap

Future capability hooks (not yet implemented):

| Hook | Purpose | Status |
|------|---------|--------|
| `on_session_start()` | Initialize resources (DB connections, caches) | Planned |
| `on_session_end()` | Cleanup and persist state | Planned |
| `on_phase_change()` | React to phase transitions | Planned |
| `adjust_urgency()` | Modify urgency score before threshold check | Planned |
| Async support | Non-blocking enrich_context and post_process | Planned |
