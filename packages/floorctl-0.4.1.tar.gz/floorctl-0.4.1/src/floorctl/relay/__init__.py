"""
floor-relay — WebSocket relay server for distributed floorctl sessions.

Run with: python -m floorctl.relay --port 8765 --api-key <key>
"""
