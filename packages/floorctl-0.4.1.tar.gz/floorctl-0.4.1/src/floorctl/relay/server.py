"""
WebSocket relay server for distributed floorctl sessions.

Handles:
- API key authentication on connect
- Session lifecycle (create, get state, update)
- Atomic floor control (asyncio.Lock per session)
- Turn storage + broadcast to all connected clients
- Reconnection with missed-turn replay
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

import websockets
from websockets.asyncio.server import ServerConnection

logger = logging.getLogger("floor-relay")


# ── Server-Side Session State ────────────────────────────────────────

@dataclass
class _RelaySession:
    """Server-side session state (mirrors InMemoryBackend._SessionData)."""

    session_id: str
    config: dict[str, Any] = field(default_factory=dict)
    status: str = "WAITING"
    phase: str = ""
    topic: str = ""
    active_speaker: str | None = None
    speaker_done: bool = True
    floor_claimed_at: float = 0.0
    floor_reserved_for: str | None = None
    floor_reserved_at: float = 0.0
    floor_released_without_post: bool = False
    floor_released_by: str | None = None
    turn_number: int = 0
    participants: list[str] = field(default_factory=list)
    turns: list[dict[str, Any]] = field(default_factory=list)
    metrics: dict[str, dict[str, Any]] = field(default_factory=dict)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    def to_state_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "phase": self.phase,
            "topic": self.topic,
            "active_speaker": self.active_speaker,
            "speaker_done": self.speaker_done,
            "floor_reserved_for": self.floor_reserved_for,
            "floor_reserved_at": self.floor_reserved_at,
            "floor_released_without_post": self.floor_released_without_post,
            "floor_released_by": self.floor_released_by,
            "turn_number": self.turn_number,
            "participants": list(self.participants),
        }


# ── Connected Client Tracking ────────────────────────────────────────

@dataclass
class _ConnectedClient:
    ws: ServerConnection
    subscribed_sessions: set[str] = field(default_factory=set)
    agent_name: str | None = None


# ── Relay Server ─────────────────────────────────────────────────────

class RelayServer:
    """
    WebSocket relay server for distributed floorctl coordination.

    Provides the same guarantees as InMemoryBackend but over WebSocket:
    - Atomic floor claims (asyncio.Lock per session)
    - Turn broadcast to all subscribed clients
    - Session state change notifications
    """

    def __init__(self, api_key: str | None = None) -> None:
        self._api_key = api_key
        self._sessions: dict[str, _RelaySession] = {}
        self._clients: dict[ServerConnection, _ConnectedClient] = {}

    async def handler(self, ws: ServerConnection) -> None:
        """Handle a single WebSocket connection."""
        # Auth check on connect
        try:
            auth_msg = await asyncio.wait_for(ws.recv(), timeout=10.0)
            auth = json.loads(auth_msg)
            if auth.get("action") != "auth":
                await ws.send(json.dumps({"error": "first message must be auth"}))
                await ws.close()
                return
            if self._api_key and auth.get("api_key") != self._api_key:
                await ws.send(json.dumps({"error": "invalid api key"}))
                await ws.close()
                return
            agent_name = auth.get("agent_name")
            client = _ConnectedClient(ws=ws, agent_name=agent_name)
            self._clients[ws] = client
            await ws.send(json.dumps({"action": "auth_ok"}))
            logger.info("Client connected: %s", agent_name or "anonymous")
        except (asyncio.TimeoutError, json.JSONDecodeError) as e:
            logger.warning("Auth failed: %s", e)
            await ws.close()
            return

        try:
            async for raw in ws:
                try:
                    msg = json.loads(raw)
                    response = await self._handle_message(ws, msg)
                    if response is not None:
                        # Echo back request_id for correlation
                        if "request_id" in msg:
                            response["request_id"] = msg["request_id"]
                        await ws.send(json.dumps(response))
                except json.JSONDecodeError:
                    await ws.send(json.dumps({"error": "invalid json"}))
                except Exception as e:
                    logger.exception("Error handling message")
                    await ws.send(json.dumps({"error": str(e)}))
        finally:
            self._clients.pop(ws, None)
            logger.info("Client disconnected: %s", agent_name or "anonymous")

    async def _handle_message(
        self, ws: ServerConnection, msg: dict[str, Any]
    ) -> dict[str, Any] | None:
        action = msg.get("action")
        session_id = msg.get("session_id", "")

        if action == "create_session":
            return await self._create_session(session_id, msg.get("config", {}))
        elif action == "get_session_state":
            return self._get_session_state(session_id)
        elif action == "update_session":
            return await self._update_session(session_id, msg.get("updates", {}))
        elif action == "claim_floor":
            return await self._claim_floor(
                session_id, msg["agent_name"], msg.get("timeout_seconds", 30.0)
            )
        elif action == "release_floor":
            return await self._release_floor(
                session_id, msg["agent_name"], msg.get("posted_successfully", True)
            )
        elif action == "reserve_floor":
            return await self._reserve_floor(
                session_id, msg["for_agent"], msg.get("duration_seconds", 30.0)
            )
        elif action == "post_turn":
            return await self._post_turn(session_id, msg["turn"])
        elif action == "get_turns":
            return self._get_turns(session_id, msg.get("since_index", 0))
        elif action == "subscribe":
            return self._subscribe(ws, session_id)
        elif action == "unsubscribe":
            return self._unsubscribe(ws, session_id)
        elif action == "store_metrics":
            return self._store_metrics(
                session_id, msg["agent_name"], msg.get("data", {})
            )
        else:
            return {"error": f"unknown action: {action}"}

    # ── Session Operations ───────────────────────────────────────────

    async def _create_session(
        self, session_id: str, config: dict[str, Any]
    ) -> dict[str, Any]:
        if session_id not in self._sessions:
            self._sessions[session_id] = _RelaySession(
                session_id=session_id,
                config=config,
                topic=config.get("topic", ""),
                phase=config.get("phase", ""),
                participants=config.get("participants", []),
            )
            logger.info("Session created: %s", session_id)
        return {"action": "session_created", "session_id": session_id}

    def _get_session_state(self, session_id: str) -> dict[str, Any]:
        s = self._sessions.get(session_id)
        if not s:
            return {"error": f"session not found: {session_id}"}
        return {"action": "session_state", "state": s.to_state_dict()}

    async def _update_session(
        self, session_id: str, updates: dict[str, Any]
    ) -> dict[str, Any]:
        s = self._sessions.get(session_id)
        if not s:
            return {"error": f"session not found: {session_id}"}

        async with s.lock:
            for key, value in updates.items():
                if hasattr(s, key) and key not in ("lock", "turns", "metrics"):
                    setattr(s, key, value)
            state = s.to_state_dict()

        # Broadcast session state change
        await self._broadcast(session_id, {
            "action": "session_update",
            "session_id": session_id,
            "state": state,
        })
        return {"action": "session_updated", "state": state}

    # ── Floor Control ────────────────────────────────────────────────

    async def _claim_floor(
        self, session_id: str, agent_name: str, timeout_seconds: float
    ) -> dict[str, Any]:
        s = self._sessions.get(session_id)
        if not s:
            return {"error": f"session not found: {session_id}"}

        async with s.lock:
            now = time.time()

            # Check reservation
            if s.floor_reserved_for and s.floor_reserved_for != agent_name:
                if (now - s.floor_reserved_at) < 30.0:
                    return {"action": "claim_result", "result": False}

            # Check if floor is currently held
            if s.active_speaker and not s.speaker_done:
                if s.active_speaker == agent_name:
                    return {"action": "claim_result", "result": True}
                if (now - s.floor_claimed_at) < timeout_seconds:
                    return {"action": "claim_result", "result": False}

            # Claim
            s.active_speaker = agent_name
            s.speaker_done = False
            s.floor_claimed_at = now
            s.floor_released_without_post = False
            s.floor_released_by = None

        return {"action": "claim_result", "result": True}

    async def _release_floor(
        self, session_id: str, agent_name: str, posted_successfully: bool
    ) -> dict[str, Any]:
        s = self._sessions.get(session_id)
        if not s:
            return {"error": f"session not found: {session_id}"}

        async with s.lock:
            if s.active_speaker == agent_name:
                s.active_speaker = None
                s.speaker_done = True
                if not posted_successfully:
                    s.floor_released_without_post = True
                    s.floor_released_by = agent_name
            state = s.to_state_dict()

        await self._broadcast(session_id, {
            "action": "session_update",
            "session_id": session_id,
            "state": state,
        })
        return {"action": "floor_released"}

    async def _reserve_floor(
        self, session_id: str, for_agent: str, duration_seconds: float
    ) -> dict[str, Any]:
        s = self._sessions.get(session_id)
        if not s:
            return {"error": f"session not found: {session_id}"}

        async with s.lock:
            s.floor_reserved_for = for_agent
            s.floor_reserved_at = time.time()

        return {"action": "floor_reserved", "for_agent": for_agent}

    # ── Turns ────────────────────────────────────────────────────────

    async def _post_turn(
        self, session_id: str, turn: dict[str, Any]
    ) -> dict[str, Any]:
        s = self._sessions.get(session_id)
        if not s:
            return {"error": f"session not found: {session_id}"}

        turn_id = str(uuid.uuid4())[:8]

        async with s.lock:
            record = {
                "speaker": turn["agent_name"],
                "text": turn["transcript"],
                "phase": s.phase,
                "turn_index": s.turn_number,
                "timestamp": turn.get("timestamp", ""),
                "is_moderator": turn.get("is_moderator", False),
            }
            s.turns.append(record)
            s.turn_number += 1

            # Clear reservation
            if s.floor_reserved_for == turn["agent_name"]:
                s.floor_reserved_for = None

        # Broadcast turn to all subscribed clients
        await self._broadcast(session_id, {
            "action": "new_turn",
            "session_id": session_id,
            "turn": record,
        })

        return {"action": "turn_posted", "turn_id": turn_id}

    def _get_turns(self, session_id: str, since_index: int) -> dict[str, Any]:
        s = self._sessions.get(session_id)
        if not s:
            return {"error": f"session not found: {session_id}"}
        turns = [t for t in s.turns if t["turn_index"] >= since_index]
        return {"action": "turns", "turns": turns}

    # ── Subscriptions ────────────────────────────────────────────────

    def _subscribe(
        self, ws: ServerConnection, session_id: str
    ) -> dict[str, Any]:
        client = self._clients.get(ws)
        if client:
            client.subscribed_sessions.add(session_id)
        return {"action": "subscribed", "session_id": session_id}

    def _unsubscribe(
        self, ws: ServerConnection, session_id: str
    ) -> dict[str, Any]:
        client = self._clients.get(ws)
        if client:
            client.subscribed_sessions.discard(session_id)
        return {"action": "unsubscribed", "session_id": session_id}

    # ── Metrics ──────────────────────────────────────────────────────

    def _store_metrics(
        self, session_id: str, agent_name: str, data: dict[str, Any]
    ) -> dict[str, Any]:
        s = self._sessions.get(session_id)
        if not s:
            return {"error": f"session not found: {session_id}"}
        s.metrics[agent_name] = data
        return {"action": "metrics_stored"}

    # ── Broadcasting ─────────────────────────────────────────────────

    async def _broadcast(
        self, session_id: str, message: dict[str, Any]
    ) -> None:
        """Broadcast a message to all clients subscribed to this session."""
        raw = json.dumps(message)
        disconnected: list[ServerConnection] = []

        for ws, client in self._clients.items():
            if session_id in client.subscribed_sessions:
                try:
                    await ws.send(raw)
                except websockets.exceptions.ConnectionClosed:
                    disconnected.append(ws)

        for ws in disconnected:
            self._clients.pop(ws, None)


async def run_server(
    host: str = "0.0.0.0",
    port: int = 8765,
    api_key: str | None = None,
) -> None:
    """Start the relay server."""
    server = RelayServer(api_key=api_key)
    logger.info("floor-relay starting on ws://%s:%d", host, port)
    if api_key:
        logger.info("API key authentication enabled")

    async with websockets.serve(server.handler, host, port):
        await asyncio.Future()  # run forever
