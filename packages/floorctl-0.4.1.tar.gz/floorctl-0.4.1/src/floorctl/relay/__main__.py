"""
CLI entry point: python -m floorctl.relay --port 8765 --api-key <key>
"""

import argparse
import asyncio
import logging

from floorctl.relay.server import run_server


def main() -> None:
    parser = argparse.ArgumentParser(
        description="floor-relay: WebSocket relay server for distributed floorctl sessions"
    )
    parser.add_argument("--host", default="0.0.0.0", help="Bind address (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8765, help="Port (default: 8765)")
    parser.add_argument("--api-key", default=None, help="API key for auth (optional)")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    asyncio.run(run_server(host=args.host, port=args.port, api_key=args.api_key))


if __name__ == "__main__":
    main()
