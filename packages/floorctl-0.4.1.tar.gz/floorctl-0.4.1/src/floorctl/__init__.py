"""
floorctl — Contention-based multi-agent coordination with transactional floor control.

A framework for building multi-agent systems where agents compete for a shared
floor, self-validate their outputs, and are observed by a reactive moderator.

New in v0.2: Artifacts, Consensus, and Conviction primitives for
structured collaboration, formal decision-making, and position tracking.

Usage:
    from floorctl import FloorAgent, FloorSession, AgentProfile, InMemoryBackend

    agent = FloorAgent(name="Alpha", profile=AgentProfile(...), generate_fn=..., backend=...)
    session = FloorSession(backend=InMemoryBackend())
    session.add_agent(agent)
    result = session.run("session-001", topic="...")
"""

from floorctl.agent import FloorAgent
from floorctl.moderator import (
    ModeratorObserver,
    InterventionDetector,
    InterventionResult,
    EscalationDetector,
    DominanceDetector,
    SilenceDetector,
)
from floorctl.session import FloorSession
from floorctl.state import ConversationState, AgentMemory
from floorctl.config import (
    ArenaConfig,
    AgentProfile,
    StyleContract,
    PhaseConfig,
    PhaseSequence,
    FloorConfig,
    ModeratorConfig,
    ConsensusConfig,
    ConvictionConfig,
)
from floorctl.urgency import UrgencyScorer, UrgencyResult
from floorctl.types import (
    TurnRecord,
    TurnData,
    SessionResult,
    SessionStatus,
    Temperament,
    ValidationResult,
    FloorEvent,
    AgentCapability,
    GenerateFn,
    ModeratorFn,
)
from floorctl.transcript import export_transcript
from floorctl.validators import (
    Validator,
    run_validators,
    SpeakerPrefixValidator,
    DuplicateValidator,
    LengthValidator,
    BannedPhraseValidator,
    StyleContractValidator,
    PhaseValidator,
)
from floorctl.metrics import AgentMetrics, SessionMetrics
from floorctl.backends.memory import InMemoryBackend

# Optional distributed backends
try:
    from floorctl.backends.websocket import WebSocketBackend
except ImportError:
    WebSocketBackend = None  # type: ignore[assignment,misc]

try:
    from floorctl.backends.firestore import FirestoreBackend
except ImportError:
    FirestoreBackend = None  # type: ignore[assignment,misc]

from floorctl.floor import FloorController
from floorctl.phases import PhaseManager

# New primitives (v0.2)
from floorctl.artifacts import (
    ArtifactStore,
    Artifact,
    ArtifactVersion,
    ArtifactType,
    ArtifactStatus,
)
from floorctl.consensus import (
    ConsensusProtocol,
    Proposal,
    Vote,
    ConsensusResult,
    QuorumRule,
    VoteChoice,
    ProposalStatus,
)
from floorctl.conviction import (
    ConvictionTracker,
    EvidenceEvent,
    EvidenceType,
    DriftDirection,
    PositionState,
    ConvictionSnapshot,
)

__version__ = "0.4.1"

__all__ = [
    # Core
    "FloorAgent",
    "FloorSession",
    "ModeratorObserver",
    # Config
    "ArenaConfig",
    "AgentProfile",
    "StyleContract",
    "PhaseConfig",
    "PhaseSequence",
    "FloorConfig",
    "ModeratorConfig",
    "ConsensusConfig",
    "ConvictionConfig",
    # State
    "ConversationState",
    "AgentMemory",
    # Urgency
    "UrgencyScorer",
    "UrgencyResult",
    # Validators
    "Validator",
    "run_validators",
    "SpeakerPrefixValidator",
    "DuplicateValidator",
    "LengthValidator",
    "BannedPhraseValidator",
    "StyleContractValidator",
    "PhaseValidator",
    # Metrics
    "AgentMetrics",
    "SessionMetrics",
    # Backends
    "InMemoryBackend",
    "WebSocketBackend",
    "FirestoreBackend",
    # Types
    "TurnRecord",
    "TurnData",
    "SessionResult",
    "SessionStatus",
    "Temperament",
    "ValidationResult",
    "FloorEvent",
    "AgentCapability",
    "GenerateFn",
    "ModeratorFn",
    # Transcript Export
    "export_transcript",
    # Artifacts (v0.2)
    "ArtifactStore",
    "Artifact",
    "ArtifactVersion",
    "ArtifactType",
    "ArtifactStatus",
    # Consensus (v0.2)
    "ConsensusProtocol",
    "Proposal",
    "Vote",
    "ConsensusResult",
    "QuorumRule",
    "VoteChoice",
    "ProposalStatus",
    # Conviction (v0.2)
    "ConvictionTracker",
    "EvidenceEvent",
    "EvidenceType",
    "DriftDirection",
    "PositionState",
    "ConvictionSnapshot",
    # Internals (for advanced usage)
    "FloorController",
    "PhaseManager",
    "InterventionDetector",
    "InterventionResult",
    "EscalationDetector",
    "DominanceDetector",
    "SilenceDetector",
]
