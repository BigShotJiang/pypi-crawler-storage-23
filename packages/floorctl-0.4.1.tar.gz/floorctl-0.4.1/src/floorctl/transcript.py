"""
Transcript exporter — generates a formatted Markdown transcript
from a SessionResult, including floor contention details.

Usage:
    from floorctl.transcript import export_transcript

    result = session.run(session_id, topic="...")
    path = export_transcript(result, "transcripts/session.md")
"""

from __future__ import annotations

import os
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any

from floorctl.types import FloorEvent, SessionResult, TurnRecord


def _parse_ts(ts: str) -> datetime | None:
    """Parse ISO 8601 timestamp string to datetime."""
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts)
    except (ValueError, TypeError):
        return None


def _format_elapsed(seconds: float) -> str:
    """Format elapsed seconds as HH:MM:SS."""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    if h > 0:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def _format_duration(seconds: float) -> str:
    """Format duration as human-readable string."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes = seconds / 60
    if minutes < 60:
        return f"{minutes:.1f}m"
    hours = minutes / 60
    return f"{hours:.1f}h"


def _assign_events_to_turns(
    transcript: list[TurnRecord],
    floor_events: list[FloorEvent],
) -> dict[int, list[FloorEvent]]:
    """
    Assign floor events to turns using speaker-based attribution.

    Returns: dict mapping turn index (0-based in transcript) to its FloorEvents.

    Algorithm:
    - Events are consumed in timestamp order.
    - A pending buffer accumulates events as we scan.
    - When we reach a non-moderator turn with speaker X, we find the
      winning event for X (success=True, agent_name=X) in the pending buffer.
    - All events up to and including that anchor are assigned to this turn.
    - Winning events for OTHER agents stay in the pending buffer for later turns.
    """
    result: dict[int, list[FloorEvent]] = {}

    if not floor_events:
        return result

    # Build ordered list of non-moderator turn indices
    agent_turn_indices = [
        i for i, t in enumerate(transcript) if not t.is_moderator
    ]

    if not agent_turn_indices:
        return result

    # Work through events in order, assigning them to turns
    pending: list[FloorEvent] = []
    event_idx = 0
    total_events = len(floor_events)

    for turn_pos, turn_i in enumerate(agent_turn_indices):
        turn = transcript[turn_i]
        turn_ts = _parse_ts(turn.timestamp)

        # Determine the timestamp boundary: use the next turn's timestamp
        # to know when to stop collecting events for this turn
        next_turn_ts: datetime | None = None
        if turn_pos + 1 < len(agent_turn_indices):
            next_turn = transcript[agent_turn_indices[turn_pos + 1]]
            next_turn_ts = _parse_ts(next_turn.timestamp)

        # Collect events up to next turn's timestamp into pending buffer
        while event_idx < total_events:
            evt = floor_events[event_idx]
            evt_ts = _parse_ts(evt.timestamp)

            if evt_ts is None:
                event_idx += 1
                continue

            # If there's a next turn, only collect events before it
            if next_turn_ts and evt_ts > next_turn_ts:
                break

            pending.append(evt)
            event_idx += 1

        # Now find the anchor: the winning event for this turn's speaker
        anchor_idx: int | None = None
        for pi, pevt in enumerate(pending):
            if pevt.success and pevt.agent_name == turn.speaker:
                anchor_idx = pi
                break  # Take the first (earliest) matching win

        if anchor_idx is not None:
            # Assign everything up to and including the anchor to this turn
            assigned = pending[:anchor_idx + 1]
            remaining = pending[anchor_idx + 1:]
        else:
            # No winning event found for this speaker (edge case).
            # This can happen if floor was granted without a recorded claim
            # (e.g., opening round). Assign all losing events to this turn.
            assigned = [e for e in pending if not e.success or e.agent_name == turn.speaker]
            remaining = [e for e in pending if e.success and e.agent_name != turn.speaker]

        if assigned:
            result[turn_i] = assigned

        pending = remaining

    # If there are remaining events after all turns, attach to the last turn
    if pending and agent_turn_indices:
        last_turn_i = agent_turn_indices[-1]
        if last_turn_i in result:
            result[last_turn_i].extend(pending)
        else:
            result[last_turn_i] = pending

    return result


def _build_header(result: SessionResult) -> str:
    """Build the transcript header."""
    # Extract agent names from transcript
    agents = sorted(set(
        t.speaker for t in result.transcript if not t.is_moderator
    ))

    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    lines = [
        f"# Session Transcript: {result.session_id}",
        "",
        f"**Topic**: {result.topic}",
        f"**Duration**: {_format_duration(result.duration_seconds)} | "
        f"**Total Turns**: {result.total_turns}",
        f"**Agents**: {', '.join(agents)}",
        f"**Generated**: {generated_at}",
        "",
        "---",
        "",
    ]
    return "\n".join(lines)


def _build_turn_entry(
    turn: TurnRecord,
    turn_number: int,
    elapsed_str: str,
    events: list[FloorEvent],
) -> str:
    """Build a single turn entry."""
    lines = [
        f"## Turn {turn_number} — [Phase: {turn.phase}] — {elapsed_str}",
        "",
    ]

    if turn.is_moderator:
        lines.append("### Moderator")
        lines.append(f"> {turn.text}")
        lines.append("")
        lines.append("---")
        lines.append("")
        return "\n".join(lines)

    # Floor contention table
    if events:
        lines.append("### Floor Contention")
        lines.append("")
        lines.append("| Agent | Action | Urgency | Threshold | Result |")
        lines.append("|-------|--------|---------|-----------|--------|")

        for evt in events:
            action = "Retry" if evt.is_retry else "Claim"
            # Only mark WON if this event's agent is the actual speaker
            if evt.success and evt.agent_name == turn.speaker:
                result_str = "**WON**"
            else:
                result_str = "LOST"
            urgency_str = f"{evt.urgency_score:.2f}" if evt.urgency_score > 0 else "—"
            threshold_str = f"{evt.urgency_threshold:.2f}" if evt.urgency_threshold > 0 else "—"
            lines.append(
                f"| {evt.agent_name} | {action} | {urgency_str} | "
                f"{threshold_str} | {result_str} |"
            )

        lines.append("")

    # Speaker text
    lines.append(f"### Speaker: {turn.speaker}")
    lines.append(f"> {turn.text}")
    lines.append("")
    lines.append("---")
    lines.append("")

    return "\n".join(lines)


def _build_summary(result: SessionResult) -> str:
    """Build the summary table at the end of the transcript."""
    # Count per-agent stats from floor events
    agent_stats: dict[str, dict[str, int]] = defaultdict(
        lambda: {"turns": 0, "claims": 0, "won": 0, "lost": 0}
    )

    # Count turns per agent
    for turn in result.transcript:
        if not turn.is_moderator:
            agent_stats[turn.speaker]["turns"] += 1

    # Count floor claims per agent
    for evt in result.floor_events:
        stats = agent_stats[evt.agent_name]
        stats["claims"] += 1
        if evt.success:
            stats["won"] += 1
        else:
            stats["lost"] += 1

    lines = [
        "## Session Summary",
        "",
        "### Participation",
        "",
        "| Agent | Turns | Claims | Won | Lost | Win Rate |",
        "|-------|-------|--------|-----|------|----------|",
    ]

    for agent in sorted(agent_stats.keys()):
        s = agent_stats[agent]
        win_rate = (
            f"{s['won'] / s['claims'] * 100:.0f}%"
            if s["claims"] > 0 else "—"
        )
        lines.append(
            f"| {agent} | {s['turns']} | {s['claims']} | "
            f"{s['won']} | {s['lost']} | {win_rate} |"
        )

    lines.append("")

    # Session-level metrics
    if result.session_metrics:
        participation = result.session_metrics.get("participation", {})
        gini = participation.get("gini", "N/A")
        interventions_data = result.session_metrics.get("interventions", {})
        total_interventions = interventions_data.get("total", 0)

        lines.append("### Session Metrics")
        lines.append("")
        lines.append(f"- **Gini Coefficient**: {gini}")
        lines.append(f"- **Total Interventions**: {total_interventions}")

        if total_interventions > 0:
            by_type = interventions_data.get("by_type", {})
            if by_type:
                lines.append(f"- **Intervention Types**: {', '.join(f'{k}: {v}' for k, v in by_type.items())}")

        lines.append("")

    # Agent-level metrics summary
    if result.agent_metrics:
        lines.append("### Agent Performance")
        lines.append("")
        lines.append("| Agent | Avg Urgency | Validation Pass Rate | Avg Gen Time |")
        lines.append("|-------|-------------|---------------------|--------------|")

        for agent_name in sorted(result.agent_metrics.keys()):
            m = result.agent_metrics[agent_name]
            avg_urg = m.get("urgency", {}).get("avg_urgency", 0)
            pass_rate = m.get("validation", {}).get("pass_rate", 0)
            avg_gen = m.get("generation", {}).get("avg_time_seconds", 0)
            lines.append(
                f"| {agent_name} | {avg_urg:.3f} | {pass_rate:.1%} | {avg_gen:.2f}s |"
            )

        lines.append("")

    return "\n".join(lines)


def export_transcript(
    result: SessionResult,
    output_path: str | None = None,
) -> str:
    """
    Export a SessionResult as a formatted Markdown transcript.

    Args:
        result: The session result containing transcript and floor events.
        output_path: Path to write the transcript file. If None, auto-generates
                     a path as ``transcripts/{session_id}.md``.

    Returns:
        The absolute path of the written file.
    """
    if output_path is None:
        output_path = f"transcripts/{result.session_id}.md"

    # Ensure directory exists
    output_dir = os.path.dirname(output_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    # Determine session start time
    session_start: datetime | None = None
    for turn in result.transcript:
        ts = _parse_ts(turn.timestamp)
        if ts is not None:
            session_start = ts
            break

    # Assign floor events to turns using speaker-based attribution
    events_by_turn = _assign_events_to_turns(result.transcript, result.floor_events)

    # Build the document
    parts = [_build_header(result)]

    for i, turn in enumerate(result.transcript):
        turn_ts = _parse_ts(turn.timestamp)

        # Compute elapsed time
        if session_start and turn_ts:
            elapsed_seconds = (turn_ts - session_start).total_seconds()
            elapsed_str = _format_elapsed(elapsed_seconds)
        else:
            elapsed_str = "—"

        # Get pre-assigned events for this turn
        turn_events = events_by_turn.get(i, [])

        # Build the turn entry
        turn_number = i + 1
        parts.append(_build_turn_entry(turn, turn_number, elapsed_str, turn_events))

    # Summary section
    parts.append(_build_summary(result))

    content = "\n".join(parts)

    # Write to file
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(content)

    abs_path = os.path.abspath(output_path)
    return abs_path
