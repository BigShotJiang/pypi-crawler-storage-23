"""
FloorSession — high-level orchestrator that ties agents, moderator, and backend.

The primary entry point for running a multi-agent session.
"""

from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone
from typing import Any

from floorctl.agent import FloorAgent
from floorctl.backends.base import Backend
from floorctl.config import ArenaConfig
from floorctl.moderator import ModeratorObserver
from floorctl.types import FloorEvent, SessionResult, TurnRecord

logger = logging.getLogger("floorctl.session")


class FloorSession:
    """
    Orchestrates a multi-agent session.

    Usage:
        session = FloorSession(backend=InMemoryBackend(), config=ArenaConfig(...))
        session.add_agent(agent1)
        session.add_agent(agent2)
        session.set_moderator(moderator)
        result = session.run("session-001", topic="Should AI have rights?")
    """

    def __init__(
        self,
        backend: Backend,
        config: ArenaConfig | None = None,
    ) -> None:
        self.backend = backend
        self.config = config or ArenaConfig()
        self.agents: list[FloorAgent] = []
        self.moderator: ModeratorObserver | None = None

    def add_agent(self, agent: FloorAgent) -> None:
        """Add an agent to the session."""
        self.agents.append(agent)

    def set_moderator(self, moderator: ModeratorObserver) -> None:
        """Set the moderator observer."""
        self.moderator = moderator

    def run(
        self,
        session_id: str,
        topic: str,
        timeout_seconds: float | None = None,
    ) -> SessionResult:
        """
        Run the session. Blocks until completion or timeout.

        Returns SessionResult with transcript and metrics.
        """
        start_time = time.time()
        agent_names = [a.name for a in self.agents]

        # Create session in backend
        self.backend.create_session(session_id, {
            "topic": topic,
            "phase": self.config.phases.first().name if self.config.phases.first() else "DISCUSSION",
            "participants": agent_names,
            "status": "WAITING",
        })

        # Share config with agents
        for agent in self.agents:
            agent.config = self.config
            agent.join_session(session_id)

        # Start agent threads
        agent_threads: list[threading.Thread] = []
        for agent in self.agents:
            t = threading.Thread(
                target=agent.listen_and_react,
                args=(session_id,),
                name=f"agent-{agent.name}",
                daemon=True,
            )
            agent_threads.append(t)
            t.start()
            time.sleep(0.1)  # Small stagger

        logger.info(
            f"Session {session_id} started: {len(self.agents)} agents, "
            f"topic='{topic}'"
        )

        # Run moderator intro (this posts turns that agents will react to)
        if self.moderator:
            # Subscribe moderator to turns
            def on_mod_turn(turn: TurnRecord) -> None:
                if turn.speaker != "Moderator":
                    self.moderator.on_new_turn(turn)  # type: ignore

            unsub = self.backend.subscribe_turns(session_id, on_mod_turn)
            self.moderator.run_intro(topic)
        else:
            unsub = lambda: None  # noqa: E731
            # Without a moderator, just set session live
            self.backend.update_session(session_id, {"status": "LIVE"})

        # Wait for completion
        max_time = timeout_seconds or 600.0  # 10 min default
        poll_interval = 0.5

        while (time.time() - start_time) < max_time:
            state = self.backend.get_session_state(session_id)
            if state.get("status") == "COMPLETED":
                break

            # Check max total turns
            turns = self.backend.get_turns(session_id)
            agent_turn_count = sum(1 for t in turns if not t.is_moderator)
            if agent_turn_count >= self.config.max_total_turns:
                logger.info(
                    f"Max turns ({self.config.max_total_turns}) reached"
                )
                if self.moderator:
                    self.moderator.run_closing()
                else:
                    self.backend.update_session(session_id, {"status": "COMPLETED"})
                break

            time.sleep(poll_interval)

        # Stop all agents
        for agent in self.agents:
            agent.stop()

        # Wait for threads to finish
        for t in agent_threads:
            t.join(timeout=5.0)

        unsub()

        # Collect results
        elapsed = time.time() - start_time
        turns = self.backend.get_turns(session_id)

        # Store agent metrics
        agent_metrics_dict: dict[str, Any] = {}
        for agent in self.agents:
            if agent.metrics:
                data = agent.metrics.to_dict()
                agent_metrics_dict[agent.name] = data
                self.backend.store_metrics(session_id, agent.name, data)

        session_metrics_dict: dict[str, Any] = {}
        if self.moderator:
            session_metrics_dict = self.moderator.metrics.to_dict()
            self.backend.store_metrics(session_id, "moderator", session_metrics_dict)

        # Collect floor events from all agents into a sorted audit log
        all_floor_events: list[FloorEvent] = []
        for agent in self.agents:
            if agent.metrics:
                for evt in agent.metrics.floor_events:
                    all_floor_events.append(FloorEvent(
                        agent_name=agent.name,
                        timestamp=evt["timestamp"],
                        success=evt["success"],
                        is_retry=evt.get("is_retry", False),
                        urgency_score=evt.get("urgency", 0.0),
                        urgency_threshold=evt.get("threshold", 0.0),
                        phase=evt.get("phase", ""),
                    ))
        all_floor_events.sort(key=lambda e: e.timestamp)

        result = SessionResult(
            session_id=session_id,
            topic=topic,
            transcript=turns,
            agent_metrics=agent_metrics_dict,
            session_metrics=session_metrics_dict,
            total_turns=len(turns),
            duration_seconds=round(elapsed, 1),
            floor_events=all_floor_events,
        )

        logger.info(
            f"Session {session_id} complete: {len(turns)} turns, "
            f"{elapsed:.1f}s, Gini={self.moderator.metrics.gini_coefficient if self.moderator else 'N/A'}"
        )

        return result
