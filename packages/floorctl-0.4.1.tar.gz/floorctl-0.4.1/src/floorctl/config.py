"""
Configuration dataclasses for floorctl.

All configuration is through dataclasses — no YAML/JSON parsing in the library.
Users construct configs however they want.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from floorctl.types import Temperament


# ── Style Contract ───────────────────────────────────────────────────

@dataclass
class StyleContract:
    """Per-agent style enforcement rules for self-validation."""
    description: str = ""
    required_patterns: list[str] = field(default_factory=list)
    forbidden_patterns: list[str] = field(default_factory=list)
    max_sentences: int | None = None


# ── Agent Profile ────────────────────────────────────────────────────

@dataclass
class AgentProfile:
    """
    Defines an agent's personality, triggers, and style.

    react_to: keywords that make this agent want to speak
    temperament: controls urgency threshold (reactive=0.35, patient=0.55)
    base_cooldown: minimum seconds between own turns
    urgency_boost_keywords: additional keywords that boost urgency further
    """
    name: str
    personality: str = ""
    react_to: list[str] = field(default_factory=list)
    temperament: str = "deliberate"
    base_cooldown: float = 10.0
    urgency_boost_keywords: list[str] = field(default_factory=list)
    style_contract: StyleContract | None = None


# ── Phase Config ─────────────────────────────────────────────────────

@dataclass
class PhaseConfig:
    """Configuration for a single conversation phase."""
    name: str
    min_turns: int = 0
    max_turns: int = 999
    constraints: str = ""           # Human-readable constraints for LLM prompt
    turn_type: str = "discussion"
    max_words: int = 150
    min_words: int = 15
    max_sentences: int | None = None
    allow_critiques: bool = True
    is_opening: bool = False        # Agents take turns in sequence (like OPENING_ROUND)
    is_terminal: bool = False       # Session ends after this phase


@dataclass
class PhaseSequence:
    """Ordered sequence of conversation phases."""
    phases: list[PhaseConfig] = field(default_factory=list)

    def get(self, name: str) -> PhaseConfig | None:
        for p in self.phases:
            if p.name == name:
                return p
        return None

    def first(self) -> PhaseConfig | None:
        return self.phases[0] if self.phases else None

    def next_phase(self, current: str) -> PhaseConfig | None:
        for i, p in enumerate(self.phases):
            if p.name == current and i + 1 < len(self.phases):
                return self.phases[i + 1]
        return None

    def is_terminal(self, name: str) -> bool:
        pc = self.get(name)
        return pc.is_terminal if pc else False

    @property
    def phase_names(self) -> list[str]:
        return [p.name for p in self.phases]


# ── Floor Config ─────────────────────────────────────────────────────

@dataclass
class FloorConfig:
    """Floor control tuning parameters."""
    timeout_seconds: float = 45.0
    min_turns_between_speaking: int = 2
    max_turns_per_phase_per_agent: int = 3
    reservation_duration_seconds: float = 30.0
    max_retries: int = 1
    retry_base_min: float = 8.0
    retry_base_max: float = 15.0
    starvation_threshold_reduction: float = 0.10
    starvation_streak_threshold: int = 3


# ── Moderator Config ─────────────────────────────────────────────────

@dataclass
class ModeratorConfig:
    """Moderator intervention tuning parameters."""
    intervention_cooldown_turns: int = 3
    escalation_markers: list[str] = field(default_factory=lambda: [
        "wrong", "absurd", "ridiculous", "nonsense", "naive",
        "completely miss", "that's just", "you're ignoring",
        "disagree completely", "fundamentally flawed",
    ])
    escalation_threshold: int = 2
    dominance_window: int = 8
    dominance_threshold: int = 3
    silence_threshold: int = 5


# ── Arena Config (top-level) ─────────────────────────────────────────

@dataclass
class ConsensusConfig:
    """Configuration for the consensus protocol."""
    quorum_rule: str = "majority"      # "majority", "supermajority", "unanimity", "threshold"
    custom_threshold: float = 0.5      # Used when quorum_rule is "threshold"
    veto_agents: list[str] = field(default_factory=list)
    allow_abstain: bool = True
    require_reason: bool = False       # Voters must provide reasoning
    max_voting_rounds: int = 3         # Max re-votes after amendments


@dataclass
class ConvictionConfig:
    """Configuration for conviction tracking."""
    entrenchment_threshold: float = 0.02  # Below this total drift = entrenched
    convergence_threshold: float = 0.15   # Below this spread = converging
    enable_anti_entrenchment: bool = True  # Warn when agents don't budge


@dataclass
class ArenaConfig:
    """Top-level configuration tying everything together."""
    floor: FloorConfig = field(default_factory=FloorConfig)
    moderator: ModeratorConfig = field(default_factory=ModeratorConfig)
    phases: PhaseSequence = field(default_factory=PhaseSequence)
    banned_phrases: list[str] = field(default_factory=lambda: [
        "As an AI", "Let's face it", "We must balance",
    ])
    max_self_retries: int = 2
    context_window_turns: int = 8   # how many recent turns to include in LLM context
    max_total_turns: int = 40       # end session after this many turns
