"""
Urgency scoring engine — extracted from Sangam's council_sdk._compute_urgency.

Determines whether an agent should compete for the floor after each new turn.
The scorer is composable: each component contributes a delta to the final score.
Users can add, replace, or reorder components.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Protocol

from floorctl.config import AgentProfile
from floorctl.state import ConversationState
from floorctl.types import Temperament, UrgencyResult


# ── Temperament → Threshold mapping ─────────────────────────────────

TEMPERAMENT_THRESHOLDS: dict[str, float] = {
    "reactive": 0.35,
    "passionate": 0.40,
    "provocative": 0.42,
    "mediating": 0.45,
    "deliberate": 0.50,
    "patient": 0.55,
}


# ── Component Protocol ───────────────────────────────────────────────

class UrgencyComponent(Protocol):
    """A single scoring component. Returns (component_name, score_delta)."""

    def compute(
        self,
        agent_name: str,
        last_text: str,
        last_speaker: str,
        is_moderator: bool,
        state: ConversationState,
        profile: AgentProfile,
    ) -> tuple[str, float]: ...


# ── Built-in Components ──────────────────────────────────────────────

@dataclass
class KeywordReactComponent:
    """Score boost when react_to keywords are found in the last turn."""

    def compute(
        self, agent_name: str, last_text: str, last_speaker: str,
        is_moderator: bool, state: ConversationState, profile: AgentProfile,
    ) -> tuple[str, float]:
        text_lower = last_text.lower()
        hits = sum(1 for kw in profile.react_to if kw.lower() in text_lower)
        if hits == 0:
            return "keyword_react", 0.0
        score = min(0.3 + 0.1 * hits, 0.6)
        return "keyword_react", score


@dataclass
class BoostKeywordComponent:
    """Additional urgency from boost keywords."""

    def compute(
        self, agent_name: str, last_text: str, last_speaker: str,
        is_moderator: bool, state: ConversationState, profile: AgentProfile,
    ) -> tuple[str, float]:
        text_lower = last_text.lower()
        hits = sum(1 for kw in profile.urgency_boost_keywords if kw.lower() in text_lower)
        if hits == 0:
            return "boost_keywords", 0.0
        score = min(0.1 * hits, 0.3)
        return "boost_keywords", score


@dataclass
class NameMentionComponent:
    """Boost when agent's name is mentioned."""

    def compute(
        self, agent_name: str, last_text: str, last_speaker: str,
        is_moderator: bool, state: ConversationState, profile: AgentProfile,
    ) -> tuple[str, float]:
        if agent_name.lower() in last_text.lower():
            return "name_mention", 0.4
        return "name_mention", 0.0


@dataclass
class ModeratorQuestionComponent:
    """Boost when moderator asks a question or opens the floor."""

    floor_open_phrases: list[str] = field(default_factory=lambda: [
        "thoughts?", "anyone", "what do you think",
        "the floor is open", "who wants to",
        "let's hear", "your take",
    ])

    def compute(
        self, agent_name: str, last_text: str, last_speaker: str,
        is_moderator: bool, state: ConversationState, profile: AgentProfile,
    ) -> tuple[str, float]:
        if not is_moderator:
            return "moderator_question", 0.0

        text_lower = last_text.lower()

        # Floor-open signals get higher boost
        for phrase in self.floor_open_phrases:
            if phrase in text_lower:
                return "moderator_question", 0.35

        # General moderator question
        if "?" in last_text:
            return "moderator_question", 0.2

        return "moderator_question", 0.0


@dataclass
class SilenceBonusComponent:
    """Boost for agents who haven't spoken recently (anti-starvation)."""

    def compute(
        self, agent_name: str, last_text: str, last_speaker: str,
        is_moderator: bool, state: ConversationState, profile: AgentProfile,
    ) -> tuple[str, float]:
        turns_silent = state.turns_since_agent_spoke(agent_name)
        if turns_silent >= 6:
            return "silence_bonus", 0.40
        if turns_silent >= 4:
            return "silence_bonus", 0.30
        if turns_silent >= 2:
            return "silence_bonus", 0.15
        return "silence_bonus", 0.0


@dataclass
class RecentSpeakerPenaltyComponent:
    """Penalty if agent spoke too recently (prevents domination)."""
    min_turns_between: int = 2

    def compute(
        self, agent_name: str, last_text: str, last_speaker: str,
        is_moderator: bool, state: ConversationState, profile: AgentProfile,
    ) -> tuple[str, float]:
        turns_silent = state.turns_since_agent_spoke(agent_name)
        if turns_silent < self.min_turns_between:
            return "recent_speaker_penalty", -0.5
        return "recent_speaker_penalty", 0.0


@dataclass
class JitterComponent:
    """Random jitter to prevent deterministic ties."""
    low: float = -0.05
    high: float = 0.15

    def compute(
        self, agent_name: str, last_text: str, last_speaker: str,
        is_moderator: bool, state: ConversationState, profile: AgentProfile,
    ) -> tuple[str, float]:
        return "jitter", random.uniform(self.low, self.high)


@dataclass
class PhaseBoostComponent:
    """Boost in active discussion phases."""
    active_phases: list[str] = field(default_factory=lambda: [
        "DISCUSSION", "SCENARIO", "TRADEOFF_VOTE", "DEBATE", "BRAINSTORM",
    ])

    def compute(
        self, agent_name: str, last_text: str, last_speaker: str,
        is_moderator: bool, state: ConversationState, profile: AgentProfile,
    ) -> tuple[str, float]:
        if state.phase.upper() in [p.upper() for p in self.active_phases]:
            return "phase_boost", 0.10
        return "phase_boost", 0.0


# ── Default components ───────────────────────────────────────────────

def default_components(min_turns_between: int = 2) -> list[UrgencyComponent]:
    """Create the default set of urgency components matching Sangam's scoring."""
    return [
        KeywordReactComponent(),
        BoostKeywordComponent(),
        NameMentionComponent(),
        ModeratorQuestionComponent(),
        SilenceBonusComponent(),
        RecentSpeakerPenaltyComponent(min_turns_between=min_turns_between),
        JitterComponent(),
        PhaseBoostComponent(),
    ]


# ── Urgency Scorer ───────────────────────────────────────────────────

class UrgencyScorer:
    """
    Computes urgency score (0.0-1.0) for an agent given the latest turn.

    Score above the agent's temperament threshold means the agent should
    compete for the floor.
    """

    def __init__(self, components: list[UrgencyComponent] | None = None) -> None:
        self.components = components or default_components()

    def threshold_for(self, profile: AgentProfile) -> float:
        """Get the urgency threshold for this agent's temperament."""
        return TEMPERAMENT_THRESHOLDS.get(profile.temperament, 0.50)

    def compute(
        self,
        agent_name: str,
        last_text: str,
        last_speaker: str,
        is_moderator: bool,
        state: ConversationState,
        profile: AgentProfile,
        threshold_adjustment: float = 0.0,
    ) -> UrgencyResult:
        """Compute urgency score with all components."""
        total = 0.0
        component_scores: dict[str, float] = {}

        for comp in self.components:
            name, delta = comp.compute(
                agent_name, last_text, last_speaker,
                is_moderator, state, profile,
            )
            total += delta
            component_scores[name] = round(delta, 4)

        # Clamp to [0.0, 1.0]
        score = max(0.0, min(1.0, total))
        threshold = self.threshold_for(profile) + threshold_adjustment

        return UrgencyResult(
            score=round(score, 4),
            threshold=round(threshold, 4),
            above_threshold=score >= threshold,
            components=component_scores,
            triggered_by=last_speaker,
        )
