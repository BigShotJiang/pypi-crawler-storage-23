"""
Moderator Observer — reactive observer that watches and intervenes.

Extracted from Sangam's controller.py. The moderator does NOT control agents.
It watches the conversation and intervenes when needed:
- Phase transitions
- Escalation detection → deescalation
- Dominance detection → redirect to quiet agents
- Silence detection → pull in quiet agents
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol

from floorctl.backends.base import Backend
from floorctl.config import ArenaConfig, ModeratorConfig, PhaseConfig, PhaseSequence
from floorctl.metrics import SessionMetrics
from floorctl.phases import PhaseManager
from floorctl.state import ConversationState
from floorctl.types import ModeratorFn, TurnData, TurnRecord

logger = logging.getLogger("floorctl.moderator")


# ── Intervention Detector Protocol ───────────────────────────────────

@dataclass
class InterventionResult:
    """Result of an intervention check."""
    type: str                      # "escalation", "dominance", "silence"
    target_agent: str | None = None
    suggested_action: str = ""     # "deescalate", "redirect", "pull_in"
    details: dict[str, Any] = field(default_factory=dict)


class InterventionDetector(Protocol):
    """Protocol for pluggable intervention detectors."""

    def check(
        self, state: ConversationState, speaker: str, text: str,
        config: ModeratorConfig,
    ) -> InterventionResult | None: ...


# ── Built-in Detectors ──────────────────────────────────────────────

@dataclass
class EscalationDetector:
    """Detects escalating conflict between agents."""

    def check(
        self, state: ConversationState, speaker: str, text: str,
        config: ModeratorConfig,
    ) -> InterventionResult | None:
        text_lower = text.lower()
        markers_found = sum(1 for m in config.escalation_markers if m in text_lower)

        if markers_found >= config.escalation_threshold:
            return InterventionResult(
                type="escalation",
                target_agent=speaker,
                suggested_action="deescalate",
                details={"markers_found": markers_found},
            )
        return None


@dataclass
class DominanceDetector:
    """Detects when one agent is dominating the conversation."""

    def check(
        self, state: ConversationState, speaker: str, text: str,
        config: ModeratorConfig,
    ) -> InterventionResult | None:
        recent = state.get_last_n_turns(config.dominance_window)
        agent_turns = [t for t in recent if not t.is_moderator]

        if len(agent_turns) < config.dominance_window // 2:
            return None

        # Count turns per agent in the window
        from collections import Counter
        counts = Counter(t.speaker for t in agent_turns)

        for agent, count in counts.most_common(1):
            if count >= config.dominance_threshold:
                # Find a quiet agent to redirect to
                all_agents = set(state.speaker_queue) if state.speaker_queue else set()
                recent_speakers = {t.speaker for t in agent_turns}
                quiet = all_agents - recent_speakers
                target = next(iter(quiet), None)

                return InterventionResult(
                    type="dominance",
                    target_agent=target,
                    suggested_action="redirect",
                    details={
                        "dominant_agent": agent,
                        "turn_count": count,
                        "quiet_agent": target,
                    },
                )
        return None


@dataclass
class SilenceDetector:
    """Detects agents who haven't spoken in a while."""

    def check(
        self, state: ConversationState, speaker: str, text: str,
        config: ModeratorConfig,
    ) -> InterventionResult | None:
        if not state.speaker_queue:
            return None

        for agent in state.speaker_queue:
            turns_silent = state.turns_since_agent_spoke(agent)
            if turns_silent >= config.silence_threshold:
                return InterventionResult(
                    type="silence",
                    target_agent=agent,
                    suggested_action="pull_in",
                    details={"turns_silent": turns_silent},
                )
        return None


# ── Default detectors ────────────────────────────────────────────────

def default_detectors() -> list[InterventionDetector]:
    return [
        EscalationDetector(),
        DominanceDetector(),
        SilenceDetector(),
    ]


# ── Moderator Observer ───────────────────────────────────────────────

class ModeratorObserver:
    """
    Reactive moderator that watches the conversation and intervenes strategically.
    Does NOT control agent turns — only produces moderator interventions.
    """

    def __init__(
        self,
        agent_names: list[str],
        moderator_fn: ModeratorFn,
        backend: Backend,
        session_id: str,
        phase_sequence: PhaseSequence,
        config: ModeratorConfig | None = None,
        detectors: list[InterventionDetector] | None = None,
    ) -> None:
        self.agent_names = list(agent_names)
        self.moderator_fn = moderator_fn
        self.backend = backend
        self.session_id = session_id
        self.config = config or ModeratorConfig()
        self.detectors = detectors or default_detectors()

        # State
        self.state = ConversationState()
        self.state.speaker_queue = list(agent_names)
        self.phase_manager = PhaseManager(phase_sequence)

        # Opening round management
        self._opening_queue: list[str] = list(agent_names)
        self._opening_index = 0
        self._opened_agents: set[str] = set()
        self._out_of_turn_count = 0
        self._closing_triggered = False

        # Intervention cooldown
        self._last_intervention_turn = -10

        # Metrics
        self.metrics = SessionMetrics(
            session_id=session_id,
            agent_names=agent_names,
        )

    def run_intro(self, topic: str) -> None:
        """Open the session. Moderator introduces the topic."""
        self.state.topic = topic
        phase_config = self.phase_manager.current_config

        # Set first phase
        first_phase = self.phase_manager.current_phase
        self.state.phase = first_phase
        self.metrics.record_phase_start(first_phase)
        self.backend.update_session(self.session_id, {
            "phase": first_phase,
            "status": "LIVE",
        })

        # Generate intro
        context = {
            "topic": topic,
            "agents": self.agent_names,
            "phase": first_phase,
        }
        text = self.moderator_fn("intro", context)
        self._commit_moderator_turn(text)

        # If the first phase is an opening round, start invitations
        if phase_config and phase_config.is_opening:
            self._advance_to_next_phase_if_opening()

    def on_new_turn(self, turn: TurnRecord) -> None:
        """Called whenever a new turn appears. The moderator decides whether to intervene."""
        self.metrics.record_turn(turn.speaker, turn.is_moderator, self.state.phase)

        if turn.is_moderator:
            self.state.add_turn(turn.speaker, turn.text, is_moderator=True)
            return

        self.state.add_turn(turn.speaker, turn.text)

        phase_config = self.phase_manager.current_config
        if not phase_config:
            return

        # Opening round logic
        if phase_config.is_opening:
            self._handle_opening_round(turn.speaker, turn.text)
            return

        # Check for phase transition (agent turns only, respecting min_turns)
        agent_turns = self.state.phase_agent_turn_count
        if (self.phase_manager.can_advance(agent_turns)
                and self.phase_manager.should_advance(agent_turns)):
            self._transition_to_next_phase()
            return

        # Run intervention detectors
        if self._can_intervene():
            for detector in self.detectors:
                result = detector.check(
                    self.state, turn.speaker, turn.text, self.config
                )
                if result:
                    self._handle_intervention(result)
                    break

    def run_closing(self, force: bool = False) -> None:
        """Generate closing remarks."""
        if self._closing_triggered and not force:
            return
        self._closing_triggered = True

        context = {
            "topic": self.state.topic,
            "agents": self.agent_names,
            "transcript_summary": self.state.get_last_n_turns_text(10),
            "phase": "CLOSING",
        }
        text = self.moderator_fn("closing", context)
        self._commit_moderator_turn(text)

        self.backend.update_session(self.session_id, {"status": "COMPLETED"})

    # ── Opening Round ────────────────────────────────────────────────

    def _handle_opening_round(self, speaker: str, text: str) -> None:
        """Handle an agent speaking during opening round."""
        if speaker in self._opened_agents:
            return

        self._opened_agents.add(speaker)
        is_invited = (
            self._opening_index < len(self._opening_queue)
            and speaker == self._opening_queue[self._opening_index]
        )

        self.metrics.record_opening_speaker(speaker, out_of_turn=not is_invited)

        if is_invited:
            self._opening_index += 1
            while (self._opening_index < len(self._opening_queue)
                   and self._opening_queue[self._opening_index] in self._opened_agents):
                self._opening_index += 1

        # All agents spoke? Opening round complete — transition to next phase.
        if len(self._opened_agents) >= len(self._opening_queue):
            self._transition_to_next_phase()
            return

        if is_invited:
            self._out_of_turn_count = 0
            if self._opening_index < len(self._opening_queue):
                self._invite_next_opening_agent()
            else:
                self._transition_to_next_phase()
        else:
            self._out_of_turn_count += 1
            if self._out_of_turn_count >= 2:
                # Skip stuck agent
                self.metrics.record_opening_skip(
                    self._opening_queue[self._opening_index]
                )
                self._opening_index += 1
                while (self._opening_index < len(self._opening_queue)
                       and self._opening_queue[self._opening_index] in self._opened_agents):
                    self._opening_index += 1
                if self._opening_index < len(self._opening_queue):
                    self._invite_next_opening_agent()
                else:
                    self._transition_to_next_phase()

    def _invite_next_opening_agent(self) -> None:
        """Post a moderator turn inviting the next agent."""
        if self._opening_index >= len(self._opening_queue):
            return

        agent = self._opening_queue[self._opening_index]
        context = {
            "topic": self.state.topic,
            "agent_name": agent,
            "phase": self.state.phase,
            "opened_so_far": list(self._opened_agents),
        }
        text = self.moderator_fn("invite_opening", context)
        self._commit_moderator_turn(text)

        # Reserve floor for invited agent
        self.backend.reserve_floor(self.session_id, agent)

    def _advance_to_next_phase_if_opening(self) -> None:
        """Start the opening round invitations."""
        if self._opening_index < len(self._opening_queue):
            self._invite_next_opening_agent()

    # ── Phase Transitions ────────────────────────────────────────────

    def _transition_to_next_phase(self) -> None:
        """Move to the next phase in the sequence."""
        current = self.state.phase
        self.metrics.record_phase_end(current)

        next_config = self.phase_manager.advance()
        if not next_config:
            # No more phases — close
            self.run_closing()
            return

        self.state.phase = next_config.name
        self.state.reset_phase_count()
        self.metrics.record_phase_start(next_config.name)

        self.backend.update_session(self.session_id, {"phase": next_config.name})

        # Generate transition turn
        context = {
            "topic": self.state.topic,
            "agents": self.agent_names,
            "phase": next_config.name,
            "previous_phase": current,
            "transcript_summary": self.state.get_last_n_turns_text(6),
        }
        text = self.moderator_fn("phase_transition", context)
        self._commit_moderator_turn(text)

        # If new phase is opening, start invitations
        if next_config.is_opening:
            self._opening_queue = list(self.agent_names)
            self._opening_index = 0
            self._opened_agents.clear()
            self._invite_next_opening_agent()

        # If new phase is terminal, close
        if next_config.is_terminal:
            self.run_closing()

    # ── Interventions ────────────────────────────────────────────────

    def _can_intervene(self) -> bool:
        """Check if enough turns have passed since last intervention."""
        return (self.state.turn_index - self._last_intervention_turn
                >= self.config.intervention_cooldown_turns)

    def _handle_intervention(self, result: InterventionResult) -> None:
        """Handle a detected intervention."""
        self._last_intervention_turn = self.state.turn_index

        self.metrics.record_intervention(
            result.type, result.target_agent,
            self.state.phase, str(result.details),
        )

        context = {
            "topic": self.state.topic,
            "intervention_type": result.type,
            "target_agent": result.target_agent,
            "suggested_action": result.suggested_action,
            "details": result.details,
            "recent_transcript": self.state.get_last_n_turns_text(4),
            "phase": self.state.phase,
        }
        text = self.moderator_fn("intervention", context)
        self._commit_moderator_turn(text)

        # Reserve floor for target if redirecting
        if result.target_agent and result.suggested_action in ("redirect", "pull_in"):
            self.backend.reserve_floor(self.session_id, result.target_agent)

    # ── Helpers ──────────────────────────────────────────────────────

    def _commit_moderator_turn(self, text: str) -> None:
        """Post a moderator turn to the backend."""
        turn = TurnData(
            agent_name="Moderator",
            transcript=text,
            timestamp=datetime.now(timezone.utc).isoformat(),
            is_moderator=True,
            turn_type=self.state.phase.lower(),
        )
        self.backend.post_turn(self.session_id, turn)
