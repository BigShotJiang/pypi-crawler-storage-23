"""
Conviction Tracker — measures and tracks how agent positions evolve through debate.

Research (NeurIPS 2025) shows LLMs exhibit anti-Bayesian behavior during debates —
they become MORE confident when challenged. This module explicitly engineers
conviction tracking with evidence-based drift correction.

Key concepts:
- Each agent has a conviction score (0.0-1.0) per position/topic
- Evidence events (arguments from others) cause drift
- Drift is asymmetric: strong evidence shifts more than weak
- Entrenchment detection: flags agents who never budge
- Convergence detection: flags when agents align
- Full audit trail of conviction changes over time

Example:
    tracker = ConvictionTracker()
    tracker.register("Architect", "use-postgres", initial=0.8)
    tracker.register("SecurityLead", "use-postgres", initial=0.3)

    # After SecurityLead presents encryption concerns
    tracker.record_evidence("Architect", "use-postgres",
        evidence_type=EvidenceType.COUNTER_ARGUMENT,
        source="SecurityLead", strength=0.7,
        description="Encryption at rest not native")

    # Architect's conviction should drift DOWN
    print(tracker.get_conviction("Architect", "use-postgres"))  # ~0.65
"""

from __future__ import annotations

import logging
import math
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable

logger = logging.getLogger("floorctl.conviction")


# ── Enums ────────────────────────────────────────────────────────────

class EvidenceType(str, Enum):
    """Types of evidence that affect conviction."""
    SUPPORTING = "supporting"               # Reinforces position
    COUNTER_ARGUMENT = "counter_argument"   # Challenges position
    NEW_DATA = "new_data"                   # Novel information
    EXPERT_OPINION = "expert_opinion"       # Authority-based
    CONCESSION = "concession"              # Agent's own concession
    REBUTTAL = "rebuttal"                  # Rebuttal of counter-argument


class DriftDirection(str, Enum):
    """Direction of conviction change."""
    STRENGTHENED = "strengthened"
    WEAKENED = "weakened"
    UNCHANGED = "unchanged"


# ── Data Classes ─────────────────────────────────────────────────────

@dataclass
class EvidenceEvent:
    """A single piece of evidence that affects conviction."""
    event_id: int
    agent: str                          # Whose conviction is affected
    position: str                       # The position/topic
    evidence_type: EvidenceType
    source: str                         # Who provided the evidence
    strength: float                     # 0.0-1.0 how strong the evidence is
    description: str = ""
    timestamp: str = ""
    conviction_before: float = 0.0
    conviction_after: float = 0.0
    drift: float = 0.0                  # Actual change (can be negative)


@dataclass
class PositionState:
    """Current state of an agent's conviction on a position."""
    agent: str
    position: str
    conviction: float                   # Current 0.0-1.0
    initial_conviction: float           # Starting point
    total_drift: float = 0.0            # Cumulative absolute drift
    net_drift: float = 0.0              # Current - initial
    evidence_count: int = 0
    last_updated: str = ""
    history: list[float] = field(default_factory=list)  # Conviction over time


@dataclass
class ConvictionSnapshot:
    """Snapshot of all agents' convictions on all positions at a point in time."""
    timestamp: str
    positions: dict[str, dict[str, float]] = field(default_factory=dict)
    # position -> {agent_name: conviction}


# ── Drift Functions ──────────────────────────────────────────────────

def _default_drift_fn(
    current: float,
    evidence_type: EvidenceType,
    strength: float,
) -> float:
    """
    Compute conviction drift based on evidence.

    Uses asymmetric sigmoid-like scaling:
    - Counter-arguments reduce conviction proportionally
    - Supporting evidence increases with diminishing returns
    - Stronger evidence = larger drift
    - Already-extreme convictions are harder to move further

    Returns the new conviction value (clamped to [0.05, 0.95]).
    """
    # Base drift magnitude scales with evidence strength
    base_drift = strength * 0.25  # Max 25% shift per event

    if evidence_type in (EvidenceType.COUNTER_ARGUMENT, EvidenceType.CONCESSION):
        # Reduce conviction — proportional to how much room there is to fall
        room = current - 0.05
        drift = -base_drift * room
    elif evidence_type == EvidenceType.SUPPORTING:
        # Increase conviction — diminishing returns near 1.0
        room = 0.95 - current
        drift = base_drift * room * 0.7  # Dampened — easier to weaken than strengthen
    elif evidence_type == EvidenceType.REBUTTAL:
        # Rebuttal of a counter-argument — moderate strengthening
        room = 0.95 - current
        drift = base_drift * room * 0.5
    elif evidence_type == EvidenceType.NEW_DATA:
        # New data — can go either way based on current position
        # If conviction > 0.5, new data weakens slightly (challenges assumptions)
        # If conviction < 0.5, new data strengthens slightly (fills gaps)
        if current > 0.5:
            room = current - 0.05
            drift = -base_drift * room * 0.4
        else:
            room = 0.95 - current
            drift = base_drift * room * 0.4
    elif evidence_type == EvidenceType.EXPERT_OPINION:
        # Expert opinion — moderate strengthening (authority bias correction)
        room = 0.95 - current
        drift = base_drift * room * 0.6
    else:
        drift = 0.0

    new_conviction = max(0.05, min(0.95, current + drift))
    return round(new_conviction, 4)


# ── Type for custom drift functions ──────────────────────────────────

DriftFn = Callable[[float, EvidenceType, float], float]


# ── Conviction Tracker ──────────────────────────────────────────────

class ConvictionTracker:
    """
    Thread-safe tracker for agent conviction levels across positions.

    Provides:
    - Registration of agent positions with initial conviction
    - Evidence-based conviction drift with pluggable drift function
    - Entrenchment detection (agents who never budge)
    - Convergence detection (agents aligning)
    - Polarization metrics
    - Full audit trail
    """

    def __init__(
        self,
        drift_fn: DriftFn | None = None,
        entrenchment_threshold: float = 0.02,
        convergence_threshold: float = 0.15,
    ) -> None:
        self._lock = threading.RLock()
        self._drift_fn = drift_fn or _default_drift_fn
        self._entrenchment_threshold = entrenchment_threshold
        self._convergence_threshold = convergence_threshold

        # State: position -> agent -> PositionState
        self._positions: dict[str, dict[str, PositionState]] = {}
        # Full event log
        self._events: list[EvidenceEvent] = []
        self._event_counter = 0
        # Subscribers
        self._subscribers: list[Callable[[EvidenceEvent], None]] = []

    def register(
        self,
        agent: str,
        position: str,
        initial: float = 0.5,
    ) -> None:
        """
        Register an agent's stance on a position.

        Args:
            agent: Agent name
            position: Position/topic identifier
            initial: Starting conviction (0.0=opposed, 1.0=fully committed)
        """
        initial = max(0.05, min(0.95, initial))
        now = datetime.now(timezone.utc).isoformat()

        with self._lock:
            if position not in self._positions:
                self._positions[position] = {}

            self._positions[position][agent] = PositionState(
                agent=agent,
                position=position,
                conviction=initial,
                initial_conviction=initial,
                last_updated=now,
                history=[initial],
            )

        logger.info(
            f"[Conviction] {agent} registered on '{position}' "
            f"with conviction {initial:.2f}"
        )

    def record_evidence(
        self,
        agent: str,
        position: str,
        evidence_type: EvidenceType,
        source: str,
        strength: float,
        description: str = "",
    ) -> EvidenceEvent:
        """
        Record evidence that affects an agent's conviction.

        Args:
            agent: Whose conviction is affected
            position: The position being evaluated
            evidence_type: Type of evidence
            source: Who presented the evidence
            strength: How strong the evidence is (0.0-1.0)
            description: What the evidence is

        Returns:
            EvidenceEvent with before/after conviction

        Raises:
            ValueError: If agent not registered on position
        """
        strength = max(0.0, min(1.0, strength))

        with self._lock:
            pos_agents = self._positions.get(position, {})
            state = pos_agents.get(agent)
            if not state:
                raise ValueError(
                    f"Agent '{agent}' not registered on position '{position}'"
                )

            conviction_before = state.conviction
            conviction_after = self._drift_fn(
                conviction_before, evidence_type, strength
            )

            # Update state
            drift = conviction_after - conviction_before
            state.conviction = conviction_after
            state.total_drift += abs(drift)
            state.net_drift = state.conviction - state.initial_conviction
            state.evidence_count += 1
            state.last_updated = datetime.now(timezone.utc).isoformat()
            state.history.append(conviction_after)

            # Record event
            self._event_counter += 1
            event = EvidenceEvent(
                event_id=self._event_counter,
                agent=agent,
                position=position,
                evidence_type=evidence_type,
                source=source,
                strength=strength,
                description=description,
                timestamp=state.last_updated,
                conviction_before=conviction_before,
                conviction_after=conviction_after,
                drift=round(drift, 4),
            )
            self._events.append(event)

        direction = (
            DriftDirection.STRENGTHENED if drift > 0.001
            else DriftDirection.WEAKENED if drift < -0.001
            else DriftDirection.UNCHANGED
        )

        logger.info(
            f"[Conviction] {agent} on '{position}': "
            f"{conviction_before:.3f} → {conviction_after:.3f} "
            f"({direction.value}, {evidence_type.value} from {source})"
        )

        # Notify subscribers
        for cb in self._subscribers:
            try:
                cb(event)
            except Exception as e:
                logger.error(f"[Conviction] Subscriber error: {e}")

        return event

    def get_conviction(self, agent: str, position: str) -> float | None:
        """Get current conviction level. Returns None if not registered."""
        with self._lock:
            state = self._positions.get(position, {}).get(agent)
            return state.conviction if state else None

    def get_state(self, agent: str, position: str) -> PositionState | None:
        """Get full position state for an agent."""
        with self._lock:
            return self._positions.get(position, {}).get(agent)

    def get_all_convictions(self, position: str) -> dict[str, float]:
        """Get all agents' convictions on a position."""
        with self._lock:
            pos = self._positions.get(position, {})
            return {agent: state.conviction for agent, state in pos.items()}

    def get_events(
        self,
        agent: str | None = None,
        position: str | None = None,
    ) -> list[EvidenceEvent]:
        """Get evidence events, optionally filtered."""
        with self._lock:
            events = list(self._events)
        if agent:
            events = [e for e in events if e.agent == agent]
        if position:
            events = [e for e in events if e.position == position]
        return events

    # ── Analysis ─────────────────────────────────────────────────────

    def detect_entrenchment(self, position: str) -> list[str]:
        """
        Find agents who haven't moved despite evidence.

        An entrenched agent has received evidence but their conviction
        has barely changed (total drift < threshold).
        """
        with self._lock:
            pos = self._positions.get(position, {})
            entrenched: list[str] = []
            for agent, state in pos.items():
                if (state.evidence_count >= 2
                        and state.total_drift < self._entrenchment_threshold):
                    entrenched.append(agent)
            return entrenched

    def detect_convergence(self, position: str) -> bool:
        """
        Check if all agents' convictions are converging.

        Returns True if the spread (max - min) is below threshold.
        """
        with self._lock:
            pos = self._positions.get(position, {})
            if len(pos) < 2:
                return False
            convictions = [s.conviction for s in pos.values()]
            spread = max(convictions) - min(convictions)
            return spread < self._convergence_threshold

    def detect_polarization(self, position: str) -> float:
        """
        Measure polarization on a position.

        Returns 0.0 (consensus) to 1.0 (complete polarization).
        Uses standard deviation normalized to max possible spread.
        """
        with self._lock:
            pos = self._positions.get(position, {})
            if len(pos) < 2:
                return 0.0
            convictions = [s.conviction for s in pos.values()]

        mean = sum(convictions) / len(convictions)
        variance = sum((c - mean) ** 2 for c in convictions) / len(convictions)
        std_dev = math.sqrt(variance)
        # Normalize: max std_dev for [0,1] range is 0.5
        return round(min(1.0, std_dev / 0.45), 4)

    def snapshot(self) -> ConvictionSnapshot:
        """Take a snapshot of all current convictions."""
        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            positions: dict[str, dict[str, float]] = {}
            for pos_name, agents in self._positions.items():
                positions[pos_name] = {
                    agent: state.conviction
                    for agent, state in agents.items()
                }
        return ConvictionSnapshot(timestamp=now, positions=positions)

    def biggest_movers(self, position: str) -> list[tuple[str, float]]:
        """
        Get agents ranked by how much their conviction has shifted.

        Returns list of (agent_name, net_drift) sorted by absolute drift.
        """
        with self._lock:
            pos = self._positions.get(position, {})
            movers = [
                (agent, state.net_drift)
                for agent, state in pos.items()
            ]
        movers.sort(key=lambda x: abs(x[1]), reverse=True)
        return movers

    def subscribe(
        self,
        callback: Callable[[EvidenceEvent], None],
    ) -> Callable[[], None]:
        """
        Subscribe to evidence events.

        Returns unsubscribe function.
        """
        self._subscribers.append(callback)

        def unsubscribe() -> None:
            try:
                self._subscribers.remove(callback)
            except ValueError:
                pass

        return unsubscribe

    def to_context(self, position: str | None = None) -> dict[str, Any]:
        """Compact representation for LLM context."""
        with self._lock:
            if position:
                pos = self._positions.get(position, {})
                return {
                    "position": position,
                    "agents": {
                        agent: {
                            "conviction": round(state.conviction, 3),
                            "initial": round(state.initial_conviction, 3),
                            "drift": round(state.net_drift, 3),
                            "evidence_count": state.evidence_count,
                        }
                        for agent, state in pos.items()
                    },
                    "converging": self.detect_convergence(position),
                    "polarization": self.detect_polarization(position),
                    "entrenched": self.detect_entrenchment(position),
                }
            else:
                return {
                    pos_name: {
                        agent: round(state.conviction, 3)
                        for agent, state in agents.items()
                    }
                    for pos_name, agents in self._positions.items()
                }

    def summary(self) -> dict[str, Any]:
        """Summary statistics across all positions."""
        with self._lock:
            total_events = len(self._events)
            total_positions = len(self._positions)
            total_registrations = sum(
                len(agents) for agents in self._positions.values()
            )

            avg_drift = 0.0
            if total_registrations > 0:
                all_drifts = [
                    abs(state.net_drift)
                    for agents in self._positions.values()
                    for state in agents.values()
                ]
                avg_drift = sum(all_drifts) / len(all_drifts) if all_drifts else 0.0

            converging_positions = [
                pos for pos in self._positions
                if self.detect_convergence(pos)
            ]

            return {
                "total_positions": total_positions,
                "total_registrations": total_registrations,
                "total_evidence_events": total_events,
                "avg_absolute_drift": round(avg_drift, 4),
                "converging_positions": converging_positions,
                "positions": {
                    pos_name: {
                        "agents": len(agents),
                        "polarization": self.detect_polarization(pos_name),
                        "converging": self.detect_convergence(pos_name),
                        "entrenched": self.detect_entrenchment(pos_name),
                    }
                    for pos_name, agents in self._positions.items()
                },
            }
