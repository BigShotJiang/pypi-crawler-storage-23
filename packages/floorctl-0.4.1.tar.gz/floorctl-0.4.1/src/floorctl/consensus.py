"""
Consensus Protocol — formal quorum-based decision-making for multi-agent systems.

Unlike "discuss until done," this provides actual voting mechanics:
- Proposals submitted by any agent
- Configurable quorum (majority, supermajority, unanimity)
- Individual veto power (for designated agents)
- Abstention support
- Time-bounded voting rounds
- Full vote audit trail

This is what separates "agents chatting about a decision" from "agents formally deciding."

Example:
    protocol = ConsensusProtocol(
        quorum=QuorumRule.SUPERMAJORITY,
        veto_agents=["ComplianceOfficer"],
    )
    proposal_id = protocol.propose(
        proposer="Architect",
        title="Use PostgreSQL for persistence",
        artifact_id="adr-001",
    )
    protocol.vote(proposal_id, "SecurityLead", VoteChoice.APPROVE, reason="Meets audit needs")
    protocol.vote(proposal_id, "ComplianceOfficer", VoteChoice.APPROVE)
    protocol.vote(proposal_id, "DevLead", VoteChoice.APPROVE)
    result = protocol.resolve(proposal_id, eligible_voters=4)
"""

from __future__ import annotations

import logging
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable

logger = logging.getLogger("floorctl.consensus")


# ── Enums ────────────────────────────────────────────────────────────

class QuorumRule(str, Enum):
    """How many approvals are needed to pass."""
    MAJORITY = "majority"               # > 50%
    SUPERMAJORITY = "supermajority"      # >= 2/3
    UNANIMITY = "unanimity"             # 100%
    THRESHOLD = "threshold"             # Custom percentage


class VoteChoice(str, Enum):
    """Individual vote options."""
    APPROVE = "approve"
    REJECT = "reject"
    ABSTAIN = "abstain"
    VETO = "veto"                       # Blocks regardless of quorum


class ProposalStatus(str, Enum):
    """Lifecycle of a proposal."""
    OPEN = "open"                       # Accepting votes
    PASSED = "passed"                   # Quorum met, approved
    REJECTED = "rejected"              # Quorum not met or majority rejected
    VETOED = "vetoed"                  # Blocked by veto holder
    EXPIRED = "expired"               # Timed out without resolution


# ── Data Classes ─────────────────────────────────────────────────────

@dataclass
class Vote:
    """A single agent's vote on a proposal."""
    voter: str
    choice: VoteChoice
    reason: str = ""
    timestamp: str = ""
    conviction_score: float | None = None  # Links to ConvictionTracker


@dataclass
class Proposal:
    """A formal proposal submitted for consensus voting."""
    proposal_id: str
    proposer: str
    title: str
    description: str = ""
    artifact_id: str | None = None      # Links to ArtifactStore
    status: ProposalStatus = ProposalStatus.OPEN
    created_at: str = ""
    resolved_at: str | None = None
    votes: dict[str, Vote] = field(default_factory=dict)  # voter_name -> Vote
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def vote_counts(self) -> dict[str, int]:
        """Count votes by choice."""
        counts: dict[str, int] = {c.value: 0 for c in VoteChoice}
        for vote in self.votes.values():
            counts[vote.choice.value] += 1
        return counts

    def to_dict(self) -> dict[str, Any]:
        return {
            "proposal_id": self.proposal_id,
            "proposer": self.proposer,
            "title": self.title,
            "description": self.description,
            "artifact_id": self.artifact_id,
            "status": self.status.value,
            "created_at": self.created_at,
            "resolved_at": self.resolved_at,
            "vote_counts": self.vote_counts,
            "votes": {
                name: {
                    "choice": v.choice.value,
                    "reason": v.reason,
                    "conviction": v.conviction_score,
                }
                for name, v in self.votes.items()
            },
        }

    def to_context(self) -> dict[str, Any]:
        """Compact representation for LLM context."""
        return {
            "id": self.proposal_id,
            "title": self.title,
            "status": self.status.value,
            "proposer": self.proposer,
            "artifact_id": self.artifact_id,
            "votes": self.vote_counts,
            "voters": list(self.votes.keys()),
        }


@dataclass
class ConsensusResult:
    """Outcome of resolving a proposal."""
    proposal_id: str
    status: ProposalStatus
    approval_rate: float               # 0.0 - 1.0
    quorum_met: bool
    vetoed_by: str | None = None
    vote_summary: dict[str, int] = field(default_factory=dict)
    eligible_voters: int = 0
    actual_voters: int = 0


# ── Configuration ────────────────────────────────────────────────────

@dataclass
class ConsensusConfig:
    """Configuration for the consensus protocol."""
    quorum_rule: QuorumRule = QuorumRule.MAJORITY
    custom_threshold: float = 0.5      # Used when quorum_rule is THRESHOLD
    veto_agents: list[str] = field(default_factory=list)
    allow_abstain: bool = True
    require_reason: bool = False       # Voters must provide reasoning
    max_voting_rounds: int = 3         # Max re-votes after amendments


# ── Consensus Protocol ──────────────────────────────────────────────

class ConsensusProtocol:
    """
    Thread-safe consensus protocol for multi-agent decision-making.

    Provides:
    - Proposal creation with optional artifact linkage
    - Configurable quorum rules (majority, supermajority, unanimity, custom)
    - Veto power for designated agents
    - Vote audit trail with reasons
    - Resolution with detailed outcome
    """

    def __init__(self, config: ConsensusConfig | None = None) -> None:
        self._lock = threading.Lock()
        self.config = config or ConsensusConfig()
        self._proposals: dict[str, Proposal] = {}
        self._subscribers: list[Callable[[str, Proposal], None]] = []
        self._history: list[ConsensusResult] = []

    def propose(
        self,
        proposer: str,
        title: str,
        description: str = "",
        artifact_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """
        Submit a new proposal for voting.

        Args:
            proposer: Agent creating the proposal
            title: Short title
            description: Detailed description
            artifact_id: Optional link to an Artifact
            metadata: Additional data

        Returns:
            proposal_id
        """
        proposal_id = f"prop-{uuid.uuid4().hex[:8]}"
        now = datetime.now(timezone.utc).isoformat()

        proposal = Proposal(
            proposal_id=proposal_id,
            proposer=proposer,
            title=title,
            description=description,
            artifact_id=artifact_id,
            created_at=now,
            metadata=metadata or {},
        )

        with self._lock:
            self._proposals[proposal_id] = proposal

        logger.info(
            f"[Consensus] Proposal '{title}' by {proposer} "
            f"(id={proposal_id})"
        )

        self._notify("proposed", proposal)
        return proposal_id

    def vote(
        self,
        proposal_id: str,
        voter: str,
        choice: VoteChoice,
        reason: str = "",
        conviction_score: float | None = None,
    ) -> Vote:
        """
        Cast a vote on a proposal.

        Args:
            proposal_id: ID of the proposal
            voter: Voting agent name
            choice: APPROVE, REJECT, ABSTAIN, or VETO
            reason: Reasoning for the vote
            conviction_score: Optional link to agent's conviction level

        Returns:
            The recorded Vote

        Raises:
            ValueError: If proposal not found, already resolved, or invalid vote
        """
        with self._lock:
            proposal = self._proposals.get(proposal_id)
            if not proposal:
                raise ValueError(f"Proposal '{proposal_id}' not found")

            if proposal.status != ProposalStatus.OPEN:
                raise ValueError(
                    f"Proposal '{proposal_id}' is already {proposal.status.value}"
                )

            # Veto check — only designated agents can veto
            if choice == VoteChoice.VETO and voter not in self.config.veto_agents:
                raise ValueError(
                    f"Agent '{voter}' does not have veto power. "
                    f"Veto agents: {self.config.veto_agents}"
                )

            # Reason requirement
            if self.config.require_reason and not reason and choice != VoteChoice.ABSTAIN:
                raise ValueError("A reason is required for this vote")

            vote = Vote(
                voter=voter,
                choice=choice,
                reason=reason,
                timestamp=datetime.now(timezone.utc).isoformat(),
                conviction_score=conviction_score,
            )
            proposal.votes[voter] = vote

        logger.info(
            f"[Consensus] {voter} voted {choice.value} on '{proposal.title}'"
            + (f" — {reason}" if reason else "")
        )

        self._notify("voted", proposal)
        return vote

    def resolve(
        self,
        proposal_id: str,
        eligible_voters: int,
    ) -> ConsensusResult:
        """
        Resolve a proposal based on current votes and quorum rules.

        Args:
            proposal_id: ID of the proposal to resolve
            eligible_voters: Total number of agents who could vote

        Returns:
            ConsensusResult with detailed outcome
        """
        with self._lock:
            proposal = self._proposals.get(proposal_id)
            if not proposal:
                raise ValueError(f"Proposal '{proposal_id}' not found")

            if proposal.status != ProposalStatus.OPEN:
                raise ValueError(
                    f"Proposal '{proposal_id}' is already {proposal.status.value}"
                )

            counts = proposal.vote_counts
            now = datetime.now(timezone.utc).isoformat()

            # Check for veto
            veto_voter = None
            for name, vote in proposal.votes.items():
                if vote.choice == VoteChoice.VETO:
                    veto_voter = name
                    break

            if veto_voter:
                proposal.status = ProposalStatus.VETOED
                proposal.resolved_at = now
                result = ConsensusResult(
                    proposal_id=proposal_id,
                    status=ProposalStatus.VETOED,
                    approval_rate=0.0,
                    quorum_met=False,
                    vetoed_by=veto_voter,
                    vote_summary=counts,
                    eligible_voters=eligible_voters,
                    actual_voters=len(proposal.votes),
                )
                self._history.append(result)
                self._notify("resolved", proposal)
                return result

            # Calculate approval rate (excluding abstentions)
            non_abstain = counts["approve"] + counts["reject"]
            approval_rate = (
                counts["approve"] / non_abstain if non_abstain > 0 else 0.0
            )

            # Check quorum
            quorum_met = self._check_quorum(
                approvals=counts["approve"],
                rejections=counts["reject"],
                abstentions=counts["abstain"],
                eligible=eligible_voters,
            )

            # Determine outcome
            if quorum_met and approval_rate > 0.5:
                proposal.status = ProposalStatus.PASSED
            else:
                proposal.status = ProposalStatus.REJECTED

            proposal.resolved_at = now
            result = ConsensusResult(
                proposal_id=proposal_id,
                status=proposal.status,
                approval_rate=round(approval_rate, 4),
                quorum_met=quorum_met,
                vote_summary=counts,
                eligible_voters=eligible_voters,
                actual_voters=len(proposal.votes),
            )
            self._history.append(result)

        logger.info(
            f"[Consensus] Proposal '{proposal.title}' → {proposal.status.value} "
            f"(approval={approval_rate:.0%}, quorum={'met' if quorum_met else 'NOT met'})"
        )

        self._notify("resolved", proposal)
        return result

    def get_proposal(self, proposal_id: str) -> Proposal | None:
        """Get a proposal by ID."""
        with self._lock:
            return self._proposals.get(proposal_id)

    def list_proposals(
        self,
        status: ProposalStatus | None = None,
    ) -> list[Proposal]:
        """List proposals, optionally filtered by status."""
        with self._lock:
            results = list(self._proposals.values())
        if status:
            results = [p for p in results if p.status == status]
        return results

    def get_results(self) -> list[ConsensusResult]:
        """Get all resolution results."""
        with self._lock:
            return list(self._history)

    def subscribe(
        self,
        callback: Callable[[str, Proposal], None],
    ) -> Callable[[], None]:
        """
        Subscribe to consensus events.

        Callback receives (event_type, proposal).
        event_type: "proposed" | "voted" | "resolved"

        Returns unsubscribe function.
        """
        self._subscribers.append(callback)

        def unsubscribe() -> None:
            try:
                self._subscribers.remove(callback)
            except ValueError:
                pass

        return unsubscribe

    def to_context(self) -> list[dict[str, Any]]:
        """Get open proposals in compact form for LLM context."""
        with self._lock:
            return [
                p.to_context()
                for p in self._proposals.values()
                if p.status == ProposalStatus.OPEN
            ]

    def summary(self) -> dict[str, Any]:
        """Summary statistics for the consensus protocol."""
        with self._lock:
            total = len(self._proposals)
            by_status = {}
            for p in self._proposals.values():
                by_status[p.status.value] = by_status.get(p.status.value, 0) + 1

            avg_approval = 0.0
            if self._history:
                avg_approval = sum(r.approval_rate for r in self._history) / len(self._history)

            return {
                "total_proposals": total,
                "by_status": by_status,
                "avg_approval_rate": round(avg_approval, 4),
                "total_vetoes": sum(
                    1 for r in self._history if r.status == ProposalStatus.VETOED
                ),
                "quorum_rule": self.config.quorum_rule.value,
                "veto_agents": self.config.veto_agents,
            }

    # ── Internal ─────────────────────────────────────────────────────

    def _check_quorum(
        self,
        approvals: int,
        rejections: int,
        abstentions: int,
        eligible: int,
    ) -> bool:
        """Check if quorum requirements are met."""
        total_votes = approvals + rejections  # Abstentions don't count toward quorum
        rule = self.config.quorum_rule

        if rule == QuorumRule.MAJORITY:
            # At least half of eligible voters must cast a non-abstain vote
            return total_votes >= (eligible / 2)

        elif rule == QuorumRule.SUPERMAJORITY:
            # At least 2/3 of eligible must approve
            return approvals >= (eligible * 2 / 3)

        elif rule == QuorumRule.UNANIMITY:
            # All eligible must approve (no rejections, no missing votes)
            return approvals == eligible

        elif rule == QuorumRule.THRESHOLD:
            # Custom threshold
            return approvals >= (eligible * self.config.custom_threshold)

        return False

    def _notify(self, event: str, proposal: Proposal) -> None:
        """Notify subscribers."""
        for cb in self._subscribers:
            try:
                cb(event, proposal)
            except Exception as e:
                logger.error(f"[Consensus] Subscriber error: {e}")
