from floorctl.backends.base import Backend
from floorctl.backends.memory import InMemoryBackend

__all__ = ["Backend", "InMemoryBackend"]

# Optional backends — import only if dependencies are available

try:
    from floorctl.backends.websocket import WebSocketBackend
    __all__.append("WebSocketBackend")
except ImportError:
    pass

try:
    from floorctl.backends.firestore import FirestoreBackend
    __all__.append("FirestoreBackend")
except ImportError:
    pass
