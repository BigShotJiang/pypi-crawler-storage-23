"""
WebSocket backend — distributed coordination via a relay server.

Implements the Backend Protocol over WebSocket, allowing agents on separate
machines to coordinate through a shared relay server.

Usage:
    from floorctl.backends.websocket import WebSocketBackend

    backend = WebSocketBackend("ws://relay.example.com:8765", api_key="mykey")
    backend.connect()

    # Now use it exactly like InMemoryBackend
    agent = FloorAgent(name="Alice", ..., backend=backend)
    session = FloorSession(backend=backend)
    session.add_agent(agent)
    result = session.run("session-001", topic="...")

    backend.disconnect()
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import json
import logging
import threading
import uuid
from typing import Any, Callable

import websockets

from floorctl.types import SessionState, TurnData, TurnRecord

logger = logging.getLogger("floorctl.ws")


class WebSocketBackend:
    """
    Distributed backend using WebSocket relay server.

    Provides the same Backend Protocol as InMemoryBackend but communicates
    with a remote relay server for multi-machine coordination.

    The sync API (required by Backend Protocol) is backed by a background
    asyncio event loop running in a daemon thread.
    """

    def __init__(
        self,
        relay_url: str,
        api_key: str | None = None,
        agent_name: str | None = None,
    ) -> None:
        self._relay_url = relay_url
        self._api_key = api_key
        self._agent_name = agent_name

        # Background event loop for async WebSocket ops
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._ws: websockets.ClientConnection | None = None
        self._connected = threading.Event()

        # Subscription callbacks (local)
        self._turn_subscribers: dict[str, list[Callable[[TurnRecord], None]]] = {}
        self._session_subscribers: dict[str, list[Callable[[SessionState], None]]] = {}

        # Request/response correlation (use concurrent.futures for cross-thread)
        self._pending: dict[str, concurrent.futures.Future[dict[str, Any]]] = {}
        self._request_counter = 0

    # ── Connection Lifecycle ─────────────────────────────────────────

    def connect(self, timeout: float = 10.0) -> None:
        """Connect to the relay server. Blocks until connected."""
        if self._loop is not None:
            return

        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(
            target=self._run_loop, daemon=True, name="ws-backend"
        )
        self._thread.start()

        if not self._connected.wait(timeout=timeout):
            raise ConnectionError(f"Failed to connect to {self._relay_url}")

    def disconnect(self) -> None:
        """Disconnect from the relay server."""
        if self._loop and self._ws:
            future = asyncio.run_coroutine_threadsafe(
                self._ws.close(), self._loop
            )
            try:
                future.result(timeout=5.0)
            except Exception:
                pass
        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread:
            self._thread.join(timeout=5.0)
        self._loop = None
        self._thread = None
        self._ws = None
        self._connected.clear()

    def _run_loop(self) -> None:
        """Background thread running the asyncio event loop."""
        assert self._loop is not None
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._connect_and_listen())

    async def _connect_and_listen(self) -> None:
        """Connect, authenticate, and listen for messages."""
        try:
            self._ws = await websockets.connect(self._relay_url)

            # Authenticate
            auth_msg = {"action": "auth", "api_key": self._api_key or ""}
            if self._agent_name:
                auth_msg["agent_name"] = self._agent_name
            await self._ws.send(json.dumps(auth_msg))

            response = await asyncio.wait_for(self._ws.recv(), timeout=10.0)
            data = json.loads(response)
            if data.get("action") != "auth_ok":
                raise ConnectionError(f"Auth failed: {data.get('error', 'unknown')}")

            self._connected.set()
            logger.info("Connected to relay: %s", self._relay_url)

            # Listen for messages
            async for raw in self._ws:
                try:
                    msg = json.loads(raw)
                    await self._handle_server_message(msg)
                except json.JSONDecodeError:
                    logger.warning("Invalid JSON from relay")
                except Exception:
                    logger.exception("Error handling relay message")

        except websockets.exceptions.ConnectionClosed:
            logger.warning("Relay connection closed")
        except Exception:
            logger.exception("Relay connection error")
        finally:
            self._connected.clear()

    async def _handle_server_message(self, msg: dict[str, Any]) -> None:
        """Handle a message from the relay server."""
        action = msg.get("action")
        request_id = msg.get("request_id")

        # Correlation: resolve pending request (concurrent.futures.Future)
        if request_id and request_id in self._pending:
            future = self._pending[request_id]
            future.set_result(msg)
            return

        # Broadcast: new turn
        if action == "new_turn":
            session_id = msg["session_id"]
            turn_data = msg["turn"]
            record = TurnRecord(
                speaker=turn_data["speaker"],
                text=turn_data["text"],
                phase=turn_data.get("phase", ""),
                turn_index=turn_data.get("turn_index", 0),
                timestamp=turn_data.get("timestamp", ""),
                is_moderator=turn_data.get("is_moderator", False),
            )
            for cb in self._turn_subscribers.get(session_id, []):
                try:
                    cb(record)
                except Exception:
                    logger.exception("Turn subscriber error")
            return

        # Broadcast: session state update
        if action == "session_update":
            session_id = msg["session_id"]
            state: SessionState = msg["state"]
            for cb in self._session_subscribers.get(session_id, []):
                try:
                    cb(state)
                except Exception:
                    logger.exception("Session subscriber error")
            return

    # ── Request/Response Helpers ─────────────────────────────────────

    def _send_and_wait(
        self, msg: dict[str, Any], timeout: float = 30.0
    ) -> dict[str, Any]:
        """Send a message and wait for the correlated response."""
        if not self._loop or not self._ws or not self._connected.is_set():
            raise ConnectionError("Not connected to relay")

        request_id = f"req-{self._request_counter}"
        self._request_counter += 1
        msg["request_id"] = request_id

        future: concurrent.futures.Future[dict[str, Any]] = concurrent.futures.Future()
        self._pending[request_id] = future

        asyncio.run_coroutine_threadsafe(
            self._ws.send(json.dumps(msg)), self._loop
        )

        try:
            result = future.result(timeout=timeout)
        finally:
            self._pending.pop(request_id, None)

        if "error" in result:
            raise RuntimeError(result["error"])
        return result

    # ── Backend Protocol Implementation ──────────────────────────────

    def create_session(self, session_id: str, config: dict[str, Any]) -> None:
        self._send_and_wait({
            "action": "create_session",
            "session_id": session_id,
            "config": config,
        })

    def get_session_state(self, session_id: str) -> SessionState:
        result = self._send_and_wait({
            "action": "get_session_state",
            "session_id": session_id,
        })
        return result["state"]

    def update_session(self, session_id: str, updates: dict[str, Any]) -> None:
        self._send_and_wait({
            "action": "update_session",
            "session_id": session_id,
            "updates": updates,
        })

    def claim_floor(
        self, session_id: str, agent_name: str, timeout_seconds: float
    ) -> bool:
        result = self._send_and_wait({
            "action": "claim_floor",
            "session_id": session_id,
            "agent_name": agent_name,
            "timeout_seconds": timeout_seconds,
        })
        return result.get("result", False)

    def release_floor(
        self, session_id: str, agent_name: str, posted_successfully: bool
    ) -> None:
        self._send_and_wait({
            "action": "release_floor",
            "session_id": session_id,
            "agent_name": agent_name,
            "posted_successfully": posted_successfully,
        })

    def reserve_floor(
        self, session_id: str, for_agent: str, duration_seconds: float = 30.0
    ) -> None:
        self._send_and_wait({
            "action": "reserve_floor",
            "session_id": session_id,
            "for_agent": for_agent,
            "duration_seconds": duration_seconds,
        })

    def post_turn(self, session_id: str, turn: TurnData) -> str:
        result = self._send_and_wait({
            "action": "post_turn",
            "session_id": session_id,
            "turn": {
                "agent_name": turn.agent_name,
                "transcript": turn.transcript,
                "timestamp": turn.timestamp,
                "is_moderator": turn.is_moderator,
                "turn_type": turn.turn_type,
            },
        })
        return result.get("turn_id", "")

    def get_turns(self, session_id: str, since_index: int = 0) -> list[TurnRecord]:
        result = self._send_and_wait({
            "action": "get_turns",
            "session_id": session_id,
            "since_index": since_index,
        })
        return [
            TurnRecord(
                speaker=t["speaker"],
                text=t["text"],
                phase=t.get("phase", ""),
                turn_index=t.get("turn_index", 0),
                timestamp=t.get("timestamp", ""),
                is_moderator=t.get("is_moderator", False),
            )
            for t in result.get("turns", [])
        ]

    def subscribe_turns(
        self, session_id: str, callback: Callable[[TurnRecord], None]
    ) -> Callable[[], None]:
        self._turn_subscribers.setdefault(session_id, []).append(callback)

        # Tell relay we want broadcasts for this session
        if self._loop and self._ws and self._connected.is_set():
            asyncio.run_coroutine_threadsafe(
                self._ws.send(json.dumps({
                    "action": "subscribe",
                    "session_id": session_id,
                })),
                self._loop,
            )

        def unsubscribe() -> None:
            try:
                self._turn_subscribers[session_id].remove(callback)
            except (ValueError, KeyError):
                pass

        return unsubscribe

    def subscribe_session(
        self, session_id: str, callback: Callable[[SessionState], None]
    ) -> Callable[[], None]:
        self._session_subscribers.setdefault(session_id, []).append(callback)

        # Subscribe on relay too (same subscribe message covers both)
        if self._loop and self._ws and self._connected.is_set():
            asyncio.run_coroutine_threadsafe(
                self._ws.send(json.dumps({
                    "action": "subscribe",
                    "session_id": session_id,
                })),
                self._loop,
            )

        def unsubscribe() -> None:
            try:
                self._session_subscribers[session_id].remove(callback)
            except (ValueError, KeyError):
                pass

        return unsubscribe

    def store_metrics(
        self, session_id: str, agent_name: str, data: dict[str, Any]
    ) -> None:
        self._send_and_wait({
            "action": "store_metrics",
            "session_id": session_id,
            "agent_name": agent_name,
            "data": data,
        })
