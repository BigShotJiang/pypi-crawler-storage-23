"""
Firestore backend — distributed coordination via Google Cloud Firestore.

Uses Firestore transactions for atomic floor control and onSnapshot for
real-time subscriptions. Designed for production use with the Sangam web app.

Requires: pip install floorctl[firestore]

Usage:
    from firebase_admin import firestore
    from floorctl.backends.firestore import FirestoreBackend

    db = firestore.client()
    backend = FirestoreBackend(db, collection_prefix="agents/myagent/sangam")
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from typing import Any, Callable

try:
    from google.cloud import firestore  # type: ignore[import-untyped]
    from google.cloud.firestore_v1 import DocumentSnapshot  # type: ignore[import-untyped]
    from google.cloud.firestore_v1.watch import DocumentChange  # type: ignore[import-untyped]
except ImportError:
    raise ImportError(
        "FirestoreBackend requires firebase-admin. "
        "Install with: pip install floorctl[firestore]"
    )

from floorctl.types import SessionState, TurnData, TurnRecord

logger = logging.getLogger("floorctl.firestore")


class FirestoreBackend:
    """
    Distributed backend using Google Cloud Firestore.

    Collection structure:
        {collection_prefix}/{session_id}          — session document
        {collection_prefix}/{session_id}/turns/    — turn subcollection

    Provides the same guarantees as InMemoryBackend:
    - Atomic floor claims via Firestore transactions
    - Real-time turn/session subscriptions via onSnapshot
    """

    def __init__(
        self,
        db: firestore.Client,
        collection_prefix: str = "floorctl_sessions",
    ) -> None:
        self._db = db
        self._prefix = collection_prefix

        # Local subscriber lists (callbacks fire from snapshot listeners)
        self._turn_subscribers: dict[str, list[Callable[[TurnRecord], None]]] = {}
        self._session_subscribers: dict[str, list[Callable[[SessionState], None]]] = {}

        # Track snapshot listeners for cleanup
        self._watchers: list[Any] = []

        # Track last known turn count to only fire callbacks for new turns
        self._last_turn_index: dict[str, int] = {}

    def _session_ref(self, session_id: str) -> firestore.DocumentReference:
        return self._db.collection(self._prefix).document(session_id)

    def _turns_col(self, session_id: str) -> firestore.CollectionReference:
        return self._session_ref(session_id).collection("turns")

    # ── Session Operations ───────────────────────────────────────────

    def create_session(self, session_id: str, config: dict[str, Any]) -> None:
        doc_ref = self._session_ref(session_id)
        doc = doc_ref.get()
        if doc.exists:
            return  # Preserve existing session (idempotent)

        doc_ref.set({
            "config": config,
            "status": "WAITING",
            "phase": config.get("phase", ""),
            "topic": config.get("topic", ""),
            "active_speaker": None,
            "speaker_done": True,
            "floor_claimed_at": 0.0,
            "floor_reserved_for": None,
            "floor_reserved_at": 0.0,
            "floor_released_without_post": False,
            "floor_released_by": None,
            "turn_number": 0,
            "participants": config.get("participants", []),
        })
        self._last_turn_index[session_id] = 0
        logger.info("Session created in Firestore: %s", session_id)

    def get_session_state(self, session_id: str) -> SessionState:
        doc = self._session_ref(session_id).get()
        if not doc.exists:
            raise KeyError(f"Session not found: {session_id}")
        data = doc.to_dict()
        return SessionState(
            status=data.get("status", "WAITING"),
            phase=data.get("phase", ""),
            topic=data.get("topic", ""),
            active_speaker=data.get("active_speaker"),
            speaker_done=data.get("speaker_done", True),
            floor_reserved_for=data.get("floor_reserved_for"),
            floor_reserved_at=data.get("floor_reserved_at", 0.0),
            floor_released_without_post=data.get("floor_released_without_post", False),
            floor_released_by=data.get("floor_released_by"),
            turn_number=data.get("turn_number", 0),
            participants=data.get("participants", []),
        )

    def update_session(self, session_id: str, updates: dict[str, Any]) -> None:
        # Filter out fields that shouldn't be updated directly
        safe_updates = {
            k: v for k, v in updates.items()
            if k not in ("config", "turns", "metrics")
        }
        self._session_ref(session_id).update(safe_updates)

    # ── Floor Control (Transactional) ────────────────────────────────

    def claim_floor(
        self, session_id: str, agent_name: str, timeout_seconds: float
    ) -> bool:
        doc_ref = self._session_ref(session_id)

        @firestore.transactional
        def _claim(transaction: firestore.Transaction) -> bool:
            doc = doc_ref.get(transaction=transaction)
            if not doc.exists:
                return False

            data = doc.to_dict()
            now = time.time()

            # Check reservation
            reserved_for = data.get("floor_reserved_for")
            if reserved_for and reserved_for != agent_name:
                reserved_at = data.get("floor_reserved_at", 0.0)
                if (now - reserved_at) < 30.0:
                    return False

            # Check if floor is currently held
            active = data.get("active_speaker")
            done = data.get("speaker_done", True)
            if active and not done:
                if active == agent_name:
                    return True  # Already holding
                claimed_at = data.get("floor_claimed_at", 0.0)
                if (now - claimed_at) < timeout_seconds:
                    return False

            # Claim the floor
            transaction.update(doc_ref, {
                "active_speaker": agent_name,
                "speaker_done": False,
                "floor_claimed_at": now,
                "floor_released_without_post": False,
                "floor_released_by": None,
            })
            return True

        transaction = self._db.transaction()
        return _claim(transaction)

    def release_floor(
        self, session_id: str, agent_name: str, posted_successfully: bool
    ) -> None:
        doc_ref = self._session_ref(session_id)

        @firestore.transactional
        def _release(transaction: firestore.Transaction) -> None:
            doc = doc_ref.get(transaction=transaction)
            if not doc.exists:
                return

            data = doc.to_dict()
            if data.get("active_speaker") == agent_name:
                updates: dict[str, Any] = {
                    "active_speaker": None,
                    "speaker_done": True,
                }
                if not posted_successfully:
                    updates["floor_released_without_post"] = True
                    updates["floor_released_by"] = agent_name
                transaction.update(doc_ref, updates)

        transaction = self._db.transaction()
        _release(transaction)

    def reserve_floor(
        self, session_id: str, for_agent: str, duration_seconds: float = 30.0
    ) -> None:
        self._session_ref(session_id).update({
            "floor_reserved_for": for_agent,
            "floor_reserved_at": time.time(),
        })

    # ── Turns ────────────────────────────────────────────────────────

    def post_turn(self, session_id: str, turn: TurnData) -> str:
        turn_id = str(uuid.uuid4())[:8]
        doc_ref = self._session_ref(session_id)

        @firestore.transactional
        def _post(transaction: firestore.Transaction) -> int:
            doc = doc_ref.get(transaction=transaction)
            data = doc.to_dict()
            turn_number = data.get("turn_number", 0)

            # Write turn to subcollection
            turn_doc = self._turns_col(session_id).document(turn_id)
            transaction.set(turn_doc, {
                "speaker": turn.agent_name,
                "text": turn.transcript,
                "phase": data.get("phase", ""),
                "turn_index": turn_number,
                "timestamp": turn.timestamp,
                "is_moderator": turn.is_moderator,
            })

            # Increment turn counter + clear reservation
            updates: dict[str, Any] = {"turn_number": turn_number + 1}
            if data.get("floor_reserved_for") == turn.agent_name:
                updates["floor_reserved_for"] = None
            transaction.update(doc_ref, updates)

            return turn_number

        transaction = self._db.transaction()
        _post(transaction)
        return turn_id

    def get_turns(self, session_id: str, since_index: int = 0) -> list[TurnRecord]:
        query = (
            self._turns_col(session_id)
            .where("turn_index", ">=", since_index)
            .order_by("turn_index")
        )
        return [
            TurnRecord(
                speaker=doc.get("speaker", ""),
                text=doc.get("text", ""),
                phase=doc.get("phase", ""),
                turn_index=doc.get("turn_index", 0),
                timestamp=doc.get("timestamp", ""),
                is_moderator=doc.get("is_moderator", False),
            )
            for doc in query.stream()
        ]

    # ── Subscriptions (onSnapshot) ───────────────────────────────────

    def subscribe_turns(
        self, session_id: str, callback: Callable[[TurnRecord], None]
    ) -> Callable[[], None]:
        self._turn_subscribers.setdefault(session_id, []).append(callback)
        self._last_turn_index.setdefault(session_id, 0)

        # Set up Firestore snapshot listener on turns subcollection
        def on_snapshot(col_snapshot: list[DocumentSnapshot], changes: list[DocumentChange], read_time: Any) -> None:
            for change in changes:
                if change.type.name == "ADDED":
                    data = change.document.to_dict()
                    turn_idx = data.get("turn_index", 0)
                    # Only fire for genuinely new turns
                    if turn_idx >= self._last_turn_index.get(session_id, 0):
                        record = TurnRecord(
                            speaker=data.get("speaker", ""),
                            text=data.get("text", ""),
                            phase=data.get("phase", ""),
                            turn_index=turn_idx,
                            timestamp=data.get("timestamp", ""),
                            is_moderator=data.get("is_moderator", False),
                        )
                        self._last_turn_index[session_id] = turn_idx + 1
                        for cb in self._turn_subscribers.get(session_id, []):
                            try:
                                cb(record)
                            except Exception:
                                logger.exception("Turn subscriber error")

        watcher = self._turns_col(session_id).on_snapshot(on_snapshot)
        self._watchers.append(watcher)

        def unsubscribe() -> None:
            try:
                self._turn_subscribers[session_id].remove(callback)
            except (ValueError, KeyError):
                pass
            try:
                watcher.unsubscribe()
                self._watchers.remove(watcher)
            except (ValueError, AttributeError):
                pass

        return unsubscribe

    def subscribe_session(
        self, session_id: str, callback: Callable[[SessionState], None]
    ) -> Callable[[], None]:
        self._session_subscribers.setdefault(session_id, []).append(callback)

        def on_snapshot(doc_snapshot: list[DocumentSnapshot], changes: list[DocumentChange], read_time: Any) -> None:
            for doc in doc_snapshot:
                if doc.exists:
                    data = doc.to_dict()
                    state = SessionState(
                        status=data.get("status", "WAITING"),
                        phase=data.get("phase", ""),
                        topic=data.get("topic", ""),
                        active_speaker=data.get("active_speaker"),
                        speaker_done=data.get("speaker_done", True),
                        floor_reserved_for=data.get("floor_reserved_for"),
                        floor_reserved_at=data.get("floor_reserved_at", 0.0),
                        floor_released_without_post=data.get("floor_released_without_post", False),
                        floor_released_by=data.get("floor_released_by"),
                        turn_number=data.get("turn_number", 0),
                        participants=data.get("participants", []),
                    )
                    for cb in self._session_subscribers.get(session_id, []):
                        try:
                            cb(state)
                        except Exception:
                            logger.exception("Session subscriber error")

        watcher = self._session_ref(session_id).on_snapshot(on_snapshot)
        self._watchers.append(watcher)

        def unsubscribe() -> None:
            try:
                self._session_subscribers[session_id].remove(callback)
            except (ValueError, KeyError):
                pass
            try:
                watcher.unsubscribe()
                self._watchers.remove(watcher)
            except (ValueError, AttributeError):
                pass

        return unsubscribe

    # ── Metrics ──────────────────────────────────────────────────────

    def store_metrics(
        self, session_id: str, agent_name: str, data: dict[str, Any]
    ) -> None:
        self._session_ref(session_id).collection("metrics").document(
            agent_name
        ).set(data)

    # ── Cleanup ──────────────────────────────────────────────────────

    def close(self) -> None:
        """Unsubscribe all snapshot listeners."""
        for watcher in self._watchers:
            try:
                watcher.unsubscribe()
            except Exception:
                pass
        self._watchers.clear()
