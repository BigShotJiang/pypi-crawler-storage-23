"""
Backend protocol — the coordination substrate.

All state flows through this interface. Backends must guarantee:
1. claim_floor() is atomic (only one agent wins at a time)
2. on_new_turn callbacks fire for every posted turn
3. session state changes propagate to subscribers
"""

from __future__ import annotations

from typing import Any, Callable, Protocol

from floorctl.types import SessionState, TurnData, TurnRecord


class Backend(Protocol):
    """
    Protocol for multi-agent coordination backends.

    Implementations:
    - InMemoryBackend: threading.Lock for atomicity (testing, single-process)
    - FirestoreBackend: Firestore transactions (production, distributed)
    - RedisBackend: SET NX + Pub/Sub (production, distributed)
    """

    def create_session(self, session_id: str, config: dict[str, Any]) -> None:
        """Create a new session with initial state."""
        ...

    def get_session_state(self, session_id: str) -> SessionState:
        """Get current session state."""
        ...

    def update_session(self, session_id: str, updates: dict[str, Any]) -> None:
        """Update session-level fields (phase, status, floor signals)."""
        ...

    def claim_floor(
        self, session_id: str, agent_name: str, timeout_seconds: float
    ) -> bool:
        """
        Atomically claim the floor. Returns True if this agent won.

        Must handle:
        - Current holder check (reject if floor is held and not timed out)
        - Timeout expiry (allow claim if holder exceeded timeout)
        - Floor reservation (only reserved agent can claim)
        """
        ...

    def release_floor(
        self, session_id: str, agent_name: str, posted_successfully: bool
    ) -> None:
        """Release the floor. Signal to other agents if post failed."""
        ...

    def reserve_floor(
        self, session_id: str, for_agent: str, duration_seconds: float = 30.0
    ) -> None:
        """Reserve the floor for a specific agent (moderator intervention)."""
        ...

    def post_turn(self, session_id: str, turn: TurnData) -> str:
        """Post a turn to the session transcript. Returns turn_id."""
        ...

    def get_turns(self, session_id: str, since_index: int = 0) -> list[TurnRecord]:
        """Get turns from the transcript, optionally since a given index."""
        ...

    def subscribe_turns(
        self, session_id: str, callback: Callable[[TurnRecord], None]
    ) -> Callable[[], None]:
        """
        Subscribe to new turns. Returns an unsubscribe function.
        Callback fires for each new turn (NOT replayed history).
        """
        ...

    def subscribe_session(
        self, session_id: str, callback: Callable[[SessionState], None]
    ) -> Callable[[], None]:
        """Subscribe to session-level state changes."""
        ...

    def store_metrics(
        self, session_id: str, agent_name: str, data: dict[str, Any]
    ) -> None:
        """Persist agent metrics for a session."""
        ...
