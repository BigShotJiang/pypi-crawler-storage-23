"""
In-memory backend — for testing and single-process usage.

Uses threading.Lock for floor atomicity and callback lists for subscriptions.
"""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable

from floorctl.types import SessionState, TurnData, TurnRecord


@dataclass
class _SessionData:
    """Internal session storage."""
    config: dict[str, Any] = field(default_factory=dict)
    status: str = "WAITING"
    phase: str = ""
    topic: str = ""
    active_speaker: str | None = None
    speaker_done: bool = True
    floor_claimed_at: float = 0.0
    floor_reserved_for: str | None = None
    floor_reserved_at: float = 0.0
    floor_released_without_post: bool = False
    floor_released_by: str | None = None
    turn_number: int = 0
    participants: list[str] = field(default_factory=list)
    turns: list[TurnRecord] = field(default_factory=list)
    metrics: dict[str, dict[str, Any]] = field(default_factory=dict)


class InMemoryBackend:
    """
    Single-process backend using threading primitives.
    Perfect for testing, prototyping, and single-machine sessions.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._sessions: dict[str, _SessionData] = {}
        self._turn_subscribers: dict[str, list[Callable[[TurnRecord], None]]] = {}
        self._session_subscribers: dict[str, list[Callable[[SessionState], None]]] = {}

    def create_session(self, session_id: str, config: dict[str, Any]) -> None:
        with self._lock:
            self._sessions[session_id] = _SessionData(
                config=config,
                topic=config.get("topic", ""),
                phase=config.get("phase", ""),
                participants=config.get("participants", []),
            )
            # Preserve existing subscribers (supports pre-subscription pattern)
            if session_id not in self._turn_subscribers:
                self._turn_subscribers[session_id] = []
            if session_id not in self._session_subscribers:
                self._session_subscribers[session_id] = []

    def get_session_state(self, session_id: str) -> SessionState:
        with self._lock:
            s = self._sessions[session_id]
            return SessionState(
                status=s.status,
                phase=s.phase,
                topic=s.topic,
                active_speaker=s.active_speaker,
                speaker_done=s.speaker_done,
                floor_reserved_for=s.floor_reserved_for,
                floor_reserved_at=s.floor_reserved_at,
                floor_released_without_post=s.floor_released_without_post,
                floor_released_by=s.floor_released_by,
                turn_number=s.turn_number,
                participants=list(s.participants),
            )

    def update_session(self, session_id: str, updates: dict[str, Any]) -> None:
        with self._lock:
            s = self._sessions[session_id]
            for key, value in updates.items():
                if hasattr(s, key):
                    setattr(s, key, value)
            state = self._build_state(s)

        # Notify session subscribers outside lock
        for cb in self._session_subscribers.get(session_id, []):
            cb(state)

    def claim_floor(
        self, session_id: str, agent_name: str, timeout_seconds: float
    ) -> bool:
        with self._lock:
            s = self._sessions[session_id]
            now = time.time()

            # Check reservation
            if s.floor_reserved_for and s.floor_reserved_for != agent_name:
                if (now - s.floor_reserved_at) < 30.0:
                    return False

            # Check if floor is currently held
            if s.active_speaker and not s.speaker_done:
                if s.active_speaker == agent_name:
                    return True  # Already holding
                if (now - s.floor_claimed_at) < timeout_seconds:
                    return False  # Someone else holds it and hasn't timed out

            # Claim the floor
            s.active_speaker = agent_name
            s.speaker_done = False
            s.floor_claimed_at = now
            s.floor_released_without_post = False
            s.floor_released_by = None
            return True

    def release_floor(
        self, session_id: str, agent_name: str, posted_successfully: bool
    ) -> None:
        with self._lock:
            s = self._sessions[session_id]
            if s.active_speaker == agent_name:
                s.active_speaker = None
                s.speaker_done = True
                if not posted_successfully:
                    s.floor_released_without_post = True
                    s.floor_released_by = agent_name

        # Notify session subscribers
        state = self.get_session_state(session_id)
        for cb in self._session_subscribers.get(session_id, []):
            cb(state)

    def reserve_floor(
        self, session_id: str, for_agent: str, duration_seconds: float = 30.0
    ) -> None:
        with self._lock:
            s = self._sessions[session_id]
            s.floor_reserved_for = for_agent
            s.floor_reserved_at = time.time()

    def post_turn(self, session_id: str, turn: TurnData) -> str:
        turn_id = str(uuid.uuid4())[:8]
        record = TurnRecord(
            speaker=turn.agent_name,
            text=turn.transcript,
            phase="",  # filled below
            turn_index=0,
            timestamp=turn.timestamp,
            is_moderator=turn.is_moderator,
        )

        with self._lock:
            s = self._sessions[session_id]
            record.phase = s.phase
            record.turn_index = s.turn_number
            s.turns.append(record)
            s.turn_number += 1
            # Clear reservation if this agent was reserved
            if s.floor_reserved_for == turn.agent_name:
                s.floor_reserved_for = None

        # Notify turn subscribers outside lock
        for cb in self._turn_subscribers.get(session_id, []):
            cb(record)

        return turn_id

    def get_turns(self, session_id: str, since_index: int = 0) -> list[TurnRecord]:
        with self._lock:
            s = self._sessions[session_id]
            return [t for t in s.turns if t.turn_index >= since_index]

    def subscribe_turns(
        self, session_id: str, callback: Callable[[TurnRecord], None]
    ) -> Callable[[], None]:
        self._turn_subscribers.setdefault(session_id, []).append(callback)

        def unsubscribe() -> None:
            try:
                self._turn_subscribers[session_id].remove(callback)
            except (ValueError, KeyError):
                pass

        return unsubscribe

    def subscribe_session(
        self, session_id: str, callback: Callable[[SessionState], None]
    ) -> Callable[[], None]:
        self._session_subscribers.setdefault(session_id, []).append(callback)

        def unsubscribe() -> None:
            try:
                self._session_subscribers[session_id].remove(callback)
            except (ValueError, KeyError):
                pass

        return unsubscribe

    def store_metrics(
        self, session_id: str, agent_name: str, data: dict[str, Any]
    ) -> None:
        with self._lock:
            self._sessions[session_id].metrics[agent_name] = data

    # ── Internal helpers ─────────────────────────────────────────────

    def _build_state(self, s: _SessionData) -> SessionState:
        return SessionState(
            status=s.status,
            phase=s.phase,
            topic=s.topic,
            active_speaker=s.active_speaker,
            speaker_done=s.speaker_done,
            floor_reserved_for=s.floor_reserved_for,
            floor_reserved_at=s.floor_reserved_at,
            floor_released_without_post=s.floor_released_without_post,
            floor_released_by=s.floor_released_by,
            turn_number=s.turn_number,
            participants=list(s.participants),
        )
