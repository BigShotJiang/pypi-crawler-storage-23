"""
Conversation state model — extracted from Sangam's conversation_state.py.

Each agent and the moderator maintain their own local copy of ConversationState,
synced from the backend's transcript.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from floorctl.types import TurnRecord


@dataclass
class AgentMemory:
    """Per-agent memory: tracks last points and text hashes for dedup."""
    last_points: list[str] = field(default_factory=list)
    last_text_hashes: list[str] = field(default_factory=list)
    turns_spoken: int = 0
    last_spoke_at: datetime | None = None


@dataclass
class ConversationState:
    """
    Local state mirror. Each agent and the moderator maintain their own copy.
    """

    topic: str = ""
    phase: str = ""
    turn_index: int = 0
    speaker_queue: list[str] = field(default_factory=list)
    transcript: list[TurnRecord] = field(default_factory=list)
    rolling_summary: str = ""
    open_threads: list[str] = field(default_factory=list)
    agent_memory: dict[str, AgentMemory] = field(default_factory=dict)

    # Phase tracking
    phase_turn_count: int = 0         # all turns (agent + moderator)
    phase_agent_turn_count: int = 0   # agent turns only (for phase transitions)
    summary_counter: int = 0

    def ensure_agent_memory(self, agent_name: str) -> AgentMemory:
        if agent_name not in self.agent_memory:
            self.agent_memory[agent_name] = AgentMemory()
        return self.agent_memory[agent_name]

    def add_turn(self, speaker: str, text: str, is_moderator: bool = False) -> None:
        """Record a turn in the local transcript."""
        record = TurnRecord(
            speaker=speaker,
            text=text,
            phase=self.phase,
            turn_index=self.turn_index,
            timestamp=datetime.now(timezone.utc).isoformat(),
            is_moderator=is_moderator,
        )
        self.transcript.append(record)
        self.turn_index += 1
        self.phase_turn_count += 1
        if not is_moderator:
            self.phase_agent_turn_count += 1
        self.summary_counter += 1

        mem = self.ensure_agent_memory(speaker)
        mem.turns_spoken += 1
        mem.last_spoke_at = datetime.now(timezone.utc)
        text_hash = hashlib.md5(text.encode()).hexdigest()
        mem.last_text_hashes.append(text_hash)
        if len(mem.last_text_hashes) > 10:
            mem.last_text_hashes = mem.last_text_hashes[-10:]

    def get_last_n_turns(self, n: int = 8) -> list[TurnRecord]:
        return self.transcript[-n:]

    def get_last_n_turns_text(self, n: int = 8) -> str:
        turns = self.get_last_n_turns(n)
        return "\n".join(f"{t.speaker}: {t.text}" for t in turns)

    def last_speaker(self) -> str | None:
        """Who spoke last?"""
        if self.transcript:
            return self.transcript[-1].speaker
        return None

    def turns_since_agent_spoke(self, agent_name: str) -> int:
        """How many turns since this agent last spoke?"""
        for i, t in enumerate(reversed(self.transcript)):
            if t.speaker == agent_name:
                return i
        return len(self.transcript)

    def agent_turns_in_phase(self, agent_name: str) -> int:
        """Count turns by this agent in the current phase."""
        count = 0
        for t in reversed(self.transcript):
            if t.phase != self.phase:
                break
            if t.speaker == agent_name and not t.is_moderator:
                count += 1
        return count

    def needs_summary_update(self) -> bool:
        return self.summary_counter >= 3

    def reset_phase_count(self) -> None:
        """Reset phase tracking for a new phase."""
        self.phase_turn_count = 0
        self.phase_agent_turn_count = 0
