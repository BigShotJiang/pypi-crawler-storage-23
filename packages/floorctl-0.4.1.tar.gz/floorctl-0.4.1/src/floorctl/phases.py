"""
Phase management — transition logic for structured conversations.
"""

from __future__ import annotations

import logging

from floorctl.config import PhaseConfig, PhaseSequence

logger = logging.getLogger("floorctl.phases")


class PhaseManager:
    """
    Manages phase transitions for a session.
    Tracks current phase and decides when to advance.
    """

    def __init__(self, sequence: PhaseSequence) -> None:
        self.sequence = sequence
        self._current: PhaseConfig | None = sequence.first()

    @property
    def current_phase(self) -> str:
        return self._current.name if self._current else ""

    @property
    def current_config(self) -> PhaseConfig | None:
        return self._current

    def set_phase(self, name: str) -> PhaseConfig | None:
        """Explicitly set the current phase."""
        pc = self.sequence.get(name)
        if pc:
            self._current = pc
            logger.info(f"Phase set to: {name}")
        return pc

    def should_advance(self, phase_turn_count: int) -> bool:
        """Check if the current phase should auto-advance based on turn count."""
        if not self._current:
            return False
        return phase_turn_count >= self._current.max_turns

    def advance(self) -> PhaseConfig | None:
        """Advance to the next phase. Returns the new phase config, or None if terminal."""
        if not self._current:
            return None

        next_pc = self.sequence.next_phase(self._current.name)
        if next_pc:
            logger.info(f"Phase transition: {self._current.name} → {next_pc.name}")
            self._current = next_pc
            return next_pc

        return None

    def is_terminal(self) -> bool:
        """Check if we're in a terminal phase."""
        if not self._current:
            return True
        return self._current.is_terminal

    def can_advance(self, phase_turn_count: int) -> bool:
        """Check if minimum turn requirement is met for advancing."""
        if not self._current:
            return False
        return phase_turn_count >= self._current.min_turns
