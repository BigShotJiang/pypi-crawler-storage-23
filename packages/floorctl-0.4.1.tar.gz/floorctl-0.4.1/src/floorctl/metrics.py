"""
Research-grade metrics collectors — extracted from Sangam's metrics.py.

Thread-safe, per-agent and per-session metrics with Gini coefficient
for participation balance analysis.
"""

from __future__ import annotations

import json
import threading
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any


class AgentMetrics:
    """
    Thread-safe metrics collector for a single agent in a session.
    Each agent creates its own instance.
    """

    def __init__(self, agent_name: str, session_id: str) -> None:
        self.agent_name = agent_name
        self.session_id = session_id
        self._lock = threading.Lock()
        self._start_time = datetime.now(timezone.utc)

        # Floor Control
        self.floor_claims_attempted = 0
        self.floor_claims_won = 0
        self.floor_claims_lost = 0
        self.floor_claims_error = 0
        self.floor_hold_times: list[float] = []
        self.floor_releases_with_post = 0
        self.floor_releases_without_post = 0
        self.floor_retries_scheduled = 0
        self.floor_retries_executed = 0
        self.floor_retries_succeeded = 0
        self.floor_recovery_signals_received = 0
        self.floor_recovery_claims_attempted = 0
        self.floor_events: list[dict[str, Any]] = []  # per-event audit log

        # Urgency Scoring
        self.urgency_scores: list[dict[str, Any]] = []

        # Self-Validation
        self.validation_attempts = 0
        self.validation_passes = 0
        self.validation_failures = 0
        self.validation_failure_types: dict[str, int] = defaultdict(int)
        self.retries_per_turn: list[int] = []

        # Generation Timing
        self.generation_times: list[float] = []
        self.total_generation_time = 0.0

        # Turn Posting
        self.turns_posted = 0
        self.turns_by_phase: dict[str, int] = defaultdict(int)

        # Participation
        self.turns_silent_when_triggered: list[int] = []
        self.invitation_response_times: list[float] = []

    def record_urgency(
        self, urgency: float, threshold: float, triggered_by: str,
        phase: str, above_threshold: bool,
        components: dict[str, float] | None = None,
    ) -> None:
        with self._lock:
            self.urgency_scores.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "urgency": round(urgency, 4),
                "threshold": round(threshold, 4),
                "triggered_by": triggered_by,
                "phase": phase,
                "above_threshold": above_threshold,
                "components": components or {},
            })

    def record_floor_claim(self, success: bool, error: bool = False) -> None:
        with self._lock:
            self.floor_claims_attempted += 1
            if error:
                self.floor_claims_error += 1
            elif success:
                self.floor_claims_won += 1
            else:
                self.floor_claims_lost += 1

    def record_floor_hold_time(self, seconds: float) -> None:
        with self._lock:
            self.floor_hold_times.append(round(seconds, 2))

    def record_floor_release(self, posted_successfully: bool) -> None:
        with self._lock:
            if posted_successfully:
                self.floor_releases_with_post += 1
            else:
                self.floor_releases_without_post += 1

    def record_floor_retry(
        self, scheduled: bool = False, executed: bool = False,
        succeeded: bool = False,
    ) -> None:
        with self._lock:
            if scheduled:
                self.floor_retries_scheduled += 1
            if executed:
                self.floor_retries_executed += 1
            if succeeded:
                self.floor_retries_succeeded += 1

    def record_floor_event(
        self, success: bool, is_retry: bool = False,
        urgency: float = 0.0, threshold: float = 0.0,
        phase: str = "",
    ) -> None:
        """Record a per-event floor claim attempt for the audit log."""
        with self._lock:
            self.floor_events.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "success": success,
                "is_retry": is_retry,
                "urgency": round(urgency, 4),
                "threshold": round(threshold, 4),
                "phase": phase,
            })

    def record_validation(
        self, passed: bool, failure_types: list[str] | None = None,
    ) -> None:
        with self._lock:
            self.validation_attempts += 1
            if passed:
                self.validation_passes += 1
            else:
                self.validation_failures += 1
                for ft in (failure_types or []):
                    self.validation_failure_types[ft] += 1

    def record_retries_for_turn(self, retry_count: int) -> None:
        with self._lock:
            self.retries_per_turn.append(retry_count)

    def record_generation_time(self, seconds: float) -> None:
        with self._lock:
            self.generation_times.append(round(seconds, 3))
            self.total_generation_time += seconds

    def record_turn_posted(self, phase: str) -> None:
        with self._lock:
            self.turns_posted += 1
            self.turns_by_phase[phase] += 1

    def record_silence_duration(self, turns_silent: int) -> None:
        with self._lock:
            self.turns_silent_when_triggered.append(turns_silent)

    def to_dict(self) -> dict[str, Any]:
        with self._lock:
            elapsed = (datetime.now(timezone.utc) - self._start_time).total_seconds()

            avg_urgency = (
                sum(u["urgency"] for u in self.urgency_scores) / len(self.urgency_scores)
                if self.urgency_scores else 0.0
            )
            above_threshold_rate = (
                sum(1 for u in self.urgency_scores if u["above_threshold"])
                / len(self.urgency_scores)
                if self.urgency_scores else 0.0
            )
            avg_gen_time = (
                sum(self.generation_times) / len(self.generation_times)
                if self.generation_times else 0.0
            )
            floor_success_rate = (
                self.floor_claims_won / self.floor_claims_attempted
                if self.floor_claims_attempted > 0 else 0.0
            )
            validation_pass_rate = (
                self.validation_passes / self.validation_attempts
                if self.validation_attempts > 0 else 0.0
            )
            avg_hold = (
                sum(self.floor_hold_times) / len(self.floor_hold_times)
                if self.floor_hold_times else 0.0
            )

            return {
                "agent_name": self.agent_name,
                "session_id": self.session_id,
                "collected_at": datetime.now(timezone.utc).isoformat(),
                "episode_duration_seconds": round(elapsed, 1),
                "floor": {
                    "claims_attempted": self.floor_claims_attempted,
                    "claims_won": self.floor_claims_won,
                    "claims_lost": self.floor_claims_lost,
                    "claims_error": self.floor_claims_error,
                    "claim_success_rate": round(floor_success_rate, 4),
                    "avg_hold_time_seconds": round(avg_hold, 2),
                    "releases_with_post": self.floor_releases_with_post,
                    "releases_without_post": self.floor_releases_without_post,
                    "retries_scheduled": self.floor_retries_scheduled,
                    "retries_executed": self.floor_retries_executed,
                    "retries_succeeded": self.floor_retries_succeeded,
                    "events": self.floor_events,
                },
                "urgency": {
                    "total_computations": len(self.urgency_scores),
                    "avg_urgency": round(avg_urgency, 4),
                    "above_threshold_rate": round(above_threshold_rate, 4),
                    "scores": self.urgency_scores[-50:],
                },
                "validation": {
                    "total_attempts": self.validation_attempts,
                    "passes": self.validation_passes,
                    "failures": self.validation_failures,
                    "pass_rate": round(validation_pass_rate, 4),
                    "failure_types": dict(self.validation_failure_types),
                    "retries_per_turn": self.retries_per_turn,
                },
                "generation": {
                    "total_calls": len(self.generation_times),
                    "avg_time_seconds": round(avg_gen_time, 3),
                    "total_time_seconds": round(self.total_generation_time, 2),
                },
                "participation": {
                    "turns_posted": self.turns_posted,
                    "turns_by_phase": dict(self.turns_by_phase),
                    "silence_durations": self.turns_silent_when_triggered,
                },
            }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


class SessionMetrics:
    """
    Metrics for the whole session — collected by the moderator.
    Tracks interventions, phase durations, and participation balance (Gini).
    """

    def __init__(self, session_id: str, agent_names: list[str]) -> None:
        self.session_id = session_id
        self.agent_names = list(agent_names)
        self._lock = threading.RLock()
        self._start_time = datetime.now(timezone.utc)

        # Interventions
        self.interventions: list[dict[str, Any]] = []
        self.intervention_counts: dict[str, int] = defaultdict(int)

        # Phase durations
        self.phase_start_times: dict[str, str] = {}
        self.phase_durations: dict[str, float] = {}
        self.phase_turn_counts: dict[str, int] = defaultdict(int)

        # Turns
        self.total_agent_turns = 0
        self.total_moderator_turns = 0
        self.turns_per_agent: dict[str, int] = defaultdict(int)

        # Opening round
        self.opening_round_order: list[str] = []
        self.opening_out_of_turn_count = 0
        self.opening_agents_skipped: list[str] = []

    def record_intervention(
        self, intervention_type: str, target_agent: str | None,
        phase: str, trigger_reason: str = "",
    ) -> None:
        with self._lock:
            self.interventions.append({
                "type": intervention_type,
                "target_agent": target_agent,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "phase": phase,
                "trigger_reason": trigger_reason,
            })
            self.intervention_counts[intervention_type] += 1

    def record_phase_start(self, phase: str) -> None:
        with self._lock:
            self.phase_start_times[phase] = datetime.now(timezone.utc).isoformat()

    def record_phase_end(self, phase: str) -> None:
        with self._lock:
            start_str = self.phase_start_times.get(phase)
            if start_str:
                start = datetime.fromisoformat(start_str)
                duration = (datetime.now(timezone.utc) - start).total_seconds()
                self.phase_durations[phase] = round(duration, 1)

    def record_turn(
        self, speaker: str, is_moderator: bool, phase: str,
    ) -> None:
        with self._lock:
            if is_moderator:
                self.total_moderator_turns += 1
            else:
                self.total_agent_turns += 1
                self.turns_per_agent[speaker] += 1
            self.phase_turn_counts[phase] += 1

    def record_opening_speaker(
        self, agent: str, out_of_turn: bool = False,
    ) -> None:
        with self._lock:
            self.opening_round_order.append(agent)
            if out_of_turn:
                self.opening_out_of_turn_count += 1

    def record_opening_skip(self, agent: str) -> None:
        with self._lock:
            self.opening_agents_skipped.append(agent)

    def compute_gini_coefficient(self) -> float:
        """
        Gini coefficient of turns per agent.
        0.0 = perfectly balanced, 1.0 = one agent spoke all turns.
        """
        with self._lock:
            counts = [self.turns_per_agent.get(a, 0) for a in self.agent_names]

        if not counts or sum(counts) == 0:
            return 0.0

        n = len(counts)
        sorted_counts = sorted(counts)
        total = sum(sorted_counts)

        numerator = sum(
            (2 * (i + 1) - n - 1) * x
            for i, x in enumerate(sorted_counts)
        )
        denominator = n * total
        return round(numerator / denominator, 4) if denominator > 0 else 0.0

    @property
    def gini_coefficient(self) -> float:
        return self.compute_gini_coefficient()

    def to_dict(self) -> dict[str, Any]:
        with self._lock:
            elapsed = (datetime.now(timezone.utc) - self._start_time).total_seconds()
            counts = {a: self.turns_per_agent.get(a, 0) for a in self.agent_names}
            total = sum(counts.values())
            ideal = total / len(self.agent_names) if self.agent_names else 0
            max_dev = (
                max(abs(c - ideal) / ideal for c in counts.values())
                if ideal > 0 else 0.0
            )

            return {
                "session_id": self.session_id,
                "collected_at": datetime.now(timezone.utc).isoformat(),
                "episode_duration_seconds": round(elapsed, 1),
                "agent_count": len(self.agent_names),
                "participation": {
                    "gini": self.compute_gini_coefficient(),
                    "per_agent": counts,
                    "total_agent_turns": total,
                    "ideal_share": round(ideal, 2),
                    "max_deviation_from_ideal": round(max_dev, 4),
                },
                "interventions": {
                    "total": len(self.interventions),
                    "by_type": dict(self.intervention_counts),
                    "intervention_rate": round(
                        len(self.interventions) / max(self.total_agent_turns, 1), 4
                    ),
                    "details": self.interventions[-30:],
                },
                "phases": {
                    "durations_seconds": self.phase_durations,
                    "turn_counts": dict(self.phase_turn_counts),
                },
                "turns": {
                    "total_agent": self.total_agent_turns,
                    "total_moderator": self.total_moderator_turns,
                    "per_agent": dict(self.turns_per_agent),
                },
                "opening_round": {
                    "order": self.opening_round_order,
                    "out_of_turn_count": self.opening_out_of_turn_count,
                    "agents_skipped": self.opening_agents_skipped,
                },
            }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)
