"""
Core type definitions for floorctl.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, TypedDict


# ── Enums ────────────────────────────────────────────────────────────

class SessionStatus(str, Enum):
    WAITING = "WAITING"
    LIVE = "LIVE"
    PAUSED = "PAUSED"
    COMPLETED = "COMPLETED"


class Temperament(str, Enum):
    REACTIVE = "reactive"          # threshold 0.35
    PASSIONATE = "passionate"      # threshold 0.40
    PROVOCATIVE = "provocative"    # threshold 0.42
    MEDIATING = "mediating"        # threshold 0.45
    DELIBERATE = "deliberate"      # threshold 0.50
    PATIENT = "patient"            # threshold 0.55


# ── Turn Data ────────────────────────────────────────────────────────

@dataclass
class TurnRecord:
    """A single turn in the conversation transcript."""
    speaker: str
    text: str
    phase: str
    turn_index: int
    timestamp: str = ""
    is_moderator: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "speaker": self.speaker,
            "text": self.text,
            "phase": self.phase,
            "turn_index": self.turn_index,
            "timestamp": self.timestamp,
            "is_moderator": self.is_moderator,
        }


@dataclass
class TurnData:
    """Turn data for backend posting."""
    agent_name: str
    transcript: str
    timestamp: str
    is_moderator: bool = False
    turn_type: str = "discussion"
    metadata: dict[str, Any] = field(default_factory=dict)


class SessionState(TypedDict, total=False):
    """Session-level state stored in the backend."""
    status: str
    phase: str
    topic: str
    active_speaker: str | None
    speaker_done: bool
    floor_reserved_for: str | None
    floor_reserved_at: float | None
    floor_released_without_post: bool
    floor_released_by: str | None
    turn_number: int
    participants: list[str]


# ── Urgency ──────────────────────────────────────────────────────────

@dataclass
class UrgencyResult:
    """Result of an urgency computation."""
    score: float                       # 0.0-1.0 clamped
    threshold: float
    above_threshold: bool
    components: dict[str, float] = field(default_factory=dict)
    triggered_by: str = ""


# ── Floor Events ────────────────────────────────────────────────────

@dataclass
class FloorEvent:
    """Auditable record of a single floor claim attempt."""
    agent_name: str
    timestamp: str          # ISO 8601
    success: bool
    is_retry: bool = False
    turn_index: int = -1    # linked turn if claim succeeded and agent posted
    urgency_score: float = 0.0
    urgency_threshold: float = 0.0
    phase: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "agent_name": self.agent_name,
            "timestamp": self.timestamp,
            "success": self.success,
            "is_retry": self.is_retry,
            "turn_index": self.turn_index,
            "urgency_score": self.urgency_score,
            "urgency_threshold": self.urgency_threshold,
            "phase": self.phase,
        }


# ── Validation ───────────────────────────────────────────────────────

@dataclass
class ValidationResult:
    """Result of a single validator."""
    passed: bool
    reason: str = ""
    validator_name: str = ""


# ── Session Result ───────────────────────────────────────────────────

@dataclass
class SessionResult:
    """Result returned when a FloorSession completes."""
    session_id: str
    topic: str
    transcript: list[TurnRecord] = field(default_factory=list)
    agent_metrics: dict[str, Any] = field(default_factory=dict)
    session_metrics: dict[str, Any] = field(default_factory=dict)
    total_turns: int = 0
    duration_seconds: float = 0.0
    floor_events: list[FloorEvent] = field(default_factory=list)


# ── Capability Protocol ──────────────────────────────────────────────

class AgentCapability:
    """
    Base class for agent capabilities — modular behaviors that plug into
    the FloorAgent pipeline without subclassing.

    Override any of these methods to extend agent behavior:
    - enrich_context: inject data before LLM generation (RAG, search, DB)
    - post_process: transform the response after generation, before validation
    - on_turn_received: react to new turns (logging, memory, analytics)

    Capabilities run in insertion order. enrich_context and post_process
    are chained — each receives the output of the previous one.

    Usage:
        class RAGCapability(AgentCapability):
            name = "rag"

            def __init__(self, retriever):
                self.retriever = retriever

            def enrich_context(self, context):
                context["retrieved_docs"] = self.retriever.search(context["topic"])
                return context

        agent = FloorAgent(name="Researcher", ...)
        agent.add_capability(RAGCapability(my_retriever))
    """

    name: str = "base"

    def enrich_context(self, context: dict[str, Any]) -> dict[str, Any]:
        """
        Enrich the context dict before it's passed to the LLM generate_fn.
        Called after the base context is built, before generation.
        Must return the (modified) context dict.
        """
        return context

    def post_process(self, response: str, context: dict[str, Any]) -> str:
        """
        Transform the generated response before validation.
        Called after LLM generation, before validators run.
        Must return the (modified) response string.
        """
        return response

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        """
        Called when a new turn appears in the transcript.
        Use for side-effects: logging, memory updates, analytics.
        Does not affect the agent's decision to speak.
        """
        pass


# ── Function Types ───────────────────────────────────────────────────

# User provides: (agent_name, context_dict) -> response_text
GenerateFn = Callable[[str, dict[str, Any]], str]

# Moderator function: (prompt_type, context_dict) -> moderator_text
ModeratorFn = Callable[[str, dict[str, Any]], str]
