"""
Floor controller — transactional floor claim/release with retry and anti-starvation.

Extracted from Sangam's council_sdk._claim_floor, _release_floor, _schedule_floor_retry.
"""

from __future__ import annotations

import logging
import random
import threading
import time
from typing import Any, Callable

from floorctl.backends.base import Backend
from floorctl.config import FloorConfig

logger = logging.getLogger("floorctl.floor")


class FloorController:
    """
    Manages floor claiming, releasing, retries, and starvation prevention
    for a single agent.
    """

    def __init__(
        self,
        agent_name: str,
        backend: Backend,
        config: FloorConfig | None = None,
    ) -> None:
        self.agent_name = agent_name
        self.backend = backend
        self.config = config or FloorConfig()
        self._losses_streak = 0
        self._retry_timer: threading.Timer | None = None

    @property
    def losses_streak(self) -> int:
        return self._losses_streak

    def reset_streak(self) -> None:
        self._losses_streak = 0

    def try_claim(self, session_id: str) -> bool:
        """
        Attempt to claim the floor. Returns True if successful.
        Tracks streak for anti-starvation.
        """
        success = self.backend.claim_floor(
            session_id, self.agent_name, self.config.timeout_seconds
        )
        if success:
            self._losses_streak = 0
            logger.debug(f"[{self.agent_name}] Floor claimed successfully")
        else:
            self._losses_streak += 1
            logger.debug(
                f"[{self.agent_name}] Floor claim failed "
                f"(streak: {self._losses_streak})"
            )
        return success

    def release(self, session_id: str, posted_successfully: bool) -> None:
        """Release the floor after posting (or failing to post)."""
        self.backend.release_floor(
            session_id, self.agent_name, posted_successfully
        )
        logger.debug(
            f"[{self.agent_name}] Floor released "
            f"(posted: {posted_successfully})"
        )

    def schedule_retry(
        self,
        session_id: str,
        callback: Callable[[], None],
        phase_turns: int = 0,
    ) -> None:
        """
        Schedule a delayed floor retry with adaptive delay.

        Anti-starvation features:
        - Agents on losing streak get shorter delays
        - Agents with fewer phase turns get 30% faster retry
        """
        if self._retry_timer is not None:
            self._retry_timer.cancel()

        base_min = self.config.retry_base_min
        base_max = self.config.retry_base_max

        # Reduce delay for agents on a losing streak
        streak_reduction = min(self._losses_streak * 1.5, 6.0)
        delay_min = max(2.0, base_min - streak_reduction)
        delay_max = max(delay_min + 2.0, base_max - streak_reduction)

        # Fairness bonus: agents with fewer phase turns get faster retry
        if phase_turns <= 1:
            delay_min *= 0.7
            delay_max *= 0.7

        delay = random.uniform(delay_min, delay_max)

        logger.debug(
            f"[{self.agent_name}] Scheduling retry in {delay:.1f}s "
            f"(streak: {self._losses_streak})"
        )

        self._retry_timer = threading.Timer(delay, callback)
        self._retry_timer.daemon = True
        self._retry_timer.start()

    def starvation_threshold_reduction(self) -> float:
        """
        Reduce urgency threshold for agents on a losing streak.
        After N consecutive losses, lower the threshold to give them a chance.
        """
        if self._losses_streak >= self.config.starvation_streak_threshold:
            return -self.config.starvation_threshold_reduction
        return 0.0

    def cancel_retry(self) -> None:
        """Cancel any pending retry timer."""
        if self._retry_timer is not None:
            self._retry_timer.cancel()
            self._retry_timer = None
