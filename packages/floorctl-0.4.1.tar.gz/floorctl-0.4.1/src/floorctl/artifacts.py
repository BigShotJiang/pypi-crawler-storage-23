"""
Artifacts — structured mutable objects that agents produce, modify, and version.

Unlike conversation turns (immutable text), artifacts are living documents:
- Code, decisions, proposals, designs that evolve during the session
- Full version history with diffs
- Ownership and lock semantics for concurrent modification
- Section-level granularity for collaborative editing

This is what separates "agents talking" from "agents building something together."

Example:
    store = ArtifactStore()
    artifact = store.create("adr-001", ArtifactType.DECISION_RECORD, creator="Architect")
    store.update("adr-001", agent="Architect", sections={"title": "Use PostgreSQL"})
    store.update("adr-001", agent="SecurityLead", sections={"risks": "SQL injection..."})
    history = store.history("adr-001")  # full version log
"""

from __future__ import annotations

import copy
import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable

logger = logging.getLogger("floorctl.artifacts")


# ── Enums ────────────────────────────────────────────────────────────

class ArtifactType(str, Enum):
    """Types of structured artifacts agents can produce."""
    DOCUMENT = "document"               # Free-form structured document
    DECISION_RECORD = "decision_record" # ADR-style with status, context, decision, consequences
    PROPOSAL = "proposal"               # Proposed action with rationale
    CODE = "code"                       # Code artifact with language metadata
    CHECKLIST = "checklist"             # Items with done/not-done status
    SCHEMA = "schema"                   # Data schema or interface definition
    CUSTOM = "custom"                   # User-defined structure


class ArtifactStatus(str, Enum):
    """Lifecycle status of an artifact."""
    DRAFT = "draft"
    PROPOSED = "proposed"               # Submitted for review/consensus
    ACCEPTED = "accepted"               # Passed consensus
    REJECTED = "rejected"               # Failed consensus
    SUPERSEDED = "superseded"           # Replaced by newer version


# ── Data Classes ─────────────────────────────────────────────────────

@dataclass
class ArtifactVersion:
    """A single version of an artifact — immutable snapshot."""
    version: int
    sections: dict[str, Any]
    author: str
    timestamp: str
    message: str = ""                   # Commit message describing the change
    diff: dict[str, Any] = field(default_factory=dict)  # What changed


@dataclass
class Artifact:
    """
    A structured, versioned, collaboratively-edited object.

    Sections are key-value pairs where keys are section names and values
    are the content (strings, lists, dicts — whatever the artifact type needs).
    """
    artifact_id: str
    artifact_type: ArtifactType
    creator: str
    created_at: str = ""
    status: ArtifactStatus = ArtifactStatus.DRAFT
    sections: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    version: int = 0
    history: list[ArtifactVersion] = field(default_factory=list)
    locked_by: str | None = None
    locked_at: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "artifact_id": self.artifact_id,
            "artifact_type": self.artifact_type.value,
            "creator": self.creator,
            "created_at": self.created_at,
            "status": self.status.value,
            "sections": copy.deepcopy(self.sections),
            "metadata": copy.deepcopy(self.metadata),
            "version": self.version,
            "history_length": len(self.history),
            "locked_by": self.locked_by,
        }

    def to_context(self) -> dict[str, Any]:
        """Compact representation for LLM context."""
        return {
            "id": self.artifact_id,
            "type": self.artifact_type.value,
            "status": self.status.value,
            "version": self.version,
            "sections": copy.deepcopy(self.sections),
            "last_author": self.history[-1].author if self.history else self.creator,
        }


# ── Templates ────────────────────────────────────────────────────────

ARTIFACT_TEMPLATES: dict[ArtifactType, dict[str, Any]] = {
    ArtifactType.DECISION_RECORD: {
        "title": "",
        "status": "proposed",
        "context": "",
        "decision": "",
        "consequences": "",
        "alternatives_considered": [],
        "risks": "",
    },
    ArtifactType.PROPOSAL: {
        "title": "",
        "summary": "",
        "rationale": "",
        "implementation": "",
        "risks": "",
        "timeline": "",
    },
    ArtifactType.CODE: {
        "language": "",
        "description": "",
        "code": "",
        "tests": "",
        "dependencies": [],
    },
    ArtifactType.CHECKLIST: {
        "title": "",
        "items": [],   # list of {"text": str, "done": bool, "assignee": str}
    },
    ArtifactType.SCHEMA: {
        "name": "",
        "description": "",
        "fields": [],   # list of {"name": str, "type": str, "required": bool}
        "constraints": [],
    },
}


def _compute_diff(
    old_sections: dict[str, Any],
    new_sections: dict[str, Any],
) -> dict[str, Any]:
    """Compute a simple section-level diff."""
    diff: dict[str, Any] = {}

    for key in new_sections:
        if key not in old_sections:
            diff[key] = {"action": "added", "value": new_sections[key]}
        elif old_sections[key] != new_sections[key]:
            diff[key] = {
                "action": "modified",
                "old": old_sections[key],
                "new": new_sections[key],
            }

    for key in old_sections:
        if key not in new_sections:
            diff[key] = {"action": "removed", "old": old_sections[key]}

    return diff


# ── Artifact Store ───────────────────────────────────────────────────

class ArtifactStore:
    """
    Thread-safe store for managing artifacts within a session.

    Provides:
    - Create/read/update with automatic versioning
    - Section-level locking for concurrent modification
    - Change subscriptions for reactive agents
    - Full version history with diffs
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._artifacts: dict[str, Artifact] = {}
        self._subscribers: list[Callable[[str, str, Artifact], None]] = []

    def create(
        self,
        artifact_id: str,
        artifact_type: ArtifactType,
        creator: str,
        initial_sections: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        message: str = "",
    ) -> Artifact:
        """
        Create a new artifact. Uses template sections for known types.

        Args:
            artifact_id: Unique identifier
            artifact_type: Type of artifact (determines template)
            creator: Name of the creating agent
            initial_sections: Override or extend template sections
            metadata: Arbitrary metadata
            message: Creation message

        Returns:
            The created Artifact
        """
        now = datetime.now(timezone.utc).isoformat()

        # Start from template if available
        template = ARTIFACT_TEMPLATES.get(artifact_type, {})
        sections = copy.deepcopy(template)
        if initial_sections:
            sections.update(initial_sections)

        artifact = Artifact(
            artifact_id=artifact_id,
            artifact_type=artifact_type,
            creator=creator,
            created_at=now,
            sections=sections,
            metadata=metadata or {},
            version=1,
        )

        # Record initial version
        artifact.history.append(ArtifactVersion(
            version=1,
            sections=copy.deepcopy(sections),
            author=creator,
            timestamp=now,
            message=message or f"Created by {creator}",
        ))

        with self._lock:
            if artifact_id in self._artifacts:
                raise ValueError(f"Artifact '{artifact_id}' already exists")
            self._artifacts[artifact_id] = artifact

        logger.info(
            f"[ArtifactStore] Created {artifact_type.value} '{artifact_id}' "
            f"by {creator}"
        )

        self._notify("created", artifact_id, artifact)
        return artifact

    def get(self, artifact_id: str) -> Artifact | None:
        """Get an artifact by ID."""
        with self._lock:
            return self._artifacts.get(artifact_id)

    def list_artifacts(
        self,
        artifact_type: ArtifactType | None = None,
        status: ArtifactStatus | None = None,
    ) -> list[Artifact]:
        """List artifacts, optionally filtered by type and/or status."""
        with self._lock:
            results = list(self._artifacts.values())

        if artifact_type:
            results = [a for a in results if a.artifact_type == artifact_type]
        if status:
            results = [a for a in results if a.status == status]

        return results

    def update(
        self,
        artifact_id: str,
        agent: str,
        sections: dict[str, Any] | None = None,
        status: ArtifactStatus | None = None,
        metadata: dict[str, Any] | None = None,
        message: str = "",
    ) -> Artifact:
        """
        Update an artifact. Creates a new version with full diff.

        Args:
            artifact_id: ID of artifact to update
            agent: Name of the modifying agent
            sections: Section updates (merged with existing)
            status: New status (if changing)
            metadata: Metadata updates (merged)
            message: Commit message

        Returns:
            Updated Artifact

        Raises:
            ValueError: If artifact doesn't exist or is locked by another agent
        """
        with self._lock:
            artifact = self._artifacts.get(artifact_id)
            if not artifact:
                raise ValueError(f"Artifact '{artifact_id}' not found")

            # Check lock
            if artifact.locked_by and artifact.locked_by != agent:
                raise ValueError(
                    f"Artifact '{artifact_id}' is locked by {artifact.locked_by}"
                )

            old_sections = copy.deepcopy(artifact.sections)

            # Apply section updates
            if sections:
                artifact.sections.update(sections)

            # Apply status change
            if status:
                artifact.status = status

            # Apply metadata updates
            if metadata:
                artifact.metadata.update(metadata)

            # Compute diff and version
            diff = _compute_diff(old_sections, artifact.sections)
            artifact.version += 1
            now = datetime.now(timezone.utc).isoformat()

            version_record = ArtifactVersion(
                version=artifact.version,
                sections=copy.deepcopy(artifact.sections),
                author=agent,
                timestamp=now,
                message=message or f"Updated by {agent}",
                diff=diff,
            )
            artifact.history.append(version_record)

        logger.info(
            f"[ArtifactStore] Updated '{artifact_id}' v{artifact.version} "
            f"by {agent}: {list(diff.keys()) if diff else 'status/metadata only'}"
        )

        self._notify("updated", artifact_id, artifact)
        return artifact

    def lock(self, artifact_id: str, agent: str) -> bool:
        """
        Lock an artifact for exclusive editing.

        Returns True if lock acquired, False if already locked by another.
        """
        with self._lock:
            artifact = self._artifacts.get(artifact_id)
            if not artifact:
                return False

            if artifact.locked_by and artifact.locked_by != agent:
                return False

            artifact.locked_by = agent
            artifact.locked_at = datetime.now(timezone.utc).isoformat()
            return True

    def unlock(self, artifact_id: str, agent: str) -> bool:
        """Release a lock. Only the lock holder can unlock."""
        with self._lock:
            artifact = self._artifacts.get(artifact_id)
            if not artifact:
                return False

            if artifact.locked_by != agent:
                return False

            artifact.locked_by = None
            artifact.locked_at = None
            return True

    def get_history(self, artifact_id: str) -> list[ArtifactVersion]:
        """Get the full version history of an artifact."""
        with self._lock:
            artifact = self._artifacts.get(artifact_id)
            if not artifact:
                return []
            return list(artifact.history)

    def get_version(self, artifact_id: str, version: int) -> ArtifactVersion | None:
        """Get a specific version of an artifact."""
        with self._lock:
            artifact = self._artifacts.get(artifact_id)
            if not artifact:
                return None
            for v in artifact.history:
                if v.version == version:
                    return v
            return None

    def get_contributors(self, artifact_id: str) -> list[str]:
        """Get all agents who have contributed to an artifact."""
        with self._lock:
            artifact = self._artifacts.get(artifact_id)
            if not artifact:
                return []
            seen: set[str] = set()
            ordered: list[str] = []
            for v in artifact.history:
                if v.author not in seen:
                    seen.add(v.author)
                    ordered.append(v.author)
            return ordered

    def subscribe(
        self,
        callback: Callable[[str, str, Artifact], None],
    ) -> Callable[[], None]:
        """
        Subscribe to artifact changes.

        Callback receives (event_type, artifact_id, artifact).
        event_type: "created" | "updated"

        Returns unsubscribe function.
        """
        self._subscribers.append(callback)

        def unsubscribe() -> None:
            try:
                self._subscribers.remove(callback)
            except ValueError:
                pass

        return unsubscribe

    def to_context(self) -> list[dict[str, Any]]:
        """Get all artifacts in compact form for LLM context."""
        with self._lock:
            return [a.to_context() for a in self._artifacts.values()]

    # ── Internal ─────────────────────────────────────────────────────

    def _notify(self, event: str, artifact_id: str, artifact: Artifact) -> None:
        """Notify subscribers of artifact changes."""
        for cb in self._subscribers:
            try:
                cb(event, artifact_id, artifact)
            except Exception as e:
                logger.error(f"[ArtifactStore] Subscriber error: {e}")
