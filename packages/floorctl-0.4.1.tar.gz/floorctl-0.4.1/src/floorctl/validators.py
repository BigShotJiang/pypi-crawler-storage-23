"""
Self-validation pipeline — extracted from Sangam's validators.py.

Validators return (passed, reason). Agents call run_validators() on their
own drafts before posting. Failed drafts are retried with the failure
reasons fed back to the LLM.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Protocol

from floorctl.config import PhaseConfig, StyleContract
from floorctl.state import ConversationState
from floorctl.types import ValidationResult


# ── Helpers ──────────────────────────────────────────────────────────

def strip_speaker_prefix(text: str, speaker: str) -> str:
    """Remove 'AgentName: ' prefix from text."""
    prefix = f"{speaker}:"
    t = text.strip()
    if t.startswith(prefix):
        return t[len(prefix):].strip()
    return t


# ── Validator Protocol ───────────────────────────────────────────────

class Validator(Protocol):
    """Protocol for a validator. Implement this to create custom validators."""
    name: str

    def validate(
        self,
        draft: str,
        speaker: str,
        state: ConversationState,
        style_contract: StyleContract | None = None,
        phase_config: PhaseConfig | None = None,
        agent_names: list[str] | None = None,
    ) -> ValidationResult: ...


# ── Built-in Validators ──────────────────────────────────────────────

@dataclass
class SpeakerPrefixValidator:
    """Draft MUST start with 'AgentName:' prefix."""
    name: str = "SpeakerPrefix"

    def validate(
        self, draft: str, speaker: str, state: ConversationState,
        style_contract: StyleContract | None = None,
        phase_config: PhaseConfig | None = None,
        agent_names: list[str] | None = None,
    ) -> ValidationResult:
        text = draft.strip()
        expected_prefix = f"{speaker}:"

        if text.startswith(expected_prefix):
            return ValidationResult(passed=True, validator_name=self.name)

        # Check if it starts with any other known agent name
        for agent in (agent_names or []):
            if text.startswith(f"{agent}:") and agent != speaker:
                return ValidationResult(
                    passed=False,
                    reason=f"Wrong speaker prefix: expected '{speaker}:', got '{agent}:'",
                    validator_name=self.name,
                )

        return ValidationResult(
            passed=False,
            reason=f"Missing required prefix '{speaker}:'. Response must start with '{speaker}:'",
            validator_name=self.name,
        )


@dataclass
class DuplicateValidator:
    """Check hash collision and semantic similarity against recent transcript."""
    name: str = "Duplicate"
    similarity_threshold: float = 0.65

    def validate(
        self, draft: str, speaker: str, state: ConversationState,
        style_contract: StyleContract | None = None,
        phase_config: PhaseConfig | None = None,
        agent_names: list[str] | None = None,
    ) -> ValidationResult:
        clean_text = strip_speaker_prefix(draft, speaker)
        text_hash = hashlib.md5(clean_text.encode()).hexdigest()

        mem = state.ensure_agent_memory(speaker)
        if text_hash in mem.last_text_hashes:
            return ValidationResult(
                passed=False,
                reason="Exact duplicate of a previous response.",
                validator_name=self.name,
            )

        for turn in state.get_last_n_turns(10):
            prev_text = strip_speaker_prefix(turn.text, turn.speaker)
            ratio = SequenceMatcher(None, clean_text.lower(), prev_text.lower()).ratio()
            if ratio > self.similarity_threshold:
                return ValidationResult(
                    passed=False,
                    reason=(
                        f"Near-duplicate (similarity={ratio:.0%}) with {turn.speaker}'s "
                        f"turn at index {turn.turn_index}. Reformulate with a fresh angle."
                    ),
                    validator_name=self.name,
                )

        return ValidationResult(passed=True, validator_name=self.name)


@dataclass
class LengthValidator:
    """Enforce word count and sentence count limits."""
    name: str = "Length"
    default_min_words: int = 15
    default_max_words: int = 150

    def validate(
        self, draft: str, speaker: str, state: ConversationState,
        style_contract: StyleContract | None = None,
        phase_config: PhaseConfig | None = None,
        agent_names: list[str] | None = None,
    ) -> ValidationResult:
        clean_text = strip_speaker_prefix(draft, speaker)
        words = clean_text.split()
        word_count = len(words)
        sentences = [s.strip() for s in re.split(r'[.!?]+', clean_text) if s.strip()]

        min_w = phase_config.min_words if phase_config else self.default_min_words
        max_w = phase_config.max_words if phase_config else self.default_max_words
        max_s = phase_config.max_sentences if phase_config and phase_config.max_sentences else None

        # Opening phases: stricter limits
        if phase_config and phase_config.is_opening:
            if max_s and len(sentences) > max_s:
                return ValidationResult(
                    passed=False,
                    reason=f"Opening: max {max_s} sentences, got {len(sentences)}.",
                    validator_name=self.name,
                )

        if word_count > max_w:
            return ValidationResult(
                passed=False,
                reason=f"Too long: {word_count} words (max {max_w}).",
                validator_name=self.name,
            )

        if word_count < min_w:
            return ValidationResult(
                passed=False,
                reason=f"Too short: {word_count} words (min {min_w}).",
                validator_name=self.name,
            )

        return ValidationResult(passed=True, validator_name=self.name)


@dataclass
class BannedPhraseValidator:
    """Reject if any banned phrase appears."""
    name: str = "BannedPhrase"
    banned_phrases: list[str] = field(default_factory=list)

    def validate(
        self, draft: str, speaker: str, state: ConversationState,
        style_contract: StyleContract | None = None,
        phase_config: PhaseConfig | None = None,
        agent_names: list[str] | None = None,
    ) -> ValidationResult:
        text_lower = draft.lower()
        for phrase in self.banned_phrases:
            if phrase.lower() in text_lower:
                return ValidationResult(
                    passed=False,
                    reason=f"Contains banned phrase: '{phrase}'",
                    validator_name=self.name,
                )
        return ValidationResult(passed=True, validator_name=self.name)


@dataclass
class StyleContractValidator:
    """Verify the speaker's style contract is satisfied."""
    name: str = "StyleContract"

    def validate(
        self, draft: str, speaker: str, state: ConversationState,
        style_contract: StyleContract | None = None,
        phase_config: PhaseConfig | None = None,
        agent_names: list[str] | None = None,
    ) -> ValidationResult:
        if not style_contract:
            return ValidationResult(passed=True, validator_name=self.name)

        clean_text = strip_speaker_prefix(draft, speaker)
        text_lower = clean_text.lower()

        # Check forbidden patterns
        for pattern in style_contract.forbidden_patterns:
            if re.search(pattern, text_lower):
                return ValidationResult(
                    passed=False,
                    reason=(
                        f"Style violation ({speaker}): contains forbidden pattern '{pattern}'. "
                        f"{style_contract.description}"
                    ),
                    validator_name=self.name,
                )

        # Check max_sentences
        if style_contract.max_sentences:
            sentences = [s.strip() for s in re.split(r'[.!?]+', clean_text) if s.strip()]
            if len(sentences) > style_contract.max_sentences:
                return ValidationResult(
                    passed=False,
                    reason=(
                        f"Style violation ({speaker}): max {style_contract.max_sentences} "
                        f"sentences, got {len(sentences)}."
                    ),
                    validator_name=self.name,
                )

        # Check required elements (skip during opening phases)
        if phase_config and phase_config.is_opening:
            return ValidationResult(passed=True, validator_name=self.name)

        failures: list[str] = []
        for req in style_contract.required_patterns:
            # Extract keywords from parenthetical groups
            keywords_match = re.search(r'\(([^)]+)\)', req)
            if keywords_match:
                keywords = [k.strip().lower() for k in keywords_match.group(1).split(',')]
                if not any(kw in text_lower for kw in keywords):
                    failures.append(req)
            else:
                # Generic keyword check
                req_words = [w.lower() for w in req.split() if len(w) > 3]
                if req_words and not any(w in text_lower for w in req_words):
                    failures.append(req)

        if failures:
            return ValidationResult(
                passed=False,
                reason=(
                    f"Style violation ({speaker}): missing required elements: "
                    + "; ".join(failures)
                    + f". Contract: {style_contract.description}"
                ),
                validator_name=self.name,
            )

        return ValidationResult(passed=True, validator_name=self.name)


@dataclass
class PhaseValidator:
    """Ensure content matches phase requirements."""
    name: str = "Phase"

    def validate(
        self, draft: str, speaker: str, state: ConversationState,
        style_contract: StyleContract | None = None,
        phase_config: PhaseConfig | None = None,
        agent_names: list[str] | None = None,
    ) -> ValidationResult:
        if not phase_config:
            return ValidationResult(passed=True, validator_name=self.name)

        clean_text = strip_speaker_prefix(draft, speaker)

        # No critiques in opening phases
        if not phase_config.allow_critiques:
            aggressive_markers = ["disagree", "wrong", "that's incorrect", "you're missing"]
            for m in aggressive_markers:
                if m in clean_text.lower():
                    return ValidationResult(
                        passed=False,
                        reason=f"{phase_config.name}: no critiques allowed. Found '{m}'.",
                        validator_name=self.name,
                    )

        return ValidationResult(passed=True, validator_name=self.name)


# ── Pipeline Runner ──────────────────────────────────────────────────

def run_validators(
    draft: str,
    speaker: str,
    state: ConversationState,
    validators: list[Validator],
    style_contract: StyleContract | None = None,
    phase_config: PhaseConfig | None = None,
    agent_names: list[str] | None = None,
) -> tuple[bool, list[str]]:
    """Run all validators. Returns (all_passed, list_of_failure_reasons)."""
    failures: list[str] = []

    for v in validators:
        result = v.validate(
            draft, speaker, state,
            style_contract=style_contract,
            phase_config=phase_config,
            agent_names=agent_names,
        )
        if not result.passed:
            failures.append(f"[{v.name}] {result.reason}")

    return len(failures) == 0, failures
