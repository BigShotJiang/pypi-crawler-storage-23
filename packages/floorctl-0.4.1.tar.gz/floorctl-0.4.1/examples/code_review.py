#!/usr/bin/env python3
"""
code_review.py — 3-agent code review example using floorctl.

Demonstrates: domain-specific style contracts, strict validation,
phase transitions, specialized expertise, and capabilities
(FindingsTrackerCapability to collect and categorize review findings).

Usage:
    python examples/code_review.py
    python examples/code_review.py --topic "Review: microservices auth with JWT tokens"
"""

import argparse
import json
import logging
import os
import sys
import time

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from floorctl import (
    FloorAgent,
    FloorSession,
    ModeratorObserver,
    AgentProfile,
    AgentCapability,
    StyleContract,
    ArenaConfig,
    PhaseConfig,
    PhaseSequence,
    FloorConfig,
    ModeratorConfig,
    InMemoryBackend,
    TurnRecord,
    SpeakerPrefixValidator,
    DuplicateValidator,
    LengthValidator,
    BannedPhraseValidator,
    StyleContractValidator,
)


# ── Capabilities ────────────────────────────────────────────────────

class FindingsTrackerCapability(AgentCapability):
    """Collects and categorizes review findings by severity.

    Demonstrates:
    - on_turn_received: categorizes each turn's findings by keywords
    - enrich_context: injects prior findings so agents don't repeat themselves
    """

    name = "findings_tracker"

    SEVERITY_KEYWORDS = {
        "critical": ["vulnerability", "exploit", "injection", "breach", "CSRF", "XSS",
                      "remote code", "privilege escalation", "unauthenticated"],
        "major": ["latency", "bottleneck", "p99", "memory leak", "N+1", "deadlock",
                   "coupling", "circular", "untested", "no test"],
        "minor": ["naming", "readability", "comment", "documentation", "typo",
                   "convention", "formatting", "refactor"],
    }

    def __init__(self):
        self.findings: list[dict] = []

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        if turn.is_moderator:
            return
        text_lower = turn.text.lower()
        severity = "info"
        for level, keywords in self.SEVERITY_KEYWORDS.items():
            if any(kw in text_lower for kw in keywords):
                severity = level
                break
        self.findings.append({
            "reviewer": turn.speaker,
            "severity": severity,
            "phase": turn.phase,
            "summary": turn.text.split(":", 1)[-1].strip()[:100],
        })

    def enrich_context(self, context: dict) -> dict:
        if self.findings:
            prior = "\n".join(
                f"  [{f['severity'].upper()}] {f['reviewer']}: {f['summary']}"
                for f in self.findings[-5:]
            )
            context["findings_tracker:prior_findings"] = prior
        return context

    def get_report(self) -> dict:
        """Return findings grouped by severity."""
        report: dict[str, list] = {"critical": [], "major": [], "minor": [], "info": []}
        for f in self.findings:
            report[f["severity"]].append(f)
        return report


def create_generator():
    from openai import OpenAI
    client = OpenAI()

    def generate(agent_name: str, context: dict) -> str:
        retry_info = ""
        if context.get("retry_failures"):
            retry_info = f"\n\nFix these issues:\n" + "\n".join(f"- {f}" for f in context["retry_failures"])

        prompt = f"""You are {agent_name}, a code review expert.
Perspective: {context.get('personality', '')}
Architecture under review: {context['topic']}
Phase: {context['phase']}
{f"Style requirements: {context.get('style_contract', '')}" if context.get('style_contract') else ""}

Discussion so far:
{context.get('recent_turns', '(none)')}

RULES:
- Prefix with "{agent_name}:"
- {context.get('phase_min_words', 20)}-{context.get('phase_max_words', 120)} words
- Be specific and actionable — cite concrete patterns, risks, or improvements
- No generic advice
{retry_info}

Your review comment:"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=250,
            temperature=0.7,
        )
        return response.choices[0].message.content.strip()

    return generate


def create_moderator():
    from openai import OpenAI
    client = OpenAI()

    def moderate(prompt_type: str, context: dict) -> str:
        topic = context.get("topic", "")
        prompts = {
            "intro": f"You are leading a code review of '{topic}' with security, performance, and maintainability experts. 2-sentence intro framing key concerns.",
            "invite_opening": f"Ask {context.get('agent_name', '')} for their initial assessment of '{topic}'. 1 sentence.",
            "phase_transition": f"Transition from {context.get('previous_phase', '')} to {context.get('phase', '')}. Summarize findings and set next focus. 2 sentences.",
            "intervention": f"Moderate: {context.get('intervention_type', '')} on {context.get('target_agent', '')}. Brief redirect. 1 sentence.",
            "closing": f"Summarize the code review of '{topic}'. List top 3 action items. 3 sentences.",
        }

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompts.get(prompt_type, f"Brief comment on {topic}.")}],
            max_tokens=150,
            temperature=0.7,
        )
        return response.choices[0].message.content.strip()

    return moderate


def main():
    parser = argparse.ArgumentParser(description="3-agent code review")
    parser.add_argument("--topic", default="Review: microservices authentication using JWT with Redis session store")
    parser.add_argument("--max-turns", type=int, default=14)
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY required")
        sys.exit(1)

    backend = InMemoryBackend()
    generate_fn = create_generator()
    moderator_fn = create_moderator()

    phases = PhaseSequence(phases=[
        PhaseConfig(name="INITIAL_REVIEW", is_opening=True, max_turns=6, max_words=100, min_words=15, max_sentences=4, allow_critiques=False, constraints="Give initial assessment. Identify top concern from your perspective."),
        PhaseConfig(name="DEEP_DIVE", min_turns=6, max_turns=args.max_turns, max_words=130, min_words=20, constraints="Go deeper. Propose specific changes, patterns, or mitigations."),
        PhaseConfig(name="CLOSING", is_terminal=True),
    ])

    config = ArenaConfig(
        phases=phases,
        floor=FloorConfig(timeout_seconds=30, min_turns_between_speaking=1, max_turns_per_phase_per_agent=4),
        moderator=ModeratorConfig(silence_threshold=3, dominance_threshold=3),
        banned_phrases=["As an AI", "best practices", "industry standard"],
        max_self_retries=2,
        max_total_turns=args.max_turns,
    )

    # Domain-specific style contracts
    security_contract = StyleContract(
        description="Must mention a specific vulnerability class or attack vector. No generic 'be secure' advice.",
        required_patterns=[
            "one attack vector or vulnerability (XSS, CSRF, injection, MITM, replay, brute force, token theft, privilege escalation)",
        ],
        forbidden_patterns=[r"best practices", r"industry standard"],
    )

    perf_contract = StyleContract(
        description="Must include a measurable concern or specific optimization. No vague 'optimize' suggestions.",
        required_patterns=[
            "one performance metric or technique (latency, throughput, p99, cache hit, connection pool, batch, index, lazy load)",
        ],
        forbidden_patterns=[r"best practices", r"industry standard"],
    )

    maint_contract = StyleContract(
        description="Must reference a design pattern or code organization concern. No generic 'keep it clean' advice.",
        required_patterns=[
            "one design pattern or principle (SOLID, DRY, separation of concerns, dependency injection, interface, adapter, facade, repository)",
        ],
        forbidden_patterns=[r"best practices", r"industry standard"],
    )

    agents_config = [
        ("Security", "Security engineer. You find vulnerabilities, attack surfaces, and auth weaknesses.", ["auth", "token", "session", "access", "user", "login"], "reactive", ["vulnerability", "exploit", "attack", "CVE"], security_contract),
        ("Performance", "Performance engineer. You care about latency, throughput, and resource usage.", ["scale", "load", "request", "database", "query", "cache"], "deliberate", ["latency", "p99", "throughput", "bottleneck"], perf_contract),
        ("Maintainability", "Software architect. You care about code structure, testing, and long-term evolution.", ["implementation", "code", "design", "architecture", "pattern"], "mediating", ["refactor", "test", "interface", "coupling"], maint_contract),
    ]

    # Shared findings tracker — all agents contribute to the same findings list
    findings_tracker = FindingsTrackerCapability()

    agents = []
    for name, personality, react_to, temperament, boosts, contract in agents_config:
        validators = [
            SpeakerPrefixValidator(),
            DuplicateValidator(),
            LengthValidator(),
            BannedPhraseValidator(banned_phrases=config.banned_phrases),
            StyleContractValidator(),
        ]
        agent = FloorAgent(
            name=name,
            profile=AgentProfile(
                name=name, personality=personality, react_to=react_to,
                temperament=temperament, urgency_boost_keywords=boosts,
                style_contract=contract,
            ),
            generate_fn=generate_fn, backend=backend,
            validators=validators, config=config,
            capabilities=[findings_tracker],
        )
        agents.append(agent)

    session_id = f"review-{int(time.time())}"
    agent_names = [a.name for a in agents]

    moderator = ModeratorObserver(
        agent_names=agent_names, moderator_fn=moderator_fn,
        backend=backend, session_id=session_id,
        phase_sequence=phases, config=config.moderator,
    )

    print(f"\n{'='*60}")
    print(f"  CODE REVIEW: {args.topic}")
    print(f"  Reviewers: {', '.join(agent_names)}")
    print(f"{'='*60}\n")

    backend.create_session(session_id, {
        "topic": args.topic, "phase": "INITIAL_REVIEW", "participants": agent_names,
    })

    def print_turn(turn):
        prefix = "🎙️" if turn.is_moderator else "🔍"
        print(f"\n{prefix} [{turn.speaker}] ({turn.phase})")
        print(f"   {turn.text[:300]}{'...' if len(turn.text) > 300 else ''}")

    backend.subscribe_turns(session_id, print_turn)

    session = FloorSession(backend=backend, config=config)
    for a in agents:
        session.add_agent(a)
    session.set_moderator(moderator)

    result = session.run(session_id, topic=args.topic, timeout_seconds=args.timeout)

    print(f"\n{'='*60}")
    print(f"  CODE REVIEW COMPLETE")
    print(f"  Turns: {result.total_turns} | Duration: {result.duration_seconds:.1f}s")
    if result.session_metrics:
        gini = result.session_metrics.get("participation", {}).get("gini", "N/A")
        print(f"  Participation Gini: {gini}")
    for name, m in result.agent_metrics.items():
        val = m.get("validation", {})
        print(f"  {name}: {m['participation']['turns_posted']} turns, "
              f"validation pass rate: {val.get('pass_rate', 'N/A')}")

    # Capability output: findings report by severity
    report = findings_tracker.get_report()
    print(f"\n  CAPABILITY: FindingsTracker")
    for severity in ["critical", "major", "minor", "info"]:
        items = report[severity]
        if items:
            print(f"    {severity.upper()} ({len(items)}):")
            for f in items:
                print(f"      {f['reviewer']}: {f['summary'][:60]}")

    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
