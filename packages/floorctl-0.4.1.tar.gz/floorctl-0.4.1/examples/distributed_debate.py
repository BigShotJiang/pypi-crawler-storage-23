#!/usr/bin/env python3
"""
distributed_debate.py — Multi-machine debate via WebSocket relay.

Shows how two agents on separate processes coordinate through a relay server,
with PositionMemoryCapability tracking each agent's stated positions.

Usage (3 terminals):

    # Terminal 1: Start the relay server
    python -m floorctl.relay --port 8765 --api-key demo123

    # Terminal 2: Run Agent A (Optimist)
    python examples/distributed_debate.py --agent optimist --relay ws://localhost:8765 --api-key demo123

    # Terminal 3: Run Agent B (Skeptic)
    python examples/distributed_debate.py --agent skeptic --relay ws://localhost:8765 --api-key demo123

The first agent to connect creates the session. The second joins.
Both coordinate via the relay — atomic floor control, turn broadcast, etc.

Requires: OPENAI_API_KEY in environment or .env file.
          pip install floorctl[websocket,openai]
"""

import argparse
import logging
import os
import sys
import time

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from floorctl import (
    FloorAgent,
    FloorSession,
    ModeratorObserver,
    AgentProfile,
    AgentCapability,
    ArenaConfig,
    PhaseConfig,
    PhaseSequence,
    FloorConfig,
    ModeratorConfig,
    TurnRecord,
    SpeakerPrefixValidator,
    DuplicateValidator,
    LengthValidator,
    BannedPhraseValidator,
)
from floorctl.backends.websocket import WebSocketBackend


# ── Capabilities ────────────────────────────────────────────────────

class PositionMemoryCapability(AgentCapability):
    """Remembers the opponent's stated positions to help build counterarguments.

    In a distributed setup, each agent runs in a separate process.
    This capability shows how per-agent memory works — each instance
    independently tracks what the OTHER agent has said.

    Demonstrates:
    - on_turn_received: memorizes opponent positions
    - enrich_context: injects opponent's key points into context
    """

    name = "position_memory"

    def __init__(self):
        self.opponent_positions: list[str] = []

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        """Remember what the opponent said (skip own turns and moderator)."""
        if turn.is_moderator or turn.speaker == agent_name:
            return
        # Extract the core claim (first sentence after prefix)
        text = turn.text.split(":", 1)[-1].strip()
        first_sentence = text.split(".")[0].strip()
        if first_sentence:
            self.opponent_positions.append(first_sentence)

    def enrich_context(self, context: dict) -> dict:
        """Inject opponent's positions so agent can reference them."""
        if self.opponent_positions:
            recent = self.opponent_positions[-3:]  # Last 3 positions
            context["position_memory:opponent_claims"] = " | ".join(recent)
        return context


# ── LLM Integration ─────────────────────────────────────────────────

def create_openai_generator():
    from openai import OpenAI
    client = OpenAI()

    def generate(agent_name: str, context: dict) -> str:
        retry_info = ""
        if context.get("retry_failures"):
            retry_info = (
                f"\n\nPREVIOUS ATTEMPT FAILED. Fix these issues:\n"
                + "\n".join(f"- {f}" for f in context["retry_failures"])
            )

        prompt = f"""You are {agent_name}, a debate participant.
Personality: {context.get('personality', '')}
Topic: {context['topic']}
Current phase: {context['phase']}

Recent conversation:
{context.get('recent_turns', '(none yet)')}

RULES:
- Start your response with "{agent_name}:" prefix
- Keep it between 15 and 80 words
- Be substantive and engaging
- Reference what others said when possible
{retry_info}

Respond now as {agent_name}:"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=200,
            temperature=0.8,
        )
        return response.choices[0].message.content.strip()

    return generate


def create_moderator_fn():
    from openai import OpenAI
    client = OpenAI()

    def moderate(prompt_type: str, context: dict) -> str:
        agents = context.get("agents", [])
        topic = context.get("topic", "")

        prompts = {
            "intro": f"You are the moderator of a debate between {', '.join(agents)} about '{topic}'. Write a 2-sentence introduction.",
            "invite_opening": f"Invite {context.get('agent_name', '')} to give their opening statement. 1 sentence.",
            "phase_transition": f"Transition from {context.get('previous_phase', '')} to {context.get('phase', '')}. 1 sentence.",
            "closing": f"The debate on '{topic}' is ending. Write a 2-sentence closing.",
        }
        prompt = prompts.get(prompt_type, f"Provide a brief moderator statement about {topic}.")

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=150,
            temperature=0.7,
        )
        return response.choices[0].message.content.strip()

    return moderate


# ── Agent Definitions ────────────────────────────────────────────────

AGENTS = {
    "optimist": AgentProfile(
        name="Optimist",
        personality=(
            "You believe AI should be given rights and legal personhood. "
            "You argue from principles of progress and innovation."
        ),
        react_to=["risk", "danger", "concern", "limit"],
        temperament="passionate",
        base_cooldown=5.0,
        urgency_boost_keywords=["future", "progress", "rights"],
    ),
    "skeptic": AgentProfile(
        name="Skeptic",
        personality=(
            "You are cautious about giving AI legal personhood. "
            "You argue from principles of accountability and safety."
        ),
        react_to=["opportunity", "vision", "future", "rights"],
        temperament="reactive",
        base_cooldown=5.0,
        urgency_boost_keywords=["accountability", "safety", "risk"],
    ),
}


def main():
    parser = argparse.ArgumentParser(description="Distributed debate via WebSocket relay")
    parser.add_argument("--agent", required=True, choices=list(AGENTS.keys()),
                        help="Which agent to run")
    parser.add_argument("--relay", required=True,
                        help="Relay server URL (e.g. ws://localhost:8765)")
    parser.add_argument("--api-key", default="",
                        help="API key for relay auth")
    parser.add_argument("--session-id", default="distributed-debate-001",
                        help="Session ID (must match across agents)")
    parser.add_argument("--topic", default="Should AI systems be given legal personhood?")
    parser.add_argument("--max-turns", type=int, default=10)
    parser.add_argument("--timeout", type=int, default=120)
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY not set.")
        sys.exit(1)

    profile = AGENTS[args.agent]

    # Connect to relay
    print(f"\nConnecting to relay: {args.relay}")
    backend = WebSocketBackend(
        relay_url=args.relay,
        api_key=args.api_key,
        agent_name=profile.name,
    )
    backend.connect(timeout=10.0)
    print(f"Connected as {profile.name}")

    # Config
    phases = PhaseSequence(phases=[
        PhaseConfig(
            name="OPENING", is_opening=True, max_turns=4,
            max_words=80, min_words=10, max_sentences=3,
            allow_critiques=False,
        ),
        PhaseConfig(
            name="DEBATE", min_turns=4, max_turns=args.max_turns,
            max_words=100, min_words=15,
        ),
        PhaseConfig(name="CLOSING", is_terminal=True),
    ])

    config = ArenaConfig(
        phases=phases,
        floor=FloorConfig(timeout_seconds=30, min_turns_between_speaking=1),
        moderator=ModeratorConfig(silence_threshold=4, dominance_threshold=3),
        banned_phrases=["As an AI"],
        max_self_retries=2,
        max_total_turns=args.max_turns,
    )

    # Validators
    validators = [
        SpeakerPrefixValidator(),
        DuplicateValidator(similarity_threshold=0.65),
        LengthValidator(),
        BannedPhraseValidator(banned_phrases=config.banned_phrases),
    ]

    # Create agent with PositionMemoryCapability
    generate_fn = create_openai_generator()
    position_memory = PositionMemoryCapability()
    agent = FloorAgent(
        name=profile.name,
        profile=profile,
        generate_fn=generate_fn,
        backend=backend,
        validators=validators,
        config=config,
        capabilities=[position_memory],
    )

    # Print turns as they come in
    def print_turn(turn):
        prefix = "[MOD]" if turn.is_moderator else f"[{turn.speaker}]"
        print(f"\n  {prefix} ({turn.phase}) {turn.text[:200]}")

    # Create or join session
    print(f"\nCreating/joining session: {args.session_id}")
    backend.create_session(args.session_id, {
        "topic": args.topic,
        "phase": "OPENING",
        "participants": ["Optimist", "Skeptic"],
    })
    backend.subscribe_turns(args.session_id, print_turn)

    # Only the first agent (optimist) runs the moderator
    moderator = None
    if args.agent == "optimist":
        moderator_fn = create_moderator_fn()
        moderator = ModeratorObserver(
            agent_names=["Optimist", "Skeptic"],
            moderator_fn=moderator_fn,
            backend=backend,
            session_id=args.session_id,
            phase_sequence=phases,
            config=config.moderator,
        )

    # Run
    print(f"\n{'='*50}")
    print(f"  DISTRIBUTED DEBATE")
    print(f"  Agent: {profile.name}")
    print(f"  Topic: {args.topic}")
    print(f"  Session: {args.session_id}")
    print(f"{'='*50}\n")

    session = FloorSession(backend=backend, config=config)
    session.add_agent(agent)
    if moderator:
        session.set_moderator(moderator)

    try:
        result = session.run(
            args.session_id, topic=args.topic, timeout_seconds=args.timeout
        )

        print(f"\n{'='*50}")
        print(f"  SESSION COMPLETE")
        print(f"  Turns: {result.total_turns}")
        print(f"  Duration: {result.duration_seconds:.1f}s")

        # Capability output: opponent positions this agent tracked
        if position_memory.opponent_positions:
            print(f"\n  CAPABILITY: PositionMemory")
            print(f"  Tracked {len(position_memory.opponent_positions)} opponent positions:")
            for pos in position_memory.opponent_positions:
                print(f"    - {pos[:80]}")

        print(f"{'='*50}\n")

    except KeyboardInterrupt:
        print("\nSession interrupted.")
    finally:
        backend.disconnect()
        print("Disconnected from relay.")


if __name__ == "__main__":
    main()
