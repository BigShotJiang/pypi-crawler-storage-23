#!/usr/bin/env python3
"""
brainstorm.py — 4-agent brainstorming example using floorctl.

Demonstrates: multi-party contention, dominance detection, silence pull-in,
style contracts, phase transitions, and capabilities (IdeaTrackerCapability
to collect and deduplicate ideas across the session).

Usage:
    python examples/brainstorm.py
    python examples/brainstorm.py --topic "How to reduce AI hallucinations"
"""

import argparse
import json
import logging
import os
import sys
import time

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from floorctl import (
    FloorAgent,
    FloorSession,
    ModeratorObserver,
    AgentProfile,
    AgentCapability,
    StyleContract,
    ArenaConfig,
    PhaseConfig,
    PhaseSequence,
    FloorConfig,
    ModeratorConfig,
    InMemoryBackend,
    TurnRecord,
    SpeakerPrefixValidator,
    DuplicateValidator,
    LengthValidator,
    BannedPhraseValidator,
    StyleContractValidator,
)


# ── Capabilities ────────────────────────────────────────────────────

class IdeaTrackerCapability(AgentCapability):
    """Tracks ideas mentioned across the session to help agents build on them.

    Demonstrates:
    - on_turn_received: captures ideas from all speakers
    - enrich_context: injects collected ideas so the LLM can reference them
    """

    name = "idea_tracker"

    def __init__(self):
        self.ideas: list[dict] = []  # {speaker, idea_snippet, phase}

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        """Capture the first sentence of each non-moderator turn as an 'idea'."""
        if turn.is_moderator:
            return
        # Extract first sentence as the idea summary
        text = turn.text.split(":", 1)[-1].strip()  # Remove speaker prefix
        first_sentence = text.split(".")[0].strip()
        if first_sentence:
            self.ideas.append({
                "speaker": turn.speaker,
                "idea": first_sentence,
                "phase": turn.phase,
            })

    def enrich_context(self, context: dict) -> dict:
        """Inject collected ideas into context so the agent can reference them."""
        if self.ideas:
            idea_list = "\n".join(
                f"  - {i['speaker']}: {i['idea']}" for i in self.ideas[-6:]
            )
            context["idea_tracker:collected_ideas"] = idea_list
        return context

    def get_all_ideas(self) -> list[dict]:
        return list(self.ideas)


def create_generator():
    from openai import OpenAI
    client = OpenAI()

    def generate(agent_name: str, context: dict) -> str:
        retry_info = ""
        if context.get("retry_failures"):
            retry_info = (
                f"\n\nYour previous attempt was rejected. Fix these:\n"
                + "\n".join(f"- {f}" for f in context["retry_failures"])
            )

        prompt = f"""You are {agent_name} in a brainstorming session.
Personality: {context.get('personality', '')}
Topic: {context['topic']}
Phase: {context['phase']}
{f"Style guide: {context.get('style_contract', '')}" if context.get('style_contract') else ""}

Recent discussion:
{context.get('recent_turns', '(none)')}

RULES:
- Prefix your response with "{agent_name}:"
- {context.get('phase_min_words', 20)}-{context.get('phase_max_words', 100)} words
- Be creative and build on others' ideas
- No generic AI-speak
{retry_info}

Respond:"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=250,
            temperature=0.9,
        )
        return response.choices[0].message.content.strip()

    return generate


def create_moderator():
    from openai import OpenAI
    client = OpenAI()

    def moderate(prompt_type: str, context: dict) -> str:
        topic = context.get("topic", "")
        agents = context.get("agents", [])

        prompts = {
            "intro": f"You are facilitating a brainstorm on '{topic}' with {', '.join(agents)}. Give a 2-sentence energetic introduction.",
            "invite_opening": f"Invite {context.get('agent_name', '')} to share their initial idea on '{topic}'. 1 sentence.",
            "phase_transition": f"Transition the brainstorm from {context.get('previous_phase', '')} to {context.get('phase', '')}. Brief summary + new direction. 2 sentences.",
            "intervention": f"Moderate: {context.get('intervention_type', '')} detected. Target: {context.get('target_agent', '')}. Brief steering comment. 1-2 sentences.",
            "closing": f"Close the brainstorm on '{topic}'. Summarize top ideas. 2-3 sentences.",
        }

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompts.get(prompt_type, f"Brief comment on {topic}.")}],
            max_tokens=150,
            temperature=0.7,
        )
        return response.choices[0].message.content.strip()

    return moderate


def main():
    parser = argparse.ArgumentParser(description="4-agent brainstorming")
    parser.add_argument("--topic", default="How can we make cities more resilient to climate change?")
    parser.add_argument("--max-turns", type=int, default=24)
    parser.add_argument("--timeout", type=int, default=600)
    parser.add_argument("-o", "--output", default=None,
                        help="Save transcript to file (default: auto-named in transcripts/)")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY required")
        sys.exit(1)

    backend = InMemoryBackend()
    generate_fn = create_generator()
    moderator_fn = create_moderator()

    phases = PhaseSequence(phases=[
        PhaseConfig(name="IDEAS", is_opening=True, max_turns=12, max_words=80, min_words=10, max_sentences=3, allow_critiques=False, constraints="Share one creative idea. Max 3 sentences."),
        PhaseConfig(name="BUILD", min_turns=6, max_turns=16, max_words=120, min_words=20, constraints="Build on someone else's idea or combine ideas. Be specific."),
        PhaseConfig(name="CLOSING", is_terminal=True),
    ])

    config = ArenaConfig(
        phases=phases,
        floor=FloorConfig(timeout_seconds=30, min_turns_between_speaking=1, max_turns_per_phase_per_agent=8),
        moderator=ModeratorConfig(silence_threshold=3, dominance_threshold=3, dominance_window=6),
        banned_phrases=["As an AI", "Let's face it"],
        max_self_retries=2,
        max_total_turns=args.max_turns,
    )

    validators = [
        SpeakerPrefixValidator(),
        DuplicateValidator(),
        LengthValidator(),
        BannedPhraseValidator(banned_phrases=config.banned_phrases),
    ]

    agent_configs = [
        ("Visionary", "Bold futurist who thinks in moonshots. Uses vivid imagery.", ["limit", "can't", "impossible", "current", "today"], "passionate", ["future", "transform", "revolution"]),
        ("Realist", "Pragmatic engineer focused on what works now. Uses numbers.", ["dream", "imagine", "future", "vision"], "reactive", ["cost", "deploy", "measure", "data"]),
        ("Ethicist", "Questions assumptions. Centers equity and impact.", ["should", "must", "obviously", "always"], "provocative", ["equity", "justice", "impact", "who"]),
        ("Builder", "Hands-on maker. Thinks in prototypes and MVPs.", ["concept", "theory", "abstract", "ideal"], "deliberate", ["build", "prototype", "test", "ship"]),
    ]

    # Each agent gets its own IdeaTracker — they all see the same turns,
    # but each maintains an independent view (useful for per-agent analysis).
    idea_trackers: dict[str, IdeaTrackerCapability] = {}

    agents = []
    for name, personality, react_to, temperament, boosts in agent_configs:
        tracker = IdeaTrackerCapability()
        idea_trackers[name] = tracker
        agent = FloorAgent(
            name=name,
            profile=AgentProfile(name=name, personality=personality, react_to=react_to, temperament=temperament, urgency_boost_keywords=boosts),
            generate_fn=generate_fn,
            backend=backend,
            validators=validators,
            config=config,
            capabilities=[tracker],
        )
        agents.append(agent)

    session_id = f"brainstorm-{int(time.time())}"
    agent_names = [a.name for a in agents]

    moderator = ModeratorObserver(
        agent_names=agent_names,
        moderator_fn=moderator_fn,
        backend=backend,
        session_id=session_id,
        phase_sequence=phases,
        config=config.moderator,
    )

    print(f"\n{'='*60}")
    print(f"  BRAINSTORM: {args.topic}")
    print(f"  Agents: {', '.join(agent_names)}")
    print(f"{'='*60}\n")

    backend.create_session(session_id, {
        "topic": args.topic,
        "phase": "IDEAS",
        "participants": agent_names,
    })

    def print_turn(turn):
        prefix = "🎙️" if turn.is_moderator else "💡"
        print(f"\n{prefix} [{turn.speaker}] ({turn.phase})")
        print(f"   {turn.text[:250]}{'...' if len(turn.text) > 250 else ''}")

    backend.subscribe_turns(session_id, print_turn)

    session = FloorSession(backend=backend, config=config)
    for a in agents:
        session.add_agent(a)
    session.set_moderator(moderator)

    result = session.run(session_id, topic=args.topic, timeout_seconds=args.timeout)

    print(f"\n{'='*60}")
    print(f"  BRAINSTORM COMPLETE")
    print(f"  Turns: {result.total_turns} | Duration: {result.duration_seconds:.1f}s")
    if result.session_metrics:
        gini = result.session_metrics.get("participation", {}).get("gini", "N/A")
        turns = result.session_metrics.get("turns", {}).get("per_agent", {})
        print(f"  Gini: {gini} | Turns: {json.dumps(turns)}")
        interv = result.session_metrics.get("interventions", {}).get("total", 0)
        if interv:
            print(f"  Interventions: {interv}")
    # Capability output: show collected ideas from one tracker (they all see the same turns)
    any_tracker = list(idea_trackers.values())[0]
    all_ideas = any_tracker.get_all_ideas()
    if all_ideas:
        print(f"\n  CAPABILITY: IdeaTracker ({len(all_ideas)} ideas collected)")
        for idea in all_ideas:
            print(f"    [{idea['phase']}] {idea['speaker']}: {idea['idea'][:80]}")

    print(f"{'='*60}\n")

    # Save transcript to file
    from floorctl.transcript import export_transcript

    output_path = args.output or f"transcripts/{session_id}.md"
    saved_path = export_transcript(result, output_path)
    print(f"  Transcript saved to: {saved_path}\n")


if __name__ == "__main__":
    main()
