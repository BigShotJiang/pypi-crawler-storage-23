#!/usr/bin/env python3
"""
research_team.py — Research team with EXTENSIVE multi-capability composition.

This example shows advanced capability patterns: shared state between capabilities,
capability chaining order mattering, and capabilities that interact with each other
through the context dict.

Scenario:
  A research team evaluates a technical topic and produces a structured research brief.
  - Researcher: Finds and cites sources (simulated web search)
  - Analyst: Evaluates evidence quality, identifies gaps
  - Writer: Synthesizes findings into clear prose
  - FactChecker: Cross-references claims against known facts

Advanced capability patterns demonstrated:
  1. CitationCapability     — enrich_context + post_process: adds citations, enforces format
  2. SourceRegistryCapability — on_turn_received: builds a shared registry of all cited sources
  3. ClaimExtractorCapability — on_turn_received + enrich_context: extracts and tracks factual claims
  4. QualityScorerCapability  — post_process: scores response quality on multiple dimensions
  5. BriefBuilderCapability   — on_turn_received + enrich_context: incrementally builds the research brief

This is the ADVANCED example — it shows capabilities that:
- Share state through a common object
- Chain in a specific order (citation before quality scoring)
- Read each other's context keys (brief builder reads claim extractor's data)

Usage:
    python examples/research_team.py
    python examples/research_team.py --topic "Impact of LLMs on software engineering productivity"
    python examples/research_team.py -v  # verbose
"""

import argparse
import json
import logging
import os
import re
import sys
import time
from dataclasses import dataclass, field

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from floorctl import (
    FloorAgent,
    FloorSession,
    ModeratorObserver,
    AgentProfile,
    AgentCapability,
    ArenaConfig,
    PhaseConfig,
    PhaseSequence,
    FloorConfig,
    ModeratorConfig,
    InMemoryBackend,
    TurnRecord,
    SpeakerPrefixValidator,
    DuplicateValidator,
    LengthValidator,
    BannedPhraseValidator,
)


# ═══════════════════════════════════════════════════════════════════════
# SHARED STATE — Capabilities can share state through a common object.
# This is the recommended pattern for capabilities that need to coordinate.
# ═══════════════════════════════════════════════════════════════════════


@dataclass
class ResearchState:
    """Shared state that multiple capabilities read and write.

    This is the "glue" that lets capabilities interact without
    coupling to each other directly.
    """
    sources: list[dict] = field(default_factory=list)        # All cited sources
    claims: list[dict] = field(default_factory=list)          # Extracted factual claims
    brief_sections: dict[str, str] = field(default_factory=dict)  # Accumulated brief
    quality_scores: list[dict] = field(default_factory=list)  # Per-turn quality scores
    total_turns_processed: int = 0


# ═══════════════════════════════════════════════════════════════════════
# CAPABILITIES
# ═══════════════════════════════════════════════════════════════════════


class CitationCapability(AgentCapability):
    """Provides simulated research sources and enforces citation format.

    This is the "Researcher's superpower" — it enriches context with relevant
    sources before generation, and post-processes to ensure citations are properly
    formatted.

    Hook used: enrich_context, post_process
    Pipeline: enrich_context runs FIRST (adds sources) → LLM generates →
              post_process runs AFTER (formats citations)
    """

    name = "citation"

    # Simulated source database — in production, this would be a search API
    SOURCES = {
        "llm": [
            {"id": "S1", "title": "GitHub Copilot Productivity Study", "year": 2023, "finding": "55% faster task completion with AI pair programming"},
            {"id": "S2", "title": "LLM Code Quality Meta-analysis", "year": 2024, "finding": "Generated code has 15-40% more bugs than human-written code"},
            {"id": "S3", "title": "Stack Overflow Developer Survey 2024", "year": 2024, "finding": "76% of developers use AI coding tools"},
        ],
        "productivity": [
            {"id": "S4", "title": "Microsoft Research: AI and Developer Productivity", "year": 2024, "finding": "Task completion time reduced but debugging time increased"},
            {"id": "S5", "title": "Google DeepMind: Code Generation Benchmark", "year": 2024, "finding": "SOTA models solve 85% of HumanEval but only 12% of real-world bugs"},
        ],
        "software": [
            {"id": "S6", "title": "ACM Survey: AI-Assisted Software Engineering", "year": 2024, "finding": "Code review time reduced 30% with AI suggestions"},
            {"id": "S7", "title": "IEEE: Technical Debt in AI-Generated Code", "year": 2024, "finding": "AI-generated code accumulates technical debt 2x faster than manual code"},
        ],
        "engineering": [
            {"id": "S8", "title": "Nature: Measuring Software Engineering Productivity", "year": 2023, "finding": "Productivity metrics (DORA, SPACE) show mixed results for AI adoption"},
        ],
    }

    def __init__(self, state: ResearchState):
        self.state = state

    def enrich_context(self, context: dict) -> dict:
        """Inject relevant sources based on topic keywords."""
        topic = context.get("topic", "").lower()
        recent = context.get("recent_turns", "").lower()
        search_text = f"{topic} {recent}"

        relevant = []
        for keyword, sources in self.SOURCES.items():
            if keyword in search_text:
                relevant.extend(sources)

        # Deduplicate
        seen_ids = {s["id"] for s in self.state.sources}
        new_sources = [s for s in relevant if s["id"] not in seen_ids]

        if new_sources or self.state.sources:
            all_sources = list({s["id"]: s for s in self.state.sources + new_sources}.values())
            source_text = "\n".join(
                f"  [{s['id']}] {s['title']} ({s['year']}): {s['finding']}"
                for s in all_sources[:6]
            )
            context["citation:available_sources"] = source_text
            context["citation:source_count"] = str(len(all_sources))
        return context

    def post_process(self, response: str, context: dict) -> str:
        """Track any sources that were actually cited in the response."""
        for keyword, sources in self.SOURCES.items():
            for source in sources:
                if source["id"] in response and source not in self.state.sources:
                    self.state.sources.append(source)
        return response


class SourceRegistryCapability(AgentCapability):
    """Maintains a registry of all sources cited across the discussion.

    This capability is "passive" — it only uses on_turn_received to track
    citations mentioned by ANY agent. It doesn't modify context or responses.

    Hook used: on_turn_received
    """

    name = "source_registry"

    def __init__(self, state: ResearchState):
        self.state = state

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        """Scan each turn for source references ([S1], [S2], etc.)."""
        if turn.is_moderator:
            return
        # Find all [Sn] references
        refs = re.findall(r'\[S(\d+)\]', turn.text)
        for ref_num in refs:
            source_id = f"S{ref_num}"
            # Check if we already have this source
            if not any(s["id"] == source_id for s in self.state.sources):
                self.state.sources.append({
                    "id": source_id,
                    "title": f"Referenced source {source_id}",
                    "year": 2024,
                    "finding": "Referenced in discussion",
                    "cited_by": turn.speaker,
                })


class ClaimExtractorCapability(AgentCapability):
    """Extracts factual claims from turns for fact-checking.

    Demonstrates capability chaining: the FactChecker agent uses this capability
    to know what claims have been made, then responds to verify or challenge them.

    Hook used: on_turn_received, enrich_context
    """

    name = "claim_extractor"

    CLAIM_INDICATORS = [
        r"(\d+%\s+[\w\s]+)",                    # "55% faster completion"
        r"(\d+x\s+[\w\s]+)",                    # "2x faster"
        r"(studies?\s+show\w*\s+.+?)(?:\.|$)",   # "studies show..."
        r"(research\s+\w+\s+.+?)(?:\.|$)",       # "research indicates..."
        r"(data\s+suggests?\s+.+?)(?:\.|$)",      # "data suggests..."
    ]

    def __init__(self, state: ResearchState):
        self.state = state

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        if turn.is_moderator:
            return
        for pattern in self.CLAIM_INDICATORS:
            matches = re.findall(pattern, turn.text, re.IGNORECASE)
            for match in matches:
                claim = match.strip()[:120]
                if claim and len(claim) > 10:
                    self.state.claims.append({
                        "claim": claim,
                        "by": turn.speaker,
                        "phase": turn.phase,
                        "verified": False,
                    })

    def enrich_context(self, context: dict) -> dict:
        """Inject unverified claims for the FactChecker to address."""
        unverified = [c for c in self.state.claims if not c["verified"]]
        if unverified:
            claims_text = "\n".join(
                f"  - {c['by']}: \"{c['claim']}\"" for c in unverified[-4:]
            )
            context["claims:unverified"] = claims_text
            context["claims:total"] = str(len(self.state.claims))
            context["claims:unverified_count"] = str(len(unverified))
        return context


class QualityScorerCapability(AgentCapability):
    """Scores each response on multiple quality dimensions.

    Demonstrates post_process that doesn't modify the response — it only
    records metrics about it. This is a monitoring/analytics capability.

    Hook used: post_process
    """

    name = "quality_scorer"

    def __init__(self, state: ResearchState):
        self.state = state

    def post_process(self, response: str, context: dict) -> str:
        """Score the response (but don't modify it)."""
        words = response.split()
        word_count = len(words)

        # Score dimensions (simple heuristics — production would use an LLM judge)
        specificity = min(1.0, len(re.findall(r'\d+', response)) * 0.2)  # Has numbers?
        citation_score = min(1.0, len(re.findall(r'\[S\d+\]', response)) * 0.3)  # Has citations?
        length_score = min(1.0, word_count / 80)  # Reasonable length?

        # Penalize generic phrases
        generic_phrases = ["in general", "it depends", "there are many", "various factors"]
        generic_penalty = sum(0.1 for p in generic_phrases if p in response.lower())

        overall = max(0, (specificity + citation_score + length_score) / 3 - generic_penalty)

        self.state.quality_scores.append({
            "agent": context.get("agent_name", "unknown"),
            "overall": round(overall, 2),
            "specificity": round(specificity, 2),
            "citation": round(citation_score, 2),
            "length": round(length_score, 2),
            "word_count": word_count,
        })
        self.state.total_turns_processed += 1

        return response  # Never modify — scoring only


class BriefBuilderCapability(AgentCapability):
    """Incrementally builds a research brief from the discussion.

    This is the most complex capability — it reads from other capabilities'
    context keys (citations, claims) and accumulates a structured document.

    Demonstrates:
    - on_turn_received: categorizes turns into brief sections
    - enrich_context: injects the current brief so agents know what's covered

    Hook used: on_turn_received, enrich_context
    """

    name = "brief_builder"

    def __init__(self, state: ResearchState):
        self.state = state

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        """Categorize each turn's content into brief sections."""
        if turn.is_moderator:
            return

        text = turn.text.split(":", 1)[-1].strip()
        text_lower = text.lower()

        # Categorize into sections based on content
        if turn.phase == "RESEARCH":
            section = "findings"
        elif turn.phase == "ANALYSIS":
            if any(w in text_lower for w in ["gap", "missing", "unclear", "limitation"]):
                section = "gaps"
            elif any(w in text_lower for w in ["strong", "weak", "evidence", "support"]):
                section = "evidence_quality"
            else:
                section = "analysis"
        elif turn.phase == "SYNTHESIS":
            section = "synthesis"
        else:
            section = "other"

        # Append to the appropriate section
        current = self.state.brief_sections.get(section, "")
        new_entry = f"[{turn.speaker}] {text[:150]}"
        self.state.brief_sections[section] = (
            f"{current}\n{new_entry}" if current else new_entry
        )

    def enrich_context(self, context: dict) -> dict:
        """Show the current brief so agents know what's been covered."""
        if self.state.brief_sections:
            sections_summary = []
            for section, content in self.state.brief_sections.items():
                line_count = content.count("\n") + 1
                sections_summary.append(f"  {section}: {line_count} entries")
            context["brief:sections_covered"] = "\n".join(sections_summary)
            context["brief:total_sections"] = str(len(self.state.brief_sections))
        return context

    def get_brief(self) -> str:
        """Format the accumulated brief as a readable document."""
        if not self.state.brief_sections:
            return "(No brief generated)"

        lines = ["RESEARCH BRIEF", "=" * 40]
        section_order = ["findings", "evidence_quality", "analysis", "gaps", "synthesis", "other"]
        for section in section_order:
            content = self.state.brief_sections.get(section)
            if content:
                lines.append(f"\n## {section.replace('_', ' ').title()}")
                lines.append(content)

        # Add sources
        if self.state.sources:
            lines.append(f"\n## Sources ({len(self.state.sources)})")
            for s in self.state.sources:
                lines.append(f"  [{s['id']}] {s['title']} ({s['year']})")

        # Add claims
        if self.state.claims:
            lines.append(f"\n## Claims ({len(self.state.claims)})")
            verified = [c for c in self.state.claims if c["verified"]]
            lines.append(f"  Verified: {len(verified)}/{len(self.state.claims)}")

        return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════
# LLM Integration
# ═══════════════════════════════════════════════════════════════════════


def create_generator():
    from openai import OpenAI
    client = OpenAI()

    def generate(agent_name: str, context: dict) -> str:
        retry_info = ""
        if context.get("retry_failures"):
            retry_info = (
                f"\n\nPREVIOUS ATTEMPT REJECTED. Fix these:\n"
                + "\n".join(f"- {f}" for f in context["retry_failures"])
            )

        # Build capability-enriched sections
        extra = ""
        if context.get("citation:available_sources"):
            extra += f"\nAVAILABLE SOURCES:\n{context['citation:available_sources']}\n"
        if context.get("claims:unverified"):
            extra += f"\nUNVERIFIED CLAIMS:\n{context['claims:unverified']}\n"
        if context.get("brief:sections_covered"):
            extra += f"\nBRIEF PROGRESS:\n{context['brief:sections_covered']}\n"

        prompt = f"""You are {agent_name}, a research team member.
Role: {context.get('personality', '')}
Research Topic: {context['topic']}
Phase: {context['phase']}
{extra}

Discussion so far:
{context.get('recent_turns', '(none yet)')}

RULES:
- Prefix with "{agent_name}:"
- {context.get('phase_min_words', 20)}-{context.get('phase_max_words', 120)} words
- Cite sources using [S1], [S2] format when available
- Be specific — use numbers, percentages, and concrete examples
- Build on what others have said, don't repeat
{retry_info}

{agent_name}:"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=250,
            temperature=0.7,
        )
        text = response.choices[0].message.content.strip()
        if not text.startswith(f"{agent_name}:"):
            text = f"{agent_name}: {text}"
        return text

    return generate


def create_moderator():
    from openai import OpenAI
    client = OpenAI()

    def moderate(prompt_type: str, context: dict) -> str:
        topic = context.get("topic", "")
        agents = context.get("agents", [])

        prompts = {
            "intro": (
                f"You are the Research Director leading a team of {', '.join(agents)} "
                f"investigating: '{topic}'. Give a 2-sentence introduction framing "
                f"the research question and what you need from each team member."
            ),
            "invite_opening": (
                f"Ask {context.get('agent_name', '')} to present their initial "
                f"findings on '{topic}'. 1 sentence."
            ),
            "phase_transition": (
                f"Transition from {context.get('previous_phase', '')} to "
                f"{context.get('phase', '')}. Summarize what we've learned. 2 sentences."
            ),
            "intervention": (
                f"Research Director: {context.get('intervention_type', '')}. "
                f"Redirect to {context.get('target_agent', '')}. 1 sentence."
            ),
            "closing": (
                f"Close the research session on '{topic}'. Summarize key findings "
                f"and identify remaining questions. 2-3 sentences."
            ),
        }

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompts.get(prompt_type, f"Brief comment on {topic}.")}],
            max_tokens=150,
            temperature=0.7,
        )
        return response.choices[0].message.content.strip()

    return moderate


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════


def main():
    parser = argparse.ArgumentParser(description="Research team with advanced capabilities")
    parser.add_argument(
        "--topic",
        default="Impact of LLMs on software engineering productivity: evidence and gaps",
    )
    parser.add_argument("--max-turns", type=int, default=16)
    parser.add_argument("--timeout", type=int, default=200)
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY required")
        sys.exit(1)

    backend = InMemoryBackend()
    generate_fn = create_generator()
    moderator_fn = create_moderator()

    # ── Shared State ────────────────────────────────────────────────
    state = ResearchState()

    # ── Capabilities ────────────────────────────────────────────────
    # All share the same ResearchState — this is the coordination pattern
    citation = CitationCapability(state)
    source_registry = SourceRegistryCapability(state)
    claim_extractor = ClaimExtractorCapability(state)
    quality_scorer = QualityScorerCapability(state)
    brief_builder = BriefBuilderCapability(state)

    # ── Phases ──────────────────────────────────────────────────────
    phases = PhaseSequence(phases=[
        PhaseConfig(
            name="RESEARCH",
            is_opening=True,
            max_turns=8,
            max_words=100,
            min_words=20,
            max_sentences=5,
            allow_critiques=False,
            constraints="Present findings with citations. Use [S1], [S2] format for sources.",
        ),
        PhaseConfig(
            name="ANALYSIS",
            min_turns=6,
            max_turns=12,
            max_words=120,
            min_words=20,
            constraints="Evaluate evidence quality. Identify gaps, contradictions, and strengths.",
        ),
        PhaseConfig(
            name="SYNTHESIS",
            min_turns=4,
            max_turns=8,
            max_words=100,
            min_words=20,
            constraints="Synthesize findings into clear conclusions. Identify remaining questions.",
            max_sentences=4,
        ),
        PhaseConfig(name="CLOSING", is_terminal=True),
    ])

    config = ArenaConfig(
        phases=phases,
        floor=FloorConfig(timeout_seconds=30, min_turns_between_speaking=1, max_turns_per_phase_per_agent=4),
        moderator=ModeratorConfig(silence_threshold=3, dominance_threshold=3),
        banned_phrases=["As an AI", "It's worth noting"],
        max_self_retries=2,
        max_total_turns=args.max_turns,
    )

    validators = [
        SpeakerPrefixValidator(),
        DuplicateValidator(),
        LengthValidator(),
        BannedPhraseValidator(banned_phrases=config.banned_phrases),
    ]

    # ── Agents with layered capabilities ────────────────────────────
    #
    # CAPABILITY CHAINING ORDER MATTERS:
    #   enrich_context runs in insertion order: citation → claim_extractor → brief_builder
    #   post_process runs in insertion order: citation → quality_scorer
    #   on_turn_received runs in insertion order: source_registry → claim_extractor → brief_builder
    #
    # This means:
    #   - citation enriches context FIRST (adds sources)
    #   - claim_extractor sees turns BEFORE brief_builder categorizes them
    #   - quality_scorer scores AFTER citation post-processing

    researcher = FloorAgent(
        name="Researcher",
        profile=AgentProfile(
            name="Researcher",
            personality=(
                "Research specialist. You find and cite relevant studies, papers, "
                "and data. You always reference specific sources with [S1] format. "
                "You care about source quality and recency."
            ),
            react_to=["evidence", "source", "study", "data", "claim", "finding"],
            temperament="deliberate",
            base_cooldown=5.0,
            urgency_boost_keywords=["source", "study", "paper", "data", "evidence"],
        ),
        generate_fn=generate_fn,
        backend=backend,
        validators=validators,
        config=config,
        capabilities=[citation, source_registry, brief_builder, quality_scorer],
    )

    analyst = FloorAgent(
        name="Analyst",
        profile=AgentProfile(
            name="Analyst",
            personality=(
                "Evidence analyst. You evaluate the strength and quality of cited "
                "evidence. You identify gaps, methodological weaknesses, and "
                "conflicting results. You think critically about sample sizes, "
                "confounders, and generalizability."
            ),
            react_to=["found", "shows", "evidence", "result", "conclusion", "percent"],
            temperament="provocative",
            base_cooldown=6.0,
            urgency_boost_keywords=["bias", "limitation", "gap", "conflicting", "methodology"],
        ),
        generate_fn=generate_fn,
        backend=backend,
        validators=validators,
        config=config,
        capabilities=[citation, source_registry, claim_extractor, brief_builder, quality_scorer],
    )

    writer = FloorAgent(
        name="Writer",
        profile=AgentProfile(
            name="Writer",
            personality=(
                "Research writer. You synthesize findings into clear, structured "
                "prose. You create summaries, identify themes, and write for "
                "a technical audience. You ensure the narrative is coherent."
            ),
            react_to=["finding", "result", "analysis", "conclude", "summary", "theme"],
            temperament="patient",
            base_cooldown=7.0,
            urgency_boost_keywords=["synthesize", "summary", "theme", "narrative", "conclusion"],
        ),
        generate_fn=generate_fn,
        backend=backend,
        validators=validators,
        config=config,
        capabilities=[source_registry, brief_builder, quality_scorer],
    )

    fact_checker = FloorAgent(
        name="FactChecker",
        profile=AgentProfile(
            name="FactChecker",
            personality=(
                "Fact verification specialist. You cross-reference claims against "
                "known data. You flag unsupported assertions, verify statistics, "
                "and check if sources are being cited accurately. You are rigorous "
                "but constructive."
            ),
            react_to=["percent", "study", "shows", "proven", "always", "never", "claim"],
            temperament="reactive",
            base_cooldown=6.0,
            urgency_boost_keywords=["verify", "check", "confirm", "accurate", "claim", "false"],
        ),
        generate_fn=generate_fn,
        backend=backend,
        validators=validators,
        config=config,
        capabilities=[citation, source_registry, claim_extractor, brief_builder, quality_scorer],
    )

    # ── Session Setup ───────────────────────────────────────────────
    session_id = f"research-{int(time.time())}"
    agent_names = ["Researcher", "Analyst", "Writer", "FactChecker"]

    moderator = ModeratorObserver(
        agent_names=agent_names,
        moderator_fn=moderator_fn,
        backend=backend,
        session_id=session_id,
        phase_sequence=phases,
        config=config.moderator,
    )

    # Print header
    print(f"\n{'='*70}")
    print(f"  RESEARCH TEAM — ADVANCED CAPABILITY SHOWCASE")
    print(f"  Topic: {args.topic}")
    print(f"  Team: {', '.join(agent_names)}")
    print(f"{'='*70}")
    print(f"  Capability Matrix:")
    print(f"    Researcher:   Citation, SourceRegistry, BriefBuilder, QualityScorer")
    print(f"    Analyst:      Citation, SourceRegistry, ClaimExtractor, BriefBuilder, QualityScorer")
    print(f"    Writer:       SourceRegistry, BriefBuilder, QualityScorer")
    print(f"    FactChecker:  Citation, SourceRegistry, ClaimExtractor, BriefBuilder, QualityScorer")
    print(f"{'='*70}\n")

    backend.create_session(session_id, {
        "topic": args.topic,
        "phase": "RESEARCH",
        "participants": agent_names,
    })

    def print_turn(turn):
        if turn.is_moderator:
            print(f"\n  {'─'*60}")
            print(f"  📋 Research Director  [{turn.phase}]")
            print(f"  {turn.text}")
            print(f"  {'─'*60}")
        else:
            icons = {"Researcher": "🔍", "Analyst": "📊", "Writer": "✍️", "FactChecker": "✅"}
            icon = icons.get(turn.speaker, "👤")
            print(f"\n  {icon} {turn.speaker}  [{turn.phase}]")
            print(f"     {turn.text}")

    backend.subscribe_turns(session_id, print_turn)

    session = FloorSession(backend=backend, config=config)
    session.add_agent(researcher)
    session.add_agent(analyst)
    session.add_agent(writer)
    session.add_agent(fact_checker)
    session.set_moderator(moderator)

    result = session.run(session_id, topic=args.topic, timeout_seconds=args.timeout)

    # ═══════════════════════════════════════════════════════════════
    # RESULTS — Show what each capability produced
    # ═══════════════════════════════════════════════════════════════

    print(f"\n{'='*70}")
    print(f"  RESEARCH SESSION COMPLETE")
    print(f"{'='*70}")
    print(f"  Turns: {result.total_turns} | Duration: {result.duration_seconds:.1f}s")

    if result.session_metrics:
        gini = result.session_metrics.get("participation", {}).get("gini", "N/A")
        turns = result.session_metrics.get("turns", {}).get("per_agent", {})
        print(f"  Gini: {gini}")
        for agent, count in sorted(turns.items(), key=lambda x: -x[1]):
            print(f"    {agent}: {count} turns")

    # ── Capability Reports ──────────────────────────────────────────

    print(f"\n  {'─'*60}")
    print(f"  CAPABILITY REPORTS (from shared ResearchState)")
    print(f"  {'─'*60}")

    # Sources
    print(f"\n  📚 Citation & Source Registry ({len(state.sources)} sources)")
    for s in state.sources:
        print(f"    [{s['id']}] {s['title']} ({s['year']})")

    # Claims
    print(f"\n  📋 Claim Extractor ({len(state.claims)} claims)")
    for c in state.claims:
        verified = "✅" if c["verified"] else "❓"
        print(f"    {verified} {c['by']}: {c['claim'][:60]}")

    # Quality scores
    if state.quality_scores:
        print(f"\n  📊 Quality Scorer ({len(state.quality_scores)} scored)")
        by_agent: dict[str, list] = {}
        for s in state.quality_scores:
            by_agent.setdefault(s["agent"], []).append(s["overall"])
        for agent, scores in sorted(by_agent.items()):
            avg = sum(scores) / len(scores)
            print(f"    {agent}: avg quality {avg:.2f} ({len(scores)} responses)")

    # Brief
    print(f"\n  📄 Brief Builder ({len(state.brief_sections)} sections)")
    brief = brief_builder.get_brief()
    # Print first 20 lines of the brief
    brief_lines = brief.split("\n")[:20]
    for line in brief_lines:
        print(f"    {line}")
    if len(brief.split("\n")) > 20:
        print(f"    ... ({len(brief.split(chr(10))) - 20} more lines)")

    print(f"\n{'='*70}\n")


if __name__ == "__main__":
    main()
