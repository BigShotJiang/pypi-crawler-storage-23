#!/usr/bin/env python3
"""
debate.py — 2-agent debate example using floorctl.

Demonstrates: basic floor contention, urgency-driven turn-taking, fairness metrics,
and capabilities (TurnLoggerCapability for observability).

Usage:
    python examples/debate.py                         # In-memory + console
    python examples/debate.py --backend firestore     # Write to Firestore

Requires: OPENAI_API_KEY in environment or .env file.
"""

import argparse
import json
import logging
import os
import sys
import time

# Load .env if available
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from floorctl import (
    FloorAgent,
    FloorSession,
    ModeratorObserver,
    AgentProfile,
    AgentCapability,
    StyleContract,
    ArenaConfig,
    PhaseConfig,
    PhaseSequence,
    FloorConfig,
    ModeratorConfig,
    InMemoryBackend,
    TurnRecord,
    SpeakerPrefixValidator,
    DuplicateValidator,
    LengthValidator,
    BannedPhraseValidator,
)


# ── Capabilities ────────────────────────────────────────────────────

class TurnLoggerCapability(AgentCapability):
    """Logs every turn to a list for post-session analysis.

    Demonstrates: on_turn_received hook for observability.
    """

    name = "turn_logger"

    def __init__(self):
        self.log: list[dict] = []

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        self.log.append({
            "speaker": turn.speaker,
            "phase": turn.phase,
            "words": len(turn.text.split()),
            "is_own": turn.speaker == agent_name,
        })

    def summary(self) -> dict:
        """Return a summary of observed turns."""
        speakers: dict[str, int] = {}
        total_words = 0
        for entry in self.log:
            speakers[entry["speaker"]] = speakers.get(entry["speaker"], 0) + 1
            total_words += entry["words"]
        return {
            "total_turns_observed": len(self.log),
            "total_words": total_words,
            "turns_by_speaker": speakers,
        }

# ── LLM Integration ─────────────────────────────────────────────────

def create_openai_generator():
    """Create a generate_fn using OpenAI GPT-4o-mini."""
    from openai import OpenAI
    client = OpenAI()

    def generate(agent_name: str, context: dict) -> str:
        retry_info = ""
        if context.get("retry_failures"):
            retry_info = (
                f"\n\nPREVIOUS ATTEMPT FAILED. Fix these issues:\n"
                + "\n".join(f"- {f}" for f in context["retry_failures"])
            )

        prompt = f"""You are {agent_name}, a debate participant.
Personality: {context.get('personality', '')}
Topic: {context['topic']}
Current phase: {context['phase']}
{f"Style contract: {context.get('style_contract', '')}" if context.get('style_contract') else ""}
{f"Phase constraints: {context.get('phase_constraints', '')}" if context.get('phase_constraints') else ""}

Recent conversation:
{context.get('recent_turns', '(none yet)')}

RULES:
- Start your response with "{agent_name}:" prefix
- Keep it between {context.get('phase_min_words', 15)} and {context.get('phase_max_words', 100)} words
- Be substantive and engaging — this is a real debate
- Reference what others said when possible
- No "As an AI" or generic filler phrases
{retry_info}

Respond now as {agent_name}:"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=300,
            temperature=0.8,
        )
        return response.choices[0].message.content.strip()

    return generate


def create_moderator_fn():
    """Create a moderator_fn using OpenAI GPT-4o-mini."""
    from openai import OpenAI
    client = OpenAI()

    def moderate(prompt_type: str, context: dict) -> str:
        agents = context.get("agents", [])
        topic = context.get("topic", "")

        if prompt_type == "intro":
            prompt = f"""You are the moderator of a debate between {', '.join(agents)}.
Topic: {topic}

Write a brief, engaging introduction (2-3 sentences). Welcome the participants
and frame the debate topic. Be concise and energetic."""

        elif prompt_type == "invite_opening":
            agent = context.get("agent_name", "")
            prompt = f"""You are the moderator. Invite {agent} to give their opening statement
on "{topic}". Keep it to 1 sentence."""

        elif prompt_type == "phase_transition":
            prev = context.get("previous_phase", "")
            new = context.get("phase", "")
            prompt = f"""You are the moderator. Transition from {prev} to {new}.
Topic: {topic}
Summary of discussion so far:
{context.get('transcript_summary', '')}

Write a brief transition (1-2 sentences)."""

        elif prompt_type == "intervention":
            itype = context.get("intervention_type", "")
            target = context.get("target_agent", "")
            details = context.get("details", {})

            if itype == "escalation":
                prompt = f"""You are the moderator. The debate is getting heated.
Gently deescalate and redirect the conversation. 1-2 sentences."""
            elif itype == "dominance":
                dominant = details.get("dominant_agent", "someone")
                prompt = f"""You are the moderator. {dominant} has been dominating.
Redirect to {target} with a specific question. 1 sentence."""
            elif itype == "silence":
                prompt = f"""You are the moderator. {target} hasn't spoken recently.
Invite them to share their perspective. 1 sentence."""
            else:
                prompt = f"You are the moderator. Provide a brief intervention. 1 sentence."

        elif prompt_type == "closing":
            prompt = f"""You are the moderator. The debate on "{topic}" is ending.
Summary of discussion:
{context.get('transcript_summary', '')}

Write a brief closing (2-3 sentences). Summarize key points and thank participants."""

        else:
            prompt = f"You are the moderator. Provide a brief statement about {topic}."

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=200,
            temperature=0.7,
        )
        return response.choices[0].message.content.strip()

    return moderate


# ── Main ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="2-agent debate example")
    parser.add_argument("--backend", choices=["memory", "firestore"], default="memory")
    parser.add_argument("--topic", default="Should AI systems be given legal personhood?")
    parser.add_argument("--max-turns", type=int, default=12)
    parser.add_argument("--timeout", type=int, default=120)
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    # Logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    # Check API key
    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY not set. Export it or add to .env file.")
        sys.exit(1)

    # Backend
    if args.backend == "firestore":
        print("Firestore backend not yet implemented — using in-memory")
    backend = InMemoryBackend()

    # Config
    phases = PhaseSequence(phases=[
        PhaseConfig(
            name="OPENING", is_opening=True, max_turns=4,
            max_words=80, min_words=10, max_sentences=3,
            allow_critiques=False, constraints="State your position clearly. Max 3 sentences.",
        ),
        PhaseConfig(
            name="DEBATE", min_turns=6, max_turns=args.max_turns,
            constraints="Engage with the other side. Critique, question, and build arguments. 30-100 words.",
            max_words=120, min_words=20,
        ),
        PhaseConfig(name="CLOSING", is_terminal=True),
    ])

    config = ArenaConfig(
        phases=phases,
        floor=FloorConfig(
            timeout_seconds=30,
            min_turns_between_speaking=1,
            max_turns_per_phase_per_agent=5,
        ),
        moderator=ModeratorConfig(
            silence_threshold=4,
            dominance_threshold=3,
            dominance_window=6,
        ),
        banned_phrases=["As an AI", "Let's face it", "In conclusion"],
        max_self_retries=2,
        max_total_turns=args.max_turns,
    )

    # Create generator functions
    generate_fn = create_openai_generator()
    moderator_fn = create_moderator_fn()

    # Validators
    validators = [
        SpeakerPrefixValidator(),
        DuplicateValidator(similarity_threshold=0.65),
        LengthValidator(),
        BannedPhraseValidator(banned_phrases=config.banned_phrases),
    ]

    # Capabilities (shared so we can inspect after session)
    optimist_logger = TurnLoggerCapability()
    skeptic_logger = TurnLoggerCapability()

    # Agents — each gets a TurnLoggerCapability for observability
    optimist = FloorAgent(
        name="Optimist",
        profile=AgentProfile(
            name="Optimist",
            personality=(
                "You believe AI should be given rights and legal personhood. "
                "You argue from principles of progress, autonomy, and innovation. "
                "You use bold, forward-looking language."
            ),
            react_to=["risk", "danger", "problem", "concern", "can't", "impossible", "limit"],
            temperament="passionate",
            base_cooldown=5.0,
            urgency_boost_keywords=["future", "progress", "rights", "freedom"],
        ),
        generate_fn=generate_fn,
        backend=backend,
        validators=validators,
        config=config,
        capabilities=[optimist_logger],
    )

    skeptic = FloorAgent(
        name="Skeptic",
        profile=AgentProfile(
            name="Skeptic",
            personality=(
                "You are cautious about giving AI legal personhood. "
                "You argue from principles of accountability, safety, and precedent. "
                "You use data-driven, measured language."
            ),
            react_to=["opportunity", "vision", "future", "should", "must", "rights"],
            temperament="reactive",
            base_cooldown=5.0,
            urgency_boost_keywords=["accountability", "precedent", "safety", "risk"],
        ),
        generate_fn=generate_fn,
        backend=backend,
        validators=validators,
        config=config,
        capabilities=[skeptic_logger],
    )

    # Moderator
    session_id = f"debate-{int(time.time())}"
    moderator = ModeratorObserver(
        agent_names=["Optimist", "Skeptic"],
        moderator_fn=moderator_fn,
        backend=backend,
        session_id=session_id,
        phase_sequence=phases,
        config=config.moderator,
    )

    # Run session
    print(f"\n{'='*60}")
    print(f"  DEBATE: {args.topic}")
    print(f"  Agents: Optimist vs Skeptic")
    print(f"  Max turns: {args.max_turns}")
    print(f"{'='*60}\n")

    # Subscribe to see turns in real time
    def print_turn(turn):
        prefix = "🎙️" if turn.is_moderator else "💬"
        print(f"\n{prefix} [{turn.speaker}] ({turn.phase})")
        print(f"   {turn.text[:200]}{'...' if len(turn.text) > 200 else ''}")

    backend.create_session(session_id, {
        "topic": args.topic,
        "phase": "OPENING",
        "participants": ["Optimist", "Skeptic"],
    })
    backend.subscribe_turns(session_id, print_turn)

    session = FloorSession(backend=backend, config=config)
    session.add_agent(optimist)
    session.add_agent(skeptic)
    session.set_moderator(moderator)

    result = session.run(session_id, topic=args.topic, timeout_seconds=args.timeout)

    # Print results
    print(f"\n{'='*60}")
    print(f"  SESSION COMPLETE")
    print(f"{'='*60}")
    print(f"  Total turns: {result.total_turns}")
    print(f"  Duration: {result.duration_seconds:.1f}s")

    if result.session_metrics:
        gini = result.session_metrics.get("participation", {}).get("gini", "N/A")
        turns = result.session_metrics.get("turns", {}).get("per_agent", {})
        interventions = result.session_metrics.get("interventions", {}).get("total", 0)
        print(f"  Gini coefficient: {gini}")
        print(f"  Turns per agent: {json.dumps(turns)}")
        print(f"  Interventions: {interventions}")

    for name, metrics in result.agent_metrics.items():
        floor = metrics.get("floor", {})
        print(f"\n  {name}:")
        print(f"    Floor claims: {floor.get('claims_attempted', 0)} attempted, "
              f"{floor.get('claims_won', 0)} won")
        print(f"    Turns posted: {metrics.get('participation', {}).get('turns_posted', 0)}")

    # Capability output: show what each agent's logger observed
    print(f"\n  CAPABILITY: TurnLogger")
    for name, logger in [("Optimist", optimist_logger), ("Skeptic", skeptic_logger)]:
        summary = logger.summary()
        print(f"    {name} observed {summary['total_turns_observed']} turns, "
              f"{summary['total_words']} total words")

    print(f"\n{'='*60}\n")


if __name__ == "__main__":
    main()
