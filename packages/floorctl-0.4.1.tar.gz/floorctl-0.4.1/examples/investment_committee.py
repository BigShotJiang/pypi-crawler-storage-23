#!/usr/bin/env python3
"""
investment_committee.py — Multi-agent investment committee using floorctl.

Simulates a real investment committee where analysts with different mandates
evaluate a deal. Each agent has strict style contracts enforcing their role.

Agents:
  - CreditAnalyst: Focuses on debt coverage, default risk, covenants
  - EquityAnalyst: Focuses on valuation multiples, growth, upside potential
  - RiskOfficer: Focuses on tail risk, correlation, portfolio concentration
  - ComplianceOfficer: Focuses on regulatory, KYC/AML, mandate violations

Demonstrates:
  - Domain-specific style contracts (each analyst MUST cite their domain metrics)
  - Phase transitions: INITIAL_ASSESSMENT → RISK_DEBATE → VOTE → CLOSING
  - Escalation detection when analysts clash on risk rating
  - Dominance prevention (no single analyst dominates the discussion)
  - Gini coefficient measuring participation balance
  - Self-validation ensuring each analyst stays in their lane
  - Capabilities: RiskRegisterCapability that auto-builds a risk register from discussion

Usage:
    python examples/investment_committee.py
    python examples/investment_committee.py --deal "Series B: $50M AI healthcare startup, 8x revenue multiple, 18-month runway"
    python examples/investment_committee.py --deal "LBO: $2B industrial manufacturer, 5.5x EBITDA, 65% leverage"
"""

import argparse
import json
import logging
import os
import sys
import time

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from floorctl import (
    FloorAgent,
    FloorSession,
    ModeratorObserver,
    AgentProfile,
    AgentCapability,
    StyleContract,
    ArenaConfig,
    PhaseConfig,
    PhaseSequence,
    FloorConfig,
    ModeratorConfig,
    InMemoryBackend,
    TurnRecord,
    SpeakerPrefixValidator,
    DuplicateValidator,
    LengthValidator,
    BannedPhraseValidator,
    StyleContractValidator,
    PhaseValidator,
)


# ── Capabilities ────────────────────────────────────────────────────

class RiskRegisterCapability(AgentCapability):
    """Automatically builds a risk register from committee discussion.

    Demonstrates:
    - on_turn_received: extracts risk mentions and who raised them
    - enrich_context: injects the running risk register so agents can reference it
    - post_process: appends a risk count footer to VOTE-phase responses
    """

    name = "risk_register"

    RISK_KEYWORDS = [
        "default", "covenant", "leverage", "downgrade", "refinancing",
        "concentration", "correlation", "tail risk", "drawdown", "liquidity",
        "regulatory", "compliance", "mandate", "breach", "violation",
        "valuation", "overvalued", "bubble", "margin", "multiple compression",
    ]

    def __init__(self):
        self.risks: list[dict] = []

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        if turn.is_moderator:
            return
        text_lower = turn.text.lower()
        for keyword in self.RISK_KEYWORDS:
            if keyword in text_lower:
                self.risks.append({
                    "risk": keyword,
                    "raised_by": turn.speaker,
                    "phase": turn.phase,
                })

    def enrich_context(self, context: dict) -> dict:
        if self.risks:
            unique_risks = {r["risk"] for r in self.risks}
            context["risk_register:identified_risks"] = ", ".join(sorted(unique_risks))
            context["risk_register:count"] = len(unique_risks)
        return context

    def post_process(self, response: str, context: dict) -> str:
        """In VOTE phase, remind the agent how many risks are on the register."""
        if context.get("phase") == "VOTE" and self.risks:
            unique_count = len({r["risk"] for r in self.risks})
            # Don't modify if already mentions the count
            if f"{unique_count} risk" not in response.lower():
                pass  # Let the LLM's context enrichment handle it
        return response

    def get_register(self) -> list[dict]:
        """Return the full risk register."""
        return list(self.risks)


# ── LLM Integration ─────────────────────────────────────────────────

def create_generator():
    from openai import OpenAI
    client = OpenAI()

    def generate(agent_name: str, context: dict) -> str:
        retry_info = ""
        if context.get("retry_failures"):
            retry_info = (
                f"\n\nYour previous response was REJECTED by compliance validation. "
                f"You MUST fix these issues:\n"
                + "\n".join(f"- {f}" for f in context["retry_failures"])
                + "\n\nDo NOT repeat the same mistake. Ensure you include the required "
                "domain-specific metrics and terminology."
            )

        prompt = f"""You are {agent_name} on an investment committee evaluating a deal.

YOUR ROLE: {context.get('personality', '')}

DEAL UNDER REVIEW: {context['topic']}

CURRENT PHASE: {context['phase']}
{f"Phase guidance: {context.get('phase_constraints', '')}" if context.get('phase_constraints') else ""}

{f"STYLE REQUIREMENTS (MUST follow): {context.get('style_contract', '')}" if context.get('style_contract') else ""}

COMMITTEE DISCUSSION SO FAR:
{context.get('recent_turns', '(No discussion yet — you are among the first to speak.)')}

RESPONSE RULES:
1. Start with "{agent_name}:" prefix (MANDATORY)
2. Word count: {context.get('phase_min_words', 25)}-{context.get('phase_max_words', 120)} words
3. Stay in your lane — only analyze from YOUR perspective
4. Reference specific numbers, ratios, or regulatory frameworks
5. If you disagree with another analyst, cite the metric that supports your position
6. No generic statements like "we should be careful" — be SPECIFIC
{retry_info}

{agent_name}:"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=300,
            temperature=0.75,
        )
        text = response.choices[0].message.content.strip()
        # Ensure prefix
        if not text.startswith(f"{agent_name}:"):
            text = f"{agent_name}: {text}"
        return text

    return generate


def create_moderator():
    from openai import OpenAI
    client = OpenAI()

    def moderate(prompt_type: str, context: dict) -> str:
        deal = context.get("topic", "")
        agents = context.get("agents", [])

        prompts = {
            "intro": (
                f"You are the Chief Investment Officer chairing the investment committee. "
                f"The committee ({', '.join(agents)}) is evaluating: '{deal}'. "
                f"Give a 2-3 sentence opening. State the deal, the ask, and what you need from the committee."
            ),
            "invite_opening": (
                f"You are the CIO. Ask {context.get('agent_name', '')} specifically for their "
                f"initial assessment of '{deal}' from their domain perspective. 1 sentence, be specific "
                f"about what you want them to evaluate."
            ),
            "phase_transition": (
                f"You are the CIO transitioning the committee from {context.get('previous_phase', '')} "
                f"to {context.get('phase', '')}.\n"
                f"Discussion so far:\n{context.get('transcript_summary', '')}\n\n"
                f"Summarize key findings and set the agenda for the next phase. 2-3 sentences. "
                f"If moving to VOTE, ask each analyst for their GO/NO-GO recommendation."
            ),
            "intervention": (
                f"You are the CIO. Intervention needed: {context.get('intervention_type', '')}. "
                f"{'Redirect to ' + context['target_agent'] if context.get('target_agent') else 'Manage the discussion'}. "
                f"Details: {context.get('details', {})}. "
                f"Be firm but professional. 1-2 sentences."
            ),
            "closing": (
                f"You are the CIO closing the committee review of '{deal}'.\n"
                f"Discussion summary:\n{context.get('transcript_summary', '')}\n\n"
                f"Summarize: (1) the consensus view, (2) key risks flagged, (3) your recommendation. "
                f"3-4 sentences."
            ),
        }

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompts.get(prompt_type, f"Brief CIO comment on {deal}.")}],
            max_tokens=200,
            temperature=0.7,
        )
        return response.choices[0].message.content.strip()

    return moderate


# ── Agent Definitions ────────────────────────────────────────────────

AGENTS = [
    {
        "name": "CreditAnalyst",
        "personality": (
            "Senior credit analyst. You evaluate debt serviceability, default probability, "
            "and covenant structures. You think in terms of DSCR, interest coverage ratios, "
            "leverage multiples, and credit ratings. You are conservative and skeptical of "
            "growth projections. You flag covenant-lite structures as red flags."
        ),
        "react_to": ["growth", "upside", "opportunity", "valuation", "revenue", "expand", "scale"],
        "temperament": "reactive",
        "base_cooldown": 5.0,
        "urgency_boost": ["default", "covenant", "leverage", "debt", "downgrade", "maturity"],
        "contract": StyleContract(
            description=(
                "MUST include one credit metric (DSCR, ICR, leverage ratio, debt/EBITDA, "
                "LTV, default probability, recovery rate, credit spread) AND one risk assessment "
                "(covenant, maturity, refinancing, subordination, collateral)."
            ),
            required_patterns=[
                "one credit metric (DSCR, ICR, leverage, debt/EBITDA, LTV, default, recovery, spread, coverage, ratio)",
                "one risk term (covenant, maturity, refinancing, subordination, collateral, amortization, waterfall, tranche)",
            ],
            forbidden_patterns=[r"to the moon", r"guaranteed returns", r"risk-free"],
            max_sentences=6,
        ),
    },
    {
        "name": "EquityAnalyst",
        "personality": (
            "Equity research analyst. You evaluate growth potential, valuation multiples, "
            "and market positioning. You think in terms of EV/Revenue, P/E, TAM/SAM/SOM, "
            "and comparable transactions. You are growth-oriented but disciplined about "
            "paying the right price. You benchmark against public comps."
        ),
        "react_to": ["risk", "default", "covenant", "downside", "loss", "debt", "conservative"],
        "temperament": "passionate",
        "base_cooldown": 6.0,
        "urgency_boost": ["valuation", "multiple", "growth", "TAM", "market", "revenue"],
        "contract": StyleContract(
            description=(
                "MUST include one valuation metric (EV/Revenue, P/E, EV/EBITDA, DCF, IRR, "
                "MOIC, multiple, comparable) AND one growth indicator (TAM, CAGR, market share, "
                "runway, ARR, retention, expansion)."
            ),
            required_patterns=[
                "one valuation metric (EV/Revenue, P/E, EV/EBITDA, DCF, IRR, MOIC, multiple, comparable, valuation)",
                "one growth indicator (TAM, CAGR, market share, runway, ARR, retention, expansion, revenue growth, addressable)",
            ],
            forbidden_patterns=[r"risk-free", r"guaranteed"],
            max_sentences=6,
        ),
    },
    {
        "name": "RiskOfficer",
        "personality": (
            "Chief risk officer. You evaluate tail risks, portfolio concentration, "
            "stress scenarios, and correlation effects. You think in terms of VaR, "
            "expected shortfall, stress tests, and scenario analysis. You are the voice "
            "of caution and always ask 'what if we're wrong?' You quantify downside scenarios."
        ),
        "react_to": ["confident", "sure", "upside", "opportunity", "growth", "attractive", "strong"],
        "temperament": "provocative",
        "base_cooldown": 7.0,
        "urgency_boost": ["concentration", "correlation", "tail", "stress", "scenario", "drawdown"],
        "contract": StyleContract(
            description=(
                "MUST include one risk measure (VaR, CVaR, stress test, drawdown, correlation, "
                "concentration, beta, volatility, Sharpe) AND one scenario or stress condition "
                "(recession, rate hike, market crash, sector rotation, liquidity crisis)."
            ),
            required_patterns=[
                "one risk measure (VaR, CVaR, stress, drawdown, correlation, concentration, beta, volatility, Sharpe, exposure)",
                "one scenario (recession, rate, crash, rotation, liquidity, downturn, inflation, default cycle, contagion, black swan)",
            ],
            forbidden_patterns=[r"risk-free", r"no downside", r"guaranteed"],
            max_sentences=6,
        ),
    },
    {
        "name": "ComplianceOfficer",
        "personality": (
            "Head of compliance. You evaluate regulatory requirements, mandate constraints, "
            "KYC/AML obligations, and fiduciary duties. You think in terms of regulatory "
            "frameworks (SEC, Basel, MiFID, Dodd-Frank), concentration limits, and disclosure "
            "requirements. You are non-negotiable on compliance and flag mandate violations."
        ),
        "react_to": ["proceed", "approve", "go ahead", "invest", "allocate", "commit"],
        "temperament": "deliberate",
        "base_cooldown": 8.0,
        "urgency_boost": ["regulatory", "mandate", "compliance", "disclosure", "fiduciary", "limit"],
        "contract": StyleContract(
            description=(
                "MUST reference one regulatory framework or rule (SEC, Basel, MiFID, Dodd-Frank, "
                "AIFMD, UCITS, concentration limit, mandate constraint, fiduciary duty) AND one "
                "compliance action (disclosure, filing, reporting, approval, documentation, KYC, AML)."
            ),
            required_patterns=[
                "one regulatory reference (SEC, Basel, MiFID, Dodd-Frank, AIFMD, UCITS, concentration, mandate, fiduciary, regulatory, regulation)",
                "one compliance action (disclosure, filing, reporting, approval, documentation, KYC, AML, due diligence, audit, sign-off)",
            ],
            forbidden_patterns=[r"skip compliance", r"bypass", r"ignore regulation"],
            max_sentences=5,
        ),
    },
]


# ── Main ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Investment committee simulation")
    parser.add_argument(
        "--deal",
        default="Series C: $120M fintech lending platform, 12x ARR multiple, $10M ARR growing 150% YoY, 3 years to profitability",
    )
    parser.add_argument("--max-turns", type=int, default=16)
    parser.add_argument("--timeout", type=int, default=240)
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY required. Export it or add to .env file.")
        sys.exit(1)

    backend = InMemoryBackend()
    generate_fn = create_generator()
    moderator_fn = create_moderator()

    # Phases model a real IC process
    phases = PhaseSequence(phases=[
        PhaseConfig(
            name="INITIAL_ASSESSMENT",
            is_opening=True,
            max_turns=8,
            max_words=100,
            min_words=20,
            max_sentences=4,
            allow_critiques=False,
            constraints="State your initial view from YOUR domain only. One key metric and one concern. Max 4 sentences.",
        ),
        PhaseConfig(
            name="RISK_DEBATE",
            min_turns=6,
            max_turns=12,
            max_words=130,
            min_words=25,
            constraints="Challenge others' assessments. Cite specific metrics that support or contradict their view. Be direct.",
        ),
        PhaseConfig(
            name="VOTE",
            min_turns=4,
            max_turns=8,
            max_words=80,
            min_words=15,
            constraints="State GO or NO-GO with your single strongest reason. Max 3 sentences.",
            max_sentences=3,
        ),
        PhaseConfig(name="CLOSING", is_terminal=True),
    ])

    config = ArenaConfig(
        phases=phases,
        floor=FloorConfig(
            timeout_seconds=30,
            min_turns_between_speaking=1,
            max_turns_per_phase_per_agent=3,
        ),
        moderator=ModeratorConfig(
            silence_threshold=3,
            dominance_threshold=3,
            dominance_window=6,
            escalation_markers=[
                "wrong", "absurd", "ridiculous", "reckless", "irresponsible",
                "completely miss", "ignoring the data", "you're not seeing",
                "dangerous", "unacceptable risk",
            ],
            escalation_threshold=2,
        ),
        banned_phrases=["As an AI", "guaranteed returns", "risk-free investment", "to the moon"],
        max_self_retries=2,
        max_total_turns=args.max_turns,
    )

    # Shared capability — all analysts contribute to one risk register
    risk_register = RiskRegisterCapability()

    # Build agents with domain-specific contracts
    agents = []
    for agent_def in AGENTS:
        validators = [
            SpeakerPrefixValidator(),
            DuplicateValidator(similarity_threshold=0.60),
            LengthValidator(),
            BannedPhraseValidator(banned_phrases=config.banned_phrases),
            StyleContractValidator(),
            PhaseValidator(),
        ]

        agent = FloorAgent(
            name=agent_def["name"],
            profile=AgentProfile(
                name=agent_def["name"],
                personality=agent_def["personality"],
                react_to=agent_def["react_to"],
                temperament=agent_def["temperament"],
                base_cooldown=agent_def["base_cooldown"],
                urgency_boost_keywords=agent_def["urgency_boost"],
                style_contract=agent_def["contract"],
            ),
            generate_fn=generate_fn,
            backend=backend,
            validators=validators,
            config=config,
            capabilities=[risk_register],
        )
        agents.append(agent)

    session_id = f"ic-{int(time.time())}"
    agent_names = [a.name for a in agents]

    moderator = ModeratorObserver(
        agent_names=agent_names,
        moderator_fn=moderator_fn,
        backend=backend,
        session_id=session_id,
        phase_sequence=phases,
        config=config.moderator,
    )

    # Print header
    print(f"\n{'='*70}")
    print(f"  INVESTMENT COMMITTEE")
    print(f"  Deal: {args.deal}")
    print(f"  Committee: {', '.join(agent_names)}")
    print(f"  Phases: Assessment → Risk Debate → Vote → Close")
    print(f"{'='*70}\n")

    # Setup session
    backend.create_session(session_id, {
        "topic": args.deal,
        "phase": "INITIAL_ASSESSMENT",
        "participants": agent_names,
    })

    # Real-time turn display
    def print_turn(turn):
        if turn.is_moderator:
            print(f"\n  {'─'*60}")
            print(f"  🏛️  CIO / Moderator  [{turn.phase}]")
            print(f"  {turn.text}")
            print(f"  {'─'*60}")
        else:
            # Color-code by role
            icons = {
                "CreditAnalyst": "📊",
                "EquityAnalyst": "📈",
                "RiskOfficer": "⚠️",
                "ComplianceOfficer": "📋",
            }
            icon = icons.get(turn.speaker, "💬")
            print(f"\n  {icon} {turn.speaker}  [{turn.phase}]")
            print(f"     {turn.text}")

    backend.subscribe_turns(session_id, print_turn)

    # Run
    session = FloorSession(backend=backend, config=config)
    for a in agents:
        session.add_agent(a)
    session.set_moderator(moderator)

    result = session.run(session_id, topic=args.deal, timeout_seconds=args.timeout)

    # Print results
    print(f"\n{'='*70}")
    print(f"  INVESTMENT COMMITTEE — SESSION SUMMARY")
    print(f"{'='*70}")
    print(f"  Deal: {args.deal}")
    print(f"  Total turns: {result.total_turns}")
    print(f"  Duration: {result.duration_seconds:.1f}s")

    if result.session_metrics:
        participation = result.session_metrics.get("participation", {})
        gini = participation.get("gini", "N/A")
        turns = result.session_metrics.get("turns", {}).get("per_agent", {})
        interventions = result.session_metrics.get("interventions", {})

        print(f"\n  PARTICIPATION:")
        print(f"    Gini coefficient: {gini} (0=balanced, 1=dominated)")
        for agent, count in sorted(turns.items(), key=lambda x: -x[1]):
            print(f"    {agent}: {count} turns")

        if interventions.get("total", 0) > 0:
            print(f"\n  INTERVENTIONS: {interventions['total']}")
            for detail in interventions.get("details", []):
                print(f"    - {detail['type']}: {detail.get('target_agent', 'N/A')} ({detail['phase']})")

    print(f"\n  ANALYST PERFORMANCE:")
    for name, metrics in result.agent_metrics.items():
        floor = metrics.get("floor", {})
        val = metrics.get("validation", {})
        posted = metrics.get("participation", {}).get("turns_posted", 0)
        pass_rate = val.get("pass_rate", 1.0)
        failures = val.get("failure_types", {})

        print(f"\n    {name}:")
        print(f"      Turns posted: {posted}")
        print(f"      Floor: {floor.get('claims_won', 0)}/{floor.get('claims_attempted', 0)} claims won")
        print(f"      Validation pass rate: {pass_rate:.0%}")
        if failures:
            print(f"      Validation failures: {json.dumps(failures)}")

    # Capability output: auto-generated risk register
    register = risk_register.get_register()
    if register:
        unique_risks = {}
        for r in register:
            if r["risk"] not in unique_risks:
                unique_risks[r["risk"]] = r["raised_by"]
        print(f"\n  CAPABILITY: RiskRegister ({len(unique_risks)} unique risks)")
        for risk, raised_by in sorted(unique_risks.items()):
            print(f"    - {risk} (raised by {raised_by})")

    print(f"\n{'='*70}\n")


if __name__ == "__main__":
    main()
