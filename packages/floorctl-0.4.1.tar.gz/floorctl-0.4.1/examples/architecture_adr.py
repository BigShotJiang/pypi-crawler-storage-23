#!/usr/bin/env python3
"""
architecture_adr.py — Architecture Decision Record using floorctl's v0.2 primitives.

This demo ties ALL THREE new primitives together:
- Artifacts: Agents collaboratively build an ADR document with versioned sections
- Consensus: Formal quorum-based voting on the final decision
- Conviction: Agent positions drift as evidence is presented during debate

Scenario: A team must decide on the database technology for a new platform.
Each agent has a domain perspective and initial conviction that evolves.

Agents:
  - Architect: System design perspective, proposes PostgreSQL
  - SecurityLead: Data protection, encryption, audit trail concerns
  - DevLead: Developer experience, ORM support, migration tooling
  - SRE: Operational excellence, scaling, monitoring, backup/recovery

Flow:
  1. PROPOSAL: Architect creates ADR artifact, agents state initial positions
  2. DEBATE: Agents present evidence, convictions drift, artifact gets updated
  3. VOTE: Formal consensus vote with conviction-weighted reasoning
  4. CLOSING: Final ADR status, conviction summary, decision record

This is the demo that no other framework can run — structured artifact exchange
+ formal consensus + tracked conviction drift, all coordinated through
contention-based floor control.

Usage:
    python examples/architecture_adr.py
    python examples/architecture_adr.py --topic "Choose message queue: Kafka vs RabbitMQ vs SQS"
    python examples/architecture_adr.py -v  # verbose logging
"""

import argparse
import json
import logging
import os
import sys
import time

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from floorctl import (
    FloorAgent,
    FloorSession,
    ModeratorObserver,
    AgentProfile,
    AgentCapability,
    StyleContract,
    ArenaConfig,
    PhaseConfig,
    PhaseSequence,
    FloorConfig,
    ModeratorConfig,
    InMemoryBackend,
    TurnRecord,
    SpeakerPrefixValidator,
    DuplicateValidator,
    LengthValidator,
    BannedPhraseValidator,
    PhaseValidator,
)
from floorctl.artifacts import ArtifactStore, ArtifactType, ArtifactStatus
from floorctl.consensus import (
    ConsensusProtocol,
    ConsensusConfig,
    QuorumRule,
    VoteChoice,
    ProposalStatus,
)
from floorctl.conviction import (
    ConvictionTracker,
    EvidenceType,
)


# ── Capabilities ────────────────────────────────────────────────────

class EvidenceExtractorCapability(AgentCapability):
    """Extracts evidence from turns and updates conviction tracker + ADR artifact.

    This is a great example of a capability that bridges floorctl's core pipeline
    with external primitives (conviction tracking, artifact store). Instead of
    hooking into the turn subscriber, the capability plugs directly into the
    agent's on_turn_received hook.

    Demonstrates:
    - on_turn_received: side-effect-based evidence extraction and conviction updates
    - enrich_context: injects the agent's current conviction into the LLM context
    """

    name = "evidence_extractor"

    def __init__(self, shared: "SharedDecisionState"):
        self.shared = shared
        self.evidence_count = 0

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        """Extract evidence from each turn and update convictions."""
        if turn.is_moderator or turn.speaker == agent_name:
            return
        # Delegate to the existing extraction logic
        extract_evidence_from_turn(
            self.shared, turn.speaker, turn.text, self.shared.agent_names
        )
        extract_adr_update_from_turn(
            self.shared, turn.speaker, turn.text, turn.phase
        )
        self.evidence_count += 1

    def enrich_context(self, context: dict) -> dict:
        """Inject this agent's conviction score into the context."""
        # The agent_name isn't directly available here, but we can get it
        # from context (set by FloorAgent._build_context)
        agent_name = context.get("agent_name", "")
        if agent_name:
            conv = self.shared.conviction.get_conviction(agent_name, "proposed-decision")
            if conv is not None:
                context["evidence:conviction_score"] = f"{conv:.2f}"
                context["evidence:total_evidence"] = str(self.evidence_count)
        return context


# ── State shared across agents ──────────────────────────────────────

class SharedDecisionState:
    """
    Shared state that all agents and the moderator can access.
    Holds the artifact store, consensus protocol, and conviction tracker.
    """
    def __init__(self, agent_names: list[str]):
        self.artifact_store = ArtifactStore()
        self.consensus = ConsensusProtocol(ConsensusConfig(
            quorum_rule=QuorumRule.SUPERMAJORITY,
            veto_agents=["SecurityLead"],  # Security can veto
            require_reason=True,
        ))
        self.conviction = ConvictionTracker(
            convergence_threshold=0.15,
            entrenchment_threshold=0.03,
        )
        self.agent_names = agent_names
        self.proposal_id: str | None = None
        self.adr_id = "adr-001"

    def to_context(self) -> dict:
        """Build context dict for LLM prompts."""
        artifact = self.artifact_store.get(self.adr_id)
        return {
            "adr": artifact.to_context() if artifact else None,
            "open_proposals": self.consensus.to_context(),
            "convictions": self.conviction.to_context("proposed-decision"),
        }


# ── LLM Integration ────────────────────────────────────────────────

def create_generator(shared: SharedDecisionState):
    from openai import OpenAI
    client = OpenAI()

    def generate(agent_name: str, context: dict) -> str:
        decision_ctx = shared.to_context()

        retry_info = ""
        if context.get("retry_failures"):
            retry_info = (
                f"\n\nYour previous response was REJECTED. Fix these:\n"
                + "\n".join(f"- {f}" for f in context["retry_failures"])
            )

        conviction_info = ""
        conv = shared.conviction.get_conviction(agent_name, "proposed-decision")
        if conv is not None:
            conviction_info = (
                f"\n\nYour current conviction on the proposed decision: {conv:.2f}/1.0 "
                f"(0=strongly opposed, 1=strongly in favor)"
            )

        adr_info = ""
        if decision_ctx["adr"]:
            sections = decision_ctx["adr"]["sections"]
            adr_info = "\n\nCURRENT ADR DOCUMENT:\n"
            for k, v in sections.items():
                if v:
                    adr_info += f"  {k}: {v}\n"

        prompt = f"""You are {agent_name} in an architecture decision review.

YOUR ROLE: {context.get('personality', '')}

DECISION TOPIC: {context['topic']}

CURRENT PHASE: {context['phase']}
{f"Phase guidance: {context.get('phase_constraints', '')}" if context.get('phase_constraints') else ""}
{adr_info}
{conviction_info}

RECENT DISCUSSION:
{context.get('recent_turns', '(No discussion yet.)')}

RESPONSE RULES:
1. Start with "{agent_name}:" prefix (MANDATORY)
2. Word count: {context.get('phase_min_words', 20)}-{context.get('phase_max_words', 120)} words
3. Be specific — cite technologies, metrics, or trade-offs
4. If the phase is VOTE: state APPROVE or REJECT with your reason
5. Reference the ADR document if it exists
{retry_info}

{agent_name}:"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=250,
            temperature=0.7,
        )
        text = response.choices[0].message.content.strip()
        if not text.startswith(f"{agent_name}:"):
            text = f"{agent_name}: {text}"
        return text

    return generate


def create_moderator(shared: SharedDecisionState):
    from openai import OpenAI
    client = OpenAI()

    def moderate(prompt_type: str, context: dict) -> str:
        agents = context.get("agents", [])
        topic = context.get("topic", "")

        prompts = {
            "intro": (
                f"You are the Engineering Director moderating an Architecture Decision Review. "
                f"The team ({', '.join(agents)}) is deciding: '{topic}'. "
                f"SecurityLead has veto power. We need supermajority to proceed. "
                f"Give a 2-3 sentence opening setting the context and what you need from each role."
            ),
            "invite_opening": (
                f"You are the Engineering Director. Ask {context.get('agent_name', '')} for their "
                f"initial position on '{topic}' from their domain perspective. "
                f"1-2 sentences, be specific about what assessment you want."
            ),
            "phase_transition": (
                f"You are the Engineering Director transitioning from {context.get('previous_phase', '')} "
                f"to {context.get('phase', '')}.\n"
                f"Discussion so far:\n{context.get('transcript_summary', '')}\n\n"
                f"Summarize key points and set direction for the next phase. 2-3 sentences."
            ),
            "intervention": (
                f"You are the Engineering Director. Intervention: {context.get('intervention_type', '')}. "
                f"{'Direct attention to ' + context['target_agent'] if context.get('target_agent') else 'Refocus the discussion'}. "
                f"1-2 sentences, be constructive."
            ),
            "closing": (
                f"You are the Engineering Director closing the architecture review on '{topic}'.\n"
                f"Summary:\n{context.get('transcript_summary', '')}\n\n"
                f"State the final decision, key trade-offs accepted, and action items. 3-4 sentences."
            ),
        }

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompts.get(prompt_type, f"Brief comment on {topic}.")}],
            max_tokens=200,
            temperature=0.7,
        )
        return response.choices[0].message.content.strip()

    return moderate


# ── Evidence Extraction ─────────────────────────────────────────────

def extract_evidence_from_turn(
    shared: SharedDecisionState,
    speaker: str,
    text: str,
    all_agents: list[str],
) -> None:
    """
    Analyze a turn and update convictions based on evidence presented.
    This is a simplified heuristic — a production system would use an LLM.
    """
    text_lower = text.lower()

    # Positive signals strengthen conviction
    positive_signals = [
        "strong", "proven", "reliable", "mature", "battle-tested",
        "excellent", "robust", "comprehensive", "approve", "support",
        "agree", "solid", "well-suited", "advantage", "benefit",
        "recommend", "favor", "good", "great", "effective", "efficient",
        "stable", "performan", "fast", "ecosystem", "community",
        "endorse", "compatible", "flexible", "powerful", "transact",
        "acid", "consistency", "postgres", "postgresql", "scaling",
    ]
    # Negative signals weaken conviction
    negative_signals = [
        "concern", "risk", "weakness", "problem", "issue", "lack",
        "missing", "complex", "overhead", "reject", "veto", "oppose",
        "worry", "costly", "difficult", "limitation", "drawback",
        "challenge", "downside", "slow", "expensive", "latency",
        "vulnerab", "breach", "threat", "careful", "however",
        "but", "although", "despite", "alternatively", "instead",
        "question", "uncertain", "doubt", "caveat", "trade-off",
    ]

    positive_count = sum(1 for s in positive_signals if s in text_lower)
    negative_count = sum(1 for s in negative_signals if s in text_lower)

    if positive_count == 0 and negative_count == 0:
        return

    # Determine evidence type and strength
    if positive_count > negative_count:
        evidence_type = EvidenceType.SUPPORTING
        strength = min(0.8, positive_count * 0.2)
    else:
        evidence_type = EvidenceType.COUNTER_ARGUMENT
        strength = min(0.8, negative_count * 0.2)

    # Apply to all OTHER agents (the speaker's evidence affects others)
    for agent in all_agents:
        if agent != speaker:
            try:
                shared.conviction.record_evidence(
                    agent, "proposed-decision",
                    evidence_type=evidence_type,
                    source=speaker,
                    strength=strength,
                    description=text[:100],
                )
            except ValueError:
                pass  # Agent not registered yet


def extract_adr_update_from_turn(
    shared: SharedDecisionState,
    speaker: str,
    text: str,
    phase: str,
) -> None:
    """
    Extract and apply ADR updates from agent turns.
    Simple heuristic — looks for domain-relevant content to add to ADR sections.
    """
    text_lower = text.lower()
    artifact = shared.artifact_store.get(shared.adr_id)
    if not artifact:
        return

    updates: dict[str, str] = {}

    # Map speaker domains to ADR sections
    if speaker == "SecurityLead":
        current_risks = artifact.sections.get("risks", "")
        updates["risks"] = f"{current_risks}\n- [{speaker}] {text[:150]}" if current_risks else f"- [{speaker}] {text[:150]}"

    elif speaker == "SRE":
        current_cons = artifact.sections.get("consequences", "")
        updates["consequences"] = f"{current_cons}\n- [{speaker}] {text[:150]}" if current_cons else f"- [{speaker}] {text[:150]}"

    elif speaker == "DevLead" and any(w in text_lower for w in ["orm", "migration", "developer", "tooling", "ecosystem", "type", "pris", "library"]):
        current_alts = artifact.sections.get("alternatives_considered", [])
        if isinstance(current_alts, list):
            current_alts.append(f"[{speaker}] {text[:100]}")
            updates["alternatives_considered"] = current_alts

    if updates:
        try:
            shared.artifact_store.update(
                shared.adr_id, agent=speaker,
                sections=updates,
                message=f"Evidence from {speaker} during {phase}",
            )
        except (ValueError, Exception):
            pass


# ── Agent Definitions ───────────────────────────────────────────────

AGENTS = [
    {
        "name": "Architect",
        "personality": (
            "Senior system architect. You proposed PostgreSQL and own the ADR. "
            "You think about system design, data modeling, query patterns, and "
            "long-term maintainability. You're open to changing your mind if the "
            "evidence warrants it, but you need strong technical arguments."
        ),
        "react_to": ["alternative", "NoSQL", "MongoDB", "DynamoDB", "scale", "performance"],
        "temperament": "deliberate",
        "base_cooldown": 5.0,
        "urgency_boost": ["schema", "query", "model", "migration", "consistency"],
        "initial_conviction": 0.85,
    },
    {
        "name": "SecurityLead",
        "personality": (
            "Head of security. You evaluate encryption at rest, audit logging, "
            "access control, and compliance (SOC2, GDPR). You have VETO power. "
            "You need to be convinced the solution meets security requirements "
            "before you approve. You are cautious but fair."
        ),
        "react_to": ["data", "store", "access", "user", "PII", "encrypt", "compliance"],
        "temperament": "patient",
        "base_cooldown": 8.0,
        "urgency_boost": ["vulnerability", "breach", "audit", "SOC2", "GDPR", "encryption"],
        "initial_conviction": 0.55,
    },
    {
        "name": "DevLead",
        "personality": (
            "Engineering lead. You care about developer productivity, ORM support, "
            "testing ease, local development experience, and the hiring market. "
            "You've worked with both PostgreSQL and MongoDB extensively. You're "
            "pragmatic and favor what ships faster with fewer bugs."
        ),
        "react_to": ["development", "team", "hire", "skill", "tooling", "testing", "deploy"],
        "temperament": "passionate",
        "base_cooldown": 5.0,
        "urgency_boost": ["ORM", "TypeORM", "Prisma", "developer", "productivity"],
        "initial_conviction": 0.70,
    },
    {
        "name": "SRE",
        "personality": (
            "Site reliability engineer. You evaluate operational burden, scaling "
            "characteristics, monitoring, backup/recovery, and incident response. "
            "You think about connection pooling, read replicas, failover, and "
            "the 3am pager call. You need to operate whatever gets chosen."
        ),
        "react_to": ["deploy", "production", "scale", "reliability", "incident", "backup"],
        "temperament": "provocative",
        "base_cooldown": 6.0,
        "urgency_boost": ["uptime", "failover", "replica", "connection", "monitoring", "backup"],
        "initial_conviction": 0.60,
    },
]


# ── Main ────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Architecture ADR decision demo")
    parser.add_argument(
        "--topic",
        default="ADR: Choose primary database — PostgreSQL vs alternatives (MongoDB, DynamoDB)",
    )
    parser.add_argument("--max-turns", type=int, default=20)
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY required. Export it or add to .env file.")
        sys.exit(1)

    agent_names = [a["name"] for a in AGENTS]

    # ── Initialize shared primitives ────────────────────────────────
    shared = SharedDecisionState(agent_names)

    # Create the ADR artifact
    shared.artifact_store.create(
        shared.adr_id,
        ArtifactType.DECISION_RECORD,
        creator="Architect",
        initial_sections={
            "title": "Choose primary database for platform",
            "status": "proposed",
            "context": (
                "We are building a new platform that needs a primary data store. "
                "Requirements: ACID transactions, horizontal read scaling, "
                "SOC2 compliance, sub-10ms p99 reads, team familiarity."
            ),
            "decision": "Proposed: PostgreSQL 16 with Citus extension for horizontal scaling",
            "consequences": "",
            "alternatives_considered": ["MongoDB Atlas", "AWS DynamoDB", "CockroachDB"],
            "risks": "",
        },
        message="Initial ADR proposal by Architect",
    )

    # Register agent convictions
    for agent_def in AGENTS:
        shared.conviction.register(
            agent_def["name"], "proposed-decision",
            initial=agent_def["initial_conviction"],
        )

    # ── Build floorctl components ───────────────────────────────────
    backend = InMemoryBackend()
    generate_fn = create_generator(shared)
    moderator_fn = create_moderator(shared)

    phases = PhaseSequence(phases=[
        PhaseConfig(
            name="PROPOSAL",
            is_opening=True,
            max_turns=8,
            max_words=100,
            min_words=20,
            max_sentences=5,
            allow_critiques=False,
            constraints=(
                "State your initial position on the proposed PostgreSQL decision. "
                "What's your biggest concern or strongest endorsement from YOUR domain?"
            ),
        ),
        PhaseConfig(
            name="DEBATE",
            min_turns=8,
            max_turns=14,
            max_words=130,
            min_words=25,
            constraints=(
                "Challenge or support the proposal with specific evidence. "
                "Cite metrics, benchmarks, or experience. Be direct about trade-offs."
            ),
        ),
        PhaseConfig(
            name="VOTE",
            min_turns=4,
            max_turns=8,
            max_words=80,
            min_words=15,
            constraints=(
                "State APPROVE or REJECT with your single strongest reason. "
                "If you're SecurityLead, you may VETO if security requirements aren't met."
            ),
            max_sentences=3,
        ),
        PhaseConfig(name="CLOSING", is_terminal=True),
    ])

    config = ArenaConfig(
        phases=phases,
        floor=FloorConfig(
            timeout_seconds=30,
            min_turns_between_speaking=1,
            max_turns_per_phase_per_agent=3,
        ),
        moderator=ModeratorConfig(
            silence_threshold=3,
            dominance_threshold=3,
            dominance_window=6,
        ),
        banned_phrases=["As an AI", "Let's face it", "We must balance"],
        max_self_retries=2,
        max_total_turns=args.max_turns,
    )

    # Each agent gets an EvidenceExtractorCapability that feeds into the shared state
    evidence_caps: dict[str, EvidenceExtractorCapability] = {}

    agents = []
    for agent_def in AGENTS:
        evidence_cap = EvidenceExtractorCapability(shared)
        evidence_caps[agent_def["name"]] = evidence_cap
        agent = FloorAgent(
            name=agent_def["name"],
            profile=AgentProfile(
                name=agent_def["name"],
                personality=agent_def["personality"],
                react_to=agent_def["react_to"],
                temperament=agent_def["temperament"],
                base_cooldown=agent_def["base_cooldown"],
                urgency_boost_keywords=agent_def["urgency_boost"],
            ),
            generate_fn=generate_fn,
            backend=backend,
            validators=[
                SpeakerPrefixValidator(),
                DuplicateValidator(),
                LengthValidator(),
                BannedPhraseValidator(banned_phrases=config.banned_phrases),
                PhaseValidator(),
            ],
            config=config,
            capabilities=[evidence_cap],
        )
        agents.append(agent)

    session_id = f"adr-{int(time.time())}"

    moderator = ModeratorObserver(
        agent_names=agent_names,
        moderator_fn=moderator_fn,
        backend=backend,
        session_id=session_id,
        phase_sequence=phases,
        config=config.moderator,
    )

    # ── Print header ────────────────────────────────────────────────
    print(f"\n{'='*70}")
    print(f"  ARCHITECTURE DECISION RECORD — REVIEW SESSION")
    print(f"  Topic: {args.topic}")
    print(f"  Team: {', '.join(agent_names)}")
    print(f"  Veto Power: SecurityLead")
    print(f"  Quorum: Supermajority (2/3)")
    print(f"  Phases: Proposal → Debate → Vote → Close")
    print(f"{'='*70}")

    # Show initial convictions
    print(f"\n  📊 INITIAL CONVICTIONS (on PostgreSQL proposal):")
    for agent_def in AGENTS:
        conv = agent_def["initial_conviction"]
        bar = "█" * int(conv * 20) + "░" * (20 - int(conv * 20))
        print(f"    {agent_def['name']:15s} [{bar}] {conv:.2f}")

    print()

    # ── Setup session & subscribe ─────────────────────────────────
    backend.create_session(session_id, {
        "topic": args.topic,
        "phase": "PROPOSAL",
        "participants": agent_names,
    })

    # Subscribe to turns for live display
    # NOTE: Evidence extraction is now handled by EvidenceExtractorCapability
    # instead of being done here in the subscriber — capabilities are the
    # proper place for per-agent side effects.
    def on_turn(turn):
        if turn.is_moderator:
            print(f"\n  {'─'*60}")
            print(f"  🏛️  Engineering Director  [{turn.phase}]")
            print(f"  {turn.text}")
            print(f"  {'─'*60}")
        else:
            icons = {
                "Architect": "🏗️",
                "SecurityLead": "🔒",
                "DevLead": "👨‍💻",
                "SRE": "⚙️",
            }
            icon = icons.get(turn.speaker, "💬")

            # Show conviction next to name
            conv = shared.conviction.get_conviction(turn.speaker, "proposed-decision")
            conv_str = f"  [conviction: {conv:.2f}]" if conv is not None else ""

            print(f"\n  {icon} {turn.speaker}{conv_str}  [{turn.phase}]")
            print(f"     {turn.text}")

    backend.subscribe_turns(session_id, on_turn)

    # ── Run session ─────────────────────────────────────────────────
    session = FloorSession(backend=backend, config=config)
    for a in agents:
        session.add_agent(a)
    session.set_moderator(moderator)

    result = session.run(session_id, topic=args.topic, timeout_seconds=args.timeout)

    # ── Post-session: Formal Consensus Vote ─────────────────────────
    print(f"\n{'='*70}")
    print(f"  FORMAL CONSENSUS VOTE")
    print(f"{'='*70}")

    # Create the formal proposal linked to the ADR
    proposal_id = shared.consensus.propose(
        proposer="Architect",
        title="Accept PostgreSQL as primary database",
        description="ADR-001: Use PostgreSQL 16 with Citus for horizontal scaling",
        artifact_id=shared.adr_id,
    )

    # Each agent votes based on their final conviction
    for agent_def in AGENTS:
        name = agent_def["name"]
        conv = shared.conviction.get_conviction(name, "proposed-decision")
        if conv is None:
            conv = 0.5

        # Determine vote from conviction
        if name == "SecurityLead" and conv < 0.4:
            choice = VoteChoice.VETO
            reason = "Security requirements not adequately addressed"
        elif conv >= 0.6:
            choice = VoteChoice.APPROVE
            reason = f"Conviction {conv:.2f} — meets {name.replace('Lead', '').lower()} requirements"
        elif conv >= 0.4:
            choice = VoteChoice.ABSTAIN
            reason = f"Conviction {conv:.2f} — not fully convinced either way"
        else:
            choice = VoteChoice.REJECT
            reason = f"Conviction {conv:.2f} — significant concerns from {name.lower()} perspective"

        shared.consensus.vote(
            proposal_id, name, choice,
            reason=reason,
            conviction_score=conv,
        )
        icon = {"approve": "✅", "reject": "❌", "abstain": "⏸️", "veto": "🚫"}
        print(f"  {icon.get(choice.value, '?')} {name:15s} → {choice.value:8s}  (conviction: {conv:.2f}) — {reason}")

    # Resolve
    consensus_result = shared.consensus.resolve(proposal_id, eligible_voters=len(AGENTS))

    status_icon = {
        "passed": "✅ APPROVED",
        "rejected": "❌ REJECTED",
        "vetoed": "🚫 VETOED",
    }
    print(f"\n  RESULT: {status_icon.get(consensus_result.status.value, consensus_result.status.value)}")
    print(f"  Approval rate: {consensus_result.approval_rate:.0%}")
    print(f"  Quorum met: {'Yes' if consensus_result.quorum_met else 'No'}")
    if consensus_result.vetoed_by:
        print(f"  Vetoed by: {consensus_result.vetoed_by}")

    # Update ADR status based on vote
    final_status = ArtifactStatus.ACCEPTED if consensus_result.status == ProposalStatus.PASSED else ArtifactStatus.REJECTED
    shared.artifact_store.update(
        shared.adr_id, agent="Moderator",
        status=final_status,
        sections={"status": consensus_result.status.value},
        message=f"Decision: {consensus_result.status.value} (approval: {consensus_result.approval_rate:.0%})",
    )

    # ── Final Summary ───────────────────────────────────────────────
    print(f"\n{'='*70}")
    print(f"  SESSION SUMMARY")
    print(f"{'='*70}")
    print(f"  Total turns: {result.total_turns}")
    print(f"  Duration: {result.duration_seconds:.1f}s")

    # Conviction drift
    print(f"\n  📊 CONVICTION DRIFT:")
    for agent_def in AGENTS:
        name = agent_def["name"]
        initial = agent_def["initial_conviction"]
        final = shared.conviction.get_conviction(name, "proposed-decision") or initial
        drift = final - initial
        arrow = "↑" if drift > 0.01 else "↓" if drift < -0.01 else "→"
        bar_initial = "░" * int(initial * 20)
        bar_final = "█" * int(final * 20)
        print(f"    {name:15s} {initial:.2f} {arrow} {final:.2f}  (drift: {drift:+.3f})")

    # Polarization & convergence
    polarization = shared.conviction.detect_polarization("proposed-decision")
    converging = shared.conviction.detect_convergence("proposed-decision")
    entrenched = shared.conviction.detect_entrenchment("proposed-decision")

    print(f"\n  Polarization: {polarization:.3f} (0=consensus, 1=polarized)")
    print(f"  Converging: {'Yes' if converging else 'No'}")
    if entrenched:
        print(f"  Entrenched agents: {', '.join(entrenched)}")

    # Biggest movers
    movers = shared.conviction.biggest_movers("proposed-decision")
    if movers:
        biggest = movers[0]
        print(f"  Biggest mover: {biggest[0]} (drift: {biggest[1]:+.3f})")

    # ADR artifact summary
    artifact = shared.artifact_store.get(shared.adr_id)
    if artifact:
        print(f"\n  📄 FINAL ADR (v{artifact.version}):")
        print(f"    Title: {artifact.sections.get('title', '')}")
        print(f"    Status: {artifact.status.value}")
        print(f"    Decision: {artifact.sections.get('decision', '')}")
        contributors = shared.artifact_store.get_contributors(shared.adr_id)
        print(f"    Contributors: {', '.join(contributors)}")
        print(f"    Versions: {artifact.version}")

    # Participation
    if result.session_metrics:
        participation = result.session_metrics.get("participation", {})
        gini = participation.get("gini", "N/A")
        turns = result.session_metrics.get("turns", {}).get("per_agent", {})
        print(f"\n  PARTICIPATION (Gini: {gini}):")
        for agent, count in sorted(turns.items(), key=lambda x: -x[1]):
            print(f"    {agent}: {count} turns")

    # Evidence events
    events = shared.conviction.get_events()
    print(f"\n  Total evidence events: {len(events)}")

    # Capability output: per-agent evidence processing stats
    print(f"\n  CAPABILITY: EvidenceExtractor")
    for name, cap in evidence_caps.items():
        print(f"    {name}: processed {cap.evidence_count} evidence turns")

    print(f"\n{'='*70}\n")


if __name__ == "__main__":
    main()
