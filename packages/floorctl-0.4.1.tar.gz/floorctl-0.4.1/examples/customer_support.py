#!/usr/bin/env python3
"""
customer_support.py — Multi-agent customer support triage with EXTENSIVE capabilities.

This example showcases how multiple capabilities compose on a single agent to create
rich, production-like behavior. Each agent has 2-4 capabilities that chain together.

Scenario:
  A customer has filed a support ticket. Three specialist agents triage the issue:
  - Diagnostician: Identifies the root cause using a knowledge base (RAG)
  - Resolver: Proposes solutions, tracks resolution steps
  - Communicator: Drafts customer-facing responses with sentiment awareness

Capabilities demonstrated:
  1. KnowledgeBaseCapability  — enrich_context with simulated RAG retrieval
  2. SentimentCapability      — on_turn_received to track emotional tone
  3. ResolutionTrackerCapability — post_process to tag resolution steps
  4. ResponseDraftCapability  — enrich_context + post_process for customer comms
  5. EscalationDetectorCapability — on_turn_received to flag escalation triggers

This is the "kitchen sink" example — it shows how capabilities compose,
chain in order, and interact without conflicts.

Usage:
    python examples/customer_support.py
    python examples/customer_support.py --ticket "User reports data loss after migration"
    python examples/customer_support.py -v  # verbose logging
"""

import argparse
import json
import logging
import os
import re
import sys
import time

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from floorctl import (
    FloorAgent,
    FloorSession,
    ModeratorObserver,
    AgentProfile,
    AgentCapability,
    ArenaConfig,
    PhaseConfig,
    PhaseSequence,
    FloorConfig,
    ModeratorConfig,
    InMemoryBackend,
    TurnRecord,
    SpeakerPrefixValidator,
    DuplicateValidator,
    LengthValidator,
    BannedPhraseValidator,
)


# ═══════════════════════════════════════════════════════════════════════
# CAPABILITIES — This is the showcase. Each one is a reusable building block.
# ═══════════════════════════════════════════════════════════════════════


class KnowledgeBaseCapability(AgentCapability):
    """Simulated RAG — retrieves relevant docs based on the ticket topic.

    In production, this would call a vector DB (Pinecone, Weaviate, pgvector).
    Here we use a simple keyword-based lookup against a static knowledge base.

    Hook used: enrich_context
    Pipeline position: runs before LLM generation, adds retrieved docs to context
    """

    name = "knowledge_base"

    # Simulated knowledge base — in production this would be a vector search
    KB = {
        "migration": [
            "KB-101: Data migration failures often caused by schema version mismatch. Check migration_log table.",
            "KB-102: Always run `db:verify` after migration to check row counts match.",
            "KB-103: Migration rollback requires backup from pre-migration snapshot. Check S3 bucket.",
        ],
        "data loss": [
            "KB-201: Data loss reports — first verify if data is in soft-delete state (deleted_at NOT NULL).",
            "KB-202: Check audit_log for DELETE operations in the affected timeframe.",
            "KB-203: Recovery SLA: Tier-1 data recoverable within 4 hours from hourly snapshots.",
        ],
        "login": [
            "KB-301: Login failures after password reset — clear SSO session cache.",
            "KB-302: MFA token expiry is 30 seconds. Clock skew > 30s causes persistent failures.",
        ],
        "performance": [
            "KB-401: Slow queries — check if ANALYZE has been run on affected tables.",
            "KB-402: Connection pool exhaustion — default max is 20, increase to 50 for high-traffic.",
        ],
        "billing": [
            "KB-501: Double-charge reports — check idempotency key in payment_events table.",
            "KB-502: Refund processing takes 5-10 business days via Stripe.",
        ],
        "api": [
            "KB-601: Rate limit is 1000 req/min per API key. 429 errors indicate throttling.",
            "KB-602: API timeout default is 30s. Long-running queries should use async endpoint.",
        ],
    }

    def enrich_context(self, context: dict) -> dict:
        """Search KB for relevant articles based on topic keywords."""
        topic = context.get("topic", "").lower()
        retrieved = []
        for keyword, articles in self.KB.items():
            if keyword in topic:
                retrieved.extend(articles)

        # Also search recent turns for additional keywords
        recent = context.get("recent_turns", "").lower()
        for keyword, articles in self.KB.items():
            if keyword in recent and not any(a in retrieved for a in articles):
                retrieved.extend(articles[:1])  # Add top match only

        if retrieved:
            context["kb:retrieved_docs"] = "\n".join(f"  {doc}" for doc in retrieved[:5])
            context["kb:doc_count"] = str(len(retrieved))
        return context


class SentimentCapability(AgentCapability):
    """Tracks emotional sentiment of the discussion over time.

    Useful for detecting when a support conversation is going south
    (frustration building) or improving (resolution in sight).

    Hook used: on_turn_received (side-effect only)
    """

    name = "sentiment"

    POSITIVE_WORDS = {
        "resolved", "fixed", "working", "solution", "found", "confirm",
        "thanks", "great", "excellent", "recovered", "restored", "success",
    }
    NEGATIVE_WORDS = {
        "broken", "lost", "error", "fail", "crash", "corrupt", "missing",
        "frustrated", "unacceptable", "critical", "urgent", "escalate",
        "damage", "outage", "down", "unavailable", "angry", "disappointed",
    }

    def __init__(self):
        self.history: list[dict] = []

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        if turn.is_moderator:
            return
        words = set(turn.text.lower().split())
        pos = len(words & self.POSITIVE_WORDS)
        neg = len(words & self.NEGATIVE_WORDS)
        score = (pos - neg) / max(pos + neg, 1)  # -1.0 to 1.0
        self.history.append({
            "speaker": turn.speaker,
            "score": score,
            "phase": turn.phase,
        })

    def current_mood(self) -> str:
        """Return the current overall mood of the conversation."""
        if not self.history:
            return "neutral"
        recent = self.history[-3:]
        avg = sum(h["score"] for h in recent) / len(recent)
        if avg > 0.3:
            return "positive"
        elif avg < -0.3:
            return "negative"
        return "neutral"

    def trend(self) -> str:
        """Is sentiment improving or declining?"""
        if len(self.history) < 3:
            return "stable"
        early = sum(h["score"] for h in self.history[:3]) / 3
        recent = sum(h["score"] for h in self.history[-3:]) / 3
        if recent - early > 0.2:
            return "improving"
        elif recent - early < -0.2:
            return "declining"
        return "stable"


class ResolutionTrackerCapability(AgentCapability):
    """Tracks resolution steps proposed by agents.

    Demonstrates:
    - on_turn_received: extracts action items from turns
    - enrich_context: injects action items so agents don't repeat steps
    - post_process: tags responses that contain new action items

    Hook used: on_turn_received, enrich_context, post_process (ALL THREE)
    """

    name = "resolution_tracker"

    ACTION_PATTERNS = [
        r"(?:step \d|action item|next step|recommendation|we should|please|let's)\s*:?\s*(.+)",
        r"(?:run|execute|check|verify|restart|rollback|deploy|update)\s+(.+?)(?:\.|$)",
    ]

    def __init__(self):
        self.steps: list[dict] = []
        self.resolved = False

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        if turn.is_moderator:
            return
        text = turn.text.lower()
        for pattern in self.ACTION_PATTERNS:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                self.steps.append({
                    "step": match.strip()[:100],
                    "proposed_by": turn.speaker,
                    "phase": turn.phase,
                })

        # Check for resolution indicators
        if any(word in text for word in ["resolved", "fixed", "confirmed working"]):
            self.resolved = True

    def enrich_context(self, context: dict) -> dict:
        if self.steps:
            step_list = "\n".join(
                f"  {i+1}. {s['step']} (by {s['proposed_by']})"
                for i, s in enumerate(self.steps[-5:])
            )
            context["resolution:action_items"] = step_list
            context["resolution:total_steps"] = str(len(self.steps))
            context["resolution:status"] = "RESOLVED" if self.resolved else "IN PROGRESS"
        return context

    def post_process(self, response: str, context: dict) -> str:
        """No modification — just tracking. Capability doesn't need to change output."""
        return response


class ResponseDraftCapability(AgentCapability):
    """Helps the Communicator agent draft customer-facing responses.

    Demonstrates capability that is agent-specific — only useful for the
    Communicator agent but harmless on others.

    Hook used: enrich_context, post_process
    """

    name = "response_draft"

    TEMPLATES = {
        "investigating": "We're actively investigating your reported issue regarding {topic}.",
        "identified": "We've identified the root cause and are working on a resolution.",
        "resolved": "Great news — your issue has been resolved. Here's what happened: ",
        "escalated": "We've escalated your ticket to our senior engineering team for priority attention.",
    }

    def __init__(self, sentiment_cap: SentimentCapability):
        self.sentiment = sentiment_cap

    def enrich_context(self, context: dict) -> dict:
        """Add sentiment-aware drafting hints."""
        mood = self.sentiment.current_mood()
        trend = self.sentiment.trend()
        context["response_draft:customer_mood"] = mood
        context["response_draft:mood_trend"] = trend
        if mood == "negative":
            context["response_draft:tone_hint"] = (
                "Customer appears frustrated. Use empathetic language. "
                "Acknowledge the impact. Avoid technical jargon."
            )
        elif mood == "positive":
            context["response_draft:tone_hint"] = (
                "Customer sentiment is positive. Be professional but warm."
            )
        return context

    def post_process(self, response: str, context: dict) -> str:
        """Ensure customer-facing responses don't contain internal jargon."""
        # Remove common internal references
        response = response.replace("KB-", "article ")
        return response


class EscalationDetectorCapability(AgentCapability):
    """Detects when a ticket should be escalated to senior engineering.

    Demonstrates: on_turn_received for real-time monitoring + state tracking.

    Hook used: on_turn_received
    """

    name = "escalation_detector"

    ESCALATION_TRIGGERS = [
        "data loss", "data corruption", "security breach", "downtime",
        "sla violation", "regulatory", "legal", "executive",
        "production outage", "p0", "p1", "critical",
    ]

    def __init__(self):
        self.should_escalate = False
        self.escalation_reasons: list[str] = []

    def on_turn_received(self, turn: TurnRecord, agent_name: str) -> None:
        if turn.is_moderator:
            return
        text_lower = turn.text.lower()
        for trigger in self.ESCALATION_TRIGGERS:
            if trigger in text_lower and trigger not in self.escalation_reasons:
                self.escalation_reasons.append(trigger)
                self.should_escalate = True


# ═══════════════════════════════════════════════════════════════════════
# LLM Integration
# ═══════════════════════════════════════════════════════════════════════


def create_generator():
    from openai import OpenAI
    client = OpenAI()

    def generate(agent_name: str, context: dict) -> str:
        retry_info = ""
        if context.get("retry_failures"):
            retry_info = (
                f"\n\nPREVIOUS ATTEMPT REJECTED. Fix these:\n"
                + "\n".join(f"- {f}" for f in context["retry_failures"])
            )

        # Build capability-injected context sections
        extra_sections = ""
        if context.get("kb:retrieved_docs"):
            extra_sections += f"\nKNOWLEDGE BASE ARTICLES:\n{context['kb:retrieved_docs']}\n"
        if context.get("resolution:action_items"):
            extra_sections += f"\nACTION ITEMS SO FAR:\n{context['resolution:action_items']}\n"
        if context.get("response_draft:tone_hint"):
            extra_sections += f"\nTONE GUIDANCE: {context['response_draft:tone_hint']}\n"

        prompt = f"""You are {agent_name}, a customer support specialist.
Role: {context.get('personality', '')}
Customer Ticket: {context['topic']}
Phase: {context['phase']}
{extra_sections}

Discussion so far:
{context.get('recent_turns', '(none yet)')}

RULES:
- Prefix with "{agent_name}:"
- {context.get('phase_min_words', 20)}-{context.get('phase_max_words', 100)} words
- Be specific and actionable — no generic "we'll look into it"
- Reference knowledge base articles when available
- Propose concrete next steps
{retry_info}

{agent_name}:"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=250,
            temperature=0.7,
        )
        text = response.choices[0].message.content.strip()
        if not text.startswith(f"{agent_name}:"):
            text = f"{agent_name}: {text}"
        return text

    return generate


def create_moderator():
    from openai import OpenAI
    client = OpenAI()

    def moderate(prompt_type: str, context: dict) -> str:
        ticket = context.get("topic", "")
        agents = context.get("agents", [])

        prompts = {
            "intro": (
                f"You are the Support Lead triaging ticket: '{ticket}'. "
                f"Team: {', '.join(agents)}. Give a 2-sentence briefing on the ticket."
            ),
            "invite_opening": (
                f"Ask {context.get('agent_name', '')} for their initial assessment "
                f"of '{ticket}'. 1 sentence."
            ),
            "phase_transition": (
                f"Transition from {context.get('previous_phase', '')} to {context.get('phase', '')}. "
                f"Summarize findings. 2 sentences."
            ),
            "intervention": (
                f"Support Lead intervention: {context.get('intervention_type', '')}. "
                f"Redirect to {context.get('target_agent', 'the team')}. 1 sentence."
            ),
            "closing": (
                f"Close the triage for '{ticket}'. State resolution status and next steps. 2 sentences."
            ),
        }

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompts.get(prompt_type, f"Brief comment on {ticket}.")}],
            max_tokens=150,
            temperature=0.7,
        )
        return response.choices[0].message.content.strip()

    return moderate


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════


def main():
    parser = argparse.ArgumentParser(description="Multi-agent support triage with capabilities")
    parser.add_argument(
        "--ticket",
        default="User reports data loss after database migration — 500 records missing from production",
    )
    parser.add_argument("--max-turns", type=int, default=14)
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY required")
        sys.exit(1)

    backend = InMemoryBackend()
    generate_fn = create_generator()
    moderator_fn = create_moderator()

    # ── Phases ──────────────────────────────────────────────────────
    phases = PhaseSequence(phases=[
        PhaseConfig(
            name="TRIAGE",
            is_opening=True,
            max_turns=6,
            max_words=100,
            min_words=15,
            max_sentences=4,
            allow_critiques=False,
            constraints="Identify the problem category and severity. Reference any relevant KB articles.",
        ),
        PhaseConfig(
            name="INVESTIGATE",
            min_turns=6,
            max_turns=12,
            max_words=120,
            min_words=20,
            constraints="Dig deeper. Propose specific diagnostic steps or solutions. Build on others' findings.",
        ),
        PhaseConfig(name="CLOSING", is_terminal=True),
    ])

    config = ArenaConfig(
        phases=phases,
        floor=FloorConfig(timeout_seconds=30, min_turns_between_speaking=1, max_turns_per_phase_per_agent=4),
        moderator=ModeratorConfig(silence_threshold=3, dominance_threshold=3),
        banned_phrases=["As an AI", "I understand your frustration"],
        max_self_retries=2,
        max_total_turns=args.max_turns,
    )

    validators = [
        SpeakerPrefixValidator(),
        DuplicateValidator(),
        LengthValidator(),
        BannedPhraseValidator(banned_phrases=config.banned_phrases),
    ]

    # ── Shared Capabilities ─────────────────────────────────────────
    # These instances are shared across agents — all agents contribute data
    kb = KnowledgeBaseCapability()
    sentiment = SentimentCapability()
    resolution = ResolutionTrackerCapability()
    escalation = EscalationDetectorCapability()
    response_draft = ResponseDraftCapability(sentiment)

    # ── Agents with different capability combinations ───────────────
    #
    # This is the key pattern: each agent gets a DIFFERENT MIX of capabilities
    # based on their role. Some capabilities are shared (sentiment, resolution),
    # some are agent-specific (response_draft only on Communicator).

    diagnostician = FloorAgent(
        name="Diagnostician",
        profile=AgentProfile(
            name="Diagnostician",
            personality=(
                "Root cause analysis expert. You diagnose issues using knowledge base "
                "articles and systematic troubleshooting. You think in terms of logs, "
                "traces, and reproduction steps."
            ),
            react_to=["error", "fail", "missing", "corrupt", "broken", "symptom"],
            temperament="deliberate",
            base_cooldown=5.0,
            urgency_boost_keywords=["root cause", "log", "trace", "reproduce", "diagnose"],
        ),
        generate_fn=generate_fn,
        backend=backend,
        validators=validators,
        config=config,
        capabilities=[kb, sentiment, escalation],  # RAG + sentiment + escalation
    )

    resolver = FloorAgent(
        name="Resolver",
        profile=AgentProfile(
            name="Resolver",
            personality=(
                "Solutions engineer. You propose and track resolution steps. "
                "You think in terms of rollback plans, patches, and verification. "
                "You are action-oriented and want to fix things fast."
            ),
            react_to=["cause", "found", "identified", "confirmed", "root cause", "diagnosis"],
            temperament="passionate",
            base_cooldown=5.0,
            urgency_boost_keywords=["fix", "resolve", "patch", "rollback", "deploy", "recover"],
        ),
        generate_fn=generate_fn,
        backend=backend,
        validators=validators,
        config=config,
        capabilities=[kb, sentiment, resolution, escalation],  # RAG + sentiment + resolution + escalation
    )

    communicator = FloorAgent(
        name="Communicator",
        profile=AgentProfile(
            name="Communicator",
            personality=(
                "Customer communications specialist. You draft clear, empathetic "
                "responses for the customer. You translate technical findings into "
                "plain language. You manage expectations and provide timelines."
            ),
            react_to=["update", "status", "timeline", "customer", "communicate", "response"],
            temperament="patient",
            base_cooldown=7.0,
            urgency_boost_keywords=["customer", "response", "update", "SLA", "timeline"],
        ),
        generate_fn=generate_fn,
        backend=backend,
        validators=validators,
        config=config,
        capabilities=[sentiment, resolution, response_draft, escalation],  # sentiment + resolution + draft + escalation
    )

    # ── Session Setup ───────────────────────────────────────────────
    session_id = f"support-{int(time.time())}"
    agent_names = ["Diagnostician", "Resolver", "Communicator"]

    moderator = ModeratorObserver(
        agent_names=agent_names,
        moderator_fn=moderator_fn,
        backend=backend,
        session_id=session_id,
        phase_sequence=phases,
        config=config.moderator,
    )

    # Print header
    print(f"\n{'='*70}")
    print(f"  SUPPORT TRIAGE — CAPABILITY SHOWCASE")
    print(f"  Ticket: {args.ticket}")
    print(f"  Team: {', '.join(agent_names)}")
    print(f"  Capabilities:")
    print(f"    Diagnostician: KnowledgeBase, Sentiment, EscalationDetector")
    print(f"    Resolver:      KnowledgeBase, Sentiment, ResolutionTracker, EscalationDetector")
    print(f"    Communicator:  Sentiment, ResolutionTracker, ResponseDraft, EscalationDetector")
    print(f"{'='*70}\n")

    backend.create_session(session_id, {
        "topic": args.ticket,
        "phase": "TRIAGE",
        "participants": agent_names,
    })

    def print_turn(turn):
        if turn.is_moderator:
            print(f"\n  {'─'*60}")
            print(f"  📋 Support Lead  [{turn.phase}]")
            print(f"  {turn.text}")
            print(f"  {'─'*60}")
        else:
            icons = {"Diagnostician": "🔬", "Resolver": "🔧", "Communicator": "💬"}
            icon = icons.get(turn.speaker, "👤")
            print(f"\n  {icon} {turn.speaker}  [{turn.phase}]")
            print(f"     {turn.text}")

    backend.subscribe_turns(session_id, print_turn)

    session = FloorSession(backend=backend, config=config)
    session.add_agent(diagnostician)
    session.add_agent(resolver)
    session.add_agent(communicator)
    session.set_moderator(moderator)

    result = session.run(session_id, topic=args.ticket, timeout_seconds=args.timeout)

    # ── Results ─────────────────────────────────────────────────────
    print(f"\n{'='*70}")
    print(f"  TRIAGE COMPLETE")
    print(f"{'='*70}")
    print(f"  Turns: {result.total_turns} | Duration: {result.duration_seconds:.1f}s")

    if result.session_metrics:
        gini = result.session_metrics.get("participation", {}).get("gini", "N/A")
        turns = result.session_metrics.get("turns", {}).get("per_agent", {})
        print(f"  Gini: {gini}")
        for agent, count in sorted(turns.items(), key=lambda x: -x[1]):
            print(f"    {agent}: {count} turns")

    # ── Capability Reports ──────────────────────────────────────────
    print(f"\n  {'─'*60}")
    print(f"  CAPABILITY REPORTS")
    print(f"  {'─'*60}")

    # Sentiment
    print(f"\n  📊 Sentiment Analysis:")
    print(f"    Current mood: {sentiment.current_mood()}")
    print(f"    Trend: {sentiment.trend()}")
    if sentiment.history:
        scores = [h["score"] for h in sentiment.history]
        print(f"    Score range: {min(scores):.2f} to {max(scores):.2f}")

    # Resolution tracker
    print(f"\n  ✅ Resolution Tracker:")
    print(f"    Status: {'RESOLVED' if resolution.resolved else 'IN PROGRESS'}")
    print(f"    Action items: {len(resolution.steps)}")
    for i, step in enumerate(resolution.steps):
        print(f"      {i+1}. {step['step'][:60]} (by {step['proposed_by']})")

    # Escalation detector
    print(f"\n  🚨 Escalation Detector:")
    if escalation.should_escalate:
        print(f"    ESCALATION RECOMMENDED")
        print(f"    Triggers: {', '.join(escalation.escalation_reasons)}")
    else:
        print(f"    No escalation needed")

    # Knowledge base usage
    print(f"\n  📚 Knowledge Base:")
    print(f"    Articles available for this topic: "
          f"{sum(len(v) for k, v in kb.KB.items() if k in args.ticket.lower())}")

    print(f"\n{'='*70}\n")


if __name__ == "__main__":
    main()
