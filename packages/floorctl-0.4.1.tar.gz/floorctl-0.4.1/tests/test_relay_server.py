"""
Tests for the WebSocket relay server.

Uses real asyncio WebSocket connections to test the relay end-to-end.
"""

import asyncio
import json
import pytest
import threading
import time

import websockets

from floorctl.relay.server import RelayServer


# ── Fixtures ─────────────────────────────────────────────────────────

@pytest.fixture
def relay_port():
    """Find a free port for testing."""
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


@pytest.fixture
def relay_server(relay_port):
    """Start a relay server in a background thread."""
    server = RelayServer(api_key="test-key")
    loop = asyncio.new_event_loop()
    started = threading.Event()

    async def run():
        async with websockets.serve(server.handler, "127.0.0.1", relay_port):
            started.set()
            await asyncio.Future()  # run forever

    def target():
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(run())
        except asyncio.CancelledError:
            pass

    thread = threading.Thread(target=target, daemon=True)
    thread.start()
    started.wait(timeout=5.0)

    yield server, relay_port

    loop.call_soon_threadsafe(loop.stop)


async def _connect(port, api_key="test-key", agent_name=None):
    """Helper: connect and authenticate."""
    ws = await websockets.connect(f"ws://127.0.0.1:{port}")
    auth = {"action": "auth", "api_key": api_key}
    if agent_name:
        auth["agent_name"] = agent_name
    await ws.send(json.dumps(auth))
    resp = json.loads(await ws.recv())
    assert resp["action"] == "auth_ok"
    return ws


async def _send_recv(ws, msg):
    """Send a message and wait for response."""
    msg["request_id"] = f"req-{id(msg)}"
    await ws.send(json.dumps(msg))
    resp = json.loads(await ws.recv())
    return resp


# ── Tests ────────────────────────────────────────────────────────────

class TestRelayAuth:
    def test_auth_success(self, relay_server):
        _, port = relay_server

        async def _test():
            ws = await _connect(port)
            await ws.close()

        asyncio.run(_test())

    def test_auth_failure(self, relay_server):
        _, port = relay_server

        async def _test():
            ws = await websockets.connect(f"ws://127.0.0.1:{port}")
            await ws.send(json.dumps({"action": "auth", "api_key": "wrong"}))
            resp = json.loads(await ws.recv())
            assert "error" in resp

        asyncio.run(_test())

    def test_no_auth_message(self, relay_server):
        _, port = relay_server

        async def _test():
            ws = await websockets.connect(f"ws://127.0.0.1:{port}")
            await ws.send(json.dumps({"action": "not_auth"}))
            resp = json.loads(await ws.recv())
            assert "error" in resp

        asyncio.run(_test())


class TestRelaySession:
    def test_create_session(self, relay_server):
        _, port = relay_server

        async def _test():
            ws = await _connect(port)
            resp = await _send_recv(ws, {
                "action": "create_session",
                "session_id": "s1",
                "config": {"topic": "test", "participants": ["A", "B"]},
            })
            assert resp["action"] == "session_created"
            await ws.close()

        asyncio.run(_test())

    def test_get_session_state(self, relay_server):
        _, port = relay_server

        async def _test():
            ws = await _connect(port)
            await _send_recv(ws, {
                "action": "create_session",
                "session_id": "s2",
                "config": {"topic": "testing", "participants": ["A"]},
            })
            resp = await _send_recv(ws, {
                "action": "get_session_state",
                "session_id": "s2",
            })
            assert resp["action"] == "session_state"
            assert resp["state"]["topic"] == "testing"
            assert resp["state"]["status"] == "WAITING"
            await ws.close()

        asyncio.run(_test())

    def test_update_session(self, relay_server):
        _, port = relay_server

        async def _test():
            ws = await _connect(port)
            await _send_recv(ws, {
                "action": "create_session",
                "session_id": "s3",
                "config": {"topic": "t"},
            })
            resp = await _send_recv(ws, {
                "action": "update_session",
                "session_id": "s3",
                "updates": {"status": "LIVE", "phase": "DEBATE"},
            })
            assert resp["state"]["status"] == "LIVE"
            assert resp["state"]["phase"] == "DEBATE"
            await ws.close()

        asyncio.run(_test())

    def test_nonexistent_session(self, relay_server):
        _, port = relay_server

        async def _test():
            ws = await _connect(port)
            resp = await _send_recv(ws, {
                "action": "get_session_state",
                "session_id": "nope",
            })
            assert "error" in resp
            await ws.close()

        asyncio.run(_test())


class TestRelayFloorControl:
    def test_claim_floor(self, relay_server):
        _, port = relay_server

        async def _test():
            ws = await _connect(port)
            await _send_recv(ws, {
                "action": "create_session",
                "session_id": "fc1",
                "config": {},
            })
            resp = await _send_recv(ws, {
                "action": "claim_floor",
                "session_id": "fc1",
                "agent_name": "Alice",
                "timeout_seconds": 30.0,
            })
            assert resp["result"] is True
            await ws.close()

        asyncio.run(_test())

    def test_contention(self, relay_server):
        _, port = relay_server

        async def _test():
            ws1 = await _connect(port, agent_name="Alice")
            ws2 = await _connect(port, agent_name="Bob")

            # Create session
            await _send_recv(ws1, {
                "action": "create_session",
                "session_id": "fc2",
                "config": {},
            })

            # Alice claims
            r1 = await _send_recv(ws1, {
                "action": "claim_floor",
                "session_id": "fc2",
                "agent_name": "Alice",
                "timeout_seconds": 30.0,
            })
            assert r1["result"] is True

            # Bob tries — should fail
            r2 = await _send_recv(ws2, {
                "action": "claim_floor",
                "session_id": "fc2",
                "agent_name": "Bob",
                "timeout_seconds": 30.0,
            })
            assert r2["result"] is False

            # Alice releases
            await _send_recv(ws1, {
                "action": "release_floor",
                "session_id": "fc2",
                "agent_name": "Alice",
                "posted_successfully": True,
            })

            # Bob claims — should succeed now
            r3 = await _send_recv(ws2, {
                "action": "claim_floor",
                "session_id": "fc2",
                "agent_name": "Bob",
                "timeout_seconds": 30.0,
            })
            assert r3["result"] is True

            await ws1.close()
            await ws2.close()

        asyncio.run(_test())

    def test_reserve_floor(self, relay_server):
        _, port = relay_server

        async def _test():
            ws = await _connect(port)
            await _send_recv(ws, {
                "action": "create_session",
                "session_id": "fc3",
                "config": {},
            })

            # Reserve for Bob
            r = await _send_recv(ws, {
                "action": "reserve_floor",
                "session_id": "fc3",
                "for_agent": "Bob",
            })
            assert r["action"] == "floor_reserved"

            # Alice tries — should fail (reserved for Bob)
            r2 = await _send_recv(ws, {
                "action": "claim_floor",
                "session_id": "fc3",
                "agent_name": "Alice",
                "timeout_seconds": 30.0,
            })
            assert r2["result"] is False

            # Bob claims — should succeed
            r3 = await _send_recv(ws, {
                "action": "claim_floor",
                "session_id": "fc3",
                "agent_name": "Bob",
                "timeout_seconds": 30.0,
            })
            assert r3["result"] is True

            await ws.close()

        asyncio.run(_test())


class TestRelayTurns:
    def test_post_and_get_turns(self, relay_server):
        _, port = relay_server

        async def _test():
            ws = await _connect(port)
            await _send_recv(ws, {
                "action": "create_session",
                "session_id": "t1",
                "config": {},
            })

            # Post turn
            r = await _send_recv(ws, {
                "action": "post_turn",
                "session_id": "t1",
                "turn": {
                    "agent_name": "Alice",
                    "transcript": "Hello!",
                    "timestamp": "2024-01-01",
                    "is_moderator": False,
                },
            })
            assert r["action"] == "turn_posted"
            assert "turn_id" in r

            # Get turns
            r2 = await _send_recv(ws, {
                "action": "get_turns",
                "session_id": "t1",
                "since_index": 0,
            })
            assert len(r2["turns"]) == 1
            assert r2["turns"][0]["speaker"] == "Alice"
            assert r2["turns"][0]["text"] == "Hello!"

            await ws.close()

        asyncio.run(_test())

    def test_turn_broadcast(self, relay_server):
        _, port = relay_server

        async def _test():
            ws1 = await _connect(port, agent_name="Alice")
            ws2 = await _connect(port, agent_name="Bob")

            # Create session
            await _send_recv(ws1, {
                "action": "create_session",
                "session_id": "t2",
                "config": {},
            })

            # Both subscribe
            await _send_recv(ws1, {"action": "subscribe", "session_id": "t2"})
            await _send_recv(ws2, {"action": "subscribe", "session_id": "t2"})

            # Alice posts — Bob should receive broadcast
            await ws1.send(json.dumps({
                "action": "post_turn",
                "session_id": "t2",
                "request_id": "post-1",
                "turn": {
                    "agent_name": "Alice",
                    "transcript": "Hey Bob!",
                    "timestamp": "now",
                },
            }))

            # Collect messages from ws2 (expect broadcast)
            received = []
            try:
                while True:
                    msg = json.loads(await asyncio.wait_for(ws2.recv(), timeout=2.0))
                    received.append(msg)
                    if msg.get("action") == "new_turn":
                        break
            except asyncio.TimeoutError:
                pass

            broadcasts = [m for m in received if m.get("action") == "new_turn"]
            assert len(broadcasts) == 1
            assert broadcasts[0]["turn"]["speaker"] == "Alice"
            assert broadcasts[0]["turn"]["text"] == "Hey Bob!"

            await ws1.close()
            await ws2.close()

        asyncio.run(_test())

    def test_get_turns_since_index(self, relay_server):
        _, port = relay_server

        async def _test():
            ws = await _connect(port)
            await _send_recv(ws, {
                "action": "create_session",
                "session_id": "t3",
                "config": {},
            })

            # Post 3 turns
            for i in range(3):
                await _send_recv(ws, {
                    "action": "post_turn",
                    "session_id": "t3",
                    "turn": {
                        "agent_name": f"Agent{i}",
                        "transcript": f"Turn {i}",
                        "timestamp": "now",
                    },
                })

            # Get since index 2
            r = await _send_recv(ws, {
                "action": "get_turns",
                "session_id": "t3",
                "since_index": 2,
            })
            assert len(r["turns"]) == 1
            assert r["turns"][0]["text"] == "Turn 2"

            await ws.close()

        asyncio.run(_test())


class TestRelayMetrics:
    def test_store_metrics(self, relay_server):
        _, port = relay_server

        async def _test():
            ws = await _connect(port)
            await _send_recv(ws, {
                "action": "create_session",
                "session_id": "m1",
                "config": {},
            })

            r = await _send_recv(ws, {
                "action": "store_metrics",
                "session_id": "m1",
                "agent_name": "Alice",
                "data": {"floor_claims": 5},
            })
            assert r["action"] == "metrics_stored"
            await ws.close()

        asyncio.run(_test())
