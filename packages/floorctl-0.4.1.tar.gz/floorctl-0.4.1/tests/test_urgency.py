"""Tests for urgency scoring."""

from floorctl.config import AgentProfile
from floorctl.state import ConversationState
from floorctl.urgency import (
    UrgencyScorer,
    KeywordReactComponent,
    SilenceBonusComponent,
    RecentSpeakerPenaltyComponent,
    NameMentionComponent,
    TEMPERAMENT_THRESHOLDS,
)


def test_keyword_react_basic():
    comp = KeywordReactComponent()
    profile = AgentProfile(name="Alpha", react_to=["cost", "risk"])
    state = ConversationState(topic="Test", phase="DISCUSSION")

    name, score = comp.compute("Alpha", "The cost is too high", "Beta", False, state, profile)
    assert name == "keyword_react"
    assert score > 0


def test_keyword_react_no_match():
    comp = KeywordReactComponent()
    profile = AgentProfile(name="Alpha", react_to=["cost", "risk"])
    state = ConversationState(topic="Test", phase="DISCUSSION")

    _, score = comp.compute("Alpha", "Hello world", "Beta", False, state, profile)
    assert score == 0.0


def test_silence_bonus():
    comp = SilenceBonusComponent()
    profile = AgentProfile(name="Alpha")
    state = ConversationState(topic="Test", phase="DISCUSSION")

    # No turns yet — full silence
    _, score = comp.compute("Alpha", "text", "Beta", False, state, profile)
    assert score == 0.0  # No transcript = 0 turns silent

    # Add turns without Alpha speaking
    for i in range(6):
        state.add_turn("Beta", f"Turn {i}")

    _, score = comp.compute("Alpha", "text", "Beta", False, state, profile)
    assert score >= 0.40  # 6+ turns silent = max bonus


def test_recent_speaker_penalty():
    comp = RecentSpeakerPenaltyComponent(min_turns_between=2)
    profile = AgentProfile(name="Alpha")
    state = ConversationState(topic="Test", phase="DISCUSSION")

    state.add_turn("Alpha", "I just spoke")
    state.add_turn("Beta", "Response")

    # Only 1 turn since Alpha spoke (< 2 min)
    _, score = comp.compute("Alpha", "text", "Beta", False, state, profile)
    assert score == -0.5

    state.add_turn("Gamma", "Another turn")

    # Now 2 turns since Alpha spoke
    _, score = comp.compute("Alpha", "text", "Gamma", False, state, profile)
    assert score == 0.0


def test_name_mention():
    comp = NameMentionComponent()
    profile = AgentProfile(name="Alpha")
    state = ConversationState(topic="Test", phase="DISCUSSION")

    _, score = comp.compute("Alpha", "What does Alpha think?", "Beta", False, state, profile)
    assert score == 0.4

    _, score = comp.compute("Alpha", "What does Beta think?", "Gamma", False, state, profile)
    assert score == 0.0


def test_scorer_computes_result():
    scorer = UrgencyScorer()
    profile = AgentProfile(
        name="Alpha",
        react_to=["cost", "risk"],
        temperament="reactive",
    )
    state = ConversationState(topic="Test", phase="DISCUSSION")

    # Add some turns so Alpha hasn't spoken
    for i in range(5):
        state.add_turn("Beta", f"The cost and risk are high {i}")

    result = scorer.compute("Alpha", "The cost is too high", "Beta", False, state, profile)

    assert 0.0 <= result.score <= 1.0
    assert result.threshold == TEMPERAMENT_THRESHOLDS["reactive"]
    assert isinstance(result.components, dict)
    assert len(result.components) > 0


def test_temperament_thresholds():
    scorer = UrgencyScorer()

    reactive = AgentProfile(name="A", temperament="reactive")
    patient = AgentProfile(name="B", temperament="patient")

    assert scorer.threshold_for(reactive) == 0.35
    assert scorer.threshold_for(patient) == 0.55
    assert scorer.threshold_for(reactive) < scorer.threshold_for(patient)


def test_score_clamped():
    scorer = UrgencyScorer()
    profile = AgentProfile(name="Alpha", react_to=["a", "b", "c", "d", "e"])
    state = ConversationState(topic="Test", phase="DISCUSSION")

    # Force very high score
    for i in range(10):
        state.add_turn("Beta", f"a b c d e Alpha {i}")

    result = scorer.compute("Alpha", "a b c d e Alpha urgent critical", "Beta", False, state, profile)
    assert result.score <= 1.0
    assert result.score >= 0.0
