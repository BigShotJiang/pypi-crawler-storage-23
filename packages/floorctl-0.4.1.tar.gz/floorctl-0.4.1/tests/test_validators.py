"""Tests for validators."""

from floorctl.config import PhaseConfig, StyleContract
from floorctl.state import ConversationState
from floorctl.validators import (
    SpeakerPrefixValidator,
    DuplicateValidator,
    LengthValidator,
    BannedPhraseValidator,
    StyleContractValidator,
    PhaseValidator,
    run_validators,
)


def test_speaker_prefix_valid():
    v = SpeakerPrefixValidator()
    state = ConversationState()
    result = v.validate("Alpha: Hello world", "Alpha", state)
    assert result.passed


def test_speaker_prefix_wrong():
    v = SpeakerPrefixValidator()
    state = ConversationState()
    result = v.validate("Beta: Hello world", "Alpha", state, agent_names=["Alpha", "Beta"])
    assert not result.passed
    assert "Wrong speaker prefix" in result.reason


def test_speaker_prefix_missing():
    v = SpeakerPrefixValidator()
    state = ConversationState()
    result = v.validate("Hello world", "Alpha", state)
    assert not result.passed
    assert "Missing required prefix" in result.reason


def test_duplicate_exact():
    v = DuplicateValidator()
    state = ConversationState(topic="Test", phase="DISCUSSION")
    state.add_turn("Alpha", "Alpha: This is my exact response")

    # Same text again
    result = v.validate("Alpha: This is my exact response", "Alpha", state)
    assert not result.passed
    assert "duplicate" in result.reason.lower()


def test_duplicate_similar():
    v = DuplicateValidator(similarity_threshold=0.65)
    state = ConversationState(topic="Test", phase="DISCUSSION")
    state.add_turn("Alpha", "Alpha: The cost of deployment is very high and needs reduction")

    result = v.validate("Alpha: The cost of deployment is very high and needs to be reduced", "Alpha", state)
    assert not result.passed


def test_duplicate_unique():
    v = DuplicateValidator()
    state = ConversationState(topic="Test", phase="DISCUSSION")
    state.add_turn("Alpha", "Alpha: First unique point about costs")

    result = v.validate("Alpha: Completely different topic about innovation", "Alpha", state)
    assert result.passed


def test_length_too_long():
    v = LengthValidator(default_max_words=20)
    state = ConversationState()
    long_text = "Alpha: " + " ".join(["word"] * 30)
    result = v.validate(long_text, "Alpha", state)
    assert not result.passed
    assert "Too long" in result.reason


def test_length_too_short():
    v = LengthValidator(default_min_words=10)
    state = ConversationState()
    result = v.validate("Alpha: Short.", "Alpha", state)
    assert not result.passed
    assert "Too short" in result.reason


def test_length_ok():
    v = LengthValidator()
    state = ConversationState()
    text = "Alpha: " + " ".join(["word"] * 50)
    result = v.validate(text, "Alpha", state)
    assert result.passed


def test_banned_phrase():
    v = BannedPhraseValidator(banned_phrases=["As an AI", "Let's face it"])
    state = ConversationState()

    result = v.validate("Alpha: As an AI model, I think...", "Alpha", state)
    assert not result.passed

    result = v.validate("Alpha: I think this is important", "Alpha", state)
    assert result.passed


def test_style_contract_forbidden():
    contract = StyleContract(
        forbidden_patterns=["imagine a world", "like a"],
        description="No metaphors allowed",
    )
    v = StyleContractValidator()
    state = ConversationState()

    result = v.validate("Alpha: Imagine a world where AI...", "Alpha", state, style_contract=contract)
    assert not result.passed
    assert "forbidden pattern" in result.reason


def test_style_contract_max_sentences():
    contract = StyleContract(max_sentences=2, description="Max 2 sentences")
    v = StyleContractValidator()
    state = ConversationState()

    result = v.validate("Alpha: First. Second. Third. Fourth.", "Alpha", state, style_contract=contract)
    assert not result.passed


def test_phase_no_critiques():
    v = PhaseValidator()
    state = ConversationState()
    phase = PhaseConfig(name="OPENING", allow_critiques=False)

    result = v.validate("Alpha: I disagree with everything", "Alpha", state, phase_config=phase)
    assert not result.passed

    result = v.validate("Alpha: I believe in progress", "Alpha", state, phase_config=phase)
    assert result.passed


def test_run_validators_pipeline():
    validators = [
        SpeakerPrefixValidator(),
        BannedPhraseValidator(banned_phrases=["As an AI"]),
        LengthValidator(),
    ]
    state = ConversationState(topic="Test", phase="DISCUSSION")

    # Good response
    passed, failures = run_validators(
        "Alpha: " + " ".join(["good"] * 30),
        "Alpha", state, validators,
    )
    assert passed
    assert len(failures) == 0

    # Bad response (wrong prefix + banned phrase)
    passed, failures = run_validators(
        "Beta: As an AI, I must say",
        "Alpha", state, validators,
        agent_names=["Alpha", "Beta"],
    )
    assert not passed
    assert len(failures) >= 1
