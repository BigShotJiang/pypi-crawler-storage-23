"""
Tests for the WebSocketBackend client.

Tests the full stack: WebSocketBackend -> relay server -> response.
"""

import asyncio
import json
import pytest
import threading
import time

import websockets

from floorctl.backends.websocket import WebSocketBackend
from floorctl.relay.server import RelayServer
from floorctl.types import TurnData, TurnRecord


# ── Fixtures ─────────────────────────────────────────────────────────

@pytest.fixture
def relay_port():
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


@pytest.fixture
def relay(relay_port):
    """Start relay server in background, yield port."""
    server = RelayServer(api_key="testkey")
    loop = asyncio.new_event_loop()
    started = threading.Event()

    async def run():
        async with websockets.serve(server.handler, "127.0.0.1", relay_port):
            started.set()
            await asyncio.Future()

    def target():
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(run())
        except asyncio.CancelledError:
            pass

    thread = threading.Thread(target=target, daemon=True)
    thread.start()
    started.wait(timeout=5.0)
    yield relay_port
    loop.call_soon_threadsafe(loop.stop)


@pytest.fixture
def backend(relay):
    """Create and connect a WebSocketBackend."""
    b = WebSocketBackend(
        relay_url=f"ws://127.0.0.1:{relay}",
        api_key="testkey",
        agent_name="TestAgent",
    )
    b.connect(timeout=5.0)
    yield b
    b.disconnect()


# ── Tests ────────────────────────────────────────────────────────────

class TestConnection:
    def test_connect_and_disconnect(self, relay):
        b = WebSocketBackend(
            relay_url=f"ws://127.0.0.1:{relay}",
            api_key="testkey",
        )
        b.connect(timeout=5.0)
        assert b._connected.is_set()
        b.disconnect()
        assert not b._connected.is_set()

    def test_bad_api_key(self, relay):
        b = WebSocketBackend(
            relay_url=f"ws://127.0.0.1:{relay}",
            api_key="wrong",
        )
        with pytest.raises(ConnectionError):
            b.connect(timeout=3.0)


class TestSessionOps:
    def test_create_and_get_session(self, backend):
        backend.create_session("ws-s1", {
            "topic": "testing",
            "participants": ["A", "B"],
        })
        state = backend.get_session_state("ws-s1")
        assert state["topic"] == "testing"
        assert state["status"] == "WAITING"

    def test_update_session(self, backend):
        backend.create_session("ws-s2", {"topic": "t"})
        backend.update_session("ws-s2", {"status": "LIVE", "phase": "DEBATE"})
        state = backend.get_session_state("ws-s2")
        assert state["status"] == "LIVE"
        assert state["phase"] == "DEBATE"


class TestFloorControl:
    def test_claim_and_release(self, backend):
        backend.create_session("ws-fc1", {})
        assert backend.claim_floor("ws-fc1", "Alice", 30.0) is True
        backend.release_floor("ws-fc1", "Alice", True)

    def test_contention_two_backends(self, relay):
        """Two separate backends contending for the floor."""
        b1 = WebSocketBackend(f"ws://127.0.0.1:{relay}", api_key="testkey", agent_name="A")
        b2 = WebSocketBackend(f"ws://127.0.0.1:{relay}", api_key="testkey", agent_name="B")
        b1.connect(timeout=5.0)
        b2.connect(timeout=5.0)

        try:
            b1.create_session("ws-fc2", {})

            # A claims
            assert b1.claim_floor("ws-fc2", "A", 30.0) is True
            # B contends — should fail
            assert b2.claim_floor("ws-fc2", "B", 30.0) is False
            # A releases
            b1.release_floor("ws-fc2", "A", True)
            # B claims — should succeed
            assert b2.claim_floor("ws-fc2", "B", 30.0) is True
        finally:
            b1.disconnect()
            b2.disconnect()


class TestTurns:
    def test_post_and_get(self, backend):
        backend.create_session("ws-t1", {})
        turn_id = backend.post_turn("ws-t1", TurnData(
            agent_name="Alice",
            transcript="Hello!",
            timestamp="2024-01-01",
        ))
        assert turn_id != ""

        turns = backend.get_turns("ws-t1")
        assert len(turns) == 1
        assert turns[0].speaker == "Alice"
        assert turns[0].text == "Hello!"

    def test_get_turns_since_index(self, backend):
        backend.create_session("ws-t2", {})
        for i in range(3):
            backend.post_turn("ws-t2", TurnData(
                agent_name=f"Agent{i}",
                transcript=f"Turn {i}",
                timestamp="now",
            ))

        turns = backend.get_turns("ws-t2", since_index=2)
        assert len(turns) == 1
        assert turns[0].text == "Turn 2"

    def test_turn_subscription(self, relay):
        """Test that turn subscriptions work across backends."""
        b1 = WebSocketBackend(f"ws://127.0.0.1:{relay}", api_key="testkey", agent_name="A")
        b2 = WebSocketBackend(f"ws://127.0.0.1:{relay}", api_key="testkey", agent_name="B")
        b1.connect(timeout=5.0)
        b2.connect(timeout=5.0)

        received: list[TurnRecord] = []
        event = threading.Event()

        try:
            b1.create_session("ws-t3", {})

            # B subscribes to turns
            b2.subscribe_turns("ws-t3", lambda t: (received.append(t), event.set()))

            # Small delay for subscription to propagate
            time.sleep(0.3)

            # A posts a turn
            b1.post_turn("ws-t3", TurnData(
                agent_name="A",
                transcript="Hello from A!",
                timestamp="now",
            ))

            # Wait for callback
            event.wait(timeout=5.0)

            assert len(received) >= 1
            assert received[0].speaker == "A"
            assert received[0].text == "Hello from A!"
        finally:
            b1.disconnect()
            b2.disconnect()


class TestMetrics:
    def test_store_metrics(self, backend):
        backend.create_session("ws-m1", {})
        backend.store_metrics("ws-m1", "Alice", {"turns": 5})
        # No error means success (relay stores but doesn't expose via get)
