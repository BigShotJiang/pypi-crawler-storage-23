"""Tests for floor control."""

import threading
from floorctl.backends.memory import InMemoryBackend
from floorctl.floor import FloorController
from floorctl.config import FloorConfig


def test_basic_claim():
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test", "participants": ["A", "B"]})

    fc = FloorController("A", backend)
    assert fc.try_claim("s1") is True

    state = backend.get_session_state("s1")
    assert state["active_speaker"] == "A"


def test_competing_claims():
    """Only one agent should win the floor."""
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test", "participants": ["A", "B", "C"]})

    results = {}
    lock = threading.Lock()

    def claim(name):
        fc = FloorController(name, backend)
        success = fc.try_claim("s1")
        with lock:
            results[name] = success

    threads = [threading.Thread(target=claim, args=(n,)) for n in ["A", "B", "C"]]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    winners = [k for k, v in results.items() if v]
    assert len(winners) == 1, f"Expected 1 winner, got {len(winners)}: {winners}"


def test_release_and_reclaim():
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test", "participants": ["A", "B"]})

    fc_a = FloorController("A", backend)
    fc_b = FloorController("B", backend)

    assert fc_a.try_claim("s1") is True
    assert fc_b.try_claim("s1") is False  # A holds it

    fc_a.release("s1", posted_successfully=True)
    assert fc_b.try_claim("s1") is True  # Now B can claim


def test_reservation():
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test", "participants": ["A", "B"]})

    # Reserve for B
    backend.reserve_floor("s1", "B")

    fc_a = FloorController("A", backend)
    fc_b = FloorController("B", backend)

    assert fc_a.try_claim("s1") is False  # Reserved for B
    assert fc_b.try_claim("s1") is True   # B can claim


def test_streak_tracking():
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test", "participants": ["A", "B"]})

    fc_a = FloorController("A", backend)
    fc_b = FloorController("B", backend)

    # B claims first
    fc_b.try_claim("s1")

    # A tries and fails
    fc_a.try_claim("s1")
    assert fc_a.losses_streak == 1

    fc_a.try_claim("s1")
    assert fc_a.losses_streak == 2

    # Release and A succeeds
    fc_b.release("s1", True)
    fc_a.try_claim("s1")
    assert fc_a.losses_streak == 0  # Reset on success


def test_starvation_threshold_reduction():
    config = FloorConfig(starvation_streak_threshold=3, starvation_threshold_reduction=0.10)
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test", "participants": ["A", "B"]})

    fc_a = FloorController("A", backend, config)

    # Below streak threshold
    fc_a._losses_streak = 2
    assert fc_a.starvation_threshold_reduction() == 0.0

    # At streak threshold
    fc_a._losses_streak = 3
    assert fc_a.starvation_threshold_reduction() == -0.10
