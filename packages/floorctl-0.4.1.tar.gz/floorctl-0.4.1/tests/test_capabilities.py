"""Tests for the AgentCapability protocol."""

import pytest
from floorctl import (
    AgentCapability,
    AgentProfile,
    ArenaConfig,
    FloorAgent,
    InMemoryBackend,
    PhaseConfig,
    PhaseSequence,
    TurnRecord,
)


# ── Test Capabilities ────────────────────────────────────────────────

class ContextEnricherCapability(AgentCapability):
    """Adds retrieved_docs to context."""
    name = "context_enricher"

    def __init__(self):
        self.enrich_calls = 0

    def enrich_context(self, context):
        self.enrich_calls += 1
        context["retrieved_docs"] = ["doc1.txt", "doc2.txt"]
        context["enriched_by"] = self.name
        return context


class PostProcessCapability(AgentCapability):
    """Appends a tag to responses."""
    name = "post_processor"

    def __init__(self):
        self.process_calls = 0

    def post_process(self, response, context):
        self.process_calls += 1
        return response + " [processed]"


class TurnListenerCapability(AgentCapability):
    """Records all turns received."""
    name = "turn_listener"

    def __init__(self):
        self.turns_received: list[tuple[str, str]] = []

    def on_turn_received(self, turn, agent_name):
        self.turns_received.append((turn.speaker, agent_name))


class FailingCapability(AgentCapability):
    """Capability that raises errors — should not crash the agent."""
    name = "failing"

    def enrich_context(self, context):
        raise ValueError("enrich boom")

    def post_process(self, response, context):
        raise ValueError("post_process boom")

    def on_turn_received(self, turn, agent_name):
        raise ValueError("on_turn boom")


class ChainingCapability(AgentCapability):
    """Adds a marker to context to verify chaining order."""
    name = "chainer"

    def __init__(self, marker: str):
        self.name = f"chainer_{marker}"
        self.marker = marker

    def enrich_context(self, context):
        markers = context.get("chain_markers", [])
        markers.append(self.marker)
        context["chain_markers"] = markers
        return context


# ── Fixtures ─────────────────────────────────────────────────────────

@pytest.fixture
def backend():
    return InMemoryBackend()


@pytest.fixture
def simple_config():
    return ArenaConfig(
        phases=PhaseSequence(phases=[
            PhaseConfig(name="DISCUSS", max_turns=8, min_words=3, max_words=50),
            PhaseConfig(name="CLOSING", is_terminal=True),
        ]),
        max_total_turns=10,
    )


@pytest.fixture
def profile():
    return AgentProfile(
        name="TestAgent",
        personality="Test personality",
        react_to=["test"],
        temperament="reactive",
    )


@pytest.fixture
def dummy_generate():
    def gen(agent_name, context):
        return f"{agent_name}: Response about {context.get('topic', '?')}."
    return gen


# ── Tests: AgentCapability base class ────────────────────────────────

class TestAgentCapabilityBase:
    def test_default_name(self):
        cap = AgentCapability()
        assert cap.name == "base"

    def test_enrich_context_passthrough(self):
        cap = AgentCapability()
        ctx = {"topic": "AI"}
        result = cap.enrich_context(ctx)
        assert result is ctx
        assert result["topic"] == "AI"

    def test_post_process_passthrough(self):
        cap = AgentCapability()
        result = cap.post_process("hello", {})
        assert result == "hello"

    def test_on_turn_received_noop(self):
        cap = AgentCapability()
        turn = TurnRecord(speaker="X", text="hi", phase="A", turn_index=0)
        cap.on_turn_received(turn, "Y")  # should not raise


# ── Tests: Adding capabilities to FloorAgent ─────────────────────────

class TestCapabilityAttachment:
    def test_init_with_capabilities(self, backend, profile, dummy_generate, simple_config):
        cap = ContextEnricherCapability()
        agent = FloorAgent(
            name="TestAgent",
            profile=profile,
            generate_fn=dummy_generate,
            backend=backend,
            config=simple_config,
            capabilities=[cap],
        )
        assert len(agent.capabilities) == 1
        assert agent.capabilities[0] is cap

    def test_add_capability(self, backend, profile, dummy_generate, simple_config):
        agent = FloorAgent(
            name="TestAgent",
            profile=profile,
            generate_fn=dummy_generate,
            backend=backend,
            config=simple_config,
        )
        assert len(agent.capabilities) == 0

        cap = ContextEnricherCapability()
        agent.add_capability(cap)
        assert len(agent.capabilities) == 1
        assert agent.capabilities[0] is cap

    def test_multiple_capabilities(self, backend, profile, dummy_generate, simple_config):
        cap1 = ContextEnricherCapability()
        cap2 = PostProcessCapability()
        cap3 = TurnListenerCapability()

        agent = FloorAgent(
            name="TestAgent",
            profile=profile,
            generate_fn=dummy_generate,
            backend=backend,
            config=simple_config,
            capabilities=[cap1],
        )
        agent.add_capability(cap2)
        agent.add_capability(cap3)
        assert len(agent.capabilities) == 3

    def test_no_capabilities_by_default(self, backend, profile, dummy_generate, simple_config):
        agent = FloorAgent(
            name="TestAgent",
            profile=profile,
            generate_fn=dummy_generate,
            backend=backend,
            config=simple_config,
        )
        assert agent.capabilities == []


# ── Tests: enrich_context integration ────────────────────────────────

class TestEnrichContext:
    def test_enrich_context_called(self, backend, profile, dummy_generate, simple_config):
        cap = ContextEnricherCapability()
        agent = FloorAgent(
            name="TestAgent",
            profile=profile,
            generate_fn=dummy_generate,
            backend=backend,
            config=simple_config,
            capabilities=[cap],
        )
        agent.state.topic = "AI Safety"
        agent.state.phase = "DISCUSS"

        ctx = agent._build_context()
        assert cap.enrich_calls == 1
        assert ctx["retrieved_docs"] == ["doc1.txt", "doc2.txt"]
        assert ctx["enriched_by"] == "context_enricher"
        # Original context fields preserved
        assert ctx["topic"] == "AI Safety"

    def test_chaining_order(self, backend, profile, dummy_generate, simple_config):
        cap_a = ChainingCapability("A")
        cap_b = ChainingCapability("B")
        cap_c = ChainingCapability("C")

        agent = FloorAgent(
            name="TestAgent",
            profile=profile,
            generate_fn=dummy_generate,
            backend=backend,
            config=simple_config,
            capabilities=[cap_a, cap_b, cap_c],
        )
        agent.state.topic = "test"
        agent.state.phase = "DISCUSS"

        ctx = agent._build_context()
        assert ctx["chain_markers"] == ["A", "B", "C"]


# ── Tests: post_process integration ──────────────────────────────────

class TestPostProcess:
    def test_post_process_called(self, backend, profile, simple_config):
        cap = PostProcessCapability()

        def gen(name, ctx):
            return f"{name}: Original response."

        agent = FloorAgent(
            name="TestAgent",
            profile=profile,
            generate_fn=gen,
            backend=backend,
            config=simple_config,
            capabilities=[cap],
        )
        agent.state.topic = "test"
        agent.state.phase = "DISCUSS"

        result = agent._generate_response()
        assert result is not None
        assert result.endswith(" [processed]")
        assert cap.process_calls >= 1


# ── Tests: on_turn_received integration ──────────────────────────────

class TestOnTurnReceived:
    def test_on_turn_received_fires(self, backend, profile, dummy_generate, simple_config):
        cap = TurnListenerCapability()
        agent = FloorAgent(
            name="TestAgent",
            profile=profile,
            generate_fn=dummy_generate,
            backend=backend,
            config=simple_config,
            capabilities=[cap],
        )
        agent._session_id = "test-session"
        backend.create_session("test-session", {
            "topic": "test",
            "phase": "DISCUSS",
            "participants": ["TestAgent", "Other"],
        })
        agent._is_running = True

        turn = TurnRecord(
            speaker="Other", text="Hello", phase="DISCUSS", turn_index=0
        )
        # Simulate — call _on_new_turn directly
        agent._on_new_turn(turn)

        assert len(cap.turns_received) == 1
        assert cap.turns_received[0] == ("Other", "TestAgent")

    def test_on_turn_received_fires_for_own_turns(self, backend, profile, dummy_generate, simple_config):
        """on_turn_received fires for ALL turns including own."""
        cap = TurnListenerCapability()
        agent = FloorAgent(
            name="TestAgent",
            profile=profile,
            generate_fn=dummy_generate,
            backend=backend,
            config=simple_config,
            capabilities=[cap],
        )
        agent._session_id = "test-session"
        backend.create_session("test-session", {
            "topic": "test",
            "phase": "DISCUSS",
            "participants": ["TestAgent"],
        })

        own_turn = TurnRecord(
            speaker="TestAgent", text="My turn", phase="DISCUSS", turn_index=0
        )
        agent._on_new_turn(own_turn)

        # Capability sees the turn even though agent doesn't react to its own
        assert len(cap.turns_received) == 1
        assert cap.turns_received[0] == ("TestAgent", "TestAgent")


# ── Tests: Error resilience ──────────────────────────────────────────

class TestCapabilityErrorResilience:
    def test_failing_enrich_context_does_not_crash(self, backend, profile, dummy_generate, simple_config):
        failing = FailingCapability()
        good = ContextEnricherCapability()

        agent = FloorAgent(
            name="TestAgent",
            profile=profile,
            generate_fn=dummy_generate,
            backend=backend,
            config=simple_config,
            capabilities=[failing, good],
        )
        agent.state.topic = "test"
        agent.state.phase = "DISCUSS"

        # Should not raise — failing cap is skipped, good cap still runs
        ctx = agent._build_context()
        assert good.enrich_calls == 1
        assert ctx["retrieved_docs"] == ["doc1.txt", "doc2.txt"]

    def test_failing_post_process_does_not_crash(self, backend, profile, simple_config):
        failing = FailingCapability()

        def gen(name, ctx):
            return f"{name}: Response."

        agent = FloorAgent(
            name="TestAgent",
            profile=profile,
            generate_fn=gen,
            backend=backend,
            config=simple_config,
            capabilities=[failing],
        )
        agent.state.topic = "test"
        agent.state.phase = "DISCUSS"

        # Should not raise — failing post_process is skipped
        result = agent._generate_response()
        assert result is not None

    def test_failing_on_turn_received_does_not_crash(self, backend, profile, dummy_generate, simple_config):
        failing = FailingCapability()
        good = TurnListenerCapability()

        agent = FloorAgent(
            name="TestAgent",
            profile=profile,
            generate_fn=dummy_generate,
            backend=backend,
            config=simple_config,
            capabilities=[failing, good],
        )
        agent._session_id = "test-session"
        backend.create_session("test-session", {
            "topic": "test",
            "phase": "DISCUSS",
            "participants": ["TestAgent", "Other"],
        })

        turn = TurnRecord(
            speaker="Other", text="Hello", phase="DISCUSS", turn_index=0
        )
        # Should not raise — failing cap is skipped, good cap still fires
        agent._on_new_turn(turn)
        assert len(good.turns_received) == 1
