"""Tests for the Consensus Protocol — quorum-based voting with veto power."""

import pytest

from floorctl.consensus import (
    ConsensusConfig,
    ConsensusProtocol,
    ConsensusResult,
    ProposalStatus,
    QuorumRule,
    VoteChoice,
)


# ── Fixtures ─────────────────────────────────────────────────────────

@pytest.fixture
def majority_protocol() -> ConsensusProtocol:
    return ConsensusProtocol(ConsensusConfig(quorum_rule=QuorumRule.MAJORITY))


@pytest.fixture
def veto_protocol() -> ConsensusProtocol:
    return ConsensusProtocol(ConsensusConfig(
        quorum_rule=QuorumRule.MAJORITY,
        veto_agents=["ComplianceOfficer"],
    ))


@pytest.fixture
def supermajority_protocol() -> ConsensusProtocol:
    return ConsensusProtocol(ConsensusConfig(quorum_rule=QuorumRule.SUPERMAJORITY))


@pytest.fixture
def unanimity_protocol() -> ConsensusProtocol:
    return ConsensusProtocol(ConsensusConfig(quorum_rule=QuorumRule.UNANIMITY))


# ── Proposal Tests ───────────────────────────────────────────────────

def test_create_proposal(majority_protocol: ConsensusProtocol) -> None:
    pid = majority_protocol.propose(
        proposer="Architect",
        title="Use PostgreSQL",
        description="For persistence layer",
    )
    assert pid.startswith("prop-")
    proposal = majority_protocol.get_proposal(pid)
    assert proposal is not None
    assert proposal.title == "Use PostgreSQL"
    assert proposal.proposer == "Architect"
    assert proposal.status == ProposalStatus.OPEN


def test_proposal_with_artifact_link(majority_protocol: ConsensusProtocol) -> None:
    pid = majority_protocol.propose(
        proposer="Architect",
        title="ADR-001",
        artifact_id="adr-001",
    )
    proposal = majority_protocol.get_proposal(pid)
    assert proposal is not None
    assert proposal.artifact_id == "adr-001"


# ── Voting Tests ─────────────────────────────────────────────────────

def test_basic_voting(majority_protocol: ConsensusProtocol) -> None:
    pid = majority_protocol.propose("A", "Test Proposal")
    vote = majority_protocol.vote(pid, "B", VoteChoice.APPROVE, reason="Looks good")
    assert vote.voter == "B"
    assert vote.choice == VoteChoice.APPROVE
    assert vote.reason == "Looks good"


def test_vote_on_nonexistent_raises(majority_protocol: ConsensusProtocol) -> None:
    with pytest.raises(ValueError, match="not found"):
        majority_protocol.vote("nope", "A", VoteChoice.APPROVE)


def test_veto_only_for_designated(veto_protocol: ConsensusProtocol) -> None:
    pid = veto_protocol.propose("Architect", "Risky Proposal")
    # ComplianceOfficer can veto
    veto_protocol.vote(pid, "ComplianceOfficer", VoteChoice.VETO, reason="Non-compliant")
    # Regular agent cannot veto
    pid2 = veto_protocol.propose("A", "Another Proposal")
    with pytest.raises(ValueError, match="does not have veto power"):
        veto_protocol.vote(pid2, "DevLead", VoteChoice.VETO)


def test_vote_on_resolved_raises(majority_protocol: ConsensusProtocol) -> None:
    pid = majority_protocol.propose("A", "Test")
    majority_protocol.vote(pid, "B", VoteChoice.APPROVE)
    majority_protocol.vote(pid, "C", VoteChoice.APPROVE)
    majority_protocol.resolve(pid, eligible_voters=3)
    with pytest.raises(ValueError, match="already"):
        majority_protocol.vote(pid, "D", VoteChoice.APPROVE)


# ── Resolution Tests: Majority ──────────────────────────────────────

def test_majority_passes(majority_protocol: ConsensusProtocol) -> None:
    pid = majority_protocol.propose("A", "Test")
    majority_protocol.vote(pid, "B", VoteChoice.APPROVE)
    majority_protocol.vote(pid, "C", VoteChoice.APPROVE)
    majority_protocol.vote(pid, "D", VoteChoice.REJECT)
    result = majority_protocol.resolve(pid, eligible_voters=4)
    assert result.status == ProposalStatus.PASSED
    assert result.quorum_met is True
    assert result.approval_rate == pytest.approx(0.6667, abs=0.01)


def test_majority_fails_insufficient_votes(majority_protocol: ConsensusProtocol) -> None:
    pid = majority_protocol.propose("A", "Test")
    majority_protocol.vote(pid, "B", VoteChoice.APPROVE)
    # Only 1 vote out of 4 eligible — quorum not met
    result = majority_protocol.resolve(pid, eligible_voters=4)
    assert result.quorum_met is False
    assert result.status == ProposalStatus.REJECTED


def test_majority_fails_more_rejections(majority_protocol: ConsensusProtocol) -> None:
    pid = majority_protocol.propose("A", "Test")
    majority_protocol.vote(pid, "B", VoteChoice.APPROVE)
    majority_protocol.vote(pid, "C", VoteChoice.REJECT)
    majority_protocol.vote(pid, "D", VoteChoice.REJECT)
    result = majority_protocol.resolve(pid, eligible_voters=4)
    # Quorum met (3 votes > 2), but approval rate < 50%
    assert result.status == ProposalStatus.REJECTED


# ── Resolution Tests: Supermajority ─────────────────────────────────

def test_supermajority_passes(supermajority_protocol: ConsensusProtocol) -> None:
    pid = supermajority_protocol.propose("A", "Test")
    supermajority_protocol.vote(pid, "B", VoteChoice.APPROVE)
    supermajority_protocol.vote(pid, "C", VoteChoice.APPROVE)
    supermajority_protocol.vote(pid, "D", VoteChoice.APPROVE)
    # 3 approvals out of 4 eligible = 75% >= 66.7%
    result = supermajority_protocol.resolve(pid, eligible_voters=4)
    assert result.status == ProposalStatus.PASSED
    assert result.quorum_met is True


def test_supermajority_fails(supermajority_protocol: ConsensusProtocol) -> None:
    pid = supermajority_protocol.propose("A", "Test")
    supermajority_protocol.vote(pid, "B", VoteChoice.APPROVE)
    supermajority_protocol.vote(pid, "C", VoteChoice.REJECT)
    supermajority_protocol.vote(pid, "D", VoteChoice.REJECT)
    # 1 approval out of 4 < 2/3
    result = supermajority_protocol.resolve(pid, eligible_voters=4)
    assert result.quorum_met is False


# ── Resolution Tests: Unanimity ─────────────────────────────────────

def test_unanimity_passes(unanimity_protocol: ConsensusProtocol) -> None:
    pid = unanimity_protocol.propose("A", "Test")
    unanimity_protocol.vote(pid, "A", VoteChoice.APPROVE)
    unanimity_protocol.vote(pid, "B", VoteChoice.APPROVE)
    unanimity_protocol.vote(pid, "C", VoteChoice.APPROVE)
    result = unanimity_protocol.resolve(pid, eligible_voters=3)
    assert result.status == ProposalStatus.PASSED
    assert result.quorum_met is True


def test_unanimity_fails_with_one_reject(unanimity_protocol: ConsensusProtocol) -> None:
    pid = unanimity_protocol.propose("A", "Test")
    unanimity_protocol.vote(pid, "A", VoteChoice.APPROVE)
    unanimity_protocol.vote(pid, "B", VoteChoice.APPROVE)
    unanimity_protocol.vote(pid, "C", VoteChoice.REJECT)
    result = unanimity_protocol.resolve(pid, eligible_voters=3)
    assert result.quorum_met is False


# ── Veto Tests ──────────────────────────────────────────────────────

def test_veto_blocks_even_with_majority(veto_protocol: ConsensusProtocol) -> None:
    pid = veto_protocol.propose("Architect", "Deploy to prod")
    veto_protocol.vote(pid, "DevLead", VoteChoice.APPROVE)
    veto_protocol.vote(pid, "QA", VoteChoice.APPROVE)
    veto_protocol.vote(pid, "ComplianceOfficer", VoteChoice.VETO, reason="Missing audit")
    result = veto_protocol.resolve(pid, eligible_voters=4)
    assert result.status == ProposalStatus.VETOED
    assert result.vetoed_by == "ComplianceOfficer"


# ── Abstention Tests ────────────────────────────────────────────────

def test_abstentions_dont_count_toward_quorum(majority_protocol: ConsensusProtocol) -> None:
    pid = majority_protocol.propose("A", "Test")
    majority_protocol.vote(pid, "B", VoteChoice.APPROVE)
    majority_protocol.vote(pid, "C", VoteChoice.APPROVE)
    majority_protocol.vote(pid, "D", VoteChoice.ABSTAIN)
    # 2 non-abstain votes > 2 (half of 4) — quorum met
    result = majority_protocol.resolve(pid, eligible_voters=4)
    assert result.status == ProposalStatus.PASSED
    assert result.approval_rate == 1.0  # 2/2 non-abstain


# ── Query Tests ──────────────────────────────────────────────────────

def test_list_proposals_by_status(majority_protocol: ConsensusProtocol) -> None:
    pid1 = majority_protocol.propose("A", "Proposal 1")
    pid2 = majority_protocol.propose("B", "Proposal 2")
    majority_protocol.vote(pid1, "C", VoteChoice.APPROVE)
    majority_protocol.vote(pid1, "D", VoteChoice.APPROVE)
    majority_protocol.resolve(pid1, eligible_voters=3)

    open_proposals = majority_protocol.list_proposals(status=ProposalStatus.OPEN)
    assert len(open_proposals) == 1
    assert open_proposals[0].proposal_id == pid2


def test_vote_counts(majority_protocol: ConsensusProtocol) -> None:
    pid = majority_protocol.propose("A", "Test")
    majority_protocol.vote(pid, "B", VoteChoice.APPROVE)
    majority_protocol.vote(pid, "C", VoteChoice.REJECT)
    majority_protocol.vote(pid, "D", VoteChoice.ABSTAIN)
    proposal = majority_protocol.get_proposal(pid)
    assert proposal is not None
    counts = proposal.vote_counts
    assert counts["approve"] == 1
    assert counts["reject"] == 1
    assert counts["abstain"] == 1


# ── Subscription Tests ──────────────────────────────────────────────

def test_subscribe_to_events(majority_protocol: ConsensusProtocol) -> None:
    events: list[str] = []
    majority_protocol.subscribe(lambda event, prop: events.append(event))

    pid = majority_protocol.propose("A", "Test")
    majority_protocol.vote(pid, "B", VoteChoice.APPROVE)
    majority_protocol.vote(pid, "C", VoteChoice.APPROVE)
    majority_protocol.resolve(pid, eligible_voters=3)

    assert events == ["proposed", "voted", "voted", "resolved"]


# ── Summary Tests ────────────────────────────────────────────────────

def test_summary(majority_protocol: ConsensusProtocol) -> None:
    pid = majority_protocol.propose("A", "Test")
    majority_protocol.vote(pid, "B", VoteChoice.APPROVE)
    majority_protocol.vote(pid, "C", VoteChoice.APPROVE)
    majority_protocol.resolve(pid, eligible_voters=3)

    summary = majority_protocol.summary()
    assert summary["total_proposals"] == 1
    assert summary["by_status"]["passed"] == 1
    assert summary["total_vetoes"] == 0


# ── Context Tests ────────────────────────────────────────────────────

def test_to_context_only_open(majority_protocol: ConsensusProtocol) -> None:
    pid1 = majority_protocol.propose("A", "Open One")
    pid2 = majority_protocol.propose("B", "Open Two")
    majority_protocol.vote(pid1, "C", VoteChoice.APPROVE)
    majority_protocol.vote(pid1, "D", VoteChoice.APPROVE)
    majority_protocol.resolve(pid1, eligible_voters=3)

    ctx = majority_protocol.to_context()
    assert len(ctx) == 1
    assert ctx[0]["title"] == "Open Two"


# ── Custom Threshold Tests ──────────────────────────────────────────

def test_custom_threshold() -> None:
    protocol = ConsensusProtocol(ConsensusConfig(
        quorum_rule=QuorumRule.THRESHOLD,
        custom_threshold=0.75,
    ))
    pid = protocol.propose("A", "Need 75%")
    protocol.vote(pid, "B", VoteChoice.APPROVE)
    protocol.vote(pid, "C", VoteChoice.APPROVE)
    protocol.vote(pid, "D", VoteChoice.APPROVE)
    # 3 approvals out of 4 = 75% >= 75%
    result = protocol.resolve(pid, eligible_voters=4)
    assert result.quorum_met is True
    assert result.status == ProposalStatus.PASSED


# ── Require Reason Tests ────────────────────────────────────────────

def test_require_reason() -> None:
    protocol = ConsensusProtocol(ConsensusConfig(require_reason=True))
    pid = protocol.propose("A", "Test")
    with pytest.raises(ValueError, match="reason is required"):
        protocol.vote(pid, "B", VoteChoice.APPROVE)
    # Should work with reason
    protocol.vote(pid, "B", VoteChoice.APPROVE, reason="Makes sense")
    # Abstain doesn't need reason
    protocol.vote(pid, "C", VoteChoice.ABSTAIN)
