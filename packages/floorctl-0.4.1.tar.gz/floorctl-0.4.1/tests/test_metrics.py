"""Tests for metrics collectors."""

import threading
from floorctl.metrics import AgentMetrics, SessionMetrics


def test_agent_metrics_basic():
    m = AgentMetrics("Alpha", "s1")

    m.record_floor_claim(success=True)
    m.record_floor_claim(success=False)
    m.record_floor_claim(success=False)
    m.record_turn_posted("DISCUSSION")
    m.record_generation_time(1.5)

    d = m.to_dict()
    assert d["agent_name"] == "Alpha"
    assert d["floor"]["claims_attempted"] == 3
    assert d["floor"]["claims_won"] == 1
    assert d["floor"]["claims_lost"] == 2
    assert d["participation"]["turns_posted"] == 1
    assert d["generation"]["avg_time_seconds"] == 1.5


def test_agent_metrics_thread_safety():
    m = AgentMetrics("Alpha", "s1")

    def record_claims(n):
        for _ in range(n):
            m.record_floor_claim(success=True)

    threads = [threading.Thread(target=record_claims, args=(100,)) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert m.floor_claims_attempted == 1000
    assert m.floor_claims_won == 1000


def test_session_metrics_gini_balanced():
    m = SessionMetrics("s1", ["A", "B", "C"])

    # Perfectly balanced: 5 turns each
    for agent in ["A", "B", "C"]:
        for _ in range(5):
            m.record_turn(agent, is_moderator=False, phase="DISCUSSION")

    assert m.gini_coefficient == 0.0


def test_session_metrics_gini_imbalanced():
    m = SessionMetrics("s1", ["A", "B", "C"])

    # Heavily imbalanced: A speaks 10, B speaks 1, C speaks 0
    for _ in range(10):
        m.record_turn("A", is_moderator=False, phase="DISCUSSION")
    m.record_turn("B", is_moderator=False, phase="DISCUSSION")

    gini = m.gini_coefficient
    assert gini > 0.5  # Highly imbalanced


def test_session_metrics_intervention():
    m = SessionMetrics("s1", ["A", "B"])

    m.record_intervention("escalation", "A", "DISCUSSION", "heated argument")
    m.record_intervention("silence", "B", "DISCUSSION", "quiet for 6 turns")

    d = m.to_dict()
    assert d["interventions"]["total"] == 2
    assert d["interventions"]["by_type"]["escalation"] == 1
    assert d["interventions"]["by_type"]["silence"] == 1


def test_session_metrics_phase_tracking():
    m = SessionMetrics("s1", ["A", "B"])

    m.record_phase_start("OPENING")
    m.record_turn("A", False, "OPENING")
    m.record_turn("B", False, "OPENING")
    m.record_phase_end("OPENING")

    d = m.to_dict()
    assert "OPENING" in d["phases"]["durations_seconds"]
    assert d["phases"]["turn_counts"]["OPENING"] == 2


def test_agent_metrics_validation():
    m = AgentMetrics("Alpha", "s1")

    m.record_validation(passed=True)
    m.record_validation(passed=False, failure_types=["Length", "Contract"])
    m.record_validation(passed=True)

    d = m.to_dict()
    assert d["validation"]["total_attempts"] == 3
    assert d["validation"]["passes"] == 2
    assert d["validation"]["failures"] == 1
    assert d["validation"]["failure_types"]["Length"] == 1


def test_agent_metrics_to_json():
    m = AgentMetrics("Alpha", "s1")
    m.record_turn_posted("DISCUSSION")

    json_str = m.to_json()
    assert "Alpha" in json_str
    assert "DISCUSSION" in json_str
