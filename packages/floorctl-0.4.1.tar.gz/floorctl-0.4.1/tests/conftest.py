"""Shared fixtures for floorctl tests."""

import pytest
from floorctl import (
    AgentProfile,
    ArenaConfig,
    FloorAgent,
    InMemoryBackend,
    PhaseConfig,
    PhaseSequence,
)


@pytest.fixture
def backend():
    return InMemoryBackend()


@pytest.fixture
def dummy_generate():
    """Simple generate function that returns predictable responses."""
    def gen(agent_name: str, context: dict) -> str:
        topic = context.get("topic", "unknown")
        phase = context.get("phase", "unknown")
        return f"{agent_name}: My thoughts on {topic} during {phase}."
    return gen


@pytest.fixture
def simple_phases():
    return PhaseSequence(phases=[
        PhaseConfig(name="OPENING", is_opening=True, max_turns=4, max_words=80, min_words=5, max_sentences=2, allow_critiques=False),
        PhaseConfig(name="DISCUSSION", min_turns=4, max_turns=10),
        PhaseConfig(name="CLOSING", is_terminal=True, max_turns=0),
    ])


@pytest.fixture
def simple_config(simple_phases):
    return ArenaConfig(
        phases=simple_phases,
        max_total_turns=20,
        max_self_retries=1,
    )


@pytest.fixture
def alpha_profile():
    return AgentProfile(
        name="Alpha",
        personality="Bold and decisive",
        react_to=["problem", "risk", "challenge"],
        temperament="reactive",
        base_cooldown=5.0,
        urgency_boost_keywords=["critical", "urgent"],
    )


@pytest.fixture
def beta_profile():
    return AgentProfile(
        name="Beta",
        personality="Cautious and analytical",
        react_to=["opportunity", "vision", "future"],
        temperament="deliberate",
        base_cooldown=8.0,
        urgency_boost_keywords=["trend", "data"],
    )


@pytest.fixture
def sample_agents(backend, dummy_generate, alpha_profile, beta_profile, simple_config):
    return [
        FloorAgent(
            name="Alpha",
            profile=alpha_profile,
            generate_fn=dummy_generate,
            backend=backend,
            config=simple_config,
        ),
        FloorAgent(
            name="Beta",
            profile=beta_profile,
            generate_fn=dummy_generate,
            backend=backend,
            config=simple_config,
        ),
    ]
