"""Tests for the Conviction Tracker — position tracking with evidence-based drift."""

import pytest

from floorctl.conviction import (
    ConvictionTracker,
    EvidenceType,
    DriftDirection,
    _default_drift_fn,
)


# ── Fixtures ─────────────────────────────────────────────────────────

@pytest.fixture
def tracker() -> ConvictionTracker:
    return ConvictionTracker()


# ── Registration Tests ──────────────────────────────────────────────

def test_register_agent(tracker: ConvictionTracker) -> None:
    tracker.register("Architect", "use-postgres", initial=0.8)
    conviction = tracker.get_conviction("Architect", "use-postgres")
    assert conviction == 0.8


def test_register_clamps_values(tracker: ConvictionTracker) -> None:
    tracker.register("A", "pos1", initial=1.5)  # Clamped to 0.95
    tracker.register("B", "pos1", initial=-0.5)  # Clamped to 0.05
    assert tracker.get_conviction("A", "pos1") == 0.95
    assert tracker.get_conviction("B", "pos1") == 0.05


def test_get_unregistered_returns_none(tracker: ConvictionTracker) -> None:
    assert tracker.get_conviction("Nobody", "nothing") is None


# ── Drift Function Tests ────────────────────────────────────────────

def test_counter_argument_reduces_conviction() -> None:
    result = _default_drift_fn(0.8, EvidenceType.COUNTER_ARGUMENT, strength=0.7)
    assert result < 0.8
    assert result > 0.05  # Doesn't go to zero


def test_supporting_evidence_increases_conviction() -> None:
    result = _default_drift_fn(0.5, EvidenceType.SUPPORTING, strength=0.7)
    assert result > 0.5


def test_strong_evidence_bigger_drift_than_weak() -> None:
    strong = _default_drift_fn(0.8, EvidenceType.COUNTER_ARGUMENT, strength=0.9)
    weak = _default_drift_fn(0.8, EvidenceType.COUNTER_ARGUMENT, strength=0.2)
    # Strong evidence should cause MORE drift (lower result)
    assert strong < weak


def test_diminishing_returns_near_extremes() -> None:
    # Supporting evidence when already at 0.9 should move very little
    high = _default_drift_fn(0.9, EvidenceType.SUPPORTING, strength=0.7)
    mid = _default_drift_fn(0.5, EvidenceType.SUPPORTING, strength=0.7)
    # Mid should drift more than high
    drift_high = high - 0.9
    drift_mid = mid - 0.5
    assert drift_mid > drift_high


def test_concession_weakens_conviction() -> None:
    result = _default_drift_fn(0.7, EvidenceType.CONCESSION, strength=0.5)
    assert result < 0.7


def test_rebuttal_strengthens_conviction() -> None:
    result = _default_drift_fn(0.5, EvidenceType.REBUTTAL, strength=0.6)
    assert result > 0.5


# ── Evidence Recording Tests ────────────────────────────────────────

def test_record_evidence_updates_conviction(tracker: ConvictionTracker) -> None:
    tracker.register("Architect", "use-postgres", initial=0.8)
    event = tracker.record_evidence(
        "Architect", "use-postgres",
        evidence_type=EvidenceType.COUNTER_ARGUMENT,
        source="SecurityLead",
        strength=0.7,
        description="Encryption at rest not native",
    )
    assert event.conviction_before == 0.8
    assert event.conviction_after < 0.8
    assert event.drift < 0
    assert tracker.get_conviction("Architect", "use-postgres") == event.conviction_after


def test_multiple_evidence_events(tracker: ConvictionTracker) -> None:
    tracker.register("Architect", "use-postgres", initial=0.8)
    # Counter argument
    tracker.record_evidence(
        "Architect", "use-postgres",
        EvidenceType.COUNTER_ARGUMENT, "Security", 0.7,
    )
    after_counter = tracker.get_conviction("Architect", "use-postgres")
    assert after_counter is not None
    assert after_counter < 0.8

    # Supporting evidence
    tracker.record_evidence(
        "Architect", "use-postgres",
        EvidenceType.SUPPORTING, "DevLead", 0.5,
    )
    after_support = tracker.get_conviction("Architect", "use-postgres")
    assert after_support is not None
    assert after_support > after_counter


def test_evidence_on_unregistered_raises(tracker: ConvictionTracker) -> None:
    with pytest.raises(ValueError, match="not registered"):
        tracker.record_evidence(
            "Nobody", "nothing",
            EvidenceType.SUPPORTING, "A", 0.5,
        )


def test_evidence_history_tracked(tracker: ConvictionTracker) -> None:
    tracker.register("A", "pos1", initial=0.5)
    tracker.record_evidence("A", "pos1", EvidenceType.SUPPORTING, "B", 0.6)
    tracker.record_evidence("A", "pos1", EvidenceType.COUNTER_ARGUMENT, "C", 0.4)

    events = tracker.get_events(agent="A", position="pos1")
    assert len(events) == 2
    assert events[0].evidence_type == EvidenceType.SUPPORTING
    assert events[1].evidence_type == EvidenceType.COUNTER_ARGUMENT


def test_position_state_tracks_drift(tracker: ConvictionTracker) -> None:
    tracker.register("A", "pos1", initial=0.7)
    tracker.record_evidence("A", "pos1", EvidenceType.COUNTER_ARGUMENT, "B", 0.8)
    state = tracker.get_state("A", "pos1")
    assert state is not None
    assert state.initial_conviction == 0.7
    assert state.evidence_count == 1
    assert state.total_drift > 0
    assert state.net_drift < 0
    assert len(state.history) == 2  # initial + after evidence


# ── Analysis Tests ──────────────────────────────────────────────────

def test_detect_entrenchment(tracker: ConvictionTracker) -> None:
    # Low entrenchment threshold for testing
    tracker._entrenchment_threshold = 0.02
    tracker.register("Stubborn", "topic", initial=0.8)
    # Weak evidence that barely moves conviction
    tracker.record_evidence("Stubborn", "topic", EvidenceType.COUNTER_ARGUMENT, "B", 0.05)
    tracker.record_evidence("Stubborn", "topic", EvidenceType.COUNTER_ARGUMENT, "C", 0.05)

    entrenched = tracker.detect_entrenchment("topic")
    assert "Stubborn" in entrenched


def test_detect_convergence(tracker: ConvictionTracker) -> None:
    tracker.register("A", "topic", initial=0.6)
    tracker.register("B", "topic", initial=0.65)
    tracker.register("C", "topic", initial=0.55)
    # Spread is 0.1, threshold is 0.15
    assert tracker.detect_convergence("topic") is True


def test_no_convergence_when_spread_high(tracker: ConvictionTracker) -> None:
    tracker.register("A", "topic", initial=0.2)
    tracker.register("B", "topic", initial=0.9)
    assert tracker.detect_convergence("topic") is False


def test_detect_polarization(tracker: ConvictionTracker) -> None:
    tracker.register("A", "topic", initial=0.1)
    tracker.register("B", "topic", initial=0.9)
    polarization = tracker.detect_polarization("topic")
    assert polarization > 0.5  # Highly polarized


def test_low_polarization(tracker: ConvictionTracker) -> None:
    tracker.register("A", "topic", initial=0.5)
    tracker.register("B", "topic", initial=0.55)
    tracker.register("C", "topic", initial=0.48)
    polarization = tracker.detect_polarization("topic")
    assert polarization < 0.2


def test_biggest_movers(tracker: ConvictionTracker) -> None:
    tracker.register("A", "topic", initial=0.5)
    tracker.register("B", "topic", initial=0.5)
    # A gets strong counter argument
    tracker.record_evidence("A", "topic", EvidenceType.COUNTER_ARGUMENT, "X", 0.9)
    # B gets weak evidence
    tracker.record_evidence("B", "topic", EvidenceType.COUNTER_ARGUMENT, "Y", 0.1)

    movers = tracker.biggest_movers("topic")
    assert movers[0][0] == "A"  # A moved more
    assert abs(movers[0][1]) > abs(movers[1][1])


# ── Snapshot Tests ──────────────────────────────────────────────────

def test_snapshot(tracker: ConvictionTracker) -> None:
    tracker.register("A", "pos1", initial=0.7)
    tracker.register("B", "pos1", initial=0.3)
    tracker.register("A", "pos2", initial=0.5)

    snap = tracker.snapshot()
    assert "pos1" in snap.positions
    assert "pos2" in snap.positions
    assert snap.positions["pos1"]["A"] == 0.7
    assert snap.positions["pos1"]["B"] == 0.3


# ── Subscription Tests ──────────────────────────────────────────────

def test_subscribe_to_evidence(tracker: ConvictionTracker) -> None:
    events_received: list[float] = []
    tracker.subscribe(lambda e: events_received.append(e.drift))

    tracker.register("A", "topic", initial=0.6)
    tracker.record_evidence("A", "topic", EvidenceType.COUNTER_ARGUMENT, "B", 0.5)

    assert len(events_received) == 1
    assert events_received[0] < 0  # Drift should be negative


# ── All Convictions Query ────────────────────────────────────────────

def test_get_all_convictions(tracker: ConvictionTracker) -> None:
    tracker.register("A", "topic", initial=0.3)
    tracker.register("B", "topic", initial=0.7)
    tracker.register("C", "topic", initial=0.5)

    all_conv = tracker.get_all_convictions("topic")
    assert all_conv == {"A": 0.3, "B": 0.7, "C": 0.5}


# ── Context Tests ────────────────────────────────────────────────────

def test_to_context_single_position(tracker: ConvictionTracker) -> None:
    tracker.register("A", "topic", initial=0.7)
    tracker.register("B", "topic", initial=0.3)

    ctx = tracker.to_context("topic")
    assert ctx["position"] == "topic"
    assert "A" in ctx["agents"]
    assert "converging" in ctx
    assert "polarization" in ctx


def test_to_context_all_positions(tracker: ConvictionTracker) -> None:
    tracker.register("A", "pos1", initial=0.7)
    tracker.register("A", "pos2", initial=0.4)

    ctx = tracker.to_context()
    assert "pos1" in ctx
    assert "pos2" in ctx


# ── Summary Tests ────────────────────────────────────────────────────

def test_summary(tracker: ConvictionTracker) -> None:
    tracker.register("A", "pos1", initial=0.7)
    tracker.register("B", "pos1", initial=0.3)
    tracker.record_evidence("A", "pos1", EvidenceType.COUNTER_ARGUMENT, "B", 0.5)

    summary = tracker.summary()
    assert summary["total_positions"] == 1
    assert summary["total_registrations"] == 2
    assert summary["total_evidence_events"] == 1
    assert "pos1" in summary["positions"]


# ── Custom Drift Function ──────────────────────────────────────────

def test_custom_drift_fn() -> None:
    """Test that a custom drift function is respected."""
    def flat_drift(current: float, evidence_type: EvidenceType, strength: float) -> float:
        # Always shift by exactly 0.1 toward 0.5
        if current > 0.5:
            return current - 0.1
        return current + 0.1

    tracker = ConvictionTracker(drift_fn=flat_drift)
    tracker.register("A", "topic", initial=0.8)
    tracker.record_evidence("A", "topic", EvidenceType.COUNTER_ARGUMENT, "B", 1.0)
    assert tracker.get_conviction("A", "topic") == pytest.approx(0.7, abs=0.001)
