"""Tests for InMemoryBackend."""

import threading
from floorctl.backends.memory import InMemoryBackend
from floorctl.types import TurnData


def test_create_and_get_session():
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Mars", "participants": ["A", "B"], "phase": "OPENING"})

    state = backend.get_session_state("s1")
    assert state["topic"] == "Mars"
    assert state["status"] == "WAITING"
    assert "A" in state["participants"]


def test_post_and_get_turns():
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test", "phase": "DISCUSSION"})

    turn = TurnData(
        agent_name="Alpha",
        transcript="Alpha: Hello world",
        timestamp="2024-01-01T00:00:00Z",
    )
    backend.post_turn("s1", turn)

    turns = backend.get_turns("s1")
    assert len(turns) == 1
    assert turns[0].speaker == "Alpha"
    assert turns[0].text == "Alpha: Hello world"


def test_turn_subscription():
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test", "phase": "DISCUSSION"})

    received = []

    def on_turn(turn):
        received.append(turn)

    unsub = backend.subscribe_turns("s1", on_turn)

    backend.post_turn("s1", TurnData(
        agent_name="A", transcript="Hello", timestamp="t1"
    ))
    backend.post_turn("s1", TurnData(
        agent_name="B", transcript="Hi", timestamp="t2"
    ))

    assert len(received) == 2
    assert received[0].speaker == "A"
    assert received[1].speaker == "B"

    # Unsubscribe
    unsub()
    backend.post_turn("s1", TurnData(
        agent_name="C", transcript="Hey", timestamp="t3"
    ))
    assert len(received) == 2  # No more callbacks


def test_session_subscription():
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test", "phase": "OPENING"})

    updates = []
    backend.subscribe_session("s1", lambda state: updates.append(state))

    backend.update_session("s1", {"phase": "DISCUSSION"})

    assert len(updates) == 1
    assert updates[0]["phase"] == "DISCUSSION"


def test_update_session():
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test", "phase": "OPENING"})

    backend.update_session("s1", {"phase": "DISCUSSION", "status": "LIVE"})

    state = backend.get_session_state("s1")
    assert state["phase"] == "DISCUSSION"
    assert state["status"] == "LIVE"


def test_atomic_floor_claims():
    """Multiple threads competing for floor — exactly one should win."""
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test", "participants": list("ABCDE")})

    results = {}
    lock = threading.Lock()

    def claim(name):
        success = backend.claim_floor("s1", name, 45.0)
        with lock:
            results[name] = success

    threads = [threading.Thread(target=claim, args=(n,)) for n in "ABCDE"]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    winners = sum(1 for v in results.values() if v)
    assert winners == 1


def test_store_and_retrieve_metrics():
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test"})

    backend.store_metrics("s1", "Alpha", {"turns": 5, "gini": 0.1})

    # Access internal storage
    assert backend._sessions["s1"].metrics["Alpha"]["turns"] == 5


def test_floor_release_signal():
    backend = InMemoryBackend()
    backend.create_session("s1", {"topic": "Test"})

    # Claim and release without posting
    backend.claim_floor("s1", "A", 45.0)
    backend.release_floor("s1", "A", posted_successfully=False)

    state = backend.get_session_state("s1")
    assert state["floor_released_without_post"] is True
    assert state["floor_released_by"] == "A"
