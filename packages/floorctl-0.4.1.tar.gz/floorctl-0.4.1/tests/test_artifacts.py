"""Tests for the Artifact Store — structured mutable objects with versioning."""

import threading

import pytest

from floorctl.artifacts import (
    Artifact,
    ArtifactStore,
    ArtifactStatus,
    ArtifactType,
    ArtifactVersion,
    _compute_diff,
)


# ── Fixtures ─────────────────────────────────────────────────────────

@pytest.fixture
def store() -> ArtifactStore:
    return ArtifactStore()


# ── Creation Tests ───────────────────────────────────────────────────

def test_create_artifact(store: ArtifactStore) -> None:
    artifact = store.create(
        "adr-001", ArtifactType.DECISION_RECORD,
        creator="Architect", message="Initial ADR",
    )
    assert artifact.artifact_id == "adr-001"
    assert artifact.artifact_type == ArtifactType.DECISION_RECORD
    assert artifact.creator == "Architect"
    assert artifact.version == 1
    assert artifact.status == ArtifactStatus.DRAFT
    assert "title" in artifact.sections  # Template applied
    assert "decision" in artifact.sections
    assert len(artifact.history) == 1


def test_create_with_initial_sections(store: ArtifactStore) -> None:
    artifact = store.create(
        "adr-002", ArtifactType.DECISION_RECORD,
        creator="Architect",
        initial_sections={"title": "Use PostgreSQL", "context": "We need a database"},
    )
    assert artifact.sections["title"] == "Use PostgreSQL"
    assert artifact.sections["context"] == "We need a database"
    # Template fields should still exist
    assert "decision" in artifact.sections


def test_create_custom_type(store: ArtifactStore) -> None:
    artifact = store.create(
        "custom-001", ArtifactType.CUSTOM,
        creator="Agent",
        initial_sections={"foo": "bar", "nested": {"a": 1}},
    )
    assert artifact.sections["foo"] == "bar"
    assert artifact.sections["nested"]["a"] == 1


def test_create_duplicate_raises(store: ArtifactStore) -> None:
    store.create("dup-001", ArtifactType.DOCUMENT, creator="A")
    with pytest.raises(ValueError, match="already exists"):
        store.create("dup-001", ArtifactType.DOCUMENT, creator="B")


# ── Update Tests ─────────────────────────────────────────────────────

def test_update_sections(store: ArtifactStore) -> None:
    store.create("adr-001", ArtifactType.DECISION_RECORD, creator="Architect")
    updated = store.update(
        "adr-001", agent="Architect",
        sections={"title": "Use PostgreSQL", "decision": "We will use PG 16"},
        message="Added title and decision",
    )
    assert updated.version == 2
    assert updated.sections["title"] == "Use PostgreSQL"
    assert updated.sections["decision"] == "We will use PG 16"
    assert len(updated.history) == 2


def test_update_records_diff(store: ArtifactStore) -> None:
    store.create(
        "adr-001", ArtifactType.DECISION_RECORD, creator="Architect",
        initial_sections={"title": "Use PostgreSQL"},
    )
    store.update(
        "adr-001", agent="SecurityLead",
        sections={"risks": "SQL injection if not parameterized"},
    )
    history = store.get_history("adr-001")
    v2 = history[1]
    assert "risks" in v2.diff
    assert v2.diff["risks"]["action"] == "modified"  # Changed from empty string


def test_update_status(store: ArtifactStore) -> None:
    store.create("adr-001", ArtifactType.DECISION_RECORD, creator="Architect")
    updated = store.update(
        "adr-001", agent="Architect",
        status=ArtifactStatus.PROPOSED,
    )
    assert updated.status == ArtifactStatus.PROPOSED


def test_update_nonexistent_raises(store: ArtifactStore) -> None:
    with pytest.raises(ValueError, match="not found"):
        store.update("nope", agent="A", sections={"x": 1})


# ── Lock Tests ───────────────────────────────────────────────────────

def test_lock_and_unlock(store: ArtifactStore) -> None:
    store.create("adr-001", ArtifactType.DOCUMENT, creator="A")
    assert store.lock("adr-001", "A") is True
    assert store.lock("adr-001", "B") is False  # Already locked by A
    assert store.unlock("adr-001", "B") is False  # B can't unlock A's lock
    assert store.unlock("adr-001", "A") is True


def test_locked_artifact_blocks_other_updates(store: ArtifactStore) -> None:
    store.create("adr-001", ArtifactType.DOCUMENT, creator="A")
    store.lock("adr-001", "A")
    # A can still update
    store.update("adr-001", agent="A", sections={"x": 1})
    # B cannot
    with pytest.raises(ValueError, match="locked"):
        store.update("adr-001", agent="B", sections={"y": 2})


# ── Query Tests ──────────────────────────────────────────────────────

def test_list_artifacts_filter(store: ArtifactStore) -> None:
    store.create("adr-001", ArtifactType.DECISION_RECORD, creator="A")
    store.create("doc-001", ArtifactType.DOCUMENT, creator="B")
    store.create("code-001", ArtifactType.CODE, creator="C")

    adrs = store.list_artifacts(artifact_type=ArtifactType.DECISION_RECORD)
    assert len(adrs) == 1
    assert adrs[0].artifact_id == "adr-001"

    all_arts = store.list_artifacts()
    assert len(all_arts) == 3


def test_get_contributors(store: ArtifactStore) -> None:
    store.create("adr-001", ArtifactType.DECISION_RECORD, creator="Architect")
    store.update("adr-001", agent="SecurityLead", sections={"risks": "..."})
    store.update("adr-001", agent="Architect", sections={"decision": "..."})
    store.update("adr-001", agent="DevLead", sections={"implementation": "..."})

    contributors = store.get_contributors("adr-001")
    assert contributors == ["Architect", "SecurityLead", "DevLead"]


def test_get_version(store: ArtifactStore) -> None:
    store.create("adr-001", ArtifactType.DOCUMENT, creator="A")
    store.update("adr-001", agent="A", sections={"title": "v2"})
    store.update("adr-001", agent="B", sections={"title": "v3"})

    v1 = store.get_version("adr-001", 1)
    v3 = store.get_version("adr-001", 3)
    assert v1 is not None
    assert v1.author == "A"
    assert v3 is not None
    assert v3.sections["title"] == "v3"
    assert store.get_version("adr-001", 99) is None


# ── Subscription Tests ───────────────────────────────────────────────

def test_subscribe_to_changes(store: ArtifactStore) -> None:
    events: list[tuple[str, str]] = []
    store.subscribe(lambda event, aid, art: events.append((event, aid)))

    store.create("adr-001", ArtifactType.DOCUMENT, creator="A")
    store.update("adr-001", agent="B", sections={"x": 1})

    assert len(events) == 2
    assert events[0] == ("created", "adr-001")
    assert events[1] == ("updated", "adr-001")


# ── Context Tests ────────────────────────────────────────────────────

def test_to_context(store: ArtifactStore) -> None:
    store.create("adr-001", ArtifactType.DECISION_RECORD, creator="Architect",
                 initial_sections={"title": "Use PG"})
    ctx = store.to_context()
    assert len(ctx) == 1
    assert ctx[0]["id"] == "adr-001"
    assert ctx[0]["type"] == "decision_record"
    assert ctx[0]["sections"]["title"] == "Use PG"


# ── Diff Tests ───────────────────────────────────────────────────────

def test_compute_diff_added() -> None:
    diff = _compute_diff({"a": 1}, {"a": 1, "b": 2})
    assert diff["b"]["action"] == "added"


def test_compute_diff_modified() -> None:
    diff = _compute_diff({"a": 1}, {"a": 2})
    assert diff["a"]["action"] == "modified"
    assert diff["a"]["old"] == 1
    assert diff["a"]["new"] == 2


def test_compute_diff_removed() -> None:
    diff = _compute_diff({"a": 1, "b": 2}, {"a": 1})
    assert diff["b"]["action"] == "removed"


# ── Thread Safety ────────────────────────────────────────────────────

def test_concurrent_updates(store: ArtifactStore) -> None:
    store.create("shared-001", ArtifactType.DOCUMENT, creator="Init")
    errors: list[str] = []

    def updater(agent: str, n: int) -> None:
        for i in range(n):
            try:
                store.update(
                    "shared-001", agent=agent,
                    sections={f"{agent}_key_{i}": f"value_{i}"},
                )
            except Exception as e:
                errors.append(str(e))

    threads = [
        threading.Thread(target=updater, args=("A", 10)),
        threading.Thread(target=updater, args=("B", 10)),
        threading.Thread(target=updater, args=("C", 10)),
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors
    artifact = store.get("shared-001")
    assert artifact is not None
    assert artifact.version == 31  # 1 creation + 30 updates
