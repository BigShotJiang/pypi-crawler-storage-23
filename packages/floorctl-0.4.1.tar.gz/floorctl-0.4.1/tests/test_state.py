"""Tests for ConversationState."""

from floorctl.state import ConversationState, AgentMemory


def test_add_turn():
    state = ConversationState(topic="Test", phase="DISCUSSION")
    state.add_turn("Alpha", "Hello world")
    assert len(state.transcript) == 1
    assert state.transcript[0].speaker == "Alpha"
    assert state.transcript[0].text == "Hello world"
    assert state.turn_index == 1
    assert state.phase_turn_count == 1


def test_agent_memory_tracking():
    state = ConversationState(topic="Test", phase="DISCUSSION")
    state.add_turn("Alpha", "First point")
    state.add_turn("Beta", "Counter point")
    state.add_turn("Alpha", "Second point")

    mem = state.ensure_agent_memory("Alpha")
    assert mem.turns_spoken == 2
    assert len(mem.last_text_hashes) == 2


def test_turns_since_agent_spoke():
    state = ConversationState(topic="Test", phase="DISCUSSION")
    state.add_turn("Alpha", "Hello")
    state.add_turn("Beta", "Hi")
    state.add_turn("Gamma", "Hey")

    assert state.turns_since_agent_spoke("Alpha") == 2
    assert state.turns_since_agent_spoke("Gamma") == 0
    assert state.turns_since_agent_spoke("Unknown") == 3


def test_last_speaker():
    state = ConversationState(topic="Test", phase="DISCUSSION")
    assert state.last_speaker() is None

    state.add_turn("Alpha", "Hello")
    assert state.last_speaker() == "Alpha"

    state.add_turn("Beta", "Hi")
    assert state.last_speaker() == "Beta"


def test_get_last_n_turns():
    state = ConversationState(topic="Test", phase="DISCUSSION")
    for i in range(10):
        state.add_turn(f"Agent{i}", f"Turn {i}")

    last_3 = state.get_last_n_turns(3)
    assert len(last_3) == 3
    assert last_3[0].speaker == "Agent7"


def test_agent_turns_in_phase():
    state = ConversationState(topic="Test", phase="OPENING")
    state.add_turn("Alpha", "Opening")
    state.add_turn("Beta", "Opening")

    assert state.agent_turns_in_phase("Alpha") == 1
    assert state.agent_turns_in_phase("Beta") == 1

    state.phase = "DISCUSSION"
    state.reset_phase_count()
    state.add_turn("Alpha", "Discussion 1")
    state.add_turn("Alpha", "Discussion 2")

    assert state.agent_turns_in_phase("Alpha") == 2


def test_needs_summary_update():
    state = ConversationState(topic="Test", phase="DISCUSSION")
    assert not state.needs_summary_update()

    state.add_turn("A", "1")
    state.add_turn("B", "2")
    assert not state.needs_summary_update()

    state.add_turn("C", "3")
    assert state.needs_summary_update()


def test_dedup_hash_storage():
    state = ConversationState(topic="Test", phase="DISCUSSION")
    # Add 12 turns from same agent to test hash list trimming
    for i in range(12):
        state.add_turn("Alpha", f"Unique text {i}")

    mem = state.ensure_agent_memory("Alpha")
    assert len(mem.last_text_hashes) == 10  # trimmed to last 10
