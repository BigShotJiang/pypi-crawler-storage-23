"""Tests for moderator observer."""

from floorctl.config import ModeratorConfig
from floorctl.moderator import (
    EscalationDetector,
    DominanceDetector,
    SilenceDetector,
)
from floorctl.state import ConversationState


def test_escalation_detected():
    detector = EscalationDetector()
    config = ModeratorConfig(escalation_threshold=2)
    state = ConversationState(topic="Test", phase="DISCUSSION")

    # Two markers in one turn
    result = detector.check(
        state, "Alpha",
        "That's absurd and completely wrong! You're ignoring the data.",
        config,
    )
    assert result is not None
    assert result.type == "escalation"
    assert result.target_agent == "Alpha"


def test_escalation_not_detected():
    detector = EscalationDetector()
    config = ModeratorConfig(escalation_threshold=2)
    state = ConversationState(topic="Test", phase="DISCUSSION")

    result = detector.check(
        state, "Alpha",
        "I respectfully disagree with the approach.",
        config,
    )
    assert result is None


def test_dominance_detected():
    detector = DominanceDetector()
    config = ModeratorConfig(dominance_window=6, dominance_threshold=3)
    state = ConversationState(topic="Test", phase="DISCUSSION")
    state.speaker_queue = ["Alpha", "Beta", "Gamma"]

    # Alpha dominates: speaks 4 of last 6 turns
    state.add_turn("Alpha", "Point 1")
    state.add_turn("Alpha", "Point 2")
    state.add_turn("Beta", "Response")
    state.add_turn("Alpha", "Point 3")
    state.add_turn("Alpha", "Point 4")
    state.add_turn("Beta", "Another response")

    result = detector.check(state, "Alpha", "Point 4", config)
    assert result is not None
    assert result.type == "dominance"
    assert result.details["dominant_agent"] == "Alpha"


def test_silence_detected():
    detector = SilenceDetector()
    config = ModeratorConfig(silence_threshold=4)
    state = ConversationState(topic="Test", phase="DISCUSSION")
    state.speaker_queue = ["Alpha", "Beta", "Gamma"]

    # Gamma hasn't spoken while others have
    state.add_turn("Alpha", "Turn 1")
    state.add_turn("Beta", "Turn 2")
    state.add_turn("Alpha", "Turn 3")
    state.add_turn("Beta", "Turn 4")

    result = detector.check(state, "Beta", "Turn 4", config)
    assert result is not None
    assert result.type == "silence"
    assert result.target_agent == "Gamma"


def test_silence_not_detected():
    detector = SilenceDetector()
    config = ModeratorConfig(silence_threshold=5)
    state = ConversationState(topic="Test", phase="DISCUSSION")
    state.speaker_queue = ["Alpha", "Beta"]

    # Both spoke recently
    state.add_turn("Alpha", "Turn 1")
    state.add_turn("Beta", "Turn 2")
    state.add_turn("Alpha", "Turn 3")

    result = detector.check(state, "Alpha", "Turn 3", config)
    assert result is None
