# Getting Started with floorctl

A step-by-step guide to building your first multi-agent session with contention-based floor control.

## Installation

```bash
pip install floorctl                # core library (zero dependencies)
pip install "floorctl[openai]"      # + OpenAI for LLM-powered agents
pip install "floorctl[websocket]"   # + WebSocket for distributed sessions
pip install "floorctl[firestore]"   # + Firebase Firestore for production
pip install "floorctl[all]"         # all optional backends
pip install "floorctl[dev]"         # + pytest, mypy, ruff for development
```

## Core Concepts

**floorctl** is a coordination framework where agents **compete** for the floor rather than being orchestrated by a central planner.

| Concept | What it does |
|---------|-------------|
| **FloorAgent** | An autonomous agent that listens, computes urgency, claims the floor, generates a response, self-validates, and posts |
| **FloorSession** | Orchestrates the lifecycle — starts agents in threads, runs the moderator, collects metrics |
| **ModeratorObserver** | Watches the conversation and intervenes only on anomalies (silence, dominance, escalation) |
| **Backend** | The coordination substrate — atomic floor claims, turn posting, pub/sub. Swap between InMemory, WebSocket, or Firestore |
| **Urgency Scorer** | 8 composable components that decide whether an agent should compete for the floor |
| **Validators** | Self-validation pipeline — agents check their own output before posting |

## Minimal Example (No LLM)

You can run floorctl without any API keys using a simple function as the generator:

```python
from floorctl import (
    FloorAgent, FloorSession, AgentProfile,
    ArenaConfig, PhaseConfig, PhaseSequence,
    FloorConfig, InMemoryBackend,
    SpeakerPrefixValidator, LengthValidator,
)

# 1. Backend — InMemory for local, single-process usage
backend = InMemoryBackend()

# 2. Simple generator — no LLM needed
def generate(agent_name: str, context: dict) -> str:
    topic = context["topic"]
    phase = context["phase"]
    return f"{agent_name}: Here's my take on {topic} during {phase} phase."

# 3. Define phases
phases = PhaseSequence(phases=[
    PhaseConfig(name="DISCUSS", min_turns=4, max_turns=8, min_words=5, max_words=50),
    PhaseConfig(name="CLOSING", is_terminal=True),
])

# 4. Configuration
config = ArenaConfig(
    phases=phases,
    floor=FloorConfig(timeout_seconds=15, min_turns_between_speaking=1),
    max_total_turns=10,
)

# 5. Create agents with different temperaments
agent_a = FloorAgent(
    name="Alice",
    profile=AgentProfile(
        name="Alice",
        react_to=["risk", "problem"],    # keywords that trigger urgency
        temperament="reactive",           # low threshold (0.35) — speaks often
    ),
    generate_fn=generate,
    backend=backend,
    validators=[SpeakerPrefixValidator(), LengthValidator()],
    config=config,
)

agent_b = FloorAgent(
    name="Bob",
    profile=AgentProfile(
        name="Bob",
        react_to=["opportunity", "idea"],
        temperament="patient",            # high threshold (0.55) — speaks less
    ),
    generate_fn=generate,
    backend=backend,
    validators=[SpeakerPrefixValidator(), LengthValidator()],
    config=config,
)

# 6. Run
session = FloorSession(backend=backend, config=config)
session.add_agent(agent_a)
session.add_agent(agent_b)

result = session.run("my-session", topic="Should we adopt microservices?", timeout_seconds=30)

print(f"Turns: {result.total_turns}, Duration: {result.duration_seconds:.1f}s")
for turn in result.transcript:
    print(f"  [{turn.speaker}] {turn.text}")
```

## Full Example with OpenAI + Moderator

```python
import os
from openai import OpenAI
from floorctl import (
    FloorAgent, FloorSession, ModeratorObserver,
    AgentProfile, ArenaConfig, PhaseConfig, PhaseSequence,
    FloorConfig, ModeratorConfig, InMemoryBackend,
    SpeakerPrefixValidator, DuplicateValidator,
    LengthValidator, BannedPhraseValidator,
)

client = OpenAI()  # uses OPENAI_API_KEY from env

# --- Generator: wraps any LLM ---
def generate(agent_name: str, context: dict) -> str:
    retry_info = ""
    if context.get("retry_failures"):
        retry_info = "\nFix these issues:\n" + "\n".join(
            f"- {f}" for f in context["retry_failures"]
        )

    prompt = f"""You are {agent_name}.
Personality: {context.get('personality', '')}
Topic: {context['topic']}
Phase: {context['phase']}

Recent discussion:
{context.get('recent_turns', '(none)')}

RULES:
- Prefix response with "{agent_name}:"
- {context.get('phase_min_words', 15)}-{context.get('phase_max_words', 80)} words
- Be substantive, no filler
{retry_info}

Respond:"""

    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=200, temperature=0.8,
    )
    return resp.choices[0].message.content.strip()


# --- Moderator: generates intro, transitions, interventions ---
def moderate(prompt_type: str, context: dict) -> str:
    prompts = {
        "intro": f"You moderate a discussion on '{context.get('topic')}' with {context.get('agents')}. 2-sentence intro.",
        "invite_opening": f"Invite {context.get('agent_name')} to share their view. 1 sentence.",
        "phase_transition": f"Transition from {context.get('previous_phase')} to {context.get('phase')}. 2 sentences.",
        "intervention": f"Moderate: {context.get('intervention_type')} detected for {context.get('target_agent')}. 1 sentence.",
        "closing": f"Close the discussion on '{context.get('topic')}'. 2 sentences.",
    }
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompts.get(prompt_type, "Brief comment.")}],
        max_tokens=150, temperature=0.7,
    )
    return resp.choices[0].message.content.strip()


# --- Setup ---
backend = InMemoryBackend()

phases = PhaseSequence(phases=[
    PhaseConfig(name="IDEAS", is_opening=True, max_turns=12, max_words=80, min_words=10),
    PhaseConfig(name="DEBATE", min_turns=6, max_turns=16, max_words=120, min_words=20),
    PhaseConfig(name="CLOSING", is_terminal=True),
])

config = ArenaConfig(
    phases=phases,
    floor=FloorConfig(
        timeout_seconds=30,
        min_turns_between_speaking=1,
        max_turns_per_phase_per_agent=5,
    ),
    moderator=ModeratorConfig(
        silence_threshold=3,      # pull in quiet agents after 3 turns of silence
        dominance_threshold=3,    # intervene if one agent takes 3 of last 6 turns
        dominance_window=6,
    ),
    banned_phrases=["As an AI", "Let's face it"],
    max_total_turns=20,
)

validators = [
    SpeakerPrefixValidator(),        # must start with "AgentName:"
    DuplicateValidator(),            # rejects near-duplicate responses
    LengthValidator(),               # enforces word count from phase config
    BannedPhraseValidator(banned_phrases=config.banned_phrases),
]

# --- Agents ---
optimist = FloorAgent(
    name="Optimist",
    profile=AgentProfile(
        name="Optimist",
        personality="Bold futurist. Thinks in moonshots.",
        react_to=["risk", "problem", "can't", "impossible"],
        temperament="passionate",     # threshold 0.40
        urgency_boost_keywords=["future", "opportunity", "transform"],
    ),
    generate_fn=generate, backend=backend,
    validators=validators, config=config,
)

skeptic = FloorAgent(
    name="Skeptic",
    profile=AgentProfile(
        name="Skeptic",
        personality="Pragmatic engineer. Argues with data.",
        react_to=["dream", "vision", "should", "must"],
        temperament="reactive",       # threshold 0.35
        urgency_boost_keywords=["cost", "evidence", "precedent"],
    ),
    generate_fn=generate, backend=backend,
    validators=validators, config=config,
)

# --- Session ---
session_id = "demo-001"
backend.create_session(session_id, {
    "topic": "Should AI be given legal personhood?",
    "phase": "IDEAS",
    "participants": ["Optimist", "Skeptic"],
})

moderator = ModeratorObserver(
    agent_names=["Optimist", "Skeptic"],
    moderator_fn=moderate,
    backend=backend,
    session_id=session_id,
    phase_sequence=phases,
    config=config.moderator,
)

# Print turns as they happen
backend.subscribe_turns(session_id, lambda t: print(f"[{t.speaker}] {t.text[:150]}"))

session = FloorSession(backend=backend, config=config)
session.add_agent(optimist)
session.add_agent(skeptic)
session.set_moderator(moderator)

result = session.run(session_id, topic="Should AI be given legal personhood?", timeout_seconds=120)

# --- Results ---
print(f"\nDone! {result.total_turns} turns in {result.duration_seconds:.1f}s")
print(f"Gini: {result.session_metrics.get('participation', {}).get('gini', 'N/A')}")
```

## Temperaments

Each agent has a temperament that sets its urgency threshold — how eager it is to speak:

| Temperament | Threshold | Behaviour |
|------------|-----------|-----------|
| `reactive` | 0.35 | Jumps in quickly, speaks often |
| `passionate` | 0.40 | Engaged, responds to triggers fast |
| `provocative` | 0.42 | Challenges others, slightly restrained |
| `mediating` | 0.45 | Balanced, waits for the right moment |
| `deliberate` | 0.50 | Thoughtful, speaks with purpose |
| `patient` | 0.55 | Waits longest, speaks only when necessary |

## Urgency Components

The urgency score is computed from 8 composable components. When the total exceeds the agent's threshold, it competes for the floor:

| Component | Max Score | Triggers on |
|-----------|-----------|-------------|
| `keyword_react` | 0.6 | Agent's `react_to` keywords found in last turn |
| `boost_keywords` | 0.3 | Agent's `urgency_boost_keywords` in last turn |
| `name_mention` | 0.4 | Agent's name mentioned by another speaker |
| `moderator_question` | 0.35 | Moderator asks a question or opens the floor |
| `silence_bonus` | 0.40 | Agent hasn't spoken for 4+ turns |
| `recent_speaker_penalty` | -0.5 | Agent spoke too recently |
| `jitter` | 0.15 | Random tie-breaking |
| `phase_boost` | 0.10 | Active discussion phase |

## Validators

Agents self-validate before posting. If validation fails, the agent retries with failure reasons injected into the prompt:

```python
from floorctl import (
    SpeakerPrefixValidator,   # response must start with "AgentName:"
    DuplicateValidator,       # rejects near-duplicates (cosine similarity)
    LengthValidator,          # enforces min/max word count from phase config
    BannedPhraseValidator,    # blocks "As an AI" etc.
    StyleContractValidator,   # enforces custom regex patterns
    PhaseValidator,           # phase-specific rules
)

# Custom style contract per agent
from floorctl import StyleContract

profile = AgentProfile(
    name="DataScientist",
    style_contract=StyleContract(
        description="Must cite at least one number or statistic",
        required_patterns=[r"\d+"],           # must contain a number
        forbidden_patterns=[r"(?i)obviously"], # no "obviously"
        max_sentences=4,
    ),
    ...
)
```

## Phases

Phases structure the conversation flow. Each phase has its own word limits, constraints, and transition rules:

```python
phases = PhaseSequence(phases=[
    # Opening: agents take turns in sequence (round-robin invites)
    PhaseConfig(
        name="OPENING",
        is_opening=True,         # moderator invites agents one by one
        max_turns=8,
        max_words=60,
        allow_critiques=False,   # no attacking during opening
        constraints="State your position clearly.",
    ),
    # Free discussion: agents compete via urgency
    PhaseConfig(
        name="DISCUSSION",
        min_turns=6,             # must run at least 6 agent turns
        max_turns=20,            # transitions after 20 agent turns
        max_words=120,
        min_words=20,
    ),
    # Terminal: moderator delivers closing, session ends
    PhaseConfig(name="CLOSING", is_terminal=True),
])
```

## Moderator Interventions

The moderator observes and intervenes automatically on three conditions:

| Intervention | Trigger | What happens |
|-------------|---------|--------------|
| **Silence** | An agent hasn't spoken for N turns | Moderator invites them by name, reserves floor |
| **Dominance** | One agent took 3+ of the last 6 turns | Moderator redirects to quieter agent |
| **Escalation** | Heated language detected | Moderator de-escalates and reframes |

Configure thresholds:
```python
ModeratorConfig(
    silence_threshold=3,       # turns of silence before pull-in
    dominance_window=6,        # look-back window for dominance check
    dominance_threshold=3,     # turns by one agent to trigger intervention
    escalation_threshold=2,    # heated markers to trigger de-escalation
)
```

## Saving Transcripts

Export a rich Markdown transcript with floor contention tables, per-turn attribution, and session metrics:

```python
from floorctl import export_transcript

result = session.run(...)
path = export_transcript(result, "transcripts/my-session.md")
```

The transcript includes:
- Per-turn floor contention tables (who claimed, urgency scores, who won/lost)
- Speaker attribution with timestamps
- Session summary with Gini coefficient, participation rates, and agent performance

## Swapping Backends

floorctl ships with three backends. The `Backend` protocol makes it easy to add your own:

```python
# Local development (default)
from floorctl import InMemoryBackend
backend = InMemoryBackend()

# Distributed via WebSocket relay
from floorctl import WebSocketBackend
backend = WebSocketBackend("ws://relay.example.com:8765", api_key="your-key", agent_name="Agent1")
backend.connect()

# Production with Firestore (transactional)
from floorctl import FirestoreBackend
backend = FirestoreBackend(project_id="my-project", session_collection="sessions")
```

## Metrics & Fairness

Every session produces research-grade metrics:

```python
result = session.run(...)

# Session-level
gini = result.session_metrics["participation"]["gini"]  # 0.0 = perfect equality
interventions = result.session_metrics["interventions"]["total"]

# Per-agent
for name, metrics in result.agent_metrics.items():
    floor = metrics["floor"]
    print(f"{name}: {floor['claims_won']}/{floor['claims_attempted']} claims won")
    print(f"  Avg urgency: {metrics['urgency']['mean']:.3f}")
    print(f"  Validation pass rate: {metrics['validation']['pass_rate']:.0%}")
```

## Bringing Your Own LLM

floorctl is LLM-agnostic. The `generate_fn` is just a function with signature:

```python
def generate(agent_name: str, context: dict) -> str:
    # context contains: topic, phase, personality, recent_turns,
    #                   phase_min_words, phase_max_words, style_contract,
    #                   retry_failures (if retrying after validation failure)
    return f"{agent_name}: Your response here"
```

Works with OpenAI, Anthropic, local models, or any HTTP API:

```python
# Anthropic Claude
import anthropic
client = anthropic.Anthropic()

def generate(agent_name, context):
    resp = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=200,
        messages=[{"role": "user", "content": f"You are {agent_name}. Topic: {context['topic']}. Respond:"}],
    )
    return resp.content[0].text

# Local Ollama
import requests

def generate(agent_name, context):
    resp = requests.post("http://localhost:11434/api/generate", json={
        "model": "llama3",
        "prompt": f"You are {agent_name}. Topic: {context['topic']}. Respond:",
    })
    return resp.json()["response"]
```

## Capabilities (v0.4)

Extend agent behavior without subclassing. Capabilities are modular plugins that hook into the generate pipeline:

```python
from floorctl import AgentCapability, FloorAgent

class RAGCapability(AgentCapability):
    name = "rag"

    def __init__(self, retriever):
        self.retriever = retriever

    def enrich_context(self, context):
        context["rag:docs"] = self.retriever.search(context["topic"])
        return context

class MemoryCapability(AgentCapability):
    name = "memory"

    def __init__(self):
        self.history = []

    def on_turn_received(self, turn, agent_name):
        self.history.append({"speaker": turn.speaker, "text": turn.text})

    def enrich_context(self, context):
        context["memory:history"] = self.history[-20:]
        return context

# Attach to any agent — no subclassing needed
agent = FloorAgent(name="Researcher", ...)
agent.add_capability(RAGCapability(my_retriever))
agent.add_capability(MemoryCapability())
```

Three hooks available:

| Hook | When | Use for |
|------|------|---------|
| `enrich_context(context)` | Before LLM call | Inject data: RAG docs, search results, DB records |
| `post_process(response, context)` | After LLM call, before validation | Transform response: append sources, tool execution |
| `on_turn_received(turn, agent_name)` | On every new turn | Side-effects: logging, memory, analytics |

Capabilities run in insertion order and are error-resilient — a failing capability is skipped without crashing the agent.

For the full spec and more examples, see [SKILLS.md](SKILLS.md).

## Next Steps

- Browse the [examples/](examples/) folder for complete runnable scripts (debate, brainstorm, code review, investment committee)
- Read [SKILLS.md](SKILLS.md) for the full capability protocol and extension guide
- Read the [README](README.md) for architecture overview
- Check the source — floorctl is 100% typed Python with zero core dependencies
