# GitHub仿真Shell包初始化文件
__version__ = "1.2.0"
__author__ = "wjr-2015"
__email__ = "wangjinrui_150328@126.com"
