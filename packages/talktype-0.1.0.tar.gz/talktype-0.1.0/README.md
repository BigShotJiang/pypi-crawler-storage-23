# talk

> **macOS only** (Apple Silicon recommended). Requires Python 3.11+.

Local-first dictation for macOS.
Press a hotkey, talk, text appears at your cursor.

- Parakeet local transcription by default (zero API cost on Apple Silicon).
- OpenAI `gpt-4o-transcribe` fallback with one env switch.
- Automatic paste at cursor (clipboard-safe restore).

## Install

```bash
pip install talk
```

That's it. On first run, Parakeet model weights (~1.2 GB) download automatically.

### Alternative: from source

```bash
git clone https://github.com/strangeloopcanon/talk.git
cd talk
./scripts/install_macos.sh
./scripts/doctor_macos.sh
./scripts/run_macos.sh
```

## Usage

```bash
talk run
```

- Press `Cmd+Shift+Space` to start recording.
- Press `Cmd+Shift+Space` again to stop, transcribe, and paste.
- Press `Cmd+Shift+Q` to quit.

### Preflight checks

```bash
talk doctor
```

### File transcription

```bash
talk transcribe-file /path/to/sample.wav
```

## macOS permissions

You must grant your terminal app:

- **Microphone** -- for audio recording
- **Accessibility** -- for paste keystroke automation
- **Input Monitoring** -- for global hotkeys

If paste fails but transcription works, Accessibility permission is usually the issue.

## Configuration

Works out of the box with zero configuration. To customize, create `~/.config/talk/.env`:

```bash
mkdir -p ~/.config/talk
```

Key options (all have sensible defaults):

| Variable | Default | Notes |
|----------|---------|-------|
| `DICTATE_BACKEND` | `parakeet` | `parakeet` (local) or `openai` (cloud) |
| `DICTATE_HOTKEY` | `<cmd>+<shift>+<space>` | Toggle recording |
| `DICTATE_QUIT_HOTKEY` | `<cmd>+<shift>+q` | Quit the app |
| `DICTATE_AUTOPASTE` | `true` | Paste transcription at cursor |
| `PARAKEET_MODEL` | `mlx-community/parakeet-tdt-0.6b-v3` | Local model |
| `OPENAI_API_KEY` | *(empty)* | Required if backend=openai |

See `.env.example` for the full list.

## Switching backend

```bash
# In ~/.config/talk/.env or as env vars:
DICTATE_BACKEND=openai
OPENAI_API_KEY=sk-...
```

## Cleanup

Parakeet model weights are cached in `~/.cache/huggingface/hub/`. To reclaim disk space:

```bash
rm -rf ~/.cache/huggingface/hub/models--mlx-community--parakeet-tdt-0.6b-v3
```
