from __future__ import annotations

import subprocess
import time


def paste_text(text: str, restore_clipboard: bool = True) -> None:
    previous_clipboard = None
    if restore_clipboard:
        prior = subprocess.run(["pbpaste"], capture_output=True, text=True, check=False)
        if prior.returncode == 0:
            previous_clipboard = prior.stdout

    subprocess.run(["pbcopy"], input=text, text=True, check=True)

    # Requires macOS Accessibility permission for Terminal/Codex app.
    subprocess.run(
        [
            "osascript",
            "-e",
            'tell application "System Events" to keystroke "v" using command down',
        ],
        check=False,
    )

    if restore_clipboard and previous_clipboard is not None:
        time.sleep(0.15)
        subprocess.run(["pbcopy"], input=previous_clipboard, text=True, check=False)
