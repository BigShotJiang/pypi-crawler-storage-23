from __future__ import annotations

import platform
import sys
from dataclasses import dataclass

import sounddevice as sd

from talk.config import Settings


@dataclass(slots=True)
class CheckResult:
    name: str
    ok: bool
    message: str


def _check_platform() -> CheckResult:
    system = platform.system()
    machine = platform.machine().lower()
    if system != "Darwin":
        return CheckResult(
            name="platform",
            ok=False,
            message=f"Detected {system}. This build is currently optimized for macOS (Darwin).",
        )

    if machine != "arm64":
        return CheckResult(
            name="platform",
            ok=True,
            message=f"Running on macOS {machine}. Works, but Parakeet-MLX is best on Apple Silicon.",
        )

    return CheckResult(
        name="platform",
        ok=True,
        message="Running on macOS arm64 (Apple Silicon), ideal for Parakeet-MLX.",
    )


def _check_microphone_device() -> CheckResult:
    try:
        devices = sd.query_devices()
    except Exception as exc:  # noqa: BLE001
        return CheckResult(
            name="microphone_device",
            ok=False,
            message=f"Could not enumerate audio devices: {exc}",
        )

    has_input = any((device.get("max_input_channels") or 0) > 0 for device in devices)
    if not has_input:
        return CheckResult(
            name="microphone_device",
            ok=False,
            message="No input-capable microphone device found.",
        )

    default_device = sd.default.device
    return CheckResult(
        name="microphone_device",
        ok=True,
        message=f"Input device detected. Default device tuple: {default_device}.",
    )


def _check_microphone_access(settings: Settings) -> CheckResult:
    stream = None
    try:
        stream = sd.InputStream(
            samplerate=settings.sample_rate,
            channels=settings.channels,
            dtype="float32",
        )
        stream.start()
        stream.stop()
        return CheckResult(
            name="microphone_access",
            ok=True,
            message="Microphone stream opened successfully.",
        )
    except Exception as exc:  # noqa: BLE001
        return CheckResult(
            name="microphone_access",
            ok=False,
            message=f"Microphone stream failed. Grant microphone permission in macOS settings. Error: {exc}",
        )
    finally:
        if stream is not None:
            try:
                stream.close()
            except Exception:  # noqa: BLE001
                pass


def _check_accessibility_permission() -> CheckResult:
    if platform.system() != "Darwin":
        return CheckResult(
            name="accessibility_permission",
            ok=False,
            message="Accessibility permission check is only available on macOS.",
        )

    try:
        from ApplicationServices import AXIsProcessTrusted
    except Exception as exc:  # noqa: BLE001
        return CheckResult(
            name="accessibility_permission",
            ok=False,
            message=f"Could not load macOS accessibility APIs: {exc}",
        )

    trusted = bool(AXIsProcessTrusted())
    if trusted:
        return CheckResult(
            name="accessibility_permission",
            ok=True,
            message="Accessibility permission is granted.",
        )

    return CheckResult(
        name="accessibility_permission",
        ok=False,
        message=(
            "Accessibility permission is not granted. Add your terminal/Codex app in "
            "System Settings > Privacy & Security > Accessibility."
        ),
    )


def _check_input_monitoring_permission() -> CheckResult:
    if platform.system() != "Darwin":
        return CheckResult(
            name="input_monitoring_permission",
            ok=False,
            message="Input Monitoring check is only available on macOS.",
        )

    try:
        from Quartz import CGPreflightListenEventAccess
    except Exception as exc:  # noqa: BLE001
        return CheckResult(
            name="input_monitoring_permission",
            ok=False,
            message=f"Could not load Input Monitoring API: {exc}",
        )

    trusted = bool(CGPreflightListenEventAccess())
    if trusted:
        return CheckResult(
            name="input_monitoring_permission",
            ok=True,
            message="Input Monitoring permission is granted.",
        )

    return CheckResult(
        name="input_monitoring_permission",
        ok=False,
        message=(
            "Input Monitoring permission is not granted. Add your terminal/Codex app in "
            "System Settings > Privacy & Security > Input Monitoring."
        ),
    )


def _check_backend_config(settings: Settings) -> CheckResult:
    if settings.backend == "parakeet":
        return CheckResult(
            name="backend_config",
            ok=True,
            message=f"Backend is parakeet (model: {settings.parakeet_model}).",
        )

    if settings.backend == "openai":
        if settings.openai_api_key:
            return CheckResult(
                name="backend_config",
                ok=True,
                message="Backend is openai and OPENAI_API_KEY is set.",
            )
        return CheckResult(
            name="backend_config",
            ok=False,
            message="Backend is openai but OPENAI_API_KEY is missing.",
        )

    return CheckResult(
        name="backend_config",
        ok=False,
        message=f"Unknown backend value: {settings.backend}",
    )


def run_doctor(settings: Settings) -> int:
    print("[doctor] talk preflight checks")
    print(f"[doctor] Python: {sys.version.split()[0]}")
    print(f"[doctor] Backend: {settings.backend}")
    print(f"[doctor] Dictate hotkey: {settings.hotkey}")
    print(f"[doctor] Quit hotkey: {settings.quit_hotkey}")
    print()

    checks = [
        _check_platform(),
        _check_backend_config(settings),
        _check_microphone_device(),
        _check_microphone_access(settings),
        _check_accessibility_permission(),
        _check_input_monitoring_permission(),
    ]

    failed = 0
    for check in checks:
        status = "ok" if check.ok else "fail"
        print(f"[{status}] {check.name}: {check.message}")
        if not check.ok:
            failed += 1

    print()
    if failed:
        print(f"[doctor] Completed with {failed} failing check(s).")
        return 1

    print("[doctor] All checks passed. You are ready to run live dictation.")
    return 0
