from __future__ import annotations

import io
import threading
import wave
from dataclasses import dataclass

import numpy as np
import sounddevice as sd


class RecorderError(RuntimeError):
    """Raised when recording state is invalid."""


@dataclass(slots=True)
class AudioChunk:
    samples: np.ndarray
    sample_rate: int


class MicRecorder:
    def __init__(self, sample_rate: int, channels: int = 1) -> None:
        self.sample_rate = sample_rate
        self.channels = channels
        self._stream: sd.InputStream | None = None
        self._frames: list[np.ndarray] = []
        self._lock = threading.Lock()

    def _on_audio(self, indata: np.ndarray, frames: int, time_info: dict, status: sd.CallbackFlags) -> None:
        del frames, time_info
        if status:
            print(f"[warn] audio callback status: {status}")
        with self._lock:
            self._frames.append(indata.copy())

    def start(self) -> None:
        if self._stream is not None:
            raise RecorderError("Recorder is already running")

        with self._lock:
            self._frames = []

        self._stream = sd.InputStream(
            samplerate=self.sample_rate,
            channels=self.channels,
            dtype="float32",
            callback=self._on_audio,
        )
        self._stream.start()

    def stop(self) -> AudioChunk:
        if self._stream is None:
            raise RecorderError("Recorder is not running")

        self._stream.stop()
        self._stream.close()
        self._stream = None

        with self._lock:
            if not self._frames:
                merged = np.zeros((0,), dtype=np.float32)
            else:
                merged = np.concatenate(self._frames, axis=0).astype(np.float32)

        if merged.ndim == 2:
            if merged.shape[1] == 1:
                merged = merged[:, 0]
            else:
                merged = merged.mean(axis=1)

        return AudioChunk(samples=merged, sample_rate=self.sample_rate)


def to_wav_buffer(audio: np.ndarray, sample_rate: int) -> io.BytesIO:
    clipped = np.clip(audio.astype(np.float32), -1.0, 1.0)
    pcm16 = (clipped * 32767.0).astype(np.int16)

    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(pcm16.tobytes())

    buffer.seek(0)
    buffer.name = "dictation.wav"
    return buffer


def load_wav_mono(path: str) -> AudioChunk:
    with wave.open(path, "rb") as wav_file:
        channels = wav_file.getnchannels()
        sample_rate = wav_file.getframerate()
        sample_width = wav_file.getsampwidth()
        frame_count = wav_file.getnframes()
        raw = wav_file.readframes(frame_count)

    if sample_width != 2:
        raise ValueError("Only 16-bit PCM WAV files are supported for file transcription.")

    audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32767.0

    if channels > 1:
        audio = audio.reshape(-1, channels).mean(axis=1)

    return AudioChunk(samples=audio, sample_rate=sample_rate)
