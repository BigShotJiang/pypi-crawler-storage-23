from __future__ import annotations

import signal
import subprocess
import threading
import time
from pathlib import Path

from pynput import keyboard

from talk.audio import AudioChunk, MicRecorder, RecorderError
from talk.backends.factory import build_backend
from talk.config import Settings
from talk.paste import paste_text


def _play_sound(filename: str) -> None:
    sound_path = Path("/System/Library/Sounds") / filename
    if not sound_path.exists():
        return
    subprocess.Popen(
        ["afplay", str(sound_path)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


class DictationApp:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.backend = build_backend(settings)
        self.recorder = MicRecorder(
            sample_rate=settings.sample_rate,
            channels=settings.channels,
        )

        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._is_recording = False
        self._is_transcribing = False

    def _toggle_recording(self) -> None:
        chunk: AudioChunk | None = None

        with self._lock:
            if self._is_transcribing:
                print("[busy] Still transcribing previous clip.")
                return

            if not self._is_recording:
                try:
                    self.recorder.start()
                except Exception as exc:  # noqa: BLE001
                    print(f"[error] Could not start recording: {exc}")
                    return

                self._is_recording = True
                _play_sound("Glass.aiff")
                print("[rec] Recording... press hotkey again to stop.")
                return

            try:
                chunk = self.recorder.stop()
            except RecorderError as exc:
                print(f"[error] Could not stop recording cleanly: {exc}")
                self._is_recording = False
                return

            self._is_recording = False
            self._is_transcribing = True

        _play_sound("Pop.aiff")
        worker = threading.Thread(
            target=self._transcribe_and_emit,
            args=(chunk,),
            daemon=True,
        )
        worker.start()

    def _transcribe_and_emit(self, chunk: AudioChunk) -> None:
        try:
            duration_seconds = 0.0
            if chunk.sample_rate > 0:
                duration_seconds = len(chunk.samples) / float(chunk.sample_rate)

            if duration_seconds < self.settings.min_seconds:
                print("[skip] Clip too short. Try speaking a bit longer.")
                return

            text = self.backend.transcribe(chunk.samples, chunk.sample_rate).strip()
            if not text:
                print("[skip] No speech detected.")
                return

            print(f"[text] {text}")
            if self.settings.autopaste:
                paste_text(text)
                print("[paste] Inserted at current cursor.")
        except Exception as exc:  # noqa: BLE001
            print(f"[error] Transcription failed: {exc}")
        finally:
            with self._lock:
                self._is_transcribing = False

    def _request_shutdown(self) -> None:
        with self._lock:
            if self._is_recording:
                try:
                    self.recorder.stop()
                except Exception:  # noqa: BLE001
                    pass
                self._is_recording = False
        print("[exit] Shutting down dictation app.")
        self._stop_event.set()

    def run(self) -> None:
        print(f"[ready] Backend: {self.backend.name}")
        print(f"[ready] Toggle dictation: {self.settings.hotkey}")
        print(f"[ready] Quit app: {self.settings.quit_hotkey}")

        keymap = {
            self.settings.hotkey: self._toggle_recording,
            self.settings.quit_hotkey: self._request_shutdown,
        }

        signal.signal(signal.SIGTERM, lambda *_: self._request_shutdown())

        listener = keyboard.GlobalHotKeys(keymap)
        listener.start()
        try:
            while not self._stop_event.is_set():
                time.sleep(0.15)
        except KeyboardInterrupt:
            self._request_shutdown()
        finally:
            listener.stop()

