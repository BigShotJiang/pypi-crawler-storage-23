"""Transcription backends."""
