from __future__ import annotations

from talk.backends.base import DictationBackend
from talk.config import Settings


def build_backend(settings: Settings) -> DictationBackend:
    if settings.backend == "parakeet":
        from talk.backends.parakeet_backend import ParakeetBackend

        return ParakeetBackend(model_id=settings.parakeet_model)

    if settings.backend == "openai":
        from talk.backends.openai_backend import OpenAIBackend

        return OpenAIBackend(
            api_key=settings.openai_api_key or "",
            model=settings.openai_model,
            language=settings.openai_language,
        )

    raise ValueError(
        f"Unknown DICTATE_BACKEND='{settings.backend}'. Use 'parakeet' or 'openai'."
    )
