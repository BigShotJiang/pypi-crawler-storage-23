from __future__ import annotations

import numpy as np

from talk.audio import to_wav_buffer


class OpenAIBackend:
    name = "openai"

    def __init__(self, api_key: str, model: str, language: str | None = None) -> None:
        if not api_key:
            raise ValueError("OPENAI_API_KEY is required for the OpenAI backend")

        from openai import OpenAI

        self._client = OpenAI(api_key=api_key)
        self.model = model
        self.language = language

    def transcribe(self, audio: np.ndarray, sample_rate: int) -> str:
        payload = {
            "model": self.model,
            "file": to_wav_buffer(audio, sample_rate),
        }
        if self.language:
            payload["language"] = self.language

        transcript = self._client.audio.transcriptions.create(**payload)
        text = getattr(transcript, "text", "")
        return (text or "").strip()
