from __future__ import annotations

from typing import Protocol

import numpy as np


class DictationBackend(Protocol):
    name: str

    def transcribe(self, audio: np.ndarray, sample_rate: int) -> str:
        """Convert mono float32 audio into text."""
