# Dictation Build Plan (Executed)

## Human-friendly plan

Build a simple, reliable "press hotkey, talk, text appears" loop that feels close to WisprFlow for laptop use.

- Prioritize **local transcription first** so per-use cost is effectively zero.
- Keep a **cloud fallback** for quality and edge cases.
- Make setup short enough to run in minutes.
- Avoid heavy UI work until the core dictation loop is proven.

## Task-focused plan

1. Research model/API options and choose architecture.
2. Scaffold Python app with environment-based config.
3. Implement global hotkey + microphone recorder.
4. Implement local Parakeet backend.
5. Implement OpenAI backend fallback.
6. Implement auto-paste insertion into active app on macOS.
7. Add docs and `.env.example`.
8. Smoke-test both backends with a sample WAV clip.
9. Verify live app starts and reports permission requirements clearly.

## Status

All steps above are complete in this repo.

## Onboarding hardening (completed)

To make this easy for other laptop users, the repo now includes:

1. `scripts/install_macos.sh` for one-command setup.
2. `scripts/doctor_macos.sh` for preflight checks.
3. `scripts/run_macos.sh` to launch dictation.
4. README guidance that starts with the script-based flow.
