#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "[error] This installer currently targets macOS." >&2
  exit 1
fi

if ! command -v uv >/dev/null 2>&1; then
  echo "[error] 'uv' is required but not installed." >&2
  if command -v brew >/dev/null 2>&1; then
    echo "Install it with: brew install uv" >&2
  else
    echo "Install instructions: https://docs.astral.sh/uv/getting-started/installation/" >&2
  fi
  exit 1
fi

python_version="$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>/dev/null || true)"
if [[ -z "$python_version" ]]; then
  echo "[error] Python 3 not found. Install Python 3.11+ first." >&2
  exit 1
fi
python_minor="${python_version#*.}"
if [[ "$python_minor" -lt 11 ]]; then
  echo "[error] Python >= 3.11 required (found $python_version)." >&2
  echo "Install a newer Python: brew install python@3.13" >&2
  exit 1
fi
echo "[setup] Python $python_version detected."

if [[ ! -f .env ]]; then
  cp .env.example .env
  echo "[setup] Created .env from .env.example"
fi

ensure_key_default() {
  local key="$1"
  local value="$2"
  if ! grep -q "^${key}=" .env; then
    printf '%s=%s\n' "$key" "$value" >> .env
    echo "[setup] Added default ${key}=${value}"
  fi
}

# Keep Parakeet as the default for fresh installs.
ensure_key_default "DICTATE_BACKEND" "parakeet"
ensure_key_default "DICTATE_HOTKEY" "<cmd>+<shift>+<space>"
ensure_key_default "DICTATE_QUIT_HOTKEY" "<cmd>+<shift>+q"
ensure_key_default "DICTATE_AUTOPASTE" "true"
ensure_key_default "PARAKEET_MODEL" "mlx-community/parakeet-tdt-0.6b-v3"

uv sync

echo ""
echo "[done] Installation complete."
echo "Next steps:"
echo "  1) ./scripts/doctor_macos.sh"
echo "  2) ./scripts/run_macos.sh"
