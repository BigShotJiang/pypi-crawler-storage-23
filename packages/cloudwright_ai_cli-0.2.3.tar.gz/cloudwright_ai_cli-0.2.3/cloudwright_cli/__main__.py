"""Allow running as `python3 -m cloudwright_cli`."""

from cloudwright_cli.main import app

app()
