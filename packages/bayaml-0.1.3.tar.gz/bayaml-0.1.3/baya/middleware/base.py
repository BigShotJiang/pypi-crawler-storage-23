class BaseMiddleware:
    def before(self, context):
        return None

    def after(self, context):
        return None
