def enforce_best_practices() -> list[str]:
    return ["Use train/test split before training", "Set random seed"]
