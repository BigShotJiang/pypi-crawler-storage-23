class Lineage:
    def link(self, parent: str, child: str) -> tuple[str, str]:
        return parent, child
