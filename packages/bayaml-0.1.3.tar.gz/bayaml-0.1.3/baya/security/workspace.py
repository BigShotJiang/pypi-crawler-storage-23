class WorkspacePolicy:
    def __init__(self, root: str) -> None:
        self.root = root
