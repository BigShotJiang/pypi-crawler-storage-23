class SeabornBackend:
    def available(self) -> bool:
        return True
