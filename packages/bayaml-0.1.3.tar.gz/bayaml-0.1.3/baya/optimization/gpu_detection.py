def gpu_available() -> bool:
    return False
