def parallel_map(fn, items):
    return [fn(x) for x in items]
