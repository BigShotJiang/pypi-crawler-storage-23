class BayaError(Exception):
    """Base framework exception."""
