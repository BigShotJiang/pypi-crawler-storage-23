"""
Setup script for diamond-quant package
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text() if readme_file.exists() else ""

setup(
    name="diamond-quant",
    version="0.2.0",
    description="Diamond Quant - MLB MCMC Prediction Tool",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Diamond Quant",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "fastapi>=0.104.0",
        "uvicorn>=0.24.0",
        "requests>=2.31.0",
        "python-dotenv>=1.0.0",
        "click>=8.1.0",
        "bcrypt>=4.0.0",
        "cryptography>=41.0.0",
        "psycopg2-binary>=2.9.0",
        "httpx>=0.25.0",
    ],
    entry_points={
        "console_scripts": [
            "diamond-quant=diamond_quant.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "diamond_quant": ["static/**/*"],
    },
)
