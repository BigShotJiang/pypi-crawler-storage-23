"""
Tier system for API key permissions
Defines tiers, limits, and permission checking functions
"""

from typing import Optional, Dict, Any
from enum import Enum

class APITier(str, Enum):
    """API key tiers"""
    ENDBOSS = "ENDBOSS"
    DIAMOND = "DIAMOND"
    GOLD = "GOLD"
    SILVER = "SILVER"
    BRONZE = "BRONZE"
    BASE = "BASE"

# Tier limits configuration
TIER_LIMITS = {
    APITier.ENDBOSS: {
        "max_sims_per_game": None,  # Unlimited
        "rate_limit_per_minute": None,  # Unlimited
        "ai_chat_requests_per_month": None,  # Unlimited
        "ai_chat_requests_per_minute": None,  # Unlimited
        "can_access_models": True,
    },
    APITier.DIAMOND: {
        "max_sims_per_game": 2_000_000,
        "rate_limit_per_minute": 1000,  # Very high
        "ai_chat_requests_per_month": None,  # Unlimited
        "ai_chat_requests_per_minute": None,  # Unlimited
        "can_access_models": False,
    },
    APITier.GOLD: {
        "max_sims_per_game": 500_000,
        "rate_limit_per_minute": 500,
        "ai_chat_requests_per_month": 1000,
        "ai_chat_requests_per_minute": 20,
        "can_access_models": False,
    },
    APITier.SILVER: {
        "max_sims_per_game": 100_000,
        "rate_limit_per_minute": 200,
        "ai_chat_requests_per_month": 500,
        "ai_chat_requests_per_minute": 10,
        "can_access_models": False,
    },
    APITier.BRONZE: {
        "max_sims_per_game": 50_000,
        "rate_limit_per_minute": 100,
        "ai_chat_requests_per_month": 250,
        "ai_chat_requests_per_minute": 5,
        "can_access_models": False,
    },
    APITier.BASE: {
        "max_sims_per_game": 10_000,
        "rate_limit_per_minute": 50,  # Most restrictive
        "ai_chat_requests_per_month": 100,
        "ai_chat_requests_per_minute": 2,
        "can_access_models": False,
    },
}

def get_tier_limits(tier: Optional[str]) -> Dict[str, Any]:
    """Get limits for a given tier"""
    if not tier:
        tier = APITier.BASE.value
    
    try:
        tier_enum = APITier(tier.upper())
    except ValueError:
        tier_enum = APITier.BASE
    
    return TIER_LIMITS.get(tier_enum, TIER_LIMITS[APITier.BASE])

def can_access_models(tier: Optional[str]) -> bool:
    """Check if tier can access MODELS tab"""
    limits = get_tier_limits(tier)
    return limits.get("can_access_models", False)

def get_max_sims_per_game(tier: Optional[str]) -> Optional[int]:
    """Get max simulations per game for tier"""
    limits = get_tier_limits(tier)
    return limits.get("max_sims_per_game")

def get_rate_limit_per_minute(tier: Optional[str]) -> Optional[int]:
    """Get rate limit per minute for tier"""
    limits = get_tier_limits(tier)
    return limits.get("rate_limit_per_minute")

def get_ai_chat_monthly_limit(tier: Optional[str]) -> Optional[int]:
    """Get monthly AI chat request limit for tier"""
    limits = get_tier_limits(tier)
    return limits.get("ai_chat_requests_per_month")

def get_ai_chat_per_minute_limit(tier: Optional[str]) -> Optional[int]:
    """Get per-minute AI chat request limit for tier"""
    limits = get_tier_limits(tier)
    return limits.get("ai_chat_requests_per_minute")

def validate_tier(tier: str) -> bool:
    """Validate that tier is a valid tier name"""
    try:
        APITier(tier.upper())
        return True
    except ValueError:
        return False
