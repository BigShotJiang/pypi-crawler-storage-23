globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2852f09a196828e3.js",
    "static/chunks/c2059af7508aa63c.js",
    "static/chunks/a3288e8b9e4e81b3.js",
    "static/chunks/4535414c71787aad.js",
    "static/chunks/turbopack-944b7897342c1ab6.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];