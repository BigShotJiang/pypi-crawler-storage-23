module.exports=[77346,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app__global-error_page_actions_33753f04.js.map