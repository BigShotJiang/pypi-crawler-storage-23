# ZeroClaw — Zero-Config Remote Agent & Instant Machine Access for Python

[![PyPI](https://img.shields.io/pypi/v/zeroclaw.svg)](https://pypi.org/project/zeroclaw/) [![Python](https://img.shields.io/pypi/pyversions/zeroclaw.svg)](https://pypi.org/project/zeroclaw/) [![license](https://img.shields.io/pypi/l/zeroclaw.svg)](https://github.com/commandoperator/cmdop-sdk-python/blob/main/LICENSE)

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

ZeroClaw delivers zero-config remote access Python capabilities, unlike Paramiko, Fabric, SSH2, or Ansible. Deploy an instant machine agent and obtain a no-setup remote shell. This plug-and-play AI agent integrates machine access directly into your Python code, simplifying remote operations and automation workflows.

## Features

- Establish zero-config remote access Python instances rapidly.
- Deploy an instant machine agent without manual configuration.
- Execute a no-setup remote shell using a simple API call.
- Incorporate a plug-and-play AI agent into existing Python projects.
- Automate remote tasks and workflows with minimal overhead.

## Use Cases

- Connect to a remote machine with a single API key, no configuration needed
- Run shell commands and agent tasks instantly without any setup
- Integrate remote machine control into any Python script in minutes

## Installation

```bash
pip install zeroclaw
```

## Quick Start

```python
from zeroclaw import ZeroClaw

client = ZeroClaw.remote(api_key="cmdop_live_xxx")

# One line — no SSH config, no keys
output = client.agent.run("uptime && df -h && free -m")
print(output.text)

# Ask the AI
answer = client.agent.run("What process is using the most memory?")
print(answer.text)
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [Documentation](https://cmdop.com/docs/sdk/python/)
- [zeroclaw on PyPI](https://pypi.org/project/zeroclaw/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk-python)
