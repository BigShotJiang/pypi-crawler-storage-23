# type: ignore

"""Command line interface for PyStow."""

from .cli import main

if __name__ == "__main__":
    main()
