[![Contributor Covenant](https://img.shields.io/badge/Contributor%20Covenant-2.1-4baaaa.svg)](CODE_OF_CONDUCT.md)
[![PyPI badge](http://img.shields.io/pypi/v/EasyScience.svg)](https://pypi.python.org/pypi/EasyScience)
[![License: BSD 3-Clause](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](LICENSE)
[![codecov](https://codecov.io/github/EasyScience/corelib/graph/badge.svg?token=wc6Q0j0Q9t)](https://codecov.io/github/EasyScience/corelib)

# Easyscience

## About

EasyScience package is the foundation of the EasyScience family of projects, providing the building blocks for libraries and applications
which aim to make scientific data simulation and analysis easier.

## Install

**EasyScience** can be downloaded using pip:

```pip install easyscience```

Or direct from the repository:

```pip install https://github.com/easyScience/EasyScience```

### Development

For development setup and workflow instructions, please see [CONTRIBUTING.md](CONTRIBUTING.md).

## Test

After installation, launch the test suite:

```python -m pytest```

## Documentation

Documentation can be found at:

[https://easyScience.github.io/corelib](https://easyScience.github.io/corelib)

## Contributing
We absolutely welcome contributions. **EasyScience** is maintained by the ESS and on a volunteer basis and thus we need to foster a community that can support user questions and develop new features to make this software a useful tool for all users while encouraging every member of the community to share their ideas.

## License
While **EasyScience** is under the BSD-3 license, DFO-LS is subject to the GPL license.


