from dbt.tests.adapter.utils.test_last_day import BaseLastDay


class TestLastDayFabric(BaseLastDay):
    pass
