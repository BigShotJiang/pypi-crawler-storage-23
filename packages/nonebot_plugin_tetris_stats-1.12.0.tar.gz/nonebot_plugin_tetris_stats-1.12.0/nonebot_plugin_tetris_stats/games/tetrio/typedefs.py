from typing import Literal

Template = Literal['v1', 'v2']
