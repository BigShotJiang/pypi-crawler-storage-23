from importlib.metadata import version

__version__ = version('nonebot_plugin_tetris_stats')
