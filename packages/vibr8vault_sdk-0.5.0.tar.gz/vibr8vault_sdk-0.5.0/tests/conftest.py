from __future__ import annotations

import pytest

from vibr8vault import Vibr8Vault


@pytest.fixture
def client() -> Vibr8Vault:
    return Vibr8Vault(address="http://localhost:8200", token="ov_test")
