from __future__ import annotations

import httpx
import pytest
from pytest_httpx import HTTPXMock

from vibr8vault import Vibr8Vault, Vibr8VaultError


# ---------------------------------------------------------------------------
# Secrets
# ---------------------------------------------------------------------------


class TestSecrets:
    def test_read_secret(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "path": "apps/prod", "version": 1,
            "data": {"KEY": "val"}, "created_at": "2026-01-01T00:00:00Z",
        })

        secret = client.secrets.read("apps/prod")
        assert secret["data"]["KEY"] == "val"

        req = httpx_mock.get_request()
        assert req is not None
        assert req.url == "http://localhost:8200/v1/secrets/apps/prod"
        assert req.method == "GET"

    def test_read_specific_version(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "path": "x", "version": 2, "data": {}, "created_at": "",
        })

        client.secrets.read("x", version=2)

        req = httpx_mock.get_request()
        assert req is not None
        assert str(req.url) == "http://localhost:8200/v1/secrets/x?version=2"

    def test_write_secret(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "path": "apps/prod", "version": 1, "created_at": "",
        })

        resp = client.secrets.write("apps/prod", {"DB_PASS": "secret"})
        assert resp["version"] == 1

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "PUT"
        assert str(req.url) == "http://localhost:8200/v1/secrets/apps/prod"

    def test_delete_secret(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=204)

        client.secrets.delete("apps/prod")

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "DELETE"
        assert str(req.url) == "http://localhost:8200/v1/secrets/apps/prod"

    def test_hard_delete(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=204)

        client.secrets.delete("apps/prod", hard=True)

        req = httpx_mock.get_request()
        assert req is not None
        assert str(req.url) == "http://localhost:8200/v1/secrets/apps/prod?hard=true"

    def test_list_secrets(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"keys": ["apps/a", "apps/b"]})

        resp = client.secrets.list("apps/")
        assert resp["keys"] == ["apps/a", "apps/b"]

    def test_versions(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "versions": [{"version": 1, "created_at": "2026-01-01T00:00:00Z", "deleted": False}],
        })

        resp = client.secrets.versions("apps/prod")
        assert len(resp["versions"]) == 1
        assert resp["versions"][0]["version"] == 1


# ---------------------------------------------------------------------------
# Tokens
# ---------------------------------------------------------------------------


class TestTokens:
    def test_create_token(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "id": "tok_1", "token": "ov_new", "type": "service",
            "expires_at": "", "policies": ["default"],
        })

        resp = client.tokens.create(type="service", policies=["default"])
        assert resp["token"] == "ov_new"

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "POST"
        assert str(req.url) == "http://localhost:8200/auth/tokens"

    def test_revoke_token(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=204)

        client.tokens.revoke("tok_1")

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "DELETE"
        assert str(req.url) == "http://localhost:8200/auth/tokens/tok_1"

    def test_list_tokens(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"tokens": []})

        resp = client.tokens.list()
        assert resp["tokens"] == []


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


class TestAuth:
    def test_login(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "token": "ov_session", "expires_at": "",
            "user": {"id": "1", "username": "alice", "admin": False},
        })

        resp = client.auth.login("alice", "pass123")
        assert resp["token"] == "ov_session"

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "POST"
        assert str(req.url) == "http://localhost:8200/auth/login"

    def test_me(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "admin": False, "policies": ["default"], "token_type": "service",
        })

        resp = client.auth.me()
        assert resp["token_type"] == "service"


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------


class TestUsers:
    def test_create_user(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "id": "u1", "username": "bob", "policies": [],
            "admin": False, "created_at": "", "updated_at": "",
        })

        resp = client.users.create("bob", "secret")
        assert resp["username"] == "bob"

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "POST"
        assert str(req.url) == "http://localhost:8200/auth/users"

    def test_list_users(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"users": []})

        resp = client.users.list()
        assert resp["users"] == []

    def test_get_user(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "id": "u1", "username": "bob", "policies": [],
            "admin": False, "created_at": "", "updated_at": "",
        })

        resp = client.users.get("u1")
        assert resp["id"] == "u1"

    def test_update_user(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "id": "u1", "username": "bob", "policies": ["admin"],
            "admin": False, "created_at": "", "updated_at": "",
        })

        resp = client.users.update("u1", policies=["admin"])
        assert resp["policies"] == ["admin"]

    def test_delete_user(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=204)

        client.users.delete("u1")

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "DELETE"
        assert str(req.url) == "http://localhost:8200/auth/users/u1"


# ---------------------------------------------------------------------------
# Sys
# ---------------------------------------------------------------------------


class TestSys:
    def test_health(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"status": "ok"})

        resp = client.sys.health()
        assert resp["status"] == "ok"

    def test_status(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"sealed": True, "initialized": False})

        resp = client.sys.status()
        assert resp["sealed"] is True

    def test_unseal(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"sealed": False})

        resp = client.sys.unseal("shard-key-1")
        assert resp["sealed"] is False

    def test_seal(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=204)

        client.sys.seal()

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "POST"
        assert str(req.url) == "http://localhost:8200/sys/seal"


# ---------------------------------------------------------------------------
# Namespaces
# ---------------------------------------------------------------------------


class TestNamespaces:
    def test_list_namespaces(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "namespaces": [{"name": "default", "owner": "", "type": "default", "created_at": ""}],
        })

        resp = client.namespaces.list()
        assert len(resp["namespaces"]) == 1

        req = httpx_mock.get_request()
        assert req is not None
        assert str(req.url) == "http://localhost:8200/v1/namespaces"

    def test_get_namespace(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "name": "default", "owner": "", "type": "default", "created_at": "",
        })

        resp = client.namespaces.get("default")
        assert resp["name"] == "default"

    def test_create_namespace(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=201, json={
            "name": "team-backend", "owner": "", "type": "shared", "created_at": "",
        })

        resp = client.namespaces.create("team-backend")
        assert resp["name"] == "team-backend"

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "POST"

    def test_delete_namespace(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=204)

        client.namespaces.delete("team-backend")

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "DELETE"
        assert str(req.url) == "http://localhost:8200/v1/namespaces/team-backend"


# ---------------------------------------------------------------------------
# Namespace-scoped secrets
# ---------------------------------------------------------------------------


class TestNamespaceScopedSecrets:
    def test_read_ns(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "path": "apps/prod", "version": 1, "data": {"KEY": "val"}, "created_at": "",
        })

        client.secrets.read_ns("team", "apps/prod")

        req = httpx_mock.get_request()
        assert req is not None
        assert str(req.url) == "http://localhost:8200/v1/namespaces/team/secrets/apps/prod"

    def test_write_ns(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"path": "x", "version": 1, "created_at": ""})

        client.secrets.write_ns("team", "x", {"K": "v"})

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "PUT"
        assert str(req.url) == "http://localhost:8200/v1/namespaces/team/secrets/x"

    def test_list_ns(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"keys": ["a", "b"]})

        client.secrets.list_ns("team", "apps/")

        req = httpx_mock.get_request()
        assert req is not None
        assert str(req.url) == "http://localhost:8200/v1/namespaces/team/secrets/apps/?list=true"

    def test_delete_ns(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=204)

        client.secrets.delete_ns("team", "apps/prod")

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "DELETE"
        assert str(req.url) == "http://localhost:8200/v1/namespaces/team/secrets/apps/prod"

    def test_delete_ns_hard(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=204)

        client.secrets.delete_ns("team", "apps/prod", hard=True)

        req = httpx_mock.get_request()
        assert req is not None
        assert str(req.url) == "http://localhost:8200/v1/namespaces/team/secrets/apps/prod?hard=true"

    def test_versions_ns(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "versions": [{"version": 1, "created_at": "2026-01-01T00:00:00Z", "deleted": False}],
        })

        resp = client.secrets.versions_ns("team", "apps/prod")
        assert len(resp["versions"]) == 1

        req = httpx_mock.get_request()
        assert req is not None
        assert str(req.url) == "http://localhost:8200/v1/namespaces/team/secrets/apps/prod?versions=true"


# ---------------------------------------------------------------------------
# Policies
# ---------------------------------------------------------------------------


class TestPolicies:
    def test_list_default_ns(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"policies": ["read-only"]})

        resp = client.policies.list()
        assert resp["policies"] == ["read-only"]

        req = httpx_mock.get_request()
        assert req is not None
        assert str(req.url) == "http://localhost:8200/auth/policies"

    def test_list_specific_ns(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"policies": ["admin"]})

        client.policies.list("team")

        req = httpx_mock.get_request()
        assert req is not None
        assert str(req.url) == "http://localhost:8200/v1/namespaces/team/policies"

    def test_create_in_ns(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"name": "admin", "yaml": ""})

        client.policies.create("name: admin\nrules: []", "team")

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "POST"
        assert str(req.url) == "http://localhost:8200/v1/namespaces/team/policies"

    def test_delete_in_ns(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=204)

        client.policies.delete("admin", "team")

        req = httpx_mock.get_request()
        assert req is not None
        assert req.method == "DELETE"
        assert str(req.url) == "http://localhost:8200/v1/namespaces/team/policies/admin"

    def test_get_policy(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"name": "read-only", "yaml": "name: read-only\nrules: []"})

        resp = client.policies.get("read-only")
        assert resp["name"] == "read-only"

        req = httpx_mock.get_request()
        assert req is not None
        assert str(req.url) == "http://localhost:8200/auth/policies/read-only"

    def test_get_policy_in_ns(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"name": "admin", "yaml": ""})

        resp = client.policies.get("admin", "team")
        assert resp["name"] == "admin"

        req = httpx_mock.get_request()
        assert req is not None
        assert str(req.url) == "http://localhost:8200/v1/namespaces/team/policies/admin"


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_4xx_raises_error(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=404, json={"error": "not found"})

        with pytest.raises(Vibr8VaultError):
            client.secrets.read("missing")

    def test_error_has_status(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=403, json={"error": "forbidden"})

        with pytest.raises(Vibr8VaultError) as exc_info:
            client.secrets.read("forbidden-path")

        assert exc_info.value.status == 403
        assert str(exc_info.value) == "forbidden"

    def test_5xx_raises_error(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=500, json={"error": "internal error"})

        with pytest.raises(Vibr8VaultError):
            client.sys.health()

    def test_non_json_error_body(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=502, text="Bad Gateway")

        with pytest.raises(Vibr8VaultError):
            client.sys.health()


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


class TestConfiguration:
    def test_strips_trailing_slash(self, httpx_mock: HTTPXMock) -> None:
        c = Vibr8Vault(address="http://localhost:8200/", token="ov_test")
        httpx_mock.add_response(json={"status": "ok"})

        c.sys.health()

        req = httpx_mock.get_request()
        assert req is not None
        assert str(req.url) == "http://localhost:8200/sys/health"

    def test_sends_auth_header(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"status": "ok"})

        client.sys.health()

        req = httpx_mock.get_request()
        assert req is not None
        assert req.headers["authorization"] == "Bearer ov_test"

    def test_set_token(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        client.set_token("ov_new_token")
        httpx_mock.add_response(json={"status": "ok"})

        client.sys.health()

        req = httpx_mock.get_request()
        assert req is not None
        assert req.headers["authorization"] == "Bearer ov_new_token"

    def test_no_auth_header_without_token(self, httpx_mock: HTTPXMock) -> None:
        anon = Vibr8Vault(address="http://localhost:8200")
        httpx_mock.add_response(json={"status": "ok"})

        anon.sys.health()

        req = httpx_mock.get_request()
        assert req is not None
        assert "authorization" not in req.headers

    def test_content_type_for_body(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"path": "x", "version": 1, "created_at": ""})

        client.secrets.write("x", {"KEY": "val"})

        req = httpx_mock.get_request()
        assert req is not None
        assert req.headers["content-type"] == "application/json"

    def test_close(self, httpx_mock: HTTPXMock) -> None:
        vault = Vibr8Vault(address="http://localhost:8200", token="ov_test")
        vault.close()

    def test_context_manager(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={"status": "ok"})

        with Vibr8Vault(address="http://localhost:8200", token="ov_test") as vault:
            resp = vault.sys.health()
            assert resp["status"] == "ok"


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_tokens_create_all_params(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "id": "tok_1", "token": "ov_new", "type": "ephemeral",
            "expires_at": "", "policies": ["ci"],
        })

        resp = client.tokens.create(type="ephemeral", ttl="1h", policies=["ci"], max_uses=5)
        assert resp["type"] == "ephemeral"

        req = httpx_mock.get_request()
        assert req is not None
        import json
        body = json.loads(req.content)
        assert body["type"] == "ephemeral"
        assert body["ttl"] == "1h"
        assert body["policies"] == ["ci"]
        assert body["max_uses"] == 5

    def test_users_create_with_policies(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "id": "u1", "username": "bob", "policies": ["admin"],
            "admin": False, "created_at": "", "updated_at": "",
        })

        resp = client.users.create("bob", "secret", policies=["admin"])
        assert resp["policies"] == ["admin"]

        req = httpx_mock.get_request()
        assert req is not None
        import json
        body = json.loads(req.content)
        assert body["policies"] == ["admin"]

    def test_users_update_with_password(self, client: Vibr8Vault, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(json={
            "id": "u1", "username": "bob", "policies": [],
            "admin": False, "created_at": "", "updated_at": "",
        })

        client.users.update("u1", password="newpass")

        req = httpx_mock.get_request()
        assert req is not None
        import json
        body = json.loads(req.content)
        assert body["password"] == "newpass"
