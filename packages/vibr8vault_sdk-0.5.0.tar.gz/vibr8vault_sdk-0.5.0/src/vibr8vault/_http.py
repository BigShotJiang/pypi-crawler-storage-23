from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

from .errors import Vibr8VaultError


class HTTPTransport:
    """Low-level HTTP transport for the Vibr8Vault REST API."""

    def __init__(self, address: str, token: Optional[str] = None) -> None:
        self._address = address.rstrip("/")
        self._token = token
        self._client = httpx.Client(timeout=15.0)

    @property
    def token(self) -> Optional[str]:
        return self._token

    @token.setter
    def token(self, value: Optional[str]) -> None:
        self._token = value

    def request(self, method: str, path: str, body: Any = None) -> Any:
        headers: Dict[str, str] = {}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        if body is not None:
            headers["Content-Type"] = "application/json"

        resp = self._client.request(
            method,
            f"{self._address}{path}",
            headers=headers,
            json=body if body is not None else None,
        )

        if resp.status_code < 200 or resp.status_code >= 300:
            message = f"HTTP {resp.status_code}"
            try:
                err = resp.json()
                if isinstance(err, dict) and err.get("error"):
                    message = err["error"]
            except Exception:
                pass
            raise Vibr8VaultError(message, resp.status_code, resp)

        if resp.status_code == 204:
            return None

        return resp.json()

    def close(self) -> None:
        self._client.close()
