from __future__ import annotations

from typing import Any


class Vibr8VaultError(Exception):
    """Raised when the Vibr8Vault API returns a non-2xx response."""

    def __init__(self, message: str, status: int, response: Any = None) -> None:
        super().__init__(message)
        self.status = status
        self.response = response
