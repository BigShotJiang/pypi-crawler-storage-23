from __future__ import annotations

from typing import Dict, List, Optional
from typing_extensions import TypedDict


class SecretResponse(TypedDict):
    path: str
    version: int
    data: Dict[str, str]
    created_at: str


class WriteResponse(TypedDict):
    path: str
    version: int
    created_at: str


class VersionInfo(TypedDict):
    version: int
    created_at: str
    deleted: bool


class VersionsResponse(TypedDict):
    versions: List[VersionInfo]


class ListResponse(TypedDict):
    keys: List[str]


class TokenResponse(TypedDict):
    id: str
    token: str
    type: str
    expires_at: str
    policies: List[str]


class TokenListItem(TypedDict):
    id: str
    type: str
    policies: List[str]
    expires_at: str
    created_at: str


class TokenListResponse(TypedDict):
    tokens: List[TokenListItem]


class TokenCreateOpts(TypedDict, total=False):
    type: str
    ttl: str
    policies: List[str]
    max_uses: int


class LoginUser(TypedDict):
    id: str
    username: str
    admin: bool


class LoginResponse(TypedDict):
    token: str
    expires_at: str
    user: LoginUser


class MeResponse(TypedDict):
    admin: bool
    policies: List[str]
    token_type: str


class HealthResponse(TypedDict):
    status: str


class StatusResponse(TypedDict):
    sealed: bool
    initialized: bool


class UnsealResponse(TypedDict):
    sealed: bool


class UserResponse(TypedDict):
    id: str
    username: str
    policies: List[str]
    admin: bool
    created_at: str
    updated_at: str


class UserListResponse(TypedDict):
    users: List[UserResponse]


class UserCreateOpts(TypedDict, total=False):
    username: str
    password: str
    policies: List[str]


class NamespaceResponse(TypedDict):
    name: str
    owner: str
    type: str
    created_at: str


class NamespaceListResponse(TypedDict):
    namespaces: List[NamespaceResponse]


class PolicyResponse(TypedDict):
    name: str
    yaml: str


class PolicyListResponse(TypedDict):
    policies: List[str]
