from __future__ import annotations

from typing import Any, Dict, List, Optional
from urllib.parse import quote

from ._http import HTTPTransport
from .types import (
    HealthResponse,
    ListResponse,
    LoginResponse,
    MeResponse,
    NamespaceListResponse,
    NamespaceResponse,
    PolicyListResponse,
    PolicyResponse,
    SecretResponse,
    StatusResponse,
    TokenListResponse,
    TokenResponse,
    UnsealResponse,
    UserListResponse,
    UserResponse,
    VersionsResponse,
    WriteResponse,
)


class Vibr8Vault:
    """Client for the Vibr8Vault secrets manager REST API."""

    def __init__(self, address: str, token: Optional[str] = None) -> None:
        self._http = HTTPTransport(address, token)
        self.secrets = self._Secrets(self._http)
        self.tokens = self._Tokens(self._http)
        self.auth = self._Auth(self._http)
        self.users = self._Users(self._http)
        self.sys = self._Sys(self._http)
        self.namespaces = self._Namespaces(self._http)
        self.policies = self._Policies(self._http)

    def set_token(self, token: Optional[str]) -> None:
        self._http.token = token

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> Vibr8Vault:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    @staticmethod
    def _enc(segment: str) -> str:
        return quote(segment, safe="")

    class _Secrets:
        def __init__(self, http: HTTPTransport) -> None:
            self._http = http

        def read(self, path: str, version: Optional[int] = None) -> SecretResponse:
            url = f"/v1/secrets/{path}"
            if version is not None:
                url += f"?version={version}"
            return self._http.request("GET", url)

        def write(self, path: str, data: Dict[str, str]) -> WriteResponse:
            return self._http.request("PUT", f"/v1/secrets/{path}", {"data": data})

        def delete(self, path: str, hard: bool = False) -> None:
            url = f"/v1/secrets/{path}"
            if hard:
                url += "?hard=true"
            self._http.request("DELETE", url)

        def list(self, prefix: str) -> ListResponse:
            return self._http.request("GET", f"/v1/secrets/{prefix}?list=true")

        def versions(self, path: str) -> VersionsResponse:
            return self._http.request("GET", f"/v1/secrets/{path}?versions=true")

        def read_ns(self, ns: str, path: str, version: Optional[int] = None) -> SecretResponse:
            url = f"/v1/namespaces/{Vibr8Vault._enc(ns)}/secrets/{path}"
            if version is not None:
                url += f"?version={version}"
            return self._http.request("GET", url)

        def write_ns(self, ns: str, path: str, data: Dict[str, str]) -> WriteResponse:
            return self._http.request(
                "PUT", f"/v1/namespaces/{Vibr8Vault._enc(ns)}/secrets/{path}", {"data": data}
            )

        def delete_ns(self, ns: str, path: str, hard: bool = False) -> None:
            url = f"/v1/namespaces/{Vibr8Vault._enc(ns)}/secrets/{path}"
            if hard:
                url += "?hard=true"
            self._http.request("DELETE", url)

        def list_ns(self, ns: str, prefix: str) -> ListResponse:
            return self._http.request(
                "GET", f"/v1/namespaces/{Vibr8Vault._enc(ns)}/secrets/{prefix}?list=true"
            )

        def versions_ns(self, ns: str, path: str) -> VersionsResponse:
            return self._http.request(
                "GET", f"/v1/namespaces/{Vibr8Vault._enc(ns)}/secrets/{path}?versions=true"
            )

    class _Tokens:
        def __init__(self, http: HTTPTransport) -> None:
            self._http = http

        def list(self) -> TokenListResponse:
            return self._http.request("GET", "/auth/tokens")

        def create(
            self,
            type: Optional[str] = None,
            ttl: Optional[str] = None,
            policies: Optional[List[str]] = None,
            max_uses: Optional[int] = None,
        ) -> TokenResponse:
            body: Dict[str, Any] = {}
            if type is not None:
                body["type"] = type
            if ttl is not None:
                body["ttl"] = ttl
            if policies is not None:
                body["policies"] = policies
            if max_uses is not None:
                body["max_uses"] = max_uses
            return self._http.request("POST", "/auth/tokens", body)

        def revoke(self, id: str) -> None:
            self._http.request("DELETE", f"/auth/tokens/{id}")

    class _Auth:
        def __init__(self, http: HTTPTransport) -> None:
            self._http = http

        def login(self, username: str, password: str) -> LoginResponse:
            return self._http.request("POST", "/auth/login", {"username": username, "password": password})

        def me(self) -> MeResponse:
            return self._http.request("GET", "/auth/me")

    class _Users:
        def __init__(self, http: HTTPTransport) -> None:
            self._http = http

        def create(
            self, username: str, password: str, policies: Optional[List[str]] = None
        ) -> UserResponse:
            body: Dict[str, Any] = {"username": username, "password": password}
            if policies is not None:
                body["policies"] = policies
            return self._http.request("POST", "/auth/users", body)

        def list(self) -> UserListResponse:
            return self._http.request("GET", "/auth/users")

        def get(self, id: str) -> UserResponse:
            return self._http.request("GET", f"/auth/users/{id}")

        def update(
            self, id: str, password: Optional[str] = None, policies: Optional[List[str]] = None
        ) -> UserResponse:
            body: Dict[str, Any] = {}
            if password is not None:
                body["password"] = password
            if policies is not None:
                body["policies"] = policies
            return self._http.request("PUT", f"/auth/users/{id}", body)

        def delete(self, id: str) -> None:
            self._http.request("DELETE", f"/auth/users/{id}")

    class _Sys:
        def __init__(self, http: HTTPTransport) -> None:
            self._http = http

        def health(self) -> HealthResponse:
            return self._http.request("GET", "/sys/health")

        def status(self) -> StatusResponse:
            return self._http.request("GET", "/sys/status")

        def unseal(self, key: str) -> UnsealResponse:
            return self._http.request("POST", "/sys/unseal", {"key": key})

        def seal(self) -> None:
            self._http.request("POST", "/sys/seal")

    class _Namespaces:
        def __init__(self, http: HTTPTransport) -> None:
            self._http = http

        def list(self) -> NamespaceListResponse:
            return self._http.request("GET", "/v1/namespaces")

        def get(self, name: str) -> NamespaceResponse:
            return self._http.request("GET", f"/v1/namespaces/{Vibr8Vault._enc(name)}")

        def create(self, name: str) -> NamespaceResponse:
            return self._http.request("POST", "/v1/namespaces", {"name": name})

        def delete(self, name: str) -> None:
            self._http.request("DELETE", f"/v1/namespaces/{Vibr8Vault._enc(name)}")

    class _Policies:
        def __init__(self, http: HTTPTransport) -> None:
            self._http = http

        def list(self, ns: Optional[str] = None) -> PolicyListResponse:
            base = f"/v1/namespaces/{Vibr8Vault._enc(ns)}/policies" if ns else "/auth/policies"
            return self._http.request("GET", base)

        def get(self, name: str, ns: Optional[str] = None) -> PolicyResponse:
            base = f"/v1/namespaces/{Vibr8Vault._enc(ns)}/policies" if ns else "/auth/policies"
            return self._http.request("GET", f"{base}/{Vibr8Vault._enc(name)}")

        def create(self, yaml: str, ns: Optional[str] = None) -> PolicyResponse:
            base = f"/v1/namespaces/{Vibr8Vault._enc(ns)}/policies" if ns else "/auth/policies"
            return self._http.request("POST", base, {"yaml": yaml})

        def delete(self, name: str, ns: Optional[str] = None) -> None:
            base = f"/v1/namespaces/{Vibr8Vault._enc(ns)}/policies" if ns else "/auth/policies"
            self._http.request("DELETE", f"{base}/{Vibr8Vault._enc(name)}")
