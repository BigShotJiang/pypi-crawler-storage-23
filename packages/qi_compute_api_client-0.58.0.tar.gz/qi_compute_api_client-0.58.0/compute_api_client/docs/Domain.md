# Domain


## Enum

* `COMPUTE` (value: `'compute'`)

* `NETWORKING` (value: `'networking'`)

* `SIMULATE` (value: `'simulate'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


