# ShareType


## Enum

* `PRIVATE` (value: `'private'`)

* `LINK_ONLY` (value: `'link_only'`)

* `TEAM` (value: `'team'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


