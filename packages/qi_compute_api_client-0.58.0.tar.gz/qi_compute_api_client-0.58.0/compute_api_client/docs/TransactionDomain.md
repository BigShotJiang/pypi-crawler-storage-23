# TransactionDomain

The domain type of the transaction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from compute_api_client.models.transaction_domain import TransactionDomain

# TODO update the JSON string below
json = "{}"
# create an instance of TransactionDomain from a JSON string
transaction_domain_instance = TransactionDomain.from_json(json)
# print the JSON string representation of the object
print TransactionDomain.to_json()

# convert the object into a dict
transaction_domain_dict = transaction_domain_instance.to_dict()
# create an instance of TransactionDomain from a dict
transaction_domain_form_dict = transaction_domain.from_dict(transaction_domain_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


