import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib
from conexionBD import *

bd = ConexionBD("BDbiblioteca.db")
bd.conectaBD()
bd.creaCursor()

bd.engadeRexistro("""
    CREATE TABLE IF NOT EXISTS libros (
        id TEXT PRIMARY KEY,
        titulo TEXT,
        autor TEXT,
        ano TEXT,
        disponible INTEGER DEFAULT 0
    )
""")


def al_pulsar_buscar(boton):
    """
    Gestiona la búsqueda de libros en la base de datos.

    Obtiene el texto de la entrada de búsqueda y filtra por título, autor o ID.
    Si hay resultados, abre la ficha del libro; si no, muestra un aviso emergente.
    """
    texto = entrada_texto_busqueda.get_text()
    sql = "SELECT id, titulo, autor, ano, disponible FROM libros WHERE titulo LIKE ? OR autor LIKE ? OR id LIKE ?"
    resultados = bd.consultaConParametros(sql, f"%{texto}%", f"%{texto}%", f"%{texto}%")

    if resultados:
        ficha_libro(boton, resultados)
    else:
        mensaxe_merxente("No se han encontrado resultados.")


def al_doble_clic(tree_view, path, column):
    """
    Carga los datos de un libro seleccionado desde la lista al formulario de edición.

    :param tree_view: El widget TreeView que contiene los datos.
    :param path: La ruta de la fila seleccionada.
    """
    modelo = tree_view.get_model()
    iterador = modelo.get_iter(path)

    ent_id.set_text(str(modelo.get_value(iterador, 0)))
    ent_titulo.set_text(str(modelo.get_value(iterador, 1)))
    ent_autor.set_text(str(modelo.get_value(iterador, 2)))
    ent_ano.set_text(str(modelo.get_value(iterador, 3)))

    estado_texto = modelo.get_value(iterador, 4)
    check_disponible.set_active(True if estado_texto == "Si" else False)

    pestaña.set_current_page(1)
    tree_view.get_toplevel().destroy()


def al_pulsar_insertar(boton):
    """
    Inserta o actualiza un registro de libro en la base de datos.

    Recoge los datos del formulario, valida que el ID y el Título no estén vacíos,
    y guarda la información. Finalmente, limpia el formulario para un nuevo uso.
    """
    id_f = ent_id.get_text()
    tit_f = ent_titulo.get_text()
    aut_f = ent_autor.get_text()
    ano_f = ent_ano.get_text()
    disp_f = 1 if check_disponible.get_active() else 0

    if not id_f or not tit_f:
        mensaxe_merxente("Error: ID y Título son obligatorios.")
        return

    sql = "INSERT OR REPLACE INTO libros (id, titulo, autor, ano, disponible) VALUES (?, ?, ?, ?, ?)"
    bd.engadeRexistro(sql, id_f, tit_f, aut_f, ano_f, disp_f)
    for e in [ent_id, ent_titulo, ent_autor, ent_ano]: e.set_text("")
    check_disponible.set_active(True)
    mensaxe_merxente("Libro guardado con éxito.")


def al_pulsar_borrar(boton):
    """
    Elimina el libro seleccionado tras una confirmación del usuario mediante un diálogo.
    """
    id_lib = ent_id.get_text()
    if id_lib:
        confirmado = confirmar_accion("Borrar libro", "¿Está seguro de que desea eliminar este libro?")

        if confirmado:
            sql = "DELETE FROM libros WHERE id = ?"
            bd.borraRexistro(sql, id_lib)

            for e in [ent_id, ent_titulo, ent_autor, ent_ano]: e.set_text("")
            check_disponible.set_active(True)
            mensaxe_merxente("Libro borrado con éxito")
        else:
            mensaxe_merxente("Operación de borrado cancelada")


def confirmar_accion(titulo, mensaxe):
    """
    Crea un diálogo de confirmación de tipo SÍ/NO.

    :param titulo: Título de la ventana del diálogo.
    :param mensaxe: Cuerpo del mensaje del diálogo.
    :return: True si el usuario pulsa SÍ, False en caso contrario.
    """
    dialogo = Gtk.MessageDialog(
        transient_for=ventanaPrincipal,
        flags=0,
        message_type=Gtk.MessageType.QUESTION,
        buttons=Gtk.ButtonsType.YES_NO,
        text=titulo,
    )
    dialogo.format_secondary_text(mensaxe)
    resposta = dialogo.run()
    dialogo.destroy()
    return resposta == Gtk.ResponseType.YES


def mensaxe_merxente(texto):
    """
    Crea una ventana emergente temporal (toast) sin bordes para informar al usuario.

    La ventana se cierra automáticamente después de 2 segundos utilizando un
    temporizador de la librería GLib para no bloquear la interfaz.
    """
    ventana_msg = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
    ventana_msg.set_decorated(False)
    ventana_msg.set_resizable(False)
    ventana_msg.set_transient_for(ventanaPrincipal)
    ventana_msg.set_position(Gtk.WindowPosition.CENTER_ON_PARENT)

    frame = Gtk.Frame()
    ventana_msg.add(frame)

    caja = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    caja.set_border_width(15)
    frame.add(caja)

    icono = Gtk.Image.new_from_icon_name("dialog-information-symbolic", Gtk.IconSize.BUTTON)
    label = Gtk.Label(label=texto)

    caja.pack_start(icono, False, False, 0)
    caja.pack_start(label, True, True, 0)

    ventana_msg.show_all()
    GLib.timeout_add(2000, ventana_msg.destroy)


def ficha_libro(boton, lista_libros):
    """
    Muestra una ventana modal con una lista de resultados de la búsqueda en un TreeView.

    Permite visualizar los libros encontrados y seleccionar uno mediante doble clic.
    """
    ventana_resultados = Gtk.Window(title="Resultados")
    ventana_resultados.set_default_size(600, 400)
    ventana_resultados.set_type_hint(Gdk.WindowTypeHint.DIALOG)
    ventana_resultados.set_transient_for(ventanaPrincipal)
    ventana_resultados.set_modal(True)

    vbox_res = Gtk.VBox(spacing=15)
    ventana_resultados.add(vbox_res)

    label_titulo = Gtk.Label()
    label_titulo.set_markup("<span size='large' weight='bold'>Ficha del Libro</span>")
    vbox_res.pack_start(label_titulo, False, False, 10)

    modelo_lista = Gtk.ListStore(str, str, str, str, str)

    for libro in lista_libros:
        dispo_texto = "Si" if libro[4] == 1 else "No"
        modelo_lista.append([str(libro[0]), str(libro[1]), str(libro[2]), str(libro[3]), dispo_texto])

    tree_view = Gtk.TreeView(model=modelo_lista)
    tree_view.connect("row-activated", al_doble_clic)

    columnas = ["ID", "Título", "Autor", "Año", "Disponibilidad"]
    for i, tit in enumerate(columnas):
        renderer = Gtk.CellRendererText()
        col = Gtk.TreeViewColumn(tit, renderer, text=i)
        tree_view.append_column(col)

    scroll = Gtk.ScrolledWindow()
    scroll.add(tree_view)
    vbox_res.pack_start(scroll, True, True, 0)

    ventana_resultados.show_all()

"""
    Interfaz principal del programa

 
    """
ventanaPrincipal = Gtk.Window(title="Biblioteca Bolsón Cerrado")
ventanaPrincipal.set_default_size(800, 600)
ventanaPrincipal.set_border_width(10)

pestaña = Gtk.Notebook()
ventanaPrincipal.add(pestaña)

vbox1 = Gtk.VBox(spacing=10)
vbox1.pack_start(Gtk.Label(label="Bienvenido a la Biblioteca Bolsón Cerrado"), False, False, 10)

hbox_busca = Gtk.HBox(spacing=5)
entrada_texto_busqueda = Gtk.Entry()
entrada_texto_busqueda.set_placeholder_text("Introduce Título, autor o código")
boton_buscar = Gtk.Button(label="Buscar")
boton_buscar.connect("clicked", al_pulsar_buscar)

hbox_busca.pack_start(boton_buscar, False, False, 0)
hbox_busca.pack_start(entrada_texto_busqueda, True, True, 0)
vbox1.pack_start(hbox_busca, False, False, 0)
pestaña.append_page(vbox1, Gtk.Label(label="Buscar"))

vbox2 = Gtk.VBox(spacing=20)
vbox2.set_border_width(30)

formulario = Gtk.Grid(column_spacing=20, row_spacing=15, halign=Gtk.Align.CENTER)
vbox2.pack_start(formulario, False, False, 0)

ent_id, ent_titulo, ent_autor, ent_ano = Gtk.Entry(), Gtk.Entry(), Gtk.Entry(), Gtk.Entry()
check_disponible = Gtk.CheckButton(label="Disponible")
check_disponible.set_active(True)

campos = [("ID/código", ent_id), ("Título", ent_titulo), ("Autor", ent_autor), ("Año de publicación", ent_ano)]

for i, (nombre, entry) in enumerate(campos):
    lbl = Gtk.Label(label=nombre, xalign=1)
    entry.set_width_chars(40)
    formulario.attach(lbl, 0, i, 1, 1)
    formulario.attach(entry, 1, i, 1, 1)

formulario.attach(Gtk.Label(label="Estado:", xalign=1), 0, 4, 1, 1)
formulario.attach(check_disponible, 1, 4, 1, 1)

hbox_btns = Gtk.HBox(spacing=20, halign=Gtk.Align.CENTER)
btn_ins = Gtk.Button(label="Insertar/Modificar Libro")
btn_ins.get_style_context().add_class("suggested-action")
btn_ins.connect("clicked", al_pulsar_insertar)

btn_borr = Gtk.Button(label="Borrar Libro")
btn_borr.get_style_context().add_class("destructive-action")
btn_borr.connect("clicked", al_pulsar_borrar)

hbox_btns.pack_start(btn_ins, False, False, 0)
hbox_btns.pack_start(btn_borr, False, False, 0)
vbox2.pack_start(hbox_btns, False, False, 20)

pestaña.append_page(vbox2, Gtk.Label(label="Insertar/Modificar"))

if __name__ == "__main__":
    ventanaPrincipal.connect("destroy", lambda w: (bd.pechaBD(), Gtk.main_quit()))
    ventanaPrincipal.show_all()
    Gtk.main()