"""
vd-dlt-salesforce-schema: Schema, defaults, and documentation for the Salesforce connector.

Provides:
- defaults.yml: Resource templates and default sync config
- schema.json: Credentials validation schema
- manifest.yml: Connector metadata
"""

__version__ = "0.1.2"

import importlib.resources
import json
from typing import Any, Dict

import yaml


def _load_package_file(filename: str) -> str:
    """Load a file from the package data directory."""
    ref = importlib.resources.files("vd_dlt_salesforce_schema") / filename
    return ref.read_text(encoding="utf-8")


def get_defaults() -> Dict[str, Any]:
    """
    Load connector defaults from defaults.yml.

    Returns:
        Dictionary with 'default_sync' and 'resources' keys
    """
    data = yaml.safe_load(_load_package_file("defaults.yml")) or {}
    return {
        "default_sync": data.get("default_sync", {}),
        "resources": data.get("resources", []),
    }


def get_defaults_raw() -> Dict[str, Any]:
    """
    Load raw defaults.yml content as dictionary.

    Returns:
        Full defaults.yml as dictionary
    """
    return yaml.safe_load(_load_package_file("defaults.yml")) or {}


def get_schema() -> Dict[str, Any]:
    """
    Load credentials validation schema from schema.json.

    Returns:
        JSON Schema dictionary for validating connector credentials
    """
    return json.loads(_load_package_file("schema.json"))


def get_manifest() -> Dict[str, Any]:
    """
    Load connector manifest metadata.

    Returns:
        Dictionary with connector name, version, status, etc.
    """
    return yaml.safe_load(_load_package_file("manifest.yml")) or {}


__all__ = [
    "get_defaults",
    "get_defaults_raw",
    "get_schema",
    "get_manifest",
]
