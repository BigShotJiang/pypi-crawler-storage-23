"""pyg-hyper: Unified interface for PyTorch Geometric Hypergraph Learning.

This meta-package provides convenient access to all pyg-hyper components:
- pyg_hyper.data: Hypergraph datasets and data structures
- pyg_hyper.nn: Neural network layers for hypergraphs
- pyg_hyper.ssl: Self-supervised learning methods
- pyg_hyper.bench: Benchmarking protocols and evaluators

Install sub-packages as needed:
    pip install pyg-hyper[all]  # Install everything
    pip install pyg-hyper[data,nn]  # Install specific components
"""

__version__ = "0.1.0"

import sys
from typing import TYPE_CHECKING, Any

# Lazy loading for zero import overhead
_SUBMODULES = {
    "data": "pyg_hyper_data",
    "nn": "pyg_hyper_nn",
    "ssl": "pyg_hyper_ssl",
    "bench": "pyg_hyper_bench",
}


def __getattr__(name: str) -> Any:
    """Lazy import sub-packages on demand."""
    if name in _SUBMODULES:
        import importlib

        module_name = _SUBMODULES[name]
        try:
            module = importlib.import_module(module_name)
            # Cache in sys.modules for subsequent imports
            sys.modules[f"pyg_hyper.{name}"] = module
            return module
        except ImportError as e:
            msg = (
                f"Cannot import '{name}' from pyg_hyper. "
                f"Install it with: pip install {module_name}"
            )
            raise ImportError(msg) from e

    raise AttributeError(f"module 'pyg_hyper' has no attribute '{name}'")


def __dir__() -> list[str]:
    """List available sub-packages."""
    return list(_SUBMODULES.keys()) + ["__version__"]


if TYPE_CHECKING:
    # Type stubs for IDEs (no runtime cost)
    import pyg_hyper_bench as bench
    import pyg_hyper_data as data
    import pyg_hyper_nn as nn
    import pyg_hyper_ssl as ssl

__all__ = ["__version__", "bench", "data", "nn", "ssl"]
