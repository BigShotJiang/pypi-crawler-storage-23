# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [v0.1.1] - 2026-02-21

### Changed
- **BREAKING**: Updated README with comprehensive installation instructions
  - Added detailed uv installation guide with PyTorch Geometric index configuration
  - Documented required `pyproject.toml` configuration for `torch-scatter` and `torch-sparse`
  - Added pip fallback instructions with find-links
  - Clarified that users need to configure PyTorch Geometric index in their own projects

### Fixed
- Improved documentation to address `torch-scatter`/`torch-sparse` build issues
- Clarified that `tool.uv.sources` configuration must be in user's `pyproject.toml`

## [v0.1.0] - 2026-02-21

### Added
- Initial release of pyg-hyper meta-package
- Pure meta-package with lazy import forwarding using `__getattr__` (PEP 562)
- Unified imports: `from pyg_hyper import data, nn, ssl, bench`
- Zero import overhead - only loads what you use
- Optional dependencies for maximum flexibility:
  - `pyg-hyper[data]` - Hypergraph datasets
  - `pyg-hyper[nn]` - Neural network layers
  - `pyg-hyper[ssl]` - Self-supervised learning
  - `pyg-hyper[bench]` - Benchmarking protocols
  - `pyg-hyper[all]` - Install everything
- Pre-commit hooks (ruff lint/format)
- CI/CD workflows:
  - Code quality checks
  - Import tests (Python 3.12)
  - Integration tests
  - Automatic TestPyPI publishing (main branch)
  - Automatic PyPI publishing (version tags)
- Comprehensive test suite (10 tests):
  - Lazy import mechanism tests
  - Integration workflow tests
  - Version information tests
- Type safety with `py.typed` marker
- MIT License
- Comprehensive README with usage examples

### Features
- Lazy loading ensures zero import overhead
- Type stubs for IDE support via `TYPE_CHECKING`
- Proper error messages for missing sub-packages
- `__dir__()` support for package introspection

[Unreleased]: https://github.com/nishide-dev/pyg-hyper/compare/v0.1.1...HEAD
[v0.1.1]: https://github.com/nishide-dev/pyg-hyper/compare/v0.1.0...v0.1.1
[v0.1.0]: https://github.com/nishide-dev/pyg-hyper/releases/tag/v0.1.0
