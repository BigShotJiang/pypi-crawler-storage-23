"""Test version information."""


def test_version_exists():
    """Test that __version__ is defined."""
    import pyg_hyper

    assert hasattr(pyg_hyper, "__version__")
    assert isinstance(pyg_hyper.__version__, str)
    assert len(pyg_hyper.__version__) > 0


def test_version_format():
    """Test version follows semantic versioning."""
    import re

    import pyg_hyper

    # Semantic versioning: MAJOR.MINOR.PATCH
    pattern = r"^\d+\.\d+\.\d+$"
    assert re.match(pattern, pyg_hyper.__version__)
