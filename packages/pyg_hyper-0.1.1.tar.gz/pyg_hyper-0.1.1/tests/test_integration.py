"""Integration tests for cross-package workflows."""

import pytest


@pytest.mark.integration
def test_data_to_nn_workflow():
    """Test loading dataset and passing to model."""
    pytest.importorskip("pyg_hyper_data")
    pytest.importorskip("pyg_hyper_nn")

    import torch
    from pyg_hyper_data.datasets import CoraCocitation
    from pyg_hyper_nn.layers import HypergraphConv

    # Load dataset
    dataset = CoraCocitation()
    hyper_data = dataset[0]

    # Create model (simple 1-layer)
    model = HypergraphConv(
        in_channels=hyper_data.num_node_features,
        out_channels=dataset.num_classes,
    )

    # Forward pass
    with torch.no_grad():
        result = model(hyper_data.x, hyper_data.hyperedge_index)
        # HypergraphConv returns (output, attention) tuple
        output = result[0] if isinstance(result, tuple) else result

    assert output.shape == (hyper_data.num_nodes, dataset.num_classes)


@pytest.mark.integration
def test_ssl_to_bench_workflow():
    """Test SSL encoder with benchmark evaluation."""
    pytest.importorskip("pyg_hyper_data")
    pytest.importorskip("pyg_hyper_nn")
    pytest.importorskip("pyg_hyper_ssl")
    pytest.importorskip("pyg_hyper_bench")

    import torch
    from pyg_hyper_bench.protocols import SSLLinearEvaluationProtocol
    from pyg_hyper_data.datasets import CoraCocitation
    from pyg_hyper_nn.layers import HypergraphConv

    # Load dataset
    dataset = CoraCocitation()
    hyper_data = dataset[0]

    # Create SSL encoder (simple 1-layer for embedding)
    encoder = HypergraphConv(
        in_channels=hyper_data.num_node_features,
        out_channels=64,
    )

    # Generate embeddings
    with torch.no_grad():
        result = encoder(hyper_data.x, hyper_data.hyperedge_index)
        # HypergraphConv returns (output, attention) tuple
        embeddings = result[0] if isinstance(result, tuple) else result

    # Evaluate with benchmark protocol
    protocol = SSLLinearEvaluationProtocol(
        task="node_classification",
        classifier_type="logistic_regression",
        seed=42,
    )

    # Split the data
    split = protocol.split_data(hyper_data)

    # Evaluate embeddings with the split
    result = protocol.evaluate(
        embeddings,
        labels=hyper_data.y,
        train_mask=split["train_mask"],
        val_mask=split["val_mask"],
        test_mask=split["test_mask"],
    )

    assert "test_accuracy" in result
    assert 0.0 <= result["test_accuracy"] <= 1.0
