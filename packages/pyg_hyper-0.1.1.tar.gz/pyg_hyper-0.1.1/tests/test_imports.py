"""Test lazy import mechanism."""

import sys

import pytest


def test_lazy_import_data():
    """Test lazy loading of pyg_hyper.data."""
    # Clear cache
    if "pyg_hyper.data" in sys.modules:
        del sys.modules["pyg_hyper.data"]

    # Import should trigger lazy loading
    from pyg_hyper import data

    assert data is not None
    assert "pyg_hyper_data" in sys.modules


def test_lazy_import_nn():
    """Test lazy loading of pyg_hyper.nn."""
    if "pyg_hyper.nn" in sys.modules:
        del sys.modules["pyg_hyper.nn"]

    from pyg_hyper import nn

    assert nn is not None
    assert "pyg_hyper_nn" in sys.modules


@pytest.mark.integration
def test_lazy_import_ssl():
    """Test lazy loading of pyg_hyper.ssl."""
    pytest.importorskip("pyg_hyper_ssl")

    if "pyg_hyper.ssl" in sys.modules:
        del sys.modules["pyg_hyper.ssl"]

    from pyg_hyper import ssl

    assert ssl is not None
    assert "pyg_hyper_ssl" in sys.modules


@pytest.mark.integration
def test_lazy_import_bench():
    """Test lazy loading of pyg_hyper.bench."""
    pytest.importorskip("pyg_hyper_bench")

    if "pyg_hyper.bench" in sys.modules:
        del sys.modules["pyg_hyper.bench"]

    from pyg_hyper import bench

    assert bench is not None
    assert "pyg_hyper_bench" in sys.modules


def test_import_error_missing_package():
    """Test that ImportError is raised for missing packages."""
    # Simulate missing package by temporarily removing from sys.modules
    import pyg_hyper

    with pytest.raises(AttributeError, match="module 'pyg_hyper' has no attribute"):
        pyg_hyper.__getattr__("nonexistent")


def test_dir_lists_submodules():
    """Test __dir__ returns available sub-packages."""
    import pyg_hyper

    available = dir(pyg_hyper)
    assert "data" in available
    assert "nn" in available
    assert "ssl" in available
    assert "bench" in available
    assert "__version__" in available
