from .langmail import *

__doc__ = langmail.__doc__
if hasattr(langmail, "__all__"):
    __all__ = langmail.__all__