# neurolinker-sdk
This repo is made to provide a solid sdk of the application neurolinker from Ainexxo S.R.L.
