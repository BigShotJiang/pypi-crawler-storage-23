
from .getCdnTokenEx import (
    HuyaGetCdnTokenExReq,
    HuyaGetCdnTokenExRsp
)

__all__ = [
    'HuyaGetCdnTokenExReq',
    'HuyaGetCdnTokenExRsp'
]
