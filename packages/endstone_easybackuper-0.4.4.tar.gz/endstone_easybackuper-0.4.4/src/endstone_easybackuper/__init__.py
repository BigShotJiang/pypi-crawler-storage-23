from endstone_easybackuper.easybackuper_plugin import EasyBackuperPlugin

__all__ = ["EasyBackuperPlugin"]
