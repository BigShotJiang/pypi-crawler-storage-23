"""Pydantic model entities for flow-sdk.

This module imports entity models to trigger __init_subclass__ registration
with the type_registry. Imported by loaders module at startup.
"""

# Import core entity models needed for minihub
# Some modules have complex dependencies - import with try/except

# Core entities that should work
try:
    from flow_sdk.builtin.visitor import Visitor  # noqa: F401
except ImportError as e:
    print(f"[WARN] Failed to import Visitor: {e}")

try:
    from flow_sdk.builtin.user import User  # noqa: F401
except ImportError as e:
    print(f"[WARN] Failed to import User: {e}")

try:
    from flow_sdk.builtin.project import Project  # noqa: F401
except ImportError as e:
    print(f"[WARN] Failed to import Project: {e}")

try:
    from flow_sdk.builtin.workspace import Workspace  # noqa: F401
except ImportError as e:
    print(f"[WARN] Failed to import Workspace: {e}")

try:
    from flow_sdk.builtin.agent import Agent  # noqa: F401
except ImportError as e:
    print(f"[WARN] Failed to import Agent: {e}")

try:
    from flow_sdk.builtin.api_key import ApiKey  # noqa: F401
except ImportError as e:
    print(f"[WARN] Failed to import ApiKey: {e}")

try:
    from flow_sdk.builtin.compute_node import ComputeNode  # noqa: F401
except ImportError as e:
    print(f"[WARN] Failed to import ComputeNode: {e}")

# Flow entity
try:
    from flow_sdk.builtin.process import Flow  # noqa: F401
except ImportError as e:
    print(f"[WARN] Failed to import Flow: {e}")

# Agentic processor entities (APU compatibility + processor/process)
try:
    from flow_sdk.builtin.agentic_processor import APU, AgenticProcess, AgenticProcessor  # noqa: F401
except ImportError as e:
    print(f"[WARN] Failed to import AgenticProcessor entities: {e}")

try:
    from flow_sdk.builtin.memo import Memo  # noqa: F401
except ImportError as e:
    print(f"[WARN] Failed to import Memo: {e}")

# These have more complex dependencies - skip for now
# from builtin.page import Page  # noqa: F401
# from builtin.task import Task  # noqa: F401
# from builtin.comment import Comment  # noqa: F401
# from builtin.question import Question  # noqa: F401

__all__ = []
