"""SkillitSkill -- a typed record for skills managed by skillit."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any, ClassVar

from flow_sdk.fs_store import Record, RecordType

from ._frontmatter import _coerce_scalar, _extract_frontmatter, _yaml_load  # noqa: F401


def _load_skill_yaml_from_dir(skill_dir: Path) -> dict[str, Any]:
    yaml_sources = [skill_dir / "skill.yaml", skill_dir / "skill.yml"]
    for source in yaml_sources:
        if source.exists():
            return _yaml_load(source.read_text(encoding="utf-8"))

    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        return {}

    frontmatter = _extract_frontmatter(skill_md.read_text(encoding="utf-8"))
    if not frontmatter:
        return {}
    return _yaml_load(frontmatter)


class SkillRecord(Record):
    """A skill record backed by Record."""

    _record_type: ClassVar[str] = RecordType.SKILL

    def __init__(self, **kwargs: Any):
        kwargs.setdefault("type", RecordType.SKILL)
        kwargs.setdefault("status", "active")
        super().__init__(**kwargs)

    @property
    def yaml_fields(self) -> dict[str, Any]:
        """Load YAML metadata from skill.yaml/skill.yml or SKILL.md frontmatter."""
        rd = self.record_dir
        if rd is None:
            return {}
        return _load_skill_yaml_from_dir(rd)

    def read_record(self, path: Path) -> None:
        """Read skill record -- bootstraps from YAML when JSON is absent."""
        if path.exists():
            super().read_record(path)
            return
        folder = path.parent.parent if path.parent.name == ".flow_record" else path.parent
        if not folder.is_dir():
            return
        yaml_fields = _load_skill_yaml_from_dir(folder)
        yaml_name = yaml_fields.get("name")
        skill_name = (yaml_name.strip() if isinstance(yaml_name, str) and yaml_name.strip()
                      else folder.name.split("-@", 1)[-1] if "-@" in folder.name else folder.name)
        self._meta_data["id"] = skill_name
        self._meta_data["name"] = skill_name
        self._meta_data["type"] = RecordType.SKILL
        self._meta_data["status"] = "active"
        if isinstance(yaml_fields.get("description"), str):
            if self._data is None:
                object.__setattr__(self, "_data", {})
            self._data["description"] = yaml_fields["description"]
        if yaml_fields:
            if self._data is None:
                object.__setattr__(self, "_data", {})
            self._data["metadata"] = yaml_fields

    @classmethod
    def init_record(cls, path_or_data, path=None, indent=2) -> SkillRecord:
        """Initialize or load a skill record with YAML bootstrap."""
        from flow_sdk.fs_store.record import _resolve_record_json

        if isinstance(path_or_data, dict):
            return super().init_record(path_or_data, path, indent=indent)

        p = Path(path_or_data)
        if p.is_dir():
            if _resolve_record_json(p).exists():
                return super().init_record(path_or_data, path, indent=indent)
        elif p.exists():
            return super().init_record(path_or_data, path, indent=indent)

        if not p.is_dir():
            return super().init_record(path_or_data, path, indent=indent)

        yaml_fields = _load_skill_yaml_from_dir(p)
        yaml_name = yaml_fields.get("name")
        skill_name = (yaml_name.strip() if isinstance(yaml_name, str) and yaml_name.strip()
                      else p.name.split("-@", 1)[-1] if "-@" in p.name else p.name)

        data: dict[str, Any] = {"id": skill_name, "name": skill_name, "type": RecordType.SKILL, "status": "active"}
        if isinstance(yaml_fields.get("description"), str):
            data["description"] = yaml_fields["description"]
        if yaml_fields:
            data["metadata"] = yaml_fields
        return super().init_record(data, p, indent=indent)

    @classmethod
    def load_record(cls, path: str | Path) -> SkillRecord:
        return cls.init_record(path)

    def copy_to_claude_user_home(self) -> Path:
        return self.copy_to(Path.home() / ".claude" / "skills")

    def copy_to_project(self, project_dir: str | Path) -> Path:
        return self.copy_to(Path(project_dir) / ".claude" / "skills")

    def copy_to(self, destination_root: Path) -> Path:
        source_dir = self.record_dir
        if source_dir is None:
            raise ValueError("Skill record has no source directory")
        if not (source_dir / "SKILL.md").exists():
            raise FileNotFoundError(f"Missing SKILL.md in {source_dir}")

        yaml_name = self.yaml_fields.get("name")
        skill_name = (yaml_name.strip() if isinstance(yaml_name, str) and yaml_name.strip()
                      else self.name or self.id or source_dir.name)

        destination_root.mkdir(parents=True, exist_ok=True)
        destination = destination_root / skill_name
        if destination.exists():
            shutil.rmtree(destination)
        shutil.copytree(source_dir, destination,
                        ignore=shutil.ignore_patterns(".flow_record", "record.json"))
        return destination

    def __getattr__(self, item: str) -> Any:
        # Check _data first (via parent), then yaml_fields
        try:
            return super().__getattr__(item)
        except AttributeError:
            pass
        yaml_data = object.__getattribute__(self, "yaml_fields")
        if item in yaml_data:
            return yaml_data[item]
        raise AttributeError(f"{self.__class__.__name__!s} has no attribute {item!r}")
