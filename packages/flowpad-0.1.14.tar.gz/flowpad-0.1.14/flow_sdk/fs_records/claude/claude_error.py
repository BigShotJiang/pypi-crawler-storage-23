"""ClaudeErrorRecord — persistent, deduplicated error triage records.

Errors are deduplicated by **fingerprint** (one record per unique error
pattern).  A background sync step parses ``~/.claude/debug/*.txt`` via the
existing ``parse_debug_log()`` helper and upserts into a writable
``ResourceRecordList`` stored at ``~/.flow/records/claude_error/``.

Each record tracks occurrence count, first/last seen timestamps, session
list, and a triage status (open / ignored / ignored_until / task_created).
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import time
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from typing import Any, ClassVar, Iterator

from flow_sdk.fs_store import Record, RecordType
from flow_sdk.fs_store.resource_record_list import ResourceRecordList
from flow_sdk.fs_store.scope import Scope

from .claude_debug_log import (
    ClaudeDebugLogFsRecord,
    _find_transcript,
    parse_debug_log,
)

# ─── Normalization helpers ────────────────────────────────────────────────────

_UUID_RE = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I)
_HEX_ADDR_RE = re.compile(r"0x[0-9a-fA-F]{6,}")
_TIMESTAMP_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[.\d]*Z?")
_PATH_RE = re.compile(r"(/[\w./-]+)+")
_DIGITS_RUN_RE = re.compile(r"\d{4,}")
# Matches API request/token IDs like req_011CYeki3KXBqWXJ5dMnKPsc, sk-ant-..., msg_..., etc.
_REQUEST_ID_RE = re.compile(r"\"(?:request_id|req_id|message_id)\":\s*\"[^\"]+\"")
_TOKEN_ID_RE = re.compile(r"\b(?:req|msg|sk|key|tok|ant)[-_][A-Za-z0-9]{10,}\b")
# Targeted quantity patterns — normalize counts but preserve error codes/status codes
_QUANTITY_PATTERNS = [
    re.compile(r"\b(\d+)\s+events?\b"),  # "44 events", "2 event"
    re.compile(r"attempt\s+(\d+)"),  # "attempt 3"
    re.compile(r"(\d+)\s+tokens?\b"),  # "28817 tokens"
    re.compile(r"(\d+)\s+errors?\b"),  # "5 errors"
    re.compile(r"(\d+)\s+items?\b"),  # "10 items"
    re.compile(r"(\d+)\s+files?\b"),  # "3 files"
    re.compile(r"(\d+)\s+retries?\b"),  # "2 retries"
    re.compile(r"(\d+)\s+times?\b"),  # "5 times"
]


def _normalize(text: str) -> str:
    """Strip variable parts for fingerprinting. Preserves error codes/status codes."""
    text = _UUID_RE.sub("<UUID>", text)
    text = _HEX_ADDR_RE.sub("<HEX>", text)
    text = _TIMESTAMP_RE.sub("<TS>", text)
    text = _REQUEST_ID_RE.sub("<REQ_ID>", text)
    text = _TOKEN_ID_RE.sub("<TOKEN>", text)
    text = _PATH_RE.sub("<PATH>", text)
    text = _DIGITS_RUN_RE.sub("<NUM>", text)
    for pat in _QUANTITY_PATTERNS:
        text = pat.sub(lambda m: m.group(0).replace(m.group(1), "<N>"), text)
    return text.strip()


def _fingerprint_hook(hook: str, event: str, root_cause: str) -> str:
    """Stable fingerprint for a hook error (keyed on root_cause only, not hook/event)."""
    key = f"hook:{_normalize(root_cause)}"
    return hashlib.sha256(key.encode()).hexdigest()[:12]


def _fingerprint_log(message: str) -> str:
    """Stable fingerprint for a log error."""
    key = f"log:{_normalize(message)}"
    return hashlib.sha256(key.encode()).hexdigest()[:12]


# ─── Status enum ──────────────────────────────────────────────────────────────


class ErrorStatus(StrEnum):
    OPEN = "open"
    IGNORED = "ignored"
    IGNORED_UNTIL = "ignored_until"
    TASK_CREATED = "task_created"


class ErrorCategory(StrEnum):
    HOOK = "hook"
    LOG = "log"


# ─── Record ───────────────────────────────────────────────────────────────────


class ClaudeErrorRecord(Record):
    """A deduplicated, triageable error record backed by ``~/.flow/records/claude_error/``."""

    _record_type: ClassVar[str] = RecordType.CLAUDE_ERROR

    def __init__(self, **kwargs: Any):
        kwargs.setdefault("type", RecordType.CLAUDE_ERROR)
        # Identity
        kwargs.setdefault("fingerprint", "")
        kwargs.setdefault("error_category", "")
        # Error content (from most recent occurrence)
        kwargs.setdefault("error_msg", "")
        kwargs.setdefault("hook", "")
        kwargs.setdefault("event", "")
        kwargs.setdefault("root_cause", "")
        kwargs.setdefault("traceback", [])
        # Occurrence tracking
        kwargs.setdefault("occurrence_count", 0)
        kwargs.setdefault("first_seen", "")
        kwargs.setdefault("last_seen", "")
        kwargs.setdefault("session_ids", [])
        kwargs.setdefault("last_session_id", "")
        kwargs.setdefault("last_jsonl_path", "")
        kwargs.setdefault("occurrences", [])
        # Triage
        kwargs.setdefault("error_status", ErrorStatus.OPEN)
        kwargs.setdefault("ignored_until", "")
        kwargs.setdefault("linked_task_id", "")
        kwargs.setdefault("worker_session_id", "")
        kwargs.setdefault("claude_session_id", "")
        kwargs.setdefault("triaged_at", "")
        kwargs.setdefault("notes", "")
        super().__init__(**kwargs)

    @classmethod
    def discover(cls, scope: Scope | None = None, hours: float = 168.0, **kwargs) -> list[ClaudeErrorRecord]:
        """Find all error records, syncing from debug logs first."""
        rl = ClaudeErrorRecordList(hours=hours)
        return list(rl)

    @classmethod
    def discover_one(cls, uid: str, scope: Scope | None = None, **kwargs) -> ClaudeErrorRecord | None:
        """Load a specific error record by fingerprint."""
        rl = ClaudeErrorRecordList()
        return rl.get(uid)


# ─── Sync state persistence ──────────────────────────────────────────────────


_SYNC_STATE_FILE = "_sync_state.json"
_MAX_OCCURRENCES = 50  # cap stored individual occurrences per fingerprint


def _load_sync_state(base: Path) -> dict:
    """Load sync state from ``<base>/_sync_state.json``."""
    p = base / _SYNC_STATE_FILE
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {"processed": {}}


def _save_sync_state(base: Path, state: dict) -> None:
    """Persist sync state."""
    base.mkdir(parents=True, exist_ok=True)
    p = base / _SYNC_STATE_FILE
    p.write_text(json.dumps(state, indent=2), encoding="utf-8")


# ─── Debug log maintenance ───────────────────────────────────────────────────

_DEBUG_MAX_AGE_DAYS = 7
_DEBUG_SIZE_WARN_MB = 400


def _cleanup_and_measure_debug_dir() -> tuple[int, int, int]:
    """Single-pass: delete old debug logs and measure remaining size.

    Returns (removed_count, remaining_bytes, remaining_file_count).
    """
    debug_dir = ClaudeDebugLogFsRecord.debug_dir()
    if not debug_dir.is_dir():
        return 0, 0, 0
    cutoff = time.time() - (_DEBUG_MAX_AGE_DAYS * 86400)
    removed = 0
    total_bytes = 0
    file_count = 0
    for entry in os.scandir(debug_dir):
        if not entry.name.endswith(".txt"):
            continue
        try:
            st = entry.stat()
            if st.st_mtime < cutoff:
                os.unlink(entry.path)
                removed += 1
            else:
                total_bytes += st.st_size
                file_count += 1
        except OSError:
            continue
    return removed, total_bytes, file_count


def _check_debug_dir_size(
    error_list: ClaudeErrorRecordList,
    total_bytes: int,
    file_count: int,
) -> None:
    """If debug dir exceeds threshold, create an error record about it."""
    total_mb = total_bytes / (1024 * 1024)
    if total_mb <= _DEBUG_SIZE_WARN_MB:
        return
    fp = "debug-dir-size-warning"
    now_iso = datetime.now(timezone.utc).isoformat()
    error_list._upsert_error(
        fingerprint=fp,
        error_category=ErrorCategory.LOG,
        error_msg=(
            f"Claude debug log directory is {total_mb:.0f} MB "
            f"({file_count} files). "
            f"Consider deleting entries older than a week: "
            f"find ~/.claude/debug -name '*.txt' -mtime +7 -delete"
        ),
        hook="",
        event="",
        root_cause="disk-usage",
        traceback=[],
        timestamp=now_iso,
        session_id="system",
        jsonl_path="",
    )


def run_startup_sync() -> None:
    """Run debug-log sync, cleanup, and size check.

    Called once at server startup in a background thread.
    After this completes, per-request reads just return what's on disk.
    """
    # 1. Delete old debug logs (>7 days) and measure remaining size (single pass)
    removed, total_bytes, file_count = _cleanup_and_measure_debug_dir()

    # 2. Sync remaining debug logs into error records
    rl = ClaudeErrorRecordList()
    rl._do_sync()

    # 3. Check if debug dir is still too large
    _check_debug_dir_size(rl, total_bytes, file_count)


class ClaudeErrorRecordList:
    """Syncing collection that materializes debug-log errors into persistent records.

    Delegates CRUD to a backing ``ResourceRecordList`` (writable, FOLDER layout).
    On iteration / get, runs ``_sync_from_debug_logs()`` first.
    """

    def __init__(self, list_path: Path | None = None, hours: float = 168.0):
        if list_path is None:
            from flow_sdk.fs_store.record import get_default_records_root

            list_path = get_default_records_root() / RecordType.CLAUDE_ERROR
        self.list_path = list_path
        self.hours = hours
        self._backing = ResourceRecordList(
            list_path=self.list_path,
            record_class=ClaudeErrorRecord,
        )

    # -- Sync engine (called at startup, NOT per-request) ---------------------

    def _do_sync(self) -> None:
        """Parse debug logs and upsert error records into the backing store."""
        debug_dir = ClaudeDebugLogFsRecord.debug_dir()
        if not debug_dir.is_dir():
            return

        base = self.list_path
        base.mkdir(parents=True, exist_ok=True)
        sync_state = _load_sync_state(base)
        processed: dict[str, float] = sync_state.get("processed", {})

        cutoff = time.time() - (self.hours * 3600)
        dirty = False

        for entry in os.scandir(debug_dir):
            if not entry.name.endswith(".txt"):
                continue
            mtime = entry.stat().st_mtime
            if mtime < cutoff:
                continue
            session_id = Path(entry.name).stem
            prev_mtime = processed.get(session_id)
            if prev_mtime is not None and abs(prev_mtime - mtime) < 0.01:
                continue  # already processed at this mtime

            # Parse the debug log
            path = Path(entry.path)
            try:
                hook_errors, log_errors = parse_debug_log(path)
            except OSError:
                continue

            if not hook_errors and not log_errors:
                processed[session_id] = mtime
                dirty = True
                continue

            jsonl_path = _find_transcript(session_id)

            # Upsert each hook error
            for he in hook_errors:
                fp = _fingerprint_hook(he.hook, he.event, he.root_cause)
                self._upsert_error(
                    fingerprint=fp,
                    error_category=ErrorCategory.HOOK,
                    error_msg=he.root_cause or f"{he.hook} ({he.event}) error",
                    hook=he.hook,
                    event=he.event,
                    root_cause=he.root_cause,
                    traceback=he.traceback,
                    timestamp=he.timestamp,
                    session_id=session_id,
                    jsonl_path=jsonl_path,
                )

            # Upsert each log error
            for le in log_errors:
                fp = _fingerprint_log(le.message)
                self._upsert_error(
                    fingerprint=fp,
                    error_category=ErrorCategory.LOG,
                    error_msg=le.message,
                    hook="",
                    event="",
                    root_cause="",
                    traceback=[],
                    timestamp=le.timestamp,
                    session_id=session_id,
                    jsonl_path=jsonl_path,
                )

            processed[session_id] = mtime
            dirty = True

        # Check ignored_until expiry on all existing records
        now_iso = datetime.now(timezone.utc).isoformat()
        cutoff_iso = datetime.fromtimestamp(cutoff, tz=timezone.utc).isoformat()
        for rec in list(self._backing):
            # Auto-reopen expired snoozes — but only for real future snoozes, not
            # "ignore till now" (where ignored_until ≈ triaged_at, both set to the
            # same moment).  A real snooze always has ignored_until > triaged_at.
            if rec.error_status == ErrorStatus.IGNORED_UNTIL and rec.ignored_until:
                is_real_snooze = rec.triaged_at and rec.ignored_until > rec.triaged_at
                if is_real_snooze and rec.ignored_until <= now_iso:
                    rec.error_status = ErrorStatus.OPEN
                    rec.ignored_until = ""
                    self._backing.save(rec)
            # Prune records older than the time window
            if rec.last_seen and rec.last_seen < cutoff_iso:
                self._backing.delete(rec.id)

        if dirty:
            sync_state["processed"] = processed
            _save_sync_state(base, sync_state)

    def _upsert_error(
        self,
        *,
        fingerprint: str,
        error_category: str,
        error_msg: str,
        hook: str,
        event: str,
        root_cause: str,
        traceback: list[str],
        timestamp: str,
        session_id: str,
        jsonl_path: str,
    ) -> None:
        """Create or update an error record by fingerprint."""
        existing = self._backing.get(fingerprint)

        occurrence = {
            "timestamp": timestamp,
            "session_id": session_id,
            "jsonl_path": jsonl_path,
            "error_msg": error_msg,
            "traceback": traceback,
        }

        if existing is not None:
            # Check for duplicate occurrence (same session + timestamp)
            for occ in existing.occurrences:
                if occ.get("session_id") == session_id and occ.get("timestamp") == timestamp:
                    return  # already recorded

            existing.occurrence_count += 1
            existing.last_seen = timestamp
            existing.last_session_id = session_id
            existing.last_jsonl_path = jsonl_path
            # Update error content from latest occurrence
            existing.error_msg = error_msg
            existing.traceback = traceback
            if root_cause:
                existing.root_cause = root_cause
            # Track session
            if session_id and session_id not in existing.session_ids:
                existing.session_ids.append(session_id)
            # Append occurrence (capped)
            existing.occurrences.append(occurrence)
            if len(existing.occurrences) > _MAX_OCCURRENCES:
                existing.occurrences = existing.occurrences[-_MAX_OCCURRENCES:]
            # Re-open if a new occurrence fired after the ignored_until point
            if existing.error_status == ErrorStatus.IGNORED_UNTIL and existing.ignored_until:
                if timestamp > existing.ignored_until:
                    existing.error_status = ErrorStatus.OPEN
                    existing.ignored_until = ""
            self._backing.save(existing)
        else:
            rec = ClaudeErrorRecord(
                fingerprint=fingerprint,
                error_category=error_category,
                error_msg=error_msg,
                hook=hook,
                event=event,
                root_cause=root_cause,
                traceback=traceback,
                occurrence_count=1,
                first_seen=timestamp,
                last_seen=timestamp,
                session_ids=[session_id] if session_id else [],
                last_session_id=session_id,
                last_jsonl_path=jsonl_path,
                occurrences=[occurrence],
                error_status=ErrorStatus.OPEN,
            )
            rec.id = fingerprint
            rec.name = error_msg[:80] if error_msg else fingerprint
            try:
                self._backing.create(rec)
            except ValueError:
                # Race: record appeared between get and create.
                # Re-read; if still unreadable (corrupt/empty), overwrite.
                existing2 = self._backing.get(fingerprint)
                if existing2 is not None:
                    # Now readable — merge this occurrence into it
                    for occ in existing2.occurrences:
                        if occ.get("session_id") == session_id and occ.get("timestamp") == timestamp:
                            return
                    existing2.occurrence_count += 1
                    existing2.last_seen = timestamp
                    existing2.last_session_id = session_id
                    existing2.last_jsonl_path = jsonl_path
                    existing2.error_msg = error_msg
                    existing2.traceback = traceback
                    if root_cause:
                        existing2.root_cause = root_cause
                    if session_id and session_id not in existing2.session_ids:
                        existing2.session_ids.append(session_id)
                    existing2.occurrences.append(occurrence)
                    if len(existing2.occurrences) > _MAX_OCCURRENCES:
                        existing2.occurrences = existing2.occurrences[-_MAX_OCCURRENCES:]
                    self._backing.save(existing2)
                else:
                    # File on disk is corrupt/empty — overwrite it
                    self._backing.save(rec)

    # -- Collection protocol (reads disk, no sync) ----------------------------

    def __iter__(self) -> Iterator[ClaudeErrorRecord]:
        yield from self._backing

    def __len__(self) -> int:
        return len(self._backing)

    @property
    def records(self) -> list[ClaudeErrorRecord]:
        return list(self)

    def get(self, uid: str) -> ClaudeErrorRecord | None:
        return self._backing.get(uid)

    # -- Write operations (direct to backing store) -------------------------

    def create(self, record: Record | dict) -> Record:
        return self._backing.create(record)

    def update(self, uid: str, data: dict[str, Any]) -> Record:
        return self._backing.update(uid, data)

    def save(self, record: Record) -> None:
        self._backing.save(record)

    def delete(self, uid: str) -> bool:
        return self._backing.delete(uid)
