"""ClaudeRootFsRecord — the root of all Claude Code projects.

Represents ``~/.claude/projects/`` and provides access to all projects
and sessions across the entire Claude installation.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, ClassVar

from flow_sdk.fs_store import Record, RecordType
from .claude_session import ClaudeSessionFsRecord

if TYPE_CHECKING:
    from .claude_project import ClaudeProjectFsRecord

_DEFAULT_PROJECTS_DIR = Path.home() / ".claude" / "projects"


class ClaudeRootFsRecord(Record):
    """Root record for the Claude Code installation.

    Children are ``ClaudeProjectFsRecord`` instances (one per project dir).
    """

    _read_only: ClassVar[bool] = True

    def __init__(self, **kwargs):
        if "type" not in kwargs:
            kwargs["type"] = RecordType.CLAUDE_ROOT
        if "projects_dir" not in kwargs:
            kwargs["projects_dir"] = str(_DEFAULT_PROJECTS_DIR)
        super().__init__(**kwargs)
        if not self.name:
            self.name = "claude_root"

    @property
    def _projects_path(self) -> Path:
        return Path(self.projects_dir)

    @property
    def projects(self) -> list[ClaudeProjectFsRecord]:
        """Return all project directories as ``ClaudeProjectFsRecord``."""
        from .claude_project import ClaudeProjectFsRecord

        if not self._projects_path.is_dir():
            return []
        result = []
        for d in sorted(self._projects_path.iterdir()):
            if not d.is_dir():
                continue
            encoded = d.name
            real = "/" + encoded.lstrip("-").replace("-", "/")
            session_count = sum(1 for f in d.glob("*.jsonl"))
            result.append(ClaudeProjectFsRecord(
                encoded_path=encoded,
                real_path=real,
                session_count=session_count,
                path=str(d),
            ))
        return result

    @property
    def active_sessions(self):
        """Return the active-sessions scanner."""
        from .claude_active_sessions import ClaudeActiveSessionsFsRecord
        return ClaudeActiveSessionsFsRecord.default()

    @property
    def history(self):
        """Return the global prompt history record."""
        from .claude_history import ClaudeHistoryFsRecord
        return ClaudeHistoryFsRecord.default()

    def get_session(self, session_id: str) -> ClaudeSessionFsRecord | None:
        """Find a session by ID across all projects.

        Returns a ``ClaudeSessionFsRecord`` or ``None``.
        """
        if not self._projects_path.is_dir():
            return None
        for project_dir in self._projects_path.iterdir():
            if not project_dir.is_dir():
                continue
            jsonl = project_dir / f"{session_id}.jsonl"
            if jsonl.is_file():
                return ClaudeSessionFsRecord.from_jsonl(jsonl)
        return None

    @classmethod
    def default(cls) -> ClaudeRootFsRecord:
        """Return the root record for the default Claude installation."""
        return cls(projects_dir=str(_DEFAULT_PROJECTS_DIR))
