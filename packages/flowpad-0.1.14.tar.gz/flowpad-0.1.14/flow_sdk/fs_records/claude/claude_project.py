"""ClaudeProjectFsRecord — represents a Claude Code project directory.

Source: ~/.claude/projects/<encoded-path>/
The directory name is the URL-encoded absolute path of the working directory.
Contains .jsonl session files and optional subdirectories (subagents, etc.).
"""

from __future__ import annotations

from pathlib import Path
from typing import ClassVar

from flow_sdk.fs_store import Record, RecordType, StorageLayout
from .claude_session import ClaudeSessionFsRecord


class ClaudeProjectFsRecord(Record):
    """A Claude Code project — a working directory with associated sessions.

    Mapped from ``~/.claude/projects/<encoded-cwd>/``.
    """

    _read_only: ClassVar[bool] = True

    def __init__(self, **kwargs):
        if "type" not in kwargs:
            kwargs["type"] = RecordType.PROJECT
        super().__init__(**kwargs)
        self.storage_layout = StorageLayout.FOLDER
        encoded_path = self.data.get("encoded_path", "")
        if encoded_path:
            self.id = encoded_path
            if not self.name:
                self.name = self.data.get("real_path", "") or encoded_path

    @property
    def sessions(self) -> list[ClaudeSessionFsRecord]:
        """Return all sessions in this project as ``ClaudeSessionFsRecord``."""

        project_dir = Path(self.path or self.source_file) if (self.path or self.source_file) else None
        if not project_dir or not project_dir.is_dir():
            return []
        return [
            ClaudeSessionFsRecord.from_jsonl(f)
            for f in sorted(project_dir.glob("*.jsonl"))
        ]
