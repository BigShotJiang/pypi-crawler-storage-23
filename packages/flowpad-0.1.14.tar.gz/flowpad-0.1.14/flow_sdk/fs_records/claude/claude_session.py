"""ClaudeSessionFsRecord — represents a Claude Code chat session.

Source: ~/.claude/projects/<encoded-path>/<session-id>.jsonl
Each line is a JSON entry with a shared envelope (sessionId, cwd, version,
gitBranch, slug, timestamp, uuid) plus a type-specific payload.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar, Self

from flow_sdk.fs_store import Record, RecordType

if TYPE_CHECKING:
    from .claude_transcript_entry import ClaudeTranscriptEntryFsRecord


class ClaudeSessionFsRecord(Record):
    """A single Claude Code chat session.

    Mapped from the JSONL transcript at
    ``~/.claude/projects/<project>/<session-id>.jsonl``.
    """

    _read_only: ClassVar[bool] = True

    def __init__(self, **kwargs):
        if "type" not in kwargs:
            kwargs["type"] = RecordType.SESSION
        super().__init__(**kwargs)
        session_id = self.data.get("session_id", "")
        if session_id:
            self.id = session_id
            if not self.name:
                self.name = self.data.get("slug", "") or session_id

    EXCLUDED_ENTRY_TYPES: ClassVar[list[str]] = ["file-history-snapshot", "progress"]

    def read_record(self, path: Path) -> None:
        """Read session from JSONL — delegates to ``from_jsonl``."""
        if path.suffix == ".jsonl" and path.exists():
            loaded = self.__class__.from_jsonl(path)
            # Copy internal state from loaded into self
            object.__setattr__(self, "_meta_data", loaded._meta_data)
            object.__setattr__(self, "_data", loaded._data)
        elif path.exists():
            super().read_record(path)

    @property
    def filtered_entries(self) -> list[ClaudeTranscriptEntryFsRecord]:
        """Return transcript entries with noisy types excluded.

        Uses ``EXCLUDED_ENTRY_TYPES`` as a blocklist.
        """
        return [
            e for e in self.transcript_entries
            if e.entry_type not in self.EXCLUDED_ENTRY_TYPES
        ]

    @property
    def transcript_entries(self) -> list[ClaudeTranscriptEntryFsRecord]:
        """Lazily load transcript entries from the JSONL file.

        Returns a list of transcript entry records (base or type-specific).
        """
        from .transcript_records import create_transcript_entry

        path = self.jsonl_path or (self.source_file or "")
        if not path or not Path(path).is_file():
            return []
        entries = []
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    raw = json.loads(line)
                except json.JSONDecodeError:
                    continue
                entries.append(create_transcript_entry(raw))
        return entries

    @property
    def entries(self) -> list[ClaudeTranscriptEntryFsRecord]:
        """Alias for ``filtered_entries`` — used by the tree-walk API."""
        return self.filtered_entries

    @property
    def summary_log(self) -> str:
        """Newline-joined one-line summaries of filtered transcript entries."""
        return "\n".join(
            f"[{i:4d}]  {e.summary}" for i, e in enumerate(self.filtered_entries, 1)
        )

    @classmethod
    def discover(cls, scope=None, **kwargs) -> list[ClaudeSessionFsRecord]:
        """Find all session JSONL files under ~/.claude/projects/."""
        projects_dir = Path.home() / ".claude" / "projects"
        if not projects_dir.is_dir():
            return []
        results: list[ClaudeSessionFsRecord] = []
        for project_dir in sorted(projects_dir.iterdir()):
            if not project_dir.is_dir():
                continue
            for jsonl_file in sorted(project_dir.glob("*.jsonl")):
                try:
                    rec = cls.from_jsonl(jsonl_file)
                    results.append(rec)
                except (json.JSONDecodeError, OSError):
                    continue
        return results

    @classmethod
    def discover_one(cls, uid: str, scope=None, **kwargs) -> ClaudeSessionFsRecord | None:
        """Find a specific session by session ID.

        Pass ``project="/abs/path"`` for O(1) lookup via the encoded
        project directory.  Without it, falls back to scanning all
        project directories.
        """
        projects_dir = Path.home() / ".claude" / "projects"
        if not projects_dir.is_dir():
            return None
        fname = f"{uid}.jsonl"

        # Fast path: caller knows the project directory
        project_path = kwargs.get("project")
        if project_path:
            encoded = str(project_path).replace("/", "-")
            candidate = projects_dir / encoded / fname
            if candidate.exists():
                try:
                    return cls.from_jsonl(candidate)
                except (json.JSONDecodeError, OSError):
                    return None

        # Slow path: scan all project directories
        for project_dir in projects_dir.iterdir():
            if not project_dir.is_dir():
                continue
            candidate = project_dir / fname
            if candidate.exists():
                try:
                    return cls.from_jsonl(candidate)
                except (json.JSONDecodeError, OSError):
                    return None
        return None

    @classmethod
    def from_jsonl(cls, path: str | Path) -> Self:
        """Build a session record by parsing a transcript JSONL file.

        Populates envelope fields from the first entry that carries them
        and aggregates message counts and token usage across all entries.
        """
        path = Path(path)
        session_id = ""
        cwd = ""
        version = ""
        git_branch = ""
        slug = ""
        model: str | None = None

        message_count = 0
        user_count = 0
        assistant_count = 0
        input_tokens = 0
        output_tokens = 0
        cache_read = 0
        cache_creation = 0
        duration_ms = 0
        tools: set[str] = set()
        has_plan = False

        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    raw = json.loads(line)
                except json.JSONDecodeError:
                    continue

                # Envelope fields — take from first entry that has them
                if not session_id and raw.get("sessionId"):
                    session_id = raw["sessionId"]
                if not cwd and raw.get("cwd"):
                    cwd = raw["cwd"]
                if not version and raw.get("version"):
                    version = raw["version"]
                if not git_branch and raw.get("gitBranch"):
                    git_branch = raw["gitBranch"]
                if not slug and raw.get("slug"):
                    slug = raw["slug"]

                entry_type = raw.get("type", "")

                if entry_type == "user":
                    message_count += 1
                    user_count += 1
                    if raw.get("planContent"):
                        has_plan = True

                elif entry_type == "assistant":
                    message_count += 1
                    assistant_count += 1
                    msg = raw.get("message") or {}
                    if not model and msg.get("model"):
                        model = msg["model"]
                    usage = msg.get("usage") or {}
                    input_tokens += usage.get("input_tokens", 0)
                    output_tokens += usage.get("output_tokens", 0)
                    cache_read += usage.get("cache_read_input_tokens", 0)
                    cache_creation += usage.get(
                        "cache_creation_input_tokens", 0
                    )
                    # Collect tool names from content blocks
                    for block in msg.get("content") or []:
                        if isinstance(block, dict) and block.get("type") == "tool_use":
                            tools.add(block.get("name", ""))

                elif entry_type == "system" and raw.get("subtype") == "turn_duration":
                    duration_ms += raw.get("durationMs", 0)

        return cls(
            session_id=session_id,
            cwd=cwd,
            version=version,
            git_branch=git_branch,
            slug=slug,
            model=model,
            message_count=message_count,
            user_message_count=user_count,
            assistant_message_count=assistant_count,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_input_tokens=cache_read,
            cache_creation_input_tokens=cache_creation,
            duration_ms=duration_ms,
            tools_used=sorted(tools),
            has_plan=has_plan,
            jsonl_path=str(path),
            source_file=str(path),
        )
