"""ClaudeMdFsRecord — represents a CLAUDE.md instruction file.

Source: CLAUDE.md, CLAUDE.local.md, .claude/CLAUDE.md at project or user level.
These are instruction files that provide context and rules to Claude Code sessions.
"""

from __future__ import annotations

from typing import ClassVar

from flow_sdk.fs_store import Record, RecordType


class ClaudeMdFsRecord(Record):
    """A CLAUDE.md instruction file.

    Mapped from ``CLAUDE.md``, ``CLAUDE.local.md``, or ``.claude/CLAUDE.md``.
    """

    _read_only: ClassVar[bool] = True

    def __init__(self, **kwargs):
        if "type" not in kwargs:
            kwargs["type"] = RecordType.CLAUDE_MD
        kwargs.setdefault("filename", "")
        kwargs.setdefault("content", "")
        kwargs.setdefault("scope", "project")
        kwargs.setdefault("file_path", "")
        super().__init__(**kwargs)
        if self.file_path:
            self.id = self.file_path
            if not self.name:
                self.name = self.filename or self.file_path
