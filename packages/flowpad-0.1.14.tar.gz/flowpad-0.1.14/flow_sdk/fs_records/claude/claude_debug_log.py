"""ClaudeDebugLogFsRecord — a Claude Code debug session log.

Source: ~/.claude/debug/<session-uuid>.txt

Each file is a plain-text debug log with two kinds of errors:

1. **Hook errors** — multi-line blocks starting with
   ``Hook <name> (<event>) error:`` followed by a traceback.

2. **Runtime errors** — single ``[ERROR]`` log lines from Claude Code
   (tool failures, MCP errors, file-not-found, lock errors, etc.).

The record parses both on load and exposes them via ``to_dict()``.
"""

from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, ClassVar, Iterator, Self

from flow_sdk.fs_store import Record, RecordType

# --- Compiled patterns (module-level, compiled once) ---

_ERROR_MARKER = re.compile(r"Hook (.+?) \((\w+)\) error:")
_TIMESTAMP_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z")
_DEBUG_LINE = re.compile(r"\[DEBUG\]")
_ERROR_LOG_LINE = re.compile(
    r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z)\s+\[ERROR\]\s+(.*)"
)
_EXCEPTION_RE = re.compile(
    r"^(ModuleNotFoundError|ImportError|FileNotFoundError|PermissionError|"
    r"OSError|TypeError|ValueError|RuntimeError|KeyError|AttributeError|"
    r"SyntaxError|ConnectionError|TimeoutError|EOFError|StopIteration)"
)


# --- HookError (nested value object, not a standalone Record) ---


@dataclass
class HookError:
    """A single hook error parsed from a debug log."""

    hook: str = ""
    event: str = ""
    timestamp: str = ""
    traceback: list[str] = field(default_factory=list)
    root_cause: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "hook": self.hook,
            "event": self.event,
            "timestamp": self.timestamp,
            "traceback": self.traceback,
            "root_cause": self.root_cause,
        }


@dataclass
class LogError:
    """A single [ERROR] log line from Claude Code."""

    timestamp: str = ""
    message: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "message": self.message,
        }


# --- Parser ---


def parse_debug_log(path: Path) -> tuple[list[HookError], list[LogError]]:
    """Parse all hook errors and [ERROR] log lines in a single pass."""
    hook_errors: list[HookError] = []
    log_errors: list[LogError] = []
    current: HookError | None = None

    with open(path, "r", errors="replace") as f:
        for line in f:
            line = line.rstrip("\n")

            # Check for hook error start marker
            m = _ERROR_MARKER.search(line)
            if m:
                if current is not None:
                    hook_errors.append(current)
                ts_m = _TIMESTAMP_RE.search(line)
                current = HookError(
                    hook=m.group(1),
                    event=m.group(2),
                    timestamp=ts_m.group(0) if ts_m else "unknown",
                )
                continue

            # Inside a hook error block — collect traceback lines
            if current is not None:
                if _DEBUG_LINE.search(line) or _ERROR_LOG_LINE.match(line):
                    hook_errors.append(current)
                    current = None
                    # Fall through to check if this line is an [ERROR]
                else:
                    if len(current.traceback) < 30:
                        current.traceback.append(line)
                        if _EXCEPTION_RE.match(line):
                            current.root_cause = line
                    continue

            # Check for [ERROR] log line
            em = _ERROR_LOG_LINE.match(line)
            if em:
                log_errors.append(LogError(
                    timestamp=em.group(1),
                    message=em.group(2),
                ))

    if current is not None:
        hook_errors.append(current)

    return hook_errors, log_errors


def parse_hook_errors(path: Path) -> list[HookError]:
    """Parse only hook errors (backward compat)."""
    hook_errors, _ = parse_debug_log(path)
    return hook_errors


def has_errors(path: Path) -> bool:
    """Quick check — does this file contain hook errors or [ERROR] lines?"""
    with open(path, "r", errors="replace") as f:
        for line in f:
            if "[ERROR]" in line:
                return True
            if "error:" in line and _ERROR_MARKER.search(line):
                return True
    return False


def has_hook_errors(path: Path) -> bool:
    """Quick check — does this file contain any hook error markers?"""
    with open(path, "r", errors="replace") as f:
        for line in f:
            if "error:" in line and _ERROR_MARKER.search(line):
                return True
    return False


# --- Transcript discovery ---


def _find_transcript(session_id: str) -> str:
    """Find the JSONL transcript path for a given session ID.

    Scans ``~/.claude/projects/*/`` for ``{session_id}.jsonl``.
    Returns the full path as a string, or empty string if not found.
    """
    projects_dir = Path.home() / ".claude" / "projects"
    if not projects_dir.is_dir():
        return ""
    fname = f"{session_id}.jsonl"
    for project_dir in projects_dir.iterdir():
        if not project_dir.is_dir():
            continue
        candidate = project_dir / fname
        if candidate.exists():
            return str(candidate)
    return ""


# --- Record ---


class ClaudeDebugLogFsRecord(Record):
    """A Claude Code debug session log with parsed hook errors and log errors.

    Read-only record backed by ``~/.claude/debug/<session-id>.txt``.
    Errors are parsed on load.
    """

    _record_type: ClassVar[str] = RecordType.CLAUDE_DEBUG_LOG
    _read_only: ClassVar[bool] = True

    def __init__(self, **kwargs):
        if "type" not in kwargs:
            kwargs["type"] = RecordType.CLAUDE_DEBUG_LOG
        super().__init__(**kwargs)
        session_id = self.data.get("session_id", "")
        if session_id:
            self.id = session_id
            if not self.name:
                self.name = session_id

    def read_record(self, path: Path) -> None:
        """Parse the debug log file instead of reading JSON."""
        self.source_file = str(path)
        self.session_id = path.stem
        self.id = self.session_id
        self.name = self.session_id

        hook_errs, log_errs = parse_debug_log(path)
        self.hook_errors = [e.to_dict() for e in hook_errs]
        self.log_errors = [e.to_dict() for e in log_errs]
        self.error_count = len(hook_errs) + len(log_errs)
        self.log_error_count = len(log_errs)
        self.has_errors = self.error_count > 0

        self.jsonl_path = _find_transcript(self.session_id)

    def to_dict(self) -> dict[str, Any]:
        d = super().to_dict()
        d["session_id"] = self.session_id
        d["error_count"] = self.error_count
        d["has_errors"] = self.has_errors
        d["hook_errors"] = self.hook_errors
        d["log_errors"] = self.log_errors
        d["log_error_count"] = self.log_error_count
        d["jsonl_path"] = self.jsonl_path
        return d

    @classmethod
    def from_debug_file(cls, path: Path) -> Self:
        """Build a record by parsing a debug log file."""
        rec = cls()
        rec.read_record(path)
        return rec

    @classmethod
    def debug_dir(cls) -> Path:
        """Return the platform-appropriate debug log directory."""
        home = Path.home()
        d = home / ".claude" / "debug"
        if d.is_dir():
            return d
        # Windows AppData fallback
        import sys
        if sys.platform == "win32":
            appdata = os.environ.get("APPDATA", "")
            if appdata:
                d = Path(appdata) / "claude" / "debug"
                if d.is_dir():
                    return d
        return home / ".claude" / "debug"

    @classmethod
    def discover(cls, scope=None, hours: float = 168.0, **kwargs) -> list[ClaudeDebugLogFsRecord]:
        """Find all debug log records with errors within *hours* window."""
        rl = ClaudeDebugLogRecordList(hours=hours)
        return list(rl)

    @classmethod
    def discover_one(cls, uid: str, scope=None, **kwargs) -> ClaudeDebugLogFsRecord | None:
        """Load a specific debug log session by ID."""
        rl = ClaudeDebugLogRecordList()
        return rl.get(uid)


# --- Record List ---


@dataclass
class ClaudeDebugLogRecordList:
    """Iterable collection of debug log records.

    Scans ``~/.claude/debug/*.txt``, optionally filtering by age.
    Only parses files that contain errors (hook errors or [ERROR] lines).

    Compatible with the ``ResourceRecordList`` iteration protocol
    used by the ``fs-records`` action.
    """

    list_path: Path | None = None
    hours: float = 168.0

    def __post_init__(self):
        if self.list_path is None:
            self.list_path = ClaudeDebugLogFsRecord.debug_dir()

    def _candidate_files(self) -> list[Path]:
        """Return .txt files within the time window, newest first."""
        if not self.list_path or not self.list_path.is_dir():
            return []
        cutoff = time.time() - (self.hours * 3600)
        files = []
        for entry in os.scandir(self.list_path):
            if entry.name.endswith(".txt") and entry.stat().st_mtime >= cutoff:
                files.append(Path(entry.path))
        files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return files

    def __iter__(self) -> Iterator[ClaudeDebugLogFsRecord]:
        for path in self._candidate_files():
            if has_errors(path):
                yield ClaudeDebugLogFsRecord.from_debug_file(path)

    def __len__(self) -> int:
        return sum(1 for _ in self)

    @property
    def records(self) -> list[ClaudeDebugLogFsRecord]:
        return list(self)

    def get(self, uid: str) -> ClaudeDebugLogFsRecord | None:
        """Load a specific session by ID."""
        if not self.list_path:
            return None
        path = self.list_path / f"{uid}.txt"
        if not path.exists():
            return None
        return ClaudeDebugLogFsRecord.from_debug_file(path)
