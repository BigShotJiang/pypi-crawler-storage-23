"""ClaudeOAuthAccountFsRecord -- OAuth account from ~/.claude.json /oauthAccount."""

from __future__ import annotations

from typing import Any, ClassVar

from flow_sdk.fs_store import Record, RecordType


class ClaudeOAuthAccountFsRecord(Record):
    """OAuth account credentials and metadata."""

    _read_only: ClassVar[bool] = True
    _record_type: ClassVar[str] = RecordType.CLAUDE_SETTINGS_OAUTH

    def __init__(self, **kwargs: Any):
        if "type" not in kwargs:
            kwargs["type"] = RecordType.CLAUDE_SETTINGS_OAUTH
        super().__init__(**kwargs)
        if self.account_uuid and not self._meta_data.get("id"):
            self.id = self.account_uuid

    @property
    def account_uuid(self) -> str:
        return (self._data or {}).get("account_uuid", "")

    @classmethod
    def from_raw(cls, data: dict) -> ClaudeOAuthAccountFsRecord:
        """Create from the oauthAccount sub-object."""
        rec = cls(
            account_uuid=data.get("accountUuid", ""),
            email_address=data.get("emailAddress", ""),
            organization_uuid=data.get("organizationUuid", ""),
            has_extra_usage_enabled=data.get("hasExtraUsageEnabled", False),
            billing_type=data.get("billingType", ""),
            account_created_at=data.get("accountCreatedAt", ""),
            subscription_created_at=data.get("subscriptionCreatedAt", ""),
            display_name=data.get("displayName", ""),
        )
        rec.id = rec.account_uuid or "default"
        return rec
