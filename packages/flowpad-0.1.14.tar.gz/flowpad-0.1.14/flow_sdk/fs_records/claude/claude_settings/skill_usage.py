"""ClaudeSkillUsageFsRecord -- per-skill usage entry from ~/.claude.json."""

from __future__ import annotations

from typing import Any, ClassVar

from flow_sdk.fs_store import Record, RecordType


class ClaudeSkillUsageFsRecord(Record):
    """Usage statistics for a single skill."""

    _read_only: ClassVar[bool] = True
    _record_type: ClassVar[str] = RecordType.CLAUDE_SETTINGS_SKILL_USAGE

    def __init__(self, **kwargs: Any):
        if "type" not in kwargs:
            kwargs["type"] = RecordType.CLAUDE_SETTINGS_SKILL_USAGE
        super().__init__(**kwargs)
        if self.skill_name and not self._meta_data.get("id"):
            self.id = self.skill_name

    @property
    def skill_name(self) -> str:
        return (self._data or {}).get("skill_name", "")

    @classmethod
    def from_raw(cls, skill_name: str, data: dict) -> ClaudeSkillUsageFsRecord:
        """Create from a skillUsage entry."""
        rec = cls(
            skill_name=skill_name,
            usage_count=data.get("usageCount", 0),
            last_used_at=data.get("lastUsedAt", 0),
        )
        rec.id = skill_name
        rec.name = skill_name
        return rec
