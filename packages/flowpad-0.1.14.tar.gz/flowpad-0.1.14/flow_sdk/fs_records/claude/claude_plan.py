"""ClaudePlanFsRecord — represents a saved Claude Code session plan.

Source: ~/.claude/plans/<slug>.md
Markdown files containing implementation plans generated during plan mode.
"""

from __future__ import annotations

from typing import ClassVar

from flow_sdk.fs_store import Record, RecordType


class ClaudePlanFsRecord(Record):
    """A saved Claude Code session plan.

    Mapped from ``~/.claude/plans/<slug>.md``.
    """

    _read_only: ClassVar[bool] = True

    def __init__(self, **kwargs):
        if "type" not in kwargs:
            kwargs["type"] = RecordType.PLAN
        kwargs.setdefault("slug", "")
        kwargs.setdefault("content", "")
        super().__init__(**kwargs)
        if self.slug:
            self.id = self.slug
            if not self.name:
                self.name = self.slug
