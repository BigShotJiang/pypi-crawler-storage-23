"""Memo record type for session memos, notes, and context snapshots."""

from __future__ import annotations

from typing import Any, ClassVar

from flow_sdk.fs_store import Record, RecordType


class MemoRecord(Record):
    """A memo record backed by Record."""

    _record_type: ClassVar[str] = RecordType.MEMO

    def __init__(self, **kwargs: Any):
        kwargs.setdefault("type", RecordType.MEMO)
        kwargs.setdefault("status", "open")
        super().__init__(**kwargs)
