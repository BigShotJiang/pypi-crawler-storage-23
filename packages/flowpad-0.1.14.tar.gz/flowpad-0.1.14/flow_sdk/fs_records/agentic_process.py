"""AgenticProcess record type for tracking processor lifecycle."""

from __future__ import annotations

from enum import StrEnum
from typing import Any, ClassVar

from flow_sdk.fs_store import Record, RecordType


class ProcessorStatus(StrEnum):
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    STEPPING = "stepping"
    COMPLETE = "complete"
    ERROR = "error"
    TERMINATED = "terminated"


class AgenticProcess(Record):
    _record_type: ClassVar[str] = RecordType.AGENTIC_PROCESS

    def __init__(self, **kwargs: Any):
        kwargs.setdefault("type", RecordType.AGENTIC_PROCESS)
        kwargs.setdefault("state", ProcessorStatus.IDLE)
        super().__init__(**kwargs)

    def to_dict(self) -> dict:
        d = super().to_dict()
        # FlowPad expects state as a ProcessorState dict, not a plain string
        d["state"] = {"status": d.get("state", self.state)}
        return d
