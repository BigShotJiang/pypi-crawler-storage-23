"""Relationship record type for graph edge synchronization."""

from __future__ import annotations

from flow_sdk.fs_store import RecordRef, Record


class RelationshipType:
    CHILD = "child"


class RelationshipRecord(Record):
    """A first-class relationship record between two resource refs."""

    def __init__(self, **kwargs):
        # Normalize ref dicts to RecordRef before passing to super
        from_ref = kwargs.get("from_ref")
        to_ref = kwargs.get("to_ref")
        if isinstance(from_ref, dict):
            kwargs["from_ref"] = RecordRef.from_dict(from_ref)
        if isinstance(to_ref, dict):
            kwargs["to_ref"] = RecordRef.from_dict(to_ref)
        if "type" not in kwargs:
            kwargs["type"] = RelationshipType.CHILD
        super().__init__(**kwargs)

    def to_dict(self) -> dict:
        """Serialize with RecordRef compact shape (omit null path)."""
        data = super().to_dict()
        from_ref = self.data.get("from_ref")
        to_ref = self.data.get("to_ref")
        if isinstance(from_ref, RecordRef):
            data["from_ref"] = from_ref.to_dict()
        if isinstance(to_ref, RecordRef):
            data["to_ref"] = to_ref.to_dict()
        return data

    @classmethod
    def from_dict(cls, data: dict) -> RelationshipRecord:
        """Deserialize and normalize ref fields into RecordRef."""
        rel = super().from_dict(data)
        from_ref = rel.data.get("from_ref")
        to_ref = rel.data.get("to_ref")
        if isinstance(from_ref, dict):
            rel.from_ref = RecordRef.from_dict(from_ref)
        if isinstance(to_ref, dict):
            rel.to_ref = RecordRef.from_dict(to_ref)
        return rel

    @staticmethod
    def make_id(rel_type: str, from_ref: RecordRef, to_ref: RecordRef) -> str:
        """Deterministic ID for the relationship edge."""
        return f"{rel_type}:{from_ref.type}:{from_ref.id}:{to_ref.type}:{to_ref.id}"

    @classmethod
    def child(cls, from_ref: RecordRef, to_ref: RecordRef) -> RelationshipRecord:
        """Create a canonical parent->child edge record."""
        rel_type = RelationshipType.CHILD
        return cls(
            id=cls.make_id(rel_type, from_ref, to_ref),
            type=rel_type,
            from_ref=from_ref,
            to_ref=to_ref,
        )
