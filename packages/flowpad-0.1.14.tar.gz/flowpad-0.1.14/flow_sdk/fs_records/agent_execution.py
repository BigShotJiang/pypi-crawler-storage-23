"""AgentExecution -- lifecycle manager for agent-based task execution.

Orchestrates: create records -> build context -> execute -> collect artifacts.

Replaces ad-hoc record management patterns from Skillit and session analysis.
"""

from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from flow_sdk.fs_store import RecordRef, RecordType
from flow_sdk.fs_store.sync_protocol import ResourceType, SyncOperation

from .agentic_process import AgenticProcess, ProcessorStatus
from .agent_record import AgentRecord
from .relationship import RelationshipRecord
from .task import TaskResource, TaskStatus

if TYPE_CHECKING:
    from flow_sdk.claude_env import ClaudeProjectEnvManager

logger = logging.getLogger(__name__)


class AgentExecution:
    """Orchestrates agent lifecycle: create records, build context, execute, collect artifacts.

    Usage::

        agent = AgentRecord.from_file("my-agent.md")
        env = ClaudeProjectEnvManager(root=tmp / "project")
        execution = agent.run(env, "Do the thing")
        await execution.wait_for_completion()
        skills = [a for a in execution.artifacts if a.type == RecordType.SKILL]
    """

    def __init__(
        self,
        agent: AgentRecord,
        session_id: str,
        workdir: str,
        task_type: str = "agent_run",
        task_title: str | None = None,
        env: ClaudeProjectEnvManager | None = None,
        instruction: str | None = None,
    ):
        self.agent = agent
        self.session_id = session_id
        self.workdir = workdir
        self.task_type = task_type
        self.task_title = task_title or f"Run agent: {agent.name}"
        self.env = env
        self.instruction = instruction

        self.task: TaskResource | None = None
        self.process: AgenticProcess | None = None
        self.relationship: RelationshipRecord | None = None
        self.process_id: str = str(uuid4())
        self._completed: bool = False

    def prepare(self, session_record_dir: Path | None = None) -> dict[str, Any]:
        """Create TaskResource + AgenticProcess + RelationshipRecord.

        Optionally saves to session_record_dir. Returns context_data dict
        suitable for passing to AgenticProcessor (includes agents_json).
        """
        # 1. Create task
        self.task = TaskResource(
            id=str(uuid4()),
            name=self.task_title,
            title=self.task_title,
            status=TaskStatus.IN_PROGRESS,
            task_type=self.task_type,
            tags=["agent", self.agent.name or "unnamed"],
            metadata={
                "agent_name": self.agent.name,
                "session_id": self.session_id,
                "process_id": self.process_id,
            },
        )

        # 2. Create agentic process
        self.process = AgenticProcess(
            id=self.process_id,
            name=f"agent:{self.agent.name}:{self.session_id[:8]}",
            state=ProcessorStatus.IDLE,
        )

        # 3. Create relationship: task -> process
        task_ref = RecordRef(id=self.task.id, type=RecordType.TASK)
        process_ref = RecordRef(id=self.process.id, type=RecordType.AGENTIC_PROCESS)
        self.relationship = RelationshipRecord.child(task_ref, process_ref)

        # 4. Optionally persist to session record dir
        if session_record_dir is not None:
            self.task.save_to(session_record_dir)

        # 5. Build context_data with agents_json
        agents_json = self.agent.to_agents_json()
        context_data: dict[str, Any] = {
            "workdir": self.workdir,
            "permission_mode": self.agent.data.get("permission_mode", "bypassPermissions"),
            "model": self.agent.data.get("model"),
            "agents_json": agents_json,
        }

        return context_data

    # -- Execution API ---------------------------------------------------------

    @property
    def output_dir(self) -> Path:
        """The output directory for this execution session."""
        if self.env is not None:
            return self.env.output_dir
        return Path(self.workdir) / "output"

    async def wait_for_completion(self) -> None:
        """Run the agent via ClaudeCLIWorker and wait for completion."""
        from flow_sdk.builtin.agentic_workers import ClaudeCLIWorker
        from flow_sdk.builtin.agentic_workers.context import AgenticContext

        if self._completed:
            return

        worker = ClaudeCLIWorker()
        ctx = AgenticContext(
            workdir=self.workdir,
            model=self.agent.data.get("model"),
            permission_mode=self.agent.data.get("permission_mode", "bypassPermissions"),
        )
        agents_json = self.agent.to_agents_json()
        async for _chunk in worker.execute(
            self.instruction or "", ctx, agents_json=agents_json,
        ):
            pass  # collect/stream chunks as needed

        self._completed = True
        self.mark_complete()

    @property
    def artifacts(self) -> list:
        """Scan the output directory for artifact records (skills, etc.)."""
        from .skill_record import SkillRecord

        results: list = []
        od = self.output_dir
        if not od.is_dir():
            return results

        for item in od.iterdir():
            if not item.is_dir() or item.name.startswith("."):
                continue
            if (item / "SKILL.md").exists():
                skill = SkillRecord.load_record(item)
                if skill is not None:
                    results.append(skill)

        return results

    def sync_to_flowpad(self, wait: bool = False) -> None:
        """Send entity sync notifications for task, process, relationship."""
        try:
            from flow_sdk.discovery.notify import send_entity_sync
        except ImportError:
            logger.debug("discovery.notify not available, skipping sync")
            return

        if self.task:
            send_entity_sync(SyncOperation.CREATE, self.task.to_dict(), wait=wait)
        if self.process:
            send_entity_sync(SyncOperation.CREATE, self.process.to_dict(), wait=wait)
        if self.relationship:
            send_entity_sync(
                SyncOperation.CREATE,
                self.relationship.to_dict(),
                resource_type=ResourceType.RELATIONSHIP,
                wait=wait,
            )

    def mark_complete(self) -> None:
        """Transition task to DONE, process to COMPLETE, sync updates."""
        if self.task:
            self.task.status = TaskStatus.DONE
        if self.process:
            self.process.state = ProcessorStatus.COMPLETE

        try:
            from flow_sdk.discovery.notify import send_entity_sync
        except ImportError:
            return

        if self.task:
            send_entity_sync(SyncOperation.UPDATE, self.task.to_dict())
        if self.process:
            send_entity_sync(SyncOperation.UPDATE, self.process.to_dict())

    def mark_error(self, error: str) -> None:
        """Transition process to ERROR, sync updates."""
        if self.process:
            self.process.state = ProcessorStatus.ERROR
            if self.process._data is None:
                object.__setattr__(self.process, "_data", {})
            self.process._data["error"] = error

        try:
            from flow_sdk.discovery.notify import send_entity_sync
        except ImportError:
            return

        if self.process:
            send_entity_sync(SyncOperation.UPDATE, self.process.to_dict())

    def install_output_skills(
        self,
        output_dir: Path,
        scope: str = "user",
        project_dir: str | Path | None = None,
    ) -> list[Path]:
        """Scan output_dir for skill folders and copy them to the target scope.

        Returns list of installed skill paths.
        """
        from .skill_record import SkillRecord

        installed: list[Path] = []
        if not output_dir.is_dir():
            return installed

        for item in output_dir.iterdir():
            if not item.is_dir() or item.name.startswith("."):
                continue
            skill_md = item / "SKILL.md"
            if not skill_md.exists():
                continue

            skill = SkillRecord.load_record(item)
            if scope == "project" and project_dir:
                dest = skill.copy_to_project(str(project_dir))
            else:
                dest = skill.copy_to_claude_user_home()
            installed.append(dest)
            logger.info("Installed skill %s to %s", skill.name, dest)

        return installed
