"""Database initialization and session management.

Provides async session factory and database initialization utilities
for the flow-cli application.
"""

import logging
from contextlib import asynccontextmanager
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from flow_sdk.db.drivers.sqlite.connection import create_engine_and_session

logger = logging.getLogger(__name__)

# Global session factory - will be initialized on first use
_session_factory: Optional[async_sessionmaker] = None
_engine = None


async def init_db() -> None:
    """Initialize the database engine and create tables.

    Should be called once at application startup.
    """
    global _session_factory, _engine

    if _session_factory is not None:
        logger.debug("Database already initialized")
        return

    logger.info("Initializing database...")
    _engine, _session_factory = await create_engine_and_session()
    logger.info("Database initialized successfully")


async def close_db() -> None:
    """Dispose the database engine and clear the session factory.

    Should be called once at application shutdown.
    """
    global _session_factory, _engine
    if _engine is not None:
        await _engine.dispose()
        _engine = None
    _session_factory = None


@asynccontextmanager
async def async_session():
    """Get a database session as an async context manager.

    Usage:
        async with async_session() as session:
            result = await session.execute(select(...))

    Raises:
        RuntimeError: If database has not been initialized
    """
    global _session_factory

    if _session_factory is None:
        await init_db()

    session: AsyncSession = _session_factory()
    try:
        yield session
    finally:
        await session.close()


__all__ = ["init_db", "close_db", "async_session"]
