from typing import Any, Dict, List


class RegistryEntry:
    def __init__(self, name: str, entity: Any, source_hash: str):
        self.name = name
        self.source_hash = source_hash
        self.entity_model = entity

    def __str__(self):
        return self.name

    def __repr__(self):
        return self.name


# noinspection PyUnreachableCode
def get_class_hash(cls):
    if cls is None:
        return "hash of none"
    return cls.__module__ + "." + cls.__name__


class TypeRegistry:
    def __init__(self):
        self._types: Dict[str, RegistryEntry] = {}
        self.private_types = ["flowpad_service"]

    def _add_to_registry(self, name: str, entity=None):
        source_hash = get_class_hash(entity)
        self._types[name] = RegistryEntry(name, entity, source_hash)

    def register(self, type_name: str, entity=None):
        type_name = type_name.lower()
        existing = self.get_entry_by_name(type_name)
        if not existing or existing.entity_model is None:
            self._add_to_registry(type_name, entity)
            return
        if existing.source_hash != get_class_hash(entity):
            return
            # TODO managing conflicts is a bit more complex, for now last one wins
            # raise Exception(f'Entity with name {name} registration conflict')
        return

    @property
    def entity_models(self) -> List[Any]:  # Entity
        return [self._types[k].entity_model for k in self._types.keys()]

    @property
    def registered_keys(self) -> List[str]:
        return [k for k in self._types.keys()]

    def is_registered(self, type_name: str):
        type_name = type_name.lower()
        return type_name in self.registered_keys

    def is_implemented(self, type_name: str):
        if not self.is_registered(type_name):
            return False
        entry = self.get_entry_by_name(type_name)
        return entry and entry.entity_model is not None

    def get_entry_by_name(self, type_name: str):
        type_name = type_name.lower()
        if type_name not in self._types:
            return None
        return self._types[type_name]

    def is_public(self, type_name: str):
        # noinspection PyBroadException
        try:
            entry = self.get_entry_by_name(type_name)
            if entry and entry.entity_model:
                if entry.entity_model.api_visible():
                    return True
            return False
        except Exception:
            return False

    def get(self, name: str) -> Any:
        entry = self.get_entry_by_name(name)
        if entry:
            if entry.entity_model:
                return entry.entity_model
            return lambda **kwargs: kwargs
        return None

    def get_all_types(self) -> List[str]:
        return [k.lower() for k in self._types.keys()]

    def get_public_types(self) -> List[str]:
        return [k.lower() for k in self.get_all_types() if self.is_public(k.lower())]

    def __getitem__(self, name):
        name = name.lower()
        return self.get(name)


type_registry: TypeRegistry = TypeRegistry()


def is_entity_type(e_type: str) -> bool:
    return type_registry.get(e_type) is not None
