import asyncio
from typing import List

from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

from flow_sdk import service_log
from flow_sdk.external_apis.oauth_lib import AuthSession
from flow_sdk.external_apis.oauth_lib.oauth_provider_config import (
    OAuthParamMapping,
    OauthProviderConfig,
    OAuthRequestMapping,
    OAuthRequestType,
    RequestParamMappingType,
)
from flow_sdk.external_apis.oauth_lib.tester.local_app.local_oauth_app import LocalApp

code_request_params: List[OAuthParamMapping] = [
    OAuthParamMapping(name="client_id"),
    OAuthParamMapping(name="scopes", mapping=RequestParamMappingType.CSV, mapped_name="scope"),
    OAuthParamMapping(name="user_scope", mapping=RequestParamMappingType.CSV),
    OAuthParamMapping(name="state"),
    OAuthParamMapping(name="redirect_uri"),
]
code_request_map = OAuthRequestMapping(params_mappings=code_request_params, request_type=OAuthRequestType.BROWSER_LINK)
code_response_params: List[OAuthParamMapping] = [
    OAuthParamMapping(name="state"),
    OAuthParamMapping(name="code"),
]

token_request_params: List[OAuthParamMapping] = [
    OAuthParamMapping(name="code"),
    OAuthParamMapping(name="redirect_uri"),
    OAuthParamMapping(name="grant_type", mapping=RequestParamMappingType.VALUE, value="authorization_code"),
    OAuthParamMapping(name="client_id"),
    OAuthParamMapping(name="client_secret"),
]
token_request_map = OAuthRequestMapping(params_mappings=token_request_params, request_type=OAuthRequestType.POST)
slack_config = OauthProviderConfig(
    provider_name="slack",
    auth_url="https://slack.com/oauth/v2/authorize",
    token_url="https://slack.com/api/oauth.v2.access",
    revoke_url="https://slack.com/api/auth.revoke",
    client_id="6669333671878.8524158055136",
    client_secret="8045367db31555af58ca57d69295b124",
    scopes=["assistant:write", "app_mentions:read", "groups:read", "channels:read", "chat:write"],
    use_pkce=False,
    extras={
        "user_scope": ["chat:write", "channels:read", "usergroups:read", "groups:read"],
    },
    code_request_map=code_request_map,
    code_response_mapping=code_response_params,
    token_request_map=token_request_map,
)


def auth_slack():
    # Define a Slack provider configuration.

    # Instantiate the Slack provider and the OAuth flow state machine.
    pass


async def main():
    service_log.info("starting test app")
    app = LocalApp()
    await app.start()
    service_log.info("Test app ready")
    session: AuthSession = AuthSession(slack_config)
    service_log.info(f"session: {session.state}")
    await app.start_session(session)
    service_log.info("Session started")
    await session.wait_for_code()
    service_log.info("Code granted")
    token_response = await session.get_token()
    service_log.info(token_response.access_token)
    bot_token = token_response.access_token
    bot_client = WebClient(token=bot_token)

    def get_channel_id_by_name(c_name):
        try:
            # Retrieve channels (handle pagination if necessary)
            result = bot_client.conversations_list(limit=100, types=["public_channel", "private_channel"])
            channels = result.get("channels", [])

            for channel in channels:
                if channel["name"] == c_name:
                    return channel["id"]
            return None  # Channel not found
        except SlackApiError as slack_exception:
            service_log.error(f"Error fetching conversations: {slack_exception.response['error']}")
            return None

    # Example usage:
    channel_name = "boto"  # or any other channel name
    channel_id = get_channel_id_by_name(channel_name)
    if channel_id:
        try:
            response = bot_client.chat_postMessage(
                channel=channel_id,
                text="Hi, I'm a bot!",
            )
            service_log.info(f"Message sent successfully: {response['message']['text']}")
        except SlackApiError as e:
            service_log.error(f"Error sending message: {e.response['error']}")
        # try:
        #     response = user_client.chat_postMessage(
        #         channel=channel_id,
        #         text="Hi, I'm a user! (but this is still the bot sending as me)",
        #     )
        #     service_log.info(f"Message sent successfully: {response['message']['text']}")
        # except SlackApiError as e:
        #     service_log.error(f"Error sending message: {e.response['error']}")
    else:
        service_log.warning(f"Channel '{channel_name}' not found.")


if __name__ == "__main__":
    asyncio.run(main())
