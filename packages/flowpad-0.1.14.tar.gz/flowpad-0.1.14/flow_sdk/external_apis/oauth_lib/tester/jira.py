import asyncio
from typing import List

from flow_sdk.external_apis.oauth_lib.oauth_provider_config import (
    OAuthParamMapping,
    OauthProviderConfig,
    OAuthRequestMapping,
    OAuthRequestType,
    RequestParamMappingType,
)
from flow_sdk.external_apis.oauth_lib.tester.local_app.local_oauth_app import LocalApp

# ruff: noqa
code_request_params: List[OAuthParamMapping] = [
    OAuthParamMapping(name="client_id"),
    OAuthParamMapping(name="scopes", mapping=RequestParamMappingType.SSV, mapped_name="scope", url_encode=True),
    OAuthParamMapping(name="state"),
    OAuthParamMapping(name="redirect_uri", url_encode=True),
    OAuthParamMapping(name="response_type", mapping=RequestParamMappingType.VALUE, value="code"),
    OAuthParamMapping(name="prompt", mapping=RequestParamMappingType.VALUE, value="consent"),
]
code_request_map = OAuthRequestMapping(params_mappings=code_request_params)

code_response_params: List[OAuthParamMapping] = [
    OAuthParamMapping(name="state"),
    OAuthParamMapping(name="code"),
]

token_request_params: List[OAuthParamMapping] = [
    OAuthParamMapping(name="code"),
    OAuthParamMapping(name="redirect_uri", url_encode=True),
    OAuthParamMapping(name="grant_type", mapping=RequestParamMappingType.VALUE, value="authorization_code"),
    OAuthParamMapping(name="client_id"),
    OAuthParamMapping(name="client_secret"),
]
token_request_map = OAuthRequestMapping(params_mappings=token_request_params, request_type=OAuthRequestType.POST)

# noinspection SpellCheckingInspection
atlassian_config = OauthProviderConfig(
    provider_name="atlassian",
    audience="api.atlassian.com",
    auth_url="https://auth.atlassian.com/authorize",
    token_url="https://auth.atlassian.com/oauth/token",
    client_id="7Uz0wZIia2rQviDDKPFZOcgkPond8464",
    client_secret="ATOAHGd-XIThdN8bo0l-2cea5O0oBcOxmr-h3JWiAH6SJIeHfa3vv7c0J2BOyOR-dPV8D3004DA5",
    scopes=["read:me", "read:jira-user", "read:jira-work", "write:jira-work", "offline_access"],
    use_pkce=False,
    code_request_map=code_request_map,
    code_response_mapping=code_response_params,
    token_request_map=token_request_map,
)


async def main():
    print("starting test app")
    app = LocalApp()
    await app.start()
    print("Test app ready")
    session = await app.start_session(atlassian_config)
    print("Session started")
    await session.wait_for_code()
    print("Code granted")
    token_response = await session.get_token()
    print(token_response.access_token)


if __name__ == "__main__":
    asyncio.run(main())
