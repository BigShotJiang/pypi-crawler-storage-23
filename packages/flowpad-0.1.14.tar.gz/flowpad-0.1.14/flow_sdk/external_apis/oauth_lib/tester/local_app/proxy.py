import http.client
import http.server
import os
import ssl

import requests
from dotenv import find_dotenv, load_dotenv

env = os.getenv("ENV", ".env.local")
env_file = find_dotenv(env)
print(f"Loading env file: {env_file}")
load_dotenv(env_file)
reverse_proxy_url: str = os.getenv(key="REVERSE_PROXY_URL")
# ruff: noqa


class ProxyHTTPRequestHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.proxy_request()

    def do_POST(self):
        self.proxy_request()

    def proxy_request(self):
        # Define the target server and port
        target_host = "localhost"
        target_port = 8000
        content_length = int(self.headers.get("Content-Length", 0))
        request_body = self.rfile.read(content_length) if content_length > 0 else None

        host = self.headers.get("Host", "")
        flowpad_path = self.path

        if reverse_proxy_url in host:
            print("Reverse proxy URL found in host: ", reverse_proxy_url)
            # TODO use consts
            flowpad_path = "/api/v1/webhook/plugin/slack"

        target_url = f"http://{target_host}:{target_port}{flowpad_path}"
        headers = {key: value for key, value in self.headers.items()}

        response = requests.request(method=self.command, url=target_url, headers=headers, data=request_body)

        self.send_response(response.status_code)
        for header, value in response.headers.items():
            self.send_header(header, value)
        self.end_headers()
        self.wfile.write(response.content)


def run(server_class=http.server.HTTPServer, handler_class=ProxyHTTPRequestHandler):
    server_address = ("", 5600)
    # noinspection PyTypeChecker
    httpd = server_class(server_address, handler_class)

    # Create an SSL context
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile="cert.pem", keyfile="key.pem")

    # Wrap the server's socket with the SSL context
    httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

    print("Starting proxy server on https://localhost:5600...")
    httpd.serve_forever()


if __name__ == "__main__":
    run()
