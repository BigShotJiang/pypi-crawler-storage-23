import asyncio
import os.path
import threading
import webbrowser
from pathlib import Path

import httpx
import uvicorn
from fastapi import FastAPI
from starlette.requests import Request
from starlette.responses import HTMLResponse

from flow_sdk import service_log
from flow_sdk.external_apis.oauth_lib.auth_session import AuthSession
from flow_sdk.external_apis.oauth_lib.oauth_provider_config import AuthUIConfig


# Each LocalApp has its own FastAPI app and unique port
async def _fetch_until_success(url: str, timeout: float = 10.0):
    async with httpx.AsyncClient(timeout=timeout, verify=False) as client:
        while True:
            try:
                response = await client.get(
                    url,
                )
                if response.status_code == 200:
                    service_log.info("local server alive")
                    return response.text
                elif response.status_code == 403:
                    raise Exception(f"Forbidden: {url}, status code: {response.status_code}")
                else:
                    service_log.info(f"Received status code {response.status_code}. Retrying in 1 second...")
            except httpx.RequestError as exc:
                service_log.info(f"An error occurred: {exc}. Retrying in 1 second...")
            await asyncio.sleep(1)  # Wait for 1 second before the next attempt


async def _open_auth_ui(url: str) -> None:
    webbrowser.open(url)


class LocalApp:
    def __init__(self, host="localhost", port=6123):
        super().__init__()
        self.host = host
        self.port = port
        self.server_thread = None
        self.app = FastAPI()
        self.ui_config: AuthUIConfig | None = None
        self.sessions: dict[str, AuthSession] = {}

        # Define the root route to include the app's unique client_id
        @self.app.get("/")
        def read_root():
            return "hello"

        @self.app.get("/callback/{provider}")
        def auth_callback(provider, request: Request):
            session = self.get_session_by_provider(provider)
            if session is None:
                return "Session not found"
            session.set_code_response(dict(request.query_params))
            return "Code granted"

        # Define the root route to include the app's unique client_id
        @self.app.get("/auth/{provider}", response_class=HTMLResponse)
        def auth_form(provider: str):
            session = self.get_session_by_provider(provider)
            if session is None:
                return "Session not found"
            start_url = session.start()
            name = session.config.provider_name
            service_log.info(start_url)
            return f"<a href='{start_url}'>Add {name}</a>"
            # return f"""<body><a href = "https://slack.com/oauth/v2/authorize?scope=assistant%3Awrite%2Capp_mentions%3Aread&amp;user_scope=chat%3Awrite%2Cchannels%3Aread&amp;redirect_uri=https%3A%2F%2Flocalhost%3A6123%2Fcallback&amp;client_id=6669333671878.8524158055136" style = "align-items:center;color:#000;background-color:#fff;border:1px solid #ddd;border-radius:4px;display:inline-flex;font-family:Lato, sans-serif;font-size:14px;font-weight:600;height:44px;justify-content:center;text-decoration:none;width:204px"> <svg xmlns = "http://www.w3.org/2000/svg"
            # style = "height:16px;width:16px;margin-right:12px"
            # viewBox = "0 0 122.8 122.8" > < path
            # d = "M25.8 77.6c0 7.1-5.8 12.9-12.9 12.9S0 84.7 0 77.6s5.8-12.9 12.9-12.9h12.9v12.9zm6.5 0c0-7.1 5.8-12.9 12.9-12.9s12.9 5.8 12.9 12.9v32.3c0 7.1-5.8 12.9-12.9 12.9s-12.9-5.8-12.9-12.9V77.6z"
            # fill = "#e01e5a" > < / path > < path
            # d = "M45.2 25.8c-7.1 0-12.9-5.8-12.9-12.9S38.1 0 45.2 0s12.9 5.8 12.9 12.9v12.9H45.2zm0 6.5c7.1 0 12.9 5.8 12.9 12.9s-5.8 12.9-12.9 12.9H12.9C5.8 58.1 0 52.3 0 45.2s5.8-12.9 12.9-12.9h32.3z"
            # fill = "#36c5f0" > < / path > < path
            # d = "M97 45.2c0-7.1 5.8-12.9 12.9-12.9s12.9 5.8 12.9 12.9-5.8 12.9-12.9 12.9H97V45.2zm-6.5 0c0 7.1-5.8 12.9-12.9 12.9s-12.9-5.8-12.9-12.9V12.9C64.7 5.8 70.5 0 77.6 0s12.9 5.8 12.9 12.9v32.3z"
            # fill = "#2eb67d" > < / path > < path
            # d = "M77.6 97c7.1 0 12.9 5.8 12.9 12.9s-5.8 12.9-12.9 12.9-12.9-5.8-12.9-12.9V97h12.9zm0-6.5c-7.1 0-12.9-5.8-12.9-12.9s5.8-12.9 12.9-12.9h32.3c7.1 0 12.9 5.8 12.9 12.9s-5.8 12.9-12.9 12.9H77.6z"
            # fill = "#ecb22e" > < / path > < / svg > Add
            # to
            # Slack </a><a href='{start_url}'>Add to Slack 2</a>{start_url} </body>"""

    def get_session_by_provider(self, provider_name: str):
        for session in self.sessions.values():
            if session.config.provider_name == provider_name:
                return session
        return None

    @property
    def host_address(self):
        return f"https://{self.host}:{self.port}"

    def session_ui_url(self, provider_name):
        return f"{self.host_address}/auth/{provider_name}"

    def session_redirect_url(self, provider_name):
        return f"{self.host_address}/callback/{provider_name}"

    @property
    def callback_url(self):
        return f"{self.host_address}/callback"

    # async def wait_for_login(self, timeout=20):
    #     passed_time = 0
    #     while not self.called:
    #         await asyncio.sleep(1)  # Wait for 1 second before the next attempt
    #         passed_time += 1
    #         print(f"waiting for login {passed_time}")
    #         if passed_time > timeout:
    #             raise Exception("Timeout waiting for login")

    async def start_session(self, session: AuthSession):
        if session.id in self.sessions:
            raise Exception("Session already exists")
        self.sessions[session.id] = session
        session.app_redirect_base_uri = self.session_redirect_url(session.config.provider_name)
        await _open_auth_ui(self.session_ui_url(session.config.provider_name))
        return session

    async def start(self):
        # Start this FastAPI app on its designated port in a new thread
        self.server_thread = threading.Thread(target=self.run_server, daemon=True)
        self.server_thread.start()
        await _fetch_until_success(self.host_address)

    def run_server(self):
        current_folder_path = str(Path(__file__).parent)
        key_path = os.path.join(current_folder_path, "key.pem")
        cert_path = os.path.join(current_folder_path, "cert.pem")
        uvicorn.run(
            self.app,
            host="127.0.0.1",
            port=self.port,
            ssl_keyfile=key_path,
            # Update with your key file path
            ssl_certfile=cert_path,
        )
