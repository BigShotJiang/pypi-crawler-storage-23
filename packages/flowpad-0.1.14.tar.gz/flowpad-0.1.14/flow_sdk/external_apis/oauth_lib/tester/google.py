import asyncio
from typing import List

from flow_sdk import service_log
from flow_sdk.external_apis.oauth_lib.oauth_provider_config import (
    OAuthParamMapping,
    OauthProviderConfig,
    OAuthRequestMapping,
    OAuthRequestType,
    RequestParamMappingType,
)
from flow_sdk.external_apis.oauth_lib.tester.local_app.local_oauth_app import LocalApp

code_request_params: List[OAuthParamMapping] = [
    OAuthParamMapping(name="client_id"),
    OAuthParamMapping(name="scopes", mapping=RequestParamMappingType.SSV, mapped_name="scope", url_encode=True),
    OAuthParamMapping(name="state"),
    OAuthParamMapping(name="redirect_uri", url_encode=True),
    OAuthParamMapping(name="response_type", mapping=RequestParamMappingType.VALUE, value="code"),
    OAuthParamMapping(name="access_type", mapping=RequestParamMappingType.VALUE, value="offline"),
    OAuthParamMapping(name="include_granted_scopes", mapping=RequestParamMappingType.VALUE, value="true"),
]
code_request_map = OAuthRequestMapping(params_mappings=code_request_params)

code_response_params: List[OAuthParamMapping] = [
    OAuthParamMapping(name="state"),
    OAuthParamMapping(name="code"),
]
token_request_params: List[OAuthParamMapping] = [
    OAuthParamMapping(name="code"),
    OAuthParamMapping(name="redirect_uri", url_encode=True),
    OAuthParamMapping(name="grant_type", mapping=RequestParamMappingType.VALUE, value="authorization_code"),
    OAuthParamMapping(name="client_id"),
    OAuthParamMapping(name="client_secret"),
]
token_request_map = OAuthRequestMapping(params_mappings=token_request_params, request_type=OAuthRequestType.POST)
# noinspection SpellCheckingInspection
google_config = OauthProviderConfig(
    provider_name="google",
    auth_url="https://accounts.google.com/o/oauth2/v2/auth",
    token_url="https://oauth2.googleapis.com/token",
    client_id="494862393260-l41v0g4lmsll730rig1anibugupkol6e.apps.googleusercontent.com",
    client_secret="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",
    scopes=["https://www.googleapis.com/auth/userinfo.email"],
    use_pkce=False,
    code_request_map=code_request_map,
    code_response_mapping=code_response_params,
    token_request_map=token_request_map,
)


# scopes=["https://www.googleapis.com/auth/gmail.modify",
#            "https://www.googleapis.com/auth/calendar.events"],


async def main():
    service_log.info("starting test app")
    app = LocalApp()
    await app.start()
    service_log.info("Test app ready")
    session = await app.start_session(google_config)
    service_log.info("Session started")
    await session.wait_for_code(timeout=500)
    service_log.info("Code granted")
    token_response = await session.get_token()
    if token_response:
        service_log.info(token_response.access_token)


if __name__ == "__main__":
    asyncio.run(main())
