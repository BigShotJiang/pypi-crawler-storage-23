"""Authentication and authorization module."""
