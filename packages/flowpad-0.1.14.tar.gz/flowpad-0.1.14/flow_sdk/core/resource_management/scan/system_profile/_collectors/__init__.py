"""Collectors package."""
