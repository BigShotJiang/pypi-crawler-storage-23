"""Composable query for filtering, sorting, and paginating Records.

Usage::

    q = RecordQuery(
        types=["claude_session"],
        modified_after=datetime(2026, 1, 1),
        sort_by="modified_at",
        limit=10,
    )
    results = q.apply(records)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any, Callable, Iterable

if TYPE_CHECKING:
    from .record import Record


@dataclass
class RecordQuery:
    """Declarative filter + sort + pagination for records.

    All filter fields are optional — ``None`` means "no constraint".
    Combine freely; they are AND-ed together.
    """

    # Identity filters
    ids: list[str] | None = None
    types: list[str] | None = None
    status: str | list[str] | None = None

    # Date-range filters (compares against record.created_at / modified_at)
    created_after: datetime | None = None
    created_before: datetime | None = None
    modified_after: datetime | None = None
    modified_before: datetime | None = None

    # Relationship filters
    parent_id: str | None = None
    child_filter: RecordQuery | None = None  # recursive composition

    # Arbitrary predicate (for caller-supplied logic)
    predicate: Callable[[Record], bool] | None = None

    # Pagination & sorting
    limit: int | None = None
    offset: int = 0
    sort_by: str | None = None  # "created_at", "modified_at", "name"
    sort_desc: bool = True

    def matches(self, record: Record) -> bool:
        """Return True if *record* passes all filter criteria."""
        if self.ids is not None and record.uid not in self.ids:
            return False

        if self.types is not None and record.type not in self.types:
            return False

        if self.status is not None:
            rec_status = str(record.status) if record.status else ""
            if isinstance(self.status, list):
                if rec_status not in self.status:
                    return False
            elif rec_status != self.status:
                return False

        if self.created_after is not None:
            ca = record.created_at
            if ca is None or ca < self.created_after:
                return False

        if self.created_before is not None:
            ca = record.created_at
            if ca is None or ca > self.created_before:
                return False

        if self.modified_after is not None:
            ma = record.modified_at
            if ma is None or ma < self.modified_after:
                return False

        if self.modified_before is not None:
            ma = record.modified_at
            if ma is None or ma > self.modified_before:
                return False

        if self.parent_id is not None:
            pr = record.parent_ref
            parent_ok = pr is not None and pr.id == self.parent_id
            if not parent_ok:
                return False

        if self.predicate is not None and not self.predicate(record):
            return False

        return True

    def apply(self, records: Iterable[Record]) -> list[Record]:
        """Filter, sort, and paginate *records*."""
        # Filter
        result = [r for r in records if self.matches(r)]

        # Sort
        if self.sort_by:
            key_attr = self.sort_by

            def _sort_key(r: Record) -> Any:
                val = getattr(r, key_attr, None)
                if val is None:
                    # Push None to the end regardless of direction
                    return (1, "")
                return (0, val)

            result.sort(key=_sort_key, reverse=self.sort_desc)

        # Paginate
        if self.offset:
            result = result[self.offset:]
        if self.limit is not None:
            result = result[:self.limit]

        return result
