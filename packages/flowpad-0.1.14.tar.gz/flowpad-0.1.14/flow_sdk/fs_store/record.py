"""Unified Record class — merges ResourceRecord + FsRecord into one.

Single base class with:
- Two-dict internal storage (_meta_data for identity/audit, _data for domain fields)
- Dirty tracking (_meta_dirty, _data_dirty)
- Two-file on-disk layout (.flow_record/record.json + record_data.json)
- Unified save() with single entry point
- Orphan detection for external data refs
"""

from __future__ import annotations

import copy
import hashlib
import json
import platform
import shutil
import subprocess
import uuid
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, ClassVar, TypeVar

from .record_ref import RecordRef
from .scope import Scope
from .storage_layout import StorageLayout

T = TypeVar("T", bound="Record")

_RECORD_JSON = "record.json"
_RECORD_DATA_JSON = "record_data.json"
_RECORD_DIR = ".flow_record"

_DEFAULT_RECORDS_ROOT: Path = Path.home() / ".flow" / "records"


def get_default_records_root() -> Path:
    """Return the default root for record storage."""
    return _DEFAULT_RECORDS_ROOT


def set_default_records_root(path: Path) -> None:
    """Override the default records root (primarily for testing)."""
    global _DEFAULT_RECORDS_ROOT
    _DEFAULT_RECORDS_ROOT = path


def _resolve_record_json(folder: Path) -> Path:
    """Find the record JSON inside *folder*, preferring new convention.

    Returns ``folder/.flow_record/record.json`` if it exists, otherwise
    falls back to ``folder/record.json`` (legacy). When neither exists the
    new-convention path is returned (for creation).
    """
    new = folder / _RECORD_DIR / _RECORD_JSON
    if new.exists():
        return new
    old = folder / _RECORD_JSON
    if old.exists():
        return old
    return new  # default to new convention for creation


class RecordStatus(str, Enum):
    """Status of a record."""
    CREATING = "creating"
    NEW = "new"
    ACTIVE = "active"
    ORPHAN = "orphan"


# Naming convention: <type>-@<uid>
_NAME_SEP = "-@"


def record_stem(record_type: str, uid: str) -> str:
    """Build the canonical stem used for file / folder names."""
    return f"{record_type}{_NAME_SEP}{uid}"


def parse_record_stem(stem: str) -> tuple[str, str]:
    """Parse a ``<type>-@<uid>`` stem into (type, uid)."""
    if _NAME_SEP not in stem:
        raise ValueError(f"Invalid record stem: {stem!r}")
    record_type, uid = stem.split(_NAME_SEP, 1)
    return record_type, uid


# Meta fields — these live in record.json (_meta_data)
_META_FIELDS: frozenset[str] = frozenset({
    "id", "type", "name", "status",
    "created_at", "modified_at", "created_by", "updated_by",
    "scope",
    "parent", "children", "origin", "data_ref",
    # Legacy key names (from ResourceRecord era)
    "parent_ref", "children_refs", "origin_ref", "parent_id",
})

# Fields that should never appear in serialized output
_INTERNAL_FIELDS: frozenset[str] = frozenset({
    "source_file", "path", "entity_id",
    "json_path",
    "fs_sync", "storage_layout",
})

# Fields from FsRecord/ResourceRecord infrastructure that SourceFileRecordList
# should skip when converting records back to JSON
_INFRA_FIELDS: frozenset[str] = _META_FIELDS | _INTERNAL_FIELDS | frozenset({
    "raw_json",
})

_FS_SYNC_SKIP = frozenset({"fs_sync", "storage_layout", "source_file", "path"})


class Record:
    """Unified base class for all records.

    NOT a dataclass. Uses two internal dicts with properties on top:
    - _meta_data: identity, audit, refs, scope -> persisted to record.json
    - _data: domain-specific fields -> persisted to record_data.json (owned)
                                       or loaded from data_ref (external)

    Subclasses define domain properties on _data.
    """

    # Subclasses set this to auto-register in the type registry.
    _record_type: ClassVar[str] = ""
    # Subclasses set this to True to prevent writes.
    _read_only: ClassVar[bool] = False
    # Which field serves as the unique identifier.
    uid_field_name: ClassVar[str] = "id"

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        rt = cls.__dict__.get("_record_type")
        if rt:
            from .factory.type_registry import type_registry
            if rt not in type_registry:
                type_registry.register(rt, cls)

    def __init__(self, _meta: dict | None = None, _data: dict | None = None, **kwargs: Any):
        """Initialize a Record.

        Can be called three ways:
        1. Record() — empty record with generated UUID
        2. Record(_meta={...}, _data={...}) — explicit split
        3. Record(id="x", name="y", description="z") — kwargs split automatically
        """
        object.__setattr__(self, "_meta_data", {})
        object.__setattr__(self, "_data", None)
        object.__setattr__(self, "_meta_dirty", False)
        object.__setattr__(self, "_data_dirty", False)
        object.__setattr__(self, "_source_file", None)
        object.__setattr__(self, "_path", None)
        # fs_sync and storage_layout as plain instance attrs
        object.__setattr__(self, "fs_sync", False)
        object.__setattr__(self, "storage_layout", StorageLayout.FOLDER)

        if _meta is not None:
            self._meta_data.update(_meta)
        if _data is not None:
            object.__setattr__(self, "_data", _data)

        # Split kwargs into meta vs data
        if kwargs:
            for key, value in kwargs.items():
                if key in _META_FIELDS or key in _INTERNAL_FIELDS:
                    self._set_meta_field(key, value)
                elif key == "raw_json":
                    # Merge raw_json into _data
                    if self._data is None:
                        object.__setattr__(self, "_data", {})
                    self._data.update(value)
                elif key == "fs_sync":
                    object.__setattr__(self, "fs_sync", value)
                elif key == "storage_layout":
                    object.__setattr__(self, "storage_layout", value)
                else:
                    if self._data is None:
                        object.__setattr__(self, "_data", {})
                    self._data[key] = value

        # Ensure id exists
        if "id" not in self._meta_data:
            self._meta_data["id"] = str(uuid.uuid4())

    def __getattr__(self, name: str) -> Any:
        """Fallback attribute access: check _data dict for domain fields.

        This is only called when normal attribute lookup fails (i.e. no
        property/descriptor/instance-attr found). Provides transparent
        access to _data fields without needing explicit properties.
        """
        # Avoid recursion for internal attrs
        if name.startswith("_"):
            raise AttributeError(name)
        # Try _data dict
        try:
            data = object.__getattribute__(self, "_data")
        except AttributeError:
            raise AttributeError(name)
        if data is not None and name in data:
            return data[name]
        raise AttributeError(f"{self.__class__.__name__!r} has no attribute {name!r}")

    def __setattr__(self, name: str, value: Any) -> None:
        """Route attribute writes to the correct storage.

        - Internal/private attrs (_foo) → object.__setattr__
        - Meta fields (id, type, name, etc.) → property setter
        - fs_sync, storage_layout → object.__setattr__
        - Everything else → _data dict (with dirty tracking + auto-sync)
        """
        # Internal attrs
        if name.startswith("_"):
            object.__setattr__(self, name, value)
            return

        # Check if there's a property descriptor for this name
        for cls in type(self).__mro__:
            if name in cls.__dict__:
                desc = cls.__dict__[name]
                if isinstance(desc, property) and desc.fset is not None:
                    desc.fset(self, value)
                    return
                elif isinstance(desc, property):
                    raise AttributeError(f"can't set attribute {name!r}")

        # Instance-level attrs (fs_sync, storage_layout)
        if name in ("fs_sync", "storage_layout"):
            object.__setattr__(self, name, value)
            return

        # Everything else goes to _data
        try:
            data = object.__getattribute__(self, "_data")
        except AttributeError:
            object.__setattr__(self, "_data", {})
            data = object.__getattribute__(self, "_data")
        if data is None:
            object.__setattr__(self, "_data", {})
            data = object.__getattribute__(self, "_data")
        data[name] = value
        object.__setattr__(self, "_data_dirty", True)
        self._auto_sync(name)

    def _set_meta_field(self, key: str, value: Any) -> None:
        """Set a meta field, handling special key mappings."""
        if key == "parent_ref" or key == "parent":
            self._meta_data["parent"] = self._serialize_ref(value)
        elif key == "children_refs" or key == "children":
            self._meta_data["children"] = [self._serialize_ref(c) for c in (value or [])]
        elif key == "origin_ref" or key == "origin":
            self._meta_data["origin"] = self._serialize_ref(value)
        elif key == "data_ref":
            self._meta_data["data_ref"] = self._serialize_ref(value)
        elif key == "parent_id":
            self._meta_data["parent"] = {"id": value, "type": ""}
        elif key == "source_file":
            object.__setattr__(self, "_source_file", value)
        elif key == "path":
            object.__setattr__(self, "_path", value)
        elif key == "entity_id":
            self._meta_data["entity_id"] = value
        elif key == "json_path":
            self._meta_data["json_path"] = value
        else:
            self._meta_data[key] = value

    @staticmethod
    def _serialize_ref(value: Any) -> dict | None:
        """Convert a ref value to a dict for storage in _meta_data."""
        if value is None:
            return None
        if isinstance(value, dict):
            return value
        if isinstance(value, RecordRef):
            return value.to_dict()
        # Duck-type: FsRecordRef or similar
        if hasattr(value, "to_dict"):
            return value.to_dict()
        return None

    @staticmethod
    def _deserialize_ref(value: Any) -> RecordRef | None:
        """Convert a stored dict back to a RecordRef."""
        if value is None:
            return None
        if isinstance(value, RecordRef):
            return value
        if isinstance(value, dict):
            return RecordRef.from_dict(value)
        return None

    # -- Identity properties (read/write _meta_data) --

    @property
    def id(self) -> str:
        return self._meta_data.get("id", "")

    @id.setter
    def id(self, value: str) -> None:
        self._meta_data["id"] = value
        self._meta_dirty = True
        self._auto_sync("id")

    @property
    def uid(self) -> str:
        """Return the value of the field designated as the unique id."""
        if self.uid_field_name == "id":
            return self.id
        # Check meta first, then data
        val = self._meta_data.get(self.uid_field_name)
        if val is not None:
            return str(val)
        if self._data is not None:
            val = self._data.get(self.uid_field_name)
            if val is not None:
                return str(val)
        return self.id

    @property
    def type(self) -> str:
        return self._meta_data.get("type", "")

    @type.setter
    def type(self, value: str) -> None:
        self._meta_data["type"] = value
        self._meta_dirty = True
        self._auto_sync("type")

    @property
    def name(self) -> str:
        return self._meta_data.get("name", "")

    @name.setter
    def name(self, value: str) -> None:
        self._meta_data["name"] = value
        self._meta_dirty = True
        self._auto_sync("name")

    @property
    def status(self) -> str | RecordStatus | None:
        return self._meta_data.get("status")

    @status.setter
    def status(self, value: str | RecordStatus | None) -> None:
        old_status = self._meta_data.get("status")
        self._meta_data["status"] = value
        self._meta_dirty = True
        if value != old_status:
            self.on_status_change(old_status, value)
        self._auto_sync("status")

    def on_status_change(self, old_status: Any, new_status: Any) -> None:
        """Called when ``status`` changes. Override in subclasses to react."""

    # -- Audit properties --

    @property
    def created_at(self) -> datetime | None:
        val = self._meta_data.get("created_at")
        if isinstance(val, str):
            return datetime.fromisoformat(val)
        return val

    @created_at.setter
    def created_at(self, value: datetime | None) -> None:
        self._meta_data["created_at"] = value
        self._meta_dirty = True

    @property
    def modified_at(self) -> datetime | None:
        val = self._meta_data.get("modified_at")
        if isinstance(val, str):
            return datetime.fromisoformat(val)
        return val

    @modified_at.setter
    def modified_at(self, value: datetime | None) -> None:
        self._meta_data["modified_at"] = value
        self._meta_dirty = True

    @property
    def created_by(self) -> str | None:
        return self._meta_data.get("created_by")

    @created_by.setter
    def created_by(self, value: str | None) -> None:
        self._meta_data["created_by"] = value
        self._meta_dirty = True

    @property
    def updated_by(self) -> str | None:
        return self._meta_data.get("updated_by")

    @updated_by.setter
    def updated_by(self, value: str | None) -> None:
        self._meta_data["updated_by"] = value
        self._meta_dirty = True

    # -- Scope --

    @property
    def scope(self) -> Scope | str:
        val = self._meta_data.get("scope", Scope.USER)
        if isinstance(val, str):
            try:
                return Scope(val)
            except ValueError:
                return val
        return val

    @scope.setter
    def scope(self, value: Scope | str) -> None:
        self._meta_data["scope"] = value
        self._meta_dirty = True

    # -- Location (not in _meta_data dict, stored as instance attrs) --

    @property
    def source_file(self) -> str | None:
        return self._source_file

    @source_file.setter
    def source_file(self, value: str | None) -> None:
        object.__setattr__(self, "_source_file", value)

    @property
    def path(self) -> str | None:
        return self._path

    @path.setter
    def path(self, value: str | None) -> None:
        object.__setattr__(self, "_path", value)

    @property
    def entity_id(self) -> str | None:
        return self._meta_data.get("entity_id")

    @entity_id.setter
    def entity_id(self, value: str | None) -> None:
        self._meta_data["entity_id"] = value
        self._meta_dirty = True

    # -- JSON path (position within source file, RFC 6901) --

    @property
    def json_path(self) -> str:
        return self._meta_data.get("json_path", "")

    @json_path.setter
    def json_path(self, value: str) -> None:
        self._meta_data["json_path"] = value

    # -- Relationship refs --

    @property
    def parent_ref(self) -> RecordRef | None:
        return self._deserialize_ref(self._meta_data.get("parent"))

    @parent_ref.setter
    def parent_ref(self, value: RecordRef | None) -> None:
        self._meta_data["parent"] = self._serialize_ref(value)
        self._meta_dirty = True

    @property
    def children_refs(self) -> list[RecordRef]:
        raw = self._meta_data.get("children", [])
        return [self._deserialize_ref(c) for c in raw if c is not None]

    @children_refs.setter
    def children_refs(self, value: list[RecordRef]) -> None:
        self._meta_data["children"] = [self._serialize_ref(c) for c in value]
        self._meta_dirty = True

    @property
    def origin_ref(self) -> RecordRef | None:
        return self._deserialize_ref(self._meta_data.get("origin"))

    @origin_ref.setter
    def origin_ref(self, value: RecordRef | None) -> None:
        self._meta_data["origin"] = self._serialize_ref(value)
        self._meta_dirty = True

    @property
    def data_ref(self) -> RecordRef | None:
        return self._deserialize_ref(self._meta_data.get("data_ref"))

    @data_ref.setter
    def data_ref(self, value: RecordRef | None) -> None:
        self._meta_data["data_ref"] = value if isinstance(value, dict) else self._serialize_ref(value)
        self._meta_dirty = True

    # -- Data access --

    @property
    def data(self) -> dict:
        """Access the domain data dict. Returns empty dict if None."""
        if self._data is None:
            return {}
        return self._data

    @data.setter
    def data(self, value: dict | None) -> None:
        object.__setattr__(self, "_data", value)
        self._data_dirty = True

    # -- Raw JSON (backward compat with ResourceRecord.raw_json) --

    @property
    def raw_json(self) -> dict:
        """Backward compat: access _data as raw_json."""
        if self._data is None:
            object.__setattr__(self, "_data", {})
        return self._data

    @raw_json.setter
    def raw_json(self, value: dict) -> None:
        if self._data is None:
            object.__setattr__(self, "_data", value)
        else:
            self._data.update(value)
        self._data_dirty = True

    # -- Naming helpers --

    @property
    def stem(self) -> str:
        """Canonical ``<type>-@<uid>`` stem for this record."""
        return record_stem(self.type, self.uid)

    # -- Filesystem properties --

    @property
    def fs_modified_at(self) -> datetime | None:
        """Return modified_at from the filesystem (mtime of source path)."""
        target = None
        if self.storage_layout == StorageLayout.FOLDER and self.path:
            target = Path(self.path)
        elif self.source_file:
            target = Path(self.source_file)
        if target is not None:
            try:
                mtime = target.stat().st_mtime
                return datetime.fromtimestamp(mtime, tz=timezone.utc)
            except OSError:
                pass
        return self.modified_at

    @property
    def record_dir(self) -> Path | None:
        """The directory containing this record on disk."""
        if self.path:
            return Path(self.path)
        if self.source_file:
            sf = Path(self.source_file)
            if sf.parent.name == _RECORD_DIR:
                return sf.parent.parent
            return sf.parent
        return None

    def read_file(self, filename: str) -> str | None:
        """Read a companion text file from record_dir. Returns None if missing."""
        rd = self.record_dir
        if rd is None:
            return None
        p = rd / filename
        if not p.exists():
            return None
        return p.read_text(encoding="utf-8")

    def write_file(self, filename: str, content: str) -> Path:
        """Write a companion text file to record_dir. Creates dirs if needed."""
        rd = self.record_dir
        if rd is None:
            raise ValueError("No record_dir -- set path or source_file first")
        rd.mkdir(parents=True, exist_ok=True)
        p = rd / filename
        p.write_text(content, encoding="utf-8")
        return p

    @property
    def output_dir(self) -> Path:
        """The output subdirectory for this record. Creates it if needed."""
        d = self.record_dir
        if d is None:
            raise ValueError("No path or source_file set")
        out = d / "output"
        out.mkdir(parents=True, exist_ok=True)
        return out

    @property
    def default_path(self) -> Path | None:
        """The default storage path for this record based on type and id."""
        if not self.type:
            return None
        return get_default_records_root() / self.type / record_stem(self.type, self.uid)

    # -- Key-value access (backward compat with ResourceRecord) --

    def __getitem__(self, key: str) -> Any:
        # Check meta first
        if key in _META_FIELDS:
            return getattr(self, key)
        # Check data
        if self._data is not None and key in self._data:
            return self._data[key]
        raise KeyError(key)

    def __setitem__(self, key: str, value: Any) -> None:
        if key in _META_FIELDS:
            setattr(self, key, value)
        else:
            if self._data is None:
                object.__setattr__(self, "_data", {})
            self._data[key] = value
            self._data_dirty = True
            self._auto_sync(key)

    def __delitem__(self, key: str) -> None:
        if self._data is not None and key in self._data:
            del self._data[key]
            self._data_dirty = True
            return
        raise KeyError(key)

    def __contains__(self, key: str) -> bool:
        if key in _META_FIELDS:
            return True
        if self._data is not None and key in self._data:
            return True
        return False

    def keys(self) -> list[str]:
        """All meta field names + data keys."""
        result = [k for k in self._meta_data.keys() if k not in ("json_path", "entity_id")]
        if self._data:
            result.extend(self._data.keys())
        return result

    # -- Serialization --

    def to_dict(self) -> dict:
        """Serialize to a flat dict (backward compatible with ResourceRecord.to_dict).

        Internal fields (source_file, path, entity_id, json_path, fs_sync,
        storage_layout) are excluded.
        """
        def _convert(obj: Any) -> Any:
            if isinstance(obj, datetime):
                return obj.isoformat()
            if isinstance(obj, Enum):
                return obj.value
            return obj

        result: dict = {}

        # Emit meta fields (skip internal-only ones)
        for key, value in self._meta_data.items():
            if key in _INTERNAL_FIELDS:
                continue
            if key == "parent" and value is not None:
                result["parent"] = value
                continue
            if key == "children" and value:
                result["children"] = value
                continue
            if key == "origin" and value is not None:
                result["origin"] = value
                continue
            if key == "data_ref" and value is not None:
                result["data_ref"] = value
                continue
            result[key] = _convert(value)

        # Emit data fields
        if self._data:
            for key, value in self._data.items():
                result[key] = _convert(value)

        return result

    @classmethod
    def from_dict(cls, data: dict) -> Record:
        """Deserialize from a flat dict, splitting meta vs data."""
        meta: dict[str, Any] = {}
        record_data: dict[str, Any] = {}

        for key, value in data.items():
            if key in ("children", "children_refs"):
                raw = value if isinstance(value, list) else []
                meta["children"] = [
                    c if isinstance(c, dict) else {"id": str(c), "type": ""}
                    for c in raw
                ]
            elif key in ("parent", "parent_ref"):
                if isinstance(value, dict):
                    meta["parent"] = value
            elif key == "parent_id" and value is not None:
                if "parent" not in meta:
                    meta["parent"] = {"id": value, "type": ""}
            elif key in ("origin", "origin_ref"):
                if isinstance(value, dict):
                    meta["origin"] = value
            elif key == "data_ref":
                if isinstance(value, dict):
                    meta["data_ref"] = value
            elif key == "raw_json" and isinstance(value, dict):
                record_data.update(value)
            elif key in _META_FIELDS and key not in ("parent_ref", "children_refs", "origin_ref", "parent_id"):
                meta[key] = value
            elif key in _INTERNAL_FIELDS:
                meta[key] = value
            else:
                record_data[key] = value

        # Coerce scope
        if "scope" in meta and isinstance(meta["scope"], str):
            try:
                meta["scope"] = Scope(meta["scope"])
            except ValueError:
                pass

        # Coerce status
        if "status" in meta and isinstance(meta["status"], str):
            try:
                meta["status"] = RecordStatus(meta["status"])
            except ValueError:
                pass  # keep as raw string (subclasses may use custom status enums)

        # Coerce datetime strings
        for dt_field in ("created_at", "modified_at"):
            val = meta.get(dt_field)
            if isinstance(val, str):
                meta[dt_field] = datetime.fromisoformat(val)

        rec = cls.__new__(cls)
        object.__setattr__(rec, "_meta_data", meta)
        object.__setattr__(rec, "_data", record_data if record_data else None)
        object.__setattr__(rec, "_meta_dirty", False)
        object.__setattr__(rec, "_data_dirty", False)
        object.__setattr__(rec, "_source_file", meta.pop("source_file", None))
        object.__setattr__(rec, "_path", meta.pop("path", None))
        object.__setattr__(rec, "fs_sync", False)
        object.__setattr__(rec, "storage_layout", StorageLayout.FOLDER)

        # Ensure id
        if "id" not in rec._meta_data:
            rec._meta_data["id"] = str(uuid.uuid4())

        # Ensure type from _record_type ClassVar
        if not rec._meta_data.get("type"):
            rt = getattr(cls, "_record_type", "")
            if rt:
                rec._meta_data["type"] = rt

        return rec

    # -- Key management --

    @classmethod
    def _get_record_key(cls, record_data: dict) -> str:
        """Default: fast md5 hash of canonical JSON (first 12 chars).

        Subclasses override for meaningful keys.
        """
        canonical = json.dumps(record_data, sort_keys=True, separators=(",", ":"))
        return hashlib.md5(canonical.encode()).hexdigest()[:12]

    # -- Load / Read --

    @classmethod
    def init_record(
        cls: type[T],
        path_or_data: str | Path | dict[str, Any],
        path: str | Path | None = None,
        indent: int = 2,
    ) -> T:
        """Initialize or load a record.

        Forms:
        - ``init_record(path)`` -> load from path (or create empty if missing)
        - ``init_record(data, path)`` -> create folder-layout record at path
        """
        if isinstance(path_or_data, dict):
            if path is None:
                raise ValueError("path is required when initializing from data")
            p = Path(path)
            if p.name == _RECORD_JSON:
                if p.parent.name == _RECORD_DIR:
                    folder = p.parent.parent
                else:
                    folder = p.parent
            elif p.suffix == ".json":
                folder = p.parent / p.stem
            else:
                folder = p

            record_file = folder / _RECORD_DIR / _RECORD_JSON
            rec = cls.from_dict(path_or_data)
            rec.path = str(folder)
            rec.save_record_json(record_file, indent=indent)
            return rec

        p = Path(path_or_data)
        if p.is_dir():
            p = _resolve_record_json(p)
        rec = cls()
        if p.exists():
            rec.read_record(p)
        rec.source_file = str(p)
        return rec

    @classmethod
    def init(
        cls: type[T],
        data: dict[str, Any],
        path: str | Path,
        indent: int = 2,
    ) -> T:
        """Backward-compatible alias for ``init_record(data, path)``."""
        return cls.init_record(data, path, indent=indent)

    @classmethod
    def load(cls, path: str | Path) -> Record:
        """Polymorphic loader -- reads JSON, checks type, returns correct subclass."""
        from .factory.type_registry import type_registry

        p = Path(path)
        if p.is_dir():
            p = _resolve_record_json(p)
        if not p.exists():
            raise FileNotFoundError(f"Record not found: {p}")
        data = json.loads(p.read_text(encoding="utf-8"))
        record_type = data.get("type", "")
        target_cls = type_registry.get(record_type) or Record
        rec = target_cls.from_dict(data)
        rec.source_file = str(p)
        return rec

    # -- Discovery (overridable by subclasses) --

    @classmethod
    def discover(cls: type[T], scope: Scope | None = None, **kwargs: Any) -> list[T]:
        """Find all records of this type on disk.

        Default implementation: directory-scan of ``records_root / <type> /``.
        Source-file-backed records override this to parse their source file.

        Parameters:
            scope: optional scope filter (not used by default scan)
            **kwargs: passed to subclass overrides
        """
        record_type = getattr(cls, "_record_type", "") or cls().type
        if not record_type:
            return []

        records_root = get_default_records_root()
        type_dir = records_root / record_type
        if not type_dir.is_dir():
            return []

        results: list[T] = []
        for entry in sorted(type_dir.iterdir()):
            if not entry.is_dir() or _NAME_SEP not in entry.name:
                continue
            rj = _resolve_record_json(entry)
            if not rj.exists():
                continue
            try:
                rec = cls.init_record(rj)
                rec.path = str(entry)
                results.append(rec)
            except (json.JSONDecodeError, OSError):
                continue
        return results

    @classmethod
    def discover_one(cls: type[T], uid: str, scope: Scope | None = None, **kwargs: Any) -> T | None:
        """Find a single record by uid.

        Default implementation: O(1) path lookup at the standard location.
        """
        record_type = getattr(cls, "_record_type", "") or cls().type
        if not record_type:
            return None

        records_root = get_default_records_root()
        stem = record_stem(record_type, uid)
        folder = records_root / record_type / stem
        if not folder.is_dir():
            return None

        rj = _resolve_record_json(folder)
        if not rj.exists():
            return None

        try:
            rec = cls.init_record(rj)
            rec.path = str(folder)
            return rec
        except (json.JSONDecodeError, OSError):
            return None

    def persist(self) -> None:
        """Save this record using the strategy appropriate for its type.

        For owned records: delegates to ``save()``.
        Subclasses (source-file records) may override to write back
        to their source file.
        """
        self.save()

    def save_meta_only(self) -> None:
        """Persist only metadata to the meta_path.

        For referenced records this creates the metadata overlay
        (``records/<type>/<type>-@<data_ref.content_hash>/.flow_record/record.json``)
        without touching the external data source.
        """
        mp = self.meta_path
        if mp is None:
            raise ValueError("Cannot determine meta_path — set type and uid or data_ref")
        record_file = mp / _RECORD_DIR / _RECORD_JSON
        self.path = str(mp)
        self.save_record_json(record_file)

    @property
    def has_persisted_meta(self) -> bool:
        """O(1) check: does a metadata directory exist on disk for this record?"""
        mp = self.meta_path
        return mp is not None and mp.is_dir()

    @property
    def meta_path(self) -> Path | None:
        """Compute the metadata storage path.

        Owned records: ``records/<type>/<type>-@<uid>/``
        Referenced records: ``records/<type>/<type>-@<data_ref.content_hash>/``
        """
        if not self.type:
            return None
        dr = self.data_ref
        if dr is not None and (dr.path or dr.json_path):
            stem = record_stem(self.type, dr.content_hash)
        else:
            stem = record_stem(self.type, self.uid)
        return get_default_records_root() / self.type / stem

    def read_record(self, path: Path) -> None:
        """Populate this record's fields from *path*.

        The default implementation reads JSON and calls from_dict.
        Subclasses may override (e.g. to parse YAML or JSONL).

        Raises ``ValueError`` if the file is empty or contains invalid JSON
        (can happen when concurrent writers haven't finished flushing).
        """
        text = path.read_text(encoding="utf-8")
        if not text.strip():
            raise ValueError(f"Empty record file: {path}")
        data = json.loads(text)
        loaded = self.__class__.from_dict(data)
        # Copy internal state from loaded into self
        object.__setattr__(self, "_meta_data", loaded._meta_data)
        object.__setattr__(self, "_data", loaded._data)
        object.__setattr__(self, "_meta_dirty", False)
        object.__setattr__(self, "_data_dirty", False)
        if loaded._source_file:
            object.__setattr__(self, "_source_file", loaded._source_file)
        if loaded._path:
            object.__setattr__(self, "_path", loaded._path)

    # -- Write / Save --

    def write_record(self, path: Path, indent: int = 2) -> None:
        """Write this record to *path*.

        Raises ReadOnlyRecordError if the record type is read-only.
        """
        from .exceptions import ReadOnlyRecordError
        if self._read_only:
            raise ReadOnlyRecordError(
                f"{self.__class__.__name__} is read-only and cannot be written"
            )
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(self.to_dict(), indent=indent, ensure_ascii=False),
            encoding="utf-8",
        )

    def save_record_json(self, path: str | Path | None = None, indent: int = 2) -> None:
        """Write this record to a JSON file."""
        p = Path(path or self.source_file)
        self.write_record(p, indent=indent)
        self.source_file = str(p)

    def save(self) -> None:
        """Save to source_file, auto-assigning a default path if needed."""
        if not self.source_file:
            dp = self.default_path
            if dp is not None:
                record_file = dp / _RECORD_DIR / _RECORD_JSON
                self.path = str(dp)
                self.save_record_json(record_file)
                return
            raise ValueError("source_file not set; use save_record_json(path) first")
        self.save_record_json()

    # -- Auto-sync (fs_sync behavior from FsRecord) --

    def _auto_sync(self, field_name: str) -> None:
        """If fs_sync is enabled and source_file is set, auto-save."""
        if (
            field_name not in _FS_SYNC_SKIP
            and not field_name.startswith("_")
            and getattr(self, "fs_sync", False)
            and self.source_file
        ):
            self.save()

    # -- Origin / Meta --

    @property
    def meta(self) -> Record | None:
        """Load the writable meta record for this (typically read-only) origin."""
        dp = self.default_path
        if dp is None:
            return None
        rj = _resolve_record_json(dp)
        if not rj.exists():
            return None
        return Record.init_record(rj)

    def get_or_create_meta(self) -> Record:
        """Return the existing meta record or prepare a new one in memory."""
        existing = self.meta
        if existing is not None:
            return existing
        dp = self.default_path
        if dp is None:
            raise ValueError("Cannot create meta for a record without a type")
        meta = Record(id=self.uid, type=self.type, name=self.name)
        meta.origin_ref = RecordRef.from_record(self)
        record_file = dp / _RECORD_DIR / _RECORD_JSON
        meta.path = str(dp)
        meta.source_file = str(record_file)
        return meta

    # -- Live relationship properties --

    @property
    def parent(self) -> Record | None:
        """Load the parent record from disk via parent_ref.path."""
        if self.parent_ref is None or not self.parent_ref.path:
            return None
        p = Path(self.parent_ref.path)
        if not p.exists():
            return None
        return Record.init_record(p)

    @property
    def children(self) -> list[Record]:
        """Load child records from disk via each ref's path."""
        result: list[Record] = []
        for ref in self.children_refs:
            if not ref.path:
                continue
            p = Path(ref.path)
            if not p.exists():
                continue
            result.append(Record.init_record(p))
        return result

    def get_children_by_type(self, type: str) -> list[Record]:
        """Load child records filtered by type."""
        from .factory.type_registry import type_registry

        result: list[Record] = []
        for ref in self.children_refs:
            if not ref.path:
                continue
            p = Path(ref.path)
            if not p.exists():
                continue
            target_cls = type_registry.get(type) or Record
            child = target_cls.init_record(p)
            if child.type == type:
                result.append(child)
        return result

    def add_child(self, child: Record | RecordRef) -> RecordRef:
        """Append a child ref without creating/modifying child files."""
        ref = child if isinstance(child, RecordRef) else RecordRef.from_record(child)
        existing = self._meta_data.get("children", [])
        if not any(
            (isinstance(e, dict) and e.get("id") == ref.id and e.get("type") == ref.type)
            for e in existing
        ):
            existing.append(ref.to_dict())
            self._meta_data["children"] = existing
            self._meta_dirty = True
            if self.source_file:
                self.save()
        return ref

    # -- Clone / Move / Delete --

    def clone(self, new_path: str | Path) -> Record:
        """Create a copy with a new id at new_path."""
        from .exceptions import ReadOnlyRecordError

        if self._read_only:
            raise ReadOnlyRecordError(
                f"{self.__class__.__name__} is read-only and cannot be cloned"
            )
        cloned = copy.deepcopy(self)
        cloned._meta_data["id"] = str(uuid.uuid4())
        cloned.origin_ref = RecordRef.from_record(self)
        p = Path(new_path)
        if p.is_dir() or not p.suffix:
            record_file = p / _RECORD_DIR / _RECORD_JSON
        else:
            record_file = p
        cloned.path = str(p) if (p.is_dir() or not p.suffix) else None
        cloned.save_record_json(record_file)
        return cloned

    def move(self, new_path: str | Path) -> None:
        """Relocate this record to new_path."""
        from .exceptions import ReadOnlyRecordError

        if self._read_only:
            raise ReadOnlyRecordError(
                f"{self.__class__.__name__} is read-only and cannot be moved"
            )
        old_record_dir = self.record_dir
        p = Path(new_path)
        if p.is_dir() or not p.suffix:
            record_file = p / _RECORD_DIR / _RECORD_JSON
        else:
            record_file = p
        if p.is_dir() or not p.suffix:
            self.path = str(p)
        self.save_record_json(record_file)
        if old_record_dir and old_record_dir.exists() and old_record_dir != p:
            shutil.rmtree(old_record_dir, ignore_errors=True)

    def delete(self) -> None:
        """Remove this record from disk."""
        rd = self.record_dir
        if rd and rd.exists():
            if self.storage_layout == StorageLayout.FOLDER:
                shutil.rmtree(rd, ignore_errors=True)
            elif self.source_file:
                Path(self.source_file).unlink(missing_ok=True)
        elif self.source_file:
            Path(self.source_file).unlink(missing_ok=True)
        self.source_file = None
        self.path = None

    def open(self) -> None:
        """Open this record's folder in the native OS file explorer."""
        folder = self.record_dir
        if folder is None:
            raise ValueError("No path or source_file set")
        system = platform.system()
        if system == "Darwin":
            subprocess.Popen(["open", str(folder)])
        elif system == "Windows":
            subprocess.Popen(["explorer", str(folder)])
        else:
            subprocess.Popen(["xdg-open", str(folder)])

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(id={self.id!r}, type={self.type!r}, name={self.name!r})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Record):
            return NotImplemented
        return self.id == other.id and self.type == other.type

    def __hash__(self) -> int:
        return hash((self.id, self.type))
