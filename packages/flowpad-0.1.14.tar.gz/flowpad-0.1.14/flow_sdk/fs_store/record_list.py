"""Unified RecordList — single collection class for all record types.

Delegates discovery to ``record_class.discover()`` and persistence
to ``record.persist()``, so the collection layer is storage-agnostic.

Replaces the need for callers to choose between ``ResourceRecordList``
(individual files) and ``SourceFileRecordList`` (embedded JSON).
"""

from __future__ import annotations

from typing import Any, Iterator

from .record import Record
from .record_query import RecordQuery
from .scope import Scope


class RecordList:
    """Storage-agnostic typed record collection.

    Read operations delegate to ``record_class.discover()`` /
    ``record_class.discover_one()``.
    Write operations delegate to ``record.persist()`` / ``record.save()``
    / ``record.delete()``.

    Parameters:
        record_class: the Record subclass this list manages.
        scope: optional scope passed through to discover().
        **kwargs: forwarded to discover() calls.
    """

    def __init__(
        self,
        record_class: type[Record],
        scope: Scope | None = None,
        **kwargs: Any,
    ) -> None:
        self.record_class = record_class
        self.scope = scope
        self._kwargs = kwargs

    # -- Read --

    def get(self, uid: str) -> Record | None:
        """Fetch a single record by uid."""
        return self.record_class.discover_one(uid, scope=self.scope, **self._kwargs)

    def __iter__(self) -> Iterator[Record]:
        return iter(self.record_class.discover(scope=self.scope, **self._kwargs))

    def __len__(self) -> int:
        return len(self.record_class.discover(scope=self.scope, **self._kwargs))

    @property
    def records(self) -> list[Record]:
        """Return all records as a list."""
        return list(self)

    # -- Write --

    def create(self, record: Record | dict) -> Record:
        """Persist a new record. Raises ValueError if uid already exists."""
        if isinstance(record, dict):
            record = self.record_class.from_dict(record)
        # Check for duplicate
        existing = self.get(record.uid)
        if existing is not None:
            raise ValueError(f"Record with uid {record.uid!r} already exists")
        record.persist()
        return record

    def save(self, record: Record) -> None:
        """Persist a record (create or overwrite)."""
        record.persist()

    def update(self, uid: str, data: dict[str, Any]) -> Record:
        """Fetch, patch fields, and persist. Raises KeyError if missing."""
        record = self.get(uid)
        if record is None:
            raise KeyError(f"No record with uid {uid!r}")
        for key, value in data.items():
            setattr(record, key, value)
        record.persist()
        return record

    def delete(self, uid: str) -> bool:
        """Remove a record. Returns True if it existed."""
        record = self.get(uid)
        if record is None:
            return False
        record.delete()
        return True

    # -- Query --

    def query(self, q: RecordQuery) -> list[Record]:
        """Apply a RecordQuery to all discovered records."""
        return q.apply(self)
