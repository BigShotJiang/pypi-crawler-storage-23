"""Type registry -- maps record type strings to their Python classes.

Explicit registration of the known record types.
Use ``type_registry.get(RecordType.SKILL)`` to look up a class.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..record import Record


class TypeRegistry:
    """Maps type name strings to Record subclasses."""

    def __init__(self):
        self._types: dict[str, type[Record]] = {}

    def register(self, type_name: str, cls: type[Record]) -> None:
        """Register a record class under a type name."""
        if type_name:
            self._types[type_name] = cls

    def get(self, type_name: str) -> type[Record] | None:
        """Look up a record class by type name, or None if unknown."""
        return self._types.get(type_name)

    def get_all_types(self) -> list[str]:
        """Return all registered type name strings."""
        return list(self._types.keys())

    def __contains__(self, type_name: str) -> bool:
        return type_name in self._types

    def __len__(self) -> int:
        return len(self._types)


type_registry = TypeRegistry()
