"""Unified record reference — replaces FsRecordRef with extended fields.

A RecordRef is a lightweight pointer to another record. It can point to:
- A parent/child record (id + type + path)
- An external data source (path + json_path + format)
- An origin record for clone provenance
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass


@dataclass
class RecordRef:
    """Flat reference to a record or external data source.

    Covers all current uses: parent/child refs, origin tracking,
    AND data pointers. Serializes to dict omitting None fields.

    The ``content_hash`` property computes a deterministic hash of the
    addressing fields (path, json_path, key_field, key_value) — useful
    as a content-addressable id for data_ref pointers.
    """

    id: str = ""
    type: str = ""
    path: str | None = None          # filesystem path (to record or data file)
    json_path: str | None = None     # RFC 6901 pointer (may include array index)
    key_field: str | None = None     # field name for identifying objects in arrays
    key_value: str | None = None     # field value to match
    format: str | None = None        # "json" | "jsonl" | "yaml" | None (infer)

    @property
    def content_hash(self) -> str:
        """Deterministic hash of addressing fields. O(1).

        Stable across runs — same source produces the same hash.
        Useful for building metadata paths for referenced records.
        """
        key = f"{self.path or ''}|{self.json_path or ''}|{self.key_field or ''}|{self.key_value or ''}"
        return hashlib.md5(key.encode()).hexdigest()[:12]

    def to_dict(self) -> dict:
        """Serialize to a plain dict, omitting fields that are None or empty."""
        d: dict = {}
        if self.id:
            d["id"] = self.id
        if self.type:
            d["type"] = self.type
        if self.path is not None:
            d["path"] = self.path
        if self.json_path is not None:
            d["json_path"] = self.json_path
        if self.key_field is not None:
            d["key_field"] = self.key_field
        if self.key_value is not None:
            d["key_value"] = self.key_value
        if self.format is not None:
            d["format"] = self.format
        return d

    @classmethod
    def from_dict(cls, data: dict) -> RecordRef:
        """Deserialize from a dict. Extra keys are silently ignored."""
        # Support legacy FsRecordRef format (record_path -> path)
        path = data.get("path") or data.get("record_path")
        return cls(
            id=data.get("id", ""),
            type=data.get("type", ""),
            path=path,
            json_path=data.get("json_path"),
            key_field=data.get("key_field"),
            key_value=data.get("key_value"),
            format=data.get("format"),
        )

    @classmethod
    def from_record(cls, record: object) -> RecordRef:
        """Build a ref from any record with uid/type attrs (duck-typed)."""
        return cls(
            id=record.uid,      # type: ignore[attr-defined]
            type=record.type,   # type: ignore[attr-defined]
            path=getattr(record, "source_file", None),
        )

    # Backward compatibility with FsRecordRef.record_path
    @property
    def record_path(self) -> str | None:
        """Alias for ``path`` — backward compat with FsRecordRef."""
        return self.path

    @record_path.setter
    def record_path(self, value: str | None) -> None:
        self.path = value
