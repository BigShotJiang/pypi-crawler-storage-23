"""MCP server endpoint stub for flow-cli.

Ported from FlowPad: flowpad/hub/app/actions/knowledge/mcp_actions.py
Desktop stub: registers the action path for API compatibility but returns
a simple response since FastMCP and knowledge engine are not available.

Routes:
  GET/POST /api/v1/graph/agent/{id}/mcp
  GET      /api/v1/graph/agent/{id}/mcp/health
"""

import logging

from flow_sdk.core import action
from flow_sdk.request_context.methods import get_current_request_info
from flow_sdk.responses.response import ApiFailResponse, ApiSuccessResponse

logger = logging.getLogger(__name__)


@action.all(action_name="mcp", types=["agent"], methods=["get", "post"])
async def mcp_endpoint():
    """MCP server endpoint stub.

    Production uses FastMCP with Streamable-HTTP transport to expose
    an 'instruct' tool for querying entity-specific instructions.

    Desktop stub returns health check or not-available response.
    """
    request_info = get_current_request_info()
    if not request_info:
        return ApiFailResponse(message="No request context available")

    # Health check endpoint
    if request_info.sub_path and "health" in request_info.sub_path:
        return ApiSuccessResponse(data="mcp available")

    # MCP protocol not available in desktop mode
    return ApiFailResponse(
        message="MCP server not available in desktop mode. "
        "FastMCP and knowledge engine are production-only features."
    )
