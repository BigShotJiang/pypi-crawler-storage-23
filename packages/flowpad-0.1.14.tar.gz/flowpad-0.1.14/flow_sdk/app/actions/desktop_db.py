"""Desktop DB management action.

Provides SQLite database management operations: paths, clear, backup, open folders.
Simplified from production FlowPad: flowpad/hub/app/actions/desktop_db.py
"""

import logging
import os
import platform
import shutil
import subprocess
from datetime import datetime
from enum import StrEnum
from pathlib import Path

from pydantic import BaseModel

from flow_sdk.core import action
from flow_sdk.request_context.methods import get_current_request_info
from flow_sdk.responses.response import ApiFailResponse, ApiResponse, ApiSuccessResponse

logger = logging.getLogger(__name__)


class FolderType(StrEnum):
    BACKUP = "backup"
    DB = "db"
    LOGS = "logs"


class DesktopDbSubpath(StrEnum):
    PATHS = "paths"
    STATS = "stats"
    CLEAR = "clear"
    BACKUP = "backup"
    OPEN_BACKUP = "open-backup"
    OPEN_DB = "open-db"
    OPEN_LOGS = "open-logs"


class DatabasePathsResponse(BaseModel):
    db_path: str
    backup_folder: str
    db_folder: str
    logs_folder: str


class EntityTypeCount(BaseModel):
    type: str
    count: int


class DatabaseStatsResponse(BaseModel):
    file_size_bytes: int
    total_entities: int
    total_relationships: int
    entity_types: list[EntityTypeCount]


class ClearDbResponse(BaseModel):
    backup_path: str
    message: str


def _get_db_path() -> Path:
    """Get the SQLite database file path."""
    db_path_str = os.environ.get("SQLITE_DATABASE_PATH")
    if not db_path_str:
        db_folder = Path.home() / ".flow" / "db"
        db_folder.mkdir(parents=True, exist_ok=True)
        db_path_str = str(db_folder / "flowpad_db")
    return Path(db_path_str)


def _get_backup_folder() -> Path:
    """Get the backup folder path."""
    home = Path.home()
    backup_folder = home / ".flowpad" / "backups"
    backup_folder.mkdir(parents=True, exist_ok=True)
    return backup_folder


def _get_db_folder() -> Path:
    """Get the database folder path."""
    db_path = _get_db_path()
    return db_path.parent


def _get_logs_folder() -> Path:
    """Get the logs folder path."""
    home = Path.home()
    logs_folder = home / "Flowpad workspace" / ".flow" / "logs"
    logs_folder.mkdir(parents=True, exist_ok=True)
    return logs_folder


def _open_folder(folder_path: Path) -> None:
    """Open a folder in the OS file manager."""
    folder_str = str(folder_path.resolve())
    system = platform.system()

    try:
        if system == "Windows":
            subprocess.run(["explorer", folder_str], check=False, timeout=5)
        elif system == "Darwin":
            subprocess.run(["open", folder_str], check=True, timeout=5)
        else:  # Linux and other Unix-like systems
            subprocess.run(["xdg-open", folder_str], check=True, timeout=5)
    except subprocess.TimeoutExpired:
        logger.warning(f"Timeout opening folder: {folder_str}")
        raise
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to open folder: {folder_str}, error: {e}")
        raise
    except FileNotFoundError:
        logger.error(f"Command not found to open folder on OS: {system}")
        raise


async def _handle_get_paths() -> ApiResponse:
    try:
        db_path = _get_db_path()
        backup_folder = _get_backup_folder()
        db_folder = _get_db_folder()
        logs_folder = _get_logs_folder()

        return ApiSuccessResponse(
            data=DatabasePathsResponse(
                db_path=str(db_path),
                backup_folder=str(backup_folder),
                db_folder=str(db_folder),
                logs_folder=str(logs_folder),
            )
        )
    except Exception as e:
        logger.error(f"Error getting database paths: {e}")
        return ApiFailResponse(message=f"Failed to get database paths: {str(e)}")


async def _handle_get_stats() -> ApiResponse:
    try:
        import sqlite3 as stdlib_sqlite3

        db_path = _get_db_path()
        if not db_path.exists():
            return ApiFailResponse(message="Database file does not exist")

        file_size = db_path.stat().st_size

        conn = stdlib_sqlite3.connect(str(db_path))
        try:
            cur = conn.cursor()

            cur.execute("SELECT COUNT(*) FROM entities")
            total_entities = cur.fetchone()[0]

            cur.execute("SELECT COUNT(*) FROM relationships")
            total_relationships = cur.fetchone()[0]

            cur.execute(
                "SELECT type, COUNT(*) as cnt FROM entities GROUP BY type ORDER BY cnt DESC"
            )
            entity_types = [EntityTypeCount(type=row[0], count=row[1]) for row in cur.fetchall()]
        finally:
            conn.close()

        return ApiSuccessResponse(
            data=DatabaseStatsResponse(
                file_size_bytes=file_size,
                total_entities=total_entities,
                total_relationships=total_relationships,
                entity_types=entity_types,
            )
        )
    except Exception as e:
        logger.error(f"Error getting database stats: {e}")
        return ApiFailResponse(message=f"Failed to get database stats: {str(e)}")


async def _handle_backup_db() -> ApiResponse:
    try:
        db_path = _get_db_path()
        backup_folder = _get_backup_folder()

        if not db_path.exists():
            return ApiFailResponse(message="Database file does not exist")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"flowpad_db_{timestamp}"
        backup_path = backup_folder / backup_filename

        shutil.copy2(db_path, backup_path)
        logger.info(f"Database backed up to: {backup_path}")

        return ApiSuccessResponse(
            data=ClearDbResponse(
                backup_path=str(backup_path),
                message="Database backed up successfully",
            )
        )
    except Exception as e:
        logger.error(f"Error backing up database: {e}")
        return ApiFailResponse(message=f"Failed to backup database: {str(e)}")


async def _handle_clear_db() -> ApiResponse:
    try:
        db_path = _get_db_path()
        backup_folder = _get_backup_folder()

        if not db_path.exists():
            return ApiFailResponse(message="Database file does not exist")

        # Backup before clearing
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"flowpad_db_{timestamp}"
        backup_path = backup_folder / backup_filename

        shutil.copy2(db_path, backup_path)
        logger.info(f"Database backed up to: {backup_path}")

        # Close existing connection, delete the file, then reinitialize
        from flow_sdk.core.cache.entity_cache import entity_cache, uname_cache
        from flow_sdk.db.database import close_db, init_db

        await close_db()
        db_path.unlink()
        logger.info(f"Database file deleted: {db_path}")

        # Clear in-memory caches so stale UUIDs don't poison lookups
        entity_cache.clear()
        uname_cache.clear()

        await init_db()

        return ApiSuccessResponse(
            data=ClearDbResponse(
                backup_path=str(backup_path),
                message="All data has been cleared from the database. A backup was created.",
            )
        )
    except Exception as e:
        logger.error(f"Error clearing database: {e}")
        return ApiFailResponse(message=f"Failed to clear database: {str(e)}")


async def _handle_open_folder(folder_type: FolderType) -> ApiResponse:
    try:
        if folder_type == FolderType.BACKUP:
            folder_path = _get_backup_folder()
        elif folder_type == FolderType.DB:
            folder_path = _get_db_folder()
        elif folder_type == FolderType.LOGS:
            folder_path = _get_logs_folder()
        else:
            return ApiFailResponse(message=f"Invalid folder type: {folder_type}")

        _open_folder(folder_path)
        return ApiSuccessResponse(data={"message": f"Opened {folder_type.value} folder"})
    except Exception as e:
        logger.error(f"Error opening folder: {e}")
        return ApiFailResponse(message=f"Failed to open folder: {str(e)}")


@action.all(action_name="desktop-db", methods=["get", "post"], types="all")
async def desktop_db_action() -> ApiResponse:
    """Desktop DB management action.

    GET /desktop-db/paths - Get database paths
    GET /desktop-db/stats - Get database stats (size, row counts, entity types)
    POST /desktop-db/clear - Clear database (with backup)
    POST /desktop-db/backup - Backup database
    POST /desktop-db/open-backup - Open backup folder
    POST /desktop-db/open-db - Open database folder
    POST /desktop-db/open-logs - Open logs folder
    """
    request_info = get_current_request_info()
    if not request_info or not request_info.request:
        return ApiFailResponse(message="No request info available")

    method = request_info.request.method.upper()
    sub_path = request_info.sub_path or ""

    if method == "GET":
        if sub_path == DesktopDbSubpath.PATHS.value or not sub_path:
            return await _handle_get_paths()
        elif sub_path == DesktopDbSubpath.STATS.value:
            return await _handle_get_stats()
        else:
            return ApiFailResponse(message=f"Unknown GET subpath: {sub_path}")

    elif method == "POST":
        if sub_path == DesktopDbSubpath.CLEAR.value:
            return await _handle_clear_db()
        elif sub_path == DesktopDbSubpath.BACKUP.value:
            return await _handle_backup_db()
        elif sub_path == DesktopDbSubpath.OPEN_BACKUP.value:
            return await _handle_open_folder(FolderType.BACKUP)
        elif sub_path == DesktopDbSubpath.OPEN_DB.value:
            return await _handle_open_folder(FolderType.DB)
        elif sub_path == DesktopDbSubpath.OPEN_LOGS.value:
            return await _handle_open_folder(FolderType.LOGS)
        else:
            return ApiFailResponse(message=f"Unknown POST subpath: {sub_path}")

    else:
        return ApiFailResponse(message=f"Method {method} not supported")
