"""Validation utilities and patterns."""

# UUID v4 pattern for validation (as string for use in regex composition)
UUID_PATTERN = r'[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}'
