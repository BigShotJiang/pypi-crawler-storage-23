import uuid
from enum import Enum, StrEnum
from typing import Any, ClassVar, Optional

from pydantic import BaseModel, ConfigDict, Field

from flow_sdk.api.api_request import APIRequest
from flow_sdk.api.type_id import TypeId
from flow_sdk.request_context.auth_info import AuthContext


class WSMessageType(Enum):
    ECHO = "echo"
    BROADCAST = "broadcast"
    PING = "ping"
    PONG = "pong"
    HANGUP = "hangup"
    ENTITY_MSG = "entity_msg"
    DATA_OP_MSG = "data_op_msg"
    REST_API_MSG = "rest_api_msg"
    STREAM_MSG = "stream_msg"
    TRANSCRIPT = "transcript_msg"
    EXE_MSG = "exe_msg"
    CONTROL_MSG = "control_msg"
    OAUTH_MSG = "oauth_msg"
    RESPONSE_MSG = "response_msg"
    CMD_STATUS_MSG = "cmd_status_msg"
    CLIENT_NODE_READY_MSG = "client_node_ready_msg"
    PTY_OUTPUT_MSG = "pty_output_msg"
    PTY_SESSION_STATUS_MSG = "pty_session_status_msg"
    LLM_CONFIG_MSG = "llm_config_msg"
    FLOW_DATA_MSG = "flow_data_msg"


class ExeMessageSubType(StrEnum):
    CONTROL = "control"
    EXECUTION = "execution"


class CtlMessageSubType(StrEnum):
    READY = "ready"
    START_SESSION = "session_start"


class BaseMessage(BaseModel):
    message_type: str
    message_id: str = Field(default_factory=lambda: BaseMessage._gen_id())
    # This field will automatically get an incremented value
    instance_id: int = Field(default_factory=lambda: BaseMessage._increment_counter())

    # This is a class variable acting as a static counter
    _counter: ClassVar[int] = 0

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @classmethod
    def _gen_id(cls) -> str:
        """
        Generate a unique ID for the message based on its type and instance ID.
        This is used to ensure that each message has a unique identifier.
        """
        return uuid.uuid4().hex

    def __init__(self, **data):
        super().__init__(**data)

    @classmethod
    def _increment_counter(cls) -> int:
        cls._counter += 1
        return cls._counter


class EchoMessage(BaseMessage):
    message_type: str = WSMessageType.ECHO.value
    text: str


class PingMessage(BaseMessage):
    message_type: str = WSMessageType.PING.value
    text: str


class PongMessage(BaseMessage):
    message_type: str = WSMessageType.PONG.value
    text: str


class HangupMessage(BaseMessage):
    message_type: str = WSMessageType.HANGUP.value
    text: str


class StreamMessage(BaseMessage):
    message_type: str = WSMessageType.STREAM_MSG.value
    stream_id: int


class TranscriptMessage(StreamMessage):
    message_type: str = WSMessageType.TRANSCRIPT.value
    text: str


class OAuthMessageStatus(Enum):
    SUCCESS = "success"
    ERROR = "error"


class OAuthMessage(BaseMessage):
    message_type: str = WSMessageType.OAUTH_MSG.value
    oauth_request_id: str
    status: OAuthMessageStatus


class EntityMessage(BaseMessage):
    message_type: str = WSMessageType.ENTITY_MSG.value
    from_entity: Optional[TypeId] = None
    to_entity: TypeId


class OperationType(Enum):
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"


class HttpMethod(Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"


class DataOpMessage(EntityMessage):
    model_config = ConfigDict(use_enum_values=True)
    message_type: str = WSMessageType.DATA_OP_MSG.value
    op: OperationType
    data: Any = None  # AppLayerMessage

    def handle(self):
        raise NotImplementedError("This method must be implemented in a subclass")


class APIMessage(BaseMessage, APIRequest):
    message_type: str = WSMessageType.REST_API_MSG.value

    @property
    def auth_info(self) -> AuthContext:
        auth_context = AuthContext()
        auth_context.scope = self.scope
        auth_context.method = self.method
        auth_context.target_type = self.target_typeid.type if self.target_typeid else None
        auth_context.target_id = self.target_typeid.id if self.target_typeid else None
        auth_context.direct_resource_type = self.direct_resource_type
        auth_context.action = self.action
        auth_context.sub_path = self.sub_path
        auth_context.query_params = self.query_params
        auth_context.body = self.body
        return auth_context


class ComputeMessage(BaseMessage):
    session_id: Optional[str] = None
    ack_required: bool = False


class ComputeExeMessage(ComputeMessage):
    message_type: str = WSMessageType.EXE_MSG.value
    session_id: Optional[str] = None
    cmd: str


class ComputeCtrlMessage(ComputeMessage):
    message_type: str = WSMessageType.CONTROL_MSG.value
    subtype: CtlMessageSubType
    content: str


class CommandStatusMessage(ComputeMessage):
    """
    Represents a message that contains the status of a command execution.
    This can be used to report the status of a command execution back to the client.
    """

    message_type: str = WSMessageType.CMD_STATUS_MSG.value
    command_message_id: str
    exit_code: Optional[int] = None
    stdout: Optional[str] = None
    stderr: Optional[str] = None


class ClientReadyMessage(ComputeMessage):
    message_type: str = WSMessageType.CLIENT_NODE_READY_MSG.value
    node_id: str
    default_session_id: Optional[str] = None


class PtyOutputMessage(BaseMessage):
    """Message for streaming PTY output to frontend."""

    message_type: str = WSMessageType.PTY_OUTPUT_MSG.value
    provider_node_id: Optional[str] = None
    session_id: Optional[str] = None
    data: Optional[str] = None  # base64-encoded bytes
    seq: int = 0  # Monotonic sequence number (0 for backward compatibility)

    @classmethod
    def from_bytes(cls, provider_node_id: str, session_id: str, data: bytes, seq: int = 0):
        """Create message from raw PTY output bytes."""
        import base64

        return cls(
            provider_node_id=provider_node_id,
            session_id=session_id,
            data=base64.b64encode(data).decode("utf-8"),
            seq=seq,
        )


class PtySessionStatusMessage(BaseMessage):
    """Message for PTY session status (reattach, not_found, etc.)."""

    message_type: str = WSMessageType.PTY_SESSION_STATUS_MSG.value
    session_id: str
    status: str  # "connected", "reattached", "not_found", "expired"
    replay_truncated: bool = False
    latest_seq: Optional[int] = None


class LlmConfigMessage(BaseMessage):
    """LLM configuration change notification sent to user via WebSocket.

    Broadcast when:
    - User adds/removes API key
    - OAuth token is added/removed/refreshed
    - Credentials change

    This message includes OAuth request fields for tracking which OAuth request completed.
    """

    message_type: str = WSMessageType.LLM_CONFIG_MSG.value
    is_configured: bool  # True if any auth method is available
    auth_method: str  # "oauth", "api_key", or "none"
    auth_data: Optional[dict] = None  # Full ClaudeCodeAuthStatus as dict
    # OAuth request fields (for tracking which OAuth request completed)
    oauth_request_id: Optional[str] = None
    status: Optional[OAuthMessageStatus] = None


class ResponseMessage(ComputeMessage):
    message_type: str = WSMessageType.RESPONSE_MSG.value
    response_message_id: str
    content: Optional[str | dict | PtyOutputMessage | PtySessionStatusMessage] = None
    error: Optional[str] = None
