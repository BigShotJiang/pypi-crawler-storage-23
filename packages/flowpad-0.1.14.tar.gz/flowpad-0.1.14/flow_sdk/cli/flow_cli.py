#!/usr/bin/env python3

import os
import threading
from typing import Optional

import requests
import typer
from typing_extensions import Annotated

from flow_sdk._version import __version__
from flow_sdk.cli.auth import delete_api_key, is_logged_in, set_api_key
from flow_sdk.cli.cli_command import CLICommand
from flow_sdk.cli.cli_context import ClaudeScope, CLIContext
from flow_sdk.cli.commands.prompt_cmd import run_prompt_command
from flow_sdk.cli.commands.setup_cmd.setup_cmd import run_setup
from flow_sdk.cli.config_manager import (
    list_config,
    remove_config_value,
    set_config_value,
    setup_defaults,
)
from flow_sdk.cli.env_loader import cli_init

# Initialize CLI - load environment variables as first step
cli_init()

# Create Typer app
app = typer.Typer(name="flow", help="Flow CLI tool for flowpad", add_completion=False)

# Global context (initialized once)
_context: Optional[CLIContext] = None


def get_context() -> CLIContext:
    """Get or initialize the CLI context."""
    global _context
    if _context is None:
        _context = CLIContext()
    return _context


def _discover_port() -> int:
    """Discover the running server port via ~/.flow/server.json, env, or default."""
    from flow_sdk.discovery.flowpad_discovery import read_server_info

    server_info = read_server_info()
    if server_info:
        return server_info.port
    return int(os.environ.get("LOCAL_SERVER_PORT", "9007"))


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context):
    """
    Flow CLI - Main entry point.

    If no command is provided, prints version.
    """
    # Ensure config defaults are set
    setup_defaults()

    # If no subcommand was invoked, show version
    if ctx.invoked_subcommand is None:
        typer.echo(f"flow {__version__}")


@app.command()
def setup(
    agent_name: Annotated[str, typer.Argument(help="Name of the coding agent (e.g., claude-code)")],
):
    """
    Setup flowpad for a specific coding agent.

    Example: flow setup claude-code
    """
    context = get_context()
    cmd = CLICommand(f"setup {agent_name}", context=context)

    # Set first_time_prompt flag when running setup
    set_config_value("first_time_prompt", "true")

    run_setup(agent_name, cmd)


@app.command()
def prompt(prompt_text: Annotated[Optional[str], typer.Argument(help="Prompt text to process")] = None):
    """
    Process a prompt command.

    Example: flow prompt "analyze this code"
    """
    if prompt_text:
        context = get_context()
        cmd = CLICommand(f"prompt {prompt_text}", context=context)
        run_prompt_command(prompt_text, cmd)


@app.command()
def ping(
    ping_str: Annotated[str, typer.Argument(help="Ping string to send")],
):
    """
    Send a ping to the local server for testing hook integration.

    Example: flow ping hello
    """
    get_context()

    port = _discover_port()

    # Send ping to local server
    try:
        url = f"http://127.0.0.1:{port}/ping"
        response = requests.get(url, params={"ping_str": ping_str}, timeout=5)

        if response.status_code == 200:
            typer.echo(f"Ping sent successfully: {ping_str}")
        else:
            typer.echo(f"Ping failed with status {response.status_code}", err=True)
            raise typer.Exit(1)
    except requests.exceptions.RequestException as e:
        typer.echo(f"Error sending ping: {e}", err=True)
        raise typer.Exit(1)


@app.command()
def start():
    """
    Start the Flow server in background with health monitoring.

    Launches a background monitor that keeps the server alive and
    restarts it if it crashes.  The CLI exits immediately.

    Example: flow start
    """
    import webbrowser

    from server.launch import check_server_health, start_monitor_detached, wait_for_server_health

    port = int(os.environ.get("LOCAL_SERVER_PORT", "9007"))

    if check_server_health(port):
        typer.echo(f"Server already running on port {port}")
    else:
        typer.echo(f"Starting Flow server on http://127.0.0.1:{port}")
        start_monitor_detached(port)
        if wait_for_server_health(port, timeout=10.0):
            typer.echo("Server is ready")
        else:
            typer.echo("Server may still be starting...")

    webbrowser.open(f"http://127.0.0.1:{port}")


@app.command()
def stop():
    """
    Stop the Flow server and monitor.

    Example: flow stop
    """
    from server.launch import stop_all

    monitor_killed, server_killed = stop_all()
    if monitor_killed:
        typer.echo("Monitor stopped")
    if server_killed:
        typer.echo("Server stopped")
    if not (monitor_killed or server_killed):
        typer.echo("Nothing was running")


@app.command()
def status():
    """
    Show server and monitor status.

    Example: flow status
    """
    from server.launch import get_status

    s = get_status()
    port = s["port"]

    typer.echo(f"Port: {port}")

    if s["monitor_alive"]:
        typer.echo(f"Monitor: running (PID {s['monitor_pid']})")
    else:
        typer.echo("Monitor: not running")

    if s["server_healthy"]:
        typer.echo(f"Server:  healthy (PID {s['server_pid']})")
    elif s["server_alive"]:
        typer.echo(f"Server:  alive but unhealthy (PID {s['server_pid']})")
    else:
        typer.echo("Server:  not running")

    if s["launch_iso_time"]:
        typer.echo(f"Started: {s['launch_iso_time']}")


@app.command()
def trace():
    """
    Start the server and trace hook events in real-time.

    Displays hook events with colored output as they occur.
    Use Ctrl+C to stop.

    Usage:
      Terminal 1: flow trace
      Terminal 2: flow hooks set && claude -p "hello" && flow hooks clear
    """
    import time

    from server.app import start_server
    from server.reporters import PrintReporter
    from server.state import reporter_registry

    port = int(os.environ.get("LOCAL_SERVER_PORT", "9007"))

    typer.echo(f"Starting Flow trace server on port {port}...")

    # Create and register print reporter
    print_reporter = PrintReporter()
    reporter_registry.add(print_reporter)

    # Start server in background thread
    server_thread = threading.Thread(target=start_server, args=(port,), daemon=True)
    server_thread.start()

    # Give server time to start
    time.sleep(1)

    typer.echo(f"✓ Server started on http://127.0.0.1:{port}")
    typer.echo("\n\033[2mTip: Run 'flow hooks set' in another terminal to enable hooks\033[0m\n")
    typer.echo("Waiting for hook events (Ctrl+C to stop)\n")

    try:
        # Keep main thread alive
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        # Cleanup
        reporter_registry.remove(print_reporter)
        typer.echo("\n\n✓ Trace stopped")
        raise typer.Exit(0)


# Config command group
config_app = typer.Typer(help="Manage configuration")
app.add_typer(config_app, name="config")


@config_app.command("list")
def config_list():
    """List all configuration values."""
    config = list_config()
    if not config:
        typer.echo("No configuration values set.")
    else:
        for key, value in config.items():
            typer.echo(f"{key}={value}")


@config_app.command("set")
def config_set(key_value: Annotated[str, typer.Argument(help="Configuration in format key=value")]):
    """
    Set a configuration value.

    Example: flow config set timeout=30
    """
    if "=" not in key_value:
        typer.echo("Error: Expected format key=value", err=True)
        raise typer.Exit(1)

    key, value = key_value.split("=", 1)
    key = key.strip()
    value = value.strip()

    if not key:
        typer.echo("Error: Key cannot be empty", err=True)
        raise typer.Exit(1)

    set_config_value(key, value)
    typer.echo(f"Set {key}={value}")


@config_app.command("remove")
def config_remove(key: Annotated[str, typer.Argument(help="Configuration key to remove")]):
    """
    Remove a configuration value.

    Example: flow config remove timeout
    """
    if remove_config_value(key):
        typer.echo(f"Removed {key}")
    else:
        typer.echo(f"Key '{key}' not found", err=True)
        raise typer.Exit(1)


# Auth command group
auth_app = typer.Typer(help="Manage authentication")
app.add_typer(auth_app, name="auth")


@auth_app.command("login")
def auth_login(
    api_key: Annotated[
        Optional[str], typer.Argument(help="Your Flowpad API key (optional - opens browser if not provided)")
    ] = None,
):
    """
    Login to Flowpad.

    If API key is provided, stores it directly.
    If no API key is provided, opens browser for authentication.

    Examples:
      flow auth login your-api-key-here
      flow auth login  # Opens browser
    """
    if api_key:
        # Direct API key login
        from flow_sdk.cli.app_config import set_user
        from flow_sdk.cli.auth import validate_api_key

        try:
            user_info = validate_api_key(api_key)
            set_api_key(api_key)
            set_user(user_info)
            typer.echo("✓ Successfully logged in to Flowpad")
            typer.echo("✓ API key stored securely in system keyring")
            typer.echo(f"✓ User ID: {user_info.get('id')}")
        except Exception as e:
            typer.echo(f"✗ Login failed: {e}", err=True)
            raise typer.Exit(1)
    else:
        # Browser-based login flow
        import webbrowser

        from flow_sdk.cli.env_loader import get_login_url
        from server.app import wait_for_post_login

        port = _discover_port()

        # Build the callback URL
        callback_url = f"http://127.0.0.1:{port}/post_login"

        # Get the formatted login URL with the callback URL
        full_login_url = get_login_url(callback_url)

        typer.echo("\n🌊 Opening browser for Flowpad login...")
        typer.echo(f"Callback URL: {callback_url}")
        typer.echo(f"Full Login URL: {full_login_url}\n")

        # Open browser
        webbrowser.open(full_login_url)

        # Wait for the login callback
        result = wait_for_post_login()

        if result.get("success"):
            typer.echo("\n✓ Successfully logged in to Flowpad")
            typer.echo("✓ API key stored securely in system keyring")
            if "user" in result:
                typer.echo(f"✓ User ID: {result['user'].get('id')}")
        else:
            typer.echo(f"\n✗ Login failed: {result.get('message', 'Unknown error')}", err=True)
            if "error" in result:
                typer.echo(f"  Error: {result['error']}", err=True)
            raise typer.Exit(1)


@auth_app.command("logout")
def auth_logout():
    """
    Logout from Flowpad by removing your stored API key.

    Example: flow auth logout
    """
    if is_logged_in():
        from flow_sdk.cli.app_config import clear_user

        delete_api_key()
        clear_user()
        typer.echo("✓ Successfully logged out from Flowpad")
        typer.echo("✓ API key and user info removed")
    else:
        typer.echo("⚠ Not currently logged in")


@auth_app.command("test")
def auth_test(delay: Annotated[int, typer.Option(help="Delay in seconds before allowing login")] = 5):
    """
    Test the login flow using a local test page with countdown timer.

    This command opens a test login page that simulates the Flowpad login flow.
    Use the --delay option to test the countdown timer functionality.

    Examples:
      flow auth test          # 5 second delay (default)
      flow auth test --delay 10  # 10 second delay
    """
    import webbrowser

    from server.app import wait_for_post_login

    port = _discover_port()

    # Build the test login URL with callback and delay
    callback_url = f"http://127.0.0.1:{port}/post_login"
    test_login_url = f"http://127.0.0.1:{port}/test_login?callback={callback_url}&delay={delay}"

    typer.echo(f"\n🧪 Opening test login page with {delay} second delay...")
    typer.echo(f"Test URL: {test_login_url}\n")

    # Open browser
    webbrowser.open(test_login_url)

    # Wait for the login callback
    result = wait_for_post_login()

    if result.get("success"):
        typer.echo("\n✓ Test login successful!")
        typer.echo("✓ API key stored securely in system keyring")
        if "user" in result:
            typer.echo(f"✓ User ID: {result['user'].get('id')}")
    else:
        typer.echo(f"\n✗ Test login failed: {result.get('message', 'Unknown error')}", err=True)
        if "error" in result:
            typer.echo(f"  Error: {result['error']}", err=True)
        raise typer.Exit(1)


# Hooks command group
hooks_app = typer.Typer(help="Manage Claude Code hooks")
app.add_typer(hooks_app, name="hooks")


def _parse_scope(scope_str: str) -> ClaudeScope:
    """Convert scope string to ClaudeScope enum."""
    scope_map = {
        "user": ClaudeScope.USER,
        "project": ClaudeScope.PROJECT,
        "local": ClaudeScope.LOCAL,
    }
    scope_lower = scope_str.lower()
    if scope_lower not in scope_map:
        raise typer.BadParameter(f"Invalid scope '{scope_str}'. Must be one of: user, project, local")
    return scope_map[scope_lower]


@hooks_app.command("set")
def hooks_set(
    scope: Annotated[str, typer.Option(help="Scope for hooks: user, project, or local")] = "user",
):
    """
    Set all Flow hooks in Claude Code settings.

    Configures hooks for all Claude Code events to report to flow trace.
    Default scope is 'user' (applies globally to all projects).

    Events configured:
    - UserPromptSubmit: User sends a prompt
    - PreToolUse: Before a tool is executed
    - PostToolUse: After a tool is executed
    - Notification: Claude sends a notification
    - Stop: Session stops
    - SubagentStop: Subagent stops

    Examples:
      flow hooks set
      flow hooks set --scope project
      flow hooks set --scope local
    """
    from flow_sdk.cli.commands.setup_cmd.claude_code_setup.claude_hooks import setHook
    from flow_sdk.cli.commands.setup_cmd.claude_code_setup.flow_metadata import FlowHookMetadata
    from flow_sdk.cli.commands.setup_cmd.claude_code_setup.hook_events import EVENTS_NO_MATCHER, EVENTS_WITH_MATCHER
    from flow_sdk.cli.commands.setup_cmd.claude_code_setup.setup_claude import _get_hook_script_path

    try:
        claude_scope = _parse_scope(scope)
    except typer.BadParameter as e:
        typer.echo(str(e), err=True)
        raise typer.Exit(1)

    context = get_context()

    # Validate scope is available
    if claude_scope in [ClaudeScope.PROJECT, ClaudeScope.LOCAL] and not context.is_in_repo():
        typer.echo(f"Error: Cannot use '{scope}' scope - not in a git repository", err=True)
        raise typer.Exit(1)

    typer.echo(f"Setting Flow hooks (scope: {scope})...")

    # Get the hook script path
    hook_script_path = _get_hook_script_path()

    if not hook_script_path.exists():
        typer.echo(f"Error: Hook script not found at {hook_script_path}", err=True)
        typer.echo("Run 'flow setup claude-code' first to create the hook script.", err=True)
        raise typer.Exit(1)

    success_count = 0

    # Set hooks for events without matchers
    for event_name in EVENTS_NO_MATCHER:
        flow_metadata = FlowHookMetadata.create(name=event_name.lower())
        success = setHook(
            scope=claude_scope,
            event_name=event_name,
            matcher=None,
            cmd=str(hook_script_path),
            context=context,
            flow_metadata=flow_metadata,
        )
        if success:
            typer.echo(f"✓ {event_name}")
            success_count += 1
        else:
            typer.echo(f"✗ {event_name} (failed)", err=True)

    # Set hooks for events with matchers (match all tools)
    for event_name in EVENTS_WITH_MATCHER:
        flow_metadata = FlowHookMetadata.create(name=event_name.lower())
        success = setHook(
            scope=claude_scope,
            event_name=event_name,
            matcher="*",  # Match all tools
            cmd=str(hook_script_path),
            context=context,
            flow_metadata=flow_metadata,
        )
        if success:
            typer.echo(f"✓ {event_name} (matcher: *)")
            success_count += 1
        else:
            typer.echo(f"✗ {event_name} (failed)", err=True)

    typer.echo(f"\n✓ {success_count} hooks configured")
    typer.echo(f"✓ Settings file: {context.get_claude_settings_path(claude_scope)}")


@hooks_app.command("clear")
def hooks_clear(
    scope: Annotated[str, typer.Option(help="Scope for hooks: user, project, or local")] = "user",
):
    """
    Clear all Flow hooks from Claude Code settings.

    Only removes hooks that are Flow commands (safe for other hooks).
    Default scope is 'user'.

    Examples:
      flow hooks clear
      flow hooks clear --scope project
    """
    from flow_sdk.cli.commands.setup_cmd.claude_code_setup.claude_hooks import removeHook
    from flow_sdk.cli.commands.setup_cmd.claude_code_setup.hook_events import ALL_HOOK_EVENTS

    try:
        claude_scope = _parse_scope(scope)
    except typer.BadParameter as e:
        typer.echo(str(e), err=True)
        raise typer.Exit(1)

    context = get_context()

    # Validate scope is available
    if claude_scope in [ClaudeScope.PROJECT, ClaudeScope.LOCAL] and not context.is_in_repo():
        typer.echo(f"Error: Cannot use '{scope}' scope - not in a git repository", err=True)
        raise typer.Exit(1)

    typer.echo(f"Clearing Flow hooks (scope: {scope})...")

    # Remove all flow-managed hooks
    removed_count = 0
    for event_name in ALL_HOOK_EVENTS:
        success = removeHook(scope=claude_scope, event_name=event_name, matcher=None, context=context)
        if success:
            typer.echo(f"✓ {event_name}")
            removed_count += 1

    if removed_count > 0:
        typer.echo(f"\n✓ {removed_count} hooks cleared from {context.get_claude_settings_path(claude_scope)}")
    else:
        typer.echo("No Flow hooks found to remove.")


@hooks_app.command("report")
def hooks_report(
    hook_entry_id: Annotated[
        Optional[str], typer.Option("--hook-entry-id", help="Hook entry ID for metadata lookup")
    ] = None,
    name: Annotated[Optional[str], typer.Option("--name", help="Hook name (e.g. flowpad_sniffer)")] = None,
):
    """
    Report hook event data to the Flow server.

    This command is called BY hook scripts to report event data.
    Reads JSON from stdin and POSTs to AGENT_HOOKS_REPORT_URL (or local server).
    Always exits with code 0 to avoid blocking Claude.

    This command is designed for efficiency - called on every hook trigger.
    """
    import json
    import sys
    from pathlib import Path

    def find_hook_metadata(
        entry_id: Optional[str], hook_name: Optional[str] = None
    ) -> tuple[Optional[dict], Optional[str]]:
        """Build hook metadata from CLI args (--hook-entry-id, --name).

        Hook identity is carried in the command string, so no need to
        scan settings files for flow_metadata (which gets stripped by
        Claude Code's additionalProperties: false anyway).
        """
        metadata = {}
        if hook_name:
            metadata["name"] = hook_name

        # Check project-level settings first, then user-level
        project_dir = os.environ.get("CLAUDE_PROJECT_DIR")
        if project_dir:
            project_settings = Path(project_dir) / ".claude" / "settings.json"
            if project_settings.exists():
                return (metadata or None), str(project_settings)

        fallback_path = Path.home() / ".claude" / "settings.json"
        settings_path = str(fallback_path) if fallback_path.exists() else None
        return (metadata or None), settings_path

    verbose = sys.stdin.isatty()

    try:
        # Read JSON from stdin (hook event data), or use test payload if interactive
        if verbose:
            input_data = {"hook_event_name": "test_ping", "source": "manual_cli"}
            typer.echo("No stdin detected (TTY), using test payload")
        else:
            input_data = json.load(sys.stdin)

        hook_metadata, hook_file_path = find_hook_metadata(hook_entry_id, hook_name=name)
        report_payload = {
            **input_data,
            "hook_entry_id": hook_entry_id,
            "hook_metadata": hook_metadata,
            "hook_file_path": hook_file_path,
        }

        # Prefer dedicated webhook/listen route when configured by AgentHook command.
        report_url = os.environ.get("AGENT_HOOKS_REPORT_URL")
        if report_url:
            flow_data_payload = {
                "webhook_type": "agent_hook",
                "webhook_payload": {
                    "agent_hook_id": hook_entry_id,
                    "hook_data": {
                        "hook_event_name": input_data.get("hook_event_name", input_data.get("event")),
                        "session_id": input_data.get("session_id"),
                        "terminal_id": os.environ.get("FLOWPAD_TERMINAL_ID"),
                        "tool_name": input_data.get("tool_name"),
                        "tool_input": input_data.get("tool_input"),
                        "tool_response": input_data.get("tool_response"),
                        "output": input_data.get("output"),
                        "prompt": input_data.get("prompt"),
                        "message": input_data.get("message"),
                        "usage": input_data.get("usage"),
                        "cwd": input_data.get("cwd"),
                        "transcript_path": input_data.get("transcript_path"),
                        "raw_hook_data": input_data,
                    },
                    "hook_entry_id": hook_entry_id,
                    "hook_metadata": hook_metadata,
                    "hook_file_path": hook_file_path,
                },
            }
            if verbose:
                typer.echo(f"\nTarget: POST {report_url}")
                typer.echo(f"\nPayload:\n{json.dumps(flow_data_payload, indent=2)}")
            try:
                resp = requests.post(report_url, json=flow_data_payload, timeout=5)
                if verbose:
                    typer.echo(f"\nResponse: {resp.status_code} {resp.text[:200]}")
            except requests.exceptions.RequestException as e:
                if verbose:
                    typer.echo(f"\nRequest failed: {e}")
        else:
            # Discover server from ~/.flow/server.json, fall back to env/default port
            from flow_sdk.discovery.flowpad_discovery import read_server_info

            server_info = read_server_info()
            if server_info:
                fallback_url = server_info.url  # http://localhost:{port}/api/v1/webhook/listen
                fallback_payload = {
                    "webhook_type": "agent_hook",
                    "webhook_payload": {
                        "agent_hook_id": hook_entry_id,
                        "hook_data": {
                            "hook_event_name": input_data.get("hook_event_name", input_data.get("event")),
                            "session_id": input_data.get("session_id"),
                            "raw_hook_data": input_data,
                        },
                        "hook_entry_id": hook_entry_id,
                        "hook_metadata": hook_metadata,
                        "hook_file_path": hook_file_path,
                    },
                }
                if verbose:
                    typer.echo(f"\nDiscovered server via ~/.flow/server.json (port {server_info.port})")
            else:
                port = int(os.environ.get("LOCAL_SERVER_PORT", "9007"))
                fallback_url = f"http://127.0.0.1:{port}/api/hooks/report"
                fallback_payload = report_payload
                if verbose:
                    typer.echo(f"\nNo AGENT_HOOKS_REPORT_URL or server.json, using legacy fallback (port {port})")

            if verbose:
                typer.echo(f"Target: POST {fallback_url}")
                typer.echo(f"\nPayload:\n{json.dumps(fallback_payload, indent=2)}")
            try:
                resp = requests.post(fallback_url, json=fallback_payload, timeout=2)
                if verbose:
                    typer.echo(f"\nResponse: {resp.status_code} {resp.text[:200]}")
            except requests.exceptions.RequestException as e:
                if verbose:
                    typer.echo(f"\nRequest failed: {e}")

    except json.JSONDecodeError:
        pass
    except Exception as e:
        if verbose:
            typer.echo(f"Error: {e}")

    # Always exit 0 to not block Claude
    raise typer.Exit(0)


@hooks_app.command("list")
def hooks_list(
    scope: Annotated[str, typer.Option(help="Scope for hooks: user, project, or local")] = "user",
):
    """
    List all configured hooks in Claude Code settings.

    Shows events, matchers, and hook commands for the specified scope.
    Default scope is 'user'.

    Examples:
      flow hooks list
      flow hooks list --scope project
    """
    from flow_sdk.cli.commands.setup_cmd.claude_code_setup.hook_parser import HookParser

    try:
        claude_scope = _parse_scope(scope)
    except typer.BadParameter as e:
        typer.echo(str(e), err=True)
        raise typer.Exit(1)

    context = get_context()

    # Validate scope is available
    if claude_scope in [ClaudeScope.PROJECT, ClaudeScope.LOCAL] and not context.is_in_repo():
        typer.echo(f"Error: Cannot use '{scope}' scope - not in a git repository", err=True)
        raise typer.Exit(1)

    settings_path = context.get_claude_settings_path(claude_scope)
    typer.echo(f"Hooks for scope '{scope}': {settings_path}")
    typer.echo("-" * 60)

    # Initialize HookParser for the specified scope
    hook_parser = HookParser(context=context, scope=claude_scope)

    events = hook_parser.list_events()

    if not events:
        typer.echo("No hooks configured.")
        return

    for event in events:
        typer.echo(f"\nEvent: {event}")
        event_hooks = hook_parser.get_event_hooks(event)

        # Handle null/None values in hooks
        if event_hooks is None:
            typer.echo("  (disabled/null)")
            continue

        for entry in event_hooks:
            matcher = entry.get("matcher")
            if matcher:
                typer.echo(f"  Matcher: {matcher}")
            else:
                typer.echo("  Matcher: (none)")

            hooks = entry.get("hooks", [])
            for hook in hooks:
                hook_type = hook.get("type", "unknown")
                command = hook.get("command", "")
                typer.echo(f"    [{hook_type}] {command}")


def cli_main():
    """Entry point that can be used with CLICommand."""
    app()


if __name__ == "__main__":
    app()
