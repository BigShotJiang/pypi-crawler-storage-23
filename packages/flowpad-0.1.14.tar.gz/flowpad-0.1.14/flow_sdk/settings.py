"""Settings module for Flow SDK."""

import os
from enum import StrEnum


class DeployEnv(StrEnum):
    """Deployment environment types."""
    DESKTOP = "desktop"


deploy_env: DeployEnv = DeployEnv(os.getenv(key="DEPLOY_ENV", default=DeployEnv.DESKTOP.value))


def is_desktop() -> bool:
    """Check if running in desktop environment."""
    return deploy_env == DeployEnv.DESKTOP
