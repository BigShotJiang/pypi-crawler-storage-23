"""ComputeNode entity for representing compute resources."""

from typing import ClassVar

from flow_sdk.db.drivers.db_base_record import BuiltinEntityType
from flow_sdk.core.entity.entity_model import Entity
from flow_sdk.api.api_types.api_field import APIField
from flow_sdk.flowpad_types.runtime_environment import RuntimeEnvironment
from flow_sdk.config import ComputeProviderType


class ComputeNode(Entity):
    """Represents a compute node/machine."""

    _api_visible: ClassVar[bool] = True
    type: str = APIField(default=BuiltinEntityType.COMPUTE_NODE.value)
    name: str | None = APIField(default=None)
    runtime: RuntimeEnvironment = APIField(default_factory=RuntimeEnvironment)
    node_provider_type: ComputeProviderType | None = APIField(default=None)
    fs_storage_provider: str | None = APIField(default=None)
    fs_storage_mount_path: str | None = APIField(default=None)
    visitor_role: str | None = APIField(default=None)

    def __init__(self, **data):
        super().__init__(**data)
        # Local compute nodes mount the machine root filesystem
        if self.node_provider_type == ComputeProviderType.LOCAL_MACHINE:
            if not self.fs_storage_mount_path:
                self.fs_storage_mount_path = "/"
            if not self.fs_storage_provider:
                self.fs_storage_provider = "local"
