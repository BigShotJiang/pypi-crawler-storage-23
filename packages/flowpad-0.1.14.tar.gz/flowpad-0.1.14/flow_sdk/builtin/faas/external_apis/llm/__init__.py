"""Stub LLM module."""
