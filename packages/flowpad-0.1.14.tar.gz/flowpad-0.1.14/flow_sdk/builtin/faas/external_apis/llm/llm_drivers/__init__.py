"""Stub LLM drivers module."""
