"""Stub external APIs module."""
