from enum import StrEnum
from typing import Any, ClassVar, Dict, Optional

from flow_sdk.api.api_types.api_field import APIField
from flow_sdk.core import Entity


class MemoStatus(StrEnum):
    OPEN = "open"
    CLOSED = "closed"
    PENDING = "pending"


class Memo(Entity):
    type: str = APIField(default="memo")
    memo_type: str = APIField("")
    source: str = APIField("")
    title: str = APIField("")
    content: str = APIField("")
    data: Optional[Dict[str, Any]] = APIField(default_factory=dict)
    session_id: str = APIField("")
    work_dir: str = APIField("")
    status: str = APIField(MemoStatus.OPEN)
    closed_at: Optional[str] = APIField(None)
    remind_at: Optional[str] = APIField(None)
    _api_visible: ClassVar[bool] = True
