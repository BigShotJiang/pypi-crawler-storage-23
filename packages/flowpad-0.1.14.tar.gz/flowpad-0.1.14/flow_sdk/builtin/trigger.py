from datetime import datetime, timezone
from typing import Any, ClassVar, Optional, Union

from starlette.requests import Request

from flow_sdk.flowpad_types.enums.entity_enums import BuiltInRelationshipTypes, RelationshipDirection
from flow_sdk.api.api_types.api_field import APIField
from flow_sdk.api.messages import HttpMethod
from flow_sdk.api.type_id import TypeId
from flow_sdk.builtin.hook_models import (
    ActionType,
    ErrorMessage,
    ExecutedAction,
    HookEventData,
    RelationshipSubAction,
    SuccessMessage,
    TriggerAction,
    get_action_handler,
)
from flow_sdk.core import action as core_action
from flow_sdk.db.drivers.db_base_record import BuiltinEntityType
from flow_sdk.db.drivers.query import QueryFilter
from flow_sdk.core.entity.entity_model import Entity
from flow_sdk.request_context.methods import get_current_request_info
from flow_sdk.responses.response import ApiFailResponse, ApiResponse, ApiSuccessResponse


class Trigger(Entity):
    """Entity representing a trigger that matches hook data and executes actions."""

    type: str = APIField(default=BuiltinEntityType.TRIGGER.value)
    name: str = APIField()
    description: Optional[str] = APIField(None)
    mask: dict[str, Any] = APIField(default_factory=dict, description="JSON mask for matching hook data")
    action: TriggerAction = APIField(default_factory=lambda: TriggerAction(action_type=ActionType.NOP))
    enabled: bool = APIField(default=True)
    last_triggered: Optional[datetime] = APIField(None, description="Timestamp of last trigger match")
    counter: int = APIField(default=0, description="Counter incremented when trigger action is executed")

    _api_visible: ClassVar[bool] = True
    _unique: ClassVar[list[str]] = []

    def match(self, hook_data: HookEventData) -> bool:
        """
        Check if the hook data matches this trigger's mask.

        Uses simple key-value matching. All key-value pairs in the mask must
        exactly match the corresponding fields in the hook data.

        Args:
            hook_data: The hook event data to match against

        Returns:
            True if all mask criteria match, False otherwise
        """
        if not self.enabled:
            return False

        hook_dict = hook_data.model_dump(exclude_none=False)

        for key, expected_value in self.mask.items():
            if key not in hook_dict:
                return False

            actual_value = hook_dict[key]

            if actual_value != expected_value:
                return False

        return True

    async def invoke(self, hook_data: HookEventData) -> ExecutedAction | None:
        """
        Invoke this trigger if it matches the hook data.

        Args:
            hook_data: The hook event data to match against

        Returns:
            ExecutedAction if trigger matched and executed, None otherwise
        """
        if not self.match(hook_data):
            return None

        return await self.execute_action()

    async def execute_action(self) -> ExecutedAction:
        """
        Execute the trigger action.

        Updates last_triggered timestamp and executes the action handler.
        Saves changes to the database.

        Returns:
            ExecutedAction with execution details
        """
        self.last_triggered = datetime.now(timezone.utc)

        handler = get_action_handler(self.action.action_type)
        if handler:
            await handler.execute(self)

        await self.update()

        return ExecutedAction(
            trigger_id=self.id,
            trigger_name=self.name,
            action_type=self.action.action_type,
            counter=self.counter,
        )

    async def get_agent_hooks(self) -> list[TypeId]:
        """Get all agent hooks connected to this trigger."""
        relationships = await self.get_incoming_relationships(
            relationships_filter=QueryFilter(type=BuiltInRelationshipTypes.ConnectedTo)
        )
        return [rel.from_typeid for rel in relationships if rel.from_typeid]

    async def connect_to_agent_hook(self, agent_hook: Union[Entity, TypeId]) -> None:
        """Connect this trigger to an agent hook."""
        if isinstance(agent_hook, Entity):
            agent_hook = agent_hook.typeid

        await self.save_relationship(
            to_e=agent_hook,
            relationship_or_str=BuiltInRelationshipTypes.ConnectedTo,
            direction=RelationshipDirection.Incoming,
        )

    async def disconnect_from_agent_hook(self, agent_hook: Union[Entity, TypeId]) -> None:
        """Disconnect this trigger from an agent hook."""
        if isinstance(agent_hook, Entity):
            agent_hook = agent_hook.typeid

        await self.delete_relationship(to_e=agent_hook, relationship=BuiltInRelationshipTypes.ConnectedTo)

    @core_action.all(action_name="agent_hook")
    async def agent_hook_action(self, request: Request) -> ApiResponse:
        """
        Handle agent hook relationship management for this trigger.

        Routes:
        - GET  /api/v1/graph/trigger/{id}/agent_hook        -> list connected agent hooks
        - POST /api/v1/graph/trigger/{id}/agent_hook/add    -> add agent hook connection
        - POST /api/v1/graph/trigger/{id}/agent_hook/remove -> remove agent hook connection
        """
        from flow_sdk.builtin.agent_hook import AgentHook

        request_info = get_current_request_info()
        if not request_info:
            return ApiFailResponse(message=ErrorMessage.REQUEST_INFO_NOT_AVAILABLE)

        method = request.method.upper()
        sub_action = request_info.sub_path

        if method == HttpMethod.GET.value:
            # List all agent hooks connected to this trigger
            agent_hook_typeids = await self.get_agent_hooks()
            agent_hooks = []
            for typeid in agent_hook_typeids:
                agent_hook = await AgentHook.get_by_typeid(typeid)
                if agent_hook:
                    agent_hooks.append(agent_hook.model_dump())
            return ApiSuccessResponse(data=agent_hooks)

        elif method == HttpMethod.POST.value:
            body = await request_info.get_post_data()
            if not body:
                return ApiFailResponse(message=ErrorMessage.REQUEST_BODY_REQUIRED)

            agent_hook_id = body.get("agent_hook_id")
            if not agent_hook_id:
                return ApiFailResponse(message=ErrorMessage.AGENT_HOOK_ID_REQUIRED)

            try:
                agent_hook_typeid = TypeId.model_validate(agent_hook_id)
            except Exception as e:
                return ApiFailResponse(message=f"{ErrorMessage.INVALID_AGENT_HOOK_ID_FORMAT}: {e}")

            if sub_action == RelationshipSubAction.ADD:
                await self.connect_to_agent_hook(agent_hook_typeid)
                return ApiSuccessResponse(message=SuccessMessage.AGENT_HOOK_CONNECTED)

            elif sub_action == RelationshipSubAction.REMOVE:
                await self.disconnect_from_agent_hook(agent_hook_typeid)
                return ApiSuccessResponse(message=SuccessMessage.AGENT_HOOK_DISCONNECTED)

            else:
                return ApiFailResponse(message=f"{ErrorMessage.UNKNOWN_SUB_ACTION}: {sub_action}")

        return ApiFailResponse(message=f"{ErrorMessage.METHOD_NOT_ALLOWED} agent_hook")
