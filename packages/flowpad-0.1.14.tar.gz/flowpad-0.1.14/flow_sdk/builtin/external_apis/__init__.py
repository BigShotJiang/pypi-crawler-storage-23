# Builtin external APIs stub
