"""Agentic processor backend for flow-cli.

Supports the full AgenticProcessor action surface:
- POST /api/v1/graph/apu (compatibility factory)
- POST /api/v1/graph/agentic_processor/{id}/controlStart
- POST /api/v1/graph/agentic_processor/{id}/controlAppend
- POST /api/v1/graph/agentic_processor/{id}/controlInput
- POST /api/v1/graph/agentic_processor/{id}/controlAbort
- POST /api/v1/graph/agentic_processor/{id}/controlStep
- POST /api/v1/graph/agentic_processor/{id}/controlContinue
- GET  /api/v1/graph/agentic_processor/{id}/state
- POST /api/v1/graph/agentic_processor/{id}/runFile
- POST /api/v1/graph/agentic_processor/{id}/run
- POST /api/v1/graph/agentic_processor/{id}/execute
- POST /api/v1/graph/agentic_processor/{id}/createProcess

It parses AMD `flow-ui` directives, emits websocket `flow_data_msg` events, and
updates processor state via normal entity update notifications.

Desktop mode: No Flow entity, single @local compute node, simplified execution.
"""

from __future__ import annotations

import asyncio
import copy
import json
import logging
import os
import re
import shlex
import sys
import shutil
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable
from uuid import uuid4

from pydantic import BaseModel

from flow_sdk.api.api_types.api_field import APIField
from flow_sdk.core import Entity, action
from flow_sdk.request_context.methods import get_current_request_info
from flow_sdk.responses.response import ApiFailResponse, ApiSuccessResponse

logger = logging.getLogger(__name__)


class ProcessorStatus(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    STEPPING = "stepping"
    COMPLETE = "complete"
    ERROR = "error"
    TERMINATED = "terminated"


class StackFrame(BaseModel):
    frame_id: str
    type: str
    instruction_id: str
    index: int = 0
    source_vfs_path: str | None = None
    local_variables: dict[str, Any] = {}
    iterator_name: str | None = None
    iterator_index: int | None = None
    iterator_total: int | None = None


class DebugState(BaseModel):
    enabled: bool = False
    breakpoints: list[str] = []
    step_mode: str | None = None


class ProcessorState(BaseModel):
    status: str = ProcessorStatus.IDLE.value
    index: int = 0
    total_instructions: int = 0
    current_instruction_id: str | None = None
    variables: dict[str, Any] = {}
    waiting_for_input: bool = False
    input_id: str | None = None
    stack: list[dict[str, Any]] = []
    debug: dict[str, Any] = {"enabled": False, "breakpoints": [], "step_mode": None}
    error: str | None = None
    mdo_content: str | None = None


class AgenticContext(BaseModel):
    permission_mode: str | None = None
    workdir: str | None = None
    model: str | None = None
    max_thinking_tokens: int | None = None
    compute_node_id: str | None = None


class ContextData(BaseModel):
    """Serialized context data from frontend.

    Note: compute_node_id is NOT passed from frontend - it's a security-sensitive
    field set by the backend when AgenticProcessor is created via ComputeNode action.
    """

    instructions: str | None = None
    workdir: str | None = None
    env_vars: dict[str, str] = {}
    model: str | None = None
    max_thinking_tokens: int = 1024
    permission_mode: str = "bypassPermissions"
    project_id: str | None = None  # Project to associate the process with
    agents_json: dict[str, Any] | None = None  # Claude Code --agents spec


class ControlStartRequest(BaseModel):
    """Request to start execution."""

    mdo_content: str | None = None
    source_vfs_path: str | None = None  # VFS path of the executing skill file for UI URI resolution
    debug: bool = False
    breakpoints: list[str] = []


class ControlInputRequest(BaseModel):
    """Request to provide input for blocking UI."""

    input_data: str | None = None
    input_id: str | None = None


class ControlStepRequest(BaseModel):
    """Request to step in debug mode."""

    step_mode: str = "over"


class ControlAppendRequest(BaseModel):
    """Request to append a new instruction to a running process."""

    content: str
    instruction_id: str | None = None


class ControlContinueRequest(BaseModel):
    """Request to continue a completed process with new instruction."""

    process_id: str  # ID of the completed process to continue
    mdo_content: str  # New instruction content to execute
    debug: bool = False
    breakpoints: list[str] = []


class RunFileRequest(BaseModel):
    """Request to run an instruction file from VFS path."""

    vfs_path: str
    debug: bool = False
    breakpoints: list[str] = []


class RunRequest(BaseModel):
    """Request to run instruction content with context."""

    instruction_content: str
    context: ContextData | dict[str, Any] = {}
    debug: bool = False
    breakpoints: list[str] = []


class ExecuteRequest(BaseModel):
    """Request to execute instruction content directly (no file parsing).

    This is a simpler API that takes just the instruction text and context.
    The instruction is wrapped in AMD format if needed.
    """

    instruction_content: str  # Plain text or AMD instruction content
    context: ContextData | dict[str, Any] = {}
    debug: bool = False
    breakpoints: list[str] = []


class ProcessResultRequest(BaseModel):
    """Optional result metadata to create a ProcessResult child for a process."""

    uname: str | None = None
    result_type: str | None = None
    source_session_id: str | None = None


class CreateProcessRequest(BaseModel):
    """Request to create a new idle process ready for execute() calls."""

    context: ContextData | dict[str, Any] = {}
    result: ProcessResultRequest | None = None


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _default_processor_state() -> dict[str, Any]:
    return ProcessorState().model_dump()


class _UIItem(BaseModel):
    ui_id: str
    uri: str | None = None
    page: str | None = None
    params: dict[str, Any] = {}
    blocking: bool = True
    content: str | None = None


_FLOW_UI_RE = re.compile(r"<!--\s*<flow-ui\s+(.*?)\/>\s*-->", re.IGNORECASE | re.DOTALL)
_ATTR_RE = re.compile(r"""([a-zA-Z0-9_-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')""")


def _parse_flow_ui_items(mdo_content: str) -> list[_UIItem]:
    items: list[_UIItem] = []
    for idx, match in enumerate(_FLOW_UI_RE.finditer(mdo_content or "")):
        raw_attrs = match.group(1)
        attrs: dict[str, str] = {}
        for attr_match in _ATTR_RE.finditer(raw_attrs):
            key = attr_match.group(1)
            value = attr_match.group(2) if attr_match.group(2) is not None else (attr_match.group(3) or "")
            attrs[key] = value

        ui_id = attrs.get("id", f"ui_{idx}")
        uri = attrs.get("uri")
        page = attrs.get("page")
        non_blocking = attrs.get("non-blocking", "false").strip().lower() == "true"

        params: dict[str, Any] = {}
        raw_params = attrs.get("params")
        if raw_params:
            try:
                loaded = json.loads(raw_params)
                if isinstance(loaded, dict):
                    params = loaded
            except Exception:
                logger.warning("Failed parsing flow-ui params for %s", ui_id)

        items.append(
            _UIItem(
                ui_id=ui_id,
                uri=uri,
                page=page,
                params=params,
                blocking=not non_blocking,
            )
        )
    return items


async def _send_flow_data_message(target_type: str, target_id: str, payload: dict[str, Any]) -> None:
    """Emit a websocket flow_data message to watchers of the target entity."""
    try:
        from flow_sdk.app.actions.watch_registry import get_watched_by
        from flow_sdk.core.network.connections import get_all_connections
    except Exception as exc:
        logger.warning("Unable to import watch/connection helpers for flow_data emit: %s", exc)
        return

    entity_key = f"{target_type}:{target_id}"
    recipients = get_watched_by(entity_key)
    if not recipients:
        return

    active_connections = get_all_connections()
    message = {
        "message_type": "flow_data_msg",
        "message_id": str(uuid4()),
        "to_entity": f"{target_type}-{target_id}",
        "flow_data": payload,
    }
    message_json = json.dumps(message)

    for connection_id in recipients:
        ws = active_connections.get(connection_id)
        if not ws:
            continue
        try:
            await ws.send_text(message_json)
        except Exception as exc:
            logger.warning("Failed sending flow_data to %s: %s", connection_id, exc)


def build_claude_shell_command(
    worker_session_id: str,
    process_type: str,
    process_id: str,
    context_data: dict[str, Any],
    instruction: str | None = None,
    resume: bool = False,
) -> str:
    """Build a shell command string to launch Claude Code CLI.

    Reads all parameters from context_data and produces a single shell command
    with env-var prefix, suitable for injection into a PTY session.

    Args:
        worker_session_id: The claude --session-id value.
        process_type: Entity type for FLOWPAD_EXECUTION_SCOPE (e.g. "agentic_process").
        process_id: Entity id for FLOWPAD_EXECUTION_SCOPE.
        context_data: Dict with workdir, permission_mode, chrome, model, env_vars,
                      agents_json, etc.
        instruction: Prompt text (required unless resume=True).
        resume: If True, build a --resume command instead of --session-id -p.

    Returns:
        Shell command string ready for PTY injection.
    """
    workdir = context_data.get("workdir") or os.getcwd()
    permission_mode = context_data.get("permission_mode", "bypassPermissions")
    model: str | None = context_data.get("model")
    chrome: bool = bool(context_data.get("chrome"))
    agents_json: dict | None = context_data.get("agents_json")
    extra_env_vars: dict[str, str] = context_data.get("env_vars") or {}

    # Build env vars to prefix on the command line
    env_vars: dict[str, str] = {"CLAUDE_PROJECT_DIR": workdir}
    env_vars.update(extra_env_vars)

    # Webhook URL for hook event routing
    try:
        from flow_sdk.builtin.claude_settings_sync import get_webhook_listen_url

        env_vars["AGENT_HOOKS_REPORT_URL"] = get_webhook_listen_url()
    except Exception:
        logger.debug("Could not resolve webhook URL for AGENT_HOOKS_REPORT_URL")

    # Execution scope for routing hook events back to this process
    env_vars["FLOWPAD_EXECUTION_SCOPE"] = json.dumps([{"type": process_type, "id": process_id}])

    if sys.platform == "win32":
        import base64 as _b64

        def _ps_quote(s: str) -> str:
            return "'" + s.replace("'", "''") + "'"

        env_commands = [f"$env:{k} = {_ps_quote(v)}" for k, v in env_vars.items()]
        env_prefix = "; ".join(env_commands) + "; " if env_commands else ""

        args_parts = ["claude"]
        if permission_mode == "bypassPermissions":
            args_parts.append("--dangerously-skip-permissions")
        if chrome:
            args_parts.append("--chrome")
        if resume:
            args_parts.append(f"--resume {worker_session_id}")
        else:
            args_parts.append(f"--session-id {worker_session_id}")
        if model:
            args_parts.append(f"--model {model}")
        if agents_json:
            args_parts.append(f"--agents {_ps_quote(json.dumps(agents_json))}")
        if instruction and not resume:
            prompt_b64 = _b64.b64encode(instruction.encode("utf-8")).decode("ascii")
            decode_cmd = f"[System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{prompt_b64}'))"
            args_parts.append(f"-p ({decode_cmd})")

        return f"cd {_ps_quote(workdir)}; {env_prefix}{' '.join(args_parts)}"
    else:
        # POSIX
        env_prefix = " ".join(f"{k}={shlex.quote(v)}" for k, v in env_vars.items())

        args_parts = ["claude"]
        if permission_mode == "bypassPermissions":
            args_parts.append("--dangerously-skip-permissions")
        if chrome:
            args_parts.append("--chrome")
        if resume:
            args_parts.append(f"--resume {shlex.quote(worker_session_id)}")
        else:
            args_parts.append(f"--session-id {shlex.quote(worker_session_id)}")
        if model:
            args_parts.append(f"--model {shlex.quote(model)}")
        if agents_json:
            args_parts.append(f"--agents {shlex.quote(json.dumps(agents_json))}")

        cmd = f"cd {shlex.quote(workdir)} && {env_prefix} {' '.join(args_parts)}"

        if instruction and not resume:
            # Use heredoc for multi-line prompt safety
            cmd += f" -p \"$(cat <<'EOF'\n{instruction}\nEOF\n)\""

        return cmd


async def _run_claude_subprocess(
    process_id: str,
    process_type: str,
    instruction: str,
    worker_session_id: str,
    context_data: dict[str, Any],
) -> None:
    """Run claude CLI in background and update AgenticProcess state when done."""
    try:
        claude_bin = shutil.which("claude")
        if not claude_bin:
            logger.error("AgenticProcess %s: claude binary not found in PATH", process_id)
            process = await AgenticProcess.get_by_id(process_id)
            if process:
                process._set_process_state(status=ProcessorStatus.ERROR.value, error="claude binary not found")
                await process.save()
            return

        workdir = context_data.get("workdir") or os.getcwd()
        permission_mode = context_data.get("permission_mode", "bypassPermissions")
        model: str | None = context_data.get("model")
        extra_env_vars: dict[str, str] = context_data.get("env_vars") or {}

        env = os.environ.copy()
        env.update(extra_env_vars)
        env["CLAUDE_PROJECT_DIR"] = workdir

        try:
            from builtin.claude_settings_sync import get_webhook_listen_url

            env["AGENT_HOOKS_REPORT_URL"] = get_webhook_listen_url()
        except Exception:
            pass

        env["FLOWPAD_EXECUTION_SCOPE"] = json.dumps([{"type": process_type, "id": process_id}])

        args = [claude_bin]
        if permission_mode == "bypassPermissions":
            args.append("--dangerously-skip-permissions")
        args.extend(["--session-id", worker_session_id])
        if model:
            args.extend(["--model", model])
        agents_json: dict | None = context_data.get("agents_json")
        if agents_json:
            args.extend(["--agents", json.dumps(agents_json)])
        args.extend(["-p", instruction])

        logger.info(
            "AgenticProcess %s: launching claude, workdir=%s args=%s",
            process_id,
            workdir,
            " ".join(shlex.quote(a) for a in args[1:]),
        )

        proc = await asyncio.create_subprocess_exec(
            *args,
            cwd=workdir,
            env=env,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout_bytes, stderr_bytes = await proc.communicate()
        output = stdout_bytes.decode("utf-8", errors="replace")
        error_output = stderr_bytes.decode("utf-8", errors="replace")

        logger.info(
            "AgenticProcess %s: claude exited code=%d output_len=%d",
            process_id,
            proc.returncode,
            len(output),
        )

        if output:
            await _send_flow_data_message(
                process_type,
                process_id,
                {
                    "element_type": "text",
                    "data_type": "string",
                    "flow_value": output,
                    "attributes": {"t": _now_iso()},
                },
            )

        process = await AgenticProcess.get_by_id(process_id)
        if process:
            if proc.returncode == 0:
                process._set_process_state(status=ProcessorStatus.COMPLETE.value)
            else:
                err_msg = error_output or f"claude exited with code {proc.returncode}"
                process._set_process_state(status=ProcessorStatus.ERROR.value, error=err_msg)
            await process.save()

    except Exception as exc:
        logger.exception("AgenticProcess %s: background claude error: %s", process_id, exc)
        try:
            process = await AgenticProcess.get_by_id(process_id)
            if process:
                process._set_process_state(status=ProcessorStatus.ERROR.value, error=str(exc))
                await process.save()
        except Exception:
            pass


class AgenticProcess(Entity):
    _api_visible = True
    type: str = APIField(default="agentic_process")

    processor_id: str | None = APIField(default=None)
    instruction_content: str | None = APIField(default=None)
    source_vfs_path: str | None = APIField(default=None)
    context: dict[str, Any] = APIField(default_factory=dict)
    context_data: dict[str, Any] = APIField(default_factory=dict)
    favorite_index: int | None = APIField(default=None)
    state: dict[str, Any] = APIField(default_factory=_default_processor_state)
    worker_session_id: str | None = APIField(default=None)
    use_worker_history: bool = APIField(default=False)
    pty_session_id: str | None = APIField(default=None)
    compute_node_id: str | None = APIField(default=None)

    def _get_process_state(self) -> dict[str, Any]:
        if not isinstance(self.state, dict):
            self.state = _default_processor_state()
        return copy.deepcopy(self.state)

    def _set_process_state(self, **updates: Any) -> None:
        state = self._get_process_state()
        state.update(updates)
        self.state = state

    @action.all(action_name="control")
    async def control(self):
        """Unified control action dispatched by sub_path.

        Ported from FlowPad: flowpad/hub/core/agentic_processor/process.py
        Routes to internal control methods based on sub_path:
        - /control/pause - Pause message processing
        - /control/resume - Resume message processing
        - /control/inject - Inject a new message

        Returns:
            ApiResponse with status or error message
        """
        request_info = get_current_request_info()
        if request_info is None:
            return ApiFailResponse(message="No request context available")

        sub_action = request_info.sub_path
        if not sub_action:
            return ApiFailResponse(message="Missing sub_path for control action")

        # Remove leading slash if present
        sub_action = sub_action.lstrip("/")

        if sub_action == "pause":
            return await self._control_pause()
        elif sub_action == "resume":
            return await self._control_resume()
        elif sub_action == "inject":
            return await self._control_inject(request_info)
        else:
            return ApiFailResponse(message=f"Unknown control action: {sub_action}")

    async def _control_pause(self):
        """Pause message processing."""
        logger.info(f"AgenticProcess {self.id}: control/pause")
        self._set_process_state(status=ProcessorStatus.PAUSED.value)
        await self.save()
        return ApiSuccessResponse(data={"status": ProcessorStatus.PAUSED.value})

    async def _control_resume(self):
        """Resume message processing after pause."""
        logger.info(f"AgenticProcess {self.id}: control/resume")
        self._set_process_state(status=ProcessorStatus.RUNNING.value)
        await self.save()
        return ApiSuccessResponse(data={"status": ProcessorStatus.RUNNING.value})

    async def _control_inject(self, request_info):
        """Inject a new message into the worker's input queue."""
        # Get message from request parameters or POST body
        message = None
        if request_info.request_parameters:
            message = request_info.request_parameters.get("message")
        if not message:
            post_data = await request_info.get_post_data()
            if isinstance(post_data, dict):
                message = post_data.get("message")

        if not message:
            return ApiFailResponse(message="Missing 'message' parameter")

        logger.info(f"AgenticProcess {self.id}: control/inject message: {message[:80]}...")

        # Desktop stub: no active worker, log and return success
        return ApiSuccessResponse(data={"injected": True, "message_length": len(message)})

    @action.get(action_name="get-history")
    async def get_history(self):
        """Get the execution history for this process.

        Ported from FlowPad: flowpad/hub/core/agentic_processor/process.py
        Desktop stub: returns empty history (no worker/blob storage in desktop mode).

        Returns:
            ApiSuccessResponse with list of FlowData items
        """
        return ApiSuccessResponse(
            data={
                "history": [],
                "count": 0,
                "worker_session_id": self.worker_session_id,
                "use_worker_history": self.use_worker_history,
            }
        )

    @action.all(action_name="step")
    async def step_action(self):
        """Execute one instruction step.

        Ported from FlowPad: flowpad/hub/core/agentic_processor/process.py
        Desktop stub: validates status and returns step result.

        Returns:
            ApiSuccessResponse with step result
        """
        state = self._get_process_state()

        if state.get("status") == ProcessorStatus.TERMINATED.value:
            return ApiFailResponse(message="Process has been terminated")

        if state.get("status") == ProcessorStatus.RUNNING.value:
            return ApiFailResponse(message="Process is already running")

        logger.info(f"AgenticProcess {self.id}: step action")

        try:
            # Desktop mode: set status back to idle (no real instruction execution)
            self._set_process_state(status=ProcessorStatus.IDLE.value)
            await self.save()

            return ApiSuccessResponse(
                data={
                    "id": self.id,
                    "status": self._get_process_state().get("status"),
                    "index": self._get_process_state().get("index", 0),
                }
            )

        except Exception as e:
            logger.exception(f"AgenticProcess {self.id} step error: {e}")
            self._set_process_state(status=ProcessorStatus.ERROR.value, error=str(e))
            await self.save()
            return ApiFailResponse(message=str(e))

    @action.all(action_name="exit")
    async def exit_action(self):
        """Terminate this process.

        Ported from FlowPad: flowpad/hub/core/agentic_processor/process.py
        Sets status to TERMINATED. After exit, the process cannot accept
        new instructions.

        Returns:
            ApiSuccessResponse confirming termination
        """
        state = self._get_process_state()
        if state.get("status") == ProcessorStatus.TERMINATED.value:
            return ApiFailResponse(message="Process already terminated")

        logger.info(f"AgenticProcess {self.id}: exit action")

        try:
            self._set_process_state(status=ProcessorStatus.TERMINATED.value)
            await self.save()

            return ApiSuccessResponse(
                data={
                    "id": self.id,
                    "status": ProcessorStatus.TERMINATED.value,
                    "terminated": True,
                }
            )

        except Exception as e:
            logger.exception(f"AgenticProcess {self.id} exit error: {e}")
            return ApiFailResponse(message=str(e))

    # ============ PTY Lifecycle ============

    def _make_pty_exit_callback(self) -> Callable[[int | None], None]:
        """Create a callback for PTY process exit that updates process state.

        Captures process_id and the running event loop. The callback is called
        from the daemon reader thread, so it schedules the async state update
        via run_coroutine_threadsafe.
        """
        main_loop = asyncio.get_running_loop()
        process_id = self.id

        def _on_pty_exit(exit_code: int | None) -> None:
            async def _update_state():
                try:
                    proc = await AgenticProcess.get_by_id(process_id)
                    if not proc:
                        return
                    if exit_code is not None and exit_code != 0:
                        proc._set_process_state(
                            status=ProcessorStatus.ERROR.value,
                            error=f"claude exited with code {exit_code}",
                        )
                    else:
                        proc._set_process_state(status=ProcessorStatus.COMPLETE.value)
                    proc.pty_session_id = None
                    await proc.save()
                    logger.info(
                        "AgenticProcess %s: PTY exited (code=%s), state updated",
                        process_id,
                        exit_code,
                    )
                except Exception as exc:
                    logger.warning("AgenticProcess %s: on_exit update failed: %s", process_id, exc)

            asyncio.run_coroutine_threadsafe(_update_state(), main_loop)

        return _on_pty_exit

    async def _resolve_compute_node(self):
        """Resolve the ComputeNode for this process.

        Uses compute_node_id if set, otherwise falls back to @local node.
        """
        from flow_sdk.builtin.faas.compute_node import ComputeNode

        if self.compute_node_id:
            # compute_node_id is stored as "compute_node-<id>"
            parts = self.compute_node_id.split("-", 1)
            if len(parts) == 2:
                node = await ComputeNode.get_by_id(parts[1])
                if node:
                    return node

        # Desktop fallback: always @local
        return await ComputeNode.get_by_uname("local")

    @action.post(action_name="start-pty")
    async def start_pty(self, instruction: str | None = None, worker_session_id: str | None = None):
        """Create a PTY session and launch Claude Code CLI in it.

        Builds the full claude command from context_data (permission_mode, chrome,
        model, env_vars, etc.) and injects it into a new PTY. The PTY output is
        routed to WebSocket clients via the existing infrastructure.

        Args:
            instruction: Prompt text to send to claude (-p flag). Optional for interactive mode.
            worker_session_id: Optional pre-generated session ID. If not provided, one is generated.

        Returns:
            ApiSuccessResponse with pty_session_id and worker_session_id.
        """
        state = self._get_process_state()
        if state.get("status") == ProcessorStatus.TERMINATED.value:
            return ApiFailResponse(message="Process has been terminated")

        if self.pty_session_id:
            return ApiFailResponse(message="PTY session already active. Kill it first or use resume-pty.")

        compute_node = await self._resolve_compute_node()
        if not compute_node:
            return ApiFailResponse(message="No compute node available")

        try:
            self.worker_session_id = worker_session_id or self.worker_session_id or str(uuid4())
            self.pty_session_id = str(uuid4())
            self.compute_node_id = str(compute_node.typeid)

            # Build the shell command from context_data
            command = build_claude_shell_command(
                worker_session_id=self.worker_session_id,
                process_type=self.get_type(),
                process_id=self.id,
                context_data=dict(self.context_data),
                instruction=instruction,
            )

            on_exit = self._make_pty_exit_callback()
            workdir = self.context_data.get("workdir")
            session_name = f"Claude - {self.worker_session_id[:8]}"

            logger.info(
                "AgenticProcess %s: starting PTY session %s (worker=%s)",
                self.id,
                self.pty_session_id,
                self.worker_session_id,
            )

            ok = await compute_node.start_machine_pty_session(
                session_id=self.pty_session_id,
                rows=24,
                cols=80,
                name=session_name,
                working_dir=workdir,
                initial_command=command,
                on_exit=on_exit,
            )

            if not ok:
                self.pty_session_id = None
                return ApiFailResponse(message="Failed to create PTY session")

            self._set_process_state(status=ProcessorStatus.RUNNING.value)
            await self.save()

            return ApiSuccessResponse(
                data={
                    "id": self.id,
                    "status": ProcessorStatus.RUNNING.value,
                    "pty_session_id": self.pty_session_id,
                    "worker_session_id": self.worker_session_id,
                    "compute_node_id": self.compute_node_id,
                }
            )

        except Exception as e:
            logger.exception(f"AgenticProcess {self.id} start-pty error: {e}")
            self.pty_session_id = None
            self._set_process_state(status=ProcessorStatus.ERROR.value, error=str(e))
            await self.save()
            return ApiFailResponse(message=str(e))

    @action.post(action_name="resume-pty")
    async def resume_pty(self):
        """Create a NEW PTY and resume the existing Claude Code session in it.

        Requires an existing worker_session_id. The old PTY may be dead — this
        creates a fresh one and launches `claude --resume <session_id>`.

        Returns:
            ApiSuccessResponse with new pty_session_id.
        """
        if not self.worker_session_id:
            return ApiFailResponse(message="No worker_session_id to resume")

        if self.pty_session_id:
            return ApiFailResponse(message="PTY session still active. Kill it first.")

        compute_node = await self._resolve_compute_node()
        if not compute_node:
            return ApiFailResponse(message="No compute node available")

        try:
            self.pty_session_id = str(uuid4())
            self.compute_node_id = str(compute_node.typeid)

            # Build resume command
            command = build_claude_shell_command(
                worker_session_id=self.worker_session_id,
                process_type=self.get_type(),
                process_id=self.id,
                context_data=dict(self.context_data),
                resume=True,
            )

            on_exit = self._make_pty_exit_callback()
            workdir = self.context_data.get("workdir")
            session_name = f"Claude - {self.worker_session_id[:8]} (resumed)"

            logger.info(
                "AgenticProcess %s: resuming PTY session %s (worker=%s)",
                self.id,
                self.pty_session_id,
                self.worker_session_id,
            )

            ok = await compute_node.start_machine_pty_session(
                session_id=self.pty_session_id,
                rows=24,
                cols=80,
                name=session_name,
                working_dir=workdir,
                initial_command=command,
                on_exit=on_exit,
            )

            if not ok:
                self.pty_session_id = None
                return ApiFailResponse(message="Failed to create PTY session for resume")

            self._set_process_state(status=ProcessorStatus.RUNNING.value)
            await self.save()

            return ApiSuccessResponse(
                data={
                    "id": self.id,
                    "status": ProcessorStatus.RUNNING.value,
                    "pty_session_id": self.pty_session_id,
                    "worker_session_id": self.worker_session_id,
                }
            )

        except Exception as e:
            logger.exception(f"AgenticProcess {self.id} resume-pty error: {e}")
            self.pty_session_id = None
            self._set_process_state(status=ProcessorStatus.ERROR.value, error=str(e))
            await self.save()
            return ApiFailResponse(message=str(e))

    @action.post(action_name="kill-pty")
    async def kill_pty(self):
        """Kill the active PTY session.

        Sends SIGINT (Ctrl+C) to the PTY process, then closes the session.
        Preserves worker_session_id so the Claude conversation can be resumed later.

        Returns:
            ApiSuccessResponse confirming the kill.
        """
        if not self.pty_session_id:
            return ApiFailResponse(message="No active PTY session")

        compute_node = await self._resolve_compute_node()
        if not compute_node:
            return ApiFailResponse(message="No compute node available")

        try:
            provider_node_id = compute_node.verified_node_provider_id

            # Send SIGINT first
            try:
                await compute_node.compute_provider.send_pty_input(
                    provider_node_id,
                    self.pty_session_id,
                    b"\x03",  # Ctrl+C
                    cols=80,
                    rows=24,
                )
            except Exception:
                pass  # PTY may already be dead

            # Close the PTY session
            try:
                await compute_node.compute_provider.close_pty_session(
                    provider_node_id,
                    self.pty_session_id,
                )
            except Exception:
                pass  # Best effort

            old_pty = self.pty_session_id
            self.pty_session_id = None
            self._set_process_state(status=ProcessorStatus.IDLE.value)
            await self.save()

            logger.info(
                "AgenticProcess %s: killed PTY %s (worker_session_id preserved: %s)",
                self.id,
                old_pty,
                self.worker_session_id,
            )

            return ApiSuccessResponse(
                data={
                    "id": self.id,
                    "status": ProcessorStatus.IDLE.value,
                    "pty_session_id": None,
                    "worker_session_id": self.worker_session_id,
                }
            )

        except Exception as e:
            logger.exception(f"AgenticProcess {self.id} kill-pty error: {e}")
            return ApiFailResponse(message=str(e))

    # ============ Legacy Execute (headless subprocess) ============

    @action.post(action_name="execute")
    async def execute_action(self, instruction: str | None = None, worker_session_id: str | None = None):
        """Execute an instruction on this process via Claude Code CLI.

        Launches claude as a PTY session (interactive terminal). Falls back to
        headless subprocess if PTY creation fails.

        Args:
            instruction: The instruction text to execute
            worker_session_id: Optional pre-generated session ID. If not provided, one is generated.

        Returns:
            ApiSuccessResponse with RUNNING status and worker_session_id
        """
        if not instruction:
            return ApiFailResponse(message="instruction is required")

        # Try PTY path first
        result = await self.start_pty(instruction=instruction, worker_session_id=worker_session_id)
        if hasattr(result, "status") and result.status == "OK":
            return result

        # Fallback to headless subprocess
        logger.warning("AgenticProcess %s: PTY start failed, falling back to subprocess", self.id)

        state = self._get_process_state()
        if state.get("status") == ProcessorStatus.TERMINATED.value:
            return ApiFailResponse(message="Process has been terminated")

        if state.get("status") == ProcessorStatus.RUNNING.value:
            return ApiFailResponse(message="Process is already running")

        try:
            worker_session_id = worker_session_id or str(uuid4())
            self.worker_session_id = worker_session_id

            logger.info(
                f"AgenticProcess {self.id}: execute instruction "
                f"processor={self.processor_id} session={worker_session_id}: "
                f"{instruction[:80]}..."
            )
            self._set_process_state(status=ProcessorStatus.RUNNING.value)
            await self.save()

            asyncio.create_task(
                _run_claude_subprocess(
                    process_id=self.id,
                    process_type=self.get_type(),
                    instruction=instruction,
                    worker_session_id=worker_session_id,
                    context_data=dict(self.context_data),
                )
            )

            return ApiSuccessResponse(
                data={
                    "id": self.id,
                    "status": ProcessorStatus.RUNNING.value,
                    "worker_session_id": worker_session_id,
                    "instruction_executed": True,
                }
            )

        except Exception as e:
            logger.exception(f"AgenticProcess {self.id} execute error: {e}")
            self._set_process_state(status=ProcessorStatus.ERROR.value, error=str(e))
            await self.save()
            return ApiFailResponse(message=str(e))


class AgenticProcessor(Entity):
    _api_visible = True
    type: str = APIField(default="agentic_processor")

    state: dict[str, Any] = APIField(default_factory=_default_processor_state)
    active_process_id: str | None = APIField(default=None)
    queued_ui: list[dict[str, Any]] = APIField(default_factory=list)
    next_ui_index: int = APIField(default=0)
    process_seq: int = APIField(default=0)

    def _get_state(self) -> dict[str, Any]:
        if not isinstance(self.state, dict):
            self.state = _default_processor_state()
        return copy.deepcopy(self.state)

    def _set_state(self, **updates: Any) -> None:
        state = self._get_state()
        state.update(updates)
        self.state = state

    async def _sync_active_process_state(self) -> None:
        if not self.active_process_id:
            return
        process = await AgenticProcess.get_by_id(self.active_process_id)
        if not process:
            return
        process.state = self._get_state()
        await process.save()

    async def _emit_ui_process_data(self, ui_item: dict[str, Any]) -> None:
        ui_payload: dict[str, Any] = {
            "ui_id": ui_item["ui_id"],
            "params": ui_item.get("params", {}),
            "blocking": ui_item.get("blocking", True),
        }
        if ui_item.get("uri"):
            ui_payload["uri"] = ui_item["uri"]
        if ui_item.get("page"):
            ui_payload["page"] = ui_item["page"]
        if ui_item.get("content"):
            ui_payload["content"] = ui_item["content"]

        self.process_seq += 1
        attrs = {
            "element-type": "ui",
            "data-type": "object",
            "ui-id": ui_item["ui_id"],
            "i": str(self.process_seq),
            "t": _now_iso(),
        }
        message_payload = {
            "element_type": "ui",
            "data_type": "object",
            "flow_value": json.dumps(ui_payload),
            "attributes": attrs,
        }

        await _send_flow_data_message(self.get_type(), self.id, message_payload)

    async def _advance_execution(self) -> None:
        total = len(self.queued_ui)
        logger.info(f"AgenticProcessor {self.id}: advancing execution ({self.next_ui_index}/{total} items)")
        while self.next_ui_index < len(self.queued_ui):
            ui_item = self.queued_ui[self.next_ui_index]
            self.next_ui_index += 1
            logger.info(
                f"AgenticProcessor {self.id}: processing item {self.next_ui_index}/{total} "
                f"ui_id={ui_item.get('ui_id')} blocking={ui_item.get('blocking', True)}"
            )

            await self._emit_ui_process_data(ui_item)

            if ui_item.get("blocking", True):
                self._set_state(
                    status=ProcessorStatus.PAUSED.value,
                    waiting_for_input=True,
                    input_id=ui_item["ui_id"],
                    index=self.next_ui_index,
                )
                await self.save()
                await self._sync_active_process_state()
                logger.info(f"AgenticProcessor {self.id}: paused, waiting for input on {ui_item['ui_id']}")
                return

        self._set_state(
            status=ProcessorStatus.COMPLETE.value,
            waiting_for_input=False,
            input_id=None,
            index=self.next_ui_index,
        )
        await self.save()
        await self._sync_active_process_state()
        logger.info(f"AgenticProcessor {self.id}: execution complete ({total} items processed)")

    @action.post(action_name="controlStart")
    async def control_start(
        self,
        mdo_content: str | None = None,
        source_vfs_path: str | None = None,
        debug: bool = False,
        breakpoints: list[str] | None = None,
    ):
        request_info = get_current_request_info()
        owner = request_info.someone_typeid if request_info else None

        self.queued_ui = []
        self.next_ui_index = 0
        self.process_seq = 0
        self._set_state(
            status=ProcessorStatus.IDLE.value,
            index=0,
            waiting_for_input=False,
            input_id=None,
            error=None,
            mdo_content=mdo_content,
            debug={
                "enabled": bool(debug),
                "breakpoints": breakpoints or [],
                "step_mode": None,
            },
        )

        process = AgenticProcess(
            processor_id=self.id,
            instruction_content=mdo_content,
            source_vfs_path=source_vfs_path,
            state=self._get_state(),
        )
        await process.save(owner)

        self.active_process_id = process.id
        await self.save(owner)
        return ApiSuccessResponse(data=process)

    @action.post(action_name="controlAppend")
    async def control_append(self, content: str, instruction_id: str | None = None):
        if not content:
            return ApiFailResponse(message="content is required")

        parsed_items = _parse_flow_ui_items(content)
        self.queued_ui = [item.model_dump() for item in parsed_items]
        self.next_ui_index = 0
        self.process_seq = 0

        state = self._get_state()
        total_instructions = int(state.get("total_instructions", 0)) + 1
        resolved_instruction_id = instruction_id or f"instr_{uuid4().hex[:10]}"

        self._set_state(
            status=ProcessorStatus.RUNNING.value,
            total_instructions=total_instructions,
            current_instruction_id=resolved_instruction_id,
            waiting_for_input=False,
            input_id=None,
            mdo_content=content,
            index=0,
        )
        await self.save()
        await self._sync_active_process_state()

        await self._advance_execution()

        return ApiSuccessResponse(
            data={
                "instructionId": resolved_instruction_id,
                "totalInstructions": total_instructions,
            }
        )

    @action.post(action_name="controlInput")
    async def control_input(self, input_data: str | None = None, input_id: str | None = None):
        state = self._get_state()
        if not state.get("waiting_for_input", False):
            return ApiFailResponse(message="Processor not waiting for input", status_code=400)

        state_variables = dict(state.get("variables", {}))
        if input_data:
            try:
                state_variables["last_input"] = json.loads(input_data)
            except Exception:
                state_variables["last_input"] = input_data
        if input_id:
            state_variables["last_input_id"] = input_id

        self._set_state(
            status=ProcessorStatus.RUNNING.value,
            waiting_for_input=False,
            input_id=None,
            variables=state_variables,
        )
        await self.save()
        await self._sync_active_process_state()

        await self._advance_execution()
        return ApiSuccessResponse(data=True)

    @action.post(action_name="controlAbort")
    async def control_abort(self):
        self.queued_ui = []
        self.next_ui_index = 0
        self.process_seq = 0
        self._set_state(
            status=ProcessorStatus.IDLE.value,
            waiting_for_input=False,
            input_id=None,
            error=None,
        )
        await self.save()
        await self._sync_active_process_state()
        return ApiSuccessResponse(data=True)

    @action.all(action_name="controlStep")
    async def control_step(self, step_mode: str = "over"):
        """Step to next instruction in debug mode.

        Args:
            step_mode: Step mode (over, into, out)

        Returns:
            Success response on step, error if not in debug mode
        """
        state = self._get_state()
        debug = state.get("debug", {})
        if not debug.get("enabled", False):
            return ApiFailResponse(message="Debug mode not enabled")

        if state.get("status") != ProcessorStatus.STEPPING.value:
            return ApiFailResponse(message="Processor not paused at breakpoint")

        try:
            debug["step_mode"] = step_mode
            self._set_state(
                status=ProcessorStatus.RUNNING.value,
                debug=debug,
            )
            await self.save()
            await self._sync_active_process_state()

            # In desktop mode, advance execution if there are queued UI items
            await self._advance_execution()

            return ApiSuccessResponse(data={"status": self._get_state().get("status")})

        except Exception as e:
            logger.exception(f"AgenticProcessor {self.id} step error: {e}")
            self._set_state(status=ProcessorStatus.ERROR.value, error=str(e))
            await self.save()
            return ApiFailResponse(message=str(e))

    @action.all(action_name="controlContinue")
    async def control_continue(
        self,
        process_id: str | None = None,
        mdo_content: str | None = None,
        debug: bool = False,
        breakpoints: list[str] | None = None,
    ):
        """Continue a completed process with new instruction content.

        This action loads an existing completed process, appends the new
        instruction, and continues execution.

        Args:
            process_id: ID of the completed process to continue
            mdo_content: New instruction content to execute
            debug: Enable debug mode
            breakpoints: List of breakpoint IDs

        Returns:
            AgenticProcess data with updated state
        """
        state = self._get_state()
        if state.get("status") == ProcessorStatus.RUNNING.value:
            return ApiFailResponse(message="Processor is already running")

        if not process_id:
            return ApiFailResponse(message="process_id is required")
        if not mdo_content:
            return ApiFailResponse(message="mdo_content is required")

        try:
            # Load the existing process from DB
            existing_process = await AgenticProcess.get_by_id(process_id)
            if not existing_process:
                return ApiFailResponse(message=f"Process not found: {process_id}")

            # Parse UI items from the new content
            parsed_items = _parse_flow_ui_items(mdo_content)
            self.queued_ui = [item.model_dump() for item in parsed_items]
            self.next_ui_index = 0
            self.process_seq = 0

            # Reset state for new execution
            self._set_state(
                status=ProcessorStatus.RUNNING.value,
                mdo_content=mdo_content,
                debug={
                    "enabled": bool(debug),
                    "breakpoints": breakpoints or [],
                    "step_mode": None,
                },
                error=None,
                waiting_for_input=False,
                input_id=None,
            )

            self.active_process_id = existing_process.id
            await self.save()

            # Sync state to existing process
            existing_process.instruction_content = mdo_content
            existing_process.state = self._get_state()
            await existing_process.save()

            # Advance execution
            await self._advance_execution()

            return ApiSuccessResponse(
                data={
                    "id": existing_process.id,
                    "type": existing_process.type,
                    "processor_id": existing_process.processor_id,
                    "instruction_content": existing_process.instruction_content,
                    "state": existing_process.state
                    if isinstance(existing_process.state, dict)
                    else existing_process.state,
                    "worker_session_id": existing_process.worker_session_id,
                    "resumed": True,
                }
            )

        except Exception as e:
            logger.exception(f"AgenticProcessor {self.id} controlContinue error: {e}")
            self._set_state(status=ProcessorStatus.ERROR.value, error=str(e))
            await self.save()
            return ApiFailResponse(message=str(e))

    @action.all(action_name="state")
    async def get_state(self):
        """Get current processor state."""
        return ApiSuccessResponse(data=self._get_state())

    @action.all(action_name="runFile")
    async def run_file(self, vfs_path: str | None = None, debug: bool = False, breakpoints: list[str] | None = None):
        """Run an instruction file from VFS path.

        This is the primary way to execute skill files. It loads the file
        from the VFS path and executes all instructions.

        Args:
            vfs_path: VFS path to the instruction file
            debug: Enable debug mode
            breakpoints: List of breakpoint IDs

        Returns:
            AgenticProcess entity data
        """
        state = self._get_state()
        if state.get("status") == ProcessorStatus.RUNNING.value:
            return ApiFailResponse(message="Processor is already running")

        if not vfs_path:
            return ApiFailResponse(message="vfs_path is required")

        try:
            request_info = get_current_request_info()
            owner = request_info.someone_typeid if request_info else None

            # Try to load the file content via VFS/FS
            file_content = None
            try:
                from flow_sdk.api.fs_api import VFSPath

                vfs = VFSPath(vfs_path)
                # Attempt to read the file through the compute provider
                from pathlib import Path

                local_path = vfs.local_path if hasattr(vfs, "local_path") else None
                if local_path and Path(local_path).exists():
                    file_content = Path(local_path).read_text()
            except Exception as e:
                logger.warning(f"Could not load file from VFS path {vfs_path}: {e}")

            # Parse UI items if we got file content
            if file_content:
                parsed_items = _parse_flow_ui_items(file_content)
                self.queued_ui = [item.model_dump() for item in parsed_items]
            else:
                self.queued_ui = []

            self.next_ui_index = 0
            self.process_seq = 0

            self._set_state(
                status=ProcessorStatus.RUNNING.value,
                mdo_content=file_content or "",
                debug={
                    "enabled": bool(debug),
                    "breakpoints": breakpoints or [],
                    "step_mode": None,
                },
                error=None,
                index=0,
                waiting_for_input=False,
                input_id=None,
            )

            # Create process entity
            process = AgenticProcess(
                processor_id=self.id,
                instruction_content=file_content or "",
                source_vfs_path=vfs_path,
                state=self._get_state(),
            )
            await process.save(owner)

            self.active_process_id = process.id
            await self.save(owner)

            # Advance execution
            await self._advance_execution()

            return ApiSuccessResponse(
                data={
                    "id": process.id,
                    "type": process.type,
                    "processor_id": process.processor_id,
                    "instruction_content": process.instruction_content,
                    "source_vfs_path": process.source_vfs_path,
                    "state": process.state if isinstance(process.state, dict) else process.state,
                }
            )

        except FileNotFoundError:
            logger.error(f"AgenticProcessor {self.id} file not found: {vfs_path}")
            return ApiFailResponse(message=f"File not found: {vfs_path}")

        except Exception as e:
            logger.exception(f"AgenticProcessor {self.id} runFile error: {e}")
            self._set_state(status=ProcessorStatus.ERROR.value, error=str(e))
            await self.save()
            return ApiFailResponse(message=str(e))

    @action.all(action_name="run")
    async def run(
        self,
        instruction_content: str | None = None,
        context: dict[str, Any] | None = None,
        debug: bool = False,
        breakpoints: list[str] | None = None,
    ):
        """Run instruction content with context - returns AgenticProcess.

        This is the primary interface for the TypeScript SDK's processor.run() method.
        Creates an AgenticProcess, starts execution, and returns the entity data.

        Args:
            instruction_content: The instruction/AMD content to execute
            context: Context data (workdir, env_vars, model, etc.)
            debug: Enable debug mode
            breakpoints: List of breakpoint IDs

        Returns:
            AgenticProcess data (id, type, state, etc.)
        """
        state = self._get_state()
        if state.get("status") == ProcessorStatus.RUNNING.value:
            return ApiFailResponse(message="Processor is already running")

        if not instruction_content:
            return ApiFailResponse(message="instruction_content is required")

        logger.info(f"AgenticProcessor {self.id}: run started, content_len={len(instruction_content)}, debug={debug}")
        try:
            request_info = get_current_request_info()
            owner = request_info.someone_typeid if request_info else None

            context_data = context or {}

            # Parse UI items from instruction content
            parsed_items = _parse_flow_ui_items(instruction_content)
            self.queued_ui = [item.model_dump() for item in parsed_items]
            self.next_ui_index = 0
            self.process_seq = 0

            self._set_state(
                status=ProcessorStatus.RUNNING.value,
                mdo_content=instruction_content,
                debug={
                    "enabled": bool(debug),
                    "breakpoints": breakpoints or [],
                    "step_mode": None,
                },
                error=None,
                index=0,
                waiting_for_input=False,
                input_id=None,
            )

            # Create process entity
            process = AgenticProcess(
                processor_id=self.id,
                instruction_content=instruction_content,
                context_data=context_data,
                state=self._get_state(),
            )
            await process.save(owner)
            logger.info(f"AgenticProcessor {self.id}: created process {process.id}")

            self.active_process_id = process.id
            await self.save(owner)

            # Advance execution
            await self._advance_execution()

            logger.info(
                f"AgenticProcessor {self.id}: run finished, process={process.id} state={self._get_state().get('status')}"
            )
            return ApiSuccessResponse(
                data={
                    "id": process.id,
                    "type": process.type,
                    "processor_id": process.processor_id,
                    "instruction_content": process.instruction_content,
                    "context": process.context_data,
                    "state": process.state if isinstance(process.state, dict) else process.state,
                }
            )

        except Exception as e:
            logger.exception(f"AgenticProcessor {self.id} run error: {e}")
            self._set_state(status=ProcessorStatus.ERROR.value, error=str(e))
            await self.save()
            return ApiFailResponse(message=str(e))

    @action.all(action_name="execute")
    async def execute(
        self,
        instruction_content: str | None = None,
        context: dict[str, Any] | None = None,
        debug: bool = False,
        breakpoints: list[str] | None = None,
    ):
        """Execute instruction content directly (no file parsing) - returns AgenticProcess.

        This is a simpler API than run() that takes instruction text directly.

        Args:
            instruction_content: Plain text or AMD instruction content
            context: Context data (workdir, env_vars, model, etc.)
            debug: Enable debug mode
            breakpoints: List of breakpoint IDs

        Returns:
            AgenticProcess data (id, type, state, etc.)
        """
        state = self._get_state()
        if state.get("status") == ProcessorStatus.RUNNING.value:
            return ApiFailResponse(message="Processor is already running")

        if not instruction_content:
            return ApiFailResponse(message="instruction_content is required")

        logger.info(
            f"AgenticProcessor {self.id}: execute started, content_len={len(instruction_content)}, debug={debug}"
        )
        try:
            request_info = get_current_request_info()
            owner = request_info.someone_typeid if request_info else None

            context_data = context or {}

            # Parse UI items from instruction content
            parsed_items = _parse_flow_ui_items(instruction_content)
            self.queued_ui = [item.model_dump() for item in parsed_items]
            self.next_ui_index = 0
            self.process_seq = 0

            self._set_state(
                status=ProcessorStatus.RUNNING.value,
                mdo_content=instruction_content,
                debug={
                    "enabled": bool(debug),
                    "breakpoints": breakpoints or [],
                    "step_mode": None,
                },
                error=None,
                index=0,
                waiting_for_input=False,
                input_id=None,
            )

            # Create process entity
            process = AgenticProcess(
                processor_id=self.id,
                instruction_content=instruction_content,
                context_data=context_data,
                state=self._get_state(),
            )
            await process.save(owner)
            logger.info(f"AgenticProcessor {self.id}: created process {process.id}")

            self.active_process_id = process.id
            await self.save(owner)

            # Advance execution
            await self._advance_execution()

            logger.info(
                f"AgenticProcessor {self.id}: execute finished, process={process.id} state={self._get_state().get('status')}"
            )
            return ApiSuccessResponse(
                data={
                    "id": process.id,
                    "type": process.type,
                    "processor_id": process.processor_id,
                    "instruction_content": process.instruction_content,
                    "context": process.context_data,
                    "state": process.state if isinstance(process.state, dict) else process.state,
                }
            )

        except Exception as e:
            logger.exception(f"AgenticProcessor {self.id} execute error: {e}")
            self._set_state(status=ProcessorStatus.ERROR.value, error=str(e))
            await self.save()
            return ApiFailResponse(message=str(e))

    @action.all(action_name="createProcess")
    async def create_process(
        self,
        context: dict[str, Any] | None = None,
        result: dict[str, Any] | None = None,
    ):
        """Create a new idle process ready for execute() calls.

        This creates a process in IDLE status that can accept instructions
        via the process.execute() action. The process stays alive until
        explicitly terminated via process.exit().

        Args:
            context: Context data (workdir, env_vars, model, etc.)
            result: Optional ProcessResult metadata

        Returns:
            AgenticProcess entity data in IDLE status
        """
        try:
            request_info = get_current_request_info()
            owner = request_info.someone_typeid if request_info else None

            context_data = context or {}

            # Create process in IDLE state
            idle_state = _default_processor_state()
            idle_state["status"] = ProcessorStatus.IDLE.value

            process = AgenticProcess(
                processor_id=self.id,
                instruction_content="",
                context_data=context_data,
                state=idle_state,
            )
            await process.save(owner)

            # Handle ProcessResult creation if requested
            if result and isinstance(result, dict):
                try:
                    from flow_sdk.builtin.process_result import ProcessResult

                    result_uname = result.get("uname")
                    existing_result = None
                    if result_uname:
                        existing_result = await ProcessResult.get_by_uname(result_uname)

                    if existing_result:
                        existing_result.process_id = process.id
                        existing_result.status = "running"
                        existing_result.result_type = result.get("result_type")
                        existing_result.source_session_id = result.get("source_session_id")
                        await existing_result.save(owner)
                    else:
                        process_result = ProcessResult(
                            uname=result_uname,
                            process_id=process.id,
                            status="running",
                            result_type=result.get("result_type"),
                            source_session_id=result.get("source_session_id"),
                        )
                        await process_result.save(owner)
                except ImportError:
                    logger.debug("ProcessResult entity not available, skipping result creation")

            self.active_process_id = process.id
            await self.save(owner)

            logger.info(f"AgenticProcessor {self.id} created process {process.id} in IDLE status")

            return ApiSuccessResponse(
                data={
                    "id": process.id,
                    "type": process.type,
                    "processor_id": process.processor_id,
                    "state": process.state if isinstance(process.state, dict) else process.state,
                }
            )

        except Exception as e:
            logger.exception(f"AgenticProcessor {self.id} createProcess error: {e}")
            return ApiFailResponse(message=str(e))


class APU(Entity):
    """Compatibility factory endpoint used by API tests.

    POST /graph/apu creates an `agentic_processor` and returns `{type:'apu', id}`.
    """

    _api_visible = True
    type: str = APIField(default="apu")

    @action.post(action_name="create")
    async def create(cls):
        request_info = get_current_request_info()
        owner = request_info.someone_typeid if request_info else None

        processor = AgenticProcessor()
        await processor.save(owner)
        return ApiSuccessResponse(data={"type": "apu", "id": processor.id})


__all__ = [
    "ProcessorStatus",
    "StackFrame",
    "DebugState",
    "ProcessorState",
    "AgenticContext",
    "AgenticProcess",
    "AgenticProcessor",
    "APU",
    "ContextData",
    "ControlStartRequest",
    "ControlInputRequest",
    "ControlStepRequest",
    "ControlAppendRequest",
    "ControlContinueRequest",
    "RunFileRequest",
    "RunRequest",
    "ExecuteRequest",
    "CreateProcessRequest",
    "ProcessResultRequest",
]
