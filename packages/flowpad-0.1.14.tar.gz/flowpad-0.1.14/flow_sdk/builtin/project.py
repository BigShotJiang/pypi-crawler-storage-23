import logging
import os
import sys
from typing import ClassVar, List

from fastapi import HTTPException
from pydantic import ConfigDict, Field, model_validator
from pydantic.alias_generators import to_camel

from flow_sdk.config import AGENT_MOUNT_FOLDER, PLATFORM_WIN32, StorageProvider
from flow_sdk.flowpad_types.enums import AuthRole
from flow_sdk.api.api_types.api_field import APIField
from flow_sdk.api.type_id import TypeId
from flow_sdk.builtin.faas.compute_node import ComputeNode
from flow_sdk.builtin.worker_sessions import get_worker_sessions
from flow_sdk.core import Entity, QueryFilter, action
from flow_sdk.db.drivers.db_base_record import BuiltinEntityType
from flow_sdk.core.flow.flow_source_control import ComputeSourceControlInitializeOptions
from flow_sdk.core.flow.mcp_server import MCPConnector, mcp_connector_pool
from flow_sdk.core.flow.models.execution.env_context import get_env_vars_context
from flow_sdk.request_context.methods import (
    get_current_request_info,
    get_current_service,
)
from flow_sdk.responses.response import ApiSuccessResponse


class ProjectInitializeOptions(ComputeSourceControlInitializeOptions):
    model_config = ConfigDict(alias_generator=to_camel, validate_by_name=True)

    mcp_connector_init: bool = Field(default=True)


class Project(Entity):
    type: str = APIField(default=BuiltinEntityType.PROJECT.value)
    name: str | None = APIField(default=None, description="Display name of the project")
    artifacts: List[str] = APIField(
        default_factory=list,
        description="List of artifact IDs belonging to this project",
    )
    fs_storage_provider: StorageProvider | None = StorageProvider.SANDBOX
    fs_storage_mount_path: str | None = APIField(
        default=None, description="Full path to the project folder"
    )
    _api_visible: ClassVar[bool] = True

    @model_validator(mode="after")
    def set_fs_storage_mount_path(self):
        """Set the storage mount path based on project name and create the folder if needed."""
        if self.name and not self.fs_storage_mount_path:
            if os.path.isabs(self.name):
                # Name is an absolute path - use it directly as mount path
                self.fs_storage_mount_path = self.name
                self.name = os.path.basename(self.name)
            elif "/" in self.name or "\\" in self.name:
                # Name is a VFS-relative path - convert to absolute OS path
                # VFS root maps to OS root ("/" on Unix, "C:\" on Windows)
                if sys.platform == PLATFORM_WIN32:
                    drive = os.path.splitdrive(AGENT_MOUNT_FOLDER)[0]
                    os_root = drive + os.sep
                else:
                    os_root = os.sep
                self.fs_storage_mount_path = os.path.normpath(
                    os.path.join(os_root, self.name)
                )
                self.name = os.path.basename(self.fs_storage_mount_path)
            else:
                # Simple name like "my_first_project"
                self.fs_storage_mount_path = os.path.join(AGENT_MOUNT_FOLDER, self.name)

        # Prevent project mount path from being the user's home directory.
        home_dir = os.path.expanduser("~").rstrip(os.sep)
        if (
            self.fs_storage_mount_path
            and self.fs_storage_mount_path.rstrip(os.sep) == home_dir
        ):
            self.fs_storage_mount_path = os.path.join(
                AGENT_MOUNT_FOLDER, self.name or "home"
            )

        # Create the project folder if it doesn't exist
        if self.fs_storage_mount_path and not os.path.exists(
            self.fs_storage_mount_path
        ):
            os.makedirs(self.fs_storage_mount_path, exist_ok=True)
        return self

    async def get_compute_node(self):
        from flow_sdk.config import default_service_config

        # In desktop/local mode, always use the @local compute node
        if default_service_config.is_local:
            project_compute_nodes = await ComputeNode.get_all(source_entity=self.typeid)
            if project_compute_nodes:
                logging.warning(
                    f"Found {len(project_compute_nodes)} compute nodes on desktop env"
                )
            return await ComputeNode.get_by_uname("local")

        project_compute_nodes = await ComputeNode.get_all(source_entity=self.typeid)
        if project_compute_nodes:
            if len(project_compute_nodes) > 1:
                logging.warning(
                    f"Multiple compute nodes found for project {self.typeid}"
                )
                project_compute_nodes = list(
                    sorted(
                        project_compute_nodes,
                        key=lambda x: x.created_date or 0,
                        reverse=True,
                    )
                )
            return project_compute_nodes[0]
        return None

    async def get_mcp_connector(self):
        project_compute_node = await self.get_compute_node()
        if project_compute_node:
            return MCPConnector(compute_node=project_compute_node)
        warm_mcp_connector = await mcp_connector_pool.get_warm_mcp_connector()
        # Ensure compute_node exists in DB before creating relationship
        # Note: The pool's compute_node might think it exists in DB (created_by set from previous save)
        # but the DB may have been reset. Force-check and save if needed.
        compute_node = warm_mcp_connector.compute_node
        db_compute_node = await ComputeNode.get_by_id(compute_node.id)
        if not db_compute_node:
            # Node doesn't actually exist in DB - clear created_by to force save
            compute_node.created_by = None
            await compute_node.save()
        await self.add_child(compute_node)
        return warm_mcp_connector

    @classmethod
    async def get_mcp_connector_for_process(cls, process_typeid: TypeId):
        compute_node = await ComputeNode.get_one(source_entity=process_typeid)
        if compute_node:
            return MCPConnector(compute_node=compute_node)

        project = await cls.get_ancestor(process_typeid)
        if not project:
            logging.warning(
                f"No project or compute node found for process {process_typeid}"
            )
            new_project = cls()
            await new_project.save()
            await new_project.attach_child(process_typeid)
            project = new_project
        return await project.get_mcp_connector()

    @classmethod
    async def get_mcp_connector_for_flow(cls, flow_typeid: TypeId):
        """Backward-compatible alias for get_mcp_connector_for_process."""
        return await cls.get_mcp_connector_for_process(flow_typeid)

    @action.post(action_name="initialize")
    async def initialize(
        self, initialize_options: ProjectInitializeOptions | None = None
    ):
        if not initialize_options:
            initialize_options = ProjectInitializeOptions()

        mcp_connector = await self.get_mcp_connector()
        if initialize_options.mcp_connector_init:
            process_env_list = await get_env_vars_context(
                get_current_request_info().user, self
            )
            async with mcp_connector.initialize(initialize_options, process_env_list):
                pass

        compute_node = await self.get_compute_node()
        return ApiSuccessResponse(
            data={"compute_node": compute_node.model_dump() if compute_node else None}
        )

    async def _create_process_impl(
        self,
        process_id: str = "",
        agent_id: str | None = None,
        source_vfs_path: str | None = None,
    ):
        request_info = get_current_request_info()
        if not request_info:
            raise HTTPException(
                status_code=401, detail="Unauthorized: request info required"
            )

        from flow_sdk.builtin.agent import Agent
        from flow_sdk.builtin.process import Flow

        someone = await request_info.someone()
        if not someone or not someone.id:
            raise HTTPException(
                status_code=401, detail="Unauthorized: user or visitor required"
            )

        if not agent_id:
            raise HTTPException(
                status_code=400, detail="Agent ID is required to create flow"
            )

        # Handle both UUIDs and unames (e.g., "@local" -> "local")
        if agent_id.startswith("@"):
            uname = agent_id[1:]  # Remove the @ prefix
            agent = await Agent.get_by_uname(uname)
        else:
            agent = await Agent.get_by_id(agent_id)
        if not agent:
            raise HTTPException(status_code=404, detail="Agent not found")

        # Check if user or visitor is allowed to use this agent for completion
        service = get_current_service()
        if not service:
            raise HTTPException(status_code=500, detail="Service not available")

        is_allowed = await service.authorizer.is_allowed_action(
            agent.typeid, "completion"
        )
        if not is_allowed:
            raise HTTPException(
                status_code=403,
                detail="User or visitor not allowed to use agent for completion",
            )

        # Create the process entity with resolved agent ID (not uname), project_id, and optional source_vfs_path
        # noinspection PyArgumentList
        new_process = Flow(
            id=process_id,
            agent_id=agent.id,
            project_id=self.id,
            source_vfs_path=source_vfs_path,
        )
        await self.add_child(new_process)
        # Set visitor role for the process if the request is from a visitor
        is_visitor = (
            request_info.someone_typeid
            and request_info.someone_typeid.type == BuiltinEntityType.VISITOR.value
        )
        if is_visitor:
            await new_process.set_visitor_role(AuthRole.ANONYMOUS_VIEWER.value.lower())

        # Preemptively give process editor role on project compute node - also done on first completion
        compute_node = await self.get_compute_node()
        if compute_node:
            await compute_node.grant_role(
                new_process.typeid, to_role=AuthRole.EDITOR.value.lower()
            )
            if is_visitor:  # and self.visitor_role:
                await compute_node.set_visitor_role(
                    AuthRole.ANONYMOUS_VIEWER.value.lower()
                )

        return ApiSuccessResponse(data=new_process)

    @action.post(action_name="create-process")
    async def create_process(
        self,
        process_id: str = "",
        agent_id: str | None = None,
        source_vfs_path: str | None = None,
    ):
        return await self._create_process_impl(
            process_id=process_id,
            agent_id=agent_id,
            source_vfs_path=source_vfs_path,
        )

    @action.post(action_name="create-flow")
    async def create_flow(
        self,
        flow_id: str = "",
        agent_id: str | None = None,
        source_vfs_path: str | None = None,
    ):
        """Backward-compatible alias for create_process."""
        return await self._create_process_impl(
            process_id=flow_id,
            agent_id=agent_id,
            source_vfs_path=source_vfs_path,
        )

    async def _get_process_by_source_impl(self, source_vfs_path: str):
        """Find an existing process entity associated with the given source file path."""
        from flow_sdk.builtin.process import Flow

        if not source_vfs_path:
            raise HTTPException(status_code=400, detail="source_vfs_path is required")

        # Query all child process entities of this project
        process_filter = QueryFilter.by_type(Flow.get_type())
        child_processes = await self.get_children(child_filter=process_filter)

        # Find the process with matching source_vfs_path
        for child in child_processes:
            process_entity = child.value
            if (
                isinstance(process_entity, Flow)
                and process_entity.source_vfs_path == source_vfs_path
            ):
                return ApiSuccessResponse(data=process_entity)

        # No process found with this source path
        return ApiSuccessResponse(data=None)

    @action.get(action_name="get-process-by-source")
    async def get_process_by_source(self, source_vfs_path: str):
        return await self._get_process_by_source_impl(source_vfs_path)

    @action.get(action_name="get-flow-by-source")
    async def get_flow_by_source(self, source_vfs_path: str):
        """Backward-compatible alias for get_process_by_source."""
        return await self._get_process_by_source_impl(source_vfs_path)

    @action.get(action_name="get-compute-node")
    async def get_compute_node_action(self):
        # Use the same query as the entity method (source_entity relationship)
        compute_node = await self.get_compute_node()
        return ApiSuccessResponse(
            data={"compute_node": compute_node.model_dump() if compute_node else None}
        )

    @action.get(action_name="get-worker-sessions")
    async def _get_worker_sessions_action(self):
        """Get worker sessions for current directory."""
        sessions = get_worker_sessions()
        return ApiSuccessResponse(data=sessions)

    @action.post(action_name="setup-for-desktop")
    async def setup_for_desktop(self):
        """Connect project to desktop entities (workspace, agent, compute node).

        This action links the project to the @local workspace, @local agent, and @local compute node
        that were created during desktop bootstrap. Should be called after creating/opening a project
        in desktop mode.

        Returns:
            ApiSuccessResponse with workspace, agent, and compute_node entities
        """
        from flow_sdk.builtin.agent import Agent
        from flow_sdk.builtin.workspace import Workspace

        # Get the @local workspace
        local_workspace = await Workspace.get_by_uname("local")
        if local_workspace:
            # Add project as child of workspace
            await local_workspace.attach_child(self.typeid)
            logging.info(
                f"Connected project {self.id} to @local workspace {local_workspace.id}"
            )

        # Get the @local agent
        local_agent = await Agent.get_by_uname("local")
        if local_agent:
            # Add agent as child of project
            await self.attach_child(local_agent.typeid)
            logging.info(
                f"Connected @local agent {local_agent.id} to project {self.id}"
            )

        # Get the @local compute node
        local_compute_node = await ComputeNode.get_by_uname("local")
        if local_compute_node:
            # Add compute node as child of project
            await self.attach_child(local_compute_node.typeid)
            logging.info(
                f"Connected @local compute node {local_compute_node.id} to project {self.id}"
            )

        return ApiSuccessResponse(
            data={
                "workspace": local_workspace.model_dump() if local_workspace else None,
                "agent": local_agent.model_dump() if local_agent else None,
                "compute_node": local_compute_node.model_dump()
                if local_compute_node
                else None,
            }
        )
