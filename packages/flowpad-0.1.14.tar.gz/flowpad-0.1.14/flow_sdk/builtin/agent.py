import asyncio
import logging
from datetime import date
from enum import Enum
from typing import Any, ClassVar, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from flow_sdk.flowpad_types.enums import WorkerType
from flow_sdk.api.api_types.api_field import APIField, NoDbBField
from flow_sdk.builtin.knowledge_base import KnowledgeBase, KnowledgeData
from flow_sdk.builtin.page import Page
from flow_sdk.builtin.site_config import SiteConfig
from flow_sdk.db.drivers.db_base_record import BuiltinEntityType
from flow_sdk.core.entity.entity_model import Entity
from flow_sdk.core.flow.tools import SearchConfig
from .knowledge_engine.ontology import Ontology
from .types.runtime_environment import ComputeNodeSize

# KnowledgeBaseAccessor imported in method to avoid circular import


class CheckpointMode(str, Enum):
    OFF = "off"
    APPROVE = "approve"
    AUTO = "auto"


class LLMConfig(BaseModel):
    model: Literal["anthropic/claude-sonnet-4.5", "openai/gpt-5"] | None = Field(default=None)


class AgentConfig(BaseModel):
    search: SearchConfig = Field(default_factory=SearchConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    checkpoint_mode: CheckpointMode = Field(default=CheckpointMode.AUTO)
    worker_type: WorkerType = Field(default=WorkerType.AUTO)
    planning_enabled: bool = Field(default=False)
    execution_enabled: bool = Field(default=True)
    machine_size: ComputeNodeSize = Field(default=ComputeNodeSize.SMALL)


def _instruction_chunk_to_dict(chunk: Any) -> Dict[str, Any]:
    """Convert knowledge entry to dictionary format."""
    return {
        "id": chunk.id,
        "content": chunk.content,
        "labels": chunk.labels,
        "entry_type": chunk.entry_type,
        "section_labels": getattr(chunk, "section_labels", []),
        "priority": getattr(chunk, "priority", 1),
        "keywords": getattr(chunk, "keywords", []),
    }


class Agent(Entity):
    type: str = APIField(default=BuiltinEntityType.AGENT.value)
    name: str | None = APIField(default=None)
    site_config: SiteConfig | None = APIField(default=None)
    agent_config: AgentConfig = APIField(default_factory=AgentConfig)
    _anonymous_user_id = "anonymous"
    histogram: dict[str, dict[date, int]] = APIField(default_factory=dict)
    enabled: bool = APIField(default=True)
    _instructions: str | None = None
    _knowledge_base: KnowledgeBase | None = None
    loaded_kbps: list[KnowledgeData] = NoDbBField(default_factory=list)
    _api_visible: ClassVar[bool] = True
    _initialized: bool = False
    # TODO shall we take it out to a separate entity to avoid contamination?
    slack_channel_id: str | None = APIField(default=None)

    def add_user_activity(self, activity_date: date, user_id: str | None = None):
        if user_id is None:
            user_id = self._anonymous_user_id
        if user_id not in self.histogram:
            self.histogram[user_id] = {}
        date_key = activity_date.isoformat()
        self.histogram[user_id][date_key] = self.histogram[user_id].get(date_key, 0) + 1

    @property
    def instructions(self) -> str:
        if self._initialized is None:
            raise ValueError("Agent instructions not initialized. Call initialize() first.")

        # Try to get instructions from knowledge_data first
        if self._knowledge_base and self._knowledge_base.knowledge_data:
            knowledge_data = self._knowledge_base.knowledge_data
            # Look for instruction entry with name="user_instructions"
            for entry in knowledge_data.entries:
                if getattr(entry, "name", None) == "user_instructions" and hasattr(entry, "content"):
                    return entry.content

        # Fallback to _instructions if set
        if self._instructions is not None:
            return self._instructions

        return ""

    @property
    def knowledge_base(self) -> KnowledgeBase:
        if self._initialized is None:
            raise ValueError("Knowledge base not initialized. Call initialize() first.")
        assert self._knowledge_base is not None
        return self._knowledge_base

    @property
    def ontology(self) -> Optional[Ontology]:
        """Get ontology from agent's knowledge base."""
        return self._get_ontology()

    async def __aenter__(self):
        await self.initialize()
        return self

    async def __aexit__(self, exc_type, exc_value, traceback):
        pass

    async def initialize(self):
        if not self._initialized:
            self._initialized = True

            # Only initialize knowledge base if not already set (e.g., via set_knowledge_data)
            if not self._knowledge_base:
                logging.info("Agent knowledge base not initialized. Initializing from knowledge bases.")
                # 1. Load knowledge bases from database
                knowledge_bases: List[KnowledgeBase] = await KnowledgeBase.get_children_sub_tree_of_source(
                    source_entity=self.typeid
                )
                await asyncio.gather(*[kb.expand_blobs() for kb in knowledge_bases])
                # Filter out knowledge bases that don't have raw_knowledge after expansion
                valid_knowledge_bases = [kb for kb in knowledge_bases if kb.raw_knowledge]
                logging.info(f"After filtering, {len(valid_knowledge_bases)} valid knowledge bases remain")

                # 2. Initialize knowledge base
                if valid_knowledge_bases:
                    # Merge knowledge bases from database
                    self._knowledge_base = KnowledgeBase.from_knowledge_bases(valid_knowledge_bases)
                else:
                    # No database knowledge bases, start with empty one
                    self._knowledge_base = KnowledgeBase()

            # 3. Load any pre-existing KBPs
            if self.loaded_kbps:
                logging.info(f"Loading {len(self.loaded_kbps)} pre-existing KnowledgeData objects")
                for kbp in self.loaded_kbps:
                    await self._add_kbp_to_knowledge_base(kbp)

            # 4. Validate index if we have knowledge base
            if self._knowledge_base:
                await self._knowledge_base.validate_index()

        if not self._instructions:
            logging.info("Agent instructions not initialized. Fetching from page.")
            self._instructions = await self._get_instructions()
        return self

    async def _add_kbp_to_knowledge_base(self, kbp: KnowledgeData):
        """Add a KnowledgeData object to the existing knowledge base."""
        if self._knowledge_base is None:
            # If no knowledge base exists, create one
            kb = KnowledgeBase()
            kb.knowledge_data = kbp
            self._knowledge_base = kb
        else:
            # Merge with existing knowledge base
            kb_to_add = KnowledgeBase()
            kb_to_add.knowledge_data = kbp
            self._knowledge_base = KnowledgeBase.from_knowledge_bases([self._knowledge_base, kb_to_add])

    async def load_kbp(self, kbp: KnowledgeData):
        """Load a KnowledgeData into the agent's knowledge base.

        This is a straightforward method that:
        1. Adds the KBP to the loaded_kbps list for tracking
        2. If agent is initialized, adds it directly to the knowledge base
        3. If not initialized, it will be loaded during initialize()

        Args:
            kbp: KnowledgeData object to load
        """
        self.loaded_kbps.append(kbp)

        # If already initialized, add directly to knowledge base
        if self._knowledge_base is not None:
            logging.info("Adding KBP to existing knowledge base")
            await self._add_kbp_to_knowledge_base(kbp)
            # Re-validate index after adding new knowledge
            await self._knowledge_base.validate_index()

    def set_knowledge_data(self, knowledge_data: KnowledgeData):
        """Set agent knowledge data directly (mainly for testing).

        This creates a knowledge base with the provided knowledge data.
        Instructions will be extracted from entries with name="user_instructions".

        Args:
            knowledge_data: The KnowledgeData object containing instructions
        """
        kb = KnowledgeBase()
        kb.knowledge_data = knowledge_data
        self._knowledge_base = kb

    async def _get_instructions(self):
        # TODO [FLOWPAD-878] find better way to get instructions to agent
        try:
            dependencies = await self.get_dependencies()
            child_pages_typeids = [dep for dep in dependencies if dep.type == Page.get_type()]
            child_pages = await asyncio.gather(
                *[Page.get_by_typeid(page_typeid) for page_typeid in child_pages_typeids]
            )
            child_pages = [page for page in child_pages if page is not None]
            instructions_pages = [page for page in child_pages if page.tags and "instructions" in page.tags]
            await asyncio.gather(*[page.expand_blobs() for page in instructions_pages])
            return "\n\n".join([page.markdown_content for page in instructions_pages])
        except Exception:
            return ""

    def _get_ontology(self) -> Optional[Ontology]:
        """Extract ontology from agent's knowledge base."""
        try:
            if not self._knowledge_base:
                return None

            # Use knowledge base's ontology manager's data property
            return self._knowledge_base.ontology.data

        except Exception as e:
            logging.warning(f"Could not extract ontology: {e}")
            return None

    def _get_ontology_labels(self) -> List[str]:
        """Extract ontology labels from agent's knowledge base."""
        try:
            if self.ontology and hasattr(self.ontology, "labels"):
                return [label_info.label for label_info in self.ontology.labels.values()]

            # Fallback: extract from entries
            knowledge_data = self.knowledge_data
            if knowledge_data and hasattr(knowledge_data, "entries"):
                all_labels = set()
                for entry in knowledge_data.entries:
                    if hasattr(entry, "labels"):
                        all_labels.update(entry.labels)
                return list(all_labels)

            return []
        except Exception as e:
            logging.warning(f"Could not extract ontology labels: {e}")
            return []

    @property
    def knowledge_data(self) -> KnowledgeData | None:
        if not self._knowledge_base:
            return None
        kb = self._knowledge_base
        return kb.knowledge_data

    def _query_instruction_chunks(self, keywords: List[str]) -> List[Any]:
        """Query knowledge data for instruction chunks matching keywords."""
        try:
            knowledge_data = self.knowledge_data
            if not knowledge_data:
                return []

            # Use get_entries_by_labels method if available
            if hasattr(knowledge_data, "get_entries_by_labels"):
                matches = knowledge_data.get_entries_by_labels(keywords)

                # Filter for instruction entries
                instruction_matches = [entry for entry in matches if getattr(entry, "entry_type", "") == "instruction"]

                logging.info(f"Found {len(instruction_matches)} instruction matches for keywords: {keywords}")
                return instruction_matches

            return []

        except Exception as e:
            logging.warning(f"Could not query instruction chunks: {e}")
            return []

    def extract_instruction_guidance(self, keywords: List[str]) -> str:
        """Extract formatted instruction guidance from knowledge base."""
        instruction_chunks = self._query_instruction_chunks(keywords)

        if not instruction_chunks:
            return ""

        # Sort by priority if available
        sorted_chunks = sorted(instruction_chunks, key=lambda x: getattr(x, "priority", 1), reverse=True)

        # Format as bullet points
        guidance_lines = []
        for chunk in sorted_chunks[:5]:  # Limit to top 5
            guidance_lines.append(f"- {chunk.content}")

        return "\n".join(guidance_lines)
