"""Optional utilities for working with KSeF data structures."""

from ksef2.utils.packages import PackageReader

__all__ = [
    "PackageReader",
]
