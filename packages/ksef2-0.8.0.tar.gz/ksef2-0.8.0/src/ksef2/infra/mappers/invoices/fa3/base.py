"""Base mappers for FA3 invoice schema to domain models."""
