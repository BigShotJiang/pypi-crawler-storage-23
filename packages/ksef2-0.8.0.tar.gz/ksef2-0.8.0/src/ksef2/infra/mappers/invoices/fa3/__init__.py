"""FA3 invoice mappers."""

from ksef2.infra.mappers.invoices.fa3.attachment import AttachmentMapper

__all__ = [
    "AttachmentMapper",
]
