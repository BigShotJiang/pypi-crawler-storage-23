"""
Scripts module for synthyverse setup utilities.
"""

