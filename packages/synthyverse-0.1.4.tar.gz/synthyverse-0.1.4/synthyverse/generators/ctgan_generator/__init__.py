from .ct_gan import CTGANGenerator
