from .tabargn import TabARGNGenerator
