from .synth_pop import SynthpopGenerator
