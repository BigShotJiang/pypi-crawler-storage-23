from .permutation import PermutationGenerator
