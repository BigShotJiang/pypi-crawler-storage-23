from .ctab_gan import CTABGANGenerator
