from .tabsyn import TabSynGenerator
