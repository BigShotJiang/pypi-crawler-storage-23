from .nrg_boost import NRGBoostGenerator
