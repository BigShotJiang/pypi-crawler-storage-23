try:
    from .synthesis import TabularSynthesisBenchmark
except:
    TabularSynthesisBenchmark = None
