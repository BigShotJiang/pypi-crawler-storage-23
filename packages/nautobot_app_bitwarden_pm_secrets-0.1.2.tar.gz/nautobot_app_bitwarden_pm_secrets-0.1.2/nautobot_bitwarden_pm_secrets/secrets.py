# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

"""Bitwarden Password Manager secrets provider for Nautobot."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import requests
from django import forms
from django.conf import settings
from nautobot.apps.forms import BootstrapMixin
from nautobot.apps.secrets import SecretsProvider
from nautobot.extras.secrets.exceptions import SecretParametersError, SecretProviderError, SecretValueNotFoundError

if TYPE_CHECKING:
    from django.db import models as django_models
    from nautobot.extras.models import Secret

SECRET_FIELD_CHOICES = (
    ("username", "Username"),
    ("password", "Password"),
    ("totp", "TOTP (Current Code)"),
    ("uri", "URI (first)"),
    ("notes", "Notes"),
    ("custom_field", "Custom Field"),
)


class BitwardenPasswordManagerSecretsProvider(SecretsProvider):
    """A secrets provider for Bitwarden Password Manager using the bw serve REST API."""

    slug = "bitwarden-password-manager"
    name = "Bitwarden Password Manager"

    class ParametersForm(BootstrapMixin, forms.Form):
        """Form for defining the parameters needed to retrieve a secret from Bitwarden."""

        item_id = forms.CharField(
            required=True,
            help_text="The Bitwarden vault item ID (GUID).",
        )
        secret_field = forms.ChoiceField(
            choices=SECRET_FIELD_CHOICES,
            required=True,
            help_text="The field to retrieve from the vault item.",
        )
        custom_field_name = forms.CharField(
            required=False,
            help_text="The name of the custom field to retrieve (required when Secret Field is 'Custom Field').",
        )

        def clean(self) -> dict[str, Any]:
            cleaned_data = super().clean()
            secret_field = cleaned_data.get("secret_field")
            custom_field_name = cleaned_data.get("custom_field_name")

            if secret_field == "custom_field" and not custom_field_name:
                raise forms.ValidationError(
                    {"custom_field_name": "Custom Field Name is required when Secret Field is 'Custom Field'."}
                )

            return cleaned_data

    @classmethod
    def get_value_for_secret(cls, secret: Secret, obj: django_models.Model | None = None, **kwargs: Any) -> str:
        """Retrieve a secret value from Bitwarden Password Manager via the bw serve REST API."""
        parameters = secret.rendered_parameters(obj=obj)

        item_id = parameters.get("item_id")
        secret_field = parameters.get("secret_field")
        custom_field_name = parameters.get("custom_field_name", "")

        if not item_id:
            raise SecretParametersError(secret, cls, "item_id parameter is required.")

        if not secret_field:
            raise SecretParametersError(secret, cls, "secret_field parameter is required.")

        plugin_settings = settings.PLUGINS_CONFIG.get("nautobot_bitwarden_pm_secrets", {})
        base_url = plugin_settings.get("base_url", "http://localhost:8087").rstrip("/")

        if secret_field == "totp":
            return cls._get_totp_code(secret, base_url, item_id)

        result = cls._api_get(secret, base_url, f"/object/item/{item_id}")
        data = result.get("data", {})

        return cls._extract_field(secret, data, secret_field, custom_field_name)

    @classmethod
    def _api_get(cls, secret: Secret, base_url: str, path: str) -> dict[str, Any]:
        """Make a GET request to the Bitwarden CLI server and return the parsed JSON result."""
        url = f"{base_url}{path}"

        try:
            response = requests.get(url, timeout=30)
        except requests.ConnectionError as err:
            raise SecretProviderError(
                secret,
                cls,
                f"Unable to connect to Bitwarden CLI server at {base_url}: {err}",
            ) from err
        except requests.RequestException as err:
            raise SecretProviderError(
                secret,
                cls,
                f"Error communicating with Bitwarden CLI server: {err}",
            ) from err

        if response.status_code != 200:
            try:
                error_data = response.json()
                message = error_data.get("message", response.text)
            except ValueError:
                message = response.text
            raise SecretProviderError(
                secret,
                cls,
                f"Bitwarden CLI server returned HTTP {response.status_code}: {message}",
            )

        try:
            result = response.json()
        except ValueError as err:
            raise SecretProviderError(secret, cls, f"Invalid JSON response from Bitwarden CLI server: {err}") from err

        if not result.get("success"):
            raise SecretProviderError(
                secret,
                cls,
                f"Bitwarden CLI server returned an error: {result.get('message', 'Unknown error')}",
            )

        return result

    @classmethod
    def _get_totp_code(cls, secret: Secret, base_url: str, item_id: str) -> str:
        """Retrieve the current TOTP code for a vault item via the /object/totp endpoint."""
        result = cls._api_get(secret, base_url, f"/object/totp/{item_id}")
        data = result.get("data", {})
        code = data.get("data")
        if not code:
            raise SecretValueNotFoundError(
                secret,
                cls,
                "The Bitwarden vault item does not have TOTP configured.",
            )
        return code

    @classmethod
    def _extract_field(cls, secret: Secret, data: dict[str, Any], secret_field: str, custom_field_name: str) -> str:
        """Extract the requested field from a Bitwarden vault item."""
        if secret_field == "notes":
            value = data.get("notes")
        elif secret_field == "custom_field":
            value = cls._get_custom_field(data, custom_field_name)
        else:
            login = data.get("login")
            if login is None:
                raise SecretValueNotFoundError(
                    secret,
                    cls,
                    "The Bitwarden vault item is not a Login type and has no login fields.",
                )

            if secret_field == "uri":
                uris = login.get("uris")
                if not uris:
                    raise SecretValueNotFoundError(secret, cls, "The Bitwarden vault item has no URIs.")
                value = uris[0].get("uri")
            else:
                value = login.get(secret_field)

        if value is None:
            raise SecretValueNotFoundError(
                secret,
                cls,
                f"The field '{secret_field}' is not set on the Bitwarden vault item.",
            )

        return value

    @classmethod
    def _get_custom_field(cls, data: dict[str, Any], custom_field_name: str) -> str:
        """Retrieve a custom field value by name from a Bitwarden vault item."""
        fields = data.get("fields")
        if not fields:
            raise SecretValueNotFoundError(
                None,
                cls,
                f"The Bitwarden vault item has no custom fields (looking for '{custom_field_name}').",
            )

        for field in fields:
            if field.get("name") == custom_field_name:
                return field.get("value")

        available = ", ".join(f.get("name", "<unnamed>") for f in fields)
        raise SecretValueNotFoundError(
            None,
            cls,
            f"Custom field '{custom_field_name}' not found. Available fields: {available}",
        )


secrets_providers = [BitwardenPasswordManagerSecretsProvider]
