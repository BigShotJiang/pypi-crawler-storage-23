"""Output adapters."""
