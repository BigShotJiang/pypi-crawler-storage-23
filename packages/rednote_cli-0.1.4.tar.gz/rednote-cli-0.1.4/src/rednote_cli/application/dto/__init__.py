"""DTO models for CLI inputs and outputs."""
