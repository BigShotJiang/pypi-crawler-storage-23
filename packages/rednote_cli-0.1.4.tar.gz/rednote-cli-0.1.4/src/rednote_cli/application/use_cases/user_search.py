from __future__ import annotations

from rednote_cli.adapters.platform.rednote.extractor import RednoteExtractorAdapter


async def execute_user_search(keyword: str, size: int = 20, account_uid: str | None = None) -> list[dict]:
    adapter = RednoteExtractorAdapter()
    return await adapter.search_users(keyword=keyword, size=size, account_uid=account_uid)
