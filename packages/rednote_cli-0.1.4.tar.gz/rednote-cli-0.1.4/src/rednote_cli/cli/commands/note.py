from __future__ import annotations

import typer

from rednote_cli.application.dto.input_models import NoteGetInput
from rednote_cli.application.use_cases.note_get import execute_note_get
from rednote_cli.cli.options import CliContext
from rednote_cli.cli.runtime import run_async_command
from rednote_cli.cli.utils import all_option_params_are_default, load_json_input, pick_cli_or_input
from rednote_cli.cli.xsec_help import NOTE_COMMAND_DOC, NOTE_INPUT_HELP, NOTE_XSEC_SOURCE_HELP

app = typer.Typer(help="笔记详情查询", no_args_is_help=False)


@app.callback(invoke_without_command=True)
def note_get(
    ctx: typer.Context,
    note_id: str | None = typer.Option(None, "--note-id", help="笔记 ID；可由 --input 提供"),
    xsec_token: str | None = typer.Option(None, "--xsec-token", help="xsec_token；默认优先携带，已拿到时不要省略"),
    xsec_source: str = typer.Option(
        "pc_feed",
        "--xsec-source",
        help=NOTE_XSEC_SOURCE_HELP,
    ),
    comment_size: int = typer.Option(10, "--comment-size", help="一级评论数量（1..100）"),
    sub_comment_size: int = typer.Option(5, "--sub-comment-size", help="二级评论数量（1..50）"),
    account: str | None = typer.Option(None, "--account", help="账号唯一标识（user_no）"),
    input_file: str | None = typer.Option(
        None,
        "--input",
        help=NOTE_INPUT_HELP,
    ),
):
    if all_option_params_are_default(ctx=ctx):
        typer.echo(ctx.get_help())
        raise typer.Exit(code=0)

    cli_ctx: CliContext = ctx.obj
    payload = load_json_input(input_file)
    account_uid = pick_cli_or_input(
        ctx=ctx,
        param_name="account",
        cli_value=account,
        payload=payload,
        payload_key="account_uid",
    )

    async def _run():
        validated = NoteGetInput(
            note_id=pick_cli_or_input(
                ctx=ctx,
                param_name="note_id",
                cli_value=note_id,
                payload=payload,
                payload_key="note_id",
            ),
            xsec_token=pick_cli_or_input(
                ctx=ctx,
                param_name="xsec_token",
                cli_value=xsec_token,
                payload=payload,
                payload_key="xsec_token",
            ),
            xsec_source=pick_cli_or_input(
                ctx=ctx,
                param_name="xsec_source",
                cli_value=xsec_source,
                payload=payload,
                payload_key="xsec_source",
            ),
            comment_size=pick_cli_or_input(
                ctx=ctx,
                param_name="comment_size",
                cli_value=comment_size,
                payload=payload,
                payload_key="comment_size",
            ),
            sub_comment_size=pick_cli_or_input(
                ctx=ctx,
                param_name="sub_comment_size",
                cli_value=sub_comment_size,
                payload=payload,
                payload_key="sub_comment_size",
            ),
            account_uid=account_uid,
        )
        return await execute_note_get(
            note_id=validated.note_id,
            xsec_token=validated.xsec_token,
            xsec_source=validated.xsec_source,
            comment_size=validated.comment_size,
            sub_comment_size=validated.sub_comment_size,
            account_uid=validated.account_uid,
        )

    run_async_command(
        ctx=cli_ctx,
        command="note.get",
        func=_run,
        account_uid=account_uid,
    )


note_get.__doc__ = NOTE_COMMAND_DOC
