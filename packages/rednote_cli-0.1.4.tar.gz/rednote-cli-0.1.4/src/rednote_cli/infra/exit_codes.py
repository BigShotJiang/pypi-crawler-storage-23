from __future__ import annotations

from enum import IntEnum


class ExitCode(IntEnum):
    SUCCESS = 0
    INVALID_ARGS = 2
    AUTH_REQUIRED = 3
    RISK_CONTROL = 4
    INTERNAL_ERROR = 5
    TIMEOUT = 6
    DEPENDENCY_MISSING = 7


ERROR_CODE_TO_EXIT_CODE: dict[str, ExitCode] = {
    "INVALID_ARGS": ExitCode.INVALID_ARGS,
    "AUTH_REQUIRED": ExitCode.AUTH_REQUIRED,
    "ACCOUNT_UNAVAILABLE": ExitCode.INVALID_ARGS,
    "RISK_CONTROL_TRIGGERED": ExitCode.RISK_CONTROL,
    "RATE_LIMITED": ExitCode.RISK_CONTROL,
    "UPSTREAM_CHANGED": ExitCode.INTERNAL_ERROR,
    "TIMEOUT": ExitCode.TIMEOUT,
    "DEPENDENCY_MISSING": ExitCode.DEPENDENCY_MISSING,
    "INTERNAL_ERROR": ExitCode.INTERNAL_ERROR,
}


def map_error_code_to_exit_code(code: str) -> ExitCode:
    return ERROR_CODE_TO_EXIT_CODE.get(code, ExitCode.INTERNAL_ERROR)
