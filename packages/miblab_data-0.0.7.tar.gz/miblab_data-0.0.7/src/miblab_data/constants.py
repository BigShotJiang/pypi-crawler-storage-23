"""
miblab_data.constants
====================

Central registry of persistent identifiers for miblab datasets.

Notes
-----
Numeric values correspond to Zenodo *record IDs*.
Each record ID is resolvable via a DOI of the form:

    https://doi.org/10.5281/zenodo.<record_id>
"""

DOI = {
    "RAT": 17178063,  # DOI: 10.5281/zenodo.17178063
}