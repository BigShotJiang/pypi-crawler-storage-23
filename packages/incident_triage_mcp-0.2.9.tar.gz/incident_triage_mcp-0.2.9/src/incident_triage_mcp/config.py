from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


class ConfigError(RuntimeError):
    pass


def _env(name: str, default: Optional[str] = None) -> Optional[str]:
    return os.getenv(name, default)


def _require(name: str) -> str:
    v = os.getenv(name)
    if not v:
        raise ConfigError(f"Missing required environment variable: {name}")
    return v


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    value = raw.strip().lower()
    if value in {"1", "true", "yes", "on"}:
        return True
    if value in {"0", "false", "no", "off", ""}:
        return False
    raise ConfigError(f"{name} must be a boolean value (true/false)")


@dataclass(frozen=True)
class AppConfig:
    # Deployment profile
    deployment_profile: str

    # MCP
    mcp_transport: str
    mcp_host: str
    mcp_port: int

    # Audit
    audit_mode: str
    audit_path: str

    # Artifact store
    workflow_backend: str
    evidence_backend: str
    evidence_dir: str
    artifact_store: str
    bundle_only_mode: bool
    s3_endpoint_url: Optional[str]
    s3_bucket: Optional[str]
    s3_region: str
    aws_access_key_id: Optional[str]
    aws_secret_access_key: Optional[str]

    # Airflow (optional)
    airflow_base_url: Optional[str]
    airflow_username: Optional[str]
    airflow_password: Optional[str]

    # Adapter providers
    alerts_provider: str
    metrics_provider: str
    logs_provider: str
    traces_provider: str
    notify_provider: str

    # HTTP auth boundary
    http_auth_mode: str
    http_api_key: Optional[str]
    http_jwt_secret: Optional[str]
    http_jwt_issuer: Optional[str]
    http_jwt_audience: Optional[str]
    http_jwt_leeway_seconds: int

    # Adapter resilience
    adapter_timeout_seconds: float
    adapter_retries: int
    adapter_backoff_seconds: float
    adapter_max_backoff_seconds: float
    adapter_circuit_failure_threshold: int
    adapter_circuit_open_seconds: float

    # Runbooks
    runbooks_dir: str


def load_config() -> AppConfig:
    artifact_store = (_env("ARTIFACT_STORE", "fs") or "fs").lower()
    evidence_backend = (_env("EVIDENCE_BACKEND") or artifact_store or "fs").lower()
    workflow_backend = (_env("WORKFLOW_BACKEND") or "").lower()
    if not workflow_backend:
        # Backward compatibility: prior versions enabled Airflow workflow via EVIDENCE_BACKEND=airflow.
        workflow_backend = "airflow" if evidence_backend == "airflow" else "none"

    cfg = AppConfig(
        deployment_profile=(_env("DEPLOYMENT_PROFILE", "local") or "local").lower(),
        mcp_transport=_env("MCP_TRANSPORT", "stdio") or "stdio",
        mcp_host=_env("MCP_HOST", "0.0.0.0") or "0.0.0.0",
        mcp_port=int(_env("MCP_PORT", "3333") or "3333"),

        audit_mode=(_env("AUDIT_MODE", "stdout") or "stdout").lower(),
        audit_path=_env("AUDIT_PATH", "audit.jsonl") or "audit.jsonl",

        workflow_backend=workflow_backend,
        evidence_backend=evidence_backend,
        evidence_dir=_env("EVIDENCE_DIR", "./evidence") or "./evidence",
        artifact_store=artifact_store,
        bundle_only_mode=_env_bool("BUNDLE_ONLY_MODE", False),
        s3_endpoint_url=_env("S3_ENDPOINT_URL"),
        s3_bucket=_env("S3_BUCKET"),
        s3_region=_env("S3_REGION", "us-east-1") or "us-east-1",
        aws_access_key_id=_env("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=_env("AWS_SECRET_ACCESS_KEY"),

        airflow_base_url=_env("AIRFLOW_BASE_URL"),
        airflow_username=_env("AIRFLOW_USERNAME"),
        airflow_password=_env("AIRFLOW_PASSWORD"),

        alerts_provider=(_env("ALERTS_PROVIDER", "mock") or "mock").lower(),
        metrics_provider=(_env("METRICS_PROVIDER", "mock") or "mock").lower(),
        logs_provider=(_env("LOGS_PROVIDER", "mock") or "mock").lower(),
        traces_provider=(_env("TRACES_PROVIDER", "mock") or "mock").lower(),
        notify_provider=(_env("NOTIFY_PROVIDER", "slack") or "slack").lower(),

        http_auth_mode=(_env("MCP_HTTP_AUTH_MODE", "none") or "none").lower(),
        http_api_key=_env("MCP_HTTP_API_KEY"),
        http_jwt_secret=_env("MCP_HTTP_JWT_SECRET"),
        http_jwt_issuer=_env("MCP_HTTP_JWT_ISSUER"),
        http_jwt_audience=_env("MCP_HTTP_JWT_AUDIENCE"),
        http_jwt_leeway_seconds=int(_env("MCP_HTTP_JWT_LEEWAY_SECONDS", "30") or "30"),

        adapter_timeout_seconds=float(_env("ADAPTER_TIMEOUT_SECONDS", "5.0") or "5.0"),
        adapter_retries=int(_env("ADAPTER_RETRIES", "1") or "1"),
        adapter_backoff_seconds=float(_env("ADAPTER_BACKOFF_SECONDS", "0.15") or "0.15"),
        adapter_max_backoff_seconds=float(_env("ADAPTER_MAX_BACKOFF_SECONDS", "1.0") or "1.0"),
        adapter_circuit_failure_threshold=int(
            _env("ADAPTER_CIRCUIT_FAILURE_THRESHOLD", "3") or "3"
        ),
        adapter_circuit_open_seconds=float(
            _env("ADAPTER_CIRCUIT_OPEN_SECONDS", "10.0") or "10.0"
        ),

        runbooks_dir=_env("RUNBOOKS_DIR", "./runbooks") or "./runbooks",
    )

    # Validate deployment profile
    if cfg.deployment_profile not in {"local", "staging", "prod"}:
        raise ConfigError("DEPLOYMENT_PROFILE must be one of: local, staging, prod")

    # Validate audit
    if cfg.audit_mode not in {"stdout", "file"}:
        raise ConfigError("AUDIT_MODE must be 'stdout' or 'file'")

    # Validate evidence backend mode
    if cfg.evidence_backend not in {"none", "fs", "s3", "airflow"}:
        raise ConfigError("EVIDENCE_BACKEND must be one of: none, fs, s3, airflow")
    if cfg.workflow_backend not in {"none", "airflow"}:
        raise ConfigError("WORKFLOW_BACKEND must be one of: none, airflow")

    # Validate provider flags
    provider_sets = {
        "ALERTS_PROVIDER": (
            cfg.alerts_provider,
            {"mock", "datadog", "cloudwatch", "prometheus", "pagerduty", "opsgenie"},
        ),
        "METRICS_PROVIDER": (cfg.metrics_provider, {"mock", "datadog", "cloudwatch", "prometheus"}),
        "LOGS_PROVIDER": (cfg.logs_provider, {"mock", "datadog", "cloudwatch", "elk", "none"}),
        "TRACES_PROVIDER": (
            cfg.traces_provider,
            {"mock", "datadog", "cloudwatch", "xray", "otel", "none"},
        ),
    }
    for env_name, (value, allowed) in provider_sets.items():
        if value not in allowed:
            allowed_str = ", ".join(sorted(allowed))
            raise ConfigError(f"{env_name} must be one of: {allowed_str}")
    if cfg.notify_provider not in {"slack", "teams"}:
        raise ConfigError("NOTIFY_PROVIDER must be one of: slack, teams")

    ticket_provider = (_env("JIRA_PROVIDER", "mock") or "mock").lower()
    if ticket_provider not in {"mock", "cloud", "servicenow"}:
        raise ConfigError("JIRA_PROVIDER must be one of: mock, cloud, servicenow")

    # Validate HTTP auth settings
    if cfg.http_auth_mode not in {"none", "api_key", "jwt_hs256"}:
        raise ConfigError("MCP_HTTP_AUTH_MODE must be one of: none, api_key, jwt_hs256")
    if cfg.http_auth_mode == "api_key" and not cfg.http_api_key:
        raise ConfigError("MCP_HTTP_API_KEY is required when MCP_HTTP_AUTH_MODE=api_key")
    if cfg.http_auth_mode == "jwt_hs256" and not cfg.http_jwt_secret:
        raise ConfigError("MCP_HTTP_JWT_SECRET is required when MCP_HTTP_AUTH_MODE=jwt_hs256")
    if cfg.http_jwt_leeway_seconds < 0:
        raise ConfigError("MCP_HTTP_JWT_LEEWAY_SECONDS must be >= 0")

    # Profile-aware security requirements
    if cfg.deployment_profile in {"staging", "prod"}:
        if cfg.mcp_transport == "streamable-http" and cfg.http_auth_mode == "none":
            raise ConfigError(
                "MCP_HTTP_AUTH_MODE cannot be 'none' in staging/prod when MCP_TRANSPORT=streamable-http"
            )

        selected_providers = {
            cfg.alerts_provider,
            cfg.metrics_provider,
            cfg.logs_provider,
            cfg.traces_provider,
        }
        if not cfg.bundle_only_mode:
            provider_requirements: dict[str, list[str]] = {
                "datadog": ["DATADOG_API_KEY", "DATADOG_APP_KEY"],
                "prometheus": ["PROMETHEUS_BASE_URL"],
                "pagerduty": ["PAGERDUTY_API_TOKEN"],
                "opsgenie": ["OPSGENIE_API_KEY"],
                "elk": ["ELASTICSEARCH_BASE_URL"],
            }
            for provider, env_vars in provider_requirements.items():
                if provider not in selected_providers:
                    continue
                missing = [name for name in env_vars if not _env(name)]
                if missing:
                    raise ConfigError(
                        f"Missing required env vars for {provider} provider in {cfg.deployment_profile} profile: "
                        + ", ".join(missing)
                    )

        ticket_provider_requirements: dict[str, list[str]] = {
            "cloud": ["JIRA_BASE_URL", "JIRA_EMAIL", "JIRA_API_TOKEN"],
            "servicenow": [
                "SERVICENOW_BASE_URL",
                "SERVICENOW_USERNAME",
                "SERVICENOW_PASSWORD",
            ],
        }
        required_ticket_env = ticket_provider_requirements.get(ticket_provider)
        if required_ticket_env:
            missing_ticket = [name for name in required_ticket_env if not _env(name)]
            if missing_ticket:
                raise ConfigError(
                    f"Missing required env vars for JIRA_PROVIDER={ticket_provider} in "
                    f"{cfg.deployment_profile} profile: " + ", ".join(missing_ticket)
                )

    if cfg.deployment_profile == "prod":
        if cfg.audit_mode != "stdout":
            raise ConfigError("AUDIT_MODE must be 'stdout' in DEPLOYMENT_PROFILE=prod")
        if (not cfg.bundle_only_mode) and (
            cfg.alerts_provider == "mock" or cfg.metrics_provider == "mock"
        ):
            raise ConfigError(
                "ALERTS_PROVIDER and METRICS_PROVIDER cannot be 'mock' in DEPLOYMENT_PROFILE=prod"
            )
        if cfg.evidence_backend == "none":
            raise ConfigError("EVIDENCE_BACKEND cannot be 'none' in DEPLOYMENT_PROFILE=prod")
        idempotency_backend = (_env("IDEMPOTENCY_BACKEND", "file") or "file").strip().lower()
        if idempotency_backend not in {"redis", "postgres", "postgresql"}:
            raise ConfigError(
                "IDEMPOTENCY_BACKEND must be redis or postgres in DEPLOYMENT_PROFILE=prod"
            )

    # Validate resilience settings
    if cfg.adapter_timeout_seconds <= 0:
        raise ConfigError("ADAPTER_TIMEOUT_SECONDS must be > 0")
    if cfg.adapter_retries < 0:
        raise ConfigError("ADAPTER_RETRIES must be >= 0")
    if cfg.adapter_backoff_seconds < 0:
        raise ConfigError("ADAPTER_BACKOFF_SECONDS must be >= 0")
    if cfg.adapter_max_backoff_seconds <= 0:
        raise ConfigError("ADAPTER_MAX_BACKOFF_SECONDS must be > 0")
    if cfg.adapter_circuit_failure_threshold <= 0:
        raise ConfigError("ADAPTER_CIRCUIT_FAILURE_THRESHOLD must be > 0")
    if cfg.adapter_circuit_open_seconds < 0:
        raise ConfigError("ADAPTER_CIRCUIT_OPEN_SECONDS must be >= 0")

    # Validate artifacts for S3 backend only
    if cfg.evidence_backend == "s3":
        missing = []
        if not cfg.s3_endpoint_url:
            missing.append("S3_ENDPOINT_URL")
        if not cfg.s3_bucket:
            missing.append("S3_BUCKET")
        if not cfg.aws_access_key_id:
            missing.append("AWS_ACCESS_KEY_ID")
        if not cfg.aws_secret_access_key:
            missing.append("AWS_SECRET_ACCESS_KEY")
        if missing:
            raise ConfigError(
                "Missing required env vars for EVIDENCE_BACKEND=s3: " + ", ".join(missing)
            )

    return cfg
