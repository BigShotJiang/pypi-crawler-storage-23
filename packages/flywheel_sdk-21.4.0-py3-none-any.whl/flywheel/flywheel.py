# coding: utf-8

# flake8: noqa

"""
"""


from __future__ import absolute_import


import codecs
import os
import os.path
import sys
import six
import time
import math
import io
import platform
import logging
import mimetypes
import warnings
from packaging import version
from urllib.parse import urlparse, parse_qs

log = logging.getLogger('Flywheel')

from flywheel.configuration import Configuration
from flywheel.api_client import ApiClient
from flywheel.partial_reader import PartialReader
from flywheel.view_builder import ViewBuilder
from flywheel.finder import Finder
import flywheel.api

SDK_VERSION = "21.4.0"

def config_from_api_key(api_key):
    parts = api_key.split(':')
    if len(parts) < 2:
        raise Exception('Invalid API key')

    host = parts[0]
    if len(parts) == 2:
        key = parts[1]
        port = '443'
    else:
        port = parts[1]
        key = parts[-1]

    if '__force_insecure' in parts:
        scheme = 'http'
    else:
        scheme = 'https'

    config = Configuration()
    config.host = '{}://{}:{}/api'.format(scheme, host, port)
    config.api_key = {'Authorization': key}

    if len(key) == 57:
        config.api_key_prefix = {'Authorization': 'Bearer'}
    else:
        config.api_key_prefix = {'Authorization': 'scitran-user'}

    return config


class Flywheel:
    """Main client class for the Python SDK.

    Normally initialized via a call to `flywheel.Client` rather than by directly
    calling this class.

    :param api_key: The API key to authenticate with.
    :type api_key: str
    :param minimum_supported_major_version: Minimum major version of the SDK the
        caller accepts.
    :type minimum_supported_major_version: int, optional
    :param root: Sets default parameter for requests to return a complete list
        regardless of permissions - for site admin users. Deprecated - use `exhaustive`
        instead.
    :type root: bool, optional
    :param skip_version_check: Deprecated--does nothing.
    :type skip_version_check: bool, optional
    :param subjects_in_resolver: Deprecated--does nothing.
    :type subjects_in_resolver: bool, optional
    :param request_timeout: The client timeout for making requests, in seconds.
    :type request_timeout: int, optional
    :param connect_timeout: The client timeout for making connections, in seconds.
    :type connect_timeout: int, optional
    :param exhaustive: Sets default parameter for requests to return a complete
        list regardless of permissions - for site admin users.
    :type exhaustive: bool, optional
    """
    def __init__(self, api_key, minimum_supported_major_version=0, root=False,
                 skip_version_check=None, subjects_in_resolver=None,
                 request_timeout=None, connect_timeout=None, exhaustive=False):

        # Check that the client caller is expecting the minimum supported version
        if minimum_supported_major_version < 11:
            raise Exception('The Flywheel CLI is expecting a version before v11'
                ' of the Flywheel SDK. Please use flywheel.Client() instead of'
                ' flywheel.Flywheel() if your are not the Flywheel CLI.')

        # Parse API Key and configure api_client
        config = config_from_api_key(api_key)
        self.api_client = ApiClient(
            config,
            context=self,
            request_timeout=request_timeout,
            connect_timeout=connect_timeout
        )

        # skip_version_check (Deprecated)
        if skip_version_check is not None:
            log.warning('The skip_version_check parameter is deprecated')
            warnings.warn('The skip_version_check parameter is deprecated', DeprecationWarning)

        # subjects in resolver (deprecated)
        if subjects_in_resolver is not None:
            log.warning('The subjects_in_resolver parameter is deprecated')
            warnings.warn('The subjects_in_resolver parameter is deprecated', DeprecationWarning)

        # Root mode (Deprecated)
        if root:
            log.warning('Root mode is deprecated')
            warnings.warn('Root mode is deprecated', DeprecationWarning)
            self.api_client.set_default_query_param('exhaustive', 'true')

        # exhaustive mode
        if exhaustive:
            self.api_client.set_default_query_param('exhaustive', 'true')

        self.api_client.user_agent = 'Flywheel SDK/{} (Python {}; {})'.format(SDK_VERSION,
            platform.python_version(), platform.system())

        # Initialize Apis
        self.acquisitions_api = flywheel.api.AcquisitionsApi(self.api_client)
        self.analyses_api = flywheel.api.AnalysesApi(self.api_client)
        self.audit_trail_api = flywheel.api.AuditTrailApi(self.api_client)
        self.auth_api = flywheel.api.AuthApi(self.api_client)
        self.batch_api = flywheel.api.BatchApi(self.api_client)
        self.bulk_api = flywheel.api.BulkApi(self.api_client)
        self.change_log_api = flywheel.api.ChangeLogApi(self.api_client)
        self.collections_api = flywheel.api.CollectionsApi(self.api_client)
        self.config_api = flywheel.api.ConfigApi(self.api_client)
        self.container_tasks_api = flywheel.api.ContainerTasksApi(self.api_client)
        self.container_type_api = flywheel.api.ContainerTypeApi(self.api_client)
        self.containers_api = flywheel.api.ContainersApi(self.api_client)
        self.custom_filters_api = flywheel.api.CustomFiltersApi(self.api_client)
        self.data_view_executions_api = flywheel.api.DataViewExecutionsApi(self.api_client)
        self.dataexplorer_api = flywheel.api.DataexplorerApi(self.api_client)
        self.devices_api = flywheel.api.DevicesApi(self.api_client)
        self.dimse_api = flywheel.api.DimseApi(self.api_client)
        self.download_api = flywheel.api.DownloadApi(self.api_client)
        self.files_api = flywheel.api.FilesApi(self.api_client)
        self.form_responses_api = flywheel.api.FormResponsesApi(self.api_client)
        self.gears_api = flywheel.api.GearsApi(self.api_client)
        self.groups_api = flywheel.api.GroupsApi(self.api_client)
        self.jobs_api = flywheel.api.JobsApi(self.api_client)
        self.jupyterlab_servers_api = flywheel.api.JupyterlabServersApi(self.api_client)
        self.modalities_api = flywheel.api.ModalitiesApi(self.api_client)
        self.packfiles_api = flywheel.api.PackfilesApi(self.api_client)
        self.projects_api = flywheel.api.ProjectsApi(self.api_client)
        self.protocols_api = flywheel.api.ProtocolsApi(self.api_client)
        self.reports_api = flywheel.api.ReportsApi(self.api_client)
        self.resolve_api = flywheel.api.ResolveApi(self.api_client)
        self.roles_api = flywheel.api.RolesApi(self.api_client)
        self.sessions_api = flywheel.api.SessionsApi(self.api_client)
        self.site_api = flywheel.api.SiteApi(self.api_client)
        self.staffing_pools_api = flywheel.api.StaffingPoolsApi(self.api_client)
        self.subjects_api = flywheel.api.SubjectsApi(self.api_client)
        self.tasks_api = flywheel.api.TasksApi(self.api_client)
        self.tree_api = flywheel.api.TreeApi(self.api_client)
        self.uids_api = flywheel.api.UidsApi(self.api_client)
        self.upload_api = flywheel.api.UploadApi(self.api_client)
        self.users_api = flywheel.api.UsersApi(self.api_client)
        self.views_api = flywheel.api.ViewsApi(self.api_client)

        # Finder objects
        self.users = Finder(self, 'get_all_users')
        self.groups = Finder(self, 'get_all_groups')
        self.projects = Finder(self, 'get_all_projects')
        self.subjects = Finder(self, 'get_all_subjects')
        self.sessions = Finder(self, 'get_all_sessions')
        self.acquisitions = Finder(self, 'get_all_acquisitions')
        self.jobs = Finder(self, 'get_all_jobs')
        self.gears = Finder(self, 'get_all_gears')
        self.collections = Finder(self, 'get_all_collections')
        self.data_view_executions = Finder(self, 'get_all_data_view_executions')
        self.files = Finder(self, 'get_all_files')
        self.analyses = Finder(self, 'get_all_analyses')

        # Overwrite catalog_list endpoint with a Finder because it can only work with
        # pagination
        catalog_list = Finder(self, 'catalog_list')
        catalog_list._func
        self.catalog_list = catalog_list

        self.enable_feature('Safe-Redirect')
        self.enable_feature('multipart_signed_url')


    def enable_debug(self, message_cutoff=None):
        self.api_client.configuration.debug = True

        if message_cutoff is not None:
            self.api_client.configuration.enable_message_cutoff(message_cutoff)


    def disable_debug(self):
        self.api_client.configuration.debug = False
        self.api_client.configuration.disable_message_cutoff()


    def acquisition_copy(self, acquisition_id, body, **kwargs):  # noqa: E501
        """Smart copy an acquisition

        See ``AcquisitionsApi.acquisition_copy()`` for parameter details.
        """
        return self.acquisitions_api.acquisition_copy(acquisition_id, body, **kwargs)


    def add_acquisition(self, body, **kwargs):  # noqa: E501
        """Create a new acquisition

        See ``AcquisitionsApi.add_acquisition()`` for parameter details.
        """
        return self.acquisitions_api.add_acquisition(body, **kwargs)


    def add_acquisition_analysis(self, cid, body, **kwargs):  # noqa: E501
        """Create an analysis and upload files.

        See ``AcquisitionsApi.add_acquisition_analysis()`` for parameter details.
        """
        return self.acquisitions_api.add_acquisition_analysis(cid, body, **kwargs)


    def add_acquisition_analysis_note(self, container_id, analysis_id, body, **kwargs):  # noqa: E501
        """Add a note to a(n) acquisition analysis.

        See ``AcquisitionsApi.add_acquisition_analysis_note()`` for parameter details.
        """
        return self.acquisitions_api.add_acquisition_analysis_note(container_id, analysis_id, body, **kwargs)


    def add_acquisition_note(self, container_id, body, **kwargs):  # noqa: E501
        """Add a note to a(n) acquisition.

        See ``AcquisitionsApi.add_acquisition_note()`` for parameter details.
        """
        return self.acquisitions_api.add_acquisition_note(container_id, body, **kwargs)


    def add_acquisition_tag(self, cid, body, **kwargs):  # noqa: E501
        """Add a tag to a(n) acquisition.

        See ``AcquisitionsApi.add_acquisition_tag()`` for parameter details.
        """
        return self.acquisitions_api.add_acquisition_tag(cid, body, **kwargs)


    def add_acquisition_tags(self, cid, body, **kwargs):  # noqa: E501
        """Add multiple tags to a(n) acquisition

        See ``AcquisitionsApi.add_acquisition_tags()`` for parameter details.
        """
        return self.acquisitions_api.add_acquisition_tags(cid, body, **kwargs)


    def delete_acquisition(self, acquisition_id, **kwargs):  # noqa: E501
        """Delete a acquisition

        See ``AcquisitionsApi.delete_acquisition()`` for parameter details.
        """
        return self.acquisitions_api.delete_acquisition(acquisition_id, **kwargs)


    def delete_acquisition_analysis(self, cid, analysis_id, **kwargs):  # noqa: E501
        """Delete an analysis

        See ``AcquisitionsApi.delete_acquisition_analysis()`` for parameter details.
        """
        return self.acquisitions_api.delete_acquisition_analysis(cid, analysis_id, **kwargs)


    def delete_acquisition_analysis_note(self, cid, analysis_id, note_id, **kwargs):  # noqa: E501
        """Remove a note from a(n) acquisition analysis.

        See ``AcquisitionsApi.delete_acquisition_analysis_note()`` for parameter details.
        """
        return self.acquisitions_api.delete_acquisition_analysis_note(cid, analysis_id, note_id, **kwargs)


    def delete_acquisition_file(self, cid, filename, **kwargs):  # noqa: E501
        """Delete a file

        See ``AcquisitionsApi.delete_acquisition_file()`` for parameter details.
        """
        return self.acquisitions_api.delete_acquisition_file(cid, filename, **kwargs)


    def delete_acquisition_note(self, cid, note_id, **kwargs):  # noqa: E501
        """Remove a note from a(n) acquisition

        See ``AcquisitionsApi.delete_acquisition_note()`` for parameter details.
        """
        return self.acquisitions_api.delete_acquisition_note(cid, note_id, **kwargs)


    def delete_acquisition_tag(self, cid, value, **kwargs):  # noqa: E501
        """Delete a tag

        See ``AcquisitionsApi.delete_acquisition_tag()`` for parameter details.
        """
        return self.acquisitions_api.delete_acquisition_tag(cid, value, **kwargs)


    def delete_acquisition_tags(self, cid, body, **kwargs):  # noqa: E501
        """Delete multiple tags from a(n) acquisition

        See ``AcquisitionsApi.delete_acquisition_tags()`` for parameter details.
        """
        return self.acquisitions_api.delete_acquisition_tags(cid, body, **kwargs)


    def delete_acquisitions_by_ids(self, body, **kwargs):  # noqa: E501
        """Delete multiple acquisitions by ID list

        See ``AcquisitionsApi.delete_acquisitions_by_ids()`` for parameter details.
        """
        return self.acquisitions_api.delete_acquisitions_by_ids(body, **kwargs)


    def download_file_from_acquisition(self, acquisition_id, file_name, dest_file, **kwargs):  # noqa: E501
        """Download a file.

        See ``AcquisitionsApi.download_file_from_acquisition()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.acquisitions_api.download_file_from_acquisition(acquisition_id, file_name, dest_file, **kwargs)


    def get_acquisition_file_zip_info(self, acquisition_id, file_name, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``AcquisitionsApi.get_acquisition_file_zip_info()`` for parameter details.
        """
        return self.acquisitions_api.get_acquisition_file_zip_info(acquisition_id, file_name, **kwargs)


    def get_acquisition_download_url(self, acquisition_id, file_name, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``AcquisitionsApi.get_acquisition_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.acquisitions_api.get_acquisition_download_ticket(acquisition_id, file_name, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def download_input_from_acquisition_analysis(self, acquisition_id, analysis_id, filename, dest_file, **kwargs):  # noqa: E501
        """Download analysis inputs with filter.

        See ``AcquisitionsApi.download_input_from_acquisition_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.acquisitions_api.download_input_from_acquisition_analysis(acquisition_id, analysis_id, filename, dest_file, **kwargs)


    def get_acquisition_analysis_input_zip_info(self, acquisition_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``AcquisitionsApi.get_acquisition_analysis_input_zip_info()`` for parameter details.
        """
        return self.acquisitions_api.get_acquisition_analysis_input_zip_info(acquisition_id, analysis_id, filename, **kwargs)


    def get_acquisition_analysis_input_download_url(self, acquisition_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``AcquisitionsApi.get_acquisition_analysis_input_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.acquisitions_api.get_acquisition_analysis_input_download_ticket(acquisition_id, analysis_id, filename, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def download_output_from_acquisition_analysis(self, acquisition_id, analysis_id, filename, dest_file, **kwargs):  # noqa: E501
        """Download analysis outputs with filter.

        See ``AcquisitionsApi.download_output_from_acquisition_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.acquisitions_api.download_output_from_acquisition_analysis(acquisition_id, analysis_id, filename, dest_file, **kwargs)


    def get_acquisition_analysis_output_zip_info(self, acquisition_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``AcquisitionsApi.get_acquisition_analysis_output_zip_info()`` for parameter details.
        """
        return self.acquisitions_api.get_acquisition_analysis_output_zip_info(acquisition_id, analysis_id, filename, **kwargs)


    def get_acquisition_analysis_output_download_url(self, acquisition_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``AcquisitionsApi.get_acquisition_analysis_output_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.acquisitions_api.get_acquisition_analysis_output_download_ticket(acquisition_id, analysis_id, filename, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def get_acquisition(self, acquisition_id, **kwargs):  # noqa: E501
        """Get a single acquisition

        See ``AcquisitionsApi.get_acquisition()`` for parameter details.
        """
        return self.acquisitions_api.get_acquisition(acquisition_id, **kwargs)


    def get_acquisition_analyses(self, cid, **kwargs):  # noqa: E501
        """Get analyses for a(n) acquisition.

        See ``AcquisitionsApi.get_acquisition_analyses()`` for parameter details.
        """
        return self.acquisitions_api.get_acquisition_analyses(cid, **kwargs)


    def get_acquisition_analysis(self, cid, analysis_id, **kwargs):  # noqa: E501
        """Get an analysis.

        See ``AcquisitionsApi.get_acquisition_analysis()`` for parameter details.
        """
        return self.acquisitions_api.get_acquisition_analysis(cid, analysis_id, **kwargs)


    def get_acquisition_file_info(self, cid, filename, **kwargs):  # noqa: E501
        """Get info for a particular file.

        See ``AcquisitionsApi.get_acquisition_file_info()`` for parameter details.
        """
        return self.acquisitions_api.get_acquisition_file_info(cid, filename, **kwargs)


    def get_acquisition_note(self, cid, note_id, **kwargs):  # noqa: E501
        """Get a note of a(n) acquisition.

        See ``AcquisitionsApi.get_acquisition_note()`` for parameter details.
        """
        return self.acquisitions_api.get_acquisition_note(cid, note_id, **kwargs)


    def get_acquisition_tag(self, cid, value, **kwargs):  # noqa: E501
        """Get the value of a tag, by name.

        See ``AcquisitionsApi.get_acquisition_tag()`` for parameter details.
        """
        return self.acquisitions_api.get_acquisition_tag(cid, value, **kwargs)


    def get_all_acquisitions(self, **kwargs):  # noqa: E501
        """Get a list of acquisitions

        See ``AcquisitionsApi.get_all_acquisitions()`` for parameter details.
        """
        return self.acquisitions_api.get_all_acquisitions(**kwargs)


    def modify_acquisition(self, acquisition_id, body, **kwargs):  # noqa: E501
        """Update an acquisition

        See ``AcquisitionsApi.modify_acquisition()`` for parameter details.
        """
        return self.acquisitions_api.modify_acquisition(acquisition_id, body, **kwargs)


    def modify_acquisition_analysis(self, cid, analysis_id, body, **kwargs):  # noqa: E501
        """Modify an analysis.

        See ``AcquisitionsApi.modify_acquisition_analysis()`` for parameter details.
        """
        return self.acquisitions_api.modify_acquisition_analysis(cid, analysis_id, body, **kwargs)


    def modify_acquisition_file(self, cid, filename, body, **kwargs):  # noqa: E501
        """Modify a file&#x27;s attributes

        See ``AcquisitionsApi.modify_acquisition_file()`` for parameter details.
        """
        return self.acquisitions_api.modify_acquisition_file(cid, filename, body, **kwargs)


    def modify_acquisition_file_classification(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update classification for a particular file.

        See ``AcquisitionsApi.modify_acquisition_file_classification()`` for parameter details.
        """
        return self.acquisitions_api.modify_acquisition_file_classification(cid, filename, body, **kwargs)


    def modify_acquisition_file_info(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update info for a particular file.

        See ``AcquisitionsApi.modify_acquisition_file_info()`` for parameter details.
        """
        return self.acquisitions_api.modify_acquisition_file_info(cid, filename, body, **kwargs)


    def modify_acquisition_info(self, cid, body, **kwargs):  # noqa: E501
        """Update or replace info for a(n) acquisition.

        See ``AcquisitionsApi.modify_acquisition_info()`` for parameter details.
        """
        return self.acquisitions_api.modify_acquisition_info(cid, body, **kwargs)


    def modify_acquisition_note(self, cid, note_id, body, **kwargs):  # noqa: E501
        """Update a note of a(n) acquisition.

        See ``AcquisitionsApi.modify_acquisition_note()`` for parameter details.
        """
        return self.acquisitions_api.modify_acquisition_note(cid, note_id, body, **kwargs)


    def rename_acquisition_tag(self, cid, value, body, **kwargs):  # noqa: E501
        """Rename a tag.

        See ``AcquisitionsApi.rename_acquisition_tag()`` for parameter details.
        """
        return self.acquisitions_api.rename_acquisition_tag(cid, value, body, **kwargs)


    def upload_file_to_acquisition(self, container_id, file, signed=True, **kwargs):  # noqa: E501
        """Upload a file to a(n) acquisition.

        See ``AcquisitionsApi.upload_file_to_acquisition()`` for parameter details.
        :param signed: Use signed URL upload if available, defaults to True
        :type signed: bool, optional
        """
        if signed:
            signed_result = self.signed_upload_file_to_acquisition(container_id, file, **kwargs)
            if signed_result:
                return signed_result

        return self.acquisitions_api.upload_file_to_acquisition(container_id, file, **kwargs)


    def upload_output_to_acquisition_analysis(self, cid, analysis_id, file, signed=True, **kwargs):  # noqa: E501
        """Upload an output file to an analysis.

        See ``AcquisitionsApi.upload_output_to_acquisition_analysis()`` for parameter details.
        :param signed: Use signed URL upload if available, defaults to True
        :type signed: bool, optional
        """
        if signed:
            signed_result = self.signed_upload_output_to_acquisition_analysis(cid, analysis_id, file, **kwargs)
            if signed_result:
                return signed_result

        return self.acquisitions_api.upload_output_to_acquisition_analysis(cid, analysis_id, file, **kwargs)


    def add_analysis_note(self, container_id, body, **kwargs):  # noqa: E501
        """Add a note to a(n) analysis.

        See ``AnalysesApi.add_analysis_note()`` for parameter details.
        """
        return self.analyses_api.add_analysis_note(container_id, body, **kwargs)


    def add_analysis_tag(self, container_id, body, **kwargs):  # noqa: E501
        """Add a tag to a(n) analysis.

        See ``AnalysesApi.add_analysis_tag()`` for parameter details.
        """
        return self.analyses_api.add_analysis_tag(container_id, body, **kwargs)


    def delete_analyses_by_ids(self, body, **kwargs):  # noqa: E501
        """Delete multiple analyses by ID list

        See ``AnalysesApi.delete_analyses_by_ids()`` for parameter details.
        """
        return self.analyses_api.delete_analyses_by_ids(body, **kwargs)


    def delete_analysis(self, analysis_id, **kwargs):  # noqa: E501
        """Delete an analysis

        See ``AnalysesApi.delete_analysis()`` for parameter details.
        """
        return self.analyses_api.delete_analysis(analysis_id, **kwargs)


    def delete_analysis_file(self, cid, filename, **kwargs):  # noqa: E501
        """Delete a file

        See ``AnalysesApi.delete_analysis_file()`` for parameter details.
        """
        return self.analyses_api.delete_analysis_file(cid, filename, **kwargs)


    def delete_analysis_note(self, container_id, note_id, **kwargs):  # noqa: E501
        """Remove a note from a(n) analysis

        See ``AnalysesApi.delete_analysis_note()`` for parameter details.
        """
        return self.analyses_api.delete_analysis_note(container_id, note_id, **kwargs)


    def delete_analysis_tag(self, container_id, value, **kwargs):  # noqa: E501
        """Delete a tag

        See ``AnalysesApi.delete_analysis_tag()`` for parameter details.
        """
        return self.analyses_api.delete_analysis_tag(container_id, value, **kwargs)


    def download_file_from_analysis(self, analysis_id, file_name, dest_file, **kwargs):  # noqa: E501
        """Download a file.

        See ``AnalysesApi.download_file_from_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.analyses_api.download_file_from_analysis(analysis_id, file_name, dest_file, **kwargs)


    def get_analysis_file_zip_info(self, analysis_id, file_name, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``AnalysesApi.get_analysis_file_zip_info()`` for parameter details.
        """
        return self.analyses_api.get_analysis_file_zip_info(analysis_id, file_name, **kwargs)


    def get_analysis_download_url(self, analysis_id, file_name, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``AnalysesApi.get_analysis_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.analyses_api.get_analysis_download_ticket(analysis_id, file_name, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def download_input_from_analysis(self, analysis_id, filename, dest_file, **kwargs):  # noqa: E501
        """Download analysis inputs with filter.

        See ``AnalysesApi.download_input_from_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.analyses_api.download_input_from_analysis(analysis_id, filename, dest_file, **kwargs)


    def get_analysis_input_zip_info(self, analysis_id, filename, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``AnalysesApi.get_analysis_input_zip_info()`` for parameter details.
        """
        return self.analyses_api.get_analysis_input_zip_info(analysis_id, filename, **kwargs)


    def get_analysis_input_download_url(self, analysis_id, filename, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``AnalysesApi.get_analysis_input_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.analyses_api.get_analysis_input_download_ticket(analysis_id, filename, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def download_output_from_analysis(self, analysis_id, filename, dest_file, **kwargs):  # noqa: E501
        """Download output file from analysis

        See ``AnalysesApi.download_output_from_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.analyses_api.download_output_from_analysis(analysis_id, filename, dest_file, **kwargs)


    def get_analysis_output_zip_info(self, analysis_id, filename, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``AnalysesApi.get_analysis_output_zip_info()`` for parameter details.
        """
        return self.analyses_api.get_analysis_output_zip_info(analysis_id, filename, **kwargs)


    def get_analysis_output_download_url(self, analysis_id, filename, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``AnalysesApi.get_analysis_output_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.analyses_api.get_analysis_output_download_ticket(analysis_id, filename, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def get_all_analyses(self, **kwargs):  # noqa: E501
        """Find all analyses

        See ``AnalysesApi.get_all_analyses()`` for parameter details.
        """
        return self.analyses_api.get_all_analyses(**kwargs)


    def get_analyses(self, container_name, container_id, subcontainer_name, **kwargs):  # noqa: E501
        """Get nested analyses for a container

        See ``AnalysesApi.get_analyses()`` for parameter details.
        """
        return self.analyses_api.get_analyses(container_name, container_id, subcontainer_name, **kwargs)


    def get_analysis(self, analysis_id, **kwargs):  # noqa: E501
        """Get an analysis.

        See ``AnalysesApi.get_analysis()`` for parameter details.
        """
        return self.analyses_api.get_analysis(analysis_id, **kwargs)


    def get_analysis_file_info(self, container_id, filename, **kwargs):  # noqa: E501
        """Get metadata for an input file of an analysis.

        See ``AnalysesApi.get_analysis_file_info()`` for parameter details.
        """
        return self.analyses_api.get_analysis_file_info(container_id, filename, **kwargs)


    def get_analysis_input_files(self, container_id, filename, **kwargs):  # noqa: E501
        """Get metadata for input file(s) for an analysis.

        See ``AnalysesApi.get_analysis_input_files()`` for parameter details.
        """
        return self.analyses_api.get_analysis_input_files(container_id, filename, **kwargs)


    def get_analysis_note(self, container_id, note_id, **kwargs):  # noqa: E501
        """Get a note of a(n) analysis.

        See ``AnalysesApi.get_analysis_note()`` for parameter details.
        """
        return self.analyses_api.get_analysis_note(container_id, note_id, **kwargs)


    def get_analysis_output_file(self, cid, filename, **kwargs):  # noqa: E501
        """Get metadata for an output file of an analysis.

        See ``AnalysesApi.get_analysis_output_file()`` for parameter details.
        """
        return self.analyses_api.get_analysis_output_file(cid, filename, **kwargs)


    def get_analysis_tag(self, container_id, value, **kwargs):  # noqa: E501
        """Get the value of a tag, by name.

        See ``AnalysesApi.get_analysis_tag()`` for parameter details.
        """
        return self.analyses_api.get_analysis_tag(container_id, value, **kwargs)


    def modify_analysis(self, analysis_id, body, **kwargs):  # noqa: E501
        """Modify an analysis.

        See ``AnalysesApi.modify_analysis()`` for parameter details.
        """
        return self.analyses_api.modify_analysis(analysis_id, body, **kwargs)


    def modify_analysis_file(self, cid, filename, body, **kwargs):  # noqa: E501
        """Modify a file&#x27;s attributes

        See ``AnalysesApi.modify_analysis_file()`` for parameter details.
        """
        return self.analyses_api.modify_analysis_file(cid, filename, body, **kwargs)


    def modify_analysis_file_classification(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update classification for a particular file.

        See ``AnalysesApi.modify_analysis_file_classification()`` for parameter details.
        """
        return self.analyses_api.modify_analysis_file_classification(cid, filename, body, **kwargs)


    def modify_analysis_file_info(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update info for a particular file.

        See ``AnalysesApi.modify_analysis_file_info()`` for parameter details.
        """
        return self.analyses_api.modify_analysis_file_info(cid, filename, body, **kwargs)


    def modify_analysis_info(self, container_id, body, **kwargs):  # noqa: E501
        """Update or replace info for a(n) analysis.

        See ``AnalysesApi.modify_analysis_info()`` for parameter details.
        """
        return self.analyses_api.modify_analysis_info(container_id, body, **kwargs)


    def modify_analysis_note(self, container_id, note_id, body, **kwargs):  # noqa: E501
        """Update a note of a(n) analysis.

        See ``AnalysesApi.modify_analysis_note()`` for parameter details.
        """
        return self.analyses_api.modify_analysis_note(container_id, note_id, body, **kwargs)


    def rename_analysis_tag(self, container_id, value, body, **kwargs):  # noqa: E501
        """Rename a tag.

        See ``AnalysesApi.rename_analysis_tag()`` for parameter details.
        """
        return self.analyses_api.rename_analysis_tag(container_id, value, body, **kwargs)


    def upload_output_to_analysis(self, container_id, file, signed=True, **kwargs):  # noqa: E501
        """Upload an output file to an analysis.

        See ``AnalysesApi.upload_output_to_analysis()`` for parameter details.
        :param signed: Use signed URL upload if available, defaults to True
        :type signed: bool, optional
        """
        if signed:
            signed_result = self.signed_upload_output_to_analysis(container_id, file, **kwargs)
            if signed_result:
                return signed_result

        return self.analyses_api.upload_output_to_analysis(container_id, file, **kwargs)


    def add_audit_trail_report(self, body, **kwargs):  # noqa: E501
        """Starts generation of an Audit Trail Report

        See ``AuditTrailApi.add_audit_trail_report()`` for parameter details.
        """
        return self.audit_trail_api.add_audit_trail_report(body, **kwargs)


    def delete_audit_trail_report(self, report_id, **kwargs):  # noqa: E501
        """Deletes an Audit Trail Report

        See ``AuditTrailApi.delete_audit_trail_report()`` for parameter details.
        """
        return self.audit_trail_api.delete_audit_trail_report(report_id, **kwargs)


    def download_audit_trail_report(self, report_id, **kwargs):  # noqa: E501
        """Download Audit Trail Report

        See ``AuditTrailApi.download_audit_trail_report()`` for parameter details.
        """
        return self.audit_trail_api.download_audit_trail_report(report_id, **kwargs)


    def list_audit_trail_reports(self, **kwargs):  # noqa: E501
        """List Audit Trail Reports

        See ``AuditTrailApi.list_audit_trail_reports()`` for parameter details.
        """
        return self.audit_trail_api.list_audit_trail_reports(**kwargs)


    def modify_audit_trail_report(self, report_id, body, **kwargs):  # noqa: E501
        """Modify an Audit Trail Report

        See ``AuditTrailApi.modify_audit_trail_report()`` for parameter details.
        """
        return self.audit_trail_api.modify_audit_trail_report(report_id, body, **kwargs)


    def get_auth_status(self, **kwargs):  # noqa: E501
        """Get Login status

        See ``AuthApi.get_auth_status()`` for parameter details.
        """
        return self.auth_api.get_auth_status(**kwargs)


    def cancel_batch(self, batch_id, **kwargs):  # noqa: E501
        """Cancel a Job

        See ``BatchApi.cancel_batch()`` for parameter details.
        """
        return self.batch_api.cancel_batch(batch_id, **kwargs)


    def create_batch_job_from_jobs(self, body, **kwargs):  # noqa: E501
        """Create a batch job proposal from preconstructed jobs and insert it as &#x27;pending&#x27;.

        See ``BatchApi.create_batch_job_from_jobs()`` for parameter details.
        """
        return self.batch_api.create_batch_job_from_jobs(body, **kwargs)


    def get_all_batches(self, **kwargs):  # noqa: E501
        """Get a list of batch jobs the user has created.

        See ``BatchApi.get_all_batches()`` for parameter details.
        """
        return self.batch_api.get_all_batches(**kwargs)


    def get_batch(self, batch_id, **kwargs):  # noqa: E501
        """Get batch job details.

        See ``BatchApi.get_batch()`` for parameter details.
        """
        return self.batch_api.get_batch(batch_id, **kwargs)


    def propose_batch(self, body, **kwargs):  # noqa: E501
        """Create a batch job proposal and insert it as &#x27;pending&#x27;.

        See ``BatchApi.propose_batch()`` for parameter details.
        """
        return self.batch_api.propose_batch(body, **kwargs)


    def start_batch(self, batch_id, **kwargs):  # noqa: E501
        """Launch a job.

        See ``BatchApi.start_batch()`` for parameter details.
        """
        return self.batch_api.start_batch(batch_id, **kwargs)


    def bulk_move_sessions(self, body, **kwargs):  # noqa: E501
        """Perform a bulk move of sessions to either a subject or project

        See ``BulkApi.bulk_move_sessions()`` for parameter details.
        """
        return self.bulk_api.bulk_move_sessions(body, **kwargs)


    def get_change_log(self, container_type, container_id, **kwargs):  # noqa: E501
        """Get Change Log

        See ``ChangeLogApi.get_change_log()`` for parameter details.
        """
        return self.change_log_api.get_change_log(container_type, container_id, **kwargs)


    def get_field_change_log(self, container_type, container_id, field, **kwargs):  # noqa: E501
        """Get change logs by specific field, in reverse chronological order

        See ``ChangeLogApi.get_field_change_log()`` for parameter details.
        """
        return self.change_log_api.get_field_change_log(container_type, container_id, field, **kwargs)


    def add_collection(self, body, **kwargs):  # noqa: E501
        """Create a collection

        See ``CollectionsApi.add_collection()`` for parameter details.
        """
        return self.collections_api.add_collection(body, **kwargs)


    def add_collection_note(self, container_id, body, **kwargs):  # noqa: E501
        """Add a note to a(n) collection.

        See ``CollectionsApi.add_collection_note()`` for parameter details.
        """
        return self.collections_api.add_collection_note(container_id, body, **kwargs)


    def add_collection_permission(self, collection_id, body, **kwargs):  # noqa: E501
        """Add a permission

        See ``CollectionsApi.add_collection_permission()`` for parameter details.
        """
        return self.collections_api.add_collection_permission(collection_id, body, **kwargs)


    def add_collection_tag(self, cid, body, **kwargs):  # noqa: E501
        """Add a tag to a(n) collection.

        See ``CollectionsApi.add_collection_tag()`` for parameter details.
        """
        return self.collections_api.add_collection_tag(cid, body, **kwargs)


    def add_collection_tags(self, cid, body, **kwargs):  # noqa: E501
        """Add multiple tags to a(n) collection

        See ``CollectionsApi.add_collection_tags()`` for parameter details.
        """
        return self.collections_api.add_collection_tags(cid, body, **kwargs)


    def delete_collection(self, collection_id, **kwargs):  # noqa: E501
        """Delete a collection

        See ``CollectionsApi.delete_collection()`` for parameter details.
        """
        return self.collections_api.delete_collection(collection_id, **kwargs)


    def delete_collection_file(self, cid, filename, **kwargs):  # noqa: E501
        """Delete a file

        See ``CollectionsApi.delete_collection_file()`` for parameter details.
        """
        return self.collections_api.delete_collection_file(cid, filename, **kwargs)


    def delete_collection_note(self, cid, note_id, **kwargs):  # noqa: E501
        """Remove a note from a(n) collection

        See ``CollectionsApi.delete_collection_note()`` for parameter details.
        """
        return self.collections_api.delete_collection_note(cid, note_id, **kwargs)


    def delete_collection_tag(self, cid, value, **kwargs):  # noqa: E501
        """Delete a tag

        See ``CollectionsApi.delete_collection_tag()`` for parameter details.
        """
        return self.collections_api.delete_collection_tag(cid, value, **kwargs)


    def delete_collection_tags(self, cid, body, **kwargs):  # noqa: E501
        """Delete multiple tags from a(n) collection

        See ``CollectionsApi.delete_collection_tags()`` for parameter details.
        """
        return self.collections_api.delete_collection_tags(cid, body, **kwargs)


    def delete_collection_user_permission(self, collection_id, user_id, **kwargs):  # noqa: E501
        """Delete a permission

        See ``CollectionsApi.delete_collection_user_permission()`` for parameter details.
        """
        return self.collections_api.delete_collection_user_permission(collection_id, user_id, **kwargs)


    def delete_collections_by_ids(self, body, **kwargs):  # noqa: E501
        """Delete multiple collections by ID list

        See ``CollectionsApi.delete_collections_by_ids()`` for parameter details.
        """
        return self.collections_api.delete_collections_by_ids(body, **kwargs)


    def download_file_from_collection(self, collection_id, file_name, dest_file, **kwargs):  # noqa: E501
        """Download a file.

        See ``CollectionsApi.download_file_from_collection()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.collections_api.download_file_from_collection(collection_id, file_name, dest_file, **kwargs)


    def get_collection_file_zip_info(self, collection_id, file_name, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``CollectionsApi.get_collection_file_zip_info()`` for parameter details.
        """
        return self.collections_api.get_collection_file_zip_info(collection_id, file_name, **kwargs)


    def get_collection_download_url(self, collection_id, file_name, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``CollectionsApi.get_collection_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.collections_api.get_collection_download_ticket(collection_id, file_name, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def get_all_collections(self, **kwargs):  # noqa: E501
        """List all collections.

        See ``CollectionsApi.get_all_collections()`` for parameter details.
        """
        return self.collections_api.get_all_collections(**kwargs)


    def get_all_collections_curators(self, **kwargs):  # noqa: E501
        """List all curators of collections

        See ``CollectionsApi.get_all_collections_curators()`` for parameter details.
        """
        return self.collections_api.get_all_collections_curators(**kwargs)


    def get_collection(self, collection_id, **kwargs):  # noqa: E501
        """Retrieve a single collection

        See ``CollectionsApi.get_collection()`` for parameter details.
        """
        return self.collections_api.get_collection(collection_id, **kwargs)


    def get_collection_acquisitions(self, collection_id, **kwargs):  # noqa: E501
        """List acquisitions in a collection

        See ``CollectionsApi.get_collection_acquisitions()`` for parameter details.
        """
        return self.collections_api.get_collection_acquisitions(collection_id, **kwargs)


    def get_collection_file_info(self, cid, filename, **kwargs):  # noqa: E501
        """Get info for a particular file.

        See ``CollectionsApi.get_collection_file_info()`` for parameter details.
        """
        return self.collections_api.get_collection_file_info(cid, filename, **kwargs)


    def get_collection_note(self, cid, note_id, **kwargs):  # noqa: E501
        """Get a note of a(n) collection.

        See ``CollectionsApi.get_collection_note()`` for parameter details.
        """
        return self.collections_api.get_collection_note(cid, note_id, **kwargs)


    def get_collection_sessions(self, collection_id, **kwargs):  # noqa: E501
        """List sessions in a collection

        See ``CollectionsApi.get_collection_sessions()`` for parameter details.
        """
        return self.collections_api.get_collection_sessions(collection_id, **kwargs)


    def get_collection_tag(self, cid, value, **kwargs):  # noqa: E501
        """Get the value of a tag, by name.

        See ``CollectionsApi.get_collection_tag()`` for parameter details.
        """
        return self.collections_api.get_collection_tag(cid, value, **kwargs)


    def get_collection_user_permission(self, collection_id, user_id, **kwargs):  # noqa: E501
        """List a user&#x27;s permissions for this group.

        See ``CollectionsApi.get_collection_user_permission()`` for parameter details.
        """
        return self.collections_api.get_collection_user_permission(collection_id, user_id, **kwargs)


    def modify_collection(self, collection_id, body, **kwargs):  # noqa: E501
        """Update a collection and its contents

        See ``CollectionsApi.modify_collection()`` for parameter details.
        """
        return self.collections_api.modify_collection(collection_id, body, **kwargs)


    def modify_collection_file(self, cid, filename, body, **kwargs):  # noqa: E501
        """Modify a file&#x27;s attributes

        See ``CollectionsApi.modify_collection_file()`` for parameter details.
        """
        return self.collections_api.modify_collection_file(cid, filename, body, **kwargs)


    def modify_collection_file_classification(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update classification for a particular file.

        See ``CollectionsApi.modify_collection_file_classification()`` for parameter details.
        """
        return self.collections_api.modify_collection_file_classification(cid, filename, body, **kwargs)


    def modify_collection_file_info(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update info for a particular file.

        See ``CollectionsApi.modify_collection_file_info()`` for parameter details.
        """
        return self.collections_api.modify_collection_file_info(cid, filename, body, **kwargs)


    def modify_collection_info(self, cid, body, **kwargs):  # noqa: E501
        """Update or replace info for a(n) collection.

        See ``CollectionsApi.modify_collection_info()`` for parameter details.
        """
        return self.collections_api.modify_collection_info(cid, body, **kwargs)


    def modify_collection_note(self, cid, note_id, body, **kwargs):  # noqa: E501
        """Update a note of a(n) collection.

        See ``CollectionsApi.modify_collection_note()`` for parameter details.
        """
        return self.collections_api.modify_collection_note(cid, note_id, body, **kwargs)


    def modify_collection_user_permission(self, collection_id, user_id, body, **kwargs):  # noqa: E501
        """Update a user&#x27;s permission for this group.

        See ``CollectionsApi.modify_collection_user_permission()`` for parameter details.
        """
        return self.collections_api.modify_collection_user_permission(collection_id, user_id, body, **kwargs)


    def rename_collection_tag(self, cid, value, body, **kwargs):  # noqa: E501
        """Rename a tag.

        See ``CollectionsApi.rename_collection_tag()`` for parameter details.
        """
        return self.collections_api.rename_collection_tag(cid, value, body, **kwargs)


    def upload_file_to_collection(self, container_id, file, signed=True, **kwargs):  # noqa: E501
        """Upload a file to a(n) collection.

        See ``CollectionsApi.upload_file_to_collection()`` for parameter details.
        :param signed: Use signed URL upload if available, defaults to True
        :type signed: bool, optional
        """
        if signed:
            signed_result = self.signed_upload_file_to_collection(container_id, file, **kwargs)
            if signed_result:
                return signed_result

        return self.collections_api.upload_file_to_collection(container_id, file, **kwargs)


    def get_config(self, **kwargs):  # noqa: E501
        """Get public configuration

        See ``ConfigApi.get_config()`` for parameter details.
        """
        return self.config_api.get_config(**kwargs)


    def get_config_js(self, **kwargs):  # noqa: E501
        """Return public Scitran configuration information in javascript format.

        See ``ConfigApi.get_config_js()`` for parameter details.
        """
        return self.config_api.get_config_js(**kwargs)


    def get_version(self, **kwargs):  # noqa: E501
        """Get server and database schema version info

        See ``ConfigApi.get_version()`` for parameter details.
        """
        return self.config_api.get_version(**kwargs)


    def get_task_parent_container_ids(self, ids, container_type, **kwargs):  # noqa: E501
        """Get Task Parent Container Ids

        See ``ContainerTasksApi.get_task_parent_container_ids()`` for parameter details.
        """
        return self.container_tasks_api.get_task_parent_container_ids(ids, container_type, **kwargs)


    def cleanup_info(self, container_type, path, **kwargs):  # noqa: E501
        """Remove a custom field from all applicable containers

        See ``ContainerTypeApi.cleanup_info()`` for parameter details.
        """
        return self.container_type_api.cleanup_info(container_type, path, **kwargs)


    def add_container_analysis(self, cid, body, **kwargs):  # noqa: E501
        """Create an analysis and upload files.

        See ``ContainersApi.add_container_analysis()`` for parameter details.
        """
        return self.containers_api.add_container_analysis(cid, body, **kwargs)


    def add_container_analysis_note(self, container_id, analysis_id, body, **kwargs):  # noqa: E501
        """Add a note to a(n) container analysis.

        See ``ContainersApi.add_container_analysis_note()`` for parameter details.
        """
        return self.containers_api.add_container_analysis_note(container_id, analysis_id, body, **kwargs)


    def add_container_note(self, container_id, body, **kwargs):  # noqa: E501
        """Add a note to a(n) container.

        See ``ContainersApi.add_container_note()`` for parameter details.
        """
        return self.containers_api.add_container_note(container_id, body, **kwargs)


    def add_container_tag(self, cid, body, **kwargs):  # noqa: E501
        """Add a tag to a(n) container.

        See ``ContainersApi.add_container_tag()`` for parameter details.
        """
        return self.containers_api.add_container_tag(cid, body, **kwargs)


    def add_container_tags(self, cid, body, **kwargs):  # noqa: E501
        """Add multiple tags to a(n) container

        See ``ContainersApi.add_container_tags()`` for parameter details.
        """
        return self.containers_api.add_container_tags(cid, body, **kwargs)


    def add_view(self, container_id, body, **kwargs):  # noqa: E501
        """Add a new data view

        See ``ContainersApi.add_view()`` for parameter details.
        """
        return self.containers_api.add_view(container_id, body, **kwargs)


    def delete_container(self, container_id, **kwargs):  # noqa: E501
        """Delete a container

        See ``ContainersApi.delete_container()`` for parameter details.
        """
        return self.containers_api.delete_container(container_id, **kwargs)


    def delete_container_analysis(self, cid, analysis_id, **kwargs):  # noqa: E501
        """Delete an analysis

        See ``ContainersApi.delete_container_analysis()`` for parameter details.
        """
        return self.containers_api.delete_container_analysis(cid, analysis_id, **kwargs)


    def delete_container_analysis_note(self, cid, analysis_id, note_id, **kwargs):  # noqa: E501
        """Remove a note from a(n) container analysis.

        See ``ContainersApi.delete_container_analysis_note()`` for parameter details.
        """
        return self.containers_api.delete_container_analysis_note(cid, analysis_id, note_id, **kwargs)


    def delete_container_file(self, cid, filename, **kwargs):  # noqa: E501
        """Delete a file

        See ``ContainersApi.delete_container_file()`` for parameter details.
        """
        return self.containers_api.delete_container_file(cid, filename, **kwargs)


    def delete_container_note(self, cid, note_id, **kwargs):  # noqa: E501
        """Remove a note from a(n) container

        See ``ContainersApi.delete_container_note()`` for parameter details.
        """
        return self.containers_api.delete_container_note(cid, note_id, **kwargs)


    def delete_container_tag(self, cid, value, **kwargs):  # noqa: E501
        """Delete a tag

        See ``ContainersApi.delete_container_tag()`` for parameter details.
        """
        return self.containers_api.delete_container_tag(cid, value, **kwargs)


    def delete_container_tags(self, cid, body, **kwargs):  # noqa: E501
        """Delete multiple tags from a(n) container

        See ``ContainersApi.delete_container_tags()`` for parameter details.
        """
        return self.containers_api.delete_container_tags(cid, body, **kwargs)


    def download_file_from_container(self, container_id, file_name, dest_file, **kwargs):  # noqa: E501
        """Download a file.

        See ``ContainersApi.download_file_from_container()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.containers_api.download_file_from_container(container_id, file_name, dest_file, **kwargs)


    def get_container_file_zip_info(self, container_id, file_name, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``ContainersApi.get_container_file_zip_info()`` for parameter details.
        """
        return self.containers_api.get_container_file_zip_info(container_id, file_name, **kwargs)


    def get_container_download_url(self, container_id, file_name, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``ContainersApi.get_container_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.containers_api.get_container_download_ticket(container_id, file_name, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def download_input_from_container_analysis(self, container_id, analysis_id, filename, dest_file, **kwargs):  # noqa: E501
        """Download analysis inputs with filter.

        See ``ContainersApi.download_input_from_container_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.containers_api.download_input_from_container_analysis(container_id, analysis_id, filename, dest_file, **kwargs)


    def get_container_analysis_input_zip_info(self, container_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``ContainersApi.get_container_analysis_input_zip_info()`` for parameter details.
        """
        return self.containers_api.get_container_analysis_input_zip_info(container_id, analysis_id, filename, **kwargs)


    def get_container_analysis_input_download_url(self, container_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``ContainersApi.get_container_analysis_input_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.containers_api.get_container_analysis_input_download_ticket(container_id, analysis_id, filename, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def download_output_from_container_analysis(self, container_id, analysis_id, filename, dest_file, **kwargs):  # noqa: E501
        """Download analysis outputs with filter.

        See ``ContainersApi.download_output_from_container_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.containers_api.download_output_from_container_analysis(container_id, analysis_id, filename, dest_file, **kwargs)


    def get_container_analysis_output_zip_info(self, container_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``ContainersApi.get_container_analysis_output_zip_info()`` for parameter details.
        """
        return self.containers_api.get_container_analysis_output_zip_info(container_id, analysis_id, filename, **kwargs)


    def get_container_analysis_output_download_url(self, container_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``ContainersApi.get_container_analysis_output_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.containers_api.get_container_analysis_output_download_ticket(container_id, analysis_id, filename, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def get_container(self, container_id, **kwargs):  # noqa: E501
        """Retrieve a single container

        See ``ContainersApi.get_container()`` for parameter details.
        """
        return self.containers_api.get_container(container_id, **kwargs)


    def get_container_analyses(self, cid, **kwargs):  # noqa: E501
        """Get analyses for a(n) container.

        See ``ContainersApi.get_container_analyses()`` for parameter details.
        """
        return self.containers_api.get_container_analyses(cid, **kwargs)


    def get_container_analysis(self, cid, analysis_id, **kwargs):  # noqa: E501
        """Get an analysis.

        See ``ContainersApi.get_container_analysis()`` for parameter details.
        """
        return self.containers_api.get_container_analysis(cid, analysis_id, **kwargs)


    def get_container_file_info(self, cid, filename, **kwargs):  # noqa: E501
        """Get info for a particular file.

        See ``ContainersApi.get_container_file_info()`` for parameter details.
        """
        return self.containers_api.get_container_file_info(cid, filename, **kwargs)


    def get_container_note(self, cid, note_id, **kwargs):  # noqa: E501
        """Get a note of a(n) container.

        See ``ContainersApi.get_container_note()`` for parameter details.
        """
        return self.containers_api.get_container_note(cid, note_id, **kwargs)


    def get_container_tag(self, cid, value, **kwargs):  # noqa: E501
        """Get the value of a tag, by name.

        See ``ContainersApi.get_container_tag()`` for parameter details.
        """
        return self.containers_api.get_container_tag(cid, value, **kwargs)


    def get_views(self, container_id, **kwargs):  # noqa: E501
        """Return a list of all views belonging to container

        See ``ContainersApi.get_views()`` for parameter details.
        """
        return self.containers_api.get_views(container_id, **kwargs)


    def modify_container(self, container_id, body, **kwargs):  # noqa: E501
        """Update a container and its contents

        See ``ContainersApi.modify_container()`` for parameter details.
        """
        return self.containers_api.modify_container(container_id, body, **kwargs)


    def modify_container_analysis(self, cid, analysis_id, body, **kwargs):  # noqa: E501
        """Modify an analysis.

        See ``ContainersApi.modify_container_analysis()`` for parameter details.
        """
        return self.containers_api.modify_container_analysis(cid, analysis_id, body, **kwargs)


    def modify_container_file(self, cid, filename, body, **kwargs):  # noqa: E501
        """Modify a file&#x27;s attributes

        See ``ContainersApi.modify_container_file()`` for parameter details.
        """
        return self.containers_api.modify_container_file(cid, filename, body, **kwargs)


    def modify_container_file_classification(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update classification for a particular file.

        See ``ContainersApi.modify_container_file_classification()`` for parameter details.
        """
        return self.containers_api.modify_container_file_classification(cid, filename, body, **kwargs)


    def modify_container_file_info(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update info for a particular file.

        See ``ContainersApi.modify_container_file_info()`` for parameter details.
        """
        return self.containers_api.modify_container_file_info(cid, filename, body, **kwargs)


    def modify_container_info(self, cid, body, **kwargs):  # noqa: E501
        """Update or replace info for a(n) container.

        See ``ContainersApi.modify_container_info()`` for parameter details.
        """
        return self.containers_api.modify_container_info(cid, body, **kwargs)


    def modify_container_note(self, cid, note_id, body, **kwargs):  # noqa: E501
        """Update a note of a(n) container.

        See ``ContainersApi.modify_container_note()`` for parameter details.
        """
        return self.containers_api.modify_container_note(cid, note_id, body, **kwargs)


    def rename_container_tag(self, cid, value, body, **kwargs):  # noqa: E501
        """Rename a tag.

        See ``ContainersApi.rename_container_tag()`` for parameter details.
        """
        return self.containers_api.rename_container_tag(cid, value, body, **kwargs)


    def upload_file_to_container(self, container_id, file, signed=True, **kwargs):  # noqa: E501
        """Upload a file to a(n) container.

        See ``ContainersApi.upload_file_to_container()`` for parameter details.
        :param signed: Use signed URL upload if available, defaults to True
        :type signed: bool, optional
        """
        if signed:
            signed_result = self.signed_upload_file_to_container(container_id, file, **kwargs)
            if signed_result:
                return signed_result

        return self.containers_api.upload_file_to_container(container_id, file, **kwargs)


    def upload_output_to_container_analysis(self, cid, analysis_id, file, signed=True, **kwargs):  # noqa: E501
        """Upload an output file to an analysis.

        See ``ContainersApi.upload_output_to_container_analysis()`` for parameter details.
        :param signed: Use signed URL upload if available, defaults to True
        :type signed: bool, optional
        """
        if signed:
            signed_result = self.signed_upload_output_to_container_analysis(cid, analysis_id, file, **kwargs)
            if signed_result:
                return signed_result

        return self.containers_api.upload_output_to_container_analysis(cid, analysis_id, file, **kwargs)


    def create_custom_filter(self, body, **kwargs):  # noqa: E501
        """Create a custom filter for user

        See ``CustomFiltersApi.create_custom_filter()`` for parameter details.
        """
        return self.custom_filters_api.create_custom_filter(body, **kwargs)


    def delete_custom_filter(self, custom_filter_id, **kwargs):  # noqa: E501
        """Delete a custom filter for user

        See ``CustomFiltersApi.delete_custom_filter()`` for parameter details.
        """
        return self.custom_filters_api.delete_custom_filter(custom_filter_id, **kwargs)


    def get_all_custom_filters(self, **kwargs):  # noqa: E501
        """Get all custom filters for user

        See ``CustomFiltersApi.get_all_custom_filters()`` for parameter details.
        """
        return self.custom_filters_api.get_all_custom_filters(**kwargs)


    def update_custom_filter(self, custom_filter_id, body, **kwargs):  # noqa: E501
        """Update a custom filter for user

        See ``CustomFiltersApi.update_custom_filter()`` for parameter details.
        """
        return self.custom_filters_api.update_custom_filter(custom_filter_id, body, **kwargs)


    def delete_view_execution(self, data_view_execution_id, **kwargs):  # noqa: E501
        """Delete a data_view_execution

        See ``DataViewExecutionsApi.delete_view_execution()`` for parameter details.
        """
        return self.data_view_executions_api.delete_view_execution(data_view_execution_id, **kwargs)


    def get_all_data_view_executions(self, **kwargs):  # noqa: E501
        """Get a list of data_view_executions

        See ``DataViewExecutionsApi.get_all_data_view_executions()`` for parameter details.
        """
        return self.data_view_executions_api.get_all_data_view_executions(**kwargs)


    def get_data_view_execution(self, data_view_execution_id, **kwargs):  # noqa: E501
        """Get a single data_view_execution

        See ``DataViewExecutionsApi.get_data_view_execution()`` for parameter details.
        """
        return self.data_view_executions_api.get_data_view_execution(data_view_execution_id, **kwargs)


    def get_data_view_execution_data(self, data_view_execution_id, **kwargs):  # noqa: E501
        """Get the data from a data_view_execution

        See ``DataViewExecutionsApi.get_data_view_execution_data()`` for parameter details.
        """
        return self.data_view_executions_api.get_data_view_execution_data(data_view_execution_id, **kwargs)


    def save_data_view_execution(self, data_view_execution_id, **kwargs):  # noqa: E501
        """Save a data_view_execution to a project

        See ``DataViewExecutionsApi.save_data_view_execution()`` for parameter details.
        """
        return self.data_view_executions_api.save_data_view_execution(data_view_execution_id, **kwargs)


    def delete_by_search(self, body, **kwargs):  # noqa: E501
        """Delete containers by a search query

        See ``DataexplorerApi.delete_by_search()`` for parameter details.
        """
        return self.dataexplorer_api.delete_by_search(body, **kwargs)


    def delete_save_search(self, search_id, **kwargs):  # noqa: E501
        """Delete a saved search

        See ``DataexplorerApi.delete_save_search()`` for parameter details.
        """
        return self.dataexplorer_api.delete_save_search(search_id, **kwargs)


    def get_all_saved_searches(self, **kwargs):  # noqa: E501
        """Get Queries

        See ``DataexplorerApi.get_all_saved_searches()`` for parameter details.
        """
        return self.dataexplorer_api.get_all_saved_searches(**kwargs)


    def get_mapped_fields(self, **kwargs):  # noqa: E501
        """Get fields mapped for search

        See ``DataexplorerApi.get_mapped_fields()`` for parameter details.
        """
        return self.dataexplorer_api.get_mapped_fields(**kwargs)


    def get_saved_search(self, sid, **kwargs):  # noqa: E501
        """Return a saved search query

        See ``DataexplorerApi.get_saved_search()`` for parameter details.
        """
        return self.dataexplorer_api.get_saved_search(sid, **kwargs)


    def get_search_query_suggestions(self, body, **kwargs):  # noqa: E501
        """Get suggestions for a structured search query

        See ``DataexplorerApi.get_search_query_suggestions()`` for parameter details.
        """
        return self.dataexplorer_api.get_search_query_suggestions(body, **kwargs)


    def get_search_status(self, **kwargs):  # noqa: E501
        """Get the status of search (Mongo Connector)

        See ``DataexplorerApi.get_search_status()`` for parameter details.
        """
        return self.dataexplorer_api.get_search_status(**kwargs)


    def parse_search_query(self, body, **kwargs):  # noqa: E501
        """Parse a structured search query

        See ``DataexplorerApi.parse_search_query()`` for parameter details.
        """
        return self.dataexplorer_api.parse_search_query(body, **kwargs)


    def replace_search(self, sid, body, **kwargs):  # noqa: E501
        """Replace a search query

        See ``DataexplorerApi.replace_search()`` for parameter details.
        """
        return self.dataexplorer_api.replace_search(sid, body, **kwargs)


    def save_search(self, body, **kwargs):  # noqa: E501
        """Save a search query

        See ``DataexplorerApi.save_search()`` for parameter details.
        """
        return self.dataexplorer_api.save_search(body, **kwargs)


    def search(self, body, **kwargs):  # noqa: E501
        """Perform a search query

        See ``DataexplorerApi.search()`` for parameter details.
        """
        return self.dataexplorer_api.search(body, **kwargs)


    def create_device(self, body, **kwargs):  # noqa: E501
        """Create a new device.

        See ``DevicesApi.create_device()`` for parameter details.
        """
        return self.devices_api.create_device(body, **kwargs)


    def delete_device(self, device_id, **kwargs):  # noqa: E501
        """Delete a device

        See ``DevicesApi.delete_device()`` for parameter details.
        """
        return self.devices_api.delete_device(device_id, **kwargs)


    def delete_device_key(self, device_id, key_id, **kwargs):  # noqa: E501
        """Delete Device Key

        See ``DevicesApi.delete_device_key()`` for parameter details.
        """
        return self.devices_api.delete_device_key(device_id, key_id, **kwargs)


    def generate_key(self, device_id, **kwargs):  # noqa: E501
        """Generate device API key

        See ``DevicesApi.generate_key()`` for parameter details.
        """
        return self.devices_api.generate_key(device_id, **kwargs)


    def get_all_devices(self, **kwargs):  # noqa: E501
        """List all devices.

        See ``DevicesApi.get_all_devices()`` for parameter details.
        """
        return self.devices_api.get_all_devices(**kwargs)


    def get_all_devices_status(self, **kwargs):  # noqa: E501
        """Get status for all known devices.

        See ``DevicesApi.get_all_devices_status()`` for parameter details.
        """
        return self.devices_api.get_all_devices_status(**kwargs)


    def get_current_device(self, **kwargs):  # noqa: E501
        """Get current device.

        See ``DevicesApi.get_current_device()`` for parameter details.
        """
        return self.devices_api.get_current_device(**kwargs)


    def get_device(self, device_id, **kwargs):  # noqa: E501
        """Get device details

        See ``DevicesApi.get_device()`` for parameter details.
        """
        return self.devices_api.get_device(device_id, **kwargs)


    def modify_device(self, device_id, body, **kwargs):  # noqa: E501
        """Update a device

        See ``DevicesApi.modify_device()`` for parameter details.
        """
        return self.devices_api.modify_device(device_id, body, **kwargs)


    def update_device(self, body, **kwargs):  # noqa: E501
        """Modify a device&#x27;s type, name, interval, info or set errors.

        See ``DevicesApi.update_device()`` for parameter details.
        """
        return self.devices_api.update_device(body, **kwargs)


    def create_project_aet(self, body, **kwargs):  # noqa: E501
        """Create a new DIMSE project AET

        See ``DimseApi.create_project_aet()`` for parameter details.
        """
        return self.dimse_api.create_project_aet(body, **kwargs)


    def create_service_aet(self, body, **kwargs):  # noqa: E501
        """Create a new DIMSE service AET

        See ``DimseApi.create_service_aet()`` for parameter details.
        """
        return self.dimse_api.create_service_aet(body, **kwargs)


    def delete_project_aet(self, project_aet, **kwargs):  # noqa: E501
        """Delete a DIMSE project AET

        See ``DimseApi.delete_project_aet()`` for parameter details.
        """
        return self.dimse_api.delete_project_aet(project_aet, **kwargs)


    def delete_service_aet(self, service_aet, **kwargs):  # noqa: E501
        """Delete a DIMSE service AET

        See ``DimseApi.delete_service_aet()`` for parameter details.
        """
        return self.dimse_api.delete_service_aet(service_aet, **kwargs)


    def get_all_project_aets(self, **kwargs):  # noqa: E501
        """List all DIMSE project AETs

        See ``DimseApi.get_all_project_aets()`` for parameter details.
        """
        return self.dimse_api.get_all_project_aets(**kwargs)


    def get_all_service_aets(self, **kwargs):  # noqa: E501
        """List all DIMSE services AETs

        See ``DimseApi.get_all_service_aets()`` for parameter details.
        """
        return self.dimse_api.get_all_service_aets(**kwargs)


    def get_project_aet(self, project_aet, **kwargs):  # noqa: E501
        """Get DIMSE project AET

        See ``DimseApi.get_project_aet()`` for parameter details.
        """
        return self.dimse_api.get_project_aet(project_aet, **kwargs)


    def get_service_aet(self, service_aet, **kwargs):  # noqa: E501
        """Get DIMSE service by AET or id

        See ``DimseApi.get_service_aet()`` for parameter details.
        """
        return self.dimse_api.get_service_aet(service_aet, **kwargs)


    def create_download_ticket(self, body, **kwargs):  # noqa: E501
        """Create a download ticket

        See ``DownloadApi.create_download_ticket()`` for parameter details.
        """
        return self.download_api.create_download_ticket(body, **kwargs)


    def download_ticket(self, ticket, dest_file, **kwargs):  # noqa: E501
        """Download files listed in the given ticket.

        See ``DownloadApi.download_ticket()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.download_api.download_ticket(ticket, dest_file, **kwargs)


    def add_file_tags(self, file_id, body, **kwargs):  # noqa: E501
        """Add list of tags on a file.

        See ``FilesApi.add_file_tags()`` for parameter details.
        """
        return self.files_api.add_file_tags(file_id, body, **kwargs)


    def delete_file(self, file_id, **kwargs):  # noqa: E501
        """Delete a File

        See ``FilesApi.delete_file()`` for parameter details.
        """
        return self.files_api.delete_file(file_id, **kwargs)


    def delete_file_tags(self, file_id, **kwargs):  # noqa: E501
        """Remove the specified tags from most recent file version

        See ``FilesApi.delete_file_tags()`` for parameter details.
        """
        return self.files_api.delete_file_tags(file_id, **kwargs)


    def delete_files_by_ids(self, body, **kwargs):  # noqa: E501
        """Delete multiple files by ID list

        See ``FilesApi.delete_files_by_ids()`` for parameter details.
        """
        return self.files_api.delete_files_by_ids(body, **kwargs)


    def get_all_files(self, **kwargs):  # noqa: E501
        """Return all files

        See ``FilesApi.get_all_files()`` for parameter details.
        """
        return self.files_api.get_all_files(**kwargs)


    def get_file(self, file_id, **kwargs):  # noqa: E501
        """Get File

        See ``FilesApi.get_file()`` for parameter details.
        """
        return self.files_api.get_file(file_id, **kwargs)


    def get_file_info(self, file_id, **kwargs):  # noqa: E501
        """Get Info

        See ``FilesApi.get_file_info()`` for parameter details.
        """
        return self.files_api.get_file_info(file_id, **kwargs)


    def get_file_tags(self, file_id, **kwargs):  # noqa: E501
        """Return a file tags, from any version

        See ``FilesApi.get_file_tags()`` for parameter details.
        """
        return self.files_api.get_file_tags(file_id, **kwargs)


    def get_file_versions(self, file_id, **kwargs):  # noqa: E501
        """Get Versions

        See ``FilesApi.get_file_versions()`` for parameter details.
        """
        return self.files_api.get_file_versions(file_id, **kwargs)


    def get_file_zip_info(self, file_id, **kwargs):  # noqa: E501
        """Get Zip Info

        See ``FilesApi.get_file_zip_info()`` for parameter details.
        """
        return self.files_api.get_file_zip_info(file_id, **kwargs)


    def modify_file_classification(self, file_id, body, **kwargs):  # noqa: E501
        """Modify Classification

        See ``FilesApi.modify_file_classification()`` for parameter details.
        """
        return self.files_api.modify_file_classification(file_id, body, **kwargs)


    def modify_file_info(self, file_id, **kwargs):  # noqa: E501
        """Modify Info

        See ``FilesApi.modify_file_info()`` for parameter details.
        """
        return self.files_api.modify_file_info(file_id, **kwargs)


    def move_file(self, file_id, body, **kwargs):  # noqa: E501
        """Move and/or rename a file

        See ``FilesApi.move_file()`` for parameter details.
        """
        return self.files_api.move_file(file_id, body, **kwargs)


    def replace_file_info(self, file_id, **kwargs):  # noqa: E501
        """Replace Info

        See ``FilesApi.replace_file_info()`` for parameter details.
        """
        return self.files_api.replace_file_info(file_id, **kwargs)


    def restore_file(self, file_id, version, evaluate_gear_rules, **kwargs):  # noqa: E501
        """Restore a File

        See ``FilesApi.restore_file()`` for parameter details.
        """
        return self.files_api.restore_file(file_id, version, evaluate_gear_rules, **kwargs)


    def set_file_tags(self, file_id, body, **kwargs):  # noqa: E501
        """Set list of tags on a file.

        See ``FilesApi.set_file_tags()`` for parameter details.
        """
        return self.files_api.set_file_tags(file_id, body, **kwargs)


    def upsert_file(self, body, **kwargs):  # noqa: E501
        """Upsert a File

        See ``FilesApi.upsert_file()`` for parameter details.
        """
        return self.files_api.upsert_file(body, **kwargs)


    def create_or_replace_task_response(self, task_id, body, **kwargs):  # noqa: E501
        """Create or replace a response for a task (409 if submitted)

        See ``FormResponsesApi.create_or_replace_task_response()`` for parameter details.
        """
        return self.form_responses_api.create_or_replace_task_response(task_id, body, **kwargs)


    def get_response(self, response_id, **kwargs):  # noqa: E501
        """Retrieve a specific response

        See ``FormResponsesApi.get_response()`` for parameter details.
        """
        return self.form_responses_api.get_response(response_id, **kwargs)


    def list_task_responses(self, task_id, **kwargs):  # noqa: E501
        """List all responses for a given task

        See ``FormResponsesApi.list_task_responses()`` for parameter details.
        """
        return self.form_responses_api.list_task_responses(task_id, **kwargs)


    def put_task_response(self, task_id, response_id, body, **kwargs):  # noqa: E501
        """Create or replace a response for a task (409 if submitted)

        See ``FormResponsesApi.put_task_response()`` for parameter details.
        """
        return self.form_responses_api.put_task_response(task_id, response_id, body, **kwargs)


    def submit_response(self, response_id, **kwargs):  # noqa: E501
        """Submit a response. Validate against form schema and lock it

        See ``FormResponsesApi.submit_response()`` for parameter details.
        """
        return self.form_responses_api.submit_response(response_id, **kwargs)


    def update_response(self, response_id, body, **kwargs):  # noqa: E501
        """Update a response only if not submitted

        See ``FormResponsesApi.update_response()`` for parameter details.
        """
        return self.form_responses_api.update_response(response_id, body, **kwargs)


    def add_gear(self, gear_name, body, **kwargs):  # noqa: E501
        """Create or update a gear.

        See ``GearsApi.add_gear()`` for parameter details.
        """
        return self.gears_api.add_gear(gear_name, body, **kwargs)


    def add_gear_permission(self, gear_name, permission_type, body, **kwargs):  # noqa: E501
        """Add an individual permission to the given gear

        See ``GearsApi.add_gear_permission()`` for parameter details.
        """
        return self.gears_api.add_gear_permission(gear_name, permission_type, body, **kwargs)


    def delete_gear(self, gear_id, **kwargs):  # noqa: E501
        """Delete a gear (not recommended)

        See ``GearsApi.delete_gear()`` for parameter details.
        """
        return self.gears_api.delete_gear(gear_id, **kwargs)


    def delete_gear_permission(self, gear_name, permission_type, permission_id, **kwargs):  # noqa: E501
        """Delete an individual permission of the given gear

        See ``GearsApi.delete_gear_permission()`` for parameter details.
        """
        return self.gears_api.delete_gear_permission(gear_name, permission_type, permission_id, **kwargs)


    def delete_gear_permissions(self, gear_name, **kwargs):  # noqa: E501
        """Delete permissions of the given gear

        See ``GearsApi.delete_gear_permissions()`` for parameter details.
        """
        return self.gears_api.delete_gear_permissions(gear_name, **kwargs)


    def get_all_gears(self, **kwargs):  # noqa: E501
        """List all gears

        See ``GearsApi.get_all_gears()`` for parameter details.
        """
        return self.gears_api.get_all_gears(**kwargs)


    def get_gear(self, gear_id, **kwargs):  # noqa: E501
        """Retrieve details about a specific gear

        See ``GearsApi.get_gear()`` for parameter details.
        """
        return self.gears_api.get_gear(gear_id, **kwargs)


    def get_gear_context(self, gear_id, container_name, container_id, **kwargs):  # noqa: E501
        """Get context values for the given gear and container.

        See ``GearsApi.get_gear_context()`` for parameter details.
        """
        return self.gears_api.get_gear_context(gear_id, container_name, container_id, **kwargs)


    def get_gear_invocation(self, gear_id, **kwargs):  # noqa: E501
        """Get a schema for invoking a gear

        See ``GearsApi.get_gear_invocation()`` for parameter details.
        """
        return self.gears_api.get_gear_invocation(gear_id, **kwargs)


    def get_gear_series(self, gear_name, **kwargs):  # noqa: E501
        """Get gear series.

        See ``GearsApi.get_gear_series()`` for parameter details.
        """
        return self.gears_api.get_gear_series(gear_name, **kwargs)


    def get_gear_suggest(self, gear_id, container_name, container_id, **kwargs):  # noqa: E501
        """Get files with input suggestions, parent containers, and child containers for the given container.

        See ``GearsApi.get_gear_suggest()`` for parameter details.
        """
        return self.gears_api.get_gear_suggest(gear_id, container_name, container_id, **kwargs)


    def get_gear_ticket(self, ticket_id, **kwargs):  # noqa: E501
        """Retrieve a specific gear ticket

        See ``GearsApi.get_gear_ticket()`` for parameter details.
        """
        return self.gears_api.get_gear_ticket(ticket_id, **kwargs)


    def get_my_gear_tickets(self, **kwargs):  # noqa: E501
        """Retrieve all gear tickets for the current user

        See ``GearsApi.get_my_gear_tickets()`` for parameter details.
        """
        return self.gears_api.get_my_gear_tickets(**kwargs)


    def modify_gear_series(self, gear_name, body, **kwargs):  # noqa: E501
        """Update a gear series

        See ``GearsApi.modify_gear_series()`` for parameter details.
        """
        return self.gears_api.modify_gear_series(gear_name, body, **kwargs)


    def prepare_add_gear(self, body, **kwargs):  # noqa: E501
        """Prepare a gear upload

        See ``GearsApi.prepare_add_gear()`` for parameter details.
        """
        return self.gears_api.prepare_add_gear(body, **kwargs)


    def replace_gear_permissions(self, gear_name, body, **kwargs):  # noqa: E501
        """Replace permissions for the given gear

        See ``GearsApi.replace_gear_permissions()`` for parameter details.
        """
        return self.gears_api.replace_gear_permissions(gear_name, body, **kwargs)


    def save_gear(self, body, **kwargs):  # noqa: E501
        """Report the result of a gear upload and save the ticket

        See ``GearsApi.save_gear()`` for parameter details.
        """
        return self.gears_api.save_gear(body, **kwargs)


    def add_group(self, body, **kwargs):  # noqa: E501
        """Add a group

        See ``GroupsApi.add_group()`` for parameter details.
        """
        return self.groups_api.add_group(body, **kwargs)


    def add_group_permission(self, group_id, body, **kwargs):  # noqa: E501
        """Add a permission

        See ``GroupsApi.add_group_permission()`` for parameter details.
        """
        return self.groups_api.add_group_permission(group_id, body, **kwargs)


    def add_group_permission_template(self, group_id, body, **kwargs):  # noqa: E501
        """Add a permission template

        See ``GroupsApi.add_group_permission_template()`` for parameter details.
        """
        return self.groups_api.add_group_permission_template(group_id, body, **kwargs)


    def add_group_tag(self, cid, body, **kwargs):  # noqa: E501
        """Add a tag to a(n) group.

        See ``GroupsApi.add_group_tag()`` for parameter details.
        """
        return self.groups_api.add_group_tag(cid, body, **kwargs)


    def add_group_tags(self, cid, body, **kwargs):  # noqa: E501
        """Add multiple tags to a(n) group

        See ``GroupsApi.add_group_tags()`` for parameter details.
        """
        return self.groups_api.add_group_tags(cid, body, **kwargs)


    def add_role_to_group(self, group_id, body, **kwargs):  # noqa: E501
        """Add a role to the pool of roles in a group

        See ``GroupsApi.add_role_to_group()`` for parameter details.
        """
        return self.groups_api.add_role_to_group(group_id, body, **kwargs)


    def delete_group(self, group_id, **kwargs):  # noqa: E501
        """Delete group

        See ``GroupsApi.delete_group()`` for parameter details.
        """
        return self.groups_api.delete_group(group_id, **kwargs)


    def delete_group_tag(self, cid, value, **kwargs):  # noqa: E501
        """Delete a tag

        See ``GroupsApi.delete_group_tag()`` for parameter details.
        """
        return self.groups_api.delete_group_tag(cid, value, **kwargs)


    def delete_group_tags(self, cid, body, **kwargs):  # noqa: E501
        """Delete multiple tags from a(n) group

        See ``GroupsApi.delete_group_tags()`` for parameter details.
        """
        return self.groups_api.delete_group_tags(cid, body, **kwargs)


    def delete_group_user_permission(self, group_id, user_id, **kwargs):  # noqa: E501
        """Delete a permission

        See ``GroupsApi.delete_group_user_permission()`` for parameter details.
        """
        return self.groups_api.delete_group_user_permission(group_id, user_id, **kwargs)


    def delete_group_user_permission_template(self, group_id, user_id, **kwargs):  # noqa: E501
        """Delete a permission

        See ``GroupsApi.delete_group_user_permission_template()`` for parameter details.
        """
        return self.groups_api.delete_group_user_permission_template(group_id, user_id, **kwargs)


    def delete_groups_by_ids(self, body, **kwargs):  # noqa: E501
        """Delete multiple groups by ID list

        See ``GroupsApi.delete_groups_by_ids()`` for parameter details.
        """
        return self.groups_api.delete_groups_by_ids(body, **kwargs)


    def get_all_group_roles(self, group_id, **kwargs):  # noqa: E501
        """Get list of group roles

        See ``GroupsApi.get_all_group_roles()`` for parameter details.
        """
        return self.groups_api.get_all_group_roles(group_id, **kwargs)


    def get_all_groups(self, **kwargs):  # noqa: E501
        """List all groups

        See ``GroupsApi.get_all_groups()`` for parameter details.
        """
        return self.groups_api.get_all_groups(**kwargs)


    def get_group(self, group_id, **kwargs):  # noqa: E501
        """Get group info

        See ``GroupsApi.get_group()`` for parameter details.
        """
        return self.groups_api.get_group(group_id, **kwargs)


    def get_group_projects(self, group_id, **kwargs):  # noqa: E501
        """Get all projects in a group

        See ``GroupsApi.get_group_projects()`` for parameter details.
        """
        return self.groups_api.get_group_projects(group_id, **kwargs)


    def get_group_role(self, group_id, role_id, **kwargs):  # noqa: E501
        """Return the role identified by the RoleId

        See ``GroupsApi.get_group_role()`` for parameter details.
        """
        return self.groups_api.get_group_role(group_id, role_id, **kwargs)


    def get_group_tag(self, cid, value, **kwargs):  # noqa: E501
        """Get the value of a tag, by name.

        See ``GroupsApi.get_group_tag()`` for parameter details.
        """
        return self.groups_api.get_group_tag(cid, value, **kwargs)


    def get_group_user_permission(self, group_id, user_id, **kwargs):  # noqa: E501
        """List a user&#x27;s permissions for this group.

        See ``GroupsApi.get_group_user_permission()`` for parameter details.
        """
        return self.groups_api.get_group_user_permission(group_id, user_id, **kwargs)


    def get_group_user_permission_template(self, group_id, user_id, **kwargs):  # noqa: E501
        """List a user&#x27;s permissions for this group.

        See ``GroupsApi.get_group_user_permission_template()`` for parameter details.
        """
        return self.groups_api.get_group_user_permission_template(group_id, user_id, **kwargs)


    def modify_group(self, group_id, body, **kwargs):  # noqa: E501
        """Update group

        See ``GroupsApi.modify_group()`` for parameter details.
        """
        return self.groups_api.modify_group(group_id, body, **kwargs)


    def modify_group_user_permission(self, group_id, user_id, body, **kwargs):  # noqa: E501
        """Update a user&#x27;s permission for this group.

        See ``GroupsApi.modify_group_user_permission()`` for parameter details.
        """
        return self.groups_api.modify_group_user_permission(group_id, user_id, body, **kwargs)


    def modify_group_user_permission_template(self, group_id, user_id, body, **kwargs):  # noqa: E501
        """Update a user&#x27;s permission for this group.

        See ``GroupsApi.modify_group_user_permission_template()`` for parameter details.
        """
        return self.groups_api.modify_group_user_permission_template(group_id, user_id, body, **kwargs)


    def remove_role_from_group(self, group_id, role_id, **kwargs):  # noqa: E501
        """Remove the role from the group

        See ``GroupsApi.remove_role_from_group()`` for parameter details.
        """
        return self.groups_api.remove_role_from_group(group_id, role_id, **kwargs)


    def rename_group_tag(self, cid, value, body, **kwargs):  # noqa: E501
        """Rename a tag.

        See ``GroupsApi.rename_group_tag()`` for parameter details.
        """
        return self.groups_api.rename_group_tag(cid, value, body, **kwargs)


    def add_job(self, body, **kwargs):  # noqa: E501
        """Add a job

        See ``JobsApi.add_job()`` for parameter details.
        """
        return self.jobs_api.add_job(body, **kwargs)


    def add_job_logs(self, job_id, body, **kwargs):  # noqa: E501
        """Add logs to a job.

        See ``JobsApi.add_job_logs()`` for parameter details.
        """
        return self.jobs_api.add_job_logs(job_id, body, **kwargs)


    def ask_jobs(self, body, **kwargs):  # noqa: E501
        """Ask the queue a question

        See ``JobsApi.ask_jobs()`` for parameter details.
        """
        return self.jobs_api.ask_jobs(body, **kwargs)


    def ask_jobs_state(self, job_state, body, **kwargs):  # noqa: E501
        """Ask job count by state

        See ``JobsApi.ask_jobs_state()`` for parameter details.
        """
        return self.jobs_api.ask_jobs_state(job_state, body, **kwargs)


    def complete_job(self, job_id, body, **kwargs):  # noqa: E501
        """Complete a job, with information

        See ``JobsApi.complete_job()`` for parameter details.
        """
        return self.jobs_api.complete_job(job_id, body, **kwargs)


    def determine_provider_for_job(self, body, **kwargs):  # noqa: E501
        """Determine the effective compute provider for a proposed job.

        See ``JobsApi.determine_provider_for_job()`` for parameter details.
        """
        return self.jobs_api.determine_provider_for_job(body, **kwargs)


    def engine_complete_job(self, job_id, body, **kwargs):  # noqa: E501
        """Complete a job, with information.

        See ``JobsApi.engine_complete_job()`` for parameter details.
        """
        return self.jobs_api.engine_complete_job(job_id, body, **kwargs)


    def engine_prepare_complete_job(self, job_id, **kwargs):  # noqa: E501
        """Create a ticket for completing a job, with id and status.

        See ``JobsApi.engine_prepare_complete_job()`` for parameter details.
        """
        return self.jobs_api.engine_prepare_complete_job(job_id, **kwargs)


    def get_all_jobs(self, **kwargs):  # noqa: E501
        """Return all jobs

        See ``JobsApi.get_all_jobs()`` for parameter details.
        """
        return self.jobs_api.get_all_jobs(**kwargs)


    def get_job(self, job_id, **kwargs):  # noqa: E501
        """Get job details

        See ``JobsApi.get_job()`` for parameter details.
        """
        return self.jobs_api.get_job(job_id, **kwargs)


    def get_job_config(self, job_id, **kwargs):  # noqa: E501
        """Get a job&#x27;s config

        See ``JobsApi.get_job_config()`` for parameter details.
        """
        return self.jobs_api.get_job_config(job_id, **kwargs)


    def get_job_detail(self, job_id, **kwargs):  # noqa: E501
        """Get job container details

        See ``JobsApi.get_job_detail()`` for parameter details.
        """
        return self.jobs_api.get_job_detail(job_id, **kwargs)


    def get_job_logs(self, job_id, **kwargs):  # noqa: E501
        """Get job logs

        See ``JobsApi.get_job_logs()`` for parameter details.
        """
        return self.jobs_api.get_job_logs(job_id, **kwargs)


    def get_jobs_stats(self, **kwargs):  # noqa: E501
        """Get stats about all current jobs

        See ``JobsApi.get_jobs_stats()`` for parameter details.
        """
        return self.jobs_api.get_jobs_stats(**kwargs)


    def get_next_job(self, **kwargs):  # noqa: E501
        """Get the next job in the queue

        See ``JobsApi.get_next_job()`` for parameter details.
        """
        return self.jobs_api.get_next_job(**kwargs)


    def heartbeat_job(self, job_id, **kwargs):  # noqa: E501
        """Heartbeat a running job to update its modified timestamp.

        See ``JobsApi.heartbeat_job()`` for parameter details.
        """
        return self.jobs_api.heartbeat_job(job_id, **kwargs)


    def modify_job(self, job_id, body, **kwargs):  # noqa: E501
        """Update a job.

        See ``JobsApi.modify_job()`` for parameter details.
        """
        return self.jobs_api.modify_job(job_id, body, **kwargs)


    def prepare_complete_job(self, job_id, **kwargs):  # noqa: E501
        """Create a ticket for completing a job, with id and status.

        See ``JobsApi.prepare_complete_job()`` for parameter details.
        """
        return self.jobs_api.prepare_complete_job(job_id, **kwargs)


    def reap_jobs(self, **kwargs):  # noqa: E501
        """Reap stale jobs

        See ``JobsApi.reap_jobs()`` for parameter details.
        """
        return self.jobs_api.reap_jobs(**kwargs)


    def retry_job(self, job_id, **kwargs):  # noqa: E501
        """Retry a job.

        See ``JobsApi.retry_job()`` for parameter details.
        """
        return self.jobs_api.retry_job(job_id, **kwargs)


    def update_job_profile(self, job_id, body, **kwargs):  # noqa: E501
        """Update profile information on a job. (e.g. machine type, etc)

        See ``JobsApi.update_job_profile()`` for parameter details.
        """
        return self.jobs_api.update_job_profile(job_id, body, **kwargs)


    def update_jobs_priority(self, body, **kwargs):  # noqa: E501
        """Update a job priority.

        See ``JobsApi.update_jobs_priority()`` for parameter details.
        """
        return self.jobs_api.update_jobs_priority(body, **kwargs)


    def get_jupyterlab_server(self, jupyterlab_server_id, **kwargs):  # noqa: E501
        """Get jupyterlab server

        See ``JupyterlabServersApi.get_jupyterlab_server()`` for parameter details.
        """
        return self.jupyterlab_servers_api.get_jupyterlab_server(jupyterlab_server_id, **kwargs)


    def modify_jupyterlab_server(self, jupyterlab_server_id, body, **kwargs):  # noqa: E501
        """Update a jupyterlab server

        See ``JupyterlabServersApi.modify_jupyterlab_server()`` for parameter details.
        """
        return self.jupyterlab_servers_api.modify_jupyterlab_server(jupyterlab_server_id, body, **kwargs)


    def add_modality(self, body, **kwargs):  # noqa: E501
        """Create a new modality.

        See ``ModalitiesApi.add_modality()`` for parameter details.
        """
        return self.modalities_api.add_modality(body, **kwargs)


    def delete_modality(self, modality_id, **kwargs):  # noqa: E501
        """Delete a modality

        See ``ModalitiesApi.delete_modality()`` for parameter details.
        """
        return self.modalities_api.delete_modality(modality_id, **kwargs)


    def get_all_modalities(self, **kwargs):  # noqa: E501
        """List all modalities.

        See ``ModalitiesApi.get_all_modalities()`` for parameter details.
        """
        return self.modalities_api.get_all_modalities(**kwargs)


    def get_modality(self, modality_id, **kwargs):  # noqa: E501
        """Get a modality&#x27;s classification specification

        See ``ModalitiesApi.get_modality()`` for parameter details.
        """
        return self.modalities_api.get_modality(modality_id, **kwargs)


    def replace_modality(self, modality_id, body, **kwargs):  # noqa: E501
        """Replace modality

        See ``ModalitiesApi.replace_modality()`` for parameter details.
        """
        return self.modalities_api.replace_modality(modality_id, body, **kwargs)


    def clean_packfiles(self, **kwargs):  # noqa: E501
        """Clean up expired upload tokens and invalid token directories.

        See ``PackfilesApi.clean_packfiles()`` for parameter details.
        """
        return self.packfiles_api.clean_packfiles(**kwargs)


    def add_project(self, body, **kwargs):  # noqa: E501
        """Create a new project

        See ``ProjectsApi.add_project()`` for parameter details.
        """
        return self.projects_api.add_project(body, **kwargs)


    def add_project_analysis(self, cid, body, **kwargs):  # noqa: E501
        """Create an analysis and upload files.

        See ``ProjectsApi.add_project_analysis()`` for parameter details.
        """
        return self.projects_api.add_project_analysis(cid, body, **kwargs)


    def add_project_analysis_note(self, container_id, analysis_id, body, **kwargs):  # noqa: E501
        """Add a note to a(n) project analysis.

        See ``ProjectsApi.add_project_analysis_note()`` for parameter details.
        """
        return self.projects_api.add_project_analysis_note(container_id, analysis_id, body, **kwargs)


    def add_project_note(self, container_id, body, **kwargs):  # noqa: E501
        """Add a note to a(n) project.

        See ``ProjectsApi.add_project_note()`` for parameter details.
        """
        return self.projects_api.add_project_note(container_id, body, **kwargs)


    def add_project_permission(self, project_id, body, **kwargs):  # noqa: E501
        """Add a permission

        See ``ProjectsApi.add_project_permission()`` for parameter details.
        """
        return self.projects_api.add_project_permission(project_id, body, **kwargs)


    def add_project_rule(self, project_id, body, **kwargs):  # noqa: E501
        """Create a new rule for a project.

        See ``ProjectsApi.add_project_rule()`` for parameter details.
        """
        return self.projects_api.add_project_rule(project_id, body, **kwargs)


    def add_project_tag(self, cid, body, **kwargs):  # noqa: E501
        """Add a tag to a(n) project.

        See ``ProjectsApi.add_project_tag()`` for parameter details.
        """
        return self.projects_api.add_project_tag(cid, body, **kwargs)


    def add_project_tags(self, cid, body, **kwargs):  # noqa: E501
        """Add multiple tags to a(n) project

        See ``ProjectsApi.add_project_tags()`` for parameter details.
        """
        return self.projects_api.add_project_tags(cid, body, **kwargs)


    def catalog_list(self, **kwargs):  # noqa: E501
        """Catalog List

        See ``ProjectsApi.catalog_list()`` for parameter details.
        """
        return self.projects_api.catalog_list(**kwargs)


    def delete_project(self, project_id, **kwargs):  # noqa: E501
        """Delete a project

        See ``ProjectsApi.delete_project()`` for parameter details.
        """
        return self.projects_api.delete_project(project_id, **kwargs)


    def delete_project_analysis(self, cid, analysis_id, **kwargs):  # noqa: E501
        """Delete an analysis

        See ``ProjectsApi.delete_project_analysis()`` for parameter details.
        """
        return self.projects_api.delete_project_analysis(cid, analysis_id, **kwargs)


    def delete_project_analysis_note(self, cid, analysis_id, note_id, **kwargs):  # noqa: E501
        """Remove a note from a(n) project analysis.

        See ``ProjectsApi.delete_project_analysis_note()`` for parameter details.
        """
        return self.projects_api.delete_project_analysis_note(cid, analysis_id, note_id, **kwargs)


    def delete_project_file(self, cid, filename, **kwargs):  # noqa: E501
        """Delete a file

        See ``ProjectsApi.delete_project_file()`` for parameter details.
        """
        return self.projects_api.delete_project_file(cid, filename, **kwargs)


    def delete_project_note(self, cid, note_id, **kwargs):  # noqa: E501
        """Remove a note from a(n) project

        See ``ProjectsApi.delete_project_note()`` for parameter details.
        """
        return self.projects_api.delete_project_note(cid, note_id, **kwargs)


    def delete_project_tag(self, cid, value, **kwargs):  # noqa: E501
        """Delete a tag

        See ``ProjectsApi.delete_project_tag()`` for parameter details.
        """
        return self.projects_api.delete_project_tag(cid, value, **kwargs)


    def delete_project_tags(self, cid, body, **kwargs):  # noqa: E501
        """Delete multiple tags from a(n) project

        See ``ProjectsApi.delete_project_tags()`` for parameter details.
        """
        return self.projects_api.delete_project_tags(cid, body, **kwargs)


    def delete_project_user_permission(self, project_id, uid, **kwargs):  # noqa: E501
        """Delete a permission

        See ``ProjectsApi.delete_project_user_permission()`` for parameter details.
        """
        return self.projects_api.delete_project_user_permission(project_id, uid, **kwargs)


    def delete_projects_by_ids(self, body, **kwargs):  # noqa: E501
        """Delete multiple projects by ID list

        See ``ProjectsApi.delete_projects_by_ids()`` for parameter details.
        """
        return self.projects_api.delete_projects_by_ids(body, **kwargs)


    def download_file_from_project(self, project_id, file_name, dest_file, **kwargs):  # noqa: E501
        """Download a file.

        See ``ProjectsApi.download_file_from_project()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.projects_api.download_file_from_project(project_id, file_name, dest_file, **kwargs)


    def get_project_file_zip_info(self, project_id, file_name, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``ProjectsApi.get_project_file_zip_info()`` for parameter details.
        """
        return self.projects_api.get_project_file_zip_info(project_id, file_name, **kwargs)


    def get_project_download_url(self, project_id, file_name, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``ProjectsApi.get_project_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.projects_api.get_project_download_ticket(project_id, file_name, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def download_input_from_project_analysis(self, project_id, analysis_id, filename, dest_file, **kwargs):  # noqa: E501
        """Download analysis inputs with filter.

        See ``ProjectsApi.download_input_from_project_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.projects_api.download_input_from_project_analysis(project_id, analysis_id, filename, dest_file, **kwargs)


    def get_project_analysis_input_zip_info(self, project_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``ProjectsApi.get_project_analysis_input_zip_info()`` for parameter details.
        """
        return self.projects_api.get_project_analysis_input_zip_info(project_id, analysis_id, filename, **kwargs)


    def get_project_analysis_input_download_url(self, project_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``ProjectsApi.get_project_analysis_input_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.projects_api.get_project_analysis_input_download_ticket(project_id, analysis_id, filename, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def download_output_from_project_analysis(self, project_id, analysis_id, filename, dest_file, **kwargs):  # noqa: E501
        """Download analysis outputs with filter.

        See ``ProjectsApi.download_output_from_project_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.projects_api.download_output_from_project_analysis(project_id, analysis_id, filename, dest_file, **kwargs)


    def get_project_analysis_output_zip_info(self, project_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``ProjectsApi.get_project_analysis_output_zip_info()`` for parameter details.
        """
        return self.projects_api.get_project_analysis_output_zip_info(project_id, analysis_id, filename, **kwargs)


    def get_project_analysis_output_download_url(self, project_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``ProjectsApi.get_project_analysis_output_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.projects_api.get_project_analysis_output_download_ticket(project_id, analysis_id, filename, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def end_project_packfile_upload(self, token, metadata, file_count, project_id, **kwargs):  # noqa: E501
        """End a packfile upload

        See ``ProjectsApi.end_project_packfile_upload()`` for parameter details.
        """
        return self.projects_api.end_project_packfile_upload(token, metadata, file_count, project_id, **kwargs)


    def get_all_projects(self, **kwargs):  # noqa: E501
        """Get a list of projects

        See ``ProjectsApi.get_all_projects()`` for parameter details.
        """
        return self.projects_api.get_all_projects(**kwargs)


    def get_all_projects_groups(self, **kwargs):  # noqa: E501
        """List all groups which have a project in them

        See ``ProjectsApi.get_all_projects_groups()`` for parameter details.
        """
        return self.projects_api.get_all_projects_groups(**kwargs)


    def get_catalog_list_filter_options(self, **kwargs):  # noqa: E501
        """Get all filter options for sharing a project

        See ``ProjectsApi.get_catalog_list_filter_options()`` for parameter details.
        """
        return self.projects_api.get_catalog_list_filter_options(**kwargs)


    def get_project(self, project_id, **kwargs):  # noqa: E501
        """Get a single project

        See ``ProjectsApi.get_project()`` for parameter details.
        """
        return self.projects_api.get_project(project_id, **kwargs)


    def get_project_acquisitions(self, project_id, **kwargs):  # noqa: E501
        """List all acquisitions for the given project.

        See ``ProjectsApi.get_project_acquisitions()`` for parameter details.
        """
        return self.projects_api.get_project_acquisitions(project_id, **kwargs)


    def get_project_analyses(self, cid, **kwargs):  # noqa: E501
        """Get analyses for a(n) project.

        See ``ProjectsApi.get_project_analyses()`` for parameter details.
        """
        return self.projects_api.get_project_analyses(cid, **kwargs)


    def get_project_analysis(self, cid, analysis_id, **kwargs):  # noqa: E501
        """Get an analysis.

        See ``ProjectsApi.get_project_analysis()`` for parameter details.
        """
        return self.projects_api.get_project_analysis(cid, analysis_id, **kwargs)


    def get_project_delete_status(self, project_id, **kwargs):  # noqa: E501
        """Get project deletion status

        See ``ProjectsApi.get_project_delete_status()`` for parameter details.
        """
        return self.projects_api.get_project_delete_status(project_id, **kwargs)


    def get_project_file_info(self, cid, filename, **kwargs):  # noqa: E501
        """Get info for a particular file.

        See ``ProjectsApi.get_project_file_info()`` for parameter details.
        """
        return self.projects_api.get_project_file_info(cid, filename, **kwargs)


    def get_project_note(self, cid, note_id, **kwargs):  # noqa: E501
        """Get a note of a(n) project.

        See ``ProjectsApi.get_project_note()`` for parameter details.
        """
        return self.projects_api.get_project_note(cid, note_id, **kwargs)


    def get_project_rule(self, project_id, rule_id, **kwargs):  # noqa: E501
        """Get a project rule.

        See ``ProjectsApi.get_project_rule()`` for parameter details.
        """
        return self.projects_api.get_project_rule(project_id, rule_id, **kwargs)


    def get_project_rules(self, project_id, **kwargs):  # noqa: E501
        """List all rules for a project.

        See ``ProjectsApi.get_project_rules()`` for parameter details.
        """
        return self.projects_api.get_project_rules(project_id, **kwargs)


    def get_project_sessions(self, project_id, **kwargs):  # noqa: E501
        """List all sessions for the given project.

        See ``ProjectsApi.get_project_sessions()`` for parameter details.
        """
        return self.projects_api.get_project_sessions(project_id, **kwargs)


    def get_project_settings(self, project_id, **kwargs):  # noqa: E501
        """Get a(n) project settings

        See ``ProjectsApi.get_project_settings()`` for parameter details.
        """
        return self.projects_api.get_project_settings(project_id, **kwargs)


    def get_project_subjects(self, project_id, **kwargs):  # noqa: E501
        """List all subjects for the given project.

        See ``ProjectsApi.get_project_subjects()`` for parameter details.
        """
        return self.projects_api.get_project_subjects(project_id, **kwargs)


    def get_project_tag(self, cid, value, **kwargs):  # noqa: E501
        """Get the value of a tag, by name.

        See ``ProjectsApi.get_project_tag()`` for parameter details.
        """
        return self.projects_api.get_project_tag(cid, value, **kwargs)


    def get_project_user_permission(self, project_id, uid, **kwargs):  # noqa: E501
        """List a user&#x27;s permissions for this project.

        See ``ProjectsApi.get_project_user_permission()`` for parameter details.
        """
        return self.projects_api.get_project_user_permission(project_id, uid, **kwargs)


    def modify_project(self, project_id, body, **kwargs):  # noqa: E501
        """Update a project

        See ``ProjectsApi.modify_project()`` for parameter details.
        """
        return self.projects_api.modify_project(project_id, body, **kwargs)


    def modify_project_analysis(self, cid, analysis_id, body, **kwargs):  # noqa: E501
        """Modify an analysis.

        See ``ProjectsApi.modify_project_analysis()`` for parameter details.
        """
        return self.projects_api.modify_project_analysis(cid, analysis_id, body, **kwargs)


    def modify_project_file(self, cid, filename, body, **kwargs):  # noqa: E501
        """Modify a file&#x27;s attributes

        See ``ProjectsApi.modify_project_file()`` for parameter details.
        """
        return self.projects_api.modify_project_file(cid, filename, body, **kwargs)


    def modify_project_file_classification(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update classification for a particular file.

        See ``ProjectsApi.modify_project_file_classification()`` for parameter details.
        """
        return self.projects_api.modify_project_file_classification(cid, filename, body, **kwargs)


    def modify_project_file_info(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update info for a particular file.

        See ``ProjectsApi.modify_project_file_info()`` for parameter details.
        """
        return self.projects_api.modify_project_file_info(cid, filename, body, **kwargs)


    def modify_project_info(self, cid, body, **kwargs):  # noqa: E501
        """Update or replace info for a(n) project.

        See ``ProjectsApi.modify_project_info()`` for parameter details.
        """
        return self.projects_api.modify_project_info(cid, body, **kwargs)


    def modify_project_note(self, cid, note_id, body, **kwargs):  # noqa: E501
        """Update a note of a(n) project.

        See ``ProjectsApi.modify_project_note()`` for parameter details.
        """
        return self.projects_api.modify_project_note(cid, note_id, body, **kwargs)


    def modify_project_rule(self, project_id, rule_id, body, **kwargs):  # noqa: E501
        """Update a rule on a project.

        See ``ProjectsApi.modify_project_rule()`` for parameter details.
        """
        return self.projects_api.modify_project_rule(project_id, rule_id, body, **kwargs)


    def modify_project_settings(self, project_id, body, **kwargs):  # noqa: E501
        """Modify a(n) project settings

        See ``ProjectsApi.modify_project_settings()`` for parameter details.
        """
        return self.projects_api.modify_project_settings(project_id, body, **kwargs)


    def modify_project_user_permission(self, project_id, uid, body, **kwargs):  # noqa: E501
        """Update a user&#x27;s permission for this project.

        See ``ProjectsApi.modify_project_user_permission()`` for parameter details.
        """
        return self.projects_api.modify_project_user_permission(project_id, uid, body, **kwargs)


    def project_copy(self, project_id, body, **kwargs):  # noqa: E501
        """Copy By Reference

        See ``ProjectsApi.project_copy()`` for parameter details.
        """
        return self.projects_api.project_copy(project_id, body, **kwargs)


    def project_packfile_upload(self, project_id, token, file, **kwargs):  # noqa: E501
        """Add files to an in-progress packfile

        See ``ProjectsApi.project_packfile_upload()`` for parameter details.
        """
        return self.projects_api.project_packfile_upload(project_id, token, file, **kwargs)


    def recalc_all_projects(self, **kwargs):  # noqa: E501
        """Recalculate all sessions against their project templates.

        See ``ProjectsApi.recalc_all_projects()`` for parameter details.
        """
        return self.projects_api.recalc_all_projects(**kwargs)


    def recalc_project(self, project_id, **kwargs):  # noqa: E501
        """Currently does nothing--will eventually calculate if sessions in the project satisfy the template.

        See ``ProjectsApi.recalc_project()`` for parameter details.
        """
        return self.projects_api.recalc_project(project_id, **kwargs)


    def remove_project_rule(self, project_id, rule_id, **kwargs):  # noqa: E501
        """Remove a project rule.

        See ``ProjectsApi.remove_project_rule()`` for parameter details.
        """
        return self.projects_api.remove_project_rule(project_id, rule_id, **kwargs)


    def remove_project_template(self, project_id, **kwargs):  # noqa: E501
        """Remove the session template for a project.

        See ``ProjectsApi.remove_project_template()`` for parameter details.
        """
        return self.projects_api.remove_project_template(project_id, **kwargs)


    def rename_project_tag(self, cid, value, body, **kwargs):  # noqa: E501
        """Rename a tag.

        See ``ProjectsApi.rename_project_tag()`` for parameter details.
        """
        return self.projects_api.rename_project_tag(cid, value, body, **kwargs)


    def set_project_template(self, project_id, body, **kwargs):  # noqa: E501
        """Set the session template for a project.

        See ``ProjectsApi.set_project_template()`` for parameter details.
        """
        return self.projects_api.set_project_template(project_id, body, **kwargs)


    def start_project_packfile_upload(self, project_id, **kwargs):  # noqa: E501
        """Start a packfile upload to project

        See ``ProjectsApi.start_project_packfile_upload()`` for parameter details.
        """
        return self.projects_api.start_project_packfile_upload(project_id, **kwargs)


    def upload_file_to_project(self, container_id, file, signed=True, **kwargs):  # noqa: E501
        """Upload a file to a(n) project.

        See ``ProjectsApi.upload_file_to_project()`` for parameter details.
        :param signed: Use signed URL upload if available, defaults to True
        :type signed: bool, optional
        """
        if signed:
            signed_result = self.signed_upload_file_to_project(container_id, file, **kwargs)
            if signed_result:
                return signed_result

        return self.projects_api.upload_file_to_project(container_id, file, **kwargs)


    def upload_output_to_project_analysis(self, cid, analysis_id, file, signed=True, **kwargs):  # noqa: E501
        """Upload an output file to an analysis.

        See ``ProjectsApi.upload_output_to_project_analysis()`` for parameter details.
        :param signed: Use signed URL upload if available, defaults to True
        :type signed: bool, optional
        """
        if signed:
            signed_result = self.signed_upload_output_to_project_analysis(cid, analysis_id, file, **kwargs)
            if signed_result:
                return signed_result

        return self.projects_api.upload_output_to_project_analysis(cid, analysis_id, file, **kwargs)


    def upsert_project_hierarchy(self, project_id, body, **kwargs):  # noqa: E501
        """Create or update subject, session and acquisition containers in the project.

        See ``ProjectsApi.upsert_project_hierarchy()`` for parameter details.
        """
        return self.projects_api.upsert_project_hierarchy(project_id, body, **kwargs)


    def archive_task_protocol(self, protocol_id, **kwargs):  # noqa: E501
        """Archive

        See ``ProtocolsApi.archive_task_protocol()`` for parameter details.
        """
        return self.protocols_api.archive_task_protocol(protocol_id, **kwargs)


    def create_task_protocol(self, body, **kwargs):  # noqa: E501
        """Create

        See ``ProtocolsApi.create_task_protocol()`` for parameter details.
        """
        return self.protocols_api.create_task_protocol(body, **kwargs)


    def delete_task_protocol(self, protocol_id, **kwargs):  # noqa: E501
        """Delete

        See ``ProtocolsApi.delete_task_protocol()`` for parameter details.
        """
        return self.protocols_api.delete_task_protocol(protocol_id, **kwargs)


    def find_task_protocols(self, **kwargs):  # noqa: E501
        """Find All

        See ``ProtocolsApi.find_task_protocols()`` for parameter details.
        """
        return self.protocols_api.find_task_protocols(**kwargs)


    def get_task_protocol(self, protocol_id, **kwargs):  # noqa: E501
        """Get By Id

        See ``ProtocolsApi.get_task_protocol()`` for parameter details.
        """
        return self.protocols_api.get_task_protocol(protocol_id, **kwargs)


    def modify_task_protocol(self, protocol_id, body, **kwargs):  # noqa: E501
        """Modify

        See ``ProtocolsApi.modify_task_protocol()`` for parameter details.
        """
        return self.protocols_api.modify_task_protocol(protocol_id, body, **kwargs)


    def publish_task_protocol(self, protocol_id, **kwargs):  # noqa: E501
        """Publish

        See ``ProtocolsApi.publish_task_protocol()`` for parameter details.
        """
        return self.protocols_api.publish_task_protocol(protocol_id, **kwargs)


    def collect_usage(self, **kwargs):  # noqa: E501
        """Collect daily usage statistics.

        See ``ReportsApi.collect_usage()`` for parameter details.
        """
        return self.reports_api.collect_usage(**kwargs)


    def get_access_log_report(self, **kwargs):  # noqa: E501
        """Get a report of access log entries for the given parameters

        See ``ReportsApi.get_access_log_report()`` for parameter details.
        """
        return self.reports_api.get_access_log_report(**kwargs)


    def get_access_log_types(self, **kwargs):  # noqa: E501
        """Get the list of types of access log entries

        See ``ReportsApi.get_access_log_types()`` for parameter details.
        """
        return self.reports_api.get_access_log_types(**kwargs)


    def get_daily_usage_range_report(self, **kwargs):  # noqa: E501
        """Get a daily usage report for a given range of dates.

        See ``ReportsApi.get_daily_usage_range_report()`` for parameter details.
        """
        return self.reports_api.get_daily_usage_range_report(**kwargs)


    def get_daily_usage_report(self, **kwargs):  # noqa: E501
        """Get a daily usage report for the given month.

        See ``ReportsApi.get_daily_usage_report()`` for parameter details.
        """
        return self.reports_api.get_daily_usage_report(**kwargs)


    def get_legacy_usage_report(self, type, **kwargs):  # noqa: E501
        """Get a usage report for the site grouped by month or project

        See ``ReportsApi.get_legacy_usage_report()`` for parameter details.
        """
        return self.reports_api.get_legacy_usage_report(type, **kwargs)


    def get_project_report(self, **kwargs):  # noqa: E501
        """Get project report

        See ``ReportsApi.get_project_report()`` for parameter details.
        """
        return self.reports_api.get_project_report(**kwargs)


    def get_site_report(self, **kwargs):  # noqa: E501
        """Get the site report

        See ``ReportsApi.get_site_report()`` for parameter details.
        """
        return self.reports_api.get_site_report(**kwargs)


    def get_usage_availability(self, **kwargs):  # noqa: E501
        """Get year/month combinations where report data is available.

        See ``ReportsApi.get_usage_availability()`` for parameter details.
        """
        return self.reports_api.get_usage_availability(**kwargs)


    def get_usage_report(self, **kwargs):  # noqa: E501
        """Get a usage report for the given month.

        See ``ReportsApi.get_usage_report()`` for parameter details.
        """
        return self.reports_api.get_usage_report(**kwargs)


    def lookup_path(self, body, **kwargs):  # noqa: E501
        """Perform path based lookup of a single node in the Flywheel hierarchy

        See ``ResolveApi.lookup_path()`` for parameter details.
        """
        return self.resolve_api.lookup_path(body, **kwargs)


    def resolve_path(self, body, **kwargs):  # noqa: E501
        """Perform path based lookup of nodes in the Flywheel hierarchy

        See ``ResolveApi.resolve_path()`` for parameter details.
        """
        return self.resolve_api.resolve_path(body, **kwargs)


    def add_role(self, body, **kwargs):  # noqa: E501
        """Add a new role

        See ``RolesApi.add_role()`` for parameter details.
        """
        return self.roles_api.add_role(body, **kwargs)


    def delete_role(self, role_id, **kwargs):  # noqa: E501
        """Delete the role

        See ``RolesApi.delete_role()`` for parameter details.
        """
        return self.roles_api.delete_role(role_id, **kwargs)


    def get_all_roles(self, **kwargs):  # noqa: E501
        """Get list of all roles

        See ``RolesApi.get_all_roles()`` for parameter details.
        """
        return self.roles_api.get_all_roles(**kwargs)


    def get_role(self, role_id, **kwargs):  # noqa: E501
        """Return the role identified by the RoleId

        See ``RolesApi.get_role()`` for parameter details.
        """
        return self.roles_api.get_role(role_id, **kwargs)


    def modify_role(self, role_id, body, **kwargs):  # noqa: E501
        """Update the role identified by RoleId

        See ``RolesApi.modify_role()`` for parameter details.
        """
        return self.roles_api.modify_role(role_id, body, **kwargs)


    def add_session(self, body, **kwargs):  # noqa: E501
        """Create a new session

        See ``SessionsApi.add_session()`` for parameter details.
        """
        return self.sessions_api.add_session(body, **kwargs)


    def add_session_analysis(self, cid, body, **kwargs):  # noqa: E501
        """Create an analysis and upload files.

        See ``SessionsApi.add_session_analysis()`` for parameter details.
        """
        return self.sessions_api.add_session_analysis(cid, body, **kwargs)


    def add_session_analysis_note(self, container_id, analysis_id, body, **kwargs):  # noqa: E501
        """Add a note to a(n) session analysis.

        See ``SessionsApi.add_session_analysis_note()`` for parameter details.
        """
        return self.sessions_api.add_session_analysis_note(container_id, analysis_id, body, **kwargs)


    def add_session_note(self, container_id, body, **kwargs):  # noqa: E501
        """Add a note to a(n) session.

        See ``SessionsApi.add_session_note()`` for parameter details.
        """
        return self.sessions_api.add_session_note(container_id, body, **kwargs)


    def add_session_tag(self, cid, body, **kwargs):  # noqa: E501
        """Add a tag to a(n) session.

        See ``SessionsApi.add_session_tag()`` for parameter details.
        """
        return self.sessions_api.add_session_tag(cid, body, **kwargs)


    def add_session_tags(self, cid, body, **kwargs):  # noqa: E501
        """Add multiple tags to a(n) session

        See ``SessionsApi.add_session_tags()`` for parameter details.
        """
        return self.sessions_api.add_session_tags(cid, body, **kwargs)


    def delete_session(self, session_id, **kwargs):  # noqa: E501
        """Delete a session

        See ``SessionsApi.delete_session()`` for parameter details.
        """
        return self.sessions_api.delete_session(session_id, **kwargs)


    def delete_session_analysis(self, cid, analysis_id, **kwargs):  # noqa: E501
        """Delete an analysis

        See ``SessionsApi.delete_session_analysis()`` for parameter details.
        """
        return self.sessions_api.delete_session_analysis(cid, analysis_id, **kwargs)


    def delete_session_analysis_note(self, cid, analysis_id, note_id, **kwargs):  # noqa: E501
        """Remove a note from a(n) session analysis.

        See ``SessionsApi.delete_session_analysis_note()`` for parameter details.
        """
        return self.sessions_api.delete_session_analysis_note(cid, analysis_id, note_id, **kwargs)


    def delete_session_file(self, cid, filename, **kwargs):  # noqa: E501
        """Delete a file

        See ``SessionsApi.delete_session_file()`` for parameter details.
        """
        return self.sessions_api.delete_session_file(cid, filename, **kwargs)


    def delete_session_note(self, cid, note_id, **kwargs):  # noqa: E501
        """Remove a note from a(n) session

        See ``SessionsApi.delete_session_note()`` for parameter details.
        """
        return self.sessions_api.delete_session_note(cid, note_id, **kwargs)


    def delete_session_tag(self, cid, value, **kwargs):  # noqa: E501
        """Delete a tag

        See ``SessionsApi.delete_session_tag()`` for parameter details.
        """
        return self.sessions_api.delete_session_tag(cid, value, **kwargs)


    def delete_session_tags(self, cid, body, **kwargs):  # noqa: E501
        """Delete multiple tags from a(n) session

        See ``SessionsApi.delete_session_tags()`` for parameter details.
        """
        return self.sessions_api.delete_session_tags(cid, body, **kwargs)


    def delete_sessions_by_ids(self, body, **kwargs):  # noqa: E501
        """Delete multiple sessions by ID list

        See ``SessionsApi.delete_sessions_by_ids()`` for parameter details.
        """
        return self.sessions_api.delete_sessions_by_ids(body, **kwargs)


    def download_file_from_session(self, session_id, file_name, dest_file, **kwargs):  # noqa: E501
        """Download a file.

        See ``SessionsApi.download_file_from_session()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.sessions_api.download_file_from_session(session_id, file_name, dest_file, **kwargs)


    def get_session_file_zip_info(self, session_id, file_name, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``SessionsApi.get_session_file_zip_info()`` for parameter details.
        """
        return self.sessions_api.get_session_file_zip_info(session_id, file_name, **kwargs)


    def get_session_download_url(self, session_id, file_name, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``SessionsApi.get_session_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.sessions_api.get_session_download_ticket(session_id, file_name, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def download_input_from_session_analysis(self, session_id, analysis_id, filename, dest_file, **kwargs):  # noqa: E501
        """Download analysis inputs with filter.

        See ``SessionsApi.download_input_from_session_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.sessions_api.download_input_from_session_analysis(session_id, analysis_id, filename, dest_file, **kwargs)


    def get_session_analysis_input_zip_info(self, session_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``SessionsApi.get_session_analysis_input_zip_info()`` for parameter details.
        """
        return self.sessions_api.get_session_analysis_input_zip_info(session_id, analysis_id, filename, **kwargs)


    def get_session_analysis_input_download_url(self, session_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``SessionsApi.get_session_analysis_input_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.sessions_api.get_session_analysis_input_download_ticket(session_id, analysis_id, filename, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def download_output_from_session_analysis(self, session_id, analysis_id, filename, dest_file, **kwargs):  # noqa: E501
        """Download analysis outputs with filter.

        See ``SessionsApi.download_output_from_session_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.sessions_api.download_output_from_session_analysis(session_id, analysis_id, filename, dest_file, **kwargs)


    def get_session_analysis_output_zip_info(self, session_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``SessionsApi.get_session_analysis_output_zip_info()`` for parameter details.
        """
        return self.sessions_api.get_session_analysis_output_zip_info(session_id, analysis_id, filename, **kwargs)


    def get_session_analysis_output_download_url(self, session_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``SessionsApi.get_session_analysis_output_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.sessions_api.get_session_analysis_output_download_ticket(session_id, analysis_id, filename, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def get_all_sessions(self, **kwargs):  # noqa: E501
        """Get a list of sessions

        See ``SessionsApi.get_all_sessions()`` for parameter details.
        """
        return self.sessions_api.get_all_sessions(**kwargs)


    def get_session(self, session_id, **kwargs):  # noqa: E501
        """Get a single session

        See ``SessionsApi.get_session()`` for parameter details.
        """
        return self.sessions_api.get_session(session_id, **kwargs)


    def get_session_acquisitions(self, session_id, **kwargs):  # noqa: E501
        """List acquisitions in a session

        See ``SessionsApi.get_session_acquisitions()`` for parameter details.
        """
        return self.sessions_api.get_session_acquisitions(session_id, **kwargs)


    def get_session_analyses(self, cid, **kwargs):  # noqa: E501
        """Get analyses for a(n) session.

        See ``SessionsApi.get_session_analyses()`` for parameter details.
        """
        return self.sessions_api.get_session_analyses(cid, **kwargs)


    def get_session_analysis(self, cid, analysis_id, **kwargs):  # noqa: E501
        """Get an analysis.

        See ``SessionsApi.get_session_analysis()`` for parameter details.
        """
        return self.sessions_api.get_session_analysis(cid, analysis_id, **kwargs)


    def get_session_file_info(self, cid, filename, **kwargs):  # noqa: E501
        """Get info for a particular file.

        See ``SessionsApi.get_session_file_info()`` for parameter details.
        """
        return self.sessions_api.get_session_file_info(cid, filename, **kwargs)


    def get_session_jobs(self, session_id, **kwargs):  # noqa: E501
        """Return any jobs that use inputs from this session

        See ``SessionsApi.get_session_jobs()`` for parameter details.
        """
        return self.sessions_api.get_session_jobs(session_id, **kwargs)


    def get_session_note(self, cid, note_id, **kwargs):  # noqa: E501
        """Get a note of a(n) session.

        See ``SessionsApi.get_session_note()`` for parameter details.
        """
        return self.sessions_api.get_session_note(cid, note_id, **kwargs)


    def get_session_tag(self, cid, value, **kwargs):  # noqa: E501
        """Get the value of a tag, by name.

        See ``SessionsApi.get_session_tag()`` for parameter details.
        """
        return self.sessions_api.get_session_tag(cid, value, **kwargs)


    def modify_session(self, session_id, body, **kwargs):  # noqa: E501
        """Update a session

        See ``SessionsApi.modify_session()`` for parameter details.
        """
        return self.sessions_api.modify_session(session_id, body, **kwargs)


    def modify_session_analysis(self, cid, analysis_id, body, **kwargs):  # noqa: E501
        """Modify an analysis.

        See ``SessionsApi.modify_session_analysis()`` for parameter details.
        """
        return self.sessions_api.modify_session_analysis(cid, analysis_id, body, **kwargs)


    def modify_session_file(self, cid, filename, body, **kwargs):  # noqa: E501
        """Modify a file&#x27;s attributes

        See ``SessionsApi.modify_session_file()`` for parameter details.
        """
        return self.sessions_api.modify_session_file(cid, filename, body, **kwargs)


    def modify_session_file_classification(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update classification for a particular file.

        See ``SessionsApi.modify_session_file_classification()`` for parameter details.
        """
        return self.sessions_api.modify_session_file_classification(cid, filename, body, **kwargs)


    def modify_session_file_info(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update info for a particular file.

        See ``SessionsApi.modify_session_file_info()`` for parameter details.
        """
        return self.sessions_api.modify_session_file_info(cid, filename, body, **kwargs)


    def modify_session_info(self, cid, body, **kwargs):  # noqa: E501
        """Update or replace info for a(n) session.

        See ``SessionsApi.modify_session_info()`` for parameter details.
        """
        return self.sessions_api.modify_session_info(cid, body, **kwargs)


    def modify_session_note(self, cid, note_id, body, **kwargs):  # noqa: E501
        """Update a note of a(n) session.

        See ``SessionsApi.modify_session_note()`` for parameter details.
        """
        return self.sessions_api.modify_session_note(cid, note_id, body, **kwargs)


    def rename_session_tag(self, cid, value, body, **kwargs):  # noqa: E501
        """Rename a tag.

        See ``SessionsApi.rename_session_tag()`` for parameter details.
        """
        return self.sessions_api.rename_session_tag(cid, value, body, **kwargs)


    def session_copy(self, session_id, body, **kwargs):  # noqa: E501
        """Smart copy a session

        See ``SessionsApi.session_copy()`` for parameter details.
        """
        return self.sessions_api.session_copy(session_id, body, **kwargs)


    def upload_file_to_session(self, container_id, file, signed=True, **kwargs):  # noqa: E501
        """Upload a file to a(n) session.

        See ``SessionsApi.upload_file_to_session()`` for parameter details.
        :param signed: Use signed URL upload if available, defaults to True
        :type signed: bool, optional
        """
        if signed:
            signed_result = self.signed_upload_file_to_session(container_id, file, **kwargs)
            if signed_result:
                return signed_result

        return self.sessions_api.upload_file_to_session(container_id, file, **kwargs)


    def upload_output_to_session_analysis(self, cid, analysis_id, file, signed=True, **kwargs):  # noqa: E501
        """Upload an output file to an analysis.

        See ``SessionsApi.upload_output_to_session_analysis()`` for parameter details.
        :param signed: Use signed URL upload if available, defaults to True
        :type signed: bool, optional
        """
        if signed:
            signed_result = self.signed_upload_output_to_session_analysis(cid, analysis_id, file, **kwargs)
            if signed_result:
                return signed_result

        return self.sessions_api.upload_output_to_session_analysis(cid, analysis_id, file, **kwargs)


    def add_provider(self, body, **kwargs):  # noqa: E501
        """Add a new provider

        See ``SiteApi.add_provider()`` for parameter details.
        """
        return self.site_api.add_provider(body, **kwargs)


    def add_site_rule(self, body, **kwargs):  # noqa: E501
        """Create a new site rule.

        See ``SiteApi.add_site_rule()`` for parameter details.
        """
        return self.site_api.add_site_rule(body, **kwargs)


    def delete_provider(self, provider_id, **kwargs):  # noqa: E501
        """Delete the provider identified by ProviderId

        See ``SiteApi.delete_provider()`` for parameter details.
        """
        return self.site_api.delete_provider(provider_id, **kwargs)


    def get_bookmark_list(self, **kwargs):  # noqa: E501
        """Get Bookmark List

        See ``SiteApi.get_bookmark_list()`` for parameter details.
        """
        return self.site_api.get_bookmark_list(**kwargs)


    def get_provider(self, provider_id, **kwargs):  # noqa: E501
        """Return the provider identified by ProviderId

        See ``SiteApi.get_provider()`` for parameter details.
        """
        return self.site_api.get_provider(provider_id, **kwargs)


    def get_provider_config(self, provider_id, **kwargs):  # noqa: E501
        """Return the configuration for provider identified by ProviderId

        See ``SiteApi.get_provider_config()`` for parameter details.
        """
        return self.site_api.get_provider_config(provider_id, **kwargs)


    def get_providers(self, **kwargs):  # noqa: E501
        """Return a list of all providers on the site

        See ``SiteApi.get_providers()`` for parameter details.
        """
        return self.site_api.get_providers(**kwargs)


    def get_site_rule(self, rule_id, **kwargs):  # noqa: E501
        """Get a site rule.

        See ``SiteApi.get_site_rule()`` for parameter details.
        """
        return self.site_api.get_site_rule(rule_id, **kwargs)


    def get_site_rules(self, **kwargs):  # noqa: E501
        """List all site rules.

        See ``SiteApi.get_site_rules()`` for parameter details.
        """
        return self.site_api.get_site_rules(**kwargs)


    def get_site_settings(self, **kwargs):  # noqa: E501
        """Return administrative site settings

        See ``SiteApi.get_site_settings()`` for parameter details.
        """
        return self.site_api.get_site_settings(**kwargs)


    def modify_bookmark_list(self, body, **kwargs):  # noqa: E501
        """Modify Bookmark List

        See ``SiteApi.modify_bookmark_list()`` for parameter details.
        """
        return self.site_api.modify_bookmark_list(body, **kwargs)


    def modify_provider(self, provider_id, body, **kwargs):  # noqa: E501
        """Update the provider identified by ProviderId

        See ``SiteApi.modify_provider()`` for parameter details.
        """
        return self.site_api.modify_provider(provider_id, body, **kwargs)


    def modify_site_rule(self, rule_id, body, **kwargs):  # noqa: E501
        """Update a site rule.

        See ``SiteApi.modify_site_rule()`` for parameter details.
        """
        return self.site_api.modify_site_rule(rule_id, body, **kwargs)


    def modify_site_settings(self, body, **kwargs):  # noqa: E501
        """Update administrative site settings

        See ``SiteApi.modify_site_settings()`` for parameter details.
        """
        return self.site_api.modify_site_settings(body, **kwargs)


    def remove_site_rule(self, rule_id, **kwargs):  # noqa: E501
        """Remove a site rule.

        See ``SiteApi.remove_site_rule()`` for parameter details.
        """
        return self.site_api.remove_site_rule(rule_id, **kwargs)


    def create_staffing_pool(self, body, **kwargs):  # noqa: E501
        """Create

        See ``StaffingPoolsApi.create_staffing_pool()`` for parameter details.
        """
        return self.staffing_pools_api.create_staffing_pool(body, **kwargs)


    def delete_staffing_pool(self, pool_id, **kwargs):  # noqa: E501
        """Delete

        See ``StaffingPoolsApi.delete_staffing_pool()`` for parameter details.
        """
        return self.staffing_pools_api.delete_staffing_pool(pool_id, **kwargs)


    def find_all_api_staffing_pools_get(self, **kwargs):  # noqa: E501
        """Find All

        See ``StaffingPoolsApi.find_all_api_staffing_pools_get()`` for parameter details.
        """
        return self.staffing_pools_api.find_all_api_staffing_pools_get(**kwargs)


    def get_staffing_pool(self, pool_id, **kwargs):  # noqa: E501
        """Get By Id

        See ``StaffingPoolsApi.get_staffing_pool()`` for parameter details.
        """
        return self.staffing_pools_api.get_staffing_pool(pool_id, **kwargs)


    def modify_staffing_pool(self, pool_id, body, **kwargs):  # noqa: E501
        """Modify

        See ``StaffingPoolsApi.modify_staffing_pool()`` for parameter details.
        """
        return self.staffing_pools_api.modify_staffing_pool(pool_id, body, **kwargs)


    def set_user_staffing_pools(self, user_id, body, **kwargs):  # noqa: E501
        """Set User Staffing Pools

        See ``StaffingPoolsApi.set_user_staffing_pools()`` for parameter details.
        """
        return self.staffing_pools_api.set_user_staffing_pools(user_id, body, **kwargs)


    def add_subject(self, body, **kwargs):  # noqa: E501
        """Create a new subject

        See ``SubjectsApi.add_subject()`` for parameter details.
        """
        return self.subjects_api.add_subject(body, **kwargs)


    def add_subject_analysis(self, cid, body, **kwargs):  # noqa: E501
        """Create an analysis and upload files.

        See ``SubjectsApi.add_subject_analysis()`` for parameter details.
        """
        return self.subjects_api.add_subject_analysis(cid, body, **kwargs)


    def add_subject_analysis_note(self, container_id, analysis_id, body, **kwargs):  # noqa: E501
        """Add a note to a(n) subject analysis.

        See ``SubjectsApi.add_subject_analysis_note()`` for parameter details.
        """
        return self.subjects_api.add_subject_analysis_note(container_id, analysis_id, body, **kwargs)


    def add_subject_note(self, container_id, body, **kwargs):  # noqa: E501
        """Add a note to a(n) subject.

        See ``SubjectsApi.add_subject_note()`` for parameter details.
        """
        return self.subjects_api.add_subject_note(container_id, body, **kwargs)


    def add_subject_tag(self, cid, body, **kwargs):  # noqa: E501
        """Add a tag to a(n) subject.

        See ``SubjectsApi.add_subject_tag()`` for parameter details.
        """
        return self.subjects_api.add_subject_tag(cid, body, **kwargs)


    def add_subject_tags(self, cid, body, **kwargs):  # noqa: E501
        """Add multiple tags to a(n) subject

        See ``SubjectsApi.add_subject_tags()`` for parameter details.
        """
        return self.subjects_api.add_subject_tags(cid, body, **kwargs)


    def create_master_subject_code(self, body, **kwargs):  # noqa: E501
        """Request a master subject code for the given patient

        See ``SubjectsApi.create_master_subject_code()`` for parameter details.
        """
        return self.subjects_api.create_master_subject_code(body, **kwargs)


    def delete_subject(self, subject_id, **kwargs):  # noqa: E501
        """Delete a subject

        See ``SubjectsApi.delete_subject()`` for parameter details.
        """
        return self.subjects_api.delete_subject(subject_id, **kwargs)


    def delete_subject_analysis(self, cid, analysis_id, **kwargs):  # noqa: E501
        """Delete an analysis

        See ``SubjectsApi.delete_subject_analysis()`` for parameter details.
        """
        return self.subjects_api.delete_subject_analysis(cid, analysis_id, **kwargs)


    def delete_subject_analysis_note(self, cid, analysis_id, note_id, **kwargs):  # noqa: E501
        """Remove a note from a(n) subject analysis.

        See ``SubjectsApi.delete_subject_analysis_note()`` for parameter details.
        """
        return self.subjects_api.delete_subject_analysis_note(cid, analysis_id, note_id, **kwargs)


    def delete_subject_file(self, cid, filename, **kwargs):  # noqa: E501
        """Delete a file

        See ``SubjectsApi.delete_subject_file()`` for parameter details.
        """
        return self.subjects_api.delete_subject_file(cid, filename, **kwargs)


    def delete_subject_note(self, cid, note_id, **kwargs):  # noqa: E501
        """Remove a note from a(n) subject

        See ``SubjectsApi.delete_subject_note()`` for parameter details.
        """
        return self.subjects_api.delete_subject_note(cid, note_id, **kwargs)


    def delete_subject_tag(self, cid, value, **kwargs):  # noqa: E501
        """Delete a tag

        See ``SubjectsApi.delete_subject_tag()`` for parameter details.
        """
        return self.subjects_api.delete_subject_tag(cid, value, **kwargs)


    def delete_subject_tags(self, cid, body, **kwargs):  # noqa: E501
        """Delete multiple tags from a(n) subject

        See ``SubjectsApi.delete_subject_tags()`` for parameter details.
        """
        return self.subjects_api.delete_subject_tags(cid, body, **kwargs)


    def delete_subjects_by_ids(self, body, **kwargs):  # noqa: E501
        """Delete multiple subjects by ID list

        See ``SubjectsApi.delete_subjects_by_ids()`` for parameter details.
        """
        return self.subjects_api.delete_subjects_by_ids(body, **kwargs)


    def download_file_from_subject(self, subject_id, file_name, dest_file, **kwargs):  # noqa: E501
        """Download a file.

        See ``SubjectsApi.download_file_from_subject()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.subjects_api.download_file_from_subject(subject_id, file_name, dest_file, **kwargs)


    def get_subject_file_zip_info(self, subject_id, file_name, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``SubjectsApi.get_subject_file_zip_info()`` for parameter details.
        """
        return self.subjects_api.get_subject_file_zip_info(subject_id, file_name, **kwargs)


    def get_subject_download_url(self, subject_id, file_name, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``SubjectsApi.get_subject_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.subjects_api.get_subject_download_ticket(subject_id, file_name, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def download_input_from_subject_analysis(self, subject_id, analysis_id, filename, dest_file, **kwargs):  # noqa: E501
        """Download analysis inputs with filter.

        See ``SubjectsApi.download_input_from_subject_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.subjects_api.download_input_from_subject_analysis(subject_id, analysis_id, filename, dest_file, **kwargs)


    def get_subject_analysis_input_zip_info(self, subject_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``SubjectsApi.get_subject_analysis_input_zip_info()`` for parameter details.
        """
        return self.subjects_api.get_subject_analysis_input_zip_info(subject_id, analysis_id, filename, **kwargs)


    def get_subject_analysis_input_download_url(self, subject_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``SubjectsApi.get_subject_analysis_input_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.subjects_api.get_subject_analysis_input_download_ticket(subject_id, analysis_id, filename, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def download_output_from_subject_analysis(self, subject_id, analysis_id, filename, dest_file, **kwargs):  # noqa: E501
        """Download analysis outputs with filter.

        See ``SubjectsApi.download_output_from_subject_analysis()`` for parameter details.

        :param dest_file: Destination file path
        :type dest_file: str
        """
        return self.subjects_api.download_output_from_subject_analysis(subject_id, analysis_id, filename, dest_file, **kwargs)


    def get_subject_analysis_output_zip_info(self, subject_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Retrieve the zip info of a child file by name.

        See ``SubjectsApi.get_subject_analysis_output_zip_info()`` for parameter details.
        """
        return self.subjects_api.get_subject_analysis_output_zip_info(subject_id, analysis_id, filename, **kwargs)


    def get_subject_analysis_output_download_url(self, subject_id, analysis_id, filename, **kwargs):  # noqa: E501
        """Get a signed URL to download a named child file.

        Returns a download URL with ticket. See ``SubjectsApi.get_subject_analysis_output_download_ticket()`` for parameter details.
        """
        req_info = {}
        kwargs['_request_out'] = req_info
        kwargs['ticket'] = ''
        data = self.subjects_api.get_subject_analysis_output_download_ticket(subject_id, analysis_id, filename, **kwargs)
        if data is not None:
            data = req_info['url'] + '?ticket=' + data.ticket
        return data

    def get_all_subjects(self, **kwargs):  # noqa: E501
        """Get a list of subjects

        See ``SubjectsApi.get_all_subjects()`` for parameter details.
        """
        return self.subjects_api.get_all_subjects(**kwargs)


    def get_subject(self, subject_id, **kwargs):  # noqa: E501
        """Get a single subject

        See ``SubjectsApi.get_subject()`` for parameter details.
        """
        return self.subjects_api.get_subject(subject_id, **kwargs)


    def get_subject_analyses(self, cid, **kwargs):  # noqa: E501
        """Get analyses for a(n) subject.

        See ``SubjectsApi.get_subject_analyses()`` for parameter details.
        """
        return self.subjects_api.get_subject_analyses(cid, **kwargs)


    def get_subject_analysis(self, cid, analysis_id, **kwargs):  # noqa: E501
        """Get an analysis.

        See ``SubjectsApi.get_subject_analysis()`` for parameter details.
        """
        return self.subjects_api.get_subject_analysis(cid, analysis_id, **kwargs)


    def get_subject_file_info(self, cid, filename, **kwargs):  # noqa: E501
        """Get info for a particular file.

        See ``SubjectsApi.get_subject_file_info()`` for parameter details.
        """
        return self.subjects_api.get_subject_file_info(cid, filename, **kwargs)


    def get_subject_note(self, cid, note_id, **kwargs):  # noqa: E501
        """Get a note of a(n) subject.

        See ``SubjectsApi.get_subject_note()`` for parameter details.
        """
        return self.subjects_api.get_subject_note(cid, note_id, **kwargs)


    def get_subject_sessions(self, subject_id, **kwargs):  # noqa: E501
        """List sessions of a subject

        See ``SubjectsApi.get_subject_sessions()`` for parameter details.
        """
        return self.subjects_api.get_subject_sessions(subject_id, **kwargs)


    def get_subject_tag(self, cid, value, **kwargs):  # noqa: E501
        """Get the value of a tag, by name.

        See ``SubjectsApi.get_subject_tag()`` for parameter details.
        """
        return self.subjects_api.get_subject_tag(cid, value, **kwargs)


    def modify_subject(self, subject_id, body, **kwargs):  # noqa: E501
        """Update a subject

        See ``SubjectsApi.modify_subject()`` for parameter details.
        """
        return self.subjects_api.modify_subject(subject_id, body, **kwargs)


    def modify_subject_analysis(self, cid, analysis_id, body, **kwargs):  # noqa: E501
        """Modify an analysis.

        See ``SubjectsApi.modify_subject_analysis()`` for parameter details.
        """
        return self.subjects_api.modify_subject_analysis(cid, analysis_id, body, **kwargs)


    def modify_subject_file(self, cid, filename, body, **kwargs):  # noqa: E501
        """Modify a file&#x27;s attributes

        See ``SubjectsApi.modify_subject_file()`` for parameter details.
        """
        return self.subjects_api.modify_subject_file(cid, filename, body, **kwargs)


    def modify_subject_file_classification(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update classification for a particular file.

        See ``SubjectsApi.modify_subject_file_classification()`` for parameter details.
        """
        return self.subjects_api.modify_subject_file_classification(cid, filename, body, **kwargs)


    def modify_subject_file_info(self, cid, filename, body, **kwargs):  # noqa: E501
        """Update info for a particular file.

        See ``SubjectsApi.modify_subject_file_info()`` for parameter details.
        """
        return self.subjects_api.modify_subject_file_info(cid, filename, body, **kwargs)


    def modify_subject_info(self, cid, body, **kwargs):  # noqa: E501
        """Update or replace info for a(n) subject.

        See ``SubjectsApi.modify_subject_info()`` for parameter details.
        """
        return self.subjects_api.modify_subject_info(cid, body, **kwargs)


    def modify_subject_note(self, cid, note_id, body, **kwargs):  # noqa: E501
        """Update a note of a(n) subject.

        See ``SubjectsApi.modify_subject_note()`` for parameter details.
        """
        return self.subjects_api.modify_subject_note(cid, note_id, body, **kwargs)


    def rename_subject_tag(self, cid, value, body, **kwargs):  # noqa: E501
        """Rename a tag.

        See ``SubjectsApi.rename_subject_tag()`` for parameter details.
        """
        return self.subjects_api.rename_subject_tag(cid, value, body, **kwargs)


    def subject_copy(self, subject_id, body, **kwargs):  # noqa: E501
        """Smart copy a subject

        See ``SubjectsApi.subject_copy()`` for parameter details.
        """
        return self.subjects_api.subject_copy(subject_id, body, **kwargs)


    def upload_file_to_subject(self, container_id, file, signed=True, **kwargs):  # noqa: E501
        """Upload a file to a(n) subject.

        See ``SubjectsApi.upload_file_to_subject()`` for parameter details.
        :param signed: Use signed URL upload if available, defaults to True
        :type signed: bool, optional
        """
        if signed:
            signed_result = self.signed_upload_file_to_subject(container_id, file, **kwargs)
            if signed_result:
                return signed_result

        return self.subjects_api.upload_file_to_subject(container_id, file, **kwargs)


    def upload_output_to_subject_analysis(self, cid, analysis_id, file, signed=True, **kwargs):  # noqa: E501
        """Upload an output file to an analysis.

        See ``SubjectsApi.upload_output_to_subject_analysis()`` for parameter details.
        :param signed: Use signed URL upload if available, defaults to True
        :type signed: bool, optional
        """
        if signed:
            signed_result = self.signed_upload_output_to_subject_analysis(cid, analysis_id, file, **kwargs)
            if signed_result:
                return signed_result

        return self.subjects_api.upload_output_to_subject_analysis(cid, analysis_id, file, **kwargs)


    def verify_master_subject_code(self, code, **kwargs):  # noqa: E501
        """Verify that the given master subject code exists or not

        See ``SubjectsApi.verify_master_subject_code()`` for parameter details.
        """
        return self.subjects_api.verify_master_subject_code(code, **kwargs)


    def assign_reader_task(self, task_id, body, **kwargs):  # noqa: E501
        """Assign

        See ``TasksApi.assign_reader_task()`` for parameter details.
        """
        return self.tasks_api.assign_reader_task(task_id, body, **kwargs)


    def batch_create_reader_task(self, body, **kwargs):  # noqa: E501
        """Create Batch

        See ``TasksApi.batch_create_reader_task()`` for parameter details.
        """
        return self.tasks_api.batch_create_reader_task(body, **kwargs)


    def complete_reader_task(self, task_id, **kwargs):  # noqa: E501
        """Complete

        See ``TasksApi.complete_reader_task()`` for parameter details.
        """
        return self.tasks_api.complete_reader_task(task_id, **kwargs)


    def create_reader_task(self, body, **kwargs):  # noqa: E501
        """Create

        See ``TasksApi.create_reader_task()`` for parameter details.
        """
        return self.tasks_api.create_reader_task(body, **kwargs)


    def find_all_api_tasks_reader_get(self, **kwargs):  # noqa: E501
        """Find All

        See ``TasksApi.find_all_api_tasks_reader_get()`` for parameter details.
        """
        return self.tasks_api.find_all_api_tasks_reader_get(**kwargs)


    def get_facets_api_tasks_reader_facets_facet_field_get(self, facet_field, **kwargs):  # noqa: E501
        """Get Facets

        See ``TasksApi.get_facets_api_tasks_reader_facets_facet_field_get()`` for parameter details.
        """
        return self.tasks_api.get_facets_api_tasks_reader_facets_facet_field_get(facet_field, **kwargs)


    def get_reader_task(self, task_id, **kwargs):  # noqa: E501
        """Get By Id

        See ``TasksApi.get_reader_task()`` for parameter details.
        """
        return self.tasks_api.get_reader_task(task_id, **kwargs)


    def modify_reader_task(self, task_id, body, **kwargs):  # noqa: E501
        """Modify

        See ``TasksApi.modify_reader_task()`` for parameter details.
        """
        return self.tasks_api.modify_reader_task(task_id, body, **kwargs)


    def fetch_tree(self, body, **kwargs):  # noqa: E501
        """Query a portion of the flywheel hierarchy, returning only the requested fields.

        See ``TreeApi.fetch_tree()`` for parameter details.
        """
        return self.tree_api.fetch_tree(body, **kwargs)


    def get_tree_graph(self, **kwargs):  # noqa: E501
        """Get a description of the flywheel hiearchy

        See ``TreeApi.get_tree_graph()`` for parameter details.
        """
        return self.tree_api.get_tree_graph(**kwargs)


    def check_uids_exist(self, body, **kwargs):  # noqa: E501
        """Check for existence of UIDs system-wide

        See ``UidsApi.check_uids_exist()`` for parameter details.
        """
        return self.uids_api.check_uids_exist(body, **kwargs)


    def cleanup_signed_upload_url(self, body, **kwargs):  # noqa: E501
        """Cleanup unused file blob previously uploaded using signed URL

        See ``UploadApi.cleanup_signed_upload_url()`` for parameter details.
        """
        return self.upload_api.cleanup_signed_upload_url(body, **kwargs)


    def complete_s3_multipart_upload(self, body, **kwargs):  # noqa: E501
        """Complete S3 multipart signed url upload

        See ``UploadApi.complete_s3_multipart_upload()`` for parameter details.
        """
        return self.upload_api.complete_s3_multipart_upload(body, **kwargs)


    def create_signed_upload_url(self, body, **kwargs):  # noqa: E501
        """Create new signed upload URL

        See ``UploadApi.create_signed_upload_url()`` for parameter details.
        """
        return self.upload_api.create_signed_upload_url(body, **kwargs)


    def upload_by_label(self, **kwargs):  # noqa: E501
        """Multipart form upload with N file fields, each with their desired filename.

        See ``UploadApi.upload_by_label()`` for parameter details.
        """
        return self.upload_api.upload_by_label(**kwargs)


    def upload_by_reaper(self, **kwargs):  # noqa: E501
        """Bottom-up UID matching of Multipart form upload with N file fields, each with their desired filename.

        See ``UploadApi.upload_by_reaper()`` for parameter details.
        """
        return self.upload_api.upload_by_reaper(**kwargs)


    def upload_by_uid(self, **kwargs):  # noqa: E501
        """Multipart form upload with N file fields, each with their desired filename.

        See ``UploadApi.upload_by_uid()`` for parameter details.
        """
        return self.upload_api.upload_by_uid(**kwargs)


    def upload_signed_fs_file(self, token, body, **kwargs):  # noqa: E501
        """Upload file to local filesystem storage provider

        See ``UploadApi.upload_signed_fs_file()`` for parameter details.
        """
        return self.upload_api.upload_signed_fs_file(token, body, **kwargs)


    def add_user(self, body, **kwargs):  # noqa: E501
        """Add a new user

        See ``UsersApi.add_user()`` for parameter details.
        """
        return self.users_api.add_user(body, **kwargs)


    def delete_user(self, user_id, **kwargs):  # noqa: E501
        """Delete a user

        See ``UsersApi.delete_user()`` for parameter details.
        """
        return self.users_api.delete_user(user_id, **kwargs)


    def delete_user_key(self, id_, **kwargs):  # noqa: E501
        """Delete User Api Key

        See ``UsersApi.delete_user_key()`` for parameter details.
        """
        return self.users_api.delete_user_key(id_, **kwargs)


    def generate_user_key(self, body, **kwargs):  # noqa: E501
        """Generates user api key

        See ``UsersApi.generate_user_key()`` for parameter details.
        """
        return self.users_api.generate_user_key(body, **kwargs)


    def get_all_users(self, **kwargs):  # noqa: E501
        """Return a list of all users

        See ``UsersApi.get_all_users()`` for parameter details.
        """
        return self.users_api.get_all_users(**kwargs)


    def get_current_user(self, **kwargs):  # noqa: E501
        """Get information about the current user

        See ``UsersApi.get_current_user()`` for parameter details.
        """
        return self.users_api.get_current_user(**kwargs)


    def get_current_user_avatar(self, **kwargs):  # noqa: E501
        """Get the avatar of the current user

        See ``UsersApi.get_current_user_avatar()`` for parameter details.
        """
        return self.users_api.get_current_user_avatar(**kwargs)


    def get_current_user_info(self, **kwargs):  # noqa: E501
        """Get info of the current user

        See ``UsersApi.get_current_user_info()`` for parameter details.
        """
        return self.users_api.get_current_user_info(**kwargs)


    def get_current_user_jobs(self, **kwargs):  # noqa: E501
        """Return list of jobs created by the current user

        See ``UsersApi.get_current_user_jobs()`` for parameter details.
        """
        return self.users_api.get_current_user_jobs(**kwargs)


    def get_user(self, user_id, **kwargs):  # noqa: E501
        """Get information about the specified user

        See ``UsersApi.get_user()`` for parameter details.
        """
        return self.users_api.get_user(user_id, **kwargs)


    def get_user_acquisitions(self, uid, **kwargs):  # noqa: E501
        """Get all acquisitions that belong to the given user.

        See ``UsersApi.get_user_acquisitions()`` for parameter details.
        """
        return self.users_api.get_user_acquisitions(uid, **kwargs)


    def get_user_avatar(self, user_id, **kwargs):  # noqa: E501
        """Get the avatar of the specified user

        See ``UsersApi.get_user_avatar()`` for parameter details.
        """
        return self.users_api.get_user_avatar(user_id, **kwargs)


    def get_user_collections(self, user_id, **kwargs):  # noqa: E501
        """Get all collections that belong to the given user.

        See ``UsersApi.get_user_collections()`` for parameter details.
        """
        return self.users_api.get_user_collections(user_id, **kwargs)


    def get_user_groups(self, uid, **kwargs):  # noqa: E501
        """List all groups the specified user is a member of

        See ``UsersApi.get_user_groups()`` for parameter details.
        """
        return self.users_api.get_user_groups(uid, **kwargs)


    def get_user_projects(self, uid, **kwargs):  # noqa: E501
        """Get all projects that belong to the given user.

        See ``UsersApi.get_user_projects()`` for parameter details.
        """
        return self.users_api.get_user_projects(uid, **kwargs)


    def get_user_sessions(self, uid, **kwargs):  # noqa: E501
        """Get all sessions that belong to the given user.

        See ``UsersApi.get_user_sessions()`` for parameter details.
        """
        return self.users_api.get_user_sessions(uid, **kwargs)


    def modify_current_user_info(self, body, **kwargs):  # noqa: E501
        """Update or replace info for the current user.

        See ``UsersApi.modify_current_user_info()`` for parameter details.
        """
        return self.users_api.modify_current_user_info(body, **kwargs)


    def modify_user(self, uid, body, **kwargs):  # noqa: E501
        """Update the specified user

        See ``UsersApi.modify_user()`` for parameter details.
        """
        return self.users_api.modify_user(uid, body, **kwargs)


    def sync_user(self, cid, body, **kwargs):  # noqa: E501
        """Sync a center user to enterprise (Sync service use ONLY)

        See ``UsersApi.sync_user()`` for parameter details.
        """
        return self.users_api.sync_user(cid, body, **kwargs)


    def data_view_columns(self, **kwargs):  # noqa: E501
        """Return a list of all known column aliases for use in data views

        See ``ViewsApi.data_view_columns()`` for parameter details.
        """
        return self.views_api.data_view_columns(**kwargs)


    def delete_view(self, view_id, **kwargs):  # noqa: E501
        """Delete a data view

        See ``ViewsApi.delete_view()`` for parameter details.
        """
        return self.views_api.delete_view(view_id, **kwargs)


    def evaluate_view(self, view_id, container_id, **kwargs):  # noqa: E501
        """Execute a view, returning data in the preferred format.

        See ``ViewsApi.evaluate_view()`` for parameter details.
        """
        return self.views_api.evaluate_view(view_id, container_id, **kwargs)


    def evaluate_view_adhoc(self, container_id, body, **kwargs):  # noqa: E501
        """Execute an ad-hoc view, returning data in the preferred format.

        See ``ViewsApi.evaluate_view_adhoc()`` for parameter details.
        """
        return self.views_api.evaluate_view_adhoc(container_id, body, **kwargs)


    def get_view(self, view_id, **kwargs):  # noqa: E501
        """Return the view identified by ViewId

        See ``ViewsApi.get_view()`` for parameter details.
        """
        return self.views_api.get_view(view_id, **kwargs)


    def modify_view(self, view_id, body, **kwargs):  # noqa: E501
        """Update the view identified by ViewId

        See ``ViewsApi.modify_view()`` for parameter details.
        """
        return self.views_api.modify_view(view_id, body, **kwargs)


    def queue_adhoc(self, container_id, body, **kwargs):  # noqa: E501
        """Execute an ad-hoc view, returning a reference to the created data view execution.

        See ``ViewsApi.queue_adhoc()`` for parameter details.
        """
        return self.views_api.queue_adhoc(container_id, body, **kwargs)


    def queue_saved(self, view_id, container_id, **kwargs):  # noqa: E501
        """Execute a view, returning a reference to the created data view execution.

        See ``ViewsApi.queue_saved()`` for parameter details.
        """
        return self.views_api.queue_saved(view_id, container_id, **kwargs)


    def save_view_data_to_container(self, container_id, body, **kwargs):  # noqa: E501
        """Execute a view, saving data to the target container / file

        See ``ViewsApi.save_view_data_to_container()`` for parameter details.
        """
        return self.views_api.save_view_data_to_container(container_id, body, **kwargs)


    def enable_feature(self, value):
        """Enable feature named value, via the x-accept-feature header"""
        features = self.api_client.default_headers.get('x-accept-feature')
        features = features + ',' + value if features else value
        self.api_client.set_default_header('x-accept-feature', features)

    def perform_version_check(self):
        import re
        import warnings

        VERSION_RE = re.compile(r'^(?P<semver>(?P<major>\d+)\.(?P<minor>\d+)(\.(?P<patch>\d+)))+.*')
        release_version = '' # Older core only version
        flywheel_version = None # Newer umbrella version for entire application
        try:
            version_info = self.default_api.get_version()
            release_version = version_info.release
            flywheel_version = getattr(version_info, 'flywheel_release', None)
        except:
            pass

        # If not sdk version
        # Prefer the newer flywheel version but fallback to the older release version
        sdk_version_match = VERSION_RE.match(SDK_VERSION)
        if flywheel_version:
            release_version_match = VERSION_RE.match(flywheel_version)
        elif release_version:
            release_version_match = VERSION_RE.match(release_version)
        else:
            release_version_match = None

        # Log conditionals:
        # 1. Client or server version not set
        # 2. Major version mismatch
        # 3. SDK Minor version > Server Minor version (client features not available on server)
        # 4. SDK Minor version < Server Minor version (new features on server)

        show_pip_message = False
        if sdk_version_match and release_version_match:
            # Compare major/minor version
            sdk_major = int(sdk_version_match.group('major'))
            sdk_minor = int(sdk_version_match.group('minor'))

            release_major = int(release_version_match.group('major'))
            release_minor = int(release_version_match.group('minor'))

            if sdk_major != release_major:
                if SDK_VERSION.find('dev') == -1:
                    # Always print version mismatch
                    warnings.warn('Client version {} does not match server version {}. Please update your client version!'.format(SDK_VERSION, release_version))
                    show_pip_message = True

            elif self.check_version:
                if sdk_minor > release_minor:
                    log.warning('Client version {} is ahead of server version {}. '.format(SDK_VERSION, release_version) +
                        'Not all client functionality will be supported by the server.')
                    show_pip_message = True
                elif sdk_minor < release_minor:
                    log.warning('Client version {} is behind server version {}. '.format(SDK_VERSION, release_version) +
                        'Please consider upgrading your client to access all available functionality.')
                    show_pip_message = True
        elif self.check_version:
            warnings.warn('Client or server version not available! This is an unsupported configuration!')

        if show_pip_message:
            log.warning('Use "pip install flywheel-sdk~={}" '.format(release_version_match.group('semver')) +
                'to install a compatible version for this server')

    def add_nodes_to_collection(self, collection_id, level, node_ids, **kwargs):
        """Generic method to add a list of nodes to a collection.

        :param collection_id: The id of the collection to update
        :type collection_id: str
        :param level: The level of nodes to add (e.g. session or acquisition)
        :type level: str
        :param node_ids: The list of node ids of type level to add
        :type node_ids: list[str]
        :rtype: None
        """
        update = {
            'contents': {
                'operation': 'add',
                'nodes': [ {'_id': id, 'level': level} for id in node_ids ]
            }
        }
        return self.collections_api.modify_collection(collection_id, update, **kwargs)

    def add_sessions_to_collection(self, collection_id, session_ids, **kwargs):
        """Add a list of sessions to a collection.

        :param collection_id: The id of the collection to update
        :type collection_id: str
        :param session_ids: The list of session ids to add
        :type session_ids: list[str]
        :rtype: None
        """
        return self.add_nodes_to_collection(collection_id, 'session', session_ids, **kwargs)

    def add_acquisitions_to_collection(self, collection_id, acquisition_ids, **kwargs):
        """Add a list of acquisitions to a collection.

        :param collection_id: The id of the collection to update
        :type collection_id: str
        :param acquisition_ids: The list of acquisition ids to add
        :type acquisition_ids: list[str]
        :rtype: None
        """
        return self.add_nodes_to_collection(collection_id, 'acquisition', acquisition_ids, **kwargs)

    def change_job_state(self, job_id, state):
        """Change a job state.

        :param job_id: The id of the job to modify
        :type job_id: str
        :param state: The new job state
        :type state: str
        :rtype: None
        """
        return self.modify_job(job_id, { 'state': state })

    def get(self, id, **kwargs):
        """Retrieve the specified object by id.

        Objects that can be retrieved in this way are:
            group, project, session, subject, acquisition, analysis and collection

        :param id: The id of the object to retrieve
        :type id: str
        :rtype: ContainerOutput
        """
        return self.get_container(id, **kwargs)

    def resolve(self, path, **kwargs):
        """Perform a path based lookup of nodes in the Flywheel hierarchy.

        :param path: The path to resolve
        :type path: str
        :rtype: ResolverOutput
        """
        if not isinstance(path, list):
            path = path.split('/')

        return self.resolve_path(flywheel.ResolverInput(path=path), **kwargs)

    def lookup(self, path):
        """Perform a path based lookup of a single node in the Flywheel hierarchy.

        :param path: The path to resolve
        :type path: str
        :rtype: ResolverOutput
        """
        if not isinstance(path, list):
            path = path.split('/')

        return self.lookup_path(flywheel.ResolverInput(path=path))

    def file_url(self, path):
        """Perform a path based lookup of a file in the Flywheel hierarchy, and return a single-use download URL.

        :param path: The path to resolve
        :type path: str
        :return: The file URL if found, otherwise raises an error
        :rtype: str
        """
        result = self.resolve(path)
        if getattr(result.path[-1], 'container_type', None) != 'file':
            raise ValueError('Resolved path is not a file!')

        return result.path[-1].url()

    def download_tar(self, containers, dest_file, include_types=None, exclude_types=None):
        """Download the given set of containers as a tarball to dest_file.

        Supports downloading Projects, Sessions, Acquisitions and/or Analyses.

        :param containers: The container, or list of containers to download.
        :param dest_file: The destination file on disk
        :type dest_file: str
        :param include_types: The optional list of types to include in the download (e.g. ['nifti'])
        :type include_types: list[str], optional
        :param exclude_types: The optional list of types to exclude from the download (e.g. ['dicom'])
        :type exclude_types: list[str], optional
        :return: A summary of the download
        :rtype: DownloadTicketStub
        """
        return self._download(
            containers,
            dest_file,
            "tar",
            include_types=include_types,
            exclude_types=exclude_types,
        )

    def download_zip(self, containers, dest_file, include_types=None, exclude_types=None):
        """Download the given set of containers as a zip archive to dest_file.

        Supports downloading Projects, Sessions, Acquisitions and/or Analyses.

        :param containers: The container, or list of containers to download.
        :param dest_file: The destination file on disk
        :type dest_file: str
        :param include_types: The optional list of types to include in the download (e.g. ['nifti'])
        :type include_types: list[str], optional
        :param exclude_types: The optional list of types to exclude from the download (e.g. ['dicom'])
        :type exclude_types: list[str], optional
        :return: A summary of the download
        :rtype: DownloadTicketStub
        """
        return self._download(
            containers,
            dest_file,
            "zip",
            include_types=include_types,
            exclude_types=exclude_types,
        )

    def _download(self, containers, dest_file, format, include_types=None, exclude_types=None):
        if not isinstance(containers, list):
            containers = [containers]

        # Extract the list of nodes
        nodes = []
        for container in containers:
            container_type = getattr(container, 'container_type', None)
            if container_type is None:
                raise ValueError('Unknown container specified!')

            nodes.append(flywheel.DownloadNode(level=container_type, id=container.id))

        # Setup filters
        type_filter = None
        if include_types or exclude_types:
            type_filter = flywheel.DownloadFilterDefinition(plus=include_types, minus=exclude_types)

        download_filters = None
        if type_filter:
            download_filters = [flywheel.DownloadFilter(types=type_filter)]

        # Create download request
        request = flywheel.Download(nodes=nodes, filters=download_filters, optional=True)
        summary = self.create_download_ticket(request)

        # Perform download
        self.download_ticket(summary.ticket, dest_file, format=format)
        return summary

    def download_file_from_acquisition_as_data(self, acquisition_id, file_name, **kwargs):
        """Download a file.

        Returns binary file data instead of downloading to a file. See ``AcquisitionsApi.download_file_from_acquisition()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.acquisitions_api.download_file_from_acquisition_with_http_info(acquisition_id, file_name, **kwargs)
        if resp:
            return resp.content
        return None

    def download_input_from_acquisition_analysis_as_data(self, acquisition_id, analysis_id, filename, **kwargs):
        """Download analysis inputs with filter.

        Returns binary file data instead of downloading to a file. See ``AcquisitionsApi.download_input_from_acquisition_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.acquisitions_api.download_input_from_acquisition_analysis_with_http_info(acquisition_id, analysis_id, filename, **kwargs)
        if resp:
            return resp.content
        return None

    def download_output_from_acquisition_analysis_as_data(self, acquisition_id, analysis_id, filename, **kwargs):
        """Download analysis outputs with filter.

        Returns binary file data instead of downloading to a file. See ``AcquisitionsApi.download_output_from_acquisition_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.acquisitions_api.download_output_from_acquisition_analysis_with_http_info(acquisition_id, analysis_id, filename, **kwargs)
        if resp:
            return resp.content
        return None

    def set_acquisition_file_classification(self, cid, filename, body, **kwargs):
        """Update classification with the provided fields.

        See ``AcquisitionsApi.modify_acquisition_file_classification()`` for parameter details.
        """
        body = { 'add': body }
        return self.acquisitions_api.modify_acquisition_file_classification(cid, filename, body, **kwargs)

    def replace_acquisition_file_classification(self, cid, filename, body, **kwargs):
        """Entirely replace classification with the provided fields.

        See ``AcquisitionsApi.modify_acquisition_file_classification()`` for parameter details.
        """
        body = { 'replace': body }
        return self.acquisitions_api.modify_acquisition_file_classification(cid, filename, body, **kwargs)

    def delete_acquisition_file_classification_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``AcquisitionsApi.modify_acquisition_file_classification()`` for parameter details.
        """
        body = { 'delete': body }
        return self.acquisitions_api.modify_acquisition_file_classification(cid, filename, body, **kwargs)

    def set_acquisition_file_info(self, cid, filename, body, **kwargs):
        """Update info with the provided fields.

        See ``AcquisitionsApi.modify_acquisition_file_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.acquisitions_api.modify_acquisition_file_info(cid, filename, body, **kwargs)

    def replace_acquisition_file_info(self, cid, filename, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``AcquisitionsApi.modify_acquisition_file_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.acquisitions_api.modify_acquisition_file_info(cid, filename, body, **kwargs)

    def delete_acquisition_file_info_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``AcquisitionsApi.modify_acquisition_file_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.acquisitions_api.modify_acquisition_file_info(cid, filename, body, **kwargs)

    def set_acquisition_info(self, cid, body, **kwargs):
        """Update info with the provided fields.

        See ``AcquisitionsApi.modify_acquisition_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.acquisitions_api.modify_acquisition_info(cid, body, **kwargs)

    def replace_acquisition_info(self, cid, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``AcquisitionsApi.modify_acquisition_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.acquisitions_api.modify_acquisition_info(cid, body, **kwargs)

    def delete_acquisition_info_fields(self, cid, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``AcquisitionsApi.modify_acquisition_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.acquisitions_api.modify_acquisition_info(cid, body, **kwargs)

    def download_file_from_analysis_as_data(self, analysis_id, file_name, **kwargs):
        """Download a file.

        Returns binary file data instead of downloading to a file. See ``AnalysesApi.download_file_from_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.analyses_api.download_file_from_analysis_with_http_info(analysis_id, file_name, **kwargs)
        if resp:
            return resp.content
        return None

    def download_input_from_analysis_as_data(self, analysis_id, filename, **kwargs):
        """Download analysis inputs with filter.

        Returns binary file data instead of downloading to a file. See ``AnalysesApi.download_input_from_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.analyses_api.download_input_from_analysis_with_http_info(analysis_id, filename, **kwargs)
        if resp:
            return resp.content
        return None

    def download_output_from_analysis_as_data(self, analysis_id, filename, **kwargs):
        """Download output file from analysis

        Returns binary file data instead of downloading to a file. See ``AnalysesApi.download_output_from_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.analyses_api.download_output_from_analysis_with_http_info(analysis_id, filename, **kwargs)
        if resp:
            return resp.content
        return None

    def set_analysis_file_classification(self, cid, filename, body, **kwargs):
        """Update classification with the provided fields.

        See ``AnalysesApi.modify_analysis_file_classification()`` for parameter details.
        """
        body = { 'add': body }
        return self.analyses_api.modify_analysis_file_classification(cid, filename, body, **kwargs)

    def replace_analysis_file_classification(self, cid, filename, body, **kwargs):
        """Entirely replace classification with the provided fields.

        See ``AnalysesApi.modify_analysis_file_classification()`` for parameter details.
        """
        body = { 'replace': body }
        return self.analyses_api.modify_analysis_file_classification(cid, filename, body, **kwargs)

    def delete_analysis_file_classification_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``AnalysesApi.modify_analysis_file_classification()`` for parameter details.
        """
        body = { 'delete': body }
        return self.analyses_api.modify_analysis_file_classification(cid, filename, body, **kwargs)

    def set_analysis_file_info(self, cid, filename, body, **kwargs):
        """Update info with the provided fields.

        See ``AnalysesApi.modify_analysis_file_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.analyses_api.modify_analysis_file_info(cid, filename, body, **kwargs)

    def replace_analysis_file_info(self, cid, filename, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``AnalysesApi.modify_analysis_file_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.analyses_api.modify_analysis_file_info(cid, filename, body, **kwargs)

    def delete_analysis_file_info_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``AnalysesApi.modify_analysis_file_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.analyses_api.modify_analysis_file_info(cid, filename, body, **kwargs)

    def set_analysis_info(self, container_id, body, **kwargs):
        """Update info with the provided fields.

        See ``AnalysesApi.modify_analysis_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.analyses_api.modify_analysis_info(container_id, body, **kwargs)

    def replace_analysis_info(self, container_id, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``AnalysesApi.modify_analysis_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.analyses_api.modify_analysis_info(container_id, body, **kwargs)

    def delete_analysis_info_fields(self, container_id, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``AnalysesApi.modify_analysis_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.analyses_api.modify_analysis_info(container_id, body, **kwargs)

    def download_file_from_collection_as_data(self, collection_id, file_name, **kwargs):
        """Download a file.

        Returns binary file data instead of downloading to a file. See ``CollectionsApi.download_file_from_collection()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.collections_api.download_file_from_collection_with_http_info(collection_id, file_name, **kwargs)
        if resp:
            return resp.content
        return None

    def set_collection_file_classification(self, cid, filename, body, **kwargs):
        """Update classification with the provided fields.

        See ``CollectionsApi.modify_collection_file_classification()`` for parameter details.
        """
        body = { 'add': body }
        return self.collections_api.modify_collection_file_classification(cid, filename, body, **kwargs)

    def replace_collection_file_classification(self, cid, filename, body, **kwargs):
        """Entirely replace classification with the provided fields.

        See ``CollectionsApi.modify_collection_file_classification()`` for parameter details.
        """
        body = { 'replace': body }
        return self.collections_api.modify_collection_file_classification(cid, filename, body, **kwargs)

    def delete_collection_file_classification_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``CollectionsApi.modify_collection_file_classification()`` for parameter details.
        """
        body = { 'delete': body }
        return self.collections_api.modify_collection_file_classification(cid, filename, body, **kwargs)

    def set_collection_file_info(self, cid, filename, body, **kwargs):
        """Update info with the provided fields.

        See ``CollectionsApi.modify_collection_file_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.collections_api.modify_collection_file_info(cid, filename, body, **kwargs)

    def replace_collection_file_info(self, cid, filename, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``CollectionsApi.modify_collection_file_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.collections_api.modify_collection_file_info(cid, filename, body, **kwargs)

    def delete_collection_file_info_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``CollectionsApi.modify_collection_file_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.collections_api.modify_collection_file_info(cid, filename, body, **kwargs)

    def set_collection_info(self, cid, body, **kwargs):
        """Update info with the provided fields.

        See ``CollectionsApi.modify_collection_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.collections_api.modify_collection_info(cid, body, **kwargs)

    def replace_collection_info(self, cid, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``CollectionsApi.modify_collection_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.collections_api.modify_collection_info(cid, body, **kwargs)

    def delete_collection_info_fields(self, cid, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``CollectionsApi.modify_collection_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.collections_api.modify_collection_info(cid, body, **kwargs)

    def download_file_from_container_as_data(self, container_id, file_name, **kwargs):
        """Download a file.

        Returns binary file data instead of downloading to a file. See ``ContainersApi.download_file_from_container()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.containers_api.download_file_from_container_with_http_info(container_id, file_name, **kwargs)
        if resp:
            return resp.content
        return None

    def download_input_from_container_analysis_as_data(self, container_id, analysis_id, filename, **kwargs):
        """Download analysis inputs with filter.

        Returns binary file data instead of downloading to a file. See ``ContainersApi.download_input_from_container_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.containers_api.download_input_from_container_analysis_with_http_info(container_id, analysis_id, filename, **kwargs)
        if resp:
            return resp.content
        return None

    def download_output_from_container_analysis_as_data(self, container_id, analysis_id, filename, **kwargs):
        """Download analysis outputs with filter.

        Returns binary file data instead of downloading to a file. See ``ContainersApi.download_output_from_container_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.containers_api.download_output_from_container_analysis_with_http_info(container_id, analysis_id, filename, **kwargs)
        if resp:
            return resp.content
        return None

    def set_container_file_classification(self, cid, filename, body, **kwargs):
        """Update classification with the provided fields.

        See ``ContainersApi.modify_container_file_classification()`` for parameter details.
        """
        body = { 'add': body }
        return self.containers_api.modify_container_file_classification(cid, filename, body, **kwargs)

    def replace_container_file_classification(self, cid, filename, body, **kwargs):
        """Entirely replace classification with the provided fields.

        See ``ContainersApi.modify_container_file_classification()`` for parameter details.
        """
        body = { 'replace': body }
        return self.containers_api.modify_container_file_classification(cid, filename, body, **kwargs)

    def delete_container_file_classification_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``ContainersApi.modify_container_file_classification()`` for parameter details.
        """
        body = { 'delete': body }
        return self.containers_api.modify_container_file_classification(cid, filename, body, **kwargs)

    def set_container_file_info(self, cid, filename, body, **kwargs):
        """Update info with the provided fields.

        See ``ContainersApi.modify_container_file_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.containers_api.modify_container_file_info(cid, filename, body, **kwargs)

    def replace_container_file_info(self, cid, filename, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``ContainersApi.modify_container_file_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.containers_api.modify_container_file_info(cid, filename, body, **kwargs)

    def delete_container_file_info_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``ContainersApi.modify_container_file_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.containers_api.modify_container_file_info(cid, filename, body, **kwargs)

    def set_container_info(self, cid, body, **kwargs):
        """Update info with the provided fields.

        See ``ContainersApi.modify_container_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.containers_api.modify_container_info(cid, body, **kwargs)

    def replace_container_info(self, cid, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``ContainersApi.modify_container_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.containers_api.modify_container_info(cid, body, **kwargs)

    def delete_container_info_fields(self, cid, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``ContainersApi.modify_container_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.containers_api.modify_container_info(cid, body, **kwargs)

    def download_ticket_as_data(self, ticket, **kwargs):
        """Download files listed in the given ticket.

        Returns binary file data instead of downloading to a file. See ``DownloadApi.download_ticket()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.download_api.download_ticket_with_http_info(ticket, **kwargs)
        if resp:
            return resp.content
        return None

    def download_file_from_project_as_data(self, project_id, file_name, **kwargs):
        """Download a file.

        Returns binary file data instead of downloading to a file. See ``ProjectsApi.download_file_from_project()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.projects_api.download_file_from_project_with_http_info(project_id, file_name, **kwargs)
        if resp:
            return resp.content
        return None

    def download_input_from_project_analysis_as_data(self, project_id, analysis_id, filename, **kwargs):
        """Download analysis inputs with filter.

        Returns binary file data instead of downloading to a file. See ``ProjectsApi.download_input_from_project_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.projects_api.download_input_from_project_analysis_with_http_info(project_id, analysis_id, filename, **kwargs)
        if resp:
            return resp.content
        return None

    def download_output_from_project_analysis_as_data(self, project_id, analysis_id, filename, **kwargs):
        """Download analysis outputs with filter.

        Returns binary file data instead of downloading to a file. See ``ProjectsApi.download_output_from_project_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.projects_api.download_output_from_project_analysis_with_http_info(project_id, analysis_id, filename, **kwargs)
        if resp:
            return resp.content
        return None

    def set_project_file_classification(self, cid, filename, body, **kwargs):
        """Update classification with the provided fields.

        See ``ProjectsApi.modify_project_file_classification()`` for parameter details.
        """
        body = { 'add': body }
        return self.projects_api.modify_project_file_classification(cid, filename, body, **kwargs)

    def replace_project_file_classification(self, cid, filename, body, **kwargs):
        """Entirely replace classification with the provided fields.

        See ``ProjectsApi.modify_project_file_classification()`` for parameter details.
        """
        body = { 'replace': body }
        return self.projects_api.modify_project_file_classification(cid, filename, body, **kwargs)

    def delete_project_file_classification_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``ProjectsApi.modify_project_file_classification()`` for parameter details.
        """
        body = { 'delete': body }
        return self.projects_api.modify_project_file_classification(cid, filename, body, **kwargs)

    def set_project_file_info(self, cid, filename, body, **kwargs):
        """Update info with the provided fields.

        See ``ProjectsApi.modify_project_file_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.projects_api.modify_project_file_info(cid, filename, body, **kwargs)

    def replace_project_file_info(self, cid, filename, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``ProjectsApi.modify_project_file_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.projects_api.modify_project_file_info(cid, filename, body, **kwargs)

    def delete_project_file_info_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``ProjectsApi.modify_project_file_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.projects_api.modify_project_file_info(cid, filename, body, **kwargs)

    def set_project_info(self, cid, body, **kwargs):
        """Update info with the provided fields.

        See ``ProjectsApi.modify_project_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.projects_api.modify_project_info(cid, body, **kwargs)

    def replace_project_info(self, cid, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``ProjectsApi.modify_project_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.projects_api.modify_project_info(cid, body, **kwargs)

    def delete_project_info_fields(self, cid, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``ProjectsApi.modify_project_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.projects_api.modify_project_info(cid, body, **kwargs)

    def download_file_from_session_as_data(self, session_id, file_name, **kwargs):
        """Download a file.

        Returns binary file data instead of downloading to a file. See ``SessionsApi.download_file_from_session()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.sessions_api.download_file_from_session_with_http_info(session_id, file_name, **kwargs)
        if resp:
            return resp.content
        return None

    def download_input_from_session_analysis_as_data(self, session_id, analysis_id, filename, **kwargs):
        """Download analysis inputs with filter.

        Returns binary file data instead of downloading to a file. See ``SessionsApi.download_input_from_session_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.sessions_api.download_input_from_session_analysis_with_http_info(session_id, analysis_id, filename, **kwargs)
        if resp:
            return resp.content
        return None

    def download_output_from_session_analysis_as_data(self, session_id, analysis_id, filename, **kwargs):
        """Download analysis outputs with filter.

        Returns binary file data instead of downloading to a file. See ``SessionsApi.download_output_from_session_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.sessions_api.download_output_from_session_analysis_with_http_info(session_id, analysis_id, filename, **kwargs)
        if resp:
            return resp.content
        return None

    def set_session_file_classification(self, cid, filename, body, **kwargs):
        """Update classification with the provided fields.

        See ``SessionsApi.modify_session_file_classification()`` for parameter details.
        """
        body = { 'add': body }
        return self.sessions_api.modify_session_file_classification(cid, filename, body, **kwargs)

    def replace_session_file_classification(self, cid, filename, body, **kwargs):
        """Entirely replace classification with the provided fields.

        See ``SessionsApi.modify_session_file_classification()`` for parameter details.
        """
        body = { 'replace': body }
        return self.sessions_api.modify_session_file_classification(cid, filename, body, **kwargs)

    def delete_session_file_classification_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``SessionsApi.modify_session_file_classification()`` for parameter details.
        """
        body = { 'delete': body }
        return self.sessions_api.modify_session_file_classification(cid, filename, body, **kwargs)

    def set_session_file_info(self, cid, filename, body, **kwargs):
        """Update info with the provided fields.

        See ``SessionsApi.modify_session_file_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.sessions_api.modify_session_file_info(cid, filename, body, **kwargs)

    def replace_session_file_info(self, cid, filename, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``SessionsApi.modify_session_file_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.sessions_api.modify_session_file_info(cid, filename, body, **kwargs)

    def delete_session_file_info_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``SessionsApi.modify_session_file_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.sessions_api.modify_session_file_info(cid, filename, body, **kwargs)

    def set_session_info(self, cid, body, **kwargs):
        """Update info with the provided fields.

        See ``SessionsApi.modify_session_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.sessions_api.modify_session_info(cid, body, **kwargs)

    def replace_session_info(self, cid, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``SessionsApi.modify_session_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.sessions_api.modify_session_info(cid, body, **kwargs)

    def delete_session_info_fields(self, cid, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``SessionsApi.modify_session_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.sessions_api.modify_session_info(cid, body, **kwargs)

    def download_file_from_subject_as_data(self, subject_id, file_name, **kwargs):
        """Download a file.

        Returns binary file data instead of downloading to a file. See ``SubjectsApi.download_file_from_subject()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.subjects_api.download_file_from_subject_with_http_info(subject_id, file_name, **kwargs)
        if resp:
            return resp.content
        return None

    def download_input_from_subject_analysis_as_data(self, subject_id, analysis_id, filename, **kwargs):
        """Download analysis inputs with filter.

        Returns binary file data instead of downloading to a file. See ``SubjectsApi.download_input_from_subject_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.subjects_api.download_input_from_subject_analysis_with_http_info(subject_id, analysis_id, filename, **kwargs)
        if resp:
            return resp.content
        return None

    def download_output_from_subject_analysis_as_data(self, subject_id, analysis_id, filename, **kwargs):
        """Download analysis outputs with filter.

        Returns binary file data instead of downloading to a file. See ``SubjectsApi.download_output_from_subject_analysis()`` for parameter details.

        :return: The binary file data
        :rtype: bytes
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False
        (resp) = self.subjects_api.download_output_from_subject_analysis_with_http_info(subject_id, analysis_id, filename, **kwargs)
        if resp:
            return resp.content
        return None

    def set_subject_file_classification(self, cid, filename, body, **kwargs):
        """Update classification with the provided fields.

        See ``SubjectsApi.modify_subject_file_classification()`` for parameter details.
        """
        body = { 'add': body }
        return self.subjects_api.modify_subject_file_classification(cid, filename, body, **kwargs)

    def replace_subject_file_classification(self, cid, filename, body, **kwargs):
        """Entirely replace classification with the provided fields.

        See ``SubjectsApi.modify_subject_file_classification()`` for parameter details.
        """
        body = { 'replace': body }
        return self.subjects_api.modify_subject_file_classification(cid, filename, body, **kwargs)

    def delete_subject_file_classification_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``SubjectsApi.modify_subject_file_classification()`` for parameter details.
        """
        body = { 'delete': body }
        return self.subjects_api.modify_subject_file_classification(cid, filename, body, **kwargs)

    def set_subject_file_info(self, cid, filename, body, **kwargs):
        """Update info with the provided fields.

        See ``SubjectsApi.modify_subject_file_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.subjects_api.modify_subject_file_info(cid, filename, body, **kwargs)

    def replace_subject_file_info(self, cid, filename, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``SubjectsApi.modify_subject_file_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.subjects_api.modify_subject_file_info(cid, filename, body, **kwargs)

    def delete_subject_file_info_fields(self, cid, filename, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``SubjectsApi.modify_subject_file_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.subjects_api.modify_subject_file_info(cid, filename, body, **kwargs)

    def set_subject_info(self, cid, body, **kwargs):
        """Update info with the provided fields.

        See ``SubjectsApi.modify_subject_info()`` for parameter details.
        """
        body = { 'set': body }
        return self.subjects_api.modify_subject_info(cid, body, **kwargs)

    def replace_subject_info(self, cid, body, **kwargs):
        """Entirely replace info with the provided fields.

        See ``SubjectsApi.modify_subject_info()`` for parameter details.
        """
        body = { 'replace': body }
        return self.subjects_api.modify_subject_info(cid, body, **kwargs)

    def delete_subject_info_fields(self, cid, body, **kwargs):
        """Delete the specified fields from  + name + .

        See ``SubjectsApi.modify_subject_info()`` for parameter details.
        """
        body = { 'delete': body }
        return self.subjects_api.modify_subject_info(cid, body, **kwargs)


    def View(self, **kwargs):
        """Short-hand for ``flywheel.ViewBuilder(**kwargs).build()``

        :param kwargs: The arguments to pass directly to ViewBuilder
        :return: The built data view
        """
        return ViewBuilder(**kwargs).build()

    def print_view_columns(self, filter=None, limit=25, file=sys.stdout):
        """Print a list of column aliases that can be used in data views.

        :param filter: The filter for available columns
        :type filter: str, optional
        :param limit: The limit for the number of columns to return
        :type limit: int, optional
        :param file: The file to print to
        :type file: file-like
        """
        columns = self.views_api.data_view_columns()
        columns = [
            column.to_dict()
            for column in columns
            if filter is None or filter.lower() in column.name.lower()
        ]
        if filter:
            self._fw.api_client.call_api(
                "/dataexplorer/search/fields",
                "POST",
                body={"field": filter},
                auth_settings=["ApiKey"],
            )
            elastic_columns = self._fw.api_client.last_response.data
            # Concat elastic fields
            columns = elastic_columns + columns
        for column in columns[:limit]:
            if column.get("group"):
                coltype = "group"
            else:
                coltype = column.get("type")
            six.print_('{} ({}): {}'.format(column["name"], coltype, column.get("description", "")), file=file)

    def read_view_data(self, view, container_id, decode=True, **kwargs):
        """Execute a data view against container, and return a file-like object that can be streamed.

        :param view: The view id or DataView object to execute.
        :type view: str or DataView
        :param container_id: The id of the container to execute the view against
        :type container_id: str
        :param decode: Whether or not to decode the stream to utf-8 (default is true)
        :type decode: bool, optional
        :param kwargs: Additional arguments to pass to the evaluate_view call. (e.g. format='csv')
        :return: A file-like object where the contents can be read
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False

        current_version = self.get_version().get("release")
        parsed_version = None
        try:
            parsed_version = version.parse(current_version)
        except version.InvalidVersion:
            pass
        if parsed_version is not None and parsed_version < version.parse("16.8.0"):
            if not isinstance(view, six.string_types):
                if view.error_column is not None:
                    log.warning(
                        "Error column not supported with %s API version, value will be ignored",
                        current_version
                    )
                view.swagger_types.pop("error_column", None)

        view_format = kwargs.pop('format', 'json')

        if isinstance(view, six.string_types):
            resp = self.views_api.queue_saved(view, container_id, **kwargs)
        else:
            resp = self.views_api.queue_adhoc(container_id, view, **kwargs)

        data_view_execution_id = resp.json()["_id"]

        while True:
            data_view_execution = self.get_data_view_execution(data_view_execution_id)
            if data_view_execution.state == 'failed':
                raise RuntimeError("Execution of data view failed")
            if data_view_execution.state == 'completed':
                break
            time.sleep(1)

        kwargs['file_format'] = view_format
        retrieve_data_kwargs = {k: v for k, v in kwargs.items() if k not in ["filter", "skip", "limit"]}

        resp = self.get_data_view_execution_data(data_view_execution_id, **retrieve_data_kwargs)

        resp.raw.decode_content = True
        if decode:
            return codecs.getreader(resp.encoding)(resp.raw)
        return resp.raw


    def read_view_dataframe(self, view, container_id, opts=None, **kwargs):
        """Execute a data view against container, and return a DataFrame.

        NOTE: This requires that the pandas module be installed on the system.

        :param view: The view id or DataView object to execute.
        :type view: str or DataView
        :param container_id: The id of the container to execute the view against
        :type container_id: str
        :param opts: Additional options to pass to the pandas read_json function
        :type opts: dict, optional
        :param kwargs: Additional arguments to pass to the evaluate_view call.
        :return: A pandas DataFrame
        """
        import pandas

        if opts is None:
            opts = {}

        kwargs['format'] = 'json-flat'
        resp = self.read_view_data(view, container_id, decode=False, **kwargs)
        if resp:
            try:
                df = pandas.read_json(resp, orient='records', **opts)
                return df
            finally:
                resp.close()
        return None


    def save_view_data_task_manager(self, view,container_id, dest_file, **kwargs):
        view_format = kwargs.pop('format', 'json')

        if isinstance(view, six.string_types):
            resp = self.views_api.queue_saved(view, container_id, **kwargs)
        else:
            resp = self.views_api.queue_adhoc(container_id, view, **kwargs)

        data_view_execution_id = resp.json()["_id"]

        while True:
            data_view_execution = self.get_data_view_execution(resp.json()['_id'])
            if data_view_execution.state == 'failed':
                raise RuntimeError("Execution of data view failed")
            if data_view_execution.state == 'completed':
                break

        kwargs['file_format'] = view_format


        # Stream response to file
        with open(dest_file, 'wb') as out_file:
            retrieve_data_kwargs = {k: v for k, v in kwargs.items() if k not in ["filter", "skip", "limit"]}
            resp = self.get_data_view_execution_data(data_view_execution_id, **retrieve_data_kwargs)

            if resp:
                try:
                    for chunk in resp.iter_content(chunk_size=65536):
                        out_file.write(chunk)
                finally:
                    resp.close()


    def save_view_data(self, view, container_id, dest_file, **kwargs):
        """Execute a data view against container, and save the results to disk.

        :param view: The view id or DataView object to execute.
        :type view: str or DataView
        :param container_id: The id of the container to execute the view against
        :type container_id: str
        :param dest_file: The destination file path
        :type dest_file: str
        :param kwargs: Additional arguments to pass to the evaluate_view call. (e.g. format='csv')
        """
        kwargs['_return_http_data_only'] = True
        kwargs['_preload_content'] = False

        self.save_view_data_task_manager(view,container_id, dest_file, **kwargs)
        return

        # Stream response to file
        with open(dest_file, 'wb') as out_file:
            if isinstance(view, six.string_types):
                resp = self.views_api.evaluate_view_with_http_info(view, container_id, **kwargs)
            else:
                resp = self.views_api.evaluate_view_adhoc_with_http_info(container_id, view, **kwargs)

            if resp:
                try:
                    for chunk in resp.iter_content(chunk_size=65536):
                        out_file.write(chunk)
                finally:
                    resp.close()

    # Signed upload
    def signed_upload_output_to_analysis(self, cid, file, **kwargs):
        return self._signed_upload("analysis", cid, file, **kwargs)

    def signed_upload_output_to_acquisition_analysis(self, _, cid, file, **kwargs):
        return self._signed_upload("analysis", cid, file, **kwargs)

    def signed_upload_output_to_collection_analysis(self, _, cid, file, **kwargs):
        return self._signed_upload("analysis", cid, file, **kwargs)

    def signed_upload_output_to_container_analysis(self, _, cid, file, **kwargs):
        return self._signed_upload("analysis", cid, file, **kwargs)

    def signed_upload_output_to_project_analysis(self, _, cid, file, **kwargs):
        return self._signed_upload("analysis", cid, file, **kwargs)

    def signed_upload_output_to_session_analysis(self, _, cid, file, **kwargs):
        return self._signed_upload("analysis", cid, file, **kwargs)

    def signed_upload_output_to_subject_analysis(self, _, cid, file, **kwargs):
        return self._signed_upload("analysis", cid, file, **kwargs)

    def signed_upload_file_to_acquisition(self, cid, file, **kwargs):
        return self._signed_upload("acquisition", cid, file, **kwargs)

    def signed_upload_file_to_collection(self, cid, file, **kwargs):
        return self._signed_upload("collection", cid, file, **kwargs)

    def signed_upload_file_to_container(self, cid, file, **kwargs):
        return self._signed_upload("container", cid, file, **kwargs)

    def signed_upload_file_to_project(self, cid, file, **kwargs):
        return self._signed_upload("project", cid, file, **kwargs)

    def signed_upload_file_to_session(self, cid, file, **kwargs):
        return self._signed_upload("session", cid, file, **kwargs)

    def signed_upload_file_to_subject(self, cid, file, **kwargs):
        return self._signed_upload("subject", cid, file, **kwargs)

    def _signed_upload(self, ctype, cid, file, **kwargs):
        config = self.get_config()
        features = config.get("features")
        f1 = features.get("signed_url", False) if features else False
        f2 = config.get("signed_url", False)
        if not (f1 or f2):
            log.debug("Skipping signed upload because the site does not support it")
            return None

        if not isinstance(file, (list, tuple)):
            file = [file]
        metadata_list = None
        if "metadata" in kwargs:
            metadata = kwargs["metadata"]
            # JSON-decode
            if isinstance(metadata, str):
                metadata = json.loads(metadata)
            if isinstance(metadata, (list, tuple)):
                metadata_list = metadata
        response = list()
        if metadata_list:
            if len(metadata_list) != len(file):
                raise ValueError("Metadata list must be the same length as file list")
            for subfile, md in zip(file, metadata_list):
                kwargs["metadata"] = md
                resp = self._signed_upload_single_file(ctype, cid, subfile, **kwargs)
                if resp is not None:
                    response.extend(resp)
        else:
            for subfile in file:
                resp = self._signed_upload_single_file(ctype, cid, subfile, **kwargs)
                if resp:
                    response.extend(resp)
        if not response:
            return None
        else:
            return response

    def _signed_upload_single_file(self, ctype, cid, file, **kwargs):
        fsize = None
        if isinstance(file, str):
            fname = os.path.basename(file)
            fsize = os.path.getsize(file)
            fdata = open(file, "rb")
            mimetype = mimetypes.guess_type(fname) or "application/octet-stream"
        else: # FileSpec
            fname, fdata, mimetype = file.to_file_tuple()
            if isinstance(fdata, str):
                file.size = len(fdata)
                fdata = io.StringIO(fdata)
            elif isinstance(fdata, bytes):
                file.size = len(fdata)
                fdata = io.BytesIO(fdata)

            if file.size is None:
                raise ValueError("Need to set file.size (in bytes) on input FileSpec")
            fsize = file.size

        # Create upload ticket
        metadata = kwargs.pop("metadata", {})
        if not isinstance(metadata, str):
            metadata.setdefault("name", fname)
            if fsize:
                metadata.setdefault("size", fsize)
            if ctype == "analysis":
                metadata = [metadata]
        plural_ctype = "analyses" if ctype == "analysis" else ctype + "s"
        create_ticket_response = self._ticketed_upload(plural_ctype, cid, fname,
            metadata=metadata, **kwargs)

        ticket = create_ticket_response["ticket"]
        urls = create_ticket_response["urls"][fname]
        if not isinstance(urls, list):
            urls = [urls]
        headers = create_ticket_response["headers"]

        etags_info = None
        try:
            etags_info = self._upload_to_signed_url(urls, fdata, fsize, headers)
        finally:
            if isinstance(file, str):
                fdata.close()
            if etags_info:
                kwargs["etags"] = etags_info

            # Close ticket
            close_ticket_response = self._ticketed_upload(plural_ctype, cid, None,
                None, ticket=ticket, **kwargs)
        return close_ticket_response

    def _ticketed_upload(self, ctype, cid, fname, metadata=None, ticket="", **params):
        query_params = [("ticket", ticket)]
        if "preserve_metadata" in params:
            query_params.append(("preserve_metadata", params["preserve_metadata"]))

        collection_formats = {}
        header_params = {
            "Accept": self.api_client.select_header_accept(["application/json"]),
        }
        if "x_accept_feature" in params:
            header_params["x-accept-feature"] = params["x_accept_feature"]
            collection_formats["x-accept-feature"] = ""

        kwargs = {}
        if ticket == "":
            kwargs["body"] = {"metadata": metadata or {}, "filenames": [fname]}
            kwargs["response_type"] = object
        else:
            kwargs["response_type"] = "list[FileOutput]"
            if "etags" in params:
                kwargs["body"] = {"multipart": params["etags"]}

        kwargs.setdefault("_return_http_data_only", True)
        kwargs.setdefault("_preload_content", True)
        kwargs["collection_formats"] = collection_formats
        kwargs["auth_settings"] = ["ApiKey"]

        return self.api_client.call_api("/{ctype}/{container_id}/files", "POST",
            {"ctype": ctype, "container_id": cid},
            query_params,
            header_params,
            **kwargs)


    def _upload_to_signed_url(self, urls, fdata, fsize, headers):
        is_s3_upload = ".s3." in urls[0] or ".amazonaws." in urls[0]
        is_gc_upload = ".googleapis." in urls[0]
        e_tags = list()
        upload_id = None

        num_urls = len(urls)
        # gcp requires chunks uploaded at a 256Kb alignment
        alignment_size = 256 * 1024
        even_split_size = math.ceil(fsize / num_urls)
        split_size_offset = alignment_size - (even_split_size % alignment_size)
        part_size = even_split_size + split_size_offset
        for part_num, url in enumerate(urls):
            remaining = fsize - part_size * part_num
            content_length = remaining if remaining < part_size else part_size
            reader = PartialReader(fdata, content_length)
            if is_gc_upload:
                headers['Content-Length'] = str(content_length)
                start = part_num * part_size
                end = start + content_length - 1
                headers['Content-Range'] = f"bytes {start}-{end}/{fsize}"
            upload_response = self.api_client.rest_client.session.put(
                url, data=reader, headers=headers
            )
            upload_response.raise_for_status()
            if is_s3_upload:
                parsed = urlparse(url)
                upload_id = parse_qs(parsed.query)["uploadId"][0]
                e_tags.append(upload_response.headers["ETag"].strip('"'))
            upload_response.close()

        if is_s3_upload and e_tags and upload_id:
            return {"e_tags": e_tags, "upload_id": upload_id}
        else:
            return {}


    def shutdown(self):
        """Release any outstanding resources"""
        self.api_client.shutdown()

