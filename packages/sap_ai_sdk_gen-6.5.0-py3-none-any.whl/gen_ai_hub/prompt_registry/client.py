from typing import Optional

from gen_ai_hub import GenAIHubProxyClient
from gen_ai_hub.proxy import get_proxy_client
from gen_ai_hub.proxy.gen_ai_hub_proxy.client import GenAIHubRestClient
from .models.prompt_template import (
    PromptTemplatePostRequest,
    PromptTemplatePostResponse,
    PromptTemplateGetResponse,
    PromptTemplateListResponse,
    PromptTemplateDeleteResponse,
    PromptTemplateSubstitutionRequest,
    PromptTemplateSubstitutionResponse,
    PromptTemplateSpec,
)

# Constants
PATH_SCENARIOS = "/lm/scenarios"
PATH_PROMPT_TEMPLATES = "/lm/promptTemplates"
CONTENT_TYPE_JSON_ = "application/json"


class PromptTemplateClient:
    """
    Client for interacting with the Prompt Registry API.

    https://api.sap.com/api/PROMPT_REGISTRY_API/overview
    """
    def __init__(self, proxy_client: Optional[GenAIHubProxyClient] = None):
        """Initializes the PromptTemplateClient.

        :param proxy_client: Optional proxy client to use for requests.
        :type proxy_client: Optional[GenAIHubProxyClient], optional
        """
        self.proxy_client = proxy_client or get_proxy_client(proxy_version="gen-ai-hub")
        self.rest_client = GenAIHubRestClient(self.proxy_client)

    def create_prompt_template(self, name: str, version: str, scenario: str,
                               prompt_template_spec: PromptTemplateSpec ) -> PromptTemplatePostResponse:
        """Create or update a prompt template.

        :param name: the name of the prompt template.
        :type name: str
        :param version: the version of the prompt template.
        :type version: str
        :param scenario: the scenario name of the prompt template.
        :type scenario: str
        :param prompt_template_spec: the specification of the prompt template.
        :type prompt_template_spec: PromptTemplateSpec
        :return: A PromptTemplatePostResponse object.
        :rtype: PromptTemplatePostResponse
        """
        request = PromptTemplatePostRequest(scenario=scenario, name=name, version=version, spec=prompt_template_spec)
        response = self.rest_client.post(path=PATH_PROMPT_TEMPLATES, body=request.model_dump())

        return PromptTemplatePostResponse(**response)

    def get_prompt_templates(self, scenario: str, name: str, version: str, retrieve: str = None,
                             include_spec: bool = None) -> PromptTemplateListResponse:
        """Retrieve the latest version of every prompt template based on the filters.

        :param scenario: the scenario name of the prompt template.
        :type scenario: str
        :param name: the name of the prompt template.
        :type name: str
        :param version: the version of the prompt template.
        :type version: str
        :param retrieve: both(default), imperative, declarative
        :type retrieve: str, optional
        :param include_spec: false(default), true
        :type include_spec: bool, optional
        :return: A PromptTemplateListResponse object.
        :rtype: PromptTemplateListResponse
        """
        query_params = {
            "scenario": scenario,
            "name": name,
            "version": version,
            "retrieve": retrieve,
            "include_spec": include_spec
        }

        response = self.rest_client.get(path=PATH_PROMPT_TEMPLATES, params=query_params)

        return PromptTemplateListResponse(**response)

    def get_prompt_template_by_id(self, template_id: str) -> PromptTemplateGetResponse:
        """Retrieve a specific version of the prompt template by ID.

        :param template_id: The ID of the prompt template to retrieve.
        :type template_id: str
        :return: A PromptTemplateGetResponse object.
        :rtype: PromptTemplateGetResponse
        """

        response = self.rest_client.get(path=f"{PATH_PROMPT_TEMPLATES}/{template_id}")

        return PromptTemplateGetResponse(**response)

    def get_prompt_template_history(self, scenario: str, name: str, version: str) -> PromptTemplateListResponse:
        """Retrieve the history of edits to the prompt template. Only for imperative managed prompt templates.

        :param scenario: The scenario name of the prompt template.
        :type scenario: str
        :param name: The name of the prompt template.
        :type name: str
        :param version: The version ID of the prompt template.
        :type version: str
        :return: A PromptTemplateListResponse object.
        :rtype: PromptTemplateListResponse
        """

        response = self.rest_client.get(f"{PATH_SCENARIOS}/{scenario}/promptTemplates/{name}/versions/{version}/history")

        return PromptTemplateListResponse(**response)

    def delete_prompt_template_by_id(self, template_id: str) -> PromptTemplateDeleteResponse:
        """Delete a specific version of the prompt template by ID.

        :param template_id: The ID of the prompt template to delete.
        :type template_id: str
        :return: A PromptTemplateDeleteResponse object.
        :rtype: PromptTemplateDeleteResponse
        """

        response = self.rest_client.delete(f"{PATH_PROMPT_TEMPLATES}/{template_id}")

        return PromptTemplateDeleteResponse(**response)

    def import_prompt_template(self, file: bytes) -> PromptTemplatePostResponse:
        """Import a runtime/declarative prompt template into the design time environment.

        :param file: binary file content
        :type file: bytes
        :return: A PromptTemplatePostResponse object.
        :rtype: PromptTemplatePostResponse
        """

        # Content-Type: multipart/form-data is added automatically by requests when a file is passed in the request.
        kwargs = {"files": {"file": file}}
        response = self.rest_client.post(path=f"{PATH_PROMPT_TEMPLATES}/import", **kwargs)
        return PromptTemplatePostResponse(**response)

    def export_prompt_template(self, template_id: str) -> bytes:
        """Export a design time template in a declarative compatible yaml file. Supports only single file export.

        :param template_id: The id of the prompt template to export.
        :type template_id: str
        :return: bytes: The content of the exported file
        :rtype: bytes
        """

        response = self.rest_client.get(path=f"{PATH_PROMPT_TEMPLATES}/{template_id}/export", return_bytes_content=True)

        return response

    def fill_prompt_template(self, scenario: str, name: str, version: str, input_params: dict,
                             metadata: bool = False) -> PromptTemplateSubstitutionResponse:
        """Replace the placeholders of the prompt template referenced via scenario-name-version 
        with user provided values.

        :param scenario: the scenario name of the prompt template.
        :type scenario: str
        :param name: the name of the prompt template.
        :type name: str
        :param version: the version of the prompt template.
        :type version: str
        :param input_params: User provided values to replace the placeholders of the prompt template.
        :type input_params: dict
        :param metadata: False(default), True return resource object with all details.
        :type metadata: bool, optional
        :return: A PromptTemplateSubstitutionResponse object.
        :rtype: PromptTemplateSubstitutionResponse
        """

        request =PromptTemplateSubstitutionRequest(input_params=input_params)
        kwargs = {'convert_body_to_camel_case': False}
        if metadata:
            kwargs.update({'params': {"metadata": metadata}})
        response = self.rest_client.post(path=(f"{PATH_SCENARIOS}/{scenario}/promptTemplates/{name}/versions/"
                                               f"{version}/substitution"),
                                         headers={"Content-Type": CONTENT_TYPE_JSON_},
                                         body=request.model_dump(by_alias=True),
                                         **kwargs)

        return PromptTemplateSubstitutionResponse(**response)

    def fill_prompt_template_by_id(self,
                                   template_id: str,
                                   input_params: dict,
                                   metadata: bool = False, ) -> PromptTemplateSubstitutionResponse:
        """Replace the placeholders of the prompt template referenced via template_id with user provided values.

        :param template_id: The ID of the prompt template.
        :type template_id: str
        :param input_params: User provided values to replace the placeholders of the prompt template.
        :type input_params: dict
        :param metadata: False(default), True return resource object with all details.
        :type metadata: bool, optional
        :return: A PromptTemplateSubstitutionResponse object.
        :rtype: PromptTemplateSubstitutionResponse
        """

        request =PromptTemplateSubstitutionRequest(input_params=input_params)
        kwargs = {'params': {"metadata": metadata}, 'convert_body_to_camel_case': False}
        response = self.rest_client.post(path=f"{PATH_PROMPT_TEMPLATES}/{template_id}/substitution",
                                         headers={"Content-Type": CONTENT_TYPE_JSON_},
                                         body=request.model_dump(by_alias=True),
                                         **kwargs)

        return PromptTemplateSubstitutionResponse(**response)
