from typing import Optional

# pylint unable to detect the objects imported from lingua-py lib
# pylint:disable-next=no-name-in-module
from lingua import IsoCode639_1


class LanguageMapper:
    """
    This class provides method to convert supported iso_code_639_1 string to iso_code_639_1 object.
    Also handling extended conversion of iso_code_639_1 with region for zh_CN and zh_TW.
    """

    @classmethod
    def get_iso_code_639_1(cls, code: str) -> Optional[IsoCode639_1]:
        if code is None:
            return None
        code = code.lower()
        for name, value in IsoCode639_1.__dict__.items():
            # exclude Bosnian and Malay due to low accuracy
            if value == IsoCode639_1.BS or value == IsoCode639_1.MS:
                continue
            if not name.startswith("_") and not callable(value):
                # handles additional zh_TW and zh_CN, map to Chinese first
                if code.startswith(name.lower()):
                    return value
        return None
