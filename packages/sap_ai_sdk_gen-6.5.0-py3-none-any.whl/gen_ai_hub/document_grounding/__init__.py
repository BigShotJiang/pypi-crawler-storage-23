"""Document Grounding package for SAP Generative AI Hub.

This package provides APIs for document grounding capabilities including:
- Pipeline management for document vectorization from various data sources
- Vector store operations for semantic search
- Retrieval operations for querying document repositories

The package includes three main API clients:
- PipelineAPIClient: Manages document vectorization pipelines
- VectorAPIClient: Manages vector collections and semantic search
- RetrievalAPIClient: Performs retrieval operations across data repositories
"""
