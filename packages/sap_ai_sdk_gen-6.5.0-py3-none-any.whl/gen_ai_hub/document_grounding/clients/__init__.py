"""Clients subpackage for Document Grounding API.

This subpackage contains the API client implementations for interacting with
the SAP Generative AI Hub Document Grounding services.

Available clients:
    - PipelineAPIClient: Manages document vectorization pipelines from various data sources
    - RetrievalAPIClient: Performs retrieval operations across configured data repositories
    - VectorAPIClient: Manages vector collections and performs semantic searches
"""
