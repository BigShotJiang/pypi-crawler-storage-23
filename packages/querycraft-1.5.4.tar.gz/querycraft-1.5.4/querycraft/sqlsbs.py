#!/usr/bin/env python3

import argparse
import importlib.resources
import json
import os
import sys
from configparser import ConfigParser

import colorama

from querycraft.Database import DBSQLite, DBPGSQL, DBMySQL
from querycraft.LLM import manage_ia, show_ia
from querycraft.LRS import LRS
from querycraft.SQL import SQL, colorize_sql
from querycraft.SQLException import SQLQueryException
from querycraft.__init__ import __version__
from querycraft.logger import setup_logger, get_logger
from querycraft.tools import (readConfigFile, clear_line,colorize_sql,colorize_sql_html,
                              existFile, deleteFile, saveExos, loadExos,Spinner,wait_for_user,
                              cadre, getQuestion, format_table_1, format_table_2, format_table_3)


##########################################################################################################
##########################################################################################################
##########################################################################################################

def getCfgLog(verbose=True, debug=False):
    cfg = readConfigFile()
    level = 'INFO'
    try:
        username = getpass.getuser()
    except Exception:
        username = "unknown"
    with (importlib.resources.path("querycraft.logs",
                                   f"querycraft-{__version__}-{username}.log")
          as log_file):
        logger = setup_logger(
            name=f"querycraft",
            level=level,
            log_file=log_file,
            verbose=verbose,
            console=debug == True or cfg.getboolean('Autre', 'debug')
        )
    return cfg, logger


##########################################################################################################
##########################################################################################################
##########################################################################################################

def sbs(sql, cfg, sol=None, verbose=False, output='txt'):
    log = get_logger(f"sbs")
    log.info(f"Requête à traiter : {sql}")

    if output == 'html':
        print("<!DOCTYPE html><html lang=\"fr\" xmlns=\"http://www.w3.org/1999/xhtml\">")
        print("<head>\n<meta charset=\"UTF-8\"><title>QueryCraft</title>\n</head>\n<body>\n")

    print(cadre(f"QueryCraft@Nantes-Université — v. {__version__}", '*', output=output,
                couleur=colorama.Style.BRIGHT))

    if verbose:
        print(cadre("Contexte", '=', output, couleur=colorama.Style.BRIGHT))

        print(cadre("Schéma de la base", '-', output))
        sql.printDBTables(output)

        print(cadre("Requête à exécuter", '-', output))
        req = f"{colorize_sql(str(sql))}"
        if output == 'txt':
            print(f"{colorize_sql(str(sql))}\n")
        elif output == 'html':
            #print(f"<p><pre><code>{req}</code></pre></p>\n")
            print(
                f"<div style='background:#f5f5f5;padding:15px;border-radius:5px;border-left:4px solid #667eea;font-family:monospace;'>{colorize_sql_html(str(sql))}</div>"
                )
        elif output == 'md':
            print(f"```sql\n{colorize_sql(str(sql))}\n```\n\n")
        else:
            pass

        print(cadre("Table à obtenir", '-', output))
        (hd, rows) = sql.getTable()
        print(f"{format_table_2(hd, rows, output=output)}\n")

        if cfg['IA']['mode'] == 'on':
            with Spinner("Construction de l'explication avec l'IA générative") :
                rep = manage_ia('explain', cfg, verbose, f"{sql}", sql.getDB(), None, sql, None, None)
            clear_line()
            show_ia(rep, "Explication de la requête", output)
        print(cadre("Pas à pas", '=', output, couleur=colorama.Style.BRIGHT))

        if sql.step_by_step:
            #input("Appuyez sur Entrée pour voir le pas à pas ou Ctrl + Z pour quitter.")
            if not wait_for_user("Appuyez sur Entrée pour voir le pas à pas"):
                print(f"\n{colorama.Fore.YELLOW}Exécution interrompue.{colorama.Style.RESET_ALL}")
                return  # Sortie propre
            clear_line()

    (nb, l) = sql.sbs()

    # Affichage des étapes
    for i, s in l:
        print()
        if (i < nb - 1):
            print(cadre(f"Étape N°{i + 1}/{nb}", '—', output))
        else:
            print(cadre(f"Étape N°{i + 1}/{nb} (Résultat)", '—', output))

        # Affichage des étapes intermédiaires :
        #  - textes : id = 0
        #  - tables : id in [1,3]
        #  - SQL : id = 10
        for j in s:
            (id, t) = j
            if id == 0:
                if t:  # Nombre de lignes de la table
                    if output == "md":
                        print(f"\n{t}")
                    elif output == "html":
                        print(f"<p>{t}</p>")
                    else:
                        print(f"{t}")
                else:
                    print(f"{colorama.Fore.MAGENTA}                ⬇︎ {colorama.Style.RESET_ALL}")
            elif id == 10:  # Texte formater de la requête SQL
                if output == "txt":
                    print(f"{colorize_sql(t)}")
                elif output == "html":
                    print(f"<div style='background:#f5f5f5;padding:15px;border-radius:5px;border-left:4px solid #667eea;font-family:monospace;'>{colorize_sql_html(t)}</div>"
                          )
                elif output == "md":
                    print(f"```sql\n{t}\n```\n")
                else:
                    pass
            else:  # table(s)
                (col, row, dif) = t
                if id == 1:
                    print(f"{format_table_1(col, row, dif, output=output)}")
                elif id == 2:
                    print(f"{format_table_2(col, row, dif, output=output)}")
                elif id == 3:
                    print(f"{format_table_3(col, row, dif, output=output, inter=True)}")
                else:
                    pass
        if sql.step_by_step and i < nb - 1:
            #input("Appuyez sur Entrée pour continuer ou Ctrl + Z pour quitter.")
            if not wait_for_user("Appuyez sur Entrée pour voir le pas à pas"):
                print(f"\n{colorama.Fore.YELLOW}Exécution interrompue.{colorama.Style.RESET_ALL}")
                return  # Sortie propre
            else :
                clear_line()


    if sol is not None :
        # Comparaison des résultats
        print(cadre("Correction", '=', output, couleur=colorama.Style.BRIGHT))
        print(sql.buildStdCorrection(cfg['Autre']['aide'] == 'on', sol, output))

        if verbose:
            # Analyse des requêtes
            if cfg['IA']['mode'] == 'on' :
                with Spinner("Construction de la correction avec l'IA générative") :
                    (exo, quest, intention, com, inst) = sol.getExo()
                    rep = manage_ia('solution', cfg, verbose, f"{sql} ; {sol}", sql.getDB(),
                                    None, sql, sol, intention)
                clear_line()
                show_ia(rep, "Correction de la requête", output)

    if output == 'html':
        print('</body></html>')
    log.info(f"fin : {sql}")




def getQuery(args):
    if args.file and existFile(args.file):
        sqlTXT = ''
        with open(args.file, 'r') as f:
            sqlTXT += f.read()
    elif args.sql:
        sqlTXT = args.sql
    else:
        sqlTXT = ''
    return sqlTXT


##########################################################################################################
##########################################################################################################
##########################################################################################################

def stdArgs(parser, def_db):
    parser.add_argument("--version", action="store_true", help="Affiche la version du programme")

    if def_db:
        parser.add_argument('-d', '--db', help=f'database name (by default {def_db})', default=def_db)
    else:
        parser.add_argument('-d', '--db', help=f'database name', required=True)

    parser.add_argument('-v', '--verbose', help='verbose mode', action='store_true', default=False)
    parser.add_argument('-nsbs', '--step_by_step', help='step by step mode off', action='store_false', default=True)

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-b', '--describe', help='DB Schema', action='store_true', default=False)
    group.add_argument('-f', '--file', help='sql file')
    group.add_argument('-s', '--sql', type=str, help='sql string')

    parser.add_argument('-o', '--output', help='output (txt, html, md), default txt', default='txt')

    group = parser.add_argument_group(title='exercice')
    group.add_argument('-e', '--exercice', help="code de l'exercice", default=None)
    group.add_argument('-q', '--question', help="code de la question", default=None)
    parser.epilog = f"QueryCraft version {__version__} --- (c) E. Desmontils, Nantes Université, 2024, 2025, 2026"

    return parser


def ctrlStdArgs(parser, args):
    if (args.exercice is None) ^ (args.question is None):
        parser.error("Les options -e et -q doivent être fournies ensemble ou aucune des deux.")


def dbConnectArgs(parser, defaultPort, defaultHost='localhost', defaultUser='desmontils-e'):
    parser.add_argument('-u', '--user', help=f'database user (by default {defaultUser})',
                        default=defaultUser)  # 'desmontils-e')
    parser.add_argument('-p', '--password', help='database password', default=None)
    parser.add_argument('--host', help=f'database host (by default {defaultHost})', default=defaultHost)  # 'localhost')
    parser.add_argument('--port', help=f'database port (by default {defaultPort})', default=defaultPort)  # '5432')


def doSBS(db, dbtype, dbname, sqlTXT, debug, verbose, output='txt', step_by_step=False, exo=None, quest=None, lrs=None):
    # clear_terminal()
    log = get_logger("sbs")
    try:
        cfg = readConfigFile()
        SQLQueryException.setCfg(cfg)

        # LRS configuration
        if lrs:
            lrs.setContextSBS()
        sql = SQL(db=db, dbtype=dbtype, debug=debug, verbose=verbose,
                  step_by_step=step_by_step, output=output)
        sql.setSQL(sqlTXT, True)
        if lrs: lrs.sendSBSExecute(dbtype, dbname, sqlTXT)

        # Lancement du programme
        try:
            if exo is not None and quest is not None:
                q = getQuestion(exo, quest)
                if q is not None:
                    (requete, intention, com, type, inst) = q
                    sol = SQL(db=db, dbtype=dbtype, debug=debug, verbose=verbose, step_by_step=step_by_step,
                              output=output)
                    sol.setSQL(requete, True)
                    sol.setExo(intention, exo, quest, com, type, inst)
                else:
                    sol = None
            else:
                sol = None

            sbs(sql, cfg, sol, verbose, output)  # Pas à pas

            if lrs: lrs.sendSBSpap(dbtype, dbname, sqlTXT)
        except Exception as e:
            # LRS : envoie du statement
            if lrs: lrs.sendSBSpap(dbtype, dbname, sqlTXT, error=e)
            log.error(f'Erreur SBS 2 : {e}', exc_info=True)
    except SQLQueryException as e:
        print(e)
        # LRS : envoie du statement
        if lrs: lrs.sendSBSExecute(dbtype, dbname, sqlTXT, error=e)
        exit(0)
    except Exception as e:
        log.error(f'Erreur SBS 1 : {e}', exc_info=True)
        # LRS : envoie du statement
        if lrs: lrs.sendSBSExecute(dbtype, dbname, sqlTXT, error=e)
        exit(1)

##########################################################################################################
##########################################################################################################
##########################################################################################################

def doDescribe(cfg, sgbd, output='txt'):
    print(sgbd.describe(cfg, output))
    exit(0)


##########################################################################################################
##########################################################################################################
##########################################################################################################

def mysql():
    cfg, log = getCfgLog()
    parser = argparse.ArgumentParser(
        description="Effectue l'exécution pas à pas d'une requête sur MySQL")
    if cfg['Database']['type'] == "mysql":
        port = cfg['Database']['port']
        host = cfg['Database']['host']
        user = cfg['Database']['username']
        password = cfg['Database']['password']
        db = cfg['Database']['database']
        dbConnectArgs(parser, defaultPort=port, defaultHost=host, defaultUser=user)
    else:
        port = 3306
        host = 'localhost'
        user = 'desmontils-e'
        password = ''
        db = None
        dbConnectArgs(parser, defaultPort=port, defaultHost=host, defaultUser=user)

    stdArgs(parser, db)
    args = parser.parse_args()
    ctrlStdArgs(parser, args)

    port = args.port
    host = args.host
    user = args.user
    db = args.db

    if (args.password is None) and (args.port == cfg['Database']['port']) and (
            args.host == cfg['Database']['host']) and (args.user == cfg['Database']['username']) and (
            args.db == cfg['Database']['database']):
        password = cfg['Database']['password']
    else:
        if args.password is None:
            password = ''
        else:
            password = args.password

    debug = cfg.getboolean('Autre', 'debug', fallback=False)
    verbose = cfg.getboolean('Autre', 'verbose') or args.verbose

    # if debug:
    #    print('Infos BD : ', type, args.user, args.password, args.host, args.port, args.db)
    if args.describe:
        # Affichage des tables de la BD
        try:
            doDescribe(cfg,
                       DBMySQL(db=(user, password, host, db), debug=False, verbose=verbose), verbose,
                       output=args.output)
        except Exception as e:
            print(f'Erreur Describe MySQL : {e}')
            exit(1)

    # xAPI configuration
    onLRS = cfg['LRS']['mode'] == 'on'
    if onLRS:
        lrs = LRS(cfg['LRS']['endpoint'], cfg['LRS']['username'], cfg['LRS']['password'], debug=debug)
    else:
        lrs = None

    sqlTXT = getQuery(args)
    if (args.exercice is not None) and (args.question is not None):
        exo = args.exercice
        quest = args.question
    else:
        exo = None
        quest = None

    if onLRS:
        doSBS((user, password, host, db), 'mysql', db, sqlTXT,
              debug, verbose, args.step_by_step,
              exo, quest, lrs)
    else:
        doSBS((user, password, host, db), 'mysql', db, sqlTXT,
              debug, verbose, args.output, args.step_by_step,
              exo, quest)


##########################################################################################################
##########################################################################################################
##########################################################################################################
def pgsql():
    cfg, log = getCfgLog()
    parser = argparse.ArgumentParser(
        description="Effectue l'exécution pas à pas d'une requête sur PostgreSQL")
    if cfg['Database']['type'] == "pgsql":
        port = cfg['Database']['port']
        host = cfg['Database']['host']
        user = cfg['Database']['username']
        password = cfg['Database']['password']
        db = cfg['Database']['database']
        dbConnectArgs(parser, defaultPort=port, defaultHost=host, defaultUser=user)
    else:
        port = 5432
        host = 'localhost'
        user = 'desmontils-e'
        db = None
        dbConnectArgs(parser, defaultPort=port, defaultHost=host, defaultUser=user)

    stdArgs(parser, db)
    args = parser.parse_args()
    ctrlStdArgs(parser, args)

    port = args.port
    host = args.host
    user = args.user
    db = args.db

    if (args.password is None) and (args.port == cfg['Database']['port']) and (
            args.host == cfg['Database']['host']) and (args.user == cfg['Database']['username']) and (
            args.db == cfg['Database']['database']):
        password = cfg['Database']['password']
    else:
        if args.password is None:
            password = ''
        else:
            password = args.password

    debug = cfg.getboolean('Autre', 'debug', fallback=False)
    verbose = cfg.getboolean('Autre', 'verbose') or args.verbose

    if args.describe:
        # Affichage des tables de la BD
        try:
            doDescribe(cfg,
                       DBPGSQL(db=f"dbname={db} user={user} password={password} host={host} port={port}", debug=debug,
                               verbose=verbose), output=args.output)
        except Exception as e:
            print(f'Erreur Describe PostgreSQL : {e}')
            exit(1)

    # xAPI configuration
    onLRS = cfg['LRS']['mode'] == 'on'
    if onLRS:
        lrs = LRS(cfg['LRS']['endpoint'], cfg['LRS']['username'], cfg['LRS']['password'], debug=debug)
    else:
        lrs = None

    sqlTXT = getQuery(args)
    if (args.exercice is not None) and (args.question is not None):
        exo = args.exercice
        quest = args.question
    else:
        exo = None
        quest = None

    if onLRS:
        doSBS(f"dbname={db} user={user} password={password} host={host} port={port}", 'pgsql',
              db, sqlTXT, debug, verbose, args.output,
              args.step_by_step, exo, quest, lrs)
    else:
        doSBS(f"dbname={db} user={user} password={password} host={host} port={port}", 'pgsql',
              db, sqlTXT, debug, verbose, args.output,
              args.step_by_step, exo, quest)


##########################################################################################################
##########################################################################################################
##########################################################################################################
def sqlite():
    cfg, log = getCfgLog()
    parser = argparse.ArgumentParser(
        description="Effectue l'exécution pas à pas d'une requête sur SQLite")

    if cfg['Database']['type'] == "sqlite":
        db = cfg['Database']['database']
    else:
        db = None

    parser = stdArgs(parser, db)
    args = parser.parse_args()
    ctrlStdArgs(parser, args)

    debug = cfg.getboolean('Autre', 'debug', fallback=False)
    verbose = cfg.getboolean('Autre', 'verbose') or args.verbose

    db = args.db

    if not (existFile(db)):
        log.error(f'database file not found : {db}')
        package_files = importlib.resources.files("querycraft.data")
        log.info(f'trying to search in default databases')
        if not (existFile(package_files / db)):
            log.error(f' default database file not found')
            exit(1)
        else:
            db = package_files / db
            log.info('database exists')
    else:
        log.info('database exists')
    # if args.debug:
    #    print('Infos BD : ', type, args.user, args.password, args.host, args.port, args.db)
    if args.describe:
        # Affichage des tables de la BD
        try:
            doDescribe(cfg, DBSQLite(db=str(db), debug=debug, verbose=verbose), output=args.output)
        except Exception as e:
            print(f'Erreur Describe SQLite : {e}')
            exit(1)

    # xAPI configuration
    onLRS = cfg['LRS']['mode'] == 'on'
    if onLRS:
        lrs = LRS(cfg['LRS']['endpoint'], cfg['LRS']['username'], cfg['LRS']['password'], debug=debug)
    else:
        lrs = None

    sqlTXT = getQuery(args)
    if (args.exercice is not None) and (args.question is not None):
        exo = args.exercice
        quest = args.question
    else:
        exo = None
        quest = None
    if onLRS:
        doSBS(db, 'sqlite', db, sqlTXT,
              debug, verbose, args.output, args.step_by_step,
              exo, quest, lrs)
    else:
        doSBS(db, 'sqlite', db, sqlTXT,
              debug, verbose, args.output, args.step_by_step,
              exo, quest)


##########################################################################################################
##########################################################################################################
##########################################################################################################
def parse_assignment(assignment: str):
    """
    Transforme une chaîne 'Section.clef=valeur' en ses composantes.
    """
    try:
        section_key, value = assignment.split("=", 1)
        section, key = section_key.split(".", 1)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            f"Format invalide pour --set '{assignment}'. "
            "Utiliser Section.clef=valeur."
        ) from exc
    return section.strip(), key.strip(), value.strip()


def afficher_config(config: ConfigParser) -> None:
    if not config.sections():
        print("❌ Le fichier ne contient aucune section.")
        return

    largeur_section = max(len(section) for section in config.sections())
    largeur_cle = max(
        len(key)
        for section in config.sections()
        for key in config[section].keys()
    )
    # print(largeur_cle)
    for section in config.sections():
        print(f"\n{colorama.Fore.GREEN}{colorama.Style.BRIGHT}[{section}]{colorama.Style.RESET_ALL}")
        tab = []
        for key, value in config[section].items():
            tab.append([key, value])
        print(
            format_table_2(headers=['Clé', 'Valeur'], rows=tab, table_size=50, min_col_width=largeur_cle, output='txt'))
        if section == "IA":
            print(f"Services reconnus : ollama, ollama_cloud, lms, poe, openai, google et generic")


def admin() -> None:
    parser = argparse.ArgumentParser(
        description="Met à jour des paramètres du fichier de configuration."
    )
    parser.add_argument(
        "--set",
        nargs="+",
        required=False,
        help="Assignments au format Section.clef=valeur."
    )

    parser.epilog = f"QueryCraft version {__version__} --- (c) E. Desmontils, Nantes Université, 2025, 2026"

    args = parser.parse_args()
    config, log = getCfgLog()
    log = get_logger("admin")

    if args.set:
        for assignment in args.set:
            section, key, value = parse_assignment(assignment)
            if section not in config:
                log.error(f"❌ Erreur : section '{section}' absente.")
                sys.exit(1)
            if key not in config[section]:
                log.error(f"❌ Erreur : clef '{key}' absente dans la section '{section}'.")
                sys.exit(1)
            config[section][key] = value

        with importlib.resources.path("querycraft.config", "config-sbs.cfg") as config_path:
            with config_path.open("w", encoding="utf-8") as config_file:
                config.write(config_file)
        print(f"✅ Fichier de configuration mis à jour avec succès.")
    else:
        log.info("Aucune assignation à traiter. Affichage de la configuration actuelle.")
        afficher_config(config)


##########################################################################################################
##########################################################################################################
##########################################################################################################


def build_parser_exos() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Gestion d'exercices et questions."
    )
    sub = p.add_subparsers(dest="command", required=True)

    c1 = sub.add_parser("create-ex", help="Créer un exercice")
    c1.add_argument("code", help="Code de l'exercice")

    c2 = sub.add_parser("delete-ex", help="Supprimer un exercice")
    c2.add_argument("code", help="Code de l'exercice")

    c3a = sub.add_parser("add-q", help="Ajouter une question à un exercice")
    c3a.add_argument("code", help="Code de l'exercice")
    c3a.add_argument("numero", help="Numéro de la question")
    c3a.add_argument("requete", help="Requête SQL")
    c3a.add_argument("-i", "--intention", help="Intention de la requête", default="")
    c3a.add_argument("-e", "--explication", help="Explication/aide de la requête", default="")
    c3a.add_argument("-t", "--type", help="Type", choices=["I->R", "R->I"], default="I->R")
    c3a.add_argument("-r", "--instruction", help="Instruction selon le type de la requête", default="")

    c3b = sub.add_parser("add-q2",
                         help="Ajouter un groupe de questions à un exercice. Si un numéro de question existe déjà, le processus est stoppé et l'exercice reste inchangé.")
    c3b.add_argument("code", help="Code de l'exercice")
    c3b.add_argument("file", help="Fichier JSON contenant les questions")

    c4 = sub.add_parser("delete-q", help="Supprimer une question")
    c4.add_argument("code", help="Code de l'exercice")
    c4.add_argument("numero", help="Numéro de la question")

    c5 = sub.add_parser("show-ex", help="Afficher un exercice")
    c5.add_argument("code", help="Code de l'exercice")

    p.epilog = f"QueryCraft version {__version__} --- (c) E. Desmontils, Nantes Université, 2026"

    return p


def create_exercice(code):
    exo = dict()
    with importlib.resources.path("querycraft.exos", f"{code}.json") as file:
        if existFile(file):
            print(f"L'exercice {code} existe déjà.")
            return False
        else:
            saveExos(code, exo)
            return True


def delete_exercice(code):
    with importlib.resources.path("querycraft.exos", f"{code}.json") as file:
        if existFile(file):
            deleteFile(file)
            print(f"L'exercice {code} a été supprimé.")
            return True
        else:
            print(f"L'exercice {code} n'existe pas.")
            return False


def add_question(codeex, numero, requete, intention, type):
    exo = loadExos(codeex)
    if numero in exo:
        print(f"La question {numero} existe déjà.")
        return False
    else:
        exo[numero] = [requete, intention, type]
        saveExos(codeex, exo)
        return True


def add_question_list(codex, file):
    '''
    À partir d'un fichier JSON, ajoute des questions à un exercice.
    Le fichier JSON doit être de la forme :
    {"no_question": ["requete", "intention", "commentaire", "type", "instruction"], ...}
    '''
    exo = loadExos(codex)
    with open(file, 'r') as f:
        questions = json.load(f)
        for q, infos in questions.items():
            if q in exo:
                print(f"La question {q} existe déjà.")
                return False
        for q, (requete, intention, comment, type, instuction) in questions.items():
            exo[q] = [requete, intention, comment, type, instuction]
        saveExos(codex, exo)
        return True


def delete_question(codeex, numero):
    exo = loadExos(codeex)
    if numero not in exo:
        print(f"La question {numero} n'existe pas.")
        return False
    else:
        del exo[numero]
        saveExos(codeex, exo)
        return True


def show_exercice(codeex):
    exo = loadExos(codeex)
    if exo:
        for q, (requete, intention, comment, type, instuctions) in exo.items():
            print(f"- Question {q}")
            print(f"  Requête SQL : {requete}")
            print(f"  Intention   : {intention}")
            print(f"  Commentaire : {comment}")
            print(f"  Type        : {type}")
            print(f"  Instructions : {instuctions}")
        return True
    else:
        print("Aucune question dans cet exercice.")
        return False


def exos() -> None:
    parser = build_parser_exos()
    args = parser.parse_args()
    ok = False
    cfg, log = getCfgLog()
    log = get_logger("exos")
    log.info(f"Commande : {args.command}")
    try:
        if args.command == "create-ex":
            ok = create_exercice(args.code)
        elif args.command == "delete-ex":
            ok = delete_exercice(args.code)
        elif args.command == "add-q":
            ok = add_question(args.code, args.numero, args.requete, args.intention, args.type)
        elif args.command == "add-q2":
            ok = add_question_list(args.code, args.file)  # args.type)
        elif args.command == "delete-q":
            ok = delete_question(args.code, args.numero)
        elif args.command == "show-ex":
            ok = show_exercice(args.code)
        else:
            log.error("❌ Commande inconnue.")
            parser.error("Commande inconnue.")
        if ok:
            print("✅ Opération réussie.")
            log.info("✅ Opération réussie.")
        else:
            print(f"❌ Échec de l'opération")
            log.info(f"❌ Échec de l'opération")
    except Exception as e:
        print(f"❌ Erreur: {e}")
        log.error(f"❌ Erreur: {e}", exc_info=True)
        sys.exit(1)


##########################################################################################################
##########################################################################################################
##########################################################################################################
def main():
    parser = argparse.ArgumentParser()
    # parser.add_argument('--lrs', help='use en Veracity lrs', action='store_true', default=False)
    parser.add_argument('-v', '--verbose', help='verbose mode', action='store_true', default=False)
    parser.add_argument('--debug', help='debug mode', action='store_true', default=False)
    parser.add_argument('-d', '--db', help='database file (sqlite) or name (others)', default=None)
    parser.add_argument('-nsbs', '--step_by_step', help='step by step mode', action='store_false', default=False)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-f', '--file', help='sql file')
    group.add_argument('-s', '--sql', type=str, help='sql string', default="")
    group.add_argument('-b', '--describe', help='DB Schema', action='store_true', default=False)

    args = parser.parse_args()
    sqlTXT = getQuery(args)

    # ==================================================
    # === Gestion de la configuration =================
    # ==================================================

    # Debug ?
    cfg, log = getCfgLog(False, args.debug)
    debug = cfg.getboolean('Autre', 'debug') or args.debug
    verbose = cfg.getboolean('Autre', 'verbose') or args.verbose
    if debug:
        log.info("Mode debug activé")
    package_files = importlib.resources.files("querycraft.data")
    # Database configuration
    if args.db:
        if args.db.endswith('.db'):
            if not (existFile(args.db)):
                log.error(f'database file not found : {args.db} — trying to search in default databases')
                if not (existFile(package_files / args.db)):
                    log.error(f'default database file not found')
                    exit(1)
                else:
                    args.db = package_files / args.db
                    log.info('database exists')
            else:
                log.info('database exists')
            database = args.db
            log.info(f"SQLite database from parameter : {database}")
            type = 'sqlite'
            username = None
            password = None
            host = None
            port = None
        else:
            database = args.db
            log.info(f"PGSQL database from parameter : {database}")
            type = 'pgsql'  # Database configuration
            username = 'postgres'
            password = ''
            host = 'localhost'
            port = '5432'
    else:
        type = cfg['Database']['type']
        if type == 'sqlite':
            log.info(f"SQLite database from config file : {cfg['Database']['database']}")
            database = package_files / cfg['Database'][
                'database']  # importlib.resources.resource_filename("querycraft.data", cfg['Database']['database'])
            username = None
            password = None
            host = None
            port = None
        else:
            log.info(f"{type} database from config file : {cfg['Database']['database']}")
            username = cfg['Database']['username']
            password = cfg['Database']['password']
            host = cfg['Database']['host']
            port = cfg['Database']['port']
            database = cfg['Database']['database']

    # xAPI configuration
    onLRS = cfg['LRS']['mode'] == 'on'
    if onLRS:
        lrs = LRS(cfg['LRS']['endpoint'], cfg['LRS']['username'], cfg['LRS']['password'], debug=debug)
        lrs.setContextSBS()

    if debug:
        log.debug('Infos BD : ', type, username, password, host, port, database)

    try:
        try:
            if type is None:
                raise Exception("Configuration non fournie")
            if type == 'sqlite':
                if args.describe:
                    # Affichage des tables de la BD
                    try:
                        db = DBSQLite(db=database, debug=False, verbose=args.verbose)
                        print(f"{type}\n{db.tables2string()}")
                        exit(0)
                    except Exception as e:
                        print(f"Erreur Describe SQLite : {e}")
                        exit(1)
                sql = SQL(db=database, dbtype='sqlite', debug=debug, verbose=verbose, step_by_step=args.step_by_step)
            elif type == 'pgsql':  # f"dbname={database} user={username} password={password} host={host} port={port}"
                if args.describe:
                    # Affichage des tables de la BD
                    try:
                        db = DBPGSQL(
                            db=f"dbname={database} user={username} password={password} host={host} port={port}",
                            debug=False, verbose=args.verbose)
                        print(f"{type}\n{db.tables2string()}")
                        exit(0)
                    except Exception as e:
                        print(f"Erreur Describe PostgreSQL : {e}")
                        exit(1)
                sql = SQL(f"dbname={database} user={username} password={password} host={host} port={port}",
                          dbtype='pgsql', debug=debug, verbose=verbose, step_by_step=args.step_by_step)
            elif type == 'mysql':  # (username, password, host ,database) # port ????
                if args.describe:
                    # Affichage des tables de la BD
                    try:
                        db = DBMySQL(db=(username, password, host, database), debug=False, verbose=args.verbose)
                        print(f"{type}\n{db.tables2string()}")
                        exit(0)
                    except Exception as e:
                        print(f"Erreur Describe MySQL : {e}")
                        exit(1)
                sql = SQL(db=(username, password, host, database), dbtype='mysql', debug=debug, verbose=verbose,
                          step_by_step=args.step_by_step)
            else:
                raise Exception("Base de données non supportée")

            sql.setSQL(sqlTXT)

            # LRS : envoie du statement
            if onLRS: lrs.sendSBSExecute(type, database, sqlTXT)

        except SQLQueryException as e:
            print(e)
            # LRS : envoie du statement
            if onLRS: lrs.sendSBSExecute(type, database, sqlTXT, error=e)
            exit(0)
        except Exception as e:
            log.error(f'Erreur SBS 1 : {e}', exc_info=True)
            # LRS : envoie du statement
            if onLRS: lrs.sendSBSExecute(type, database, sqlTXT, error=e)
            exit(1)

        sbs(sql, cfg, None, verbose)  # Pas à pas

        if onLRS: lrs.sendSBSpap(type, database, sqlTXT)

    except Exception as e:
        # LRS : envoie du statement
        if onLRS: lrs.sendSBSpap(type, database, sqlTXT, e)
        log.error(f'Erreur SBS 2 : {e}', exc_info=True)


if __name__ == '__main__':
    main()
