#!/usr/bin/env python3
"""
Application web Flask pour QueryCraft
Permet l'exécution pas à pas de requêtes SQL via une interface web

Fichier généré initialement avec l'aide de Claude Code / Claude Sonnet 4.5 - le 2026-02-12

(c) E. Desmontils, Nantes Université, 2026
"""

import importlib.resources
import getpass
import os
import platform
import json
import colorama
from flask import Flask, render_template, request, jsonify

from querycraft.Database import DBSQLite, DBPGSQL, DBMySQL
from querycraft.SQL import SQL
from querycraft.SQLException import SQLException, SQLQueryException
from querycraft.__init__ import __version__
from querycraft.logger import setup_logger, get_logger
from querycraft.tools import readConfigFile, existFile, format_table_1, format_table_3, cadre, \
    colorize_sql_html, markdown_to_html, loadExos, saveExos, existFile, getQuestion, format_table_2
from querycraft.LLM import format_ia,manage_ia

app = Flask(__name__)

# Configuration globale chargée au démarrage
config = readConfigFile()
level = 'INFO'
try:
    username = getpass.getuser()
except Exception:
    username = "unknown"
with (importlib.resources.path("querycraft.logs",
                               f"querycraft-{__version__}-{username}.log")
      as log_file):
    logger = setup_logger(
        name="querycraft",
        level=level,
        log_file=log_file,
        verbose=config.getboolean('Autre', 'verbose'),
        console=config.getboolean('Autre', 'debug')
    )

def get_system_info():
    """
    Récupère les informations système (machine, OS, version Python)

    Returns:
        dict: Dictionnaire contenant les informations système
    """
    return {
        'machine': platform.machine(),  # Architecture (x86_64, arm64, etc.)
        'system': platform.system(),    # Système d'exploitation (Darwin, Linux, Windows)
        'release': platform.release(),  # Version du système
        'python_version': platform.python_version(),  # Version Python
        'platform': platform.platform(),  # Plateforme complète
        'node': platform.node()  # Nom de la machine
    }

def get_database_from_config(debug=False, verbose=False, output='html'):
    """
    Récupère la connexion à la base de données depuis la configuration

    Args:
        debug: Mode debug
        verbose: Mode verbose
        output: Format de sortie ('txt', 'html', 'md')

    Returns:
        Instance de Database (DBSQLite, DBPGSQL ou DBMySQL)
    """
    db_type = config.get('Database', 'type')
    database = config.get('Database', 'database')
    log = get_logger('querycraft.web.get_database_from_config')
    if db_type == 'sqlite':
        # SQLite: db = chemin du fichier
        # db = DBSQLite(db=str(database), debug=debug, verbose=verbose, output=output)
        if not (existFile(database)):
            log.error(f'database file not found : {database}')
            package_files = importlib.resources.files("querycraft.data")
            log.info(f'trying to search in default databases')
            if not (existFile(package_files / database)):
                log.error(f' default database file not found')
                exit(1)
            else:
                database = package_files / database
                log.info('database exists')
        else:
            log.info('database exists')
        db = DBSQLite(db=str(database), debug=debug, verbose=verbose, output=output)
    elif db_type == 'pgsql':
        # PostgreSQL: db = chaîne de connexion
        username = config.get('Database', 'username')
        password = config.get('Database', 'password')
        host = config.get('Database', 'host', fallback='localhost')
        port = config.get('Database', 'port', fallback='5432')

        connection_string = f"dbname={database} user={username} password={password} host={host} port={port}"
        db = DBPGSQL(db=connection_string, debug=debug, verbose=verbose, output=output)

    elif db_type == 'mysql':
        # MySQL: db = tuple (user, password, host, database)
        username = config.get('Database', 'username')
        password = config.get('Database', 'password')
        host = config.get('Database', 'host', fallback='localhost')

        db = DBMySQL(db=(username, password, host, database), debug=debug, verbose=verbose, output=output)

    else:
        raise ValueError(f"Type de base de données non supporté : {db_type}")

    return db


def get_available_databases():
    """Liste les fichiers de bases de données SQLite disponibles dans querycraft/data/"""
    databases = []

    try:
        with importlib.resources.path("querycraft.data", "") as data_dir:
            if os.path.exists(data_dir):
                for filename in os.listdir(data_dir):
                    if filename.endswith('.db'):
                        databases.append(filename)
    except Exception as e:
        print(f"Erreur lors du chargement des bases de données : {e}")

    databases.sort()
    return databases


def execute_query_sbs(sql_query, step_by_step=True, verbose=False, code_ex=None, code_q=None):
    """
    Exécute une requête SQL en mode pas à pas

    Args:
        sql_query: Requête SQL à exécuter
        step_by_step: Mode pas à pas activé
        verbose: Mode verbose avec aide de l'IA
        code_ex: Code de l'exercice (optionnel)
        code_q: Code de la question (optionnel)

    Returns:
        dict: Résultat contenant 'success', 'output', 'error', 'html_output', 'comparison'
    """
    result = {
        'success': False,
        'output': '',
        'error': '',
        'html_output': '',
        'comparison': None
    }

    try:
        # Vérifier le mode debug et verbose depuis la config
        debug = config.getboolean('Autre', 'debug', fallback=False)

        # Récupérer la connexion à la base de données
        db = get_database_from_config(debug=debug, verbose=verbose, output='html')
        SQLQueryException.setCfg(config)

        # Créer l'objet SQL
        sql = SQL(db.db, db.dbtype, None, None, debug, verbose, step_by_step, output='html')
        sql.setSQL(sql_query, True)
        html_output = []

        #Récupération de la question
        if code_ex is not None and code_q is not None:
            q = getQuestion(code_ex, code_q)
            if q is not None:
                (requete, intention, com, type, inst) = q
                sol = SQL(db=db.db, dbtype=db.dbtype, debug=debug, verbose=verbose, step_by_step=step_by_step,
                          output='html')
                sol.setSQL(requete, True)
                sol.setExo(intention, code_ex, code_q, com, type, inst)
            else:
                sol = None
        else:
            sol = None

        html_output.append(
            f"<h3>Requête étudiée</h3><div class='info'>{colorize_sql_html(sql_query)} </div> ")

        if verbose and config['IA']['mode'] == 'on':
            rep = manage_ia('explain', config, verbose, f"{sql_query}", sql.getDB(), None, sql, None, None)
            rep_str = format_ia(rep, "Explication de la requête", 'html')
            html_output.append(rep_str)

        if step_by_step:
            # Exécution pas à pas : récupérer les étapes
            from querycraft.tools import format_table_2

            nb_steps, steps = sql.sbs()

            # Affichage des étapes
            for i, s in steps:
                if (i < nb_steps - 1):
                    html_output.append(
                        '<hr style="border: none; border-top: 1px solid #dee2e6; margin: 20px 0;">')
                    html_output.append(cadre(f"Étape N°{i + 1}/{nb_steps}", '—', 'html'))
                else:
                    html_output.append(
                        '<hr style="border: none; border-top: 1px solid #dee2e6; margin: 20px 0;">')
                    html_output.append(cadre(f"Étape N°{i + 1}/{nb_steps} (Résultat)", '—', 'html'))

                # Affichage des étapes intermédiaires :
                #  - textes : id = 0
                #  - tables : id in [1,3]
                #  - SQL : id = 10
                for j in s:
                    (id, t) = j
                    if id == 0:
                        if t:  # Nombre de lignes de la table
                            html_output.append(f"<p>{t}</p> <br> ")
                        else:
                            html_output.append(f"&nbsp;&nbsp;&nbsp;&nbsp;⬇︎ ")
                    elif id == 10:  # Texte formater de la requête SQL
                        # html_output.append(f"<p><pre><code>{t}</code></pre></p>")
                        html_output.append(
                            f"<div style='background:#e8f4f8;padding:15px;border-radius:5px;border-left:4px solid  # 17a2b8;font-family:monospace;'>{colorize_sql_html(t)} </div> ")
                    else:  # table(s)
                        (col, row, dif) = t
                        if id == 1:
                            html_output.append(f"{format_table_1(col, row, dif, output='html')}")
                        elif id == 2:
                            html_output.append(f"{format_table_2(col, row, dif, output='html')}")
                        elif id == 3:
                            html_output.append(f"{format_table_3(col, row, dif, output='html', inter=True)}")
                        else:
                            pass

        else:
            # Exécution directe
            from querycraft.tools import format_table_2

            headers, rows = sql.getTable()

            html_output.append(f"<h3>Résultat :</h3>")
            print(headers, rows)
            if rows:
                table_html = format_table_2(headers, rows, output='html')
                html_output.append(table_html)
                html_output.append(f"<p><strong>{len(rows)} ligne(s) retournée(s)</strong></p>")
            else:
                html_output.append("<p><em>Aucun résultat</em></p>")


        if sol is not None:
            # Comparaison des résultats
            html_output.append(cadre("Correction", '=', 'html', couleur=colorama.Style.BRIGHT))
            html_output.append(sql.buildStdCorrection(config['Autre']['aide'] == 'on', sol, output='html'))

            if verbose:
                html_output.append('<br/>')
                # Analyse des requêtes
                if config['IA']['mode'] == 'on':
                    (exo, quest, intention, com, inst) = sol.getExo()
                    rep = manage_ia('solution', config, verbose, f"{sql} ; {sol}", sql.getDB(), None, sql, sol,
                                    intention)
                    html_output.append(format_ia(rep, "Correction de la requête", 'html'))

        result['html_output'] = "\n".join(html_output)
        result['success'] = True
    except SQLQueryException as e:
        result['success'] = True
        if e.hints :
            h = format_ia(e.hints, "Explication de l'erreur", output='html')
        else :
            h = ""
        result['html_output'] = e.err + '\n<br>'+ h
    except Exception as e:
        result['error'] = f"<strong>Erreur :</strong><br>{str(e)}"
        import traceback
        result['error'] += f"<br><br><pre style='background:#fff3cd;padding:10px;'>{traceback.format_exc()}</pre>"

    return result


@app.route('/config')
def config_page():
    """Page de configuration"""
    # Lire la configuration actuelle
    config_data = {
        'Database': {
            'type': config.get('Database', 'type', fallback='sqlite'),
            'database': config.get('Database', 'database', fallback=''),
            'username': config.get('Database', 'username', fallback=''),
            'password': config.get('Database', 'password', fallback=''),
            'host': config.get('Database', 'host', fallback='localhost'),
            'port': config.get('Database', 'port', fallback=''),
        },
        'IA': {
            'modele': config.get('IA', 'modele', fallback=''),
            'service': config.get('IA', 'service', fallback='ollama'),
            'api-key': config.get('IA', 'api-key', fallback='None'),
            'url': config.get('IA', 'url', fallback='None'),
            'mode': config.get('IA', 'mode', fallback='off'),
        },
        'LRS': {
            'endpoint': config.get('LRS', 'endpoint', fallback=''),
            'username': config.get('LRS', 'username', fallback=''),
            'password': config.get('LRS', 'password', fallback=''),
            'mode': config.get('LRS', 'mode', fallback='off'),
        },
        'Autre': {
            'debug': config.get('Autre', 'debug', fallback='False'),
            'verbose': config.get('Autre', 'verbose', fallback='False'),
            'cache': config.get('Autre', 'cache', fallback='on'),
            'duree-cache': config.get('Autre', 'duree-cache', fallback='60'),
            'exos': config.get('Autre', 'exos', fallback='off'),
            'aide': config.get('Autre', 'aide', fallback='off'),
        }
    }

    system_info = get_system_info()
    available_databases = get_available_databases()

    return render_template('config.html', config=config_data,
                           version=__version__, available_databases=available_databases)


@app.route('/config/save', methods=['POST'])
def config_save():
    """Sauvegarde la configuration"""
    global config
    try:
        data = request.get_json()

        # Mettre à jour la configuration en mémoire
        for section, values in data.items():
            if not config.has_section(section):
                config.add_section(section)
            for key, value in values.items():
                config.set(section, key, str(value))

        # Sauvegarder dans le fichier
        import importlib.resources
        with importlib.resources.path("querycraft.config", "config-sbs.cfg") as config_file:
            with open(config_file, 'w') as f:
                config.write(f)

        # Recharger la configuration

        config = readConfigFile()

        return jsonify({
            'success': True,
            'message': 'Configuration sauvegardée avec succès'
        })

    except Exception as e:
        import traceback
        return jsonify({
            'success': False,
            'error': f"Erreur lors de la sauvegarde : {str(e)}",
            'traceback': traceback.format_exc()
        })

@app.route('/credits')
def credits():
    """Page des crédits et informations sur l'application"""
    system_info = get_system_info()
    return render_template('credits.html',
                           version=__version__,
                           system_info=system_info,)


@app.route('/')
def index():
    """Page d'accueil avec le formulaire de requête"""
    db_type = config.get('Database', 'type')
    db_name = config.get('Database', 'database')
    ia_mode = config.get('IA', 'mode', fallback='off')
    ia_service = config.get('IA', 'service', fallback='')
    ia_model = config.get('IA', 'modele', fallback='')
    de = ' display: none;' if config.get('Autre', 'exos', fallback='off') == 'off' else ' display: block;'
    system_info = get_system_info()
    return render_template('index.html',
                           db_type=db_type,
                           db_name=db_name,
                           ia_mode=ia_mode,
                           ia_service=f"{ia_service}/{ia_model}",
                           version=__version__,
                           display_exos=de,
                           system_info=system_info,
    )


@app.route('/execute', methods=['POST'])
def execute():
    """Exécute la requête SQL et retourne le résultat"""
    data = request.get_json()
    sql_query = data.get('query', '').strip()
    step_by_step = data.get('step_by_step', True)
    verbose = data.get('verbose', False) and config.getboolean('Autre', 'verbose', fallback=False)
    code_ex = data.get('code_ex', None)
    code_q = data.get('code_q', None)

    if not sql_query:
        return jsonify({
            'success': False,
            'error': 'Veuillez entrer une requête SQL'
        })

    result = execute_query_sbs(sql_query, step_by_step, verbose, code_ex, code_q)
    return jsonify(result)


@app.route('/schema', methods=['POST'])
def schema():
    """Affiche le schéma de la base de données"""
    data = request.get_json()
    verbose = data.get('verbose', False) and config.getboolean('Autre', 'verbose', fallback=False)

    try:
        debug = config.getboolean('Autre', 'debug', fallback=False)
        #verbose = verbose or config.getboolean('Autre', 'verbose', fallback=False)
        log = get_logger("describe")
        db = get_database_from_config(debug=debug, verbose=verbose, output='html')
        schema_html = db.describe(config, output='html')

        return jsonify({
            'success': True,
            'html_output': schema_html
        })
    except Exception as e:
        import traceback
        return jsonify({
            'success': False,
            'error': f"<strong>Erreur lors de la récupération du schéma :</strong><br>{str(e)}<br><br><pre style='background:#fff3cd;padding:10px;'>{traceback.format_exc()}</pre>"
        })


@app.route('/exercices')
def exercices_page():
    """Page de gestion des exercices"""
    try :
        exercices_list = exos_list()
    except Exception as e:
        print(f"Erreur lors du chargement des exercices : {e}")
        exercices_list = []
    return render_template('exercices.html', exercices=exercices_list, version=__version__)

def exos_list():
    # Lister tous les fichiers d'exercices
    exercices_list = []
    with importlib.resources.path("querycraft.exos", "") as exos_dir:
        if os.path.exists(exos_dir):
            for filename in os.listdir(exos_dir):
                if filename.endswith('.json'):
                    code_ex = filename[:-5]  # Retirer .json
                    exercices_list.append(code_ex)
    exercices_list.sort()
    #print(f"Exercices trouvés : {exercices_list}")
    return exercices_list

@app.route('/exercices/list')
def exercices_list_api():
    """API pour lister les exercices"""
    try :
        exercices_list = exos_list()
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})
    return jsonify({'success': True, 'exercices': exercices_list})


@app.route('/exercices/<code_ex>')
def exercice_detail(code_ex):
    """API pour obtenir les détails d'un exercice"""
    try:
        exos = loadExos(code_ex)

        # Convertir en format plus lisible
        questions = []
        for code_q, data in exos.items():
            requete, intention, comment, type_q, instructions = data
            questions.append({
                'code': code_q,
                'requete': requete,
                'intention': intention,
                'comment': comment,
                'type': type_q,
                'instructions': instructions
            })
        return jsonify({
            'success': True,
            'code_ex': code_ex,
            'questions': questions
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/exercices/<code_ex>/questions')
def exercice_questions(code_ex):
    """API pour obtenir les questions d'un exercice (sans les requêtes SQL)"""
    try:
        exos = loadExos(code_ex)

        # Vérifier le mode debug et verbose depuis la config
        debug = config.getboolean('Autre', 'debug', fallback=False)
        verbose = config.getboolean('Autre', 'verbose', fallback=False)

        # Retourner seulement les infos nécessaires (pas la requête SQL)
        questions = []
        for code_q, data in exos.items():
            requete, intention, comment, type_q, instructions = data

            # Récupérer la connexion à la base de données
            db = get_database_from_config(debug=debug, verbose=verbose, output='html')
            SQLQueryException.setCfg(config)

            # Créer l'objet SQL
            sql = SQL(db.db, db.dbtype, None, None, debug, verbose, False, output='html')
            sql.setSQL(requete)
            (hd, rows) = sql.getTable()
            table = f"{format_table_2(hd, rows, None,output='html')}\n"

            questions.append({
                'code': code_q,
                'intention': intention,
                'instructions': instructions,
                'type': type_q,
                'table_html': table if type_q == 'IT->R' else None
            })

        return jsonify({
            'success': True,
            'questions': questions
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })



@app.route('/exercices/<code_ex>/save', methods=['POST'])
def exercice_save(code_ex):
    """Sauvegarde un exercice"""
    try:
        data = request.get_json()
        questions = data.get('questions', [])

        # Convertir en format dict pour saveExos
        exos = {}
        for q in questions:
            exos[q['code']] = [
                q['requete'],
                q['intention'],
                q['comment'],
                q['type'],
                q['instructions']
            ]

        saveExos(code_ex, exos)

        return jsonify({
            'success': True,
            'message': f'Exercice {code_ex} sauvegardé'
        })
    except Exception as e:
        import traceback
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        })


@app.route('/exercices/<code_ex>/delete', methods=['POST'])
def exercice_delete(code_ex):
    """Supprime un exercice"""
    try:
        with importlib.resources.path("querycraft.exos", f"{code_ex}.json") as file:
            if os.path.exists(file):
                os.remove(file)
                return jsonify({
                    'success': True,
                    'message': f'Exercice {code_ex} supprimé'
                })
            else:
                return jsonify({
                    'success': False,
                    'error': f'Exercice {code_ex} introuvable'
                })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })


@app.route('/exercices/create', methods=['POST'])
def exercice_create():
    """Crée un nouvel exercice"""
    try:
        data = request.get_json()
        code_ex = data.get('code_ex', '').strip()

        if not code_ex:
            return jsonify({
                'success': False,
                'error': 'Le code de l\'exercice est requis'
            })

        # Vérifier si l'exercice existe déjà
        with importlib.resources.path("querycraft.exos", f"{code_ex}.json") as file:
            if os.path.exists(file):
                return jsonify({
                    'success': False,
                    'error': f'L\'exercice {code_ex} existe déjà'
                })

        # Créer un exercice vide
        saveExos(code_ex, {})

        return jsonify({
            'success': True,
            'message': f'Exercice {code_ex} créé',
            'code_ex': code_ex
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })


def main():
    """Point d'entrée principal de l'application web"""
    import argparse

    parser = argparse.ArgumentParser(
        description="Interface web pour QueryCraft (c) E. Desmontils, Nantes Université, 2025"
    )
    #parser.add_argument('--host', default='127.0.0.1', help='Adresse IP du serveur (défaut: 127.0.0.1)')
    parser.add_argument('--host', default='0.0.0.0', help='Adresse IP du serveur (défaut: 0.0.0.0)')
    parser.add_argument('--port', type=int, default=5000, help='Port du serveur (défaut: 5000)')
    parser.add_argument('--debug', action='store_true', help='Mode debug Flask')

    args = parser.parse_args()

    print(f"🚀 QueryCraft {__version__} version Web - Démarrage du serveur...")
    print(f"📊 Base de données : {config.get('Database', 'type')} - {config.get('Database', 'database')}")
    print(f"🤖 IA : {config.get('IA', 'mode')} ({config.get('IA', 'service')}/{config.get('IA', 'modele')})")
    print(f"🌐 Accès : http://{args.host}:{args.port}")
    print(f"\nAppuyez sur Ctrl+C pour arrêter le serveur")

    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == '__main__':
    main()
