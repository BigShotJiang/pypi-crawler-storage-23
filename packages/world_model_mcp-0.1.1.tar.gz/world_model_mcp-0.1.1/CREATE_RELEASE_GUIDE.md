# How to Create GitHub Release v0.1.0

## Step-by-Step Instructions

### Step 1: Go to Releases Page
Open this URL in your browser:
https://github.com/SaravananJaichandar/world-model-mcp/releases/new

### Step 2: Fill in the Release Form

**Tag:**
```
v0.1.0
```
(Type this in the "Choose a tag" field and select "Create new tag: v0.1.0 on publish")

**Release title:**
```
World Model MCP v0.1.0 - Initial Release
```

**Description:**
Copy the entire content from this file:
`GITHUB_RELEASE_v0.1.0.md`

To view the file content:
```bash
cat GITHUB_RELEASE_v0.1.0.md
```

Or open it in your editor and copy all the text.

### Step 3: Publish

1. Click the green **"Publish release"** button at the bottom
2. Your release will be created instantly!

### Step 4: Verify

Visit: https://github.com/SaravananJaichandar/world-model-mcp/releases

You should see:
- ✅ v0.1.0 tag
- ✅ Release title and description
- ✅ Source code downloads (automatically generated)

---

## Quick Copy-Paste

Open the release description file:
```bash
# View in terminal
cat GITHUB_RELEASE_v0.1.0.md

# Or open in your default editor
open GITHUB_RELEASE_v0.1.0.md
```

Then:
1. Select all (Cmd+A)
2. Copy (Cmd+C)
3. Paste into GitHub release description field (Cmd+V)

---

## That's it!

Your first GitHub release will be live at:
https://github.com/SaravananJaichandar/world-model-mcp/releases/tag/v0.1.0

🎉 Congratulations on your open source release!
