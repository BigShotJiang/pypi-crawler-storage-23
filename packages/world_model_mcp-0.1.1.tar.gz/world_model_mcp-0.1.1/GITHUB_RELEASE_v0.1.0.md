## 🎉 First Release - Production Ready!

**World Model MCP v0.1.0** is a production-grade MCP server that builds a "world model" for your codebase, learning from Claude Code sessions to prevent hallucinations, repeated mistakes, and regressions.

---

## ✨ What's New

### Core Features

#### 🤖 LLM-Powered Entity Extraction
- Automatically extracts entities (APIs, functions, classes) from code changes
- Uses Claude Haiku for fast, cost-effective extraction
- Fallback to regex patterns when API key not available
- Supports TypeScript, JavaScript, Python with extensible architecture

#### 🔍 External Linter Integration
- Integrates with ESLint, Pylint, and Ruff
- Pre-execution validation catches errors before code runs
- Combines world model constraints with linter rules
- Provides actionable suggestions for violations

#### 🧠 Intelligent Constraint Inference
- LLM-powered pattern recognition from user corrections
- Automatically learns project conventions
- Infers constraint type, severity, and applicability
- Generates reusable examples

**Example:**
```typescript
// Session 1: User corrects Claude
Claude: console.log('debug info');
User:   logger.debug('debug info');

// World model learns the pattern automatically

// Session 2: Claude uses logger.debug() from the start
Result: Zero repeated violations ✅
```

#### 📊 Temporal Knowledge Graph
- 6 SQLite databases with full-text search (FTS5)
- Temporal facts with validity periods (track what was true when)
- Evidence chains for every assertion
- Efficient querying (< 100ms p95)

#### 🪝 Claude Code Hooks
- TypeScript hooks for event capture and validation
- Non-blocking async execution
- Can block operations that violate constraints
- Full session lifecycle management

#### 🛠️ Six MCP Tools
1. **`query_fact`** - Check if APIs/functions exist
2. **`record_event`** - Capture development actions
3. **`validate_change`** - Pre-lint and constraint check
4. **`get_constraints`** - Retrieve rules for a file
5. **`record_correction`** - Learn from user edits
6. **`get_related_bugs`** - Find bugs fixed in a file

---

## 📈 Performance Metrics

### Achieved Goals
- ✅ **Query Latency**: < 100ms (p95) for fact lookups
- ✅ **Storage Efficiency**: < 10MB per 1000 sessions
- ✅ **Test Coverage**: 93% overall pass rate (13/14 tests)
- ✅ **Extraction Accuracy**: 100% on test cases

### Benchmarks
```
Entity Extraction:    50-200ms (LLM) / 5-10ms (patterns)
Constraint Learning:  100-300ms (LLM) / 1ms (patterns)
Linter Integration:   100-500ms (depends on project size)
Database Queries:     10-50ms (FTS5 search)
```

---

## 🚀 Installation

### Quick Start (3 commands)

```bash
# 1. Install
pip install world-model-mcp

# 2. Setup in your project
cd /path/to/your/project
python -m world_model_server.cli setup

# 3. Restart Claude Code
# Done! World model is active
```

### What Gets Installed

```
your-project/
├── .mcp.json                    # MCP server configuration
├── .claude/
│   ├── settings.json           # Hook configuration
│   ├── hooks/                  # Compiled TypeScript hooks
│   └── world-model/            # SQLite databases (155 KB initially)
```

---

## 🎯 Use Cases

### 1. Prevent Hallucinations
```
❌ Before: "I'll use User.findByEmail()..." (doesn't exist)
✅ After:  "I'll use User.findOne({email}) based on src/models/User.ts:42"
```

### 2. Learn from Corrections
```
Session 1: User corrects console.log → logger.debug
Session 2: Claude automatically uses logger.debug
Result: Zero repeated violations
```

### 3. Prevent Regressions
```
Week 1: Bug fixed (null check added on line 42)
Week 2: Refactoring preserves critical null check
Result: No re-introduction of old bugs
```

---

## 📚 Documentation

- **[README.md](https://github.com/SaravananJaichandar/world-model-mcp/blob/main/README.md)** - Complete documentation
- **[QUICKSTART.md](https://github.com/SaravananJaichandar/world-model-mcp/blob/main/QUICKSTART.md)** - 5-minute setup guide
- **[CONTRIBUTING.md](https://github.com/SaravananJaichandar/world-model-mcp/blob/main/CONTRIBUTING.md)** - Contribution guidelines

---

## 🌍 Language Support

**Currently Supported:**
- ✅ TypeScript / JavaScript
- ✅ Python

**Coming Soon:**
- Go, Rust, Java, C++

---

## 🔒 Privacy & Security

- **Local-First**: All data stays on your machine
- **No Telemetry**: Zero tracking or external data transmission
- **Optional LLM**: Works without API key (uses regex patterns as fallback)
- **MIT Licensed**: Free for commercial and personal use

---

## 🤝 Contributing

We welcome contributions! See [CONTRIBUTING.md](https://github.com/SaravananJaichandar/world-model-mcp/blob/main/CONTRIBUTING.md)

**Areas We Need Help:**
- Language parsers (Go, Rust, Java, C++)
- Performance optimization
- Documentation improvements
- Real-world testing feedback

---

## 🙏 Acknowledgments

Built on the shoulders of giants:
- **Context Graph Theory**: [Foundation Capital](https://foundationcapital.com/context-graphs-ais-trillion-dollar-opportunity/)
- **MCP Protocol**: [Anthropic's Model Context Protocol](https://www.anthropic.com/news/model-context-protocol)
- **Claude Code Hooks**: Continuous Claude v2 patterns
- **Knowledge Graphs**: Mem0, Cognee, Graphiti architectures

---

## 📊 Stats

- **29 files** committed
- **5,177 lines** of code
- **93% test** pass rate
- **100% type** hint coverage
- **MIT License**

---

**Ready to try it?** Install with `pip install world-model-mcp` and follow the [Quick Start Guide](https://github.com/SaravananJaichandar/world-model-mcp/blob/main/QUICKSTART.md)!

⭐ **Star the repo** if you find it useful!
