"""FraiseQL repository utilities."""

__all__ = []
