"""Array operator strategies."""

from .array_operators import ArrayOperatorStrategy

__all__ = ["ArrayOperatorStrategy"]
