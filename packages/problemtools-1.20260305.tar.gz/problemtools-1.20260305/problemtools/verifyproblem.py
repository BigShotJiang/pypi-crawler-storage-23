#! /usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor
import math
import threading
import queue
import glob
import string
import hashlib
import collections
import os
import signal
import re
import shutil
import logging
import tempfile
import sys
import copy
import random
import traceback
import uuid
import difflib
from pathlib import Path

import colorlog
import yaml

from . import config
from . import languages
from . import metadata
from . import problem2html
from . import problem2pdf
from . import run
from . import statement_util
from .formatversion import FormatVersion, get_format_version
from .version import add_version_arg

from abc import ABC
from typing import Any, Callable, ClassVar, Literal, Pattern, Match, ParamSpec, TypeVar, cast
from pydantic import ValidationError

random.seed(42)

log = logging.getLogger(__name__)

Verdict = Literal['AC', 'TLE', 'OLE', 'MLE', 'RTE', 'WA', 'PAC', 'JE']


def is_TLE(status: int, may_signal_with_usr1: bool = False) -> bool:
    return os.WIFSIGNALED(status) and (
        os.WTERMSIG(status) == signal.SIGXCPU or (may_signal_with_usr1 and os.WTERMSIG(status) == signal.SIGUSR1)
    )


def is_RTE(status: int) -> bool:
    return not os.WIFEXITED(status) or bool(os.WEXITSTATUS(status))


class SubmissionResult:
    def __init__(self, verdict: str, score: float | None = None, reason: str | None = None, additional_info: str | None = None):
        self.verdict = verdict
        self.score = score
        self.reason = reason
        self.additional_info = additional_info
        self.testcase: TestCase | None = None
        self.runtime_testcase: TestCase | None = None
        self.runtime = -1.0
        self.ac_runtime = -1.0
        self.ac_runtime_testcase: TestCase | None = None
        self.validator_first = False
        self.sample_failures: list[SubmissionResult] = []

    def set_ac_runtime(self) -> None:
        if self.verdict == 'AC':
            self.ac_runtime = self.runtime
            self.ac_runtime_testcase = self.runtime_testcase

    def __str__(self) -> str:
        verdict = self.verdict
        details = []

        if verdict == 'AC' and self.score is not None:
            verdict += f' ({self.score:.0f})'

        if self.reason is not None:
            details.append(self.reason)
        if self.testcase is not None:
            details.append(f'testcase: {self.testcase}')
        if self.runtime != -1:
            details.append(f'CPU: {self.runtime:.2f}s @ {self.runtime_testcase}')

        if len(details) == 0:
            return verdict
        return f'{verdict} [{", ".join(details)}]'


class VerifyError(Exception):
    pass


_T = TypeVar('_T')
_P = ParamSpec('_P')


class Context:
    def __init__(self, args: argparse.Namespace, executor: ThreadPoolExecutor | None) -> None:
        self.data_filter: Pattern[str] = args.data_filter
        self.submission_filter: Pattern[str] = args.submission_filter
        self.fixed_timelim: float | None = args.fixed_timelim
        self.executor = executor
        self._background_work: list[concurrent.futures.Future[object]] = []

    def submit_background_work(self, job: Callable[_P, _T], *args: _P.args, **kwargs: _P.kwargs) -> None:
        assert self.executor
        self._background_work.append(self.executor.submit(job, *args, **kwargs))

    def wait_for_background_work(self) -> None:
        concurrent.futures.wait(self._background_work)


class ProblemAspect(ABC):
    errors: int = 0
    warnings: int = 0
    _check_res: bool | None = None
    problem: Problem

    def __append_additional_info(self, msg: str, additional_info: str | None) -> str:
        max_additional_info = self.problem.max_additional_info()
        if additional_info is None or max_additional_info <= 0:
            return msg
        additional_info = additional_info.rstrip()
        if not additional_info:
            return msg
        lines = additional_info.split('\n')
        if len(lines) == 1:
            return f'{msg} ({lines[0]})'
        if len(lines) > max_additional_info:
            lines = lines[:max_additional_info] + [f'[.....truncated to {max_additional_info} lines.....]']

        return f'{msg}:\n' + '\n'.join(' ' * 8 + line for line in lines)

    def __init__(self, name: str, problem: Problem) -> None:
        self.log = log.getChild(name)
        self.problem = problem

    def fatal(self, msg: str, additional_info: str | None = None, *args) -> None:
        self._check_res = False
        self._add_error()
        self.log.critical(self.__append_additional_info(msg, additional_info), *args)
        raise VerifyError(msg)

    def error(self, msg: str, additional_info: str | None = None, *args) -> None:
        self._check_res = False
        self._add_error()
        self.log.error(self.__append_additional_info(msg, additional_info), *args)
        if self.problem.bail_on_error():
            raise VerifyError(msg)

    def warning(self, msg: str, additional_info: str | None = None, *args) -> None:
        if self.problem.consider_warnings_errors():
            self.error(msg, additional_info, *args)
            return
        self._add_warning()
        self.log.warning(self.__append_additional_info(msg, additional_info), *args)

    def error_in_2023_07(self, msg: str, additional_info: str | None = None, *args) -> None:
        if self.problem.format is FormatVersion.LEGACY:
            self.warning(msg, additional_info, *args)
        else:
            self.error(msg, additional_info, *args)

    def info(self, msg: str, *args) -> None:
        self.log.info(msg, *args)

    def debug(self, msg: str, *args) -> None:
        self.log.debug(msg, *args)

    def msg(self, msg):
        print(msg)

    def warn_directory(self, name: str, prop: str) -> None:
        """Warns if a directory meant for a different problem format version exists"""
        good_dir = getattr(self.problem.format, prop)
        bad_dirs = {getattr(version, prop) for version in FormatVersion} - {good_dir}
        problem_root = Path(self.problem.probdir)
        for directory in bad_dirs:
            if (problem_root / directory).exists():
                self.warning(f'Found directory "{directory}". Version {self.problem.format} looks for {name} in "{good_dir}"')

    def _add_error(self) -> None:
        self.errors += 1
        if self.problem is not self:
            self.problem._add_error()

    def _add_warning(self) -> None:
        self.warnings += 1
        if self.problem is not self:
            self.problem._add_warning()


class ProblemPart(ProblemAspect):
    """Baseclass for all parts that can be included in a problem-format."""

    """Should always be overridden by the subclass. Specifies the name that will be used to refer
    to the part e.g for logs.
    """
    PART_NAME: ClassVar[str]

    def __init__(self, problem: Problem) -> None:
        if self.PART_NAME is None:
            raise NotImplementedError('Every problem-part must override PART_NAME')
        super().__init__(f'{problem.shortname}.{self.PART_NAME}', problem)
        self.setup()

    def setup(self) -> None:
        pass

    def start_background_work(self, context: Context) -> None:
        pass

    def check(self, context: Context) -> bool:
        return True


class TestCase(ProblemAspect):
    Result = tuple[SubmissionResult, SubmissionResult, SubmissionResult]

    def __init__(self, problem: Problem, base: str, testcasegroup: TestCaseGroup) -> None:
        super().__init__(f'{problem.shortname}.test.{testcasegroup.name}.{os.path.basename(base)}', problem)
        self._base = base
        self.infile = f'{base}.in'
        self.ansfile = f'{base}.ans'
        self._problem = problem
        self.testcasegroup = testcasegroup
        self.reuse_result_from: TestCase | None = None
        self.counter = len(problem.testcase_by_infile)
        problem.testcase_by_infile[self.infile] = self

    def check_newlines(self, filename: str) -> None:
        with open(filename, 'rb') as f:
            rawdata = f.read()
            try:
                data = rawdata.decode('utf-8', 'strict')
            except UnicodeDecodeError:
                self.warning(f'The file {filename} could not be decoded as utf-8')
                return
        if data.find('\r') != -1:
            self.warning(f'The file {filename} contains non-standard line breaks.')
        if len(data) > 0 and data[-1] != '\n':
            self.warning(f"The file {filename} does not end with '\\n'.")

    def check_size_limits(self, filename: str) -> None:
        filesize = os.path.getsize(filename) / 1024.0 / 1024.0
        if filesize > 1000:
            self.error(f'The file {filename} ({filesize:.1f} Mb) is larger than 1000 Mb and can not be installed.')
        elif filesize > 100:
            self.warning(
                f'The file {filename} ({filesize:.1f} Mb) is larger than 100 Mb. This may cause performance issues and is not recommended.'
            )

    def strip_path_prefix(self, path: str) -> str:
        return os.path.relpath(path, os.path.join(self._problem.probdir, 'data'))

    def is_in_sample_group(self) -> bool:
        return self.strip_path_prefix(self.infile).startswith('sample')

    def check(self, context: Context) -> bool:
        if self._check_res is not None:
            return self._check_res
        self._check_res = True
        self.check_newlines(self.infile)
        self.check_newlines(self.ansfile)
        self.check_size_limits(self.infile)
        self.check_size_limits(self.ansfile)
        self._problem.input_validators.validate(self)
        anssize = os.path.getsize(self.ansfile) / 1024.0 / 1024.0
        outputlim = self._problem.metadata.limits.output
        if anssize > outputlim:
            self.error(
                f'Answer file ({anssize:.1f} Mb) is larger than output limit ({outputlim} Mb), you need to increase output limit'
            )
        elif 2 * anssize > outputlim:
            self.warning(
                f'Answer file ({anssize:.1f} Mb) is within 50% of output limit ({outputlim} Mb), you might want to increase output limit'
            )
        if not self._problem.is_interactive() and not self._problem.is_multi_pass():
            val_res = self._problem.output_validators.validate(self, self.ansfile)
            if val_res.verdict != 'AC':
                if self.is_in_sample_group():
                    self.error(f'judge answer file got {val_res} on testcase {self.strip_path_prefix(self.ansfile)}')
                else:
                    self.warning(f'judge answer file got {val_res} on testcase {self.strip_path_prefix(self.ansfile)}')
        self._check_symlinks()
        return self._check_res

    def __str__(self) -> str:
        return f'testcase {self.strip_path_prefix(self._base)}'

    def matches_filter(self, filter_re: Pattern[str]) -> bool:
        return filter_re.search(self.strip_path_prefix(self._base)) is not None

    def set_symlinks(self) -> None:
        if not os.path.islink(self.infile):
            return
        target = os.path.realpath(self.infile)
        if target in self._problem.testcase_by_infile:
            self.reuse_result_from = self._problem.testcase_by_infile[target]

    def _check_symlinks(self) -> bool:
        if not os.path.islink(self.infile):
            return True
        nicepath = os.path.relpath(self.infile, self._problem.probdir)
        in_target = os.path.realpath(self.infile)
        ans_target = os.path.realpath(self.ansfile)
        if not in_target.endswith('.in'):
            self.error(f"Symbolic link does not point to a .in file for input '{nicepath}'")
            return False
        if ans_target != f'{in_target[:-3]}.ans':
            self.error(f"Symbolic link '{nicepath}' must have a corresponding link for answer file")
            return False
        if self.reuse_result_from is None:
            self.error(f"Symbolic link points outside data/ directory for file '{nicepath}'")
            return False
        if (
            self.testcasegroup.config['output_validator_flags']
            != self.reuse_result_from.testcasegroup.config['output_validator_flags']
        ):
            self.error(f"Symbolic link '{nicepath}' points to testcase with different output validator flags")
            return False
        return True

    def run_submission(self, sub, runner: Runner, context: Context) -> Result:
        (res, res_low, res_high), reused = runner.run(self)
        res = self._init_result_for_testcase(res)
        res_low = self._init_result_for_testcase(res_low)
        res_high = self._init_result_for_testcase(res_high)
        msg = 'Reused test file result' if reused else 'Test file result'
        self.info(f'{msg}: {res}')
        if res.verdict != 'AC' and self.is_in_sample_group():
            res.sample_failures.append(res)

        return (res, res_low, res_high)

    def run_normal(self, sub, infile: Path, time_limit: float, feedback_dir: Path) -> SubmissionResult:
        """
        Run a submission batch-style (non-interactive)
        """
        outfile = Path(self._problem.tmpdir) / f'output-{self.counter}'
        errfile = Path(self._problem.tmpdir) / f'error-{self.counter}'

        status, runtime = sub.run(
            infile=str(infile),
            outfile=str(outfile),
            errfile=str(errfile),
            timelim=math.ceil(time_limit) + 1,
            memlim=self._problem.metadata.limits.memory,
            work_dir=sub.path,
        )
        if is_TLE(status) or runtime > time_limit:
            res_high = SubmissionResult('TLE')
        elif is_RTE(status):
            try:
                with open(errfile, mode='rt') as f:
                    info = f.read()
            except IOError:
                self.info('Failed to read error file %s', errfile)
                info = None
            res_high = SubmissionResult('RTE', additional_info=info)
        else:
            res_high = self._problem.output_validators.validate(
                self, submission_output=str(outfile), infile=str(infile), feedback_dir_path=str(feedback_dir)
            )

        res_high.runtime = runtime
        return res_high

    def run_submission_multipass(self, feedback_dir: Path, run_sub_fn) -> SubmissionResult:
        # This may be called off-main thread.

        infile = Path(self.infile)
        validation_passes = self._problem.metadata.limits.validation_passes

        input_dir = Path(tempfile.mkdtemp(prefix=f'input-{self.counter}-', dir=self.problem.tmpdir))

        slowest_pass = 0
        for curr_pass in range(validation_passes):
            res = run_sub_fn(infile)

            slowest_pass = max(slowest_pass, res.runtime)
            res.runtime = slowest_pass

            nextpass_file = feedback_dir / 'nextpass.in'

            if res.verdict != 'AC':
                if nextpass_file.is_file():
                    return SubmissionResult('JE', reason='Output validator produced nextpass.in despite non-42 exit code')
                return res

            # Done with passes
            if not nextpass_file.is_file():
                return res

            infile = input_dir / 'input.in'
            # Remove nextpass from feedback
            nextpass_file.rename(infile)

        return SubmissionResult('JE', reason=f'Multipass validator did not give verdict in {validation_passes=} passes')

    def run_submission_real(self, sub, context: Context, timelim: float, timelim_low: float, timelim_high: float) -> Result:
        # This may be called off-main thread.

        feedback_dir = Path(tempfile.mkdtemp(prefix=f'feedback-{self.counter}-', dir=self.problem.tmpdir))

        if self._problem.is_interactive():

            def run_submission(infile: Path) -> SubmissionResult:
                return self._problem.output_validators.validate_interactive(
                    self, sub, timelim_high, self._problem.submissions, str(infile), str(feedback_dir)
                )
        else:

            def run_submission(infile: Path) -> SubmissionResult:
                return self.run_normal(sub, infile, timelim_high, feedback_dir)

        if self._problem.is_multi_pass():
            res_high = self.run_submission_multipass(feedback_dir, run_submission)
        else:
            res_high = run_submission(Path(self.infile))

        if res_high.runtime <= timelim_low:
            res_low = res_high
            res = res_high
        elif res_high.runtime <= timelim:
            res_low = SubmissionResult('TLE')
            res = res_high
        elif res_high.validator_first and res_high.verdict == 'WA':
            # WA can override TLE for interactive problems (see comment in validate_interactive).
            res = SubmissionResult('WA')
            res.validator_first = True
            res_low = res
            res_high.runtime = timelim_low
        else:
            res_low = SubmissionResult('TLE')
            res = res_low

        res.runtime = res_high.runtime
        res_low.runtime = res_high.runtime
        res.set_ac_runtime()
        res_low.set_ac_runtime()
        res_high.set_ac_runtime()
        return (res, res_low, res_high)

    def _init_result_for_testcase(self, res: SubmissionResult) -> SubmissionResult:
        res = copy.copy(res)
        res.testcase = self
        res.runtime_testcase = self
        if res.score is None:
            if res.verdict == 'AC':
                res.score = self.testcasegroup.config['accept_score']
            else:
                res.score = self.testcasegroup.config['reject_score']
        return res

    def get_all_testcases(self) -> list[TestCase]:
        return [self]

    def all_datasets(self) -> list[str]:
        return [self._base]


class TestCaseGroup(ProblemAspect):
    name: str
    _DEFAULT_CONFIG = config.load_config('testdata.yaml')
    _SCORING_ONLY_KEYS = ['accept_score', 'reject_score', 'range']

    def __init__(self, problem: Problem, datadir: str | None = None, parent: TestCaseGroup | None = None):
        self._parent = parent
        self._problem = problem
        datadir = datadir or os.path.join(problem.probdir, 'data')
        self._datadir = datadir
        self.name = os.path.relpath(os.path.abspath(self._datadir), os.path.abspath(self._problem.probdir)).replace('/', '.')

        super().__init__(f'{problem.shortname}.test.{self.name}', problem)

        self._seen_oob_scores = False
        self.debug('Loading test data group %s', datadir)
        configfile = os.path.join(self._datadir, 'testdata.yaml')
        self.config: dict[str, Any] = {}
        if os.path.isfile(configfile):
            try:
                with open(configfile) as f:
                    self.config = yaml.safe_load(f)
            except Exception as e:
                self.error(str(e))
            if self.config is None:
                self.config = {}

        # For non-root groups, missing properties are inherited from the parent group
        if parent:
            for field, parent_value in parent.config.items():
                if field not in self.config:
                    self.config[field] = parent_value

        # TODO: Decide if these should stay
        # Some deprecated properties are inherited from problem config during a transition period
        legacy_grading = problem.metadata.legacy_grading
        for key in ['accept_score', 'reject_score', 'range']:
            if getattr(legacy_grading, key) is not None:
                self.config[key] = getattr(legacy_grading, key)

        problem_on_reject = legacy_grading.on_reject
        if problem_on_reject == 'first_error':
            self.config['on_reject'] = 'break'
        if problem_on_reject == 'grade':
            self.config['on_reject'] = 'continue'

        if self._problem.is_pass_fail():
            for key in TestCaseGroup._SCORING_ONLY_KEYS:
                if key not in self.config:
                    self.config[key] = None

        for field, default in TestCaseGroup._DEFAULT_CONFIG.items():
            if field not in self.config:
                self.config[field] = default

        self._items: list[TestCaseGroup | TestCase] = []
        if os.path.isdir(datadir):
            for filename in sorted(os.listdir(datadir)):
                filename = os.path.join(datadir, filename)
                if os.path.isdir(filename):
                    self._items.append(TestCaseGroup(problem, filename, self))
                else:
                    base, ext = os.path.splitext(filename)
                    if ext == '.ans' and os.path.isfile(f'{base}.in'):
                        self._items.append(TestCase(problem, base, self))

        if not parent:
            self.set_symlinks()

    def start_background_work(self, context: Context) -> None:
        pass

    def __str__(self) -> str:
        return f'testcase group {self.name}'

    def set_symlinks(self) -> None:
        for sub in self._items:
            sub.set_symlinks()

    def matches_filter(self, filter_re: Pattern[str]) -> bool:
        return True

    def get_all_testcases(self) -> list:
        res: list = []
        for child in self._items:
            res += child.get_all_testcases()
        return res

    def get_testcases(self) -> list[TestCase]:
        return [child for child in self._items if isinstance(child, TestCase)]

    def get_subgroups(self) -> list[TestCaseGroup]:
        return [child for child in self._items if isinstance(child, TestCaseGroup)]

    def get_subgroup(self, name: str) -> TestCaseGroup | None:
        return next(
            (child for child in self._items if isinstance(child, TestCaseGroup) and os.path.basename(child._datadir) == name),
            None,
        )

    def has_custom_groups(self) -> bool:
        return any(group.get_subgroups() for group in self.get_subgroups())

    def get_score_range(self) -> tuple[float, float]:
        try:
            score_range = self.config['range']
            min_score, max_score = list(map(float, score_range.split()))
            return (min_score, max_score)
        except Exception:
            return (float('-inf'), float('inf'))

    def check(self, context: Context) -> bool:
        if self._check_res is not None:
            return self._check_res
        self._check_res = True

        if self.config['grading'] not in ['default', 'custom']:
            self.error('Invalid grading policy in testdata.yaml')

        if self.config['grading'] == 'custom' and self._problem.graders._grader is None:
            self._problem.graders.fatal(f'{self} has custom grading but no custom graders provided')
        if self.config['grading'] == 'default' and Graders._default_grader is None:
            self._problem.graders.fatal(f'{self} has default grading but I could not find default grader')

        if self.config['grading'] == 'default' and 'ignore_sample' in self.config['grader_flags'].split():
            if self._parent is not None:
                self.error("'grader_flags: ignore_sample' is specified, but that flag is only allowed at top level")
            elif self.config['on_reject'] == 'break':
                self.error(
                    "'grader_flags: ignore_sample' is specified, but 'on_reject: break' may cause secret data not to be judged"
                )

        for field in self.config.keys():
            if field not in TestCaseGroup._DEFAULT_CONFIG.keys():
                self.warning(f"Unknown key '{field}' in '{os.path.join(self._datadir, 'testdata.yaml')}'")

        if not self._problem.is_scoring():
            for key in TestCaseGroup._SCORING_ONLY_KEYS:
                if self.config.get(key) is not None:
                    self.error(f"Key '{key}' is only applicable for scoring problems, this is a pass-fail problem")

        if self.config['on_reject'] not in ['break', 'continue']:
            self.error(f"Invalid value '{self.config['on_reject']}' for on_reject policy")

        if self._problem.is_scoring():
            # Check grading
            try:
                score_range = self.config['range']
                min_score, max_score = list(map(float, score_range.split()))
                if min_score > max_score:
                    self.error(f"Invalid score range '{score_range}': minimum score cannot be greater than maximum score")
            except VerifyError:
                raise
            except Exception:
                self.error(f"Invalid format '{score_range}' for range: must be exactly two floats")

        if self._parent is None:
            seen_secret = False
            seen_sample = False
            for item in self._items:
                if not isinstance(item, TestCaseGroup):
                    self.error("Can't have individual test data files at top level")
                else:
                    name = os.path.basename(item._datadir)
                    if name == 'secret':
                        seen_secret = True
                    elif name == 'sample':
                        seen_sample = True
                    else:
                        self.error('Test data at top level can only have the groups sample and secret')
                        self.debug(str(self._items))
            if not seen_secret:
                self.error('No secret data provided')
            if not seen_sample:
                self.warning('No sample data provided')

            hashes = collections.defaultdict(list)
            for root, dirs, files in os.walk(self._datadir):
                for filename in files:
                    filepath = os.path.join(root, filename)
                    if filepath.endswith('.in') and not os.path.islink(filepath):
                        md5 = hashlib.md5()
                        with open(filepath, 'rb') as f:
                            for buf in iter(lambda: f.read(1024), b''):
                                md5.update(buf)
                        filehash = md5.digest()
                        hashes[filehash].append(os.path.relpath(filepath, self._problem.probdir))
            for _, files in hashes.items():
                if len(files) > 1:
                    self.warning(f"Identical input files: '{str(files)}'")

        infiles = glob.glob(os.path.join(self._datadir, '*.in'))
        ansfiles = glob.glob(os.path.join(self._datadir, '*.ans'))

        for infile in infiles:
            if os.path.isdir(infile):
                continue
            if f'{infile[:-3]}.ans' not in ansfiles:
                self.error(f"No matching answer file for input '{infile}'")
        for ansfile in ansfiles:
            if os.path.isdir(ansfile):
                continue
            if f'{ansfile[:-4]}.in' not in infiles:
                self.error(f"No matching input file for answer '{ansfile}'")

        if not self.get_subgroups() and not self.get_testcases():
            if os.path.basename(self._datadir) != 'sample':
                self.error(f'Testcase group {self._datadir} exists, but does not contain any testcases')
            else:
                if not (
                    (self._problem.is_interactive() or self._problem.is_multi_pass())
                    and glob.glob(os.path.join(self._datadir, '*.interaction'))
                ):
                    self.warning(f'Sample testcase group {self._datadir} exists, but does not contain any testcases')

        # Check whether a <= b according to a natural sorting where numeric components
        # are compactified, so that e.g. "a" < "a1" < "a2" < "a10" = "a010" < "a10a".
        def natural_sort_le(a: str, b: str) -> bool:
            a += '\0'
            b += '\0'
            i = j = 0

            def parse_num(s: str, i: int) -> tuple[int, int]:
                ret = 0
                while ord('0') <= ord(s[i]) <= ord('9'):
                    ret = ret * 10 + ord(s[i]) - ord('0')
                    i += 1
                return ret, i

            while i < len(a) and j < len(b):
                if ord('0') <= ord(a[i]) <= ord('9') and ord('0') <= ord(b[i]) <= ord('9'):
                    anum, i = parse_num(a, i)
                    bnum, j = parse_num(b, j)
                    if anum == bnum:
                        continue
                    return anum < bnum
                if a[i] == b[j]:
                    i += 1
                    j += 1
                    continue
                return a[i] < b[j]
            return True

        last_testgroup_name = ''
        for group in self.get_subgroups():
            name = os.path.relpath(group._datadir, self._problem.probdir)
            if natural_sort_le(name, last_testgroup_name):
                self.warning(f"Test data group '{last_testgroup_name}' will be ordered before '{name}'; consider zero-padding")
            last_testgroup_name = name

        for child in self._items:
            if child.matches_filter(context.data_filter):
                child.check(context)

        return self._check_res

    def run_submission(self, sub, runner: Runner, context: Context) -> TestCase.Result:
        self.info(f'Running on {self}')
        subres: list[SubmissionResult] = []
        subres_low: list[SubmissionResult] = []
        subres_high: list[SubmissionResult] = []
        active_low, active = True, True
        on_reject = self.config['on_reject']
        broken = False
        for child in self._items:
            if not child.matches_filter(context.data_filter):
                continue
            res, res_low, res_high = child.run_submission(sub, runner, context)
            subres_high.append(res_high)
            if active:
                subres.append(res)
            if active_low:
                subres_low.append(res_low)
            if on_reject == 'break':
                active_low &= res_low.verdict == 'AC'
                active &= res.verdict == 'AC'
                if res_high.verdict != 'AC':
                    broken = True
                    break

        runner.mark_group_done(self, broken)

        return (
            self.aggregate_results(sub, subres),
            self.aggregate_results(sub, subres_low, shadow_result=True),
            self.aggregate_results(sub, subres_high, shadow_result=True),
        )

    def aggregate_results(self, sub, sub_results: list[SubmissionResult], shadow_result: bool = False) -> SubmissionResult:
        res = SubmissionResult('JE')

        for r in sub_results:
            if r.runtime > res.runtime:
                res.runtime = r.runtime
                res.runtime_testcase = r.runtime_testcase
            if r.ac_runtime > res.ac_runtime:
                res.ac_runtime = r.ac_runtime
                res.ac_runtime_testcase = r.ac_runtime_testcase
            res.sample_failures.extend(r.sample_failures)

        judge_error = next((r for r in sub_results if r.verdict == 'JE'), None)
        if judge_error:
            res.verdict = judge_error.verdict
            res.reason = judge_error.reason
            res.additional_info = judge_error.additional_info
            res.testcase = judge_error.testcase
        else:
            res.verdict, score = self._problem.graders.grade(sub_results, self, shadow_result)
            if sub_results:
                res.testcase = sub_results[-1].testcase
                res.additional_info = sub_results[-1].additional_info
            if self._problem.is_scoring():
                res.score = score
                min_score, max_score = self.get_score_range()
                if score is not None and not (min_score <= score <= max_score) and not self._seen_oob_scores:
                    # Don't warn twice on the same subgroup, since every submission is likely
                    # to have the same error.
                    self._seen_oob_scores = True
                    groupname = os.path.relpath(self._datadir, self._problem.probdir)
                    self.error(
                        f'submission {sub} got {res} on group {groupname}, which is outside of expected score range [{min_score}, {max_score}]'
                    )
        return res

    def all_datasets(self) -> list:
        res: list = []
        for child in self._items:
            res += child.all_datasets()
        return res


class ProblemStatement(ProblemPart):
    statements: dict[str, list[Path]]  # Maps language code -> statement(s)
    PART_NAME = 'statement'

    def setup(self):
        self.debug('  Loading problem statement')
        self.statements = statement_util.find_statements(Path(self.problem.probdir), self.problem.format)

    def check(self, context: Context) -> bool:
        if self._check_res is not None:
            return self._check_res
        self._check_res = True

        self.warn_directory('problem statements', 'statement_directory')

        for ifilename in glob.glob(os.path.join(self.problem.probdir, 'data/sample/*.interaction')):
            if not self.problem.is_interactive() and not self.problem.is_multi_pass():
                self.error(f'Problem is not interactive, but there is an interaction sample {ifilename}')
            with open(ifilename, 'r') as interaction:
                for i, line in enumerate(interaction):
                    valid_new_pass = self.problem.is_multi_pass() and line.strip() == '---'
                    if len(line) == 0 or (line[0] != '<' and line[0] != '>' and not valid_new_pass):
                        self.error(
                            f'Interaction {ifilename}: line {i + 1} does not start with < or > {"or ---" if self.problem.is_multi_pass() else ""}'
                        )
                        break

        if not self.statements:
            if self.problem.format is FormatVersion.LEGACY:
                allowed_statements = ', '.join(
                    f'problem.{ext}, problem.<language>.{ext}' for ext in self.problem.format.statement_extensions
                )
            else:
                allowed_statements = ', '.join(f'problem.<language>.{ext}' for ext in self.problem.format.statement_extensions)

            self.error(
                f'No problem statements found (expected file of one of following forms in directory {self.problem.format.statement_directory}/: {allowed_statements})'
            )

        def _latex_heuristic(name: str) -> bool:
            return '\\' in name or '$' in name

        for lang, files in self.statements.items():
            if len(files) > 1:
                self.error(f'Found multiple statements in the same language {lang}: {", ".join((file.name for file in files))}')

            if lang not in self.problem.metadata.name:
                self.error(f'No problem name given in language {lang}')
            elif not self.problem.metadata.name[lang]:
                self.error(f'Problem name in language {lang} is empty')
            elif not self.problem.metadata.name[lang].strip():
                self.error(f'Problem name in language {lang} contains only whitespace')
            elif self.problem.format is FormatVersion.LEGACY and _latex_heuristic(self.problem.metadata.name[lang]):
                self.warning(f'Problem name in language {lang} looks like LaTeX. Consider using plainproblemname.')

            for file in files:
                try:
                    options = problem2pdf.get_parser().parse_args([''])
                    options.problem = self.problem.probdir
                    options.language = lang
                    options.nopdf = True
                    options.quiet = True
                    if not problem2pdf.convert(options, file):
                        self.error(
                            f'Could not compile problem statement for language "{lang}".  Run problem2pdf --language {lang} on the problem to diagnose.'
                        )
                except Exception as e:
                    self.error(
                        f'Error raised when checking problem statement for language {lang}:\n{e}\n{traceback.format_exc()}'
                    )

                try:
                    options = problem2html.get_parser().parse_args([''])
                    options.problem = self.problem.probdir
                    options.destdir = os.path.join(self.problem.tmpdir, 'html')
                    options.language = lang
                    options.quiet = True
                    problem2html.convert(options, file)
                except Exception as e:
                    self.error(
                        f'Could not convert problem statement to html for language "{lang}".  Run problem2html --language {lang} on the problem to diagnose.\n{e}\n{traceback.format_exc()}'
                    )

        return self._check_res

    def __str__(self) -> str:
        return 'problem statement'


class ProblemConfig(ProblemPart):
    PART_NAME = 'config'

    def setup(self):
        self.debug('  Loading problem config')
        try:
            self._metadata, self._origdata = metadata.load_metadata(Path(self.problem.probdir))
            self.problem._set_metadata(self._metadata)
        except ValidationError as e:
            error_str = '\n'.join([f'    {"->".join((str(loc) for loc in err["loc"]))}: {err["msg"]}' for err in e.errors()])
            self.fatal(f'Failed parsing problem.yaml. Found {len(e.errors())} errors:\n{error_str}')
        except Exception as e:
            self.fatal(f'Failed loading problem configuration: {e}')

    def __str__(self) -> str:
        return 'problem configuration'

    def check(self, context: Context) -> bool:
        if self._check_res is not None:
            return self._check_res
        self._check_res = True

        INCOMPATIBLE_TYPES = [
            (metadata.ProblemType.PASS_FAIL, metadata.ProblemType.SCORING),
            (metadata.ProblemType.SUBMIT_ANSWER, metadata.ProblemType.MULTI_PASS),
            (metadata.ProblemType.SUBMIT_ANSWER, metadata.ProblemType.INTERACTIVE),
        ]
        for t1, t2 in INCOMPATIBLE_TYPES:
            if t1 in self._metadata.type and t2 in self._metadata.type:
                self.error(f'Problem has incompatible types: {t1}, {t2}')

        if self.problem.is_submit_answer():
            self.warning('The type submit-answer is not yet supported.')

        # Check rights_owner
        if self._metadata.license == metadata.License.PUBLIC_DOMAIN:
            if self._metadata.rights_owner:
                self.error('Can not have a rights_owner for a problem in public domain')
        elif self._metadata.license != metadata.License.UNKNOWN:
            if not self._metadata.rights_owner and not self._metadata.source and not self._metadata.credits.authors:
                self.error('No author, source or rights_owner provided')

        # Sanity check that the author name is parsed reasonably
        disallowed_in_name = [',', '&']
        for author in self._metadata.credits.authors:
            for disallowed_character in disallowed_in_name:
                if disallowed_character in author.name:
                    self.warning(f'Author name parsed to "{author.name}", which contains character "{disallowed_character}".')

        # Check license
        if self._metadata.license == metadata.License.UNKNOWN:
            self.warning("License is 'unknown'")

        if self._metadata.uuid is None:
            self.error_in_2023_07(f'Missing uuid from problem.yaml. Add "uuid: {uuid.uuid4()}" to problem.yaml.')

        names_with_no_statement = [lang for lang in self._metadata.name if lang not in self.problem.statement.statements]
        if names_with_no_statement:
            self.error(f'Names exist for languages without problem statements: {", ".join(names_with_no_statement)}')

        if self._metadata.legacy_grading.show_test_data_groups and self.problem.is_pass_fail():
            self.error('Showing test data groups is only supported for scoring problems, this is a pass-fail problem')
        if (
            not self.problem.is_pass_fail()
            and self.problem.testdata.has_custom_groups()
            and 'show_test_data_groups' not in self._origdata.get('grading', {})
            and self.problem.format is FormatVersion.LEGACY
        ):
            self.warning(
                'Problem has custom testcase groups, but does not specify a value for grading.show_test_data_groups; defaulting to false'
            )

        if self._metadata.legacy_grading.on_reject is not None:
            if self.problem.is_pass_fail() and self._metadata.legacy_grading.on_reject == 'grade':
                self.error("Invalid on_reject policy 'grade' for problem type 'pass-fail'")

        for deprecated_grading_key in ['accept_score', 'reject_score', 'range', 'on_reject']:
            if getattr(self._metadata.legacy_grading, deprecated_grading_key) is not None:
                self.warning(
                    f"Grading key '{deprecated_grading_key}' is deprecated in problem.yaml, use '{deprecated_grading_key}' in testdata.yaml instead"
                )

        if self._metadata.legacy_validation:
            val = self._metadata.legacy_validation.split()
            validation_type = val[0]
            validation_params = val[1:]
            if validation_type not in ['default', 'custom']:
                self.error(f"Invalid value '{validation_type}' for validation, first word must be 'default' or 'custom'")

            if validation_type == 'default' and len(validation_params) > 0:
                self.error(f"Invalid value '{self._metadata.legacy_validation}' for validation")

            if validation_type == 'custom':
                for param in validation_params:
                    if param not in ['score', 'interactive']:
                        self.error(f"Invalid parameter '{param}' for custom validation")

        if self._metadata.limits.time_limit is not None and not self._metadata.limits.time_limit.is_integer():
            self.warning(
                'Time limit configured to non-integer value. This can be fragile, and may not be supported by your CCS (Kattis does not).'
            )
        if not self._metadata.limits.time_resolution.is_integer():
            self.warning(
                'Time resolution is not an integer. This can be fragile, and may not be supported by your CCS (Kattis does not).'
            )

        return self._check_res


class Attachments(ProblemPart):
    """Represents the attachments of a problem.

    Attributes:
        attachments: The absolute paths to the attachment files for this problem.
    """

    attachments: list[Path]

    PART_NAME = 'attachments'

    def setup(self):
        attachments_dir = Path(self.problem.probdir) / 'attachments'
        self.attachments = [p for p in attachments_dir.iterdir()] if attachments_dir.is_dir() else []
        self.debug(f'Adding attachments {str(self.attachments)}')

    def check(self, context: Context) -> bool:
        if self._check_res is not None:
            return self._check_res
        self._check_res = True

        for attachment_path in self.attachments:
            if os.path.isdir(attachment_path):
                self.error(f'Directories are not allowed as attachments ({attachment_path} is a directory)')

        return self._check_res

    def get_attachment_paths(self):
        return self.attachments

    def __str__(self) -> str:
        return 'attachments'


# Junk data. The validator should reject these cases
_JUNK_CASES = [
    ('an empty file', b''),
    ('a binary file with random bytes', bytearray(random.Random(42).randbytes(1024))),
    ('a text file with the ASCII characters 32 up to 127', bytearray(x for x in range(32, 127))),
    (
        'a random text file with printable ASCII characters',
        (lambda rng: bytearray(rng.choice(string.printable.encode('utf8')) for _ in range(200)))(random.Random(42)),
    ),
]

# Try to crash the output validator, causing a judge error
_JUNK_CASES_CRASH = [
    ('a file with the number -1', b'-1'),
    ('a file with the number 2147483647', b'2147483647'),
    ('a file with the number 2147483648', b'2147483648'),
    ('a file with the number 9223372036854775808', b'9223372036854775808'),
    ('a file with the number 0', b'0'),
    ('a file with the number 1', b'1'),
    ('a file with the number 1.0', b'1.0'),
    ('a file with the string "a"', b'a'),
    ('a file with the contents "2\\n-1 1"', b'2\n-1 1'),
    ('a file with the contents "2\\n1"', b'2\n1'),
    ('a file with the contents "1\\n-1 1"', b'1\n-1 1'),
    ('a file with the contents "1\\na"', b'1\na'),
    ('a file with the contents "(()"', b'(()'),
    ('a file with the contents "1-"', b'1-'),
    ('a file with the contents "1/0"', b'1/0'),
    ('a file with the contents "2\\n<"', b'2\n<'),
    ('a file with the contents "NaN"', b'NaN'),
    ('a file with the contents "inf"', b'inf'),
    ('a file with the contents "\\x00"', b'\x00'),
    ('a file with the contents "\\x80"', b'\x80'),
]


def _build_junk_modifier(
    desc: str, pattern: str, repl: str | Callable[[Match[str]], str]
) -> tuple[str, Callable, Callable[[str], str]]:
    p = re.compile(pattern)
    return (desc, p.search, lambda text: p.sub(repl, text))


_JUNK_MODIFICATIONS = [
    _build_junk_modifier('spaces added where there already is whitespace', r'\s', lambda m: m.group(0) + ' '),
    _build_junk_modifier('spaces added to the end of a line', r'\n', lambda m: m.group(0) + ' '),
    _build_junk_modifier('newlines added where there already are newlines', '\n', lambda m: '\n\n'),
    _build_junk_modifier('leading zeros added to integers', r'(^|[^.]\b)([0-9]+)\b', r'\g<1>0000000000\g<2>'),
    _build_junk_modifier('trailing zeros added to real number decimal portion', r'\.[0-9]+\b', r'\g<0>0000000000'),
    (
        'random junk added to the end of the file',
        lambda f: True,
        lambda f: f + ''.join(random.choice(string.printable) for _ in range(200)),
    ),
]


class InputValidators(ProblemPart):
    PART_NAME = 'input_validator'

    def setup(self):
        input_validators_path = os.path.join(self.problem.probdir, 'input_format_validators')
        if os.path.isdir(input_validators_path):
            self._uses_old_path = True
        else:
            self._uses_old_path = False
            new_input_validators_path = os.path.join(self.problem.probdir, 'input_validators')
            if os.path.isdir(new_input_validators_path):
                input_validators_path = new_input_validators_path
        self._validators = run.find_programs(
            input_validators_path,
            language_config=self.problem.language_config,
            allow_validation_script=True,
            work_dir=self.problem.tmpdir,
        )
        return {}

    def __str__(self) -> str:
        return 'input format validators'

    def start_background_work(self, context: Context) -> None:
        for val in self._validators:
            context.submit_background_work(lambda v: v.compile(), val)

    def check(self, context: Context | None) -> bool:
        if self._check_res is not None:
            return self._check_res
        if self._uses_old_path:
            self.warning('input_format_validators is a deprecated name; please use input_validators instead')
        self._check_res = True
        if len(self._validators) == 0:
            self.error('No input format validators found')

        for val in self._validators[:]:
            try:
                success, msg = val.compile()
                if not success:
                    self.error(f'Compile error for {val}', msg)
                    self._validators.remove(val)
            except run.ProgramError as e:
                self.error(str(e))

        # Only sanity check input validators if they all actually compiled
        if self._check_res:
            all_flags: set[str] = set()

            def collect_flags(group: TestCaseGroup, flags: set[str]) -> None:
                if len(group.get_testcases()) > 0:
                    flags.add(group.config['input_validator_flags'])
                for subgroup in group.get_subgroups():
                    collect_flags(subgroup, flags)

            collect_flags(self.problem.testdata, all_flags)

            fd, file_name = tempfile.mkstemp()
            os.close(fd)
            for desc, case in _JUNK_CASES:
                f = open(file_name, 'wb')
                f.write(case)
                f.close()
                for flags_str in all_flags:
                    flags = flags_str.split()
                    for val in self._validators:
                        status, _ = val.run(file_name, args=flags)
                        if os.WEXITSTATUS(status) != 42:
                            break
                    else:
                        self.warning(f'No validator rejects {desc} with flags "{" ".join(flags)}"')

            def modified_input_validates(applicable, modifier):
                for testcase in self.problem.testdata.get_all_testcases():
                    try:
                        with open(testcase.infile) as infile:
                            infile_data = infile.read()
                        if not applicable(infile_data):
                            continue
                    except UnicodeDecodeError:
                        continue

                    with open(file_name, 'wb') as f:
                        f.write(modifier(infile_data).encode('utf8'))

                    for flags_str in all_flags:
                        flags = flags_str.split()
                        for val in self._validators:
                            status, _ = val.run(file_name, args=flags)
                            if os.WEXITSTATUS(status) != 42:
                                # expected behavior; validator rejects modified input
                                return False

                    # we found a file we could modify, and all validators
                    # accepted the modifications
                    return True

                # no files were modifiable
                return False

            for desc, applicable, modifier in _JUNK_MODIFICATIONS:
                if modified_input_validates(applicable, modifier):
                    self.warning(f'No validator rejects {desc}')

            os.unlink(file_name)

        return self._check_res

    def validate(self, testcase: TestCase) -> None:
        flags = testcase.testcasegroup.config['input_validator_flags'].split()

        # Remove input validators that don't compile, even without -p validators
        self.check(None)

        for val in self._validators:
            with tempfile.NamedTemporaryFile() as outfile, tempfile.NamedTemporaryFile() as errfile:
                status, _ = val.run(testcase.infile, outfile.name, errfile.name, args=flags)
                if not os.WIFEXITED(status):
                    emsg = f'Input format validator {val} crashed on input {testcase.infile}'
                elif os.WEXITSTATUS(status) != 42:
                    emsg = f'Input format validator {val} did not accept input {testcase.infile}, exit code: {os.WEXITSTATUS(status)}'
                else:
                    continue
                validator_stdout = outfile.read().decode('utf-8', 'replace')
                validator_stderr = errfile.read().decode('utf-8', 'replace')
                validator_output = '\n'.join(out for out in [validator_stdout, validator_stderr] if out)
                testcase.error(emsg, validator_output)


class Graders(ProblemPart):
    _default_grader = run.get_tool('default_grader')

    PART_NAME = 'grader'

    def setup(self):
        graders: list = run.find_programs(
            os.path.join(self.problem.probdir, 'graders'),
            language_config=self.problem.language_config,
            work_dir=self.problem.tmpdir,
        )
        if len(graders) > 1:
            self.fatal('There is more than one custom grader')
        self._grader = graders[0] if graders else None
        return {}

    def __str__(self) -> str:
        return 'graders'

    def check(self, context: Context) -> bool:
        if self._check_res is not None:
            return self._check_res
        self._check_res = True

        if self._grader:
            if self.problem.is_pass_fail() and self._grader:
                self.fatal('There is a grader but the problem is pass-fail')

            success, msg = self._grader.compile()
            if not success:
                self.fatal(f'Compile error for {self._grader}', msg)
        return self._check_res

    def grade(
        self, sub_results: list[SubmissionResult], testcasegroup: TestCaseGroup, shadow_result: bool = False
    ) -> tuple[Verdict, float | None]:
        if testcasegroup.config['grading'] == 'default':
            if not self._default_grader:
                self.fatal('Failed to locate default grader')
                return ('JE', None)
            grader = self._default_grader
        else:
            if not self._grader:
                self.fatal('Problem has grading: custom without any custom grader')
                return ('JE', None)
            grader = self._grader

        if not grader.compile()[0]:
            self.fatal(f'Failed to compile grader {grader}', grader.compile()[1])
            return ('JE', None)

        grader_input = ''.join([f'{r.verdict} {0 if r.score is None else r.score}\n' for r in sub_results])
        grader_output_re = r'^((AC)|(WA)|(TLE)|(RTE)|(JE))\s+-?[0-9.]+\s*$'
        verdict: Verdict = 'AC'
        score: float = 0

        if not sub_results:
            self.info(f'No results on {testcasegroup}, so no grader ran')
            return (verdict, score)

        grader_flags = testcasegroup.config['grader_flags'].split()
        self.debug(f'Grading {len(sub_results)} results:\n{grader_input}')
        self.debug(f'Grader flags: {grader_flags}')

        infile_path = outfile_path = errfile_path = None
        try:
            # Create input and output files for grader
            # We do it in this awkward way because the files need to be closed before reading/writing
            with tempfile.NamedTemporaryFile(mode='w', delete=False) as infile:
                infile.write(grader_input)
                infile_path = infile.name

            with tempfile.NamedTemporaryFile(delete=False) as outfile:
                outfile_path = outfile.name

            with tempfile.NamedTemporaryFile(delete=False) as errfile:
                errfile_path = errfile.name

            status, runtime = grader.run(infile_path, outfile_path, errfile_path, args=grader_flags)

            with open(outfile_path, 'r') as fh:
                grader_output = fh.read()

            with open(errfile_path, 'r') as errfile:
                stderr_content = errfile.read()

            if not os.WIFEXITED(status) or os.WEXITSTATUS(status) != 0:
                if not os.WIFEXITED(status):
                    self.error(f'Judge error: {grader} crashed')
                else:
                    self.error(f'Judge error: exit code {os.WEXITSTATUS(status)} for grader {grader}, expected 0')
                self.error(f'Grader stderr:\n{stderr_content}\n')
                self.debug(f'Grader input:\n{grader_input}')
                return ('JE', None)

            if not re.match(grader_output_re, grader_output):
                self.error('Judge error: invalid format of grader output')
                self.debug(f'Output must match: "{grader_output_re}"')
                self.debug(f'Output was: "{grader_output}"')
                return ('JE', None)

            verdict_str, score_str = grader_output.split()
            # Make mypy happy by explicitly using cast
            verdict = cast(Verdict, verdict_str)
            score = float(score_str)

            if not shadow_result:
                self.debug(f'Grade on {testcasegroup} is {verdict} ({score})')

            return (verdict, score)
        except Exception as e:
            self.error(f'Grader failed with exception {e}')
            return ('JE', None)
        finally:
            for path in [infile_path, outfile_path, errfile_path]:
                if path:
                    try:
                        os.remove(path)
                    except OSError:
                        pass


class OutputValidators(ProblemPart):
    _default_validator = run.get_tool('default_validator')

    PART_NAME = 'output_validator'

    def setup(self):
        self._validators = run.find_programs(
            os.path.join(self.problem.probdir, self.problem.format.output_validator_directory),
            language_config=self.problem.language_config,
            work_dir=self.problem.tmpdir,
        )
        self._has_precompiled = False

    def uses_default_validator(self) -> bool:
        if self.problem.format is FormatVersion.LEGACY:
            return self.problem.metadata.legacy_validation == 'default'
        return not self._validators

    def __str__(self) -> str:
        return 'output validators'

    def start_background_work(self, context: Context) -> None:
        if not self._has_precompiled:
            for val in self._actual_validators():
                context.submit_background_work(lambda v: v.compile(), val)
            self._has_precompiled = True

    def check(self, context: Context) -> bool:
        if self._check_res is not None:
            return self._check_res
        self._check_res = True

        self.warn_directory('output validators', 'output_validator_directory')

        safe_output_validator_languages = {'c', 'cpp', 'python3'}

        for v in self._validators:
            if isinstance(v, run.SourceCode) and v.language.lang_id not in safe_output_validator_languages:
                self.error_in_2023_07(
                    f'Output validator in {v.language.name}. Only {safe_output_validator_languages} are standardized. Check carefully if your CCS supports more (Kattis does not).'
                )

        if len(self._validators) > 1:
            self.error_in_2023_07('Found more than one output validator. This was allowed in legacy (but not on Kattis)')

        if self.uses_default_validator() and self._validators:
            self.error('There are validator programs but problem.yaml has validation = "default"')
        elif not self.uses_default_validator() and not self._validators:
            self.fatal('problem.yaml specifies custom validator but no validator programs found')

        if self.uses_default_validator() and self._default_validator is None:
            self.fatal('Unable to locate default validator')

        for val in self._validators[:]:
            try:
                success, msg = val.compile()
                if not success:
                    self.fatal(f'Compile error for output validator {val}', msg)
            except run.ProgramError as e:
                self.error(str(e))

        # Only sanity check output validators if they all actually compiled
        if self._check_res:
            flags = self.problem.metadata.legacy_validator_flags

            # Sanity check cases that should be rejected by the output validator
            def run_junk_case(case_desc: str, junk_content: bytes, testcases: list[TestCase]) -> list[SubmissionResult]:
                results = []
                with tempfile.NamedTemporaryFile(mode='wb') as f:
                    f.write(junk_content)
                    f.flush()
                    for testcase in testcases:
                        result = self.validate(testcase, f.name)
                        results.append(result)
                        if result.verdict == 'JE':
                            self.error(f'{case_desc} as output, and output validator flags "{" ".join(flags)}" gave {result}')
                            break
                return results

            # Junk cases that the output validator should reject
            for desc, junk_case_content in _JUNK_CASES:
                results = run_junk_case(desc, junk_case_content, self.problem.testdata.get_all_testcases())
                rejected = any(result.verdict != 'AC' for result in results)
                if not rejected:
                    self.warning(f'{desc} gets AC')

            # For performance reasons, strongly limit the amount of testcases we run on
            fast_languages = {'c', 'cpp'}
            all_validators_are_fast = True
            for val in self._validators:
                if isinstance(val, run.SourceCode):
                    all_validators_are_fast &= val.language.lang_id in fast_languages
            num_testcases = 3 if all_validators_are_fast else 1
            test_cases = self.problem.testdata.get_all_testcases()[:num_testcases]
            # Malformed cases that a poorly-written output validator might crash on
            # Note that these might be valid output, so we only check if it crashes
            for desc, junk_case_content in _JUNK_CASES_CRASH:
                run_junk_case(desc, junk_case_content, test_cases)

        return self._check_res

    @staticmethod
    def _get_feedback(feedback_dir: str) -> str | None:
        all_feedback = []
        for feedback_file in os.listdir(feedback_dir):
            feedback_path = os.path.join(feedback_dir, feedback_file)
            if os.path.getsize(feedback_path) == 0:
                continue
            all_feedback.append(f'=== {feedback_file}: ===')
            # Note: The file could contain non-unicode characters, "replace" to be on the safe side
            with open(feedback_path, 'r', errors='replace') as feedback:
                # Cap amount of feedback per file at some high-ish
                # size, so that a buggy validator spewing out lots of
                # data doesn't kill us.
                all_feedback.append(feedback.read(128 * 1024))
        if all_feedback:
            return '\n'.join(all_feedback)
        return None

    def _parse_validator_results(self, val, status: int, feedbackdir, testcase: TestCase) -> SubmissionResult:
        score = None
        # TODO: would be good to have some way of displaying the feedback for debugging uses
        score_file = os.path.join(feedbackdir, 'score.txt')
        if not self.problem.metadata.is_custom_score_allowed() and os.path.isfile(score_file):
            return SubmissionResult(
                'JE', reason='validator produced "score.txt" but problem does not have custom scoring activated'
            )

        if not os.WIFEXITED(status):
            return SubmissionResult(
                'JE',
                reason=f'output validator {val} crashed, status {status}',
                additional_info=OutputValidators._get_feedback(feedbackdir),
            )
        ret = os.WEXITSTATUS(status)
        if ret not in [42, 43]:
            return SubmissionResult(
                'JE',
                reason=f'output validator {val} exited with status {ret}',
                additional_info=OutputValidators._get_feedback(feedbackdir),
            )

        if ret == 43:
            return SubmissionResult('WA', additional_info=OutputValidators._get_feedback(feedbackdir))

        if self.problem.metadata.is_custom_score_mandatory():
            if os.path.isfile(score_file):
                try:
                    score_str = open(score_file).read()
                    score = float(score_str)
                except Exception as e:
                    return SubmissionResult('JE', reason=f'failed to parse validator score: {e}')
            else:
                # If we're running multipass, we do not need to output a score after every pass
                # We accept the small risk of allowing a non-multipass output validator to not output score.txt
                # if it produces a file called nextpass.in
                if (Path(feedbackdir) / 'nextpass.in').exists():
                    score = 0
                else:
                    return SubmissionResult('JE', reason='problem has custom scoring but validator did not produce "score.txt"')

        return SubmissionResult('AC', score=score)

    def _actual_validators(self) -> list:
        if self.uses_default_validator():
            return [self._default_validator]
        return self._validators

    def validate_interactive(
        self,
        testcase: TestCase,
        submission,
        timelim: float,
        errorhandler: Submissions,
        infile: str | None = None,
        feedback_dir_path: str | None = None,
    ) -> SubmissionResult:
        # This may be called off-main thread.
        interactive_output_re = r'\d+ \d+\.\d+ \d+ \d+\.\d+ (validator|submission)'
        res = SubmissionResult('JE')
        interactive = run.get_tool('interactive')
        if interactive is None:
            errorhandler.error('Could not locate interactive runner')
            return res
        # file descriptor, wall time lim
        initargs = ['1', str(math.ceil(2 * timelim))]
        validator_args = [infile if infile else testcase.infile, testcase.ansfile, '<feedbackdir>']
        submission_args = submission.get_runcmd(memlim=self.problem.metadata.limits.memory)

        val_memlim = self.problem.metadata.limits.validation_memory
        for i, val in enumerate(self._actual_validators()):
            if val.compile()[0]:
                # If we are running multiple output validators in legacy, make sure to wipe it
                # If we are running multipass, i will always be 0 and we do not accidentally wipe feedback
                if i > 0 and feedback_dir_path:
                    shutil.rmtree(feedback_dir_path)
                    Path(feedback_dir_path).mkdir()

                if feedback_dir_path:
                    feedbackdir = feedback_dir_path
                else:
                    feedbackdir = tempfile.mkdtemp(prefix='feedback', dir=self.problem.tmpdir)

                validator_args[2] = feedbackdir + os.sep
                f = tempfile.NamedTemporaryFile(delete=False)
                interactive_out = f.name
                f.close()
                i_status, _ = interactive.run(
                    outfile=interactive_out,
                    args=initargs + val.get_runcmd(memlim=val_memlim) + validator_args + [';'] + submission_args,
                    work_dir=submission.path,
                )
                if is_RTE(i_status):
                    errorhandler.error(f'Interactive crashed, status {i_status}')
                else:
                    interactive_output = open(interactive_out).read()
                    errorhandler.debug(f'Interactive output: "{interactive_output}"')
                    if not re.match(interactive_output_re, interactive_output):
                        errorhandler.error(
                            f'Output from interactive does not follow expected format, got output "{interactive_output}"'
                        )
                    else:
                        val_status_str, _, sub_status_str, sub_runtime_str, first = interactive_output.split()
                        sub_status = int(sub_status_str)
                        sub_runtime = float(sub_runtime_str)
                        val_status = int(val_status_str)
                        val_JE = not os.WIFEXITED(val_status) or os.WEXITSTATUS(val_status) not in [42, 43]
                        val_WA = os.WIFEXITED(val_status) and os.WEXITSTATUS(val_status) == 43
                        if val_JE or (val_WA and first == 'validator'):
                            # If the validator crashed, or exited first with WA,
                            # always follow validator verdict, even if that early
                            # exit caused the submission to behave erratically and
                            # time out.
                            if sub_runtime > timelim:
                                sub_runtime = timelim
                            res = self._parse_validator_results(val, val_status, feedbackdir, testcase)
                        elif is_TLE(sub_status, True) or sub_runtime > timelim:
                            res = SubmissionResult('TLE')
                        elif is_RTE(sub_status):
                            res = SubmissionResult('RTE')
                        else:
                            res = self._parse_validator_results(val, val_status, feedbackdir, testcase)

                        res.runtime = sub_runtime
                        res.validator_first = first == 'validator'

                os.unlink(interactive_out)
                if feedback_dir_path is None:
                    shutil.rmtree(feedbackdir)
                if res.verdict != 'AC':
                    return res
        return res

    def validate(
        self, testcase: TestCase, submission_output: str, infile: str | None = None, feedback_dir_path: str | None = None
    ) -> SubmissionResult:
        """
        Run all output validators on the given test case and submission output.
        Parameters:
            testcase: The test case we are validating.
            submission_output: Path to out file of submission.
            infile: The input file. Overrides testcase.infile if we are running multipass.
            feedback_dir_path: Path to feedback directory. If None, a temporary directory will be created and cleaned up.
        """
        res = SubmissionResult('JE')
        val_timelim = self.problem.metadata.limits.validation_time
        val_memlim = self.problem.metadata.limits.validation_memory
        flags = (
            self.problem.metadata.legacy_validator_flags.split() + testcase.testcasegroup.config['output_validator_flags'].split()
        )
        for i, val in enumerate(self._actual_validators()):
            if val.compile()[0]:
                # If we are running multiple output validators in legacy, make sure to wipe it
                # If we are running multipass, i will always be 0 and we do not accidentally wipe feedback
                if i > 0 and feedback_dir_path:
                    shutil.rmtree(feedback_dir_path)
                    Path(feedback_dir_path).mkdir()

                if feedback_dir_path:
                    feedbackdir = feedback_dir_path
                else:
                    feedbackdir = tempfile.mkdtemp(prefix='feedback', dir=self.problem.tmpdir)

                validator_output = tempfile.mkdtemp(prefix='checker_out', dir=self.problem.tmpdir)
                outfile = validator_output + '/out.txt'
                errfile = validator_output + '/err.txt'
                status, runtime = val.run(
                    infile=submission_output,
                    args=[infile if infile else testcase.infile, testcase.ansfile, feedbackdir] + flags,
                    timelim=val_timelim,
                    memlim=val_memlim,
                    outfile=outfile,
                    errfile=errfile,
                )
                if self.log.isEnabledFor(logging.DEBUG):
                    try:
                        with open(outfile, mode='rt') as f:
                            output = f.read()
                        if output:
                            self.log.debug('Validator output:\n%s', output)
                        with open(errfile, mode='rt') as f:
                            error = f.read()
                        if error:
                            self.log.debug('Validator stderr:\n%s', error)
                    except IOError as e:
                        self.info('Failed to read validator output: %s', e)
                res = self._parse_validator_results(val, status, feedbackdir, testcase)
                shutil.rmtree(validator_output)
                if feedback_dir_path is None:
                    shutil.rmtree(feedbackdir)
                if res.verdict != 'AC':
                    return res

        # TODO: check that all output validators give same result
        return res


class Runner:
    def __init__(self, problem: Problem, sub, context: Context, timelim: float, timelim_low: float, timelim_high: float) -> None:
        self._problem = problem
        self._sub = sub
        self._context = context
        self._multithreaded = context.executor is not None
        self._timelim = timelim
        self._timelim_low = timelim_low
        self._timelim_high = timelim_high
        self._cache: dict[TestCase, TestCase.Result] = {}
        if self._multithreaded:
            self._queues: dict[TestCase, queue.Queue[TestCase.Result]] = {}
            self._lock = threading.Lock()
            self._started_jobs: set[TestCase] = set()
            self._done_groups: set[TestCaseGroup] = set()
            self._remaining_jobs: list[TestCase] = []
            self._recompute_jobs()

    def __enter__(self) -> Runner:
        if self._multithreaded:
            for i in range(len(self._remaining_jobs)):
                self._context.submit_background_work(self._work)
        return self

    def __exit__(self, *exc) -> None:
        if self._multithreaded:
            with self._lock:
                self._remaining_jobs = []

    def run(self, testcase: TestCase) -> tuple[TestCase.Result, bool]:
        while testcase.reuse_result_from:
            testcase = testcase.reuse_result_from

        if testcase in self._cache:
            return (self._cache[testcase], True)

        if sys.stdout.isatty():
            msg = f'Running {self._sub} on {testcase}...'
            sys.stdout.write(msg)
            sys.stdout.flush()

        if self._multithreaded:
            result = self._queues[testcase].get()
        else:
            result = self._run_submission_real(testcase)

        if sys.stdout.isatty():
            sys.stdout.write('\b \b' * len(msg))

        self._cache[testcase] = result
        return (result, False)

    def mark_group_done(self, group: TestCaseGroup, broken: bool) -> None:
        if self._multithreaded:
            self._done_groups.add(group)
            if broken:
                # Since a group was broken out of, some test cases may no
                # longer be relevant to run. Recompute the work list.
                self._recompute_jobs()

    def _run_submission_real(self, item: TestCase) -> TestCase.Result:
        return item.run_submission_real(self._sub, self._context, self._timelim, self._timelim_low, self._timelim_high)

    def _work(self) -> None:
        item = self._next_job()
        if item:
            res = self._run_submission_real(item)
            self._queues[item].put(res)

    def _gather_testcases(self, item: TestCase | TestCaseGroup) -> list[TestCase]:
        if not item.matches_filter(self._context.data_filter):
            return []
        if isinstance(item, TestCase):
            if item.reuse_result_from:
                return self._gather_testcases(item.reuse_result_from)
            else:
                return [item]
        elif item not in self._done_groups:
            ret = []
            for child in item.get_testcases() + item.get_subgroups():
                ret.extend(self._gather_testcases(child))
            return ret
        else:
            return []

    def _next_job(self) -> TestCase | None:
        with self._lock:
            if self._remaining_jobs:
                job = self._remaining_jobs.pop()
                self._started_jobs.add(job)
                return job
            else:
                return None

    def _recompute_jobs(self) -> None:
        with self._lock:
            seen = set(self._started_jobs)
            self._remaining_jobs = []
            for testcase in self._gather_testcases(self._problem.testdata):
                if testcase not in seen:
                    seen.add(testcase)
                    self._remaining_jobs.append(testcase)
                    if testcase not in self._queues:
                        self._queues[testcase] = queue.Queue(maxsize=1)
            self._remaining_jobs.reverse()


class Submissions(ProblemPart):
    # (verdict, directory, required)
    _VERDICTS: list[tuple[Verdict, str, bool]] = [
        ('AC', 'accepted', True),
        ('PAC', 'partially_accepted', False),
        ('WA', 'wrong_answer', False),
        ('RTE', 'run_time_error', False),
        ('TLE', 'time_limit_exceeded', False),
    ]

    PART_NAME = 'submission'

    def setup(self):
        self._submissions = {}
        srcdir = os.path.join(self.problem.probdir, 'submissions')
        for verdict in Submissions._VERDICTS:
            acr = verdict[0]
            self._submissions[acr] = run.find_programs(
                os.path.join(srcdir, verdict[1]),
                language_config=self.problem.language_config,
                work_dir=self.problem.tmpdir,
                include_dir=os.path.join(self.problem.probdir, 'include'),
            )
        return {}

    def __str__(self) -> str:
        return 'submissions'

    def check_submission(
        self, sub, context: Context, expected_verdict: Verdict, timelim: float, timelim_high: float
    ) -> SubmissionResult:
        desc = f'{expected_verdict} submission {sub}'
        partial = False
        if expected_verdict == 'PAC':
            expected_verdict = 'AC'
            partial = True
            # For partially accepted, we don't want to use them to lower bound the time limit, but we do want
            # to warn if they're slow enough that they would have affected the time limit, had they been used
            # to compute it.
            timelim_low = timelim / self.problem.metadata.limits.time_multipliers.ac_to_time_limit
        else:
            timelim_low = timelim

        with Runner(self.problem, sub, context, timelim, timelim_low, timelim_high) as runner:
            result, result_low, result_high = self.problem.testdata.run_submission(sub, runner, context)

        if result.verdict == 'AC' and expected_verdict == 'AC' and not partial and result.sample_failures:
            res = result.sample_failures[0]
            self.warning(f'{desc} got {res.verdict} on sample: {res}')

        if result_low.verdict != result_high.verdict or result_low.score != result_high.score:
            r1, r2 = (
                (result_low, result_high)
                if result_low.verdict == result_high.verdict
                else (result_low.verdict, result_high.verdict)
            )
            self.warning(
                f'{desc} sensitive to time limit: limit of {timelim_low} secs -> {r1}, limit of {timelim_high} secs -> {r2}'
            )

        if partial and self.fully_accepted(result):
            self.warning(f'{desc} got {result}')
        elif result.verdict == expected_verdict:
            self.msg(f'   {desc} OK: {result}')
            if expected_verdict == 'AC' and not partial and not self.fully_accepted(result) and self.full_score_finite():
                # For some heuristic problems, this is expected. Thus, only warn.
                self.warning(f'{desc} did not attain full score (consider moving it to partially_accepted)')
        elif result_high.verdict == expected_verdict and not (partial and self.fully_accepted(result_high)):
            self.msg(f'   {desc} OK with extra time: {result_high}')
        else:
            self.error(f'{desc} got {result}', result_high.additional_info)

        return result

    def full_score_finite(self) -> bool:
        min_score, max_score = self.problem.testdata.get_score_range()
        if self.problem.metadata.legacy_grading.objective == 'min':
            return min_score != float('-inf')
        else:
            return max_score != float('inf')

    def fully_accepted(self, result: SubmissionResult) -> bool:
        min_score, max_score = self.problem.testdata.get_score_range()
        best_score = min_score if self.problem.metadata.legacy_grading.objective == 'min' else max_score
        return result.verdict == 'AC' and (not self.problem.is_scoring() or result.score == best_score)

    def start_background_work(self, context: Context) -> None:
        # Send off an early background compile job for each submission and
        # validator, to avoid a bottleneck step at the start of each test run.
        self.problem.output_validators.start_background_work(context)
        for verdict in Submissions._VERDICTS:
            acr = verdict[0]
            for sub in self._submissions[acr]:
                sub_name = sub.name  # type: ignore
                if context.submission_filter.search(os.path.join(verdict[1], sub_name)):
                    context.submit_background_work(lambda s: s.compile(), sub)

    def _compute_time_limit(self, fixed_limit: float | None, lower_bound_runtime: float | None) -> tuple[float, float]:
        if fixed_limit is None and lower_bound_runtime is None:
            # 5 minutes is our currently hard coded upper bound for what to allow when we don't know the time limit yet
            return 300.0, 300.0

        limits = self.problem.metadata.limits
        if fixed_limit is not None:
            timelim = fixed_limit
        else:
            assert lower_bound_runtime is not None, 'Assert to keep mypy happy'
            exact_timelim = lower_bound_runtime * limits.time_multipliers.ac_to_time_limit
            timelim = max(1, math.ceil(exact_timelim / limits.time_resolution)) * limits.time_resolution

        return timelim, timelim * limits.time_multipliers.time_limit_to_tle

    def check(self, context: Context) -> bool:
        if self._check_res is not None:
            return self._check_res
        self._check_res = True

        limits = self.problem.metadata.limits
        ac_to_time_limit = limits.time_multipliers.ac_to_time_limit

        fixed_limit: float | None = context.fixed_timelim if context.fixed_timelim is not None else limits.time_limit
        lower_bound_runtime: float | None = None  # The runtime of the slowest submission used to lower bound the time limit.

        if limits.time_limit is not None and context.fixed_timelim is not None:
            self.warning('There is a fixed time limit in problem.yaml, and you provided one on command line. Using command line.')

        for verdict in Submissions._VERDICTS:
            acr = verdict[0]
            if verdict[2] and not self._submissions[acr]:
                self.error(f'Require at least one "{verdict[1]}" submission')

            runtimes = []

            for sub in self._submissions[acr]:
                sub_name = sub.name  # type: ignore
                if context.submission_filter.search(os.path.join(verdict[1], sub_name)):
                    self.info(f'Check {acr} submission {sub}')

                    if sub.code_size() > 1024 * limits.code:
                        self.error(
                            f'{acr} submission {sub} has size {sub.code_size() / 1024.0:.1f} kiB, exceeds code size limit of {limits.code} kiB'
                        )
                        continue

                    success, msg = sub.compile()
                    if not success:
                        self.error(f'Compile error for {acr} submission {sub}', additional_info=msg)
                        continue

                    timelim, timelim_high = self._compute_time_limit(fixed_limit, lower_bound_runtime)
                    res = self.check_submission(sub, context, acr, timelim, timelim_high)
                    runtimes.append(res.runtime)

            if acr == 'AC':
                if len(runtimes) > 0:
                    lower_bound_runtime = max(runtimes)

                # Helper function to format numbers with at most 3 decimals and dealing with None
                def _f_n(number: float | None) -> str:
                    return f'{round(number, 3):g}' if number is not None else '-'

                if fixed_limit is not None and lower_bound_runtime is not None:
                    if lower_bound_runtime * ac_to_time_limit > fixed_limit:
                        self.error(
                            f'Time limit fixed to {_f_n(fixed_limit)}, but slowest AC runs in {_f_n(lower_bound_runtime)} which is within a factor {_f_n(ac_to_time_limit)}.'
                        )
                    tl_from_subs, _ = self._compute_time_limit(None, lower_bound_runtime)
                    if not math.isclose(fixed_limit, tl_from_subs):
                        self.msg(
                            f'   Solutions give timelim of {_f_n(tl_from_subs)} seconds, but will use provided fixed limit of {_f_n(fixed_limit)} seconds instead'
                        )

                timelim, timelim_margin = self._compute_time_limit(fixed_limit, lower_bound_runtime)
                self.msg(
                    f'   Slowest AC runtime: {_f_n(lower_bound_runtime)}, setting timelim to {_f_n(timelim)} secs, safety margin to {_f_n(timelim_margin)} secs'
                )
                self.problem._set_timelim(timelim)

        return self._check_res


PROBLEM_PARTS = ['config', 'data', 'graders', 'statement', 'submissions', 'validators']


class Problem(ProblemAspect):
    """Represents a checkable problem"""

    def __init__(self, probdir: str, args: argparse.Namespace):
        self.probdir = os.path.realpath(probdir)
        self.shortname: str = os.path.basename(self.probdir)
        super().__init__(self.shortname, self)
        self.language_config = languages.load_language_config(Path(self.probdir).parent)
        self.testcase_by_infile: dict[str, TestCase] = {}
        self.loaded = False
        self._metadata: metadata.Metadata | None = None
        self._args = args
        self._timelim: float | None = None

    # Unfortunately must be before metadata, otherwise mypy gets confused about the type metadata.Metadata (feels like a bug)
    def _set_metadata(self, metadata: metadata.Metadata) -> None:  # Should only be called by ProblemConfig
        assert self._metadata is None, 'Attempted to set metadata twice'
        self._metadata = metadata

    @property
    def metadata(self) -> metadata.Metadata:
        assert self._metadata is not None, 'Attempted to access config before it was set. load() or check() first.'
        return self._metadata

    @property
    def timelim(self) -> float:
        assert self._timelim is not None, 'Attempted to access timelim before it was set. check() first.'
        return self._timelim

    def _set_timelim(self, timelim: float) -> None:  # Should only be called by Submissions
        assert self._timelim is None, 'Attempted to set timelim twice'
        self._timelim = timelim

    def is_pass_fail(self) -> bool:
        return self.metadata.is_pass_fail()

    def is_scoring(self) -> bool:
        return self.metadata.is_scoring()

    def is_interactive(self) -> bool:
        return self.metadata.is_interactive()

    def is_multi_pass(self) -> bool:
        return self.metadata.is_multi_pass()

    def is_submit_answer(self) -> bool:
        return self.metadata.is_submit_answer()

    def load(self) -> None:
        """Parses the problem package statically, loading up information with very little verification.

        Call this if you want to get a usable Problem object without expensive
        steps (such as compiling validators, and testing submissions).

        N.B., This api is EXPERIMENTAL. We eventually want to create a stable
        API from problemtools, this is a first move in that direction.

        Raises:
            VerifyError: if problem package is too broken to parse safely
        """

        if self.loaded:
            return

        if not os.path.isdir(self.probdir):
            self.fatal(f"Problem directory '{self.probdir}' not found")

        try:
            self.format = get_format_version(Path(self.probdir))
        except Exception as e:
            self.fatal(f'Failed loading problem version: {e}')
        self.config = ProblemConfig(self)  # Populates self.metadata as a side effect. Needs to run first.
        self.statement = ProblemStatement(self)
        self.attachments = Attachments(self)
        self.input_validators = InputValidators(self)
        self.output_validators = OutputValidators(self)
        self.graders = Graders(self)
        self.testdata = TestCaseGroup(self, os.path.join(self.probdir, 'data'))
        self.submissions = Submissions(self)
        self.loaded = True

    def __enter__(self) -> Problem:
        self.tmpdir = tempfile.mkdtemp(prefix=f'verify-{self.shortname}-')
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback) -> None:
        shutil.rmtree(self.tmpdir)

    def __str__(self) -> str:
        return str(self.shortname)

    def check(self) -> tuple[int, int]:
        """Loads and checks the problem package

        Loads the problem package and runs checks. After this has completed,
        the Problem object is fully populated. You do not need to manually
        run load() first.

        Returns:
            Tuple with the number of errors, warnings found.

        Raises:
            VerifyError: if problem package is too broken to parse safely
        """
        try:
            self.load()
        except VerifyError:
            return self.errors, self.warnings

        executor = ThreadPoolExecutor(self._args.threads) if self._args.threads > 1 else None
        context = Context(self._args, executor)

        try:
            part_mapping: dict[str, list] = {
                'config': [self.config],
                'statement': [self.statement, self.attachments],
                'validators': [self.input_validators, self.output_validators],
                'graders': [self.graders],
                'data': [self.testdata],
                'submissions': [self.submissions],
            }
            assert sorted(part_mapping.keys()) == sorted(PROBLEM_PARTS), 'part_mapping and PROBLEM_PARTS must be kept in sync'

            if not re.match('^[a-z0-9]+$', self.shortname):
                self.error(f"Invalid shortname '{self.shortname}' (must be [a-z0-9]+)")
            if self.format is FormatVersion.V_2023_07:
                self.warning(f'Support for version {self.format} is very incomplete. Verification may not work as expected.')

            self._check_symlinks()
            self._check_file_and_directory_names()
            self._check_submission_directory_names()

            run.limit.check_limit_capabilities(self)

            parts = [
                part for part in part_mapping if part in self._args.parts
            ]  # Parts from _args in the order they appear in part_mapping
            if executor:
                for part in parts:
                    for item in part_mapping[part]:
                        item.start_background_work(context)

            for part in parts:
                self.msg(f'Checking {part}')
                for item in part_mapping[part]:
                    item.check(context)
        except VerifyError:
            pass
        finally:
            # Wait for background work to finish before performing an rmtree on
            # the directory tree it uses.
            context.wait_for_background_work()
        return self.errors, self.warnings

    def _check_submission_directory_names(self):
        """Heuristically check if submissions contain any directories that will be ignored because of typos or format mismatches"""
        submission_directories = [p.name for p in (Path(self.probdir) / 'submissions').glob('*') if p.is_dir()]
        if len(submission_directories) == 0:
            return

        def most_similar(present_dir: str, format_version: FormatVersion):
            similarities = [
                (spec_dir, difflib.SequenceMatcher(None, present_dir, spec_dir).ratio())
                for spec_dir in format_version.submission_directories
            ]
            return max(similarities, key=lambda x: x[1])

        for present_dir in submission_directories:
            most_similar_dir, max_similarity = most_similar(present_dir, self.format)

            if max_similarity == 1:
                # Exact match, no typo
                continue

            if 0.75 <= max_similarity:
                self.warning(f'Potential typo: directory submissions/{present_dir} is similar to {most_similar_dir}')
            else:
                for other_version in [v for v in FormatVersion if v != self.format]:
                    _, max_similarity = most_similar(present_dir, other_version)
                    if max_similarity == 1:
                        self.warning(
                            f'Directory submissions/{present_dir} is not part of format version {self.format}, but part of {other_version}'
                        )
                        break

    def _check_symlinks(self):
        """Check that all symlinks point to something existing within the problem package"""
        probdir = os.path.realpath(self.probdir)
        for root, dirs, files in os.walk(probdir):
            for file in dirs + files:
                filename = os.path.join(root, file)
                if os.path.islink(filename):
                    target = os.path.realpath(filename)
                    # relfile is the filename of the symlink, relative to the problem root (only used for nicer error messages)
                    relfile = os.path.relpath(filename, self.probdir)
                    # reltarget is what the symlink points to (absolute, or relative to where the symlink is)
                    reltarget = os.readlink(filename)
                    if not os.path.exists(target):
                        self.error(f'Symlink {relfile} links to {reltarget} which does not exist')
                    if os.path.commonpath([probdir, target]) != probdir:
                        self.error(f'Symlink {relfile} links to {reltarget} which is outside of problem package')
                    if os.path.isabs(reltarget):
                        self.error(
                            f'Symlink {relfile} links to {reltarget} which is an absolute path. Symlinks must be relative.'
                        )

    def _check_file_and_directory_names(self):
        regex = re.compile(r'^[a-zA-Z0-9_][a-zA-Z0-9_.-]{0,254}$')

        def _special_case_allowed_files(file: str, reldir: str) -> bool:
            return file == '.gitignore' or (file == '.timelimit' and reldir == os.path.basename(self.probdir))

        def _special_case_allowed_dirs(directory: str, reldir: str) -> bool:
            return directory == '.git' and reldir == os.path.basename(self.probdir)

        for root, dirs, files in os.walk(self.probdir):
            # Path of the directory we're in, starting with problem shortname. Only used for nicer error messages.
            reldir = os.path.relpath(root, os.path.dirname(self.probdir))
            for file in files:
                if not regex.match(file) and not _special_case_allowed_files(file, reldir):
                    self.error(f"Invalid file name '{file}' in {reldir}, should match {regex.pattern}")
            for directory in dirs:
                if not regex.match(directory) and not _special_case_allowed_dirs(directory, reldir):
                    self.error(f"Invalid directory name '{directory}' in {reldir}, should match {regex.pattern}")

    def bail_on_error(self) -> bool:
        return self._args.bail_on_error

    def consider_warnings_errors(self) -> bool:
        return self._args.werror

    def max_additional_info(self) -> int:
        return self._args.max_additional_info


def re_argument(s: str) -> Pattern[str]:
    try:
        r = re.compile(s)
        return r
    except re.error:
        raise argparse.ArgumentTypeError(f'{s} is not a valid regex')


def part_argument(s: str) -> str:
    if s not in PROBLEM_PARTS:
        raise argparse.ArgumentTypeError(f'Invalid problem part specified: {s}')
    return s


def argparser_basic_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument('-b', '--bail_on_error', action='store_true', help='bail verification on first error')
    parser.add_argument('-l', '--log_level', default='warning', help='set log level (debug, info, warning, error, critical)')
    parser.add_argument('-e', '--werror', action='store_true', help='consider warnings as errors')
    parser.add_argument(
        '--max_additional_info',
        type=int,
        default=15,
        help='maximum number of lines of additional info (e.g. compiler output or validator feedback) to display about an error (set to 0 to disable additional info)',
    )


def argparser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description='Validate a problem package in the Kattis problem format.')
    parser.add_argument(
        '-s',
        '--submission_filter',
        metavar='SUBMISSIONS',
        type=re_argument,
        default=re.compile('.*'),
        help='run only submissions whose name contains this regex.  The name includes category (accepted, wrong_answer, etc), e.g. "accepted/hello.java" (for a single file submission) or "wrong_answer/hello" (for a directory submission)',
    )
    parser.add_argument(
        '-d',
        '--data_filter',
        metavar='DATA',
        type=re_argument,
        default=re.compile('.*'),
        help='use only data files whose name contains this regex.  The name includes path relative to the data directory but not the extension, e.g. "sample/hello" for a sample data file',
    )
    parser.add_argument(
        '-t',
        '--fixed_timelim',
        type=float,
        help='use this fixed time limit (useful in combination with -d and/or -s when all AC submissions might not be run on all data)',
    )
    parser.add_argument(
        '-p',
        '--parts',
        metavar='PROBLEM_PART',
        type=part_argument,
        nargs='+',
        default=PROBLEM_PARTS,
        help=f'only test the indicated parts of the problem.  Each PROBLEM_PART can be one of {PROBLEM_PARTS}.',
    )
    parser.add_argument(
        '-j',
        '--threads',
        type=int,
        default=1,
        help='run validation using multiple threads. This will make timings less reliable, but can be convenient during development',
    )

    add_version_arg(parser)
    argparser_basic_arguments(parser)

    parser.add_argument('problemdir', nargs='+')
    return parser


def initialize_logging(args: argparse.Namespace) -> None:
    fmt = '%(log_color)s%(levelname)s %(message)s'
    colorlog.basicConfig(stream=sys.stdout, format=fmt, level=getattr(logging, args.log_level.upper()))


def main() -> None:
    args = argparser().parse_args()

    initialize_logging(args)

    total_errors = 0
    try:
        for problemdir in args.problemdir:
            print(f'Loading problem {os.path.basename(os.path.realpath(problemdir))}')
            with Problem(problemdir, args) as prob:
                errors, warnings = prob.check()

                def p(x: int) -> str:
                    return '' if x == 1 else 's'

                print(f'{prob.shortname} tested: {errors} error{p(errors)}, {warnings} warning{p(warnings)}')
                total_errors += errors

    except KeyboardInterrupt:
        print('\naborting...')
    finally:
        if total_errors > 0:
            sys.exit(1)


if __name__ == '__main__':
    main()
