XSS via sample?
