"""Tests for MCP CLI."""
