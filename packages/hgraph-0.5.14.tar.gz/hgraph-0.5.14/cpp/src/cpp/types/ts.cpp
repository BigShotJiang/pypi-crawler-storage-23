#include <hgraph/types/ts.h>
#include <hgraph/util/string_utils.h>

namespace hgraph {

    // ============================================================================
    // TimeSeriesValueOutput Implementation
    // ============================================================================

    TimeSeriesValueOutput::TimeSeriesValueOutput(Node* owning_node, const value::TypeMeta* schema)
        : TimeSeriesValueOutputBase(owning_node), _value(schema) {}

    TimeSeriesValueOutput::TimeSeriesValueOutput(TimeSeriesOutput* parent, const value::TypeMeta* schema)
        : TimeSeriesValueOutputBase(parent), _value(schema) {}

    nb::object TimeSeriesValueOutput::py_value() const {
        if (!valid()) {
            return nb::none();
        }
        if (_py_cached_value.is_valid()) {
            return _py_cached_value;
        }
        return _value.to_python();
    }

    nb::object TimeSeriesValueOutput::py_delta_value() const {
        return py_value();
    }

    void TimeSeriesValueOutput::py_set_value(const nb::object& value) {
        if (value.is_none()) {
            invalidate();
            return;
        }
        _value.from_python(value);
        _py_cached_value = value;
        BaseTimeSeriesOutput::mark_modified();
    }

    void TimeSeriesValueOutput::apply_result(const nb::object& value) {
        if (!value.is_valid() || value.is_none()) {
            return;
        }
        try {
            py_set_value(value);
        } catch (std::exception& e) {
            std::string msg = "Cannot apply node output " + to_string(value) +
                              " to TimeSeriesValueOutput: " + e.what();
            throw nb::type_error(msg.c_str());
        }
    }

    void TimeSeriesValueOutput::mark_modified() {
        _py_cached_value = nb::object();
        BaseTimeSeriesOutput::mark_modified();
    }

    void TimeSeriesValueOutput::mark_modified(engine_time_t modified_time) {
        _py_cached_value = nb::object();
        BaseTimeSeriesOutput::mark_modified(modified_time);
    }

    void TimeSeriesValueOutput::mark_invalid() {
        _value = value::Value(schema());  // Reset to typed-null
        _py_cached_value = nb::object();
        BaseTimeSeriesOutput::mark_invalid();
    }

    void TimeSeriesValueOutput::copy_from_output(const TimeSeriesOutput& output) {
        auto* other = dynamic_cast<const TimeSeriesValueOutput*>(&output);
        if (!other) {
            throw std::runtime_error("TimeSeriesValueOutput::copy_from_output: type mismatch");
        }
        if (other->valid()) {
            if (!_value.has_value()) {
                _value.emplace();
            }
            _value.view().copy_from(other->_value.view());
            _py_cached_value = other->_py_cached_value.is_valid() ? other->_py_cached_value : nb::object();
            BaseTimeSeriesOutput::mark_modified();
        } else {
            mark_invalid();
        }
    }

    void TimeSeriesValueOutput::copy_from_input(const TimeSeriesInput& input) {
        auto* other = dynamic_cast<const TimeSeriesValueInput*>(&input);
        if (!other) {
            throw std::runtime_error("TimeSeriesValueOutput::copy_from_input: type mismatch");
        }
        if (other->valid()) {
            if (!_value.has_value()) {
                _value.emplace();
            }
            _value.view().copy_from(other->value());
            const auto& source = other->value_output();
            _py_cached_value = source._py_cached_value.is_valid() ? source._py_cached_value : nb::object();
            BaseTimeSeriesOutput::mark_modified();
        } else {
            mark_invalid();
        }
    }

    bool TimeSeriesValueOutput::is_same_type(const TimeSeriesType* other) const {
        // Single comparison checks both type (Value) and direction (Output)
        if (other->kind() != kind()) { return false; }
        // Kind matches exactly, safe to use static_cast
        auto* ts = static_cast<const TimeSeriesValueOutput*>(other);
        return ts->schema() == schema();
    }

    void TimeSeriesValueOutput::reset_value() {
        _value = value::Value(schema());
        _py_cached_value = nb::object();
    }

    // ============================================================================
    // TimeSeriesValueInput Implementation
    // ============================================================================

    TimeSeriesValueOutput& TimeSeriesValueInput::value_output() {
        return dynamic_cast<TimeSeriesValueOutput&>(*output());
    }

    const TimeSeriesValueOutput& TimeSeriesValueInput::value_output() const {
        return dynamic_cast<const TimeSeriesValueOutput&>(*output());
    }

    value::View TimeSeriesValueInput::value() const {
        return value_output().value();
    }

    const value::TypeMeta* TimeSeriesValueInput::schema() const {
        return value_output().schema();
    }

    bool TimeSeriesValueInput::is_same_type(const TimeSeriesType* other) const {
        // Single comparison checks both type (Value) and direction (Input)
        return other->kind() == kind();
    }

    // ============================================================================
    // Python Bindings
    // ============================================================================

    void register_ts_with_nanobind(nb::module_& m) {
        // TimeSeriesValueOutputBase - intermediate class for visitor pattern
        nb::class_<TimeSeriesValueOutputBase, BaseTimeSeriesOutput>(m, "TimeSeriesValueOutputBase");

        // TimeSeriesValueOutput - created via builders, not directly from Python
        nb::class_<TimeSeriesValueOutput, TimeSeriesValueOutputBase>(m, "TimeSeriesValueOutput")
            .def_prop_ro("schema", &TimeSeriesValueOutput::schema);

        // TimeSeriesValueInputBase - intermediate class for visitor pattern
        nb::class_<TimeSeriesValueInputBase, BaseTimeSeriesInput>(m, "TimeSeriesValueInputBase");

        // TimeSeriesValueInput - created via builders
        nb::class_<TimeSeriesValueInput, TimeSeriesValueInputBase>(m, "TimeSeriesValueInput")
            .def_prop_ro("schema", &TimeSeriesValueInput::schema);
    }

} // namespace hgraph
