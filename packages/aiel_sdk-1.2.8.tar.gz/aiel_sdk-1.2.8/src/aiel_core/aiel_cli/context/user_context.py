from __future__ import annotations
from aiel_sdk.errors import RuntimeDependencyError

try:
    from aiel_cli.context.user_context import UserContext, UserContextData  # type: ignore
except Exception as e:  # pragma: no cover
    raise RuntimeDependencyError("aiel-cli", "pip install 'aiel-sdk[aiel-cli]'") from e

__all__ = ["UserContext", "UserContextData"]
