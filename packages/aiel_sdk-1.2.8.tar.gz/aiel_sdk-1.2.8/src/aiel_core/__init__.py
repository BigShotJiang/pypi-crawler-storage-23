"""
AIEL facade namespace.

Provides stable import paths for curated integrations shipped/guaranteed by runtime bundles.
Example:
  from aiel.langgraph.graph import StateGraph, START, END
  from aiel.aiel_cli.context.user_context import UserContext
"""
__all__ = ["pydantic", "langgraph", "langchain", "langsmith", "aiel_cli"]
