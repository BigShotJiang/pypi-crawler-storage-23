from __future__ import annotations
from .decorators import http_get, http_post

class http:
    get = staticmethod(http_get)
    post = staticmethod(http_post)
