from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

PACKAGE_NAME = "aiel-sdk"

try:
    SDK_VERSION = version(PACKAGE_NAME)
except PackageNotFoundError:
    # Running from source (not installed) or editable edge case
    SDK_VERSION = "0.0.0+dev"