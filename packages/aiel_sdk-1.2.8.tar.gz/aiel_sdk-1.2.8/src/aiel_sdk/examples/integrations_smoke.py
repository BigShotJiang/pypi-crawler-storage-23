from aiel_sdk import IntegrationsClient

client = IntegrationsClient(
    base_url="https://api.example.com",
    api_key="REPLACE_ME",
)

connections = client.list("workspace_id", "project_id")
print("connections", connections)

if connections:
    first = connections[0]
    detail = client.get(first.workspace_id, first.project_id, first.connection_id)
    print("detail", detail)

    # Example: invoke an action (replace action/payload with your provider)
    # result = client.invoke_action(
    #     first.workspace_id,
    #     first.project_id,
    #     first.connection_id,
    #     action="slack.post_message",
    #     payload={"params": {"channel": "#general", "text": "Hello from AIEL SDK"}},
    # )
    # print("action result", result)
