class PriorBase:
    """Base class to facilitate detection of prior types."""
