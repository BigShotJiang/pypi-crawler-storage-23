"""Table plugin initialization."""
