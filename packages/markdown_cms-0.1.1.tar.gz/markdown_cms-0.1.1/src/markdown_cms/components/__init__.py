"""Components module initialization."""
