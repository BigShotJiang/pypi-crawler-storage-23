"""Markdown-First Application Framework."""

__version__ = "0.1.1"
__author__ = "Rakesh Patil"
__email__ = "rakeshpatil1983@gmail.com"
