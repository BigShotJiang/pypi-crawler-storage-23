"""Main entry point for the markdown_cms package."""

from .cli import main

if __name__ == "__main__":
    main()
