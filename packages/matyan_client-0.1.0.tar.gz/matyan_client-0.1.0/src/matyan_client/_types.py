"""Shared type aliases for the matyan client SDK."""

from __future__ import annotations

from typing import Any

AimObject = int | float | str | bool | list | tuple | dict | None

Context = dict[str, Any]
