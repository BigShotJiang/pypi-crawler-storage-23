"""Collect system parameters at run creation time.

Ported from ``aim/aim/ext/utils.py`` — collects installed packages,
environment variables (secrets masked), and git repository info.
"""

from __future__ import annotations

import subprocess
import sys
from os import environ

from loguru import logger


def get_installed_packages() -> dict[str, str]:
    """Return ``{package_name: version}`` for all installed distributions."""
    from importlib.metadata import distributions  # noqa: PLC0415

    return {d.metadata["Name"]: d.metadata["Version"] for d in distributions() if d.metadata["Name"]}


def get_environment_variables() -> dict[str, str]:
    """Return environment variables, excluding keys that look like secrets."""
    mask = ("secret", "key", "token", "password")
    return {k: v for k, v in environ.items() if not any(m in k.lower() for m in mask)}


def get_git_info() -> dict:
    """Return git branch, remote URL and latest commit info."""
    git_info: dict = {}
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],  # noqa: S607
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return git_info

    if r.stdout.decode("utf-8").strip().lower() != "true":
        return git_info

    cmds = {
        "branch": ("git", "rev-parse", "--abbrev-ref", "HEAD"),
        "remote_origin_url": ("git", "config", "--get", "remote.origin.url"),
        "commit": ("git", "log", "--pretty=format:%h/%ad/%an", "--date=iso-strict", "-1"),
    }
    results: dict[str, str] = {}
    for key, cmd in cmds.items():
        try:
            r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)  # noqa: S603
        except subprocess.CalledProcessError:
            continue
        results[key] = r.stdout.decode("utf-8").strip()

    try:
        commit_hash, commit_timestamp, commit_author = results["commit"].split("/")
    except (ValueError, KeyError):
        commit_hash = commit_timestamp = commit_author = None

    git_info.update(
        {
            "branch": results.get("branch"),
            "remote_origin_url": results.get("remote_origin_url"),
            "commit": {"hash": commit_hash, "timestamp": commit_timestamp, "author": commit_author},
        },
    )
    return git_info


def collect_system_params() -> dict:
    """Gather all system parameters into a single dict."""
    result: dict = {
        "executable": sys.executable,
        "arguments": sys.argv,
    }
    try:
        result["packages"] = get_installed_packages()
    except Exception:  # noqa: BLE001
        logger.debug("Failed to collect installed packages")
        result["packages"] = {}
    try:
        result["env_variables"] = get_environment_variables()
    except Exception:  # noqa: BLE001
        logger.debug("Failed to collect environment variables")
        result["env_variables"] = {}
    try:
        result["git_info"] = get_git_info()
    except Exception:  # noqa: BLE001
        logger.debug("Failed to collect git info")
        result["git_info"] = {}
    return result
