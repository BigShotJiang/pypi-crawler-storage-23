from __future__ import annotations

import base64
import io
from pathlib import Path
from typing import TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:
    from types import ModuleType

    import numpy as np

    AudioInput = bytes | str | Path | io.IOBase | np.ndarray


class Audio:
    """A tracked audio value.

    Accepts file path, raw bytes, io stream, or numpy array (WAV).

    Usage::

        run.track(Audio("recording.wav", caption="sample"), name="audio", step=0)
    """

    def __init__(
        self,
        data: AudioInput,
        format_: str = "",
        caption: str = "",
        rate: int | None = None,
    ) -> None:
        self._caption = caption
        self._rate = rate
        self._format = format_
        self._data_bytes = self._encode(data)

    def _encode(self, data: AudioInput) -> bytes:
        if isinstance(data, bytes):
            return data

        if isinstance(data, (str, Path)):
            p = Path(data)
            if not self._format:
                self._format = p.suffix.lstrip(".")
            return p.read_bytes()

        if isinstance(data, io.IOBase):
            return data.read()

        np: ModuleType | None = None

        try:
            import numpy as np  # noqa: PLC0415
        except ImportError:
            logger.debug("numpy unavailable; audio tracking disabled")

        if np is not None and isinstance(data, np.ndarray):
            return self._numpy_to_wav(data)

        msg = f"Unsupported audio type: {type(data).__name__}"
        raise TypeError(msg)

    def _numpy_to_wav(self, arr: np.ndarray) -> bytes:
        import struct  # noqa: PLC0415

        import numpy as np  # noqa: PLC0415

        self._format = "wav"
        rate = self._rate or 22050
        if arr.dtype != np.int16:
            peak = np.abs(arr).max()
            arr = (arr / peak * 32767).astype(np.int16) if peak > 0 else arr.astype(np.int16)

        buf = io.BytesIO()
        num_channels = 1 if arr.ndim == 1 else arr.shape[1]
        data_bytes = arr.tobytes()
        byte_rate = rate * num_channels * 2
        block_align = num_channels * 2
        data_size = len(data_bytes)

        buf.write(b"RIFF")
        buf.write(struct.pack("<I", 36 + data_size))
        buf.write(b"WAVE")
        buf.write(b"fmt ")
        buf.write(struct.pack("<IHHIIHH", 16, 1, num_channels, rate, byte_rate, block_align, 16))
        buf.write(b"data")
        buf.write(struct.pack("<I", data_size))
        buf.write(data_bytes)
        return buf.getvalue()

    @property
    def caption(self) -> str:
        return self._caption

    @property
    def format(self) -> str:
        return self._format

    def json(self) -> dict:
        return {
            "type": "audio",
            "data": base64.b64encode(self._data_bytes).decode(),
            "format": self._format,
            "caption": self._caption,
            "rate": self._rate,
        }

    def __repr__(self) -> str:
        return f"Audio(format={self._format!r}, size={len(self._data_bytes)}, caption={self._caption!r})"
