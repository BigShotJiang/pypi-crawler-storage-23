from __future__ import annotations


class Text:
    """A tracked text value.

    Usage::

        run.track(Text("prediction: cat"), name="predictions", step=0)
    """

    def __init__(self, text: str) -> None:
        self._data = str(text)

    @property
    def data(self) -> str:
        return self._data

    def json(self) -> dict:
        return {"type": "text", "data": self._data}

    def __repr__(self) -> str:
        snippet = self._data[:60] + "..." if len(self._data) > 60 else self._data
        return f"Text({snippet!r})"
