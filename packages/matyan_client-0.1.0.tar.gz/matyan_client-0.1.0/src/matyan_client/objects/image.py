from __future__ import annotations

import base64
import io
from pathlib import Path
from typing import TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:
    from types import ModuleType

    import numpy as np
    import PIL.Image as PILImage

    ImageInput = bytes | str | Path | PILImage.Image | np.ndarray


class Image:
    """A tracked image value.

    Accepts PIL Image, numpy array, file path (str/Path), or raw bytes.

    Usage::

        run.track(Image(pil_img, caption="epoch 5"), name="samples", step=5)
    """

    def __init__(
        self,
        image: ImageInput,
        caption: str = "",
        format_: str | None = None,
        quality: int = 90,
        optimize: bool = False,
    ) -> None:
        self._caption = caption
        self._format = format_ or "PNG"
        self._width: int | None = None
        self._height: int | None = None
        self._data_bytes = self._encode(image, quality, optimize)

    def _encode(self, image: ImageInput, quality: int, optimize: bool) -> bytes:
        if isinstance(image, bytes):
            return image

        if isinstance(image, (str, Path)):
            return Path(image).read_bytes()

        PILImage: type | None = None  # noqa: N806

        try:
            import PIL.Image as PILImage  # noqa: PLC0415
        except ImportError:
            logger.debug("PIL.Image unavailable; image tracking disabled")

        if PILImage is not None and isinstance(image, PILImage.Image):
            self._width, self._height = image.size
            buf = io.BytesIO()
            image.save(buf, format=self._format, quality=quality, optimize=optimize)
            return buf.getvalue()

        np: ModuleType | None = None

        try:
            import numpy as np  # noqa: PLC0415
        except ImportError:
            logger.debug("numpy unavailable; image tracking disabled")

        if np is not None and isinstance(image, np.ndarray):
            if PILImage is None:
                msg = "Pillow is required to track numpy array images"
                raise ImportError(msg)
            pil_img = PILImage.fromarray(image)
            self._width, self._height = pil_img.size
            buf = io.BytesIO()
            pil_img.save(buf, format=self._format, quality=quality, optimize=optimize)
            return buf.getvalue()

        msg = f"Unsupported image type: {type(image).__name__}"
        raise TypeError(msg)

    @property
    def caption(self) -> str:
        return self._caption

    @property
    def format(self) -> str:
        return self._format

    @property
    def width(self) -> int | None:
        return self._width

    @property
    def height(self) -> int | None:
        return self._height

    @property
    def size(self) -> int:
        return len(self._data_bytes)

    def json(self) -> dict:
        return {
            "type": "image",
            "data": base64.b64encode(self._data_bytes).decode(),
            "format": self._format,
            "caption": self._caption,
            "width": self._width,
            "height": self._height,
        }

    def __repr__(self) -> str:
        return f"Image(format={self._format!r}, size={self.size}, caption={self._caption!r})"
