from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from types import ModuleType


class Figure:
    """A tracked figure value (plotly or matplotlib).

    Usage::

        import plotly.express as px
        fig = px.scatter(df, x="x", y="y")
        run.track(Figure(fig), name="scatter", step=0)
    """

    def __init__(self, obj: Any) -> None:  # noqa: ANN401
        self._data = self._serialize(obj)

    @staticmethod
    def _serialize(obj: Any) -> dict:  # noqa: ANN401
        go: ModuleType | None = None
        try:
            import plotly.graph_objects as go  # noqa: PLC0415
        except ImportError:
            logger.debug("plotly.graph_objects unavailable; figure tracking disabled")

        if go is not None and isinstance(obj, go.Figure):
            return json.loads(obj.to_json())

        matplotlib: ModuleType | None = None

        try:
            import matplotlib.figure  # noqa: F401, PLC0415  # pyright: ignore[reportMissingImports]
        except ImportError:
            logger.debug("matplotlib.figure unavailable; figure tracking disabled")

        if hasattr(obj, "savefig"):
            try:
                import plotly.tools  # noqa: PLC0415

                plotly_fig = plotly.tools.mpl_to_plotly(obj)
                return json.loads(plotly_fig.to_json())
            except (ImportError, ValueError, TypeError):
                logger.debug("matplotlib-to-plotly conversion failed, trying dict fallback")

        if isinstance(obj, dict):
            return obj

        msg = f"Unsupported figure type: {type(obj).__name__}. Pass a plotly Figure, matplotlib Figure, or dict."
        raise TypeError(msg)

    @property
    def data(self) -> dict:
        return self._data

    def json(self) -> dict:
        return {"type": "figure", "data": self._data}

    def __repr__(self) -> str:
        return f"Figure(keys={list(self._data.keys())!r})"
