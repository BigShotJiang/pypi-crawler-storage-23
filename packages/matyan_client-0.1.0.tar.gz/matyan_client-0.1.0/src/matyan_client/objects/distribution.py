from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence

_MAX_BIN_COUNT = 512


class Distribution:
    """A tracked distribution value.

    Can be created from raw samples or from a pre-computed histogram.

    Usage::

        run.track(Distribution(samples), name="weights", step=0)
        run.track(Distribution.from_histogram(hist, bin_range), name="grads")
    """

    def __init__(
        self,
        samples: Sequence[float | int] | None = None,
        bin_count: int = 64,
        *,
        hist: Sequence[float | int] | None = None,
        bin_range: tuple[float, float] | None = None,
    ) -> None:
        if hist is not None and bin_range is not None:
            self._weights = _to_list(hist)
            self._bin_count = len(self._weights)
            self._range = tuple(bin_range)
        elif samples is not None:
            self._from_samples(samples, min(bin_count, _MAX_BIN_COUNT))
        else:
            msg = "Provide either `samples` or both `hist` and `bin_range`"
            raise ValueError(msg)

    def _from_samples(self, samples: Sequence[float | int], bin_count: int) -> None:
        try:
            import numpy as np  # noqa: PLC0415
        except ImportError:
            flat = list(samples)
            lo, hi = min(flat), max(flat)
            self._range = (float(lo), float(hi))
            self._bin_count = bin_count
            width = (hi - lo) / bin_count if hi != lo else 1.0
            counts = [0] * bin_count
            for v in flat:
                idx = min(int((v - lo) / width), bin_count - 1)
                counts[idx] += 1
            self._weights = counts
            return

        arr = np.asarray(samples).ravel()
        hist, edges = np.histogram(arr, bins=bin_count)
        self._weights = hist.tolist()
        self._range = (float(edges[0]), float(edges[-1]))
        self._bin_count = bin_count

    @classmethod
    def from_histogram(cls, hist: Sequence[float | int], bin_range: tuple[float, float]) -> Distribution:
        return cls(hist=hist, bin_range=bin_range)

    @classmethod
    def from_samples(cls, samples: Sequence[float | int], bin_count: int = 64) -> Distribution:
        return cls(samples=samples, bin_count=bin_count)

    @property
    def bin_count(self) -> int:
        return self._bin_count

    @property
    def range(self) -> tuple[float, float]:
        return self._range

    @property
    def weights(self) -> list[float | int]:
        return self._weights

    def json(self) -> dict:
        return {
            "type": "distribution",
            "bin_count": self._bin_count,
            "range": list(self._range),
            "data": self._weights,
        }

    def __repr__(self) -> str:
        return f"Distribution(bins={self._bin_count}, range={self._range})"


def _to_list(obj: Sequence[float | int]) -> list[float | int]:
    to_list = getattr(obj, "tolist", None)
    if to_list is not None:
        return to_list()
    return list(obj)
