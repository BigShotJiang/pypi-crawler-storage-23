"""WebSocket transport for streaming data to the frontier service.

Runs a persistent WebSocket connection in a background daemon thread with
its own asyncio event loop.  The public API is fully synchronous — callers
enqueue messages via ``send()`` and the background loop drains the queue.

Robustness features:
- Memory-bounded queue with backpressure (blocks ``send()`` when full)
- Message batching (time + count triggers, sent as JSON array)
- Retry on send failure (configurable count, re-enqueue at front)
- Heartbeat via last-ack staleness detection → force reconnect
- Graceful close with ``wait_for_flush()`` and drain reporting
- ``connected`` property + reliable startup handshake detection
"""

from __future__ import annotations

import asyncio
import collections
import json
import sys
import threading
import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

import websockets
from loguru import logger

from matyan_client.config import SETTINGS

if TYPE_CHECKING:
    from websockets.asyncio.client import ClientConnection

_SENTINEL = object()


class WsTransport:
    """One WebSocket connection to ``frontier /api/v1/ws/runs/{run_id}``."""

    def __init__(self, frontier_url: str, run_id: str) -> None:
        ws_base = frontier_url.replace("http://", "ws://").replace("https://", "wss://")
        self._url = f"{ws_base}/api/v1/ws/runs/{run_id}"
        self._run_id = run_id

        self._max_memory = SETTINGS.ws_queue_max_memory_mb * 1024 * 1024
        self._batch_size = SETTINGS.ws_batch_size
        self._batch_interval = SETTINGS.ws_batch_interval_ms / 1000.0
        self._retry_count = SETTINGS.ws_retry_count
        self._heartbeat_interval = SETTINGS.ws_heartbeat_interval

        self._deque: collections.deque[dict] = collections.deque()
        self._memory_usage = 0
        self._lock = threading.Lock()
        self._not_full = threading.Condition(self._lock)
        self._not_empty = threading.Condition(self._lock)
        self._flushed = threading.Event()
        self._flushed.set()

        self._connected_event = threading.Event()
        self._closed = threading.Event()
        self._connect_error: str | None = None

        self._sent_count = 0
        self._dropped_count = 0

        self._thread = threading.Thread(
            target=self._run_loop,
            daemon=True,
            name=f"ws-{run_id[:8]}",
        )
        self._thread.start()

        if not self._connected_event.wait(timeout=15):
            if self._connect_error:
                logger.error(
                    "WS connection failed for run {}: {}",
                    self._run_id,
                    self._connect_error,
                )
            else:
                logger.warning(
                    "WS connection timeout for run {} (will retry in background)",
                    self._run_id,
                )

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def connected(self) -> bool:
        return self._connected_event.is_set() and not self._closed.is_set()

    @property
    def pending(self) -> int:
        with self._lock:
            return len(self._deque)

    @property
    def stats(self) -> dict[str, int]:
        return {
            "sent": self._sent_count,
            "dropped": self._dropped_count,
            "pending": self.pending,
        }

    # ------------------------------------------------------------------
    # Public send API (called from main thread)
    # ------------------------------------------------------------------

    def send(self, message: dict) -> None:
        """Enqueue a JSON message.  Blocks if memory limit is reached."""
        if self._closed.is_set():
            logger.warning("WS transport already closed for run {}", self._run_id)
            return
        msg_size = _estimate_size(message)
        with self._not_full:
            while self._memory_usage + msg_size > self._max_memory:
                if self._closed.is_set():
                    return
                self._not_full.wait(timeout=1.0)
            self._deque.append(message)
            self._memory_usage += msg_size
            self._flushed.clear()
            self._not_empty.notify()

    def send_create_run(self, *, force_resume: bool = False) -> None:
        self.send(
            {
                "type": "create_run",
                "run_id": self._run_id,
                "client_datetime": datetime.now(timezone.utc).isoformat(),
                "force_resume": force_resume,
            },
        )

    def send_log_metric(
        self,
        name: str,
        value: float,
        step: int | None = None,
        epoch: int | None = None,
        context: dict | None = None,
        dtype: str | None = None,
    ) -> None:
        self.send(
            {
                "type": "log_metric",
                "run_id": self._run_id,
                "name": name,
                "value": value,
                "step": step,
                "epoch": epoch,
                "context": context,
                "dtype": dtype or "float",
                "client_datetime": datetime.now(timezone.utc).isoformat(),
            },
        )

    def send_log_hparams(self, value: dict) -> None:
        self.send(
            {
                "type": "log_hparams",
                "run_id": self._run_id,
                "value": value,
            },
        )

    def send_set_run_property(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
        archived: bool | None = None,
        experiment: str | None = None,
    ) -> None:
        msg: dict[str, Any] = {"type": "set_run_property", "run_id": self._run_id}
        if name is not None:
            msg["name"] = name
        if description is not None:
            msg["description"] = description
        if archived is not None:
            msg["archived"] = archived
        if experiment is not None:
            msg["experiment"] = experiment
        self.send(msg)

    def send_add_tag(self, tag_name: str) -> None:
        self.send({"type": "add_tag", "run_id": self._run_id, "tag_name": tag_name})

    def send_remove_tag(self, tag_name: str) -> None:
        self.send({"type": "remove_tag", "run_id": self._run_id, "tag_name": tag_name})

    def send_log_custom_object(
        self,
        name: str,
        value: dict,
        step: int | None = None,
        epoch: int | None = None,
        context: dict | None = None,
        dtype: str = "custom",
    ) -> None:
        self.send(
            {
                "type": "log_custom_object",
                "run_id": self._run_id,
                "name": name,
                "value": value,
                "step": step,
                "epoch": epoch,
                "context": context,
                "dtype": dtype,
                "client_datetime": datetime.now(timezone.utc).isoformat(),
            },
        )

    def send_log_terminal_line(self, line: str, step: int) -> None:
        self.send({"type": "log_terminal_line", "run_id": self._run_id, "line": line, "step": step})

    def send_log_record(
        self,
        message: str,
        level: int,
        timestamp: float,
        logger_info: list | None = None,
        extra_args: dict | None = None,
    ) -> None:
        msg: dict = {
            "type": "log_record",
            "run_id": self._run_id,
            "message": message,
            "level": level,
            "timestamp": timestamp,
        }
        if logger_info is not None:
            msg["logger_info"] = logger_info
        if extra_args is not None:
            msg["extra_args"] = extra_args
        self.send(msg)

    def send_finish_run(self) -> None:
        self.send(
            {
                "type": "finish_run",
                "run_id": self._run_id,
                "client_datetime": datetime.now(timezone.utc).isoformat(),
            }
        )

    # ------------------------------------------------------------------
    # Close / flush
    # ------------------------------------------------------------------

    def wait_for_flush(self, timeout: float = 30.0) -> bool:
        """Block until all queued messages have been sent.

        Returns True if the queue was fully drained within *timeout* seconds.
        """
        return self._flushed.wait(timeout=timeout)

    def close(self, timeout: float = 10.0) -> None:
        """Drain remaining messages and shut down the background thread."""
        if self._closed.is_set():
            return

        if not self._flushed.wait(timeout=max(timeout - 2, 1)):
            with self._lock:
                remaining = len(self._deque)
            if remaining:
                logger.warning(
                    "WS close for run {}: {} message(s) still pending, may be lost",
                    self._run_id,
                    remaining,
                )

        with self._not_empty:
            self._deque.append(_SENTINEL)  # type: ignore[arg-type]
            self._not_empty.notify()
        self._closed.set()

        with self._not_full:
            self._not_full.notify_all()

        self._thread.join(timeout=3.0)

        stats = self.stats
        logger.debug(
            "WS transport closed for run {}: sent={}, dropped={}, pending={}",
            self._run_id,
            stats["sent"],
            stats["dropped"],
            stats["pending"],
        )

    # ------------------------------------------------------------------
    # Internal queue helpers
    # ------------------------------------------------------------------

    def _take_batch(self) -> list[dict]:
        """Collect up to ``_batch_size`` messages, waiting up to
        ``_batch_interval`` seconds for the batch to fill.
        """
        batch: list[dict] = []
        deadline = time.monotonic() + self._batch_interval
        freed = 0

        with self._not_empty:
            while not self._deque:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                self._not_empty.wait(timeout=remaining)

            while self._deque and len(batch) < self._batch_size:
                item = self._deque.popleft()
                if item is _SENTINEL:
                    batch.append(item)
                    break
                freed += _estimate_size(item)
                batch.append(item)

            self._memory_usage = max(0, self._memory_usage - freed)
            if freed:
                self._not_full.notify_all()
            if not self._deque:
                self._flushed.set()

        return batch

    # ------------------------------------------------------------------
    # Background thread
    # ------------------------------------------------------------------

    def _run_loop(self) -> None:
        try:
            asyncio.run(self._async_loop())
        except RuntimeError as e:
            err_msg = str(e)
            if "cannot schedule new futures" in err_msg and "shutdown" in err_msg:
                logger.debug(
                    "WS transport loop for run {} stopped during process shutdown",
                    self._run_id,
                )
            else:
                logger.exception("WS transport loop crashed for run {}", self._run_id)
        except Exception:  # noqa: BLE001
            logger.exception("WS transport loop crashed for run {}", self._run_id)

    async def _async_loop(self) -> None:
        # websockets 13+ moved connect to websockets.asyncio.client;
        # fall back to the legacy path for websockets 12 and earlier.
        try:
            from websockets.asyncio.client import connect  # noqa: PLC0415
        except ImportError:
            from websockets.client import connect  # noqa: PLC0415  # ty:ignore[unresolved-import]

        try:
            async for ws in connect(self._url, ping_interval=self._heartbeat_interval):
                self._connected_event.set()
                self._connect_error = None
                try:
                    await self._drain(ws)
                except (ConnectionError, websockets.ConnectionClosed):
                    logger.warning(
                        "WS connection lost for run {}, reconnecting…",
                        self._run_id,
                    )
                    continue
                else:
                    return
        except (OSError, websockets.WebSocketException) as exc:
            self._connect_error = str(exc)
            self._connected_event.set()
            logger.exception("WS connect failed for run {}", self._run_id)

    async def _drain(self, ws: ClientConnection) -> None:
        loop = asyncio.get_running_loop()
        last_ack = time.monotonic()

        while True:
            batch = await loop.run_in_executor(None, self._take_batch)
            if not batch:
                continue

            has_sentinel = batch[-1] is _SENTINEL
            real_msgs = [m for m in batch if m is not _SENTINEL]

            if real_msgs:
                await self._send_with_retry(ws, real_msgs)
                last_ack = time.monotonic()

            if has_sentinel:
                return

            if time.monotonic() - last_ack > self._heartbeat_interval * 3:
                msg = "No ack received for too long, forcing reconnect"
                raise ConnectionError(msg)

    async def _send_with_retry(
        self,
        ws: ClientConnection,
        messages: list[dict],
    ) -> None:
        """Send a batch of messages as a JSON array, retrying on failure."""
        payload = json.dumps(messages) if len(messages) > 1 else json.dumps(messages[0])
        max_attempts = 1 + self._retry_count
        last_err = await self._attempt_send(ws, payload, messages, max_attempts)
        if last_err is not None:
            self._dropped_count += len(messages)
            logger.error(
                "WS send failed after {} retries for run {}, dropping {} message(s)",
                self._retry_count,
                self._run_id,
                len(messages),
            )
            raise last_err

    async def _attempt_send(
        self,
        ws: ClientConnection,
        payload: str,
        messages: list[dict],
        max_attempts: int,
    ) -> Exception | None:
        for attempt in range(max_attempts):
            try:
                await ws.send(payload)
                raw_resp = await asyncio.wait_for(ws.recv(), timeout=15)
                resp = json.loads(raw_resp)
                if resp.get("status") != "ok":
                    logger.warning(
                        "WS error for run {}: {}",
                        self._run_id,
                        resp.get("error"),
                    )
                self._sent_count += len(messages)
            except (ConnectionError, websockets.ConnectionClosed, asyncio.TimeoutError) as exc:  # noqa: PERF203
                if attempt < max_attempts - 1:
                    logger.debug(
                        "WS send retry {}/{} for run {}",
                        attempt + 1,
                        self._retry_count,
                        self._run_id,
                    )
                    await asyncio.sleep(0.1 * (attempt + 1))
                    continue
                return exc
            else:
                return None
        return None


def _estimate_size(msg: dict) -> int:
    """Rough byte-size estimate of a message dict for memory tracking."""
    return sys.getsizeof(msg) + sum(sys.getsizeof(k) + sys.getsizeof(v) for k, v in msg.items())
