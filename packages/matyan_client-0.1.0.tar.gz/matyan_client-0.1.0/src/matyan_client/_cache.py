"""Client-side write cache for read-after-write consistency.

All writes (track, __setitem__, property setters) are stored locally so
that subsequent reads return the latest value even though ingestion to
FoundationDB is asynchronous.
"""

from __future__ import annotations

import threading
from typing import Any


class WriteCache:
    """Thread-safe in-memory cache keyed by ``(run_hash, dotted_path)``."""

    def __init__(self) -> None:
        self._data: dict[tuple[str, str], Any] = {}
        self._lock = threading.Lock()

    def set(self, run_hash: str, path: str, value: Any) -> None:  # noqa: ANN401
        with self._lock:
            self._data[(run_hash, path)] = value

    def get(self, run_hash: str, path: str, default: Any = None) -> Any:  # noqa: ANN401
        with self._lock:
            return self._data.get((run_hash, path), default)

    def has(self, run_hash: str, path: str) -> bool:
        with self._lock:
            return (run_hash, path) in self._data

    def get_tree(self, run_hash: str) -> dict[str, Any]:
        """Return all cached key-value pairs for *run_hash* as a flat dict."""
        with self._lock:
            return {path: val for (rh, path), val in self._data.items() if rh == run_hash}

    def clear(self, run_hash: str | None = None) -> None:
        with self._lock:
            if run_hash is None:
                self._data.clear()
            else:
                self._data = {k: v for k, v in self._data.items() if k[0] != run_hash}
