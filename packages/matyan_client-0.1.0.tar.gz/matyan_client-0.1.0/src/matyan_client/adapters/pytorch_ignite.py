"""PyTorch Ignite logger and handlers for tracking metrics with Matyan."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL

if TYPE_CHECKING:
    from collections.abc import Callable

    from ignite.engine import Engine, Events
    from torch.optim import Optimizer


try:
    from ignite.contrib.handlers.base_logger import (
        BaseLogger,
        BaseOptimizerParamsHandler,
        BaseOutputHandler,
    )
    from omegaconf import Container, OmegaConf

except ImportError as _exc:
    msg = "This adapter requires PyTorch Ignite and Omegaconf. Install with: pip install pytorch-ignite omegaconf"
    raise RuntimeError(msg) from _exc


class AimLogger(BaseLogger):
    """Aim-compatible logger for PyTorch Ignite."""

    def __init__(
        self,
        repo: str | None = None,
        experiment: str | None = None,
        train_metric_prefix: str | None = "train_",
        val_metric_prefix: str | None = "val_",
        test_metric_prefix: str | None = "test_",
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
    ) -> None:
        super().__init__()

        self._experiment_name = experiment
        self._repo_path = repo

        self._train_metric_prefix = train_metric_prefix
        self._val_metric_prefix = val_metric_prefix
        self._test_metric_prefix = test_metric_prefix
        self._system_tracking_interval = system_tracking_interval
        self._log_system_params = log_system_params
        self._capture_terminal_logs = capture_terminal_logs

        self._run: Run | None = None
        self._run_hash: str | None = None

    @property
    def experiment(self) -> Run:
        if self._run is None:
            if self._run_hash:
                self._run = Run(
                    self._run_hash,
                    repo=self._repo_path,
                    system_tracking_interval=self._system_tracking_interval,
                    capture_terminal_logs=self._capture_terminal_logs,
                )
            else:
                self._run = Run(
                    repo=self._repo_path,
                    experiment=self._experiment_name,
                    system_tracking_interval=self._system_tracking_interval,
                    log_system_params=self._log_system_params,
                    capture_terminal_logs=self._capture_terminal_logs,
                )
                self._run_hash = self._run.hash
        return self._run

    def log_params(self, params: dict[str, Any]) -> None:
        if isinstance(params, Container):
            params = cast("dict[str, Any]", OmegaConf.to_container(params, resolve=True))

        for key, value in params.items():
            self.experiment[f"hparams.{key}"] = value

    def log_metrics(self, metrics: dict[str, float], step: int | None = None) -> None:
        for k, v in metrics.items():
            name = k
            context: dict[str, str] = {}
            if self._train_metric_prefix and name.startswith(self._train_metric_prefix):
                name = name[len(self._train_metric_prefix) :]
                context["subset"] = "train"
            elif self._test_metric_prefix and name.startswith(self._test_metric_prefix):
                name = name[len(self._test_metric_prefix) :]
                context["subset"] = "test"
            elif self._val_metric_prefix and name.startswith(self._val_metric_prefix):
                name = name[len(self._val_metric_prefix) :]
                context["subset"] = "val"
            self.experiment.track(v, step=step, name=name, context=context)

    @property
    def name(self) -> str | None:
        return self._experiment_name

    @property
    def version(self) -> str:
        return self.experiment.hash

    def close(self) -> None:
        if self._run:
            self._run.close()
            self._run = None

    def __del__(self) -> None:
        self.close()

    def _create_output_handler(self, *args: Any, **kwargs: Any) -> OutputHandler:  # noqa: ANN401
        return OutputHandler(*args, **kwargs)

    def _create_opt_params_handler(self, *args: Any, **kwargs: Any) -> OptimizerParamsHandler:  # noqa: ANN401
        return OptimizerParamsHandler(*args, **kwargs)


class OutputHandler(BaseOutputHandler):
    """Log engine output and/or metrics to Matyan via :class:`AimLogger`."""

    def __init__(
        self,
        tag: str,
        metric_names: str | list[str] | None = None,
        output_transform: Callable | None = None,
        global_step_transform: Callable | None = None,
        state_attributes: list[str] | None = None,
    ) -> None:
        super().__init__(tag, metric_names, output_transform, global_step_transform, state_attributes)

    def __call__(self, engine: Engine, logger: AimLogger, event_name: str | Events) -> None:
        if not isinstance(logger, AimLogger):
            msg = "OutputHandler works only with AimLogger"
            raise TypeError(msg)

        rendered_metrics = self._setup_output_metrics_state_attrs(engine)
        global_step = self.global_step_transform(engine, event_name)
        if not isinstance(global_step, int):
            msg = f"global_step must be int, got {type(global_step)}."
            raise TypeError(msg)

        metrics: dict[str, Any] = {}
        for keys, value in rendered_metrics.items():
            metrics["_".join(keys)] = value

        logger.log_metrics(metrics, step=global_step)


class OptimizerParamsHandler(BaseOptimizerParamsHandler):
    """Log optimizer parameter groups to Matyan via :class:`AimLogger`."""

    def __init__(
        self,
        optimizer: Optimizer,
        param_name: str = "lr",
        tag: str | None = None,
    ) -> None:
        super().__init__(optimizer, param_name, tag)

    def __call__(self, engine: Engine, logger: AimLogger, event_name: str | Events) -> None:
        if not isinstance(logger, AimLogger):
            msg = "OptimizerParamsHandler works only with AimLogger"
            raise TypeError(msg)

        global_step = engine.state.get_event_attrib_value(event_name)
        tag_prefix = f"{self.tag}_" if self.tag else ""
        params = {
            f"{tag_prefix}{self.param_name}_group_{i}": float(pg[self.param_name])
            for i, pg in enumerate(self.optimizer.param_groups)
        }
        logger.log_metrics(params, step=global_step)
