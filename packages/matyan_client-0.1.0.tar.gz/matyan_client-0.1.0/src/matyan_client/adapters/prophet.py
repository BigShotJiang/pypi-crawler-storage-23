"""Prophet logger that captures hyperparameters and user-provided metrics."""

from __future__ import annotations

import json
from typing import Any

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL


def _json_safe(value: Any) -> Any:  # noqa: ANN401
    """Return a JSON-serializable version of value for WebSocket payloads."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    try:
        json.dumps(value)
    except (TypeError, ValueError):
        return str(value)
    else:
        return value


class AimLogger:
    """Logger for Facebook Prophet models.

    Prophet does not have a callback system and is not trained iteratively,
    so only hyperparameters and user-provided metrics are logged.
    """

    def __init__(
        self,
        prophet_model: Any,  # noqa: ANN401
        repo: str | None = None,
        experiment: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
    ) -> None:
        self._repo_path = repo
        self._experiment = experiment
        self._system_tracking_interval = system_tracking_interval
        self._log_system_params = log_system_params
        self._capture_terminal_logs = capture_terminal_logs
        self._run: Run | None = None
        self._run_hash: str | None = None
        self.setup(prophet_model.__dict__)

    @property
    def experiment(self) -> Run:
        if not self._run:
            self.setup({})
        assert self._run is not None
        return self._run

    def setup(self, hparams: dict[str, Any]) -> None:
        if self._run:
            return
        if self._run_hash:
            self._run = Run(
                self._run_hash,
                repo=self._repo_path,
                system_tracking_interval=self._system_tracking_interval,
                capture_terminal_logs=self._capture_terminal_logs,
            )
        else:
            self._run = Run(
                repo=self._repo_path,
                experiment=self._experiment,
                system_tracking_interval=self._system_tracking_interval,
                log_system_params=self._log_system_params,
                capture_terminal_logs=self._capture_terminal_logs,
            )
            self._run_hash = self._run.hash

        for key, value in hparams.items():
            self._run[key] = _json_safe(value)

    def track_metrics(
        self,
        metrics: dict[str, float],
        context: dict[str, Any] | None = None,
    ) -> None:
        """Log user-provided metrics (Prophet has no built-in loss callback)."""
        if context is None:
            context = {"subset": "val"}
        run = self._run
        assert run is not None
        for name, value in metrics.items():
            run.track(value, name=name, context=context)

    def __del__(self) -> None:
        if self._run is not None:
            self._run.close()
