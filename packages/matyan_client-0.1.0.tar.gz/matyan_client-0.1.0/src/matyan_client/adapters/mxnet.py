"""MXNet Gluon Estimator logging handler that tracks metrics to Matyan."""

from __future__ import annotations

import time
from typing import Any

from loguru import logger as _logger
from typing_extensions import override

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL

try:
    import numpy as np
    from mxnet.gluon.contrib.estimator import (
        BatchBegin,
        BatchEnd,
        EpochBegin,
        EpochEnd,
        Estimator,
        TrainBegin,
        TrainEnd,
    )
    from mxnet.gluon.contrib.estimator.utils import _check_metrics
except ImportError as _exc:
    msg = "This adapter requires MXNet. Install with: pip install mxnet"
    raise RuntimeError(msg) from _exc


class AimLoggingHandler(TrainBegin, TrainEnd, EpochBegin, EpochEnd, BatchBegin, BatchEnd):
    """Tracks hyper-parameters, training statistics, and metrics per epoch/batch."""

    def __init__(
        self,
        log_interval: int | str = "epoch",
        repo: str | None = None,
        experiment_name: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
        metrics: list[Any] | None = None,
        priority: float = np.inf,
    ) -> None:
        super().__init__()
        if not isinstance(log_interval, int) and log_interval != "epoch":
            msg = "log_interval must be an integer or 'epoch'"
            raise ValueError(msg)

        self.metrics = _check_metrics(metrics)
        self.batch_index = 0
        self.current_epoch = 0
        self.processed_samples = 0
        self.priority = priority
        self.log_interval: int | str = log_interval
        self.log_interval_time: float = 0.0

        self.repo = repo
        self.experiment_name = experiment_name
        self.system_tracking_interval = system_tracking_interval
        self.log_system_params = log_system_params
        self.capture_terminal_logs = capture_terminal_logs
        self._run: Run | None = None
        self._run_hash: str | None = None

        self.train_start: float = 0.0
        self.epoch_start: float = 0.0
        self.batch_start: float = 0.0

    # ------------------------------------------------------------------
    # Estimator hooks
    # ------------------------------------------------------------------

    @override
    def train_begin(self, estimator: Estimator | None, *args: Any, **kwargs: Any) -> None:
        if estimator is None:
            return
        self.train_start = time.time()
        trainer = estimator.trainer
        optimizer = trainer.optimizer.__class__.__name__
        lr = trainer.learning_rate

        logger = estimator.logger
        assert logger is not None
        logger.info("Training begin: optimizer=%s  lr=%.4f", optimizer, lr)
        if estimator.max_epoch:
            logger.info("Train for %d epochs.", estimator.max_epoch)
        else:
            logger.info("Train for %d batches.", estimator.max_batch)

        self.current_epoch = 0
        self.batch_index = 0
        self.processed_samples = 0
        self.log_interval_time = 0.0

        params = {
            "arch": estimator.net.name,
            "loss": estimator.loss.name,
            "optimizer": optimizer,
            "lr": lr,
            "max_epoch": estimator.max_epoch,
            "max_batch": estimator.max_batch,
        }
        self.setup(estimator, params)

    @override
    def train_end(self, estimator: Estimator | None, *args: Any, **kwargs: Any) -> None:
        if estimator is None:
            return
        elapsed = time.time() - self.train_start
        msg = f"Train finished in {elapsed:.0f}s ({self.current_epoch} epochs). "
        for m in self.metrics:
            name, value = m.get()
            msg += f"{name}: {value:.4f}, "
        logger = estimator.logger
        assert logger is not None
        logger.info(msg.rstrip(", "))

    @override
    def epoch_begin(self, estimator: Estimator | None, *args: Any, **kwargs: Any) -> None:
        if estimator is None:
            return
        if isinstance(self.log_interval, int) or self.log_interval == "epoch":
            self.epoch_start = time.time()
            logger = estimator.logger
            assert logger is not None
            is_training = any("training" in m.name for m in self.metrics)
            if is_training:
                logger.info("[Epoch %d] Begin, lr=%.4f", self.current_epoch, estimator.trainer.learning_rate)
            else:
                logger.info("Validation Begin")

    @override
    def epoch_end(self, estimator: Estimator | None, *args: Any, **kwargs: Any) -> None:
        if estimator is None:
            return
        if isinstance(self.log_interval, int) or self.log_interval == "epoch":
            elapsed = time.time() - self.epoch_start
            msg = f"[Epoch {self.current_epoch}] {elapsed:.3f}s, "
            run = self.experiment
            for m in self.metrics:
                name, value = m.get()
                msg += f"{name}: {value:.4f}, "
                ctx_name, metric_name = name.split(" ")
                run.track(value, metric_name, step=self.batch_index, context={"subset": ctx_name})
            logger = estimator.logger
            assert logger is not None
            logger.info(msg.rstrip(", "))
        self.current_epoch += 1
        self.batch_index = 0

    @override
    def batch_begin(self, estimator: Estimator | None, *args: Any, **kwargs: Any) -> None:
        if isinstance(self.log_interval, int):
            self.batch_start = time.time()

    @override
    def batch_end(self, estimator: Estimator | None, *args: Any, **kwargs: Any) -> None:
        if estimator is None:
            return
        if isinstance(self.log_interval, int):
            batch_time = time.time() - self.batch_start
            self.processed_samples += kwargs["batch"][0].shape[0]
            self.log_interval_time += batch_time

            if self.batch_index % self.log_interval == 0:
                msg = (
                    f"[Epoch {self.current_epoch}][Batch {self.batch_index}]"
                    f"[Samples {self.processed_samples}] "
                    f"time/interval: {self.log_interval_time:.3f}s "
                )
                self.log_interval_time = 0.0
                run = self.experiment
                for m in self.metrics:
                    name, value = m.get()
                    msg += f"{name}: {value:.4f}, "
                    ctx_name, metric_name = name.split(" ")
                    run.track(value, metric_name, step=self.batch_index, context={"subset": ctx_name})
                logger = estimator.logger
                assert logger is not None
                logger.info(msg.rstrip(", "))
        self.batch_index += 1

    # ------------------------------------------------------------------
    # Run management
    # ------------------------------------------------------------------

    @property
    def experiment(self) -> Run:
        if not self._run:
            self.setup()
        assert self._run is not None  # setup() always sets _run
        return self._run

    def setup(self, estimator: Estimator | None = None, args: dict[str, Any] | None = None) -> None:
        if not self._run:
            if self._run_hash:
                self._run = Run(
                    self._run_hash,
                    repo=self.repo,
                    system_tracking_interval=self.system_tracking_interval,
                    log_system_params=self.log_system_params,
                    capture_terminal_logs=self.capture_terminal_logs,
                )
            else:
                self._run = Run(
                    repo=self.repo,
                    experiment=self.experiment_name,
                    system_tracking_interval=self.system_tracking_interval,
                    log_system_params=self.log_system_params,
                    capture_terminal_logs=self.capture_terminal_logs,
                )
                self._run_hash = self._run.hash

        if args:
            try:
                run = self._run
                assert run is not None
                for key, value in args.items():
                    run[key] = value
            except Exception:  # noqa: BLE001
                if estimator is not None:
                    logger = estimator.logger
                    assert logger is not None
                    logger.warning("Could not log config parameters")
                else:
                    _logger.opt(exception=True).warning("Could not log config parameters")

    def __del__(self) -> None:
        if self._run is not None:
            self._run.close()
