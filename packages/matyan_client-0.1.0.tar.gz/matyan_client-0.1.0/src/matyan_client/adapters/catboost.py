"""CatBoost logger that parses training output and logs metrics to Matyan."""

from __future__ import annotations

from sys import stdout
from typing import IO, Any

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL


class AimLogger:
    def __init__(
        self,
        loss_function: str = "Loss",
        repo: str | None = None,
        experiment: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
        log_cout: IO[str] | None = stdout,
    ) -> None:
        self._loss_function = loss_function
        self._repo_path = repo
        self._experiment = experiment
        self._system_tracking_interval = system_tracking_interval
        self._log_system_params = log_system_params
        self._capture_terminal_logs = capture_terminal_logs
        self._run: Run | None = None
        self._run_hash: str | None = None
        self._log_cout = log_cout

    @property
    def experiment(self) -> Run:
        if not self._run:
            self.setup()
        assert self._run is not None  # setup() always sets _run
        return self._run

    def setup(self) -> None:
        if self._run:
            return
        if self._run_hash:
            self._run = Run(
                self._run_hash,
                repo=self._repo_path,
                system_tracking_interval=self._system_tracking_interval,
                capture_terminal_logs=self._capture_terminal_logs,
            )
        else:
            self._run = Run(
                repo=self._repo_path,
                experiment=self._experiment,
                system_tracking_interval=self._system_tracking_interval,
                log_system_params=self._log_system_params,
                capture_terminal_logs=self._capture_terminal_logs,
            )
            self._run_hash = self._run.hash

    @staticmethod
    def _to_number(val: Any) -> float | Any:  # noqa: ANN401
        try:
            return float(val)
        except (ValueError, TypeError):
            return val

    def write(self, log: str) -> None:
        run = self.experiment
        raw = log

        tokens = log.strip().split()
        if tokens:
            if len(tokens) == 3 and tokens[1] == "=":
                run[tokens[0]] = self._to_number(tokens[2])
            else:
                self._parse_iteration_log(run, tokens)

        if self._log_cout:
            self._log_cout.write(raw)

    def _parse_iteration_log(self, run: Run, tokens: list[str]) -> None:
        value_learn = value_test = value_best = None
        value_iter: int | None = None

        if len(tokens) >= 3 and tokens[1] == "learn:":
            value_iter = int(tokens[0][:-1])
            value_learn = self._to_number(tokens[2])
            if len(tokens) >= 5 and tokens[3] == "test:":
                value_test = self._to_number(tokens[4])
                if len(tokens) >= 7 and tokens[5] == "best:":
                    value_best = self._to_number(tokens[6])

        if value_learn is not None:
            run.track(value_learn, name=self._loss_function, step=value_iter, context={"log": "learn"})
        if value_test is not None:
            run.track(value_test, name=self._loss_function, step=value_iter, context={"log": "test"})
        if value_best is not None:
            run.track(value_best, name=self._loss_function, step=value_iter, context={"log": "best"})
