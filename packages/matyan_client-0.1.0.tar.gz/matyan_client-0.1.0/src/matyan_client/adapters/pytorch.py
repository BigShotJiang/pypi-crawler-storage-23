"""Helpers to track PyTorch model parameter and gradient distributions."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from matyan_client import Distribution

if TYPE_CHECKING:
    from matyan_client import Run


def track_params_dists(model: Any, run: Run) -> None:  # noqa: ANN401
    """Track weight and bias distributions for all model layers."""
    data_hist = _get_model_layers(model, "data")
    for name, params in data_hist.items():
        if "weight" in params:
            run.track(Distribution(params["weight"]), name=name, context={"type": "data", "params": "weights"})
        if "bias" in params:
            run.track(Distribution(params["bias"]), name=name, context={"type": "data", "params": "biases"})


def track_gradients_dists(model: Any, run: Run) -> None:  # noqa: ANN401
    """Track gradient distributions for all model layers."""
    grad_hist = _get_model_layers(model, "grad")
    for name, params in grad_hist.items():
        if "weight" in params:
            run.track(Distribution(params["weight"]), name=name, context={"type": "gradients", "params": "weights"})
        if "bias" in params:
            run.track(Distribution(params["bias"]), name=name, context={"type": "gradients", "params": "biases"})


def _get_model_layers(model: Any, dt: str, parent_name: str | None = None) -> dict[str, dict[str, Any]]:  # noqa: ANN401
    layers: dict[str, dict[str, Any]] = {}
    for name, m in model.named_children():
        layer_name = f"{parent_name}__{name}" if parent_name else name
        layer_name += f".{type(m).__name__}"

        if list(m.named_children()):
            layers.update(_get_model_layers(m, dt, layer_name))
        else:
            layers[layer_name] = {}
            if hasattr(m, "weight") and m.weight is not None:
                weight = getattr(m.weight, dt, None)
                if weight is not None:
                    layers[layer_name]["weight"] = _get_pt_tensor(weight).numpy()
            if hasattr(m, "bias") and m.bias is not None:
                bias = getattr(m.bias, dt, None)
                if bias is not None:
                    layers[layer_name]["bias"] = _get_pt_tensor(bias).numpy()
    return layers


def _get_pt_tensor(t: Any) -> Any:  # noqa: ANN401
    """Move tensor from GPU to CPU if needed."""
    return t.cpu() if hasattr(t, "is_cuda") and t.is_cuda else t
