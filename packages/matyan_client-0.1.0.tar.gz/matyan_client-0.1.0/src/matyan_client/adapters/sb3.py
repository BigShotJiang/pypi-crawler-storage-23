"""Stable Baselines 3 callback and output format for logging to Matyan."""

from __future__ import annotations

from typing import Any

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL

try:
    import numpy as np
    from stable_baselines3.common.callbacks import BaseCallback
    from stable_baselines3.common.logger import KVWriter, Logger
except ImportError as _exc:
    msg = "This adapter requires Stable Baselines 3. Install with: pip install stable-baselines3"
    raise RuntimeError(msg) from _exc


class AimOutputFormat(KVWriter):
    """Writes key/value pairs into a Matyan run."""

    def __init__(self, aim_callback: AimCallback) -> None:
        self.aim_callback = aim_callback

    def write(
        self,
        key_values: dict[str, Any],
        key_excluded: dict[str, tuple[str, ...]],
        step: int = 0,
    ) -> None:
        for (key, value), (_, excluded) in zip(sorted(key_values.items()), sorted(key_excluded.items()), strict=True):
            if excluded is not None and "aim" in excluded:
                continue
            if isinstance(value, np.ScalarType) and not isinstance(value, str):
                tag, metric_name = key.split("/")
                context = {"subset": tag} if tag in ("train", "valid") else {"tag": tag}
                self.aim_callback.experiment.track(value, metric_name, step=step, context=context)


class AimCallback(BaseCallback):
    """SB3 callback that sets up Matyan tracking and logs config + metrics."""

    def __init__(
        self,
        repo: str | None = None,
        experiment_name: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
        verbose: int = 0,
    ) -> None:
        super().__init__(verbose)
        self.repo = repo
        self.experiment_name = experiment_name
        self.system_tracking_interval = system_tracking_interval
        self.log_system_params = log_system_params
        self.capture_terminal_logs = capture_terminal_logs
        self._run: Run | None = None
        self._run_hash: str | None = None

    def _init_callback(self) -> None:
        args: dict[str, Any] = {"algo": type(self.model).__name__}
        for key, val in self.model.__dict__.items():
            args[key] = val if isinstance(val, (float, int, str)) else str(val)

        self.setup(args=args)

        loggers = Logger(folder=None, output_formats=[AimOutputFormat(self)])
        self.model.set_logger(loggers)

    def _on_step(self) -> bool:
        return True

    @property
    def experiment(self) -> Run:
        if not self._run:
            self.setup()
        assert self._run is not None  # setup() always sets _run
        return self._run

    def setup(self, args: dict[str, Any] | None = None) -> None:
        if not self._run:
            if self._run_hash:
                self._run = Run(
                    self._run_hash,
                    repo=self.repo,
                    system_tracking_interval=self.system_tracking_interval,
                    log_system_params=self.log_system_params,
                    capture_terminal_logs=self.capture_terminal_logs,
                )
            else:
                self._run = Run(
                    repo=self.repo,
                    experiment=self.experiment_name,
                    system_tracking_interval=self.system_tracking_interval,
                    log_system_params=self.log_system_params,
                    capture_terminal_logs=self.capture_terminal_logs,
                )
                self._run_hash = self._run.hash

        if args:
            for key, value in args.items():
                self._run[key] = value

    def __del__(self) -> None:
        if self._run is not None:
            self._run.close()
