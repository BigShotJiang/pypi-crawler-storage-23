"""LightGBM callback that logs evaluation metrics to Matyan."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL

if TYPE_CHECKING:
    from lightgbm.callback import CallbackEnv


class AimCallback:
    """Records evaluation data into Matyan, similar to ``lightgbm.record_evaluation``."""

    def __init__(
        self,
        repo: str | None = None,
        experiment: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
    ) -> None:
        self._repo_path = repo
        self._experiment = experiment
        self._system_tracking_interval = system_tracking_interval
        self._log_system_params = log_system_params
        self._capture_terminal_logs = capture_terminal_logs
        self._run: Run | None = None
        self._run_hash: str | None = None

        self.order = 25
        self.before_iteration = False

    @property
    def experiment(self) -> Run:
        if not self._run:
            self.setup()
        assert self._run is not None  # setup() always sets _run
        return self._run

    def setup(self) -> None:
        if self._run:
            return
        if self._run_hash:
            self._run = Run(
                self._run_hash,
                repo=self._repo_path,
                system_tracking_interval=self._system_tracking_interval,
                capture_terminal_logs=self._capture_terminal_logs,
            )
        else:
            self._run = Run(
                repo=self._repo_path,
                experiment=self._experiment,
                system_tracking_interval=self._system_tracking_interval,
                log_system_params=self._log_system_params,
                capture_terminal_logs=self._capture_terminal_logs,
            )
            self._run_hash = self._run.hash

    def before_tracking(self, **kwargs: Any) -> None:  # noqa: ANN401
        """Hook called before tracking data."""  # noqa: D401

    def after_tracking(self, **kwargs: Any) -> None:  # noqa: ANN401
        """Hook called after tracking data."""  # noqa: D401

    def __call__(self, env: CallbackEnv) -> None:
        if env.iteration == env.begin_iteration:
            self.setup()

        self.before_tracking(env=env)

        run = self.experiment
        for item in env.evaluation_result_list or []:
            if len(item) == 4:
                data_name, eval_name, result = item[0], item[1], item[2]
                run.track(result, name=eval_name, context={"data_name": data_name})
            elif len(item) >= 5:
                data_name, eval_name = item[1].split()
                res_mean = item[2]
                res_stdv = item[4]  # type: ignore[index]
                run.track(res_mean, name=f"{eval_name}-mean", context={"data_name": data_name})
                run.track(res_stdv, name=f"{eval_name}-stdv", context={"data_name": data_name})
            else:
                msg = f"Unexpected evaluation_result_list item length {len(item)}; expected 4 or >= 5"
                raise ValueError(msg)

        self.after_tracking(env=env)

    def close(self) -> None:
        if self._run:
            self._run.close()
            self._run = None

    def __del__(self) -> None:
        self.close()
