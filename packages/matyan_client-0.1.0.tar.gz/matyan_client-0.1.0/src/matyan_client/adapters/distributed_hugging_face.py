"""Distributed Hugging Face adapter for multi-node system metric aggregation.

Collects system metrics from all workers and funnels them into a single Matyan
run created on rank 0.  Auxiliary workers open a TCP connection to the main
worker and periodically forward their resource usage.
"""

from __future__ import annotations

import contextlib
import copy
import json
import logging
import os
import select
import socket
import struct
import threading
import time
from typing import TYPE_CHECKING, Any

from loguru import logger as _loguru

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL

try:
    import accelerate.utils.environment
except ImportError as _exc:
    msg = "This adapter requires HuggingFace Accelerate. Install with: pip install accelerate"
    raise RuntimeError(msg) from _exc

from .hugging_face import AimCallback as _BaseAimCallback

if TYPE_CHECKING:
    from collections.abc import Callable

# ---------------------------------------------------------------------------
# Packet encoding helpers
# ---------------------------------------------------------------------------


def _packet_encode(usage: dict[str, Any]) -> bytes:
    data = json.dumps(usage).encode("utf-8")
    header = len(data).to_bytes(4, "big")
    return header + struct.pack(f"!{len(data)}s", data)


def _packet_decode(packet: bytes) -> dict[str, Any]:
    length = int.from_bytes(packet[:4], "big")
    raw = struct.unpack_from(f"!{length}s", packet, 4)[0]
    return json.loads(raw)


# ---------------------------------------------------------------------------
# Worker-side: forward resource metrics to rank-0
# ---------------------------------------------------------------------------


class _MetricsReporter:
    """Runs on non-zero ranks; sends system metrics to the rank-0 receiver."""

    def __init__(
        self,
        host: str,
        port: int,
        node_rank: int,
        rank: int,
        interval: float,
    ) -> None:
        self.node_rank = node_rank
        self.rank = rank
        self._log = logging.getLogger(f"MetricsReporter{rank}")
        self._client: socket.socket | None = None
        self._connect(host, port)
        self._interval = interval
        self._shutdown = False
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        self._shutdown = False
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._shutdown = True
        if self._thread is not None:
            self._thread.join(timeout=5)
        if self._client is not None:
            self._client.close()
            self._client = None

    # -- internal ----------------------------------------------------------

    def _connect(self, host: str, port: int, timeout: int = 600, retry: int = 5) -> None:
        start = time.time()
        while time.time() - start <= timeout:
            for family, socktype, proto, _, sa in socket.getaddrinfo(host, port, proto=socket.SOL_TCP):
                self._client = socket.socket(family, socktype, proto)
                try:
                    self._client.connect(sa)
                    return
                except (ConnectionRefusedError, OSError) as e:
                    self._client.close()
                    self._log.info("Connection to main worker failed (%s), retry in %ds", e, retry)
            time.sleep(retry)
        msg = f"Could not connect to {host}:{port} after {timeout}s"
        raise ConnectionError(msg)

    def _loop(self) -> None:
        """Placeholder: the actual metric collection would be done by a
        ResourceTracker that calls ``self._send(stat)`` periodically.
        """  # noqa: D401

    def _send(self, stat_dict: dict[str, Any]) -> None:
        if self._client is None:
            return
        raw = {"stat": stat_dict, "worker": {"node_rank": self.node_rank, "rank": self.rank}}
        packet = _packet_encode(raw)
        try:
            self._client.sendall(packet)
        except BrokenPipeError:
            self._log.info("BrokenPipeError while sending metrics -- stopping reporter")
            with contextlib.suppress(RuntimeError):
                self.stop()
        except Exception:
            self._log.info("Error sending metrics -- ignoring", exc_info=True)


# ---------------------------------------------------------------------------
# Rank-0 side: receive metrics from all workers
# ---------------------------------------------------------------------------


class _MetricsReceiver:
    def __init__(self, host: str, port: int, num_workers: int, connection_timeout: int) -> None:
        self.tracker: Callable[[dict[str, Any], dict[str, Any]], None] | None = None
        self.clients: list[socket.socket] = []
        self._log = logging.getLogger("MetricsReceiver")
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._wait_workers(host, port, num_workers, connection_timeout)
        self.running = True
        self._thread: threading.Thread | None = None

    def start(self, tracker: Callable[[dict[str, Any], dict[str, Any]], None]) -> None:
        self.tracker = tracker
        self.running = True
        self._thread = threading.Thread(target=self._collect_metrics, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        if self.running:
            self.running = False
            if self._thread is not None:
                self._thread.join(timeout=10)

    def _recv(self, sock: socket.socket, length: int) -> bytes | None:
        data = b""
        retries = 0
        while len(data) < length and retries < 10:
            buf = sock.recv(length - len(data))
            data += buf
            retries += 1
        if len(data) < length:
            return None
        return data

    def _recv_packet(self, sock: socket.socket) -> dict[str, Any] | None:
        header = self._recv(sock, 4)
        if header is None:
            return None
        length = int.from_bytes(header, "big")
        data = self._recv(sock, length)
        if data and len(data) > 0:
            return json.loads(data)
        return None

    def _collect_metrics(self) -> None:
        while self.running:
            readable, _, _ = select.select(self.clients, [], [], 5.0)
            for client in readable:
                try:
                    packet = self._recv_packet(client)
                except Exception:
                    self._log.info("Error receiving packet -- treating as transient", exc_info=True)
                    continue
                if packet and self.tracker:
                    self.tracker(packet["stat"], packet["worker"])
                elif packet is None:
                    self._log.info("Client disconnected")
                    client.close()
                    self.clients.remove(client)

    def _wait_workers(self, host: str, port: int, num_workers: int, timeout: float) -> None:
        self.server.bind((host, port))
        self.server.listen(num_workers)
        start = time.time()
        self._log.info("Waiting for %d workers to connect", num_workers)
        while time.time() - start <= timeout:
            readable, _, _ = select.select([self.server], [], [], 5.0)
            for srv in readable:
                client, _ = srv.accept()
                self.clients.append(client)
                self._log.info("Client %d/%d connected", len(self.clients), num_workers)
                if len(self.clients) == num_workers:
                    return
        self.server.close()
        msg = f"{num_workers - len(self.clients)} of {num_workers} clients did not connect"
        raise ConnectionError(msg)


# ---------------------------------------------------------------------------
# Public callback
# ---------------------------------------------------------------------------


class AimCallback(_BaseAimCallback):
    """Distributed HF callback that aggregates system metrics from all workers.

    On rank 0, starts a receiver that accepts connections from auxiliary
    workers and pushes their system metrics into the single Matyan run.
    """

    def __init__(
        self,
        main_port: int,
        repo: str | None = None,
        experiment: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
        main_addr: str | None = None,
        distributed_information: Any | None = None,  # noqa: ANN401
        connection_timeout: int = 300,
        workers_only_on_rank_0: bool = True,
    ) -> None:

        if main_addr is None:
            main_addr = os.environ.get("MASTER_ADDR")
        if not main_addr:
            msg = "main_addr cannot be empty"
            raise ValueError(msg)
        if not main_port or main_port < 0:
            msg = "main_port must be a positive number"
            raise ValueError(msg)

        if distributed_information is None:
            distributed_information = accelerate.utils.get_cpu_distributed_information()

        self.distributed_information = distributed_information
        self.connection_timeout = connection_timeout

        self.metrics_reporter: _MetricsReporter | None = None
        self.metrics_receiver: _MetricsReceiver | None = None
        self._run = None

        if not workers_only_on_rank_0:
            auxiliary_workers = self.distributed_information.world_size
        else:
            auxiliary_workers = self.distributed_information.world_size // self.distributed_information.local_world_size

        rank = self.distributed_information.rank

        if (
            rank is not None
            and rank > 0
            and (not workers_only_on_rank_0 or self.distributed_information.local_rank == 0)
            and system_tracking_interval is not None
        ):
            node_rank = rank // distributed_information.local_world_size if workers_only_on_rank_0 else rank
            self.metrics_reporter = _MetricsReporter(
                host=main_addr,
                port=main_port,
                rank=rank,
                node_rank=node_rank,
                interval=system_tracking_interval or DEFAULT_SYSTEM_TRACKING_INTERVAL,
            )
            _loguru.info("Distributed worker {} connected", rank)

        elif rank == 0:
            super().__init__(
                repo=repo,
                experiment=experiment,
                system_tracking_interval=system_tracking_interval,
                log_system_params=log_system_params,
                capture_terminal_logs=capture_terminal_logs,
            )

            if auxiliary_workers > 1 and main_port and system_tracking_interval is not None:
                _loguru.info("Expecting {} auxiliary workers", auxiliary_workers - 1)
                self.metrics_receiver = _MetricsReceiver(
                    host="0.0.0.0",
                    port=main_port,
                    num_workers=auxiliary_workers - 1,
                    connection_timeout=self.connection_timeout,
                )
                self.metrics_receiver.start(self._push_auxiliary_worker_metrics)

    def _push_auxiliary_worker_metrics(
        self,
        stat: dict[str, Any],
        worker_info: dict[str, Any],
    ) -> None:
        if self._run is None:
            return
        context = copy.deepcopy(worker_info)
        for resource, usage in stat.get("system", {}).items():
            self._run.track(usage, name=f"__system__{resource}", context=context)
        for gpu_idx, gpu in enumerate(stat.get("gpus", [])):
            gpu_ctx = {**context, "gpu": gpu_idx}
            for resource, usage in gpu.items():
                self._run.track(usage, name=f"__system__{resource}", context=gpu_ctx)

    def on_train_begin(self, args: Any, state: Any, control: Any, model: Any = None, **kwargs: Any) -> None:
        super().on_train_begin(args, state, control, model, **kwargs)
        if self.metrics_reporter:
            self.metrics_reporter.start()

    def close(self) -> None:
        try:
            super().close()
        finally:
            if self.metrics_receiver is not None:
                self.metrics_receiver.stop()
            if self.metrics_reporter is not None:
                self.metrics_reporter.stop()
