"""PaddlePaddle callback that logs training and evaluation metrics to Matyan."""

from __future__ import annotations

from typing import Any

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL

try:
    from paddle.hapi.callbacks import Callback
except ImportError as _exc:
    msg = "This adapter requires PaddlePaddle. Install with: pip install paddlepaddle"
    raise RuntimeError(msg) from _exc


class AimCallback(Callback):
    def __init__(
        self,
        repo: str | None = None,
        experiment_name: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
    ) -> None:
        self.repo = repo
        self.experiment_name = experiment_name
        self.system_tracking_interval = system_tracking_interval
        self.log_system_params = log_system_params
        self.capture_terminal_logs = capture_terminal_logs
        self._run: Run | None = None
        self._run_hash: str | None = None
        self.epoch: int = 0

    def on_train_begin(self, logs: dict[str, Any] | None = None) -> None:
        self.setup(self.params)

    def on_epoch_begin(self, epoch: int | None = None, logs: dict[str, Any] | None = None) -> None:
        self.epoch = epoch or 0

    def on_train_batch_end(self, step: int, logs: dict[str, Any] | None = None) -> None:
        self._track(logs or {}, {"subset": "train"}, step)

    def on_eval_end(self, logs: dict[str, Any] | None = None) -> None:
        self._track(logs or {}, {"subset": "valid"})

    def _track(
        self,
        logs: dict[str, Any],
        context: dict[str, str],
        step: int | None = None,
    ) -> None:
        for k, v in logs.items():
            if isinstance(v, list):
                if len(v) == 1:
                    v = v[0]
                else:
                    msg = f"More than one item in {k}"
                    raise NotImplementedError(msg)
            self._run.track(v, k, step=step, context=context, epoch=self.epoch)

    @property
    def experiment(self) -> Run:
        if not self._run:
            self.setup()
        return self._run

    def setup(self, args: dict[str, Any] | None = None) -> None:
        if not self._run:
            if self._run_hash:
                self._run = Run(
                    self._run_hash,
                    repo=self.repo,
                    system_tracking_interval=self.system_tracking_interval,
                    log_system_params=self.log_system_params,
                    capture_terminal_logs=self.capture_terminal_logs,
                )
            else:
                self._run = Run(
                    repo=self.repo,
                    experiment=self.experiment_name,
                    system_tracking_interval=self.system_tracking_interval,
                    log_system_params=self.log_system_params,
                    capture_terminal_logs=self.capture_terminal_logs,
                )
                self._run_hash = self._run.hash

        if args:
            for key, value in args.items():
                self._run[key] = value

    def __del__(self) -> None:
        if self._run is not None:
            self._run.close()
