"""Keras epoch-end mixin shared by the Keras and TensorFlow adapters."""

from __future__ import annotations

from loguru import logger


class TrackerKerasCallbackMetricsEpochEndMixin:
    def on_epoch_end(self, epoch: int, logs: dict | None = None) -> None:
        self._log_epoch_metrics(epoch, logs)

    def _get_learning_rate(self) -> float | None:
        model = getattr(self, "model", None)
        if model is None:
            logger.debug("Keras callback mixin: no model on self, skipping learning rate")
            return None
        lr_schedule = getattr(model.optimizer, "lr", None)
        if lr_schedule is None:
            logger.debug("Keras callback mixin: optimizer has no lr attribute, skipping learning rate")
            return None
        try:
            if callable(lr_schedule):
                return float(lr_schedule(model.optimizer.iterations))
            return float(lr_schedule)
        except Exception:  # noqa: BLE001
            logger.opt(exception=True).warning(
                "Keras callback mixin: failed to get learning rate from optimizer",
            )
            return None

    def _log_epoch_metrics(self, epoch: int, logs: dict | None) -> None:
        if not logs:
            logger.debug("Keras callback mixin: on_epoch_end called with no logs, skipping")
            return

        run = getattr(self, "_run", None)
        if run is None:
            logger.warning(
                "Keras callback mixin: no _run on self, skipping epoch metrics for epoch {}",
                epoch,
            )
            return
        track = run.track

        train_logs = {k: v for k, v in logs.items() if not k.startswith("val_")}
        for name, value in train_logs.items():
            track(value, name=name, epoch=epoch, context={"subset": "train"})

        val_logs = {k: v for k, v in logs.items() if k.startswith("val_")}
        for name, value in val_logs.items():
            track(value, name=name[4:], epoch=epoch, context={"subset": "val"})

        lr = self._get_learning_rate()
        if lr is not None:
            track(lr, name="lr", epoch=epoch, context={"subset": "train"})
