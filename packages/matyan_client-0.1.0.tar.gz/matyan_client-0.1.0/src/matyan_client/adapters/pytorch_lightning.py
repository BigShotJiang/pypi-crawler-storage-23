"""PyTorch Lightning logger that sends metrics and hyperparameters to Matyan."""

from __future__ import annotations

import importlib.util
import warnings
from argparse import Namespace
from typing import Any, cast

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL

if importlib.util.find_spec("lightning"):
    from lightning.pytorch.loggers.logger import Logger, rank_zero_experiment
    from lightning.pytorch.utilities import rank_zero_only
    from omegaconf import OmegaConf
elif importlib.util.find_spec("pytorch_lightning"):
    import packaging.version
    import pytorch_lightning as pl
    from omegaconf import OmegaConf

    pl_version = getattr(pl, "__version__", "0.0")
    if packaging.version.parse(pl_version) < packaging.version.parse("1.7"):
        from pytorch_lightning.loggers.base import (  # ty:ignore[unresolved-import]  # pyright: ignore[reportMissingImports]
            LightningLoggerBase as Logger,
        )
        from pytorch_lightning.loggers.base import (  # ty:ignore[unresolved-import]  # pyright: ignore[reportMissingImports]
            rank_zero_experiment,
        )
    else:
        from pytorch_lightning.loggers.logger import Logger, rank_zero_experiment
    from pytorch_lightning.utilities import rank_zero_only
else:
    msg = (
        "This adapter requires PyTorch Lightning and Omegaconf. "
        "Install with: pip install pytorch-lightning omegaconf or pip install lightning omegaconf"
    )
    raise RuntimeError(msg)


class AimLogger(Logger):
    def __init__(
        self,
        repo: str | None = None,
        experiment: str | None = None,
        train_metric_prefix: str | None = "train_",
        val_metric_prefix: str | None = "val_",
        test_metric_prefix: str | None = "test_",
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
        run_name: str | None = None,
        run_hash: str | None = None,
        context_prefixes: dict[str, dict[str, str]] | None = None,
        context_postfixes: dict[str, dict[str, str]] | None = None,
    ) -> None:
        super().__init__()

        self._experiment_name = experiment
        self._run_name = run_name
        self._repo_path = repo

        default_prefixes: dict[str, dict[str, str]] = {"subset": {"train": "train_", "val": "val_", "test": "test_"}}

        if context_prefixes is None:
            context_prefixes = {
                "subset": {
                    k: v
                    for k, v in {
                        "train": train_metric_prefix,
                        "val": val_metric_prefix,
                        "test": test_metric_prefix,
                    }.items()
                    if v
                },
            }
            if not context_prefixes["subset"]:
                context_prefixes.pop("subset")
        elif train_metric_prefix != "train_" or val_metric_prefix != "val_" or test_metric_prefix != "test_":
            msg = (
                '"train_metric_prefix", "val_metric_prefix", and "test_metric_prefix" '
                'cannot be used together with "context_prefixes".'
            )
            raise ValueError(msg)

        for arg, default in [
            ("train_metric_prefix", "train_"),
            ("val_metric_prefix", "val_"),
            ("test_metric_prefix", "test_"),
        ]:
            val = locals()[arg]
            if val != default:
                warnings.warn(
                    f'"{arg}" is deprecated. Use "context_prefixes" instead.',
                    DeprecationWarning,
                    stacklevel=2,
                )

        self._context_prefixes = context_prefixes
        self._context_postfixes = context_postfixes or {}
        self._system_tracking_interval = system_tracking_interval
        self._log_system_params = log_system_params
        self._capture_terminal_logs = capture_terminal_logs

        self._run: Run | None = None
        self._run_hash = run_hash
        self._finalized = False

    @staticmethod
    def _convert_params(params: dict[str, Any] | Namespace) -> dict[str, Any]:
        if isinstance(params, Namespace):
            params = vars(params)
        return params or {}

    def _reopen(self) -> None:
        """Reset the finalized flag so the next ``experiment`` access creates a
        fresh connection.  Called by framework hooks that legitimately need to
        restart tracking on the same run (e.g. ``trainer.test()`` after
        ``trainer.fit()``).
        """
        self._finalized = False

    @property
    @rank_zero_experiment
    def experiment(self) -> Run:
        if self._run is None and not self._finalized:
            if self._run_hash:
                self._run = Run(
                    self._run_hash,
                    repo=self._repo_path,
                    system_tracking_interval=self._system_tracking_interval,
                    capture_terminal_logs=self._capture_terminal_logs,
                    force_resume=True,
                )
            else:
                self._run = Run(
                    repo=self._repo_path,
                    experiment=self._experiment_name,
                    system_tracking_interval=self._system_tracking_interval,
                    log_system_params=self._log_system_params,
                    capture_terminal_logs=self._capture_terminal_logs,
                )
                self._run_hash = self._run.hash
            if self._run_name is not None:
                self._run.name = self._run_name
        return self._run

    @rank_zero_only
    def log_hyperparams(self, params: dict[str, Any] | Namespace) -> None:
        self._reopen()
        params = self._convert_params(params)

        if OmegaConf.is_config(params):
            params = cast("dict[str, Any]", OmegaConf.to_container(params, resolve=True))

        for key, value in params.items():
            self.experiment[f"hparams.{key}"] = value

    @rank_zero_only
    def log_metrics(self, metrics: dict[str, float], step: int | None = None) -> None:
        self._reopen()
        metric_items = dict(metrics)
        epoch = cast("int | None", metric_items.pop("epoch", None))

        for k, v in metric_items.items():
            name, context = self.parse_context(k)
            self.experiment.track(v, name=name, step=step, epoch=epoch, context=context)

    def parse_context(self, name: str) -> tuple[str, dict[str, str]]:
        context: dict[str, str] = {}
        for ctx, mappings in self._context_prefixes.items():
            for category, prefix in mappings.items():
                if name.startswith(prefix):
                    name = name[len(prefix) :]
                    context[ctx] = category
                    break
        for ctx, mappings in self._context_postfixes.items():
            for category, postfix in mappings.items():
                if name.endswith(postfix):
                    name = name[: -len(postfix)]
                    context[ctx] = category
                    break
        return name, context

    @rank_zero_only
    def finalize(self, status: str = "") -> None:
        super().finalize(status)
        if self._run:
            self._run.close()
            self._run = None
        self._finalized = True

    def __del__(self) -> None:
        self.finalize()

    @property
    def name(self) -> str | None:
        return self._experiment_name

    @property
    def version(self) -> str:
        if self._run_hash:
            return self._run_hash
        return self.experiment.hash
