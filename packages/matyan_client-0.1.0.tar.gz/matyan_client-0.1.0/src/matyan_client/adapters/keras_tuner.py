"""Keras Tuner callback that logs trial hyperparameters and metrics to Matyan."""

from __future__ import annotations

from typing import Any

from typing_extensions import override

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL

try:
    from keras_tuner.src.engine.tuner_utils import TunerCallback
except ImportError as _exc:
    msg = "This adapter requires KerasTuner. Install with: pip install keras-tuner"
    raise RuntimeError(msg) from _exc


class AimCallback(TunerCallback):
    @override
    def __init__(
        self,
        tuner: Any = None,
        repo: str | None = None,
        experiment: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
    ) -> None:
        self.tuner = tuner
        self._repo_path = repo
        self._experiment_name = experiment
        self._system_tracking_interval = system_tracking_interval
        self._log_system_params = log_system_params
        self._capture_terminal_logs = capture_terminal_logs

        self._started_trials: list[str] = []
        self.trial = None
        self._run: Run | None = None

    @property
    def experiment(self) -> Run | None:
        return self._run

    @override
    def on_epoch_begin(self, epoch: int, logs: dict[str, Any] | None = None) -> None:
        if self.tuner is None:
            return
        trial_dict = self.tuner.oracle.ongoing_trials
        tuner_key = next(iter(trial_dict))
        current_trial_id = trial_dict[tuner_key].trial_id

        if current_trial_id not in self._started_trials:
            self._run = Run(
                repo=self._repo_path,
                experiment=self._experiment_name,
                system_tracking_interval=self._system_tracking_interval,
                log_system_params=self._log_system_params,
                capture_terminal_logs=self._capture_terminal_logs,
            )
            self._run["trial_id"] = current_trial_id
            self._started_trials.append(current_trial_id)

        trial = self.tuner.oracle.get_trial(current_trial_id)
        hparams = trial.hyperparameters.values
        run = self._run
        assert run is not None  # set above when current_trial_id not in _started_trials, or in prior epoch
        for key, value in hparams.items():
            run[f"hparams.{key}"] = value

    @override
    def on_batch_end(self, batch: int, logs: dict[str, Any] | None = None) -> None:
        if logs and self._run:
            for name, value in logs.items():
                self._run.track(value, name=name)

    def __del__(self) -> None:
        if self._run is not None:
            self._run.close()
