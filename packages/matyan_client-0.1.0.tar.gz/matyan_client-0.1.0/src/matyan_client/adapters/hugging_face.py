"""Hugging Face Transformers TrainerCallback for logging to Matyan."""

from __future__ import annotations

import json
from collections import defaultdict
from difflib import SequenceMatcher
from typing import Any

from loguru import logger
from typing_extensions import override

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL, is_number


def _json_safe(value: Any) -> Any:  # noqa: ANN401
    """Return a JSON-serializable version of value for WebSocket payloads."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    try:
        json.dumps(value)
    except (TypeError, ValueError):
        return str(value)
    return value


try:
    from transformers.trainer_callback import TrainerCallback
except ImportError as _exc:
    msg = "This adapter requires Transformers. Install with: pip install transformers"
    raise RuntimeError(msg) from _exc


class AimCallback(TrainerCallback):
    def __init__(
        self,
        repo: str | None = None,
        experiment: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
    ) -> None:
        self._repo_path = repo
        self._experiment_name = experiment
        self._system_tracking_interval = system_tracking_interval
        self._log_system_params = log_system_params
        self._capture_terminal_logs = capture_terminal_logs
        self._run: Run | None = None
        self._run_hash: str | None = None
        self._log_value_warned = False

    @property
    def experiment(self) -> Run:
        if not self._run:
            self.setup()
        assert self._run is not None  # setup() always sets _run
        return self._run

    def setup(
        self,
        args: Any | None = None,  # noqa: ANN401
        state: Any | None = None,  # noqa: ANN401
        model: Any | None = None,  # noqa: ANN401
    ) -> None:
        if state and not state.is_world_process_zero:
            return

        if not self._run:
            if self._run_hash:
                self._run = Run(
                    self._run_hash,
                    repo=self._repo_path,
                    system_tracking_interval=self._system_tracking_interval,
                    capture_terminal_logs=self._capture_terminal_logs,
                )
            else:
                self._run = Run(
                    repo=self._repo_path,
                    experiment=self._experiment_name,
                    system_tracking_interval=self._system_tracking_interval,
                    log_system_params=self._log_system_params,
                    capture_terminal_logs=self._capture_terminal_logs,
                )
                self._run_hash = self._run.hash

        if args:
            for key, value in args.to_sanitized_dict().items():
                self._run[f"hparams.{key}"] = _json_safe(value)
        if model and hasattr(model, "config"):
            self._run["model"] = _json_safe(
                {
                    **vars(model.config),
                    "num_labels": getattr(model, "num_labels", None),
                },
            )

    @override
    def on_init_end(self, args: Any, state: Any, control: Any, **kwargs: Any) -> None:
        self.setup(state=state)

    @override
    def on_train_begin(self, args: Any, state: Any, control: Any, model: Any = None, **kwargs: Any) -> None:
        self.setup(args, state, model)

    @override
    def on_train_end(self, args: Any, state: Any, control: Any, **kwargs: Any) -> None:
        if not state.is_world_process_zero:
            return
        self.close()

    @override
    def on_log(  # noqa: C901
        self,
        args: Any,
        state: Any,
        control: Any,
        model: Any = None,
        logs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        if not state.is_world_process_zero:
            return
        if not self._run:
            self.setup(args, state, model)

        if not logs:
            return

        run = self.experiment
        for log_name, log_value in logs.items():
            context: dict[str, str] = {}
            for prefix in ("train_", "eval_", "test_"):
                if log_name.startswith(prefix):
                    log_name = log_name[len(prefix) :]  # noqa: PLW2901
                    context = {"subset": prefix[:-1]}
                    if "_" in log_name:
                        sub_dataset = self._find_most_common_substring(list(logs.keys())).split(prefix)[-1]
                        if sub_dataset != prefix.rstrip("_"):
                            log_name = log_name.split(sub_dataset)[-1].lstrip("_")  # noqa: PLW2901
                            context["sub_dataset"] = sub_dataset
                    break

            if not is_number(log_value):
                if not self._log_value_warned:
                    self._log_value_warned = True
                    logger.warning(
                        "Trainer is logging non-numeric value {!r} (type {}) for key {!r}",
                        log_value,
                        type(log_value).__name__,
                        log_name,
                    )
                continue

            run.track(
                log_value,
                name=log_name,
                context=context,
                step=state.global_step,
                epoch=state.epoch,
            )

    def close(self) -> None:
        if self._run:
            self._run.close()
            self._run = None

    def __del__(self) -> None:
        self.close()

    @staticmethod
    def _find_most_common_substring(names: list[str]) -> str:
        counts: dict[str, int] = defaultdict(int)
        for i in range(len(names)):
            for j in range(i + 1, len(names)):
                match = SequenceMatcher(None, names[i], names[j]).find_longest_match(0, len(names[i]), 0, len(names[j]))
                substr = names[i][match.a : match.a + match.size]
                counts[substr] += 1
        return max(counts, key=lambda x: counts[x]).rstrip("_") if counts else ""
