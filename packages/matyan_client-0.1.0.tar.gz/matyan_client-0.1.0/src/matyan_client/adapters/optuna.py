"""Optuna callback that logs trials as Matyan runs."""

from __future__ import annotations

import functools
from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, Any

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL

if TYPE_CHECKING:
    import optuna


class AimCallback:
    """Track Optuna study trials in Matyan.

    Each trial's hyperparameters and objective values are logged.  When
    *as_multirun* is ``True``, a new Matyan run is created per trial; otherwise
    everything is tracked within a single run.
    """

    def __init__(
        self,
        metric_name: str | Sequence[str] = "value",
        as_multirun: bool = False,
        repo: str | None = None,
        experiment_name: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
    ) -> None:
        if not isinstance(metric_name, (str, Sequence)):
            msg = f"Expected metric_name to be str or Sequence[str], got {type(metric_name)}"
            raise TypeError(msg)

        self._metric_name = metric_name
        self._as_multirun = as_multirun
        self._repo_path = repo
        self._experiment_name = experiment_name
        self._system_tracking_interval = system_tracking_interval
        self._log_system_params = log_system_params
        self._capture_terminal_logs = capture_terminal_logs
        self._run: Run | None = None
        self._run_hash: str | None = None

        if not self._as_multirun:
            self.setup()

    def __call__(self, study: optuna.study.Study, trial: optuna.trial.FrozenTrial) -> None:
        values = trial.values if trial.values is not None else []
        if isinstance(self._metric_name, str):
            names = [f"{self._metric_name}_{i}" for i in range(len(values))] if len(values) > 1 else [self._metric_name]
        else:
            if len(self._metric_name) != len(values):
                msg = (
                    f"Running multi-objective optimization with {len(values)} values "
                    f"but {len(self._metric_name)} names specified."
                )
                raise ValueError(msg)
            names = list(self._metric_name)

        metrics = dict(zip(names, values, strict=True))
        if self._as_multirun:
            metrics["trial_number"] = trial.number

        step = trial.number if self._run else None

        if not self._run:
            self.setup()
            run_after_setup = self._run
            assert run_after_setup is not None
            run_after_setup.name = f"trial-{trial.number}"

        run = self._run
        assert run is not None
        run["hparams.direction"] = [d.name for d in study.directions]
        run["study_name"] = study.study_name

        if self._as_multirun:
            for key, value in trial.params.items():
                run[f"hparams.{key}"] = value
            for key, value in metrics.items():
                run[key] = value
            self.close()
        else:
            for key, value in trial.params.items():
                run.track(value, name=key, step=step)
            for key, value in metrics.items():
                run.track(value, name=key, step=step)

    @property
    def experiment(self) -> Run | None:
        return self._run

    def setup(self, args: dict[str, Any] | None = None) -> None:
        if not self._run:
            if self._run_hash:
                self._run = Run(
                    self._run_hash,
                    repo=self._repo_path,
                    system_tracking_interval=self._system_tracking_interval,
                    capture_terminal_logs=self._capture_terminal_logs,
                )
            else:
                self._run = Run(
                    repo=self._repo_path,
                    experiment=self._experiment_name,
                    system_tracking_interval=self._system_tracking_interval,
                    log_system_params=self._log_system_params,
                    capture_terminal_logs=self._capture_terminal_logs,
                )
                self._run_hash = self._run.hash

        if args:
            run = self._run
            assert run is not None
            for key, value in args.items():
                run[key] = value

    def close(self) -> None:
        if self._run:
            self._run.close()
            self._run = None
            self._run_hash = None

    def track_in_aim(self) -> Callable:
        """Decorator for tracking inside the objective function."""  # noqa: D401

        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            def wrapper(trial: optuna.trial.Trial) -> float | Sequence[float]:
                if not self._run:
                    self.setup()
                    run = self._run
                    assert run is not None
                    run.name = f"trial-{trial.number}"
                return func(trial)

            return wrapper

        return decorator
