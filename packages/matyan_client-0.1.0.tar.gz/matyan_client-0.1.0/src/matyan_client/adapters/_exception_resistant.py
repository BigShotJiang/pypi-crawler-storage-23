"""Decorators that prevent callback exceptions from crashing the training loop."""

from __future__ import annotations

from functools import wraps
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from collections.abc import Callable


def exception_resistant(silent: bool = False) -> Callable:
    """Decorator factory: catch exceptions in callback methods.

    When *silent* is ``False``, the first failure is printed and subsequent
    ones are logged up to a cap.  When *silent* is ``True``, failures are
    silently swallowed.
    """  # noqa: D401

    def inner(func: Callable) -> Callable:
        if not silent:
            num_fails = 0
            max_fails = 6

            @wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:  # noqa: ANN401
                nonlocal num_fails
                try:
                    return func(*args, **kwargs)
                except Exception:  # noqa: BLE001
                    num_fails += 1
                    if num_fails <= max_fails:
                        logger.opt(exception=True).warning(
                            "Error in callback {!r} (failure {}/{})",
                            func.__name__,  # ty:ignore[unresolved-attribute]
                            num_fails,
                            max_fails,
                        )
                    elif num_fails == max_fails + 1:
                        logger.warning("Further errors in {!r} are hidden", func.__name__)
                    return None
        else:

            @wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:  # noqa: ANN401
                try:
                    return func(*args, **kwargs)
                except Exception:  # noqa: BLE001
                    return None

        return wrapper

    return inner


class _SafeModeConfig:
    @staticmethod
    def log_exception(e: Exception, func: Callable) -> None:
        logger.warning("Exception in {!r}: {}", func.__name__, e)  # ty:ignore[unresolved-attribute]

    @staticmethod
    def reraise_exception(e: Exception, func: Callable) -> None:  # noqa: ARG004
        raise e

    exception_callback: Callable = reraise_exception


def enable_safe_mode() -> None:
    _SafeModeConfig.exception_callback = _SafeModeConfig.log_exception


def disable_safe_mode() -> None:
    _SafeModeConfig.exception_callback = _SafeModeConfig.reraise_exception


def noexcept(func: Callable) -> Callable:
    """Decorator: route exceptions through the safe-mode handler."""  # noqa: D401

    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:  # noqa: ANN401
        try:
            return func(*args, **kwargs)
        except Exception as e:  # noqa: BLE001
            _SafeModeConfig.exception_callback(e, func)
            return None

    return wrapper
