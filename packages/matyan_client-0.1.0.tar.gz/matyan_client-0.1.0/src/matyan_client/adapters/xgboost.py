"""XGBoost callback that logs evaluation metrics to Matyan."""

from __future__ import annotations

from typing import Any

from typing_extensions import override

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL

try:
    from xgboost.callback import TrainingCallback
except ImportError as _exc:
    msg = "This adapter requires XGBoost. Install with: pip install xgboost"
    raise RuntimeError(msg) from _exc


class AimCallback(TrainingCallback):
    def __init__(
        self,
        repo: str | None = None,
        experiment: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
    ) -> None:
        super().__init__()
        self._repo_path = repo
        self._experiment = experiment
        self._system_tracking_interval = system_tracking_interval
        self._log_system_params = log_system_params
        self._capture_terminal_logs = capture_terminal_logs
        self._run: Run | None = None
        self._run_hash: str | None = None

    @property
    def experiment(self) -> Run:
        if not self._run:
            self.setup()
        assert self._run is not None  # setup() always sets _run
        return self._run

    def setup(self) -> None:
        if self._run:
            return
        if self._run_hash:
            self._run = Run(
                self._run_hash,
                repo=self._repo_path,
                system_tracking_interval=self._system_tracking_interval,
                capture_terminal_logs=self._capture_terminal_logs,
            )
        else:
            self._run = Run(
                repo=self._repo_path,
                experiment=self._experiment,
                system_tracking_interval=self._system_tracking_interval,
                log_system_params=self._log_system_params,
                capture_terminal_logs=self._capture_terminal_logs,
            )
            self._run_hash = self._run.hash

    @override
    def before_training(self, model: Any) -> Any:
        self.setup()
        return model

    @override
    def after_iteration(self, model: Any, epoch: int, evals_log: dict[str, Any]) -> bool:
        if not evals_log:
            return False

        run = self.experiment

        for metric in evals_log.values():
            for metric_name, log in metric.items():
                if isinstance(log[-1], tuple):
                    score = log[-1][0]
                    stdv = log[-1][1]
                else:
                    score = log[-1]
                    stdv = None

                run.track(score, step=0, name=metric_name, context={"stdv": False})
                if stdv is not None:
                    run.track(stdv, step=0, name=metric_name, context={"stdv": True})

        return False

    @override
    def after_training(self, model: Any) -> Any:
        self.close()
        return model

    def close(self) -> None:
        if self._run:
            self._run.close()
            self._run = None

    def __del__(self) -> None:
        self.close()
