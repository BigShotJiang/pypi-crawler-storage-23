"""Shared helpers for adapter callbacks."""

from __future__ import annotations

DEFAULT_SYSTEM_TRACKING_INTERVAL: int = 10


def parse_context_prefix(
    name: str,
    prefixes: dict[str, str] | None = None,
) -> tuple[str, dict[str, str]]:
    """Strip a known prefix from *name* and return ``(clean_name, context)``.

    *prefixes* maps a context value to its prefix string, e.g.
    ``{"train": "train_", "val": "val_", "test": "test_"}``.
    """
    if prefixes is None:
        prefixes = {"train": "train_", "val": "val_", "test": "test_", "eval": "eval_"}
    for subset, prefix in prefixes.items():
        if name.startswith(prefix):
            return name[len(prefix) :], {"subset": subset}
    return name, {}


def is_number(value: object) -> bool:
    """Return ``True`` if *value* is a numeric scalar."""
    if isinstance(value, (int, float)):
        return True
    try:
        float(value)  # ty:ignore[invalid-argument-type]
    except (TypeError, ValueError):
        return False
    return True
