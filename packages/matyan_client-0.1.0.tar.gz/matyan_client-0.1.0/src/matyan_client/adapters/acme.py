"""DeepMind Acme callback and writer for logging to Matyan."""

from __future__ import annotations

from typing import Any

from matyan_client import Run

from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL

try:
    from acme.utils.loggers.base import Logger, LoggingData
except ImportError as _exc:
    msg = "This adapter requires DeepMind Acme. Install with: pip install dm-acme"
    raise RuntimeError(msg) from _exc


class AimCallback:
    def __init__(
        self,
        repo: str | None = None,
        experiment_name: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
        args: dict[str, Any] | None = None,
    ) -> None:
        self.repo = repo
        self.experiment_name = experiment_name
        self.system_tracking_interval = system_tracking_interval
        self.log_system_params = log_system_params
        self.capture_terminal_logs = capture_terminal_logs
        self._run: Run | None = None
        self._run_hash: str | None = None
        self.setup(args)

    @property
    def experiment(self) -> Run:
        if not self._run:
            self.setup()
        return self._run

    def setup(self, args: dict[str, Any] | None = None) -> None:
        if not self._run:
            if self._run_hash:
                self._run = Run(
                    self._run_hash,
                    repo=self.repo,
                    system_tracking_interval=self.system_tracking_interval,
                    log_system_params=self.log_system_params,
                    capture_terminal_logs=self.capture_terminal_logs,
                )
            else:
                self._run = Run(
                    repo=self.repo,
                    experiment=self.experiment_name,
                    system_tracking_interval=self.system_tracking_interval,
                    log_system_params=self.log_system_params,
                    capture_terminal_logs=self.capture_terminal_logs,
                )
                self._run_hash = self._run.hash

        if args:
            for key, value in args.items():
                self._run[key] = value

    def track(
        self,
        logs: Any,
        step: int | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        self._run.track(logs, step=step, context=context)

    def close(self) -> None:
        if self._run is not None:
            self._run.close()
            self._run = None


class AimWriter(Logger):
    """Acme Logger implementation backed by a Matyan run."""

    def __init__(
        self,
        aim_run: Run,
        logger_label: str,
        steps_key: str,
        task_id: int,
    ) -> None:
        self.aim_run = aim_run
        self.logger_label = logger_label
        self.steps_key = steps_key
        self.task_id = task_id

    def write(self, values: LoggingData) -> None:
        self.aim_run.track(values, context={"logger_label": self.logger_label})

    def close(self) -> None:
        if self.aim_run is not None:
            self.aim_run.close()
