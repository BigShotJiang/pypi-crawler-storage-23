"""Keras callback that logs metrics to Matyan."""

from __future__ import annotations

from matyan_client import Run

from ._keras_mixins import TrackerKerasCallbackMetricsEpochEndMixin
from ._utils import DEFAULT_SYSTEM_TRACKING_INTERVAL

try:
    from keras.callbacks import Callback
except ImportError as _exc:
    msg = "This adapter requires keras. Install with: pip install keras"
    raise RuntimeError(msg) from _exc


class AimCallback(TrackerKerasCallbackMetricsEpochEndMixin, Callback):
    def __init__(
        self,
        repo: str | None = None,
        experiment: str | None = None,
        system_tracking_interval: float | None = DEFAULT_SYSTEM_TRACKING_INTERVAL,
        log_system_params: bool = True,
        capture_terminal_logs: bool = True,
    ) -> None:
        super(Callback, self).__init__()

        self._system_tracking_interval = system_tracking_interval
        self._log_system_params = log_system_params
        self._capture_terminal_logs = capture_terminal_logs

        self._run = Run(
            repo=repo,
            experiment=experiment,
            system_tracking_interval=self._system_tracking_interval,
            log_system_params=self._log_system_params,
            capture_terminal_logs=self._capture_terminal_logs,
        )
        self._run_hash = self._run.hash
        self._repo_path = repo

    @property
    def experiment(self) -> Run:
        if not self._run:
            self._run = Run(
                self._run_hash,
                repo=self._repo_path,
                system_tracking_interval=self._system_tracking_interval,
                capture_terminal_logs=self._capture_terminal_logs,
            )
        return self._run

    def close(self) -> None:
        if self._run:
            self._run.close()
            self._run = None

    def __del__(self) -> None:
        self.close()
