"""Platform adapters for automatic experiment tracking with popular ML frameworks.

Each adapter module contains a callback/logger class that plugs into the
framework's training loop and logs metrics, hyperparameters, and system
information to Matyan.

All framework dependencies are optional; importing a specific adapter will
raise ``RuntimeError`` with installation instructions if the framework is
missing.

Quick-start examples::

    # Keras
    from matyan_client.adapters.keras import AimCallback
    model.fit(..., callbacks=[AimCallback(experiment="my-exp")])

    # PyTorch Lightning
    from matyan_client.adapters.pytorch_lightning import AimLogger
    trainer = Trainer(logger=AimLogger(experiment="my-exp"))

    # Hugging Face Transformers
    from matyan_client.adapters.hugging_face import AimCallback
    trainer = Trainer(..., callbacks=[AimCallback(experiment="my-exp")])
"""
