"""Aim-compatible Repo class for querying experiment data.

All operations go through the matyan-backend REST API.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import httpx
from loguru import logger

from .config import SETTINGS
from .run import Run
from .transport.http import HttpTransport

if TYPE_CHECKING:
    from collections.abc import Iterator


class Repo:
    """Repository client that talks to the matyan-backend REST API.

    Usage::

        repo = Repo("http://localhost:53800")
        for run_info in repo.iter_runs():
            print(run_info)
    """

    def __init__(self, url: str | None = None) -> None:
        self._url = url or SETTINGS.backend_url
        self._http = HttpTransport(self._url)

    # ------------------------------------------------------------------
    # Class methods (Aim compatibility)
    # ------------------------------------------------------------------

    @classmethod
    def default_repo(cls) -> Repo:
        return cls()

    @classmethod
    def from_path(cls, path: str) -> Repo:
        return cls(url=path)

    @staticmethod
    def is_remote_path(path: str) -> bool:
        return path.startswith(("http://", "https://"))

    @property
    def is_remote_repo(self) -> bool:
        return True

    # ------------------------------------------------------------------
    # Run access
    # ------------------------------------------------------------------

    def get_run(self, run_hash: str) -> Run | None:
        """Return a read-only Run proxy, or None if not found."""
        try:
            info = self._http.get_run_info(run_hash)
            if not info:
                return None
            return Run(run_hash=run_hash, repo=self._url, read_only=True)
        except httpx.HTTPError:
            logger.debug("Run not found or unreachable", run_hash=run_hash)
            return None

    def run_exists(self, run_hash: str) -> bool:
        return self.get_run(run_hash) is not None

    def iter_runs(self) -> Iterator[dict]:
        """Iterate over all runs (as info dicts)."""
        results = self._http.search_runs(query="")
        yield from results

    def list_all_runs(self) -> list[str]:
        """Return all run hashes."""
        runs = self._http.search_runs(query="")
        return [r.get("hash", r.get("run_id", "")) for r in runs]

    def list_active_runs(self) -> list[str]:
        runs = self._http.search_runs(query="run.active == True")
        return [r.get("hash", r.get("run_id", "")) for r in runs]

    def total_runs_count(self) -> int:
        return len(self.list_all_runs())

    # ------------------------------------------------------------------
    # Querying
    # ------------------------------------------------------------------

    _DEFAULT_PAGE_LIMIT = 50

    def query_runs(
        self,
        query: str = "",
        paginated: bool = False,
        offset: str | None = None,
        limit: int = _DEFAULT_PAGE_LIMIT,
    ) -> list[dict] | Iterator[list[dict]]:
        if not paginated:
            return self._http.search_runs(query=query, offset=offset)
        return self._iter_run_pages(query=query, limit=limit, offset=offset)

    def _iter_run_pages(
        self,
        query: str,
        limit: int,
        offset: str | None,
    ) -> Iterator[list[dict]]:
        while True:
            page = self._http.search_runs(query=query, limit=limit, offset=offset)
            if not page:
                break
            yield page
            if len(page) < limit:
                break
            last = page[-1]
            offset = last.get("hash", last.get("run_id"))

    def query_metrics(self, query: str = "") -> list[dict]:
        return self._http.search_metrics(query=query)

    def query_images(self, query: str = "") -> list[dict]:
        return self._http.search_sequence("images", query=query)

    def query_audios(self, query: str = "") -> list[dict]:
        return self._http.search_sequence("audios", query=query)

    def query_figure_objects(self, query: str = "") -> list[dict]:
        return self._http.search_sequence("figures", query=query)

    def query_distributions(self, query: str = "") -> list[dict]:
        return self._http.search_sequence("distributions", query=query)

    def query_texts(self, query: str = "") -> list[dict]:
        return self._http.search_sequence("texts", query=query)

    # ------------------------------------------------------------------
    # Run management
    # ------------------------------------------------------------------

    def delete_run(self, run_hash: str) -> bool:
        try:
            self._http.delete_run(run_hash)
        except httpx.HTTPError:
            logger.warning("Failed to delete run", run_hash=run_hash)
            return False
        else:
            return True

    def delete_runs(self, run_hashes: list[str]) -> tuple[bool, list[str]]:
        failed = [rh for rh in run_hashes if not self.delete_run(rh)]
        return len(failed) == 0, failed

    # ------------------------------------------------------------------
    # Experiment management
    # ------------------------------------------------------------------

    def delete_experiment(self, exp_id: str) -> bool:
        try:
            self._http.delete_experiment(exp_id)
        except httpx.HTTPError:
            logger.warning("Failed to delete experiment", exp_id=exp_id)
            return False
        else:
            return True

    # ------------------------------------------------------------------
    # Info aggregation
    # ------------------------------------------------------------------

    def collect_sequence_info(self, sequence_types: tuple[str, ...] = ("metric",)) -> dict[str, dict[str, list]]:
        """Collect sequence names/contexts across all runs."""
        result: dict[str, dict[str, list]] = {}
        for run_data in self.iter_runs():
            rh = run_data.get("hash", run_data.get("run_id", ""))
            if not rh:
                continue
            try:
                info = self._http.get_run_info(rh)
                traces = info.get("traces", {})
                for seq_type in sequence_types:
                    if seq_type in traces:
                        if rh not in result:
                            result[rh] = {}
                        result[rh][seq_type] = traces[seq_type]
            except httpx.HTTPError:
                logger.debug("Failed to fetch sequence info", run_hash=rh)
                continue
        return result

    def collect_params_info(self) -> dict:
        """Collect all runs' meta-parameters."""
        params: dict = {}
        for run_data in self.iter_runs():
            rh = run_data.get("hash", run_data.get("run_id", ""))
            if not rh:
                continue
            try:
                info = self._http.get_run_info(rh)
                params[rh] = info.get("params", {})
            except httpx.HTTPError:
                logger.debug("Failed to fetch params info", run_hash=rh)
                continue
        return params

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def available_sequence_types() -> list[str]:
        return ["metric", "images", "figures", "texts", "audios", "distributions"]

    def close(self) -> None:
        self._http.close()

    def __repr__(self) -> str:
        return f"Repo(url={self._url!r})"
