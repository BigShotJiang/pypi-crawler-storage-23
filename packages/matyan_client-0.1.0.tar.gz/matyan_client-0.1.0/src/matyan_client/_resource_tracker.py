"""Background resource tracker for system metrics and terminal log capture.

Adapted from ``aim/aim/ext/resource/tracker.py``.  Runs a single daemon
thread that periodically collects CPU/memory/disk/GPU stats and (optionally)
captures ``sys.stdout`` / ``sys.stderr`` output.
"""

from __future__ import annotations

import io
import re
import sys
import time
from threading import Event, Thread
from typing import TYPE_CHECKING
from weakref import WeakValueDictionary

from loguru import logger

if TYPE_CHECKING:
    from collections.abc import Callable

METRIC_PREFIX = "__system__"

STAT_INTERVAL_MIN = 0.1
STAT_INTERVAL_MAX = 86400.0  # 24 hours
_LOG_CAPTURE_INTERVAL = 1.0  # seconds
_TICK = 0.1  # main-loop sleep granularity

_ANSI_CSI_RE = re.compile(rb"\001?\033\[((?:\d|;)*)([a-dA-D])\002?")


class ResourceTracker:
    """Collects system resource metrics and/or terminal logs in the background.

    Parameters
    ----------
    track_fn:
        ``(value, name, context) -> None`` — called for each metric sample.
    interval:
        Seconds between system-stat collections.  ``None`` disables stats.
    capture_logs:
        If ``True``, intercept ``sys.stdout`` / ``sys.stderr``.
    send_terminal_line_fn:
        ``(line, step) -> None`` — called for each captured terminal line.
    log_offset:
        Starting step number for terminal lines (for resume).

    """

    _buffer_registry: WeakValueDictionary[int, io.BytesIO] = WeakValueDictionary()
    _old_out_write: Callable | None = None
    _old_err_write: Callable | None = None
    _patches_installed: bool = False

    # ------------------------------------------------------------------
    # Class-level stdout/stderr patching
    # ------------------------------------------------------------------

    @classmethod
    def _install_stream_patches(cls) -> None:
        if cls._patches_installed:
            return
        cls._old_out_write = sys.stdout.write
        cls._old_err_write = sys.stderr.write

        def _new_out_write(data: str) -> int:
            result = cls._old_out_write(data)  # type: ignore[misc]
            raw = data.encode() if isinstance(data, str) else data
            for buf in cls._buffer_registry.values():
                buf.write(raw)
            return result

        def _new_err_write(data: str) -> int:
            result = cls._old_err_write(data)  # type: ignore[misc]
            raw = data.encode() if isinstance(data, str) else data
            for buf in cls._buffer_registry.values():
                buf.write(raw)
            return result

        sys.stdout.write = _new_out_write  # type: ignore[assignment]
        sys.stderr.write = _new_err_write  # type: ignore[assignment]
        cls._patches_installed = True

    @classmethod
    def _uninstall_stream_patches(cls) -> None:
        if not cls._patches_installed:
            return
        if cls._old_out_write is not None:
            sys.stdout.write = cls._old_out_write  # type: ignore[assignment]
        if cls._old_err_write is not None:
            sys.stderr.write = cls._old_err_write  # type: ignore[assignment]
        cls._patches_installed = False

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    @classmethod
    def check_interval(cls, interval: float | None, *, warn: bool = True) -> bool:
        """Return ``True`` if *interval* is a valid stat-collection interval."""
        if interval is None:
            return False
        if not isinstance(interval, (int, float)) or not (STAT_INTERVAL_MIN <= interval <= STAT_INTERVAL_MAX):
            if warn:
                logger.warning(
                    "system_tracking_interval must be between {} and {} seconds",
                    STAT_INTERVAL_MIN,
                    STAT_INTERVAL_MAX,
                )
            return False
        return True

    # ------------------------------------------------------------------
    # Init / lifecycle
    # ------------------------------------------------------------------

    def __init__(
        self,
        *,
        track_fn: Callable[[float, str, dict | None], None],
        interval: float | None = None,
        capture_logs: bool = False,
        send_terminal_line_fn: Callable[[str, int], None] | None = None,
        log_offset: int = 0,
    ) -> None:
        self._track_fn = track_fn
        self._stat_interval: float | None = interval if self.check_interval(interval, warn=False) else None
        self._capture_logs = capture_logs
        self._send_line_fn = send_terminal_line_fn
        self._line_counter = log_offset

        self._io_buffer = io.BytesIO()
        self._shutdown = Event()
        self._started = False
        self._thread: Thread | None = None

        self._process = None
        if self._stat_interval is not None:
            try:
                import psutil  # noqa: PLC0415

                self._process = psutil.Process()
                psutil.cpu_percent(0.0)
            except Exception:  # noqa: BLE001
                logger.debug("psutil unavailable; system stats disabled")
                self._stat_interval = None

    def start(self) -> None:
        if self._started:
            return
        if self._stat_interval is None and not self._capture_logs:
            return
        self._started = True
        if self._capture_logs:
            if not self._buffer_registry:
                self._install_stream_patches()
            self._buffer_registry[id(self)] = self._io_buffer
        self._thread = Thread(target=self._loop, daemon=True, name="matyan-resource-tracker")
        self._thread.start()

    def stop(self) -> None:
        if not self._started:
            return
        self._shutdown.set()
        if self._thread is not None:
            self._thread.join(timeout=5)
        if self._capture_logs:
            self._flush_logs()
            self._buffer_registry.pop(id(self), None)
            if not self._buffer_registry:
                self._uninstall_stream_patches()
        self._started = False

    # ------------------------------------------------------------------
    # Main collection loop
    # ------------------------------------------------------------------

    def _loop(self) -> None:
        stat_elapsed = 0.0
        log_elapsed = 0.0

        if self._stat_interval is not None:
            self._collect_stats()

        while not self._shutdown.is_set():
            time.sleep(_TICK)
            stat_elapsed += _TICK
            log_elapsed += _TICK

            if self._stat_interval is not None and stat_elapsed >= self._stat_interval:
                self._collect_stats()
                stat_elapsed = 0.0

            if self._capture_logs and log_elapsed >= _LOG_CAPTURE_INTERVAL:
                self._flush_logs()
                log_elapsed = 0.0

    # ------------------------------------------------------------------
    # System stats
    # ------------------------------------------------------------------

    def _collect_stats(self) -> None:
        try:
            self._collect_system_stats()
        except Exception:  # noqa: BLE001
            logger.debug("Error collecting system stats")
        try:
            self._collect_gpu_stats()
        except Exception:  # noqa: BLE001
            logger.debug("GPU stats collection failed", exc_info=True)

    def _collect_system_stats(self) -> None:
        import psutil  # noqa: PLC0415

        proc = self._process
        if proc is None:
            return

        metrics = {
            "cpu": round(proc.cpu_percent(0.0), 5),
            "p_memory_percent": round(proc.memory_percent(), 5),
            "memory_percent": round(psutil.virtual_memory().percent, 5),
            "disk_percent": round(psutil.disk_usage("/").percent, 5),
        }
        for name, value in metrics.items():
            self._track_fn(value, f"{METRIC_PREFIX}{name}", None)

    def _collect_gpu_stats(self) -> None:
        try:
            import pynvml  # noqa: PLC0415  # pyright: ignore[reportMissingImports]
        except ImportError:
            logger.debug("pynvml unavailable; GPU stats disabled")
            return

        try:
            pynvml.nvmlInit()
        except pynvml.NVMLError:
            logger.debug("NVML initialization failed", exc_info=True)
            return

        try:
            count = pynvml.nvmlDeviceGetCount()
            for idx in range(count):
                handle = pynvml.nvmlDeviceGetHandleByIndex(idx)
                ctx = {"gpu": idx}
                try:
                    util = pynvml.nvmlDeviceGetUtilizationRates(handle)
                    self._track_fn(round(util.gpu, 5), f"{METRIC_PREFIX}gpu", ctx)
                except pynvml.NVMLError:
                    logger.debug("GPU {} utilization query failed", idx, exc_info=True)
                try:
                    mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
                    pct = round(mem.used * 100 / mem.total, 5) if mem.total else 0.0
                    self._track_fn(pct, f"{METRIC_PREFIX}gpu_memory_percent", ctx)
                except pynvml.NVMLError:
                    logger.debug("GPU {} memory query failed", idx, exc_info=True)
                try:
                    temp = pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU)
                    self._track_fn(round(float(temp), 5), f"{METRIC_PREFIX}gpu_temp", ctx)
                except pynvml.NVMLError:
                    logger.debug("GPU {} temperature query failed", idx, exc_info=True)
                try:
                    power = pynvml.nvmlDeviceGetPowerUsage(handle) / 1000
                    self._track_fn(round(power, 5), f"{METRIC_PREFIX}gpu_power_watts", ctx)
                except pynvml.NVMLError:
                    logger.debug("GPU {} power query failed", idx, exc_info=True)
        finally:
            try:
                pynvml.nvmlShutdown()
            except pynvml.NVMLError:
                logger.debug("NVML shutdown failed", exc_info=True)

    # ------------------------------------------------------------------
    # Terminal log capture
    # ------------------------------------------------------------------

    def _flush_logs(self) -> None:
        if self._send_line_fn is None:
            return
        buf_size = self._io_buffer.tell()
        if not buf_size:
            return

        self._io_buffer.seek(0)
        data = self._io_buffer.read(buf_size)
        self._io_buffer.seek(0)
        self._io_buffer.truncate()

        lines = data.split(b"\n")
        for line in lines:
            line = self._strip_ansi(line)  # noqa: PLW2901
            line = line.rsplit(b"\r", maxsplit=1)[-1]  # noqa: PLW2901
            try:
                text = line.decode("utf-8", errors="replace")
            except Exception:  # noqa: BLE001
                logger.debug("Failed to decode terminal line", exc_info=True)
                continue
            self._send_line_fn(text, self._line_counter)
            self._line_counter += 1

        # last line without trailing newline stays in counter
        self._line_counter -= 1
        if lines[-1] != b"":
            self._io_buffer.write(lines[-1])

    @staticmethod
    def _strip_ansi(line: bytes) -> bytes:
        return re.sub(_ANSI_CSI_RE, b"", line)
