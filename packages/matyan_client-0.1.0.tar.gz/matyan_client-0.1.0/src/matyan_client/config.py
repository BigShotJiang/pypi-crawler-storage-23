from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="MATYAN_")

    frontier_url: str = "http://localhost:53801"
    backend_url: str = "http://localhost:53800"
    s3_endpoint: str = "http://localhost:9000"

    ws_queue_max_memory_mb: int = 512
    ws_heartbeat_interval: int = 10
    ws_batch_interval_ms: int = 50
    ws_batch_size: int = 100
    ws_retry_count: int = 2


SETTINGS = Settings()
