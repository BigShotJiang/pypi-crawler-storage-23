"""Background blob uploader using a thread pool.

Presigned-URL acquisition and S3 PUT uploads run in worker threads so that
``run.track(Image(...))`` returns immediately without blocking the training
loop.
"""

from __future__ import annotations

from concurrent.futures import Future, ThreadPoolExecutor
from typing import TYPE_CHECKING

import httpx
from loguru import logger

if TYPE_CHECKING:
    from .transport.http import HttpTransport

_MAX_WORKERS = 4


class BlobUploader:
    """Manages background S3 blob uploads via presigned URLs."""

    def __init__(
        self,
        http: HttpTransport,
        frontier_url: str,
        run_id: str,
    ) -> None:
        self._http = http
        self._frontier_url = frontier_url
        self._run_id = run_id
        self._pool = ThreadPoolExecutor(max_workers=_MAX_WORKERS, thread_name_prefix="blob-upload")
        self._futures: list[Future[None]] = []

    def submit(
        self,
        raw_bytes: bytes,
        artifact_path: str,
        content_type: str,
    ) -> str:
        """Submit a blob upload and return the deterministic ``s3_key`` immediately."""
        s3_key = f"{self._run_id}/{artifact_path}"
        fut = self._pool.submit(self._upload, raw_bytes, artifact_path, content_type, s3_key)
        self._futures.append(fut)
        return s3_key

    def _upload(self, raw_bytes: bytes, artifact_path: str, content_type: str, s3_key: str) -> None:
        try:
            resp = self._http.presign_artifact(
                self._frontier_url,
                self._run_id,
                artifact_path,
                content_type=content_type,
            )
            upload_resp = httpx.put(
                resp["upload_url"],
                content=raw_bytes,
                headers={"Content-Type": content_type},
                timeout=120,
            )
            upload_resp.raise_for_status()
        except httpx.HTTPError:
            logger.exception("Background blob upload failed", s3_key=s3_key)

    def drain(self, timeout: float = 60.0) -> int:
        """Wait for all pending uploads to finish. Returns the number of failures."""
        failures = 0
        for fut in self._futures:
            try:
                fut.result(timeout=timeout)
            except TimeoutError:  # noqa: PERF203
                failures += 1
                logger.warning("Blob upload timed out after {:.0f}s", timeout)
            except httpx.HTTPError:
                failures += 1
                logger.exception("Blob upload failed with HTTP error")
            except Exception:  # noqa: BLE001
                failures += 1
                logger.exception("Blob upload failed with unexpected error")
        self._futures.clear()
        return failures

    @property
    def pending(self) -> int:
        return sum(1 for f in self._futures if not f.done())

    def shutdown(self, timeout: float = 60.0) -> None:
        """Drain pending uploads and shut down the thread pool."""
        failures = self.drain(timeout=timeout)
        if failures:
            logger.warning("{} blob upload(s) failed during shutdown", failures)
        self._pool.shutdown(wait=False)
