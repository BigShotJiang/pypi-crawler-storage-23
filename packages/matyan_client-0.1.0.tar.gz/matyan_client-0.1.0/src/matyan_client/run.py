"""Aim-compatible Run class for experiment tracking.

Preserves the original Aim SDK public API while routing data through the
matyan infrastructure (frontier WebSocket for ingestion, backend REST for
metadata).
"""

from __future__ import annotations

import contextlib
import inspect
import time
import uuid
import weakref
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar

import httpx
from loguru import logger

from ._blob_uploader import BlobUploader as _BlobUploader
from ._cache import WriteCache
from ._resource_tracker import ResourceTracker as _ResourceTracker
from .config import SETTINGS
from .transport.http import HttpTransport
from .transport.ws import WsTransport

if TYPE_CHECKING:
    from collections.abc import Iterator

    from ._types import AimObject, Context

_global_cache = WriteCache()


class Run:
    """A single experiment run.

    Usage::

        run = Run(experiment="baseline")
        run["hparams"] = {"lr": 0.01, "batch_size": 32}
        for step in range(100):
            run.track(loss, name="loss", step=step, context={"subset": "train"})
        run.close()
    """

    _instances: ClassVar[list[Run]] = []

    def __init__(
        self,
        run_hash: str | None = None,
        *,
        repo: str | None = None,
        read_only: bool = False,
        experiment: str | None = None,
        force_resume: bool = False,
        system_tracking_interval: float | None = None,
        log_system_params: bool | None = False,
        capture_terminal_logs: bool | None = True,
    ) -> None:
        self._hash = run_hash or uuid.uuid4().hex
        self._read_only = read_only
        self._experiment: str | None = experiment
        self._name: str | None = None
        self._description: str | None = None
        self._archived = False
        self._creation_time = datetime.now(timezone.utc).timestamp()
        self._end_time: float | None = None
        self._active = True
        self._closed = False

        backend_url = SETTINGS.backend_url
        frontier_url = SETTINGS.frontier_url
        if repo is not None:
            backend_url = repo

        self._http = HttpTransport(backend_url)
        self._ws: WsTransport | None = None
        self._blob_uploader: _BlobUploader | None = None
        self._step_counters: dict[str, int] = {}

        if not read_only:
            self._ws = WsTransport(frontier_url, self._hash)
            self._ws.send_create_run(force_resume=force_resume)
            self._blob_uploader = _BlobUploader(self._http, frontier_url, self._hash)

            if experiment:
                self._ws.send_set_run_property(experiment=experiment)

            if log_system_params:
                from ._system_params import collect_system_params  # noqa: PLC0415

                self["__system_params"] = collect_system_params()

        self._resource_tracker = None
        needs_stats = not read_only and _ResourceTracker.check_interval(system_tracking_interval, warn=False)
        needs_logs = bool(capture_terminal_logs) and not read_only
        if needs_stats or needs_logs:
            self._resource_tracker = _ResourceTracker(
                track_fn=self._track_system_metric,
                interval=system_tracking_interval if needs_stats else None,
                capture_logs=needs_logs,
                send_terminal_line_fn=self._send_terminal_line if needs_logs else None,
            )
            self._resource_tracker.start()

        weakref.finalize(self, self._weak_cleanup, self._hash)
        self._instances.append(self)

    # ------------------------------------------------------------------
    # Identity
    # ------------------------------------------------------------------

    @property
    def hash(self) -> str:
        return self._hash

    # ------------------------------------------------------------------
    # Properties (getter / setter)  # noqa: ERA001
    # ------------------------------------------------------------------

    @property
    def name(self) -> str | None:
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value
        _global_cache.set(self._hash, "__props__.name", value)
        if not self._read_only and self._ws:
            self._ws.send_set_run_property(name=value)

    @property
    def description(self) -> str | None:
        return self._description

    @description.setter
    def description(self, value: str) -> None:
        self._description = value
        _global_cache.set(self._hash, "__props__.description", value)
        if not self._read_only and self._ws:
            self._ws.send_set_run_property(description=value)

    @property
    def archived(self) -> bool:
        return self._archived

    @archived.setter
    def archived(self, value: bool) -> None:
        self._archived = value
        _global_cache.set(self._hash, "__props__.archived", value)
        if not self._read_only and self._ws:
            self._ws.send_set_run_property(archived=value)

    @property
    def experiment(self) -> str | None:
        return self._experiment

    @experiment.setter
    def experiment(self, value: str | None) -> None:
        self._experiment = value
        _global_cache.set(self._hash, "__props__.experiment", value)
        if not self._read_only and self._ws and value is not None:
            self._ws.send_set_run_property(experiment=value)

    @property
    def tags(self) -> list[str]:
        """Return tag names from the backend."""
        try:
            info = self._http.get_run_info(self._hash)
            return [t.get("name", "") for t in info.get("props", {}).get("tags", [])]
        except httpx.HTTPError:
            logger.debug("Failed to fetch tags from backend", run_id=self._hash)
            return []

    @property
    def creation_time(self) -> float:
        return self._creation_time

    @property
    def created_at(self) -> datetime:
        return datetime.fromtimestamp(self._creation_time, tz=timezone.utc)

    @property
    def end_time(self) -> float | None:
        return self._end_time

    @property
    def finalized_at(self) -> datetime | None:
        return datetime.fromtimestamp(self._end_time, tz=timezone.utc) if self._end_time else None

    @property
    def duration(self) -> float | None:
        if self._end_time is not None:
            return self._end_time - self._creation_time
        return None

    @property
    def active(self) -> bool:
        return self._active

    @property
    def props(self) -> dict:
        """Fetch full props from backend."""
        try:
            info = self._http.get_run_info(self._hash)
            return info.get("props", {})
        except httpx.HTTPError:
            logger.debug("Failed to fetch props from backend", run_id=self._hash)
            return {}

    # ------------------------------------------------------------------
    # Dictionary interface (__setitem__ / __getitem__)
    # ------------------------------------------------------------------

    def __setitem__(self, key: str, val: AimObject) -> None:
        _global_cache.set(self._hash, key, val)
        if not self._read_only and self._ws:
            self._ws.send_log_hparams(_nest_key(key, val))

    def __getitem__(self, key: str) -> Any:  # noqa: ANN401
        cached = _global_cache.get(self._hash, key)
        if cached is not None:
            return cached

        try:
            info = self._http.get_run_info(self._hash)
            params = info.get("params", {})
            return _resolve_dotted(params, key)
        except httpx.HTTPError:
            msg = f"Key {key!r} not found for run {self._hash}"
            raise KeyError(msg) from None

    def __delitem__(self, key: str) -> None:
        _global_cache.set(self._hash, key, None)

    def set(self, key: str, val: AimObject) -> None:
        self[key] = val

    def get(self, key: str, default: Any = None) -> Any:  # noqa: ANN401
        try:
            return self[key]
        except KeyError:
            return default

    # ------------------------------------------------------------------
    # Tracking
    # ------------------------------------------------------------------

    def track(
        self,
        value: Any,  # noqa: ANN401
        name: str | None = None,
        step: int | None = None,
        epoch: int | None = None,
        *,
        context: Context | None = None,
    ) -> None:
        """Track a value (scalar, custom object, etc.)."""
        if self._read_only:
            msg = "Cannot track on a read-only run"
            raise RuntimeError(msg)
        if name is None:
            msg = "metric `name` is required"
            raise ValueError(msg)

        if self._ws is None:
            msg = "WebSocket transport not initialized"
            raise RuntimeError(msg)

        if step is None:
            counter_key = f"{name}:{id(context)}"
            step = self._step_counters.get(counter_key, 0)
            self._step_counters[counter_key] = step + 1

        if hasattr(value, "json") and callable(value.json):
            serialized = value.json()
            dtype = serialized.get("type", type(value).__name__)
            metadata = self._upload_blob_if_needed(serialized, name, step)
            self._ws.send_log_custom_object(
                name=name,
                value=metadata,
                step=step,
                epoch=epoch,
                context=context,
                dtype=dtype,
            )
        else:
            self._ws.send_log_metric(
                name=name,
                value=float(value),
                step=step,
                epoch=epoch,
                context=context,
                dtype=type(value).__name__,
            )

    def _upload_blob_if_needed(self, serialized: dict, name: str, step: int) -> dict:
        """For Image/Audio, submit a background S3 upload and return metadata immediately."""
        obj_type = serialized.get("type", "")
        if obj_type not in ("image", "audio") or "data" not in serialized:
            return serialized

        import base64  # noqa: PLC0415

        raw_bytes = base64.b64decode(serialized["data"])
        fmt = serialized.get("format", "bin").lower()
        content_type = _CONTENT_TYPES.get(obj_type, {}).get(fmt, "application/octet-stream")
        artifact_path = f"seq/{name}/{step}.{fmt}"

        metadata = {k: v for k, v in serialized.items() if k != "data"}
        if self._blob_uploader is not None:
            s3_key = self._blob_uploader.submit(raw_bytes, artifact_path, content_type)
        else:
            s3_key = f"{self._hash}/{artifact_path}"
        metadata["s3_key"] = s3_key
        return metadata

    # ------------------------------------------------------------------
    # Tags
    # ------------------------------------------------------------------

    def add_tag(self, value: str) -> None:
        if self._read_only:
            return
        if self._ws:
            self._ws.send_add_tag(value)
        else:
            self._http.add_tag_to_run(self._hash, value)

    def remove_tag(self, tag_name: str) -> None:
        if self._read_only:
            return
        if self._ws:
            self._ws.send_remove_tag(tag_name)
        else:
            try:
                info = self._http.get_run_info(self._hash)
                tags = info.get("props", {}).get("tags", [])
                for t in tags:
                    if t.get("name") == tag_name:
                        self._http.remove_tag_from_run(self._hash, t["id"])
                        return
            except httpx.HTTPError:
                logger.warning("Failed to remove tag from run", tag=tag_name, run_id=self._hash)

    # ------------------------------------------------------------------
    # Logging (structured log records)
    # ------------------------------------------------------------------

    def _log_message(self, level: int, msg: str, **params: Any) -> None:  # noqa: ANN401
        if self._read_only or self._ws is None:
            return

        frame = inspect.currentframe()
        logger_info: list | None = None
        if frame and frame.f_back and frame.f_back.f_back:
            caller = frame.f_back.f_back
            logger_info = [caller.f_code.co_filename, caller.f_lineno]

        self._ws.send_log_record(
            message=msg,
            level=level,
            timestamp=time.time(),
            logger_info=logger_info,
            extra_args=params or None,
        )

    def log_info(self, msg: str, **kwargs: Any) -> None:  # noqa: ANN401
        self._log_message(20, msg, **kwargs)

    def log_warning(self, msg: str, **kwargs: Any) -> None:  # noqa: ANN401
        self._log_message(30, msg, **kwargs)

    def log_error(self, msg: str, **kwargs: Any) -> None:  # noqa: ANN401
        self._log_message(40, msg, **kwargs)

    def log_debug(self, msg: str, **kwargs: Any) -> None:  # noqa: ANN401
        self._log_message(10, msg, **kwargs)

    # ------------------------------------------------------------------
    # Artifacts
    # ------------------------------------------------------------------

    def log_artifact(self, path: str, name: str | None = None) -> None:
        """Upload an artifact file via presigned S3 URL (non-blocking)."""
        artifact_path = name or Path(path).name
        data = Path(path).read_bytes()
        if self._blob_uploader is not None:
            self._blob_uploader.submit(data, artifact_path, "application/octet-stream")
        else:
            resp = self._http.presign_artifact(
                SETTINGS.frontier_url,
                self._hash,
                artifact_path,
            )
            upload_resp = httpx.put(
                resp["upload_url"],
                content=data,
                headers={"Content-Type": "application/octet-stream"},
                timeout=120,
            )
            upload_resp.raise_for_status()

    def log_artifacts(self, path: str, name: str | None = None) -> None:
        """Upload a directory of artifacts."""
        from pathlib import Path  # noqa: PLC0415

        base = Path(path)
        for f in base.rglob("*"):
            if f.is_file():
                rel = str(f.relative_to(base))
                prefix = f"{name}/{rel}" if name else rel
                self.log_artifact(str(f), name=prefix)

    # ------------------------------------------------------------------
    # Sequences / metrics (read)  # noqa: ERA001
    # ------------------------------------------------------------------

    def metrics(self) -> list[dict]:
        """Return an overview of all tracked metrics for this run."""
        try:
            info = self._http.get_run_info(self._hash)
            return info.get("traces", {}).get("metric", [])
        except httpx.HTTPError:
            logger.debug("Failed to fetch metrics from backend", run_id=self._hash)
            return []

    def get_metric(self, name: str, context: Context | None = None) -> dict | None:
        for m in self.metrics():
            if m.get("name") == name and m.get("context", {}) == (context or {}):
                return m
        return None

    def iter_metrics_info(self) -> Iterator[tuple[str, dict, Run]]:
        for m in self.metrics():
            yield m.get("name", ""), m.get("context", {}), self

    def collect_sequence_info(
        self,
        sequence_types: str | tuple[str, ...] = (),
    ) -> dict[str, list]:
        seq = (sequence_types,) if isinstance(sequence_types, str) else tuple(sequence_types)
        try:
            info = self._http.get_run_info(self._hash, sequence=seq)
            return info.get("traces", {})
        except httpx.HTTPError:
            logger.debug("Failed to fetch sequence info from backend", run_id=self._hash)
            return {}

    # ------------------------------------------------------------------
    # Internal helpers for ResourceTracker callbacks
    # ------------------------------------------------------------------

    def _track_system_metric(self, value: float, name: str, context: dict | None = None) -> None:
        """Track a single system-resource metric via the WS transport."""
        if self._read_only or self._ws is None:
            return
        self.track(value, name=name, context=context)

    def _send_terminal_line(self, line: str, step: int) -> None:
        """Send a captured terminal output line via the WS transport."""
        if self._read_only or self._ws is None:
            return
        self._ws.send_log_terminal_line(line, step)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._active = False
        self._end_time = datetime.now(timezone.utc).timestamp()

        if self._resource_tracker is not None:
            self._resource_tracker.stop()
            self._resource_tracker = None

        if self._blob_uploader is not None:
            self._blob_uploader.shutdown()
            self._blob_uploader = None

        if self._ws:
            self._ws.send_finish_run()
            self._ws.close()
            self._ws = None

        self._http.close()
        _global_cache.clear(self._hash)

        with contextlib.suppress(ValueError):
            self._instances.remove(self)

    @staticmethod
    def _weak_cleanup(run_hash: str) -> None:
        logger.debug("GC cleanup for run {}", run_hash)
        _global_cache.clear(run_hash)

    def __repr__(self) -> str:
        return f"Run(hash={self._hash!r}, experiment={self._experiment!r})"

    def __del__(self) -> None:
        if not self._closed:
            with contextlib.suppress(Exception):
                self.close()


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


_CONTENT_TYPES: dict[str, dict[str, str]] = {
    "image": {
        "png": "image/png",
        "jpeg": "image/jpeg",
        "jpg": "image/jpeg",
        "gif": "image/gif",
        "bmp": "image/bmp",
        "webp": "image/webp",
    },
    "audio": {
        "wav": "audio/wav",
        "mp3": "audio/mpeg",
        "flac": "audio/flac",
        "ogg": "audio/ogg",
    },
}


def _nest_key(key: str, val: Any) -> dict:  # noqa: ANN401
    """Convert ``"hparams"`` + ``{"lr": 0.01}`` to ``{"hparams": {"lr": 0.01}}``."""
    parts = key.split(".")
    result = val
    for part in reversed(parts):
        result = {part: result}
    return result


def _resolve_dotted(d: dict, key: str) -> Any:  # noqa: ANN401
    """Resolve ``"hparams.lr"`` from a nested dict."""
    parts = key.split(".")
    current = d
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            msg = f"Key {key!r} not found"
            raise KeyError(msg)
    return current
