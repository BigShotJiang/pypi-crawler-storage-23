"""Tests for matyan_client.transport.http — HttpTransport + binary decoder."""

from __future__ import annotations

import struct
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import httpx
import pytest
import respx

from matyan_client.transport.http import (
    _SKIP,
    _STRUCT_BE_Q,
    _TYPE_ARRAY,
    _TYPE_BOOL,
    _TYPE_BYTES,
    _TYPE_FLOAT,
    _TYPE_INT,
    _TYPE_NONE,
    _TYPE_OBJECT,
    _TYPE_STRING,
    HttpTransport,
    _decode_path,
    _decode_streaming_response,
    _decode_value,
    _fold_tree,
    _set_nested,
)

if TYPE_CHECKING:
    from collections.abc import Generator

BASE = "http://test-backend:53800"


@pytest.fixture
def transport() -> Generator[HttpTransport]:
    t = HttpTransport(BASE)
    yield t
    t.close()


# ------------------------------------------------------------------
# Generic helpers
# ------------------------------------------------------------------


class TestGenericHelpers:
    @respx.mock
    def test_get(self, transport: HttpTransport) -> None:
        respx.get(f"{BASE}/api/v1/rest/projects/").mock(return_value=httpx.Response(200, json={"name": "test"}))
        result = transport.get("/api/v1/rest/projects/")
        assert result == {"name": "test"}

    @respx.mock
    def test_put(self, transport: HttpTransport) -> None:
        respx.put(f"{BASE}/api/v1/rest/runs/r1/").mock(return_value=httpx.Response(200, json={"status": "ok"}))
        result = transport.put("/api/v1/rest/runs/r1/", json={"name": "new"})
        assert result == {"status": "ok"}

    @respx.mock
    def test_post(self, transport: HttpTransport) -> None:
        respx.post(f"{BASE}/api/v1/rest/experiments/").mock(return_value=httpx.Response(200, json={"id": "123"}))
        result = transport.post("/api/v1/rest/experiments/", json={"name": "exp"})
        assert result == {"id": "123"}

    @respx.mock
    def test_delete(self, transport: HttpTransport) -> None:
        respx.delete(f"{BASE}/api/v1/rest/runs/r1/").mock(return_value=httpx.Response(200, json={"status": "deleted"}))
        result = transport.delete("/api/v1/rest/runs/r1/")
        assert result == {"status": "deleted"}

    @respx.mock
    def test_get_raises_on_error(self, transport: HttpTransport) -> None:
        respx.get(f"{BASE}/api/v1/rest/projects/").mock(return_value=httpx.Response(500, text="error"))
        with pytest.raises(httpx.HTTPStatusError):
            transport.get("/api/v1/rest/projects/")

    @respx.mock
    def test_put_default_json(self, transport: HttpTransport) -> None:
        route = respx.put(f"{BASE}/api/v1/rest/runs/r1/").mock(return_value=httpx.Response(200, json={}))
        transport.put("/api/v1/rest/runs/r1/")
        assert route.called

    @respx.mock
    def test_post_default_json(self, transport: HttpTransport) -> None:
        route = respx.post(f"{BASE}/api/v1/rest/experiments/").mock(return_value=httpx.Response(200, json={}))
        transport.post("/api/v1/rest/experiments/")
        assert route.called


# ------------------------------------------------------------------
# Run operations
# ------------------------------------------------------------------


class TestGetStream:
    @respx.mock
    def test_get_stream(self, transport: HttpTransport) -> None:
        respx.get(f"{BASE}/api/v1/rest/runs/search/run/").mock(
            return_value=httpx.Response(200, text="streaming content"),
        )
        with transport.get_stream("/api/v1/rest/runs/search/run/") as resp:
            assert resp.status_code == 200


class TestRunOperations:
    @respx.mock
    def test_get_run_info(self, transport: HttpTransport) -> None:
        respx.get(f"{BASE}/api/v1/rest/runs/hash1/info/").mock(
            return_value=httpx.Response(200, json={"params": {"lr": 0.01}}),
        )
        result = transport.get_run_info("hash1")
        assert result["params"]["lr"] == 0.01

    @respx.mock
    def test_get_run_info_with_sequence(self, transport: HttpTransport) -> None:
        route = respx.get(f"{BASE}/api/v1/rest/runs/hash1/info/").mock(
            return_value=httpx.Response(200, json={"traces": {}}),
        )
        transport.get_run_info("hash1", sequence=("metric", "images"))
        assert route.called

    @respx.mock
    def test_update_run(self, transport: HttpTransport) -> None:
        respx.put(f"{BASE}/api/v1/rest/runs/h1/").mock(return_value=httpx.Response(200, json={"status": "ok"}))
        result = transport.update_run("h1", name="new_name")
        assert result["status"] == "ok"

    @respx.mock
    def test_delete_run(self, transport: HttpTransport) -> None:
        respx.delete(f"{BASE}/api/v1/rest/runs/h1/").mock(return_value=httpx.Response(200, json={}))
        transport.delete_run("h1")

    @respx.mock
    def test_delete_runs_batch(self, transport: HttpTransport) -> None:
        respx.post(f"{BASE}/api/v1/rest/runs/delete-batch/").mock(return_value=httpx.Response(200, json={}))
        transport.delete_runs_batch(["h1", "h2"])

    @respx.mock
    def test_add_tag_to_run(self, transport: HttpTransport) -> None:
        respx.post(f"{BASE}/api/v1/rest/runs/h1/tags/new/").mock(return_value=httpx.Response(200, json={}))
        transport.add_tag_to_run("h1", "my-tag")

    @respx.mock
    def test_remove_tag_from_run(self, transport: HttpTransport) -> None:
        respx.delete(f"{BASE}/api/v1/rest/runs/h1/tags/tid/").mock(return_value=httpx.Response(200, json={}))
        transport.remove_tag_from_run("h1", "tid")


# ------------------------------------------------------------------
# Search endpoints
# ------------------------------------------------------------------


class TestSearch:
    @respx.mock
    def test_search_runs_empty(self, transport: HttpTransport) -> None:
        respx.get(f"{BASE}/api/v1/rest/runs/search/run/").mock(return_value=httpx.Response(200, content=b""))
        result = transport.search_runs()
        assert result == []

    @respx.mock
    def test_search_runs_with_limit_offset(self, transport: HttpTransport) -> None:
        route = respx.get(f"{BASE}/api/v1/rest/runs/search/run/").mock(return_value=httpx.Response(200, content=b""))
        transport.search_runs(query="run.active==True", limit=10, offset="abc")
        assert route.called
        req = route.calls[0].request
        assert b"limit=10" in req.url.raw_path
        assert b"offset=abc" in req.url.raw_path

    @respx.mock
    def test_search_runs_http_error(self, transport: HttpTransport) -> None:
        respx.get(f"{BASE}/api/v1/rest/runs/search/run/").mock(return_value=httpx.Response(500, text="error"))
        result = transport.search_runs()
        assert result == []

    @respx.mock
    def test_search_metrics_delegates(self, transport: HttpTransport) -> None:
        route = respx.get(f"{BASE}/api/v1/rest/runs/search/metric/").mock(return_value=httpx.Response(200, content=b""))
        transport.search_metrics(query="metric.name == 'loss'")
        assert route.called

    @respx.mock
    def test_search_sequence_custom_type(self, transport: HttpTransport) -> None:
        route = respx.get(f"{BASE}/api/v1/rest/runs/search/images/").mock(return_value=httpx.Response(200, content=b""))
        transport.search_sequence("images", query="")
        assert route.called

    @respx.mock
    def test_search_sequence_error_returns_empty(self, transport: HttpTransport) -> None:
        respx.get(f"{BASE}/api/v1/rest/runs/search/audios/").mock(return_value=httpx.Response(503, text="down"))
        result = transport.search_sequence("audios")
        assert result == []


# ------------------------------------------------------------------
# Experiments / Tags / Project
# ------------------------------------------------------------------


class TestEntities:
    @respx.mock
    def test_list_experiments(self, transport: HttpTransport) -> None:
        respx.get(f"{BASE}/api/v1/rest/experiments/").mock(
            return_value=httpx.Response(200, json=[{"id": "1", "name": "exp1"}]),
        )
        result = transport.list_experiments()
        assert len(result) == 1

    @respx.mock
    def test_create_experiment(self, transport: HttpTransport) -> None:
        respx.post(f"{BASE}/api/v1/rest/experiments/").mock(return_value=httpx.Response(200, json={"id": "1"}))
        result = transport.create_experiment("exp1")
        assert result["id"] == "1"

    @respx.mock
    def test_delete_experiment(self, transport: HttpTransport) -> None:
        respx.delete(f"{BASE}/api/v1/rest/experiments/uuid1/").mock(return_value=httpx.Response(200, json={}))
        transport.delete_experiment("uuid1")

    @respx.mock
    def test_list_tags(self, transport: HttpTransport) -> None:
        respx.get(f"{BASE}/api/v1/rest/tags/").mock(return_value=httpx.Response(200, json=[]))
        assert transport.list_tags() == []

    @respx.mock
    def test_get_project_info(self, transport: HttpTransport) -> None:
        respx.get(f"{BASE}/api/v1/rest/projects/").mock(return_value=httpx.Response(200, json={"name": "proj"}))
        assert transport.get_project_info()["name"] == "proj"


# ------------------------------------------------------------------
# Presigned artifact
# ------------------------------------------------------------------


class TestPresignArtifact:
    def test_presign_artifact(self, transport: HttpTransport) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"upload_url": "http://s3/presigned", "s3_key": "r1/file.bin"}
        mock_resp.raise_for_status = MagicMock()

        with patch("matyan_client.transport.http.httpx.post", return_value=mock_resp) as mock_post:
            result = transport.presign_artifact("http://frontier:53801", "r1", "file.bin", "application/octet-stream")
        assert result["upload_url"] == "http://s3/presigned"
        mock_post.assert_called_once()
        call_kwargs = mock_post.call_args
        assert "frontier:53801" in call_kwargs.args[0]


# ------------------------------------------------------------------
# Binary streaming decoder
# ------------------------------------------------------------------


def _encode_kv(key_bytes: bytes, val_bytes: bytes) -> bytes:
    return struct.pack("<I", len(key_bytes)) + key_bytes + struct.pack("<I", len(val_bytes)) + val_bytes


def _encode_string_key(parts: list[str]) -> bytes:
    return b"\xfe".join(p.encode("utf-8") for p in parts) + b"\xfe"


def _encode_int_key(n: int) -> bytes:
    return b"\xfe" + _STRUCT_BE_Q.pack(n) + b"\xfe"


class TestDecodeStreamingResponse:
    def test_empty(self) -> None:
        assert _decode_streaming_response(b"") == []

    def test_single_string_value(self) -> None:
        key = _encode_string_key(["run1", "name"])
        val = bytes([_TYPE_STRING]) + b"my_run"
        content = _encode_kv(key, val)
        result = _decode_streaming_response(content)
        assert len(result) == 1
        assert result[0]["hash"] == "run1"
        assert result[0]["name"] == "my_run"

    def test_multiple_kv_pairs(self) -> None:
        k1 = _encode_string_key(["r1", "a"])
        v1 = bytes([_TYPE_INT]) + struct.pack("<q", 42)
        k2 = _encode_string_key(["r1", "b"])
        v2 = bytes([_TYPE_FLOAT]) + struct.pack("<d", 3.14)
        content = _encode_kv(k1, v1) + _encode_kv(k2, v2)
        result = _decode_streaming_response(content)
        assert result[0]["a"] == 42
        assert abs(result[0]["b"] - 3.14) < 1e-10

    def test_multiple_runs(self) -> None:
        k1 = _encode_string_key(["r1", "x"])
        v1 = bytes([_TYPE_INT]) + struct.pack("<q", 1)
        k2 = _encode_string_key(["r2", "x"])
        v2 = bytes([_TYPE_INT]) + struct.pack("<q", 2)
        content = _encode_kv(k1, v1) + _encode_kv(k2, v2)
        result = _decode_streaming_response(content)
        assert len(result) == 2
        hashes = {r["hash"] for r in result}
        assert hashes == {"r1", "r2"}

    def test_progress_keys_filtered(self) -> None:
        k = _encode_string_key(["progress_123", "pct"])
        v = bytes([_TYPE_INT]) + struct.pack("<q", 50)
        content = _encode_kv(k, v)
        result = _decode_streaming_response(content)
        assert result == []

    def test_none_value(self) -> None:
        k = _encode_string_key(["r1", "val"])
        v = bytes([_TYPE_NONE])
        result = _decode_streaming_response(_encode_kv(k, v))
        assert result[0]["val"] is None

    def test_bool_value(self) -> None:
        k = _encode_string_key(["r1", "flag"])
        v = bytes([_TYPE_BOOL, 1])
        result = _decode_streaming_response(_encode_kv(k, v))
        assert result[0]["flag"] is True

        k2 = _encode_string_key(["r1", "flag2"])
        v2 = bytes([_TYPE_BOOL, 0])
        result = _decode_streaming_response(_encode_kv(k2, v2))
        assert result[0]["flag2"] is False

    def test_bytes_value(self) -> None:
        k = _encode_string_key(["r1", "blob"])
        v = bytes([_TYPE_BYTES]) + b"\x00\x01\x02"
        result = _decode_streaming_response(_encode_kv(k, v))
        assert result[0]["blob"] == b"\x00\x01\x02"

    def test_array_object_markers_skipped(self) -> None:
        k1 = _encode_string_key(["r1", "arr"])
        v1 = bytes([_TYPE_ARRAY])
        k2 = _encode_string_key(["r1", "obj"])
        v2 = bytes([_TYPE_OBJECT])
        k3 = _encode_string_key(["r1", "real"])
        v3 = bytes([_TYPE_INT]) + struct.pack("<q", 99)
        content = _encode_kv(k1, v1) + _encode_kv(k2, v2) + _encode_kv(k3, v3)
        result = _decode_streaming_response(content)
        assert "arr" not in result[0]
        assert "obj" not in result[0]
        assert result[0]["real"] == 99

    def test_truncated_key_length(self) -> None:
        k = _encode_string_key(["r1", "x"])
        v = bytes([_TYPE_INT]) + struct.pack("<q", 1)
        full = _encode_kv(k, v)
        truncated = full[:4] + b"\xff\xff\xff\x7f"
        result = _decode_streaming_response(truncated)
        assert result == []

    def test_truncated_value_data(self) -> None:
        k = _encode_string_key(["r1", "x"])
        v = bytes([_TYPE_INT]) + struct.pack("<q", 1)
        full = _encode_kv(k, v)
        truncated = full[: len(full) - 3]
        result = _decode_streaming_response(truncated)
        assert result == []

    def test_empty_path(self) -> None:
        content = _encode_kv(b"", bytes([_TYPE_INT]) + struct.pack("<q", 42))
        result = _decode_streaming_response(content)
        assert result == []

    def test_non_dict_top_level_value(self) -> None:
        k = _encode_string_key(["r1"])
        v = bytes([_TYPE_STRING]) + b"scalar"
        result = _decode_streaming_response(_encode_kv(k, v))
        assert result[0]["hash"] == "r1"
        assert result[0]["data"] == "scalar"


# ------------------------------------------------------------------
# Decode helpers
# ------------------------------------------------------------------


class TestDecodePath:
    def test_string_keys(self) -> None:
        raw = b"hello\xfeworld\xfe"
        assert _decode_path(raw) == ["hello", "world"]

    def test_integer_key(self) -> None:
        raw = b"\xfe" + _STRUCT_BE_Q.pack(42) + b"\xfe"
        assert _decode_path(raw) == [42]

    def test_mixed(self) -> None:
        raw = b"runs\xfe" + b"\xfe" + _STRUCT_BE_Q.pack(0) + b"\xfe" + b"name\xfe"
        result = _decode_path(raw)
        assert result == ["runs", 0, "name"]

    def test_empty(self) -> None:
        assert _decode_path(b"") == []

    def test_double_sentinel(self) -> None:
        raw = b"\xfe\xfe"
        result = _decode_path(raw)
        assert isinstance(result, list)

    def test_string_without_trailing_sentinel(self) -> None:
        raw = b"no_trailing"
        result = _decode_path(raw)
        assert result == ["no_trailing"]

    def test_integer_key_with_trailing_sentinel(self) -> None:
        raw = b"\xfe" + _STRUCT_BE_Q.pack(7) + b"\xfe"
        result = _decode_path(raw)
        assert result == [7]


class TestDecodeValue:
    def test_empty(self) -> None:

        assert _decode_value(b"") is _SKIP

    def test_none(self) -> None:
        assert _decode_value(bytes([_TYPE_NONE])) is None

    def test_bool_true(self) -> None:
        assert _decode_value(bytes([_TYPE_BOOL, 1])) is True

    def test_bool_false(self) -> None:
        assert _decode_value(bytes([_TYPE_BOOL, 0])) is False

    def test_bool_empty_payload(self) -> None:
        assert _decode_value(bytes([_TYPE_BOOL])) is False

    def test_int(self) -> None:
        assert _decode_value(bytes([_TYPE_INT]) + struct.pack("<q", -7)) == -7

    def test_int_short_payload(self) -> None:
        assert _decode_value(bytes([_TYPE_INT]) + b"\x00") == 0

    def test_float(self) -> None:
        result = _decode_value(bytes([_TYPE_FLOAT]) + struct.pack("<d", 2.5))
        assert isinstance(result, float)
        assert abs(result - 2.5) < 1e-10

    def test_float_short_payload(self) -> None:
        assert _decode_value(bytes([_TYPE_FLOAT]) + b"\x00") == 0.0

    def test_string(self) -> None:
        assert _decode_value(bytes([_TYPE_STRING]) + b"hello") == "hello"

    def test_bytes(self) -> None:
        assert _decode_value(bytes([_TYPE_BYTES]) + b"\xff\x00") == b"\xff\x00"

    def test_array_marker(self) -> None:

        assert _decode_value(bytes([_TYPE_ARRAY])) is _SKIP

    def test_object_marker(self) -> None:

        assert _decode_value(bytes([_TYPE_OBJECT])) is _SKIP

    def test_unknown_tag(self) -> None:

        assert _decode_value(bytes([99])) is _SKIP


class TestSetNested:
    def test_simple(self) -> None:
        root = {}
        _set_nested(root, ["a", "b"], 42)
        assert root == {"a": {"b": 42}}

    def test_single_key(self) -> None:
        root = {}
        _set_nested(root, ["x"], 1)
        assert root == {"x": 1}

    def test_empty_path(self) -> None:
        root = {}
        _set_nested(root, [], 1)
        assert root == {}

    def test_non_dict_intermediate(self) -> None:
        root = {"a": 5}
        _set_nested(root, ["a", "b"], 42)
        assert root == {"a": 5}


class TestFoldTree:
    def test_empty(self) -> None:
        assert _fold_tree([]) == []

    def test_groups_by_top_key(self) -> None:

        flat = [
            (["r1", "a"], 1),
            (["r1", "b"], 2),
            (["r2", "c"], 3),
        ]
        result = _fold_tree(flat)
        assert len(result) == 2

    def test_skips_progress(self) -> None:
        flat = [(["progress_1", "pct"], 50)]
        assert _fold_tree(flat) == []

    def test_skips_skip_values(self) -> None:

        flat = [(["r1", "arr"], _SKIP), (["r1", "name"], "hello")]
        result = _fold_tree(flat)
        assert result[0]["name"] == "hello"
        assert "arr" not in result[0]

    def test_empty_path_skipped(self) -> None:
        flat = [([], "value")]
        assert _fold_tree(flat) == []
