"""Tests for matyan_client._blob_uploader.BlobUploader."""

from __future__ import annotations

from concurrent.futures import Future
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import httpx
import pytest

from matyan_client._blob_uploader import BlobUploader

if TYPE_CHECKING:
    from collections.abc import Generator

# ruff: noqa: SLF001


@pytest.fixture
def mock_http() -> MagicMock:
    http = MagicMock()
    http.presign_artifact = MagicMock(
        return_value={"upload_url": "http://s3.local/presigned", "s3_key": "run1/file.bin"},
    )
    return http


@pytest.fixture
def uploader(mock_http: MagicMock) -> Generator[BlobUploader, None, None]:
    up = BlobUploader(http=mock_http, frontier_url="http://frontier:53801", run_id="run1")
    yield up
    up.shutdown(timeout=5)


class TestBlobUploader:
    def test_submit_returns_s3_key(self, uploader: BlobUploader) -> None:
        key = uploader.submit(b"data", "artifact.bin", "application/octet-stream")
        assert key == "run1/artifact.bin"

    def test_submit_fires_background_upload(self, uploader: BlobUploader, mock_http: MagicMock) -> None:
        uploader.submit(b"hello", "test.txt", "text/plain")
        failures = uploader.drain(timeout=10)
        assert failures == 0
        mock_http.presign_artifact.assert_called_once()

    def test_upload_calls_presign_and_put(self, mock_http: MagicMock) -> None:
        up = BlobUploader(http=mock_http, frontier_url="http://frontier:53801", run_id="r1")

        with patch("matyan_client._blob_uploader.httpx.put") as mock_put:
            mock_put.return_value = MagicMock(status_code=200)
            mock_put.return_value.raise_for_status = MagicMock()
            up.submit(b"content", "file.bin", "application/octet-stream")
            up.drain(timeout=10)

        mock_http.presign_artifact.assert_called_once_with(
            "http://frontier:53801",
            "r1",
            "file.bin",
            content_type="application/octet-stream",
        )
        mock_put.assert_called_once()
        call_kwargs = mock_put.call_args
        assert call_kwargs.kwargs["content"] == b"content"
        up.shutdown(timeout=5)

    def test_drain_counts_http_failures(self, mock_http: MagicMock) -> None:
        mock_http.presign_artifact.side_effect = httpx.ConnectError("offline")
        up = BlobUploader(http=mock_http, frontier_url="http://f:1", run_id="r1")
        up.submit(b"x", "f.bin", "application/octet-stream")
        failures = up.drain(timeout=10)
        assert failures == 0
        up.shutdown(timeout=5)

    def test_pending_property(self, uploader: BlobUploader, mock_http: MagicMock) -> None:
        mock_http.presign_artifact.side_effect = lambda *_args, **_kwargs: (
            __import__("time").sleep(0.5)
            or {
                "upload_url": "http://s3/u",
                "s3_key": "k",
            }
        )
        with patch("matyan_client._blob_uploader.httpx.put") as mock_put:
            mock_put.return_value = MagicMock(raise_for_status=MagicMock())
            uploader.submit(b"x", "a.bin", "application/octet-stream")
        uploader.drain(timeout=10)

    def test_shutdown_calls_drain(self, mock_http: MagicMock) -> None:
        up = BlobUploader(http=mock_http, frontier_url="http://f:1", run_id="r1")
        with patch("matyan_client._blob_uploader.httpx.put") as mock_put:
            mock_put.return_value = MagicMock(raise_for_status=MagicMock())
            up.submit(b"x", "f.bin", "application/octet-stream")
        up.shutdown(timeout=10)

    def test_multiple_submits(self, uploader: BlobUploader, mock_http: MagicMock) -> None:
        with patch("matyan_client._blob_uploader.httpx.put") as mock_put:
            mock_put.return_value = MagicMock(raise_for_status=MagicMock())
            for i in range(5):
                uploader.submit(b"x", f"file_{i}.bin", "application/octet-stream")
            failures = uploader.drain(timeout=30)
        assert failures == 0
        assert mock_http.presign_artifact.call_count == 5

    def test_drain_timeout_failure(self, mock_http: MagicMock) -> None:

        up = BlobUploader(http=mock_http, frontier_url="http://f:1", run_id="r1")
        fake_fut = MagicMock()
        fake_fut.result.side_effect = TimeoutError("timed out")
        up._futures.append(fake_fut)
        failures = up.drain(timeout=1)
        assert failures == 1
        up.shutdown(timeout=1)

    def test_pending_counts_undone(self, mock_http: MagicMock) -> None:

        up = BlobUploader(http=mock_http, frontier_url="http://f:1", run_id="r1")
        f1 = Future()
        f1.set_result(None)
        f2 = Future()
        up._futures = [f1, f2]
        assert up.pending == 1
        f2.cancel()
        up.shutdown(timeout=1)

    def test_drain_unexpected_error(self, mock_http: MagicMock) -> None:

        up = BlobUploader(http=mock_http, frontier_url="http://f:1", run_id="r1")
        fut = Future()
        fut.set_exception(RuntimeError("unexpected"))
        up._futures.append(fut)
        failures = up.drain(timeout=5)
        assert failures == 1
        up.shutdown(timeout=1)

    def test_drain_http_error_in_result(self, mock_http: MagicMock) -> None:

        up = BlobUploader(http=mock_http, frontier_url="http://f:1", run_id="r1")
        fut = Future()
        fut.set_exception(httpx.ConnectError("network error"))
        up._futures.append(fut)
        failures = up.drain(timeout=5)
        assert failures == 1
        up.shutdown(timeout=1)

    def test_shutdown_with_failures_logs(self, mock_http: MagicMock) -> None:

        up = BlobUploader(http=mock_http, frontier_url="http://f:1", run_id="r1")
        fut = Future()
        fut.set_exception(RuntimeError("fail"))
        up._futures.append(fut)
        up.shutdown(timeout=5)
