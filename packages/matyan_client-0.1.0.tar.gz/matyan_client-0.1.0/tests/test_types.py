"""Tests for matyan_client._types — type aliases."""

from __future__ import annotations

from matyan_client._types import AimObject, Context


def test_imports() -> None:

    assert AimObject is not None
    assert Context is not None


def test_aim_object_accepts_primitives() -> None:

    vals: list[AimObject] = [1, 1.0, "s", True, [1], (1,), {"k": "v"}, None]
    assert len(vals) == 8
