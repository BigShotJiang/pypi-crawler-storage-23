"""Tests for matyan_client.repo — Repo class."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import httpx
import pytest

from matyan_client.repo import Repo

# ruff: noqa: SLF001


@pytest.fixture
def mock_http() -> MagicMock:
    return MagicMock()


@pytest.fixture
def repo(mock_http: MagicMock) -> Repo:
    with patch("matyan_client.repo.HttpTransport", return_value=mock_http):
        return Repo("http://backend:53800")


# ------------------------------------------------------------------
# Init / Class methods
# ------------------------------------------------------------------


class TestRepoInit:
    def test_default_url(self) -> None:
        with patch("matyan_client.repo.HttpTransport") as mock_cls:
            mock_cls.return_value = MagicMock()
            r = Repo()
            assert "53800" in r._url

    def test_custom_url(self, repo: Repo) -> None:
        assert repo._url == "http://backend:53800"


class TestClassMethods:
    def test_default_repo(self) -> None:
        with patch("matyan_client.repo.HttpTransport", return_value=MagicMock()):
            r = Repo.default_repo()
        assert isinstance(r, Repo)

    def test_from_path(self) -> None:
        with patch("matyan_client.repo.HttpTransport", return_value=MagicMock()):
            r = Repo.from_path("http://custom:9999")
        assert r._url == "http://custom:9999"

    def test_is_remote_path(self) -> None:
        assert Repo.is_remote_path("http://example.com") is True
        assert Repo.is_remote_path("https://example.com") is True
        assert Repo.is_remote_path("/local/path") is False

    def test_is_remote_repo(self, repo: Repo) -> None:
        assert repo.is_remote_repo is True


# ------------------------------------------------------------------
# Run access
# ------------------------------------------------------------------


class TestRunAccess:
    def test_get_run_success(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.get_run_info.return_value = {"params": {}, "traces": {}}
        with (
            patch("matyan_client.repo.Run") as mock_run_cls,
        ):
            mock_run_cls.return_value = MagicMock()
            result = repo.get_run("hash1")
            assert result is not None
            mock_run_cls.assert_called_once_with(run_hash="hash1", repo="http://backend:53800", read_only=True)

    def test_get_run_empty(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.get_run_info.return_value = {}
        assert repo.get_run("hash1") is None

    def test_get_run_http_error(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.get_run_info.side_effect = httpx.ConnectError("offline")
        assert repo.get_run("hash1") is None

    def test_run_exists(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.get_run_info.return_value = {"params": {}}
        with patch("matyan_client.repo.Run", return_value=MagicMock()):
            assert repo.run_exists("hash1") is True

    def test_run_exists_false(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.get_run_info.return_value = {}
        assert repo.run_exists("hash1") is False


# ------------------------------------------------------------------
# Iteration
# ------------------------------------------------------------------


class TestIteration:
    def test_iter_runs(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [
            {"hash": "r1", "name": "run1"},
            {"hash": "r2", "name": "run2"},
        ]
        result = list(repo.iter_runs())
        assert len(result) == 2

    def test_list_all_runs(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"hash": "r1"}, {"hash": "r2"}]
        assert repo.list_all_runs() == ["r1", "r2"]

    def test_list_all_runs_run_id_fallback(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"run_id": "r1"}]
        assert repo.list_all_runs() == ["r1"]

    def test_list_active_runs(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"hash": "r1"}]
        assert repo.list_active_runs() == ["r1"]
        mock_http.search_runs.assert_called_with(query="run.active == True")

    def test_total_runs_count(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"hash": "r1"}, {"hash": "r2"}, {"hash": "r3"}]
        assert repo.total_runs_count() == 3


# ------------------------------------------------------------------
# Querying
# ------------------------------------------------------------------


class TestQueryRuns:
    def test_non_paginated(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"hash": "r1"}]
        result = repo.query_runs(query="run.active == True")
        assert result == [{"hash": "r1"}]

    def test_non_paginated_with_offset(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"hash": "r2"}]
        repo.query_runs(query="", offset="r1")
        mock_http.search_runs.assert_called_with(query="", offset="r1")

    def test_paginated_single_page(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"hash": "r1"}]
        pages = list(repo.query_runs(paginated=True, limit=50))
        assert len(pages) == 1
        assert pages[0] == [{"hash": "r1"}]

    def test_paginated_multiple_pages(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.side_effect = [
            [{"hash": f"r{i}"} for i in range(50)],
            [{"hash": f"r{i}"} for i in range(50, 80)],
        ]
        pages = list(repo.query_runs(paginated=True, limit=50))
        assert len(pages) == 2
        assert len(pages[0]) == 50
        assert len(pages[1]) == 30

    def test_paginated_empty(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = []
        pages = list(repo.query_runs(paginated=True))
        assert pages == []

    def test_paginated_offset_cursor(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.side_effect = [
            [{"hash": "r1"}, {"hash": "r2"}],
            [],
        ]
        list(repo.query_runs(paginated=True, limit=2))
        calls = mock_http.search_runs.call_args_list
        assert calls[1].kwargs.get("offset") == "r2"


class TestQuerySequences:
    def test_query_metrics(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_metrics.return_value = [{"name": "loss"}]
        assert repo.query_metrics("q") == [{"name": "loss"}]

    def test_query_images(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_sequence.return_value = []
        repo.query_images("q")
        mock_http.search_sequence.assert_called_with("images", query="q")

    def test_query_audios(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_sequence.return_value = []
        repo.query_audios()
        mock_http.search_sequence.assert_called_with("audios", query="")

    def test_query_figure_objects(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_sequence.return_value = []
        repo.query_figure_objects()
        mock_http.search_sequence.assert_called_with("figures", query="")

    def test_query_distributions(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_sequence.return_value = []
        repo.query_distributions()
        mock_http.search_sequence.assert_called_with("distributions", query="")

    def test_query_texts(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_sequence.return_value = []
        repo.query_texts()
        mock_http.search_sequence.assert_called_with("texts", query="")


# ------------------------------------------------------------------
# Management
# ------------------------------------------------------------------


class TestManagement:
    def test_delete_run_success(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.delete_run.return_value = {}
        assert repo.delete_run("r1") is True

    def test_delete_run_failure(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.delete_run.side_effect = httpx.ConnectError("offline")
        assert repo.delete_run("r1") is False

    def test_delete_runs_all_success(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.delete_run.return_value = {}
        success, failed = repo.delete_runs(["r1", "r2"])
        assert success is True
        assert failed == []

    def test_delete_runs_partial_failure(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.delete_run.side_effect = [
            {},
            httpx.ConnectError("offline"),
        ]
        success, failed = repo.delete_runs(["r1", "r2"])
        assert success is False
        assert failed == ["r2"]

    def test_delete_experiment_success(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.delete_experiment.return_value = {}
        assert repo.delete_experiment("exp1") is True

    def test_delete_experiment_failure(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.delete_experiment.side_effect = httpx.ConnectError("offline")
        assert repo.delete_experiment("exp1") is False


# ------------------------------------------------------------------
# Info aggregation
# ------------------------------------------------------------------


class TestInfoAggregation:
    def test_collect_sequence_info(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"hash": "r1"}, {"hash": "r2"}]
        mock_http.get_run_info.side_effect = [
            {"traces": {"metric": [{"name": "loss"}]}},
            {"traces": {"metric": [{"name": "acc"}]}},
        ]
        result = repo.collect_sequence_info(("metric",))
        assert "r1" in result
        assert "r2" in result

    def test_collect_sequence_info_http_error(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"hash": "r1"}]
        mock_http.get_run_info.side_effect = httpx.ConnectError("offline")
        result = repo.collect_sequence_info()
        assert result == {}

    def test_collect_sequence_info_skip_empty_hash(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"name": "no-hash"}]
        result = repo.collect_sequence_info()
        assert result == {}

    def test_collect_params_info(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"hash": "r1"}]
        mock_http.get_run_info.return_value = {"params": {"lr": 0.01}}
        result = repo.collect_params_info()
        assert result == {"r1": {"lr": 0.01}}

    def test_collect_params_info_http_error(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"hash": "r1"}]
        mock_http.get_run_info.side_effect = httpx.ConnectError("offline")
        result = repo.collect_params_info()
        assert result == {}

    def test_collect_params_info_skip_empty_hash(self, repo: Repo, mock_http: MagicMock) -> None:
        mock_http.search_runs.return_value = [{"name": "no-hash"}]
        result = repo.collect_params_info()
        assert result == {}


# ------------------------------------------------------------------
# Utilities
# ------------------------------------------------------------------


class TestUtilities:
    def test_available_sequence_types(self) -> None:
        types = Repo.available_sequence_types()
        assert "metric" in types
        assert "images" in types
        assert "figures" in types

    def test_close(self, repo: Repo, mock_http: MagicMock) -> None:
        repo.close()
        mock_http.close.assert_called_once()

    def test_repr(self, repo: Repo) -> None:
        r = repr(repo)
        assert "Repo" in r
        assert "backend:53800" in r
