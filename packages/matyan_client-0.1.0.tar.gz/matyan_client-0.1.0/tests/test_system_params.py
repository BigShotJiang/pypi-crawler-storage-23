"""Tests for matyan_client._system_params."""

from __future__ import annotations

import subprocess
from typing import TYPE_CHECKING, Any
from unittest.mock import MagicMock, patch

from matyan_client._system_params import (
    collect_system_params,
    get_environment_variables,
    get_git_info,
    get_installed_packages,
)

if TYPE_CHECKING:
    import pytest


class TestGetInstalledPackages:
    def test_returns_dict(self) -> None:
        pkgs = get_installed_packages()
        assert isinstance(pkgs, dict)
        assert "pip" in pkgs or len(pkgs) > 0

    def test_values_are_strings(self) -> None:
        pkgs = get_installed_packages()
        for name, version in pkgs.items():
            assert isinstance(name, str)
            assert isinstance(version, str)


class TestGetEnvironmentVariables:
    def test_returns_dict(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("MY_SAFE_VAR", "hello")
        env = get_environment_variables()
        assert env["MY_SAFE_VAR"] == "hello"

    def test_filters_secrets(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("MY_SECRET", "s3cr3t")
        monkeypatch.setenv("API_KEY", "k3y")
        monkeypatch.setenv("AUTH_TOKEN", "tok")
        monkeypatch.setenv("DB_PASSWORD", "pw")
        monkeypatch.setenv("SAFE_VAR", "ok")
        env = get_environment_variables()
        assert "MY_SECRET" not in env
        assert "API_KEY" not in env
        assert "AUTH_TOKEN" not in env
        assert "DB_PASSWORD" not in env
        assert env.get("SAFE_VAR") == "ok"

    def test_case_insensitive_filter(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("my_Secret_value", "x")
        env = get_environment_variables()
        assert "my_Secret_value" not in env


class TestGetGitInfo:
    def test_success(self) -> None:
        branch_result = MagicMock(stdout=b"main\n")
        remote_result = MagicMock(stdout=b"git@github.com:user/repo.git\n")
        commit_result = MagicMock(stdout=b"abc123f/2024-01-01T00:00:00+00:00/Author Name\n")
        worktree_result = MagicMock(stdout=b"true\n")

        call_count = 0

        def fake_run(cmd: str, **_kwargs: Any) -> subprocess.CompletedProcess[bytes]:  # noqa: ANN401
            nonlocal call_count
            if "rev-parse" in cmd and "--is-inside-work-tree" in cmd:
                return worktree_result
            if "rev-parse" in cmd and "--abbrev-ref" in cmd:
                return branch_result
            if "config" in cmd:
                return remote_result
            if "log" in cmd:
                return commit_result
            return MagicMock(stdout=b"")

        with patch("matyan_client._system_params.subprocess.run", side_effect=fake_run):
            info = get_git_info()
        assert info["branch"] == "main"
        assert info["remote_origin_url"] == "git@github.com:user/repo.git"
        assert info["commit"]["hash"] == "abc123f"
        assert info["commit"]["author"] == "Author Name"

    def test_not_a_repo(self) -> None:
        with patch(
            "matyan_client._system_params.subprocess.run",
            side_effect=subprocess.CalledProcessError(128, "git"),
        ):
            info = get_git_info()
        assert info == {}

    def test_git_not_installed(self) -> None:
        with patch(
            "matyan_client._system_params.subprocess.run",
            side_effect=FileNotFoundError,
        ):
            info = get_git_info()
        assert info == {}

    def test_worktree_false(self) -> None:
        result = MagicMock(stdout=b"false\n")
        with patch("matyan_client._system_params.subprocess.run", return_value=result):
            info = get_git_info()
        assert info == {}

    def test_bad_commit_format(self) -> None:
        worktree_result = MagicMock(stdout=b"true\n")

        def fake_run(cmd: str, **_kwargs: Any) -> subprocess.CompletedProcess[bytes]:  # noqa: ANN401
            if "--is-inside-work-tree" in cmd:
                return worktree_result
            if "log" in cmd:
                return MagicMock(stdout=b"malformed")
            if "rev-parse" in cmd and "--abbrev-ref" in cmd:
                return MagicMock(stdout=b"main\n")
            if "config" in cmd:
                raise subprocess.CalledProcessError(1, "git")
            return MagicMock(stdout=b"")

        with patch("matyan_client._system_params.subprocess.run", side_effect=fake_run):
            info = get_git_info()
        assert info["commit"]["hash"] is None


class TestCollectSystemParams:
    def test_aggregates_all(self) -> None:
        params = collect_system_params()
        assert "executable" in params
        assert "arguments" in params
        assert "packages" in params
        assert "env_variables" in params
        assert "git_info" in params

    def test_handles_packages_failure(self) -> None:
        with patch(
            "matyan_client._system_params.get_installed_packages",
            side_effect=RuntimeError("fail"),
        ):
            params = collect_system_params()
        assert params["packages"] == {}

    def test_handles_env_failure(self) -> None:
        with patch(
            "matyan_client._system_params.get_environment_variables",
            side_effect=RuntimeError("fail"),
        ):
            params = collect_system_params()
        assert params["env_variables"] == {}

    def test_handles_git_failure(self) -> None:
        with patch(
            "matyan_client._system_params.get_git_info",
            side_effect=RuntimeError("fail"),
        ):
            params = collect_system_params()
        assert params["git_info"] == {}
