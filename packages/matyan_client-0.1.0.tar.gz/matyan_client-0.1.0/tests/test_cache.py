"""Tests for matyan_client._cache.WriteCache."""

from __future__ import annotations

import threading

from matyan_client._cache import WriteCache


class TestWriteCache:
    def test_set_get_roundtrip(self) -> None:
        c = WriteCache()
        c.set("r1", "lr", 0.01)
        assert c.get("r1", "lr") == 0.01

    def test_get_default(self) -> None:
        c = WriteCache()
        assert c.get("r1", "missing") is None
        assert c.get("r1", "missing", 42) == 42

    def test_has(self) -> None:
        c = WriteCache()
        assert not c.has("r1", "x")
        c.set("r1", "x", 1)
        assert c.has("r1", "x")

    def test_get_tree(self) -> None:
        c = WriteCache()
        c.set("r1", "a", 1)
        c.set("r1", "b", 2)
        c.set("r2", "c", 3)
        tree = c.get_tree("r1")
        assert tree == {"a": 1, "b": 2}

    def test_get_tree_empty(self) -> None:
        c = WriteCache()
        assert c.get_tree("nonexistent") == {}

    def test_clear_selective(self) -> None:
        c = WriteCache()
        c.set("r1", "a", 1)
        c.set("r2", "b", 2)
        c.clear("r1")
        assert not c.has("r1", "a")
        assert c.has("r2", "b")

    def test_clear_all(self) -> None:
        c = WriteCache()
        c.set("r1", "a", 1)
        c.set("r2", "b", 2)
        c.clear()
        assert not c.has("r1", "a")
        assert not c.has("r2", "b")

    def test_overwrite(self) -> None:
        c = WriteCache()
        c.set("r1", "x", 1)
        c.set("r1", "x", 2)
        assert c.get("r1", "x") == 2

    def test_none_value(self) -> None:
        c = WriteCache()
        c.set("r1", "x", None)
        assert c.has("r1", "x")
        assert c.get("r1", "x") is None

    def test_thread_safety(self) -> None:
        c = WriteCache()
        errors: list[Exception] = []

        def writer(prefix: str) -> None:
            try:
                for i in range(200):
                    c.set("run", f"{prefix}_{i}", i)
            except Exception as e:  # noqa: BLE001
                errors.append(e)

        def reader() -> None:
            try:
                for _ in range(200):
                    c.get_tree("run")
            except Exception as e:  # noqa: BLE001
                errors.append(e)

        threads = [
            threading.Thread(target=writer, args=("a",)),
            threading.Thread(target=writer, args=("b",)),
            threading.Thread(target=reader),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert not errors
