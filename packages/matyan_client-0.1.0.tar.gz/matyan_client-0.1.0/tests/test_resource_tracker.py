"""Tests for matyan_client._resource_tracker.ResourceTracker."""

from __future__ import annotations

import io
import sys
import time
from unittest.mock import MagicMock, patch

from matyan_client._resource_tracker import (
    METRIC_PREFIX,
    STAT_INTERVAL_MAX,
    STAT_INTERVAL_MIN,
    ResourceTracker,
)

# ruff: noqa: SLF001


class TestCheckInterval:
    def test_none_returns_false(self) -> None:
        assert ResourceTracker.check_interval(None) is False

    def test_valid_float(self) -> None:
        assert ResourceTracker.check_interval(1.0) is True

    def test_valid_min(self) -> None:
        assert ResourceTracker.check_interval(STAT_INTERVAL_MIN) is True

    def test_valid_max(self) -> None:
        assert ResourceTracker.check_interval(STAT_INTERVAL_MAX) is True

    def test_below_min(self) -> None:
        assert ResourceTracker.check_interval(0.01) is False

    def test_above_max(self) -> None:
        assert ResourceTracker.check_interval(STAT_INTERVAL_MAX + 1) is False

    def test_warn_flag(self) -> None:
        assert ResourceTracker.check_interval(0.01, warn=True) is False
        assert ResourceTracker.check_interval(0.01, warn=False) is False


class TestStripAnsi:
    def test_plain_text(self) -> None:
        assert ResourceTracker._strip_ansi(b"hello world") == b"hello world"

    def test_cursor_movement_codes(self) -> None:
        text = b"\033[2Amoved"
        stripped = ResourceTracker._strip_ansi(text)
        assert b"moved" in stripped
        assert b"\033" not in stripped

    def test_cursor_codes_b_c_d(self) -> None:
        assert b"\033" not in ResourceTracker._strip_ansi(b"\033[3Bdown")
        assert b"\033" not in ResourceTracker._strip_ansi(b"\033[1Cright")
        assert b"\033" not in ResourceTracker._strip_ansi(b"\033[4Dleft")

    def test_color_codes_not_in_pattern(self) -> None:
        # The regex only targets cursor movement [a-dA-D], not color [m]
        colored = b"\033[31mred\033[0m"
        result = ResourceTracker._strip_ansi(colored)
        # Color codes are NOT stripped by this specific regex
        assert b"red" in result


class TestLifecycle:
    def test_start_stop_with_stats(self) -> None:
        track_fn = MagicMock()
        mock_proc = MagicMock()
        mock_proc.cpu_percent.return_value = 10.0
        mock_proc.memory_percent.return_value = 50.0

        mock_psutil = MagicMock()
        mock_psutil.Process.return_value = mock_proc
        mock_psutil.cpu_percent.return_value = 10.0
        mock_psutil.virtual_memory.return_value = MagicMock(percent=60.0)
        mock_psutil.disk_usage.return_value = MagicMock(percent=70.0)

        with patch.dict("sys.modules", {"psutil": mock_psutil}):
            rt = ResourceTracker(
                track_fn=track_fn,
                interval=0.2,
                capture_logs=False,
            )
            rt.start()
            time.sleep(0.5)
            rt.stop()
        assert track_fn.call_count > 0

    def test_start_stop_idempotent(self) -> None:
        track_fn = MagicMock()
        rt = ResourceTracker(track_fn=track_fn, interval=None, capture_logs=False)
        rt.start()
        rt.start()
        rt.stop()
        rt.stop()

    def test_no_start_when_nothing_enabled(self) -> None:
        track_fn = MagicMock()
        rt = ResourceTracker(track_fn=track_fn, interval=None, capture_logs=False)
        rt.start()
        assert rt._thread is None

    def test_psutil_unavailable(self) -> None:
        track_fn = MagicMock()
        with patch.dict("sys.modules", {"psutil": None}):
            rt = ResourceTracker(track_fn=track_fn, interval=1.0, capture_logs=False)
        assert rt._stat_interval is None

    def test_capture_logs_only(self) -> None:
        send_fn = MagicMock()
        rt = ResourceTracker(
            track_fn=MagicMock(),
            interval=None,
            capture_logs=True,
            send_terminal_line_fn=send_fn,
        )
        rt.start()
        assert rt._thread is not None
        time.sleep(0.2)
        rt.stop()


class TestCollectSystemStats:
    def test_collects_four_metrics(self) -> None:
        track_fn = MagicMock()
        mock_proc = MagicMock()
        mock_proc.cpu_percent.return_value = 25.5
        mock_proc.memory_percent.return_value = 40.1

        mock_psutil = MagicMock()
        mock_psutil.Process.return_value = mock_proc
        mock_psutil.cpu_percent.return_value = 0
        mock_psutil.virtual_memory.return_value = MagicMock(percent=60.2)
        mock_psutil.disk_usage.return_value = MagicMock(percent=70.3)

        with patch.dict("sys.modules", {"psutil": mock_psutil}):
            rt = ResourceTracker(track_fn=track_fn, interval=1.0, capture_logs=False)
            track_fn.reset_mock()
            rt._collect_system_stats()

        names = [call.args[1] for call in track_fn.call_args_list]
        assert f"{METRIC_PREFIX}cpu" in names
        assert f"{METRIC_PREFIX}p_memory_percent" in names
        assert f"{METRIC_PREFIX}memory_percent" in names
        assert f"{METRIC_PREFIX}disk_percent" in names

    def test_no_process(self) -> None:
        track_fn = MagicMock()
        mock_psutil = MagicMock()
        mock_psutil.Process.return_value = MagicMock()
        mock_psutil.cpu_percent.return_value = 0

        with patch.dict("sys.modules", {"psutil": mock_psutil}):
            rt = ResourceTracker(track_fn=track_fn, interval=1.0, capture_logs=False)
        rt._process = None
        track_fn.reset_mock()

        with patch.dict("sys.modules", {"psutil": mock_psutil}):
            rt._collect_system_stats()
        track_fn.assert_not_called()


class TestCollectGpuStats:
    def test_pynvml_import_error(self) -> None:
        track_fn = MagicMock()
        rt = ResourceTracker(track_fn=track_fn, interval=None, capture_logs=False)
        with patch.dict("sys.modules", {"pynvml": None}):
            rt._collect_gpu_stats()
        track_fn.assert_not_called()

    def test_nvml_init_error(self) -> None:
        track_fn = MagicMock()
        rt = ResourceTracker(track_fn=track_fn, interval=None, capture_logs=False)

        nvmle_error = type("NVMLError", (Exception,), {})
        mock_pynvml = MagicMock()
        mock_pynvml.NVMLError = nvmle_error
        mock_pynvml.nvmlInit.side_effect = nvmle_error("no driver")

        with patch.dict("sys.modules", {"pynvml": mock_pynvml}):
            rt._collect_gpu_stats()
        track_fn.assert_not_called()

    def test_gpu_stats_collected(self) -> None:
        track_fn = MagicMock()
        rt = ResourceTracker(track_fn=track_fn, interval=None, capture_logs=False)

        nvmle_error = type("NVMLError", (Exception,), {})
        mock_pynvml = MagicMock()
        mock_pynvml.NVMLError = nvmle_error
        mock_pynvml.NVML_TEMPERATURE_GPU = 0
        mock_pynvml.nvmlDeviceGetCount.return_value = 1
        mock_pynvml.nvmlDeviceGetHandleByIndex.return_value = MagicMock()

        util = MagicMock()
        util.gpu = 75.0
        mock_pynvml.nvmlDeviceGetUtilizationRates.return_value = util

        mem = MagicMock()
        mem.used = 4000
        mem.total = 8000
        mock_pynvml.nvmlDeviceGetMemoryInfo.return_value = mem

        mock_pynvml.nvmlDeviceGetTemperature.return_value = 65
        mock_pynvml.nvmlDeviceGetPowerUsage.return_value = 120_000

        with patch.dict("sys.modules", {"pynvml": mock_pynvml}):
            rt._collect_gpu_stats()

        names = [call.args[1] for call in track_fn.call_args_list]
        assert f"{METRIC_PREFIX}gpu" in names
        assert f"{METRIC_PREFIX}gpu_memory_percent" in names
        assert f"{METRIC_PREFIX}gpu_temp" in names
        assert f"{METRIC_PREFIX}gpu_power_watts" in names

    def test_gpu_individual_errors(self) -> None:
        track_fn = MagicMock()
        rt = ResourceTracker(track_fn=track_fn, interval=None, capture_logs=False)

        nvmle_error = type("NVMLError", (Exception,), {})
        mock_pynvml = MagicMock()
        mock_pynvml.NVMLError = nvmle_error
        mock_pynvml.NVML_TEMPERATURE_GPU = 0
        mock_pynvml.nvmlDeviceGetCount.return_value = 1
        mock_pynvml.nvmlDeviceGetHandleByIndex.return_value = MagicMock()
        mock_pynvml.nvmlDeviceGetUtilizationRates.side_effect = nvmle_error("fail")
        mock_pynvml.nvmlDeviceGetMemoryInfo.side_effect = nvmle_error("fail")
        mock_pynvml.nvmlDeviceGetTemperature.side_effect = nvmle_error("fail")
        mock_pynvml.nvmlDeviceGetPowerUsage.side_effect = nvmle_error("fail")

        with patch.dict("sys.modules", {"pynvml": mock_pynvml}):
            rt._collect_gpu_stats()
        track_fn.assert_not_called()

    def test_gpu_mem_zero_total(self) -> None:
        track_fn = MagicMock()
        rt = ResourceTracker(track_fn=track_fn, interval=None, capture_logs=False)

        nvmle_error = type("NVMLError", (Exception,), {})
        mock_pynvml = MagicMock()
        mock_pynvml.NVMLError = nvmle_error
        mock_pynvml.NVML_TEMPERATURE_GPU = 0
        mock_pynvml.nvmlDeviceGetCount.return_value = 1
        mock_pynvml.nvmlDeviceGetHandleByIndex.return_value = MagicMock()

        util = MagicMock()
        util.gpu = 0.0
        mock_pynvml.nvmlDeviceGetUtilizationRates.return_value = util

        mem = MagicMock()
        mem.used = 0
        mem.total = 0
        mock_pynvml.nvmlDeviceGetMemoryInfo.return_value = mem

        mock_pynvml.nvmlDeviceGetTemperature.return_value = 30
        mock_pynvml.nvmlDeviceGetPowerUsage.return_value = 10_000

        with patch.dict("sys.modules", {"pynvml": mock_pynvml}):
            rt._collect_gpu_stats()
        mem_calls = [c for c in track_fn.call_args_list if "gpu_memory_percent" in c.args[1]]
        assert mem_calls[0].args[0] == 0.0

    def test_nvml_shutdown_error(self) -> None:
        track_fn = MagicMock()
        rt = ResourceTracker(track_fn=track_fn, interval=None, capture_logs=False)

        nvmle_error = type("NVMLError", (Exception,), {})
        mock_pynvml = MagicMock()
        mock_pynvml.NVMLError = nvmle_error
        mock_pynvml.NVML_TEMPERATURE_GPU = 0
        mock_pynvml.nvmlDeviceGetCount.return_value = 0
        mock_pynvml.nvmlShutdown.side_effect = nvmle_error("shutdown fail")

        with patch.dict("sys.modules", {"pynvml": mock_pynvml}):
            rt._collect_gpu_stats()


class TestFlushLogs:
    def test_lines_sent(self) -> None:
        send_fn = MagicMock()
        rt = ResourceTracker(
            track_fn=MagicMock(),
            interval=None,
            capture_logs=True,
            send_terminal_line_fn=send_fn,
        )
        rt._io_buffer.write(b"line1\nline2\n")
        rt._flush_logs()

        lines = [call.args[0] for call in send_fn.call_args_list]
        assert "line1" in lines
        assert "line2" in lines

    def test_carriage_return_handled(self) -> None:
        send_fn = MagicMock()
        rt = ResourceTracker(
            track_fn=MagicMock(),
            interval=None,
            capture_logs=True,
            send_terminal_line_fn=send_fn,
        )
        rt._io_buffer.write(b"old\rnew\n")
        rt._flush_logs()
        lines = [call.args[0] for call in send_fn.call_args_list]
        assert any("new" in l for l in lines)  # noqa: E741

    def test_no_send_fn(self) -> None:
        rt = ResourceTracker(
            track_fn=MagicMock(),
            interval=None,
            capture_logs=True,
            send_terminal_line_fn=None,
        )
        rt._io_buffer.write(b"data\n")
        rt._flush_logs()

    def test_empty_buffer(self) -> None:
        send_fn = MagicMock()
        rt = ResourceTracker(
            track_fn=MagicMock(),
            interval=None,
            capture_logs=True,
            send_terminal_line_fn=send_fn,
        )
        rt._flush_logs()
        send_fn.assert_not_called()

    def test_step_counter_increments(self) -> None:
        send_fn = MagicMock()
        rt = ResourceTracker(
            track_fn=MagicMock(),
            interval=None,
            capture_logs=True,
            send_terminal_line_fn=send_fn,
            log_offset=10,
        )
        rt._io_buffer.write(b"a\nb\nc\n")
        rt._flush_logs()
        steps = [call.args[1] for call in send_fn.call_args_list]
        assert steps[0] == 10
        assert steps[1] == 11

    def test_partial_line_stays_in_buffer(self) -> None:
        send_fn = MagicMock()
        rt = ResourceTracker(
            track_fn=MagicMock(),
            interval=None,
            capture_logs=True,
            send_terminal_line_fn=send_fn,
        )
        rt._io_buffer.write(b"complete\npartial")
        rt._flush_logs()
        assert rt._io_buffer.tell() > 0


class TestStreamPatching:
    def test_install_and_uninstall(self) -> None:
        ResourceTracker._uninstall_stream_patches()

        ResourceTracker._install_stream_patches()
        assert ResourceTracker._patches_installed is True

        ResourceTracker._uninstall_stream_patches()
        assert ResourceTracker._patches_installed is False

    def test_patched_stderr_broadcasts_to_buffers(self) -> None:
        ResourceTracker._uninstall_stream_patches()
        buf = io.BytesIO()
        ResourceTracker._buffer_registry[998] = buf

        ResourceTracker._install_stream_patches()
        try:
            sys.stderr.write("err output")
            assert b"err output" in buf.getvalue()
        finally:
            ResourceTracker._uninstall_stream_patches()
            ResourceTracker._buffer_registry.pop(998, None)

    def test_patched_write_broadcasts_to_buffers(self) -> None:
        ResourceTracker._uninstall_stream_patches()
        buf = io.BytesIO()
        ResourceTracker._buffer_registry[999] = buf

        ResourceTracker._install_stream_patches()
        try:
            sys.stdout.write("test output")
            assert b"test output" in buf.getvalue()
        finally:
            ResourceTracker._uninstall_stream_patches()
            ResourceTracker._buffer_registry.pop(999, None)

    def test_idempotent_install(self) -> None:
        ResourceTracker._uninstall_stream_patches()
        ResourceTracker._install_stream_patches()
        ResourceTracker._install_stream_patches()
        assert ResourceTracker._patches_installed is True
        ResourceTracker._uninstall_stream_patches()

    def test_idempotent_uninstall(self) -> None:
        ResourceTracker._uninstall_stream_patches()
        ResourceTracker._uninstall_stream_patches()
        assert ResourceTracker._patches_installed is False


class TestFlushLogsEdgeCases:
    def test_decode_error_skips_line(self) -> None:
        send_fn = MagicMock()
        rt = ResourceTracker(
            track_fn=MagicMock(),
            interval=None,
            capture_logs=True,
            send_terminal_line_fn=send_fn,
        )
        rt._io_buffer.write(b"good line\n\xff\xfe bad bytes\n")
        rt._flush_logs()
        lines = [call.args[0] for call in send_fn.call_args_list]
        assert any("good line" in l for l in lines)  # noqa: E741

    def test_decode_exception_continues(self) -> None:
        send_fn = MagicMock()
        rt = ResourceTracker(
            track_fn=MagicMock(),
            interval=None,
            capture_logs=True,
            send_terminal_line_fn=send_fn,
        )
        bad_line = MagicMock()
        bad_line.rsplit.return_value = [bad_line]
        bad_line.__getitem__ = MagicMock(return_value=bad_line)
        bad_line.decode.side_effect = RuntimeError("decode fail")

        rt._io_buffer.write(b"line1\nline2\n")
        with patch.object(rt, "_strip_ansi", side_effect=[b"line1", bad_line, b""]):
            rt._flush_logs()
        lines = [call.args[0] for call in send_fn.call_args_list]
        assert any("line1" in l for l in lines)  # noqa: E741

    def test_start_with_existing_buffer_registry(self) -> None:
        existing_buf = io.BytesIO()
        ResourceTracker._buffer_registry[777] = existing_buf

        send_fn = MagicMock()
        rt = ResourceTracker(
            track_fn=MagicMock(),
            interval=None,
            capture_logs=True,
            send_terminal_line_fn=send_fn,
        )
        rt.start()
        assert id(rt) in ResourceTracker._buffer_registry
        rt.stop()
        ResourceTracker._buffer_registry.pop(777, None)

    def test_start_already_started_noop(self) -> None:
        send_fn = MagicMock()
        rt = ResourceTracker(
            track_fn=MagicMock(),
            interval=None,
            capture_logs=True,
            send_terminal_line_fn=send_fn,
        )
        rt.start()
        thread1 = rt._thread
        rt.start()
        thread2 = rt._thread
        assert thread1 is thread2
        rt.stop()

    def test_loop_flushes_logs_periodically(self) -> None:
        send_fn = MagicMock()
        rt = ResourceTracker(
            track_fn=MagicMock(),
            interval=None,
            capture_logs=True,
            send_terminal_line_fn=send_fn,
        )
        rt.start()
        rt._io_buffer.write(b"test line\n")
        time.sleep(0.4)
        rt.stop()
        lines = [call.args[0] for call in send_fn.call_args_list]
        assert any("test line" in l for l in lines)  # noqa: E741


class TestCollectStats:
    def test_collect_stats_handles_exception(self) -> None:
        track_fn = MagicMock()
        rt = ResourceTracker(track_fn=track_fn, interval=None, capture_logs=False)
        rt._process = MagicMock()
        rt._stat_interval = 1.0

        with patch.object(rt, "_collect_system_stats", side_effect=RuntimeError("boom")):
            rt._collect_stats()

    def test_collect_stats_handles_gpu_exception(self) -> None:
        track_fn = MagicMock()
        rt = ResourceTracker(track_fn=track_fn, interval=None, capture_logs=False)

        with (
            patch.object(rt, "_collect_system_stats"),
            patch.object(rt, "_collect_gpu_stats", side_effect=RuntimeError("boom")),
        ):
            rt._collect_stats()
