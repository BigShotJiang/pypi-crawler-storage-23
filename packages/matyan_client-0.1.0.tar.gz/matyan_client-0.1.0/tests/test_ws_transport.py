"""Tests for matyan_client.transport.ws — WsTransport.

These tests avoid creating actual background threads.  We construct the
transport object by bypassing __init__ and setting internal state directly,
then test the public API methods, internal helpers, and async drain/retry
logic.
"""

from __future__ import annotations

import asyncio
import collections
import json
import threading
from typing import Any, NoReturn
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import websockets
from typing_extensions import Self

from matyan_client.transport.ws import _SENTINEL, WsTransport, _estimate_size

# ruff: noqa: SLF001


def _make_transport(**overrides: Any) -> WsTransport:  # noqa: ANN401
    """Build a WsTransport without starting any threads."""
    t = object.__new__(WsTransport)
    t._url = "ws://frontier:53801/api/v1/ws/runs/run123"
    t._run_id = "run123"
    t._max_memory = overrides.get("max_memory", 512 * 1024 * 1024)
    t._batch_size = overrides.get("batch_size", 100)
    t._batch_interval = overrides.get("batch_interval", 0.05)
    t._retry_count = overrides.get("retry_count", 2)
    t._heartbeat_interval = overrides.get("heartbeat_interval", 10)
    t._deque = collections.deque()
    t._memory_usage = 0
    t._lock = threading.Lock()
    t._not_full = threading.Condition(t._lock)
    t._not_empty = threading.Condition(t._lock)
    t._flushed = threading.Event()
    t._flushed.set()
    t._connected_event = threading.Event()
    t._connected_event.set()
    t._closed = threading.Event()
    t._connect_error = None
    t._sent_count = 0
    t._dropped_count = 0
    t._thread = MagicMock()
    return t


# ------------------------------------------------------------------
# Init / URL
# ------------------------------------------------------------------


class TestWsInit:
    def test_url_http_to_ws(self) -> None:
        t = _make_transport()
        assert t._url.startswith("ws://")
        assert "run123" in t._url

    def test_real_init_url_construction(self) -> None:
        with (
            patch("matyan_client.transport.ws.SETTINGS") as mock_settings,
            patch.object(WsTransport, "_run_loop"),
        ):
            mock_settings.ws_queue_max_memory_mb = 1
            mock_settings.ws_heartbeat_interval = 10
            mock_settings.ws_batch_interval_ms = 50
            mock_settings.ws_batch_size = 100
            mock_settings.ws_retry_count = 2

            WsTransport.__new__(WsTransport)
            ws_base = "https://secure:443".replace("http://", "ws://").replace("https://", "wss://")
            expected_url = f"{ws_base}/api/v1/ws/runs/r1"
            assert expected_url == "wss://secure:443/api/v1/ws/runs/r1"


# ------------------------------------------------------------------
# Properties
# ------------------------------------------------------------------


class TestWsProperties:
    def test_connected_true(self) -> None:
        t = _make_transport()
        assert t.connected is True

    def test_connected_false_when_closed(self) -> None:
        t = _make_transport()
        t._closed.set()
        assert t.connected is False

    def test_connected_false_when_not_set(self) -> None:
        t = _make_transport()
        t._connected_event.clear()
        assert t.connected is False

    def test_pending(self) -> None:
        t = _make_transport()
        assert t.pending == 0
        t._deque.append({"type": "test"})
        assert t.pending == 1

    def test_stats(self) -> None:
        t = _make_transport()
        t._sent_count = 10
        t._dropped_count = 2
        s = t.stats
        assert s == {"sent": 10, "dropped": 2, "pending": 0}


# ------------------------------------------------------------------
# send()  # noqa: ERA001
# ------------------------------------------------------------------


class TestWsSend:
    def test_send_enqueues(self) -> None:
        t = _make_transport()
        t.send({"type": "test"})
        assert len(t._deque) == 1

    def test_send_after_close(self) -> None:
        t = _make_transport()
        t._closed.set()
        t.send({"type": "test"})
        assert len(t._deque) == 0

    def test_send_updates_memory(self) -> None:
        t = _make_transport()
        t.send({"type": "x"})
        assert t._memory_usage > 0

    def test_send_clears_flushed_event(self) -> None:
        t = _make_transport()
        assert t._flushed.is_set()
        t.send({"type": "x"})
        assert not t._flushed.is_set()


# ------------------------------------------------------------------
# send_* methods — verify message structure
# ------------------------------------------------------------------


class TestSendBackpressure:
    def test_send_blocks_at_memory_limit(self) -> None:
        t = _make_transport(max_memory=100)
        large_msg = {"data": "x" * 200}

        result = []

        def try_send() -> None:
            t.send(large_msg)
            result.append("sent")

        thread = threading.Thread(target=try_send)
        thread.start()
        thread.join(timeout=0.3)
        # The thread should be blocked since msg exceeds memory
        # Release by closing
        t._closed.set()
        with t._not_full:
            t._not_full.notify_all()
        thread.join(timeout=2)


class TestSendMethods:
    def test_send_create_run(self) -> None:
        t = _make_transport()
        t.send_create_run(force_resume=True)
        msg = t._deque[0]
        assert msg["type"] == "create_run"
        assert msg["run_id"] == "run123"
        assert msg["force_resume"] is True
        assert "client_datetime" in msg

    def test_send_create_run_defaults(self) -> None:
        t = _make_transport()
        t.send_create_run()
        assert t._deque[0]["force_resume"] is False

    def test_send_log_metric(self) -> None:
        t = _make_transport()
        t.send_log_metric(name="loss", value=0.5, step=1, epoch=0, context={"s": "train"}, dtype="float")
        msg = t._deque[0]
        assert msg["type"] == "log_metric"
        assert msg["name"] == "loss"
        assert msg["value"] == 0.5
        assert msg["step"] == 1
        assert msg["epoch"] == 0
        assert msg["context"] == {"s": "train"}

    def test_send_log_metric_defaults(self) -> None:
        t = _make_transport()
        t.send_log_metric(name="acc", value=0.9)
        msg = t._deque[0]
        assert msg["step"] is None
        assert msg["epoch"] is None
        assert msg["context"] is None
        assert msg["dtype"] == "float"

    def test_send_log_hparams(self) -> None:
        t = _make_transport()
        t.send_log_hparams({"lr": 0.01})
        msg = t._deque[0]
        assert msg["type"] == "log_hparams"
        assert msg["value"] == {"lr": 0.01}

    def test_send_set_run_property_all(self) -> None:
        t = _make_transport()
        t.send_set_run_property(name="r", description="d", archived=True, experiment="e")
        msg = t._deque[0]
        assert msg["type"] == "set_run_property"
        assert msg["name"] == "r"
        assert msg["description"] == "d"
        assert msg["archived"] is True
        assert msg["experiment"] == "e"

    def test_send_set_run_property_partial(self) -> None:
        t = _make_transport()
        t.send_set_run_property(name="r")
        msg = t._deque[0]
        assert msg["name"] == "r"
        assert "description" not in msg
        assert "archived" not in msg
        assert "experiment" not in msg

    def test_send_add_tag(self) -> None:
        t = _make_transport()
        t.send_add_tag("my-tag")
        assert t._deque[0] == {"type": "add_tag", "run_id": "run123", "tag_name": "my-tag"}

    def test_send_remove_tag(self) -> None:
        t = _make_transport()
        t.send_remove_tag("old")
        assert t._deque[0]["type"] == "remove_tag"
        assert t._deque[0]["tag_name"] == "old"

    def test_send_log_custom_object(self) -> None:
        t = _make_transport()
        t.send_log_custom_object(name="img", value={"k": "v"}, step=5, epoch=1, context={"c": 1}, dtype="image")
        msg = t._deque[0]
        assert msg["type"] == "log_custom_object"
        assert msg["name"] == "img"
        assert msg["dtype"] == "image"

    def test_send_log_terminal_line(self) -> None:
        t = _make_transport()
        t.send_log_terminal_line("line", step=3)
        msg = t._deque[0]
        assert msg == {"type": "log_terminal_line", "run_id": "run123", "line": "line", "step": 3}

    def test_send_log_record_full(self) -> None:
        t = _make_transport()
        t.send_log_record(message="msg", level=20, timestamp=1.0, logger_info=["f.py", 10], extra_args={"k": "v"})
        msg = t._deque[0]
        assert msg["type"] == "log_record"
        assert msg["logger_info"] == ["f.py", 10]
        assert msg["extra_args"] == {"k": "v"}

    def test_send_log_record_minimal(self) -> None:
        t = _make_transport()
        t.send_log_record(message="m", level=10, timestamp=0.0)
        msg = t._deque[0]
        assert "logger_info" not in msg
        assert "extra_args" not in msg

    def test_send_finish_run(self) -> None:
        t = _make_transport()
        t.send_finish_run()
        msg = t._deque[0]
        assert msg["type"] == "finish_run"
        assert msg["run_id"] == "run123"
        assert "client_datetime" in msg


# ------------------------------------------------------------------
# _take_batch
# ------------------------------------------------------------------


class TestTakeBatch:
    def test_collects_messages(self) -> None:
        t = _make_transport(batch_size=3, batch_interval=0.01)
        for i in range(3):
            t.send({"i": i})
        batch = t._take_batch()
        assert len(batch) == 3

    def test_respects_batch_size(self) -> None:
        t = _make_transport(batch_size=2, batch_interval=0.01)
        for i in range(5):
            t.send({"i": i})
        batch = t._take_batch()
        assert len(batch) == 2

    def test_sentinel_terminates(self) -> None:
        t = _make_transport(batch_interval=0.01)
        t.send({"type": "x"})
        t._deque.append(_SENTINEL)  # type: ignore[arg-type]
        batch = t._take_batch()
        assert batch[-1] is _SENTINEL

    def test_empty_queue_returns_empty(self) -> None:
        t = _make_transport(batch_interval=0.01)
        batch = t._take_batch()
        assert batch == []

    def test_flushed_set_when_empty(self) -> None:
        t = _make_transport(batch_interval=0.01)
        t.send({"x": 1})
        assert not t._flushed.is_set()
        t._take_batch()
        assert t._flushed.is_set()

    def test_memory_freed(self) -> None:
        t = _make_transport(batch_interval=0.01)
        t.send({"data": "x"})
        assert t._memory_usage > 0
        t._take_batch()
        assert t._memory_usage == 0


# ------------------------------------------------------------------
# close / wait_for_flush
# ------------------------------------------------------------------


class TestWsClose:
    def test_close_sets_closed(self) -> None:
        t = _make_transport()
        t.close(timeout=1)
        assert t._closed.is_set()

    def test_close_idempotent(self) -> None:
        t = _make_transport()
        t.close(timeout=1)
        t.close(timeout=1)
        assert t._closed.is_set()

    def test_close_injects_sentinel(self) -> None:
        t = _make_transport()
        t.close(timeout=1)
        assert _SENTINEL in t._deque

    def test_wait_for_flush_when_empty(self) -> None:
        t = _make_transport()
        assert t.wait_for_flush(timeout=1) is True


# ------------------------------------------------------------------
# _estimate_size
# ------------------------------------------------------------------


class TestEstimateSize:
    def test_positive(self) -> None:
        assert _estimate_size({"type": "test", "val": 42}) > 0

    def test_empty_dict(self) -> None:
        assert _estimate_size({}) > 0

    def test_large_value(self) -> None:
        msg = {"data": "x" * 10000}
        assert _estimate_size(msg) > 10000


# ------------------------------------------------------------------
# Async drain/retry logic
# ------------------------------------------------------------------


class TestAsyncDrain:
    @pytest.mark.asyncio
    async def test_drain_sends_and_exits_on_sentinel(self) -> None:
        t = _make_transport()
        t.send({"type": "test"})
        t._deque.append(_SENTINEL)  # type: ignore[arg-type]

        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock()
        mock_ws.recv = AsyncMock(return_value=json.dumps({"status": "ok"}))

        await t._drain(mock_ws)
        mock_ws.send.assert_called_once()
        assert t._sent_count == 1

    @pytest.mark.asyncio
    async def test_drain_heartbeat_timeout(self) -> None:
        t = _make_transport(heartbeat_interval=0)
        t.send({"type": "test1"})
        t.send({"type": "test2"})

        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock()
        mock_ws.recv = AsyncMock(return_value=json.dumps({"status": "ok"}))

        with pytest.raises(ConnectionError, match="No ack"):
            await t._drain(mock_ws)


class TestSendWithRetry:
    @pytest.mark.asyncio
    async def test_success(self) -> None:
        t = _make_transport()
        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock()
        mock_ws.recv = AsyncMock(return_value=json.dumps({"status": "ok"}))

        await t._send_with_retry(mock_ws, [{"type": "x"}])
        assert t._sent_count == 1
        assert t._dropped_count == 0

    @pytest.mark.asyncio
    async def test_retry_then_success(self) -> None:
        t = _make_transport(retry_count=2)
        mock_ws = AsyncMock()
        call_count = 0

        async def _send_effect(payload: Any) -> None:  # noqa: ANN401, ARG001
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                msg = "fail"
                raise ConnectionError(msg)

        mock_ws.send = _send_effect
        mock_ws.recv = AsyncMock(return_value=json.dumps({"status": "ok"}))

        await t._send_with_retry(mock_ws, [{"type": "x"}])
        assert t._sent_count == 1

    @pytest.mark.asyncio
    async def test_all_retries_fail(self) -> None:
        t = _make_transport(retry_count=1)
        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock(side_effect=ConnectionError("fail"))

        with pytest.raises(ConnectionError):
            await t._send_with_retry(mock_ws, [{"type": "x"}])
        assert t._dropped_count == 1

    @pytest.mark.asyncio
    async def test_non_ok_response(self) -> None:
        t = _make_transport()
        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock()
        mock_ws.recv = AsyncMock(return_value=json.dumps({"status": "error", "error": "bad"}))

        await t._send_with_retry(mock_ws, [{"type": "x"}])
        assert t._sent_count == 1

    @pytest.mark.asyncio
    async def test_batch_sent_as_array(self) -> None:
        t = _make_transport()
        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock()
        mock_ws.recv = AsyncMock(return_value=json.dumps({"status": "ok"}))

        await t._send_with_retry(mock_ws, [{"type": "a"}, {"type": "b"}])
        payload = mock_ws.send.call_args.args[0]
        parsed = json.loads(payload)
        assert isinstance(parsed, list)
        assert len(parsed) == 2
        assert t._sent_count == 2

    @pytest.mark.asyncio
    async def test_single_msg_sent_as_object(self) -> None:
        t = _make_transport()
        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock()
        mock_ws.recv = AsyncMock(return_value=json.dumps({"status": "ok"}))

        await t._send_with_retry(mock_ws, [{"type": "x"}])
        payload = mock_ws.send.call_args.args[0]
        parsed = json.loads(payload)
        assert isinstance(parsed, dict)


class TestAttemptSend:
    @pytest.mark.asyncio
    async def test_success_returns_none(self) -> None:
        t = _make_transport()
        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock()
        mock_ws.recv = AsyncMock(return_value=json.dumps({"status": "ok"}))

        result = await t._attempt_send(mock_ws, '{"type":"x"}', [{"type": "x"}], 1)
        assert result is None

    @pytest.mark.asyncio
    async def test_timeout_returns_error(self) -> None:
        t = _make_transport()
        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock()
        mock_ws.recv = AsyncMock(side_effect=asyncio.TimeoutError)

        result = await t._attempt_send(mock_ws, '{"type":"x"}', [{"type": "x"}], 1)
        assert isinstance(result, asyncio.TimeoutError)

    @pytest.mark.asyncio
    async def test_connection_closed_returns_error(self) -> None:

        t = _make_transport()
        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock(side_effect=websockets.ConnectionClosed(None, None))

        result = await t._attempt_send(mock_ws, '{"type":"x"}', [{"type": "x"}], 1)
        assert isinstance(result, websockets.ConnectionClosed)

    @pytest.mark.asyncio
    async def test_retry_with_backoff(self) -> None:
        t = _make_transport(retry_count=2)
        call_count = 0

        async def _send_effect(payload: Any) -> None:  # noqa: ANN401, ARG001
            nonlocal call_count
            call_count += 1
            if call_count <= 2:
                msg = "fail"
                raise ConnectionError(msg)

        mock_ws = AsyncMock()
        mock_ws.send = _send_effect
        mock_ws.recv = AsyncMock(return_value=json.dumps({"status": "ok"}))

        result = await t._attempt_send(mock_ws, '{"type":"x"}', [{"type": "x"}], 3)
        assert result is None
        assert call_count == 3


# ------------------------------------------------------------------
# close() edge cases
# ------------------------------------------------------------------


class TestCloseEdgeCases:
    def test_close_with_pending_messages(self) -> None:
        t = _make_transport()
        t._flushed.clear()
        t.send({"type": "unflushed1"})
        t.send({"type": "unflushed2"})
        t.close(timeout=1)
        assert t._closed.is_set()

    def test_close_timeout_with_remaining(self) -> None:
        t = _make_transport()
        t._flushed.clear()
        for i in range(5):
            t._deque.append({"type": f"msg{i}"})
        t.close(timeout=3)
        assert t._closed.is_set()


# ------------------------------------------------------------------
# _run_loop / _async_loop
# ------------------------------------------------------------------


class TestRunLoop:
    def test_run_loop_exception_handled(self) -> None:
        t = _make_transport()
        with (
            patch.object(t, "_async_loop", side_effect=RuntimeError("crash")),
            patch("matyan_client.transport.ws.asyncio.run", side_effect=RuntimeError("crash")),
        ):
            t._run_loop()

    @pytest.mark.asyncio
    async def test_async_loop_connection_error(self) -> None:

        t = _make_transport()

        class FailConnect:
            def __init__(self, *_a: Any, **_kw: Any) -> None:  # noqa: ANN401
                pass

            def __aiter__(self) -> Self:
                return self

            async def __anext__(self) -> NoReturn:
                msg = "connect failed"
                raise websockets.WebSocketException(msg)

        with patch("websockets.asyncio.client.connect", return_value=FailConnect()):
            await t._async_loop()
        assert t._connect_error is not None

    @pytest.mark.asyncio
    async def test_async_loop_drain_connection_lost(self) -> None:

        t = _make_transport()

        call_count = 0

        class ReconnectConnect:
            def __aiter__(self) -> Self:
                return self

            async def __anext__(self) -> AsyncMock:
                nonlocal call_count
                call_count += 1
                if call_count > 2:
                    raise StopAsyncIteration
                return AsyncMock()

        async def _drain_effect(ws: Any) -> None:  # noqa: ANN401, ARG001
            if call_count == 1:
                msg = "lost"
                raise ConnectionError(msg)

        with (
            patch("websockets.asyncio.client.connect", return_value=ReconnectConnect()),
            patch.object(t, "_drain", side_effect=_drain_effect),
        ):
            await t._async_loop()

    @pytest.mark.asyncio
    async def test_async_loop_normal_exit(self) -> None:
        t = _make_transport()

        class SingleConnect:
            def __aiter__(self) -> Self:
                return self

            async def __anext__(self) -> AsyncMock:
                if hasattr(self, "_done"):
                    raise StopAsyncIteration
                self._done = True
                return AsyncMock()

        with (
            patch("websockets.asyncio.client.connect", return_value=SingleConnect()),
            patch.object(t, "_drain", return_value=None),
        ):
            await t._async_loop()

    @pytest.mark.asyncio
    async def test_drain_empty_batch_continues(self) -> None:
        t = _make_transport()
        call_count = 0

        def _take_batch() -> list[dict]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return []
            return [_SENTINEL]

        with patch.object(t, "_take_batch", side_effect=_take_batch):
            mock_ws = AsyncMock()
            await t._drain(mock_ws)
