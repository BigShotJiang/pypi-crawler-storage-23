"""Tests for matyan_client.config.Settings."""

from __future__ import annotations

from typing import TYPE_CHECKING

from matyan_client.config import Settings

if TYPE_CHECKING:
    import pytest


class TestSettings:
    def test_defaults(self) -> None:

        s = Settings()
        assert s.frontier_url == "http://localhost:53801"
        assert s.backend_url == "http://localhost:53800"
        assert s.s3_endpoint == "http://localhost:9000"
        assert s.ws_queue_max_memory_mb == 512
        assert s.ws_heartbeat_interval == 10
        assert s.ws_batch_interval_ms == 50
        assert s.ws_batch_size == 100
        assert s.ws_retry_count == 2

    def test_env_override(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("MATYAN_BACKEND_URL", "http://custom:9999")
        monkeypatch.setenv("MATYAN_FRONTIER_URL", "http://frontier:1234")
        monkeypatch.setenv("MATYAN_WS_BATCH_SIZE", "500")

        s = Settings()
        assert s.backend_url == "http://custom:9999"
        assert s.frontier_url == "http://frontier:1234"
        assert s.ws_batch_size == 500
