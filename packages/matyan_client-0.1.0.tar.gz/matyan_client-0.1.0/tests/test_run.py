"""Tests for matyan_client.run — Run class."""

from __future__ import annotations

import base64
from datetime import datetime
from typing import TYPE_CHECKING, cast
from unittest.mock import MagicMock, patch

import httpx
import pytest

from matyan_client.run import Run, _global_cache, _nest_key, _resolve_dotted

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

# ruff: noqa: SLF001

# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


class TestNestKey:
    def test_simple(self) -> None:
        assert _nest_key("hparams", {"lr": 0.01}) == {"hparams": {"lr": 0.01}}

    def test_dotted(self) -> None:
        assert _nest_key("a.b", 42) == {"a": {"b": 42}}

    def test_single(self) -> None:
        assert _nest_key("x", 1) == {"x": 1}


class TestResolveDotted:
    def test_simple(self) -> None:
        assert _resolve_dotted({"a": {"b": 42}}, "a.b") == 42

    def test_single(self) -> None:
        assert _resolve_dotted({"x": 1}, "x") == 1

    def test_missing_raises(self) -> None:
        with pytest.raises(KeyError, match="not found"):
            _resolve_dotted({"a": 1}, "b")

    def test_intermediate_not_dict(self) -> None:
        with pytest.raises(KeyError, match="not found"):
            _resolve_dotted({"a": 5}, "a.b")


# ------------------------------------------------------------------
# Init
# ------------------------------------------------------------------


class TestRunInit:
    def test_default_hash(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _ws, _http = make_run(run_hash=None)
        assert len(run.hash) == 32
        run.close()

    def test_custom_hash(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run(run_hash="my-hash")
        assert run.hash == "my-hash"
        run.close()

    def test_read_only_no_ws(self) -> None:
        with (
            patch("matyan_client.run.WsTransport") as mock_ws_cls,
            patch("matyan_client.run.HttpTransport") as mock_http_cls,
        ):
            mock_http_cls.return_value = MagicMock()
            run = Run(run_hash="ro", read_only=True, capture_terminal_logs=False)
            mock_ws_cls.assert_not_called()
            assert run._ws is None
            run.close()

    def test_experiment_sent_via_ws(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run(experiment="baseline")
        ws.send_set_run_property.assert_called()
        call_kwargs = ws.send_set_run_property.call_args
        assert call_kwargs.kwargs.get("experiment") == "baseline"
        run.close()

    def test_force_resume_forwarded(self, mock_ws: MagicMock, mock_http: MagicMock) -> None:
        with (
            patch("matyan_client.run.WsTransport", return_value=mock_ws),
            patch("matyan_client.run.HttpTransport", return_value=mock_http),
            patch("matyan_client.run._BlobUploader", return_value=MagicMock()),
        ):
            run = Run(
                run_hash="r",
                force_resume=True,
                capture_terminal_logs=False,
            )
            mock_ws.send_create_run.assert_called_with(force_resume=True)
            run.close()

    def test_with_system_tracking(self, mock_ws: MagicMock, mock_http: MagicMock) -> None:
        with (
            patch("matyan_client.run.WsTransport", return_value=mock_ws),
            patch("matyan_client.run.HttpTransport", return_value=mock_http),
            patch("matyan_client.run._BlobUploader", return_value=MagicMock()),
            patch("matyan_client.run._ResourceTracker") as mock_tracker_cls,
        ):
            mock_tracker = MagicMock()
            mock_tracker_cls.return_value = mock_tracker
            mock_tracker_cls.check_interval.return_value = True
            run = Run(
                run_hash="r",
                system_tracking_interval=1.0,
                capture_terminal_logs=True,
            )
            mock_tracker.start.assert_called_once()
            run.close()
            mock_tracker.stop.assert_called_once()

    def test_with_custom_repo_url(self, mock_ws: MagicMock, mock_http: MagicMock) -> None:
        with (
            patch("matyan_client.run.WsTransport", return_value=mock_ws),
            patch("matyan_client.run.HttpTransport", return_value=mock_http) as http_cls,
            patch("matyan_client.run._BlobUploader", return_value=MagicMock()),
        ):
            run = Run(
                run_hash="r",
                repo="http://custom-backend:9999",
                capture_terminal_logs=False,
            )
            http_cls.assert_called_with("http://custom-backend:9999")
            run.close()

    def test_default_hash_generation(self, mock_ws: MagicMock, mock_http: MagicMock) -> None:
        with (
            patch("matyan_client.run.WsTransport", return_value=mock_ws),
            patch("matyan_client.run.HttpTransport", return_value=mock_http),
            patch("matyan_client.run._BlobUploader", return_value=MagicMock()),
        ):
            run = Run(capture_terminal_logs=False)
            assert len(run.hash) == 32
            run.close()

    def test_log_system_params(self, mock_ws: MagicMock, mock_http: MagicMock) -> None:
        with (
            patch("matyan_client.run.WsTransport", return_value=mock_ws),
            patch("matyan_client.run.HttpTransport", return_value=mock_http),
            patch("matyan_client.run._BlobUploader", return_value=MagicMock()),
            patch("matyan_client._system_params.collect_system_params", return_value={"exe": "/bin/py"}),
        ):
            run = Run(
                run_hash="r",
                log_system_params=True,
                capture_terminal_logs=False,
            )
            mock_ws.send_log_hparams.assert_called()
            run.close()


# ------------------------------------------------------------------
# Properties
# ------------------------------------------------------------------


class TestRunProperties:
    def test_name_getter_setter(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        assert run.name is None
        run.name = "my-run"
        assert run.name == "my-run"
        ws.send_set_run_property.assert_called()
        run.close()

    def test_description_getter_setter(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _ws, _ = make_run()
        run.description = "desc"
        assert run.description == "desc"
        run.close()

    def test_archived_getter_setter(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _ws, _ = make_run()
        assert run.archived is False
        run.archived = True
        assert run.archived is True
        run.close()

    def test_experiment_getter_setter(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _ws, _ = make_run()
        run.experiment = "new-exp"
        assert run.experiment == "new-exp"
        run.close()

    def test_experiment_setter_none_no_ws(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        ws.reset_mock()
        run.experiment = None
        assert run.experiment is None
        ws.send_set_run_property.assert_not_called()
        run.close()

    def test_creation_time(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        assert run.creation_time > 0
        run.close()

    def test_created_at(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        assert isinstance(run.created_at, datetime)
        run.close()

    def test_end_time_before_close(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        assert run.end_time is None
        assert run.finalized_at is None
        assert run.duration is None
        run.close()

    def test_end_time_after_close(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        run.close()
        assert run.end_time is not None
        assert run.finalized_at is not None
        assert run.duration is not None
        assert run.duration >= 0

    def test_active(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        assert run.active is True
        run.close()
        assert run.active is False

    def test_tags_property(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.return_value = {
            "props": {"tags": [{"name": "t1"}, {"name": "t2"}]},
        }
        tags = run.tags
        assert tags == ["t1", "t2"]
        run.close()

    def test_tags_http_error(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.side_effect = httpx.ConnectError("offline")
        assert run.tags == []
        run.close()

    def test_props_property(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.return_value = {"props": {"name": "r"}}
        assert run.props == {"name": "r"}
        run.close()

    def test_props_http_error(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.side_effect = httpx.ConnectError("offline")
        assert run.props == {}
        run.close()


# ------------------------------------------------------------------
# Dict interface
# ------------------------------------------------------------------


class TestDictInterface:
    def test_setitem_getitem(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run["hparams"] = {"lr": 0.01}
        assert run["hparams"] == {"lr": 0.01}
        ws.send_log_hparams.assert_called_with({"hparams": {"lr": 0.01}})
        run.close()

    def test_getitem_cache_miss_http_fallback(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.return_value = {"params": {"hparams": {"lr": 0.01}}}
        assert run["hparams.lr"] == 0.01
        run.close()

    def test_getitem_missing_raises(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.return_value = {"params": {}}
        with pytest.raises(KeyError):
            _ = run["nonexistent"]
        run.close()

    def test_getitem_http_error_raises(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.side_effect = httpx.ConnectError("offline")
        with pytest.raises(KeyError):
            _ = run["x"]
        run.close()

    def test_delitem(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        run["x"] = 1
        del run["x"]
        assert _global_cache.get(run.hash, "x") is None
        run.close()

    def test_set_method(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _ws, _ = make_run()
        run.set("key", "val")
        assert run["key"] == "val"
        run.close()

    def test_get_method_default(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.return_value = {"params": {}}
        assert run.get("missing", 42) == 42
        run.close()

    def test_get_method_found(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        run["x"] = 5
        assert run.get("x") == 5
        run.close()


# ------------------------------------------------------------------
# Tracking
# ------------------------------------------------------------------


class TestTrack:
    def test_track_scalar(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run.track(0.5, name="loss", step=0, context={"subset": "train"})
        ws.send_log_metric.assert_called_once()
        call_kwargs = ws.send_log_metric.call_args.kwargs
        assert call_kwargs["name"] == "loss"
        assert call_kwargs["value"] == 0.5
        assert call_kwargs["step"] == 0
        run.close()

    def test_track_auto_step(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run.track(0.5, name="loss")
        run.track(0.4, name="loss")
        calls = ws.send_log_metric.call_args_list
        assert calls[0].kwargs["step"] == 0
        assert calls[1].kwargs["step"] == 1
        run.close()

    def test_track_custom_object(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        obj = MagicMock()
        obj.json.return_value = {"type": "text", "data": "hello"}
        run.track(obj, name="texts", step=0)
        ws.send_log_custom_object.assert_called_once()
        run.close()

    def test_track_image_blob_upload(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        obj = MagicMock()
        obj.json.return_value = {
            "type": "image",
            "data": base64.b64encode(b"png-data").decode(),
            "format": "png",
        }
        run.track(obj, name="imgs", step=0)
        cast("MagicMock", run._blob_uploader).submit.assert_called_once()
        ws.send_log_custom_object.assert_called_once()
        run.close()

    def test_track_audio_blob_upload(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _ws, _ = make_run()
        obj = MagicMock()
        obj.json.return_value = {
            "type": "audio",
            "data": base64.b64encode(b"wav-data").decode(),
            "format": "wav",
        }
        run.track(obj, name="audio", step=0)
        cast("MagicMock", run._blob_uploader).submit.assert_called_once()
        run.close()

    def test_track_read_only_raises(self) -> None:
        with (
            patch("matyan_client.run.HttpTransport") as mock_http_cls,
        ):
            mock_http_cls.return_value = MagicMock()
            run = Run(run_hash="ro", read_only=True, capture_terminal_logs=False)
            with pytest.raises(RuntimeError, match="read-only"):
                run.track(0.5, name="loss")
            run.close()

    def test_track_no_name_raises(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        with pytest.raises(ValueError, match="name"):
            run.track(0.5)
        run.close()

    def test_track_no_ws_raises(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        run._ws = None
        with pytest.raises(RuntimeError, match="WebSocket"):
            run.track(0.5, name="loss")
        run.close()


class TestUploadBlobIfNeeded:
    def test_non_blob_passthrough(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        serialized = {"type": "text", "data": "hello"}
        result = run._upload_blob_if_needed(serialized, "t", 0)
        assert result == serialized
        run.close()

    def test_image_uploads(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        serialized = {
            "type": "image",
            "data": base64.b64encode(b"img").decode(),
            "format": "png",
        }
        result = run._upload_blob_if_needed(serialized, "img", 5)
        assert "s3_key" in result
        assert "data" not in result
        run.close()

    def test_no_blob_uploader(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        run._blob_uploader = None
        serialized = {
            "type": "image",
            "data": base64.b64encode(b"img").decode(),
            "format": "png",
        }
        result = run._upload_blob_if_needed(serialized, "img", 0)
        assert "s3_key" in result
        run.close()


# ------------------------------------------------------------------
# Tags
# ------------------------------------------------------------------


class TestRunTags:
    def test_add_tag_via_ws(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run.add_tag("new-tag")
        ws.send_add_tag.assert_called_with("new-tag")
        run.close()

    def test_add_tag_read_only_noop(self) -> None:
        with patch("matyan_client.run.HttpTransport") as mock_http_cls:
            mock_http_cls.return_value = MagicMock()
            run = Run(run_hash="ro", read_only=True, capture_terminal_logs=False)
            run.add_tag("tag")
            run.close()

    def test_add_tag_no_ws_uses_http(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        run._ws = None
        run.add_tag("tag")
        http.add_tag_to_run.assert_called()
        run.close()

    def test_remove_tag_via_ws(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run.remove_tag("old")
        ws.send_remove_tag.assert_called_with("old")
        run.close()

    def test_remove_tag_read_only_noop(self) -> None:
        with patch("matyan_client.run.HttpTransport") as mock_http_cls:
            mock_http_cls.return_value = MagicMock()
            run = Run(run_hash="ro", read_only=True, capture_terminal_logs=False)
            run.remove_tag("tag")
            run.close()

    def test_remove_tag_no_ws_uses_http(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        run._ws = None
        http.get_run_info.return_value = {
            "props": {"tags": [{"name": "old", "id": "tid1"}]},
        }
        run.remove_tag("old")
        http.remove_tag_from_run.assert_called_with(run.hash, "tid1")
        run.close()

    def test_remove_tag_http_error(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        run._ws = None
        http.get_run_info.side_effect = httpx.ConnectError("offline")
        run.remove_tag("tag")
        run.close()


# ------------------------------------------------------------------
# Logging
# ------------------------------------------------------------------


class TestLogging:
    def test_log_info(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run.log_info("hello")
        ws.send_log_record.assert_called_once()
        kwargs = ws.send_log_record.call_args.kwargs
        assert kwargs["message"] == "hello"
        assert kwargs["level"] == 20
        run.close()

    def test_log_warning(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run.log_warning("warn")
        assert ws.send_log_record.call_args.kwargs["level"] == 30
        run.close()

    def test_log_error(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run.log_error("err")
        assert ws.send_log_record.call_args.kwargs["level"] == 40
        run.close()

    def test_log_debug(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run.log_debug("dbg")
        assert ws.send_log_record.call_args.kwargs["level"] == 10
        run.close()

    def test_log_read_only_noop(self) -> None:
        with patch("matyan_client.run.HttpTransport") as mock_http_cls:
            mock_http_cls.return_value = MagicMock()
            run = Run(run_hash="ro", read_only=True, capture_terminal_logs=False)
            run.log_info("should be ignored")
            run.close()

    def test_log_no_ws_noop(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        run._ws = None
        run.log_info("ignored")
        run.close()

    def test_log_with_extra_kwargs(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run.log_info("msg", extra_key="val")
        kwargs = ws.send_log_record.call_args.kwargs
        assert kwargs["extra_args"] == {"extra_key": "val"}
        run.close()

    def test_log_caller_frame(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run.log_info("test")
        kwargs = ws.send_log_record.call_args.kwargs
        assert kwargs["logger_info"] is not None
        assert len(kwargs["logger_info"]) == 2
        run.close()


# ------------------------------------------------------------------
# Artifacts
# ------------------------------------------------------------------


class TestArtifacts:
    def test_log_artifact_with_blob_uploader(
        self,
        make_run: Callable[..., tuple[Run, MagicMock, MagicMock]],
        tmp_path: Path,
    ) -> None:
        run, _, _ = make_run()
        f = tmp_path / "file.txt"
        f.write_bytes(b"content")
        run.log_artifact(str(f))
        cast("MagicMock", run._blob_uploader).submit.assert_called_once()
        run.close()

    def test_log_artifact_with_custom_name(
        self,
        make_run: Callable[..., tuple[Run, MagicMock, MagicMock]],
        tmp_path: Path,
    ) -> None:
        run, _, _ = make_run()
        f = tmp_path / "file.txt"
        f.write_bytes(b"content")
        run.log_artifact(str(f), name="custom.txt")
        call_args = cast("MagicMock", run._blob_uploader).submit.call_args
        assert call_args.args[1] == "custom.txt"
        run.close()

    def test_log_artifact_no_blob_uploader(
        self,
        make_run: Callable[..., tuple[Run, MagicMock, MagicMock]],
        tmp_path: Path,
    ) -> None:
        run, _, http = make_run()
        run._blob_uploader = None
        f = tmp_path / "file.txt"
        f.write_bytes(b"content")

        with patch("matyan_client.run.httpx.put") as mock_put:
            mock_put.return_value = MagicMock(raise_for_status=MagicMock())
            run.log_artifact(str(f))
            http.presign_artifact.assert_called_once()
            mock_put.assert_called_once()
        run.close()

    def test_log_artifacts_directory(
        self,
        make_run: Callable[..., tuple[Run, MagicMock, MagicMock]],
        tmp_path: Path,
    ) -> None:
        run, _, _ = make_run()
        (tmp_path / "a.txt").write_bytes(b"a")
        (tmp_path / "sub").mkdir()
        (tmp_path / "sub" / "b.txt").write_bytes(b"b")
        run.log_artifacts(str(tmp_path))
        assert cast("MagicMock", run._blob_uploader).submit.call_count == 2
        run.close()

    def test_log_artifacts_with_name_prefix(
        self,
        make_run: Callable[..., tuple[Run, MagicMock, MagicMock]],
        tmp_path: Path,
    ) -> None:
        run, _, _ = make_run()
        (tmp_path / "a.txt").write_bytes(b"a")
        run.log_artifacts(str(tmp_path), name="data")
        call_args = cast("MagicMock", run._blob_uploader).submit.call_args
        assert "data/" in call_args.args[1]
        run.close()


# ------------------------------------------------------------------
# Metrics / sequences
# ------------------------------------------------------------------


class TestMetrics:
    def test_metrics(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.return_value = {
            "traces": {"metric": [{"name": "loss", "context": {}}]},
        }
        assert len(run.metrics()) == 1
        run.close()

    def test_metrics_http_error(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.side_effect = httpx.ConnectError("offline")
        assert run.metrics() == []
        run.close()

    def test_get_metric_found(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.return_value = {
            "traces": {"metric": [{"name": "loss", "context": {}}]},
        }
        m = run.get_metric("loss")
        assert m is not None
        run.close()

    def test_get_metric_not_found(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.return_value = {"traces": {"metric": []}}
        assert run.get_metric("nonexistent") is None
        run.close()

    def test_get_metric_with_context(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.return_value = {
            "traces": {"metric": [{"name": "loss", "context": {"s": "train"}}]},
        }
        assert run.get_metric("loss", context={"s": "train"}) is not None
        assert run.get_metric("loss", context={"s": "val"}) is None
        run.close()

    def test_iter_metrics_info(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.return_value = {
            "traces": {"metric": [{"name": "loss", "context": {}}]},
        }
        result = list(run.iter_metrics_info())
        assert len(result) == 1
        name, _, r = result[0]
        assert name == "loss"
        assert r is run
        run.close()

    def test_collect_sequence_info(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.return_value = {"traces": {"metric": [], "images": []}}
        result = run.collect_sequence_info(("metric", "images"))
        assert "metric" in result
        run.close()

    def test_collect_sequence_info_string(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.return_value = {"traces": {"metric": []}}
        result = run.collect_sequence_info("metric")
        assert "metric" in result
        run.close()

    def test_collect_sequence_info_error(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, http = make_run()
        http.get_run_info.side_effect = httpx.ConnectError("offline")
        assert run.collect_sequence_info() == {}
        run.close()


# ------------------------------------------------------------------
# Internal callbacks
# ------------------------------------------------------------------


class TestInternalCallbacks:
    def test_track_system_metric(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run._track_system_metric(0.5, "__system__cpu", {"gpu": 0})
        ws.send_log_metric.assert_called()
        run.close()

    def test_track_system_metric_read_only(self) -> None:
        with patch("matyan_client.run.HttpTransport") as mock_http_cls:
            mock_http_cls.return_value = MagicMock()
            run = Run(run_hash="ro", read_only=True, capture_terminal_logs=False)
            run._track_system_metric(0.5, "cpu", None)
            run.close()

    def test_send_terminal_line(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run._send_terminal_line("hello", 5)
        ws.send_log_terminal_line.assert_called_with("hello", 5)
        run.close()

    def test_send_terminal_line_read_only(self) -> None:
        with patch("matyan_client.run.HttpTransport") as mock_http_cls:
            mock_http_cls.return_value = MagicMock()
            run = Run(run_hash="ro", read_only=True, capture_terminal_logs=False)
            run._send_terminal_line("hello", 0)
            run.close()


# ------------------------------------------------------------------
# Lifecycle
# ------------------------------------------------------------------


class TestLifecycle:
    def test_close_idempotent(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, ws, _ = make_run()
        run.close()
        run.close()
        assert ws.send_finish_run.call_count == 1

    def test_close_clears_cache(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        run["x"] = 1
        run.close()
        assert _global_cache.get(run.hash, "x") is None

    def test_close_removes_from_instances(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        assert run in Run._instances
        run.close()
        assert run not in Run._instances

    def test_close_stops_resource_tracker(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        mock_tracker = MagicMock()
        run._resource_tracker = mock_tracker
        run.close()
        mock_tracker.stop.assert_called_once()

    def test_close_shuts_down_blob_uploader(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        blob = run._blob_uploader
        run.close()
        cast("MagicMock", blob).shutdown.assert_called_once()

    def test_repr(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        r = repr(run)
        assert "Run" in r
        assert run.hash in r
        run.close()

    def test_weak_cleanup(self) -> None:
        _global_cache.set("wc-test", "key", "val")
        Run._weak_cleanup("wc-test")
        assert _global_cache.get("wc-test", "key") is None

    def test_del_calls_close(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        run.__del__()
        assert run._closed

    def test_del_already_closed(self, make_run: Callable[..., tuple[Run, MagicMock, MagicMock]]) -> None:
        run, _, _ = make_run()
        run.close()
        run.__del__()
