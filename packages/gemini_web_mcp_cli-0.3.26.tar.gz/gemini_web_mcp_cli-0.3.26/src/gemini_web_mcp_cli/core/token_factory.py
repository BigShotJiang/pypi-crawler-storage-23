"""Token Factory: capture BotGuard tokens from Chrome for Pro/Thinking model switching.

Chrome generates BotGuard tokens that validate model selection headers.
The Token Factory intercepts the XHR request before it's sent, captures the
token, and lets Python replay the request with the desired model header.

All methods are sync (CDP uses sync websocket library). Called from async
client via run_in_executor.
"""

from __future__ import annotations

import atexit
import os
import shutil
import signal
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path

from loguru import logger

from .cdp import (
    find_available_port,
    find_existing_chrome,
    find_or_create_gemini_page,
    get_chrome_path,
    get_current_url,
    get_page_cookies,
    navigate_to_url,
    run_js,
)
from .constants import (
    CHROME_HEADERS,
    CHROME_USER_AGENT,
    compute_xbv,
)
from .exceptions import AuthError, TokenFactoryError

GEMINI_APP_URL = "https://gemini.google.com/app"

# XHR interceptor JS — hooks XMLHttpRequest to capture StreamGenerate requests.
# Captures the URL, headers (including BotGuard token set by JS), and body,
# then aborts the original request so Chrome doesn't send it.
XHR_INTERCEPTOR_JS = """
(() => {
    window.__cap = null;
    const origOpen = XMLHttpRequest.prototype.open;
    const origSend = XMLHttpRequest.prototype.send;
    const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;

    XMLHttpRequest.prototype.open = function(m, u, ...r) {
        this.__u = u; this.__h = {};
        return origOpen.call(this, m, u, ...r);
    };
    XMLHttpRequest.prototype.setRequestHeader = function(n, v) {
        if (this.__h) this.__h[n] = v;
        return origSetHeader.call(this, n, v);
    };
    XMLHttpRequest.prototype.send = function(body) {
        if (this.__u?.includes('StreamGenerate') && !window.__cap) {
            window.__cap = {url: this.__u, headers: this.__h, body: body};
            this.abort();
            return;
        }
        return origSend.call(this, body);
    };
})()
"""

# JS to type a prompt into the Gemini input field
TYPE_PROMPT_JS = """
(() => {{
    const input = document.querySelector('div[contenteditable="true"]');
    if (input) {{
        input.focus(); input.click();
        document.execCommand('selectAll');
        document.execCommand('delete');
        document.execCommand('insertText', false, {prompt!r});
    }}
}})()
"""

# JS to click the send button
CLICK_SEND_JS = """
(() => {
    const btn = document.querySelector('button[aria-label="Send message"]')
        || document.querySelector('button[data-test-id="send-button"]');
    if (btn) btn.click();
})()
"""

# JS to check if the input field is ready
INPUT_READY_JS = '!!document.querySelector(\'div[contenteditable="true"]\')'


@dataclass
class CapturedRequest:
    """A captured StreamGenerate request from Chrome, ready for Python replay."""

    url: str
    body: str
    headers: dict[str, str]
    cookies: dict[str, str]
    access_token: str | None = None  # Chrome's live SNlM0e token (WIZ_global_data)


class TokenFactory:
    """Captures BotGuard tokens from Chrome for Python HTTP replay.

    Usage:
        factory = TokenFactory(chrome_profile_path="/path/to/profile", profile_name="default")
        factory.ensure_ready()
        captured = factory.capture(prompt="Hello", model=some_model, metadata=None)
        # Use captured.url, captured.body, captured.headers, captured.cookies
        # to send via httpx
        factory.shutdown()
    """

    def __init__(
        self,
        chrome_profile_path: str | None = None,
        profile_name: str = "default",
    ):
        self._chrome_profile_path = chrome_profile_path
        self._profile_name = profile_name
        self._port: int | None = None
        self._ws_url: str | None = None
        self._process = None
        self._we_launched: bool = False
        self._ready: bool = False
        self._raw_cookies: list[dict] = []
        self._tf_profile_dir: Path | None = None  # Token Factory's own isolated profile
        atexit.register(self.shutdown)
        # Handle SIGTERM/SIGINT so cleanup runs when a parent process kills us
        # (atexit does NOT fire on SIGTERM — Python uses the OS default which
        # terminates immediately).  Signal handlers can only be set from the
        # main thread; silently skip if we're in a worker thread.
        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                signal.signal(sig, self._signal_handler)
            except (OSError, ValueError):
                pass

    def _signal_handler(self, signum, frame):
        """Handle SIGTERM/SIGINT by cleaning up Chrome before exit."""
        self.shutdown()
        sys.exit(128 + signum)

    def _get_tf_profile_dir(self, source_dir: Path) -> Path:
        """Get the Token Factory's isolated profile directory.

        Creates a copy of the source Chrome profile at ``<source>_tf/`` so the
        Token Factory's headless Chrome never competes for the SingletonLock
        with ``gemcli login`` or CLI commands using the source profile.

        The copy is reused across Token Factory restarts and only refreshed
        when the source profile's Cookies file is newer (i.e. the user
        re-logged in).
        """
        tf_dir = source_dir.parent / f"{source_dir.name}_tf"
        synced_sentinel = tf_dir / ".tf_synced"

        needs_sync = False
        if not tf_dir.exists():
            needs_sync = True
        else:
            # Re-sync when the source Cookies DB is newer than our last copy.
            source_cookies = source_dir / "Default" / "Cookies"
            if source_cookies.exists() and synced_sentinel.exists():
                if source_cookies.stat().st_mtime > synced_sentinel.stat().st_mtime:
                    needs_sync = True
                    logger.debug("Token Factory: source profile updated, re-syncing")
            elif source_cookies.exists() and not synced_sentinel.exists():
                needs_sync = True

        if needs_sync:
            # Kill Chrome processes still referencing the old TF profile
            if tf_dir.exists():
                self._kill_stale_chrome(tf_dir)
                shutil.rmtree(tf_dir, ignore_errors=True)

            logger.debug(f"Token Factory: syncing profile → {tf_dir}")
            shutil.copytree(source_dir, tf_dir)
            # Remove SingletonLock carried over from the source copy
            (tf_dir / "SingletonLock").unlink(missing_ok=True)
            synced_sentinel.touch()

        return tf_dir

    def ensure_ready(self) -> None:
        """Lazy init: find/launch Chrome, navigate to Gemini, wait for input field."""
        if self._ready:
            return

        chrome_path = get_chrome_path()
        if not chrome_path:
            raise TokenFactoryError(
                "Chrome not found. Install Google Chrome for Pro/Thinking models."
            )

        if not self._chrome_profile_path:
            raise TokenFactoryError(
                "No Chrome profile configured. Run 'gemcli login' first."
            )

        # Try to connect to existing Chrome ONLY if we're not using an isolated profile.
        # If the user created a dedicated profile (gemcli login my-profile), we MUST
        # launch a dedicated headless instance to avoid hijacking their main daily browser.
        existing = find_existing_chrome()
        is_isolated = (
            self._chrome_profile_path
            and "gemini-web-mcp-cli/chrome-profiles" in self._chrome_profile_path
        )

        if existing and not is_isolated:
            self._port = existing
            logger.debug(f"Token Factory: reusing Chrome on port {existing}")
        else:
            # Use an isolated Token Factory profile — a copy of the login
            # profile.  This prevents SingletonLock contention with gemcli
            # login / CLI commands that may use the source profile concurrently.
            source_dir = Path(self._chrome_profile_path)
            source_dir.mkdir(parents=True, exist_ok=True)

            profile_dir = self._get_tf_profile_dir(source_dir)
            self._tf_profile_dir = profile_dir

            # Clean up any stale Chrome processes using the TF profile
            self._kill_stale_chrome(profile_dir)

            self._port = find_available_port()
            args = [
                chrome_path,
                f"--remote-debugging-port={self._port}",
                "--no-first-run",
                "--no-default-browser-check",
                "--disable-extensions",
                f"--user-data-dir={profile_dir}",
                "--remote-allow-origins=*",
                "--headless=new",
            ]
            try:
                self._process = subprocess.Popen(
                    args, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )
                time.sleep(3)
            except Exception as e:
                raise TokenFactoryError(f"Failed to launch Chrome: {e}")
            self._we_launched = True
            logger.debug(
                f"Token Factory: launched Chrome on port {self._port} "
                f"with TF profile {profile_dir}"
            )

        # Find or create Gemini page
        page = find_or_create_gemini_page(self._port)
        if not page:
            raise TokenFactoryError("Failed to open Gemini page in Chrome.")

        self._ws_url = page.get("webSocketDebuggerUrl")
        if not self._ws_url:
            raise TokenFactoryError("No WebSocket URL for Gemini page.")

        # Check if logged in
        current_url = get_current_url(self._ws_url)
        if "accounts.google.com" in current_url:
            raise AuthError("Not logged in to Gemini. Run 'gemcli login' first.")

        # Navigate to /app if not already there
        if "gemini.google.com/app" not in current_url:
            navigate_to_url(self._ws_url, GEMINI_APP_URL)

        # Wait for input field
        if not self._wait_for_input():
            raise TokenFactoryError("Gemini page failed to load (input field not found).")

        self._ready = True
        logger.debug("Token Factory: ready")

    def capture(
        self,
        prompt: str,
        model,
        metadata=None,
    ) -> CapturedRequest:
        """Capture a BotGuard token by triggering a request in Chrome.

        Args:
            prompt: The message to send
            model: Model object with .name and .header attributes
            metadata: ConversationMetadata for multi-turn (has .cid for conversation ID)

        Returns:
            CapturedRequest with URL, body, headers, and cookies for Python replay.
        """
        self.ensure_ready()

        # Navigate to the right conversation
        target_url = GEMINI_APP_URL
        if metadata and metadata.cid:
            target_url = f"{GEMINI_APP_URL}/{metadata.cid}"

        current = get_current_url(self._ws_url)
        if target_url not in current:
            navigate_to_url(self._ws_url, target_url)
            if not self._wait_for_input():
                raise TokenFactoryError("Gemini page failed to load after navigation.")

        # Install XHR interceptor
        run_js(self._ws_url, XHR_INTERCEPTOR_JS)

        # Type prompt and click send
        # Type dummy prompt strings to avoid truncation and browser hanging
        # from massive system prompts. We only need ANY text to trigger BotGuard.
        dummy_prompt = "[BotGuard Capture]"
        run_js(self._ws_url, TYPE_PROMPT_JS.format(prompt=dummy_prompt))
        time.sleep(0.5)
        run_js(self._ws_url, CLICK_SEND_JS)

        # Poll for captured request
        captured = self._poll_capture()
        if not captured:
            # Retry once: navigate fresh, re-install hook
            logger.debug("Token Factory: first capture failed, retrying...")
            navigate_to_url(self._ws_url, target_url)
            if not self._wait_for_input():
                raise TokenFactoryError("Gemini page failed to load on retry.")
            run_js(self._ws_url, XHR_INTERCEPTOR_JS)
            run_js(self._ws_url, TYPE_PROMPT_JS.format(prompt=dummy_prompt))
            time.sleep(0.5)
            run_js(self._ws_url, CLICK_SEND_JS)
            captured = self._poll_capture()
            if not captured:
                raise TokenFactoryError(
                    "Failed to capture BotGuard token after retry. "
                    "Chrome may not be on gemini.google.com."
                )

        # Build the full URL
        url = "https://gemini.google.com" + captured["url"]

        # Get JS-set headers (model header, tracking headers, etc.)
        js_headers = captured.get("headers", {})

        # Build complete Chrome-like headers
        headers = dict(CHROME_HEADERS)
        headers["x-browser-validation"] = compute_xbv(CHROME_USER_AGENT)
        headers.update(js_headers)

        # Override model header to the requested model
        if model and model.header:
            headers.update(model.header)

        # Grab ALL cookies from the browser
        cookies = self._get_google_cookies()

        # Extract the live SNlM0e access token from Chrome's window global.
        # This is the correct 'at=' token for the current Chrome session, which
        # must be used when replaying batchexecute calls with Chrome's cookies.
        # Mismatching Python's cached token with Chrome's cookies causes HTTP 400.
        chrome_access_token: str | None = None
        try:
            chrome_access_token = run_js(
                self._ws_url,
                "window.WIZ_global_data && window.WIZ_global_data.SNlM0e",
            )
            if chrome_access_token:
                logger.debug(
                    f"Token Factory: captured Chrome SNlM0e ({len(chrome_access_token)} chars)"
                )
            else:
                logger.debug("Token Factory: SNlM0e not found in window, will use cached token")
        except Exception as e:
            logger.debug(f"Token Factory: could not extract SNlM0e: {e}")

        # Navigate back to /app to leave Chrome in a clean state for next capture
        # (the aborted XHR may leave the page in a weird state)
        navigate_to_url(self._ws_url, GEMINI_APP_URL)

        return CapturedRequest(
            url=url,
            body=captured["body"],
            headers=headers,
            cookies=cookies,
            access_token=chrome_access_token,
        )

    def shutdown(self) -> None:
        """Clean up Chrome and resources."""
        if self._process and self._we_launched:
            try:
                self._process.terminate()
                self._process.wait(timeout=5)
            except Exception:
                try:
                    self._process.kill()
                except Exception:
                    pass
            self._process = None
        # Remove SingletonLock from the TF profile (what Chrome actually used)
        lock_dir = self._tf_profile_dir or (
            Path(self._chrome_profile_path) if self._chrome_profile_path else None
        )
        if lock_dir:
            (lock_dir / "SingletonLock").unlink(missing_ok=True)
        self._ready = False
        self._ws_url = None
        logger.debug("Token Factory: shutdown")

    @staticmethod
    def _kill_stale_chrome(profile_dir: Path) -> None:
        """Kill ALL Chrome processes using the given profile directory."""
        try:
            result = subprocess.run(
                ["pgrep", "-f", f"--user-data-dir={profile_dir}"],
                capture_output=True, text=True, timeout=5,
            )
            pids = [
                int(p) for p in result.stdout.strip().split("\n") if p.strip()
            ]
            for pid in pids:
                try:
                    os.kill(pid, signal.SIGTERM)
                    logger.debug(f"Token Factory: killing Chrome PID {pid}")
                except OSError:
                    pass
            if pids:
                # Wait for graceful exit (up to 5s), then SIGKILL survivors
                for _ in range(10):
                    alive = []
                    for pid in pids:
                        try:
                            os.kill(pid, 0)  # probe — raises OSError if dead
                            alive.append(pid)
                        except OSError:
                            pass
                    if not alive:
                        break
                    time.sleep(0.5)
                else:
                    for pid in alive:
                        try:
                            os.kill(pid, signal.SIGKILL)
                            logger.debug(
                                f"Token Factory: force-killed Chrome PID {pid}"
                            )
                        except OSError:
                            pass
                    time.sleep(1)
        except Exception as e:
            logger.debug(f"Token Factory: stale Chrome check skipped: {e}")
        # Remove stale SingletonLock regardless
        lock = profile_dir / "SingletonLock"
        lock.unlink(missing_ok=True)

    def _wait_for_input(self, timeout: int = 20) -> bool:
        """Wait for Gemini's input field to appear."""
        for _ in range(timeout):
            if run_js(self._ws_url, INPUT_READY_JS):
                return True
            time.sleep(1)
        return False

    def _poll_capture(self, timeout: int = 20) -> dict | None:
        """Poll window.__cap for a captured request."""
        for _ in range(timeout):
            time.sleep(1)
            result = run_js(self._ws_url, "window.__cap")
            if result:
                return result
        return None

    def get_raw_cookies(self) -> list[dict]:
        """Get the raw CDP cookie list (with domain/path info) from the last capture."""
        return self._raw_cookies

    def _get_google_cookies(self) -> dict[str, str]:
        """Get all Google/Gemini cookies from the browser."""
        all_cookies = get_page_cookies(self._ws_url)
        # Store raw cookies with domain info for cross-domain downloads
        self._raw_cookies = all_cookies
        cookies = {}
        for c in all_cookies:
            domain = c.get("domain", "")
            if "google.com" in domain or "gemini.google.com" in domain:
                cookies[c["name"]] = c["value"]
        return cookies
