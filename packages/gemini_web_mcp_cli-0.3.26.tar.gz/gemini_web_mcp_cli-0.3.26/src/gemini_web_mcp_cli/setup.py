"""MCP server setup commands for AI tool clients.

Configures the gemini-web-mcp server in various AI tool config files,
so the tools can use Gemini via MCP protocol.

Usage:
    gemcli setup add cursor
    gemcli setup add claude-desktop
    gemcli setup list
    gemcli setup remove cursor
"""

import json
import os
import platform
import shutil
import subprocess
from pathlib import Path

import click
from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.syntax import Syntax
from rich.table import Table

console = Console()

# MCP server command - the binary that clients will execute
MCP_SERVER_CMD = "gemini-web-mcp"
MCP_SERVER_KEY = "gemini-web-mcp"


# ── Helpers ─────────────────────────────────────────────────────────────────


def _read_json_config(path: Path) -> dict:
    """Read a JSON config file, returning empty dict if missing or invalid."""
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def _write_json_config(path: Path, config: dict) -> None:
    """Write a JSON config file, creating parent dirs as needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2) + "\n")


def _is_configured(config: dict, key: str = MCP_SERVER_KEY) -> bool:
    """Check if gemini-web-mcp is already in an mcpServers config."""
    servers = config.get("mcpServers", {})
    return key in servers


def _add_mcp_server(config: dict, key: str = MCP_SERVER_KEY, extra: dict | None = None) -> dict:
    """Add gemini-web-mcp to an mcpServers config dict."""
    config.setdefault("mcpServers", {})
    entry = {"command": MCP_SERVER_CMD, "args": []}
    if extra:
        entry.update(extra)
    config["mcpServers"][key] = entry
    return config


def _remove_mcp_server(config: dict, key: str = MCP_SERVER_KEY) -> bool:
    """Remove gemini-web-mcp from an mcpServers config dict. Returns True if removed."""
    servers = config.get("mcpServers", {})
    if key in servers:
        del servers[key]
        return True
    return False


# ── Config paths (platform-specific) ───────────────────────────────────────


def _claude_desktop_config_path() -> Path:
    system = platform.system()
    if system == "Darwin":
        return (
            Path.home() / "Library" / "Application Support" / "Claude"
            / "claude_desktop_config.json"
        )
    elif system == "Windows":
        return Path(os.environ.get("APPDATA", "")) / "Claude" / "claude_desktop_config.json"
    else:
        return Path.home() / ".config" / "claude" / "claude_desktop_config.json"


def _gemini_cli_config_path() -> Path:
    return Path.home() / ".gemini" / "settings.json"


def _cursor_config_path() -> Path:
    system = platform.system()
    if system == "Darwin":
        return Path.home() / ".cursor" / "mcp.json"
    elif system == "Windows":
        return Path(os.environ.get("APPDATA", "")) / "Cursor" / "User" / "mcp.json"
    else:
        return Path.home() / ".config" / "cursor" / "mcp.json"


def _windsurf_config_path() -> Path:
    system = platform.system()
    if system == "Darwin":
        return Path.home() / ".codeium" / "windsurf" / "mcp_config.json"
    elif system == "Windows":
        return Path(os.environ.get("APPDATA", "")) / "Codeium" / "windsurf" / "mcp_config.json"
    else:
        return Path.home() / ".config" / "codeium" / "windsurf" / "mcp_config.json"


def _cline_config_path() -> Path:
    return Path.home() / ".cline" / "data" / "settings" / "cline_mcp_settings.json"


def _antigravity_config_path() -> Path:
    return Path.home() / ".gemini" / "antigravity" / "mcp_config.json"


# ── Client registry ────────────────────────────────────────────────────────


CLIENT_REGISTRY = {
    "claude-code": {
        "name": "Claude Code",
        "description": "Anthropic CLI (claude command)",
        "config_fn": None,  # Uses claude mcp add
    },
    "claude-desktop": {
        "name": "Claude Desktop",
        "description": "Claude desktop application",
        "config_fn": _claude_desktop_config_path,
    },
    "gemini-cli": {
        "name": "Gemini CLI",
        "description": "Google Gemini CLI",
        "config_fn": _gemini_cli_config_path,
        "key": "gemini-web",
        "extra": {"trust": True},
    },
    "cursor": {
        "name": "Cursor",
        "description": "Cursor AI editor",
        "config_fn": _cursor_config_path,
    },
    "windsurf": {
        "name": "Windsurf",
        "description": "Codeium Windsurf editor",
        "config_fn": _windsurf_config_path,
    },
    "cline": {
        "name": "Cline CLI",
        "description": "Cline CLI terminal agent",
        "config_fn": _cline_config_path,
    },
    "antigravity": {
        "name": "Antigravity",
        "description": "Google Antigravity AI IDE",
        "config_fn": _antigravity_config_path,
        "key": "gemini-web",
    },
    "codex": {
        "name": "Codex",
        "description": "OpenAI Codex CLI agent (skill-based)",
        "config_fn": None,  # Uses AGENTS.md via gemcli skill install codex
    },
}

VALID_CLIENTS = list(CLIENT_REGISTRY.keys())


# ── Setup implementations ──────────────────────────────────────────────────


def _setup_claude_code() -> bool:
    """Add MCP to Claude Code via `claude mcp add`."""
    claude_cmd = shutil.which("claude")
    if not claude_cmd:
        console.print("[yellow]Warning:[/yellow] 'claude' command not found in PATH")
        console.print("  Install Claude Code: https://docs.anthropic.com/en/docs/claude-code")
        return False

    try:
        result = subprocess.run(
            [claude_cmd, "mcp", "add", "-s", "user", MCP_SERVER_KEY, "--", MCP_SERVER_CMD],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            console.print("[green]Added to Claude Code (user scope)[/green]")
            return True
        elif "already exists" in result.stderr.lower():
            console.print("[green]Already configured in Claude Code[/green]")
            return True
        else:
            console.print(f"[yellow]Warning:[/yellow] {result.stderr.strip()}")
            return False
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        console.print(f"[yellow]Warning:[/yellow] Could not run claude command: {e}")
        return False


def _setup_json_client(client_id: str) -> bool:
    """Add MCP to a JSON config-based client."""
    info = CLIENT_REGISTRY[client_id]
    config_fn = info["config_fn"]
    key = info.get("key", MCP_SERVER_KEY)
    extra = info.get("extra")

    config_path = config_fn()
    config = _read_json_config(config_path)

    if _is_configured(config, key):
        console.print(f"[green]Already configured in {info['name']}[/green]")
        return True

    _add_mcp_server(config, key=key, extra=extra)
    _write_json_config(config_path, config)
    console.print(f"[green]Added to {info['name']}[/green]")
    console.print(f"  [dim]{config_path}[/dim]")
    return True


def _remove_claude_code() -> bool:
    """Remove MCP from Claude Code."""
    claude_cmd = shutil.which("claude")
    if not claude_cmd:
        console.print("[yellow]Warning:[/yellow] 'claude' command not found")
        return False

    try:
        result = subprocess.run(
            [claude_cmd, "mcp", "remove", "-s", "user", MCP_SERVER_KEY],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            console.print("[green]Removed from Claude Code[/green]")
            return True
        else:
            console.print(f"[yellow]Note:[/yellow] {result.stderr.strip()}")
            return False
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        console.print(f"[yellow]Warning:[/yellow] {e}")
        return False


def _remove_json_client(client_id: str) -> bool:
    """Remove MCP from a JSON config-based client."""
    info = CLIENT_REGISTRY[client_id]
    config_fn = info["config_fn"]
    key = info.get("key", MCP_SERVER_KEY)

    config_path = config_fn()
    if not config_path.exists():
        console.print(f"[dim]No config file found for {info['name']}.[/dim]")
        return False

    config = _read_json_config(config_path)
    if _remove_mcp_server(config, key):
        _write_json_config(config_path, config)
        console.print(f"[green]Removed from {info['name']}[/green]")
        return True
    else:
        console.print(f"[dim]Gemini Web MCP was not configured in {info['name']}.[/dim]")
        return False


def _find_mcp_server_path() -> str | None:
    """Find the full path to the gemini-web-mcp binary."""
    return shutil.which(MCP_SERVER_CMD)


def _prompt_numbered(prompt_text: str, options: list[tuple[str, str]], default: int = 1) -> str:
    """Show a numbered prompt and return the chosen option value."""
    console.print(f"{prompt_text}")
    for i, (_value, label) in enumerate(options, 1):
        marker = " [dim](default)[/dim]" if i == default else ""
        console.print(f"  [cyan]{i}[/cyan]) {label}{marker}")

    valid = [str(i) for i in range(1, len(options) + 1)]
    choice = Prompt.ask("Choose", choices=valid, default=str(default), show_choices=False)
    return options[int(choice) - 1][0]


def _setup_json() -> None:
    """Interactive flow to generate MCP JSON config for any tool."""
    console.print("[bold]Generate MCP JSON config[/bold]\n")
    console.print("This generates a JSON snippet you can paste into any tool's MCP config.\n")

    config_type = _prompt_numbered("Config type:", [
        ("uvx", "uvx (no install required)"),
        ("regular", "Regular (uses installed binary)"),
    ])

    use_full_path = False
    if config_type == "regular":
        path_choice = _prompt_numbered("\nCommand format:", [
            ("name", f"Command name ({MCP_SERVER_CMD})"),
            ("full", "Full path to binary"),
        ])
        use_full_path = path_choice == "full"

    config_scope = _prompt_numbered("\nConfig scope:", [
        ("existing", "Add to existing config (server entry only)"),
        ("new", "New config file (includes mcpServers wrapper)"),
    ])

    # Build the server entry
    if config_type == "uvx":
        server_entry = {
            "command": "uvx",
            "args": ["--from", "gemini-web-mcp-cli", MCP_SERVER_CMD],
        }
    else:
        if use_full_path:
            binary_path = _find_mcp_server_path()
            if not binary_path:
                console.print(
                    f"\n[yellow]Warning:[/yellow] {MCP_SERVER_CMD} not found in PATH, "
                    "using command name instead"
                )
                binary_path = MCP_SERVER_CMD
            server_entry = {"command": binary_path}
        else:
            server_entry = {"command": MCP_SERVER_CMD}

    if config_scope == "new":
        output = {"mcpServers": {MCP_SERVER_KEY: server_entry}}
    else:
        output = {MCP_SERVER_KEY: server_entry}

    json_str = json.dumps(output, indent=2)

    console.print()
    console.print(Syntax(json_str, "json", theme="monokai", padding=1))
    console.print()

    if platform.system() == "Darwin":
        if Confirm.ask("Copy to clipboard?", default=True):
            try:
                subprocess.run(
                    ["pbcopy"],
                    input=json_str.encode(),
                    check=True,
                    timeout=5,
                )
                console.print("[green]✓[/green] Copied to clipboard")
            except (subprocess.SubprocessError, OSError):
                console.print("[yellow]Warning:[/yellow] Could not copy to clipboard")

# ── Click commands ──────────────────────────────────────────────────────────


@click.group()
def setup():
    """Configure Gemini Web MCP server for AI tools."""
    pass


@setup.command("add")
@click.argument("client", type=click.Choice(VALID_CLIENTS + ["json"]))
def setup_add(client):
    """Add Gemini Web MCP server to an AI tool.

    Examples:
        gemcli setup add cursor
        gemcli setup add claude-desktop
        gemcli setup add claude-code
        gemcli setup add gemini-cli
        gemcli setup add windsurf
        gemcli setup add json
    """
    if client == "json":
        _setup_json()
        return

    info = CLIENT_REGISTRY[client]
    console.print(f"\n[bold]{info['name']}[/bold] -- Adding Gemini Web MCP\n")

    if client == "codex":
        console.print("[yellow]Note:[/yellow] Codex uses AGENTS.md for configuration.")
        console.print("Use [bold]gemcli skill install codex[/bold] to install the skill.")
        return

    if client == "claude-code":
        success = _setup_claude_code()
    else:
        success = _setup_json_client(client)

    if success:
        console.print(f"\n[dim]Restart {info['name']} to activate the MCP server.[/dim]")


@setup.command("remove")
@click.argument("client", type=click.Choice(VALID_CLIENTS))
def setup_remove(client):
    """Remove Gemini Web MCP server from an AI tool.

    Examples:
        gemcli setup remove cursor
        gemcli setup remove claude-desktop
    """
    if client == "codex":
        console.print("[yellow]Note:[/yellow] Codex uses AGENTS.md for configuration.")
        console.print("Use [bold]gemcli skill uninstall codex[/bold] to remove the skill.")
        return

    if client == "claude-code":
        _remove_claude_code()
    else:
        _remove_json_client(client)


@setup.command("list")
def setup_list():
    """Show supported AI tools and their MCP configuration status."""
    table = Table(title="Gemini Web MCP Server Configuration")
    table.add_column("Client", style="cyan")
    table.add_column("Description")
    table.add_column("MCP Status", justify="center")
    table.add_column("Config Path", style="dim")

    for client_id, info in CLIENT_REGISTRY.items():
        status = "[dim]-[/dim]"
        config_path_str = ""

        if client_id == "claude-code":
            claude_cmd = shutil.which("claude")
            if claude_cmd:
                try:
                    result = subprocess.run(
                        [claude_cmd, "mcp", "list"],
                        capture_output=True, text=True, timeout=5,
                    )
                    if MCP_SERVER_KEY in result.stdout.lower():
                        status = "[green]yes[/green]"
                except (subprocess.TimeoutExpired, OSError):
                    status = "[dim]?[/dim]"
                config_path_str = "claude mcp list"
            else:
                config_path_str = "not installed"
        elif client_id == "codex":
            config_path_str = "gemcli skill install codex"
            status = "[dim]skill[/dim]"
        else:
            config_fn = info["config_fn"]
            key = info.get("key", MCP_SERVER_KEY)
            path = config_fn()
            config = _read_json_config(path)
            if _is_configured(config, key):
                status = "[green]yes[/green]"
            config_path_str = str(path).replace(str(Path.home()), "~")

        table.add_row(info["name"], info["description"], status, config_path_str)

    console.print(table)
    console.print("\n[dim]Add:    gemcli setup add <client>[/dim]")
    console.print("[dim]Remove: gemcli setup remove <client>[/dim]")
