# TODO: Chrome Profile Locking Fix (v0.3.26)

## Bug
Token Factory Chrome competes for SingletonLock with `gemcli login`/`gemcli chat` CLI.

## Fix: Layered Defense
- [x] **Fix D**: Token Factory uses `<profile>_tf/` copy — eliminates all contention
- [x] **Fix A**: Improved `_kill_stale_chrome` — SIGKILL fallback + wait for exit
- [x] **Fix C**: SIGTERM/SIGINT signal handlers — cleanup when subprocess killed
- [ ] Test manually
- [ ] Update CHANGELOG
- [ ] Bump version
