from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
from acp import RequestPermissionResponse, text_block
from acp.schema import AllowedOutcome
from unittest.mock import AsyncMock

from isaac.agent.tools.fetch_url import fetch_url
from isaac.agent.tools import get_tools, register_tools
from isaac.agent.tools.apply_patch import apply_patch
from isaac.agent.tools.code_search import code_search
from isaac.agent.tools.edit_file import edit_file
from isaac.agent.tools.file_summary import file_summary
from isaac.agent.tools.list_files import list_files
from isaac.agent.tools.read_file import read_file
from isaac.agent.tools import TOOL_HANDLERS, run_tool
from isaac.agent.tools.run_command import run_command
from tests.utils import make_function_agent
from pydantic_ai import Agent as PydanticAgent  # type: ignore
from pydantic_ai import DeferredToolRequests  # type: ignore
from pydantic_ai.models.test import TestModel  # type: ignore
from isaac.agent import ACPAgent
import httpx


@pytest.mark.asyncio
async def test_list_files(tmp_path: Path):
    (tmp_path / "a.txt").write_text("a")
    (tmp_path / "b.txt").write_text("b")

    result = await list_files(directory=str(tmp_path), recursive=False)
    assert result["error"] is None
    assert "a.txt" in result["content"]


@pytest.mark.asyncio
async def test_read_file_with_range(tmp_path: Path):
    target = tmp_path / "sample.txt"
    target.write_text("line1\nline2\nline3\n")

    result = await read_file(path=str(target), start=2, lines=1)
    assert result["error"] is None
    assert "line2" in result["content"]


@pytest.mark.asyncio
async def test_edit_file(tmp_path: Path):
    target = tmp_path / "edit.txt"
    result = await edit_file(path=str(target), content="new", create=True)
    assert result["error"] is None
    assert target.read_text() == "new"
    assert "diff" in result
    assert "+new" in result["diff"] or "new" in result["diff"]


@pytest.mark.asyncio
async def test_apply_patch(tmp_path: Path):
    target = tmp_path / "patch.txt"
    target.write_text("one\n")
    patch = """--- a/patch.txt
+++ b/patch.txt
@@ -1 +1 @@
-one
+two
"""
    result = await apply_patch(path=str(target), patch=patch, strip=1)
    assert result["error"] is None
    assert "two" in target.read_text()


@pytest.mark.asyncio
async def test_code_search(tmp_path: Path):
    target = tmp_path / "search.txt"
    target.write_text("hello world\n")
    result = await code_search(pattern="hello", directory=str(tmp_path))
    assert result["error"] is None
    assert "hello" in result["content"]


@pytest.mark.asyncio
async def test_run_command():
    result = await run_command("echo hi")
    assert result["error"] is None
    assert result["content"].strip() == "hi"


@pytest.mark.asyncio
async def test_file_summary(tmp_path: Path):
    target = tmp_path / "sum.txt"
    target.write_text("a\nb\nc\n")
    result = await file_summary(path=str(target), head_lines=1, tail_lines=1)
    assert result["error"] is None
    assert "Lines: 3" in result["content"]


@pytest.mark.asyncio
async def test_run_tool_reports_missing_args():
    result = await run_tool("edit_file")
    assert result["error"].startswith("Missing required arguments:")


def test_tool_list_includes_coding_delegate():
    tools = get_tools()
    tool_names = {tool.function for tool in tools}
    assert "coding" in tool_names
    coding = next(tool for tool in tools if tool.function == "coding")
    assert coding.description == "Delegate implementation work to a coding-focused agent."


@pytest.mark.asyncio
async def test_run_command_requests_permission():
    conn = AsyncMock()
    conn.request_permission = AsyncMock(
        return_value=RequestPermissionResponse(outcome=AllowedOutcome(option_id="reject_once", outcome="selected"))
    )
    agent = make_function_agent(conn)
    session_id = "perm-session"
    agent._session_modes[session_id] = "ask"
    agent._session_cwds[session_id] = Path.cwd()

    await agent._execute_run_command_with_terminal(session_id, tool_call_id="tc1", arguments={"command": "echo hi"})

    conn.request_permission.assert_awaited()
    assert conn.session_update.await_args_list, "Expected a session_update for permission denial"
    updates = [call.kwargs["update"] for call in conn.session_update.await_args_list]  # type: ignore[attr-defined]
    failed = [u for u in updates if getattr(u, "status", "") == "failed"]
    assert failed, "Expected a failed tool update after permission denial"
    raw_out = getattr(failed[-1], "raw_output", {}) or {}
    assert raw_out.get("error") == "permission denied"


@pytest.mark.asyncio
async def test_allow_always_cached_per_command():
    conn = AsyncMock()
    conn.request_permission = AsyncMock(
        return_value=RequestPermissionResponse(outcome=AllowedOutcome(option_id="allow_always", outcome="selected"))
    )
    agent = make_function_agent(conn)
    session_id = "perm-cache"
    agent._session_modes[session_id] = "ask"
    agent._session_cwds[session_id] = Path.cwd()

    first = await agent._request_run_permission(session_id, tool_call_id="tc-1", command="echo cached", cwd=None)
    second = await agent._request_run_permission(session_id, tool_call_id="tc-2", command="echo cached", cwd=None)

    assert first is True
    assert second is True
    conn.request_permission.assert_awaited_once()


@pytest.mark.asyncio
async def test_model_tool_call_requests_permission(monkeypatch: pytest.MonkeyPatch, tmp_path: Path):
    """Ensure ask mode prompts for permission when the model triggers run_command."""

    conn = AsyncMock()
    conn.session_update = AsyncMock()
    conn.request_permission = AsyncMock(
        return_value=RequestPermissionResponse(outcome=AllowedOutcome(option_id="allow_once", outcome="selected"))
    )

    calls: list[dict[str, object]] = []

    async def fake_run_command(
        ctx: Any = None, command: str = "", cwd: str | None = None, timeout: float | None = None
    ):
        calls.append({"command": command, "cwd": cwd, "timeout": timeout})
        return {"content": "ok", "error": None, "returncode": 0}

    monkeypatch.setattr("isaac.agent.tools.run_command", fake_run_command)
    monkeypatch.setitem(TOOL_HANDLERS, "run_command", fake_run_command)

    model = TestModel(call_tools=["run_command"], custom_output_text="done")
    ai_runner = PydanticAgent(model, output_type=[str, DeferredToolRequests])
    register_tools(ai_runner)
    from isaac.agent.brain import session_ops

    def _build(_model_id: str, _register: object, toolsets=None, **kwargs: object) -> object:
        _ = toolsets
        return ai_runner

    monkeypatch.setattr(session_ops, "create_subagent_for_model", _build)
    agent = ACPAgent(conn)
    session = await agent.new_session(cwd=str(tmp_path), mcp_servers=[])

    response = await agent.prompt(prompt=[text_block("run a command")], session_id=session.session_id)

    conn.request_permission.assert_awaited()
    assert calls, "Expected run_command to be invoked by the model"
    assert response.stop_reason == "end_turn"


@pytest.mark.asyncio
async def test_model_run_command_denied_blocks_execution(monkeypatch: pytest.MonkeyPatch, tmp_path: Path):
    """When permission is denied, run_command should not execute."""

    conn = AsyncMock()
    conn.session_update = AsyncMock()
    conn.request_permission = AsyncMock(
        return_value=RequestPermissionResponse(outcome=AllowedOutcome(option_id="reject_once", outcome="selected"))
    )

    calls: list[dict[str, object]] = []

    async def fake_run_command(
        ctx: Any = None, command: str = "", cwd: str | None = None, timeout: float | None = None
    ):
        calls.append({"command": command, "cwd": cwd, "timeout": timeout})
        return {"content": "ok", "error": None, "returncode": 0}

    monkeypatch.setattr("isaac.agent.tools.run_command", fake_run_command)
    monkeypatch.setitem(TOOL_HANDLERS, "run_command", fake_run_command)

    model = TestModel(call_tools=["run_command"], custom_output_text="done")
    ai_runner = PydanticAgent(model, output_type=[str, DeferredToolRequests])
    register_tools(ai_runner)
    from isaac.agent.brain import session_ops

    def _build(_model_id: str, _register: object, toolsets=None, **kwargs: object) -> object:
        _ = toolsets
        return ai_runner

    monkeypatch.setattr(session_ops, "create_subagent_for_model", _build)
    agent = ACPAgent(conn)
    session = await agent.new_session(cwd=str(tmp_path), mcp_servers=[])
    agent._session_modes[session.session_id] = "ask"

    await agent.prompt(prompt=[text_block("run a command")], session_id=session.session_id)

    conn.request_permission.assert_awaited()
    assert calls == [], "run_command should not execute when denied"


@pytest.mark.asyncio
async def test_request_permission_path():
    """Ensure permission is requested via the ACP request_permission hook."""

    conn = AsyncMock()
    conn.session_update = AsyncMock()
    conn.request_permission = AsyncMock(
        return_value=RequestPermissionResponse(outcome=AllowedOutcome(option_id="allow_once", outcome="selected"))
    )

    agent = make_function_agent(conn)
    session_id = "camel-session"
    agent._session_modes[session_id] = "ask"
    agent._session_cwds[session_id] = Path.cwd()

    allowed = await agent._request_run_permission(
        session_id=session_id, tool_call_id="tc-camel", command="echo hi", cwd=None
    )

    assert allowed is True
    conn.request_permission.assert_awaited()


@pytest.mark.asyncio
async def test_fetch_url_uses_mock_transport(monkeypatch: pytest.MonkeyPatch):
    calls = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(str(request.url))
        return httpx.Response(200, text="hello world", headers={"content-type": "text/plain"})

    transport = httpx.MockTransport(handler)

    import importlib

    fetch_mod = importlib.import_module("isaac.agent.tools.fetch_url")
    orig_async_client = fetch_mod.httpx.AsyncClient

    class _MockAsyncClient:
        def __init__(self, *args, **kwargs):
            self._client = orig_async_client(transport=transport, follow_redirects=True, timeout=kwargs.get("timeout"))

        async def __aenter__(self):
            return self

        async def __aexit__(self, *exc):
            await self._client.aclose()

        def stream(self, method: str, url: str, headers=None):
            return self._client.stream(method, url, headers=headers)

    monkeypatch.setattr(fetch_mod.httpx, "AsyncClient", _MockAsyncClient)
    await fetch_mod._clear_fetch_cache()

    result = await fetch_url("https://example.com")

    assert result["error"] is None
    assert "hello world" in result["content"]
    assert result["status_code"] == 200
    assert not result["truncated"]
    assert calls and "example.com" in calls[0]


@pytest.mark.asyncio
async def test_fetch_url_truncates(monkeypatch: pytest.MonkeyPatch):
    body = "x" * 50

    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text=body)

    transport = httpx.MockTransport(handler)

    import importlib

    fetch_mod = importlib.import_module("isaac.agent.tools.fetch_url")
    orig_async_client = fetch_mod.httpx.AsyncClient

    class _MockAsyncClient:
        def __init__(self, *args, **kwargs):
            self._client = orig_async_client(transport=transport, follow_redirects=True, timeout=kwargs.get("timeout"))

        async def __aenter__(self):
            return self

        async def __aexit__(self, *exc):
            await self._client.aclose()

        def stream(self, method: str, url: str, headers=None):
            return self._client.stream(method, url, headers=headers)

    monkeypatch.setattr(fetch_mod.httpx, "AsyncClient", _MockAsyncClient)
    await fetch_mod._clear_fetch_cache()

    result = await fetch_url("https://example.com", max_bytes=10)

    assert result["error"] is None
    assert result["truncated"] is True
    assert len(result["content"]) <= 10


@pytest.mark.asyncio
async def test_fetch_url_blocks_bad_scheme():
    result = await fetch_url("file:///etc/passwd")
    assert result["error"]
    assert "https" in result["error"].lower()
