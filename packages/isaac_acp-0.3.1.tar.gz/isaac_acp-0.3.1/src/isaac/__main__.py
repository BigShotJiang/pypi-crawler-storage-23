from isaac.agent.agent import main_entry

if __name__ == "__main__":
    main_entry()
