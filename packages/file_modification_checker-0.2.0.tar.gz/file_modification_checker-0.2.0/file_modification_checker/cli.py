from .modified_checker import find_differences as find
from pathlib import Path
import argparse
parser = argparse.ArgumentParser(description="tool to check for modifications")
parser.add_argument("folder", help="Name of folder to scan.")
parser.add_argument("-e","--exclude", nargs="+", required= False, default=[], help = "file suffixes to exclude (seperate by spaces)")
parser.add_argument("-i", "--information", nargs = "+", required = False, default = [], help="gives information on the files")
args=parser.parse_args()
folder = Path(args.folder)
new, deleted, modified = find(folder)
def return_values():
    for change_type in [new, deleted, modified]:
        for i, change in enumerate(change_type.copy()):
            if change.suffix in args.exclude:
                change_type.remove(change)
            else:
                if change_type != deleted:
                    change_list = [change.name]
                    if "size" in args.information:
                        change_list.append(change.stat().st_size)
                    if "date" in args.information:
                        change_list.append(change.stat().st_mtime)
                    if "permissions" in args.information:
                        change_list.append(change.stat().st_mode)
                    if "owner" in args.information:
                        change_list.append(change.stat().st_uid)
                    if "group" in args.information:
                        change_list.append(change.stat().st_gid)
                    if "contents" in args.information:
                        change_list.append(change.read_text())
                    print(change_list)
                else:
                    change_list.append("deleted, no infromation available")
                change_type[i] = change_list
    print(f"\033[31mDeleted Files: {[file for file in deleted]}\033[0m")
    print(f"\033[32mAdded Files: {[file for file in new]}\033[0m")
    print(f"\033[33mModified Files: {[file for file in modified]}\033[0m")