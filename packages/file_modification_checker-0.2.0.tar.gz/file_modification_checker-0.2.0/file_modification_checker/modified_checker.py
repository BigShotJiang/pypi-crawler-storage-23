#!/usr/bin/env python3
from pathlib import Path
from multiprocessing import Pool, cpu_count
#lets try with file names instead of file sizes
def get_file_sizes(folder:Path)->list:
    list_of_file_sizes = []
    for item in folder.iterdir():
        if item.is_file():
            list_of_file_sizes.append(item)
        else:
            list_of_file_sizes.extend(get_file_sizes(item))
            continue
    return list_of_file_sizes

def find_differences(folder)->list:
    #get the file sizes before the changes
    before_changes = get_file_sizes(folder)
    before_changes_texts = [file.read_text() for file in before_changes]
    #wait for the user to make changes to the files in the folder
    input("Make changes to the files in the folder and press Enter when done. ")
    #get the file sizes after the changes
    after_changes = get_file_sizes(folder)
    #find the differences between the two lists of file sizes
    deleted_differences = [file for file in before_changes if file not in after_changes]
    new_differences = [file for file in after_changes if file not in before_changes]
    #find the modified files
    modified_differences = []
    #set before and after changes to exclude the new and deleted files
    before_changes = [file for file in before_changes if file not in deleted_differences]
    after_changes = [file for file in after_changes if file not in new_differences]
    #compare the texts of the files
    for index in range(len(before_changes)):
        file = before_changes[index]
        if before_changes_texts[index] != after_changes[index].read_text():
            modified_differences.append(file)  
    #return the differences
    return new_differences, deleted_differences, modified_differences
