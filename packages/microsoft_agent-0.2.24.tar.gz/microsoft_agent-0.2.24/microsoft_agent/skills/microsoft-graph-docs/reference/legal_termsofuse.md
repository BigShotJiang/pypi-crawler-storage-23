[ Skip to main content ](https://learn.microsoft.com/en-us/legal/termsofuse#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/legal/termsofuse)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/legal/termsofuse)
# learn.microsoft.com - Terms of Use
[](https://learn.microsoft.com/en-us/legal/termsofuse#acceptance-of-terms)
## Acceptance of Terms
The following Terms of Use ("TOU") apply to your use of the Microsoft Learn website ([https://learn.microsoft.com](https://learn.microsoft.com/en-us/)), Microsoft Learn Profile and any associated services. Microsoft reserves the right to update the TOU at any time without notice to you. The most current version of the TOU can be reviewed by clicking on the "Terms of Use" hypertext link located at the bottom of our Web pages.
[](https://learn.microsoft.com/en-us/legal/termsofuse#description-of-service)
## Description of Service
Through the Microsoft Learn website, Microsoft Learn and associated services, Microsoft provides you with access to a variety of resources, including interactive training tutorials, documentation, videos, developer tools, download areas, communication forums and product information (collectively the "Services"). The Services, including any updates, enhancements, new features, and/or the addition of any new Web properties, are subject to the TOU.
[](https://learn.microsoft.com/en-us/legal/termsofuse#personal-and-non-commercial-use-limitation)
## Personal and Non-Commercial Use Limitation
Unless otherwise specified, the Services are for your personal and non-commercial use. You may not modify, copy, distribute, transmit, publicly display, perform, reproduce, publish, license, create derivative works from, transfer or sell any information, software, products or services obtained from the Services (except for your own, personal, non-commercial use) without prior written consent from Microsoft. For your own safety, do not post any sensitive information, such as passwords, dates of birth, Social Security numbers, passport numbers, credit card information, or financial information.
[](https://learn.microsoft.com/en-us/legal/termsofuse#privacy-and-protection-of-personal-information)
## Privacy and Protection of Personal Information
Your privacy is important to us. Please read the [Microsoft Privacy Statement](https://privacy.microsoft.com/privacystatement) (the "Privacy Statement") as it describes the types of data we collect from you and your devices, how we use that data, and the legal bases we have to process that data. The Privacy Statement also describes how Microsoft uses the Submissions (as defined herein), comments, ratings or reviews of the Services, communications, files, photos, documents, audio, digital works, livestreams, videos and any other content that you upload, store, broadcast or share through the Services, (collectively, "Your Content"). Where processing is based on consent and to the extent permitted by law, by agreeing to these Terms, you consent to Microsoft’s collection, use and disclosure of Your Content and data as described in the Privacy Statement. In some cases, we will provide separate notice and request your consent as referenced in the Privacy Statement.
**Public user Information and Content** : The user information you provide (including your username, display name, avatar image, biography, your job title and organization, your activities on Microsoft Learn website, and your user achievements) may be viewed by others. You are only required to provide a username and display name in order to use the Microsoft Learn Profile. All other fields are optional. You may update your username and display name at any time. Microsoft may also collect and publicly display the date that you registered with Microsoft Learn Profile and your affiliation with Microsoft.
Any Content you post publicly may also be viewed by others. You may be able to delete certain types of Content after they have been posted, but not all types of Content can be deleted after they have been posted publicly.
[](https://learn.microsoft.com/en-us/legal/termsofuse#notice-specific-to-software-available-on-this-website)
## Notice Specific to Software Available on this Website
Any software that is made available to download from the Services ("Software") is the copyrighted work of Microsoft and/or its suppliers. Use of the Software is governed by the terms of the end user license agreement, if any, which accompanies or is included with the Software ("License Agreement"). An end user will be unable to install any Software that is accompanied by or includes a License Agreement, unless he or she first agrees to the License Agreement terms. Third party scripts or code, linked to or referenced from this website, are licensed to you by the third parties that own such code, not by Microsoft.
The Software is made available for download solely for use by end users according to the License Agreement. Any reproduction or redistribution of the Software not in accordance with the License Agreement is expressly prohibited by law, and may result in severe civil and criminal penalties. Violators will be prosecuted to the maximum extent possible.
WITHOUT LIMITING THE FOREGOING, COPYING OR REPRODUCTION OF THE SOFTWARE TO ANY OTHER SERVER OR LOCATION FOR FURTHER REPRODUCTION OR REDISTRIBUTION IS EXPRESSLY PROHIBITED, UNLESS SUCH REPRODUCTION OR REDISTRIBUTION IS EXPRESSLY PERMITTED BY THE LICENSE AGREEMENT ACCOMPANYING SUCH SOFTWARE.
THE SOFTWARE IS WARRANTED, IF AT ALL, ONLY ACCORDING TO THE TERMS OF THE LICENSE AGREEMENT. EXCEPT AS WARRANTED IN THE LICENSE AGREEMENT, MICROSOFT CORPORATION HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS WITH REGARD TO THE SOFTWARE, INCLUDING ALL WARRANTIES AND CONDITIONS OF MERCHANTABILITY, WHETHER EXPRESS, IMPLIED OR STATUTORY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. FOR YOUR CONVENIENCE, MICROSOFT MAY MAKE AVAILABLE AS PART OF THE SERVICES OR IN ITS SOFTWARE PRODUCTS, TOOLS AND UTILITIES FOR USE AND/OR DOWNLOAD. MICROSOFT DOES NOT MAKE ANY ASSURANCES WITH REGARD TO THE ACCURACY OF THE RESULTS OR OUTPUT THAT DERIVES FROM SUCH USE OF ANY SUCH TOOLS AND UTILITIES. PLEASE RESPECT THE INTELLECTUAL PROPERTY RIGHTS OF OTHERS WHEN USING THE TOOLS AND UTILITIES MADE AVAILABLE ON THE SERVICES OR IN MICROSOFT SOFTWARE PRODUCTS.
RESTRICTED RIGHTS LEGEND. Any Software which is downloaded from the Services for or on behalf of the United States of America, its agencies and/or instrumentalities ("U.S. Government"), is provided with Restricted Rights. Use, duplication, or disclosure by the U.S. Government is subject to restrictions as set forth in subparagraph (c)(1)(ii) of the Rights in Technical Data and Computer Software clause at DFARS 252.227-7013 or subparagraphs (c)(1) and (2) of the Commercial Computer Software - Restricted Rights at 48 CFR 52.227-19, as applicable. Manufacturer is Microsoft Corporation, One Microsoft Way, Redmond, WA 98052-6399.
[](https://learn.microsoft.com/en-us/legal/termsofuse#notice-specific-to-documents-available-on-this-website)
## Notice Specific to Documents Available on this Website
Certain documentation may be subject to explicit license terms separate from the terms contained here. To the extent the terms conflict, the explicit license terms control. Permission to use Documents (such as white papers, press releases, datasheets and FAQs) from the Services is granted, provided that (1) the below copyright notice appears in all copies and that both the copyright notice and this permission notice appear, (2) use of such Documents from the Services is for informational and non-commercial or personal use only and will not be copied or posted on any network computer or broadcast in any media, and (3) no modifications of any Documents are made. Accredited educational institutions, such as K-12, universities, private/public colleges, and state community colleges, may download and reproduce the Documents for distribution in the classroom. Distribution outside the classroom requires express written permission. Use for any other purpose is expressly prohibited by law, and may result in severe civil and criminal penalties. Violators will be prosecuted to the maximum extent possible.
Documents specified above do not include the design or layout of the Microsoft.com website or any other Microsoft owned, operated, licensed or controlled site. Elements of Microsoft websites are protected by trade dress, trademark, unfair competition, and other laws and may not be copied or imitated in whole or in part. No logo, graphic, sound or image from any Microsoft website may be copied or retransmitted unless expressly permitted by Microsoft.
[](https://learn.microsoft.com/en-us/legal/termsofuse#disclaimer-and-limitation-of-liability-for-the-services)
## Disclaimer and Limitation of Liability for the Services
MICROSOFT AND/OR ITS RESPECTIVE SUPPLIERS MAKE NO REPRESENTATIONS ABOUT THE SUITABILITY OF THE SERVICES OR THE SUITABILITY OF THE INFORMATION CONTAINED IN THE DOCUMENTS AND RELATED GRAPHICS PUBLISHED AS PART OF THE SERVICES FOR ANY PURPOSE. ALL SERVICES, DOCUMENTS AND RELATED GRAPHICS ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. MICROSOFT AND/OR ITS RESPECTIVE SUPPLIERS HEREBY DISCLAIM ALL WARRANTIES AND CONDITIONS WITH REGARD TO THE SERVICES, INFORMATION AND RELATED GRAPHICS, INCLUDING ALL WARRANTIES AND CONDITIONS OF MERCHANTABILITY, WHETHER EXPRESS, IMPLIED OR STATUTORY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT SHALL MICROSOFT AND/OR ITS RESPECTIVE SUPPLIERS BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE SERVICES, INCLUDING THE USE OR PERFORMANCE OF INFORMATION AVAILABLE FROM THE SERVICES.
THE DOCUMENTS AND RELATED GRAPHICS PUBLISHED ON THE SERVICES COULD INCLUDE TECHNICAL INACCURACIES OR TYPOGRAPHICAL ERRORS. CHANGES ARE PERIODICALLY ADDED TO THE INFORMATION HEREIN. MICROSOFT AND/OR ITS RESPECTIVE SUPPLIERS MAY MAKE IMPROVEMENTS AND/OR CHANGES IN THE PRODUCT(S) AND/OR THE PROGRAM(S) DESCRIBED HEREIN AT ANY TIME.
IN NO EVENT SHALL MICROSOFT AND/OR ITS RESPECTIVE SUPPLIERS BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE SERVICES, SOFTWARE, DOCUMENTS, PROVISION OF OR FAILURE TO PROVIDE SERVICES, OR INFORMATION AVAILABLE FROM THE SERVICES.
[](https://learn.microsoft.com/en-us/legal/termsofuse#microsoft-learn-profile-account-password-and-security)
## Microsoft Learn Profile Account, Password, and Security
You may need a Microsoft account, Azure Active Directory account or Microsoft Learn Profile account to access some of the Services.
**Microsoft Account**. Your Microsoft account lets you sign in to products, websites and services provided by Microsoft and some Microsoft partners. You can [create a Microsoft account by signing up online](https://signup.live.com/). Microsoft accounts are subject to the [Microsoft Services Agreement](https://www.microsoft.com/servicesagreement/).
**Azure Active Directory Account**. You may have an account with Microsoft through an organization to which you belong. Please contact your organization’s administrator for information about this account.
**Microsoft Learn Profile Account**. Your Microsoft Learn Profile account lets you sign in to the Microsoft Learn website and use the associated services, including free access to training resources, unblocking achievements, rating, commenting, posting content and using other interactive services. You can create a Microsoft Learn Profile account by creating a username in Microsoft Learn Profile after logging-in with a Microsoft Account or Azure Active Directory Account.
You agree not to use any false, inaccurate or misleading information when signing up for your Microsoft Learn Profile account. You are entirely responsible for maintaining the confidentiality of your password and account. Furthermore, you are entirely responsible for any and all activities that occur under your account. You agree to notify Microsoft immediately of any unauthorized use of your account or any other breach of security. Microsoft will not be liable for any loss that you may incur as a result of someone else using your password or account, either with or without your knowledge. However, you could be held liable for losses incurred by Microsoft or another party due to someone else using your account or password. You may not use anyone else's account at any time, without the permission of the account holder.
If you create a Microsoft Learn Profile account on behalf of an entity, such as your business or employer, you represent that you have the legal authority to bind that entity to these Terms. You cannot transfer your Microsoft Learn Profile account credentials to another user or entity. To protect your account, keep your account details confidential. You are responsible for all activity that occurs under your Microsoft Learn Profile account.
You may close your Microsoft Learn Profile Account by accessing your Microsoft Learn Profile account settings.
[](https://learn.microsoft.com/en-us/legal/termsofuse#no-unlawful-or-prohibited-use)
## No Unlawful or Prohibited Use
As a condition of your use of the Services, you will not use the Services for any purpose that is unlawful or prohibited by these terms, conditions, and notices. You may not use the Services in any manner that could damage, disable, overburden, or impair any Microsoft server, or the network(s) connected to any Microsoft server, or interfere with any other party's use and enjoyment of any Services. You may not attempt to gain unauthorized access to any Services, other accounts, computer systems or networks connected to any Microsoft server or to any of the Services, through hacking, password mining or any other means. You may not obtain or attempt to obtain any materials or information through any means not intentionally made available through the Services.
[](https://learn.microsoft.com/en-us/legal/termsofuse#policies)
## Policies
To ensure the digital safety of how users interact with each other in their content and their conduct, The Services has rules about what types of content and conduct are not allowed. Prohibited content will be removed. Your account may be suspended or deleted from the Services if you post harmful content.
[](https://learn.microsoft.com/en-us/legal/termsofuse#bullying-and-harassment)
### Bullying and harassment
We do not allow content or conduct that targets a person or group with abusive behavior. This includes any action that:
  * Harasses, intimidates, or threatens others.
  * Hurts people by insulting or belittling them.
  * Continues contact or interaction that is unwelcome, especially where contact causes others to fear injury.


[](https://learn.microsoft.com/en-us/legal/termsofuse#child-sexual-exploitation-and-abuse-csea)
### Child sexual exploitation and abuse (CSEA)
We do not allow the exploitation of, harm, or threat of harm to children on the Services, CSEA is any content or activity that harms or threatens to harm a child through exploitation, trafficking, extortion, or endangerment. This includes sharing visual media that contain sexual content that involves or sexualizes a child. CSEA also includes grooming, which is the inappropriate interaction with children by contacting, private messaging, or talking with a child to ask for or offer sex or sexual content, sharing content that is sexually suggestive, and planning to meet with a child for sexual encounters. A child is anyone under 18 years old or who has not reached the age of majority under applicable law.
We will automatically delete the Microsoft Learn account of any user posting CSEA.
[](https://learn.microsoft.com/en-us/legal/termsofuse#coordination-of-harm)
### Coordination of harm
The Services should never be used to hurt people, including by working with others to cause physical harm. Cooperating or making specific plans with others with the shared purpose of harming someone physically is not allowed.
[](https://learn.microsoft.com/en-us/legal/termsofuse#graphic-violence-and-gore)
### Graphic violence and gore
Real-world violent content can be disturbing, offensive, or even traumatic for users.
We do not permit any visual content that promotes real-world violence or human gore.
This may include images or videos that show:
  * Real acts of serious physical harm or death against a person or group.
  * Violent domestic abuse against a real person or people.
  * Severe effects or physical trauma, such as internal organs or tissues, burnt remains of a person, severed limbs, or beheading.


[](https://learn.microsoft.com/en-us/legal/termsofuse#hate-speech-and-discrimination)
### Hate speech and discrimination
We do not allow hateful content that attacks, insults, or degrades someone because of a protected trait, such as their race, ethnicity, gender, gender identity, sexual orientation, religion, national origin, age, disability status, or caste.
Hate speech includes:
  * Promoting harmful stereotypes about people because of a protected trait.
  * Dehumanizing statements, such as comparing someone to an animal or other non-human, because of a protected trait.
  * Encouraging or supporting violence against someone because of a protected trait.
  * Calling for segregation, exclusion, or intimidation of people because of their protected trait.
  * Symbols, logos, or other images that are recognized as communicating hatred or racial superiority.


[](https://learn.microsoft.com/en-us/legal/termsofuse#non-consensual-intimate-imagery--intimate-extortion)
### Non-consensual intimate imagery & intimate extortion
We do not allow the sharing of sexually intimate images of someone without their permission—also called non-consensual intimate imagery, or NCII. We do not allow NCII to be distributed on our services, nor do we allow any content that praises, supports, or request NCII.
In general, if a video or image has the following traits, we treat it as NCII:
  * It was taken privately, not in a professional setting.
  * It shows sexual activity, nudity, or a sexualized body part.
  * The person shown in the imagery didn’t agree to either the creation or the sharing of the imagery.


Additionally, Microsoft does not allow any threats to share or publish NCII—also called intimate extortion. This includes asking for or threatening a person to get money, images, or other value things in exchange for not making the NCII public.
[](https://learn.microsoft.com/en-us/legal/termsofuse#sexual-solicitation)
### Sexual solicitation
We do not allow people to use its products and services to ask for or offer sex, sexual services, or sexual content in exchange for money or something else of value.
[](https://learn.microsoft.com/en-us/legal/termsofuse#suicide-and-self-injury)
### Suicide and self-injury
We work to remove any content about suicide and self-harm that could be dangerous. We also know that people may use our services to talk about mental health, share their stories, or join groups with others who have been affected by suicide or self-injury.
This includes the following (without limitation):
  * Supporting general ways people can end their lives, such as with a gun, hanging, or drug overdose.
  * Encouraging someone to take their life.
  * Showing images of real or attempted suicide.
  * Praising those who have died by suicide for taking their own life.


Self-injury content demonstrates, praises, or inspires physical harm to oneself, including through cutting, burning, or carving one’s skin. It also includes content that encourages or instructs on eating disorders, or systematic over or under-eating.
[](https://learn.microsoft.com/en-us/legal/termsofuse#terrorism-and-violent-extremism)
### Terrorism and violent extremism
We do not allow content that praises or supports terrorists or violent extremists, helps them to recruit, or encourages or enables their activities. We look to the United Nations Security Council’s Consolidated List to identify terrorists or terrorist groups. Violent extremists include people who embrace an ideology of violence or violent hatred towards another group.
We will delete the Microsoft Learn account of any user posting terrorism and violent extremism content.
[](https://learn.microsoft.com/en-us/legal/termsofuse#trafficking)
### Trafficking
We do not allow any content that perpetrates human trafficking. Trafficking happens when someone exploits someone else for personal gain by depriving them of their human rights.
Trafficking commonly includes three parts:
  * The act of recurring, moving, relocating, paying for, or abducting people.
  * The use of—or threat of—force, lies, trickery, or coercion to do these activities.
  * The activities are done for money, status, or some other kind of gain.


Trafficking includes forcing people to work, marry, engage in sexual activity, or have medical treatments or operations without their consent and is not limited to any age or background.
[](https://learn.microsoft.com/en-us/legal/termsofuse#violent-threats-incitement-and-glorification-of-violence)
### Violent threats, incitement, and glorification of violence
We do not permit content that encourages violence against other people through violent threats or incitement.
Threats of violence are words that show a specific intention to cause someone serious physical harm.
Incitement is material that encourages, urges, or is likely to result in serious physical harm to a person or group.
We also do not allow the glorification of violence through content that praises or supports real acts of violence causing serious physical harm to people or groups, including violence that happened in the past.
[](https://learn.microsoft.com/en-us/legal/termsofuse#adult-and-sexual)
### Adult and sexual
We do not allow the use of the Services to generate or share inappropriate content or material (involving, for example, nudity, bestiality, pornography, offensive language, graphic violence, self-harm, or criminal activity).
[](https://learn.microsoft.com/en-us/legal/termsofuse#profanity-and-vulgarity)
### Profanity and vulgarity
We do not allow swearing or any other dismissive language.
[](https://learn.microsoft.com/en-us/legal/termsofuse#spam)
### Spam
We do not allow spam or any posts that engage in phishing or the generation or distribution of malware.
Spam is unwanted or unsolicited bulk email, postings, contact requests, SMS (text messages), instant messages, or similar electronic communications.
Phishing is sending emails or other electronic communications to fraudulently or unlawfully induce recipients to reveal personal or sensitive information to gain access to accounts or records, exfiltration of documents or other sensitive information, payment and/or financial benefit.
Malware includes any activity designed to cause technical harm, such as delivering malicious executables, organizing denial of service attacks, or managing command and control servers.
[](https://learn.microsoft.com/en-us/legal/termsofuse#defamation-impersonation-false-information)
### Defamation, impersonation, false information
We do not allow any activities that are fraudulent, false, or misleading (e.g., asking for money under false pretenses, impersonating someone else, defamation, manipulating the Services to increase play count, or affect rankings, ratings, or comments).
[](https://learn.microsoft.com/en-us/legal/termsofuse#use-of-services)
## Use of Services
The Services may contain e-mail services, bulletin board services, chat areas, news groups, forums, communities, personal web pages, calendars, photo albums, file cabinets and/or other message or communication facilities designed to enable you to communicate with others. You agree to use the Services only to post, send and receive messages and material that are proper and, when applicable, related to the particular Service. By way of example, and not as a limitation, you agree that when using the Services, you will not:
  * Use the Services in connection with surveys, contests, pyramid schemes, chain letters, junk email, spamming or any duplicative or unsolicited messages (commercial or otherwise).
  * Upload, or otherwise make available, files that contain images, photographs, software or other material protected by intellectual property laws, including, by way of example, and not as limitation, copyright or trademark laws (or by rights of privacy or publicity) unless you own or control the rights thereto or have received all necessary consent to do the same.
  * Use any material or information, including images or photographs, which are made available through the Services in any manner that infringes any copyright, trademark, patent, trade secret, or other proprietary right of any party.
  * Upload files that contain viruses, Trojan horses, worms, time bombs, cancelbots, corrupted files, or any other similar software or programs that may damage the operation of another's computer or property of another.
  * Advertise or offer to sell or buy any goods or services for any business purpose, unless the Services specifically allows such messages.
  * Download any file posted by another user of a Service that you know, or reasonably should know, cannot be legally reproduced, displayed, performed, and/or distributed in such manner.
  * Falsify or delete any copyright management information, such as author attributions, legal or other proper notices or proprietary designations or labels of the origin or source of software or other material contained in a file that is uploaded.
  * Restrict or inhibit any other user from using and enjoying the Services.
  * Violate any code of conduct or other guidelines which may be applicable for any particular Service.
  * Harvest or otherwise collect information about others, including e-mail addresses.
  * Violate any applicable laws or regulations.
  * Create a false identity for the purpose of misleading others.
  * Use, download or otherwise copy, or provide (whether or not for a fee) to a person or entity any directory of users of the Services or other user or usage information or any portion thereof.


Microsoft has no obligation to monitor the Services. However, Microsoft reserves the right to review materials posted to the Services and to remove any materials in its sole discretion. Microsoft reserves the right to terminate your access to any or all of the Services at any time, without notice, for any reason whatsoever.
Microsoft reserves the right at all times to disclose any information as Microsoft deems necessary to satisfy any applicable law, regulation, legal process or governmental request, or to edit, refuse to post or to remove any information or materials, in whole or in part, in Microsoft's sole discretion.
Always use caution when giving out any personally identifiable information about yourself or your children in any Services. Microsoft does not control or endorse the content, messages or information found in any Services and, therefore, Microsoft specifically disclaims any liability with regard to the Services and any actions resulting from your participation in any Services. Managers and hosts are not authorized Microsoft spokespersons, and their views do not necessarily reflect those of Microsoft.
Microsoft isn't responsible for the content of any user-created posting, listing, or message. The decision to view content or engage with others is yours. We advise you to use your judgment.
Materials uploaded to the Services may be subject to posted limitations on usage, reproduction and/or dissemination; you are responsible for adhering to such limitations if you download the materials.
Some information you provide or upload to the Services may be stored outside of the country in which you reside.
The videos and eBooks might be in English only. If you click the links, you may be redirected to a U.S. website whose content is solely in English.
[](https://learn.microsoft.com/en-us/legal/termsofuse#materials-provided-to-microsoft-or-posted-to-the-services)
## Materials Provided to Microsoft or Posted to the Services
Microsoft does not claim ownership of the materials you provide to Microsoft (including feedback and suggestions) or post, upload, input or submit to any Services or its associated services for review by the general public, or by the members of any public or private community, (each a "Submission" and collectively "Submissions"). However, by posting, uploading, inputting, providing or submitting ("Posting") your Submission you are granting Microsoft, its affiliated companies and necessary sublicensees permission to use your Submission in connection with the operation of their Internet businesses (including, without limitation, all Microsoft Services), including, without limitation, the license rights to: copy, distribute, transmit, publicly display, publicly perform, reproduce, edit, translate and reformat your Submission; to publish your name in connection with your Submission; and the right to sublicense such rights to any supplier of the Services.
No compensation will be paid with respect to the use of your Submission, as provided herein. Microsoft is under no obligation to post or use any Submission you may provide and Microsoft may remove any Submission at any time in its sole discretion.
By Posting a Submission you warrant and represent that you own or otherwise control all of the rights to your Submission as described in these Terms of Use including, without limitation, all the rights necessary for you to provide, post, upload, input or submit the Submissions.
In addition to the warranty and representation set forth above, by Posting a Submission that contain images, photographs, pictures or that are otherwise graphical in whole or in part ("Images"), you warrant and represent that (a) you are the copyright owner of such Images, or that the copyright owner of such Images has granted you permission to use such Images or any content and/or images contained in such Images consistent with the manner and purpose of your use and as otherwise permitted by these Terms of Use and the Services, (b) you have the rights necessary to grant the licenses and sublicenses described in these Terms of Use, and (c) that each person depicted in such Images, if any, has provided consent to the use of the Images as set forth in these Terms of Use, including, by way of example, and not as a limitation, the distribution, public display and reproduction of such Images. By Posting Images, you are granting (a) to all members of your private community (for each such Images available to members of such private community), and/or (b) to the general public (for each such Images available anywhere on the Services, other than a private community), permission to use your Images in connection with the use, as permitted by these Terms of Use, of any of the Services, (including, by way of example, and not as a limitation, making prints and gift items which include such Images), and including, without limitation, a non-exclusive, world-wide, royalty-free license to: copy, distribute, transmit, publicly display, publicly perform, reproduce, edit, translate and reformat your Images without having your name attached to such Images, and the right to sublicense such rights to any supplier of the Services. The licenses granted in the preceding sentences for a Images will terminate at the time you completely remove such Images from the Services, provided that, such termination shall not affect any licenses granted in connection with such Images prior to the time you completely remove such Images. No compensation will be paid with respect to the use of your Images.
[](https://learn.microsoft.com/en-us/legal/termsofuse#notices-and-procedure-for-making-claims-of-copyright-infringement)
## Notices and Procedure for Making Claims of Copyright Infringement
Microsoft respects the intellectual property rights of third parties. If you wish to send a notice of intellectual property infringement, including claims of copyright infringement, please use our procedure for submitting [Notices of Infringement](https://www.microsoft.com/info/cpyrtinfrg.aspx). ONLY INQUIRIES RELEVANT TO THIS PROCEDURE WILL RECEIVE A RESPONSE.
Microsoft uses the processes set out in Title 17, United States Code, Section 512 to respond to notices of copyright infringement. In appropriate circumstances, Microsoft may also disable or terminate accounts of users of Microsoft services who may be repeat infringers.
[](https://learn.microsoft.com/en-us/legal/termsofuse#governing-law)
## Governing Law
The laws of the State of Washington govern these Terms of Use. If federal jurisdiction exists, the parties’ consent to exclusive jurisdiction and venue in the federal courts in King County, Washington. If not, the parties’ consent to the exclusive jurisdiction and venue in the Superior Court of King County, Washington.
[](https://learn.microsoft.com/en-us/legal/termsofuse#links-to-third-party-sites)
## Links to Third-Party Sites
THE LINKS IN THIS SERVICE MAY LET YOU LEAVE MICROSOFT'S SITE. THE LINKED SITES ARE NOT UNDER THE CONTROL OF MICROSOFT AND MICROSOFT IS NOT RESPONSIBLE FOR THE CONTENTS OF ANY LINKED SITE OR ANY LINK CONTAINED IN A LINKED SITE, OR ANY CHANGES OR UPDATES TO SUCH SITES. MICROSOFT IS NOT RESPONSIBLE FOR WEBCASTING OR ANY OTHER FORM OF TRANSMISSION RECEIVED FROM ANY LINKED SITE. MICROSOFT IS PROVIDING THESE LINKS TO YOU ONLY AS A CONVENIENCE, AND THE INCLUSION OF ANY LINK DOES NOT IMPLY ENDORSEMENT BY MICROSOFT OF THE SITE.
[](https://learn.microsoft.com/en-us/legal/termsofuse#unsolicited-idea-submission-policy-reservation-of-rights-and-feedback)
## Unsolicited Idea Submission Policy, Reservation of Rights and Feedback
MICROSOFT OR ANY OF ITS EMPLOYEES DO NOT ACCEPT OR CONSIDER UNSOLICITED IDEAS, INCLUDING IDEAS FOR NEW ADVERTISING CAMPAIGNS, NEW PROMOTIONS, NEW PRODUCTS OR TECHNOLOGIES, PROCESSES, MATERIALS, MARKETING PLANS OR NEW PRODUCT NAMES. PLEASE DO NOT SEND ANY ORIGINAL CREATIVE ARTWORK, SAMPLES, DEMOS, OR OTHER WORKS. THE SOLE PURPOSE OF THIS POLICY IS TO AVOID POTENTIAL MISUNDERSTANDINGS OR DISPUTES WHEN MICROSOFT'S PRODUCTS OR MARKETING STRATEGIES MIGHT SEEM SIMILAR TO IDEAS SUBMITTED TO MICROSOFT. SO, PLEASE DO NOT SEND YOUR UNSOLICITED IDEAS TO MICROSOFT OR ANYONE AT MICROSOFT. IF, DESPITE OUR REQUEST THAT YOU NOT SEND US YOUR IDEAS AND MATERIALS, YOU STILL SEND THEM, PLEASE UNDERSTAND THAT MICROSOFT MAKES NO ASSURANCES THAT YOUR IDEAS AND MATERIALS WILL BE TREATED AS CONFIDENTIAL OR PROPRIETARY.
Except as expressly provided under these TOU, Microsoft does not grant you a license or any other rights of any type under any patents, know-how, copyrights, trade secrets, trademarks or other intellectual property owned or controlled by Microsoft or any related entity, including but not limited to any name, trade dress, logo or equivalents. If you give to Microsoft any idea, proposal, suggestion or feedback, including without limitation ideas for the Services, new products, technologies, promotions, product names, product feedback and product improvements ("Feedback"), you give to Microsoft, without charge, royalties or other obligation to you, the right to make, have made, create derivative works, use, share and commercialize your Feedback in any way and for any purpose. You will not give Feedback that is subject to a license that requires Microsoft to license its software, technologies or documentation to any third party because Microsoft includes your Feedback in them.
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Flegal%2Ftermsofuse)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
