from abc import ABCMeta
from typing import Any, Dict, List, Callable
import inspect
from inspect import Parameter, Signature
from collections import defaultdict
import copy
import warnings
from uuid import UUID

# Replace these imports with your actual module paths
from .weavitae_reference import Reference
from .weaviate_property import Property
from .weaviate_utility import validate_method_params

from weaviate.classes.config import (
    Property as WeaviateProperty,
    ReferenceProperty as WeaviateReferenceProperty,
    Configure
)

from weaviate.collections.collections.sync import _Collections
from .weaviate_utility import validate_method_params
from weaviate.classes.config import Configure, DataType
from weaviate.collections.collections.sync import _Collections


def _order_parameters(params: list[Parameter]) -> list[Parameter]:
    """Enforce Python's positional-parameter rule: non-defaults must not follow defaults."""
    has_default = lambda p: p.default is not Parameter.empty

    pos_only_no_def   = [p for p in params if p.kind == Parameter.POSITIONAL_ONLY       and not has_default(p)]
    pos_only_with_def = [p for p in params if p.kind == Parameter.POSITIONAL_ONLY       and     has_default(p)]
    pok_no_def        = [p for p in params if p.kind == Parameter.POSITIONAL_OR_KEYWORD and not has_default(p)]
    pok_with_def      = [p for p in params if p.kind == Parameter.POSITIONAL_OR_KEYWORD and     has_default(p)]
    kw_only_any       = [p for p in params if p.kind == Parameter.KEYWORD_ONLY]

    # Optional: stabile Reihenfolge innerhalb der Gruppen beibehalten
    return (
        pos_only_no_def + pos_only_with_def +
        pok_no_def + pok_with_def +
        kw_only_any
    )

class Weaviate_Meta(ABCMeta):
    _weaviate_schema: dict[str, Any]
    _properties: list[Property]
    _references: list[Reference]
    _abstract : bool = True  # This is an abstract class set to False in all subclasses. If abstract is True, the class cannot created in Weaviate.

    """
    Metaclass that dynamically extracts model attributes to build Weaviate schemas.

    - If an attribute is an instance of `Property`, we treat it as a scalar property.
    - If it's a `Reference`, we treat it as a cross-reference property.
    - If a class variable `__collection_name__` is present, we use that name
      as the Weaviate class name instead of the Python class name.

    We also look for specific config attribute names (like "vector_config")
    to store in the final schema dict.
    """

    def __new__(mcs, name, bases, dct):
        cls = super().__new__(mcs, name, bases, dct)

        properties: List[Property] = []
        references: List[Reference] = []
        _handle_required_strict: bool = dct.get("_handle_required_strict", True)

        # Handle Callbacks
        setattr(cls, "_callbacks", dict(dct.get("_callbacks", {})))

        if name != "Base_Model":
            
            # Set abstract property of class
            if "_abstract" in dct:
                cls._abstract = dct["_abstract"]
            else:
                cls._abstract = False
            
            # Check if this class DIRECTLY uses PolymorphicParent (not inherited from a parent class)
            # A class uses it directly if PolymorphicParent is in the bases
            uses_polymorphic_parent_directly = any(
                base.__name__ == 'PolymorphicParent' or (isinstance(base, type) and hasattr(base, '_is_polymorphic_parent') and not getattr(base, '_is_concrete_polymorphic_parent', False))
                for base in bases
            )
            
            # Also track if we're a PolymorphicParent for inheritance purposes
            is_concrete_polymorphic_parent = False
            
            if uses_polymorphic_parent_directly:
                # PolymorphicParent classes MUST be concrete (not abstract)
                if dct.get("_abstract", False) is True:
                    raise ValueError(
                        f"Class {name} uses PolymorphicParent but has _abstract=True. "
                        f"Polymorphic parent classes must be concrete (set _abstract=False or remove it)."
                    )
                
                # Ensure __collection_name__ is set
                if "__collection_name__" not in dct:
                    warnings.warn(
                        f"PolymorphicParent class {name} should explicitly set __collection_name__. "
                        f"Using class name '{name}' as collection name.",
                        DeprecationWarning,
                        stacklevel=2
                    )
                
                is_concrete_polymorphic_parent = True
            
            # Check if we're a child of a PolymorphicParent (for property injection)
            is_polymorphic_parent = any(
                isinstance(base, type) and hasattr(base, '_is_polymorphic_parent')
                for base in bases
            )
            
            # Backward-compat: map non-underscored config attributes to underscored ones with a deprecation warning
            # CRITICAL: This must be done BEFORE building the schema, so that the schema uses the new names
            deprecated_map = (
                ("description", "_description"),
                ("vector_config", "_vector_config"),
                ("vector_index_config", "_vector_index_config"),
                ("inverted_index_config", "_inverted_index_config"),
                ("generative_config", "_generative_config"),
            )
            
            # Apply the mapping BOTH to dct (for initialization) and to cls (after creation)
            # This ensures the schema builder will use the underscored versions
            for old_key, new_key in deprecated_map:
                if old_key in dct and new_key not in dct:
                    # Skip mapping if the value is a Property or Reference (user-defined field, not config)
                    if isinstance(dct[old_key], (Property, Reference)):
                        continue
                    
                    warnings.warn(
                        f"Class attribute '{old_key}' is deprecated; use '{new_key}' instead. "
                        f"This will become an error in a future release.",
                        DeprecationWarning,
                        stacklevel=2,
                    )
                    # Map the old attribute to the new underscored version
                    dct[new_key] = dct[old_key]
                    # Also set it on the class object after creation
                    setattr(cls, new_key, dct[old_key])

            collection_name = dct.get("__collection_name__", name)
            weaviate_collection = {
                "name": collection_name,
                "description": dct.get("_description", ""),
                "properties": [],
                "references": [],
                "vector_config": None,
                "vector_index_config": None,
                "inverted_index_config": None,
                "generative_config": None,
            }

            # Auto-inject discriminator properties for direct PolymorphicParent classes ONLY
            # (NOT for children of polymorphic parents)
            if is_concrete_polymorphic_parent and "_object_uuid" not in dct:
                # Create discriminator properties
                object_uuid_prop = Property(
                    cast_type=UUID,
                    weaviate_type=DataType.UUID,
                    description="UUID of the concrete polymorphic object",
                    required=False,
                    default=None,
                    inherited=False
                )
                object_uuid_prop.name = "_object_uuid"
                object_uuid_prop.__set_name__(cls, "_object_uuid")
                setattr(cls, "_object_uuid", object_uuid_prop)
                # NOTE: Don't add to properties list yet - will be picked up in the loop below
                
                object_type_prop = Property(
                    cast_type=str,
                    weaviate_type=DataType.TEXT,
                    description="Type discriminator: concrete class name",
                    required=False,
                    default=None,
                    inherited=False
                )
                object_type_prop.name = "_object_type"
                object_type_prop.__set_name__(cls, "_object_type")
                setattr(cls, "_object_type", object_type_prop)
                # NOTE: Don't add to properties list yet - will be picked up in the loop below

            # 1) add properties/references defined *on this class body*
            # Iterate over a copy to avoid "dictionary changed size during iteration" error
            # when setattr() is called for polymorphic reference hidden properties
            for attr_name, attr_value in list(cls.__dict__.items()):
                if isinstance(attr_value, Property):
                    weaviate_collection["properties"].append(
                        attr_value._get_weaviate_property()
                    )
                    properties.append(attr_value)
                elif isinstance(attr_value, Reference):
                    # Add reference to schema
                    weaviate_collection["references"].append(
                        attr_value._get_weaviate_reference()
                    )
                    references.append(attr_value)

            # 2) inherit from bases: deep‑copy and *rebind* onto subclass if missing here
            for base in bases:
                for base_prop in getattr(base, "_properties", []):
                    if base_prop.name and base_prop.name not in cls.__dict__:
                        prop_copy = copy.deepcopy(base_prop)
                        prop_copy.inherited = True
                        setattr(cls, base_prop.name, prop_copy)
                        # ensure descriptor binding now that we set it dynamically
                        if hasattr(prop_copy, "__set_name__"):
                            prop_copy.__set_name__(cls, base_prop.name)

                        weaviate_collection["properties"].append(
                            prop_copy._get_weaviate_property()
                        )
                        properties.append(prop_copy)

                for base_ref in getattr(base, "_references", []):
                    if base_ref.name and base_ref.name not in cls.__dict__:
                        ref_copy = copy.deepcopy(base_ref)
                        ref_copy.inherited = True
                        setattr(cls, base_ref.name, ref_copy)
                        if hasattr(ref_copy, "__set_name__"):
                            ref_copy.__set_name__(cls, base_ref.name)

                        # Add reference to schema
                        weaviate_collection["references"].append(
                            ref_copy._get_weaviate_reference()
                        )
                        references.append(ref_copy)

            # 3) apply collection-level configs from class attributes if provided
            for key in (
                "_vector_config",
                "_vector_index_config",
                "_inverted_index_config",
                "_generative_config",
            ):
                val = getattr(cls, key, None)
                if val is not None:
                    weaviate_collection[key[1:]] = val  # Remove leading underscore for schema

            # 4) validate and attach schema, registries and dynamic __init__
            validate_method_params(_Collections.create, weaviate_collection)


            cls._weaviate_schema = weaviate_collection
            cls._properties = properties
            cls._references = references
            
            # Mark if this is a concrete polymorphic parent (for subclass detection)
            if is_concrete_polymorphic_parent:
                cls._is_concrete_polymorphic_parent = True

            if "__init__" not in dct:
                cls.__init__ = mcs._make_dynamic_init(properties=properties, references=references, handle_required_strict=_handle_required_strict)

        return cls
    
    @staticmethod
    def _make_dynamic_init(properties:list[Property], references:list[Reference], handle_required_strict: bool=True): #TODO: Rewrite this function!!!
        """
        Build a function with a dynamic signature for __init__.
        Each `Property` or `Reference` becomes a keyword parameter (with default if any).
        """
        # We'll build an inspect.Signature that has parameters for each property/ref.
        parameters = []

        # 0) Add the `self` parameter
        #parameters.append(
        #    Parameter(
        #        name="self",
        #        kind=Parameter.POSITIONAL_ONLY
        #    )
        #)

        # 1) Create parameters for each Property
        for prop in properties:
            # If the property has a default, use that; otherwise Parameter.empty
            if prop.default is not None:
                default_val = prop.default
            elif not prop.required or not handle_required_strict:
                default_val = None
            else:
                default_val = Parameter.empty
                
            kind = Parameter.POSITIONAL_OR_KEYWORD            

            if not prop.name:
                raise ValueError("Property name is not set.")
            
            #kind = Parameter.POSITIONAL_OR_KEYWORD

            parameters.append(
                Parameter(
                    name=prop.name,
                    kind=kind,
                    default=default_val,
                    annotation=prop.cast_type
                )
            )

        # 2) Create parameters for each Reference
        for ref in references:
            # Typically references won't have "default" in the same sense, but if you do:
            if not ref.required or not handle_required_strict:
                default_val = None
            else:
                default_val = Parameter.empty

            if not ref.name:
                raise ValueError("Reference field name is not set.")
            
            parameters.append(
                Parameter(
                    name=ref.name,
                    kind=Parameter.POSITIONAL_OR_KEYWORD,
                    default=default_val,
                    annotation=ref.target_collection_name  # Get type from the target collection name -> str to type
                )
            )

        # Order parameters by kind (POSITIONAL_ONLY, POSITIONAL_OR_KEYWORD, KEYWORD_ONLY) and with defaults last
        parameters = _order_parameters(parameters)


        # Build a signature with the above parameters
        sig = Signature(parameters=parameters)

        # Now define the actual function that uses that signature at runtime.
        def dynamic_init(self, *args, **kwargs):
            # Bind arguments to the signature -> enforces correct usage
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()

            # bound_args.arguments is an OrderedDict of (param_name -> value)
            # first argument is `self`, skip it when setting attributes
            for param_name, arg_val in list(bound_args.arguments.items()):
                if(param_name in self.__dict__):
                    raise ValueError(f"Parameter '{param_name}' already exists in the class.")
                setattr(self, param_name, arg_val)

            #Set uuid
            self.generate_uuid()

            #Set vector(s) to None
            if getattr(self, "vector_config", None) is not None:
                self.vector = None
                self.vectors = None  # For named vectors

        # Attach our custom signature to the function object
        dynamic_init.__signature__ = sig
        # For better debugging, give it a nice name:
        dynamic_init.__name__ = "__init__"

        return dynamic_init
