# minions-tasks

Task and work management across agents, humans, and workflows

## Installation

```bash
pip install minions-tasks
```

## Usage

```python
from minions_tasks import create_client

client = create_client()
```

## License

[MIT](../../LICENSE)
