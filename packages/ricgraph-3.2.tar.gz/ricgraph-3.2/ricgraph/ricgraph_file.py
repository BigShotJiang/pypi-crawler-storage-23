# ########################################################################
#
# Ricgraph - Research in context graph
#
# ########################################################################
#
# MIT License
#
# Copyright (c) 2023 - 2025 Rik D.T. Janssen
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
# ########################################################################
#
# Ricgraph file functions.
# For more information about Ricgraph and Ricgraph Explorer,
# go to https://www.ricgraph.eu and https://docs.ricgraph.eu.
#
# ########################################################################
#
# Original version Rik D.T. Janssen, December 2022.
# Updated Rik D.T. Janssen, February, March, September to December 2023.
# Updated Rik D.T. Janssen, February to June, September to December  2024.
# Updated Rik D.T. Janssen, January to June, October 2025.
#
# ########################################################################


from os import makedirs
from os.path import isfile, dirname, exists
from pandas import DataFrame, read_csv
from typing import Union
from csv import QUOTE_ALL
from json import load, dump


def write_json_to_file(filename:str,
                       json_data: Union[list, dict]) -> None:
    """Write json data to a file. This also works for dicts.
    If no records are harvested, nothing is written.

    :param filename: filename of the file to use for writing.
      It will also work if you specify a directory and filename.
    :param json_data: a list of records in json format.
      Can also be a dict.
    :return: None.
    """
    print('Writing json data to file ' + filename + '...', end=' ')
    if filename == '':
        print('write_json_to_file(): Error, filename is empty, exiting.')
        exit(1)

    dir_path = dirname(p=filename)
    if dir_path != '':
        try:
            if not exists(path=dir_path):
                makedirs(name=dir_path, exist_ok=True)
        except:
            print('write_json_to_file(): Error, could not create directory "' + dir_path + '", exiting.')
            exit(1)

    try:
        # Try opening the file for writing and immediately close it
        with open(filename, 'a'):
            pass
    except:
        # Generates a 'Local variable 'filename' might be referenced before assignment'
        # warning in PyCharm.
        print('write_json_to_file(): Error, filename "' + filename + '" is not writable, exiting.')
        exit(1)

    with open(filename, 'w') as fd:
        dump(obj=json_data, fp=fd, ensure_ascii=False, indent=2)
    print('Done.')
    return


def read_json_from_file(filename: str) -> list:
    """Read json data from a file.

    :param filename: filename of the file to use for writing.
    :return: list of records in json format, or empty list if nothing found.
    """
    print('Reading json data from file ' + filename + '...', end=' ')
    if not isfile(path=filename):
        print('read_json_from_file(): Error, file "' + filename + '" does not exist, exiting...')
        exit(1)

    with open(filename) as fd:
        json_data = load(fp=fd)
    print('Done.')
    if json_data is None:
        return []
    return json_data


def write_read_json_file(json_data: Union[list, dict],
                         filename: str = '') -> list:
    """In case filename != '', write the JSON to a file and
    then read it back. In any case, return the JSON data received.

    :param json_data: a list of records in json format.
    :param filename: If filename != '', write it to a file and read it back.
    :return: The JSON data received.
    """
    if filename == '':
        return json_data
    if len(json_data) == 0:
        return json_data

    write_json_to_file(filename=filename, json_data=json_data)
    json_from_file = read_json_from_file(filename=filename)
    return json_from_file


def write_dict_to_file(filename:str, json_data: dict) -> None:
    """Wrapper around write_json_to_file() for dicts.

    :param filename: filename of the file to use for writing.
      It will also work if you specify a directory and filename.
    :param json_data: a list of records in json format.
    :return: None.
    """
    write_json_to_file(filename=filename, json_data=json_data)
    return


def read_dict_from_file(filename: str) -> dict:
    """Wrapper around read_json_from_file() for dicts.

    :param filename: filename of the file to use for writing.
    :return: dict of records in json format, or empty dict if nothing found.
    """
    return dict(read_json_from_file(filename=filename))


def write_read_dict_file(json_data: dict,
                         filename: str = '') -> dict:
    """Wrapper around write_read_json_file() for dicts.

    :param json_data: a list of records in json format.
    :param filename: If filename != '', write it to a file and read it back.
    :return: The JSON data received, as a dict.
    """
    return dict(write_read_json_file(json_data=json_data,
                                     filename=filename))


def write_text_to_file(filename: str, text: str) -> None:
    """Write text data to a file, in utf-8 format.

    :param filename: filename of the file to use for writing.
      It will also work if you specify a directory and filename.
    :param text: the text data to write to the file.
    :return: None.
    """
    print('Writing text data to file ' + filename + '...', end=' ')
    if filename == '':
        print('write_text_to_file(): Error, filename is empty, exiting.')
        exit(1)

    dir_path = dirname(p=filename)
    if dir_path != '':
        try:
            if not exists(path=dir_path):
                makedirs(name=dir_path, exist_ok=True)
        except:
            print('write_text_to_file(): Error, could not create directory "' + dir_path + '", exiting.')
            exit(1)

    try:
        # Try opening the file for writing and immediately close it
        with open(filename, 'a'):
            pass
    except:
        # Generates a 'Local variable 'filename' might be referenced before assignment'
        # warning in PyCharm.
        print('write_text_to_file(): Error, filename "' + filename + '" is not writable, exiting.')
        exit(1)

    with open(filename, 'w', encoding='utf-8') as fd:
        fd.write(text)
    print('Done.')
    return


def write_dataframe_to_csv(filename: str,
                           df: DataFrame,
                           write_index: bool = False) -> None:
    """Write a DataFrame to file.

    :param filename: csv file to write.
      It will also work if you specify a directory and filename.
    :param df: dataframe to write.
    :param write_index: whether to write the index of the DataFrame
      as first column to the csv file (True) or not (False).
    :return: None.
    """
    print('Writing DataFrame to csv file ' + filename + '...', end=' ')
    if df is None or df.empty:
        print('write_dataframe_to_csv(): Empty DataFrame, nothing to write, continuing.')
        return

    if filename == '':
        print('write_dataframe_to_file(): Error, filename is empty, exiting.')
        exit(1)

    dir_path = dirname(p=filename)
    if dir_path != '':
        try:
            if not exists(path=dir_path):
                makedirs(name=dir_path, exist_ok=True)
        except:
            print('write_dataframe_to_csv(): Error, could not create directory "' + dir_path + '", exiting.')
            exit(1)

    try:
        # Try opening the file for writing and immediately close it
        with open(filename, 'a'):
            pass
    except:
        # Generates a 'Local variable 'filename' might be referenced before assignment'
        # warning in PyCharm.
        print('write_dataframe_to_csv(): Error, filename "' + filename + '" is not writable, exiting.')
        exit(1)

    # PyCharm generates a warning
    # "Unexpected type(s):(str, str, bool, str, int, str) [etc]...".
    df.to_csv(filename,
              sep=',',
              quotechar='"',
              quoting=QUOTE_ALL,
              encoding='utf-8',
              index=write_index)
    print('Done.')
    return


def read_dataframe_from_csv(filename: str,
                            columns: dict = None,
                            nr_rows: int = None,
                            datatype=str,
                            read_index: bool = False) -> DataFrame:
    """Read a DataFrame from csv file.

    :param filename: csv file to read.
    :param columns: which columns to read.
    :param nr_rows: how many rows to read (default: all).
    :param datatype: type of (some) columns to read.
    :param read_index: whether to use the first column
      from the csv file (True) or not (False) for index in the DataFrame.
    :return: dataframe read.
    """
    print('Reading DataFrame from csv file ' + filename + '...', end=' ')
    if not isfile(path=filename):
        print('read_dataframe_from_csv(): Error, file "' + filename + '" does not exist, exiting...')
        exit(1)

    # Note the inconsistent type of 'index_col'.
    if read_index:
        index_col = 0
    else:
        index_col = False

    try:
        # Some input files have problems reading in utf-8.
        csv_data = read_csv(filename,
                            sep=',',
                            index_col=index_col,
                            usecols=columns,
                            dtype=datatype,
                            engine='python',
                            nrows=nr_rows,
                            keep_default_na=False,
                            parse_dates=False,
                            iterator=False,
                            quotechar='"',
                            encoding='utf-8')
    except BaseException:
        print('read_dataframe_from_csv(): error reading in utf-8 format, reading in latin-1 format.')
        csv_data = read_csv(filename,
                            sep=',',
                            index_col=index_col,
                            usecols=columns,
                            dtype=datatype,
                            engine='python',
                            nrows=nr_rows,
                            keep_default_na=False,
                            parse_dates=False,
                            iterator=False,
                            quotechar='"',
                            encoding='latin-1')
    print('Done.')
    return csv_data
