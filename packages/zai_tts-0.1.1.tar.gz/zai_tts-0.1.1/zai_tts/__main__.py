from . import main

main()
