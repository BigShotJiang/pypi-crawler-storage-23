# 🗣️ ZAI/GLM TTS

## Install / 安装

### 🐳 Docker compose
```shell
mkdir /opt/zai-tts
cd /opt/zai-tts
echo "ZAI_USERID=xxxx-yyyy" > .env
echo "ZAI_TOKEN=eyJhbGc..." >> .env
wget https://raw.githubusercontent.com/aahl/zai-tts/refs/heads/main/docker-compose.yml
docker compose up -d
```
> `ZAI_USERID`和`ZAI_TOKEN`可在`audio.z.ai`登录后，通过F12开发者工具在控制台执行`localStorage['auth-storage']`获取

### 🐳 Docker run
```shell
docker run -d \
  --name zai-tts \
  --restart=unless-stopped \
  -p 8823:80 \
  -e ZAI_USERID=xxxx-yyyy \
  -e ZAI_TOKEN=eyJhbGc... \
  ghcr.io/aahl/zai-tts:main
```

### 🤖 Agent Skills
```shell
npx skills add aahl/skills --skill zai-tts
```

### 🏠 Home Assistant OS Add-on
1. 添加加载项仓库
   * 打开 HomeAssistant，点击左侧菜单的 **配置 (Settings)** -> **加载项 (Add-ons)**
   * 点击右下角的 **加载项商店 (Add-on Store)**
   * 点击右上角的三个点 -> **仓库 (Repositories)**
   * 在输入框填入：`https://gitee.com/hasscc/addons`, 点击添加
   * 或者点击此按钮一键添加: [![添加加载项仓库](https://my.home-assistant.io/badges/supervisor_add_addon_repository.svg)](https://my.home-assistant.io/redirect/supervisor_add_addon_repository/?repository_url=https%3A%2F%2Fgitee.com%2Fhasscc%2Faddons)

2. **安装加载项**：
   * 刷新页面，找到并点击 **`智谱TTS`**
   * 点击 **安装 (Install)**
   * 切换到 **配置** 标签页，添加`ZAI_USERID`和`ZAI_TOKEN`环境变量
   * 启动并设置开机启动


## 💻 Usage / 使用

### 🎼 内置音色
- `system_001`: 活泼女声
- `system_002`: 温柔女声
- `system_003`: 通用男声

> 如果想要使用克隆的音色，请在`audio.z.ai`完成音色克隆，并通过接口`http://localhost:8823/v1/models`获取

### 🌐 CURL调用示例
```shell
curl --request POST \
  --url http://localhost:8823/v1/audio/speech \
  --header 'Content-Type: application/json' \
  --data '{"voice":"system_001", "input":"hello", "speed":1.0, "volume":1}' \
  --output output.wav
```

### 🐚 命令行
```shell
uvx zai-tts -h

# 获取音色
uvx zai-tts -l

# 语音合成
uvx zai-tts -t 'Hello, world' -o hello.wav
uvx zai-tts -t 'Hello, world' -v system_001 --speed 1.2 > hello.wav 
```

### 🏠 Home Assistant
1. 安装 AI Conversation 集成
   > 点击这里 [一键安装](https://my.home-assistant.io/redirect/hacs_repository/?category=integration&owner=hasscc&repository=ai-conversation)，安装完记得重启HA
2. [添加 AI Conversation 服务](https://my.home-assistant.io/redirect/config_flow_start/?domain=ai_conversation)，配置模型提供商
   > 服务商: 自定义; 接口: `http://4e0de88e-zai-tts/v1`; 密钥留空
3. 添加TTS模型，模型ID随意
4. 配置语音助手
