class DoesNotExist(FileNotFoundError):
    pass
