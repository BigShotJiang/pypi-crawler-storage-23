# Skir Python Client

Library imported from Python code generated from skir files.

Install with:
```shell
pip install skir-client
```

See:

*   [skir](https://github.com/gepheum/skir): home of the skir compiler
*   [skir-python-gen](https://github.com/gepheum/skir-python-gen): skir to Python code generator
*   [skir-python-example](https://github.com/gepheum/skir-python-example): example showing how to use skir's Python code generator in a project
