from yta_validation import PythonValidator
from dataclasses import dataclass
from typing import Union


@dataclass(frozen = True)
class ParameterSpecification:
    """
    Class to specify the conditions of a parameter
    that must be used within a node, including the
    type, the default value if existing, or a
    minimum and/or maximum value if set.

    A type that is not orderable not comparable 
    must not include `min` nor `max` parameter or
    an exception will be raised. 
    """

    name: str
    """
    The name of the parameter to set, that must be
    unique for that specific node and method.
    """
    # TODO: Set the type (?)
    type: any
    """
    The type of parameter we are accepting, that
    can be `float`, `int`, `str`, etc.
    """
    is_required: bool = False
    """
    Boolean flag to indicate if this parameter is
    required (mandatory) or not (optional).
    """
    default: Union[any, None] = None
    """
    The default value we want for this parameter,
    that will be used if the user doesn't provide
    a value.
    """
    min: Union[float, None] = None
    """
    The minimum possible value for this parameter,
    that can be `None` if we accept any value (if
    we don't want to limit it).
    """
    max: Union[float, None] = None
    """
    The maximum possible value for this parameter,
    that can be `None` if we accept any value (if
    we don't want to limit it).
    """

    def __post_init__(
        self
    ):
        if (
            self.default is not None and
            self.min is not None and
            self.default < self.min
        ):
            raise Exception('The default value provided is under the minimum.')
        
        if (
            self.default is not None and
            self.max is not None and
            self.default > self.max
        ):
            raise Exception('The default value provided is over the maximum.')

class ParameterSpecificationValidator:
    """
    Class to validate if a parameter value is
    accepted according to the specification
    provided.
    """

    @staticmethod
    def validate_parameter(
        key: str,
        value: any,
        specification: ParameterSpecification
    ) -> Union[any, None]:
        """
        Validate that the `key` provided is associated to
        the `specification` and that the `value` given is
        valid according to that same specification.

        This method will return the value of the parameter,
        that could be the default one if existing and the
        `value` provided was `None`.
        """
        if key != specification.name:
            raise Exception('The "key" provided is not associated to the specification given.')
        
        if (
            value is None and
            specification.is_required and
            specification.default is None
        ):
            raise Exception(f'The "value" of the "{key}" parameter provided is `None` and the specification is required and does not have any default value.')
        
        if (
            value is None and
            specification.default is not None
        ):
            value = specification.default

        value = (
            specification.default
            if value is None else
            value
        )

        if value is not None:
            if not PythonValidator.is_instance_of(value, specification.type):
                raise Exception(f"The '{specification.name}' parameter value must be '{specification.type}'")

            if PythonValidator.is_orderable(value):
                if (
                    specification.min is not None and
                    value < specification.min
                ):
                    raise Exception(f"'The '{specification.name}' parameter value is below the min={specification.min}")

                if (
                    specification.max is not None and
                    value > specification.max
                ):
                    raise Exception(f"'The '{specification.name}' parameter value is above the max={specification.max}")
        
        return value


    @staticmethod
    def validate_parameters(
        parameters: dict[str, any],
        parameter_specifications: list[ParameterSpecification]
    ) -> Union[dict[str, any], None]:
        """
        Validate that the `parameters` provided are accepted
        and valid for the `parameter_specifications` given,
        which means that the required values are provided and
        the values have the accepted type and valid values.

        This method will return the `parameters` dict that
        could have been modified by replacing `None` values
        for the ones specified as default values.
        """

        tmp_parameters = {}
        for parameter_specification in parameter_specifications:
            key = parameter_specification.name
            value = (
                parameters[key]
                if key in parameters else
                None
            )

            tmp_parameters[key] = ParameterSpecificationValidator.validate_parameter(
                key = key,
                value = value,
                specification = parameter_specification
            )
            
        """
        Using this new dict we will only preserve those
        parameters that are registered as expected, avoiding
        errors with unexpected parameters reaching the nodes.
        """
        return tmp_parameters