"""
TODO: Maybe this 'validation' module must be
moved to the 'yta-editor-parameters' library
and refactor the Parameter concept we have
there because it is more a Parametervalue
concept.
"""