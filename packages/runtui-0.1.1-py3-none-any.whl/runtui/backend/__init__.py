"""Terminal backend abstraction layer."""
