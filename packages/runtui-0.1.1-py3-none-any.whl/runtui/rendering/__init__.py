"""Rendering pipeline: buffers, screen management, and painter."""
