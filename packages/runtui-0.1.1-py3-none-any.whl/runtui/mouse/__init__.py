"""Mouse cursor and tracking."""
