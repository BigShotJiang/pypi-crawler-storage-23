"""Dialog windows (file open, save, message box, etc.)."""
