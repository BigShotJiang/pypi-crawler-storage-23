"""Core types, events, and event loop for runtui."""
