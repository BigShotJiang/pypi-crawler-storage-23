# Project State

<!-- Persistent snapshot — any agent updates this at session end. -->

## Current Focus

- (What is being worked on right now)

## Next

1. (Priority item)
2. (Priority item)
3. (Priority item)

## Blockers

- None

## Recent Decisions

- (Link to `DECISIONS.md` entry or one-line summary)

## Last Updated

<!-- Update this date whenever you modify this file. -->
YYYY-MM-DD
