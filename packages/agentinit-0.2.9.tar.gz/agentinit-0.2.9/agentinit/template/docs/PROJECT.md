# Project Context

**Purpose:** TBD (Describe what this project is for and expected outcomes)

## Stack

- **Runtime:** TBD
- **Language(s):** TBD
- **Framework(s):** TBD
- **Storage/Infra:** TBD

## Commands (TBD)

- Setup: TBD
- Build: TBD
- Test: TBD
- Lint/Format: TBD
- Run: TBD

## Layout

- `AGENTS.md`: Primary router.
- `docs/`: Source-of-truth context and memory files.
- `src/`: TBD
- `tests/`: TBD

## Constraints

- **Security:** TBD
- **Performance:** TBD
- **Deadlines/Limits:** TBD
