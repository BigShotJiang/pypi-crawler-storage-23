"""LLM related functions."""
import logging

logger = logging.getLogger(__name__)

import json

from google import genai
from google.genai import types
from openai import AsyncOpenAI as OpenAI

from src.io import get_gcp_labels
from src.utils import cache_on_disk


# flake8: noqa
# pylint: disable=all
class LlmClient:
    """A client for interacting with large language models (LLMs)."""

    def __init__(self, openai_key=None, parameters=None, genai_client=None):
        """Initialize the LLM client."""
        self.genai_client = genai_client

        # Initialize the model parameters
        self.model_params = {
            "temperature": parameters.get("temperature", 0),
            "max_output_tokens": parameters.get("maxOutputTokens", 65536),
            "top_p": parameters.get("top_p", 0.8),
            "top_k": parameters.get("top_k", 40),
            "seed": parameters.get("seed", 42),
        }
        self.model_id = parameters.get("model_id", "gemini-2.5-flash")
        self.thinking_level = parameters.get("thinking_level")

        # Initialize the safety configuration (new format: list of SafetySetting objects)
        self.safety_settings = [
            types.SafetySetting(
                category="HARM_CATEGORY_DANGEROUS_CONTENT", threshold="OFF"
            ),
            types.SafetySetting(category="HARM_CATEGORY_HARASSMENT", threshold="OFF"),
            types.SafetySetting(category="HARM_CATEGORY_HATE_SPEECH", threshold="OFF"),
            types.SafetySetting(
                category="HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold="OFF"
            ),
        ]

        if openai_key is not None:
            # Initialize the ChatGPT client
            self.chatgpt_client = self._create_client_chatgpt(openai_key)

    def _create_client_chatgpt(self, openai_key):
        client = OpenAI(api_key=openai_key)
        return client

    async def ask_gemini(
        self,
        prompt: str,
        document: types.Part = None,
        response_schema: dict = None,
        response_mime_type: str = "application/json",
        doc_type: str = None,
    ):
        """Ask the Gemini model a question.

        Args:
            prompt (str): The prompt to send to the model.
            document (types.Part, optional): An optional document to provide context.
            response_schema (dict, optional): Defines a specific response schema for the model.
            doc_type (str, optional): Document type for cost tracking labels.

        Returns:
            str: The response from the model.
        """
        try:
            # Build config with all parameters
            config_params = {
                **self.model_params,
                "safety_settings": self.safety_settings,
                "labels": get_gcp_labels(doc_type=doc_type),
            }

            # Add thinking config for Gemini 3 models
            if self.thinking_level:
                config_params["thinking_config"] = types.ThinkingConfig(
                    thinking_level=self.thinking_level
                )

            if response_schema is not None:
                config_params["response_schema"] = response_schema
                config_params["response_mime_type"] = response_mime_type

            config = types.GenerateContentConfig(**config_params)
            contents = [document, prompt] if document else prompt

            # Use async client
            model_response = await cache_on_disk(
                self.genai_client.aio.models.generate_content,
                model=self.model_id,
                contents=contents,
                config=config,
            )

            return model_response.text

        except Exception as e:
            logger.error(f"Failed to generate response: {str(e)}")
            return "{}"

    async def get_unified_json_genai(
        self, prompt, document=None, response_schema=None, model="gemini", doc_type=None
    ):
        """Send a prompt to a Google Cloud AI Platform model and returns the generated json.

        Args:
            prompt (str): The prompt to send to the LLM model.
            document: Content of the PDF document
            response_schema: The schema to use for the response
            model (str): The model to use for the response ["gemini" or "chatGPT"]. Default is "gemini".
            doc_type (str, optional): Document type for cost tracking labels.

        Returns:
            dict: The generated json from the model.
        """
        # Ask the LLM model
        if model.lower() in {"chatgpt", "openai", "gpt"}:
            response = await self.ask_chatgpt(prompt, document, response_schema)
        else:
            # Default to Gemini
            response = await self.ask_gemini(
                prompt, document, response_schema, doc_type=doc_type
            )

        return json.loads(response)

    def prepare_document_for_gemini(self, file_content: bytes) -> types.Part:
        """Prepare a document from file content for the Gemini model.

        Args:
            file_content (bytes): The binary content of the file to be processed.

        Returns:
            types.Part: A document object ready for processing by the language model.
        """
        return types.Part.from_bytes(
            data=file_content,
            mime_type="application/pdf",
        )

    async def ask_chatgpt(self, prompt: str, document=None, response_schema=None):
        """Ask the chatgpt model a question.

        Args:
            prompt (str): The prompt to ask the model.
            document (base64): the image to send the model
            response_schema (dict): The schema to use for the response
        Returns:
            str: The response from the model.
        """
        # Check if chatgpt_client was initialised
        if self.chatgpt_client is None:
            logger.error("Attempting to call chatgpt model that was not initialised.")
            return ""

        inputs = [{"type": "text", "text": prompt}]
        if document:
            inputs.append(
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/jpeg;base64,{document}",
                    },
                }
            )
        completion = await cache_on_disk(
            self.chatgpt_client.chat.completions.create,
            model="gpt-4o",
            temperature=0.1,
            messages=[{"role": "user", "content": inputs}],
            response_format=response_schema,
        )
        response = completion.choices[0].message.content
        return response


# pylint: enable=all
