import re
from enum import Enum
from pathlib import Path

from pydantic import BaseModel, ConfigDict, field_validator, model_validator

from depictio.models.config import DEPICTIO_CONTEXT
from depictio.models.logging import logger
from depictio.models.models.base import MongoModel
from depictio.models.models.data_collections_types.geojson import DCGeoJSONConfig
from depictio.models.models.data_collections_types.image import DCImageConfig
from depictio.models.models.data_collections_types.jbrowse import DCJBrowse2Config
from depictio.models.models.data_collections_types.multiqc import DCMultiQC
from depictio.models.models.data_collections_types.table import DCTableConfig


class DataCollectionSource(str, Enum):
    """Origin/source type of a data collection."""

    NATIVE = "native"  # Ingested from external files/sources (requires scan)
    JOINED = "joined"  # Derived from joining other DCs (no scan needed)
    AGGREGATED = "aggregated"  # Future: aggregations, transformations, etc.


class WildcardRegexBase(BaseModel):
    name: str
    wildcard_regex: str

    class Config:
        extra = "forbid"  # Reject unexpected fields

    @field_validator("wildcard_regex")
    def validate_files_regex(cls, v):
        try:
            re.compile(v)
            return v
        except re.error:
            raise ValueError("Invalid regex pattern")


class Regex(BaseModel):
    pattern: str
    wildcards: list[WildcardRegexBase] | None = None

    class Config:
        extra = "forbid"  # Reject unexpected fields

    @field_validator("pattern")
    def validate_files_regex(cls, v):
        try:
            re.compile(v)
            return v
        except re.error:
            raise ValueError("Invalid regex pattern")


class ScanRecursive(BaseModel):
    regex_config: Regex
    max_depth: int | None = None
    ignore: list[str] | None = None

    class Config:
        extra = "forbid"


class ScanSingle(BaseModel):
    filename: str

    class Config:
        extra = "forbid"

    @field_validator("filename")
    def validate_filename(cls, v):
        # Basic validation
        if not v:
            raise ValueError("Filename cannot be empty")

        # Check if this is a Docker container path
        is_docker_path = str(v).startswith("/app/depictio/")

        # Only validate file existence in CLI context for non-Docker paths
        if DEPICTIO_CONTEXT.lower() == "cli" and not is_docker_path:
            # Add debugging
            import os

            current_dir = os.getcwd()
            abs_path = os.path.abspath(v)
            normalized_path = os.path.normpath(v)

            # Log the paths for debugging
            logger.debug(f"Current working directory: {current_dir}")
            logger.debug(f"Relative path: {v}")
            logger.debug(f"Absolute path: {abs_path}")
            logger.debug(f"Normalized path: {normalized_path}")
            logger.debug(f"Path exists check: {Path(v).exists()}")

            # Try to see if the file exists with different path resolutions
            resolved_path = Path(v).resolve()
            logger.debug(f"Resolved path: {resolved_path}")
            logger.debug(f"Resolved path exists: {resolved_path.exists()}")

            # Validate file exists for local paths
            if not Path(v).exists():
                raise ValueError(f"File {v} does not exist")
        return v


class Scan(BaseModel):
    mode: str
    scan_parameters: ScanRecursive | ScanSingle

    @field_validator("mode")
    def validate_mode(cls, v):
        allowed_values = ["recursive", "single"]
        if v.lower() not in allowed_values:
            raise ValueError(f"mode must be one of {allowed_values}")
        return v

    @model_validator(mode="before")
    def validate_join(cls, values):
        type_value = values.get("mode").lower()  # normalize to lowercase for comparison
        scan_parameters = values.get("scan_parameters")
        if type_value == "recursive":
            if not isinstance(scan_parameters, ScanRecursive):
                if isinstance(scan_parameters, dict) and "regex_config" in scan_parameters:
                    try:
                        values["scan_parameters"] = ScanRecursive(**scan_parameters)  # type: ignore[missing-argument]
                    except Exception:
                        # Keep original if conversion fails
                        pass
        elif type_value == "single":
            if not isinstance(scan_parameters, ScanSingle):
                if isinstance(scan_parameters, dict) and "filename" in scan_parameters:
                    try:
                        values["scan_parameters"] = ScanSingle(**scan_parameters)  # type: ignore[missing-argument]
                    except Exception:
                        # Keep original if conversion fails
                        pass
        return values


class TableJoinConfig(BaseModel):
    on_columns: list[str]
    how: str = "inner"
    with_dc: list[str]

    class Config:
        extra = "forbid"  # Reject unexpected fields

    @field_validator("how")
    def validate_join_how(cls, v):
        allowed_values = ["inner", "outer", "left", "right"]
        if v.lower() not in allowed_values:
            raise ValueError(f"join_how must be one of {allowed_values}")
        return v


class DataCollectionConfig(MongoModel):
    type: str
    source: DataCollectionSource = DataCollectionSource.NATIVE
    metatype: str | None = None
    scan: Scan | None = None
    dc_specific_properties: (
        DCTableConfig | DCJBrowse2Config | DCMultiQC | DCImageConfig | DCGeoJSONConfig
    )
    join: TableJoinConfig | None = None

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    @field_validator("source", mode="before")
    @classmethod
    def validate_source(cls, v):
        """Handle string-to-enum conversion for source field."""
        # Already an enum - return as-is
        if isinstance(v, DataCollectionSource):
            return v

        # None or missing - use default
        if v is None:
            return DataCollectionSource.NATIVE

        # String conversion
        if not isinstance(v, str):
            raise ValueError(f"Invalid type for source field: {type(v)}")

        # Handle enum name strings ("DataCollectionSource.NATIVE")
        if v.startswith("DataCollectionSource."):
            enum_member_name = v.split(".")[-1]
            try:
                return DataCollectionSource[enum_member_name]
            except KeyError:
                raise ValueError(f"Invalid DataCollectionSource member: {enum_member_name}")

        # Handle enum value strings ("native", "joined", "aggregated")
        try:
            return DataCollectionSource(v)
        except ValueError:
            valid_values = ", ".join(e.value for e in DataCollectionSource)
            raise ValueError(f"Invalid source value: {v}. Must be one of: {valid_values}")

    @field_validator("type", mode="before")
    def validate_type(cls, v):
        allowed_values = ["table", "jbrowse2", "multiqc", "image", "geojson"]
        lower_v = v.lower()
        if lower_v not in allowed_values:
            raise ValueError(f"type must be one of {allowed_values}")
        return lower_v  # return the normalized lowercase value

    @model_validator(mode="before")
    def validate_join(cls, values):
        type_value = values.get("type").lower()  # normalize to lowercase for comparison
        # logger.debug(f"Validating join for type: {type_value}")

        # Get the dc_specific_properties
        dc_specific_properties = values.get("dc_specific_properties")

        if type_value == "table":
            # Check if it's already a DCTableConfig instance
            if not isinstance(dc_specific_properties, DCTableConfig):
                if isinstance(dc_specific_properties, dict) and "format" in dc_specific_properties:
                    try:
                        values["dc_specific_properties"] = DCTableConfig(**dc_specific_properties)
                    except Exception:
                        # Keep original if conversion fails
                        pass
        elif type_value == "jbrowse2":
            # Check if it's already a DCJBrowse2Config instance
            if not isinstance(dc_specific_properties, DCJBrowse2Config):
                if isinstance(dc_specific_properties, dict):
                    values["dc_specific_properties"] = DCJBrowse2Config(**dc_specific_properties)
        elif type_value == "multiqc":
            # For MultiQC, scan field is optional - it will be handled by the processing logic
            # Check if it's already a DCMultiQC instance
            if not isinstance(dc_specific_properties, DCMultiQC):
                if isinstance(dc_specific_properties, dict):
                    values["dc_specific_properties"] = DCMultiQC(**dc_specific_properties)
                else:
                    # Initialize with empty DCMultiQC if not provided
                    values["dc_specific_properties"] = DCMultiQC()
        elif type_value == "image":
            # Image type for image gallery components
            if not isinstance(dc_specific_properties, DCImageConfig):
                if isinstance(dc_specific_properties, dict):
                    values["dc_specific_properties"] = DCImageConfig(**dc_specific_properties)
                else:
                    # Initialize with default DCImageConfig if not provided
                    values["dc_specific_properties"] = DCImageConfig()
        elif type_value == "geojson":
            if not isinstance(dc_specific_properties, DCGeoJSONConfig):
                if isinstance(dc_specific_properties, dict):
                    values["dc_specific_properties"] = DCGeoJSONConfig(**dc_specific_properties)
                else:
                    values["dc_specific_properties"] = DCGeoJSONConfig()

        # Validate that scan is provided for non-MultiQC types and native sources
        source = values.get("source", "native")  # Default to string value

        # With use_enum_values=True, source is stored as string, so compare with string
        is_native_source = (
            source == "native"
            or source == DataCollectionSource.NATIVE
            or (isinstance(source, str) and source.endswith(".NATIVE"))
        )

        # Skip scan validation for MultiQC type only
        # - MultiQC: has its own data handling
        # - Image: now requires scan config (works like Table DC with mandatory image_column)
        skip_scan_types = ["multiqc"]
        if type_value not in skip_scan_types and is_native_source and not values.get("scan"):
            raise ValueError(
                "scan field is required for native data collections "
                "(ingested from external sources). For joined/derived data collections, "
                "set source='joined' to skip scan validation."
            )

        return values


class DataCollection(MongoModel):
    data_collection_tag: str
    config: DataCollectionConfig

    def __eq__(self, other):
        if isinstance(other, DataCollection):
            return all(
                getattr(self, field) == getattr(other, field)
                for field in self.model_fields.keys()
                if field not in ["id", "registration_time"]
            )
        return NotImplemented


class DataCollectionResponse(DataCollection):
    """Permissive DataCollection model for API responses.

    Allows extra fields like delta_location and last_aggregation
    that may be added by API endpoints.
    """

    model_config = ConfigDict(extra="allow")
