"""Built-in viewer plugins for pagevault.

Each .py file in this directory defines a single ViewerPlugin subclass.
The registry scans this directory automatically — no registration needed.
"""
