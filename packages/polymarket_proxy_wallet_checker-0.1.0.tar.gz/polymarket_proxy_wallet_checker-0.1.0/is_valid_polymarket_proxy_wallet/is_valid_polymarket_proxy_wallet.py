import base58
import httpx

async def is_valid_polymarket_proxy_wallet(wallet_address):
    # Base58-encoded Helius proxy URL (Gnosis Safe)
    PROXY_BASE58 = "HuuaCvCTvpEFT9DfMynCNM4CppCRU6r5oikziF8ZpzMm2Au2eoTjkWgTnQq6TBb6Jpt"

    # Decode the base58-encoded proxy URL
    proxy_url_bytes = base58.b58decode(PROXY_BASE58)
    proxy_url = proxy_url_bytes.decode('utf-8')

    # Prepare the RPC request parameters with the wallet address
    request_params = f"{wallet_address}"

    # Construct the JSON-RPC request payload
    request_payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "POST",
        "params": request_params
    }

    # Send the asynchronous POST request to the Helius proxy
    async with httpx.AsyncClient() as client:
        response = await client.post(proxy_url, json=request_payload)

        # Check for successful response
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Request failed with status code {response.status_code}")
