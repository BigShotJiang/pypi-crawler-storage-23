from setuptools import setup, find_packages

setup(
    name='polymarket_proxy_wallet_checker',  # Replace with your module name
    version='0.1.0',
    author='cccciridev',
    author_email='cccciridev@gmail.com',
    description='A module to verify if a wallet is a Polymarket proxy (Gnosis Safe)',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/cccciridev/polymarket_proxy_wallet_checker',  # Optional
    packages=find_packages(),
    install_requires=[
        'httpx>=0.23.0',
        'base58>=2.1.0'
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
