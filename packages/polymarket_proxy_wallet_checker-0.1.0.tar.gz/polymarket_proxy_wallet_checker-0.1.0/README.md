# Polymarket Proxy Wallet Validator

A Python module to verify if a given wallet address is a valid Polymarket proxy on the Solana blockchain using Helius API.

---

## Features

- Asynchronously checks the validity of a wallet as a Polymarket proxy.
- Utilizes Helius's proxy URL decoded from a base58 string.
- Easy to integrate into your Python projects.

---

## Installation

Ensure you have the required dependencies:

```bash
pip install httpx
